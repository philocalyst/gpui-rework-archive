use gpui::{AppContext, Context, IntoElement, Render, Window, div, prelude::*, px, rgb, text};

struct LayoutDemo;

impl Render for LayoutDemo {
    fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
        div()
            .size_full()
            .p_6()
            .flex()
            .flex_col()
            .gap_4()
            .bg(rgb(0xf7f6f2))
            .child(
                div()
                    .h(px(40.))
                    .flex_shrink_0()
                    .flex()
                    .items_center()
                    .px_3()
                    .bg(rgb(0x155b50))
                    .text_color(rgb(0xffffff))
                    .child(text!("A stable header in normal flow")),
            )
            .child(
                div()
                    .id("content")
                    .flex_1()
                    .min_h_0()
                    .flex()
                    .gap_4()
                    .child(
                        div()
                            .flex_1()
                            .min_w_0()
                            .flex_shrink_1()
                            .p_4()
                            .bg(rgb(0xdbeee8))
                            .text_color(rgb(0x202b29))
                            .child(text!(
                                "This pane yields before its sibling when the row gets narrow."
                            )),
                    )
                    .child(
                        div()
                            .w(px(180.))
                            .flex_shrink_0()
                            .p_4()
                            .bg(rgb(0xffd8a8))
                            .text_color(rgb(0x202b29))
                            .child(text!("Fixed pane")),
                    ),
            )
    }
}

fn component(_window: &mut Window, cx: &mut gpui::App) -> gpui::Entity<LayoutDemo> {
    cx.new(|_cx| LayoutDemo)
}

pub fn main() {
    support::run(component);
}

mod support {
    //! Platform setup shared by the walkthroughs; each downloaded main.rs includes it.
    use gpui::{App, Entity, Render, Window, WindowOptions};

    pub fn run<V: Render>(build: impl FnOnce(&mut Window, &mut App) -> Entity<V> + 'static) {
        #[cfg(not(target_family = "wasm"))]
        gpui_platform::application().run(move |cx| {
            cx.on_window_closed(|cx, _| {
                if cx.windows().is_empty() {
                    cx.quit();
                }
            })
            .detach();
            open(build, cx);
        });

        #[cfg(target_family = "wasm")]
        {
            use gpui::{Application, ApplicationHandle};
            use std::{cell::RefCell, rc::Rc, sync::Arc};
            thread_local! {
                static APPLICATION: RefCell<Option<ApplicationHandle>> = const { RefCell::new(None) };
            }
            gpui_web::init_logging();
            let platform = Rc::new(gpui_web::WebPlatform::new(false));
            let client = Arc::new(platform.fetch_http_client());
            let handle = Application::with_platform(platform)
                .with_http_client(client)
                .run_embedded(move |cx| {
                    use std::borrow::Cow;
                    cx.text_system()
                        .add_fonts(vec![Cow::Borrowed(include_bytes!(
                            "../../../assets/fonts/ibm-plex-sans/IBMPlexSans-Regular.ttf"
                        ) as &[u8])])
                        .expect("load the preview font");
                    open(build, cx);
                });
            APPLICATION.with(|slot| *slot.borrow_mut() = Some(handle));
            if let Some(window) = web_sys::window() {
                if let Ok(Some(parent)) = window.parent() {
                    let _ = parent
                        .post_message(&wasm_bindgen::JsValue::from_str("gpui-preview-ready"), "*");
                }
            }
        }
    }

    fn open<V: Render>(build: impl FnOnce(&mut Window, &mut App) -> Entity<V> + 'static, cx: &mut App) {
        cx.open_window(WindowOptions::default(), build)
            .expect("open the example window");
        cx.activate(true);
    }
}
