use std::time::Duration;
use gpui::{AppContext, Context, IntoElement, Render, Task, Window, div, prelude::*, rgb};

struct AsyncDemo {
    task: Option<Task<()>>,
    running: bool,
    message: String,
}

impl AsyncDemo {
    fn start(&mut self, cx: &mut Context<Self>) {
        self.task = None;
        self.running = true;
        self.message = "Waiting...".into();
        cx.notify();
        self.task = Some(cx.spawn(async move |this, cx| {
            cx.background_executor()
                .timer(Duration::from_secs(2))
                .await;
            let _ = this.update(cx, |this, cx| {
                this.running = false;
                this.task = None;
                this.message = "Complete".into();
                cx.notify();
            });
        }));
    }

    fn stop(&mut self, cx: &mut Context<Self>) {
        self.task = None;
        self.running = false;
        self.message = "Stopped".into();
        cx.notify();
    }
}

impl Render for AsyncDemo {
    fn render(&mut self, _window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        let action = if self.running { "Stop" } else { "Start" };
        div()
            .size_full().flex().flex_col().items_center().justify_center().gap_4()
            .bg(rgb(0xf7f6f2)).text_color(rgb(0x202b29))
            .child(div().text_2xl().child(self.message.clone()))
            .child(
                div().id("task-action").px_4().py_2().rounded_md()
                    .bg(rgb(0x155b50)).text_color(rgb(0xffffff)).cursor_pointer()
                    .child(action)
                    .on_click(cx.listener(|this, _, _, cx| {
                        if this.running { this.stop(cx); } else { this.start(cx); }
                    })),
            )
    }
}

pub fn main() {
    support::run(|_window, cx| {
        cx.new(|_cx| AsyncDemo { task: None, running: false, message: "Ready".into() })
    });
}

mod support {
    //! Platform setup shared by the walkthroughs; each downloaded main.rs includes it.
    use gpui::{App, Entity, Render, Window, WindowOptions};

    pub fn run<V: Render>(build: impl FnOnce(&mut Window, &mut App) -> Entity<V> + 'static) {
        #[cfg(not(target_family = "wasm"))]
        gpui_platform::application().run(move |cx| {
            cx.on_window_closed(|cx, _| {
                if cx.windows().is_empty() {
                    cx.quit();
                }
            }).detach();
            open(build, cx);
        });

        #[cfg(target_family = "wasm")]
        {
            use std::{cell::RefCell, rc::Rc, sync::Arc};
            use gpui::{Application, ApplicationHandle};
            thread_local! {
                static APPLICATION: RefCell<Option<ApplicationHandle>> = const { RefCell::new(None) };
            }
            gpui_web::init_logging();
            let platform = Rc::new(gpui_web::WebPlatform::new(false));
            let client = Arc::new(platform.fetch_http_client());
            let handle = Application::with_platform(platform).with_http_client(client)
                .run_embedded(move |cx| {
                    use std::borrow::Cow;
                    cx.text_system().add_fonts(vec![Cow::Borrowed(
                        include_bytes!("../../../crates/gpui_test/assets/fonts/ibm-plex-sans/IBMPlexSans-Regular.ttf") as &[u8],
                    )]).expect("load the preview font");
                    open(build, cx);
                });
            APPLICATION.with(|slot| *slot.borrow_mut() = Some(handle));
            if let Some(window) = web_sys::window() {
                if let Ok(Some(parent)) = window.parent() {
                    let _ = parent.post_message(&wasm_bindgen::JsValue::from_str("gpui-preview-ready"), "*");
                }
            }
        }
    }

    fn open<V: Render>(build: impl FnOnce(&mut Window, &mut App) -> Entity<V> + 'static, cx: &mut App) {
        cx.open_window(WindowOptions::default(), build).expect("open the example window");
        cx.activate(true);
    }
}
