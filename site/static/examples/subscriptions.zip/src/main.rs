use gpui::{
    AppContext, Context, Entity, IntoElement, Render, Role, Subscription, Window, div, prelude::*,
    rgb, text,
};

struct Model {
    count: u32,
}

impl Model {
    fn increment(&mut self, cx: &mut Context<Self>) {
        self.count = self.count.saturating_add(1);
        cx.notify();
    }
}

struct CounterView {
    model: Entity<Model>,
    notifications: u32,
    _model_subscription: Subscription,
}

impl CounterView {
    fn new(model: Entity<Model>, cx: &mut Context<Self>) -> Self {
        let _model_subscription = cx.observe(&model, |view: &mut Self, _model, cx| {
            view.notifications = view.notifications.saturating_add(1);
            cx.notify();
        });
        Self {
            model,
            notifications: 0,
            _model_subscription,
        }
    }
}

impl Render for CounterView {
    fn render(&mut self, _window: &mut Window, cx: &mut Context<Self>) -> impl IntoElement {
        let count = self.model.read(cx).count;
        div()
            .size_full()
            .flex()
            .flex_col()
            .items_center()
            .justify_center()
            .gap_4()
            .bg(rgb(0xf7f6f2))
            .text_color(rgb(0x202b29))
            .child(div().text_2xl().child(text!(format!("Count: {count}"))))
            .child(text!(format!(
                "Notifications received: {}",
                self.notifications
            )))
            .child(
                div()
                    .id("increment-model")
                    .role(Role::Button)
                    .aria_label("Increment")
                    .tab_index(0)
                    .focus_visible(|style| style.ring_2().ring_color(rgb(0x3478c8)))
                    .px_4()
                    .py_2()
                    .rounded_md()
                    .bg(rgb(0x155b50))
                    .text_color(rgb(0xffffff))
                    .cursor_pointer()
                    .child("Increment")
                    .on_click(cx.listener(|this, _, _, cx| {
                        this.model.update(cx, |model, cx| model.increment(cx));
                    })),
            )
    }
}

fn component(_window: &mut Window, cx: &mut gpui::App) -> gpui::Entity<CounterView> {
    let model = cx.new(|_cx| Model { count: 0 });
    let model_for_view = model.clone();
    cx.new(|cx| CounterView::new(model_for_view, cx))
}

pub fn main() {
    support::run(component);
}

mod support {
    //! Platform setup shared by the walkthroughs; each downloaded main.rs includes it.
    use gpui::{App, Entity, Render, Window, WindowOptions};

    pub fn run<V: Render>(build: impl FnOnce(&mut Window, &mut App) -> Entity<V> + 'static) {
        #[cfg(not(target_family = "wasm"))]
        gpui_platform::application().run(move |cx| {
            cx.on_window_closed(|cx, _| {
                if cx.windows().is_empty() {
                    cx.quit();
                }
            })
            .detach();
            open(build, cx);
        });

        #[cfg(target_family = "wasm")]
        {
            use gpui::{Application, ApplicationHandle};
            use std::{cell::RefCell, rc::Rc, sync::Arc};
            thread_local! {
                static APPLICATION: RefCell<Option<ApplicationHandle>> = const { RefCell::new(None) };
            }
            gpui_web::init_logging();
            let platform = Rc::new(gpui_web::WebPlatform::new(false));
            let client = Arc::new(platform.fetch_http_client());
            let handle = Application::with_platform(platform)
                .with_http_client(client)
                .run_embedded(move |cx| {
                    use std::borrow::Cow;
                    cx.text_system()
                        .add_fonts(vec![Cow::Borrowed(include_bytes!(
                            "../../../assets/fonts/ibm-plex-sans/IBMPlexSans-Regular.ttf"
                        ) as &[u8])])
                        .expect("load the preview font");
                    open(build, cx);
                });
            APPLICATION.with(|slot| *slot.borrow_mut() = Some(handle));
            if let Some(window) = web_sys::window() {
                if let Ok(Some(parent)) = window.parent() {
                    let _ = parent
                        .post_message(&wasm_bindgen::JsValue::from_str("gpui-preview-ready"), "*");
                }
            }
        }
    }

    fn open<V: Render>(build: impl FnOnce(&mut Window, &mut App) -> Entity<V> + 'static, cx: &mut App) {
        cx.open_window(WindowOptions::default(), build)
            .expect("open the example window");
        cx.activate(true);
    }
}
