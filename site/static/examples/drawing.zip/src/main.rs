use gpui::{
    AppContext, Bounds, Context, IntoElement, Render, Window, canvas, fill, point, prelude::*, px,
    rgb, size,
};

struct PaintDemo;

impl Render for PaintDemo {
    fn render(&mut self, _window: &mut Window, _cx: &mut Context<Self>) -> impl IntoElement {
        canvas(
            |_bounds, _window, _cx| {},
            |bounds: Bounds<gpui::Pixels>, _state, window, _cx| {
                window.paint_quad(fill(bounds, rgb(0xf4f1ea)));
                let left = bounds.origin + point(px(10.), px(10.));
                let right_x = (bounds.origin.x + bounds.size.width - px(70.))
                    .max(left.x + px(70.));
                window.paint_quad(fill(
                    Bounds::new(left, size(px(60.), px(40.))),
                    rgb(0xe05a47),
                ));
                window.paint_quad(fill(
                    Bounds::new(point(right_x, left.y), size(px(60.), px(40.))),
                    rgb(0x3478c8),
                ));
            },
        )
        .size_full()
    }
}

pub fn main() {
    support::run(|_window, cx| cx.new(|_cx| PaintDemo));
}

mod support {
    //! Platform setup shared by the walkthroughs; each downloaded main.rs includes it.
    use gpui::{App, Entity, Render, Window, WindowOptions};

    pub fn run<V: Render>(build: impl FnOnce(&mut Window, &mut App) -> Entity<V> + 'static) {
        #[cfg(not(target_family = "wasm"))]
        gpui_platform::application().run(move |cx| {
            cx.on_window_closed(|cx, _| {
                if cx.windows().is_empty() {
                    cx.quit();
                }
            }).detach();
            open(build, cx);
        });

        #[cfg(target_family = "wasm")]
        {
            use std::{cell::RefCell, rc::Rc, sync::Arc};
            use gpui::{Application, ApplicationHandle};
            thread_local! {
                static APPLICATION: RefCell<Option<ApplicationHandle>> = const { RefCell::new(None) };
            }
            gpui_web::init_logging();
            let platform = Rc::new(gpui_web::WebPlatform::new(false));
            let client = Arc::new(platform.fetch_http_client());
            let handle = Application::with_platform(platform).with_http_client(client)
                .run_embedded(move |cx| {
                    use std::borrow::Cow;
                    cx.text_system().add_fonts(vec![Cow::Borrowed(
                        include_bytes!("../../../crates/gpui_test/assets/fonts/ibm-plex-sans/IBMPlexSans-Regular.ttf") as &[u8],
                    )]).expect("load the preview font");
                    open(build, cx);
                });
            APPLICATION.with(|slot| *slot.borrow_mut() = Some(handle));
            if let Some(window) = web_sys::window() {
                if let Ok(Some(parent)) = window.parent() {
                    let _ = parent.post_message(&wasm_bindgen::JsValue::from_str("gpui-preview-ready"), "*");
                }
            }
        }
    }

    fn open<V: Render>(build: impl FnOnce(&mut Window, &mut App) -> Entity<V> + 'static, cx: &mut App) {
        cx.open_window(WindowOptions::default(), build).expect("open the example window");
        cx.activate(true);
    }
}
