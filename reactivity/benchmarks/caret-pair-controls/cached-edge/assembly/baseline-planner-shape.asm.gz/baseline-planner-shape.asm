
/tmp/gpui-caret-pair-controls-v3/baseline:     file format elf64-x86-64


Disassembly of section .text:

00000000006700a0 <<gpui_canvas::text::planner::Planner>::shape>:
  6700a0:	55                   	push   %rbp
  6700a1:	41 57                	push   %r15
  6700a3:	41 56                	push   %r14
  6700a5:	41 55                	push   %r13
  6700a7:	41 54                	push   %r12
  6700a9:	53                   	push   %rbx
  6700aa:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  6700b1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  6700b8:	00 
  6700b9:	48 81 ec 18 02 00 00 	sub    $0x218,%rsp
  6700c0:	44 89 8c 24 2c 02 00 	mov    %r9d,0x22c(%rsp)
  6700c7:	00 
  6700c8:	f3 0f 11 8c 24 d4 01 	movss  %xmm1,0x1d4(%rsp)
  6700cf:	00 00 
  6700d1:	44 89 84 24 d0 01 00 	mov    %r8d,0x1d0(%rsp)
  6700d8:	00 
  6700d9:	f3 0f 11 84 24 8c 00 	movss  %xmm0,0x8c(%rsp)
  6700e0:	00 00 
  6700e2:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6700e7:	48 89 bc 24 78 03 00 	mov    %rdi,0x378(%rsp)
  6700ee:	00 
  6700ef:	4c 8d 24 0a          	lea    (%rdx,%rcx,1),%r12
  6700f3:	48 85 c9             	test   %rcx,%rcx
  6700f6:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  6700fb:	4c 89 a4 24 b8 01 00 	mov    %r12,0x1b8(%rsp)
  670102:	00 
  670103:	48 89 94 24 48 01 00 	mov    %rdx,0x148(%rsp)
  67010a:	00 
  67010b:	0f 84 94 03 00 00    	je     6704a5 <<gpui_canvas::text::planner::Planner>::shape+0x405>
  670111:	48 8d 86 78 0a 00 00 	lea    0xa78(%rsi),%rax
  670118:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  67011d:	48 8d bc 24 1c 0d 00 	lea    0xd1c(%rsp),%rdi
  670124:	00 
  670125:	48 8d 46 38          	lea    0x38(%rsi),%rax
  670129:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  67012e:	48 8d 46 3c          	lea    0x3c(%rsi),%rax
  670132:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  670137:	48 8d 46 58          	lea    0x58(%rsi),%rax
  67013b:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  670142:	00 
  670143:	48 8d 46 5c          	lea    0x5c(%rsi),%rax
  670147:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  67014c:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
  670153:	00 
  670154:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
  67015b:	00 
  67015c:	4c 8b 05 f5 67 11 00 	mov    0x1167f5(%rip),%r8        # 786958 <_DYNAMIC+0x430>
  670163:	49 89 d6             	mov    %rdx,%r14
  670166:	eb 21                	jmp    670189 <<gpui_canvas::text::planner::Planner>::shape+0xe9>
  670168:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  67016f:	00 
  670170:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  670177:	83 f8 02             	cmp    $0x2,%eax
  67017a:	0f 83 e1 00 00 00    	jae    670261 <<gpui_canvas::text::planner::Planner>::shape+0x1c1>
  670180:	4d 39 e6             	cmp    %r12,%r14
  670183:	0f 84 bd 02 00 00    	je     670446 <<gpui_canvas::text::planner::Planner>::shape+0x3a6>
  670189:	45 0f b6 3e          	movzbl (%r14),%r15d
  67018d:	45 84 ff             	test   %r15b,%r15b
  670190:	78 1e                	js     6701b0 <<gpui_canvas::text::planner::Planner>::shape+0x110>
  670192:	49 ff c6             	inc    %r14
  670195:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67019c:	0f 8e 9e 00 00 00    	jle    670240 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  6701a2:	eb cc                	jmp    670170 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  6701a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6701ab:	00 00 00 00 00 
  6701b0:	44 89 f8             	mov    %r15d,%eax
  6701b3:	83 e0 1f             	and    $0x1f,%eax
  6701b6:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  6701bb:	83 e2 3f             	and    $0x3f,%edx
  6701be:	41 80 ff df          	cmp    $0xdf,%r15b
  6701c2:	76 3d                	jbe    670201 <<gpui_canvas::text::planner::Planner>::shape+0x161>
  6701c4:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  6701c9:	c1 e2 06             	shl    $0x6,%edx
  6701cc:	83 e1 3f             	and    $0x3f,%ecx
  6701cf:	09 d1                	or     %edx,%ecx
  6701d1:	41 80 ff f0          	cmp    $0xf0,%r15b
  6701d5:	72 44                	jb     67021b <<gpui_canvas::text::planner::Planner>::shape+0x17b>
  6701d7:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  6701dc:	49 83 c6 04          	add    $0x4,%r14
  6701e0:	83 e0 07             	and    $0x7,%eax
  6701e3:	c1 e0 12             	shl    $0x12,%eax
  6701e6:	c1 e1 06             	shl    $0x6,%ecx
  6701e9:	41 83 e7 3f          	and    $0x3f,%r15d
  6701ed:	41 09 cf             	or     %ecx,%r15d
  6701f0:	41 09 c7             	or     %eax,%r15d
  6701f3:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  6701fa:	7e 44                	jle    670240 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  6701fc:	e9 6f ff ff ff       	jmp    670170 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  670201:	49 83 c6 02          	add    $0x2,%r14
  670205:	c1 e0 06             	shl    $0x6,%eax
  670208:	09 d0                	or     %edx,%eax
  67020a:	41 89 c7             	mov    %eax,%r15d
  67020d:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  670214:	7e 2a                	jle    670240 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  670216:	e9 55 ff ff ff       	jmp    670170 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  67021b:	49 83 c6 03          	add    $0x3,%r14
  67021f:	c1 e0 0c             	shl    $0xc,%eax
  670222:	09 c1                	or     %eax,%ecx
  670224:	41 89 cf             	mov    %ecx,%r15d
  670227:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67022e:	0f 8f 3c ff ff ff    	jg     670170 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  670234:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  67023b:	00 00 00 00 00 
  670240:	41 83 ff 0a          	cmp    $0xa,%r15d
  670244:	0f 84 36 ff ff ff    	je     670180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67024a:	41 83 ff 0d          	cmp    $0xd,%r15d
  67024e:	0f 84 2c ff ff ff    	je     670180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  670254:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  67025b:	0f 84 1f ff ff ff    	je     670180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  670261:	48 89 fd             	mov    %rdi,%rbp
  670264:	48 8d 3d 6d bf 10 00 	lea    0x10bf6d(%rip),%rdi        # 77c1d8 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x170>
  67026b:	49 89 f5             	mov    %rsi,%r13
  67026e:	44 89 fe             	mov    %r15d,%esi
  670271:	4c 89 c3             	mov    %r8,%rbx
  670274:	ff 15 fe 68 11 00    	call   *0x1168fe(%rip)        # 786b78 <_DYNAMIC+0x650>
  67027a:	49 89 d8             	mov    %rbx,%r8
  67027d:	4c 89 ee             	mov    %r13,%rsi
  670280:	48 89 ef             	mov    %rbp,%rdi
  670283:	84 c0                	test   %al,%al
  670285:	0f 85 f5 fe ff ff    	jne    670180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67028b:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  670291:	41 83 ff 20          	cmp    $0x20,%r15d
  670295:	0f 82 5f 02 00 00    	jb     6704fa <<gpui_canvas::text::planner::Planner>::shape+0x45a>
  67029b:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  67029f:	83 f8 21             	cmp    $0x21,%eax
  6702a2:	0f 82 52 02 00 00    	jb     6704fa <<gpui_canvas::text::planner::Planner>::shape+0x45a>
  6702a8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6702ad:	44 89 fe             	mov    %r15d,%esi
  6702b0:	e8 6b 3d 00 00       	call   674020 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  6702b5:	49 89 d8             	mov    %rbx,%r8
  6702b8:	4c 89 ee             	mov    %r13,%rsi
  6702bb:	a8 01                	test   $0x1,%al
  6702bd:	4c 8b a4 24 b8 01 00 	mov    0x1b8(%rsp),%r12
  6702c4:	00 
  6702c5:	74 0c                	je     6702d3 <<gpui_canvas::text::planner::Planner>::shape+0x233>
  6702c7:	48 89 ef             	mov    %rbp,%rdi
  6702ca:	66 85 d2             	test   %dx,%dx
  6702cd:	0f 85 ad fe ff ff    	jne    670180 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  6702d3:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6702d8:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  6702df:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  6702e5:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  6702e9:	0f 85 0b 02 00 00    	jne    6704fa <<gpui_canvas::text::planner::Planner>::shape+0x45a>
  6702ef:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  6702f4:	0f 85 eb 00 00 00    	jne    6703e5 <<gpui_canvas::text::planner::Planner>::shape+0x345>
  6702fa:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  6702ff:	48 89 f7             	mov    %rsi,%rdi
  670302:	48 8d 35 03 56 9b ff 	lea    -0x64a9fd(%rip),%rsi        # 2590c <gpui_canvas::text::ARABIC_BYTES>
  670309:	31 c9                	xor    %ecx,%ecx
  67030b:	41 ff d0             	call   *%r8
  67030e:	83 bc 24 40 07 00 00 	cmpl   $0xffffffff,0x740(%rsp)
  670315:	ff 
  670316:	0f 84 ef 30 00 00    	je     67340b <<gpui_canvas::text::planner::Planner>::shape+0x336b>
  67031c:	8b 84 24 18 0d 00 00 	mov    0xd18(%rsp),%eax
  670323:	89 44 24 30          	mov    %eax,0x30(%rsp)
  670327:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
  67032b:	0f 10 4d 0c          	movups 0xc(%rbp),%xmm1
  67032f:	0f 29 84 24 f0 04 00 	movaps %xmm0,0x4f0(%rsp)
  670336:	00 
  670337:	0f 11 8c 24 fc 04 00 	movups %xmm1,0x4fc(%rsp)
  67033e:	00 
  67033f:	ba 14 69 00 00       	mov    $0x6914,%edx
  670344:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  67034b:	00 
  67034c:	48 8d 35 01 01 9f ff 	lea    -0x60feff(%rip),%rsi        # 60454 <gpui_canvas::text::HEBREW_BYTES>
  670353:	31 c9                	xor    %ecx,%ecx
  670355:	ff 15 fd 65 11 00    	call   *0x1165fd(%rip)        # 786958 <_DYNAMIC+0x430>
  67035b:	83 bc 24 40 07 00 00 	cmpl   $0xffffffff,0x740(%rsp)
  670362:	ff 
  670363:	0f 84 b4 30 00 00    	je     67341d <<gpui_canvas::text::planner::Planner>::shape+0x337d>
  670369:	8b 94 24 18 0d 00 00 	mov    0xd18(%rsp),%edx
  670370:	48 8d 84 24 1c 0d 00 	lea    0xd1c(%rsp),%rax
  670377:	00 
  670378:	0f 10 00             	movups (%rax),%xmm0
  67037b:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  67037f:	0f 29 84 24 60 04 00 	movaps %xmm0,0x460(%rsp)
  670386:	00 
  670387:	0f 11 8c 24 6c 04 00 	movups %xmm1,0x46c(%rsp)
  67038e:	00 
  67038f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  670394:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  67039b:	00 
  67039c:	8b 4c 24 30          	mov    0x30(%rsp),%ecx
  6703a0:	89 48 38             	mov    %ecx,0x38(%rax)
  6703a3:	0f 10 84 24 fc 04 00 	movups 0x4fc(%rsp),%xmm0
  6703aa:	00 
  6703ab:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6703b0:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  6703b4:	0f 28 84 24 f0 04 00 	movaps 0x4f0(%rsp),%xmm0
  6703bb:	00 
  6703bc:	0f 11 01             	movups %xmm0,(%rcx)
  6703bf:	89 94 24 90 00 00 00 	mov    %edx,0x90(%rsp)
  6703c6:	89 50 58             	mov    %edx,0x58(%rax)
  6703c9:	0f 10 84 24 6c 04 00 	movups 0x46c(%rsp),%xmm0
  6703d0:	00 
  6703d1:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6703d6:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  6703da:	0f 28 84 24 60 04 00 	movaps 0x460(%rsp),%xmm0
  6703e1:	00 
  6703e2:	0f 11 00             	movups %xmm0,(%rax)
  6703e5:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6703ea:	44 89 fe             	mov    %r15d,%esi
  6703ed:	e8 2e 3c 00 00       	call   674020 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  6703f2:	66 85 d2             	test   %dx,%dx
  6703f5:	0f 95 c1             	setne  %cl
  6703f8:	20 c1                	and    %al,%cl
  6703fa:	88 4c 24 18          	mov    %cl,0x18(%rsp)
  6703fe:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
  670405:	00 
  670406:	44 89 fe             	mov    %r15d,%esi
  670409:	e8 12 3c 00 00       	call   674020 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  67040e:	66 85 d2             	test   %dx,%dx
  670411:	0f 95 c1             	setne  %cl
  670414:	20 c1                	and    %al,%cl
  670416:	00 c9                	add    %cl,%cl
  670418:	0a 4c 24 18          	or     0x18(%rsp),%cl
  67041c:	0f 84 d8 00 00 00    	je     6704fa <<gpui_canvas::text::planner::Planner>::shape+0x45a>
  670422:	8b 44 24 10          	mov    0x10(%rsp),%eax
  670426:	08 c8                	or     %cl,%al
  670428:	89 44 24 10          	mov    %eax,0x10(%rsp)
  67042c:	4c 8b a4 24 b8 01 00 	mov    0x1b8(%rsp),%r12
  670433:	00 
  670434:	4d 39 e6             	cmp    %r12,%r14
  670437:	48 89 ef             	mov    %rbp,%rdi
  67043a:	4c 89 ee             	mov    %r13,%rsi
  67043d:	49 89 d8             	mov    %rbx,%r8
  670440:	0f 85 43 fd ff ff    	jne    670189 <<gpui_canvas::text::planner::Planner>::shape+0xe9>
  670446:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
  67044a:	f6 c1 01             	test   $0x1,%cl
  67044d:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  670452:	0f 84 c8 00 00 00    	je     670520 <<gpui_canvas::text::planner::Planner>::shape+0x480>
  670458:	49 83 be 48 0a 00 00 	cmpq   $0x0,0xa48(%r14)
  67045f:	00 
  670460:	0f 85 ba 00 00 00    	jne    670520 <<gpui_canvas::text::planner::Planner>::shape+0x480>
  670466:	48 8d 35 23 93 11 00 	lea    0x119323(%rip),%rsi        # 789790 <gpui_canvas::text::ARABIC_FONT>
  67046d:	48 8d 15 98 54 9b ff 	lea    -0x64ab68(%rip),%rdx        # 2590c <gpui_canvas::text::ARABIC_BYTES>
  670474:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  67047b:	00 
  67047c:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  670481:	45 31 c0             	xor    %r8d,%r8d
  670484:	e8 17 35 ff ff       	call   6639a0 <<gpui_canvas::text::FontFace>::shared_static>
  670489:	83 bc 24 40 07 00 00 	cmpl   $0x1,0x740(%rsp)
  670490:	01 
  670491:	75 19                	jne    6704ac <<gpui_canvas::text::planner::Planner>::shape+0x40c>
  670493:	44 8b a4 24 44 07 00 	mov    0x744(%rsp),%r12d
  67049a:	00 
  67049b:	44 8b bc 24 48 07 00 	mov    0x748(%rsp),%r15d
  6704a2:	00 
  6704a3:	eb 55                	jmp    6704fa <<gpui_canvas::text::planner::Planner>::shape+0x45a>
  6704a5:	31 c9                	xor    %ecx,%ecx
  6704a7:	e9 87 00 00 00       	jmp    670533 <<gpui_canvas::text::planner::Planner>::shape+0x493>
  6704ac:	4d 8d be 48 0a 00 00 	lea    0xa48(%r14),%r15
  6704b3:	4c 8b a4 24 48 07 00 	mov    0x748(%rsp),%r12
  6704ba:	00 
  6704bb:	49 8b 07             	mov    (%r15),%rax
  6704be:	48 85 c0             	test   %rax,%rax
  6704c1:	74 0f                	je     6704d2 <<gpui_canvas::text::planner::Planner>::shape+0x432>
  6704c3:	f0 48 ff 08          	lock decq (%rax)
  6704c7:	75 09                	jne    6704d2 <<gpui_canvas::text::planner::Planner>::shape+0x432>
  6704c9:	4c 89 ff             	mov    %r15,%rdi
  6704cc:	ff 15 b6 62 11 00    	call   *0x1162b6(%rip)        # 786788 <_DYNAMIC+0x260>
  6704d2:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  6704d7:	4d 89 a6 48 0a 00 00 	mov    %r12,0xa48(%r14)
  6704de:	be 01 00 00 00       	mov    $0x1,%esi
  6704e3:	4c 89 f7             	mov    %r14,%rdi
  6704e6:	e8 35 38 00 00       	call   673d20 <<gpui_canvas::text::planner::Planner>::register>
  6704eb:	83 f8 ff             	cmp    $0xffffffff,%eax
  6704ee:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
  6704f2:	74 2c                	je     670520 <<gpui_canvas::text::planner::Planner>::shape+0x480>
  6704f4:	41 89 c4             	mov    %eax,%r12d
  6704f7:	45 31 ff             	xor    %r15d,%r15d
  6704fa:	44 89 a4 24 b8 00 00 	mov    %r12d,0xb8(%rsp)
  670501:	00 
  670502:	44 89 bc 24 bc 00 00 	mov    %r15d,0xbc(%rsp)
  670509:	00 
  67050a:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  670511:	00 ff ff ff ff 
  670516:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  67051b:	e9 b4 29 00 00       	jmp    672ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2e34>
  670520:	f6 c1 02             	test   $0x2,%cl
  670523:	74 0e                	je     670533 <<gpui_canvas::text::planner::Planner>::shape+0x493>
  670525:	49 83 be 50 0a 00 00 	cmpq   $0x0,0xa50(%r14)
  67052c:	00 
  67052d:	0f 84 3e 2b 00 00    	je     673071 <<gpui_canvas::text::planner::Planner>::shape+0x2fd1>
  670533:	48 c7 84 24 e0 02 00 	movq   $0xffffffffffffffff,0x2e0(%rsp)
  67053a:	00 ff ff ff ff 
  67053f:	48 8d 05 98 b0 be ff 	lea    -0x414f68(%rip),%rax        # 25b5de <anon.77df2256dbac5170b9422659b074405f.30.llvm.18408255876715279706+0xf6>
  670546:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  67054d:	00 
  67054e:	48 c7 84 24 f0 02 00 	movq   $0xc,0x2f0(%rsp)
  670555:	00 0c 00 00 00 
  67055a:	48 c7 84 24 f8 02 00 	movq   $0xffffffffffffffff,0x2f8(%rsp)
  670561:	00 ff ff ff ff 
  670566:	48 8d 05 7d b0 be ff 	lea    -0x414f83(%rip),%rax        # 25b5ea <anon.77df2256dbac5170b9422659b074405f.30.llvm.18408255876715279706+0x102>
  67056d:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  670574:	00 
  670575:	48 c7 84 24 08 03 00 	movq   $0x11,0x308(%rsp)
  67057c:	00 11 00 00 00 
  670581:	48 c7 84 24 10 03 00 	movq   $0xffffffffffffffff,0x310(%rsp)
  670588:	00 ff ff ff ff 
  67058d:	4c 8d 35 67 b0 be ff 	lea    -0x414f99(%rip),%r14        # 25b5fb <anon.77df2256dbac5170b9422659b074405f.30.llvm.18408255876715279706+0x113>
  670594:	4c 89 b4 24 18 03 00 	mov    %r14,0x318(%rsp)
  67059b:	00 
  67059c:	48 c7 84 24 20 03 00 	movq   $0x11,0x320(%rsp)
  6705a3:	00 11 00 00 00 
  6705a8:	f6 c1 01             	test   $0x1,%cl
  6705ab:	75 1c                	jne    6705c9 <<gpui_canvas::text::planner::Planner>::shape+0x529>
  6705ad:	4c 8d bc 24 f8 02 00 	lea    0x2f8(%rsp),%r15
  6705b4:	00 
  6705b5:	b8 01 00 00 00       	mov    $0x1,%eax
  6705ba:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6705c1:	00 
  6705c2:	f6 c1 02             	test   $0x2,%cl
  6705c5:	75 24                	jne    6705eb <<gpui_canvas::text::planner::Planner>::shape+0x54b>
  6705c7:	eb 5a                	jmp    670623 <<gpui_canvas::text::planner::Planner>::shape+0x583>
  6705c9:	4c 8d bc 24 10 03 00 	lea    0x310(%rsp),%r15
  6705d0:	00 
  6705d1:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  6705d8:	00 
  6705d9:	b8 02 00 00 00       	mov    $0x2,%eax
  6705de:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  6705e5:	00 
  6705e6:	f6 c1 02             	test   $0x2,%cl
  6705e9:	74 38                	je     670623 <<gpui_canvas::text::planner::Planner>::shape+0x583>
  6705eb:	49 8b 37             	mov    (%r15),%rsi
  6705ee:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  6705f2:	77 14                	ja     670608 <<gpui_canvas::text::planner::Planner>::shape+0x568>
  6705f4:	48 85 f6             	test   %rsi,%rsi
  6705f7:	74 0f                	je     670608 <<gpui_canvas::text::planner::Planner>::shape+0x568>
  6705f9:	49 8b 7f 08          	mov    0x8(%r15),%rdi
  6705fd:	ba 01 00 00 00       	mov    $0x1,%edx
  670602:	ff 15 58 61 11 00    	call   *0x116158(%rip)        # 786760 <_DYNAMIC+0x238>
  670608:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  67060f:	4d 89 77 08          	mov    %r14,0x8(%r15)
  670613:	49 c7 47 10 11 00 00 	movq   $0x11,0x10(%r15)
  67061a:	00 
  67061b:	48 ff 84 24 10 02 00 	incq   0x210(%rsp)
  670622:	00 
  670623:	48 c7 84 24 20 01 00 	movq   $0x0,0x120(%rsp)
  67062a:	00 00 00 00 00 
  67062f:	48 c7 84 24 28 01 00 	movq   $0x4,0x128(%rsp)
  670636:	00 04 00 00 00 
  67063b:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
  670642:	00 00 00 00 00 
  670647:	48 c7 84 24 50 01 00 	movq   $0xffffffffffffffff,0x150(%rsp)
  67064e:	00 ff ff ff ff 
  670653:	f6 84 24 d0 01 00 00 	testb  $0x1,0x1d0(%rsp)
  67065a:	01 
  67065b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  670660:	75 11                	jne    670673 <<gpui_canvas::text::planner::Planner>::shape+0x5d3>
  670662:	f3 0f 10 05 f2 cf 9a 	movss  -0x65300e(%rip),%xmm0        # 1d65c <GCC_except_table0+0x98>
  670669:	ff 
  67066a:	f3 0f 11 84 24 d4 01 	movss  %xmm0,0x1d4(%rsp)
  670671:	00 00 
  670673:	48 8d 48 78          	lea    0x78(%rax),%rcx
  670677:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
  67067e:	00 
  67067f:	48 8d 88 38 06 00 00 	lea    0x638(%rax),%rcx
  670686:	48 89 8c 24 68 03 00 	mov    %rcx,0x368(%rsp)
  67068d:	00 
  67068e:	48 05 c8 08 00 00    	add    $0x8c8,%rax
  670694:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  670699:	4c 8d bc 24 70 04 00 	lea    0x470(%rsp),%r15
  6706a0:	00 
  6706a1:	0f 57 c0             	xorps  %xmm0,%xmm0
  6706a4:	0f 29 84 24 c0 02 00 	movaps %xmm0,0x2c0(%rsp)
  6706ab:	00 
  6706ac:	f3 0f 11 44 24 3c    	movss  %xmm0,0x3c(%rsp)
  6706b2:	f3 0f 11 84 24 84 00 	movss  %xmm0,0x84(%rsp)
  6706b9:	00 00 
  6706bb:	4c 8d a4 24 f8 04 00 	lea    0x4f8(%rsp),%r12
  6706c2:	00 
  6706c3:	48 8d 05 4e bc 10 00 	lea    0x10bc4e(%rip),%rax        # 77c318 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x2b0>
  6706ca:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  6706cf:	48 8d 05 aa be 10 00 	lea    0x10beaa(%rip),%rax        # 77c580 <anon.65c0d5535d99d532b50dfd321f8783c6.26.llvm.10908145274026468279>
  6706d6:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
  6706dd:	00 
  6706de:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  6706e5:	00 00 00 00 00 
  6706ea:	31 ed                	xor    %ebp,%ebp
  6706ec:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6706f3:	00 
  6706f4:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6706f9:	31 c0                	xor    %eax,%eax
  6706fb:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  670700:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  670705:	83 fe fe             	cmp    $0xfffffffe,%esi
  670708:	75 26                	jne    670730 <<gpui_canvas::text::planner::Planner>::shape+0x690>
  67070a:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  67070f:	4c 3b 8c 24 b8 01 00 	cmp    0x1b8(%rsp),%r9
  670716:	00 
  670717:	74 2b                	je     670744 <<gpui_canvas::text::planner::Planner>::shape+0x6a4>
  670719:	41 0f b6 09          	movzbl (%r9),%ecx
  67071d:	84 c9                	test   %cl,%cl
  67071f:	78 3e                	js     67075f <<gpui_canvas::text::planner::Planner>::shape+0x6bf>
  670721:	49 8d 51 01          	lea    0x1(%r9),%rdx
  670725:	e9 92 00 00 00       	jmp    6707bc <<gpui_canvas::text::planner::Planner>::shape+0x71c>
  67072a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  670730:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  670735:	89 f1                	mov    %esi,%ecx
  670737:	4c 8b 84 24 50 03 00 	mov    0x350(%rsp),%r8
  67073e:	00 
  67073f:	e9 81 00 00 00       	jmp    6707c5 <<gpui_canvas::text::planner::Planner>::shape+0x725>
  670744:	c7 84 24 88 00 00 00 	movl   $0xfffffffe,0x88(%rsp)
  67074b:	fe ff ff ff 
  67074f:	b1 01                	mov    $0x1,%cl
  670751:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
  670755:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  67075a:	e9 d7 01 00 00       	jmp    670936 <<gpui_canvas::text::planner::Planner>::shape+0x896>
  67075f:	49 89 c0             	mov    %rax,%r8
  670762:	89 c8                	mov    %ecx,%eax
  670764:	83 e0 1f             	and    $0x1f,%eax
  670767:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  67076c:	83 e7 3f             	and    $0x3f,%edi
  67076f:	80 f9 e0             	cmp    $0xe0,%cl
  670772:	72 2d                	jb     6707a1 <<gpui_canvas::text::planner::Planner>::shape+0x701>
  670774:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  670779:	c1 e7 06             	shl    $0x6,%edi
  67077c:	83 e6 3f             	and    $0x3f,%esi
  67077f:	09 fe                	or     %edi,%esi
  670781:	80 f9 f0             	cmp    $0xf0,%cl
  670784:	72 28                	jb     6707ae <<gpui_canvas::text::planner::Planner>::shape+0x70e>
  670786:	49 8d 51 04          	lea    0x4(%r9),%rdx
  67078a:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  67078f:	83 e0 07             	and    $0x7,%eax
  670792:	c1 e0 12             	shl    $0x12,%eax
  670795:	c1 e6 06             	shl    $0x6,%esi
  670798:	83 e1 3f             	and    $0x3f,%ecx
  67079b:	09 f1                	or     %esi,%ecx
  67079d:	09 c1                	or     %eax,%ecx
  67079f:	eb 18                	jmp    6707b9 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  6707a1:	49 8d 51 02          	lea    0x2(%r9),%rdx
  6707a5:	c1 e0 06             	shl    $0x6,%eax
  6707a8:	09 f8                	or     %edi,%eax
  6707aa:	89 c1                	mov    %eax,%ecx
  6707ac:	eb 0b                	jmp    6707b9 <<gpui_canvas::text::planner::Planner>::shape+0x719>
  6707ae:	49 8d 51 03          	lea    0x3(%r9),%rdx
  6707b2:	c1 e0 0c             	shl    $0xc,%eax
  6707b5:	09 c6                	or     %eax,%esi
  6707b7:	89 f1                	mov    %esi,%ecx
  6707b9:	4c 89 c0             	mov    %r8,%rax
  6707bc:	49 89 c0             	mov    %rax,%r8
  6707bf:	4c 29 c8             	sub    %r9,%rax
  6707c2:	48 01 d0             	add    %rdx,%rax
  6707c5:	c7 84 24 88 00 00 00 	movl   $0xfffffffe,0x88(%rsp)
  6707cc:	fe ff ff ff 
  6707d0:	40 b6 01             	mov    $0x1,%sil
  6707d3:	89 74 24 4c          	mov    %esi,0x4c(%rsp)
  6707d7:	83 f9 0c             	cmp    $0xc,%ecx
  6707da:	7e 24                	jle    670800 <<gpui_canvas::text::planner::Planner>::shape+0x760>
  6707dc:	83 f9 0d             	cmp    $0xd,%ecx
  6707df:	0f 84 5b 01 00 00    	je     670940 <<gpui_canvas::text::planner::Planner>::shape+0x8a0>
  6707e5:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  6707eb:	74 21                	je     67080e <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  6707ed:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  6707f3:	74 19                	je     67080e <<gpui_canvas::text::planner::Planner>::shape+0x76e>
  6707f5:	e9 83 00 00 00       	jmp    67087d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  6707fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  670800:	83 f9 ff             	cmp    $0xffffffff,%ecx
  670803:	0f 84 23 01 00 00    	je     67092c <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  670809:	83 f9 0a             	cmp    $0xa,%ecx
  67080c:	75 6f                	jne    67087d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  67080e:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  670813:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  670819:	0f 83 32 01 00 00    	jae    670951 <<gpui_canvas::text::planner::Planner>::shape+0x8b1>
  67081f:	49 8d 70 01          	lea    0x1(%r8),%rsi
  670823:	83 f9 0d             	cmp    $0xd,%ecx
  670826:	0f 85 37 01 00 00    	jne    670963 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  67082c:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  670831:	4c 3b 8c 24 b8 01 00 	cmp    0x1b8(%rsp),%r9
  670838:	00 
  670839:	0f 84 7a 24 00 00    	je     672cb9 <<gpui_canvas::text::planner::Planner>::shape+0x2c19>
  67083f:	45 0f b6 11          	movzbl (%r9),%r10d
  670843:	49 89 f3             	mov    %rsi,%r11
  670846:	45 84 d2             	test   %r10b,%r10b
  670849:	0f 88 7a 24 00 00    	js     672cc9 <<gpui_canvas::text::planner::Planner>::shape+0x2c29>
  67084f:	49 8d 59 01          	lea    0x1(%r9),%rbx
  670853:	e9 d0 24 00 00       	jmp    672d28 <<gpui_canvas::text::planner::Planner>::shape+0x2c88>
  670858:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  67085f:	00 
  670860:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  670866:	0f 84 d9 00 00 00    	je     670945 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67086c:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  670871:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  670877:	0f 84 c8 00 00 00    	je     670945 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67087d:	48 3b 94 24 b8 01 00 	cmp    0x1b8(%rsp),%rdx
  670884:	00 
  670885:	0f 84 a1 00 00 00    	je     67092c <<gpui_canvas::text::planner::Planner>::shape+0x88c>
  67088b:	49 89 c0             	mov    %rax,%r8
  67088e:	0f b6 0a             	movzbl (%rdx),%ecx
  670891:	84 c9                	test   %cl,%cl
  670893:	78 0b                	js     6708a0 <<gpui_canvas::text::planner::Planner>::shape+0x800>
  670895:	48 8d 42 01          	lea    0x1(%rdx),%rax
  670899:	eb 65                	jmp    670900 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  67089b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6708a0:	89 c8                	mov    %ecx,%eax
  6708a2:	83 e0 1f             	and    $0x1f,%eax
  6708a5:	0f b6 7a 01          	movzbl 0x1(%rdx),%edi
  6708a9:	83 e7 3f             	and    $0x3f,%edi
  6708ac:	80 f9 df             	cmp    $0xdf,%cl
  6708af:	76 2e                	jbe    6708df <<gpui_canvas::text::planner::Planner>::shape+0x83f>
  6708b1:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
  6708b5:	c1 e7 06             	shl    $0x6,%edi
  6708b8:	83 e6 3f             	and    $0x3f,%esi
  6708bb:	09 fe                	or     %edi,%esi
  6708bd:	80 f9 f0             	cmp    $0xf0,%cl
  6708c0:	72 2d                	jb     6708ef <<gpui_canvas::text::planner::Planner>::shape+0x84f>
  6708c2:	48 8d 7a 04          	lea    0x4(%rdx),%rdi
  6708c6:	0f b6 4a 03          	movzbl 0x3(%rdx),%ecx
  6708ca:	83 e0 07             	and    $0x7,%eax
  6708cd:	c1 e0 12             	shl    $0x12,%eax
  6708d0:	c1 e6 06             	shl    $0x6,%esi
  6708d3:	83 e1 3f             	and    $0x3f,%ecx
  6708d6:	09 f1                	or     %esi,%ecx
  6708d8:	09 c1                	or     %eax,%ecx
  6708da:	48 89 f8             	mov    %rdi,%rax
  6708dd:	eb 21                	jmp    670900 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  6708df:	48 8d 72 02          	lea    0x2(%rdx),%rsi
  6708e3:	c1 e0 06             	shl    $0x6,%eax
  6708e6:	09 f8                	or     %edi,%eax
  6708e8:	89 c1                	mov    %eax,%ecx
  6708ea:	48 89 f0             	mov    %rsi,%rax
  6708ed:	eb 11                	jmp    670900 <<gpui_canvas::text::planner::Planner>::shape+0x860>
  6708ef:	48 8d 4a 03          	lea    0x3(%rdx),%rcx
  6708f3:	c1 e0 0c             	shl    $0xc,%eax
  6708f6:	09 c6                	or     %eax,%esi
  6708f8:	48 89 c8             	mov    %rcx,%rax
  6708fb:	89 f1                	mov    %esi,%ecx
  6708fd:	0f 1f 00             	nopl   (%rax)
  670900:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  670905:	48 29 d0             	sub    %rdx,%rax
  670908:	4c 01 c0             	add    %r8,%rax
  67090b:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  670911:	0f 8f 49 ff ff ff    	jg     670860 <<gpui_canvas::text::planner::Planner>::shape+0x7c0>
  670917:	83 f9 0a             	cmp    $0xa,%ecx
  67091a:	74 29                	je     670945 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67091c:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  670921:	83 f9 0d             	cmp    $0xd,%ecx
  670924:	0f 85 53 ff ff ff    	jne    67087d <<gpui_canvas::text::planner::Planner>::shape+0x7dd>
  67092a:	eb 19                	jmp    670945 <<gpui_canvas::text::planner::Planner>::shape+0x8a5>
  67092c:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  670931:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  670936:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  67093b:	48 89 fe             	mov    %rdi,%rsi
  67093e:	eb 33                	jmp    670973 <<gpui_canvas::text::planner::Planner>::shape+0x8d3>
  670940:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  670945:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  67094b:	0f 82 ce fe ff ff    	jb     67081f <<gpui_canvas::text::planner::Planner>::shape+0x77f>
  670951:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  670957:	be 03 00 00 00       	mov    $0x3,%esi
  67095c:	48 83 de 00          	sbb    $0x0,%rsi
  670960:	4c 01 c6             	add    %r8,%rsi
  670963:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  67096a:	00 
  67096b:	4c 89 c1             	mov    %r8,%rcx
  67096e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  670973:	48 89 ca             	mov    %rcx,%rdx
  670976:	48 29 fa             	sub    %rdi,%rdx
  670979:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  670980:	00 
  670981:	0f 82 fc 2d 00 00    	jb     673783 <<gpui_canvas::text::planner::Planner>::shape+0x36e3>
  670987:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  67098d:	48 89 84 24 60 03 00 	mov    %rax,0x360(%rsp)
  670994:	00 
  670995:	74 2f                	je     6709c6 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  670997:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  67099c:	48 3b 54 24 58       	cmp    0x58(%rsp),%rdx
  6709a1:	73 1d                	jae    6709c0 <<gpui_canvas::text::planner::Planner>::shape+0x920>
  6709a3:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6709aa:	00 
  6709ab:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
  6709af:	7f 15                	jg     6709c6 <<gpui_canvas::text::planner::Planner>::shape+0x926>
  6709b1:	e9 cd 2d 00 00       	jmp    673783 <<gpui_canvas::text::planner::Planner>::shape+0x36e3>
  6709b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6709bd:	00 00 00 
  6709c0:	0f 85 bd 2d 00 00    	jne    673783 <<gpui_canvas::text::planner::Planner>::shape+0x36e3>
  6709c6:	48 85 c9             	test   %rcx,%rcx
  6709c9:	74 2b                	je     6709f6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  6709cb:	48 3b 4c 24 58       	cmp    0x58(%rsp),%rcx
  6709d0:	73 1e                	jae    6709f0 <<gpui_canvas::text::planner::Planner>::shape+0x950>
  6709d2:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6709d9:	00 
  6709da:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  6709de:	7d 16                	jge    6709f6 <<gpui_canvas::text::planner::Planner>::shape+0x956>
  6709e0:	e9 9e 2d 00 00       	jmp    673783 <<gpui_canvas::text::planner::Planner>::shape+0x36e3>
  6709e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6709ec:	00 00 00 00 
  6709f0:	0f 85 8d 2d 00 00    	jne    673783 <<gpui_canvas::text::planner::Planner>::shape+0x36e3>
  6709f6:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6709fb:	48 89 b4 24 58 03 00 	mov    %rsi,0x358(%rsp)
  670a02:	00 
  670a03:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  670a0a:	00 
  670a0b:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  670a10:	48 01 c1             	add    %rax,%rcx
  670a13:	48 8d bc 24 38 04 00 	lea    0x438(%rsp),%rdi
  670a1a:	00 
  670a1b:	48 8b b4 24 70 03 00 	mov    0x370(%rsp),%rsi
  670a22:	00 
  670a23:	48 8b 94 24 68 03 00 	mov    0x368(%rsp),%rdx
  670a2a:	00 
  670a2b:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  670a30:	4c 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%r8
  670a37:	00 
  670a38:	f3 0f 10 05 ac cb 9a 	movss  -0x653454(%rip),%xmm0        # 1d5ec <GCC_except_table0+0x28>
  670a3f:	ff 
  670a40:	45 31 c9             	xor    %r9d,%r9d
  670a43:	e8 98 34 ff ff       	call   663ee0 <<parley::context::LayoutContext<()>>::ranged_builder>
  670a48:	48 8d bc 24 38 04 00 	lea    0x438(%rsp),%rdi
  670a4f:	00 
  670a50:	48 8d b4 24 e0 02 00 	lea    0x2e0(%rsp),%rsi
  670a57:	00 
  670a58:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  670a5f:	00 
  670a60:	e8 db dc 00 00       	call   67e740 <<parley::builder::RangedBuilder<()>>::push_default::<&[parlance::font_family::FontFamilyName]>>
  670a65:	4c 8b b4 24 38 04 00 	mov    0x438(%rsp),%r14
  670a6c:	00 
  670a6d:	4c 8b ac 24 40 04 00 	mov    0x440(%rsp),%r13
  670a74:	00 
  670a75:	49 8d b6 30 02 00 00 	lea    0x230(%r14),%rsi
  670a7c:	c6 84 24 40 07 00 00 	movb   $0x1,0x740(%rsp)
  670a83:	01 
  670a84:	f3 0f 10 84 24 8c 00 	movss  0x8c(%rsp),%xmm0
  670a8b:	00 00 
  670a8d:	f3 0f 11 84 24 44 07 	movss  %xmm0,0x744(%rsp)
  670a94:	00 00 
  670a96:	f3 0f 10 84 24 58 04 	movss  0x458(%rsp),%xmm0
  670a9d:	00 00 
  670a9f:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
  670aa6:	00 
  670aa7:	48 89 f5             	mov    %rsi,%rbp
  670aaa:	4c 89 ea             	mov    %r13,%rdx
  670aad:	48 8d 9c 24 40 07 00 	lea    0x740(%rsp),%rbx
  670ab4:	00 
  670ab5:	48 89 d9             	mov    %rbx,%rcx
  670ab8:	f3 0f 11 44 24 18    	movss  %xmm0,0x18(%rsp)
  670abe:	e8 fd 51 ff ff       	call   665cc0 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  670ac3:	48 89 df             	mov    %rbx,%rdi
  670ac6:	e8 55 de 00 00       	call   67e920 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  670acb:	49 83 be 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r14)
  670ad2:	ff 
  670ad3:	0f 84 ea 28 00 00    	je     6733c3 <<gpui_canvas::text::planner::Planner>::shape+0x3323>
  670ad9:	49 8d 9e 98 04 00 00 	lea    0x498(%r14),%rbx
  670ae0:	48 89 df             	mov    %rbx,%rdi
  670ae3:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
  670aea:	00 
  670aeb:	e8 00 74 ff ff       	call   667ef0 <<parley::resolve::ResolvedStyle<()>>::apply>
  670af0:	66 c7 84 24 40 07 00 	movw   $0x117,0x740(%rsp)
  670af7:	00 17 01 
  670afa:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
  670b01:	00 
  670b02:	48 89 ee             	mov    %rbp,%rsi
  670b05:	4c 89 ea             	mov    %r13,%rdx
  670b08:	4c 8d ac 24 40 07 00 	lea    0x740(%rsp),%r13
  670b0f:	00 
  670b10:	4c 89 e9             	mov    %r13,%rcx
  670b13:	f3 0f 10 44 24 18    	movss  0x18(%rsp),%xmm0
  670b19:	e8 a2 51 ff ff       	call   665cc0 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  670b1e:	4c 89 ef             	mov    %r13,%rdi
  670b21:	e8 fa dd 00 00       	call   67e920 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  670b26:	49 83 be 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r14)
  670b2d:	ff 
  670b2e:	0f 84 8f 28 00 00    	je     6733c3 <<gpui_canvas::text::planner::Planner>::shape+0x3323>
  670b34:	48 89 df             	mov    %rbx,%rdi
  670b37:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
  670b3e:	00 
  670b3f:	e8 ac 73 ff ff       	call   667ef0 <<parley::resolve::ResolvedStyle<()>>::apply>
  670b44:	48 8d bc 24 38 04 00 	lea    0x438(%rsp),%rdi
  670b4b:	00 
  670b4c:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  670b51:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  670b56:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  670b5d:	00 
  670b5e:	e8 7d a5 00 00       	call   67b0e0 <<parley::builder::RangedBuilder<()>>::build_into::<&str>>
  670b63:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  670b6a:	00 
  670b6b:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  670b70:	e8 4b 3c 01 00       	call   6847c0 <<parley::layout::line_break::BreakLines<()>>::new>
  670b75:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  670b7c:	00 
  670b7d:	f3 0f 10 84 24 d4 01 	movss  0x1d4(%rsp),%xmm0
  670b84:	00 00 
  670b86:	e8 15 2d 01 00       	call   6838a0 <<parley::layout::line_break::BreakLines<()>>::break_remaining>
  670b8b:	80 bc 24 2c 02 00 00 	cmpb   $0x0,0x22c(%rsp)
  670b92:	00 
  670b93:	74 1b                	je     670bb0 <<gpui_canvas::text::planner::Planner>::shape+0xb10>
  670b95:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  670b9c:	00 ff 
  670b9e:	0f 85 0f 02 00 00    	jne    670db3 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  670ba4:	31 c0                	xor    %eax,%eax
  670ba6:	e9 8b 01 00 00       	jmp    670d36 <<gpui_canvas::text::planner::Planner>::shape+0xc96>
  670bab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  670bb0:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  670bb6:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  670bbb:	0f 85 5f 01 00 00    	jne    670d20 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  670bc1:	48 3b 44 24 58       	cmp    0x58(%rsp),%rax
  670bc6:	0f 85 54 01 00 00    	jne    670d20 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  670bcc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  670bd1:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  670bd8:	01 
  670bd9:	0f 85 41 01 00 00    	jne    670d20 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  670bdf:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  670be4:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  670beb:	48 8d 48 70          	lea    0x70(%rax),%rcx
  670bef:	48 89 8c 24 48 07 00 	mov    %rcx,0x748(%rsp)
  670bf6:	00 
  670bf7:	48 c7 84 24 50 07 00 	movq   $0x0,0x750(%rsp)
  670bfe:	00 00 00 00 00 
  670c03:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  670c08:	48 89 b4 24 58 07 00 	mov    %rsi,0x758(%rsp)
  670c0f:	00 
  670c10:	48 c7 84 24 88 07 00 	movq   $0x0,0x788(%rsp)
  670c17:	00 00 00 00 00 
  670c1c:	48 89 94 24 f0 04 00 	mov    %rdx,0x4f0(%rsp)
  670c23:	00 
  670c24:	48 c7 84 24 60 07 00 	movq   $0x0,0x760(%rsp)
  670c2b:	00 00 00 00 00 
  670c30:	48 89 8c 24 40 07 00 	mov    %rcx,0x740(%rsp)
  670c37:	00 
  670c38:	48 8b 78 10          	mov    0x10(%rax),%rdi
  670c3c:	48 8b 70 18          	mov    0x18(%rax),%rsi
  670c40:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  670c47:	48 39 fe             	cmp    %rdi,%rsi
  670c4a:	0f 82 fd 2a 00 00    	jb     67374d <<gpui_canvas::text::planner::Planner>::shape+0x36ad>
  670c50:	48 39 d6             	cmp    %rdx,%rsi
  670c53:	0f 87 f4 2a 00 00    	ja     67374d <<gpui_canvas::text::planner::Planner>::shape+0x36ad>
  670c59:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  670c5e:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  670c65:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  670c69:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  670c6d:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  670c71:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  670c75:	48 89 8c 24 60 07 00 	mov    %rcx,0x760(%rsp)
  670c7c:	00 
  670c7d:	48 89 84 24 68 07 00 	mov    %rax,0x768(%rsp)
  670c84:	00 
  670c85:	48 c7 84 24 70 07 00 	movq   $0x0,0x770(%rsp)
  670c8c:	00 00 00 00 00 
  670c91:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  670c96:	48 89 84 24 78 07 00 	mov    %rax,0x778(%rsp)
  670c9d:	00 
  670c9e:	c7 84 24 80 07 00 00 	movl   $0x0,0x780(%rsp)
  670ca5:	00 00 00 00 
  670ca9:	48 8d bc 24 60 07 00 	lea    0x760(%rsp),%rdi
  670cb0:	00 
  670cb1:	48 8d b4 24 88 07 00 	lea    0x788(%rsp),%rsi
  670cb8:	00 
  670cb9:	48 8d 94 24 f0 04 00 	lea    0x4f0(%rsp),%rdx
  670cc0:	00 
  670cc1:	e8 0a 5f ff ff       	call   666bd0 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  670cc6:	48 c7 84 24 50 07 00 	movq   $0x1,0x750(%rsp)
  670ccd:	00 01 00 00 00 
  670cd2:	84 c0                	test   %al,%al
  670cd4:	75 4a                	jne    670d20 <<gpui_canvas::text::planner::Planner>::shape+0xc80>
  670cd6:	48 c7 84 24 60 07 00 	movq   $0x0,0x760(%rsp)
  670cdd:	00 00 00 00 00 
  670ce2:	48 83 bc 24 88 07 00 	cmpq   $0x0,0x788(%rsp)
  670ce9:	00 00 
  670ceb:	0f 84 4c 1f 00 00    	je     672c3d <<gpui_canvas::text::planner::Planner>::shape+0x2b9d>
  670cf1:	48 8d bc 24 88 07 00 	lea    0x788(%rsp),%rdi
  670cf8:	00 
  670cf9:	48 8d b4 24 b0 07 00 	lea    0x7b0(%rsp),%rsi
  670d00:	00 
  670d01:	48 8d 94 24 f0 04 00 	lea    0x4f0(%rsp),%rdx
  670d08:	00 
  670d09:	e8 c2 5e ff ff       	call   666bd0 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  670d0e:	84 c0                	test   %al,%al
  670d10:	0f 84 27 1f 00 00    	je     672c3d <<gpui_canvas::text::planner::Planner>::shape+0x2b9d>
  670d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  670d1d:	00 00 00 
  670d20:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  670d27:	00 ff 
  670d29:	0f 85 84 00 00 00    	jne    670db3 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  670d2f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  670d36:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  670d3d:	00 00 00 00 00 
  670d42:	48 c7 84 24 58 01 00 	movq   $0x4,0x158(%rsp)
  670d49:	00 04 00 00 00 
  670d4e:	48 8d 8c 24 58 01 00 	lea    0x158(%rsp),%rcx
  670d55:	00 
  670d56:	0f 57 c0             	xorps  %xmm0,%xmm0
  670d59:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  670d5d:	48 c7 84 24 70 01 00 	movq   $0x4,0x170(%rsp)
  670d64:	00 04 00 00 00 
  670d69:	48 c7 84 24 78 01 00 	movq   $0x0,0x178(%rsp)
  670d70:	00 00 00 00 00 
  670d75:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  670d7c:	00 
  670d7d:	48 c7 84 24 88 01 00 	movq   $0x4,0x188(%rsp)
  670d84:	00 04 00 00 00 
  670d89:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
  670d90:	00 00 00 00 00 
  670d95:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  670d9a:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  670da1:	f3 0f 10 84 24 8c 00 	movss  0x8c(%rsp),%xmm0
  670da8:	00 00 
  670daa:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  670db1:	00 00 
  670db3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  670db8:	48 8b 98 e0 09 00 00 	mov    0x9e0(%rax),%rbx
  670dbf:	48 85 db             	test   %rbx,%rbx
  670dc2:	0f 84 08 01 00 00    	je     670ed0 <<gpui_canvas::text::planner::Planner>::shape+0xe30>
  670dc8:	48 8b a8 d8 09 00 00 	mov    0x9d8(%rax),%rbp
  670dcf:	45 31 f6             	xor    %r14d,%r14d
  670dd2:	45 31 ed             	xor    %r13d,%r13d
  670dd5:	eb 15                	jmp    670dec <<gpui_canvas::text::planner::Planner>::shape+0xd4c>
  670dd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  670dde:	00 00 
  670de0:	49 ff c6             	inc    %r14
  670de3:	49 39 de             	cmp    %rbx,%r14
  670de6:	0f 84 e7 00 00 00    	je     670ed3 <<gpui_canvas::text::planner::Planner>::shape+0xe33>
  670dec:	49 6b c6 70          	imul   $0x70,%r14,%rax
  670df0:	48 01 e8             	add    %rbp,%rax
  670df3:	4c 89 ac 24 40 07 00 	mov    %r13,0x740(%rsp)
  670dfa:	00 
  670dfb:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  670e02:	00 00 00 00 00 
  670e07:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  670e0c:	48 89 8c 24 50 07 00 	mov    %rcx,0x750(%rsp)
  670e13:	00 
  670e14:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  670e1b:	00 
  670e1c:	44 89 b4 24 60 07 00 	mov    %r14d,0x760(%rsp)
  670e23:	00 
  670e24:	c6 84 24 08 08 00 00 	movb   $0x2,0x808(%rsp)
  670e2b:	02 
  670e2c:	c7 84 24 10 08 00 00 	movl   $0x0,0x810(%rsp)
  670e33:	00 00 00 00 
  670e37:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  670e3e:	00 
  670e3f:	48 8d b4 24 48 07 00 	lea    0x748(%rsp),%rsi
  670e46:	00 
  670e47:	e8 d4 88 00 00       	call   679720 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  670e4c:	83 bc 24 60 04 00 00 	cmpl   $0x1,0x460(%rsp)
  670e53:	01 
  670e54:	75 8a                	jne    670de0 <<gpui_canvas::text::planner::Planner>::shape+0xd40>
  670e56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  670e5d:	00 00 00 
  670e60:	49 8b 47 38          	mov    0x38(%r15),%rax
  670e64:	49 89 44 24 40       	mov    %rax,0x40(%r12)
  670e69:	41 0f 10 47 f8       	movups -0x8(%r15),%xmm0
  670e6e:	41 0f 10 4f 08       	movups 0x8(%r15),%xmm1
  670e73:	41 0f 10 57 18       	movups 0x18(%r15),%xmm2
  670e78:	41 0f 10 5f 28       	movups 0x28(%r15),%xmm3
  670e7d:	41 0f 11 5c 24 30    	movups %xmm3,0x30(%r12)
  670e83:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
  670e89:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
  670e8f:	41 0f 11 04 24       	movups %xmm0,(%r12)
  670e94:	4c 89 ac 24 f0 04 00 	mov    %r13,0x4f0(%rsp)
  670e9b:	00 
  670e9c:	4c 89 ee             	mov    %r13,%rsi
  670e9f:	4c 89 e2             	mov    %r12,%rdx
  670ea2:	e8 29 77 ff ff       	call   6685d0 <<&mut core::iter::adapters::map::map_fold<parley::layout::line::PositionedLayoutItem<()>, usize, usize, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, parley::layout::line::GlyphRunIter<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#4}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(usize, parley::layout::line::PositionedLayoutItem<()>)>>::call_mut>
  670ea7:	49 89 c5             	mov    %rax,%r13
  670eaa:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  670eb1:	00 
  670eb2:	48 8d b4 24 48 07 00 	lea    0x748(%rsp),%rsi
  670eb9:	00 
  670eba:	e8 61 88 00 00       	call   679720 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  670ebf:	80 bc 24 60 04 00 00 	cmpb   $0x0,0x460(%rsp)
  670ec6:	00 
  670ec7:	75 97                	jne    670e60 <<gpui_canvas::text::planner::Planner>::shape+0xdc0>
  670ec9:	e9 12 ff ff ff       	jmp    670de0 <<gpui_canvas::text::planner::Planner>::shape+0xd40>
  670ece:	66 90                	xchg   %ax,%ax
  670ed0:	45 31 ed             	xor    %r13d,%r13d
  670ed3:	48 8b b4 24 30 01 00 	mov    0x130(%rsp),%rsi
  670eda:	00 
  670edb:	48 89 f0             	mov    %rsi,%rax
  670ede:	4c 01 e8             	add    %r13,%rax
  670ee1:	0f 92 c1             	setb   %cl
  670ee4:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  670eea:	0f 93 c0             	setae  %al
  670eed:	08 c8                	or     %cl,%al
  670eef:	0f 85 9c 1e 00 00    	jne    672d91 <<gpui_canvas::text::planner::Planner>::shape+0x2cf1>
  670ef5:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  670efa:	48 39 6c 24 50       	cmp    %rbp,0x50(%rsp)
  670eff:	74 14                	je     670f15 <<gpui_canvas::text::planner::Planner>::shape+0xe75>
  670f01:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  670f08:	00 
  670f09:	48 29 f0             	sub    %rsi,%rax
  670f0c:	49 39 c5             	cmp    %rax,%r13
  670f0f:	0f 87 5c 1e 00 00    	ja     672d71 <<gpui_canvas::text::planner::Planner>::shape+0x2cd1>
  670f15:	48 85 ed             	test   %rbp,%rbp
  670f18:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
  670f1d:	74 2b                	je     670f4a <<gpui_canvas::text::planner::Planner>::shape+0xeaa>
  670f1f:	0f 57 c0             	xorps  %xmm0,%xmm0
  670f22:	f3 0f 11 84 24 10 01 	movss  %xmm0,0x110(%rsp)
  670f29:	00 00 
  670f2b:	49 39 ee             	cmp    %rbp,%r14
  670f2e:	75 54                	jne    670f84 <<gpui_canvas::text::planner::Planner>::shape+0xee4>
  670f30:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  670f35:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  670f3c:	48 85 c0             	test   %rax,%rax
  670f3f:	0f 85 83 00 00 00    	jne    670fc8 <<gpui_canvas::text::planner::Planner>::shape+0xf28>
  670f45:	e9 ac 14 00 00       	jmp    6723f6 <<gpui_canvas::text::planner::Planner>::shape+0x2356>
  670f4a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  670f4f:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  670f56:	00 
  670f57:	74 0e                	je     670f67 <<gpui_canvas::text::planner::Planner>::shape+0xec7>
  670f59:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  670f60:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  670f65:	eb 03                	jmp    670f6a <<gpui_canvas::text::planner::Planner>::shape+0xeca>
  670f67:	0f 57 c0             	xorps  %xmm0,%xmm0
  670f6a:	f3 0f 11 84 24 84 00 	movss  %xmm0,0x84(%rsp)
  670f71:	00 00 
  670f73:	0f 57 c0             	xorps  %xmm0,%xmm0
  670f76:	f3 0f 11 84 24 10 01 	movss  %xmm0,0x110(%rsp)
  670f7d:	00 00 
  670f7f:	49 39 ee             	cmp    %rbp,%r14
  670f82:	74 ac                	je     670f30 <<gpui_canvas::text::planner::Planner>::shape+0xe90>
  670f84:	83 bc 24 d0 01 00 00 	cmpl   $0x0,0x1d0(%rsp)
  670f8b:	00 
  670f8c:	74 0f                	je     670f9d <<gpui_canvas::text::planner::Planner>::shape+0xefd>
  670f8e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  670f93:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  670f9a:	00 
  670f9b:	eb 0d                	jmp    670faa <<gpui_canvas::text::planner::Planner>::shape+0xf0a>
  670f9d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  670fa2:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  670fa9:	00 
  670faa:	f3 0f 11 84 24 10 01 	movss  %xmm0,0x110(%rsp)
  670fb1:	00 00 
  670fb3:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  670fb8:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  670fbf:	48 85 c0             	test   %rax,%rax
  670fc2:	0f 84 2e 14 00 00    	je     6723f6 <<gpui_canvas::text::planner::Planner>::shape+0x2356>
  670fc8:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  670fcf:	48 6b c0 70          	imul   $0x70,%rax,%rax
  670fd3:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
  670fda:	00 
  670fdb:	48 01 c8             	add    %rcx,%rax
  670fde:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  670fe5:	00 
  670fe6:	c7 84 24 80 00 00 00 	movl   $0x0,0x80(%rsp)
  670fed:	00 00 00 00 
  670ff1:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  670ff8:	00 ff 
  670ffa:	74 2e                	je     67102a <<gpui_canvas::text::planner::Planner>::shape+0xf8a>
  670ffc:	49 39 ee             	cmp    %rbp,%r14
  670fff:	75 3f                	jne    671040 <<gpui_canvas::text::planner::Planner>::shape+0xfa0>
  671001:	45 31 ed             	xor    %r13d,%r13d
  671004:	45 31 f6             	xor    %r14d,%r14d
  671007:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  67100e:	00 
  67100f:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  671016:	00 
  671017:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  67101e:	00 
  67101f:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  671023:	74 44                	je     671069 <<gpui_canvas::text::planner::Planner>::shape+0xfc9>
  671025:	e9 d2 01 00 00       	jmp    6711fc <<gpui_canvas::text::planner::Planner>::shape+0x115c>
  67102a:	8b 8c 24 80 00 00 00 	mov    0x80(%rsp),%ecx
  671031:	89 c8                	mov    %ecx,%eax
  671033:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
  67103a:	00 
  67103b:	e9 d5 03 00 00       	jmp    671415 <<gpui_canvas::text::planner::Planner>::shape+0x1375>
  671040:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  671047:	00 
  671048:	4c 8b 30             	mov    (%rax),%r14
  67104b:	4c 8b 68 08          	mov    0x8(%rax),%r13
  67104f:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
  671056:	00 
  671057:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  67105e:	00 
  67105f:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  671063:	0f 85 93 01 00 00    	jne    6711fc <<gpui_canvas::text::planner::Planner>::shape+0x115c>
  671069:	48 8b 78 10          	mov    0x10(%rax),%rdi
  67106d:	48 8b 70 18          	mov    0x18(%rax),%rsi
  671071:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  671076:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  67107d:	48 39 fe             	cmp    %rdi,%rsi
  671080:	0f 82 d9 26 00 00    	jb     67375f <<gpui_canvas::text::planner::Planner>::shape+0x36bf>
  671086:	48 39 d6             	cmp    %rdx,%rsi
  671089:	0f 87 d0 26 00 00    	ja     67375f <<gpui_canvas::text::planner::Planner>::shape+0x36bf>
  67108f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  671094:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  67109b:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  67109f:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  6710a3:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  6710a7:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  6710ab:	48 89 8c 24 f0 04 00 	mov    %rcx,0x4f0(%rsp)
  6710b2:	00 
  6710b3:	48 89 84 24 f8 04 00 	mov    %rax,0x4f8(%rsp)
  6710ba:	00 
  6710bb:	48 c7 84 24 00 05 00 	movq   $0x0,0x500(%rsp)
  6710c2:	00 00 00 00 00 
  6710c7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6710cc:	48 89 84 24 08 05 00 	mov    %rax,0x508(%rsp)
  6710d3:	00 
  6710d4:	8b 84 24 80 00 00 00 	mov    0x80(%rsp),%eax
  6710db:	89 84 24 10 05 00 00 	mov    %eax,0x510(%rsp)
  6710e2:	c6 84 24 30 07 00 00 	movb   $0x2,0x730(%rsp)
  6710e9:	02 
  6710ea:	48 8d 84 24 38 07 00 	lea    0x738(%rsp),%rax
  6710f1:	00 
  6710f2:	48 89 84 24 60 04 00 	mov    %rax,0x460(%rsp)
  6710f9:	00 
  6710fa:	c6 84 24 20 06 00 00 	movb   $0x2,0x620(%rsp)
  671101:	02 
  671102:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  671109:	00 
  67110a:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
  671111:	00 
  671112:	48 8d 94 24 60 04 00 	lea    0x460(%rsp),%rdx
  671119:	00 
  67111a:	48 8d 8c 24 18 05 00 	lea    0x518(%rsp),%rcx
  671121:	00 
  671122:	e8 a9 53 ff ff       	call   6664d0 <<core::iter::adapters::map::Map<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, core::iter::traits::iterator::Iterator::find::check<parley::layout::cluster::Cluster<()>, &mut gpui_canvas::text::planner::freeze_line::{closure#1}>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>>>
  671127:	48 8b 8c 24 40 07 00 	mov    0x740(%rsp),%rcx
  67112e:	00 
  67112f:	48 85 c9             	test   %rcx,%rcx
  671132:	0f 84 b2 00 00 00    	je     6711ea <<gpui_canvas::text::planner::Planner>::shape+0x114a>
  671138:	8b bc 24 68 07 00 00 	mov    0x768(%rsp),%edi
  67113f:	8b b4 24 c0 07 00 00 	mov    0x7c0(%rsp),%esi
  671146:	8b 94 24 c4 07 00 00 	mov    0x7c4(%rsp),%edx
  67114d:	48 8b 41 58          	mov    0x58(%rcx),%rax
  671151:	48 39 f8             	cmp    %rdi,%rax
  671154:	0f 86 15 27 00 00    	jbe    67386f <<gpui_canvas::text::planner::Planner>::shape+0x37cf>
  67115a:	48 8b 41 50          	mov    0x50(%rcx),%rax
  67115e:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  671162:	48 c1 e7 04          	shl    $0x4,%rdi
  671166:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  67116a:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  671171:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  671178:	0f 11 84 24 40 07 00 	movups %xmm0,0x740(%rsp)
  67117f:	00 
  671180:	0f 11 8c 24 50 07 00 	movups %xmm1,0x750(%rsp)
  671187:	00 
  671188:	0f 11 94 24 60 07 00 	movups %xmm2,0x760(%rsp)
  67118f:	00 
  671190:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  671195:	48 89 84 24 70 07 00 	mov    %rax,0x770(%rsp)
  67119c:	00 
  67119d:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  6711a4:	00 
  6711a5:	ff 15 25 59 11 00    	call   *0x115925(%rip)        # 786ad0 <_DYNAMIC+0x5a8>
  6711ab:	48 89 c3             	mov    %rax,%rbx
  6711ae:	ba 48 02 00 00       	mov    $0x248,%edx
  6711b3:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
  6711b8:	4c 8d b4 24 40 07 00 	lea    0x740(%rsp),%r14
  6711bf:	00 
  6711c0:	4c 89 f7             	mov    %r14,%rdi
  6711c3:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
  6711ca:	00 
  6711cb:	ff 15 27 56 11 00    	call   *0x115627(%rip)        # 7867f8 <memcpy@GLIBC_2.14>
  6711d1:	4c 89 f7             	mov    %r14,%rdi
  6711d4:	4c 8b 74 24 18       	mov    0x18(%rsp),%r14
  6711d9:	48 89 de             	mov    %rbx,%rsi
  6711dc:	e8 8f 55 ff ff       	call   666770 <<core::iter::adapters::map::Map<core::iter::adapters::filter::Filter<core::iter::adapters::flatten::FlatMap<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, parley::layout::run::Clusters<()>, gpui_canvas::text::planner::freeze_line::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#1}>, gpui_canvas::text::planner::freeze_line::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::traits::iterator::Iterator::min_by::fold<usize, <usize as core::cmp::Ord>::cmp>::{closure#0}>>
  6711e1:	4c 39 e8             	cmp    %r13,%rax
  6711e4:	4c 0f 42 e8          	cmovb  %rax,%r13
  6711e8:	eb 12                	jmp    6711fc <<gpui_canvas::text::planner::Planner>::shape+0x115c>
  6711ea:	80 bc 24 30 07 00 00 	cmpb   $0x2,0x730(%rsp)
  6711f1:	02 
  6711f2:	c6 84 24 20 06 00 00 	movb   $0x2,0x620(%rsp)
  6711f9:	02 
  6711fa:	75 44                	jne    671240 <<gpui_canvas::text::planner::Planner>::shape+0x11a0>
  6711fc:	4d 39 ee             	cmp    %r13,%r14
  6711ff:	0f 87 ab 1f 00 00    	ja     6731b0 <<gpui_canvas::text::planner::Planner>::shape+0x3110>
  671205:	4d 85 f6             	test   %r14,%r14
  671208:	0f 84 ae 00 00 00    	je     6712bc <<gpui_canvas::text::planner::Planner>::shape+0x121c>
  67120e:	4c 3b b4 24 a0 00 00 	cmp    0xa0(%rsp),%r14
  671215:	00 
  671216:	0f 83 9a 00 00 00    	jae    6712b6 <<gpui_canvas::text::planner::Planner>::shape+0x1216>
  67121c:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  671221:	42 80 3c 30 bf       	cmpb   $0xbf,(%rax,%r14,1)
  671226:	0f 8f 90 00 00 00    	jg     6712bc <<gpui_canvas::text::planner::Planner>::shape+0x121c>
  67122c:	e9 7f 1f 00 00       	jmp    6731b0 <<gpui_canvas::text::planner::Planner>::shape+0x3110>
  671231:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  671238:	0f 1f 84 00 00 00 00 
  67123f:	00 
  671240:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  671247:	00 
  671248:	48 8d b4 24 28 06 00 	lea    0x628(%rsp),%rsi
  67124f:	00 
  671250:	e8 eb 77 ff ff       	call   668a40 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  671255:	48 8b 8c 24 40 07 00 	mov    0x740(%rsp),%rcx
  67125c:	00 
  67125d:	48 85 c9             	test   %rcx,%rcx
  671260:	74 9a                	je     6711fc <<gpui_canvas::text::planner::Planner>::shape+0x115c>
  671262:	8b bc 24 68 07 00 00 	mov    0x768(%rsp),%edi
  671269:	48 8b 41 58          	mov    0x58(%rcx),%rax
  67126d:	48 39 f8             	cmp    %rdi,%rax
  671270:	0f 86 76 25 00 00    	jbe    6737ec <<gpui_canvas::text::planner::Planner>::shape+0x374c>
  671276:	8b b4 24 c0 07 00 00 	mov    0x7c0(%rsp),%esi
  67127d:	8b 94 24 c4 07 00 00 	mov    0x7c4(%rsp),%edx
  671284:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  671288:	39 f2                	cmp    %esi,%edx
  67128a:	0f 82 52 24 00 00    	jb     6736e2 <<gpui_canvas::text::planner::Planner>::shape+0x3642>
  671290:	49 39 d0             	cmp    %rdx,%r8
  671293:	0f 82 49 24 00 00    	jb     6736e2 <<gpui_canvas::text::planner::Planner>::shape+0x3642>
  671299:	39 f2                	cmp    %esi,%edx
  67129b:	0f 84 5c 25 00 00    	je     6737fd <<gpui_canvas::text::planner::Planner>::shape+0x375d>
  6712a1:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  6712a5:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  6712a9:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  6712af:	75 8f                	jne    671240 <<gpui_canvas::text::planner::Planner>::shape+0x11a0>
  6712b1:	e9 9b fe ff ff       	jmp    671151 <<gpui_canvas::text::planner::Planner>::shape+0x10b1>
  6712b6:	0f 85 f4 1e 00 00    	jne    6731b0 <<gpui_canvas::text::planner::Planner>::shape+0x3110>
  6712bc:	4d 85 ed             	test   %r13,%r13
  6712bf:	74 21                	je     6712e2 <<gpui_canvas::text::planner::Planner>::shape+0x1242>
  6712c1:	4c 3b ac 24 a0 00 00 	cmp    0xa0(%rsp),%r13
  6712c8:	00 
  6712c9:	73 11                	jae    6712dc <<gpui_canvas::text::planner::Planner>::shape+0x123c>
  6712cb:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6712d0:	42 80 3c 28 c0       	cmpb   $0xc0,(%rax,%r13,1)
  6712d5:	7d 0b                	jge    6712e2 <<gpui_canvas::text::planner::Planner>::shape+0x1242>
  6712d7:	e9 d4 1e 00 00       	jmp    6731b0 <<gpui_canvas::text::planner::Planner>::shape+0x3110>
  6712dc:	0f 85 ce 1e 00 00    	jne    6731b0 <<gpui_canvas::text::planner::Planner>::shape+0x3110>
  6712e2:	0f 57 c0             	xorps  %xmm0,%xmm0
  6712e5:	48 39 6c 24 50       	cmp    %rbp,0x50(%rsp)
  6712ea:	74 0d                	je     6712f9 <<gpui_canvas::text::planner::Planner>::shape+0x1259>
  6712ec:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  6712f3:	00 
  6712f4:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  6712f9:	f3 0f 11 44 24 18    	movss  %xmm0,0x18(%rsp)
  6712ff:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  671306:	00 
  671307:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  67130c:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  671311:	0f 29 8c 24 d0 02 00 	movaps %xmm1,0x2d0(%rsp)
  671318:	00 
  671319:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  67131e:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  671325:	00 
  671326:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
  67132d:	00 
  67132e:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  671333:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  67133a:	00 
  67133b:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  671340:	f3 0f 58 44 24 3c    	addss  0x3c(%rsp),%xmm0
  671346:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  67134c:	48 8b 9c 24 78 01 00 	mov    0x178(%rsp),%rbx
  671353:	00 
  671354:	48 3b 9c 24 68 01 00 	cmp    0x168(%rsp),%rbx
  67135b:	00 
  67135c:	75 0e                	jne    67136c <<gpui_canvas::text::planner::Planner>::shape+0x12cc>
  67135e:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  671365:	00 
  671366:	ff 15 14 58 11 00    	call   *0x115814(%rip)        # 786b80 <_DYNAMIC+0x658>
  67136c:	41 01 ee             	add    %ebp,%r14d
  67136f:	41 01 ed             	add    %ebp,%r13d
  671372:	0f 28 94 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm2
  671379:	00 
  67137a:	0f 28 c2             	movaps %xmm2,%xmm0
  67137d:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  671382:	0f 28 c8             	movaps %xmm0,%xmm1
  671385:	0f 55 ca             	andnps %xmm2,%xmm1
  671388:	0f 54 84 24 d0 02 00 	andps  0x2d0(%rsp),%xmm0
  67138f:	00 
  671390:	0f 56 c1             	orps   %xmm1,%xmm0
  671393:	f3 0f 10 4c 24 3c    	movss  0x3c(%rsp),%xmm1
  671399:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  67139d:	0f 28 a4 24 f0 00 00 	movaps 0xf0(%rsp),%xmm4
  6713a4:	00 
  6713a5:	0f 28 d4             	movaps %xmm4,%xmm2
  6713a8:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  6713ad:	0f 28 da             	movaps %xmm2,%xmm3
  6713b0:	0f 55 dc             	andnps %xmm4,%xmm3
  6713b3:	0f 54 94 24 90 00 00 	andps  0x90(%rsp),%xmm2
  6713ba:	00 
  6713bb:	0f 56 d3             	orps   %xmm3,%xmm2
  6713be:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  6713c2:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6713c9:	00 
  6713ca:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  6713ce:	44 89 34 c8          	mov    %r14d,(%rax,%rcx,8)
  6713d2:	44 89 6c c8 04       	mov    %r13d,0x4(%rax,%rcx,8)
  6713d7:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  6713dd:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  6713e3:	f3 0f 10 44 24 30    	movss  0x30(%rsp),%xmm0
  6713e9:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  6713ef:	f3 0f 10 44 24 18    	movss  0x18(%rsp),%xmm0
  6713f5:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  6713fb:	48 ff c3             	inc    %rbx
  6713fe:	48 89 9c 24 78 01 00 	mov    %rbx,0x178(%rsp)
  671405:	00 
  671406:	44 89 ac 24 18 02 00 	mov    %r13d,0x218(%rsp)
  67140d:	00 
  67140e:	8b 8c 24 80 00 00 00 	mov    0x80(%rsp),%ecx
  671415:	48 c7 84 24 40 07 00 	movq   $0x0,0x740(%rsp)
  67141c:	00 00 00 00 00 
  671421:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  671426:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  67142d:	00 
  67142e:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  671435:	00 
  671436:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  67143d:	00 
  67143e:	48 83 c0 70          	add    $0x70,%rax
  671442:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  671449:	00 
  67144a:	89 8c 24 58 07 00 00 	mov    %ecx,0x758(%rsp)
  671451:	ff c1                	inc    %ecx
  671453:	89 8c 24 80 00 00 00 	mov    %ecx,0x80(%rsp)
  67145a:	c6 84 24 00 08 00 00 	movb   $0x2,0x800(%rsp)
  671461:	02 
  671462:	c7 84 24 08 08 00 00 	movl   $0x0,0x808(%rsp)
  671469:	00 00 00 00 
  67146d:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  671474:	00 
  671475:	48 8d b4 24 40 07 00 	lea    0x740(%rsp),%rsi
  67147c:	00 
  67147d:	e8 9e 82 00 00       	call   679720 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  671482:	83 bc 24 60 04 00 00 	cmpl   $0x1,0x460(%rsp)
  671489:	01 
  67148a:	0f 85 46 0f 00 00    	jne    6723d6 <<gpui_canvas::text::planner::Planner>::shape+0x2336>
  671490:	48 8b 84 24 68 04 00 	mov    0x468(%rsp),%rax
  671497:	00 
  671498:	48 85 c0             	test   %rax,%rax
  67149b:	0f 84 ff 1c 00 00    	je     6731a0 <<gpui_canvas::text::planner::Planner>::shape+0x3100>
  6714a1:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
  6714a8:	00 
  6714a9:	41 0f 10 07          	movups (%r15),%xmm0
  6714ad:	41 0f 10 4f 10       	movups 0x10(%r15),%xmm1
  6714b2:	41 0f 10 57 20       	movups 0x20(%r15),%xmm2
  6714b7:	41 0f 10 5f 30       	movups 0x30(%r15),%xmm3
  6714bc:	48 8d 8c 24 80 02 00 	lea    0x280(%rsp),%rcx
  6714c3:	00 
  6714c4:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  6714c8:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  6714cc:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  6714d0:	0f 11 01             	movups %xmm0,(%rcx)
  6714d3:	4c 8b 9c 24 80 02 00 	mov    0x280(%rsp),%r11
  6714da:	00 
  6714db:	49 8b 4b 30          	mov    0x30(%r11),%rcx
  6714df:	49 8b 73 38          	mov    0x38(%r11),%rsi
  6714e3:	48 89 f2             	mov    %rsi,%rdx
  6714e6:	48 29 ca             	sub    %rcx,%rdx
  6714e9:	40 0f 92 c7          	setb   %dil
  6714ed:	48 3b b0 d0 00 00 00 	cmp    0xd0(%rax),%rsi
  6714f4:	40 0f 97 c6          	seta   %sil
  6714f8:	48 01 c9             	add    %rcx,%rcx
  6714fb:	48 03 88 c8 00 00 00 	add    0xc8(%rax),%rcx
  671502:	40 08 fe             	or     %dil,%sil
  671505:	40 84 f6             	test   %sil,%sil
  671508:	be 00 00 00 00       	mov    $0x0,%esi
  67150d:	48 0f 45 d6          	cmovne %rsi,%rdx
  671511:	be 02 00 00 00       	mov    $0x2,%esi
  671516:	48 0f 45 ce          	cmovne %rsi,%rcx
  67151a:	48 01 d2             	add    %rdx,%rdx
  67151d:	31 f6                	xor    %esi,%esi
  67151f:	90                   	nop
  671520:	48 39 f2             	cmp    %rsi,%rdx
  671523:	74 10                	je     671535 <<gpui_canvas::text::planner::Planner>::shape+0x1495>
  671525:	66 83 3c 31 00       	cmpw   $0x0,(%rcx,%rsi,1)
  67152a:	48 8d 76 02          	lea    0x2(%rsi),%rsi
  67152e:	74 f0                	je     671520 <<gpui_canvas::text::planner::Planner>::shape+0x1480>
  671530:	e9 69 18 00 00       	jmp    672d9e <<gpui_canvas::text::planner::Planner>::shape+0x2cfe>
  671535:	49 8b 4b 40          	mov    0x40(%r11),%rcx
  671539:	48 3b 88 b8 00 00 00 	cmp    0xb8(%rax),%rcx
  671540:	0f 83 2b 22 00 00    	jae    673771 <<gpui_canvas::text::planner::Planner>::shape+0x36d1>
  671546:	48 c1 e1 06          	shl    $0x6,%rcx
  67154a:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  671551:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  671556:	83 3e 01             	cmpl   $0x1,(%rsi)
  671559:	75 0f                	jne    67156a <<gpui_canvas::text::planner::Planner>::shape+0x14ca>
  67155b:	48 8b 56 08          	mov    0x8(%rsi),%rdx
  67155f:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  671563:	75 05                	jne    67156a <<gpui_canvas::text::planner::Planner>::shape+0x14ca>
  671565:	45 31 c0             	xor    %r8d,%r8d
  671568:	eb 4c                	jmp    6715b6 <<gpui_canvas::text::planner::Planner>::shape+0x1516>
  67156a:	83 7e 10 01          	cmpl   $0x1,0x10(%rsi)
  67156e:	75 10                	jne    671580 <<gpui_canvas::text::planner::Planner>::shape+0x14e0>
  671570:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  671574:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  67157a:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  67157e:	74 1e                	je     67159e <<gpui_canvas::text::planner::Planner>::shape+0x14fe>
  671580:	83 7e 20 01          	cmpl   $0x1,0x20(%rsi)
  671584:	0f 85 44 1c 00 00    	jne    6731ce <<gpui_canvas::text::planner::Planner>::shape+0x312e>
  67158a:	48 8b 56 28          	mov    0x28(%rsi),%rdx
  67158e:	41 b8 02 00 00 00    	mov    $0x2,%r8d
  671594:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  671598:	0f 85 30 1c 00 00    	jne    6731ce <<gpui_canvas::text::planner::Planner>::shape+0x312e>
  67159e:	41 8d 48 ff          	lea    -0x1(%r8),%ecx
  6715a2:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
  6715a9:	00 
  6715aa:	48 0f ab ca          	bts    %rcx,%rdx
  6715ae:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  6715b5:	00 
  6715b6:	8b bc 24 a0 02 00 00 	mov    0x2a0(%rsp),%edi
  6715bd:	48 8b 70 58          	mov    0x58(%rax),%rsi
  6715c1:	48 39 fe             	cmp    %rdi,%rsi
  6715c4:	0f 86 5a 22 00 00    	jbe    673824 <<gpui_canvas::text::planner::Planner>::shape+0x3784>
  6715ca:	48 8b 94 24 90 02 00 	mov    0x290(%rsp),%rdx
  6715d1:	00 
  6715d2:	48 85 d2             	test   %rdx,%rdx
  6715d5:	4c 89 84 24 58 02 00 	mov    %r8,0x258(%rsp)
  6715dc:	00 
  6715dd:	48 89 94 24 28 03 00 	mov    %rdx,0x328(%rsp)
  6715e4:	00 
  6715e5:	74 0a                	je     6715f1 <<gpui_canvas::text::planner::Planner>::shape+0x1551>
  6715e7:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  6715eb:	48 83 c2 1c          	add    $0x1c,%rdx
  6715ef:	eb 1b                	jmp    67160c <<gpui_canvas::text::planner::Planner>::shape+0x156c>
  6715f1:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6715f5:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  6715f9:	48 c1 e6 04          	shl    $0x4,%rsi
  6715fd:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
  671601:	48 83 c2 54          	add    $0x54,%rdx
  671605:	48 01 f1             	add    %rsi,%rcx
  671608:	48 83 c1 50          	add    $0x50,%rcx
  67160c:	48 8b b4 24 30 01 00 	mov    0x130(%rsp),%rsi
  671613:	00 
  671614:	48 89 b4 24 30 03 00 	mov    %rsi,0x330(%rsp)
  67161b:	00 
  67161c:	48 8b 70 68          	mov    0x68(%rax),%rsi
  671620:	48 8b 78 70          	mov    0x70(%rax),%rdi
  671624:	4c 8b 80 80 00 00 00 	mov    0x80(%rax),%r8
  67162b:	4c 8b 88 88 00 00 00 	mov    0x88(%rax),%r9
  671632:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  671639:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  671640:	8b 12                	mov    (%rdx),%edx
  671642:	8b 09                	mov    (%rcx),%ecx
  671644:	4c 89 9c 24 40 02 00 	mov    %r11,0x240(%rsp)
  67164b:	00 
  67164c:	45 0f b6 9b 8c 00 00 	movzbl 0x8c(%r11),%r11d
  671653:	00 
  671654:	41 80 e3 01          	and    $0x1,%r11b
  671658:	89 d3                	mov    %edx,%ebx
  67165a:	29 cb                	sub    %ecx,%ebx
  67165c:	48 c7 84 24 f0 04 00 	movq   $0x0,0x4f0(%rsp)
  671663:	00 00 00 00 00 
  671668:	48 c7 84 24 10 05 00 	movq   $0x0,0x510(%rsp)
  67166f:	00 00 00 00 00 
  671674:	c7 84 24 30 05 00 00 	movl   $0x0,0x530(%rsp)
  67167b:	00 00 00 00 
  67167f:	89 9c 24 34 05 00 00 	mov    %ebx,0x534(%rsp)
  671686:	48 89 b4 24 38 05 00 	mov    %rsi,0x538(%rsp)
  67168d:	00 
  67168e:	48 89 bc 24 40 05 00 	mov    %rdi,0x540(%rsp)
  671695:	00 
  671696:	4c 89 84 24 48 05 00 	mov    %r8,0x548(%rsp)
  67169d:	00 
  67169e:	4c 89 8c 24 50 05 00 	mov    %r9,0x550(%rsp)
  6716a5:	00 
  6716a6:	4c 89 94 24 58 05 00 	mov    %r10,0x558(%rsp)
  6716ad:	00 
  6716ae:	48 89 84 24 60 05 00 	mov    %rax,0x560(%rsp)
  6716b5:	00 
  6716b6:	89 8c 24 68 05 00 00 	mov    %ecx,0x568(%rsp)
  6716bd:	89 94 24 6c 05 00 00 	mov    %edx,0x56c(%rsp)
  6716c4:	89 8c 24 70 05 00 00 	mov    %ecx,0x570(%rsp)
  6716cb:	89 94 24 74 05 00 00 	mov    %edx,0x574(%rsp)
  6716d2:	44 88 9c 24 78 05 00 	mov    %r11b,0x578(%rsp)
  6716d9:	00 
  6716da:	f2 0f 10 84 24 b0 02 	movsd  0x2b0(%rsp),%xmm0
  6716e1:	00 00 
  6716e3:	0f 29 84 24 80 03 00 	movaps %xmm0,0x380(%rsp)
  6716ea:	00 
  6716eb:	8b 94 24 a8 02 00 00 	mov    0x2a8(%rsp),%edx
  6716f2:	8b 8c 24 ac 02 00 00 	mov    0x2ac(%rsp),%ecx
  6716f9:	48 8d bc 24 98 03 00 	lea    0x398(%rsp),%rdi
  671700:	00 
  671701:	48 8d b4 24 78 02 00 	lea    0x278(%rsp),%rsi
  671708:	00 
  671709:	e8 72 66 ff ff       	call   667d80 <<parley::layout::run::Run<()>>::glyphs_in>
  67170e:	0f 28 94 24 80 03 00 	movaps 0x380(%rsp),%xmm2
  671715:	00 
  671716:	0f 13 94 24 30 04 00 	movlps %xmm2,0x430(%rsp)
  67171d:	00 
  67171e:	4c 8b ac 24 98 03 00 	mov    0x398(%rsp),%r13
  671725:	00 
  671726:	48 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%rax
  67172d:	00 
  67172e:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  671735:	00 
  671736:	0f b6 84 24 a8 03 00 	movzbl 0x3a8(%rsp),%eax
  67173d:	00 
  67173e:	8b 8c 24 ac 03 00 00 	mov    0x3ac(%rsp),%ecx
  671745:	89 8c 24 c4 01 00 00 	mov    %ecx,0x1c4(%rsp)
  67174c:	f2 0f 10 84 24 b0 03 	movsd  0x3b0(%rsp),%xmm0
  671753:	00 00 
  671755:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  67175c:	00 
  67175d:	f3 0f 10 84 24 b8 03 	movss  0x3b8(%rsp),%xmm0
  671764:	00 00 
  671766:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  67176d:	00 00 
  67176f:	48 8b 8c 24 c0 03 00 	mov    0x3c0(%rsp),%rcx
  671776:	00 
  671777:	48 89 8c 24 60 02 00 	mov    %rcx,0x260(%rsp)
  67177e:	00 
  67177f:	48 8b 8c 24 c8 03 00 	mov    0x3c8(%rsp),%rcx
  671786:	00 
  671787:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  67178e:	00 
  67178f:	48 8b 94 24 d0 03 00 	mov    0x3d0(%rsp),%rdx
  671796:	00 
  671797:	48 8b 9c 24 d8 03 00 	mov    0x3d8(%rsp),%rbx
  67179e:	00 
  67179f:	48 8b 8c 24 e0 03 00 	mov    0x3e0(%rsp),%rcx
  6717a6:	00 
  6717a7:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
  6717ae:	00 
  6717af:	48 8b 8c 24 e8 03 00 	mov    0x3e8(%rsp),%rcx
  6717b6:	00 
  6717b7:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  6717be:	00 
  6717bf:	8b 8c 24 f0 03 00 00 	mov    0x3f0(%rsp),%ecx
  6717c6:	48 89 8c 24 e0 01 00 	mov    %rcx,0x1e0(%rsp)
  6717cd:	00 
  6717ce:	8b 8c 24 f4 03 00 00 	mov    0x3f4(%rsp),%ecx
  6717d5:	48 89 8c 24 e8 01 00 	mov    %rcx,0x1e8(%rsp)
  6717dc:	00 
  6717dd:	8b 8c 24 f8 03 00 00 	mov    0x3f8(%rsp),%ecx
  6717e4:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  6717eb:	00 
  6717ec:	44 8b b4 24 fc 03 00 	mov    0x3fc(%rsp),%r14d
  6717f3:	00 
  6717f4:	f3 0f 10 84 24 00 04 	movss  0x400(%rsp),%xmm0
  6717fb:	00 00 
  6717fd:	f3 0f 11 84 24 c8 01 	movss  %xmm0,0x1c8(%rsp)
  671804:	00 00 
  671806:	f3 0f 10 84 24 04 04 	movss  0x404(%rsp),%xmm0
  67180d:	00 00 
  67180f:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  671815:	48 8b 8c 24 08 04 00 	mov    0x408(%rsp),%rcx
  67181c:	00 
  67181d:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  671822:	f3 0f 10 84 24 20 04 	movss  0x420(%rsp),%xmm0
  671829:	00 00 
  67182b:	f3 0f 10 8c 24 1c 04 	movss  0x41c(%rsp),%xmm1
  671832:	00 00 
  671834:	f3 0f 11 84 24 28 02 	movss  %xmm0,0x228(%rsp)
  67183b:	00 00 
  67183d:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  671841:	f3 0f 10 84 24 24 04 	movss  0x424(%rsp),%xmm0
  671848:	00 00 
  67184a:	f3 0f 11 8c 24 24 02 	movss  %xmm1,0x224(%rsp)
  671851:	00 00 
  671853:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  671857:	f3 0f 11 84 24 1c 02 	movss  %xmm0,0x21c(%rsp)
  67185e:	00 00 
  671860:	0f 28 c2             	movaps %xmm2,%xmm0
  671863:	0f b6 8c 24 2c 04 00 	movzbl 0x42c(%rsp),%ecx
  67186a:	00 
  67186b:	88 8c 24 d0 02 00 00 	mov    %cl,0x2d0(%rsp)
  671872:	48 8b 8c 24 10 04 00 	mov    0x410(%rsp),%rcx
  671879:	00 
  67187a:	48 89 8c 24 38 01 00 	mov    %rcx,0x138(%rsp)
  671881:	00 
  671882:	8b 8c 24 18 04 00 00 	mov    0x418(%rsp),%ecx
  671889:	89 8c 24 18 01 00 00 	mov    %ecx,0x118(%rsp)
  671890:	8b 8c 24 28 04 00 00 	mov    0x428(%rsp),%ecx
  671897:	89 8c 24 20 02 00 00 	mov    %ecx,0x220(%rsp)
  67189e:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  6718a2:	48 89 8c 24 48 02 00 	mov    %rcx,0x248(%rsp)
  6718a9:	00 
  6718aa:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
  6718b1:	00 
  6718b2:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  6718b6:	48 89 8c 24 40 03 00 	mov    %rcx,0x340(%rsp)
  6718bd:	00 
  6718be:	48 89 9c 24 d8 01 00 	mov    %rbx,0x1d8(%rsp)
  6718c5:	00 
  6718c6:	eb 6e                	jmp    671936 <<gpui_canvas::text::planner::Planner>::shape+0x1896>
  6718c8:	03 6c 24 10          	add    0x10(%rsp),%ebp
  6718cc:	0f 28 8c 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm1
  6718d3:	00 
  6718d4:	f3 0f 58 4c 24 3c    	addss  0x3c(%rsp),%xmm1
  6718da:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  6718e1:	00 
  6718e2:	48 89 d9             	mov    %rbx,%rcx
  6718e5:	48 c1 e1 04          	shl    $0x4,%rcx
  6718e9:	89 2c 08             	mov    %ebp,(%rax,%rcx,1)
  6718ec:	f3 0f 10 44 24 2c    	movss  0x2c(%rsp),%xmm0
  6718f2:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  6718f8:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  6718fe:	8b 54 24 64          	mov    0x64(%rsp),%edx
  671902:	66 89 54 08 0c       	mov    %dx,0xc(%rax,%rcx,1)
  671907:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  67190e:	00 
  67190f:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  671913:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  671918:	48 ff c3             	inc    %rbx
  67191b:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
  671922:	00 
  671923:	31 c0                	xor    %eax,%eax
  671925:	48 8b 9c 24 d8 01 00 	mov    0x1d8(%rsp),%rbx
  67192c:	00 
  67192d:	f3 0f 10 84 24 cc 01 	movss  0x1cc(%rsp),%xmm0
  671934:	00 00 
  671936:	f3 0f 11 44 24 2c    	movss  %xmm0,0x2c(%rsp)
  67193c:	a8 01                	test   $0x1,%al
  67193e:	74 60                	je     6719a0 <<gpui_canvas::text::planner::Planner>::shape+0x1900>
  671940:	f3 0f 10 84 24 c0 01 	movss  0x1c0(%rsp),%xmm0
  671947:	00 00 
  671949:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  67194f:	8b 84 24 c4 01 00 00 	mov    0x1c4(%rsp),%eax
  671956:	89 44 24 64          	mov    %eax,0x64(%rsp)
  67195a:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  671961:	00 
  671962:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  671969:	00 
  67196a:	83 bc 24 18 01 00 00 	cmpl   $0x0,0x118(%rsp)
  671971:	00 
  671972:	74 74                	je     6719e8 <<gpui_canvas::text::planner::Planner>::shape+0x1948>
  671974:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  67197a:	74 7f                	je     6719fb <<gpui_canvas::text::planner::Planner>::shape+0x195b>
  67197c:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  671983:	00 
  671984:	f3 0f 11 84 24 14 01 	movss  %xmm0,0x114(%rsp)
  67198b:	00 00 
  67198d:	e9 97 00 00 00       	jmp    671a29 <<gpui_canvas::text::planner::Planner>::shape+0x1989>
  671992:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  671999:	1f 84 00 00 00 00 00 
  6719a0:	4c 3b ac 24 00 01 00 	cmp    0x100(%rsp),%r13
  6719a7:	00 
  6719a8:	0f 84 3e 01 00 00    	je     671aec <<gpui_canvas::text::planner::Planner>::shape+0x1a4c>
  6719ae:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6719b3:	41 8b 45 00          	mov    0x0(%r13),%eax
  6719b7:	89 44 24 64          	mov    %eax,0x64(%rsp)
  6719bb:	f2 41 0f 10 45 04    	movsd  0x4(%r13),%xmm0
  6719c1:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  6719c8:	00 
  6719c9:	f3 41 0f 10 45 0c    	movss  0xc(%r13),%xmm0
  6719cf:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  6719d5:	49 83 c5 10          	add    $0x10,%r13
  6719d9:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  6719de:	83 bc 24 18 01 00 00 	cmpl   $0x0,0x118(%rsp)
  6719e5:	00 
  6719e6:	75 8c                	jne    671974 <<gpui_canvas::text::planner::Planner>::shape+0x18d4>
  6719e8:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  6719ef:	00 
  6719f0:	f3 0f 11 84 24 14 01 	movss  %xmm0,0x114(%rsp)
  6719f7:	00 00 
  6719f9:	eb 5f                	jmp    671a5a <<gpui_canvas::text::planner::Planner>::shape+0x19ba>
  6719fb:	f3 0f 10 84 24 c8 01 	movss  0x1c8(%rsp),%xmm0
  671a02:	00 00 
  671a04:	0f 28 c8             	movaps %xmm0,%xmm1
  671a07:	f3 0f 58 8c 24 a0 01 	addss  0x1a0(%rsp),%xmm1
  671a0e:	00 00 
  671a10:	f3 0f 11 8c 24 14 01 	movss  %xmm1,0x114(%rsp)
  671a17:	00 00 
  671a19:	f3 0f 10 4c 24 30    	movss  0x30(%rsp),%xmm1
  671a1f:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  671a23:	f3 0f 11 4c 24 30    	movss  %xmm1,0x30(%rsp)
  671a29:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  671a2e:	48 ff c2             	inc    %rdx
  671a31:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  671a38:	00 
  671a39:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  671a3e:	48 39 c2             	cmp    %rax,%rdx
  671a41:	75 17                	jne    671a5a <<gpui_canvas::text::planner::Planner>::shape+0x19ba>
  671a43:	f3 0f 10 44 24 30    	movss  0x30(%rsp),%xmm0
  671a49:	f3 0f 58 44 24 60    	addss  0x60(%rsp),%xmm0
  671a4f:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  671a55:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  671a5a:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  671a61:	00 
  671a62:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
  671a69:	00 
  671a6a:	e8 21 28 00 00       	call   674290 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  671a6f:	83 bc 24 b0 00 00 00 	cmpl   $0x1,0xb0(%rsp)
  671a76:	01 
  671a77:	0f 85 12 17 00 00    	jne    67318f <<gpui_canvas::text::planner::Planner>::shape+0x30ef>
  671a7d:	f3 0f 10 44 24 2c    	movss  0x2c(%rsp),%xmm0
  671a83:	f3 0f 58 44 24 30    	addss  0x30(%rsp),%xmm0
  671a89:	31 c0                	xor    %eax,%eax
  671a8b:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  671a90:	48 39 4c 24 50       	cmp    %rcx,0x50(%rsp)
  671a95:	0f 84 9b fe ff ff    	je     671936 <<gpui_canvas::text::planner::Planner>::shape+0x1896>
  671a9b:	f3 0f 11 84 24 cc 01 	movss  %xmm0,0x1cc(%rsp)
  671aa2:	00 00 
  671aa4:	4c 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%r9
  671aab:	00 
  671aac:	48 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%rbp
  671ab3:	00 
  671ab4:	49 39 e9             	cmp    %rbp,%r9
  671ab7:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  671abe:	00 
  671abf:	0f 87 2b 16 00 00    	ja     6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  671ac5:	4d 85 c9             	test   %r9,%r9
  671ac8:	0f 84 f6 04 00 00    	je     671fc4 <<gpui_canvas::text::planner::Planner>::shape+0x1f24>
  671ace:	49 39 c9             	cmp    %rcx,%r9
  671ad1:	0f 83 e7 04 00 00    	jae    671fbe <<gpui_canvas::text::planner::Planner>::shape+0x1f1e>
  671ad7:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  671adc:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  671ae1:	0f 8f dd 04 00 00    	jg     671fc4 <<gpui_canvas::text::planner::Planner>::shape+0x1f24>
  671ae7:	e9 04 16 00 00       	jmp    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  671aec:	4c 89 ac 24 00 01 00 	mov    %r13,0x100(%rsp)
  671af3:	00 
  671af4:	f6 84 24 d0 02 00 00 	testb  $0x1,0x2d0(%rsp)
  671afb:	01 
  671afc:	74 19                	je     671b17 <<gpui_canvas::text::planner::Planner>::shape+0x1a77>
  671afe:	4c 89 f2             	mov    %r14,%rdx
  671b01:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  671b08:	00 
  671b09:	39 d1                	cmp    %edx,%ecx
  671b0b:	0f 83 3d 01 00 00    	jae    671c4e <<gpui_canvas::text::planner::Planner>::shape+0x1bae>
  671b11:	ff ca                	dec    %edx
  671b13:	89 d0                	mov    %edx,%eax
  671b15:	eb 19                	jmp    671b30 <<gpui_canvas::text::planner::Planner>::shape+0x1a90>
  671b17:	4c 89 f2             	mov    %r14,%rdx
  671b1a:	48 8b ac 24 f0 00 00 	mov    0xf0(%rsp),%rbp
  671b21:	00 
  671b22:	39 d5                	cmp    %edx,%ebp
  671b24:	0f 83 3f 01 00 00    	jae    671c69 <<gpui_canvas::text::planner::Planner>::shape+0x1bc9>
  671b2a:	8d 4d 01             	lea    0x1(%rbp),%ecx
  671b2d:	48 89 e8             	mov    %rbp,%rax
  671b30:	89 c7                	mov    %eax,%edi
  671b32:	48 39 fb             	cmp    %rdi,%rbx
  671b35:	0f 86 6c 1c 00 00    	jbe    6737a7 <<gpui_canvas::text::planner::Planner>::shape+0x3707>
  671b3b:	49 89 d6             	mov    %rdx,%r14
  671b3e:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  671b42:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  671b49:	00 
  671b4a:	44 8b 6c c2 08       	mov    0x8(%rdx,%rax,8),%r13d
  671b4f:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  671b54:	0f 85 61 05 00 00    	jne    6720bb <<gpui_canvas::text::planner::Planner>::shape+0x201b>
  671b5a:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  671b5e:	8b 50 0c             	mov    0xc(%rax),%edx
  671b61:	4a 8d 34 2a          	lea    (%rdx,%r13,1),%rsi
  671b65:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  671b6c:	00 
  671b6d:	0f 87 6e 18 00 00    	ja     6733e1 <<gpui_canvas::text::planner::Planner>::shape+0x3341>
  671b73:	49 c1 e5 04          	shl    $0x4,%r13
  671b77:	4c 03 ac 24 70 02 00 	add    0x270(%rsp),%r13
  671b7e:	00 
  671b7f:	48 89 d0             	mov    %rdx,%rax
  671b82:	48 c1 e0 04          	shl    $0x4,%rax
  671b86:	4c 01 e8             	add    %r13,%rax
  671b89:	0f 57 c0             	xorps  %xmm0,%xmm0
  671b8c:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  671b93:	00 
  671b94:	48 85 d2             	test   %rdx,%rdx
  671b97:	0f 85 bd 06 00 00    	jne    67225a <<gpui_canvas::text::planner::Planner>::shape+0x21ba>
  671b9d:	89 ca                	mov    %ecx,%edx
  671b9f:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
  671ba6:	00 
  671ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  671bae:	00 00 
  671bb0:	f6 84 24 d0 02 00 00 	testb  $0x1,0x2d0(%rsp)
  671bb7:	01 
  671bb8:	74 16                	je     671bd0 <<gpui_canvas::text::planner::Planner>::shape+0x1b30>
  671bba:	44 39 f1             	cmp    %r14d,%ecx
  671bbd:	0f 83 c5 00 00 00    	jae    671c88 <<gpui_canvas::text::planner::Planner>::shape+0x1be8>
  671bc3:	41 ff ce             	dec    %r14d
  671bc6:	4c 89 f0             	mov    %r14,%rax
  671bc9:	89 ca                	mov    %ecx,%edx
  671bcb:	89 c1                	mov    %eax,%ecx
  671bcd:	eb 19                	jmp    671be8 <<gpui_canvas::text::planner::Planner>::shape+0x1b48>
  671bcf:	90                   	nop
  671bd0:	4c 89 f2             	mov    %r14,%rdx
  671bd3:	39 d1                	cmp    %edx,%ecx
  671bd5:	0f 83 5c 01 00 00    	jae    671d37 <<gpui_canvas::text::planner::Planner>::shape+0x1c97>
  671bdb:	8d 41 01             	lea    0x1(%rcx),%eax
  671bde:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  671be5:	00 
  671be6:	89 c2                	mov    %eax,%edx
  671be8:	89 cf                	mov    %ecx,%edi
  671bea:	48 39 fb             	cmp    %rdi,%rbx
  671bed:	0f 86 b4 1b 00 00    	jbe    6737a7 <<gpui_canvas::text::planner::Planner>::shape+0x3707>
  671bf3:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  671bf7:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  671bfe:	00 
  671bff:	44 8b 6c c1 08       	mov    0x8(%rcx,%rax,8),%r13d
  671c04:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  671c09:	0f 85 a4 04 00 00    	jne    6720b3 <<gpui_canvas::text::planner::Planner>::shape+0x2013>
  671c0f:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  671c13:	8b 78 0c             	mov    0xc(%rax),%edi
  671c16:	4a 8d 34 2f          	lea    (%rdi,%r13,1),%rsi
  671c1a:	48 3b b4 24 40 01 00 	cmp    0x140(%rsp),%rsi
  671c21:	00 
  671c22:	0f 87 b9 17 00 00    	ja     6733e1 <<gpui_canvas::text::planner::Planner>::shape+0x3341>
  671c28:	49 c1 e5 04          	shl    $0x4,%r13
  671c2c:	4c 03 ac 24 70 02 00 	add    0x270(%rsp),%r13
  671c33:	00 
  671c34:	48 89 f8             	mov    %rdi,%rax
  671c37:	48 c1 e0 04          	shl    $0x4,%rax
  671c3b:	4c 01 e8             	add    %r13,%rax
  671c3e:	89 d1                	mov    %edx,%ecx
  671c40:	48 85 ff             	test   %rdi,%rdi
  671c43:	0f 84 67 ff ff ff    	je     671bb0 <<gpui_canvas::text::planner::Planner>::shape+0x1b10>
  671c49:	e9 e0 04 00 00       	jmp    67212e <<gpui_canvas::text::planner::Planner>::shape+0x208e>
  671c4e:	4c 89 e8             	mov    %r13,%rax
  671c51:	3b 8c 24 e0 01 00 00 	cmp    0x1e0(%rsp),%ecx
  671c58:	0f 95 c2             	setne  %dl
  671c5b:	84 94 24 18 01 00 00 	test   %dl,0x118(%rsp)
  671c62:	75 4e                	jne    671cb2 <<gpui_canvas::text::planner::Planner>::shape+0x1c12>
  671c64:	e9 0b 06 00 00       	jmp    672274 <<gpui_canvas::text::planner::Planner>::shape+0x21d4>
  671c69:	4c 89 e8             	mov    %r13,%rax
  671c6c:	3b 94 24 e8 01 00 00 	cmp    0x1e8(%rsp),%edx
  671c73:	0f 95 c1             	setne  %cl
  671c76:	84 8c 24 18 01 00 00 	test   %cl,0x118(%rsp)
  671c7d:	0f 85 de 00 00 00    	jne    671d61 <<gpui_canvas::text::planner::Planner>::shape+0x1cc1>
  671c83:	e9 ec 05 00 00       	jmp    672274 <<gpui_canvas::text::planner::Planner>::shape+0x21d4>
  671c88:	0f 57 c0             	xorps  %xmm0,%xmm0
  671c8b:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  671c92:	00 
  671c93:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  671c9a:	00 
  671c9b:	3b 8c 24 e0 01 00 00 	cmp    0x1e0(%rsp),%ecx
  671ca2:	0f 95 c2             	setne  %dl
  671ca5:	84 94 24 18 01 00 00 	test   %dl,0x118(%rsp)
  671cac:	0f 84 c2 05 00 00    	je     672274 <<gpui_canvas::text::planner::Planner>::shape+0x21d4>
  671cb2:	8d 79 ff             	lea    -0x1(%rcx),%edi
  671cb5:	48 39 fb             	cmp    %rdi,%rbx
  671cb8:	0f 86 8a 1b 00 00    	jbe    673848 <<gpui_canvas::text::planner::Planner>::shape+0x37a8>
  671cbe:	3b bc 24 e0 01 00 00 	cmp    0x1e0(%rsp),%edi
  671cc5:	76 47                	jbe    671d0e <<gpui_canvas::text::planner::Planner>::shape+0x1c6e>
  671cc7:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  671ccb:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  671cd2:	00 
  671cd3:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  671cd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  671cde:	00 00 
  671ce0:	48 39 fb             	cmp    %rdi,%rbx
  671ce3:	0f 86 df 1a 00 00    	jbe    6737c8 <<gpui_canvas::text::planner::Planner>::shape+0x3728>
  671ce9:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  671ced:	75 1f                	jne    671d0e <<gpui_canvas::text::planner::Planner>::shape+0x1c6e>
  671cef:	48 ff cf             	dec    %rdi
  671cf2:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  671cf6:	39 bc 24 e0 01 00 00 	cmp    %edi,0x1e0(%rsp)
  671cfd:	72 e1                	jb     671ce0 <<gpui_canvas::text::planner::Planner>::shape+0x1c40>
  671cff:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
  671d06:	00 
  671d07:	48 89 d7             	mov    %rdx,%rdi
  671d0a:	89 d5                	mov    %edx,%ebp
  671d0c:	eb 02                	jmp    671d10 <<gpui_canvas::text::planner::Planner>::shape+0x1c70>
  671d0e:	89 fd                	mov    %edi,%ebp
  671d10:	48 39 fb             	cmp    %rdi,%rbx
  671d13:	0f 86 3b 1b 00 00    	jbe    673854 <<gpui_canvas::text::planner::Planner>::shape+0x37b4>
  671d19:	48 89 ac 24 f0 00 00 	mov    %rbp,0xf0(%rsp)
  671d20:	00 
  671d21:	89 ca                	mov    %ecx,%edx
  671d23:	48 ff ca             	dec    %rdx
  671d26:	48 39 da             	cmp    %rbx,%rdx
  671d29:	0f 83 31 1b 00 00    	jae    673860 <<gpui_canvas::text::planner::Planner>::shape+0x37c0>
  671d2f:	41 89 ce             	mov    %ecx,%r14d
  671d32:	e9 a8 00 00 00       	jmp    671ddf <<gpui_canvas::text::planner::Planner>::shape+0x1d3f>
  671d37:	0f 57 c0             	xorps  %xmm0,%xmm0
  671d3a:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  671d41:	00 
  671d42:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  671d49:	00 
  671d4a:	3b 94 24 e8 01 00 00 	cmp    0x1e8(%rsp),%edx
  671d51:	0f 95 c1             	setne  %cl
  671d54:	84 8c 24 18 01 00 00 	test   %cl,0x118(%rsp)
  671d5b:	0f 84 13 05 00 00    	je     672274 <<gpui_canvas::text::planner::Planner>::shape+0x21d4>
  671d61:	49 89 d0             	mov    %rdx,%r8
  671d64:	48 89 d1             	mov    %rdx,%rcx
  671d67:	89 cf                	mov    %ecx,%edi
  671d69:	48 39 fb             	cmp    %rdi,%rbx
  671d6c:	0f 86 c1 1a 00 00    	jbe    673833 <<gpui_canvas::text::planner::Planner>::shape+0x3793>
  671d72:	44 8d 71 01          	lea    0x1(%rcx),%r14d
  671d76:	44 3b b4 24 e8 01 00 	cmp    0x1e8(%rsp),%r14d
  671d7d:	00 
  671d7e:	73 48                	jae    671dc8 <<gpui_canvas::text::planner::Planner>::shape+0x1d28>
  671d80:	44 89 f2             	mov    %r14d,%edx
  671d83:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  671d87:	48 8b b4 24 48 02 00 	mov    0x248(%rsp),%rsi
  671d8e:	00 
  671d8f:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  671d93:	49 89 d6             	mov    %rdx,%r14
  671d96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  671d9d:	00 00 00 
  671da0:	4c 39 f3             	cmp    %r14,%rbx
  671da3:	0f 86 07 1a 00 00    	jbe    6737b0 <<gpui_canvas::text::planner::Planner>::shape+0x3710>
  671da9:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  671dad:	75 19                	jne    671dc8 <<gpui_canvas::text::planner::Planner>::shape+0x1d28>
  671daf:	49 ff c6             	inc    %r14
  671db2:	48 83 c6 18          	add    $0x18,%rsi
  671db6:	4c 39 b4 24 e8 01 00 	cmp    %r14,0x1e8(%rsp)
  671dbd:	00 
  671dbe:	75 e0                	jne    671da0 <<gpui_canvas::text::planner::Planner>::shape+0x1d00>
  671dc0:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  671dc7:	00 
  671dc8:	44 89 f2             	mov    %r14d,%edx
  671dcb:	48 ff ca             	dec    %rdx
  671dce:	48 39 da             	cmp    %rbx,%rdx
  671dd1:	0f 83 65 1a 00 00    	jae    67383c <<gpui_canvas::text::planner::Planner>::shape+0x379c>
  671dd7:	4c 89 84 24 f0 00 00 	mov    %r8,0xf0(%rsp)
  671dde:	00 
  671ddf:	48 83 bc 24 60 02 00 	cmpq   $0x0,0x260(%rsp)
  671de6:	00 00 
  671de8:	0f 84 86 04 00 00    	je     672274 <<gpui_canvas::text::planner::Planner>::shape+0x21d4>
  671dee:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  671df2:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  671df9:	00 
  671dfa:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  671dfd:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  671e01:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  671e05:	39 ce                	cmp    %ecx,%esi
  671e07:	0f 82 0a 19 00 00    	jb     673717 <<gpui_canvas::text::planner::Planner>::shape+0x3677>
  671e0d:	48 39 b4 24 00 02 00 	cmp    %rsi,0x200(%rsp)
  671e14:	00 
  671e15:	0f 82 fc 18 00 00    	jb     673717 <<gpui_canvas::text::planner::Planner>::shape+0x3677>
  671e1b:	39 ce                	cmp    %ecx,%esi
  671e1d:	0f 84 f1 19 00 00    	je     673814 <<gpui_canvas::text::planner::Planner>::shape+0x3774>
  671e23:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  671e27:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  671e2e:	00 
  671e2f:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  671e34:	8d 51 ff             	lea    -0x1(%rcx),%edx
  671e37:	83 fa 02             	cmp    $0x2,%edx
  671e3a:	73 26                	jae    671e62 <<gpui_canvas::text::planner::Planner>::shape+0x1dc2>
  671e3c:	f3 0f 10 84 24 24 02 	movss  0x224(%rsp),%xmm0
  671e43:	00 00 
  671e45:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  671e4b:	4c 89 f2             	mov    %r14,%rdx
  671e4e:	3b 94 24 20 02 00 00 	cmp    0x220(%rsp),%edx
  671e55:	77 2b                	ja     671e82 <<gpui_canvas::text::planner::Planner>::shape+0x1de2>
  671e57:	f3 0f 10 84 24 1c 02 	movss  0x21c(%rsp),%xmm0
  671e5e:	00 00 
  671e60:	eb 1a                	jmp    671e7c <<gpui_canvas::text::planner::Planner>::shape+0x1ddc>
  671e62:	f3 0f 10 84 24 28 02 	movss  0x228(%rsp),%xmm0
  671e69:	00 00 
  671e6b:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  671e71:	83 f9 06             	cmp    $0x6,%ecx
  671e74:	4c 89 f2             	mov    %r14,%rdx
  671e77:	75 09                	jne    671e82 <<gpui_canvas::text::planner::Planner>::shape+0x1de2>
  671e79:	0f 57 c0             	xorps  %xmm0,%xmm0
  671e7c:	f3 0f 11 44 24 60    	movss  %xmm0,0x60(%rsp)
  671e82:	89 d6                	mov    %edx,%esi
  671e84:	48 39 f3             	cmp    %rsi,%rbx
  671e87:	0f 92 c1             	setb   %cl
  671e8a:	3b 94 24 f0 00 00 00 	cmp    0xf0(%rsp),%edx
  671e91:	0f 82 0e 01 00 00    	jb     671fa5 <<gpui_canvas::text::planner::Planner>::shape+0x1f05>
  671e97:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  671e9e:	00 
  671e9f:	89 fa                	mov    %edi,%edx
  671ea1:	84 c9                	test   %cl,%cl
  671ea3:	0f 85 8d 18 00 00    	jne    673736 <<gpui_canvas::text::planner::Planner>::shape+0x3696>
  671ea9:	44 39 f7             	cmp    %r14d,%edi
  671eac:	75 11                	jne    671ebf <<gpui_canvas::text::planner::Planner>::shape+0x1e1f>
  671eae:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  671eb5:	00 00 00 00 00 
  671eba:	e9 bd 00 00 00       	jmp    671f7c <<gpui_canvas::text::planner::Planner>::shape+0x1edc>
  671ebf:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  671ec6:	00 
  671ec7:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  671ecb:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  671ecf:	48 39 d7             	cmp    %rdx,%rdi
  671ed2:	75 10                	jne    671ee4 <<gpui_canvas::text::planner::Planner>::shape+0x1e44>
  671ed4:	31 d2                	xor    %edx,%edx
  671ed6:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  671edd:	00 00 00 00 00 
  671ee2:	eb 67                	jmp    671f4b <<gpui_canvas::text::planner::Planner>::shape+0x1eab>
  671ee4:	48 29 d6             	sub    %rdx,%rsi
  671ee7:	48 89 f7             	mov    %rsi,%rdi
  671eea:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  671eee:	48 8b 94 24 40 03 00 	mov    0x340(%rsp),%rdx
  671ef5:	00 
  671ef6:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  671efa:	31 d2                	xor    %edx,%edx
  671efc:	45 31 d2             	xor    %r10d,%r10d
  671eff:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  671f05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  671f0c:	00 00 00 00 
  671f10:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  671f14:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  671f19:	4d 0f 45 cb          	cmovne %r11,%r9
  671f1d:	4d 01 d1             	add    %r10,%r9
  671f20:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  671f25:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  671f29:	4d 0f 45 d3          	cmovne %r11,%r10
  671f2d:	4d 01 ca             	add    %r9,%r10
  671f30:	48 83 c2 02          	add    $0x2,%rdx
  671f34:	49 83 c0 30          	add    $0x30,%r8
  671f38:	48 39 d7             	cmp    %rdx,%rdi
  671f3b:	75 d3                	jne    671f10 <<gpui_canvas::text::planner::Planner>::shape+0x1e70>
  671f3d:	4c 89 94 24 38 01 00 	mov    %r10,0x138(%rsp)
  671f44:	00 
  671f45:	40 f6 c6 01          	test   $0x1,%sil
  671f49:	74 31                	je     671f7c <<gpui_canvas::text::planner::Planner>::shape+0x1edc>
  671f4b:	48 8b b4 24 38 01 00 	mov    0x138(%rsp),%rsi
  671f52:	00 
  671f53:	48 03 8c 24 90 00 00 	add    0x90(%rsp),%rcx
  671f5a:	00 
  671f5b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  671f5f:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  671f64:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  671f68:	b9 01 00 00 00       	mov    $0x1,%ecx
  671f6d:	48 0f 45 d1          	cmovne %rcx,%rdx
  671f71:	48 01 f2             	add    %rsi,%rdx
  671f74:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
  671f7b:	00 
  671f7c:	0f 57 c0             	xorps  %xmm0,%xmm0
  671f7f:	f3 0f 11 84 24 c8 01 	movss  %xmm0,0x1c8(%rsp)
  671f86:	00 00 
  671f88:	b9 00 00 00 00       	mov    $0x0,%ecx
  671f8d:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  671f92:	ba 00 00 00 00       	mov    $0x0,%edx
  671f97:	49 39 c5             	cmp    %rax,%r13
  671f9a:	0f 84 54 fb ff ff    	je     671af4 <<gpui_canvas::text::planner::Planner>::shape+0x1a54>
  671fa0:	e9 0e fa ff ff       	jmp    6719b3 <<gpui_canvas::text::planner::Planner>::shape+0x1913>
  671fa5:	b1 01                	mov    $0x1,%cl
  671fa7:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  671fae:	00 
  671faf:	89 fa                	mov    %edi,%edx
  671fb1:	84 c9                	test   %cl,%cl
  671fb3:	0f 84 f0 fe ff ff    	je     671ea9 <<gpui_canvas::text::planner::Planner>::shape+0x1e09>
  671fb9:	e9 78 17 00 00       	jmp    673736 <<gpui_canvas::text::planner::Planner>::shape+0x3696>
  671fbe:	0f 85 2c 11 00 00    	jne    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  671fc4:	48 85 ed             	test   %rbp,%rbp
  671fc7:	0f 94 c2             	sete   %dl
  671fca:	74 1b                	je     671fe7 <<gpui_canvas::text::planner::Planner>::shape+0x1f47>
  671fcc:	48 39 cd             	cmp    %rcx,%rbp
  671fcf:	73 10                	jae    671fe1 <<gpui_canvas::text::planner::Planner>::shape+0x1f41>
  671fd1:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  671fd6:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  671fda:	7d 0b                	jge    671fe7 <<gpui_canvas::text::planner::Planner>::shape+0x1f47>
  671fdc:	e9 0f 11 00 00       	jmp    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  671fe1:	0f 85 09 11 00 00    	jne    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  671fe7:	83 7c 24 64 00       	cmpl   $0x0,0x64(%rsp)
  671fec:	0f 84 9a 00 00 00    	je     67208c <<gpui_canvas::text::planner::Planner>::shape+0x1fec>
  671ff2:	f3 0f 10 44 24 2c    	movss  0x2c(%rsp),%xmm0
  671ff8:	f3 0f 58 84 24 14 01 	addss  0x114(%rsp),%xmm0
  671fff:	00 00 
  672001:	f3 0f 11 44 24 2c    	movss  %xmm0,0x2c(%rsp)
  672007:	66 0f 7e c1          	movd   %xmm0,%ecx
  67200b:	0f 28 84 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm0
  672012:	00 
  672013:	0f 58 84 24 80 03 00 	addps  0x380(%rsp),%xmm0
  67201a:	00 
  67201b:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  67201f:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  672026:	00 
  672027:	66 0f 7e c0          	movd   %xmm0,%eax
  67202b:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  672031:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  672036:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  67203b:	0f 9d c0             	setge  %al
  67203e:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  672044:	0f 8f 56 11 00 00    	jg     6731a0 <<gpui_canvas::text::planner::Planner>::shape+0x3100>
  67204a:	84 c0                	test   %al,%al
  67204c:	0f 85 4e 11 00 00    	jne    6731a0 <<gpui_canvas::text::planner::Planner>::shape+0x3100>
  672052:	81 7c 24 64 ff ff 00 	cmpl   $0xffff,0x64(%rsp)
  672059:	00 
  67205a:	0f 87 90 10 00 00    	ja     6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  672060:	4c 89 cd             	mov    %r9,%rbp
  672063:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
  67206a:	00 
  67206b:	48 3b 9c 24 20 01 00 	cmp    0x120(%rsp),%rbx
  672072:	00 
  672073:	0f 85 4f f8 ff ff    	jne    6718c8 <<gpui_canvas::text::planner::Planner>::shape+0x1828>
  672079:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
  672080:	00 
  672081:	ff 15 01 4b 11 00    	call   *0x114b01(%rip)        # 786b88 <_DYNAMIC+0x660>
  672087:	e9 3c f8 ff ff       	jmp    6718c8 <<gpui_canvas::text::planner::Planner>::shape+0x1828>
  67208c:	4d 85 c9             	test   %r9,%r9
  67208f:	0f 84 b1 00 00 00    	je     672146 <<gpui_canvas::text::planner::Planner>::shape+0x20a6>
  672095:	49 39 c9             	cmp    %rcx,%r9
  672098:	0f 83 a2 00 00 00    	jae    672140 <<gpui_canvas::text::planner::Planner>::shape+0x20a0>
  67209e:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6720a3:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  6720a8:	0f 8f 98 00 00 00    	jg     672146 <<gpui_canvas::text::planner::Planner>::shape+0x20a6>
  6720ae:	e9 95 11 00 00       	jmp    673248 <<gpui_canvas::text::planner::Planner>::shape+0x31a8>
  6720b3:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  6720ba:	00 
  6720bb:	44 89 ea             	mov    %r13d,%edx
  6720be:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  6720c2:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  6720c9:	00 
  6720ca:	f3 0f 10 44 c6 10    	movss  0x10(%rsi,%rax,8),%xmm0
  6720d0:	0f 57 c9             	xorps  %xmm1,%xmm1
  6720d3:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  6720da:	00 
  6720db:	41 bd 04 00 00 00    	mov    $0x4,%r13d
  6720e1:	b8 04 00 00 00       	mov    $0x4,%eax
  6720e6:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  6720ed:	00 
  6720ee:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  6720f5:	00 
  6720f6:	f3 0f 11 84 24 c0 01 	movss  %xmm0,0x1c0(%rsp)
  6720fd:	00 00 
  6720ff:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  672105:	89 94 24 c4 01 00 00 	mov    %edx,0x1c4(%rsp)
  67210c:	89 54 24 64          	mov    %edx,0x64(%rsp)
  672110:	0f 57 c0             	xorps  %xmm0,%xmm0
  672113:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  67211a:	00 
  67211b:	83 bc 24 18 01 00 00 	cmpl   $0x0,0x118(%rsp)
  672122:	00 
  672123:	0f 85 4b f8 ff ff    	jne    671974 <<gpui_canvas::text::planner::Planner>::shape+0x18d4>
  672129:	e9 ba f8 ff ff       	jmp    6719e8 <<gpui_canvas::text::planner::Planner>::shape+0x1948>
  67212e:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  672133:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  67213a:	00 
  67213b:	e9 73 f8 ff ff       	jmp    6719b3 <<gpui_canvas::text::planner::Planner>::shape+0x1913>
  672140:	0f 85 02 11 00 00    	jne    673248 <<gpui_canvas::text::planner::Planner>::shape+0x31a8>
  672146:	48 85 ed             	test   %rbp,%rbp
  672149:	4c 89 8c 24 38 03 00 	mov    %r9,0x338(%rsp)
  672150:	00 
  672151:	74 1b                	je     67216e <<gpui_canvas::text::planner::Planner>::shape+0x20ce>
  672153:	48 39 cd             	cmp    %rcx,%rbp
  672156:	73 10                	jae    672168 <<gpui_canvas::text::planner::Planner>::shape+0x20c8>
  672158:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  67215d:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  672161:	7d 0b                	jge    67216e <<gpui_canvas::text::planner::Planner>::shape+0x20ce>
  672163:	e9 e7 10 00 00       	jmp    67324f <<gpui_canvas::text::planner::Planner>::shape+0x31af>
  672168:	0f 85 e1 10 00 00    	jne    67324f <<gpui_canvas::text::planner::Planner>::shape+0x31af>
  67216e:	89 54 24 2c          	mov    %edx,0x2c(%rsp)
  672172:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  672177:	4a 8d 1c 08          	lea    (%rax,%r9,1),%rbx
  67217b:	48 01 e8             	add    %rbp,%rax
  67217e:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  672185:	00 
  672186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67218d:	00 00 00 
  672190:	48 3b 9c 24 a0 01 00 	cmp    0x1a0(%rsp),%rbx
  672197:	00 
  672198:	0f 84 8c 00 00 00    	je     67222a <<gpui_canvas::text::planner::Planner>::shape+0x218a>
  67219e:	0f b6 33             	movzbl (%rbx),%esi
  6721a1:	40 84 f6             	test   %sil,%sil
  6721a4:	78 0a                	js     6721b0 <<gpui_canvas::text::planner::Planner>::shape+0x2110>
  6721a6:	48 ff c3             	inc    %rbx
  6721a9:	eb 65                	jmp    672210 <<gpui_canvas::text::planner::Planner>::shape+0x2170>
  6721ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6721b0:	89 f0                	mov    %esi,%eax
  6721b2:	83 e0 1f             	and    $0x1f,%eax
  6721b5:	0f b6 53 01          	movzbl 0x1(%rbx),%edx
  6721b9:	83 e2 3f             	and    $0x3f,%edx
  6721bc:	40 80 fe df          	cmp    $0xdf,%sil
  6721c0:	76 2c                	jbe    6721ee <<gpui_canvas::text::planner::Planner>::shape+0x214e>
  6721c2:	0f b6 4b 02          	movzbl 0x2(%rbx),%ecx
  6721c6:	c1 e2 06             	shl    $0x6,%edx
  6721c9:	83 e1 3f             	and    $0x3f,%ecx
  6721cc:	09 d1                	or     %edx,%ecx
  6721ce:	40 80 fe f0          	cmp    $0xf0,%sil
  6721d2:	72 27                	jb     6721fb <<gpui_canvas::text::planner::Planner>::shape+0x215b>
  6721d4:	0f b6 73 03          	movzbl 0x3(%rbx),%esi
  6721d8:	48 83 c3 04          	add    $0x4,%rbx
  6721dc:	83 e0 07             	and    $0x7,%eax
  6721df:	c1 e0 12             	shl    $0x12,%eax
  6721e2:	c1 e1 06             	shl    $0x6,%ecx
  6721e5:	83 e6 3f             	and    $0x3f,%esi
  6721e8:	09 ce                	or     %ecx,%esi
  6721ea:	09 c6                	or     %eax,%esi
  6721ec:	eb 22                	jmp    672210 <<gpui_canvas::text::planner::Planner>::shape+0x2170>
  6721ee:	48 83 c3 02          	add    $0x2,%rbx
  6721f2:	c1 e0 06             	shl    $0x6,%eax
  6721f5:	09 d0                	or     %edx,%eax
  6721f7:	89 c6                	mov    %eax,%esi
  6721f9:	eb 15                	jmp    672210 <<gpui_canvas::text::planner::Planner>::shape+0x2170>
  6721fb:	48 83 c3 03          	add    $0x3,%rbx
  6721ff:	c1 e0 0c             	shl    $0xc,%eax
  672202:	09 c1                	or     %eax,%ecx
  672204:	89 ce                	mov    %ecx,%esi
  672206:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67220d:	00 00 00 
  672210:	48 8d 3d c1 9f 10 00 	lea    0x109fc1(%rip),%rdi        # 77c1d8 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x170>
  672217:	ff 15 5b 49 11 00    	call   *0x11495b(%rip)        # 786b78 <_DYNAMIC+0x650>
  67221d:	84 c0                	test   %al,%al
  67221f:	0f 85 6b ff ff ff    	jne    672190 <<gpui_canvas::text::planner::Planner>::shape+0x20f0>
  672225:	e9 2d 10 00 00       	jmp    673257 <<gpui_canvas::text::planner::Planner>::shape+0x31b7>
  67222a:	31 c0                	xor    %eax,%eax
  67222c:	0f 57 c0             	xorps  %xmm0,%xmm0
  67222f:	f3 0f 10 4c 24 30    	movss  0x30(%rsp),%xmm1
  672235:	0f 2e c8             	ucomiss %xmm0,%xmm1
  672238:	48 8b 9c 24 d8 01 00 	mov    0x1d8(%rsp),%rbx
  67223f:	00 
  672240:	f3 0f 10 84 24 cc 01 	movss  0x1cc(%rsp),%xmm0
  672247:	00 00 
  672249:	0f 85 08 10 00 00    	jne    673257 <<gpui_canvas::text::planner::Planner>::shape+0x31b7>
  67224f:	0f 8b e1 f6 ff ff    	jnp    671936 <<gpui_canvas::text::planner::Planner>::shape+0x1896>
  672255:	e9 fd 0f 00 00       	jmp    673257 <<gpui_canvas::text::planner::Planner>::shape+0x31b7>
  67225a:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  67225f:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  672266:	00 
  672267:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  67226e:	00 
  67226f:	e9 3f f7 ff ff       	jmp    6719b3 <<gpui_canvas::text::planner::Planner>::shape+0x1913>
  672274:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  67227b:	00 
  67227c:	48 8d b4 24 f0 04 00 	lea    0x4f0(%rsp),%rsi
  672283:	00 
  672284:	e8 07 20 00 00       	call   674290 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  672289:	48 83 bc 24 b0 00 00 	cmpq   $0x0,0xb0(%rsp)
  672290:	00 00 
  672292:	0f 85 58 0e 00 00    	jne    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  672298:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  67229f:	00 
  6722a0:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6722a4:	0f 84 c3 f1 ff ff    	je     67146d <<gpui_canvas::text::planner::Planner>::shape+0x13cd>
  6722aa:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6722af:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  6722b4:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  6722bb:	00 
  6722bc:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  6722c1:	75 0f                	jne    6722d2 <<gpui_canvas::text::planner::Planner>::shape+0x2232>
  6722c3:	31 db                	xor    %ebx,%ebx
  6722c5:	45 31 f6             	xor    %r14d,%r14d
  6722c8:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
  6722cf:	00 
  6722d0:	eb 6d                	jmp    67233f <<gpui_canvas::text::planner::Planner>::shape+0x229f>
  6722d2:	48 8b bc 24 28 03 00 	mov    0x328(%rsp),%rdi
  6722d9:	00 
  6722da:	48 85 ff             	test   %rdi,%rdi
  6722dd:	48 8b b4 24 40 02 00 	mov    0x240(%rsp),%rsi
  6722e4:	00 
  6722e5:	48 0f 44 fe          	cmove  %rsi,%rdi
  6722e9:	48 8b 1f             	mov    (%rdi),%rbx
  6722ec:	4c 8b 77 08          	mov    0x8(%rdi),%r14
  6722f0:	4c 39 f3             	cmp    %r14,%rbx
  6722f3:	0f 87 f7 0d 00 00    	ja     6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  6722f9:	48 85 db             	test   %rbx,%rbx
  6722fc:	74 10                	je     67230e <<gpui_canvas::text::planner::Planner>::shape+0x226e>
  6722fe:	48 39 cb             	cmp    %rcx,%rbx
  672301:	73 0f                	jae    672312 <<gpui_canvas::text::planner::Planner>::shape+0x2272>
  672303:	80 3c 1a bf          	cmpb   $0xbf,(%rdx,%rbx,1)
  672307:	7f 12                	jg     67231b <<gpui_canvas::text::planner::Planner>::shape+0x227b>
  672309:	e9 e2 0d 00 00       	jmp    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  67230e:	31 db                	xor    %ebx,%ebx
  672310:	eb 09                	jmp    67231b <<gpui_canvas::text::planner::Planner>::shape+0x227b>
  672312:	48 89 cb             	mov    %rcx,%rbx
  672315:	0f 85 d5 0d 00 00    	jne    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  67231b:	4d 85 f6             	test   %r14,%r14
  67231e:	74 11                	je     672331 <<gpui_canvas::text::planner::Planner>::shape+0x2291>
  672320:	49 39 ce             	cmp    %rcx,%r14
  672323:	73 11                	jae    672336 <<gpui_canvas::text::planner::Planner>::shape+0x2296>
  672325:	42 80 3c 32 c0       	cmpb   $0xc0,(%rdx,%r14,1)
  67232a:	7d 13                	jge    67233f <<gpui_canvas::text::planner::Planner>::shape+0x229f>
  67232c:	e9 bf 0d 00 00       	jmp    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  672331:	45 31 f6             	xor    %r14d,%r14d
  672334:	eb 09                	jmp    67233f <<gpui_canvas::text::planner::Planner>::shape+0x229f>
  672336:	49 89 ce             	mov    %rcx,%r14
  672339:	0f 85 b1 0d 00 00    	jne    6730f0 <<gpui_canvas::text::planner::Planner>::shape+0x3050>
  67233f:	8b 8c 24 30 01 00 00 	mov    0x130(%rsp),%ecx
  672346:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
  67234a:	0f b6 ae 8c 00 00 00 	movzbl 0x8c(%rsi),%ebp
  672351:	4c 8b ac 24 60 01 00 	mov    0x160(%rsp),%r13
  672358:	00 
  672359:	49 39 c5             	cmp    %rax,%r13
  67235c:	75 0e                	jne    67236c <<gpui_canvas::text::planner::Planner>::shape+0x22cc>
  67235e:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  672365:	00 
  672366:	ff 15 24 48 11 00    	call   *0x114824(%rip)        # 786b90 <_DYNAMIC+0x668>
  67236c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  672371:	01 c3                	add    %eax,%ebx
  672373:	41 01 c6             	add    %eax,%r14d
  672376:	40 80 e5 01          	and    $0x1,%bpl
  67237a:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  672381:	00 
  672382:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
  672389:	00 
  67238a:	4c 01 e9             	add    %r13,%rcx
  67238d:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  672390:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  672395:	48 8b 94 24 30 03 00 	mov    0x330(%rsp),%rdx
  67239c:	00 
  67239d:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  6723a1:	8b 54 24 18          	mov    0x18(%rsp),%edx
  6723a5:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  6723a9:	48 8b 94 24 50 02 00 	mov    0x250(%rsp),%rdx
  6723b0:	00 
  6723b1:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  6723b5:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  6723bc:	00 
  6723bd:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  6723c1:	40 88 6c c8 15       	mov    %bpl,0x15(%rax,%rcx,8)
  6723c6:	49 ff c5             	inc    %r13
  6723c9:	4c 89 ac 24 60 01 00 	mov    %r13,0x160(%rsp)
  6723d0:	00 
  6723d1:	e9 97 f0 ff ff       	jmp    67146d <<gpui_canvas::text::planner::Planner>::shape+0x13cd>
  6723d6:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  6723dd:	00 
  6723de:	48 39 84 24 08 01 00 	cmp    %rax,0x108(%rsp)
  6723e5:	00 
  6723e6:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  6723eb:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
  6723f0:	0f 85 fb eb ff ff    	jne    670ff1 <<gpui_canvas::text::planner::Planner>::shape+0xf51>
  6723f6:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6723fd:	00 ff 
  6723ff:	0f 84 c8 07 00 00    	je     672bcd <<gpui_canvas::text::planner::Planner>::shape+0x2b2d>
  672405:	48 83 bc 24 80 01 00 	cmpq   $0xffffffffffffffff,0x180(%rsp)
  67240c:	00 ff 
  67240e:	0f 84 b9 07 00 00    	je     672bcd <<gpui_canvas::text::planner::Planner>::shape+0x2b2d>
  672414:	4c 03 b4 24 48 01 00 	add    0x148(%rsp),%r14
  67241b:	00 
  67241c:	48 c7 84 24 40 07 00 	movq   $0x0,0x740(%rsp)
  672423:	00 00 00 00 00 
  672428:	48 c7 84 24 48 07 00 	movq   $0x8,0x748(%rsp)
  67242f:	00 08 00 00 00 
  672434:	48 c7 84 24 50 07 00 	movq   $0x0,0x750(%rsp)
  67243b:	00 00 00 00 00 
  672440:	c7 84 24 60 07 00 00 	movl   $0xffffffff,0x760(%rsp)
  672447:	ff ff ff ff 
  67244b:	48 8b 6c 24 70       	mov    0x70(%rsp),%rbp
  672450:	48 89 ac 24 68 07 00 	mov    %rbp,0x768(%rsp)
  672457:	00 
  672458:	4c 89 b4 24 70 07 00 	mov    %r14,0x770(%rsp)
  67245f:	00 
  672460:	48 c7 84 24 78 07 00 	movq   $0x0,0x778(%rsp)
  672467:	00 00 00 00 00 
  67246c:	48 8d 05 d5 9e 10 00 	lea    0x109ed5(%rip),%rax        # 77c348 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x2e0>
  672473:	48 89 84 24 80 07 00 	mov    %rax,0x780(%rsp)
  67247a:	00 
  67247b:	48 8d 05 ce b7 ff ff 	lea    -0x4832(%rip),%rax        # 66dc50 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  672482:	48 89 84 24 88 07 00 	mov    %rax,0x788(%rsp)
  672489:	00 
  67248a:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  672491:	00 
  672492:	4c 89 ac 24 90 07 00 	mov    %r13,0x790(%rsp)
  672499:	00 
  67249a:	48 c7 84 24 98 07 00 	movq   $0x0,0x798(%rsp)
  6724a1:	00 00 00 00 00 
  6724a6:	48 c7 84 24 c8 07 00 	movq   $0x0,0x7c8(%rsp)
  6724ad:	00 00 00 00 00 
  6724b2:	c6 84 24 d0 07 00 00 	movb   $0x0,0x7d0(%rsp)
  6724b9:	00 
  6724ba:	31 db                	xor    %ebx,%ebx
  6724bc:	0f 1f 40 00          	nopl   0x0(%rax)
  6724c0:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  6724c7:	00 
  6724c8:	e8 d3 cf 00 00       	call   67f4a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  6724cd:	48 83 f8 01          	cmp    $0x1,%rax
  6724d1:	75 05                	jne    6724d8 <<gpui_canvas::text::planner::Planner>::shape+0x2438>
  6724d3:	48 ff c3             	inc    %rbx
  6724d6:	eb e8                	jmp    6724c0 <<gpui_canvas::text::planner::Planner>::shape+0x2420>
  6724d8:	48 8b b4 24 40 07 00 	mov    0x740(%rsp),%rsi
  6724df:	00 
  6724e0:	48 85 f6             	test   %rsi,%rsi
  6724e3:	74 17                	je     6724fc <<gpui_canvas::text::planner::Planner>::shape+0x245c>
  6724e5:	48 8b bc 24 48 07 00 	mov    0x748(%rsp),%rdi
  6724ec:	00 
  6724ed:	48 c1 e6 03          	shl    $0x3,%rsi
  6724f1:	ba 08 00 00 00       	mov    $0x8,%edx
  6724f6:	ff 15 64 42 11 00    	call   *0x114264(%rip)        # 786760 <_DYNAMIC+0x238>
  6724fc:	48 83 fb 08          	cmp    $0x8,%rbx
  672500:	76 77                	jbe    672579 <<gpui_canvas::text::planner::Planner>::shape+0x24d9>
  672502:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  672509:	00 
  67250a:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  67250f:	e8 9c 62 00 00       	call   6787b0 <<parley::editing::geometry::CursorGeometry<()>>::new>
  672514:	48 8b b4 24 40 07 00 	mov    0x740(%rsp),%rsi
  67251b:	00 
  67251c:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  672520:	0f 84 8e 0e 00 00    	je     6733b4 <<gpui_canvas::text::planner::Planner>::shape+0x3314>
  672526:	48 8d 8c 24 60 07 00 	lea    0x760(%rsp),%rcx
  67252d:	00 
  67252e:	48 8b 41 10          	mov    0x10(%rcx),%rax
  672532:	48 8d 94 24 80 02 00 	lea    0x280(%rsp),%rdx
  672539:	00 
  67253a:	48 89 42 28          	mov    %rax,0x28(%rdx)
  67253e:	0f 10 41 f0          	movups -0x10(%rcx),%xmm0
  672542:	0f 10 09             	movups (%rcx),%xmm1
  672545:	0f 11 4a 18          	movups %xmm1,0x18(%rdx)
  672549:	0f 11 42 08          	movups %xmm0,0x8(%rdx)
  67254d:	48 8b 84 24 48 07 00 	mov    0x748(%rsp),%rax
  672554:	00 
  672555:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
  67255a:	48 89 b4 24 78 02 00 	mov    %rsi,0x278(%rsp)
  672561:	00 
  672562:	48 89 84 24 80 02 00 	mov    %rax,0x280(%rsp)
  672569:	00 
  67256a:	4c 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%r13
  672571:	00 
  672572:	48 8b 6c 24 70       	mov    0x70(%rsp),%rbp
  672577:	eb 15                	jmp    67258e <<gpui_canvas::text::planner::Planner>::shape+0x24ee>
  672579:	48 c7 84 24 78 02 00 	movq   $0xffffffffffffffff,0x278(%rsp)
  672580:	00 ff ff ff ff 
  672585:	48 c7 44 24 30 ff ff 	movq   $0xffffffffffffffff,0x30(%rsp)
  67258c:	ff ff 
  67258e:	48 c7 84 24 f0 04 00 	movq   $0x0,0x4f0(%rsp)
  672595:	00 00 00 00 00 
  67259a:	48 c7 84 24 f8 04 00 	movq   $0x8,0x4f8(%rsp)
  6725a1:	00 08 00 00 00 
  6725a6:	48 c7 84 24 00 05 00 	movq   $0x0,0x500(%rsp)
  6725ad:	00 00 00 00 00 
  6725b2:	c7 84 24 10 05 00 00 	movl   $0xffffffff,0x510(%rsp)
  6725b9:	ff ff ff ff 
  6725bd:	48 89 ac 24 18 05 00 	mov    %rbp,0x518(%rsp)
  6725c4:	00 
  6725c5:	4c 89 b4 24 20 05 00 	mov    %r14,0x520(%rsp)
  6725cc:	00 
  6725cd:	48 c7 84 24 28 05 00 	movq   $0x0,0x528(%rsp)
  6725d4:	00 00 00 00 00 
  6725d9:	48 8d 05 68 9d 10 00 	lea    0x109d68(%rip),%rax        # 77c348 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x2e0>
  6725e0:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  6725e7:	00 
  6725e8:	48 8d 05 61 b6 ff ff 	lea    -0x499f(%rip),%rax        # 66dc50 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  6725ef:	48 89 84 24 38 05 00 	mov    %rax,0x538(%rsp)
  6725f6:	00 
  6725f7:	4c 89 ac 24 40 05 00 	mov    %r13,0x540(%rsp)
  6725fe:	00 
  6725ff:	48 c7 84 24 48 05 00 	movq   $0x0,0x548(%rsp)
  672606:	00 00 00 00 00 
  67260b:	48 c7 84 24 78 05 00 	movq   $0x0,0x578(%rsp)
  672612:	00 00 00 00 00 
  672617:	c6 84 24 80 05 00 00 	movb   $0x0,0x580(%rsp)
  67261e:	00 
  67261f:	f3 0f 10 44 24 3c    	movss  0x3c(%rsp),%xmm0
  672625:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  672629:	f2 0f 11 44 24 50    	movsd  %xmm0,0x50(%rsp)
  67262f:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  672634:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  672639:	eb 0e                	jmp    672649 <<gpui_canvas::text::planner::Planner>::shape+0x25a9>
  67263b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  672640:	45 84 ed             	test   %r13b,%r13b
  672643:	0f 85 45 02 00 00    	jne    67288e <<gpui_canvas::text::planner::Planner>::shape+0x27ee>
  672649:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
  672650:	00 
  672651:	e8 4a ce 00 00       	call   67f4a0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  672656:	48 83 f8 01          	cmp    $0x1,%rax
  67265a:	0f 85 00 05 00 00    	jne    672b60 <<gpui_canvas::text::planner::Planner>::shape+0x2ac0>
  672660:	48 89 d3             	mov    %rdx,%rbx
  672663:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  672667:	74 67                	je     6726d0 <<gpui_canvas::text::planner::Planner>::shape+0x2630>
  672669:	48 8d bc 24 78 02 00 	lea    0x278(%rsp),%rdi
  672670:	00 
  672671:	48 89 de             	mov    %rbx,%rsi
  672674:	ba 01 00 00 00       	mov    $0x1,%edx
  672679:	e8 a2 69 00 00       	call   679020 <<parley::editing::geometry::CursorGeometry<()>>::cursor>
  67267e:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  672685:	00 
  672686:	89 d1                	mov    %edx,%ecx
  672688:	80 e1 01             	and    $0x1,%cl
  67268b:	88 8c 24 f8 01 00 00 	mov    %cl,0x1f8(%rsp)
  672692:	48 39 d8             	cmp    %rbx,%rax
  672695:	0f 85 85 00 00 00    	jne    672720 <<gpui_canvas::text::planner::Planner>::shape+0x2680>
  67269b:	0f b6 ca             	movzbl %dl,%ecx
  67269e:	83 e1 01             	and    $0x1,%ecx
  6726a1:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  6726a8:	00 
  6726a9:	48 8d b4 24 78 02 00 	lea    0x278(%rsp),%rsi
  6726b0:	00 
  6726b1:	48 89 da             	mov    %rbx,%rdx
  6726b4:	f3 0f 10 05 30 af 9a 	movss  -0x6550d0(%rip),%xmm0        # 1d5ec <GCC_except_table0+0x28>
  6726bb:	ff 
  6726bc:	e8 ff 6a 00 00       	call   6791c0 <<parley::editing::geometry::CursorGeometry<()>>::geometry>
  6726c1:	e9 d3 00 00 00       	jmp    672799 <<gpui_canvas::text::planner::Planner>::shape+0x26f9>
  6726c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6726cd:	00 00 00 
  6726d0:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6726d5:	48 89 de             	mov    %rbx,%rsi
  6726d8:	ba 01 00 00 00       	mov    $0x1,%edx
  6726dd:	e8 ee 53 00 00       	call   677ad0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6726e2:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  6726e9:	00 
  6726ea:	80 e2 01             	and    $0x1,%dl
  6726ed:	88 94 24 f8 01 00 00 	mov    %dl,0x1f8(%rsp)
  6726f4:	48 39 d8             	cmp    %rbx,%rax
  6726f7:	75 2f                	jne    672728 <<gpui_canvas::text::planner::Planner>::shape+0x2688>
  6726f9:	48 85 db             	test   %rbx,%rbx
  6726fc:	74 32                	je     672730 <<gpui_canvas::text::planner::Planner>::shape+0x2690>
  6726fe:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
  672702:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  672709:	00 
  67270a:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  67270f:	e8 5c 6e 00 00       	call   679570 <<parley::layout::cluster::Cluster<()>>::from_byte_index>
  672714:	eb 26                	jmp    67273c <<gpui_canvas::text::planner::Planner>::shape+0x269c>
  672716:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67271d:	00 00 00 
  672720:	45 31 ed             	xor    %r13d,%r13d
  672723:	e9 e3 00 00 00       	jmp    67280b <<gpui_canvas::text::planner::Planner>::shape+0x276b>
  672728:	45 31 ed             	xor    %r13d,%r13d
  67272b:	e9 10 01 00 00       	jmp    672840 <<gpui_canvas::text::planner::Planner>::shape+0x27a0>
  672730:	48 c7 84 24 60 04 00 	movq   $0x0,0x460(%rsp)
  672737:	00 00 00 00 00 
  67273c:	48 8d bc 24 d0 07 00 	lea    0x7d0(%rsp),%rdi
  672743:	00 
  672744:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  672749:	48 89 da             	mov    %rbx,%rdx
  67274c:	e8 1f 6e 00 00       	call   679570 <<parley::layout::cluster::Cluster<()>>::from_byte_index>
  672751:	ba 90 00 00 00       	mov    $0x90,%edx
  672756:	4c 8d b4 24 40 07 00 	lea    0x740(%rsp),%r14
  67275d:	00 
  67275e:	4c 89 f7             	mov    %r14,%rdi
  672761:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
  672768:	00 
  672769:	ff 15 89 40 11 00    	call   *0x114089(%rip)        # 7867f8 <memcpy@GLIBC_2.14>
  67276f:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  672776:	00 
  672777:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
  67277e:	00 
  67277f:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  672784:	f3 0f 10 05 60 ae 9a 	movss  -0x6551a0(%rip),%xmm0        # 1d5ec <GCC_except_table0+0x28>
  67278b:	ff 
  67278c:	4c 89 f1             	mov    %r14,%rcx
  67278f:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  672794:	e8 47 51 00 00       	call   6778e0 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::cursor::Cursor>::geometry<()>::{closure#0}>>
  672799:	f2 0f 10 84 24 b8 00 	movsd  0xb8(%rsp),%xmm0
  6727a0:	00 00 
  6727a2:	f2 0f 58 44 24 50    	addsd  0x50(%rsp),%xmm0
  6727a8:	66 0f 28 8c 24 b0 00 	movapd 0xb0(%rsp),%xmm1
  6727af:	00 00 
  6727b1:	66 0f 28 94 24 c0 00 	movapd 0xc0(%rsp),%xmm2
  6727b8:	00 00 
  6727ba:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  6727be:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  6727c2:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  6727c6:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  6727ca:	66 0f 29 54 24 70    	movapd %xmm2,0x70(%rsp)
  6727d0:	66 0f 14 ca          	unpcklpd %xmm2,%xmm1
  6727d4:	66 0f 29 8c 24 a0 00 	movapd %xmm1,0xa0(%rsp)
  6727db:	00 00 
  6727dd:	66 0f 54 0d 3b 2b 9b 	andpd  -0x64d4c5(%rip),%xmm1        # 25320 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  6727e4:	ff 
  6727e5:	66 0f 66 0d 03 25 9b 	pcmpgtd -0x64dafd(%rip),%xmm1        # 24cf0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  6727ec:	ff 
  6727ed:	0f 50 c1             	movmskps %xmm1,%eax
  6727f0:	85 c0                	test   %eax,%eax
  6727f2:	0f 85 08 09 00 00    	jne    673100 <<gpui_canvas::text::planner::Planner>::shape+0x3060>
  6727f8:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  6727fc:	f3 0f 11 44 24 18    	movss  %xmm0,0x18(%rsp)
  672802:	41 b5 01             	mov    $0x1,%r13b
  672805:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  672809:	74 35                	je     672840 <<gpui_canvas::text::planner::Planner>::shape+0x27a0>
  67280b:	48 8d bc 24 78 02 00 	lea    0x278(%rsp),%rdi
  672812:	00 
  672813:	48 89 de             	mov    %rbx,%rsi
  672816:	31 d2                	xor    %edx,%edx
  672818:	e8 03 68 00 00       	call   679020 <<parley::editing::geometry::CursorGeometry<()>>::cursor>
  67281d:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  672824:	00 
  672825:	89 d1                	mov    %edx,%ecx
  672827:	80 e1 01             	and    $0x1,%cl
  67282a:	88 8c 24 f8 01 00 00 	mov    %cl,0x1f8(%rsp)
  672831:	48 39 d8             	cmp    %rbx,%rax
  672834:	0f 85 06 fe ff ff    	jne    672640 <<gpui_canvas::text::planner::Planner>::shape+0x25a0>
  67283a:	e9 dd 00 00 00       	jmp    67291c <<gpui_canvas::text::planner::Planner>::shape+0x287c>
  67283f:	90                   	nop
  672840:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  672845:	48 89 de             	mov    %rbx,%rsi
  672848:	31 d2                	xor    %edx,%edx
  67284a:	e8 81 52 00 00       	call   677ad0 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  67284f:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  672856:	00 
  672857:	80 e2 01             	and    $0x1,%dl
  67285a:	88 94 24 f8 01 00 00 	mov    %dl,0x1f8(%rsp)
  672861:	48 39 d8             	cmp    %rbx,%rax
  672864:	0f 85 d6 fd ff ff    	jne    672640 <<gpui_canvas::text::planner::Planner>::shape+0x25a0>
  67286a:	48 85 db             	test   %rbx,%rbx
  67286d:	0f 84 d1 00 00 00    	je     672944 <<gpui_canvas::text::planner::Planner>::shape+0x28a4>
  672873:	48 8d 53 ff          	lea    -0x1(%rbx),%rdx
  672877:	48 8d bc 24 60 04 00 	lea    0x460(%rsp),%rdi
  67287e:	00 
  67287f:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  672884:	e8 e7 6c 00 00       	call   679570 <<parley::layout::cluster::Cluster<()>>::from_byte_index>
  672889:	e9 c2 00 00 00       	jmp    672950 <<gpui_canvas::text::planner::Planner>::shape+0x28b0>
  67288e:	01 eb                	add    %ebp,%ebx
  672890:	31 ed                	xor    %ebp,%ebp
  672892:	4c 8b ac 24 90 01 00 	mov    0x190(%rsp),%r13
  672899:	00 
  67289a:	4c 3b ac 24 80 01 00 	cmp    0x180(%rsp),%r13
  6728a1:	00 
  6728a2:	75 0e                	jne    6728b2 <<gpui_canvas::text::planner::Planner>::shape+0x2812>
  6728a4:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  6728ab:	00 
  6728ac:	ff 15 e6 42 11 00    	call   *0x1142e6(%rip)        # 786b98 <_DYNAMIC+0x670>
  6728b2:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  6728b9:	00 
  6728ba:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
  6728c1:	00 
  6728c2:	4c 01 e9             	add    %r13,%rcx
  6728c5:	89 1c 88             	mov    %ebx,(%rax,%rcx,4)
  6728c8:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6728cf:	00 
  6728d0:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  6728d6:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  6728db:	49 ff c5             	inc    %r13
  6728de:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
  6728e5:	00 
  6728e6:	40 84 ed             	test   %bpl,%bpl
  6728e9:	0f 84 45 fd ff ff    	je     672634 <<gpui_canvas::text::planner::Planner>::shape+0x2594>
  6728ef:	40 b5 02             	mov    $0x2,%bpl
  6728f2:	4c 3b ac 24 80 01 00 	cmp    0x180(%rsp),%r13
  6728f9:	00 
  6728fa:	0f 85 f8 01 00 00    	jne    672af8 <<gpui_canvas::text::planner::Planner>::shape+0x2a58>
  672900:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  672907:	00 
  672908:	ff 15 8a 42 11 00    	call   *0x11428a(%rip)        # 786b98 <_DYNAMIC+0x670>
  67290e:	f3 0f 10 8c 24 90 00 	movss  0x90(%rsp),%xmm1
  672915:	00 00 
  672917:	e9 01 02 00 00       	jmp    672b1d <<gpui_canvas::text::planner::Planner>::shape+0x2a7d>
  67291c:	0f b6 ca             	movzbl %dl,%ecx
  67291f:	83 e1 01             	and    $0x1,%ecx
  672922:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  672929:	00 
  67292a:	48 8d b4 24 78 02 00 	lea    0x278(%rsp),%rsi
  672931:	00 
  672932:	48 89 da             	mov    %rbx,%rdx
  672935:	f3 0f 10 05 af ac 9a 	movss  -0x655351(%rip),%xmm0        # 1d5ec <GCC_except_table0+0x28>
  67293c:	ff 
  67293d:	e8 7e 68 00 00       	call   6791c0 <<parley::editing::geometry::CursorGeometry<()>>::geometry>
  672942:	eb 69                	jmp    6729ad <<gpui_canvas::text::planner::Planner>::shape+0x290d>
  672944:	48 c7 84 24 60 04 00 	movq   $0x0,0x460(%rsp)
  67294b:	00 00 00 00 00 
  672950:	48 8d bc 24 d0 07 00 	lea    0x7d0(%rsp),%rdi
  672957:	00 
  672958:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  67295d:	48 89 da             	mov    %rbx,%rdx
  672960:	e8 0b 6c 00 00       	call   679570 <<parley::layout::cluster::Cluster<()>>::from_byte_index>
  672965:	ba 90 00 00 00       	mov    $0x90,%edx
  67296a:	4c 8d b4 24 40 07 00 	lea    0x740(%rsp),%r14
  672971:	00 
  672972:	4c 89 f7             	mov    %r14,%rdi
  672975:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
  67297c:	00 
  67297d:	ff 15 75 3e 11 00    	call   *0x113e75(%rip)        # 7867f8 <memcpy@GLIBC_2.14>
  672983:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  67298a:	00 
  67298b:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
  672992:	00 
  672993:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  672998:	f3 0f 10 05 4c ac 9a 	movss  -0x6553b4(%rip),%xmm0        # 1d5ec <GCC_except_table0+0x28>
  67299f:	ff 
  6729a0:	4c 89 f1             	mov    %r14,%rcx
  6729a3:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  6729a8:	e8 33 4f 00 00       	call   6778e0 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::cursor::Cursor>::geometry<()>::{closure#0}>>
  6729ad:	f2 0f 10 84 24 b8 00 	movsd  0xb8(%rsp),%xmm0
  6729b4:	00 00 
  6729b6:	f2 0f 58 44 24 50    	addsd  0x50(%rsp),%xmm0
  6729bc:	66 0f 28 8c 24 b0 00 	movapd 0xb0(%rsp),%xmm1
  6729c3:	00 00 
  6729c5:	66 0f 28 94 24 c0 00 	movapd 0xc0(%rsp),%xmm2
  6729cc:	00 00 
  6729ce:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  6729d2:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  6729d6:	66 0f 5a d9          	cvtpd2ps %xmm1,%xmm3
  6729da:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  6729de:	66 0f 14 d8          	unpcklpd %xmm0,%xmm3
  6729e2:	66 0f 28 c3          	movapd %xmm3,%xmm0
  6729e6:	66 0f 54 05 32 29 9b 	andpd  -0x64d6ce(%rip),%xmm0        # 25320 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  6729ed:	ff 
  6729ee:	66 0f 66 05 fa 22 9b 	pcmpgtd -0x64dd06(%rip),%xmm0        # 24cf0 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  6729f5:	ff 
  6729f6:	0f 50 c0             	movmskps %xmm0,%eax
  6729f9:	85 c0                	test   %eax,%eax
  6729fb:	0f 85 ff 06 00 00    	jne    673100 <<gpui_canvas::text::planner::Planner>::shape+0x3060>
  672a01:	01 eb                	add    %ebp,%ebx
  672a03:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  672a0a:	00 
  672a0b:	0f 2e c3             	ucomiss %xmm3,%xmm0
  672a0e:	0f 9b c0             	setnp  %al
  672a11:	0f 94 c1             	sete   %cl
  672a14:	20 c1                	and    %al,%cl
  672a16:	44 20 e9             	and    %r13b,%cl
  672a19:	80 f9 01             	cmp    $0x1,%cl
  672a1c:	0f 85 88 00 00 00    	jne    672aaa <<gpui_canvas::text::planner::Planner>::shape+0x2a0a>
  672a22:	0f 28 c3             	movaps %xmm3,%xmm0
  672a25:	0f c6 c3 55          	shufps $0x55,%xmm3,%xmm0
  672a29:	f3 0f 10 4c 24 18    	movss  0x18(%rsp),%xmm1
  672a2f:	0f 2e c8             	ucomiss %xmm0,%xmm1
  672a32:	75 76                	jne    672aaa <<gpui_canvas::text::planner::Planner>::shape+0x2a0a>
  672a34:	7a 74                	jp     672aaa <<gpui_canvas::text::planner::Planner>::shape+0x2a0a>
  672a36:	0f 28 c3             	movaps %xmm3,%xmm0
  672a39:	66 0f 15 c3          	unpckhpd %xmm3,%xmm0
  672a3d:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  672a42:	0f 2e c8             	ucomiss %xmm0,%xmm1
  672a45:	75 63                	jne    672aaa <<gpui_canvas::text::planner::Planner>::shape+0x2a0a>
  672a47:	7a 61                	jp     672aaa <<gpui_canvas::text::planner::Planner>::shape+0x2a0a>
  672a49:	0f 28 c3             	movaps %xmm3,%xmm0
  672a4c:	0f c6 c3 ff          	shufps $0xff,%xmm3,%xmm0
  672a50:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  672a55:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
  672a59:	0f 2e c8             	ucomiss %xmm0,%xmm1
  672a5c:	75 4c                	jne    672aaa <<gpui_canvas::text::planner::Planner>::shape+0x2a0a>
  672a5e:	7a 4a                	jp     672aaa <<gpui_canvas::text::planner::Planner>::shape+0x2a0a>
  672a60:	0f 29 9c 24 f0 00 00 	movaps %xmm3,0xf0(%rsp)
  672a67:	00 
  672a68:	4c 8b ac 24 90 01 00 	mov    0x190(%rsp),%r13
  672a6f:	00 
  672a70:	40 b5 03             	mov    $0x3,%bpl
  672a73:	4c 3b ac 24 80 01 00 	cmp    0x180(%rsp),%r13
  672a7a:	00 
  672a7b:	0f 85 82 00 00 00    	jne    672b03 <<gpui_canvas::text::planner::Planner>::shape+0x2a63>
  672a81:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  672a88:	00 
  672a89:	ff 15 09 41 11 00    	call   *0x114109(%rip)        # 786b98 <_DYNAMIC+0x670>
  672a8f:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  672a96:	00 
  672a97:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  672a9e:	00 00 
  672aa0:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
  672aa7:	00 
  672aa8:	eb 73                	jmp    672b1d <<gpui_canvas::text::planner::Planner>::shape+0x2a7d>
  672aaa:	40 b5 01             	mov    $0x1,%bpl
  672aad:	45 84 ed             	test   %r13b,%r13b
  672ab0:	74 24                	je     672ad6 <<gpui_canvas::text::planner::Planner>::shape+0x2a36>
  672ab2:	f3 0f 11 9c 24 90 00 	movss  %xmm3,0x90(%rsp)
  672ab9:	00 00 
  672abb:	4c 8b ac 24 90 01 00 	mov    0x190(%rsp),%r13
  672ac2:	00 
  672ac3:	4c 3b ac 24 80 01 00 	cmp    0x180(%rsp),%r13
  672aca:	00 
  672acb:	0f 84 d3 fd ff ff    	je     6728a4 <<gpui_canvas::text::planner::Planner>::shape+0x2804>
  672ad1:	e9 dc fd ff ff       	jmp    6728b2 <<gpui_canvas::text::planner::Planner>::shape+0x2812>
  672ad6:	4c 8b ac 24 90 01 00 	mov    0x190(%rsp),%r13
  672add:	00 
  672ade:	f3 0f 11 9c 24 90 00 	movss  %xmm3,0x90(%rsp)
  672ae5:	00 00 
  672ae7:	40 b5 02             	mov    $0x2,%bpl
  672aea:	4c 3b ac 24 80 01 00 	cmp    0x180(%rsp),%r13
  672af1:	00 
  672af2:	0f 84 08 fe ff ff    	je     672900 <<gpui_canvas::text::planner::Planner>::shape+0x2860>
  672af8:	f3 0f 10 8c 24 90 00 	movss  0x90(%rsp),%xmm1
  672aff:	00 00 
  672b01:	eb 1a                	jmp    672b1d <<gpui_canvas::text::planner::Planner>::shape+0x2a7d>
  672b03:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  672b0a:	00 
  672b0b:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  672b12:	00 00 
  672b14:	66 0f 28 8c 24 f0 00 	movapd 0xf0(%rsp),%xmm1
  672b1b:	00 00 
  672b1d:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  672b24:	00 
  672b25:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
  672b2c:	00 
  672b2d:	4c 01 e9             	add    %r13,%rcx
  672b30:	89 1c 88             	mov    %ebx,(%rax,%rcx,4)
  672b33:	f3 0f 10 84 24 90 00 	movss  0x90(%rsp),%xmm0
  672b3a:	00 00 
  672b3c:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  672b42:	40 88 6c 88 08       	mov    %bpl,0x8(%rax,%rcx,4)
  672b47:	49 ff c5             	inc    %r13
  672b4a:	4c 89 ac 24 90 01 00 	mov    %r13,0x190(%rsp)
  672b51:	00 
  672b52:	f3 0f 11 8c 24 90 00 	movss  %xmm1,0x90(%rsp)
  672b59:	00 00 
  672b5b:	e9 d4 fa ff ff       	jmp    672634 <<gpui_canvas::text::planner::Planner>::shape+0x2594>
  672b60:	48 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%rsi
  672b67:	00 
  672b68:	48 85 f6             	test   %rsi,%rsi
  672b6b:	74 17                	je     672b84 <<gpui_canvas::text::planner::Planner>::shape+0x2ae4>
  672b6d:	48 8b bc 24 f8 04 00 	mov    0x4f8(%rsp),%rdi
  672b74:	00 
  672b75:	48 c1 e6 03          	shl    $0x3,%rsi
  672b79:	ba 08 00 00 00       	mov    $0x8,%edx
  672b7e:	ff 15 dc 3b 11 00    	call   *0x113bdc(%rip)        # 786760 <_DYNAMIC+0x238>
  672b84:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  672b88:	74 43                	je     672bcd <<gpui_canvas::text::planner::Planner>::shape+0x2b2d>
  672b8a:	4d 85 f6             	test   %r14,%r14
  672b8d:	74 1a                	je     672ba9 <<gpui_canvas::text::planner::Planner>::shape+0x2b09>
  672b8f:	48 8b bc 24 80 02 00 	mov    0x280(%rsp),%rdi
  672b96:	00 
  672b97:	49 c1 e6 04          	shl    $0x4,%r14
  672b9b:	ba 04 00 00 00       	mov    $0x4,%edx
  672ba0:	4c 89 f6             	mov    %r14,%rsi
  672ba3:	ff 15 b7 3b 11 00    	call   *0x113bb7(%rip)        # 786760 <_DYNAMIC+0x238>
  672ba9:	48 8b b4 24 90 02 00 	mov    0x290(%rsp),%rsi
  672bb0:	00 
  672bb1:	48 85 f6             	test   %rsi,%rsi
  672bb4:	74 17                	je     672bcd <<gpui_canvas::text::planner::Planner>::shape+0x2b2d>
  672bb6:	48 8b bc 24 98 02 00 	mov    0x298(%rsp),%rdi
  672bbd:	00 
  672bbe:	48 c1 e6 02          	shl    $0x2,%rsi
  672bc2:	ba 04 00 00 00       	mov    $0x4,%edx
  672bc7:	ff 15 93 3b 11 00    	call   *0x113b93(%rip)        # 786760 <_DYNAMIC+0x238>
  672bcd:	0f 28 9c 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm3
  672bd4:	00 
  672bd5:	0f 28 c3             	movaps %xmm3,%xmm0
  672bd8:	f3 0f 5f 84 24 10 01 	maxss  0x110(%rsp),%xmm0
  672bdf:	00 00 
  672be1:	0f 28 c8             	movaps %xmm0,%xmm1
  672be4:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  672be9:	0f 28 d1             	movaps %xmm1,%xmm2
  672bec:	0f 55 d0             	andnps %xmm0,%xmm2
  672bef:	0f 54 cb             	andps  %xmm3,%xmm1
  672bf2:	0f 56 ca             	orps   %xmm2,%xmm1
  672bf5:	0f 29 8c 24 c0 02 00 	movaps %xmm1,0x2c0(%rsp)
  672bfc:	00 
  672bfd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  672c02:	f3 0f 10 44 24 3c    	movss  0x3c(%rsp),%xmm0
  672c08:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  672c0f:	00 
  672c10:	f3 0f 11 44 24 3c    	movss  %xmm0,0x3c(%rsp)
  672c16:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  672c1b:	48 8b 84 24 60 03 00 	mov    0x360(%rsp),%rax
  672c22:	00 
  672c23:	8b b4 24 88 00 00 00 	mov    0x88(%rsp),%esi
  672c2a:	48 8b ac 24 58 03 00 	mov    0x358(%rsp),%rbp
  672c31:	00 
  672c32:	0f 84 c8 da ff ff    	je     670700 <<gpui_canvas::text::planner::Planner>::shape+0x660>
  672c38:	e9 b1 05 00 00       	jmp    6731ee <<gpui_canvas::text::planner::Planner>::shape+0x314e>
  672c3d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  672c42:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  672c49:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  672c50:	70 
  672c51:	48 01 c1             	add    %rax,%rcx
  672c54:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  672c5b:	00 
  672c5c:	48 89 8c 24 48 07 00 	mov    %rcx,0x748(%rsp)
  672c63:	00 
  672c64:	48 c7 84 24 50 07 00 	movq   $0x0,0x750(%rsp)
  672c6b:	00 00 00 00 00 
  672c70:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  672c75:	48 89 84 24 58 07 00 	mov    %rax,0x758(%rsp)
  672c7c:	00 
  672c7d:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  672c84:	00 
  672c85:	31 f6                	xor    %esi,%esi
  672c87:	48 8d 94 24 1f 01 00 	lea    0x11f(%rsp),%rdx
  672c8e:	00 
  672c8f:	e8 dc 36 ff ff       	call   666370 <<core::iter::adapters::map::Map<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#3}> as core::iter::traits::iterator::Iterator>::fold::<usize, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, usize, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::count::count<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>>>::{closure#0}>>
  672c94:	48 83 f8 02          	cmp    $0x2,%rax
  672c98:	0f 82 15 e1 ff ff    	jb     670db3 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  672c9e:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  672ca5:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  672cac:	00 ff 
  672cae:	0f 84 82 e0 ff ff    	je     670d36 <<gpui_canvas::text::planner::Planner>::shape+0xc96>
  672cb4:	e9 fa e0 ff ff       	jmp    670db3 <<gpui_canvas::text::planner::Planner>::shape+0xd13>
  672cb9:	c7 84 24 88 00 00 00 	movl   $0xffffffff,0x88(%rsp)
  672cc0:	ff ff ff ff 
  672cc4:	e9 9a dc ff ff       	jmp    670963 <<gpui_canvas::text::planner::Planner>::shape+0x8c3>
  672cc9:	44 89 d2             	mov    %r10d,%edx
  672ccc:	83 e2 1f             	and    $0x1f,%edx
  672ccf:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  672cd4:	83 e7 3f             	and    $0x3f,%edi
  672cd7:	41 80 fa df          	cmp    $0xdf,%r10b
  672cdb:	76 31                	jbe    672d0e <<gpui_canvas::text::planner::Planner>::shape+0x2c6e>
  672cdd:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  672ce2:	c1 e7 06             	shl    $0x6,%edi
  672ce5:	83 e6 3f             	and    $0x3f,%esi
  672ce8:	09 fe                	or     %edi,%esi
  672cea:	41 80 fa f0          	cmp    $0xf0,%r10b
  672cee:	72 2c                	jb     672d1c <<gpui_canvas::text::planner::Planner>::shape+0x2c7c>
  672cf0:	49 8d 59 04          	lea    0x4(%r9),%rbx
  672cf4:	45 0f b6 51 03       	movzbl 0x3(%r9),%r10d
  672cf9:	83 e2 07             	and    $0x7,%edx
  672cfc:	c1 e2 12             	shl    $0x12,%edx
  672cff:	c1 e6 06             	shl    $0x6,%esi
  672d02:	41 83 e2 3f          	and    $0x3f,%r10d
  672d06:	41 09 f2             	or     %esi,%r10d
  672d09:	41 09 d2             	or     %edx,%r10d
  672d0c:	eb 1a                	jmp    672d28 <<gpui_canvas::text::planner::Planner>::shape+0x2c88>
  672d0e:	49 8d 59 02          	lea    0x2(%r9),%rbx
  672d12:	c1 e2 06             	shl    $0x6,%edx
  672d15:	09 fa                	or     %edi,%edx
  672d17:	41 89 d2             	mov    %edx,%r10d
  672d1a:	eb 0c                	jmp    672d28 <<gpui_canvas::text::planner::Planner>::shape+0x2c88>
  672d1c:	49 8d 59 03          	lea    0x3(%r9),%rbx
  672d20:	c1 e2 0c             	shl    $0xc,%edx
  672d23:	09 d6                	or     %edx,%esi
  672d25:	41 89 f2             	mov    %esi,%r10d
  672d28:	49 8d 50 02          	lea    0x2(%r8),%rdx
  672d2c:	4c 89 c1             	mov    %r8,%rcx
  672d2f:	48 89 c6             	mov    %rax,%rsi
  672d32:	4c 29 ce             	sub    %r9,%rsi
  672d35:	48 01 de             	add    %rbx,%rsi
  672d38:	41 83 fa 0a          	cmp    $0xa,%r10d
  672d3c:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  672d41:	44 0f 44 d7          	cmove  %edi,%r10d
  672d45:	44 89 94 24 88 00 00 	mov    %r10d,0x88(%rsp)
  672d4c:	00 
  672d4d:	4c 0f 44 da          	cmove  %rdx,%r11
  672d51:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  672d58:	00 
  672d59:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  672d60:	00 
  672d61:	48 89 f0             	mov    %rsi,%rax
  672d64:	4c 89 de             	mov    %r11,%rsi
  672d67:	48 89 5c 24 40       	mov    %rbx,0x40(%rsp)
  672d6c:	e9 fd db ff ff       	jmp    67096e <<gpui_canvas::text::planner::Planner>::shape+0x8ce>
  672d71:	b9 04 00 00 00       	mov    $0x4,%ecx
  672d76:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  672d7c:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
  672d83:	00 
  672d84:	4c 89 ea             	mov    %r13,%rdx
  672d87:	e8 d4 74 00 00       	call   67a260 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  672d8c:	e9 84 e1 ff ff       	jmp    670f15 <<gpui_canvas::text::planner::Planner>::shape+0xe75>
  672d91:	c7 84 24 b8 00 00 00 	movl   $0x7,0xb8(%rsp)
  672d98:	07 00 00 00 
  672d9c:	eb 0b                	jmp    672da9 <<gpui_canvas::text::planner::Planner>::shape+0x2d09>
  672d9e:	c7 84 24 b8 00 00 00 	movl   $0x4,0xb8(%rsp)
  672da5:	04 00 00 00 
  672da9:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  672db0:	00 ff ff ff ff 
  672db5:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  672dba:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  672dc1:	00 
  672dc2:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  672dc6:	74 76                	je     672e3e <<gpui_canvas::text::planner::Planner>::shape+0x2d9e>
  672dc8:	48 85 c0             	test   %rax,%rax
  672dcb:	74 1b                	je     672de8 <<gpui_canvas::text::planner::Planner>::shape+0x2d48>
  672dcd:	48 8b bc 24 58 01 00 	mov    0x158(%rsp),%rdi
  672dd4:	00 
  672dd5:	48 c1 e0 03          	shl    $0x3,%rax
  672dd9:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  672ddd:	ba 04 00 00 00       	mov    $0x4,%edx
  672de2:	ff 15 78 39 11 00    	call   *0x113978(%rip)        # 786760 <_DYNAMIC+0x238>
  672de8:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  672def:	00 
  672df0:	48 85 c0             	test   %rax,%rax
  672df3:	74 1b                	je     672e10 <<gpui_canvas::text::planner::Planner>::shape+0x2d70>
  672df5:	48 8b bc 24 70 01 00 	mov    0x170(%rsp),%rdi
  672dfc:	00 
  672dfd:	48 c1 e0 03          	shl    $0x3,%rax
  672e01:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  672e05:	ba 04 00 00 00       	mov    $0x4,%edx
  672e0a:	ff 15 50 39 11 00    	call   *0x113950(%rip)        # 786760 <_DYNAMIC+0x238>
  672e10:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  672e17:	00 
  672e18:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  672e1c:	74 20                	je     672e3e <<gpui_canvas::text::planner::Planner>::shape+0x2d9e>
  672e1e:	48 85 c0             	test   %rax,%rax
  672e21:	74 1b                	je     672e3e <<gpui_canvas::text::planner::Planner>::shape+0x2d9e>
  672e23:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  672e2a:	00 
  672e2b:	48 c1 e0 02          	shl    $0x2,%rax
  672e2f:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  672e33:	ba 04 00 00 00       	mov    $0x4,%edx
  672e38:	ff 15 22 39 11 00    	call   *0x113922(%rip)        # 786760 <_DYNAMIC+0x238>
  672e3e:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
  672e45:	00 
  672e46:	48 85 f6             	test   %rsi,%rsi
  672e49:	74 17                	je     672e62 <<gpui_canvas::text::planner::Planner>::shape+0x2dc2>
  672e4b:	48 8b bc 24 28 01 00 	mov    0x128(%rsp),%rdi
  672e52:	00 
  672e53:	48 c1 e6 04          	shl    $0x4,%rsi
  672e57:	ba 04 00 00 00       	mov    $0x4,%edx
  672e5c:	ff 15 fe 38 11 00    	call   *0x1138fe(%rip)        # 786760 <_DYNAMIC+0x238>
  672e62:	48 8b b4 24 e0 02 00 	mov    0x2e0(%rsp),%rsi
  672e69:	00 
  672e6a:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  672e6e:	77 18                	ja     672e88 <<gpui_canvas::text::planner::Planner>::shape+0x2de8>
  672e70:	48 85 f6             	test   %rsi,%rsi
  672e73:	74 13                	je     672e88 <<gpui_canvas::text::planner::Planner>::shape+0x2de8>
  672e75:	48 8b bc 24 e8 02 00 	mov    0x2e8(%rsp),%rdi
  672e7c:	00 
  672e7d:	ba 01 00 00 00       	mov    $0x1,%edx
  672e82:	ff 15 d8 38 11 00    	call   *0x1138d8(%rip)        # 786760 <_DYNAMIC+0x238>
  672e88:	48 8b b4 24 f8 02 00 	mov    0x2f8(%rsp),%rsi
  672e8f:	00 
  672e90:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  672e94:	77 18                	ja     672eae <<gpui_canvas::text::planner::Planner>::shape+0x2e0e>
  672e96:	48 85 f6             	test   %rsi,%rsi
  672e99:	74 13                	je     672eae <<gpui_canvas::text::planner::Planner>::shape+0x2e0e>
  672e9b:	48 8b bc 24 00 03 00 	mov    0x300(%rsp),%rdi
  672ea2:	00 
  672ea3:	ba 01 00 00 00       	mov    $0x1,%edx
  672ea8:	ff 15 b2 38 11 00    	call   *0x1138b2(%rip)        # 786760 <_DYNAMIC+0x238>
  672eae:	48 8b b4 24 10 03 00 	mov    0x310(%rsp),%rsi
  672eb5:	00 
  672eb6:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  672eba:	77 18                	ja     672ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2e34>
  672ebc:	48 85 f6             	test   %rsi,%rsi
  672ebf:	74 13                	je     672ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2e34>
  672ec1:	48 8b bc 24 18 03 00 	mov    0x318(%rsp),%rdi
  672ec8:	00 
  672ec9:	ba 01 00 00 00       	mov    $0x1,%edx
  672ece:	ff 15 8c 38 11 00    	call   *0x11388c(%rip)        # 786760 <_DYNAMIC+0x238>
  672ed4:	49 8d bf c8 08 00 00 	lea    0x8c8(%r15),%rdi
  672edb:	e8 20 b6 ff ff       	call   66e500 <core::ptr::drop_glue::<parley::layout::layout::Layout<()>>>
  672ee0:	49 c7 87 c8 08 00 00 	movq   $0x0,0x8c8(%r15)
  672ee7:	00 00 00 00 
  672eeb:	49 c7 87 d0 08 00 00 	movq   $0x4,0x8d0(%r15)
  672ef2:	04 00 00 00 
  672ef6:	0f 57 c0             	xorps  %xmm0,%xmm0
  672ef9:	41 0f 11 87 d8 08 00 	movups %xmm0,0x8d8(%r15)
  672f00:	00 
  672f01:	49 c7 87 e8 08 00 00 	movq   $0x4,0x8e8(%r15)
  672f08:	04 00 00 00 
  672f0c:	41 0f 11 87 f0 08 00 	movups %xmm0,0x8f0(%r15)
  672f13:	00 
  672f14:	49 c7 87 00 09 00 00 	movq   $0x8,0x900(%r15)
  672f1b:	08 00 00 00 
  672f1f:	41 0f 11 87 08 09 00 	movups %xmm0,0x908(%r15)
  672f26:	00 
  672f27:	49 c7 87 18 09 00 00 	movq   $0x8,0x918(%r15)
  672f2e:	08 00 00 00 
  672f32:	41 0f 11 87 20 09 00 	movups %xmm0,0x920(%r15)
  672f39:	00 
  672f3a:	49 c7 87 30 09 00 00 	movq   $0x4,0x930(%r15)
  672f41:	04 00 00 00 
  672f45:	41 0f 11 87 38 09 00 	movups %xmm0,0x938(%r15)
  672f4c:	00 
  672f4d:	49 c7 87 48 09 00 00 	movq   $0x4,0x948(%r15)
  672f54:	04 00 00 00 
  672f58:	41 0f 11 87 50 09 00 	movups %xmm0,0x950(%r15)
  672f5f:	00 
  672f60:	49 c7 87 60 09 00 00 	movq   $0x4,0x960(%r15)
  672f67:	04 00 00 00 
  672f6b:	41 0f 11 87 68 09 00 	movups %xmm0,0x968(%r15)
  672f72:	00 
  672f73:	49 c7 87 78 09 00 00 	movq   $0x8,0x978(%r15)
  672f7a:	08 00 00 00 
  672f7e:	41 0f 11 87 80 09 00 	movups %xmm0,0x980(%r15)
  672f85:	00 
  672f86:	49 c7 87 90 09 00 00 	movq   $0x2,0x990(%r15)
  672f8d:	02 00 00 00 
  672f91:	41 0f 11 87 98 09 00 	movups %xmm0,0x998(%r15)
  672f98:	00 
  672f99:	49 c7 87 a8 09 00 00 	movq   $0x4,0x9a8(%r15)
  672fa0:	04 00 00 00 
  672fa4:	41 0f 11 87 b0 09 00 	movups %xmm0,0x9b0(%r15)
  672fab:	00 
  672fac:	49 c7 87 c0 09 00 00 	movq   $0x8,0x9c0(%r15)
  672fb3:	08 00 00 00 
  672fb7:	41 0f 11 87 c8 09 00 	movups %xmm0,0x9c8(%r15)
  672fbe:	00 
  672fbf:	49 c7 87 d8 09 00 00 	movq   $0x8,0x9d8(%r15)
  672fc6:	08 00 00 00 
  672fca:	41 0f 11 87 e0 09 00 	movups %xmm0,0x9e0(%r15)
  672fd1:	00 
  672fd2:	49 c7 87 f0 09 00 00 	movq   $0x8,0x9f0(%r15)
  672fd9:	08 00 00 00 
  672fdd:	41 0f 11 87 f8 09 00 	movups %xmm0,0x9f8(%r15)
  672fe4:	00 
  672fe5:	49 c7 87 08 0a 00 00 	movq   $0x4,0xa08(%r15)
  672fec:	04 00 00 00 
  672ff0:	41 0f 11 87 10 0a 00 	movups %xmm0,0xa10(%r15)
  672ff7:	00 
  672ff8:	41 c7 87 20 0a 00 00 	movl   $0x3f800000,0xa20(%r15)
  672fff:	00 00 80 3f 
  673003:	41 0f 11 87 24 0a 00 	movups %xmm0,0xa24(%r15)
  67300a:	00 
  67300b:	49 c7 87 32 0a 00 00 	movq   $0x0,0xa32(%r15)
  673012:	00 00 00 00 
  673016:	66 41 c7 87 3a 0a 00 	movw   $0xff01,0xa3a(%r15)
  67301d:	00 01 ff 
  673020:	41 c6 87 3c 0a 00 00 	movb   $0x0,0xa3c(%r15)
  673027:	00 
  673028:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  67302f:	00 
  673030:	48 8b 84 24 78 03 00 	mov    0x378(%rsp),%rax
  673037:	00 
  673038:	48 89 48 30          	mov    %rcx,0x30(%rax)
  67303c:	0f 10 84 24 b0 00 00 	movups 0xb0(%rsp),%xmm0
  673043:	00 
  673044:	0f 10 8c 24 c0 00 00 	movups 0xc0(%rsp),%xmm1
  67304b:	00 
  67304c:	0f 10 94 24 d0 00 00 	movups 0xd0(%rsp),%xmm2
  673053:	00 
  673054:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  673058:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  67305c:	0f 11 00             	movups %xmm0,(%rax)
  67305f:	48 81 c4 18 12 00 00 	add    $0x1218,%rsp
  673066:	5b                   	pop    %rbx
  673067:	41 5c                	pop    %r12
  673069:	41 5d                	pop    %r13
  67306b:	41 5e                	pop    %r14
  67306d:	41 5f                	pop    %r15
  67306f:	5d                   	pop    %rbp
  673070:	c3                   	ret
  673071:	48 8d 35 28 67 11 00 	lea    0x116728(%rip),%rsi        # 7897a0 <gpui_canvas::text::HEBREW_FONT>
  673078:	48 8d 15 d5 d3 9e ff 	lea    -0x612c2b(%rip),%rdx        # 60454 <gpui_canvas::text::HEBREW_BYTES>
  67307f:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  673086:	00 
  673087:	b9 14 69 00 00       	mov    $0x6914,%ecx
  67308c:	45 31 c0             	xor    %r8d,%r8d
  67308f:	e8 0c 09 ff ff       	call   6639a0 <<gpui_canvas::text::FontFace>::shared_static>
  673094:	80 bc 24 40 07 00 00 	cmpb   $0x0,0x740(%rsp)
  67309b:	00 
  67309c:	0f 85 f1 d3 ff ff    	jne    670493 <<gpui_canvas::text::planner::Planner>::shape+0x3f3>
  6730a2:	4d 8d be 50 0a 00 00 	lea    0xa50(%r14),%r15
  6730a9:	4c 8b a4 24 48 07 00 	mov    0x748(%rsp),%r12
  6730b0:	00 
  6730b1:	49 8b 07             	mov    (%r15),%rax
  6730b4:	48 85 c0             	test   %rax,%rax
  6730b7:	74 0f                	je     6730c8 <<gpui_canvas::text::planner::Planner>::shape+0x3028>
  6730b9:	f0 48 ff 08          	lock decq (%rax)
  6730bd:	75 09                	jne    6730c8 <<gpui_canvas::text::planner::Planner>::shape+0x3028>
  6730bf:	4c 89 ff             	mov    %r15,%rdi
  6730c2:	ff 15 c0 36 11 00    	call   *0x1136c0(%rip)        # 786788 <_DYNAMIC+0x260>
  6730c8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6730cd:	4c 89 a7 50 0a 00 00 	mov    %r12,0xa50(%rdi)
  6730d4:	be 02 00 00 00       	mov    $0x2,%esi
  6730d9:	e8 42 0c 00 00       	call   673d20 <<gpui_canvas::text::planner::Planner>::register>
  6730de:	83 f8 ff             	cmp    $0xffffffff,%eax
  6730e1:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
  6730e5:	0f 85 09 d4 ff ff    	jne    6704f4 <<gpui_canvas::text::planner::Planner>::shape+0x454>
  6730eb:	e9 43 d4 ff ff       	jmp    670533 <<gpui_canvas::text::planner::Planner>::shape+0x493>
  6730f0:	c7 84 24 b8 00 00 00 	movl   $0x3,0xb8(%rsp)
  6730f7:	03 00 00 00 
  6730fb:	e9 a9 fc ff ff       	jmp    672da9 <<gpui_canvas::text::planner::Planner>::shape+0x2d09>
  673100:	48 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%rsi
  673107:	00 
  673108:	48 85 f6             	test   %rsi,%rsi
  67310b:	74 17                	je     673124 <<gpui_canvas::text::planner::Planner>::shape+0x3084>
  67310d:	48 8b bc 24 f8 04 00 	mov    0x4f8(%rsp),%rdi
  673114:	00 
  673115:	48 c1 e6 03          	shl    $0x3,%rsi
  673119:	ba 08 00 00 00       	mov    $0x8,%edx
  67311e:	ff 15 3c 36 11 00    	call   *0x11363c(%rip)        # 786760 <_DYNAMIC+0x238>
  673124:	bb 01 00 00 00       	mov    $0x1,%ebx
  673129:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
  67312d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  673132:	74 43                	je     673177 <<gpui_canvas::text::planner::Planner>::shape+0x30d7>
  673134:	4d 85 f6             	test   %r14,%r14
  673137:	74 1a                	je     673153 <<gpui_canvas::text::planner::Planner>::shape+0x30b3>
  673139:	48 8b bc 24 80 02 00 	mov    0x280(%rsp),%rdi
  673140:	00 
  673141:	49 c1 e6 04          	shl    $0x4,%r14
  673145:	ba 04 00 00 00       	mov    $0x4,%edx
  67314a:	4c 89 f6             	mov    %r14,%rsi
  67314d:	ff 15 0d 36 11 00    	call   *0x11360d(%rip)        # 786760 <_DYNAMIC+0x238>
  673153:	48 8b b4 24 90 02 00 	mov    0x290(%rsp),%rsi
  67315a:	00 
  67315b:	48 85 f6             	test   %rsi,%rsi
  67315e:	74 17                	je     673177 <<gpui_canvas::text::planner::Planner>::shape+0x30d7>
  673160:	48 8b bc 24 98 02 00 	mov    0x298(%rsp),%rdi
  673167:	00 
  673168:	48 c1 e6 02          	shl    $0x2,%rsi
  67316c:	ba 04 00 00 00       	mov    $0x4,%edx
  673171:	ff 15 e9 35 11 00    	call   *0x1135e9(%rip)        # 786760 <_DYNAMIC+0x238>
  673177:	89 9c 24 b8 00 00 00 	mov    %ebx,0xb8(%rsp)
  67317e:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  673185:	00 ff ff ff ff 
  67318a:	e9 2b fc ff ff       	jmp    672dba <<gpui_canvas::text::planner::Planner>::shape+0x2d1a>
  67318f:	48 c7 84 24 b8 00 00 	movq   $0x3,0xb8(%rsp)
  673196:	00 03 00 00 00 
  67319b:	e9 09 fc ff ff       	jmp    672da9 <<gpui_canvas::text::planner::Planner>::shape+0x2d09>
  6731a0:	c7 84 24 b8 00 00 00 	movl   $0x1,0xb8(%rsp)
  6731a7:	01 00 00 00 
  6731ab:	e9 f9 fb ff ff       	jmp    672da9 <<gpui_canvas::text::planner::Planner>::shape+0x2d09>
  6731b0:	c7 84 24 b8 00 00 00 	movl   $0x3,0xb8(%rsp)
  6731b7:	03 00 00 00 
  6731bb:	8b 84 24 18 02 00 00 	mov    0x218(%rsp),%eax
  6731c2:	89 84 24 bc 00 00 00 	mov    %eax,0xbc(%rsp)
  6731c9:	e9 db fb ff ff       	jmp    672da9 <<gpui_canvas::text::planner::Planner>::shape+0x2d09>
  6731ce:	48 c7 84 24 b8 00 00 	movq   $0xc,0xb8(%rsp)
  6731d5:	00 0c 00 00 00 
  6731da:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  6731e1:	00 ff ff ff ff 
  6731e6:	49 89 f7             	mov    %rsi,%r15
  6731e9:	e9 cc fb ff ff       	jmp    672dba <<gpui_canvas::text::planner::Planner>::shape+0x2d1a>
  6731ee:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6731f5:	00 ff 
  6731f7:	0f 84 4d 01 00 00    	je     67334a <<gpui_canvas::text::planner::Planner>::shape+0x32aa>
  6731fd:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  673204:	00 
  673205:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  673209:	0f 84 3a 03 00 00    	je     673549 <<gpui_canvas::text::planner::Planner>::shape+0x34a9>
  67320f:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
  673216:	00 
  673217:	48 39 f0             	cmp    %rsi,%rax
  67321a:	0f 86 29 03 00 00    	jbe    673549 <<gpui_canvas::text::planner::Planner>::shape+0x34a9>
  673220:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
  673227:	00 
  673228:	e8 43 0d 00 00       	call   673f70 <<alloc::raw_vec::RawVecInner>::shrink>
  67322d:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  673231:	0f 84 12 03 00 00    	je     673549 <<gpui_canvas::text::planner::Planner>::shape+0x34a9>
  673237:	48 89 c7             	mov    %rax,%rdi
  67323a:	48 89 d6             	mov    %rdx,%rsi
  67323d:	ff 15 35 36 11 00    	call   *0x113635(%rip)        # 786878 <_DYNAMIC+0x350>
  673243:	e9 37 06 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  673248:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  67324d:	eb 26                	jmp    673275 <<gpui_canvas::text::planner::Planner>::shape+0x31d5>
  67324f:	c7 44 24 2c 00 00 00 	movl   $0x0,0x2c(%rsp)
  673256:	00 
  673257:	4c 8b 8c 24 38 03 00 	mov    0x338(%rsp),%r9
  67325e:	00 
  67325f:	4d 85 c9             	test   %r9,%r9
  673262:	74 24                	je     673288 <<gpui_canvas::text::planner::Planner>::shape+0x31e8>
  673264:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  673269:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  673270:	00 
  673271:	8b 54 24 2c          	mov    0x2c(%rsp),%edx
  673275:	49 39 c9             	cmp    %rcx,%r9
  673278:	73 24                	jae    67329e <<gpui_canvas::text::planner::Planner>::shape+0x31fe>
  67327a:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  67327f:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  673284:	7f 1d                	jg     6732a3 <<gpui_canvas::text::planner::Planner>::shape+0x3203>
  673286:	eb 4d                	jmp    6732d5 <<gpui_canvas::text::planner::Planner>::shape+0x3235>
  673288:	45 31 c9             	xor    %r9d,%r9d
  67328b:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  673290:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  673297:	00 
  673298:	8b 54 24 2c          	mov    0x2c(%rsp),%edx
  67329c:	eb 05                	jmp    6732a3 <<gpui_canvas::text::planner::Planner>::shape+0x3203>
  67329e:	49 89 c9             	mov    %rcx,%r9
  6732a1:	75 32                	jne    6732d5 <<gpui_canvas::text::planner::Planner>::shape+0x3235>
  6732a3:	84 d2                	test   %dl,%dl
  6732a5:	74 1a                	je     6732c1 <<gpui_canvas::text::planner::Planner>::shape+0x3221>
  6732a7:	4c 39 cd             	cmp    %r9,%rbp
  6732aa:	74 29                	je     6732d5 <<gpui_canvas::text::planner::Planner>::shape+0x3235>
  6732ac:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  6732b1:	43 0f b6 0c 08       	movzbl (%r8,%r9,1),%ecx
  6732b6:	84 c9                	test   %cl,%cl
  6732b8:	78 44                	js     6732fe <<gpui_canvas::text::planner::Planner>::shape+0x325e>
  6732ba:	b8 0b 00 00 00       	mov    $0xb,%eax
  6732bf:	eb 1e                	jmp    6732df <<gpui_canvas::text::planner::Planner>::shape+0x323f>
  6732c1:	48 39 cd             	cmp    %rcx,%rbp
  6732c4:	73 0d                	jae    6732d3 <<gpui_canvas::text::planner::Planner>::shape+0x3233>
  6732c6:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6732cb:	80 3c 28 bf          	cmpb   $0xbf,(%rax,%rbp,1)
  6732cf:	7f d6                	jg     6732a7 <<gpui_canvas::text::planner::Planner>::shape+0x3207>
  6732d1:	eb 02                	jmp    6732d5 <<gpui_canvas::text::planner::Planner>::shape+0x3235>
  6732d3:	74 d2                	je     6732a7 <<gpui_canvas::text::planner::Planner>::shape+0x3207>
  6732d5:	b8 03 00 00 00       	mov    $0x3,%eax
  6732da:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  6732df:	89 84 24 b8 00 00 00 	mov    %eax,0xb8(%rsp)
  6732e6:	89 8c 24 bc 00 00 00 	mov    %ecx,0xbc(%rsp)
  6732ed:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  6732f4:	00 ff ff ff ff 
  6732f9:	e9 bc fa ff ff       	jmp    672dba <<gpui_canvas::text::planner::Planner>::shape+0x2d1a>
  6732fe:	89 ca                	mov    %ecx,%edx
  673300:	83 e2 1f             	and    $0x1f,%edx
  673303:	43 0f b6 7c 08 01    	movzbl 0x1(%r8,%r9,1),%edi
  673309:	83 e7 3f             	and    $0x3f,%edi
  67330c:	b8 0b 00 00 00       	mov    $0xb,%eax
  673311:	80 f9 df             	cmp    $0xdf,%cl
  673314:	76 2b                	jbe    673341 <<gpui_canvas::text::planner::Planner>::shape+0x32a1>
  673316:	43 0f b6 74 08 02    	movzbl 0x2(%r8,%r9,1),%esi
  67331c:	c1 e7 06             	shl    $0x6,%edi
  67331f:	83 e6 3f             	and    $0x3f,%esi
  673322:	09 fe                	or     %edi,%esi
  673324:	80 f9 f0             	cmp    $0xf0,%cl
  673327:	72 7f                	jb     6733a8 <<gpui_canvas::text::planner::Planner>::shape+0x3308>
  673329:	43 0f b6 4c 08 03    	movzbl 0x3(%r8,%r9,1),%ecx
  67332f:	83 e2 07             	and    $0x7,%edx
  673332:	c1 e2 12             	shl    $0x12,%edx
  673335:	c1 e6 06             	shl    $0x6,%esi
  673338:	83 e1 3f             	and    $0x3f,%ecx
  67333b:	09 f1                	or     %esi,%ecx
  67333d:	09 d1                	or     %edx,%ecx
  67333f:	eb 9e                	jmp    6732df <<gpui_canvas::text::planner::Planner>::shape+0x323f>
  673341:	c1 e2 06             	shl    $0x6,%edx
  673344:	09 fa                	or     %edi,%edx
  673346:	89 d1                	mov    %edx,%ecx
  673348:	eb 95                	jmp    6732df <<gpui_canvas::text::planner::Planner>::shape+0x323f>
  67334a:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  673351:	00 
  673352:	48 85 c0             	test   %rax,%rax
  673355:	0f 84 a3 00 00 00    	je     6733fe <<gpui_canvas::text::planner::Planner>::shape+0x335e>
  67335b:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
  673362:	00 
  673363:	48 c1 e0 04          	shl    $0x4,%rax
  673367:	48 8b 54 24 58       	mov    0x58(%rsp),%rdx
  67336c:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  673370:	0f 83 bc 00 00 00    	jae    673432 <<gpui_canvas::text::planner::Planner>::shape+0x3392>
  673376:	c7 84 24 b8 00 00 00 	movl   $0x3,0xb8(%rsp)
  67337d:	03 00 00 00 
  673381:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  673388:	00 ff ff ff ff 
  67338d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  673392:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
  673399:	00 
  67339a:	48 85 f6             	test   %rsi,%rsi
  67339d:	0f 85 a8 fa ff ff    	jne    672e4b <<gpui_canvas::text::planner::Planner>::shape+0x2dab>
  6733a3:	e9 ba fa ff ff       	jmp    672e62 <<gpui_canvas::text::planner::Planner>::shape+0x2dc2>
  6733a8:	c1 e2 0c             	shl    $0xc,%edx
  6733ab:	09 d6                	or     %edx,%esi
  6733ad:	89 f1                	mov    %esi,%ecx
  6733af:	e9 2b ff ff ff       	jmp    6732df <<gpui_canvas::text::planner::Planner>::shape+0x323f>
  6733b4:	bb 03 00 00 00       	mov    $0x3,%ebx
  6733b9:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  6733be:	e9 b4 fd ff ff       	jmp    673177 <<gpui_canvas::text::planner::Planner>::shape+0x30d7>
  6733c3:	48 8d 3d 1e 81 be ff 	lea    -0x417ee2(%rip),%rdi        # 25b4e8 <anon.77df2256dbac5170b9422659b074405f.30.llvm.18408255876715279706>
  6733ca:	48 8d 15 97 8c 10 00 	lea    0x108c97(%rip),%rdx        # 77c068 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706>
  6733d1:	be ad 00 00 00       	mov    $0xad,%esi
  6733d6:	ff 15 7c 34 11 00    	call   *0x11347c(%rip)        # 786858 <_DYNAMIC+0x330>
  6733dc:	e9 9e 04 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  6733e1:	48 8d 0d 40 8e 10 00 	lea    0x108e40(%rip),%rcx        # 77c228 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x1c0>
  6733e8:	4c 89 ef             	mov    %r13,%rdi
  6733eb:	48 8b 94 24 40 01 00 	mov    0x140(%rsp),%rdx
  6733f2:	00 
  6733f3:	ff 15 cf 36 11 00    	call   *0x1136cf(%rip)        # 786ac8 <_DYNAMIC+0x5a0>
  6733f9:	e9 81 04 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  6733fe:	48 83 7c 24 58 00    	cmpq   $0x0,0x58(%rsp)
  673404:	75 38                	jne    67343e <<gpui_canvas::text::planner::Planner>::shape+0x339e>
  673406:	e9 3e 01 00 00       	jmp    673549 <<gpui_canvas::text::planner::Planner>::shape+0x34a9>
  67340b:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  673411:	8b 44 24 30          	mov    0x30(%rsp),%eax
  673415:	41 89 c7             	mov    %eax,%r15d
  673418:	e9 dd d0 ff ff       	jmp    6704fa <<gpui_canvas::text::planner::Planner>::shape+0x45a>
  67341d:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  673423:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
  67342a:	41 89 c7             	mov    %eax,%r15d
  67342d:	e9 c8 d0 ff ff       	jmp    6704fa <<gpui_canvas::text::planner::Planner>::shape+0x45a>
  673432:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  673438:	0f 86 bf 02 00 00    	jbe    6736fd <<gpui_canvas::text::planner::Planner>::shape+0x365d>
  67343e:	bf 04 00 00 00       	mov    $0x4,%edi
  673443:	be 18 00 00 00       	mov    $0x18,%esi
  673448:	e8 f3 0d 00 00       	call   674240 <alloc::boxed::box_new_uninit>
  67344d:	49 89 c7             	mov    %rax,%r15
  673450:	8b 84 24 30 01 00 00 	mov    0x130(%rsp),%eax
  673457:	41 c7 07 00 00 00 00 	movl   $0x0,(%r15)
  67345e:	4c 8b 74 24 58       	mov    0x58(%rsp),%r14
  673463:	45 89 77 04          	mov    %r14d,0x4(%r15)
  673467:	41 c7 47 08 00 00 00 	movl   $0x0,0x8(%r15)
  67346e:	00 
  67346f:	41 89 47 0c          	mov    %eax,0xc(%r15)
  673473:	41 c7 47 10 00 00 00 	movl   $0x0,0x10(%r15)
  67347a:	00 
  67347b:	66 41 c7 47 14 00 00 	movw   $0x0,0x14(%r15)
  673482:	bf 04 00 00 00       	mov    $0x4,%edi
  673487:	be 18 00 00 00       	mov    $0x18,%esi
  67348c:	e8 af 0d 00 00       	call   674240 <alloc::boxed::box_new_uninit>
  673491:	48 89 c3             	mov    %rax,%rbx
  673494:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  67349a:	44 89 70 04          	mov    %r14d,0x4(%rax)
  67349e:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  6734a5:	f3 0f 10 44 24 3c    	movss  0x3c(%rsp),%xmm0
  6734ab:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  6734b0:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  6734b7:	00 00 
  6734b9:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  6734be:	0f 28 84 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm0
  6734c5:	00 
  6734c6:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  6734cb:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6734d2:	00 ff 
  6734d4:	74 0d                	je     6734e3 <<gpui_canvas::text::planner::Planner>::shape+0x3443>
  6734d6:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  6734dd:	00 
  6734de:	e8 4d c1 ff ff       	call   66f630 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  6734e3:	48 c7 84 24 50 01 00 	movq   $0x1,0x150(%rsp)
  6734ea:	00 01 00 00 00 
  6734ef:	4c 89 bc 24 58 01 00 	mov    %r15,0x158(%rsp)
  6734f6:	00 
  6734f7:	48 c7 84 24 60 01 00 	movq   $0x1,0x160(%rsp)
  6734fe:	00 01 00 00 00 
  673503:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  67350a:	00 01 00 00 00 
  67350f:	48 89 9c 24 70 01 00 	mov    %rbx,0x170(%rsp)
  673516:	00 
  673517:	48 c7 84 24 78 01 00 	movq   $0x1,0x178(%rsp)
  67351e:	00 01 00 00 00 
  673523:	48 c7 84 24 80 01 00 	movq   $0xffffffffffffffff,0x180(%rsp)
  67352a:	00 ff ff ff ff 
  67352f:	44 89 b4 24 98 01 00 	mov    %r14d,0x198(%rsp)
  673536:	00 
  673537:	f3 0f 10 84 24 8c 00 	movss  0x8c(%rsp),%xmm0
  67353e:	00 00 
  673540:	f3 0f 11 84 24 9c 01 	movss  %xmm0,0x19c(%rsp)
  673547:	00 00 
  673549:	4c 8b bc 24 20 01 00 	mov    0x120(%rsp),%r15
  673550:	00 
  673551:	4c 8b a4 24 28 01 00 	mov    0x128(%rsp),%r12
  673558:	00 
  673559:	4c 8b b4 24 30 01 00 	mov    0x130(%rsp),%r14
  673560:	00 
  673561:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  673566:	48 8b b4 24 08 02 00 	mov    0x208(%rsp),%rsi
  67356d:	00 
  67356e:	e8 6d 06 00 00       	call   673be0 <<gpui_canvas::text::planner::Planner>::font_set>
  673573:	49 89 c5             	mov    %rax,%r13
  673576:	48 89 84 24 f0 04 00 	mov    %rax,0x4f0(%rsp)
  67357d:	00 
  67357e:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  673585:	00 
  673586:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  67358a:	0f 84 c3 00 00 00    	je     673653 <<gpui_canvas::text::planner::Planner>::shape+0x35b3>
  673590:	48 8d 94 24 58 01 00 	lea    0x158(%rsp),%rdx
  673597:	00 
  673598:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  67359c:	48 89 8c 24 98 07 00 	mov    %rcx,0x798(%rsp)
  6735a3:	00 
  6735a4:	0f 10 02             	movups (%rdx),%xmm0
  6735a7:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  6735ab:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  6735af:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  6735b3:	0f 11 9c 24 88 07 00 	movups %xmm3,0x788(%rsp)
  6735ba:	00 
  6735bb:	0f 11 94 24 78 07 00 	movups %xmm2,0x778(%rsp)
  6735c2:	00 
  6735c3:	0f 11 8c 24 68 07 00 	movups %xmm1,0x768(%rsp)
  6735ca:	00 
  6735cb:	0f 11 84 24 58 07 00 	movups %xmm0,0x758(%rsp)
  6735d2:	00 
  6735d3:	48 c7 84 24 40 07 00 	movq   $0x1,0x740(%rsp)
  6735da:	00 01 00 00 00 
  6735df:	48 c7 84 24 48 07 00 	movq   $0x1,0x748(%rsp)
  6735e6:	00 01 00 00 00 
  6735eb:	48 8d 9c 24 50 07 00 	lea    0x750(%rsp),%rbx
  6735f2:	00 
  6735f3:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  6735fa:	00 
  6735fb:	bf 08 00 00 00       	mov    $0x8,%edi
  673600:	be 60 00 00 00       	mov    $0x60,%esi
  673605:	e8 36 0c 00 00       	call   674240 <alloc::boxed::box_new_uninit>
  67360a:	0f 10 84 24 90 07 00 	movups 0x790(%rsp),%xmm0
  673611:	00 
  673612:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  673616:	0f 10 84 24 80 07 00 	movups 0x780(%rsp),%xmm0
  67361d:	00 
  67361e:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  673622:	0f 10 84 24 40 07 00 	movups 0x740(%rsp),%xmm0
  673629:	00 
  67362a:	0f 10 8c 24 50 07 00 	movups 0x750(%rsp),%xmm1
  673631:	00 
  673632:	0f 10 94 24 60 07 00 	movups 0x760(%rsp),%xmm2
  673639:	00 
  67363a:	0f 10 9c 24 70 07 00 	movups 0x770(%rsp),%xmm3
  673641:	00 
  673642:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  673646:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  67364a:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  67364e:	0f 11 00             	movups %xmm0,(%rax)
  673651:	eb 02                	jmp    673655 <<gpui_canvas::text::planner::Planner>::shape+0x35b5>
  673653:	31 c0                	xor    %eax,%eax
  673655:	4c 89 bc 24 b0 00 00 	mov    %r15,0xb0(%rsp)
  67365c:	00 
  67365d:	4c 89 a4 24 b8 00 00 	mov    %r12,0xb8(%rsp)
  673664:	00 
  673665:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
  67366c:	00 
  67366d:	4c 89 ac 24 c8 00 00 	mov    %r13,0xc8(%rsp)
  673674:	00 
  673675:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  67367c:	00 
  67367d:	0f 28 84 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm0
  673684:	00 
  673685:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  67368c:	00 00 
  67368e:	f3 0f 10 44 24 3c    	movss  0x3c(%rsp),%xmm0
  673694:	f3 0f 11 84 24 dc 00 	movss  %xmm0,0xdc(%rsp)
  67369b:	00 00 
  67369d:	f3 0f 10 84 24 84 00 	movss  0x84(%rsp),%xmm0
  6736a4:	00 00 
  6736a6:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  6736ad:	00 00 
  6736af:	f3 0f 10 84 24 8c 00 	movss  0x8c(%rsp),%xmm0
  6736b6:	00 00 
  6736b8:	f3 0f 11 84 24 e4 00 	movss  %xmm0,0xe4(%rsp)
  6736bf:	00 00 
  6736c1:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  6736c8:	00 
  6736c9:	e8 f2 a6 ff ff       	call   66ddc0 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  6736ce:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  6736d2:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  6736d7:	0f 85 4b f9 ff ff    	jne    673028 <<gpui_canvas::text::planner::Planner>::shape+0x2f88>
  6736dd:	e9 f2 f7 ff ff       	jmp    672ed4 <<gpui_canvas::text::planner::Planner>::shape+0x2e34>
  6736e2:	48 8d 0d af 8e 10 00 	lea    0x108eaf(%rip),%rcx        # 77c598 <anon.65c0d5535d99d532b50dfd321f8783c6.28.llvm.10908145274026468279>
  6736e9:	48 89 f7             	mov    %rsi,%rdi
  6736ec:	48 89 d6             	mov    %rdx,%rsi
  6736ef:	4c 89 c2             	mov    %r8,%rdx
  6736f2:	ff 15 d0 33 11 00    	call   *0x1133d0(%rip)        # 786ac8 <_DYNAMIC+0x5a0>
  6736f8:	e9 82 01 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  6736fd:	48 01 c1             	add    %rax,%rcx
  673700:	88 51 ff             	mov    %dl,-0x1(%rcx)
  673703:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  67370a:	00 ff 
  67370c:	0f 85 eb fa ff ff    	jne    6731fd <<gpui_canvas::text::planner::Planner>::shape+0x315d>
  673712:	e9 32 fe ff ff       	jmp    673549 <<gpui_canvas::text::planner::Planner>::shape+0x34a9>
  673717:	49 89 cd             	mov    %rcx,%r13
  67371a:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  673721:	00 
  673722:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  673729:	00 
  67372a:	48 8d 0d ff 8b 10 00 	lea    0x108bff(%rip),%rcx        # 77c330 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x2c8>
  673731:	e9 b2 fc ff ff       	jmp    6733e8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  673736:	49 89 d5             	mov    %rdx,%r13
  673739:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
  673740:	00 
  673741:	48 8d 0d b0 8a 10 00 	lea    0x108ab0(%rip),%rcx        # 77c1f8 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x190>
  673748:	e9 9b fc ff ff       	jmp    6733e8 <<gpui_canvas::text::planner::Planner>::shape+0x3348>
  67374d:	48 8d 0d 14 8e 10 00 	lea    0x108e14(%rip),%rcx        # 77c568 <anon.65c0d5535d99d532b50dfd321f8783c6.24.llvm.10908145274026468279>
  673754:	ff 15 6e 33 11 00    	call   *0x11336e(%rip)        # 786ac8 <_DYNAMIC+0x5a0>
  67375a:	e9 20 01 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  67375f:	48 8d 0d 02 8e 10 00 	lea    0x108e02(%rip),%rcx        # 77c568 <anon.65c0d5535d99d532b50dfd321f8783c6.24.llvm.10908145274026468279>
  673766:	ff 15 5c 33 11 00    	call   *0x11335c(%rip)        # 786ac8 <_DYNAMIC+0x5a0>
  67376c:	e9 0e 01 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  673771:	48 8d 3d 10 85 10 00 	lea    0x108510(%rip),%rdi        # 77bc88 <anon.d1c5e71728065e152e7afc2084c95a94.21.llvm.16205762496989061431>
  673778:	ff 15 e2 30 11 00    	call   *0x1130e2(%rip)        # 786860 <_DYNAMIC+0x338>
  67377e:	e9 fc 00 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  673783:	4c 8d 05 e6 8a 10 00 	lea    0x108ae6(%rip),%r8        # 77c270 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x208>
  67378a:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  673791:	00 
  673792:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  673797:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  67379c:	ff 15 fe 33 11 00    	call   *0x1133fe(%rip)        # 786ba0 <_DYNAMIC+0x678>
  6737a2:	e9 d8 00 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  6737a7:	48 8d 05 62 8a 10 00 	lea    0x108a62(%rip),%rax        # 77c210 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x1a8>
  6737ae:	eb 1f                	jmp    6737cf <<gpui_canvas::text::planner::Planner>::shape+0x372f>
  6737b0:	48 39 d3             	cmp    %rdx,%rbx
  6737b3:	48 0f 47 d3          	cmova  %rbx,%rdx
  6737b7:	48 8d 05 42 8c 10 00 	lea    0x108c42(%rip),%rax        # 77c400 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x398>
  6737be:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  6737c3:	48 89 d7             	mov    %rdx,%rdi
  6737c6:	eb 0c                	jmp    6737d4 <<gpui_canvas::text::planner::Planner>::shape+0x3734>
  6737c8:	48 8d 05 01 8b 10 00 	lea    0x108b01(%rip),%rax        # 77c2d0 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x268>
  6737cf:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  6737d4:	48 8b b4 24 d8 01 00 	mov    0x1d8(%rsp),%rsi
  6737db:	00 
  6737dc:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  6737e1:	ff 15 a1 30 11 00    	call   *0x1130a1(%rip)        # 786888 <_DYNAMIC+0x360>
  6737e7:	e9 93 00 00 00       	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  6737ec:	48 8d 0d 65 8e 10 00 	lea    0x108e65(%rip),%rcx        # 77c658 <anon.65c0d5535d99d532b50dfd321f8783c6.40.llvm.10908145274026468279>
  6737f3:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
  6737fa:	00 
  6737fb:	eb 04                	jmp    673801 <<gpui_canvas::text::planner::Planner>::shape+0x3761>
  6737fd:	31 ff                	xor    %edi,%edi
  6737ff:	31 c0                	xor    %eax,%eax
  673801:	48 89 c6             	mov    %rax,%rsi
  673804:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  67380b:	00 
  67380c:	ff 15 76 30 11 00    	call   *0x113076(%rip)        # 786888 <_DYNAMIC+0x360>
  673812:	eb 6b                	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  673814:	31 ff                	xor    %edi,%edi
  673816:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
  67381d:	00 00 00 00 00 
  673822:	eb b0                	jmp    6737d4 <<gpui_canvas::text::planner::Planner>::shape+0x3734>
  673824:	48 8d 15 c5 85 10 00 	lea    0x1085c5(%rip),%rdx        # 77bdf0 <anon.d1c5e71728065e152e7afc2084c95a94.38.llvm.16205762496989061431>
  67382b:	ff 15 57 30 11 00    	call   *0x113057(%rip)        # 786888 <_DYNAMIC+0x360>
  673831:	eb 4c                	jmp    67387f <<gpui_canvas::text::planner::Planner>::shape+0x37df>
  673833:	48 8d 05 ae 8b 10 00 	lea    0x108bae(%rip),%rax        # 77c3e8 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x380>
  67383a:	eb 93                	jmp    6737cf <<gpui_canvas::text::planner::Planner>::shape+0x372f>
  67383c:	48 89 d7             	mov    %rdx,%rdi
  67383f:	48 8d 05 d2 8b 10 00 	lea    0x108bd2(%rip),%rax        # 77c418 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x3b0>
  673846:	eb 87                	jmp    6737cf <<gpui_canvas::text::planner::Planner>::shape+0x372f>
  673848:	48 8d 05 69 8a 10 00 	lea    0x108a69(%rip),%rax        # 77c2b8 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x250>
  67384f:	e9 7b ff ff ff       	jmp    6737cf <<gpui_canvas::text::planner::Planner>::shape+0x372f>
  673854:	48 8d 05 8d 8a 10 00 	lea    0x108a8d(%rip),%rax        # 77c2e8 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x280>
  67385b:	e9 6f ff ff ff       	jmp    6737cf <<gpui_canvas::text::planner::Planner>::shape+0x372f>
  673860:	48 89 d7             	mov    %rdx,%rdi
  673863:	48 8d 05 96 8a 10 00 	lea    0x108a96(%rip),%rax        # 77c300 <anon.77df2256dbac5170b9422659b074405f.31.llvm.18408255876715279706+0x298>
  67386a:	e9 60 ff ff ff       	jmp    6737cf <<gpui_canvas::text::planner::Planner>::shape+0x372f>
  67386f:	48 8d 15 e2 8d 10 00 	lea    0x108de2(%rip),%rdx        # 77c658 <anon.65c0d5535d99d532b50dfd321f8783c6.40.llvm.10908145274026468279>
  673876:	48 89 c6             	mov    %rax,%rsi
  673879:	ff 15 09 30 11 00    	call   *0x113009(%rip)        # 786888 <_DYNAMIC+0x360>
  67387f:	0f 0b                	ud2
  673881:	49 89 c6             	mov    %rax,%r14
  673884:	be 18 00 00 00       	mov    $0x18,%esi
  673889:	ba 04 00 00 00       	mov    $0x4,%edx
  67388e:	4c 89 ff             	mov    %r15,%rdi
  673891:	ff 15 c9 2e 11 00    	call   *0x112ec9(%rip)        # 786760 <_DYNAMIC+0x238>
  673897:	e9 e3 02 00 00       	jmp    673b7f <<gpui_canvas::text::planner::Planner>::shape+0x3adf>
  67389c:	49 89 c6             	mov    %rax,%r14
  67389f:	48 89 df             	mov    %rbx,%rdi
  6738a2:	e8 89 bd ff ff       	call   66f630 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  6738a7:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  6738ac:	75 0e                	jne    6738bc <<gpui_canvas::text::planner::Planner>::shape+0x381c>
  6738ae:	48 8d bc 24 f0 04 00 	lea    0x4f0(%rsp),%rdi
  6738b5:	00 
  6738b6:	ff 15 bc 2e 11 00    	call   *0x112ebc(%rip)        # 786778 <_DYNAMIC+0x250>
  6738bc:	31 db                	xor    %ebx,%ebx
  6738be:	eb 0b                	jmp    6738cb <<gpui_canvas::text::planner::Planner>::shape+0x382b>
  6738c0:	ff 15 ba 2e 11 00    	call   *0x112eba(%rip)        # 786780 <_DYNAMIC+0x258>
  6738c6:	49 89 c6             	mov    %rax,%r14
  6738c9:	b3 01                	mov    $0x1,%bl
  6738cb:	4d 85 ff             	test   %r15,%r15
  6738ce:	74 15                	je     6738e5 <<gpui_canvas::text::planner::Planner>::shape+0x3845>
  6738d0:	49 c1 e7 04          	shl    $0x4,%r15
  6738d4:	ba 04 00 00 00       	mov    $0x4,%edx
  6738d9:	4c 89 e7             	mov    %r12,%rdi
  6738dc:	4c 89 fe             	mov    %r15,%rsi
  6738df:	ff 15 7b 2e 11 00    	call   *0x112e7b(%rip)        # 786760 <_DYNAMIC+0x238>
  6738e5:	84 db                	test   %bl,%bl
  6738e7:	0f 84 d8 02 00 00    	je     673bc5 <<gpui_canvas::text::planner::Planner>::shape+0x3b25>
  6738ed:	31 db                	xor    %ebx,%ebx
  6738ef:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  6738f6:	00 ff 
  6738f8:	0f 84 09 02 00 00    	je     673b07 <<gpui_canvas::text::planner::Planner>::shape+0x3a67>
  6738fe:	e9 8d 02 00 00       	jmp    673b90 <<gpui_canvas::text::planner::Planner>::shape+0x3af0>
  673903:	e9 30 02 00 00       	jmp    673b38 <<gpui_canvas::text::planner::Planner>::shape+0x3a98>
  673908:	e9 2b 02 00 00       	jmp    673b38 <<gpui_canvas::text::planner::Planner>::shape+0x3a98>
  67390d:	49 89 c6             	mov    %rax,%r14
  673910:	4d 89 27             	mov    %r12,(%r15)
  673913:	4c 89 f7             	mov    %r14,%rdi
  673916:	e8 45 6e 10 00       	call   77a760 <_Unwind_Resume@plt>
  67391b:	e9 18 02 00 00       	jmp    673b38 <<gpui_canvas::text::planner::Planner>::shape+0x3a98>
  673920:	e9 57 02 00 00       	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673925:	e9 52 02 00 00       	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  67392a:	e9 4d 02 00 00       	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  67392f:	e9 48 02 00 00       	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673934:	e9 43 02 00 00       	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673939:	e9 3e 02 00 00       	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  67393e:	e9 39 02 00 00       	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673943:	49 89 c6             	mov    %rax,%r14
  673946:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  67394d:	00 
  67394e:	e8 cd af 00 00       	call   67e920 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  673953:	e9 27 02 00 00       	jmp    673b7f <<gpui_canvas::text::planner::Planner>::shape+0x3adf>
  673958:	ff 15 22 2e 11 00    	call   *0x112e22(%rip)        # 786780 <_DYNAMIC+0x258>
  67395e:	49 89 c6             	mov    %rax,%r14
  673961:	48 8d bc 24 40 07 00 	lea    0x740(%rsp),%rdi
  673968:	00 
  673969:	e8 b2 af 00 00       	call   67e920 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  67396e:	e9 0c 02 00 00       	jmp    673b7f <<gpui_canvas::text::planner::Planner>::shape+0x3adf>
  673973:	ff 15 07 2e 11 00    	call   *0x112e07(%rip)        # 786780 <_DYNAMIC+0x258>
  673979:	49 89 c6             	mov    %rax,%r14
  67397c:	49 c7 87 c8 08 00 00 	movq   $0x0,0x8c8(%r15)
  673983:	00 00 00 00 
  673987:	49 c7 87 d0 08 00 00 	movq   $0x4,0x8d0(%r15)
  67398e:	04 00 00 00 
  673992:	0f 57 c0             	xorps  %xmm0,%xmm0
  673995:	41 0f 11 87 d8 08 00 	movups %xmm0,0x8d8(%r15)
  67399c:	00 
  67399d:	49 c7 87 e8 08 00 00 	movq   $0x4,0x8e8(%r15)
  6739a4:	04 00 00 00 
  6739a8:	41 0f 11 87 f0 08 00 	movups %xmm0,0x8f0(%r15)
  6739af:	00 
  6739b0:	49 c7 87 00 09 00 00 	movq   $0x8,0x900(%r15)
  6739b7:	08 00 00 00 
  6739bb:	41 0f 11 87 08 09 00 	movups %xmm0,0x908(%r15)
  6739c2:	00 
  6739c3:	49 c7 87 18 09 00 00 	movq   $0x8,0x918(%r15)
  6739ca:	08 00 00 00 
  6739ce:	41 0f 11 87 20 09 00 	movups %xmm0,0x920(%r15)
  6739d5:	00 
  6739d6:	49 c7 87 30 09 00 00 	movq   $0x4,0x930(%r15)
  6739dd:	04 00 00 00 
  6739e1:	41 0f 11 87 38 09 00 	movups %xmm0,0x938(%r15)
  6739e8:	00 
  6739e9:	49 c7 87 48 09 00 00 	movq   $0x4,0x948(%r15)
  6739f0:	04 00 00 00 
  6739f4:	41 0f 11 87 50 09 00 	movups %xmm0,0x950(%r15)
  6739fb:	00 
  6739fc:	49 c7 87 60 09 00 00 	movq   $0x4,0x960(%r15)
  673a03:	04 00 00 00 
  673a07:	41 0f 11 87 68 09 00 	movups %xmm0,0x968(%r15)
  673a0e:	00 
  673a0f:	49 c7 87 78 09 00 00 	movq   $0x8,0x978(%r15)
  673a16:	08 00 00 00 
  673a1a:	41 0f 11 87 80 09 00 	movups %xmm0,0x980(%r15)
  673a21:	00 
  673a22:	49 c7 87 90 09 00 00 	movq   $0x2,0x990(%r15)
  673a29:	02 00 00 00 
  673a2d:	41 0f 11 87 98 09 00 	movups %xmm0,0x998(%r15)
  673a34:	00 
  673a35:	49 c7 87 a8 09 00 00 	movq   $0x4,0x9a8(%r15)
  673a3c:	04 00 00 00 
  673a40:	41 0f 11 87 b0 09 00 	movups %xmm0,0x9b0(%r15)
  673a47:	00 
  673a48:	49 c7 87 c0 09 00 00 	movq   $0x8,0x9c0(%r15)
  673a4f:	08 00 00 00 
  673a53:	41 0f 11 87 c8 09 00 	movups %xmm0,0x9c8(%r15)
  673a5a:	00 
  673a5b:	49 c7 87 d8 09 00 00 	movq   $0x8,0x9d8(%r15)
  673a62:	08 00 00 00 
  673a66:	41 0f 11 87 e0 09 00 	movups %xmm0,0x9e0(%r15)
  673a6d:	00 
  673a6e:	49 c7 87 f0 09 00 00 	movq   $0x8,0x9f0(%r15)
  673a75:	08 00 00 00 
  673a79:	41 0f 11 87 f8 09 00 	movups %xmm0,0x9f8(%r15)
  673a80:	00 
  673a81:	49 c7 87 08 0a 00 00 	movq   $0x4,0xa08(%r15)
  673a88:	04 00 00 00 
  673a8c:	41 0f 11 87 10 0a 00 	movups %xmm0,0xa10(%r15)
  673a93:	00 
  673a94:	41 c7 87 20 0a 00 00 	movl   $0x3f800000,0xa20(%r15)
  673a9b:	00 00 80 3f 
  673a9f:	41 0f 11 87 24 0a 00 	movups %xmm0,0xa24(%r15)
  673aa6:	00 
  673aa7:	49 c7 87 32 0a 00 00 	movq   $0x0,0xa32(%r15)
  673aae:	00 00 00 00 
  673ab2:	66 41 c7 87 3a 0a 00 	movw   $0xff01,0xa3a(%r15)
  673ab9:	00 01 ff 
  673abc:	41 c6 87 3c 0a 00 00 	movb   $0x0,0xa3c(%r15)
  673ac3:	00 
  673ac4:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  673acb:	00 
  673acc:	e8 4f a4 ff ff       	call   66df20 <core::ptr::drop_glue::<core::result::Result<gpui_canvas::text::TextLayout, gpui_canvas::Error>>>
  673ad1:	4c 89 f7             	mov    %r14,%rdi
  673ad4:	e8 87 6c 10 00       	call   77a760 <_Unwind_Resume@plt>
  673ad9:	ff 15 a1 2c 11 00    	call   *0x112ca1(%rip)        # 786780 <_DYNAMIC+0x258>
  673adf:	eb 57                	jmp    673b38 <<gpui_canvas::text::planner::Planner>::shape+0x3a98>
  673ae1:	e9 96 00 00 00       	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673ae6:	49 89 c6             	mov    %rax,%r14
  673ae9:	48 8b b4 24 40 07 00 	mov    0x740(%rsp),%rsi
  673af0:	00 
  673af1:	b3 01                	mov    $0x1,%bl
  673af3:	48 85 f6             	test   %rsi,%rsi
  673af6:	75 1c                	jne    673b14 <<gpui_canvas::text::planner::Planner>::shape+0x3a74>
  673af8:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  673aff:	00 ff 
  673b01:	0f 85 89 00 00 00    	jne    673b90 <<gpui_canvas::text::planner::Planner>::shape+0x3af0>
  673b07:	84 db                	test   %bl,%bl
  673b09:	0f 85 92 00 00 00    	jne    673ba1 <<gpui_canvas::text::planner::Planner>::shape+0x3b01>
  673b0f:	e9 b1 00 00 00       	jmp    673bc5 <<gpui_canvas::text::planner::Planner>::shape+0x3b25>
  673b14:	48 8b bc 24 48 07 00 	mov    0x748(%rsp),%rdi
  673b1b:	00 
  673b1c:	48 c1 e6 03          	shl    $0x3,%rsi
  673b20:	ba 08 00 00 00       	mov    $0x8,%edx
  673b25:	ff 15 35 2c 11 00    	call   *0x112c35(%rip)        # 786760 <_DYNAMIC+0x238>
  673b2b:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  673b32:	00 ff 
  673b34:	74 d1                	je     673b07 <<gpui_canvas::text::planner::Planner>::shape+0x3a67>
  673b36:	eb 58                	jmp    673b90 <<gpui_canvas::text::planner::Planner>::shape+0x3af0>
  673b38:	49 89 c6             	mov    %rax,%r14
  673b3b:	48 8b b4 24 f0 04 00 	mov    0x4f0(%rsp),%rsi
  673b42:	00 
  673b43:	48 85 f6             	test   %rsi,%rsi
  673b46:	74 17                	je     673b5f <<gpui_canvas::text::planner::Planner>::shape+0x3abf>
  673b48:	48 8b bc 24 f8 04 00 	mov    0x4f8(%rsp),%rdi
  673b4f:	00 
  673b50:	48 c1 e6 03          	shl    $0x3,%rsi
  673b54:	ba 08 00 00 00       	mov    $0x8,%edx
  673b59:	ff 15 01 2c 11 00    	call   *0x112c01(%rip)        # 786760 <_DYNAMIC+0x238>
  673b5f:	48 8d bc 24 78 02 00 	lea    0x278(%rsp),%rdi
  673b66:	00 
  673b67:	e8 b4 a2 ff ff       	call   66de20 <core::ptr::drop_glue::<core::option::Option<parley::editing::geometry::CursorGeometry<()>>>>
  673b6c:	eb 11                	jmp    673b7f <<gpui_canvas::text::planner::Planner>::shape+0x3adf>
  673b6e:	eb 0c                	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673b70:	eb 0a                	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673b72:	eb 08                	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673b74:	eb 06                	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673b76:	eb 04                	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673b78:	eb 02                	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673b7a:	eb 00                	jmp    673b7c <<gpui_canvas::text::planner::Planner>::shape+0x3adc>
  673b7c:	49 89 c6             	mov    %rax,%r14
  673b7f:	b3 01                	mov    $0x1,%bl
  673b81:	48 83 bc 24 50 01 00 	cmpq   $0xffffffffffffffff,0x150(%rsp)
  673b88:	00 ff 
  673b8a:	0f 84 77 ff ff ff    	je     673b07 <<gpui_canvas::text::planner::Planner>::shape+0x3a67>
  673b90:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  673b97:	00 
  673b98:	e8 93 ba ff ff       	call   66f630 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  673b9d:	84 db                	test   %bl,%bl
  673b9f:	74 24                	je     673bc5 <<gpui_canvas::text::planner::Planner>::shape+0x3b25>
  673ba1:	48 8b b4 24 20 01 00 	mov    0x120(%rsp),%rsi
  673ba8:	00 
  673ba9:	48 85 f6             	test   %rsi,%rsi
  673bac:	74 17                	je     673bc5 <<gpui_canvas::text::planner::Planner>::shape+0x3b25>
  673bae:	48 8b bc 24 28 01 00 	mov    0x128(%rsp),%rdi
  673bb5:	00 
  673bb6:	48 c1 e6 04          	shl    $0x4,%rsi
  673bba:	ba 04 00 00 00       	mov    $0x4,%edx
  673bbf:	ff 15 9b 2b 11 00    	call   *0x112b9b(%rip)        # 786760 <_DYNAMIC+0x238>
  673bc5:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  673bcc:	00 
  673bcd:	e8 ee a1 ff ff       	call   66ddc0 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  673bd2:	4c 89 f7             	mov    %r14,%rdi
  673bd5:	e8 86 6b 10 00       	call   77a760 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
