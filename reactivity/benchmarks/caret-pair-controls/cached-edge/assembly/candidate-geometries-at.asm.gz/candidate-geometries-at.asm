
/tmp/gpui-caret-pair-controls-v3/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000669340 <<parley::editing::geometry::CursorGeometry<()>>::geometries_at>:
  669340:	55                   	push   %rbp
  669341:	41 57                	push   %r15
  669343:	41 56                	push   %r14
  669345:	41 55                	push   %r13
  669347:	41 54                	push   %r12
  669349:	53                   	push   %rbx
  66934a:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
  669351:	48 89 fb             	mov    %rdi,%rbx
  669354:	f3 0f 11 44 24 14    	movss  %xmm0,0x14(%rsp)
  66935a:	48 85 d2             	test   %rdx,%rdx
  66935d:	0f 84 97 01 00 00    	je     6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  669363:	48 8b 46 28          	mov    0x28(%rsi),%rax
  669367:	48 8d 4a ff          	lea    -0x1(%rdx),%rcx
  66936b:	48 39 c1             	cmp    %rax,%rcx
  66936e:	0f 83 86 01 00 00    	jae    6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  669374:	48 39 c2             	cmp    %rax,%rdx
  669377:	0f 83 7d 01 00 00    	jae    6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  66937d:	48 8b 46 20          	mov    0x20(%rsi),%rax
  669381:	44 8b 6c 90 fc       	mov    -0x4(%rax,%rdx,4),%r13d
  669386:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  66938a:	4c 39 e9             	cmp    %r13,%rcx
  66938d:	0f 86 67 01 00 00    	jbe    6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  669393:	8b 2c 90             	mov    (%rax,%rdx,4),%ebp
  669396:	48 39 e9             	cmp    %rbp,%rcx
  669399:	0f 86 5b 01 00 00    	jbe    6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  66939f:	4c 8b 7e 08          	mov    0x8(%rsi),%r15
  6693a3:	4d 89 ec             	mov    %r13,%r12
  6693a6:	49 c1 e4 04          	shl    $0x4,%r12
  6693aa:	4d 01 fc             	add    %r15,%r12
  6693ad:	48 89 e8             	mov    %rbp,%rax
  6693b0:	48 c1 e0 04          	shl    $0x4,%rax
  6693b4:	41 8b 0c 24          	mov    (%r12),%ecx
  6693b8:	41 3b 0c 07          	cmp    (%r15,%rax,1),%ecx
  6693bc:	0f 85 38 01 00 00    	jne    6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  6693c2:	49 01 c7             	add    %rax,%r15
  6693c5:	41 8b 44 24 04       	mov    0x4(%r12),%eax
  6693ca:	41 3b 47 04          	cmp    0x4(%r15),%eax
  6693ce:	0f 85 26 01 00 00    	jne    6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  6693d4:	48 8b 7e 30          	mov    0x30(%rsi),%rdi
  6693d8:	48 39 8f 18 01 00 00 	cmp    %rcx,0x118(%rdi)
  6693df:	0f 86 15 01 00 00    	jbe    6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  6693e5:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  6693eb:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  6693f0:	49 89 d6             	mov    %rdx,%r14
  6693f3:	48 6b d1 70          	imul   $0x70,%rcx,%rdx
  6693f7:	48 03 97 10 01 00 00 	add    0x110(%rdi),%rdx
  6693fe:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
  669403:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  669408:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  66940c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  669411:	48 8d 74 24 68       	lea    0x68(%rsp),%rsi
  669416:	48 89 c2             	mov    %rax,%rdx
  669419:	e8 72 fe ff ff       	call   669290 <<parley::layout::line::Line<()>>::item>
  66941e:	83 7c 24 20 01       	cmpl   $0x1,0x20(%rsp)
  669423:	0f 85 c3 00 00 00    	jne    6694ec <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ac>
  669429:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
  66942f:	4c 89 f2             	mov    %r14,%rdx
  669432:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  669437:	f3 0f 10 44 24 10    	movss  0x10(%rsp),%xmm0
  66943d:	0f 84 b7 00 00 00    	je     6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  669443:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  669448:	0f b6 80 8c 00 00 00 	movzbl 0x8c(%rax),%eax
  66944f:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
  669453:	31 ff                	xor    %edi,%edi
  669455:	4c 39 e9             	cmp    %r13,%rcx
  669458:	40 0f 94 c7          	sete   %dil
  66945c:	49 ff c5             	inc    %r13
  66945f:	31 c9                	xor    %ecx,%ecx
  669461:	49 39 ed             	cmp    %rbp,%r13
  669464:	0f 94 c1             	sete   %cl
  669467:	24 01                	and    $0x1,%al
  669469:	88 44 24 0f          	mov    %al,0xf(%rsp)
  66946d:	0f 44 f9             	cmove  %ecx,%edi
  669470:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
  669475:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66947a:	48 8d 44 24 14       	lea    0x14(%rsp),%rax
  66947f:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  669484:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  669489:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  66948e:	4c 89 64 24 38       	mov    %r12,0x38(%rsp)
  669493:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
  669498:	40 84 ff             	test   %dil,%dil
  66949b:	74 5d                	je     6694fa <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1ba>
  66949d:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  6694a4:	00 
  6694a5:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  6694aa:	e8 61 fd ff ff       	call   669210 <<parley::editing::geometry::CursorGeometry<()>>::shared_edge::{closure#0}>
  6694af:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  6694b6:	00 
  6694b7:	0f 10 8c 24 98 00 00 	movups 0x98(%rsp),%xmm1
  6694be:	00 
  6694bf:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  6694c4:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  6694c9:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  6694ce:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  6694d3:	0f 11 4b 38          	movups %xmm1,0x38(%rbx)
  6694d7:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6694db:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6694df:	0f 11 43 28          	movups %xmm0,0x28(%rbx)
  6694e3:	48 c7 03 01 00 00 00 	movq   $0x1,(%rbx)
  6694ea:	eb 17                	jmp    669503 <<parley::editing::geometry::CursorGeometry<()>>::geometries_at+0x1c3>
  6694ec:	4c 89 f2             	mov    %r14,%rdx
  6694ef:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6694f4:	f3 0f 10 44 24 10    	movss  0x10(%rsp),%xmm0
  6694fa:	48 89 df             	mov    %rbx,%rdi
  6694fd:	ff 15 8d da 11 00    	call   *0x11da8d(%rip)        # 786f90 <_DYNAMIC+0x3d8>
  669503:	48 89 d8             	mov    %rbx,%rax
  669506:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
  66950d:	5b                   	pop    %rbx
  66950e:	41 5c                	pop    %r12
  669510:	41 5d                	pop    %r13
  669512:	41 5e                	pop    %r14
  669514:	41 5f                	pop    %r15
  669516:	5d                   	pop    %rbp
  669517:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
