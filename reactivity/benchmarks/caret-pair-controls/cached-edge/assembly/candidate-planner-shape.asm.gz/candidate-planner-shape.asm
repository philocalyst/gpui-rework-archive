
/tmp/gpui-caret-pair-controls-v3/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000067e0e0 <<gpui_canvas::text::planner::Planner>::shape>:
  67e0e0:	55                   	push   %rbp
  67e0e1:	41 57                	push   %r15
  67e0e3:	41 56                	push   %r14
  67e0e5:	41 55                	push   %r13
  67e0e7:	41 54                	push   %r12
  67e0e9:	53                   	push   %rbx
  67e0ea:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  67e0f1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  67e0f8:	00 
  67e0f9:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
  67e100:	44 89 8c 24 2c 02 00 	mov    %r9d,0x22c(%rsp)
  67e107:	00 
  67e108:	f3 0f 11 8c 24 bc 01 	movss  %xmm1,0x1bc(%rsp)
  67e10f:	00 00 
  67e111:	44 89 84 24 b8 01 00 	mov    %r8d,0x1b8(%rsp)
  67e118:	00 
  67e119:	f3 0f 11 44 24 7c    	movss  %xmm0,0x7c(%rsp)
  67e11f:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  67e124:	49 89 f5             	mov    %rsi,%r13
  67e127:	48 89 bc 24 c8 03 00 	mov    %rdi,0x3c8(%rsp)
  67e12e:	00 
  67e12f:	48 8d 04 0a          	lea    (%rdx,%rcx,1),%rax
  67e133:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  67e13a:	00 
  67e13b:	48 85 c9             	test   %rcx,%rcx
  67e13e:	48 89 34 24          	mov    %rsi,(%rsp)
  67e142:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
  67e149:	00 
  67e14a:	0f 84 8a 03 00 00    	je     67e4da <<gpui_canvas::text::planner::Planner>::shape+0x3fa>
  67e150:	49 8d 85 78 0a 00 00 	lea    0xa78(%r13),%rax
  67e157:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  67e15c:	4c 8d a4 24 dc 0c 00 	lea    0xcdc(%rsp),%r12
  67e163:	00 
  67e164:	49 8d 45 38          	lea    0x38(%r13),%rax
  67e168:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  67e16d:	49 8d 45 3c          	lea    0x3c(%r13),%rax
  67e171:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  67e176:	49 8d 45 58          	lea    0x58(%r13),%rax
  67e17a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  67e17f:	49 8d 45 5c          	lea    0x5c(%r13),%rax
  67e183:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  67e18a:	00 
  67e18b:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  67e192:	00 
  67e193:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
  67e19a:	00 
  67e19b:	4c 8b 05 b6 92 10 00 	mov    0x1092b6(%rip),%r8        # 787458 <_DYNAMIC+0x8a0>
  67e1a2:	49 89 d6             	mov    %rdx,%r14
  67e1a5:	eb 27                	jmp    67e1ce <<gpui_canvas::text::planner::Planner>::shape+0xee>
  67e1a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  67e1ae:	00 00 
  67e1b0:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  67e1b7:	83 f8 02             	cmp    $0x2,%eax
  67e1ba:	0f 83 e1 00 00 00    	jae    67e2a1 <<gpui_canvas::text::planner::Planner>::shape+0x1c1>
  67e1c0:	4c 3b b4 24 a0 01 00 	cmp    0x1a0(%rsp),%r14
  67e1c7:	00 
  67e1c8:	0f 84 ae 02 00 00    	je     67e47c <<gpui_canvas::text::planner::Planner>::shape+0x39c>
  67e1ce:	45 0f b6 3e          	movzbl (%r14),%r15d
  67e1d2:	45 84 ff             	test   %r15b,%r15b
  67e1d5:	78 19                	js     67e1f0 <<gpui_canvas::text::planner::Planner>::shape+0x110>
  67e1d7:	49 ff c6             	inc    %r14
  67e1da:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67e1e1:	0f 8e 99 00 00 00    	jle    67e280 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  67e1e7:	eb c7                	jmp    67e1b0 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  67e1e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  67e1f0:	44 89 f8             	mov    %r15d,%eax
  67e1f3:	83 e0 1f             	and    $0x1f,%eax
  67e1f6:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  67e1fb:	83 e2 3f             	and    $0x3f,%edx
  67e1fe:	41 80 ff df          	cmp    $0xdf,%r15b
  67e202:	76 3d                	jbe    67e241 <<gpui_canvas::text::planner::Planner>::shape+0x161>
  67e204:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  67e209:	c1 e2 06             	shl    $0x6,%edx
  67e20c:	83 e1 3f             	and    $0x3f,%ecx
  67e20f:	09 d1                	or     %edx,%ecx
  67e211:	41 80 ff f0          	cmp    $0xf0,%r15b
  67e215:	72 44                	jb     67e25b <<gpui_canvas::text::planner::Planner>::shape+0x17b>
  67e217:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  67e21c:	49 83 c6 04          	add    $0x4,%r14
  67e220:	83 e0 07             	and    $0x7,%eax
  67e223:	c1 e0 12             	shl    $0x12,%eax
  67e226:	c1 e1 06             	shl    $0x6,%ecx
  67e229:	41 83 e7 3f          	and    $0x3f,%r15d
  67e22d:	41 09 cf             	or     %ecx,%r15d
  67e230:	41 09 c7             	or     %eax,%r15d
  67e233:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67e23a:	7e 44                	jle    67e280 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  67e23c:	e9 6f ff ff ff       	jmp    67e1b0 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  67e241:	49 83 c6 02          	add    $0x2,%r14
  67e245:	c1 e0 06             	shl    $0x6,%eax
  67e248:	09 d0                	or     %edx,%eax
  67e24a:	41 89 c7             	mov    %eax,%r15d
  67e24d:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67e254:	7e 2a                	jle    67e280 <<gpui_canvas::text::planner::Planner>::shape+0x1a0>
  67e256:	e9 55 ff ff ff       	jmp    67e1b0 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  67e25b:	49 83 c6 03          	add    $0x3,%r14
  67e25f:	c1 e0 0c             	shl    $0xc,%eax
  67e262:	09 c1                	or     %eax,%ecx
  67e264:	41 89 cf             	mov    %ecx,%r15d
  67e267:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  67e26e:	0f 8f 3c ff ff ff    	jg     67e1b0 <<gpui_canvas::text::planner::Planner>::shape+0xd0>
  67e274:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  67e27b:	00 00 00 00 00 
  67e280:	41 83 ff 0a          	cmp    $0xa,%r15d
  67e284:	0f 84 36 ff ff ff    	je     67e1c0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67e28a:	41 83 ff 0d          	cmp    $0xd,%r15d
  67e28e:	0f 84 2c ff ff ff    	je     67e1c0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67e294:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  67e29b:	0f 84 1f ff ff ff    	je     67e1c0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67e2a1:	49 89 f5             	mov    %rsi,%r13
  67e2a4:	48 8d 3d fd ed 0f 00 	lea    0xfedfd(%rip),%rdi        # 77d0a8 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x38>
  67e2ab:	44 89 fe             	mov    %r15d,%esi
  67e2ae:	4c 89 c3             	mov    %r8,%rbx
  67e2b1:	ff 15 31 92 10 00    	call   *0x109231(%rip)        # 7874e8 <_DYNAMIC+0x930>
  67e2b7:	49 89 d8             	mov    %rbx,%r8
  67e2ba:	4c 89 ee             	mov    %r13,%rsi
  67e2bd:	84 c0                	test   %al,%al
  67e2bf:	0f 85 fb fe ff ff    	jne    67e1c0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67e2c5:	4c 89 e5             	mov    %r12,%rbp
  67e2c8:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  67e2ce:	41 83 ff 20          	cmp    $0x20,%r15d
  67e2d2:	0f 82 52 02 00 00    	jb     67e52a <<gpui_canvas::text::planner::Planner>::shape+0x44a>
  67e2d8:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  67e2dc:	83 f8 21             	cmp    $0x21,%eax
  67e2df:	0f 82 45 02 00 00    	jb     67e52a <<gpui_canvas::text::planner::Planner>::shape+0x44a>
  67e2e5:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  67e2ea:	44 89 fe             	mov    %r15d,%esi
  67e2ed:	e8 9e 3b 00 00       	call   681e90 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  67e2f2:	49 89 d8             	mov    %rbx,%r8
  67e2f5:	4c 89 ee             	mov    %r13,%rsi
  67e2f8:	a8 01                	test   $0x1,%al
  67e2fa:	74 0c                	je     67e308 <<gpui_canvas::text::planner::Planner>::shape+0x228>
  67e2fc:	49 89 ec             	mov    %rbp,%r12
  67e2ff:	66 85 d2             	test   %dx,%dx
  67e302:	0f 85 b8 fe ff ff    	jne    67e1c0 <<gpui_canvas::text::planner::Planner>::shape+0xe0>
  67e308:	48 8b 0c 24          	mov    (%rsp),%rcx
  67e30c:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  67e313:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  67e319:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  67e31d:	0f 85 07 02 00 00    	jne    67e52a <<gpui_canvas::text::planner::Planner>::shape+0x44a>
  67e323:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  67e328:	0f 85 f3 00 00 00    	jne    67e421 <<gpui_canvas::text::planner::Planner>::shape+0x341>
  67e32e:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  67e333:	48 89 f7             	mov    %rsi,%rdi
  67e336:	48 8d 35 79 7d 9a ff 	lea    -0x658287(%rip),%rsi        # 260b6 <gpui_canvas::text::ARABIC_BYTES>
  67e33d:	31 c9                	xor    %ecx,%ecx
  67e33f:	41 ff d0             	call   *%r8
  67e342:	83 bc 24 00 07 00 00 	cmpl   $0xffffffff,0x700(%rsp)
  67e349:	ff 
  67e34a:	0f 84 ed 31 00 00    	je     68153d <<gpui_canvas::text::planner::Planner>::shape+0x345d>
  67e350:	8b 84 24 d8 0c 00 00 	mov    0xcd8(%rsp),%eax
  67e357:	89 84 24 80 00 00 00 	mov    %eax,0x80(%rsp)
  67e35e:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
  67e362:	0f 10 4d 0c          	movups 0xc(%rbp),%xmm1
  67e366:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
  67e36d:	00 
  67e36e:	0f 11 8c 24 bc 04 00 	movups %xmm1,0x4bc(%rsp)
  67e375:	00 
  67e376:	ba 14 69 00 00       	mov    $0x6914,%edx
  67e37b:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  67e382:	00 
  67e383:	48 8d 35 74 28 9e ff 	lea    -0x61d78c(%rip),%rsi        # 60bfe <gpui_canvas::text::HEBREW_BYTES>
  67e38a:	31 c9                	xor    %ecx,%ecx
  67e38c:	ff 15 c6 90 10 00    	call   *0x1090c6(%rip)        # 787458 <_DYNAMIC+0x8a0>
  67e392:	83 bc 24 00 07 00 00 	cmpl   $0xffffffff,0x700(%rsp)
  67e399:	ff 
  67e39a:	0f 84 b2 31 00 00    	je     681552 <<gpui_canvas::text::planner::Planner>::shape+0x3472>
  67e3a0:	8b 94 24 d8 0c 00 00 	mov    0xcd8(%rsp),%edx
  67e3a7:	48 8d 84 24 dc 0c 00 	lea    0xcdc(%rsp),%rax
  67e3ae:	00 
  67e3af:	0f 10 00             	movups (%rax),%xmm0
  67e3b2:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  67e3b6:	0f 29 84 24 a0 02 00 	movaps %xmm0,0x2a0(%rsp)
  67e3bd:	00 
  67e3be:	0f 11 8c 24 ac 02 00 	movups %xmm1,0x2ac(%rsp)
  67e3c5:	00 
  67e3c6:	48 8b 04 24          	mov    (%rsp),%rax
  67e3ca:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  67e3d1:	00 
  67e3d2:	8b 8c 24 80 00 00 00 	mov    0x80(%rsp),%ecx
  67e3d9:	89 48 38             	mov    %ecx,0x38(%rax)
  67e3dc:	0f 10 84 24 bc 04 00 	movups 0x4bc(%rsp),%xmm0
  67e3e3:	00 
  67e3e4:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  67e3e9:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  67e3ed:	0f 28 84 24 b0 04 00 	movaps 0x4b0(%rsp),%xmm0
  67e3f4:	00 
  67e3f5:	0f 11 01             	movups %xmm0,(%rcx)
  67e3f8:	89 94 24 00 01 00 00 	mov    %edx,0x100(%rsp)
  67e3ff:	89 50 58             	mov    %edx,0x58(%rax)
  67e402:	0f 10 84 24 ac 02 00 	movups 0x2ac(%rsp),%xmm0
  67e409:	00 
  67e40a:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  67e411:	00 
  67e412:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  67e416:	0f 28 84 24 a0 02 00 	movaps 0x2a0(%rsp),%xmm0
  67e41d:	00 
  67e41e:	0f 11 00             	movups %xmm0,(%rax)
  67e421:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  67e426:	44 89 fe             	mov    %r15d,%esi
  67e429:	e8 62 3a 00 00       	call   681e90 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  67e42e:	66 85 d2             	test   %dx,%dx
  67e431:	0f 95 c1             	setne  %cl
  67e434:	20 c1                	and    %al,%cl
  67e436:	88 4c 24 10          	mov    %cl,0x10(%rsp)
  67e43a:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  67e43f:	44 89 fe             	mov    %r15d,%esi
  67e442:	e8 49 3a 00 00       	call   681e90 <<gpui_canvas::text::planner::Cmap>::glyph_index>
  67e447:	66 85 d2             	test   %dx,%dx
  67e44a:	0f 95 c1             	setne  %cl
  67e44d:	20 c1                	and    %al,%cl
  67e44f:	00 c9                	add    %cl,%cl
  67e451:	0a 4c 24 10          	or     0x10(%rsp),%cl
  67e455:	0f 84 cf 00 00 00    	je     67e52a <<gpui_canvas::text::planner::Planner>::shape+0x44a>
  67e45b:	8b 44 24 18          	mov    0x18(%rsp),%eax
  67e45f:	08 c8                	or     %cl,%al
  67e461:	89 44 24 18          	mov    %eax,0x18(%rsp)
  67e465:	4c 3b b4 24 a0 01 00 	cmp    0x1a0(%rsp),%r14
  67e46c:	00 
  67e46d:	49 89 ec             	mov    %rbp,%r12
  67e470:	4c 89 ee             	mov    %r13,%rsi
  67e473:	49 89 d8             	mov    %rbx,%r8
  67e476:	0f 85 52 fd ff ff    	jne    67e1ce <<gpui_canvas::text::planner::Planner>::shape+0xee>
  67e47c:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
  67e480:	f6 c1 01             	test   $0x1,%cl
  67e483:	4c 8b 2c 24          	mov    (%rsp),%r13
  67e487:	0f 84 c2 00 00 00    	je     67e54f <<gpui_canvas::text::planner::Planner>::shape+0x46f>
  67e48d:	49 83 bd 48 0a 00 00 	cmpq   $0x0,0xa48(%r13)
  67e494:	00 
  67e495:	0f 85 b4 00 00 00    	jne    67e54f <<gpui_canvas::text::planner::Planner>::shape+0x46f>
  67e49b:	48 8d 35 86 b9 10 00 	lea    0x10b986(%rip),%rsi        # 789e28 <gpui_canvas::text::ARABIC_FONT>
  67e4a2:	48 8d 15 0d 7c 9a ff 	lea    -0x6583f3(%rip),%rdx        # 260b6 <gpui_canvas::text::ARABIC_BYTES>
  67e4a9:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  67e4b0:	00 
  67e4b1:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  67e4b6:	45 31 c0             	xor    %r8d,%r8d
  67e4b9:	e8 02 c3 ff ff       	call   67a7c0 <<gpui_canvas::text::FontFace>::shared_static>
  67e4be:	83 bc 24 00 07 00 00 	cmpl   $0x1,0x700(%rsp)
  67e4c5:	01 
  67e4c6:	75 19                	jne    67e4e1 <<gpui_canvas::text::planner::Planner>::shape+0x401>
  67e4c8:	44 8b a4 24 04 07 00 	mov    0x704(%rsp),%r12d
  67e4cf:	00 
  67e4d0:	44 8b bc 24 08 07 00 	mov    0x708(%rsp),%r15d
  67e4d7:	00 
  67e4d8:	eb 50                	jmp    67e52a <<gpui_canvas::text::planner::Planner>::shape+0x44a>
  67e4da:	31 c9                	xor    %ecx,%ecx
  67e4dc:	e9 81 00 00 00       	jmp    67e562 <<gpui_canvas::text::planner::Planner>::shape+0x482>
  67e4e1:	4d 8d bd 48 0a 00 00 	lea    0xa48(%r13),%r15
  67e4e8:	4c 8b a4 24 08 07 00 	mov    0x708(%rsp),%r12
  67e4ef:	00 
  67e4f0:	49 8b 07             	mov    (%r15),%rax
  67e4f3:	48 85 c0             	test   %rax,%rax
  67e4f6:	74 0f                	je     67e507 <<gpui_canvas::text::planner::Planner>::shape+0x427>
  67e4f8:	f0 48 ff 08          	lock decq (%rax)
  67e4fc:	75 09                	jne    67e507 <<gpui_canvas::text::planner::Planner>::shape+0x427>
  67e4fe:	4c 89 ff             	mov    %r15,%rdi
  67e501:	ff 15 11 89 10 00    	call   *0x108911(%rip)        # 786e18 <_DYNAMIC+0x260>
  67e507:	4d 89 a5 48 0a 00 00 	mov    %r12,0xa48(%r13)
  67e50e:	be 01 00 00 00       	mov    $0x1,%esi
  67e513:	4c 89 ef             	mov    %r13,%rdi
  67e516:	e8 75 36 00 00       	call   681b90 <<gpui_canvas::text::planner::Planner>::register>
  67e51b:	83 f8 ff             	cmp    $0xffffffff,%eax
  67e51e:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
  67e522:	74 2b                	je     67e54f <<gpui_canvas::text::planner::Planner>::shape+0x46f>
  67e524:	41 89 c4             	mov    %eax,%r12d
  67e527:	45 31 ff             	xor    %r15d,%r15d
  67e52a:	44 89 a4 24 98 00 00 	mov    %r12d,0x98(%rsp)
  67e531:	00 
  67e532:	44 89 bc 24 9c 00 00 	mov    %r15d,0x9c(%rsp)
  67e539:	00 
  67e53a:	48 c7 84 24 90 00 00 	movq   $0xffffffffffffffff,0x90(%rsp)
  67e541:	00 ff ff ff ff 
  67e546:	48 8b 2c 24          	mov    (%rsp),%rbp
  67e54a:	e9 26 28 00 00       	jmp    680d75 <<gpui_canvas::text::planner::Planner>::shape+0x2c95>
  67e54f:	f6 c1 02             	test   $0x2,%cl
  67e552:	74 0e                	je     67e562 <<gpui_canvas::text::planner::Planner>::shape+0x482>
  67e554:	49 83 bd 50 0a 00 00 	cmpq   $0x0,0xa50(%r13)
  67e55b:	00 
  67e55c:	0f 84 9e 29 00 00    	je     680f00 <<gpui_canvas::text::planner::Planner>::shape+0x2e20>
  67e562:	48 c7 84 24 38 03 00 	movq   $0xffffffffffffffff,0x338(%rsp)
  67e569:	00 ff ff ff ff 
  67e56e:	48 8d 05 71 d4 bd ff 	lea    -0x422b8f(%rip),%rax        # 25b9e6 <gpui_canvas::text::PRIMARY_BYTES+0x1f44d4>
  67e575:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  67e57c:	00 
  67e57d:	48 c7 84 24 48 03 00 	movq   $0xc,0x348(%rsp)
  67e584:	00 0c 00 00 00 
  67e589:	48 c7 84 24 50 03 00 	movq   $0xffffffffffffffff,0x350(%rsp)
  67e590:	00 ff ff ff ff 
  67e595:	48 8d 05 56 d4 bd ff 	lea    -0x422baa(%rip),%rax        # 25b9f2 <gpui_canvas::text::PRIMARY_BYTES+0x1f44e0>
  67e59c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  67e5a3:	00 
  67e5a4:	48 c7 84 24 60 03 00 	movq   $0x11,0x360(%rsp)
  67e5ab:	00 11 00 00 00 
  67e5b0:	48 c7 84 24 68 03 00 	movq   $0xffffffffffffffff,0x368(%rsp)
  67e5b7:	00 ff ff ff ff 
  67e5bc:	4c 8d 35 40 d4 bd ff 	lea    -0x422bc0(%rip),%r14        # 25ba03 <gpui_canvas::text::PRIMARY_BYTES+0x1f44f1>
  67e5c3:	4c 89 b4 24 70 03 00 	mov    %r14,0x370(%rsp)
  67e5ca:	00 
  67e5cb:	48 c7 84 24 78 03 00 	movq   $0x11,0x378(%rsp)
  67e5d2:	00 11 00 00 00 
  67e5d7:	f6 c1 01             	test   $0x1,%cl
  67e5da:	75 1c                	jne    67e5f8 <<gpui_canvas::text::planner::Planner>::shape+0x518>
  67e5dc:	4c 8d bc 24 50 03 00 	lea    0x350(%rsp),%r15
  67e5e3:	00 
  67e5e4:	b8 01 00 00 00       	mov    $0x1,%eax
  67e5e9:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  67e5f0:	00 
  67e5f1:	f6 c1 02             	test   $0x2,%cl
  67e5f4:	75 24                	jne    67e61a <<gpui_canvas::text::planner::Planner>::shape+0x53a>
  67e5f6:	eb 5a                	jmp    67e652 <<gpui_canvas::text::planner::Planner>::shape+0x572>
  67e5f8:	4c 8d bc 24 68 03 00 	lea    0x368(%rsp),%r15
  67e5ff:	00 
  67e600:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  67e607:	00 
  67e608:	b8 02 00 00 00       	mov    $0x2,%eax
  67e60d:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  67e614:	00 
  67e615:	f6 c1 02             	test   $0x2,%cl
  67e618:	74 38                	je     67e652 <<gpui_canvas::text::planner::Planner>::shape+0x572>
  67e61a:	49 8b 37             	mov    (%r15),%rsi
  67e61d:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  67e621:	77 14                	ja     67e637 <<gpui_canvas::text::planner::Planner>::shape+0x557>
  67e623:	48 85 f6             	test   %rsi,%rsi
  67e626:	74 0f                	je     67e637 <<gpui_canvas::text::planner::Planner>::shape+0x557>
  67e628:	49 8b 7f 08          	mov    0x8(%r15),%rdi
  67e62c:	ba 01 00 00 00       	mov    $0x1,%edx
  67e631:	ff 15 b9 87 10 00    	call   *0x1087b9(%rip)        # 786df0 <_DYNAMIC+0x238>
  67e637:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  67e63e:	4d 89 77 08          	mov    %r14,0x8(%r15)
  67e642:	49 c7 47 10 11 00 00 	movq   $0x11,0x10(%r15)
  67e649:	00 
  67e64a:	48 ff 84 24 10 02 00 	incq   0x210(%rsp)
  67e651:	00 
  67e652:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  67e659:	00 00 00 00 00 
  67e65e:	48 c7 84 24 f0 00 00 	movq   $0x4,0xf0(%rsp)
  67e665:	00 04 00 00 00 
  67e66a:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  67e671:	00 00 00 00 00 
  67e676:	48 c7 84 24 40 01 00 	movq   $0xffffffffffffffff,0x140(%rsp)
  67e67d:	00 ff ff ff ff 
  67e682:	f6 84 24 b8 01 00 00 	testb  $0x1,0x1b8(%rsp)
  67e689:	01 
  67e68a:	75 11                	jne    67e69d <<gpui_canvas::text::planner::Planner>::shape+0x5bd>
  67e68c:	f3 0f 10 05 18 f0 99 	movss  -0x660fe8(%rip),%xmm0        # 1d6ac <GCC_except_table0+0x8c>
  67e693:	ff 
  67e694:	f3 0f 11 84 24 bc 01 	movss  %xmm0,0x1bc(%rsp)
  67e69b:	00 00 
  67e69d:	49 8d 45 78          	lea    0x78(%r13),%rax
  67e6a1:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  67e6a8:	00 
  67e6a9:	49 8d 85 38 06 00 00 	lea    0x638(%r13),%rax
  67e6b0:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  67e6b7:	00 
  67e6b8:	49 8d 85 c8 08 00 00 	lea    0x8c8(%r13),%rax
  67e6bf:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  67e6c4:	4c 8d bc 24 b0 02 00 	lea    0x2b0(%rsp),%r15
  67e6cb:	00 
  67e6cc:	48 8d ac 24 b8 04 00 	lea    0x4b8(%rsp),%rbp
  67e6d3:	00 
  67e6d4:	0f 57 c0             	xorps  %xmm0,%xmm0
  67e6d7:	0f 29 84 24 80 02 00 	movaps %xmm0,0x280(%rsp)
  67e6de:	00 
  67e6df:	f3 0f 11 44 24 24    	movss  %xmm0,0x24(%rsp)
  67e6e5:	f3 0f 11 44 24 6c    	movss  %xmm0,0x6c(%rsp)
  67e6eb:	48 8d 05 f6 ea 0f 00 	lea    0xfeaf6(%rip),%rax        # 77d1e8 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x178>
  67e6f2:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  67e6f7:	48 8d 05 42 ed 0f 00 	lea    0xfed42(%rip),%rax        # 77d440 <anon.1151abbc0aa39aee2edfb443bb148018.25.llvm.12564331471646380133>
  67e6fe:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
  67e705:	00 
  67e706:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
  67e70d:	00 00 00 00 00 
  67e712:	31 d2                	xor    %edx,%edx
  67e714:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  67e71b:	00 
  67e71c:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  67e721:	31 c0                	xor    %eax,%eax
  67e723:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  67e728:	83 fe fe             	cmp    $0xfffffffe,%esi
  67e72b:	75 23                	jne    67e750 <<gpui_canvas::text::planner::Planner>::shape+0x670>
  67e72d:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  67e732:	4c 3b 94 24 a0 01 00 	cmp    0x1a0(%rsp),%r10
  67e739:	00 
  67e73a:	74 34                	je     67e770 <<gpui_canvas::text::planner::Planner>::shape+0x690>
  67e73c:	41 0f b6 0a          	movzbl (%r10),%ecx
  67e740:	84 c9                	test   %cl,%cl
  67e742:	78 44                	js     67e788 <<gpui_canvas::text::planner::Planner>::shape+0x6a8>
  67e744:	4d 8d 4a 01          	lea    0x1(%r10),%r9
  67e748:	e9 98 00 00 00       	jmp    67e7e5 <<gpui_canvas::text::planner::Planner>::shape+0x705>
  67e74d:	0f 1f 00             	nopl   (%rax)
  67e750:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  67e755:	89 f1                	mov    %esi,%ecx
  67e757:	4c 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%r8
  67e75e:	00 
  67e75f:	e9 8a 00 00 00       	jmp    67e7ee <<gpui_canvas::text::planner::Planner>::shape+0x70e>
  67e764:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  67e76b:	00 00 00 00 00 
  67e770:	c7 44 24 74 fe ff ff 	movl   $0xfffffffe,0x74(%rsp)
  67e777:	ff 
  67e778:	b1 01                	mov    $0x1,%cl
  67e77a:	89 4c 24 4c          	mov    %ecx,0x4c(%rsp)
  67e77e:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  67e783:	e9 ce 01 00 00       	jmp    67e956 <<gpui_canvas::text::planner::Planner>::shape+0x876>
  67e788:	49 89 c0             	mov    %rax,%r8
  67e78b:	89 c8                	mov    %ecx,%eax
  67e78d:	83 e0 1f             	and    $0x1f,%eax
  67e790:	41 0f b6 7a 01       	movzbl 0x1(%r10),%edi
  67e795:	83 e7 3f             	and    $0x3f,%edi
  67e798:	80 f9 e0             	cmp    $0xe0,%cl
  67e79b:	72 2d                	jb     67e7ca <<gpui_canvas::text::planner::Planner>::shape+0x6ea>
  67e79d:	41 0f b6 72 02       	movzbl 0x2(%r10),%esi
  67e7a2:	c1 e7 06             	shl    $0x6,%edi
  67e7a5:	83 e6 3f             	and    $0x3f,%esi
  67e7a8:	09 fe                	or     %edi,%esi
  67e7aa:	80 f9 f0             	cmp    $0xf0,%cl
  67e7ad:	72 28                	jb     67e7d7 <<gpui_canvas::text::planner::Planner>::shape+0x6f7>
  67e7af:	4d 8d 4a 04          	lea    0x4(%r10),%r9
  67e7b3:	41 0f b6 4a 03       	movzbl 0x3(%r10),%ecx
  67e7b8:	83 e0 07             	and    $0x7,%eax
  67e7bb:	c1 e0 12             	shl    $0x12,%eax
  67e7be:	c1 e6 06             	shl    $0x6,%esi
  67e7c1:	83 e1 3f             	and    $0x3f,%ecx
  67e7c4:	09 f1                	or     %esi,%ecx
  67e7c6:	09 c1                	or     %eax,%ecx
  67e7c8:	eb 18                	jmp    67e7e2 <<gpui_canvas::text::planner::Planner>::shape+0x702>
  67e7ca:	4d 8d 4a 02          	lea    0x2(%r10),%r9
  67e7ce:	c1 e0 06             	shl    $0x6,%eax
  67e7d1:	09 f8                	or     %edi,%eax
  67e7d3:	89 c1                	mov    %eax,%ecx
  67e7d5:	eb 0b                	jmp    67e7e2 <<gpui_canvas::text::planner::Planner>::shape+0x702>
  67e7d7:	4d 8d 4a 03          	lea    0x3(%r10),%r9
  67e7db:	c1 e0 0c             	shl    $0xc,%eax
  67e7de:	09 c6                	or     %eax,%esi
  67e7e0:	89 f1                	mov    %esi,%ecx
  67e7e2:	4c 89 c0             	mov    %r8,%rax
  67e7e5:	49 89 c0             	mov    %rax,%r8
  67e7e8:	4c 29 d0             	sub    %r10,%rax
  67e7eb:	4c 01 c8             	add    %r9,%rax
  67e7ee:	c7 44 24 74 fe ff ff 	movl   $0xfffffffe,0x74(%rsp)
  67e7f5:	ff 
  67e7f6:	40 b6 01             	mov    $0x1,%sil
  67e7f9:	89 74 24 4c          	mov    %esi,0x4c(%rsp)
  67e7fd:	83 f9 0c             	cmp    $0xc,%ecx
  67e800:	7e 1e                	jle    67e820 <<gpui_canvas::text::planner::Planner>::shape+0x740>
  67e802:	83 f9 0d             	cmp    $0xd,%ecx
  67e805:	0f 84 60 01 00 00    	je     67e96b <<gpui_canvas::text::planner::Planner>::shape+0x88b>
  67e80b:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  67e811:	74 1b                	je     67e82e <<gpui_canvas::text::planner::Planner>::shape+0x74e>
  67e813:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  67e819:	74 13                	je     67e82e <<gpui_canvas::text::planner::Planner>::shape+0x74e>
  67e81b:	e9 7d 00 00 00       	jmp    67e89d <<gpui_canvas::text::planner::Planner>::shape+0x7bd>
  67e820:	83 f9 ff             	cmp    $0xffffffff,%ecx
  67e823:	0f 84 23 01 00 00    	je     67e94c <<gpui_canvas::text::planner::Planner>::shape+0x86c>
  67e829:	83 f9 0a             	cmp    $0xa,%ecx
  67e82c:	75 6f                	jne    67e89d <<gpui_canvas::text::planner::Planner>::shape+0x7bd>
  67e82e:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  67e833:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  67e839:	0f 83 3d 01 00 00    	jae    67e97c <<gpui_canvas::text::planner::Planner>::shape+0x89c>
  67e83f:	49 8d 58 01          	lea    0x1(%r8),%rbx
  67e843:	83 f9 0d             	cmp    $0xd,%ecx
  67e846:	0f 85 42 01 00 00    	jne    67e98e <<gpui_canvas::text::planner::Planner>::shape+0x8ae>
  67e84c:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  67e851:	4c 3b 94 24 a0 01 00 	cmp    0x1a0(%rsp),%r10
  67e858:	00 
  67e859:	0f 84 ed 22 00 00    	je     680b4c <<gpui_canvas::text::planner::Planner>::shape+0x2a6c>
  67e85f:	45 0f b6 1a          	movzbl (%r10),%r11d
  67e863:	45 84 db             	test   %r11b,%r11b
  67e866:	0f 88 ed 22 00 00    	js     680b59 <<gpui_canvas::text::planner::Planner>::shape+0x2a79>
  67e86c:	4d 8d 72 01          	lea    0x1(%r10),%r14
  67e870:	e9 4a 23 00 00       	jmp    680bbf <<gpui_canvas::text::planner::Planner>::shape+0x2adf>
  67e875:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  67e87c:	00 00 00 00 
  67e880:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  67e886:	0f 84 e4 00 00 00    	je     67e970 <<gpui_canvas::text::planner::Planner>::shape+0x890>
  67e88c:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  67e891:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  67e897:	0f 84 d3 00 00 00    	je     67e970 <<gpui_canvas::text::planner::Planner>::shape+0x890>
  67e89d:	4c 3b 8c 24 a0 01 00 	cmp    0x1a0(%rsp),%r9
  67e8a4:	00 
  67e8a5:	0f 84 a1 00 00 00    	je     67e94c <<gpui_canvas::text::planner::Planner>::shape+0x86c>
  67e8ab:	49 89 c0             	mov    %rax,%r8
  67e8ae:	41 0f b6 09          	movzbl (%r9),%ecx
  67e8b2:	84 c9                	test   %cl,%cl
  67e8b4:	78 0a                	js     67e8c0 <<gpui_canvas::text::planner::Planner>::shape+0x7e0>
  67e8b6:	49 8d 41 01          	lea    0x1(%r9),%rax
  67e8ba:	eb 64                	jmp    67e920 <<gpui_canvas::text::planner::Planner>::shape+0x840>
  67e8bc:	0f 1f 40 00          	nopl   0x0(%rax)
  67e8c0:	89 c8                	mov    %ecx,%eax
  67e8c2:	83 e0 1f             	and    $0x1f,%eax
  67e8c5:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  67e8ca:	83 e7 3f             	and    $0x3f,%edi
  67e8cd:	80 f9 df             	cmp    $0xdf,%cl
  67e8d0:	76 30                	jbe    67e902 <<gpui_canvas::text::planner::Planner>::shape+0x822>
  67e8d2:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  67e8d7:	c1 e7 06             	shl    $0x6,%edi
  67e8da:	83 e6 3f             	and    $0x3f,%esi
  67e8dd:	09 fe                	or     %edi,%esi
  67e8df:	80 f9 f0             	cmp    $0xf0,%cl
  67e8e2:	72 2e                	jb     67e912 <<gpui_canvas::text::planner::Planner>::shape+0x832>
  67e8e4:	49 8d 79 04          	lea    0x4(%r9),%rdi
  67e8e8:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  67e8ed:	83 e0 07             	and    $0x7,%eax
  67e8f0:	c1 e0 12             	shl    $0x12,%eax
  67e8f3:	c1 e6 06             	shl    $0x6,%esi
  67e8f6:	83 e1 3f             	and    $0x3f,%ecx
  67e8f9:	09 f1                	or     %esi,%ecx
  67e8fb:	09 c1                	or     %eax,%ecx
  67e8fd:	48 89 f8             	mov    %rdi,%rax
  67e900:	eb 1e                	jmp    67e920 <<gpui_canvas::text::planner::Planner>::shape+0x840>
  67e902:	49 8d 71 02          	lea    0x2(%r9),%rsi
  67e906:	c1 e0 06             	shl    $0x6,%eax
  67e909:	09 f8                	or     %edi,%eax
  67e90b:	89 c1                	mov    %eax,%ecx
  67e90d:	48 89 f0             	mov    %rsi,%rax
  67e910:	eb 0e                	jmp    67e920 <<gpui_canvas::text::planner::Planner>::shape+0x840>
  67e912:	49 8d 49 03          	lea    0x3(%r9),%rcx
  67e916:	c1 e0 0c             	shl    $0xc,%eax
  67e919:	09 c6                	or     %eax,%esi
  67e91b:	48 89 c8             	mov    %rcx,%rax
  67e91e:	89 f1                	mov    %esi,%ecx
  67e920:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  67e925:	4c 29 c8             	sub    %r9,%rax
  67e928:	4c 01 c0             	add    %r8,%rax
  67e92b:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  67e931:	0f 8f 49 ff ff ff    	jg     67e880 <<gpui_canvas::text::planner::Planner>::shape+0x7a0>
  67e937:	83 f9 0a             	cmp    $0xa,%ecx
  67e93a:	74 34                	je     67e970 <<gpui_canvas::text::planner::Planner>::shape+0x890>
  67e93c:	4c 8b 4c 24 18       	mov    0x18(%rsp),%r9
  67e941:	83 f9 0d             	cmp    $0xd,%ecx
  67e944:	0f 85 53 ff ff ff    	jne    67e89d <<gpui_canvas::text::planner::Planner>::shape+0x7bd>
  67e94a:	eb 24                	jmp    67e970 <<gpui_canvas::text::planner::Planner>::shape+0x890>
  67e94c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  67e951:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  67e956:	48 89 d3             	mov    %rdx,%rbx
  67e959:	48 89 ce             	mov    %rcx,%rsi
  67e95c:	48 29 d6             	sub    %rdx,%rsi
  67e95f:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  67e964:	73 44                	jae    67e9aa <<gpui_canvas::text::planner::Planner>::shape+0x8ca>
  67e966:	e9 9d 2c 00 00       	jmp    681608 <<gpui_canvas::text::planner::Planner>::shape+0x3528>
  67e96b:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  67e970:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  67e976:	0f 82 c3 fe ff ff    	jb     67e83f <<gpui_canvas::text::planner::Planner>::shape+0x75f>
  67e97c:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  67e982:	bb 03 00 00 00       	mov    $0x3,%ebx
  67e987:	48 83 db 00          	sbb    $0x0,%rbx
  67e98b:	4c 01 c3             	add    %r8,%rbx
  67e98e:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  67e995:	00 
  67e996:	4c 89 c1             	mov    %r8,%rcx
  67e999:	48 89 ce             	mov    %rcx,%rsi
  67e99c:	48 29 d6             	sub    %rdx,%rsi
  67e99f:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  67e9a4:	0f 82 5e 2c 00 00    	jb     681608 <<gpui_canvas::text::planner::Planner>::shape+0x3528>
  67e9aa:	48 85 d2             	test   %rdx,%rdx
  67e9ad:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  67e9b4:	00 
  67e9b5:	74 2f                	je     67e9e6 <<gpui_canvas::text::planner::Planner>::shape+0x906>
  67e9b7:	48 3b 54 24 50       	cmp    0x50(%rsp),%rdx
  67e9bc:	73 22                	jae    67e9e0 <<gpui_canvas::text::planner::Planner>::shape+0x900>
  67e9be:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  67e9c5:	00 
  67e9c6:	80 3c 10 bf          	cmpb   $0xbf,(%rax,%rdx,1)
  67e9ca:	7f 1a                	jg     67e9e6 <<gpui_canvas::text::planner::Planner>::shape+0x906>
  67e9cc:	e9 37 2c 00 00       	jmp    681608 <<gpui_canvas::text::planner::Planner>::shape+0x3528>
  67e9d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  67e9d8:	0f 1f 84 00 00 00 00 
  67e9df:	00 
  67e9e0:	0f 85 22 2c 00 00    	jne    681608 <<gpui_canvas::text::planner::Planner>::shape+0x3528>
  67e9e6:	48 85 c9             	test   %rcx,%rcx
  67e9e9:	74 2b                	je     67ea16 <<gpui_canvas::text::planner::Planner>::shape+0x936>
  67e9eb:	48 3b 4c 24 50       	cmp    0x50(%rsp),%rcx
  67e9f0:	73 1e                	jae    67ea10 <<gpui_canvas::text::planner::Planner>::shape+0x930>
  67e9f2:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  67e9f9:	00 
  67e9fa:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  67e9fe:	7d 16                	jge    67ea16 <<gpui_canvas::text::planner::Planner>::shape+0x936>
  67ea00:	e9 03 2c 00 00       	jmp    681608 <<gpui_canvas::text::planner::Planner>::shape+0x3528>
  67ea05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  67ea0c:	00 00 00 00 
  67ea10:	0f 85 f2 2b 00 00    	jne    681608 <<gpui_canvas::text::planner::Planner>::shape+0x3528>
  67ea16:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
  67ea1d:	00 
  67ea1e:	48 89 9c 24 a8 03 00 	mov    %rbx,0x3a8(%rsp)
  67ea25:	00 
  67ea26:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  67ea2d:	00 
  67ea2e:	48 89 54 24 40       	mov    %rdx,0x40(%rsp)
  67ea33:	48 8d 0c 10          	lea    (%rax,%rdx,1),%rcx
  67ea37:	48 8d bc 24 88 04 00 	lea    0x488(%rsp),%rdi
  67ea3e:	00 
  67ea3f:	48 8b b4 24 c0 03 00 	mov    0x3c0(%rsp),%rsi
  67ea46:	00 
  67ea47:	48 8b 94 24 b8 03 00 	mov    0x3b8(%rsp),%rdx
  67ea4e:	00 
  67ea4f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  67ea54:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  67ea59:	f3 0f 10 05 db eb 99 	movss  -0x661425(%rip),%xmm0        # 1d63c <GCC_except_table0+0x1c>
  67ea60:	ff 
  67ea61:	45 31 c9             	xor    %r9d,%r9d
  67ea64:	e8 97 c2 ff ff       	call   67ad00 <<parley::context::LayoutContext<()>>::ranged_builder>
  67ea69:	48 8d bc 24 88 04 00 	lea    0x488(%rsp),%rdi
  67ea70:	00 
  67ea71:	48 8d b4 24 38 03 00 	lea    0x338(%rsp),%rsi
  67ea78:	00 
  67ea79:	48 8b 94 24 10 02 00 	mov    0x210(%rsp),%rdx
  67ea80:	00 
  67ea81:	e8 7a ff fe ff       	call   66ea00 <<parley::builder::RangedBuilder<()>>::push_default::<&[parlance::font_family::FontFamilyName]>>
  67ea86:	4c 8b b4 24 88 04 00 	mov    0x488(%rsp),%r14
  67ea8d:	00 
  67ea8e:	4c 8b ac 24 90 04 00 	mov    0x490(%rsp),%r13
  67ea95:	00 
  67ea96:	4d 8d a6 30 02 00 00 	lea    0x230(%r14),%r12
  67ea9d:	c6 84 24 00 07 00 00 	movb   $0x1,0x700(%rsp)
  67eaa4:	01 
  67eaa5:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  67eaab:	f3 0f 11 84 24 04 07 	movss  %xmm0,0x704(%rsp)
  67eab2:	00 00 
  67eab4:	f3 0f 10 84 24 a8 04 	movss  0x4a8(%rsp),%xmm0
  67eabb:	00 00 
  67eabd:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  67eac4:	00 
  67eac5:	4c 89 e6             	mov    %r12,%rsi
  67eac8:	4c 89 ea             	mov    %r13,%rdx
  67eacb:	48 8d 9c 24 00 07 00 	lea    0x700(%rsp),%rbx
  67ead2:	00 
  67ead3:	48 89 d9             	mov    %rbx,%rcx
  67ead6:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  67eadc:	e8 3f 5c fe ff       	call   664720 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  67eae1:	48 89 df             	mov    %rbx,%rdi
  67eae4:	e8 f7 00 ff ff       	call   66ebe0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  67eae9:	49 83 be 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r14)
  67eaf0:	ff 
  67eaf1:	0f 84 5d 27 00 00    	je     681254 <<gpui_canvas::text::planner::Planner>::shape+0x3174>
  67eaf7:	49 8d 9e 98 04 00 00 	lea    0x498(%r14),%rbx
  67eafe:	48 89 df             	mov    %rbx,%rdi
  67eb01:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  67eb08:	00 
  67eb09:	e8 42 7e fe ff       	call   666950 <<parley::resolve::ResolvedStyle<()>>::apply>
  67eb0e:	66 c7 84 24 00 07 00 	movw   $0x117,0x700(%rsp)
  67eb15:	00 17 01 
  67eb18:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  67eb1f:	00 
  67eb20:	4c 89 e6             	mov    %r12,%rsi
  67eb23:	4c 89 ea             	mov    %r13,%rdx
  67eb26:	4c 8d a4 24 00 07 00 	lea    0x700(%rsp),%r12
  67eb2d:	00 
  67eb2e:	4c 89 e1             	mov    %r12,%rcx
  67eb31:	f3 0f 10 44 24 30    	movss  0x30(%rsp),%xmm0
  67eb37:	e8 e4 5b fe ff       	call   664720 <<parley::resolve::ResolveContext>::resolve_property::<()>>
  67eb3c:	4c 89 e7             	mov    %r12,%rdi
  67eb3f:	e8 9c 00 ff ff       	call   66ebe0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  67eb44:	49 83 be 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r14)
  67eb4b:	ff 
  67eb4c:	0f 84 02 27 00 00    	je     681254 <<gpui_canvas::text::planner::Planner>::shape+0x3174>
  67eb52:	48 89 df             	mov    %rbx,%rdi
  67eb55:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  67eb5c:	00 
  67eb5d:	e8 ee 7d fe ff       	call   666950 <<parley::resolve::ResolvedStyle<()>>::apply>
  67eb62:	48 8d bc 24 88 04 00 	lea    0x488(%rsp),%rdi
  67eb69:	00 
  67eb6a:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  67eb6f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  67eb74:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  67eb79:	e8 32 c8 fe ff       	call   66b3b0 <<parley::builder::RangedBuilder<()>>::build_into::<&str>>
  67eb7e:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  67eb85:	00 
  67eb86:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  67eb8b:	e8 c0 96 ff ff       	call   678250 <<parley::layout::line_break::BreakLines<()>>::new>
  67eb90:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  67eb97:	00 
  67eb98:	f3 0f 10 84 24 bc 01 	movss  0x1bc(%rsp),%xmm0
  67eb9f:	00 00 
  67eba1:	e8 8a 87 ff ff       	call   677330 <<parley::layout::line_break::BreakLines<()>>::break_remaining>
  67eba6:	80 bc 24 2c 02 00 00 	cmpb   $0x0,0x22c(%rsp)
  67ebad:	00 
  67ebae:	74 20                	je     67ebd0 <<gpui_canvas::text::planner::Planner>::shape+0xaf0>
  67ebb0:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  67ebb7:	00 ff 
  67ebb9:	0f 85 11 02 00 00    	jne    67edd0 <<gpui_canvas::text::planner::Planner>::shape+0xcf0>
  67ebbf:	31 c0                	xor    %eax,%eax
  67ebc1:	e9 90 01 00 00       	jmp    67ed56 <<gpui_canvas::text::planner::Planner>::shape+0xc76>
  67ebc6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67ebcd:	00 00 00 
  67ebd0:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
  67ebd6:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  67ebdd:	00 
  67ebde:	0f 85 5c 01 00 00    	jne    67ed40 <<gpui_canvas::text::planner::Planner>::shape+0xc60>
  67ebe4:	48 3b 44 24 50       	cmp    0x50(%rsp),%rax
  67ebe9:	0f 85 51 01 00 00    	jne    67ed40 <<gpui_canvas::text::planner::Planner>::shape+0xc60>
  67ebef:	48 8b 04 24          	mov    (%rsp),%rax
  67ebf3:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  67ebfa:	01 
  67ebfb:	0f 85 3f 01 00 00    	jne    67ed40 <<gpui_canvas::text::planner::Planner>::shape+0xc60>
  67ec01:	48 8b 14 24          	mov    (%rsp),%rdx
  67ec05:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  67ec0c:	48 8d 48 70          	lea    0x70(%rax),%rcx
  67ec10:	48 89 8c 24 08 07 00 	mov    %rcx,0x708(%rsp)
  67ec17:	00 
  67ec18:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  67ec1f:	00 00 00 00 00 
  67ec24:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  67ec29:	48 89 b4 24 18 07 00 	mov    %rsi,0x718(%rsp)
  67ec30:	00 
  67ec31:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  67ec38:	00 00 00 00 00 
  67ec3d:	48 89 94 24 b0 04 00 	mov    %rdx,0x4b0(%rsp)
  67ec44:	00 
  67ec45:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  67ec4c:	00 00 00 00 00 
  67ec51:	48 89 8c 24 00 07 00 	mov    %rcx,0x700(%rsp)
  67ec58:	00 
  67ec59:	48 8b 78 10          	mov    0x10(%rax),%rdi
  67ec5d:	48 8b 70 18          	mov    0x18(%rax),%rsi
  67ec61:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  67ec68:	48 39 fe             	cmp    %rdi,%rsi
  67ec6b:	0f 82 61 29 00 00    	jb     6815d2 <<gpui_canvas::text::planner::Planner>::shape+0x34f2>
  67ec71:	48 39 d6             	cmp    %rdx,%rsi
  67ec74:	0f 87 58 29 00 00    	ja     6815d2 <<gpui_canvas::text::planner::Planner>::shape+0x34f2>
  67ec7a:	48 8b 04 24          	mov    (%rsp),%rax
  67ec7e:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  67ec85:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  67ec89:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  67ec8d:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  67ec91:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  67ec95:	48 89 8c 24 20 07 00 	mov    %rcx,0x720(%rsp)
  67ec9c:	00 
  67ec9d:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  67eca4:	00 
  67eca5:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  67ecac:	00 00 00 00 00 
  67ecb1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  67ecb6:	48 89 84 24 38 07 00 	mov    %rax,0x738(%rsp)
  67ecbd:	00 
  67ecbe:	c7 84 24 40 07 00 00 	movl   $0x0,0x740(%rsp)
  67ecc5:	00 00 00 00 
  67ecc9:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  67ecd0:	00 
  67ecd1:	48 8d b4 24 48 07 00 	lea    0x748(%rsp),%rsi
  67ecd8:	00 
  67ecd9:	48 8d 94 24 b0 04 00 	lea    0x4b0(%rsp),%rdx
  67ece0:	00 
  67ece1:	e8 4a 69 fe ff       	call   665630 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  67ece6:	48 c7 84 24 10 07 00 	movq   $0x1,0x710(%rsp)
  67eced:	00 01 00 00 00 
  67ecf2:	84 c0                	test   %al,%al
  67ecf4:	75 4a                	jne    67ed40 <<gpui_canvas::text::planner::Planner>::shape+0xc60>
  67ecf6:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  67ecfd:	00 00 00 00 00 
  67ed02:	48 83 bc 24 48 07 00 	cmpq   $0x0,0x748(%rsp)
  67ed09:	00 00 
  67ed0b:	0f 84 c0 1d 00 00    	je     680ad1 <<gpui_canvas::text::planner::Planner>::shape+0x29f1>
  67ed11:	48 8d bc 24 48 07 00 	lea    0x748(%rsp),%rdi
  67ed18:	00 
  67ed19:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
  67ed20:	00 
  67ed21:	48 8d 94 24 b0 04 00 	lea    0x4b0(%rsp),%rdx
  67ed28:	00 
  67ed29:	e8 02 69 fe ff       	call   665630 <<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), core::iter::adapters::filter_map::filter_map_try_fold<parley::layout::line::LineItem<()>, parley::layout::run::Run<()>, (), core::ops::control_flow::ControlFlow<()>, <parley::layout::line::Line<()>>::runs::{closure#0}, &mut core::iter::traits::iterator::Iterator::all::check<parley::layout::run::Run<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#2}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<()>>>
  67ed2e:	84 c0                	test   %al,%al
  67ed30:	0f 84 9b 1d 00 00    	je     680ad1 <<gpui_canvas::text::planner::Planner>::shape+0x29f1>
  67ed36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67ed3d:	00 00 00 
  67ed40:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  67ed47:	00 ff 
  67ed49:	0f 85 81 00 00 00    	jne    67edd0 <<gpui_canvas::text::planner::Planner>::shape+0xcf0>
  67ed4f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  67ed56:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  67ed5d:	00 00 00 00 00 
  67ed62:	48 c7 84 24 48 01 00 	movq   $0x4,0x148(%rsp)
  67ed69:	00 04 00 00 00 
  67ed6e:	48 8d 8c 24 48 01 00 	lea    0x148(%rsp),%rcx
  67ed75:	00 
  67ed76:	0f 57 c0             	xorps  %xmm0,%xmm0
  67ed79:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  67ed7d:	48 c7 84 24 60 01 00 	movq   $0x4,0x160(%rsp)
  67ed84:	00 04 00 00 00 
  67ed89:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  67ed90:	00 00 00 00 00 
  67ed95:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  67ed9c:	00 
  67ed9d:	48 c7 84 24 78 01 00 	movq   $0x4,0x178(%rsp)
  67eda4:	00 04 00 00 00 
  67eda9:	48 c7 84 24 80 01 00 	movq   $0x0,0x180(%rsp)
  67edb0:	00 00 00 00 00 
  67edb5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  67edba:	89 84 24 88 01 00 00 	mov    %eax,0x188(%rsp)
  67edc1:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  67edc7:	f3 0f 11 84 24 8c 01 	movss  %xmm0,0x18c(%rsp)
  67edce:	00 00 
  67edd0:	48 8b 04 24          	mov    (%rsp),%rax
  67edd4:	48 8b 98 e0 09 00 00 	mov    0x9e0(%rax),%rbx
  67eddb:	48 85 db             	test   %rbx,%rbx
  67edde:	0f 84 0c 01 00 00    	je     67eef0 <<gpui_canvas::text::planner::Planner>::shape+0xe10>
  67ede4:	4c 8b a0 d8 09 00 00 	mov    0x9d8(%rax),%r12
  67edeb:	45 31 f6             	xor    %r14d,%r14d
  67edee:	45 31 ed             	xor    %r13d,%r13d
  67edf1:	eb 19                	jmp    67ee0c <<gpui_canvas::text::planner::Planner>::shape+0xd2c>
  67edf3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  67edfa:	84 00 00 00 00 00 
  67ee00:	49 ff c6             	inc    %r14
  67ee03:	49 39 de             	cmp    %rbx,%r14
  67ee06:	0f 84 e7 00 00 00    	je     67eef3 <<gpui_canvas::text::planner::Planner>::shape+0xe13>
  67ee0c:	49 6b c6 70          	imul   $0x70,%r14,%rax
  67ee10:	4c 01 e0             	add    %r12,%rax
  67ee13:	4c 89 ac 24 00 07 00 	mov    %r13,0x700(%rsp)
  67ee1a:	00 
  67ee1b:	48 c7 84 24 08 07 00 	movq   $0x0,0x708(%rsp)
  67ee22:	00 00 00 00 00 
  67ee27:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  67ee2c:	48 89 8c 24 10 07 00 	mov    %rcx,0x710(%rsp)
  67ee33:	00 
  67ee34:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  67ee3b:	00 
  67ee3c:	44 89 b4 24 20 07 00 	mov    %r14d,0x720(%rsp)
  67ee43:	00 
  67ee44:	c6 84 24 c8 07 00 00 	movb   $0x2,0x7c8(%rsp)
  67ee4b:	02 
  67ee4c:	c7 84 24 d0 07 00 00 	movl   $0x0,0x7d0(%rsp)
  67ee53:	00 00 00 00 
  67ee57:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  67ee5e:	00 
  67ee5f:	48 8d b4 24 08 07 00 	lea    0x708(%rsp),%rsi
  67ee66:	00 
  67ee67:	e8 24 b4 fe ff       	call   66a290 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  67ee6c:	83 bc 24 a0 02 00 00 	cmpl   $0x1,0x2a0(%rsp)
  67ee73:	01 
  67ee74:	75 8a                	jne    67ee00 <<gpui_canvas::text::planner::Planner>::shape+0xd20>
  67ee76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67ee7d:	00 00 00 
  67ee80:	49 8b 47 38          	mov    0x38(%r15),%rax
  67ee84:	48 89 45 40          	mov    %rax,0x40(%rbp)
  67ee88:	41 0f 10 47 f8       	movups -0x8(%r15),%xmm0
  67ee8d:	41 0f 10 4f 08       	movups 0x8(%r15),%xmm1
  67ee92:	41 0f 10 57 18       	movups 0x18(%r15),%xmm2
  67ee97:	41 0f 10 5f 28       	movups 0x28(%r15),%xmm3
  67ee9c:	0f 11 5d 30          	movups %xmm3,0x30(%rbp)
  67eea0:	0f 11 55 20          	movups %xmm2,0x20(%rbp)
  67eea4:	0f 11 4d 10          	movups %xmm1,0x10(%rbp)
  67eea8:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
  67eeac:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
  67eeb3:	00 
  67eeb4:	4c 89 ee             	mov    %r13,%rsi
  67eeb7:	48 89 ea             	mov    %rbp,%rdx
  67eeba:	e8 71 81 fe ff       	call   667030 <<&mut core::iter::adapters::map::map_fold<parley::layout::line::PositionedLayoutItem<()>, usize, usize, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, parley::layout::line::GlyphRunIter<()>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#4}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#5}>>::{closure#0}>::{closure#0} as core::ops::function::FnMut<(usize, parley::layout::line::PositionedLayoutItem<()>)>>::call_mut>
  67eebf:	49 89 c5             	mov    %rax,%r13
  67eec2:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  67eec9:	00 
  67eeca:	48 8d b4 24 08 07 00 	lea    0x708(%rsp),%rsi
  67eed1:	00 
  67eed2:	e8 b9 b3 fe ff       	call   66a290 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  67eed7:	80 bc 24 a0 02 00 00 	cmpb   $0x0,0x2a0(%rsp)
  67eede:	00 
  67eedf:	75 9f                	jne    67ee80 <<gpui_canvas::text::planner::Planner>::shape+0xda0>
  67eee1:	e9 1a ff ff ff       	jmp    67ee00 <<gpui_canvas::text::planner::Planner>::shape+0xd20>
  67eee6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  67eeed:	00 00 00 
  67eef0:	45 31 ed             	xor    %r13d,%r13d
  67eef3:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  67eefa:	00 
  67eefb:	48 89 f0             	mov    %rsi,%rax
  67eefe:	4c 01 e8             	add    %r13,%rax
  67ef01:	0f 92 c1             	setb   %cl
  67ef04:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  67ef0a:	0f 93 c0             	setae  %al
  67ef0d:	08 c8                	or     %cl,%al
  67ef0f:	0f 85 1e 1d 00 00    	jne    680c33 <<gpui_canvas::text::planner::Planner>::shape+0x2b53>
  67ef15:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  67ef1c:	00 
  67ef1d:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
  67ef22:	74 14                	je     67ef38 <<gpui_canvas::text::planner::Planner>::shape+0xe58>
  67ef24:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  67ef2b:	00 
  67ef2c:	48 29 f0             	sub    %rsi,%rax
  67ef2f:	49 39 c5             	cmp    %rax,%r13
  67ef32:	0f 87 db 1c 00 00    	ja     680c13 <<gpui_canvas::text::planner::Planner>::shape+0x2b33>
  67ef38:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  67ef3d:	48 85 d2             	test   %rdx,%rdx
  67ef40:	4c 8b b4 24 90 01 00 	mov    0x190(%rsp),%r14
  67ef47:	00 
  67ef48:	74 26                	je     67ef70 <<gpui_canvas::text::planner::Planner>::shape+0xe90>
  67ef4a:	0f 57 c0             	xorps  %xmm0,%xmm0
  67ef4d:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  67ef54:	00 00 
  67ef56:	49 39 d6             	cmp    %rdx,%r14
  67ef59:	75 4b                	jne    67efa6 <<gpui_canvas::text::planner::Planner>::shape+0xec6>
  67ef5b:	48 8b 0c 24          	mov    (%rsp),%rcx
  67ef5f:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  67ef66:	48 85 c0             	test   %rax,%rax
  67ef69:	75 7c                	jne    67efe7 <<gpui_canvas::text::planner::Planner>::shape+0xf07>
  67ef6b:	e9 d6 14 00 00       	jmp    680446 <<gpui_canvas::text::planner::Planner>::shape+0x2366>
  67ef70:	48 8b 04 24          	mov    (%rsp),%rax
  67ef74:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  67ef7b:	00 
  67ef7c:	74 0e                	je     67ef8c <<gpui_canvas::text::planner::Planner>::shape+0xeac>
  67ef7e:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  67ef85:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  67ef8a:	eb 03                	jmp    67ef8f <<gpui_canvas::text::planner::Planner>::shape+0xeaf>
  67ef8c:	0f 57 c0             	xorps  %xmm0,%xmm0
  67ef8f:	f3 0f 11 44 24 6c    	movss  %xmm0,0x6c(%rsp)
  67ef95:	0f 57 c0             	xorps  %xmm0,%xmm0
  67ef98:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  67ef9f:	00 00 
  67efa1:	49 39 d6             	cmp    %rdx,%r14
  67efa4:	74 b5                	je     67ef5b <<gpui_canvas::text::planner::Planner>::shape+0xe7b>
  67efa6:	83 bc 24 b8 01 00 00 	cmpl   $0x0,0x1b8(%rsp)
  67efad:	00 
  67efae:	74 0e                	je     67efbe <<gpui_canvas::text::planner::Planner>::shape+0xede>
  67efb0:	48 8b 04 24          	mov    (%rsp),%rax
  67efb4:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  67efbb:	00 
  67efbc:	eb 0c                	jmp    67efca <<gpui_canvas::text::planner::Planner>::shape+0xeea>
  67efbe:	48 8b 04 24          	mov    (%rsp),%rax
  67efc2:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  67efc9:	00 
  67efca:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  67efd1:	00 00 
  67efd3:	48 8b 0c 24          	mov    (%rsp),%rcx
  67efd7:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  67efde:	48 85 c0             	test   %rax,%rax
  67efe1:	0f 84 5f 14 00 00    	je     680446 <<gpui_canvas::text::planner::Planner>::shape+0x2366>
  67efe7:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  67efee:	48 6b c0 70          	imul   $0x70,%rax,%rax
  67eff2:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  67eff9:	00 
  67effa:	48 01 c8             	add    %rcx,%rax
  67effd:	48 89 84 24 98 03 00 	mov    %rax,0x398(%rsp)
  67f004:	00 
  67f005:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
  67f00c:	00 
  67f00d:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  67f014:	00 ff 
  67f016:	74 2e                	je     67f046 <<gpui_canvas::text::planner::Planner>::shape+0xf66>
  67f018:	49 39 d6             	cmp    %rdx,%r14
  67f01b:	75 3c                	jne    67f059 <<gpui_canvas::text::planner::Planner>::shape+0xf79>
  67f01d:	45 31 ed             	xor    %r13d,%r13d
  67f020:	45 31 f6             	xor    %r14d,%r14d
  67f023:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  67f02a:	00 
  67f02b:	4c 8b a4 24 68 01 00 	mov    0x168(%rsp),%r12
  67f032:	00 
  67f033:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  67f037:	4c 89 a4 24 58 02 00 	mov    %r12,0x258(%rsp)
  67f03e:	00 
  67f03f:	74 41                	je     67f082 <<gpui_canvas::text::planner::Planner>::shape+0xfa2>
  67f041:	e9 c6 01 00 00       	jmp    67f20c <<gpui_canvas::text::planner::Planner>::shape+0x112c>
  67f046:	8b 4c 24 70          	mov    0x70(%rsp),%ecx
  67f04a:	89 c8                	mov    %ecx,%eax
  67f04c:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
  67f053:	00 
  67f054:	e9 c9 03 00 00       	jmp    67f422 <<gpui_canvas::text::planner::Planner>::shape+0x1342>
  67f059:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  67f060:	00 
  67f061:	4c 8b 30             	mov    (%rax),%r14
  67f064:	4c 8b 68 08          	mov    0x8(%rax),%r13
  67f068:	4c 8b a4 24 68 01 00 	mov    0x168(%rsp),%r12
  67f06f:	00 
  67f070:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  67f074:	4c 89 a4 24 58 02 00 	mov    %r12,0x258(%rsp)
  67f07b:	00 
  67f07c:	0f 85 8a 01 00 00    	jne    67f20c <<gpui_canvas::text::planner::Planner>::shape+0x112c>
  67f082:	48 8b 78 10          	mov    0x10(%rax),%rdi
  67f086:	48 8b 70 18          	mov    0x18(%rax),%rsi
  67f08a:	48 8b 04 24          	mov    (%rsp),%rax
  67f08e:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  67f095:	48 39 fe             	cmp    %rdi,%rsi
  67f098:	0f 82 46 25 00 00    	jb     6815e4 <<gpui_canvas::text::planner::Planner>::shape+0x3504>
  67f09e:	48 39 d6             	cmp    %rdx,%rsi
  67f0a1:	0f 87 3d 25 00 00    	ja     6815e4 <<gpui_canvas::text::planner::Planner>::shape+0x3504>
  67f0a7:	48 8b 04 24          	mov    (%rsp),%rax
  67f0ab:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  67f0b2:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  67f0b6:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  67f0ba:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  67f0be:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  67f0c2:	48 89 8c 24 b0 04 00 	mov    %rcx,0x4b0(%rsp)
  67f0c9:	00 
  67f0ca:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
  67f0d1:	00 
  67f0d2:	48 c7 84 24 c0 04 00 	movq   $0x0,0x4c0(%rsp)
  67f0d9:	00 00 00 00 00 
  67f0de:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  67f0e3:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
  67f0ea:	00 
  67f0eb:	8b 44 24 70          	mov    0x70(%rsp),%eax
  67f0ef:	89 84 24 d0 04 00 00 	mov    %eax,0x4d0(%rsp)
  67f0f6:	c6 84 24 f0 06 00 00 	movb   $0x2,0x6f0(%rsp)
  67f0fd:	02 
  67f0fe:	48 8d 84 24 f8 06 00 	lea    0x6f8(%rsp),%rax
  67f105:	00 
  67f106:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  67f10d:	00 
  67f10e:	c6 84 24 e0 05 00 00 	movb   $0x2,0x5e0(%rsp)
  67f115:	02 
  67f116:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  67f11d:	00 
  67f11e:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  67f125:	00 
  67f126:	48 8d 94 24 a0 02 00 	lea    0x2a0(%rsp),%rdx
  67f12d:	00 
  67f12e:	48 8d 8c 24 d8 04 00 	lea    0x4d8(%rsp),%rcx
  67f135:	00 
  67f136:	e8 f5 5d fe ff       	call   664f30 <<core::iter::adapters::map::Map<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#0}> as core::iter::traits::iterator::Iterator>::try_fold::<(), <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::try_fold::flatten<parley::layout::run::Clusters<()>, (), core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>, core::iter::traits::iterator::Iterator::find::check<parley::layout::cluster::Cluster<()>, &mut gpui_canvas::text::planner::freeze_line::{closure#1}>::{closure#0}>::{closure#0}>::{closure#0}, core::ops::control_flow::ControlFlow<parley::layout::cluster::Cluster<()>>>>
  67f13b:	48 8b 8c 24 00 07 00 	mov    0x700(%rsp),%rcx
  67f142:	00 
  67f143:	48 85 c9             	test   %rcx,%rcx
  67f146:	0f 84 ae 00 00 00    	je     67f1fa <<gpui_canvas::text::planner::Planner>::shape+0x111a>
  67f14c:	8b bc 24 28 07 00 00 	mov    0x728(%rsp),%edi
  67f153:	8b b4 24 80 07 00 00 	mov    0x780(%rsp),%esi
  67f15a:	8b 94 24 84 07 00 00 	mov    0x784(%rsp),%edx
  67f161:	48 8b 41 58          	mov    0x58(%rcx),%rax
  67f165:	48 39 f8             	cmp    %rdi,%rax
  67f168:	0f 86 81 25 00 00    	jbe    6816ef <<gpui_canvas::text::planner::Planner>::shape+0x360f>
  67f16e:	48 8b 41 50          	mov    0x50(%rcx),%rax
  67f172:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  67f176:	48 c1 e7 04          	shl    $0x4,%rdi
  67f17a:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  67f17e:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  67f185:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  67f18c:	0f 11 84 24 00 07 00 	movups %xmm0,0x700(%rsp)
  67f193:	00 
  67f194:	0f 11 8c 24 10 07 00 	movups %xmm1,0x710(%rsp)
  67f19b:	00 
  67f19c:	0f 11 94 24 20 07 00 	movups %xmm2,0x720(%rsp)
  67f1a3:	00 
  67f1a4:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  67f1a9:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
  67f1b0:	00 
  67f1b1:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  67f1b8:	00 
  67f1b9:	ff 15 11 7f 10 00    	call   *0x107f11(%rip)        # 7870d0 <_DYNAMIC+0x518>
  67f1bf:	48 89 c3             	mov    %rax,%rbx
  67f1c2:	ba 48 02 00 00       	mov    $0x248,%edx
  67f1c7:	4d 89 f4             	mov    %r14,%r12
  67f1ca:	4c 8d b4 24 00 07 00 	lea    0x700(%rsp),%r14
  67f1d1:	00 
  67f1d2:	4c 89 f7             	mov    %r14,%rdi
  67f1d5:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  67f1dc:	00 
  67f1dd:	ff 15 a5 7c 10 00    	call   *0x107ca5(%rip)        # 786e88 <memcpy@GLIBC_2.14>
  67f1e3:	4c 89 f7             	mov    %r14,%rdi
  67f1e6:	4d 89 e6             	mov    %r12,%r14
  67f1e9:	48 89 de             	mov    %rbx,%rsi
  67f1ec:	e8 df 5f fe ff       	call   6651d0 <<core::iter::adapters::map::Map<core::iter::adapters::filter::Filter<core::iter::adapters::flatten::FlatMap<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, parley::layout::run::Clusters<()>, gpui_canvas::text::planner::freeze_line::{closure#0}>, gpui_canvas::text::planner::freeze_line::{closure#1}>, gpui_canvas::text::planner::freeze_line::{closure#2}> as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::traits::iterator::Iterator::min_by::fold<usize, <usize as core::cmp::Ord>::cmp>::{closure#0}>>
  67f1f1:	4c 39 e8             	cmp    %r13,%rax
  67f1f4:	4c 0f 42 e8          	cmovb  %rax,%r13
  67f1f8:	eb 12                	jmp    67f20c <<gpui_canvas::text::planner::Planner>::shape+0x112c>
  67f1fa:	80 bc 24 f0 06 00 00 	cmpb   $0x2,0x6f0(%rsp)
  67f201:	02 
  67f202:	c6 84 24 e0 05 00 00 	movb   $0x2,0x5e0(%rsp)
  67f209:	02 
  67f20a:	75 34                	jne    67f240 <<gpui_canvas::text::planner::Planner>::shape+0x1160>
  67f20c:	4d 39 ee             	cmp    %r13,%r14
  67f20f:	0f 87 99 1d 00 00    	ja     680fae <<gpui_canvas::text::planner::Planner>::shape+0x2ece>
  67f215:	4d 85 f6             	test   %r14,%r14
  67f218:	0f 84 9e 00 00 00    	je     67f2bc <<gpui_canvas::text::planner::Planner>::shape+0x11dc>
  67f21e:	4c 3b 74 24 08       	cmp    0x8(%rsp),%r14
  67f223:	0f 83 8d 00 00 00    	jae    67f2b6 <<gpui_canvas::text::planner::Planner>::shape+0x11d6>
  67f229:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  67f22e:	42 80 3c 30 bf       	cmpb   $0xbf,(%rax,%r14,1)
  67f233:	0f 8f 83 00 00 00    	jg     67f2bc <<gpui_canvas::text::planner::Planner>::shape+0x11dc>
  67f239:	e9 70 1d 00 00       	jmp    680fae <<gpui_canvas::text::planner::Planner>::shape+0x2ece>
  67f23e:	66 90                	xchg   %ax,%ax
  67f240:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  67f247:	00 
  67f248:	48 8d b4 24 e8 05 00 	lea    0x5e8(%rsp),%rsi
  67f24f:	00 
  67f250:	e8 4b 82 fe ff       	call   6674a0 <<parley::layout::run::Clusters<()> as core::iter::traits::iterator::Iterator>::next>
  67f255:	48 8b 8c 24 00 07 00 	mov    0x700(%rsp),%rcx
  67f25c:	00 
  67f25d:	48 85 c9             	test   %rcx,%rcx
  67f260:	74 aa                	je     67f20c <<gpui_canvas::text::planner::Planner>::shape+0x112c>
  67f262:	8b bc 24 28 07 00 00 	mov    0x728(%rsp),%edi
  67f269:	48 8b 41 58          	mov    0x58(%rcx),%rax
  67f26d:	48 39 f8             	cmp    %rdi,%rax
  67f270:	0f 86 f6 23 00 00    	jbe    68166c <<gpui_canvas::text::planner::Planner>::shape+0x358c>
  67f276:	8b b4 24 80 07 00 00 	mov    0x780(%rsp),%esi
  67f27d:	8b 94 24 84 07 00 00 	mov    0x784(%rsp),%edx
  67f284:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  67f288:	39 f2                	cmp    %esi,%edx
  67f28a:	0f 82 f1 22 00 00    	jb     681581 <<gpui_canvas::text::planner::Planner>::shape+0x34a1>
  67f290:	49 39 d0             	cmp    %rdx,%r8
  67f293:	0f 82 e8 22 00 00    	jb     681581 <<gpui_canvas::text::planner::Planner>::shape+0x34a1>
  67f299:	39 f2                	cmp    %esi,%edx
  67f29b:	0f 84 dc 23 00 00    	je     68167d <<gpui_canvas::text::planner::Planner>::shape+0x359d>
  67f2a1:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  67f2a5:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  67f2a9:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  67f2af:	75 8f                	jne    67f240 <<gpui_canvas::text::planner::Planner>::shape+0x1160>
  67f2b1:	e9 af fe ff ff       	jmp    67f165 <<gpui_canvas::text::planner::Planner>::shape+0x1085>
  67f2b6:	0f 85 f2 1c 00 00    	jne    680fae <<gpui_canvas::text::planner::Planner>::shape+0x2ece>
  67f2bc:	4d 85 ed             	test   %r13,%r13
  67f2bf:	74 1e                	je     67f2df <<gpui_canvas::text::planner::Planner>::shape+0x11ff>
  67f2c1:	4c 3b 6c 24 08       	cmp    0x8(%rsp),%r13
  67f2c6:	73 11                	jae    67f2d9 <<gpui_canvas::text::planner::Planner>::shape+0x11f9>
  67f2c8:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  67f2cd:	42 80 3c 28 c0       	cmpb   $0xc0,(%rax,%r13,1)
  67f2d2:	7d 0b                	jge    67f2df <<gpui_canvas::text::planner::Planner>::shape+0x11ff>
  67f2d4:	e9 d5 1c 00 00       	jmp    680fae <<gpui_canvas::text::planner::Planner>::shape+0x2ece>
  67f2d9:	0f 85 cf 1c 00 00    	jne    680fae <<gpui_canvas::text::planner::Planner>::shape+0x2ece>
  67f2df:	0f 57 c0             	xorps  %xmm0,%xmm0
  67f2e2:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  67f2e9:	00 
  67f2ea:	48 3b 44 24 40       	cmp    0x40(%rsp),%rax
  67f2ef:	74 0d                	je     67f2fe <<gpui_canvas::text::planner::Planner>::shape+0x121e>
  67f2f1:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  67f2f8:	00 
  67f2f9:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  67f2fe:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  67f304:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  67f30b:	00 
  67f30c:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  67f311:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  67f316:	0f 29 8c 24 10 01 00 	movaps %xmm1,0x110(%rsp)
  67f31d:	00 
  67f31e:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  67f323:	0f 29 8c 24 90 02 00 	movaps %xmm1,0x290(%rsp)
  67f32a:	00 
  67f32b:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  67f332:	00 
  67f333:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  67f338:	0f 29 84 24 f0 01 00 	movaps %xmm0,0x1f0(%rsp)
  67f33f:	00 
  67f340:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  67f345:	f3 0f 58 44 24 24    	addss  0x24(%rsp),%xmm0
  67f34b:	f3 0f 11 84 24 80 00 	movss  %xmm0,0x80(%rsp)
  67f352:	00 00 
  67f354:	48 8b 9c 24 68 01 00 	mov    0x168(%rsp),%rbx
  67f35b:	00 
  67f35c:	48 3b 9c 24 58 01 00 	cmp    0x158(%rsp),%rbx
  67f363:	00 
  67f364:	75 0e                	jne    67f374 <<gpui_canvas::text::planner::Planner>::shape+0x1294>
  67f366:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
  67f36d:	00 
  67f36e:	ff 15 e4 7c 10 00    	call   *0x107ce4(%rip)        # 787058 <_DYNAMIC+0x4a0>
  67f374:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  67f379:	41 01 c6             	add    %eax,%r14d
  67f37c:	41 01 c5             	add    %eax,%r13d
  67f37f:	0f 28 94 24 90 02 00 	movaps 0x290(%rsp),%xmm2
  67f386:	00 
  67f387:	0f 28 c2             	movaps %xmm2,%xmm0
  67f38a:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  67f38f:	0f 28 c8             	movaps %xmm0,%xmm1
  67f392:	0f 55 ca             	andnps %xmm2,%xmm1
  67f395:	0f 54 84 24 10 01 00 	andps  0x110(%rsp),%xmm0
  67f39c:	00 
  67f39d:	0f 56 c1             	orps   %xmm1,%xmm0
  67f3a0:	f3 0f 10 4c 24 24    	movss  0x24(%rsp),%xmm1
  67f3a6:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  67f3aa:	0f 28 a4 24 f0 01 00 	movaps 0x1f0(%rsp),%xmm4
  67f3b1:	00 
  67f3b2:	0f 28 d4             	movaps %xmm4,%xmm2
  67f3b5:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  67f3ba:	0f 28 da             	movaps %xmm2,%xmm3
  67f3bd:	0f 55 dc             	andnps %xmm4,%xmm3
  67f3c0:	0f 54 94 24 00 01 00 	andps  0x100(%rsp),%xmm2
  67f3c7:	00 
  67f3c8:	0f 56 d3             	orps   %xmm3,%xmm2
  67f3cb:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  67f3cf:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  67f3d6:	00 
  67f3d7:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  67f3db:	44 89 34 c8          	mov    %r14d,(%rax,%rcx,8)
  67f3df:	44 89 6c c8 04       	mov    %r13d,0x4(%rax,%rcx,8)
  67f3e4:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  67f3ea:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  67f3f0:	f3 0f 10 84 24 80 00 	movss  0x80(%rsp),%xmm0
  67f3f7:	00 00 
  67f3f9:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  67f3ff:	f3 0f 10 44 24 30    	movss  0x30(%rsp),%xmm0
  67f405:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  67f40b:	48 ff c3             	inc    %rbx
  67f40e:	48 89 9c 24 68 01 00 	mov    %rbx,0x168(%rsp)
  67f415:	00 
  67f416:	44 89 ac 24 18 02 00 	mov    %r13d,0x218(%rsp)
  67f41d:	00 
  67f41e:	8b 4c 24 70          	mov    0x70(%rsp),%ecx
  67f422:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  67f429:	00 00 00 00 00 
  67f42e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  67f433:	48 89 84 24 08 07 00 	mov    %rax,0x708(%rsp)
  67f43a:	00 
  67f43b:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  67f442:	00 
  67f443:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  67f44a:	00 
  67f44b:	48 83 c0 70          	add    $0x70,%rax
  67f44f:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  67f456:	00 
  67f457:	89 8c 24 18 07 00 00 	mov    %ecx,0x718(%rsp)
  67f45e:	ff c1                	inc    %ecx
  67f460:	89 4c 24 70          	mov    %ecx,0x70(%rsp)
  67f464:	c6 84 24 c0 07 00 00 	movb   $0x2,0x7c0(%rsp)
  67f46b:	02 
  67f46c:	c7 84 24 c8 07 00 00 	movl   $0x0,0x7c8(%rsp)
  67f473:	00 00 00 00 
  67f477:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  67f47e:	00 
  67f47f:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
  67f486:	00 
  67f487:	e8 04 ae fe ff       	call   66a290 <<parley::layout::line::GlyphRunIter<()> as core::iter::traits::iterator::Iterator>::next>
  67f48c:	83 bc 24 a0 02 00 00 	cmpl   $0x1,0x2a0(%rsp)
  67f493:	01 
  67f494:	0f 85 89 0f 00 00    	jne    680423 <<gpui_canvas::text::planner::Planner>::shape+0x2343>
  67f49a:	48 8b 84 24 a8 02 00 	mov    0x2a8(%rsp),%rax
  67f4a1:	00 
  67f4a2:	48 85 c0             	test   %rax,%rax
  67f4a5:	0f 84 f3 1a 00 00    	je     680f9e <<gpui_canvas::text::planner::Planner>::shape+0x2ebe>
  67f4ab:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  67f4b2:	00 
  67f4b3:	41 0f 10 07          	movups (%r15),%xmm0
  67f4b7:	41 0f 10 4f 10       	movups 0x10(%r15),%xmm1
  67f4bc:	41 0f 10 57 20       	movups 0x20(%r15),%xmm2
  67f4c1:	41 0f 10 5f 30       	movups 0x30(%r15),%xmm3
  67f4c6:	48 8d 8c 24 f8 02 00 	lea    0x2f8(%rsp),%rcx
  67f4cd:	00 
  67f4ce:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  67f4d2:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  67f4d6:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  67f4da:	0f 11 01             	movups %xmm0,(%rcx)
  67f4dd:	4c 8b 9c 24 f8 02 00 	mov    0x2f8(%rsp),%r11
  67f4e4:	00 
  67f4e5:	49 8b 4b 30          	mov    0x30(%r11),%rcx
  67f4e9:	49 8b 73 38          	mov    0x38(%r11),%rsi
  67f4ed:	48 89 f2             	mov    %rsi,%rdx
  67f4f0:	48 29 ca             	sub    %rcx,%rdx
  67f4f3:	40 0f 92 c7          	setb   %dil
  67f4f7:	48 3b b0 d0 00 00 00 	cmp    0xd0(%rax),%rsi
  67f4fe:	40 0f 97 c6          	seta   %sil
  67f502:	48 01 c9             	add    %rcx,%rcx
  67f505:	48 03 88 c8 00 00 00 	add    0xc8(%rax),%rcx
  67f50c:	40 08 fe             	or     %dil,%sil
  67f50f:	40 84 f6             	test   %sil,%sil
  67f512:	be 00 00 00 00       	mov    $0x0,%esi
  67f517:	48 0f 45 d6          	cmovne %rsi,%rdx
  67f51b:	be 02 00 00 00       	mov    $0x2,%esi
  67f520:	48 0f 45 ce          	cmovne %rsi,%rcx
  67f524:	48 01 d2             	add    %rdx,%rdx
  67f527:	31 f6                	xor    %esi,%esi
  67f529:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  67f530:	48 39 f2             	cmp    %rsi,%rdx
  67f533:	74 10                	je     67f545 <<gpui_canvas::text::planner::Planner>::shape+0x1465>
  67f535:	66 83 3c 31 00       	cmpw   $0x0,(%rcx,%rsi,1)
  67f53a:	48 8d 76 02          	lea    0x2(%rsi),%rsi
  67f53e:	74 f0                	je     67f530 <<gpui_canvas::text::planner::Planner>::shape+0x1450>
  67f540:	e9 fb 16 00 00       	jmp    680c40 <<gpui_canvas::text::planner::Planner>::shape+0x2b60>
  67f545:	49 8b 4b 40          	mov    0x40(%r11),%rcx
  67f549:	48 3b 88 b8 00 00 00 	cmp    0xb8(%rax),%rcx
  67f550:	0f 83 a0 20 00 00    	jae    6815f6 <<gpui_canvas::text::planner::Planner>::shape+0x3516>
  67f556:	48 c1 e1 06          	shl    $0x6,%rcx
  67f55a:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  67f561:	48 8b 34 24          	mov    (%rsp),%rsi
  67f565:	83 3e 01             	cmpl   $0x1,(%rsi)
  67f568:	75 0f                	jne    67f579 <<gpui_canvas::text::planner::Planner>::shape+0x1499>
  67f56a:	48 8b 56 08          	mov    0x8(%rsi),%rdx
  67f56e:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  67f572:	75 05                	jne    67f579 <<gpui_canvas::text::planner::Planner>::shape+0x1499>
  67f574:	45 31 f6             	xor    %r14d,%r14d
  67f577:	eb 4c                	jmp    67f5c5 <<gpui_canvas::text::planner::Planner>::shape+0x14e5>
  67f579:	83 7e 10 01          	cmpl   $0x1,0x10(%rsi)
  67f57d:	75 10                	jne    67f58f <<gpui_canvas::text::planner::Planner>::shape+0x14af>
  67f57f:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  67f583:	41 be 01 00 00 00    	mov    $0x1,%r14d
  67f589:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  67f58d:	74 1e                	je     67f5ad <<gpui_canvas::text::planner::Planner>::shape+0x14cd>
  67f58f:	83 7e 20 01          	cmpl   $0x1,0x20(%rsi)
  67f593:	0f 85 91 1a 00 00    	jne    68102a <<gpui_canvas::text::planner::Planner>::shape+0x2f4a>
  67f599:	48 8b 56 28          	mov    0x28(%rsi),%rdx
  67f59d:	41 be 02 00 00 00    	mov    $0x2,%r14d
  67f5a3:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  67f5a7:	0f 85 7d 1a 00 00    	jne    68102a <<gpui_canvas::text::planner::Planner>::shape+0x2f4a>
  67f5ad:	41 8d 4e ff          	lea    -0x1(%r14),%ecx
  67f5b1:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
  67f5b8:	00 
  67f5b9:	48 0f ab ca          	bts    %rcx,%rdx
  67f5bd:	48 89 94 24 08 02 00 	mov    %rdx,0x208(%rsp)
  67f5c4:	00 
  67f5c5:	8b bc 24 18 03 00 00 	mov    0x318(%rsp),%edi
  67f5cc:	48 8b 70 58          	mov    0x58(%rax),%rsi
  67f5d0:	48 39 fe             	cmp    %rdi,%rsi
  67f5d3:	0f 86 cb 20 00 00    	jbe    6816a4 <<gpui_canvas::text::planner::Planner>::shape+0x35c4>
  67f5d9:	48 8b 94 24 08 03 00 	mov    0x308(%rsp),%rdx
  67f5e0:	00 
  67f5e1:	48 85 d2             	test   %rdx,%rdx
  67f5e4:	48 89 94 24 80 03 00 	mov    %rdx,0x380(%rsp)
  67f5eb:	00 
  67f5ec:	74 0a                	je     67f5f8 <<gpui_canvas::text::planner::Planner>::shape+0x1518>
  67f5ee:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  67f5f2:	48 83 c2 1c          	add    $0x1c,%rdx
  67f5f6:	eb 1b                	jmp    67f613 <<gpui_canvas::text::planner::Planner>::shape+0x1533>
  67f5f8:	48 8b 48 50          	mov    0x50(%rax),%rcx
  67f5fc:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  67f600:	48 c1 e6 04          	shl    $0x4,%rsi
  67f604:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
  67f608:	48 83 c2 54          	add    $0x54,%rdx
  67f60c:	48 01 f1             	add    %rsi,%rcx
  67f60f:	48 83 c1 50          	add    $0x50,%rcx
  67f613:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  67f61a:	00 
  67f61b:	48 89 b4 24 88 03 00 	mov    %rsi,0x388(%rsp)
  67f622:	00 
  67f623:	48 8b 70 68          	mov    0x68(%rax),%rsi
  67f627:	48 8b 78 70          	mov    0x70(%rax),%rdi
  67f62b:	4c 8b 80 80 00 00 00 	mov    0x80(%rax),%r8
  67f632:	4c 8b 88 88 00 00 00 	mov    0x88(%rax),%r9
  67f639:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  67f640:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  67f647:	8b 12                	mov    (%rdx),%edx
  67f649:	8b 09                	mov    (%rcx),%ecx
  67f64b:	4c 89 9c 24 40 02 00 	mov    %r11,0x240(%rsp)
  67f652:	00 
  67f653:	45 0f b6 9b 8c 00 00 	movzbl 0x8c(%r11),%r11d
  67f65a:	00 
  67f65b:	41 80 e3 01          	and    $0x1,%r11b
  67f65f:	89 d3                	mov    %edx,%ebx
  67f661:	29 cb                	sub    %ecx,%ebx
  67f663:	48 c7 84 24 b0 04 00 	movq   $0x0,0x4b0(%rsp)
  67f66a:	00 00 00 00 00 
  67f66f:	48 c7 84 24 d0 04 00 	movq   $0x0,0x4d0(%rsp)
  67f676:	00 00 00 00 00 
  67f67b:	c7 84 24 f0 04 00 00 	movl   $0x0,0x4f0(%rsp)
  67f682:	00 00 00 00 
  67f686:	89 9c 24 f4 04 00 00 	mov    %ebx,0x4f4(%rsp)
  67f68d:	48 89 b4 24 f8 04 00 	mov    %rsi,0x4f8(%rsp)
  67f694:	00 
  67f695:	48 89 bc 24 00 05 00 	mov    %rdi,0x500(%rsp)
  67f69c:	00 
  67f69d:	4c 89 84 24 08 05 00 	mov    %r8,0x508(%rsp)
  67f6a4:	00 
  67f6a5:	4c 89 8c 24 10 05 00 	mov    %r9,0x510(%rsp)
  67f6ac:	00 
  67f6ad:	4c 89 94 24 18 05 00 	mov    %r10,0x518(%rsp)
  67f6b4:	00 
  67f6b5:	48 89 84 24 20 05 00 	mov    %rax,0x520(%rsp)
  67f6bc:	00 
  67f6bd:	89 8c 24 28 05 00 00 	mov    %ecx,0x528(%rsp)
  67f6c4:	89 94 24 2c 05 00 00 	mov    %edx,0x52c(%rsp)
  67f6cb:	89 8c 24 30 05 00 00 	mov    %ecx,0x530(%rsp)
  67f6d2:	89 94 24 34 05 00 00 	mov    %edx,0x534(%rsp)
  67f6d9:	44 88 9c 24 38 05 00 	mov    %r11b,0x538(%rsp)
  67f6e0:	00 
  67f6e1:	f2 0f 10 84 24 28 03 	movsd  0x328(%rsp),%xmm0
  67f6e8:	00 00 
  67f6ea:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  67f6f1:	00 
  67f6f2:	8b 94 24 20 03 00 00 	mov    0x320(%rsp),%edx
  67f6f9:	8b 8c 24 24 03 00 00 	mov    0x324(%rsp),%ecx
  67f700:	48 8d bc 24 e8 03 00 	lea    0x3e8(%rsp),%rdi
  67f707:	00 
  67f708:	48 8d b4 24 f0 02 00 	lea    0x2f0(%rsp),%rsi
  67f70f:	00 
  67f710:	e8 cb 70 fe ff       	call   6667e0 <<parley::layout::run::Run<()>>::glyphs_in>
  67f715:	0f 28 94 24 d0 03 00 	movaps 0x3d0(%rsp),%xmm2
  67f71c:	00 
  67f71d:	0f 13 94 24 80 04 00 	movlps %xmm2,0x480(%rsp)
  67f724:	00 
  67f725:	4c 8b ac 24 e8 03 00 	mov    0x3e8(%rsp),%r13
  67f72c:	00 
  67f72d:	48 8b 84 24 f0 03 00 	mov    0x3f0(%rsp),%rax
  67f734:	00 
  67f735:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  67f73c:	00 
  67f73d:	0f b6 84 24 f8 03 00 	movzbl 0x3f8(%rsp),%eax
  67f744:	00 
  67f745:	8b 8c 24 fc 03 00 00 	mov    0x3fc(%rsp),%ecx
  67f74c:	89 8c 24 ac 01 00 00 	mov    %ecx,0x1ac(%rsp)
  67f753:	f2 0f 10 84 24 00 04 	movsd  0x400(%rsp),%xmm0
  67f75a:	00 00 
  67f75c:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  67f763:	00 
  67f764:	f3 0f 10 84 24 08 04 	movss  0x408(%rsp),%xmm0
  67f76b:	00 00 
  67f76d:	f3 0f 11 84 24 a8 01 	movss  %xmm0,0x1a8(%rsp)
  67f774:	00 00 
  67f776:	48 8b 8c 24 10 04 00 	mov    0x410(%rsp),%rcx
  67f77d:	00 
  67f77e:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
  67f785:	00 
  67f786:	48 8b 8c 24 18 04 00 	mov    0x418(%rsp),%rcx
  67f78d:	00 
  67f78e:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
  67f795:	00 
  67f796:	48 8b 94 24 20 04 00 	mov    0x420(%rsp),%rdx
  67f79d:	00 
  67f79e:	48 8b 9c 24 28 04 00 	mov    0x428(%rsp),%rbx
  67f7a5:	00 
  67f7a6:	48 8b 8c 24 30 04 00 	mov    0x430(%rsp),%rcx
  67f7ad:	00 
  67f7ae:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
  67f7b5:	00 
  67f7b6:	48 8b 8c 24 38 04 00 	mov    0x438(%rsp),%rcx
  67f7bd:	00 
  67f7be:	48 89 8c 24 30 01 00 	mov    %rcx,0x130(%rsp)
  67f7c5:	00 
  67f7c6:	8b 8c 24 40 04 00 00 	mov    0x440(%rsp),%ecx
  67f7cd:	48 89 8c 24 e8 01 00 	mov    %rcx,0x1e8(%rsp)
  67f7d4:	00 
  67f7d5:	8b 8c 24 44 04 00 00 	mov    0x444(%rsp),%ecx
  67f7dc:	48 89 8c 24 e0 01 00 	mov    %rcx,0x1e0(%rsp)
  67f7e3:	00 
  67f7e4:	8b 8c 24 48 04 00 00 	mov    0x448(%rsp),%ecx
  67f7eb:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
  67f7f2:	00 
  67f7f3:	8b 8c 24 4c 04 00 00 	mov    0x44c(%rsp),%ecx
  67f7fa:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  67f7ff:	f3 0f 10 84 24 50 04 	movss  0x450(%rsp),%xmm0
  67f806:	00 00 
  67f808:	f3 0f 11 84 24 b0 01 	movss  %xmm0,0x1b0(%rsp)
  67f80f:	00 00 
  67f811:	f3 0f 10 84 24 54 04 	movss  0x454(%rsp),%xmm0
  67f818:	00 00 
  67f81a:	f3 0f 11 44 24 5c    	movss  %xmm0,0x5c(%rsp)
  67f820:	48 8b 8c 24 58 04 00 	mov    0x458(%rsp),%rcx
  67f827:	00 
  67f828:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  67f82f:	00 
  67f830:	f3 0f 10 84 24 70 04 	movss  0x470(%rsp),%xmm0
  67f837:	00 00 
  67f839:	f3 0f 10 8c 24 6c 04 	movss  0x46c(%rsp),%xmm1
  67f840:	00 00 
  67f842:	f3 0f 11 84 24 28 02 	movss  %xmm0,0x228(%rsp)
  67f849:	00 00 
  67f84b:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  67f84f:	f3 0f 10 84 24 74 04 	movss  0x474(%rsp),%xmm0
  67f856:	00 00 
  67f858:	f3 0f 11 8c 24 24 02 	movss  %xmm1,0x224(%rsp)
  67f85f:	00 00 
  67f861:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  67f865:	f3 0f 11 84 24 1c 02 	movss  %xmm0,0x21c(%rsp)
  67f86c:	00 00 
  67f86e:	0f 28 c2             	movaps %xmm2,%xmm0
  67f871:	0f b6 8c 24 7c 04 00 	movzbl 0x47c(%rsp),%ecx
  67f878:	00 
  67f879:	88 8c 24 90 02 00 00 	mov    %cl,0x290(%rsp)
  67f880:	48 8b 8c 24 60 04 00 	mov    0x460(%rsp),%rcx
  67f887:	00 
  67f888:	48 89 8c 24 28 01 00 	mov    %rcx,0x128(%rsp)
  67f88f:	00 
  67f890:	8b 8c 24 68 04 00 00 	mov    0x468(%rsp),%ecx
  67f897:	89 8c 24 e0 00 00 00 	mov    %ecx,0xe0(%rsp)
  67f89e:	8b 8c 24 78 04 00 00 	mov    0x478(%rsp),%ecx
  67f8a5:	89 8c 24 20 02 00 00 	mov    %ecx,0x220(%rsp)
  67f8ac:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  67f8b0:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  67f8b7:	00 
  67f8b8:	48 89 94 24 f0 01 00 	mov    %rdx,0x1f0(%rsp)
  67f8bf:	00 
  67f8c0:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  67f8c4:	48 89 8c 24 90 03 00 	mov    %rcx,0x390(%rsp)
  67f8cb:	00 
  67f8cc:	4c 89 b4 24 60 02 00 	mov    %r14,0x260(%rsp)
  67f8d3:	00 
  67f8d4:	48 89 9c 24 d8 01 00 	mov    %rbx,0x1d8(%rsp)
  67f8db:	00 
  67f8dc:	eb 6d                	jmp    67f94b <<gpui_canvas::text::planner::Planner>::shape+0x186b>
  67f8de:	44 03 74 24 40       	add    0x40(%rsp),%r14d
  67f8e3:	0f 28 8c 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm1
  67f8ea:	00 
  67f8eb:	f3 0f 58 4c 24 24    	addss  0x24(%rsp),%xmm1
  67f8f1:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  67f8f8:	00 
  67f8f9:	48 89 d9             	mov    %rbx,%rcx
  67f8fc:	48 c1 e1 04          	shl    $0x4,%rcx
  67f900:	44 89 34 08          	mov    %r14d,(%rax,%rcx,1)
  67f904:	f3 0f 10 44 24 78    	movss  0x78(%rsp),%xmm0
  67f90a:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  67f910:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  67f916:	66 44 89 64 08 0c    	mov    %r12w,0xc(%rax,%rcx,1)
  67f91c:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  67f923:	00 
  67f924:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  67f928:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  67f92d:	48 ff c3             	inc    %rbx
  67f930:	48 89 9c 24 f8 00 00 	mov    %rbx,0xf8(%rsp)
  67f937:	00 
  67f938:	31 c0                	xor    %eax,%eax
  67f93a:	48 8b 9c 24 d8 01 00 	mov    0x1d8(%rsp),%rbx
  67f941:	00 
  67f942:	f3 0f 10 84 24 b4 01 	movss  0x1b4(%rsp),%xmm0
  67f949:	00 00 
  67f94b:	f3 0f 11 44 24 78    	movss  %xmm0,0x78(%rsp)
  67f951:	a8 01                	test   $0x1,%al
  67f953:	74 5b                	je     67f9b0 <<gpui_canvas::text::planner::Planner>::shape+0x18d0>
  67f955:	f3 0f 10 84 24 a8 01 	movss  0x1a8(%rsp),%xmm0
  67f95c:	00 00 
  67f95e:	f3 0f 11 84 24 00 01 	movss  %xmm0,0x100(%rsp)
  67f965:	00 00 
  67f967:	44 8b b4 24 ac 01 00 	mov    0x1ac(%rsp),%r14d
  67f96e:	00 
  67f96f:	0f 28 84 24 30 02 00 	movaps 0x230(%rsp),%xmm0
  67f976:	00 
  67f977:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  67f97e:	00 
  67f97f:	83 bc 24 e0 00 00 00 	cmpl   $0x0,0xe0(%rsp)
  67f986:	00 
  67f987:	74 74                	je     67f9fd <<gpui_canvas::text::planner::Planner>::shape+0x191d>
  67f989:	48 83 bc 24 80 00 00 	cmpq   $0x0,0x80(%rsp)
  67f990:	00 00 
  67f992:	74 7c                	je     67fa10 <<gpui_canvas::text::planner::Planner>::shape+0x1930>
  67f994:	0f 28 84 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm0
  67f99b:	00 
  67f99c:	f3 0f 11 84 24 dc 00 	movss  %xmm0,0xdc(%rsp)
  67f9a3:	00 00 
  67f9a5:	e9 9a 00 00 00       	jmp    67fa44 <<gpui_canvas::text::planner::Planner>::shape+0x1964>
  67f9aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  67f9b0:	4c 3b ac 24 c8 00 00 	cmp    0xc8(%rsp),%r13
  67f9b7:	00 
  67f9b8:	0f 84 58 01 00 00    	je     67fb16 <<gpui_canvas::text::planner::Planner>::shape+0x1a36>
  67f9be:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  67f9c5:	00 
  67f9c6:	45 8b 75 00          	mov    0x0(%r13),%r14d
  67f9ca:	f2 41 0f 10 45 04    	movsd  0x4(%r13),%xmm0
  67f9d0:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  67f9d7:	00 
  67f9d8:	f3 41 0f 10 45 0c    	movss  0xc(%r13),%xmm0
  67f9de:	f3 0f 11 84 24 00 01 	movss  %xmm0,0x100(%rsp)
  67f9e5:	00 00 
  67f9e7:	49 83 c5 10          	add    $0x10,%r13
  67f9eb:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  67f9f2:	00 
  67f9f3:	83 bc 24 e0 00 00 00 	cmpl   $0x0,0xe0(%rsp)
  67f9fa:	00 
  67f9fb:	75 8c                	jne    67f989 <<gpui_canvas::text::planner::Planner>::shape+0x18a9>
  67f9fd:	0f 28 84 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm0
  67fa04:	00 
  67fa05:	f3 0f 11 84 24 dc 00 	movss  %xmm0,0xdc(%rsp)
  67fa0c:	00 00 
  67fa0e:	eb 74                	jmp    67fa84 <<gpui_canvas::text::planner::Planner>::shape+0x19a4>
  67fa10:	f3 0f 10 84 24 b0 01 	movss  0x1b0(%rsp),%xmm0
  67fa17:	00 00 
  67fa19:	0f 28 c8             	movaps %xmm0,%xmm1
  67fa1c:	f3 0f 58 8c 24 c0 01 	addss  0x1c0(%rsp),%xmm1
  67fa23:	00 00 
  67fa25:	f3 0f 11 8c 24 dc 00 	movss  %xmm1,0xdc(%rsp)
  67fa2c:	00 00 
  67fa2e:	f3 0f 10 8c 24 00 01 	movss  0x100(%rsp),%xmm1
  67fa35:	00 00 
  67fa37:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  67fa3b:	f3 0f 11 8c 24 00 01 	movss  %xmm1,0x100(%rsp)
  67fa42:	00 00 
  67fa44:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  67fa4b:	00 
  67fa4c:	48 ff c2             	inc    %rdx
  67fa4f:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  67fa56:	00 
  67fa57:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  67fa5e:	00 
  67fa5f:	48 39 c2             	cmp    %rax,%rdx
  67fa62:	75 20                	jne    67fa84 <<gpui_canvas::text::planner::Planner>::shape+0x19a4>
  67fa64:	f3 0f 10 84 24 00 01 	movss  0x100(%rsp),%xmm0
  67fa6b:	00 00 
  67fa6d:	f3 0f 58 44 24 5c    	addss  0x5c(%rsp),%xmm0
  67fa73:	f3 0f 11 84 24 00 01 	movss  %xmm0,0x100(%rsp)
  67fa7a:	00 00 
  67fa7c:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  67fa83:	00 
  67fa84:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  67fa8b:	00 
  67fa8c:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  67fa93:	00 
  67fa94:	e8 67 26 00 00       	call   682100 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  67fa99:	83 bc 24 90 00 00 00 	cmpl   $0x1,0x90(%rsp)
  67faa0:	01 
  67faa1:	0f 85 e6 14 00 00    	jne    680f8d <<gpui_canvas::text::planner::Planner>::shape+0x2ead>
  67faa7:	f3 0f 10 44 24 78    	movss  0x78(%rsp),%xmm0
  67faad:	f3 0f 58 84 24 00 01 	addss  0x100(%rsp),%xmm0
  67fab4:	00 00 
  67fab6:	31 c0                	xor    %eax,%eax
  67fab8:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  67fabf:	00 
  67fac0:	48 3b 4c 24 40       	cmp    0x40(%rsp),%rcx
  67fac5:	0f 84 80 fe ff ff    	je     67f94b <<gpui_canvas::text::planner::Planner>::shape+0x186b>
  67facb:	f3 0f 11 84 24 b4 01 	movss  %xmm0,0x1b4(%rsp)
  67fad2:	00 00 
  67fad4:	4c 8b 8c 24 98 00 00 	mov    0x98(%rsp),%r9
  67fadb:	00 
  67fadc:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  67fae3:	00 
  67fae4:	49 39 c9             	cmp    %rcx,%r9
  67fae7:	0f 87 90 14 00 00    	ja     680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  67faed:	4d 85 c9             	test   %r9,%r9
  67faf0:	0f 84 01 05 00 00    	je     67fff7 <<gpui_canvas::text::planner::Planner>::shape+0x1f17>
  67faf6:	4c 3b 4c 24 08       	cmp    0x8(%rsp),%r9
  67fafb:	0f 83 f0 04 00 00    	jae    67fff1 <<gpui_canvas::text::planner::Planner>::shape+0x1f11>
  67fb01:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  67fb06:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  67fb0b:	0f 8f e6 04 00 00    	jg     67fff7 <<gpui_canvas::text::planner::Planner>::shape+0x1f17>
  67fb11:	e9 67 14 00 00       	jmp    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  67fb16:	4c 89 ac 24 c8 00 00 	mov    %r13,0xc8(%rsp)
  67fb1d:	00 
  67fb1e:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  67fb25:	01 
  67fb26:	74 1e                	je     67fb46 <<gpui_canvas::text::planner::Planner>::shape+0x1a66>
  67fb28:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  67fb2d:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  67fb34:	00 
  67fb35:	39 c1                	cmp    %eax,%ecx
  67fb37:	0f 83 53 01 00 00    	jae    67fc90 <<gpui_canvas::text::planner::Planner>::shape+0x1bb0>
  67fb3d:	ff c8                	dec    %eax
  67fb3f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  67fb44:	eb 18                	jmp    67fb5e <<gpui_canvas::text::planner::Planner>::shape+0x1a7e>
  67fb46:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  67fb4b:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
  67fb52:	00 
  67fb53:	39 d0                	cmp    %edx,%eax
  67fb55:	0f 83 50 01 00 00    	jae    67fcab <<gpui_canvas::text::planner::Planner>::shape+0x1bcb>
  67fb5b:	8d 48 01             	lea    0x1(%rax),%ecx
  67fb5e:	89 c7                	mov    %eax,%edi
  67fb60:	48 39 fb             	cmp    %rdi,%rbx
  67fb63:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  67fb6a:	00 
  67fb6b:	0f 86 b6 1a 00 00    	jbe    681627 <<gpui_canvas::text::planner::Planner>::shape+0x3547>
  67fb71:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  67fb75:	44 8b 6c c2 08       	mov    0x8(%rdx,%rax,8),%r13d
  67fb7a:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  67fb7f:	0f 85 6e 05 00 00    	jne    6800f3 <<gpui_canvas::text::planner::Planner>::shape+0x2013>
  67fb85:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  67fb89:	8b 50 0c             	mov    0xc(%rax),%edx
  67fb8c:	4a 8d 34 2a          	lea    (%rdx,%r13,1),%rsi
  67fb90:	48 3b b4 24 30 01 00 	cmp    0x130(%rsp),%rsi
  67fb97:	00 
  67fb98:	0f 87 d4 16 00 00    	ja     681272 <<gpui_canvas::text::planner::Planner>::shape+0x3192>
  67fb9e:	49 c1 e5 04          	shl    $0x4,%r13
  67fba2:	4c 03 ac 24 78 02 00 	add    0x278(%rsp),%r13
  67fba9:	00 
  67fbaa:	48 89 d0             	mov    %rdx,%rax
  67fbad:	48 c1 e0 04          	shl    $0x4,%rax
  67fbb1:	4c 01 e8             	add    %r13,%rax
  67fbb4:	0f 57 c0             	xorps  %xmm0,%xmm0
  67fbb7:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  67fbbe:	00 
  67fbbf:	48 85 d2             	test   %rdx,%rdx
  67fbc2:	0f 85 d5 06 00 00    	jne    68029d <<gpui_canvas::text::planner::Planner>::shape+0x21bd>
  67fbc8:	89 ca                	mov    %ecx,%edx
  67fbca:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  67fbd1:	00 
  67fbd2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  67fbd9:	1f 84 00 00 00 00 00 
  67fbe0:	f6 84 24 90 02 00 00 	testb  $0x1,0x290(%rsp)
  67fbe7:	01 
  67fbe8:	74 26                	je     67fc10 <<gpui_canvas::text::planner::Planner>::shape+0x1b30>
  67fbea:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  67fbef:	44 39 e1             	cmp    %r12d,%ecx
  67fbf2:	0f 83 d2 00 00 00    	jae    67fcca <<gpui_canvas::text::planner::Planner>::shape+0x1bea>
  67fbf8:	41 ff cc             	dec    %r12d
  67fbfb:	4c 89 e0             	mov    %r12,%rax
  67fbfe:	89 ca                	mov    %ecx,%edx
  67fc00:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  67fc05:	89 c1                	mov    %eax,%ecx
  67fc07:	eb 21                	jmp    67fc2a <<gpui_canvas::text::planner::Planner>::shape+0x1b4a>
  67fc09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  67fc10:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  67fc15:	39 d1                	cmp    %edx,%ecx
  67fc17:	0f 83 55 01 00 00    	jae    67fd72 <<gpui_canvas::text::planner::Planner>::shape+0x1c92>
  67fc1d:	8d 41 01             	lea    0x1(%rcx),%eax
  67fc20:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  67fc27:	00 
  67fc28:	89 c2                	mov    %eax,%edx
  67fc2a:	89 cf                	mov    %ecx,%edi
  67fc2c:	48 39 fb             	cmp    %rdi,%rbx
  67fc2f:	48 8b 8c 24 f0 01 00 	mov    0x1f0(%rsp),%rcx
  67fc36:	00 
  67fc37:	0f 86 ea 19 00 00    	jbe    681627 <<gpui_canvas::text::planner::Planner>::shape+0x3547>
  67fc3d:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  67fc41:	44 8b 6c c1 08       	mov    0x8(%rcx,%rax,8),%r13d
  67fc46:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  67fc4b:	0f 85 9a 04 00 00    	jne    6800eb <<gpui_canvas::text::planner::Planner>::shape+0x200b>
  67fc51:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  67fc55:	8b 78 0c             	mov    0xc(%rax),%edi
  67fc58:	4a 8d 34 2f          	lea    (%rdi,%r13,1),%rsi
  67fc5c:	48 3b b4 24 30 01 00 	cmp    0x130(%rsp),%rsi
  67fc63:	00 
  67fc64:	0f 87 08 16 00 00    	ja     681272 <<gpui_canvas::text::planner::Planner>::shape+0x3192>
  67fc6a:	49 c1 e5 04          	shl    $0x4,%r13
  67fc6e:	4c 03 ac 24 78 02 00 	add    0x278(%rsp),%r13
  67fc75:	00 
  67fc76:	48 89 f8             	mov    %rdi,%rax
  67fc79:	48 c1 e0 04          	shl    $0x4,%rax
  67fc7d:	4c 01 e8             	add    %r13,%rax
  67fc80:	89 d1                	mov    %edx,%ecx
  67fc82:	48 85 ff             	test   %rdi,%rdi
  67fc85:	0f 84 55 ff ff ff    	je     67fbe0 <<gpui_canvas::text::planner::Planner>::shape+0x1b00>
  67fc8b:	e9 d8 04 00 00       	jmp    680168 <<gpui_canvas::text::planner::Planner>::shape+0x2088>
  67fc90:	4c 89 e8             	mov    %r13,%rax
  67fc93:	3b 8c 24 e8 01 00 00 	cmp    0x1e8(%rsp),%ecx
  67fc9a:	0f 95 c2             	setne  %dl
  67fc9d:	84 94 24 e0 00 00 00 	test   %dl,0xe0(%rsp)
  67fca4:	75 4e                	jne    67fcf4 <<gpui_canvas::text::planner::Planner>::shape+0x1c14>
  67fca6:	e9 0f 06 00 00       	jmp    6802ba <<gpui_canvas::text::planner::Planner>::shape+0x21da>
  67fcab:	4c 89 e8             	mov    %r13,%rax
  67fcae:	3b 94 24 e0 01 00 00 	cmp    0x1e0(%rsp),%edx
  67fcb5:	0f 95 c1             	setne  %cl
  67fcb8:	84 8c 24 e0 00 00 00 	test   %cl,0xe0(%rsp)
  67fcbf:	0f 85 d7 00 00 00    	jne    67fd9c <<gpui_canvas::text::planner::Planner>::shape+0x1cbc>
  67fcc5:	e9 f0 05 00 00       	jmp    6802ba <<gpui_canvas::text::planner::Planner>::shape+0x21da>
  67fcca:	0f 57 c0             	xorps  %xmm0,%xmm0
  67fccd:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  67fcd4:	00 
  67fcd5:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  67fcdc:	00 
  67fcdd:	3b 8c 24 e8 01 00 00 	cmp    0x1e8(%rsp),%ecx
  67fce4:	0f 95 c2             	setne  %dl
  67fce7:	84 94 24 e0 00 00 00 	test   %dl,0xe0(%rsp)
  67fcee:	0f 84 c6 05 00 00    	je     6802ba <<gpui_canvas::text::planner::Planner>::shape+0x21da>
  67fcf4:	8d 79 ff             	lea    -0x1(%rcx),%edi
  67fcf7:	48 39 fb             	cmp    %rdi,%rbx
  67fcfa:	0f 86 c8 19 00 00    	jbe    6816c8 <<gpui_canvas::text::planner::Planner>::shape+0x35e8>
  67fd00:	3b bc 24 e8 01 00 00 	cmp    0x1e8(%rsp),%edi
  67fd07:	76 43                	jbe    67fd4c <<gpui_canvas::text::planner::Planner>::shape+0x1c6c>
  67fd09:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  67fd0d:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  67fd14:	00 
  67fd15:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  67fd19:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  67fd20:	48 39 fb             	cmp    %rdi,%rbx
  67fd23:	0f 86 1f 19 00 00    	jbe    681648 <<gpui_canvas::text::planner::Planner>::shape+0x3568>
  67fd29:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  67fd2d:	75 1d                	jne    67fd4c <<gpui_canvas::text::planner::Planner>::shape+0x1c6c>
  67fd2f:	48 ff cf             	dec    %rdi
  67fd32:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  67fd36:	39 bc 24 e8 01 00 00 	cmp    %edi,0x1e8(%rsp)
  67fd3d:	72 e1                	jb     67fd20 <<gpui_canvas::text::planner::Planner>::shape+0x1c40>
  67fd3f:	48 8b 94 24 e8 01 00 	mov    0x1e8(%rsp),%rdx
  67fd46:	00 
  67fd47:	48 89 d7             	mov    %rdx,%rdi
  67fd4a:	eb 02                	jmp    67fd4e <<gpui_canvas::text::planner::Planner>::shape+0x1c6e>
  67fd4c:	89 fa                	mov    %edi,%edx
  67fd4e:	48 39 fb             	cmp    %rdi,%rbx
  67fd51:	0f 86 7d 19 00 00    	jbe    6816d4 <<gpui_canvas::text::planner::Planner>::shape+0x35f4>
  67fd57:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  67fd5e:	00 
  67fd5f:	89 ca                	mov    %ecx,%edx
  67fd61:	48 ff ca             	dec    %rdx
  67fd64:	48 39 da             	cmp    %rbx,%rdx
  67fd67:	0f 82 a1 00 00 00    	jb     67fe0e <<gpui_canvas::text::planner::Planner>::shape+0x1d2e>
  67fd6d:	e9 6e 19 00 00       	jmp    6816e0 <<gpui_canvas::text::planner::Planner>::shape+0x3600>
  67fd72:	0f 57 c0             	xorps  %xmm0,%xmm0
  67fd75:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  67fd7c:	00 
  67fd7d:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  67fd84:	00 
  67fd85:	3b 94 24 e0 01 00 00 	cmp    0x1e0(%rsp),%edx
  67fd8c:	0f 95 c1             	setne  %cl
  67fd8f:	84 8c 24 e0 00 00 00 	test   %cl,0xe0(%rsp)
  67fd96:	0f 84 1e 05 00 00    	je     6802ba <<gpui_canvas::text::planner::Planner>::shape+0x21da>
  67fd9c:	49 89 d0             	mov    %rdx,%r8
  67fd9f:	48 89 d1             	mov    %rdx,%rcx
  67fda2:	89 cf                	mov    %ecx,%edi
  67fda4:	48 39 fb             	cmp    %rdi,%rbx
  67fda7:	0f 86 06 19 00 00    	jbe    6816b3 <<gpui_canvas::text::planner::Planner>::shape+0x35d3>
  67fdad:	ff c1                	inc    %ecx
  67fdaf:	3b 8c 24 e0 01 00 00 	cmp    0x1e0(%rsp),%ecx
  67fdb6:	73 40                	jae    67fdf8 <<gpui_canvas::text::planner::Planner>::shape+0x1d18>
  67fdb8:	89 ca                	mov    %ecx,%edx
  67fdba:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  67fdbe:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  67fdc5:	00 
  67fdc6:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  67fdca:	48 89 d1             	mov    %rdx,%rcx
  67fdcd:	0f 1f 00             	nopl   (%rax)
  67fdd0:	48 39 cb             	cmp    %rcx,%rbx
  67fdd3:	0f 86 57 18 00 00    	jbe    681630 <<gpui_canvas::text::planner::Planner>::shape+0x3550>
  67fdd9:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  67fddd:	75 19                	jne    67fdf8 <<gpui_canvas::text::planner::Planner>::shape+0x1d18>
  67fddf:	48 ff c1             	inc    %rcx
  67fde2:	48 83 c6 18          	add    $0x18,%rsi
  67fde6:	48 39 8c 24 e0 01 00 	cmp    %rcx,0x1e0(%rsp)
  67fded:	00 
  67fdee:	75 e0                	jne    67fdd0 <<gpui_canvas::text::planner::Planner>::shape+0x1cf0>
  67fdf0:	48 8b 8c 24 e0 01 00 	mov    0x1e0(%rsp),%rcx
  67fdf7:	00 
  67fdf8:	89 ca                	mov    %ecx,%edx
  67fdfa:	48 ff ca             	dec    %rdx
  67fdfd:	48 39 da             	cmp    %rbx,%rdx
  67fe00:	0f 83 b6 18 00 00    	jae    6816bc <<gpui_canvas::text::planner::Planner>::shape+0x35dc>
  67fe06:	4c 89 84 24 10 01 00 	mov    %r8,0x110(%rsp)
  67fe0d:	00 
  67fe0e:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  67fe13:	48 83 bc 24 68 02 00 	cmpq   $0x0,0x268(%rsp)
  67fe1a:	00 00 
  67fe1c:	0f 84 98 04 00 00    	je     6802ba <<gpui_canvas::text::planner::Planner>::shape+0x21da>
  67fe22:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  67fe26:	48 8b b4 24 f0 01 00 	mov    0x1f0(%rsp),%rsi
  67fe2d:	00 
  67fe2e:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  67fe31:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  67fe35:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  67fe39:	39 ce                	cmp    %ecx,%esi
  67fe3b:	0f 82 5b 17 00 00    	jb     68159c <<gpui_canvas::text::planner::Planner>::shape+0x34bc>
  67fe41:	48 39 b4 24 00 02 00 	cmp    %rsi,0x200(%rsp)
  67fe48:	00 
  67fe49:	0f 82 4d 17 00 00    	jb     68159c <<gpui_canvas::text::planner::Planner>::shape+0x34bc>
  67fe4f:	39 ce                	cmp    %ecx,%esi
  67fe51:	0f 84 3d 18 00 00    	je     681694 <<gpui_canvas::text::planner::Planner>::shape+0x35b4>
  67fe57:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  67fe5b:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  67fe62:	00 
  67fe63:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  67fe68:	8d 51 ff             	lea    -0x1(%rcx),%edx
  67fe6b:	83 fa 02             	cmp    $0x2,%edx
  67fe6e:	73 28                	jae    67fe98 <<gpui_canvas::text::planner::Planner>::shape+0x1db8>
  67fe70:	f3 0f 10 84 24 24 02 	movss  0x224(%rsp),%xmm0
  67fe77:	00 00 
  67fe79:	f3 0f 11 44 24 5c    	movss  %xmm0,0x5c(%rsp)
  67fe7f:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  67fe84:	3b 94 24 20 02 00 00 	cmp    0x220(%rsp),%edx
  67fe8b:	77 2d                	ja     67feba <<gpui_canvas::text::planner::Planner>::shape+0x1dda>
  67fe8d:	f3 0f 10 84 24 1c 02 	movss  0x21c(%rsp),%xmm0
  67fe94:	00 00 
  67fe96:	eb 1c                	jmp    67feb4 <<gpui_canvas::text::planner::Planner>::shape+0x1dd4>
  67fe98:	f3 0f 10 84 24 28 02 	movss  0x228(%rsp),%xmm0
  67fe9f:	00 00 
  67fea1:	f3 0f 11 44 24 5c    	movss  %xmm0,0x5c(%rsp)
  67fea7:	83 f9 06             	cmp    $0x6,%ecx
  67feaa:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  67feaf:	75 09                	jne    67feba <<gpui_canvas::text::planner::Planner>::shape+0x1dda>
  67feb1:	0f 57 c0             	xorps  %xmm0,%xmm0
  67feb4:	f3 0f 11 44 24 5c    	movss  %xmm0,0x5c(%rsp)
  67feba:	89 d6                	mov    %edx,%esi
  67febc:	48 39 f3             	cmp    %rsi,%rbx
  67febf:	0f 92 c1             	setb   %cl
  67fec2:	3b 94 24 10 01 00 00 	cmp    0x110(%rsp),%edx
  67fec9:	0f 82 09 01 00 00    	jb     67ffd8 <<gpui_canvas::text::planner::Planner>::shape+0x1ef8>
  67fecf:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  67fed6:	00 
  67fed7:	89 fa                	mov    %edi,%edx
  67fed9:	84 c9                	test   %cl,%cl
  67fedb:	0f 85 da 16 00 00    	jne    6815bb <<gpui_canvas::text::planner::Planner>::shape+0x34db>
  67fee1:	3b 7c 24 30          	cmp    0x30(%rsp),%edi
  67fee5:	75 11                	jne    67fef8 <<gpui_canvas::text::planner::Planner>::shape+0x1e18>
  67fee7:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
  67feee:	00 00 00 00 00 
  67fef3:	e9 b4 00 00 00       	jmp    67ffac <<gpui_canvas::text::planner::Planner>::shape+0x1ecc>
  67fef8:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  67feff:	00 
  67ff00:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  67ff04:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  67ff08:	48 39 d7             	cmp    %rdx,%rdi
  67ff0b:	75 10                	jne    67ff1d <<gpui_canvas::text::planner::Planner>::shape+0x1e3d>
  67ff0d:	31 d2                	xor    %edx,%edx
  67ff0f:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
  67ff16:	00 00 00 00 00 
  67ff1b:	eb 5e                	jmp    67ff7b <<gpui_canvas::text::planner::Planner>::shape+0x1e9b>
  67ff1d:	48 29 d6             	sub    %rdx,%rsi
  67ff20:	48 89 f7             	mov    %rsi,%rdi
  67ff23:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  67ff27:	48 8b 94 24 90 03 00 	mov    0x390(%rsp),%rdx
  67ff2e:	00 
  67ff2f:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  67ff33:	31 d2                	xor    %edx,%edx
  67ff35:	45 31 d2             	xor    %r10d,%r10d
  67ff38:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  67ff3e:	66 90                	xchg   %ax,%ax
  67ff40:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  67ff44:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  67ff49:	4d 0f 45 cb          	cmovne %r11,%r9
  67ff4d:	4d 01 d1             	add    %r10,%r9
  67ff50:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  67ff55:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  67ff59:	4d 0f 45 d3          	cmovne %r11,%r10
  67ff5d:	4d 01 ca             	add    %r9,%r10
  67ff60:	48 83 c2 02          	add    $0x2,%rdx
  67ff64:	49 83 c0 30          	add    $0x30,%r8
  67ff68:	48 39 d7             	cmp    %rdx,%rdi
  67ff6b:	75 d3                	jne    67ff40 <<gpui_canvas::text::planner::Planner>::shape+0x1e60>
  67ff6d:	4c 89 94 24 28 01 00 	mov    %r10,0x128(%rsp)
  67ff74:	00 
  67ff75:	40 f6 c6 01          	test   $0x1,%sil
  67ff79:	74 31                	je     67ffac <<gpui_canvas::text::planner::Planner>::shape+0x1ecc>
  67ff7b:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
  67ff82:	00 
  67ff83:	48 03 8c 24 f0 01 00 	add    0x1f0(%rsp),%rcx
  67ff8a:	00 
  67ff8b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  67ff8f:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  67ff94:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  67ff98:	b9 01 00 00 00       	mov    $0x1,%ecx
  67ff9d:	48 0f 45 d1          	cmovne %rcx,%rdx
  67ffa1:	48 01 f2             	add    %rsi,%rdx
  67ffa4:	48 89 94 24 28 01 00 	mov    %rdx,0x128(%rsp)
  67ffab:	00 
  67ffac:	0f 57 c0             	xorps  %xmm0,%xmm0
  67ffaf:	f3 0f 11 84 24 b0 01 	movss  %xmm0,0x1b0(%rsp)
  67ffb6:	00 00 
  67ffb8:	b9 00 00 00 00       	mov    $0x0,%ecx
  67ffbd:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  67ffc4:	00 
  67ffc5:	ba 00 00 00 00       	mov    $0x0,%edx
  67ffca:	49 39 c5             	cmp    %rax,%r13
  67ffcd:	0f 84 4b fb ff ff    	je     67fb1e <<gpui_canvas::text::planner::Planner>::shape+0x1a3e>
  67ffd3:	e9 ee f9 ff ff       	jmp    67f9c6 <<gpui_canvas::text::planner::Planner>::shape+0x18e6>
  67ffd8:	b1 01                	mov    $0x1,%cl
  67ffda:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  67ffe1:	00 
  67ffe2:	89 fa                	mov    %edi,%edx
  67ffe4:	84 c9                	test   %cl,%cl
  67ffe6:	0f 84 f5 fe ff ff    	je     67fee1 <<gpui_canvas::text::planner::Planner>::shape+0x1e01>
  67ffec:	e9 ca 15 00 00       	jmp    6815bb <<gpui_canvas::text::planner::Planner>::shape+0x34db>
  67fff1:	0f 85 86 0f 00 00    	jne    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  67fff7:	48 85 c9             	test   %rcx,%rcx
  67fffa:	41 0f 94 c4          	sete   %r12b
  67fffe:	74 1d                	je     68001d <<gpui_canvas::text::planner::Planner>::shape+0x1f3d>
  680000:	48 3b 4c 24 08       	cmp    0x8(%rsp),%rcx
  680005:	73 10                	jae    680017 <<gpui_canvas::text::planner::Planner>::shape+0x1f37>
  680007:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  68000c:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  680010:	7d 0b                	jge    68001d <<gpui_canvas::text::planner::Planner>::shape+0x1f3d>
  680012:	e9 66 0f 00 00       	jmp    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  680017:	0f 85 60 0f 00 00    	jne    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  68001d:	45 85 f6             	test   %r14d,%r14d
  680020:	0f 84 9c 00 00 00    	je     6800c2 <<gpui_canvas::text::planner::Planner>::shape+0x1fe2>
  680026:	f3 0f 10 44 24 78    	movss  0x78(%rsp),%xmm0
  68002c:	f3 0f 58 84 24 dc 00 	addss  0xdc(%rsp),%xmm0
  680033:	00 00 
  680035:	f3 0f 11 44 24 78    	movss  %xmm0,0x78(%rsp)
  68003b:	66 0f 7e c1          	movd   %xmm0,%ecx
  68003f:	0f 28 84 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm0
  680046:	00 
  680047:	0f 58 84 24 d0 03 00 	addps  0x3d0(%rsp),%xmm0
  68004e:	00 
  68004f:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  680053:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  68005a:	00 
  68005b:	66 0f 7e c0          	movd   %xmm0,%eax
  68005f:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  680065:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  68006a:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  68006f:	0f 9d c0             	setge  %al
  680072:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  680078:	0f 8f 20 0f 00 00    	jg     680f9e <<gpui_canvas::text::planner::Planner>::shape+0x2ebe>
  68007e:	84 c0                	test   %al,%al
  680080:	0f 85 18 0f 00 00    	jne    680f9e <<gpui_canvas::text::planner::Planner>::shape+0x2ebe>
  680086:	41 81 fe ff ff 00 00 	cmp    $0xffff,%r14d
  68008d:	0f 87 ea 0e 00 00    	ja     680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  680093:	45 89 f4             	mov    %r14d,%r12d
  680096:	4d 89 ce             	mov    %r9,%r14
  680099:	48 8b 9c 24 f8 00 00 	mov    0xf8(%rsp),%rbx
  6800a0:	00 
  6800a1:	48 3b 9c 24 e8 00 00 	cmp    0xe8(%rsp),%rbx
  6800a8:	00 
  6800a9:	0f 85 2f f8 ff ff    	jne    67f8de <<gpui_canvas::text::planner::Planner>::shape+0x17fe>
  6800af:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  6800b6:	00 
  6800b7:	ff 15 0b 6f 10 00    	call   *0x106f0b(%rip)        # 786fc8 <_DYNAMIC+0x410>
  6800bd:	e9 1c f8 ff ff       	jmp    67f8de <<gpui_canvas::text::planner::Planner>::shape+0x17fe>
  6800c2:	4d 85 c9             	test   %r9,%r9
  6800c5:	0f 84 b8 00 00 00    	je     680183 <<gpui_canvas::text::planner::Planner>::shape+0x20a3>
  6800cb:	4c 3b 4c 24 08       	cmp    0x8(%rsp),%r9
  6800d0:	0f 83 a7 00 00 00    	jae    68017d <<gpui_canvas::text::planner::Planner>::shape+0x209d>
  6800d6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6800db:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  6800e0:	0f 8f 9d 00 00 00    	jg     680183 <<gpui_canvas::text::planner::Planner>::shape+0x20a3>
  6800e6:	e9 e2 0f 00 00       	jmp    6810cd <<gpui_canvas::text::planner::Planner>::shape+0x2fed>
  6800eb:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  6800f2:	00 
  6800f3:	44 89 ee             	mov    %r13d,%esi
  6800f6:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  6800fa:	48 8b 94 24 f0 01 00 	mov    0x1f0(%rsp),%rdx
  680101:	00 
  680102:	f3 0f 10 44 c2 10    	movss  0x10(%rdx,%rax,8),%xmm0
  680108:	0f 57 c9             	xorps  %xmm1,%xmm1
  68010b:	0f 29 8c 24 c0 01 00 	movaps %xmm1,0x1c0(%rsp)
  680112:	00 
  680113:	41 bd 04 00 00 00    	mov    $0x4,%r13d
  680119:	b8 04 00 00 00       	mov    $0x4,%eax
  68011e:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  680125:	00 
  680126:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
  68012d:	00 
  68012e:	f3 0f 11 84 24 a8 01 	movss  %xmm0,0x1a8(%rsp)
  680135:	00 00 
  680137:	f3 0f 11 84 24 00 01 	movss  %xmm0,0x100(%rsp)
  68013e:	00 00 
  680140:	89 b4 24 ac 01 00 00 	mov    %esi,0x1ac(%rsp)
  680147:	41 89 f6             	mov    %esi,%r14d
  68014a:	0f 57 c0             	xorps  %xmm0,%xmm0
  68014d:	0f 29 84 24 30 02 00 	movaps %xmm0,0x230(%rsp)
  680154:	00 
  680155:	83 bc 24 e0 00 00 00 	cmpl   $0x0,0xe0(%rsp)
  68015c:	00 
  68015d:	0f 85 26 f8 ff ff    	jne    67f989 <<gpui_canvas::text::planner::Planner>::shape+0x18a9>
  680163:	e9 95 f8 ff ff       	jmp    67f9fd <<gpui_canvas::text::planner::Planner>::shape+0x191d>
  680168:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  68016f:	00 
  680170:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  680177:	00 
  680178:	e9 49 f8 ff ff       	jmp    67f9c6 <<gpui_canvas::text::planner::Planner>::shape+0x18e6>
  68017d:	0f 85 4a 0f 00 00    	jne    6810cd <<gpui_canvas::text::planner::Planner>::shape+0x2fed>
  680183:	48 85 c9             	test   %rcx,%rcx
  680186:	48 89 8c 24 48 02 00 	mov    %rcx,0x248(%rsp)
  68018d:	00 
  68018e:	74 1d                	je     6801ad <<gpui_canvas::text::planner::Planner>::shape+0x20cd>
  680190:	48 3b 4c 24 08       	cmp    0x8(%rsp),%rcx
  680195:	73 10                	jae    6801a7 <<gpui_canvas::text::planner::Planner>::shape+0x20c7>
  680197:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  68019c:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  6801a0:	7d 0b                	jge    6801ad <<gpui_canvas::text::planner::Planner>::shape+0x20cd>
  6801a2:	e9 36 0f 00 00       	jmp    6810dd <<gpui_canvas::text::planner::Planner>::shape+0x2ffd>
  6801a7:	0f 85 30 0f 00 00    	jne    6810dd <<gpui_canvas::text::planner::Planner>::shape+0x2ffd>
  6801ad:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6801b2:	4d 89 ce             	mov    %r9,%r14
  6801b5:	4a 8d 1c 08          	lea    (%rax,%r9,1),%rbx
  6801b9:	48 01 c8             	add    %rcx,%rax
  6801bc:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  6801c3:	00 
  6801c4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6801cb:	00 00 00 00 00 
  6801d0:	48 3b 9c 24 c0 01 00 	cmp    0x1c0(%rsp),%rbx
  6801d7:	00 
  6801d8:	0f 84 8c 00 00 00    	je     68026a <<gpui_canvas::text::planner::Planner>::shape+0x218a>
  6801de:	0f b6 33             	movzbl (%rbx),%esi
  6801e1:	40 84 f6             	test   %sil,%sil
  6801e4:	78 0a                	js     6801f0 <<gpui_canvas::text::planner::Planner>::shape+0x2110>
  6801e6:	48 ff c3             	inc    %rbx
  6801e9:	eb 65                	jmp    680250 <<gpui_canvas::text::planner::Planner>::shape+0x2170>
  6801eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6801f0:	89 f0                	mov    %esi,%eax
  6801f2:	83 e0 1f             	and    $0x1f,%eax
  6801f5:	0f b6 53 01          	movzbl 0x1(%rbx),%edx
  6801f9:	83 e2 3f             	and    $0x3f,%edx
  6801fc:	40 80 fe df          	cmp    $0xdf,%sil
  680200:	76 2c                	jbe    68022e <<gpui_canvas::text::planner::Planner>::shape+0x214e>
  680202:	0f b6 4b 02          	movzbl 0x2(%rbx),%ecx
  680206:	c1 e2 06             	shl    $0x6,%edx
  680209:	83 e1 3f             	and    $0x3f,%ecx
  68020c:	09 d1                	or     %edx,%ecx
  68020e:	40 80 fe f0          	cmp    $0xf0,%sil
  680212:	72 27                	jb     68023b <<gpui_canvas::text::planner::Planner>::shape+0x215b>
  680214:	0f b6 73 03          	movzbl 0x3(%rbx),%esi
  680218:	48 83 c3 04          	add    $0x4,%rbx
  68021c:	83 e0 07             	and    $0x7,%eax
  68021f:	c1 e0 12             	shl    $0x12,%eax
  680222:	c1 e1 06             	shl    $0x6,%ecx
  680225:	83 e6 3f             	and    $0x3f,%esi
  680228:	09 ce                	or     %ecx,%esi
  68022a:	09 c6                	or     %eax,%esi
  68022c:	eb 22                	jmp    680250 <<gpui_canvas::text::planner::Planner>::shape+0x2170>
  68022e:	48 83 c3 02          	add    $0x2,%rbx
  680232:	c1 e0 06             	shl    $0x6,%eax
  680235:	09 d0                	or     %edx,%eax
  680237:	89 c6                	mov    %eax,%esi
  680239:	eb 15                	jmp    680250 <<gpui_canvas::text::planner::Planner>::shape+0x2170>
  68023b:	48 83 c3 03          	add    $0x3,%rbx
  68023f:	c1 e0 0c             	shl    $0xc,%eax
  680242:	09 c1                	or     %eax,%ecx
  680244:	89 ce                	mov    %ecx,%esi
  680246:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  68024d:	00 00 00 
  680250:	48 8d 3d 51 ce 0f 00 	lea    0xfce51(%rip),%rdi        # 77d0a8 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x38>
  680257:	ff 15 8b 72 10 00    	call   *0x10728b(%rip)        # 7874e8 <_DYNAMIC+0x930>
  68025d:	84 c0                	test   %al,%al
  68025f:	0f 85 6b ff ff ff    	jne    6801d0 <<gpui_canvas::text::planner::Planner>::shape+0x20f0>
  680265:	e9 79 0e 00 00       	jmp    6810e3 <<gpui_canvas::text::planner::Planner>::shape+0x3003>
  68026a:	31 c0                	xor    %eax,%eax
  68026c:	0f 57 c0             	xorps  %xmm0,%xmm0
  68026f:	f3 0f 10 8c 24 00 01 	movss  0x100(%rsp),%xmm1
  680276:	00 00 
  680278:	0f 2e c8             	ucomiss %xmm0,%xmm1
  68027b:	48 8b 9c 24 d8 01 00 	mov    0x1d8(%rsp),%rbx
  680282:	00 
  680283:	f3 0f 10 84 24 b4 01 	movss  0x1b4(%rsp),%xmm0
  68028a:	00 00 
  68028c:	0f 85 51 0e 00 00    	jne    6810e3 <<gpui_canvas::text::planner::Planner>::shape+0x3003>
  680292:	0f 8b b3 f6 ff ff    	jnp    67f94b <<gpui_canvas::text::planner::Planner>::shape+0x186b>
  680298:	e9 46 0e 00 00       	jmp    6810e3 <<gpui_canvas::text::planner::Planner>::shape+0x3003>
  68029d:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  6802a4:	00 
  6802a5:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  6802ac:	00 
  6802ad:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
  6802b4:	00 
  6802b5:	e9 0c f7 ff ff       	jmp    67f9c6 <<gpui_canvas::text::planner::Planner>::shape+0x18e6>
  6802ba:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6802c1:	00 
  6802c2:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  6802c9:	00 
  6802ca:	e8 31 1e 00 00       	call   682100 <<core::iter::adapters::flatten::FlattenCompat<core::iter::adapters::map::Map<core::ops::range::Range<u32>, <parley::layout::run::Run<()>>::glyph_source_ranges::{closure#0}>, core::iter::sources::repeat_n::RepeatN<core::ops::range::Range<usize>>> as core::iter::traits::iterator::Iterator>::next>
  6802cf:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
  6802d6:	00 00 
  6802d8:	0f 85 9f 0c 00 00    	jne    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  6802de:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  6802e5:	00 
  6802e6:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6802ea:	0f 84 87 f1 ff ff    	je     67f477 <<gpui_canvas::text::planner::Planner>::shape+0x1397>
  6802f0:	48 8b 8c 24 90 01 00 	mov    0x190(%rsp),%rcx
  6802f7:	00 
  6802f8:	48 3b 4c 24 40       	cmp    0x40(%rsp),%rcx
  6802fd:	75 12                	jne    680311 <<gpui_canvas::text::planner::Planner>::shape+0x2231>
  6802ff:	31 db                	xor    %ebx,%ebx
  680301:	45 31 f6             	xor    %r14d,%r14d
  680304:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
  68030b:	00 
  68030c:	e9 81 00 00 00       	jmp    680392 <<gpui_canvas::text::planner::Planner>::shape+0x22b2>
  680311:	48 8b 8c 24 80 03 00 	mov    0x380(%rsp),%rcx
  680318:	00 
  680319:	48 85 c9             	test   %rcx,%rcx
  68031c:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
  680323:	00 
  680324:	48 0f 44 ca          	cmove  %rdx,%rcx
  680328:	48 8b 19             	mov    (%rcx),%rbx
  68032b:	4c 8b 71 08          	mov    0x8(%rcx),%r14
  68032f:	4c 39 f3             	cmp    %r14,%rbx
  680332:	0f 87 45 0c 00 00    	ja     680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  680338:	48 85 db             	test   %rbx,%rbx
  68033b:	74 1a                	je     680357 <<gpui_canvas::text::planner::Planner>::shape+0x2277>
  68033d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  680342:	48 39 cb             	cmp    %rcx,%rbx
  680345:	73 14                	jae    68035b <<gpui_canvas::text::planner::Planner>::shape+0x227b>
  680347:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  68034c:	80 3c 19 bf          	cmpb   $0xbf,(%rcx,%rbx,1)
  680350:	7f 12                	jg     680364 <<gpui_canvas::text::planner::Planner>::shape+0x2284>
  680352:	e9 26 0c 00 00       	jmp    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  680357:	31 db                	xor    %ebx,%ebx
  680359:	eb 09                	jmp    680364 <<gpui_canvas::text::planner::Planner>::shape+0x2284>
  68035b:	48 89 cb             	mov    %rcx,%rbx
  68035e:	0f 85 19 0c 00 00    	jne    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  680364:	4d 85 f6             	test   %r14,%r14
  680367:	74 1b                	je     680384 <<gpui_canvas::text::planner::Planner>::shape+0x22a4>
  680369:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  68036e:	49 39 ce             	cmp    %rcx,%r14
  680371:	73 16                	jae    680389 <<gpui_canvas::text::planner::Planner>::shape+0x22a9>
  680373:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  680378:	42 80 3c 31 c0       	cmpb   $0xc0,(%rcx,%r14,1)
  68037d:	7d 13                	jge    680392 <<gpui_canvas::text::planner::Planner>::shape+0x22b2>
  68037f:	e9 f9 0b 00 00       	jmp    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  680384:	45 31 f6             	xor    %r14d,%r14d
  680387:	eb 09                	jmp    680392 <<gpui_canvas::text::planner::Planner>::shape+0x22b2>
  680389:	49 89 ce             	mov    %rcx,%r14
  68038c:	0f 85 eb 0b 00 00    	jne    680f7d <<gpui_canvas::text::planner::Planner>::shape+0x2e9d>
  680392:	8b 8c 24 f8 00 00 00 	mov    0xf8(%rsp),%ecx
  680399:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
  68039d:	44 0f b6 aa 8c 00 00 	movzbl 0x8c(%rdx),%r13d
  6803a4:	00 
  6803a5:	4c 8b a4 24 50 01 00 	mov    0x150(%rsp),%r12
  6803ac:	00 
  6803ad:	49 39 c4             	cmp    %rax,%r12
  6803b0:	75 0e                	jne    6803c0 <<gpui_canvas::text::planner::Planner>::shape+0x22e0>
  6803b2:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
  6803b9:	00 
  6803ba:	ff 15 18 6c 10 00    	call   *0x106c18(%rip)        # 786fd8 <_DYNAMIC+0x420>
  6803c0:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6803c5:	01 c3                	add    %eax,%ebx
  6803c7:	41 01 c6             	add    %eax,%r14d
  6803ca:	41 80 e5 01          	and    $0x1,%r13b
  6803ce:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6803d5:	00 
  6803d6:	4b 8d 0c 64          	lea    (%r12,%r12,2),%rcx
  6803da:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  6803dd:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  6803e2:	48 8b 94 24 88 03 00 	mov    0x388(%rsp),%rdx
  6803e9:	00 
  6803ea:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  6803ee:	8b 54 24 30          	mov    0x30(%rsp),%edx
  6803f2:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  6803f6:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  6803fd:	00 
  6803fe:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  680402:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  680409:	00 
  68040a:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  68040e:	44 88 6c c8 15       	mov    %r13b,0x15(%rax,%rcx,8)
  680413:	49 ff c4             	inc    %r12
  680416:	4c 89 a4 24 50 01 00 	mov    %r12,0x150(%rsp)
  68041d:	00 
  68041e:	e9 54 f0 ff ff       	jmp    67f477 <<gpui_canvas::text::planner::Planner>::shape+0x1397>
  680423:	48 8b 84 24 98 03 00 	mov    0x398(%rsp),%rax
  68042a:	00 
  68042b:	48 39 84 24 d0 00 00 	cmp    %rax,0xd0(%rsp)
  680432:	00 
  680433:	48 8b 54 24 40       	mov    0x40(%rsp),%rdx
  680438:	4c 8b b4 24 90 01 00 	mov    0x190(%rsp),%r14
  68043f:	00 
  680440:	0f 85 c7 eb ff ff    	jne    67f00d <<gpui_canvas::text::planner::Planner>::shape+0xf2d>
  680446:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  68044d:	00 ff 
  68044f:	0f 84 10 06 00 00    	je     680a65 <<gpui_canvas::text::planner::Planner>::shape+0x2985>
  680455:	48 83 bc 24 70 01 00 	cmpq   $0xffffffffffffffff,0x170(%rsp)
  68045c:	00 ff 
  68045e:	0f 84 01 06 00 00    	je     680a65 <<gpui_canvas::text::planner::Planner>::shape+0x2985>
  680464:	4c 03 b4 24 38 01 00 	add    0x138(%rsp),%r14
  68046b:	00 
  68046c:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  680473:	00 00 00 00 00 
  680478:	48 c7 84 24 08 07 00 	movq   $0x8,0x708(%rsp)
  68047f:	00 08 00 00 00 
  680484:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  68048b:	00 00 00 00 00 
  680490:	c7 84 24 20 07 00 00 	movl   $0xffffffff,0x720(%rsp)
  680497:	ff ff ff ff 
  68049b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6804a0:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  6804a7:	00 
  6804a8:	4c 89 b4 24 30 07 00 	mov    %r14,0x730(%rsp)
  6804af:	00 
  6804b0:	48 c7 84 24 38 07 00 	movq   $0x0,0x738(%rsp)
  6804b7:	00 00 00 00 00 
  6804bc:	48 8d 05 55 cd 0f 00 	lea    0xfcd55(%rip),%rax        # 77d218 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x1a8>
  6804c3:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  6804ca:	00 
  6804cb:	48 8d 05 be b7 ff ff 	lea    -0x4842(%rip),%rax        # 67bc90 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  6804d2:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  6804d9:	00 
  6804da:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6804df:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  6804e6:	00 
  6804e7:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  6804ee:	00 00 00 00 00 
  6804f3:	48 c7 84 24 88 07 00 	movq   $0x0,0x788(%rsp)
  6804fa:	00 00 00 00 00 
  6804ff:	c6 84 24 90 07 00 00 	movb   $0x0,0x790(%rsp)
  680506:	00 
  680507:	31 db                	xor    %ebx,%ebx
  680509:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  680510:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  680517:	00 
  680518:	e8 43 f2 fe ff       	call   66f760 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  68051d:	48 83 f8 01          	cmp    $0x1,%rax
  680521:	75 05                	jne    680528 <<gpui_canvas::text::planner::Planner>::shape+0x2448>
  680523:	48 ff c3             	inc    %rbx
  680526:	eb e8                	jmp    680510 <<gpui_canvas::text::planner::Planner>::shape+0x2430>
  680528:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  68052f:	00 
  680530:	48 85 f6             	test   %rsi,%rsi
  680533:	74 17                	je     68054c <<gpui_canvas::text::planner::Planner>::shape+0x246c>
  680535:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  68053c:	00 
  68053d:	48 c1 e6 03          	shl    $0x3,%rsi
  680541:	ba 08 00 00 00       	mov    $0x8,%edx
  680546:	ff 15 a4 68 10 00    	call   *0x1068a4(%rip)        # 786df0 <_DYNAMIC+0x238>
  68054c:	48 83 fb 08          	cmp    $0x8,%rbx
  680550:	76 5e                	jbe    6805b0 <<gpui_canvas::text::planner::Planner>::shape+0x24d0>
  680552:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  680559:	00 
  68055a:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  68055f:	e8 ac 94 fe ff       	call   669a10 <<parley::editing::geometry::CursorGeometry<()>>::new>
  680564:	4c 8b ac 24 00 07 00 	mov    0x700(%rsp),%r13
  68056b:	00 
  68056c:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
  680570:	0f 84 bd 0c 00 00    	je     681233 <<gpui_canvas::text::planner::Planner>::shape+0x3153>
  680576:	48 8d 8c 24 20 07 00 	lea    0x720(%rsp),%rcx
  68057d:	00 
  68057e:	48 8b 41 10          	mov    0x10(%rcx),%rax
  680582:	49 89 47 20          	mov    %rax,0x20(%r15)
  680586:	0f 10 41 f0          	movups -0x10(%rcx),%xmm0
  68058a:	0f 10 09             	movups (%rcx),%xmm1
  68058d:	41 0f 11 4f 10       	movups %xmm1,0x10(%r15)
  680592:	41 0f 11 07          	movups %xmm0,(%r15)
  680596:	48 8b 84 24 08 07 00 	mov    0x708(%rsp),%rax
  68059d:	00 
  68059e:	4c 89 ac 24 a0 02 00 	mov    %r13,0x2a0(%rsp)
  6805a5:	00 
  6805a6:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  6805ad:	00 
  6805ae:	eb 13                	jmp    6805c3 <<gpui_canvas::text::planner::Planner>::shape+0x24e3>
  6805b0:	48 c7 84 24 a0 02 00 	movq   $0xffffffffffffffff,0x2a0(%rsp)
  6805b7:	00 ff ff ff ff 
  6805bc:	49 c7 c5 ff ff ff ff 	mov    $0xffffffffffffffff,%r13
  6805c3:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  6805ca:	00 00 00 00 00 
  6805cf:	48 c7 84 24 08 07 00 	movq   $0x8,0x708(%rsp)
  6805d6:	00 08 00 00 00 
  6805db:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  6805e2:	00 00 00 00 00 
  6805e7:	c7 84 24 20 07 00 00 	movl   $0xffffffff,0x720(%rsp)
  6805ee:	ff ff ff ff 
  6805f2:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6805f7:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  6805fe:	00 
  6805ff:	4c 89 b4 24 30 07 00 	mov    %r14,0x730(%rsp)
  680606:	00 
  680607:	48 c7 84 24 38 07 00 	movq   $0x0,0x738(%rsp)
  68060e:	00 00 00 00 00 
  680613:	48 8d 05 fe cb 0f 00 	lea    0xfcbfe(%rip),%rax        # 77d218 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x1a8>
  68061a:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  680621:	00 
  680622:	48 8d 05 67 b6 ff ff 	lea    -0x4999(%rip),%rax        # 67bc90 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  680629:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  680630:	00 
  680631:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  680636:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  68063d:	00 
  68063e:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  680645:	00 00 00 00 00 
  68064a:	48 c7 84 24 88 07 00 	movq   $0x0,0x788(%rsp)
  680651:	00 00 00 00 00 
  680656:	c6 84 24 90 07 00 00 	movb   $0x0,0x790(%rsp)
  68065d:	00 
  68065e:	f3 0f 10 44 24 24    	movss  0x24(%rsp),%xmm0
  680664:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  680668:	f2 0f 11 44 24 08    	movsd  %xmm0,0x8(%rsp)
  68066e:	66 90                	xchg   %ax,%ax
  680670:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  680677:	00 
  680678:	e8 e3 f0 fe ff       	call   66f760 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  68067d:	48 83 f8 01          	cmp    $0x1,%rax
  680681:	0f 85 71 03 00 00    	jne    6809f8 <<gpui_canvas::text::planner::Planner>::shape+0x2918>
  680687:	48 89 d3             	mov    %rdx,%rbx
  68068a:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
  68068e:	74 44                	je     6806d4 <<gpui_canvas::text::planner::Planner>::shape+0x25f4>
  680690:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  680697:	00 
  680698:	48 8d b4 24 a0 02 00 	lea    0x2a0(%rsp),%rsi
  68069f:	00 
  6806a0:	48 89 da             	mov    %rbx,%rdx
  6806a3:	f3 0f 10 05 91 cf 99 	movss  -0x66306f(%rip),%xmm0        # 1d63c <GCC_except_table0+0x1c>
  6806aa:	ff 
  6806ab:	e8 90 8c fe ff       	call   669340 <<parley::editing::geometry::CursorGeometry<()>>::geometries_at>
  6806b0:	80 bc 24 b0 04 00 00 	cmpb   $0x0,0x4b0(%rsp)
  6806b7:	00 
  6806b8:	74 b6                	je     680670 <<gpui_canvas::text::planner::Planner>::shape+0x2590>
  6806ba:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
  6806be:	0f 10 4d 10          	movups 0x10(%rbp),%xmm1
  6806c2:	0f 29 8c 24 00 03 00 	movaps %xmm1,0x300(%rsp)
  6806c9:	00 
  6806ca:	0f 29 84 24 f0 02 00 	movaps %xmm0,0x2f0(%rsp)
  6806d1:	00 
  6806d2:	eb 5b                	jmp    68072f <<gpui_canvas::text::planner::Planner>::shape+0x264f>
  6806d4:	48 c7 84 24 b0 04 00 	movq   $0x0,0x4b0(%rsp)
  6806db:	00 00 00 00 00 
  6806e0:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  6806e5:	48 89 de             	mov    %rbx,%rsi
  6806e8:	ba 01 00 00 00       	mov    $0x1,%edx
  6806ed:	e8 6e 82 fe ff       	call   668960 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6806f2:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6806f9:	00 
  6806fa:	80 e2 01             	and    $0x1,%dl
  6806fd:	88 94 24 98 00 00 00 	mov    %dl,0x98(%rsp)
  680704:	48 39 d8             	cmp    %rbx,%rax
  680707:	0f 85 bc 00 00 00    	jne    6807c9 <<gpui_canvas::text::planner::Planner>::shape+0x26e9>
  68070d:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
  680714:	00 
  680715:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  68071c:	00 
  68071d:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  680722:	f3 0f 10 05 12 cf 99 	movss  -0x6630ee(%rip),%xmm0        # 1d63c <GCC_except_table0+0x1c>
  680729:	ff 
  68072a:	e8 f1 82 fe ff       	call   668a20 <<parley::editing::cursor::Cursor>::geometry::<()>>
  68072f:	f2 0f 10 84 24 f8 02 	movsd  0x2f8(%rsp),%xmm0
  680736:	00 00 
  680738:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
  68073e:	66 0f 28 8c 24 f0 02 	movapd 0x2f0(%rsp),%xmm1
  680745:	00 00 
  680747:	66 0f 28 94 24 00 03 	movapd 0x300(%rsp),%xmm2
  68074e:	00 00 
  680750:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  680754:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  680758:	66 0f 5a d9          	cvtpd2ps %xmm1,%xmm3
  68075c:	66 0f 5a ca          	cvtpd2ps %xmm2,%xmm1
  680760:	66 0f 29 8c 24 90 01 	movapd %xmm1,0x190(%rsp)
  680767:	00 00 
  680769:	66 0f 14 d9          	unpcklpd %xmm1,%xmm3
  68076d:	66 0f 29 5c 24 30    	movapd %xmm3,0x30(%rsp)
  680773:	66 0f 28 cb          	movapd %xmm3,%xmm1
  680777:	66 0f 54 0d f1 4b 9a 	andpd  -0x65b40f(%rip),%xmm1        # 25370 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  68077e:	ff 
  68077f:	66 0f 66 0d b9 45 9a 	pcmpgtd -0x65ba47(%rip),%xmm1        # 24d40 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  680786:	ff 
  680787:	0f 50 c1             	movmskps %xmm1,%eax
  68078a:	85 c0                	test   %eax,%eax
  68078c:	0f 85 b8 08 00 00    	jne    68104a <<gpui_canvas::text::planner::Planner>::shape+0x2f6a>
  680792:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  680796:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  68079c:	41 b6 01             	mov    $0x1,%r14b
  68079f:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
  6807a3:	74 27                	je     6807cc <<gpui_canvas::text::planner::Planner>::shape+0x26ec>
  6807a5:	48 8d 84 24 d8 04 00 	lea    0x4d8(%rsp),%rax
  6807ac:	00 
  6807ad:	0f 10 00             	movups (%rax),%xmm0
  6807b0:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  6807b4:	0f 29 8c 24 00 03 00 	movaps %xmm1,0x300(%rsp)
  6807bb:	00 
  6807bc:	0f 29 84 24 f0 02 00 	movaps %xmm0,0x2f0(%rsp)
  6807c3:	00 
  6807c4:	41 b6 01             	mov    $0x1,%r14b
  6807c7:	eb 60                	jmp    680829 <<gpui_canvas::text::planner::Planner>::shape+0x2749>
  6807c9:	45 31 f6             	xor    %r14d,%r14d
  6807cc:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  6807d1:	48 89 de             	mov    %rbx,%rsi
  6807d4:	31 d2                	xor    %edx,%edx
  6807d6:	e8 85 81 fe ff       	call   668960 <<parley::editing::cursor::Cursor>::from_byte_index::<()>>
  6807db:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6807e2:	00 
  6807e3:	80 e2 01             	and    $0x1,%dl
  6807e6:	88 94 24 98 00 00 00 	mov    %dl,0x98(%rsp)
  6807ed:	48 39 d8             	cmp    %rbx,%rax
  6807f0:	74 15                	je     680807 <<gpui_canvas::text::planner::Planner>::shape+0x2727>
  6807f2:	45 84 f6             	test   %r14b,%r14b
  6807f5:	0f 84 75 fe ff ff    	je     680670 <<gpui_canvas::text::planner::Planner>::shape+0x2590>
  6807fb:	03 5c 24 40          	add    0x40(%rsp),%ebx
  6807ff:	45 31 f6             	xor    %r14d,%r14d
  680802:	e9 40 01 00 00       	jmp    680947 <<gpui_canvas::text::planner::Planner>::shape+0x2867>
  680807:	48 8d bc 24 f0 02 00 	lea    0x2f0(%rsp),%rdi
  68080e:	00 
  68080f:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
  680816:	00 
  680817:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  68081c:	f3 0f 10 05 18 ce 99 	movss  -0x6631e8(%rip),%xmm0        # 1d63c <GCC_except_table0+0x1c>
  680823:	ff 
  680824:	e8 f7 81 fe ff       	call   668a20 <<parley::editing::cursor::Cursor>::geometry::<()>>
  680829:	66 0f 28 5c 24 30    	movapd 0x30(%rsp),%xmm3
  68082f:	f2 0f 10 84 24 f8 02 	movsd  0x2f8(%rsp),%xmm0
  680836:	00 00 
  680838:	f2 0f 58 44 24 08    	addsd  0x8(%rsp),%xmm0
  68083e:	66 0f 28 8c 24 f0 02 	movapd 0x2f0(%rsp),%xmm1
  680845:	00 00 
  680847:	66 0f 28 94 24 00 03 	movapd 0x300(%rsp),%xmm2
  68084e:	00 00 
  680850:	66 0f 5c d1          	subpd  %xmm1,%xmm2
  680854:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  680858:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  68085c:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
  680860:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
  680864:	66 0f 29 8c 24 80 00 	movapd %xmm1,0x80(%rsp)
  68086b:	00 00 
  68086d:	66 0f 28 c1          	movapd %xmm1,%xmm0
  680871:	66 0f 54 05 f7 4a 9a 	andpd  -0x65b509(%rip),%xmm0        # 25370 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x7e0>
  680878:	ff 
  680879:	66 0f 66 05 bf 44 9a 	pcmpgtd -0x65bb41(%rip),%xmm0        # 24d40 <anon.1508e9dce0c1a49d095b8c30671814b4.0.llvm.16300762181250184790+0x1b0>
  680880:	ff 
  680881:	0f 50 c0             	movmskps %xmm0,%eax
  680884:	85 c0                	test   %eax,%eax
  680886:	0f 85 be 07 00 00    	jne    68104a <<gpui_canvas::text::planner::Planner>::shape+0x2f6a>
  68088c:	03 5c 24 40          	add    0x40(%rsp),%ebx
  680890:	45 84 f6             	test   %r14b,%r14b
  680893:	0f 84 99 00 00 00    	je     680932 <<gpui_canvas::text::planner::Planner>::shape+0x2852>
  680899:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
  6808a0:	00 
  6808a1:	0f 2e da             	ucomiss %xmm2,%xmm3
  6808a4:	41 b6 01             	mov    $0x1,%r14b
  6808a7:	0f 85 95 00 00 00    	jne    680942 <<gpui_canvas::text::planner::Planner>::shape+0x2862>
  6808ad:	0f 8a 8f 00 00 00    	jp     680942 <<gpui_canvas::text::planner::Planner>::shape+0x2862>
  6808b3:	0f 28 c2             	movaps %xmm2,%xmm0
  6808b6:	0f c6 c2 55          	shufps $0x55,%xmm2,%xmm0
  6808ba:	f3 0f 10 4c 24 10    	movss  0x10(%rsp),%xmm1
  6808c0:	0f 2e c8             	ucomiss %xmm0,%xmm1
  6808c3:	75 7d                	jne    680942 <<gpui_canvas::text::planner::Planner>::shape+0x2862>
  6808c5:	7a 7b                	jp     680942 <<gpui_canvas::text::planner::Planner>::shape+0x2862>
  6808c7:	0f 28 c2             	movaps %xmm2,%xmm0
  6808ca:	66 0f 15 c2          	unpckhpd %xmm2,%xmm0
  6808ce:	0f 28 8c 24 90 01 00 	movaps 0x190(%rsp),%xmm1
  6808d5:	00 
  6808d6:	0f 2e c8             	ucomiss %xmm0,%xmm1
  6808d9:	75 67                	jne    680942 <<gpui_canvas::text::planner::Planner>::shape+0x2862>
  6808db:	7a 65                	jp     680942 <<gpui_canvas::text::planner::Planner>::shape+0x2862>
  6808dd:	0f 28 c2             	movaps %xmm2,%xmm0
  6808e0:	0f c6 c2 ff          	shufps $0xff,%xmm2,%xmm0
  6808e4:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
  6808e8:	0f 2e c8             	ucomiss %xmm0,%xmm1
  6808eb:	75 55                	jne    680942 <<gpui_canvas::text::planner::Planner>::shape+0x2862>
  6808ed:	7a 53                	jp     680942 <<gpui_canvas::text::planner::Planner>::shape+0x2862>
  6808ef:	4c 8b a4 24 80 01 00 	mov    0x180(%rsp),%r12
  6808f6:	00 
  6808f7:	41 b6 03             	mov    $0x3,%r14b
  6808fa:	4c 3b a4 24 70 01 00 	cmp    0x170(%rsp),%r12
  680901:	00 
  680902:	0f 85 c1 00 00 00    	jne    6809c9 <<gpui_canvas::text::planner::Planner>::shape+0x28e9>
  680908:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  68090f:	00 
  680910:	f3 0f 11 9c 24 00 01 	movss  %xmm3,0x100(%rsp)
  680917:	00 00 
  680919:	ff 15 c1 66 10 00    	call   *0x1066c1(%rip)        # 786fe0 <_DYNAMIC+0x428>
  68091f:	f3 0f 10 9c 24 00 01 	movss  0x100(%rsp),%xmm3
  680926:	00 00 
  680928:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  68092d:	e9 9c 00 00 00       	jmp    6809ce <<gpui_canvas::text::planner::Planner>::shape+0x28ee>
  680932:	4c 8b a4 24 80 01 00 	mov    0x180(%rsp),%r12
  680939:	00 
  68093a:	66 0f 29 5c 24 30    	movapd %xmm3,0x30(%rsp)
  680940:	eb 58                	jmp    68099a <<gpui_canvas::text::planner::Planner>::shape+0x28ba>
  680942:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  680947:	4c 8b a4 24 80 01 00 	mov    0x180(%rsp),%r12
  68094e:	00 
  68094f:	4c 3b a4 24 70 01 00 	cmp    0x170(%rsp),%r12
  680956:	00 
  680957:	75 0e                	jne    680967 <<gpui_canvas::text::planner::Planner>::shape+0x2887>
  680959:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  680960:	00 
  680961:	ff 15 79 66 10 00    	call   *0x106679(%rip)        # 786fe0 <_DYNAMIC+0x428>
  680967:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  68096e:	00 
  68096f:	4b 8d 0c 64          	lea    (%r12,%r12,2),%rcx
  680973:	89 1c 88             	mov    %ebx,(%rax,%rcx,4)
  680976:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  68097b:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  680981:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  680986:	49 ff c4             	inc    %r12
  680989:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
  680990:	00 
  680991:	45 84 f6             	test   %r14b,%r14b
  680994:	0f 84 d6 fc ff ff    	je     680670 <<gpui_canvas::text::planner::Planner>::shape+0x2590>
  68099a:	41 b6 02             	mov    $0x2,%r14b
  68099d:	4c 3b a4 24 70 01 00 	cmp    0x170(%rsp),%r12
  6809a4:	00 
  6809a5:	75 18                	jne    6809bf <<gpui_canvas::text::planner::Planner>::shape+0x28df>
  6809a7:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  6809ae:	00 
  6809af:	ff 15 2b 66 10 00    	call   *0x10662b(%rip)        # 786fe0 <_DYNAMIC+0x428>
  6809b5:	0f 28 9c 24 80 00 00 	movaps 0x80(%rsp),%xmm3
  6809bc:	00 
  6809bd:	eb 0f                	jmp    6809ce <<gpui_canvas::text::planner::Planner>::shape+0x28ee>
  6809bf:	0f 28 9c 24 80 00 00 	movaps 0x80(%rsp),%xmm3
  6809c6:	00 
  6809c7:	eb 05                	jmp    6809ce <<gpui_canvas::text::planner::Planner>::shape+0x28ee>
  6809c9:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  6809ce:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  6809d5:	00 
  6809d6:	4b 8d 0c 64          	lea    (%r12,%r12,2),%rcx
  6809da:	89 1c 88             	mov    %ebx,(%rax,%rcx,4)
  6809dd:	f3 0f 11 5c 88 04    	movss  %xmm3,0x4(%rax,%rcx,4)
  6809e3:	44 88 74 88 08       	mov    %r14b,0x8(%rax,%rcx,4)
  6809e8:	49 ff c4             	inc    %r12
  6809eb:	4c 89 a4 24 80 01 00 	mov    %r12,0x180(%rsp)
  6809f2:	00 
  6809f3:	e9 78 fc ff ff       	jmp    680670 <<gpui_canvas::text::planner::Planner>::shape+0x2590>
  6809f8:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  6809ff:	00 
  680a00:	48 85 f6             	test   %rsi,%rsi
  680a03:	74 17                	je     680a1c <<gpui_canvas::text::planner::Planner>::shape+0x293c>
  680a05:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  680a0c:	00 
  680a0d:	48 c1 e6 03          	shl    $0x3,%rsi
  680a11:	ba 08 00 00 00       	mov    $0x8,%edx
  680a16:	ff 15 d4 63 10 00    	call   *0x1063d4(%rip)        # 786df0 <_DYNAMIC+0x238>
  680a1c:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
  680a20:	74 43                	je     680a65 <<gpui_canvas::text::planner::Planner>::shape+0x2985>
  680a22:	4d 85 ed             	test   %r13,%r13
  680a25:	74 1a                	je     680a41 <<gpui_canvas::text::planner::Planner>::shape+0x2961>
  680a27:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
  680a2e:	00 
  680a2f:	49 c1 e5 04          	shl    $0x4,%r13
  680a33:	ba 04 00 00 00       	mov    $0x4,%edx
  680a38:	4c 89 ee             	mov    %r13,%rsi
  680a3b:	ff 15 af 63 10 00    	call   *0x1063af(%rip)        # 786df0 <_DYNAMIC+0x238>
  680a41:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  680a48:	00 
  680a49:	48 85 f6             	test   %rsi,%rsi
  680a4c:	74 17                	je     680a65 <<gpui_canvas::text::planner::Planner>::shape+0x2985>
  680a4e:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  680a55:	00 
  680a56:	48 c1 e6 02          	shl    $0x2,%rsi
  680a5a:	ba 04 00 00 00       	mov    $0x4,%edx
  680a5f:	ff 15 8b 63 10 00    	call   *0x10638b(%rip)        # 786df0 <_DYNAMIC+0x238>
  680a65:	0f 28 9c 24 80 02 00 	movaps 0x280(%rsp),%xmm3
  680a6c:	00 
  680a6d:	0f 28 c3             	movaps %xmm3,%xmm0
  680a70:	f3 0f 5f 84 24 d8 00 	maxss  0xd8(%rsp),%xmm0
  680a77:	00 00 
  680a79:	0f 28 c8             	movaps %xmm0,%xmm1
  680a7c:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  680a81:	0f 28 d1             	movaps %xmm1,%xmm2
  680a84:	0f 55 d0             	andnps %xmm0,%xmm2
  680a87:	0f 54 cb             	andps  %xmm3,%xmm1
  680a8a:	0f 56 ca             	orps   %xmm2,%xmm1
  680a8d:	0f 29 8c 24 80 02 00 	movaps %xmm1,0x280(%rsp)
  680a94:	00 
  680a95:	48 8b 04 24          	mov    (%rsp),%rax
  680a99:	f3 0f 10 44 24 24    	movss  0x24(%rsp),%xmm0
  680a9f:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  680aa6:	00 
  680aa7:	f3 0f 11 44 24 24    	movss  %xmm0,0x24(%rsp)
  680aad:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  680ab2:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  680ab9:	00 
  680aba:	8b 74 24 74          	mov    0x74(%rsp),%esi
  680abe:	48 8b 94 24 a8 03 00 	mov    0x3a8(%rsp),%rdx
  680ac5:	00 
  680ac6:	0f 84 5c dc ff ff    	je     67e728 <<gpui_canvas::text::planner::Planner>::shape+0x648>
  680acc:	e9 fb 04 00 00       	jmp    680fcc <<gpui_canvas::text::planner::Planner>::shape+0x2eec>
  680ad1:	48 8b 0c 24          	mov    (%rsp),%rcx
  680ad5:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  680adc:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  680ae3:	70 
  680ae4:	48 01 c1             	add    %rax,%rcx
  680ae7:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
  680aee:	00 
  680aef:	48 89 8c 24 08 07 00 	mov    %rcx,0x708(%rsp)
  680af6:	00 
  680af7:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  680afe:	00 00 00 00 00 
  680b03:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  680b08:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  680b0f:	00 
  680b10:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  680b17:	00 
  680b18:	31 f6                	xor    %esi,%esi
  680b1a:	48 8d 94 24 e7 00 00 	lea    0xe7(%rsp),%rdx
  680b21:	00 
  680b22:	e8 a9 42 fe ff       	call   664dd0 <<core::iter::adapters::map::Map<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineData>>, <parley::layout::layout::Layout<()>>::lines::{closure#0}>, <gpui_canvas::text::planner::Planner>::shape_inner::{closure#3}> as core::iter::traits::iterator::Iterator>::fold::<usize, <core::iter::adapters::flatten::FlattenCompat<_, _>>::iter_fold::flatten<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>, usize, <core::iter::adapters::flatten::FlattenCompat<_, _> as core::iter::traits::iterator::Iterator>::count::count<core::iter::adapters::filter_map::FilterMap<core::iter::adapters::map::Map<core::iter::adapters::enumerate::Enumerate<core::slice::iter::Iter<parley::layout::data::LineItemData>>, <parley::layout::line::Line<()>>::items_nonpositioned::{closure#0}>, <parley::layout::line::Line<()>>::runs::{closure#0}>>>::{closure#0}>>
  680b27:	48 83 f8 02          	cmp    $0x2,%rax
  680b2b:	0f 82 9f e2 ff ff    	jb     67edd0 <<gpui_canvas::text::planner::Planner>::shape+0xcf0>
  680b31:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  680b38:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  680b3f:	00 ff 
  680b41:	0f 84 0f e2 ff ff    	je     67ed56 <<gpui_canvas::text::planner::Planner>::shape+0xc76>
  680b47:	e9 84 e2 ff ff       	jmp    67edd0 <<gpui_canvas::text::planner::Planner>::shape+0xcf0>
  680b4c:	c7 44 24 74 ff ff ff 	movl   $0xffffffff,0x74(%rsp)
  680b53:	ff 
  680b54:	e9 35 de ff ff       	jmp    67e98e <<gpui_canvas::text::planner::Planner>::shape+0x8ae>
  680b59:	45 89 d9             	mov    %r11d,%r9d
  680b5c:	41 83 e1 1f          	and    $0x1f,%r9d
  680b60:	41 0f b6 7a 01       	movzbl 0x1(%r10),%edi
  680b65:	83 e7 3f             	and    $0x3f,%edi
  680b68:	41 80 fb df          	cmp    $0xdf,%r11b
  680b6c:	76 33                	jbe    680ba1 <<gpui_canvas::text::planner::Planner>::shape+0x2ac1>
  680b6e:	41 0f b6 72 02       	movzbl 0x2(%r10),%esi
  680b73:	c1 e7 06             	shl    $0x6,%edi
  680b76:	83 e6 3f             	and    $0x3f,%esi
  680b79:	09 fe                	or     %edi,%esi
  680b7b:	41 80 fb f0          	cmp    $0xf0,%r11b
  680b7f:	72 30                	jb     680bb1 <<gpui_canvas::text::planner::Planner>::shape+0x2ad1>
  680b81:	4d 8d 72 04          	lea    0x4(%r10),%r14
  680b85:	45 0f b6 5a 03       	movzbl 0x3(%r10),%r11d
  680b8a:	41 83 e1 07          	and    $0x7,%r9d
  680b8e:	41 c1 e1 12          	shl    $0x12,%r9d
  680b92:	c1 e6 06             	shl    $0x6,%esi
  680b95:	41 83 e3 3f          	and    $0x3f,%r11d
  680b99:	41 09 f3             	or     %esi,%r11d
  680b9c:	45 09 cb             	or     %r9d,%r11d
  680b9f:	eb 1e                	jmp    680bbf <<gpui_canvas::text::planner::Planner>::shape+0x2adf>
  680ba1:	4d 8d 72 02          	lea    0x2(%r10),%r14
  680ba5:	41 c1 e1 06          	shl    $0x6,%r9d
  680ba9:	41 09 f9             	or     %edi,%r9d
  680bac:	45 89 cb             	mov    %r9d,%r11d
  680baf:	eb 0e                	jmp    680bbf <<gpui_canvas::text::planner::Planner>::shape+0x2adf>
  680bb1:	4d 8d 72 03          	lea    0x3(%r10),%r14
  680bb5:	41 c1 e1 0c          	shl    $0xc,%r9d
  680bb9:	44 09 ce             	or     %r9d,%esi
  680bbc:	41 89 f3             	mov    %esi,%r11d
  680bbf:	4d 8d 48 02          	lea    0x2(%r8),%r9
  680bc3:	4c 89 c1             	mov    %r8,%rcx
  680bc6:	48 89 c6             	mov    %rax,%rsi
  680bc9:	4c 29 d6             	sub    %r10,%rsi
  680bcc:	4c 01 f6             	add    %r14,%rsi
  680bcf:	41 83 fb 0a          	cmp    $0xa,%r11d
  680bd3:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  680bd8:	44 0f 44 df          	cmove  %edi,%r11d
  680bdc:	44 89 5c 24 74       	mov    %r11d,0x74(%rsp)
  680be1:	49 0f 44 d9          	cmove  %r9,%rbx
  680be5:	c7 44 24 4c 00 00 00 	movl   $0x0,0x4c(%rsp)
  680bec:	00 
  680bed:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  680bf4:	00 
  680bf5:	48 89 f0             	mov    %rsi,%rax
  680bf8:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
  680bfd:	48 89 ce             	mov    %rcx,%rsi
  680c00:	48 29 d6             	sub    %rdx,%rsi
  680c03:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  680c08:	0f 83 9c dd ff ff    	jae    67e9aa <<gpui_canvas::text::planner::Planner>::shape+0x8ca>
  680c0e:	e9 f5 09 00 00       	jmp    681608 <<gpui_canvas::text::planner::Planner>::shape+0x3528>
  680c13:	b9 04 00 00 00       	mov    $0x4,%ecx
  680c18:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  680c1e:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
  680c25:	00 
  680c26:	4c 89 ea             	mov    %r13,%rdx
  680c29:	e8 f2 0b fe ff       	call   661820 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  680c2e:	e9 05 e3 ff ff       	jmp    67ef38 <<gpui_canvas::text::planner::Planner>::shape+0xe58>
  680c33:	c7 84 24 98 00 00 00 	movl   $0x7,0x98(%rsp)
  680c3a:	07 00 00 00 
  680c3e:	eb 0b                	jmp    680c4b <<gpui_canvas::text::planner::Planner>::shape+0x2b6b>
  680c40:	c7 84 24 98 00 00 00 	movl   $0x4,0x98(%rsp)
  680c47:	04 00 00 00 
  680c4b:	48 c7 84 24 90 00 00 	movq   $0xffffffffffffffff,0x90(%rsp)
  680c52:	00 ff ff ff ff 
  680c57:	48 8b 2c 24          	mov    (%rsp),%rbp
  680c5b:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  680c62:	00 
  680c63:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  680c67:	74 76                	je     680cdf <<gpui_canvas::text::planner::Planner>::shape+0x2bff>
  680c69:	48 85 c0             	test   %rax,%rax
  680c6c:	74 1b                	je     680c89 <<gpui_canvas::text::planner::Planner>::shape+0x2ba9>
  680c6e:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  680c75:	00 
  680c76:	48 c1 e0 03          	shl    $0x3,%rax
  680c7a:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  680c7e:	ba 04 00 00 00       	mov    $0x4,%edx
  680c83:	ff 15 67 61 10 00    	call   *0x106167(%rip)        # 786df0 <_DYNAMIC+0x238>
  680c89:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  680c90:	00 
  680c91:	48 85 c0             	test   %rax,%rax
  680c94:	74 1b                	je     680cb1 <<gpui_canvas::text::planner::Planner>::shape+0x2bd1>
  680c96:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  680c9d:	00 
  680c9e:	48 c1 e0 03          	shl    $0x3,%rax
  680ca2:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  680ca6:	ba 04 00 00 00       	mov    $0x4,%edx
  680cab:	ff 15 3f 61 10 00    	call   *0x10613f(%rip)        # 786df0 <_DYNAMIC+0x238>
  680cb1:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  680cb8:	00 
  680cb9:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  680cbd:	74 20                	je     680cdf <<gpui_canvas::text::planner::Planner>::shape+0x2bff>
  680cbf:	48 85 c0             	test   %rax,%rax
  680cc2:	74 1b                	je     680cdf <<gpui_canvas::text::planner::Planner>::shape+0x2bff>
  680cc4:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
  680ccb:	00 
  680ccc:	48 c1 e0 02          	shl    $0x2,%rax
  680cd0:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  680cd4:	ba 04 00 00 00       	mov    $0x4,%edx
  680cd9:	ff 15 11 61 10 00    	call   *0x106111(%rip)        # 786df0 <_DYNAMIC+0x238>
  680cdf:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  680ce6:	00 
  680ce7:	48 85 f6             	test   %rsi,%rsi
  680cea:	74 17                	je     680d03 <<gpui_canvas::text::planner::Planner>::shape+0x2c23>
  680cec:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  680cf3:	00 
  680cf4:	48 c1 e6 04          	shl    $0x4,%rsi
  680cf8:	ba 04 00 00 00       	mov    $0x4,%edx
  680cfd:	ff 15 ed 60 10 00    	call   *0x1060ed(%rip)        # 786df0 <_DYNAMIC+0x238>
  680d03:	48 8b b4 24 38 03 00 	mov    0x338(%rsp),%rsi
  680d0a:	00 
  680d0b:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  680d0f:	77 18                	ja     680d29 <<gpui_canvas::text::planner::Planner>::shape+0x2c49>
  680d11:	48 85 f6             	test   %rsi,%rsi
  680d14:	74 13                	je     680d29 <<gpui_canvas::text::planner::Planner>::shape+0x2c49>
  680d16:	48 8b bc 24 40 03 00 	mov    0x340(%rsp),%rdi
  680d1d:	00 
  680d1e:	ba 01 00 00 00       	mov    $0x1,%edx
  680d23:	ff 15 c7 60 10 00    	call   *0x1060c7(%rip)        # 786df0 <_DYNAMIC+0x238>
  680d29:	48 8b b4 24 50 03 00 	mov    0x350(%rsp),%rsi
  680d30:	00 
  680d31:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  680d35:	77 18                	ja     680d4f <<gpui_canvas::text::planner::Planner>::shape+0x2c6f>
  680d37:	48 85 f6             	test   %rsi,%rsi
  680d3a:	74 13                	je     680d4f <<gpui_canvas::text::planner::Planner>::shape+0x2c6f>
  680d3c:	48 8b bc 24 58 03 00 	mov    0x358(%rsp),%rdi
  680d43:	00 
  680d44:	ba 01 00 00 00       	mov    $0x1,%edx
  680d49:	ff 15 a1 60 10 00    	call   *0x1060a1(%rip)        # 786df0 <_DYNAMIC+0x238>
  680d4f:	48 8b b4 24 68 03 00 	mov    0x368(%rsp),%rsi
  680d56:	00 
  680d57:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  680d5b:	77 18                	ja     680d75 <<gpui_canvas::text::planner::Planner>::shape+0x2c95>
  680d5d:	48 85 f6             	test   %rsi,%rsi
  680d60:	74 13                	je     680d75 <<gpui_canvas::text::planner::Planner>::shape+0x2c95>
  680d62:	48 8b bc 24 70 03 00 	mov    0x370(%rsp),%rdi
  680d69:	00 
  680d6a:	ba 01 00 00 00       	mov    $0x1,%edx
  680d6f:	ff 15 7b 60 10 00    	call   *0x10607b(%rip)        # 786df0 <_DYNAMIC+0x238>
  680d75:	48 8d bd c8 08 00 00 	lea    0x8c8(%rbp),%rdi
  680d7c:	e8 bf b7 ff ff       	call   67c540 <core::ptr::drop_glue::<parley::layout::layout::Layout<()>>>
  680d81:	48 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%rbp)
  680d88:	00 00 00 00 
  680d8c:	48 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%rbp)
  680d93:	04 00 00 00 
  680d97:	0f 57 c0             	xorps  %xmm0,%xmm0
  680d9a:	0f 11 85 d8 08 00 00 	movups %xmm0,0x8d8(%rbp)
  680da1:	48 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%rbp)
  680da8:	04 00 00 00 
  680dac:	0f 11 85 f0 08 00 00 	movups %xmm0,0x8f0(%rbp)
  680db3:	48 c7 85 00 09 00 00 	movq   $0x8,0x900(%rbp)
  680dba:	08 00 00 00 
  680dbe:	0f 11 85 08 09 00 00 	movups %xmm0,0x908(%rbp)
  680dc5:	48 c7 85 18 09 00 00 	movq   $0x8,0x918(%rbp)
  680dcc:	08 00 00 00 
  680dd0:	0f 11 85 20 09 00 00 	movups %xmm0,0x920(%rbp)
  680dd7:	48 c7 85 30 09 00 00 	movq   $0x4,0x930(%rbp)
  680dde:	04 00 00 00 
  680de2:	0f 11 85 38 09 00 00 	movups %xmm0,0x938(%rbp)
  680de9:	48 c7 85 48 09 00 00 	movq   $0x4,0x948(%rbp)
  680df0:	04 00 00 00 
  680df4:	0f 11 85 50 09 00 00 	movups %xmm0,0x950(%rbp)
  680dfb:	48 c7 85 60 09 00 00 	movq   $0x4,0x960(%rbp)
  680e02:	04 00 00 00 
  680e06:	0f 11 85 68 09 00 00 	movups %xmm0,0x968(%rbp)
  680e0d:	48 c7 85 78 09 00 00 	movq   $0x8,0x978(%rbp)
  680e14:	08 00 00 00 
  680e18:	0f 11 85 80 09 00 00 	movups %xmm0,0x980(%rbp)
  680e1f:	48 c7 85 90 09 00 00 	movq   $0x2,0x990(%rbp)
  680e26:	02 00 00 00 
  680e2a:	0f 11 85 98 09 00 00 	movups %xmm0,0x998(%rbp)
  680e31:	48 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%rbp)
  680e38:	04 00 00 00 
  680e3c:	0f 11 85 b0 09 00 00 	movups %xmm0,0x9b0(%rbp)
  680e43:	48 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%rbp)
  680e4a:	08 00 00 00 
  680e4e:	0f 11 85 c8 09 00 00 	movups %xmm0,0x9c8(%rbp)
  680e55:	48 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%rbp)
  680e5c:	08 00 00 00 
  680e60:	0f 11 85 e0 09 00 00 	movups %xmm0,0x9e0(%rbp)
  680e67:	48 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%rbp)
  680e6e:	08 00 00 00 
  680e72:	0f 11 85 f8 09 00 00 	movups %xmm0,0x9f8(%rbp)
  680e79:	48 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%rbp)
  680e80:	04 00 00 00 
  680e84:	0f 11 85 10 0a 00 00 	movups %xmm0,0xa10(%rbp)
  680e8b:	c7 85 20 0a 00 00 00 	movl   $0x3f800000,0xa20(%rbp)
  680e92:	00 80 3f 
  680e95:	0f 11 85 24 0a 00 00 	movups %xmm0,0xa24(%rbp)
  680e9c:	48 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%rbp)
  680ea3:	00 00 00 00 
  680ea7:	66 c7 85 3a 0a 00 00 	movw   $0xff01,0xa3a(%rbp)
  680eae:	01 ff 
  680eb0:	c6 85 3c 0a 00 00 00 	movb   $0x0,0xa3c(%rbp)
  680eb7:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  680ebe:	00 
  680ebf:	48 8b 84 24 c8 03 00 	mov    0x3c8(%rsp),%rax
  680ec6:	00 
  680ec7:	48 89 48 30          	mov    %rcx,0x30(%rax)
  680ecb:	0f 10 84 24 90 00 00 	movups 0x90(%rsp),%xmm0
  680ed2:	00 
  680ed3:	0f 10 8c 24 a0 00 00 	movups 0xa0(%rsp),%xmm1
  680eda:	00 
  680edb:	0f 10 94 24 b0 00 00 	movups 0xb0(%rsp),%xmm2
  680ee2:	00 
  680ee3:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  680ee7:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  680eeb:	0f 11 00             	movups %xmm0,(%rax)
  680eee:	48 81 c4 d8 11 00 00 	add    $0x11d8,%rsp
  680ef5:	5b                   	pop    %rbx
  680ef6:	41 5c                	pop    %r12
  680ef8:	41 5d                	pop    %r13
  680efa:	41 5e                	pop    %r14
  680efc:	41 5f                	pop    %r15
  680efe:	5d                   	pop    %rbp
  680eff:	c3                   	ret
  680f00:	48 8d 35 31 8f 10 00 	lea    0x108f31(%rip),%rsi        # 789e38 <gpui_canvas::text::HEBREW_FONT>
  680f07:	48 8d 15 f0 fc 9d ff 	lea    -0x620310(%rip),%rdx        # 60bfe <gpui_canvas::text::HEBREW_BYTES>
  680f0e:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  680f15:	00 
  680f16:	b9 14 69 00 00       	mov    $0x6914,%ecx
  680f1b:	45 31 c0             	xor    %r8d,%r8d
  680f1e:	e8 9d 98 ff ff       	call   67a7c0 <<gpui_canvas::text::FontFace>::shared_static>
  680f23:	80 bc 24 00 07 00 00 	cmpb   $0x0,0x700(%rsp)
  680f2a:	00 
  680f2b:	0f 85 97 d5 ff ff    	jne    67e4c8 <<gpui_canvas::text::planner::Planner>::shape+0x3e8>
  680f31:	4d 8d bd 50 0a 00 00 	lea    0xa50(%r13),%r15
  680f38:	4c 8b a4 24 08 07 00 	mov    0x708(%rsp),%r12
  680f3f:	00 
  680f40:	49 8b 07             	mov    (%r15),%rax
  680f43:	48 85 c0             	test   %rax,%rax
  680f46:	74 0f                	je     680f57 <<gpui_canvas::text::planner::Planner>::shape+0x2e77>
  680f48:	f0 48 ff 08          	lock decq (%rax)
  680f4c:	75 09                	jne    680f57 <<gpui_canvas::text::planner::Planner>::shape+0x2e77>
  680f4e:	4c 89 ff             	mov    %r15,%rdi
  680f51:	ff 15 c1 5e 10 00    	call   *0x105ec1(%rip)        # 786e18 <_DYNAMIC+0x260>
  680f57:	4d 89 a5 50 0a 00 00 	mov    %r12,0xa50(%r13)
  680f5e:	be 02 00 00 00       	mov    $0x2,%esi
  680f63:	4c 89 ef             	mov    %r13,%rdi
  680f66:	e8 25 0c 00 00       	call   681b90 <<gpui_canvas::text::planner::Planner>::register>
  680f6b:	83 f8 ff             	cmp    $0xffffffff,%eax
  680f6e:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
  680f72:	0f 85 ac d5 ff ff    	jne    67e524 <<gpui_canvas::text::planner::Planner>::shape+0x444>
  680f78:	e9 e5 d5 ff ff       	jmp    67e562 <<gpui_canvas::text::planner::Planner>::shape+0x482>
  680f7d:	c7 84 24 98 00 00 00 	movl   $0x3,0x98(%rsp)
  680f84:	03 00 00 00 
  680f88:	e9 be fc ff ff       	jmp    680c4b <<gpui_canvas::text::planner::Planner>::shape+0x2b6b>
  680f8d:	48 c7 84 24 98 00 00 	movq   $0x3,0x98(%rsp)
  680f94:	00 03 00 00 00 
  680f99:	e9 ad fc ff ff       	jmp    680c4b <<gpui_canvas::text::planner::Planner>::shape+0x2b6b>
  680f9e:	c7 84 24 98 00 00 00 	movl   $0x1,0x98(%rsp)
  680fa5:	01 00 00 00 
  680fa9:	e9 9d fc ff ff       	jmp    680c4b <<gpui_canvas::text::planner::Planner>::shape+0x2b6b>
  680fae:	c7 84 24 98 00 00 00 	movl   $0x3,0x98(%rsp)
  680fb5:	03 00 00 00 
  680fb9:	8b 84 24 18 02 00 00 	mov    0x218(%rsp),%eax
  680fc0:	89 84 24 9c 00 00 00 	mov    %eax,0x9c(%rsp)
  680fc7:	e9 7f fc ff ff       	jmp    680c4b <<gpui_canvas::text::planner::Planner>::shape+0x2b6b>
  680fcc:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  680fd3:	00 ff 
  680fd5:	48 8b 2c 24          	mov    (%rsp),%rbp
  680fd9:	0f 84 ef 01 00 00    	je     6811ce <<gpui_canvas::text::planner::Planner>::shape+0x30ee>
  680fdf:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  680fe6:	00 
  680fe7:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  680feb:	0f 84 c0 03 00 00    	je     6813b1 <<gpui_canvas::text::planner::Planner>::shape+0x32d1>
  680ff1:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  680ff8:	00 
  680ff9:	48 39 f0             	cmp    %rsi,%rax
  680ffc:	0f 86 af 03 00 00    	jbe    6813b1 <<gpui_canvas::text::planner::Planner>::shape+0x32d1>
  681002:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  681009:	00 
  68100a:	e8 d1 0d 00 00       	call   681de0 <<alloc::raw_vec::RawVecInner>::shrink>
  68100f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  681013:	0f 84 98 03 00 00    	je     6813b1 <<gpui_canvas::text::planner::Planner>::shape+0x32d1>
  681019:	48 89 c7             	mov    %rax,%rdi
  68101c:	48 89 d6             	mov    %rdx,%rsi
  68101f:	ff 15 e3 5e 10 00    	call   *0x105ee3(%rip)        # 786f08 <_DYNAMIC+0x350>
  681025:	e9 d5 06 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  68102a:	48 c7 84 24 98 00 00 	movq   $0xc,0x98(%rsp)
  681031:	00 0c 00 00 00 
  681036:	48 c7 84 24 90 00 00 	movq   $0xffffffffffffffff,0x90(%rsp)
  68103d:	00 ff ff ff ff 
  681042:	48 89 f5             	mov    %rsi,%rbp
  681045:	e9 11 fc ff ff       	jmp    680c5b <<gpui_canvas::text::planner::Planner>::shape+0x2b7b>
  68104a:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  681051:	00 
  681052:	48 85 f6             	test   %rsi,%rsi
  681055:	74 17                	je     68106e <<gpui_canvas::text::planner::Planner>::shape+0x2f8e>
  681057:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  68105e:	00 
  68105f:	48 c1 e6 03          	shl    $0x3,%rsi
  681063:	ba 08 00 00 00       	mov    $0x8,%edx
  681068:	ff 15 82 5d 10 00    	call   *0x105d82(%rip)        # 786df0 <_DYNAMIC+0x238>
  68106e:	bb 01 00 00 00       	mov    $0x1,%ebx
  681073:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
  681077:	48 8b 2c 24          	mov    (%rsp),%rbp
  68107b:	0f 84 bb 01 00 00    	je     68123c <<gpui_canvas::text::planner::Planner>::shape+0x315c>
  681081:	4d 85 ed             	test   %r13,%r13
  681084:	74 1a                	je     6810a0 <<gpui_canvas::text::planner::Planner>::shape+0x2fc0>
  681086:	48 8b bc 24 a8 02 00 	mov    0x2a8(%rsp),%rdi
  68108d:	00 
  68108e:	49 c1 e5 04          	shl    $0x4,%r13
  681092:	ba 04 00 00 00       	mov    $0x4,%edx
  681097:	4c 89 ee             	mov    %r13,%rsi
  68109a:	ff 15 50 5d 10 00    	call   *0x105d50(%rip)        # 786df0 <_DYNAMIC+0x238>
  6810a0:	48 8b b4 24 b8 02 00 	mov    0x2b8(%rsp),%rsi
  6810a7:	00 
  6810a8:	48 85 f6             	test   %rsi,%rsi
  6810ab:	0f 84 8b 01 00 00    	je     68123c <<gpui_canvas::text::planner::Planner>::shape+0x315c>
  6810b1:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  6810b8:	00 
  6810b9:	48 c1 e6 02          	shl    $0x2,%rsi
  6810bd:	ba 04 00 00 00       	mov    $0x4,%edx
  6810c2:	ff 15 28 5d 10 00    	call   *0x105d28(%rip)        # 786df0 <_DYNAMIC+0x238>
  6810c8:	e9 6f 01 00 00       	jmp    68123c <<gpui_canvas::text::planner::Planner>::shape+0x315c>
  6810cd:	48 8b 2c 24          	mov    (%rsp),%rbp
  6810d1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6810d6:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  6810db:	eb 24                	jmp    681101 <<gpui_canvas::text::planner::Planner>::shape+0x3021>
  6810dd:	4d 89 ce             	mov    %r9,%r14
  6810e0:	45 31 e4             	xor    %r12d,%r12d
  6810e3:	4d 85 f6             	test   %r14,%r14
  6810e6:	74 27                	je     68110f <<gpui_canvas::text::planner::Planner>::shape+0x302f>
  6810e8:	4d 89 f1             	mov    %r14,%r9
  6810eb:	48 8b 2c 24          	mov    (%rsp),%rbp
  6810ef:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6810f4:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  6810f9:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
  681100:	00 
  681101:	49 39 c1             	cmp    %rax,%r9
  681104:	73 24                	jae    68112a <<gpui_canvas::text::planner::Planner>::shape+0x304a>
  681106:	43 80 3c 08 bf       	cmpb   $0xbf,(%r8,%r9,1)
  68110b:	7f 22                	jg     68112f <<gpui_canvas::text::planner::Planner>::shape+0x304f>
  68110d:	eb 4a                	jmp    681159 <<gpui_canvas::text::planner::Planner>::shape+0x3079>
  68110f:	45 31 c9             	xor    %r9d,%r9d
  681112:	48 8b 2c 24          	mov    (%rsp),%rbp
  681116:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  68111b:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  681120:	48 8b 8c 24 48 02 00 	mov    0x248(%rsp),%rcx
  681127:	00 
  681128:	eb 05                	jmp    68112f <<gpui_canvas::text::planner::Planner>::shape+0x304f>
  68112a:	49 89 c1             	mov    %rax,%r9
  68112d:	75 2a                	jne    681159 <<gpui_canvas::text::planner::Planner>::shape+0x3079>
  68112f:	45 84 e4             	test   %r12b,%r12b
  681132:	74 15                	je     681149 <<gpui_canvas::text::planner::Planner>::shape+0x3069>
  681134:	4c 39 c9             	cmp    %r9,%rcx
  681137:	74 20                	je     681159 <<gpui_canvas::text::planner::Planner>::shape+0x3079>
  681139:	43 0f b6 0c 08       	movzbl (%r8,%r9,1),%ecx
  68113e:	84 c9                	test   %cl,%cl
  681140:	78 40                	js     681182 <<gpui_canvas::text::planner::Planner>::shape+0x30a2>
  681142:	b8 0b 00 00 00       	mov    $0xb,%eax
  681147:	eb 1a                	jmp    681163 <<gpui_canvas::text::planner::Planner>::shape+0x3083>
  681149:	48 39 c1             	cmp    %rax,%rcx
  68114c:	73 09                	jae    681157 <<gpui_canvas::text::planner::Planner>::shape+0x3077>
  68114e:	41 80 3c 08 bf       	cmpb   $0xbf,(%r8,%rcx,1)
  681153:	7f df                	jg     681134 <<gpui_canvas::text::planner::Planner>::shape+0x3054>
  681155:	eb 02                	jmp    681159 <<gpui_canvas::text::planner::Planner>::shape+0x3079>
  681157:	74 db                	je     681134 <<gpui_canvas::text::planner::Planner>::shape+0x3054>
  681159:	b8 03 00 00 00       	mov    $0x3,%eax
  68115e:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  681163:	89 84 24 98 00 00 00 	mov    %eax,0x98(%rsp)
  68116a:	89 8c 24 9c 00 00 00 	mov    %ecx,0x9c(%rsp)
  681171:	48 c7 84 24 90 00 00 	movq   $0xffffffffffffffff,0x90(%rsp)
  681178:	00 ff ff ff ff 
  68117d:	e9 d9 fa ff ff       	jmp    680c5b <<gpui_canvas::text::planner::Planner>::shape+0x2b7b>
  681182:	89 ca                	mov    %ecx,%edx
  681184:	83 e2 1f             	and    $0x1f,%edx
  681187:	43 0f b6 7c 08 01    	movzbl 0x1(%r8,%r9,1),%edi
  68118d:	83 e7 3f             	and    $0x3f,%edi
  681190:	b8 0b 00 00 00       	mov    $0xb,%eax
  681195:	80 f9 df             	cmp    $0xdf,%cl
  681198:	76 2b                	jbe    6811c5 <<gpui_canvas::text::planner::Planner>::shape+0x30e5>
  68119a:	43 0f b6 74 08 02    	movzbl 0x2(%r8,%r9,1),%esi
  6811a0:	c1 e7 06             	shl    $0x6,%edi
  6811a3:	83 e6 3f             	and    $0x3f,%esi
  6811a6:	09 fe                	or     %edi,%esi
  6811a8:	80 f9 f0             	cmp    $0xf0,%cl
  6811ab:	72 7a                	jb     681227 <<gpui_canvas::text::planner::Planner>::shape+0x3147>
  6811ad:	43 0f b6 4c 08 03    	movzbl 0x3(%r8,%r9,1),%ecx
  6811b3:	83 e2 07             	and    $0x7,%edx
  6811b6:	c1 e2 12             	shl    $0x12,%edx
  6811b9:	c1 e6 06             	shl    $0x6,%esi
  6811bc:	83 e1 3f             	and    $0x3f,%ecx
  6811bf:	09 f1                	or     %esi,%ecx
  6811c1:	09 d1                	or     %edx,%ecx
  6811c3:	eb 9e                	jmp    681163 <<gpui_canvas::text::planner::Planner>::shape+0x3083>
  6811c5:	c1 e2 06             	shl    $0x6,%edx
  6811c8:	09 fa                	or     %edi,%edx
  6811ca:	89 d1                	mov    %edx,%ecx
  6811cc:	eb 95                	jmp    681163 <<gpui_canvas::text::planner::Planner>::shape+0x3083>
  6811ce:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  6811d5:	00 
  6811d6:	48 85 c0             	test   %rax,%rax
  6811d9:	0f 84 b0 00 00 00    	je     68128f <<gpui_canvas::text::planner::Planner>::shape+0x31af>
  6811df:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  6811e6:	00 
  6811e7:	48 c1 e0 04          	shl    $0x4,%rax
  6811eb:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  6811f0:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  6811f4:	0f 83 a2 00 00 00    	jae    68129c <<gpui_canvas::text::planner::Planner>::shape+0x31bc>
  6811fa:	c7 84 24 98 00 00 00 	movl   $0x3,0x98(%rsp)
  681201:	03 00 00 00 
  681205:	48 c7 84 24 90 00 00 	movq   $0xffffffffffffffff,0x90(%rsp)
  68120c:	00 ff ff ff ff 
  681211:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  681218:	00 
  681219:	48 85 f6             	test   %rsi,%rsi
  68121c:	0f 85 ca fa ff ff    	jne    680cec <<gpui_canvas::text::planner::Planner>::shape+0x2c0c>
  681222:	e9 dc fa ff ff       	jmp    680d03 <<gpui_canvas::text::planner::Planner>::shape+0x2c23>
  681227:	c1 e2 0c             	shl    $0xc,%edx
  68122a:	09 d6                	or     %edx,%esi
  68122c:	89 f1                	mov    %esi,%ecx
  68122e:	e9 30 ff ff ff       	jmp    681163 <<gpui_canvas::text::planner::Planner>::shape+0x3083>
  681233:	bb 03 00 00 00       	mov    $0x3,%ebx
  681238:	48 8b 2c 24          	mov    (%rsp),%rbp
  68123c:	89 9c 24 98 00 00 00 	mov    %ebx,0x98(%rsp)
  681243:	48 c7 84 24 90 00 00 	movq   $0xffffffffffffffff,0x90(%rsp)
  68124a:	00 ff ff ff ff 
  68124f:	e9 07 fa ff ff       	jmp    680c5b <<gpui_canvas::text::planner::Planner>::shape+0x2b7b>
  681254:	48 8d 3d 4d 48 9a ff 	lea    -0x65b7b3(%rip),%rdi        # 25aa8 <anon.f4165e4923b64ff7e2de5584add5135c.4.llvm.8686550795488547836>
  68125b:	48 8d 15 36 af 0f 00 	lea    0xfaf36(%rip),%rdx        # 77c198 <anon.f4165e4923b64ff7e2de5584add5135c.5.llvm.8686550795488547836>
  681262:	be ad 00 00 00       	mov    $0xad,%esi
  681267:	ff 15 7b 5c 10 00    	call   *0x105c7b(%rip)        # 786ee8 <_DYNAMIC+0x330>
  68126d:	e9 8d 04 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  681272:	48 8d 0d 7f be 0f 00 	lea    0xfbe7f(%rip),%rcx        # 77d0f8 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x88>
  681279:	4c 89 ef             	mov    %r13,%rdi
  68127c:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
  681283:	00 
  681284:	ff 15 06 5e 10 00    	call   *0x105e06(%rip)        # 787090 <_DYNAMIC+0x4d8>
  68128a:	e9 70 04 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  68128f:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  681295:	75 11                	jne    6812a8 <<gpui_canvas::text::planner::Planner>::shape+0x31c8>
  681297:	e9 15 01 00 00       	jmp    6813b1 <<gpui_canvas::text::planner::Planner>::shape+0x32d1>
  68129c:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  6812a2:	0f 86 bf 02 00 00    	jbe    681567 <<gpui_canvas::text::planner::Planner>::shape+0x3487>
  6812a8:	bf 04 00 00 00       	mov    $0x4,%edi
  6812ad:	be 18 00 00 00       	mov    $0x18,%esi
  6812b2:	e8 f9 0d 00 00       	call   6820b0 <alloc::boxed::box_new_uninit>
  6812b7:	49 89 c7             	mov    %rax,%r15
  6812ba:	8b 84 24 f8 00 00 00 	mov    0xf8(%rsp),%eax
  6812c1:	41 c7 07 00 00 00 00 	movl   $0x0,(%r15)
  6812c8:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
  6812cd:	45 89 77 04          	mov    %r14d,0x4(%r15)
  6812d1:	41 c7 47 08 00 00 00 	movl   $0x0,0x8(%r15)
  6812d8:	00 
  6812d9:	41 89 47 0c          	mov    %eax,0xc(%r15)
  6812dd:	41 c7 47 10 00 00 00 	movl   $0x0,0x10(%r15)
  6812e4:	00 
  6812e5:	66 41 c7 47 14 00 00 	movw   $0x0,0x14(%r15)
  6812ec:	bf 04 00 00 00       	mov    $0x4,%edi
  6812f1:	be 18 00 00 00       	mov    $0x18,%esi
  6812f6:	e8 b5 0d 00 00       	call   6820b0 <alloc::boxed::box_new_uninit>
  6812fb:	48 89 c3             	mov    %rax,%rbx
  6812fe:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  681304:	44 89 70 04          	mov    %r14d,0x4(%rax)
  681308:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  68130f:	f3 0f 10 44 24 24    	movss  0x24(%rsp),%xmm0
  681315:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  68131a:	f3 0f 10 44 24 6c    	movss  0x6c(%rsp),%xmm0
  681320:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  681325:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  68132c:	00 
  68132d:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  681332:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  681339:	00 ff 
  68133b:	74 0d                	je     68134a <<gpui_canvas::text::planner::Planner>::shape+0x326a>
  68133d:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
  681344:	00 
  681345:	e8 26 c3 ff ff       	call   67d670 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  68134a:	48 c7 84 24 40 01 00 	movq   $0x1,0x140(%rsp)
  681351:	00 01 00 00 00 
  681356:	4c 89 bc 24 48 01 00 	mov    %r15,0x148(%rsp)
  68135d:	00 
  68135e:	48 c7 84 24 50 01 00 	movq   $0x1,0x150(%rsp)
  681365:	00 01 00 00 00 
  68136a:	48 c7 84 24 58 01 00 	movq   $0x1,0x158(%rsp)
  681371:	00 01 00 00 00 
  681376:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
  68137d:	00 
  68137e:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  681385:	00 01 00 00 00 
  68138a:	48 c7 84 24 70 01 00 	movq   $0xffffffffffffffff,0x170(%rsp)
  681391:	00 ff ff ff ff 
  681396:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  68139b:	89 84 24 88 01 00 00 	mov    %eax,0x188(%rsp)
  6813a2:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  6813a8:	f3 0f 11 84 24 8c 01 	movss  %xmm0,0x18c(%rsp)
  6813af:	00 00 
  6813b1:	4c 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%r15
  6813b8:	00 
  6813b9:	4c 8b a4 24 f0 00 00 	mov    0xf0(%rsp),%r12
  6813c0:	00 
  6813c1:	4c 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%r14
  6813c8:	00 
  6813c9:	48 89 ef             	mov    %rbp,%rdi
  6813cc:	48 8b b4 24 08 02 00 	mov    0x208(%rsp),%rsi
  6813d3:	00 
  6813d4:	e8 77 06 00 00       	call   681a50 <<gpui_canvas::text::planner::Planner>::font_set>
  6813d9:	49 89 c5             	mov    %rax,%r13
  6813dc:	48 89 84 24 b0 04 00 	mov    %rax,0x4b0(%rsp)
  6813e3:	00 
  6813e4:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  6813eb:	00 
  6813ec:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6813f0:	0f 84 c3 00 00 00    	je     6814b9 <<gpui_canvas::text::planner::Planner>::shape+0x33d9>
  6813f6:	48 8d 94 24 48 01 00 	lea    0x148(%rsp),%rdx
  6813fd:	00 
  6813fe:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  681402:	48 89 8c 24 58 07 00 	mov    %rcx,0x758(%rsp)
  681409:	00 
  68140a:	0f 10 02             	movups (%rdx),%xmm0
  68140d:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  681411:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  681415:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  681419:	0f 11 9c 24 48 07 00 	movups %xmm3,0x748(%rsp)
  681420:	00 
  681421:	0f 11 94 24 38 07 00 	movups %xmm2,0x738(%rsp)
  681428:	00 
  681429:	0f 11 8c 24 28 07 00 	movups %xmm1,0x728(%rsp)
  681430:	00 
  681431:	0f 11 84 24 18 07 00 	movups %xmm0,0x718(%rsp)
  681438:	00 
  681439:	48 c7 84 24 00 07 00 	movq   $0x1,0x700(%rsp)
  681440:	00 01 00 00 00 
  681445:	48 c7 84 24 08 07 00 	movq   $0x1,0x708(%rsp)
  68144c:	00 01 00 00 00 
  681451:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  681458:	00 
  681459:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  681460:	00 
  681461:	bf 08 00 00 00       	mov    $0x8,%edi
  681466:	be 60 00 00 00       	mov    $0x60,%esi
  68146b:	e8 40 0c 00 00       	call   6820b0 <alloc::boxed::box_new_uninit>
  681470:	0f 10 84 24 50 07 00 	movups 0x750(%rsp),%xmm0
  681477:	00 
  681478:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  68147c:	0f 10 84 24 40 07 00 	movups 0x740(%rsp),%xmm0
  681483:	00 
  681484:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  681488:	0f 10 84 24 00 07 00 	movups 0x700(%rsp),%xmm0
  68148f:	00 
  681490:	0f 10 8c 24 10 07 00 	movups 0x710(%rsp),%xmm1
  681497:	00 
  681498:	0f 10 94 24 20 07 00 	movups 0x720(%rsp),%xmm2
  68149f:	00 
  6814a0:	0f 10 9c 24 30 07 00 	movups 0x730(%rsp),%xmm3
  6814a7:	00 
  6814a8:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  6814ac:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  6814b0:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  6814b4:	0f 11 00             	movups %xmm0,(%rax)
  6814b7:	eb 02                	jmp    6814bb <<gpui_canvas::text::planner::Planner>::shape+0x33db>
  6814b9:	31 c0                	xor    %eax,%eax
  6814bb:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6814c2:	00 
  6814c3:	4c 89 a4 24 98 00 00 	mov    %r12,0x98(%rsp)
  6814ca:	00 
  6814cb:	4c 89 b4 24 a0 00 00 	mov    %r14,0xa0(%rsp)
  6814d2:	00 
  6814d3:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
  6814da:	00 
  6814db:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6814e2:	00 
  6814e3:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  6814ea:	00 
  6814eb:	f3 0f 11 84 24 b8 00 	movss  %xmm0,0xb8(%rsp)
  6814f2:	00 00 
  6814f4:	f3 0f 10 44 24 24    	movss  0x24(%rsp),%xmm0
  6814fa:	f3 0f 11 84 24 bc 00 	movss  %xmm0,0xbc(%rsp)
  681501:	00 00 
  681503:	f3 0f 10 44 24 6c    	movss  0x6c(%rsp),%xmm0
  681509:	f3 0f 11 84 24 c0 00 	movss  %xmm0,0xc0(%rsp)
  681510:	00 00 
  681512:	f3 0f 10 44 24 7c    	movss  0x7c(%rsp),%xmm0
  681518:	f3 0f 11 84 24 c4 00 	movss  %xmm0,0xc4(%rsp)
  68151f:	00 00 
  681521:	48 8d bc 24 38 03 00 	lea    0x338(%rsp),%rdi
  681528:	00 
  681529:	e8 d2 a8 ff ff       	call   67be00 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  68152e:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  681532:	0f 85 7f f9 ff ff    	jne    680eb7 <<gpui_canvas::text::planner::Planner>::shape+0x2dd7>
  681538:	e9 38 f8 ff ff       	jmp    680d75 <<gpui_canvas::text::planner::Planner>::shape+0x2c95>
  68153d:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  681543:	8b 84 24 80 00 00 00 	mov    0x80(%rsp),%eax
  68154a:	41 89 c7             	mov    %eax,%r15d
  68154d:	e9 d8 cf ff ff       	jmp    67e52a <<gpui_canvas::text::planner::Planner>::shape+0x44a>
  681552:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  681558:	8b 84 24 00 01 00 00 	mov    0x100(%rsp),%eax
  68155f:	41 89 c7             	mov    %eax,%r15d
  681562:	e9 c3 cf ff ff       	jmp    67e52a <<gpui_canvas::text::planner::Planner>::shape+0x44a>
  681567:	48 01 c1             	add    %rax,%rcx
  68156a:	88 51 ff             	mov    %dl,-0x1(%rcx)
  68156d:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  681574:	00 ff 
  681576:	0f 85 63 fa ff ff    	jne    680fdf <<gpui_canvas::text::planner::Planner>::shape+0x2eff>
  68157c:	e9 30 fe ff ff       	jmp    6813b1 <<gpui_canvas::text::planner::Planner>::shape+0x32d1>
  681581:	48 8d 0d d0 be 0f 00 	lea    0xfbed0(%rip),%rcx        # 77d458 <anon.1151abbc0aa39aee2edfb443bb148018.26.llvm.12564331471646380133>
  681588:	48 89 f7             	mov    %rsi,%rdi
  68158b:	48 89 d6             	mov    %rdx,%rsi
  68158e:	4c 89 c2             	mov    %r8,%rdx
  681591:	ff 15 f9 5a 10 00    	call   *0x105af9(%rip)        # 787090 <_DYNAMIC+0x4d8>
  681597:	e9 63 01 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  68159c:	49 89 cd             	mov    %rcx,%r13
  68159f:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  6815a6:	00 
  6815a7:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  6815ae:	00 
  6815af:	48 8d 0d 4a bc 0f 00 	lea    0xfbc4a(%rip),%rcx        # 77d200 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x190>
  6815b6:	e9 be fc ff ff       	jmp    681279 <<gpui_canvas::text::planner::Planner>::shape+0x3199>
  6815bb:	49 89 d5             	mov    %rdx,%r13
  6815be:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
  6815c5:	00 
  6815c6:	48 8d 0d fb ba 0f 00 	lea    0xfbafb(%rip),%rcx        # 77d0c8 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x58>
  6815cd:	e9 a7 fc ff ff       	jmp    681279 <<gpui_canvas::text::planner::Planner>::shape+0x3199>
  6815d2:	48 8d 0d b7 b0 0f 00 	lea    0xfb0b7(%rip),%rcx        # 77c690 <anon.4751b62d855c69562269c18746b5820c.22.llvm.11613928405728550318>
  6815d9:	ff 15 b1 5a 10 00    	call   *0x105ab1(%rip)        # 787090 <_DYNAMIC+0x4d8>
  6815df:	e9 1b 01 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  6815e4:	48 8d 0d a5 b0 0f 00 	lea    0xfb0a5(%rip),%rcx        # 77c690 <anon.4751b62d855c69562269c18746b5820c.22.llvm.11613928405728550318>
  6815eb:	ff 15 9f 5a 10 00    	call   *0x105a9f(%rip)        # 787090 <_DYNAMIC+0x4d8>
  6815f1:	e9 09 01 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  6815f6:	48 8d 3d f3 ad 0f 00 	lea    0xfadf3(%rip),%rdi        # 77c3f0 <anon.d1c5e71728065e152e7afc2084c95a94.21.llvm.16205762496989061431>
  6815fd:	ff 15 ed 58 10 00    	call   *0x1058ed(%rip)        # 786ef0 <_DYNAMIC+0x338>
  681603:	e9 f7 00 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  681608:	4c 8d 05 31 bb 0f 00 	lea    0xfbb31(%rip),%r8        # 77d140 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0xd0>
  68160f:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
  681616:	00 
  681617:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  68161c:	ff 15 4e 5c 10 00    	call   *0x105c4e(%rip)        # 787270 <_DYNAMIC+0x6b8>
  681622:	e9 d8 00 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  681627:	48 8d 05 b2 ba 0f 00 	lea    0xfbab2(%rip),%rax        # 77d0e0 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x70>
  68162e:	eb 1f                	jmp    68164f <<gpui_canvas::text::planner::Planner>::shape+0x356f>
  681630:	48 39 d3             	cmp    %rdx,%rbx
  681633:	48 0f 47 d3          	cmova  %rbx,%rdx
  681637:	48 8d 05 92 bc 0f 00 	lea    0xfbc92(%rip),%rax        # 77d2d0 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x260>
  68163e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  681643:	48 89 d7             	mov    %rdx,%rdi
  681646:	eb 0c                	jmp    681654 <<gpui_canvas::text::planner::Planner>::shape+0x3574>
  681648:	48 8d 05 51 bb 0f 00 	lea    0xfbb51(%rip),%rax        # 77d1a0 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x130>
  68164f:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  681654:	48 8b b4 24 d8 01 00 	mov    0x1d8(%rsp),%rsi
  68165b:	00 
  68165c:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  681661:	ff 15 b1 58 10 00    	call   *0x1058b1(%rip)        # 786f18 <_DYNAMIC+0x360>
  681667:	e9 93 00 00 00       	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  68166c:	48 8d 0d d5 be 0f 00 	lea    0xfbed5(%rip),%rcx        # 77d548 <anon.1151abbc0aa39aee2edfb443bb148018.38.llvm.12564331471646380133>
  681673:	48 89 8c 24 70 02 00 	mov    %rcx,0x270(%rsp)
  68167a:	00 
  68167b:	eb 04                	jmp    681681 <<gpui_canvas::text::planner::Planner>::shape+0x35a1>
  68167d:	31 ff                	xor    %edi,%edi
  68167f:	31 c0                	xor    %eax,%eax
  681681:	48 89 c6             	mov    %rax,%rsi
  681684:	48 8b 94 24 70 02 00 	mov    0x270(%rsp),%rdx
  68168b:	00 
  68168c:	ff 15 86 58 10 00    	call   *0x105886(%rip)        # 786f18 <_DYNAMIC+0x360>
  681692:	eb 6b                	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  681694:	31 ff                	xor    %edi,%edi
  681696:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
  68169d:	00 00 00 00 00 
  6816a2:	eb b0                	jmp    681654 <<gpui_canvas::text::planner::Planner>::shape+0x3574>
  6816a4:	48 8d 15 ad ae 0f 00 	lea    0xfaead(%rip),%rdx        # 77c558 <anon.d1c5e71728065e152e7afc2084c95a94.38.llvm.16205762496989061431>
  6816ab:	ff 15 67 58 10 00    	call   *0x105867(%rip)        # 786f18 <_DYNAMIC+0x360>
  6816b1:	eb 4c                	jmp    6816ff <<gpui_canvas::text::planner::Planner>::shape+0x361f>
  6816b3:	48 8d 05 fe bb 0f 00 	lea    0xfbbfe(%rip),%rax        # 77d2b8 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x248>
  6816ba:	eb 93                	jmp    68164f <<gpui_canvas::text::planner::Planner>::shape+0x356f>
  6816bc:	48 89 d7             	mov    %rdx,%rdi
  6816bf:	48 8d 05 22 bc 0f 00 	lea    0xfbc22(%rip),%rax        # 77d2e8 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x278>
  6816c6:	eb 87                	jmp    68164f <<gpui_canvas::text::planner::Planner>::shape+0x356f>
  6816c8:	48 8d 05 b9 ba 0f 00 	lea    0xfbab9(%rip),%rax        # 77d188 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x118>
  6816cf:	e9 7b ff ff ff       	jmp    68164f <<gpui_canvas::text::planner::Planner>::shape+0x356f>
  6816d4:	48 8d 05 dd ba 0f 00 	lea    0xfbadd(%rip),%rax        # 77d1b8 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x148>
  6816db:	e9 6f ff ff ff       	jmp    68164f <<gpui_canvas::text::planner::Planner>::shape+0x356f>
  6816e0:	48 89 d7             	mov    %rdx,%rdi
  6816e3:	48 8d 05 e6 ba 0f 00 	lea    0xfbae6(%rip),%rax        # 77d1d0 <anon.802d09ffbb264091142cda3ccd9ce6e9.25.llvm.7934801021181108053+0x160>
  6816ea:	e9 60 ff ff ff       	jmp    68164f <<gpui_canvas::text::planner::Planner>::shape+0x356f>
  6816ef:	48 8d 15 52 be 0f 00 	lea    0xfbe52(%rip),%rdx        # 77d548 <anon.1151abbc0aa39aee2edfb443bb148018.38.llvm.12564331471646380133>
  6816f6:	48 89 c6             	mov    %rax,%rsi
  6816f9:	ff 15 19 58 10 00    	call   *0x105819(%rip)        # 786f18 <_DYNAMIC+0x360>
  6816ff:	0f 0b                	ud2
  681701:	49 89 c6             	mov    %rax,%r14
  681704:	be 18 00 00 00       	mov    $0x18,%esi
  681709:	ba 04 00 00 00       	mov    $0x4,%edx
  68170e:	4c 89 ff             	mov    %r15,%rdi
  681711:	ff 15 d9 56 10 00    	call   *0x1056d9(%rip)        # 786df0 <_DYNAMIC+0x238>
  681717:	e9 d4 02 00 00       	jmp    6819f0 <<gpui_canvas::text::planner::Planner>::shape+0x3910>
  68171c:	e9 88 02 00 00       	jmp    6819a9 <<gpui_canvas::text::planner::Planner>::shape+0x38c9>
  681721:	49 89 c6             	mov    %rax,%r14
  681724:	48 89 df             	mov    %rbx,%rdi
  681727:	e8 44 bf ff ff       	call   67d670 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  68172c:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  681731:	75 0e                	jne    681741 <<gpui_canvas::text::planner::Planner>::shape+0x3661>
  681733:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  68173a:	00 
  68173b:	ff 15 c7 56 10 00    	call   *0x1056c7(%rip)        # 786e08 <_DYNAMIC+0x250>
  681741:	31 db                	xor    %ebx,%ebx
  681743:	eb 10                	jmp    681755 <<gpui_canvas::text::planner::Planner>::shape+0x3675>
  681745:	ff 15 c5 56 10 00    	call   *0x1056c5(%rip)        # 786e10 <_DYNAMIC+0x258>
  68174b:	e9 59 02 00 00       	jmp    6819a9 <<gpui_canvas::text::planner::Planner>::shape+0x38c9>
  681750:	49 89 c6             	mov    %rax,%r14
  681753:	b3 01                	mov    $0x1,%bl
  681755:	4d 85 ff             	test   %r15,%r15
  681758:	74 15                	je     68176f <<gpui_canvas::text::planner::Planner>::shape+0x368f>
  68175a:	49 c1 e7 04          	shl    $0x4,%r15
  68175e:	ba 04 00 00 00       	mov    $0x4,%edx
  681763:	4c 89 e7             	mov    %r12,%rdi
  681766:	4c 89 fe             	mov    %r15,%rsi
  681769:	ff 15 81 56 10 00    	call   *0x105681(%rip)        # 786df0 <_DYNAMIC+0x238>
  68176f:	84 db                	test   %bl,%bl
  681771:	0f 84 bf 02 00 00    	je     681a36 <<gpui_canvas::text::planner::Planner>::shape+0x3956>
  681777:	31 db                	xor    %ebx,%ebx
  681779:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  681780:	00 ff 
  681782:	0f 84 f0 01 00 00    	je     681978 <<gpui_canvas::text::planner::Planner>::shape+0x3898>
  681788:	e9 74 02 00 00       	jmp    681a01 <<gpui_canvas::text::planner::Planner>::shape+0x3921>
  68178d:	e9 17 02 00 00       	jmp    6819a9 <<gpui_canvas::text::planner::Planner>::shape+0x38c9>
  681792:	49 89 c6             	mov    %rax,%r14
  681795:	4d 89 27             	mov    %r12,(%r15)
  681798:	4c 89 f7             	mov    %r14,%rdi
  68179b:	e8 f0 95 0f 00       	call   77ad90 <_Unwind_Resume@plt>
  6817a0:	e9 48 02 00 00       	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6817a5:	e9 43 02 00 00       	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6817aa:	e9 3e 02 00 00       	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6817af:	e9 f5 01 00 00       	jmp    6819a9 <<gpui_canvas::text::planner::Planner>::shape+0x38c9>
  6817b4:	e9 34 02 00 00       	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6817b9:	e9 2f 02 00 00       	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6817be:	e9 2a 02 00 00       	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6817c3:	e9 25 02 00 00       	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6817c8:	49 89 c6             	mov    %rax,%r14
  6817cb:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  6817d2:	00 
  6817d3:	e8 08 d4 fe ff       	call   66ebe0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  6817d8:	e9 13 02 00 00       	jmp    6819f0 <<gpui_canvas::text::planner::Planner>::shape+0x3910>
  6817dd:	ff 15 2d 56 10 00    	call   *0x10562d(%rip)        # 786e10 <_DYNAMIC+0x258>
  6817e3:	49 89 c6             	mov    %rax,%r14
  6817e6:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  6817ed:	00 
  6817ee:	e8 ed d3 fe ff       	call   66ebe0 <core::ptr::drop_glue::<parley::style::StyleProperty<()>>>
  6817f3:	e9 f8 01 00 00       	jmp    6819f0 <<gpui_canvas::text::planner::Planner>::shape+0x3910>
  6817f8:	ff 15 12 56 10 00    	call   *0x105612(%rip)        # 786e10 <_DYNAMIC+0x258>
  6817fe:	49 89 c6             	mov    %rax,%r14
  681801:	48 c7 85 c8 08 00 00 	movq   $0x0,0x8c8(%rbp)
  681808:	00 00 00 00 
  68180c:	48 c7 85 d0 08 00 00 	movq   $0x4,0x8d0(%rbp)
  681813:	04 00 00 00 
  681817:	0f 57 c0             	xorps  %xmm0,%xmm0
  68181a:	0f 11 85 d8 08 00 00 	movups %xmm0,0x8d8(%rbp)
  681821:	48 c7 85 e8 08 00 00 	movq   $0x4,0x8e8(%rbp)
  681828:	04 00 00 00 
  68182c:	0f 11 85 f0 08 00 00 	movups %xmm0,0x8f0(%rbp)
  681833:	48 c7 85 00 09 00 00 	movq   $0x8,0x900(%rbp)
  68183a:	08 00 00 00 
  68183e:	0f 11 85 08 09 00 00 	movups %xmm0,0x908(%rbp)
  681845:	48 c7 85 18 09 00 00 	movq   $0x8,0x918(%rbp)
  68184c:	08 00 00 00 
  681850:	0f 11 85 20 09 00 00 	movups %xmm0,0x920(%rbp)
  681857:	48 c7 85 30 09 00 00 	movq   $0x4,0x930(%rbp)
  68185e:	04 00 00 00 
  681862:	0f 11 85 38 09 00 00 	movups %xmm0,0x938(%rbp)
  681869:	48 c7 85 48 09 00 00 	movq   $0x4,0x948(%rbp)
  681870:	04 00 00 00 
  681874:	0f 11 85 50 09 00 00 	movups %xmm0,0x950(%rbp)
  68187b:	48 c7 85 60 09 00 00 	movq   $0x4,0x960(%rbp)
  681882:	04 00 00 00 
  681886:	0f 11 85 68 09 00 00 	movups %xmm0,0x968(%rbp)
  68188d:	48 c7 85 78 09 00 00 	movq   $0x8,0x978(%rbp)
  681894:	08 00 00 00 
  681898:	0f 11 85 80 09 00 00 	movups %xmm0,0x980(%rbp)
  68189f:	48 c7 85 90 09 00 00 	movq   $0x2,0x990(%rbp)
  6818a6:	02 00 00 00 
  6818aa:	0f 11 85 98 09 00 00 	movups %xmm0,0x998(%rbp)
  6818b1:	48 c7 85 a8 09 00 00 	movq   $0x4,0x9a8(%rbp)
  6818b8:	04 00 00 00 
  6818bc:	0f 11 85 b0 09 00 00 	movups %xmm0,0x9b0(%rbp)
  6818c3:	48 c7 85 c0 09 00 00 	movq   $0x8,0x9c0(%rbp)
  6818ca:	08 00 00 00 
  6818ce:	0f 11 85 c8 09 00 00 	movups %xmm0,0x9c8(%rbp)
  6818d5:	48 c7 85 d8 09 00 00 	movq   $0x8,0x9d8(%rbp)
  6818dc:	08 00 00 00 
  6818e0:	0f 11 85 e0 09 00 00 	movups %xmm0,0x9e0(%rbp)
  6818e7:	48 c7 85 f0 09 00 00 	movq   $0x8,0x9f0(%rbp)
  6818ee:	08 00 00 00 
  6818f2:	0f 11 85 f8 09 00 00 	movups %xmm0,0x9f8(%rbp)
  6818f9:	48 c7 85 08 0a 00 00 	movq   $0x4,0xa08(%rbp)
  681900:	04 00 00 00 
  681904:	0f 11 85 10 0a 00 00 	movups %xmm0,0xa10(%rbp)
  68190b:	c7 85 20 0a 00 00 00 	movl   $0x3f800000,0xa20(%rbp)
  681912:	00 80 3f 
  681915:	0f 11 85 24 0a 00 00 	movups %xmm0,0xa24(%rbp)
  68191c:	48 c7 85 32 0a 00 00 	movq   $0x0,0xa32(%rbp)
  681923:	00 00 00 00 
  681927:	66 c7 85 3a 0a 00 00 	movw   $0xff01,0xa3a(%rbp)
  68192e:	01 ff 
  681930:	c6 85 3c 0a 00 00 00 	movb   $0x0,0xa3c(%rbp)
  681937:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  68193e:	00 
  68193f:	e8 1c a6 ff ff       	call   67bf60 <core::ptr::drop_glue::<core::result::Result<gpui_canvas::text::TextLayout, gpui_canvas::Error>>>
  681944:	4c 89 f7             	mov    %r14,%rdi
  681947:	e8 44 94 0f 00       	call   77ad90 <_Unwind_Resume@plt>
  68194c:	ff 15 be 54 10 00    	call   *0x1054be(%rip)        # 786e10 <_DYNAMIC+0x258>
  681952:	e9 96 00 00 00       	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  681957:	49 89 c6             	mov    %rax,%r14
  68195a:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  681961:	00 
  681962:	b3 01                	mov    $0x1,%bl
  681964:	48 85 f6             	test   %rsi,%rsi
  681967:	75 1c                	jne    681985 <<gpui_canvas::text::planner::Planner>::shape+0x38a5>
  681969:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  681970:	00 ff 
  681972:	0f 85 89 00 00 00    	jne    681a01 <<gpui_canvas::text::planner::Planner>::shape+0x3921>
  681978:	84 db                	test   %bl,%bl
  68197a:	0f 85 92 00 00 00    	jne    681a12 <<gpui_canvas::text::planner::Planner>::shape+0x3932>
  681980:	e9 b1 00 00 00       	jmp    681a36 <<gpui_canvas::text::planner::Planner>::shape+0x3956>
  681985:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  68198c:	00 
  68198d:	48 c1 e6 03          	shl    $0x3,%rsi
  681991:	ba 08 00 00 00       	mov    $0x8,%edx
  681996:	ff 15 54 54 10 00    	call   *0x105454(%rip)        # 786df0 <_DYNAMIC+0x238>
  68199c:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  6819a3:	00 ff 
  6819a5:	74 d1                	je     681978 <<gpui_canvas::text::planner::Planner>::shape+0x3898>
  6819a7:	eb 58                	jmp    681a01 <<gpui_canvas::text::planner::Planner>::shape+0x3921>
  6819a9:	49 89 c6             	mov    %rax,%r14
  6819ac:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  6819b3:	00 
  6819b4:	48 85 f6             	test   %rsi,%rsi
  6819b7:	74 17                	je     6819d0 <<gpui_canvas::text::planner::Planner>::shape+0x38f0>
  6819b9:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  6819c0:	00 
  6819c1:	48 c1 e6 03          	shl    $0x3,%rsi
  6819c5:	ba 08 00 00 00       	mov    $0x8,%edx
  6819ca:	ff 15 20 54 10 00    	call   *0x105420(%rip)        # 786df0 <_DYNAMIC+0x238>
  6819d0:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  6819d7:	00 
  6819d8:	e8 83 a4 ff ff       	call   67be60 <core::ptr::drop_glue::<core::option::Option<parley::editing::geometry::CursorGeometry<()>>>>
  6819dd:	eb 11                	jmp    6819f0 <<gpui_canvas::text::planner::Planner>::shape+0x3910>
  6819df:	eb 0c                	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6819e1:	eb 0a                	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6819e3:	eb 08                	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6819e5:	eb 06                	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6819e7:	eb 04                	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6819e9:	eb 02                	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6819eb:	eb 00                	jmp    6819ed <<gpui_canvas::text::planner::Planner>::shape+0x390d>
  6819ed:	49 89 c6             	mov    %rax,%r14
  6819f0:	b3 01                	mov    $0x1,%bl
  6819f2:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  6819f9:	00 ff 
  6819fb:	0f 84 77 ff ff ff    	je     681978 <<gpui_canvas::text::planner::Planner>::shape+0x3898>
  681a01:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
  681a08:	00 
  681a09:	e8 62 bc ff ff       	call   67d670 <core::ptr::drop_glue::<gpui_canvas::text::layout::TextGeometry>>
  681a0e:	84 db                	test   %bl,%bl
  681a10:	74 24                	je     681a36 <<gpui_canvas::text::planner::Planner>::shape+0x3956>
  681a12:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  681a19:	00 
  681a1a:	48 85 f6             	test   %rsi,%rsi
  681a1d:	74 17                	je     681a36 <<gpui_canvas::text::planner::Planner>::shape+0x3956>
  681a1f:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  681a26:	00 
  681a27:	48 c1 e6 04          	shl    $0x4,%rsi
  681a2b:	ba 04 00 00 00       	mov    $0x4,%edx
  681a30:	ff 15 ba 53 10 00    	call   *0x1053ba(%rip)        # 786df0 <_DYNAMIC+0x238>
  681a36:	48 8d bc 24 38 03 00 	lea    0x338(%rsp),%rdi
  681a3d:	00 
  681a3e:	e8 bd a3 ff ff       	call   67be00 <core::ptr::drop_glue::<[parlance::font_family::FontFamilyName; 3]>>
  681a43:	4c 89 f7             	mov    %r14,%rdi
  681a46:	e8 45 93 0f 00       	call   77ad90 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
