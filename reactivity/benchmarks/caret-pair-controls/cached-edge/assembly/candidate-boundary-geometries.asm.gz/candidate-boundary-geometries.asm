
/tmp/gpui-caret-pair-controls-v3/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000669520 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries>:
  669520:	55                   	push   %rbp
  669521:	41 57                	push   %r15
  669523:	41 56                	push   %r14
  669525:	41 55                	push   %r13
  669527:	41 54                	push   %r12
  669529:	53                   	push   %rbx
  66952a:	48 81 ec f8 01 00 00 	sub    $0x1f8,%rsp
  669531:	48 89 fb             	mov    %rdi,%rbx
  669534:	4c 8b 76 28          	mov    0x28(%rsi),%r14
  669538:	4c 39 f2             	cmp    %r14,%rdx
  66953b:	73 74                	jae    6695b1 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x91>
  66953d:	48 8b 46 20          	mov    0x20(%rsi),%rax
  669541:	44 8b 04 90          	mov    (%rax,%rdx,4),%r8d
  669545:	4c 39 46 10          	cmp    %r8,0x10(%rsi)
  669549:	76 66                	jbe    6695b1 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x91>
  66954b:	49 c1 e0 04          	shl    $0x4,%r8
  66954f:	48 8b 46 08          	mov    0x8(%rsi),%rax
  669553:	4c 8b 7e 30          	mov    0x30(%rsi),%r15
  669557:	42 8b 0c 00          	mov    (%rax,%r8,1),%ecx
  66955b:	49 39 8f 18 01 00 00 	cmp    %rcx,0x118(%r15)
  669562:	76 3f                	jbe    6695a3 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x83>
  669564:	42 8b 7c 00 04       	mov    0x4(%rax,%r8,1),%edi
  669569:	4c 6b d1 70          	imul   $0x70,%rcx,%r10
  66956d:	4d 8b 9f 10 01 00 00 	mov    0x110(%r15),%r11
  669574:	4f 8b 4c 13 10       	mov    0x10(%r11,%r10,1),%r9
  669579:	49 01 f9             	add    %rdi,%r9
  66957c:	4f 3b 4c 13 18       	cmp    0x18(%r11,%r10,1),%r9
  669581:	73 20                	jae    6695a3 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x83>
  669583:	4d 3b 8f 30 01 00 00 	cmp    0x130(%r15),%r9
  66958a:	73 17                	jae    6695a3 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x83>
  66958c:	4d 8b 97 28 01 00 00 	mov    0x128(%r15),%r10
  669593:	4f 8d 0c 89          	lea    (%r9,%r9,4),%r9
  669597:	43 80 7c ca 21 00    	cmpb   $0x0,0x21(%r10,%r9,8)
  66959d:	0f 84 4e 02 00 00    	je     6697f1 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x2d1>
  6695a3:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
  6695aa:	00 00 00 00 00 
  6695af:	eb 10                	jmp    6695c1 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0xa1>
  6695b1:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
  6695b8:	00 00 00 00 00 
  6695bd:	4c 8b 7e 30          	mov    0x30(%rsi),%r15
  6695c1:	49 8b 87 50 01 00 00 	mov    0x150(%r15),%rax
  6695c8:	40 b5 01             	mov    $0x1,%bpl
  6695cb:	41 b4 01             	mov    $0x1,%r12b
  6695ce:	48 39 d0             	cmp    %rdx,%rax
  6695d1:	0f 85 57 03 00 00    	jne    66992e <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x40e>
  6695d7:	48 85 d2             	test   %rdx,%rdx
  6695da:	0f 84 6d 01 00 00    	je     66974d <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x22d>
  6695e0:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
  6695e4:	4c 39 f0             	cmp    %r14,%rax
  6695e7:	f3 0f 11 44 24 14    	movss  %xmm0,0x14(%rsp)
  6695ed:	73 60                	jae    66964f <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x12f>
  6695ef:	48 8b 46 20          	mov    0x20(%rsi),%rax
  6695f3:	8b 7c 90 fc          	mov    -0x4(%rax,%rdx,4),%edi
  6695f7:	48 39 7e 10          	cmp    %rdi,0x10(%rsi)
  6695fb:	76 52                	jbe    66964f <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x12f>
  6695fd:	48 8b 46 08          	mov    0x8(%rsi),%rax
  669601:	48 c1 e7 04          	shl    $0x4,%rdi
  669605:	8b 0c 38             	mov    (%rax,%rdi,1),%ecx
  669608:	49 39 8f 18 01 00 00 	cmp    %rcx,0x118(%r15)
  66960f:	76 3e                	jbe    66964f <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x12f>
  669611:	8b 54 38 04          	mov    0x4(%rax,%rdi,1),%edx
  669615:	4c 6b c9 70          	imul   $0x70,%rcx,%r9
  669619:	4d 8b 97 10 01 00 00 	mov    0x110(%r15),%r10
  669620:	4f 8b 44 0a 10       	mov    0x10(%r10,%r9,1),%r8
  669625:	49 01 d0             	add    %rdx,%r8
  669628:	4f 3b 44 0a 18       	cmp    0x18(%r10,%r9,1),%r8
  66962d:	73 20                	jae    66964f <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x12f>
  66962f:	4d 3b 87 30 01 00 00 	cmp    0x130(%r15),%r8
  669636:	73 17                	jae    66964f <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x12f>
  669638:	4d 8b 8f 28 01 00 00 	mov    0x128(%r15),%r9
  66963f:	4f 8d 04 80          	lea    (%r8,%r8,4),%r8
  669643:	43 80 7c c1 21 00    	cmpb   $0x0,0x21(%r9,%r8,8)
  669649:	0f 84 fb 02 00 00    	je     66994a <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x42a>
  66964f:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  669656:	00 00 00 00 00 
  66965b:	45 31 f6             	xor    %r14d,%r14d
  66965e:	31 c0                	xor    %eax,%eax
  669660:	40 84 ed             	test   %bpl,%bpl
  669663:	4c 8d 8c 24 30 01 00 	lea    0x130(%rsp),%r9
  66966a:	00 
  66966b:	4c 0f 45 c8          	cmovne %rax,%r9
  66966f:	49 8b 97 10 01 00 00 	mov    0x110(%r15),%rdx
  669676:	49 8b 8f 18 01 00 00 	mov    0x118(%r15),%rcx
  66967d:	49 89 f5             	mov    %rsi,%r13
  669680:	48 89 34 24          	mov    %rsi,(%rsp)
  669684:	41 0f b6 f4          	movzbl %r12b,%esi
  669688:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  66968d:	4d 89 f0             	mov    %r14,%r8
  669690:	e8 9b ee ff ff       	call   668530 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>>
  669695:	40 84 ed             	test   %bpl,%bpl
  669698:	0f 85 ef 00 00 00    	jne    66978d <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x26d>
  66969e:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  6696a5:	00 
  6696a6:	8b bc 24 58 01 00 00 	mov    0x158(%rsp),%edi
  6696ad:	48 8b 70 58          	mov    0x58(%rax),%rsi
  6696b1:	48 39 fe             	cmp    %rdi,%rsi
  6696b4:	0f 86 3c 03 00 00    	jbe    6699f6 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x4d6>
  6696ba:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6696be:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  6696c2:	48 c1 e2 04          	shl    $0x4,%rdx
  6696c6:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  6696ca:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  6696d1:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  6696d8:	0f 11 84 24 c0 01 00 	movups %xmm0,0x1c0(%rsp)
  6696df:	00 
  6696e0:	0f 11 8c 24 d0 01 00 	movups %xmm1,0x1d0(%rsp)
  6696e7:	00 
  6696e8:	0f 11 94 24 e0 01 00 	movups %xmm2,0x1e0(%rsp)
  6696ef:	00 
  6696f0:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  6696f5:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  6696fc:	00 
  6696fd:	8b b4 24 b0 01 00 00 	mov    0x1b0(%rsp),%esi
  669704:	8b 94 24 b4 01 00 00 	mov    0x1b4(%rsp),%edx
  66970b:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  669712:	00 
  669713:	ff 15 b7 d9 11 00    	call   *0x11d9b7(%rip)        # 7870d0 <_DYNAMIC+0x518>
  669719:	49 8b 97 10 01 00 00 	mov    0x110(%r15),%rdx
  669720:	49 8b 8f 18 01 00 00 	mov    0x118(%r15),%rcx
  669727:	4c 89 2c 24          	mov    %r13,(%rsp)
  66972b:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  669732:	00 
  669733:	4c 8d 8c 24 30 01 00 	lea    0x130(%rsp),%r9
  66973a:	00 
  66973b:	31 f6                	xor    %esi,%esi
  66973d:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  669743:	4d 89 f0             	mov    %r14,%r8
  669746:	e8 e5 ed ff ff       	call   668530 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>>
  66974b:	eb 5a                	jmp    6697a7 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x287>
  66974d:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  669754:	00 00 00 00 00 
  669759:	31 c0                	xor    %eax,%eax
  66975b:	40 84 ed             	test   %bpl,%bpl
  66975e:	4c 8d 8c 24 30 01 00 	lea    0x130(%rsp),%r9
  669765:	00 
  669766:	4c 0f 45 c8          	cmovne %rax,%r9
  66976a:	49 8b 97 10 01 00 00 	mov    0x110(%r15),%rdx
  669771:	49 8b 8f 18 01 00 00 	mov    0x118(%r15),%rcx
  669778:	48 89 34 24          	mov    %rsi,(%rsp)
  66977c:	41 0f b6 f4          	movzbl %r12b,%esi
  669780:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  669785:	45 31 c0             	xor    %r8d,%r8d
  669788:	e8 a3 ed ff ff       	call   668530 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>>
  66978d:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  669792:	0f 10 4c 24 70       	movups 0x70(%rsp),%xmm1
  669797:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
  66979e:	00 
  66979f:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  6697a6:	00 
  6697a7:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  6697ac:	0f 10 4c 24 70       	movups 0x70(%rsp),%xmm1
  6697b1:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  6697b6:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  6697bb:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
  6697c2:	00 
  6697c3:	0f 28 9c 24 90 00 00 	movaps 0x90(%rsp),%xmm3
  6697ca:	00 
  6697cb:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  6697d0:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
  6697d5:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  6697d9:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  6697dd:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6697e1:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6697e5:	48 c7 03 01 00 00 00 	movq   $0x1,(%rbx)
  6697ec:	e9 44 01 00 00       	jmp    669935 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x415>
  6697f1:	4f 8d 14 ca          	lea    (%r10,%r9,8),%r10
  6697f5:	4d 8b 4a 10          	mov    0x10(%r10),%r9
  6697f9:	4d 3b 4f 58          	cmp    0x58(%r15),%r9
  6697fd:	0f 83 a0 fd ff ff    	jae    6695a3 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x83>
  669803:	4d 3b 8f e8 00 00 00 	cmp    0xe8(%r15),%r9
  66980a:	0f 83 93 fd ff ff    	jae    6695a3 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x83>
  669810:	f3 0f 11 44 24 14    	movss  %xmm0,0x14(%rsp)
  669816:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  66981b:	49 89 f5             	mov    %rsi,%r13
  66981e:	4c 01 c0             	add    %r8,%rax
  669821:	4b 8d 14 c9          	lea    (%r9,%r9,8),%rdx
  669825:	48 c1 e2 04          	shl    $0x4,%rdx
  669829:	49 03 57 50          	add    0x50(%r15),%rdx
  66982d:	4b 8d 34 89          	lea    (%r9,%r9,4),%rsi
  669831:	48 c1 e6 04          	shl    $0x4,%rsi
  669835:	49 03 b7 e0 00 00 00 	add    0xe0(%r15),%rsi
  66983c:	4c 89 bc 24 a0 00 00 	mov    %r15,0xa0(%rsp)
  669843:	00 
  669844:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  66984b:	00 
  66984c:	48 89 b4 24 b0 00 00 	mov    %rsi,0xb0(%rsp)
  669853:	00 
  669854:	4c 89 94 24 b8 00 00 	mov    %r10,0xb8(%rsp)
  66985b:	00 
  66985c:	89 8c 24 c0 00 00 00 	mov    %ecx,0xc0(%rsp)
  669863:	89 bc 24 c4 00 00 00 	mov    %edi,0xc4(%rsp)
  66986a:	44 89 8c 24 c8 00 00 	mov    %r9d,0xc8(%rsp)
  669871:	00 
  669872:	8b 50 08             	mov    0x8(%rax),%edx
  669875:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  66987c:	00 
  66987d:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
  669884:	00 
  669885:	e8 b6 c7 ff ff       	call   666040 <<parley::layout::run::Run<()>>::cluster_containing_char>
  66988a:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  669891:	00 
  669892:	48 85 c0             	test   %rax,%rax
  669895:	0f 84 48 01 00 00    	je     6699e3 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x4c3>
  66989b:	8b bc 24 58 01 00 00 	mov    0x158(%rsp),%edi
  6698a2:	48 8b 70 58          	mov    0x58(%rax),%rsi
  6698a6:	48 39 fe             	cmp    %rdi,%rsi
  6698a9:	0f 86 47 01 00 00    	jbe    6699f6 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x4d6>
  6698af:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6698b3:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  6698b7:	48 c1 e2 04          	shl    $0x4,%rdx
  6698bb:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  6698bf:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  6698c6:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  6698cd:	0f 11 84 24 a0 00 00 	movups %xmm0,0xa0(%rsp)
  6698d4:	00 
  6698d5:	0f 11 8c 24 b0 00 00 	movups %xmm1,0xb0(%rsp)
  6698dc:	00 
  6698dd:	0f 11 94 24 c0 00 00 	movups %xmm2,0xc0(%rsp)
  6698e4:	00 
  6698e5:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  6698ea:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6698f1:	00 
  6698f2:	8b b4 24 b0 01 00 00 	mov    0x1b0(%rsp),%esi
  6698f9:	8b 94 24 b4 01 00 00 	mov    0x1b4(%rsp),%edx
  669900:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  669907:	00 
  669908:	ff 15 c2 d7 11 00    	call   *0x11d7c2(%rip)        # 7870d0 <_DYNAMIC+0x518>
  66990e:	48 85 c0             	test   %rax,%rax
  669911:	41 0f 95 c4          	setne  %r12b
  669915:	31 ed                	xor    %ebp,%ebp
  669917:	4c 89 ee             	mov    %r13,%rsi
  66991a:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  66991f:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  669925:	48 39 d0             	cmp    %rdx,%rax
  669928:	0f 84 a9 fc ff ff    	je     6695d7 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0xb7>
  66992e:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  669935:	48 89 d8             	mov    %rbx,%rax
  669938:	48 81 c4 f8 01 00 00 	add    $0x1f8,%rsp
  66993f:	5b                   	pop    %rbx
  669940:	41 5c                	pop    %r12
  669942:	41 5d                	pop    %r13
  669944:	41 5e                	pop    %r14
  669946:	41 5f                	pop    %r15
  669948:	5d                   	pop    %rbp
  669949:	c3                   	ret
  66994a:	4f 8d 0c c1          	lea    (%r9,%r8,8),%r9
  66994e:	4d 8b 41 10          	mov    0x10(%r9),%r8
  669952:	4d 3b 47 58          	cmp    0x58(%r15),%r8
  669956:	0f 83 f3 fc ff ff    	jae    66964f <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x12f>
  66995c:	4d 3b 87 e8 00 00 00 	cmp    0xe8(%r15),%r8
  669963:	0f 83 e6 fc ff ff    	jae    66964f <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x12f>
  669969:	48 01 f8             	add    %rdi,%rax
  66996c:	4b 8d 3c c0          	lea    (%r8,%r8,8),%rdi
  669970:	48 c1 e7 04          	shl    $0x4,%rdi
  669974:	49 03 7f 50          	add    0x50(%r15),%rdi
  669978:	4f 8d 14 80          	lea    (%r8,%r8,4),%r10
  66997c:	49 c1 e2 04          	shl    $0x4,%r10
  669980:	4d 03 97 e0 00 00 00 	add    0xe0(%r15),%r10
  669987:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
  66998c:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
  669991:	4c 89 54 24 30       	mov    %r10,0x30(%rsp)
  669996:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
  66999b:	89 4c 24 40          	mov    %ecx,0x40(%rsp)
  66999f:	89 54 24 44          	mov    %edx,0x44(%rsp)
  6699a3:	44 89 44 24 48       	mov    %r8d,0x48(%rsp)
  6699a8:	8b 50 08             	mov    0x8(%rax),%edx
  6699ab:	4c 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%r14
  6699b2:	00 
  6699b3:	48 8d 44 24 20       	lea    0x20(%rsp),%rax
  6699b8:	4c 89 f7             	mov    %r14,%rdi
  6699bb:	49 89 f5             	mov    %rsi,%r13
  6699be:	48 89 c6             	mov    %rax,%rsi
  6699c1:	e8 7a c6 ff ff       	call   666040 <<parley::layout::run::Run<()>>::cluster_containing_char>
  6699c6:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  6699cc:	4c 89 ee             	mov    %r13,%rsi
  6699cf:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  6699d6:	00 
  6699d7:	48 85 c0             	test   %rax,%rax
  6699da:	4c 0f 44 f0          	cmove  %rax,%r14
  6699de:	e9 7b fc ff ff       	jmp    66965e <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0x13e>
  6699e3:	4c 89 ee             	mov    %r13,%rsi
  6699e6:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6699eb:	f3 0f 10 44 24 14    	movss  0x14(%rsp),%xmm0
  6699f1:	e9 cb fb ff ff       	jmp    6695c1 <<parley::editing::geometry::CursorGeometry<()>>::boundary_geometries+0xa1>
  6699f6:	48 8d 15 4b 3b 11 00 	lea    0x113b4b(%rip),%rdx        # 77d548 <anon.1151abbc0aa39aee2edfb443bb148018.38.llvm.12564331471646380133>
  6699fd:	ff 15 15 d5 11 00    	call   *0x11d515(%rip)        # 786f18 <_DYNAMIC+0x360>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
