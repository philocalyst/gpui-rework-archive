
/tmp/gpui-caret-pair-controls-v3/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000668530 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>>:
  668530:	55                   	push   %rbp
  668531:	41 57                	push   %r15
  668533:	41 56                	push   %r14
  668535:	41 54                	push   %r12
  668537:	53                   	push   %rbx
  668538:	48 83 ec 60          	sub    $0x60,%rsp
  66853c:	4d 89 ce             	mov    %r9,%r14
  66853f:	48 89 fb             	mov    %rdi,%rbx
  668542:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
  668549:	00 
  66854a:	4d 85 c9             	test   %r9,%r9
  66854d:	0f 94 c0             	sete   %al
  668550:	40 08 f0             	or     %sil,%al
  668553:	4d 85 c0             	test   %r8,%r8
  668556:	40 0f 95 c6          	setne  %sil
  66855a:	40 84 c6             	test   %al,%sil
  66855d:	74 53                	je     6685b2 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x82>
  66855f:	4d 8b 10             	mov    (%r8),%r10
  668562:	41 8b 78 28          	mov    0x28(%r8),%edi
  668566:	49 8b 72 58          	mov    0x58(%r10),%rsi
  66856a:	48 39 fe             	cmp    %rdi,%rsi
  66856d:	0f 86 9d 03 00 00    	jbe    668910 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3e0>
  668573:	4d 8b 4a 70          	mov    0x70(%r10),%r9
  668577:	41 8b b0 80 00 00 00 	mov    0x80(%r8),%esi
  66857e:	41 8b 80 84 00 00 00 	mov    0x84(%r8),%eax
  668585:	39 f0                	cmp    %esi,%eax
  668587:	0f 82 6d 03 00 00    	jb     6688fa <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3ca>
  66858d:	49 39 c1             	cmp    %rax,%r9
  668590:	0f 82 64 03 00 00    	jb     6688fa <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3ca>
  668596:	39 f0                	cmp    %esi,%eax
  668598:	0f 84 9c 03 00 00    	je     66893a <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x40a>
  66859e:	4d 8b 5a 68          	mov    0x68(%r10),%r11
  6685a2:	4c 8d 24 76          	lea    (%rsi,%rsi,2),%r12
  6685a6:	43 80 7c a3 07 06    	cmpb   $0x6,0x7(%r11,%r12,4)
  6685ac:	0f 85 29 01 00 00    	jne    6686db <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x1ab>
  6685b2:	4d 85 f6             	test   %r14,%r14
  6685b5:	0f 84 ee 00 00 00    	je     6686a9 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x179>
  6685bb:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  6685c0:	49 8b 06             	mov    (%r14),%rax
  6685c3:	41 8b 7e 28          	mov    0x28(%r14),%edi
  6685c7:	48 8b 70 58          	mov    0x58(%rax),%rsi
  6685cb:	48 39 fe             	cmp    %rdi,%rsi
  6685ce:	0f 86 3c 03 00 00    	jbe    668910 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3e0>
  6685d4:	49 8b 4e 08          	mov    0x8(%r14),%rcx
  6685d8:	0f b6 a9 8c 00 00 00 	movzbl 0x8c(%rcx),%ebp
  6685df:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6685e3:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  6685e7:	48 c1 e2 04          	shl    $0x4,%rdx
  6685eb:	0f 10 40 68          	movups 0x68(%rax),%xmm0
  6685ef:	0f 10 88 80 00 00 00 	movups 0x80(%rax),%xmm1
  6685f6:	0f 10 90 98 00 00 00 	movups 0x98(%rax),%xmm2
  6685fd:	0f 11 44 24 08       	movups %xmm0,0x8(%rsp)
  668602:	0f 11 4c 24 18       	movups %xmm1,0x18(%rsp)
  668607:	0f 11 54 24 28       	movups %xmm2,0x28(%rsp)
  66860c:	48 8b 44 11 50       	mov    0x50(%rcx,%rdx,1),%rax
  668611:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  668616:	41 8b b6 80 00 00 00 	mov    0x80(%r14),%esi
  66861d:	41 8b 96 84 00 00 00 	mov    0x84(%r14),%edx
  668624:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  668629:	ff 15 a1 ea 11 00    	call   *0x11eaa1(%rip)        # 7870d0 <_DYNAMIC+0x518>
  66862f:	49 8b 77 28          	mov    0x28(%r15),%rsi
  668633:	48 39 f0             	cmp    %rsi,%rax
  668636:	0f 83 e1 02 00 00    	jae    66891d <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3ed>
  66863c:	49 8b 77 10          	mov    0x10(%r15),%rsi
  668640:	49 8b 4f 20          	mov    0x20(%r15),%rcx
  668644:	8b 3c 81             	mov    (%rcx,%rax,4),%edi
  668647:	48 39 fe             	cmp    %rdi,%rsi
  66864a:	0f 86 dd 02 00 00    	jbe    66892d <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3fd>
  668650:	49 8b 47 08          	mov    0x8(%r15),%rax
  668654:	48 c1 e7 04          	shl    $0x4,%rdi
  668658:	f3 0f 10 6c 38 0c    	movss  0xc(%rax,%rdi,1),%xmm5
  66865e:	40 f6 c5 01          	test   $0x1,%bpl
  668662:	0f 84 97 01 00 00    	je     6687ff <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x2cf>
  668668:	49 83 7e 18 00       	cmpq   $0x0,0x18(%r14)
  66866d:	0f 29 6c 24 40       	movaps %xmm5,0x40(%rsp)
  668672:	0f 84 39 01 00 00    	je     6687b1 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x281>
  668678:	49 8b 06             	mov    (%r14),%rax
  66867b:	41 8b 7e 20          	mov    0x20(%r14),%edi
  66867f:	48 8b b0 18 01 00 00 	mov    0x118(%rax),%rsi
  668686:	48 39 fe             	cmp    %rdi,%rsi
  668689:	0f 86 bc 02 00 00    	jbe    66894b <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x41b>
  66868f:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  668696:	48 6b cf 70          	imul   $0x70,%rdi,%rcx
  66869a:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  6686a0:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  6686a4:	e9 10 01 00 00       	jmp    6687b9 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x289>
  6686a9:	48 83 f9 01          	cmp    $0x1,%rcx
  6686ad:	48 89 c8             	mov    %rcx,%rax
  6686b0:	48 83 d0 ff          	adc    $0xffffffffffffffff,%rax
  6686b4:	0f 57 ed             	xorps  %xmm5,%xmm5
  6686b7:	0f 57 c9             	xorps  %xmm1,%xmm1
  6686ba:	48 39 c8             	cmp    %rcx,%rax
  6686bd:	0f 83 b2 01 00 00    	jae    668875 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x345>
  6686c3:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  6686c8:	48 6b c8 70          	imul   $0x70,%rax,%rcx
  6686cc:	48 8d 04 0a          	lea    (%rdx,%rcx,1),%rax
  6686d0:	f3 0f 10 6c 0a 28    	movss  0x28(%rdx,%rcx,1),%xmm5
  6686d6:	e9 43 01 00 00       	jmp    66881e <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x2ee>
  6686db:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  6686e0:	4d 89 c6             	mov    %r8,%r14
  6686e3:	49 8b 48 08          	mov    0x8(%r8),%rcx
  6686e7:	0f b6 a9 8c 00 00 00 	movzbl 0x8c(%rcx),%ebp
  6686ee:	49 8b 4a 50          	mov    0x50(%r10),%rcx
  6686f2:	48 8d 14 ff          	lea    (%rdi,%rdi,8),%rdx
  6686f6:	48 c1 e2 04          	shl    $0x4,%rdx
  6686fa:	41 0f 10 82 80 00 00 	movups 0x80(%r10),%xmm0
  668701:	00 
  668702:	41 0f 10 8a 98 00 00 	movups 0x98(%r10),%xmm1
  668709:	00 
  66870a:	4c 89 5c 24 08       	mov    %r11,0x8(%rsp)
  66870f:	4c 89 4c 24 10       	mov    %r9,0x10(%rsp)
  668714:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  668719:	0f 11 4c 24 28       	movups %xmm1,0x28(%rsp)
  66871e:	48 8b 4c 11 50       	mov    0x50(%rcx,%rdx,1),%rcx
  668723:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  668728:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  66872d:	89 c2                	mov    %eax,%edx
  66872f:	ff 15 9b e9 11 00    	call   *0x11e99b(%rip)        # 7870d0 <_DYNAMIC+0x518>
  668735:	49 8b 77 28          	mov    0x28(%r15),%rsi
  668739:	48 39 f0             	cmp    %rsi,%rax
  66873c:	0f 83 db 01 00 00    	jae    66891d <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3ed>
  668742:	49 8b 77 10          	mov    0x10(%r15),%rsi
  668746:	49 8b 4f 20          	mov    0x20(%r15),%rcx
  66874a:	8b 3c 81             	mov    (%rcx,%rax,4),%edi
  66874d:	48 39 fe             	cmp    %rdi,%rsi
  668750:	0f 86 d7 01 00 00    	jbe    66892d <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3fd>
  668756:	49 8b 47 08          	mov    0x8(%r15),%rax
  66875a:	48 c1 e7 04          	shl    $0x4,%rdi
  66875e:	f3 0f 10 6c 38 0c    	movss  0xc(%rax,%rdi,1),%xmm5
  668764:	40 f6 c5 01          	test   $0x1,%bpl
  668768:	4c 89 f0             	mov    %r14,%rax
  66876b:	0f 85 69 01 00 00    	jne    6688da <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3aa>
  668771:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
  668776:	0f 29 6c 24 40       	movaps %xmm5,0x40(%rsp)
  66877b:	0f 84 08 01 00 00    	je     668889 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x359>
  668781:	48 8b 08             	mov    (%rax),%rcx
  668784:	8b 78 20             	mov    0x20(%rax),%edi
  668787:	48 8b b1 18 01 00 00 	mov    0x118(%rcx),%rsi
  66878e:	48 39 fe             	cmp    %rdi,%rsi
  668791:	0f 86 b4 01 00 00    	jbe    66894b <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x41b>
  668797:	48 8b 89 10 01 00 00 	mov    0x110(%rcx),%rcx
  66879e:	48 6b d7 70          	imul   $0x70,%rdi,%rdx
  6687a2:	f3 0f 10 44 11 50    	movss  0x50(%rcx,%rdx,1),%xmm0
  6687a8:	8b 4c 11 54          	mov    0x54(%rcx,%rdx,1),%ecx
  6687ac:	e9 e0 00 00 00       	jmp    668891 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x361>
  6687b1:	0f 57 c0             	xorps  %xmm0,%xmm0
  6687b4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  6687b9:	49 8d 96 80 00 00 00 	lea    0x80(%r14),%rdx
  6687c0:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  6687c4:	f2 0f 10 49 44       	movsd  0x44(%rcx),%xmm1
  6687c9:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
  6687cf:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  6687d5:	89 44 24 14          	mov    %eax,0x14(%rsp)
  6687d9:	49 8d 76 30          	lea    0x30(%r14),%rsi
  6687dd:	49 8b 46 08          	mov    0x8(%r14),%rax
  6687e1:	0f b6 88 8c 00 00 00 	movzbl 0x8c(%rax),%ecx
  6687e8:	83 e1 01             	and    $0x1,%ecx
  6687eb:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  6687f0:	ff 15 62 e9 11 00    	call   *0x11e962(%rip)        # 787158 <_DYNAMIC+0x5a0>
  6687f6:	0f 28 6c 24 40       	movaps 0x40(%rsp),%xmm5
  6687fb:	f3 0f 58 e8          	addss  %xmm0,%xmm5
  6687ff:	49 8b 0e             	mov    (%r14),%rcx
  668802:	41 8b 46 20          	mov    0x20(%r14),%eax
  668806:	48 39 81 18 01 00 00 	cmp    %rax,0x118(%rcx)
  66880d:	0f 86 da 00 00 00    	jbe    6688ed <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x3bd>
  668813:	48 6b c0 70          	imul   $0x70,%rax,%rax
  668817:	48 03 81 10 01 00 00 	add    0x110(%rcx),%rax
  66881e:	f3 0f 10 40 40       	movss  0x40(%rax),%xmm0
  668823:	f3 0f 10 48 44       	movss  0x44(%rax),%xmm1
  668828:	0f 28 d0             	movaps %xmm0,%xmm2
  66882b:	f3 0f 5d 50 48       	minss  0x48(%rax),%xmm2
  668830:	0f 28 da             	movaps %xmm2,%xmm3
  668833:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  668838:	0f 28 e3             	movaps %xmm3,%xmm4
  66883b:	0f 55 e2             	andnps %xmm2,%xmm4
  66883e:	0f 54 d8             	andps  %xmm0,%xmm3
  668841:	0f 56 dc             	orps   %xmm4,%xmm3
  668844:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  668849:	f3 0f 58 c5          	addss  %xmm5,%xmm0
  66884d:	0f 14 eb             	unpcklps %xmm3,%xmm5
  668850:	0f 5a ed             	cvtps2pd %xmm5,%xmm5
  668853:	0f 28 d1             	movaps %xmm1,%xmm2
  668856:	f3 0f 5f 50 4c       	maxss  0x4c(%rax),%xmm2
  66885b:	0f 28 da             	movaps %xmm2,%xmm3
  66885e:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  668863:	0f 28 e3             	movaps %xmm3,%xmm4
  668866:	0f 55 e2             	andnps %xmm2,%xmm4
  668869:	0f 54 d9             	andps  %xmm1,%xmm3
  66886c:	0f 56 dc             	orps   %xmm4,%xmm3
  66886f:	0f 14 c3             	unpcklps %xmm3,%xmm0
  668872:	0f 5a c8             	cvtps2pd %xmm0,%xmm1
  668875:	0f 11 2b             	movups %xmm5,(%rbx)
  668878:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  66887c:	48 83 c4 60          	add    $0x60,%rsp
  668880:	5b                   	pop    %rbx
  668881:	41 5c                	pop    %r12
  668883:	41 5e                	pop    %r14
  668885:	41 5f                	pop    %r15
  668887:	5d                   	pop    %rbp
  668888:	c3                   	ret
  668889:	0f 57 c0             	xorps  %xmm0,%xmm0
  66888c:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  668891:	48 8d 90 80 00 00 00 	lea    0x80(%rax),%rdx
  668898:	48 8b 70 10          	mov    0x10(%rax),%rsi
  66889c:	f2 0f 10 4e 44       	movsd  0x44(%rsi),%xmm1
  6688a1:	f2 0f 11 4c 24 08    	movsd  %xmm1,0x8(%rsp)
  6688a7:	f3 0f 11 44 24 10    	movss  %xmm0,0x10(%rsp)
  6688ad:	89 4c 24 14          	mov    %ecx,0x14(%rsp)
  6688b1:	48 8d 70 30          	lea    0x30(%rax),%rsi
  6688b5:	48 8b 40 08          	mov    0x8(%rax),%rax
  6688b9:	0f b6 88 8c 00 00 00 	movzbl 0x8c(%rax),%ecx
  6688c0:	83 e1 01             	and    $0x1,%ecx
  6688c3:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  6688c8:	ff 15 8a e8 11 00    	call   *0x11e88a(%rip)        # 787158 <_DYNAMIC+0x5a0>
  6688ce:	4c 89 f0             	mov    %r14,%rax
  6688d1:	0f 28 6c 24 40       	movaps 0x40(%rsp),%xmm5
  6688d6:	f3 0f 58 e8          	addss  %xmm0,%xmm5
  6688da:	48 8b 08             	mov    (%rax),%rcx
  6688dd:	8b 40 20             	mov    0x20(%rax),%eax
  6688e0:	48 39 81 18 01 00 00 	cmp    %rax,0x118(%rcx)
  6688e7:	0f 87 26 ff ff ff    	ja     668813 <<parley::editing::cursor::Cursor>::geometry_with::<(), <parley::editing::geometry::CursorGeometry<()>>::boundary_geometries::{closure#1}::{closure#0}>+0x2e3>
  6688ed:	48 8d 3d 7c 4b 11 00 	lea    0x114b7c(%rip),%rdi        # 77d470 <anon.1151abbc0aa39aee2edfb443bb148018.27.llvm.12564331471646380133>
  6688f4:	ff 15 f6 e5 11 00    	call   *0x11e5f6(%rip)        # 786ef0 <_DYNAMIC+0x338>
  6688fa:	48 8d 0d 57 4b 11 00 	lea    0x114b57(%rip),%rcx        # 77d458 <anon.1151abbc0aa39aee2edfb443bb148018.26.llvm.12564331471646380133>
  668901:	48 89 f7             	mov    %rsi,%rdi
  668904:	48 89 c6             	mov    %rax,%rsi
  668907:	4c 89 ca             	mov    %r9,%rdx
  66890a:	ff 15 80 e7 11 00    	call   *0x11e780(%rip)        # 787090 <_DYNAMIC+0x4d8>
  668910:	48 8d 15 31 4c 11 00 	lea    0x114c31(%rip),%rdx        # 77d548 <anon.1151abbc0aa39aee2edfb443bb148018.38.llvm.12564331471646380133>
  668917:	ff 15 fb e5 11 00    	call   *0x11e5fb(%rip)        # 786f18 <_DYNAMIC+0x360>
  66891d:	48 8d 15 dc 3c 11 00 	lea    0x113cdc(%rip),%rdx        # 77c600 <anon.d1c5e71728065e152e7afc2084c95a94.38.llvm.16205762496989061431+0xa8>
  668924:	48 89 c7             	mov    %rax,%rdi
  668927:	ff 15 eb e5 11 00    	call   *0x11e5eb(%rip)        # 786f18 <_DYNAMIC+0x360>
  66892d:	48 8d 15 e4 3c 11 00 	lea    0x113ce4(%rip),%rdx        # 77c618 <anon.d1c5e71728065e152e7afc2084c95a94.38.llvm.16205762496989061431+0xc0>
  668934:	ff 15 de e5 11 00    	call   *0x11e5de(%rip)        # 786f18 <_DYNAMIC+0x360>
  66893a:	48 8d 15 ff 4a 11 00 	lea    0x114aff(%rip),%rdx        # 77d440 <anon.1151abbc0aa39aee2edfb443bb148018.25.llvm.12564331471646380133>
  668941:	31 ff                	xor    %edi,%edi
  668943:	31 f6                	xor    %esi,%esi
  668945:	ff 15 cd e5 11 00    	call   *0x11e5cd(%rip)        # 786f18 <_DYNAMIC+0x360>
  66894b:	48 8d 15 36 4b 11 00 	lea    0x114b36(%rip),%rdx        # 77d488 <anon.1151abbc0aa39aee2edfb443bb148018.29.llvm.12564331471646380133>
  668952:	ff 15 c0 e5 11 00    	call   *0x11e5c0(%rip)        # 786f18 <_DYNAMIC+0x360>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
