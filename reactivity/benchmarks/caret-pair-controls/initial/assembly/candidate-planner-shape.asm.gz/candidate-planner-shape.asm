
/tmp/gpui-caret-pair-controls-v2/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000668ba0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape>:
  668ba0:	55                   	push   %rbp
  668ba1:	41 57                	push   %r15
  668ba3:	41 56                	push   %r14
  668ba5:	41 55                	push   %r13
  668ba7:	41 54                	push   %r12
  668ba9:	53                   	push   %rbx
  668baa:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  668bb1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  668bb8:	00 
  668bb9:	48 81 ec d8 01 00 00 	sub    $0x1d8,%rsp
  668bc0:	44 89 8c 24 1c 02 00 	mov    %r9d,0x21c(%rsp)
  668bc7:	00 
  668bc8:	f3 0f 11 8c 24 bc 01 	movss  %xmm1,0x1bc(%rsp)
  668bcf:	00 00 
  668bd1:	44 89 84 24 b8 01 00 	mov    %r8d,0x1b8(%rsp)
  668bd8:	00 
  668bd9:	f3 0f 11 84 24 9c 00 	movss  %xmm0,0x9c(%rsp)
  668be0:	00 00 
  668be2:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  668be7:	48 89 bc 24 80 03 00 	mov    %rdi,0x380(%rsp)
  668bee:	00 
  668bef:	4c 8d 24 0a          	lea    (%rdx,%rcx,1),%r12
  668bf3:	48 85 c9             	test   %rcx,%rcx
  668bf6:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  668bfb:	4c 89 a4 24 a0 01 00 	mov    %r12,0x1a0(%rsp)
  668c02:	00 
  668c03:	48 89 94 24 38 01 00 	mov    %rdx,0x138(%rsp)
  668c0a:	00 
  668c0b:	0f 84 94 03 00 00    	je     668fa5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x405>
  668c11:	48 8d 86 78 0a 00 00 	lea    0xa78(%rsi),%rax
  668c18:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  668c1d:	48 8d bc 24 dc 0c 00 	lea    0xcdc(%rsp),%rdi
  668c24:	00 
  668c25:	48 8d 46 38          	lea    0x38(%rsi),%rax
  668c29:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  668c2e:	48 8d 46 3c          	lea    0x3c(%rsi),%rax
  668c32:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  668c37:	48 8d 46 58          	lea    0x58(%rsi),%rax
  668c3b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  668c42:	00 
  668c43:	48 8d 46 5c          	lea    0x5c(%rsi),%rax
  668c47:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  668c4c:	c7 44 24 10 00 00 00 	movl   $0x0,0x10(%rsp)
  668c53:	00 
  668c54:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
  668c5b:	00 
  668c5c:	4c 8b 05 1d e5 11 00 	mov    0x11e51d(%rip),%r8        # 787180 <_DYNAMIC+0x478>
  668c63:	49 89 d6             	mov    %rdx,%r14
  668c66:	eb 21                	jmp    668c89 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe9>
  668c68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  668c6f:	00 
  668c70:	41 8d 87 d8 df ff ff 	lea    -0x2028(%r15),%eax
  668c77:	83 f8 02             	cmp    $0x2,%eax
  668c7a:	0f 83 e1 00 00 00    	jae    668d61 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1c1>
  668c80:	4d 39 e6             	cmp    %r12,%r14
  668c83:	0f 84 bd 02 00 00    	je     668f46 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3a6>
  668c89:	45 0f b6 3e          	movzbl (%r14),%r15d
  668c8d:	45 84 ff             	test   %r15b,%r15b
  668c90:	78 1e                	js     668cb0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x110>
  668c92:	49 ff c6             	inc    %r14
  668c95:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  668c9c:	0f 8e 9e 00 00 00    	jle    668d40 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1a0>
  668ca2:	eb cc                	jmp    668c70 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xd0>
  668ca4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  668cab:	00 00 00 00 00 
  668cb0:	44 89 f8             	mov    %r15d,%eax
  668cb3:	83 e0 1f             	and    $0x1f,%eax
  668cb6:	41 0f b6 56 01       	movzbl 0x1(%r14),%edx
  668cbb:	83 e2 3f             	and    $0x3f,%edx
  668cbe:	41 80 ff df          	cmp    $0xdf,%r15b
  668cc2:	76 3d                	jbe    668d01 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x161>
  668cc4:	41 0f b6 4e 02       	movzbl 0x2(%r14),%ecx
  668cc9:	c1 e2 06             	shl    $0x6,%edx
  668ccc:	83 e1 3f             	and    $0x3f,%ecx
  668ccf:	09 d1                	or     %edx,%ecx
  668cd1:	41 80 ff f0          	cmp    $0xf0,%r15b
  668cd5:	72 44                	jb     668d1b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x17b>
  668cd7:	45 0f b6 7e 03       	movzbl 0x3(%r14),%r15d
  668cdc:	49 83 c6 04          	add    $0x4,%r14
  668ce0:	83 e0 07             	and    $0x7,%eax
  668ce3:	c1 e0 12             	shl    $0x12,%eax
  668ce6:	c1 e1 06             	shl    $0x6,%ecx
  668ce9:	41 83 e7 3f          	and    $0x3f,%r15d
  668ced:	41 09 cf             	or     %ecx,%r15d
  668cf0:	41 09 c7             	or     %eax,%r15d
  668cf3:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  668cfa:	7e 44                	jle    668d40 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1a0>
  668cfc:	e9 6f ff ff ff       	jmp    668c70 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xd0>
  668d01:	49 83 c6 02          	add    $0x2,%r14
  668d05:	c1 e0 06             	shl    $0x6,%eax
  668d08:	09 d0                	or     %edx,%eax
  668d0a:	41 89 c7             	mov    %eax,%r15d
  668d0d:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  668d14:	7e 2a                	jle    668d40 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1a0>
  668d16:	e9 55 ff ff ff       	jmp    668c70 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xd0>
  668d1b:	49 83 c6 03          	add    $0x3,%r14
  668d1f:	c1 e0 0c             	shl    $0xc,%eax
  668d22:	09 c1                	or     %eax,%ecx
  668d24:	41 89 cf             	mov    %ecx,%r15d
  668d27:	41 81 ff 27 20 00 00 	cmp    $0x2027,%r15d
  668d2e:	0f 8f 3c ff ff ff    	jg     668c70 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xd0>
  668d34:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  668d3b:	00 00 00 00 00 
  668d40:	41 83 ff 0a          	cmp    $0xa,%r15d
  668d44:	0f 84 36 ff ff ff    	je     668c80 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe0>
  668d4a:	41 83 ff 0d          	cmp    $0xd,%r15d
  668d4e:	0f 84 2c ff ff ff    	je     668c80 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe0>
  668d54:	41 81 ff 85 00 00 00 	cmp    $0x85,%r15d
  668d5b:	0f 84 1f ff ff ff    	je     668c80 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe0>
  668d61:	48 89 fd             	mov    %rdi,%rbp
  668d64:	48 8d 3d 45 35 11 00 	lea    0x113545(%rip),%rdi        # 77c2b0 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x20>
  668d6b:	49 89 f5             	mov    %rsi,%r13
  668d6e:	44 89 fe             	mov    %r15d,%esi
  668d71:	4c 89 c3             	mov    %r8,%rbx
  668d74:	ff 15 a6 e5 11 00    	call   *0x11e5a6(%rip)        # 787320 <_DYNAMIC+0x618>
  668d7a:	49 89 d8             	mov    %rbx,%r8
  668d7d:	4c 89 ee             	mov    %r13,%rsi
  668d80:	48 89 ef             	mov    %rbp,%rdi
  668d83:	84 c0                	test   %al,%al
  668d85:	0f 85 f5 fe ff ff    	jne    668c80 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe0>
  668d8b:	41 bc 0a 00 00 00    	mov    $0xa,%r12d
  668d91:	41 83 ff 20          	cmp    $0x20,%r15d
  668d95:	0f 82 5f 02 00 00    	jb     668ffa <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x45a>
  668d9b:	41 8d 47 81          	lea    -0x7f(%r15),%eax
  668d9f:	83 f8 21             	cmp    $0x21,%eax
  668da2:	0f 82 52 02 00 00    	jb     668ffa <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x45a>
  668da8:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  668dad:	44 89 fe             	mov    %r15d,%esi
  668db0:	e8 7b 3c 00 00       	call   66ca30 <_RNvMs_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB4_4Cmap11glyph_index>
  668db5:	49 89 d8             	mov    %rbx,%r8
  668db8:	4c 89 ee             	mov    %r13,%rsi
  668dbb:	a8 01                	test   $0x1,%al
  668dbd:	4c 8b a4 24 a0 01 00 	mov    0x1a0(%rsp),%r12
  668dc4:	00 
  668dc5:	74 0c                	je     668dd3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x233>
  668dc7:	48 89 ef             	mov    %rbp,%rdi
  668dca:	66 85 d2             	test   %dx,%dx
  668dcd:	0f 85 ad fe ff ff    	jne    668c80 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe0>
  668dd3:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  668dd8:	48 8b 81 40 0a 00 00 	mov    0xa40(%rcx),%rax
  668ddf:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  668de5:	80 78 38 01          	cmpb   $0x1,0x38(%rax)
  668de9:	0f 85 0b 02 00 00    	jne    668ffa <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x45a>
  668def:	48 83 79 30 00       	cmpq   $0x0,0x30(%rcx)
  668df4:	0f 85 eb 00 00 00    	jne    668ee5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x345>
  668dfa:	ba 48 ab 03 00       	mov    $0x3ab48,%edx
  668dff:	48 89 f7             	mov    %rsi,%rdi
  668e02:	48 8d 35 13 cb 9b ff 	lea    -0x6434ed(%rip),%rsi        # 2591c <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text12ARABIC_BYTES>
  668e09:	31 c9                	xor    %ecx,%ecx
  668e0b:	41 ff d0             	call   *%r8
  668e0e:	83 bc 24 00 07 00 00 	cmpl   $0xffffffff,0x700(%rsp)
  668e15:	ff 
  668e16:	0f 84 f2 2f 00 00    	je     66be0e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x326e>
  668e1c:	8b 84 24 d8 0c 00 00 	mov    0xcd8(%rsp),%eax
  668e23:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  668e27:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
  668e2b:	0f 10 4d 0c          	movups 0xc(%rbp),%xmm1
  668e2f:	0f 29 84 24 b0 04 00 	movaps %xmm0,0x4b0(%rsp)
  668e36:	00 
  668e37:	0f 11 8c 24 bc 04 00 	movups %xmm1,0x4bc(%rsp)
  668e3e:	00 
  668e3f:	ba 14 69 00 00       	mov    $0x6914,%edx
  668e44:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  668e4b:	00 
  668e4c:	48 8d 35 11 76 9f ff 	lea    -0x6089ef(%rip),%rsi        # 60464 <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text12HEBREW_BYTES>
  668e53:	31 c9                	xor    %ecx,%ecx
  668e55:	ff 15 25 e3 11 00    	call   *0x11e325(%rip)        # 787180 <_DYNAMIC+0x478>
  668e5b:	83 bc 24 00 07 00 00 	cmpl   $0xffffffff,0x700(%rsp)
  668e62:	ff 
  668e63:	0f 84 b7 2f 00 00    	je     66be20 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3280>
  668e69:	8b 94 24 d8 0c 00 00 	mov    0xcd8(%rsp),%edx
  668e70:	48 8d 84 24 dc 0c 00 	lea    0xcdc(%rsp),%rax
  668e77:	00 
  668e78:	0f 10 00             	movups (%rax),%xmm0
  668e7b:	0f 10 48 0c          	movups 0xc(%rax),%xmm1
  668e7f:	0f 29 84 24 90 02 00 	movaps %xmm0,0x290(%rsp)
  668e86:	00 
  668e87:	0f 11 8c 24 9c 02 00 	movups %xmm1,0x29c(%rsp)
  668e8e:	00 
  668e8f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  668e94:	48 c7 40 30 01 00 00 	movq   $0x1,0x30(%rax)
  668e9b:	00 
  668e9c:	8b 4c 24 1c          	mov    0x1c(%rsp),%ecx
  668ea0:	89 48 38             	mov    %ecx,0x38(%rax)
  668ea3:	0f 10 84 24 bc 04 00 	movups 0x4bc(%rsp),%xmm0
  668eaa:	00 
  668eab:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  668eb0:	0f 11 41 0c          	movups %xmm0,0xc(%rcx)
  668eb4:	0f 28 84 24 b0 04 00 	movaps 0x4b0(%rsp),%xmm0
  668ebb:	00 
  668ebc:	0f 11 01             	movups %xmm0,(%rcx)
  668ebf:	89 94 24 c0 01 00 00 	mov    %edx,0x1c0(%rsp)
  668ec6:	89 50 58             	mov    %edx,0x58(%rax)
  668ec9:	0f 10 84 24 9c 02 00 	movups 0x29c(%rsp),%xmm0
  668ed0:	00 
  668ed1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  668ed6:	0f 11 40 0c          	movups %xmm0,0xc(%rax)
  668eda:	0f 28 84 24 90 02 00 	movaps 0x290(%rsp),%xmm0
  668ee1:	00 
  668ee2:	0f 11 00             	movups %xmm0,(%rax)
  668ee5:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  668eea:	44 89 fe             	mov    %r15d,%esi
  668eed:	e8 3e 3b 00 00       	call   66ca30 <_RNvMs_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB4_4Cmap11glyph_index>
  668ef2:	66 85 d2             	test   %dx,%dx
  668ef5:	0f 95 c1             	setne  %cl
  668ef8:	20 c1                	and    %al,%cl
  668efa:	88 4c 24 20          	mov    %cl,0x20(%rsp)
  668efe:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  668f05:	00 
  668f06:	44 89 fe             	mov    %r15d,%esi
  668f09:	e8 22 3b 00 00       	call   66ca30 <_RNvMs_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB4_4Cmap11glyph_index>
  668f0e:	66 85 d2             	test   %dx,%dx
  668f11:	0f 95 c1             	setne  %cl
  668f14:	20 c1                	and    %al,%cl
  668f16:	00 c9                	add    %cl,%cl
  668f18:	0a 4c 24 20          	or     0x20(%rsp),%cl
  668f1c:	0f 84 d8 00 00 00    	je     668ffa <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x45a>
  668f22:	8b 44 24 10          	mov    0x10(%rsp),%eax
  668f26:	08 c8                	or     %cl,%al
  668f28:	89 44 24 10          	mov    %eax,0x10(%rsp)
  668f2c:	4c 8b a4 24 a0 01 00 	mov    0x1a0(%rsp),%r12
  668f33:	00 
  668f34:	4d 39 e6             	cmp    %r12,%r14
  668f37:	48 89 ef             	mov    %rbp,%rdi
  668f3a:	4c 89 ee             	mov    %r13,%rsi
  668f3d:	49 89 d8             	mov    %rbx,%r8
  668f40:	0f 85 43 fd ff ff    	jne    668c89 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe9>
  668f46:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
  668f4a:	f6 c1 01             	test   $0x1,%cl
  668f4d:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  668f52:	0f 84 c8 00 00 00    	je     669020 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x480>
  668f58:	49 83 be 48 0a 00 00 	cmpq   $0x0,0xa48(%r14)
  668f5f:	00 
  668f60:	0f 85 ba 00 00 00    	jne    669020 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x480>
  668f66:	48 8d 35 03 10 12 00 	lea    0x121003(%rip),%rsi        # 789f70 <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text11ARABIC_FONT.llvm.17982672398492329123>
  668f6d:	48 8d 15 a8 c9 9b ff 	lea    -0x643658(%rip),%rdx        # 2591c <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text12ARABIC_BYTES>
  668f74:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  668f7b:	00 
  668f7c:	b9 48 ab 03 00       	mov    $0x3ab48,%ecx
  668f81:	45 31 c0             	xor    %r8d,%r8d
  668f84:	e8 77 aa ff ff       	call   663a00 <_RNvMNtCs6tOD1aKRtN9_11gpui_canvas4textNtB2_8FontFace13shared_static.llvm.17982672398492329123>
  668f89:	83 bc 24 00 07 00 00 	cmpl   $0x1,0x700(%rsp)
  668f90:	01 
  668f91:	75 19                	jne    668fac <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x40c>
  668f93:	44 8b a4 24 04 07 00 	mov    0x704(%rsp),%r12d
  668f9a:	00 
  668f9b:	44 8b bc 24 08 07 00 	mov    0x708(%rsp),%r15d
  668fa2:	00 
  668fa3:	eb 55                	jmp    668ffa <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x45a>
  668fa5:	31 c9                	xor    %ecx,%ecx
  668fa7:	e9 87 00 00 00       	jmp    669033 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x493>
  668fac:	4d 8d be 48 0a 00 00 	lea    0xa48(%r14),%r15
  668fb3:	4c 8b a4 24 08 07 00 	mov    0x708(%rsp),%r12
  668fba:	00 
  668fbb:	49 8b 07             	mov    (%r15),%rax
  668fbe:	48 85 c0             	test   %rax,%rax
  668fc1:	74 0f                	je     668fd2 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x432>
  668fc3:	f0 48 ff 08          	lock decq (%rax)
  668fc7:	75 09                	jne    668fd2 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x432>
  668fc9:	4c 89 ff             	mov    %r15,%rdi
  668fcc:	ff 15 96 df 11 00    	call   *0x11df96(%rip)        # 786f68 <_DYNAMIC+0x260>
  668fd2:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  668fd7:	4d 89 a6 48 0a 00 00 	mov    %r12,0xa48(%r14)
  668fde:	be 01 00 00 00       	mov    $0x1,%esi
  668fe3:	4c 89 f7             	mov    %r14,%rdi
  668fe6:	e8 45 37 00 00       	call   66c730 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner8register>
  668feb:	83 f8 ff             	cmp    $0xffffffff,%eax
  668fee:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
  668ff2:	74 2c                	je     669020 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x480>
  668ff4:	41 89 c4             	mov    %eax,%r12d
  668ff7:	45 31 ff             	xor    %r15d,%r15d
  668ffa:	44 89 a4 24 b8 00 00 	mov    %r12d,0xb8(%rsp)
  669001:	00 
  669002:	44 89 bc 24 bc 00 00 	mov    %r15d,0xbc(%rsp)
  669009:	00 
  66900a:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  669011:	00 ff ff ff ff 
  669016:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66901b:	e9 c7 28 00 00       	jmp    66b8e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2d47>
  669020:	f6 c1 02             	test   $0x2,%cl
  669023:	74 0e                	je     669033 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x493>
  669025:	49 83 be 50 0a 00 00 	cmpq   $0x0,0xa50(%r14)
  66902c:	00 
  66902d:	0f 84 51 2a 00 00    	je     66ba84 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ee4>
  669033:	48 c7 84 24 e8 02 00 	movq   $0xffffffffffffffff,0x2e8(%rsp)
  66903a:	00 ff ff ff ff 
  66903f:	48 8d 05 3c 23 bf ff 	lea    -0x40dcc4(%rip),%rax        # 25b382 <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text13PRIMARY_BYTES+0x1f460a>
  669046:	48 89 84 24 f0 02 00 	mov    %rax,0x2f0(%rsp)
  66904d:	00 
  66904e:	48 c7 84 24 f8 02 00 	movq   $0xc,0x2f8(%rsp)
  669055:	00 0c 00 00 00 
  66905a:	48 c7 84 24 00 03 00 	movq   $0xffffffffffffffff,0x300(%rsp)
  669061:	00 ff ff ff ff 
  669066:	48 8d 05 21 23 bf ff 	lea    -0x40dcdf(%rip),%rax        # 25b38e <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text13PRIMARY_BYTES+0x1f4616>
  66906d:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  669074:	00 
  669075:	48 c7 84 24 10 03 00 	movq   $0x11,0x310(%rsp)
  66907c:	00 11 00 00 00 
  669081:	48 c7 84 24 18 03 00 	movq   $0xffffffffffffffff,0x318(%rsp)
  669088:	00 ff ff ff ff 
  66908d:	4c 8d 35 0b 23 bf ff 	lea    -0x40dcf5(%rip),%r14        # 25b39f <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text13PRIMARY_BYTES+0x1f4627>
  669094:	4c 89 b4 24 20 03 00 	mov    %r14,0x320(%rsp)
  66909b:	00 
  66909c:	48 c7 84 24 28 03 00 	movq   $0x11,0x328(%rsp)
  6690a3:	00 11 00 00 00 
  6690a8:	f6 c1 01             	test   $0x1,%cl
  6690ab:	75 1c                	jne    6690c9 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x529>
  6690ad:	4c 8d bc 24 00 03 00 	lea    0x300(%rsp),%r15
  6690b4:	00 
  6690b5:	b8 01 00 00 00       	mov    $0x1,%eax
  6690ba:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
  6690c1:	00 
  6690c2:	f6 c1 02             	test   $0x2,%cl
  6690c5:	75 24                	jne    6690eb <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x54b>
  6690c7:	eb 5a                	jmp    669123 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x583>
  6690c9:	4c 8d bc 24 18 03 00 	lea    0x318(%rsp),%r15
  6690d0:	00 
  6690d1:	48 89 84 24 08 03 00 	mov    %rax,0x308(%rsp)
  6690d8:	00 
  6690d9:	b8 02 00 00 00       	mov    $0x2,%eax
  6690de:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
  6690e5:	00 
  6690e6:	f6 c1 02             	test   $0x2,%cl
  6690e9:	74 38                	je     669123 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x583>
  6690eb:	49 8b 37             	mov    (%r15),%rsi
  6690ee:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  6690f2:	77 14                	ja     669108 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x568>
  6690f4:	48 85 f6             	test   %rsi,%rsi
  6690f7:	74 0f                	je     669108 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x568>
  6690f9:	49 8b 7f 08          	mov    0x8(%r15),%rdi
  6690fd:	ba 01 00 00 00       	mov    $0x1,%edx
  669102:	ff 15 38 de 11 00    	call   *0x11de38(%rip)        # 786f40 <_DYNAMIC+0x238>
  669108:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  66910f:	4d 89 77 08          	mov    %r14,0x8(%r15)
  669113:	49 c7 47 10 11 00 00 	movq   $0x11,0x10(%r15)
  66911a:	00 
  66911b:	48 ff 84 24 00 02 00 	incq   0x200(%rsp)
  669122:	00 
  669123:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
  66912a:	00 00 00 00 00 
  66912f:	48 c7 84 24 00 01 00 	movq   $0x4,0x100(%rsp)
  669136:	00 04 00 00 00 
  66913b:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
  669142:	00 00 00 00 00 
  669147:	48 c7 84 24 40 01 00 	movq   $0xffffffffffffffff,0x140(%rsp)
  66914e:	00 ff ff ff ff 
  669153:	f6 84 24 b8 01 00 00 	testb  $0x1,0x1b8(%rsp)
  66915a:	01 
  66915b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  669160:	75 11                	jne    669173 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x5d3>
  669162:	f3 0f 10 05 12 45 9b 	movss  -0x64baee(%rip),%xmm0        # 1d67c <GCC_except_table0+0x94>
  669169:	ff 
  66916a:	f3 0f 11 84 24 bc 01 	movss  %xmm0,0x1bc(%rsp)
  669171:	00 00 
  669173:	48 8d 48 78          	lea    0x78(%rax),%rcx
  669177:	48 89 8c 24 78 03 00 	mov    %rcx,0x378(%rsp)
  66917e:	00 
  66917f:	48 8d 88 38 06 00 00 	lea    0x638(%rax),%rcx
  669186:	48 89 8c 24 70 03 00 	mov    %rcx,0x370(%rsp)
  66918d:	00 
  66918e:	48 05 c8 08 00 00    	add    $0x8c8,%rax
  669194:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  669199:	4c 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%r15
  6691a0:	00 
  6691a1:	0f 57 c0             	xorps  %xmm0,%xmm0
  6691a4:	0f 29 84 24 70 02 00 	movaps %xmm0,0x270(%rsp)
  6691ab:	00 
  6691ac:	f3 0f 11 44 24 34    	movss  %xmm0,0x34(%rsp)
  6691b2:	f3 0f 11 84 24 94 00 	movss  %xmm0,0x94(%rsp)
  6691b9:	00 00 
  6691bb:	4c 8d a4 24 b8 04 00 	lea    0x4b8(%rsp),%r12
  6691c2:	00 
  6691c3:	48 8d 05 26 32 11 00 	lea    0x113226(%rip),%rax        # 77c3f0 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x160>
  6691ca:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  6691cf:	48 8d 05 ea 37 11 00 	lea    0x1137ea(%rip),%rax        # 77c9c0 <anon.82ba7c80bfefe788d7fd53f5e69bad68.30.llvm.13034477518265263966>
  6691d6:	48 89 84 24 58 02 00 	mov    %rax,0x258(%rsp)
  6691dd:	00 
  6691de:	48 c7 84 24 f8 01 00 	movq   $0x0,0x1f8(%rsp)
  6691e5:	00 00 00 00 00 
  6691ea:	31 d2                	xor    %edx,%edx
  6691ec:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  6691f3:	00 
  6691f4:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6691f9:	31 c0                	xor    %eax,%eax
  6691fb:	be fe ff ff ff       	mov    $0xfffffffe,%esi
  669200:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  669205:	83 fe fe             	cmp    $0xfffffffe,%esi
  669208:	75 26                	jne    669230 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x690>
  66920a:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  66920f:	4c 3b 8c 24 a0 01 00 	cmp    0x1a0(%rsp),%r9
  669216:	00 
  669217:	74 2b                	je     669244 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x6a4>
  669219:	41 0f b6 09          	movzbl (%r9),%ecx
  66921d:	84 c9                	test   %cl,%cl
  66921f:	78 3e                	js     66925f <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x6bf>
  669221:	49 8d 51 01          	lea    0x1(%r9),%rdx
  669225:	e9 92 00 00 00       	jmp    6692bc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x71c>
  66922a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  669230:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  669235:	89 f1                	mov    %esi,%ecx
  669237:	4c 8b 84 24 58 03 00 	mov    0x358(%rsp),%r8
  66923e:	00 
  66923f:	e9 81 00 00 00       	jmp    6692c5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x725>
  669244:	c7 84 24 98 00 00 00 	movl   $0xfffffffe,0x98(%rsp)
  66924b:	fe ff ff ff 
  66924f:	b1 01                	mov    $0x1,%cl
  669251:	89 4c 24 44          	mov    %ecx,0x44(%rsp)
  669255:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  66925a:	e9 b7 01 00 00       	jmp    669416 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x876>
  66925f:	49 89 c0             	mov    %rax,%r8
  669262:	89 c8                	mov    %ecx,%eax
  669264:	83 e0 1f             	and    $0x1f,%eax
  669267:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  66926c:	83 e7 3f             	and    $0x3f,%edi
  66926f:	80 f9 e0             	cmp    $0xe0,%cl
  669272:	72 2d                	jb     6692a1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x701>
  669274:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  669279:	c1 e7 06             	shl    $0x6,%edi
  66927c:	83 e6 3f             	and    $0x3f,%esi
  66927f:	09 fe                	or     %edi,%esi
  669281:	80 f9 f0             	cmp    $0xf0,%cl
  669284:	72 28                	jb     6692ae <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x70e>
  669286:	49 8d 51 04          	lea    0x4(%r9),%rdx
  66928a:	41 0f b6 49 03       	movzbl 0x3(%r9),%ecx
  66928f:	83 e0 07             	and    $0x7,%eax
  669292:	c1 e0 12             	shl    $0x12,%eax
  669295:	c1 e6 06             	shl    $0x6,%esi
  669298:	83 e1 3f             	and    $0x3f,%ecx
  66929b:	09 f1                	or     %esi,%ecx
  66929d:	09 c1                	or     %eax,%ecx
  66929f:	eb 18                	jmp    6692b9 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x719>
  6692a1:	49 8d 51 02          	lea    0x2(%r9),%rdx
  6692a5:	c1 e0 06             	shl    $0x6,%eax
  6692a8:	09 f8                	or     %edi,%eax
  6692aa:	89 c1                	mov    %eax,%ecx
  6692ac:	eb 0b                	jmp    6692b9 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x719>
  6692ae:	49 8d 51 03          	lea    0x3(%r9),%rdx
  6692b2:	c1 e0 0c             	shl    $0xc,%eax
  6692b5:	09 c6                	or     %eax,%esi
  6692b7:	89 f1                	mov    %esi,%ecx
  6692b9:	4c 89 c0             	mov    %r8,%rax
  6692bc:	49 89 c0             	mov    %rax,%r8
  6692bf:	4c 29 c8             	sub    %r9,%rax
  6692c2:	48 01 d0             	add    %rdx,%rax
  6692c5:	c7 84 24 98 00 00 00 	movl   $0xfffffffe,0x98(%rsp)
  6692cc:	fe ff ff ff 
  6692d0:	40 b6 01             	mov    $0x1,%sil
  6692d3:	89 74 24 44          	mov    %esi,0x44(%rsp)
  6692d7:	83 f9 0c             	cmp    $0xc,%ecx
  6692da:	7e 24                	jle    669300 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x760>
  6692dc:	83 f9 0d             	cmp    $0xd,%ecx
  6692df:	0f 84 3b 01 00 00    	je     669420 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x880>
  6692e5:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  6692eb:	74 21                	je     66930e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x76e>
  6692ed:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  6692f3:	74 19                	je     66930e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x76e>
  6692f5:	eb 66                	jmp    66935d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x7bd>
  6692f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6692fe:	00 00 
  669300:	83 f9 ff             	cmp    $0xffffffff,%ecx
  669303:	0f 84 03 01 00 00    	je     66940c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x86c>
  669309:	83 f9 0a             	cmp    $0xa,%ecx
  66930c:	75 4f                	jne    66935d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x7bd>
  66930e:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
  669313:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  669319:	0f 83 12 01 00 00    	jae    669431 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x891>
  66931f:	49 8d 70 01          	lea    0x1(%r8),%rsi
  669323:	83 f9 0d             	cmp    $0xd,%ecx
  669326:	0f 84 2d 1d 00 00    	je     66b059 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x24b9>
  66932c:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
  669333:	00 
  669334:	e9 12 01 00 00       	jmp    66944b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x8ab>
  669339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  669340:	81 f9 29 20 00 00    	cmp    $0x2029,%ecx
  669346:	0f 84 d9 00 00 00    	je     669425 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x885>
  66934c:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  669351:	81 f9 85 00 00 00    	cmp    $0x85,%ecx
  669357:	0f 84 c8 00 00 00    	je     669425 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x885>
  66935d:	48 3b 94 24 a0 01 00 	cmp    0x1a0(%rsp),%rdx
  669364:	00 
  669365:	0f 84 a1 00 00 00    	je     66940c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x86c>
  66936b:	49 89 c0             	mov    %rax,%r8
  66936e:	0f b6 0a             	movzbl (%rdx),%ecx
  669371:	84 c9                	test   %cl,%cl
  669373:	78 0b                	js     669380 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x7e0>
  669375:	48 8d 42 01          	lea    0x1(%rdx),%rax
  669379:	eb 65                	jmp    6693e0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x840>
  66937b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  669380:	89 c8                	mov    %ecx,%eax
  669382:	83 e0 1f             	and    $0x1f,%eax
  669385:	0f b6 7a 01          	movzbl 0x1(%rdx),%edi
  669389:	83 e7 3f             	and    $0x3f,%edi
  66938c:	80 f9 df             	cmp    $0xdf,%cl
  66938f:	76 2e                	jbe    6693bf <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x81f>
  669391:	0f b6 72 02          	movzbl 0x2(%rdx),%esi
  669395:	c1 e7 06             	shl    $0x6,%edi
  669398:	83 e6 3f             	and    $0x3f,%esi
  66939b:	09 fe                	or     %edi,%esi
  66939d:	80 f9 f0             	cmp    $0xf0,%cl
  6693a0:	72 2d                	jb     6693cf <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x82f>
  6693a2:	48 8d 7a 04          	lea    0x4(%rdx),%rdi
  6693a6:	0f b6 4a 03          	movzbl 0x3(%rdx),%ecx
  6693aa:	83 e0 07             	and    $0x7,%eax
  6693ad:	c1 e0 12             	shl    $0x12,%eax
  6693b0:	c1 e6 06             	shl    $0x6,%esi
  6693b3:	83 e1 3f             	and    $0x3f,%ecx
  6693b6:	09 f1                	or     %esi,%ecx
  6693b8:	09 c1                	or     %eax,%ecx
  6693ba:	48 89 f8             	mov    %rdi,%rax
  6693bd:	eb 21                	jmp    6693e0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x840>
  6693bf:	48 8d 72 02          	lea    0x2(%rdx),%rsi
  6693c3:	c1 e0 06             	shl    $0x6,%eax
  6693c6:	09 f8                	or     %edi,%eax
  6693c8:	89 c1                	mov    %eax,%ecx
  6693ca:	48 89 f0             	mov    %rsi,%rax
  6693cd:	eb 11                	jmp    6693e0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x840>
  6693cf:	48 8d 4a 03          	lea    0x3(%rdx),%rcx
  6693d3:	c1 e0 0c             	shl    $0xc,%eax
  6693d6:	09 c6                	or     %eax,%esi
  6693d8:	48 89 c8             	mov    %rcx,%rax
  6693db:	89 f1                	mov    %esi,%ecx
  6693dd:	0f 1f 00             	nopl   (%rax)
  6693e0:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6693e5:	48 29 d0             	sub    %rdx,%rax
  6693e8:	4c 01 c0             	add    %r8,%rax
  6693eb:	81 f9 84 00 00 00    	cmp    $0x84,%ecx
  6693f1:	0f 8f 49 ff ff ff    	jg     669340 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x7a0>
  6693f7:	83 f9 0a             	cmp    $0xa,%ecx
  6693fa:	74 29                	je     669425 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x885>
  6693fc:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  669401:	83 f9 0d             	cmp    $0xd,%ecx
  669404:	0f 85 53 ff ff ff    	jne    66935d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x7bd>
  66940a:	eb 19                	jmp    669425 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x885>
  66940c:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  669411:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
  669416:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  66941b:	48 89 ce             	mov    %rcx,%rsi
  66941e:	eb 30                	jmp    669450 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x8b0>
  669420:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
  669425:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
  66942b:	0f 82 ee fe ff ff    	jb     66931f <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x77f>
  669431:	81 f9 00 08 00 00    	cmp    $0x800,%ecx
  669437:	be 03 00 00 00       	mov    $0x3,%esi
  66943c:	48 83 de 00          	sbb    $0x0,%rsi
  669440:	4c 01 c6             	add    %r8,%rsi
  669443:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
  66944a:	00 
  66944b:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  669450:	4c 89 84 24 80 00 00 	mov    %r8,0x80(%rsp)
  669457:	00 
  669458:	4c 89 c2             	mov    %r8,%rdx
  66945b:	48 29 ca             	sub    %rcx,%rdx
  66945e:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  669463:	0f 82 2a 2d 00 00    	jb     66c193 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35f3>
  669469:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  66946f:	48 89 84 24 68 03 00 	mov    %rax,0x368(%rsp)
  669476:	00 
  669477:	74 2d                	je     6694a6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x906>
  669479:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  66947e:	48 3b 4c 24 50       	cmp    0x50(%rsp),%rcx
  669483:	73 1b                	jae    6694a0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x900>
  669485:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  66948c:	00 
  66948d:	80 3c 08 bf          	cmpb   $0xbf,(%rax,%rcx,1)
  669491:	7f 13                	jg     6694a6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x906>
  669493:	e9 fb 2c 00 00       	jmp    66c193 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35f3>
  669498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  66949f:	00 
  6694a0:	0f 85 ed 2c 00 00    	jne    66c193 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35f3>
  6694a6:	48 83 bc 24 80 00 00 	cmpq   $0x0,0x80(%rsp)
  6694ad:	00 00 
  6694af:	74 35                	je     6694e6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x946>
  6694b1:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  6694b8:	00 
  6694b9:	48 3b 4c 24 50       	cmp    0x50(%rsp),%rcx
  6694be:	73 20                	jae    6694e0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x940>
  6694c0:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  6694c7:	00 
  6694c8:	80 3c 08 c0          	cmpb   $0xc0,(%rax,%rcx,1)
  6694cc:	7d 18                	jge    6694e6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x946>
  6694ce:	e9 c0 2c 00 00       	jmp    66c193 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35f3>
  6694d3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6694da:	84 00 00 00 00 00 
  6694e0:	0f 85 ad 2c 00 00    	jne    66c193 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35f3>
  6694e6:	48 89 b4 24 60 03 00 	mov    %rsi,0x360(%rsp)
  6694ed:	00 
  6694ee:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  6694f5:	00 
  6694f6:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6694fb:	48 01 c1             	add    %rax,%rcx
  6694fe:	48 8d bc 24 88 04 00 	lea    0x488(%rsp),%rdi
  669505:	00 
  669506:	48 8b b4 24 78 03 00 	mov    0x378(%rsp),%rsi
  66950d:	00 
  66950e:	48 8b 94 24 70 03 00 	mov    0x370(%rsp),%rdx
  669515:	00 
  669516:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  66951b:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  669520:	f3 0f 10 05 e4 40 9b 	movss  -0x64bf1c(%rip),%xmm0        # 1d60c <GCC_except_table0+0x24>
  669527:	ff 
  669528:	45 31 c9             	xor    %r9d,%r9d
  66952b:	e8 10 aa ff ff       	call   663f40 <_RNvMNtCshQYmODNYIQG_6parley7contextINtB2_13LayoutContextuE14ranged_builderCs6tOD1aKRtN9_11gpui_canvas>
  669530:	48 8d bc 24 88 04 00 	lea    0x488(%rsp),%rdi
  669537:	00 
  669538:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  66953f:	00 
  669540:	48 8b 94 24 00 02 00 	mov    0x200(%rsp),%rdx
  669547:	00 
  669548:	e8 83 f4 00 00       	call   6789d0 <_RINvMs_NtCshQYmODNYIQG_6parley7builderINtB5_13RangedBuilderuE12push_defaultRSNtNtCs2D57TIA91Kp_8parlance11font_family14FontFamilyNameECs6tOD1aKRtN9_11gpui_canvas>
  66954d:	4c 8b b4 24 88 04 00 	mov    0x488(%rsp),%r14
  669554:	00 
  669555:	4c 8b ac 24 90 04 00 	mov    0x490(%rsp),%r13
  66955c:	00 
  66955d:	49 8d b6 30 02 00 00 	lea    0x230(%r14),%rsi
  669564:	c6 84 24 00 07 00 00 	movb   $0x1,0x700(%rsp)
  66956b:	01 
  66956c:	f3 0f 10 84 24 9c 00 	movss  0x9c(%rsp),%xmm0
  669573:	00 00 
  669575:	f3 0f 11 84 24 04 07 	movss  %xmm0,0x704(%rsp)
  66957c:	00 00 
  66957e:	f3 0f 10 84 24 a8 04 	movss  0x4a8(%rsp),%xmm0
  669585:	00 00 
  669587:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  66958e:	00 
  66958f:	48 89 f5             	mov    %rsi,%rbp
  669592:	4c 89 ea             	mov    %r13,%rdx
  669595:	48 8d 9c 24 00 07 00 	lea    0x700(%rsp),%rbx
  66959c:	00 
  66959d:	48 89 d9             	mov    %rbx,%rcx
  6695a0:	f3 0f 11 44 24 20    	movss  %xmm0,0x20(%rsp)
  6695a6:	e8 15 c7 ff ff       	call   665cc0 <_RINvMs2_NtCshQYmODNYIQG_6parley7resolveNtB6_14ResolveContext16resolve_propertyuECs6tOD1aKRtN9_11gpui_canvas>
  6695ab:	48 89 df             	mov    %rbx,%rdi
  6695ae:	e8 0d f6 00 00       	call   678bc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCshQYmODNYIQG_6parley5style13StylePropertyuEECs6tOD1aKRtN9_11gpui_canvas.llvm.3659747509729363938>
  6695b3:	49 83 be 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r14)
  6695ba:	ff 
  6695bb:	0f 84 12 28 00 00    	je     66bdd3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3233>
  6695c1:	49 8d 9e 98 04 00 00 	lea    0x498(%r14),%rbx
  6695c8:	48 89 df             	mov    %rbx,%rdi
  6695cb:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  6695d2:	00 
  6695d3:	e8 88 cc ff ff       	call   666260 <_RNvMs3_NtCshQYmODNYIQG_6parley7resolveINtB5_13ResolvedStyleuE5applyCs6tOD1aKRtN9_11gpui_canvas>
  6695d8:	66 c7 84 24 00 07 00 	movw   $0x117,0x700(%rsp)
  6695df:	00 17 01 
  6695e2:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  6695e9:	00 
  6695ea:	48 89 ee             	mov    %rbp,%rsi
  6695ed:	4c 89 ea             	mov    %r13,%rdx
  6695f0:	4c 8d ac 24 00 07 00 	lea    0x700(%rsp),%r13
  6695f7:	00 
  6695f8:	4c 89 e9             	mov    %r13,%rcx
  6695fb:	f3 0f 10 44 24 20    	movss  0x20(%rsp),%xmm0
  669601:	e8 ba c6 ff ff       	call   665cc0 <_RINvMs2_NtCshQYmODNYIQG_6parley7resolveNtB6_14ResolveContext16resolve_propertyuECs6tOD1aKRtN9_11gpui_canvas>
  669606:	4c 89 ef             	mov    %r13,%rdi
  669609:	e8 b2 f5 00 00       	call   678bc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCshQYmODNYIQG_6parley5style13StylePropertyuEECs6tOD1aKRtN9_11gpui_canvas.llvm.3659747509729363938>
  66960e:	49 83 be 20 05 00 00 	cmpq   $0xffffffffffffffff,0x520(%r14)
  669615:	ff 
  669616:	0f 84 b7 27 00 00    	je     66bdd3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3233>
  66961c:	48 89 df             	mov    %rbx,%rdi
  66961f:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  669626:	00 
  669627:	e8 34 cc ff ff       	call   666260 <_RNvMs3_NtCshQYmODNYIQG_6parley7resolveINtB5_13ResolvedStyleuE5applyCs6tOD1aKRtN9_11gpui_canvas>
  66962c:	48 8d bc 24 88 04 00 	lea    0x488(%rsp),%rdi
  669633:	00 
  669634:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  669639:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  66963e:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  669643:	e8 d8 bc 00 00       	call   675320 <_RINvMs_NtCshQYmODNYIQG_6parley7builderINtB5_13RangedBuilderuE10build_intoReECs6tOD1aKRtN9_11gpui_canvas>
  669648:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66964f:	00 
  669650:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  669655:	e8 46 54 01 00       	call   67eaa0 <_RNvMs8_NtNtCshQYmODNYIQG_6parley6layout10line_breakINtB5_10BreakLinesuE3newCs6tOD1aKRtN9_11gpui_canvas>
  66965a:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  669661:	00 
  669662:	f3 0f 10 84 24 bc 01 	movss  0x1bc(%rsp),%xmm0
  669669:	00 00 
  66966b:	e8 10 45 01 00       	call   67db80 <_RNvMs8_NtNtCshQYmODNYIQG_6parley6layout10line_breakINtB5_10BreakLinesuE15break_remainingCs6tOD1aKRtN9_11gpui_canvas>
  669670:	80 bc 24 1c 02 00 00 	cmpb   $0x0,0x21c(%rsp)
  669677:	00 
  669678:	74 16                	je     669690 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xaf0>
  66967a:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  669681:	00 ff 
  669683:	0f 85 0a 02 00 00    	jne    669893 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xcf3>
  669689:	31 c0                	xor    %eax,%eax
  66968b:	e9 86 01 00 00       	jmp    669816 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xc76>
  669690:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  669696:	0f 85 64 01 00 00    	jne    669800 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xc60>
  66969c:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  6696a3:	00 
  6696a4:	48 3b 44 24 50       	cmp    0x50(%rsp),%rax
  6696a9:	0f 85 51 01 00 00    	jne    669800 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xc60>
  6696af:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6696b4:	48 83 b8 e0 09 00 00 	cmpq   $0x1,0x9e0(%rax)
  6696bb:	01 
  6696bc:	0f 85 3e 01 00 00    	jne    669800 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xc60>
  6696c2:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6696c7:	48 8b 82 d8 09 00 00 	mov    0x9d8(%rdx),%rax
  6696ce:	48 8d 48 70          	lea    0x70(%rax),%rcx
  6696d2:	48 89 8c 24 08 07 00 	mov    %rcx,0x708(%rsp)
  6696d9:	00 
  6696da:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  6696e1:	00 00 00 00 00 
  6696e6:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  6696eb:	48 89 b4 24 18 07 00 	mov    %rsi,0x718(%rsp)
  6696f2:	00 
  6696f3:	48 c7 84 24 48 07 00 	movq   $0x0,0x748(%rsp)
  6696fa:	00 00 00 00 00 
  6696ff:	48 89 94 24 b0 04 00 	mov    %rdx,0x4b0(%rsp)
  669706:	00 
  669707:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  66970e:	00 00 00 00 00 
  669713:	48 89 8c 24 00 07 00 	mov    %rcx,0x700(%rsp)
  66971a:	00 
  66971b:	48 8b 78 10          	mov    0x10(%rax),%rdi
  66971f:	48 8b 70 18          	mov    0x18(%rax),%rsi
  669723:	48 8b 92 f8 09 00 00 	mov    0x9f8(%rdx),%rdx
  66972a:	48 39 fe             	cmp    %rdi,%rsi
  66972d:	0f 82 2a 2a 00 00    	jb     66c15d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35bd>
  669733:	48 39 d6             	cmp    %rdx,%rsi
  669736:	0f 87 21 2a 00 00    	ja     66c15d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35bd>
  66973c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  669741:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  669748:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  66974c:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  669750:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  669754:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  669758:	48 89 8c 24 20 07 00 	mov    %rcx,0x720(%rsp)
  66975f:	00 
  669760:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  669767:	00 
  669768:	48 c7 84 24 30 07 00 	movq   $0x0,0x730(%rsp)
  66976f:	00 00 00 00 00 
  669774:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  669779:	48 89 84 24 38 07 00 	mov    %rax,0x738(%rsp)
  669780:	00 
  669781:	c7 84 24 40 07 00 00 	movl   $0x0,0x740(%rsp)
  669788:	00 00 00 00 
  66978c:	48 8d bc 24 20 07 00 	lea    0x720(%rsp),%rdi
  669793:	00 
  669794:	48 8d b4 24 48 07 00 	lea    0x748(%rsp),%rsi
  66979b:	00 
  66979c:	48 8d 94 24 b0 04 00 	lea    0x4b0(%rsp),%rdx
  6697a3:	00 
  6697a4:	e8 d7 85 01 00       	call   681d80 <_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_9enumerate9EnumerateINtNtNtBc_5slice4iter4IterNtNtNtCshQYmODNYIQG_6parley6layout4data12LineItemDataEENCNvMNtB1T_4lineINtB2N_4LineuE19items_nonpositioned0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_10filter_map19filter_map_try_foldINtB2N_8LineItemuEINtNtB1T_3run3RunuEuINtNtNtBc_3ops12control_flow11ControlFlowuENCNvB2M_4runs0QNCINvNvB3z_3all5checkB5g_NCNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB73_7Planner11shape_inners0_0E0E0B5A_EB77_>
  6697a9:	48 c7 84 24 10 07 00 	movq   $0x1,0x710(%rsp)
  6697b0:	00 01 00 00 00 
  6697b5:	84 c0                	test   %al,%al
  6697b7:	75 47                	jne    669800 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xc60>
  6697b9:	48 c7 84 24 20 07 00 	movq   $0x0,0x720(%rsp)
  6697c0:	00 00 00 00 00 
  6697c5:	48 83 bc 24 48 07 00 	cmpq   $0x0,0x748(%rsp)
  6697cc:	00 00 
  6697ce:	0f 84 77 1e 00 00    	je     66b64b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2aab>
  6697d4:	48 8d bc 24 48 07 00 	lea    0x748(%rsp),%rdi
  6697db:	00 
  6697dc:	48 8d b4 24 70 07 00 	lea    0x770(%rsp),%rsi
  6697e3:	00 
  6697e4:	48 8d 94 24 b0 04 00 	lea    0x4b0(%rsp),%rdx
  6697eb:	00 
  6697ec:	e8 8f 85 01 00       	call   681d80 <_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_9enumerate9EnumerateINtNtNtBc_5slice4iter4IterNtNtNtCshQYmODNYIQG_6parley6layout4data12LineItemDataEENCNvMNtB1T_4lineINtB2N_4LineuE19items_nonpositioned0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_10filter_map19filter_map_try_foldINtB2N_8LineItemuEINtNtB1T_3run3RunuEuINtNtNtBc_3ops12control_flow11ControlFlowuENCNvB2M_4runs0QNCINvNvB3z_3all5checkB5g_NCNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB73_7Planner11shape_inners0_0E0E0B5A_EB77_>
  6697f1:	84 c0                	test   %al,%al
  6697f3:	0f 84 52 1e 00 00    	je     66b64b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2aab>
  6697f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  669800:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  669807:	00 ff 
  669809:	0f 85 84 00 00 00    	jne    669893 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xcf3>
  66980f:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  669816:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  66981d:	00 00 00 00 00 
  669822:	48 c7 84 24 48 01 00 	movq   $0x4,0x148(%rsp)
  669829:	00 04 00 00 00 
  66982e:	48 8d 8c 24 48 01 00 	lea    0x148(%rsp),%rcx
  669835:	00 
  669836:	0f 57 c0             	xorps  %xmm0,%xmm0
  669839:	0f 11 41 08          	movups %xmm0,0x8(%rcx)
  66983d:	48 c7 84 24 60 01 00 	movq   $0x4,0x160(%rsp)
  669844:	00 04 00 00 00 
  669849:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  669850:	00 00 00 00 00 
  669855:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  66985c:	00 
  66985d:	48 c7 84 24 78 01 00 	movq   $0x4,0x178(%rsp)
  669864:	00 04 00 00 00 
  669869:	48 c7 84 24 80 01 00 	movq   $0x0,0x180(%rsp)
  669870:	00 00 00 00 00 
  669875:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  66987a:	89 84 24 88 01 00 00 	mov    %eax,0x188(%rsp)
  669881:	f3 0f 10 84 24 9c 00 	movss  0x9c(%rsp),%xmm0
  669888:	00 00 
  66988a:	f3 0f 11 84 24 8c 01 	movss  %xmm0,0x18c(%rsp)
  669891:	00 00 
  669893:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  669898:	48 8b 98 e0 09 00 00 	mov    0x9e0(%rax),%rbx
  66989f:	48 85 db             	test   %rbx,%rbx
  6698a2:	0f 84 08 01 00 00    	je     6699b0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe10>
  6698a8:	48 8b a8 d8 09 00 00 	mov    0x9d8(%rax),%rbp
  6698af:	45 31 f6             	xor    %r14d,%r14d
  6698b2:	45 31 ed             	xor    %r13d,%r13d
  6698b5:	eb 15                	jmp    6698cc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xd2c>
  6698b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6698be:	00 00 
  6698c0:	49 ff c6             	inc    %r14
  6698c3:	49 39 de             	cmp    %rbx,%r14
  6698c6:	0f 84 e7 00 00 00    	je     6699b3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe13>
  6698cc:	49 6b c6 70          	imul   $0x70,%r14,%rax
  6698d0:	48 01 e8             	add    %rbp,%rax
  6698d3:	4c 89 ac 24 00 07 00 	mov    %r13,0x700(%rsp)
  6698da:	00 
  6698db:	48 c7 84 24 08 07 00 	movq   $0x0,0x708(%rsp)
  6698e2:	00 00 00 00 00 
  6698e7:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  6698ec:	48 89 8c 24 10 07 00 	mov    %rcx,0x710(%rsp)
  6698f3:	00 
  6698f4:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  6698fb:	00 
  6698fc:	44 89 b4 24 20 07 00 	mov    %r14d,0x720(%rsp)
  669903:	00 
  669904:	c6 84 24 c8 07 00 00 	movb   $0x2,0x7c8(%rsp)
  66990b:	02 
  66990c:	c7 84 24 d0 07 00 00 	movl   $0x0,0x7d0(%rsp)
  669913:	00 00 00 00 
  669917:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
  66991e:	00 
  66991f:	48 8d b4 24 08 07 00 	lea    0x708(%rsp),%rsi
  669926:	00 
  669927:	e8 c4 a8 00 00       	call   6741f0 <_RNvXs3_NtNtCshQYmODNYIQG_6parley6layout4lineINtB5_12GlyphRunIteruENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  66992c:	83 bc 24 90 02 00 00 	cmpl   $0x1,0x290(%rsp)
  669933:	01 
  669934:	75 8a                	jne    6698c0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xd20>
  669936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66993d:	00 00 00 
  669940:	49 8b 47 38          	mov    0x38(%r15),%rax
  669944:	49 89 44 24 40       	mov    %rax,0x40(%r12)
  669949:	41 0f 10 47 f8       	movups -0x8(%r15),%xmm0
  66994e:	41 0f 10 4f 08       	movups 0x8(%r15),%xmm1
  669953:	41 0f 10 57 18       	movups 0x18(%r15),%xmm2
  669958:	41 0f 10 5f 28       	movups 0x28(%r15),%xmm3
  66995d:	41 0f 11 5c 24 30    	movups %xmm3,0x30(%r12)
  669963:	41 0f 11 54 24 20    	movups %xmm2,0x20(%r12)
  669969:	41 0f 11 4c 24 10    	movups %xmm1,0x10(%r12)
  66996f:	41 0f 11 04 24       	movups %xmm0,(%r12)
  669974:	4c 89 ac 24 b0 04 00 	mov    %r13,0x4b0(%rsp)
  66997b:	00 
  66997c:	4c 89 ee             	mov    %r13,%rsi
  66997f:	4c 89 e2             	mov    %r12,%rdx
  669982:	e8 d9 98 01 00       	call   683260 <_RNvXs1_NtNtNtCs4NRVxsYgnAr_4core3ops8function5implsQNCINvNtNtNtBb_4iter8adapters3map8map_foldINtNtNtCshQYmODNYIQG_6parley6layout4line20PositionedLayoutItemuEjjNCNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB2F_7Planner11shape_inners3_0NCINvXsK_NtNtBX_6traits5accumjNtB41_3Sum3sumINtBT_3MapINtNtBV_7flatten7FlatMapIB4B_INtNtBV_9enumerate9EnumerateINtNtNtBb_5slice4iter4IterNtNtB1y_4data8LineDataEENCNvMs_NtB1y_6layoutINtB6A_6LayoutuE5lines0EINtB1w_12GlyphRunIteruENCB2z_s2_0EB2x_EE0E0INtB7_5FnMutTjB1t_EE8call_mutB2J_>
  669987:	49 89 c5             	mov    %rax,%r13
  66998a:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
  669991:	00 
  669992:	48 8d b4 24 08 07 00 	lea    0x708(%rsp),%rsi
  669999:	00 
  66999a:	e8 51 a8 00 00       	call   6741f0 <_RNvXs3_NtNtCshQYmODNYIQG_6parley6layout4lineINtB5_12GlyphRunIteruENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  66999f:	80 bc 24 90 02 00 00 	cmpb   $0x0,0x290(%rsp)
  6699a6:	00 
  6699a7:	75 97                	jne    669940 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xda0>
  6699a9:	e9 12 ff ff ff       	jmp    6698c0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xd20>
  6699ae:	66 90                	xchg   %ax,%ax
  6699b0:	45 31 ed             	xor    %r13d,%r13d
  6699b3:	48 8b b4 24 08 01 00 	mov    0x108(%rsp),%rsi
  6699ba:	00 
  6699bb:	48 89 f0             	mov    %rsi,%rax
  6699be:	4c 01 e8             	add    %r13,%rax
  6699c1:	0f 92 c1             	setb   %cl
  6699c4:	48 3d 01 80 00 00    	cmp    $0x8001,%rax
  6699ca:	0f 93 c0             	setae  %al
  6699cd:	08 c8                	or     %cl,%al
  6699cf:	0f 85 cf 1d 00 00    	jne    66b7a4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c04>
  6699d5:	48 8b ac 24 80 00 00 	mov    0x80(%rsp),%rbp
  6699dc:	00 
  6699dd:	48 3b 6c 24 10       	cmp    0x10(%rsp),%rbp
  6699e2:	74 14                	je     6699f8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe58>
  6699e4:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  6699eb:	00 
  6699ec:	48 29 f0             	sub    %rsi,%rax
  6699ef:	49 39 c5             	cmp    %rax,%r13
  6699f2:	0f 87 8c 1d 00 00    	ja     66b784 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2be4>
  6699f8:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6699fd:	48 85 c0             	test   %rax,%rax
  669a00:	74 2b                	je     669a2d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe8d>
  669a02:	0f 57 c0             	xorps  %xmm0,%xmm0
  669a05:	f3 0f 11 84 24 e8 00 	movss  %xmm0,0xe8(%rsp)
  669a0c:	00 00 
  669a0e:	48 39 c5             	cmp    %rax,%rbp
  669a11:	75 59                	jne    669a6c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xecc>
  669a13:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  669a18:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  669a1f:	48 85 c0             	test   %rax,%rax
  669a22:	0f 85 88 00 00 00    	jne    669ab0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xf10>
  669a28:	e9 bc 14 00 00       	jmp    66aee9 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2349>
  669a2d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  669a32:	48 83 b8 e0 09 00 00 	cmpq   $0x0,0x9e0(%rax)
  669a39:	00 
  669a3a:	74 0e                	je     669a4a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xeaa>
  669a3c:	48 8b 80 d8 09 00 00 	mov    0x9d8(%rax),%rax
  669a43:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  669a48:	eb 03                	jmp    669a4d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xead>
  669a4a:	0f 57 c0             	xorps  %xmm0,%xmm0
  669a4d:	f3 0f 11 84 24 94 00 	movss  %xmm0,0x94(%rsp)
  669a54:	00 00 
  669a56:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  669a5b:	0f 57 c0             	xorps  %xmm0,%xmm0
  669a5e:	f3 0f 11 84 24 e8 00 	movss  %xmm0,0xe8(%rsp)
  669a65:	00 00 
  669a67:	48 39 c5             	cmp    %rax,%rbp
  669a6a:	74 a7                	je     669a13 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe73>
  669a6c:	83 bc 24 b8 01 00 00 	cmpl   $0x0,0x1b8(%rsp)
  669a73:	00 
  669a74:	74 0f                	je     669a85 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xee5>
  669a76:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  669a7b:	f3 0f 10 80 28 0a 00 	movss  0xa28(%rax),%xmm0
  669a82:	00 
  669a83:	eb 0d                	jmp    669a92 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xef2>
  669a85:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  669a8a:	f3 0f 10 80 2c 0a 00 	movss  0xa2c(%rax),%xmm0
  669a91:	00 
  669a92:	f3 0f 11 84 24 e8 00 	movss  %xmm0,0xe8(%rsp)
  669a99:	00 00 
  669a9b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  669aa0:	48 8b 81 e0 09 00 00 	mov    0x9e0(%rcx),%rax
  669aa7:	48 85 c0             	test   %rax,%rax
  669aaa:	0f 84 39 14 00 00    	je     66aee9 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2349>
  669ab0:	48 8b 89 d8 09 00 00 	mov    0x9d8(%rcx),%rcx
  669ab7:	48 6b c0 70          	imul   $0x70,%rax,%rax
  669abb:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  669ac2:	00 
  669ac3:	48 01 c8             	add    %rcx,%rax
  669ac6:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  669acd:	00 
  669ace:	c7 84 24 90 00 00 00 	movl   $0x0,0x90(%rsp)
  669ad5:	00 00 00 00 
  669ad9:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  669ae0:	00 ff 
  669ae2:	74 30                	je     669b14 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xf74>
  669ae4:	48 3b 6c 24 10       	cmp    0x10(%rsp),%rbp
  669ae9:	75 3f                	jne    669b2a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xf8a>
  669aeb:	45 31 ed             	xor    %r13d,%r13d
  669aee:	45 31 f6             	xor    %r14d,%r14d
  669af1:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  669af8:	00 
  669af9:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  669b00:	00 
  669b01:	48 89 8c 24 40 02 00 	mov    %rcx,0x240(%rsp)
  669b08:	00 
  669b09:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  669b0d:	74 44                	je     669b53 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xfb3>
  669b0f:	e9 d2 01 00 00       	jmp    669ce6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1146>
  669b14:	8b 8c 24 90 00 00 00 	mov    0x90(%rsp),%ecx
  669b1b:	89 c8                	mov    %ecx,%eax
  669b1d:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
  669b24:	00 
  669b25:	e9 cd 03 00 00       	jmp    669ef7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1357>
  669b2a:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  669b31:	00 
  669b32:	4c 8b 30             	mov    (%rax),%r14
  669b35:	4c 8b 68 08          	mov    0x8(%rax),%r13
  669b39:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  669b40:	00 
  669b41:	48 89 8c 24 40 02 00 	mov    %rcx,0x240(%rsp)
  669b48:	00 
  669b49:	80 78 68 02          	cmpb   $0x2,0x68(%rax)
  669b4d:	0f 85 93 01 00 00    	jne    669ce6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1146>
  669b53:	48 8b 78 10          	mov    0x10(%rax),%rdi
  669b57:	48 8b 70 18          	mov    0x18(%rax),%rsi
  669b5b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  669b60:	48 8b 90 f8 09 00 00 	mov    0x9f8(%rax),%rdx
  669b67:	48 39 fe             	cmp    %rdi,%rsi
  669b6a:	0f 82 ff 25 00 00    	jb     66c16f <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35cf>
  669b70:	48 39 d6             	cmp    %rdx,%rsi
  669b73:	0f 87 f6 25 00 00    	ja     66c16f <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35cf>
  669b79:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  669b7e:	48 8b 80 f0 09 00 00 	mov    0x9f0(%rax),%rax
  669b85:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  669b89:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
  669b8d:	48 8d 14 b6          	lea    (%rsi,%rsi,4),%rdx
  669b91:	48 8d 04 d0          	lea    (%rax,%rdx,8),%rax
  669b95:	48 89 8c 24 b0 04 00 	mov    %rcx,0x4b0(%rsp)
  669b9c:	00 
  669b9d:	48 89 84 24 b8 04 00 	mov    %rax,0x4b8(%rsp)
  669ba4:	00 
  669ba5:	48 c7 84 24 c0 04 00 	movq   $0x0,0x4c0(%rsp)
  669bac:	00 00 00 00 00 
  669bb1:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  669bb6:	48 89 84 24 c8 04 00 	mov    %rax,0x4c8(%rsp)
  669bbd:	00 
  669bbe:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
  669bc5:	89 84 24 d0 04 00 00 	mov    %eax,0x4d0(%rsp)
  669bcc:	c6 84 24 f0 06 00 00 	movb   $0x2,0x6f0(%rsp)
  669bd3:	02 
  669bd4:	48 8d 84 24 f8 06 00 	lea    0x6f8(%rsp),%rax
  669bdb:	00 
  669bdc:	48 89 84 24 90 02 00 	mov    %rax,0x290(%rsp)
  669be3:	00 
  669be4:	c6 84 24 e0 05 00 00 	movb   $0x2,0x5e0(%rsp)
  669beb:	02 
  669bec:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  669bf3:	00 
  669bf4:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  669bfb:	00 
  669bfc:	48 8d 94 24 90 02 00 	lea    0x290(%rsp),%rdx
  669c03:	00 
  669c04:	48 8d 8c 24 d8 04 00 	lea    0x4d8(%rsp),%rcx
  669c0b:	00 
  669c0c:	e8 6f 7a 01 00       	call   681680 <_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_10filter_map9FilterMapIBO_INtNtB8_9enumerate9EnumerateINtNtNtBc_5slice4iter4IterNtNtNtCshQYmODNYIQG_6parley6layout4data12LineItemDataEENCNvMNtB2r_4lineINtB3l_4LineuE19items_nonpositioned0ENCNvB3k_4runs0ENCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner11freeze_line0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNvMsg_NtB8_7flattenINtB6g_13FlattenCompatppE13iter_try_fold7flattenINtNtB2r_3run8ClustersuEuINtNtNtBc_3ops12control_flow11ControlFlowINtNtB2r_7cluster7ClusteruEENCINvNvXsi_B6g_B6t_B5n_8try_fold7flattenB7f_uB7E_NCINvNvB5n_4find5checkB8j_QNCB4o_s_0E0E0E0B7E_EB4u_>
  669c11:	48 8b 8c 24 00 07 00 	mov    0x700(%rsp),%rcx
  669c18:	00 
  669c19:	48 85 c9             	test   %rcx,%rcx
  669c1c:	0f 84 b2 00 00 00    	je     669cd4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1134>
  669c22:	8b bc 24 28 07 00 00 	mov    0x728(%rsp),%edi
  669c29:	8b b4 24 80 07 00 00 	mov    0x780(%rsp),%esi
  669c30:	8b 94 24 84 07 00 00 	mov    0x784(%rsp),%edx
  669c37:	48 8b 41 58          	mov    0x58(%rcx),%rax
  669c3b:	48 39 f8             	cmp    %rdi,%rax
  669c3e:	0f 86 43 26 00 00    	jbe    66c287 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36e7>
  669c44:	48 8b 41 50          	mov    0x50(%rcx),%rax
  669c48:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  669c4c:	48 c1 e7 04          	shl    $0x4,%rdi
  669c50:	0f 10 41 68          	movups 0x68(%rcx),%xmm0
  669c54:	0f 10 89 80 00 00 00 	movups 0x80(%rcx),%xmm1
  669c5b:	0f 10 91 98 00 00 00 	movups 0x98(%rcx),%xmm2
  669c62:	0f 11 84 24 00 07 00 	movups %xmm0,0x700(%rsp)
  669c69:	00 
  669c6a:	0f 11 8c 24 10 07 00 	movups %xmm1,0x710(%rsp)
  669c71:	00 
  669c72:	0f 11 94 24 20 07 00 	movups %xmm2,0x720(%rsp)
  669c79:	00 
  669c7a:	48 8b 44 38 50       	mov    0x50(%rax,%rdi,1),%rax
  669c7f:	48 89 84 24 30 07 00 	mov    %rax,0x730(%rsp)
  669c86:	00 
  669c87:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  669c8e:	00 
  669c8f:	ff 15 93 d6 11 00    	call   *0x11d693(%rip)        # 787328 <_DYNAMIC+0x620>
  669c95:	48 89 c3             	mov    %rax,%rbx
  669c98:	ba 48 02 00 00       	mov    $0x248,%edx
  669c9d:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
  669ca2:	4c 8d b4 24 00 07 00 	lea    0x700(%rsp),%r14
  669ca9:	00 
  669caa:	4c 89 f7             	mov    %r14,%rdi
  669cad:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  669cb4:	00 
  669cb5:	ff 15 1d d3 11 00    	call   *0x11d31d(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  669cbb:	4c 89 f7             	mov    %r14,%rdi
  669cbe:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  669cc3:	48 89 de             	mov    %rbx,%rsi
  669cc6:	e8 55 7c 01 00       	call   681920 <_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_6filter6FilterINtNtB8_7flatten7FlatMapINtNtB8_10filter_map9FilterMapIBO_INtNtB8_9enumerate9EnumerateINtNtNtBc_5slice4iter4IterNtNtNtCshQYmODNYIQG_6parley6layout4data12LineItemDataEENCNvMNtB3b_4lineINtB45_4LineuE19items_nonpositioned0ENCNvB44_4runs0EINtNtB3b_3run8ClustersuENCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner11freeze_line0ENCB5w_s_0ENCB5w_s0_0ENtNtNtBa_6traits8iterator8Iterator4foldjNCINvNvB6Q_6min_by4foldjNvYjNtNtBc_3cmp3Ord3cmpE0EB5C_>
  669ccb:	4c 39 e8             	cmp    %r13,%rax
  669cce:	4c 0f 42 e8          	cmovb  %rax,%r13
  669cd2:	eb 12                	jmp    669ce6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1146>
  669cd4:	80 bc 24 f0 06 00 00 	cmpb   $0x2,0x6f0(%rsp)
  669cdb:	02 
  669cdc:	c6 84 24 e0 05 00 00 	movb   $0x2,0x5e0(%rsp)
  669ce3:	02 
  669ce4:	75 3a                	jne    669d20 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1180>
  669ce6:	4d 39 ee             	cmp    %r13,%r14
  669ce9:	0f 87 d6 1e 00 00    	ja     66bbc5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3025>
  669cef:	4d 85 f6             	test   %r14,%r14
  669cf2:	0f 84 a4 00 00 00    	je     669d9c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x11fc>
  669cf8:	4c 3b 74 24 70       	cmp    0x70(%rsp),%r14
  669cfd:	0f 83 93 00 00 00    	jae    669d96 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x11f6>
  669d03:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  669d08:	42 80 3c 30 bf       	cmpb   $0xbf,(%rax,%r14,1)
  669d0d:	0f 8f 89 00 00 00    	jg     669d9c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x11fc>
  669d13:	e9 ad 1e 00 00       	jmp    66bbc5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3025>
  669d18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  669d1f:	00 
  669d20:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  669d27:	00 
  669d28:	48 8d b4 24 e8 05 00 	lea    0x5e8(%rsp),%rsi
  669d2f:	00 
  669d30:	e8 9b 99 01 00       	call   6836d0 <_RNvXs5_NtNtCshQYmODNYIQG_6parley6layout3runINtB5_8ClustersuENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  669d35:	48 8b 8c 24 00 07 00 	mov    0x700(%rsp),%rcx
  669d3c:	00 
  669d3d:	48 85 c9             	test   %rcx,%rcx
  669d40:	74 a4                	je     669ce6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1146>
  669d42:	8b bc 24 28 07 00 00 	mov    0x728(%rsp),%edi
  669d49:	48 8b 41 58          	mov    0x58(%rcx),%rax
  669d4d:	48 39 f8             	cmp    %rdi,%rax
  669d50:	0f 86 ae 24 00 00    	jbe    66c204 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3664>
  669d56:	8b b4 24 80 07 00 00 	mov    0x780(%rsp),%esi
  669d5d:	8b 94 24 84 07 00 00 	mov    0x784(%rsp),%edx
  669d64:	4c 8b 41 70          	mov    0x70(%rcx),%r8
  669d68:	39 f2                	cmp    %esi,%edx
  669d6a:	0f 82 82 23 00 00    	jb     66c0f2 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3552>
  669d70:	49 39 d0             	cmp    %rdx,%r8
  669d73:	0f 82 79 23 00 00    	jb     66c0f2 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3552>
  669d79:	39 f2                	cmp    %esi,%edx
  669d7b:	0f 84 94 24 00 00    	je     66c215 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3675>
  669d81:	4c 8b 41 68          	mov    0x68(%rcx),%r8
  669d85:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  669d89:	43 80 7c 88 07 06    	cmpb   $0x6,0x7(%r8,%r9,4)
  669d8f:	75 8f                	jne    669d20 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1180>
  669d91:	e9 a5 fe ff ff       	jmp    669c3b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x109b>
  669d96:	0f 85 29 1e 00 00    	jne    66bbc5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3025>
  669d9c:	4d 85 ed             	test   %r13,%r13
  669d9f:	74 1e                	je     669dbf <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x121f>
  669da1:	4c 3b 6c 24 70       	cmp    0x70(%rsp),%r13
  669da6:	73 11                	jae    669db9 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1219>
  669da8:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  669dad:	42 80 3c 28 c0       	cmpb   $0xc0,(%rax,%r13,1)
  669db2:	7d 0b                	jge    669dbf <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x121f>
  669db4:	e9 0c 1e 00 00       	jmp    66bbc5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3025>
  669db9:	0f 85 06 1e 00 00    	jne    66bbc5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3025>
  669dbf:	0f 57 c0             	xorps  %xmm0,%xmm0
  669dc2:	48 3b 6c 24 10       	cmp    0x10(%rsp),%rbp
  669dc7:	74 0d                	je     669dd6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1236>
  669dc9:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  669dd0:	00 
  669dd1:	f3 0f 10 40 30       	movss  0x30(%rax),%xmm0
  669dd6:	f3 0f 11 44 24 20    	movss  %xmm0,0x20(%rsp)
  669ddc:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  669de3:	00 
  669de4:	f3 0f 10 48 40       	movss  0x40(%rax),%xmm1
  669de9:	f3 0f 10 40 44       	movss  0x44(%rax),%xmm0
  669dee:	0f 29 8c 24 80 02 00 	movaps %xmm1,0x280(%rsp)
  669df5:	00 
  669df6:	f3 0f 5d 48 48       	minss  0x48(%rax),%xmm1
  669dfb:	0f 29 8c 24 90 01 00 	movaps %xmm1,0x190(%rsp)
  669e02:	00 
  669e03:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  669e0a:	00 
  669e0b:	f3 0f 5f 40 4c       	maxss  0x4c(%rax),%xmm0
  669e10:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  669e17:	00 
  669e18:	f3 0f 10 40 24       	movss  0x24(%rax),%xmm0
  669e1d:	f3 0f 58 44 24 34    	addss  0x34(%rsp),%xmm0
  669e23:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  669e29:	48 8b 9c 24 68 01 00 	mov    0x168(%rsp),%rbx
  669e30:	00 
  669e31:	48 3b 9c 24 58 01 00 	cmp    0x158(%rsp),%rbx
  669e38:	00 
  669e39:	75 0e                	jne    669e49 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x12a9>
  669e3b:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
  669e42:	00 
  669e43:	ff 15 e7 d4 11 00    	call   *0x11d4e7(%rip)        # 787330 <_DYNAMIC+0x628>
  669e49:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  669e4e:	41 01 c6             	add    %eax,%r14d
  669e51:	41 01 c5             	add    %eax,%r13d
  669e54:	0f 28 94 24 90 01 00 	movaps 0x190(%rsp),%xmm2
  669e5b:	00 
  669e5c:	0f 28 c2             	movaps %xmm2,%xmm0
  669e5f:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  669e64:	0f 28 c8             	movaps %xmm0,%xmm1
  669e67:	0f 55 ca             	andnps %xmm2,%xmm1
  669e6a:	0f 54 84 24 80 02 00 	andps  0x280(%rsp),%xmm0
  669e71:	00 
  669e72:	0f 56 c1             	orps   %xmm1,%xmm0
  669e75:	f3 0f 10 4c 24 34    	movss  0x34(%rsp),%xmm1
  669e7b:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  669e7f:	0f 28 a4 24 10 01 00 	movaps 0x110(%rsp),%xmm4
  669e86:	00 
  669e87:	0f 28 d4             	movaps %xmm4,%xmm2
  669e8a:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  669e8f:	0f 28 da             	movaps %xmm2,%xmm3
  669e92:	0f 55 dc             	andnps %xmm4,%xmm3
  669e95:	0f 54 94 24 c0 01 00 	andps  0x1c0(%rsp),%xmm2
  669e9c:	00 
  669e9d:	0f 56 d3             	orps   %xmm3,%xmm2
  669ea0:	f3 0f 5c d0          	subss  %xmm0,%xmm2
  669ea4:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  669eab:	00 
  669eac:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  669eb0:	44 89 34 c8          	mov    %r14d,(%rax,%rcx,8)
  669eb4:	44 89 6c c8 04       	mov    %r13d,0x4(%rax,%rcx,8)
  669eb9:	f3 0f 11 4c c8 08    	movss  %xmm1,0x8(%rax,%rcx,8)
  669ebf:	f3 0f 11 54 c8 0c    	movss  %xmm2,0xc(%rax,%rcx,8)
  669ec5:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  669ecb:	f3 0f 11 44 c8 10    	movss  %xmm0,0x10(%rax,%rcx,8)
  669ed1:	f3 0f 10 44 24 20    	movss  0x20(%rsp),%xmm0
  669ed7:	f3 0f 11 44 c8 14    	movss  %xmm0,0x14(%rax,%rcx,8)
  669edd:	48 ff c3             	inc    %rbx
  669ee0:	48 89 9c 24 68 01 00 	mov    %rbx,0x168(%rsp)
  669ee7:	00 
  669ee8:	44 89 ac 24 08 02 00 	mov    %r13d,0x208(%rsp)
  669eef:	00 
  669ef0:	8b 8c 24 90 00 00 00 	mov    0x90(%rsp),%ecx
  669ef7:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  669efe:	00 00 00 00 00 
  669f03:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  669f08:	48 89 84 24 08 07 00 	mov    %rax,0x708(%rsp)
  669f0f:	00 
  669f10:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  669f17:	00 
  669f18:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  669f1f:	00 
  669f20:	48 83 c0 70          	add    $0x70,%rax
  669f24:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  669f2b:	00 
  669f2c:	89 8c 24 18 07 00 00 	mov    %ecx,0x718(%rsp)
  669f33:	ff c1                	inc    %ecx
  669f35:	89 8c 24 90 00 00 00 	mov    %ecx,0x90(%rsp)
  669f3c:	c6 84 24 c0 07 00 00 	movb   $0x2,0x7c0(%rsp)
  669f43:	02 
  669f44:	c7 84 24 c8 07 00 00 	movl   $0x0,0x7c8(%rsp)
  669f4b:	00 00 00 00 
  669f4f:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
  669f56:	00 
  669f57:	48 8d b4 24 00 07 00 	lea    0x700(%rsp),%rsi
  669f5e:	00 
  669f5f:	e8 8c a2 00 00       	call   6741f0 <_RNvXs3_NtNtCshQYmODNYIQG_6parley6layout4lineINtB5_12GlyphRunIteruENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  669f64:	83 bc 24 90 02 00 00 	cmpl   $0x1,0x290(%rsp)
  669f6b:	01 
  669f6c:	0f 85 59 0f 00 00    	jne    66aecb <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x232b>
  669f72:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  669f79:	00 
  669f7a:	48 85 c0             	test   %rax,%rax
  669f7d:	0f 84 32 1c 00 00    	je     66bbb5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3015>
  669f83:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  669f8a:	00 
  669f8b:	41 0f 10 07          	movups (%r15),%xmm0
  669f8f:	41 0f 10 4f 10       	movups 0x10(%r15),%xmm1
  669f94:	41 0f 10 57 20       	movups 0x20(%r15),%xmm2
  669f99:	41 0f 10 5f 30       	movups 0x30(%r15),%xmm3
  669f9e:	48 8d 8c 24 a8 03 00 	lea    0x3a8(%rsp),%rcx
  669fa5:	00 
  669fa6:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  669faa:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  669fae:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  669fb2:	0f 11 01             	movups %xmm0,(%rcx)
  669fb5:	4c 8b 9c 24 a8 03 00 	mov    0x3a8(%rsp),%r11
  669fbc:	00 
  669fbd:	49 8b 4b 30          	mov    0x30(%r11),%rcx
  669fc1:	49 8b 73 38          	mov    0x38(%r11),%rsi
  669fc5:	48 89 f2             	mov    %rsi,%rdx
  669fc8:	48 29 ca             	sub    %rcx,%rdx
  669fcb:	40 0f 92 c7          	setb   %dil
  669fcf:	48 3b b0 d0 00 00 00 	cmp    0xd0(%rax),%rsi
  669fd6:	40 0f 97 c6          	seta   %sil
  669fda:	48 01 c9             	add    %rcx,%rcx
  669fdd:	48 03 88 c8 00 00 00 	add    0xc8(%rax),%rcx
  669fe4:	40 08 fe             	or     %dil,%sil
  669fe7:	40 84 f6             	test   %sil,%sil
  669fea:	be 00 00 00 00       	mov    $0x0,%esi
  669fef:	48 0f 45 d6          	cmovne %rsi,%rdx
  669ff3:	be 02 00 00 00       	mov    $0x2,%esi
  669ff8:	48 0f 45 ce          	cmovne %rsi,%rcx
  669ffc:	48 01 d2             	add    %rdx,%rdx
  669fff:	31 f6                	xor    %esi,%esi
  66a001:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66a008:	0f 1f 84 00 00 00 00 
  66a00f:	00 
  66a010:	48 39 f2             	cmp    %rsi,%rdx
  66a013:	74 10                	je     66a025 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1485>
  66a015:	66 83 3c 31 00       	cmpw   $0x0,(%rcx,%rsi,1)
  66a01a:	48 8d 76 02          	lea    0x2(%rsi),%rsi
  66a01e:	74 f0                	je     66a010 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1470>
  66a020:	e9 8c 17 00 00       	jmp    66b7b1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c11>
  66a025:	49 8b 4b 40          	mov    0x40(%r11),%rcx
  66a029:	48 3b 88 b8 00 00 00 	cmp    0xb8(%rax),%rcx
  66a030:	0f 83 4b 21 00 00    	jae    66c181 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35e1>
  66a036:	48 c1 e1 06          	shl    $0x6,%rcx
  66a03a:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  66a041:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  66a046:	83 3e 01             	cmpl   $0x1,(%rsi)
  66a049:	75 0f                	jne    66a05a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x14ba>
  66a04b:	48 8b 56 08          	mov    0x8(%rsi),%rdx
  66a04f:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66a053:	75 05                	jne    66a05a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x14ba>
  66a055:	45 31 c0             	xor    %r8d,%r8d
  66a058:	eb 4c                	jmp    66a0a6 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1506>
  66a05a:	83 7e 10 01          	cmpl   $0x1,0x10(%rsi)
  66a05e:	75 10                	jne    66a070 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x14d0>
  66a060:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  66a064:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  66a06a:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66a06e:	74 1e                	je     66a08e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x14ee>
  66a070:	83 7e 20 01          	cmpl   $0x1,0x20(%rsi)
  66a074:	0f 85 69 1b 00 00    	jne    66bbe3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3043>
  66a07a:	48 8b 56 28          	mov    0x28(%rsi),%rdx
  66a07e:	41 b8 02 00 00 00    	mov    $0x2,%r8d
  66a084:	48 3b 51 10          	cmp    0x10(%rcx),%rdx
  66a088:	0f 85 55 1b 00 00    	jne    66bbe3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3043>
  66a08e:	41 8d 48 ff          	lea    -0x1(%r8),%ecx
  66a092:	48 8b 94 24 f8 01 00 	mov    0x1f8(%rsp),%rdx
  66a099:	00 
  66a09a:	48 0f ab ca          	bts    %rcx,%rdx
  66a09e:	48 89 94 24 f8 01 00 	mov    %rdx,0x1f8(%rsp)
  66a0a5:	00 
  66a0a6:	8b bc 24 c8 03 00 00 	mov    0x3c8(%rsp),%edi
  66a0ad:	48 8b 70 58          	mov    0x58(%rax),%rsi
  66a0b1:	48 39 fe             	cmp    %rdi,%rsi
  66a0b4:	0f 86 82 21 00 00    	jbe    66c23c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x369c>
  66a0ba:	48 8b 94 24 b8 03 00 	mov    0x3b8(%rsp),%rdx
  66a0c1:	00 
  66a0c2:	48 85 d2             	test   %rdx,%rdx
  66a0c5:	4c 89 84 24 48 02 00 	mov    %r8,0x248(%rsp)
  66a0cc:	00 
  66a0cd:	48 89 94 24 30 03 00 	mov    %rdx,0x330(%rsp)
  66a0d4:	00 
  66a0d5:	74 0a                	je     66a0e1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1541>
  66a0d7:	48 8d 4a 18          	lea    0x18(%rdx),%rcx
  66a0db:	48 83 c2 1c          	add    $0x1c,%rdx
  66a0df:	eb 1b                	jmp    66a0fc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x155c>
  66a0e1:	48 8b 48 50          	mov    0x50(%rax),%rcx
  66a0e5:	48 8d 34 ff          	lea    (%rdi,%rdi,8),%rsi
  66a0e9:	48 c1 e6 04          	shl    $0x4,%rsi
  66a0ed:	48 8d 14 31          	lea    (%rcx,%rsi,1),%rdx
  66a0f1:	48 83 c2 54          	add    $0x54,%rdx
  66a0f5:	48 01 f1             	add    %rsi,%rcx
  66a0f8:	48 83 c1 50          	add    $0x50,%rcx
  66a0fc:	48 8b b4 24 08 01 00 	mov    0x108(%rsp),%rsi
  66a103:	00 
  66a104:	48 89 b4 24 38 03 00 	mov    %rsi,0x338(%rsp)
  66a10b:	00 
  66a10c:	48 8b 70 68          	mov    0x68(%rax),%rsi
  66a110:	48 8b 78 70          	mov    0x70(%rax),%rdi
  66a114:	4c 8b 80 80 00 00 00 	mov    0x80(%rax),%r8
  66a11b:	4c 8b 88 88 00 00 00 	mov    0x88(%rax),%r9
  66a122:	4c 8b 90 98 00 00 00 	mov    0x98(%rax),%r10
  66a129:	48 8b 80 a0 00 00 00 	mov    0xa0(%rax),%rax
  66a130:	8b 12                	mov    (%rdx),%edx
  66a132:	8b 09                	mov    (%rcx),%ecx
  66a134:	4c 89 9c 24 30 02 00 	mov    %r11,0x230(%rsp)
  66a13b:	00 
  66a13c:	45 0f b6 9b 8c 00 00 	movzbl 0x8c(%r11),%r11d
  66a143:	00 
  66a144:	41 80 e3 01          	and    $0x1,%r11b
  66a148:	89 d3                	mov    %edx,%ebx
  66a14a:	29 cb                	sub    %ecx,%ebx
  66a14c:	48 c7 84 24 b0 04 00 	movq   $0x0,0x4b0(%rsp)
  66a153:	00 00 00 00 00 
  66a158:	48 c7 84 24 d0 04 00 	movq   $0x0,0x4d0(%rsp)
  66a15f:	00 00 00 00 00 
  66a164:	c7 84 24 f0 04 00 00 	movl   $0x0,0x4f0(%rsp)
  66a16b:	00 00 00 00 
  66a16f:	89 9c 24 f4 04 00 00 	mov    %ebx,0x4f4(%rsp)
  66a176:	48 89 b4 24 f8 04 00 	mov    %rsi,0x4f8(%rsp)
  66a17d:	00 
  66a17e:	48 89 bc 24 00 05 00 	mov    %rdi,0x500(%rsp)
  66a185:	00 
  66a186:	4c 89 84 24 08 05 00 	mov    %r8,0x508(%rsp)
  66a18d:	00 
  66a18e:	4c 89 8c 24 10 05 00 	mov    %r9,0x510(%rsp)
  66a195:	00 
  66a196:	4c 89 94 24 18 05 00 	mov    %r10,0x518(%rsp)
  66a19d:	00 
  66a19e:	48 89 84 24 20 05 00 	mov    %rax,0x520(%rsp)
  66a1a5:	00 
  66a1a6:	89 8c 24 28 05 00 00 	mov    %ecx,0x528(%rsp)
  66a1ad:	89 94 24 2c 05 00 00 	mov    %edx,0x52c(%rsp)
  66a1b4:	89 8c 24 30 05 00 00 	mov    %ecx,0x530(%rsp)
  66a1bb:	89 94 24 34 05 00 00 	mov    %edx,0x534(%rsp)
  66a1c2:	44 88 9c 24 38 05 00 	mov    %r11b,0x538(%rsp)
  66a1c9:	00 
  66a1ca:	f2 0f 10 84 24 d8 03 	movsd  0x3d8(%rsp),%xmm0
  66a1d1:	00 00 
  66a1d3:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
  66a1da:	00 
  66a1db:	8b 94 24 d0 03 00 00 	mov    0x3d0(%rsp),%edx
  66a1e2:	8b 8c 24 d4 03 00 00 	mov    0x3d4(%rsp),%ecx
  66a1e9:	48 8d bc 24 e8 03 00 	lea    0x3e8(%rsp),%rdi
  66a1f0:	00 
  66a1f1:	48 8d b4 24 a0 03 00 	lea    0x3a0(%rsp),%rsi
  66a1f8:	00 
  66a1f9:	e8 02 8c 01 00       	call   682e00 <_RNvMs0_NtNtCshQYmODNYIQG_6parley6layout3runINtB5_3RunuE9glyphs_inCs6tOD1aKRtN9_11gpui_canvas>
  66a1fe:	0f 28 94 24 90 03 00 	movaps 0x390(%rsp),%xmm2
  66a205:	00 
  66a206:	0f 13 94 24 80 04 00 	movlps %xmm2,0x480(%rsp)
  66a20d:	00 
  66a20e:	4c 8b ac 24 e8 03 00 	mov    0x3e8(%rsp),%r13
  66a215:	00 
  66a216:	48 8b 84 24 f0 03 00 	mov    0x3f0(%rsp),%rax
  66a21d:	00 
  66a21e:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  66a225:	00 
  66a226:	0f b6 84 24 f8 03 00 	movzbl 0x3f8(%rsp),%eax
  66a22d:	00 
  66a22e:	8b 8c 24 fc 03 00 00 	mov    0x3fc(%rsp),%ecx
  66a235:	89 8c 24 ac 01 00 00 	mov    %ecx,0x1ac(%rsp)
  66a23c:	f2 0f 10 84 24 00 04 	movsd  0x400(%rsp),%xmm0
  66a243:	00 00 
  66a245:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
  66a24c:	00 
  66a24d:	f3 0f 10 84 24 08 04 	movss  0x408(%rsp),%xmm0
  66a254:	00 00 
  66a256:	f3 0f 11 84 24 a8 01 	movss  %xmm0,0x1a8(%rsp)
  66a25d:	00 00 
  66a25f:	48 8b 8c 24 10 04 00 	mov    0x410(%rsp),%rcx
  66a266:	00 
  66a267:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  66a26e:	00 
  66a26f:	48 8b 8c 24 18 04 00 	mov    0x418(%rsp),%rcx
  66a276:	00 
  66a277:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  66a27e:	00 
  66a27f:	48 8b 94 24 20 04 00 	mov    0x420(%rsp),%rdx
  66a286:	00 
  66a287:	48 8b 9c 24 28 04 00 	mov    0x428(%rsp),%rbx
  66a28e:	00 
  66a28f:	48 8b 8c 24 30 04 00 	mov    0x430(%rsp),%rcx
  66a296:	00 
  66a297:	48 89 8c 24 60 02 00 	mov    %rcx,0x260(%rsp)
  66a29e:	00 
  66a29f:	48 8b 8c 24 38 04 00 	mov    0x438(%rsp),%rcx
  66a2a6:	00 
  66a2a7:	48 89 8c 24 30 01 00 	mov    %rcx,0x130(%rsp)
  66a2ae:	00 
  66a2af:	8b 8c 24 40 04 00 00 	mov    0x440(%rsp),%ecx
  66a2b6:	48 89 8c 24 e0 01 00 	mov    %rcx,0x1e0(%rsp)
  66a2bd:	00 
  66a2be:	8b 8c 24 44 04 00 00 	mov    0x444(%rsp),%ecx
  66a2c5:	48 89 8c 24 e8 01 00 	mov    %rcx,0x1e8(%rsp)
  66a2cc:	00 
  66a2cd:	8b 8c 24 48 04 00 00 	mov    0x448(%rsp),%ecx
  66a2d4:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
  66a2db:	00 
  66a2dc:	44 8b b4 24 4c 04 00 	mov    0x44c(%rsp),%r14d
  66a2e3:	00 
  66a2e4:	f3 0f 10 84 24 50 04 	movss  0x450(%rsp),%xmm0
  66a2eb:	00 00 
  66a2ed:	f3 0f 11 84 24 b0 01 	movss  %xmm0,0x1b0(%rsp)
  66a2f4:	00 00 
  66a2f6:	f3 0f 10 84 24 54 04 	movss  0x454(%rsp),%xmm0
  66a2fd:	00 00 
  66a2ff:	f3 0f 11 44 24 5c    	movss  %xmm0,0x5c(%rsp)
  66a305:	48 8b 8c 24 58 04 00 	mov    0x458(%rsp),%rcx
  66a30c:	00 
  66a30d:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  66a312:	f3 0f 10 84 24 70 04 	movss  0x470(%rsp),%xmm0
  66a319:	00 00 
  66a31b:	f3 0f 10 8c 24 6c 04 	movss  0x46c(%rsp),%xmm1
  66a322:	00 00 
  66a324:	f3 0f 11 84 24 18 02 	movss  %xmm0,0x218(%rsp)
  66a32b:	00 00 
  66a32d:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66a331:	f3 0f 10 84 24 74 04 	movss  0x474(%rsp),%xmm0
  66a338:	00 00 
  66a33a:	f3 0f 11 8c 24 14 02 	movss  %xmm1,0x214(%rsp)
  66a341:	00 00 
  66a343:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  66a347:	f3 0f 11 84 24 0c 02 	movss  %xmm0,0x20c(%rsp)
  66a34e:	00 00 
  66a350:	0f 28 c2             	movaps %xmm2,%xmm0
  66a353:	0f b6 8c 24 7c 04 00 	movzbl 0x47c(%rsp),%ecx
  66a35a:	00 
  66a35b:	88 8c 24 80 02 00 00 	mov    %cl,0x280(%rsp)
  66a362:	48 8b 8c 24 60 04 00 	mov    0x460(%rsp),%rcx
  66a369:	00 
  66a36a:	48 89 8c 24 28 01 00 	mov    %rcx,0x128(%rsp)
  66a371:	00 
  66a372:	8b 8c 24 68 04 00 00 	mov    0x468(%rsp),%ecx
  66a379:	89 8c 24 f0 00 00 00 	mov    %ecx,0xf0(%rsp)
  66a380:	8b 8c 24 78 04 00 00 	mov    0x478(%rsp),%ecx
  66a387:	89 8c 24 10 02 00 00 	mov    %ecx,0x210(%rsp)
  66a38e:	48 8d 4a 16          	lea    0x16(%rdx),%rcx
  66a392:	48 89 8c 24 38 02 00 	mov    %rcx,0x238(%rsp)
  66a399:	00 
  66a39a:	48 89 94 24 c0 01 00 	mov    %rdx,0x1c0(%rsp)
  66a3a1:	00 
  66a3a2:	48 8d 4a 2e          	lea    0x2e(%rdx),%rcx
  66a3a6:	48 89 8c 24 48 03 00 	mov    %rcx,0x348(%rsp)
  66a3ad:	00 
  66a3ae:	48 89 9c 24 d8 01 00 	mov    %rbx,0x1d8(%rsp)
  66a3b5:	00 
  66a3b6:	eb 6e                	jmp    66a426 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1886>
  66a3b8:	03 6c 24 10          	add    0x10(%rsp),%ebp
  66a3bc:	0f 28 8c 24 90 01 00 	movaps 0x190(%rsp),%xmm1
  66a3c3:	00 
  66a3c4:	f3 0f 58 4c 24 34    	addss  0x34(%rsp),%xmm1
  66a3ca:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  66a3d1:	00 
  66a3d2:	48 89 d9             	mov    %rbx,%rcx
  66a3d5:	48 c1 e1 04          	shl    $0x4,%rcx
  66a3d9:	89 2c 08             	mov    %ebp,(%rax,%rcx,1)
  66a3dc:	f3 0f 10 44 24 30    	movss  0x30(%rsp),%xmm0
  66a3e2:	f3 0f 11 44 08 04    	movss  %xmm0,0x4(%rax,%rcx,1)
  66a3e8:	f3 0f 11 4c 08 08    	movss  %xmm1,0x8(%rax,%rcx,1)
  66a3ee:	8b 54 24 60          	mov    0x60(%rsp),%edx
  66a3f2:	66 89 54 08 0c       	mov    %dx,0xc(%rax,%rcx,1)
  66a3f7:	48 8b 94 24 48 02 00 	mov    0x248(%rsp),%rdx
  66a3fe:	00 
  66a3ff:	88 54 08 0e          	mov    %dl,0xe(%rax,%rcx,1)
  66a403:	c6 44 08 0f 00       	movb   $0x0,0xf(%rax,%rcx,1)
  66a408:	48 ff c3             	inc    %rbx
  66a40b:	48 89 9c 24 08 01 00 	mov    %rbx,0x108(%rsp)
  66a412:	00 
  66a413:	31 c0                	xor    %eax,%eax
  66a415:	48 8b 9c 24 d8 01 00 	mov    0x1d8(%rsp),%rbx
  66a41c:	00 
  66a41d:	f3 0f 10 84 24 b4 01 	movss  0x1b4(%rsp),%xmm0
  66a424:	00 00 
  66a426:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  66a42c:	a8 01                	test   $0x1,%al
  66a42e:	74 60                	je     66a490 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x18f0>
  66a430:	f3 0f 10 84 24 a8 01 	movss  0x1a8(%rsp),%xmm0
  66a437:	00 00 
  66a439:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66a43f:	8b 84 24 ac 01 00 00 	mov    0x1ac(%rsp),%eax
  66a446:	89 44 24 60          	mov    %eax,0x60(%rsp)
  66a44a:	0f 28 84 24 20 02 00 	movaps 0x220(%rsp),%xmm0
  66a451:	00 
  66a452:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  66a459:	00 
  66a45a:	83 bc 24 f0 00 00 00 	cmpl   $0x0,0xf0(%rsp)
  66a461:	00 
  66a462:	74 74                	je     66a4d8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1938>
  66a464:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  66a46a:	74 7f                	je     66a4eb <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x194b>
  66a46c:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  66a473:	00 
  66a474:	f3 0f 11 84 24 ec 00 	movss  %xmm0,0xec(%rsp)
  66a47b:	00 00 
  66a47d:	e9 97 00 00 00       	jmp    66a519 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1979>
  66a482:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  66a489:	1f 84 00 00 00 00 00 
  66a490:	4c 3b ac 24 a0 00 00 	cmp    0xa0(%rsp),%r13
  66a497:	00 
  66a498:	0f 84 3e 01 00 00    	je     66a5dc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1a3c>
  66a49e:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66a4a3:	41 8b 45 00          	mov    0x0(%r13),%eax
  66a4a7:	89 44 24 60          	mov    %eax,0x60(%rsp)
  66a4ab:	f2 41 0f 10 45 04    	movsd  0x4(%r13),%xmm0
  66a4b1:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  66a4b8:	00 
  66a4b9:	f3 41 0f 10 45 0c    	movss  0xc(%r13),%xmm0
  66a4bf:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66a4c5:	49 83 c5 10          	add    $0x10,%r13
  66a4c9:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  66a4ce:	83 bc 24 f0 00 00 00 	cmpl   $0x0,0xf0(%rsp)
  66a4d5:	00 
  66a4d6:	75 8c                	jne    66a464 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x18c4>
  66a4d8:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  66a4df:	00 
  66a4e0:	f3 0f 11 84 24 ec 00 	movss  %xmm0,0xec(%rsp)
  66a4e7:	00 00 
  66a4e9:	eb 5f                	jmp    66a54a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x19aa>
  66a4eb:	f3 0f 10 84 24 b0 01 	movss  0x1b0(%rsp),%xmm0
  66a4f2:	00 00 
  66a4f4:	0f 28 c8             	movaps %xmm0,%xmm1
  66a4f7:	f3 0f 58 8c 24 90 01 	addss  0x190(%rsp),%xmm1
  66a4fe:	00 00 
  66a500:	f3 0f 11 8c 24 ec 00 	movss  %xmm1,0xec(%rsp)
  66a507:	00 00 
  66a509:	f3 0f 10 4c 24 1c    	movss  0x1c(%rsp),%xmm1
  66a50f:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  66a513:	f3 0f 11 4c 24 1c    	movss  %xmm1,0x1c(%rsp)
  66a519:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66a51e:	48 ff c2             	inc    %rdx
  66a521:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  66a528:	00 
  66a529:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  66a52e:	48 39 c2             	cmp    %rax,%rdx
  66a531:	75 17                	jne    66a54a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x19aa>
  66a533:	f3 0f 10 44 24 1c    	movss  0x1c(%rsp),%xmm0
  66a539:	f3 0f 58 44 24 5c    	addss  0x5c(%rsp),%xmm0
  66a53f:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66a545:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  66a54a:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  66a551:	00 
  66a552:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  66a559:	00 
  66a55a:	e8 41 27 00 00       	call   66cca0 <_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flattenINtB5_13FlattenCompatINtNtB7_3map3MapINtNtNtBb_3ops5range5RangemENCNvMs0_NtNtCshQYmODNYIQG_6parley6layout3runINtB21_3RunuE19glyph_source_ranges0EINtNtNtB9_7sources8repeat_n7RepeatNIB1s_jEEENtNtNtB9_6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  66a55f:	83 bc 24 b0 00 00 00 	cmpl   $0x1,0xb0(%rsp)
  66a566:	01 
  66a567:	0f 85 37 16 00 00    	jne    66bba4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3004>
  66a56d:	f3 0f 10 44 24 30    	movss  0x30(%rsp),%xmm0
  66a573:	f3 0f 58 44 24 1c    	addss  0x1c(%rsp),%xmm0
  66a579:	31 c0                	xor    %eax,%eax
  66a57b:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  66a582:	00 
  66a583:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  66a588:	0f 84 98 fe ff ff    	je     66a426 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1886>
  66a58e:	f3 0f 11 84 24 b4 01 	movss  %xmm0,0x1b4(%rsp)
  66a595:	00 00 
  66a597:	4c 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%r9
  66a59e:	00 
  66a59f:	48 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%rbp
  66a5a6:	00 
  66a5a7:	49 39 e9             	cmp    %rbp,%r9
  66a5aa:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  66a5af:	0f 87 df 15 00 00    	ja     66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66a5b5:	4d 85 c9             	test   %r9,%r9
  66a5b8:	0f 84 f6 04 00 00    	je     66aab4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1f14>
  66a5be:	49 39 c9             	cmp    %rcx,%r9
  66a5c1:	0f 83 e7 04 00 00    	jae    66aaae <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1f0e>
  66a5c7:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  66a5cc:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  66a5d1:	0f 8f dd 04 00 00    	jg     66aab4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1f14>
  66a5d7:	e9 b8 15 00 00       	jmp    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66a5dc:	4c 89 ac 24 a0 00 00 	mov    %r13,0xa0(%rsp)
  66a5e3:	00 
  66a5e4:	f6 84 24 80 02 00 00 	testb  $0x1,0x280(%rsp)
  66a5eb:	01 
  66a5ec:	74 19                	je     66a607 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1a67>
  66a5ee:	4c 89 f2             	mov    %r14,%rdx
  66a5f1:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66a5f8:	00 
  66a5f9:	39 d1                	cmp    %edx,%ecx
  66a5fb:	0f 83 3d 01 00 00    	jae    66a73e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1b9e>
  66a601:	ff ca                	dec    %edx
  66a603:	89 d0                	mov    %edx,%eax
  66a605:	eb 19                	jmp    66a620 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1a80>
  66a607:	4c 89 f2             	mov    %r14,%rdx
  66a60a:	48 8b ac 24 10 01 00 	mov    0x110(%rsp),%rbp
  66a611:	00 
  66a612:	39 d5                	cmp    %edx,%ebp
  66a614:	0f 83 3f 01 00 00    	jae    66a759 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1bb9>
  66a61a:	8d 4d 01             	lea    0x1(%rbp),%ecx
  66a61d:	48 89 e8             	mov    %rbp,%rax
  66a620:	89 c7                	mov    %eax,%edi
  66a622:	48 39 fb             	cmp    %rdi,%rbx
  66a625:	0f 86 94 1b 00 00    	jbe    66c1bf <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x361f>
  66a62b:	49 89 d6             	mov    %rdx,%r14
  66a62e:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66a632:	48 8b 94 24 c0 01 00 	mov    0x1c0(%rsp),%rdx
  66a639:	00 
  66a63a:	44 8b 6c c2 08       	mov    0x8(%rdx,%rax,8),%r13d
  66a63f:	f6 44 c2 17 01       	testb  $0x1,0x17(%rdx,%rax,8)
  66a644:	0f 85 61 05 00 00    	jne    66abab <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x200b>
  66a64a:	48 8d 04 c2          	lea    (%rdx,%rax,8),%rax
  66a64e:	8b 50 0c             	mov    0xc(%rax),%edx
  66a651:	4a 8d 34 2a          	lea    (%rdx,%r13,1),%rsi
  66a655:	48 3b b4 24 30 01 00 	cmp    0x130(%rsp),%rsi
  66a65c:	00 
  66a65d:	0f 87 8e 17 00 00    	ja     66bdf1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3251>
  66a663:	49 c1 e5 04          	shl    $0x4,%r13
  66a667:	4c 03 ac 24 60 02 00 	add    0x260(%rsp),%r13
  66a66e:	00 
  66a66f:	48 89 d0             	mov    %rdx,%rax
  66a672:	48 c1 e0 04          	shl    $0x4,%rax
  66a676:	4c 01 e8             	add    %r13,%rax
  66a679:	0f 57 c0             	xorps  %xmm0,%xmm0
  66a67c:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
  66a683:	00 
  66a684:	48 85 d2             	test   %rdx,%rdx
  66a687:	0f 85 bd 06 00 00    	jne    66ad4a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x21aa>
  66a68d:	89 ca                	mov    %ecx,%edx
  66a68f:	48 89 94 24 10 01 00 	mov    %rdx,0x110(%rsp)
  66a696:	00 
  66a697:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66a69e:	00 00 
  66a6a0:	f6 84 24 80 02 00 00 	testb  $0x1,0x280(%rsp)
  66a6a7:	01 
  66a6a8:	74 16                	je     66a6c0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1b20>
  66a6aa:	44 39 f1             	cmp    %r14d,%ecx
  66a6ad:	0f 83 c5 00 00 00    	jae    66a778 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1bd8>
  66a6b3:	41 ff ce             	dec    %r14d
  66a6b6:	4c 89 f0             	mov    %r14,%rax
  66a6b9:	89 ca                	mov    %ecx,%edx
  66a6bb:	89 c1                	mov    %eax,%ecx
  66a6bd:	eb 19                	jmp    66a6d8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1b38>
  66a6bf:	90                   	nop
  66a6c0:	4c 89 f2             	mov    %r14,%rdx
  66a6c3:	39 d1                	cmp    %edx,%ecx
  66a6c5:	0f 83 5c 01 00 00    	jae    66a827 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1c87>
  66a6cb:	8d 41 01             	lea    0x1(%rcx),%eax
  66a6ce:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
  66a6d5:	00 
  66a6d6:	89 c2                	mov    %eax,%edx
  66a6d8:	89 cf                	mov    %ecx,%edi
  66a6da:	48 39 fb             	cmp    %rdi,%rbx
  66a6dd:	0f 86 dc 1a 00 00    	jbe    66c1bf <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x361f>
  66a6e3:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66a6e7:	48 8b 8c 24 c0 01 00 	mov    0x1c0(%rsp),%rcx
  66a6ee:	00 
  66a6ef:	44 8b 6c c1 08       	mov    0x8(%rcx,%rax,8),%r13d
  66a6f4:	f6 44 c1 17 01       	testb  $0x1,0x17(%rcx,%rax,8)
  66a6f9:	0f 85 a4 04 00 00    	jne    66aba3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2003>
  66a6ff:	48 8d 04 c1          	lea    (%rcx,%rax,8),%rax
  66a703:	8b 78 0c             	mov    0xc(%rax),%edi
  66a706:	4a 8d 34 2f          	lea    (%rdi,%r13,1),%rsi
  66a70a:	48 3b b4 24 30 01 00 	cmp    0x130(%rsp),%rsi
  66a711:	00 
  66a712:	0f 87 d9 16 00 00    	ja     66bdf1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3251>
  66a718:	49 c1 e5 04          	shl    $0x4,%r13
  66a71c:	4c 03 ac 24 60 02 00 	add    0x260(%rsp),%r13
  66a723:	00 
  66a724:	48 89 f8             	mov    %rdi,%rax
  66a727:	48 c1 e0 04          	shl    $0x4,%rax
  66a72b:	4c 01 e8             	add    %r13,%rax
  66a72e:	89 d1                	mov    %edx,%ecx
  66a730:	48 85 ff             	test   %rdi,%rdi
  66a733:	0f 84 67 ff ff ff    	je     66a6a0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1b00>
  66a739:	e9 e0 04 00 00       	jmp    66ac1e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x207e>
  66a73e:	4c 89 e8             	mov    %r13,%rax
  66a741:	3b 8c 24 e0 01 00 00 	cmp    0x1e0(%rsp),%ecx
  66a748:	0f 95 c2             	setne  %dl
  66a74b:	84 94 24 f0 00 00 00 	test   %dl,0xf0(%rsp)
  66a752:	75 4e                	jne    66a7a2 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1c02>
  66a754:	e9 0b 06 00 00       	jmp    66ad64 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x21c4>
  66a759:	4c 89 e8             	mov    %r13,%rax
  66a75c:	3b 94 24 e8 01 00 00 	cmp    0x1e8(%rsp),%edx
  66a763:	0f 95 c1             	setne  %cl
  66a766:	84 8c 24 f0 00 00 00 	test   %cl,0xf0(%rsp)
  66a76d:	0f 85 de 00 00 00    	jne    66a851 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1cb1>
  66a773:	e9 ec 05 00 00       	jmp    66ad64 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x21c4>
  66a778:	0f 57 c0             	xorps  %xmm0,%xmm0
  66a77b:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
  66a782:	00 
  66a783:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  66a78a:	00 
  66a78b:	3b 8c 24 e0 01 00 00 	cmp    0x1e0(%rsp),%ecx
  66a792:	0f 95 c2             	setne  %dl
  66a795:	84 94 24 f0 00 00 00 	test   %dl,0xf0(%rsp)
  66a79c:	0f 84 c2 05 00 00    	je     66ad64 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x21c4>
  66a7a2:	8d 79 ff             	lea    -0x1(%rcx),%edi
  66a7a5:	48 39 fb             	cmp    %rdi,%rbx
  66a7a8:	0f 86 b2 1a 00 00    	jbe    66c260 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36c0>
  66a7ae:	3b bc 24 e0 01 00 00 	cmp    0x1e0(%rsp),%edi
  66a7b5:	76 47                	jbe    66a7fe <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1c5e>
  66a7b7:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  66a7bb:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
  66a7c2:	00 
  66a7c3:	48 8d 14 d6          	lea    (%rsi,%rdx,8),%rdx
  66a7c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  66a7ce:	00 00 
  66a7d0:	48 39 fb             	cmp    %rdi,%rbx
  66a7d3:	0f 86 07 1a 00 00    	jbe    66c1e0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3640>
  66a7d9:	f6 42 01 02          	testb  $0x2,0x1(%rdx)
  66a7dd:	75 1f                	jne    66a7fe <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1c5e>
  66a7df:	48 ff cf             	dec    %rdi
  66a7e2:	48 83 c2 e8          	add    $0xffffffffffffffe8,%rdx
  66a7e6:	39 bc 24 e0 01 00 00 	cmp    %edi,0x1e0(%rsp)
  66a7ed:	72 e1                	jb     66a7d0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1c30>
  66a7ef:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
  66a7f6:	00 
  66a7f7:	48 89 d7             	mov    %rdx,%rdi
  66a7fa:	89 d5                	mov    %edx,%ebp
  66a7fc:	eb 02                	jmp    66a800 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1c60>
  66a7fe:	89 fd                	mov    %edi,%ebp
  66a800:	48 39 fb             	cmp    %rdi,%rbx
  66a803:	0f 86 63 1a 00 00    	jbe    66c26c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36cc>
  66a809:	48 89 ac 24 10 01 00 	mov    %rbp,0x110(%rsp)
  66a810:	00 
  66a811:	89 ca                	mov    %ecx,%edx
  66a813:	48 ff ca             	dec    %rdx
  66a816:	48 39 da             	cmp    %rbx,%rdx
  66a819:	0f 83 59 1a 00 00    	jae    66c278 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36d8>
  66a81f:	41 89 ce             	mov    %ecx,%r14d
  66a822:	e9 a8 00 00 00       	jmp    66a8cf <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1d2f>
  66a827:	0f 57 c0             	xorps  %xmm0,%xmm0
  66a82a:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
  66a831:	00 
  66a832:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  66a839:	00 
  66a83a:	3b 94 24 e8 01 00 00 	cmp    0x1e8(%rsp),%edx
  66a841:	0f 95 c1             	setne  %cl
  66a844:	84 8c 24 f0 00 00 00 	test   %cl,0xf0(%rsp)
  66a84b:	0f 84 13 05 00 00    	je     66ad64 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x21c4>
  66a851:	49 89 d0             	mov    %rdx,%r8
  66a854:	48 89 d1             	mov    %rdx,%rcx
  66a857:	89 cf                	mov    %ecx,%edi
  66a859:	48 39 fb             	cmp    %rdi,%rbx
  66a85c:	0f 86 e9 19 00 00    	jbe    66c24b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36ab>
  66a862:	44 8d 71 01          	lea    0x1(%rcx),%r14d
  66a866:	44 3b b4 24 e8 01 00 	cmp    0x1e8(%rsp),%r14d
  66a86d:	00 
  66a86e:	73 48                	jae    66a8b8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1d18>
  66a870:	44 89 f2             	mov    %r14d,%edx
  66a873:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  66a877:	48 8b b4 24 38 02 00 	mov    0x238(%rsp),%rsi
  66a87e:	00 
  66a87f:	48 8d 34 ce          	lea    (%rsi,%rcx,8),%rsi
  66a883:	49 89 d6             	mov    %rdx,%r14
  66a886:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66a88d:	00 00 00 
  66a890:	4c 39 f3             	cmp    %r14,%rbx
  66a893:	0f 86 2f 19 00 00    	jbe    66c1c8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3628>
  66a899:	f6 46 01 02          	testb  $0x2,0x1(%rsi)
  66a89d:	75 19                	jne    66a8b8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1d18>
  66a89f:	49 ff c6             	inc    %r14
  66a8a2:	48 83 c6 18          	add    $0x18,%rsi
  66a8a6:	4c 39 b4 24 e8 01 00 	cmp    %r14,0x1e8(%rsp)
  66a8ad:	00 
  66a8ae:	75 e0                	jne    66a890 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1cf0>
  66a8b0:	4c 8b b4 24 e8 01 00 	mov    0x1e8(%rsp),%r14
  66a8b7:	00 
  66a8b8:	44 89 f2             	mov    %r14d,%edx
  66a8bb:	48 ff ca             	dec    %rdx
  66a8be:	48 39 da             	cmp    %rbx,%rdx
  66a8c1:	0f 83 8d 19 00 00    	jae    66c254 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36b4>
  66a8c7:	4c 89 84 24 10 01 00 	mov    %r8,0x110(%rsp)
  66a8ce:	00 
  66a8cf:	48 83 bc 24 50 02 00 	cmpq   $0x0,0x250(%rsp)
  66a8d6:	00 00 
  66a8d8:	0f 84 86 04 00 00    	je     66ad64 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x21c4>
  66a8de:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  66a8e2:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
  66a8e9:	00 
  66a8ea:	8b 0c ce             	mov    (%rsi,%rcx,8),%ecx
  66a8ed:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  66a8f1:	8b 74 d6 04          	mov    0x4(%rsi,%rdx,8),%esi
  66a8f5:	39 ce                	cmp    %ecx,%esi
  66a8f7:	0f 82 2a 18 00 00    	jb     66c127 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3587>
  66a8fd:	48 39 b4 24 f0 01 00 	cmp    %rsi,0x1f0(%rsp)
  66a904:	00 
  66a905:	0f 82 1c 18 00 00    	jb     66c127 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3587>
  66a90b:	39 ce                	cmp    %ecx,%esi
  66a90d:	0f 84 19 19 00 00    	je     66c22c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x368c>
  66a913:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  66a917:	48 8b 94 24 50 02 00 	mov    0x250(%rsp),%rdx
  66a91e:	00 
  66a91f:	0f b6 4c 8a 07       	movzbl 0x7(%rdx,%rcx,4),%ecx
  66a924:	8d 51 ff             	lea    -0x1(%rcx),%edx
  66a927:	83 fa 02             	cmp    $0x2,%edx
  66a92a:	73 26                	jae    66a952 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1db2>
  66a92c:	f3 0f 10 84 24 14 02 	movss  0x214(%rsp),%xmm0
  66a933:	00 00 
  66a935:	f3 0f 11 44 24 5c    	movss  %xmm0,0x5c(%rsp)
  66a93b:	4c 89 f2             	mov    %r14,%rdx
  66a93e:	3b 94 24 10 02 00 00 	cmp    0x210(%rsp),%edx
  66a945:	77 2b                	ja     66a972 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1dd2>
  66a947:	f3 0f 10 84 24 0c 02 	movss  0x20c(%rsp),%xmm0
  66a94e:	00 00 
  66a950:	eb 1a                	jmp    66a96c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1dcc>
  66a952:	f3 0f 10 84 24 18 02 	movss  0x218(%rsp),%xmm0
  66a959:	00 00 
  66a95b:	f3 0f 11 44 24 5c    	movss  %xmm0,0x5c(%rsp)
  66a961:	83 f9 06             	cmp    $0x6,%ecx
  66a964:	4c 89 f2             	mov    %r14,%rdx
  66a967:	75 09                	jne    66a972 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1dd2>
  66a969:	0f 57 c0             	xorps  %xmm0,%xmm0
  66a96c:	f3 0f 11 44 24 5c    	movss  %xmm0,0x5c(%rsp)
  66a972:	89 d6                	mov    %edx,%esi
  66a974:	48 39 f3             	cmp    %rsi,%rbx
  66a977:	0f 92 c1             	setb   %cl
  66a97a:	3b 94 24 10 01 00 00 	cmp    0x110(%rsp),%edx
  66a981:	0f 82 0e 01 00 00    	jb     66aa95 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1ef5>
  66a987:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  66a98e:	00 
  66a98f:	89 fa                	mov    %edi,%edx
  66a991:	84 c9                	test   %cl,%cl
  66a993:	0f 85 ad 17 00 00    	jne    66c146 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35a6>
  66a999:	44 39 f7             	cmp    %r14d,%edi
  66a99c:	75 11                	jne    66a9af <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1e0f>
  66a99e:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
  66a9a5:	00 00 00 00 00 
  66a9aa:	e9 bd 00 00 00       	jmp    66aa6c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1ecc>
  66a9af:	48 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%rcx
  66a9b6:	00 
  66a9b7:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  66a9bb:	48 8d 7e ff          	lea    -0x1(%rsi),%rdi
  66a9bf:	48 39 d7             	cmp    %rdx,%rdi
  66a9c2:	75 10                	jne    66a9d4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1e34>
  66a9c4:	31 d2                	xor    %edx,%edx
  66a9c6:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
  66a9cd:	00 00 00 00 00 
  66a9d2:	eb 67                	jmp    66aa3b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1e9b>
  66a9d4:	48 29 d6             	sub    %rdx,%rsi
  66a9d7:	48 89 f7             	mov    %rsi,%rdi
  66a9da:	48 83 e7 fe          	and    $0xfffffffffffffffe,%rdi
  66a9de:	48 8b 94 24 48 03 00 	mov    0x348(%rsp),%rdx
  66a9e5:	00 
  66a9e6:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  66a9ea:	31 d2                	xor    %edx,%edx
  66a9ec:	45 31 d2             	xor    %r10d,%r10d
  66a9ef:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  66a9f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  66a9fc:	00 00 00 00 
  66aa00:	45 8b 48 de          	mov    -0x22(%r8),%r9d
  66aa04:	41 f6 40 e9 01       	testb  $0x1,-0x17(%r8)
  66aa09:	4d 0f 45 cb          	cmovne %r11,%r9
  66aa0d:	4d 01 d1             	add    %r10,%r9
  66aa10:	41 f6 40 01 01       	testb  $0x1,0x1(%r8)
  66aa15:	45 8b 50 f6          	mov    -0xa(%r8),%r10d
  66aa19:	4d 0f 45 d3          	cmovne %r11,%r10
  66aa1d:	4d 01 ca             	add    %r9,%r10
  66aa20:	48 83 c2 02          	add    $0x2,%rdx
  66aa24:	49 83 c0 30          	add    $0x30,%r8
  66aa28:	48 39 d7             	cmp    %rdx,%rdi
  66aa2b:	75 d3                	jne    66aa00 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1e60>
  66aa2d:	4c 89 94 24 28 01 00 	mov    %r10,0x128(%rsp)
  66aa34:	00 
  66aa35:	40 f6 c6 01          	test   $0x1,%sil
  66aa39:	74 31                	je     66aa6c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1ecc>
  66aa3b:	48 8b b4 24 28 01 00 	mov    0x128(%rsp),%rsi
  66aa42:	00 
  66aa43:	48 03 8c 24 c0 01 00 	add    0x1c0(%rsp),%rcx
  66aa4a:	00 
  66aa4b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  66aa4f:	f6 44 d1 17 01       	testb  $0x1,0x17(%rcx,%rdx,8)
  66aa54:	8b 54 d1 0c          	mov    0xc(%rcx,%rdx,8),%edx
  66aa58:	b9 01 00 00 00       	mov    $0x1,%ecx
  66aa5d:	48 0f 45 d1          	cmovne %rcx,%rdx
  66aa61:	48 01 f2             	add    %rsi,%rdx
  66aa64:	48 89 94 24 28 01 00 	mov    %rdx,0x128(%rsp)
  66aa6b:	00 
  66aa6c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66aa6f:	f3 0f 11 84 24 b0 01 	movss  %xmm0,0x1b0(%rsp)
  66aa76:	00 00 
  66aa78:	b9 00 00 00 00       	mov    $0x0,%ecx
  66aa7d:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  66aa82:	ba 00 00 00 00       	mov    $0x0,%edx
  66aa87:	49 39 c5             	cmp    %rax,%r13
  66aa8a:	0f 84 54 fb ff ff    	je     66a5e4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1a44>
  66aa90:	e9 0e fa ff ff       	jmp    66a4a3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1903>
  66aa95:	b1 01                	mov    $0x1,%cl
  66aa97:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
  66aa9e:	00 
  66aa9f:	89 fa                	mov    %edi,%edx
  66aaa1:	84 c9                	test   %cl,%cl
  66aaa3:	0f 84 f0 fe ff ff    	je     66a999 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1df9>
  66aaa9:	e9 98 16 00 00       	jmp    66c146 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x35a6>
  66aaae:	0f 85 e0 10 00 00    	jne    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66aab4:	48 85 ed             	test   %rbp,%rbp
  66aab7:	0f 94 c2             	sete   %dl
  66aaba:	74 1b                	je     66aad7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1f37>
  66aabc:	48 39 cd             	cmp    %rcx,%rbp
  66aabf:	73 10                	jae    66aad1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1f31>
  66aac1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  66aac6:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  66aaca:	7d 0b                	jge    66aad7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1f37>
  66aacc:	e9 c3 10 00 00       	jmp    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66aad1:	0f 85 bd 10 00 00    	jne    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66aad7:	83 7c 24 60 00       	cmpl   $0x0,0x60(%rsp)
  66aadc:	0f 84 9a 00 00 00    	je     66ab7c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1fdc>
  66aae2:	f3 0f 10 44 24 30    	movss  0x30(%rsp),%xmm0
  66aae8:	f3 0f 58 84 24 ec 00 	addss  0xec(%rsp),%xmm0
  66aaef:	00 00 
  66aaf1:	f3 0f 11 44 24 30    	movss  %xmm0,0x30(%rsp)
  66aaf7:	66 0f 7e c1          	movd   %xmm0,%ecx
  66aafb:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  66ab02:	00 
  66ab03:	0f 58 84 24 90 03 00 	addps  0x390(%rsp),%xmm0
  66ab0a:	00 
  66ab0b:	0f c6 c0 55          	shufps $0x55,%xmm0,%xmm0
  66ab0f:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  66ab16:	00 
  66ab17:	66 0f 7e c0          	movd   %xmm0,%eax
  66ab1b:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  66ab21:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
  66ab26:	3d 00 00 80 7f       	cmp    $0x7f800000,%eax
  66ab2b:	0f 9d c0             	setge  %al
  66ab2e:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
  66ab34:	0f 8f 7b 10 00 00    	jg     66bbb5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3015>
  66ab3a:	84 c0                	test   %al,%al
  66ab3c:	0f 85 73 10 00 00    	jne    66bbb5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3015>
  66ab42:	81 7c 24 60 ff ff 00 	cmpl   $0xffff,0x60(%rsp)
  66ab49:	00 
  66ab4a:	0f 87 44 10 00 00    	ja     66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66ab50:	4c 89 cd             	mov    %r9,%rbp
  66ab53:	48 8b 9c 24 08 01 00 	mov    0x108(%rsp),%rbx
  66ab5a:	00 
  66ab5b:	48 3b 9c 24 f8 00 00 	cmp    0xf8(%rsp),%rbx
  66ab62:	00 
  66ab63:	0f 85 4f f8 ff ff    	jne    66a3b8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1818>
  66ab69:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  66ab70:	00 
  66ab71:	ff 15 c1 c7 11 00    	call   *0x11c7c1(%rip)        # 787338 <_DYNAMIC+0x630>
  66ab77:	e9 3c f8 ff ff       	jmp    66a3b8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1818>
  66ab7c:	4d 85 c9             	test   %r9,%r9
  66ab7f:	0f 84 b1 00 00 00    	je     66ac36 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2096>
  66ab85:	49 39 c9             	cmp    %rcx,%r9
  66ab88:	0f 83 a2 00 00 00    	jae    66ac30 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2090>
  66ab8e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  66ab93:	42 80 3c 08 bf       	cmpb   $0xbf,(%rax,%r9,1)
  66ab98:	0f 8f 98 00 00 00    	jg     66ac36 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2096>
  66ab9e:	e9 ba 10 00 00       	jmp    66bc5d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30bd>
  66aba3:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
  66abaa:	00 
  66abab:	44 89 ea             	mov    %r13d,%edx
  66abae:	48 8d 04 7f          	lea    (%rdi,%rdi,2),%rax
  66abb2:	48 8b b4 24 c0 01 00 	mov    0x1c0(%rsp),%rsi
  66abb9:	00 
  66abba:	f3 0f 10 44 c6 10    	movss  0x10(%rsi,%rax,8),%xmm0
  66abc0:	0f 57 c9             	xorps  %xmm1,%xmm1
  66abc3:	0f 29 8c 24 90 01 00 	movaps %xmm1,0x190(%rsp)
  66abca:	00 
  66abcb:	41 bd 04 00 00 00    	mov    $0x4,%r13d
  66abd1:	b8 04 00 00 00       	mov    $0x4,%eax
  66abd6:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  66abdd:	00 
  66abde:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
  66abe5:	00 
  66abe6:	f3 0f 11 84 24 a8 01 	movss  %xmm0,0x1a8(%rsp)
  66abed:	00 00 
  66abef:	f3 0f 11 44 24 1c    	movss  %xmm0,0x1c(%rsp)
  66abf5:	89 94 24 ac 01 00 00 	mov    %edx,0x1ac(%rsp)
  66abfc:	89 54 24 60          	mov    %edx,0x60(%rsp)
  66ac00:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ac03:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
  66ac0a:	00 
  66ac0b:	83 bc 24 f0 00 00 00 	cmpl   $0x0,0xf0(%rsp)
  66ac12:	00 
  66ac13:	0f 85 4b f8 ff ff    	jne    66a464 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x18c4>
  66ac19:	e9 ba f8 ff ff       	jmp    66a4d8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1938>
  66ac1e:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66ac23:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  66ac2a:	00 
  66ac2b:	e9 73 f8 ff ff       	jmp    66a4a3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1903>
  66ac30:	0f 85 27 10 00 00    	jne    66bc5d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30bd>
  66ac36:	48 85 ed             	test   %rbp,%rbp
  66ac39:	4c 89 8c 24 40 03 00 	mov    %r9,0x340(%rsp)
  66ac40:	00 
  66ac41:	74 1b                	je     66ac5e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x20be>
  66ac43:	48 39 cd             	cmp    %rcx,%rbp
  66ac46:	73 10                	jae    66ac58 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x20b8>
  66ac48:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  66ac4d:	80 3c 28 c0          	cmpb   $0xc0,(%rax,%rbp,1)
  66ac51:	7d 0b                	jge    66ac5e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x20be>
  66ac53:	e9 11 10 00 00       	jmp    66bc69 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30c9>
  66ac58:	0f 85 0b 10 00 00    	jne    66bc69 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30c9>
  66ac5e:	89 54 24 30          	mov    %edx,0x30(%rsp)
  66ac62:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  66ac67:	4a 8d 1c 08          	lea    (%rax,%r9,1),%rbx
  66ac6b:	48 01 e8             	add    %rbp,%rax
  66ac6e:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  66ac75:	00 
  66ac76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66ac7d:	00 00 00 
  66ac80:	48 3b 9c 24 90 01 00 	cmp    0x190(%rsp),%rbx
  66ac87:	00 
  66ac88:	0f 84 8c 00 00 00    	je     66ad1a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x217a>
  66ac8e:	0f b6 33             	movzbl (%rbx),%esi
  66ac91:	40 84 f6             	test   %sil,%sil
  66ac94:	78 0a                	js     66aca0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2100>
  66ac96:	48 ff c3             	inc    %rbx
  66ac99:	eb 65                	jmp    66ad00 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2160>
  66ac9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  66aca0:	89 f0                	mov    %esi,%eax
  66aca2:	83 e0 1f             	and    $0x1f,%eax
  66aca5:	0f b6 53 01          	movzbl 0x1(%rbx),%edx
  66aca9:	83 e2 3f             	and    $0x3f,%edx
  66acac:	40 80 fe df          	cmp    $0xdf,%sil
  66acb0:	76 2c                	jbe    66acde <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x213e>
  66acb2:	0f b6 4b 02          	movzbl 0x2(%rbx),%ecx
  66acb6:	c1 e2 06             	shl    $0x6,%edx
  66acb9:	83 e1 3f             	and    $0x3f,%ecx
  66acbc:	09 d1                	or     %edx,%ecx
  66acbe:	40 80 fe f0          	cmp    $0xf0,%sil
  66acc2:	72 27                	jb     66aceb <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x214b>
  66acc4:	0f b6 73 03          	movzbl 0x3(%rbx),%esi
  66acc8:	48 83 c3 04          	add    $0x4,%rbx
  66accc:	83 e0 07             	and    $0x7,%eax
  66accf:	c1 e0 12             	shl    $0x12,%eax
  66acd2:	c1 e1 06             	shl    $0x6,%ecx
  66acd5:	83 e6 3f             	and    $0x3f,%esi
  66acd8:	09 ce                	or     %ecx,%esi
  66acda:	09 c6                	or     %eax,%esi
  66acdc:	eb 22                	jmp    66ad00 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2160>
  66acde:	48 83 c3 02          	add    $0x2,%rbx
  66ace2:	c1 e0 06             	shl    $0x6,%eax
  66ace5:	09 d0                	or     %edx,%eax
  66ace7:	89 c6                	mov    %eax,%esi
  66ace9:	eb 15                	jmp    66ad00 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2160>
  66aceb:	48 83 c3 03          	add    $0x3,%rbx
  66acef:	c1 e0 0c             	shl    $0xc,%eax
  66acf2:	09 c1                	or     %eax,%ecx
  66acf4:	89 ce                	mov    %ecx,%esi
  66acf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66acfd:	00 00 00 
  66ad00:	48 8d 3d a9 15 11 00 	lea    0x1115a9(%rip),%rdi        # 77c2b0 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x20>
  66ad07:	ff 15 13 c6 11 00    	call   *0x11c613(%rip)        # 787320 <_DYNAMIC+0x618>
  66ad0d:	84 c0                	test   %al,%al
  66ad0f:	0f 85 6b ff ff ff    	jne    66ac80 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x20e0>
  66ad15:	e9 57 0f 00 00       	jmp    66bc71 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30d1>
  66ad1a:	31 c0                	xor    %eax,%eax
  66ad1c:	0f 57 c0             	xorps  %xmm0,%xmm0
  66ad1f:	f3 0f 10 4c 24 1c    	movss  0x1c(%rsp),%xmm1
  66ad25:	0f 2e c8             	ucomiss %xmm0,%xmm1
  66ad28:	48 8b 9c 24 d8 01 00 	mov    0x1d8(%rsp),%rbx
  66ad2f:	00 
  66ad30:	f3 0f 10 84 24 b4 01 	movss  0x1b4(%rsp),%xmm0
  66ad37:	00 00 
  66ad39:	0f 85 32 0f 00 00    	jne    66bc71 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30d1>
  66ad3f:	0f 8b e1 f6 ff ff    	jnp    66a426 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1886>
  66ad45:	e9 27 0f 00 00       	jmp    66bc71 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30d1>
  66ad4a:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  66ad4f:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  66ad56:	00 
  66ad57:	48 89 8c 24 10 01 00 	mov    %rcx,0x110(%rsp)
  66ad5e:	00 
  66ad5f:	e9 3f f7 ff ff       	jmp    66a4a3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x1903>
  66ad64:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  66ad6b:	00 
  66ad6c:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  66ad73:	00 
  66ad74:	e8 27 1f 00 00       	call   66cca0 <_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flattenINtB5_13FlattenCompatINtNtB7_3map3MapINtNtNtBb_3ops5range5RangemENCNvMs0_NtNtCshQYmODNYIQG_6parley6layout3runINtB21_3RunuE19glyph_source_ranges0EINtNtNtB9_7sources8repeat_n7RepeatNIB1s_jEEENtNtNtB9_6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  66ad79:	48 83 bc 24 b0 00 00 	cmpq   $0x0,0xb0(%rsp)
  66ad80:	00 00 
  66ad82:	0f 85 0c 0e 00 00    	jne    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66ad88:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  66ad8f:	00 
  66ad90:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66ad94:	0f 84 b5 f1 ff ff    	je     669f4f <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x13af>
  66ad9a:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  66ada1:	00 
  66ada2:	48 3b 4c 24 10       	cmp    0x10(%rsp),%rcx
  66ada7:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  66adac:	75 0f                	jne    66adbd <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x221d>
  66adae:	31 db                	xor    %ebx,%ebx
  66adb0:	45 31 f6             	xor    %r14d,%r14d
  66adb3:	48 8b b4 24 30 02 00 	mov    0x230(%rsp),%rsi
  66adba:	00 
  66adbb:	eb 77                	jmp    66ae34 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2294>
  66adbd:	48 8b 94 24 30 03 00 	mov    0x330(%rsp),%rdx
  66adc4:	00 
  66adc5:	48 85 d2             	test   %rdx,%rdx
  66adc8:	48 8b b4 24 30 02 00 	mov    0x230(%rsp),%rsi
  66adcf:	00 
  66add0:	48 0f 44 d6          	cmove  %rsi,%rdx
  66add4:	48 8b 1a             	mov    (%rdx),%rbx
  66add7:	4c 8b 72 08          	mov    0x8(%rdx),%r14
  66addb:	4c 39 f3             	cmp    %r14,%rbx
  66adde:	0f 87 b0 0d 00 00    	ja     66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66ade4:	48 85 db             	test   %rbx,%rbx
  66ade7:	74 15                	je     66adfe <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x225e>
  66ade9:	48 39 cb             	cmp    %rcx,%rbx
  66adec:	73 14                	jae    66ae02 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2262>
  66adee:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  66adf3:	80 3c 1a bf          	cmpb   $0xbf,(%rdx,%rbx,1)
  66adf7:	7f 12                	jg     66ae0b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x226b>
  66adf9:	e9 96 0d 00 00       	jmp    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66adfe:	31 db                	xor    %ebx,%ebx
  66ae00:	eb 09                	jmp    66ae0b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x226b>
  66ae02:	48 89 cb             	mov    %rcx,%rbx
  66ae05:	0f 85 89 0d 00 00    	jne    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66ae0b:	4d 85 f6             	test   %r14,%r14
  66ae0e:	74 16                	je     66ae26 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2286>
  66ae10:	49 39 ce             	cmp    %rcx,%r14
  66ae13:	73 16                	jae    66ae2b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x228b>
  66ae15:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  66ae1a:	42 80 3c 31 c0       	cmpb   $0xc0,(%rcx,%r14,1)
  66ae1f:	7d 13                	jge    66ae34 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2294>
  66ae21:	e9 6e 0d 00 00       	jmp    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66ae26:	45 31 f6             	xor    %r14d,%r14d
  66ae29:	eb 09                	jmp    66ae34 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2294>
  66ae2b:	49 89 ce             	mov    %rcx,%r14
  66ae2e:	0f 85 60 0d 00 00    	jne    66bb94 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2ff4>
  66ae34:	8b 8c 24 08 01 00 00 	mov    0x108(%rsp),%ecx
  66ae3b:	89 4c 24 20          	mov    %ecx,0x20(%rsp)
  66ae3f:	0f b6 ae 8c 00 00 00 	movzbl 0x8c(%rsi),%ebp
  66ae46:	4c 8b ac 24 50 01 00 	mov    0x150(%rsp),%r13
  66ae4d:	00 
  66ae4e:	49 39 c5             	cmp    %rax,%r13
  66ae51:	75 0e                	jne    66ae61 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x22c1>
  66ae53:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
  66ae5a:	00 
  66ae5b:	ff 15 df c4 11 00    	call   *0x11c4df(%rip)        # 787340 <_DYNAMIC+0x638>
  66ae61:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66ae66:	01 c3                	add    %eax,%ebx
  66ae68:	41 01 c6             	add    %eax,%r14d
  66ae6b:	40 80 e5 01          	and    $0x1,%bpl
  66ae6f:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  66ae76:	00 
  66ae77:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
  66ae7e:	00 
  66ae7f:	4c 01 e9             	add    %r13,%rcx
  66ae82:	89 1c c8             	mov    %ebx,(%rax,%rcx,8)
  66ae85:	44 89 74 c8 04       	mov    %r14d,0x4(%rax,%rcx,8)
  66ae8a:	48 8b 94 24 38 03 00 	mov    0x338(%rsp),%rdx
  66ae91:	00 
  66ae92:	89 54 c8 08          	mov    %edx,0x8(%rax,%rcx,8)
  66ae96:	8b 54 24 20          	mov    0x20(%rsp),%edx
  66ae9a:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  66ae9e:	48 8b 94 24 40 02 00 	mov    0x240(%rsp),%rdx
  66aea5:	00 
  66aea6:	89 54 c8 10          	mov    %edx,0x10(%rax,%rcx,8)
  66aeaa:	48 8b 94 24 48 02 00 	mov    0x248(%rsp),%rdx
  66aeb1:	00 
  66aeb2:	88 54 c8 14          	mov    %dl,0x14(%rax,%rcx,8)
  66aeb6:	40 88 6c c8 15       	mov    %bpl,0x15(%rax,%rcx,8)
  66aebb:	49 ff c5             	inc    %r13
  66aebe:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
  66aec5:	00 
  66aec6:	e9 84 f0 ff ff       	jmp    669f4f <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x13af>
  66aecb:	48 8b 84 24 50 03 00 	mov    0x350(%rsp),%rax
  66aed2:	00 
  66aed3:	48 39 84 24 a8 00 00 	cmp    %rax,0xa8(%rsp)
  66aeda:	00 
  66aedb:	48 8b ac 24 80 00 00 	mov    0x80(%rsp),%rbp
  66aee2:	00 
  66aee3:	0f 85 f0 eb ff ff    	jne    669ad9 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xf39>
  66aee9:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66aef0:	00 ff 
  66aef2:	0f 84 e3 06 00 00    	je     66b5db <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2a3b>
  66aef8:	48 83 bc 24 70 01 00 	cmpq   $0xffffffffffffffff,0x170(%rsp)
  66aeff:	00 ff 
  66af01:	0f 84 d4 06 00 00    	je     66b5db <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2a3b>
  66af07:	48 03 ac 24 38 01 00 	add    0x138(%rsp),%rbp
  66af0e:	00 
  66af0f:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  66af16:	00 00 00 00 00 
  66af1b:	48 c7 84 24 08 07 00 	movq   $0x8,0x708(%rsp)
  66af22:	00 08 00 00 00 
  66af27:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66af2e:	00 00 00 00 00 
  66af33:	c7 84 24 20 07 00 00 	movl   $0xffffffff,0x720(%rsp)
  66af3a:	ff ff ff ff 
  66af3e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  66af43:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66af4a:	00 
  66af4b:	48 89 ac 24 30 07 00 	mov    %rbp,0x730(%rsp)
  66af52:	00 
  66af53:	48 c7 84 24 38 07 00 	movq   $0x0,0x738(%rsp)
  66af5a:	00 00 00 00 00 
  66af5f:	48 8d 05 ba 14 11 00 	lea    0x1114ba(%rip),%rax        # 77c420 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x190>
  66af66:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  66af6d:	00 
  66af6e:	48 8d 05 db b7 ff ff 	lea    -0x4825(%rip),%rax        # 666750 <_RINvNtCs27TG78Py0Qp_13icu_segmenter17rule_segmenter_v120empty_handle_complexNtNtB4_8scaffold4Utf8ECs6tOD1aKRtN9_11gpui_canvas>
  66af75:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  66af7c:	00 
  66af7d:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66af82:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66af89:	00 
  66af8a:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  66af91:	00 00 00 00 00 
  66af96:	48 c7 84 24 88 07 00 	movq   $0x0,0x788(%rsp)
  66af9d:	00 00 00 00 00 
  66afa2:	c6 84 24 90 07 00 00 	movb   $0x0,0x790(%rsp)
  66afa9:	00 
  66afaa:	31 db                	xor    %ebx,%ebx
  66afac:	0f 1f 40 00          	nopl   0x0(%rax)
  66afb0:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66afb7:	00 
  66afb8:	e8 83 e7 00 00       	call   679740 <_RNvXNtCs27TG78Py0Qp_13icu_segmenter17rule_segmenter_v1INtB2_17RuleBreakIteratorNtNtB4_8scaffold4Utf8ENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  66afbd:	48 83 f8 01          	cmp    $0x1,%rax
  66afc1:	75 05                	jne    66afc8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2428>
  66afc3:	48 ff c3             	inc    %rbx
  66afc6:	eb e8                	jmp    66afb0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2410>
  66afc8:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  66afcf:	00 
  66afd0:	48 85 f6             	test   %rsi,%rsi
  66afd3:	74 17                	je     66afec <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x244c>
  66afd5:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  66afdc:	00 
  66afdd:	48 c1 e6 03          	shl    $0x3,%rsi
  66afe1:	ba 08 00 00 00       	mov    $0x8,%edx
  66afe6:	ff 15 54 bf 11 00    	call   *0x11bf54(%rip)        # 786f40 <_DYNAMIC+0x238>
  66afec:	48 83 fb 08          	cmp    $0x8,%rbx
  66aff0:	0f 86 8f 00 00 00    	jbe    66b085 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x24e5>
  66aff6:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66affd:	00 
  66affe:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  66b003:	e8 c8 87 00 00       	call   6737d0 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE3newCs6tOD1aKRtN9_11gpui_canvas>
  66b008:	48 8b 94 24 00 07 00 	mov    0x700(%rsp),%rdx
  66b00f:	00 
  66b010:	48 83 fa ff          	cmp    $0xffffffffffffffff,%rdx
  66b014:	0f 84 aa 0d 00 00    	je     66bdc4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3224>
  66b01a:	48 8d 8c 24 20 07 00 	lea    0x720(%rsp),%rcx
  66b021:	00 
  66b022:	48 8b 41 10          	mov    0x10(%rcx),%rax
  66b026:	49 89 47 20          	mov    %rax,0x20(%r15)
  66b02a:	0f 10 41 f0          	movups -0x10(%rcx),%xmm0
  66b02e:	0f 10 09             	movups (%rcx),%xmm1
  66b031:	41 0f 11 4f 10       	movups %xmm1,0x10(%r15)
  66b036:	41 0f 11 07          	movups %xmm0,(%r15)
  66b03a:	48 8b 84 24 08 07 00 	mov    0x708(%rsp),%rax
  66b041:	00 
  66b042:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  66b047:	48 89 94 24 90 02 00 	mov    %rdx,0x290(%rsp)
  66b04e:	00 
  66b04f:	48 89 84 24 98 02 00 	mov    %rax,0x298(%rsp)
  66b056:	00 
  66b057:	eb 41                	jmp    66b09a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x24fa>
  66b059:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  66b05e:	4c 3b 8c 24 a0 01 00 	cmp    0x1a0(%rsp),%r9
  66b065:	00 
  66b066:	0f 84 5b 06 00 00    	je     66b6c7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2b27>
  66b06c:	45 0f b6 11          	movzbl (%r9),%r10d
  66b070:	49 89 f3             	mov    %rsi,%r11
  66b073:	45 84 d2             	test   %r10b,%r10b
  66b076:	0f 88 63 06 00 00    	js     66b6df <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2b3f>
  66b07c:	49 8d 49 01          	lea    0x1(%r9),%rcx
  66b080:	e9 b9 06 00 00       	jmp    66b73e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2b9e>
  66b085:	48 c7 84 24 90 02 00 	movq   $0xffffffffffffffff,0x290(%rsp)
  66b08c:	00 ff ff ff ff 
  66b091:	48 c7 44 24 20 ff ff 	movq   $0xffffffffffffffff,0x20(%rsp)
  66b098:	ff ff 
  66b09a:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  66b0a1:	00 00 00 00 00 
  66b0a6:	48 c7 84 24 08 07 00 	movq   $0x8,0x708(%rsp)
  66b0ad:	00 08 00 00 00 
  66b0b2:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66b0b9:	00 00 00 00 00 
  66b0be:	c7 84 24 20 07 00 00 	movl   $0xffffffff,0x720(%rsp)
  66b0c5:	ff ff ff ff 
  66b0c9:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  66b0ce:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66b0d5:	00 
  66b0d6:	48 89 ac 24 30 07 00 	mov    %rbp,0x730(%rsp)
  66b0dd:	00 
  66b0de:	48 c7 84 24 38 07 00 	movq   $0x0,0x738(%rsp)
  66b0e5:	00 00 00 00 00 
  66b0ea:	48 8d 05 2f 13 11 00 	lea    0x11132f(%rip),%rax        # 77c420 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x190>
  66b0f1:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  66b0f8:	00 
  66b0f9:	48 8d 05 50 b6 ff ff 	lea    -0x49b0(%rip),%rax        # 666750 <_RINvNtCs27TG78Py0Qp_13icu_segmenter17rule_segmenter_v120empty_handle_complexNtNtB4_8scaffold4Utf8ECs6tOD1aKRtN9_11gpui_canvas>
  66b100:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  66b107:	00 
  66b108:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66b10d:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66b114:	00 
  66b115:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  66b11c:	00 00 00 00 00 
  66b121:	48 c7 84 24 88 07 00 	movq   $0x0,0x788(%rsp)
  66b128:	00 00 00 00 00 
  66b12d:	c6 84 24 90 07 00 00 	movb   $0x0,0x790(%rsp)
  66b134:	00 
  66b135:	f3 0f 10 44 24 34    	movss  0x34(%rsp),%xmm0
  66b13b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
  66b13f:	f2 0f 11 44 24 28    	movsd  %xmm0,0x28(%rsp)
  66b145:	eb 3c                	jmp    66b183 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x25e3>
  66b147:	66 0f 28 44 24 70    	movapd 0x70(%rsp),%xmm0
  66b14d:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
  66b154:	00 00 
  66b156:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  66b15d:	00 
  66b15e:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
  66b162:	89 1c 88             	mov    %ebx,(%rax,%rcx,4)
  66b165:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  66b16c:	00 
  66b16d:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  66b173:	40 88 6c 88 08       	mov    %bpl,0x8(%rax,%rcx,4)
  66b178:	49 ff c6             	inc    %r14
  66b17b:	4c 89 b4 24 80 01 00 	mov    %r14,0x180(%rsp)
  66b182:	00 
  66b183:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66b18a:	00 
  66b18b:	e8 b0 e5 00 00       	call   679740 <_RNvXNtCs27TG78Py0Qp_13icu_segmenter17rule_segmenter_v1INtB2_17RuleBreakIteratorNtNtB4_8scaffold4Utf8ENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  66b190:	48 83 f8 01          	cmp    $0x1,%rax
  66b194:	0f 85 d2 03 00 00    	jne    66b56c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x29cc>
  66b19a:	48 89 d3             	mov    %rdx,%rbx
  66b19d:	48 89 94 24 88 03 00 	mov    %rdx,0x388(%rsp)
  66b1a4:	00 
  66b1a5:	48 83 7c 24 20 ff    	cmpq   $0xffffffffffffffff,0x20(%rsp)
  66b1ab:	74 63                	je     66b210 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2670>
  66b1ad:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  66b1b4:	00 
  66b1b5:	48 8d b4 24 90 02 00 	lea    0x290(%rsp),%rsi
  66b1bc:	00 
  66b1bd:	48 89 da             	mov    %rbx,%rdx
  66b1c0:	f3 0f 10 05 44 24 9b 	movss  -0x64dbbc(%rip),%xmm0        # 1d60c <GCC_except_table0+0x24>
  66b1c7:	ff 
  66b1c8:	e8 93 7c 00 00       	call   672e60 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas>
  66b1cd:	80 bc 24 b0 04 00 00 	cmpb   $0x0,0x4b0(%rsp)
  66b1d4:	00 
  66b1d5:	74 ac                	je     66b183 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x25e3>
  66b1d7:	66 0f 10 9c 24 b8 04 	movupd 0x4b8(%rsp),%xmm3
  66b1de:	00 00 
  66b1e0:	66 0f 10 a4 24 c8 04 	movupd 0x4c8(%rsp),%xmm4
  66b1e7:	00 00 
  66b1e9:	66 0f 10 84 24 d8 04 	movupd 0x4d8(%rsp),%xmm0
  66b1f0:	00 00 
  66b1f2:	66 0f 10 8c 24 e8 04 	movupd 0x4e8(%rsp),%xmm1
  66b1f9:	00 00 
  66b1fb:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  66b201:	e9 f1 00 00 00       	jmp    66b2f7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2757>
  66b206:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  66b20d:	00 00 00 
  66b210:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  66b215:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  66b21c:	00 
  66b21d:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  66b224:	00 
  66b225:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
  66b22c:	00 
  66b22d:	66 c7 44 24 66 01 00 	movw   $0x1,0x66(%rsp)
  66b234:	48 8d 44 24 66       	lea    0x66(%rsp),%rax
  66b239:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  66b240:	00 
  66b241:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
  66b246:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  66b24d:	00 
  66b24e:	48 8d 84 24 b0 00 00 	lea    0xb0(%rsp),%rax
  66b255:	00 
  66b256:	48 89 84 24 a8 03 00 	mov    %rax,0x3a8(%rsp)
  66b25d:	00 
  66b25e:	48 8d 84 24 a0 03 00 	lea    0x3a0(%rsp),%rax
  66b265:	00 
  66b266:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
  66b26d:	00 
  66b26e:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  66b275:	00 
  66b276:	48 8d b4 24 68 02 00 	lea    0x268(%rsp),%rsi
  66b27d:	00 
  66b27e:	31 d2                	xor    %edx,%edx
  66b280:	e8 cb b3 ff ff       	call   666650 <_RNvXs0_NtNtCs4NRVxsYgnAr_4core5array5drainQINtB5_5DrainNtNtNtCshQYmODNYIQG_6parley6layout7cluster8AffinityNCINvMNtNtB9_3ops9try_traitINtB1M_17NeverShortCircuitINtNtB9_6option6OptionNtNtBX_4util11BoundingBoxEE10wrap_mut_1BR_NCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner13append_carets0E0EINtNtB1O_8function5FnMutTjEE8call_mutB3H_>
  66b285:	4c 8b b4 24 b0 04 00 	mov    0x4b0(%rsp),%r14
  66b28c:	00 
  66b28d:	0f 10 84 24 b8 04 00 	movups 0x4b8(%rsp),%xmm0
  66b294:	00 
  66b295:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  66b29c:	00 
  66b29d:	0f 10 84 24 c8 04 00 	movups 0x4c8(%rsp),%xmm0
  66b2a4:	00 
  66b2a5:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  66b2aa:	ba 01 00 00 00       	mov    $0x1,%edx
  66b2af:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  66b2b6:	00 
  66b2b7:	48 8d b4 24 68 02 00 	lea    0x268(%rsp),%rsi
  66b2be:	00 
  66b2bf:	e8 8c b3 ff ff       	call   666650 <_RNvXs0_NtNtCs4NRVxsYgnAr_4core5array5drainQINtB5_5DrainNtNtNtCshQYmODNYIQG_6parley6layout7cluster8AffinityNCINvMNtNtB9_3ops9try_traitINtB1M_17NeverShortCircuitINtNtB9_6option6OptionNtNtBX_4util11BoundingBoxEE10wrap_mut_1BR_NCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner13append_carets0E0EINtNtB1O_8function5FnMutTjEE8call_mutB3H_>
  66b2c4:	4c 8b ac 24 b0 04 00 	mov    0x4b0(%rsp),%r13
  66b2cb:	00 
  66b2cc:	66 0f 10 84 24 b8 04 	movupd 0x4b8(%rsp),%xmm0
  66b2d3:	00 00 
  66b2d5:	66 0f 10 8c 24 c8 04 	movupd 0x4c8(%rsp),%xmm1
  66b2dc:	00 00 
  66b2de:	49 83 fe 01          	cmp    $0x1,%r14
  66b2e2:	0f 85 73 02 00 00    	jne    66b55b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x29bb>
  66b2e8:	66 0f 28 9c 24 80 00 	movapd 0x80(%rsp),%xmm3
  66b2ef:	00 00 
  66b2f1:	66 0f 28 64 24 70    	movapd 0x70(%rsp),%xmm4
  66b2f7:	66 0f 28 d3          	movapd %xmm3,%xmm2
  66b2fb:	66 0f 15 d3          	unpckhpd %xmm3,%xmm2
  66b2ff:	f2 0f 58 54 24 28    	addsd  0x28(%rsp),%xmm2
  66b305:	66 0f 5c e3          	subpd  %xmm3,%xmm4
  66b309:	66 0f 14 da          	unpcklpd %xmm2,%xmm3
  66b30d:	66 0f 5a d4          	cvtpd2ps %xmm4,%xmm2
  66b311:	66 0f 5a db          	cvtpd2ps %xmm3,%xmm3
  66b315:	66 0f 14 da          	unpcklpd %xmm2,%xmm3
  66b319:	66 0f 29 9c 24 80 00 	movapd %xmm3,0x80(%rsp)
  66b320:	00 00 
  66b322:	b0 01                	mov    $0x1,%al
  66b324:	49 83 fd 01          	cmp    $0x1,%r13
  66b328:	75 28                	jne    66b352 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x27b2>
  66b32a:	66 0f 28 d0          	movapd %xmm0,%xmm2
  66b32e:	66 0f 15 d0          	unpckhpd %xmm0,%xmm2
  66b332:	f2 0f 58 54 24 28    	addsd  0x28(%rsp),%xmm2
  66b338:	66 0f 5c c8          	subpd  %xmm0,%xmm1
  66b33c:	66 0f 5a c9          	cvtpd2ps %xmm1,%xmm1
  66b340:	66 0f 14 c2          	unpcklpd %xmm2,%xmm0
  66b344:	66 0f 5a c0          	cvtpd2ps %xmm0,%xmm0
  66b348:	66 0f 14 c1          	unpcklpd %xmm1,%xmm0
  66b34c:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
  66b352:	84 c0                	test   %al,%al
  66b354:	0f 84 89 00 00 00    	je     66b3e3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2843>
  66b35a:	66 0f 6f 8c 24 80 00 	movdqa 0x80(%rsp),%xmm1
  66b361:	00 00 
  66b363:	66 0f 7e cf          	movd   %xmm1,%edi
  66b367:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  66b36d:	66 0f 6f c1          	movdqa %xmm1,%xmm0
  66b371:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  66b375:	66 0f 7e c1          	movd   %xmm0,%ecx
  66b379:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  66b37f:	81 f9 00 00 80 7f    	cmp    $0x7f800000,%ecx
  66b385:	0f 9d c1             	setge  %cl
  66b388:	66 0f 6f c1          	movdqa %xmm1,%xmm0
  66b38c:	66 0f 6d c1          	punpckhqdq %xmm1,%xmm0
  66b390:	66 0f 7e c2          	movd   %xmm0,%edx
  66b394:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  66b39a:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
  66b3a0:	0f 9d c2             	setge  %dl
  66b3a3:	0f 28 c1             	movaps %xmm1,%xmm0
  66b3a6:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  66b3aa:	66 0f 7e c6          	movd   %xmm0,%esi
  66b3ae:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  66b3b4:	81 fe 00 00 80 7f    	cmp    $0x7f800000,%esi
  66b3ba:	40 0f 9d c6          	setge  %sil
  66b3be:	81 ff ff ff 7f 7f    	cmp    $0x7f7fffff,%edi
  66b3c4:	0f 8f 39 07 00 00    	jg     66bb03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f63>
  66b3ca:	84 c9                	test   %cl,%cl
  66b3cc:	0f 85 31 07 00 00    	jne    66bb03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f63>
  66b3d2:	84 d2                	test   %dl,%dl
  66b3d4:	0f 85 29 07 00 00    	jne    66bb03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f63>
  66b3da:	40 84 f6             	test   %sil,%sil
  66b3dd:	0f 85 20 07 00 00    	jne    66bb03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f63>
  66b3e3:	41 f6 c5 01          	test   $0x1,%r13b
  66b3e7:	0f 84 d3 00 00 00    	je     66b4c0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2920>
  66b3ed:	66 0f 6f 4c 24 70    	movdqa 0x70(%rsp),%xmm1
  66b3f3:	66 0f 7e cf          	movd   %xmm1,%edi
  66b3f7:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  66b3fd:	66 0f 6f c1          	movdqa %xmm1,%xmm0
  66b401:	0f c6 c1 55          	shufps $0x55,%xmm1,%xmm0
  66b405:	66 0f 7e c1          	movd   %xmm0,%ecx
  66b409:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
  66b40f:	81 f9 00 00 80 7f    	cmp    $0x7f800000,%ecx
  66b415:	0f 9d c1             	setge  %cl
  66b418:	66 0f 6f c1          	movdqa %xmm1,%xmm0
  66b41c:	66 0f 6d c1          	punpckhqdq %xmm1,%xmm0
  66b420:	66 0f 7e c2          	movd   %xmm0,%edx
  66b424:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  66b42a:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
  66b430:	0f 9d c2             	setge  %dl
  66b433:	0f 28 c1             	movaps %xmm1,%xmm0
  66b436:	0f c6 c1 ff          	shufps $0xff,%xmm1,%xmm0
  66b43a:	66 0f 7e c6          	movd   %xmm0,%esi
  66b43e:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
  66b444:	81 fe 00 00 80 7f    	cmp    $0x7f800000,%esi
  66b44a:	40 0f 9d c6          	setge  %sil
  66b44e:	81 ff ff ff 7f 7f    	cmp    $0x7f7fffff,%edi
  66b454:	0f 8f a9 06 00 00    	jg     66bb03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f63>
  66b45a:	84 c9                	test   %cl,%cl
  66b45c:	0f 85 a1 06 00 00    	jne    66bb03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f63>
  66b462:	84 d2                	test   %dl,%dl
  66b464:	0f 85 99 06 00 00    	jne    66bb03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f63>
  66b46a:	40 84 f6             	test   %sil,%sil
  66b46d:	0f 85 90 06 00 00    	jne    66bb03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f63>
  66b473:	03 5c 24 10          	add    0x10(%rsp),%ebx
  66b477:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  66b47e:	00 
  66b47f:	0f c2 44 24 70 00    	cmpeqps 0x70(%rsp),%xmm0
  66b485:	0f 50 c8             	movmskps %xmm0,%ecx
  66b488:	83 f9 0f             	cmp    $0xf,%ecx
  66b48b:	0f 94 c1             	sete   %cl
  66b48e:	84 c8                	test   %cl,%al
  66b490:	74 32                	je     66b4c4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2924>
  66b492:	4c 8b b4 24 80 01 00 	mov    0x180(%rsp),%r14
  66b499:	00 
  66b49a:	40 b5 03             	mov    $0x3,%bpl
  66b49d:	4c 3b b4 24 70 01 00 	cmp    0x170(%rsp),%r14
  66b4a4:	00 
  66b4a5:	0f 85 ab fc ff ff    	jne    66b156 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x25b6>
  66b4ab:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  66b4b2:	00 
  66b4b3:	ff 15 8f be 11 00    	call   *0x11be8f(%rip)        # 787348 <_DYNAMIC+0x640>
  66b4b9:	e9 98 fc ff ff       	jmp    66b156 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x25b6>
  66b4be:	66 90                	xchg   %ax,%ax
  66b4c0:	03 5c 24 10          	add    0x10(%rsp),%ebx
  66b4c4:	84 c0                	test   %al,%al
  66b4c6:	74 4e                	je     66b516 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2976>
  66b4c8:	4c 8b b4 24 80 01 00 	mov    0x180(%rsp),%r14
  66b4cf:	00 
  66b4d0:	4c 3b b4 24 70 01 00 	cmp    0x170(%rsp),%r14
  66b4d7:	00 
  66b4d8:	75 0e                	jne    66b4e8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2948>
  66b4da:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  66b4e1:	00 
  66b4e2:	ff 15 60 be 11 00    	call   *0x11be60(%rip)        # 787348 <_DYNAMIC+0x640>
  66b4e8:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  66b4ef:	00 
  66b4f0:	4b 8d 0c 76          	lea    (%r14,%r14,2),%rcx
  66b4f4:	89 1c 88             	mov    %ebx,(%rax,%rcx,4)
  66b4f7:	66 0f 28 84 24 80 00 	movapd 0x80(%rsp),%xmm0
  66b4fe:	00 00 
  66b500:	f3 0f 11 44 88 04    	movss  %xmm0,0x4(%rax,%rcx,4)
  66b506:	c6 44 88 08 01       	movb   $0x1,0x8(%rax,%rcx,4)
  66b50b:	49 ff c6             	inc    %r14
  66b50e:	4c 89 b4 24 80 01 00 	mov    %r14,0x180(%rsp)
  66b515:	00 
  66b516:	41 f6 c5 01          	test   $0x1,%r13b
  66b51a:	0f 84 63 fc ff ff    	je     66b183 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x25e3>
  66b520:	4c 8b b4 24 80 01 00 	mov    0x180(%rsp),%r14
  66b527:	00 
  66b528:	40 b5 02             	mov    $0x2,%bpl
  66b52b:	4c 3b b4 24 70 01 00 	cmp    0x170(%rsp),%r14
  66b532:	00 
  66b533:	0f 85 0e fc ff ff    	jne    66b147 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x25a7>
  66b539:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  66b540:	00 
  66b541:	ff 15 01 be 11 00    	call   *0x11be01(%rip)        # 787348 <_DYNAMIC+0x640>
  66b547:	66 0f 28 44 24 70    	movapd 0x70(%rsp),%xmm0
  66b54d:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
  66b554:	00 00 
  66b556:	e9 fb fb ff ff       	jmp    66b156 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x25b6>
  66b55b:	31 c0                	xor    %eax,%eax
  66b55d:	49 83 fd 01          	cmp    $0x1,%r13
  66b561:	0f 84 c3 fd ff ff    	je     66b32a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x278a>
  66b567:	e9 e6 fd ff ff       	jmp    66b352 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x27b2>
  66b56c:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  66b573:	00 
  66b574:	48 85 f6             	test   %rsi,%rsi
  66b577:	74 17                	je     66b590 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x29f0>
  66b579:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  66b580:	00 
  66b581:	48 c1 e6 03          	shl    $0x3,%rsi
  66b585:	ba 08 00 00 00       	mov    $0x8,%edx
  66b58a:	ff 15 b0 b9 11 00    	call   *0x11b9b0(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b590:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66b595:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  66b599:	74 40                	je     66b5db <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2a3b>
  66b59b:	48 85 f6             	test   %rsi,%rsi
  66b59e:	74 17                	je     66b5b7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2a17>
  66b5a0:	48 8b bc 24 98 02 00 	mov    0x298(%rsp),%rdi
  66b5a7:	00 
  66b5a8:	48 c1 e6 04          	shl    $0x4,%rsi
  66b5ac:	ba 04 00 00 00       	mov    $0x4,%edx
  66b5b1:	ff 15 89 b9 11 00    	call   *0x11b989(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b5b7:	48 8b b4 24 a8 02 00 	mov    0x2a8(%rsp),%rsi
  66b5be:	00 
  66b5bf:	48 85 f6             	test   %rsi,%rsi
  66b5c2:	74 17                	je     66b5db <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2a3b>
  66b5c4:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  66b5cb:	00 
  66b5cc:	48 c1 e6 02          	shl    $0x2,%rsi
  66b5d0:	ba 04 00 00 00       	mov    $0x4,%edx
  66b5d5:	ff 15 65 b9 11 00    	call   *0x11b965(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b5db:	0f 28 9c 24 70 02 00 	movaps 0x270(%rsp),%xmm3
  66b5e2:	00 
  66b5e3:	0f 28 c3             	movaps %xmm3,%xmm0
  66b5e6:	f3 0f 5f 84 24 e8 00 	maxss  0xe8(%rsp),%xmm0
  66b5ed:	00 00 
  66b5ef:	0f 28 c8             	movaps %xmm0,%xmm1
  66b5f2:	f3 0f c2 c8 03       	cmpunordss %xmm0,%xmm1
  66b5f7:	0f 28 d1             	movaps %xmm1,%xmm2
  66b5fa:	0f 55 d0             	andnps %xmm0,%xmm2
  66b5fd:	0f 54 cb             	andps  %xmm3,%xmm1
  66b600:	0f 56 ca             	orps   %xmm2,%xmm1
  66b603:	0f 29 8c 24 70 02 00 	movaps %xmm1,0x270(%rsp)
  66b60a:	00 
  66b60b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  66b610:	f3 0f 10 44 24 34    	movss  0x34(%rsp),%xmm0
  66b616:	f3 0f 58 80 30 0a 00 	addss  0xa30(%rax),%xmm0
  66b61d:	00 
  66b61e:	f3 0f 11 44 24 34    	movss  %xmm0,0x34(%rsp)
  66b624:	80 7c 24 44 00       	cmpb   $0x0,0x44(%rsp)
  66b629:	48 8b 84 24 68 03 00 	mov    0x368(%rsp),%rax
  66b630:	00 
  66b631:	8b b4 24 98 00 00 00 	mov    0x98(%rsp),%esi
  66b638:	48 8b 94 24 60 03 00 	mov    0x360(%rsp),%rdx
  66b63f:	00 
  66b640:	0f 84 ba db ff ff    	je     669200 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x660>
  66b646:	e9 b8 05 00 00       	jmp    66bc03 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3063>
  66b64b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  66b650:	48 8b 81 d8 09 00 00 	mov    0x9d8(%rcx),%rax
  66b657:	48 6b 89 e0 09 00 00 	imul   $0x70,0x9e0(%rcx),%rcx
  66b65e:	70 
  66b65f:	48 01 c1             	add    %rax,%rcx
  66b662:	48 89 84 24 00 07 00 	mov    %rax,0x700(%rsp)
  66b669:	00 
  66b66a:	48 89 8c 24 08 07 00 	mov    %rcx,0x708(%rsp)
  66b671:	00 
  66b672:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66b679:	00 00 00 00 00 
  66b67e:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  66b683:	48 89 84 24 18 07 00 	mov    %rax,0x718(%rsp)
  66b68a:	00 
  66b68b:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66b692:	00 
  66b693:	31 f6                	xor    %esi,%esi
  66b695:	48 8d 94 24 f7 00 00 	lea    0xf7(%rsp),%rdx
  66b69c:	00 
  66b69d:	e8 7e 5e 01 00       	call   681520 <_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapIBO_INtNtB8_9enumerate9EnumerateINtNtNtBc_5slice4iter4IterNtNtNtCshQYmODNYIQG_6parley6layout4data8LineDataEENCNvMs_NtB1X_6layoutINtB2O_6LayoutuE5lines0ENCNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB3x_7Planner11shape_inners1_0ENtNtNtBa_6traits8iterator8Iterator4foldjNCINvNvMsg_NtB8_7flattenINtB5A_13FlattenCompatppE9iter_fold7flattenINtNtB8_10filter_map9FilterMapIBO_IB12_IB1u_NtB1V_12LineItemDataEENCNvMNtB1X_4lineINtB7D_4LineuE19items_nonpositioned0ENCNvB7C_4runs0EjINvNvXsi_B5A_B5N_B4L_5count5countB6u_EE0EB3B_>
  66b6a2:	48 83 f8 02          	cmp    $0x2,%rax
  66b6a6:	0f 82 e7 e1 ff ff    	jb     669893 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xcf3>
  66b6ac:	48 c7 c0 ff ff ff ff 	mov    $0xffffffffffffffff,%rax
  66b6b3:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66b6ba:	00 ff 
  66b6bc:	0f 84 54 e1 ff ff    	je     669816 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xc76>
  66b6c2:	e9 cc e1 ff ff       	jmp    669893 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xcf3>
  66b6c7:	c7 84 24 98 00 00 00 	movl   $0xffffffff,0x98(%rsp)
  66b6ce:	ff ff ff ff 
  66b6d2:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
  66b6d9:	00 
  66b6da:	e9 6c dd ff ff       	jmp    66944b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x8ab>
  66b6df:	44 89 d2             	mov    %r10d,%edx
  66b6e2:	83 e2 1f             	and    $0x1f,%edx
  66b6e5:	41 0f b6 79 01       	movzbl 0x1(%r9),%edi
  66b6ea:	83 e7 3f             	and    $0x3f,%edi
  66b6ed:	41 80 fa df          	cmp    $0xdf,%r10b
  66b6f1:	76 31                	jbe    66b724 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2b84>
  66b6f3:	41 0f b6 71 02       	movzbl 0x2(%r9),%esi
  66b6f8:	c1 e7 06             	shl    $0x6,%edi
  66b6fb:	83 e6 3f             	and    $0x3f,%esi
  66b6fe:	09 fe                	or     %edi,%esi
  66b700:	41 80 fa f0          	cmp    $0xf0,%r10b
  66b704:	72 2c                	jb     66b732 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2b92>
  66b706:	49 8d 49 04          	lea    0x4(%r9),%rcx
  66b70a:	45 0f b6 51 03       	movzbl 0x3(%r9),%r10d
  66b70f:	83 e2 07             	and    $0x7,%edx
  66b712:	c1 e2 12             	shl    $0x12,%edx
  66b715:	c1 e6 06             	shl    $0x6,%esi
  66b718:	41 83 e2 3f          	and    $0x3f,%r10d
  66b71c:	41 09 f2             	or     %esi,%r10d
  66b71f:	41 09 d2             	or     %edx,%r10d
  66b722:	eb 1a                	jmp    66b73e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2b9e>
  66b724:	49 8d 49 02          	lea    0x2(%r9),%rcx
  66b728:	c1 e2 06             	shl    $0x6,%edx
  66b72b:	09 fa                	or     %edi,%edx
  66b72d:	41 89 d2             	mov    %edx,%r10d
  66b730:	eb 0c                	jmp    66b73e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2b9e>
  66b732:	49 8d 49 03          	lea    0x3(%r9),%rcx
  66b736:	c1 e2 0c             	shl    $0xc,%edx
  66b739:	09 d6                	or     %edx,%esi
  66b73b:	41 89 f2             	mov    %esi,%r10d
  66b73e:	49 8d 50 02          	lea    0x2(%r8),%rdx
  66b742:	48 89 c6             	mov    %rax,%rsi
  66b745:	4c 29 ce             	sub    %r9,%rsi
  66b748:	48 01 ce             	add    %rcx,%rsi
  66b74b:	41 83 fa 0a          	cmp    $0xa,%r10d
  66b74f:	bf fe ff ff ff       	mov    $0xfffffffe,%edi
  66b754:	44 0f 44 d7          	cmove  %edi,%r10d
  66b758:	44 89 94 24 98 00 00 	mov    %r10d,0x98(%rsp)
  66b75f:	00 
  66b760:	4c 0f 44 da          	cmove  %rdx,%r11
  66b764:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
  66b76b:	00 
  66b76c:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  66b773:	00 
  66b774:	48 89 f0             	mov    %rsi,%rax
  66b777:	4c 89 de             	mov    %r11,%rsi
  66b77a:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  66b77f:	e9 c7 dc ff ff       	jmp    66944b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x8ab>
  66b784:	b9 04 00 00 00       	mov    $0x4,%ecx
  66b789:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  66b78f:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  66b796:	00 
  66b797:	4c 89 ea             	mov    %r13,%rdx
  66b79a:	e8 f1 61 00 00       	call   671990 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs6tOD1aKRtN9_11gpui_canvas>
  66b79f:	e9 54 e2 ff ff       	jmp    6699f8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0xe58>
  66b7a4:	c7 84 24 b8 00 00 00 	movl   $0x7,0xb8(%rsp)
  66b7ab:	07 00 00 00 
  66b7af:	eb 0b                	jmp    66b7bc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c1c>
  66b7b1:	c7 84 24 b8 00 00 00 	movl   $0x4,0xb8(%rsp)
  66b7b8:	04 00 00 00 
  66b7bc:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  66b7c3:	00 ff ff ff ff 
  66b7c8:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66b7cd:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  66b7d4:	00 
  66b7d5:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66b7d9:	74 76                	je     66b851 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2cb1>
  66b7db:	48 85 c0             	test   %rax,%rax
  66b7de:	74 1b                	je     66b7fb <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c5b>
  66b7e0:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  66b7e7:	00 
  66b7e8:	48 c1 e0 03          	shl    $0x3,%rax
  66b7ec:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66b7f0:	ba 04 00 00 00       	mov    $0x4,%edx
  66b7f5:	ff 15 45 b7 11 00    	call   *0x11b745(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b7fb:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  66b802:	00 
  66b803:	48 85 c0             	test   %rax,%rax
  66b806:	74 1b                	je     66b823 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c83>
  66b808:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  66b80f:	00 
  66b810:	48 c1 e0 03          	shl    $0x3,%rax
  66b814:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66b818:	ba 04 00 00 00       	mov    $0x4,%edx
  66b81d:	ff 15 1d b7 11 00    	call   *0x11b71d(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b823:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  66b82a:	00 
  66b82b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66b82f:	74 20                	je     66b851 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2cb1>
  66b831:	48 85 c0             	test   %rax,%rax
  66b834:	74 1b                	je     66b851 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2cb1>
  66b836:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
  66b83d:	00 
  66b83e:	48 c1 e0 02          	shl    $0x2,%rax
  66b842:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  66b846:	ba 04 00 00 00       	mov    $0x4,%edx
  66b84b:	ff 15 ef b6 11 00    	call   *0x11b6ef(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b851:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  66b858:	00 
  66b859:	48 85 f6             	test   %rsi,%rsi
  66b85c:	74 17                	je     66b875 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2cd5>
  66b85e:	48 8b bc 24 00 01 00 	mov    0x100(%rsp),%rdi
  66b865:	00 
  66b866:	48 c1 e6 04          	shl    $0x4,%rsi
  66b86a:	ba 04 00 00 00       	mov    $0x4,%edx
  66b86f:	ff 15 cb b6 11 00    	call   *0x11b6cb(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b875:	48 8b b4 24 e8 02 00 	mov    0x2e8(%rsp),%rsi
  66b87c:	00 
  66b87d:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66b881:	77 18                	ja     66b89b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2cfb>
  66b883:	48 85 f6             	test   %rsi,%rsi
  66b886:	74 13                	je     66b89b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2cfb>
  66b888:	48 8b bc 24 f0 02 00 	mov    0x2f0(%rsp),%rdi
  66b88f:	00 
  66b890:	ba 01 00 00 00       	mov    $0x1,%edx
  66b895:	ff 15 a5 b6 11 00    	call   *0x11b6a5(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b89b:	48 8b b4 24 00 03 00 	mov    0x300(%rsp),%rsi
  66b8a2:	00 
  66b8a3:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66b8a7:	77 18                	ja     66b8c1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2d21>
  66b8a9:	48 85 f6             	test   %rsi,%rsi
  66b8ac:	74 13                	je     66b8c1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2d21>
  66b8ae:	48 8b bc 24 08 03 00 	mov    0x308(%rsp),%rdi
  66b8b5:	00 
  66b8b6:	ba 01 00 00 00       	mov    $0x1,%edx
  66b8bb:	ff 15 7f b6 11 00    	call   *0x11b67f(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b8c1:	48 8b b4 24 18 03 00 	mov    0x318(%rsp),%rsi
  66b8c8:	00 
  66b8c9:	48 83 fe fd          	cmp    $0xfffffffffffffffd,%rsi
  66b8cd:	77 18                	ja     66b8e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2d47>
  66b8cf:	48 85 f6             	test   %rsi,%rsi
  66b8d2:	74 13                	je     66b8e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2d47>
  66b8d4:	48 8b bc 24 20 03 00 	mov    0x320(%rsp),%rdi
  66b8db:	00 
  66b8dc:	ba 01 00 00 00       	mov    $0x1,%edx
  66b8e1:	ff 15 59 b6 11 00    	call   *0x11b659(%rip)        # 786f40 <_DYNAMIC+0x238>
  66b8e7:	49 8d bf c8 08 00 00 	lea    0x8c8(%r15),%rdi
  66b8ee:	e8 0d b7 ff ff       	call   667000 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCshQYmODNYIQG_6parley6layout6layout6LayoutuEECs6tOD1aKRtN9_11gpui_canvas>
  66b8f3:	49 c7 87 c8 08 00 00 	movq   $0x0,0x8c8(%r15)
  66b8fa:	00 00 00 00 
  66b8fe:	49 c7 87 d0 08 00 00 	movq   $0x4,0x8d0(%r15)
  66b905:	04 00 00 00 
  66b909:	0f 57 c0             	xorps  %xmm0,%xmm0
  66b90c:	41 0f 11 87 d8 08 00 	movups %xmm0,0x8d8(%r15)
  66b913:	00 
  66b914:	49 c7 87 e8 08 00 00 	movq   $0x4,0x8e8(%r15)
  66b91b:	04 00 00 00 
  66b91f:	41 0f 11 87 f0 08 00 	movups %xmm0,0x8f0(%r15)
  66b926:	00 
  66b927:	49 c7 87 00 09 00 00 	movq   $0x8,0x900(%r15)
  66b92e:	08 00 00 00 
  66b932:	41 0f 11 87 08 09 00 	movups %xmm0,0x908(%r15)
  66b939:	00 
  66b93a:	49 c7 87 18 09 00 00 	movq   $0x8,0x918(%r15)
  66b941:	08 00 00 00 
  66b945:	41 0f 11 87 20 09 00 	movups %xmm0,0x920(%r15)
  66b94c:	00 
  66b94d:	49 c7 87 30 09 00 00 	movq   $0x4,0x930(%r15)
  66b954:	04 00 00 00 
  66b958:	41 0f 11 87 38 09 00 	movups %xmm0,0x938(%r15)
  66b95f:	00 
  66b960:	49 c7 87 48 09 00 00 	movq   $0x4,0x948(%r15)
  66b967:	04 00 00 00 
  66b96b:	41 0f 11 87 50 09 00 	movups %xmm0,0x950(%r15)
  66b972:	00 
  66b973:	49 c7 87 60 09 00 00 	movq   $0x4,0x960(%r15)
  66b97a:	04 00 00 00 
  66b97e:	41 0f 11 87 68 09 00 	movups %xmm0,0x968(%r15)
  66b985:	00 
  66b986:	49 c7 87 78 09 00 00 	movq   $0x8,0x978(%r15)
  66b98d:	08 00 00 00 
  66b991:	41 0f 11 87 80 09 00 	movups %xmm0,0x980(%r15)
  66b998:	00 
  66b999:	49 c7 87 90 09 00 00 	movq   $0x2,0x990(%r15)
  66b9a0:	02 00 00 00 
  66b9a4:	41 0f 11 87 98 09 00 	movups %xmm0,0x998(%r15)
  66b9ab:	00 
  66b9ac:	49 c7 87 a8 09 00 00 	movq   $0x4,0x9a8(%r15)
  66b9b3:	04 00 00 00 
  66b9b7:	41 0f 11 87 b0 09 00 	movups %xmm0,0x9b0(%r15)
  66b9be:	00 
  66b9bf:	49 c7 87 c0 09 00 00 	movq   $0x8,0x9c0(%r15)
  66b9c6:	08 00 00 00 
  66b9ca:	41 0f 11 87 c8 09 00 	movups %xmm0,0x9c8(%r15)
  66b9d1:	00 
  66b9d2:	49 c7 87 d8 09 00 00 	movq   $0x8,0x9d8(%r15)
  66b9d9:	08 00 00 00 
  66b9dd:	41 0f 11 87 e0 09 00 	movups %xmm0,0x9e0(%r15)
  66b9e4:	00 
  66b9e5:	49 c7 87 f0 09 00 00 	movq   $0x8,0x9f0(%r15)
  66b9ec:	08 00 00 00 
  66b9f0:	41 0f 11 87 f8 09 00 	movups %xmm0,0x9f8(%r15)
  66b9f7:	00 
  66b9f8:	49 c7 87 08 0a 00 00 	movq   $0x4,0xa08(%r15)
  66b9ff:	04 00 00 00 
  66ba03:	41 0f 11 87 10 0a 00 	movups %xmm0,0xa10(%r15)
  66ba0a:	00 
  66ba0b:	41 c7 87 20 0a 00 00 	movl   $0x3f800000,0xa20(%r15)
  66ba12:	00 00 80 3f 
  66ba16:	41 0f 11 87 24 0a 00 	movups %xmm0,0xa24(%r15)
  66ba1d:	00 
  66ba1e:	49 c7 87 32 0a 00 00 	movq   $0x0,0xa32(%r15)
  66ba25:	00 00 00 00 
  66ba29:	66 41 c7 87 3a 0a 00 	movw   $0xff01,0xa3a(%r15)
  66ba30:	00 01 ff 
  66ba33:	41 c6 87 3c 0a 00 00 	movb   $0x0,0xa3c(%r15)
  66ba3a:	00 
  66ba3b:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  66ba42:	00 
  66ba43:	48 8b 84 24 80 03 00 	mov    0x380(%rsp),%rax
  66ba4a:	00 
  66ba4b:	48 89 48 30          	mov    %rcx,0x30(%rax)
  66ba4f:	0f 10 84 24 b0 00 00 	movups 0xb0(%rsp),%xmm0
  66ba56:	00 
  66ba57:	0f 10 8c 24 c0 00 00 	movups 0xc0(%rsp),%xmm1
  66ba5e:	00 
  66ba5f:	0f 10 94 24 d0 00 00 	movups 0xd0(%rsp),%xmm2
  66ba66:	00 
  66ba67:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  66ba6b:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  66ba6f:	0f 11 00             	movups %xmm0,(%rax)
  66ba72:	48 81 c4 d8 11 00 00 	add    $0x11d8,%rsp
  66ba79:	5b                   	pop    %rbx
  66ba7a:	41 5c                	pop    %r12
  66ba7c:	41 5d                	pop    %r13
  66ba7e:	41 5e                	pop    %r14
  66ba80:	41 5f                	pop    %r15
  66ba82:	5d                   	pop    %rbp
  66ba83:	c3                   	ret
  66ba84:	48 8d 35 f5 e4 11 00 	lea    0x11e4f5(%rip),%rsi        # 789f80 <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text11HEBREW_FONT.llvm.17982672398492329123>
  66ba8b:	48 8d 15 d2 49 9f ff 	lea    -0x60b62e(%rip),%rdx        # 60464 <_RNvNtCs6tOD1aKRtN9_11gpui_canvas4text12HEBREW_BYTES>
  66ba92:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66ba99:	00 
  66ba9a:	b9 14 69 00 00       	mov    $0x6914,%ecx
  66ba9f:	45 31 c0             	xor    %r8d,%r8d
  66baa2:	e8 59 7f ff ff       	call   663a00 <_RNvMNtCs6tOD1aKRtN9_11gpui_canvas4textNtB2_8FontFace13shared_static.llvm.17982672398492329123>
  66baa7:	80 bc 24 00 07 00 00 	cmpb   $0x0,0x700(%rsp)
  66baae:	00 
  66baaf:	0f 85 de d4 ff ff    	jne    668f93 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3f3>
  66bab5:	4d 8d be 50 0a 00 00 	lea    0xa50(%r14),%r15
  66babc:	4c 8b a4 24 08 07 00 	mov    0x708(%rsp),%r12
  66bac3:	00 
  66bac4:	49 8b 07             	mov    (%r15),%rax
  66bac7:	48 85 c0             	test   %rax,%rax
  66baca:	74 0f                	je     66badb <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f3b>
  66bacc:	f0 48 ff 08          	lock decq (%rax)
  66bad0:	75 09                	jne    66badb <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f3b>
  66bad2:	4c 89 ff             	mov    %r15,%rdi
  66bad5:	ff 15 8d b4 11 00    	call   *0x11b48d(%rip)        # 786f68 <_DYNAMIC+0x260>
  66badb:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66bae0:	4c 89 a7 50 0a 00 00 	mov    %r12,0xa50(%rdi)
  66bae7:	be 02 00 00 00       	mov    $0x2,%esi
  66baec:	e8 3f 0c 00 00       	call   66c730 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner8register>
  66baf1:	83 f8 ff             	cmp    $0xffffffff,%eax
  66baf4:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
  66baf8:	0f 85 f6 d4 ff ff    	jne    668ff4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x454>
  66bafe:	e9 30 d5 ff ff       	jmp    669033 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x493>
  66bb03:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  66bb0a:	00 
  66bb0b:	48 85 f6             	test   %rsi,%rsi
  66bb0e:	74 17                	je     66bb27 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2f87>
  66bb10:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  66bb17:	00 
  66bb18:	48 c1 e6 03          	shl    $0x3,%rsi
  66bb1c:	ba 08 00 00 00       	mov    $0x8,%edx
  66bb21:	ff 15 19 b4 11 00    	call   *0x11b419(%rip)        # 786f40 <_DYNAMIC+0x238>
  66bb27:	bb 01 00 00 00       	mov    $0x1,%ebx
  66bb2c:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  66bb31:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  66bb35:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66bb3a:	74 40                	je     66bb7c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2fdc>
  66bb3c:	48 85 f6             	test   %rsi,%rsi
  66bb3f:	74 17                	je     66bb58 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2fb8>
  66bb41:	48 8b bc 24 98 02 00 	mov    0x298(%rsp),%rdi
  66bb48:	00 
  66bb49:	48 c1 e6 04          	shl    $0x4,%rsi
  66bb4d:	ba 04 00 00 00       	mov    $0x4,%edx
  66bb52:	ff 15 e8 b3 11 00    	call   *0x11b3e8(%rip)        # 786f40 <_DYNAMIC+0x238>
  66bb58:	48 8b b4 24 a8 02 00 	mov    0x2a8(%rsp),%rsi
  66bb5f:	00 
  66bb60:	48 85 f6             	test   %rsi,%rsi
  66bb63:	74 17                	je     66bb7c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2fdc>
  66bb65:	48 8b bc 24 b0 02 00 	mov    0x2b0(%rsp),%rdi
  66bb6c:	00 
  66bb6d:	48 c1 e6 02          	shl    $0x2,%rsi
  66bb71:	ba 04 00 00 00       	mov    $0x4,%edx
  66bb76:	ff 15 c4 b3 11 00    	call   *0x11b3c4(%rip)        # 786f40 <_DYNAMIC+0x238>
  66bb7c:	89 9c 24 b8 00 00 00 	mov    %ebx,0xb8(%rsp)
  66bb83:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  66bb8a:	00 ff ff ff ff 
  66bb8f:	e9 39 fc ff ff       	jmp    66b7cd <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c2d>
  66bb94:	c7 84 24 b8 00 00 00 	movl   $0x3,0xb8(%rsp)
  66bb9b:	03 00 00 00 
  66bb9f:	e9 18 fc ff ff       	jmp    66b7bc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c1c>
  66bba4:	48 c7 84 24 b8 00 00 	movq   $0x3,0xb8(%rsp)
  66bbab:	00 03 00 00 00 
  66bbb0:	e9 07 fc ff ff       	jmp    66b7bc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c1c>
  66bbb5:	c7 84 24 b8 00 00 00 	movl   $0x1,0xb8(%rsp)
  66bbbc:	01 00 00 00 
  66bbc0:	e9 f7 fb ff ff       	jmp    66b7bc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c1c>
  66bbc5:	c7 84 24 b8 00 00 00 	movl   $0x3,0xb8(%rsp)
  66bbcc:	03 00 00 00 
  66bbd0:	8b 84 24 08 02 00 00 	mov    0x208(%rsp),%eax
  66bbd7:	89 84 24 bc 00 00 00 	mov    %eax,0xbc(%rsp)
  66bbde:	e9 d9 fb ff ff       	jmp    66b7bc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c1c>
  66bbe3:	48 c7 84 24 b8 00 00 	movq   $0xc,0xb8(%rsp)
  66bbea:	00 0c 00 00 00 
  66bbef:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  66bbf6:	00 ff ff ff ff 
  66bbfb:	49 89 f7             	mov    %rsi,%r15
  66bbfe:	e9 ca fb ff ff       	jmp    66b7cd <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c2d>
  66bc03:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66bc0a:	00 ff 
  66bc0c:	0f 84 48 01 00 00    	je     66bd5a <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x31ba>
  66bc12:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  66bc19:	00 
  66bc1a:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66bc1e:	0f 84 35 03 00 00    	je     66bf59 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x33b9>
  66bc24:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  66bc2b:	00 
  66bc2c:	48 39 f0             	cmp    %rsi,%rax
  66bc2f:	0f 86 24 03 00 00    	jbe    66bf59 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x33b9>
  66bc35:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  66bc3c:	00 
  66bc3d:	e8 3e 0d 00 00       	call   66c980 <_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner6shrinkCs6tOD1aKRtN9_11gpui_canvas>
  66bc42:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66bc46:	0f 84 0d 03 00 00    	je     66bf59 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x33b9>
  66bc4c:	48 89 c7             	mov    %rax,%rdi
  66bc4f:	48 89 d6             	mov    %rdx,%rsi
  66bc52:	ff 15 00 b4 11 00    	call   *0x11b400(%rip)        # 787058 <_DYNAMIC+0x350>
  66bc58:	e9 3a 06 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66bc5d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66bc62:	4c 8b 44 24 28       	mov    0x28(%rsp),%r8
  66bc67:	eb 28                	jmp    66bc91 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30f1>
  66bc69:	c7 44 24 30 00 00 00 	movl   $0x0,0x30(%rsp)
  66bc70:	00 
  66bc71:	4c 8b 8c 24 40 03 00 	mov    0x340(%rsp),%r9
  66bc78:	00 
  66bc79:	4d 85 c9             	test   %r9,%r9
  66bc7c:	74 21                	je     66bc9f <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x30ff>
  66bc7e:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66bc83:	4c 8b 44 24 28       	mov    0x28(%rsp),%r8
  66bc88:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  66bc8d:	8b 54 24 30          	mov    0x30(%rsp),%edx
  66bc91:	49 39 c9             	cmp    %rcx,%r9
  66bc94:	73 21                	jae    66bcb7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3117>
  66bc96:	43 80 3c 08 bf       	cmpb   $0xbf,(%r8,%r9,1)
  66bc9b:	7f 1f                	jg     66bcbc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x311c>
  66bc9d:	eb 46                	jmp    66bce5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3145>
  66bc9f:	45 31 c9             	xor    %r9d,%r9d
  66bca2:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66bca7:	4c 8b 44 24 28       	mov    0x28(%rsp),%r8
  66bcac:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
  66bcb1:	8b 54 24 30          	mov    0x30(%rsp),%edx
  66bcb5:	eb 05                	jmp    66bcbc <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x311c>
  66bcb7:	49 89 c9             	mov    %rcx,%r9
  66bcba:	75 29                	jne    66bce5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3145>
  66bcbc:	84 d2                	test   %dl,%dl
  66bcbe:	74 15                	je     66bcd5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3135>
  66bcc0:	4c 39 cd             	cmp    %r9,%rbp
  66bcc3:	74 20                	je     66bce5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3145>
  66bcc5:	43 0f b6 0c 08       	movzbl (%r8,%r9,1),%ecx
  66bcca:	84 c9                	test   %cl,%cl
  66bccc:	78 40                	js     66bd0e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x316e>
  66bcce:	b8 0b 00 00 00       	mov    $0xb,%eax
  66bcd3:	eb 1a                	jmp    66bcef <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x314f>
  66bcd5:	48 39 cd             	cmp    %rcx,%rbp
  66bcd8:	73 09                	jae    66bce3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3143>
  66bcda:	41 80 3c 28 bf       	cmpb   $0xbf,(%r8,%rbp,1)
  66bcdf:	7f df                	jg     66bcc0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3120>
  66bce1:	eb 02                	jmp    66bce5 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3145>
  66bce3:	74 db                	je     66bcc0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3120>
  66bce5:	b8 03 00 00 00       	mov    $0x3,%eax
  66bcea:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
  66bcef:	89 84 24 b8 00 00 00 	mov    %eax,0xb8(%rsp)
  66bcf6:	89 8c 24 bc 00 00 00 	mov    %ecx,0xbc(%rsp)
  66bcfd:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  66bd04:	00 ff ff ff ff 
  66bd09:	e9 bf fa ff ff       	jmp    66b7cd <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2c2d>
  66bd0e:	89 ca                	mov    %ecx,%edx
  66bd10:	83 e2 1f             	and    $0x1f,%edx
  66bd13:	43 0f b6 7c 08 01    	movzbl 0x1(%r8,%r9,1),%edi
  66bd19:	83 e7 3f             	and    $0x3f,%edi
  66bd1c:	b8 0b 00 00 00       	mov    $0xb,%eax
  66bd21:	80 f9 df             	cmp    $0xdf,%cl
  66bd24:	76 2b                	jbe    66bd51 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x31b1>
  66bd26:	43 0f b6 74 08 02    	movzbl 0x2(%r8,%r9,1),%esi
  66bd2c:	c1 e7 06             	shl    $0x6,%edi
  66bd2f:	83 e6 3f             	and    $0x3f,%esi
  66bd32:	09 fe                	or     %edi,%esi
  66bd34:	80 f9 f0             	cmp    $0xf0,%cl
  66bd37:	72 7f                	jb     66bdb8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3218>
  66bd39:	43 0f b6 4c 08 03    	movzbl 0x3(%r8,%r9,1),%ecx
  66bd3f:	83 e2 07             	and    $0x7,%edx
  66bd42:	c1 e2 12             	shl    $0x12,%edx
  66bd45:	c1 e6 06             	shl    $0x6,%esi
  66bd48:	83 e1 3f             	and    $0x3f,%ecx
  66bd4b:	09 f1                	or     %esi,%ecx
  66bd4d:	09 d1                	or     %edx,%ecx
  66bd4f:	eb 9e                	jmp    66bcef <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x314f>
  66bd51:	c1 e2 06             	shl    $0x6,%edx
  66bd54:	09 fa                	or     %edi,%edx
  66bd56:	89 d1                	mov    %edx,%ecx
  66bd58:	eb 95                	jmp    66bcef <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x314f>
  66bd5a:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  66bd61:	00 
  66bd62:	48 85 c0             	test   %rax,%rax
  66bd65:	0f 84 ca 00 00 00    	je     66be35 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3295>
  66bd6b:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  66bd72:	00 
  66bd73:	48 c1 e0 04          	shl    $0x4,%rax
  66bd77:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  66bd7c:	2b 54 01 f0          	sub    -0x10(%rcx,%rax,1),%edx
  66bd80:	0f 83 bc 00 00 00    	jae    66be42 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x32a2>
  66bd86:	c7 84 24 b8 00 00 00 	movl   $0x3,0xb8(%rsp)
  66bd8d:	03 00 00 00 
  66bd91:	48 c7 84 24 b0 00 00 	movq   $0xffffffffffffffff,0xb0(%rsp)
  66bd98:	00 ff ff ff ff 
  66bd9d:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66bda2:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  66bda9:	00 
  66bdaa:	48 85 f6             	test   %rsi,%rsi
  66bdad:	0f 85 ab fa ff ff    	jne    66b85e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2cbe>
  66bdb3:	e9 bd fa ff ff       	jmp    66b875 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2cd5>
  66bdb8:	c1 e2 0c             	shl    $0xc,%edx
  66bdbb:	09 d6                	or     %edx,%esi
  66bdbd:	89 f1                	mov    %esi,%ecx
  66bdbf:	e9 2b ff ff ff       	jmp    66bcef <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x314f>
  66bdc4:	bb 03 00 00 00       	mov    $0x3,%ebx
  66bdc9:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66bdce:	e9 a9 fd ff ff       	jmp    66bb7c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2fdc>
  66bdd3:	48 8d 3d d2 1f bf ff 	lea    -0x40e02e(%rip),%rdi        # 25ddac <anon.77df2256dbac5170b9422659b074405f.30.llvm.9834853108928011428>
  66bdda:	48 8d 15 27 09 11 00 	lea    0x110927(%rip),%rdx        # 77c708 <anon.77df2256dbac5170b9422659b074405f.31.llvm.9834853108928011428>
  66bde1:	be ad 00 00 00       	mov    $0xad,%esi
  66bde6:	ff 15 4c b2 11 00    	call   *0x11b24c(%rip)        # 787038 <_DYNAMIC+0x330>
  66bdec:	e9 a6 04 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66bdf1:	48 8d 0d 08 05 11 00 	lea    0x110508(%rip),%rcx        # 77c300 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x70>
  66bdf8:	4c 89 ef             	mov    %r13,%rdi
  66bdfb:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
  66be02:	00 
  66be03:	ff 15 e7 b4 11 00    	call   *0x11b4e7(%rip)        # 7872f0 <_DYNAMIC+0x5e8>
  66be09:	e9 89 04 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66be0e:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  66be14:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  66be18:	41 89 c7             	mov    %eax,%r15d
  66be1b:	e9 da d1 ff ff       	jmp    668ffa <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x45a>
  66be20:	41 bc 03 00 00 00    	mov    $0x3,%r12d
  66be26:	8b 84 24 c0 01 00 00 	mov    0x1c0(%rsp),%eax
  66be2d:	41 89 c7             	mov    %eax,%r15d
  66be30:	e9 c5 d1 ff ff       	jmp    668ffa <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x45a>
  66be35:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
  66be3b:	75 11                	jne    66be4e <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x32ae>
  66be3d:	e9 17 01 00 00       	jmp    66bf59 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x33b9>
  66be42:	81 fa ff 00 00 00    	cmp    $0xff,%edx
  66be48:	0f 86 bf 02 00 00    	jbe    66c10d <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x356d>
  66be4e:	bf 04 00 00 00       	mov    $0x4,%edi
  66be53:	be 18 00 00 00       	mov    $0x18,%esi
  66be58:	e8 f3 0d 00 00       	call   66cc50 <_RNvNtCscdodAO9FK5_5alloc5boxed14box_new_uninit>
  66be5d:	49 89 c7             	mov    %rax,%r15
  66be60:	8b 84 24 08 01 00 00 	mov    0x108(%rsp),%eax
  66be67:	41 c7 07 00 00 00 00 	movl   $0x0,(%r15)
  66be6e:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
  66be73:	45 89 77 04          	mov    %r14d,0x4(%r15)
  66be77:	41 c7 47 08 00 00 00 	movl   $0x0,0x8(%r15)
  66be7e:	00 
  66be7f:	41 89 47 0c          	mov    %eax,0xc(%r15)
  66be83:	41 c7 47 10 00 00 00 	movl   $0x0,0x10(%r15)
  66be8a:	00 
  66be8b:	66 41 c7 47 14 00 00 	movw   $0x0,0x14(%r15)
  66be92:	bf 04 00 00 00       	mov    $0x4,%edi
  66be97:	be 18 00 00 00       	mov    $0x18,%esi
  66be9c:	e8 af 0d 00 00       	call   66cc50 <_RNvNtCscdodAO9FK5_5alloc5boxed14box_new_uninit>
  66bea1:	48 89 c3             	mov    %rax,%rbx
  66bea4:	c7 00 00 00 00 00    	movl   $0x0,(%rax)
  66beaa:	44 89 70 04          	mov    %r14d,0x4(%rax)
  66beae:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
  66beb5:	f3 0f 10 44 24 34    	movss  0x34(%rsp),%xmm0
  66bebb:	f3 0f 11 40 0c       	movss  %xmm0,0xc(%rax)
  66bec0:	f3 0f 10 84 24 94 00 	movss  0x94(%rsp),%xmm0
  66bec7:	00 00 
  66bec9:	f3 0f 11 40 10       	movss  %xmm0,0x10(%rax)
  66bece:	0f 28 84 24 70 02 00 	movaps 0x270(%rsp),%xmm0
  66bed5:	00 
  66bed6:	f3 0f 11 40 14       	movss  %xmm0,0x14(%rax)
  66bedb:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66bee2:	00 ff 
  66bee4:	74 0d                	je     66bef3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3353>
  66bee6:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
  66beed:	00 
  66beee:	e8 3d c2 ff ff       	call   668130 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCs6tOD1aKRtN9_11gpui_canvas4text6layout12TextGeometryEBH_>
  66bef3:	48 c7 84 24 40 01 00 	movq   $0x1,0x140(%rsp)
  66befa:	00 01 00 00 00 
  66beff:	4c 89 bc 24 48 01 00 	mov    %r15,0x148(%rsp)
  66bf06:	00 
  66bf07:	48 c7 84 24 50 01 00 	movq   $0x1,0x150(%rsp)
  66bf0e:	00 01 00 00 00 
  66bf13:	48 c7 84 24 58 01 00 	movq   $0x1,0x158(%rsp)
  66bf1a:	00 01 00 00 00 
  66bf1f:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
  66bf26:	00 
  66bf27:	48 c7 84 24 68 01 00 	movq   $0x1,0x168(%rsp)
  66bf2e:	00 01 00 00 00 
  66bf33:	48 c7 84 24 70 01 00 	movq   $0xffffffffffffffff,0x170(%rsp)
  66bf3a:	00 ff ff ff ff 
  66bf3f:	44 89 b4 24 88 01 00 	mov    %r14d,0x188(%rsp)
  66bf46:	00 
  66bf47:	f3 0f 10 84 24 9c 00 	movss  0x9c(%rsp),%xmm0
  66bf4e:	00 00 
  66bf50:	f3 0f 11 84 24 8c 01 	movss  %xmm0,0x18c(%rsp)
  66bf57:	00 00 
  66bf59:	4c 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%r15
  66bf60:	00 
  66bf61:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
  66bf68:	00 
  66bf69:	4c 8b b4 24 08 01 00 	mov    0x108(%rsp),%r14
  66bf70:	00 
  66bf71:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  66bf76:	48 8b b4 24 f8 01 00 	mov    0x1f8(%rsp),%rsi
  66bf7d:	00 
  66bf7e:	e8 6d 06 00 00       	call   66c5f0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner8font_set>
  66bf83:	49 89 c5             	mov    %rax,%r13
  66bf86:	48 89 84 24 b0 04 00 	mov    %rax,0x4b0(%rsp)
  66bf8d:	00 
  66bf8e:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  66bf95:	00 
  66bf96:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  66bf9a:	0f 84 c3 00 00 00    	je     66c063 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x34c3>
  66bfa0:	48 8d 94 24 48 01 00 	lea    0x148(%rsp),%rdx
  66bfa7:	00 
  66bfa8:	48 8b 4a 40          	mov    0x40(%rdx),%rcx
  66bfac:	48 89 8c 24 58 07 00 	mov    %rcx,0x758(%rsp)
  66bfb3:	00 
  66bfb4:	0f 10 02             	movups (%rdx),%xmm0
  66bfb7:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  66bfbb:	0f 10 52 20          	movups 0x20(%rdx),%xmm2
  66bfbf:	0f 10 5a 30          	movups 0x30(%rdx),%xmm3
  66bfc3:	0f 11 9c 24 48 07 00 	movups %xmm3,0x748(%rsp)
  66bfca:	00 
  66bfcb:	0f 11 94 24 38 07 00 	movups %xmm2,0x738(%rsp)
  66bfd2:	00 
  66bfd3:	0f 11 8c 24 28 07 00 	movups %xmm1,0x728(%rsp)
  66bfda:	00 
  66bfdb:	0f 11 84 24 18 07 00 	movups %xmm0,0x718(%rsp)
  66bfe2:	00 
  66bfe3:	48 c7 84 24 00 07 00 	movq   $0x1,0x700(%rsp)
  66bfea:	00 01 00 00 00 
  66bfef:	48 c7 84 24 08 07 00 	movq   $0x1,0x708(%rsp)
  66bff6:	00 01 00 00 00 
  66bffb:	48 8d 9c 24 10 07 00 	lea    0x710(%rsp),%rbx
  66c002:	00 
  66c003:	48 89 84 24 10 07 00 	mov    %rax,0x710(%rsp)
  66c00a:	00 
  66c00b:	bf 08 00 00 00       	mov    $0x8,%edi
  66c010:	be 60 00 00 00       	mov    $0x60,%esi
  66c015:	e8 36 0c 00 00       	call   66cc50 <_RNvNtCscdodAO9FK5_5alloc5boxed14box_new_uninit>
  66c01a:	0f 10 84 24 50 07 00 	movups 0x750(%rsp),%xmm0
  66c021:	00 
  66c022:	0f 11 40 50          	movups %xmm0,0x50(%rax)
  66c026:	0f 10 84 24 40 07 00 	movups 0x740(%rsp),%xmm0
  66c02d:	00 
  66c02e:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  66c032:	0f 10 84 24 00 07 00 	movups 0x700(%rsp),%xmm0
  66c039:	00 
  66c03a:	0f 10 8c 24 10 07 00 	movups 0x710(%rsp),%xmm1
  66c041:	00 
  66c042:	0f 10 94 24 20 07 00 	movups 0x720(%rsp),%xmm2
  66c049:	00 
  66c04a:	0f 10 9c 24 30 07 00 	movups 0x730(%rsp),%xmm3
  66c051:	00 
  66c052:	0f 11 58 30          	movups %xmm3,0x30(%rax)
  66c056:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  66c05a:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  66c05e:	0f 11 00             	movups %xmm0,(%rax)
  66c061:	eb 02                	jmp    66c065 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x34c5>
  66c063:	31 c0                	xor    %eax,%eax
  66c065:	4c 89 bc 24 b0 00 00 	mov    %r15,0xb0(%rsp)
  66c06c:	00 
  66c06d:	4c 89 a4 24 b8 00 00 	mov    %r12,0xb8(%rsp)
  66c074:	00 
  66c075:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
  66c07c:	00 
  66c07d:	4c 89 ac 24 c8 00 00 	mov    %r13,0xc8(%rsp)
  66c084:	00 
  66c085:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  66c08c:	00 
  66c08d:	0f 28 84 24 70 02 00 	movaps 0x270(%rsp),%xmm0
  66c094:	00 
  66c095:	f3 0f 11 84 24 d8 00 	movss  %xmm0,0xd8(%rsp)
  66c09c:	00 00 
  66c09e:	f3 0f 10 44 24 34    	movss  0x34(%rsp),%xmm0
  66c0a4:	f3 0f 11 84 24 dc 00 	movss  %xmm0,0xdc(%rsp)
  66c0ab:	00 00 
  66c0ad:	f3 0f 10 84 24 94 00 	movss  0x94(%rsp),%xmm0
  66c0b4:	00 00 
  66c0b6:	f3 0f 11 84 24 e0 00 	movss  %xmm0,0xe0(%rsp)
  66c0bd:	00 00 
  66c0bf:	f3 0f 10 84 24 9c 00 	movss  0x9c(%rsp),%xmm0
  66c0c6:	00 00 
  66c0c8:	f3 0f 11 84 24 e4 00 	movss  %xmm0,0xe4(%rsp)
  66c0cf:	00 00 
  66c0d1:	48 8d bc 24 e8 02 00 	lea    0x2e8(%rsp),%rdi
  66c0d8:	00 
  66c0d9:	e8 e2 a7 ff ff       	call   6668c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueANtNtCs2D57TIA91Kp_8parlance11font_family14FontFamilyNamej3_ECs6tOD1aKRtN9_11gpui_canvas>
  66c0de:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  66c0e2:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  66c0e7:	0f 85 4e f9 ff ff    	jne    66ba3b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2e9b>
  66c0ed:	e9 f5 f7 ff ff       	jmp    66b8e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2d47>
  66c0f2:	48 8d 0d df 08 11 00 	lea    0x1108df(%rip),%rcx        # 77c9d8 <anon.82ba7c80bfefe788d7fd53f5e69bad68.32.llvm.13034477518265263966>
  66c0f9:	48 89 f7             	mov    %rsi,%rdi
  66c0fc:	48 89 d6             	mov    %rdx,%rsi
  66c0ff:	4c 89 c2             	mov    %r8,%rdx
  66c102:	ff 15 e8 b1 11 00    	call   *0x11b1e8(%rip)        # 7872f0 <_DYNAMIC+0x5e8>
  66c108:	e9 8a 01 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66c10d:	48 01 c1             	add    %rax,%rcx
  66c110:	88 51 ff             	mov    %dl,-0x1(%rcx)
  66c113:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66c11a:	00 ff 
  66c11c:	0f 85 f0 fa ff ff    	jne    66bc12 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3072>
  66c122:	e9 32 fe ff ff       	jmp    66bf59 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x33b9>
  66c127:	49 89 cd             	mov    %rcx,%r13
  66c12a:	48 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%rax
  66c131:	00 
  66c132:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  66c139:	00 
  66c13a:	48 8d 0d c7 02 11 00 	lea    0x1102c7(%rip),%rcx        # 77c408 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x178>
  66c141:	e9 b2 fc ff ff       	jmp    66bdf8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3258>
  66c146:	49 89 d5             	mov    %rdx,%r13
  66c149:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
  66c150:	00 
  66c151:	48 8d 0d 78 01 11 00 	lea    0x110178(%rip),%rcx        # 77c2d0 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x40>
  66c158:	e9 9b fc ff ff       	jmp    66bdf8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3258>
  66c15d:	48 8d 0d 44 08 11 00 	lea    0x110844(%rip),%rcx        # 77c9a8 <anon.82ba7c80bfefe788d7fd53f5e69bad68.28.llvm.13034477518265263966>
  66c164:	ff 15 86 b1 11 00    	call   *0x11b186(%rip)        # 7872f0 <_DYNAMIC+0x5e8>
  66c16a:	e9 28 01 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66c16f:	48 8d 0d 32 08 11 00 	lea    0x110832(%rip),%rcx        # 77c9a8 <anon.82ba7c80bfefe788d7fd53f5e69bad68.28.llvm.13034477518265263966>
  66c176:	ff 15 74 b1 11 00    	call   *0x11b174(%rip)        # 7872f0 <_DYNAMIC+0x5e8>
  66c17c:	e9 16 01 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66c181:	48 8d 3d f8 13 11 00 	lea    0x1113f8(%rip),%rdi        # 77d580 <anon.6c5084435b11a18255f0e2633167e6a9.26.llvm.16566473696946250863>
  66c188:	ff 15 b2 ae 11 00    	call   *0x11aeb2(%rip)        # 787040 <_DYNAMIC+0x338>
  66c18e:	e9 04 01 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66c193:	4c 8d 05 ae 01 11 00 	lea    0x1101ae(%rip),%r8        # 77c348 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0xb8>
  66c19a:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
  66c1a1:	00 
  66c1a2:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  66c1a7:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  66c1ac:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  66c1b3:	00 
  66c1b4:	ff 15 96 b1 11 00    	call   *0x11b196(%rip)        # 787350 <_DYNAMIC+0x648>
  66c1ba:	e9 d8 00 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66c1bf:	48 8d 05 22 01 11 00 	lea    0x110122(%rip),%rax        # 77c2e8 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x58>
  66c1c6:	eb 1f                	jmp    66c1e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3647>
  66c1c8:	48 39 d3             	cmp    %rdx,%rbx
  66c1cb:	48 0f 47 d3          	cmova  %rbx,%rdx
  66c1cf:	48 8d 05 02 03 11 00 	lea    0x110302(%rip),%rax        # 77c4d8 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x248>
  66c1d6:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  66c1db:	48 89 d7             	mov    %rdx,%rdi
  66c1de:	eb 0c                	jmp    66c1ec <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x364c>
  66c1e0:	48 8d 05 c1 01 11 00 	lea    0x1101c1(%rip),%rax        # 77c3a8 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x118>
  66c1e7:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  66c1ec:	48 8b b4 24 d8 01 00 	mov    0x1d8(%rsp),%rsi
  66c1f3:	00 
  66c1f4:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  66c1f9:	ff 15 69 ae 11 00    	call   *0x11ae69(%rip)        # 787068 <_DYNAMIC+0x360>
  66c1ff:	e9 93 00 00 00       	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66c204:	48 8d 0d 8d 08 11 00 	lea    0x11088d(%rip),%rcx        # 77ca98 <anon.82ba7c80bfefe788d7fd53f5e69bad68.44.llvm.13034477518265263966>
  66c20b:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
  66c212:	00 
  66c213:	eb 04                	jmp    66c219 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3679>
  66c215:	31 ff                	xor    %edi,%edi
  66c217:	31 c0                	xor    %eax,%eax
  66c219:	48 89 c6             	mov    %rax,%rsi
  66c21c:	48 8b 94 24 58 02 00 	mov    0x258(%rsp),%rdx
  66c223:	00 
  66c224:	ff 15 3e ae 11 00    	call   *0x11ae3e(%rip)        # 787068 <_DYNAMIC+0x360>
  66c22a:	eb 6b                	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66c22c:	31 ff                	xor    %edi,%edi
  66c22e:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
  66c235:	00 00 00 00 00 
  66c23a:	eb b0                	jmp    66c1ec <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x364c>
  66c23c:	48 8d 15 a5 14 11 00 	lea    0x1114a5(%rip),%rdx        # 77d6e8 <anon.6c5084435b11a18255f0e2633167e6a9.43.llvm.16566473696946250863>
  66c243:	ff 15 1f ae 11 00    	call   *0x11ae1f(%rip)        # 787068 <_DYNAMIC+0x360>
  66c249:	eb 4c                	jmp    66c297 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x36f7>
  66c24b:	48 8d 05 6e 02 11 00 	lea    0x11026e(%rip),%rax        # 77c4c0 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x230>
  66c252:	eb 93                	jmp    66c1e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3647>
  66c254:	48 89 d7             	mov    %rdx,%rdi
  66c257:	48 8d 05 92 02 11 00 	lea    0x110292(%rip),%rax        # 77c4f0 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x260>
  66c25e:	eb 87                	jmp    66c1e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3647>
  66c260:	48 8d 05 29 01 11 00 	lea    0x110129(%rip),%rax        # 77c390 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x100>
  66c267:	e9 7b ff ff ff       	jmp    66c1e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3647>
  66c26c:	48 8d 05 4d 01 11 00 	lea    0x11014d(%rip),%rax        # 77c3c0 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x130>
  66c273:	e9 6f ff ff ff       	jmp    66c1e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3647>
  66c278:	48 89 d7             	mov    %rdx,%rdi
  66c27b:	48 8d 05 56 01 11 00 	lea    0x110156(%rip),%rax        # 77c3d8 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x148>
  66c282:	e9 60 ff ff ff       	jmp    66c1e7 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3647>
  66c287:	48 8d 15 0a 08 11 00 	lea    0x11080a(%rip),%rdx        # 77ca98 <anon.82ba7c80bfefe788d7fd53f5e69bad68.44.llvm.13034477518265263966>
  66c28e:	48 89 c6             	mov    %rax,%rsi
  66c291:	ff 15 d1 ad 11 00    	call   *0x11add1(%rip)        # 787068 <_DYNAMIC+0x360>
  66c297:	0f 0b                	ud2
  66c299:	49 89 c6             	mov    %rax,%r14
  66c29c:	be 18 00 00 00       	mov    $0x18,%esi
  66c2a1:	ba 04 00 00 00       	mov    $0x4,%edx
  66c2a6:	4c 89 ff             	mov    %r15,%rdi
  66c2a9:	ff 15 91 ac 11 00    	call   *0x11ac91(%rip)        # 786f40 <_DYNAMIC+0x238>
  66c2af:	e9 d7 02 00 00       	jmp    66c58b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39eb>
  66c2b4:	49 89 c6             	mov    %rax,%r14
  66c2b7:	48 89 df             	mov    %rbx,%rdi
  66c2ba:	e8 71 be ff ff       	call   668130 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCs6tOD1aKRtN9_11gpui_canvas4text6layout12TextGeometryEBH_>
  66c2bf:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  66c2c4:	75 0e                	jne    66c2d4 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3734>
  66c2c6:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  66c2cd:	00 
  66c2ce:	ff 15 84 ac 11 00    	call   *0x11ac84(%rip)        # 786f58 <_DYNAMIC+0x250>
  66c2d4:	31 db                	xor    %ebx,%ebx
  66c2d6:	eb 0b                	jmp    66c2e3 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3743>
  66c2d8:	ff 15 82 ac 11 00    	call   *0x11ac82(%rip)        # 786f60 <_DYNAMIC+0x258>
  66c2de:	49 89 c6             	mov    %rax,%r14
  66c2e1:	b3 01                	mov    $0x1,%bl
  66c2e3:	4d 85 ff             	test   %r15,%r15
  66c2e6:	74 15                	je     66c2fd <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x375d>
  66c2e8:	49 c1 e7 04          	shl    $0x4,%r15
  66c2ec:	ba 04 00 00 00       	mov    $0x4,%edx
  66c2f1:	4c 89 e7             	mov    %r12,%rdi
  66c2f4:	4c 89 fe             	mov    %r15,%rsi
  66c2f7:	ff 15 43 ac 11 00    	call   *0x11ac43(%rip)        # 786f40 <_DYNAMIC+0x238>
  66c2fd:	84 db                	test   %bl,%bl
  66c2ff:	0f 84 cc 02 00 00    	je     66c5d1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3a31>
  66c305:	31 db                	xor    %ebx,%ebx
  66c307:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66c30e:	00 ff 
  66c310:	0f 84 fd 01 00 00    	je     66c513 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3973>
  66c316:	e9 81 02 00 00       	jmp    66c59c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39fc>
  66c31b:	49 89 c6             	mov    %rax,%r14
  66c31e:	4d 89 27             	mov    %r12,(%r15)
  66c321:	4c 89 f7             	mov    %r14,%rdi
  66c324:	e8 e7 eb 10 00       	call   77af10 <_Unwind_Resume@plt>
  66c329:	e9 5a 02 00 00       	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c32e:	e9 55 02 00 00       	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c333:	e9 50 02 00 00       	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c338:	e9 4b 02 00 00       	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c33d:	e9 46 02 00 00       	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c342:	e9 fd 01 00 00       	jmp    66c544 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39a4>
  66c347:	e9 3c 02 00 00       	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c34c:	e9 37 02 00 00       	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c351:	49 89 c6             	mov    %rax,%r14
  66c354:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66c35b:	00 
  66c35c:	e8 5f c8 00 00       	call   678bc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCshQYmODNYIQG_6parley5style13StylePropertyuEECs6tOD1aKRtN9_11gpui_canvas.llvm.3659747509729363938>
  66c361:	e9 25 02 00 00       	jmp    66c58b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39eb>
  66c366:	ff 15 f4 ab 11 00    	call   *0x11abf4(%rip)        # 786f60 <_DYNAMIC+0x258>
  66c36c:	49 89 c6             	mov    %rax,%r14
  66c36f:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66c376:	00 
  66c377:	e8 44 c8 00 00       	call   678bc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCshQYmODNYIQG_6parley5style13StylePropertyuEECs6tOD1aKRtN9_11gpui_canvas.llvm.3659747509729363938>
  66c37c:	e9 0a 02 00 00       	jmp    66c58b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39eb>
  66c381:	ff 15 d9 ab 11 00    	call   *0x11abd9(%rip)        # 786f60 <_DYNAMIC+0x258>
  66c387:	49 89 c6             	mov    %rax,%r14
  66c38a:	49 c7 87 c8 08 00 00 	movq   $0x0,0x8c8(%r15)
  66c391:	00 00 00 00 
  66c395:	49 c7 87 d0 08 00 00 	movq   $0x4,0x8d0(%r15)
  66c39c:	04 00 00 00 
  66c3a0:	0f 57 c0             	xorps  %xmm0,%xmm0
  66c3a3:	41 0f 11 87 d8 08 00 	movups %xmm0,0x8d8(%r15)
  66c3aa:	00 
  66c3ab:	49 c7 87 e8 08 00 00 	movq   $0x4,0x8e8(%r15)
  66c3b2:	04 00 00 00 
  66c3b6:	41 0f 11 87 f0 08 00 	movups %xmm0,0x8f0(%r15)
  66c3bd:	00 
  66c3be:	49 c7 87 00 09 00 00 	movq   $0x8,0x900(%r15)
  66c3c5:	08 00 00 00 
  66c3c9:	41 0f 11 87 08 09 00 	movups %xmm0,0x908(%r15)
  66c3d0:	00 
  66c3d1:	49 c7 87 18 09 00 00 	movq   $0x8,0x918(%r15)
  66c3d8:	08 00 00 00 
  66c3dc:	41 0f 11 87 20 09 00 	movups %xmm0,0x920(%r15)
  66c3e3:	00 
  66c3e4:	49 c7 87 30 09 00 00 	movq   $0x4,0x930(%r15)
  66c3eb:	04 00 00 00 
  66c3ef:	41 0f 11 87 38 09 00 	movups %xmm0,0x938(%r15)
  66c3f6:	00 
  66c3f7:	49 c7 87 48 09 00 00 	movq   $0x4,0x948(%r15)
  66c3fe:	04 00 00 00 
  66c402:	41 0f 11 87 50 09 00 	movups %xmm0,0x950(%r15)
  66c409:	00 
  66c40a:	49 c7 87 60 09 00 00 	movq   $0x4,0x960(%r15)
  66c411:	04 00 00 00 
  66c415:	41 0f 11 87 68 09 00 	movups %xmm0,0x968(%r15)
  66c41c:	00 
  66c41d:	49 c7 87 78 09 00 00 	movq   $0x8,0x978(%r15)
  66c424:	08 00 00 00 
  66c428:	41 0f 11 87 80 09 00 	movups %xmm0,0x980(%r15)
  66c42f:	00 
  66c430:	49 c7 87 90 09 00 00 	movq   $0x2,0x990(%r15)
  66c437:	02 00 00 00 
  66c43b:	41 0f 11 87 98 09 00 	movups %xmm0,0x998(%r15)
  66c442:	00 
  66c443:	49 c7 87 a8 09 00 00 	movq   $0x4,0x9a8(%r15)
  66c44a:	04 00 00 00 
  66c44e:	41 0f 11 87 b0 09 00 	movups %xmm0,0x9b0(%r15)
  66c455:	00 
  66c456:	49 c7 87 c0 09 00 00 	movq   $0x8,0x9c0(%r15)
  66c45d:	08 00 00 00 
  66c461:	41 0f 11 87 c8 09 00 	movups %xmm0,0x9c8(%r15)
  66c468:	00 
  66c469:	49 c7 87 d8 09 00 00 	movq   $0x8,0x9d8(%r15)
  66c470:	08 00 00 00 
  66c474:	41 0f 11 87 e0 09 00 	movups %xmm0,0x9e0(%r15)
  66c47b:	00 
  66c47c:	49 c7 87 f0 09 00 00 	movq   $0x8,0x9f0(%r15)
  66c483:	08 00 00 00 
  66c487:	41 0f 11 87 f8 09 00 	movups %xmm0,0x9f8(%r15)
  66c48e:	00 
  66c48f:	49 c7 87 08 0a 00 00 	movq   $0x4,0xa08(%r15)
  66c496:	04 00 00 00 
  66c49a:	41 0f 11 87 10 0a 00 	movups %xmm0,0xa10(%r15)
  66c4a1:	00 
  66c4a2:	41 c7 87 20 0a 00 00 	movl   $0x3f800000,0xa20(%r15)
  66c4a9:	00 00 80 3f 
  66c4ad:	41 0f 11 87 24 0a 00 	movups %xmm0,0xa24(%r15)
  66c4b4:	00 
  66c4b5:	49 c7 87 32 0a 00 00 	movq   $0x0,0xa32(%r15)
  66c4bc:	00 00 00 00 
  66c4c0:	66 41 c7 87 3a 0a 00 	movw   $0xff01,0xa3a(%r15)
  66c4c7:	00 01 ff 
  66c4ca:	41 c6 87 3c 0a 00 00 	movb   $0x0,0xa3c(%r15)
  66c4d1:	00 
  66c4d2:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  66c4d9:	00 
  66c4da:	e8 41 a5 ff ff       	call   666a20 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6result6ResultNtNtCs6tOD1aKRtN9_11gpui_canvas4text10TextLayoutNtB11_5ErrorEEB11_>
  66c4df:	4c 89 f7             	mov    %r14,%rdi
  66c4e2:	e8 29 ea 10 00       	call   77af10 <_Unwind_Resume@plt>
  66c4e7:	ff 15 73 aa 11 00    	call   *0x11aa73(%rip)        # 786f60 <_DYNAMIC+0x258>
  66c4ed:	e9 96 00 00 00       	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c4f2:	49 89 c6             	mov    %rax,%r14
  66c4f5:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  66c4fc:	00 
  66c4fd:	b3 01                	mov    $0x1,%bl
  66c4ff:	48 85 f6             	test   %rsi,%rsi
  66c502:	75 1c                	jne    66c520 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3980>
  66c504:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66c50b:	00 ff 
  66c50d:	0f 85 89 00 00 00    	jne    66c59c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39fc>
  66c513:	84 db                	test   %bl,%bl
  66c515:	0f 85 92 00 00 00    	jne    66c5ad <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3a0d>
  66c51b:	e9 b1 00 00 00       	jmp    66c5d1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3a31>
  66c520:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  66c527:	00 
  66c528:	48 c1 e6 03          	shl    $0x3,%rsi
  66c52c:	ba 08 00 00 00       	mov    $0x8,%edx
  66c531:	ff 15 09 aa 11 00    	call   *0x11aa09(%rip)        # 786f40 <_DYNAMIC+0x238>
  66c537:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66c53e:	00 ff 
  66c540:	74 d1                	je     66c513 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3973>
  66c542:	eb 58                	jmp    66c59c <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39fc>
  66c544:	49 89 c6             	mov    %rax,%r14
  66c547:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  66c54e:	00 
  66c54f:	48 85 f6             	test   %rsi,%rsi
  66c552:	74 17                	je     66c56b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39cb>
  66c554:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  66c55b:	00 
  66c55c:	48 c1 e6 03          	shl    $0x3,%rsi
  66c560:	ba 08 00 00 00       	mov    $0x8,%edx
  66c565:	ff 15 d5 a9 11 00    	call   *0x11a9d5(%rip)        # 786f40 <_DYNAMIC+0x238>
  66c56b:	48 8d bc 24 90 02 00 	lea    0x290(%rsp),%rdi
  66c572:	00 
  66c573:	e8 a8 a3 ff ff       	call   666920 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtNtCshQYmODNYIQG_6parley7editing8geometry14CursorGeometryuEEECs6tOD1aKRtN9_11gpui_canvas>
  66c578:	eb 11                	jmp    66c58b <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39eb>
  66c57a:	eb 0c                	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c57c:	eb 0a                	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c57e:	eb 08                	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c580:	eb 06                	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c582:	eb 04                	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c584:	eb 02                	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c586:	eb 00                	jmp    66c588 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x39e8>
  66c588:	49 89 c6             	mov    %rax,%r14
  66c58b:	b3 01                	mov    $0x1,%bl
  66c58d:	48 83 bc 24 40 01 00 	cmpq   $0xffffffffffffffff,0x140(%rsp)
  66c594:	00 ff 
  66c596:	0f 84 77 ff ff ff    	je     66c513 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3973>
  66c59c:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
  66c5a3:	00 
  66c5a4:	e8 87 bb ff ff       	call   668130 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCs6tOD1aKRtN9_11gpui_canvas4text6layout12TextGeometryEBH_>
  66c5a9:	84 db                	test   %bl,%bl
  66c5ab:	74 24                	je     66c5d1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3a31>
  66c5ad:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  66c5b4:	00 
  66c5b5:	48 85 f6             	test   %rsi,%rsi
  66c5b8:	74 17                	je     66c5d1 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x3a31>
  66c5ba:	48 8b bc 24 00 01 00 	mov    0x100(%rsp),%rdi
  66c5c1:	00 
  66c5c2:	48 c1 e6 04          	shl    $0x4,%rsi
  66c5c6:	ba 04 00 00 00       	mov    $0x4,%edx
  66c5cb:	ff 15 6f a9 11 00    	call   *0x11a96f(%rip)        # 786f40 <_DYNAMIC+0x238>
  66c5d1:	48 8d bc 24 e8 02 00 	lea    0x2e8(%rsp),%rdi
  66c5d8:	00 
  66c5d9:	e8 e2 a2 ff ff       	call   6668c0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueANtNtCs2D57TIA91Kp_8parlance11font_family14FontFamilyNamej3_ECs6tOD1aKRtN9_11gpui_canvas>
  66c5de:	4c 89 f7             	mov    %r14,%rdi
  66c5e1:	e8 2a e9 10 00       	call   77af10 <_Unwind_Resume@plt>
