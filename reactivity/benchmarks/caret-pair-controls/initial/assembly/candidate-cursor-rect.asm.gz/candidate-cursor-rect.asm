
/tmp/gpui-caret-pair-controls-v2/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006729e0 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas>:
  6729e0:	41 56                	push   %r14
  6729e2:	53                   	push   %rbx
  6729e3:	48 83 ec 38          	sub    $0x38,%rsp
  6729e7:	49 89 f6             	mov    %rsi,%r14
  6729ea:	48 89 fb             	mov    %rdi,%rbx
  6729ed:	85 d2                	test   %edx,%edx
  6729ef:	0f 84 8f 00 00 00    	je     672a84 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0xa4>
  6729f5:	49 83 7e 18 00       	cmpq   $0x0,0x18(%r14)
  6729fa:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  6729ff:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  672a04:	74 2e                	je     672a34 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0x54>
  672a06:	49 8b 06             	mov    (%r14),%rax
  672a09:	41 8b 7e 20          	mov    0x20(%r14),%edi
  672a0d:	48 8b b0 18 01 00 00 	mov    0x118(%rax),%rsi
  672a14:	48 39 fe             	cmp    %rdi,%rsi
  672a17:	0f 86 ee 00 00 00    	jbe    672b0b <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0x12b>
  672a1d:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  672a24:	48 6b cf 70          	imul   $0x70,%rdi,%rcx
  672a28:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  672a2e:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  672a32:	eb 08                	jmp    672a3c <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0x5c>
  672a34:	0f 57 c0             	xorps  %xmm0,%xmm0
  672a37:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  672a3c:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  672a40:	f2 0f 10 49 44       	movsd  0x44(%rcx),%xmm1
  672a45:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
  672a4a:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  672a50:	89 44 24 0c          	mov    %eax,0xc(%rsp)
  672a54:	49 8d 76 30          	lea    0x30(%r14),%rsi
  672a58:	49 8d 96 80 00 00 00 	lea    0x80(%r14),%rdx
  672a5f:	49 8b 46 08          	mov    0x8(%r14),%rax
  672a63:	0f b6 88 8c 00 00 00 	movzbl 0x8c(%rax),%ecx
  672a6a:	83 e1 01             	and    $0x1,%ecx
  672a6d:	48 89 e7             	mov    %rsp,%rdi
  672a70:	ff 15 22 4a 11 00    	call   *0x114a22(%rip)        # 787498 <_DYNAMIC+0x790>
  672a76:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  672a7b:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  672a7f:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  672a84:	49 8b 06             	mov    (%r14),%rax
  672a87:	41 8b 4e 20          	mov    0x20(%r14),%ecx
  672a8b:	48 39 88 18 01 00 00 	cmp    %rcx,0x118(%rax)
  672a92:	76 6a                	jbe    672afe <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0x11e>
  672a94:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  672a9b:	48 6b c9 70          	imul   $0x70,%rcx,%rcx
  672a9f:	f3 0f 10 64 08 40    	movss  0x40(%rax,%rcx,1),%xmm4
  672aa5:	f3 0f 10 6c 08 44    	movss  0x44(%rax,%rcx,1),%xmm5
  672aab:	0f 28 d4             	movaps %xmm4,%xmm2
  672aae:	f3 0f 5d 54 08 48    	minss  0x48(%rax,%rcx,1),%xmm2
  672ab4:	0f 28 da             	movaps %xmm2,%xmm3
  672ab7:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  672abc:	0f 54 e3             	andps  %xmm3,%xmm4
  672abf:	0f 55 da             	andnps %xmm2,%xmm3
  672ac2:	0f 56 dc             	orps   %xmm4,%xmm3
  672ac5:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  672ac9:	0f 28 e5             	movaps %xmm5,%xmm4
  672acc:	f3 0f 5f 64 08 4c    	maxss  0x4c(%rax,%rcx,1),%xmm4
  672ad2:	0f 28 d4             	movaps %xmm4,%xmm2
  672ad5:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  672ada:	0f 54 ea             	andps  %xmm2,%xmm5
  672add:	0f 55 d4             	andnps %xmm4,%xmm2
  672ae0:	0f 56 d5             	orps   %xmm5,%xmm2
  672ae3:	0f 14 cb             	unpcklps %xmm3,%xmm1
  672ae6:	0f 5a c9             	cvtps2pd %xmm1,%xmm1
  672ae9:	0f 11 0b             	movups %xmm1,(%rbx)
  672aec:	0f 14 c2             	unpcklps %xmm2,%xmm0
  672aef:	0f 5a c0             	cvtps2pd %xmm0,%xmm0
  672af2:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  672af6:	48 83 c4 38          	add    $0x38,%rsp
  672afa:	5b                   	pop    %rbx
  672afb:	41 5e                	pop    %r14
  672afd:	c3                   	ret
  672afe:	48 8d 3d eb 9e 10 00 	lea    0x109eeb(%rip),%rdi        # 77c9f0 <anon.82ba7c80bfefe788d7fd53f5e69bad68.32.llvm.13034477518265263966+0x18>
  672b05:	ff 15 35 45 11 00    	call   *0x114535(%rip)        # 787040 <_DYNAMIC+0x338>
  672b0b:	48 8d 15 be 9d 10 00 	lea    0x109dbe(%rip),%rdx        # 77c8d0 <anon.82ba7c80bfefe788d7fd53f5e69bad68.9.llvm.13034477518265263966+0x18>
  672b12:	ff 15 50 45 11 00    	call   *0x114550(%rip)        # 787068 <_DYNAMIC+0x360>
