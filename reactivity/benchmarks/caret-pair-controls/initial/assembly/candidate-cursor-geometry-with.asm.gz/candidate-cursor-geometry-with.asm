
/tmp/gpui-caret-pair-controls-v2/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000672310 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas>:
  672310:	55                   	push   %rbp
  672311:	41 57                	push   %r15
  672313:	41 56                	push   %r14
  672315:	41 55                	push   %r13
  672317:	41 54                	push   %r12
  672319:	53                   	push   %rbx
  67231a:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
  672321:	49 89 cf             	mov    %rcx,%r15
  672324:	0f 29 04 24          	movaps %xmm0,(%rsp)
  672328:	49 89 d6             	mov    %rdx,%r14
  67232b:	48 89 fb             	mov    %rdi,%rbx
  67232e:	4c 8b a1 90 00 00 00 	mov    0x90(%rcx),%r12
  672335:	4d 85 e4             	test   %r12,%r12
  672338:	0f 94 c0             	sete   %al
  67233b:	0a 46 08             	or     0x8(%rsi),%al
  67233e:	4c 8b 29             	mov    (%rcx),%r13
  672341:	4d 85 ed             	test   %r13,%r13
  672344:	0f 95 c1             	setne  %cl
  672347:	84 c8                	test   %cl,%al
  672349:	74 68                	je     6723b3 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0xa3>
  67234b:	49 8d 77 08          	lea    0x8(%r15),%rsi
  67234f:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  672354:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  672359:	ba 88 00 00 00       	mov    $0x88,%edx
  67235e:	ff 15 74 4c 11 00    	call   *0x114c74(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  672364:	8b 7c 24 40          	mov    0x40(%rsp),%edi
  672368:	49 8b 75 58          	mov    0x58(%r13),%rsi
  67236c:	48 39 fe             	cmp    %rdi,%rsi
  67236f:	0f 86 66 01 00 00    	jbe    6724db <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1cb>
  672375:	49 8b 55 70          	mov    0x70(%r13),%rdx
  672379:	8b bc 24 98 00 00 00 	mov    0x98(%rsp),%edi
  672380:	8b b4 24 9c 00 00 00 	mov    0x9c(%rsp),%esi
  672387:	39 fe                	cmp    %edi,%esi
  672389:	0f 82 3f 01 00 00    	jb     6724ce <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1be>
  67238f:	48 39 f2             	cmp    %rsi,%rdx
  672392:	0f 82 36 01 00 00    	jb     6724ce <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1be>
  672398:	39 fe                	cmp    %edi,%esi
  67239a:	0f 84 48 01 00 00    	je     6724e8 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1d8>
  6723a0:	49 8b 45 68          	mov    0x68(%r13),%rax
  6723a4:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  6723a8:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  6723ad:	0f 85 d3 00 00 00    	jne    672486 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x176>
  6723b3:	4d 85 e4             	test   %r12,%r12
  6723b6:	74 43                	je     6723fb <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0xeb>
  6723b8:	49 81 c7 98 00 00 00 	add    $0x98,%r15
  6723bf:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  6723c4:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6723c9:	ba 88 00 00 00       	mov    $0x88,%edx
  6723ce:	4c 89 fe             	mov    %r15,%rsi
  6723d1:	ff 15 01 4c 11 00    	call   *0x114c01(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  6723d7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6723dc:	0f b6 a8 8c 00 00 00 	movzbl 0x8c(%rax),%ebp
  6723e3:	4c 8d 74 24 18       	lea    0x18(%rsp),%r14
  6723e8:	4c 89 f7             	mov    %r14,%rdi
  6723eb:	e8 30 07 00 00       	call   672b20 <_RNCINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB5_6Cursor8geometryuE0Cs6tOD1aKRtN9_11gpui_canvas>
  6723f0:	0f 28 c8             	movaps %xmm0,%xmm1
  6723f3:	83 e5 01             	and    $0x1,%ebp
  6723f6:	e9 ad 00 00 00       	jmp    6724a8 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x198>
  6723fb:	49 8b 8e 18 01 00 00 	mov    0x118(%r14),%rcx
  672402:	48 83 f9 01          	cmp    $0x1,%rcx
  672406:	48 89 c8             	mov    %rcx,%rax
  672409:	48 83 d0 ff          	adc    $0xffffffffffffffff,%rax
  67240d:	0f 57 c0             	xorps  %xmm0,%xmm0
  672410:	0f 57 c9             	xorps  %xmm1,%xmm1
  672413:	48 39 c8             	cmp    %rcx,%rax
  672416:	73 65                	jae    67247d <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x16d>
  672418:	49 8b 8e 10 01 00 00 	mov    0x110(%r14),%rcx
  67241f:	48 6b c0 70          	imul   $0x70,%rax,%rax
  672423:	f3 0f 10 44 01 28    	movss  0x28(%rcx,%rax,1),%xmm0
  672429:	f3 0f 10 4c 01 40    	movss  0x40(%rcx,%rax,1),%xmm1
  67242f:	0f 28 d1             	movaps %xmm1,%xmm2
  672432:	f3 0f 5d 54 01 48    	minss  0x48(%rcx,%rax,1),%xmm2
  672438:	0f 28 da             	movaps %xmm2,%xmm3
  67243b:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  672440:	0f 54 cb             	andps  %xmm3,%xmm1
  672443:	0f 55 da             	andnps %xmm2,%xmm3
  672446:	0f 56 d9             	orps   %xmm1,%xmm3
  672449:	0f 28 24 24          	movaps (%rsp),%xmm4
  67244d:	f3 0f 58 e0          	addss  %xmm0,%xmm4
  672451:	0f 14 c3             	unpcklps %xmm3,%xmm0
  672454:	0f 5a c0             	cvtps2pd %xmm0,%xmm0
  672457:	f3 0f 10 4c 01 44    	movss  0x44(%rcx,%rax,1),%xmm1
  67245d:	0f 28 d1             	movaps %xmm1,%xmm2
  672460:	f3 0f 5f 54 01 4c    	maxss  0x4c(%rcx,%rax,1),%xmm2
  672466:	0f 28 da             	movaps %xmm2,%xmm3
  672469:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  67246e:	0f 54 cb             	andps  %xmm3,%xmm1
  672471:	0f 55 da             	andnps %xmm2,%xmm3
  672474:	0f 56 d9             	orps   %xmm1,%xmm3
  672477:	0f 14 e3             	unpcklps %xmm3,%xmm4
  67247a:	0f 5a cc             	cvtps2pd %xmm4,%xmm1
  67247d:	0f 11 03             	movups %xmm0,(%rbx)
  672480:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  672484:	eb 33                	jmp    6724b9 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1a9>
  672486:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  67248b:	31 ed                	xor    %ebp,%ebp
  67248d:	f6 80 8c 00 00 00 01 	testb  $0x1,0x8c(%rax)
  672494:	40 0f 94 c5          	sete   %bpl
  672498:	4c 8d 74 24 18       	lea    0x18(%rsp),%r14
  67249d:	4c 89 f7             	mov    %r14,%rdi
  6724a0:	e8 7b 06 00 00       	call   672b20 <_RNCINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB5_6Cursor8geometryuE0Cs6tOD1aKRtN9_11gpui_canvas>
  6724a5:	0f 28 c8             	movaps %xmm0,%xmm1
  6724a8:	48 89 df             	mov    %rbx,%rdi
  6724ab:	4c 89 f6             	mov    %r14,%rsi
  6724ae:	89 ea                	mov    %ebp,%edx
  6724b0:	0f 28 04 24          	movaps (%rsp),%xmm0
  6724b4:	e8 27 05 00 00       	call   6729e0 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas>
  6724b9:	48 89 d8             	mov    %rbx,%rax
  6724bc:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
  6724c3:	5b                   	pop    %rbx
  6724c4:	41 5c                	pop    %r12
  6724c6:	41 5d                	pop    %r13
  6724c8:	41 5e                	pop    %r14
  6724ca:	41 5f                	pop    %r15
  6724cc:	5d                   	pop    %rbp
  6724cd:	c3                   	ret
  6724ce:	48 8d 0d 03 a5 10 00 	lea    0x10a503(%rip),%rcx        # 77c9d8 <anon.82ba7c80bfefe788d7fd53f5e69bad68.32.llvm.13034477518265263966>
  6724d5:	ff 15 15 4e 11 00    	call   *0x114e15(%rip)        # 7872f0 <_DYNAMIC+0x5e8>
  6724db:	48 8d 15 b6 a5 10 00 	lea    0x10a5b6(%rip),%rdx        # 77ca98 <anon.82ba7c80bfefe788d7fd53f5e69bad68.44.llvm.13034477518265263966>
  6724e2:	ff 15 80 4b 11 00    	call   *0x114b80(%rip)        # 787068 <_DYNAMIC+0x360>
  6724e8:	48 8d 15 d1 a4 10 00 	lea    0x10a4d1(%rip),%rdx        # 77c9c0 <anon.82ba7c80bfefe788d7fd53f5e69bad68.30.llvm.13034477518265263966>
  6724ef:	31 ff                	xor    %edi,%edi
  6724f1:	31 f6                	xor    %esi,%esi
  6724f3:	ff 15 6f 4b 11 00    	call   *0x114b6f(%rip)        # 787068 <_DYNAMIC+0x360>
