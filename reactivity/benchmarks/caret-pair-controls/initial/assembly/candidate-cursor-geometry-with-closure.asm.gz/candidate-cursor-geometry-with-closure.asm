
/tmp/gpui-caret-pair-controls-v2/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000672500 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas>:
  672500:	55                   	push   %rbp
  672501:	41 57                	push   %r15
  672503:	41 56                	push   %r14
  672505:	41 55                	push   %r13
  672507:	41 54                	push   %r12
  672509:	53                   	push   %rbx
  67250a:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
  672511:	4d 89 ce             	mov    %r9,%r14
  672514:	4d 89 c4             	mov    %r8,%r12
  672517:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  67251c:	49 89 cd             	mov    %rcx,%r13
  67251f:	49 89 d7             	mov    %rdx,%r15
  672522:	49 8b 18             	mov    (%r8),%rbx
  672525:	49 8b a8 90 00 00 00 	mov    0x90(%r8),%rbp
  67252c:	48 85 ed             	test   %rbp,%rbp
  67252f:	0f 94 c0             	sete   %al
  672532:	40 08 f0             	or     %sil,%al
  672535:	48 85 db             	test   %rbx,%rbx
  672538:	0f 95 c1             	setne  %cl
  67253b:	84 c8                	test   %cl,%al
  67253d:	74 77                	je     6725b6 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0xb6>
  67253f:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  672544:	49 8d 74 24 08       	lea    0x8(%r12),%rsi
  672549:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
  67254e:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  672553:	ba 88 00 00 00       	mov    $0x88,%edx
  672558:	ff 15 7a 4a 11 00    	call   *0x114a7a(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  67255e:	8b bc 24 80 00 00 00 	mov    0x80(%rsp),%edi
  672565:	48 8b 73 58          	mov    0x58(%rbx),%rsi
  672569:	48 39 fe             	cmp    %rdi,%rsi
  67256c:	0f 86 63 02 00 00    	jbe    6727d5 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2d5>
  672572:	48 8b 43 70          	mov    0x70(%rbx),%rax
  672576:	8b b4 24 d8 00 00 00 	mov    0xd8(%rsp),%esi
  67257d:	8b 94 24 dc 00 00 00 	mov    0xdc(%rsp),%edx
  672584:	39 f2                	cmp    %esi,%edx
  672586:	0f 82 33 02 00 00    	jb     6727bf <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2bf>
  67258c:	48 39 d0             	cmp    %rdx,%rax
  67258f:	0f 82 2a 02 00 00    	jb     6727bf <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2bf>
  672595:	39 f2                	cmp    %esi,%edx
  672597:	0f 84 62 02 00 00    	je     6727ff <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2ff>
  67259d:	48 8b 4b 68          	mov    0x68(%rbx),%rcx
  6725a1:	4c 8d 04 76          	lea    (%rsi,%rsi,2),%r8
  6725a5:	42 80 7c 81 07 06    	cmpb   $0x6,0x7(%rcx,%r8,4)
  6725ab:	0f 85 68 01 00 00    	jne    672719 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x219>
  6725b1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6725b6:	48 85 ed             	test   %rbp,%rbp
  6725b9:	0f 84 d4 00 00 00    	je     672693 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x193>
  6725bf:	49 89 ff             	mov    %rdi,%r15
  6725c2:	49 81 c4 98 00 00 00 	add    $0x98,%r12
  6725c9:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6725ce:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6725d3:	ba 88 00 00 00       	mov    $0x88,%edx
  6725d8:	4c 89 e6             	mov    %r12,%rsi
  6725db:	ff 15 f7 49 11 00    	call   *0x1149f7(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  6725e1:	8b bc 24 80 00 00 00 	mov    0x80(%rsp),%edi
  6725e8:	48 8b 75 58          	mov    0x58(%rbp),%rsi
  6725ec:	48 39 fe             	cmp    %rdi,%rsi
  6725ef:	0f 86 e0 01 00 00    	jbe    6727d5 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2d5>
  6725f5:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6725fa:	0f b6 98 8c 00 00 00 	movzbl 0x8c(%rax),%ebx
  672601:	48 8b 45 50          	mov    0x50(%rbp),%rax
  672605:	48 8d 0c ff          	lea    (%rdi,%rdi,8),%rcx
  672609:	48 c1 e1 04          	shl    $0x4,%rcx
  67260d:	0f 10 45 68          	movups 0x68(%rbp),%xmm0
  672611:	0f 10 8d 80 00 00 00 	movups 0x80(%rbp),%xmm1
  672618:	0f 10 95 98 00 00 00 	movups 0x98(%rbp),%xmm2
  67261f:	0f 11 44 24 20       	movups %xmm0,0x20(%rsp)
  672624:	0f 11 4c 24 30       	movups %xmm1,0x30(%rsp)
  672629:	0f 11 54 24 40       	movups %xmm2,0x40(%rsp)
  67262e:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  672633:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  672638:	8b b4 24 d8 00 00 00 	mov    0xd8(%rsp),%esi
  67263f:	8b 94 24 dc 00 00 00 	mov    0xdc(%rsp),%edx
  672646:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  67264b:	ff 15 d7 4c 11 00    	call   *0x114cd7(%rip)        # 787328 <_DYNAMIC+0x620>
  672651:	49 8b 76 28          	mov    0x28(%r14),%rsi
  672655:	48 39 f0             	cmp    %rsi,%rax
  672658:	0f 83 84 01 00 00    	jae    6727e2 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2e2>
  67265e:	49 8b 76 10          	mov    0x10(%r14),%rsi
  672662:	49 8b 4e 20          	mov    0x20(%r14),%rcx
  672666:	8b 3c 81             	mov    (%rcx,%rax,4),%edi
  672669:	48 39 fe             	cmp    %rdi,%rsi
  67266c:	0f 86 80 01 00 00    	jbe    6727f2 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2f2>
  672672:	49 8b 46 08          	mov    0x8(%r14),%rax
  672676:	48 c1 e7 04          	shl    $0x4,%rdi
  67267a:	f3 0f 10 4c 38 0c    	movss  0xc(%rax,%rdi,1),%xmm1
  672680:	80 e3 01             	and    $0x1,%bl
  672683:	0f b6 d3             	movzbl %bl,%edx
  672686:	48 8d 74 24 58       	lea    0x58(%rsp),%rsi
  67268b:	4c 89 ff             	mov    %r15,%rdi
  67268e:	e9 10 01 00 00       	jmp    6727a3 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2a3>
  672693:	49 83 fd 01          	cmp    $0x1,%r13
  672697:	4c 89 e8             	mov    %r13,%rax
  67269a:	48 83 d0 ff          	adc    $0xffffffffffffffff,%rax
  67269e:	0f 57 c0             	xorps  %xmm0,%xmm0
  6726a1:	0f 57 c9             	xorps  %xmm1,%xmm1
  6726a4:	4c 39 e8             	cmp    %r13,%rax
  6726a7:	73 64                	jae    67270d <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x20d>
  6726a9:	48 6b c0 70          	imul   $0x70,%rax,%rax
  6726ad:	f3 41 0f 10 44 07 28 	movss  0x28(%r15,%rax,1),%xmm0
  6726b4:	f3 41 0f 10 4c 07 40 	movss  0x40(%r15,%rax,1),%xmm1
  6726bb:	0f 28 d1             	movaps %xmm1,%xmm2
  6726be:	f3 41 0f 5d 54 07 48 	minss  0x48(%r15,%rax,1),%xmm2
  6726c5:	0f 28 da             	movaps %xmm2,%xmm3
  6726c8:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  6726cd:	0f 54 cb             	andps  %xmm3,%xmm1
  6726d0:	0f 55 da             	andnps %xmm2,%xmm3
  6726d3:	0f 56 d9             	orps   %xmm1,%xmm3
  6726d6:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
  6726db:	f3 0f 58 e0          	addss  %xmm0,%xmm4
  6726df:	0f 14 c3             	unpcklps %xmm3,%xmm0
  6726e2:	0f 5a c0             	cvtps2pd %xmm0,%xmm0
  6726e5:	f3 41 0f 10 4c 07 44 	movss  0x44(%r15,%rax,1),%xmm1
  6726ec:	0f 28 d1             	movaps %xmm1,%xmm2
  6726ef:	f3 41 0f 5f 54 07 4c 	maxss  0x4c(%r15,%rax,1),%xmm2
  6726f6:	0f 28 da             	movaps %xmm2,%xmm3
  6726f9:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  6726fe:	0f 54 cb             	andps  %xmm3,%xmm1
  672701:	0f 55 da             	andnps %xmm2,%xmm3
  672704:	0f 56 d9             	orps   %xmm1,%xmm3
  672707:	0f 14 e3             	unpcklps %xmm3,%xmm4
  67270a:	0f 5a cc             	cvtps2pd %xmm4,%xmm1
  67270d:	0f 11 07             	movups %xmm0,(%rdi)
  672710:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  672714:	e9 94 00 00 00       	jmp    6727ad <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2ad>
  672719:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  67271e:	41 0f b6 a8 8c 00 00 	movzbl 0x8c(%r8),%ebp
  672725:	00 
  672726:	4c 8b 43 50          	mov    0x50(%rbx),%r8
  67272a:	48 8d 3c ff          	lea    (%rdi,%rdi,8),%rdi
  67272e:	48 c1 e7 04          	shl    $0x4,%rdi
  672732:	0f 10 83 80 00 00 00 	movups 0x80(%rbx),%xmm0
  672739:	0f 10 8b 98 00 00 00 	movups 0x98(%rbx),%xmm1
  672740:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  672745:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  67274a:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
  67274f:	0f 11 4c 24 40       	movups %xmm1,0x40(%rsp)
  672754:	49 8b 44 38 50       	mov    0x50(%r8,%rdi,1),%rax
  672759:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  67275e:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  672763:	ff 15 bf 4b 11 00    	call   *0x114bbf(%rip)        # 787328 <_DYNAMIC+0x620>
  672769:	49 8b 76 28          	mov    0x28(%r14),%rsi
  67276d:	48 39 f0             	cmp    %rsi,%rax
  672770:	73 70                	jae    6727e2 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2e2>
  672772:	49 8b 76 10          	mov    0x10(%r14),%rsi
  672776:	49 8b 4e 20          	mov    0x20(%r14),%rcx
  67277a:	8b 3c 81             	mov    (%rcx,%rax,4),%edi
  67277d:	48 39 fe             	cmp    %rdi,%rsi
  672780:	76 70                	jbe    6727f2 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas+0x2f2>
  672782:	49 8b 46 08          	mov    0x8(%r14),%rax
  672786:	48 c1 e7 04          	shl    $0x4,%rdi
  67278a:	f3 0f 10 4c 38 0c    	movss  0xc(%rax,%rdi,1),%xmm1
  672790:	31 d2                	xor    %edx,%edx
  672792:	40 f6 c5 01          	test   $0x1,%bpl
  672796:	0f 94 c2             	sete   %dl
  672799:	48 8d 74 24 58       	lea    0x58(%rsp),%rsi
  67279e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6727a3:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  6727a8:	e8 33 02 00 00       	call   6729e0 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas>
  6727ad:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
  6727b4:	5b                   	pop    %rbx
  6727b5:	41 5c                	pop    %r12
  6727b7:	41 5d                	pop    %r13
  6727b9:	41 5e                	pop    %r14
  6727bb:	41 5f                	pop    %r15
  6727bd:	5d                   	pop    %rbp
  6727be:	c3                   	ret
  6727bf:	48 8d 0d 12 a2 10 00 	lea    0x10a212(%rip),%rcx        # 77c9d8 <anon.82ba7c80bfefe788d7fd53f5e69bad68.32.llvm.13034477518265263966>
  6727c6:	48 89 f7             	mov    %rsi,%rdi
  6727c9:	48 89 d6             	mov    %rdx,%rsi
  6727cc:	48 89 c2             	mov    %rax,%rdx
  6727cf:	ff 15 1b 4b 11 00    	call   *0x114b1b(%rip)        # 7872f0 <_DYNAMIC+0x5e8>
  6727d5:	48 8d 15 bc a2 10 00 	lea    0x10a2bc(%rip),%rdx        # 77ca98 <anon.82ba7c80bfefe788d7fd53f5e69bad68.44.llvm.13034477518265263966>
  6727dc:	ff 15 86 48 11 00    	call   *0x114886(%rip)        # 787068 <_DYNAMIC+0x360>
  6727e2:	48 8d 15 ff a0 10 00 	lea    0x10a0ff(%rip),%rdx        # 77c8e8 <anon.82ba7c80bfefe788d7fd53f5e69bad68.9.llvm.13034477518265263966+0x30>
  6727e9:	48 89 c7             	mov    %rax,%rdi
  6727ec:	ff 15 76 48 11 00    	call   *0x114876(%rip)        # 787068 <_DYNAMIC+0x360>
  6727f2:	48 8d 15 07 a1 10 00 	lea    0x10a107(%rip),%rdx        # 77c900 <anon.82ba7c80bfefe788d7fd53f5e69bad68.9.llvm.13034477518265263966+0x48>
  6727f9:	ff 15 69 48 11 00    	call   *0x114869(%rip)        # 787068 <_DYNAMIC+0x360>
  6727ff:	48 8d 15 ba a1 10 00 	lea    0x10a1ba(%rip),%rdx        # 77c9c0 <anon.82ba7c80bfefe788d7fd53f5e69bad68.30.llvm.13034477518265263966>
  672806:	31 ff                	xor    %edi,%edi
  672808:	31 f6                	xor    %esi,%esi
  67280a:	ff 15 58 48 11 00    	call   *0x114858(%rip)        # 787068 <_DYNAMIC+0x360>
