
/tmp/gpui-caret-pair-controls-v2/baseline:     file format elf64-x86-64


Disassembly of section .text:

00000000006778e0 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas>:
  6778e0:	55                   	push   %rbp
  6778e1:	41 57                	push   %r15
  6778e3:	41 56                	push   %r14
  6778e5:	41 55                	push   %r13
  6778e7:	41 54                	push   %r12
  6778e9:	53                   	push   %rbx
  6778ea:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
  6778f1:	49 89 cf             	mov    %rcx,%r15
  6778f4:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6778f8:	49 89 d6             	mov    %rdx,%r14
  6778fb:	48 89 fb             	mov    %rdi,%rbx
  6778fe:	4c 8b a1 90 00 00 00 	mov    0x90(%rcx),%r12
  677905:	4d 85 e4             	test   %r12,%r12
  677908:	0f 94 c0             	sete   %al
  67790b:	0a 46 08             	or     0x8(%rsi),%al
  67790e:	4c 8b 29             	mov    (%rcx),%r13
  677911:	4d 85 ed             	test   %r13,%r13
  677914:	0f 95 c1             	setne  %cl
  677917:	84 c8                	test   %cl,%al
  677919:	74 68                	je     677983 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0xa3>
  67791b:	49 8d 77 08          	lea    0x8(%r15),%rsi
  67791f:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  677924:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  677929:	ba 88 00 00 00       	mov    $0x88,%edx
  67792e:	ff 15 c4 ee 10 00    	call   *0x10eec4(%rip)        # 7867f8 <memcpy@GLIBC_2.14>
  677934:	8b 7c 24 40          	mov    0x40(%rsp),%edi
  677938:	49 8b 75 58          	mov    0x58(%r13),%rsi
  67793c:	48 39 fe             	cmp    %rdi,%rsi
  67793f:	0f 86 66 01 00 00    	jbe    677aab <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1cb>
  677945:	49 8b 55 70          	mov    0x70(%r13),%rdx
  677949:	8b bc 24 98 00 00 00 	mov    0x98(%rsp),%edi
  677950:	8b b4 24 9c 00 00 00 	mov    0x9c(%rsp),%esi
  677957:	39 fe                	cmp    %edi,%esi
  677959:	0f 82 3f 01 00 00    	jb     677a9e <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1be>
  67795f:	48 39 f2             	cmp    %rsi,%rdx
  677962:	0f 82 36 01 00 00    	jb     677a9e <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1be>
  677968:	39 fe                	cmp    %edi,%esi
  67796a:	0f 84 48 01 00 00    	je     677ab8 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1d8>
  677970:	49 8b 45 68          	mov    0x68(%r13),%rax
  677974:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  677978:	80 7c 88 07 06       	cmpb   $0x6,0x7(%rax,%rcx,4)
  67797d:	0f 85 d3 00 00 00    	jne    677a56 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x176>
  677983:	4d 85 e4             	test   %r12,%r12
  677986:	74 43                	je     6779cb <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0xeb>
  677988:	49 81 c7 98 00 00 00 	add    $0x98,%r15
  67798f:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  677994:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  677999:	ba 88 00 00 00       	mov    $0x88,%edx
  67799e:	4c 89 fe             	mov    %r15,%rsi
  6779a1:	ff 15 51 ee 10 00    	call   *0x10ee51(%rip)        # 7867f8 <memcpy@GLIBC_2.14>
  6779a7:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6779ac:	0f b6 a8 8c 00 00 00 	movzbl 0x8c(%rax),%ebp
  6779b3:	4c 8d 74 24 18       	lea    0x18(%rsp),%r14
  6779b8:	4c 89 f7             	mov    %r14,%rdi
  6779bb:	e8 b0 0a 00 00       	call   678470 <_RNCINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB5_6Cursor8geometryuE0Cs6tOD1aKRtN9_11gpui_canvas>
  6779c0:	0f 28 c8             	movaps %xmm0,%xmm1
  6779c3:	83 e5 01             	and    $0x1,%ebp
  6779c6:	e9 ad 00 00 00       	jmp    677a78 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x198>
  6779cb:	49 8b 8e 18 01 00 00 	mov    0x118(%r14),%rcx
  6779d2:	48 83 f9 01          	cmp    $0x1,%rcx
  6779d6:	48 89 c8             	mov    %rcx,%rax
  6779d9:	48 83 d0 ff          	adc    $0xffffffffffffffff,%rax
  6779dd:	0f 57 c0             	xorps  %xmm0,%xmm0
  6779e0:	0f 57 c9             	xorps  %xmm1,%xmm1
  6779e3:	48 39 c8             	cmp    %rcx,%rax
  6779e6:	73 65                	jae    677a4d <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x16d>
  6779e8:	49 8b 8e 10 01 00 00 	mov    0x110(%r14),%rcx
  6779ef:	48 6b c0 70          	imul   $0x70,%rax,%rax
  6779f3:	f3 0f 10 44 01 28    	movss  0x28(%rcx,%rax,1),%xmm0
  6779f9:	f3 0f 10 4c 01 40    	movss  0x40(%rcx,%rax,1),%xmm1
  6779ff:	0f 28 d1             	movaps %xmm1,%xmm2
  677a02:	f3 0f 5d 54 01 48    	minss  0x48(%rcx,%rax,1),%xmm2
  677a08:	0f 28 da             	movaps %xmm2,%xmm3
  677a0b:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  677a10:	0f 54 cb             	andps  %xmm3,%xmm1
  677a13:	0f 55 da             	andnps %xmm2,%xmm3
  677a16:	0f 56 d9             	orps   %xmm1,%xmm3
  677a19:	0f 28 24 24          	movaps (%rsp),%xmm4
  677a1d:	f3 0f 58 e0          	addss  %xmm0,%xmm4
  677a21:	0f 14 c3             	unpcklps %xmm3,%xmm0
  677a24:	0f 5a c0             	cvtps2pd %xmm0,%xmm0
  677a27:	f3 0f 10 4c 01 44    	movss  0x44(%rcx,%rax,1),%xmm1
  677a2d:	0f 28 d1             	movaps %xmm1,%xmm2
  677a30:	f3 0f 5f 54 01 4c    	maxss  0x4c(%rcx,%rax,1),%xmm2
  677a36:	0f 28 da             	movaps %xmm2,%xmm3
  677a39:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  677a3e:	0f 54 cb             	andps  %xmm3,%xmm1
  677a41:	0f 55 da             	andnps %xmm2,%xmm3
  677a44:	0f 56 d9             	orps   %xmm1,%xmm3
  677a47:	0f 14 e3             	unpcklps %xmm3,%xmm4
  677a4a:	0f 5a cc             	cvtps2pd %xmm4,%xmm1
  677a4d:	0f 11 03             	movups %xmm0,(%rbx)
  677a50:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  677a54:	eb 33                	jmp    677a89 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas+0x1a9>
  677a56:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  677a5b:	31 ed                	xor    %ebp,%ebp
  677a5d:	f6 80 8c 00 00 00 01 	testb  $0x1,0x8c(%rax)
  677a64:	40 0f 94 c5          	sete   %bpl
  677a68:	4c 8d 74 24 18       	lea    0x18(%rsp),%r14
  677a6d:	4c 89 f7             	mov    %r14,%rdi
  677a70:	e8 fb 09 00 00       	call   678470 <_RNCINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB5_6Cursor8geometryuE0Cs6tOD1aKRtN9_11gpui_canvas>
  677a75:	0f 28 c8             	movaps %xmm0,%xmm1
  677a78:	48 89 df             	mov    %rbx,%rdi
  677a7b:	4c 89 f6             	mov    %r14,%rsi
  677a7e:	89 ea                	mov    %ebp,%edx
  677a80:	0f 28 04 24          	movaps (%rsp),%xmm0
  677a84:	e8 a7 08 00 00       	call   678330 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas>
  677a89:	48 89 d8             	mov    %rbx,%rax
  677a8c:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
  677a93:	5b                   	pop    %rbx
  677a94:	41 5c                	pop    %r12
  677a96:	41 5d                	pop    %r13
  677a98:	41 5e                	pop    %r14
  677a9a:	41 5f                	pop    %r15
  677a9c:	5d                   	pop    %rbp
  677a9d:	c3                   	ret
  677a9e:	48 8d 0d f3 4a 10 00 	lea    0x104af3(%rip),%rcx        # 77c598 <anon.65c0d5535d99d532b50dfd321f8783c6.28.llvm.10908145274026468279>
  677aa5:	ff 15 1d f0 10 00    	call   *0x10f01d(%rip)        # 786ac8 <_DYNAMIC+0x5a0>
  677aab:	48 8d 15 a6 4b 10 00 	lea    0x104ba6(%rip),%rdx        # 77c658 <anon.65c0d5535d99d532b50dfd321f8783c6.40.llvm.10908145274026468279>
  677ab2:	ff 15 d0 ed 10 00    	call   *0x10edd0(%rip)        # 786888 <_DYNAMIC+0x360>
  677ab8:	48 8d 15 c1 4a 10 00 	lea    0x104ac1(%rip),%rdx        # 77c580 <anon.65c0d5535d99d532b50dfd321f8783c6.26.llvm.10908145274026468279>
  677abf:	31 ff                	xor    %edi,%edi
  677ac1:	31 f6                	xor    %esi,%esi
  677ac3:	ff 15 bf ed 10 00    	call   *0x10edbf(%rip)        # 786888 <_DYNAMIC+0x360>
