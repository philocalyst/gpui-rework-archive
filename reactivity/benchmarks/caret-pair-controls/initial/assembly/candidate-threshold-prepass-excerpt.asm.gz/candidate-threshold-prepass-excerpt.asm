  66aef2:	0f 84 e3 06 00 00    	je     66b5db <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2a3b>
  66aef8:	48 83 bc 24 70 01 00 	cmpq   $0xffffffffffffffff,0x170(%rsp)
  66aeff:	00 ff 
  66af01:	0f 84 d4 06 00 00    	je     66b5db <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2a3b>
  66af07:	48 03 ac 24 38 01 00 	add    0x138(%rsp),%rbp
  66af0e:	00 
  66af0f:	48 c7 84 24 00 07 00 	movq   $0x0,0x700(%rsp)
  66af16:	00 00 00 00 00 
  66af1b:	48 c7 84 24 08 07 00 	movq   $0x8,0x708(%rsp)
  66af22:	00 08 00 00 00 
  66af27:	48 c7 84 24 10 07 00 	movq   $0x0,0x710(%rsp)
  66af2e:	00 00 00 00 00 
  66af33:	c7 84 24 20 07 00 00 	movl   $0xffffffff,0x720(%rsp)
  66af3a:	ff ff ff ff 
  66af3e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  66af43:	48 89 84 24 28 07 00 	mov    %rax,0x728(%rsp)
  66af4a:	00 
  66af4b:	48 89 ac 24 30 07 00 	mov    %rbp,0x730(%rsp)
  66af52:	00 
  66af53:	48 c7 84 24 38 07 00 	movq   $0x0,0x738(%rsp)
  66af5a:	00 00 00 00 00 
  66af5f:	48 8d 05 ba 14 11 00 	lea    0x1114ba(%rip),%rax        # 77c420 <anon.ddd295ed9a1214a3c2d89114c2a6b41e.1.llvm.6313990301832848616+0x190>
  66af66:	48 89 84 24 40 07 00 	mov    %rax,0x740(%rsp)
  66af6d:	00 
  66af6e:	48 8d 05 db b7 ff ff 	lea    -0x4825(%rip),%rax        # 666750 <_RINvNtCs27TG78Py0Qp_13icu_segmenter17rule_segmenter_v120empty_handle_complexNtNtB4_8scaffold4Utf8ECs6tOD1aKRtN9_11gpui_canvas>
  66af75:	48 89 84 24 48 07 00 	mov    %rax,0x748(%rsp)
  66af7c:	00 
  66af7d:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  66af82:	48 89 84 24 50 07 00 	mov    %rax,0x750(%rsp)
  66af89:	00 
  66af8a:	48 c7 84 24 58 07 00 	movq   $0x0,0x758(%rsp)
  66af91:	00 00 00 00 00 
  66af96:	48 c7 84 24 88 07 00 	movq   $0x0,0x788(%rsp)
  66af9d:	00 00 00 00 00 
  66afa2:	c6 84 24 90 07 00 00 	movb   $0x0,0x790(%rsp)
  66afa9:	00 
  66afaa:	31 db                	xor    %ebx,%ebx
  66afac:	0f 1f 40 00          	nopl   0x0(%rax)
  66afb0:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66afb7:	00 
  66afb8:	e8 83 e7 00 00       	call   679740 <_RNvXNtCs27TG78Py0Qp_13icu_segmenter17rule_segmenter_v1INtB2_17RuleBreakIteratorNtNtB4_8scaffold4Utf8ENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs6tOD1aKRtN9_11gpui_canvas>
  66afbd:	48 83 f8 01          	cmp    $0x1,%rax
  66afc1:	75 05                	jne    66afc8 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2428>
  66afc3:	48 ff c3             	inc    %rbx
  66afc6:	eb e8                	jmp    66afb0 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x2410>
  66afc8:	48 8b b4 24 00 07 00 	mov    0x700(%rsp),%rsi
  66afcf:	00 
  66afd0:	48 85 f6             	test   %rsi,%rsi
  66afd3:	74 17                	je     66afec <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x244c>
  66afd5:	48 8b bc 24 08 07 00 	mov    0x708(%rsp),%rdi
  66afdc:	00 
  66afdd:	48 c1 e6 03          	shl    $0x3,%rsi
  66afe1:	ba 08 00 00 00       	mov    $0x8,%edx
  66afe6:	ff 15 54 bf 11 00    	call   *0x11bf54(%rip)        # 786f40 <_DYNAMIC+0x238>
  66afec:	48 83 fb 08          	cmp    $0x8,%rbx
  66aff0:	0f 86 8f 00 00 00    	jbe    66b085 <_RNvMs0_NtNtCs6tOD1aKRtN9_11gpui_canvas4text7plannerNtB5_7Planner5shape+0x24e5>
  66aff6:	48 8d bc 24 00 07 00 	lea    0x700(%rsp),%rdi
  66affd:	00 
  66affe:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
