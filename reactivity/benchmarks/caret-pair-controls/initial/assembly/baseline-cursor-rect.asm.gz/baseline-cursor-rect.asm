
/tmp/gpui-caret-pair-controls-v2/baseline:     file format elf64-x86-64


Disassembly of section .text:

0000000000678330 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas>:
  678330:	41 56                	push   %r14
  678332:	53                   	push   %rbx
  678333:	48 83 ec 38          	sub    $0x38,%rsp
  678337:	49 89 f6             	mov    %rsi,%r14
  67833a:	48 89 fb             	mov    %rdi,%rbx
  67833d:	85 d2                	test   %edx,%edx
  67833f:	0f 84 8f 00 00 00    	je     6783d4 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0xa4>
  678345:	49 83 7e 18 00       	cmpq   $0x0,0x18(%r14)
  67834a:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  67834f:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  678354:	74 2e                	je     678384 <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0x54>
  678356:	49 8b 06             	mov    (%r14),%rax
  678359:	41 8b 7e 20          	mov    0x20(%r14),%edi
  67835d:	48 8b b0 18 01 00 00 	mov    0x118(%rax),%rsi
  678364:	48 39 fe             	cmp    %rdi,%rsi
  678367:	0f 86 ee 00 00 00    	jbe    67845b <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0x12b>
  67836d:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  678374:	48 6b cf 70          	imul   $0x70,%rdi,%rcx
  678378:	f3 0f 10 44 08 50    	movss  0x50(%rax,%rcx,1),%xmm0
  67837e:	8b 44 08 54          	mov    0x54(%rax,%rcx,1),%eax
  678382:	eb 08                	jmp    67838c <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0x5c>
  678384:	0f 57 c0             	xorps  %xmm0,%xmm0
  678387:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
  67838c:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  678390:	f2 0f 10 49 44       	movsd  0x44(%rcx),%xmm1
  678395:	f2 0f 11 0c 24       	movsd  %xmm1,(%rsp)
  67839a:	f3 0f 11 44 24 08    	movss  %xmm0,0x8(%rsp)
  6783a0:	89 44 24 0c          	mov    %eax,0xc(%rsp)
  6783a4:	49 8d 76 30          	lea    0x30(%r14),%rsi
  6783a8:	49 8d 96 80 00 00 00 	lea    0x80(%r14),%rdx
  6783af:	49 8b 46 08          	mov    0x8(%r14),%rax
  6783b3:	0f b6 88 8c 00 00 00 	movzbl 0x8c(%rax),%ecx
  6783ba:	83 e1 01             	and    $0x1,%ecx
  6783bd:	48 89 e7             	mov    %rsp,%rdi
  6783c0:	ff 15 e2 e8 10 00    	call   *0x10e8e2(%rip)        # 786ca8 <_DYNAMIC+0x780>
  6783c6:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6783cb:	f3 0f 58 c8          	addss  %xmm0,%xmm1
  6783cf:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  6783d4:	49 8b 06             	mov    (%r14),%rax
  6783d7:	41 8b 4e 20          	mov    0x20(%r14),%ecx
  6783db:	48 39 88 18 01 00 00 	cmp    %rcx,0x118(%rax)
  6783e2:	76 6a                	jbe    67844e <_RINvNtNtCshQYmODNYIQG_6parley7editing6cursor11cursor_rectuECs6tOD1aKRtN9_11gpui_canvas+0x11e>
  6783e4:	48 8b 80 10 01 00 00 	mov    0x110(%rax),%rax
  6783eb:	48 6b c9 70          	imul   $0x70,%rcx,%rcx
  6783ef:	f3 0f 10 64 08 40    	movss  0x40(%rax,%rcx,1),%xmm4
  6783f5:	f3 0f 10 6c 08 44    	movss  0x44(%rax,%rcx,1),%xmm5
  6783fb:	0f 28 d4             	movaps %xmm4,%xmm2
  6783fe:	f3 0f 5d 54 08 48    	minss  0x48(%rax,%rcx,1),%xmm2
  678404:	0f 28 da             	movaps %xmm2,%xmm3
  678407:	f3 0f c2 da 03       	cmpunordss %xmm2,%xmm3
  67840c:	0f 54 e3             	andps  %xmm3,%xmm4
  67840f:	0f 55 da             	andnps %xmm2,%xmm3
  678412:	0f 56 dc             	orps   %xmm4,%xmm3
  678415:	f3 0f 58 c1          	addss  %xmm1,%xmm0
  678419:	0f 28 e5             	movaps %xmm5,%xmm4
  67841c:	f3 0f 5f 64 08 4c    	maxss  0x4c(%rax,%rcx,1),%xmm4
  678422:	0f 28 d4             	movaps %xmm4,%xmm2
  678425:	f3 0f c2 d4 03       	cmpunordss %xmm4,%xmm2
  67842a:	0f 54 ea             	andps  %xmm2,%xmm5
  67842d:	0f 55 d4             	andnps %xmm4,%xmm2
  678430:	0f 56 d5             	orps   %xmm5,%xmm2
  678433:	0f 14 cb             	unpcklps %xmm3,%xmm1
  678436:	0f 5a c9             	cvtps2pd %xmm1,%xmm1
  678439:	0f 11 0b             	movups %xmm1,(%rbx)
  67843c:	0f 14 c2             	unpcklps %xmm2,%xmm0
  67843f:	0f 5a c0             	cvtps2pd %xmm0,%xmm0
  678442:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  678446:	48 83 c4 38          	add    $0x38,%rsp
  67844a:	5b                   	pop    %rbx
  67844b:	41 5e                	pop    %r14
  67844d:	c3                   	ret
  67844e:	48 8d 3d 5b 41 10 00 	lea    0x10415b(%rip),%rdi        # 77c5b0 <anon.65c0d5535d99d532b50dfd321f8783c6.28.llvm.10908145274026468279+0x18>
  678455:	ff 15 05 e4 10 00    	call   *0x10e405(%rip)        # 786860 <_DYNAMIC+0x338>
  67845b:	48 8d 15 2e 40 10 00 	lea    0x10402e(%rip),%rdx        # 77c490 <anon.b0964daeeb2701cfeb196c9b24447b81.3.llvm.7401615574458183615+0x60>
  678462:	ff 15 20 e4 10 00    	call   *0x10e420(%rip)        # 786888 <_DYNAMIC+0x360>
