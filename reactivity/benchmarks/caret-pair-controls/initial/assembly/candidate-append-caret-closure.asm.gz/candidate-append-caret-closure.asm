
/tmp/gpui-caret-pair-controls-v2/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000666650 <_RNvXs0_NtNtCs4NRVxsYgnAr_4core5array5drainQINtB5_5DrainNtNtNtCshQYmODNYIQG_6parley6layout7cluster8AffinityNCINvMNtNtB9_3ops9try_traitINtB1M_17NeverShortCircuitINtNtB9_6option6OptionNtNtBX_4util11BoundingBoxEE10wrap_mut_1BR_NCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner13append_carets0E0EINtNtB1O_8function5FnMutTjEE8call_mutB3H_>:
  666650:	41 57                	push   %r15
  666652:	41 56                	push   %r14
  666654:	53                   	push   %rbx
  666655:	48 81 ec c0 01 00 00 	sub    $0x1c0,%rsp
  66665c:	48 89 fb             	mov    %rdi,%rbx
  66665f:	48 8b 06             	mov    (%rsi),%rax
  666662:	48 8b 08             	mov    (%rax),%rcx
  666665:	48 8b 70 08          	mov    0x8(%rax),%rsi
  666669:	48 8d 51 01          	lea    0x1(%rcx),%rdx
  66666d:	48 89 10             	mov    %rdx,(%rax)
  666670:	0f b6 11             	movzbl (%rcx),%edx
  666673:	4c 8b 36             	mov    (%rsi),%r14
  666676:	4c 8b 7e 08          	mov    0x8(%rsi),%r15
  66667a:	49 8b 37             	mov    (%r15),%rsi
  66667d:	4c 89 f7             	mov    %r14,%rdi
  666680:	e8 8b c1 00 00       	call   672810 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor15from_byte_indexuECs6tOD1aKRtN9_11gpui_canvas>
  666685:	48 89 04 24          	mov    %rax,(%rsp)
  666689:	80 e2 01             	and    $0x1,%dl
  66668c:	88 54 24 08          	mov    %dl,0x8(%rsp)
  666690:	49 3b 07             	cmp    (%r15),%rax
  666693:	75 20                	jne    6666b5 <_RNvXs0_NtNtCs4NRVxsYgnAr_4core5array5drainQINtB5_5DrainNtNtNtCshQYmODNYIQG_6parley6layout7cluster8AffinityNCINvMNtNtB9_3ops9try_traitINtB1M_17NeverShortCircuitINtNtB9_6option6OptionNtNtBX_4util11BoundingBoxEE10wrap_mut_1BR_NCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner13append_carets0E0EINtNtB1O_8function5FnMutTjEE8call_mutB3H_+0x65>
  666695:	48 85 c0             	test   %rax,%rax
  666698:	74 1f                	je     6666b9 <_RNvXs0_NtNtCs4NRVxsYgnAr_4core5array5drainQINtB5_5DrainNtNtNtCshQYmODNYIQG_6parley6layout7cluster8AffinityNCINvMNtNtB9_3ops9try_traitINtB1M_17NeverShortCircuitINtNtB9_6option6OptionNtNtBX_4util11BoundingBoxEE10wrap_mut_1BR_NCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner13append_carets0E0EINtNtB1O_8function5FnMutTjEE8call_mutB3H_+0x69>
  66669a:	48 89 c2             	mov    %rax,%rdx
  66669d:	48 ff ca             	dec    %rdx
  6666a0:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6666a5:	4c 89 f6             	mov    %r14,%rsi
  6666a8:	49 89 c7             	mov    %rax,%r15
  6666ab:	e8 90 d9 00 00       	call   674040 <_RNvMs0_NtNtCshQYmODNYIQG_6parley6layout7clusterINtB5_7ClusteruE15from_byte_indexCs6tOD1aKRtN9_11gpui_canvas.llvm.13034477518265263966>
  6666b0:	4c 89 f8             	mov    %r15,%rax
  6666b3:	eb 0d                	jmp    6666c2 <_RNvXs0_NtNtCs4NRVxsYgnAr_4core5array5drainQINtB5_5DrainNtNtNtCshQYmODNYIQG_6parley6layout7cluster8AffinityNCINvMNtNtB9_3ops9try_traitINtB1M_17NeverShortCircuitINtNtB9_6option6OptionNtNtBX_4util11BoundingBoxEE10wrap_mut_1BR_NCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner13append_carets0E0EINtNtB1O_8function5FnMutTjEE8call_mutB3H_+0x72>
  6666b5:	31 c0                	xor    %eax,%eax
  6666b7:	eb 57                	jmp    666710 <_RNvXs0_NtNtCs4NRVxsYgnAr_4core5array5drainQINtB5_5DrainNtNtNtCshQYmODNYIQG_6parley6layout7cluster8AffinityNCINvMNtNtB9_3ops9try_traitINtB1M_17NeverShortCircuitINtNtB9_6option6OptionNtNtBX_4util11BoundingBoxEE10wrap_mut_1BR_NCNvNtNtCs6tOD1aKRtN9_11gpui_canvas4text7planner13append_carets0E0EINtNtB1O_8function5FnMutTjEE8call_mutB3H_+0xc0>
  6666b9:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  6666c0:	00 00 
  6666c2:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  6666c9:	00 
  6666ca:	4c 89 f6             	mov    %r14,%rsi
  6666cd:	48 89 c2             	mov    %rax,%rdx
  6666d0:	e8 6b d9 00 00       	call   674040 <_RNvMs0_NtNtCshQYmODNYIQG_6parley6layout7clusterINtB5_7ClusteruE15from_byte_indexCs6tOD1aKRtN9_11gpui_canvas.llvm.13034477518265263966>
  6666d5:	4c 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%r15
  6666dc:	00 
  6666dd:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  6666e2:	ba 90 00 00 00       	mov    $0x90,%edx
  6666e7:	4c 89 ff             	mov    %r15,%rdi
  6666ea:	ff 15 e8 08 12 00    	call   *0x1208e8(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  6666f0:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  6666f5:	48 89 e6             	mov    %rsp,%rsi
  6666f8:	f3 0f 10 05 0c 6f 9b 	movss  -0x6490f4(%rip),%xmm0        # 1d60c <GCC_except_table0+0x24>
  6666ff:	ff 
  666700:	4c 89 f2             	mov    %r14,%rdx
  666703:	4c 89 f9             	mov    %r15,%rcx
  666706:	e8 05 bc 00 00       	call   672310 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCINvB2_8geometryuE0ECs6tOD1aKRtN9_11gpui_canvas>
  66670b:	b8 01 00 00 00       	mov    $0x1,%eax
  666710:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  666715:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  66671a:	48 89 43 20          	mov    %rax,0x20(%rbx)
  66671e:	0f 10 44 24 20       	movups 0x20(%rsp),%xmm0
  666723:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  666727:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  66672c:	48 89 03             	mov    %rax,(%rbx)
  66672f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  666734:	48 89 43 08          	mov    %rax,0x8(%rbx)
  666738:	48 89 d8             	mov    %rbx,%rax
  66673b:	48 81 c4 c0 01 00 00 	add    $0x1c0,%rsp
  666742:	5b                   	pop    %rbx
  666743:	41 5e                	pop    %r14
  666745:	41 5f                	pop    %r15
  666747:	c3                   	ret
