
/tmp/gpui-caret-pair-controls-v2/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000672e60 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas>:
  672e60:	55                   	push   %rbp
  672e61:	41 57                	push   %r15
  672e63:	41 56                	push   %r14
  672e65:	41 55                	push   %r13
  672e67:	41 54                	push   %r12
  672e69:	53                   	push   %rbx
  672e6a:	48 81 ec 78 04 00 00 	sub    $0x478,%rsp
  672e71:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
  672e77:	48 89 d5             	mov    %rdx,%rbp
  672e7a:	49 89 f6             	mov    %rsi,%r14
  672e7d:	48 89 fb             	mov    %rdi,%rbx
  672e80:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
  672e87:	00 
  672e88:	e8 03 08 00 00       	call   673690 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE15indexed_clusterCs6tOD1aKRtN9_11gpui_canvas>
  672e8d:	4d 8b 6e 30          	mov    0x30(%r14),%r13
  672e91:	4c 8b a4 24 f8 01 00 	mov    0x1f8(%rsp),%r12
  672e98:	00 
  672e99:	4d 85 e4             	test   %r12,%r12
  672e9c:	0f 84 6c 03 00 00    	je     67320e <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x3ae>
  672ea2:	8b bc 24 20 02 00 00 	mov    0x220(%rsp),%edi
  672ea9:	49 8b 74 24 58       	mov    0x58(%r12),%rsi
  672eae:	48 39 fe             	cmp    %rdi,%rsi
  672eb1:	0f 86 72 07 00 00    	jbe    673629 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7c9>
  672eb7:	8b b4 24 78 02 00 00 	mov    0x278(%rsp),%esi
  672ebe:	8b 94 24 7c 02 00 00 	mov    0x27c(%rsp),%edx
  672ec5:	49 8b 44 24 50       	mov    0x50(%r12),%rax
  672eca:	48 8d 0c ff          	lea    (%rdi,%rdi,8),%rcx
  672ece:	48 c1 e1 04          	shl    $0x4,%rcx
  672ed2:	66 41 0f 10 44 24 68 	movupd 0x68(%r12),%xmm0
  672ed9:	41 0f 10 8c 24 80 00 	movups 0x80(%r12),%xmm1
  672ee0:	00 00 
  672ee2:	41 0f 10 94 24 98 00 	movups 0x98(%r12),%xmm2
  672ee9:	00 00 
  672eeb:	66 0f 11 84 24 d0 00 	movupd %xmm0,0xd0(%rsp)
  672ef2:	00 00 
  672ef4:	0f 11 8c 24 e0 00 00 	movups %xmm1,0xe0(%rsp)
  672efb:	00 
  672efc:	0f 11 94 24 f0 00 00 	movups %xmm2,0xf0(%rsp)
  672f03:	00 
  672f04:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  672f09:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  672f10:	00 
  672f11:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  672f18:	00 
  672f19:	ff 15 09 44 11 00    	call   *0x114409(%rip)        # 787328 <_DYNAMIC+0x620>
  672f1f:	48 85 c0             	test   %rax,%rax
  672f22:	0f 95 c1             	setne  %cl
  672f25:	48 39 e8             	cmp    %rbp,%rax
  672f28:	0f 85 f2 02 00 00    	jne    673220 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x3c0>
  672f2e:	48 85 ed             	test   %rbp,%rbp
  672f31:	88 4c 24 0b          	mov    %cl,0xb(%rsp)
  672f35:	0f 84 f1 02 00 00    	je     67322c <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x3cc>
  672f3b:	48 8d 55 ff          	lea    -0x1(%rbp),%rdx
  672f3f:	48 8d bc 24 88 02 00 	lea    0x288(%rsp),%rdi
  672f46:	00 
  672f47:	4c 89 f6             	mov    %r14,%rsi
  672f4a:	e8 41 07 00 00       	call   673690 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE15indexed_clusterCs6tOD1aKRtN9_11gpui_canvas>
  672f4f:	4c 8b bc 24 90 02 00 	mov    0x290(%rsp),%r15
  672f56:	00 
  672f57:	4d 85 ff             	test   %r15,%r15
  672f5a:	0f 84 f8 02 00 00    	je     673258 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x3f8>
  672f60:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  672f65:	4d 89 ef             	mov    %r13,%r15
  672f68:	4c 8d ac 24 98 02 00 	lea    0x298(%rsp),%r13
  672f6f:	00 
  672f70:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  672f77:	00 
  672f78:	ba 88 00 00 00       	mov    $0x88,%edx
  672f7d:	4c 89 ee             	mov    %r13,%rsi
  672f80:	ff 15 52 40 11 00    	call   *0x114052(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  672f86:	4d 85 e4             	test   %r12,%r12
  672f89:	0f 84 52 03 00 00    	je     6732e1 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x481>
  672f8f:	48 8d bc 24 68 03 00 	lea    0x368(%rsp),%rdi
  672f96:	00 
  672f97:	ba 88 00 00 00       	mov    $0x88,%edx
  672f9c:	4c 89 ee             	mov    %r13,%rsi
  672f9f:	ff 15 33 40 11 00    	call   *0x114033(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  672fa5:	48 8b bc 24 88 02 00 	mov    0x288(%rsp),%rdi
  672fac:	00 
  672fad:	49 8b 76 10          	mov    0x10(%r14),%rsi
  672fb1:	48 39 f7             	cmp    %rsi,%rdi
  672fb4:	0f 83 7c 06 00 00    	jae    673636 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7d6>
  672fba:	4c 8b 84 24 f0 01 00 	mov    0x1f0(%rsp),%r8
  672fc1:	00 
  672fc2:	49 39 f0             	cmp    %rsi,%r8
  672fc5:	0f 83 78 06 00 00    	jae    673643 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7e3>
  672fcb:	4d 89 fd             	mov    %r15,%r13
  672fce:	44 8b 8c 24 b8 02 00 	mov    0x2b8(%rsp),%r9d
  672fd5:	00 
  672fd6:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
  672fdb:	49 8b 77 58          	mov    0x58(%r15),%rsi
  672fdf:	4c 39 ce             	cmp    %r9,%rsi
  672fe2:	0f 86 6b 06 00 00    	jbe    673653 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7f3>
  672fe8:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
  672fef:	00 
  672ff0:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  672ff7:	00 
  672ff8:	48 8b 84 24 98 02 00 	mov    0x298(%rsp),%rax
  672fff:	00 
  673000:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  673007:	00 
  673008:	8b b4 24 10 03 00 00 	mov    0x310(%rsp),%esi
  67300f:	8b 94 24 14 03 00 00 	mov    0x314(%rsp),%edx
  673016:	8b 84 24 20 02 00 00 	mov    0x220(%rsp),%eax
  67301d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  673022:	8b 84 24 78 02 00 00 	mov    0x278(%rsp),%eax
  673029:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  67302e:	8b 84 24 7c 02 00 00 	mov    0x27c(%rsp),%eax
  673035:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  67303a:	49 8b 46 08          	mov    0x8(%r14),%rax
  67303e:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  673043:	48 89 f9             	mov    %rdi,%rcx
  673046:	48 c1 e1 04          	shl    $0x4,%rcx
  67304a:	f2 0f 10 04 08       	movsd  (%rax,%rcx,1),%xmm0
  67304f:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  673054:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
  673059:	4c 89 c1             	mov    %r8,%rcx
  67305c:	48 c1 e1 04          	shl    $0x4,%rcx
  673060:	f2 0f 10 04 08       	movsd  (%rax,%rcx,1),%xmm0
  673065:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  67306a:	49 8b 47 50          	mov    0x50(%r15),%rax
  67306e:	4c 89 4c 24 78       	mov    %r9,0x78(%rsp)
  673073:	4b 8d 0c c9          	lea    (%r9,%r9,8),%rcx
  673077:	48 c1 e1 04          	shl    $0x4,%rcx
  67307b:	66 41 0f 10 47 68    	movupd 0x68(%r15),%xmm0
  673081:	41 0f 10 8f 80 00 00 	movups 0x80(%r15),%xmm1
  673088:	00 
  673089:	41 0f 10 97 98 00 00 	movups 0x98(%r15),%xmm2
  673090:	00 
  673091:	66 0f 11 84 24 d0 00 	movupd %xmm0,0xd0(%rsp)
  673098:	00 00 
  67309a:	0f 11 8c 24 e0 00 00 	movups %xmm1,0xe0(%rsp)
  6730a1:	00 
  6730a2:	0f 11 94 24 f0 00 00 	movups %xmm2,0xf0(%rsp)
  6730a9:	00 
  6730aa:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  6730af:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  6730b6:	00 
  6730b7:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  6730be:	00 
  6730bf:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6730c4:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
  6730c9:	ff 15 59 42 11 00    	call   *0x114259(%rip)        # 787328 <_DYNAMIC+0x620>
  6730cf:	48 39 ea             	cmp    %rbp,%rdx
  6730d2:	0f 85 ce 02 00 00    	jne    6733a6 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x546>
  6730d8:	49 8b 74 24 58       	mov    0x58(%r12),%rsi
  6730dd:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6730e2:	48 39 fe             	cmp    %rdi,%rsi
  6730e5:	0f 86 3e 05 00 00    	jbe    673629 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7c9>
  6730eb:	49 8b 44 24 50       	mov    0x50(%r12),%rax
  6730f0:	48 8d 0c ff          	lea    (%rdi,%rdi,8),%rcx
  6730f4:	48 c1 e1 04          	shl    $0x4,%rcx
  6730f8:	41 0f 10 44 24 68    	movups 0x68(%r12),%xmm0
  6730fe:	41 0f 10 8c 24 80 00 	movups 0x80(%r12),%xmm1
  673105:	00 00 
  673107:	41 0f 10 94 24 98 00 	movups 0x98(%r12),%xmm2
  67310e:	00 00 
  673110:	0f 11 84 24 d0 00 00 	movups %xmm0,0xd0(%rsp)
  673117:	00 
  673118:	0f 11 8c 24 e0 00 00 	movups %xmm1,0xe0(%rsp)
  67311f:	00 
  673120:	0f 11 94 24 f0 00 00 	movups %xmm2,0xf0(%rsp)
  673127:	00 
  673128:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  67312d:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  673134:	00 
  673135:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  67313c:	00 
  67313d:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  673142:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  673147:	ff 15 db 41 11 00    	call   *0x1141db(%rip)        # 787328 <_DYNAMIC+0x620>
  67314d:	66 0f 6f 44 24 40    	movdqa 0x40(%rsp),%xmm0
  673153:	66 0f 76 44 24 50    	pcmpeqd 0x50(%rsp),%xmm0
  673159:	66 0f 70 c0 50       	pshufd $0x50,%xmm0,%xmm0
  67315e:	66 0f 50 c8          	movmskpd %xmm0,%ecx
  673162:	31 d2                	xor    %edx,%edx
  673164:	f6 c1 02             	test   $0x2,%cl
  673167:	0f 84 3b 02 00 00    	je     6733a8 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x548>
  67316d:	f6 c1 01             	test   $0x1,%cl
  673170:	48 8d b4 24 98 02 00 	lea    0x298(%rsp),%rsi
  673177:	00 
  673178:	0f 84 32 02 00 00    	je     6733b0 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x550>
  67317e:	48 39 e8             	cmp    %rbp,%rax
  673181:	0f 85 29 02 00 00    	jne    6733b0 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x550>
  673187:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  67318e:	00 
  67318f:	0f b6 80 8c 00 00 00 	movzbl 0x8c(%rax),%eax
  673196:	89 c1                	mov    %eax,%ecx
  673198:	80 e1 01             	and    $0x1,%cl
  67319b:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
  6731a2:	00 
  6731a3:	f6 82 8c 00 00 00 01 	testb  $0x1,0x8c(%rdx)
  6731aa:	0f 94 c2             	sete   %dl
  6731ad:	38 d1                	cmp    %dl,%cl
  6731af:	0f 84 28 04 00 00    	je     6735dd <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x77d>
  6731b5:	49 89 f1             	mov    %rsi,%r9
  6731b8:	49 8b 77 58          	mov    0x58(%r15),%rsi
  6731bc:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  6731c1:	48 39 fe             	cmp    %rdi,%rsi
  6731c4:	0f 86 5f 04 00 00    	jbe    673629 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7c9>
  6731ca:	49 8b 57 70          	mov    0x70(%r15),%rdx
  6731ce:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
  6731d3:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  6731d8:	39 fe                	cmp    %edi,%esi
  6731da:	0f 82 2c 04 00 00    	jb     67360c <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7ac>
  6731e0:	48 39 f2             	cmp    %rsi,%rdx
  6731e3:	0f 82 23 04 00 00    	jb     67360c <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7ac>
  6731e9:	39 fe                	cmp    %edi,%esi
  6731eb:	0f 84 72 04 00 00    	je     673663 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x803>
  6731f1:	49 8b 4f 68          	mov    0x68(%r15),%rcx
  6731f5:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  6731f9:	80 7c 91 07 06       	cmpb   $0x6,0x7(%rcx,%rdx,4)
  6731fe:	0f 85 91 03 00 00    	jne    673595 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x735>
  673204:	4c 89 ce             	mov    %r9,%rsi
  673207:	31 d2                	xor    %edx,%edx
  673209:	e9 a2 01 00 00       	jmp    6733b0 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x550>
  67320e:	49 8b 85 50 01 00 00 	mov    0x150(%r13),%rax
  673215:	b1 01                	mov    $0x1,%cl
  673217:	48 39 e8             	cmp    %rbp,%rax
  67321a:	0f 84 0e fd ff ff    	je     672f2e <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0xce>
  673220:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  673227:	e9 54 03 00 00       	jmp    673580 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x720>
  67322c:	4d 85 e4             	test   %r12,%r12
  67322f:	0f 84 b6 00 00 00    	je     6732eb <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x48b>
  673235:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
  67323c:	00 
  67323d:	48 8d bc 24 f0 03 00 	lea    0x3f0(%rsp),%rdi
  673244:	00 
  673245:	ba 88 00 00 00       	mov    $0x88,%edx
  67324a:	ff 15 88 3d 11 00    	call   *0x113d88(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  673250:	45 31 ff             	xor    %r15d,%r15d
  673253:	e9 b1 00 00 00       	jmp    673309 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x4a9>
  673258:	4d 85 e4             	test   %r12,%r12
  67325b:	0f 84 8d 00 00 00    	je     6732ee <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x48e>
  673261:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
  673268:	00 
  673269:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  673270:	00 00 00 00 00 
  673275:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
  67327c:	00 
  67327d:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  673284:	00 
  673285:	ba 88 00 00 00       	mov    $0x88,%edx
  67328a:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
  67328f:	ff 15 43 3d 11 00    	call   *0x113d43(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  673295:	49 8b 95 10 01 00 00 	mov    0x110(%r13),%rdx
  67329c:	49 8b 8d 18 01 00 00 	mov    0x118(%r13),%rcx
  6732a3:	0f b6 74 24 0b       	movzbl 0xb(%rsp),%esi
  6732a8:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  6732af:	00 
  6732b0:	4c 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%r8
  6732b7:	00 
  6732b8:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  6732be:	4d 89 f1             	mov    %r14,%r9
  6732c1:	e8 3a f2 ff ff       	call   672500 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas>
  6732c6:	8b 84 24 20 02 00 00 	mov    0x220(%rsp),%eax
  6732cd:	44 8b 84 24 78 02 00 	mov    0x278(%rsp),%r8d
  6732d4:	00 
  6732d5:	8b 94 24 7c 02 00 00 	mov    0x27c(%rsp),%edx
  6732dc:	e9 68 01 00 00       	jmp    673449 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x5e9>
  6732e1:	4d 89 fd             	mov    %r15,%r13
  6732e4:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
  6732e9:	eb 03                	jmp    6732ee <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x48e>
  6732eb:	45 31 ff             	xor    %r15d,%r15d
  6732ee:	48 8d bc 24 68 03 00 	lea    0x368(%rsp),%rdi
  6732f5:	00 
  6732f6:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
  6732fd:	00 
  6732fe:	ba 88 00 00 00       	mov    $0x88,%edx
  673303:	ff 15 cf 3c 11 00    	call   *0x113ccf(%rip)        # 786fd8 <memcpy@GLIBC_2.14>
  673309:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
  673310:	00 
  673311:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  673318:	00 
  673319:	48 8d b4 24 68 03 00 	lea    0x368(%rsp),%rsi
  673320:	00 
  673321:	4c 8b 3d b0 3c 11 00 	mov    0x113cb0(%rip),%r15        # 786fd8 <memcpy@GLIBC_2.14>
  673328:	ba 88 00 00 00       	mov    $0x88,%edx
  67332d:	41 ff d7             	call   *%r15
  673330:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
  673337:	00 
  673338:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  67333f:	00 
  673340:	48 8d b4 24 f0 03 00 	lea    0x3f0(%rsp),%rsi
  673347:	00 
  673348:	ba 88 00 00 00       	mov    $0x88,%edx
  67334d:	41 ff d7             	call   *%r15
  673350:	49 8b 95 10 01 00 00 	mov    0x110(%r13),%rdx
  673357:	49 8b 8d 18 01 00 00 	mov    0x118(%r13),%rcx
  67335e:	0f b6 74 24 0b       	movzbl 0xb(%rsp),%esi
  673363:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  67336a:	00 
  67336b:	4c 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%r8
  673372:	00 
  673373:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  673379:	4d 89 f1             	mov    %r14,%r9
  67337c:	e8 7f f1 ff ff       	call   672500 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas>
  673381:	0f 10 84 24 90 00 00 	movups 0x90(%rsp),%xmm0
  673388:	00 
  673389:	0f 10 8c 24 a0 00 00 	movups 0xa0(%rsp),%xmm1
  673390:	00 
  673391:	0f 29 8c 24 c0 00 00 	movaps %xmm1,0xc0(%rsp)
  673398:	00 
  673399:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  6733a0:	00 
  6733a1:	e9 80 01 00 00       	jmp    673526 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x6c6>
  6733a6:	31 d2                	xor    %edx,%edx
  6733a8:	48 8d b4 24 98 02 00 	lea    0x298(%rsp),%rsi
  6733af:	00 
  6733b0:	89 54 24 50          	mov    %edx,0x50(%rsp)
  6733b4:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
  6733bb:	00 
  6733bc:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  6733c3:	00 
  6733c4:	48 8b 2d 0d 3c 11 00 	mov    0x113c0d(%rip),%rbp        # 786fd8 <memcpy@GLIBC_2.14>
  6733cb:	ba 88 00 00 00       	mov    $0x88,%edx
  6733d0:	ff d5                	call   *%rbp
  6733d2:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
  6733d9:	00 
  6733da:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  6733e1:	00 
  6733e2:	ba 88 00 00 00       	mov    $0x88,%edx
  6733e7:	48 8d 84 24 00 02 00 	lea    0x200(%rsp),%rax
  6733ee:	00 
  6733ef:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6733f4:	48 8d b4 24 00 02 00 	lea    0x200(%rsp),%rsi
  6733fb:	00 
  6733fc:	ff d5                	call   *%rbp
  6733fe:	49 8b 95 10 01 00 00 	mov    0x110(%r13),%rdx
  673405:	49 8b 8d 18 01 00 00 	mov    0x118(%r13),%rcx
  67340c:	0f b6 74 24 0b       	movzbl 0xb(%rsp),%esi
  673411:	48 8d bc 24 90 00 00 	lea    0x90(%rsp),%rdi
  673418:	00 
  673419:	4c 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%r8
  673420:	00 
  673421:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  673427:	4d 89 f1             	mov    %r14,%r9
  67342a:	e8 d1 f0 ff ff       	call   672500 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas>
  67342f:	80 7c 24 50 00       	cmpb   $0x0,0x50(%rsp)
  673434:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  673439:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  67343e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  673443:	0f 85 38 ff ff ff    	jne    673381 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x521>
  673449:	89 c7                	mov    %eax,%edi
  67344b:	49 8b 74 24 58       	mov    0x58(%r12),%rsi
  673450:	48 39 fe             	cmp    %rdi,%rsi
  673453:	0f 86 d0 01 00 00    	jbe    673629 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7c9>
  673459:	49 8b 44 24 50       	mov    0x50(%r12),%rax
  67345e:	48 8d 0c ff          	lea    (%rdi,%rdi,8),%rcx
  673462:	48 c1 e1 04          	shl    $0x4,%rcx
  673466:	41 0f 10 44 24 68    	movups 0x68(%r12),%xmm0
  67346c:	41 0f 10 8c 24 80 00 	movups 0x80(%r12),%xmm1
  673473:	00 00 
  673475:	41 0f 10 94 24 98 00 	movups 0x98(%r12),%xmm2
  67347c:	00 00 
  67347e:	0f 11 84 24 d0 00 00 	movups %xmm0,0xd0(%rsp)
  673485:	00 
  673486:	0f 11 8c 24 e0 00 00 	movups %xmm1,0xe0(%rsp)
  67348d:	00 
  67348e:	0f 11 94 24 f0 00 00 	movups %xmm2,0xf0(%rsp)
  673495:	00 
  673496:	48 8b 44 08 50       	mov    0x50(%rax,%rcx,1),%rax
  67349b:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  6734a2:	00 
  6734a3:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  6734aa:	00 
  6734ab:	44 89 c6             	mov    %r8d,%esi
  6734ae:	ff 15 74 3e 11 00    	call   *0x113e74(%rip)        # 787328 <_DYNAMIC+0x620>
  6734b4:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
  6734bb:	00 
  6734bc:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  6734c3:	00 
  6734c4:	48 8d b4 24 68 03 00 	lea    0x368(%rsp),%rsi
  6734cb:	00 
  6734cc:	4c 8b 3d 05 3b 11 00 	mov    0x113b05(%rip),%r15        # 786fd8 <memcpy@GLIBC_2.14>
  6734d3:	ba 88 00 00 00       	mov    $0x88,%edx
  6734d8:	41 ff d7             	call   *%r15
  6734db:	4c 89 a4 24 60 01 00 	mov    %r12,0x160(%rsp)
  6734e2:	00 
  6734e3:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  6734ea:	00 
  6734eb:	ba 88 00 00 00       	mov    $0x88,%edx
  6734f0:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  6734f5:	41 ff d7             	call   *%r15
  6734f8:	49 8b 95 10 01 00 00 	mov    0x110(%r13),%rdx
  6734ff:	49 8b 8d 18 01 00 00 	mov    0x118(%r13),%rcx
  673506:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  67350d:	00 
  67350e:	4c 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%r8
  673515:	00 
  673516:	31 f6                	xor    %esi,%esi
  673518:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
  67351e:	4d 89 f1             	mov    %r14,%r9
  673521:	e8 da ef ff ff       	call   672500 <_RINvMNtNtCshQYmODNYIQG_6parley7editing6cursorNtB3_6Cursor13geometry_withuNCNCNvMNtB5_8geometryINtB1g_14CursorGeometryuE13geometries_ats3_00ECs6tOD1aKRtN9_11gpui_canvas>
  673526:	66 0f 10 84 24 90 00 	movupd 0x90(%rsp),%xmm0
  67352d:	00 00 
  67352f:	0f 10 8c 24 a0 00 00 	movups 0xa0(%rsp),%xmm1
  673536:	00 
  673537:	0f 29 8c 24 30 03 00 	movaps %xmm1,0x330(%rsp)
  67353e:	00 
  67353f:	66 0f 29 84 24 20 03 	movapd %xmm0,0x320(%rsp)
  673546:	00 00 
  673548:	0f 28 94 24 b0 00 00 	movaps 0xb0(%rsp),%xmm2
  67354f:	00 
  673550:	0f 28 9c 24 c0 00 00 	movaps 0xc0(%rsp),%xmm3
  673557:	00 
  673558:	0f 29 94 24 40 03 00 	movaps %xmm2,0x340(%rsp)
  67355f:	00 
  673560:	0f 29 9c 24 50 03 00 	movaps %xmm3,0x350(%rsp)
  673567:	00 
  673568:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  67356c:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  673570:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  673574:	66 0f 11 43 08       	movupd %xmm0,0x8(%rbx)
  673579:	48 c7 03 01 00 00 00 	movq   $0x1,(%rbx)
  673580:	48 89 d8             	mov    %rbx,%rax
  673583:	48 81 c4 78 04 00 00 	add    $0x478,%rsp
  67358a:	5b                   	pop    %rbx
  67358b:	41 5c                	pop    %r12
  67358d:	41 5d                	pop    %r13
  67358f:	41 5e                	pop    %r14
  673591:	41 5f                	pop    %r15
  673593:	5d                   	pop    %rbp
  673594:	c3                   	ret
  673595:	49 8b 74 24 58       	mov    0x58(%r12),%rsi
  67359a:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  67359f:	48 39 ce             	cmp    %rcx,%rsi
  6735a2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6735a7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  6735ac:	0f 86 c2 00 00 00    	jbe    673674 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x814>
  6735b2:	49 8b 54 24 70       	mov    0x70(%r12),%rdx
  6735b7:	41 39 f8             	cmp    %edi,%r8d
  6735ba:	72 5d                	jb     673619 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7b9>
  6735bc:	4c 39 c2             	cmp    %r8,%rdx
  6735bf:	72 58                	jb     673619 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7b9>
  6735c1:	41 39 f8             	cmp    %edi,%r8d
  6735c4:	0f 84 99 00 00 00    	je     673663 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x803>
  6735ca:	4c 89 ce             	mov    %r9,%rsi
  6735cd:	49 8b 4c 24 68       	mov    0x68(%r12),%rcx
  6735d2:	48 8d 14 7f          	lea    (%rdi,%rdi,2),%rdx
  6735d6:	80 7c 91 07 06       	cmpb   $0x6,0x7(%rcx,%rdx,4)
  6735db:	75 07                	jne    6735e4 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x784>
  6735dd:	31 d2                	xor    %edx,%edx
  6735df:	e9 cc fd ff ff       	jmp    6733b0 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x550>
  6735e4:	a8 01                	test   $0x1,%al
  6735e6:	74 0f                	je     6735f7 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x797>
  6735e8:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6735ed:	48 ff c0             	inc    %rax
  6735f0:	48 3b 44 24 30       	cmp    0x30(%rsp),%rax
  6735f5:	eb 0d                	jmp    673604 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x7a4>
  6735f7:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6735fc:	48 ff c0             	inc    %rax
  6735ff:	48 3b 44 24 28       	cmp    0x28(%rsp),%rax
  673604:	0f 94 c2             	sete   %dl
  673607:	e9 a4 fd ff ff       	jmp    6733b0 <_RNvMNtNtCshQYmODNYIQG_6parley7editing8geometryINtB2_14CursorGeometryuE13geometries_atCs6tOD1aKRtN9_11gpui_canvas+0x550>
  67360c:	48 8d 0d c5 93 10 00 	lea    0x1093c5(%rip),%rcx        # 77c9d8 <anon.82ba7c80bfefe788d7fd53f5e69bad68.32.llvm.13034477518265263966>
  673613:	ff 15 d7 3c 11 00    	call   *0x113cd7(%rip)        # 7872f0 <_DYNAMIC+0x5e8>
  673619:	48 8d 0d b8 93 10 00 	lea    0x1093b8(%rip),%rcx        # 77c9d8 <anon.82ba7c80bfefe788d7fd53f5e69bad68.32.llvm.13034477518265263966>
  673620:	4c 89 c6             	mov    %r8,%rsi
  673623:	ff 15 c7 3c 11 00    	call   *0x113cc7(%rip)        # 7872f0 <_DYNAMIC+0x5e8>
  673629:	48 8d 15 68 94 10 00 	lea    0x109468(%rip),%rdx        # 77ca98 <anon.82ba7c80bfefe788d7fd53f5e69bad68.44.llvm.13034477518265263966>
  673630:	ff 15 32 3a 11 00    	call   *0x113a32(%rip)        # 787068 <_DYNAMIC+0x360>
  673636:	48 8d 15 23 93 10 00 	lea    0x109323(%rip),%rdx        # 77c960 <anon.82ba7c80bfefe788d7fd53f5e69bad68.9.llvm.13034477518265263966+0xa8>
  67363d:	ff 15 25 3a 11 00    	call   *0x113a25(%rip)        # 787068 <_DYNAMIC+0x360>
  673643:	4c 89 c7             	mov    %r8,%rdi
  673646:	48 8d 15 2b 93 10 00 	lea    0x10932b(%rip),%rdx        # 77c978 <anon.82ba7c80bfefe788d7fd53f5e69bad68.9.llvm.13034477518265263966+0xc0>
  67364d:	ff 15 15 3a 11 00    	call   *0x113a15(%rip)        # 787068 <_DYNAMIC+0x360>
  673653:	48 8d 15 3e 94 10 00 	lea    0x10943e(%rip),%rdx        # 77ca98 <anon.82ba7c80bfefe788d7fd53f5e69bad68.44.llvm.13034477518265263966>
  67365a:	4c 89 cf             	mov    %r9,%rdi
  67365d:	ff 15 05 3a 11 00    	call   *0x113a05(%rip)        # 787068 <_DYNAMIC+0x360>
  673663:	48 8d 15 56 93 10 00 	lea    0x109356(%rip),%rdx        # 77c9c0 <anon.82ba7c80bfefe788d7fd53f5e69bad68.30.llvm.13034477518265263966>
  67366a:	31 ff                	xor    %edi,%edi
  67366c:	31 f6                	xor    %esi,%esi
  67366e:	ff 15 f4 39 11 00    	call   *0x1139f4(%rip)        # 787068 <_DYNAMIC+0x360>
  673674:	48 8d 15 1d 94 10 00 	lea    0x10941d(%rip),%rdx        # 77ca98 <anon.82ba7c80bfefe788d7fd53f5e69bad68.44.llvm.13034477518265263966>
  67367b:	48 89 cf             	mov    %rcx,%rdi
  67367e:	ff 15 e4 39 11 00    	call   *0x1139e4(%rip)        # 787068 <_DYNAMIC+0x360>
