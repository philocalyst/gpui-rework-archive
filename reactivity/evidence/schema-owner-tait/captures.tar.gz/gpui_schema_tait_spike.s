	.file	"gpui_schema_tait_spike.959ae5b8d8f2bf82-cgu.0"
	.section	.text._RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECscQllm3UHxC0_22gpui_schema_tait_spike,"ax",@progbits
	.hidden	_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECscQllm3UHxC0_22gpui_schema_tait_spike
	.globl	_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECscQllm3UHxC0_22gpui_schema_tait_spike
	.p2align	4
	.type	_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECscQllm3UHxC0_22gpui_schema_tait_spike,@function
_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECscQllm3UHxC0_22gpui_schema_tait_spike:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	movq	%rdi, (%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.0(%rip), %rsi
	movq	%rsp, %rdi
	callq	*_RNvNtCs2AWtUsOyxgP_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECscQllm3UHxC0_22gpui_schema_tait_spike, .Lfunc_end0-_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECscQllm3UHxC0_22gpui_schema_tait_spike
	.cfi_endproc

	.section	.text.unlikely._RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTyyEBM_ECscQllm3UHxC0_22gpui_schema_tait_spike,"ax",@progbits
	.type	_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTyyEBM_ECscQllm3UHxC0_22gpui_schema_tait_spike,@function
_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTyyEBM_ECscQllm3UHxC0_22gpui_schema_tait_spike:
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	leaq	24(%rsp), %rsi
	movq	%rdi, (%rsi)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.2(%rip), %rax
	leaq	32(%rsp), %rcx
	movq	%rax, (%rcx)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.9(%rip), %rax
	movq	%rax, 8(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.1(%rip), %rdx
	xorl	%edi, %edi
	movq	%rdx, %r8
	xorl	%r9d, %r9d
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking19assert_failed_inner@GOTPCREL(%rip)
.Lfunc_end1:
	.size	_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTyyEBM_ECscQllm3UHxC0_22gpui_schema_tait_spike, .Lfunc_end1-_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTyyEBM_ECscQllm3UHxC0_22gpui_schema_tait_spike
	.cfi_endproc

	.section	.text._RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscQllm3UHxC0_22gpui_schema_tait_spike,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscQllm3UHxC0_22gpui_schema_tait_spike,@function
_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscQllm3UHxC0_22gpui_schema_tait_spike:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	callq	*%rdi
	#APP
	#NO_APP
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscQllm3UHxC0_22gpui_schema_tait_spike, .Lfunc_end2-_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscQllm3UHxC0_22gpui_schema_tait_spike
	.cfi_endproc

	.section	.text._RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CscQllm3UHxC0_22gpui_schema_tait_spike,"ax",@progbits
	.p2align	4
	.type	_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CscQllm3UHxC0_22gpui_schema_tait_spike,@function
_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CscQllm3UHxC0_22gpui_schema_tait_spike:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscQllm3UHxC0_22gpui_schema_tait_spike
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end3:
	.size	_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CscQllm3UHxC0_22gpui_schema_tait_spike, .Lfunc_end3-_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CscQllm3UHxC0_22gpui_schema_tait_spike
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCscQllm3UHxC0_22gpui_schema_tait_spike,"ax",@progbits
	.p2align	4
	.type	_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCscQllm3UHxC0_22gpui_schema_tait_spike,@function
_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCscQllm3UHxC0_22gpui_schema_tait_spike:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	(%rdi), %rdi
	callq	_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECscQllm3UHxC0_22gpui_schema_tait_spike
	xorl	%eax, %eax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end4:
	.size	_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCscQllm3UHxC0_22gpui_schema_tait_spike, .Lfunc_end4-_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCscQllm3UHxC0_22gpui_schema_tait_spike
	.cfi_endproc

	.section	.text._RNvCscQllm3UHxC0_22gpui_schema_tait_spike4main,"ax",@progbits
	.hidden	_RNvCscQllm3UHxC0_22gpui_schema_tait_spike4main
	.globl	_RNvCscQllm3UHxC0_22gpui_schema_tait_spike4main
	.p2align	4
	.type	_RNvCscQllm3UHxC0_22gpui_schema_tait_spike4main,@function
_RNvCscQllm3UHxC0_22gpui_schema_tait_spike4main:
	.cfi_startproc
	subq	$104, %rsp
	.cfi_def_cfa_offset 112
	movq	$7, 64(%rsp)
	movq	$11, 72(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.15(%rip), %rax
	movq	%rax, 80(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.13(%rip), %rax
	movq	%rax, 88(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.14(%rip), %rax
	movq	%rax, 96(%rsp)
	leaq	64(%rsp), %rdi
	callq	_RNvCscQllm3UHxC0_22gpui_schema_tait_spike5probe
	movq	%rax, (%rsp)
	movq	%rdx, 8(%rsp)
	cmpq	$11, %rdx
	sete	%cl
	cmpq	$7, %rax
	jne	.LBB5_1
	testb	%cl, %cl
	je	.LBB5_4
.LBB5_3:
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.4(%rip), %rax
	movq	%rax, (%rsp)
	movq	_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt@GOTPCREL(%rip), %rax
	movq	%rax, 8(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.5(%rip), %rcx
	movq	%rcx, 16(%rsp)
	movq	%rax, 24(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.6(%rip), %rcx
	movq	%rcx, 32(%rsp)
	movq	%rax, 40(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.7(%rip), %rcx
	movq	%rcx, 48(%rsp)
	movq	%rax, 56(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.8(%rip), %rdi
	movq	%rsp, %rsi
	callq	*_RNvNtNtCs2AWtUsOyxgP_3std2io5stdio6__print@GOTPCREL(%rip)
	addq	$104, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB5_1:
	.cfi_def_cfa_offset 112
	xorl	%ecx, %ecx
	testb	%cl, %cl
	jne	.LBB5_3
.LBB5_4:
	movq	%rsp, %rdi
	callq	_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedTyyEBM_ECscQllm3UHxC0_22gpui_schema_tait_spike
.Lfunc_end5:
	.size	_RNvCscQllm3UHxC0_22gpui_schema_tait_spike4main, .Lfunc_end5-_RNvCscQllm3UHxC0_22gpui_schema_tait_spike4main
	.cfi_endproc

	.section	.text._RNvCscQllm3UHxC0_22gpui_schema_tait_spike5probe,"ax",@progbits
	.p2align	4
	.type	_RNvCscQllm3UHxC0_22gpui_schema_tait_spike5probe,@function
_RNvCscQllm3UHxC0_22gpui_schema_tait_spike5probe:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	movq	16(%rdi), %rax
	cmpl	$1, 8(%rax)
	jne	.LBB6_1
	movq	%rbx, %rdi
	callq	*(%rax)
	movq	24(%rbx), %rcx
	cmpl	$2, 8(%rcx)
	jne	.LBB6_7
	movq	(%rax), %r14
	movq	32(%rbx), %r15
	movq	%rbx, %rdi
	callq	*(%rcx)
	cmpl	$1, 8(%r15)
	jne	.LBB6_7
	movq	%rax, %rdi
	callq	*(%r15)
	movq	(%rax), %rdx
	movq	%r14, %rax
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB6_7:
	.cfi_def_cfa_offset 32
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.11(%rip), %rdi
	callq	*_RNvNtCs4NRVxsYgnAr_4core6option13unwrap_failed@GOTPCREL(%rip)
.LBB6_1:
	movq	24(%rbx), %rax
	cmpl	$1, 8(%rax)
	jne	.LBB6_3
	movq	%rbx, %rdi
	callq	*(%rax)
.LBB6_3:
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.10(%rip), %rdi
	callq	*_RNvNtCs4NRVxsYgnAr_4core6option13unwrap_failed@GOTPCREL(%rip)
.Lfunc_end6:
	.size	_RNvCscQllm3UHxC0_22gpui_schema_tait_spike5probe, .Lfunc_end6-_RNvCscQllm3UHxC0_22gpui_schema_tait_spike5probe
	.cfi_endproc

	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTyyENtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTyyENtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike,@function
_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTyyENtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$48, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	(%rdi), %r14
	leaq	24(%rsp), %rbx
	movl	$1, %edx
	movq	%rbx, %rdi
	xorl	%ecx, %ecx
	callq	*_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter11debug_tuple@GOTPCREL(%rip)
	movq	%r14, 8(%rsp)
	addq	$8, %r14
	movq	%r14, 16(%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.12(%rip), %r14
	movq	_RNvMs2_NtNtCs4NRVxsYgnAr_4core3fmt8buildersNtB5_10DebugTuple5field@GOTPCREL(%rip), %r15
	leaq	8(%rsp), %rsi
	movq	%rbx, %rdi
	movq	%r14, %rdx
	callq	*%r15
	leaq	16(%rsp), %rsi
	movq	%rbx, %rdi
	movq	%r14, %rdx
	callq	*%r15
	movq	%rbx, %rdi
	callq	*_RNvMs2_NtNtCs4NRVxsYgnAr_4core3fmt8buildersNtB5_10DebugTuple6finish@GOTPCREL(%rip)
	addq	$48, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end7:
	.size	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTyyENtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike, .Lfunc_end7-_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTyyENtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike
	.cfi_endproc

	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike,@function
_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike:
	.cfi_startproc
	movq	(%rdi), %rdi
	movl	16(%rsi), %eax
	testl	$33554432, %eax
	jne	.LBB8_3
	testl	$67108864, %eax
	jne	.LBB8_2
	jmpq	*_RNvXsd_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impyNtB9_7Display3fmt@GOTPCREL(%rip)
.LBB8_3:
	jmpq	*_RNvXsC_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB8_2:
	jmpq	*_RNvXsE_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Lfunc_end8:
	.size	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike, .Lfunc_end8-_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike
	.cfi_endproc

	.section	.text._RNvYNCNvMs3_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_5Child5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_,"ax",@progbits
	.p2align	4
	.type	_RNvYNCNvMs3_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_5Child5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_,@function
_RNvYNCNvMs3_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_5Child5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_:
	.cfi_startproc
	movq	%rdi, %rax
	retq
.Lfunc_end9:
	.size	_RNvYNCNvMs3_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_5Child5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_, .Lfunc_end9-_RNvYNCNvMs3_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_5Child5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_
	.cfi_endproc

	.section	.text._RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5CHILD0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_,"ax",@progbits
	.p2align	4
	.type	_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5CHILD0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_,@function
_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5CHILD0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_:
	.cfi_startproc
	leaq	8(%rdi), %rax
	retq
.Lfunc_end10:
	.size	_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5CHILD0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_, .Lfunc_end10-_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5CHILD0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_
	.cfi_endproc

	.section	.text._RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_,"ax",@progbits
	.p2align	4
	.type	_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_,@function
_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_:
	.cfi_startproc
	movq	%rdi, %rax
	retq
.Lfunc_end11:
	.size	_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_, .Lfunc_end11-_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.p2align	4
	.type	main,@function
main:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rcx
	movslq	%edi, %rdx
	leaq	_RNvCscQllm3UHxC0_22gpui_schema_tait_spike4main(%rip), %rax
	movq	%rax, (%rsp)
	leaq	.Lanon.bccc9e539d9a52aae869b87444ed639e.0(%rip), %rsi
	movq	%rsp, %rdi
	xorl	%r8d, %r8d
	callq	*_RNvNtCs2AWtUsOyxgP_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end12:
	.size	main, .Lfunc_end12-main
	.cfi_endproc

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.0,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.0,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCscQllm3UHxC0_22gpui_schema_tait_spike
	.quad	_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CscQllm3UHxC0_22gpui_schema_tait_spike
	.quad	_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0CscQllm3UHxC0_22gpui_schema_tait_spike
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.0, 48

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.1,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.1,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRTyyENtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.1, 32

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.2,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.2:
	.asciz	"\007\000\000\000\000\000\000\000\013\000\000\000\000\000\000"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.2, 16

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.3,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.bccc9e539d9a52aae869b87444ed639e.3:
	.asciz	"/tmp/gpui-schema-tait-spike.rs"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.3, 31

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.4,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.4:
	.zero	8
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.4, 8

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.5,@object
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.5:
	.asciz	"\b\000\000\000\000\000\000"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.5, 8

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.6,@object
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.6:
	.asciz	"\030\000\000\000\000\000\000"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.6, 8

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.7,@object
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.7:
	.asciz	"(\000\000\000\000\000\000"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.7, 8

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.8,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.bccc9e539d9a52aae869b87444ed639e.8:
	.asciz	"\rschema_blank=\300\016,schema_child=\300\f,schema_app=\300\r,runtime_app=\300\001\n"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.8, 63

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.9,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.9,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.9:
	.quad	.Lanon.bccc9e539d9a52aae869b87444ed639e.3
	.asciz	"\036\000\000\000\000\000\000\000|\000\000\000\005\000\000"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.9, 24

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.10,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.10,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.10:
	.quad	.Lanon.bccc9e539d9a52aae869b87444ed639e.3
	.asciz	"\036\000\000\000\000\000\000\000s\000\000\000!\000\000"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.10, 24

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.11,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.11,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.11:
	.quad	.Lanon.bccc9e539d9a52aae869b87444ed639e.3
	.asciz	"\036\000\000\000\000\000\000\000t\000\000\000$\000\000"
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.11, 24

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.12,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.12,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.12:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCscQllm3UHxC0_22gpui_schema_tait_spike
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.12, 32

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.13,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.13,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.13:
	.quad	_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5CHILD0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_
	.asciz	"\002\000\000"
	.zero	4
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.13, 16

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.14,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.14,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.14:
	.quad	_RNvYNCNvMs3_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_5Child5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_
	.asciz	"\001\000\000"
	.zero	4
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.14, 16

	.type	.Lanon.bccc9e539d9a52aae869b87444ed639e.15,@object
	.section	.data.rel.ro..Lanon.bccc9e539d9a52aae869b87444ed639e.15,"aw",@progbits
	.p2align	3, 0x0
.Lanon.bccc9e539d9a52aae869b87444ed639e.15:
	.quad	_RNvYNCNvMs5_CscQllm3UHxC0_22gpui_schema_tait_spikeNtBa_3App5VALUE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceTRBM_EE9call_onceBa_
	.asciz	"\001\000\000"
	.zero	4
	.size	.Lanon.bccc9e539d9a52aae869b87444ed639e.15, 16

	.ident	"rustc version 1.97.1 (8bab26f4f 2026-07-14)"
	.section	".note.GNU-stack","",@progbits
