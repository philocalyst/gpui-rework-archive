
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006eb710 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_>:
  6eb710:	53                   	push   %rbx
  6eb711:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  6eb718:	48 89 fb             	mov    %rdi,%rbx
  6eb71b:	48 8b 06             	mov    (%rsi),%rax
  6eb71e:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6eb722:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6eb726:	48 85 ff             	test   %rdi,%rdi
  6eb729:	0f 84 e3 01 00 00    	je     6eb912 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x202>
  6eb72f:	48 8b 8c c8 c8 01 00 	mov    0x1c8(%rax,%rcx,8),%rcx
  6eb736:	00 
  6eb737:	48 89 f8             	mov    %rdi,%rax
  6eb73a:	48 ff c8             	dec    %rax
  6eb73d:	0f 84 cb 00 00 00    	je     6eb80e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0xfe>
  6eb743:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6eb747:	48 89 c6             	mov    %rax,%rsi
  6eb74a:	48 83 e6 07          	and    $0x7,%rsi
  6eb74e:	74 2b                	je     6eb77b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x6b>
  6eb750:	45 31 c0             	xor    %r8d,%r8d
  6eb753:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6eb75a:	84 00 00 00 00 00 
  6eb760:	44 0f b7 89 c2 01 00 	movzwl 0x1c2(%rcx),%r9d
  6eb767:	00 
  6eb768:	4a 8b 8c c9 c8 01 00 	mov    0x1c8(%rcx,%r9,8),%rcx
  6eb76f:	00 
  6eb770:	49 ff c0             	inc    %r8
  6eb773:	4c 39 c6             	cmp    %r8,%rsi
  6eb776:	75 e8                	jne    6eb760 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x50>
  6eb778:	4c 29 c0             	sub    %r8,%rax
  6eb77b:	48 83 ff 07          	cmp    $0x7,%rdi
  6eb77f:	0f 82 89 00 00 00    	jb     6eb80e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0xfe>
  6eb785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6eb78c:	00 00 00 00 
  6eb790:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb797:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb79e:	00 
  6eb79f:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb7a6:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb7ad:	00 
  6eb7ae:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb7b5:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb7bc:	00 
  6eb7bd:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb7c4:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb7cb:	00 
  6eb7cc:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb7d3:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb7da:	00 
  6eb7db:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb7e2:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb7e9:	00 
  6eb7ea:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb7f1:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb7f8:	00 
  6eb7f9:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb800:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb807:	00 
  6eb808:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6eb80c:	75 82                	jne    6eb790 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x80>
  6eb80e:	0f b7 81 c2 01 00 00 	movzwl 0x1c2(%rcx),%eax
  6eb815:	48 ff c8             	dec    %rax
  6eb818:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6eb81d:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6eb824:	00 00 
  6eb826:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6eb82b:	48 89 e7             	mov    %rsp,%rdi
  6eb82e:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6eb833:	e8 78 5b 00 00       	call   6f13b0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>
  6eb838:	48 8b 3c 24          	mov    (%rsp),%rdi
  6eb83c:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6eb841:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6eb846:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6eb84b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  6eb850:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6eb855:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6eb85a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6eb85f:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  6eb866:	48 39 ce             	cmp    %rcx,%rsi
  6eb869:	72 1f                	jb     6eb88a <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x17a>
  6eb86b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6eb870:	0f b7 b0 c0 01 00 00 	movzwl 0x1c0(%rax),%esi
  6eb877:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6eb87e:	48 ff c2             	inc    %rdx
  6eb881:	66 3b b0 c2 01 00 00 	cmp    0x1c2(%rax),%si
  6eb888:	73 e6                	jae    6eb870 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x160>
  6eb88a:	49 89 f0             	mov    %rsi,%r8
  6eb88d:	49 c1 e0 05          	shl    $0x5,%r8
  6eb891:	48 8b 8c f0 68 01 00 	mov    0x168(%rax,%rsi,8),%rcx
  6eb898:	00 
  6eb899:	48 89 bc f0 68 01 00 	mov    %rdi,0x168(%rax,%rsi,8)
  6eb8a0:	00 
  6eb8a1:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6eb8a6:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6eb8ac:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6eb8b1:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6eb8b5:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6eb8ba:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6eb8bf:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6eb8c4:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6eb8ca:	48 85 d2             	test   %rdx,%rdx
  6eb8cd:	74 6c                	je     6eb93b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x22b>
  6eb8cf:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  6eb8d3:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6eb8da:	48 89 d6             	mov    %rdx,%rsi
  6eb8dd:	48 83 e6 07          	and    $0x7,%rsi
  6eb8e1:	74 5d                	je     6eb940 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x230>
  6eb8e3:	45 31 c9             	xor    %r9d,%r9d
  6eb8e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6eb8ed:	00 00 00 
  6eb8f0:	48 8b 07             	mov    (%rdi),%rax
  6eb8f3:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6eb8fa:	49 ff c1             	inc    %r9
  6eb8fd:	4c 39 ce             	cmp    %r9,%rsi
  6eb900:	75 ee                	jne    6eb8f0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x1e0>
  6eb902:	49 89 d0             	mov    %rdx,%r8
  6eb905:	4d 29 c8             	sub    %r9,%r8
  6eb908:	31 f6                	xor    %esi,%esi
  6eb90a:	48 83 fa 08          	cmp    $0x8,%rdx
  6eb90e:	73 40                	jae    6eb950 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x240>
  6eb910:	eb 7f                	jmp    6eb991 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6eb912:	48 89 04 24          	mov    %rax,(%rsp)
  6eb916:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6eb91d:	00 00 
  6eb91f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6eb924:	48 89 e6             	mov    %rsp,%rsi
  6eb927:	48 89 df             	mov    %rbx,%rdi
  6eb92a:	e8 81 5a 00 00       	call   6f13b0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>
  6eb92f:	48 89 d8             	mov    %rbx,%rax
  6eb932:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6eb939:	5b                   	pop    %rbx
  6eb93a:	c3                   	ret
  6eb93b:	48 ff c6             	inc    %rsi
  6eb93e:	eb 51                	jmp    6eb991 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6eb940:	49 89 d0             	mov    %rdx,%r8
  6eb943:	31 f6                	xor    %esi,%esi
  6eb945:	48 83 fa 08          	cmp    $0x8,%rdx
  6eb949:	72 46                	jb     6eb991 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6eb94b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6eb950:	48 8b 07             	mov    (%rdi),%rax
  6eb953:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb95a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb961:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb968:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb96f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb976:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb97d:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb984:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6eb98b:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6eb98f:	75 bf                	jne    6eb950 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x240>
  6eb991:	48 89 0b             	mov    %rcx,(%rbx)
  6eb994:	0f 28 04 24          	movaps (%rsp),%xmm0
  6eb998:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6eb99d:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6eb9a1:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6eb9a5:	48 89 43 28          	mov    %rax,0x28(%rbx)
  6eb9a9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
  6eb9b0:	00 
  6eb9b1:	48 89 73 38          	mov    %rsi,0x38(%rbx)
  6eb9b5:	48 89 d8             	mov    %rbx,%rax
  6eb9b8:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6eb9bf:	5b                   	pop    %rbx
  6eb9c0:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
