
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006f1c70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>:
  6f1c70:	55                   	push   %rbp
  6f1c71:	41 57                	push   %r15
  6f1c73:	41 56                	push   %r14
  6f1c75:	41 55                	push   %r13
  6f1c77:	41 54                	push   %r12
  6f1c79:	53                   	push   %rbx
  6f1c7a:	48 81 ec 58 01 00 00 	sub    $0x158,%rsp
  6f1c81:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f1c88:	00 
  6f1c89:	49 89 f7             	mov    %rsi,%r15
  6f1c8c:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  6f1c93:	00 
  6f1c94:	48 8b 2e             	mov    (%rsi),%rbp
  6f1c97:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f1c9b:	0f b7 9d c2 01 00 00 	movzwl 0x1c2(%rbp),%ebx
  6f1ca2:	4a 8d bc ed 68 01 00 	lea    0x168(%rbp,%r13,8),%rdi
  6f1ca9:	00 
  6f1caa:	4a 8b 84 ed 68 01 00 	mov    0x168(%rbp,%r13,8),%rax
  6f1cb1:	00 
  6f1cb2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f1cb7:	4a 8d 34 ed 70 01 00 	lea    0x170(,%r13,8),%rsi
  6f1cbe:	00 
  6f1cbf:	48 01 ee             	add    %rbp,%rsi
  6f1cc2:	4d 89 ec             	mov    %r13,%r12
  6f1cc5:	49 f7 d4             	not    %r12
  6f1cc8:	49 01 dc             	add    %rbx,%r12
  6f1ccb:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
  6f1cd2:	00 
  6f1cd3:	4c 8b 35 0e 60 3f 00 	mov    0x3f600e(%rip),%r14        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f1cda:	41 ff d6             	call   *%r14
  6f1cdd:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  6f1ce2:	4c 89 e8             	mov    %r13,%rax
  6f1ce5:	48 c1 e0 05          	shl    $0x5,%rax
  6f1ce9:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f1ced:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f1cf2:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f1cf7:	0f 11 8c 24 e8 00 00 	movups %xmm1,0xe8(%rsp)
  6f1cfe:	00 
  6f1cff:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f1d06:	00 
  6f1d07:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f1d0b:	48 83 c6 20          	add    $0x20,%rsi
  6f1d0f:	49 c1 e4 05          	shl    $0x5,%r12
  6f1d13:	4c 89 e2             	mov    %r12,%rdx
  6f1d16:	41 ff d6             	call   *%r14
  6f1d19:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f1d1c:	66 89 85 c2 01 00 00 	mov    %ax,0x1c2(%rbp)
  6f1d23:	4d 8b 67 08          	mov    0x8(%r15),%r12
  6f1d27:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f1d2c:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f1d33:	00 
  6f1d34:	66 83 f8 04          	cmp    $0x4,%ax
  6f1d38:	0f 87 55 01 00 00    	ja     6f1e93 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f1d3e:	48 8b 85 60 01 00 00 	mov    0x160(%rbp),%rax
  6f1d45:	48 85 c0             	test   %rax,%rax
  6f1d48:	0f 84 03 01 00 00    	je     6f1e51 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1e1>
  6f1d4e:	49 8d 4c 24 01       	lea    0x1(%r12),%rcx
  6f1d53:	0f b7 95 c0 01 00 00 	movzwl 0x1c0(%rbp),%edx
  6f1d5a:	48 85 d2             	test   %rdx,%rdx
  6f1d5d:	74 5e                	je     6f1dbd <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x14d>
  6f1d5f:	48 8b b4 d0 c0 01 00 	mov    0x1c0(%rax,%rdx,8),%rsi
  6f1d66:	00 
  6f1d67:	48 ff ca             	dec    %rdx
  6f1d6a:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f1d6f:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f1d74:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  6f1d79:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  6f1d7e:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
  6f1d83:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f1d88:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  6f1d8d:	0f b7 86 c2 01 00 00 	movzwl 0x1c2(%rsi),%eax
  6f1d94:	01 c3                	add    %eax,%ebx
  6f1d96:	83 fb 0c             	cmp    $0xc,%ebx
  6f1d99:	0f 83 80 00 00 00    	jae    6f1e1f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1af>
  6f1d9f:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  6f1da4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  6f1da9:	ba 01 00 00 00       	mov    $0x1,%edx
  6f1dae:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f1db3:	e8 a8 a2 ff ff       	call   6ec060 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1db8:	e9 a8 00 00 00       	jmp    6f1e65 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f5>
  6f1dbd:	66 83 b8 c2 01 00 00 	cmpw   $0x0,0x1c2(%rax)
  6f1dc4:	00 
  6f1dc5:	0f 84 d4 06 00 00    	je     6f249f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x82f>
  6f1dcb:	48 8b 90 d0 01 00 00 	mov    0x1d0(%rax),%rdx
  6f1dd2:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f1dd7:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f1ddc:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6f1de3:	00 00 
  6f1de5:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6f1dea:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
  6f1def:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
  6f1df4:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  6f1df9:	0f b7 82 c2 01 00 00 	movzwl 0x1c2(%rdx),%eax
  6f1e00:	01 c3                	add    %eax,%ebx
  6f1e02:	83 fb 0c             	cmp    $0xc,%ebx
  6f1e05:	73 3b                	jae    6f1e42 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1d2>
  6f1e07:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  6f1e0c:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  6f1e11:	31 d2                	xor    %edx,%edx
  6f1e13:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f1e18:	e8 43 a2 ff ff       	call   6ec060 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1e1d:	eb 46                	jmp    6f1e65 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f5>
  6f1e1f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f1e24:	be 01 00 00 00       	mov    $0x1,%esi
  6f1e29:	e8 a2 15 00 00       	call   6f33d0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1e2e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1e33:	48 ff c0             	inc    %rax
  6f1e36:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
  6f1e3b:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  6f1e40:	eb 1e                	jmp    6f1e60 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f0>
  6f1e42:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f1e47:	be 01 00 00 00       	mov    $0x1,%esi
  6f1e4c:	e8 bf 18 00 00       	call   6f3710 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1e51:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
  6f1e56:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  6f1e5b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1e60:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f1e65:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
  6f1e6a:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  6f1e6f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f1e74:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6f1e79:	4c 8b b5 60 01 00 00 	mov    0x160(%rbp),%r14
  6f1e80:	4d 85 f6             	test   %r14,%r14
  6f1e83:	74 0e                	je     6f1e93 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f1e85:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f1e8c:	00 
  6f1e8d:	66 83 f8 04          	cmp    $0x4,%ax
  6f1e91:	76 5a                	jbe    6f1eed <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x27d>
  6f1e93:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  6f1e9a:	00 
  6f1e9b:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  6f1ea2:	00 
  6f1ea3:	48 89 42 20          	mov    %rax,0x20(%rdx)
  6f1ea7:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6f1eae:	00 
  6f1eaf:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  6f1eb6:	00 
  6f1eb7:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6f1ebe:	00 
  6f1ebf:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f1ec3:	48 89 02             	mov    %rax,(%rdx)
  6f1ec6:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f1eca:	48 89 6a 28          	mov    %rbp,0x28(%rdx)
  6f1ece:	4c 89 62 30          	mov    %r12,0x30(%rdx)
  6f1ed2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1ed7:	48 89 42 38          	mov    %rax,0x38(%rdx)
  6f1edb:	48 81 c4 58 01 00 00 	add    $0x158,%rsp
  6f1ee2:	5b                   	pop    %rbx
  6f1ee3:	41 5c                	pop    %r12
  6f1ee5:	41 5d                	pop    %r13
  6f1ee7:	41 5e                	pop    %r14
  6f1ee9:	41 5f                	pop    %r15
  6f1eeb:	5d                   	pop    %rbp
  6f1eec:	c3                   	ret
  6f1eed:	4d 8d 6c 24 01       	lea    0x1(%r12),%r13
  6f1ef2:	48 8d 0d a7 79 3c 00 	lea    0x3c79a7(%rip),%rcx        # ab98a0 <__frame_dummy_init_array_entry+0x98>
  6f1ef9:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6f1f00:	00 
  6f1f01:	48 8d 0d a4 16 97 ff 	lea    -0x68e95c(%rip),%rcx        # 635ac <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f1f08:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  6f1f0d:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  6f1f14:	00 
  6f1f15:	4c 89 a4 24 88 00 00 	mov    %r12,0x88(%rsp)
  6f1f1c:	00 
  6f1f1d:	eb 21                	jmp    6f1f40 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2d0>
  6f1f1f:	90                   	nop
  6f1f20:	ba 08 00 00 00       	mov    $0x8,%edx
  6f1f25:	4c 89 ff             	mov    %r15,%rdi
  6f1f28:	ff 15 9a 5d 3f 00    	call   *0x3f5d9a(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  6f1f2e:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f1f35:	00 
  6f1f36:	66 83 f8 04          	cmp    $0x4,%ax
  6f1f3a:	0f 87 53 ff ff ff    	ja     6f1e93 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f1f40:	4c 89 f1             	mov    %r14,%rcx
  6f1f43:	0f b7 c0             	movzwl %ax,%eax
  6f1f46:	4d 8b b6 60 01 00 00 	mov    0x160(%r14),%r14
  6f1f4d:	4d 85 f6             	test   %r14,%r14
  6f1f50:	0f 84 96 04 00 00    	je     6f23ec <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x77c>
  6f1f56:	4c 89 ee             	mov    %r13,%rsi
  6f1f59:	49 8d 7d 01          	lea    0x1(%r13),%rdi
  6f1f5d:	44 0f b7 b9 c0 01 00 	movzwl 0x1c0(%rcx),%r15d
  6f1f64:	00 
  6f1f65:	4d 85 ff             	test   %r15,%r15
  6f1f68:	48 89 bc 24 c8 00 00 	mov    %rdi,0xc8(%rsp)
  6f1f6f:	00 
  6f1f70:	0f 84 8a 00 00 00    	je     6f2000 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x390>
  6f1f76:	4b 8b 9c fe c0 01 00 	mov    0x1c0(%r14,%r15,8),%rbx
  6f1f7d:	00 
  6f1f7e:	49 ff cf             	dec    %r15
  6f1f81:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  6f1f88:	00 
  6f1f89:	48 89 bc 24 00 01 00 	mov    %rdi,0x100(%rsp)
  6f1f90:	00 
  6f1f91:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
  6f1f98:	00 
  6f1f99:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
  6f1fa0:	00 
  6f1fa1:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
  6f1fa8:	00 
  6f1fa9:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6f1fb0:	00 
  6f1fb1:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
  6f1fb8:	00 
  6f1fb9:	0f b7 b3 c2 01 00 00 	movzwl 0x1c2(%rbx),%esi
  6f1fc0:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f1fc3:	ff c2                	inc    %edx
  6f1fc5:	83 fa 0c             	cmp    $0xc,%edx
  6f1fc8:	0f 83 86 04 00 00    	jae    6f2454 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x7e4>
  6f1fce:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f1fd5:	00 
  6f1fd6:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f1fda:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  6f1fdf:	48 89 f5             	mov    %rsi,%rbp
  6f1fe2:	48 01 c6             	add    %rax,%rsi
  6f1fe5:	48 ff c6             	inc    %rsi
  6f1fe8:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6f1fed:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f1ff2:	e9 7d 00 00 00       	jmp    6f2074 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x404>
  6f1ff7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f1ffe:	00 00 
  6f2000:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f2007:	00 
  6f2008:	66 85 d2             	test   %dx,%dx
  6f200b:	0f 84 8e 04 00 00    	je     6f249f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x82f>
  6f2011:	4d 8b 86 d0 01 00 00 	mov    0x1d0(%r14),%r8
  6f2018:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
  6f201d:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  6f2022:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6f2029:	00 00 
  6f202b:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6f2030:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6f2035:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
  6f203a:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6f203f:	45 0f b7 88 c2 01 00 	movzwl 0x1c2(%r8),%r9d
  6f2046:	00 
  6f2047:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f204b:	48 ff c6             	inc    %rsi
  6f204e:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f2052:	0f 83 16 04 00 00    	jae    6f246e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x7fe>
  6f2058:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f205c:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  6f2061:	48 89 cb             	mov    %rcx,%rbx
  6f2064:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  6f2069:	45 31 ff             	xor    %r15d,%r15d
  6f206c:	48 89 c5             	mov    %rax,%rbp
  6f206f:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  6f2074:	0f b7 c2             	movzwl %dx,%eax
  6f2077:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f207e:	00 
  6f207f:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
  6f2086:	00 
  6f2087:	66 89 b3 c2 01 00 00 	mov    %si,0x1c2(%rbx)
  6f208e:	4b 8d 3c fe          	lea    (%r14,%r15,8),%rdi
  6f2092:	48 81 c7 68 01 00 00 	add    $0x168,%rdi
  6f2099:	4f 8b ac fe 68 01 00 	mov    0x168(%r14,%r15,8),%r13
  6f20a0:	00 
  6f20a1:	4b 8d 34 fe          	lea    (%r14,%r15,8),%rsi
  6f20a5:	48 81 c6 70 01 00 00 	add    $0x170,%rsi
  6f20ac:	4d 89 fc             	mov    %r15,%r12
  6f20af:	49 f7 d4             	not    %r12
  6f20b2:	49 01 c4             	add    %rax,%r12
  6f20b5:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
  6f20bc:	00 
  6f20bd:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  6f20c4:	00 
  6f20c5:	48 8b 05 1c 5c 3f 00 	mov    0x3f5c1c(%rip),%rax        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f20cc:	ff d0                	call   *%rax
  6f20ce:	4c 89 ac eb 68 01 00 	mov    %r13,0x168(%rbx,%rbp,8)
  6f20d5:	00 
  6f20d6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f20db:	48 8d b0 68 01 00 00 	lea    0x168(%rax),%rsi
  6f20e2:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f20e7:	48 8d bc c3 68 01 00 	lea    0x168(%rbx,%rax,8),%rdi
  6f20ee:	00 
  6f20ef:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f20f4:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f20fb:	4c 8b 2d ee 5b 3f 00 	mov    0x3f5bee(%rip),%r13        # ae7cf0 <memcpy@GLIBC_2.14>
  6f2102:	41 ff d5             	call   *%r13
  6f2105:	4c 89 f8             	mov    %r15,%rax
  6f2108:	48 c1 e0 05          	shl    $0x5,%rax
  6f210c:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f2110:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f2115:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f211b:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  6f2122:	00 
  6f2123:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  6f212a:	00 
  6f212b:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f212f:	48 83 c6 20          	add    $0x20,%rsi
  6f2133:	49 c1 e4 05          	shl    $0x5,%r12
  6f2137:	4c 89 e2             	mov    %r12,%rdx
  6f213a:	4c 8b 2d a7 5b 3f 00 	mov    0x3f5ba7(%rip),%r13        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f2141:	41 ff d5             	call   *%r13
  6f2144:	48 89 ac 24 b0 00 00 	mov    %rbp,0xb0(%rsp)
  6f214b:	00 
  6f214c:	c1 e5 05             	shl    $0x5,%ebp
  6f214f:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  6f2156:	00 
  6f2157:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
  6f215e:	00 
  6f215f:	0f 11 04 2b          	movups %xmm0,(%rbx,%rbp,1)
  6f2163:	0f 11 4c 2b 10       	movups %xmm1,0x10(%rbx,%rbp,1)
  6f2168:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6f216d:	c1 e7 05             	shl    $0x5,%edi
  6f2170:	48 01 df             	add    %rbx,%rdi
  6f2173:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f2178:	c1 e2 05             	shl    $0x5,%edx
  6f217b:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f2180:	ff 15 6a 5b 3f 00    	call   *0x3f5b6a(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  6f2186:	4d 8d 67 01          	lea    0x1(%r15),%r12
  6f218a:	4b 8d 3c fe          	lea    (%r14,%r15,8),%rdi
  6f218e:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6f2195:	4b 8d 34 fe          	lea    (%r14,%r15,8),%rsi
  6f2199:	48 81 c6 d8 01 00 00 	add    $0x1d8,%rsi
  6f21a0:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  6f21a7:	00 
  6f21a8:	41 ff d5             	call   *%r13
  6f21ab:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6f21b2:	00 
  6f21b3:	4c 39 e6             	cmp    %r12,%rsi
  6f21b6:	4c 8b ac 24 c8 00 00 	mov    0xc8(%rsp),%r13
  6f21bd:	00 
  6f21be:	0f 86 c6 00 00 00    	jbe    6f228a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f21c4:	89 f1                	mov    %esi,%ecx
  6f21c6:	44 29 e1             	sub    %r12d,%ecx
  6f21c9:	83 e1 03             	and    $0x3,%ecx
  6f21cc:	0f 84 fe 01 00 00    	je     6f23d0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x760>
  6f21d2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f21d9:	1f 84 00 00 00 00 00 
  6f21e0:	49 8d 44 24 01       	lea    0x1(%r12),%rax
  6f21e5:	4b 8b 94 e6 c8 01 00 	mov    0x1c8(%r14,%r12,8),%rdx
  6f21ec:	00 
  6f21ed:	4c 89 b2 60 01 00 00 	mov    %r14,0x160(%rdx)
  6f21f4:	66 44 89 a2 c0 01 00 	mov    %r12w,0x1c0(%rdx)
  6f21fb:	00 
  6f21fc:	49 89 c4             	mov    %rax,%r12
  6f21ff:	48 ff c9             	dec    %rcx
  6f2202:	75 dc                	jne    6f21e0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x570>
  6f2204:	49 f7 df             	neg    %r15
  6f2207:	4a 8d 0c 3e          	lea    (%rsi,%r15,1),%rcx
  6f220b:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f220f:	83 f9 03             	cmp    $0x3,%ecx
  6f2212:	72 76                	jb     6f228a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f2214:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f221b:	00 00 00 00 00 
  6f2220:	49 8b 8c c6 c8 01 00 	mov    0x1c8(%r14,%rax,8),%rcx
  6f2227:	00 
  6f2228:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f222f:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f2236:	49 8b 8c c6 d0 01 00 	mov    0x1d0(%r14,%rax,8),%rcx
  6f223d:	00 
  6f223e:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f2245:	8d 50 01             	lea    0x1(%rax),%edx
  6f2248:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f224f:	49 8b 8c c6 d8 01 00 	mov    0x1d8(%r14,%rax,8),%rcx
  6f2256:	00 
  6f2257:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f225e:	8d 50 02             	lea    0x2(%rax),%edx
  6f2261:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f2268:	49 8b 8c c6 e0 01 00 	mov    0x1e0(%r14,%rax,8),%rcx
  6f226f:	00 
  6f2270:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f2277:	8d 50 03             	lea    0x3(%rax),%edx
  6f227a:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f2281:	48 83 c0 04          	add    $0x4,%rax
  6f2285:	48 39 f0             	cmp    %rsi,%rax
  6f2288:	75 96                	jne    6f2220 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x5b0>
  6f228a:	66 41 ff 8e c2 01 00 	decw   0x1c2(%r14)
  6f2291:	00 
  6f2292:	be c8 01 00 00       	mov    $0x1c8,%esi
  6f2297:	49 83 fd 02          	cmp    $0x2,%r13
  6f229b:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  6f22a2:	00 
  6f22a3:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
  6f22aa:	00 
  6f22ab:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  6f22b0:	0f 82 6a fc ff ff    	jb     6f1f20 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f22b6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f22bb:	48 ff c2             	inc    %rdx
  6f22be:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f22c5:	00 
  6f22c6:	48 2b 84 24 b0 00 00 	sub    0xb0(%rsp),%rax
  6f22cd:	00 
  6f22ce:	48 39 c2             	cmp    %rax,%rdx
  6f22d1:	0f 85 ae 01 00 00    	jne    6f2485 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x815>
  6f22d7:	48 8d 83 c8 01 00 00 	lea    0x1c8(%rbx),%rax
  6f22de:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  6f22e3:	4a 8d 3c e0          	lea    (%rax,%r12,8),%rdi
  6f22e7:	49 8d b7 c8 01 00 00 	lea    0x1c8(%r15),%rsi
  6f22ee:	c1 e2 03             	shl    $0x3,%edx
  6f22f1:	ff 15 f9 59 3f 00    	call   *0x3f59f9(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  6f22f7:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  6f22fe:	00 
  6f22ff:	89 f9                	mov    %edi,%ecx
  6f2301:	44 29 e1             	sub    %r12d,%ecx
  6f2304:	ff c1                	inc    %ecx
  6f2306:	4c 89 e0             	mov    %r12,%rax
  6f2309:	83 e1 03             	and    $0x3,%ecx
  6f230c:	74 34                	je     6f2342 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6d2>
  6f230e:	4c 89 e2             	mov    %r12,%rdx
  6f2311:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f2318:	0f 1f 84 00 00 00 00 
  6f231f:	00 
  6f2320:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f2324:	48 8b b4 d3 c8 01 00 	mov    0x1c8(%rbx,%rdx,8),%rsi
  6f232b:	00 
  6f232c:	48 89 9e 60 01 00 00 	mov    %rbx,0x160(%rsi)
  6f2333:	66 89 96 c0 01 00 00 	mov    %dx,0x1c0(%rsi)
  6f233a:	48 89 c2             	mov    %rax,%rdx
  6f233d:	48 ff c9             	dec    %rcx
  6f2340:	75 de                	jne    6f2320 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6b0>
  6f2342:	48 89 f9             	mov    %rdi,%rcx
  6f2345:	4c 29 e1             	sub    %r12,%rcx
  6f2348:	be 28 02 00 00       	mov    $0x228,%esi
  6f234d:	83 f9 03             	cmp    $0x3,%ecx
  6f2350:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
  6f2357:	00 
  6f2358:	0f 82 c2 fb ff ff    	jb     6f1f20 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f235e:	66 90                	xchg   %ax,%ax
  6f2360:	48 8b 8c c3 c8 01 00 	mov    0x1c8(%rbx,%rax,8),%rcx
  6f2367:	00 
  6f2368:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f236f:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f2376:	48 8b 8c c3 d0 01 00 	mov    0x1d0(%rbx,%rax,8),%rcx
  6f237d:	00 
  6f237e:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f2385:	8d 50 01             	lea    0x1(%rax),%edx
  6f2388:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f238f:	48 8b 8c c3 d8 01 00 	mov    0x1d8(%rbx,%rax,8),%rcx
  6f2396:	00 
  6f2397:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f239e:	8d 50 02             	lea    0x2(%rax),%edx
  6f23a1:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f23a8:	48 8b 8c c3 e0 01 00 	mov    0x1e0(%rbx,%rax,8),%rcx
  6f23af:	00 
  6f23b0:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f23b7:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f23bb:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f23c2:	48 83 c0 04          	add    $0x4,%rax
  6f23c6:	48 39 fa             	cmp    %rdi,%rdx
  6f23c9:	75 95                	jne    6f2360 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6f0>
  6f23cb:	e9 50 fb ff ff       	jmp    6f1f20 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f23d0:	4c 89 e0             	mov    %r12,%rax
  6f23d3:	49 f7 df             	neg    %r15
  6f23d6:	4a 8d 0c 3e          	lea    (%rsi,%r15,1),%rcx
  6f23da:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f23de:	83 f9 03             	cmp    $0x3,%ecx
  6f23e1:	0f 83 39 fe ff ff    	jae    6f2220 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x5b0>
  6f23e7:	e9 9e fe ff ff       	jmp    6f228a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f23ec:	48 85 c0             	test   %rax,%rax
  6f23ef:	0f 85 9e fa ff ff    	jne    6f1e93 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f23f5:	4c 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14
  6f23fc:	00 
  6f23fd:	49 8b 1e             	mov    (%r14),%rbx
  6f2400:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f2407:	48 85 db             	test   %rbx,%rbx
  6f240a:	0f 84 aa 00 00 00    	je     6f24ba <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x84a>
  6f2410:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f2414:	48 85 c0             	test   %rax,%rax
  6f2417:	0f 84 ac 00 00 00    	je     6f24c9 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x859>
  6f241d:	48 8b 3b             	mov    (%rbx),%rdi
  6f2420:	48 8b 8f c8 01 00 00 	mov    0x1c8(%rdi),%rcx
  6f2427:	48 89 0b             	mov    %rcx,(%rbx)
  6f242a:	48 ff c8             	dec    %rax
  6f242d:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f2431:	48 c7 81 60 01 00 00 	movq   $0x0,0x160(%rcx)
  6f2438:	00 00 00 00 
  6f243c:	be 28 02 00 00       	mov    $0x228,%esi
  6f2441:	ba 08 00 00 00       	mov    $0x8,%edx
  6f2446:	ff 15 7c 58 3f 00    	call   *0x3f587c(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  6f244c:	49 89 1e             	mov    %rbx,(%r14)
  6f244f:	e9 3f fa ff ff       	jmp    6f1e93 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f2454:	be 05 00 00 00       	mov    $0x5,%esi
  6f2459:	48 29 c6             	sub    %rax,%rsi
  6f245c:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  6f2463:	00 
  6f2464:	e8 67 0f 00 00       	call   6f33d0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2469:	e9 25 fa ff ff       	jmp    6f1e93 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f246e:	be 05 00 00 00       	mov    $0x5,%esi
  6f2473:	48 29 c6             	sub    %rax,%rsi
  6f2476:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f247b:	e8 90 12 00 00       	call   6f3710 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2480:	e9 0e fa ff ff       	jmp    6f1e93 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f2485:	be 28 00 00 00       	mov    $0x28,%esi
  6f248a:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  6f248f:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  6f2496:	00 
  6f2497:	ff 15 63 58 3f 00    	call   *0x3f5863(%rip)        # ae7d00 <_DYNAMIC+0x280>
  6f249d:	eb 28                	jmp    6f24c7 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x857>
  6f249f:	48 8d 3d 23 12 97 ff 	lea    -0x68eddd(%rip),%rdi        # 636c9 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f24a6:	48 8d 15 fb 74 3c 00 	lea    0x3c74fb(%rip),%rdx        # ab99a8 <__frame_dummy_init_array_entry+0x1a0>
  6f24ad:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f24b2:	ff 15 68 58 3f 00    	call   *0x3f5868(%rip)        # ae7d20 <_DYNAMIC+0x2a0>
  6f24b8:	eb 0d                	jmp    6f24c7 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x857>
  6f24ba:	48 8d 3d f7 73 3c 00 	lea    0x3c73f7(%rip),%rdi        # ab98b8 <__frame_dummy_init_array_entry+0xb0>
  6f24c1:	ff 15 41 58 3f 00    	call   *0x3f5841(%rip)        # ae7d08 <_DYNAMIC+0x288>
  6f24c7:	0f 0b                	ud2
  6f24c9:	48 8d 05 b8 73 3c 00 	lea    0x3c73b8(%rip),%rax        # ab9888 <__frame_dummy_init_array_entry+0x80>
  6f24d0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f24d7:	00 
  6f24d8:	be 21 00 00 00       	mov    $0x21,%esi
  6f24dd:	48 8d 05 a7 10 97 ff 	lea    -0x68ef59(%rip),%rax        # 6358b <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f24e4:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  6f24e9:	eb 9f                	jmp    6f248a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x81a>
  6f24eb:	48 89 c3             	mov    %rax,%rbx
  6f24ee:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  6f24f5:	00 
  6f24f6:	e8 e5 55 02 00       	call   717ae0 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f24fb:	48 89 df             	mov    %rbx,%rdi
  6f24fe:	e8 4d 5f 3c 00       	call   ab8450 <_Unwind_Resume@plt>
  6f2503:	ff 15 0f 58 3f 00    	call   *0x3f580f(%rip)        # ae7d18 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
