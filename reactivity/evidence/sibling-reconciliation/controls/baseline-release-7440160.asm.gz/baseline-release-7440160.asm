
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000718720 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>:
  718720:	55                   	push   %rbp
  718721:	41 57                	push   %r15
  718723:	41 56                	push   %r14
  718725:	41 55                	push   %r13
  718727:	41 54                	push   %r12
  718729:	53                   	push   %rbx
  71872a:	48 83 ec 78          	sub    $0x78,%rsp
  71872e:	48 89 fb             	mov    %rdi,%rbx
  718731:	4c 8b 26             	mov    (%rsi),%r12
  718734:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718738:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  71873c:	4c 8b 6e 28          	mov    0x28(%rsi),%r13
  718740:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718747:	00 
  718748:	48 85 c0             	test   %rax,%rax
  71874b:	0f 84 29 01 00 00    	je     71887a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x15a>
  718751:	49 89 f6             	mov    %rsi,%r14
  718754:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  718758:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  71875d:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718764:	49 39 cd             	cmp    %rcx,%r13
  718767:	73 07                	jae    718770 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  718769:	49 89 c7             	mov    %rax,%r15
  71876c:	eb 2a                	jmp    718798 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x78>
  71876e:	66 90                	xchg   %ax,%ax
  718770:	4c 8b b8 60 01 00 00 	mov    0x160(%rax),%r15
  718777:	4d 85 ff             	test   %r15,%r15
  71877a:	0f 84 fa 00 00 00    	je     71887a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x15a>
  718780:	48 ff c5             	inc    %rbp
  718783:	44 0f b7 a8 c0 01 00 	movzwl 0x1c0(%rax),%r13d
  71878a:	00 
  71878b:	4c 89 f8             	mov    %r15,%rax
  71878e:	66 45 3b af c2 01 00 	cmp    0x1c2(%r15),%r13w
  718795:	00 
  718796:	73 d8                	jae    718770 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  718798:	4b 8b b4 ef 68 01 00 	mov    0x168(%r15,%r13,8),%rsi
  71879f:	00 
  7187a0:	49 8b 3c 24          	mov    (%r12),%rdi
  7187a4:	ff 15 9e 25 3d 00    	call   *0x3d259e(%rip)        # aead48 <_DYNAMIC+0x6d0>
  7187aa:	84 c0                	test   %al,%al
  7187ac:	0f 84 e2 00 00 00    	je     718894 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x174>
  7187b2:	48 85 ed             	test   %rbp,%rbp
  7187b5:	0f 84 8b 00 00 00    	je     718846 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x126>
  7187bb:	4b 8d 04 ef          	lea    (%r15,%r13,8),%rax
  7187bf:	48 05 d0 01 00 00    	add    $0x1d0,%rax
  7187c5:	48 89 e9             	mov    %rbp,%rcx
  7187c8:	48 83 e1 07          	and    $0x7,%rcx
  7187cc:	0f 84 9d 00 00 00    	je     71886f <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x14f>
  7187d2:	31 d2                	xor    %edx,%edx
  7187d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  7187db:	00 00 00 00 00 
  7187e0:	4c 8b 38             	mov    (%rax),%r15
  7187e3:	49 8d 87 c8 01 00 00 	lea    0x1c8(%r15),%rax
  7187ea:	48 ff c2             	inc    %rdx
  7187ed:	48 39 d1             	cmp    %rdx,%rcx
  7187f0:	75 ee                	jne    7187e0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xc0>
  7187f2:	48 89 e9             	mov    %rbp,%rcx
  7187f5:	48 29 d1             	sub    %rdx,%rcx
  7187f8:	48 83 fd 08          	cmp    $0x8,%rbp
  7187fc:	72 43                	jb     718841 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x121>
  7187fe:	66 90                	xchg   %ax,%ax
  718800:	48 8b 00             	mov    (%rax),%rax
  718803:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  71880a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718811:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718818:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  71881f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718826:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  71882d:	4c 8b b8 c8 01 00 00 	mov    0x1c8(%rax),%r15
  718834:	49 8d 87 c8 01 00 00 	lea    0x1c8(%r15),%rax
  71883b:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  71883f:	75 bf                	jne    718800 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xe0>
  718841:	45 31 ed             	xor    %r13d,%r13d
  718844:	eb 03                	jmp    718849 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x129>
  718846:	49 ff c5             	inc    %r13
  718849:	4d 89 6e 28          	mov    %r13,0x28(%r14)
  71884d:	0f 57 c0             	xorps  %xmm0,%xmm0
  718850:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  718855:	31 ed                	xor    %ebp,%ebp
  718857:	4c 89 f8             	mov    %r15,%rax
  71885a:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718861:	49 39 cd             	cmp    %rcx,%r13
  718864:	0f 83 06 ff ff ff    	jae    718770 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  71886a:	e9 fa fe ff ff       	jmp    718769 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x49>
  71886f:	48 89 e9             	mov    %rbp,%rcx
  718872:	48 83 fd 08          	cmp    $0x8,%rbp
  718876:	73 88                	jae    718800 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xe0>
  718878:	eb c7                	jmp    718841 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x121>
  71887a:	48 c7 43 08 02 00 00 	movq   $0x2,0x8(%rbx)
  718881:	00 
  718882:	48 89 d8             	mov    %rbx,%rax
  718885:	48 83 c4 78          	add    $0x78,%rsp
  718889:	5b                   	pop    %rbx
  71888a:	41 5c                	pop    %r12
  71888c:	41 5d                	pop    %r13
  71888e:	41 5e                	pop    %r14
  718890:	41 5f                	pop    %r15
  718892:	5d                   	pop    %rbp
  718893:	c3                   	ret
  718894:	49 8b 46 08          	mov    0x8(%r14),%rax
  718898:	48 ff 08             	decq   (%rax)
  71889b:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
  7188a0:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  7188a5:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  7188aa:	49 83 c6 10          	add    $0x10,%r14
  7188ae:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  7188b3:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  7188b8:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  7188bd:	4c 89 f2             	mov    %r14,%rdx
  7188c0:	e8 5b 33 fd ff       	call   6ebc20 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_>
  7188c5:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  7188ca:	48 89 43 20          	mov    %rax,0x20(%rbx)
  7188ce:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  7188d3:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  7188d8:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  7188dc:	0f 11 03             	movups %xmm0,(%rbx)
  7188df:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  7188e4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  7188e9:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  7188ee:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  7188f3:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  7188f8:	48 89 41 10          	mov    %rax,0x10(%rcx)
  7188fc:	0f 11 01             	movups %xmm0,(%rcx)
  7188ff:	eb 81                	jmp    718882 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x162>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
