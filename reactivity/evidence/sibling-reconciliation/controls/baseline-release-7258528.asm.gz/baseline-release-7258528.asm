
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006ec1a0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_>:
  6ec1a0:	53                   	push   %rbx
  6ec1a1:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
  6ec1a8:	48 89 fb             	mov    %rdi,%rbx
  6ec1ab:	48 8b 06             	mov    (%rsi),%rax
  6ec1ae:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6ec1b2:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6ec1b6:	48 85 ff             	test   %rdi,%rdi
  6ec1b9:	0f 84 c3 02 00 00    	je     6ec482 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x2e2>
  6ec1bf:	48 8b 8c c8 38 05 00 	mov    0x538(%rax,%rcx,8),%rcx
  6ec1c6:	00 
  6ec1c7:	48 89 f8             	mov    %rdi,%rax
  6ec1ca:	48 ff c8             	dec    %rax
  6ec1cd:	0f 84 cb 00 00 00    	je     6ec29e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0xfe>
  6ec1d3:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6ec1d7:	48 89 c6             	mov    %rax,%rsi
  6ec1da:	48 83 e6 07          	and    $0x7,%rsi
  6ec1de:	74 2b                	je     6ec20b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x6b>
  6ec1e0:	45 31 c0             	xor    %r8d,%r8d
  6ec1e3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ec1ea:	84 00 00 00 00 00 
  6ec1f0:	44 0f b7 89 32 05 00 	movzwl 0x532(%rcx),%r9d
  6ec1f7:	00 
  6ec1f8:	4a 8b 8c c9 38 05 00 	mov    0x538(%rcx,%r9,8),%rcx
  6ec1ff:	00 
  6ec200:	49 ff c0             	inc    %r8
  6ec203:	4c 39 c6             	cmp    %r8,%rsi
  6ec206:	75 e8                	jne    6ec1f0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x50>
  6ec208:	4c 29 c0             	sub    %r8,%rax
  6ec20b:	48 83 ff 07          	cmp    $0x7,%rdi
  6ec20f:	0f 82 89 00 00 00    	jb     6ec29e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0xfe>
  6ec215:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6ec21c:	00 00 00 00 
  6ec220:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ec227:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ec22e:	00 
  6ec22f:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ec236:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ec23d:	00 
  6ec23e:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ec245:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ec24c:	00 
  6ec24d:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ec254:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ec25b:	00 
  6ec25c:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ec263:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ec26a:	00 
  6ec26b:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ec272:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ec279:	00 
  6ec27a:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ec281:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ec288:	00 
  6ec289:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ec290:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ec297:	00 
  6ec298:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6ec29c:	75 82                	jne    6ec220 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x80>
  6ec29e:	0f b7 81 32 05 00 00 	movzwl 0x532(%rcx),%eax
  6ec2a5:	48 ff c8             	dec    %rax
  6ec2a8:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6ec2af:	00 
  6ec2b0:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  6ec2b7:	00 00 00 00 00 
  6ec2bc:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6ec2c3:	00 
  6ec2c4:	48 89 e7             	mov    %rsp,%rdi
  6ec2c7:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
  6ec2ce:	00 
  6ec2cf:	e8 4c 7e 00 00       	call   6f4120 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>
  6ec2d4:	48 8b 3c 24          	mov    (%rsp),%rdi
  6ec2d8:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6ec2dd:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  6ec2e4:	00 
  6ec2e5:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6ec2ea:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  6ec2f1:	00 
  6ec2f2:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  6ec2f7:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6ec2fe:	00 
  6ec2ff:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  6ec304:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  6ec30b:	00 
  6ec30c:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  6ec311:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  6ec318:	00 
  6ec319:	0f 10 44 24 58       	movups 0x58(%rsp),%xmm0
  6ec31e:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  6ec325:	00 
  6ec326:	0f 10 44 24 68       	movups 0x68(%rsp),%xmm0
  6ec32b:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  6ec332:	00 
  6ec333:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6ec338:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6ec33f:	00 
  6ec340:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  6ec347:	00 
  6ec348:	0f b7 90 32 05 00 00 	movzwl 0x532(%rax),%edx
  6ec34f:	48 39 d1             	cmp    %rdx,%rcx
  6ec352:	72 26                	jb     6ec37a <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x1da>
  6ec354:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ec35b:	00 00 00 00 00 
  6ec360:	0f b7 88 30 05 00 00 	movzwl 0x530(%rax),%ecx
  6ec367:	48 8b 80 d0 04 00 00 	mov    0x4d0(%rax),%rax
  6ec36e:	48 ff c6             	inc    %rsi
  6ec371:	66 3b 88 32 05 00 00 	cmp    0x532(%rax),%cx
  6ec378:	73 e6                	jae    6ec360 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x1c0>
  6ec37a:	4c 6b c1 70          	imul   $0x70,%rcx,%r8
  6ec37e:	48 8b 94 c8 d8 04 00 	mov    0x4d8(%rax,%rcx,8),%rdx
  6ec385:	00 
  6ec386:	48 89 bc c8 d8 04 00 	mov    %rdi,0x4d8(%rax,%rcx,8)
  6ec38d:	00 
  6ec38e:	42 0f 10 44 00 60    	movups 0x60(%rax,%r8,1),%xmm0
  6ec394:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6ec399:	42 0f 10 44 00 50    	movups 0x50(%rax,%r8,1),%xmm0
  6ec39f:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  6ec3a4:	42 0f 10 44 00 40    	movups 0x40(%rax,%r8,1),%xmm0
  6ec3aa:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  6ec3af:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6ec3b4:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6ec3ba:	42 0f 10 54 00 20    	movups 0x20(%rax,%r8,1),%xmm2
  6ec3c0:	42 0f 10 5c 00 30    	movups 0x30(%rax,%r8,1),%xmm3
  6ec3c6:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  6ec3cb:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
  6ec3d0:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6ec3d5:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6ec3d9:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
  6ec3e0:	00 
  6ec3e1:	0f 28 8c 24 c0 00 00 	movaps 0xc0(%rsp),%xmm1
  6ec3e8:	00 
  6ec3e9:	0f 28 94 24 d0 00 00 	movaps 0xd0(%rsp),%xmm2
  6ec3f0:	00 
  6ec3f1:	0f 28 9c 24 e0 00 00 	movaps 0xe0(%rsp),%xmm3
  6ec3f8:	00 
  6ec3f9:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6ec3fe:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6ec404:	42 0f 11 54 00 20    	movups %xmm2,0x20(%rax,%r8,1)
  6ec40a:	42 0f 11 5c 00 30    	movups %xmm3,0x30(%rax,%r8,1)
  6ec410:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
  6ec417:	00 
  6ec418:	42 0f 11 44 00 40    	movups %xmm0,0x40(%rax,%r8,1)
  6ec41e:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  6ec425:	00 
  6ec426:	42 0f 11 44 00 50    	movups %xmm0,0x50(%rax,%r8,1)
  6ec42c:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  6ec433:	00 
  6ec434:	42 0f 11 44 00 60    	movups %xmm0,0x60(%rax,%r8,1)
  6ec43a:	48 85 f6             	test   %rsi,%rsi
  6ec43d:	74 6c                	je     6ec4ab <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x30b>
  6ec43f:	48 8d 3c c8          	lea    (%rax,%rcx,8),%rdi
  6ec443:	48 81 c7 40 05 00 00 	add    $0x540,%rdi
  6ec44a:	48 89 f1             	mov    %rsi,%rcx
  6ec44d:	48 83 e1 07          	and    $0x7,%rcx
  6ec451:	74 5d                	je     6ec4b0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x310>
  6ec453:	45 31 c9             	xor    %r9d,%r9d
  6ec456:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6ec45d:	00 00 00 
  6ec460:	48 8b 07             	mov    (%rdi),%rax
  6ec463:	48 8d b8 38 05 00 00 	lea    0x538(%rax),%rdi
  6ec46a:	49 ff c1             	inc    %r9
  6ec46d:	4c 39 c9             	cmp    %r9,%rcx
  6ec470:	75 ee                	jne    6ec460 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x2c0>
  6ec472:	49 89 f0             	mov    %rsi,%r8
  6ec475:	4d 29 c8             	sub    %r9,%r8
  6ec478:	31 c9                	xor    %ecx,%ecx
  6ec47a:	48 83 fe 08          	cmp    $0x8,%rsi
  6ec47e:	73 40                	jae    6ec4c0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x320>
  6ec480:	eb 7f                	jmp    6ec501 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ec482:	48 89 04 24          	mov    %rax,(%rsp)
  6ec486:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6ec48d:	00 00 
  6ec48f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6ec494:	48 89 e6             	mov    %rsp,%rsi
  6ec497:	48 89 df             	mov    %rbx,%rdi
  6ec49a:	e8 81 7c 00 00       	call   6f4120 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>
  6ec49f:	48 89 d8             	mov    %rbx,%rax
  6ec4a2:	48 81 c4 20 01 00 00 	add    $0x120,%rsp
  6ec4a9:	5b                   	pop    %rbx
  6ec4aa:	c3                   	ret
  6ec4ab:	48 ff c1             	inc    %rcx
  6ec4ae:	eb 51                	jmp    6ec501 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ec4b0:	49 89 f0             	mov    %rsi,%r8
  6ec4b3:	31 c9                	xor    %ecx,%ecx
  6ec4b5:	48 83 fe 08          	cmp    $0x8,%rsi
  6ec4b9:	72 46                	jb     6ec501 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ec4bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ec4c0:	48 8b 07             	mov    (%rdi),%rax
  6ec4c3:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec4ca:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec4d1:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec4d8:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec4df:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec4e6:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec4ed:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec4f4:	48 8d b8 38 05 00 00 	lea    0x538(%rax),%rdi
  6ec4fb:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6ec4ff:	75 bf                	jne    6ec4c0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x320>
  6ec501:	48 89 13             	mov    %rdx,(%rbx)
  6ec504:	0f 28 04 24          	movaps (%rsp),%xmm0
  6ec508:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6ec50d:	0f 28 54 24 20       	movaps 0x20(%rsp),%xmm2
  6ec512:	0f 28 5c 24 30       	movaps 0x30(%rsp),%xmm3
  6ec517:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6ec51b:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6ec51f:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  6ec523:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  6ec527:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  6ec52c:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
  6ec530:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  6ec535:	0f 11 43 58          	movups %xmm0,0x58(%rbx)
  6ec539:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6ec53e:	0f 11 43 68          	movups %xmm0,0x68(%rbx)
  6ec542:	48 89 43 78          	mov    %rax,0x78(%rbx)
  6ec546:	48 c7 83 80 00 00 00 	movq   $0x0,0x80(%rbx)
  6ec54d:	00 00 00 00 
  6ec551:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
  6ec558:	48 89 d8             	mov    %rbx,%rax
  6ec55b:	48 81 c4 20 01 00 00 	add    $0x120,%rsp
  6ec562:	5b                   	pop    %rbx
  6ec563:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
