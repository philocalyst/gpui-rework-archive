
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000731ca0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>:
  731ca0:	55                   	push   %rbp
  731ca1:	41 57                	push   %r15
  731ca3:	41 56                	push   %r14
  731ca5:	41 55                	push   %r13
  731ca7:	41 54                	push   %r12
  731ca9:	53                   	push   %rbx
  731caa:	48 81 ec f8 02 00 00 	sub    $0x2f8,%rsp
  731cb1:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  731cb6:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  731cbb:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  731cc0:	48 83 fe 02          	cmp    $0x2,%rsi
  731cc4:	0f 82 01 06 00 00    	jb     7322cb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x62b>
  731cca:	48 89 cd             	mov    %rcx,%rbp
  731ccd:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  731cd4:	00 00 40 
  731cd7:	48 89 d1             	mov    %rdx,%rcx
  731cda:	31 d2                	xor    %edx,%edx
  731cdc:	48 f7 f6             	div    %rsi
  731cdf:	48 83 fa 01          	cmp    $0x1,%rdx
  731ce3:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  731ce7:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  731cec:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  731cf3:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  731cf8:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
  731cfd:	73 1e                	jae    731d1d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x7d>
  731cff:	48 89 ca             	mov    %rcx,%rdx
  731d02:	48 89 f0             	mov    %rsi,%rax
  731d05:	48 d1 e8             	shr    $1,%rax
  731d08:	48 89 f1             	mov    %rsi,%rcx
  731d0b:	48 29 c1             	sub    %rax,%rcx
  731d0e:	48 83 f9 40          	cmp    $0x40,%rcx
  731d12:	b8 40 00 00 00       	mov    $0x40,%eax
  731d17:	48 0f 42 c1          	cmovb  %rcx,%rax
  731d1b:	eb 0e                	jmp    731d2b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x8b>
  731d1d:	48 89 f7             	mov    %rsi,%rdi
  731d20:	ff 15 7a 91 3b 00    	call   *0x3b917a(%rip)        # aeaea0 <_DYNAMIC+0x828>
  731d26:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  731d2b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  731d30:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  731d35:	48 8d 48 30          	lea    0x30(%rax),%rcx
  731d39:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  731d3e:	48 8d 48 10          	lea    0x10(%rax),%rcx
  731d42:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  731d47:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
  731d4b:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  731d50:	48 83 c0 e8          	add    $0xffffffffffffffe8,%rax
  731d54:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  731d59:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  731d5f:	31 db                	xor    %ebx,%ebx
  731d61:	45 31 db             	xor    %r11d,%r11d
  731d64:	48 89 ac 24 90 00 00 	mov    %rbp,0x90(%rsp)
  731d6b:	00 
  731d6c:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
  731d71:	49 29 d9             	sub    %rbx,%r9
  731d74:	76 23                	jbe    731d99 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0xf9>
  731d76:	eb 38                	jmp    731db0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x110>
  731d78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  731d7f:	00 
  731d80:	49 ff c3             	inc    %r11
  731d83:	4c 89 c8             	mov    %r9,%rax
  731d86:	48 d1 e8             	shr    $1,%rax
  731d89:	48 01 c3             	add    %rax,%rbx
  731d8c:	4d 89 cc             	mov    %r9,%r12
  731d8f:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
  731d94:	49 29 d9             	sub    %rbx,%r9
  731d97:	77 17                	ja     731db0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x110>
  731d99:	31 f6                	xor    %esi,%esi
  731d9b:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  731da1:	49 83 fb 02          	cmp    $0x2,%r11
  731da5:	0f 83 fa 01 00 00    	jae    731fa5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x305>
  731dab:	e9 c6 04 00 00       	jmp    732276 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  731db0:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  731db4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  731db9:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  731dbd:	4c 3b 4c 24 20       	cmp    0x20(%rsp),%r9
  731dc2:	73 4c                	jae    731e10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x170>
  731dc4:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  731dc9:	74 55                	je     731e20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x180>
  731dcb:	49 83 f9 20          	cmp    $0x20,%r9
  731dcf:	b8 20 00 00 00       	mov    $0x20,%eax
  731dd4:	4c 0f 43 c8          	cmovae %rax,%r9
  731dd8:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  731ddd:	48 89 04 24          	mov    %rax,(%rsp)
  731de1:	4c 89 ce             	mov    %r9,%rsi
  731de4:	48 89 e9             	mov    %rbp,%rcx
  731de7:	45 31 c0             	xor    %r8d,%r8d
  731dea:	4d 89 cf             	mov    %r9,%r15
  731ded:	45 31 c9             	xor    %r9d,%r9d
  731df0:	4d 89 de             	mov    %r11,%r14
  731df3:	e8 68 88 ff ff       	call   72a660 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  731df8:	4d 89 f3             	mov    %r14,%r11
  731dfb:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  731e00:	44 89 f8             	mov    %r15d,%eax
  731e03:	e9 58 01 00 00       	jmp    731f60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  731e08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  731e0f:	00 
  731e10:	49 83 f9 02          	cmp    $0x2,%r9
  731e14:	73 2a                	jae    731e40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1a0>
  731e16:	4c 89 c8             	mov    %r9,%rax
  731e19:	e9 42 01 00 00       	jmp    731f60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  731e1e:	66 90                	xchg   %ax,%ax
  731e20:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  731e25:	49 39 c1             	cmp    %rax,%r9
  731e28:	4c 0f 43 c8          	cmovae %rax,%r9
  731e2c:	4d 01 c9             	add    %r9,%r9
  731e2f:	e9 34 01 00 00       	jmp    731f68 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c8>
  731e34:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  731e3b:	00 00 00 00 00 
  731e40:	48 8b 0f             	mov    (%rdi),%rcx
  731e43:	4c 8b 57 18          	mov    0x18(%rdi),%r10
  731e47:	49 39 ca             	cmp    %rcx,%r10
  731e4a:	4d 89 ce             	mov    %r9,%r14
  731e4d:	72 3a                	jb     731e89 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1e9>
  731e4f:	b8 02 00 00 00       	mov    $0x2,%eax
  731e54:	49 83 f9 02          	cmp    $0x2,%r9
  731e58:	0f 84 02 01 00 00    	je     731f60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  731e5e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  731e63:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
  731e67:	b8 02 00 00 00       	mov    $0x2,%eax
  731e6c:	4d 89 d0             	mov    %r10,%r8
  731e6f:	90                   	nop
  731e70:	4d 89 c1             	mov    %r8,%r9
  731e73:	4c 8b 06             	mov    (%rsi),%r8
  731e76:	4d 39 c8             	cmp    %r9,%r8
  731e79:	72 5f                	jb     731eda <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x23a>
  731e7b:	48 ff c0             	inc    %rax
  731e7e:	48 83 c6 18          	add    $0x18,%rsi
  731e82:	49 39 c6             	cmp    %rax,%r14
  731e85:	75 e9                	jne    731e70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1d0>
  731e87:	eb 3e                	jmp    731ec7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x227>
  731e89:	49 83 f9 02          	cmp    $0x2,%r9
  731e8d:	75 0c                	jne    731e9b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1fb>
  731e8f:	b8 02 00 00 00       	mov    $0x2,%eax
  731e94:	b9 01 00 00 00       	mov    $0x1,%ecx
  731e99:	eb 63                	jmp    731efe <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x25e>
  731e9b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  731ea0:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
  731ea4:	b8 02 00 00 00       	mov    $0x2,%eax
  731ea9:	4d 89 d0             	mov    %r10,%r8
  731eac:	0f 1f 40 00          	nopl   0x0(%rax)
  731eb0:	4d 89 c1             	mov    %r8,%r9
  731eb3:	4c 8b 06             	mov    (%rsi),%r8
  731eb6:	4d 39 c8             	cmp    %r9,%r8
  731eb9:	73 1f                	jae    731eda <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x23a>
  731ebb:	48 ff c0             	inc    %rax
  731ebe:	48 83 c6 18          	add    $0x18,%rsi
  731ec2:	49 39 c6             	cmp    %rax,%r14
  731ec5:	75 e9                	jne    731eb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x210>
  731ec7:	4d 89 f1             	mov    %r14,%r9
  731eca:	4c 89 f0             	mov    %r14,%rax
  731ecd:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  731ed2:	0f 82 ec fe ff ff    	jb     731dc4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x124>
  731ed8:	eb 0e                	jmp    731ee8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x248>
  731eda:	4d 89 f1             	mov    %r14,%r9
  731edd:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  731ee2:	0f 82 dc fe ff ff    	jb     731dc4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x124>
  731ee8:	49 39 ca             	cmp    %rcx,%r10
  731eeb:	40 0f 93 c7          	setae  %dil
  731eef:	48 89 c1             	mov    %rax,%rcx
  731ef2:	48 d1 e9             	shr    $1,%rcx
  731ef5:	40 0f 94 c6          	sete   %sil
  731ef9:	40 08 fe             	or     %dil,%sil
  731efc:	75 62                	jne    731f60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  731efe:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
  731f05:	00 
  731f06:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
  731f0a:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
  731f0f:	4c 8d 0c 37          	lea    (%rdi,%rsi,1),%r9
  731f13:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
  731f17:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
  731f1b:	48 03 74 24 60       	add    0x60(%rsp),%rsi
  731f20:	49 8b 79 f0          	mov    -0x10(%r9),%rdi
  731f24:	4c 8b 46 f0          	mov    -0x10(%rsi),%r8
  731f28:	4d 89 41 f0          	mov    %r8,-0x10(%r9)
  731f2c:	48 89 7e f0          	mov    %rdi,-0x10(%rsi)
  731f30:	49 8b 79 f8          	mov    -0x8(%r9),%rdi
  731f34:	4c 8b 46 f8          	mov    -0x8(%rsi),%r8
  731f38:	4d 89 41 f8          	mov    %r8,-0x8(%r9)
  731f3c:	48 89 7e f8          	mov    %rdi,-0x8(%rsi)
  731f40:	49 8b 39             	mov    (%r9),%rdi
  731f43:	4c 8b 06             	mov    (%rsi),%r8
  731f46:	4d 89 01             	mov    %r8,(%r9)
  731f49:	48 89 3e             	mov    %rdi,(%rsi)
  731f4c:	49 83 c1 18          	add    $0x18,%r9
  731f50:	48 83 c6 e8          	add    $0xffffffffffffffe8,%rsi
  731f54:	48 ff c9             	dec    %rcx
  731f57:	75 c7                	jne    731f20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x280>
  731f59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  731f60:	4c 8d 0c 45 01 00 00 	lea    0x1(,%rax,2),%r9
  731f67:	00 
  731f68:	4c 89 e0             	mov    %r12,%rax
  731f6b:	48 d1 e8             	shr    $1,%rax
  731f6e:	4c 89 c9             	mov    %r9,%rcx
  731f71:	48 d1 e9             	shr    $1,%rcx
  731f74:	48 8d 34 1b          	lea    (%rbx,%rbx,1),%rsi
  731f78:	48 29 c6             	sub    %rax,%rsi
  731f7b:	48 8d 04 59          	lea    (%rcx,%rbx,2),%rax
  731f7f:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  731f84:	48 0f af f1          	imul   %rcx,%rsi
  731f88:	48 0f af c1          	imul   %rcx,%rax
  731f8c:	48 31 f0             	xor    %rsi,%rax
  731f8f:	be 7f 00 00 00       	mov    $0x7f,%esi
  731f94:	48 0f bd f0          	bsr    %rax,%rsi
  731f98:	83 f6 3f             	xor    $0x3f,%esi
  731f9b:	49 83 fb 02          	cmp    $0x2,%r11
  731f9f:	0f 82 d1 02 00 00    	jb     732276 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  731fa5:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
  731fac:	00 
  731fad:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  731fb1:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  731fb6:	48 01 c8             	add    %rcx,%rax
  731fb9:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  731fc0:	00 
  731fc1:	48 03 4c 24 70       	add    0x70(%rsp),%rcx
  731fc6:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  731fcd:	00 
  731fce:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
  731fd3:	48 89 9c 24 98 00 00 	mov    %rbx,0x98(%rsp)
  731fda:	00 
  731fdb:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  731fe0:	eb 4b                	jmp    73202d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x38d>
  731fe2:	48 89 eb             	mov    %rbp,%rbx
  731fe5:	4c 89 ce             	mov    %r9,%rsi
  731fe8:	49 29 f4             	sub    %rsi,%r12
  731feb:	48 89 df             	mov    %rbx,%rdi
  731fee:	4c 89 e2             	mov    %r12,%rdx
  731ff1:	ff 15 f1 88 3b 00    	call   *0x3b88f1(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  731ff7:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
  731ffe:	00 
  731fff:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  732004:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  732009:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  73200e:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  732013:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  73201a:	00 
  73201b:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  732022:	00 
  732023:	49 83 fb 01          	cmp    $0x1,%r11
  732027:	0f 86 43 02 00 00    	jbe    732270 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d0>
  73202d:	42 38 b4 1c a5 00 00 	cmp    %sil,0xa5(%rsp,%r11,1)
  732034:	00 
  732035:	0f 82 3b 02 00 00    	jb     732276 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  73203b:	49 ff cb             	dec    %r11
  73203e:	4a 8b 84 dc e8 00 00 	mov    0xe8(%rsp,%r11,8),%rax
  732045:	00 
  732046:	49 89 c5             	mov    %rax,%r13
  732049:	49 d1 ed             	shr    $1,%r13
  73204c:	4d 89 e7             	mov    %r12,%r15
  73204f:	49 d1 ef             	shr    $1,%r15
  732052:	4f 8d 34 2f          	lea    (%r15,%r13,1),%r14
  732056:	49 39 ee             	cmp    %rbp,%r14
  732059:	77 25                	ja     732080 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x3e0>
  73205b:	89 c1                	mov    %eax,%ecx
  73205d:	44 09 e1             	or     %r12d,%ecx
  732060:	83 e1 01             	and    $0x1,%ecx
  732063:	75 1b                	jne    732080 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x3e0>
  732065:	4d 01 f6             	add    %r14,%r14
  732068:	4d 89 f4             	mov    %r14,%r12
  73206b:	49 83 fb 01          	cmp    $0x1,%r11
  73206f:	77 bc                	ja     73202d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x38d>
  732071:	e9 fa 01 00 00       	jmp    732270 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d0>
  732076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  73207d:	00 00 00 
  732080:	48 89 d9             	mov    %rbx,%rcx
  732083:	4c 29 f1             	sub    %r14,%rcx
  732086:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  73208a:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  73208f:	48 8d 1c ce          	lea    (%rsi,%rcx,8),%rbx
  732093:	a8 01                	test   $0x1,%al
  732095:	4c 89 5c 24 40       	mov    %r11,0x40(%rsp)
  73209a:	75 54                	jne    7320f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x450>
  73209c:	4c 89 e8             	mov    %r13,%rax
  73209f:	48 83 c8 01          	or     $0x1,%rax
  7320a3:	4c 0f bd c0          	bsr    %rax,%r8
  7320a7:	41 83 f0 3f          	xor    $0x3f,%r8d
  7320ab:	45 01 c0             	add    %r8d,%r8d
  7320ae:	41 83 f0 7e          	xor    $0x7e,%r8d
  7320b2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  7320b7:	48 89 04 24          	mov    %rax,(%rsp)
  7320bb:	48 89 df             	mov    %rbx,%rdi
  7320be:	4c 89 ee             	mov    %r13,%rsi
  7320c1:	48 89 e9             	mov    %rbp,%rcx
  7320c4:	45 31 c9             	xor    %r9d,%r9d
  7320c7:	e8 94 85 ff ff       	call   72a660 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  7320cc:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  7320d1:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  7320d6:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  7320db:	41 f6 c4 01          	test   $0x1,%r12b
  7320df:	74 15                	je     7320f6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x456>
  7320e1:	4d 85 ff             	test   %r15,%r15
  7320e4:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  7320e9:	75 64                	jne    73214f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x4af>
  7320eb:	e9 23 ff ff ff       	jmp    732013 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  7320f0:	41 f6 c4 01          	test   $0x1,%r12b
  7320f4:	75 eb                	jne    7320e1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x441>
  7320f6:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  7320fd:	00 
  7320fe:	4c 01 e8             	add    %r13,%rax
  732101:	48 8d 3c c3          	lea    (%rbx,%rax,8),%rdi
  732105:	4c 89 f8             	mov    %r15,%rax
  732108:	48 83 c8 01          	or     $0x1,%rax
  73210c:	4c 0f bd c0          	bsr    %rax,%r8
  732110:	41 83 f0 3f          	xor    $0x3f,%r8d
  732114:	45 01 c0             	add    %r8d,%r8d
  732117:	41 83 f0 7e          	xor    $0x7e,%r8d
  73211b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  732120:	48 89 04 24          	mov    %rax,(%rsp)
  732124:	4c 89 fe             	mov    %r15,%rsi
  732127:	48 89 e9             	mov    %rbp,%rcx
  73212a:	45 31 c9             	xor    %r9d,%r9d
  73212d:	e8 2e 85 ff ff       	call   72a660 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  732132:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  732137:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  73213c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  732141:	4d 85 ff             	test   %r15,%r15
  732144:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  732149:	0f 84 c4 fe ff ff    	je     732013 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  73214f:	4d 85 ed             	test   %r13,%r13
  732152:	0f 84 bb fe ff ff    	je     732013 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  732158:	4d 39 ef             	cmp    %r13,%r15
  73215b:	4c 89 e8             	mov    %r13,%rax
  73215e:	49 0f 42 c7          	cmovb  %r15,%rax
  732162:	48 39 c5             	cmp    %rax,%rbp
  732165:	0f 82 a8 fe ff ff    	jb     732013 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  73216b:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
  732172:	00 
  732173:	4c 01 e9             	add    %r13,%rcx
  732176:	48 8d 2c cb          	lea    (%rbx,%rcx,8),%rbp
  73217a:	4d 39 fd             	cmp    %r15,%r13
  73217d:	48 89 de             	mov    %rbx,%rsi
  732180:	48 0f 47 f5          	cmova  %rbp,%rsi
  732184:	48 c1 e0 03          	shl    $0x3,%rax
  732188:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
  73218c:	48 89 d7             	mov    %rdx,%rdi
  73218f:	4c 89 e2             	mov    %r12,%rdx
  732192:	ff 15 50 87 3b 00    	call   *0x3b8750(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  732198:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  73219d:	4d 01 cc             	add    %r9,%r12
  7321a0:	4d 39 fd             	cmp    %r15,%r13
  7321a3:	76 68                	jbe    73220d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x56d>
  7321a5:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  7321ac:	00 
  7321ad:	0f 1f 00             	nopl   (%rax)
  7321b0:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
  7321b4:	49 8d 54 24 e8       	lea    -0x18(%r12),%rdx
  7321b9:	49 8b 74 24 e8       	mov    -0x18(%r12),%rsi
  7321be:	31 ff                	xor    %edi,%edi
  7321c0:	45 31 c0             	xor    %r8d,%r8d
  7321c3:	48 3b 75 e8          	cmp    -0x18(%rbp),%rsi
  7321c7:	40 0f 92 c7          	setb   %dil
  7321cb:	41 0f 93 c0          	setae  %r8b
  7321cf:	48 0f 42 d1          	cmovb  %rcx,%rdx
  7321d3:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  7321d7:	48 89 48 10          	mov    %rcx,0x10(%rax)
  7321db:	0f 10 02             	movups (%rdx),%xmm0
  7321de:	0f 11 00             	movups %xmm0,(%rax)
  7321e1:	4b 8d 0c 40          	lea    (%r8,%r8,2),%rcx
  7321e5:	48 8d 6c cd e8       	lea    -0x18(%rbp,%rcx,8),%rbp
  7321ea:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  7321ee:	4d 8d 24 cc          	lea    (%r12,%rcx,8),%r12
  7321f2:	49 83 c4 e8          	add    $0xffffffffffffffe8,%r12
  7321f6:	48 39 dd             	cmp    %rbx,%rbp
  7321f9:	0f 84 e3 fd ff ff    	je     731fe2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x342>
  7321ff:	48 83 c0 e8          	add    $0xffffffffffffffe8,%rax
  732203:	4d 39 cc             	cmp    %r9,%r12
  732206:	75 a8                	jne    7321b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x510>
  732208:	e9 d5 fd ff ff       	jmp    731fe2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x342>
  73220d:	4c 89 ce             	mov    %r9,%rsi
  732210:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
  732217:	00 
  732218:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  73221f:	00 
  732220:	48 8b 4d 00          	mov    0x0(%rbp),%rcx
  732224:	31 c0                	xor    %eax,%eax
  732226:	31 d2                	xor    %edx,%edx
  732228:	48 3b 0e             	cmp    (%rsi),%rcx
  73222b:	0f 92 c1             	setb   %cl
  73222e:	0f 93 c2             	setae  %dl
  732231:	48 89 f7             	mov    %rsi,%rdi
  732234:	48 0f 42 fd          	cmovb  %rbp,%rdi
  732238:	4c 8b 47 10          	mov    0x10(%rdi),%r8
  73223c:	4c 89 43 10          	mov    %r8,0x10(%rbx)
  732240:	0f 10 07             	movups (%rdi),%xmm0
  732243:	0f 11 03             	movups %xmm0,(%rbx)
  732246:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  73224a:	48 8d 34 d6          	lea    (%rsi,%rdx,8),%rsi
  73224e:	48 83 c3 18          	add    $0x18,%rbx
  732252:	4c 39 e6             	cmp    %r12,%rsi
  732255:	0f 84 8d fd ff ff    	je     731fe8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x348>
  73225b:	88 c8                	mov    %cl,%al
  73225d:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  732261:	48 8d 6c c5 00       	lea    0x0(%rbp,%rax,8),%rbp
  732266:	4c 39 cd             	cmp    %r9,%rbp
  732269:	75 b5                	jne    732220 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x580>
  73226b:	e9 78 fd ff ff       	jmp    731fe8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x348>
  732270:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  732276:	4e 89 a4 dc e8 00 00 	mov    %r12,0xe8(%rsp,%r11,8)
  73227d:	00 
  73227e:	42 88 b4 1c a6 00 00 	mov    %sil,0xa6(%rsp,%r11,1)
  732285:	00 
  732286:	48 39 5c 24 30       	cmp    %rbx,0x30(%rsp)
  73228b:	0f 87 ef fa ff ff    	ja     731d80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0xe0>
  732291:	41 f6 c4 01          	test   $0x1,%r12b
  732295:	75 34                	jne    7322cb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x62b>
  732297:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  73229c:	48 89 f0             	mov    %rsi,%rax
  73229f:	48 83 c8 01          	or     $0x1,%rax
  7322a3:	4c 0f bd c0          	bsr    %rax,%r8
  7322a7:	41 83 f0 3f          	xor    $0x3f,%r8d
  7322ab:	45 01 c0             	add    %r8d,%r8d
  7322ae:	41 83 f0 7e          	xor    $0x7e,%r8d
  7322b2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  7322b7:	48 89 04 24          	mov    %rax,(%rsp)
  7322bb:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  7322c0:	48 89 e9             	mov    %rbp,%rcx
  7322c3:	45 31 c9             	xor    %r9d,%r9d
  7322c6:	e8 95 83 ff ff       	call   72a660 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  7322cb:	48 81 c4 f8 02 00 00 	add    $0x2f8,%rsp
  7322d2:	5b                   	pop    %rbx
  7322d3:	41 5c                	pop    %r12
  7322d5:	41 5d                	pop    %r13
  7322d7:	41 5e                	pop    %r14
  7322d9:	41 5f                	pop    %r15
  7322db:	5d                   	pop    %rbp
  7322dc:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
