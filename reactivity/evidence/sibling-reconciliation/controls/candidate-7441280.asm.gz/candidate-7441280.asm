
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000718b80 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>:
  718b80:	55                   	push   %rbp
  718b81:	41 57                	push   %r15
  718b83:	41 56                	push   %r14
  718b85:	41 55                	push   %r13
  718b87:	41 54                	push   %r12
  718b89:	53                   	push   %rbx
  718b8a:	48 83 ec 78          	sub    $0x78,%rsp
  718b8e:	48 89 fb             	mov    %rdi,%rbx
  718b91:	4c 8b 26             	mov    (%rsi),%r12
  718b94:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718b98:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  718b9c:	4c 8b 6e 28          	mov    0x28(%rsi),%r13
  718ba0:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718ba7:	00 
  718ba8:	48 85 c0             	test   %rax,%rax
  718bab:	0f 84 29 01 00 00    	je     718cda <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x15a>
  718bb1:	49 89 f6             	mov    %rsi,%r14
  718bb4:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  718bb8:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  718bbd:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718bc4:	49 39 cd             	cmp    %rcx,%r13
  718bc7:	73 07                	jae    718bd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  718bc9:	49 89 c7             	mov    %rax,%r15
  718bcc:	eb 2a                	jmp    718bf8 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x78>
  718bce:	66 90                	xchg   %ax,%ax
  718bd0:	4c 8b b8 60 01 00 00 	mov    0x160(%rax),%r15
  718bd7:	4d 85 ff             	test   %r15,%r15
  718bda:	0f 84 fa 00 00 00    	je     718cda <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x15a>
  718be0:	48 ff c5             	inc    %rbp
  718be3:	44 0f b7 a8 c0 01 00 	movzwl 0x1c0(%rax),%r13d
  718bea:	00 
  718beb:	4c 89 f8             	mov    %r15,%rax
  718bee:	66 45 3b af c2 01 00 	cmp    0x1c2(%r15),%r13w
  718bf5:	00 
  718bf6:	73 d8                	jae    718bd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  718bf8:	4b 8b b4 ef 68 01 00 	mov    0x168(%r15,%r13,8),%rsi
  718bff:	00 
  718c00:	49 8b 3c 24          	mov    (%r12),%rdi
  718c04:	ff 15 6e f5 3c 00    	call   *0x3cf56e(%rip)        # ae8178 <_DYNAMIC+0x6f8>
  718c0a:	84 c0                	test   %al,%al
  718c0c:	0f 84 e2 00 00 00    	je     718cf4 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x174>
  718c12:	48 85 ed             	test   %rbp,%rbp
  718c15:	0f 84 8b 00 00 00    	je     718ca6 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x126>
  718c1b:	4b 8d 04 ef          	lea    (%r15,%r13,8),%rax
  718c1f:	48 05 d0 01 00 00    	add    $0x1d0,%rax
  718c25:	48 89 e9             	mov    %rbp,%rcx
  718c28:	48 83 e1 07          	and    $0x7,%rcx
  718c2c:	0f 84 9d 00 00 00    	je     718ccf <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x14f>
  718c32:	31 d2                	xor    %edx,%edx
  718c34:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  718c3b:	00 00 00 00 00 
  718c40:	4c 8b 38             	mov    (%rax),%r15
  718c43:	49 8d 87 c8 01 00 00 	lea    0x1c8(%r15),%rax
  718c4a:	48 ff c2             	inc    %rdx
  718c4d:	48 39 d1             	cmp    %rdx,%rcx
  718c50:	75 ee                	jne    718c40 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xc0>
  718c52:	48 89 e9             	mov    %rbp,%rcx
  718c55:	48 29 d1             	sub    %rdx,%rcx
  718c58:	48 83 fd 08          	cmp    $0x8,%rbp
  718c5c:	72 43                	jb     718ca1 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x121>
  718c5e:	66 90                	xchg   %ax,%ax
  718c60:	48 8b 00             	mov    (%rax),%rax
  718c63:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718c6a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718c71:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718c78:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718c7f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718c86:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718c8d:	4c 8b b8 c8 01 00 00 	mov    0x1c8(%rax),%r15
  718c94:	49 8d 87 c8 01 00 00 	lea    0x1c8(%r15),%rax
  718c9b:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  718c9f:	75 bf                	jne    718c60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xe0>
  718ca1:	45 31 ed             	xor    %r13d,%r13d
  718ca4:	eb 03                	jmp    718ca9 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x129>
  718ca6:	49 ff c5             	inc    %r13
  718ca9:	4d 89 6e 28          	mov    %r13,0x28(%r14)
  718cad:	0f 57 c0             	xorps  %xmm0,%xmm0
  718cb0:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  718cb5:	31 ed                	xor    %ebp,%ebp
  718cb7:	4c 89 f8             	mov    %r15,%rax
  718cba:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718cc1:	49 39 cd             	cmp    %rcx,%r13
  718cc4:	0f 83 06 ff ff ff    	jae    718bd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  718cca:	e9 fa fe ff ff       	jmp    718bc9 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x49>
  718ccf:	48 89 e9             	mov    %rbp,%rcx
  718cd2:	48 83 fd 08          	cmp    $0x8,%rbp
  718cd6:	73 88                	jae    718c60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xe0>
  718cd8:	eb c7                	jmp    718ca1 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x121>
  718cda:	48 c7 43 08 02 00 00 	movq   $0x2,0x8(%rbx)
  718ce1:	00 
  718ce2:	48 89 d8             	mov    %rbx,%rax
  718ce5:	48 83 c4 78          	add    $0x78,%rsp
  718ce9:	5b                   	pop    %rbx
  718cea:	41 5c                	pop    %r12
  718cec:	41 5d                	pop    %r13
  718cee:	41 5e                	pop    %r14
  718cf0:	41 5f                	pop    %r15
  718cf2:	5d                   	pop    %rbp
  718cf3:	c3                   	ret
  718cf4:	49 8b 46 08          	mov    0x8(%r14),%rax
  718cf8:	48 ff 08             	decq   (%rax)
  718cfb:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
  718d00:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  718d05:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  718d0a:	49 83 c6 10          	add    $0x10,%r14
  718d0e:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  718d13:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  718d18:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  718d1d:	4c 89 f2             	mov    %r14,%rdx
  718d20:	e8 eb 29 fd ff       	call   6eb710 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_>
  718d25:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  718d2a:	48 89 43 20          	mov    %rax,0x20(%rbx)
  718d2e:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  718d33:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  718d38:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  718d3c:	0f 11 03             	movups %xmm0,(%rbx)
  718d3f:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  718d44:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  718d49:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  718d4e:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  718d53:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  718d58:	48 89 41 10          	mov    %rax,0x10(%rcx)
  718d5c:	0f 11 01             	movups %xmm0,(%rcx)
  718d5f:	eb 81                	jmp    718ce2 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x162>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
