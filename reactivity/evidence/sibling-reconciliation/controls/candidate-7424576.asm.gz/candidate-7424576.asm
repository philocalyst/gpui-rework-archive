
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000714a40 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_>:
  714a40:	55                   	push   %rbp
  714a41:	41 57                	push   %r15
  714a43:	41 56                	push   %r14
  714a45:	41 55                	push   %r13
  714a47:	41 54                	push   %r12
  714a49:	53                   	push   %rbx
  714a4a:	48 83 ec 58          	sub    $0x58,%rsp
  714a4e:	49 89 d5             	mov    %rdx,%r13
  714a51:	48 89 fb             	mov    %rdi,%rbx
  714a54:	48 89 d0             	mov    %rdx,%rax
  714a57:	48 29 f0             	sub    %rsi,%rax
  714a5a:	48 c1 e8 03          	shr    $0x3,%rax
  714a5e:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  714a65:	c3 30 0c 
  714a68:	48 f7 e1             	mul    %rcx
  714a6b:	49 29 f5             	sub    %rsi,%r13
  714a6e:	74 42                	je     714ab2 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x72>
  714a70:	48 89 f5             	mov    %rsi,%rbp
  714a73:	49 89 d4             	mov    %rdx,%r12
  714a76:	49 89 d6             	mov    %rdx,%r14
  714a79:	49 c1 e6 04          	shl    $0x4,%r14
  714a7d:	ff 15 5d 32 3d 00    	call   *0x3d325d(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  714a83:	be 08 00 00 00       	mov    $0x8,%esi
  714a88:	4c 89 f7             	mov    %r14,%rdi
  714a8b:	ff 15 2f 32 3d 00    	call   *0x3d322f(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  714a91:	48 85 c0             	test   %rax,%rax
  714a94:	0f 84 b9 01 00 00    	je     714c53 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x213>
  714a9a:	49 89 c7             	mov    %rax,%r15
  714a9d:	49 8d 44 24 ff       	lea    -0x1(%r12),%rax
  714aa2:	44 89 e1             	mov    %r12d,%ecx
  714aa5:	83 e1 03             	and    $0x3,%ecx
  714aa8:	48 83 f8 03          	cmp    $0x3,%rax
  714aac:	73 18                	jae    714ac6 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x86>
  714aae:	31 c0                	xor    %eax,%eax
  714ab0:	eb 6e                	jmp    714b20 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0xe0>
  714ab2:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  714ab9:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  714ac0:	00 
  714ac1:	e9 46 01 00 00       	jmp    714c0c <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x1cc>
  714ac6:	4c 89 e2             	mov    %r12,%rdx
  714ac9:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
  714acd:	48 8d b5 90 02 00 00 	lea    0x290(%rbp),%rsi
  714ad4:	49 8d 7f 30          	lea    0x30(%r15),%rdi
  714ad8:	31 c0                	xor    %eax,%eax
  714ada:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  714ae0:	0f 10 86 08 fe ff ff 	movups -0x1f8(%rsi),%xmm0
  714ae7:	0f 11 47 d0          	movups %xmm0,-0x30(%rdi)
  714aeb:	0f 10 86 b0 fe ff ff 	movups -0x150(%rsi),%xmm0
  714af2:	0f 11 47 e0          	movups %xmm0,-0x20(%rdi)
  714af6:	0f 10 86 58 ff ff ff 	movups -0xa8(%rsi),%xmm0
  714afd:	0f 11 47 f0          	movups %xmm0,-0x10(%rdi)
  714b01:	0f 10 06             	movups (%rsi),%xmm0
  714b04:	0f 11 07             	movups %xmm0,(%rdi)
  714b07:	48 83 c0 04          	add    $0x4,%rax
  714b0b:	48 81 c6 a0 02 00 00 	add    $0x2a0,%rsi
  714b12:	48 83 c7 40          	add    $0x40,%rdi
  714b16:	48 39 c2             	cmp    %rax,%rdx
  714b19:	75 c5                	jne    714ae0 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0xa0>
  714b1b:	48 85 c9             	test   %rcx,%rcx
  714b1e:	74 47                	je     714b67 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x127>
  714b20:	48 69 d0 a8 00 00 00 	imul   $0xa8,%rax,%rdx
  714b27:	48 c1 e0 04          	shl    $0x4,%rax
  714b2b:	4c 01 f8             	add    %r15,%rax
  714b2e:	48 01 ea             	add    %rbp,%rdx
  714b31:	48 81 c2 98 00 00 00 	add    $0x98,%rdx
  714b38:	48 69 c9 a8 00 00 00 	imul   $0xa8,%rcx,%rcx
  714b3f:	31 f6                	xor    %esi,%esi
  714b41:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  714b48:	0f 1f 84 00 00 00 00 
  714b4f:	00 
  714b50:	0f 10 04 32          	movups (%rdx,%rsi,1),%xmm0
  714b54:	0f 11 00             	movups %xmm0,(%rax)
  714b57:	48 83 c0 10          	add    $0x10,%rax
  714b5b:	48 81 c6 a8 00 00 00 	add    $0xa8,%rsi
  714b62:	48 39 f1             	cmp    %rsi,%rcx
  714b65:	75 e9                	jne    714b50 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x110>
  714b67:	48 8d 44 24 07       	lea    0x7(%rsp),%rax
  714b6c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  714b71:	49 81 fd a8 00 00 00 	cmp    $0xa8,%r13
  714b78:	0f 85 a0 00 00 00    	jne    714c1e <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x1de>
  714b7e:	ff 15 5c 31 3d 00    	call   *0x3d315c(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  714b84:	bf c0 00 00 00       	mov    $0xc0,%edi
  714b89:	be 08 00 00 00       	mov    $0x8,%esi
  714b8e:	ff 15 2c 31 3d 00    	call   *0x3d312c(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  714b94:	48 85 c0             	test   %rax,%rax
  714b97:	0f 84 a4 00 00 00    	je     714c41 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x201>
  714b9d:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  714ba4:	66 c7 80 ba 00 00 00 	movw   $0x0,0xba(%rax)
  714bab:	00 00 
  714bad:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  714bb4:	00 00 
  714bb6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  714bbb:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  714bc2:	00 00 
  714bc4:	4c 89 f8             	mov    %r15,%rax
  714bc7:	4c 01 f0             	add    %r14,%rax
  714bca:	48 c7 44 24 20 02 00 	movq   $0x2,0x20(%rsp)
  714bd1:	00 00 
  714bd3:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  714bd8:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
  714bdd:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  714be2:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  714be7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  714bec:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  714bf1:	48 8d 54 24 08       	lea    0x8(%rsp),%rdx
  714bf6:	e8 f5 59 fd ff       	call   6ea5f0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBV_6marker5OwnedjNtNtCshBhuxcId5D0_4gpui4list6ListIdNtB1f_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterjB1y_INtNtNtB9_3vec9into_iter8IntoIterTjB1y_EEENtNtB9_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  714bfb:	0f 10 44 24 10       	movups 0x10(%rsp),%xmm0
  714c00:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  714c05:	0f 11 03             	movups %xmm0,(%rbx)
  714c08:	48 89 43 10          	mov    %rax,0x10(%rbx)
  714c0c:	48 89 d8             	mov    %rbx,%rax
  714c0f:	48 83 c4 58          	add    $0x58,%rsp
  714c13:	5b                   	pop    %rbx
  714c14:	41 5c                	pop    %r12
  714c16:	41 5d                	pop    %r13
  714c18:	41 5e                	pop    %r14
  714c1a:	41 5f                	pop    %r15
  714c1c:	5d                   	pop    %rbp
  714c1d:	c3                   	ret
  714c1e:	49 81 fd c8 0d 00 00 	cmp    $0xdc8,%r13
  714c25:	73 3a                	jae    714c61 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x221>
  714c27:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  714c2c:	ba 01 00 00 00       	mov    $0x1,%edx
  714c31:	4c 89 ff             	mov    %r15,%rdi
  714c34:	4c 89 e6             	mov    %r12,%rsi
  714c37:	e8 c4 c6 ff ff       	call   711300 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB3S_8adapters3map3MapINtNtB8_4iter4IterNtB1q_9ListDraftENCNvMst_NtB1s_7runtimeINtB5T_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6o_>
  714c3c:	e9 3d ff ff ff       	jmp    714b7e <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x13e>
  714c41:	bf 08 00 00 00       	mov    $0x8,%edi
  714c46:	be c0 00 00 00       	mov    $0xc0,%esi
  714c4b:	ff 15 a7 30 3d 00    	call   *0x3d30a7(%rip)        # ae7cf8 <_DYNAMIC+0x278>
  714c51:	0f 0b                	ud2
  714c53:	bf 08 00 00 00       	mov    $0x8,%edi
  714c58:	4c 89 f6             	mov    %r14,%rsi
  714c5b:	ff 15 47 31 3d 00    	call   *0x3d3147(%rip)        # ae7da8 <_DYNAMIC+0x328>
  714c61:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
  714c66:	4c 89 ff             	mov    %r15,%rdi
  714c69:	4c 89 e6             	mov    %r12,%rsi
  714c6c:	e8 8f 91 01 00       	call   72de00 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_>
  714c71:	e9 08 ff ff ff       	jmp    714b7e <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x13e>
  714c76:	eb 00                	jmp    714c78 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x238>
  714c78:	48 89 c3             	mov    %rax,%rbx
  714c7b:	ba 08 00 00 00       	mov    $0x8,%edx
  714c80:	4c 89 ff             	mov    %r15,%rdi
  714c83:	4c 89 f6             	mov    %r14,%rsi
  714c86:	ff 15 3c 30 3d 00    	call   *0x3d303c(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  714c8c:	48 89 df             	mov    %rbx,%rdi
  714c8f:	e8 bc 37 3a 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
