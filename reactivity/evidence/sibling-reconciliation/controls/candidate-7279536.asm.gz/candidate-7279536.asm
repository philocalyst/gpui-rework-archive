
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006f13b0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>:
  6f13b0:	55                   	push   %rbp
  6f13b1:	41 57                	push   %r15
  6f13b3:	41 56                	push   %r14
  6f13b5:	41 55                	push   %r13
  6f13b7:	41 54                	push   %r12
  6f13b9:	53                   	push   %rbx
  6f13ba:	48 81 ec 58 01 00 00 	sub    $0x158,%rsp
  6f13c1:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f13c8:	00 
  6f13c9:	49 89 f4             	mov    %rsi,%r12
  6f13cc:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  6f13d3:	00 
  6f13d4:	48 8b 2e             	mov    (%rsi),%rbp
  6f13d7:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f13db:	0f b7 9d c2 01 00 00 	movzwl 0x1c2(%rbp),%ebx
  6f13e2:	4a 8d bc ed 68 01 00 	lea    0x168(%rbp,%r13,8),%rdi
  6f13e9:	00 
  6f13ea:	4a 8b 84 ed 68 01 00 	mov    0x168(%rbp,%r13,8),%rax
  6f13f1:	00 
  6f13f2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f13f7:	4a 8d 34 ed 70 01 00 	lea    0x170(,%r13,8),%rsi
  6f13fe:	00 
  6f13ff:	48 01 ee             	add    %rbp,%rsi
  6f1402:	4d 89 ef             	mov    %r13,%r15
  6f1405:	49 f7 d7             	not    %r15
  6f1408:	49 01 df             	add    %rbx,%r15
  6f140b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f1412:	00 
  6f1413:	4c 8b 35 ce 68 3f 00 	mov    0x3f68ce(%rip),%r14        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f141a:	41 ff d6             	call   *%r14
  6f141d:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  6f1422:	4c 89 e8             	mov    %r13,%rax
  6f1425:	48 c1 e0 05          	shl    $0x5,%rax
  6f1429:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f142d:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f1432:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f1437:	0f 11 8c 24 e8 00 00 	movups %xmm1,0xe8(%rsp)
  6f143e:	00 
  6f143f:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f1446:	00 
  6f1447:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f144b:	48 83 c6 20          	add    $0x20,%rsi
  6f144f:	49 c1 e7 05          	shl    $0x5,%r15
  6f1453:	4c 89 fa             	mov    %r15,%rdx
  6f1456:	41 ff d6             	call   *%r14
  6f1459:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f145c:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  6f1461:	66 89 85 c2 01 00 00 	mov    %ax,0x1c2(%rbp)
  6f1468:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
  6f146d:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6f1472:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f1479:	00 
  6f147a:	66 83 f8 04          	cmp    $0x4,%ax
  6f147e:	0f 87 77 01 00 00    	ja     6f15fb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1484:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1489:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6f1490:	48 85 c0             	test   %rax,%rax
  6f1493:	0f 84 16 01 00 00    	je     6f15af <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1ff>
  6f1499:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
  6f149d:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f14a2:	0f b7 92 c0 01 00 00 	movzwl 0x1c0(%rdx),%edx
  6f14a9:	48 85 d2             	test   %rdx,%rdx
  6f14ac:	74 63                	je     6f1511 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x161>
  6f14ae:	48 8b b4 d0 c0 01 00 	mov    0x1c0(%rax,%rdx,8),%rsi
  6f14b5:	00 
  6f14b6:	48 ff ca             	dec    %rdx
  6f14b9:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f14be:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6f14c3:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
  6f14c8:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6f14cd:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f14d2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f14d7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f14dc:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f14e1:	0f b7 86 c2 01 00 00 	movzwl 0x1c2(%rsi),%eax
  6f14e8:	01 c3                	add    %eax,%ebx
  6f14ea:	83 fb 0c             	cmp    $0xc,%ebx
  6f14ed:	0f 83 85 00 00 00    	jae    6f1578 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1c8>
  6f14f3:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f14f8:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6f14fd:	ba 01 00 00 00       	mov    $0x1,%edx
  6f1502:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f1507:	e8 54 ab ff ff       	call   6ec060 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f150c:	e9 b7 00 00 00       	jmp    6f15c8 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x218>
  6f1511:	66 83 b8 c2 01 00 00 	cmpw   $0x0,0x1c2(%rax)
  6f1518:	00 
  6f1519:	0f 84 e3 06 00 00    	je     6f1c02 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x852>
  6f151f:	48 8b 90 d0 01 00 00 	mov    0x1d0(%rax),%rdx
  6f1526:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f152b:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6f1530:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f1537:	00 00 
  6f1539:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f153e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f1543:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f1548:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6f154d:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f1552:	0f b7 82 c2 01 00 00 	movzwl 0x1c2(%rdx),%eax
  6f1559:	01 c3                	add    %eax,%ebx
  6f155b:	83 fb 0c             	cmp    $0xc,%ebx
  6f155e:	73 40                	jae    6f15a0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1f0>
  6f1560:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f1565:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6f156a:	31 d2                	xor    %edx,%edx
  6f156c:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f1571:	e8 ea aa ff ff       	call   6ec060 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1576:	eb 50                	jmp    6f15c8 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x218>
  6f1578:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f157d:	be 01 00 00 00       	mov    $0x1,%esi
  6f1582:	e8 49 1e 00 00       	call   6f33d0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1587:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f158c:	48 ff c0             	inc    %rax
  6f158f:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f1594:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f1599:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  6f159e:	eb 23                	jmp    6f15c3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x213>
  6f15a0:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f15a5:	be 01 00 00 00       	mov    $0x1,%esi
  6f15aa:	e8 61 21 00 00       	call   6f3710 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f15af:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f15b4:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6f15b9:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  6f15be:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f15c3:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f15c8:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6f15cd:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  6f15d2:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6f15d7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f15dc:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  6f15e1:	4c 8b b1 60 01 00 00 	mov    0x160(%rcx),%r14
  6f15e8:	4d 85 f6             	test   %r14,%r14
  6f15eb:	74 0e                	je     6f15fb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f15ed:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f15f4:	00 
  6f15f5:	66 83 f8 04          	cmp    $0x4,%ax
  6f15f9:	76 5f                	jbe    6f165a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2aa>
  6f15fb:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  6f1602:	00 
  6f1603:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  6f160a:	00 
  6f160b:	48 89 42 20          	mov    %rax,0x20(%rdx)
  6f160f:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6f1616:	00 
  6f1617:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  6f161e:	00 
  6f161f:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6f1626:	00 
  6f1627:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f162b:	48 89 02             	mov    %rax,(%rdx)
  6f162e:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f1632:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1637:	48 89 42 28          	mov    %rax,0x28(%rdx)
  6f163b:	48 89 6a 30          	mov    %rbp,0x30(%rdx)
  6f163f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f1644:	48 89 42 38          	mov    %rax,0x38(%rdx)
  6f1648:	48 81 c4 58 01 00 00 	add    $0x158,%rsp
  6f164f:	5b                   	pop    %rbx
  6f1650:	41 5c                	pop    %r12
  6f1652:	41 5d                	pop    %r13
  6f1654:	41 5e                	pop    %r14
  6f1656:	41 5f                	pop    %r15
  6f1658:	5d                   	pop    %rbp
  6f1659:	c3                   	ret
  6f165a:	4c 8d 65 01          	lea    0x1(%rbp),%r12
  6f165e:	48 8d 0d 3b 82 3c 00 	lea    0x3c823b(%rip),%rcx        # ab98a0 <__frame_dummy_init_array_entry+0x98>
  6f1665:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  6f166c:	00 
  6f166d:	48 8d 0d 38 1f 97 ff 	lea    -0x68e0c8(%rip),%rcx        # 635ac <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f1674:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6f167b:	00 
  6f167c:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  6f1683:	00 
  6f1684:	eb 2a                	jmp    6f16b0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x300>
  6f1686:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f168d:	00 00 00 
  6f1690:	ba 08 00 00 00       	mov    $0x8,%edx
  6f1695:	4c 89 ef             	mov    %r13,%rdi
  6f1698:	ff 15 2a 66 3f 00    	call   *0x3f662a(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  6f169e:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f16a5:	00 
  6f16a6:	66 83 f8 04          	cmp    $0x4,%ax
  6f16aa:	0f 87 4b ff ff ff    	ja     6f15fb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f16b0:	4c 89 f1             	mov    %r14,%rcx
  6f16b3:	0f b7 c0             	movzwl %ax,%eax
  6f16b6:	4d 8b b6 60 01 00 00 	mov    0x160(%r14),%r14
  6f16bd:	4d 85 f6             	test   %r14,%r14
  6f16c0:	0f 84 86 04 00 00    	je     6f1b4c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x79c>
  6f16c6:	4c 89 e6             	mov    %r12,%rsi
  6f16c9:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  6f16ce:	44 0f b7 a9 c0 01 00 	movzwl 0x1c0(%rcx),%r13d
  6f16d5:	00 
  6f16d6:	4d 85 ed             	test   %r13,%r13
  6f16d9:	48 89 bc 24 c8 00 00 	mov    %rdi,0xc8(%rsp)
  6f16e0:	00 
  6f16e1:	0f 84 89 00 00 00    	je     6f1770 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x3c0>
  6f16e7:	4b 8b 9c ee c0 01 00 	mov    0x1c0(%r14,%r13,8),%rbx
  6f16ee:	00 
  6f16ef:	49 ff cd             	dec    %r13
  6f16f2:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  6f16f9:	00 
  6f16fa:	48 89 bc 24 00 01 00 	mov    %rdi,0x100(%rsp)
  6f1701:	00 
  6f1702:	4c 89 ac 24 08 01 00 	mov    %r13,0x108(%rsp)
  6f1709:	00 
  6f170a:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
  6f1711:	00 
  6f1712:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
  6f1719:	00 
  6f171a:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6f1721:	00 
  6f1722:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
  6f1729:	00 
  6f172a:	0f b7 b3 c2 01 00 00 	movzwl 0x1c2(%rbx),%esi
  6f1731:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f1734:	ff c2                	inc    %edx
  6f1736:	83 fa 0c             	cmp    $0xc,%edx
  6f1739:	0f 83 75 04 00 00    	jae    6f1bb4 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x804>
  6f173f:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f1746:	00 
  6f1747:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f174b:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  6f1750:	49 89 f4             	mov    %rsi,%r12
  6f1753:	48 01 c6             	add    %rax,%rsi
  6f1756:	48 ff c6             	inc    %rsi
  6f1759:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6f175e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6f1763:	eb 7f                	jmp    6f17e4 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x434>
  6f1765:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f176c:	00 00 00 00 
  6f1770:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f1777:	00 
  6f1778:	66 85 d2             	test   %dx,%dx
  6f177b:	0f 84 81 04 00 00    	je     6f1c02 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x852>
  6f1781:	4d 8b 86 d0 01 00 00 	mov    0x1d0(%r14),%r8
  6f1788:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
  6f178d:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
  6f1792:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f1799:	00 00 
  6f179b:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  6f17a0:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  6f17a5:	4c 89 44 24 70       	mov    %r8,0x70(%rsp)
  6f17aa:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6f17af:	45 0f b7 88 c2 01 00 	movzwl 0x1c2(%r8),%r9d
  6f17b6:	00 
  6f17b7:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f17bb:	48 ff c6             	inc    %rsi
  6f17be:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f17c2:	0f 83 06 04 00 00    	jae    6f1bce <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x81e>
  6f17c8:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f17cc:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  6f17d1:	48 89 cb             	mov    %rcx,%rbx
  6f17d4:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  6f17d9:	45 31 ed             	xor    %r13d,%r13d
  6f17dc:	49 89 c4             	mov    %rax,%r12
  6f17df:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  6f17e4:	0f b7 c2             	movzwl %dx,%eax
  6f17e7:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f17ee:	00 
  6f17ef:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
  6f17f6:	00 
  6f17f7:	66 89 b3 c2 01 00 00 	mov    %si,0x1c2(%rbx)
  6f17fe:	4b 8d 3c ee          	lea    (%r14,%r13,8),%rdi
  6f1802:	48 81 c7 68 01 00 00 	add    $0x168,%rdi
  6f1809:	4b 8b ac ee 68 01 00 	mov    0x168(%r14,%r13,8),%rbp
  6f1810:	00 
  6f1811:	4b 8d 34 ee          	lea    (%r14,%r13,8),%rsi
  6f1815:	48 81 c6 70 01 00 00 	add    $0x170,%rsi
  6f181c:	4d 89 ef             	mov    %r13,%r15
  6f181f:	49 f7 d7             	not    %r15
  6f1822:	49 01 c7             	add    %rax,%r15
  6f1825:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f182c:	00 
  6f182d:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  6f1834:	00 
  6f1835:	48 8b 05 ac 64 3f 00 	mov    0x3f64ac(%rip),%rax        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f183c:	ff d0                	call   *%rax
  6f183e:	4a 89 ac e3 68 01 00 	mov    %rbp,0x168(%rbx,%r12,8)
  6f1845:	00 
  6f1846:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f184b:	48 8d b0 68 01 00 00 	lea    0x168(%rax),%rsi
  6f1852:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f1857:	48 8d bc c3 68 01 00 	lea    0x168(%rbx,%rax,8),%rdi
  6f185e:	00 
  6f185f:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6f1864:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f186b:	48 8b 2d 7e 64 3f 00 	mov    0x3f647e(%rip),%rbp        # ae7cf0 <memcpy@GLIBC_2.14>
  6f1872:	ff d5                	call   *%rbp
  6f1874:	4c 89 e8             	mov    %r13,%rax
  6f1877:	48 c1 e0 05          	shl    $0x5,%rax
  6f187b:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f187f:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f1884:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f188a:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  6f1891:	00 
  6f1892:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  6f1899:	00 
  6f189a:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f189e:	48 83 c6 20          	add    $0x20,%rsi
  6f18a2:	49 c1 e7 05          	shl    $0x5,%r15
  6f18a6:	4c 89 fa             	mov    %r15,%rdx
  6f18a9:	48 8b 2d 38 64 3f 00 	mov    0x3f6438(%rip),%rbp        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f18b0:	ff d5                	call   *%rbp
  6f18b2:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
  6f18b9:	00 
  6f18ba:	41 c1 e4 05          	shl    $0x5,%r12d
  6f18be:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  6f18c5:	00 
  6f18c6:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
  6f18cd:	00 
  6f18ce:	42 0f 11 04 23       	movups %xmm0,(%rbx,%r12,1)
  6f18d3:	42 0f 11 4c 23 10    	movups %xmm1,0x10(%rbx,%r12,1)
  6f18d9:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f18de:	c1 e7 05             	shl    $0x5,%edi
  6f18e1:	48 01 df             	add    %rbx,%rdi
  6f18e4:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6f18e9:	c1 e2 05             	shl    $0x5,%edx
  6f18ec:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6f18f1:	ff 15 f9 63 3f 00    	call   *0x3f63f9(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  6f18f7:	4d 8d 7d 01          	lea    0x1(%r13),%r15
  6f18fb:	4b 8d 3c ee          	lea    (%r14,%r13,8),%rdi
  6f18ff:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6f1906:	4b 8d 34 ee          	lea    (%r14,%r13,8),%rsi
  6f190a:	48 81 c6 d8 01 00 00 	add    $0x1d8,%rsi
  6f1911:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  6f1918:	00 
  6f1919:	ff d5                	call   *%rbp
  6f191b:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6f1922:	00 
  6f1923:	4c 39 fe             	cmp    %r15,%rsi
  6f1926:	0f 86 be 00 00 00    	jbe    6f19ea <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f192c:	89 f1                	mov    %esi,%ecx
  6f192e:	44 29 f9             	sub    %r15d,%ecx
  6f1931:	83 e1 03             	and    $0x3,%ecx
  6f1934:	0f 84 f6 01 00 00    	je     6f1b30 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x780>
  6f193a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f1940:	49 8d 47 01          	lea    0x1(%r15),%rax
  6f1944:	4b 8b 94 fe c8 01 00 	mov    0x1c8(%r14,%r15,8),%rdx
  6f194b:	00 
  6f194c:	4c 89 b2 60 01 00 00 	mov    %r14,0x160(%rdx)
  6f1953:	66 44 89 ba c0 01 00 	mov    %r15w,0x1c0(%rdx)
  6f195a:	00 
  6f195b:	49 89 c7             	mov    %rax,%r15
  6f195e:	48 ff c9             	dec    %rcx
  6f1961:	75 dd                	jne    6f1940 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x590>
  6f1963:	49 f7 dd             	neg    %r13
  6f1966:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
  6f196a:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f196e:	83 f9 03             	cmp    $0x3,%ecx
  6f1971:	72 77                	jb     6f19ea <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f1973:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f197a:	84 00 00 00 00 00 
  6f1980:	49 8b 8c c6 c8 01 00 	mov    0x1c8(%r14,%rax,8),%rcx
  6f1987:	00 
  6f1988:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f198f:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f1996:	49 8b 8c c6 d0 01 00 	mov    0x1d0(%r14,%rax,8),%rcx
  6f199d:	00 
  6f199e:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f19a5:	8d 50 01             	lea    0x1(%rax),%edx
  6f19a8:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f19af:	49 8b 8c c6 d8 01 00 	mov    0x1d8(%r14,%rax,8),%rcx
  6f19b6:	00 
  6f19b7:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f19be:	8d 50 02             	lea    0x2(%rax),%edx
  6f19c1:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f19c8:	49 8b 8c c6 e0 01 00 	mov    0x1e0(%r14,%rax,8),%rcx
  6f19cf:	00 
  6f19d0:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f19d7:	8d 50 03             	lea    0x3(%rax),%edx
  6f19da:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f19e1:	48 83 c0 04          	add    $0x4,%rax
  6f19e5:	48 39 f0             	cmp    %rsi,%rax
  6f19e8:	75 96                	jne    6f1980 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x5d0>
  6f19ea:	66 41 ff 8e c2 01 00 	decw   0x1c2(%r14)
  6f19f1:	00 
  6f19f2:	be c8 01 00 00       	mov    $0x1c8,%esi
  6f19f7:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
  6f19fe:	00 
  6f19ff:	49 83 fc 02          	cmp    $0x2,%r12
  6f1a03:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  6f1a0a:	00 
  6f1a0b:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
  6f1a10:	0f 82 7a fc ff ff    	jb     6f1690 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f1a16:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6f1a1b:	48 ff c2             	inc    %rdx
  6f1a1e:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f1a25:	00 
  6f1a26:	48 2b 84 24 b0 00 00 	sub    0xb0(%rsp),%rax
  6f1a2d:	00 
  6f1a2e:	48 39 c2             	cmp    %rax,%rdx
  6f1a31:	0f 85 ae 01 00 00    	jne    6f1be5 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x835>
  6f1a37:	48 8d 83 c8 01 00 00 	lea    0x1c8(%rbx),%rax
  6f1a3e:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6f1a43:	4a 8d 3c f8          	lea    (%rax,%r15,8),%rdi
  6f1a47:	49 8d b5 c8 01 00 00 	lea    0x1c8(%r13),%rsi
  6f1a4e:	c1 e2 03             	shl    $0x3,%edx
  6f1a51:	ff 15 99 62 3f 00    	call   *0x3f6299(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  6f1a57:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  6f1a5e:	00 
  6f1a5f:	89 f9                	mov    %edi,%ecx
  6f1a61:	44 29 f9             	sub    %r15d,%ecx
  6f1a64:	ff c1                	inc    %ecx
  6f1a66:	4c 89 f8             	mov    %r15,%rax
  6f1a69:	83 e1 03             	and    $0x3,%ecx
  6f1a6c:	74 34                	je     6f1aa2 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x6f2>
  6f1a6e:	4c 89 fa             	mov    %r15,%rdx
  6f1a71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f1a78:	0f 1f 84 00 00 00 00 
  6f1a7f:	00 
  6f1a80:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f1a84:	48 8b b4 d3 c8 01 00 	mov    0x1c8(%rbx,%rdx,8),%rsi
  6f1a8b:	00 
  6f1a8c:	48 89 9e 60 01 00 00 	mov    %rbx,0x160(%rsi)
  6f1a93:	66 89 96 c0 01 00 00 	mov    %dx,0x1c0(%rsi)
  6f1a9a:	48 89 c2             	mov    %rax,%rdx
  6f1a9d:	48 ff c9             	dec    %rcx
  6f1aa0:	75 de                	jne    6f1a80 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x6d0>
  6f1aa2:	48 89 f9             	mov    %rdi,%rcx
  6f1aa5:	4c 29 f9             	sub    %r15,%rcx
  6f1aa8:	be 28 02 00 00       	mov    $0x228,%esi
  6f1aad:	83 f9 03             	cmp    $0x3,%ecx
  6f1ab0:	0f 82 da fb ff ff    	jb     6f1690 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f1ab6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f1abd:	00 00 00 
  6f1ac0:	48 8b 8c c3 c8 01 00 	mov    0x1c8(%rbx,%rax,8),%rcx
  6f1ac7:	00 
  6f1ac8:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f1acf:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f1ad6:	48 8b 8c c3 d0 01 00 	mov    0x1d0(%rbx,%rax,8),%rcx
  6f1add:	00 
  6f1ade:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f1ae5:	8d 50 01             	lea    0x1(%rax),%edx
  6f1ae8:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f1aef:	48 8b 8c c3 d8 01 00 	mov    0x1d8(%rbx,%rax,8),%rcx
  6f1af6:	00 
  6f1af7:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f1afe:	8d 50 02             	lea    0x2(%rax),%edx
  6f1b01:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f1b08:	48 8b 8c c3 e0 01 00 	mov    0x1e0(%rbx,%rax,8),%rcx
  6f1b0f:	00 
  6f1b10:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f1b17:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f1b1b:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f1b22:	48 83 c0 04          	add    $0x4,%rax
  6f1b26:	48 39 fa             	cmp    %rdi,%rdx
  6f1b29:	75 95                	jne    6f1ac0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x710>
  6f1b2b:	e9 60 fb ff ff       	jmp    6f1690 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f1b30:	4c 89 f8             	mov    %r15,%rax
  6f1b33:	49 f7 dd             	neg    %r13
  6f1b36:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
  6f1b3a:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f1b3e:	83 f9 03             	cmp    $0x3,%ecx
  6f1b41:	0f 83 39 fe ff ff    	jae    6f1980 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x5d0>
  6f1b47:	e9 9e fe ff ff       	jmp    6f19ea <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f1b4c:	48 85 c0             	test   %rax,%rax
  6f1b4f:	0f 85 a6 fa ff ff    	jne    6f15fb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1b55:	4c 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14
  6f1b5c:	00 
  6f1b5d:	49 8b 1e             	mov    (%r14),%rbx
  6f1b60:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f1b67:	48 85 db             	test   %rbx,%rbx
  6f1b6a:	0f 84 ad 00 00 00    	je     6f1c1d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x86d>
  6f1b70:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f1b74:	48 85 c0             	test   %rax,%rax
  6f1b77:	0f 84 af 00 00 00    	je     6f1c2c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87c>
  6f1b7d:	48 8b 3b             	mov    (%rbx),%rdi
  6f1b80:	48 8b 8f c8 01 00 00 	mov    0x1c8(%rdi),%rcx
  6f1b87:	48 89 0b             	mov    %rcx,(%rbx)
  6f1b8a:	48 ff c8             	dec    %rax
  6f1b8d:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f1b91:	48 c7 81 60 01 00 00 	movq   $0x0,0x160(%rcx)
  6f1b98:	00 00 00 00 
  6f1b9c:	be 28 02 00 00       	mov    $0x228,%esi
  6f1ba1:	ba 08 00 00 00       	mov    $0x8,%edx
  6f1ba6:	ff 15 1c 61 3f 00    	call   *0x3f611c(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  6f1bac:	49 89 1e             	mov    %rbx,(%r14)
  6f1baf:	e9 47 fa ff ff       	jmp    6f15fb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1bb4:	be 05 00 00 00       	mov    $0x5,%esi
  6f1bb9:	48 29 c6             	sub    %rax,%rsi
  6f1bbc:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  6f1bc3:	00 
  6f1bc4:	e8 07 18 00 00       	call   6f33d0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1bc9:	e9 2d fa ff ff       	jmp    6f15fb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1bce:	be 05 00 00 00       	mov    $0x5,%esi
  6f1bd3:	48 29 c6             	sub    %rax,%rsi
  6f1bd6:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f1bdb:	e8 30 1b 00 00       	call   6f3710 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1be0:	e9 16 fa ff ff       	jmp    6f15fb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1be5:	be 28 00 00 00       	mov    $0x28,%esi
  6f1bea:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  6f1bf1:	00 
  6f1bf2:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
  6f1bf9:	00 
  6f1bfa:	ff 15 00 61 3f 00    	call   *0x3f6100(%rip)        # ae7d00 <_DYNAMIC+0x280>
  6f1c00:	eb 28                	jmp    6f1c2a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87a>
  6f1c02:	48 8d 3d c0 1a 97 ff 	lea    -0x68e540(%rip),%rdi        # 636c9 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f1c09:	48 8d 15 98 7d 3c 00 	lea    0x3c7d98(%rip),%rdx        # ab99a8 <__frame_dummy_init_array_entry+0x1a0>
  6f1c10:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f1c15:	ff 15 05 61 3f 00    	call   *0x3f6105(%rip)        # ae7d20 <_DYNAMIC+0x2a0>
  6f1c1b:	eb 0d                	jmp    6f1c2a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87a>
  6f1c1d:	48 8d 3d 94 7c 3c 00 	lea    0x3c7c94(%rip),%rdi        # ab98b8 <__frame_dummy_init_array_entry+0xb0>
  6f1c24:	ff 15 de 60 3f 00    	call   *0x3f60de(%rip)        # ae7d08 <_DYNAMIC+0x288>
  6f1c2a:	0f 0b                	ud2
  6f1c2c:	48 8d 05 55 7c 3c 00 	lea    0x3c7c55(%rip),%rax        # ab9888 <__frame_dummy_init_array_entry+0x80>
  6f1c33:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6f1c3a:	00 
  6f1c3b:	be 21 00 00 00       	mov    $0x21,%esi
  6f1c40:	48 8d 05 44 19 97 ff 	lea    -0x68e6bc(%rip),%rax        # 6358b <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f1c47:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f1c4e:	00 
  6f1c4f:	eb 99                	jmp    6f1bea <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x83a>
  6f1c51:	48 89 c3             	mov    %rax,%rbx
  6f1c54:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  6f1c5b:	00 
  6f1c5c:	e8 cf 16 00 00       	call   6f3330 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueTyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtB4_6option6OptionNtNtBJ_11shared_text10SharedTextEEj2_EECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1c61:	48 89 df             	mov    %rbx,%rdi
  6f1c64:	e8 e7 67 3c 00       	call   ab8450 <_Unwind_Resume@plt>
  6f1c69:	ff 15 a9 60 3f 00    	call   *0x3f60a9(%rip)        # ae7d18 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
