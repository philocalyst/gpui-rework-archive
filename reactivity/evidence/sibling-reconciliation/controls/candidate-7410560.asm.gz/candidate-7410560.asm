
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000711380 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_>:
  711380:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
  711384:	48 39 f0             	cmp    %rsi,%rax
  711387:	0f 83 91 00 00 00    	jae    71141e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_+0x9e>
  71138d:	48 39 f2             	cmp    %rsi,%rdx
  711390:	75 01                	jne    711393 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_+0x13>
  711392:	c3                   	ret
  711393:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
  711397:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
  71139b:	48 c1 e2 03          	shl    $0x3,%rdx
  71139f:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  7113a3:	48 8d 14 0f          	lea    (%rdi,%rcx,1),%rdx
  7113a7:	eb 24                	jmp    7113cd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_+0x4d>
  7113a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  7113b0:	49 89 f8             	mov    %rdi,%r8
  7113b3:	49 89 30             	mov    %rsi,(%r8)
  7113b6:	0f 28 44 24 e8       	movaps -0x18(%rsp),%xmm0
  7113bb:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
  7113c0:	48 83 c2 18          	add    $0x18,%rdx
  7113c4:	48 83 c1 18          	add    $0x18,%rcx
  7113c8:	48 39 c2             	cmp    %rax,%rdx
  7113cb:	74 c5                	je     711392 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_+0x12>
  7113cd:	48 8b 32             	mov    (%rdx),%rsi
  7113d0:	48 3b 72 e8          	cmp    -0x18(%rdx),%rsi
  7113d4:	73 ea                	jae    7113c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_+0x40>
  7113d6:	0f 10 42 08          	movups 0x8(%rdx),%xmm0
  7113da:	0f 29 44 24 e8       	movaps %xmm0,-0x18(%rsp)
  7113df:	49 89 c9             	mov    %rcx,%r9
  7113e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7113e9:	1f 84 00 00 00 00 00 
  7113f0:	4e 8b 44 0f f8       	mov    -0x8(%rdi,%r9,1),%r8
  7113f5:	4e 89 44 0f 10       	mov    %r8,0x10(%rdi,%r9,1)
  7113fa:	42 0f 10 44 0f e8    	movups -0x18(%rdi,%r9,1),%xmm0
  711400:	42 0f 11 04 0f       	movups %xmm0,(%rdi,%r9,1)
  711405:	49 83 f9 18          	cmp    $0x18,%r9
  711409:	74 a5                	je     7113b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_+0x30>
  71140b:	4d 8d 41 e8          	lea    -0x18(%r9),%r8
  71140f:	4a 3b 74 0f d0       	cmp    -0x30(%rdi,%r9,1),%rsi
  711414:	4d 89 c1             	mov    %r8,%r9
  711417:	72 d7                	jb     7113f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_+0x70>
  711419:	49 01 f8             	add    %rdi,%r8
  71141c:	eb 95                	jmp    7113b3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_+0x33>
  71141e:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
