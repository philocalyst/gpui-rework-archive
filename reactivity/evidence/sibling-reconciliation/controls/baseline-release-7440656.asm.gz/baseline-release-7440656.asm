
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000718910 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>:
  718910:	55                   	push   %rbp
  718911:	41 57                	push   %r15
  718913:	41 56                	push   %r14
  718915:	41 55                	push   %r13
  718917:	41 54                	push   %r12
  718919:	53                   	push   %rbx
  71891a:	48 83 ec 78          	sub    $0x78,%rsp
  71891e:	48 89 fb             	mov    %rdi,%rbx
  718921:	4c 8b 2e             	mov    (%rsi),%r13
  718924:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718928:	4c 8b 7e 20          	mov    0x20(%rsi),%r15
  71892c:	4c 8b 66 28          	mov    0x28(%rsi),%r12
  718930:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718937:	00 
  718938:	48 85 c0             	test   %rax,%rax
  71893b:	0f 84 2a 01 00 00    	je     718a6b <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15b>
  718941:	49 89 f6             	mov    %rsi,%r14
  718944:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  718948:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  71894d:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718954:	49 39 cc             	cmp    %rcx,%r12
  718957:	72 31                	jb     71898a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7a>
  718959:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  718960:	48 8b a8 60 01 00 00 	mov    0x160(%rax),%rbp
  718967:	48 85 ed             	test   %rbp,%rbp
  71896a:	0f 84 fb 00 00 00    	je     718a6b <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15b>
  718970:	49 ff c7             	inc    %r15
  718973:	44 0f b7 a0 c0 01 00 	movzwl 0x1c0(%rax),%r12d
  71897a:	00 
  71897b:	48 89 e8             	mov    %rbp,%rax
  71897e:	66 44 3b a5 c2 01 00 	cmp    0x1c2(%rbp),%r12w
  718985:	00 
  718986:	73 d8                	jae    718960 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x50>
  718988:	eb 03                	jmp    71898d <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7d>
  71898a:	48 89 c5             	mov    %rax,%rbp
  71898d:	4a 8b b4 e5 68 01 00 	mov    0x168(%rbp,%r12,8),%rsi
  718994:	00 
  718995:	49 8b 45 00          	mov    0x0(%r13),%rax
  718999:	48 8b 38             	mov    (%rax),%rdi
  71899c:	ff 15 a6 23 3d 00    	call   *0x3d23a6(%rip)        # aead48 <_DYNAMIC+0x6d0>
  7189a2:	84 c0                	test   %al,%al
  7189a4:	0f 84 d8 00 00 00    	je     718a82 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x172>
  7189aa:	4d 85 ff             	test   %r15,%r15
  7189ad:	0f 84 83 00 00 00    	je     718a36 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x126>
  7189b3:	4a 8d 04 e5 d0 01 00 	lea    0x1d0(,%r12,8),%rax
  7189ba:	00 
  7189bb:	48 01 e8             	add    %rbp,%rax
  7189be:	4c 89 f9             	mov    %r15,%rcx
  7189c1:	48 83 e1 07          	and    $0x7,%rcx
  7189c5:	0f 84 95 00 00 00    	je     718a60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x150>
  7189cb:	31 d2                	xor    %edx,%edx
  7189cd:	0f 1f 00             	nopl   (%rax)
  7189d0:	48 8b 28             	mov    (%rax),%rbp
  7189d3:	48 8d 85 c8 01 00 00 	lea    0x1c8(%rbp),%rax
  7189da:	48 ff c2             	inc    %rdx
  7189dd:	48 39 d1             	cmp    %rdx,%rcx
  7189e0:	75 ee                	jne    7189d0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xc0>
  7189e2:	4c 89 f9             	mov    %r15,%rcx
  7189e5:	48 29 d1             	sub    %rdx,%rcx
  7189e8:	49 83 ff 08          	cmp    $0x8,%r15
  7189ec:	72 43                	jb     718a31 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x121>
  7189ee:	66 90                	xchg   %ax,%ax
  7189f0:	48 8b 00             	mov    (%rax),%rax
  7189f3:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  7189fa:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718a01:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718a08:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718a0f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718a16:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718a1d:	48 8b a8 c8 01 00 00 	mov    0x1c8(%rax),%rbp
  718a24:	48 8d 85 c8 01 00 00 	lea    0x1c8(%rbp),%rax
  718a2b:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  718a2f:	75 bf                	jne    7189f0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xe0>
  718a31:	45 31 e4             	xor    %r12d,%r12d
  718a34:	eb 03                	jmp    718a39 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x129>
  718a36:	49 ff c4             	inc    %r12
  718a39:	4d 89 66 28          	mov    %r12,0x28(%r14)
  718a3d:	0f 57 c0             	xorps  %xmm0,%xmm0
  718a40:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  718a45:	45 31 ff             	xor    %r15d,%r15d
  718a48:	48 89 e8             	mov    %rbp,%rax
  718a4b:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718a52:	49 39 cc             	cmp    %rcx,%r12
  718a55:	0f 83 05 ff ff ff    	jae    718960 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x50>
  718a5b:	e9 2a ff ff ff       	jmp    71898a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7a>
  718a60:	4c 89 f9             	mov    %r15,%rcx
  718a63:	49 83 ff 08          	cmp    $0x8,%r15
  718a67:	73 87                	jae    7189f0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xe0>
  718a69:	eb c6                	jmp    718a31 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x121>
  718a6b:	31 c0                	xor    %eax,%eax
  718a6d:	48 89 03             	mov    %rax,(%rbx)
  718a70:	48 89 d8             	mov    %rbx,%rax
  718a73:	48 83 c4 78          	add    $0x78,%rsp
  718a77:	5b                   	pop    %rbx
  718a78:	41 5c                	pop    %r12
  718a7a:	41 5d                	pop    %r13
  718a7c:	41 5e                	pop    %r14
  718a7e:	41 5f                	pop    %r15
  718a80:	5d                   	pop    %rbp
  718a81:	c3                   	ret
  718a82:	49 8b 46 08          	mov    0x8(%r14),%rax
  718a86:	48 ff 08             	decq   (%rax)
  718a89:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  718a8e:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
  718a93:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  718a98:	49 83 c6 10          	add    $0x10,%r14
  718a9c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  718aa1:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  718aa6:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  718aab:	4c 89 f2             	mov    %r14,%rdx
  718aae:	e8 2d 34 fd ff       	call   6ebee0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_>
  718ab3:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  718ab8:	48 89 43 28          	mov    %rax,0x28(%rbx)
  718abc:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  718ac1:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  718ac6:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  718aca:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  718ace:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  718ad3:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  718ad8:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  718add:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  718ae2:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  718ae7:	48 89 41 10          	mov    %rax,0x10(%rcx)
  718aeb:	0f 11 01             	movups %xmm0,(%rcx)
  718aee:	b8 01 00 00 00       	mov    $0x1,%eax
  718af3:	e9 75 ff ff ff       	jmp    718a6d <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15d>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
