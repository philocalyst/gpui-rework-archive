
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000729d30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2X_>:
  729d30:	55                   	push   %rbp
  729d31:	41 57                	push   %r15
  729d33:	41 56                	push   %r14
  729d35:	41 55                	push   %r13
  729d37:	41 54                	push   %r12
  729d39:	53                   	push   %rbx
  729d3a:	50                   	push   %rax
  729d3b:	49 89 d7             	mov    %rdx,%r15
  729d3e:	48 89 f3             	mov    %rsi,%rbx
  729d41:	49 89 fe             	mov    %rdi,%r14
  729d44:	48 b8 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rax
  729d4b:	ff ff 1f 
  729d4e:	48 85 c1             	test   %rax,%rcx
  729d51:	74 68                	je     729dbb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2X_+0x8b>
  729d53:	48 c1 e9 03          	shr    $0x3,%rcx
  729d57:	48 89 c8             	mov    %rcx,%rax
  729d5a:	48 c1 e0 05          	shl    $0x5,%rax
  729d5e:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
  729d62:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
  729d66:	4c 69 e9 a8 00 00 00 	imul   $0xa8,%rcx,%r13
  729d6d:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
  729d71:	4c 89 f7             	mov    %r14,%rdi
  729d74:	48 89 cd             	mov    %rcx,%rbp
  729d77:	4c 89 04 24          	mov    %r8,(%rsp)
  729d7b:	e8 b0 ff ff ff       	call   729d30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2X_>
  729d80:	49 89 c6             	mov    %rax,%r14
  729d83:	4a 8d 34 23          	lea    (%rbx,%r12,1),%rsi
  729d87:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
  729d8b:	48 89 df             	mov    %rbx,%rdi
  729d8e:	48 89 e9             	mov    %rbp,%rcx
  729d91:	4c 8b 04 24          	mov    (%rsp),%r8
  729d95:	e8 96 ff ff ff       	call   729d30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2X_>
  729d9a:	48 89 c3             	mov    %rax,%rbx
  729d9d:	4d 01 fc             	add    %r15,%r12
  729da0:	4d 01 fd             	add    %r15,%r13
  729da3:	4c 89 ff             	mov    %r15,%rdi
  729da6:	4c 89 e6             	mov    %r12,%rsi
  729da9:	4c 89 ea             	mov    %r13,%rdx
  729dac:	48 89 e9             	mov    %rbp,%rcx
  729daf:	4c 8b 04 24          	mov    (%rsp),%r8
  729db3:	e8 78 ff ff ff       	call   729d30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2X_>
  729db8:	49 89 c7             	mov    %rax,%r15
  729dbb:	49 8b 06             	mov    (%r14),%rax
  729dbe:	48 8b 0b             	mov    (%rbx),%rcx
  729dc1:	48 39 c8             	cmp    %rcx,%rax
  729dc4:	0f 92 c2             	setb   %dl
  729dc7:	49 8b 37             	mov    (%r15),%rsi
  729dca:	48 39 f0             	cmp    %rsi,%rax
  729dcd:	0f 92 c0             	setb   %al
  729dd0:	30 d0                	xor    %dl,%al
  729dd2:	48 39 f1             	cmp    %rsi,%rcx
  729dd5:	0f 92 c1             	setb   %cl
  729dd8:	30 d1                	xor    %dl,%cl
  729dda:	49 0f 45 df          	cmovne %r15,%rbx
  729dde:	84 c0                	test   %al,%al
  729de0:	49 0f 45 de          	cmovne %r14,%rbx
  729de4:	48 89 d8             	mov    %rbx,%rax
  729de7:	48 83 c4 08          	add    $0x8,%rsp
  729deb:	5b                   	pop    %rbx
  729dec:	41 5c                	pop    %r12
  729dee:	41 5d                	pop    %r13
  729df0:	41 5e                	pop    %r14
  729df2:	41 5f                	pop    %r15
  729df4:	5d                   	pop    %rbp
  729df5:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
