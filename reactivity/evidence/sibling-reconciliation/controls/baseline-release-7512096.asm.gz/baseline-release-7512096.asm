
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000072a020 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>:
  72a020:	55                   	push   %rbp
  72a021:	41 57                	push   %r15
  72a023:	41 56                	push   %r14
  72a025:	41 55                	push   %r13
  72a027:	41 54                	push   %r12
  72a029:	53                   	push   %rbx
  72a02a:	48 83 ec 58          	sub    $0x58,%rsp
  72a02e:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  72a033:	49 89 ce             	mov    %rcx,%r14
  72a036:	49 89 d7             	mov    %rdx,%r15
  72a039:	49 89 f5             	mov    %rsi,%r13
  72a03c:	49 89 fc             	mov    %rdi,%r12
  72a03f:	48 83 fe 21          	cmp    $0x21,%rsi
  72a043:	73 1e                	jae    72a063 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x43>
  72a045:	4c 89 e7             	mov    %r12,%rdi
  72a048:	4c 89 ee             	mov    %r13,%rsi
  72a04b:	4c 89 fa             	mov    %r15,%rdx
  72a04e:	4c 89 f1             	mov    %r14,%rcx
  72a051:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  72a058:	00 
  72a059:	e8 12 94 fe ff       	call   713470 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2c_11collections5btree3mapINtB2Y_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB3Y_8adapters3map3MapINtNtB8_4iter4IterNtB1w_9ListDraftENCNvMst_NtB1y_7runtimeINtB5Z_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6u_>
  72a05e:	e9 a9 05 00 00       	jmp    72a60c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5ec>
  72a063:	44 89 c3             	mov    %r8d,%ebx
  72a066:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  72a06b:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72a070:	85 db                	test   %ebx,%ebx
  72a072:	0f 84 73 05 00 00    	je     72a5eb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5cb>
  72a078:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72a07d:	48 89 f1             	mov    %rsi,%rcx
  72a080:	48 c1 e9 03          	shr    $0x3,%rcx
  72a084:	48 89 c8             	mov    %rcx,%rax
  72a087:	48 c1 e0 06          	shl    $0x6,%rax
  72a08b:	4c 01 e0             	add    %r12,%rax
  72a08e:	48 6b d1 70          	imul   $0x70,%rcx,%rdx
  72a092:	4c 01 e2             	add    %r12,%rdx
  72a095:	48 83 fe 40          	cmp    $0x40,%rsi
  72a099:	73 35                	jae    72a0d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xb0>
  72a09b:	49 8b 0c 24          	mov    (%r12),%rcx
  72a09f:	48 8b 30             	mov    (%rax),%rsi
  72a0a2:	48 39 f1             	cmp    %rsi,%rcx
  72a0a5:	40 0f 92 c7          	setb   %dil
  72a0a9:	4c 8b 02             	mov    (%rdx),%r8
  72a0ac:	4c 39 c1             	cmp    %r8,%rcx
  72a0af:	0f 92 c1             	setb   %cl
  72a0b2:	40 30 f9             	xor    %dil,%cl
  72a0b5:	4c 39 c6             	cmp    %r8,%rsi
  72a0b8:	40 0f 92 c6          	setb   %sil
  72a0bc:	40 30 fe             	xor    %dil,%sil
  72a0bf:	48 0f 45 c2          	cmovne %rdx,%rax
  72a0c3:	84 c9                	test   %cl,%cl
  72a0c5:	49 0f 45 c4          	cmovne %r12,%rax
  72a0c9:	eb 10                	jmp    72a0db <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xbb>
  72a0cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72a0d0:	4c 89 e7             	mov    %r12,%rdi
  72a0d3:	48 89 c6             	mov    %rax,%rsi
  72a0d6:	e8 25 fd ff ff       	call   729e00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72a0db:	ff cb                	dec    %ebx
  72a0dd:	89 5c 24 2c          	mov    %ebx,0x2c(%rsp)
  72a0e1:	48 89 c5             	mov    %rax,%rbp
  72a0e4:	4c 29 e5             	sub    %r12,%rbp
  72a0e7:	48 89 e9             	mov    %rbp,%rcx
  72a0ea:	48 c1 e9 04          	shr    $0x4,%rcx
  72a0ee:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  72a0f3:	0f 10 00             	movups (%rax),%xmm0
  72a0f6:	48 8b 00             	mov    (%rax),%rax
  72a0f9:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  72a0fe:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  72a104:	74 0e                	je     72a114 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xf4>
  72a106:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  72a10b:	48 39 01             	cmp    %rax,(%rcx)
  72a10e:	0f 83 8c 02 00 00    	jae    72a3a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x380>
  72a114:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  72a119:	49 39 de             	cmp    %rbx,%r14
  72a11c:	0f 82 0e 05 00 00    	jb     72a630 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x610>
  72a122:	49 89 de             	mov    %rbx,%r14
  72a125:	49 c1 e6 04          	shl    $0x4,%r14
  72a129:	4b 8d 0c 37          	lea    (%r15,%r14,1),%rcx
  72a12d:	45 31 ed             	xor    %r13d,%r13d
  72a130:	4c 89 e0             	mov    %r12,%rax
  72a133:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72a138:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  72a13d:	0f 1f 00             	nopl   (%rax)
  72a140:	48 89 d7             	mov    %rdx,%rdi
  72a143:	48 83 ef 03          	sub    $0x3,%rdi
  72a147:	be 00 00 00 00       	mov    $0x0,%esi
  72a14c:	48 0f 43 f7          	cmovae %rdi,%rsi
  72a150:	48 c1 e6 04          	shl    $0x4,%rsi
  72a154:	4c 01 e6             	add    %r12,%rsi
  72a157:	48 39 f0             	cmp    %rsi,%rax
  72a15a:	0f 83 a4 00 00 00    	jae    72a204 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x1e4>
  72a160:	48 8b 38             	mov    (%rax),%rdi
  72a163:	4c 8d 41 f0          	lea    -0x10(%rcx),%r8
  72a167:	45 31 c9             	xor    %r9d,%r9d
  72a16a:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72a16e:	4d 0f 42 c7          	cmovb  %r15,%r8
  72a172:	41 0f 92 c1          	setb   %r9b
  72a176:	4c 89 ef             	mov    %r13,%rdi
  72a179:	48 c1 e7 04          	shl    $0x4,%rdi
  72a17d:	4f 8d 14 29          	lea    (%r9,%r13,1),%r10
  72a181:	4c 8b 58 10          	mov    0x10(%rax),%r11
  72a185:	49 c1 e2 04          	shl    $0x4,%r10
  72a189:	4d 3b 1c 2c          	cmp    (%r12,%rbp,1),%r11
  72a18d:	0f 10 00             	movups (%rax),%xmm0
  72a190:	4c 8d 59 e0          	lea    -0x20(%rcx),%r11
  72a194:	4d 0f 42 df          	cmovb  %r15,%r11
  72a198:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72a19d:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72a1a1:	4d 11 cd             	adc    %r9,%r13
  72a1a4:	43 0f 11 04 13       	movups %xmm0,(%r11,%r10,1)
  72a1a9:	48 8b 78 20          	mov    0x20(%rax),%rdi
  72a1ad:	4c 8d 41 d0          	lea    -0x30(%rcx),%r8
  72a1b1:	45 31 c9             	xor    %r9d,%r9d
  72a1b4:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72a1b8:	4d 0f 42 c7          	cmovb  %r15,%r8
  72a1bc:	41 0f 92 c1          	setb   %r9b
  72a1c0:	4c 89 ef             	mov    %r13,%rdi
  72a1c3:	48 c1 e7 04          	shl    $0x4,%rdi
  72a1c7:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72a1cb:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72a1d0:	4b 8d 3c 29          	lea    (%r9,%r13,1),%rdi
  72a1d4:	4c 8b 40 30          	mov    0x30(%rax),%r8
  72a1d8:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72a1dc:	48 c1 e7 04          	shl    $0x4,%rdi
  72a1e0:	4d 3b 04 2c          	cmp    (%r12,%rbp,1),%r8
  72a1e4:	49 89 c8             	mov    %rcx,%r8
  72a1e7:	4d 0f 42 c7          	cmovb  %r15,%r8
  72a1eb:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72a1ef:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72a1f4:	4d 11 cd             	adc    %r9,%r13
  72a1f7:	48 83 c0 40          	add    $0x40,%rax
  72a1fb:	48 39 f0             	cmp    %rsi,%rax
  72a1fe:	0f 82 5c ff ff ff    	jb     72a160 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x140>
  72a204:	48 89 d6             	mov    %rdx,%rsi
  72a207:	48 c1 e6 04          	shl    $0x4,%rsi
  72a20b:	4c 01 e6             	add    %r12,%rsi
  72a20e:	48 39 f0             	cmp    %rsi,%rax
  72a211:	73 3b                	jae    72a24e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x22e>
  72a213:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72a21a:	84 00 00 00 00 00 
  72a220:	48 8b 38             	mov    (%rax),%rdi
  72a223:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72a227:	4d 89 e8             	mov    %r13,%r8
  72a22a:	49 c1 e0 04          	shl    $0x4,%r8
  72a22e:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72a232:	48 89 cf             	mov    %rcx,%rdi
  72a235:	49 0f 42 ff          	cmovb  %r15,%rdi
  72a239:	0f 10 00             	movups (%rax),%xmm0
  72a23c:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72a241:	49 83 d5 00          	adc    $0x0,%r13
  72a245:	48 83 c0 10          	add    $0x10,%rax
  72a249:	48 39 f0             	cmp    %rsi,%rax
  72a24c:	72 d2                	jb     72a220 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x200>
  72a24e:	48 39 da             	cmp    %rbx,%rdx
  72a251:	74 2d                	je     72a280 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x260>
  72a253:	4c 89 ea             	mov    %r13,%rdx
  72a256:	48 c1 e2 04          	shl    $0x4,%rdx
  72a25a:	0f 10 00             	movups (%rax),%xmm0
  72a25d:	0f 11 44 11 f0       	movups %xmm0,-0x10(%rcx,%rdx,1)
  72a262:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72a266:	48 83 c0 10          	add    $0x10,%rax
  72a26a:	48 89 da             	mov    %rbx,%rdx
  72a26d:	e9 ce fe ff ff       	jmp    72a140 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x120>
  72a272:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72a279:	1f 84 00 00 00 00 00 
  72a280:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  72a285:	4c 89 eb             	mov    %r13,%rbx
  72a288:	48 c1 e3 04          	shl    $0x4,%rbx
  72a28c:	4c 89 e7             	mov    %r12,%rdi
  72a28f:	4c 89 fe             	mov    %r15,%rsi
  72a292:	48 89 da             	mov    %rbx,%rdx
  72a295:	ff 15 4d 06 3c 00    	call   *0x3c064d(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  72a29b:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72a2a0:	4c 29 ee             	sub    %r13,%rsi
  72a2a3:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72a2aa:	ff ff 0f 
  72a2ad:	4b 8d 3c 37          	lea    (%r15,%r14,1),%rdi
  72a2b1:	0f 84 8e 00 00 00    	je     72a345 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x325>
  72a2b7:	49 8d 45 01          	lea    0x1(%r13),%rax
  72a2bb:	48 39 44 24 10       	cmp    %rax,0x10(%rsp)
  72a2c0:	75 0e                	jne    72a2d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x2b0>
  72a2c2:	31 c0                	xor    %eax,%eax
  72a2c4:	eb 65                	jmp    72a32b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x30b>
  72a2c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72a2cd:	00 00 00 
  72a2d0:	48 89 f1             	mov    %rsi,%rcx
  72a2d3:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72a2d7:	49 8d 44 24 10       	lea    0x10(%r12),%rax
  72a2dc:	48 8d 14 18          	lea    (%rax,%rbx,1),%rdx
  72a2e0:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72a2e4:	49 01 c6             	add    %rax,%r14
  72a2e7:	31 c0                	xor    %eax,%eax
  72a2e9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72a2f0:	48 89 c7             	mov    %rax,%rdi
  72a2f3:	41 0f 10 06          	movups (%r14),%xmm0
  72a2f7:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72a2fb:	48 83 c0 02          	add    $0x2,%rax
  72a2ff:	4c 31 c7             	xor    %r8,%rdi
  72a302:	48 c1 e7 04          	shl    $0x4,%rdi
  72a306:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72a30b:	41 0f 10 04 39       	movups (%r9,%rdi,1),%xmm0
  72a310:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  72a315:	0f 11 02             	movups %xmm0,(%rdx)
  72a318:	48 83 c2 20          	add    $0x20,%rdx
  72a31c:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
  72a320:	48 39 c1             	cmp    %rax,%rcx
  72a323:	75 cb                	jne    72a2f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x2d0>
  72a325:	40 f6 c6 01          	test   $0x1,%sil
  72a329:	74 1a                	je     72a345 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x325>
  72a32b:	49 8d 0c 1c          	lea    (%r12,%rbx,1),%rcx
  72a32f:	48 89 c2             	mov    %rax,%rdx
  72a332:	48 f7 d2             	not    %rdx
  72a335:	48 c1 e2 04          	shl    $0x4,%rdx
  72a339:	48 c1 e0 04          	shl    $0x4,%rax
  72a33d:	0f 10 04 17          	movups (%rdi,%rdx,1),%xmm0
  72a341:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  72a345:	4d 85 ed             	test   %r13,%r13
  72a348:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72a34d:	74 51                	je     72a3a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x380>
  72a34f:	4c 39 6c 24 10       	cmp    %r13,0x10(%rsp)
  72a354:	0f 82 d8 02 00 00    	jb     72a632 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x612>
  72a35a:	4c 01 e3             	add    %r12,%rbx
  72a35d:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  72a364:	00 
  72a365:	48 89 04 24          	mov    %rax,(%rsp)
  72a369:	48 89 df             	mov    %rbx,%rdi
  72a36c:	4c 89 fa             	mov    %r15,%rdx
  72a36f:	4c 89 f1             	mov    %r14,%rcx
  72a372:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72a376:	41 89 d8             	mov    %ebx,%r8d
  72a379:	4c 8d 4c 24 40       	lea    0x40(%rsp),%r9
  72a37e:	e8 9d fc ff ff       	call   72a020 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72a383:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72a388:	49 83 fd 21          	cmp    $0x21,%r13
  72a38c:	0f 83 de fc ff ff    	jae    72a070 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x50>
  72a392:	e9 ae fc ff ff       	jmp    72a045 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x25>
  72a397:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72a39e:	00 00 
  72a3a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72a3a5:	49 39 c6             	cmp    %rax,%r14
  72a3a8:	0f 82 82 02 00 00    	jb     72a630 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x610>
  72a3ae:	48 c1 e0 04          	shl    $0x4,%rax
  72a3b2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72a3b7:	49 8d 0c 07          	lea    (%r15,%rax,1),%rcx
  72a3bb:	31 db                	xor    %ebx,%ebx
  72a3bd:	4c 89 e0             	mov    %r12,%rax
  72a3c0:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72a3c5:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
  72a3ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  72a3d0:	4c 89 d6             	mov    %r10,%rsi
  72a3d3:	48 83 ee 03          	sub    $0x3,%rsi
  72a3d7:	ba 00 00 00 00       	mov    $0x0,%edx
  72a3dc:	48 0f 43 d6          	cmovae %rsi,%rdx
  72a3e0:	48 c1 e2 04          	shl    $0x4,%rdx
  72a3e4:	4c 01 e2             	add    %r12,%rdx
  72a3e7:	48 39 d0             	cmp    %rdx,%rax
  72a3ea:	0f 83 9d 00 00 00    	jae    72a48d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x46d>
  72a3f0:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72a3f4:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
  72a3f8:	49 89 d8             	mov    %rbx,%r8
  72a3fb:	49 c1 e0 04          	shl    $0x4,%r8
  72a3ff:	48 3b 30             	cmp    (%rax),%rsi
  72a402:	49 0f 43 ff          	cmovae %r15,%rdi
  72a406:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72a40a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72a40e:	49 89 d9             	mov    %rbx,%r9
  72a411:	49 c1 e1 04          	shl    $0x4,%r9
  72a415:	48 3b 70 10          	cmp    0x10(%rax),%rsi
  72a419:	0f 10 00             	movups (%rax),%xmm0
  72a41c:	48 8d 71 e0          	lea    -0x20(%rcx),%rsi
  72a420:	49 0f 43 f7          	cmovae %r15,%rsi
  72a424:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72a429:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72a42d:	49 8b 3c 2c          	mov    (%r12,%rbp,1),%rdi
  72a431:	49 89 d8             	mov    %rbx,%r8
  72a434:	49 c1 e0 04          	shl    $0x4,%r8
  72a438:	48 3b 78 20          	cmp    0x20(%rax),%rdi
  72a43c:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72a440:	48 8d 79 d0          	lea    -0x30(%rcx),%rdi
  72a444:	49 0f 43 ff          	cmovae %r15,%rdi
  72a448:	42 0f 11 04 0e       	movups %xmm0,(%rsi,%r9,1)
  72a44d:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72a451:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72a455:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72a45a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72a45e:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72a462:	48 89 df             	mov    %rbx,%rdi
  72a465:	48 c1 e7 04          	shl    $0x4,%rdi
  72a469:	48 3b 70 30          	cmp    0x30(%rax),%rsi
  72a46d:	48 89 ce             	mov    %rcx,%rsi
  72a470:	49 0f 43 f7          	cmovae %r15,%rsi
  72a474:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72a478:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72a47c:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72a480:	48 83 c0 40          	add    $0x40,%rax
  72a484:	48 39 d0             	cmp    %rdx,%rax
  72a487:	0f 82 63 ff ff ff    	jb     72a3f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x3d0>
  72a48d:	4c 89 d2             	mov    %r10,%rdx
  72a490:	48 c1 e2 04          	shl    $0x4,%rdx
  72a494:	4c 01 e2             	add    %r12,%rdx
  72a497:	48 39 d0             	cmp    %rdx,%rax
  72a49a:	73 31                	jae    72a4cd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4ad>
  72a49c:	0f 1f 40 00          	nopl   0x0(%rax)
  72a4a0:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72a4a4:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72a4a8:	48 89 df             	mov    %rbx,%rdi
  72a4ab:	48 c1 e7 04          	shl    $0x4,%rdi
  72a4af:	48 3b 30             	cmp    (%rax),%rsi
  72a4b2:	48 89 ce             	mov    %rcx,%rsi
  72a4b5:	49 0f 43 f7          	cmovae %r15,%rsi
  72a4b9:	0f 10 00             	movups (%rax),%xmm0
  72a4bc:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72a4c0:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72a4c4:	48 83 c0 10          	add    $0x10,%rax
  72a4c8:	48 39 d0             	cmp    %rdx,%rax
  72a4cb:	72 d3                	jb     72a4a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x480>
  72a4cd:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  72a4d2:	4d 39 f2             	cmp    %r14,%r10
  72a4d5:	74 29                	je     72a500 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4e0>
  72a4d7:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72a4db:	48 89 da             	mov    %rbx,%rdx
  72a4de:	48 c1 e2 04          	shl    $0x4,%rdx
  72a4e2:	0f 10 00             	movups (%rax),%xmm0
  72a4e5:	41 0f 11 04 17       	movups %xmm0,(%r15,%rdx,1)
  72a4ea:	48 ff c3             	inc    %rbx
  72a4ed:	48 83 c0 10          	add    $0x10,%rax
  72a4f1:	4d 89 f2             	mov    %r14,%r10
  72a4f4:	e9 d7 fe ff ff       	jmp    72a3d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x3b0>
  72a4f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72a500:	48 89 dd             	mov    %rbx,%rbp
  72a503:	48 c1 e5 04          	shl    $0x4,%rbp
  72a507:	4c 89 e7             	mov    %r12,%rdi
  72a50a:	4c 89 fe             	mov    %r15,%rsi
  72a50d:	48 89 ea             	mov    %rbp,%rdx
  72a510:	ff 15 d2 03 3c 00    	call   *0x3c03d2(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  72a516:	4d 89 f5             	mov    %r14,%r13
  72a519:	49 29 dd             	sub    %rbx,%r13
  72a51c:	0f 84 f9 00 00 00    	je     72a61b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5fb>
  72a522:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
  72a526:	48 8d 43 01          	lea    0x1(%rbx),%rax
  72a52a:	49 39 c6             	cmp    %rax,%r14
  72a52d:	75 09                	jne    72a538 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x518>
  72a52f:	31 c0                	xor    %eax,%eax
  72a531:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72a536:	eb 69                	jmp    72a5a1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x581>
  72a538:	4c 89 e9             	mov    %r13,%rcx
  72a53b:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72a53f:	49 8d 14 2c          	lea    (%r12,%rbp,1),%rdx
  72a543:	48 83 c2 10          	add    $0x10,%rdx
  72a547:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72a54b:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  72a550:	49 01 c2             	add    %rax,%r10
  72a553:	31 c0                	xor    %eax,%eax
  72a555:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72a55c:	ff ff 0f 
  72a55f:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72a564:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72a56b:	00 00 00 00 00 
  72a570:	48 89 c6             	mov    %rax,%rsi
  72a573:	41 0f 10 02          	movups (%r10),%xmm0
  72a577:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72a57b:	48 83 c0 02          	add    $0x2,%rax
  72a57f:	4c 31 c6             	xor    %r8,%rsi
  72a582:	48 c1 e6 04          	shl    $0x4,%rsi
  72a586:	41 0f 10 04 31       	movups (%r9,%rsi,1),%xmm0
  72a58b:	0f 11 02             	movups %xmm0,(%rdx)
  72a58e:	48 83 c2 20          	add    $0x20,%rdx
  72a592:	49 83 c2 e0          	add    $0xffffffffffffffe0,%r10
  72a596:	48 39 c1             	cmp    %rax,%rcx
  72a599:	75 d5                	jne    72a570 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x550>
  72a59b:	41 f6 c5 01          	test   $0x1,%r13b
  72a59f:	74 17                	je     72a5b8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x598>
  72a5a1:	48 89 c1             	mov    %rax,%rcx
  72a5a4:	48 f7 d1             	not    %rcx
  72a5a7:	48 c1 e1 04          	shl    $0x4,%rcx
  72a5ab:	48 c1 e0 04          	shl    $0x4,%rax
  72a5af:	41 0f 10 04 09       	movups (%r9,%rcx,1),%xmm0
  72a5b4:	0f 11 04 07          	movups %xmm0,(%rdi,%rax,1)
  72a5b8:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72a5bd:	48 39 da             	cmp    %rbx,%rdx
  72a5c0:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72a5c5:	0f 82 80 00 00 00    	jb     72a64b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x62b>
  72a5cb:	49 89 fc             	mov    %rdi,%r12
  72a5ce:	b8 00 00 00 00       	mov    $0x0,%eax
  72a5d3:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72a5d8:	49 83 fd 21          	cmp    $0x21,%r13
  72a5dc:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72a5e0:	0f 83 85 fa ff ff    	jae    72a06b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4b>
  72a5e6:	e9 5d fa ff ff       	jmp    72a048 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x28>
  72a5eb:	4c 89 e7             	mov    %r12,%rdi
  72a5ee:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72a5f3:	4c 89 fa             	mov    %r15,%rdx
  72a5f6:	4c 89 f1             	mov    %r14,%rcx
  72a5f9:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72a5ff:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  72a606:	00 
  72a607:	e8 14 70 00 00       	call   731620 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>
  72a60c:	48 83 c4 58          	add    $0x58,%rsp
  72a610:	5b                   	pop    %rbx
  72a611:	41 5c                	pop    %r12
  72a613:	41 5d                	pop    %r13
  72a615:	41 5e                	pop    %r14
  72a617:	41 5f                	pop    %r15
  72a619:	5d                   	pop    %rbp
  72a61a:	c3                   	ret
  72a61b:	4c 03 64 24 18       	add    0x18(%rsp),%r12
  72a620:	45 31 ed             	xor    %r13d,%r13d
  72a623:	4c 89 e7             	mov    %r12,%rdi
  72a626:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72a62b:	e9 18 fa ff ff       	jmp    72a048 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x28>
  72a630:	0f 0b                	ud2
  72a632:	48 8d 3d 3b eb 93 ff 	lea    -0x6c14c5(%rip),%rdi        # 69174 <anon.845a5de654f5e1fb5213dc527790f4a9.0.llvm.5591148014433919328+0x19c>
  72a639:	48 8d 15 68 34 39 00 	lea    0x393468(%rip),%rdx        # abdaa8 <anon.845a5de654f5e1fb5213dc527790f4a9.6.llvm.5591148014433919328+0x120>
  72a640:	be 13 00 00 00       	mov    $0x13,%esi
  72a645:	ff 15 cd 02 3c 00    	call   *0x3c02cd(%rip)        # aea918 <_DYNAMIC+0x2a0>
  72a64b:	48 8d 0d 6e 34 39 00 	lea    0x39346e(%rip),%rcx        # abdac0 <anon.845a5de654f5e1fb5213dc527790f4a9.6.llvm.5591148014433919328+0x138>
  72a652:	48 89 df             	mov    %rbx,%rdi
  72a655:	48 89 d6             	mov    %rdx,%rsi
  72a658:	ff 15 aa 02 3c 00    	call   *0x3c02aa(%rip)        # aea908 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
