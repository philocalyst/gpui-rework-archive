
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000714280 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_>:
  714280:	55                   	push   %rbp
  714281:	41 57                	push   %r15
  714283:	41 56                	push   %r14
  714285:	41 55                	push   %r13
  714287:	41 54                	push   %r12
  714289:	53                   	push   %rbx
  71428a:	48 83 ec 58          	sub    $0x58,%rsp
  71428e:	49 89 d5             	mov    %rdx,%r13
  714291:	48 89 fb             	mov    %rdi,%rbx
  714294:	48 89 d0             	mov    %rdx,%rax
  714297:	48 29 f0             	sub    %rsi,%rax
  71429a:	48 c1 e8 03          	shr    $0x3,%rax
  71429e:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  7142a5:	c3 30 0c 
  7142a8:	48 f7 e1             	mul    %rcx
  7142ab:	49 29 f5             	sub    %rsi,%r13
  7142ae:	74 42                	je     7142f2 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x72>
  7142b0:	48 89 f5             	mov    %rsi,%rbp
  7142b3:	49 89 d4             	mov    %rdx,%r12
  7142b6:	49 89 d6             	mov    %rdx,%r14
  7142b9:	49 c1 e6 04          	shl    $0x4,%r14
  7142bd:	ff 15 15 66 3d 00    	call   *0x3d6615(%rip)        # aea8d8 <_DYNAMIC+0x260>
  7142c3:	be 08 00 00 00       	mov    $0x8,%esi
  7142c8:	4c 89 f7             	mov    %r14,%rdi
  7142cb:	ff 15 e7 65 3d 00    	call   *0x3d65e7(%rip)        # aea8b8 <_DYNAMIC+0x240>
  7142d1:	48 85 c0             	test   %rax,%rax
  7142d4:	0f 84 b9 01 00 00    	je     714493 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x213>
  7142da:	49 89 c7             	mov    %rax,%r15
  7142dd:	49 8d 44 24 ff       	lea    -0x1(%r12),%rax
  7142e2:	44 89 e1             	mov    %r12d,%ecx
  7142e5:	83 e1 03             	and    $0x3,%ecx
  7142e8:	48 83 f8 03          	cmp    $0x3,%rax
  7142ec:	73 18                	jae    714306 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x86>
  7142ee:	31 c0                	xor    %eax,%eax
  7142f0:	eb 6e                	jmp    714360 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0xe0>
  7142f2:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  7142f9:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  714300:	00 
  714301:	e9 46 01 00 00       	jmp    71444c <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x1cc>
  714306:	4c 89 e2             	mov    %r12,%rdx
  714309:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
  71430d:	48 8d b5 90 02 00 00 	lea    0x290(%rbp),%rsi
  714314:	49 8d 7f 30          	lea    0x30(%r15),%rdi
  714318:	31 c0                	xor    %eax,%eax
  71431a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  714320:	0f 10 86 08 fe ff ff 	movups -0x1f8(%rsi),%xmm0
  714327:	0f 11 47 d0          	movups %xmm0,-0x30(%rdi)
  71432b:	0f 10 86 b0 fe ff ff 	movups -0x150(%rsi),%xmm0
  714332:	0f 11 47 e0          	movups %xmm0,-0x20(%rdi)
  714336:	0f 10 86 58 ff ff ff 	movups -0xa8(%rsi),%xmm0
  71433d:	0f 11 47 f0          	movups %xmm0,-0x10(%rdi)
  714341:	0f 10 06             	movups (%rsi),%xmm0
  714344:	0f 11 07             	movups %xmm0,(%rdi)
  714347:	48 83 c0 04          	add    $0x4,%rax
  71434b:	48 81 c6 a0 02 00 00 	add    $0x2a0,%rsi
  714352:	48 83 c7 40          	add    $0x40,%rdi
  714356:	48 39 c2             	cmp    %rax,%rdx
  714359:	75 c5                	jne    714320 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0xa0>
  71435b:	48 85 c9             	test   %rcx,%rcx
  71435e:	74 47                	je     7143a7 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x127>
  714360:	48 69 d0 a8 00 00 00 	imul   $0xa8,%rax,%rdx
  714367:	48 c1 e0 04          	shl    $0x4,%rax
  71436b:	4c 01 f8             	add    %r15,%rax
  71436e:	48 01 ea             	add    %rbp,%rdx
  714371:	48 81 c2 98 00 00 00 	add    $0x98,%rdx
  714378:	48 69 c9 a8 00 00 00 	imul   $0xa8,%rcx,%rcx
  71437f:	31 f6                	xor    %esi,%esi
  714381:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  714388:	0f 1f 84 00 00 00 00 
  71438f:	00 
  714390:	0f 10 04 32          	movups (%rdx,%rsi,1),%xmm0
  714394:	0f 11 00             	movups %xmm0,(%rax)
  714397:	48 83 c0 10          	add    $0x10,%rax
  71439b:	48 81 c6 a8 00 00 00 	add    $0xa8,%rsi
  7143a2:	48 39 f1             	cmp    %rsi,%rcx
  7143a5:	75 e9                	jne    714390 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x110>
  7143a7:	48 8d 44 24 07       	lea    0x7(%rsp),%rax
  7143ac:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  7143b1:	49 81 fd a8 00 00 00 	cmp    $0xa8,%r13
  7143b8:	0f 85 a0 00 00 00    	jne    71445e <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x1de>
  7143be:	ff 15 14 65 3d 00    	call   *0x3d6514(%rip)        # aea8d8 <_DYNAMIC+0x260>
  7143c4:	bf c0 00 00 00       	mov    $0xc0,%edi
  7143c9:	be 08 00 00 00       	mov    $0x8,%esi
  7143ce:	ff 15 e4 64 3d 00    	call   *0x3d64e4(%rip)        # aea8b8 <_DYNAMIC+0x240>
  7143d4:	48 85 c0             	test   %rax,%rax
  7143d7:	0f 84 a4 00 00 00    	je     714481 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x201>
  7143dd:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  7143e4:	66 c7 80 ba 00 00 00 	movw   $0x0,0xba(%rax)
  7143eb:	00 00 
  7143ed:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  7143f4:	00 00 
  7143f6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  7143fb:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  714402:	00 00 
  714404:	4c 89 f8             	mov    %r15,%rax
  714407:	4c 01 f0             	add    %r14,%rax
  71440a:	48 c7 44 24 20 02 00 	movq   $0x2,0x20(%rsp)
  714411:	00 00 
  714413:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  714418:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
  71441d:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  714422:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  714427:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  71442c:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  714431:	48 8d 54 24 08       	lea    0x8(%rsp),%rdx
  714436:	e8 c5 66 fd ff       	call   6eab00 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBV_6marker5OwnedjNtNtCshBhuxcId5D0_4gpui4list6ListIdNtB1f_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterjB1y_INtNtNtB9_3vec9into_iter8IntoIterTjB1y_EEENtNtB9_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71443b:	0f 10 44 24 10       	movups 0x10(%rsp),%xmm0
  714440:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  714445:	0f 11 03             	movups %xmm0,(%rbx)
  714448:	48 89 43 10          	mov    %rax,0x10(%rbx)
  71444c:	48 89 d8             	mov    %rbx,%rax
  71444f:	48 83 c4 58          	add    $0x58,%rsp
  714453:	5b                   	pop    %rbx
  714454:	41 5c                	pop    %r12
  714456:	41 5d                	pop    %r13
  714458:	41 5e                	pop    %r14
  71445a:	41 5f                	pop    %r15
  71445c:	5d                   	pop    %rbp
  71445d:	c3                   	ret
  71445e:	49 81 fd c8 0d 00 00 	cmp    $0xdc8,%r13
  714465:	73 3a                	jae    7144a1 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x221>
  714467:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  71446c:	ba 01 00 00 00       	mov    $0x1,%edx
  714471:	4c 89 ff             	mov    %r15,%rdi
  714474:	4c 89 e6             	mov    %r12,%rsi
  714477:	e8 54 ee ff ff       	call   7132d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB3S_8adapters3map3MapINtNtB8_4iter4IterNtB1q_9ListDraftENCNvMst_NtB1s_7runtimeINtB5T_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6o_>
  71447c:	e9 3d ff ff ff       	jmp    7143be <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x13e>
  714481:	bf 08 00 00 00       	mov    $0x8,%edi
  714486:	be c0 00 00 00       	mov    $0xc0,%esi
  71448b:	ff 15 5f 64 3d 00    	call   *0x3d645f(%rip)        # aea8f0 <_DYNAMIC+0x278>
  714491:	0f 0b                	ud2
  714493:	bf 08 00 00 00       	mov    $0x8,%edi
  714498:	4c 89 f6             	mov    %r14,%rsi
  71449b:	ff 15 ff 64 3d 00    	call   *0x3d64ff(%rip)        # aea9a0 <_DYNAMIC+0x328>
  7144a1:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
  7144a6:	4c 89 ff             	mov    %r15,%rdi
  7144a9:	4c 89 e6             	mov    %r12,%rsi
  7144ac:	e8 df 50 01 00       	call   729590 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_>
  7144b1:	e9 08 ff ff ff       	jmp    7143be <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x13e>
  7144b6:	eb 00                	jmp    7144b8 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x238>
  7144b8:	48 89 c3             	mov    %rax,%rbx
  7144bb:	ba 08 00 00 00       	mov    $0x8,%edx
  7144c0:	4c 89 ff             	mov    %r15,%rdi
  7144c3:	4c 89 f6             	mov    %r14,%rsi
  7144c6:	ff 15 f4 63 3d 00    	call   *0x3d63f4(%rip)        # aea8c0 <_DYNAMIC+0x248>
  7144cc:	48 89 df             	mov    %rbx,%rdi
  7144cf:	e8 cc 6b 3a 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
