
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000007146a0 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_>:
  7146a0:	41 57                	push   %r15
  7146a2:	41 56                	push   %r14
  7146a4:	41 54                	push   %r12
  7146a6:	53                   	push   %rbx
  7146a7:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  7146ae:	48 89 fb             	mov    %rdi,%rbx
  7146b1:	48 8b 46 40          	mov    0x40(%rsi),%rax
  7146b5:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  7146bc:	00 
  7146bd:	0f 10 06             	movups (%rsi),%xmm0
  7146c0:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  7146c4:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  7146c8:	0f 10 5e 30          	movups 0x30(%rsi),%xmm3
  7146cc:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
  7146d1:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  7146d6:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  7146db:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  7146e0:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  7146e5:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  7146ea:	e8 a1 67 00 00       	call   71ae90 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_>
  7146ef:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  7146f4:	4d 85 ff             	test   %r15,%r15
  7146f7:	0f 84 af 00 00 00    	je     7147ac <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x10c>
  7146fd:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  714702:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  714707:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  71470c:	49 83 ff 01          	cmp    $0x1,%r15
  714710:	0f 85 d5 00 00 00    	jne    7147eb <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x14b>
  714716:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  71471b:	ff 15 b7 61 3d 00    	call   *0x3d61b7(%rip)        # aea8d8 <_DYNAMIC+0x260>
  714721:	bf c0 00 00 00       	mov    $0xc0,%edi
  714726:	be 08 00 00 00       	mov    $0x8,%esi
  71472b:	ff 15 87 61 3d 00    	call   *0x3d6187(%rip)        # aea8b8 <_DYNAMIC+0x240>
  714731:	48 85 c0             	test   %rax,%rax
  714734:	0f 84 d1 00 00 00    	je     71480b <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x16b>
  71473a:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  714741:	66 c7 80 ba 00 00 00 	movw   $0x0,0xba(%rax)
  714748:	00 00 
  71474a:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  714751:	00 00 
  714753:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  714758:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  71475f:	00 00 
  714761:	49 c1 e7 04          	shl    $0x4,%r15
  714765:	4d 01 f7             	add    %r14,%r15
  714768:	48 c7 44 24 40 02 00 	movq   $0x2,0x40(%rsp)
  71476f:	00 00 
  714771:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
  714776:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  71477b:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
  714780:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  714785:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  71478a:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  71478f:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  714794:	e8 67 63 fd ff       	call   6eab00 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBV_6marker5OwnedjNtNtCshBhuxcId5D0_4gpui4list6ListIdNtB1f_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterjB1y_INtNtNtB9_3vec9into_iter8IntoIterTjB1y_EEENtNtB9_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  714799:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
  71479e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  7147a3:	0f 11 03             	movups %xmm0,(%rbx)
  7147a6:	48 89 43 10          	mov    %rax,0x10(%rbx)
  7147aa:	eb 2d                	jmp    7147d9 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x139>
  7147ac:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  7147b3:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  7147ba:	00 
  7147bb:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  7147c0:	48 85 f6             	test   %rsi,%rsi
  7147c3:	74 14                	je     7147d9 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x139>
  7147c5:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  7147ca:	48 c1 e6 04          	shl    $0x4,%rsi
  7147ce:	ba 08 00 00 00       	mov    $0x8,%edx
  7147d3:	ff 15 e7 60 3d 00    	call   *0x3d60e7(%rip)        # aea8c0 <_DYNAMIC+0x248>
  7147d9:	48 89 d8             	mov    %rbx,%rax
  7147dc:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  7147e3:	5b                   	pop    %rbx
  7147e4:	41 5c                	pop    %r12
  7147e6:	41 5e                	pop    %r14
  7147e8:	41 5f                	pop    %r15
  7147ea:	c3                   	ret
  7147eb:	49 83 ff 15          	cmp    $0x15,%r15
  7147ef:	73 2c                	jae    71481d <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x17d>
  7147f1:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
  7147f6:	ba 01 00 00 00       	mov    $0x1,%edx
  7147fb:	4c 89 f7             	mov    %r14,%rdi
  7147fe:	4c 89 fe             	mov    %r15,%rsi
  714801:	e8 ca ea ff ff       	call   7132d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB3S_8adapters3map3MapINtNtB8_4iter4IterNtB1q_9ListDraftENCNvMst_NtB1s_7runtimeINtB5T_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6o_>
  714806:	e9 0b ff ff ff       	jmp    714716 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x76>
  71480b:	bf 08 00 00 00       	mov    $0x8,%edi
  714810:	be c0 00 00 00       	mov    $0xc0,%esi
  714815:	ff 15 d5 60 3d 00    	call   *0x3d60d5(%rip)        # aea8f0 <_DYNAMIC+0x278>
  71481b:	0f 0b                	ud2
  71481d:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
  714822:	4c 89 f7             	mov    %r14,%rdi
  714825:	4c 89 fe             	mov    %r15,%rsi
  714828:	e8 d3 4f 01 00       	call   729800 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_>
  71482d:	e9 e4 fe ff ff       	jmp    714716 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x76>
  714832:	48 89 c3             	mov    %rax,%rbx
  714835:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  71483a:	eb 03                	jmp    71483f <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x19f>
  71483c:	48 89 c3             	mov    %rax,%rbx
  71483f:	4d 85 e4             	test   %r12,%r12
  714842:	74 15                	je     714859 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x1b9>
  714844:	49 c1 e4 04          	shl    $0x4,%r12
  714848:	ba 08 00 00 00       	mov    $0x8,%edx
  71484d:	4c 89 f7             	mov    %r14,%rdi
  714850:	4c 89 e6             	mov    %r12,%rsi
  714853:	ff 15 67 60 3d 00    	call   *0x3d6067(%rip)        # aea8c0 <_DYNAMIC+0x248>
  714859:	48 89 df             	mov    %rbx,%rdi
  71485c:	e8 3f 68 3a 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
