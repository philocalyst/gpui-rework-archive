
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072e720 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>:
  72e720:	55                   	push   %rbp
  72e721:	41 57                	push   %r15
  72e723:	41 56                	push   %r14
  72e725:	41 55                	push   %r13
  72e727:	41 54                	push   %r12
  72e729:	53                   	push   %rbx
  72e72a:	50                   	push   %rax
  72e72b:	49 89 d6             	mov    %rdx,%r14
  72e72e:	48 89 f3             	mov    %rsi,%rbx
  72e731:	48 83 f9 08          	cmp    $0x8,%rcx
  72e735:	72 5c                	jb     72e793 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_+0x73>
  72e737:	48 c1 e9 03          	shr    $0x3,%rcx
  72e73b:	48 89 c8             	mov    %rcx,%rax
  72e73e:	48 c1 e0 05          	shl    $0x5,%rax
  72e742:	4c 8d 3c 40          	lea    (%rax,%rax,2),%r15
  72e746:	4a 8d 34 3f          	lea    (%rdi,%r15,1),%rsi
  72e74a:	4c 69 e1 a8 00 00 00 	imul   $0xa8,%rcx,%r12
  72e751:	4a 8d 14 27          	lea    (%rdi,%r12,1),%rdx
  72e755:	49 89 cd             	mov    %rcx,%r13
  72e758:	e8 c3 ff ff ff       	call   72e720 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  72e75d:	48 89 c5             	mov    %rax,%rbp
  72e760:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
  72e764:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
  72e768:	48 89 df             	mov    %rbx,%rdi
  72e76b:	4c 89 e9             	mov    %r13,%rcx
  72e76e:	e8 ad ff ff ff       	call   72e720 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  72e773:	48 89 c3             	mov    %rax,%rbx
  72e776:	4d 01 f7             	add    %r14,%r15
  72e779:	4d 01 f4             	add    %r14,%r12
  72e77c:	4c 89 f7             	mov    %r14,%rdi
  72e77f:	4c 89 fe             	mov    %r15,%rsi
  72e782:	4c 89 e2             	mov    %r12,%rdx
  72e785:	4c 89 e9             	mov    %r13,%rcx
  72e788:	e8 93 ff ff ff       	call   72e720 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  72e78d:	48 89 ef             	mov    %rbp,%rdi
  72e790:	49 89 c6             	mov    %rax,%r14
  72e793:	48 8b 07             	mov    (%rdi),%rax
  72e796:	48 8b 0b             	mov    (%rbx),%rcx
  72e799:	48 39 c8             	cmp    %rcx,%rax
  72e79c:	0f 92 c2             	setb   %dl
  72e79f:	49 8b 36             	mov    (%r14),%rsi
  72e7a2:	48 39 f0             	cmp    %rsi,%rax
  72e7a5:	0f 92 c0             	setb   %al
  72e7a8:	30 d0                	xor    %dl,%al
  72e7aa:	48 39 f1             	cmp    %rsi,%rcx
  72e7ad:	0f 92 c1             	setb   %cl
  72e7b0:	30 d1                	xor    %dl,%cl
  72e7b2:	49 0f 45 de          	cmovne %r14,%rbx
  72e7b6:	84 c0                	test   %al,%al
  72e7b8:	48 0f 45 df          	cmovne %rdi,%rbx
  72e7bc:	48 89 d8             	mov    %rbx,%rax
  72e7bf:	48 83 c4 08          	add    $0x8,%rsp
  72e7c3:	5b                   	pop    %rbx
  72e7c4:	41 5c                	pop    %r12
  72e7c6:	41 5d                	pop    %r13
  72e7c8:	41 5e                	pop    %r14
  72e7ca:	41 5f                	pop    %r15
  72e7cc:	5d                   	pop    %rbp
  72e7cd:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
