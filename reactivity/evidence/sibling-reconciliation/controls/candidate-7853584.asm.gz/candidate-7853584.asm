
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000077d610 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new>:
  77d610:	55                   	push   %rbp
  77d611:	41 57                	push   %r15
  77d613:	41 56                	push   %r14
  77d615:	41 55                	push   %r13
  77d617:	41 54                	push   %r12
  77d619:	53                   	push   %rbx
  77d61a:	50                   	push   %rax
  77d61b:	49 89 ff             	mov    %rdi,%r15
  77d61e:	48 85 d2             	test   %rdx,%rdx
  77d621:	0f 84 64 01 00 00    	je     77d78b <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x17b>
  77d627:	49 89 d6             	mov    %rdx,%r14
  77d62a:	49 89 f4             	mov    %rsi,%r12
  77d62d:	48 8d 04 12          	lea    (%rdx,%rdx,1),%rax
  77d631:	48 8d 1c 85 08 00 00 	lea    0x8(,%rax,4),%rbx
  77d638:	00 
  77d639:	ff 15 a1 a6 36 00    	call   *0x36a6a1(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  77d63f:	be 04 00 00 00       	mov    $0x4,%esi
  77d644:	48 89 df             	mov    %rbx,%rdi
  77d647:	ff 15 8b a6 36 00    	call   *0x36a68b(%rip)        # ae7cd8 <_DYNAMIC+0x258>
  77d64d:	48 85 c0             	test   %rax,%rax
  77d650:	0f 84 7e 01 00 00    	je     77d7d4 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1c4>
  77d656:	4a 8d 0c 75 02 00 00 	lea    0x2(,%r14,2),%rcx
  77d65d:	00 
  77d65e:	49 8d 76 02          	lea    0x2(%r14),%rsi
  77d662:	4e 8d 04 b0          	lea    (%rax,%r14,4),%r8
  77d666:	49 83 c0 08          	add    $0x8,%r8
  77d66a:	4a 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%rdx
  77d671:	00 
  77d672:	4c 8d 0c 92          	lea    (%rdx,%rdx,4),%r9
  77d676:	45 31 d2             	xor    %r10d,%r10d
  77d679:	41 bb ff ff ff ff    	mov    $0xffffffff,%r11d
  77d67f:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  77d685:	48 8d 15 84 37 34 00 	lea    0x343784(%rip),%rdx        # ac0e10 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0xe8>
  77d68c:	0f 1f 40 00          	nopl   0x0(%rax)
  77d690:	43 8b 6c 14 18       	mov    0x18(%r12,%r10,1),%ebp
  77d695:	48 8d 7d 02          	lea    0x2(%rbp),%rdi
  77d699:	4c 39 dd             	cmp    %r11,%rbp
  77d69c:	48 89 fd             	mov    %rdi,%rbp
  77d69f:	49 0f 44 ed          	cmove  %r13,%rbp
  77d6a3:	48 39 f5             	cmp    %rsi,%rbp
  77d6a6:	0f 83 03 01 00 00    	jae    77d7af <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x19f>
  77d6ac:	ff 04 a8             	incl   (%rax,%rbp,4)
  77d6af:	49 83 c2 28          	add    $0x28,%r10
  77d6b3:	4d 39 d1             	cmp    %r10,%r9
  77d6b6:	75 d8                	jne    77d690 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x80>
  77d6b8:	8b 10                	mov    (%rax),%edx
  77d6ba:	4d 8d 5e 01          	lea    0x1(%r14),%r11
  77d6be:	44 89 df             	mov    %r11d,%edi
  77d6c1:	83 e7 03             	and    $0x3,%edi
  77d6c4:	41 ba 01 00 00 00    	mov    $0x1,%r10d
  77d6ca:	49 83 fe 03          	cmp    $0x3,%r14
  77d6ce:	72 49                	jb     77d719 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x109>
  77d6d0:	49 ba fc ff ff ff ff 	movabs $0x7fffffffffffffc,%r10
  77d6d7:	ff ff 07 
  77d6da:	4d 21 d3             	and    %r10,%r11
  77d6dd:	45 31 d2             	xor    %r10d,%r10d
  77d6e0:	42 03 54 90 04       	add    0x4(%rax,%r10,4),%edx
  77d6e5:	42 89 54 90 04       	mov    %edx,0x4(%rax,%r10,4)
  77d6ea:	42 03 54 90 08       	add    0x8(%rax,%r10,4),%edx
  77d6ef:	42 89 54 90 08       	mov    %edx,0x8(%rax,%r10,4)
  77d6f4:	42 03 54 90 0c       	add    0xc(%rax,%r10,4),%edx
  77d6f9:	42 89 54 90 0c       	mov    %edx,0xc(%rax,%r10,4)
  77d6fe:	42 03 54 90 10       	add    0x10(%rax,%r10,4),%edx
  77d703:	42 89 54 90 10       	mov    %edx,0x10(%rax,%r10,4)
  77d708:	49 83 c2 04          	add    $0x4,%r10
  77d70c:	4d 39 d3             	cmp    %r10,%r11
  77d70f:	75 cf                	jne    77d6e0 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0xd0>
  77d711:	48 85 ff             	test   %rdi,%rdi
  77d714:	74 1a                	je     77d730 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x120>
  77d716:	49 ff c2             	inc    %r10
  77d719:	4e 8d 14 90          	lea    (%rax,%r10,4),%r10
  77d71d:	45 31 db             	xor    %r11d,%r11d
  77d720:	43 03 14 9a          	add    (%r10,%r11,4),%edx
  77d724:	43 89 14 9a          	mov    %edx,(%r10,%r11,4)
  77d728:	49 ff c3             	inc    %r11
  77d72b:	4c 39 df             	cmp    %r11,%rdi
  77d72e:	75 f0                	jne    77d720 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x110>
  77d730:	45 31 db             	xor    %r11d,%r11d
  77d733:	41 bd ff ff ff ff    	mov    $0xffffffff,%r13d
  77d739:	48 8d 15 00 37 34 00 	lea    0x343700(%rip),%rdx        # ac0e40 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0x118>
  77d740:	31 ed                	xor    %ebp,%ebp
  77d742:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77d749:	1f 84 00 00 00 00 00 
  77d750:	45 8b 54 2c 18       	mov    0x18(%r12,%rbp,1),%r10d
  77d755:	49 8d 7a 01          	lea    0x1(%r10),%rdi
  77d759:	4d 39 ea             	cmp    %r13,%r10
  77d75c:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  77d762:	4c 0f 45 d7          	cmovne %rdi,%r10
  77d766:	49 39 f2             	cmp    %rsi,%r10
  77d769:	73 51                	jae    77d7bc <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1ac>
  77d76b:	41 8b 7c 2c 1c       	mov    0x1c(%r12,%rbp,1),%edi
  77d770:	42 03 3c 90          	add    (%rax,%r10,4),%edi
  77d774:	49 39 fe             	cmp    %rdi,%r14
  77d777:	76 3e                	jbe    77d7b7 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1a7>
  77d779:	45 89 1c b8          	mov    %r11d,(%r8,%rdi,4)
  77d77d:	48 83 c5 28          	add    $0x28,%rbp
  77d781:	41 ff c3             	inc    %r11d
  77d784:	49 39 e9             	cmp    %rbp,%r9
  77d787:	75 c7                	jne    77d750 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x140>
  77d789:	eb 07                	jmp    77d792 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x182>
  77d78b:	b8 04 00 00 00       	mov    $0x4,%eax
  77d790:	31 c9                	xor    %ecx,%ecx
  77d792:	49 89 0f             	mov    %rcx,(%r15)
  77d795:	49 89 47 08          	mov    %rax,0x8(%r15)
  77d799:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  77d79d:	4c 89 f8             	mov    %r15,%rax
  77d7a0:	48 83 c4 08          	add    $0x8,%rsp
  77d7a4:	5b                   	pop    %rbx
  77d7a5:	41 5c                	pop    %r12
  77d7a7:	41 5d                	pop    %r13
  77d7a9:	41 5e                	pop    %r14
  77d7ab:	41 5f                	pop    %r15
  77d7ad:	5d                   	pop    %rbp
  77d7ae:	c3                   	ret
  77d7af:	49 89 c7             	mov    %rax,%r15
  77d7b2:	49 89 f6             	mov    %rsi,%r14
  77d7b5:	eb 12                	jmp    77d7c9 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1b9>
  77d7b7:	49 89 c7             	mov    %rax,%r15
  77d7ba:	eb 0d                	jmp    77d7c9 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1b9>
  77d7bc:	49 89 c7             	mov    %rax,%r15
  77d7bf:	49 89 f6             	mov    %rsi,%r14
  77d7c2:	48 8d 15 5f 36 34 00 	lea    0x34365f(%rip),%rdx        # ac0e28 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0x100>
  77d7c9:	4c 89 f6             	mov    %r14,%rsi
  77d7cc:	ff 15 06 a6 36 00    	call   *0x36a606(%rip)        # ae7dd8 <_DYNAMIC+0x358>
  77d7d2:	0f 0b                	ud2
  77d7d4:	bf 04 00 00 00       	mov    $0x4,%edi
  77d7d9:	48 89 de             	mov    %rbx,%rsi
  77d7dc:	ff 15 c6 a5 36 00    	call   *0x36a5c6(%rip)        # ae7da8 <_DYNAMIC+0x328>
  77d7e2:	49 89 c6             	mov    %rax,%r14
  77d7e5:	ba 04 00 00 00       	mov    $0x4,%edx
  77d7ea:	4c 89 ff             	mov    %r15,%rdi
  77d7ed:	48 89 de             	mov    %rbx,%rsi
  77d7f0:	ff 15 d2 a4 36 00    	call   *0x36a4d2(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  77d7f6:	4c 89 f7             	mov    %r14,%rdi
  77d7f9:	e8 52 ac 33 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
