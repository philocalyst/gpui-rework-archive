
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000007322e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>:
  7322e0:	55                   	push   %rbp
  7322e1:	41 57                	push   %r15
  7322e3:	41 56                	push   %r14
  7322e5:	41 55                	push   %r13
  7322e7:	41 54                	push   %r12
  7322e9:	53                   	push   %rbx
  7322ea:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
  7322f1:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  7322f6:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  7322fb:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  732300:	48 83 fe 02          	cmp    $0x2,%rsi
  732304:	0f 82 44 06 00 00    	jb     73294e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x66e>
  73230a:	49 89 cd             	mov    %rcx,%r13
  73230d:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  732314:	00 00 40 
  732317:	48 89 d1             	mov    %rdx,%rcx
  73231a:	31 d2                	xor    %edx,%edx
  73231c:	48 f7 f6             	div    %rsi
  73231f:	48 83 fa 01          	cmp    $0x1,%rdx
  732323:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  732327:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  73232c:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  732333:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  732338:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  73233d:	73 1e                	jae    73235d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x7d>
  73233f:	48 89 ca             	mov    %rcx,%rdx
  732342:	48 89 f0             	mov    %rsi,%rax
  732345:	48 d1 e8             	shr    $1,%rax
  732348:	48 89 f1             	mov    %rsi,%rcx
  73234b:	48 29 c1             	sub    %rax,%rcx
  73234e:	48 83 f9 40          	cmp    $0x40,%rcx
  732352:	b8 40 00 00 00       	mov    $0x40,%eax
  732357:	48 0f 42 c1          	cmovb  %rcx,%rax
  73235b:	eb 0e                	jmp    73236b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x8b>
  73235d:	48 89 f7             	mov    %rsi,%rdi
  732360:	ff 15 3a 8b 3b 00    	call   *0x3b8b3a(%rip)        # aeaea0 <_DYNAMIC+0x828>
  732366:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  73236b:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  732370:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  732375:	48 8d 48 20          	lea    0x20(%rax),%rcx
  732379:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  73237e:	48 8d 48 10          	lea    0x10(%rax),%rcx
  732382:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  732387:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  73238b:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  732390:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  732396:	31 ed                	xor    %ebp,%ebp
  732398:	45 31 c9             	xor    %r9d,%r9d
  73239b:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  7323a2:	00 
  7323a3:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  7323a8:	48 29 ee             	sub    %rbp,%rsi
  7323ab:	77 23                	ja     7323d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xf0>
  7323ad:	0f 1f 00             	nopl   (%rax)
  7323b0:	31 ff                	xor    %edi,%edi
  7323b2:	be 01 00 00 00       	mov    $0x1,%esi
  7323b7:	49 83 f9 02          	cmp    $0x2,%r9
  7323bb:	0f 83 df 00 00 00    	jae    7324a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1c0>
  7323c1:	e9 80 03 00 00       	jmp    732746 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  7323c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  7323cd:	00 00 00 
  7323d0:	48 89 e9             	mov    %rbp,%rcx
  7323d3:	48 c1 e1 04          	shl    $0x4,%rcx
  7323d7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  7323dc:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
  7323e0:	48 3b 74 24 18       	cmp    0x18(%rsp),%rsi
  7323e5:	73 49                	jae    732430 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x150>
  7323e7:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  7323ec:	74 62                	je     732450 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x170>
  7323ee:	48 83 fe 20          	cmp    $0x20,%rsi
  7323f2:	b8 20 00 00 00       	mov    $0x20,%eax
  7323f7:	48 0f 43 f0          	cmovae %rax,%rsi
  7323fb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  732400:	48 89 04 24          	mov    %rax,(%rsp)
  732404:	4c 89 e9             	mov    %r13,%rcx
  732407:	45 31 c0             	xor    %r8d,%r8d
  73240a:	4c 89 cb             	mov    %r9,%rbx
  73240d:	45 31 c9             	xor    %r9d,%r9d
  732410:	49 89 f6             	mov    %rsi,%r14
  732413:	e8 48 87 ff ff       	call   72ab60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  732418:	49 89 d9             	mov    %rbx,%r9
  73241b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  732420:	44 89 f0             	mov    %r14d,%eax
  732423:	eb 18                	jmp    73243d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  732425:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  73242c:	00 00 00 00 
  732430:	48 83 fe 02          	cmp    $0x2,%rsi
  732434:	0f 83 56 03 00 00    	jae    732790 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x4b0>
  73243a:	48 89 f0             	mov    %rsi,%rax
  73243d:	48 8d 34 45 01 00 00 	lea    0x1(,%rax,2),%rsi
  732444:	00 
  732445:	eb 18                	jmp    73245f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x17f>
  732447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  73244e:	00 00 
  732450:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  732455:	48 39 c6             	cmp    %rax,%rsi
  732458:	48 0f 43 f0          	cmovae %rax,%rsi
  73245c:	48 01 f6             	add    %rsi,%rsi
  73245f:	4c 89 e0             	mov    %r12,%rax
  732462:	48 d1 e8             	shr    $1,%rax
  732465:	48 89 f1             	mov    %rsi,%rcx
  732468:	48 d1 e9             	shr    $1,%rcx
  73246b:	48 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%rdi
  732472:	00 
  732473:	48 29 c7             	sub    %rax,%rdi
  732476:	48 8d 04 69          	lea    (%rcx,%rbp,2),%rax
  73247a:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  73247f:	48 0f af f9          	imul   %rcx,%rdi
  732483:	48 0f af c1          	imul   %rcx,%rax
  732487:	48 31 f8             	xor    %rdi,%rax
  73248a:	bf 7f 00 00 00       	mov    $0x7f,%edi
  73248f:	48 0f bd f8          	bsr    %rax,%rdi
  732493:	83 f7 3f             	xor    $0x3f,%edi
  732496:	49 83 f9 02          	cmp    $0x2,%r9
  73249a:	0f 82 a6 02 00 00    	jb     732746 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  7324a0:	48 89 e9             	mov    %rbp,%rcx
  7324a3:	48 c1 e1 04          	shl    $0x4,%rcx
  7324a7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  7324ac:	48 01 c8             	add    %rcx,%rax
  7324af:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  7324b4:	48 03 4c 24 58       	add    0x58(%rsp),%rcx
  7324b9:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  7324be:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  7324c3:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  7324c8:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  7324cf:	00 
  7324d0:	eb 4b                	jmp    73251d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x23d>
  7324d2:	4c 89 ed             	mov    %r13,%rbp
  7324d5:	4c 89 c6             	mov    %r8,%rsi
  7324d8:	49 29 f4             	sub    %rsi,%r12
  7324db:	48 89 ef             	mov    %rbp,%rdi
  7324de:	4c 89 e2             	mov    %r12,%rdx
  7324e1:	ff 15 01 84 3b 00    	call   *0x3b8401(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  7324e7:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  7324ee:	00 
  7324ef:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  7324f4:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  7324f9:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  7324fe:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  732503:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  73250a:	00 
  73250b:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
  732512:	00 
  732513:	49 83 f9 01          	cmp    $0x1,%r9
  732517:	0f 86 23 02 00 00    	jbe    732740 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x460>
  73251d:	42 38 bc 0c 95 00 00 	cmp    %dil,0x95(%rsp,%r9,1)
  732524:	00 
  732525:	0f 82 1b 02 00 00    	jb     732746 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  73252b:	49 ff c9             	dec    %r9
  73252e:	4a 8b 84 cc d8 00 00 	mov    0xd8(%rsp,%r9,8),%rax
  732535:	00 
  732536:	48 89 c3             	mov    %rax,%rbx
  732539:	48 d1 eb             	shr    $1,%rbx
  73253c:	4d 89 e7             	mov    %r12,%r15
  73253f:	49 d1 ef             	shr    $1,%r15
  732542:	4e 8d 34 3b          	lea    (%rbx,%r15,1),%r14
  732546:	4d 39 ee             	cmp    %r13,%r14
  732549:	77 25                	ja     732570 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x290>
  73254b:	89 c1                	mov    %eax,%ecx
  73254d:	44 09 e1             	or     %r12d,%ecx
  732550:	83 e1 01             	and    $0x1,%ecx
  732553:	75 1b                	jne    732570 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x290>
  732555:	4d 01 f6             	add    %r14,%r14
  732558:	4d 89 f4             	mov    %r14,%r12
  73255b:	49 83 f9 01          	cmp    $0x1,%r9
  73255f:	77 bc                	ja     73251d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x23d>
  732561:	e9 da 01 00 00       	jmp    732740 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x460>
  732566:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  73256d:	00 00 00 
  732570:	4c 29 f5             	sub    %r14,%rbp
  732573:	48 c1 e5 04          	shl    $0x4,%rbp
  732577:	48 03 6c 24 10       	add    0x10(%rsp),%rbp
  73257c:	a8 01                	test   $0x1,%al
  73257e:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  732583:	75 5b                	jne    7325e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x300>
  732585:	48 89 d8             	mov    %rbx,%rax
  732588:	48 83 c8 01          	or     $0x1,%rax
  73258c:	4c 0f bd c0          	bsr    %rax,%r8
  732590:	41 83 f0 3f          	xor    $0x3f,%r8d
  732594:	45 01 c0             	add    %r8d,%r8d
  732597:	41 83 f0 7e          	xor    $0x7e,%r8d
  73259b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  7325a0:	48 89 04 24          	mov    %rax,(%rsp)
  7325a4:	48 89 ef             	mov    %rbp,%rdi
  7325a7:	48 89 de             	mov    %rbx,%rsi
  7325aa:	4c 89 e9             	mov    %r13,%rcx
  7325ad:	45 31 c9             	xor    %r9d,%r9d
  7325b0:	e8 ab 85 ff ff       	call   72ab60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  7325b5:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  7325ba:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  7325bf:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  7325c4:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  7325c9:	41 f6 c4 01          	test   $0x1,%r12b
  7325cd:	74 17                	je     7325e6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x306>
  7325cf:	4d 85 ff             	test   %r15,%r15
  7325d2:	75 66                	jne    73263a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x35a>
  7325d4:	e9 2a ff ff ff       	jmp    732503 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  7325d9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  7325e0:	41 f6 c4 01          	test   $0x1,%r12b
  7325e4:	75 e9                	jne    7325cf <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x2ef>
  7325e6:	48 89 df             	mov    %rbx,%rdi
  7325e9:	48 c1 e7 04          	shl    $0x4,%rdi
  7325ed:	48 01 ef             	add    %rbp,%rdi
  7325f0:	4c 89 f8             	mov    %r15,%rax
  7325f3:	48 83 c8 01          	or     $0x1,%rax
  7325f7:	4c 0f bd c0          	bsr    %rax,%r8
  7325fb:	41 83 f0 3f          	xor    $0x3f,%r8d
  7325ff:	45 01 c0             	add    %r8d,%r8d
  732602:	41 83 f0 7e          	xor    $0x7e,%r8d
  732606:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  73260b:	48 89 04 24          	mov    %rax,(%rsp)
  73260f:	4c 89 fe             	mov    %r15,%rsi
  732612:	4c 89 e9             	mov    %r13,%rcx
  732615:	45 31 c9             	xor    %r9d,%r9d
  732618:	e8 43 85 ff ff       	call   72ab60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  73261d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  732622:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  732627:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  73262c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  732631:	4d 85 ff             	test   %r15,%r15
  732634:	0f 84 c9 fe ff ff    	je     732503 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  73263a:	48 85 db             	test   %rbx,%rbx
  73263d:	0f 84 c0 fe ff ff    	je     732503 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  732643:	49 39 df             	cmp    %rbx,%r15
  732646:	49 89 dc             	mov    %rbx,%r12
  732649:	4d 0f 42 e7          	cmovb  %r15,%r12
  73264d:	4d 39 e5             	cmp    %r12,%r13
  732650:	0f 82 ad fe ff ff    	jb     732503 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  732656:	49 89 dd             	mov    %rbx,%r13
  732659:	49 c1 e5 04          	shl    $0x4,%r13
  73265d:	49 01 ed             	add    %rbp,%r13
  732660:	4c 39 fb             	cmp    %r15,%rbx
  732663:	48 89 ee             	mov    %rbp,%rsi
  732666:	49 0f 47 f5          	cmova  %r13,%rsi
  73266a:	49 c1 e4 04          	shl    $0x4,%r12
  73266e:	48 89 d7             	mov    %rdx,%rdi
  732671:	4c 89 e2             	mov    %r12,%rdx
  732674:	ff 15 6e 82 3b 00    	call   *0x3b826e(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  73267a:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  73267f:	4d 01 c4             	add    %r8,%r12
  732682:	4c 39 fb             	cmp    %r15,%rbx
  732685:	76 5c                	jbe    7326e3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x403>
  732687:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  73268c:	0f 1f 40 00          	nopl   0x0(%rax)
  732690:	49 8d 4d f0          	lea    -0x10(%r13),%rcx
  732694:	49 8b 54 24 f0       	mov    -0x10(%r12),%rdx
  732699:	31 f6                	xor    %esi,%esi
  73269b:	31 ff                	xor    %edi,%edi
  73269d:	49 3b 55 f0          	cmp    -0x10(%r13),%rdx
  7326a1:	49 8d 54 24 f0       	lea    -0x10(%r12),%rdx
  7326a6:	40 0f 92 c6          	setb   %sil
  7326aa:	48 0f 42 d1          	cmovb  %rcx,%rdx
  7326ae:	40 0f 93 c7          	setae  %dil
  7326b2:	0f 10 02             	movups (%rdx),%xmm0
  7326b5:	0f 11 00             	movups %xmm0,(%rax)
  7326b8:	c1 e7 04             	shl    $0x4,%edi
  7326bb:	49 01 fd             	add    %rdi,%r13
  7326be:	49 83 c5 f0          	add    $0xfffffffffffffff0,%r13
  7326c2:	c1 e6 04             	shl    $0x4,%esi
  7326c5:	49 01 f4             	add    %rsi,%r12
  7326c8:	49 83 c4 f0          	add    $0xfffffffffffffff0,%r12
  7326cc:	49 39 ed             	cmp    %rbp,%r13
  7326cf:	0f 84 fd fd ff ff    	je     7324d2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f2>
  7326d5:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  7326d9:	4d 39 c4             	cmp    %r8,%r12
  7326dc:	75 b2                	jne    732690 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x3b0>
  7326de:	e9 ef fd ff ff       	jmp    7324d2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f2>
  7326e3:	4c 89 c6             	mov    %r8,%rsi
  7326e6:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  7326eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  7326f0:	48 89 f2             	mov    %rsi,%rdx
  7326f3:	49 8b 4d 00          	mov    0x0(%r13),%rcx
  7326f7:	31 c0                	xor    %eax,%eax
  7326f9:	31 f6                	xor    %esi,%esi
  7326fb:	48 3b 0a             	cmp    (%rdx),%rcx
  7326fe:	0f 92 c1             	setb   %cl
  732701:	40 0f 93 c6          	setae  %sil
  732705:	48 89 d7             	mov    %rdx,%rdi
  732708:	49 0f 42 fd          	cmovb  %r13,%rdi
  73270c:	0f 10 07             	movups (%rdi),%xmm0
  73270f:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
  732713:	c1 e6 04             	shl    $0x4,%esi
  732716:	48 01 d6             	add    %rdx,%rsi
  732719:	48 83 c5 10          	add    $0x10,%rbp
  73271d:	4c 39 e6             	cmp    %r12,%rsi
  732720:	0f 84 b2 fd ff ff    	je     7324d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f8>
  732726:	88 c8                	mov    %cl,%al
  732728:	c1 e0 04             	shl    $0x4,%eax
  73272b:	49 01 c5             	add    %rax,%r13
  73272e:	4d 39 c5             	cmp    %r8,%r13
  732731:	75 bd                	jne    7326f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x410>
  732733:	e9 a0 fd ff ff       	jmp    7324d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f8>
  732738:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  73273f:	00 
  732740:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  732746:	4e 89 a4 cc d8 00 00 	mov    %r12,0xd8(%rsp,%r9,8)
  73274d:	00 
  73274e:	42 88 bc 0c 96 00 00 	mov    %dil,0x96(%rsp,%r9,1)
  732755:	00 
  732756:	48 39 6c 24 28       	cmp    %rbp,0x28(%rsp)
  73275b:	0f 86 b3 01 00 00    	jbe    732914 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x634>
  732761:	49 ff c1             	inc    %r9
  732764:	48 89 f0             	mov    %rsi,%rax
  732767:	48 d1 e8             	shr    $1,%rax
  73276a:	48 01 c5             	add    %rax,%rbp
  73276d:	49 89 f4             	mov    %rsi,%r12
  732770:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  732775:	48 29 ee             	sub    %rbp,%rsi
  732778:	0f 87 52 fc ff ff    	ja     7323d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xf0>
  73277e:	e9 2d fc ff ff       	jmp    7323b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xd0>
  732783:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  73278a:	84 00 00 00 00 00 
  732790:	4c 8b 1f             	mov    (%rdi),%r11
  732793:	4c 8b 77 10          	mov    0x10(%rdi),%r14
  732797:	4d 39 de             	cmp    %r11,%r14
  73279a:	49 89 f7             	mov    %rsi,%r15
  73279d:	73 15                	jae    7327b4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x4d4>
  73279f:	48 83 fe 02          	cmp    $0x2,%rsi
  7327a3:	75 54                	jne    7327f9 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x519>
  7327a5:	b8 02 00 00 00       	mov    $0x2,%eax
  7327aa:	be 01 00 00 00       	mov    $0x1,%esi
  7327af:	e9 af 00 00 00       	jmp    732863 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x583>
  7327b4:	b8 02 00 00 00       	mov    $0x2,%eax
  7327b9:	48 83 fe 02          	cmp    $0x2,%rsi
  7327bd:	0f 84 7a fc ff ff    	je     73243d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  7327c3:	4c 89 cb             	mov    %r9,%rbx
  7327c6:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  7327cb:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  7327cf:	b8 02 00 00 00       	mov    $0x2,%eax
  7327d4:	4d 89 f1             	mov    %r14,%r9
  7327d7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  7327de:	00 00 
  7327e0:	4d 89 ca             	mov    %r9,%r10
  7327e3:	4d 8b 08             	mov    (%r8),%r9
  7327e6:	4d 39 d1             	cmp    %r10,%r9
  7327e9:	72 52                	jb     73283d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x55d>
  7327eb:	48 ff c0             	inc    %rax
  7327ee:	49 83 c0 10          	add    $0x10,%r8
  7327f2:	49 39 c7             	cmp    %rax,%r15
  7327f5:	75 e9                	jne    7327e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x500>
  7327f7:	eb 2e                	jmp    732827 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x547>
  7327f9:	4c 89 cb             	mov    %r9,%rbx
  7327fc:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  732801:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  732805:	b8 02 00 00 00       	mov    $0x2,%eax
  73280a:	4d 89 f1             	mov    %r14,%r9
  73280d:	0f 1f 00             	nopl   (%rax)
  732810:	4d 89 ca             	mov    %r9,%r10
  732813:	4d 8b 08             	mov    (%r8),%r9
  732816:	4d 39 d1             	cmp    %r10,%r9
  732819:	73 22                	jae    73283d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x55d>
  73281b:	48 ff c0             	inc    %rax
  73281e:	49 83 c0 10          	add    $0x10,%r8
  732822:	49 39 c7             	cmp    %rax,%r15
  732825:	75 e9                	jne    732810 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x530>
  732827:	4c 89 fe             	mov    %r15,%rsi
  73282a:	4c 89 f8             	mov    %r15,%rax
  73282d:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  732832:	49 89 d9             	mov    %rbx,%r9
  732835:	0f 82 ac fb ff ff    	jb     7323e7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x107>
  73283b:	eb 11                	jmp    73284e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x56e>
  73283d:	4c 89 fe             	mov    %r15,%rsi
  732840:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  732845:	49 89 d9             	mov    %rbx,%r9
  732848:	0f 82 99 fb ff ff    	jb     7323e7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x107>
  73284e:	4d 39 de             	cmp    %r11,%r14
  732851:	0f 83 e6 fb ff ff    	jae    73243d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  732857:	48 89 c6             	mov    %rax,%rsi
  73285a:	48 d1 ee             	shr    $1,%rsi
  73285d:	0f 84 da fb ff ff    	je     73243d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  732863:	49 89 c0             	mov    %rax,%r8
  732866:	49 c1 e0 04          	shl    $0x4,%r8
  73286a:	4a 8d 1c 07          	lea    (%rdi,%r8,1),%rbx
  73286e:	48 83 fe 01          	cmp    $0x1,%rsi
  732872:	75 04                	jne    732878 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x598>
  732874:	31 c9                	xor    %ecx,%ecx
  732876:	eb 79                	jmp    7328f1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x611>
  732878:	4d 89 ce             	mov    %r9,%r14
  73287b:	49 89 f1             	mov    %rsi,%r9
  73287e:	49 83 e1 fe          	and    $0xfffffffffffffffe,%r9
  732882:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  732887:	4c 8d 14 0a          	lea    (%rdx,%rcx,1),%r10
  73288b:	49 01 c8             	add    %rcx,%r8
  73288e:	4c 03 44 24 58       	add    0x58(%rsp),%r8
  732893:	31 c9                	xor    %ecx,%ecx
  732895:	48 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%rdx
  73289c:	ff ff 0f 
  73289f:	90                   	nop
  7328a0:	41 0f 10 42 f0       	movups -0x10(%r10),%xmm0
  7328a5:	41 0f 10 08          	movups (%r8),%xmm1
  7328a9:	41 0f 11 4a f0       	movups %xmm1,-0x10(%r10)
  7328ae:	41 0f 11 00          	movups %xmm0,(%r8)
  7328b2:	49 89 cb             	mov    %rcx,%r11
  7328b5:	49 31 d3             	xor    %rdx,%r11
  7328b8:	49 c1 e3 04          	shl    $0x4,%r11
  7328bc:	41 0f 10 02          	movups (%r10),%xmm0
  7328c0:	42 0f 10 0c 1b       	movups (%rbx,%r11,1),%xmm1
  7328c5:	41 0f 11 0a          	movups %xmm1,(%r10)
  7328c9:	42 0f 11 04 1b       	movups %xmm0,(%rbx,%r11,1)
  7328ce:	48 83 c1 02          	add    $0x2,%rcx
  7328d2:	49 83 c2 20          	add    $0x20,%r10
  7328d6:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
  7328da:	49 39 c9             	cmp    %rcx,%r9
  7328dd:	75 c1                	jne    7328a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x5c0>
  7328df:	40 f6 c6 01          	test   $0x1,%sil
  7328e3:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  7328e8:	4d 89 f1             	mov    %r14,%r9
  7328eb:	0f 84 4c fb ff ff    	je     73243d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  7328f1:	48 89 ce             	mov    %rcx,%rsi
  7328f4:	48 f7 d6             	not    %rsi
  7328f7:	48 c1 e1 04          	shl    $0x4,%rcx
  7328fb:	48 c1 e6 04          	shl    $0x4,%rsi
  7328ff:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  732903:	0f 10 0c 33          	movups (%rbx,%rsi,1),%xmm1
  732907:	0f 11 0c 0f          	movups %xmm1,(%rdi,%rcx,1)
  73290b:	0f 11 04 33          	movups %xmm0,(%rbx,%rsi,1)
  73290f:	e9 29 fb ff ff       	jmp    73243d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  732914:	41 f6 c4 01          	test   $0x1,%r12b
  732918:	75 34                	jne    73294e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x66e>
  73291a:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  73291f:	48 89 f0             	mov    %rsi,%rax
  732922:	48 83 c8 01          	or     $0x1,%rax
  732926:	4c 0f bd c0          	bsr    %rax,%r8
  73292a:	41 83 f0 3f          	xor    $0x3f,%r8d
  73292e:	45 01 c0             	add    %r8d,%r8d
  732931:	41 83 f0 7e          	xor    $0x7e,%r8d
  732935:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  73293a:	48 89 04 24          	mov    %rax,(%rsp)
  73293e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  732943:	4c 89 e9             	mov    %r13,%rcx
  732946:	45 31 c9             	xor    %r9d,%r9d
  732949:	e8 12 82 ff ff       	call   72ab60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  73294e:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
  732955:	5b                   	pop    %rbx
  732956:	41 5c                	pop    %r12
  732958:	41 5d                	pop    %r13
  73295a:	41 5e                	pop    %r14
  73295c:	41 5f                	pop    %r15
  73295e:	5d                   	pop    %rbp
  73295f:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
