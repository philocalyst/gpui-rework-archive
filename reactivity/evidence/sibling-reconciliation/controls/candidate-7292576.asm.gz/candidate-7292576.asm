
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006f46a0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_>:
  6f46a0:	55                   	push   %rbp
  6f46a1:	41 57                	push   %r15
  6f46a3:	41 56                	push   %r14
  6f46a5:	41 55                	push   %r13
  6f46a7:	41 54                	push   %r12
  6f46a9:	53                   	push   %rbx
  6f46aa:	48 83 ec 68          	sub    $0x68,%rsp
  6f46ae:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  6f46b3:	48 8b 07             	mov    (%rdi),%rax
  6f46b6:	48 85 c0             	test   %rax,%rax
  6f46b9:	74 45                	je     6f4700 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x60>
  6f46bb:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
  6f46bf:	48 85 c9             	test   %rcx,%rcx
  6f46c2:	0f 84 96 00 00 00    	je     6f475e <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0xbe>
  6f46c8:	48 89 ca             	mov    %rcx,%rdx
  6f46cb:	48 83 e2 07          	and    $0x7,%rdx
  6f46cf:	74 35                	je     6f4706 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x66>
  6f46d1:	31 f6                	xor    %esi,%esi
  6f46d3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f46da:	84 00 00 00 00 00 
  6f46e0:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f46e7:	48 ff c6             	inc    %rsi
  6f46ea:	48 39 f2             	cmp    %rsi,%rdx
  6f46ed:	75 f1                	jne    6f46e0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x40>
  6f46ef:	48 89 ca             	mov    %rcx,%rdx
  6f46f2:	48 29 f2             	sub    %rsi,%rdx
  6f46f5:	48 89 fe             	mov    %rdi,%rsi
  6f46f8:	48 83 f9 08          	cmp    $0x8,%rcx
  6f46fc:	73 22                	jae    6f4720 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x80>
  6f46fe:	eb 61                	jmp    6f4761 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0xc1>
  6f4700:	31 c0                	xor    %eax,%eax
  6f4702:	31 f6                	xor    %esi,%esi
  6f4704:	eb 5b                	jmp    6f4761 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0xc1>
  6f4706:	48 89 ca             	mov    %rcx,%rdx
  6f4709:	48 89 fe             	mov    %rdi,%rsi
  6f470c:	48 83 f9 08          	cmp    $0x8,%rcx
  6f4710:	72 4f                	jb     6f4761 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0xc1>
  6f4712:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f4719:	1f 84 00 00 00 00 00 
  6f4720:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4727:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f472e:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4735:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f473c:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4743:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f474a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4751:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4758:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  6f475c:	75 c2                	jne    6f4720 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x80>
  6f475e:	48 89 fe             	mov    %rdi,%rsi
  6f4761:	48 83 c7 10          	add    $0x10,%rdi
  6f4765:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
  6f476a:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  6f476f:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  6f4774:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
  6f4779:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f477e:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f4781:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
  6f4786:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f478b:	48 8d 74 24 38       	lea    0x38(%rsp),%rsi
  6f4790:	e8 eb 43 02 00       	call   718b80 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>
  6f4795:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f479a:	48 83 f8 02          	cmp    $0x2,%rax
  6f479e:	75 0f                	jne    6f47af <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x10f>
  6f47a0:	48 83 c4 68          	add    $0x68,%rsp
  6f47a4:	5b                   	pop    %rbx
  6f47a5:	41 5c                	pop    %r12
  6f47a7:	41 5d                	pop    %r13
  6f47a9:	41 5e                	pop    %r14
  6f47ab:	41 5f                	pop    %r15
  6f47ad:	5d                   	pop    %rbp
  6f47ae:	c3                   	ret
  6f47af:	48 8d 5c 24 10       	lea    0x10(%rsp),%rbx
  6f47b4:	4c 8d 74 24 38       	lea    0x38(%rsp),%r14
  6f47b9:	4c 8b 2d 68 35 3f 00 	mov    0x3f3568(%rip),%r13        # ae7d28 <_DYNAMIC+0x2a8>
  6f47c0:	eb 24                	jmp    6f47e6 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x146>
  6f47c2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f47c9:	1f 84 00 00 00 00 00 
  6f47d0:	48 89 df             	mov    %rbx,%rdi
  6f47d3:	4c 89 f6             	mov    %r14,%rsi
  6f47d6:	e8 a5 43 02 00       	call   718b80 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>
  6f47db:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f47e0:	48 83 f8 02          	cmp    $0x2,%rax
  6f47e4:	74 ba                	je     6f47a0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x100>
  6f47e6:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6f47eb:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  6f47f0:	48 85 c0             	test   %rax,%rax
  6f47f3:	74 2b                	je     6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f47f5:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f47fa:	48 85 ff             	test   %rdi,%rdi
  6f47fd:	74 21                	je     6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f47ff:	f6 07 01             	testb  $0x1,(%rdi)
  6f4802:	75 1c                	jne    6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f4804:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6f4808:	a8 01                	test   $0x1,%al
  6f480a:	75 14                	jne    6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f480c:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6f4810:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6f4815:	74 42                	je     6f4859 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x1b9>
  6f4817:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f481e:	00 00 
  6f4820:	4d 85 ff             	test   %r15,%r15
  6f4823:	74 ab                	je     6f47d0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f4825:	4d 85 e4             	test   %r12,%r12
  6f4828:	74 a6                	je     6f47d0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f482a:	41 f6 04 24 01       	testb  $0x1,(%r12)
  6f482f:	75 9f                	jne    6f47d0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f4831:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f4836:	a8 01                	test   $0x1,%al
  6f4838:	75 96                	jne    6f47d0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f483a:	49 8d 44 24 08       	lea    0x8(%r12),%rax
  6f483f:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6f4844:	75 8a                	jne    6f47d0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f4846:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f484b:	40 b5 01             	mov    $0x1,%bpl
  6f484e:	4c 89 e7             	mov    %r12,%rdi
  6f4851:	41 ff d5             	call   *%r13
  6f4854:	e9 77 ff ff ff       	jmp    6f47d0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f4859:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6f485d:	31 ed                	xor    %ebp,%ebp
  6f485f:	41 ff d5             	call   *%r13
  6f4862:	eb bc                	jmp    6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f4864:	48 89 c3             	mov    %rax,%rbx
  6f4867:	40 84 ed             	test   %bpl,%bpl
  6f486a:	75 0b                	jne    6f4877 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x1d7>
  6f486c:	4c 89 ff             	mov    %r15,%rdi
  6f486f:	4c 89 e6             	mov    %r12,%rsi
  6f4872:	e8 c9 2b 00 00       	call   6f7440 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtB4_6option6OptionNtNtBG_11shared_text10SharedTextEEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4877:	48 89 df             	mov    %rbx,%rdi
  6f487a:	e8 d1 3b 3c 00       	call   ab8450 <_Unwind_Resume@plt>
  6f487f:	ff 15 93 34 3f 00    	call   *0x3f3493(%rip)        # ae7d18 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
