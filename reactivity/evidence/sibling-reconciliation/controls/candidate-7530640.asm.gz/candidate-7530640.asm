
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072e890 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>:
  72e890:	55                   	push   %rbp
  72e891:	41 57                	push   %r15
  72e893:	41 56                	push   %r14
  72e895:	41 55                	push   %r13
  72e897:	41 54                	push   %r12
  72e899:	53                   	push   %rbx
  72e89a:	48 83 ec 58          	sub    $0x58,%rsp
  72e89e:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  72e8a3:	49 89 ce             	mov    %rcx,%r14
  72e8a6:	49 89 d7             	mov    %rdx,%r15
  72e8a9:	49 89 f5             	mov    %rsi,%r13
  72e8ac:	49 89 fc             	mov    %rdi,%r12
  72e8af:	48 83 fe 21          	cmp    $0x21,%rsi
  72e8b3:	73 1e                	jae    72e8d3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x43>
  72e8b5:	4c 89 e7             	mov    %r12,%rdi
  72e8b8:	4c 89 ee             	mov    %r13,%rsi
  72e8bb:	4c 89 fa             	mov    %r15,%rdx
  72e8be:	4c 89 f1             	mov    %r14,%rcx
  72e8c1:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  72e8c8:	00 
  72e8c9:	e8 d2 2b fe ff       	call   7114a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2c_11collections5btree3mapINtB2Y_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB3Y_8adapters3map3MapINtNtB8_4iter4IterNtB1w_9ListDraftENCNvMst_NtB1y_7runtimeINtB5Z_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6u_>
  72e8ce:	e9 a9 05 00 00       	jmp    72ee7c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5ec>
  72e8d3:	44 89 c3             	mov    %r8d,%ebx
  72e8d6:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  72e8db:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72e8e0:	85 db                	test   %ebx,%ebx
  72e8e2:	0f 84 73 05 00 00    	je     72ee5b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5cb>
  72e8e8:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72e8ed:	48 89 f1             	mov    %rsi,%rcx
  72e8f0:	48 c1 e9 03          	shr    $0x3,%rcx
  72e8f4:	48 89 c8             	mov    %rcx,%rax
  72e8f7:	48 c1 e0 06          	shl    $0x6,%rax
  72e8fb:	4c 01 e0             	add    %r12,%rax
  72e8fe:	48 6b d1 70          	imul   $0x70,%rcx,%rdx
  72e902:	4c 01 e2             	add    %r12,%rdx
  72e905:	48 83 fe 40          	cmp    $0x40,%rsi
  72e909:	73 35                	jae    72e940 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xb0>
  72e90b:	49 8b 0c 24          	mov    (%r12),%rcx
  72e90f:	48 8b 30             	mov    (%rax),%rsi
  72e912:	48 39 f1             	cmp    %rsi,%rcx
  72e915:	40 0f 92 c7          	setb   %dil
  72e919:	4c 8b 02             	mov    (%rdx),%r8
  72e91c:	4c 39 c1             	cmp    %r8,%rcx
  72e91f:	0f 92 c1             	setb   %cl
  72e922:	40 30 f9             	xor    %dil,%cl
  72e925:	4c 39 c6             	cmp    %r8,%rsi
  72e928:	40 0f 92 c6          	setb   %sil
  72e92c:	40 30 fe             	xor    %dil,%sil
  72e92f:	48 0f 45 c2          	cmovne %rdx,%rax
  72e933:	84 c9                	test   %cl,%cl
  72e935:	49 0f 45 c4          	cmovne %r12,%rax
  72e939:	eb 10                	jmp    72e94b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xbb>
  72e93b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72e940:	4c 89 e7             	mov    %r12,%rdi
  72e943:	48 89 c6             	mov    %rax,%rsi
  72e946:	e8 25 fd ff ff       	call   72e670 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72e94b:	ff cb                	dec    %ebx
  72e94d:	89 5c 24 2c          	mov    %ebx,0x2c(%rsp)
  72e951:	48 89 c5             	mov    %rax,%rbp
  72e954:	4c 29 e5             	sub    %r12,%rbp
  72e957:	48 89 e9             	mov    %rbp,%rcx
  72e95a:	48 c1 e9 04          	shr    $0x4,%rcx
  72e95e:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  72e963:	0f 10 00             	movups (%rax),%xmm0
  72e966:	48 8b 00             	mov    (%rax),%rax
  72e969:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  72e96e:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  72e974:	74 0e                	je     72e984 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xf4>
  72e976:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  72e97b:	48 39 01             	cmp    %rax,(%rcx)
  72e97e:	0f 83 8c 02 00 00    	jae    72ec10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x380>
  72e984:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  72e989:	49 39 de             	cmp    %rbx,%r14
  72e98c:	0f 82 0e 05 00 00    	jb     72eea0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x610>
  72e992:	49 89 de             	mov    %rbx,%r14
  72e995:	49 c1 e6 04          	shl    $0x4,%r14
  72e999:	4b 8d 0c 37          	lea    (%r15,%r14,1),%rcx
  72e99d:	45 31 ed             	xor    %r13d,%r13d
  72e9a0:	4c 89 e0             	mov    %r12,%rax
  72e9a3:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72e9a8:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  72e9ad:	0f 1f 00             	nopl   (%rax)
  72e9b0:	48 89 d7             	mov    %rdx,%rdi
  72e9b3:	48 83 ef 03          	sub    $0x3,%rdi
  72e9b7:	be 00 00 00 00       	mov    $0x0,%esi
  72e9bc:	48 0f 43 f7          	cmovae %rdi,%rsi
  72e9c0:	48 c1 e6 04          	shl    $0x4,%rsi
  72e9c4:	4c 01 e6             	add    %r12,%rsi
  72e9c7:	48 39 f0             	cmp    %rsi,%rax
  72e9ca:	0f 83 a4 00 00 00    	jae    72ea74 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x1e4>
  72e9d0:	48 8b 38             	mov    (%rax),%rdi
  72e9d3:	4c 8d 41 f0          	lea    -0x10(%rcx),%r8
  72e9d7:	45 31 c9             	xor    %r9d,%r9d
  72e9da:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72e9de:	4d 0f 42 c7          	cmovb  %r15,%r8
  72e9e2:	41 0f 92 c1          	setb   %r9b
  72e9e6:	4c 89 ef             	mov    %r13,%rdi
  72e9e9:	48 c1 e7 04          	shl    $0x4,%rdi
  72e9ed:	4f 8d 14 29          	lea    (%r9,%r13,1),%r10
  72e9f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
  72e9f5:	49 c1 e2 04          	shl    $0x4,%r10
  72e9f9:	4d 3b 1c 2c          	cmp    (%r12,%rbp,1),%r11
  72e9fd:	0f 10 00             	movups (%rax),%xmm0
  72ea00:	4c 8d 59 e0          	lea    -0x20(%rcx),%r11
  72ea04:	4d 0f 42 df          	cmovb  %r15,%r11
  72ea08:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72ea0d:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72ea11:	4d 11 cd             	adc    %r9,%r13
  72ea14:	43 0f 11 04 13       	movups %xmm0,(%r11,%r10,1)
  72ea19:	48 8b 78 20          	mov    0x20(%rax),%rdi
  72ea1d:	4c 8d 41 d0          	lea    -0x30(%rcx),%r8
  72ea21:	45 31 c9             	xor    %r9d,%r9d
  72ea24:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72ea28:	4d 0f 42 c7          	cmovb  %r15,%r8
  72ea2c:	41 0f 92 c1          	setb   %r9b
  72ea30:	4c 89 ef             	mov    %r13,%rdi
  72ea33:	48 c1 e7 04          	shl    $0x4,%rdi
  72ea37:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72ea3b:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72ea40:	4b 8d 3c 29          	lea    (%r9,%r13,1),%rdi
  72ea44:	4c 8b 40 30          	mov    0x30(%rax),%r8
  72ea48:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72ea4c:	48 c1 e7 04          	shl    $0x4,%rdi
  72ea50:	4d 3b 04 2c          	cmp    (%r12,%rbp,1),%r8
  72ea54:	49 89 c8             	mov    %rcx,%r8
  72ea57:	4d 0f 42 c7          	cmovb  %r15,%r8
  72ea5b:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72ea5f:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72ea64:	4d 11 cd             	adc    %r9,%r13
  72ea67:	48 83 c0 40          	add    $0x40,%rax
  72ea6b:	48 39 f0             	cmp    %rsi,%rax
  72ea6e:	0f 82 5c ff ff ff    	jb     72e9d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x140>
  72ea74:	48 89 d6             	mov    %rdx,%rsi
  72ea77:	48 c1 e6 04          	shl    $0x4,%rsi
  72ea7b:	4c 01 e6             	add    %r12,%rsi
  72ea7e:	48 39 f0             	cmp    %rsi,%rax
  72ea81:	73 3b                	jae    72eabe <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x22e>
  72ea83:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72ea8a:	84 00 00 00 00 00 
  72ea90:	48 8b 38             	mov    (%rax),%rdi
  72ea93:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72ea97:	4d 89 e8             	mov    %r13,%r8
  72ea9a:	49 c1 e0 04          	shl    $0x4,%r8
  72ea9e:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72eaa2:	48 89 cf             	mov    %rcx,%rdi
  72eaa5:	49 0f 42 ff          	cmovb  %r15,%rdi
  72eaa9:	0f 10 00             	movups (%rax),%xmm0
  72eaac:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72eab1:	49 83 d5 00          	adc    $0x0,%r13
  72eab5:	48 83 c0 10          	add    $0x10,%rax
  72eab9:	48 39 f0             	cmp    %rsi,%rax
  72eabc:	72 d2                	jb     72ea90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x200>
  72eabe:	48 39 da             	cmp    %rbx,%rdx
  72eac1:	74 2d                	je     72eaf0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x260>
  72eac3:	4c 89 ea             	mov    %r13,%rdx
  72eac6:	48 c1 e2 04          	shl    $0x4,%rdx
  72eaca:	0f 10 00             	movups (%rax),%xmm0
  72eacd:	0f 11 44 11 f0       	movups %xmm0,-0x10(%rcx,%rdx,1)
  72ead2:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72ead6:	48 83 c0 10          	add    $0x10,%rax
  72eada:	48 89 da             	mov    %rbx,%rdx
  72eadd:	e9 ce fe ff ff       	jmp    72e9b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x120>
  72eae2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72eae9:	1f 84 00 00 00 00 00 
  72eaf0:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  72eaf5:	4c 89 eb             	mov    %r13,%rbx
  72eaf8:	48 c1 e3 04          	shl    $0x4,%rbx
  72eafc:	4c 89 e7             	mov    %r12,%rdi
  72eaff:	4c 89 fe             	mov    %r15,%rsi
  72eb02:	48 89 da             	mov    %rbx,%rdx
  72eb05:	ff 15 e5 91 3b 00    	call   *0x3b91e5(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72eb0b:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72eb10:	4c 29 ee             	sub    %r13,%rsi
  72eb13:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72eb1a:	ff ff 0f 
  72eb1d:	4b 8d 3c 37          	lea    (%r15,%r14,1),%rdi
  72eb21:	0f 84 8e 00 00 00    	je     72ebb5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x325>
  72eb27:	49 8d 45 01          	lea    0x1(%r13),%rax
  72eb2b:	48 39 44 24 10       	cmp    %rax,0x10(%rsp)
  72eb30:	75 0e                	jne    72eb40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x2b0>
  72eb32:	31 c0                	xor    %eax,%eax
  72eb34:	eb 65                	jmp    72eb9b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x30b>
  72eb36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72eb3d:	00 00 00 
  72eb40:	48 89 f1             	mov    %rsi,%rcx
  72eb43:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72eb47:	49 8d 44 24 10       	lea    0x10(%r12),%rax
  72eb4c:	48 8d 14 18          	lea    (%rax,%rbx,1),%rdx
  72eb50:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72eb54:	49 01 c6             	add    %rax,%r14
  72eb57:	31 c0                	xor    %eax,%eax
  72eb59:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72eb60:	48 89 c7             	mov    %rax,%rdi
  72eb63:	41 0f 10 06          	movups (%r14),%xmm0
  72eb67:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72eb6b:	48 83 c0 02          	add    $0x2,%rax
  72eb6f:	4c 31 c7             	xor    %r8,%rdi
  72eb72:	48 c1 e7 04          	shl    $0x4,%rdi
  72eb76:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72eb7b:	41 0f 10 04 39       	movups (%r9,%rdi,1),%xmm0
  72eb80:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  72eb85:	0f 11 02             	movups %xmm0,(%rdx)
  72eb88:	48 83 c2 20          	add    $0x20,%rdx
  72eb8c:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
  72eb90:	48 39 c1             	cmp    %rax,%rcx
  72eb93:	75 cb                	jne    72eb60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x2d0>
  72eb95:	40 f6 c6 01          	test   $0x1,%sil
  72eb99:	74 1a                	je     72ebb5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x325>
  72eb9b:	49 8d 0c 1c          	lea    (%r12,%rbx,1),%rcx
  72eb9f:	48 89 c2             	mov    %rax,%rdx
  72eba2:	48 f7 d2             	not    %rdx
  72eba5:	48 c1 e2 04          	shl    $0x4,%rdx
  72eba9:	48 c1 e0 04          	shl    $0x4,%rax
  72ebad:	0f 10 04 17          	movups (%rdi,%rdx,1),%xmm0
  72ebb1:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  72ebb5:	4d 85 ed             	test   %r13,%r13
  72ebb8:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72ebbd:	74 51                	je     72ec10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x380>
  72ebbf:	4c 39 6c 24 10       	cmp    %r13,0x10(%rsp)
  72ebc4:	0f 82 d8 02 00 00    	jb     72eea2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x612>
  72ebca:	4c 01 e3             	add    %r12,%rbx
  72ebcd:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  72ebd4:	00 
  72ebd5:	48 89 04 24          	mov    %rax,(%rsp)
  72ebd9:	48 89 df             	mov    %rbx,%rdi
  72ebdc:	4c 89 fa             	mov    %r15,%rdx
  72ebdf:	4c 89 f1             	mov    %r14,%rcx
  72ebe2:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72ebe6:	41 89 d8             	mov    %ebx,%r8d
  72ebe9:	4c 8d 4c 24 40       	lea    0x40(%rsp),%r9
  72ebee:	e8 9d fc ff ff       	call   72e890 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72ebf3:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72ebf8:	49 83 fd 21          	cmp    $0x21,%r13
  72ebfc:	0f 83 de fc ff ff    	jae    72e8e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x50>
  72ec02:	e9 ae fc ff ff       	jmp    72e8b5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x25>
  72ec07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72ec0e:	00 00 
  72ec10:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72ec15:	49 39 c6             	cmp    %rax,%r14
  72ec18:	0f 82 82 02 00 00    	jb     72eea0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x610>
  72ec1e:	48 c1 e0 04          	shl    $0x4,%rax
  72ec22:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72ec27:	49 8d 0c 07          	lea    (%r15,%rax,1),%rcx
  72ec2b:	31 db                	xor    %ebx,%ebx
  72ec2d:	4c 89 e0             	mov    %r12,%rax
  72ec30:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72ec35:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
  72ec3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  72ec40:	4c 89 d6             	mov    %r10,%rsi
  72ec43:	48 83 ee 03          	sub    $0x3,%rsi
  72ec47:	ba 00 00 00 00       	mov    $0x0,%edx
  72ec4c:	48 0f 43 d6          	cmovae %rsi,%rdx
  72ec50:	48 c1 e2 04          	shl    $0x4,%rdx
  72ec54:	4c 01 e2             	add    %r12,%rdx
  72ec57:	48 39 d0             	cmp    %rdx,%rax
  72ec5a:	0f 83 9d 00 00 00    	jae    72ecfd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x46d>
  72ec60:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72ec64:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
  72ec68:	49 89 d8             	mov    %rbx,%r8
  72ec6b:	49 c1 e0 04          	shl    $0x4,%r8
  72ec6f:	48 3b 30             	cmp    (%rax),%rsi
  72ec72:	49 0f 43 ff          	cmovae %r15,%rdi
  72ec76:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ec7a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72ec7e:	49 89 d9             	mov    %rbx,%r9
  72ec81:	49 c1 e1 04          	shl    $0x4,%r9
  72ec85:	48 3b 70 10          	cmp    0x10(%rax),%rsi
  72ec89:	0f 10 00             	movups (%rax),%xmm0
  72ec8c:	48 8d 71 e0          	lea    -0x20(%rcx),%rsi
  72ec90:	49 0f 43 f7          	cmovae %r15,%rsi
  72ec94:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72ec99:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ec9d:	49 8b 3c 2c          	mov    (%r12,%rbp,1),%rdi
  72eca1:	49 89 d8             	mov    %rbx,%r8
  72eca4:	49 c1 e0 04          	shl    $0x4,%r8
  72eca8:	48 3b 78 20          	cmp    0x20(%rax),%rdi
  72ecac:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72ecb0:	48 8d 79 d0          	lea    -0x30(%rcx),%rdi
  72ecb4:	49 0f 43 ff          	cmovae %r15,%rdi
  72ecb8:	42 0f 11 04 0e       	movups %xmm0,(%rsi,%r9,1)
  72ecbd:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72ecc1:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ecc5:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72ecca:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72ecce:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72ecd2:	48 89 df             	mov    %rbx,%rdi
  72ecd5:	48 c1 e7 04          	shl    $0x4,%rdi
  72ecd9:	48 3b 70 30          	cmp    0x30(%rax),%rsi
  72ecdd:	48 89 ce             	mov    %rcx,%rsi
  72ece0:	49 0f 43 f7          	cmovae %r15,%rsi
  72ece4:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72ece8:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72ecec:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ecf0:	48 83 c0 40          	add    $0x40,%rax
  72ecf4:	48 39 d0             	cmp    %rdx,%rax
  72ecf7:	0f 82 63 ff ff ff    	jb     72ec60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x3d0>
  72ecfd:	4c 89 d2             	mov    %r10,%rdx
  72ed00:	48 c1 e2 04          	shl    $0x4,%rdx
  72ed04:	4c 01 e2             	add    %r12,%rdx
  72ed07:	48 39 d0             	cmp    %rdx,%rax
  72ed0a:	73 31                	jae    72ed3d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4ad>
  72ed0c:	0f 1f 40 00          	nopl   0x0(%rax)
  72ed10:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72ed14:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72ed18:	48 89 df             	mov    %rbx,%rdi
  72ed1b:	48 c1 e7 04          	shl    $0x4,%rdi
  72ed1f:	48 3b 30             	cmp    (%rax),%rsi
  72ed22:	48 89 ce             	mov    %rcx,%rsi
  72ed25:	49 0f 43 f7          	cmovae %r15,%rsi
  72ed29:	0f 10 00             	movups (%rax),%xmm0
  72ed2c:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72ed30:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ed34:	48 83 c0 10          	add    $0x10,%rax
  72ed38:	48 39 d0             	cmp    %rdx,%rax
  72ed3b:	72 d3                	jb     72ed10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x480>
  72ed3d:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  72ed42:	4d 39 f2             	cmp    %r14,%r10
  72ed45:	74 29                	je     72ed70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4e0>
  72ed47:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72ed4b:	48 89 da             	mov    %rbx,%rdx
  72ed4e:	48 c1 e2 04          	shl    $0x4,%rdx
  72ed52:	0f 10 00             	movups (%rax),%xmm0
  72ed55:	41 0f 11 04 17       	movups %xmm0,(%r15,%rdx,1)
  72ed5a:	48 ff c3             	inc    %rbx
  72ed5d:	48 83 c0 10          	add    $0x10,%rax
  72ed61:	4d 89 f2             	mov    %r14,%r10
  72ed64:	e9 d7 fe ff ff       	jmp    72ec40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x3b0>
  72ed69:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72ed70:	48 89 dd             	mov    %rbx,%rbp
  72ed73:	48 c1 e5 04          	shl    $0x4,%rbp
  72ed77:	4c 89 e7             	mov    %r12,%rdi
  72ed7a:	4c 89 fe             	mov    %r15,%rsi
  72ed7d:	48 89 ea             	mov    %rbp,%rdx
  72ed80:	ff 15 6a 8f 3b 00    	call   *0x3b8f6a(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72ed86:	4d 89 f5             	mov    %r14,%r13
  72ed89:	49 29 dd             	sub    %rbx,%r13
  72ed8c:	0f 84 f9 00 00 00    	je     72ee8b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5fb>
  72ed92:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
  72ed96:	48 8d 43 01          	lea    0x1(%rbx),%rax
  72ed9a:	49 39 c6             	cmp    %rax,%r14
  72ed9d:	75 09                	jne    72eda8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x518>
  72ed9f:	31 c0                	xor    %eax,%eax
  72eda1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72eda6:	eb 69                	jmp    72ee11 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x581>
  72eda8:	4c 89 e9             	mov    %r13,%rcx
  72edab:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72edaf:	49 8d 14 2c          	lea    (%r12,%rbp,1),%rdx
  72edb3:	48 83 c2 10          	add    $0x10,%rdx
  72edb7:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72edbb:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  72edc0:	49 01 c2             	add    %rax,%r10
  72edc3:	31 c0                	xor    %eax,%eax
  72edc5:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72edcc:	ff ff 0f 
  72edcf:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72edd4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72eddb:	00 00 00 00 00 
  72ede0:	48 89 c6             	mov    %rax,%rsi
  72ede3:	41 0f 10 02          	movups (%r10),%xmm0
  72ede7:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72edeb:	48 83 c0 02          	add    $0x2,%rax
  72edef:	4c 31 c6             	xor    %r8,%rsi
  72edf2:	48 c1 e6 04          	shl    $0x4,%rsi
  72edf6:	41 0f 10 04 31       	movups (%r9,%rsi,1),%xmm0
  72edfb:	0f 11 02             	movups %xmm0,(%rdx)
  72edfe:	48 83 c2 20          	add    $0x20,%rdx
  72ee02:	49 83 c2 e0          	add    $0xffffffffffffffe0,%r10
  72ee06:	48 39 c1             	cmp    %rax,%rcx
  72ee09:	75 d5                	jne    72ede0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x550>
  72ee0b:	41 f6 c5 01          	test   $0x1,%r13b
  72ee0f:	74 17                	je     72ee28 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x598>
  72ee11:	48 89 c1             	mov    %rax,%rcx
  72ee14:	48 f7 d1             	not    %rcx
  72ee17:	48 c1 e1 04          	shl    $0x4,%rcx
  72ee1b:	48 c1 e0 04          	shl    $0x4,%rax
  72ee1f:	41 0f 10 04 09       	movups (%r9,%rcx,1),%xmm0
  72ee24:	0f 11 04 07          	movups %xmm0,(%rdi,%rax,1)
  72ee28:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72ee2d:	48 39 da             	cmp    %rbx,%rdx
  72ee30:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72ee35:	0f 82 80 00 00 00    	jb     72eebb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x62b>
  72ee3b:	49 89 fc             	mov    %rdi,%r12
  72ee3e:	b8 00 00 00 00       	mov    $0x0,%eax
  72ee43:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72ee48:	49 83 fd 21          	cmp    $0x21,%r13
  72ee4c:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72ee50:	0f 83 85 fa ff ff    	jae    72e8db <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4b>
  72ee56:	e9 5d fa ff ff       	jmp    72e8b8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x28>
  72ee5b:	4c 89 e7             	mov    %r12,%rdi
  72ee5e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72ee63:	4c 89 fa             	mov    %r15,%rdx
  72ee66:	4c 89 f1             	mov    %r14,%rcx
  72ee69:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72ee6f:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  72ee76:	00 
  72ee77:	e8 94 d4 ff ff       	call   72c310 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>
  72ee7c:	48 83 c4 58          	add    $0x58,%rsp
  72ee80:	5b                   	pop    %rbx
  72ee81:	41 5c                	pop    %r12
  72ee83:	41 5d                	pop    %r13
  72ee85:	41 5e                	pop    %r14
  72ee87:	41 5f                	pop    %r15
  72ee89:	5d                   	pop    %rbp
  72ee8a:	c3                   	ret
  72ee8b:	4c 03 64 24 18       	add    0x18(%rsp),%r12
  72ee90:	45 31 ed             	xor    %r13d,%r13d
  72ee93:	4c 89 e7             	mov    %r12,%rdi
  72ee96:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72ee9b:	e9 18 fa ff ff       	jmp    72e8b8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x28>
  72eea0:	0f 0b                	ud2
  72eea2:	48 8d 3d 7b a7 93 ff 	lea    -0x6c5885(%rip),%rdi        # 69624 <anon.82a788e7fdd98d311675b83eb91f04ac.0.llvm.15086054616281437909+0x27>
  72eea9:	48 8d 15 38 c4 38 00 	lea    0x38c438(%rip),%rdx        # abb2e8 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x38>
  72eeb0:	be 13 00 00 00       	mov    $0x13,%esi
  72eeb5:	ff 15 65 8e 3b 00    	call   *0x3b8e65(%rip)        # ae7d20 <_DYNAMIC+0x2a0>
  72eebb:	48 8d 0d 3e c4 38 00 	lea    0x38c43e(%rip),%rcx        # abb300 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x50>
  72eec2:	48 89 df             	mov    %rbx,%rdi
  72eec5:	48 89 d6             	mov    %rdx,%rsi
  72eec8:	ff 15 42 8e 3b 00    	call   *0x3b8e42(%rip)        # ae7d10 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
