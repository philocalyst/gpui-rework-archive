
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000071aad0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_>:
  71aad0:	55                   	push   %rbp
  71aad1:	41 57                	push   %r15
  71aad3:	41 56                	push   %r14
  71aad5:	41 55                	push   %r13
  71aad7:	41 54                	push   %r12
  71aad9:	53                   	push   %rbx
  71aada:	48 83 ec 58          	sub    $0x58,%rsp
  71aade:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  71aae3:	4c 8b 7e 10          	mov    0x10(%rsi),%r15
  71aae7:	4c 8b 2e             	mov    (%rsi),%r13
  71aaea:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  71aaee:	48 8d 46 20          	lea    0x20(%rsi),%rax
  71aaf2:	48 8b 6e 18          	mov    0x18(%rsi),%rbp
  71aaf6:	4d 85 ff             	test   %r15,%r15
  71aaf9:	74 09                	je     71ab04 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x34>
  71aafb:	49 39 ef             	cmp    %rbp,%r15
  71aafe:	0f 85 a4 00 00 00    	jne    71aba8 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xd8>
  71ab04:	4d 85 ed             	test   %r13,%r13
  71ab07:	74 4e                	je     71ab57 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x87>
  71ab09:	49 39 fd             	cmp    %rdi,%r13
  71ab0c:	74 49                	je     71ab57 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x87>
  71ab0e:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  71ab15:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71ab1c:	00 00 00 00 
  71ab20:	4d 8b 7d e0          	mov    -0x20(%r13),%r15
  71ab24:	49 8b 6d e8          	mov    -0x18(%r13),%rbp
  71ab28:	48 85 ed             	test   %rbp,%rbp
  71ab2b:	75 6a                	jne    71ab97 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xc7>
  71ab2d:	49 8d 8d a8 00 00 00 	lea    0xa8(%r13),%rcx
  71ab34:	49 39 fd             	cmp    %rdi,%r13
  71ab37:	49 89 cd             	mov    %rcx,%r13
  71ab3a:	75 e4                	jne    71ab20 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x50>
  71ab3c:	48 8d 91 b0 fe ff ff 	lea    -0x150(%rcx),%rdx
  71ab43:	48 89 10             	mov    %rdx,(%rax)
  71ab46:	48 c1 e5 05          	shl    $0x5,%rbp
  71ab4a:	4c 01 fd             	add    %r15,%rbp
  71ab4d:	48 81 c1 58 ff ff ff 	add    $0xffffffffffffff58,%rcx
  71ab54:	49 89 cd             	mov    %rcx,%r13
  71ab57:	4c 8b 7e 28          	mov    0x28(%rsi),%r15
  71ab5b:	4d 85 ff             	test   %r15,%r15
  71ab5e:	74 16                	je     71ab76 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xa6>
  71ab60:	4c 8b 46 30          	mov    0x30(%rsi),%r8
  71ab64:	4d 39 c7             	cmp    %r8,%r15
  71ab67:	74 0d                	je     71ab76 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xa6>
  71ab69:	4d 8d 4f 20          	lea    0x20(%r15),%r9
  71ab6d:	48 8d 46 38          	lea    0x38(%rsi),%rax
  71ab71:	45 31 d2             	xor    %r10d,%r10d
  71ab74:	eb 3e                	jmp    71abb4 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xe4>
  71ab76:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  71ab7b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  71ab82:	48 c7 40 08 08 00 00 	movq   $0x8,0x8(%rax)
  71ab89:	00 
  71ab8a:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  71ab91:	00 
  71ab92:	e9 b8 02 00 00       	jmp    71ae4f <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x37f>
  71ab97:	49 8d 8d 58 ff ff ff 	lea    -0xa8(%r13),%rcx
  71ab9e:	48 89 08             	mov    %rcx,(%rax)
  71aba1:	48 c1 e5 05          	shl    $0x5,%rbp
  71aba5:	4c 01 fd             	add    %r15,%rbp
  71aba8:	4d 8d 57 20          	lea    0x20(%r15),%r10
  71abac:	4c 8b 4e 28          	mov    0x28(%rsi),%r9
  71abb0:	4c 8b 46 30          	mov    0x30(%rsi),%r8
  71abb4:	48 89 e9             	mov    %rbp,%rcx
  71abb7:	4c 29 d1             	sub    %r10,%rcx
  71abba:	48 c1 e9 05          	shr    $0x5,%rcx
  71abbe:	4d 85 d2             	test   %r10,%r10
  71abc1:	49 0f 44 ca          	cmove  %r10,%rcx
  71abc5:	4c 89 c2             	mov    %r8,%rdx
  71abc8:	4c 29 ca             	sub    %r9,%rdx
  71abcb:	48 c1 ea 05          	shr    $0x5,%rdx
  71abcf:	4d 85 c9             	test   %r9,%r9
  71abd2:	49 0f 44 d1          	cmove  %r9,%rdx
  71abd6:	48 01 ca             	add    %rcx,%rdx
  71abd9:	48 83 fa 04          	cmp    $0x4,%rdx
  71abdd:	41 be 03 00 00 00    	mov    $0x3,%r14d
  71abe3:	4c 0f 43 f2          	cmovae %rdx,%r14
  71abe7:	48 b9 54 55 55 55 55 	movabs $0x555555555555554,%rcx
  71abee:	55 55 05 
  71abf1:	48 39 ca             	cmp    %rcx,%rdx
  71abf4:	76 0b                	jbe    71ac01 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x131>
  71abf6:	31 ff                	xor    %edi,%edi
  71abf8:	4c 89 e6             	mov    %r12,%rsi
  71abfb:	ff 15 9f fd 3c 00    	call   *0x3cfd9f(%rip)        # aea9a0 <_DYNAMIC+0x328>
  71ac01:	48 8b 00             	mov    (%rax),%rax
  71ac04:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
  71ac0b:	49 8b 17             	mov    (%r15),%rdx
  71ac0e:	4a 8d 04 f5 08 00 00 	lea    0x8(,%r14,8),%rax
  71ac15:	00 
  71ac16:	48 8d 1c 40          	lea    (%rax,%rax,2),%rbx
  71ac1a:	48 85 db             	test   %rbx,%rbx
  71ac1d:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  71ac22:	74 65                	je     71ac89 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x1b9>
  71ac24:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  71ac29:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  71ac2e:	4c 89 14 24          	mov    %r10,(%rsp)
  71ac32:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  71ac37:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  71ac3c:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  71ac41:	ff 15 91 fc 3c 00    	call   *0x3cfc91(%rip)        # aea8d8 <_DYNAMIC+0x260>
  71ac47:	be 08 00 00 00       	mov    $0x8,%esi
  71ac4c:	49 89 dc             	mov    %rbx,%r12
  71ac4f:	48 89 df             	mov    %rbx,%rdi
  71ac52:	ff 15 60 fc 3c 00    	call   *0x3cfc60(%rip)        # aea8b8 <_DYNAMIC+0x240>
  71ac58:	bf 08 00 00 00       	mov    $0x8,%edi
  71ac5d:	48 85 c0             	test   %rax,%rax
  71ac60:	74 96                	je     71abf8 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x128>
  71ac62:	49 ff c6             	inc    %r14
  71ac65:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  71ac6a:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  71ac6f:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  71ac74:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  71ac79:	4c 8b 14 24          	mov    (%rsp),%r10
  71ac7d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  71ac82:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  71ac87:	eb 08                	jmp    71ac91 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x1c1>
  71ac89:	b8 08 00 00 00       	mov    $0x8,%eax
  71ac8e:	45 31 f6             	xor    %r14d,%r14d
  71ac91:	48 89 10             	mov    %rdx,(%rax)
  71ac94:	48 89 48 08          	mov    %rcx,0x8(%rax)
  71ac98:	4c 89 78 10          	mov    %r15,0x10(%rax)
  71ac9c:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  71aca1:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  71aca6:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
  71acad:	00 00 
  71acaf:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
  71acb3:	48 89 0c 24          	mov    %rcx,(%rsp)
  71acb7:	48 8b 4e 38          	mov    0x38(%rsi),%rcx
  71acbb:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  71acc0:	be 01 00 00 00       	mov    $0x1,%esi
  71acc5:	eb 26                	jmp    71aced <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x21d>
  71acc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  71acce:	00 00 
  71acd0:	48 8d 0c 76          	lea    (%rsi,%rsi,2),%rcx
  71acd4:	48 89 1c c8          	mov    %rbx,(%rax,%rcx,8)
  71acd8:	48 89 54 c8 08       	mov    %rdx,0x8(%rax,%rcx,8)
  71acdd:	4c 89 4c c8 10       	mov    %r9,0x10(%rax,%rcx,8)
  71ace2:	48 ff c6             	inc    %rsi
  71ace5:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  71acea:	4d 89 d9             	mov    %r11,%r9
  71aced:	4d 85 d2             	test   %r10,%r10
  71acf0:	74 09                	je     71acfb <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x22b>
  71acf2:	49 39 ea             	cmp    %rbp,%r10
  71acf5:	0f 85 94 00 00 00    	jne    71ad8f <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2bf>
  71acfb:	4d 85 ed             	test   %r13,%r13
  71acfe:	74 44                	je     71ad44 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x274>
  71ad00:	49 39 fd             	cmp    %rdi,%r13
  71ad03:	74 3f                	je     71ad44 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x274>
  71ad05:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  71ad0c:	0f 1f 40 00          	nopl   0x0(%rax)
  71ad10:	49 8b 6d e8          	mov    -0x18(%r13),%rbp
  71ad14:	48 85 ed             	test   %rbp,%rbp
  71ad17:	75 60                	jne    71ad79 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2a9>
  71ad19:	49 8d 8d a8 00 00 00 	lea    0xa8(%r13),%rcx
  71ad20:	49 39 fd             	cmp    %rdi,%r13
  71ad23:	49 89 cd             	mov    %rcx,%r13
  71ad26:	75 e8                	jne    71ad10 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x240>
  71ad28:	48 8b a9 38 ff ff ff 	mov    -0xc8(%rcx),%rbp
  71ad2f:	48 8d 91 b0 fe ff ff 	lea    -0x150(%rcx),%rdx
  71ad36:	48 89 14 24          	mov    %rdx,(%rsp)
  71ad3a:	48 81 c1 58 ff ff ff 	add    $0xffffffffffffff58,%rcx
  71ad41:	49 89 cd             	mov    %rcx,%r13
  71ad44:	4d 85 c9             	test   %r9,%r9
  71ad47:	0f 84 ec 00 00 00    	je     71ae39 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x369>
  71ad4d:	4d 39 c1             	cmp    %r8,%r9
  71ad50:	0f 84 e3 00 00 00    	je     71ae39 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x369>
  71ad56:	4d 8d 59 20          	lea    0x20(%r9),%r11
  71ad5a:	45 31 d2             	xor    %r10d,%r10d
  71ad5d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  71ad62:	48 8b 91 a0 00 00 00 	mov    0xa0(%rcx),%rdx
  71ad69:	49 8b 19             	mov    (%r9),%rbx
  71ad6c:	48 3b 74 24 28       	cmp    0x28(%rsp),%rsi
  71ad71:	0f 85 59 ff ff ff    	jne    71acd0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  71ad77:	eb 39                	jmp    71adb2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2e2>
  71ad79:	4d 8b 55 e0          	mov    -0x20(%r13),%r10
  71ad7d:	48 c1 e5 05          	shl    $0x5,%rbp
  71ad81:	4c 01 d5             	add    %r10,%rbp
  71ad84:	49 8d 8d 58 ff ff ff 	lea    -0xa8(%r13),%rcx
  71ad8b:	48 89 0c 24          	mov    %rcx,(%rsp)
  71ad8f:	4d 89 cb             	mov    %r9,%r11
  71ad92:	4d 89 d1             	mov    %r10,%r9
  71ad95:	49 83 c2 20          	add    $0x20,%r10
  71ad99:	48 8b 0c 24          	mov    (%rsp),%rcx
  71ad9d:	48 8b 91 a0 00 00 00 	mov    0xa0(%rcx),%rdx
  71ada4:	49 8b 19             	mov    (%r9),%rbx
  71ada7:	48 3b 74 24 28       	cmp    0x28(%rsp),%rsi
  71adac:	0f 85 1e ff ff ff    	jne    71acd0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  71adb2:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  71adb7:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  71adbc:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  71adc1:	4d 89 c4             	mov    %r8,%r12
  71adc4:	4c 89 c2             	mov    %r8,%rdx
  71adc7:	4c 29 da             	sub    %r11,%rdx
  71adca:	48 c1 ea 05          	shr    $0x5,%rdx
  71adce:	48 89 e8             	mov    %rbp,%rax
  71add1:	4c 29 d0             	sub    %r10,%rax
  71add4:	48 c1 e8 05          	shr    $0x5,%rax
  71add8:	4d 85 d2             	test   %r10,%r10
  71addb:	4d 89 d6             	mov    %r10,%r14
  71adde:	49 0f 44 c2          	cmove  %r10,%rax
  71ade2:	48 ff c2             	inc    %rdx
  71ade5:	4d 89 df             	mov    %r11,%r15
  71ade8:	4d 85 db             	test   %r11,%r11
  71adeb:	b9 01 00 00 00       	mov    $0x1,%ecx
  71adf0:	48 0f 44 d1          	cmove  %rcx,%rdx
  71adf4:	48 01 c2             	add    %rax,%rdx
  71adf7:	b9 08 00 00 00       	mov    $0x8,%ecx
  71adfc:	41 b8 18 00 00 00    	mov    $0x18,%r8d
  71ae02:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  71ae07:	48 89 f3             	mov    %rsi,%rbx
  71ae0a:	e8 b1 35 01 00       	call   72e3c0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71ae0f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  71ae14:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  71ae19:	4d 89 e0             	mov    %r12,%r8
  71ae1c:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  71ae21:	4d 89 f2             	mov    %r14,%r10
  71ae24:	48 89 de             	mov    %rbx,%rsi
  71ae27:	4d 89 fb             	mov    %r15,%r11
  71ae2a:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  71ae2f:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  71ae34:	e9 97 fe ff ff       	jmp    71acd0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  71ae39:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  71ae3e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  71ae43:	48 89 48 10          	mov    %rcx,0x10(%rax)
  71ae47:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  71ae4c:	0f 11 00             	movups %xmm0,(%rax)
  71ae4f:	48 83 c4 58          	add    $0x58,%rsp
  71ae53:	5b                   	pop    %rbx
  71ae54:	41 5c                	pop    %r12
  71ae56:	41 5d                	pop    %r13
  71ae58:	41 5e                	pop    %r14
  71ae5a:	41 5f                	pop    %r15
  71ae5c:	5d                   	pop    %rbp
  71ae5d:	c3                   	ret
  71ae5e:	48 89 c3             	mov    %rax,%rbx
  71ae61:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  71ae66:	48 85 c0             	test   %rax,%rax
  71ae69:	74 18                	je     71ae83 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x3b3>
  71ae6b:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  71ae70:	48 c1 e0 03          	shl    $0x3,%rax
  71ae74:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  71ae78:	ba 08 00 00 00       	mov    $0x8,%edx
  71ae7d:	ff 15 3d fa 3c 00    	call   *0x3cfa3d(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ae83:	48 89 df             	mov    %rbx,%rdi
  71ae86:	e8 15 02 3a 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
