
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072fc50 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_>:
  72fc50:	55                   	push   %rbp
  72fc51:	41 57                	push   %r15
  72fc53:	41 56                	push   %r14
  72fc55:	41 55                	push   %r13
  72fc57:	41 54                	push   %r12
  72fc59:	53                   	push   %rbx
  72fc5a:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
  72fc61:	48 89 fb             	mov    %rdi,%rbx
  72fc64:	48 89 34 24          	mov    %rsi,(%rsp)
  72fc68:	48 89 e0             	mov    %rsp,%rax
  72fc6b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  72fc70:	48 8b 07             	mov    (%rdi),%rax
  72fc73:	48 85 c0             	test   %rax,%rax
  72fc76:	74 38                	je     72fcb0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x60>
  72fc78:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  72fc7c:	48 85 c9             	test   %rcx,%rcx
  72fc7f:	0f 84 89 00 00 00    	je     72fd0e <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0xbe>
  72fc85:	48 89 ca             	mov    %rcx,%rdx
  72fc88:	48 83 e2 07          	and    $0x7,%rdx
  72fc8c:	74 28                	je     72fcb6 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x66>
  72fc8e:	31 f6                	xor    %esi,%esi
  72fc90:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fc97:	48 ff c6             	inc    %rsi
  72fc9a:	48 39 f2             	cmp    %rsi,%rdx
  72fc9d:	75 f1                	jne    72fc90 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x40>
  72fc9f:	48 89 ca             	mov    %rcx,%rdx
  72fca2:	48 29 f2             	sub    %rsi,%rdx
  72fca5:	48 89 de             	mov    %rbx,%rsi
  72fca8:	48 83 f9 08          	cmp    $0x8,%rcx
  72fcac:	73 22                	jae    72fcd0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x80>
  72fcae:	eb 61                	jmp    72fd11 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0xc1>
  72fcb0:	31 c0                	xor    %eax,%eax
  72fcb2:	31 f6                	xor    %esi,%esi
  72fcb4:	eb 5b                	jmp    72fd11 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0xc1>
  72fcb6:	48 89 ca             	mov    %rcx,%rdx
  72fcb9:	48 89 de             	mov    %rbx,%rsi
  72fcbc:	48 83 f9 08          	cmp    $0x8,%rcx
  72fcc0:	72 4f                	jb     72fd11 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0xc1>
  72fcc2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72fcc9:	1f 84 00 00 00 00 00 
  72fcd0:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fcd7:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fcde:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fce5:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fcec:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fcf3:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fcfa:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd01:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd08:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  72fd0c:	75 c2                	jne    72fcd0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x80>
  72fd0e:	48 89 de             	mov    %rbx,%rsi
  72fd11:	4c 8d 6b 10          	lea    0x10(%rbx),%r13
  72fd15:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
  72fd1a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72fd1f:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  72fd24:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
  72fd29:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  72fd2e:	0f 57 c0             	xorps  %xmm0,%xmm0
  72fd31:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
  72fd36:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  72fd3b:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  72fd40:	e8 2b 90 fe ff       	call   718d70 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>
  72fd45:	83 7c 24 40 01       	cmpl   $0x1,0x40(%rsp)
  72fd4a:	75 4f                	jne    72fd9b <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x14b>
  72fd4c:	48 8d 6c 24 48       	lea    0x48(%rsp),%rbp
  72fd51:	4c 8d 74 24 78       	lea    0x78(%rsp),%r14
  72fd56:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
  72fd5b:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
  72fd60:	48 8b 45 20          	mov    0x20(%rbp),%rax
  72fd64:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  72fd6b:	00 
  72fd6c:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
  72fd70:	0f 10 4d 10          	movups 0x10(%rbp),%xmm1
  72fd74:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
  72fd7b:	00 
  72fd7c:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  72fd81:	4c 89 f7             	mov    %r14,%rdi
  72fd84:	e8 57 7d fe ff       	call   717ae0 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  72fd89:	4c 89 ff             	mov    %r15,%rdi
  72fd8c:	4c 89 e6             	mov    %r12,%rsi
  72fd8f:	e8 dc 8f fe ff       	call   718d70 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>
  72fd94:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
  72fd99:	75 c5                	jne    72fd60 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x110>
  72fd9b:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
  72fda0:	75 17                	jne    72fdb9 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x169>
  72fda2:	48 89 df             	mov    %rbx,%rdi
  72fda5:	e8 36 8c fe ff       	call   7189e0 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB17_13GeometryStyleEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  72fdaa:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  72fdb1:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  72fdb8:	00 
  72fdb9:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
  72fdc0:	5b                   	pop    %rbx
  72fdc1:	41 5c                	pop    %r12
  72fdc3:	41 5d                	pop    %r13
  72fdc5:	41 5e                	pop    %r14
  72fdc7:	41 5f                	pop    %r15
  72fdc9:	5d                   	pop    %rbp
  72fdca:	c3                   	ret
  72fdcb:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  72fdd2:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  72fdd9:	00 
  72fdda:	48 89 c7             	mov    %rax,%rdi
  72fddd:	e8 6e 86 38 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
