
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000726ac0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_>:
  726ac0:	41 57                	push   %r15
  726ac2:	41 56                	push   %r14
  726ac4:	41 55                	push   %r13
  726ac6:	41 54                	push   %r12
  726ac8:	53                   	push   %rbx
  726ac9:	48 81 ec 40 01 00 00 	sub    $0x140,%rsp
  726ad0:	48 89 fb             	mov    %rdi,%rbx
  726ad3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  726ad8:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  726add:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  726ae2:	48 8b 07             	mov    (%rdi),%rax
  726ae5:	48 85 c0             	test   %rax,%rax
  726ae8:	74 46                	je     726b30 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0x70>
  726aea:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  726aee:	48 85 c9             	test   %rcx,%rcx
  726af1:	0f 84 97 00 00 00    	je     726b8e <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0xce>
  726af7:	48 89 ca             	mov    %rcx,%rdx
  726afa:	48 83 e2 07          	and    $0x7,%rdx
  726afe:	74 36                	je     726b36 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0x76>
  726b00:	31 f6                	xor    %esi,%esi
  726b02:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  726b09:	1f 84 00 00 00 00 00 
  726b10:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b17:	48 ff c6             	inc    %rsi
  726b1a:	48 39 f2             	cmp    %rsi,%rdx
  726b1d:	75 f1                	jne    726b10 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0x50>
  726b1f:	48 89 ca             	mov    %rcx,%rdx
  726b22:	48 29 f2             	sub    %rsi,%rdx
  726b25:	48 89 de             	mov    %rbx,%rsi
  726b28:	48 83 f9 08          	cmp    $0x8,%rcx
  726b2c:	73 22                	jae    726b50 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0x90>
  726b2e:	eb 61                	jmp    726b91 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0xd1>
  726b30:	31 c0                	xor    %eax,%eax
  726b32:	31 f6                	xor    %esi,%esi
  726b34:	eb 5b                	jmp    726b91 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0xd1>
  726b36:	48 89 ca             	mov    %rcx,%rdx
  726b39:	48 89 de             	mov    %rbx,%rsi
  726b3c:	48 83 f9 08          	cmp    $0x8,%rcx
  726b40:	72 4f                	jb     726b91 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0xd1>
  726b42:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  726b49:	1f 84 00 00 00 00 00 
  726b50:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b57:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b5e:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b65:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b6c:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b73:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b7a:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b81:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  726b88:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  726b8c:	75 c2                	jne    726b50 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0x90>
  726b8e:	48 89 de             	mov    %rbx,%rsi
  726b91:	4c 8d 6b 10          	lea    0x10(%rbx),%r13
  726b95:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
  726b9a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  726b9f:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  726ba4:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  726ba9:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  726bae:	0f 57 c0             	xorps  %xmm0,%xmm0
  726bb1:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
  726bb6:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  726bbb:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  726bc0:	e8 3b 1f ff ff       	call   718b00 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>
  726bc5:	83 7c 24 50 02       	cmpl   $0x2,0x50(%rsp)
  726bca:	0f 84 b2 00 00 00    	je     726c82 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0x1c2>
  726bd0:	4c 8d b4 24 20 01 00 	lea    0x120(%rsp),%r14
  726bd7:	00 
  726bd8:	4c 8d 7c 24 48       	lea    0x48(%rsp),%r15
  726bdd:	4c 8d 64 24 18       	lea    0x18(%rsp),%r12
  726be2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  726be9:	1f 84 00 00 00 00 00 
  726bf0:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  726bf7:	00 
  726bf8:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  726bff:	00 
  726c00:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
  726c07:	00 
  726c08:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  726c0f:	00 
  726c10:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  726c17:	00 
  726c18:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  726c1f:	00 
  726c20:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  726c27:	00 
  726c28:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  726c2f:	00 
  726c30:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  726c35:	0f 10 4c 24 58       	movups 0x58(%rsp),%xmm1
  726c3a:	0f 10 54 24 68       	movups 0x68(%rsp),%xmm2
  726c3f:	0f 10 5c 24 78       	movups 0x78(%rsp),%xmm3
  726c44:	0f 29 9c 24 f0 00 00 	movaps %xmm3,0xf0(%rsp)
  726c4b:	00 
  726c4c:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  726c53:	00 
  726c54:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
  726c5b:	00 
  726c5c:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  726c63:	00 
  726c64:	4c 89 f7             	mov    %r14,%rdi
  726c67:	e8 b4 06 ff ff       	call   717320 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  726c6c:	4c 89 ff             	mov    %r15,%rdi
  726c6f:	4c 89 e6             	mov    %r12,%rsi
  726c72:	e8 89 1e ff ff       	call   718b00 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>
  726c77:	83 7c 24 50 02       	cmpl   $0x2,0x50(%rsp)
  726c7c:	0f 85 6e ff ff ff    	jne    726bf0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0x130>
  726c82:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
  726c87:	75 17                	jne    726ca0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0EB1y_+0x1e0>
  726c89:	48 89 df             	mov    %rbx,%rdi
  726c8c:	e8 bf 19 ff ff       	call   718650 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB19_5style5StyleEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  726c91:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  726c98:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  726c9f:	00 
  726ca0:	48 81 c4 40 01 00 00 	add    $0x140,%rsp
  726ca7:	5b                   	pop    %rbx
  726ca8:	41 5c                	pop    %r12
  726caa:	41 5d                	pop    %r13
  726cac:	41 5e                	pop    %r14
  726cae:	41 5f                	pop    %r15
  726cb0:	c3                   	ret
  726cb1:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  726cb8:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  726cbf:	00 
  726cc0:	48 89 c7             	mov    %rax,%rdi
  726cc3:	e8 d8 43 39 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
