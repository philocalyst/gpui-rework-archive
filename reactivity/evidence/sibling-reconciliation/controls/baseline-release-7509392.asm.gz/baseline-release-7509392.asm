
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000729590 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_>:
  729590:	55                   	push   %rbp
  729591:	41 57                	push   %r15
  729593:	41 56                	push   %r14
  729595:	41 55                	push   %r13
  729597:	41 54                	push   %r12
  729599:	53                   	push   %rbx
  72959a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  7295a1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  7295a8:	00 
  7295a9:	50                   	push   %rax
  7295aa:	49 89 d6             	mov    %rdx,%r14
  7295ad:	48 89 f1             	mov    %rsi,%rcx
  7295b0:	48 d1 e9             	shr    $1,%rcx
  7295b3:	48 89 f0             	mov    %rsi,%rax
  7295b6:	48 29 c8             	sub    %rcx,%rax
  7295b9:	48 81 fe 20 a1 07 00 	cmp    $0x7a120,%rsi
  7295c0:	bb 20 a1 07 00       	mov    $0x7a120,%ebx
  7295c5:	48 0f 42 de          	cmovb  %rsi,%rbx
  7295c9:	48 39 c3             	cmp    %rax,%rbx
  7295cc:	48 0f 46 d8          	cmovbe %rax,%rbx
  7295d0:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  7295d7:	73 0c                	jae    7295e5 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x55>
  7295d9:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
  7295de:	b9 00 01 00 00       	mov    $0x100,%ecx
  7295e3:	eb 62                	jmp    729647 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0xb7>
  7295e5:	49 89 dc             	mov    %rbx,%r12
  7295e8:	49 c1 e4 04          	shl    $0x4,%r12
  7295ec:	48 c1 e8 3c          	shr    $0x3c,%rax
  7295f0:	0f 95 c0             	setne  %al
  7295f3:	48 b9 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rcx
  7295fa:	ff ff 7f 
  7295fd:	49 39 cc             	cmp    %rcx,%r12
  729600:	0f 97 c1             	seta   %cl
  729603:	08 c1                	or     %al,%cl
  729605:	74 0f                	je     729616 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x86>
  729607:	45 31 ed             	xor    %r13d,%r13d
  72960a:	4c 89 ef             	mov    %r13,%rdi
  72960d:	4c 89 e6             	mov    %r12,%rsi
  729610:	ff 15 8a 13 3c 00    	call   *0x3c138a(%rip)        # aea9a0 <_DYNAMIC+0x328>
  729616:	49 89 f7             	mov    %rsi,%r15
  729619:	48 89 fd             	mov    %rdi,%rbp
  72961c:	ff 15 b6 12 3c 00    	call   *0x3c12b6(%rip)        # aea8d8 <_DYNAMIC+0x260>
  729622:	41 bd 08 00 00 00    	mov    $0x8,%r13d
  729628:	be 08 00 00 00       	mov    $0x8,%esi
  72962d:	4c 89 e7             	mov    %r12,%rdi
  729630:	ff 15 82 12 3c 00    	call   *0x3c1282(%rip)        # aea8b8 <_DYNAMIC+0x240>
  729636:	48 89 ef             	mov    %rbp,%rdi
  729639:	4c 89 fe             	mov    %r15,%rsi
  72963c:	49 89 c7             	mov    %rax,%r15
  72963f:	48 89 d9             	mov    %rbx,%rcx
  729642:	48 85 c0             	test   %rax,%rax
  729645:	74 c3                	je     72960a <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x7a>
  729647:	45 31 c0             	xor    %r8d,%r8d
  72964a:	48 83 fe 41          	cmp    $0x41,%rsi
  72964e:	41 0f 92 c0          	setb   %r8b
  729652:	4c 89 fa             	mov    %r15,%rdx
  729655:	4d 89 f1             	mov    %r14,%r9
  729658:	e8 c3 7f 00 00       	call   731620 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>
  72965d:	48 81 fb 00 01 00 00 	cmp    $0x100,%rbx
  729664:	76 15                	jbe    72967b <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0xeb>
  729666:	48 c1 e3 04          	shl    $0x4,%rbx
  72966a:	ba 08 00 00 00       	mov    $0x8,%edx
  72966f:	4c 89 ff             	mov    %r15,%rdi
  729672:	48 89 de             	mov    %rbx,%rsi
  729675:	ff 15 45 12 3c 00    	call   *0x3c1245(%rip)        # aea8c0 <_DYNAMIC+0x248>
  72967b:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  729682:	5b                   	pop    %rbx
  729683:	41 5c                	pop    %r12
  729685:	41 5d                	pop    %r13
  729687:	41 5e                	pop    %r14
  729689:	41 5f                	pop    %r15
  72968b:	5d                   	pop    %rbp
  72968c:	c3                   	ret
  72968d:	49 89 c6             	mov    %rax,%r14
  729690:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  729697:	73 08                	jae    7296a1 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x111>
  729699:	4c 89 f7             	mov    %r14,%rdi
  72969c:	e8 ff 19 39 00       	call   abb0a0 <_Unwind_Resume@plt>
  7296a1:	48 c1 e3 04          	shl    $0x4,%rbx
  7296a5:	ba 08 00 00 00       	mov    $0x8,%edx
  7296aa:	4c 89 ff             	mov    %r15,%rdi
  7296ad:	48 89 de             	mov    %rbx,%rsi
  7296b0:	ff 15 0a 12 3c 00    	call   *0x3c120a(%rip)        # aea8c0 <_DYNAMIC+0x248>
  7296b6:	4c 89 f7             	mov    %r14,%rdi
  7296b9:	e8 e2 19 39 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
