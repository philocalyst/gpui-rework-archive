
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000071ae90 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_>:
  71ae90:	55                   	push   %rbp
  71ae91:	41 57                	push   %r15
  71ae93:	41 56                	push   %r14
  71ae95:	41 55                	push   %r13
  71ae97:	41 54                	push   %r12
  71ae99:	53                   	push   %rbx
  71ae9a:	48 83 ec 28          	sub    $0x28,%rsp
  71ae9e:	49 89 f6             	mov    %rsi,%r14
  71aea1:	48 89 fb             	mov    %rdi,%rbx
  71aea4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  71aeab:	00 00 00 00 00 
  71aeb0:	4c 89 f7             	mov    %r14,%rdi
  71aeb3:	e8 88 de ff ff       	call   718d40 <_RNvXsk_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_4IterNtNtNtCshBhuxcId5D0_4gpui7runtime6scroll11ViewportKeyNtB14_13ViewportStateENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71aeb8:	48 85 c0             	test   %rax,%rax
  71aebb:	0f 84 f1 02 00 00    	je     71b1b2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x322>
  71aec1:	80 38 00             	cmpb   $0x0,(%rax)
  71aec4:	75 ea                	jne    71aeb0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x20>
  71aec6:	48 83 3a 02          	cmpq   $0x2,(%rdx)
  71aeca:	74 e4                	je     71aeb0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x20>
  71aecc:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  71aed1:	4c 8b 7a 18          	mov    0x18(%rdx),%r15
  71aed5:	4c 8b 60 08          	mov    0x8(%rax),%r12
  71aed9:	ff 15 f9 f9 3c 00    	call   *0x3cf9f9(%rip)        # aea8d8 <_DYNAMIC+0x260>
  71aedf:	bf 40 00 00 00       	mov    $0x40,%edi
  71aee4:	be 08 00 00 00       	mov    $0x8,%esi
  71aee9:	ff 15 c9 f9 3c 00    	call   *0x3cf9c9(%rip)        # aea8b8 <_DYNAMIC+0x240>
  71aeef:	48 85 c0             	test   %rax,%rax
  71aef2:	0f 84 18 03 00 00    	je     71b210 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x380>
  71aef8:	4c 89 38             	mov    %r15,(%rax)
  71aefb:	4c 89 60 08          	mov    %r12,0x8(%rax)
  71aeff:	48 c7 04 24 04 00 00 	movq   $0x4,(%rsp)
  71af06:	00 
  71af07:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  71af0c:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
  71af13:	00 00 
  71af15:	45 0f b6 1e          	movzbl (%r14),%r11d
  71af19:	4d 8b 6e 08          	mov    0x8(%r14),%r13
  71af1d:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  71af21:	49 8b 6e 18          	mov    0x18(%r14),%rbp
  71af25:	4d 8b 66 40          	mov    0x40(%r14),%r12
  71af29:	be 01 00 00 00       	mov    $0x1,%esi
  71af2e:	48 89 e7             	mov    %rsp,%rdi
  71af31:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71af38:	0f 1f 84 00 00 00 00 
  71af3f:	00 
  71af40:	4d 85 e4             	test   %r12,%r12
  71af43:	0f 84 82 02 00 00    	je     71b1cb <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x33b>
  71af49:	41 f6 c3 01          	test   $0x1,%r11b
  71af4d:	0f 84 ae 02 00 00    	je     71b201 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x371>
  71af53:	4d 85 ed             	test   %r13,%r13
  71af56:	74 28                	je     71af80 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xf0>
  71af58:	41 0f b7 95 8a 05 00 	movzwl 0x58a(%r13),%edx
  71af5f:	00 
  71af60:	48 39 d5             	cmp    %rdx,%rbp
  71af63:	0f 83 c7 00 00 00    	jae    71b030 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1a0>
  71af69:	4c 89 ea             	mov    %r13,%rdx
  71af6c:	49 89 ea             	mov    %rbp,%r10
  71af6f:	e9 e4 00 00 00       	jmp    71b058 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1c8>
  71af74:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  71af7b:	00 00 00 00 00 
  71af80:	48 85 ed             	test   %rbp,%rbp
  71af83:	74 38                	je     71afbd <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x12d>
  71af85:	48 89 ea             	mov    %rbp,%rdx
  71af88:	49 89 cd             	mov    %rcx,%r13
  71af8b:	48 83 e2 07          	and    $0x7,%rdx
  71af8f:	74 31                	je     71afc2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x132>
  71af91:	45 31 c0             	xor    %r8d,%r8d
  71af94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  71af9b:	00 00 00 00 00 
  71afa0:	4d 8b ad 90 05 00 00 	mov    0x590(%r13),%r13
  71afa7:	49 ff c0             	inc    %r8
  71afaa:	4c 39 c2             	cmp    %r8,%rdx
  71afad:	75 f1                	jne    71afa0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x110>
  71afaf:	48 89 e9             	mov    %rbp,%rcx
  71afb2:	4c 29 c1             	sub    %r8,%rcx
  71afb5:	48 83 fd 08          	cmp    $0x8,%rbp
  71afb9:	73 15                	jae    71afd0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x140>
  71afbb:	eb 51                	jmp    71b00e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  71afbd:	49 89 cd             	mov    %rcx,%r13
  71afc0:	eb 4c                	jmp    71b00e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  71afc2:	48 89 e9             	mov    %rbp,%rcx
  71afc5:	48 83 fd 08          	cmp    $0x8,%rbp
  71afc9:	72 43                	jb     71b00e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  71afcb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  71afd0:	49 8b 95 90 05 00 00 	mov    0x590(%r13),%rdx
  71afd7:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  71afde:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  71afe5:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  71afec:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  71aff3:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  71affa:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  71b001:	4c 8b aa 90 05 00 00 	mov    0x590(%rdx),%r13
  71b008:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  71b00c:	75 c2                	jne    71afd0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x140>
  71b00e:	31 c9                	xor    %ecx,%ecx
  71b010:	31 ed                	xor    %ebp,%ebp
  71b012:	41 0f b7 95 8a 05 00 	movzwl 0x58a(%r13),%edx
  71b019:	00 
  71b01a:	48 39 d5             	cmp    %rdx,%rbp
  71b01d:	0f 82 46 ff ff ff    	jb     71af69 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xd9>
  71b023:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71b02a:	84 00 00 00 00 00 
  71b030:	49 8b 95 80 05 00 00 	mov    0x580(%r13),%rdx
  71b037:	48 85 d2             	test   %rdx,%rdx
  71b03a:	0f 84 b2 01 00 00    	je     71b1f2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x362>
  71b040:	48 ff c1             	inc    %rcx
  71b043:	45 0f b7 95 88 05 00 	movzwl 0x588(%r13),%r10d
  71b04a:	00 
  71b04b:	49 89 d5             	mov    %rdx,%r13
  71b04e:	66 44 3b 92 8a 05 00 	cmp    0x58a(%rdx),%r10w
  71b055:	00 
  71b056:	73 d8                	jae    71b030 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1a0>
  71b058:	48 85 c9             	test   %rcx,%rcx
  71b05b:	0f 84 8f 00 00 00    	je     71b0f0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x260>
  71b061:	4e 8d 1c d2          	lea    (%rdx,%r10,8),%r11
  71b065:	49 81 c3 98 05 00 00 	add    $0x598,%r11
  71b06c:	49 89 c8             	mov    %rcx,%r8
  71b06f:	49 83 e0 07          	and    $0x7,%r8
  71b073:	0f 84 27 01 00 00    	je     71b1a0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x310>
  71b079:	45 31 c9             	xor    %r9d,%r9d
  71b07c:	0f 1f 40 00          	nopl   0x0(%rax)
  71b080:	4d 8b 2b             	mov    (%r11),%r13
  71b083:	4d 8d 9d 90 05 00 00 	lea    0x590(%r13),%r11
  71b08a:	49 ff c1             	inc    %r9
  71b08d:	4d 39 c8             	cmp    %r9,%r8
  71b090:	75 ee                	jne    71b080 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1f0>
  71b092:	49 89 c8             	mov    %rcx,%r8
  71b095:	4d 29 c8             	sub    %r9,%r8
  71b098:	48 83 f9 08          	cmp    $0x8,%rcx
  71b09c:	72 43                	jb     71b0e1 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x251>
  71b09e:	66 90                	xchg   %ax,%ax
  71b0a0:	49 8b 0b             	mov    (%r11),%rcx
  71b0a3:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71b0aa:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71b0b1:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71b0b8:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71b0bf:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71b0c6:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71b0cd:	4c 8b a9 90 05 00 00 	mov    0x590(%rcx),%r13
  71b0d4:	4d 8d 9d 90 05 00 00 	lea    0x590(%r13),%r11
  71b0db:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  71b0df:	75 bf                	jne    71b0a0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x210>
  71b0e1:	31 ed                	xor    %ebp,%ebp
  71b0e3:	eb 12                	jmp    71b0f7 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x267>
  71b0e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71b0ec:	00 00 00 00 
  71b0f0:	49 8d 6a 01          	lea    0x1(%r10),%rbp
  71b0f4:	49 89 d5             	mov    %rdx,%r13
  71b0f7:	49 ff cc             	dec    %r12
  71b0fa:	4d 89 d0             	mov    %r10,%r8
  71b0fd:	49 c1 e0 04          	shl    $0x4,%r8
  71b101:	41 b3 01             	mov    $0x1,%r11b
  71b104:	42 80 3c 02 00       	cmpb   $0x0,(%rdx,%r8,1)
  71b109:	b9 00 00 00 00       	mov    $0x0,%ecx
  71b10e:	0f 85 2c fe ff ff    	jne    71af40 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  71b114:	4d 6b ca 70          	imul   $0x70,%r10,%r9
  71b118:	4a 83 bc 0a b0 00 00 	cmpq   $0x2,0xb0(%rdx,%r9,1)
  71b11f:	00 02 
  71b121:	b9 00 00 00 00       	mov    $0x0,%ecx
  71b126:	0f 84 14 fe ff ff    	je     71af40 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  71b12c:	4a 8d 0c 0a          	lea    (%rdx,%r9,1),%rcx
  71b130:	48 81 c1 b0 00 00 00 	add    $0xb0,%rcx
  71b137:	49 01 d0             	add    %rdx,%r8
  71b13a:	4c 8b 79 18          	mov    0x18(%rcx),%r15
  71b13e:	49 8b 48 08          	mov    0x8(%r8),%rcx
  71b142:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  71b147:	48 3b 34 24          	cmp    (%rsp),%rsi
  71b14b:	75 26                	jne    71b173 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x2e3>
  71b14d:	ba 01 00 00 00       	mov    $0x1,%edx
  71b152:	b9 08 00 00 00       	mov    $0x8,%ecx
  71b157:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  71b15d:	49 89 fe             	mov    %rdi,%r14
  71b160:	48 89 f3             	mov    %rsi,%rbx
  71b163:	e8 58 32 01 00       	call   72e3c0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71b168:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  71b16d:	48 89 de             	mov    %rbx,%rsi
  71b170:	4c 89 f7             	mov    %r14,%rdi
  71b173:	48 89 f1             	mov    %rsi,%rcx
  71b176:	48 c1 e1 04          	shl    $0x4,%rcx
  71b17a:	4c 89 3c 08          	mov    %r15,(%rax,%rcx,1)
  71b17e:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  71b183:	48 89 54 08 08       	mov    %rdx,0x8(%rax,%rcx,1)
  71b188:	48 ff c6             	inc    %rsi
  71b18b:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  71b190:	41 b3 01             	mov    $0x1,%r11b
  71b193:	31 c9                	xor    %ecx,%ecx
  71b195:	e9 a6 fd ff ff       	jmp    71af40 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  71b19a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  71b1a0:	49 89 c8             	mov    %rcx,%r8
  71b1a3:	48 83 f9 08          	cmp    $0x8,%rcx
  71b1a7:	0f 82 34 ff ff ff    	jb     71b0e1 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x251>
  71b1ad:	e9 ee fe ff ff       	jmp    71b0a0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x210>
  71b1b2:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  71b1b9:	48 c7 43 08 08 00 00 	movq   $0x8,0x8(%rbx)
  71b1c0:	00 
  71b1c1:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  71b1c8:	00 
  71b1c9:	eb 15                	jmp    71b1e0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x350>
  71b1cb:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  71b1d0:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  71b1d5:	48 89 43 10          	mov    %rax,0x10(%rbx)
  71b1d9:	0f 10 04 24          	movups (%rsp),%xmm0
  71b1dd:	0f 11 03             	movups %xmm0,(%rbx)
  71b1e0:	48 89 d8             	mov    %rbx,%rax
  71b1e3:	48 83 c4 28          	add    $0x28,%rsp
  71b1e7:	5b                   	pop    %rbx
  71b1e8:	41 5c                	pop    %r12
  71b1ea:	41 5d                	pop    %r13
  71b1ec:	41 5e                	pop    %r14
  71b1ee:	41 5f                	pop    %r15
  71b1f0:	5d                   	pop    %rbp
  71b1f1:	c3                   	ret
  71b1f2:	48 8d 3d 1f 20 3a 00 	lea    0x3a201f(%rip),%rdi        # abd218 <anon.dd9180737c1ef1502723cdb888cc09ab.3.llvm.13290499854095963234>
  71b1f9:	ff 15 01 f7 3c 00    	call   *0x3cf701(%rip)        # aea900 <_DYNAMIC+0x288>
  71b1ff:	eb 0d                	jmp    71b20e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x37e>
  71b201:	48 8d 3d 28 20 3a 00 	lea    0x3a2028(%rip),%rdi        # abd230 <anon.dd9180737c1ef1502723cdb888cc09ab.4.llvm.13290499854095963234>
  71b208:	ff 15 f2 f6 3c 00    	call   *0x3cf6f2(%rip)        # aea900 <_DYNAMIC+0x288>
  71b20e:	0f 0b                	ud2
  71b210:	bf 08 00 00 00       	mov    $0x8,%edi
  71b215:	be 40 00 00 00       	mov    $0x40,%esi
  71b21a:	ff 15 80 f7 3c 00    	call   *0x3cf780(%rip)        # aea9a0 <_DYNAMIC+0x328>
  71b220:	eb 00                	jmp    71b222 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x392>
  71b222:	48 89 c3             	mov    %rax,%rbx
  71b225:	48 8b 34 24          	mov    (%rsp),%rsi
  71b229:	48 85 f6             	test   %rsi,%rsi
  71b22c:	74 14                	je     71b242 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x3b2>
  71b22e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  71b233:	48 c1 e6 04          	shl    $0x4,%rsi
  71b237:	ba 08 00 00 00       	mov    $0x8,%edx
  71b23c:	ff 15 7e f6 3c 00    	call   *0x3cf67e(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71b242:	48 89 df             	mov    %rbx,%rdi
  71b245:	e8 56 fe 39 00       	call   abb0a0 <_Unwind_Resume@plt>
  71b24a:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
