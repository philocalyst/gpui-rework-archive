
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000711260 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_>:
  711260:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
  711264:	48 39 f0             	cmp    %rsi,%rax
  711267:	0f 83 91 00 00 00    	jae    7112fe <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x9e>
  71126d:	48 39 f2             	cmp    %rsi,%rdx
  711270:	75 01                	jne    711273 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x13>
  711272:	c3                   	ret
  711273:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
  711277:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
  71127b:	48 c1 e2 03          	shl    $0x3,%rdx
  71127f:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  711283:	48 8d 14 0f          	lea    (%rdi,%rcx,1),%rdx
  711287:	eb 24                	jmp    7112ad <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x4d>
  711289:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  711290:	49 89 f8             	mov    %rdi,%r8
  711293:	49 89 30             	mov    %rsi,(%r8)
  711296:	0f 28 44 24 e8       	movaps -0x18(%rsp),%xmm0
  71129b:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
  7112a0:	48 83 c2 18          	add    $0x18,%rdx
  7112a4:	48 83 c1 18          	add    $0x18,%rcx
  7112a8:	48 39 c2             	cmp    %rax,%rdx
  7112ab:	74 c5                	je     711272 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x12>
  7112ad:	48 8b 32             	mov    (%rdx),%rsi
  7112b0:	48 3b 72 e8          	cmp    -0x18(%rdx),%rsi
  7112b4:	73 ea                	jae    7112a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x40>
  7112b6:	0f 10 42 08          	movups 0x8(%rdx),%xmm0
  7112ba:	0f 29 44 24 e8       	movaps %xmm0,-0x18(%rsp)
  7112bf:	49 89 c9             	mov    %rcx,%r9
  7112c2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7112c9:	1f 84 00 00 00 00 00 
  7112d0:	4e 8b 44 0f f8       	mov    -0x8(%rdi,%r9,1),%r8
  7112d5:	4e 89 44 0f 10       	mov    %r8,0x10(%rdi,%r9,1)
  7112da:	42 0f 10 44 0f e8    	movups -0x18(%rdi,%r9,1),%xmm0
  7112e0:	42 0f 11 04 0f       	movups %xmm0,(%rdi,%r9,1)
  7112e5:	49 83 f9 18          	cmp    $0x18,%r9
  7112e9:	74 a5                	je     711290 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x30>
  7112eb:	4d 8d 41 e8          	lea    -0x18(%r9),%r8
  7112ef:	4a 3b 74 0f d0       	cmp    -0x30(%rdi,%r9,1),%rsi
  7112f4:	4d 89 c1             	mov    %r8,%r9
  7112f7:	72 d7                	jb     7112d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x70>
  7112f9:	49 01 f8             	add    %rdi,%r8
  7112fc:	eb 95                	jmp    711293 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x33>
  7112fe:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
