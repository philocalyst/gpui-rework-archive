
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000713230 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_>:
  713230:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
  713234:	48 39 f0             	cmp    %rsi,%rax
  713237:	0f 83 91 00 00 00    	jae    7132ce <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_+0x9e>
  71323d:	48 39 f2             	cmp    %rsi,%rdx
  713240:	75 01                	jne    713243 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_+0x13>
  713242:	c3                   	ret
  713243:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
  713247:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
  71324b:	48 c1 e2 03          	shl    $0x3,%rdx
  71324f:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  713253:	48 8d 14 0f          	lea    (%rdi,%rcx,1),%rdx
  713257:	eb 24                	jmp    71327d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_+0x4d>
  713259:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  713260:	49 89 f8             	mov    %rdi,%r8
  713263:	49 89 30             	mov    %rsi,(%r8)
  713266:	0f 28 44 24 e8       	movaps -0x18(%rsp),%xmm0
  71326b:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
  713270:	48 83 c2 18          	add    $0x18,%rdx
  713274:	48 83 c1 18          	add    $0x18,%rcx
  713278:	48 39 c2             	cmp    %rax,%rdx
  71327b:	74 c5                	je     713242 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_+0x12>
  71327d:	48 8b 32             	mov    (%rdx),%rsi
  713280:	48 3b 72 e8          	cmp    -0x18(%rdx),%rsi
  713284:	73 ea                	jae    713270 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_+0x40>
  713286:	0f 10 42 08          	movups 0x8(%rdx),%xmm0
  71328a:	0f 29 44 24 e8       	movaps %xmm0,-0x18(%rsp)
  71328f:	49 89 c9             	mov    %rcx,%r9
  713292:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  713299:	1f 84 00 00 00 00 00 
  7132a0:	4e 8b 44 0f f8       	mov    -0x8(%rdi,%r9,1),%r8
  7132a5:	4e 89 44 0f 10       	mov    %r8,0x10(%rdi,%r9,1)
  7132aa:	42 0f 10 44 0f e8    	movups -0x18(%rdi,%r9,1),%xmm0
  7132b0:	42 0f 11 04 0f       	movups %xmm0,(%rdi,%r9,1)
  7132b5:	49 83 f9 18          	cmp    $0x18,%r9
  7132b9:	74 a5                	je     713260 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_+0x30>
  7132bb:	4d 8d 41 e8          	lea    -0x18(%r9),%r8
  7132bf:	4a 3b 74 0f d0       	cmp    -0x30(%rdi,%r9,1),%rsi
  7132c4:	4d 89 c1             	mov    %r8,%r9
  7132c7:	72 d7                	jb     7132a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_+0x70>
  7132c9:	49 01 f8             	add    %rdi,%r8
  7132cc:	eb 95                	jmp    713263 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_+0x33>
  7132ce:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
