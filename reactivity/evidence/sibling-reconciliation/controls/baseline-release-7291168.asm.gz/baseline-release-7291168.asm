
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006f4120 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>:
  6f4120:	55                   	push   %rbp
  6f4121:	41 57                	push   %r15
  6f4123:	41 56                	push   %r14
  6f4125:	41 55                	push   %r13
  6f4127:	41 54                	push   %r12
  6f4129:	53                   	push   %rbx
  6f412a:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
  6f4131:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
  6f4138:	00 
  6f4139:	49 89 f4             	mov    %rsi,%r12
  6f413c:	48 89 bc 24 e0 00 00 	mov    %rdi,0xe0(%rsp)
  6f4143:	00 
  6f4144:	48 8b 2e             	mov    (%rsi),%rbp
  6f4147:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f414b:	0f b7 9d 32 05 00 00 	movzwl 0x532(%rbp),%ebx
  6f4152:	4a 8d bc ed d8 04 00 	lea    0x4d8(%rbp,%r13,8),%rdi
  6f4159:	00 
  6f415a:	4a 8b 84 ed d8 04 00 	mov    0x4d8(%rbp,%r13,8),%rax
  6f4161:	00 
  6f4162:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6f4167:	4a 8d 34 ed e0 04 00 	lea    0x4e0(,%r13,8),%rsi
  6f416e:	00 
  6f416f:	48 01 ee             	add    %rbp,%rsi
  6f4172:	4d 89 ef             	mov    %r13,%r15
  6f4175:	49 f7 d7             	not    %r15
  6f4178:	49 01 df             	add    %rbx,%r15
  6f417b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f4182:	00 
  6f4183:	4c 8b 35 56 67 3f 00 	mov    0x3f6756(%rip),%r14        # aea8e0 <memmove@GLIBC_2.2.5>
  6f418a:	41 ff d6             	call   *%r14
  6f418d:	4c 89 2c 24          	mov    %r13,(%rsp)
  6f4191:	49 6b c5 70          	imul   $0x70,%r13,%rax
  6f4195:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f4199:	0f 10 44 05 60       	movups 0x60(%rbp,%rax,1),%xmm0
  6f419e:	0f 11 84 24 68 01 00 	movups %xmm0,0x168(%rsp)
  6f41a5:	00 
  6f41a6:	0f 10 44 05 50       	movups 0x50(%rbp,%rax,1),%xmm0
  6f41ab:	0f 11 84 24 58 01 00 	movups %xmm0,0x158(%rsp)
  6f41b2:	00 
  6f41b3:	0f 10 44 05 40       	movups 0x40(%rbp,%rax,1),%xmm0
  6f41b8:	0f 11 84 24 48 01 00 	movups %xmm0,0x148(%rsp)
  6f41bf:	00 
  6f41c0:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f41c5:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f41ca:	0f 10 54 05 20       	movups 0x20(%rbp,%rax,1),%xmm2
  6f41cf:	0f 10 5c 05 30       	movups 0x30(%rbp,%rax,1),%xmm3
  6f41d4:	0f 11 9c 24 38 01 00 	movups %xmm3,0x138(%rsp)
  6f41db:	00 
  6f41dc:	0f 11 94 24 28 01 00 	movups %xmm2,0x128(%rsp)
  6f41e3:	00 
  6f41e4:	0f 11 8c 24 18 01 00 	movups %xmm1,0x118(%rsp)
  6f41eb:	00 
  6f41ec:	0f 11 84 24 08 01 00 	movups %xmm0,0x108(%rsp)
  6f41f3:	00 
  6f41f4:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f41f8:	48 83 c6 70          	add    $0x70,%rsi
  6f41fc:	49 6b d7 70          	imul   $0x70,%r15,%rdx
  6f4200:	41 ff d6             	call   *%r14
  6f4203:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f4206:	66 89 85 32 05 00 00 	mov    %ax,0x532(%rbp)
  6f420d:	4d 8b 7c 24 08       	mov    0x8(%r12),%r15
  6f4212:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f4217:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  6f421e:	00 
  6f421f:	66 83 f8 04          	cmp    $0x4,%ax
  6f4223:	0f 87 65 01 00 00    	ja     6f438e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f4229:	48 8b 85 d0 04 00 00 	mov    0x4d0(%rbp),%rax
  6f4230:	48 85 c0             	test   %rax,%rax
  6f4233:	0f 84 11 01 00 00    	je     6f434a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x22a>
  6f4239:	49 8d 4f 01          	lea    0x1(%r15),%rcx
  6f423d:	0f b7 95 30 05 00 00 	movzwl 0x530(%rbp),%edx
  6f4244:	48 85 d2             	test   %rdx,%rdx
  6f4247:	74 66                	je     6f42af <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x18f>
  6f4249:	48 8b b4 d0 30 05 00 	mov    0x530(%rax,%rdx,8),%rsi
  6f4250:	00 
  6f4251:	48 ff ca             	dec    %rdx
  6f4254:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f4259:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6f425e:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6f4263:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6f4268:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f426f:	00 
  6f4270:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  6f4277:	00 
  6f4278:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f427f:	00 
  6f4280:	0f b7 86 32 05 00 00 	movzwl 0x532(%rsi),%eax
  6f4287:	01 c3                	add    %eax,%ebx
  6f4289:	83 fb 0c             	cmp    $0xc,%ebx
  6f428c:	0f 83 87 00 00 00    	jae    6f4319 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x1f9>
  6f4292:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f4297:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6f429c:	ba 01 00 00 00       	mov    $0x1,%edx
  6f42a1:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f42a5:	e8 f6 86 ff ff       	call   6ec9a0 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1o_5style5StyleEE25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f42aa:	e9 ae 00 00 00       	jmp    6f435d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x23d>
  6f42af:	66 83 b8 32 05 00 00 	cmpw   $0x0,0x532(%rax)
  6f42b6:	00 
  6f42b7:	0f 84 92 07 00 00    	je     6f4a4f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x92f>
  6f42bd:	48 8b 90 40 05 00 00 	mov    0x540(%rax),%rdx
  6f42c4:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f42c9:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6f42ce:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  6f42d5:	00 00 
  6f42d7:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f42dc:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f42e3:	00 
  6f42e4:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
  6f42eb:	00 
  6f42ec:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f42f3:	00 
  6f42f4:	0f b7 82 32 05 00 00 	movzwl 0x532(%rdx),%eax
  6f42fb:	01 c3                	add    %eax,%ebx
  6f42fd:	83 fb 0c             	cmp    $0xc,%ebx
  6f4300:	73 39                	jae    6f433b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x21b>
  6f4302:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f4307:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6f430c:	31 d2                	xor    %edx,%edx
  6f430e:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f4312:	e8 89 86 ff ff       	call   6ec9a0 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1o_5style5StyleEE25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4317:	eb 44                	jmp    6f435d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x23d>
  6f4319:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6f431e:	be 01 00 00 00       	mov    $0x1,%esi
  6f4323:	e8 88 17 00 00       	call   6f5ab0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4328:	48 8b 04 24          	mov    (%rsp),%rax
  6f432c:	48 ff c0             	inc    %rax
  6f432f:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  6f4334:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  6f4339:	eb 1d                	jmp    6f4358 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x238>
  6f433b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6f4340:	be 01 00 00 00       	mov    $0x1,%esi
  6f4345:	e8 a6 1b 00 00       	call   6f5ef0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f434a:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  6f434f:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  6f4354:	48 8b 04 24          	mov    (%rsp),%rax
  6f4358:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6f435d:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6f4362:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6f4367:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f436c:	48 89 04 24          	mov    %rax,(%rsp)
  6f4370:	4c 8b b5 d0 04 00 00 	mov    0x4d0(%rbp),%r14
  6f4377:	4d 85 f6             	test   %r14,%r14
  6f437a:	74 12                	je     6f438e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f437c:	41 0f b7 86 32 05 00 	movzwl 0x532(%r14),%eax
  6f4383:	00 
  6f4384:	66 83 f8 04          	cmp    $0x4,%ax
  6f4388:	0f 86 9b 00 00 00    	jbe    6f4429 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x309>
  6f438e:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6f4395:	00 
  6f4396:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  6f439d:	00 
  6f439e:	48 89 42 70          	mov    %rax,0x70(%rdx)
  6f43a2:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  6f43a9:	00 
  6f43aa:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  6f43ae:	0f 10 84 24 50 01 00 	movups 0x150(%rsp),%xmm0
  6f43b5:	00 
  6f43b6:	0f 11 42 50          	movups %xmm0,0x50(%rdx)
  6f43ba:	0f 10 84 24 40 01 00 	movups 0x140(%rsp),%xmm0
  6f43c1:	00 
  6f43c2:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  6f43c6:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  6f43cd:	00 
  6f43ce:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  6f43d5:	00 
  6f43d6:	0f 10 84 24 10 01 00 	movups 0x110(%rsp),%xmm0
  6f43dd:	00 
  6f43de:	0f 10 8c 24 20 01 00 	movups 0x120(%rsp),%xmm1
  6f43e5:	00 
  6f43e6:	0f 10 94 24 30 01 00 	movups 0x130(%rsp),%xmm2
  6f43ed:	00 
  6f43ee:	0f 11 52 30          	movups %xmm2,0x30(%rdx)
  6f43f2:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
  6f43f6:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f43fa:	48 89 02             	mov    %rax,(%rdx)
  6f43fd:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f4401:	48 89 6a 78          	mov    %rbp,0x78(%rdx)
  6f4405:	4c 89 ba 80 00 00 00 	mov    %r15,0x80(%rdx)
  6f440c:	48 8b 04 24          	mov    (%rsp),%rax
  6f4410:	48 89 82 88 00 00 00 	mov    %rax,0x88(%rdx)
  6f4417:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
  6f441e:	5b                   	pop    %rbx
  6f441f:	41 5c                	pop    %r12
  6f4421:	41 5d                	pop    %r13
  6f4423:	41 5e                	pop    %r14
  6f4425:	41 5f                	pop    %r15
  6f4427:	5d                   	pop    %rbp
  6f4428:	c3                   	ret
  6f4429:	4d 8d 67 01          	lea    0x1(%r15),%r12
  6f442d:	48 8d 0d bc 80 3c 00 	lea    0x3c80bc(%rip),%rcx        # abc4f0 <__frame_dummy_init_array_entry+0x98>
  6f4434:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f4439:	48 8d 0d 08 f2 96 ff 	lea    -0x690df8(%rip),%rcx        # 63648 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f4440:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  6f4445:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
  6f444c:	00 
  6f444d:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
  6f4452:	eb 2c                	jmp    6f4480 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x360>
  6f4454:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f445b:	00 00 00 00 00 
  6f4460:	ba 08 00 00 00       	mov    $0x8,%edx
  6f4465:	4c 89 ef             	mov    %r13,%rdi
  6f4468:	ff 15 52 64 3f 00    	call   *0x3f6452(%rip)        # aea8c0 <_DYNAMIC+0x248>
  6f446e:	41 0f b7 86 32 05 00 	movzwl 0x532(%r14),%eax
  6f4475:	00 
  6f4476:	66 83 f8 04          	cmp    $0x4,%ax
  6f447a:	0f 87 0e ff ff ff    	ja     6f438e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f4480:	4c 89 f1             	mov    %r14,%rcx
  6f4483:	0f b7 c0             	movzwl %ax,%eax
  6f4486:	4d 8b b6 d0 04 00 00 	mov    0x4d0(%r14),%r14
  6f448d:	4d 85 f6             	test   %r14,%r14
  6f4490:	0f 84 06 05 00 00    	je     6f499c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x87c>
  6f4496:	4c 89 e6             	mov    %r12,%rsi
  6f4499:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  6f449e:	44 0f b7 a1 30 05 00 	movzwl 0x530(%rcx),%r12d
  6f44a5:	00 
  6f44a6:	4d 85 e4             	test   %r12,%r12
  6f44a9:	48 89 bc 24 f8 00 00 	mov    %rdi,0xf8(%rsp)
  6f44b0:	00 
  6f44b1:	0f 84 89 00 00 00    	je     6f4540 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x420>
  6f44b7:	4b 8b 9c e6 30 05 00 	mov    0x530(%r14,%r12,8),%rbx
  6f44be:	00 
  6f44bf:	49 ff cc             	dec    %r12
  6f44c2:	4c 89 b4 24 78 01 00 	mov    %r14,0x178(%rsp)
  6f44c9:	00 
  6f44ca:	48 89 bc 24 80 01 00 	mov    %rdi,0x180(%rsp)
  6f44d1:	00 
  6f44d2:	4c 89 a4 24 88 01 00 	mov    %r12,0x188(%rsp)
  6f44d9:	00 
  6f44da:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  6f44e1:	00 
  6f44e2:	48 89 b4 24 98 01 00 	mov    %rsi,0x198(%rsp)
  6f44e9:	00 
  6f44ea:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  6f44f1:	00 
  6f44f2:	48 89 b4 24 a8 01 00 	mov    %rsi,0x1a8(%rsp)
  6f44f9:	00 
  6f44fa:	0f b7 b3 32 05 00 00 	movzwl 0x532(%rbx),%esi
  6f4501:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f4504:	ff c2                	inc    %edx
  6f4506:	83 fa 0c             	cmp    $0xc,%edx
  6f4509:	0f 83 f5 04 00 00    	jae    6f4a04 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x8e4>
  6f450f:	41 0f b7 96 32 05 00 	movzwl 0x532(%r14),%edx
  6f4516:	00 
  6f4517:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f451b:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6f4520:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  6f4525:	48 01 c6             	add    %rax,%rsi
  6f4528:	48 ff c6             	inc    %rsi
  6f452b:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  6f4530:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f4535:	e9 91 00 00 00       	jmp    6f45cb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x4ab>
  6f453a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f4540:	41 0f b7 96 32 05 00 	movzwl 0x532(%r14),%edx
  6f4547:	00 
  6f4548:	66 85 d2             	test   %dx,%dx
  6f454b:	0f 84 fe 04 00 00    	je     6f4a4f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x92f>
  6f4551:	4d 8b 86 40 05 00 00 	mov    0x540(%r14),%r8
  6f4558:	4c 89 b4 24 b0 01 00 	mov    %r14,0x1b0(%rsp)
  6f455f:	00 
  6f4560:	48 89 bc 24 b8 01 00 	mov    %rdi,0x1b8(%rsp)
  6f4567:	00 
  6f4568:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
  6f456f:	00 00 00 00 00 
  6f4574:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
  6f457b:	00 
  6f457c:	48 89 b4 24 d0 01 00 	mov    %rsi,0x1d0(%rsp)
  6f4583:	00 
  6f4584:	4c 89 84 24 d8 01 00 	mov    %r8,0x1d8(%rsp)
  6f458b:	00 
  6f458c:	48 89 b4 24 e0 01 00 	mov    %rsi,0x1e0(%rsp)
  6f4593:	00 
  6f4594:	45 0f b7 88 32 05 00 	movzwl 0x532(%r8),%r9d
  6f459b:	00 
  6f459c:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f45a0:	48 ff c6             	inc    %rsi
  6f45a3:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f45a7:	0f 83 71 04 00 00    	jae    6f4a1e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x8fe>
  6f45ad:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f45b1:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6f45b6:	48 89 cb             	mov    %rcx,%rbx
  6f45b9:	45 31 e4             	xor    %r12d,%r12d
  6f45bc:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f45c1:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  6f45c6:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  6f45cb:	0f b7 c2             	movzwl %dx,%eax
  6f45ce:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  6f45d5:	00 
  6f45d6:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  6f45db:	66 89 b3 32 05 00 00 	mov    %si,0x532(%rbx)
  6f45e2:	4b 8d 3c e6          	lea    (%r14,%r12,8),%rdi
  6f45e6:	48 81 c7 d8 04 00 00 	add    $0x4d8,%rdi
  6f45ed:	4f 8b bc e6 d8 04 00 	mov    0x4d8(%r14,%r12,8),%r15
  6f45f4:	00 
  6f45f5:	4b 8d 34 e6          	lea    (%r14,%r12,8),%rsi
  6f45f9:	48 81 c6 e0 04 00 00 	add    $0x4e0,%rsi
  6f4600:	4c 89 e5             	mov    %r12,%rbp
  6f4603:	48 f7 d5             	not    %rbp
  6f4606:	48 01 c5             	add    %rax,%rbp
  6f4609:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
  6f4610:	00 
  6f4611:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
  6f4618:	00 
  6f4619:	48 8b 05 c0 62 3f 00 	mov    0x3f62c0(%rip),%rax        # aea8e0 <memmove@GLIBC_2.2.5>
  6f4620:	ff d0                	call   *%rax
  6f4622:	4c 8b 6c 24 38       	mov    0x38(%rsp),%r13
  6f4627:	4e 89 bc eb d8 04 00 	mov    %r15,0x4d8(%rbx,%r13,8)
  6f462e:	00 
  6f462f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f4634:	48 8d b0 d8 04 00 00 	lea    0x4d8(%rax),%rsi
  6f463b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f4640:	48 8d bc c3 d8 04 00 	lea    0x4d8(%rbx,%rax,8),%rdi
  6f4647:	00 
  6f4648:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f464d:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f4654:	4c 8b 3d 8d 62 3f 00 	mov    0x3f628d(%rip),%r15        # aea8e8 <memcpy@GLIBC_2.14>
  6f465b:	41 ff d7             	call   *%r15
  6f465e:	49 6b c4 70          	imul   $0x70,%r12,%rax
  6f4662:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f4666:	41 0f 10 44 06 60    	movups 0x60(%r14,%rax,1),%xmm0
  6f466c:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  6f4673:	00 
  6f4674:	41 0f 10 44 06 50    	movups 0x50(%r14,%rax,1),%xmm0
  6f467a:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  6f4681:	00 
  6f4682:	41 0f 10 44 06 40    	movups 0x40(%r14,%rax,1),%xmm0
  6f4688:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f468f:	00 
  6f4690:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f4695:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f469b:	41 0f 10 54 06 20    	movups 0x20(%r14,%rax,1),%xmm2
  6f46a1:	41 0f 10 5c 06 30    	movups 0x30(%r14,%rax,1),%xmm3
  6f46a7:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
  6f46ae:	00 
  6f46af:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
  6f46b6:	00 
  6f46b7:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  6f46bc:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6f46c1:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f46c5:	48 83 c6 70          	add    $0x70,%rsi
  6f46c9:	48 6b d5 70          	imul   $0x70,%rbp,%rdx
  6f46cd:	4c 8b 3d 0c 62 3f 00 	mov    0x3f620c(%rip),%r15        # aea8e0 <memmove@GLIBC_2.2.5>
  6f46d4:	41 ff d7             	call   *%r15
  6f46d7:	49 6b c5 70          	imul   $0x70,%r13,%rax
  6f46db:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6f46e0:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6f46e5:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
  6f46ec:	00 
  6f46ed:	0f 28 9c 24 90 00 00 	movaps 0x90(%rsp),%xmm3
  6f46f4:	00 
  6f46f5:	0f 11 04 03          	movups %xmm0,(%rbx,%rax,1)
  6f46f9:	0f 11 4c 03 10       	movups %xmm1,0x10(%rbx,%rax,1)
  6f46fe:	0f 11 54 03 20       	movups %xmm2,0x20(%rbx,%rax,1)
  6f4703:	0f 11 5c 03 30       	movups %xmm3,0x30(%rbx,%rax,1)
  6f4708:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6f470f:	00 
  6f4710:	0f 11 44 03 40       	movups %xmm0,0x40(%rbx,%rax,1)
  6f4715:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
  6f471c:	00 
  6f471d:	0f 11 44 03 50       	movups %xmm0,0x50(%rbx,%rax,1)
  6f4722:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  6f4729:	00 
  6f472a:	0f 11 44 03 60       	movups %xmm0,0x60(%rbx,%rax,1)
  6f472f:	48 6b 7c 24 10 70    	imul   $0x70,0x10(%rsp),%rdi
  6f4735:	48 01 df             	add    %rbx,%rdi
  6f4738:	48 6b 54 24 18 70    	imul   $0x70,0x18(%rsp),%rdx
  6f473e:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6f4743:	ff 15 9f 61 3f 00    	call   *0x3f619f(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  6f4749:	49 8d 6c 24 01       	lea    0x1(%r12),%rbp
  6f474e:	4b 8d 3c e6          	lea    (%r14,%r12,8),%rdi
  6f4752:	48 81 c7 40 05 00 00 	add    $0x540,%rdi
  6f4759:	4b 8d 34 e6          	lea    (%r14,%r12,8),%rsi
  6f475d:	48 81 c6 48 05 00 00 	add    $0x548,%rsi
  6f4764:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
  6f476b:	00 
  6f476c:	41 ff d7             	call   *%r15
  6f476f:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  6f4776:	00 
  6f4777:	48 39 ee             	cmp    %rbp,%rsi
  6f477a:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6f477f:	0f 86 c5 00 00 00    	jbe    6f484a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f4785:	89 f1                	mov    %esi,%ecx
  6f4787:	29 e9                	sub    %ebp,%ecx
  6f4789:	83 e1 03             	and    $0x3,%ecx
  6f478c:	0f 84 ee 01 00 00    	je     6f4980 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x860>
  6f4792:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f4799:	1f 84 00 00 00 00 00 
  6f47a0:	48 8d 45 01          	lea    0x1(%rbp),%rax
  6f47a4:	49 8b 94 ee 38 05 00 	mov    0x538(%r14,%rbp,8),%rdx
  6f47ab:	00 
  6f47ac:	4c 89 b2 d0 04 00 00 	mov    %r14,0x4d0(%rdx)
  6f47b3:	66 89 aa 30 05 00 00 	mov    %bp,0x530(%rdx)
  6f47ba:	48 89 c5             	mov    %rax,%rbp
  6f47bd:	48 ff c9             	dec    %rcx
  6f47c0:	75 de                	jne    6f47a0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x680>
  6f47c2:	49 f7 dc             	neg    %r12
  6f47c5:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
  6f47c9:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f47cd:	83 f9 03             	cmp    $0x3,%ecx
  6f47d0:	72 78                	jb     6f484a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f47d2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f47d9:	1f 84 00 00 00 00 00 
  6f47e0:	49 8b 8c c6 38 05 00 	mov    0x538(%r14,%rax,8),%rcx
  6f47e7:	00 
  6f47e8:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f47ef:	66 89 81 30 05 00 00 	mov    %ax,0x530(%rcx)
  6f47f6:	49 8b 8c c6 40 05 00 	mov    0x540(%r14,%rax,8),%rcx
  6f47fd:	00 
  6f47fe:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f4805:	8d 50 01             	lea    0x1(%rax),%edx
  6f4808:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f480f:	49 8b 8c c6 48 05 00 	mov    0x548(%r14,%rax,8),%rcx
  6f4816:	00 
  6f4817:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f481e:	8d 50 02             	lea    0x2(%rax),%edx
  6f4821:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f4828:	49 8b 8c c6 50 05 00 	mov    0x550(%r14,%rax,8),%rcx
  6f482f:	00 
  6f4830:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f4837:	8d 50 03             	lea    0x3(%rax),%edx
  6f483a:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f4841:	48 83 c0 04          	add    $0x4,%rax
  6f4845:	48 39 f0             	cmp    %rsi,%rax
  6f4848:	75 96                	jne    6f47e0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x6c0>
  6f484a:	66 41 ff 8e 32 05 00 	decw   0x532(%r14)
  6f4851:	00 
  6f4852:	be 38 05 00 00       	mov    $0x538,%esi
  6f4857:	4c 8b a4 24 f8 00 00 	mov    0xf8(%rsp),%r12
  6f485e:	00 
  6f485f:	49 83 fc 02          	cmp    $0x2,%r12
  6f4863:	48 8b ac 24 d8 00 00 	mov    0xd8(%rsp),%rbp
  6f486a:	00 
  6f486b:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  6f4870:	0f 82 ea fb ff ff    	jb     6f4460 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f4876:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6f487b:	48 ff c2             	inc    %rdx
  6f487e:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6f4883:	48 2b 44 24 38       	sub    0x38(%rsp),%rax
  6f4888:	48 39 c2             	cmp    %rax,%rdx
  6f488b:	0f 85 a7 01 00 00    	jne    6f4a38 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x918>
  6f4891:	48 8d 83 38 05 00 00 	lea    0x538(%rbx),%rax
  6f4898:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  6f489d:	4a 8d 3c f8          	lea    (%rax,%r15,8),%rdi
  6f48a1:	49 8d b5 38 05 00 00 	lea    0x538(%r13),%rsi
  6f48a8:	c1 e2 03             	shl    $0x3,%edx
  6f48ab:	ff 15 37 60 3f 00    	call   *0x3f6037(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  6f48b1:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f48b6:	89 f9                	mov    %edi,%ecx
  6f48b8:	44 29 f9             	sub    %r15d,%ecx
  6f48bb:	ff c1                	inc    %ecx
  6f48bd:	4c 89 f8             	mov    %r15,%rax
  6f48c0:	83 e1 03             	and    $0x3,%ecx
  6f48c3:	74 2d                	je     6f48f2 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7d2>
  6f48c5:	4c 89 fa             	mov    %r15,%rdx
  6f48c8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f48cf:	00 
  6f48d0:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f48d4:	48 8b b4 d3 38 05 00 	mov    0x538(%rbx,%rdx,8),%rsi
  6f48db:	00 
  6f48dc:	48 89 9e d0 04 00 00 	mov    %rbx,0x4d0(%rsi)
  6f48e3:	66 89 96 30 05 00 00 	mov    %dx,0x530(%rsi)
  6f48ea:	48 89 c2             	mov    %rax,%rdx
  6f48ed:	48 ff c9             	dec    %rcx
  6f48f0:	75 de                	jne    6f48d0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7b0>
  6f48f2:	48 89 f9             	mov    %rdi,%rcx
  6f48f5:	4c 29 f9             	sub    %r15,%rcx
  6f48f8:	be 98 05 00 00       	mov    $0x598,%esi
  6f48fd:	83 f9 03             	cmp    $0x3,%ecx
  6f4900:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6f4905:	0f 82 55 fb ff ff    	jb     6f4460 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f490b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f4910:	48 8b 8c c3 38 05 00 	mov    0x538(%rbx,%rax,8),%rcx
  6f4917:	00 
  6f4918:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f491f:	66 89 81 30 05 00 00 	mov    %ax,0x530(%rcx)
  6f4926:	48 8b 8c c3 40 05 00 	mov    0x540(%rbx,%rax,8),%rcx
  6f492d:	00 
  6f492e:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f4935:	8d 50 01             	lea    0x1(%rax),%edx
  6f4938:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f493f:	48 8b 8c c3 48 05 00 	mov    0x548(%rbx,%rax,8),%rcx
  6f4946:	00 
  6f4947:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f494e:	8d 50 02             	lea    0x2(%rax),%edx
  6f4951:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f4958:	48 8b 8c c3 50 05 00 	mov    0x550(%rbx,%rax,8),%rcx
  6f495f:	00 
  6f4960:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f4967:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f496b:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f4972:	48 83 c0 04          	add    $0x4,%rax
  6f4976:	48 39 fa             	cmp    %rdi,%rdx
  6f4979:	75 95                	jne    6f4910 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7f0>
  6f497b:	e9 e0 fa ff ff       	jmp    6f4460 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f4980:	48 89 e8             	mov    %rbp,%rax
  6f4983:	49 f7 dc             	neg    %r12
  6f4986:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
  6f498a:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f498e:	83 f9 03             	cmp    $0x3,%ecx
  6f4991:	0f 83 49 fe ff ff    	jae    6f47e0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x6c0>
  6f4997:	e9 ae fe ff ff       	jmp    6f484a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f499c:	48 85 c0             	test   %rax,%rax
  6f499f:	0f 85 e9 f9 ff ff    	jne    6f438e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f49a5:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
  6f49ac:	00 
  6f49ad:	49 8b 1e             	mov    (%r14),%rbx
  6f49b0:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f49b7:	48 85 db             	test   %rbx,%rbx
  6f49ba:	0f 84 aa 00 00 00    	je     6f4a6a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x94a>
  6f49c0:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f49c4:	48 85 c0             	test   %rax,%rax
  6f49c7:	0f 84 ac 00 00 00    	je     6f4a79 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x959>
  6f49cd:	48 8b 3b             	mov    (%rbx),%rdi
  6f49d0:	48 8b 8f 38 05 00 00 	mov    0x538(%rdi),%rcx
  6f49d7:	48 89 0b             	mov    %rcx,(%rbx)
  6f49da:	48 ff c8             	dec    %rax
  6f49dd:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f49e1:	48 c7 81 d0 04 00 00 	movq   $0x0,0x4d0(%rcx)
  6f49e8:	00 00 00 00 
  6f49ec:	be 98 05 00 00       	mov    $0x598,%esi
  6f49f1:	ba 08 00 00 00       	mov    $0x8,%edx
  6f49f6:	ff 15 c4 5e 3f 00    	call   *0x3f5ec4(%rip)        # aea8c0 <_DYNAMIC+0x248>
  6f49fc:	49 89 1e             	mov    %rbx,(%r14)
  6f49ff:	e9 8a f9 ff ff       	jmp    6f438e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f4a04:	be 05 00 00 00       	mov    $0x5,%esi
  6f4a09:	48 29 c6             	sub    %rax,%rsi
  6f4a0c:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  6f4a13:	00 
  6f4a14:	e8 97 10 00 00       	call   6f5ab0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4a19:	e9 70 f9 ff ff       	jmp    6f438e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f4a1e:	be 05 00 00 00       	mov    $0x5,%esi
  6f4a23:	48 29 c6             	sub    %rax,%rsi
  6f4a26:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
  6f4a2d:	00 
  6f4a2e:	e8 bd 14 00 00       	call   6f5ef0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4a33:	e9 56 f9 ff ff       	jmp    6f438e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f4a38:	be 28 00 00 00       	mov    $0x28,%esi
  6f4a3d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6f4a42:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  6f4a47:	ff 15 ab 5e 3f 00    	call   *0x3f5eab(%rip)        # aea8f8 <_DYNAMIC+0x280>
  6f4a4d:	eb 28                	jmp    6f4a77 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x957>
  6f4a4f:	48 8d 3d 0f ed 96 ff 	lea    -0x6912f1(%rip),%rdi        # 63765 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f4a56:	48 8d 15 9b 7b 3c 00 	lea    0x3c7b9b(%rip),%rdx        # abc5f8 <__frame_dummy_init_array_entry+0x1a0>
  6f4a5d:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f4a62:	ff 15 b0 5e 3f 00    	call   *0x3f5eb0(%rip)        # aea918 <_DYNAMIC+0x2a0>
  6f4a68:	eb 0d                	jmp    6f4a77 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x957>
  6f4a6a:	48 8d 3d 97 7a 3c 00 	lea    0x3c7a97(%rip),%rdi        # abc508 <__frame_dummy_init_array_entry+0xb0>
  6f4a71:	ff 15 89 5e 3f 00    	call   *0x3f5e89(%rip)        # aea900 <_DYNAMIC+0x288>
  6f4a77:	0f 0b                	ud2
  6f4a79:	48 8d 05 58 7a 3c 00 	lea    0x3c7a58(%rip),%rax        # abc4d8 <__frame_dummy_init_array_entry+0x80>
  6f4a80:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f4a85:	be 21 00 00 00       	mov    $0x21,%esi
  6f4a8a:	48 8d 05 96 eb 96 ff 	lea    -0x69146a(%rip),%rax        # 63627 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f4a91:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f4a96:	eb a5                	jmp    6f4a3d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x91d>
  6f4a98:	48 89 c3             	mov    %rax,%rbx
  6f4a9b:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  6f4aa2:	00 
  6f4aa3:	e8 78 28 02 00       	call   717320 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4aa8:	48 89 df             	mov    %rbx,%rdi
  6f4aab:	e8 f0 65 3c 00       	call   abb0a0 <_Unwind_Resume@plt>
  6f4ab0:	ff 15 5a 5e 3f 00    	call   *0x3f5e5a(%rip)        # aea910 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
