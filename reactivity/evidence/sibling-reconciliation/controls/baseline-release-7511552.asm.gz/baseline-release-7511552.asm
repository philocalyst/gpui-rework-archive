
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000729e00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>:
  729e00:	55                   	push   %rbp
  729e01:	41 57                	push   %r15
  729e03:	41 56                	push   %r14
  729e05:	41 55                	push   %r13
  729e07:	41 54                	push   %r12
  729e09:	53                   	push   %rbx
  729e0a:	50                   	push   %rax
  729e0b:	49 89 d6             	mov    %rdx,%r14
  729e0e:	48 89 f3             	mov    %rsi,%rbx
  729e11:	48 83 f9 08          	cmp    $0x8,%rcx
  729e15:	72 55                	jb     729e6c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_+0x6c>
  729e17:	48 c1 e9 03          	shr    $0x3,%rcx
  729e1b:	49 89 cf             	mov    %rcx,%r15
  729e1e:	49 c1 e7 06          	shl    $0x6,%r15
  729e22:	4a 8d 34 3f          	lea    (%rdi,%r15,1),%rsi
  729e26:	4c 6b e1 70          	imul   $0x70,%rcx,%r12
  729e2a:	4a 8d 14 27          	lea    (%rdi,%r12,1),%rdx
  729e2e:	49 89 cd             	mov    %rcx,%r13
  729e31:	e8 ca ff ff ff       	call   729e00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  729e36:	48 89 c5             	mov    %rax,%rbp
  729e39:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
  729e3d:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
  729e41:	48 89 df             	mov    %rbx,%rdi
  729e44:	4c 89 e9             	mov    %r13,%rcx
  729e47:	e8 b4 ff ff ff       	call   729e00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  729e4c:	48 89 c3             	mov    %rax,%rbx
  729e4f:	4d 01 f7             	add    %r14,%r15
  729e52:	4d 01 f4             	add    %r14,%r12
  729e55:	4c 89 f7             	mov    %r14,%rdi
  729e58:	4c 89 fe             	mov    %r15,%rsi
  729e5b:	4c 89 e2             	mov    %r12,%rdx
  729e5e:	4c 89 e9             	mov    %r13,%rcx
  729e61:	e8 9a ff ff ff       	call   729e00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  729e66:	48 89 ef             	mov    %rbp,%rdi
  729e69:	49 89 c6             	mov    %rax,%r14
  729e6c:	48 8b 07             	mov    (%rdi),%rax
  729e6f:	48 8b 0b             	mov    (%rbx),%rcx
  729e72:	48 39 c8             	cmp    %rcx,%rax
  729e75:	0f 92 c2             	setb   %dl
  729e78:	49 8b 36             	mov    (%r14),%rsi
  729e7b:	48 39 f0             	cmp    %rsi,%rax
  729e7e:	0f 92 c0             	setb   %al
  729e81:	30 d0                	xor    %dl,%al
  729e83:	48 39 f1             	cmp    %rsi,%rcx
  729e86:	0f 92 c1             	setb   %cl
  729e89:	30 d1                	xor    %dl,%cl
  729e8b:	49 0f 45 de          	cmovne %r14,%rbx
  729e8f:	84 c0                	test   %al,%al
  729e91:	48 0f 45 df          	cmovne %rdi,%rbx
  729e95:	48 89 d8             	mov    %rbx,%rax
  729e98:	48 83 c4 08          	add    $0x8,%rsp
  729e9c:	5b                   	pop    %rbx
  729e9d:	41 5c                	pop    %r12
  729e9f:	41 5d                	pop    %r13
  729ea1:	41 5e                	pop    %r14
  729ea3:	41 5f                	pop    %r15
  729ea5:	5d                   	pop    %rbp
  729ea6:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
