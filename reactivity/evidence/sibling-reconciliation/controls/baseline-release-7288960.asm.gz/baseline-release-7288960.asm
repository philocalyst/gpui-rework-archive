
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006f3880 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>:
  6f3880:	55                   	push   %rbp
  6f3881:	41 57                	push   %r15
  6f3883:	41 56                	push   %r14
  6f3885:	41 55                	push   %r13
  6f3887:	41 54                	push   %r12
  6f3889:	53                   	push   %rbx
  6f388a:	48 81 ec 58 01 00 00 	sub    $0x158,%rsp
  6f3891:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f3898:	00 
  6f3899:	49 89 f7             	mov    %rsi,%r15
  6f389c:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  6f38a3:	00 
  6f38a4:	48 8b 2e             	mov    (%rsi),%rbp
  6f38a7:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f38ab:	0f b7 9d c2 01 00 00 	movzwl 0x1c2(%rbp),%ebx
  6f38b2:	4a 8d bc ed 68 01 00 	lea    0x168(%rbp,%r13,8),%rdi
  6f38b9:	00 
  6f38ba:	4a 8b 84 ed 68 01 00 	mov    0x168(%rbp,%r13,8),%rax
  6f38c1:	00 
  6f38c2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f38c7:	4a 8d 34 ed 70 01 00 	lea    0x170(,%r13,8),%rsi
  6f38ce:	00 
  6f38cf:	48 01 ee             	add    %rbp,%rsi
  6f38d2:	4d 89 ec             	mov    %r13,%r12
  6f38d5:	49 f7 d4             	not    %r12
  6f38d8:	49 01 dc             	add    %rbx,%r12
  6f38db:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
  6f38e2:	00 
  6f38e3:	4c 8b 35 f6 6f 3f 00 	mov    0x3f6ff6(%rip),%r14        # aea8e0 <memmove@GLIBC_2.2.5>
  6f38ea:	41 ff d6             	call   *%r14
  6f38ed:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  6f38f2:	4c 89 e8             	mov    %r13,%rax
  6f38f5:	48 c1 e0 05          	shl    $0x5,%rax
  6f38f9:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f38fd:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f3902:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f3907:	0f 11 8c 24 e8 00 00 	movups %xmm1,0xe8(%rsp)
  6f390e:	00 
  6f390f:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f3916:	00 
  6f3917:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f391b:	48 83 c6 20          	add    $0x20,%rsi
  6f391f:	49 c1 e4 05          	shl    $0x5,%r12
  6f3923:	4c 89 e2             	mov    %r12,%rdx
  6f3926:	41 ff d6             	call   *%r14
  6f3929:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f392c:	66 89 85 c2 01 00 00 	mov    %ax,0x1c2(%rbp)
  6f3933:	4d 8b 67 08          	mov    0x8(%r15),%r12
  6f3937:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f393c:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f3943:	00 
  6f3944:	66 83 f8 04          	cmp    $0x4,%ax
  6f3948:	0f 87 55 01 00 00    	ja     6f3aa3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f394e:	48 8b 85 60 01 00 00 	mov    0x160(%rbp),%rax
  6f3955:	48 85 c0             	test   %rax,%rax
  6f3958:	0f 84 03 01 00 00    	je     6f3a61 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1e1>
  6f395e:	49 8d 4c 24 01       	lea    0x1(%r12),%rcx
  6f3963:	0f b7 95 c0 01 00 00 	movzwl 0x1c0(%rbp),%edx
  6f396a:	48 85 d2             	test   %rdx,%rdx
  6f396d:	74 5e                	je     6f39cd <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x14d>
  6f396f:	48 8b b4 d0 c0 01 00 	mov    0x1c0(%rax,%rdx,8),%rsi
  6f3976:	00 
  6f3977:	48 ff ca             	dec    %rdx
  6f397a:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f397f:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f3984:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  6f3989:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  6f398e:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
  6f3993:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f3998:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  6f399d:	0f b7 86 c2 01 00 00 	movzwl 0x1c2(%rsi),%eax
  6f39a4:	01 c3                	add    %eax,%ebx
  6f39a6:	83 fb 0c             	cmp    $0xc,%ebx
  6f39a9:	0f 83 80 00 00 00    	jae    6f3a2f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1af>
  6f39af:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  6f39b4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  6f39b9:	ba 01 00 00 00       	mov    $0x1,%edx
  6f39be:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f39c3:	e8 a8 8b ff ff       	call   6ec570 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f39c8:	e9 a8 00 00 00       	jmp    6f3a75 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f5>
  6f39cd:	66 83 b8 c2 01 00 00 	cmpw   $0x0,0x1c2(%rax)
  6f39d4:	00 
  6f39d5:	0f 84 d4 06 00 00    	je     6f40af <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x82f>
  6f39db:	48 8b 90 d0 01 00 00 	mov    0x1d0(%rax),%rdx
  6f39e2:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f39e7:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f39ec:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6f39f3:	00 00 
  6f39f5:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6f39fa:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
  6f39ff:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
  6f3a04:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  6f3a09:	0f b7 82 c2 01 00 00 	movzwl 0x1c2(%rdx),%eax
  6f3a10:	01 c3                	add    %eax,%ebx
  6f3a12:	83 fb 0c             	cmp    $0xc,%ebx
  6f3a15:	73 3b                	jae    6f3a52 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1d2>
  6f3a17:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  6f3a1c:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  6f3a21:	31 d2                	xor    %edx,%edx
  6f3a23:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f3a28:	e8 43 8b ff ff       	call   6ec570 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f3a2d:	eb 46                	jmp    6f3a75 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f5>
  6f3a2f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f3a34:	be 01 00 00 00       	mov    $0x1,%esi
  6f3a39:	e8 b2 19 00 00       	call   6f53f0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f3a3e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f3a43:	48 ff c0             	inc    %rax
  6f3a46:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
  6f3a4b:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  6f3a50:	eb 1e                	jmp    6f3a70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f0>
  6f3a52:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f3a57:	be 01 00 00 00       	mov    $0x1,%esi
  6f3a5c:	e8 cf 1c 00 00       	call   6f5730 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f3a61:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
  6f3a66:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  6f3a6b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f3a70:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f3a75:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
  6f3a7a:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  6f3a7f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f3a84:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6f3a89:	4c 8b b5 60 01 00 00 	mov    0x160(%rbp),%r14
  6f3a90:	4d 85 f6             	test   %r14,%r14
  6f3a93:	74 0e                	je     6f3aa3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f3a95:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f3a9c:	00 
  6f3a9d:	66 83 f8 04          	cmp    $0x4,%ax
  6f3aa1:	76 5a                	jbe    6f3afd <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x27d>
  6f3aa3:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  6f3aaa:	00 
  6f3aab:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  6f3ab2:	00 
  6f3ab3:	48 89 42 20          	mov    %rax,0x20(%rdx)
  6f3ab7:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6f3abe:	00 
  6f3abf:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  6f3ac6:	00 
  6f3ac7:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6f3ace:	00 
  6f3acf:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f3ad3:	48 89 02             	mov    %rax,(%rdx)
  6f3ad6:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f3ada:	48 89 6a 28          	mov    %rbp,0x28(%rdx)
  6f3ade:	4c 89 62 30          	mov    %r12,0x30(%rdx)
  6f3ae2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f3ae7:	48 89 42 38          	mov    %rax,0x38(%rdx)
  6f3aeb:	48 81 c4 58 01 00 00 	add    $0x158,%rsp
  6f3af2:	5b                   	pop    %rbx
  6f3af3:	41 5c                	pop    %r12
  6f3af5:	41 5d                	pop    %r13
  6f3af7:	41 5e                	pop    %r14
  6f3af9:	41 5f                	pop    %r15
  6f3afb:	5d                   	pop    %rbp
  6f3afc:	c3                   	ret
  6f3afd:	4d 8d 6c 24 01       	lea    0x1(%r12),%r13
  6f3b02:	48 8d 0d e7 89 3c 00 	lea    0x3c89e7(%rip),%rcx        # abc4f0 <__frame_dummy_init_array_entry+0x98>
  6f3b09:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6f3b10:	00 
  6f3b11:	48 8d 0d 30 fb 96 ff 	lea    -0x6904d0(%rip),%rcx        # 63648 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f3b18:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  6f3b1d:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  6f3b24:	00 
  6f3b25:	4c 89 a4 24 88 00 00 	mov    %r12,0x88(%rsp)
  6f3b2c:	00 
  6f3b2d:	eb 21                	jmp    6f3b50 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2d0>
  6f3b2f:	90                   	nop
  6f3b30:	ba 08 00 00 00       	mov    $0x8,%edx
  6f3b35:	4c 89 ff             	mov    %r15,%rdi
  6f3b38:	ff 15 82 6d 3f 00    	call   *0x3f6d82(%rip)        # aea8c0 <_DYNAMIC+0x248>
  6f3b3e:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f3b45:	00 
  6f3b46:	66 83 f8 04          	cmp    $0x4,%ax
  6f3b4a:	0f 87 53 ff ff ff    	ja     6f3aa3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f3b50:	4c 89 f1             	mov    %r14,%rcx
  6f3b53:	0f b7 c0             	movzwl %ax,%eax
  6f3b56:	4d 8b b6 60 01 00 00 	mov    0x160(%r14),%r14
  6f3b5d:	4d 85 f6             	test   %r14,%r14
  6f3b60:	0f 84 96 04 00 00    	je     6f3ffc <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x77c>
  6f3b66:	4c 89 ee             	mov    %r13,%rsi
  6f3b69:	49 8d 7d 01          	lea    0x1(%r13),%rdi
  6f3b6d:	44 0f b7 b9 c0 01 00 	movzwl 0x1c0(%rcx),%r15d
  6f3b74:	00 
  6f3b75:	4d 85 ff             	test   %r15,%r15
  6f3b78:	48 89 bc 24 c8 00 00 	mov    %rdi,0xc8(%rsp)
  6f3b7f:	00 
  6f3b80:	0f 84 8a 00 00 00    	je     6f3c10 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x390>
  6f3b86:	4b 8b 9c fe c0 01 00 	mov    0x1c0(%r14,%r15,8),%rbx
  6f3b8d:	00 
  6f3b8e:	49 ff cf             	dec    %r15
  6f3b91:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  6f3b98:	00 
  6f3b99:	48 89 bc 24 00 01 00 	mov    %rdi,0x100(%rsp)
  6f3ba0:	00 
  6f3ba1:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
  6f3ba8:	00 
  6f3ba9:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
  6f3bb0:	00 
  6f3bb1:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
  6f3bb8:	00 
  6f3bb9:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6f3bc0:	00 
  6f3bc1:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
  6f3bc8:	00 
  6f3bc9:	0f b7 b3 c2 01 00 00 	movzwl 0x1c2(%rbx),%esi
  6f3bd0:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f3bd3:	ff c2                	inc    %edx
  6f3bd5:	83 fa 0c             	cmp    $0xc,%edx
  6f3bd8:	0f 83 86 04 00 00    	jae    6f4064 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x7e4>
  6f3bde:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f3be5:	00 
  6f3be6:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f3bea:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  6f3bef:	48 89 f5             	mov    %rsi,%rbp
  6f3bf2:	48 01 c6             	add    %rax,%rsi
  6f3bf5:	48 ff c6             	inc    %rsi
  6f3bf8:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6f3bfd:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f3c02:	e9 7d 00 00 00       	jmp    6f3c84 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x404>
  6f3c07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f3c0e:	00 00 
  6f3c10:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f3c17:	00 
  6f3c18:	66 85 d2             	test   %dx,%dx
  6f3c1b:	0f 84 8e 04 00 00    	je     6f40af <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x82f>
  6f3c21:	4d 8b 86 d0 01 00 00 	mov    0x1d0(%r14),%r8
  6f3c28:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
  6f3c2d:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  6f3c32:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6f3c39:	00 00 
  6f3c3b:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6f3c40:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6f3c45:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
  6f3c4a:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6f3c4f:	45 0f b7 88 c2 01 00 	movzwl 0x1c2(%r8),%r9d
  6f3c56:	00 
  6f3c57:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f3c5b:	48 ff c6             	inc    %rsi
  6f3c5e:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f3c62:	0f 83 16 04 00 00    	jae    6f407e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x7fe>
  6f3c68:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f3c6c:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  6f3c71:	48 89 cb             	mov    %rcx,%rbx
  6f3c74:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  6f3c79:	45 31 ff             	xor    %r15d,%r15d
  6f3c7c:	48 89 c5             	mov    %rax,%rbp
  6f3c7f:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  6f3c84:	0f b7 c2             	movzwl %dx,%eax
  6f3c87:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f3c8e:	00 
  6f3c8f:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
  6f3c96:	00 
  6f3c97:	66 89 b3 c2 01 00 00 	mov    %si,0x1c2(%rbx)
  6f3c9e:	4b 8d 3c fe          	lea    (%r14,%r15,8),%rdi
  6f3ca2:	48 81 c7 68 01 00 00 	add    $0x168,%rdi
  6f3ca9:	4f 8b ac fe 68 01 00 	mov    0x168(%r14,%r15,8),%r13
  6f3cb0:	00 
  6f3cb1:	4b 8d 34 fe          	lea    (%r14,%r15,8),%rsi
  6f3cb5:	48 81 c6 70 01 00 00 	add    $0x170,%rsi
  6f3cbc:	4d 89 fc             	mov    %r15,%r12
  6f3cbf:	49 f7 d4             	not    %r12
  6f3cc2:	49 01 c4             	add    %rax,%r12
  6f3cc5:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
  6f3ccc:	00 
  6f3ccd:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  6f3cd4:	00 
  6f3cd5:	48 8b 05 04 6c 3f 00 	mov    0x3f6c04(%rip),%rax        # aea8e0 <memmove@GLIBC_2.2.5>
  6f3cdc:	ff d0                	call   *%rax
  6f3cde:	4c 89 ac eb 68 01 00 	mov    %r13,0x168(%rbx,%rbp,8)
  6f3ce5:	00 
  6f3ce6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f3ceb:	48 8d b0 68 01 00 00 	lea    0x168(%rax),%rsi
  6f3cf2:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f3cf7:	48 8d bc c3 68 01 00 	lea    0x168(%rbx,%rax,8),%rdi
  6f3cfe:	00 
  6f3cff:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f3d04:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f3d0b:	4c 8b 2d d6 6b 3f 00 	mov    0x3f6bd6(%rip),%r13        # aea8e8 <memcpy@GLIBC_2.14>
  6f3d12:	41 ff d5             	call   *%r13
  6f3d15:	4c 89 f8             	mov    %r15,%rax
  6f3d18:	48 c1 e0 05          	shl    $0x5,%rax
  6f3d1c:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f3d20:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f3d25:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f3d2b:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  6f3d32:	00 
  6f3d33:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  6f3d3a:	00 
  6f3d3b:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f3d3f:	48 83 c6 20          	add    $0x20,%rsi
  6f3d43:	49 c1 e4 05          	shl    $0x5,%r12
  6f3d47:	4c 89 e2             	mov    %r12,%rdx
  6f3d4a:	4c 8b 2d 8f 6b 3f 00 	mov    0x3f6b8f(%rip),%r13        # aea8e0 <memmove@GLIBC_2.2.5>
  6f3d51:	41 ff d5             	call   *%r13
  6f3d54:	48 89 ac 24 b0 00 00 	mov    %rbp,0xb0(%rsp)
  6f3d5b:	00 
  6f3d5c:	c1 e5 05             	shl    $0x5,%ebp
  6f3d5f:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  6f3d66:	00 
  6f3d67:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
  6f3d6e:	00 
  6f3d6f:	0f 11 04 2b          	movups %xmm0,(%rbx,%rbp,1)
  6f3d73:	0f 11 4c 2b 10       	movups %xmm1,0x10(%rbx,%rbp,1)
  6f3d78:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6f3d7d:	c1 e7 05             	shl    $0x5,%edi
  6f3d80:	48 01 df             	add    %rbx,%rdi
  6f3d83:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f3d88:	c1 e2 05             	shl    $0x5,%edx
  6f3d8b:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f3d90:	ff 15 52 6b 3f 00    	call   *0x3f6b52(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  6f3d96:	4d 8d 67 01          	lea    0x1(%r15),%r12
  6f3d9a:	4b 8d 3c fe          	lea    (%r14,%r15,8),%rdi
  6f3d9e:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6f3da5:	4b 8d 34 fe          	lea    (%r14,%r15,8),%rsi
  6f3da9:	48 81 c6 d8 01 00 00 	add    $0x1d8,%rsi
  6f3db0:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  6f3db7:	00 
  6f3db8:	41 ff d5             	call   *%r13
  6f3dbb:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6f3dc2:	00 
  6f3dc3:	4c 39 e6             	cmp    %r12,%rsi
  6f3dc6:	4c 8b ac 24 c8 00 00 	mov    0xc8(%rsp),%r13
  6f3dcd:	00 
  6f3dce:	0f 86 c6 00 00 00    	jbe    6f3e9a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f3dd4:	89 f1                	mov    %esi,%ecx
  6f3dd6:	44 29 e1             	sub    %r12d,%ecx
  6f3dd9:	83 e1 03             	and    $0x3,%ecx
  6f3ddc:	0f 84 fe 01 00 00    	je     6f3fe0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x760>
  6f3de2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f3de9:	1f 84 00 00 00 00 00 
  6f3df0:	49 8d 44 24 01       	lea    0x1(%r12),%rax
  6f3df5:	4b 8b 94 e6 c8 01 00 	mov    0x1c8(%r14,%r12,8),%rdx
  6f3dfc:	00 
  6f3dfd:	4c 89 b2 60 01 00 00 	mov    %r14,0x160(%rdx)
  6f3e04:	66 44 89 a2 c0 01 00 	mov    %r12w,0x1c0(%rdx)
  6f3e0b:	00 
  6f3e0c:	49 89 c4             	mov    %rax,%r12
  6f3e0f:	48 ff c9             	dec    %rcx
  6f3e12:	75 dc                	jne    6f3df0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x570>
  6f3e14:	49 f7 df             	neg    %r15
  6f3e17:	4a 8d 0c 3e          	lea    (%rsi,%r15,1),%rcx
  6f3e1b:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f3e1f:	83 f9 03             	cmp    $0x3,%ecx
  6f3e22:	72 76                	jb     6f3e9a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f3e24:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f3e2b:	00 00 00 00 00 
  6f3e30:	49 8b 8c c6 c8 01 00 	mov    0x1c8(%r14,%rax,8),%rcx
  6f3e37:	00 
  6f3e38:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f3e3f:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f3e46:	49 8b 8c c6 d0 01 00 	mov    0x1d0(%r14,%rax,8),%rcx
  6f3e4d:	00 
  6f3e4e:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f3e55:	8d 50 01             	lea    0x1(%rax),%edx
  6f3e58:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f3e5f:	49 8b 8c c6 d8 01 00 	mov    0x1d8(%r14,%rax,8),%rcx
  6f3e66:	00 
  6f3e67:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f3e6e:	8d 50 02             	lea    0x2(%rax),%edx
  6f3e71:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f3e78:	49 8b 8c c6 e0 01 00 	mov    0x1e0(%r14,%rax,8),%rcx
  6f3e7f:	00 
  6f3e80:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f3e87:	8d 50 03             	lea    0x3(%rax),%edx
  6f3e8a:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f3e91:	48 83 c0 04          	add    $0x4,%rax
  6f3e95:	48 39 f0             	cmp    %rsi,%rax
  6f3e98:	75 96                	jne    6f3e30 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x5b0>
  6f3e9a:	66 41 ff 8e c2 01 00 	decw   0x1c2(%r14)
  6f3ea1:	00 
  6f3ea2:	be c8 01 00 00       	mov    $0x1c8,%esi
  6f3ea7:	49 83 fd 02          	cmp    $0x2,%r13
  6f3eab:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  6f3eb2:	00 
  6f3eb3:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
  6f3eba:	00 
  6f3ebb:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  6f3ec0:	0f 82 6a fc ff ff    	jb     6f3b30 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f3ec6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f3ecb:	48 ff c2             	inc    %rdx
  6f3ece:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f3ed5:	00 
  6f3ed6:	48 2b 84 24 b0 00 00 	sub    0xb0(%rsp),%rax
  6f3edd:	00 
  6f3ede:	48 39 c2             	cmp    %rax,%rdx
  6f3ee1:	0f 85 ae 01 00 00    	jne    6f4095 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x815>
  6f3ee7:	48 8d 83 c8 01 00 00 	lea    0x1c8(%rbx),%rax
  6f3eee:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  6f3ef3:	4a 8d 3c e0          	lea    (%rax,%r12,8),%rdi
  6f3ef7:	49 8d b7 c8 01 00 00 	lea    0x1c8(%r15),%rsi
  6f3efe:	c1 e2 03             	shl    $0x3,%edx
  6f3f01:	ff 15 e1 69 3f 00    	call   *0x3f69e1(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  6f3f07:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  6f3f0e:	00 
  6f3f0f:	89 f9                	mov    %edi,%ecx
  6f3f11:	44 29 e1             	sub    %r12d,%ecx
  6f3f14:	ff c1                	inc    %ecx
  6f3f16:	4c 89 e0             	mov    %r12,%rax
  6f3f19:	83 e1 03             	and    $0x3,%ecx
  6f3f1c:	74 34                	je     6f3f52 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6d2>
  6f3f1e:	4c 89 e2             	mov    %r12,%rdx
  6f3f21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f3f28:	0f 1f 84 00 00 00 00 
  6f3f2f:	00 
  6f3f30:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f3f34:	48 8b b4 d3 c8 01 00 	mov    0x1c8(%rbx,%rdx,8),%rsi
  6f3f3b:	00 
  6f3f3c:	48 89 9e 60 01 00 00 	mov    %rbx,0x160(%rsi)
  6f3f43:	66 89 96 c0 01 00 00 	mov    %dx,0x1c0(%rsi)
  6f3f4a:	48 89 c2             	mov    %rax,%rdx
  6f3f4d:	48 ff c9             	dec    %rcx
  6f3f50:	75 de                	jne    6f3f30 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6b0>
  6f3f52:	48 89 f9             	mov    %rdi,%rcx
  6f3f55:	4c 29 e1             	sub    %r12,%rcx
  6f3f58:	be 28 02 00 00       	mov    $0x228,%esi
  6f3f5d:	83 f9 03             	cmp    $0x3,%ecx
  6f3f60:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
  6f3f67:	00 
  6f3f68:	0f 82 c2 fb ff ff    	jb     6f3b30 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f3f6e:	66 90                	xchg   %ax,%ax
  6f3f70:	48 8b 8c c3 c8 01 00 	mov    0x1c8(%rbx,%rax,8),%rcx
  6f3f77:	00 
  6f3f78:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f3f7f:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f3f86:	48 8b 8c c3 d0 01 00 	mov    0x1d0(%rbx,%rax,8),%rcx
  6f3f8d:	00 
  6f3f8e:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f3f95:	8d 50 01             	lea    0x1(%rax),%edx
  6f3f98:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f3f9f:	48 8b 8c c3 d8 01 00 	mov    0x1d8(%rbx,%rax,8),%rcx
  6f3fa6:	00 
  6f3fa7:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f3fae:	8d 50 02             	lea    0x2(%rax),%edx
  6f3fb1:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f3fb8:	48 8b 8c c3 e0 01 00 	mov    0x1e0(%rbx,%rax,8),%rcx
  6f3fbf:	00 
  6f3fc0:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f3fc7:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f3fcb:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f3fd2:	48 83 c0 04          	add    $0x4,%rax
  6f3fd6:	48 39 fa             	cmp    %rdi,%rdx
  6f3fd9:	75 95                	jne    6f3f70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6f0>
  6f3fdb:	e9 50 fb ff ff       	jmp    6f3b30 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f3fe0:	4c 89 e0             	mov    %r12,%rax
  6f3fe3:	49 f7 df             	neg    %r15
  6f3fe6:	4a 8d 0c 3e          	lea    (%rsi,%r15,1),%rcx
  6f3fea:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f3fee:	83 f9 03             	cmp    $0x3,%ecx
  6f3ff1:	0f 83 39 fe ff ff    	jae    6f3e30 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x5b0>
  6f3ff7:	e9 9e fe ff ff       	jmp    6f3e9a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f3ffc:	48 85 c0             	test   %rax,%rax
  6f3fff:	0f 85 9e fa ff ff    	jne    6f3aa3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f4005:	4c 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14
  6f400c:	00 
  6f400d:	49 8b 1e             	mov    (%r14),%rbx
  6f4010:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f4017:	48 85 db             	test   %rbx,%rbx
  6f401a:	0f 84 aa 00 00 00    	je     6f40ca <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x84a>
  6f4020:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f4024:	48 85 c0             	test   %rax,%rax
  6f4027:	0f 84 ac 00 00 00    	je     6f40d9 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x859>
  6f402d:	48 8b 3b             	mov    (%rbx),%rdi
  6f4030:	48 8b 8f c8 01 00 00 	mov    0x1c8(%rdi),%rcx
  6f4037:	48 89 0b             	mov    %rcx,(%rbx)
  6f403a:	48 ff c8             	dec    %rax
  6f403d:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f4041:	48 c7 81 60 01 00 00 	movq   $0x0,0x160(%rcx)
  6f4048:	00 00 00 00 
  6f404c:	be 28 02 00 00       	mov    $0x228,%esi
  6f4051:	ba 08 00 00 00       	mov    $0x8,%edx
  6f4056:	ff 15 64 68 3f 00    	call   *0x3f6864(%rip)        # aea8c0 <_DYNAMIC+0x248>
  6f405c:	49 89 1e             	mov    %rbx,(%r14)
  6f405f:	e9 3f fa ff ff       	jmp    6f3aa3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f4064:	be 05 00 00 00       	mov    $0x5,%esi
  6f4069:	48 29 c6             	sub    %rax,%rsi
  6f406c:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  6f4073:	00 
  6f4074:	e8 77 13 00 00       	call   6f53f0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4079:	e9 25 fa ff ff       	jmp    6f3aa3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f407e:	be 05 00 00 00       	mov    $0x5,%esi
  6f4083:	48 29 c6             	sub    %rax,%rsi
  6f4086:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f408b:	e8 a0 16 00 00       	call   6f5730 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4090:	e9 0e fa ff ff       	jmp    6f3aa3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f4095:	be 28 00 00 00       	mov    $0x28,%esi
  6f409a:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  6f409f:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  6f40a6:	00 
  6f40a7:	ff 15 4b 68 3f 00    	call   *0x3f684b(%rip)        # aea8f8 <_DYNAMIC+0x280>
  6f40ad:	eb 28                	jmp    6f40d7 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x857>
  6f40af:	48 8d 3d af f6 96 ff 	lea    -0x690951(%rip),%rdi        # 63765 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f40b6:	48 8d 15 3b 85 3c 00 	lea    0x3c853b(%rip),%rdx        # abc5f8 <__frame_dummy_init_array_entry+0x1a0>
  6f40bd:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f40c2:	ff 15 50 68 3f 00    	call   *0x3f6850(%rip)        # aea918 <_DYNAMIC+0x2a0>
  6f40c8:	eb 0d                	jmp    6f40d7 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x857>
  6f40ca:	48 8d 3d 37 84 3c 00 	lea    0x3c8437(%rip),%rdi        # abc508 <__frame_dummy_init_array_entry+0xb0>
  6f40d1:	ff 15 29 68 3f 00    	call   *0x3f6829(%rip)        # aea900 <_DYNAMIC+0x288>
  6f40d7:	0f 0b                	ud2
  6f40d9:	48 8d 05 f8 83 3c 00 	lea    0x3c83f8(%rip),%rax        # abc4d8 <__frame_dummy_init_array_entry+0x80>
  6f40e0:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f40e7:	00 
  6f40e8:	be 21 00 00 00       	mov    $0x21,%esi
  6f40ed:	48 8d 05 33 f5 96 ff 	lea    -0x690acd(%rip),%rax        # 63627 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f40f4:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  6f40f9:	eb 9f                	jmp    6f409a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x81a>
  6f40fb:	48 89 c3             	mov    %rax,%rbx
  6f40fe:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  6f4105:	00 
  6f4106:	e8 15 32 02 00       	call   717320 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f410b:	48 89 df             	mov    %rbx,%rdi
  6f410e:	e8 8d 6f 3c 00       	call   abb0a0 <_Unwind_Resume@plt>
  6f4113:	ff 15 f7 67 3f 00    	call   *0x3f67f7(%rip)        # aea910 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
