
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000071d580 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_>:
  71d580:	55                   	push   %rbp
  71d581:	41 57                	push   %r15
  71d583:	41 56                	push   %r14
  71d585:	41 55                	push   %r13
  71d587:	41 54                	push   %r12
  71d589:	53                   	push   %rbx
  71d58a:	48 81 ec 38 07 00 00 	sub    $0x738,%rsp
  71d591:	4c 89 cb             	mov    %r9,%rbx
  71d594:	4c 89 84 24 08 03 00 	mov    %r8,0x308(%rsp)
  71d59b:	00 
  71d59c:	48 89 8c 24 00 03 00 	mov    %rcx,0x300(%rsp)
  71d5a3:	00 
  71d5a4:	48 89 94 24 20 03 00 	mov    %rdx,0x320(%rsp)
  71d5ab:	00 
  71d5ac:	49 89 f7             	mov    %rsi,%r15
  71d5af:	48 89 7c 24 68       	mov    %rdi,0x68(%rsp)
  71d5b4:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
  71d5bb:	00 00 00 00 00 
  71d5c0:	48 c7 84 24 f8 00 00 	movq   $0x8,0xf8(%rsp)
  71d5c7:	00 08 00 00 00 
  71d5cc:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
  71d5d3:	00 00 00 00 00 
  71d5d8:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
  71d5df:	00 00 
  71d5e1:	48 c7 84 24 80 00 00 	movq   $0x8,0x80(%rsp)
  71d5e8:	00 08 00 00 00 
  71d5ed:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  71d5f4:	00 00 00 00 00 
  71d5f9:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
  71d600:	00 00 00 00 00 
  71d605:	48 c7 84 24 18 01 00 	movq   $0x8,0x118(%rsp)
  71d60c:	00 08 00 00 00 
  71d611:	48 c7 84 24 20 01 00 	movq   $0x0,0x120(%rsp)
  71d618:	00 00 00 00 00 
  71d61d:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
  71d624:	00 00 00 00 00 
  71d629:	48 c7 84 24 30 01 00 	movq   $0x8,0x130(%rsp)
  71d630:	00 08 00 00 00 
  71d635:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  71d63c:	00 00 00 00 00 
  71d641:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  71d648:	00 00 00 00 00 
  71d64d:	48 c7 84 24 48 01 00 	movq   $0x8,0x148(%rsp)
  71d654:	00 08 00 00 00 
  71d659:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
  71d660:	00 00 00 00 00 
  71d665:	48 c7 84 24 58 01 00 	movq   $0x0,0x158(%rsp)
  71d66c:	00 00 00 00 00 
  71d671:	48 c7 84 24 60 01 00 	movq   $0x8,0x160(%rsp)
  71d678:	00 08 00 00 00 
  71d67d:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  71d684:	00 00 00 00 00 
  71d689:	ff 15 49 d2 3c 00    	call   *0x3cd249(%rip)        # aea8d8 <_DYNAMIC+0x260>
  71d68f:	bf e0 00 00 00       	mov    $0xe0,%edi
  71d694:	be 08 00 00 00       	mov    $0x8,%esi
  71d699:	ff 15 19 d2 3c 00    	call   *0x3cd219(%rip)        # aea8b8 <_DYNAMIC+0x240>
  71d69f:	49 89 c5             	mov    %rax,%r13
  71d6a2:	48 85 c0             	test   %rax,%rax
  71d6a5:	0f 84 7b 1c 00 00    	je     71f326 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1da6>
  71d6ab:	49 be 93 24 49 92 24 	movabs $0x92492492492493,%r14
  71d6b2:	49 92 00 
  71d6b5:	ba b0 00 00 00       	mov    $0xb0,%edx
  71d6ba:	4c 89 ef             	mov    %r13,%rdi
  71d6bd:	4c 89 fe             	mov    %r15,%rsi
  71d6c0:	ff 15 22 d2 3c 00    	call   *0x3cd222(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  71d6c6:	41 c7 85 b0 00 00 00 	movl   $0x0,0xb0(%r13)
  71d6cd:	00 00 00 00 
  71d6d1:	49 c7 85 b8 00 00 00 	movq   $0x0,0xb8(%r13)
  71d6d8:	00 00 00 00 
  71d6dc:	48 c7 84 24 b0 00 00 	movq   $0x1,0xb0(%rsp)
  71d6e3:	00 01 00 00 00 
  71d6e8:	4c 89 ac 24 b8 00 00 	mov    %r13,0xb8(%rsp)
  71d6ef:	00 
  71d6f0:	48 8b 03             	mov    (%rbx),%rax
  71d6f3:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  71d6fa:	00 
  71d6fb:	48 8b 43 08          	mov    0x8(%rbx),%rax
  71d6ff:	48 89 84 24 e0 02 00 	mov    %rax,0x2e0(%rsp)
  71d706:	00 
  71d707:	48 8b 43 10          	mov    0x10(%rbx),%rax
  71d70b:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  71d712:	00 
  71d713:	4c 8b 63 18          	mov    0x18(%rbx),%r12
  71d717:	48 8b 43 20          	mov    0x20(%rbx),%rax
  71d71b:	49 83 c4 e8          	add    $0xffffffffffffffe8,%r12
  71d71f:	48 c1 e0 03          	shl    $0x3,%rax
  71d723:	4c 89 fa             	mov    %r15,%rdx
  71d726:	4c 8d 3c 40          	lea    (%rax,%rax,2),%r15
  71d72a:	b8 01 00 00 00       	mov    $0x1,%eax
  71d72f:	48 8d 9c 24 88 06 00 	lea    0x688(%rsp),%rbx
  71d736:	00 
  71d737:	4c 8b 05 aa d1 3c 00 	mov    0x3cd1aa(%rip),%r8        # aea8e8 <memcpy@GLIBC_2.14>
  71d73e:	49 ff ce             	dec    %r14
  71d741:	4c 89 b4 24 f0 02 00 	mov    %r14,0x2f0(%rsp)
  71d748:	00 
  71d749:	48 8d ac 24 30 04 00 	lea    0x430(%rsp),%rbp
  71d750:	00 
  71d751:	48 89 14 24          	mov    %rdx,(%rsp)
  71d755:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  71d75a:	4c 89 a4 24 18 03 00 	mov    %r12,0x318(%rsp)
  71d761:	00 
  71d762:	4c 89 bc 24 10 03 00 	mov    %r15,0x310(%rsp)
  71d769:	00 
  71d76a:	48 ff c8             	dec    %rax
  71d76d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  71d774:	00 
  71d775:	4c 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%r15
  71d77c:	00 
  71d77d:	4c 69 e0 e0 00 00 00 	imul   $0xe0,%rax,%r12
  71d784:	4b 8d 34 27          	lea    (%r15,%r12,1),%rsi
  71d788:	ba b0 00 00 00       	mov    $0xb0,%edx
  71d78d:	48 89 df             	mov    %rbx,%rdi
  71d790:	4d 89 c6             	mov    %r8,%r14
  71d793:	41 ff d0             	call   *%r8
  71d796:	f2 43 0f 10 84 27 b0 	movsd  0xb0(%r15,%r12,1),%xmm0
  71d79d:	00 00 00 
  71d7a0:	0f 29 84 24 b0 05 00 	movaps %xmm0,0x5b0(%rsp)
  71d7a7:	00 
  71d7a8:	4f 8b ac 27 b8 00 00 	mov    0xb8(%r15,%r12,1),%r13
  71d7af:	00 
  71d7b0:	48 89 de             	mov    %rbx,%rsi
  71d7b3:	4b 8b 9c 27 c0 00 00 	mov    0xc0(%r15,%r12,1),%rbx
  71d7ba:	00 
  71d7bb:	4b 8b 84 27 c8 00 00 	mov    0xc8(%r15,%r12,1),%rax
  71d7c2:	00 
  71d7c3:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  71d7c8:	43 8b 84 27 d0 00 00 	mov    0xd0(%r15,%r12,1),%eax
  71d7cf:	00 
  71d7d0:	89 84 24 90 00 00 00 	mov    %eax,0x90(%rsp)
  71d7d7:	f2 43 0f 10 84 27 d4 	movsd  0xd4(%r15,%r12,1),%xmm0
  71d7de:	00 00 00 
  71d7e1:	0f 29 84 24 80 02 00 	movaps %xmm0,0x280(%rsp)
  71d7e8:	00 
  71d7e9:	ba b0 00 00 00       	mov    $0xb0,%edx
  71d7ee:	48 89 ef             	mov    %rbp,%rdi
  71d7f1:	41 ff d6             	call   *%r14
  71d7f4:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
  71d7fb:	00 
  71d7fc:	4c 3b a4 24 20 03 00 	cmp    0x320(%rsp),%r12
  71d803:	00 
  71d804:	0f 83 d9 15 00 00    	jae    71ede3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1863>
  71d80a:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
  71d80f:	41 f6 c5 01          	test   $0x1,%r13b
  71d813:	0f 84 8c 00 00 00    	je     71d8a5 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x325>
  71d819:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  71d820:	00 
  71d821:	48 39 f3             	cmp    %rsi,%rbx
  71d824:	0f 83 29 1b 00 00    	jae    71f353 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1dd3>
  71d82a:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  71d831:	00 
  71d832:	48 69 c3 a8 00 00 00 	imul   $0xa8,%rbx,%rax
  71d839:	41 83 7c 05 00 02    	cmpl   $0x2,0x0(%r13,%rax,1)
  71d83f:	0f 84 f3 1a 00 00    	je     71f338 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1db8>
  71d845:	49 01 c5             	add    %rax,%r13
  71d848:	49 8b 9d 90 00 00 00 	mov    0x90(%r13),%rbx
  71d84f:	49 3b 9d 80 00 00 00 	cmp    0x80(%r13),%rbx
  71d856:	75 0c                	jne    71d864 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2e4>
  71d858:	49 8d bd 80 00 00 00 	lea    0x80(%r13),%rdi
  71d85f:	e8 fc 0e 01 00       	call   72e760 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCshBhuxcId5D0_4gpui4list8RowDraftE8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71d864:	44 89 e0             	mov    %r12d,%eax
  71d867:	49 8b 8d 88 00 00 00 	mov    0x88(%r13),%rcx
  71d86e:	48 89 da             	mov    %rbx,%rdx
  71d871:	48 c1 e2 05          	shl    $0x5,%rdx
  71d875:	48 89 04 11          	mov    %rax,(%rcx,%rdx,1)
  71d879:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  71d87e:	48 89 44 11 08       	mov    %rax,0x8(%rcx,%rdx,1)
  71d883:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
  71d88a:	89 44 11 10          	mov    %eax,0x10(%rcx,%rdx,1)
  71d88e:	0f 28 84 24 80 02 00 	movaps 0x280(%rsp),%xmm0
  71d895:	00 
  71d896:	0f 13 44 11 14       	movlps %xmm0,0x14(%rcx,%rdx,1)
  71d89b:	48 ff c3             	inc    %rbx
  71d89e:	49 89 9d 90 00 00 00 	mov    %rbx,0x90(%r13)
  71d8a5:	48 8b 9c 24 d0 04 00 	mov    0x4d0(%rsp),%rbx
  71d8ac:	00 
  71d8ad:	48 c7 84 24 d0 04 00 	movq   $0x0,0x4d0(%rsp)
  71d8b4:	00 00 00 00 00 
  71d8b9:	48 85 db             	test   %rbx,%rbx
  71d8bc:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71d8c3:	00 
  71d8c4:	0f 84 f6 03 00 00    	je     71dcc0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x740>
  71d8ca:	48 89 de             	mov    %rbx,%rsi
  71d8cd:	4c 8b 3c 24          	mov    (%rsp),%r15
  71d8d1:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71d8d6:	ff 15 a4 d4 3c 00    	call   *0x3cd4a4(%rip)        # aead80 <_DYNAMIC+0x708>
  71d8dc:	be 38 00 00 00       	mov    $0x38,%esi
  71d8e1:	ba 08 00 00 00       	mov    $0x8,%edx
  71d8e6:	48 89 df             	mov    %rbx,%rdi
  71d8e9:	ff 15 d1 cf 3c 00    	call   *0x3ccfd1(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71d8ef:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  71d8f6:	00 
  71d8f7:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  71d8fe:	00 
  71d8ff:	4c 8b bc 24 78 01 00 	mov    0x178(%rsp),%r15
  71d906:	00 
  71d907:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  71d90e:	00 
  71d90f:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
  71d916:	00 
  71d917:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
  71d91e:	00 
  71d91f:	0f 10 06             	movups (%rsi),%xmm0
  71d922:	0f 29 84 24 00 04 00 	movaps %xmm0,0x400(%rsp)
  71d929:	00 
  71d92a:	48 8b 94 24 a0 01 00 	mov    0x1a0(%rsp),%rdx
  71d931:	00 
  71d932:	0f 10 46 18          	movups 0x18(%rsi),%xmm0
  71d936:	0f 29 84 24 f0 03 00 	movaps %xmm0,0x3f0(%rsp)
  71d93d:	00 
  71d93e:	f3 0f 10 84 24 bc 01 	movss  0x1bc(%rsp),%xmm0
  71d945:	00 00 
  71d947:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  71d94e:	00 00 
  71d950:	48 8b 9c 24 c0 01 00 	mov    0x1c0(%rsp),%rbx
  71d957:	00 
  71d958:	8b b4 24 cc 01 00 00 	mov    0x1cc(%rsp),%esi
  71d95f:	89 74 24 64          	mov    %esi,0x64(%rsp)
  71d963:	4c 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%r8
  71d96a:	00 
  71d96b:	48 8b b4 24 d8 01 00 	mov    0x1d8(%rsp),%rsi
  71d972:	00 
  71d973:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
  71d97a:	00 
  71d97b:	4c 8b 9c 24 e0 01 00 	mov    0x1e0(%rsp),%r11
  71d982:	00 
  71d983:	f2 0f 10 84 24 e8 01 	movsd  0x1e8(%rsp),%xmm0
  71d98a:	00 00 
  71d98c:	f2 0f 11 84 24 b0 02 	movsd  %xmm0,0x2b0(%rsp)
  71d993:	00 00 
  71d995:	48 8b b4 24 f0 01 00 	mov    0x1f0(%rsp),%rsi
  71d99c:	00 
  71d99d:	48 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%rdi
  71d9a4:	00 
  71d9a5:	4c 8b 8c 24 00 02 00 	mov    0x200(%rsp),%r9
  71d9ac:	00 
  71d9ad:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  71d9b2:	4c 8b 94 24 08 02 00 	mov    0x208(%rsp),%r10
  71d9b9:	00 
  71d9ba:	4c 8b 8c 24 10 02 00 	mov    0x210(%rsp),%r9
  71d9c1:	00 
  71d9c2:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  71d9c7:	48 89 8c 24 50 02 00 	mov    %rcx,0x250(%rsp)
  71d9ce:	00 
  71d9cf:	48 8b 8c 24 18 02 00 	mov    0x218(%rsp),%rcx
  71d9d6:	00 
  71d9d7:	0f 28 84 24 00 04 00 	movaps 0x400(%rsp),%xmm0
  71d9de:	00 
  71d9df:	4c 8d 8c 24 58 02 00 	lea    0x258(%rsp),%r9
  71d9e6:	00 
  71d9e7:	41 0f 11 01          	movups %xmm0,(%r9)
  71d9eb:	48 89 94 24 68 02 00 	mov    %rdx,0x268(%rsp)
  71d9f2:	00 
  71d9f3:	0f b6 94 24 20 02 00 	movzbl 0x220(%rsp),%edx
  71d9fa:	00 
  71d9fb:	88 54 24 74          	mov    %dl,0x74(%rsp)
  71d9ff:	0f b6 94 24 21 02 00 	movzbl 0x221(%rsp),%edx
  71da06:	00 
  71da07:	88 94 24 e0 00 00 00 	mov    %dl,0xe0(%rsp)
  71da0e:	f6 84 24 b8 01 00 00 	testb  $0x1,0x1b8(%rsp)
  71da15:	01 
  71da16:	0f 28 84 24 f0 03 00 	movaps 0x3f0(%rsp),%xmm0
  71da1d:	00 
  71da1e:	41 0f 11 41 18       	movups %xmm0,0x18(%r9)
  71da23:	4c 8b 35 be ce 3c 00 	mov    0x3ccebe(%rip),%r14        # aea8e8 <memcpy@GLIBC_2.14>
  71da2a:	75 0c                	jne    71da38 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x4b8>
  71da2c:	0f 57 c0             	xorps  %xmm0,%xmm0
  71da2f:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  71da36:	00 00 
  71da38:	48 89 9c 24 e8 02 00 	mov    %rbx,0x2e8(%rsp)
  71da3f:	00 
  71da40:	4c 89 9c 24 e8 00 00 	mov    %r11,0xe8(%rsp)
  71da47:	00 
  71da48:	4c 89 54 24 50       	mov    %r10,0x50(%rsp)
  71da4d:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  71da52:	4c 89 44 24 48       	mov    %r8,0x48(%rsp)
  71da57:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
  71da5c:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
  71da61:	48 85 c0             	test   %rax,%rax
  71da64:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
  71da69:	0f 84 81 01 00 00    	je     71dbf0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x670>
  71da6f:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  71da73:	49 8d 04 c7          	lea    (%r15,%rax,8),%rax
  71da77:	48 89 84 24 80 02 00 	mov    %rax,0x280(%rsp)
  71da7e:	00 
  71da7f:	4c 89 fb             	mov    %r15,%rbx
  71da82:	eb 50                	jmp    71dad4 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x554>
  71da84:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  71da8b:	00 00 00 00 00 
  71da90:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  71da97:	00 
  71da98:	4b 8d 0c 7f          	lea    (%r15,%r15,2),%rcx
  71da9c:	48 89 2c c8          	mov    %rbp,(%rax,%rcx,8)
  71daa0:	4c 89 74 c8 08       	mov    %r14,0x8(%rax,%rcx,8)
  71daa5:	44 89 64 c8 10       	mov    %r12d,0x10(%rax,%rcx,8)
  71daaa:	66 44 89 6c c8 14    	mov    %r13w,0x14(%rax,%rcx,8)
  71dab0:	49 ff c7             	inc    %r15
  71dab3:	4c 89 bc 24 68 01 00 	mov    %r15,0x168(%rsp)
  71daba:	00 
  71dabb:	48 83 c3 18          	add    $0x18,%rbx
  71dabf:	48 3b 9c 24 80 02 00 	cmp    0x280(%rsp),%rbx
  71dac6:	00 
  71dac7:	4c 8b 35 1a ce 3c 00 	mov    0x3cce1a(%rip),%r14        # aea8e8 <memcpy@GLIBC_2.14>
  71dace:	0f 84 1c 01 00 00    	je     71dbf0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x670>
  71dad4:	4c 0f bf 6b 10       	movswq 0x10(%rbx),%r13
  71dad9:	4d 85 ed             	test   %r13,%r13
  71dadc:	0f 84 0e 01 00 00    	je     71dbf0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x670>
  71dae2:	48 8b 2b             	mov    (%rbx),%rbp
  71dae5:	4c 8b 73 08          	mov    0x8(%rbx),%r14
  71dae9:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71daf0:	00 
  71daf1:	48 89 ee             	mov    %rbp,%rsi
  71daf4:	41 ff 56 28          	call   *0x28(%r14)
  71daf8:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  71daff:	00 
  71db00:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
  71db07:	00 
  71db08:	44 89 ea             	mov    %r13d,%edx
  71db0b:	ff 15 77 d2 3c 00    	call   *0x3cd277(%rip)        # aead88 <_DYNAMIC+0x710>
  71db11:	0f b6 84 24 40 03 00 	movzbl 0x340(%rsp),%eax
  71db18:	00 
  71db19:	3c ff                	cmp    $0xff,%al
  71db1b:	0f 84 5a 11 00 00    	je     71ec7b <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x16fb>
  71db21:	48 8d b4 24 41 03 00 	lea    0x341(%rsp),%rsi
  71db28:	00 
  71db29:	8b 0e                	mov    (%rsi),%ecx
  71db2b:	8b 56 03             	mov    0x3(%rsi),%edx
  71db2e:	89 94 24 e3 04 00 00 	mov    %edx,0x4e3(%rsp)
  71db35:	89 8c 24 e0 04 00 00 	mov    %ecx,0x4e0(%rsp)
  71db3c:	8b 4e 17             	mov    0x17(%rsi),%ecx
  71db3f:	48 8d bc 24 95 05 00 	lea    0x595(%rsp),%rdi
  71db46:	00 
  71db47:	89 4f 17             	mov    %ecx,0x17(%rdi)
  71db4a:	0f 10 46 07          	movups 0x7(%rsi),%xmm0
  71db4e:	0f 11 47 07          	movups %xmm0,0x7(%rdi)
  71db52:	88 84 24 94 05 00 00 	mov    %al,0x594(%rsp)
  71db59:	8b 8c 24 e0 04 00 00 	mov    0x4e0(%rsp),%ecx
  71db60:	8b 94 24 e3 04 00 00 	mov    0x4e3(%rsp),%edx
  71db67:	89 57 03             	mov    %edx,0x3(%rdi)
  71db6a:	89 0f                	mov    %ecx,(%rdi)
  71db6c:	48 8d 0d fd f8 39 00 	lea    0x39f8fd(%rip),%rcx        # abd470 <anon.b129ae91998be89bd150a4c6c09efb28.12.llvm.16081096212374801285+0x60>
  71db73:	4a 8b 4c e9 f8       	mov    -0x8(%rcx,%r13,8),%rcx
  71db78:	80 79 12 01          	cmpb   $0x1,0x12(%rcx)
  71db7c:	75 22                	jne    71dba0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x620>
  71db7e:	3c 01                	cmp    $0x1,%al
  71db80:	0f 85 7d 17 00 00    	jne    71f303 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1d83>
  71db86:	f3 0f 10 84 24 98 05 	movss  0x598(%rsp),%xmm0
  71db8d:	00 00 
  71db8f:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  71db96:	00 00 
  71db98:	eb 28                	jmp    71dbc2 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x642>
  71db9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  71dba0:	44 89 ef             	mov    %r13d,%edi
  71dba3:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
  71dbaa:	00 
  71dbab:	48 8d 94 24 94 05 00 	lea    0x594(%rsp),%rdx
  71dbb2:	00 
  71dbb3:	ff 15 d7 d1 3c 00    	call   *0x3cd1d7(%rip)        # aead90 <_DYNAMIC+0x718>
  71dbb9:	66 85 c0             	test   %ax,%ax
  71dbbc:	0f 85 b2 11 00 00    	jne    71ed74 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x17f4>
  71dbc2:	44 8b 64 24 18       	mov    0x18(%rsp),%r12d
  71dbc7:	4c 8b bc 24 68 01 00 	mov    0x168(%rsp),%r15
  71dbce:	00 
  71dbcf:	4c 3b bc 24 58 01 00 	cmp    0x158(%rsp),%r15
  71dbd6:	00 
  71dbd7:	0f 85 b3 fe ff ff    	jne    71da90 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x510>
  71dbdd:	48 8d bc 24 58 01 00 	lea    0x158(%rsp),%rdi
  71dbe4:	00 
  71dbe5:	e8 96 0a 01 00       	call   72e680 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCshBhuxcId5D0_4gpui10style_port5DraftE8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71dbea:	e9 a1 fe ff ff       	jmp    71da90 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x510>
  71dbef:	90                   	nop
  71dbf0:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  71dbf7:	00 
  71dbf8:	48 85 c0             	test   %rax,%rax
  71dbfb:	74 18                	je     71dc15 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x695>
  71dbfd:	48 c1 e0 03          	shl    $0x3,%rax
  71dc01:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  71dc05:	ba 08 00 00 00       	mov    $0x8,%edx
  71dc0a:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  71dc0f:	ff 15 ab cc 3c 00    	call   *0x3cccab(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71dc15:	f6 44 24 74 01       	testb  $0x1,0x74(%rsp)
  71dc1a:	4c 8b 3c 24          	mov    (%rsp),%r15
  71dc1e:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71dc23:	74 6a                	je     71dc8f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x70f>
  71dc25:	8b 44 24 18          	mov    0x18(%rsp),%eax
  71dc29:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  71dc30:	00 
  71dc31:	0f b6 84 24 e0 00 00 	movzbl 0xe0(%rsp),%eax
  71dc38:	00 
  71dc39:	88 84 24 80 01 00 00 	mov    %al,0x180(%rsp)
  71dc40:	48 c7 84 24 70 01 00 	movq   $0x2,0x170(%rsp)
  71dc47:	00 02 00 00 00 
  71dc4c:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
  71dc53:	00 
  71dc54:	48 3b 5c 24 78       	cmp    0x78(%rsp),%rbx
  71dc59:	75 0a                	jne    71dc65 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x6e5>
  71dc5b:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
  71dc60:	e8 8b 0a 01 00       	call   72e6f0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftE8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71dc65:	48 69 fb a8 00 00 00 	imul   $0xa8,%rbx,%rdi
  71dc6c:	48 03 bc 24 80 00 00 	add    0x80(%rsp),%rdi
  71dc73:	00 
  71dc74:	ba a8 00 00 00       	mov    $0xa8,%edx
  71dc79:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
  71dc80:	00 
  71dc81:	41 ff d6             	call   *%r14
  71dc84:	48 ff c3             	inc    %rbx
  71dc87:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
  71dc8e:	00 
  71dc8f:	66 0f 6e 84 24 90 00 	movd   0x90(%rsp),%xmm0
  71dc96:	00 00 
  71dc98:	66 0f 7e 84 24 90 00 	movd   %xmm0,0x90(%rsp)
  71dc9f:	00 00 
  71dca1:	66 0f 7e c0          	movd   %xmm0,%eax
  71dca5:	85 c0                	test   %eax,%eax
  71dca7:	0f 85 90 00 00 00    	jne    71dd3d <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x7bd>
  71dcad:	80 7c 24 64 02       	cmpb   $0x2,0x64(%rsp)
  71dcb2:	0f 84 60 01 00 00    	je     71de18 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x898>
  71dcb8:	e9 e9 00 00 00       	jmp    71dda6 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x826>
  71dcbd:	0f 1f 00             	nopl   (%rax)
  71dcc0:	8b 44 24 64          	mov    0x64(%rsp),%eax
  71dcc4:	25 00 ff ff ff       	and    $0xffffff00,%eax
  71dcc9:	83 c8 02             	or     $0x2,%eax
  71dccc:	89 44 24 64          	mov    %eax,0x64(%rsp)
  71dcd0:	48 c7 84 24 50 02 00 	movq   $0xffffffffffffffff,0x250(%rsp)
  71dcd7:	00 ff ff ff ff 
  71dcdc:	0f 28 84 24 00 04 00 	movaps 0x400(%rsp),%xmm0
  71dce3:	00 
  71dce4:	48 8d 84 24 58 02 00 	lea    0x258(%rsp),%rax
  71dceb:	00 
  71dcec:	0f 11 00             	movups %xmm0,(%rax)
  71dcef:	48 c7 84 24 68 02 00 	movq   $0xffffffffffffffff,0x268(%rsp)
  71dcf6:	00 ff ff ff ff 
  71dcfb:	66 0f 6f 84 24 f0 03 	movdqa 0x3f0(%rsp),%xmm0
  71dd02:	00 00 
  71dd04:	f3 0f 7f 40 18       	movdqu %xmm0,0x18(%rax)
  71dd09:	66 0f ef c0          	pxor   %xmm0,%xmm0
  71dd0d:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  71dd14:	00 00 
  71dd16:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  71dd1d:	00 00 
  71dd1f:	4c 8b 3c 24          	mov    (%rsp),%r15
  71dd23:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71dd28:	66 0f 7e 84 24 90 00 	movd   %xmm0,0x90(%rsp)
  71dd2f:	00 00 
  71dd31:	66 0f 7e c0          	movd   %xmm0,%eax
  71dd35:	85 c0                	test   %eax,%eax
  71dd37:	0f 84 70 ff ff ff    	je     71dcad <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x72d>
  71dd3d:	44 8b 64 24 18       	mov    0x18(%rsp),%r12d
  71dd42:	48 8b 9c 24 50 01 00 	mov    0x150(%rsp),%rbx
  71dd49:	00 
  71dd4a:	48 3b 9c 24 40 01 00 	cmp    0x140(%rsp),%rbx
  71dd51:	00 
  71dd52:	75 1e                	jne    71dd72 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x7f2>
  71dd54:	b0 01                	mov    $0x1,%al
  71dd56:	89 44 24 14          	mov    %eax,0x14(%rsp)
  71dd5a:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  71dd5f:	b0 01                	mov    $0x1,%al
  71dd61:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  71dd65:	48 8d bc 24 40 01 00 	lea    0x140(%rsp),%rdi
  71dd6c:	00 
  71dd6d:	e8 de 06 01 00       	call   72e450 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecAINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCshBhuxcId5D0_4gpui6source7FieldIdEj2_E8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71dd72:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  71dd79:	00 
  71dd7a:	48 89 d9             	mov    %rbx,%rcx
  71dd7d:	48 c1 e1 04          	shl    $0x4,%rcx
  71dd81:	4c 89 24 08          	mov    %r12,(%rax,%rcx,1)
  71dd85:	66 0f 6e 84 24 90 00 	movd   0x90(%rsp),%xmm0
  71dd8c:	00 00 
  71dd8e:	66 0f 7e 44 08 08    	movd   %xmm0,0x8(%rax,%rcx,1)
  71dd94:	48 ff c3             	inc    %rbx
  71dd97:	48 89 9c 24 50 01 00 	mov    %rbx,0x150(%rsp)
  71dd9e:	00 
  71dd9f:	80 7c 24 64 02       	cmpb   $0x2,0x64(%rsp)
  71dda4:	74 72                	je     71de18 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x898>
  71dda6:	8b 6c 24 18          	mov    0x18(%rsp),%ebp
  71ddaa:	48 8b 9c 24 38 01 00 	mov    0x138(%rsp),%rbx
  71ddb1:	00 
  71ddb2:	48 3b 9c 24 28 01 00 	cmp    0x128(%rsp),%rbx
  71ddb9:	00 
  71ddba:	75 1e                	jne    71ddda <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x85a>
  71ddbc:	b0 01                	mov    $0x1,%al
  71ddbe:	89 44 24 14          	mov    %eax,0x14(%rsp)
  71ddc2:	4c 8b 74 24 48       	mov    0x48(%rsp),%r14
  71ddc7:	b0 01                	mov    $0x1,%al
  71ddc9:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  71ddcd:	48 8d bc 24 28 01 00 	lea    0x128(%rsp),%rdi
  71ddd4:	00 
  71ddd5:	e8 a6 08 01 00       	call   72e680 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCshBhuxcId5D0_4gpui10style_port5DraftE8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71ddda:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
  71dde1:	00 
  71dde2:	48 8d 0c 5b          	lea    (%rbx,%rbx,2),%rcx
  71dde6:	48 8b 94 24 e8 02 00 	mov    0x2e8(%rsp),%rdx
  71dded:	00 
  71ddee:	48 89 14 c8          	mov    %rdx,(%rax,%rcx,8)
  71ddf2:	66 0f 6e 84 24 90 00 	movd   0x90(%rsp),%xmm0
  71ddf9:	00 00 
  71ddfb:	66 0f 7e 44 c8 08    	movd   %xmm0,0x8(%rax,%rcx,8)
  71de01:	8b 54 24 64          	mov    0x64(%rsp),%edx
  71de05:	89 54 c8 0c          	mov    %edx,0xc(%rax,%rcx,8)
  71de09:	89 6c c8 10          	mov    %ebp,0x10(%rax,%rcx,8)
  71de0d:	48 ff c3             	inc    %rbx
  71de10:	48 89 9c 24 38 01 00 	mov    %rbx,0x138(%rsp)
  71de17:	00 
  71de18:	b0 01                	mov    $0x1,%al
  71de1a:	89 44 24 14          	mov    %eax,0x14(%rsp)
  71de1e:	b0 01                	mov    $0x1,%al
  71de20:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
  71de26:	4c 8b a4 24 18 03 00 	mov    0x318(%rsp),%r12
  71de2d:	00 
  71de2e:	48 8b ac 24 10 03 00 	mov    0x310(%rsp),%rbp
  71de35:	00 
  71de36:	0f 84 12 01 00 00    	je     71df4e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x9ce>
  71de3c:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  71de43:	00 
  71de44:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  71de49:	48 8b 94 24 00 03 00 	mov    0x300(%rsp),%rdx
  71de50:	00 
  71de51:	48 8b 8c 24 08 03 00 	mov    0x308(%rsp),%rcx
  71de58:	00 
  71de59:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71de5e:	ff 50 18             	call   *0x18(%rax)
  71de61:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  71de67:	0f 94 c3             	sete   %bl
  71de6a:	74 47                	je     71deb3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x933>
  71de6c:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71de71:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  71de78:	00 
  71de79:	4c 8b 74 24 38       	mov    0x38(%rsp),%r14
  71de7e:	41 ff 56 28          	call   *0x28(%r14)
  71de82:	49 8b 06             	mov    (%r14),%rax
  71de85:	48 85 c0             	test   %rax,%rax
  71de88:	74 07                	je     71de91 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x911>
  71de8a:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71de8f:	ff d0                	call   *%rax
  71de91:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71de96:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71de9a:	48 85 f6             	test   %rsi,%rsi
  71de9d:	74 14                	je     71deb3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x933>
  71de9f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71dea4:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71dea8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71dead:	ff 15 0d ca 3c 00    	call   *0x3cca0d(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71deb3:	ba b0 00 00 00       	mov    $0xb0,%edx
  71deb8:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71debf:	00 
  71dec0:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  71dec7:	00 
  71dec8:	ff 15 1a ca 3c 00    	call   *0x3cca1a(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  71dece:	4c 8b b4 24 40 04 00 	mov    0x440(%rsp),%r14
  71ded5:	00 
  71ded6:	4c 3b b4 24 30 04 00 	cmp    0x430(%rsp),%r14
  71dedd:	00 
  71dede:	75 0e                	jne    71deee <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x96e>
  71dee0:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
  71dee7:	00 
  71dee8:	ff 15 aa ce 3c 00    	call   *0x3cceaa(%rip)        # aead98 <_DYNAMIC+0x720>
  71deee:	49 69 fe b0 00 00 00 	imul   $0xb0,%r14,%rdi
  71def5:	48 03 bc 24 38 04 00 	add    0x438(%rsp),%rdi
  71defc:	00 
  71defd:	ba b0 00 00 00       	mov    $0xb0,%edx
  71df02:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
  71df09:	00 
  71df0a:	ff 15 d8 c9 3c 00    	call   *0x3cc9d8(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  71df10:	49 ff c6             	inc    %r14
  71df13:	4c 89 b4 24 40 04 00 	mov    %r14,0x440(%rsp)
  71df1a:	00 
  71df1b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71df20:	48 8b 00             	mov    (%rax),%rax
  71df23:	48 85 c0             	test   %rax,%rax
  71df26:	74 07                	je     71df2f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x9af>
  71df28:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  71df2d:	ff d0                	call   *%rax
  71df2f:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71df34:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71df38:	48 85 f6             	test   %rsi,%rsi
  71df3b:	74 0f                	je     71df4c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x9cc>
  71df3d:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71df41:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  71df46:	ff 15 74 c9 3c 00    	call   *0x3cc974(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71df4c:	31 c0                	xor    %eax,%eax
  71df4e:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  71df52:	48 83 bc 24 50 02 00 	cmpq   $0xffffffffffffffff,0x250(%rsp)
  71df59:	00 ff 
  71df5b:	0f 85 8f 01 00 00    	jne    71e0f0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xb70>
  71df61:	48 83 bc 24 68 02 00 	cmpq   $0xffffffffffffffff,0x268(%rsp)
  71df68:	00 ff 
  71df6a:	0f 85 80 01 00 00    	jne    71e0f0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xb70>
  71df70:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  71df75:	48 85 c9             	test   %rcx,%rcx
  71df78:	48 8d 9c 24 90 01 00 	lea    0x190(%rsp),%rbx
  71df7f:	00 
  71df80:	0f 84 34 02 00 00    	je     71e1ba <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xc3a>
  71df86:	48 8d 94 24 60 04 00 	lea    0x460(%rsp),%rdx
  71df8d:	00 
  71df8e:	48 8b 42 50          	mov    0x50(%rdx),%rax
  71df92:	48 89 84 24 90 03 00 	mov    %rax,0x390(%rsp)
  71df99:	00 
  71df9a:	0f 10 42 40          	movups 0x40(%rdx),%xmm0
  71df9e:	0f 29 84 24 80 03 00 	movaps %xmm0,0x380(%rsp)
  71dfa5:	00 
  71dfa6:	0f 10 02             	movups (%rdx),%xmm0
  71dfa9:	0f 10 4a 10          	movups 0x10(%rdx),%xmm1
  71dfad:	66 0f 10 52 20       	movupd 0x20(%rdx),%xmm2
  71dfb2:	66 0f 10 5a 30       	movupd 0x30(%rdx),%xmm3
  71dfb7:	66 0f 29 9c 24 70 03 	movapd %xmm3,0x370(%rsp)
  71dfbe:	00 00 
  71dfc0:	66 0f 29 94 24 60 03 	movapd %xmm2,0x360(%rsp)
  71dfc7:	00 00 
  71dfc9:	0f 29 8c 24 50 03 00 	movaps %xmm1,0x350(%rsp)
  71dfd0:	00 
  71dfd1:	0f 29 84 24 40 03 00 	movaps %xmm0,0x340(%rsp)
  71dfd8:	00 
  71dfd9:	48 8b b4 24 e8 00 00 	mov    0xe8(%rsp),%rsi
  71dfe0:	00 
  71dfe1:	48 89 b4 24 a8 03 00 	mov    %rsi,0x3a8(%rsp)
  71dfe8:	00 
  71dfe9:	48 89 8c 24 98 03 00 	mov    %rcx,0x398(%rsp)
  71dff0:	00 
  71dff1:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  71dff8:	00 
  71dff9:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  71e000:	00 
  71e001:	f2 0f 10 84 24 b0 02 	movsd  0x2b0(%rsp),%xmm0
  71e008:	00 00 
  71e00a:	f2 0f 11 84 24 b0 03 	movsd  %xmm0,0x3b0(%rsp)
  71e011:	00 00 
  71e013:	48 8b bc 24 f8 02 00 	mov    0x2f8(%rsp),%rdi
  71e01a:	00 
  71e01b:	e8 40 69 ff ff       	call   714960 <_RNvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtCshBhuxcId5D0_4gpui4list6ListIdNtNtB7_7set_val9SetValZSTE6insertCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71e020:	84 c0                	test   %al,%al
  71e022:	0f 85 dc 0d 00 00    	jne    71ee04 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1884>
  71e028:	48 8b 84 24 a8 02 00 	mov    0x2a8(%rsp),%rax
  71e02f:	00 
  71e030:	48 8b 00             	mov    (%rax),%rax
  71e033:	48 85 c0             	test   %rax,%rax
  71e036:	0f 84 71 02 00 00    	je     71e2ad <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xd2d>
  71e03c:	48 8b 8c 24 a8 02 00 	mov    0x2a8(%rsp),%rcx
  71e043:	00 
  71e044:	48 8b 49 08          	mov    0x8(%rcx),%rcx
  71e048:	0f b7 90 8a 05 00 00 	movzwl 0x58a(%rax),%edx
  71e04f:	48 8d 70 40          	lea    0x40(%rax),%rsi
  71e053:	89 d7                	mov    %edx,%edi
  71e055:	c1 e7 04             	shl    $0x4,%edi
  71e058:	49 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%r10
  71e05f:	45 31 c9             	xor    %r9d,%r9d
  71e062:	49 89 c3             	mov    %rax,%r11
  71e065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71e06c:	00 00 00 00 
  71e070:	48 85 ff             	test   %rdi,%rdi
  71e073:	74 4e                	je     71e0c3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xb43>
  71e075:	41 80 3b 00          	cmpb   $0x0,(%r11)
  71e079:	75 45                	jne    71e0c0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xb40>
  71e07b:	4d 89 d0             	mov    %r10,%r8
  71e07e:	49 ff c1             	inc    %r9
  71e081:	4c 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%r10
  71e088:	00 
  71e089:	4d 3b 53 08          	cmp    0x8(%r11),%r10
  71e08d:	0f 97 c3             	seta   %bl
  71e090:	4d 8d 5b 10          	lea    0x10(%r11),%r11
  71e094:	80 db 00             	sbb    $0x0,%bl
  71e097:	48 83 c6 70          	add    $0x70,%rsi
  71e09b:	4d 8d 50 01          	lea    0x1(%r8),%r10
  71e09f:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
  71e0a3:	80 fb 01             	cmp    $0x1,%bl
  71e0a6:	74 c8                	je     71e070 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xaf0>
  71e0a8:	0f b6 d3             	movzbl %bl,%edx
  71e0ab:	85 d2                	test   %edx,%edx
  71e0ad:	0f 84 ed 01 00 00    	je     71e2a0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xd20>
  71e0b3:	49 ff c0             	inc    %r8
  71e0b6:	4c 89 c2             	mov    %r8,%rdx
  71e0b9:	eb 08                	jmp    71e0c3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xb43>
  71e0bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  71e0c0:	4c 89 ca             	mov    %r9,%rdx
  71e0c3:	48 8d 9c 24 90 01 00 	lea    0x190(%rsp),%rbx
  71e0ca:	00 
  71e0cb:	48 83 e9 01          	sub    $0x1,%rcx
  71e0cf:	0f 82 d8 01 00 00    	jb     71e2ad <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xd2d>
  71e0d5:	48 8b 84 d0 90 05 00 	mov    0x590(%rax,%rdx,8),%rax
  71e0dc:	00 
  71e0dd:	e9 66 ff ff ff       	jmp    71e048 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xac8>
  71e0e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71e0e9:	1f 84 00 00 00 00 00 
  71e0f0:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
  71e0f7:	00 00 
  71e0f9:	0f 10 8c 24 60 02 00 	movups 0x260(%rsp),%xmm1
  71e100:	00 
  71e101:	66 0f 10 94 24 70 02 	movupd 0x270(%rsp),%xmm2
  71e108:	00 00 
  71e10a:	66 0f 29 94 24 90 01 	movapd %xmm2,0x190(%rsp)
  71e111:	00 00 
  71e113:	0f 29 8c 24 80 01 00 	movaps %xmm1,0x180(%rsp)
  71e11a:	00 
  71e11b:	66 0f 7f 84 24 70 01 	movdqa %xmm0,0x170(%rsp)
  71e122:	00 00 
  71e124:	8b 44 24 18          	mov    0x18(%rsp),%eax
  71e128:	89 84 24 a0 01 00 00 	mov    %eax,0x1a0(%rsp)
  71e12f:	48 8b 9c 24 20 01 00 	mov    0x120(%rsp),%rbx
  71e136:	00 
  71e137:	48 3b 9c 24 10 01 00 	cmp    0x110(%rsp),%rbx
  71e13e:	00 
  71e13f:	75 0d                	jne    71e14e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xbce>
  71e141:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
  71e148:	00 
  71e149:	e8 52 04 01 00       	call   72e5a0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCs1rQ3kaVqKLB_20gpui_reactivity_core8geometry15CoordinateSpaceE8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71e14e:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
  71e155:	00 
  71e156:	48 6b cb 38          	imul   $0x38,%rbx,%rcx
  71e15a:	48 8b 94 24 a0 01 00 	mov    0x1a0(%rsp),%rdx
  71e161:	00 
  71e162:	48 89 54 08 30       	mov    %rdx,0x30(%rax,%rcx,1)
  71e167:	66 0f 6f 84 24 70 01 	movdqa 0x170(%rsp),%xmm0
  71e16e:	00 00 
  71e170:	0f 28 8c 24 80 01 00 	movaps 0x180(%rsp),%xmm1
  71e177:	00 
  71e178:	66 0f 28 94 24 90 01 	movapd 0x190(%rsp),%xmm2
  71e17f:	00 00 
  71e181:	66 0f 11 54 08 20    	movupd %xmm2,0x20(%rax,%rcx,1)
  71e187:	0f 11 4c 08 10       	movups %xmm1,0x10(%rax,%rcx,1)
  71e18c:	f3 0f 7f 04 08       	movdqu %xmm0,(%rax,%rcx,1)
  71e191:	48 ff c3             	inc    %rbx
  71e194:	48 89 9c 24 20 01 00 	mov    %rbx,0x120(%rsp)
  71e19b:	00 
  71e19c:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
  71e1a3:	00 
  71e1a4:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  71e1a9:	48 85 c9             	test   %rcx,%rcx
  71e1ac:	48 8d 9c 24 90 01 00 	lea    0x190(%rsp),%rbx
  71e1b3:	00 
  71e1b4:	0f 85 cc fd ff ff    	jne    71df86 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xa06>
  71e1ba:	48 8b 84 24 30 04 00 	mov    0x430(%rsp),%rax
  71e1c1:	00 
  71e1c2:	48 8b 8c 24 38 04 00 	mov    0x438(%rsp),%rcx
  71e1c9:	00 
  71e1ca:	48 8b 94 24 40 04 00 	mov    0x440(%rsp),%rdx
  71e1d1:	00 
  71e1d2:	48 c7 84 24 30 04 00 	movq   $0x0,0x430(%rsp)
  71e1d9:	00 00 00 00 00 
  71e1de:	48 c7 84 24 38 04 00 	movq   $0x8,0x438(%rsp)
  71e1e5:	00 08 00 00 00 
  71e1ea:	48 c7 84 24 40 04 00 	movq   $0x0,0x440(%rsp)
  71e1f1:	00 00 00 00 00 
  71e1f6:	48 69 f2 b0 00 00 00 	imul   $0xb0,%rdx,%rsi
  71e1fd:	48 01 ce             	add    %rcx,%rsi
  71e200:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  71e207:	00 
  71e208:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  71e20f:	00 
  71e210:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  71e217:	00 
  71e218:	48 89 b4 24 88 01 00 	mov    %rsi,0x188(%rsp)
  71e21f:	00 
  71e220:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  71e225:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  71e22c:	00 
  71e22d:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  71e234:	00 
  71e235:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  71e23c:	00 
  71e23d:	48 29 f0             	sub    %rsi,%rax
  71e240:	48 39 c2             	cmp    %rax,%rdx
  71e243:	0f 87 f1 09 00 00    	ja     71ec3a <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x16ba>
  71e249:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  71e250:	00 
  71e251:	48 8d 8c 24 c0 00 00 	lea    0xc0(%rsp),%rcx
  71e258:	00 
  71e259:	48 89 8c 24 40 03 00 	mov    %rcx,0x340(%rsp)
  71e260:	00 
  71e261:	48 89 b4 24 48 03 00 	mov    %rsi,0x348(%rsp)
  71e268:	00 
  71e269:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  71e270:	00 
  71e271:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  71e276:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  71e27d:	00 
  71e27e:	45 31 f6             	xor    %r14d,%r14d
  71e281:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71e288:	00 
  71e289:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  71e290:	00 
  71e291:	e8 0a cf 00 00       	call   72b1a0 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_>
  71e296:	b3 01                	mov    $0x1,%bl
  71e298:	e9 e6 07 00 00       	jmp    71ea83 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1503>
  71e29d:	0f 1f 00             	nopl   (%rax)
  71e2a0:	83 3e 02             	cmpl   $0x2,(%rsi)
  71e2a3:	48 8d 9c 24 90 01 00 	lea    0x190(%rsp),%rbx
  71e2aa:	00 
  71e2ab:	75 68                	jne    71e315 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xd95>
  71e2ad:	48 8b 84 24 90 03 00 	mov    0x390(%rsp),%rax
  71e2b4:	00 
  71e2b5:	48 89 84 24 30 05 00 	mov    %rax,0x530(%rsp)
  71e2bc:	00 
  71e2bd:	0f 28 84 24 80 03 00 	movaps 0x380(%rsp),%xmm0
  71e2c4:	00 
  71e2c5:	0f 29 84 24 20 05 00 	movaps %xmm0,0x520(%rsp)
  71e2cc:	00 
  71e2cd:	0f 28 84 24 40 03 00 	movaps 0x340(%rsp),%xmm0
  71e2d4:	00 
  71e2d5:	0f 28 8c 24 50 03 00 	movaps 0x350(%rsp),%xmm1
  71e2dc:	00 
  71e2dd:	66 0f 28 94 24 60 03 	movapd 0x360(%rsp),%xmm2
  71e2e4:	00 00 
  71e2e6:	66 0f 28 9c 24 70 03 	movapd 0x370(%rsp),%xmm3
  71e2ed:	00 00 
  71e2ef:	66 0f 29 9c 24 10 05 	movapd %xmm3,0x510(%rsp)
  71e2f6:	00 00 
  71e2f8:	66 0f 29 94 24 00 05 	movapd %xmm2,0x500(%rsp)
  71e2ff:	00 00 
  71e301:	0f 29 8c 24 f0 04 00 	movaps %xmm1,0x4f0(%rsp)
  71e308:	00 
  71e309:	0f 29 84 24 e0 04 00 	movaps %xmm0,0x4e0(%rsp)
  71e310:	00 
  71e311:	31 f6                	xor    %esi,%esi
  71e313:	eb 2f                	jmp    71e344 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xdc4>
  71e315:	48 8b 56 18          	mov    0x18(%rsi),%rdx
  71e319:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
  71e320:	00 
  71e321:	48 89 f3             	mov    %rsi,%rbx
  71e324:	48 8b b4 24 e0 02 00 	mov    0x2e0(%rsp),%rsi
  71e32b:	00 
  71e32c:	48 8d 8c 24 40 03 00 	lea    0x340(%rsp),%rcx
  71e333:	00 
  71e334:	e8 17 8e 00 00       	call   727150 <_RNvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB5_9Overrides7resolveCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71e339:	48 89 de             	mov    %rbx,%rsi
  71e33c:	48 8d 9c 24 90 01 00 	lea    0x190(%rsp),%rbx
  71e343:	00 
  71e344:	31 c0                	xor    %eax,%eax
  71e346:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  71e34d:	00 00 00 
  71e350:	48 39 c5             	cmp    %rax,%rbp
  71e353:	74 2b                	je     71e380 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xe00>
  71e355:	48 8d 48 18          	lea    0x18(%rax),%rcx
  71e359:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
  71e360:	00 
  71e361:	49 39 54 04 28       	cmp    %rdx,0x28(%r12,%rax,1)
  71e366:	48 89 c8             	mov    %rcx,%rax
  71e369:	75 e5                	jne    71e350 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xdd0>
  71e36b:	41 0f 10 04 0c       	movups (%r12,%rcx,1),%xmm0
  71e370:	0f 29 84 24 d0 05 00 	movaps %xmm0,0x5d0(%rsp)
  71e377:	00 
  71e378:	eb 12                	jmp    71e38c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xe0c>
  71e37a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  71e380:	48 c7 84 24 d0 05 00 	movq   $0xffffffffffffffff,0x5d0(%rsp)
  71e387:	00 ff ff ff ff 
  71e38c:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71e393:	00 
  71e394:	48 8d 94 24 e0 04 00 	lea    0x4e0(%rsp),%rdx
  71e39b:	00 
  71e39c:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
  71e3a1:	4c 8b 84 24 08 01 00 	mov    0x108(%rsp),%r8
  71e3a8:	00 
  71e3a9:	f2 0f 10 84 24 b0 02 	movsd  0x2b0(%rsp),%xmm0
  71e3b0:	00 00 
  71e3b2:	4c 8d 8c 24 d0 05 00 	lea    0x5d0(%rsp),%r9
  71e3b9:	00 
  71e3ba:	ff 15 e0 c9 3c 00    	call   *0x3cc9e0(%rip)        # aeada0 <_DYNAMIC+0x728>
  71e3c0:	48 8b b4 24 70 01 00 	mov    0x170(%rsp),%rsi
  71e3c7:	00 
  71e3c8:	48 8b 94 24 78 01 00 	mov    0x178(%rsp),%rdx
  71e3cf:	00 
  71e3d0:	48 8b 8c 24 80 01 00 	mov    0x180(%rsp),%rcx
  71e3d7:	00 
  71e3d8:	48 83 fe 02          	cmp    $0x2,%rsi
  71e3dc:	0f 84 2f 0a 00 00    	je     71ee11 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1891>
  71e3e2:	48 8b 84 24 88 01 00 	mov    0x188(%rsp),%rax
  71e3e9:	00 
  71e3ea:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  71e3f1:	00 
  71e3f2:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  71e3f9:	00 
  71e3fa:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  71e3ff:	4c 8b ac 24 98 01 00 	mov    0x198(%rsp),%r13
  71e406:	00 
  71e407:	48 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%rdi
  71e40e:	00 
  71e40f:	0f 10 43 18          	movups 0x18(%rbx),%xmm0
  71e413:	0f 29 84 24 10 04 00 	movaps %xmm0,0x410(%rsp)
  71e41a:	00 
  71e41b:	48 8b 43 28          	mov    0x28(%rbx),%rax
  71e41f:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  71e426:	00 
  71e427:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
  71e42e:	00 
  71e42f:	f2 0f 10 8c 24 c8 01 	movsd  0x1c8(%rsp),%xmm1
  71e436:	00 00 
  71e438:	4c 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%r8
  71e43f:	00 
  71e440:	f2 0f 10 94 24 d8 01 	movsd  0x1d8(%rsp),%xmm2
  71e447:	00 00 
  71e449:	0f 10 43 50          	movups 0x50(%rbx),%xmm0
  71e44d:	0f 29 84 24 c0 05 00 	movaps %xmm0,0x5c0(%rsp)
  71e454:	00 
  71e455:	66 48 0f 6e df       	movq   %rdi,%xmm3
  71e45a:	66 0f 62 1d 2e 5e 94 	punpckldq -0x6ba1d2(%rip),%xmm3        # 64290 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x100>
  71e461:	ff 
  71e462:	66 0f 5c 1d a6 5a 94 	subpd  -0x6ba55a(%rip),%xmm3        # 63f10 <anon.079f5e587c394fcac2765eb4d0cf0bc2.360.llvm.6319143315422321905+0x70>
  71e469:	ff 
  71e46a:	4c 3b ac 24 f0 02 00 	cmp    0x2f0(%rsp),%r13
  71e471:	00 
  71e472:	0f 87 e7 07 00 00    	ja     71ec5f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x16df>
  71e478:	f2 0f 11 94 24 e0 00 	movsd  %xmm2,0xe0(%rsp)
  71e47f:	00 00 
  71e481:	4c 89 84 24 b8 02 00 	mov    %r8,0x2b8(%rsp)
  71e488:	00 
  71e489:	f2 0f 11 8c 24 90 02 	movsd  %xmm1,0x290(%rsp)
  71e490:	00 00 
  71e492:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  71e499:	00 
  71e49a:	48 89 bc 24 98 02 00 	mov    %rdi,0x298(%rsp)
  71e4a1:	00 
  71e4a2:	48 89 b4 24 c0 02 00 	mov    %rsi,0x2c0(%rsp)
  71e4a9:	00 
  71e4aa:	48 89 8c 24 c8 02 00 	mov    %rcx,0x2c8(%rsp)
  71e4b1:	00 
  71e4b2:	48 89 94 24 d0 02 00 	mov    %rdx,0x2d0(%rsp)
  71e4b9:	00 
  71e4ba:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  71e4c1:	00 
  71e4c2:	48 89 84 24 38 03 00 	mov    %rax,0x338(%rsp)
  71e4c9:	00 
  71e4ca:	49 69 ed e0 00 00 00 	imul   $0xe0,%r13,%rbp
  71e4d1:	48 85 ed             	test   %rbp,%rbp
  71e4d4:	74 4a                	je     71e520 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xfa0>
  71e4d6:	66 0f 29 9c 24 90 00 	movapd %xmm3,0x90(%rsp)
  71e4dd:	00 00 
  71e4df:	ff 15 f3 c3 3c 00    	call   *0x3cc3f3(%rip)        # aea8d8 <_DYNAMIC+0x260>
  71e4e5:	41 be 08 00 00 00    	mov    $0x8,%r14d
  71e4eb:	be 08 00 00 00       	mov    $0x8,%esi
  71e4f0:	48 89 ef             	mov    %rbp,%rdi
  71e4f3:	ff 15 bf c3 3c 00    	call   *0x3cc3bf(%rip)        # aea8b8 <_DYNAMIC+0x240>
  71e4f9:	48 85 c0             	test   %rax,%rax
  71e4fc:	4c 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%r15
  71e503:	00 
  71e504:	4c 8d a4 24 d0 05 00 	lea    0x5d0(%rsp),%r12
  71e50b:	00 
  71e50c:	0f 84 58 07 00 00    	je     71ec6a <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x16ea>
  71e512:	4c 89 e9             	mov    %r13,%rcx
  71e515:	66 0f 28 9c 24 90 00 	movapd 0x90(%rsp),%xmm3
  71e51c:	00 00 
  71e51e:	eb 17                	jmp    71e537 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xfb7>
  71e520:	b8 08 00 00 00       	mov    $0x8,%eax
  71e525:	31 c9                	xor    %ecx,%ecx
  71e527:	4c 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%r15
  71e52e:	00 
  71e52f:	4c 8d a4 24 d0 05 00 	lea    0x5d0(%rsp),%r12
  71e536:	00 
  71e537:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  71e53e:	00 
  71e53f:	48 89 84 24 d8 02 00 	mov    %rax,0x2d8(%rsp)
  71e546:	00 
  71e547:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  71e54e:	00 
  71e54f:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  71e556:	00 00 00 00 00 
  71e55b:	4d 85 ed             	test   %r13,%r13
  71e55e:	0f 84 e1 02 00 00    	je     71e845 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x12c5>
  71e564:	66 0f 28 c3          	movapd %xmm3,%xmm0
  71e568:	66 0f 15 c3          	unpckhpd %xmm3,%xmm0
  71e56c:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
  71e570:	f2 0f 10 8c 24 e0 00 	movsd  0xe0(%rsp),%xmm1
  71e577:	00 00 
  71e579:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
  71e57d:	f2 0f 10 94 24 90 02 	movsd  0x290(%rsp),%xmm2
  71e584:	00 00 
  71e586:	f2 0f 5c d0          	subsd  %xmm0,%xmm2
  71e58a:	f2 0f 11 94 24 28 03 	movsd  %xmm2,0x328(%rsp)
  71e591:	00 00 
  71e593:	0f 57 c0             	xorps  %xmm0,%xmm0
  71e596:	f2 0f 5a c1          	cvtsd2ss %xmm1,%xmm0
  71e59a:	f3 0f 11 84 24 90 00 	movss  %xmm0,0x90(%rsp)
  71e5a1:	00 00 
  71e5a3:	49 c1 e5 03          	shl    $0x3,%r13
  71e5a7:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  71e5ae:	00 
  71e5af:	48 8b 40 38          	mov    0x38(%rax),%rax
  71e5b3:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  71e5ba:	00 
  71e5bb:	48 8b ac 24 98 02 00 	mov    0x298(%rsp),%rbp
  71e5c2:	00 
  71e5c3:	31 db                	xor    %ebx,%ebx
  71e5c5:	eb 56                	jmp    71e61d <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x109d>
  71e5c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  71e5ce:	00 00 
  71e5d0:	49 69 fc e0 00 00 00 	imul   $0xe0,%r12,%rdi
  71e5d7:	48 03 bc 24 d0 00 00 	add    0xd0(%rsp),%rdi
  71e5de:	00 
  71e5df:	ba e0 00 00 00       	mov    $0xe0,%edx
  71e5e4:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
  71e5eb:	00 
  71e5ec:	ff 15 f6 c2 3c 00    	call   *0x3cc2f6(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  71e5f2:	49 ff c4             	inc    %r12
  71e5f5:	4c 89 a4 24 d8 00 00 	mov    %r12,0xd8(%rsp)
  71e5fc:	00 
  71e5fd:	48 ff c5             	inc    %rbp
  71e600:	48 ff c3             	inc    %rbx
  71e603:	4c 8b ac 24 a8 00 00 	mov    0xa8(%rsp),%r13
  71e60a:	00 
  71e60b:	49 83 c5 f8          	add    $0xfffffffffffffff8,%r13
  71e60f:	4c 8d a4 24 d0 05 00 	lea    0x5d0(%rsp),%r12
  71e616:	00 
  71e617:	0f 84 28 02 00 00    	je     71e845 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x12c5>
  71e61d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  71e622:	4c 8b 34 d8          	mov    (%rax,%rbx,8),%r14
  71e626:	4c 89 e7             	mov    %r12,%rdi
  71e629:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  71e62e:	48 89 ea             	mov    %rbp,%rdx
  71e631:	ff 94 24 30 03 00 00 	call   *0x330(%rsp)
  71e638:	4c 89 b4 24 80 02 00 	mov    %r14,0x280(%rsp)
  71e63f:	00 
  71e640:	4c 89 ac 24 a8 00 00 	mov    %r13,0xa8(%rsp)
  71e647:	00 
  71e648:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  71e64d:	48 85 ff             	test   %rdi,%rdi
  71e650:	74 0b                	je     71e65d <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x10dd>
  71e652:	4c 89 e6             	mov    %r12,%rsi
  71e655:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  71e65a:	ff 50 28             	call   *0x28(%rax)
  71e65d:	c6 84 24 88 05 00 00 	movb   $0x7,0x588(%rsp)
  71e664:	07 
  71e665:	48 c7 84 24 f8 04 00 	movq   $0xffffffffffffffff,0x4f8(%rsp)
  71e66c:	00 ff ff ff ff 
  71e671:	48 c7 84 24 e0 04 00 	movq   $0x0,0x4e0(%rsp)
  71e678:	00 00 00 00 00 
  71e67d:	48 c7 84 24 e8 04 00 	movq   $0x8,0x4e8(%rsp)
  71e684:	00 08 00 00 00 
  71e689:	48 c7 84 24 f0 04 00 	movq   $0x0,0x4f0(%rsp)
  71e690:	00 00 00 00 00 
  71e695:	0f 10 05 88 a4 94 ff 	movups -0x6b5b78(%rip),%xmm0        # 68b24 <anon.b129ae91998be89bd150a4c6c09efb28.4.llvm.16081096212374801285+0x40>
  71e69c:	48 8d 84 24 10 05 00 	lea    0x510(%rsp),%rax
  71e6a3:	00 
  71e6a4:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  71e6a8:	0f 10 05 65 a4 94 ff 	movups -0x6b5b9b(%rip),%xmm0        # 68b14 <anon.b129ae91998be89bd150a4c6c09efb28.4.llvm.16081096212374801285+0x30>
  71e6af:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  71e6b3:	0f 10 05 4a a4 94 ff 	movups -0x6b5bb6(%rip),%xmm0        # 68b04 <anon.b129ae91998be89bd150a4c6c09efb28.4.llvm.16081096212374801285+0x20>
  71e6ba:	0f 11 40 20          	movups %xmm0,0x20(%rax)
  71e6be:	0f 10 05 2f a4 94 ff 	movups -0x6b5bd1(%rip),%xmm0        # 68af4 <anon.b129ae91998be89bd150a4c6c09efb28.4.llvm.16081096212374801285+0x10>
  71e6c5:	0f 11 40 10          	movups %xmm0,0x10(%rax)
  71e6c9:	0f 10 05 14 a4 94 ff 	movups -0x6b5bec(%rip),%xmm0        # 68ae4 <anon.b129ae91998be89bd150a4c6c09efb28.4.llvm.16081096212374801285>
  71e6d0:	0f 11 00             	movups %xmm0,(%rax)
  71e6d3:	48 b9 00 00 00 00 01 	movabs $0x3000100000000,%rcx
  71e6da:	00 03 00 
  71e6dd:	48 89 48 50          	mov    %rcx,0x50(%rax)
  71e6e1:	48 c7 84 24 68 05 00 	movq   $0x0,0x568(%rsp)
  71e6e8:	00 00 00 00 00 
  71e6ed:	0f 57 c0             	xorps  %xmm0,%xmm0
  71e6f0:	0f 11 40 68          	movups %xmm0,0x68(%rax)
  71e6f4:	ba b0 00 00 00       	mov    $0xb0,%edx
  71e6f9:	4c 8d ac 24 70 01 00 	lea    0x170(%rsp),%r13
  71e700:	00 
  71e701:	4c 89 e6             	mov    %r12,%rsi
  71e704:	4d 89 ec             	mov    %r13,%r12
  71e707:	4c 89 ef             	mov    %r13,%rdi
  71e70a:	4c 8b 35 d7 c1 3c 00 	mov    0x3cc1d7(%rip),%r14        # aea8e8 <memcpy@GLIBC_2.14>
  71e711:	41 ff d6             	call   *%r14
  71e714:	4c 89 ff             	mov    %r15,%rdi
  71e717:	ff 15 7b c6 3c 00    	call   *0x3cc67b(%rip)        # aead98 <_DYNAMIC+0x720>
  71e71d:	4d 89 fd             	mov    %r15,%r13
  71e720:	48 8b bc 24 e8 04 00 	mov    0x4e8(%rsp),%rdi
  71e727:	00 
  71e728:	ba b0 00 00 00       	mov    $0xb0,%edx
  71e72d:	4c 89 e6             	mov    %r12,%rsi
  71e730:	41 ff d6             	call   *%r14
  71e733:	48 c7 84 24 f0 04 00 	movq   $0x1,0x4f0(%rsp)
  71e73a:	00 01 00 00 00 
  71e73f:	c7 84 24 18 05 00 00 	movl   $0x1,0x518(%rsp)
  71e746:	01 00 00 00 
  71e74a:	f3 0f 10 84 24 90 00 	movss  0x90(%rsp),%xmm0
  71e751:	00 00 
  71e753:	f3 0f 11 84 24 1c 05 	movss  %xmm0,0x51c(%rsp)
  71e75a:	00 00 
  71e75c:	44 8b 7c 24 18       	mov    0x18(%rsp),%r15d
  71e761:	ba b0 00 00 00       	mov    $0xb0,%edx
  71e766:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  71e76d:	00 
  71e76e:	4c 89 ee             	mov    %r13,%rsi
  71e771:	41 ff d6             	call   *%r14
  71e774:	48 89 e8             	mov    %rbp,%rax
  71e777:	48 c1 e8 20          	shr    $0x20,%rax
  71e77b:	0f 85 38 05 00 00    	jne    71ecb9 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1739>
  71e781:	0f 57 c0             	xorps  %xmm0,%xmm0
  71e784:	f2 48 0f 2a c3       	cvtsi2sd %rbx,%xmm0
  71e789:	f2 0f 59 84 24 e0 00 	mulsd  0xe0(%rsp),%xmm0
  71e790:	00 00 
  71e792:	f2 0f 5c 84 24 28 03 	subsd  0x328(%rsp),%xmm0
  71e799:	00 00 
  71e79b:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  71e79f:	f3 0f 11 44 24 74    	movss  %xmm0,0x74(%rsp)
  71e7a5:	c7 84 24 20 02 00 00 	movl   $0x1,0x220(%rsp)
  71e7ac:	01 00 00 00 
  71e7b0:	44 89 bc 24 24 02 00 	mov    %r15d,0x224(%rsp)
  71e7b7:	00 
  71e7b8:	ba b0 00 00 00       	mov    $0xb0,%edx
  71e7bd:	4c 89 e7             	mov    %r12,%rdi
  71e7c0:	4c 89 ee             	mov    %r13,%rsi
  71e7c3:	41 ff d6             	call   *%r14
  71e7c6:	48 c7 84 24 28 02 00 	movq   $0x1,0x228(%rsp)
  71e7cd:	00 01 00 00 00 
  71e7d2:	48 8b 84 24 38 03 00 	mov    0x338(%rsp),%rax
  71e7d9:	00 
  71e7da:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  71e7e1:	00 
  71e7e2:	48 8b 84 24 80 02 00 	mov    0x280(%rsp),%rax
  71e7e9:	00 
  71e7ea:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
  71e7f1:	00 
  71e7f2:	89 ac 24 40 02 00 00 	mov    %ebp,0x240(%rsp)
  71e7f9:	f3 0f 10 44 24 74    	movss  0x74(%rsp),%xmm0
  71e7ff:	f3 0f 11 84 24 44 02 	movss  %xmm0,0x244(%rsp)
  71e806:	00 00 
  71e808:	f3 0f 10 84 24 90 00 	movss  0x90(%rsp),%xmm0
  71e80f:	00 00 
  71e811:	f3 0f 11 84 24 48 02 	movss  %xmm0,0x248(%rsp)
  71e818:	00 00 
  71e81a:	4c 8b a4 24 d8 00 00 	mov    0xd8(%rsp),%r12
  71e821:	00 
  71e822:	4c 3b a4 24 c8 00 00 	cmp    0xc8(%rsp),%r12
  71e829:	00 
  71e82a:	4d 89 ef             	mov    %r13,%r15
  71e82d:	0f 85 9d fd ff ff    	jne    71e5d0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1050>
  71e833:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
  71e83a:	00 
  71e83b:	e8 50 01 01 00       	call   72e990 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecTINtNtCs4NRVxsYgnAr_4core6option6OptionmENtNtCshBhuxcId5D0_4gpui7element2ElIBN_TjNtNtB1u_4list7ItemKeymffEEEE8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71e840:	e9 8b fd ff ff       	jmp    71e5d0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1050>
  71e845:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  71e84a:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
  71e851:	00 
  71e852:	ff 50 18             	call   *0x18(%rax)
  71e855:	48 3b 84 24 a0 02 00 	cmp    0x2a0(%rsp),%rax
  71e85c:	00 
  71e85d:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71e862:	0f 85 7a 0a 00 00    	jne    71f2e2 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1d62>
  71e868:	8b 5c 24 18          	mov    0x18(%rsp),%ebx
  71e86c:	4c 8b a4 24 d8 00 00 	mov    0xd8(%rsp),%r12
  71e873:	00 
  71e874:	4d 85 e4             	test   %r12,%r12
  71e877:	74 25                	je     71e89e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x131e>
  71e879:	4d 89 e6             	mov    %r12,%r14
  71e87c:	49 c1 e6 05          	shl    $0x5,%r14
  71e880:	ff 15 52 c0 3c 00    	call   *0x3cc052(%rip)        # aea8d8 <_DYNAMIC+0x260>
  71e886:	be 08 00 00 00       	mov    $0x8,%esi
  71e88b:	4c 89 f7             	mov    %r14,%rdi
  71e88e:	ff 15 24 c0 3c 00    	call   *0x3cc024(%rip)        # aea8b8 <_DYNAMIC+0x240>
  71e894:	48 85 c0             	test   %rax,%rax
  71e897:	75 0a                	jne    71e8a3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1323>
  71e899:	e9 c7 0a 00 00       	jmp    71f365 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1de5>
  71e89e:	b8 08 00 00 00       	mov    $0x8,%eax
  71e8a3:	48 8b 8c 24 c0 02 00 	mov    0x2c0(%rsp),%rcx
  71e8aa:	00 
  71e8ab:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  71e8b2:	00 
  71e8b3:	48 8b 8c 24 d0 02 00 	mov    0x2d0(%rsp),%rcx
  71e8ba:	00 
  71e8bb:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  71e8c2:	00 
  71e8c3:	48 8b 8c 24 c8 02 00 	mov    0x2c8(%rsp),%rcx
  71e8ca:	00 
  71e8cb:	48 89 8c 24 80 01 00 	mov    %rcx,0x180(%rsp)
  71e8d2:	00 
  71e8d3:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
  71e8da:	00 
  71e8db:	48 89 8c 24 88 01 00 	mov    %rcx,0x188(%rsp)
  71e8e2:	00 
  71e8e3:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  71e8e8:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
  71e8ef:	00 
  71e8f0:	48 c7 84 24 98 01 00 	movq   $0x0,0x198(%rsp)
  71e8f7:	00 00 00 00 00 
  71e8fc:	48 8b 8c 24 98 02 00 	mov    0x298(%rsp),%rcx
  71e903:	00 
  71e904:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  71e90b:	00 
  71e90c:	48 8b 8c 24 20 04 00 	mov    0x420(%rsp),%rcx
  71e913:	00 
  71e914:	48 8d 94 24 90 01 00 	lea    0x190(%rsp),%rdx
  71e91b:	00 
  71e91c:	48 89 4a 28          	mov    %rcx,0x28(%rdx)
  71e920:	0f 28 84 24 10 04 00 	movaps 0x410(%rsp),%xmm0
  71e927:	00 
  71e928:	0f 11 42 18          	movups %xmm0,0x18(%rdx)
  71e92c:	48 8b 8c 24 a0 02 00 	mov    0x2a0(%rsp),%rcx
  71e933:	00 
  71e934:	48 89 8c 24 c0 01 00 	mov    %rcx,0x1c0(%rsp)
  71e93b:	00 
  71e93c:	f2 0f 10 84 24 90 02 	movsd  0x290(%rsp),%xmm0
  71e943:	00 00 
  71e945:	f2 0f 11 84 24 c8 01 	movsd  %xmm0,0x1c8(%rsp)
  71e94c:	00 00 
  71e94e:	48 8b 8c 24 b8 02 00 	mov    0x2b8(%rsp),%rcx
  71e955:	00 
  71e956:	48 89 8c 24 d0 01 00 	mov    %rcx,0x1d0(%rsp)
  71e95d:	00 
  71e95e:	f2 0f 10 84 24 e0 00 	movsd  0xe0(%rsp),%xmm0
  71e965:	00 00 
  71e967:	f2 0f 11 84 24 d8 01 	movsd  %xmm0,0x1d8(%rsp)
  71e96e:	00 00 
  71e970:	0f 28 84 24 c0 05 00 	movaps 0x5c0(%rsp),%xmm0
  71e977:	00 
  71e978:	0f 11 42 50          	movups %xmm0,0x50(%rdx)
  71e97c:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
  71e983:	00 
  71e984:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
  71e98b:	00 
  71e98c:	48 c7 84 24 00 02 00 	movq   $0x0,0x200(%rsp)
  71e993:	00 00 00 00 00 
  71e998:	48 89 9c 24 08 02 00 	mov    %rbx,0x208(%rsp)
  71e99f:	00 
  71e9a0:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  71e9a7:	00 
  71e9a8:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  71e9af:	00 
  71e9b0:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
  71e9b7:	00 
  71e9b8:	48 3b 5c 24 78       	cmp    0x78(%rsp),%rbx
  71e9bd:	75 0a                	jne    71e9c9 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1449>
  71e9bf:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
  71e9c4:	e8 27 fd 00 00       	call   72e6f0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftE8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71e9c9:	48 69 fb a8 00 00 00 	imul   $0xa8,%rbx,%rdi
  71e9d0:	48 03 bc 24 80 00 00 	add    0x80(%rsp),%rdi
  71e9d7:	00 
  71e9d8:	ba a8 00 00 00       	mov    $0xa8,%edx
  71e9dd:	4c 8d b4 24 70 01 00 	lea    0x170(%rsp),%r14
  71e9e4:	00 
  71e9e5:	4c 89 f6             	mov    %r14,%rsi
  71e9e8:	ff 15 fa be 3c 00    	call   *0x3cbefa(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  71e9ee:	48 ff c3             	inc    %rbx
  71e9f1:	48 89 9c 24 88 00 00 	mov    %rbx,0x88(%rsp)
  71e9f8:	00 
  71e9f9:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  71ea00:	00 
  71ea01:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  71ea08:	00 
  71ea09:	48 69 94 24 d8 00 00 	imul   $0xe0,0xd8(%rsp),%rdx
  71ea10:	00 e0 00 00 00 
  71ea15:	48 01 ca             	add    %rcx,%rdx
  71ea18:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  71ea1f:	00 
  71ea20:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  71ea27:	00 
  71ea28:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  71ea2f:	00 
  71ea30:	48 89 94 24 88 01 00 	mov    %rdx,0x188(%rsp)
  71ea37:	00 
  71ea38:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  71ea3f:	00 
  71ea40:	4c 89 f6             	mov    %r14,%rsi
  71ea43:	e8 08 a5 ff ff       	call   718f50 <_RINvMsj_NtCscdodAO9FK5_5alloc3vecINtB6_3VecTINtNtCs4NRVxsYgnAr_4core6option6OptionmENtNtCshBhuxcId5D0_4gpui7element2ElIBH_TjNtNtB1o_4list7ItemKeymffEEEE14extend_trustedINtNtNtNtBL_4iter8adapters3rev3RevINtNtB6_9into_iter8IntoIterBF_EEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71ea48:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  71ea4e:	74 31                	je     71ea81 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1501>
  71ea50:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  71ea55:	48 8b 00             	mov    (%rax),%rax
  71ea58:	48 85 c0             	test   %rax,%rax
  71ea5b:	74 07                	je     71ea64 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x14e4>
  71ea5d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  71ea62:	ff d0                	call   *%rax
  71ea64:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  71ea69:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71ea6d:	48 85 f6             	test   %rsi,%rsi
  71ea70:	74 0f                	je     71ea81 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1501>
  71ea72:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71ea76:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  71ea7b:	ff 15 3f be 3c 00    	call   *0x3cbe3f(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ea81:	31 db                	xor    %ebx,%ebx
  71ea83:	0f b6 84 24 d8 04 00 	movzbl 0x4d8(%rsp),%eax
  71ea8a:	00 
  71ea8b:	48 8d b4 24 60 04 00 	lea    0x460(%rsp),%rsi
  71ea92:	00 
  71ea93:	0f 10 46 e8          	movups -0x18(%rsi),%xmm0
  71ea97:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
  71ea9e:	00 
  71ea9f:	48 8b 4e f8          	mov    -0x8(%rsi),%rcx
  71eaa3:	48 89 8c 24 80 01 00 	mov    %rcx,0x180(%rsp)
  71eaaa:	00 
  71eaab:	48 c7 84 24 48 04 00 	movq   $0xffffffffffffffff,0x448(%rsp)
  71eab2:	00 ff ff ff ff 
  71eab7:	48 8b 4e 50          	mov    0x50(%rsi),%rcx
  71eabb:	48 8d 94 24 90 01 00 	lea    0x190(%rsp),%rdx
  71eac2:	00 
  71eac3:	48 89 4a 50          	mov    %rcx,0x50(%rdx)
  71eac7:	0f 10 46 40          	movups 0x40(%rsi),%xmm0
  71eacb:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  71eacf:	0f 10 06             	movups (%rsi),%xmm0
  71ead2:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  71ead6:	66 0f 10 56 20       	movupd 0x20(%rsi),%xmm2
  71eadb:	66 0f 10 5e 30       	movupd 0x30(%rsi),%xmm3
  71eae0:	66 0f 11 5a 30       	movupd %xmm3,0x30(%rdx)
  71eae5:	66 0f 11 52 20       	movupd %xmm2,0x20(%rdx)
  71eaea:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  71eaee:	0f 11 02             	movups %xmm0,(%rdx)
  71eaf1:	48 8b 8c 24 c8 04 00 	mov    0x4c8(%rsp),%rcx
  71eaf8:	00 
  71eaf9:	48 c7 84 24 c8 04 00 	movq   $0x0,0x4c8(%rsp)
  71eb00:	00 00 00 00 00 
  71eb05:	0f 28 84 24 b0 05 00 	movaps 0x5b0(%rsp),%xmm0
  71eb0c:	00 
  71eb0d:	0f 13 84 24 88 01 00 	movlps %xmm0,0x188(%rsp)
  71eb14:	00 
  71eb15:	88 84 24 00 02 00 00 	mov    %al,0x200(%rsp)
  71eb1c:	0f 10 84 24 b8 04 00 	movups 0x4b8(%rsp),%xmm0
  71eb23:	00 
  71eb24:	48 c7 84 24 b8 04 00 	movq   $0x0,0x4b8(%rsp)
  71eb2b:	00 00 00 00 00 
  71eb30:	0f 11 84 24 e8 01 00 	movups %xmm0,0x1e8(%rsp)
  71eb37:	00 
  71eb38:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
  71eb3f:	00 
  71eb40:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
  71eb47:	00 
  71eb48:	4c 3b b4 24 f0 00 00 	cmp    0xf0(%rsp),%r14
  71eb4f:	00 
  71eb50:	75 0d                	jne    71eb5f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x15df>
  71eb52:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  71eb59:	00 
  71eb5a:	e8 71 fc 00 00       	call   72e7d0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecNtNtCshBhuxcId5D0_4gpui7element9DraftNodeE8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71eb5f:	49 69 fe 98 00 00 00 	imul   $0x98,%r14,%rdi
  71eb66:	48 03 bc 24 f8 00 00 	add    0xf8(%rsp),%rdi
  71eb6d:	00 
  71eb6e:	ba 98 00 00 00       	mov    $0x98,%edx
  71eb73:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
  71eb7a:	00 
  71eb7b:	ff 15 67 bd 3c 00    	call   *0x3cbd67(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  71eb81:	49 ff c6             	inc    %r14
  71eb84:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
  71eb8b:	00 
  71eb8c:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
  71eb91:	48 8d 9c 24 88 06 00 	lea    0x688(%rsp),%rbx
  71eb98:	00 
  71eb99:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
  71eba0:	00 
  71eba1:	74 6d                	je     71ec10 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1690>
  71eba3:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  71ebaa:	00 
  71ebab:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  71ebaf:	74 22                	je     71ebd3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1653>
  71ebb1:	48 85 f6             	test   %rsi,%rsi
  71ebb4:	78 1d                	js     71ebd3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1653>
  71ebb6:	74 1b                	je     71ebd3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1653>
  71ebb8:	48 8b bc 24 58 02 00 	mov    0x258(%rsp),%rdi
  71ebbf:	00 
  71ebc0:	ba 01 00 00 00       	mov    $0x1,%edx
  71ebc5:	ff 15 f5 bc 3c 00    	call   *0x3cbcf5(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ebcb:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
  71ebd2:	00 
  71ebd3:	48 8b b4 24 68 02 00 	mov    0x268(%rsp),%rsi
  71ebda:	00 
  71ebdb:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  71ebdf:	74 2f                	je     71ec10 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1690>
  71ebe1:	48 85 f6             	test   %rsi,%rsi
  71ebe4:	78 2a                	js     71ec10 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1690>
  71ebe6:	74 28                	je     71ec10 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1690>
  71ebe8:	48 8b bc 24 70 02 00 	mov    0x270(%rsp),%rdi
  71ebef:	00 
  71ebf0:	ba 01 00 00 00       	mov    $0x1,%edx
  71ebf5:	ff 15 c5 bc 3c 00    	call   *0x3cbcc5(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ebfb:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
  71ec02:	00 
  71ec03:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71ec0a:	84 00 00 00 00 00 
  71ec10:	e8 6b 1c 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71ec15:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  71ec1c:	00 
  71ec1d:	48 85 c0             	test   %rax,%rax
  71ec20:	4c 8b 05 c1 bc 3c 00 	mov    0x3cbcc1(%rip),%r8        # aea8e8 <memcpy@GLIBC_2.14>
  71ec27:	48 8d ac 24 30 04 00 	lea    0x430(%rsp),%rbp
  71ec2e:	00 
  71ec2f:	0f 85 35 eb ff ff    	jne    71d76a <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1ea>
  71ec35:	e9 ae 05 00 00       	jmp    71f1e8 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1c68>
  71ec3a:	b9 08 00 00 00       	mov    $0x8,%ecx
  71ec3f:	41 b8 e0 00 00 00    	mov    $0xe0,%r8d
  71ec45:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  71ec4c:	00 
  71ec4d:	e8 6e f7 00 00       	call   72e3c0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71ec52:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  71ec59:	00 
  71ec5a:	e9 ea f5 ff ff       	jmp    71e249 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0xcc9>
  71ec5f:	45 31 f6             	xor    %r14d,%r14d
  71ec62:	48 8b ac 24 d8 02 00 	mov    0x2d8(%rsp),%rbp
  71ec69:	00 
  71ec6a:	4c 89 f7             	mov    %r14,%rdi
  71ec6d:	48 89 ee             	mov    %rbp,%rsi
  71ec70:	ff 15 2a bd 3c 00    	call   *0x3cbd2a(%rip)        # aea9a0 <_DYNAMIC+0x328>
  71ec76:	e9 f8 06 00 00       	jmp    71f373 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1df3>
  71ec7b:	0f b7 84 24 46 03 00 	movzwl 0x346(%rsp),%eax
  71ec82:	00 
  71ec83:	66 89 84 24 e5 04 00 	mov    %ax,0x4e5(%rsp)
  71ec8a:	00 
  71ec8b:	8b 8c 24 42 03 00 00 	mov    0x342(%rsp),%ecx
  71ec92:	89 8c 24 e1 04 00 00 	mov    %ecx,0x4e1(%rsp)
  71ec99:	48 8b 54 24 68       	mov    0x68(%rsp),%rdx
  71ec9e:	66 89 42 14          	mov    %ax,0x14(%rdx)
  71eca2:	89 4a 10             	mov    %ecx,0x10(%rdx)
  71eca5:	48 c7 42 08 24 00 00 	movq   $0x24,0x8(%rdx)
  71ecac:	00 
  71ecad:	48 c7 02 ff ff ff ff 	movq   $0xffffffffffffffff,(%rdx)
  71ecb4:	e9 ec 00 00 00       	jmp    71eda5 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1825>
  71ecb9:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  71ecbe:	48 c7 40 08 27 00 00 	movq   $0x27,0x8(%rax)
  71ecc5:	00 
  71ecc6:	48 c7 40 10 03 00 00 	movq   $0x3,0x10(%rax)
  71eccd:	00 
  71ecce:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
  71ecd5:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  71ecdc:	00 
  71ecdd:	e8 9e 1b 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71ece2:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  71ece7:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  71ecec:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  71ecf3:	00 
  71ecf4:	48 8b 9c 24 d8 00 00 	mov    0xd8(%rsp),%rbx
  71ecfb:	00 
  71ecfc:	48 ff c3             	inc    %rbx
  71ecff:	90                   	nop
  71ed00:	48 83 fb 01          	cmp    $0x1,%rbx
  71ed04:	74 14                	je     71ed1a <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x179a>
  71ed06:	4c 8d bf e0 00 00 00 	lea    0xe0(%rdi),%r15
  71ed0d:	48 ff cb             	dec    %rbx
  71ed10:	e8 ab af ff ff       	call   719cc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.14596612939337359452>
  71ed15:	4c 89 ff             	mov    %r15,%rdi
  71ed18:	eb e6                	jmp    71ed00 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1780>
  71ed1a:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  71ed21:	00 
  71ed22:	48 85 c0             	test   %rax,%rax
  71ed25:	74 1a                	je     71ed41 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x17c1>
  71ed27:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  71ed2e:	00 
  71ed2f:	48 69 f0 e0 00 00 00 	imul   $0xe0,%rax,%rsi
  71ed36:	ba 08 00 00 00       	mov    $0x8,%edx
  71ed3b:	ff 15 7f bb 3c 00    	call   *0x3cbb7f(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ed41:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  71ed48:	00 
  71ed49:	48 85 f6             	test   %rsi,%rsi
  71ed4c:	8b 5c 24 1c          	mov    0x1c(%rsp),%ebx
  71ed50:	74 14                	je     71ed66 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x17e6>
  71ed52:	48 c1 e6 03          	shl    $0x3,%rsi
  71ed56:	ba 08 00 00 00       	mov    $0x8,%edx
  71ed5b:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  71ed60:	ff 15 5a bb 3c 00    	call   *0x3cbb5a(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ed66:	4d 85 f6             	test   %r14,%r14
  71ed69:	0f 85 d1 00 00 00    	jne    71ee40 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x18c0>
  71ed6f:	e9 f0 00 00 00       	jmp    71ee64 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x18e4>
  71ed74:	48 89 c1             	mov    %rax,%rcx
  71ed77:	48 c1 e9 18          	shr    $0x18,%rcx
  71ed7b:	89 c2                	mov    %eax,%edx
  71ed7d:	c1 ea 10             	shr    $0x10,%edx
  71ed80:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  71ed85:	48 c7 46 08 24 00 00 	movq   $0x24,0x8(%rsi)
  71ed8c:	00 
  71ed8d:	66 89 46 10          	mov    %ax,0x10(%rsi)
  71ed91:	88 56 12             	mov    %dl,0x12(%rsi)
  71ed94:	66 89 4e 13          	mov    %cx,0x13(%rsi)
  71ed98:	c1 e9 10             	shr    $0x10,%ecx
  71ed9b:	88 4e 15             	mov    %cl,0x15(%rsi)
  71ed9e:	48 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%rsi)
  71eda5:	b0 01                	mov    $0x1,%al
  71eda7:	89 44 24 14          	mov    %eax,0x14(%rsp)
  71edab:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  71edb2:	00 
  71edb3:	48 85 c0             	test   %rax,%rax
  71edb6:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  71edbb:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  71edc0:	74 18                	je     71edda <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x185a>
  71edc2:	48 c1 e0 03          	shl    $0x3,%rax
  71edc6:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  71edca:	ba 08 00 00 00       	mov    $0x8,%edx
  71edcf:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  71edd4:	ff 15 e6 ba 3c 00    	call   *0x3cbae6(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71edda:	31 c9                	xor    %ecx,%ecx
  71eddc:	b3 01                	mov    $0x1,%bl
  71edde:	e9 88 00 00 00       	jmp    71ee6b <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x18eb>
  71ede3:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  71ede8:	48 c7 40 08 27 00 00 	movq   $0x27,0x8(%rax)
  71edef:	00 
  71edf0:	48 c7 40 10 03 00 00 	movq   $0x3,0x10(%rax)
  71edf7:	00 
  71edf8:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
  71edff:	e9 71 01 00 00       	jmp    71ef75 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19f5>
  71ee04:	ba 04 00 00 00       	mov    $0x4,%edx
  71ee09:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  71ee10:	00 
  71ee11:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  71ee16:	48 c7 40 08 27 00 00 	movq   $0x27,0x8(%rax)
  71ee1d:	00 
  71ee1e:	48 89 50 10          	mov    %rdx,0x10(%rax)
  71ee22:	48 89 48 18          	mov    %rcx,0x18(%rax)
  71ee26:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
  71ee2d:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  71ee32:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  71ee37:	8b 5c 24 1c          	mov    0x1c(%rsp),%ebx
  71ee3b:	4d 85 f6             	test   %r14,%r14
  71ee3e:	74 24                	je     71ee64 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x18e4>
  71ee40:	49 8b 45 00          	mov    0x0(%r13),%rax
  71ee44:	48 85 c0             	test   %rax,%rax
  71ee47:	74 05                	je     71ee4e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x18ce>
  71ee49:	4c 89 f7             	mov    %r14,%rdi
  71ee4c:	ff d0                	call   *%rax
  71ee4e:	49 8b 75 08          	mov    0x8(%r13),%rsi
  71ee52:	48 85 f6             	test   %rsi,%rsi
  71ee55:	74 0d                	je     71ee64 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x18e4>
  71ee57:	49 8b 55 10          	mov    0x10(%r13),%rdx
  71ee5b:	4c 89 f7             	mov    %r14,%rdi
  71ee5e:	ff 15 5c ba 3c 00    	call   *0x3cba5c(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ee64:	80 f3 01             	xor    $0x1,%bl
  71ee67:	89 d9                	mov    %ebx,%ecx
  71ee69:	31 db                	xor    %ebx,%ebx
  71ee6b:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
  71ee71:	0f 94 c0             	sete   %al
  71ee74:	08 c8                	or     %cl,%al
  71ee76:	a8 01                	test   $0x1,%al
  71ee78:	75 6f                	jne    71eee9 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1969>
  71ee7a:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71ee7f:	48 8b 00             	mov    (%rax),%rax
  71ee82:	48 85 c0             	test   %rax,%rax
  71ee85:	74 07                	je     71ee8e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x190e>
  71ee87:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  71ee8c:	ff d0                	call   *%rax
  71ee8e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71ee93:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71ee97:	48 85 f6             	test   %rsi,%rsi
  71ee9a:	74 0f                	je     71eeab <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x192b>
  71ee9c:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71eea0:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  71eea5:	ff 15 15 ba 3c 00    	call   *0x3cba15(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71eeab:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  71eeb1:	74 36                	je     71eee9 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1969>
  71eeb3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71eeb8:	48 8b 00             	mov    (%rax),%rax
  71eebb:	48 85 c0             	test   %rax,%rax
  71eebe:	74 07                	je     71eec7 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1947>
  71eec0:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71eec5:	ff d0                	call   *%rax
  71eec7:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71eecc:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71eed0:	48 85 f6             	test   %rsi,%rsi
  71eed3:	74 14                	je     71eee9 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1969>
  71eed5:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71eeda:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71eede:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71eee3:	ff 15 d7 b9 3c 00    	call   *0x3cb9d7(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71eee9:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
  71eeee:	74 50                	je     71ef40 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19c0>
  71eef0:	48 8b b4 24 50 02 00 	mov    0x250(%rsp),%rsi
  71eef7:	00 
  71eef8:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  71eefc:	74 1a                	je     71ef18 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1998>
  71eefe:	48 85 f6             	test   %rsi,%rsi
  71ef01:	78 15                	js     71ef18 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1998>
  71ef03:	74 13                	je     71ef18 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1998>
  71ef05:	48 8b bc 24 58 02 00 	mov    0x258(%rsp),%rdi
  71ef0c:	00 
  71ef0d:	ba 01 00 00 00       	mov    $0x1,%edx
  71ef12:	ff 15 a8 b9 3c 00    	call   *0x3cb9a8(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ef18:	48 8b b4 24 68 02 00 	mov    0x268(%rsp),%rsi
  71ef1f:	00 
  71ef20:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  71ef24:	74 1a                	je     71ef40 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19c0>
  71ef26:	48 85 f6             	test   %rsi,%rsi
  71ef29:	78 15                	js     71ef40 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19c0>
  71ef2b:	74 13                	je     71ef40 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19c0>
  71ef2d:	48 8b bc 24 70 02 00 	mov    0x270(%rsp),%rdi
  71ef34:	00 
  71ef35:	ba 01 00 00 00       	mov    $0x1,%edx
  71ef3a:	ff 15 80 b9 3c 00    	call   *0x3cb980(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ef40:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
  71ef46:	74 2d                	je     71ef75 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19f5>
  71ef48:	84 db                	test   %bl,%bl
  71ef4a:	74 29                	je     71ef75 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19f5>
  71ef4c:	4d 85 f6             	test   %r14,%r14
  71ef4f:	74 24                	je     71ef75 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19f5>
  71ef51:	49 8b 45 00          	mov    0x0(%r13),%rax
  71ef55:	48 85 c0             	test   %rax,%rax
  71ef58:	74 05                	je     71ef5f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19df>
  71ef5a:	4c 89 f7             	mov    %r14,%rdi
  71ef5d:	ff d0                	call   *%rax
  71ef5f:	49 8b 75 08          	mov    0x8(%r13),%rsi
  71ef63:	48 85 f6             	test   %rsi,%rsi
  71ef66:	74 0d                	je     71ef75 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x19f5>
  71ef68:	49 8b 55 10          	mov    0x10(%r13),%rdx
  71ef6c:	4c 89 f7             	mov    %r14,%rdi
  71ef6f:	ff 15 4b b9 3c 00    	call   *0x3cb94b(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71ef75:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
  71ef7c:	00 
  71ef7d:	e8 fe 18 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71ef82:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
  71ef89:	00 
  71ef8a:	4c 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%r14
  71ef91:	00 
  71ef92:	49 ff c6             	inc    %r14
  71ef95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71ef9c:	00 00 00 00 
  71efa0:	49 83 fe 01          	cmp    $0x1,%r14
  71efa4:	74 14                	je     71efba <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1a3a>
  71efa6:	48 8d 9f e0 00 00 00 	lea    0xe0(%rdi),%rbx
  71efad:	49 ff ce             	dec    %r14
  71efb0:	e8 0b ad ff ff       	call   719cc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.14596612939337359452>
  71efb5:	48 89 df             	mov    %rbx,%rdi
  71efb8:	eb e6                	jmp    71efa0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1a20>
  71efba:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  71efc1:	00 
  71efc2:	48 85 c0             	test   %rax,%rax
  71efc5:	74 1a                	je     71efe1 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1a61>
  71efc7:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
  71efce:	00 
  71efcf:	48 69 f0 e0 00 00 00 	imul   $0xe0,%rax,%rsi
  71efd6:	ba 08 00 00 00       	mov    $0x8,%edx
  71efdb:	ff 15 df b8 3c 00    	call   *0x3cb8df(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71efe1:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  71efe8:	00 
  71efe9:	48 85 c0             	test   %rax,%rax
  71efec:	74 1b                	je     71f009 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1a89>
  71efee:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  71eff5:	00 
  71eff6:	48 c1 e0 03          	shl    $0x3,%rax
  71effa:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  71effe:	ba 08 00 00 00       	mov    $0x8,%edx
  71f003:	ff 15 b7 b8 3c 00    	call   *0x3cb8b7(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f009:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  71f010:	00 
  71f011:	48 85 f6             	test   %rsi,%rsi
  71f014:	74 17                	je     71f02d <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1aad>
  71f016:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  71f01d:	00 
  71f01e:	48 c1 e6 04          	shl    $0x4,%rsi
  71f022:	ba 08 00 00 00       	mov    $0x8,%edx
  71f027:	ff 15 93 b8 3c 00    	call   *0x3cb893(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f02d:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  71f034:	00 
  71f035:	48 85 c0             	test   %rax,%rax
  71f038:	74 1b                	je     71f055 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1ad5>
  71f03a:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  71f041:	00 
  71f042:	48 c1 e0 03          	shl    $0x3,%rax
  71f046:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  71f04a:	ba 08 00 00 00       	mov    $0x8,%edx
  71f04f:	ff 15 6b b8 3c 00    	call   *0x3cb86b(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f055:	48 8b 9c 24 20 01 00 	mov    0x120(%rsp),%rbx
  71f05c:	00 
  71f05d:	48 85 db             	test   %rbx,%rbx
  71f060:	74 58                	je     71f0ba <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b3a>
  71f062:	4c 8b b4 24 18 01 00 	mov    0x118(%rsp),%r14
  71f069:	00 
  71f06a:	49 83 c6 20          	add    $0x20,%r14
  71f06e:	eb 09                	jmp    71f079 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1af9>
  71f070:	49 83 c6 38          	add    $0x38,%r14
  71f074:	48 ff cb             	dec    %rbx
  71f077:	74 41                	je     71f0ba <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b3a>
  71f079:	49 8b 76 e0          	mov    -0x20(%r14),%rsi
  71f07d:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  71f081:	74 16                	je     71f099 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b19>
  71f083:	48 85 f6             	test   %rsi,%rsi
  71f086:	78 11                	js     71f099 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b19>
  71f088:	74 0f                	je     71f099 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b19>
  71f08a:	49 8b 7e e8          	mov    -0x18(%r14),%rdi
  71f08e:	ba 01 00 00 00       	mov    $0x1,%edx
  71f093:	ff 15 27 b8 3c 00    	call   *0x3cb827(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f099:	49 8b 76 f8          	mov    -0x8(%r14),%rsi
  71f09d:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  71f0a1:	74 cd                	je     71f070 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1af0>
  71f0a3:	48 85 f6             	test   %rsi,%rsi
  71f0a6:	78 c8                	js     71f070 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1af0>
  71f0a8:	74 c6                	je     71f070 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1af0>
  71f0aa:	49 8b 3e             	mov    (%r14),%rdi
  71f0ad:	ba 01 00 00 00       	mov    $0x1,%edx
  71f0b2:	ff 15 08 b8 3c 00    	call   *0x3cb808(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f0b8:	eb b6                	jmp    71f070 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1af0>
  71f0ba:	48 8b 84 24 10 01 00 	mov    0x110(%rsp),%rax
  71f0c1:	00 
  71f0c2:	48 85 c0             	test   %rax,%rax
  71f0c5:	74 17                	je     71f0de <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b5e>
  71f0c7:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
  71f0ce:	00 
  71f0cf:	48 6b f0 38          	imul   $0x38,%rax,%rsi
  71f0d3:	ba 08 00 00 00       	mov    $0x8,%edx
  71f0d8:	ff 15 e2 b7 3c 00    	call   *0x3cb7e2(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f0de:	48 8b 9c 24 88 00 00 	mov    0x88(%rsp),%rbx
  71f0e5:	00 
  71f0e6:	48 85 db             	test   %rbx,%rbx
  71f0e9:	74 64                	je     71f14f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1bcf>
  71f0eb:	4c 8b b4 24 80 00 00 	mov    0x80(%rsp),%r14
  71f0f2:	00 
  71f0f3:	49 81 c6 88 00 00 00 	add    $0x88,%r14
  71f0fa:	eb 10                	jmp    71f10c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b8c>
  71f0fc:	0f 1f 40 00          	nopl   0x0(%rax)
  71f100:	49 81 c6 a8 00 00 00 	add    $0xa8,%r14
  71f107:	48 ff cb             	dec    %rbx
  71f10a:	74 43                	je     71f14f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1bcf>
  71f10c:	41 83 be 78 ff ff ff 	cmpl   $0x2,-0x88(%r14)
  71f113:	02 
  71f114:	74 ea                	je     71f100 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b80>
  71f116:	49 8b 76 90          	mov    -0x70(%r14),%rsi
  71f11a:	48 85 f6             	test   %rsi,%rsi
  71f11d:	74 13                	je     71f132 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1bb2>
  71f11f:	49 8b 7e 98          	mov    -0x68(%r14),%rdi
  71f123:	48 c1 e6 03          	shl    $0x3,%rsi
  71f127:	ba 08 00 00 00       	mov    $0x8,%edx
  71f12c:	ff 15 8e b7 3c 00    	call   *0x3cb78e(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f132:	49 8b 76 f8          	mov    -0x8(%r14),%rsi
  71f136:	48 85 f6             	test   %rsi,%rsi
  71f139:	74 c5                	je     71f100 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b80>
  71f13b:	49 8b 3e             	mov    (%r14),%rdi
  71f13e:	48 c1 e6 05          	shl    $0x5,%rsi
  71f142:	ba 08 00 00 00       	mov    $0x8,%edx
  71f147:	ff 15 73 b7 3c 00    	call   *0x3cb773(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f14d:	eb b1                	jmp    71f100 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1b80>
  71f14f:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  71f154:	48 85 c0             	test   %rax,%rax
  71f157:	74 1a                	je     71f173 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1bf3>
  71f159:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  71f160:	00 
  71f161:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  71f168:	ba 08 00 00 00       	mov    $0x8,%edx
  71f16d:	ff 15 4d b7 3c 00    	call   *0x3cb74d(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f173:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  71f17a:	00 
  71f17b:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
  71f182:	00 
  71f183:	49 ff c6             	inc    %r14
  71f186:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  71f18d:	00 00 00 
  71f190:	49 83 fe 01          	cmp    $0x1,%r14
  71f194:	74 14                	je     71f1aa <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1c2a>
  71f196:	48 8d 9f 98 00 00 00 	lea    0x98(%rdi),%rbx
  71f19d:	49 ff ce             	dec    %r14
  71f1a0:	e8 cb ac ff ff       	call   719e70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element9DraftNodeECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.14596612939337359452>
  71f1a5:	48 89 df             	mov    %rbx,%rdi
  71f1a8:	eb e6                	jmp    71f190 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1c10>
  71f1aa:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  71f1b1:	00 
  71f1b2:	48 85 c0             	test   %rax,%rax
  71f1b5:	74 1a                	je     71f1d1 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1c51>
  71f1b7:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  71f1be:	00 
  71f1bf:	48 69 f0 98 00 00 00 	imul   $0x98,%rax,%rsi
  71f1c6:	ba 08 00 00 00       	mov    $0x8,%edx
  71f1cb:	ff 15 ef b6 3c 00    	call   *0x3cb6ef(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f1d1:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  71f1d6:	48 81 c4 38 07 00 00 	add    $0x738,%rsp
  71f1dd:	5b                   	pop    %rbx
  71f1de:	41 5c                	pop    %r12
  71f1e0:	41 5d                	pop    %r13
  71f1e2:	41 5e                	pop    %r14
  71f1e4:	41 5f                	pop    %r15
  71f1e6:	5d                   	pop    %rbp
  71f1e7:	c3                   	ret
  71f1e8:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  71f1ef:	00 
  71f1f0:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  71f1f7:	00 
  71f1f8:	0f 10 84 24 f0 00 00 	movups 0xf0(%rsp),%xmm0
  71f1ff:	00 
  71f200:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  71f207:	00 
  71f208:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  71f20d:	0f 11 84 24 b8 01 00 	movups %xmm0,0x1b8(%rsp)
  71f214:	00 
  71f215:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  71f21c:	00 
  71f21d:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
  71f224:	00 
  71f225:	0f 10 84 24 10 01 00 	movups 0x110(%rsp),%xmm0
  71f22c:	00 
  71f22d:	0f 29 84 24 d0 01 00 	movaps %xmm0,0x1d0(%rsp)
  71f234:	00 
  71f235:	48 8b 84 24 20 01 00 	mov    0x120(%rsp),%rax
  71f23c:	00 
  71f23d:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
  71f244:	00 
  71f245:	0f 10 84 24 28 01 00 	movups 0x128(%rsp),%xmm0
  71f24c:	00 
  71f24d:	0f 11 84 24 e8 01 00 	movups %xmm0,0x1e8(%rsp)
  71f254:	00 
  71f255:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
  71f25c:	00 
  71f25d:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
  71f264:	00 
  71f265:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  71f26c:	00 
  71f26d:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  71f274:	00 
  71f275:	0f 10 84 24 40 01 00 	movups 0x140(%rsp),%xmm0
  71f27c:	00 
  71f27d:	0f 29 84 24 70 01 00 	movaps %xmm0,0x170(%rsp)
  71f284:	00 
  71f285:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  71f28c:	00 
  71f28d:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  71f294:	00 
  71f295:	0f 10 84 24 58 01 00 	movups 0x158(%rsp),%xmm0
  71f29c:	00 
  71f29d:	0f 11 84 24 88 01 00 	movups %xmm0,0x188(%rsp)
  71f2a4:	00 
  71f2a5:	48 8d b4 24 70 01 00 	lea    0x170(%rsp),%rsi
  71f2ac:	00 
  71f2ad:	ba 90 00 00 00       	mov    $0x90,%edx
  71f2b2:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
  71f2b7:	ff 15 2b b6 3c 00    	call   *0x3cb62b(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  71f2bd:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  71f2c4:	00 
  71f2c5:	48 85 c0             	test   %rax,%rax
  71f2c8:	0f 84 03 ff ff ff    	je     71f1d1 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1c51>
  71f2ce:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
  71f2d5:	00 
  71f2d6:	48 69 f0 e0 00 00 00 	imul   $0xe0,%rax,%rsi
  71f2dd:	e9 e4 fe ff ff       	jmp    71f1c6 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1c46>
  71f2e2:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  71f2e7:	48 c7 40 08 27 00 00 	movq   $0x27,0x8(%rax)
  71f2ee:	00 
  71f2ef:	48 c7 40 10 0c 00 00 	movq   $0xc,0x10(%rax)
  71f2f6:	00 
  71f2f7:	48 c7 00 ff ff ff ff 	movq   $0xffffffffffffffff,(%rax)
  71f2fe:	e9 df f9 ff ff       	jmp    71ece2 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1762>
  71f303:	48 8d 3d 32 98 94 ff 	lea    -0x6b67ce(%rip),%rdi        # 68b3c <anon.b129ae91998be89bd150a4c6c09efb28.4.llvm.16081096212374801285+0x58>
  71f30a:	48 8d 15 9f e0 39 00 	lea    0x39e09f(%rip),%rdx        # abd3b0 <anon.dd9180737c1ef1502723cdb888cc09ab.4.llvm.13290499854095963234+0x180>
  71f311:	be 28 00 00 00       	mov    $0x28,%esi
  71f316:	48 8b 9c 24 a8 00 00 	mov    0xa8(%rsp),%rbx
  71f31d:	00 
  71f31e:	ff 15 d4 b5 3c 00    	call   *0x3cb5d4(%rip)        # aea8f8 <_DYNAMIC+0x280>
  71f324:	eb 4d                	jmp    71f373 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1df3>
  71f326:	bf 08 00 00 00       	mov    $0x8,%edi
  71f32b:	be e0 00 00 00       	mov    $0xe0,%esi
  71f330:	ff 15 ba b5 3c 00    	call   *0x3cb5ba(%rip)        # aea8f0 <_DYNAMIC+0x278>
  71f336:	eb 3b                	jmp    71f373 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1df3>
  71f338:	48 8d 3d 65 97 94 ff 	lea    -0x6b689b(%rip),%rdi        # 68aa4 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x28c>
  71f33f:	48 8d 15 52 e0 39 00 	lea    0x39e052(%rip),%rdx        # abd398 <anon.dd9180737c1ef1502723cdb888cc09ab.4.llvm.13290499854095963234+0x168>
  71f346:	be 7b 00 00 00       	mov    $0x7b,%esi
  71f34b:	ff 15 c7 b5 3c 00    	call   *0x3cb5c7(%rip)        # aea918 <_DYNAMIC+0x2a0>
  71f351:	eb 20                	jmp    71f373 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1df3>
  71f353:	48 8d 15 26 e0 39 00 	lea    0x39e026(%rip),%rdx        # abd380 <anon.dd9180737c1ef1502723cdb888cc09ab.4.llvm.13290499854095963234+0x150>
  71f35a:	48 89 df             	mov    %rbx,%rdi
  71f35d:	ff 15 6d b6 3c 00    	call   *0x3cb66d(%rip)        # aea9d0 <_DYNAMIC+0x358>
  71f363:	eb 0e                	jmp    71f373 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1df3>
  71f365:	bf 08 00 00 00       	mov    $0x8,%edi
  71f36a:	4c 89 f6             	mov    %r14,%rsi
  71f36d:	ff 15 2d b6 3c 00    	call   *0x3cb62d(%rip)        # aea9a0 <_DYNAMIC+0x328>
  71f373:	0f 0b                	ud2
  71f375:	49 89 c4             	mov    %rax,%r12
  71f378:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71f37f:	00 
  71f380:	e8 ab de ff ff       	call   71d230 <_RNvXse_NtNtCscdodAO9FK5_5alloc3vec9into_iterINtB5_8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f385:	b3 01                	mov    $0x1,%bl
  71f387:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  71f38e:	00 00 
  71f390:	e9 da 01 00 00       	jmp    71f56f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1fef>
  71f395:	ff 15 75 b5 3c 00    	call   *0x3cb575(%rip)        # aea910 <_DYNAMIC+0x298>
  71f39b:	49 89 c4             	mov    %rax,%r12
  71f39e:	49 8b 75 08          	mov    0x8(%r13),%rsi
  71f3a2:	eb 49                	jmp    71f3ed <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1e6d>
  71f3a4:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  71f3a9:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  71f3ae:	49 89 c4             	mov    %rax,%r12
  71f3b1:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71f3b6:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71f3ba:	48 85 f6             	test   %rsi,%rsi
  71f3bd:	74 14                	je     71f3d3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1e53>
  71f3bf:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71f3c4:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71f3c8:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71f3cd:	ff 15 ed b4 3c 00    	call   *0x3cb4ed(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f3d3:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f3d7:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f3dc:	e9 fb 04 00 00       	jmp    71f8dc <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x235c>
  71f3e1:	49 89 c4             	mov    %rax,%r12
  71f3e4:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  71f3e9:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71f3ed:	48 85 f6             	test   %rsi,%rsi
  71f3f0:	75 07                	jne    71f3f9 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1e79>
  71f3f2:	31 db                	xor    %ebx,%ebx
  71f3f4:	e9 76 01 00 00       	jmp    71f56f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1fef>
  71f3f9:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  71f3fe:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71f402:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  71f407:	ff 15 b3 b4 3c 00    	call   *0x3cb4b3(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f40d:	31 db                	xor    %ebx,%ebx
  71f40f:	e9 5b 01 00 00       	jmp    71f56f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1fef>
  71f414:	e9 c3 02 00 00       	jmp    71f6dc <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x215c>
  71f419:	49 89 c4             	mov    %rax,%r12
  71f41c:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71f423:	00 
  71f424:	e8 17 13 00 00       	call   720740 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f429:	31 db                	xor    %ebx,%ebx
  71f42b:	e9 b1 02 00 00       	jmp    71f6e1 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2161>
  71f430:	49 89 c4             	mov    %rax,%r12
  71f433:	49 8b 75 08          	mov    0x8(%r13),%rsi
  71f437:	48 85 f6             	test   %rsi,%rsi
  71f43a:	0f 84 e2 03 00 00    	je     71f822 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x22a2>
  71f440:	49 8b 55 10          	mov    0x10(%r13),%rdx
  71f444:	4c 89 f7             	mov    %r14,%rdi
  71f447:	ff 15 73 b4 3c 00    	call   *0x3cb473(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f44d:	e9 d0 03 00 00       	jmp    71f822 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x22a2>
  71f452:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  71f457:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  71f45c:	49 89 c4             	mov    %rax,%r12
  71f45f:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71f464:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71f468:	48 85 f6             	test   %rsi,%rsi
  71f46b:	74 14                	je     71f481 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1f01>
  71f46d:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71f472:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71f476:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  71f47b:	ff 15 3f b4 3c 00    	call   *0x3cb43f(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f481:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71f486:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  71f48b:	e8 80 08 00 00       	call   71fd10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTQL1_INtNtCshBhuxcId5D0_4gpui7element2ElL0_EEEp6OutputuEL_EEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f490:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f494:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f499:	e9 3e 04 00 00       	jmp    71f8dc <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x235c>
  71f49e:	49 89 c4             	mov    %rax,%r12
  71f4a1:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
  71f4a8:	00 00 
  71f4aa:	75 13                	jne    71f4bf <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x1f3f>
  71f4ac:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  71f4b3:	00 00 00 00 00 
  71f4b8:	31 db                	xor    %ebx,%ebx
  71f4ba:	e9 22 02 00 00       	jmp    71f6e1 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2161>
  71f4bf:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  71f4c6:	00 
  71f4c7:	48 8d 34 c5 00 00 00 	lea    0x0(,%rax,8),%rsi
  71f4ce:	00 
  71f4cf:	ba 08 00 00 00       	mov    $0x8,%edx
  71f4d4:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  71f4d9:	ff 15 e1 b3 3c 00    	call   *0x3cb3e1(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f4df:	31 db                	xor    %ebx,%ebx
  71f4e1:	e9 fb 01 00 00       	jmp    71f6e1 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2161>
  71f4e6:	49 89 c4             	mov    %rax,%r12
  71f4e9:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71f4f0:	00 
  71f4f1:	e8 4a 12 00 00       	call   720740 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f4f6:	b0 01                	mov    $0x1,%al
  71f4f8:	89 44 24 14          	mov    %eax,0x14(%rsp)
  71f4fc:	e9 66 03 00 00       	jmp    71f867 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x22e7>
  71f501:	49 89 c4             	mov    %rax,%r12
  71f504:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f508:	e9 91 03 00 00       	jmp    71f89e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x231e>
  71f50d:	e9 ca 01 00 00       	jmp    71f6dc <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x215c>
  71f512:	49 89 c4             	mov    %rax,%r12
  71f515:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71f51a:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71f51e:	48 85 f6             	test   %rsi,%rsi
  71f521:	0f 84 c0 00 00 00    	je     71f5e7 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2067>
  71f527:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  71f52c:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71f530:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71f535:	ff 15 85 b3 3c 00    	call   *0x3cb385(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f53b:	e9 a7 00 00 00       	jmp    71f5e7 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2067>
  71f540:	49 89 c4             	mov    %rax,%r12
  71f543:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71f54a:	00 
  71f54b:	e8 a0 15 00 00       	call   720af0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui8semantic11AnnotationsECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f550:	b3 01                	mov    $0x1,%bl
  71f552:	c7 44 24 14 00 00 00 	movl   $0x0,0x14(%rsp)
  71f559:	00 
  71f55a:	e9 50 03 00 00       	jmp    71f8af <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x232f>
  71f55f:	49 89 c4             	mov    %rax,%r12
  71f562:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71f569:	00 
  71f56a:	e8 c1 14 00 00       	call   720a30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element9DraftNodeECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f56f:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f573:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f578:	e9 32 03 00 00       	jmp    71f8af <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x232f>
  71f57d:	ff 15 8d b3 3c 00    	call   *0x3cb38d(%rip)        # aea910 <_DYNAMIC+0x298>
  71f583:	e9 97 02 00 00       	jmp    71f81f <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x229f>
  71f588:	49 89 c4             	mov    %rax,%r12
  71f58b:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71f592:	00 
  71f593:	e8 e8 12 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71f598:	eb 7b                	jmp    71f615 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2095>
  71f59a:	ff 15 70 b3 3c 00    	call   *0x3cb370(%rip)        # aea910 <_DYNAMIC+0x298>
  71f5a0:	eb 5d                	jmp    71f5ff <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x207f>
  71f5a2:	49 89 c4             	mov    %rax,%r12
  71f5a5:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71f5aa:	48 8b 70 08          	mov    0x8(%rax),%rsi
  71f5ae:	48 85 f6             	test   %rsi,%rsi
  71f5b1:	74 14                	je     71f5c7 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2047>
  71f5b3:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  71f5b8:	48 8b 50 10          	mov    0x10(%rax),%rdx
  71f5bc:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  71f5c1:	ff 15 f9 b2 3c 00    	call   *0x3cb2f9(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f5c7:	b3 01                	mov    $0x1,%bl
  71f5c9:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f5cd:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f5d2:	e9 0c 03 00 00       	jmp    71f8e3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2363>
  71f5d7:	49 89 c4             	mov    %rax,%r12
  71f5da:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71f5df:	4c 89 f6             	mov    %r14,%rsi
  71f5e2:	e8 49 10 00 00       	call   720630 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTQL1_INtNtCshBhuxcId5D0_4gpui7element2ElL0_EEEp6OutputuEL_EECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f5e7:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  71f5ee:	00 
  71f5ef:	e8 8c 12 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71f5f4:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f5f8:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f5fd:	eb 46                	jmp    71f645 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x20c5>
  71f5ff:	49 89 c4             	mov    %rax,%r12
  71f602:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f606:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f60b:	e9 09 03 00 00       	jmp    71f919 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2399>
  71f610:	49 89 c4             	mov    %rax,%r12
  71f613:	b3 01                	mov    $0x1,%bl
  71f615:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  71f61b:	0f 95 c0             	setne  %al
  71f61e:	84 d8                	test   %bl,%al
  71f620:	74 1a                	je     71f63c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x20bc>
  71f622:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71f627:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  71f62c:	e8 ff 0f 00 00       	call   720630 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTQL1_INtNtCshBhuxcId5D0_4gpui7element2ElL0_EEEp6OutputuEL_EECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f631:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f635:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f63a:	eb 09                	jmp    71f645 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x20c5>
  71f63c:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f640:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f645:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  71f64a:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  71f64f:	e8 dc 0f 00 00       	call   720630 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTQL1_INtNtCshBhuxcId5D0_4gpui7element2ElL0_EEEp6OutputuEL_EECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f654:	b3 01                	mov    $0x1,%bl
  71f656:	e9 88 02 00 00       	jmp    71f8e3 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2363>
  71f65b:	49 89 c4             	mov    %rax,%r12
  71f65e:	be 38 00 00 00       	mov    $0x38,%esi
  71f663:	ba 08 00 00 00       	mov    $0x8,%edx
  71f668:	48 89 df             	mov    %rbx,%rdi
  71f66b:	ff 15 4f b2 3c 00    	call   *0x3cb24f(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f671:	e9 96 02 00 00       	jmp    71f90c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x238c>
  71f676:	49 89 c4             	mov    %rax,%r12
  71f679:	b3 01                	mov    $0x1,%bl
  71f67b:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
  71f680:	e9 2a 02 00 00       	jmp    71f8af <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x232f>
  71f685:	49 89 c4             	mov    %rax,%r12
  71f688:	e9 11 02 00 00       	jmp    71f89e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x231e>
  71f68d:	49 89 c4             	mov    %rax,%r12
  71f690:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71f697:	00 
  71f698:	e8 e3 11 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71f69d:	eb 40                	jmp    71f6df <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x215f>
  71f69f:	ff 15 6b b2 3c 00    	call   *0x3cb26b(%rip)        # aea910 <_DYNAMIC+0x298>
  71f6a5:	49 89 c4             	mov    %rax,%r12
  71f6a8:	48 8d bc 24 d0 05 00 	lea    0x5d0(%rsp),%rdi
  71f6af:	00 
  71f6b0:	e8 cb 11 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71f6b5:	eb 28                	jmp    71f6df <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x215f>
  71f6b7:	49 89 c4             	mov    %rax,%r12
  71f6ba:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
  71f6c1:	00 
  71f6c2:	e8 b9 11 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71f6c7:	48 8d bc 24 e0 04 00 	lea    0x4e0(%rsp),%rdi
  71f6ce:	00 
  71f6cf:	e8 ac 11 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71f6d4:	eb 09                	jmp    71f6df <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x215f>
  71f6d6:	ff 15 34 b2 3c 00    	call   *0x3cb234(%rip)        # aea910 <_DYNAMIC+0x298>
  71f6dc:	49 89 c4             	mov    %rax,%r12
  71f6df:	b3 01                	mov    $0x1,%bl
  71f6e1:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
  71f6e8:	00 
  71f6e9:	e8 72 0e 00 00       	call   720560 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecTINtNtB4_6option6OptionmENtNtCshBhuxcId5D0_4gpui7element2ElIB19_TjNtNtB1A_4list7ItemKeymffEEEEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f6ee:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f6f2:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f6f7:	84 db                	test   %bl,%bl
  71f6f9:	0f 85 7e 01 00 00    	jne    71f87d <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x22fd>
  71f6ff:	e9 9a 01 00 00       	jmp    71f89e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x231e>
  71f704:	49 89 c4             	mov    %rax,%r12
  71f707:	48 ff cb             	dec    %rbx
  71f70a:	74 14                	je     71f720 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x21a0>
  71f70c:	4d 8d b7 e0 00 00 00 	lea    0xe0(%r15),%r14
  71f713:	4c 89 ff             	mov    %r15,%rdi
  71f716:	e8 a5 a5 ff ff       	call   719cc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.14596612939337359452>
  71f71b:	4d 89 f7             	mov    %r14,%r15
  71f71e:	eb e7                	jmp    71f707 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2187>
  71f720:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  71f727:	00 
  71f728:	48 85 c0             	test   %rax,%rax
  71f72b:	0f 84 43 01 00 00    	je     71f874 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x22f4>
  71f731:	48 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%rdi
  71f738:	00 
  71f739:	48 69 f0 e0 00 00 00 	imul   $0xe0,%rax,%rsi
  71f740:	ba 08 00 00 00       	mov    $0x8,%edx
  71f745:	ff 15 75 b1 3c 00    	call   *0x3cb175(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f74b:	e9 24 01 00 00       	jmp    71f874 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x22f4>
  71f750:	ff 15 ba b1 3c 00    	call   *0x3cb1ba(%rip)        # aea910 <_DYNAMIC+0x298>
  71f756:	49 89 c4             	mov    %rax,%r12
  71f759:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  71f760:	49 ff ce             	dec    %r14
  71f763:	74 14                	je     71f779 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x21f9>
  71f765:	4c 8d bb 98 00 00 00 	lea    0x98(%rbx),%r15
  71f76c:	48 89 df             	mov    %rbx,%rdi
  71f76f:	e8 fc a6 ff ff       	call   719e70 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element9DraftNodeECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.14596612939337359452>
  71f774:	4c 89 fb             	mov    %r15,%rbx
  71f777:	eb e7                	jmp    71f760 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x21e0>
  71f779:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  71f780:	00 
  71f781:	48 85 c0             	test   %rax,%rax
  71f784:	0f 84 13 02 00 00    	je     71f99d <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x241d>
  71f78a:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  71f791:	00 
  71f792:	48 69 f0 98 00 00 00 	imul   $0x98,%rax,%rsi
  71f799:	ba 08 00 00 00       	mov    $0x8,%edx
  71f79e:	ff 15 1c b1 3c 00    	call   *0x3cb11c(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f7a4:	4c 89 e7             	mov    %r12,%rdi
  71f7a7:	e8 f4 b8 39 00       	call   abb0a0 <_Unwind_Resume@plt>
  71f7ac:	ff 15 5e b1 3c 00    	call   *0x3cb15e(%rip)        # aea910 <_DYNAMIC+0x298>
  71f7b2:	49 89 c4             	mov    %rax,%r12
  71f7b5:	49 ff ce             	dec    %r14
  71f7b8:	74 14                	je     71f7ce <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x224e>
  71f7ba:	4c 8d bb e0 00 00 00 	lea    0xe0(%rbx),%r15
  71f7c1:	48 89 df             	mov    %rbx,%rdi
  71f7c4:	e8 f7 a4 ff ff       	call   719cc0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.14596612939337359452>
  71f7c9:	4c 89 fb             	mov    %r15,%rbx
  71f7cc:	eb e7                	jmp    71f7b5 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2235>
  71f7ce:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  71f7d5:	00 
  71f7d6:	48 85 c0             	test   %rax,%rax
  71f7d9:	74 1a                	je     71f7f5 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2275>
  71f7db:	48 8b bc 24 b8 00 00 	mov    0xb8(%rsp),%rdi
  71f7e2:	00 
  71f7e3:	48 69 f0 e0 00 00 00 	imul   $0xe0,%rax,%rsi
  71f7ea:	ba 08 00 00 00       	mov    $0x8,%edx
  71f7ef:	ff 15 cb b0 3c 00    	call   *0x3cb0cb(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f7f5:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f7f9:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f7fe:	e9 23 01 00 00       	jmp    71f926 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x23a6>
  71f803:	ff 15 07 b1 3c 00    	call   *0x3cb107(%rip)        # aea910 <_DYNAMIC+0x298>
  71f809:	49 89 c4             	mov    %rax,%r12
  71f80c:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f810:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f815:	48 8b 9c 24 a8 00 00 	mov    0xa8(%rsp),%rbx
  71f81c:	00 
  71f81d:	eb 25                	jmp    71f844 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x22c4>
  71f81f:	49 89 c4             	mov    %rax,%r12
  71f822:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f826:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f82b:	e9 dc 00 00 00       	jmp    71f90c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x238c>
  71f830:	49 89 c4             	mov    %rax,%r12
  71f833:	e9 ee 00 00 00       	jmp    71f926 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x23a6>
  71f838:	49 89 c4             	mov    %rax,%r12
  71f83b:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f83f:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f844:	b0 01                	mov    $0x1,%al
  71f846:	89 44 24 14          	mov    %eax,0x14(%rsp)
  71f84a:	48 85 db             	test   %rbx,%rbx
  71f84d:	74 18                	je     71f867 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x22e7>
  71f84f:	48 c1 e3 03          	shl    $0x3,%rbx
  71f853:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  71f857:	ba 08 00 00 00       	mov    $0x8,%edx
  71f85c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  71f861:	ff 15 59 b0 3c 00    	call   *0x3cb059(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f867:	b0 01                	mov    $0x1,%al
  71f869:	89 44 24 1c          	mov    %eax,0x1c(%rsp)
  71f86d:	b3 01                	mov    $0x1,%bl
  71f86f:	eb 3e                	jmp    71f8af <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x232f>
  71f871:	49 89 c4             	mov    %rax,%r12
  71f874:	4c 8b 3c 24          	mov    (%rsp),%r15
  71f878:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71f87d:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  71f884:	00 
  71f885:	48 85 f6             	test   %rsi,%rsi
  71f888:	74 14                	je     71f89e <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x231e>
  71f88a:	48 c1 e6 03          	shl    $0x3,%rsi
  71f88e:	ba 08 00 00 00       	mov    $0x8,%edx
  71f893:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  71f898:	ff 15 22 b0 3c 00    	call   *0x3cb022(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f89e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  71f8a3:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  71f8a8:	e8 63 04 00 00       	call   71fd10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTQL1_INtNtCshBhuxcId5D0_4gpui7element2ElL0_EEEp6OutputuEL_EEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f8ad:	31 db                	xor    %ebx,%ebx
  71f8af:	48 83 7c 24 40 00    	cmpq   $0x0,0x40(%rsp)
  71f8b5:	74 25                	je     71f8dc <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x235c>
  71f8b7:	80 7c 24 1c 00       	cmpb   $0x0,0x1c(%rsp)
  71f8bc:	74 1e                	je     71f8dc <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x235c>
  71f8be:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  71f8c3:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  71f8c8:	e8 63 0d 00 00       	call   720630 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTQL1_INtNtCshBhuxcId5D0_4gpui7element2ElL0_EEEp6OutputuEL_EECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f8cd:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  71f8d2:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  71f8d7:	e8 34 04 00 00       	call   71fd10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTQL1_INtNtCshBhuxcId5D0_4gpui7element2ElL0_EEEp6OutputuEL_EEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f8dc:	80 7c 24 14 00       	cmpb   $0x0,0x14(%rsp)
  71f8e1:	74 0d                	je     71f8f0 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2370>
  71f8e3:	48 8d bc 24 50 02 00 	lea    0x250(%rsp),%rdi
  71f8ea:	00 
  71f8eb:	e8 00 12 00 00       	call   720af0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui8semantic11AnnotationsECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f8f0:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
  71f8f6:	0f 95 c0             	setne  %al
  71f8f9:	84 d8                	test   %bl,%al
  71f8fb:	74 0f                	je     71f90c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x238c>
  71f8fd:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  71f902:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  71f907:	e8 04 04 00 00       	call   71fd10 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_6option6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxDG0_INtNtNtB4_3ops8function2FnTQL1_INtNtCshBhuxcId5D0_4gpui7element2ElL0_EEEp6OutputuEL_EEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f90c:	48 8d bc 24 30 04 00 	lea    0x430(%rsp),%rdi
  71f913:	00 
  71f914:	e8 67 0f 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71f919:	48 8d bc 24 b0 00 00 	lea    0xb0(%rsp),%rdi
  71f920:	00 
  71f921:	e8 3a 0c 00 00       	call   720560 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecTINtNtB4_6option6OptionmENtNtCshBhuxcId5D0_4gpui7element2ElIB19_TjNtNtB1A_4list7ItemKeymffEEEEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f926:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  71f92d:	00 
  71f92e:	48 85 c0             	test   %rax,%rax
  71f931:	75 72                	jne    71f9a5 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2425>
  71f933:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  71f93a:	00 
  71f93b:	48 85 f6             	test   %rsi,%rsi
  71f93e:	0f 85 8d 00 00 00    	jne    71f9d1 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x2451>
  71f944:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  71f94b:	00 
  71f94c:	48 85 c0             	test   %rax,%rax
  71f94f:	74 1b                	je     71f96c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x23ec>
  71f951:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  71f958:	00 
  71f959:	48 c1 e0 03          	shl    $0x3,%rax
  71f95d:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  71f961:	ba 08 00 00 00       	mov    $0x8,%edx
  71f966:	ff 15 54 af 3c 00    	call   *0x3caf54(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f96c:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
  71f973:	00 
  71f974:	e8 37 0b 00 00       	call   7204b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCshBhuxcId5D0_4gpui8semantic15AnnotationDraftEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f979:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
  71f97e:	e8 dd 08 00 00       	call   720260 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f983:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  71f98a:	00 
  71f98b:	e8 50 0a 00 00       	call   7203e0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecNtNtCshBhuxcId5D0_4gpui7element9DraftNodeEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71f990:	4d 85 ed             	test   %r13,%r13
  71f993:	75 08                	jne    71f99d <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x241d>
  71f995:	4c 89 ff             	mov    %r15,%rdi
  71f998:	e8 e3 0e 00 00       	call   720880 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtCshBhuxcId5D0_4gpui7element2ElECs4gwBMgNbBwV_27sibling_reconciliation_cost.llvm.16081096212374801285>
  71f99d:	4c 89 e7             	mov    %r12,%rdi
  71f9a0:	e8 fb b6 39 00       	call   abb0a0 <_Unwind_Resume@plt>
  71f9a5:	48 8b bc 24 60 01 00 	mov    0x160(%rsp),%rdi
  71f9ac:	00 
  71f9ad:	48 c1 e0 03          	shl    $0x3,%rax
  71f9b1:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  71f9b5:	ba 08 00 00 00       	mov    $0x8,%edx
  71f9ba:	ff 15 00 af 3c 00    	call   *0x3caf00(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f9c0:	48 8b b4 24 40 01 00 	mov    0x140(%rsp),%rsi
  71f9c7:	00 
  71f9c8:	48 85 f6             	test   %rsi,%rsi
  71f9cb:	0f 84 73 ff ff ff    	je     71f944 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x23c4>
  71f9d1:	48 8b bc 24 48 01 00 	mov    0x148(%rsp),%rdi
  71f9d8:	00 
  71f9d9:	48 c1 e6 04          	shl    $0x4,%rsi
  71f9dd:	ba 08 00 00 00       	mov    $0x8,%edx
  71f9e2:	ff 15 d8 ae 3c 00    	call   *0x3caed8(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71f9e8:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  71f9ef:	00 
  71f9f0:	48 85 c0             	test   %rax,%rax
  71f9f3:	0f 85 58 ff ff ff    	jne    71f951 <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x23d1>
  71f9f9:	e9 6e ff ff ff       	jmp    71f96c <_RINvMs5_NtCshBhuxcId5D0_4gpui7elementNtB6_2El13flatten_listsNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0EB1y_+0x23ec>
  71f9fe:	ff 15 0c af 3c 00    	call   *0x3caf0c(%rip)        # aea910 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
