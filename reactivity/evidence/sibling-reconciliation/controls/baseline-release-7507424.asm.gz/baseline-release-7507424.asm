
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000728de0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_>:
  728de0:	55                   	push   %rbp
  728de1:	41 57                	push   %r15
  728de3:	41 56                	push   %r14
  728de5:	41 55                	push   %r13
  728de7:	41 54                	push   %r12
  728de9:	53                   	push   %rbx
  728dea:	48 83 ec 28          	sub    $0x28,%rsp
  728dee:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  728df3:	49 89 f6             	mov    %rsi,%r14
  728df6:	49 89 ff             	mov    %rdi,%r15
  728df9:	48 83 fe 21          	cmp    $0x21,%rsi
  728dfd:	73 1e                	jae    728e1d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x3d>
  728dff:	4c 89 ff             	mov    %r15,%rdi
  728e02:	4c 89 f6             	mov    %r14,%rsi
  728e05:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  728e0a:	48 83 c4 28          	add    $0x28,%rsp
  728e0e:	5b                   	pop    %rbx
  728e0f:	41 5c                	pop    %r12
  728e11:	41 5d                	pop    %r13
  728e13:	41 5e                	pop    %r14
  728e15:	41 5f                	pop    %r15
  728e17:	5d                   	pop    %rbp
  728e18:	e9 d3 90 fe ff       	jmp    711ef0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_>
  728e1d:	89 cb                	mov    %ecx,%ebx
  728e1f:	49 89 d4             	mov    %rdx,%r12
  728e22:	49 89 e5             	mov    %rsp,%r13
  728e25:	eb 5e                	jmp    728e85 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0xa5>
  728e27:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  728e2e:	00 00 
  728e30:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  728e34:	49 8b 57 10          	mov    0x10(%r15),%rdx
  728e38:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  728e3d:	41 0f 10 07          	movups (%r15),%xmm0
  728e41:	0f 29 04 24          	movaps %xmm0,(%rsp)
  728e45:	49 8b 54 cf 10       	mov    0x10(%r15,%rcx,8),%rdx
  728e4a:	41 0f 10 04 cf       	movups (%r15,%rcx,8),%xmm0
  728e4f:	41 0f 11 07          	movups %xmm0,(%r15)
  728e53:	49 89 57 10          	mov    %rdx,0x10(%r15)
  728e57:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  728e5c:	49 89 54 cf 10       	mov    %rdx,0x10(%r15,%rcx,8)
  728e61:	0f 28 04 24          	movaps (%rsp),%xmm0
  728e65:	41 0f 11 04 cf       	movups %xmm0,(%r15,%rcx,8)
  728e6a:	48 f7 d0             	not    %rax
  728e6d:	49 01 c6             	add    %rax,%r14
  728e70:	4d 8d 3c cf          	lea    (%r15,%rcx,8),%r15
  728e74:	49 83 c7 18          	add    $0x18,%r15
  728e78:	45 31 e4             	xor    %r12d,%r12d
  728e7b:	49 83 fe 21          	cmp    $0x21,%r14
  728e7f:	0f 82 7a ff ff ff    	jb     728dff <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x1f>
  728e85:	85 db                	test   %ebx,%ebx
  728e87:	0f 84 44 03 00 00    	je     7291d1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x3f1>
  728e8d:	4c 89 f1             	mov    %r14,%rcx
  728e90:	48 c1 e9 03          	shr    $0x3,%rcx
  728e94:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  728e98:	48 c1 e0 05          	shl    $0x5,%rax
  728e9c:	4c 01 f8             	add    %r15,%rax
  728e9f:	48 69 d1 a8 00 00 00 	imul   $0xa8,%rcx,%rdx
  728ea6:	4c 01 fa             	add    %r15,%rdx
  728ea9:	49 83 fe 40          	cmp    $0x40,%r14
  728ead:	73 41                	jae    728ef0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x110>
  728eaf:	49 8b 0f             	mov    (%r15),%rcx
  728eb2:	48 8b 30             	mov    (%rax),%rsi
  728eb5:	48 39 f1             	cmp    %rsi,%rcx
  728eb8:	40 0f 92 c7          	setb   %dil
  728ebc:	4c 8b 02             	mov    (%rdx),%r8
  728ebf:	4c 39 c1             	cmp    %r8,%rcx
  728ec2:	0f 92 c1             	setb   %cl
  728ec5:	40 30 f9             	xor    %dil,%cl
  728ec8:	4c 39 c6             	cmp    %r8,%rsi
  728ecb:	40 0f 92 c6          	setb   %sil
  728ecf:	40 30 fe             	xor    %dil,%sil
  728ed2:	48 0f 45 c2          	cmovne %rdx,%rax
  728ed6:	84 c9                	test   %cl,%cl
  728ed8:	49 0f 45 c7          	cmovne %r15,%rax
  728edc:	ff cb                	dec    %ebx
  728ede:	4c 29 f8             	sub    %r15,%rax
  728ee1:	4d 85 e4             	test   %r12,%r12
  728ee4:	75 24                	jne    728f0a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x12a>
  728ee6:	eb 30                	jmp    728f18 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x138>
  728ee8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  728eef:	00 
  728ef0:	4c 89 ff             	mov    %r15,%rdi
  728ef3:	48 89 c6             	mov    %rax,%rsi
  728ef6:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  728efb:	e8 30 0e 00 00       	call   729d30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2X_>
  728f00:	ff cb                	dec    %ebx
  728f02:	4c 29 f8             	sub    %r15,%rax
  728f05:	4d 85 e4             	test   %r12,%r12
  728f08:	74 0e                	je     728f18 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x138>
  728f0a:	49 8b 0c 24          	mov    (%r12),%rcx
  728f0e:	49 3b 0c 07          	cmp    (%r15,%rax,1),%rcx
  728f12:	0f 83 98 01 00 00    	jae    7290b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x2d0>
  728f18:	89 5c 24 24          	mov    %ebx,0x24(%rsp)
  728f1c:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  728f20:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  728f25:	41 0f 10 07          	movups (%r15),%xmm0
  728f29:	0f 29 04 24          	movaps %xmm0,(%rsp)
  728f2d:	49 8b 4c 07 10       	mov    0x10(%r15,%rax,1),%rcx
  728f32:	41 0f 10 04 07       	movups (%r15,%rax,1),%xmm0
  728f37:	41 0f 11 07          	movups %xmm0,(%r15)
  728f3b:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  728f3f:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  728f44:	49 89 4c 07 10       	mov    %rcx,0x10(%r15,%rax,1)
  728f49:	0f 28 04 24          	movaps (%rsp),%xmm0
  728f4d:	41 0f 11 04 07       	movups %xmm0,(%r15,%rax,1)
  728f52:	49 8d 47 18          	lea    0x18(%r15),%rax
  728f56:	49 8b 4f 28          	mov    0x28(%r15),%rcx
  728f5a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  728f5f:	41 0f 10 47 18       	movups 0x18(%r15),%xmm0
  728f64:	0f 29 04 24          	movaps %xmm0,(%rsp)
  728f68:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
  728f6f:	00 
  728f70:	48 8d 3c 76          	lea    (%rsi,%rsi,2),%rdi
  728f74:	4c 01 ff             	add    %r15,%rdi
  728f77:	49 8d 4f 30          	lea    0x30(%r15),%rcx
  728f7b:	49 8b 17             	mov    (%r15),%rdx
  728f7e:	4c 8d 1c 76          	lea    (%rsi,%rsi,2),%r11
  728f82:	49 83 c3 b8          	add    $0xffffffffffffffb8,%r11
  728f86:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  728f8a:	49 83 c2 d0          	add    $0xffffffffffffffd0,%r10
  728f8e:	31 f6                	xor    %esi,%esi
  728f90:	4c 8b 41 10          	mov    0x10(%rcx),%r8
  728f94:	48 39 11             	cmp    %rdx,(%rcx)
  728f97:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  728f9b:	4a 8b 5c c8 10       	mov    0x10(%rax,%r9,8),%rbx
  728fa0:	42 0f 10 04 c8       	movups (%rax,%r9,8),%xmm0
  728fa5:	0f 11 41 e8          	movups %xmm0,-0x18(%rcx)
  728fa9:	48 89 59 f8          	mov    %rbx,-0x8(%rcx)
  728fad:	4e 89 44 c8 10       	mov    %r8,0x10(%rax,%r9,8)
  728fb2:	0f 10 01             	movups (%rcx),%xmm0
  728fb5:	42 0f 11 04 c8       	movups %xmm0,(%rax,%r9,8)
  728fba:	48 83 d6 00          	adc    $0x0,%rsi
  728fbe:	48 83 c1 18          	add    $0x18,%rcx
  728fc2:	4d 89 d8             	mov    %r11,%r8
  728fc5:	49 83 c3 e8          	add    $0xffffffffffffffe8,%r11
  728fc9:	4d 89 d1             	mov    %r10,%r9
  728fcc:	49 83 c2 e8          	add    $0xffffffffffffffe8,%r10
  728fd0:	48 39 f9             	cmp    %rdi,%rcx
  728fd3:	72 bb                	jb     728f90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x1b0>
  728fd5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  728fdc:	00 00 00 00 
  728fe0:	4d 85 c0             	test   %r8,%r8
  728fe3:	48 89 cf             	mov    %rcx,%rdi
  728fe6:	49 0f 44 fd          	cmove  %r13,%rdi
  728fea:	48 39 17             	cmp    %rdx,(%rdi)
  728fed:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  728ff1:	42 0f 10 04 d0       	movups (%rax,%r10,8),%xmm0
  728ff6:	4e 8b 5c d0 10       	mov    0x10(%rax,%r10,8),%r11
  728ffb:	4c 89 59 f8          	mov    %r11,-0x8(%rcx)
  728fff:	0f 11 41 e8          	movups %xmm0,-0x18(%rcx)
  729003:	4c 8b 5f 10          	mov    0x10(%rdi),%r11
  729007:	4e 89 5c d0 10       	mov    %r11,0x10(%rax,%r10,8)
  72900c:	0f 10 07             	movups (%rdi),%xmm0
  72900f:	48 83 d6 00          	adc    $0x0,%rsi
  729013:	42 0f 11 04 d0       	movups %xmm0,(%rax,%r10,8)
  729018:	48 83 c1 18          	add    $0x18,%rcx
  72901c:	49 83 c0 e8          	add    $0xffffffffffffffe8,%r8
  729020:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  729024:	75 ba                	jne    728fe0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x200>
  729026:	4c 39 f6             	cmp    %r14,%rsi
  729029:	0f 83 a0 01 00 00    	jae    7291cf <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x3ef>
  72902f:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
  729033:	49 8d 1c c7          	lea    (%r15,%rax,8),%rbx
  729037:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  72903b:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  729040:	41 0f 10 07          	movups (%r15),%xmm0
  729044:	0f 29 04 24          	movaps %xmm0,(%rsp)
  729048:	49 8b 4c c7 10       	mov    0x10(%r15,%rax,8),%rcx
  72904d:	41 0f 10 04 c7       	movups (%r15,%rax,8),%xmm0
  729052:	41 0f 11 07          	movups %xmm0,(%r15)
  729056:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  72905a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  72905f:	49 89 4c c7 10       	mov    %rcx,0x10(%r15,%rax,8)
  729064:	0f 28 04 24          	movaps (%rsp),%xmm0
  729068:	41 0f 11 04 c7       	movups %xmm0,(%r15,%rax,8)
  72906d:	49 8d 2c c7          	lea    (%r15,%rax,8),%rbp
  729071:	48 83 c5 18          	add    $0x18,%rbp
  729075:	48 89 f0             	mov    %rsi,%rax
  729078:	48 f7 d0             	not    %rax
  72907b:	49 01 c6             	add    %rax,%r14
  72907e:	4c 89 ff             	mov    %r15,%rdi
  729081:	4c 89 e2             	mov    %r12,%rdx
  729084:	44 8b 7c 24 24       	mov    0x24(%rsp),%r15d
  729089:	44 89 f9             	mov    %r15d,%ecx
  72908c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  729091:	e8 4a fd ff ff       	call   728de0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_>
  729096:	49 89 dc             	mov    %rbx,%r12
  729099:	44 89 fb             	mov    %r15d,%ebx
  72909c:	49 89 ef             	mov    %rbp,%r15
  72909f:	49 83 fe 21          	cmp    $0x21,%r14
  7290a3:	0f 83 dc fd ff ff    	jae    728e85 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0xa5>
  7290a9:	e9 51 fd ff ff       	jmp    728dff <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x1f>
  7290ae:	66 90                	xchg   %ax,%ax
  7290b0:	4c 01 f8             	add    %r15,%rax
  7290b3:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  7290b7:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  7290bc:	41 0f 10 07          	movups (%r15),%xmm0
  7290c0:	0f 29 04 24          	movaps %xmm0,(%rsp)
  7290c4:	48 8b 48 10          	mov    0x10(%rax),%rcx
  7290c8:	0f 10 00             	movups (%rax),%xmm0
  7290cb:	41 0f 11 07          	movups %xmm0,(%r15)
  7290cf:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  7290d3:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  7290d8:	48 89 48 10          	mov    %rcx,0x10(%rax)
  7290dc:	0f 28 04 24          	movaps (%rsp),%xmm0
  7290e0:	0f 11 00             	movups %xmm0,(%rax)
  7290e3:	49 8d 4f 18          	lea    0x18(%r15),%rcx
  7290e7:	49 8b 47 28          	mov    0x28(%r15),%rax
  7290eb:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  7290f0:	41 0f 10 47 18       	movups 0x18(%r15),%xmm0
  7290f5:	0f 29 04 24          	movaps %xmm0,(%rsp)
  7290f9:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
  729100:	00 
  729101:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
  729105:	4c 01 ff             	add    %r15,%rdi
  729108:	49 8d 57 30          	lea    0x30(%r15),%rdx
  72910c:	49 8b 37             	mov    (%r15),%rsi
  72910f:	4c 8d 1c 40          	lea    (%rax,%rax,2),%r11
  729113:	49 83 c3 b8          	add    $0xffffffffffffffb8,%r11
  729117:	4c 8d 14 40          	lea    (%rax,%rax,2),%r10
  72911b:	49 83 c2 d0          	add    $0xffffffffffffffd0,%r10
  72911f:	31 c0                	xor    %eax,%eax
  729121:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  729128:	0f 1f 84 00 00 00 00 
  72912f:	00 
  729130:	48 3b 32             	cmp    (%rdx),%rsi
  729133:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
  729137:	4e 8b 4c c1 10       	mov    0x10(%rcx,%r8,8),%r9
  72913c:	42 0f 10 04 c1       	movups (%rcx,%r8,8),%xmm0
  729141:	0f 11 42 e8          	movups %xmm0,-0x18(%rdx)
  729145:	4c 89 4a f8          	mov    %r9,-0x8(%rdx)
  729149:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
  72914d:	4e 89 4c c1 10       	mov    %r9,0x10(%rcx,%r8,8)
  729152:	0f 10 02             	movups (%rdx),%xmm0
  729155:	42 0f 11 04 c1       	movups %xmm0,(%rcx,%r8,8)
  72915a:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72915e:	48 83 c2 18          	add    $0x18,%rdx
  729162:	4d 89 d8             	mov    %r11,%r8
  729165:	49 83 c3 e8          	add    $0xffffffffffffffe8,%r11
  729169:	4d 89 d1             	mov    %r10,%r9
  72916c:	49 83 c2 e8          	add    $0xffffffffffffffe8,%r10
  729170:	48 39 fa             	cmp    %rdi,%rdx
  729173:	72 bb                	jb     729130 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x350>
  729175:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72917c:	00 00 00 00 
  729180:	4d 85 c0             	test   %r8,%r8
  729183:	48 89 d7             	mov    %rdx,%rdi
  729186:	49 0f 44 fd          	cmove  %r13,%rdi
  72918a:	48 3b 37             	cmp    (%rdi),%rsi
  72918d:	4c 8d 14 40          	lea    (%rax,%rax,2),%r10
  729191:	42 0f 10 04 d1       	movups (%rcx,%r10,8),%xmm0
  729196:	4e 8b 5c d1 10       	mov    0x10(%rcx,%r10,8),%r11
  72919b:	4c 89 5a f8          	mov    %r11,-0x8(%rdx)
  72919f:	0f 11 42 e8          	movups %xmm0,-0x18(%rdx)
  7291a3:	4c 8b 5f 10          	mov    0x10(%rdi),%r11
  7291a7:	4e 89 5c d1 10       	mov    %r11,0x10(%rcx,%r10,8)
  7291ac:	0f 10 07             	movups (%rdi),%xmm0
  7291af:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  7291b3:	42 0f 11 04 d1       	movups %xmm0,(%rcx,%r10,8)
  7291b8:	48 83 c2 18          	add    $0x18,%rdx
  7291bc:	49 83 c0 e8          	add    $0xffffffffffffffe8,%r8
  7291c0:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  7291c4:	75 ba                	jne    729180 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x3a0>
  7291c6:	4c 39 f0             	cmp    %r14,%rax
  7291c9:	0f 82 61 fc ff ff    	jb     728e30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_+0x50>
  7291cf:	0f 0b                	ud2
  7291d1:	4c 89 ff             	mov    %r15,%rdi
  7291d4:	4c 89 f6             	mov    %r14,%rsi
  7291d7:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  7291dc:	48 83 c4 28          	add    $0x28,%rsp
  7291e0:	5b                   	pop    %rbx
  7291e1:	41 5c                	pop    %r12
  7291e3:	41 5d                	pop    %r13
  7291e5:	41 5e                	pop    %r14
  7291e7:	41 5f                	pop    %r15
  7291e9:	5d                   	pop    %rbp
  7291ea:	e9 71 9c 00 00       	jmp    732e60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
