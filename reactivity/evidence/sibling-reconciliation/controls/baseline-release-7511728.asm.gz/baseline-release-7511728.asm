
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000729eb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>:
  729eb0:	55                   	push   %rbp
  729eb1:	41 57                	push   %r15
  729eb3:	41 56                	push   %r14
  729eb5:	41 55                	push   %r13
  729eb7:	41 54                	push   %r12
  729eb9:	53                   	push   %rbx
  729eba:	50                   	push   %rax
  729ebb:	49 89 d6             	mov    %rdx,%r14
  729ebe:	48 89 f3             	mov    %rsi,%rbx
  729ec1:	48 83 f9 08          	cmp    $0x8,%rcx
  729ec5:	72 5c                	jb     729f23 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_+0x73>
  729ec7:	48 c1 e9 03          	shr    $0x3,%rcx
  729ecb:	48 89 c8             	mov    %rcx,%rax
  729ece:	48 c1 e0 05          	shl    $0x5,%rax
  729ed2:	4c 8d 3c 40          	lea    (%rax,%rax,2),%r15
  729ed6:	4a 8d 34 3f          	lea    (%rdi,%r15,1),%rsi
  729eda:	4c 69 e1 a8 00 00 00 	imul   $0xa8,%rcx,%r12
  729ee1:	4a 8d 14 27          	lea    (%rdi,%r12,1),%rdx
  729ee5:	49 89 cd             	mov    %rcx,%r13
  729ee8:	e8 c3 ff ff ff       	call   729eb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  729eed:	48 89 c5             	mov    %rax,%rbp
  729ef0:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
  729ef4:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
  729ef8:	48 89 df             	mov    %rbx,%rdi
  729efb:	4c 89 e9             	mov    %r13,%rcx
  729efe:	e8 ad ff ff ff       	call   729eb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  729f03:	48 89 c3             	mov    %rax,%rbx
  729f06:	4d 01 f7             	add    %r14,%r15
  729f09:	4d 01 f4             	add    %r14,%r12
  729f0c:	4c 89 f7             	mov    %r14,%rdi
  729f0f:	4c 89 fe             	mov    %r15,%rsi
  729f12:	4c 89 e2             	mov    %r12,%rdx
  729f15:	4c 89 e9             	mov    %r13,%rcx
  729f18:	e8 93 ff ff ff       	call   729eb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  729f1d:	48 89 ef             	mov    %rbp,%rdi
  729f20:	49 89 c6             	mov    %rax,%r14
  729f23:	48 8b 07             	mov    (%rdi),%rax
  729f26:	48 8b 0b             	mov    (%rbx),%rcx
  729f29:	48 39 c8             	cmp    %rcx,%rax
  729f2c:	0f 92 c2             	setb   %dl
  729f2f:	49 8b 36             	mov    (%r14),%rsi
  729f32:	48 39 f0             	cmp    %rsi,%rax
  729f35:	0f 92 c0             	setb   %al
  729f38:	30 d0                	xor    %dl,%al
  729f3a:	48 39 f1             	cmp    %rsi,%rcx
  729f3d:	0f 92 c1             	setb   %cl
  729f40:	30 d1                	xor    %dl,%cl
  729f42:	49 0f 45 de          	cmovne %r14,%rbx
  729f46:	84 c0                	test   %al,%al
  729f48:	48 0f 45 df          	cmovne %rdi,%rbx
  729f4c:	48 89 d8             	mov    %rbx,%rax
  729f4f:	48 83 c4 08          	add    $0x8,%rsp
  729f53:	5b                   	pop    %rbx
  729f54:	41 5c                	pop    %r12
  729f56:	41 5d                	pop    %r13
  729f58:	41 5e                	pop    %r14
  729f5a:	41 5f                	pop    %r15
  729f5c:	5d                   	pop    %rbp
  729f5d:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
