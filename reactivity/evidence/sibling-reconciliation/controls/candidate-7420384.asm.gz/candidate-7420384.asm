
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000007139e0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_>:
  7139e0:	55                   	push   %rbp
  7139e1:	41 57                	push   %r15
  7139e3:	41 56                	push   %r14
  7139e5:	41 55                	push   %r13
  7139e7:	41 54                	push   %r12
  7139e9:	53                   	push   %rbx
  7139ea:	48 83 ec 58          	sub    $0x58,%rsp
  7139ee:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  7139f3:	4c 8b 7e 10          	mov    0x10(%rsi),%r15
  7139f7:	4c 8b 2e             	mov    (%rsi),%r13
  7139fa:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  7139fe:	48 8d 46 20          	lea    0x20(%rsi),%rax
  713a02:	48 8b 6e 18          	mov    0x18(%rsi),%rbp
  713a06:	4d 85 ff             	test   %r15,%r15
  713a09:	74 09                	je     713a14 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x34>
  713a0b:	49 39 ef             	cmp    %rbp,%r15
  713a0e:	0f 85 a4 00 00 00    	jne    713ab8 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xd8>
  713a14:	4d 85 ed             	test   %r13,%r13
  713a17:	74 4e                	je     713a67 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x87>
  713a19:	49 39 fd             	cmp    %rdi,%r13
  713a1c:	74 49                	je     713a67 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x87>
  713a1e:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  713a25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  713a2c:	00 00 00 00 
  713a30:	4d 8b 7d e0          	mov    -0x20(%r13),%r15
  713a34:	49 8b 6d e8          	mov    -0x18(%r13),%rbp
  713a38:	48 85 ed             	test   %rbp,%rbp
  713a3b:	75 6a                	jne    713aa7 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xc7>
  713a3d:	49 8d 8d a8 00 00 00 	lea    0xa8(%r13),%rcx
  713a44:	49 39 fd             	cmp    %rdi,%r13
  713a47:	49 89 cd             	mov    %rcx,%r13
  713a4a:	75 e4                	jne    713a30 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x50>
  713a4c:	48 8d 91 b0 fe ff ff 	lea    -0x150(%rcx),%rdx
  713a53:	48 89 10             	mov    %rdx,(%rax)
  713a56:	48 c1 e5 05          	shl    $0x5,%rbp
  713a5a:	4c 01 fd             	add    %r15,%rbp
  713a5d:	48 81 c1 58 ff ff ff 	add    $0xffffffffffffff58,%rcx
  713a64:	49 89 cd             	mov    %rcx,%r13
  713a67:	4c 8b 7e 28          	mov    0x28(%rsi),%r15
  713a6b:	4d 85 ff             	test   %r15,%r15
  713a6e:	74 16                	je     713a86 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xa6>
  713a70:	4c 8b 46 30          	mov    0x30(%rsi),%r8
  713a74:	4d 39 c7             	cmp    %r8,%r15
  713a77:	74 0d                	je     713a86 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xa6>
  713a79:	4d 8d 4f 20          	lea    0x20(%r15),%r9
  713a7d:	48 8d 46 38          	lea    0x38(%rsi),%rax
  713a81:	45 31 d2             	xor    %r10d,%r10d
  713a84:	eb 3e                	jmp    713ac4 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xe4>
  713a86:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  713a8b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  713a92:	48 c7 40 08 08 00 00 	movq   $0x8,0x8(%rax)
  713a99:	00 
  713a9a:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  713aa1:	00 
  713aa2:	e9 b8 02 00 00       	jmp    713d5f <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x37f>
  713aa7:	49 8d 8d 58 ff ff ff 	lea    -0xa8(%r13),%rcx
  713aae:	48 89 08             	mov    %rcx,(%rax)
  713ab1:	48 c1 e5 05          	shl    $0x5,%rbp
  713ab5:	4c 01 fd             	add    %r15,%rbp
  713ab8:	4d 8d 57 20          	lea    0x20(%r15),%r10
  713abc:	4c 8b 4e 28          	mov    0x28(%rsi),%r9
  713ac0:	4c 8b 46 30          	mov    0x30(%rsi),%r8
  713ac4:	48 89 e9             	mov    %rbp,%rcx
  713ac7:	4c 29 d1             	sub    %r10,%rcx
  713aca:	48 c1 e9 05          	shr    $0x5,%rcx
  713ace:	4d 85 d2             	test   %r10,%r10
  713ad1:	49 0f 44 ca          	cmove  %r10,%rcx
  713ad5:	4c 89 c2             	mov    %r8,%rdx
  713ad8:	4c 29 ca             	sub    %r9,%rdx
  713adb:	48 c1 ea 05          	shr    $0x5,%rdx
  713adf:	4d 85 c9             	test   %r9,%r9
  713ae2:	49 0f 44 d1          	cmove  %r9,%rdx
  713ae6:	48 01 ca             	add    %rcx,%rdx
  713ae9:	48 83 fa 04          	cmp    $0x4,%rdx
  713aed:	41 be 03 00 00 00    	mov    $0x3,%r14d
  713af3:	4c 0f 43 f2          	cmovae %rdx,%r14
  713af7:	48 b9 54 55 55 55 55 	movabs $0x555555555555554,%rcx
  713afe:	55 55 05 
  713b01:	48 39 ca             	cmp    %rcx,%rdx
  713b04:	76 0b                	jbe    713b11 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x131>
  713b06:	31 ff                	xor    %edi,%edi
  713b08:	4c 89 e6             	mov    %r12,%rsi
  713b0b:	ff 15 97 42 3d 00    	call   *0x3d4297(%rip)        # ae7da8 <_DYNAMIC+0x328>
  713b11:	48 8b 00             	mov    (%rax),%rax
  713b14:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
  713b1b:	49 8b 17             	mov    (%r15),%rdx
  713b1e:	4a 8d 04 f5 08 00 00 	lea    0x8(,%r14,8),%rax
  713b25:	00 
  713b26:	48 8d 1c 40          	lea    (%rax,%rax,2),%rbx
  713b2a:	48 85 db             	test   %rbx,%rbx
  713b2d:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  713b32:	74 65                	je     713b99 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x1b9>
  713b34:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  713b39:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  713b3e:	4c 89 14 24          	mov    %r10,(%rsp)
  713b42:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  713b47:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  713b4c:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  713b51:	ff 15 89 41 3d 00    	call   *0x3d4189(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  713b57:	be 08 00 00 00       	mov    $0x8,%esi
  713b5c:	49 89 dc             	mov    %rbx,%r12
  713b5f:	48 89 df             	mov    %rbx,%rdi
  713b62:	ff 15 58 41 3d 00    	call   *0x3d4158(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  713b68:	bf 08 00 00 00       	mov    $0x8,%edi
  713b6d:	48 85 c0             	test   %rax,%rax
  713b70:	74 96                	je     713b08 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x128>
  713b72:	49 ff c6             	inc    %r14
  713b75:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  713b7a:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  713b7f:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  713b84:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  713b89:	4c 8b 14 24          	mov    (%rsp),%r10
  713b8d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  713b92:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  713b97:	eb 08                	jmp    713ba1 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x1c1>
  713b99:	b8 08 00 00 00       	mov    $0x8,%eax
  713b9e:	45 31 f6             	xor    %r14d,%r14d
  713ba1:	48 89 10             	mov    %rdx,(%rax)
  713ba4:	48 89 48 08          	mov    %rcx,0x8(%rax)
  713ba8:	4c 89 78 10          	mov    %r15,0x10(%rax)
  713bac:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  713bb1:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  713bb6:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
  713bbd:	00 00 
  713bbf:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
  713bc3:	48 89 0c 24          	mov    %rcx,(%rsp)
  713bc7:	48 8b 4e 38          	mov    0x38(%rsi),%rcx
  713bcb:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  713bd0:	be 01 00 00 00       	mov    $0x1,%esi
  713bd5:	eb 26                	jmp    713bfd <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x21d>
  713bd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  713bde:	00 00 
  713be0:	48 8d 0c 76          	lea    (%rsi,%rsi,2),%rcx
  713be4:	48 89 1c c8          	mov    %rbx,(%rax,%rcx,8)
  713be8:	48 89 54 c8 08       	mov    %rdx,0x8(%rax,%rcx,8)
  713bed:	4c 89 4c c8 10       	mov    %r9,0x10(%rax,%rcx,8)
  713bf2:	48 ff c6             	inc    %rsi
  713bf5:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  713bfa:	4d 89 d9             	mov    %r11,%r9
  713bfd:	4d 85 d2             	test   %r10,%r10
  713c00:	74 09                	je     713c0b <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x22b>
  713c02:	49 39 ea             	cmp    %rbp,%r10
  713c05:	0f 85 94 00 00 00    	jne    713c9f <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2bf>
  713c0b:	4d 85 ed             	test   %r13,%r13
  713c0e:	74 44                	je     713c54 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x274>
  713c10:	49 39 fd             	cmp    %rdi,%r13
  713c13:	74 3f                	je     713c54 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x274>
  713c15:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  713c1c:	0f 1f 40 00          	nopl   0x0(%rax)
  713c20:	49 8b 6d e8          	mov    -0x18(%r13),%rbp
  713c24:	48 85 ed             	test   %rbp,%rbp
  713c27:	75 60                	jne    713c89 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2a9>
  713c29:	49 8d 8d a8 00 00 00 	lea    0xa8(%r13),%rcx
  713c30:	49 39 fd             	cmp    %rdi,%r13
  713c33:	49 89 cd             	mov    %rcx,%r13
  713c36:	75 e8                	jne    713c20 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x240>
  713c38:	48 8b a9 38 ff ff ff 	mov    -0xc8(%rcx),%rbp
  713c3f:	48 8d 91 b0 fe ff ff 	lea    -0x150(%rcx),%rdx
  713c46:	48 89 14 24          	mov    %rdx,(%rsp)
  713c4a:	48 81 c1 58 ff ff ff 	add    $0xffffffffffffff58,%rcx
  713c51:	49 89 cd             	mov    %rcx,%r13
  713c54:	4d 85 c9             	test   %r9,%r9
  713c57:	0f 84 ec 00 00 00    	je     713d49 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x369>
  713c5d:	4d 39 c1             	cmp    %r8,%r9
  713c60:	0f 84 e3 00 00 00    	je     713d49 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x369>
  713c66:	4d 8d 59 20          	lea    0x20(%r9),%r11
  713c6a:	45 31 d2             	xor    %r10d,%r10d
  713c6d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  713c72:	48 8b 91 a0 00 00 00 	mov    0xa0(%rcx),%rdx
  713c79:	49 8b 19             	mov    (%r9),%rbx
  713c7c:	48 3b 74 24 28       	cmp    0x28(%rsp),%rsi
  713c81:	0f 85 59 ff ff ff    	jne    713be0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  713c87:	eb 39                	jmp    713cc2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2e2>
  713c89:	4d 8b 55 e0          	mov    -0x20(%r13),%r10
  713c8d:	48 c1 e5 05          	shl    $0x5,%rbp
  713c91:	4c 01 d5             	add    %r10,%rbp
  713c94:	49 8d 8d 58 ff ff ff 	lea    -0xa8(%r13),%rcx
  713c9b:	48 89 0c 24          	mov    %rcx,(%rsp)
  713c9f:	4d 89 cb             	mov    %r9,%r11
  713ca2:	4d 89 d1             	mov    %r10,%r9
  713ca5:	49 83 c2 20          	add    $0x20,%r10
  713ca9:	48 8b 0c 24          	mov    (%rsp),%rcx
  713cad:	48 8b 91 a0 00 00 00 	mov    0xa0(%rcx),%rdx
  713cb4:	49 8b 19             	mov    (%r9),%rbx
  713cb7:	48 3b 74 24 28       	cmp    0x28(%rsp),%rsi
  713cbc:	0f 85 1e ff ff ff    	jne    713be0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  713cc2:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  713cc7:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  713ccc:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  713cd1:	4d 89 c4             	mov    %r8,%r12
  713cd4:	4c 89 c2             	mov    %r8,%rdx
  713cd7:	4c 29 da             	sub    %r11,%rdx
  713cda:	48 c1 ea 05          	shr    $0x5,%rdx
  713cde:	48 89 e8             	mov    %rbp,%rax
  713ce1:	4c 29 d0             	sub    %r10,%rax
  713ce4:	48 c1 e8 05          	shr    $0x5,%rax
  713ce8:	4d 85 d2             	test   %r10,%r10
  713ceb:	4d 89 d6             	mov    %r10,%r14
  713cee:	49 0f 44 c2          	cmove  %r10,%rax
  713cf2:	48 ff c2             	inc    %rdx
  713cf5:	4d 89 df             	mov    %r11,%r15
  713cf8:	4d 85 db             	test   %r11,%r11
  713cfb:	b9 01 00 00 00       	mov    $0x1,%ecx
  713d00:	48 0f 44 d1          	cmove  %rcx,%rdx
  713d04:	48 01 c2             	add    %rax,%rdx
  713d07:	b9 08 00 00 00       	mov    $0x8,%ecx
  713d0c:	41 b8 18 00 00 00    	mov    $0x18,%r8d
  713d12:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  713d17:	48 89 f3             	mov    %rsi,%rbx
  713d1a:	e8 11 24 01 00       	call   726130 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  713d1f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  713d24:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  713d29:	4d 89 e0             	mov    %r12,%r8
  713d2c:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  713d31:	4d 89 f2             	mov    %r14,%r10
  713d34:	48 89 de             	mov    %rbx,%rsi
  713d37:	4d 89 fb             	mov    %r15,%r11
  713d3a:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  713d3f:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  713d44:	e9 97 fe ff ff       	jmp    713be0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  713d49:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  713d4e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  713d53:	48 89 48 10          	mov    %rcx,0x10(%rax)
  713d57:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  713d5c:	0f 11 00             	movups %xmm0,(%rax)
  713d5f:	48 83 c4 58          	add    $0x58,%rsp
  713d63:	5b                   	pop    %rbx
  713d64:	41 5c                	pop    %r12
  713d66:	41 5d                	pop    %r13
  713d68:	41 5e                	pop    %r14
  713d6a:	41 5f                	pop    %r15
  713d6c:	5d                   	pop    %rbp
  713d6d:	c3                   	ret
  713d6e:	48 89 c3             	mov    %rax,%rbx
  713d71:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  713d76:	48 85 c0             	test   %rax,%rax
  713d79:	74 18                	je     713d93 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x3b3>
  713d7b:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  713d80:	48 c1 e0 03          	shl    $0x3,%rax
  713d84:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  713d88:	ba 08 00 00 00       	mov    $0x8,%edx
  713d8d:	ff 15 35 3f 3d 00    	call   *0x3d3f35(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  713d93:	48 89 df             	mov    %rbx,%rdi
  713d96:	e8 b5 46 3a 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
