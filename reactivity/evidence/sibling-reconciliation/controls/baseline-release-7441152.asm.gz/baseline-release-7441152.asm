
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000718b00 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>:
  718b00:	55                   	push   %rbp
  718b01:	41 57                	push   %r15
  718b03:	41 56                	push   %r14
  718b05:	41 55                	push   %r13
  718b07:	41 54                	push   %r12
  718b09:	53                   	push   %rbx
  718b0a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
  718b11:	48 89 fb             	mov    %rdi,%rbx
  718b14:	4c 8b 26             	mov    (%rsi),%r12
  718b17:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718b1b:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  718b1f:	4c 8b 6e 28          	mov    0x28(%rsi),%r13
  718b23:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718b2a:	00 
  718b2b:	48 85 c0             	test   %rax,%rax
  718b2e:	0f 84 36 01 00 00    	je     718c6a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x16a>
  718b34:	49 89 f6             	mov    %rsi,%r14
  718b37:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  718b3b:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  718b40:	0f b7 88 32 05 00 00 	movzwl 0x532(%rax),%ecx
  718b47:	49 39 cd             	cmp    %rcx,%r13
  718b4a:	73 14                	jae    718b60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  718b4c:	49 89 c7             	mov    %rax,%r15
  718b4f:	eb 37                	jmp    718b88 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x88>
  718b51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  718b58:	0f 1f 84 00 00 00 00 
  718b5f:	00 
  718b60:	4c 8b b8 d0 04 00 00 	mov    0x4d0(%rax),%r15
  718b67:	4d 85 ff             	test   %r15,%r15
  718b6a:	0f 84 fa 00 00 00    	je     718c6a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x16a>
  718b70:	48 ff c5             	inc    %rbp
  718b73:	44 0f b7 a8 30 05 00 	movzwl 0x530(%rax),%r13d
  718b7a:	00 
  718b7b:	4c 89 f8             	mov    %r15,%rax
  718b7e:	66 45 3b af 32 05 00 	cmp    0x532(%r15),%r13w
  718b85:	00 
  718b86:	73 d8                	jae    718b60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  718b88:	4b 8b b4 ef d8 04 00 	mov    0x4d8(%r15,%r13,8),%rsi
  718b8f:	00 
  718b90:	49 8b 04 24          	mov    (%r12),%rax
  718b94:	48 8b 38             	mov    (%rax),%rdi
  718b97:	ff 15 ab 21 3d 00    	call   *0x3d21ab(%rip)        # aead48 <_DYNAMIC+0x6d0>
  718b9d:	84 c0                	test   %al,%al
  718b9f:	0f 84 e1 00 00 00    	je     718c86 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x186>
  718ba5:	48 85 ed             	test   %rbp,%rbp
  718ba8:	0f 84 88 00 00 00    	je     718c36 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x136>
  718bae:	4b 8d 04 ef          	lea    (%r15,%r13,8),%rax
  718bb2:	48 05 40 05 00 00    	add    $0x540,%rax
  718bb8:	48 89 e9             	mov    %rbp,%rcx
  718bbb:	48 83 e1 07          	and    $0x7,%rcx
  718bbf:	0f 84 9a 00 00 00    	je     718c5f <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x15f>
  718bc5:	31 d2                	xor    %edx,%edx
  718bc7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  718bce:	00 00 
  718bd0:	4c 8b 38             	mov    (%rax),%r15
  718bd3:	49 8d 87 38 05 00 00 	lea    0x538(%r15),%rax
  718bda:	48 ff c2             	inc    %rdx
  718bdd:	48 39 d1             	cmp    %rdx,%rcx
  718be0:	75 ee                	jne    718bd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xd0>
  718be2:	48 89 e9             	mov    %rbp,%rcx
  718be5:	48 29 d1             	sub    %rdx,%rcx
  718be8:	48 83 fd 08          	cmp    $0x8,%rbp
  718bec:	72 43                	jb     718c31 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x131>
  718bee:	66 90                	xchg   %ax,%ax
  718bf0:	48 8b 00             	mov    (%rax),%rax
  718bf3:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  718bfa:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  718c01:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  718c08:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  718c0f:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  718c16:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  718c1d:	4c 8b b8 38 05 00 00 	mov    0x538(%rax),%r15
  718c24:	49 8d 87 38 05 00 00 	lea    0x538(%r15),%rax
  718c2b:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  718c2f:	75 bf                	jne    718bf0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xf0>
  718c31:	45 31 ed             	xor    %r13d,%r13d
  718c34:	eb 03                	jmp    718c39 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x139>
  718c36:	49 ff c5             	inc    %r13
  718c39:	4d 89 6e 28          	mov    %r13,0x28(%r14)
  718c3d:	0f 57 c0             	xorps  %xmm0,%xmm0
  718c40:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  718c45:	31 ed                	xor    %ebp,%ebp
  718c47:	4c 89 f8             	mov    %r15,%rax
  718c4a:	0f b7 88 32 05 00 00 	movzwl 0x532(%rax),%ecx
  718c51:	49 39 cd             	cmp    %rcx,%r13
  718c54:	0f 83 06 ff ff ff    	jae    718b60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  718c5a:	e9 ed fe ff ff       	jmp    718b4c <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x4c>
  718c5f:	48 89 e9             	mov    %rbp,%rcx
  718c62:	48 83 fd 08          	cmp    $0x8,%rbp
  718c66:	73 88                	jae    718bf0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xf0>
  718c68:	eb c7                	jmp    718c31 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x131>
  718c6a:	c7 43 08 02 00 00 00 	movl   $0x2,0x8(%rbx)
  718c71:	48 89 d8             	mov    %rbx,%rax
  718c74:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
  718c7b:	5b                   	pop    %rbx
  718c7c:	41 5c                	pop    %r12
  718c7e:	41 5d                	pop    %r13
  718c80:	41 5e                	pop    %r14
  718c82:	41 5f                	pop    %r15
  718c84:	5d                   	pop    %rbp
  718c85:	c3                   	ret
  718c86:	49 8b 46 08          	mov    0x8(%r14),%rax
  718c8a:	48 ff 08             	decq   (%rax)
  718c8d:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
  718c92:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  718c97:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  718c9c:	49 83 c6 10          	add    $0x10,%r14
  718ca0:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  718ca5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  718caa:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  718caf:	4c 89 f2             	mov    %r14,%rdx
  718cb2:	e8 e9 34 fd ff       	call   6ec1a0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_>
  718cb7:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  718cbe:	00 
  718cbf:	48 89 43 70          	mov    %rax,0x70(%rbx)
  718cc3:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  718cca:	00 
  718ccb:	0f 11 43 60          	movups %xmm0,0x60(%rbx)
  718ccf:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  718cd6:	00 
  718cd7:	0f 11 43 50          	movups %xmm0,0x50(%rbx)
  718cdb:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  718ce0:	0f 11 43 40          	movups %xmm0,0x40(%rbx)
  718ce4:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  718ce9:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  718cee:	0f 10 54 24 58       	movups 0x58(%rsp),%xmm2
  718cf3:	0f 10 5c 24 68       	movups 0x68(%rsp),%xmm3
  718cf8:	0f 11 5b 30          	movups %xmm3,0x30(%rbx)
  718cfc:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
  718d00:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  718d04:	0f 11 03             	movups %xmm0,(%rbx)
  718d07:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  718d0e:	00 
  718d0f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  718d14:	0f 10 84 24 b0 00 00 	movups 0xb0(%rsp),%xmm0
  718d1b:	00 
  718d1c:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  718d21:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  718d26:	48 89 41 10          	mov    %rax,0x10(%rcx)
  718d2a:	0f 11 01             	movups %xmm0,(%rcx)
  718d2d:	e9 3f ff ff ff       	jmp    718c71 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersG_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x171>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
