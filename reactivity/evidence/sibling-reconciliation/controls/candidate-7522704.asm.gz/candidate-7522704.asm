
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072c990 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>:
  72c990:	55                   	push   %rbp
  72c991:	41 57                	push   %r15
  72c993:	41 56                	push   %r14
  72c995:	41 55                	push   %r13
  72c997:	41 54                	push   %r12
  72c999:	53                   	push   %rbx
  72c99a:	48 81 ec f8 02 00 00 	sub    $0x2f8,%rsp
  72c9a1:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  72c9a6:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  72c9ab:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  72c9b0:	48 83 fe 02          	cmp    $0x2,%rsi
  72c9b4:	0f 82 01 06 00 00    	jb     72cfbb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x62b>
  72c9ba:	48 89 cd             	mov    %rcx,%rbp
  72c9bd:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  72c9c4:	00 00 40 
  72c9c7:	48 89 d1             	mov    %rdx,%rcx
  72c9ca:	31 d2                	xor    %edx,%edx
  72c9cc:	48 f7 f6             	div    %rsi
  72c9cf:	48 83 fa 01          	cmp    $0x1,%rdx
  72c9d3:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72c9d7:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  72c9dc:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  72c9e3:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72c9e8:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
  72c9ed:	73 1e                	jae    72ca0d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x7d>
  72c9ef:	48 89 ca             	mov    %rcx,%rdx
  72c9f2:	48 89 f0             	mov    %rsi,%rax
  72c9f5:	48 d1 e8             	shr    $1,%rax
  72c9f8:	48 89 f1             	mov    %rsi,%rcx
  72c9fb:	48 29 c1             	sub    %rax,%rcx
  72c9fe:	48 83 f9 40          	cmp    $0x40,%rcx
  72ca02:	b8 40 00 00 00       	mov    $0x40,%eax
  72ca07:	48 0f 42 c1          	cmovb  %rcx,%rax
  72ca0b:	eb 0e                	jmp    72ca1b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x8b>
  72ca0d:	48 89 f7             	mov    %rsi,%rdi
  72ca10:	ff 15 92 b8 3b 00    	call   *0x3bb892(%rip)        # ae82a8 <_DYNAMIC+0x828>
  72ca16:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72ca1b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  72ca20:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72ca25:	48 8d 48 30          	lea    0x30(%rax),%rcx
  72ca29:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  72ca2e:	48 8d 48 10          	lea    0x10(%rax),%rcx
  72ca32:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  72ca37:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
  72ca3b:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  72ca40:	48 83 c0 e8          	add    $0xffffffffffffffe8,%rax
  72ca44:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  72ca49:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  72ca4f:	31 db                	xor    %ebx,%ebx
  72ca51:	45 31 db             	xor    %r11d,%r11d
  72ca54:	48 89 ac 24 90 00 00 	mov    %rbp,0x90(%rsp)
  72ca5b:	00 
  72ca5c:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
  72ca61:	49 29 d9             	sub    %rbx,%r9
  72ca64:	76 23                	jbe    72ca89 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0xf9>
  72ca66:	eb 38                	jmp    72caa0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x110>
  72ca68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72ca6f:	00 
  72ca70:	49 ff c3             	inc    %r11
  72ca73:	4c 89 c8             	mov    %r9,%rax
  72ca76:	48 d1 e8             	shr    $1,%rax
  72ca79:	48 01 c3             	add    %rax,%rbx
  72ca7c:	4d 89 cc             	mov    %r9,%r12
  72ca7f:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
  72ca84:	49 29 d9             	sub    %rbx,%r9
  72ca87:	77 17                	ja     72caa0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x110>
  72ca89:	31 f6                	xor    %esi,%esi
  72ca8b:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  72ca91:	49 83 fb 02          	cmp    $0x2,%r11
  72ca95:	0f 83 fa 01 00 00    	jae    72cc95 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x305>
  72ca9b:	e9 c6 04 00 00       	jmp    72cf66 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  72caa0:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  72caa4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72caa9:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  72caad:	4c 3b 4c 24 20       	cmp    0x20(%rsp),%r9
  72cab2:	73 4c                	jae    72cb00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x170>
  72cab4:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  72cab9:	74 55                	je     72cb10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x180>
  72cabb:	49 83 f9 20          	cmp    $0x20,%r9
  72cabf:	b8 20 00 00 00       	mov    $0x20,%eax
  72cac4:	4c 0f 43 c8          	cmovae %rax,%r9
  72cac8:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72cacd:	48 89 04 24          	mov    %rax,(%rsp)
  72cad1:	4c 89 ce             	mov    %r9,%rsi
  72cad4:	48 89 e9             	mov    %rbp,%rcx
  72cad7:	45 31 c0             	xor    %r8d,%r8d
  72cada:	4d 89 cf             	mov    %r9,%r15
  72cadd:	45 31 c9             	xor    %r9d,%r9d
  72cae0:	4d 89 de             	mov    %r11,%r14
  72cae3:	e8 e8 23 00 00       	call   72eed0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72cae8:	4d 89 f3             	mov    %r14,%r11
  72caeb:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72caf0:	44 89 f8             	mov    %r15d,%eax
  72caf3:	e9 58 01 00 00       	jmp    72cc50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  72caf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72caff:	00 
  72cb00:	49 83 f9 02          	cmp    $0x2,%r9
  72cb04:	73 2a                	jae    72cb30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1a0>
  72cb06:	4c 89 c8             	mov    %r9,%rax
  72cb09:	e9 42 01 00 00       	jmp    72cc50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  72cb0e:	66 90                	xchg   %ax,%ax
  72cb10:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72cb15:	49 39 c1             	cmp    %rax,%r9
  72cb18:	4c 0f 43 c8          	cmovae %rax,%r9
  72cb1c:	4d 01 c9             	add    %r9,%r9
  72cb1f:	e9 34 01 00 00       	jmp    72cc58 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c8>
  72cb24:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72cb2b:	00 00 00 00 00 
  72cb30:	48 8b 0f             	mov    (%rdi),%rcx
  72cb33:	4c 8b 57 18          	mov    0x18(%rdi),%r10
  72cb37:	49 39 ca             	cmp    %rcx,%r10
  72cb3a:	4d 89 ce             	mov    %r9,%r14
  72cb3d:	72 3a                	jb     72cb79 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1e9>
  72cb3f:	b8 02 00 00 00       	mov    $0x2,%eax
  72cb44:	49 83 f9 02          	cmp    $0x2,%r9
  72cb48:	0f 84 02 01 00 00    	je     72cc50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  72cb4e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72cb53:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
  72cb57:	b8 02 00 00 00       	mov    $0x2,%eax
  72cb5c:	4d 89 d0             	mov    %r10,%r8
  72cb5f:	90                   	nop
  72cb60:	4d 89 c1             	mov    %r8,%r9
  72cb63:	4c 8b 06             	mov    (%rsi),%r8
  72cb66:	4d 39 c8             	cmp    %r9,%r8
  72cb69:	72 5f                	jb     72cbca <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x23a>
  72cb6b:	48 ff c0             	inc    %rax
  72cb6e:	48 83 c6 18          	add    $0x18,%rsi
  72cb72:	49 39 c6             	cmp    %rax,%r14
  72cb75:	75 e9                	jne    72cb60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1d0>
  72cb77:	eb 3e                	jmp    72cbb7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x227>
  72cb79:	49 83 f9 02          	cmp    $0x2,%r9
  72cb7d:	75 0c                	jne    72cb8b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1fb>
  72cb7f:	b8 02 00 00 00       	mov    $0x2,%eax
  72cb84:	b9 01 00 00 00       	mov    $0x1,%ecx
  72cb89:	eb 63                	jmp    72cbee <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x25e>
  72cb8b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72cb90:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
  72cb94:	b8 02 00 00 00       	mov    $0x2,%eax
  72cb99:	4d 89 d0             	mov    %r10,%r8
  72cb9c:	0f 1f 40 00          	nopl   0x0(%rax)
  72cba0:	4d 89 c1             	mov    %r8,%r9
  72cba3:	4c 8b 06             	mov    (%rsi),%r8
  72cba6:	4d 39 c8             	cmp    %r9,%r8
  72cba9:	73 1f                	jae    72cbca <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x23a>
  72cbab:	48 ff c0             	inc    %rax
  72cbae:	48 83 c6 18          	add    $0x18,%rsi
  72cbb2:	49 39 c6             	cmp    %rax,%r14
  72cbb5:	75 e9                	jne    72cba0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x210>
  72cbb7:	4d 89 f1             	mov    %r14,%r9
  72cbba:	4c 89 f0             	mov    %r14,%rax
  72cbbd:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  72cbc2:	0f 82 ec fe ff ff    	jb     72cab4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x124>
  72cbc8:	eb 0e                	jmp    72cbd8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x248>
  72cbca:	4d 89 f1             	mov    %r14,%r9
  72cbcd:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  72cbd2:	0f 82 dc fe ff ff    	jb     72cab4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x124>
  72cbd8:	49 39 ca             	cmp    %rcx,%r10
  72cbdb:	40 0f 93 c7          	setae  %dil
  72cbdf:	48 89 c1             	mov    %rax,%rcx
  72cbe2:	48 d1 e9             	shr    $1,%rcx
  72cbe5:	40 0f 94 c6          	sete   %sil
  72cbe9:	40 08 fe             	or     %dil,%sil
  72cbec:	75 62                	jne    72cc50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  72cbee:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
  72cbf5:	00 
  72cbf6:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
  72cbfa:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
  72cbff:	4c 8d 0c 37          	lea    (%rdi,%rsi,1),%r9
  72cc03:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
  72cc07:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
  72cc0b:	48 03 74 24 60       	add    0x60(%rsp),%rsi
  72cc10:	49 8b 79 f0          	mov    -0x10(%r9),%rdi
  72cc14:	4c 8b 46 f0          	mov    -0x10(%rsi),%r8
  72cc18:	4d 89 41 f0          	mov    %r8,-0x10(%r9)
  72cc1c:	48 89 7e f0          	mov    %rdi,-0x10(%rsi)
  72cc20:	49 8b 79 f8          	mov    -0x8(%r9),%rdi
  72cc24:	4c 8b 46 f8          	mov    -0x8(%rsi),%r8
  72cc28:	4d 89 41 f8          	mov    %r8,-0x8(%r9)
  72cc2c:	48 89 7e f8          	mov    %rdi,-0x8(%rsi)
  72cc30:	49 8b 39             	mov    (%r9),%rdi
  72cc33:	4c 8b 06             	mov    (%rsi),%r8
  72cc36:	4d 89 01             	mov    %r8,(%r9)
  72cc39:	48 89 3e             	mov    %rdi,(%rsi)
  72cc3c:	49 83 c1 18          	add    $0x18,%r9
  72cc40:	48 83 c6 e8          	add    $0xffffffffffffffe8,%rsi
  72cc44:	48 ff c9             	dec    %rcx
  72cc47:	75 c7                	jne    72cc10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x280>
  72cc49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72cc50:	4c 8d 0c 45 01 00 00 	lea    0x1(,%rax,2),%r9
  72cc57:	00 
  72cc58:	4c 89 e0             	mov    %r12,%rax
  72cc5b:	48 d1 e8             	shr    $1,%rax
  72cc5e:	4c 89 c9             	mov    %r9,%rcx
  72cc61:	48 d1 e9             	shr    $1,%rcx
  72cc64:	48 8d 34 1b          	lea    (%rbx,%rbx,1),%rsi
  72cc68:	48 29 c6             	sub    %rax,%rsi
  72cc6b:	48 8d 04 59          	lea    (%rcx,%rbx,2),%rax
  72cc6f:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  72cc74:	48 0f af f1          	imul   %rcx,%rsi
  72cc78:	48 0f af c1          	imul   %rcx,%rax
  72cc7c:	48 31 f0             	xor    %rsi,%rax
  72cc7f:	be 7f 00 00 00       	mov    $0x7f,%esi
  72cc84:	48 0f bd f0          	bsr    %rax,%rsi
  72cc88:	83 f6 3f             	xor    $0x3f,%esi
  72cc8b:	49 83 fb 02          	cmp    $0x2,%r11
  72cc8f:	0f 82 d1 02 00 00    	jb     72cf66 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  72cc95:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
  72cc9c:	00 
  72cc9d:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  72cca1:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72cca6:	48 01 c8             	add    %rcx,%rax
  72cca9:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  72ccb0:	00 
  72ccb1:	48 03 4c 24 70       	add    0x70(%rsp),%rcx
  72ccb6:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  72ccbd:	00 
  72ccbe:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
  72ccc3:	48 89 9c 24 98 00 00 	mov    %rbx,0x98(%rsp)
  72ccca:	00 
  72cccb:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  72ccd0:	eb 4b                	jmp    72cd1d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x38d>
  72ccd2:	48 89 eb             	mov    %rbp,%rbx
  72ccd5:	4c 89 ce             	mov    %r9,%rsi
  72ccd8:	49 29 f4             	sub    %rsi,%r12
  72ccdb:	48 89 df             	mov    %rbx,%rdi
  72ccde:	4c 89 e2             	mov    %r12,%rdx
  72cce1:	ff 15 09 b0 3b 00    	call   *0x3bb009(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72cce7:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
  72ccee:	00 
  72ccef:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72ccf4:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  72ccf9:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  72ccfe:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  72cd03:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  72cd0a:	00 
  72cd0b:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  72cd12:	00 
  72cd13:	49 83 fb 01          	cmp    $0x1,%r11
  72cd17:	0f 86 43 02 00 00    	jbe    72cf60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d0>
  72cd1d:	42 38 b4 1c a5 00 00 	cmp    %sil,0xa5(%rsp,%r11,1)
  72cd24:	00 
  72cd25:	0f 82 3b 02 00 00    	jb     72cf66 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  72cd2b:	49 ff cb             	dec    %r11
  72cd2e:	4a 8b 84 dc e8 00 00 	mov    0xe8(%rsp,%r11,8),%rax
  72cd35:	00 
  72cd36:	49 89 c5             	mov    %rax,%r13
  72cd39:	49 d1 ed             	shr    $1,%r13
  72cd3c:	4d 89 e7             	mov    %r12,%r15
  72cd3f:	49 d1 ef             	shr    $1,%r15
  72cd42:	4f 8d 34 2f          	lea    (%r15,%r13,1),%r14
  72cd46:	49 39 ee             	cmp    %rbp,%r14
  72cd49:	77 25                	ja     72cd70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x3e0>
  72cd4b:	89 c1                	mov    %eax,%ecx
  72cd4d:	44 09 e1             	or     %r12d,%ecx
  72cd50:	83 e1 01             	and    $0x1,%ecx
  72cd53:	75 1b                	jne    72cd70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x3e0>
  72cd55:	4d 01 f6             	add    %r14,%r14
  72cd58:	4d 89 f4             	mov    %r14,%r12
  72cd5b:	49 83 fb 01          	cmp    $0x1,%r11
  72cd5f:	77 bc                	ja     72cd1d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x38d>
  72cd61:	e9 fa 01 00 00       	jmp    72cf60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d0>
  72cd66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72cd6d:	00 00 00 
  72cd70:	48 89 d9             	mov    %rbx,%rcx
  72cd73:	4c 29 f1             	sub    %r14,%rcx
  72cd76:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  72cd7a:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  72cd7f:	48 8d 1c ce          	lea    (%rsi,%rcx,8),%rbx
  72cd83:	a8 01                	test   $0x1,%al
  72cd85:	4c 89 5c 24 40       	mov    %r11,0x40(%rsp)
  72cd8a:	75 54                	jne    72cde0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x450>
  72cd8c:	4c 89 e8             	mov    %r13,%rax
  72cd8f:	48 83 c8 01          	or     $0x1,%rax
  72cd93:	4c 0f bd c0          	bsr    %rax,%r8
  72cd97:	41 83 f0 3f          	xor    $0x3f,%r8d
  72cd9b:	45 01 c0             	add    %r8d,%r8d
  72cd9e:	41 83 f0 7e          	xor    $0x7e,%r8d
  72cda2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72cda7:	48 89 04 24          	mov    %rax,(%rsp)
  72cdab:	48 89 df             	mov    %rbx,%rdi
  72cdae:	4c 89 ee             	mov    %r13,%rsi
  72cdb1:	48 89 e9             	mov    %rbp,%rcx
  72cdb4:	45 31 c9             	xor    %r9d,%r9d
  72cdb7:	e8 14 21 00 00       	call   72eed0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72cdbc:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  72cdc1:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  72cdc6:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72cdcb:	41 f6 c4 01          	test   $0x1,%r12b
  72cdcf:	74 15                	je     72cde6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x456>
  72cdd1:	4d 85 ff             	test   %r15,%r15
  72cdd4:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  72cdd9:	75 64                	jne    72ce3f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x4af>
  72cddb:	e9 23 ff ff ff       	jmp    72cd03 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  72cde0:	41 f6 c4 01          	test   $0x1,%r12b
  72cde4:	75 eb                	jne    72cdd1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x441>
  72cde6:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  72cded:	00 
  72cdee:	4c 01 e8             	add    %r13,%rax
  72cdf1:	48 8d 3c c3          	lea    (%rbx,%rax,8),%rdi
  72cdf5:	4c 89 f8             	mov    %r15,%rax
  72cdf8:	48 83 c8 01          	or     $0x1,%rax
  72cdfc:	4c 0f bd c0          	bsr    %rax,%r8
  72ce00:	41 83 f0 3f          	xor    $0x3f,%r8d
  72ce04:	45 01 c0             	add    %r8d,%r8d
  72ce07:	41 83 f0 7e          	xor    $0x7e,%r8d
  72ce0b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72ce10:	48 89 04 24          	mov    %rax,(%rsp)
  72ce14:	4c 89 fe             	mov    %r15,%rsi
  72ce17:	48 89 e9             	mov    %rbp,%rcx
  72ce1a:	45 31 c9             	xor    %r9d,%r9d
  72ce1d:	e8 ae 20 00 00       	call   72eed0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72ce22:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  72ce27:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  72ce2c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72ce31:	4d 85 ff             	test   %r15,%r15
  72ce34:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  72ce39:	0f 84 c4 fe ff ff    	je     72cd03 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  72ce3f:	4d 85 ed             	test   %r13,%r13
  72ce42:	0f 84 bb fe ff ff    	je     72cd03 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  72ce48:	4d 39 ef             	cmp    %r13,%r15
  72ce4b:	4c 89 e8             	mov    %r13,%rax
  72ce4e:	49 0f 42 c7          	cmovb  %r15,%rax
  72ce52:	48 39 c5             	cmp    %rax,%rbp
  72ce55:	0f 82 a8 fe ff ff    	jb     72cd03 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  72ce5b:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
  72ce62:	00 
  72ce63:	4c 01 e9             	add    %r13,%rcx
  72ce66:	48 8d 2c cb          	lea    (%rbx,%rcx,8),%rbp
  72ce6a:	4d 39 fd             	cmp    %r15,%r13
  72ce6d:	48 89 de             	mov    %rbx,%rsi
  72ce70:	48 0f 47 f5          	cmova  %rbp,%rsi
  72ce74:	48 c1 e0 03          	shl    $0x3,%rax
  72ce78:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
  72ce7c:	48 89 d7             	mov    %rdx,%rdi
  72ce7f:	4c 89 e2             	mov    %r12,%rdx
  72ce82:	ff 15 68 ae 3b 00    	call   *0x3bae68(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72ce88:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  72ce8d:	4d 01 cc             	add    %r9,%r12
  72ce90:	4d 39 fd             	cmp    %r15,%r13
  72ce93:	76 68                	jbe    72cefd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x56d>
  72ce95:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  72ce9c:	00 
  72ce9d:	0f 1f 00             	nopl   (%rax)
  72cea0:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
  72cea4:	49 8d 54 24 e8       	lea    -0x18(%r12),%rdx
  72cea9:	49 8b 74 24 e8       	mov    -0x18(%r12),%rsi
  72ceae:	31 ff                	xor    %edi,%edi
  72ceb0:	45 31 c0             	xor    %r8d,%r8d
  72ceb3:	48 3b 75 e8          	cmp    -0x18(%rbp),%rsi
  72ceb7:	40 0f 92 c7          	setb   %dil
  72cebb:	41 0f 93 c0          	setae  %r8b
  72cebf:	48 0f 42 d1          	cmovb  %rcx,%rdx
  72cec3:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  72cec7:	48 89 48 10          	mov    %rcx,0x10(%rax)
  72cecb:	0f 10 02             	movups (%rdx),%xmm0
  72cece:	0f 11 00             	movups %xmm0,(%rax)
  72ced1:	4b 8d 0c 40          	lea    (%r8,%r8,2),%rcx
  72ced5:	48 8d 6c cd e8       	lea    -0x18(%rbp,%rcx,8),%rbp
  72ceda:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  72cede:	4d 8d 24 cc          	lea    (%r12,%rcx,8),%r12
  72cee2:	49 83 c4 e8          	add    $0xffffffffffffffe8,%r12
  72cee6:	48 39 dd             	cmp    %rbx,%rbp
  72cee9:	0f 84 e3 fd ff ff    	je     72ccd2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x342>
  72ceef:	48 83 c0 e8          	add    $0xffffffffffffffe8,%rax
  72cef3:	4d 39 cc             	cmp    %r9,%r12
  72cef6:	75 a8                	jne    72cea0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x510>
  72cef8:	e9 d5 fd ff ff       	jmp    72ccd2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x342>
  72cefd:	4c 89 ce             	mov    %r9,%rsi
  72cf00:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
  72cf07:	00 
  72cf08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72cf0f:	00 
  72cf10:	48 8b 4d 00          	mov    0x0(%rbp),%rcx
  72cf14:	31 c0                	xor    %eax,%eax
  72cf16:	31 d2                	xor    %edx,%edx
  72cf18:	48 3b 0e             	cmp    (%rsi),%rcx
  72cf1b:	0f 92 c1             	setb   %cl
  72cf1e:	0f 93 c2             	setae  %dl
  72cf21:	48 89 f7             	mov    %rsi,%rdi
  72cf24:	48 0f 42 fd          	cmovb  %rbp,%rdi
  72cf28:	4c 8b 47 10          	mov    0x10(%rdi),%r8
  72cf2c:	4c 89 43 10          	mov    %r8,0x10(%rbx)
  72cf30:	0f 10 07             	movups (%rdi),%xmm0
  72cf33:	0f 11 03             	movups %xmm0,(%rbx)
  72cf36:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  72cf3a:	48 8d 34 d6          	lea    (%rsi,%rdx,8),%rsi
  72cf3e:	48 83 c3 18          	add    $0x18,%rbx
  72cf42:	4c 39 e6             	cmp    %r12,%rsi
  72cf45:	0f 84 8d fd ff ff    	je     72ccd8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x348>
  72cf4b:	88 c8                	mov    %cl,%al
  72cf4d:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  72cf51:	48 8d 6c c5 00       	lea    0x0(%rbp,%rax,8),%rbp
  72cf56:	4c 39 cd             	cmp    %r9,%rbp
  72cf59:	75 b5                	jne    72cf10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x580>
  72cf5b:	e9 78 fd ff ff       	jmp    72ccd8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x348>
  72cf60:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  72cf66:	4e 89 a4 dc e8 00 00 	mov    %r12,0xe8(%rsp,%r11,8)
  72cf6d:	00 
  72cf6e:	42 88 b4 1c a6 00 00 	mov    %sil,0xa6(%rsp,%r11,1)
  72cf75:	00 
  72cf76:	48 39 5c 24 30       	cmp    %rbx,0x30(%rsp)
  72cf7b:	0f 87 ef fa ff ff    	ja     72ca70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0xe0>
  72cf81:	41 f6 c4 01          	test   $0x1,%r12b
  72cf85:	75 34                	jne    72cfbb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x62b>
  72cf87:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  72cf8c:	48 89 f0             	mov    %rsi,%rax
  72cf8f:	48 83 c8 01          	or     $0x1,%rax
  72cf93:	4c 0f bd c0          	bsr    %rax,%r8
  72cf97:	41 83 f0 3f          	xor    $0x3f,%r8d
  72cf9b:	45 01 c0             	add    %r8d,%r8d
  72cf9e:	41 83 f0 7e          	xor    $0x7e,%r8d
  72cfa2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72cfa7:	48 89 04 24          	mov    %rax,(%rsp)
  72cfab:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  72cfb0:	48 89 e9             	mov    %rbp,%rcx
  72cfb3:	45 31 c9             	xor    %r9d,%r9d
  72cfb6:	e8 15 1f 00 00       	call   72eed0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72cfbb:	48 81 c4 f8 02 00 00 	add    $0x2f8,%rsp
  72cfc2:	5b                   	pop    %rbx
  72cfc3:	41 5c                	pop    %r12
  72cfc5:	41 5d                	pop    %r13
  72cfc7:	41 5e                	pop    %r14
  72cfc9:	41 5f                	pop    %r15
  72cfcb:	5d                   	pop    %rbp
  72cfcc:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
