
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000711ef0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_>:
  711ef0:	41 57                	push   %r15
  711ef2:	41 56                	push   %r14
  711ef4:	41 55                	push   %r13
  711ef6:	41 54                	push   %r12
  711ef8:	53                   	push   %rbx
  711ef9:	48 81 ec 90 04 00 00 	sub    $0x490,%rsp
  711f00:	48 83 fe 02          	cmp    $0x2,%rsi
  711f04:	0f 82 6a 04 00 00    	jb     712374 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x484>
  711f0a:	49 89 f6             	mov    %rsi,%r14
  711f0d:	48 83 fe 20          	cmp    $0x20,%rsi
  711f11:	0f 87 af 04 00 00    	ja     7123c6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x4d6>
  711f17:	48 89 fb             	mov    %rdi,%rbx
  711f1a:	4c 89 f0             	mov    %r14,%rax
  711f1d:	48 d1 e8             	shr    $1,%rax
  711f20:	49 83 fe 07          	cmp    $0x7,%r14
  711f24:	0f 86 ba 01 00 00    	jbe    7120e4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x1f4>
  711f2a:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
  711f2e:	48 8b 53 48          	mov    0x48(%rbx),%rdx
  711f32:	45 31 c0             	xor    %r8d,%r8d
  711f35:	31 f6                	xor    %esi,%esi
  711f37:	48 3b 0b             	cmp    (%rbx),%rcx
  711f3a:	41 0f 93 c0          	setae  %r8b
  711f3e:	40 0f 92 c6          	setb   %sil
  711f42:	48 8d 7b 48          	lea    0x48(%rbx),%rdi
  711f46:	4c 8d 4b 30          	lea    0x30(%rbx),%r9
  711f4a:	48 3b 53 30          	cmp    0x30(%rbx),%rdx
  711f4e:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  711f52:	4a 8d 34 d3          	lea    (%rbx,%r10,8),%rsi
  711f56:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  711f5a:	4c 89 ca             	mov    %r9,%rdx
  711f5d:	48 0f 42 d7          	cmovb  %rdi,%rdx
  711f61:	4a 8d 0c c3          	lea    (%rbx,%r8,8),%rcx
  711f65:	49 0f 42 f9          	cmovb  %r9,%rdi
  711f69:	4c 8b 0a             	mov    (%rdx),%r9
  711f6c:	4c 8b 1f             	mov    (%rdi),%r11
  711f6f:	4e 8b 04 c3          	mov    (%rbx,%r8,8),%r8
  711f73:	4d 39 c3             	cmp    %r8,%r11
  711f76:	49 89 cf             	mov    %rcx,%r15
  711f79:	4c 0f 42 fa          	cmovb  %rdx,%r15
  711f7d:	4e 3b 0c d3          	cmp    (%rbx,%r10,8),%r9
  711f81:	4c 0f 42 fe          	cmovb  %rsi,%r15
  711f85:	48 0f 42 f2          	cmovb  %rdx,%rsi
  711f89:	48 0f 42 d1          	cmovb  %rcx,%rdx
  711f8d:	4d 39 c3             	cmp    %r8,%r11
  711f90:	48 0f 43 cf          	cmovae %rdi,%rcx
  711f94:	48 0f 42 d7          	cmovb  %rdi,%rdx
  711f98:	48 8b 3a             	mov    (%rdx),%rdi
  711f9b:	49 3b 3f             	cmp    (%r15),%rdi
  711f9e:	4c 89 ff             	mov    %r15,%rdi
  711fa1:	48 0f 42 fa          	cmovb  %rdx,%rdi
  711fa5:	49 0f 42 d7          	cmovb  %r15,%rdx
  711fa9:	4c 8b 46 10          	mov    0x10(%rsi),%r8
  711fad:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
  711fb2:	0f 10 06             	movups (%rsi),%xmm0
  711fb5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  711fba:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  711fbe:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  711fc3:	0f 10 07             	movups (%rdi),%xmm0
  711fc6:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
  711fcb:	48 8b 72 10          	mov    0x10(%rdx),%rsi
  711fcf:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  711fd4:	0f 10 02             	movups (%rdx),%xmm0
  711fd7:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  711fdc:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
  711fe3:	00 
  711fe4:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  711fe8:	4c 8d 0c 13          	lea    (%rbx,%rdx,1),%r9
  711fec:	48 8b 74 13 18       	mov    0x18(%rbx,%rdx,1),%rsi
  711ff1:	48 8b 7c 13 48       	mov    0x48(%rbx,%rdx,1),%rdi
  711ff6:	45 31 d2             	xor    %r10d,%r10d
  711ff9:	45 31 db             	xor    %r11d,%r11d
  711ffc:	48 3b 34 13          	cmp    (%rbx,%rdx,1),%rsi
  712000:	41 0f 93 c2          	setae  %r10b
  712004:	41 0f 92 c3          	setb   %r11b
  712008:	4c 8d 04 13          	lea    (%rbx,%rdx,1),%r8
  71200c:	49 83 c0 48          	add    $0x48,%r8
  712010:	4c 8d 3c 13          	lea    (%rbx,%rdx,1),%r15
  712014:	49 83 c7 30          	add    $0x30,%r15
  712018:	48 3b 7c 13 30       	cmp    0x30(%rbx,%rdx,1),%rdi
  71201d:	4f 8d 1c 5b          	lea    (%r11,%r11,2),%r11
  712021:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  712025:	4b 8d 34 d1          	lea    (%r9,%r10,8),%rsi
  712029:	4c 89 ff             	mov    %r15,%rdi
  71202c:	49 0f 42 f8          	cmovb  %r8,%rdi
  712030:	4d 0f 42 c7          	cmovb  %r15,%r8
  712034:	4d 8b 38             	mov    (%r8),%r15
  712037:	4f 8b 14 d1          	mov    (%r9,%r10,8),%r10
  71203b:	4d 39 d7             	cmp    %r10,%r15
  71203e:	49 89 f4             	mov    %rsi,%r12
  712041:	4c 0f 42 e7          	cmovb  %rdi,%r12
  712045:	4c 8b 2f             	mov    (%rdi),%r13
  712048:	4f 3b 2c d9          	cmp    (%r9,%r11,8),%r13
  71204c:	4f 8d 0c d9          	lea    (%r9,%r11,8),%r9
  712050:	4d 0f 42 e1          	cmovb  %r9,%r12
  712054:	4c 0f 42 cf          	cmovb  %rdi,%r9
  712058:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  71205c:	48 0f 42 fe          	cmovb  %rsi,%rdi
  712060:	4d 39 d7             	cmp    %r10,%r15
  712063:	49 0f 43 f0          	cmovae %r8,%rsi
  712067:	49 0f 42 f8          	cmovb  %r8,%rdi
  71206b:	4c 89 5c 24 68       	mov    %r11,0x68(%rsp)
  712070:	4c 8b 07             	mov    (%rdi),%r8
  712073:	4d 3b 04 24          	cmp    (%r12),%r8
  712077:	0f 10 01             	movups (%rcx),%xmm0
  71207a:	4c 89 e1             	mov    %r12,%rcx
  71207d:	48 0f 42 cf          	cmovb  %rdi,%rcx
  712081:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
  712086:	49 0f 42 fc          	cmovb  %r12,%rdi
  71208a:	4d 8b 41 10          	mov    0x10(%r9),%r8
  71208e:	4c 89 44 14 20       	mov    %r8,0x20(%rsp,%rdx,1)
  712093:	41 0f 10 01          	movups (%r9),%xmm0
  712097:	0f 11 44 14 10       	movups %xmm0,0x10(%rsp,%rdx,1)
  71209c:	0f 10 01             	movups (%rcx),%xmm0
  71209f:	0f 11 44 14 28       	movups %xmm0,0x28(%rsp,%rdx,1)
  7120a4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
  7120a8:	48 89 4c 14 38       	mov    %rcx,0x38(%rsp,%rdx,1)
  7120ad:	0f 10 07             	movups (%rdi),%xmm0
  7120b0:	0f 11 44 14 40       	movups %xmm0,0x40(%rsp,%rdx,1)
  7120b5:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
  7120b9:	48 89 4c 14 50       	mov    %rcx,0x50(%rsp,%rdx,1)
  7120be:	0f 10 06             	movups (%rsi),%xmm0
  7120c1:	0f 11 44 14 58       	movups %xmm0,0x58(%rsp,%rdx,1)
  7120c6:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  7120ca:	48 89 4c 14 68       	mov    %rcx,0x68(%rsp,%rdx,1)
  7120cf:	ba 04 00 00 00       	mov    $0x4,%edx
  7120d4:	4c 89 f6             	mov    %r14,%rsi
  7120d7:	48 29 c6             	sub    %rax,%rsi
  7120da:	48 39 c2             	cmp    %rax,%rdx
  7120dd:	72 49                	jb     712128 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x238>
  7120df:	e9 f3 00 00 00       	jmp    7121d7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x2e7>
  7120e4:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
  7120e8:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  7120ed:	0f 10 03             	movups (%rbx),%xmm0
  7120f0:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  7120f5:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
  7120fc:	00 
  7120fd:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  712101:	48 8b 54 0b 10       	mov    0x10(%rbx,%rcx,1),%rdx
  712106:	48 89 54 0c 20       	mov    %rdx,0x20(%rsp,%rcx,1)
  71210b:	0f 10 04 0b          	movups (%rbx,%rcx,1),%xmm0
  71210f:	0f 11 44 0c 10       	movups %xmm0,0x10(%rsp,%rcx,1)
  712114:	ba 01 00 00 00       	mov    $0x1,%edx
  712119:	4c 89 f6             	mov    %r14,%rsi
  71211c:	48 29 c6             	sub    %rax,%rsi
  71211f:	48 39 c2             	cmp    %rax,%rdx
  712122:	0f 83 af 00 00 00    	jae    7121d7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x2e7>
  712128:	8d 0c d5 00 00 00 00 	lea    0x0(,%rdx,8),%ecx
  71212f:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  712133:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  712138:	49 89 d0             	mov    %rdx,%r8
  71213b:	eb 1e                	jmp    71215b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x26b>
  71213d:	0f 1f 00             	nopl   (%rax)
  712140:	49 89 fa             	mov    %rdi,%r10
  712143:	4d 89 0a             	mov    %r9,(%r10)
  712146:	0f 28 04 24          	movaps (%rsp),%xmm0
  71214a:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  71214f:	49 ff c0             	inc    %r8
  712152:	48 83 c1 18          	add    $0x18,%rcx
  712156:	49 39 c0             	cmp    %rax,%r8
  712159:	74 7c                	je     7121d7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x2e7>
  71215b:	4e 8d 0c c5 00 00 00 	lea    0x0(,%r8,8),%r9
  712162:	00 
  712163:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  712167:	42 0f 10 04 13       	movups (%rbx,%r10,1),%xmm0
  71216c:	42 0f 11 44 14 10    	movups %xmm0,0x10(%rsp,%r10,1)
  712172:	4e 8b 4c 13 10       	mov    0x10(%rbx,%r10,1),%r9
  712177:	4e 89 4c 14 20       	mov    %r9,0x20(%rsp,%r10,1)
  71217c:	4e 8b 4c 14 10       	mov    0x10(%rsp,%r10,1),%r9
  712181:	4e 3b 4c 14 f8       	cmp    -0x8(%rsp,%r10,1),%r9
  712186:	73 c7                	jae    71214f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x25f>
  712188:	49 01 da             	add    %rbx,%r10
  71218b:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  712190:	0f 29 04 24          	movaps %xmm0,(%rsp)
  712194:	49 89 ca             	mov    %rcx,%r10
  712197:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  71219e:	00 00 
  7121a0:	4e 8b 5c 14 08       	mov    0x8(%rsp,%r10,1),%r11
  7121a5:	4e 89 5c 14 20       	mov    %r11,0x20(%rsp,%r10,1)
  7121aa:	42 0f 10 44 14 f8    	movups -0x8(%rsp,%r10,1),%xmm0
  7121b0:	42 0f 11 44 14 10    	movups %xmm0,0x10(%rsp,%r10,1)
  7121b6:	49 83 fa 18          	cmp    $0x18,%r10
  7121ba:	74 84                	je     712140 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x250>
  7121bc:	4d 8d 5a e8          	lea    -0x18(%r10),%r11
  7121c0:	4e 3b 4c 14 e0       	cmp    -0x20(%rsp,%r10,1),%r9
  7121c5:	4d 89 da             	mov    %r11,%r10
  7121c8:	72 d6                	jb     7121a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x2b0>
  7121ca:	4e 8d 14 1c          	lea    (%rsp,%r11,1),%r10
  7121ce:	49 83 c2 10          	add    $0x10,%r10
  7121d2:	e9 6c ff ff ff       	jmp    712143 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x253>
  7121d7:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
  7121de:	00 
  7121df:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
  7121e3:	48 8d 0c 3c          	lea    (%rsp,%rdi,1),%rcx
  7121e7:	48 83 c1 10          	add    $0x10,%rcx
  7121eb:	48 39 f2             	cmp    %rsi,%rdx
  7121ee:	0f 83 ad 00 00 00    	jae    7122a1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x3b1>
  7121f4:	48 01 df             	add    %rbx,%rdi
  7121f7:	44 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%r8d
  7121fe:	00 
  7121ff:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  712203:	eb 26                	jmp    71222b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x33b>
  712205:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71220c:	00 00 00 00 
  712210:	49 89 ca             	mov    %rcx,%r10
  712213:	4d 89 0a             	mov    %r9,(%r10)
  712216:	0f 28 04 24          	movaps (%rsp),%xmm0
  71221a:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  71221f:	48 ff c2             	inc    %rdx
  712222:	49 83 c0 18          	add    $0x18,%r8
  712226:	48 39 f2             	cmp    %rsi,%rdx
  712229:	74 76                	je     7122a1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x3b1>
  71222b:	4c 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%r9
  712232:	00 
  712233:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  712237:	42 0f 10 04 17       	movups (%rdi,%r10,1),%xmm0
  71223c:	42 0f 11 04 11       	movups %xmm0,(%rcx,%r10,1)
  712241:	4e 8b 4c 17 10       	mov    0x10(%rdi,%r10,1),%r9
  712246:	4e 89 4c 11 10       	mov    %r9,0x10(%rcx,%r10,1)
  71224b:	4e 8b 0c 11          	mov    (%rcx,%r10,1),%r9
  71224f:	4e 3b 4c 11 e8       	cmp    -0x18(%rcx,%r10,1),%r9
  712254:	73 c9                	jae    71221f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x32f>
  712256:	49 01 fa             	add    %rdi,%r10
  712259:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  71225e:	0f 29 04 24          	movaps %xmm0,(%rsp)
  712262:	4d 89 c3             	mov    %r8,%r11
  712265:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71226c:	00 00 00 00 
  712270:	4e 8b 54 19 f8       	mov    -0x8(%rcx,%r11,1),%r10
  712275:	4e 89 54 19 10       	mov    %r10,0x10(%rcx,%r11,1)
  71227a:	42 0f 10 44 19 e8    	movups -0x18(%rcx,%r11,1),%xmm0
  712280:	42 0f 11 04 19       	movups %xmm0,(%rcx,%r11,1)
  712285:	49 83 fb 18          	cmp    $0x18,%r11
  712289:	74 85                	je     712210 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x320>
  71228b:	4d 8d 53 e8          	lea    -0x18(%r11),%r10
  71228f:	4e 3b 4c 19 d0       	cmp    -0x30(%rcx,%r11,1),%r9
  712294:	4d 89 d3             	mov    %r10,%r11
  712297:	72 d7                	jb     712270 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x380>
  712299:	49 01 ca             	add    %rcx,%r10
  71229c:	e9 72 ff ff ff       	jmp    712213 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x323>
  7122a1:	4b 8d 14 76          	lea    (%r14,%r14,2),%rdx
  7122a5:	4c 8d 0c d3          	lea    (%rbx,%rdx,8),%r9
  7122a9:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  7122ad:	48 8d 34 d4          	lea    (%rsp,%rdx,8),%rsi
  7122b1:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
  7122b5:	48 8d 51 e8          	lea    -0x18(%rcx),%rdx
  7122b9:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  7122be:	49 89 d8             	mov    %rbx,%r8
  7122c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7122c8:	0f 1f 84 00 00 00 00 
  7122cf:	00 
  7122d0:	49 89 ca             	mov    %rcx,%r10
  7122d3:	49 89 fb             	mov    %rdi,%r11
  7122d6:	48 8b 39             	mov    (%rcx),%rdi
  7122d9:	48 83 c1 18          	add    $0x18,%rcx
  7122dd:	49 3b 3b             	cmp    (%r11),%rdi
  7122e0:	49 8d 7b 18          	lea    0x18(%r11),%rdi
  7122e4:	49 0f 42 fb          	cmovb  %r11,%rdi
  7122e8:	4d 0f 42 da          	cmovb  %r10,%r11
  7122ec:	4d 8b 7b 10          	mov    0x10(%r11),%r15
  7122f0:	4d 89 78 10          	mov    %r15,0x10(%r8)
  7122f4:	49 0f 43 ca          	cmovae %r10,%rcx
  7122f8:	4c 8b 16             	mov    (%rsi),%r10
  7122fb:	4c 8b 3a             	mov    (%rdx),%r15
  7122fe:	4d 39 fa             	cmp    %r15,%r10
  712301:	41 bc 00 00 00 00    	mov    $0x0,%r12d
  712307:	49 83 d4 ff          	adc    $0xffffffffffffffff,%r12
  71230b:	4d 39 fa             	cmp    %r15,%r10
  71230e:	49 89 f2             	mov    %rsi,%r10
  712311:	4c 0f 42 d2          	cmovb  %rdx,%r10
  712315:	41 0f 10 03          	movups (%r11),%xmm0
  712319:	41 bb 00 00 00 00    	mov    $0x0,%r11d
  71231f:	4d 19 db             	sbb    %r11,%r11
  712322:	41 0f 11 00          	movups %xmm0,(%r8)
  712326:	49 83 c0 18          	add    $0x18,%r8
  71232a:	4d 8b 7a 10          	mov    0x10(%r10),%r15
  71232e:	4d 89 79 10          	mov    %r15,0x10(%r9)
  712332:	41 0f 10 02          	movups (%r10),%xmm0
  712336:	41 0f 11 01          	movups %xmm0,(%r9)
  71233a:	4f 8d 14 64          	lea    (%r12,%r12,2),%r10
  71233e:	4a 8d 34 d6          	lea    (%rsi,%r10,8),%rsi
  712342:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
  712346:	4a 8d 14 d2          	lea    (%rdx,%r10,8),%rdx
  71234a:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  71234e:	48 ff c8             	dec    %rax
  712351:	0f 85 79 ff ff ff    	jne    7122d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x3e0>
  712357:	48 83 c2 18          	add    $0x18,%rdx
  71235b:	48 83 c6 18          	add    $0x18,%rsi
  71235f:	41 f6 c6 01          	test   $0x1,%r14b
  712363:	75 20                	jne    712385 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x495>
  712365:	48 39 f1             	cmp    %rsi,%rcx
  712368:	0f 95 c0             	setne  %al
  71236b:	48 39 d7             	cmp    %rdx,%rdi
  71236e:	75 4a                	jne    7123ba <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x4ca>
  712370:	84 c0                	test   %al,%al
  712372:	75 4c                	jne    7123c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x4d0>
  712374:	48 81 c4 90 04 00 00 	add    $0x490,%rsp
  71237b:	5b                   	pop    %rbx
  71237c:	41 5c                	pop    %r12
  71237e:	41 5d                	pop    %r13
  712380:	41 5e                	pop    %r14
  712382:	41 5f                	pop    %r15
  712384:	c3                   	ret
  712385:	48 8d 47 18          	lea    0x18(%rdi),%rax
  712389:	4c 8d 49 18          	lea    0x18(%rcx),%r9
  71238d:	48 39 d7             	cmp    %rdx,%rdi
  712390:	49 89 ca             	mov    %rcx,%r10
  712393:	4c 0f 42 d7          	cmovb  %rdi,%r10
  712397:	4d 8b 5a 10          	mov    0x10(%r10),%r11
  71239b:	4d 89 58 10          	mov    %r11,0x10(%r8)
  71239f:	41 0f 10 02          	movups (%r10),%xmm0
  7123a3:	41 0f 11 00          	movups %xmm0,(%r8)
  7123a7:	48 0f 42 f8          	cmovb  %rax,%rdi
  7123ab:	49 0f 43 c9          	cmovae %r9,%rcx
  7123af:	48 39 f1             	cmp    %rsi,%rcx
  7123b2:	0f 95 c0             	setne  %al
  7123b5:	48 39 d7             	cmp    %rdx,%rdi
  7123b8:	74 b6                	je     712370 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x480>
  7123ba:	b0 01                	mov    $0x1,%al
  7123bc:	84 c0                	test   %al,%al
  7123be:	74 b4                	je     712374 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB38_+0x484>
  7123c0:	ff 15 7a 89 3d 00    	call   *0x3d897a(%rip)        # aead40 <_DYNAMIC+0x6c8>
  7123c6:	0f 0b                	ud2
  7123c8:	49 89 c7             	mov    %rax,%r15
  7123cb:	49 c1 e6 03          	shl    $0x3,%r14
  7123cf:	4b 8d 14 76          	lea    (%r14,%r14,2),%rdx
  7123d3:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  7123d8:	48 89 df             	mov    %rbx,%rdi
  7123db:	ff 15 07 85 3d 00    	call   *0x3d8507(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  7123e1:	4c 89 ff             	mov    %r15,%rdi
  7123e4:	e8 b7 8c 3a 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
