
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072ffc0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_>:
  72ffc0:	41 57                	push   %r15
  72ffc2:	41 56                	push   %r14
  72ffc4:	41 55                	push   %r13
  72ffc6:	41 54                	push   %r12
  72ffc8:	53                   	push   %rbx
  72ffc9:	48 81 ec 40 01 00 00 	sub    $0x140,%rsp
  72ffd0:	48 89 fb             	mov    %rdi,%rbx
  72ffd3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  72ffd8:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  72ffdd:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  72ffe2:	48 8b 07             	mov    (%rdi),%rax
  72ffe5:	48 85 c0             	test   %rax,%rax
  72ffe8:	74 46                	je     730030 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x70>
  72ffea:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  72ffee:	48 85 c9             	test   %rcx,%rcx
  72fff1:	0f 84 97 00 00 00    	je     73008e <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0xce>
  72fff7:	48 89 ca             	mov    %rcx,%rdx
  72fffa:	48 83 e2 07          	and    $0x7,%rdx
  72fffe:	74 36                	je     730036 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x76>
  730000:	31 f6                	xor    %esi,%esi
  730002:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  730009:	1f 84 00 00 00 00 00 
  730010:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  730017:	48 ff c6             	inc    %rsi
  73001a:	48 39 f2             	cmp    %rsi,%rdx
  73001d:	75 f1                	jne    730010 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x50>
  73001f:	48 89 ca             	mov    %rcx,%rdx
  730022:	48 29 f2             	sub    %rsi,%rdx
  730025:	48 89 de             	mov    %rbx,%rsi
  730028:	48 83 f9 08          	cmp    $0x8,%rcx
  73002c:	73 22                	jae    730050 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x90>
  73002e:	eb 61                	jmp    730091 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0xd1>
  730030:	31 c0                	xor    %eax,%eax
  730032:	31 f6                	xor    %esi,%esi
  730034:	eb 5b                	jmp    730091 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0xd1>
  730036:	48 89 ca             	mov    %rcx,%rdx
  730039:	48 89 de             	mov    %rbx,%rsi
  73003c:	48 83 f9 08          	cmp    $0x8,%rcx
  730040:	72 4f                	jb     730091 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0xd1>
  730042:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  730049:	1f 84 00 00 00 00 00 
  730050:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  730057:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  73005e:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  730065:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  73006c:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  730073:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  73007a:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  730081:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  730088:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  73008c:	75 c2                	jne    730050 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x90>
  73008e:	48 89 de             	mov    %rbx,%rsi
  730091:	4c 8d 6b 10          	lea    0x10(%rbx),%r13
  730095:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
  73009a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  73009f:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  7300a4:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  7300a9:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  7300ae:	0f 57 c0             	xorps  %xmm0,%xmm0
  7300b1:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
  7300b6:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  7300bb:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  7300c0:	e8 9b 8e fe ff       	call   718f60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>
  7300c5:	83 7c 24 50 02       	cmpl   $0x2,0x50(%rsp)
  7300ca:	0f 84 b2 00 00 00    	je     730182 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x1c2>
  7300d0:	4c 8d b4 24 20 01 00 	lea    0x120(%rsp),%r14
  7300d7:	00 
  7300d8:	4c 8d 7c 24 48       	lea    0x48(%rsp),%r15
  7300dd:	4c 8d 64 24 18       	lea    0x18(%rsp),%r12
  7300e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7300e9:	1f 84 00 00 00 00 00 
  7300f0:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  7300f7:	00 
  7300f8:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  7300ff:	00 
  730100:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
  730107:	00 
  730108:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  73010f:	00 
  730110:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  730117:	00 
  730118:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  73011f:	00 
  730120:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  730127:	00 
  730128:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  73012f:	00 
  730130:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  730135:	0f 10 4c 24 58       	movups 0x58(%rsp),%xmm1
  73013a:	0f 10 54 24 68       	movups 0x68(%rsp),%xmm2
  73013f:	0f 10 5c 24 78       	movups 0x78(%rsp),%xmm3
  730144:	0f 29 9c 24 f0 00 00 	movaps %xmm3,0xf0(%rsp)
  73014b:	00 
  73014c:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  730153:	00 
  730154:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
  73015b:	00 
  73015c:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  730163:	00 
  730164:	4c 89 f7             	mov    %r14,%rdi
  730167:	e8 74 79 fe ff       	call   717ae0 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  73016c:	4c 89 ff             	mov    %r15,%rdi
  73016f:	4c 89 e6             	mov    %r12,%rsi
  730172:	e8 e9 8d fe ff       	call   718f60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>
  730177:	83 7c 24 50 02       	cmpl   $0x2,0x50(%rsp)
  73017c:	0f 85 6e ff ff ff    	jne    7300f0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x130>
  730182:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
  730187:	75 17                	jne    7301a0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x1e0>
  730189:	48 89 df             	mov    %rbx,%rdi
  73018c:	e8 1f 89 fe ff       	call   718ab0 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB19_5style5StyleEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  730191:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  730198:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  73019f:	00 
  7301a0:	48 81 c4 40 01 00 00 	add    $0x140,%rsp
  7301a7:	5b                   	pop    %rbx
  7301a8:	41 5c                	pop    %r12
  7301aa:	41 5d                	pop    %r13
  7301ac:	41 5e                	pop    %r14
  7301ae:	41 5f                	pop    %r15
  7301b0:	c3                   	ret
  7301b1:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  7301b8:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  7301bf:	00 
  7301c0:	48 89 c7             	mov    %rax,%rdi
  7301c3:	e8 88 82 38 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
