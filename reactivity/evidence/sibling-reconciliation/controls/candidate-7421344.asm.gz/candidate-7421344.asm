
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000713da0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_>:
  713da0:	55                   	push   %rbp
  713da1:	41 57                	push   %r15
  713da3:	41 56                	push   %r14
  713da5:	41 55                	push   %r13
  713da7:	41 54                	push   %r12
  713da9:	53                   	push   %rbx
  713daa:	48 83 ec 28          	sub    $0x28,%rsp
  713dae:	49 89 f6             	mov    %rsi,%r14
  713db1:	48 89 fb             	mov    %rdi,%rbx
  713db4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  713dbb:	00 00 00 00 00 
  713dc0:	4c 89 f7             	mov    %r14,%rdi
  713dc3:	e8 d8 53 00 00       	call   7191a0 <_RNvXsk_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_4IterNtNtNtCshBhuxcId5D0_4gpui7runtime6scroll11ViewportKeyNtB14_13ViewportStateENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  713dc8:	48 85 c0             	test   %rax,%rax
  713dcb:	0f 84 f1 02 00 00    	je     7140c2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x322>
  713dd1:	80 38 00             	cmpb   $0x0,(%rax)
  713dd4:	75 ea                	jne    713dc0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x20>
  713dd6:	48 83 3a 02          	cmpq   $0x2,(%rdx)
  713dda:	74 e4                	je     713dc0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x20>
  713ddc:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  713de1:	4c 8b 7a 18          	mov    0x18(%rdx),%r15
  713de5:	4c 8b 60 08          	mov    0x8(%rax),%r12
  713de9:	ff 15 f1 3e 3d 00    	call   *0x3d3ef1(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  713def:	bf 40 00 00 00       	mov    $0x40,%edi
  713df4:	be 08 00 00 00       	mov    $0x8,%esi
  713df9:	ff 15 c1 3e 3d 00    	call   *0x3d3ec1(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  713dff:	48 85 c0             	test   %rax,%rax
  713e02:	0f 84 18 03 00 00    	je     714120 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x380>
  713e08:	4c 89 38             	mov    %r15,(%rax)
  713e0b:	4c 89 60 08          	mov    %r12,0x8(%rax)
  713e0f:	48 c7 04 24 04 00 00 	movq   $0x4,(%rsp)
  713e16:	00 
  713e17:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  713e1c:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
  713e23:	00 00 
  713e25:	45 0f b6 1e          	movzbl (%r14),%r11d
  713e29:	4d 8b 6e 08          	mov    0x8(%r14),%r13
  713e2d:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  713e31:	49 8b 6e 18          	mov    0x18(%r14),%rbp
  713e35:	4d 8b 66 40          	mov    0x40(%r14),%r12
  713e39:	be 01 00 00 00       	mov    $0x1,%esi
  713e3e:	48 89 e7             	mov    %rsp,%rdi
  713e41:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  713e48:	0f 1f 84 00 00 00 00 
  713e4f:	00 
  713e50:	4d 85 e4             	test   %r12,%r12
  713e53:	0f 84 82 02 00 00    	je     7140db <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x33b>
  713e59:	41 f6 c3 01          	test   $0x1,%r11b
  713e5d:	0f 84 ae 02 00 00    	je     714111 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x371>
  713e63:	4d 85 ed             	test   %r13,%r13
  713e66:	74 28                	je     713e90 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xf0>
  713e68:	41 0f b7 95 8a 05 00 	movzwl 0x58a(%r13),%edx
  713e6f:	00 
  713e70:	48 39 d5             	cmp    %rdx,%rbp
  713e73:	0f 83 c7 00 00 00    	jae    713f40 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1a0>
  713e79:	4c 89 ea             	mov    %r13,%rdx
  713e7c:	49 89 ea             	mov    %rbp,%r10
  713e7f:	e9 e4 00 00 00       	jmp    713f68 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1c8>
  713e84:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  713e8b:	00 00 00 00 00 
  713e90:	48 85 ed             	test   %rbp,%rbp
  713e93:	74 38                	je     713ecd <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x12d>
  713e95:	48 89 ea             	mov    %rbp,%rdx
  713e98:	49 89 cd             	mov    %rcx,%r13
  713e9b:	48 83 e2 07          	and    $0x7,%rdx
  713e9f:	74 31                	je     713ed2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x132>
  713ea1:	45 31 c0             	xor    %r8d,%r8d
  713ea4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  713eab:	00 00 00 00 00 
  713eb0:	4d 8b ad 90 05 00 00 	mov    0x590(%r13),%r13
  713eb7:	49 ff c0             	inc    %r8
  713eba:	4c 39 c2             	cmp    %r8,%rdx
  713ebd:	75 f1                	jne    713eb0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x110>
  713ebf:	48 89 e9             	mov    %rbp,%rcx
  713ec2:	4c 29 c1             	sub    %r8,%rcx
  713ec5:	48 83 fd 08          	cmp    $0x8,%rbp
  713ec9:	73 15                	jae    713ee0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x140>
  713ecb:	eb 51                	jmp    713f1e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  713ecd:	49 89 cd             	mov    %rcx,%r13
  713ed0:	eb 4c                	jmp    713f1e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  713ed2:	48 89 e9             	mov    %rbp,%rcx
  713ed5:	48 83 fd 08          	cmp    $0x8,%rbp
  713ed9:	72 43                	jb     713f1e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  713edb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  713ee0:	49 8b 95 90 05 00 00 	mov    0x590(%r13),%rdx
  713ee7:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713eee:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713ef5:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713efc:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f03:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f0a:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f11:	4c 8b aa 90 05 00 00 	mov    0x590(%rdx),%r13
  713f18:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  713f1c:	75 c2                	jne    713ee0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x140>
  713f1e:	31 c9                	xor    %ecx,%ecx
  713f20:	31 ed                	xor    %ebp,%ebp
  713f22:	41 0f b7 95 8a 05 00 	movzwl 0x58a(%r13),%edx
  713f29:	00 
  713f2a:	48 39 d5             	cmp    %rdx,%rbp
  713f2d:	0f 82 46 ff ff ff    	jb     713e79 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xd9>
  713f33:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  713f3a:	84 00 00 00 00 00 
  713f40:	49 8b 95 80 05 00 00 	mov    0x580(%r13),%rdx
  713f47:	48 85 d2             	test   %rdx,%rdx
  713f4a:	0f 84 b2 01 00 00    	je     714102 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x362>
  713f50:	48 ff c1             	inc    %rcx
  713f53:	45 0f b7 95 88 05 00 	movzwl 0x588(%r13),%r10d
  713f5a:	00 
  713f5b:	49 89 d5             	mov    %rdx,%r13
  713f5e:	66 44 3b 92 8a 05 00 	cmp    0x58a(%rdx),%r10w
  713f65:	00 
  713f66:	73 d8                	jae    713f40 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1a0>
  713f68:	48 85 c9             	test   %rcx,%rcx
  713f6b:	0f 84 8f 00 00 00    	je     714000 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x260>
  713f71:	4e 8d 1c d2          	lea    (%rdx,%r10,8),%r11
  713f75:	49 81 c3 98 05 00 00 	add    $0x598,%r11
  713f7c:	49 89 c8             	mov    %rcx,%r8
  713f7f:	49 83 e0 07          	and    $0x7,%r8
  713f83:	0f 84 27 01 00 00    	je     7140b0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x310>
  713f89:	45 31 c9             	xor    %r9d,%r9d
  713f8c:	0f 1f 40 00          	nopl   0x0(%rax)
  713f90:	4d 8b 2b             	mov    (%r11),%r13
  713f93:	4d 8d 9d 90 05 00 00 	lea    0x590(%r13),%r11
  713f9a:	49 ff c1             	inc    %r9
  713f9d:	4d 39 c8             	cmp    %r9,%r8
  713fa0:	75 ee                	jne    713f90 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1f0>
  713fa2:	49 89 c8             	mov    %rcx,%r8
  713fa5:	4d 29 c8             	sub    %r9,%r8
  713fa8:	48 83 f9 08          	cmp    $0x8,%rcx
  713fac:	72 43                	jb     713ff1 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x251>
  713fae:	66 90                	xchg   %ax,%ax
  713fb0:	49 8b 0b             	mov    (%r11),%rcx
  713fb3:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  713fba:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  713fc1:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  713fc8:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  713fcf:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  713fd6:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  713fdd:	4c 8b a9 90 05 00 00 	mov    0x590(%rcx),%r13
  713fe4:	4d 8d 9d 90 05 00 00 	lea    0x590(%r13),%r11
  713feb:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  713fef:	75 bf                	jne    713fb0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x210>
  713ff1:	31 ed                	xor    %ebp,%ebp
  713ff3:	eb 12                	jmp    714007 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x267>
  713ff5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  713ffc:	00 00 00 00 
  714000:	49 8d 6a 01          	lea    0x1(%r10),%rbp
  714004:	49 89 d5             	mov    %rdx,%r13
  714007:	49 ff cc             	dec    %r12
  71400a:	4d 89 d0             	mov    %r10,%r8
  71400d:	49 c1 e0 04          	shl    $0x4,%r8
  714011:	41 b3 01             	mov    $0x1,%r11b
  714014:	42 80 3c 02 00       	cmpb   $0x0,(%rdx,%r8,1)
  714019:	b9 00 00 00 00       	mov    $0x0,%ecx
  71401e:	0f 85 2c fe ff ff    	jne    713e50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  714024:	4d 6b ca 70          	imul   $0x70,%r10,%r9
  714028:	4a 83 bc 0a b0 00 00 	cmpq   $0x2,0xb0(%rdx,%r9,1)
  71402f:	00 02 
  714031:	b9 00 00 00 00       	mov    $0x0,%ecx
  714036:	0f 84 14 fe ff ff    	je     713e50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  71403c:	4a 8d 0c 0a          	lea    (%rdx,%r9,1),%rcx
  714040:	48 81 c1 b0 00 00 00 	add    $0xb0,%rcx
  714047:	49 01 d0             	add    %rdx,%r8
  71404a:	4c 8b 79 18          	mov    0x18(%rcx),%r15
  71404e:	49 8b 48 08          	mov    0x8(%r8),%rcx
  714052:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  714057:	48 3b 34 24          	cmp    (%rsp),%rsi
  71405b:	75 26                	jne    714083 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x2e3>
  71405d:	ba 01 00 00 00       	mov    $0x1,%edx
  714062:	b9 08 00 00 00       	mov    $0x8,%ecx
  714067:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  71406d:	49 89 fe             	mov    %rdi,%r14
  714070:	48 89 f3             	mov    %rsi,%rbx
  714073:	e8 b8 20 01 00       	call   726130 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  714078:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  71407d:	48 89 de             	mov    %rbx,%rsi
  714080:	4c 89 f7             	mov    %r14,%rdi
  714083:	48 89 f1             	mov    %rsi,%rcx
  714086:	48 c1 e1 04          	shl    $0x4,%rcx
  71408a:	4c 89 3c 08          	mov    %r15,(%rax,%rcx,1)
  71408e:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  714093:	48 89 54 08 08       	mov    %rdx,0x8(%rax,%rcx,1)
  714098:	48 ff c6             	inc    %rsi
  71409b:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  7140a0:	41 b3 01             	mov    $0x1,%r11b
  7140a3:	31 c9                	xor    %ecx,%ecx
  7140a5:	e9 a6 fd ff ff       	jmp    713e50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  7140aa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  7140b0:	49 89 c8             	mov    %rcx,%r8
  7140b3:	48 83 f9 08          	cmp    $0x8,%rcx
  7140b7:	0f 82 34 ff ff ff    	jb     713ff1 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x251>
  7140bd:	e9 ee fe ff ff       	jmp    713fb0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x210>
  7140c2:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  7140c9:	48 c7 43 08 08 00 00 	movq   $0x8,0x8(%rbx)
  7140d0:	00 
  7140d1:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  7140d8:	00 
  7140d9:	eb 15                	jmp    7140f0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x350>
  7140db:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  7140e0:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  7140e5:	48 89 43 10          	mov    %rax,0x10(%rbx)
  7140e9:	0f 10 04 24          	movups (%rsp),%xmm0
  7140ed:	0f 11 03             	movups %xmm0,(%rbx)
  7140f0:	48 89 d8             	mov    %rbx,%rax
  7140f3:	48 83 c4 28          	add    $0x28,%rsp
  7140f7:	5b                   	pop    %rbx
  7140f8:	41 5c                	pop    %r12
  7140fa:	41 5d                	pop    %r13
  7140fc:	41 5e                	pop    %r14
  7140fe:	41 5f                	pop    %r15
  714100:	5d                   	pop    %rbp
  714101:	c3                   	ret
  714102:	48 8d 3d 37 65 3a 00 	lea    0x3a6537(%rip),%rdi        # aba640 <anon.5876dccaaaaea8cd2b0f61f3651112ee.3.llvm.17218317146265502647>
  714109:	ff 15 f9 3b 3d 00    	call   *0x3d3bf9(%rip)        # ae7d08 <_DYNAMIC+0x288>
  71410f:	eb 0d                	jmp    71411e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x37e>
  714111:	48 8d 3d 40 65 3a 00 	lea    0x3a6540(%rip),%rdi        # aba658 <anon.5876dccaaaaea8cd2b0f61f3651112ee.4.llvm.17218317146265502647>
  714118:	ff 15 ea 3b 3d 00    	call   *0x3d3bea(%rip)        # ae7d08 <_DYNAMIC+0x288>
  71411e:	0f 0b                	ud2
  714120:	bf 08 00 00 00       	mov    $0x8,%edi
  714125:	be 40 00 00 00       	mov    $0x40,%esi
  71412a:	ff 15 78 3c 3d 00    	call   *0x3d3c78(%rip)        # ae7da8 <_DYNAMIC+0x328>
  714130:	eb 00                	jmp    714132 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x392>
  714132:	48 89 c3             	mov    %rax,%rbx
  714135:	48 8b 34 24          	mov    (%rsp),%rsi
  714139:	48 85 f6             	test   %rsi,%rsi
  71413c:	74 14                	je     714152 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x3b2>
  71413e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  714143:	48 c1 e6 04          	shl    $0x4,%rsi
  714147:	ba 08 00 00 00       	mov    $0x8,%edx
  71414c:	ff 15 76 3b 3d 00    	call   *0x3d3b76(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  714152:	48 89 df             	mov    %rbx,%rdi
  714155:	e8 f6 42 3a 00       	call   ab8450 <_Unwind_Resume@plt>
  71415a:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
