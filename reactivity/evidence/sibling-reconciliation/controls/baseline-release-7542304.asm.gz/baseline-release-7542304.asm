
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000731620 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>:
  731620:	55                   	push   %rbp
  731621:	41 57                	push   %r15
  731623:	41 56                	push   %r14
  731625:	41 55                	push   %r13
  731627:	41 54                	push   %r12
  731629:	53                   	push   %rbx
  73162a:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
  731631:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  731636:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  73163b:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  731640:	48 83 fe 02          	cmp    $0x2,%rsi
  731644:	0f 82 44 06 00 00    	jb     731c8e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x66e>
  73164a:	49 89 cd             	mov    %rcx,%r13
  73164d:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  731654:	00 00 40 
  731657:	48 89 d1             	mov    %rdx,%rcx
  73165a:	31 d2                	xor    %edx,%edx
  73165c:	48 f7 f6             	div    %rsi
  73165f:	48 83 fa 01          	cmp    $0x1,%rdx
  731663:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  731667:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  73166c:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  731673:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  731678:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  73167d:	73 1e                	jae    73169d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x7d>
  73167f:	48 89 ca             	mov    %rcx,%rdx
  731682:	48 89 f0             	mov    %rsi,%rax
  731685:	48 d1 e8             	shr    $1,%rax
  731688:	48 89 f1             	mov    %rsi,%rcx
  73168b:	48 29 c1             	sub    %rax,%rcx
  73168e:	48 83 f9 40          	cmp    $0x40,%rcx
  731692:	b8 40 00 00 00       	mov    $0x40,%eax
  731697:	48 0f 42 c1          	cmovb  %rcx,%rax
  73169b:	eb 0e                	jmp    7316ab <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x8b>
  73169d:	48 89 f7             	mov    %rsi,%rdi
  7316a0:	ff 15 fa 97 3b 00    	call   *0x3b97fa(%rip)        # aeaea0 <_DYNAMIC+0x828>
  7316a6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  7316ab:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  7316b0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  7316b5:	48 8d 48 20          	lea    0x20(%rax),%rcx
  7316b9:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  7316be:	48 8d 48 10          	lea    0x10(%rax),%rcx
  7316c2:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  7316c7:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  7316cb:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  7316d0:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  7316d6:	31 ed                	xor    %ebp,%ebp
  7316d8:	45 31 c9             	xor    %r9d,%r9d
  7316db:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  7316e2:	00 
  7316e3:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  7316e8:	48 29 ee             	sub    %rbp,%rsi
  7316eb:	77 23                	ja     731710 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xf0>
  7316ed:	0f 1f 00             	nopl   (%rax)
  7316f0:	31 ff                	xor    %edi,%edi
  7316f2:	be 01 00 00 00       	mov    $0x1,%esi
  7316f7:	49 83 f9 02          	cmp    $0x2,%r9
  7316fb:	0f 83 df 00 00 00    	jae    7317e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1c0>
  731701:	e9 80 03 00 00       	jmp    731a86 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  731706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  73170d:	00 00 00 
  731710:	48 89 e9             	mov    %rbp,%rcx
  731713:	48 c1 e1 04          	shl    $0x4,%rcx
  731717:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  73171c:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
  731720:	48 3b 74 24 18       	cmp    0x18(%rsp),%rsi
  731725:	73 49                	jae    731770 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x150>
  731727:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  73172c:	74 62                	je     731790 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x170>
  73172e:	48 83 fe 20          	cmp    $0x20,%rsi
  731732:	b8 20 00 00 00       	mov    $0x20,%eax
  731737:	48 0f 43 f0          	cmovae %rax,%rsi
  73173b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  731740:	48 89 04 24          	mov    %rax,(%rsp)
  731744:	4c 89 e9             	mov    %r13,%rcx
  731747:	45 31 c0             	xor    %r8d,%r8d
  73174a:	4c 89 cb             	mov    %r9,%rbx
  73174d:	45 31 c9             	xor    %r9d,%r9d
  731750:	49 89 f6             	mov    %rsi,%r14
  731753:	e8 c8 88 ff ff       	call   72a020 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  731758:	49 89 d9             	mov    %rbx,%r9
  73175b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  731760:	44 89 f0             	mov    %r14d,%eax
  731763:	eb 18                	jmp    73177d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  731765:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  73176c:	00 00 00 00 
  731770:	48 83 fe 02          	cmp    $0x2,%rsi
  731774:	0f 83 56 03 00 00    	jae    731ad0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x4b0>
  73177a:	48 89 f0             	mov    %rsi,%rax
  73177d:	48 8d 34 45 01 00 00 	lea    0x1(,%rax,2),%rsi
  731784:	00 
  731785:	eb 18                	jmp    73179f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x17f>
  731787:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  73178e:	00 00 
  731790:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  731795:	48 39 c6             	cmp    %rax,%rsi
  731798:	48 0f 43 f0          	cmovae %rax,%rsi
  73179c:	48 01 f6             	add    %rsi,%rsi
  73179f:	4c 89 e0             	mov    %r12,%rax
  7317a2:	48 d1 e8             	shr    $1,%rax
  7317a5:	48 89 f1             	mov    %rsi,%rcx
  7317a8:	48 d1 e9             	shr    $1,%rcx
  7317ab:	48 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%rdi
  7317b2:	00 
  7317b3:	48 29 c7             	sub    %rax,%rdi
  7317b6:	48 8d 04 69          	lea    (%rcx,%rbp,2),%rax
  7317ba:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  7317bf:	48 0f af f9          	imul   %rcx,%rdi
  7317c3:	48 0f af c1          	imul   %rcx,%rax
  7317c7:	48 31 f8             	xor    %rdi,%rax
  7317ca:	bf 7f 00 00 00       	mov    $0x7f,%edi
  7317cf:	48 0f bd f8          	bsr    %rax,%rdi
  7317d3:	83 f7 3f             	xor    $0x3f,%edi
  7317d6:	49 83 f9 02          	cmp    $0x2,%r9
  7317da:	0f 82 a6 02 00 00    	jb     731a86 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  7317e0:	48 89 e9             	mov    %rbp,%rcx
  7317e3:	48 c1 e1 04          	shl    $0x4,%rcx
  7317e7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  7317ec:	48 01 c8             	add    %rcx,%rax
  7317ef:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  7317f4:	48 03 4c 24 58       	add    0x58(%rsp),%rcx
  7317f9:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  7317fe:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  731803:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  731808:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  73180f:	00 
  731810:	eb 4b                	jmp    73185d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x23d>
  731812:	4c 89 ed             	mov    %r13,%rbp
  731815:	4c 89 c6             	mov    %r8,%rsi
  731818:	49 29 f4             	sub    %rsi,%r12
  73181b:	48 89 ef             	mov    %rbp,%rdi
  73181e:	4c 89 e2             	mov    %r12,%rdx
  731821:	ff 15 c1 90 3b 00    	call   *0x3b90c1(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  731827:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  73182e:	00 
  73182f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  731834:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  731839:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  73183e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  731843:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  73184a:	00 
  73184b:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
  731852:	00 
  731853:	49 83 f9 01          	cmp    $0x1,%r9
  731857:	0f 86 23 02 00 00    	jbe    731a80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x460>
  73185d:	42 38 bc 0c 95 00 00 	cmp    %dil,0x95(%rsp,%r9,1)
  731864:	00 
  731865:	0f 82 1b 02 00 00    	jb     731a86 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  73186b:	49 ff c9             	dec    %r9
  73186e:	4a 8b 84 cc d8 00 00 	mov    0xd8(%rsp,%r9,8),%rax
  731875:	00 
  731876:	48 89 c3             	mov    %rax,%rbx
  731879:	48 d1 eb             	shr    $1,%rbx
  73187c:	4d 89 e7             	mov    %r12,%r15
  73187f:	49 d1 ef             	shr    $1,%r15
  731882:	4e 8d 34 3b          	lea    (%rbx,%r15,1),%r14
  731886:	4d 39 ee             	cmp    %r13,%r14
  731889:	77 25                	ja     7318b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x290>
  73188b:	89 c1                	mov    %eax,%ecx
  73188d:	44 09 e1             	or     %r12d,%ecx
  731890:	83 e1 01             	and    $0x1,%ecx
  731893:	75 1b                	jne    7318b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x290>
  731895:	4d 01 f6             	add    %r14,%r14
  731898:	4d 89 f4             	mov    %r14,%r12
  73189b:	49 83 f9 01          	cmp    $0x1,%r9
  73189f:	77 bc                	ja     73185d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x23d>
  7318a1:	e9 da 01 00 00       	jmp    731a80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x460>
  7318a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  7318ad:	00 00 00 
  7318b0:	4c 29 f5             	sub    %r14,%rbp
  7318b3:	48 c1 e5 04          	shl    $0x4,%rbp
  7318b7:	48 03 6c 24 10       	add    0x10(%rsp),%rbp
  7318bc:	a8 01                	test   $0x1,%al
  7318be:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  7318c3:	75 5b                	jne    731920 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x300>
  7318c5:	48 89 d8             	mov    %rbx,%rax
  7318c8:	48 83 c8 01          	or     $0x1,%rax
  7318cc:	4c 0f bd c0          	bsr    %rax,%r8
  7318d0:	41 83 f0 3f          	xor    $0x3f,%r8d
  7318d4:	45 01 c0             	add    %r8d,%r8d
  7318d7:	41 83 f0 7e          	xor    $0x7e,%r8d
  7318db:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  7318e0:	48 89 04 24          	mov    %rax,(%rsp)
  7318e4:	48 89 ef             	mov    %rbp,%rdi
  7318e7:	48 89 de             	mov    %rbx,%rsi
  7318ea:	4c 89 e9             	mov    %r13,%rcx
  7318ed:	45 31 c9             	xor    %r9d,%r9d
  7318f0:	e8 2b 87 ff ff       	call   72a020 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  7318f5:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  7318fa:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  7318ff:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  731904:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  731909:	41 f6 c4 01          	test   $0x1,%r12b
  73190d:	74 17                	je     731926 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x306>
  73190f:	4d 85 ff             	test   %r15,%r15
  731912:	75 66                	jne    73197a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x35a>
  731914:	e9 2a ff ff ff       	jmp    731843 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  731919:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  731920:	41 f6 c4 01          	test   $0x1,%r12b
  731924:	75 e9                	jne    73190f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x2ef>
  731926:	48 89 df             	mov    %rbx,%rdi
  731929:	48 c1 e7 04          	shl    $0x4,%rdi
  73192d:	48 01 ef             	add    %rbp,%rdi
  731930:	4c 89 f8             	mov    %r15,%rax
  731933:	48 83 c8 01          	or     $0x1,%rax
  731937:	4c 0f bd c0          	bsr    %rax,%r8
  73193b:	41 83 f0 3f          	xor    $0x3f,%r8d
  73193f:	45 01 c0             	add    %r8d,%r8d
  731942:	41 83 f0 7e          	xor    $0x7e,%r8d
  731946:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  73194b:	48 89 04 24          	mov    %rax,(%rsp)
  73194f:	4c 89 fe             	mov    %r15,%rsi
  731952:	4c 89 e9             	mov    %r13,%rcx
  731955:	45 31 c9             	xor    %r9d,%r9d
  731958:	e8 c3 86 ff ff       	call   72a020 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  73195d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  731962:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  731967:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  73196c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  731971:	4d 85 ff             	test   %r15,%r15
  731974:	0f 84 c9 fe ff ff    	je     731843 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  73197a:	48 85 db             	test   %rbx,%rbx
  73197d:	0f 84 c0 fe ff ff    	je     731843 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  731983:	49 39 df             	cmp    %rbx,%r15
  731986:	49 89 dc             	mov    %rbx,%r12
  731989:	4d 0f 42 e7          	cmovb  %r15,%r12
  73198d:	4d 39 e5             	cmp    %r12,%r13
  731990:	0f 82 ad fe ff ff    	jb     731843 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  731996:	49 89 dd             	mov    %rbx,%r13
  731999:	49 c1 e5 04          	shl    $0x4,%r13
  73199d:	49 01 ed             	add    %rbp,%r13
  7319a0:	4c 39 fb             	cmp    %r15,%rbx
  7319a3:	48 89 ee             	mov    %rbp,%rsi
  7319a6:	49 0f 47 f5          	cmova  %r13,%rsi
  7319aa:	49 c1 e4 04          	shl    $0x4,%r12
  7319ae:	48 89 d7             	mov    %rdx,%rdi
  7319b1:	4c 89 e2             	mov    %r12,%rdx
  7319b4:	ff 15 2e 8f 3b 00    	call   *0x3b8f2e(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  7319ba:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  7319bf:	4d 01 c4             	add    %r8,%r12
  7319c2:	4c 39 fb             	cmp    %r15,%rbx
  7319c5:	76 5c                	jbe    731a23 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x403>
  7319c7:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  7319cc:	0f 1f 40 00          	nopl   0x0(%rax)
  7319d0:	49 8d 4d f0          	lea    -0x10(%r13),%rcx
  7319d4:	49 8b 54 24 f0       	mov    -0x10(%r12),%rdx
  7319d9:	31 f6                	xor    %esi,%esi
  7319db:	31 ff                	xor    %edi,%edi
  7319dd:	49 3b 55 f0          	cmp    -0x10(%r13),%rdx
  7319e1:	49 8d 54 24 f0       	lea    -0x10(%r12),%rdx
  7319e6:	40 0f 92 c6          	setb   %sil
  7319ea:	48 0f 42 d1          	cmovb  %rcx,%rdx
  7319ee:	40 0f 93 c7          	setae  %dil
  7319f2:	0f 10 02             	movups (%rdx),%xmm0
  7319f5:	0f 11 00             	movups %xmm0,(%rax)
  7319f8:	c1 e7 04             	shl    $0x4,%edi
  7319fb:	49 01 fd             	add    %rdi,%r13
  7319fe:	49 83 c5 f0          	add    $0xfffffffffffffff0,%r13
  731a02:	c1 e6 04             	shl    $0x4,%esi
  731a05:	49 01 f4             	add    %rsi,%r12
  731a08:	49 83 c4 f0          	add    $0xfffffffffffffff0,%r12
  731a0c:	49 39 ed             	cmp    %rbp,%r13
  731a0f:	0f 84 fd fd ff ff    	je     731812 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f2>
  731a15:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  731a19:	4d 39 c4             	cmp    %r8,%r12
  731a1c:	75 b2                	jne    7319d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x3b0>
  731a1e:	e9 ef fd ff ff       	jmp    731812 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f2>
  731a23:	4c 89 c6             	mov    %r8,%rsi
  731a26:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  731a2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  731a30:	48 89 f2             	mov    %rsi,%rdx
  731a33:	49 8b 4d 00          	mov    0x0(%r13),%rcx
  731a37:	31 c0                	xor    %eax,%eax
  731a39:	31 f6                	xor    %esi,%esi
  731a3b:	48 3b 0a             	cmp    (%rdx),%rcx
  731a3e:	0f 92 c1             	setb   %cl
  731a41:	40 0f 93 c6          	setae  %sil
  731a45:	48 89 d7             	mov    %rdx,%rdi
  731a48:	49 0f 42 fd          	cmovb  %r13,%rdi
  731a4c:	0f 10 07             	movups (%rdi),%xmm0
  731a4f:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
  731a53:	c1 e6 04             	shl    $0x4,%esi
  731a56:	48 01 d6             	add    %rdx,%rsi
  731a59:	48 83 c5 10          	add    $0x10,%rbp
  731a5d:	4c 39 e6             	cmp    %r12,%rsi
  731a60:	0f 84 b2 fd ff ff    	je     731818 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f8>
  731a66:	88 c8                	mov    %cl,%al
  731a68:	c1 e0 04             	shl    $0x4,%eax
  731a6b:	49 01 c5             	add    %rax,%r13
  731a6e:	4d 39 c5             	cmp    %r8,%r13
  731a71:	75 bd                	jne    731a30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x410>
  731a73:	e9 a0 fd ff ff       	jmp    731818 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f8>
  731a78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  731a7f:	00 
  731a80:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  731a86:	4e 89 a4 cc d8 00 00 	mov    %r12,0xd8(%rsp,%r9,8)
  731a8d:	00 
  731a8e:	42 88 bc 0c 96 00 00 	mov    %dil,0x96(%rsp,%r9,1)
  731a95:	00 
  731a96:	48 39 6c 24 28       	cmp    %rbp,0x28(%rsp)
  731a9b:	0f 86 b3 01 00 00    	jbe    731c54 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x634>
  731aa1:	49 ff c1             	inc    %r9
  731aa4:	48 89 f0             	mov    %rsi,%rax
  731aa7:	48 d1 e8             	shr    $1,%rax
  731aaa:	48 01 c5             	add    %rax,%rbp
  731aad:	49 89 f4             	mov    %rsi,%r12
  731ab0:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  731ab5:	48 29 ee             	sub    %rbp,%rsi
  731ab8:	0f 87 52 fc ff ff    	ja     731710 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xf0>
  731abe:	e9 2d fc ff ff       	jmp    7316f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xd0>
  731ac3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  731aca:	84 00 00 00 00 00 
  731ad0:	4c 8b 1f             	mov    (%rdi),%r11
  731ad3:	4c 8b 77 10          	mov    0x10(%rdi),%r14
  731ad7:	4d 39 de             	cmp    %r11,%r14
  731ada:	49 89 f7             	mov    %rsi,%r15
  731add:	73 15                	jae    731af4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x4d4>
  731adf:	48 83 fe 02          	cmp    $0x2,%rsi
  731ae3:	75 54                	jne    731b39 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x519>
  731ae5:	b8 02 00 00 00       	mov    $0x2,%eax
  731aea:	be 01 00 00 00       	mov    $0x1,%esi
  731aef:	e9 af 00 00 00       	jmp    731ba3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x583>
  731af4:	b8 02 00 00 00       	mov    $0x2,%eax
  731af9:	48 83 fe 02          	cmp    $0x2,%rsi
  731afd:	0f 84 7a fc ff ff    	je     73177d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  731b03:	4c 89 cb             	mov    %r9,%rbx
  731b06:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  731b0b:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  731b0f:	b8 02 00 00 00       	mov    $0x2,%eax
  731b14:	4d 89 f1             	mov    %r14,%r9
  731b17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  731b1e:	00 00 
  731b20:	4d 89 ca             	mov    %r9,%r10
  731b23:	4d 8b 08             	mov    (%r8),%r9
  731b26:	4d 39 d1             	cmp    %r10,%r9
  731b29:	72 52                	jb     731b7d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x55d>
  731b2b:	48 ff c0             	inc    %rax
  731b2e:	49 83 c0 10          	add    $0x10,%r8
  731b32:	49 39 c7             	cmp    %rax,%r15
  731b35:	75 e9                	jne    731b20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x500>
  731b37:	eb 2e                	jmp    731b67 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x547>
  731b39:	4c 89 cb             	mov    %r9,%rbx
  731b3c:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  731b41:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  731b45:	b8 02 00 00 00       	mov    $0x2,%eax
  731b4a:	4d 89 f1             	mov    %r14,%r9
  731b4d:	0f 1f 00             	nopl   (%rax)
  731b50:	4d 89 ca             	mov    %r9,%r10
  731b53:	4d 8b 08             	mov    (%r8),%r9
  731b56:	4d 39 d1             	cmp    %r10,%r9
  731b59:	73 22                	jae    731b7d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x55d>
  731b5b:	48 ff c0             	inc    %rax
  731b5e:	49 83 c0 10          	add    $0x10,%r8
  731b62:	49 39 c7             	cmp    %rax,%r15
  731b65:	75 e9                	jne    731b50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x530>
  731b67:	4c 89 fe             	mov    %r15,%rsi
  731b6a:	4c 89 f8             	mov    %r15,%rax
  731b6d:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  731b72:	49 89 d9             	mov    %rbx,%r9
  731b75:	0f 82 ac fb ff ff    	jb     731727 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x107>
  731b7b:	eb 11                	jmp    731b8e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x56e>
  731b7d:	4c 89 fe             	mov    %r15,%rsi
  731b80:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  731b85:	49 89 d9             	mov    %rbx,%r9
  731b88:	0f 82 99 fb ff ff    	jb     731727 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x107>
  731b8e:	4d 39 de             	cmp    %r11,%r14
  731b91:	0f 83 e6 fb ff ff    	jae    73177d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  731b97:	48 89 c6             	mov    %rax,%rsi
  731b9a:	48 d1 ee             	shr    $1,%rsi
  731b9d:	0f 84 da fb ff ff    	je     73177d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  731ba3:	49 89 c0             	mov    %rax,%r8
  731ba6:	49 c1 e0 04          	shl    $0x4,%r8
  731baa:	4a 8d 1c 07          	lea    (%rdi,%r8,1),%rbx
  731bae:	48 83 fe 01          	cmp    $0x1,%rsi
  731bb2:	75 04                	jne    731bb8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x598>
  731bb4:	31 c9                	xor    %ecx,%ecx
  731bb6:	eb 79                	jmp    731c31 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x611>
  731bb8:	4d 89 ce             	mov    %r9,%r14
  731bbb:	49 89 f1             	mov    %rsi,%r9
  731bbe:	49 83 e1 fe          	and    $0xfffffffffffffffe,%r9
  731bc2:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  731bc7:	4c 8d 14 0a          	lea    (%rdx,%rcx,1),%r10
  731bcb:	49 01 c8             	add    %rcx,%r8
  731bce:	4c 03 44 24 58       	add    0x58(%rsp),%r8
  731bd3:	31 c9                	xor    %ecx,%ecx
  731bd5:	48 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%rdx
  731bdc:	ff ff 0f 
  731bdf:	90                   	nop
  731be0:	41 0f 10 42 f0       	movups -0x10(%r10),%xmm0
  731be5:	41 0f 10 08          	movups (%r8),%xmm1
  731be9:	41 0f 11 4a f0       	movups %xmm1,-0x10(%r10)
  731bee:	41 0f 11 00          	movups %xmm0,(%r8)
  731bf2:	49 89 cb             	mov    %rcx,%r11
  731bf5:	49 31 d3             	xor    %rdx,%r11
  731bf8:	49 c1 e3 04          	shl    $0x4,%r11
  731bfc:	41 0f 10 02          	movups (%r10),%xmm0
  731c00:	42 0f 10 0c 1b       	movups (%rbx,%r11,1),%xmm1
  731c05:	41 0f 11 0a          	movups %xmm1,(%r10)
  731c09:	42 0f 11 04 1b       	movups %xmm0,(%rbx,%r11,1)
  731c0e:	48 83 c1 02          	add    $0x2,%rcx
  731c12:	49 83 c2 20          	add    $0x20,%r10
  731c16:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
  731c1a:	49 39 c9             	cmp    %rcx,%r9
  731c1d:	75 c1                	jne    731be0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x5c0>
  731c1f:	40 f6 c6 01          	test   $0x1,%sil
  731c23:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  731c28:	4d 89 f1             	mov    %r14,%r9
  731c2b:	0f 84 4c fb ff ff    	je     73177d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  731c31:	48 89 ce             	mov    %rcx,%rsi
  731c34:	48 f7 d6             	not    %rsi
  731c37:	48 c1 e1 04          	shl    $0x4,%rcx
  731c3b:	48 c1 e6 04          	shl    $0x4,%rsi
  731c3f:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  731c43:	0f 10 0c 33          	movups (%rbx,%rsi,1),%xmm1
  731c47:	0f 11 0c 0f          	movups %xmm1,(%rdi,%rcx,1)
  731c4b:	0f 11 04 33          	movups %xmm0,(%rbx,%rsi,1)
  731c4f:	e9 29 fb ff ff       	jmp    73177d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  731c54:	41 f6 c4 01          	test   $0x1,%r12b
  731c58:	75 34                	jne    731c8e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x66e>
  731c5a:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  731c5f:	48 89 f0             	mov    %rsi,%rax
  731c62:	48 83 c8 01          	or     $0x1,%rax
  731c66:	4c 0f bd c0          	bsr    %rax,%r8
  731c6a:	41 83 f0 3f          	xor    $0x3f,%r8d
  731c6e:	45 01 c0             	add    %r8d,%r8d
  731c71:	41 83 f0 7e          	xor    $0x7e,%r8d
  731c75:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  731c7a:	48 89 04 24          	mov    %rax,(%rsp)
  731c7e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  731c83:	4c 89 e9             	mov    %r13,%rcx
  731c86:	45 31 c9             	xor    %r9d,%r9d
  731c89:	e8 92 83 ff ff       	call   72a020 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  731c8e:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
  731c95:	5b                   	pop    %rbx
  731c96:	41 5c                	pop    %r12
  731c98:	41 5d                	pop    %r13
  731c9a:	41 5e                	pop    %r14
  731c9c:	41 5f                	pop    %r15
  731c9e:	5d                   	pop    %rbp
  731c9f:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
