
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000072dfe0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_>:
  72dfe0:	48 83 fe 02          	cmp    $0x2,%rsi
  72dfe4:	0f 82 4e 01 00 00    	jb     72e138 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  72dfea:	49 89 d0             	mov    %rdx,%r8
  72dfed:	8b 07                	mov    (%rdi),%eax
  72dfef:	8b 4f 04             	mov    0x4(%rdi),%ecx
  72dff2:	ba 02 00 00 00       	mov    $0x2,%edx
  72dff7:	39 c1                	cmp    %eax,%ecx
  72dff9:	73 2b                	jae    72e026 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x46>
  72dffb:	48 83 fe 02          	cmp    $0x2,%rsi
  72dfff:	74 2b                	je     72e02c <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  72e001:	41 89 c9             	mov    %ecx,%r9d
  72e004:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72e00b:	00 00 00 00 00 
  72e010:	45 89 ca             	mov    %r9d,%r10d
  72e013:	44 8b 0c 97          	mov    (%rdi,%rdx,4),%r9d
  72e017:	45 39 d1             	cmp    %r10d,%r9d
  72e01a:	73 10                	jae    72e02c <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  72e01c:	48 ff c2             	inc    %rdx
  72e01f:	48 39 d6             	cmp    %rdx,%rsi
  72e022:	75 ec                	jne    72e010 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x30>
  72e024:	eb 3e                	jmp    72e064 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x84>
  72e026:	48 83 fe 02          	cmp    $0x2,%rsi
  72e02a:	75 1f                	jne    72e04b <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x6b>
  72e02c:	48 39 f2             	cmp    %rsi,%rdx
  72e02f:	74 33                	je     72e064 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x84>
  72e031:	48 89 f0             	mov    %rsi,%rax
  72e034:	48 83 c8 01          	or     $0x1,%rax
  72e038:	48 0f bd c8          	bsr    %rax,%rcx
  72e03c:	83 f1 3f             	xor    $0x3f,%ecx
  72e03f:	01 c9                	add    %ecx,%ecx
  72e041:	83 f1 7e             	xor    $0x7e,%ecx
  72e044:	31 d2                	xor    %edx,%edx
  72e046:	e9 75 aa ff ff       	jmp    728ac0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>
  72e04b:	41 89 c9             	mov    %ecx,%r9d
  72e04e:	66 90                	xchg   %ax,%ax
  72e050:	45 89 ca             	mov    %r9d,%r10d
  72e053:	44 8b 0c 97          	mov    (%rdi,%rdx,4),%r9d
  72e057:	45 39 d1             	cmp    %r10d,%r9d
  72e05a:	72 d0                	jb     72e02c <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  72e05c:	48 ff c2             	inc    %rdx
  72e05f:	48 39 d6             	cmp    %rdx,%rsi
  72e062:	75 ec                	jne    72e050 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x70>
  72e064:	39 c1                	cmp    %eax,%ecx
  72e066:	0f 83 cc 00 00 00    	jae    72e138 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  72e06c:	48 89 f0             	mov    %rsi,%rax
  72e06f:	48 d1 e8             	shr    $1,%rax
  72e072:	48 83 fe 10          	cmp    $0x10,%rsi
  72e076:	73 07                	jae    72e07f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x9f>
  72e078:	31 c9                	xor    %ecx,%ecx
  72e07a:	e9 87 00 00 00       	jmp    72e106 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x126>
  72e07f:	48 b9 f8 ff ff ff ff 	movabs $0xffffffffffffff8,%rcx
  72e086:	ff ff 0f 
  72e089:	48 21 c1             	and    %rax,%rcx
  72e08c:	48 89 c2             	mov    %rax,%rdx
  72e08f:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
  72e093:	48 f7 da             	neg    %rdx
  72e096:	4c 8d 47 10          	lea    0x10(%rdi),%r8
  72e09a:	4c 8d 0c b7          	lea    (%rdi,%rsi,4),%r9
  72e09e:	49 83 c1 f0          	add    $0xfffffffffffffff0,%r9
  72e0a2:	45 31 d2             	xor    %r10d,%r10d
  72e0a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72e0ac:	00 00 00 00 
  72e0b0:	f3 41 0f 6f 40 f0    	movdqu -0x10(%r8),%xmm0
  72e0b6:	f3 41 0f 6f 08       	movdqu (%r8),%xmm1
  72e0bb:	f3 43 0f 6f 54 91 f0 	movdqu -0x10(%r9,%r10,4),%xmm2
  72e0c2:	f3 43 0f 6f 1c 91    	movdqu (%r9,%r10,4),%xmm3
  72e0c8:	66 0f 70 db 1b       	pshufd $0x1b,%xmm3,%xmm3
  72e0cd:	66 0f 70 d2 1b       	pshufd $0x1b,%xmm2,%xmm2
  72e0d2:	f3 41 0f 7f 58 f0    	movdqu %xmm3,-0x10(%r8)
  72e0d8:	f3 41 0f 7f 10       	movdqu %xmm2,(%r8)
  72e0dd:	66 0f 70 c0 1b       	pshufd $0x1b,%xmm0,%xmm0
  72e0e2:	66 0f 70 c9 1b       	pshufd $0x1b,%xmm1,%xmm1
  72e0e7:	f3 43 0f 7f 04 91    	movdqu %xmm0,(%r9,%r10,4)
  72e0ed:	f3 43 0f 7f 4c 91 f0 	movdqu %xmm1,-0x10(%r9,%r10,4)
  72e0f4:	49 83 c2 f8          	add    $0xfffffffffffffff8,%r10
  72e0f8:	49 83 c0 20          	add    $0x20,%r8
  72e0fc:	4c 39 d2             	cmp    %r10,%rdx
  72e0ff:	75 af                	jne    72e0b0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0xd0>
  72e101:	48 39 c8             	cmp    %rcx,%rax
  72e104:	74 32                	je     72e138 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  72e106:	48 f7 d8             	neg    %rax
  72e109:	48 8d 14 8f          	lea    (%rdi,%rcx,4),%rdx
  72e10d:	48 f7 d9             	neg    %rcx
  72e110:	48 8d 34 b7          	lea    (%rdi,%rsi,4),%rsi
  72e114:	48 83 c6 fc          	add    $0xfffffffffffffffc,%rsi
  72e118:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72e11f:	00 
  72e120:	8b 3a                	mov    (%rdx),%edi
  72e122:	44 8b 04 8e          	mov    (%rsi,%rcx,4),%r8d
  72e126:	44 89 02             	mov    %r8d,(%rdx)
  72e129:	89 3c 8e             	mov    %edi,(%rsi,%rcx,4)
  72e12c:	48 ff c9             	dec    %rcx
  72e12f:	48 83 c2 04          	add    $0x4,%rdx
  72e133:	48 39 c8             	cmp    %rcx,%rax
  72e136:	75 e8                	jne    72e120 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x140>
  72e138:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
