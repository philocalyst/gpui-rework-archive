
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000071f340 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_>:
  71f340:	41 57                	push   %r15
  71f342:	41 56                	push   %r14
  71f344:	41 54                	push   %r12
  71f346:	53                   	push   %rbx
  71f347:	50                   	push   %rax
  71f348:	48 89 fb             	mov    %rdi,%rbx
  71f34b:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
  71f34f:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  71f353:	48 89 c8             	mov    %rcx,%rax
  71f356:	4c 29 f8             	sub    %r15,%rax
  71f359:	48 c1 e8 03          	shr    $0x3,%rax
  71f35d:	48 ba 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rdx
  71f364:	c3 30 0c 
  71f367:	48 f7 e2             	mul    %rdx
  71f36a:	4c 39 f9             	cmp    %r15,%rcx
  71f36d:	74 6a                	je     71f3d9 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x99>
  71f36f:	49 89 d6             	mov    %rdx,%r14
  71f372:	49 81 c7 88 00 00 00 	add    $0x88,%r15
  71f379:	4c 8b 25 48 89 3c 00 	mov    0x3c8948(%rip),%r12        # ae7cc8 <_DYNAMIC+0x248>
  71f380:	eb 1a                	jmp    71f39c <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x5c>
  71f382:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71f389:	1f 84 00 00 00 00 00 
  71f390:	49 81 c7 a8 00 00 00 	add    $0xa8,%r15
  71f397:	49 ff ce             	dec    %r14
  71f39a:	74 3d                	je     71f3d9 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x99>
  71f39c:	41 83 bf 78 ff ff ff 	cmpl   $0x2,-0x88(%r15)
  71f3a3:	02 
  71f3a4:	74 ea                	je     71f390 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71f3a6:	49 8b 77 90          	mov    -0x70(%r15),%rsi
  71f3aa:	48 85 f6             	test   %rsi,%rsi
  71f3ad:	74 10                	je     71f3bf <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x7f>
  71f3af:	49 8b 7f 98          	mov    -0x68(%r15),%rdi
  71f3b3:	48 c1 e6 03          	shl    $0x3,%rsi
  71f3b7:	ba 08 00 00 00       	mov    $0x8,%edx
  71f3bc:	41 ff d4             	call   *%r12
  71f3bf:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  71f3c3:	48 85 f6             	test   %rsi,%rsi
  71f3c6:	74 c8                	je     71f390 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71f3c8:	49 8b 3f             	mov    (%r15),%rdi
  71f3cb:	48 c1 e6 05          	shl    $0x5,%rsi
  71f3cf:	ba 08 00 00 00       	mov    $0x8,%edx
  71f3d4:	41 ff d4             	call   *%r12
  71f3d7:	eb b7                	jmp    71f390 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71f3d9:	48 8b 43 10          	mov    0x10(%rbx),%rax
  71f3dd:	48 85 c0             	test   %rax,%rax
  71f3e0:	74 20                	je     71f402 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0xc2>
  71f3e2:	48 8b 3b             	mov    (%rbx),%rdi
  71f3e5:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  71f3ec:	ba 08 00 00 00       	mov    $0x8,%edx
  71f3f1:	48 83 c4 08          	add    $0x8,%rsp
  71f3f5:	5b                   	pop    %rbx
  71f3f6:	41 5c                	pop    %r12
  71f3f8:	41 5e                	pop    %r14
  71f3fa:	41 5f                	pop    %r15
  71f3fc:	ff 25 c6 88 3c 00    	jmp    *0x3c88c6(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  71f402:	48 83 c4 08          	add    $0x8,%rsp
  71f406:	5b                   	pop    %rbx
  71f407:	41 5c                	pop    %r12
  71f409:	41 5e                	pop    %r14
  71f40b:	41 5f                	pop    %r15
  71f40d:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
