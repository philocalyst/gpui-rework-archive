
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072eed0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>:
  72eed0:	55                   	push   %rbp
  72eed1:	41 57                	push   %r15
  72eed3:	41 56                	push   %r14
  72eed5:	41 55                	push   %r13
  72eed7:	41 54                	push   %r12
  72eed9:	53                   	push   %rbx
  72eeda:	48 83 ec 48          	sub    $0x48,%rsp
  72eede:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  72eee3:	48 89 cd             	mov    %rcx,%rbp
  72eee6:	49 89 d7             	mov    %rdx,%r15
  72eee9:	49 89 f5             	mov    %rsi,%r13
  72eeec:	49 89 fc             	mov    %rdi,%r12
  72eeef:	48 83 fe 21          	cmp    $0x21,%rsi
  72eef3:	73 1e                	jae    72ef13 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x43>
  72eef5:	4c 89 e7             	mov    %r12,%rdi
  72eef8:	4c 89 ee             	mov    %r13,%rsi
  72eefb:	4c 89 fa             	mov    %r15,%rdx
  72eefe:	48 89 e9             	mov    %rbp,%rcx
  72ef01:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  72ef08:	00 
  72ef09:	e8 32 2a fe ff       	call   711940 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_>
  72ef0e:	e9 5f 04 00 00       	jmp    72f372 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4a2>
  72ef13:	45 89 c6             	mov    %r8d,%r14d
  72ef16:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  72ef1b:	4c 89 eb             	mov    %r13,%rbx
  72ef1e:	66 90                	xchg   %ax,%ax
  72ef20:	45 85 f6             	test   %r14d,%r14d
  72ef23:	0f 84 2a 04 00 00    	je     72f353 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x483>
  72ef29:	44 89 74 24 14       	mov    %r14d,0x14(%rsp)
  72ef2e:	48 89 d9             	mov    %rbx,%rcx
  72ef31:	48 c1 e9 03          	shr    $0x3,%rcx
  72ef35:	4c 8d 34 49          	lea    (%rcx,%rcx,2),%r14
  72ef39:	49 c1 e6 05          	shl    $0x5,%r14
  72ef3d:	4d 01 e6             	add    %r12,%r14
  72ef40:	48 69 d1 a8 00 00 00 	imul   $0xa8,%rcx,%rdx
  72ef47:	4c 01 e2             	add    %r12,%rdx
  72ef4a:	48 83 fb 40          	cmp    $0x40,%rbx
  72ef4e:	73 30                	jae    72ef80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0xb0>
  72ef50:	49 8b 04 24          	mov    (%r12),%rax
  72ef54:	49 8b 0e             	mov    (%r14),%rcx
  72ef57:	48 39 c8             	cmp    %rcx,%rax
  72ef5a:	40 0f 92 c6          	setb   %sil
  72ef5e:	48 8b 3a             	mov    (%rdx),%rdi
  72ef61:	48 39 f8             	cmp    %rdi,%rax
  72ef64:	0f 92 c0             	setb   %al
  72ef67:	40 30 f0             	xor    %sil,%al
  72ef6a:	48 39 f9             	cmp    %rdi,%rcx
  72ef6d:	0f 92 c1             	setb   %cl
  72ef70:	40 30 f1             	xor    %sil,%cl
  72ef73:	4c 0f 45 f2          	cmovne %rdx,%r14
  72ef77:	84 c0                	test   %al,%al
  72ef79:	4d 0f 45 f4          	cmovne %r12,%r14
  72ef7d:	eb 0f                	jmp    72ef8e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0xbe>
  72ef7f:	90                   	nop
  72ef80:	4c 89 e7             	mov    %r12,%rdi
  72ef83:	4c 89 f6             	mov    %r14,%rsi
  72ef86:	e8 95 f7 ff ff       	call   72e720 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  72ef8b:	49 89 c6             	mov    %rax,%r14
  72ef8e:	ff 4c 24 14          	decl   0x14(%rsp)
  72ef92:	4d 89 f2             	mov    %r14,%r10
  72ef95:	4d 29 e2             	sub    %r12,%r10
  72ef98:	49 c1 ea 03          	shr    $0x3,%r10
  72ef9c:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
  72efa3:	aa aa aa 
  72efa6:	4c 0f af d0          	imul   %rax,%r10
  72efaa:	49 8b 46 10          	mov    0x10(%r14),%rax
  72efae:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  72efb3:	41 0f 10 06          	movups (%r14),%xmm0
  72efb7:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  72efbc:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  72efc2:	74 11                	je     72efd5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x105>
  72efc4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72efc9:	48 8b 00             	mov    (%rax),%rax
  72efcc:	49 3b 06             	cmp    (%r14),%rax
  72efcf:	0f 83 db 01 00 00    	jae    72f1b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x2e0>
  72efd5:	48 39 dd             	cmp    %rbx,%rbp
  72efd8:	0f 82 b9 03 00 00    	jb     72f397 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c7>
  72efde:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
  72efe2:	49 8d 2c c7          	lea    (%r15,%rax,8),%rbp
  72efe6:	45 31 ed             	xor    %r13d,%r13d
  72efe9:	4c 89 e0             	mov    %r12,%rax
  72efec:	48 89 e9             	mov    %rbp,%rcx
  72efef:	4c 89 d2             	mov    %r10,%rdx
  72eff2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72eff9:	1f 84 00 00 00 00 00 
  72f000:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
  72f004:	49 8d 34 f4          	lea    (%r12,%rsi,8),%rsi
  72f008:	48 39 f0             	cmp    %rsi,%rax
  72f00b:	73 37                	jae    72f044 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x174>
  72f00d:	0f 1f 00             	nopl   (%rax)
  72f010:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72f014:	48 8b 38             	mov    (%rax),%rdi
  72f017:	49 3b 3e             	cmp    (%r14),%rdi
  72f01a:	48 8b 78 10          	mov    0x10(%rax),%rdi
  72f01e:	49 89 c8             	mov    %rcx,%r8
  72f021:	4d 0f 42 c7          	cmovb  %r15,%r8
  72f025:	4f 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%r9
  72f02a:	4b 89 7c c8 10       	mov    %rdi,0x10(%r8,%r9,8)
  72f02f:	0f 10 00             	movups (%rax),%xmm0
  72f032:	43 0f 11 04 c8       	movups %xmm0,(%r8,%r9,8)
  72f037:	49 83 d5 00          	adc    $0x0,%r13
  72f03b:	48 83 c0 18          	add    $0x18,%rax
  72f03f:	48 39 f0             	cmp    %rsi,%rax
  72f042:	72 cc                	jb     72f010 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x140>
  72f044:	48 39 da             	cmp    %rbx,%rdx
  72f047:	74 37                	je     72f080 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x1b0>
  72f049:	4a 8d 14 6d 00 00 00 	lea    0x0(,%r13,2),%rdx
  72f050:	00 
  72f051:	4c 01 ea             	add    %r13,%rdx
  72f054:	48 8b 70 10          	mov    0x10(%rax),%rsi
  72f058:	48 89 74 d1 f8       	mov    %rsi,-0x8(%rcx,%rdx,8)
  72f05d:	0f 10 00             	movups (%rax),%xmm0
  72f060:	0f 11 44 d1 e8       	movups %xmm0,-0x18(%rcx,%rdx,8)
  72f065:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72f069:	48 83 c0 18          	add    $0x18,%rax
  72f06d:	48 89 da             	mov    %rbx,%rdx
  72f070:	eb 8e                	jmp    72f000 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x130>
  72f072:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f079:	1f 84 00 00 00 00 00 
  72f080:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
  72f085:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
  72f08c:	00 
  72f08d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
  72f091:	4c 89 e7             	mov    %r12,%rdi
  72f094:	4c 89 fe             	mov    %r15,%rsi
  72f097:	ff 15 53 8c 3b 00    	call   *0x3b8c53(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72f09d:	49 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r10
  72f0a4:	ff ff 1f 
  72f0a7:	48 89 de             	mov    %rbx,%rsi
  72f0aa:	4c 29 ee             	sub    %r13,%rsi
  72f0ad:	0f 84 9f 00 00 00    	je     72f152 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x282>
  72f0b3:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  72f0ba:	00 
  72f0bb:	4c 01 e8             	add    %r13,%rax
  72f0be:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
  72f0c2:	49 8d 4d 01          	lea    0x1(%r13),%rcx
  72f0c6:	48 39 cb             	cmp    %rcx,%rbx
  72f0c9:	75 05                	jne    72f0d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x200>
  72f0cb:	31 d2                	xor    %edx,%edx
  72f0cd:	eb 65                	jmp    72f134 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x264>
  72f0cf:	90                   	nop
  72f0d0:	48 89 f1             	mov    %rsi,%rcx
  72f0d3:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72f0d7:	49 8d 57 e8          	lea    -0x18(%r15),%rdx
  72f0db:	48 8d 3c 5b          	lea    (%rbx,%rbx,2),%rdi
  72f0df:	48 8d 3c fa          	lea    (%rdx,%rdi,8),%rdi
  72f0e3:	49 89 c0             	mov    %rax,%r8
  72f0e6:	31 d2                	xor    %edx,%edx
  72f0e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72f0ef:	00 
  72f0f0:	49 89 d1             	mov    %rdx,%r9
  72f0f3:	48 8b 57 10          	mov    0x10(%rdi),%rdx
  72f0f7:	49 89 50 10          	mov    %rdx,0x10(%r8)
  72f0fb:	0f 10 07             	movups (%rdi),%xmm0
  72f0fe:	41 0f 11 00          	movups %xmm0,(%r8)
  72f102:	49 8d 51 02          	lea    0x2(%r9),%rdx
  72f106:	4d 31 d1             	xor    %r10,%r9
  72f109:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
  72f10d:	42 0f 10 44 cd 00    	movups 0x0(%rbp,%r9,8),%xmm0
  72f113:	41 0f 11 40 18       	movups %xmm0,0x18(%r8)
  72f118:	4e 8b 4c cd 10       	mov    0x10(%rbp,%r9,8),%r9
  72f11d:	4d 89 48 28          	mov    %r9,0x28(%r8)
  72f121:	49 83 c0 30          	add    $0x30,%r8
  72f125:	48 83 c7 d0          	add    $0xffffffffffffffd0,%rdi
  72f129:	48 39 d1             	cmp    %rdx,%rcx
  72f12c:	75 c2                	jne    72f0f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x220>
  72f12e:	40 f6 c6 01          	test   $0x1,%sil
  72f132:	74 1e                	je     72f152 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x282>
  72f134:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  72f138:	48 f7 d2             	not    %rdx
  72f13b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  72f13f:	48 8b 7c d5 10       	mov    0x10(%rbp,%rdx,8),%rdi
  72f144:	48 89 7c c8 10       	mov    %rdi,0x10(%rax,%rcx,8)
  72f149:	0f 10 44 d5 00       	movups 0x0(%rbp,%rdx,8),%xmm0
  72f14e:	0f 11 04 c8          	movups %xmm0,(%rax,%rcx,8)
  72f152:	4d 85 ed             	test   %r13,%r13
  72f155:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72f15a:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
  72f15f:	74 4f                	je     72f1b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x2e0>
  72f161:	4c 39 eb             	cmp    %r13,%rbx
  72f164:	0f 82 2f 02 00 00    	jb     72f399 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c9>
  72f16a:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  72f171:	00 
  72f172:	4c 01 e8             	add    %r13,%rax
  72f175:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
  72f179:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  72f180:	00 
  72f181:	48 89 04 24          	mov    %rax,(%rsp)
  72f185:	4c 89 fa             	mov    %r15,%rdx
  72f188:	48 89 e9             	mov    %rbp,%rcx
  72f18b:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72f190:	45 89 f0             	mov    %r14d,%r8d
  72f193:	4c 8d 4c 24 30       	lea    0x30(%rsp),%r9
  72f198:	e8 33 fd ff ff       	call   72eed0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72f19d:	4c 89 eb             	mov    %r13,%rbx
  72f1a0:	49 83 fd 21          	cmp    $0x21,%r13
  72f1a4:	0f 83 76 fd ff ff    	jae    72ef20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x50>
  72f1aa:	e9 46 fd ff ff       	jmp    72eef5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72f1af:	90                   	nop
  72f1b0:	48 39 dd             	cmp    %rbx,%rbp
  72f1b3:	0f 82 de 01 00 00    	jb     72f397 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c7>
  72f1b9:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
  72f1bd:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  72f1c2:	4d 8d 0c c7          	lea    (%r15,%rax,8),%r9
  72f1c6:	31 ed                	xor    %ebp,%ebp
  72f1c8:	4c 89 e0             	mov    %r12,%rax
  72f1cb:	4c 89 c9             	mov    %r9,%rcx
  72f1ce:	66 90                	xchg   %ax,%ax
  72f1d0:	4b 8d 14 52          	lea    (%r10,%r10,2),%rdx
  72f1d4:	49 8d 14 d4          	lea    (%r12,%rdx,8),%rdx
  72f1d8:	48 39 d0             	cmp    %rdx,%rax
  72f1db:	73 36                	jae    72f213 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x343>
  72f1dd:	0f 1f 00             	nopl   (%rax)
  72f1e0:	49 8b 36             	mov    (%r14),%rsi
  72f1e3:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72f1e7:	48 3b 30             	cmp    (%rax),%rsi
  72f1ea:	48 89 ce             	mov    %rcx,%rsi
  72f1ed:	49 0f 43 f7          	cmovae %r15,%rsi
  72f1f1:	48 8d 7c 6d 00       	lea    0x0(%rbp,%rbp,2),%rdi
  72f1f6:	4c 8b 40 10          	mov    0x10(%rax),%r8
  72f1fa:	4c 89 44 fe 10       	mov    %r8,0x10(%rsi,%rdi,8)
  72f1ff:	0f 10 00             	movups (%rax),%xmm0
  72f202:	0f 11 04 fe          	movups %xmm0,(%rsi,%rdi,8)
  72f206:	48 83 dd ff          	sbb    $0xffffffffffffffff,%rbp
  72f20a:	48 83 c0 18          	add    $0x18,%rax
  72f20e:	48 39 d0             	cmp    %rdx,%rax
  72f211:	72 cd                	jb     72f1e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x310>
  72f213:	49 39 da             	cmp    %rbx,%r10
  72f216:	74 38                	je     72f250 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x380>
  72f218:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72f21c:	48 8d 14 6d 00 00 00 	lea    0x0(,%rbp,2),%rdx
  72f223:	00 
  72f224:	48 01 ea             	add    %rbp,%rdx
  72f227:	48 8b 70 10          	mov    0x10(%rax),%rsi
  72f22b:	49 89 74 d7 10       	mov    %rsi,0x10(%r15,%rdx,8)
  72f230:	0f 10 00             	movups (%rax),%xmm0
  72f233:	41 0f 11 04 d7       	movups %xmm0,(%r15,%rdx,8)
  72f238:	48 ff c5             	inc    %rbp
  72f23b:	48 83 c0 18          	add    $0x18,%rax
  72f23f:	49 89 da             	mov    %rbx,%r10
  72f242:	eb 8c                	jmp    72f1d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x300>
  72f244:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f24b:	00 00 00 00 00 
  72f250:	4d 89 ce             	mov    %r9,%r14
  72f253:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
  72f25a:	00 
  72f25b:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
  72f25f:	4c 89 e7             	mov    %r12,%rdi
  72f262:	4c 89 fe             	mov    %r15,%rsi
  72f265:	ff 15 85 8a 3b 00    	call   *0x3b8a85(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72f26b:	49 89 dd             	mov    %rbx,%r13
  72f26e:	49 29 ed             	sub    %rbp,%r13
  72f271:	0f 84 0a 01 00 00    	je     72f381 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4b1>
  72f277:	48 8d 04 6d 00 00 00 	lea    0x0(,%rbp,2),%rax
  72f27e:	00 
  72f27f:	48 01 e8             	add    %rbp,%rax
  72f282:	4d 8d 24 c4          	lea    (%r12,%rax,8),%r12
  72f286:	48 8d 45 01          	lea    0x1(%rbp),%rax
  72f28a:	48 39 c3             	cmp    %rax,%rbx
  72f28d:	4d 89 f1             	mov    %r14,%r9
  72f290:	75 09                	jne    72f29b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x3cb>
  72f292:	31 c9                	xor    %ecx,%ecx
  72f294:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72f299:	eb 76                	jmp    72f311 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x441>
  72f29b:	4c 89 e8             	mov    %r13,%rax
  72f29e:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
  72f2a2:	49 8d 4f e8          	lea    -0x18(%r15),%rcx
  72f2a6:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
  72f2aa:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
  72f2ae:	4c 89 e6             	mov    %r12,%rsi
  72f2b1:	31 c9                	xor    %ecx,%ecx
  72f2b3:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72f2b8:	49 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r8
  72f2bf:	ff ff 1f 
  72f2c2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f2c9:	1f 84 00 00 00 00 00 
  72f2d0:	48 89 cf             	mov    %rcx,%rdi
  72f2d3:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  72f2d7:	48 89 4e 10          	mov    %rcx,0x10(%rsi)
  72f2db:	0f 10 02             	movups (%rdx),%xmm0
  72f2de:	0f 11 06             	movups %xmm0,(%rsi)
  72f2e1:	48 8d 4f 02          	lea    0x2(%rdi),%rcx
  72f2e5:	4c 31 c7             	xor    %r8,%rdi
  72f2e8:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
  72f2ec:	41 0f 10 04 f9       	movups (%r9,%rdi,8),%xmm0
  72f2f1:	0f 11 46 18          	movups %xmm0,0x18(%rsi)
  72f2f5:	49 8b 7c f9 10       	mov    0x10(%r9,%rdi,8),%rdi
  72f2fa:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
  72f2fe:	48 83 c6 30          	add    $0x30,%rsi
  72f302:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
  72f306:	48 39 c8             	cmp    %rcx,%rax
  72f309:	75 c5                	jne    72f2d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x400>
  72f30b:	41 f6 c5 01          	test   $0x1,%r13b
  72f30f:	74 1f                	je     72f330 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x460>
  72f311:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  72f315:	48 f7 d1             	not    %rcx
  72f318:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  72f31c:	49 8b 54 c9 10       	mov    0x10(%r9,%rcx,8),%rdx
  72f321:	49 89 54 c4 10       	mov    %rdx,0x10(%r12,%rax,8)
  72f326:	41 0f 10 04 c9       	movups (%r9,%rcx,8),%xmm0
  72f32b:	41 0f 11 04 c4       	movups %xmm0,(%r12,%rax,8)
  72f330:	48 39 eb             	cmp    %rbp,%rbx
  72f333:	72 7d                	jb     72f3b2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4e2>
  72f335:	b8 00 00 00 00       	mov    $0x0,%eax
  72f33a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  72f33f:	49 83 fd 21          	cmp    $0x21,%r13
  72f343:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72f348:	0f 83 cd fb ff ff    	jae    72ef1b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4b>
  72f34e:	e9 a2 fb ff ff       	jmp    72eef5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72f353:	4c 89 e7             	mov    %r12,%rdi
  72f356:	48 89 de             	mov    %rbx,%rsi
  72f359:	4c 89 fa             	mov    %r15,%rdx
  72f35c:	48 89 e9             	mov    %rbp,%rcx
  72f35f:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72f365:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
  72f36c:	00 
  72f36d:	e8 1e d6 ff ff       	call   72c990 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>
  72f372:	48 83 c4 48          	add    $0x48,%rsp
  72f376:	5b                   	pop    %rbx
  72f377:	41 5c                	pop    %r12
  72f379:	41 5d                	pop    %r13
  72f37b:	41 5e                	pop    %r14
  72f37d:	41 5f                	pop    %r15
  72f37f:	5d                   	pop    %rbp
  72f380:	c3                   	ret
  72f381:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72f386:	4d 8d 24 c4          	lea    (%r12,%rax,8),%r12
  72f38a:	45 31 ed             	xor    %r13d,%r13d
  72f38d:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72f392:	e9 5e fb ff ff       	jmp    72eef5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72f397:	0f 0b                	ud2
  72f399:	48 8d 3d 84 a2 93 ff 	lea    -0x6c5d7c(%rip),%rdi        # 69624 <anon.82a788e7fdd98d311675b83eb91f04ac.0.llvm.15086054616281437909+0x27>
  72f3a0:	48 8d 15 41 bf 38 00 	lea    0x38bf41(%rip),%rdx        # abb2e8 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x38>
  72f3a7:	be 13 00 00 00       	mov    $0x13,%esi
  72f3ac:	ff 15 6e 89 3b 00    	call   *0x3b896e(%rip)        # ae7d20 <_DYNAMIC+0x2a0>
  72f3b2:	48 8d 0d 47 bf 38 00 	lea    0x38bf47(%rip),%rcx        # abb300 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x50>
  72f3b9:	48 89 ef             	mov    %rbp,%rdi
  72f3bc:	48 89 de             	mov    %rbx,%rsi
  72f3bf:	48 89 da             	mov    %rbx,%rdx
  72f3c2:	ff 15 48 89 3b 00    	call   *0x3b8948(%rip)        # ae7d10 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
