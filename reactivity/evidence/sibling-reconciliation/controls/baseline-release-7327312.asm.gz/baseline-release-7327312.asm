
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006fce50 <_RNCNvMst_NtCshBhuxcId5D0_4gpui7runtimeINtB7_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersn_0BQ_>:
  6fce50:	48 83 ec 38          	sub    $0x38,%rsp
  6fce54:	48 8b 0f             	mov    (%rdi),%rcx
  6fce57:	48 8b 57 08          	mov    0x8(%rdi),%rdx
  6fce5b:	48 8b 47 10          	mov    0x10(%rdi),%rax
  6fce5f:	8b 30                	mov    (%rax),%esi
  6fce61:	48 8b 47 18          	mov    0x18(%rdi),%rax
  6fce65:	0f b6 38             	movzbl (%rax),%edi
  6fce68:	31 c0                	xor    %eax,%eax
  6fce6a:	40 80 ff 02          	cmp    $0x2,%dil
  6fce6e:	0f 42 f8             	cmovb  %eax,%edi
  6fce71:	0f 10 02             	movups (%rdx),%xmm0
  6fce74:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6fce78:	89 74 24 10          	mov    %esi,0x10(%rsp)
  6fce7c:	40 88 7c 24 14       	mov    %dil,0x14(%rsp)
  6fce81:	48 8b 31             	mov    (%rcx),%rsi
  6fce84:	48 85 f6             	test   %rsi,%rsi
  6fce87:	74 33                	je     6fcebc <_RNCNvMst_NtCshBhuxcId5D0_4gpui7runtimeINtB7_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersn_0BQ_+0x6c>
  6fce89:	48 8b 51 08          	mov    0x8(%rcx),%rdx
  6fce8d:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  6fce92:	48 89 e1             	mov    %rsp,%rcx
  6fce95:	e8 16 80 ff ff       	call   6f4eb0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6searchINtNtB7_4node7NodeRefNtNtBX_6marker3MutTINtNtCs4NRVxsYgnAr_4core6option6OptionyEmNtNtCshBhuxcId5D0_4gpui7element8NodeKindEjNtB1h_14LeafOrInternalE11search_treeB1x_ECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6fce9a:	80 7c 24 18 00       	cmpb   $0x0,0x18(%rsp)
  6fce9f:	74 07                	je     6fcea8 <_RNCNvMst_NtCshBhuxcId5D0_4gpui7runtimeINtB7_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersn_0BQ_+0x58>
  6fcea1:	31 c0                	xor    %eax,%eax
  6fcea3:	48 83 c4 38          	add    $0x38,%rsp
  6fcea7:	c3                   	ret
  6fcea8:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6fcead:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6fceb2:	48 8d 04 c8          	lea    (%rax,%rcx,8),%rax
  6fceb6:	48 05 10 01 00 00    	add    $0x110,%rax
  6fcebc:	48 83 c4 38          	add    $0x38,%rsp
  6fcec0:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
