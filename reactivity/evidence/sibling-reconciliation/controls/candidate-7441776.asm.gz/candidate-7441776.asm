
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000718d70 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>:
  718d70:	55                   	push   %rbp
  718d71:	41 57                	push   %r15
  718d73:	41 56                	push   %r14
  718d75:	41 55                	push   %r13
  718d77:	41 54                	push   %r12
  718d79:	53                   	push   %rbx
  718d7a:	48 83 ec 78          	sub    $0x78,%rsp
  718d7e:	48 89 fb             	mov    %rdi,%rbx
  718d81:	4c 8b 2e             	mov    (%rsi),%r13
  718d84:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718d88:	4c 8b 7e 20          	mov    0x20(%rsi),%r15
  718d8c:	4c 8b 66 28          	mov    0x28(%rsi),%r12
  718d90:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718d97:	00 
  718d98:	48 85 c0             	test   %rax,%rax
  718d9b:	0f 84 2a 01 00 00    	je     718ecb <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15b>
  718da1:	49 89 f6             	mov    %rsi,%r14
  718da4:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  718da8:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  718dad:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718db4:	49 39 cc             	cmp    %rcx,%r12
  718db7:	72 31                	jb     718dea <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7a>
  718db9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  718dc0:	48 8b a8 60 01 00 00 	mov    0x160(%rax),%rbp
  718dc7:	48 85 ed             	test   %rbp,%rbp
  718dca:	0f 84 fb 00 00 00    	je     718ecb <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15b>
  718dd0:	49 ff c7             	inc    %r15
  718dd3:	44 0f b7 a0 c0 01 00 	movzwl 0x1c0(%rax),%r12d
  718dda:	00 
  718ddb:	48 89 e8             	mov    %rbp,%rax
  718dde:	66 44 3b a5 c2 01 00 	cmp    0x1c2(%rbp),%r12w
  718de5:	00 
  718de6:	73 d8                	jae    718dc0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x50>
  718de8:	eb 03                	jmp    718ded <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7d>
  718dea:	48 89 c5             	mov    %rax,%rbp
  718ded:	4a 8b b4 e5 68 01 00 	mov    0x168(%rbp,%r12,8),%rsi
  718df4:	00 
  718df5:	49 8b 45 00          	mov    0x0(%r13),%rax
  718df9:	48 8b 38             	mov    (%rax),%rdi
  718dfc:	ff 15 76 f3 3c 00    	call   *0x3cf376(%rip)        # ae8178 <_DYNAMIC+0x6f8>
  718e02:	84 c0                	test   %al,%al
  718e04:	0f 84 d8 00 00 00    	je     718ee2 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x172>
  718e0a:	4d 85 ff             	test   %r15,%r15
  718e0d:	0f 84 83 00 00 00    	je     718e96 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x126>
  718e13:	4a 8d 04 e5 d0 01 00 	lea    0x1d0(,%r12,8),%rax
  718e1a:	00 
  718e1b:	48 01 e8             	add    %rbp,%rax
  718e1e:	4c 89 f9             	mov    %r15,%rcx
  718e21:	48 83 e1 07          	and    $0x7,%rcx
  718e25:	0f 84 95 00 00 00    	je     718ec0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x150>
  718e2b:	31 d2                	xor    %edx,%edx
  718e2d:	0f 1f 00             	nopl   (%rax)
  718e30:	48 8b 28             	mov    (%rax),%rbp
  718e33:	48 8d 85 c8 01 00 00 	lea    0x1c8(%rbp),%rax
  718e3a:	48 ff c2             	inc    %rdx
  718e3d:	48 39 d1             	cmp    %rdx,%rcx
  718e40:	75 ee                	jne    718e30 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xc0>
  718e42:	4c 89 f9             	mov    %r15,%rcx
  718e45:	48 29 d1             	sub    %rdx,%rcx
  718e48:	49 83 ff 08          	cmp    $0x8,%r15
  718e4c:	72 43                	jb     718e91 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x121>
  718e4e:	66 90                	xchg   %ax,%ax
  718e50:	48 8b 00             	mov    (%rax),%rax
  718e53:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718e5a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718e61:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718e68:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718e6f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718e76:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718e7d:	48 8b a8 c8 01 00 00 	mov    0x1c8(%rax),%rbp
  718e84:	48 8d 85 c8 01 00 00 	lea    0x1c8(%rbp),%rax
  718e8b:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  718e8f:	75 bf                	jne    718e50 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xe0>
  718e91:	45 31 e4             	xor    %r12d,%r12d
  718e94:	eb 03                	jmp    718e99 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x129>
  718e96:	49 ff c4             	inc    %r12
  718e99:	4d 89 66 28          	mov    %r12,0x28(%r14)
  718e9d:	0f 57 c0             	xorps  %xmm0,%xmm0
  718ea0:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  718ea5:	45 31 ff             	xor    %r15d,%r15d
  718ea8:	48 89 e8             	mov    %rbp,%rax
  718eab:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718eb2:	49 39 cc             	cmp    %rcx,%r12
  718eb5:	0f 83 05 ff ff ff    	jae    718dc0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x50>
  718ebb:	e9 2a ff ff ff       	jmp    718dea <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7a>
  718ec0:	4c 89 f9             	mov    %r15,%rcx
  718ec3:	49 83 ff 08          	cmp    $0x8,%r15
  718ec7:	73 87                	jae    718e50 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xe0>
  718ec9:	eb c6                	jmp    718e91 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x121>
  718ecb:	31 c0                	xor    %eax,%eax
  718ecd:	48 89 03             	mov    %rax,(%rbx)
  718ed0:	48 89 d8             	mov    %rbx,%rax
  718ed3:	48 83 c4 78          	add    $0x78,%rsp
  718ed7:	5b                   	pop    %rbx
  718ed8:	41 5c                	pop    %r12
  718eda:	41 5d                	pop    %r13
  718edc:	41 5e                	pop    %r14
  718ede:	41 5f                	pop    %r15
  718ee0:	5d                   	pop    %rbp
  718ee1:	c3                   	ret
  718ee2:	49 8b 46 08          	mov    0x8(%r14),%rax
  718ee6:	48 ff 08             	decq   (%rax)
  718ee9:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  718eee:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
  718ef3:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  718ef8:	49 83 c6 10          	add    $0x10,%r14
  718efc:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  718f01:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  718f06:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  718f0b:	4c 89 f2             	mov    %r14,%rdx
  718f0e:	e8 bd 2a fd ff       	call   6eb9d0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_>
  718f13:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  718f18:	48 89 43 28          	mov    %rax,0x28(%rbx)
  718f1c:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  718f21:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  718f26:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  718f2a:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  718f2e:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  718f33:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  718f38:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  718f3d:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  718f42:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  718f47:	48 89 41 10          	mov    %rax,0x10(%rcx)
  718f4b:	0f 11 01             	movups %xmm0,(%rcx)
  718f4e:	b8 01 00 00 00       	mov    $0x1,%eax
  718f53:	e9 75 ff ff ff       	jmp    718ecd <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15d>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
