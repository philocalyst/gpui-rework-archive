
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000725ec0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_>:
  725ec0:	48 83 fe 02          	cmp    $0x2,%rsi
  725ec4:	0f 82 e7 00 00 00    	jb     725fb1 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0xf1>
  725eca:	49 89 d0             	mov    %rdx,%r8
  725ecd:	48 8b 07             	mov    (%rdi),%rax
  725ed0:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  725ed4:	ba 02 00 00 00       	mov    $0x2,%edx
  725ed9:	48 39 c1             	cmp    %rax,%rcx
  725edc:	73 2b                	jae    725f09 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x49>
  725ede:	48 83 fe 02          	cmp    $0x2,%rsi
  725ee2:	74 2b                	je     725f0f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x4f>
  725ee4:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  725ee8:	49 89 ca             	mov    %rcx,%r10
  725eeb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  725ef0:	4d 89 d3             	mov    %r10,%r11
  725ef3:	4d 8b 11             	mov    (%r9),%r10
  725ef6:	4d 39 da             	cmp    %r11,%r10
  725ef9:	73 14                	jae    725f0f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x4f>
  725efb:	48 ff c2             	inc    %rdx
  725efe:	49 83 c1 18          	add    $0x18,%r9
  725f02:	48 39 d6             	cmp    %rdx,%rsi
  725f05:	75 e9                	jne    725ef0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x30>
  725f07:	eb 4e                	jmp    725f57 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x97>
  725f09:	48 83 fe 02          	cmp    $0x2,%rsi
  725f0d:	75 1f                	jne    725f2e <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x6e>
  725f0f:	48 39 f2             	cmp    %rsi,%rdx
  725f12:	74 43                	je     725f57 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x97>
  725f14:	48 89 f0             	mov    %rsi,%rax
  725f17:	48 83 c8 01          	or     $0x1,%rax
  725f1b:	48 0f bd c8          	bsr    %rax,%rcx
  725f1f:	83 f1 3f             	xor    $0x3f,%ecx
  725f22:	01 c9                	add    %ecx,%ecx
  725f24:	83 f1 7e             	xor    $0x7e,%ecx
  725f27:	31 d2                	xor    %edx,%edx
  725f29:	e9 72 b6 ff ff       	jmp    7215a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_>
  725f2e:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  725f32:	49 89 ca             	mov    %rcx,%r10
  725f35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  725f3c:	00 00 00 00 
  725f40:	4d 89 d3             	mov    %r10,%r11
  725f43:	4d 8b 11             	mov    (%r9),%r10
  725f46:	4d 39 da             	cmp    %r11,%r10
  725f49:	72 c4                	jb     725f0f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x4f>
  725f4b:	48 ff c2             	inc    %rdx
  725f4e:	49 83 c1 18          	add    $0x18,%r9
  725f52:	48 39 d6             	cmp    %rdx,%rsi
  725f55:	75 e9                	jne    725f40 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x80>
  725f57:	48 39 c1             	cmp    %rax,%rcx
  725f5a:	73 55                	jae    725fb1 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0xf1>
  725f5c:	48 8d 04 b5 00 00 00 	lea    0x0(,%rsi,4),%rax
  725f63:	00 
  725f64:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
  725f68:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  725f6c:	48 8d 0c 76          	lea    (%rsi,%rsi,2),%rcx
  725f70:	48 8d 0c cd e8 ff ff 	lea    -0x18(,%rcx,8),%rcx
  725f77:	ff 
  725f78:	31 d2                	xor    %edx,%edx
  725f7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  725f80:	0f 10 04 17          	movups (%rdi,%rdx,1),%xmm0
  725f84:	0f 10 0c 0f          	movups (%rdi,%rcx,1),%xmm1
  725f88:	0f 11 0c 17          	movups %xmm1,(%rdi,%rdx,1)
  725f8c:	0f 11 04 0f          	movups %xmm0,(%rdi,%rcx,1)
  725f90:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
  725f95:	4c 8b 44 0f 10       	mov    0x10(%rdi,%rcx,1),%r8
  725f9a:	4c 89 44 17 10       	mov    %r8,0x10(%rdi,%rdx,1)
  725f9f:	48 89 74 0f 10       	mov    %rsi,0x10(%rdi,%rcx,1)
  725fa4:	48 83 c2 18          	add    $0x18,%rdx
  725fa8:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  725fac:	48 39 d0             	cmp    %rdx,%rax
  725faf:	75 cf                	jne    725f80 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0xc0>
  725fb1:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
