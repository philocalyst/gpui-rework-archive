
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072e070 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_>:
  72e070:	55                   	push   %rbp
  72e071:	41 57                	push   %r15
  72e073:	41 56                	push   %r14
  72e075:	41 55                	push   %r13
  72e077:	41 54                	push   %r12
  72e079:	53                   	push   %rbx
  72e07a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  72e081:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  72e088:	00 
  72e089:	50                   	push   %rax
  72e08a:	49 89 d6             	mov    %rdx,%r14
  72e08d:	48 89 f1             	mov    %rsi,%rcx
  72e090:	48 d1 e9             	shr    $1,%rcx
  72e093:	48 89 f0             	mov    %rsi,%rax
  72e096:	48 29 c8             	sub    %rcx,%rax
  72e099:	48 81 fe 20 a1 07 00 	cmp    $0x7a120,%rsi
  72e0a0:	bb 20 a1 07 00       	mov    $0x7a120,%ebx
  72e0a5:	48 0f 42 de          	cmovb  %rsi,%rbx
  72e0a9:	48 39 c3             	cmp    %rax,%rbx
  72e0ac:	48 0f 46 d8          	cmovbe %rax,%rbx
  72e0b0:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  72e0b7:	73 0c                	jae    72e0c5 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x55>
  72e0b9:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
  72e0be:	b9 00 01 00 00       	mov    $0x100,%ecx
  72e0c3:	eb 62                	jmp    72e127 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0xb7>
  72e0c5:	49 89 dc             	mov    %rbx,%r12
  72e0c8:	49 c1 e4 04          	shl    $0x4,%r12
  72e0cc:	48 c1 e8 3c          	shr    $0x3c,%rax
  72e0d0:	0f 95 c0             	setne  %al
  72e0d3:	48 b9 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rcx
  72e0da:	ff ff 7f 
  72e0dd:	49 39 cc             	cmp    %rcx,%r12
  72e0e0:	0f 97 c1             	seta   %cl
  72e0e3:	08 c1                	or     %al,%cl
  72e0e5:	74 0f                	je     72e0f6 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x86>
  72e0e7:	45 31 ed             	xor    %r13d,%r13d
  72e0ea:	4c 89 ef             	mov    %r13,%rdi
  72e0ed:	4c 89 e6             	mov    %r12,%rsi
  72e0f0:	ff 15 b2 9c 3b 00    	call   *0x3b9cb2(%rip)        # ae7da8 <_DYNAMIC+0x328>
  72e0f6:	49 89 f7             	mov    %rsi,%r15
  72e0f9:	48 89 fd             	mov    %rdi,%rbp
  72e0fc:	ff 15 de 9b 3b 00    	call   *0x3b9bde(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  72e102:	41 bd 08 00 00 00    	mov    $0x8,%r13d
  72e108:	be 08 00 00 00       	mov    $0x8,%esi
  72e10d:	4c 89 e7             	mov    %r12,%rdi
  72e110:	ff 15 aa 9b 3b 00    	call   *0x3b9baa(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  72e116:	48 89 ef             	mov    %rbp,%rdi
  72e119:	4c 89 fe             	mov    %r15,%rsi
  72e11c:	49 89 c7             	mov    %rax,%r15
  72e11f:	48 89 d9             	mov    %rbx,%rcx
  72e122:	48 85 c0             	test   %rax,%rax
  72e125:	74 c3                	je     72e0ea <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x7a>
  72e127:	45 31 c0             	xor    %r8d,%r8d
  72e12a:	48 83 fe 41          	cmp    $0x41,%rsi
  72e12e:	41 0f 92 c0          	setb   %r8b
  72e132:	4c 89 fa             	mov    %r15,%rdx
  72e135:	4d 89 f1             	mov    %r14,%r9
  72e138:	e8 93 ee ff ff       	call   72cfd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>
  72e13d:	48 81 fb 00 01 00 00 	cmp    $0x100,%rbx
  72e144:	76 15                	jbe    72e15b <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0xeb>
  72e146:	48 c1 e3 04          	shl    $0x4,%rbx
  72e14a:	ba 08 00 00 00       	mov    $0x8,%edx
  72e14f:	4c 89 ff             	mov    %r15,%rdi
  72e152:	48 89 de             	mov    %rbx,%rsi
  72e155:	ff 15 6d 9b 3b 00    	call   *0x3b9b6d(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  72e15b:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  72e162:	5b                   	pop    %rbx
  72e163:	41 5c                	pop    %r12
  72e165:	41 5d                	pop    %r13
  72e167:	41 5e                	pop    %r14
  72e169:	41 5f                	pop    %r15
  72e16b:	5d                   	pop    %rbp
  72e16c:	c3                   	ret
  72e16d:	49 89 c6             	mov    %rax,%r14
  72e170:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  72e177:	73 08                	jae    72e181 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x111>
  72e179:	4c 89 f7             	mov    %r14,%rdi
  72e17c:	e8 cf a2 38 00       	call   ab8450 <_Unwind_Resume@plt>
  72e181:	48 c1 e3 04          	shl    $0x4,%rbx
  72e185:	ba 08 00 00 00       	mov    $0x8,%edx
  72e18a:	4c 89 ff             	mov    %r15,%rdi
  72e18d:	48 89 de             	mov    %rbx,%rsi
  72e190:	ff 15 32 9b 3b 00    	call   *0x3b9b32(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  72e196:	4c 89 f7             	mov    %r14,%rdi
  72e199:	e8 b2 a2 38 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
