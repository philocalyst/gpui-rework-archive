
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000721280 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>:
  721280:	55                   	push   %rbp
  721281:	41 57                	push   %r15
  721283:	41 56                	push   %r14
  721285:	41 55                	push   %r13
  721287:	41 54                	push   %r12
  721289:	53                   	push   %rbx
  72128a:	50                   	push   %rax
  72128b:	4c 89 04 24          	mov    %r8,(%rsp)
  72128f:	49 89 f6             	mov    %rsi,%r14
  721292:	49 89 ff             	mov    %rdi,%r15
  721295:	48 83 fe 21          	cmp    $0x21,%rsi
  721299:	73 1d                	jae    7212b8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x38>
  72129b:	4c 89 ff             	mov    %r15,%rdi
  72129e:	4c 89 f6             	mov    %r14,%rsi
  7212a1:	48 8b 14 24          	mov    (%rsp),%rdx
  7212a5:	48 83 c4 08          	add    $0x8,%rsp
  7212a9:	5b                   	pop    %rbx
  7212aa:	41 5c                	pop    %r12
  7212ac:	41 5d                	pop    %r13
  7212ae:	41 5e                	pop    %r14
  7212b0:	41 5f                	pop    %r15
  7212b2:	5d                   	pop    %rbp
  7212b3:	e9 38 f6 fe ff       	jmp    7108f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_>
  7212b8:	89 cd                	mov    %ecx,%ebp
  7212ba:	49 89 d4             	mov    %rdx,%r12
  7212bd:	eb 3f                	jmp    7212fe <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x7e>
  7212bf:	90                   	nop
  7212c0:	39 d6                	cmp    %edx,%esi
  7212c2:	8b 34 81             	mov    (%rcx,%rax,4),%esi
  7212c5:	41 89 30             	mov    %esi,(%r8)
  7212c8:	89 14 81             	mov    %edx,(%rcx,%rax,4)
  7212cb:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  7212cf:	4c 39 f0             	cmp    %r14,%rax
  7212d2:	0f 83 c2 02 00 00    	jae    72159a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x31a>
  7212d8:	41 8b 0f             	mov    (%r15),%ecx
  7212db:	41 8b 14 87          	mov    (%r15,%rax,4),%edx
  7212df:	41 89 17             	mov    %edx,(%r15)
  7212e2:	41 89 0c 87          	mov    %ecx,(%r15,%rax,4)
  7212e6:	48 8d 48 01          	lea    0x1(%rax),%rcx
  7212ea:	49 29 ce             	sub    %rcx,%r14
  7212ed:	4d 8d 3c 87          	lea    (%r15,%rax,4),%r15
  7212f1:	49 83 c7 04          	add    $0x4,%r15
  7212f5:	45 31 e4             	xor    %r12d,%r12d
  7212f8:	49 83 fe 21          	cmp    $0x21,%r14
  7212fc:	72 9d                	jb     72129b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1b>
  7212fe:	85 ed                	test   %ebp,%ebp
  721300:	0f 84 77 02 00 00    	je     72157d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2fd>
  721306:	4c 89 f1             	mov    %r14,%rcx
  721309:	48 c1 e9 03          	shr    $0x3,%rcx
  72130d:	48 89 c8             	mov    %rcx,%rax
  721310:	48 c1 e0 04          	shl    $0x4,%rax
  721314:	4c 01 f8             	add    %r15,%rax
  721317:	48 8d 14 c9          	lea    (%rcx,%rcx,8),%rdx
  72131b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  72131f:	4c 01 fa             	add    %r15,%rdx
  721322:	48 01 ca             	add    %rcx,%rdx
  721325:	49 83 fe 40          	cmp    $0x40,%r14
  721329:	0f 83 d1 00 00 00    	jae    721400 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x180>
  72132f:	41 8b 0f             	mov    (%r15),%ecx
  721332:	8b 30                	mov    (%rax),%esi
  721334:	39 f1                	cmp    %esi,%ecx
  721336:	40 0f 92 c7          	setb   %dil
  72133a:	44 8b 02             	mov    (%rdx),%r8d
  72133d:	44 39 c1             	cmp    %r8d,%ecx
  721340:	0f 92 c1             	setb   %cl
  721343:	40 30 f9             	xor    %dil,%cl
  721346:	44 39 c6             	cmp    %r8d,%esi
  721349:	40 0f 92 c6          	setb   %sil
  72134d:	40 30 fe             	xor    %dil,%sil
  721350:	48 0f 45 c2          	cmovne %rdx,%rax
  721354:	84 c9                	test   %cl,%cl
  721356:	49 0f 45 c7          	cmovne %r15,%rax
  72135a:	ff cd                	dec    %ebp
  72135c:	4c 29 f8             	sub    %r15,%rax
  72135f:	4d 85 e4             	test   %r12,%r12
  721362:	0f 84 b5 00 00 00    	je     72141d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x19d>
  721368:	41 8b 14 07          	mov    (%r15,%rax,1),%edx
  72136c:	41 8b 0f             	mov    (%r15),%ecx
  72136f:	41 39 14 24          	cmp    %edx,(%r12)
  721373:	0f 82 ab 00 00 00    	jb     721424 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1a4>
  721379:	41 89 17             	mov    %edx,(%r15)
  72137c:	41 89 0c 07          	mov    %ecx,(%r15,%rax,1)
  721380:	49 8d 4f 04          	lea    0x4(%r15),%rcx
  721384:	41 8b 37             	mov    (%r15),%esi
  721387:	41 8b 57 04          	mov    0x4(%r15),%edx
  72138b:	4f 8d 04 b7          	lea    (%r15,%r14,4),%r8
  72138f:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  721393:	49 8d 7f 08          	lea    0x8(%r15),%rdi
  721397:	4c 39 c7             	cmp    %r8,%rdi
  72139a:	0f 83 99 01 00 00    	jae    721539 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2b9>
  7213a0:	31 c0                	xor    %eax,%eax
  7213a2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7213a9:	1f 84 00 00 00 00 00 
  7213b0:	44 8b 0f             	mov    (%rdi),%r9d
  7213b3:	44 39 ce             	cmp    %r9d,%esi
  7213b6:	44 8b 14 81          	mov    (%rcx,%rax,4),%r10d
  7213ba:	44 89 57 fc          	mov    %r10d,-0x4(%rdi)
  7213be:	44 89 0c 81          	mov    %r9d,(%rcx,%rax,4)
  7213c2:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  7213c6:	44 8b 4f 04          	mov    0x4(%rdi),%r9d
  7213ca:	44 39 ce             	cmp    %r9d,%esi
  7213cd:	44 8b 14 81          	mov    (%rcx,%rax,4),%r10d
  7213d1:	44 89 17             	mov    %r10d,(%rdi)
  7213d4:	44 89 0c 81          	mov    %r9d,(%rcx,%rax,4)
  7213d8:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  7213dc:	48 83 c7 08          	add    $0x8,%rdi
  7213e0:	4c 39 c7             	cmp    %r8,%rdi
  7213e3:	72 cb                	jb     7213b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x130>
  7213e5:	4c 8d 47 fc          	lea    -0x4(%rdi),%r8
  7213e9:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  7213ed:	4c 39 cf             	cmp    %r9,%rdi
  7213f0:	0f 85 5a 01 00 00    	jne    721550 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2d0>
  7213f6:	e9 c5 fe ff ff       	jmp    7212c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  7213fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  721400:	4c 89 ff             	mov    %r15,%rdi
  721403:	48 89 c6             	mov    %rax,%rsi
  721406:	4c 8b 04 24          	mov    (%rsp),%r8
  72140a:	e8 c1 d0 00 00       	call   72e4d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  72140f:	ff cd                	dec    %ebp
  721411:	4c 29 f8             	sub    %r15,%rax
  721414:	4d 85 e4             	test   %r12,%r12
  721417:	0f 85 4b ff ff ff    	jne    721368 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0xe8>
  72141d:	41 8b 0f             	mov    (%r15),%ecx
  721420:	41 8b 14 07          	mov    (%r15,%rax,1),%edx
  721424:	41 89 17             	mov    %edx,(%r15)
  721427:	41 89 0c 07          	mov    %ecx,(%r15,%rax,1)
  72142b:	49 8d 47 04          	lea    0x4(%r15),%rax
  72142f:	41 8b 17             	mov    (%r15),%edx
  721432:	41 8b 4f 04          	mov    0x4(%r15),%ecx
  721436:	4f 8d 04 b7          	lea    (%r15,%r14,4),%r8
  72143a:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  72143e:	49 8d 7f 08          	lea    0x8(%r15),%rdi
  721442:	4c 39 c7             	cmp    %r8,%rdi
  721445:	73 59                	jae    7214a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x220>
  721447:	31 f6                	xor    %esi,%esi
  721449:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  721450:	44 8b 0f             	mov    (%rdi),%r9d
  721453:	45 31 d2             	xor    %r10d,%r10d
  721456:	41 39 d1             	cmp    %edx,%r9d
  721459:	41 0f 92 c2          	setb   %r10b
  72145d:	44 8b 1c b0          	mov    (%rax,%rsi,4),%r11d
  721461:	44 89 5f fc          	mov    %r11d,-0x4(%rdi)
  721465:	44 89 0c b0          	mov    %r9d,(%rax,%rsi,4)
  721469:	4e 8d 0c 16          	lea    (%rsi,%r10,1),%r9
  72146d:	44 8b 5f 04          	mov    0x4(%rdi),%r11d
  721471:	41 39 d3             	cmp    %edx,%r11d
  721474:	46 8b 2c 88          	mov    (%rax,%r9,4),%r13d
  721478:	44 89 2f             	mov    %r13d,(%rdi)
  72147b:	46 89 1c 88          	mov    %r11d,(%rax,%r9,4)
  72147f:	4c 11 d6             	adc    %r10,%rsi
  721482:	48 83 c7 08          	add    $0x8,%rdi
  721486:	4c 39 c7             	cmp    %r8,%rdi
  721489:	72 c5                	jb     721450 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1d0>
  72148b:	4c 8d 47 fc          	lea    -0x4(%rdi),%r8
  72148f:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  721493:	4c 39 cf             	cmp    %r9,%rdi
  721496:	75 18                	jne    7214b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x230>
  721498:	eb 3e                	jmp    7214d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x258>
  72149a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  7214a0:	49 89 c0             	mov    %rax,%r8
  7214a3:	31 f6                	xor    %esi,%esi
  7214a5:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  7214a9:	4c 39 cf             	cmp    %r9,%rdi
  7214ac:	74 2a                	je     7214d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x258>
  7214ae:	66 90                	xchg   %ax,%ax
  7214b0:	4d 89 c2             	mov    %r8,%r10
  7214b3:	49 89 f8             	mov    %rdi,%r8
  7214b6:	8b 3f                	mov    (%rdi),%edi
  7214b8:	39 d7                	cmp    %edx,%edi
  7214ba:	44 8b 1c b0          	mov    (%rax,%rsi,4),%r11d
  7214be:	45 89 1a             	mov    %r11d,(%r10)
  7214c1:	89 3c b0             	mov    %edi,(%rax,%rsi,4)
  7214c4:	48 83 d6 00          	adc    $0x0,%rsi
  7214c8:	49 8d 78 04          	lea    0x4(%r8),%rdi
  7214cc:	4c 39 cf             	cmp    %r9,%rdi
  7214cf:	75 df                	jne    7214b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x230>
  7214d1:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  7214d5:	49 89 f8             	mov    %rdi,%r8
  7214d8:	39 d1                	cmp    %edx,%ecx
  7214da:	8b 14 b0             	mov    (%rax,%rsi,4),%edx
  7214dd:	41 89 10             	mov    %edx,(%r8)
  7214e0:	89 0c b0             	mov    %ecx,(%rax,%rsi,4)
  7214e3:	48 83 d6 00          	adc    $0x0,%rsi
  7214e7:	4c 39 f6             	cmp    %r14,%rsi
  7214ea:	0f 83 aa 00 00 00    	jae    72159a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x31a>
  7214f0:	4d 8d 2c b7          	lea    (%r15,%rsi,4),%r13
  7214f4:	41 8b 07             	mov    (%r15),%eax
  7214f7:	41 8b 0c b7          	mov    (%r15,%rsi,4),%ecx
  7214fb:	41 89 0f             	mov    %ecx,(%r15)
  7214fe:	41 89 04 b7          	mov    %eax,(%r15,%rsi,4)
  721502:	49 8d 1c b7          	lea    (%r15,%rsi,4),%rbx
  721506:	48 83 c3 04          	add    $0x4,%rbx
  72150a:	48 89 f0             	mov    %rsi,%rax
  72150d:	48 f7 d0             	not    %rax
  721510:	49 01 c6             	add    %rax,%r14
  721513:	4c 89 ff             	mov    %r15,%rdi
  721516:	4c 89 e2             	mov    %r12,%rdx
  721519:	89 e9                	mov    %ebp,%ecx
  72151b:	4c 8b 04 24          	mov    (%rsp),%r8
  72151f:	e8 5c fd ff ff       	call   721280 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>
  721524:	4d 89 ec             	mov    %r13,%r12
  721527:	49 89 df             	mov    %rbx,%r15
  72152a:	49 83 fe 21          	cmp    $0x21,%r14
  72152e:	0f 83 ca fd ff ff    	jae    7212fe <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x7e>
  721534:	e9 62 fd ff ff       	jmp    72129b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1b>
  721539:	49 89 c8             	mov    %rcx,%r8
  72153c:	31 c0                	xor    %eax,%eax
  72153e:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  721542:	4c 39 cf             	cmp    %r9,%rdi
  721545:	0f 84 75 fd ff ff    	je     7212c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  72154b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  721550:	4d 89 c2             	mov    %r8,%r10
  721553:	49 89 f8             	mov    %rdi,%r8
  721556:	8b 3f                	mov    (%rdi),%edi
  721558:	39 fe                	cmp    %edi,%esi
  72155a:	44 8b 1c 81          	mov    (%rcx,%rax,4),%r11d
  72155e:	45 89 1a             	mov    %r11d,(%r10)
  721561:	89 3c 81             	mov    %edi,(%rcx,%rax,4)
  721564:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  721568:	49 8d 78 04          	lea    0x4(%r8),%rdi
  72156c:	4c 39 cf             	cmp    %r9,%rdi
  72156f:	75 df                	jne    721550 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2d0>
  721571:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  721575:	49 89 f8             	mov    %rdi,%r8
  721578:	e9 43 fd ff ff       	jmp    7212c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  72157d:	4c 89 ff             	mov    %r15,%rdi
  721580:	4c 89 f6             	mov    %r14,%rsi
  721583:	48 8b 14 24          	mov    (%rsp),%rdx
  721587:	48 83 c4 08          	add    $0x8,%rsp
  72158b:	5b                   	pop    %rbx
  72158c:	41 5c                	pop    %r12
  72158e:	41 5d                	pop    %r13
  721590:	41 5e                	pop    %r14
  721592:	41 5f                	pop    %r15
  721594:	5d                   	pop    %rbp
  721595:	e9 16 c5 00 00       	jmp    72dab0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_>
  72159a:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
