
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000732e60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_>:
  732e60:	48 89 f0             	mov    %rsi,%rax
  732e63:	48 d1 e8             	shr    $1,%rax
  732e66:	48 01 f0             	add    %rsi,%rax
  732e69:	75 0a                	jne    732e75 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_+0x15>
  732e6b:	c3                   	ret
  732e6c:	0f 1f 40 00          	nopl   0x0(%rax)
  732e70:	48 85 c0             	test   %rax,%rax
  732e73:	74 f6                	je     732e6b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_+0xb>
  732e75:	48 ff c8             	dec    %rax
  732e78:	48 89 c2             	mov    %rax,%rdx
  732e7b:	48 29 f2             	sub    %rsi,%rdx
  732e7e:	73 3a                	jae    732eba <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_+0x5a>
  732e80:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  732e84:	48 8b 57 10          	mov    0x10(%rdi),%rdx
  732e88:	48 89 54 24 f8       	mov    %rdx,-0x8(%rsp)
  732e8d:	0f 10 07             	movups (%rdi),%xmm0
  732e90:	0f 29 44 24 e8       	movaps %xmm0,-0x18(%rsp)
  732e95:	48 8b 54 cf 10       	mov    0x10(%rdi,%rcx,8),%rdx
  732e9a:	0f 10 04 cf          	movups (%rdi,%rcx,8),%xmm0
  732e9e:	0f 11 07             	movups %xmm0,(%rdi)
  732ea1:	48 89 57 10          	mov    %rdx,0x10(%rdi)
  732ea5:	48 8b 54 24 f8       	mov    -0x8(%rsp),%rdx
  732eaa:	48 89 54 cf 10       	mov    %rdx,0x10(%rdi,%rcx,8)
  732eaf:	0f 28 44 24 e8       	movaps -0x18(%rsp),%xmm0
  732eb4:	0f 11 04 cf          	movups %xmm0,(%rdi,%rcx,8)
  732eb8:	31 d2                	xor    %edx,%edx
  732eba:	48 39 c6             	cmp    %rax,%rsi
  732ebd:	48 89 c1             	mov    %rax,%rcx
  732ec0:	48 0f 42 ce          	cmovb  %rsi,%rcx
  732ec4:	4c 8d 04 55 01 00 00 	lea    0x1(,%rdx,2),%r8
  732ecb:	00 
  732ecc:	49 39 c8             	cmp    %rcx,%r8
  732ecf:	73 9f                	jae    732e70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_+0x10>
  732ed1:	4c 8d 14 12          	lea    (%rdx,%rdx,1),%r10
  732ed5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  732edc:	00 00 00 00 
  732ee0:	49 83 c2 02          	add    $0x2,%r10
  732ee4:	49 39 ca             	cmp    %rcx,%r10
  732ee7:	73 14                	jae    732efd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_+0x9d>
  732ee9:	4f 8d 0c 40          	lea    (%r8,%r8,2),%r9
  732eed:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  732ef1:	4e 8b 0c cf          	mov    (%rdi,%r9,8),%r9
  732ef5:	4e 3b 0c d7          	cmp    (%rdi,%r10,8),%r9
  732ef9:	49 83 d0 00          	adc    $0x0,%r8
  732efd:	4d 89 c1             	mov    %r8,%r9
  732f00:	4c 8d 04 52          	lea    (%rdx,%rdx,2),%r8
  732f04:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  732f08:	4a 8b 14 c7          	mov    (%rdi,%r8,8),%rdx
  732f0c:	4e 8b 1c d7          	mov    (%rdi,%r10,8),%r11
  732f10:	4c 39 da             	cmp    %r11,%rdx
  732f13:	0f 83 57 ff ff ff    	jae    732e70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_+0x10>
  732f19:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
  732f1d:	4e 8d 14 d7          	lea    (%rdi,%r10,8),%r10
  732f21:	4d 89 18             	mov    %r11,(%r8)
  732f24:	49 89 12             	mov    %rdx,(%r10)
  732f27:	41 0f 10 40 08       	movups 0x8(%r8),%xmm0
  732f2c:	41 0f 10 4a 08       	movups 0x8(%r10),%xmm1
  732f31:	41 0f 11 48 08       	movups %xmm1,0x8(%r8)
  732f36:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  732f3b:	4f 8d 14 09          	lea    (%r9,%r9,1),%r10
  732f3f:	4e 8d 04 4d 01 00 00 	lea    0x1(,%r9,2),%r8
  732f46:	00 
  732f47:	4c 89 ca             	mov    %r9,%rdx
  732f4a:	49 39 c8             	cmp    %rcx,%r8
  732f4d:	72 91                	jb     732ee0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_+0x80>
  732f4f:	e9 1c ff ff ff       	jmp    732e70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2Y_+0x10>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
