
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000729c60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>:
  729c60:	55                   	push   %rbp
  729c61:	41 57                	push   %r15
  729c63:	41 56                	push   %r14
  729c65:	41 55                	push   %r13
  729c67:	41 54                	push   %r12
  729c69:	53                   	push   %rbx
  729c6a:	50                   	push   %rax
  729c6b:	49 89 d7             	mov    %rdx,%r15
  729c6e:	48 89 f3             	mov    %rsi,%rbx
  729c71:	49 89 fe             	mov    %rdi,%r14
  729c74:	48 b8 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rax
  729c7b:	ff ff 1f 
  729c7e:	48 85 c1             	test   %rax,%rcx
  729c81:	74 68                	je     729ceb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_+0x8b>
  729c83:	48 c1 e9 03          	shr    $0x3,%rcx
  729c87:	49 89 cc             	mov    %rcx,%r12
  729c8a:	49 c1 e4 04          	shl    $0x4,%r12
  729c8e:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
  729c92:	48 8d 04 c9          	lea    (%rcx,%rcx,8),%rax
  729c96:	4c 8d 2c 40          	lea    (%rax,%rax,2),%r13
  729c9a:	49 01 cd             	add    %rcx,%r13
  729c9d:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
  729ca1:	4c 89 f7             	mov    %r14,%rdi
  729ca4:	48 89 cd             	mov    %rcx,%rbp
  729ca7:	4c 89 04 24          	mov    %r8,(%rsp)
  729cab:	e8 b0 ff ff ff       	call   729c60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  729cb0:	49 89 c6             	mov    %rax,%r14
  729cb3:	4a 8d 34 23          	lea    (%rbx,%r12,1),%rsi
  729cb7:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
  729cbb:	48 89 df             	mov    %rbx,%rdi
  729cbe:	48 89 e9             	mov    %rbp,%rcx
  729cc1:	4c 8b 04 24          	mov    (%rsp),%r8
  729cc5:	e8 96 ff ff ff       	call   729c60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  729cca:	48 89 c3             	mov    %rax,%rbx
  729ccd:	4d 01 fc             	add    %r15,%r12
  729cd0:	4d 01 fd             	add    %r15,%r13
  729cd3:	4c 89 ff             	mov    %r15,%rdi
  729cd6:	4c 89 e6             	mov    %r12,%rsi
  729cd9:	4c 89 ea             	mov    %r13,%rdx
  729cdc:	48 89 e9             	mov    %rbp,%rcx
  729cdf:	4c 8b 04 24          	mov    (%rsp),%r8
  729ce3:	e8 78 ff ff ff       	call   729c60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  729ce8:	49 89 c7             	mov    %rax,%r15
  729ceb:	41 8b 06             	mov    (%r14),%eax
  729cee:	8b 0b                	mov    (%rbx),%ecx
  729cf0:	39 c8                	cmp    %ecx,%eax
  729cf2:	0f 92 c2             	setb   %dl
  729cf5:	41 8b 37             	mov    (%r15),%esi
  729cf8:	39 f0                	cmp    %esi,%eax
  729cfa:	0f 92 c0             	setb   %al
  729cfd:	30 d0                	xor    %dl,%al
  729cff:	39 f1                	cmp    %esi,%ecx
  729d01:	0f 92 c1             	setb   %cl
  729d04:	30 d1                	xor    %dl,%cl
  729d06:	49 0f 45 df          	cmovne %r15,%rbx
  729d0a:	84 c0                	test   %al,%al
  729d0c:	49 0f 45 de          	cmovne %r14,%rbx
  729d10:	48 89 d8             	mov    %rbx,%rax
  729d13:	48 83 c4 08          	add    $0x8,%rsp
  729d17:	5b                   	pop    %rbx
  729d18:	41 5c                	pop    %r12
  729d1a:	41 5d                	pop    %r13
  729d1c:	41 5e                	pop    %r14
  729d1e:	41 5f                	pop    %r15
  729d20:	5d                   	pop    %rbp
  729d21:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
