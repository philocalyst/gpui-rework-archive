
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006f4370 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB28_>:
  6f4370:	48 83 ec 18          	sub    $0x18,%rsp
  6f4374:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  6f4379:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f437e:	48 83 fe 02          	cmp    $0x2,%rsi
  6f4382:	73 05                	jae    6f4389 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB28_+0x19>
  6f4384:	48 83 c4 18          	add    $0x18,%rsp
  6f4388:	c3                   	ret
  6f4389:	48 83 fe 15          	cmp    $0x15,%rsi
  6f438d:	73 14                	jae    6f43a3 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB28_+0x33>
  6f438f:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
  6f4394:	ba 01 00 00 00       	mov    $0x1,%edx
  6f4399:	e8 c2 ce 01 00       	call   711260 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_>
  6f439e:	48 83 c4 18          	add    $0x18,%rsp
  6f43a2:	c3                   	ret
  6f43a3:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  6f43a8:	e8 13 1b 03 00       	call   725ec0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_>
  6f43ad:	48 83 c4 18          	add    $0x18,%rsp
  6f43b1:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
