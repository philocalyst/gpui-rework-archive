
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000713910 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_>:
  713910:	55                   	push   %rbp
  713911:	41 57                	push   %r15
  713913:	41 56                	push   %r14
  713915:	41 55                	push   %r13
  713917:	41 54                	push   %r12
  713919:	53                   	push   %rbx
  71391a:	48 83 ec 38          	sub    $0x38,%rsp
  71391e:	48 83 fe 02          	cmp    $0x2,%rsi
  713922:	0f 82 76 04 00 00    	jb     713d9e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x48e>
  713928:	48 8d 46 10          	lea    0x10(%rsi),%rax
  71392c:	48 39 c1             	cmp    %rax,%rcx
  71392f:	0f 82 c8 04 00 00    	jb     713dfd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4ed>
  713935:	48 89 d3             	mov    %rdx,%rbx
  713938:	48 89 f5             	mov    %rsi,%rbp
  71393b:	48 d1 ed             	shr    $1,%rbp
  71393e:	48 83 fe 07          	cmp    $0x7,%rsi
  713942:	0f 86 b3 01 00 00    	jbe    713afb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x1eb>
  713948:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  71394c:	48 8b 57 48          	mov    0x48(%rdi),%rdx
  713950:	45 31 c0             	xor    %r8d,%r8d
  713953:	45 31 d2             	xor    %r10d,%r10d
  713956:	48 3b 0f             	cmp    (%rdi),%rcx
  713959:	41 0f 93 c0          	setae  %r8b
  71395d:	41 0f 92 c2          	setb   %r10b
  713961:	48 8d 47 48          	lea    0x48(%rdi),%rax
  713965:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  713969:	48 3b 57 30          	cmp    0x30(%rdi),%rdx
  71396d:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  713971:	4e 8d 34 d7          	lea    (%rdi,%r10,8),%r14
  713975:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  713979:	4c 89 ca             	mov    %r9,%rdx
  71397c:	48 0f 42 d0          	cmovb  %rax,%rdx
  713980:	4a 8d 0c c7          	lea    (%rdi,%r8,8),%rcx
  713984:	49 0f 42 c1          	cmovb  %r9,%rax
  713988:	4c 8b 0a             	mov    (%rdx),%r9
  71398b:	4c 8b 18             	mov    (%rax),%r11
  71398e:	4e 8b 04 c7          	mov    (%rdi,%r8,8),%r8
  713992:	4d 39 c3             	cmp    %r8,%r11
  713995:	49 89 cf             	mov    %rcx,%r15
  713998:	4c 0f 42 fa          	cmovb  %rdx,%r15
  71399c:	4e 3b 0c d7          	cmp    (%rdi,%r10,8),%r9
  7139a0:	4d 0f 42 fe          	cmovb  %r14,%r15
  7139a4:	4c 0f 42 f2          	cmovb  %rdx,%r14
  7139a8:	48 0f 42 d1          	cmovb  %rcx,%rdx
  7139ac:	4d 39 c3             	cmp    %r8,%r11
  7139af:	48 0f 43 c8          	cmovae %rax,%rcx
  7139b3:	48 0f 42 d0          	cmovb  %rax,%rdx
  7139b7:	48 8b 02             	mov    (%rdx),%rax
  7139ba:	49 3b 07             	cmp    (%r15),%rax
  7139bd:	4c 89 f8             	mov    %r15,%rax
  7139c0:	48 0f 42 c2          	cmovb  %rdx,%rax
  7139c4:	49 0f 42 d7          	cmovb  %r15,%rdx
  7139c8:	4d 8b 46 10          	mov    0x10(%r14),%r8
  7139cc:	4c 89 43 10          	mov    %r8,0x10(%rbx)
  7139d0:	41 0f 10 06          	movups (%r14),%xmm0
  7139d4:	0f 11 03             	movups %xmm0,(%rbx)
  7139d7:	4c 8b 40 10          	mov    0x10(%rax),%r8
  7139db:	4c 89 43 28          	mov    %r8,0x28(%rbx)
  7139df:	0f 10 00             	movups (%rax),%xmm0
  7139e2:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
  7139e6:	48 8b 42 10          	mov    0x10(%rdx),%rax
  7139ea:	48 89 43 40          	mov    %rax,0x40(%rbx)
  7139ee:	0f 10 02             	movups (%rdx),%xmm0
  7139f1:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  7139f5:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
  7139fc:	00 
  7139fd:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  713a01:	4c 8d 0c 17          	lea    (%rdi,%rdx,1),%r9
  713a05:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
  713a0a:	48 8b 44 17 48       	mov    0x48(%rdi,%rdx,1),%rax
  713a0f:	45 31 d2             	xor    %r10d,%r10d
  713a12:	45 31 db             	xor    %r11d,%r11d
  713a15:	4c 3b 04 17          	cmp    (%rdi,%rdx,1),%r8
  713a19:	41 0f 93 c2          	setae  %r10b
  713a1d:	41 0f 92 c3          	setb   %r11b
  713a21:	4c 8d 04 17          	lea    (%rdi,%rdx,1),%r8
  713a25:	49 83 c0 48          	add    $0x48,%r8
  713a29:	4c 8d 3c 17          	lea    (%rdi,%rdx,1),%r15
  713a2d:	49 83 c7 30          	add    $0x30,%r15
  713a31:	48 3b 44 17 30       	cmp    0x30(%rdi,%rdx,1),%rax
  713a36:	4f 8d 1c 5b          	lea    (%r11,%r11,2),%r11
  713a3a:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  713a3e:	4f 8d 34 d1          	lea    (%r9,%r10,8),%r14
  713a42:	4c 89 f8             	mov    %r15,%rax
  713a45:	49 0f 42 c0          	cmovb  %r8,%rax
  713a49:	4d 0f 42 c7          	cmovb  %r15,%r8
  713a4d:	4d 8b 38             	mov    (%r8),%r15
  713a50:	4f 8b 14 d1          	mov    (%r9,%r10,8),%r10
  713a54:	4d 39 d7             	cmp    %r10,%r15
  713a57:	4d 89 f4             	mov    %r14,%r12
  713a5a:	4c 0f 42 e0          	cmovb  %rax,%r12
  713a5e:	4c 8b 28             	mov    (%rax),%r13
  713a61:	4f 3b 2c d9          	cmp    (%r9,%r11,8),%r13
  713a65:	4f 8d 0c d9          	lea    (%r9,%r11,8),%r9
  713a69:	4d 0f 42 e1          	cmovb  %r9,%r12
  713a6d:	4c 0f 42 c8          	cmovb  %rax,%r9
  713a71:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  713a75:	49 0f 42 c6          	cmovb  %r14,%rax
  713a79:	4d 39 d7             	cmp    %r10,%r15
  713a7c:	4d 0f 43 f0          	cmovae %r8,%r14
  713a80:	49 0f 42 c0          	cmovb  %r8,%rax
  713a84:	4c 89 5b 58          	mov    %r11,0x58(%rbx)
  713a88:	4c 8b 00             	mov    (%rax),%r8
  713a8b:	4d 3b 04 24          	cmp    (%r12),%r8
  713a8f:	0f 10 01             	movups (%rcx),%xmm0
  713a92:	4c 89 e1             	mov    %r12,%rcx
  713a95:	48 0f 42 c8          	cmovb  %rax,%rcx
  713a99:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
  713a9d:	49 0f 42 c4          	cmovb  %r12,%rax
  713aa1:	4d 8b 41 10          	mov    0x10(%r9),%r8
  713aa5:	4c 89 44 13 10       	mov    %r8,0x10(%rbx,%rdx,1)
  713aaa:	41 0f 10 01          	movups (%r9),%xmm0
  713aae:	0f 11 04 13          	movups %xmm0,(%rbx,%rdx,1)
  713ab2:	0f 10 01             	movups (%rcx),%xmm0
  713ab5:	0f 11 44 13 18       	movups %xmm0,0x18(%rbx,%rdx,1)
  713aba:	48 8b 49 10          	mov    0x10(%rcx),%rcx
  713abe:	48 89 4c 13 28       	mov    %rcx,0x28(%rbx,%rdx,1)
  713ac3:	0f 10 00             	movups (%rax),%xmm0
  713ac6:	0f 11 44 13 30       	movups %xmm0,0x30(%rbx,%rdx,1)
  713acb:	48 8b 48 10          	mov    0x10(%rax),%rcx
  713acf:	48 89 4c 13 40       	mov    %rcx,0x40(%rbx,%rdx,1)
  713ad4:	41 0f 10 06          	movups (%r14),%xmm0
  713ad8:	0f 11 44 13 48       	movups %xmm0,0x48(%rbx,%rdx,1)
  713add:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  713ae1:	48 89 4c 13 58       	mov    %rcx,0x58(%rbx,%rdx,1)
  713ae6:	ba 04 00 00 00       	mov    $0x4,%edx
  713aeb:	49 89 f6             	mov    %rsi,%r14
  713aee:	49 29 ee             	sub    %rbp,%r14
  713af1:	48 39 ea             	cmp    %rbp,%rdx
  713af4:	72 45                	jb     713b3b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x22b>
  713af6:	e9 e6 00 00 00       	jmp    713be1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  713afb:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
  713aff:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
  713b03:	0f 10 07             	movups (%rdi),%xmm0
  713b06:	0f 11 03             	movups %xmm0,(%rbx)
  713b09:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  713b10:	00 
  713b11:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  713b15:	48 8b 54 0f 10       	mov    0x10(%rdi,%rcx,1),%rdx
  713b1a:	48 89 54 0b 10       	mov    %rdx,0x10(%rbx,%rcx,1)
  713b1f:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  713b23:	0f 11 04 0b          	movups %xmm0,(%rbx,%rcx,1)
  713b27:	ba 01 00 00 00       	mov    $0x1,%edx
  713b2c:	49 89 f6             	mov    %rsi,%r14
  713b2f:	49 29 ee             	sub    %rbp,%r14
  713b32:	48 39 ea             	cmp    %rbp,%rdx
  713b35:	0f 83 a6 00 00 00    	jae    713be1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  713b3b:	8d 0c d5 00 00 00 00 	lea    0x0(,%rdx,8),%ecx
  713b42:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  713b46:	49 89 d3             	mov    %rdx,%r11
  713b49:	eb 21                	jmp    713b6c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x25c>
  713b4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  713b50:	49 89 d9             	mov    %rbx,%r9
  713b53:	4d 89 01             	mov    %r8,(%r9)
  713b56:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  713b5b:	41 0f 11 41 08       	movups %xmm0,0x8(%r9)
  713b60:	49 ff c3             	inc    %r11
  713b63:	48 83 c1 18          	add    $0x18,%rcx
  713b67:	49 39 eb             	cmp    %rbp,%r11
  713b6a:	74 75                	je     713be1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  713b6c:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
  713b73:	00 
  713b74:	4c 8d 0c 40          	lea    (%rax,%rax,2),%r9
  713b78:	42 0f 10 04 0f       	movups (%rdi,%r9,1),%xmm0
  713b7d:	42 0f 11 04 0b       	movups %xmm0,(%rbx,%r9,1)
  713b82:	4a 8b 44 0f 10       	mov    0x10(%rdi,%r9,1),%rax
  713b87:	4a 89 44 0b 10       	mov    %rax,0x10(%rbx,%r9,1)
  713b8c:	4e 8b 04 0b          	mov    (%rbx,%r9,1),%r8
  713b90:	4e 3b 44 0b e8       	cmp    -0x18(%rbx,%r9,1),%r8
  713b95:	73 c9                	jae    713b60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x250>
  713b97:	49 01 f9             	add    %rdi,%r9
  713b9a:	41 0f 10 41 08       	movups 0x8(%r9),%xmm0
  713b9f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  713ba4:	49 89 ca             	mov    %rcx,%r10
  713ba7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  713bae:	00 00 
  713bb0:	4a 8b 44 13 f8       	mov    -0x8(%rbx,%r10,1),%rax
  713bb5:	4a 89 44 13 10       	mov    %rax,0x10(%rbx,%r10,1)
  713bba:	42 0f 10 44 13 e8    	movups -0x18(%rbx,%r10,1),%xmm0
  713bc0:	42 0f 11 04 13       	movups %xmm0,(%rbx,%r10,1)
  713bc5:	49 83 fa 18          	cmp    $0x18,%r10
  713bc9:	74 85                	je     713b50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x240>
  713bcb:	4d 8d 4a e8          	lea    -0x18(%r10),%r9
  713bcf:	4e 3b 44 13 d0       	cmp    -0x30(%rbx,%r10,1),%r8
  713bd4:	4d 89 ca             	mov    %r9,%r10
  713bd7:	72 d7                	jb     713bb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2a0>
  713bd9:	49 01 d9             	add    %rbx,%r9
  713bdc:	e9 72 ff ff ff       	jmp    713b53 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x243>
  713be1:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  713be8:	00 
  713be9:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  713bed:	48 8d 0c 03          	lea    (%rbx,%rax,1),%rcx
  713bf1:	4c 39 f2             	cmp    %r14,%rdx
  713bf4:	0f 83 a7 00 00 00    	jae    713ca1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x391>
  713bfa:	48 01 f8             	add    %rdi,%rax
  713bfd:	44 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%r8d
  713c04:	00 
  713c05:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  713c09:	eb 21                	jmp    713c2c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x31c>
  713c0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  713c10:	49 89 ca             	mov    %rcx,%r10
  713c13:	4d 89 0a             	mov    %r9,(%r10)
  713c16:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  713c1b:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  713c20:	48 ff c2             	inc    %rdx
  713c23:	49 83 c0 18          	add    $0x18,%r8
  713c27:	4c 39 f2             	cmp    %r14,%rdx
  713c2a:	74 75                	je     713ca1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x391>
  713c2c:	4c 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%r9
  713c33:	00 
  713c34:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  713c38:	42 0f 10 04 10       	movups (%rax,%r10,1),%xmm0
  713c3d:	42 0f 11 04 11       	movups %xmm0,(%rcx,%r10,1)
  713c42:	4e 8b 4c 10 10       	mov    0x10(%rax,%r10,1),%r9
  713c47:	4e 89 4c 11 10       	mov    %r9,0x10(%rcx,%r10,1)
  713c4c:	4e 8b 0c 11          	mov    (%rcx,%r10,1),%r9
  713c50:	4e 3b 4c 11 e8       	cmp    -0x18(%rcx,%r10,1),%r9
  713c55:	73 c9                	jae    713c20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x310>
  713c57:	49 01 c2             	add    %rax,%r10
  713c5a:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  713c5f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  713c64:	4d 89 c3             	mov    %r8,%r11
  713c67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  713c6e:	00 00 
  713c70:	4e 8b 54 19 f8       	mov    -0x8(%rcx,%r11,1),%r10
  713c75:	4e 89 54 19 10       	mov    %r10,0x10(%rcx,%r11,1)
  713c7a:	42 0f 10 44 19 e8    	movups -0x18(%rcx,%r11,1),%xmm0
  713c80:	42 0f 11 04 19       	movups %xmm0,(%rcx,%r11,1)
  713c85:	49 83 fb 18          	cmp    $0x18,%r11
  713c89:	74 85                	je     713c10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x300>
  713c8b:	4d 8d 53 e8          	lea    -0x18(%r11),%r10
  713c8f:	4e 3b 4c 19 d0       	cmp    -0x30(%rcx,%r11,1),%r9
  713c94:	4d 89 d3             	mov    %r10,%r11
  713c97:	72 d7                	jb     713c70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x360>
  713c99:	49 01 ca             	add    %rcx,%r10
  713c9c:	e9 72 ff ff ff       	jmp    713c13 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x303>
  713ca1:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  713ca6:	48 8d 14 76          	lea    (%rsi,%rsi,2),%rdx
  713caa:	4c 8d 0c d7          	lea    (%rdi,%rdx,8),%r9
  713cae:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  713cb2:	48 8d 74 d3 e8       	lea    -0x18(%rbx,%rdx,8),%rsi
  713cb7:	4c 8d 79 e8          	lea    -0x18(%rcx),%r15
  713cbb:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  713cc0:	49 89 f8             	mov    %rdi,%r8
  713cc3:	48 89 df             	mov    %rbx,%rdi
  713cc6:	eb 58                	jmp    713d20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x410>
  713cc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  713ccf:	00 
  713cd0:	45 88 eb             	mov    %r13b,%r11b
  713cd3:	4b 8d 04 5b          	lea    (%r11,%r11,2),%rax
  713cd7:	48 8d 0c c1          	lea    (%rcx,%rax,8),%rcx
  713cdb:	41 88 ea             	mov    %bpl,%r10b
  713cde:	4b 8d 04 52          	lea    (%r10,%r10,2),%rax
  713ce2:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  713ce8:	4d 19 d2             	sbb    %r10,%r10
  713ceb:	48 8d 3c c7          	lea    (%rdi,%rax,8),%rdi
  713cef:	49 83 c0 18          	add    $0x18,%r8
  713cf3:	48 8b 42 10          	mov    0x10(%rdx),%rax
  713cf7:	49 89 41 10          	mov    %rax,0x10(%r9)
  713cfb:	0f 10 02             	movups (%rdx),%xmm0
  713cfe:	41 0f 11 01          	movups %xmm0,(%r9)
  713d02:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
  713d06:	48 8d 34 c6          	lea    (%rsi,%rax,8),%rsi
  713d0a:	4b 8d 04 52          	lea    (%r10,%r10,2),%rax
  713d0e:	4d 8d 3c c7          	lea    (%r15,%rax,8),%r15
  713d12:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  713d16:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  713d1b:	48 ff cd             	dec    %rbp
  713d1e:	74 57                	je     713d77 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x467>
  713d20:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
  713d25:	4c 8b 21             	mov    (%rcx),%r12
  713d28:	45 31 d2             	xor    %r10d,%r10d
  713d2b:	45 31 db             	xor    %r11d,%r11d
  713d2e:	48 89 ca             	mov    %rcx,%rdx
  713d31:	4c 3b 27             	cmp    (%rdi),%r12
  713d34:	40 0f 93 c5          	setae  %bpl
  713d38:	41 0f 92 c5          	setb   %r13b
  713d3c:	72 03                	jb     713d41 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x431>
  713d3e:	48 89 fa             	mov    %rdi,%rdx
  713d41:	4c 8b 62 10          	mov    0x10(%rdx),%r12
  713d45:	4d 89 60 10          	mov    %r12,0x10(%r8)
  713d49:	0f 10 02             	movups (%rdx),%xmm0
  713d4c:	41 0f 11 00          	movups %xmm0,(%r8)
  713d50:	4c 8b 36             	mov    (%rsi),%r14
  713d53:	49 8b 07             	mov    (%r15),%rax
  713d56:	49 39 c6             	cmp    %rax,%r14
  713d59:	41 bc 00 00 00 00    	mov    $0x0,%r12d
  713d5f:	49 83 d4 ff          	adc    $0xffffffffffffffff,%r12
  713d63:	4c 89 fa             	mov    %r15,%rdx
  713d66:	49 39 c6             	cmp    %rax,%r14
  713d69:	0f 82 61 ff ff ff    	jb     713cd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x3c0>
  713d6f:	48 89 f2             	mov    %rsi,%rdx
  713d72:	e9 59 ff ff ff       	jmp    713cd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x3c0>
  713d77:	49 83 c7 18          	add    $0x18,%r15
  713d7b:	48 83 c6 18          	add    $0x18,%rsi
  713d7f:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  713d84:	41 f6 c5 01          	test   $0x1,%r13b
  713d88:	75 23                	jne    713dad <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x49d>
  713d8a:	48 39 f1             	cmp    %rsi,%rcx
  713d8d:	0f 95 c0             	setne  %al
  713d90:	4c 39 ff             	cmp    %r15,%rdi
  713d93:	75 57                	jne    713dec <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4dc>
  713d95:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  713d9a:	84 c0                	test   %al,%al
  713d9c:	75 59                	jne    713df7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4e7>
  713d9e:	48 83 c4 38          	add    $0x38,%rsp
  713da2:	5b                   	pop    %rbx
  713da3:	41 5c                	pop    %r12
  713da5:	41 5d                	pop    %r13
  713da7:	41 5e                	pop    %r14
  713da9:	41 5f                	pop    %r15
  713dab:	5d                   	pop    %rbp
  713dac:	c3                   	ret
  713dad:	31 c0                	xor    %eax,%eax
  713daf:	31 d2                	xor    %edx,%edx
  713db1:	4c 39 ff             	cmp    %r15,%rdi
  713db4:	0f 93 c0             	setae  %al
  713db7:	0f 92 c2             	setb   %dl
  713dba:	49 89 c9             	mov    %rcx,%r9
  713dbd:	4c 0f 42 cf          	cmovb  %rdi,%r9
  713dc1:	4d 8b 51 10          	mov    0x10(%r9),%r10
  713dc5:	4d 89 50 10          	mov    %r10,0x10(%r8)
  713dc9:	41 0f 10 01          	movups (%r9),%xmm0
  713dcd:	41 0f 11 00          	movups %xmm0,(%r8)
  713dd1:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  713dd5:	48 8d 3c d7          	lea    (%rdi,%rdx,8),%rdi
  713dd9:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  713ddd:	48 8d 0c c1          	lea    (%rcx,%rax,8),%rcx
  713de1:	48 39 f1             	cmp    %rsi,%rcx
  713de4:	0f 95 c0             	setne  %al
  713de7:	4c 39 ff             	cmp    %r15,%rdi
  713dea:	74 a9                	je     713d95 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x485>
  713dec:	b0 01                	mov    $0x1,%al
  713dee:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  713df3:	84 c0                	test   %al,%al
  713df5:	74 a7                	je     713d9e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x48e>
  713df7:	ff 15 43 6f 3d 00    	call   *0x3d6f43(%rip)        # aead40 <_DYNAMIC+0x6c8>
  713dfd:	0f 0b                	ud2
  713dff:	49 89 c4             	mov    %rax,%r12
  713e02:	49 c1 e5 03          	shl    $0x3,%r13
  713e06:	4a 8d 14 6d 00 00 00 	lea    0x0(,%r13,2),%rdx
  713e0d:	00 
  713e0e:	4c 01 ea             	add    %r13,%rdx
  713e11:	4c 89 f7             	mov    %r14,%rdi
  713e14:	48 89 de             	mov    %rbx,%rsi
  713e17:	ff 15 cb 6a 3d 00    	call   *0x3d6acb(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  713e1d:	4c 89 e7             	mov    %r12,%rdi
  713e20:	e8 7b 72 3a 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
