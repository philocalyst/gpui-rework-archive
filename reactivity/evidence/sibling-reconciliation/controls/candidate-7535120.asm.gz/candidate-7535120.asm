
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072fa10 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_>:
  72fa10:	55                   	push   %rbp
  72fa11:	41 57                	push   %r15
  72fa13:	41 56                	push   %r14
  72fa15:	41 55                	push   %r13
  72fa17:	41 54                	push   %r12
  72fa19:	53                   	push   %rbx
  72fa1a:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
  72fa21:	0f 10 07             	movups (%rdi),%xmm0
  72fa24:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  72fa28:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  72fa2d:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  72fa32:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  72fa37:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  72fa3c:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  72fa41:	48 39 c1             	cmp    %rax,%rcx
  72fa44:	0f 84 b2 00 00 00    	je     72fafc <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_+0xec>
  72fa4a:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
  72fa4e:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72fa53:	4c 8b 7e 08          	mov    0x8(%rsi),%r15
  72fa57:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  72fa5c:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  72fa60:	49 69 d7 e0 00 00 00 	imul   $0xe0,%r15,%rdx
  72fa67:	48 8d 2c 0a          	lea    (%rdx,%rcx,1),%rbp
  72fa6b:	48 81 c5 b8 00 00 00 	add    $0xb8,%rbp
  72fa72:	48 05 50 ff ff ff    	add    $0xffffffffffffff50,%rax
  72fa78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72fa7f:	00 
  72fa80:	49 89 c5             	mov    %rax,%r13
  72fa83:	4c 8b 20             	mov    (%rax),%r12
  72fa86:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  72fa8a:	74 64                	je     72faf0 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_+0xe0>
  72fa8c:	49 8d 75 08          	lea    0x8(%r13),%rsi
  72fa90:	ba a8 00 00 00       	mov    $0xa8,%edx
  72fa95:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  72fa9a:	48 8b 1d 4f 82 3b 00 	mov    0x3b824f(%rip),%rbx        # ae7cf0 <memcpy@GLIBC_2.14>
  72faa1:	ff d3                	call   *%rbx
  72faa3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72faa8:	44 8b 30             	mov    (%rax),%r14d
  72faab:	4c 89 a5 48 ff ff ff 	mov    %r12,-0xb8(%rbp)
  72fab2:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
  72fab9:	ba a8 00 00 00       	mov    $0xa8,%edx
  72fabe:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  72fac3:	ff d3                	call   *%rbx
  72fac5:	c7 45 f8 01 00 00 00 	movl   $0x1,-0x8(%rbp)
  72facc:	44 89 75 fc          	mov    %r14d,-0x4(%rbp)
  72fad0:	48 c7 45 00 00 00 00 	movq   $0x0,0x0(%rbp)
  72fad7:	00 
  72fad8:	49 ff c7             	inc    %r15
  72fadb:	48 81 c5 e0 00 00 00 	add    $0xe0,%rbp
  72fae2:	49 8d 85 50 ff ff ff 	lea    -0xb0(%r13),%rax
  72fae9:	4c 3b 6c 24 18       	cmp    0x18(%rsp),%r13
  72faee:	75 90                	jne    72fa80 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_+0x70>
  72faf0:	4c 89 6c 24 38       	mov    %r13,0x38(%rsp)
  72faf5:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  72fafa:	eb 04                	jmp    72fb00 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_+0xf0>
  72fafc:	4c 8b 7e 08          	mov    0x8(%rsi),%r15
  72fb00:	48 8b 06             	mov    (%rsi),%rax
  72fb03:	4c 89 38             	mov    %r15,(%rax)
  72fb06:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  72fb0b:	e8 a0 01 ff ff       	call   71fcb0 <_RNvXse_NtNtCscdodAO9FK5_5alloc3vec9into_iterINtB5_8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  72fb10:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
  72fb17:	5b                   	pop    %rbx
  72fb18:	41 5c                	pop    %r12
  72fb1a:	41 5d                	pop    %r13
  72fb1c:	41 5e                	pop    %r14
  72fb1e:	41 5f                	pop    %r15
  72fb20:	5d                   	pop    %rbp
  72fb21:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
