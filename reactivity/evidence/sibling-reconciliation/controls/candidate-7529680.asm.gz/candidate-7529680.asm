
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072e4d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>:
  72e4d0:	55                   	push   %rbp
  72e4d1:	41 57                	push   %r15
  72e4d3:	41 56                	push   %r14
  72e4d5:	41 55                	push   %r13
  72e4d7:	41 54                	push   %r12
  72e4d9:	53                   	push   %rbx
  72e4da:	50                   	push   %rax
  72e4db:	49 89 d7             	mov    %rdx,%r15
  72e4de:	48 89 f3             	mov    %rsi,%rbx
  72e4e1:	49 89 fe             	mov    %rdi,%r14
  72e4e4:	48 b8 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rax
  72e4eb:	ff ff 1f 
  72e4ee:	48 85 c1             	test   %rax,%rcx
  72e4f1:	74 68                	je     72e55b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_+0x8b>
  72e4f3:	48 c1 e9 03          	shr    $0x3,%rcx
  72e4f7:	49 89 cc             	mov    %rcx,%r12
  72e4fa:	49 c1 e4 04          	shl    $0x4,%r12
  72e4fe:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
  72e502:	48 8d 04 c9          	lea    (%rcx,%rcx,8),%rax
  72e506:	4c 8d 2c 40          	lea    (%rax,%rax,2),%r13
  72e50a:	49 01 cd             	add    %rcx,%r13
  72e50d:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
  72e511:	4c 89 f7             	mov    %r14,%rdi
  72e514:	48 89 cd             	mov    %rcx,%rbp
  72e517:	4c 89 04 24          	mov    %r8,(%rsp)
  72e51b:	e8 b0 ff ff ff       	call   72e4d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  72e520:	49 89 c6             	mov    %rax,%r14
  72e523:	4a 8d 34 23          	lea    (%rbx,%r12,1),%rsi
  72e527:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
  72e52b:	48 89 df             	mov    %rbx,%rdi
  72e52e:	48 89 e9             	mov    %rbp,%rcx
  72e531:	4c 8b 04 24          	mov    (%rsp),%r8
  72e535:	e8 96 ff ff ff       	call   72e4d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  72e53a:	48 89 c3             	mov    %rax,%rbx
  72e53d:	4d 01 fc             	add    %r15,%r12
  72e540:	4d 01 fd             	add    %r15,%r13
  72e543:	4c 89 ff             	mov    %r15,%rdi
  72e546:	4c 89 e6             	mov    %r12,%rsi
  72e549:	4c 89 ea             	mov    %r13,%rdx
  72e54c:	48 89 e9             	mov    %rbp,%rcx
  72e54f:	4c 8b 04 24          	mov    (%rsp),%r8
  72e553:	e8 78 ff ff ff       	call   72e4d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  72e558:	49 89 c7             	mov    %rax,%r15
  72e55b:	41 8b 06             	mov    (%r14),%eax
  72e55e:	8b 0b                	mov    (%rbx),%ecx
  72e560:	39 c8                	cmp    %ecx,%eax
  72e562:	0f 92 c2             	setb   %dl
  72e565:	41 8b 37             	mov    (%r15),%esi
  72e568:	39 f0                	cmp    %esi,%eax
  72e56a:	0f 92 c0             	setb   %al
  72e56d:	30 d0                	xor    %dl,%al
  72e56f:	39 f1                	cmp    %esi,%ecx
  72e571:	0f 92 c1             	setb   %cl
  72e574:	30 d1                	xor    %dl,%cl
  72e576:	49 0f 45 df          	cmovne %r15,%rbx
  72e57a:	84 c0                	test   %al,%al
  72e57c:	49 0f 45 de          	cmovne %r14,%rbx
  72e580:	48 89 d8             	mov    %rbx,%rax
  72e583:	48 83 c4 08          	add    $0x8,%rsp
  72e587:	5b                   	pop    %rbx
  72e588:	41 5c                	pop    %r12
  72e58a:	41 5d                	pop    %r13
  72e58c:	41 5e                	pop    %r14
  72e58e:	41 5f                	pop    %r15
  72e590:	5d                   	pop    %rbp
  72e591:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
