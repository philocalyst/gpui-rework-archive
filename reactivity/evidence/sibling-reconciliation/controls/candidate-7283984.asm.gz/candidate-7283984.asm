
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006f2510 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>:
  6f2510:	55                   	push   %rbp
  6f2511:	41 57                	push   %r15
  6f2513:	41 56                	push   %r14
  6f2515:	41 55                	push   %r13
  6f2517:	41 54                	push   %r12
  6f2519:	53                   	push   %rbx
  6f251a:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
  6f2521:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
  6f2528:	00 
  6f2529:	49 89 f4             	mov    %rsi,%r12
  6f252c:	48 89 bc 24 e0 00 00 	mov    %rdi,0xe0(%rsp)
  6f2533:	00 
  6f2534:	48 8b 2e             	mov    (%rsi),%rbp
  6f2537:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f253b:	0f b7 9d 32 05 00 00 	movzwl 0x532(%rbp),%ebx
  6f2542:	4a 8d bc ed d8 04 00 	lea    0x4d8(%rbp,%r13,8),%rdi
  6f2549:	00 
  6f254a:	4a 8b 84 ed d8 04 00 	mov    0x4d8(%rbp,%r13,8),%rax
  6f2551:	00 
  6f2552:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6f2557:	4a 8d 34 ed e0 04 00 	lea    0x4e0(,%r13,8),%rsi
  6f255e:	00 
  6f255f:	48 01 ee             	add    %rbp,%rsi
  6f2562:	4d 89 ef             	mov    %r13,%r15
  6f2565:	49 f7 d7             	not    %r15
  6f2568:	49 01 df             	add    %rbx,%r15
  6f256b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f2572:	00 
  6f2573:	4c 8b 35 6e 57 3f 00 	mov    0x3f576e(%rip),%r14        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f257a:	41 ff d6             	call   *%r14
  6f257d:	4c 89 2c 24          	mov    %r13,(%rsp)
  6f2581:	49 6b c5 70          	imul   $0x70,%r13,%rax
  6f2585:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f2589:	0f 10 44 05 60       	movups 0x60(%rbp,%rax,1),%xmm0
  6f258e:	0f 11 84 24 68 01 00 	movups %xmm0,0x168(%rsp)
  6f2595:	00 
  6f2596:	0f 10 44 05 50       	movups 0x50(%rbp,%rax,1),%xmm0
  6f259b:	0f 11 84 24 58 01 00 	movups %xmm0,0x158(%rsp)
  6f25a2:	00 
  6f25a3:	0f 10 44 05 40       	movups 0x40(%rbp,%rax,1),%xmm0
  6f25a8:	0f 11 84 24 48 01 00 	movups %xmm0,0x148(%rsp)
  6f25af:	00 
  6f25b0:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f25b5:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f25ba:	0f 10 54 05 20       	movups 0x20(%rbp,%rax,1),%xmm2
  6f25bf:	0f 10 5c 05 30       	movups 0x30(%rbp,%rax,1),%xmm3
  6f25c4:	0f 11 9c 24 38 01 00 	movups %xmm3,0x138(%rsp)
  6f25cb:	00 
  6f25cc:	0f 11 94 24 28 01 00 	movups %xmm2,0x128(%rsp)
  6f25d3:	00 
  6f25d4:	0f 11 8c 24 18 01 00 	movups %xmm1,0x118(%rsp)
  6f25db:	00 
  6f25dc:	0f 11 84 24 08 01 00 	movups %xmm0,0x108(%rsp)
  6f25e3:	00 
  6f25e4:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f25e8:	48 83 c6 70          	add    $0x70,%rsi
  6f25ec:	49 6b d7 70          	imul   $0x70,%r15,%rdx
  6f25f0:	41 ff d6             	call   *%r14
  6f25f3:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f25f6:	66 89 85 32 05 00 00 	mov    %ax,0x532(%rbp)
  6f25fd:	4d 8b 7c 24 08       	mov    0x8(%r12),%r15
  6f2602:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f2607:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  6f260e:	00 
  6f260f:	66 83 f8 04          	cmp    $0x4,%ax
  6f2613:	0f 87 65 01 00 00    	ja     6f277e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2619:	48 8b 85 d0 04 00 00 	mov    0x4d0(%rbp),%rax
  6f2620:	48 85 c0             	test   %rax,%rax
  6f2623:	0f 84 11 01 00 00    	je     6f273a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x22a>
  6f2629:	49 8d 4f 01          	lea    0x1(%r15),%rcx
  6f262d:	0f b7 95 30 05 00 00 	movzwl 0x530(%rbp),%edx
  6f2634:	48 85 d2             	test   %rdx,%rdx
  6f2637:	74 66                	je     6f269f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x18f>
  6f2639:	48 8b b4 d0 30 05 00 	mov    0x530(%rax,%rdx,8),%rsi
  6f2640:	00 
  6f2641:	48 ff ca             	dec    %rdx
  6f2644:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f2649:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6f264e:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6f2653:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6f2658:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f265f:	00 
  6f2660:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  6f2667:	00 
  6f2668:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f266f:	00 
  6f2670:	0f b7 86 32 05 00 00 	movzwl 0x532(%rsi),%eax
  6f2677:	01 c3                	add    %eax,%ebx
  6f2679:	83 fb 0c             	cmp    $0xc,%ebx
  6f267c:	0f 83 87 00 00 00    	jae    6f2709 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x1f9>
  6f2682:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f2687:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6f268c:	ba 01 00 00 00       	mov    $0x1,%edx
  6f2691:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f2695:	e8 f6 9d ff ff       	call   6ec490 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1o_5style5StyleEE25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f269a:	e9 ae 00 00 00       	jmp    6f274d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x23d>
  6f269f:	66 83 b8 32 05 00 00 	cmpw   $0x0,0x532(%rax)
  6f26a6:	00 
  6f26a7:	0f 84 92 07 00 00    	je     6f2e3f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x92f>
  6f26ad:	48 8b 90 40 05 00 00 	mov    0x540(%rax),%rdx
  6f26b4:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f26b9:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6f26be:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  6f26c5:	00 00 
  6f26c7:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f26cc:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f26d3:	00 
  6f26d4:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
  6f26db:	00 
  6f26dc:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f26e3:	00 
  6f26e4:	0f b7 82 32 05 00 00 	movzwl 0x532(%rdx),%eax
  6f26eb:	01 c3                	add    %eax,%ebx
  6f26ed:	83 fb 0c             	cmp    $0xc,%ebx
  6f26f0:	73 39                	jae    6f272b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x21b>
  6f26f2:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f26f7:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6f26fc:	31 d2                	xor    %edx,%edx
  6f26fe:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f2702:	e8 89 9d ff ff       	call   6ec490 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1o_5style5StyleEE25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2707:	eb 44                	jmp    6f274d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x23d>
  6f2709:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6f270e:	be 01 00 00 00       	mov    $0x1,%esi
  6f2713:	e8 78 13 00 00       	call   6f3a90 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2718:	48 8b 04 24          	mov    (%rsp),%rax
  6f271c:	48 ff c0             	inc    %rax
  6f271f:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  6f2724:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  6f2729:	eb 1d                	jmp    6f2748 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x238>
  6f272b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6f2730:	be 01 00 00 00       	mov    $0x1,%esi
  6f2735:	e8 96 17 00 00       	call   6f3ed0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f273a:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  6f273f:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  6f2744:	48 8b 04 24          	mov    (%rsp),%rax
  6f2748:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6f274d:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6f2752:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6f2757:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f275c:	48 89 04 24          	mov    %rax,(%rsp)
  6f2760:	4c 8b b5 d0 04 00 00 	mov    0x4d0(%rbp),%r14
  6f2767:	4d 85 f6             	test   %r14,%r14
  6f276a:	74 12                	je     6f277e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f276c:	41 0f b7 86 32 05 00 	movzwl 0x532(%r14),%eax
  6f2773:	00 
  6f2774:	66 83 f8 04          	cmp    $0x4,%ax
  6f2778:	0f 86 9b 00 00 00    	jbe    6f2819 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x309>
  6f277e:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6f2785:	00 
  6f2786:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  6f278d:	00 
  6f278e:	48 89 42 70          	mov    %rax,0x70(%rdx)
  6f2792:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  6f2799:	00 
  6f279a:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  6f279e:	0f 10 84 24 50 01 00 	movups 0x150(%rsp),%xmm0
  6f27a5:	00 
  6f27a6:	0f 11 42 50          	movups %xmm0,0x50(%rdx)
  6f27aa:	0f 10 84 24 40 01 00 	movups 0x140(%rsp),%xmm0
  6f27b1:	00 
  6f27b2:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  6f27b6:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  6f27bd:	00 
  6f27be:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  6f27c5:	00 
  6f27c6:	0f 10 84 24 10 01 00 	movups 0x110(%rsp),%xmm0
  6f27cd:	00 
  6f27ce:	0f 10 8c 24 20 01 00 	movups 0x120(%rsp),%xmm1
  6f27d5:	00 
  6f27d6:	0f 10 94 24 30 01 00 	movups 0x130(%rsp),%xmm2
  6f27dd:	00 
  6f27de:	0f 11 52 30          	movups %xmm2,0x30(%rdx)
  6f27e2:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
  6f27e6:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f27ea:	48 89 02             	mov    %rax,(%rdx)
  6f27ed:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f27f1:	48 89 6a 78          	mov    %rbp,0x78(%rdx)
  6f27f5:	4c 89 ba 80 00 00 00 	mov    %r15,0x80(%rdx)
  6f27fc:	48 8b 04 24          	mov    (%rsp),%rax
  6f2800:	48 89 82 88 00 00 00 	mov    %rax,0x88(%rdx)
  6f2807:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
  6f280e:	5b                   	pop    %rbx
  6f280f:	41 5c                	pop    %r12
  6f2811:	41 5d                	pop    %r13
  6f2813:	41 5e                	pop    %r14
  6f2815:	41 5f                	pop    %r15
  6f2817:	5d                   	pop    %rbp
  6f2818:	c3                   	ret
  6f2819:	4d 8d 67 01          	lea    0x1(%r15),%r12
  6f281d:	48 8d 0d 7c 70 3c 00 	lea    0x3c707c(%rip),%rcx        # ab98a0 <__frame_dummy_init_array_entry+0x98>
  6f2824:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f2829:	48 8d 0d 7c 0d 97 ff 	lea    -0x68f284(%rip),%rcx        # 635ac <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f2830:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  6f2835:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
  6f283c:	00 
  6f283d:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
  6f2842:	eb 2c                	jmp    6f2870 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x360>
  6f2844:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f284b:	00 00 00 00 00 
  6f2850:	ba 08 00 00 00       	mov    $0x8,%edx
  6f2855:	4c 89 ef             	mov    %r13,%rdi
  6f2858:	ff 15 6a 54 3f 00    	call   *0x3f546a(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  6f285e:	41 0f b7 86 32 05 00 	movzwl 0x532(%r14),%eax
  6f2865:	00 
  6f2866:	66 83 f8 04          	cmp    $0x4,%ax
  6f286a:	0f 87 0e ff ff ff    	ja     6f277e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2870:	4c 89 f1             	mov    %r14,%rcx
  6f2873:	0f b7 c0             	movzwl %ax,%eax
  6f2876:	4d 8b b6 d0 04 00 00 	mov    0x4d0(%r14),%r14
  6f287d:	4d 85 f6             	test   %r14,%r14
  6f2880:	0f 84 06 05 00 00    	je     6f2d8c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x87c>
  6f2886:	4c 89 e6             	mov    %r12,%rsi
  6f2889:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  6f288e:	44 0f b7 a1 30 05 00 	movzwl 0x530(%rcx),%r12d
  6f2895:	00 
  6f2896:	4d 85 e4             	test   %r12,%r12
  6f2899:	48 89 bc 24 f8 00 00 	mov    %rdi,0xf8(%rsp)
  6f28a0:	00 
  6f28a1:	0f 84 89 00 00 00    	je     6f2930 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x420>
  6f28a7:	4b 8b 9c e6 30 05 00 	mov    0x530(%r14,%r12,8),%rbx
  6f28ae:	00 
  6f28af:	49 ff cc             	dec    %r12
  6f28b2:	4c 89 b4 24 78 01 00 	mov    %r14,0x178(%rsp)
  6f28b9:	00 
  6f28ba:	48 89 bc 24 80 01 00 	mov    %rdi,0x180(%rsp)
  6f28c1:	00 
  6f28c2:	4c 89 a4 24 88 01 00 	mov    %r12,0x188(%rsp)
  6f28c9:	00 
  6f28ca:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  6f28d1:	00 
  6f28d2:	48 89 b4 24 98 01 00 	mov    %rsi,0x198(%rsp)
  6f28d9:	00 
  6f28da:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  6f28e1:	00 
  6f28e2:	48 89 b4 24 a8 01 00 	mov    %rsi,0x1a8(%rsp)
  6f28e9:	00 
  6f28ea:	0f b7 b3 32 05 00 00 	movzwl 0x532(%rbx),%esi
  6f28f1:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f28f4:	ff c2                	inc    %edx
  6f28f6:	83 fa 0c             	cmp    $0xc,%edx
  6f28f9:	0f 83 f5 04 00 00    	jae    6f2df4 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x8e4>
  6f28ff:	41 0f b7 96 32 05 00 	movzwl 0x532(%r14),%edx
  6f2906:	00 
  6f2907:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f290b:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6f2910:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  6f2915:	48 01 c6             	add    %rax,%rsi
  6f2918:	48 ff c6             	inc    %rsi
  6f291b:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  6f2920:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f2925:	e9 91 00 00 00       	jmp    6f29bb <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x4ab>
  6f292a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f2930:	41 0f b7 96 32 05 00 	movzwl 0x532(%r14),%edx
  6f2937:	00 
  6f2938:	66 85 d2             	test   %dx,%dx
  6f293b:	0f 84 fe 04 00 00    	je     6f2e3f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x92f>
  6f2941:	4d 8b 86 40 05 00 00 	mov    0x540(%r14),%r8
  6f2948:	4c 89 b4 24 b0 01 00 	mov    %r14,0x1b0(%rsp)
  6f294f:	00 
  6f2950:	48 89 bc 24 b8 01 00 	mov    %rdi,0x1b8(%rsp)
  6f2957:	00 
  6f2958:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
  6f295f:	00 00 00 00 00 
  6f2964:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
  6f296b:	00 
  6f296c:	48 89 b4 24 d0 01 00 	mov    %rsi,0x1d0(%rsp)
  6f2973:	00 
  6f2974:	4c 89 84 24 d8 01 00 	mov    %r8,0x1d8(%rsp)
  6f297b:	00 
  6f297c:	48 89 b4 24 e0 01 00 	mov    %rsi,0x1e0(%rsp)
  6f2983:	00 
  6f2984:	45 0f b7 88 32 05 00 	movzwl 0x532(%r8),%r9d
  6f298b:	00 
  6f298c:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f2990:	48 ff c6             	inc    %rsi
  6f2993:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f2997:	0f 83 71 04 00 00    	jae    6f2e0e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x8fe>
  6f299d:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f29a1:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6f29a6:	48 89 cb             	mov    %rcx,%rbx
  6f29a9:	45 31 e4             	xor    %r12d,%r12d
  6f29ac:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f29b1:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  6f29b6:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  6f29bb:	0f b7 c2             	movzwl %dx,%eax
  6f29be:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  6f29c5:	00 
  6f29c6:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  6f29cb:	66 89 b3 32 05 00 00 	mov    %si,0x532(%rbx)
  6f29d2:	4b 8d 3c e6          	lea    (%r14,%r12,8),%rdi
  6f29d6:	48 81 c7 d8 04 00 00 	add    $0x4d8,%rdi
  6f29dd:	4f 8b bc e6 d8 04 00 	mov    0x4d8(%r14,%r12,8),%r15
  6f29e4:	00 
  6f29e5:	4b 8d 34 e6          	lea    (%r14,%r12,8),%rsi
  6f29e9:	48 81 c6 e0 04 00 00 	add    $0x4e0,%rsi
  6f29f0:	4c 89 e5             	mov    %r12,%rbp
  6f29f3:	48 f7 d5             	not    %rbp
  6f29f6:	48 01 c5             	add    %rax,%rbp
  6f29f9:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
  6f2a00:	00 
  6f2a01:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
  6f2a08:	00 
  6f2a09:	48 8b 05 d8 52 3f 00 	mov    0x3f52d8(%rip),%rax        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f2a10:	ff d0                	call   *%rax
  6f2a12:	4c 8b 6c 24 38       	mov    0x38(%rsp),%r13
  6f2a17:	4e 89 bc eb d8 04 00 	mov    %r15,0x4d8(%rbx,%r13,8)
  6f2a1e:	00 
  6f2a1f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f2a24:	48 8d b0 d8 04 00 00 	lea    0x4d8(%rax),%rsi
  6f2a2b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f2a30:	48 8d bc c3 d8 04 00 	lea    0x4d8(%rbx,%rax,8),%rdi
  6f2a37:	00 
  6f2a38:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f2a3d:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f2a44:	4c 8b 3d a5 52 3f 00 	mov    0x3f52a5(%rip),%r15        # ae7cf0 <memcpy@GLIBC_2.14>
  6f2a4b:	41 ff d7             	call   *%r15
  6f2a4e:	49 6b c4 70          	imul   $0x70,%r12,%rax
  6f2a52:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f2a56:	41 0f 10 44 06 60    	movups 0x60(%r14,%rax,1),%xmm0
  6f2a5c:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  6f2a63:	00 
  6f2a64:	41 0f 10 44 06 50    	movups 0x50(%r14,%rax,1),%xmm0
  6f2a6a:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  6f2a71:	00 
  6f2a72:	41 0f 10 44 06 40    	movups 0x40(%r14,%rax,1),%xmm0
  6f2a78:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f2a7f:	00 
  6f2a80:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f2a85:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f2a8b:	41 0f 10 54 06 20    	movups 0x20(%r14,%rax,1),%xmm2
  6f2a91:	41 0f 10 5c 06 30    	movups 0x30(%r14,%rax,1),%xmm3
  6f2a97:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
  6f2a9e:	00 
  6f2a9f:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
  6f2aa6:	00 
  6f2aa7:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  6f2aac:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6f2ab1:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f2ab5:	48 83 c6 70          	add    $0x70,%rsi
  6f2ab9:	48 6b d5 70          	imul   $0x70,%rbp,%rdx
  6f2abd:	4c 8b 3d 24 52 3f 00 	mov    0x3f5224(%rip),%r15        # ae7ce8 <memmove@GLIBC_2.2.5>
  6f2ac4:	41 ff d7             	call   *%r15
  6f2ac7:	49 6b c5 70          	imul   $0x70,%r13,%rax
  6f2acb:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6f2ad0:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6f2ad5:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
  6f2adc:	00 
  6f2add:	0f 28 9c 24 90 00 00 	movaps 0x90(%rsp),%xmm3
  6f2ae4:	00 
  6f2ae5:	0f 11 04 03          	movups %xmm0,(%rbx,%rax,1)
  6f2ae9:	0f 11 4c 03 10       	movups %xmm1,0x10(%rbx,%rax,1)
  6f2aee:	0f 11 54 03 20       	movups %xmm2,0x20(%rbx,%rax,1)
  6f2af3:	0f 11 5c 03 30       	movups %xmm3,0x30(%rbx,%rax,1)
  6f2af8:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6f2aff:	00 
  6f2b00:	0f 11 44 03 40       	movups %xmm0,0x40(%rbx,%rax,1)
  6f2b05:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
  6f2b0c:	00 
  6f2b0d:	0f 11 44 03 50       	movups %xmm0,0x50(%rbx,%rax,1)
  6f2b12:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  6f2b19:	00 
  6f2b1a:	0f 11 44 03 60       	movups %xmm0,0x60(%rbx,%rax,1)
  6f2b1f:	48 6b 7c 24 10 70    	imul   $0x70,0x10(%rsp),%rdi
  6f2b25:	48 01 df             	add    %rbx,%rdi
  6f2b28:	48 6b 54 24 18 70    	imul   $0x70,0x18(%rsp),%rdx
  6f2b2e:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6f2b33:	ff 15 b7 51 3f 00    	call   *0x3f51b7(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  6f2b39:	49 8d 6c 24 01       	lea    0x1(%r12),%rbp
  6f2b3e:	4b 8d 3c e6          	lea    (%r14,%r12,8),%rdi
  6f2b42:	48 81 c7 40 05 00 00 	add    $0x540,%rdi
  6f2b49:	4b 8d 34 e6          	lea    (%r14,%r12,8),%rsi
  6f2b4d:	48 81 c6 48 05 00 00 	add    $0x548,%rsi
  6f2b54:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
  6f2b5b:	00 
  6f2b5c:	41 ff d7             	call   *%r15
  6f2b5f:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  6f2b66:	00 
  6f2b67:	48 39 ee             	cmp    %rbp,%rsi
  6f2b6a:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6f2b6f:	0f 86 c5 00 00 00    	jbe    6f2c3a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f2b75:	89 f1                	mov    %esi,%ecx
  6f2b77:	29 e9                	sub    %ebp,%ecx
  6f2b79:	83 e1 03             	and    $0x3,%ecx
  6f2b7c:	0f 84 ee 01 00 00    	je     6f2d70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x860>
  6f2b82:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f2b89:	1f 84 00 00 00 00 00 
  6f2b90:	48 8d 45 01          	lea    0x1(%rbp),%rax
  6f2b94:	49 8b 94 ee 38 05 00 	mov    0x538(%r14,%rbp,8),%rdx
  6f2b9b:	00 
  6f2b9c:	4c 89 b2 d0 04 00 00 	mov    %r14,0x4d0(%rdx)
  6f2ba3:	66 89 aa 30 05 00 00 	mov    %bp,0x530(%rdx)
  6f2baa:	48 89 c5             	mov    %rax,%rbp
  6f2bad:	48 ff c9             	dec    %rcx
  6f2bb0:	75 de                	jne    6f2b90 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x680>
  6f2bb2:	49 f7 dc             	neg    %r12
  6f2bb5:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
  6f2bb9:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f2bbd:	83 f9 03             	cmp    $0x3,%ecx
  6f2bc0:	72 78                	jb     6f2c3a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f2bc2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f2bc9:	1f 84 00 00 00 00 00 
  6f2bd0:	49 8b 8c c6 38 05 00 	mov    0x538(%r14,%rax,8),%rcx
  6f2bd7:	00 
  6f2bd8:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f2bdf:	66 89 81 30 05 00 00 	mov    %ax,0x530(%rcx)
  6f2be6:	49 8b 8c c6 40 05 00 	mov    0x540(%r14,%rax,8),%rcx
  6f2bed:	00 
  6f2bee:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f2bf5:	8d 50 01             	lea    0x1(%rax),%edx
  6f2bf8:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2bff:	49 8b 8c c6 48 05 00 	mov    0x548(%r14,%rax,8),%rcx
  6f2c06:	00 
  6f2c07:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f2c0e:	8d 50 02             	lea    0x2(%rax),%edx
  6f2c11:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2c18:	49 8b 8c c6 50 05 00 	mov    0x550(%r14,%rax,8),%rcx
  6f2c1f:	00 
  6f2c20:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f2c27:	8d 50 03             	lea    0x3(%rax),%edx
  6f2c2a:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2c31:	48 83 c0 04          	add    $0x4,%rax
  6f2c35:	48 39 f0             	cmp    %rsi,%rax
  6f2c38:	75 96                	jne    6f2bd0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x6c0>
  6f2c3a:	66 41 ff 8e 32 05 00 	decw   0x532(%r14)
  6f2c41:	00 
  6f2c42:	be 38 05 00 00       	mov    $0x538,%esi
  6f2c47:	4c 8b a4 24 f8 00 00 	mov    0xf8(%rsp),%r12
  6f2c4e:	00 
  6f2c4f:	49 83 fc 02          	cmp    $0x2,%r12
  6f2c53:	48 8b ac 24 d8 00 00 	mov    0xd8(%rsp),%rbp
  6f2c5a:	00 
  6f2c5b:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  6f2c60:	0f 82 ea fb ff ff    	jb     6f2850 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f2c66:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6f2c6b:	48 ff c2             	inc    %rdx
  6f2c6e:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6f2c73:	48 2b 44 24 38       	sub    0x38(%rsp),%rax
  6f2c78:	48 39 c2             	cmp    %rax,%rdx
  6f2c7b:	0f 85 a7 01 00 00    	jne    6f2e28 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x918>
  6f2c81:	48 8d 83 38 05 00 00 	lea    0x538(%rbx),%rax
  6f2c88:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  6f2c8d:	4a 8d 3c f8          	lea    (%rax,%r15,8),%rdi
  6f2c91:	49 8d b5 38 05 00 00 	lea    0x538(%r13),%rsi
  6f2c98:	c1 e2 03             	shl    $0x3,%edx
  6f2c9b:	ff 15 4f 50 3f 00    	call   *0x3f504f(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  6f2ca1:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f2ca6:	89 f9                	mov    %edi,%ecx
  6f2ca8:	44 29 f9             	sub    %r15d,%ecx
  6f2cab:	ff c1                	inc    %ecx
  6f2cad:	4c 89 f8             	mov    %r15,%rax
  6f2cb0:	83 e1 03             	and    $0x3,%ecx
  6f2cb3:	74 2d                	je     6f2ce2 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7d2>
  6f2cb5:	4c 89 fa             	mov    %r15,%rdx
  6f2cb8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f2cbf:	00 
  6f2cc0:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f2cc4:	48 8b b4 d3 38 05 00 	mov    0x538(%rbx,%rdx,8),%rsi
  6f2ccb:	00 
  6f2ccc:	48 89 9e d0 04 00 00 	mov    %rbx,0x4d0(%rsi)
  6f2cd3:	66 89 96 30 05 00 00 	mov    %dx,0x530(%rsi)
  6f2cda:	48 89 c2             	mov    %rax,%rdx
  6f2cdd:	48 ff c9             	dec    %rcx
  6f2ce0:	75 de                	jne    6f2cc0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7b0>
  6f2ce2:	48 89 f9             	mov    %rdi,%rcx
  6f2ce5:	4c 29 f9             	sub    %r15,%rcx
  6f2ce8:	be 98 05 00 00       	mov    $0x598,%esi
  6f2ced:	83 f9 03             	cmp    $0x3,%ecx
  6f2cf0:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6f2cf5:	0f 82 55 fb ff ff    	jb     6f2850 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f2cfb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f2d00:	48 8b 8c c3 38 05 00 	mov    0x538(%rbx,%rax,8),%rcx
  6f2d07:	00 
  6f2d08:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f2d0f:	66 89 81 30 05 00 00 	mov    %ax,0x530(%rcx)
  6f2d16:	48 8b 8c c3 40 05 00 	mov    0x540(%rbx,%rax,8),%rcx
  6f2d1d:	00 
  6f2d1e:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f2d25:	8d 50 01             	lea    0x1(%rax),%edx
  6f2d28:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2d2f:	48 8b 8c c3 48 05 00 	mov    0x548(%rbx,%rax,8),%rcx
  6f2d36:	00 
  6f2d37:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f2d3e:	8d 50 02             	lea    0x2(%rax),%edx
  6f2d41:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2d48:	48 8b 8c c3 50 05 00 	mov    0x550(%rbx,%rax,8),%rcx
  6f2d4f:	00 
  6f2d50:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f2d57:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f2d5b:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2d62:	48 83 c0 04          	add    $0x4,%rax
  6f2d66:	48 39 fa             	cmp    %rdi,%rdx
  6f2d69:	75 95                	jne    6f2d00 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7f0>
  6f2d6b:	e9 e0 fa ff ff       	jmp    6f2850 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f2d70:	48 89 e8             	mov    %rbp,%rax
  6f2d73:	49 f7 dc             	neg    %r12
  6f2d76:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
  6f2d7a:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f2d7e:	83 f9 03             	cmp    $0x3,%ecx
  6f2d81:	0f 83 49 fe ff ff    	jae    6f2bd0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x6c0>
  6f2d87:	e9 ae fe ff ff       	jmp    6f2c3a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f2d8c:	48 85 c0             	test   %rax,%rax
  6f2d8f:	0f 85 e9 f9 ff ff    	jne    6f277e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2d95:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
  6f2d9c:	00 
  6f2d9d:	49 8b 1e             	mov    (%r14),%rbx
  6f2da0:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f2da7:	48 85 db             	test   %rbx,%rbx
  6f2daa:	0f 84 aa 00 00 00    	je     6f2e5a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x94a>
  6f2db0:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f2db4:	48 85 c0             	test   %rax,%rax
  6f2db7:	0f 84 ac 00 00 00    	je     6f2e69 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x959>
  6f2dbd:	48 8b 3b             	mov    (%rbx),%rdi
  6f2dc0:	48 8b 8f 38 05 00 00 	mov    0x538(%rdi),%rcx
  6f2dc7:	48 89 0b             	mov    %rcx,(%rbx)
  6f2dca:	48 ff c8             	dec    %rax
  6f2dcd:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f2dd1:	48 c7 81 d0 04 00 00 	movq   $0x0,0x4d0(%rcx)
  6f2dd8:	00 00 00 00 
  6f2ddc:	be 98 05 00 00       	mov    $0x598,%esi
  6f2de1:	ba 08 00 00 00       	mov    $0x8,%edx
  6f2de6:	ff 15 dc 4e 3f 00    	call   *0x3f4edc(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  6f2dec:	49 89 1e             	mov    %rbx,(%r14)
  6f2def:	e9 8a f9 ff ff       	jmp    6f277e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2df4:	be 05 00 00 00       	mov    $0x5,%esi
  6f2df9:	48 29 c6             	sub    %rax,%rsi
  6f2dfc:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  6f2e03:	00 
  6f2e04:	e8 87 0c 00 00       	call   6f3a90 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2e09:	e9 70 f9 ff ff       	jmp    6f277e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2e0e:	be 05 00 00 00       	mov    $0x5,%esi
  6f2e13:	48 29 c6             	sub    %rax,%rsi
  6f2e16:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
  6f2e1d:	00 
  6f2e1e:	e8 ad 10 00 00       	call   6f3ed0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2e23:	e9 56 f9 ff ff       	jmp    6f277e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2e28:	be 28 00 00 00       	mov    $0x28,%esi
  6f2e2d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6f2e32:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  6f2e37:	ff 15 c3 4e 3f 00    	call   *0x3f4ec3(%rip)        # ae7d00 <_DYNAMIC+0x280>
  6f2e3d:	eb 28                	jmp    6f2e67 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x957>
  6f2e3f:	48 8d 3d 83 08 97 ff 	lea    -0x68f77d(%rip),%rdi        # 636c9 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f2e46:	48 8d 15 5b 6b 3c 00 	lea    0x3c6b5b(%rip),%rdx        # ab99a8 <__frame_dummy_init_array_entry+0x1a0>
  6f2e4d:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f2e52:	ff 15 c8 4e 3f 00    	call   *0x3f4ec8(%rip)        # ae7d20 <_DYNAMIC+0x2a0>
  6f2e58:	eb 0d                	jmp    6f2e67 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x957>
  6f2e5a:	48 8d 3d 57 6a 3c 00 	lea    0x3c6a57(%rip),%rdi        # ab98b8 <__frame_dummy_init_array_entry+0xb0>
  6f2e61:	ff 15 a1 4e 3f 00    	call   *0x3f4ea1(%rip)        # ae7d08 <_DYNAMIC+0x288>
  6f2e67:	0f 0b                	ud2
  6f2e69:	48 8d 05 18 6a 3c 00 	lea    0x3c6a18(%rip),%rax        # ab9888 <__frame_dummy_init_array_entry+0x80>
  6f2e70:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f2e75:	be 21 00 00 00       	mov    $0x21,%esi
  6f2e7a:	48 8d 05 0a 07 97 ff 	lea    -0x68f8f6(%rip),%rax        # 6358b <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f2e81:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f2e86:	eb a5                	jmp    6f2e2d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x91d>
  6f2e88:	48 89 c3             	mov    %rax,%rbx
  6f2e8b:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  6f2e92:	00 
  6f2e93:	e8 48 4c 02 00       	call   717ae0 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2e98:	48 89 df             	mov    %rbx,%rdi
  6f2e9b:	e8 b0 55 3c 00       	call   ab8450 <_Unwind_Resume@plt>
  6f2ea0:	ff 15 72 4e 3f 00    	call   *0x3f4e72(%rip)        # ae7d18 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
