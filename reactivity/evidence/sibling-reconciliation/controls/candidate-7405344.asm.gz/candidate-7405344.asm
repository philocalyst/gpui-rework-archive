
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000070ff20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_>:
  70ff20:	41 57                	push   %r15
  70ff22:	41 56                	push   %r14
  70ff24:	41 55                	push   %r13
  70ff26:	41 54                	push   %r12
  70ff28:	53                   	push   %rbx
  70ff29:	48 81 ec 90 04 00 00 	sub    $0x490,%rsp
  70ff30:	48 83 fe 02          	cmp    $0x2,%rsi
  70ff34:	0f 82 6a 04 00 00    	jb     7103a4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x484>
  70ff3a:	49 89 f6             	mov    %rsi,%r14
  70ff3d:	48 83 fe 20          	cmp    $0x20,%rsi
  70ff41:	0f 87 af 04 00 00    	ja     7103f6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x4d6>
  70ff47:	48 89 fb             	mov    %rdi,%rbx
  70ff4a:	4c 89 f0             	mov    %r14,%rax
  70ff4d:	48 d1 e8             	shr    $1,%rax
  70ff50:	49 83 fe 07          	cmp    $0x7,%r14
  70ff54:	0f 86 ba 01 00 00    	jbe    710114 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x1f4>
  70ff5a:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
  70ff5e:	48 8b 53 48          	mov    0x48(%rbx),%rdx
  70ff62:	45 31 c0             	xor    %r8d,%r8d
  70ff65:	31 f6                	xor    %esi,%esi
  70ff67:	48 3b 0b             	cmp    (%rbx),%rcx
  70ff6a:	41 0f 93 c0          	setae  %r8b
  70ff6e:	40 0f 92 c6          	setb   %sil
  70ff72:	48 8d 7b 48          	lea    0x48(%rbx),%rdi
  70ff76:	4c 8d 4b 30          	lea    0x30(%rbx),%r9
  70ff7a:	48 3b 53 30          	cmp    0x30(%rbx),%rdx
  70ff7e:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  70ff82:	4a 8d 34 d3          	lea    (%rbx,%r10,8),%rsi
  70ff86:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  70ff8a:	4c 89 ca             	mov    %r9,%rdx
  70ff8d:	48 0f 42 d7          	cmovb  %rdi,%rdx
  70ff91:	4a 8d 0c c3          	lea    (%rbx,%r8,8),%rcx
  70ff95:	49 0f 42 f9          	cmovb  %r9,%rdi
  70ff99:	4c 8b 0a             	mov    (%rdx),%r9
  70ff9c:	4c 8b 1f             	mov    (%rdi),%r11
  70ff9f:	4e 8b 04 c3          	mov    (%rbx,%r8,8),%r8
  70ffa3:	4d 39 c3             	cmp    %r8,%r11
  70ffa6:	49 89 cf             	mov    %rcx,%r15
  70ffa9:	4c 0f 42 fa          	cmovb  %rdx,%r15
  70ffad:	4e 3b 0c d3          	cmp    (%rbx,%r10,8),%r9
  70ffb1:	4c 0f 42 fe          	cmovb  %rsi,%r15
  70ffb5:	48 0f 42 f2          	cmovb  %rdx,%rsi
  70ffb9:	48 0f 42 d1          	cmovb  %rcx,%rdx
  70ffbd:	4d 39 c3             	cmp    %r8,%r11
  70ffc0:	48 0f 43 cf          	cmovae %rdi,%rcx
  70ffc4:	48 0f 42 d7          	cmovb  %rdi,%rdx
  70ffc8:	48 8b 3a             	mov    (%rdx),%rdi
  70ffcb:	49 3b 3f             	cmp    (%r15),%rdi
  70ffce:	4c 89 ff             	mov    %r15,%rdi
  70ffd1:	48 0f 42 fa          	cmovb  %rdx,%rdi
  70ffd5:	49 0f 42 d7          	cmovb  %r15,%rdx
  70ffd9:	4c 8b 46 10          	mov    0x10(%rsi),%r8
  70ffdd:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
  70ffe2:	0f 10 06             	movups (%rsi),%xmm0
  70ffe5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  70ffea:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  70ffee:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  70fff3:	0f 10 07             	movups (%rdi),%xmm0
  70fff6:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
  70fffb:	48 8b 72 10          	mov    0x10(%rdx),%rsi
  70ffff:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  710004:	0f 10 02             	movups (%rdx),%xmm0
  710007:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  71000c:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
  710013:	00 
  710014:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  710018:	4c 8d 0c 13          	lea    (%rbx,%rdx,1),%r9
  71001c:	48 8b 74 13 18       	mov    0x18(%rbx,%rdx,1),%rsi
  710021:	48 8b 7c 13 48       	mov    0x48(%rbx,%rdx,1),%rdi
  710026:	45 31 d2             	xor    %r10d,%r10d
  710029:	45 31 db             	xor    %r11d,%r11d
  71002c:	48 3b 34 13          	cmp    (%rbx,%rdx,1),%rsi
  710030:	41 0f 93 c2          	setae  %r10b
  710034:	41 0f 92 c3          	setb   %r11b
  710038:	4c 8d 04 13          	lea    (%rbx,%rdx,1),%r8
  71003c:	49 83 c0 48          	add    $0x48,%r8
  710040:	4c 8d 3c 13          	lea    (%rbx,%rdx,1),%r15
  710044:	49 83 c7 30          	add    $0x30,%r15
  710048:	48 3b 7c 13 30       	cmp    0x30(%rbx,%rdx,1),%rdi
  71004d:	4f 8d 1c 5b          	lea    (%r11,%r11,2),%r11
  710051:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  710055:	4b 8d 34 d1          	lea    (%r9,%r10,8),%rsi
  710059:	4c 89 ff             	mov    %r15,%rdi
  71005c:	49 0f 42 f8          	cmovb  %r8,%rdi
  710060:	4d 0f 42 c7          	cmovb  %r15,%r8
  710064:	4d 8b 38             	mov    (%r8),%r15
  710067:	4f 8b 14 d1          	mov    (%r9,%r10,8),%r10
  71006b:	4d 39 d7             	cmp    %r10,%r15
  71006e:	49 89 f4             	mov    %rsi,%r12
  710071:	4c 0f 42 e7          	cmovb  %rdi,%r12
  710075:	4c 8b 2f             	mov    (%rdi),%r13
  710078:	4f 3b 2c d9          	cmp    (%r9,%r11,8),%r13
  71007c:	4f 8d 0c d9          	lea    (%r9,%r11,8),%r9
  710080:	4d 0f 42 e1          	cmovb  %r9,%r12
  710084:	4c 0f 42 cf          	cmovb  %rdi,%r9
  710088:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  71008c:	48 0f 42 fe          	cmovb  %rsi,%rdi
  710090:	4d 39 d7             	cmp    %r10,%r15
  710093:	49 0f 43 f0          	cmovae %r8,%rsi
  710097:	49 0f 42 f8          	cmovb  %r8,%rdi
  71009b:	4c 89 5c 24 68       	mov    %r11,0x68(%rsp)
  7100a0:	4c 8b 07             	mov    (%rdi),%r8
  7100a3:	4d 3b 04 24          	cmp    (%r12),%r8
  7100a7:	0f 10 01             	movups (%rcx),%xmm0
  7100aa:	4c 89 e1             	mov    %r12,%rcx
  7100ad:	48 0f 42 cf          	cmovb  %rdi,%rcx
  7100b1:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
  7100b6:	49 0f 42 fc          	cmovb  %r12,%rdi
  7100ba:	4d 8b 41 10          	mov    0x10(%r9),%r8
  7100be:	4c 89 44 14 20       	mov    %r8,0x20(%rsp,%rdx,1)
  7100c3:	41 0f 10 01          	movups (%r9),%xmm0
  7100c7:	0f 11 44 14 10       	movups %xmm0,0x10(%rsp,%rdx,1)
  7100cc:	0f 10 01             	movups (%rcx),%xmm0
  7100cf:	0f 11 44 14 28       	movups %xmm0,0x28(%rsp,%rdx,1)
  7100d4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
  7100d8:	48 89 4c 14 38       	mov    %rcx,0x38(%rsp,%rdx,1)
  7100dd:	0f 10 07             	movups (%rdi),%xmm0
  7100e0:	0f 11 44 14 40       	movups %xmm0,0x40(%rsp,%rdx,1)
  7100e5:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
  7100e9:	48 89 4c 14 50       	mov    %rcx,0x50(%rsp,%rdx,1)
  7100ee:	0f 10 06             	movups (%rsi),%xmm0
  7100f1:	0f 11 44 14 58       	movups %xmm0,0x58(%rsp,%rdx,1)
  7100f6:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  7100fa:	48 89 4c 14 68       	mov    %rcx,0x68(%rsp,%rdx,1)
  7100ff:	ba 04 00 00 00       	mov    $0x4,%edx
  710104:	4c 89 f6             	mov    %r14,%rsi
  710107:	48 29 c6             	sub    %rax,%rsi
  71010a:	48 39 c2             	cmp    %rax,%rdx
  71010d:	72 49                	jb     710158 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x238>
  71010f:	e9 f3 00 00 00       	jmp    710207 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x2e7>
  710114:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
  710118:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  71011d:	0f 10 03             	movups (%rbx),%xmm0
  710120:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  710125:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
  71012c:	00 
  71012d:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  710131:	48 8b 54 0b 10       	mov    0x10(%rbx,%rcx,1),%rdx
  710136:	48 89 54 0c 20       	mov    %rdx,0x20(%rsp,%rcx,1)
  71013b:	0f 10 04 0b          	movups (%rbx,%rcx,1),%xmm0
  71013f:	0f 11 44 0c 10       	movups %xmm0,0x10(%rsp,%rcx,1)
  710144:	ba 01 00 00 00       	mov    $0x1,%edx
  710149:	4c 89 f6             	mov    %r14,%rsi
  71014c:	48 29 c6             	sub    %rax,%rsi
  71014f:	48 39 c2             	cmp    %rax,%rdx
  710152:	0f 83 af 00 00 00    	jae    710207 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x2e7>
  710158:	8d 0c d5 00 00 00 00 	lea    0x0(,%rdx,8),%ecx
  71015f:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  710163:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  710168:	49 89 d0             	mov    %rdx,%r8
  71016b:	eb 1e                	jmp    71018b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x26b>
  71016d:	0f 1f 00             	nopl   (%rax)
  710170:	49 89 fa             	mov    %rdi,%r10
  710173:	4d 89 0a             	mov    %r9,(%r10)
  710176:	0f 28 04 24          	movaps (%rsp),%xmm0
  71017a:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  71017f:	49 ff c0             	inc    %r8
  710182:	48 83 c1 18          	add    $0x18,%rcx
  710186:	49 39 c0             	cmp    %rax,%r8
  710189:	74 7c                	je     710207 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x2e7>
  71018b:	4e 8d 0c c5 00 00 00 	lea    0x0(,%r8,8),%r9
  710192:	00 
  710193:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  710197:	42 0f 10 04 13       	movups (%rbx,%r10,1),%xmm0
  71019c:	42 0f 11 44 14 10    	movups %xmm0,0x10(%rsp,%r10,1)
  7101a2:	4e 8b 4c 13 10       	mov    0x10(%rbx,%r10,1),%r9
  7101a7:	4e 89 4c 14 20       	mov    %r9,0x20(%rsp,%r10,1)
  7101ac:	4e 8b 4c 14 10       	mov    0x10(%rsp,%r10,1),%r9
  7101b1:	4e 3b 4c 14 f8       	cmp    -0x8(%rsp,%r10,1),%r9
  7101b6:	73 c7                	jae    71017f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x25f>
  7101b8:	49 01 da             	add    %rbx,%r10
  7101bb:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  7101c0:	0f 29 04 24          	movaps %xmm0,(%rsp)
  7101c4:	49 89 ca             	mov    %rcx,%r10
  7101c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  7101ce:	00 00 
  7101d0:	4e 8b 5c 14 08       	mov    0x8(%rsp,%r10,1),%r11
  7101d5:	4e 89 5c 14 20       	mov    %r11,0x20(%rsp,%r10,1)
  7101da:	42 0f 10 44 14 f8    	movups -0x8(%rsp,%r10,1),%xmm0
  7101e0:	42 0f 11 44 14 10    	movups %xmm0,0x10(%rsp,%r10,1)
  7101e6:	49 83 fa 18          	cmp    $0x18,%r10
  7101ea:	74 84                	je     710170 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x250>
  7101ec:	4d 8d 5a e8          	lea    -0x18(%r10),%r11
  7101f0:	4e 3b 4c 14 e0       	cmp    -0x20(%rsp,%r10,1),%r9
  7101f5:	4d 89 da             	mov    %r11,%r10
  7101f8:	72 d6                	jb     7101d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x2b0>
  7101fa:	4e 8d 14 1c          	lea    (%rsp,%r11,1),%r10
  7101fe:	49 83 c2 10          	add    $0x10,%r10
  710202:	e9 6c ff ff ff       	jmp    710173 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x253>
  710207:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
  71020e:	00 
  71020f:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
  710213:	48 8d 0c 3c          	lea    (%rsp,%rdi,1),%rcx
  710217:	48 83 c1 10          	add    $0x10,%rcx
  71021b:	48 39 f2             	cmp    %rsi,%rdx
  71021e:	0f 83 ad 00 00 00    	jae    7102d1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x3b1>
  710224:	48 01 df             	add    %rbx,%rdi
  710227:	44 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%r8d
  71022e:	00 
  71022f:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  710233:	eb 26                	jmp    71025b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x33b>
  710235:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71023c:	00 00 00 00 
  710240:	49 89 ca             	mov    %rcx,%r10
  710243:	4d 89 0a             	mov    %r9,(%r10)
  710246:	0f 28 04 24          	movaps (%rsp),%xmm0
  71024a:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  71024f:	48 ff c2             	inc    %rdx
  710252:	49 83 c0 18          	add    $0x18,%r8
  710256:	48 39 f2             	cmp    %rsi,%rdx
  710259:	74 76                	je     7102d1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x3b1>
  71025b:	4c 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%r9
  710262:	00 
  710263:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  710267:	42 0f 10 04 17       	movups (%rdi,%r10,1),%xmm0
  71026c:	42 0f 11 04 11       	movups %xmm0,(%rcx,%r10,1)
  710271:	4e 8b 4c 17 10       	mov    0x10(%rdi,%r10,1),%r9
  710276:	4e 89 4c 11 10       	mov    %r9,0x10(%rcx,%r10,1)
  71027b:	4e 8b 0c 11          	mov    (%rcx,%r10,1),%r9
  71027f:	4e 3b 4c 11 e8       	cmp    -0x18(%rcx,%r10,1),%r9
  710284:	73 c9                	jae    71024f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x32f>
  710286:	49 01 fa             	add    %rdi,%r10
  710289:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  71028e:	0f 29 04 24          	movaps %xmm0,(%rsp)
  710292:	4d 89 c3             	mov    %r8,%r11
  710295:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71029c:	00 00 00 00 
  7102a0:	4e 8b 54 19 f8       	mov    -0x8(%rcx,%r11,1),%r10
  7102a5:	4e 89 54 19 10       	mov    %r10,0x10(%rcx,%r11,1)
  7102aa:	42 0f 10 44 19 e8    	movups -0x18(%rcx,%r11,1),%xmm0
  7102b0:	42 0f 11 04 19       	movups %xmm0,(%rcx,%r11,1)
  7102b5:	49 83 fb 18          	cmp    $0x18,%r11
  7102b9:	74 85                	je     710240 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x320>
  7102bb:	4d 8d 53 e8          	lea    -0x18(%r11),%r10
  7102bf:	4e 3b 4c 19 d0       	cmp    -0x30(%rcx,%r11,1),%r9
  7102c4:	4d 89 d3             	mov    %r10,%r11
  7102c7:	72 d7                	jb     7102a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x380>
  7102c9:	49 01 ca             	add    %rcx,%r10
  7102cc:	e9 72 ff ff ff       	jmp    710243 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x323>
  7102d1:	4b 8d 14 76          	lea    (%r14,%r14,2),%rdx
  7102d5:	4c 8d 0c d3          	lea    (%rbx,%rdx,8),%r9
  7102d9:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  7102dd:	48 8d 34 d4          	lea    (%rsp,%rdx,8),%rsi
  7102e1:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
  7102e5:	48 8d 51 e8          	lea    -0x18(%rcx),%rdx
  7102e9:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  7102ee:	49 89 d8             	mov    %rbx,%r8
  7102f1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7102f8:	0f 1f 84 00 00 00 00 
  7102ff:	00 
  710300:	49 89 ca             	mov    %rcx,%r10
  710303:	49 89 fb             	mov    %rdi,%r11
  710306:	48 8b 39             	mov    (%rcx),%rdi
  710309:	48 83 c1 18          	add    $0x18,%rcx
  71030d:	49 3b 3b             	cmp    (%r11),%rdi
  710310:	49 8d 7b 18          	lea    0x18(%r11),%rdi
  710314:	49 0f 42 fb          	cmovb  %r11,%rdi
  710318:	4d 0f 42 da          	cmovb  %r10,%r11
  71031c:	4d 8b 7b 10          	mov    0x10(%r11),%r15
  710320:	4d 89 78 10          	mov    %r15,0x10(%r8)
  710324:	49 0f 43 ca          	cmovae %r10,%rcx
  710328:	4c 8b 16             	mov    (%rsi),%r10
  71032b:	4c 8b 3a             	mov    (%rdx),%r15
  71032e:	4d 39 fa             	cmp    %r15,%r10
  710331:	41 bc 00 00 00 00    	mov    $0x0,%r12d
  710337:	49 83 d4 ff          	adc    $0xffffffffffffffff,%r12
  71033b:	4d 39 fa             	cmp    %r15,%r10
  71033e:	49 89 f2             	mov    %rsi,%r10
  710341:	4c 0f 42 d2          	cmovb  %rdx,%r10
  710345:	41 0f 10 03          	movups (%r11),%xmm0
  710349:	41 bb 00 00 00 00    	mov    $0x0,%r11d
  71034f:	4d 19 db             	sbb    %r11,%r11
  710352:	41 0f 11 00          	movups %xmm0,(%r8)
  710356:	49 83 c0 18          	add    $0x18,%r8
  71035a:	4d 8b 7a 10          	mov    0x10(%r10),%r15
  71035e:	4d 89 79 10          	mov    %r15,0x10(%r9)
  710362:	41 0f 10 02          	movups (%r10),%xmm0
  710366:	41 0f 11 01          	movups %xmm0,(%r9)
  71036a:	4f 8d 14 64          	lea    (%r12,%r12,2),%r10
  71036e:	4a 8d 34 d6          	lea    (%rsi,%r10,8),%rsi
  710372:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
  710376:	4a 8d 14 d2          	lea    (%rdx,%r10,8),%rdx
  71037a:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  71037e:	48 ff c8             	dec    %rax
  710381:	0f 85 79 ff ff ff    	jne    710300 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x3e0>
  710387:	48 83 c2 18          	add    $0x18,%rdx
  71038b:	48 83 c6 18          	add    $0x18,%rsi
  71038f:	41 f6 c6 01          	test   $0x1,%r14b
  710393:	75 20                	jne    7103b5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x495>
  710395:	48 39 f1             	cmp    %rsi,%rcx
  710398:	0f 95 c0             	setne  %al
  71039b:	48 39 d7             	cmp    %rdx,%rdi
  71039e:	75 4a                	jne    7103ea <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x4ca>
  7103a0:	84 c0                	test   %al,%al
  7103a2:	75 4c                	jne    7103f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x4d0>
  7103a4:	48 81 c4 90 04 00 00 	add    $0x490,%rsp
  7103ab:	5b                   	pop    %rbx
  7103ac:	41 5c                	pop    %r12
  7103ae:	41 5d                	pop    %r13
  7103b0:	41 5e                	pop    %r14
  7103b2:	41 5f                	pop    %r15
  7103b4:	c3                   	ret
  7103b5:	48 8d 47 18          	lea    0x18(%rdi),%rax
  7103b9:	4c 8d 49 18          	lea    0x18(%rcx),%r9
  7103bd:	48 39 d7             	cmp    %rdx,%rdi
  7103c0:	49 89 ca             	mov    %rcx,%r10
  7103c3:	4c 0f 42 d7          	cmovb  %rdi,%r10
  7103c7:	4d 8b 5a 10          	mov    0x10(%r10),%r11
  7103cb:	4d 89 58 10          	mov    %r11,0x10(%r8)
  7103cf:	41 0f 10 02          	movups (%r10),%xmm0
  7103d3:	41 0f 11 00          	movups %xmm0,(%r8)
  7103d7:	48 0f 42 f8          	cmovb  %rax,%rdi
  7103db:	49 0f 43 c9          	cmovae %r9,%rcx
  7103df:	48 39 f1             	cmp    %rsi,%rcx
  7103e2:	0f 95 c0             	setne  %al
  7103e5:	48 39 d7             	cmp    %rdx,%rdi
  7103e8:	74 b6                	je     7103a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x480>
  7103ea:	b0 01                	mov    $0x1,%al
  7103ec:	84 c0                	test   %al,%al
  7103ee:	74 b4                	je     7103a4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x484>
  7103f0:	ff 15 62 7d 3d 00    	call   *0x3d7d62(%rip)        # ae8158 <_DYNAMIC+0x6d8>
  7103f6:	0f 0b                	ud2
  7103f8:	49 89 c7             	mov    %rax,%r15
  7103fb:	49 c1 e6 03          	shl    $0x3,%r14
  7103ff:	4b 8d 14 76          	lea    (%r14,%r14,2),%rdx
  710403:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  710408:	48 89 df             	mov    %rbx,%rdi
  71040b:	ff 15 df 78 3d 00    	call   *0x3d78df(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  710411:	4c 89 ff             	mov    %r15,%rdi
  710414:	e8 37 80 3a 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
