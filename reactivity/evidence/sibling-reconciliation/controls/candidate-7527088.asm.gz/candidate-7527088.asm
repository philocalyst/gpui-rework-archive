
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072dab0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_>:
  72dab0:	48 89 f0             	mov    %rsi,%rax
  72dab3:	48 d1 e8             	shr    $1,%rax
  72dab6:	48 01 f0             	add    %rsi,%rax
  72dab9:	75 0a                	jne    72dac5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x15>
  72dabb:	c3                   	ret
  72dabc:	0f 1f 40 00          	nopl   0x0(%rax)
  72dac0:	48 85 c0             	test   %rax,%rax
  72dac3:	74 f6                	je     72dabb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0xb>
  72dac5:	48 ff c8             	dec    %rax
  72dac8:	48 89 c1             	mov    %rax,%rcx
  72dacb:	48 29 f1             	sub    %rsi,%rcx
  72dace:	73 0c                	jae    72dadc <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x2c>
  72dad0:	8b 0f                	mov    (%rdi),%ecx
  72dad2:	8b 14 87             	mov    (%rdi,%rax,4),%edx
  72dad5:	89 17                	mov    %edx,(%rdi)
  72dad7:	89 0c 87             	mov    %ecx,(%rdi,%rax,4)
  72dada:	31 c9                	xor    %ecx,%ecx
  72dadc:	48 39 c6             	cmp    %rax,%rsi
  72dadf:	48 89 c2             	mov    %rax,%rdx
  72dae2:	48 0f 42 d6          	cmovb  %rsi,%rdx
  72dae6:	4c 8d 04 4d 01 00 00 	lea    0x1(,%rcx,2),%r8
  72daed:	00 
  72daee:	49 39 d0             	cmp    %rdx,%r8
  72daf1:	73 cd                	jae    72dac0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>
  72daf3:	4c 8d 0c 09          	lea    (%rcx,%rcx,1),%r9
  72daf7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72dafe:	00 00 
  72db00:	4d 8d 51 02          	lea    0x2(%r9),%r10
  72db04:	49 39 d2             	cmp    %rdx,%r10
  72db07:	73 0d                	jae    72db16 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x66>
  72db09:	46 8b 14 87          	mov    (%rdi,%r8,4),%r10d
  72db0d:	46 3b 54 8f 08       	cmp    0x8(%rdi,%r9,4),%r10d
  72db12:	49 83 d0 00          	adc    $0x0,%r8
  72db16:	4d 89 c2             	mov    %r8,%r10
  72db19:	44 8b 04 8f          	mov    (%rdi,%rcx,4),%r8d
  72db1d:	46 8b 0c 97          	mov    (%rdi,%r10,4),%r9d
  72db21:	45 39 c8             	cmp    %r9d,%r8d
  72db24:	73 9a                	jae    72dac0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>
  72db26:	44 89 0c 8f          	mov    %r9d,(%rdi,%rcx,4)
  72db2a:	46 89 04 97          	mov    %r8d,(%rdi,%r10,4)
  72db2e:	4f 8d 0c 12          	lea    (%r10,%r10,1),%r9
  72db32:	4e 8d 04 55 01 00 00 	lea    0x1(,%r10,2),%r8
  72db39:	00 
  72db3a:	4c 89 d1             	mov    %r10,%rcx
  72db3d:	49 39 d0             	cmp    %rdx,%r8
  72db40:	72 be                	jb     72db00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x50>
  72db42:	e9 79 ff ff ff       	jmp    72dac0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
