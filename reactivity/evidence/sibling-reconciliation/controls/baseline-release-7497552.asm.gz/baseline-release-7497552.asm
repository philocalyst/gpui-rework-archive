
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000726750 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_>:
  726750:	55                   	push   %rbp
  726751:	41 57                	push   %r15
  726753:	41 56                	push   %r14
  726755:	41 55                	push   %r13
  726757:	41 54                	push   %r12
  726759:	53                   	push   %rbx
  72675a:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
  726761:	48 89 fb             	mov    %rdi,%rbx
  726764:	48 89 34 24          	mov    %rsi,(%rsp)
  726768:	48 89 e0             	mov    %rsp,%rax
  72676b:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  726770:	48 8b 07             	mov    (%rdi),%rax
  726773:	48 85 c0             	test   %rax,%rax
  726776:	74 38                	je     7267b0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0x60>
  726778:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  72677c:	48 85 c9             	test   %rcx,%rcx
  72677f:	0f 84 89 00 00 00    	je     72680e <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0xbe>
  726785:	48 89 ca             	mov    %rcx,%rdx
  726788:	48 83 e2 07          	and    $0x7,%rdx
  72678c:	74 28                	je     7267b6 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0x66>
  72678e:	31 f6                	xor    %esi,%esi
  726790:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  726797:	48 ff c6             	inc    %rsi
  72679a:	48 39 f2             	cmp    %rsi,%rdx
  72679d:	75 f1                	jne    726790 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0x40>
  72679f:	48 89 ca             	mov    %rcx,%rdx
  7267a2:	48 29 f2             	sub    %rsi,%rdx
  7267a5:	48 89 de             	mov    %rbx,%rsi
  7267a8:	48 83 f9 08          	cmp    $0x8,%rcx
  7267ac:	73 22                	jae    7267d0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0x80>
  7267ae:	eb 61                	jmp    726811 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0xc1>
  7267b0:	31 c0                	xor    %eax,%eax
  7267b2:	31 f6                	xor    %esi,%esi
  7267b4:	eb 5b                	jmp    726811 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0xc1>
  7267b6:	48 89 ca             	mov    %rcx,%rdx
  7267b9:	48 89 de             	mov    %rbx,%rsi
  7267bc:	48 83 f9 08          	cmp    $0x8,%rcx
  7267c0:	72 4f                	jb     726811 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0xc1>
  7267c2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7267c9:	1f 84 00 00 00 00 00 
  7267d0:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  7267d7:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  7267de:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  7267e5:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  7267ec:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  7267f3:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  7267fa:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  726801:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  726808:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  72680c:	75 c2                	jne    7267d0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0x80>
  72680e:	48 89 de             	mov    %rbx,%rsi
  726811:	4c 8d 6b 10          	lea    0x10(%rbx),%r13
  726815:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
  72681a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72681f:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  726824:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
  726829:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  72682e:	0f 57 c0             	xorps  %xmm0,%xmm0
  726831:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
  726836:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  72683b:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  726840:	e8 cb 20 ff ff       	call   718910 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>
  726845:	83 7c 24 40 01       	cmpl   $0x1,0x40(%rsp)
  72684a:	75 4f                	jne    72689b <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0x14b>
  72684c:	48 8d 6c 24 48       	lea    0x48(%rsp),%rbp
  726851:	4c 8d 74 24 78       	lea    0x78(%rsp),%r14
  726856:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
  72685b:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
  726860:	48 8b 45 20          	mov    0x20(%rbp),%rax
  726864:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  72686b:	00 
  72686c:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
  726870:	0f 10 4d 10          	movups 0x10(%rbp),%xmm1
  726874:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
  72687b:	00 
  72687c:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  726881:	4c 89 f7             	mov    %r14,%rdi
  726884:	e8 97 0a ff ff       	call   717320 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  726889:	4c 89 ff             	mov    %r15,%rdi
  72688c:	4c 89 e6             	mov    %r12,%rsi
  72688f:	e8 7c 20 ff ff       	call   718910 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>
  726894:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
  726899:	75 c5                	jne    726860 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0x110>
  72689b:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
  7268a0:	75 17                	jne    7268b9 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB1U_+0x169>
  7268a2:	48 89 df             	mov    %rbx,%rdi
  7268a5:	e8 d6 1c ff ff       	call   718580 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB17_13GeometryStyleEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  7268aa:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  7268b1:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  7268b8:	00 
  7268b9:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
  7268c0:	5b                   	pop    %rbx
  7268c1:	41 5c                	pop    %r12
  7268c3:	41 5d                	pop    %r13
  7268c5:	41 5e                	pop    %r14
  7268c7:	41 5f                	pop    %r15
  7268c9:	5d                   	pop    %rbp
  7268ca:	c3                   	ret
  7268cb:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  7268d2:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  7268d9:	00 
  7268da:	48 89 c7             	mov    %rax,%rdi
  7268dd:	e8 be 47 39 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
