
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000071c5e0 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_>:
  71c5e0:	55                   	push   %rbp
  71c5e1:	41 57                	push   %r15
  71c5e3:	41 56                	push   %r14
  71c5e5:	41 55                	push   %r13
  71c5e7:	41 54                	push   %r12
  71c5e9:	53                   	push   %rbx
  71c5ea:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
  71c5f1:	49 89 fd             	mov    %rdi,%r13
  71c5f4:	48 8b 46 10          	mov    0x10(%rsi),%rax
  71c5f8:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  71c5fd:	48 8b 2e             	mov    (%rsi),%rbp
  71c600:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
  71c604:	4c 8b 46 18          	mov    0x18(%rsi),%r8
  71c608:	4c 39 c3             	cmp    %r8,%rbx
  71c60b:	0f 84 fd 00 00 00    	je     71c70e <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x12e>
  71c611:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  71c616:	4c 8b 6e 20          	mov    0x20(%rsi),%r13
  71c61a:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
  71c61f:	4c 8b 35 c2 e2 3c 00 	mov    0x3ce2c2(%rip),%r14        # aea8e8 <memcpy@GLIBC_2.14>
  71c626:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  71c62b:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  71c630:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  71c635:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  71c63a:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
  71c63f:	eb 58                	jmp    71c699 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xb9>
  71c641:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71c648:	0f 1f 84 00 00 00 00 
  71c64f:	00 
  71c650:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71c655:	4d 89 65 00          	mov    %r12,0x0(%r13)
  71c659:	4d 89 7d 08          	mov    %r15,0x8(%r13)
  71c65d:	41 88 6d 10          	mov    %bpl,0x10(%r13)
  71c661:	49 8d 7d 11          	lea    0x11(%r13),%rdi
  71c665:	ba 97 00 00 00       	mov    $0x97,%edx
  71c66a:	48 8d 74 24 41       	lea    0x41(%rsp),%rsi
  71c66f:	41 ff d6             	call   *%r14
  71c672:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  71c679:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  71c67e:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
  71c683:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
  71c688:	4c 39 c3             	cmp    %r8,%rbx
  71c68b:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
  71c690:	4c 8b 35 51 e2 3c 00 	mov    0x3ce251(%rip),%r14        # aea8e8 <memcpy@GLIBC_2.14>
  71c697:	74 5c                	je     71c6f5 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x115>
  71c699:	4c 8b 23             	mov    (%rbx),%r12
  71c69c:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
  71c6a0:	0f b6 6b 10          	movzbl 0x10(%rbx),%ebp
  71c6a4:	48 8d 73 11          	lea    0x11(%rbx),%rsi
  71c6a8:	ba 97 00 00 00       	mov    $0x97,%edx
  71c6ad:	41 ff d6             	call   *%r14
  71c6b0:	48 81 c3 a8 00 00 00 	add    $0xa8,%rbx
  71c6b7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  71c6bc:	48 89 58 08          	mov    %rbx,0x8(%rax)
  71c6c0:	49 83 fc 02          	cmp    $0x2,%r12
  71c6c4:	75 8a                	jne    71c650 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x70>
  71c6c6:	4d 8b 65 10          	mov    0x10(%r13),%r12
  71c6ca:	4d 3b 65 00          	cmp    0x0(%r13),%r12
  71c6ce:	75 08                	jne    71c6d8 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xf8>
  71c6d0:	4c 89 ef             	mov    %r13,%rdi
  71c6d3:	e8 78 1d 01 00       	call   72e450 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecAINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCshBhuxcId5D0_4gpui6source7FieldIdEj2_E8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71c6d8:	49 8b 45 08          	mov    0x8(%r13),%rax
  71c6dc:	4c 89 e1             	mov    %r12,%rcx
  71c6df:	48 c1 e1 04          	shl    $0x4,%rcx
  71c6e3:	4c 89 3c 08          	mov    %r15,(%rax,%rcx,1)
  71c6e7:	40 88 6c 08 08       	mov    %bpl,0x8(%rax,%rcx,1)
  71c6ec:	49 ff c4             	inc    %r12
  71c6ef:	4d 89 65 10          	mov    %r12,0x10(%r13)
  71c6f3:	eb 8e                	jmp    71c683 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xa3>
  71c6f5:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  71c6fa:	48 8b 58 08          	mov    0x8(%rax),%rbx
  71c6fe:	4c 8b 40 18          	mov    0x18(%rax),%r8
  71c702:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  71c707:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
  71c70c:	eb 05                	jmp    71c713 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x133>
  71c70e:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  71c713:	4c 89 c0             	mov    %r8,%rax
  71c716:	48 29 d8             	sub    %rbx,%rax
  71c719:	48 c1 e8 03          	shr    $0x3,%rax
  71c71d:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  71c724:	c3 30 0c 
  71c727:	48 f7 e1             	mul    %rcx
  71c72a:	49 39 d8             	cmp    %rbx,%r8
  71c72d:	74 69                	je     71c798 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x1b8>
  71c72f:	49 89 d4             	mov    %rdx,%r12
  71c732:	48 81 c3 88 00 00 00 	add    $0x88,%rbx
  71c739:	4c 8b 35 80 e1 3c 00 	mov    0x3ce180(%rip),%r14        # aea8c0 <_DYNAMIC+0x248>
  71c740:	eb 1a                	jmp    71c75c <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x17c>
  71c742:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71c749:	1f 84 00 00 00 00 00 
  71c750:	48 81 c3 a8 00 00 00 	add    $0xa8,%rbx
  71c757:	49 ff cc             	dec    %r12
  71c75a:	74 3c                	je     71c798 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x1b8>
  71c75c:	83 bb 78 ff ff ff 02 	cmpl   $0x2,-0x88(%rbx)
  71c763:	74 eb                	je     71c750 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71c765:	48 8b 73 90          	mov    -0x70(%rbx),%rsi
  71c769:	48 85 f6             	test   %rsi,%rsi
  71c76c:	74 10                	je     71c77e <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x19e>
  71c76e:	48 8b 7b 98          	mov    -0x68(%rbx),%rdi
  71c772:	48 c1 e6 03          	shl    $0x3,%rsi
  71c776:	ba 08 00 00 00       	mov    $0x8,%edx
  71c77b:	41 ff d6             	call   *%r14
  71c77e:	48 8b 73 f8          	mov    -0x8(%rbx),%rsi
  71c782:	48 85 f6             	test   %rsi,%rsi
  71c785:	74 c9                	je     71c750 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71c787:	48 8b 3b             	mov    (%rbx),%rdi
  71c78a:	48 c1 e6 05          	shl    $0x5,%rsi
  71c78e:	ba 08 00 00 00       	mov    $0x8,%edx
  71c793:	41 ff d6             	call   *%r14
  71c796:	eb b8                	jmp    71c750 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71c798:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  71c79d:	48 29 e9             	sub    %rbp,%rcx
  71c7a0:	48 c1 e9 03          	shr    $0x3,%rcx
  71c7a4:	48 b8 3d cf f3 3c cf 	movabs $0xcf3cf3cf3cf3cf3d,%rax
  71c7ab:	f3 3c cf 
  71c7ae:	48 0f af c1          	imul   %rcx,%rax
  71c7b2:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  71c7b7:	49 89 4d 00          	mov    %rcx,0x0(%r13)
  71c7bb:	49 89 6d 08          	mov    %rbp,0x8(%r13)
  71c7bf:	49 89 45 10          	mov    %rax,0x10(%r13)
  71c7c3:	4c 89 e8             	mov    %r13,%rax
  71c7c6:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
  71c7cd:	5b                   	pop    %rbx
  71c7ce:	41 5c                	pop    %r12
  71c7d0:	41 5d                	pop    %r13
  71c7d2:	41 5e                	pop    %r14
  71c7d4:	41 5f                	pop    %r15
  71c7d6:	5d                   	pop    %rbp
  71c7d7:	c3                   	ret
  71c7d8:	49 89 c6             	mov    %rax,%r14
  71c7db:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  71c7e0:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  71c7e5:	e8 56 f6 ff ff       	call   71be40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCscdodAO9FK5_5alloc3vec13in_place_drop11InPlaceDropNtNtCshBhuxcId5D0_4gpui4list9ListDraftEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71c7ea:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  71c7ef:	e8 4c f7 ff ff       	call   71bf40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_>
  71c7f4:	4c 89 f7             	mov    %r14,%rdi
  71c7f7:	e8 a4 e8 39 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
