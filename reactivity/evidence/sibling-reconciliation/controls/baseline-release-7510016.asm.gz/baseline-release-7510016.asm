
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000729800 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_>:
  729800:	55                   	push   %rbp
  729801:	41 57                	push   %r15
  729803:	41 56                	push   %r14
  729805:	41 55                	push   %r13
  729807:	41 54                	push   %r12
  729809:	53                   	push   %rbx
  72980a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  729811:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  729818:	00 
  729819:	50                   	push   %rax
  72981a:	49 89 d6             	mov    %rdx,%r14
  72981d:	48 89 f1             	mov    %rsi,%rcx
  729820:	48 d1 e9             	shr    $1,%rcx
  729823:	48 89 f0             	mov    %rsi,%rax
  729826:	48 29 c8             	sub    %rcx,%rax
  729829:	48 81 fe 20 a1 07 00 	cmp    $0x7a120,%rsi
  729830:	bb 20 a1 07 00       	mov    $0x7a120,%ebx
  729835:	48 0f 42 de          	cmovb  %rsi,%rbx
  729839:	48 39 c3             	cmp    %rax,%rbx
  72983c:	48 0f 46 d8          	cmovbe %rax,%rbx
  729840:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  729847:	73 0c                	jae    729855 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x55>
  729849:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
  72984e:	b9 00 01 00 00       	mov    $0x100,%ecx
  729853:	eb 62                	jmp    7298b7 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0xb7>
  729855:	49 89 dc             	mov    %rbx,%r12
  729858:	49 c1 e4 04          	shl    $0x4,%r12
  72985c:	48 c1 e8 3c          	shr    $0x3c,%rax
  729860:	0f 95 c0             	setne  %al
  729863:	48 b9 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rcx
  72986a:	ff ff 7f 
  72986d:	49 39 cc             	cmp    %rcx,%r12
  729870:	0f 97 c1             	seta   %cl
  729873:	08 c1                	or     %al,%cl
  729875:	74 0f                	je     729886 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x86>
  729877:	45 31 ed             	xor    %r13d,%r13d
  72987a:	4c 89 ef             	mov    %r13,%rdi
  72987d:	4c 89 e6             	mov    %r12,%rsi
  729880:	ff 15 1a 11 3c 00    	call   *0x3c111a(%rip)        # aea9a0 <_DYNAMIC+0x328>
  729886:	49 89 f7             	mov    %rsi,%r15
  729889:	48 89 fd             	mov    %rdi,%rbp
  72988c:	ff 15 46 10 3c 00    	call   *0x3c1046(%rip)        # aea8d8 <_DYNAMIC+0x260>
  729892:	41 bd 08 00 00 00    	mov    $0x8,%r13d
  729898:	be 08 00 00 00       	mov    $0x8,%esi
  72989d:	4c 89 e7             	mov    %r12,%rdi
  7298a0:	ff 15 12 10 3c 00    	call   *0x3c1012(%rip)        # aea8b8 <_DYNAMIC+0x240>
  7298a6:	48 89 ef             	mov    %rbp,%rdi
  7298a9:	4c 89 fe             	mov    %r15,%rsi
  7298ac:	49 89 c7             	mov    %rax,%r15
  7298af:	48 89 d9             	mov    %rbx,%rcx
  7298b2:	48 85 c0             	test   %rax,%rax
  7298b5:	74 c3                	je     72987a <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x7a>
  7298b7:	45 31 c0             	xor    %r8d,%r8d
  7298ba:	48 83 fe 41          	cmp    $0x41,%rsi
  7298be:	41 0f 92 c0          	setb   %r8b
  7298c2:	4c 89 fa             	mov    %r15,%rdx
  7298c5:	4d 89 f1             	mov    %r14,%r9
  7298c8:	e8 13 8a 00 00       	call   7322e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>
  7298cd:	48 81 fb 00 01 00 00 	cmp    $0x100,%rbx
  7298d4:	76 15                	jbe    7298eb <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0xeb>
  7298d6:	48 c1 e3 04          	shl    $0x4,%rbx
  7298da:	ba 08 00 00 00       	mov    $0x8,%edx
  7298df:	4c 89 ff             	mov    %r15,%rdi
  7298e2:	48 89 de             	mov    %rbx,%rsi
  7298e5:	ff 15 d5 0f 3c 00    	call   *0x3c0fd5(%rip)        # aea8c0 <_DYNAMIC+0x248>
  7298eb:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  7298f2:	5b                   	pop    %rbx
  7298f3:	41 5c                	pop    %r12
  7298f5:	41 5d                	pop    %r13
  7298f7:	41 5e                	pop    %r14
  7298f9:	41 5f                	pop    %r15
  7298fb:	5d                   	pop    %rbp
  7298fc:	c3                   	ret
  7298fd:	49 89 c6             	mov    %rax,%r14
  729900:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  729907:	73 08                	jae    729911 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x111>
  729909:	4c 89 f7             	mov    %r14,%rdi
  72990c:	e8 8f 17 39 00       	call   abb0a0 <_Unwind_Resume@plt>
  729911:	48 c1 e3 04          	shl    $0x4,%rbx
  729915:	ba 08 00 00 00       	mov    $0x8,%edx
  72991a:	4c 89 ff             	mov    %r15,%rdi
  72991d:	48 89 de             	mov    %rbx,%rsi
  729920:	ff 15 9a 0f 3c 00    	call   *0x3c0f9a(%rip)        # aea8c0 <_DYNAMIC+0x248>
  729926:	4c 89 f7             	mov    %r14,%rdi
  729929:	e8 72 17 39 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
