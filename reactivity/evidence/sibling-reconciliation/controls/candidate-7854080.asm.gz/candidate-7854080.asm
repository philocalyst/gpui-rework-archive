
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000077d800 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children>:
  77d800:	48 8b 57 10          	mov    0x10(%rdi),%rdx
  77d804:	b8 04 00 00 00       	mov    $0x4,%eax
  77d809:	48 85 d2             	test   %rdx,%rdx
  77d80c:	74 50                	je     77d85e <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0x5e>
  77d80e:	48 89 d1             	mov    %rdx,%rcx
  77d811:	48 d1 e9             	shr    $1,%rcx
  77d814:	4c 8d 51 01          	lea    0x1(%rcx),%r10
  77d818:	41 89 f1             	mov    %esi,%r9d
  77d81b:	49 ff c1             	inc    %r9
  77d81e:	45 31 c0             	xor    %r8d,%r8d
  77d821:	83 fe ff             	cmp    $0xffffffff,%esi
  77d824:	4d 0f 44 c8          	cmove  %r8,%r9
  77d828:	49 8d 71 02          	lea    0x2(%r9),%rsi
  77d82c:	4c 39 d6             	cmp    %r10,%rsi
  77d82f:	77 29                	ja     77d85a <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0x5a>
  77d831:	48 8b 47 08          	mov    0x8(%rdi),%rax
  77d835:	4c 29 d2             	sub    %r10,%rdx
  77d838:	42 8b 3c 88          	mov    (%rax,%r9,4),%edi
  77d83c:	46 8b 44 88 04       	mov    0x4(%rax,%r9,4),%r8d
  77d841:	41 39 f8             	cmp    %edi,%r8d
  77d844:	72 1f                	jb     77d865 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0x65>
  77d846:	4c 39 c2             	cmp    %r8,%rdx
  77d849:	72 1a                	jb     77d865 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0x65>
  77d84b:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  77d84f:	48 83 c0 04          	add    $0x4,%rax
  77d853:	49 29 f8             	sub    %rdi,%r8
  77d856:	48 8d 04 b8          	lea    (%rax,%rdi,4),%rax
  77d85a:	4c 89 c2             	mov    %r8,%rdx
  77d85d:	c3                   	ret
  77d85e:	45 31 c0             	xor    %r8d,%r8d
  77d861:	4c 89 c2             	mov    %r8,%rdx
  77d864:	c3                   	ret
  77d865:	50                   	push   %rax
  77d866:	48 8d 0d eb 35 34 00 	lea    0x3435eb(%rip),%rcx        # ac0e58 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0x130>
  77d86d:	4c 89 c6             	mov    %r8,%rsi
  77d870:	ff 15 9a a4 36 00    	call   *0x36a49a(%rip)        # ae7d10 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
