
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006eb9d0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_>:
  6eb9d0:	53                   	push   %rbx
  6eb9d1:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  6eb9d8:	48 89 fb             	mov    %rdi,%rbx
  6eb9db:	48 8b 06             	mov    (%rsi),%rax
  6eb9de:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6eb9e2:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6eb9e6:	48 85 ff             	test   %rdi,%rdi
  6eb9e9:	0f 84 e3 01 00 00    	je     6ebbd2 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x202>
  6eb9ef:	48 8b 8c c8 c8 01 00 	mov    0x1c8(%rax,%rcx,8),%rcx
  6eb9f6:	00 
  6eb9f7:	48 89 f8             	mov    %rdi,%rax
  6eb9fa:	48 ff c8             	dec    %rax
  6eb9fd:	0f 84 cb 00 00 00    	je     6ebace <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0xfe>
  6eba03:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6eba07:	48 89 c6             	mov    %rax,%rsi
  6eba0a:	48 83 e6 07          	and    $0x7,%rsi
  6eba0e:	74 2b                	je     6eba3b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x6b>
  6eba10:	45 31 c0             	xor    %r8d,%r8d
  6eba13:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6eba1a:	84 00 00 00 00 00 
  6eba20:	44 0f b7 89 c2 01 00 	movzwl 0x1c2(%rcx),%r9d
  6eba27:	00 
  6eba28:	4a 8b 8c c9 c8 01 00 	mov    0x1c8(%rcx,%r9,8),%rcx
  6eba2f:	00 
  6eba30:	49 ff c0             	inc    %r8
  6eba33:	4c 39 c6             	cmp    %r8,%rsi
  6eba36:	75 e8                	jne    6eba20 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x50>
  6eba38:	4c 29 c0             	sub    %r8,%rax
  6eba3b:	48 83 ff 07          	cmp    $0x7,%rdi
  6eba3f:	0f 82 89 00 00 00    	jb     6ebace <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0xfe>
  6eba45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6eba4c:	00 00 00 00 
  6eba50:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eba57:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eba5e:	00 
  6eba5f:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eba66:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eba6d:	00 
  6eba6e:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eba75:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eba7c:	00 
  6eba7d:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eba84:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eba8b:	00 
  6eba8c:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eba93:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eba9a:	00 
  6eba9b:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebaa2:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebaa9:	00 
  6ebaaa:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebab1:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebab8:	00 
  6ebab9:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebac0:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebac7:	00 
  6ebac8:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6ebacc:	75 82                	jne    6eba50 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x80>
  6ebace:	0f b7 81 c2 01 00 00 	movzwl 0x1c2(%rcx),%eax
  6ebad5:	48 ff c8             	dec    %rax
  6ebad8:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6ebadd:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6ebae4:	00 00 
  6ebae6:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6ebaeb:	48 89 e7             	mov    %rsp,%rdi
  6ebaee:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6ebaf3:	e8 78 61 00 00       	call   6f1c70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>
  6ebaf8:	48 8b 3c 24          	mov    (%rsp),%rdi
  6ebafc:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6ebb01:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6ebb06:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6ebb0b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  6ebb10:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6ebb15:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6ebb1a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6ebb1f:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  6ebb26:	48 39 ce             	cmp    %rcx,%rsi
  6ebb29:	72 1f                	jb     6ebb4a <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x17a>
  6ebb2b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ebb30:	0f b7 b0 c0 01 00 00 	movzwl 0x1c0(%rax),%esi
  6ebb37:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6ebb3e:	48 ff c2             	inc    %rdx
  6ebb41:	66 3b b0 c2 01 00 00 	cmp    0x1c2(%rax),%si
  6ebb48:	73 e6                	jae    6ebb30 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x160>
  6ebb4a:	49 89 f0             	mov    %rsi,%r8
  6ebb4d:	49 c1 e0 05          	shl    $0x5,%r8
  6ebb51:	48 8b 8c f0 68 01 00 	mov    0x168(%rax,%rsi,8),%rcx
  6ebb58:	00 
  6ebb59:	48 89 bc f0 68 01 00 	mov    %rdi,0x168(%rax,%rsi,8)
  6ebb60:	00 
  6ebb61:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6ebb66:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6ebb6c:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6ebb71:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6ebb75:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6ebb7a:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6ebb7f:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6ebb84:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6ebb8a:	48 85 d2             	test   %rdx,%rdx
  6ebb8d:	74 6c                	je     6ebbfb <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x22b>
  6ebb8f:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  6ebb93:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6ebb9a:	48 89 d6             	mov    %rdx,%rsi
  6ebb9d:	48 83 e6 07          	and    $0x7,%rsi
  6ebba1:	74 5d                	je     6ebc00 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x230>
  6ebba3:	45 31 c9             	xor    %r9d,%r9d
  6ebba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6ebbad:	00 00 00 
  6ebbb0:	48 8b 07             	mov    (%rdi),%rax
  6ebbb3:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6ebbba:	49 ff c1             	inc    %r9
  6ebbbd:	4c 39 ce             	cmp    %r9,%rsi
  6ebbc0:	75 ee                	jne    6ebbb0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x1e0>
  6ebbc2:	49 89 d0             	mov    %rdx,%r8
  6ebbc5:	4d 29 c8             	sub    %r9,%r8
  6ebbc8:	31 f6                	xor    %esi,%esi
  6ebbca:	48 83 fa 08          	cmp    $0x8,%rdx
  6ebbce:	73 40                	jae    6ebc10 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x240>
  6ebbd0:	eb 7f                	jmp    6ebc51 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ebbd2:	48 89 04 24          	mov    %rax,(%rsp)
  6ebbd6:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6ebbdd:	00 00 
  6ebbdf:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6ebbe4:	48 89 e6             	mov    %rsp,%rsi
  6ebbe7:	48 89 df             	mov    %rbx,%rdi
  6ebbea:	e8 81 60 00 00       	call   6f1c70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>
  6ebbef:	48 89 d8             	mov    %rbx,%rax
  6ebbf2:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6ebbf9:	5b                   	pop    %rbx
  6ebbfa:	c3                   	ret
  6ebbfb:	48 ff c6             	inc    %rsi
  6ebbfe:	eb 51                	jmp    6ebc51 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ebc00:	49 89 d0             	mov    %rdx,%r8
  6ebc03:	31 f6                	xor    %esi,%esi
  6ebc05:	48 83 fa 08          	cmp    $0x8,%rdx
  6ebc09:	72 46                	jb     6ebc51 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ebc0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ebc10:	48 8b 07             	mov    (%rdi),%rax
  6ebc13:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc1a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc21:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc28:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc2f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc36:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc3d:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc44:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6ebc4b:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6ebc4f:	75 bf                	jne    6ebc10 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x240>
  6ebc51:	48 89 0b             	mov    %rcx,(%rbx)
  6ebc54:	0f 28 04 24          	movaps (%rsp),%xmm0
  6ebc58:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6ebc5d:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6ebc61:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6ebc65:	48 89 43 28          	mov    %rax,0x28(%rbx)
  6ebc69:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
  6ebc70:	00 
  6ebc71:	48 89 73 38          	mov    %rsi,0x38(%rbx)
  6ebc75:	48 89 d8             	mov    %rbx,%rax
  6ebc78:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6ebc7f:	5b                   	pop    %rbx
  6ebc80:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
