
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006ebc20 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_>:
  6ebc20:	53                   	push   %rbx
  6ebc21:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  6ebc28:	48 89 fb             	mov    %rdi,%rbx
  6ebc2b:	48 8b 06             	mov    (%rsi),%rax
  6ebc2e:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6ebc32:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6ebc36:	48 85 ff             	test   %rdi,%rdi
  6ebc39:	0f 84 e3 01 00 00    	je     6ebe22 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x202>
  6ebc3f:	48 8b 8c c8 c8 01 00 	mov    0x1c8(%rax,%rcx,8),%rcx
  6ebc46:	00 
  6ebc47:	48 89 f8             	mov    %rdi,%rax
  6ebc4a:	48 ff c8             	dec    %rax
  6ebc4d:	0f 84 cb 00 00 00    	je     6ebd1e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0xfe>
  6ebc53:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6ebc57:	48 89 c6             	mov    %rax,%rsi
  6ebc5a:	48 83 e6 07          	and    $0x7,%rsi
  6ebc5e:	74 2b                	je     6ebc8b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x6b>
  6ebc60:	45 31 c0             	xor    %r8d,%r8d
  6ebc63:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ebc6a:	84 00 00 00 00 00 
  6ebc70:	44 0f b7 89 c2 01 00 	movzwl 0x1c2(%rcx),%r9d
  6ebc77:	00 
  6ebc78:	4a 8b 8c c9 c8 01 00 	mov    0x1c8(%rcx,%r9,8),%rcx
  6ebc7f:	00 
  6ebc80:	49 ff c0             	inc    %r8
  6ebc83:	4c 39 c6             	cmp    %r8,%rsi
  6ebc86:	75 e8                	jne    6ebc70 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x50>
  6ebc88:	4c 29 c0             	sub    %r8,%rax
  6ebc8b:	48 83 ff 07          	cmp    $0x7,%rdi
  6ebc8f:	0f 82 89 00 00 00    	jb     6ebd1e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0xfe>
  6ebc95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6ebc9c:	00 00 00 00 
  6ebca0:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebca7:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebcae:	00 
  6ebcaf:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebcb6:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebcbd:	00 
  6ebcbe:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebcc5:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebccc:	00 
  6ebccd:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebcd4:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebcdb:	00 
  6ebcdc:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebce3:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebcea:	00 
  6ebceb:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebcf2:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebcf9:	00 
  6ebcfa:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebd01:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebd08:	00 
  6ebd09:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebd10:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebd17:	00 
  6ebd18:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6ebd1c:	75 82                	jne    6ebca0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x80>
  6ebd1e:	0f b7 81 c2 01 00 00 	movzwl 0x1c2(%rcx),%eax
  6ebd25:	48 ff c8             	dec    %rax
  6ebd28:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6ebd2d:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6ebd34:	00 00 
  6ebd36:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6ebd3b:	48 89 e7             	mov    %rsp,%rdi
  6ebd3e:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6ebd43:	e8 78 72 00 00       	call   6f2fc0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>
  6ebd48:	48 8b 3c 24          	mov    (%rsp),%rdi
  6ebd4c:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6ebd51:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6ebd56:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6ebd5b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  6ebd60:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6ebd65:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6ebd6a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6ebd6f:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  6ebd76:	48 39 ce             	cmp    %rcx,%rsi
  6ebd79:	72 1f                	jb     6ebd9a <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x17a>
  6ebd7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ebd80:	0f b7 b0 c0 01 00 00 	movzwl 0x1c0(%rax),%esi
  6ebd87:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6ebd8e:	48 ff c2             	inc    %rdx
  6ebd91:	66 3b b0 c2 01 00 00 	cmp    0x1c2(%rax),%si
  6ebd98:	73 e6                	jae    6ebd80 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x160>
  6ebd9a:	49 89 f0             	mov    %rsi,%r8
  6ebd9d:	49 c1 e0 05          	shl    $0x5,%r8
  6ebda1:	48 8b 8c f0 68 01 00 	mov    0x168(%rax,%rsi,8),%rcx
  6ebda8:	00 
  6ebda9:	48 89 bc f0 68 01 00 	mov    %rdi,0x168(%rax,%rsi,8)
  6ebdb0:	00 
  6ebdb1:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6ebdb6:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6ebdbc:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6ebdc1:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6ebdc5:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6ebdca:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6ebdcf:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6ebdd4:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6ebdda:	48 85 d2             	test   %rdx,%rdx
  6ebddd:	74 6c                	je     6ebe4b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x22b>
  6ebddf:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  6ebde3:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6ebdea:	48 89 d6             	mov    %rdx,%rsi
  6ebded:	48 83 e6 07          	and    $0x7,%rsi
  6ebdf1:	74 5d                	je     6ebe50 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x230>
  6ebdf3:	45 31 c9             	xor    %r9d,%r9d
  6ebdf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6ebdfd:	00 00 00 
  6ebe00:	48 8b 07             	mov    (%rdi),%rax
  6ebe03:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6ebe0a:	49 ff c1             	inc    %r9
  6ebe0d:	4c 39 ce             	cmp    %r9,%rsi
  6ebe10:	75 ee                	jne    6ebe00 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x1e0>
  6ebe12:	49 89 d0             	mov    %rdx,%r8
  6ebe15:	4d 29 c8             	sub    %r9,%r8
  6ebe18:	31 f6                	xor    %esi,%esi
  6ebe1a:	48 83 fa 08          	cmp    $0x8,%rdx
  6ebe1e:	73 40                	jae    6ebe60 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x240>
  6ebe20:	eb 7f                	jmp    6ebea1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6ebe22:	48 89 04 24          	mov    %rax,(%rsp)
  6ebe26:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6ebe2d:	00 00 
  6ebe2f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6ebe34:	48 89 e6             	mov    %rsp,%rsi
  6ebe37:	48 89 df             	mov    %rbx,%rdi
  6ebe3a:	e8 81 71 00 00       	call   6f2fc0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>
  6ebe3f:	48 89 d8             	mov    %rbx,%rax
  6ebe42:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6ebe49:	5b                   	pop    %rbx
  6ebe4a:	c3                   	ret
  6ebe4b:	48 ff c6             	inc    %rsi
  6ebe4e:	eb 51                	jmp    6ebea1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6ebe50:	49 89 d0             	mov    %rdx,%r8
  6ebe53:	31 f6                	xor    %esi,%esi
  6ebe55:	48 83 fa 08          	cmp    $0x8,%rdx
  6ebe59:	72 46                	jb     6ebea1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6ebe5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ebe60:	48 8b 07             	mov    (%rdi),%rax
  6ebe63:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebe6a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebe71:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebe78:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebe7f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebe86:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebe8d:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebe94:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6ebe9b:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6ebe9f:	75 bf                	jne    6ebe60 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x240>
  6ebea1:	48 89 0b             	mov    %rcx,(%rbx)
  6ebea4:	0f 28 04 24          	movaps (%rsp),%xmm0
  6ebea8:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6ebead:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6ebeb1:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6ebeb5:	48 89 43 28          	mov    %rax,0x28(%rbx)
  6ebeb9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
  6ebec0:	00 
  6ebec1:	48 89 73 38          	mov    %rsi,0x38(%rbx)
  6ebec5:	48 89 d8             	mov    %rbx,%rax
  6ebec8:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6ebecf:	5b                   	pop    %rbx
  6ebed0:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
