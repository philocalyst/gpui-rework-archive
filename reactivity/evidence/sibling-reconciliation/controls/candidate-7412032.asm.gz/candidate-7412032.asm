
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000711940 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_>:
  711940:	55                   	push   %rbp
  711941:	41 57                	push   %r15
  711943:	41 56                	push   %r14
  711945:	41 55                	push   %r13
  711947:	41 54                	push   %r12
  711949:	53                   	push   %rbx
  71194a:	48 83 ec 38          	sub    $0x38,%rsp
  71194e:	48 83 fe 02          	cmp    $0x2,%rsi
  711952:	0f 82 76 04 00 00    	jb     711dce <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x48e>
  711958:	48 8d 46 10          	lea    0x10(%rsi),%rax
  71195c:	48 39 c1             	cmp    %rax,%rcx
  71195f:	0f 82 c8 04 00 00    	jb     711e2d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4ed>
  711965:	48 89 d3             	mov    %rdx,%rbx
  711968:	48 89 f5             	mov    %rsi,%rbp
  71196b:	48 d1 ed             	shr    $1,%rbp
  71196e:	48 83 fe 07          	cmp    $0x7,%rsi
  711972:	0f 86 b3 01 00 00    	jbe    711b2b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x1eb>
  711978:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  71197c:	48 8b 57 48          	mov    0x48(%rdi),%rdx
  711980:	45 31 c0             	xor    %r8d,%r8d
  711983:	45 31 d2             	xor    %r10d,%r10d
  711986:	48 3b 0f             	cmp    (%rdi),%rcx
  711989:	41 0f 93 c0          	setae  %r8b
  71198d:	41 0f 92 c2          	setb   %r10b
  711991:	48 8d 47 48          	lea    0x48(%rdi),%rax
  711995:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  711999:	48 3b 57 30          	cmp    0x30(%rdi),%rdx
  71199d:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  7119a1:	4e 8d 34 d7          	lea    (%rdi,%r10,8),%r14
  7119a5:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  7119a9:	4c 89 ca             	mov    %r9,%rdx
  7119ac:	48 0f 42 d0          	cmovb  %rax,%rdx
  7119b0:	4a 8d 0c c7          	lea    (%rdi,%r8,8),%rcx
  7119b4:	49 0f 42 c1          	cmovb  %r9,%rax
  7119b8:	4c 8b 0a             	mov    (%rdx),%r9
  7119bb:	4c 8b 18             	mov    (%rax),%r11
  7119be:	4e 8b 04 c7          	mov    (%rdi,%r8,8),%r8
  7119c2:	4d 39 c3             	cmp    %r8,%r11
  7119c5:	49 89 cf             	mov    %rcx,%r15
  7119c8:	4c 0f 42 fa          	cmovb  %rdx,%r15
  7119cc:	4e 3b 0c d7          	cmp    (%rdi,%r10,8),%r9
  7119d0:	4d 0f 42 fe          	cmovb  %r14,%r15
  7119d4:	4c 0f 42 f2          	cmovb  %rdx,%r14
  7119d8:	48 0f 42 d1          	cmovb  %rcx,%rdx
  7119dc:	4d 39 c3             	cmp    %r8,%r11
  7119df:	48 0f 43 c8          	cmovae %rax,%rcx
  7119e3:	48 0f 42 d0          	cmovb  %rax,%rdx
  7119e7:	48 8b 02             	mov    (%rdx),%rax
  7119ea:	49 3b 07             	cmp    (%r15),%rax
  7119ed:	4c 89 f8             	mov    %r15,%rax
  7119f0:	48 0f 42 c2          	cmovb  %rdx,%rax
  7119f4:	49 0f 42 d7          	cmovb  %r15,%rdx
  7119f8:	4d 8b 46 10          	mov    0x10(%r14),%r8
  7119fc:	4c 89 43 10          	mov    %r8,0x10(%rbx)
  711a00:	41 0f 10 06          	movups (%r14),%xmm0
  711a04:	0f 11 03             	movups %xmm0,(%rbx)
  711a07:	4c 8b 40 10          	mov    0x10(%rax),%r8
  711a0b:	4c 89 43 28          	mov    %r8,0x28(%rbx)
  711a0f:	0f 10 00             	movups (%rax),%xmm0
  711a12:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
  711a16:	48 8b 42 10          	mov    0x10(%rdx),%rax
  711a1a:	48 89 43 40          	mov    %rax,0x40(%rbx)
  711a1e:	0f 10 02             	movups (%rdx),%xmm0
  711a21:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  711a25:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
  711a2c:	00 
  711a2d:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  711a31:	4c 8d 0c 17          	lea    (%rdi,%rdx,1),%r9
  711a35:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
  711a3a:	48 8b 44 17 48       	mov    0x48(%rdi,%rdx,1),%rax
  711a3f:	45 31 d2             	xor    %r10d,%r10d
  711a42:	45 31 db             	xor    %r11d,%r11d
  711a45:	4c 3b 04 17          	cmp    (%rdi,%rdx,1),%r8
  711a49:	41 0f 93 c2          	setae  %r10b
  711a4d:	41 0f 92 c3          	setb   %r11b
  711a51:	4c 8d 04 17          	lea    (%rdi,%rdx,1),%r8
  711a55:	49 83 c0 48          	add    $0x48,%r8
  711a59:	4c 8d 3c 17          	lea    (%rdi,%rdx,1),%r15
  711a5d:	49 83 c7 30          	add    $0x30,%r15
  711a61:	48 3b 44 17 30       	cmp    0x30(%rdi,%rdx,1),%rax
  711a66:	4f 8d 1c 5b          	lea    (%r11,%r11,2),%r11
  711a6a:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  711a6e:	4f 8d 34 d1          	lea    (%r9,%r10,8),%r14
  711a72:	4c 89 f8             	mov    %r15,%rax
  711a75:	49 0f 42 c0          	cmovb  %r8,%rax
  711a79:	4d 0f 42 c7          	cmovb  %r15,%r8
  711a7d:	4d 8b 38             	mov    (%r8),%r15
  711a80:	4f 8b 14 d1          	mov    (%r9,%r10,8),%r10
  711a84:	4d 39 d7             	cmp    %r10,%r15
  711a87:	4d 89 f4             	mov    %r14,%r12
  711a8a:	4c 0f 42 e0          	cmovb  %rax,%r12
  711a8e:	4c 8b 28             	mov    (%rax),%r13
  711a91:	4f 3b 2c d9          	cmp    (%r9,%r11,8),%r13
  711a95:	4f 8d 0c d9          	lea    (%r9,%r11,8),%r9
  711a99:	4d 0f 42 e1          	cmovb  %r9,%r12
  711a9d:	4c 0f 42 c8          	cmovb  %rax,%r9
  711aa1:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  711aa5:	49 0f 42 c6          	cmovb  %r14,%rax
  711aa9:	4d 39 d7             	cmp    %r10,%r15
  711aac:	4d 0f 43 f0          	cmovae %r8,%r14
  711ab0:	49 0f 42 c0          	cmovb  %r8,%rax
  711ab4:	4c 89 5b 58          	mov    %r11,0x58(%rbx)
  711ab8:	4c 8b 00             	mov    (%rax),%r8
  711abb:	4d 3b 04 24          	cmp    (%r12),%r8
  711abf:	0f 10 01             	movups (%rcx),%xmm0
  711ac2:	4c 89 e1             	mov    %r12,%rcx
  711ac5:	48 0f 42 c8          	cmovb  %rax,%rcx
  711ac9:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
  711acd:	49 0f 42 c4          	cmovb  %r12,%rax
  711ad1:	4d 8b 41 10          	mov    0x10(%r9),%r8
  711ad5:	4c 89 44 13 10       	mov    %r8,0x10(%rbx,%rdx,1)
  711ada:	41 0f 10 01          	movups (%r9),%xmm0
  711ade:	0f 11 04 13          	movups %xmm0,(%rbx,%rdx,1)
  711ae2:	0f 10 01             	movups (%rcx),%xmm0
  711ae5:	0f 11 44 13 18       	movups %xmm0,0x18(%rbx,%rdx,1)
  711aea:	48 8b 49 10          	mov    0x10(%rcx),%rcx
  711aee:	48 89 4c 13 28       	mov    %rcx,0x28(%rbx,%rdx,1)
  711af3:	0f 10 00             	movups (%rax),%xmm0
  711af6:	0f 11 44 13 30       	movups %xmm0,0x30(%rbx,%rdx,1)
  711afb:	48 8b 48 10          	mov    0x10(%rax),%rcx
  711aff:	48 89 4c 13 40       	mov    %rcx,0x40(%rbx,%rdx,1)
  711b04:	41 0f 10 06          	movups (%r14),%xmm0
  711b08:	0f 11 44 13 48       	movups %xmm0,0x48(%rbx,%rdx,1)
  711b0d:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  711b11:	48 89 4c 13 58       	mov    %rcx,0x58(%rbx,%rdx,1)
  711b16:	ba 04 00 00 00       	mov    $0x4,%edx
  711b1b:	49 89 f6             	mov    %rsi,%r14
  711b1e:	49 29 ee             	sub    %rbp,%r14
  711b21:	48 39 ea             	cmp    %rbp,%rdx
  711b24:	72 45                	jb     711b6b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x22b>
  711b26:	e9 e6 00 00 00       	jmp    711c11 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  711b2b:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
  711b2f:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
  711b33:	0f 10 07             	movups (%rdi),%xmm0
  711b36:	0f 11 03             	movups %xmm0,(%rbx)
  711b39:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  711b40:	00 
  711b41:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  711b45:	48 8b 54 0f 10       	mov    0x10(%rdi,%rcx,1),%rdx
  711b4a:	48 89 54 0b 10       	mov    %rdx,0x10(%rbx,%rcx,1)
  711b4f:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  711b53:	0f 11 04 0b          	movups %xmm0,(%rbx,%rcx,1)
  711b57:	ba 01 00 00 00       	mov    $0x1,%edx
  711b5c:	49 89 f6             	mov    %rsi,%r14
  711b5f:	49 29 ee             	sub    %rbp,%r14
  711b62:	48 39 ea             	cmp    %rbp,%rdx
  711b65:	0f 83 a6 00 00 00    	jae    711c11 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  711b6b:	8d 0c d5 00 00 00 00 	lea    0x0(,%rdx,8),%ecx
  711b72:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  711b76:	49 89 d3             	mov    %rdx,%r11
  711b79:	eb 21                	jmp    711b9c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x25c>
  711b7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  711b80:	49 89 d9             	mov    %rbx,%r9
  711b83:	4d 89 01             	mov    %r8,(%r9)
  711b86:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  711b8b:	41 0f 11 41 08       	movups %xmm0,0x8(%r9)
  711b90:	49 ff c3             	inc    %r11
  711b93:	48 83 c1 18          	add    $0x18,%rcx
  711b97:	49 39 eb             	cmp    %rbp,%r11
  711b9a:	74 75                	je     711c11 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  711b9c:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
  711ba3:	00 
  711ba4:	4c 8d 0c 40          	lea    (%rax,%rax,2),%r9
  711ba8:	42 0f 10 04 0f       	movups (%rdi,%r9,1),%xmm0
  711bad:	42 0f 11 04 0b       	movups %xmm0,(%rbx,%r9,1)
  711bb2:	4a 8b 44 0f 10       	mov    0x10(%rdi,%r9,1),%rax
  711bb7:	4a 89 44 0b 10       	mov    %rax,0x10(%rbx,%r9,1)
  711bbc:	4e 8b 04 0b          	mov    (%rbx,%r9,1),%r8
  711bc0:	4e 3b 44 0b e8       	cmp    -0x18(%rbx,%r9,1),%r8
  711bc5:	73 c9                	jae    711b90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x250>
  711bc7:	49 01 f9             	add    %rdi,%r9
  711bca:	41 0f 10 41 08       	movups 0x8(%r9),%xmm0
  711bcf:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  711bd4:	49 89 ca             	mov    %rcx,%r10
  711bd7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  711bde:	00 00 
  711be0:	4a 8b 44 13 f8       	mov    -0x8(%rbx,%r10,1),%rax
  711be5:	4a 89 44 13 10       	mov    %rax,0x10(%rbx,%r10,1)
  711bea:	42 0f 10 44 13 e8    	movups -0x18(%rbx,%r10,1),%xmm0
  711bf0:	42 0f 11 04 13       	movups %xmm0,(%rbx,%r10,1)
  711bf5:	49 83 fa 18          	cmp    $0x18,%r10
  711bf9:	74 85                	je     711b80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x240>
  711bfb:	4d 8d 4a e8          	lea    -0x18(%r10),%r9
  711bff:	4e 3b 44 13 d0       	cmp    -0x30(%rbx,%r10,1),%r8
  711c04:	4d 89 ca             	mov    %r9,%r10
  711c07:	72 d7                	jb     711be0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2a0>
  711c09:	49 01 d9             	add    %rbx,%r9
  711c0c:	e9 72 ff ff ff       	jmp    711b83 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x243>
  711c11:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  711c18:	00 
  711c19:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  711c1d:	48 8d 0c 03          	lea    (%rbx,%rax,1),%rcx
  711c21:	4c 39 f2             	cmp    %r14,%rdx
  711c24:	0f 83 a7 00 00 00    	jae    711cd1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x391>
  711c2a:	48 01 f8             	add    %rdi,%rax
  711c2d:	44 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%r8d
  711c34:	00 
  711c35:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  711c39:	eb 21                	jmp    711c5c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x31c>
  711c3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  711c40:	49 89 ca             	mov    %rcx,%r10
  711c43:	4d 89 0a             	mov    %r9,(%r10)
  711c46:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  711c4b:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  711c50:	48 ff c2             	inc    %rdx
  711c53:	49 83 c0 18          	add    $0x18,%r8
  711c57:	4c 39 f2             	cmp    %r14,%rdx
  711c5a:	74 75                	je     711cd1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x391>
  711c5c:	4c 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%r9
  711c63:	00 
  711c64:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  711c68:	42 0f 10 04 10       	movups (%rax,%r10,1),%xmm0
  711c6d:	42 0f 11 04 11       	movups %xmm0,(%rcx,%r10,1)
  711c72:	4e 8b 4c 10 10       	mov    0x10(%rax,%r10,1),%r9
  711c77:	4e 89 4c 11 10       	mov    %r9,0x10(%rcx,%r10,1)
  711c7c:	4e 8b 0c 11          	mov    (%rcx,%r10,1),%r9
  711c80:	4e 3b 4c 11 e8       	cmp    -0x18(%rcx,%r10,1),%r9
  711c85:	73 c9                	jae    711c50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x310>
  711c87:	49 01 c2             	add    %rax,%r10
  711c8a:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  711c8f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  711c94:	4d 89 c3             	mov    %r8,%r11
  711c97:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  711c9e:	00 00 
  711ca0:	4e 8b 54 19 f8       	mov    -0x8(%rcx,%r11,1),%r10
  711ca5:	4e 89 54 19 10       	mov    %r10,0x10(%rcx,%r11,1)
  711caa:	42 0f 10 44 19 e8    	movups -0x18(%rcx,%r11,1),%xmm0
  711cb0:	42 0f 11 04 19       	movups %xmm0,(%rcx,%r11,1)
  711cb5:	49 83 fb 18          	cmp    $0x18,%r11
  711cb9:	74 85                	je     711c40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x300>
  711cbb:	4d 8d 53 e8          	lea    -0x18(%r11),%r10
  711cbf:	4e 3b 4c 19 d0       	cmp    -0x30(%rcx,%r11,1),%r9
  711cc4:	4d 89 d3             	mov    %r10,%r11
  711cc7:	72 d7                	jb     711ca0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x360>
  711cc9:	49 01 ca             	add    %rcx,%r10
  711ccc:	e9 72 ff ff ff       	jmp    711c43 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x303>
  711cd1:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  711cd6:	48 8d 14 76          	lea    (%rsi,%rsi,2),%rdx
  711cda:	4c 8d 0c d7          	lea    (%rdi,%rdx,8),%r9
  711cde:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  711ce2:	48 8d 74 d3 e8       	lea    -0x18(%rbx,%rdx,8),%rsi
  711ce7:	4c 8d 79 e8          	lea    -0x18(%rcx),%r15
  711ceb:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  711cf0:	49 89 f8             	mov    %rdi,%r8
  711cf3:	48 89 df             	mov    %rbx,%rdi
  711cf6:	eb 58                	jmp    711d50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x410>
  711cf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  711cff:	00 
  711d00:	45 88 eb             	mov    %r13b,%r11b
  711d03:	4b 8d 04 5b          	lea    (%r11,%r11,2),%rax
  711d07:	48 8d 0c c1          	lea    (%rcx,%rax,8),%rcx
  711d0b:	41 88 ea             	mov    %bpl,%r10b
  711d0e:	4b 8d 04 52          	lea    (%r10,%r10,2),%rax
  711d12:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  711d18:	4d 19 d2             	sbb    %r10,%r10
  711d1b:	48 8d 3c c7          	lea    (%rdi,%rax,8),%rdi
  711d1f:	49 83 c0 18          	add    $0x18,%r8
  711d23:	48 8b 42 10          	mov    0x10(%rdx),%rax
  711d27:	49 89 41 10          	mov    %rax,0x10(%r9)
  711d2b:	0f 10 02             	movups (%rdx),%xmm0
  711d2e:	41 0f 11 01          	movups %xmm0,(%r9)
  711d32:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
  711d36:	48 8d 34 c6          	lea    (%rsi,%rax,8),%rsi
  711d3a:	4b 8d 04 52          	lea    (%r10,%r10,2),%rax
  711d3e:	4d 8d 3c c7          	lea    (%r15,%rax,8),%r15
  711d42:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  711d46:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  711d4b:	48 ff cd             	dec    %rbp
  711d4e:	74 57                	je     711da7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x467>
  711d50:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
  711d55:	4c 8b 21             	mov    (%rcx),%r12
  711d58:	45 31 d2             	xor    %r10d,%r10d
  711d5b:	45 31 db             	xor    %r11d,%r11d
  711d5e:	48 89 ca             	mov    %rcx,%rdx
  711d61:	4c 3b 27             	cmp    (%rdi),%r12
  711d64:	40 0f 93 c5          	setae  %bpl
  711d68:	41 0f 92 c5          	setb   %r13b
  711d6c:	72 03                	jb     711d71 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x431>
  711d6e:	48 89 fa             	mov    %rdi,%rdx
  711d71:	4c 8b 62 10          	mov    0x10(%rdx),%r12
  711d75:	4d 89 60 10          	mov    %r12,0x10(%r8)
  711d79:	0f 10 02             	movups (%rdx),%xmm0
  711d7c:	41 0f 11 00          	movups %xmm0,(%r8)
  711d80:	4c 8b 36             	mov    (%rsi),%r14
  711d83:	49 8b 07             	mov    (%r15),%rax
  711d86:	49 39 c6             	cmp    %rax,%r14
  711d89:	41 bc 00 00 00 00    	mov    $0x0,%r12d
  711d8f:	49 83 d4 ff          	adc    $0xffffffffffffffff,%r12
  711d93:	4c 89 fa             	mov    %r15,%rdx
  711d96:	49 39 c6             	cmp    %rax,%r14
  711d99:	0f 82 61 ff ff ff    	jb     711d00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x3c0>
  711d9f:	48 89 f2             	mov    %rsi,%rdx
  711da2:	e9 59 ff ff ff       	jmp    711d00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x3c0>
  711da7:	49 83 c7 18          	add    $0x18,%r15
  711dab:	48 83 c6 18          	add    $0x18,%rsi
  711daf:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  711db4:	41 f6 c5 01          	test   $0x1,%r13b
  711db8:	75 23                	jne    711ddd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x49d>
  711dba:	48 39 f1             	cmp    %rsi,%rcx
  711dbd:	0f 95 c0             	setne  %al
  711dc0:	4c 39 ff             	cmp    %r15,%rdi
  711dc3:	75 57                	jne    711e1c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4dc>
  711dc5:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  711dca:	84 c0                	test   %al,%al
  711dcc:	75 59                	jne    711e27 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4e7>
  711dce:	48 83 c4 38          	add    $0x38,%rsp
  711dd2:	5b                   	pop    %rbx
  711dd3:	41 5c                	pop    %r12
  711dd5:	41 5d                	pop    %r13
  711dd7:	41 5e                	pop    %r14
  711dd9:	41 5f                	pop    %r15
  711ddb:	5d                   	pop    %rbp
  711ddc:	c3                   	ret
  711ddd:	31 c0                	xor    %eax,%eax
  711ddf:	31 d2                	xor    %edx,%edx
  711de1:	4c 39 ff             	cmp    %r15,%rdi
  711de4:	0f 93 c0             	setae  %al
  711de7:	0f 92 c2             	setb   %dl
  711dea:	49 89 c9             	mov    %rcx,%r9
  711ded:	4c 0f 42 cf          	cmovb  %rdi,%r9
  711df1:	4d 8b 51 10          	mov    0x10(%r9),%r10
  711df5:	4d 89 50 10          	mov    %r10,0x10(%r8)
  711df9:	41 0f 10 01          	movups (%r9),%xmm0
  711dfd:	41 0f 11 00          	movups %xmm0,(%r8)
  711e01:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  711e05:	48 8d 3c d7          	lea    (%rdi,%rdx,8),%rdi
  711e09:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  711e0d:	48 8d 0c c1          	lea    (%rcx,%rax,8),%rcx
  711e11:	48 39 f1             	cmp    %rsi,%rcx
  711e14:	0f 95 c0             	setne  %al
  711e17:	4c 39 ff             	cmp    %r15,%rdi
  711e1a:	74 a9                	je     711dc5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x485>
  711e1c:	b0 01                	mov    $0x1,%al
  711e1e:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  711e23:	84 c0                	test   %al,%al
  711e25:	74 a7                	je     711dce <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x48e>
  711e27:	ff 15 2b 63 3d 00    	call   *0x3d632b(%rip)        # ae8158 <_DYNAMIC+0x6d8>
  711e2d:	0f 0b                	ud2
  711e2f:	49 89 c4             	mov    %rax,%r12
  711e32:	49 c1 e5 03          	shl    $0x3,%r13
  711e36:	4a 8d 14 6d 00 00 00 	lea    0x0(,%r13,2),%rdx
  711e3d:	00 
  711e3e:	4c 01 ea             	add    %r13,%rdx
  711e41:	4c 89 f7             	mov    %r14,%rdi
  711e44:	48 89 de             	mov    %rbx,%rsi
  711e47:	ff 15 a3 5e 3d 00    	call   *0x3d5ea3(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  711e4d:	4c 89 e7             	mov    %r12,%rdi
  711e50:	e8 fb 65 3a 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
