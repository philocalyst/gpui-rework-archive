
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006f2fc0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>:
  6f2fc0:	55                   	push   %rbp
  6f2fc1:	41 57                	push   %r15
  6f2fc3:	41 56                	push   %r14
  6f2fc5:	41 55                	push   %r13
  6f2fc7:	41 54                	push   %r12
  6f2fc9:	53                   	push   %rbx
  6f2fca:	48 81 ec 58 01 00 00 	sub    $0x158,%rsp
  6f2fd1:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f2fd8:	00 
  6f2fd9:	49 89 f4             	mov    %rsi,%r12
  6f2fdc:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  6f2fe3:	00 
  6f2fe4:	48 8b 2e             	mov    (%rsi),%rbp
  6f2fe7:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f2feb:	0f b7 9d c2 01 00 00 	movzwl 0x1c2(%rbp),%ebx
  6f2ff2:	4a 8d bc ed 68 01 00 	lea    0x168(%rbp,%r13,8),%rdi
  6f2ff9:	00 
  6f2ffa:	4a 8b 84 ed 68 01 00 	mov    0x168(%rbp,%r13,8),%rax
  6f3001:	00 
  6f3002:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f3007:	4a 8d 34 ed 70 01 00 	lea    0x170(,%r13,8),%rsi
  6f300e:	00 
  6f300f:	48 01 ee             	add    %rbp,%rsi
  6f3012:	4d 89 ef             	mov    %r13,%r15
  6f3015:	49 f7 d7             	not    %r15
  6f3018:	49 01 df             	add    %rbx,%r15
  6f301b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f3022:	00 
  6f3023:	4c 8b 35 b6 78 3f 00 	mov    0x3f78b6(%rip),%r14        # aea8e0 <memmove@GLIBC_2.2.5>
  6f302a:	41 ff d6             	call   *%r14
  6f302d:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  6f3032:	4c 89 e8             	mov    %r13,%rax
  6f3035:	48 c1 e0 05          	shl    $0x5,%rax
  6f3039:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f303d:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f3042:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f3047:	0f 11 8c 24 e8 00 00 	movups %xmm1,0xe8(%rsp)
  6f304e:	00 
  6f304f:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f3056:	00 
  6f3057:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f305b:	48 83 c6 20          	add    $0x20,%rsi
  6f305f:	49 c1 e7 05          	shl    $0x5,%r15
  6f3063:	4c 89 fa             	mov    %r15,%rdx
  6f3066:	41 ff d6             	call   *%r14
  6f3069:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f306c:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  6f3071:	66 89 85 c2 01 00 00 	mov    %ax,0x1c2(%rbp)
  6f3078:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
  6f307d:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6f3082:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f3089:	00 
  6f308a:	66 83 f8 04          	cmp    $0x4,%ax
  6f308e:	0f 87 77 01 00 00    	ja     6f320b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f3094:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f3099:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6f30a0:	48 85 c0             	test   %rax,%rax
  6f30a3:	0f 84 16 01 00 00    	je     6f31bf <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1ff>
  6f30a9:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
  6f30ad:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f30b2:	0f b7 92 c0 01 00 00 	movzwl 0x1c0(%rdx),%edx
  6f30b9:	48 85 d2             	test   %rdx,%rdx
  6f30bc:	74 63                	je     6f3121 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x161>
  6f30be:	48 8b b4 d0 c0 01 00 	mov    0x1c0(%rax,%rdx,8),%rsi
  6f30c5:	00 
  6f30c6:	48 ff ca             	dec    %rdx
  6f30c9:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f30ce:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6f30d3:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
  6f30d8:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6f30dd:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f30e2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f30e7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f30ec:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f30f1:	0f b7 86 c2 01 00 00 	movzwl 0x1c2(%rsi),%eax
  6f30f8:	01 c3                	add    %eax,%ebx
  6f30fa:	83 fb 0c             	cmp    $0xc,%ebx
  6f30fd:	0f 83 85 00 00 00    	jae    6f3188 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1c8>
  6f3103:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f3108:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6f310d:	ba 01 00 00 00       	mov    $0x1,%edx
  6f3112:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f3117:	e8 54 94 ff ff       	call   6ec570 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f311c:	e9 b7 00 00 00       	jmp    6f31d8 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x218>
  6f3121:	66 83 b8 c2 01 00 00 	cmpw   $0x0,0x1c2(%rax)
  6f3128:	00 
  6f3129:	0f 84 e3 06 00 00    	je     6f3812 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x852>
  6f312f:	48 8b 90 d0 01 00 00 	mov    0x1d0(%rax),%rdx
  6f3136:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f313b:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6f3140:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f3147:	00 00 
  6f3149:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f314e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f3153:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f3158:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6f315d:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f3162:	0f b7 82 c2 01 00 00 	movzwl 0x1c2(%rdx),%eax
  6f3169:	01 c3                	add    %eax,%ebx
  6f316b:	83 fb 0c             	cmp    $0xc,%ebx
  6f316e:	73 40                	jae    6f31b0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1f0>
  6f3170:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f3175:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6f317a:	31 d2                	xor    %edx,%edx
  6f317c:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f3181:	e8 ea 93 ff ff       	call   6ec570 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f3186:	eb 50                	jmp    6f31d8 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x218>
  6f3188:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f318d:	be 01 00 00 00       	mov    $0x1,%esi
  6f3192:	e8 59 22 00 00       	call   6f53f0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f3197:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f319c:	48 ff c0             	inc    %rax
  6f319f:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f31a4:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f31a9:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  6f31ae:	eb 23                	jmp    6f31d3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x213>
  6f31b0:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f31b5:	be 01 00 00 00       	mov    $0x1,%esi
  6f31ba:	e8 71 25 00 00       	call   6f5730 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f31bf:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f31c4:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6f31c9:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  6f31ce:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f31d3:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f31d8:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6f31dd:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  6f31e2:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6f31e7:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f31ec:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  6f31f1:	4c 8b b1 60 01 00 00 	mov    0x160(%rcx),%r14
  6f31f8:	4d 85 f6             	test   %r14,%r14
  6f31fb:	74 0e                	je     6f320b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f31fd:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f3204:	00 
  6f3205:	66 83 f8 04          	cmp    $0x4,%ax
  6f3209:	76 5f                	jbe    6f326a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2aa>
  6f320b:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  6f3212:	00 
  6f3213:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  6f321a:	00 
  6f321b:	48 89 42 20          	mov    %rax,0x20(%rdx)
  6f321f:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6f3226:	00 
  6f3227:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  6f322e:	00 
  6f322f:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6f3236:	00 
  6f3237:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f323b:	48 89 02             	mov    %rax,(%rdx)
  6f323e:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f3242:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f3247:	48 89 42 28          	mov    %rax,0x28(%rdx)
  6f324b:	48 89 6a 30          	mov    %rbp,0x30(%rdx)
  6f324f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f3254:	48 89 42 38          	mov    %rax,0x38(%rdx)
  6f3258:	48 81 c4 58 01 00 00 	add    $0x158,%rsp
  6f325f:	5b                   	pop    %rbx
  6f3260:	41 5c                	pop    %r12
  6f3262:	41 5d                	pop    %r13
  6f3264:	41 5e                	pop    %r14
  6f3266:	41 5f                	pop    %r15
  6f3268:	5d                   	pop    %rbp
  6f3269:	c3                   	ret
  6f326a:	4c 8d 65 01          	lea    0x1(%rbp),%r12
  6f326e:	48 8d 0d 7b 92 3c 00 	lea    0x3c927b(%rip),%rcx        # abc4f0 <__frame_dummy_init_array_entry+0x98>
  6f3275:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  6f327c:	00 
  6f327d:	48 8d 0d c4 03 97 ff 	lea    -0x68fc3c(%rip),%rcx        # 63648 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f3284:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6f328b:	00 
  6f328c:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  6f3293:	00 
  6f3294:	eb 2a                	jmp    6f32c0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x300>
  6f3296:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f329d:	00 00 00 
  6f32a0:	ba 08 00 00 00       	mov    $0x8,%edx
  6f32a5:	4c 89 ef             	mov    %r13,%rdi
  6f32a8:	ff 15 12 76 3f 00    	call   *0x3f7612(%rip)        # aea8c0 <_DYNAMIC+0x248>
  6f32ae:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f32b5:	00 
  6f32b6:	66 83 f8 04          	cmp    $0x4,%ax
  6f32ba:	0f 87 4b ff ff ff    	ja     6f320b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f32c0:	4c 89 f1             	mov    %r14,%rcx
  6f32c3:	0f b7 c0             	movzwl %ax,%eax
  6f32c6:	4d 8b b6 60 01 00 00 	mov    0x160(%r14),%r14
  6f32cd:	4d 85 f6             	test   %r14,%r14
  6f32d0:	0f 84 86 04 00 00    	je     6f375c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x79c>
  6f32d6:	4c 89 e6             	mov    %r12,%rsi
  6f32d9:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  6f32de:	44 0f b7 a9 c0 01 00 	movzwl 0x1c0(%rcx),%r13d
  6f32e5:	00 
  6f32e6:	4d 85 ed             	test   %r13,%r13
  6f32e9:	48 89 bc 24 c8 00 00 	mov    %rdi,0xc8(%rsp)
  6f32f0:	00 
  6f32f1:	0f 84 89 00 00 00    	je     6f3380 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x3c0>
  6f32f7:	4b 8b 9c ee c0 01 00 	mov    0x1c0(%r14,%r13,8),%rbx
  6f32fe:	00 
  6f32ff:	49 ff cd             	dec    %r13
  6f3302:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  6f3309:	00 
  6f330a:	48 89 bc 24 00 01 00 	mov    %rdi,0x100(%rsp)
  6f3311:	00 
  6f3312:	4c 89 ac 24 08 01 00 	mov    %r13,0x108(%rsp)
  6f3319:	00 
  6f331a:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
  6f3321:	00 
  6f3322:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
  6f3329:	00 
  6f332a:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6f3331:	00 
  6f3332:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
  6f3339:	00 
  6f333a:	0f b7 b3 c2 01 00 00 	movzwl 0x1c2(%rbx),%esi
  6f3341:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f3344:	ff c2                	inc    %edx
  6f3346:	83 fa 0c             	cmp    $0xc,%edx
  6f3349:	0f 83 75 04 00 00    	jae    6f37c4 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x804>
  6f334f:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f3356:	00 
  6f3357:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f335b:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  6f3360:	49 89 f4             	mov    %rsi,%r12
  6f3363:	48 01 c6             	add    %rax,%rsi
  6f3366:	48 ff c6             	inc    %rsi
  6f3369:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6f336e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6f3373:	eb 7f                	jmp    6f33f4 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x434>
  6f3375:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f337c:	00 00 00 00 
  6f3380:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f3387:	00 
  6f3388:	66 85 d2             	test   %dx,%dx
  6f338b:	0f 84 81 04 00 00    	je     6f3812 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x852>
  6f3391:	4d 8b 86 d0 01 00 00 	mov    0x1d0(%r14),%r8
  6f3398:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
  6f339d:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
  6f33a2:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f33a9:	00 00 
  6f33ab:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  6f33b0:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  6f33b5:	4c 89 44 24 70       	mov    %r8,0x70(%rsp)
  6f33ba:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6f33bf:	45 0f b7 88 c2 01 00 	movzwl 0x1c2(%r8),%r9d
  6f33c6:	00 
  6f33c7:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f33cb:	48 ff c6             	inc    %rsi
  6f33ce:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f33d2:	0f 83 06 04 00 00    	jae    6f37de <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x81e>
  6f33d8:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f33dc:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  6f33e1:	48 89 cb             	mov    %rcx,%rbx
  6f33e4:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  6f33e9:	45 31 ed             	xor    %r13d,%r13d
  6f33ec:	49 89 c4             	mov    %rax,%r12
  6f33ef:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  6f33f4:	0f b7 c2             	movzwl %dx,%eax
  6f33f7:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f33fe:	00 
  6f33ff:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
  6f3406:	00 
  6f3407:	66 89 b3 c2 01 00 00 	mov    %si,0x1c2(%rbx)
  6f340e:	4b 8d 3c ee          	lea    (%r14,%r13,8),%rdi
  6f3412:	48 81 c7 68 01 00 00 	add    $0x168,%rdi
  6f3419:	4b 8b ac ee 68 01 00 	mov    0x168(%r14,%r13,8),%rbp
  6f3420:	00 
  6f3421:	4b 8d 34 ee          	lea    (%r14,%r13,8),%rsi
  6f3425:	48 81 c6 70 01 00 00 	add    $0x170,%rsi
  6f342c:	4d 89 ef             	mov    %r13,%r15
  6f342f:	49 f7 d7             	not    %r15
  6f3432:	49 01 c7             	add    %rax,%r15
  6f3435:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f343c:	00 
  6f343d:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  6f3444:	00 
  6f3445:	48 8b 05 94 74 3f 00 	mov    0x3f7494(%rip),%rax        # aea8e0 <memmove@GLIBC_2.2.5>
  6f344c:	ff d0                	call   *%rax
  6f344e:	4a 89 ac e3 68 01 00 	mov    %rbp,0x168(%rbx,%r12,8)
  6f3455:	00 
  6f3456:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f345b:	48 8d b0 68 01 00 00 	lea    0x168(%rax),%rsi
  6f3462:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f3467:	48 8d bc c3 68 01 00 	lea    0x168(%rbx,%rax,8),%rdi
  6f346e:	00 
  6f346f:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6f3474:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f347b:	48 8b 2d 66 74 3f 00 	mov    0x3f7466(%rip),%rbp        # aea8e8 <memcpy@GLIBC_2.14>
  6f3482:	ff d5                	call   *%rbp
  6f3484:	4c 89 e8             	mov    %r13,%rax
  6f3487:	48 c1 e0 05          	shl    $0x5,%rax
  6f348b:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f348f:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f3494:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f349a:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  6f34a1:	00 
  6f34a2:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  6f34a9:	00 
  6f34aa:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f34ae:	48 83 c6 20          	add    $0x20,%rsi
  6f34b2:	49 c1 e7 05          	shl    $0x5,%r15
  6f34b6:	4c 89 fa             	mov    %r15,%rdx
  6f34b9:	48 8b 2d 20 74 3f 00 	mov    0x3f7420(%rip),%rbp        # aea8e0 <memmove@GLIBC_2.2.5>
  6f34c0:	ff d5                	call   *%rbp
  6f34c2:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
  6f34c9:	00 
  6f34ca:	41 c1 e4 05          	shl    $0x5,%r12d
  6f34ce:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  6f34d5:	00 
  6f34d6:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
  6f34dd:	00 
  6f34de:	42 0f 11 04 23       	movups %xmm0,(%rbx,%r12,1)
  6f34e3:	42 0f 11 4c 23 10    	movups %xmm1,0x10(%rbx,%r12,1)
  6f34e9:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f34ee:	c1 e7 05             	shl    $0x5,%edi
  6f34f1:	48 01 df             	add    %rbx,%rdi
  6f34f4:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6f34f9:	c1 e2 05             	shl    $0x5,%edx
  6f34fc:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6f3501:	ff 15 e1 73 3f 00    	call   *0x3f73e1(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  6f3507:	4d 8d 7d 01          	lea    0x1(%r13),%r15
  6f350b:	4b 8d 3c ee          	lea    (%r14,%r13,8),%rdi
  6f350f:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6f3516:	4b 8d 34 ee          	lea    (%r14,%r13,8),%rsi
  6f351a:	48 81 c6 d8 01 00 00 	add    $0x1d8,%rsi
  6f3521:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  6f3528:	00 
  6f3529:	ff d5                	call   *%rbp
  6f352b:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6f3532:	00 
  6f3533:	4c 39 fe             	cmp    %r15,%rsi
  6f3536:	0f 86 be 00 00 00    	jbe    6f35fa <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f353c:	89 f1                	mov    %esi,%ecx
  6f353e:	44 29 f9             	sub    %r15d,%ecx
  6f3541:	83 e1 03             	and    $0x3,%ecx
  6f3544:	0f 84 f6 01 00 00    	je     6f3740 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x780>
  6f354a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f3550:	49 8d 47 01          	lea    0x1(%r15),%rax
  6f3554:	4b 8b 94 fe c8 01 00 	mov    0x1c8(%r14,%r15,8),%rdx
  6f355b:	00 
  6f355c:	4c 89 b2 60 01 00 00 	mov    %r14,0x160(%rdx)
  6f3563:	66 44 89 ba c0 01 00 	mov    %r15w,0x1c0(%rdx)
  6f356a:	00 
  6f356b:	49 89 c7             	mov    %rax,%r15
  6f356e:	48 ff c9             	dec    %rcx
  6f3571:	75 dd                	jne    6f3550 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x590>
  6f3573:	49 f7 dd             	neg    %r13
  6f3576:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
  6f357a:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f357e:	83 f9 03             	cmp    $0x3,%ecx
  6f3581:	72 77                	jb     6f35fa <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f3583:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f358a:	84 00 00 00 00 00 
  6f3590:	49 8b 8c c6 c8 01 00 	mov    0x1c8(%r14,%rax,8),%rcx
  6f3597:	00 
  6f3598:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f359f:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f35a6:	49 8b 8c c6 d0 01 00 	mov    0x1d0(%r14,%rax,8),%rcx
  6f35ad:	00 
  6f35ae:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f35b5:	8d 50 01             	lea    0x1(%rax),%edx
  6f35b8:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f35bf:	49 8b 8c c6 d8 01 00 	mov    0x1d8(%r14,%rax,8),%rcx
  6f35c6:	00 
  6f35c7:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f35ce:	8d 50 02             	lea    0x2(%rax),%edx
  6f35d1:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f35d8:	49 8b 8c c6 e0 01 00 	mov    0x1e0(%r14,%rax,8),%rcx
  6f35df:	00 
  6f35e0:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f35e7:	8d 50 03             	lea    0x3(%rax),%edx
  6f35ea:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f35f1:	48 83 c0 04          	add    $0x4,%rax
  6f35f5:	48 39 f0             	cmp    %rsi,%rax
  6f35f8:	75 96                	jne    6f3590 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x5d0>
  6f35fa:	66 41 ff 8e c2 01 00 	decw   0x1c2(%r14)
  6f3601:	00 
  6f3602:	be c8 01 00 00       	mov    $0x1c8,%esi
  6f3607:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
  6f360e:	00 
  6f360f:	49 83 fc 02          	cmp    $0x2,%r12
  6f3613:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  6f361a:	00 
  6f361b:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
  6f3620:	0f 82 7a fc ff ff    	jb     6f32a0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f3626:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6f362b:	48 ff c2             	inc    %rdx
  6f362e:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f3635:	00 
  6f3636:	48 2b 84 24 b0 00 00 	sub    0xb0(%rsp),%rax
  6f363d:	00 
  6f363e:	48 39 c2             	cmp    %rax,%rdx
  6f3641:	0f 85 ae 01 00 00    	jne    6f37f5 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x835>
  6f3647:	48 8d 83 c8 01 00 00 	lea    0x1c8(%rbx),%rax
  6f364e:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6f3653:	4a 8d 3c f8          	lea    (%rax,%r15,8),%rdi
  6f3657:	49 8d b5 c8 01 00 00 	lea    0x1c8(%r13),%rsi
  6f365e:	c1 e2 03             	shl    $0x3,%edx
  6f3661:	ff 15 81 72 3f 00    	call   *0x3f7281(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  6f3667:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  6f366e:	00 
  6f366f:	89 f9                	mov    %edi,%ecx
  6f3671:	44 29 f9             	sub    %r15d,%ecx
  6f3674:	ff c1                	inc    %ecx
  6f3676:	4c 89 f8             	mov    %r15,%rax
  6f3679:	83 e1 03             	and    $0x3,%ecx
  6f367c:	74 34                	je     6f36b2 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x6f2>
  6f367e:	4c 89 fa             	mov    %r15,%rdx
  6f3681:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f3688:	0f 1f 84 00 00 00 00 
  6f368f:	00 
  6f3690:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f3694:	48 8b b4 d3 c8 01 00 	mov    0x1c8(%rbx,%rdx,8),%rsi
  6f369b:	00 
  6f369c:	48 89 9e 60 01 00 00 	mov    %rbx,0x160(%rsi)
  6f36a3:	66 89 96 c0 01 00 00 	mov    %dx,0x1c0(%rsi)
  6f36aa:	48 89 c2             	mov    %rax,%rdx
  6f36ad:	48 ff c9             	dec    %rcx
  6f36b0:	75 de                	jne    6f3690 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x6d0>
  6f36b2:	48 89 f9             	mov    %rdi,%rcx
  6f36b5:	4c 29 f9             	sub    %r15,%rcx
  6f36b8:	be 28 02 00 00       	mov    $0x228,%esi
  6f36bd:	83 f9 03             	cmp    $0x3,%ecx
  6f36c0:	0f 82 da fb ff ff    	jb     6f32a0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f36c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f36cd:	00 00 00 
  6f36d0:	48 8b 8c c3 c8 01 00 	mov    0x1c8(%rbx,%rax,8),%rcx
  6f36d7:	00 
  6f36d8:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f36df:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f36e6:	48 8b 8c c3 d0 01 00 	mov    0x1d0(%rbx,%rax,8),%rcx
  6f36ed:	00 
  6f36ee:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f36f5:	8d 50 01             	lea    0x1(%rax),%edx
  6f36f8:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f36ff:	48 8b 8c c3 d8 01 00 	mov    0x1d8(%rbx,%rax,8),%rcx
  6f3706:	00 
  6f3707:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f370e:	8d 50 02             	lea    0x2(%rax),%edx
  6f3711:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f3718:	48 8b 8c c3 e0 01 00 	mov    0x1e0(%rbx,%rax,8),%rcx
  6f371f:	00 
  6f3720:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f3727:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f372b:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f3732:	48 83 c0 04          	add    $0x4,%rax
  6f3736:	48 39 fa             	cmp    %rdi,%rdx
  6f3739:	75 95                	jne    6f36d0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x710>
  6f373b:	e9 60 fb ff ff       	jmp    6f32a0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f3740:	4c 89 f8             	mov    %r15,%rax
  6f3743:	49 f7 dd             	neg    %r13
  6f3746:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
  6f374a:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f374e:	83 f9 03             	cmp    $0x3,%ecx
  6f3751:	0f 83 39 fe ff ff    	jae    6f3590 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x5d0>
  6f3757:	e9 9e fe ff ff       	jmp    6f35fa <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f375c:	48 85 c0             	test   %rax,%rax
  6f375f:	0f 85 a6 fa ff ff    	jne    6f320b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f3765:	4c 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14
  6f376c:	00 
  6f376d:	49 8b 1e             	mov    (%r14),%rbx
  6f3770:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f3777:	48 85 db             	test   %rbx,%rbx
  6f377a:	0f 84 ad 00 00 00    	je     6f382d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x86d>
  6f3780:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f3784:	48 85 c0             	test   %rax,%rax
  6f3787:	0f 84 af 00 00 00    	je     6f383c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87c>
  6f378d:	48 8b 3b             	mov    (%rbx),%rdi
  6f3790:	48 8b 8f c8 01 00 00 	mov    0x1c8(%rdi),%rcx
  6f3797:	48 89 0b             	mov    %rcx,(%rbx)
  6f379a:	48 ff c8             	dec    %rax
  6f379d:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f37a1:	48 c7 81 60 01 00 00 	movq   $0x0,0x160(%rcx)
  6f37a8:	00 00 00 00 
  6f37ac:	be 28 02 00 00       	mov    $0x228,%esi
  6f37b1:	ba 08 00 00 00       	mov    $0x8,%edx
  6f37b6:	ff 15 04 71 3f 00    	call   *0x3f7104(%rip)        # aea8c0 <_DYNAMIC+0x248>
  6f37bc:	49 89 1e             	mov    %rbx,(%r14)
  6f37bf:	e9 47 fa ff ff       	jmp    6f320b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f37c4:	be 05 00 00 00       	mov    $0x5,%esi
  6f37c9:	48 29 c6             	sub    %rax,%rsi
  6f37cc:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  6f37d3:	00 
  6f37d4:	e8 17 1c 00 00       	call   6f53f0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f37d9:	e9 2d fa ff ff       	jmp    6f320b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f37de:	be 05 00 00 00       	mov    $0x5,%esi
  6f37e3:	48 29 c6             	sub    %rax,%rsi
  6f37e6:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f37eb:	e8 40 1f 00 00       	call   6f5730 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f37f0:	e9 16 fa ff ff       	jmp    6f320b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f37f5:	be 28 00 00 00       	mov    $0x28,%esi
  6f37fa:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  6f3801:	00 
  6f3802:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
  6f3809:	00 
  6f380a:	ff 15 e8 70 3f 00    	call   *0x3f70e8(%rip)        # aea8f8 <_DYNAMIC+0x280>
  6f3810:	eb 28                	jmp    6f383a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87a>
  6f3812:	48 8d 3d 4c ff 96 ff 	lea    -0x6900b4(%rip),%rdi        # 63765 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f3819:	48 8d 15 d8 8d 3c 00 	lea    0x3c8dd8(%rip),%rdx        # abc5f8 <__frame_dummy_init_array_entry+0x1a0>
  6f3820:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f3825:	ff 15 ed 70 3f 00    	call   *0x3f70ed(%rip)        # aea918 <_DYNAMIC+0x2a0>
  6f382b:	eb 0d                	jmp    6f383a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87a>
  6f382d:	48 8d 3d d4 8c 3c 00 	lea    0x3c8cd4(%rip),%rdi        # abc508 <__frame_dummy_init_array_entry+0xb0>
  6f3834:	ff 15 c6 70 3f 00    	call   *0x3f70c6(%rip)        # aea900 <_DYNAMIC+0x288>
  6f383a:	0f 0b                	ud2
  6f383c:	48 8d 05 95 8c 3c 00 	lea    0x3c8c95(%rip),%rax        # abc4d8 <__frame_dummy_init_array_entry+0x80>
  6f3843:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6f384a:	00 
  6f384b:	be 21 00 00 00       	mov    $0x21,%esi
  6f3850:	48 8d 05 d0 fd 96 ff 	lea    -0x690230(%rip),%rax        # 63627 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f3857:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f385e:	00 
  6f385f:	eb 99                	jmp    6f37fa <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x83a>
  6f3861:	48 89 c3             	mov    %rax,%rbx
  6f3864:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  6f386b:	00 
  6f386c:	e8 df 1a 00 00       	call   6f5350 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueTyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtB4_6option6OptionNtNtBJ_11shared_text10SharedTextEEj2_EECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f3871:	48 89 df             	mov    %rbx,%rdi
  6f3874:	e8 27 78 3c 00       	call   abb0a0 <_Unwind_Resume@plt>
  6f3879:	ff 15 91 70 3f 00    	call   *0x3f7091(%rip)        # aea910 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
