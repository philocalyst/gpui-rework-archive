
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000072e140 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_>:
  72e140:	48 83 fe 02          	cmp    $0x2,%rsi
  72e144:	0f 82 fb 00 00 00    	jb     72e245 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x105>
  72e14a:	49 89 d0             	mov    %rdx,%r8
  72e14d:	48 8b 07             	mov    (%rdi),%rax
  72e150:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  72e154:	ba 02 00 00 00       	mov    $0x2,%edx
  72e159:	48 39 c1             	cmp    %rax,%rcx
  72e15c:	73 2b                	jae    72e189 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x49>
  72e15e:	48 83 fe 02          	cmp    $0x2,%rsi
  72e162:	74 2b                	je     72e18f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x4f>
  72e164:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  72e168:	49 89 ca             	mov    %rcx,%r10
  72e16b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72e170:	4d 89 d3             	mov    %r10,%r11
  72e173:	4d 8b 11             	mov    (%r9),%r10
  72e176:	4d 39 da             	cmp    %r11,%r10
  72e179:	73 14                	jae    72e18f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x4f>
  72e17b:	48 ff c2             	inc    %rdx
  72e17e:	49 83 c1 18          	add    $0x18,%r9
  72e182:	48 39 d6             	cmp    %rdx,%rsi
  72e185:	75 e9                	jne    72e170 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x30>
  72e187:	eb 4e                	jmp    72e1d7 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x97>
  72e189:	48 83 fe 02          	cmp    $0x2,%rsi
  72e18d:	75 1f                	jne    72e1ae <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x6e>
  72e18f:	48 39 f2             	cmp    %rsi,%rdx
  72e192:	74 43                	je     72e1d7 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x97>
  72e194:	48 89 f0             	mov    %rsi,%rax
  72e197:	48 83 c8 01          	or     $0x1,%rax
  72e19b:	48 0f bd c8          	bsr    %rax,%rcx
  72e19f:	83 f1 3f             	xor    $0x3f,%ecx
  72e1a2:	01 c9                	add    %ecx,%ecx
  72e1a4:	83 f1 7e             	xor    $0x7e,%ecx
  72e1a7:	31 d2                	xor    %edx,%edx
  72e1a9:	e9 32 ac ff ff       	jmp    728de0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB30_>
  72e1ae:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  72e1b2:	49 89 ca             	mov    %rcx,%r10
  72e1b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72e1bc:	00 00 00 00 
  72e1c0:	4d 89 d3             	mov    %r10,%r11
  72e1c3:	4d 8b 11             	mov    (%r9),%r10
  72e1c6:	4d 39 da             	cmp    %r11,%r10
  72e1c9:	72 c4                	jb     72e18f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x4f>
  72e1cb:	48 ff c2             	inc    %rdx
  72e1ce:	49 83 c1 18          	add    $0x18,%r9
  72e1d2:	48 39 d6             	cmp    %rdx,%rsi
  72e1d5:	75 e9                	jne    72e1c0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x80>
  72e1d7:	48 39 c1             	cmp    %rax,%rcx
  72e1da:	73 69                	jae    72e245 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0x105>
  72e1dc:	48 8d 04 b5 00 00 00 	lea    0x0(,%rsi,4),%rax
  72e1e3:	00 
  72e1e4:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
  72e1e8:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  72e1ec:	48 8d 0c 76          	lea    (%rsi,%rsi,2),%rcx
  72e1f0:	48 8d 0c cd e8 ff ff 	lea    -0x18(,%rcx,8),%rcx
  72e1f7:	ff 
  72e1f8:	31 d2                	xor    %edx,%edx
  72e1fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  72e200:	48 8b 34 17          	mov    (%rdi,%rdx,1),%rsi
  72e204:	4c 8b 04 0f          	mov    (%rdi,%rcx,1),%r8
  72e208:	4c 89 04 17          	mov    %r8,(%rdi,%rdx,1)
  72e20c:	48 89 34 0f          	mov    %rsi,(%rdi,%rcx,1)
  72e210:	48 8b 74 17 08       	mov    0x8(%rdi,%rdx,1),%rsi
  72e215:	4c 8b 44 0f 08       	mov    0x8(%rdi,%rcx,1),%r8
  72e21a:	4c 89 44 17 08       	mov    %r8,0x8(%rdi,%rdx,1)
  72e21f:	48 89 74 0f 08       	mov    %rsi,0x8(%rdi,%rcx,1)
  72e224:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
  72e229:	4c 8b 44 0f 10       	mov    0x10(%rdi,%rcx,1),%r8
  72e22e:	4c 89 44 17 10       	mov    %r8,0x10(%rdi,%rdx,1)
  72e233:	48 89 74 0f 10       	mov    %rsi,0x10(%rdi,%rcx,1)
  72e238:	48 83 c2 18          	add    $0x18,%rdx
  72e23c:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72e240:	48 39 d0             	cmp    %rdx,%rax
  72e243:	75 bb                	jne    72e200 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_+0xc0>
  72e245:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
