
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000072ab60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>:
  72ab60:	55                   	push   %rbp
  72ab61:	41 57                	push   %r15
  72ab63:	41 56                	push   %r14
  72ab65:	41 55                	push   %r13
  72ab67:	41 54                	push   %r12
  72ab69:	53                   	push   %rbx
  72ab6a:	48 83 ec 58          	sub    $0x58,%rsp
  72ab6e:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  72ab73:	49 89 ce             	mov    %rcx,%r14
  72ab76:	49 89 d7             	mov    %rdx,%r15
  72ab79:	49 89 f5             	mov    %rsi,%r13
  72ab7c:	49 89 fc             	mov    %rdi,%r12
  72ab7f:	48 83 fe 21          	cmp    $0x21,%rsi
  72ab83:	73 1e                	jae    72aba3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x43>
  72ab85:	4c 89 e7             	mov    %r12,%rdi
  72ab88:	4c 89 ee             	mov    %r13,%rsi
  72ab8b:	4c 89 fa             	mov    %r15,%rdx
  72ab8e:	4c 89 f1             	mov    %r14,%rcx
  72ab91:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  72ab98:	00 
  72ab99:	e8 d2 88 fe ff       	call   713470 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2c_11collections5btree3mapINtB2Y_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB3Y_8adapters3map3MapINtNtB8_4iter4IterNtB1w_9ListDraftENCNvMst_NtB1y_7runtimeINtB5Z_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6u_>
  72ab9e:	e9 a9 05 00 00       	jmp    72b14c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5ec>
  72aba3:	44 89 c3             	mov    %r8d,%ebx
  72aba6:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  72abab:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72abb0:	85 db                	test   %ebx,%ebx
  72abb2:	0f 84 73 05 00 00    	je     72b12b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5cb>
  72abb8:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72abbd:	48 89 f1             	mov    %rsi,%rcx
  72abc0:	48 c1 e9 03          	shr    $0x3,%rcx
  72abc4:	48 89 c8             	mov    %rcx,%rax
  72abc7:	48 c1 e0 06          	shl    $0x6,%rax
  72abcb:	4c 01 e0             	add    %r12,%rax
  72abce:	48 6b d1 70          	imul   $0x70,%rcx,%rdx
  72abd2:	4c 01 e2             	add    %r12,%rdx
  72abd5:	48 83 fe 40          	cmp    $0x40,%rsi
  72abd9:	73 35                	jae    72ac10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xb0>
  72abdb:	49 8b 0c 24          	mov    (%r12),%rcx
  72abdf:	48 8b 30             	mov    (%rax),%rsi
  72abe2:	48 39 f1             	cmp    %rsi,%rcx
  72abe5:	40 0f 92 c7          	setb   %dil
  72abe9:	4c 8b 02             	mov    (%rdx),%r8
  72abec:	4c 39 c1             	cmp    %r8,%rcx
  72abef:	0f 92 c1             	setb   %cl
  72abf2:	40 30 f9             	xor    %dil,%cl
  72abf5:	4c 39 c6             	cmp    %r8,%rsi
  72abf8:	40 0f 92 c6          	setb   %sil
  72abfc:	40 30 fe             	xor    %dil,%sil
  72abff:	48 0f 45 c2          	cmovne %rdx,%rax
  72ac03:	84 c9                	test   %cl,%cl
  72ac05:	49 0f 45 c4          	cmovne %r12,%rax
  72ac09:	eb 10                	jmp    72ac1b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xbb>
  72ac0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72ac10:	4c 89 e7             	mov    %r12,%rdi
  72ac13:	48 89 c6             	mov    %rax,%rsi
  72ac16:	e8 e5 f1 ff ff       	call   729e00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72ac1b:	ff cb                	dec    %ebx
  72ac1d:	89 5c 24 2c          	mov    %ebx,0x2c(%rsp)
  72ac21:	48 89 c5             	mov    %rax,%rbp
  72ac24:	4c 29 e5             	sub    %r12,%rbp
  72ac27:	48 89 e9             	mov    %rbp,%rcx
  72ac2a:	48 c1 e9 04          	shr    $0x4,%rcx
  72ac2e:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  72ac33:	0f 10 00             	movups (%rax),%xmm0
  72ac36:	48 8b 00             	mov    (%rax),%rax
  72ac39:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  72ac3e:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  72ac44:	74 0e                	je     72ac54 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xf4>
  72ac46:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  72ac4b:	48 39 01             	cmp    %rax,(%rcx)
  72ac4e:	0f 83 8c 02 00 00    	jae    72aee0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x380>
  72ac54:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  72ac59:	49 39 de             	cmp    %rbx,%r14
  72ac5c:	0f 82 0e 05 00 00    	jb     72b170 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x610>
  72ac62:	49 89 de             	mov    %rbx,%r14
  72ac65:	49 c1 e6 04          	shl    $0x4,%r14
  72ac69:	4b 8d 0c 37          	lea    (%r15,%r14,1),%rcx
  72ac6d:	45 31 ed             	xor    %r13d,%r13d
  72ac70:	4c 89 e0             	mov    %r12,%rax
  72ac73:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72ac78:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  72ac7d:	0f 1f 00             	nopl   (%rax)
  72ac80:	48 89 d7             	mov    %rdx,%rdi
  72ac83:	48 83 ef 03          	sub    $0x3,%rdi
  72ac87:	be 00 00 00 00       	mov    $0x0,%esi
  72ac8c:	48 0f 43 f7          	cmovae %rdi,%rsi
  72ac90:	48 c1 e6 04          	shl    $0x4,%rsi
  72ac94:	4c 01 e6             	add    %r12,%rsi
  72ac97:	48 39 f0             	cmp    %rsi,%rax
  72ac9a:	0f 83 a4 00 00 00    	jae    72ad44 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x1e4>
  72aca0:	48 8b 38             	mov    (%rax),%rdi
  72aca3:	4c 8d 41 f0          	lea    -0x10(%rcx),%r8
  72aca7:	45 31 c9             	xor    %r9d,%r9d
  72acaa:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72acae:	4d 0f 42 c7          	cmovb  %r15,%r8
  72acb2:	41 0f 92 c1          	setb   %r9b
  72acb6:	4c 89 ef             	mov    %r13,%rdi
  72acb9:	48 c1 e7 04          	shl    $0x4,%rdi
  72acbd:	4f 8d 14 29          	lea    (%r9,%r13,1),%r10
  72acc1:	4c 8b 58 10          	mov    0x10(%rax),%r11
  72acc5:	49 c1 e2 04          	shl    $0x4,%r10
  72acc9:	4d 3b 1c 2c          	cmp    (%r12,%rbp,1),%r11
  72accd:	0f 10 00             	movups (%rax),%xmm0
  72acd0:	4c 8d 59 e0          	lea    -0x20(%rcx),%r11
  72acd4:	4d 0f 42 df          	cmovb  %r15,%r11
  72acd8:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72acdd:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72ace1:	4d 11 cd             	adc    %r9,%r13
  72ace4:	43 0f 11 04 13       	movups %xmm0,(%r11,%r10,1)
  72ace9:	48 8b 78 20          	mov    0x20(%rax),%rdi
  72aced:	4c 8d 41 d0          	lea    -0x30(%rcx),%r8
  72acf1:	45 31 c9             	xor    %r9d,%r9d
  72acf4:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72acf8:	4d 0f 42 c7          	cmovb  %r15,%r8
  72acfc:	41 0f 92 c1          	setb   %r9b
  72ad00:	4c 89 ef             	mov    %r13,%rdi
  72ad03:	48 c1 e7 04          	shl    $0x4,%rdi
  72ad07:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72ad0b:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72ad10:	4b 8d 3c 29          	lea    (%r9,%r13,1),%rdi
  72ad14:	4c 8b 40 30          	mov    0x30(%rax),%r8
  72ad18:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72ad1c:	48 c1 e7 04          	shl    $0x4,%rdi
  72ad20:	4d 3b 04 2c          	cmp    (%r12,%rbp,1),%r8
  72ad24:	49 89 c8             	mov    %rcx,%r8
  72ad27:	4d 0f 42 c7          	cmovb  %r15,%r8
  72ad2b:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72ad2f:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72ad34:	4d 11 cd             	adc    %r9,%r13
  72ad37:	48 83 c0 40          	add    $0x40,%rax
  72ad3b:	48 39 f0             	cmp    %rsi,%rax
  72ad3e:	0f 82 5c ff ff ff    	jb     72aca0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x140>
  72ad44:	48 89 d6             	mov    %rdx,%rsi
  72ad47:	48 c1 e6 04          	shl    $0x4,%rsi
  72ad4b:	4c 01 e6             	add    %r12,%rsi
  72ad4e:	48 39 f0             	cmp    %rsi,%rax
  72ad51:	73 3b                	jae    72ad8e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x22e>
  72ad53:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72ad5a:	84 00 00 00 00 00 
  72ad60:	48 8b 38             	mov    (%rax),%rdi
  72ad63:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72ad67:	4d 89 e8             	mov    %r13,%r8
  72ad6a:	49 c1 e0 04          	shl    $0x4,%r8
  72ad6e:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72ad72:	48 89 cf             	mov    %rcx,%rdi
  72ad75:	49 0f 42 ff          	cmovb  %r15,%rdi
  72ad79:	0f 10 00             	movups (%rax),%xmm0
  72ad7c:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72ad81:	49 83 d5 00          	adc    $0x0,%r13
  72ad85:	48 83 c0 10          	add    $0x10,%rax
  72ad89:	48 39 f0             	cmp    %rsi,%rax
  72ad8c:	72 d2                	jb     72ad60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x200>
  72ad8e:	48 39 da             	cmp    %rbx,%rdx
  72ad91:	74 2d                	je     72adc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x260>
  72ad93:	4c 89 ea             	mov    %r13,%rdx
  72ad96:	48 c1 e2 04          	shl    $0x4,%rdx
  72ad9a:	0f 10 00             	movups (%rax),%xmm0
  72ad9d:	0f 11 44 11 f0       	movups %xmm0,-0x10(%rcx,%rdx,1)
  72ada2:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72ada6:	48 83 c0 10          	add    $0x10,%rax
  72adaa:	48 89 da             	mov    %rbx,%rdx
  72adad:	e9 ce fe ff ff       	jmp    72ac80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x120>
  72adb2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72adb9:	1f 84 00 00 00 00 00 
  72adc0:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  72adc5:	4c 89 eb             	mov    %r13,%rbx
  72adc8:	48 c1 e3 04          	shl    $0x4,%rbx
  72adcc:	4c 89 e7             	mov    %r12,%rdi
  72adcf:	4c 89 fe             	mov    %r15,%rsi
  72add2:	48 89 da             	mov    %rbx,%rdx
  72add5:	ff 15 0d fb 3b 00    	call   *0x3bfb0d(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  72addb:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72ade0:	4c 29 ee             	sub    %r13,%rsi
  72ade3:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72adea:	ff ff 0f 
  72aded:	4b 8d 3c 37          	lea    (%r15,%r14,1),%rdi
  72adf1:	0f 84 8e 00 00 00    	je     72ae85 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x325>
  72adf7:	49 8d 45 01          	lea    0x1(%r13),%rax
  72adfb:	48 39 44 24 10       	cmp    %rax,0x10(%rsp)
  72ae00:	75 0e                	jne    72ae10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x2b0>
  72ae02:	31 c0                	xor    %eax,%eax
  72ae04:	eb 65                	jmp    72ae6b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x30b>
  72ae06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72ae0d:	00 00 00 
  72ae10:	48 89 f1             	mov    %rsi,%rcx
  72ae13:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72ae17:	49 8d 44 24 10       	lea    0x10(%r12),%rax
  72ae1c:	48 8d 14 18          	lea    (%rax,%rbx,1),%rdx
  72ae20:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72ae24:	49 01 c6             	add    %rax,%r14
  72ae27:	31 c0                	xor    %eax,%eax
  72ae29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72ae30:	48 89 c7             	mov    %rax,%rdi
  72ae33:	41 0f 10 06          	movups (%r14),%xmm0
  72ae37:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72ae3b:	48 83 c0 02          	add    $0x2,%rax
  72ae3f:	4c 31 c7             	xor    %r8,%rdi
  72ae42:	48 c1 e7 04          	shl    $0x4,%rdi
  72ae46:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72ae4b:	41 0f 10 04 39       	movups (%r9,%rdi,1),%xmm0
  72ae50:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  72ae55:	0f 11 02             	movups %xmm0,(%rdx)
  72ae58:	48 83 c2 20          	add    $0x20,%rdx
  72ae5c:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
  72ae60:	48 39 c1             	cmp    %rax,%rcx
  72ae63:	75 cb                	jne    72ae30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x2d0>
  72ae65:	40 f6 c6 01          	test   $0x1,%sil
  72ae69:	74 1a                	je     72ae85 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x325>
  72ae6b:	49 8d 0c 1c          	lea    (%r12,%rbx,1),%rcx
  72ae6f:	48 89 c2             	mov    %rax,%rdx
  72ae72:	48 f7 d2             	not    %rdx
  72ae75:	48 c1 e2 04          	shl    $0x4,%rdx
  72ae79:	48 c1 e0 04          	shl    $0x4,%rax
  72ae7d:	0f 10 04 17          	movups (%rdi,%rdx,1),%xmm0
  72ae81:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  72ae85:	4d 85 ed             	test   %r13,%r13
  72ae88:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72ae8d:	74 51                	je     72aee0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x380>
  72ae8f:	4c 39 6c 24 10       	cmp    %r13,0x10(%rsp)
  72ae94:	0f 82 d8 02 00 00    	jb     72b172 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x612>
  72ae9a:	4c 01 e3             	add    %r12,%rbx
  72ae9d:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  72aea4:	00 
  72aea5:	48 89 04 24          	mov    %rax,(%rsp)
  72aea9:	48 89 df             	mov    %rbx,%rdi
  72aeac:	4c 89 fa             	mov    %r15,%rdx
  72aeaf:	4c 89 f1             	mov    %r14,%rcx
  72aeb2:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72aeb6:	41 89 d8             	mov    %ebx,%r8d
  72aeb9:	4c 8d 4c 24 40       	lea    0x40(%rsp),%r9
  72aebe:	e8 9d fc ff ff       	call   72ab60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72aec3:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72aec8:	49 83 fd 21          	cmp    $0x21,%r13
  72aecc:	0f 83 de fc ff ff    	jae    72abb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x50>
  72aed2:	e9 ae fc ff ff       	jmp    72ab85 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x25>
  72aed7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72aede:	00 00 
  72aee0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72aee5:	49 39 c6             	cmp    %rax,%r14
  72aee8:	0f 82 82 02 00 00    	jb     72b170 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x610>
  72aeee:	48 c1 e0 04          	shl    $0x4,%rax
  72aef2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72aef7:	49 8d 0c 07          	lea    (%r15,%rax,1),%rcx
  72aefb:	31 db                	xor    %ebx,%ebx
  72aefd:	4c 89 e0             	mov    %r12,%rax
  72af00:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72af05:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
  72af0a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  72af10:	4c 89 d6             	mov    %r10,%rsi
  72af13:	48 83 ee 03          	sub    $0x3,%rsi
  72af17:	ba 00 00 00 00       	mov    $0x0,%edx
  72af1c:	48 0f 43 d6          	cmovae %rsi,%rdx
  72af20:	48 c1 e2 04          	shl    $0x4,%rdx
  72af24:	4c 01 e2             	add    %r12,%rdx
  72af27:	48 39 d0             	cmp    %rdx,%rax
  72af2a:	0f 83 9d 00 00 00    	jae    72afcd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x46d>
  72af30:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72af34:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
  72af38:	49 89 d8             	mov    %rbx,%r8
  72af3b:	49 c1 e0 04          	shl    $0x4,%r8
  72af3f:	48 3b 30             	cmp    (%rax),%rsi
  72af42:	49 0f 43 ff          	cmovae %r15,%rdi
  72af46:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72af4a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72af4e:	49 89 d9             	mov    %rbx,%r9
  72af51:	49 c1 e1 04          	shl    $0x4,%r9
  72af55:	48 3b 70 10          	cmp    0x10(%rax),%rsi
  72af59:	0f 10 00             	movups (%rax),%xmm0
  72af5c:	48 8d 71 e0          	lea    -0x20(%rcx),%rsi
  72af60:	49 0f 43 f7          	cmovae %r15,%rsi
  72af64:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72af69:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72af6d:	49 8b 3c 2c          	mov    (%r12,%rbp,1),%rdi
  72af71:	49 89 d8             	mov    %rbx,%r8
  72af74:	49 c1 e0 04          	shl    $0x4,%r8
  72af78:	48 3b 78 20          	cmp    0x20(%rax),%rdi
  72af7c:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72af80:	48 8d 79 d0          	lea    -0x30(%rcx),%rdi
  72af84:	49 0f 43 ff          	cmovae %r15,%rdi
  72af88:	42 0f 11 04 0e       	movups %xmm0,(%rsi,%r9,1)
  72af8d:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72af91:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72af95:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72af9a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72af9e:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72afa2:	48 89 df             	mov    %rbx,%rdi
  72afa5:	48 c1 e7 04          	shl    $0x4,%rdi
  72afa9:	48 3b 70 30          	cmp    0x30(%rax),%rsi
  72afad:	48 89 ce             	mov    %rcx,%rsi
  72afb0:	49 0f 43 f7          	cmovae %r15,%rsi
  72afb4:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72afb8:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72afbc:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72afc0:	48 83 c0 40          	add    $0x40,%rax
  72afc4:	48 39 d0             	cmp    %rdx,%rax
  72afc7:	0f 82 63 ff ff ff    	jb     72af30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x3d0>
  72afcd:	4c 89 d2             	mov    %r10,%rdx
  72afd0:	48 c1 e2 04          	shl    $0x4,%rdx
  72afd4:	4c 01 e2             	add    %r12,%rdx
  72afd7:	48 39 d0             	cmp    %rdx,%rax
  72afda:	73 31                	jae    72b00d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4ad>
  72afdc:	0f 1f 40 00          	nopl   0x0(%rax)
  72afe0:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72afe4:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72afe8:	48 89 df             	mov    %rbx,%rdi
  72afeb:	48 c1 e7 04          	shl    $0x4,%rdi
  72afef:	48 3b 30             	cmp    (%rax),%rsi
  72aff2:	48 89 ce             	mov    %rcx,%rsi
  72aff5:	49 0f 43 f7          	cmovae %r15,%rsi
  72aff9:	0f 10 00             	movups (%rax),%xmm0
  72affc:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72b000:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72b004:	48 83 c0 10          	add    $0x10,%rax
  72b008:	48 39 d0             	cmp    %rdx,%rax
  72b00b:	72 d3                	jb     72afe0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x480>
  72b00d:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  72b012:	4d 39 f2             	cmp    %r14,%r10
  72b015:	74 29                	je     72b040 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4e0>
  72b017:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72b01b:	48 89 da             	mov    %rbx,%rdx
  72b01e:	48 c1 e2 04          	shl    $0x4,%rdx
  72b022:	0f 10 00             	movups (%rax),%xmm0
  72b025:	41 0f 11 04 17       	movups %xmm0,(%r15,%rdx,1)
  72b02a:	48 ff c3             	inc    %rbx
  72b02d:	48 83 c0 10          	add    $0x10,%rax
  72b031:	4d 89 f2             	mov    %r14,%r10
  72b034:	e9 d7 fe ff ff       	jmp    72af10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x3b0>
  72b039:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72b040:	48 89 dd             	mov    %rbx,%rbp
  72b043:	48 c1 e5 04          	shl    $0x4,%rbp
  72b047:	4c 89 e7             	mov    %r12,%rdi
  72b04a:	4c 89 fe             	mov    %r15,%rsi
  72b04d:	48 89 ea             	mov    %rbp,%rdx
  72b050:	ff 15 92 f8 3b 00    	call   *0x3bf892(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  72b056:	4d 89 f5             	mov    %r14,%r13
  72b059:	49 29 dd             	sub    %rbx,%r13
  72b05c:	0f 84 f9 00 00 00    	je     72b15b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5fb>
  72b062:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
  72b066:	48 8d 43 01          	lea    0x1(%rbx),%rax
  72b06a:	49 39 c6             	cmp    %rax,%r14
  72b06d:	75 09                	jne    72b078 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x518>
  72b06f:	31 c0                	xor    %eax,%eax
  72b071:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72b076:	eb 69                	jmp    72b0e1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x581>
  72b078:	4c 89 e9             	mov    %r13,%rcx
  72b07b:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72b07f:	49 8d 14 2c          	lea    (%r12,%rbp,1),%rdx
  72b083:	48 83 c2 10          	add    $0x10,%rdx
  72b087:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72b08b:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  72b090:	49 01 c2             	add    %rax,%r10
  72b093:	31 c0                	xor    %eax,%eax
  72b095:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72b09c:	ff ff 0f 
  72b09f:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72b0a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72b0ab:	00 00 00 00 00 
  72b0b0:	48 89 c6             	mov    %rax,%rsi
  72b0b3:	41 0f 10 02          	movups (%r10),%xmm0
  72b0b7:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72b0bb:	48 83 c0 02          	add    $0x2,%rax
  72b0bf:	4c 31 c6             	xor    %r8,%rsi
  72b0c2:	48 c1 e6 04          	shl    $0x4,%rsi
  72b0c6:	41 0f 10 04 31       	movups (%r9,%rsi,1),%xmm0
  72b0cb:	0f 11 02             	movups %xmm0,(%rdx)
  72b0ce:	48 83 c2 20          	add    $0x20,%rdx
  72b0d2:	49 83 c2 e0          	add    $0xffffffffffffffe0,%r10
  72b0d6:	48 39 c1             	cmp    %rax,%rcx
  72b0d9:	75 d5                	jne    72b0b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x550>
  72b0db:	41 f6 c5 01          	test   $0x1,%r13b
  72b0df:	74 17                	je     72b0f8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x598>
  72b0e1:	48 89 c1             	mov    %rax,%rcx
  72b0e4:	48 f7 d1             	not    %rcx
  72b0e7:	48 c1 e1 04          	shl    $0x4,%rcx
  72b0eb:	48 c1 e0 04          	shl    $0x4,%rax
  72b0ef:	41 0f 10 04 09       	movups (%r9,%rcx,1),%xmm0
  72b0f4:	0f 11 04 07          	movups %xmm0,(%rdi,%rax,1)
  72b0f8:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72b0fd:	48 39 da             	cmp    %rbx,%rdx
  72b100:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72b105:	0f 82 80 00 00 00    	jb     72b18b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x62b>
  72b10b:	49 89 fc             	mov    %rdi,%r12
  72b10e:	b8 00 00 00 00       	mov    $0x0,%eax
  72b113:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72b118:	49 83 fd 21          	cmp    $0x21,%r13
  72b11c:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72b120:	0f 83 85 fa ff ff    	jae    72abab <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4b>
  72b126:	e9 5d fa ff ff       	jmp    72ab88 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x28>
  72b12b:	4c 89 e7             	mov    %r12,%rdi
  72b12e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72b133:	4c 89 fa             	mov    %r15,%rdx
  72b136:	4c 89 f1             	mov    %r14,%rcx
  72b139:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72b13f:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  72b146:	00 
  72b147:	e8 94 71 00 00       	call   7322e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>
  72b14c:	48 83 c4 58          	add    $0x58,%rsp
  72b150:	5b                   	pop    %rbx
  72b151:	41 5c                	pop    %r12
  72b153:	41 5d                	pop    %r13
  72b155:	41 5e                	pop    %r14
  72b157:	41 5f                	pop    %r15
  72b159:	5d                   	pop    %rbp
  72b15a:	c3                   	ret
  72b15b:	4c 03 64 24 18       	add    0x18(%rsp),%r12
  72b160:	45 31 ed             	xor    %r13d,%r13d
  72b163:	4c 89 e7             	mov    %r12,%rdi
  72b166:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72b16b:	e9 18 fa ff ff       	jmp    72ab88 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x28>
  72b170:	0f 0b                	ud2
  72b172:	48 8d 3d fb df 93 ff 	lea    -0x6c2005(%rip),%rdi        # 69174 <anon.845a5de654f5e1fb5213dc527790f4a9.0.llvm.5591148014433919328+0x19c>
  72b179:	48 8d 15 28 29 39 00 	lea    0x392928(%rip),%rdx        # abdaa8 <anon.845a5de654f5e1fb5213dc527790f4a9.6.llvm.5591148014433919328+0x120>
  72b180:	be 13 00 00 00       	mov    $0x13,%esi
  72b185:	ff 15 8d f7 3b 00    	call   *0x3bf78d(%rip)        # aea918 <_DYNAMIC+0x2a0>
  72b18b:	48 8d 0d 2e 29 39 00 	lea    0x39292e(%rip),%rcx        # abdac0 <anon.845a5de654f5e1fb5213dc527790f4a9.6.llvm.5591148014433919328+0x138>
  72b192:	48 89 df             	mov    %rbx,%rdi
  72b195:	48 89 d6             	mov    %rdx,%rsi
  72b198:	ff 15 6a f7 3b 00    	call   *0x3bf76a(%rip)        # aea908 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
