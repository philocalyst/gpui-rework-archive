
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000718f60 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>:
  718f60:	55                   	push   %rbp
  718f61:	41 57                	push   %r15
  718f63:	41 56                	push   %r14
  718f65:	41 55                	push   %r13
  718f67:	41 54                	push   %r12
  718f69:	53                   	push   %rbx
  718f6a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
  718f71:	48 89 fb             	mov    %rdi,%rbx
  718f74:	4c 8b 26             	mov    (%rsi),%r12
  718f77:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718f7b:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  718f7f:	4c 8b 6e 28          	mov    0x28(%rsi),%r13
  718f83:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718f8a:	00 
  718f8b:	48 85 c0             	test   %rax,%rax
  718f8e:	0f 84 36 01 00 00    	je     7190ca <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x16a>
  718f94:	49 89 f6             	mov    %rsi,%r14
  718f97:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  718f9b:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  718fa0:	0f b7 88 32 05 00 00 	movzwl 0x532(%rax),%ecx
  718fa7:	49 39 cd             	cmp    %rcx,%r13
  718faa:	73 14                	jae    718fc0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  718fac:	49 89 c7             	mov    %rax,%r15
  718faf:	eb 37                	jmp    718fe8 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x88>
  718fb1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  718fb8:	0f 1f 84 00 00 00 00 
  718fbf:	00 
  718fc0:	4c 8b b8 d0 04 00 00 	mov    0x4d0(%rax),%r15
  718fc7:	4d 85 ff             	test   %r15,%r15
  718fca:	0f 84 fa 00 00 00    	je     7190ca <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x16a>
  718fd0:	48 ff c5             	inc    %rbp
  718fd3:	44 0f b7 a8 30 05 00 	movzwl 0x530(%rax),%r13d
  718fda:	00 
  718fdb:	4c 89 f8             	mov    %r15,%rax
  718fde:	66 45 3b af 32 05 00 	cmp    0x532(%r15),%r13w
  718fe5:	00 
  718fe6:	73 d8                	jae    718fc0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  718fe8:	4b 8b b4 ef d8 04 00 	mov    0x4d8(%r15,%r13,8),%rsi
  718fef:	00 
  718ff0:	49 8b 04 24          	mov    (%r12),%rax
  718ff4:	48 8b 38             	mov    (%rax),%rdi
  718ff7:	ff 15 7b f1 3c 00    	call   *0x3cf17b(%rip)        # ae8178 <_DYNAMIC+0x6f8>
  718ffd:	84 c0                	test   %al,%al
  718fff:	0f 84 e1 00 00 00    	je     7190e6 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x186>
  719005:	48 85 ed             	test   %rbp,%rbp
  719008:	0f 84 88 00 00 00    	je     719096 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x136>
  71900e:	4b 8d 04 ef          	lea    (%r15,%r13,8),%rax
  719012:	48 05 40 05 00 00    	add    $0x540,%rax
  719018:	48 89 e9             	mov    %rbp,%rcx
  71901b:	48 83 e1 07          	and    $0x7,%rcx
  71901f:	0f 84 9a 00 00 00    	je     7190bf <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x15f>
  719025:	31 d2                	xor    %edx,%edx
  719027:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  71902e:	00 00 
  719030:	4c 8b 38             	mov    (%rax),%r15
  719033:	49 8d 87 38 05 00 00 	lea    0x538(%r15),%rax
  71903a:	48 ff c2             	inc    %rdx
  71903d:	48 39 d1             	cmp    %rdx,%rcx
  719040:	75 ee                	jne    719030 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xd0>
  719042:	48 89 e9             	mov    %rbp,%rcx
  719045:	48 29 d1             	sub    %rdx,%rcx
  719048:	48 83 fd 08          	cmp    $0x8,%rbp
  71904c:	72 43                	jb     719091 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x131>
  71904e:	66 90                	xchg   %ax,%ax
  719050:	48 8b 00             	mov    (%rax),%rax
  719053:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  71905a:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  719061:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  719068:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  71906f:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  719076:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  71907d:	4c 8b b8 38 05 00 00 	mov    0x538(%rax),%r15
  719084:	49 8d 87 38 05 00 00 	lea    0x538(%r15),%rax
  71908b:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  71908f:	75 bf                	jne    719050 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xf0>
  719091:	45 31 ed             	xor    %r13d,%r13d
  719094:	eb 03                	jmp    719099 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x139>
  719096:	49 ff c5             	inc    %r13
  719099:	4d 89 6e 28          	mov    %r13,0x28(%r14)
  71909d:	0f 57 c0             	xorps  %xmm0,%xmm0
  7190a0:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  7190a5:	31 ed                	xor    %ebp,%ebp
  7190a7:	4c 89 f8             	mov    %r15,%rax
  7190aa:	0f b7 88 32 05 00 00 	movzwl 0x532(%rax),%ecx
  7190b1:	49 39 cd             	cmp    %rcx,%r13
  7190b4:	0f 83 06 ff ff ff    	jae    718fc0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  7190ba:	e9 ed fe ff ff       	jmp    718fac <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x4c>
  7190bf:	48 89 e9             	mov    %rbp,%rcx
  7190c2:	48 83 fd 08          	cmp    $0x8,%rbp
  7190c6:	73 88                	jae    719050 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xf0>
  7190c8:	eb c7                	jmp    719091 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x131>
  7190ca:	c7 43 08 02 00 00 00 	movl   $0x2,0x8(%rbx)
  7190d1:	48 89 d8             	mov    %rbx,%rax
  7190d4:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
  7190db:	5b                   	pop    %rbx
  7190dc:	41 5c                	pop    %r12
  7190de:	41 5d                	pop    %r13
  7190e0:	41 5e                	pop    %r14
  7190e2:	41 5f                	pop    %r15
  7190e4:	5d                   	pop    %rbp
  7190e5:	c3                   	ret
  7190e6:	49 8b 46 08          	mov    0x8(%r14),%rax
  7190ea:	48 ff 08             	decq   (%rax)
  7190ed:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
  7190f2:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  7190f7:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  7190fc:	49 83 c6 10          	add    $0x10,%r14
  719100:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  719105:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  71910a:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  71910f:	4c 89 f2             	mov    %r14,%rdx
  719112:	e8 79 2b fd ff       	call   6ebc90 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_>
  719117:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  71911e:	00 
  71911f:	48 89 43 70          	mov    %rax,0x70(%rbx)
  719123:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  71912a:	00 
  71912b:	0f 11 43 60          	movups %xmm0,0x60(%rbx)
  71912f:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  719136:	00 
  719137:	0f 11 43 50          	movups %xmm0,0x50(%rbx)
  71913b:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  719140:	0f 11 43 40          	movups %xmm0,0x40(%rbx)
  719144:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  719149:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  71914e:	0f 10 54 24 58       	movups 0x58(%rsp),%xmm2
  719153:	0f 10 5c 24 68       	movups 0x68(%rsp),%xmm3
  719158:	0f 11 5b 30          	movups %xmm3,0x30(%rbx)
  71915c:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
  719160:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  719164:	0f 11 03             	movups %xmm0,(%rbx)
  719167:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  71916e:	00 
  71916f:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  719174:	0f 10 84 24 b0 00 00 	movups 0xb0(%rsp),%xmm0
  71917b:	00 
  71917c:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  719181:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  719186:	48 89 41 10          	mov    %rax,0x10(%rcx)
  71918a:	0f 11 01             	movups %xmm0,(%rcx)
  71918d:	e9 3f ff ff ff       	jmp    7190d1 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x171>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
