
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006f44c0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersE_0EB2U_>:
  6f44c0:	41 56                	push   %r14
  6f44c2:	53                   	push   %rbx
  6f44c3:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
  6f44ca:	48 83 3f 00          	cmpq   $0x0,(%rdi)
  6f44ce:	0f 85 c3 00 00 00    	jne    6f4597 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersE_0EB2U_+0xd7>
  6f44d4:	49 89 fe             	mov    %rdi,%r14
  6f44d7:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
  6f44de:	00 00 00 00 00 
  6f44e3:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f44e6:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f44ed:	00 
  6f44ee:	48 c7 84 24 c8 00 00 	movq   $0x8,0xc8(%rsp)
  6f44f5:	00 08 00 00 00 
  6f44fa:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  6f4501:	00 00 00 00 00 
  6f4506:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  6f450d:	00 00 00 00 00 
  6f4512:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
  6f4519:	00 
  6f451a:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  6f4521:	00 
  6f4522:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  6f4529:	00 00 
  6f452b:	48 c7 44 24 20 08 00 	movq   $0x8,0x20(%rsp)
  6f4532:	00 00 
  6f4534:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
  6f4539:	48 c7 44 24 38 08 00 	movq   $0x8,0x38(%rsp)
  6f4540:	00 00 
  6f4542:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
  6f4547:	48 c7 44 24 50 08 00 	movq   $0x8,0x50(%rsp)
  6f454e:	00 00 
  6f4550:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f4557:	00 00 
  6f4559:	48 c7 44 24 60 ff ff 	movq   $0xffffffffffffffff,0x60(%rsp)
  6f4560:	ff ff 
  6f4562:	ff 15 78 37 3f 00    	call   *0x3f3778(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  6f4568:	bf 08 01 00 00       	mov    $0x108,%edi
  6f456d:	be 08 00 00 00       	mov    $0x8,%esi
  6f4572:	ff 15 48 37 3f 00    	call   *0x3f3748(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  6f4578:	48 85 c0             	test   %rax,%rax
  6f457b:	74 28                	je     6f45a5 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersE_0EB2U_+0xe5>
  6f457d:	48 89 c3             	mov    %rax,%rbx
  6f4580:	48 89 e6             	mov    %rsp,%rsi
  6f4583:	ba 08 01 00 00       	mov    $0x108,%edx
  6f4588:	48 89 c7             	mov    %rax,%rdi
  6f458b:	ff 15 5f 37 3f 00    	call   *0x3f375f(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  6f4591:	4c 89 f7             	mov    %r14,%rdi
  6f4594:	49 89 1e             	mov    %rbx,(%r14)
  6f4597:	48 89 f8             	mov    %rdi,%rax
  6f459a:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
  6f45a1:	5b                   	pop    %rbx
  6f45a2:	41 5e                	pop    %r14
  6f45a4:	c3                   	ret
  6f45a5:	bf 08 00 00 00       	mov    $0x8,%edi
  6f45aa:	be 08 01 00 00       	mov    $0x108,%esi
  6f45af:	ff 15 43 37 3f 00    	call   *0x3f3743(%rip)        # ae7cf8 <_DYNAMIC+0x278>
  6f45b5:	0f 0b                	ud2
  6f45b7:	48 89 c3             	mov    %rax,%rbx
  6f45ba:	48 89 e7             	mov    %rsp,%rdi
  6f45bd:	e8 3e 52 00 00       	call   6f9800 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f45c2:	48 89 df             	mov    %rbx,%rdi
  6f45c5:	e8 86 3e 3c 00       	call   ab8450 <_Unwind_Resume@plt>
  6f45ca:	ff 15 48 37 3f 00    	call   *0x3f3748(%rip)        # ae7d18 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
