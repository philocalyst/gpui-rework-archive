
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000071bf40 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_>:
  71bf40:	41 57                	push   %r15
  71bf42:	41 56                	push   %r14
  71bf44:	41 54                	push   %r12
  71bf46:	53                   	push   %rbx
  71bf47:	50                   	push   %rax
  71bf48:	48 89 fb             	mov    %rdi,%rbx
  71bf4b:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
  71bf4f:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  71bf53:	48 89 c8             	mov    %rcx,%rax
  71bf56:	4c 29 f8             	sub    %r15,%rax
  71bf59:	48 c1 e8 03          	shr    $0x3,%rax
  71bf5d:	48 ba 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rdx
  71bf64:	c3 30 0c 
  71bf67:	48 f7 e2             	mul    %rdx
  71bf6a:	4c 39 f9             	cmp    %r15,%rcx
  71bf6d:	74 6a                	je     71bfd9 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x99>
  71bf6f:	49 89 d6             	mov    %rdx,%r14
  71bf72:	49 81 c7 88 00 00 00 	add    $0x88,%r15
  71bf79:	4c 8b 25 40 e9 3c 00 	mov    0x3ce940(%rip),%r12        # aea8c0 <_DYNAMIC+0x248>
  71bf80:	eb 1a                	jmp    71bf9c <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x5c>
  71bf82:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71bf89:	1f 84 00 00 00 00 00 
  71bf90:	49 81 c7 a8 00 00 00 	add    $0xa8,%r15
  71bf97:	49 ff ce             	dec    %r14
  71bf9a:	74 3d                	je     71bfd9 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x99>
  71bf9c:	41 83 bf 78 ff ff ff 	cmpl   $0x2,-0x88(%r15)
  71bfa3:	02 
  71bfa4:	74 ea                	je     71bf90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71bfa6:	49 8b 77 90          	mov    -0x70(%r15),%rsi
  71bfaa:	48 85 f6             	test   %rsi,%rsi
  71bfad:	74 10                	je     71bfbf <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x7f>
  71bfaf:	49 8b 7f 98          	mov    -0x68(%r15),%rdi
  71bfb3:	48 c1 e6 03          	shl    $0x3,%rsi
  71bfb7:	ba 08 00 00 00       	mov    $0x8,%edx
  71bfbc:	41 ff d4             	call   *%r12
  71bfbf:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  71bfc3:	48 85 f6             	test   %rsi,%rsi
  71bfc6:	74 c8                	je     71bf90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71bfc8:	49 8b 3f             	mov    (%r15),%rdi
  71bfcb:	48 c1 e6 05          	shl    $0x5,%rsi
  71bfcf:	ba 08 00 00 00       	mov    $0x8,%edx
  71bfd4:	41 ff d4             	call   *%r12
  71bfd7:	eb b7                	jmp    71bf90 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71bfd9:	48 8b 43 10          	mov    0x10(%rbx),%rax
  71bfdd:	48 85 c0             	test   %rax,%rax
  71bfe0:	74 20                	je     71c002 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0xc2>
  71bfe2:	48 8b 3b             	mov    (%rbx),%rdi
  71bfe5:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  71bfec:	ba 08 00 00 00       	mov    $0x8,%edx
  71bff1:	48 83 c4 08          	add    $0x8,%rsp
  71bff5:	5b                   	pop    %rbx
  71bff6:	41 5c                	pop    %r12
  71bff8:	41 5e                	pop    %r14
  71bffa:	41 5f                	pop    %r15
  71bffc:	ff 25 be e8 3c 00    	jmp    *0x3ce8be(%rip)        # aea8c0 <_DYNAMIC+0x248>
  71c002:	48 83 c4 08          	add    $0x8,%rsp
  71c006:	5b                   	pop    %rbx
  71c007:	41 5c                	pop    %r12
  71c009:	41 5e                	pop    %r14
  71c00b:	41 5f                	pop    %r15
  71c00d:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
