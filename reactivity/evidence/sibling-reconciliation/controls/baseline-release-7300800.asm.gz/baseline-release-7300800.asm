
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006f66c0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_>:
  6f66c0:	55                   	push   %rbp
  6f66c1:	41 57                	push   %r15
  6f66c3:	41 56                	push   %r14
  6f66c5:	41 55                	push   %r13
  6f66c7:	41 54                	push   %r12
  6f66c9:	53                   	push   %rbx
  6f66ca:	48 83 ec 68          	sub    $0x68,%rsp
  6f66ce:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  6f66d3:	48 8b 07             	mov    (%rdi),%rax
  6f66d6:	48 85 c0             	test   %rax,%rax
  6f66d9:	74 45                	je     6f6720 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x60>
  6f66db:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
  6f66df:	48 85 c9             	test   %rcx,%rcx
  6f66e2:	0f 84 96 00 00 00    	je     6f677e <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0xbe>
  6f66e8:	48 89 ca             	mov    %rcx,%rdx
  6f66eb:	48 83 e2 07          	and    $0x7,%rdx
  6f66ef:	74 35                	je     6f6726 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x66>
  6f66f1:	31 f6                	xor    %esi,%esi
  6f66f3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f66fa:	84 00 00 00 00 00 
  6f6700:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f6707:	48 ff c6             	inc    %rsi
  6f670a:	48 39 f2             	cmp    %rsi,%rdx
  6f670d:	75 f1                	jne    6f6700 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x40>
  6f670f:	48 89 ca             	mov    %rcx,%rdx
  6f6712:	48 29 f2             	sub    %rsi,%rdx
  6f6715:	48 89 fe             	mov    %rdi,%rsi
  6f6718:	48 83 f9 08          	cmp    $0x8,%rcx
  6f671c:	73 22                	jae    6f6740 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x80>
  6f671e:	eb 61                	jmp    6f6781 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0xc1>
  6f6720:	31 c0                	xor    %eax,%eax
  6f6722:	31 f6                	xor    %esi,%esi
  6f6724:	eb 5b                	jmp    6f6781 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0xc1>
  6f6726:	48 89 ca             	mov    %rcx,%rdx
  6f6729:	48 89 fe             	mov    %rdi,%rsi
  6f672c:	48 83 f9 08          	cmp    $0x8,%rcx
  6f6730:	72 4f                	jb     6f6781 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0xc1>
  6f6732:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f6739:	1f 84 00 00 00 00 00 
  6f6740:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f6747:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f674e:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f6755:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f675c:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f6763:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f676a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f6771:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f6778:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  6f677c:	75 c2                	jne    6f6740 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x80>
  6f677e:	48 89 fe             	mov    %rdi,%rsi
  6f6781:	48 83 c7 10          	add    $0x10,%rdi
  6f6785:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
  6f678a:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  6f678f:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  6f6794:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
  6f6799:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f679e:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f67a1:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
  6f67a6:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f67ab:	48 8d 74 24 38       	lea    0x38(%rsp),%rsi
  6f67b0:	e8 6b 1f 02 00       	call   718720 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>
  6f67b5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f67ba:	48 83 f8 02          	cmp    $0x2,%rax
  6f67be:	75 0f                	jne    6f67cf <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x10f>
  6f67c0:	48 83 c4 68          	add    $0x68,%rsp
  6f67c4:	5b                   	pop    %rbx
  6f67c5:	41 5c                	pop    %r12
  6f67c7:	41 5d                	pop    %r13
  6f67c9:	41 5e                	pop    %r14
  6f67cb:	41 5f                	pop    %r15
  6f67cd:	5d                   	pop    %rbp
  6f67ce:	c3                   	ret
  6f67cf:	48 8d 5c 24 10       	lea    0x10(%rsp),%rbx
  6f67d4:	4c 8d 74 24 38       	lea    0x38(%rsp),%r14
  6f67d9:	4c 8b 2d 40 41 3f 00 	mov    0x3f4140(%rip),%r13        # aea920 <_DYNAMIC+0x2a8>
  6f67e0:	eb 24                	jmp    6f6806 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x146>
  6f67e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f67e9:	1f 84 00 00 00 00 00 
  6f67f0:	48 89 df             	mov    %rbx,%rdi
  6f67f3:	4c 89 f6             	mov    %r14,%rsi
  6f67f6:	e8 25 1f 02 00       	call   718720 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>
  6f67fb:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f6800:	48 83 f8 02          	cmp    $0x2,%rax
  6f6804:	74 ba                	je     6f67c0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x100>
  6f6806:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6f680b:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  6f6810:	48 85 c0             	test   %rax,%rax
  6f6813:	74 2b                	je     6f6840 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x180>
  6f6815:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f681a:	48 85 ff             	test   %rdi,%rdi
  6f681d:	74 21                	je     6f6840 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x180>
  6f681f:	f6 07 01             	testb  $0x1,(%rdi)
  6f6822:	75 1c                	jne    6f6840 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x180>
  6f6824:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6f6828:	a8 01                	test   $0x1,%al
  6f682a:	75 14                	jne    6f6840 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x180>
  6f682c:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6f6830:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6f6835:	74 42                	je     6f6879 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x1b9>
  6f6837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f683e:	00 00 
  6f6840:	4d 85 ff             	test   %r15,%r15
  6f6843:	74 ab                	je     6f67f0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x130>
  6f6845:	4d 85 e4             	test   %r12,%r12
  6f6848:	74 a6                	je     6f67f0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x130>
  6f684a:	41 f6 04 24 01       	testb  $0x1,(%r12)
  6f684f:	75 9f                	jne    6f67f0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x130>
  6f6851:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f6856:	a8 01                	test   $0x1,%al
  6f6858:	75 96                	jne    6f67f0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x130>
  6f685a:	49 8d 44 24 08       	lea    0x8(%r12),%rax
  6f685f:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6f6864:	75 8a                	jne    6f67f0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x130>
  6f6866:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f686b:	40 b5 01             	mov    $0x1,%bpl
  6f686e:	4c 89 e7             	mov    %r12,%rdi
  6f6871:	41 ff d5             	call   *%r13
  6f6874:	e9 77 ff ff ff       	jmp    6f67f0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x130>
  6f6879:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6f687d:	31 ed                	xor    %ebp,%ebp
  6f687f:	41 ff d5             	call   *%r13
  6f6882:	eb bc                	jmp    6f6840 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x180>
  6f6884:	48 89 c3             	mov    %rax,%rbx
  6f6887:	40 84 ed             	test   %bpl,%bpl
  6f688a:	75 0b                	jne    6f6897 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersH_0EB3T_+0x1d7>
  6f688c:	4c 89 ff             	mov    %r15,%rdi
  6f688f:	4c 89 e6             	mov    %r12,%rsi
  6f6892:	e8 c9 2b 00 00       	call   6f9460 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtB4_6option6OptionNtNtBG_11shared_text10SharedTextEEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f6897:	48 89 df             	mov    %rbx,%rdi
  6f689a:	e8 01 48 3c 00       	call   abb0a0 <_Unwind_Resume@plt>
  6f689f:	ff 15 6b 40 3f 00    	call   *0x3f406b(%rip)        # aea910 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
