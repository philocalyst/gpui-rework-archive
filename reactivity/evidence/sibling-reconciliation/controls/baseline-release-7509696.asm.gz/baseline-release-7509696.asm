
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000007296c0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_>:
  7296c0:	55                   	push   %rbp
  7296c1:	41 57                	push   %r15
  7296c3:	41 56                	push   %r14
  7296c5:	41 55                	push   %r13
  7296c7:	41 54                	push   %r12
  7296c9:	53                   	push   %rbx
  7296ca:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  7296d1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  7296d8:	00 
  7296d9:	50                   	push   %rax
  7296da:	48 89 d3             	mov    %rdx,%rbx
  7296dd:	48 89 f1             	mov    %rsi,%rcx
  7296e0:	48 d1 e9             	shr    $1,%rcx
  7296e3:	48 89 f0             	mov    %rsi,%rax
  7296e6:	48 29 c8             	sub    %rcx,%rax
  7296e9:	48 81 fe 15 16 05 00 	cmp    $0x51615,%rsi
  7296f0:	41 bd 15 16 05 00    	mov    $0x51615,%r13d
  7296f6:	4c 0f 42 ee          	cmovb  %rsi,%r13
  7296fa:	49 39 c5             	cmp    %rax,%r13
  7296fd:	4c 0f 46 e8          	cmovbe %rax,%r13
  729701:	49 81 fd ab 00 00 00 	cmp    $0xab,%r13
  729708:	73 0c                	jae    729716 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x56>
  72970a:	4c 8d 74 24 08       	lea    0x8(%rsp),%r14
  72970f:	b9 aa 00 00 00       	mov    $0xaa,%ecx
  729714:	eb 5b                	jmp    729771 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0xb1>
  729716:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
  72971d:	00 
  72971e:	4c 8d 3c 49          	lea    (%rcx,%rcx,2),%r15
  729722:	48 b9 55 55 55 55 55 	movabs $0x555555555555555,%rcx
  729729:	55 55 05 
  72972c:	48 39 c8             	cmp    %rcx,%rax
  72972f:	76 0f                	jbe    729740 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x80>
  729731:	45 31 e4             	xor    %r12d,%r12d
  729734:	4c 89 e7             	mov    %r12,%rdi
  729737:	4c 89 fe             	mov    %r15,%rsi
  72973a:	ff 15 60 12 3c 00    	call   *0x3c1260(%rip)        # aea9a0 <_DYNAMIC+0x328>
  729740:	49 89 f6             	mov    %rsi,%r14
  729743:	48 89 fd             	mov    %rdi,%rbp
  729746:	ff 15 8c 11 3c 00    	call   *0x3c118c(%rip)        # aea8d8 <_DYNAMIC+0x260>
  72974c:	41 bc 08 00 00 00    	mov    $0x8,%r12d
  729752:	be 08 00 00 00       	mov    $0x8,%esi
  729757:	4c 89 ff             	mov    %r15,%rdi
  72975a:	ff 15 58 11 3c 00    	call   *0x3c1158(%rip)        # aea8b8 <_DYNAMIC+0x240>
  729760:	48 89 ef             	mov    %rbp,%rdi
  729763:	4c 89 f6             	mov    %r14,%rsi
  729766:	49 89 c6             	mov    %rax,%r14
  729769:	4c 89 e9             	mov    %r13,%rcx
  72976c:	48 85 c0             	test   %rax,%rax
  72976f:	74 c3                	je     729734 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x74>
  729771:	45 31 c0             	xor    %r8d,%r8d
  729774:	48 83 fe 41          	cmp    $0x41,%rsi
  729778:	41 0f 92 c0          	setb   %r8b
  72977c:	4c 89 f2             	mov    %r14,%rdx
  72977f:	49 89 d9             	mov    %rbx,%r9
  729782:	e8 19 85 00 00       	call   731ca0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>
  729787:	49 81 fd aa 00 00 00 	cmp    $0xaa,%r13
  72978e:	76 1d                	jbe    7297ad <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0xed>
  729790:	49 c1 e5 03          	shl    $0x3,%r13
  729794:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
  72979b:	00 
  72979c:	4c 01 ee             	add    %r13,%rsi
  72979f:	ba 08 00 00 00       	mov    $0x8,%edx
  7297a4:	4c 89 f7             	mov    %r14,%rdi
  7297a7:	ff 15 13 11 3c 00    	call   *0x3c1113(%rip)        # aea8c0 <_DYNAMIC+0x248>
  7297ad:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  7297b4:	5b                   	pop    %rbx
  7297b5:	41 5c                	pop    %r12
  7297b7:	41 5d                	pop    %r13
  7297b9:	41 5e                	pop    %r14
  7297bb:	41 5f                	pop    %r15
  7297bd:	5d                   	pop    %rbp
  7297be:	c3                   	ret
  7297bf:	48 89 c3             	mov    %rax,%rbx
  7297c2:	49 81 fd ab 00 00 00 	cmp    $0xab,%r13
  7297c9:	73 08                	jae    7297d3 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x113>
  7297cb:	48 89 df             	mov    %rbx,%rdi
  7297ce:	e8 cd 18 39 00       	call   abb0a0 <_Unwind_Resume@plt>
  7297d3:	49 c1 e5 03          	shl    $0x3,%r13
  7297d7:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
  7297de:	00 
  7297df:	4c 01 ee             	add    %r13,%rsi
  7297e2:	ba 08 00 00 00       	mov    $0x8,%edx
  7297e7:	4c 89 f7             	mov    %r14,%rdi
  7297ea:	ff 15 d0 10 3c 00    	call   *0x3c10d0(%rip)        # aea8c0 <_DYNAMIC+0x248>
  7297f0:	48 89 df             	mov    %rbx,%rdi
  7297f3:	e8 a8 18 39 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
