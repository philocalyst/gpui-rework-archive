
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000070e130 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_>:
  70e130:	41 57                	push   %r15
  70e132:	41 56                	push   %r14
  70e134:	41 55                	push   %r13
  70e136:	41 54                	push   %r12
  70e138:	53                   	push   %rbx
  70e139:	48 8b 47 10          	mov    0x10(%rdi),%rax
  70e13d:	48 8b 4f 30          	mov    0x30(%rdi),%rcx
  70e141:	45 31 db             	xor    %r11d,%r11d
  70e144:	45 31 c9             	xor    %r9d,%r9d
  70e147:	48 3b 07             	cmp    (%rdi),%rax
  70e14a:	41 0f 93 c3          	setae  %r11b
  70e14e:	41 0f 92 c1          	setb   %r9b
  70e152:	45 31 c0             	xor    %r8d,%r8d
  70e155:	48 3b 4f 20          	cmp    0x20(%rdi),%rcx
  70e159:	41 0f 92 c0          	setb   %r8b
  70e15d:	41 c1 e1 04          	shl    $0x4,%r9d
  70e161:	4a 8d 04 0f          	lea    (%rdi,%r9,1),%rax
  70e165:	41 c1 e3 04          	shl    $0x4,%r11d
  70e169:	4a 8d 0c 1f          	lea    (%rdi,%r11,1),%rcx
  70e16d:	44 89 c3             	mov    %r8d,%ebx
  70e170:	c1 e3 04             	shl    $0x4,%ebx
  70e173:	4c 8d 14 1f          	lea    (%rdi,%rbx,1),%r10
  70e177:	49 83 c2 20          	add    $0x20,%r10
  70e17b:	41 83 f0 03          	xor    $0x3,%r8d
  70e17f:	41 c1 e0 04          	shl    $0x4,%r8d
  70e183:	48 8b 5c 1f 20       	mov    0x20(%rdi,%rbx,1),%rbx
  70e188:	4e 8b 34 07          	mov    (%rdi,%r8,1),%r14
  70e18c:	4e 8b 1c 1f          	mov    (%rdi,%r11,1),%r11
  70e190:	4d 39 de             	cmp    %r11,%r14
  70e193:	49 89 cf             	mov    %rcx,%r15
  70e196:	4d 0f 42 fa          	cmovb  %r10,%r15
  70e19a:	4a 3b 1c 0f          	cmp    (%rdi,%r9,1),%rbx
  70e19e:	4c 0f 42 f8          	cmovb  %rax,%r15
  70e1a2:	49 0f 42 c2          	cmovb  %r10,%rax
  70e1a6:	4e 8d 04 07          	lea    (%rdi,%r8,1),%r8
  70e1aa:	4c 0f 42 d1          	cmovb  %rcx,%r10
  70e1ae:	4d 39 de             	cmp    %r11,%r14
  70e1b1:	49 0f 43 c8          	cmovae %r8,%rcx
  70e1b5:	4d 0f 42 d0          	cmovb  %r8,%r10
  70e1b9:	4d 8b 02             	mov    (%r10),%r8
  70e1bc:	4d 3b 07             	cmp    (%r15),%r8
  70e1bf:	4d 89 f8             	mov    %r15,%r8
  70e1c2:	4d 0f 42 c2          	cmovb  %r10,%r8
  70e1c6:	4d 0f 42 d7          	cmovb  %r15,%r10
  70e1ca:	0f 10 00             	movups (%rax),%xmm0
  70e1cd:	0f 11 02             	movups %xmm0,(%rdx)
  70e1d0:	41 0f 10 00          	movups (%r8),%xmm0
  70e1d4:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  70e1d8:	41 0f 10 02          	movups (%r10),%xmm0
  70e1dc:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  70e1e0:	0f 10 01             	movups (%rcx),%xmm0
  70e1e3:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  70e1e7:	48 8b 47 50          	mov    0x50(%rdi),%rax
  70e1eb:	48 8b 4f 70          	mov    0x70(%rdi),%rcx
  70e1ef:	45 31 db             	xor    %r11d,%r11d
  70e1f2:	45 31 d2             	xor    %r10d,%r10d
  70e1f5:	48 3b 47 40          	cmp    0x40(%rdi),%rax
  70e1f9:	41 0f 93 c3          	setae  %r11b
  70e1fd:	41 0f 92 c2          	setb   %r10b
  70e201:	45 31 c0             	xor    %r8d,%r8d
  70e204:	48 3b 4f 60          	cmp    0x60(%rdi),%rcx
  70e208:	41 0f 92 c0          	setb   %r8b
  70e20c:	41 c1 e2 04          	shl    $0x4,%r10d
  70e210:	4a 8d 04 17          	lea    (%rdi,%r10,1),%rax
  70e214:	48 83 c0 40          	add    $0x40,%rax
  70e218:	41 c1 e3 04          	shl    $0x4,%r11d
  70e21c:	4a 8d 0c 1f          	lea    (%rdi,%r11,1),%rcx
  70e220:	48 83 c1 40          	add    $0x40,%rcx
  70e224:	44 89 c3             	mov    %r8d,%ebx
  70e227:	c1 e3 04             	shl    $0x4,%ebx
  70e22a:	4c 8d 0c 1f          	lea    (%rdi,%rbx,1),%r9
  70e22e:	49 83 c1 60          	add    $0x60,%r9
  70e232:	41 83 f0 03          	xor    $0x3,%r8d
  70e236:	41 c1 e0 04          	shl    $0x4,%r8d
  70e23a:	48 8b 5c 1f 60       	mov    0x60(%rdi,%rbx,1),%rbx
  70e23f:	4e 8b 74 07 40       	mov    0x40(%rdi,%r8,1),%r14
  70e244:	4e 8b 5c 1f 40       	mov    0x40(%rdi,%r11,1),%r11
  70e249:	4d 39 de             	cmp    %r11,%r14
  70e24c:	49 89 cf             	mov    %rcx,%r15
  70e24f:	4d 0f 42 f9          	cmovb  %r9,%r15
  70e253:	4a 3b 5c 17 40       	cmp    0x40(%rdi,%r10,1),%rbx
  70e258:	4c 0f 42 f8          	cmovb  %rax,%r15
  70e25c:	49 0f 42 c1          	cmovb  %r9,%rax
  70e260:	4c 0f 42 c9          	cmovb  %rcx,%r9
  70e264:	4d 39 de             	cmp    %r11,%r14
  70e267:	4a 8d 7c 07 40       	lea    0x40(%rdi,%r8,1),%rdi
  70e26c:	48 0f 43 cf          	cmovae %rdi,%rcx
  70e270:	4c 0f 42 cf          	cmovb  %rdi,%r9
  70e274:	49 8b 39             	mov    (%r9),%rdi
  70e277:	49 3b 3f             	cmp    (%r15),%rdi
  70e27a:	48 8d 7a 40          	lea    0x40(%rdx),%rdi
  70e27e:	4d 89 f8             	mov    %r15,%r8
  70e281:	4d 0f 42 c1          	cmovb  %r9,%r8
  70e285:	4d 0f 42 cf          	cmovb  %r15,%r9
  70e289:	0f 10 00             	movups (%rax),%xmm0
  70e28c:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  70e290:	41 0f 10 00          	movups (%r8),%xmm0
  70e294:	0f 11 42 50          	movups %xmm0,0x50(%rdx)
  70e298:	41 0f 10 01          	movups (%r9),%xmm0
  70e29c:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  70e2a0:	0f 10 01             	movups (%rcx),%xmm0
  70e2a3:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
  70e2a7:	48 8b 42 40          	mov    0x40(%rdx),%rax
  70e2ab:	31 c9                	xor    %ecx,%ecx
  70e2ad:	45 31 db             	xor    %r11d,%r11d
  70e2b0:	48 3b 02             	cmp    (%rdx),%rax
  70e2b3:	0f 93 c1             	setae  %cl
  70e2b6:	41 0f 92 c3          	setb   %r11b
  70e2ba:	48 0f 43 fa          	cmovae %rdx,%rdi
  70e2be:	0f 10 07             	movups (%rdi),%xmm0
  70e2c1:	0f 11 06             	movups %xmm0,(%rsi)
  70e2c4:	48 8b 7a 70          	mov    0x70(%rdx),%rdi
  70e2c8:	4c 8b 42 30          	mov    0x30(%rdx),%r8
  70e2cc:	31 c0                	xor    %eax,%eax
  70e2ce:	4c 39 c7             	cmp    %r8,%rdi
  70e2d1:	41 b9 00 00 00 00    	mov    $0x0,%r9d
  70e2d7:	49 83 d1 ff          	adc    $0xffffffffffffffff,%r9
  70e2db:	4c 39 c7             	cmp    %r8,%rdi
  70e2de:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  70e2e4:	4d 19 d2             	sbb    %r10,%r10
  70e2e7:	48 8d 5a 30          	lea    0x30(%rdx),%rbx
  70e2eb:	4c 8d 72 70          	lea    0x70(%rdx),%r14
  70e2ef:	4c 39 c7             	cmp    %r8,%rdi
  70e2f2:	4c 0f 42 f3          	cmovb  %rbx,%r14
  70e2f6:	41 c1 e3 04          	shl    $0x4,%r11d
  70e2fa:	4a 8d 3c 1a          	lea    (%rdx,%r11,1),%rdi
  70e2fe:	48 83 c7 40          	add    $0x40,%rdi
  70e302:	c1 e1 04             	shl    $0x4,%ecx
  70e305:	41 0f 10 06          	movups (%r14),%xmm0
  70e309:	0f 11 46 70          	movups %xmm0,0x70(%rsi)
  70e30d:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  70e311:	49 c1 e1 04          	shl    $0x4,%r9
  70e315:	49 c1 e2 04          	shl    $0x4,%r10
  70e319:	4a 8b 5c 1a 40       	mov    0x40(%rdx,%r11,1),%rbx
  70e31e:	45 31 ff             	xor    %r15d,%r15d
  70e321:	45 31 db             	xor    %r11d,%r11d
  70e324:	48 3b 1c 0a          	cmp    (%rdx,%rcx,1),%rbx
  70e328:	41 0f 93 c7          	setae  %r15b
  70e32c:	41 0f 92 c3          	setb   %r11b
  70e330:	4c 89 c1             	mov    %r8,%rcx
  70e333:	48 0f 42 cf          	cmovb  %rdi,%rcx
  70e337:	0f 10 01             	movups (%rcx),%xmm0
  70e33a:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
  70e33e:	4a 8b 5c 0a 70       	mov    0x70(%rdx,%r9,1),%rbx
  70e343:	4e 8b 74 12 30       	mov    0x30(%rdx,%r10,1),%r14
  70e348:	4c 39 f3             	cmp    %r14,%rbx
  70e34b:	b9 00 00 00 00       	mov    $0x0,%ecx
  70e350:	48 83 d1 ff          	adc    $0xffffffffffffffff,%rcx
  70e354:	4c 39 f3             	cmp    %r14,%rbx
  70e357:	4e 8d 74 0a 70       	lea    0x70(%rdx,%r9,1),%r14
  70e35c:	4a 8d 5c 12 30       	lea    0x30(%rdx,%r10,1),%rbx
  70e361:	4d 89 f2             	mov    %r14,%r10
  70e364:	4c 0f 42 d3          	cmovb  %rbx,%r10
  70e368:	ba 00 00 00 00       	mov    $0x0,%edx
  70e36d:	48 19 d2             	sbb    %rdx,%rdx
  70e370:	41 c1 e3 04          	shl    $0x4,%r11d
  70e374:	4e 8d 0c 1f          	lea    (%rdi,%r11,1),%r9
  70e378:	41 c1 e7 04          	shl    $0x4,%r15d
  70e37c:	41 0f 10 02          	movups (%r10),%xmm0
  70e380:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  70e384:	4f 8d 14 38          	lea    (%r8,%r15,1),%r10
  70e388:	48 c1 e1 04          	shl    $0x4,%rcx
  70e38c:	48 c1 e2 04          	shl    $0x4,%rdx
  70e390:	49 8b 3c 3b          	mov    (%r11,%rdi,1),%rdi
  70e394:	45 31 db             	xor    %r11d,%r11d
  70e397:	45 31 e4             	xor    %r12d,%r12d
  70e39a:	4b 3b 3c 07          	cmp    (%r15,%r8,1),%rdi
  70e39e:	41 0f 93 c3          	setae  %r11b
  70e3a2:	41 0f 92 c4          	setb   %r12b
  70e3a6:	4c 89 d7             	mov    %r10,%rdi
  70e3a9:	49 0f 42 f9          	cmovb  %r9,%rdi
  70e3ad:	0f 10 07             	movups (%rdi),%xmm0
  70e3b0:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
  70e3b4:	4e 8b 3c 31          	mov    (%rcx,%r14,1),%r15
  70e3b8:	4c 8b 2c 1a          	mov    (%rdx,%rbx,1),%r13
  70e3bc:	4d 39 ef             	cmp    %r13,%r15
  70e3bf:	bf 00 00 00 00       	mov    $0x0,%edi
  70e3c4:	48 83 d7 ff          	adc    $0xffffffffffffffff,%rdi
  70e3c8:	4d 39 ef             	cmp    %r13,%r15
  70e3cb:	41 b8 00 00 00 00    	mov    $0x0,%r8d
  70e3d1:	4d 19 c0             	sbb    %r8,%r8
  70e3d4:	4c 01 f1             	add    %r14,%rcx
  70e3d7:	48 01 da             	add    %rbx,%rdx
  70e3da:	4d 39 ef             	cmp    %r13,%r15
  70e3dd:	48 89 cb             	mov    %rcx,%rbx
  70e3e0:	48 0f 42 da          	cmovb  %rdx,%rbx
  70e3e4:	41 c1 e4 04          	shl    $0x4,%r12d
  70e3e8:	4f 8d 3c 21          	lea    (%r9,%r12,1),%r15
  70e3ec:	41 c1 e3 04          	shl    $0x4,%r11d
  70e3f0:	0f 10 03             	movups (%rbx),%xmm0
  70e3f3:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  70e3f7:	4b 8d 1c 1a          	lea    (%r10,%r11,1),%rbx
  70e3fb:	48 c1 e7 04          	shl    $0x4,%rdi
  70e3ff:	49 c1 e0 04          	shl    $0x4,%r8
  70e403:	4f 8b 24 0c          	mov    (%r12,%r9,1),%r12
  70e407:	45 31 c9             	xor    %r9d,%r9d
  70e40a:	45 31 f6             	xor    %r14d,%r14d
  70e40d:	4f 3b 24 13          	cmp    (%r11,%r10,1),%r12
  70e411:	41 0f 93 c1          	setae  %r9b
  70e415:	41 0f 92 c6          	setb   %r14b
  70e419:	49 89 da             	mov    %rbx,%r10
  70e41c:	4d 0f 42 d7          	cmovb  %r15,%r10
  70e420:	41 0f 10 02          	movups (%r10),%xmm0
  70e424:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
  70e428:	4c 8b 1c 0f          	mov    (%rdi,%rcx,1),%r11
  70e42c:	4d 8b 24 10          	mov    (%r8,%rdx,1),%r12
  70e430:	4d 39 e3             	cmp    %r12,%r11
  70e433:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  70e439:	49 83 d2 ff          	adc    $0xffffffffffffffff,%r10
  70e43d:	4d 39 e3             	cmp    %r12,%r11
  70e440:	48 19 c0             	sbb    %rax,%rax
  70e443:	48 01 cf             	add    %rcx,%rdi
  70e446:	49 01 d0             	add    %rdx,%r8
  70e449:	4d 39 e3             	cmp    %r12,%r11
  70e44c:	48 89 f9             	mov    %rdi,%rcx
  70e44f:	49 0f 42 c8          	cmovb  %r8,%rcx
  70e453:	41 c1 e6 04          	shl    $0x4,%r14d
  70e457:	4d 01 fe             	add    %r15,%r14
  70e45a:	41 c1 e1 04          	shl    $0x4,%r9d
  70e45e:	0f 10 01             	movups (%rcx),%xmm0
  70e461:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  70e465:	49 01 d9             	add    %rbx,%r9
  70e468:	49 c1 e2 04          	shl    $0x4,%r10
  70e46c:	48 c1 e0 04          	shl    $0x4,%rax
  70e470:	4a 8d 0c 00          	lea    (%rax,%r8,1),%rcx
  70e474:	48 83 c1 10          	add    $0x10,%rcx
  70e478:	49 8d 04 3a          	lea    (%r10,%rdi,1),%rax
  70e47c:	48 83 c0 10          	add    $0x10,%rax
  70e480:	49 39 c6             	cmp    %rax,%r14
  70e483:	0f 95 c0             	setne  %al
  70e486:	49 39 c9             	cmp    %rcx,%r9
  70e489:	75 0e                	jne    70e499 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x369>
  70e48b:	84 c0                	test   %al,%al
  70e48d:	75 10                	jne    70e49f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x36f>
  70e48f:	5b                   	pop    %rbx
  70e490:	41 5c                	pop    %r12
  70e492:	41 5d                	pop    %r13
  70e494:	41 5e                	pop    %r14
  70e496:	41 5f                	pop    %r15
  70e498:	c3                   	ret
  70e499:	b0 01                	mov    $0x1,%al
  70e49b:	84 c0                	test   %al,%al
  70e49d:	74 f0                	je     70e48f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x35f>
  70e49f:	ff 15 b3 9c 3d 00    	call   *0x3d9cb3(%rip)        # ae8158 <_DYNAMIC+0x6d8>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
