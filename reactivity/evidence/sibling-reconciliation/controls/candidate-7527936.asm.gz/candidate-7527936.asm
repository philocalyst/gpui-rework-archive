
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072de00 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_>:
  72de00:	55                   	push   %rbp
  72de01:	41 57                	push   %r15
  72de03:	41 56                	push   %r14
  72de05:	41 55                	push   %r13
  72de07:	41 54                	push   %r12
  72de09:	53                   	push   %rbx
  72de0a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  72de11:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  72de18:	00 
  72de19:	50                   	push   %rax
  72de1a:	49 89 d6             	mov    %rdx,%r14
  72de1d:	48 89 f1             	mov    %rsi,%rcx
  72de20:	48 d1 e9             	shr    $1,%rcx
  72de23:	48 89 f0             	mov    %rsi,%rax
  72de26:	48 29 c8             	sub    %rcx,%rax
  72de29:	48 81 fe 20 a1 07 00 	cmp    $0x7a120,%rsi
  72de30:	bb 20 a1 07 00       	mov    $0x7a120,%ebx
  72de35:	48 0f 42 de          	cmovb  %rsi,%rbx
  72de39:	48 39 c3             	cmp    %rax,%rbx
  72de3c:	48 0f 46 d8          	cmovbe %rax,%rbx
  72de40:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  72de47:	73 0c                	jae    72de55 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x55>
  72de49:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
  72de4e:	b9 00 01 00 00       	mov    $0x100,%ecx
  72de53:	eb 62                	jmp    72deb7 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0xb7>
  72de55:	49 89 dc             	mov    %rbx,%r12
  72de58:	49 c1 e4 04          	shl    $0x4,%r12
  72de5c:	48 c1 e8 3c          	shr    $0x3c,%rax
  72de60:	0f 95 c0             	setne  %al
  72de63:	48 b9 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rcx
  72de6a:	ff ff 7f 
  72de6d:	49 39 cc             	cmp    %rcx,%r12
  72de70:	0f 97 c1             	seta   %cl
  72de73:	08 c1                	or     %al,%cl
  72de75:	74 0f                	je     72de86 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x86>
  72de77:	45 31 ed             	xor    %r13d,%r13d
  72de7a:	4c 89 ef             	mov    %r13,%rdi
  72de7d:	4c 89 e6             	mov    %r12,%rsi
  72de80:	ff 15 22 9f 3b 00    	call   *0x3b9f22(%rip)        # ae7da8 <_DYNAMIC+0x328>
  72de86:	49 89 f7             	mov    %rsi,%r15
  72de89:	48 89 fd             	mov    %rdi,%rbp
  72de8c:	ff 15 4e 9e 3b 00    	call   *0x3b9e4e(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  72de92:	41 bd 08 00 00 00    	mov    $0x8,%r13d
  72de98:	be 08 00 00 00       	mov    $0x8,%esi
  72de9d:	4c 89 e7             	mov    %r12,%rdi
  72dea0:	ff 15 1a 9e 3b 00    	call   *0x3b9e1a(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  72dea6:	48 89 ef             	mov    %rbp,%rdi
  72dea9:	4c 89 fe             	mov    %r15,%rsi
  72deac:	49 89 c7             	mov    %rax,%r15
  72deaf:	48 89 d9             	mov    %rbx,%rcx
  72deb2:	48 85 c0             	test   %rax,%rax
  72deb5:	74 c3                	je     72de7a <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x7a>
  72deb7:	45 31 c0             	xor    %r8d,%r8d
  72deba:	48 83 fe 41          	cmp    $0x41,%rsi
  72debe:	41 0f 92 c0          	setb   %r8b
  72dec2:	4c 89 fa             	mov    %r15,%rdx
  72dec5:	4d 89 f1             	mov    %r14,%r9
  72dec8:	e8 43 e4 ff ff       	call   72c310 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>
  72decd:	48 81 fb 00 01 00 00 	cmp    $0x100,%rbx
  72ded4:	76 15                	jbe    72deeb <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0xeb>
  72ded6:	48 c1 e3 04          	shl    $0x4,%rbx
  72deda:	ba 08 00 00 00       	mov    $0x8,%edx
  72dedf:	4c 89 ff             	mov    %r15,%rdi
  72dee2:	48 89 de             	mov    %rbx,%rsi
  72dee5:	ff 15 dd 9d 3b 00    	call   *0x3b9ddd(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  72deeb:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  72def2:	5b                   	pop    %rbx
  72def3:	41 5c                	pop    %r12
  72def5:	41 5d                	pop    %r13
  72def7:	41 5e                	pop    %r14
  72def9:	41 5f                	pop    %r15
  72defb:	5d                   	pop    %rbp
  72defc:	c3                   	ret
  72defd:	49 89 c6             	mov    %rax,%r14
  72df00:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  72df07:	73 08                	jae    72df11 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x111>
  72df09:	4c 89 f7             	mov    %r14,%rdi
  72df0c:	e8 3f a5 38 00       	call   ab8450 <_Unwind_Resume@plt>
  72df11:	48 c1 e3 04          	shl    $0x4,%rbx
  72df15:	ba 08 00 00 00       	mov    $0x8,%edx
  72df1a:	4c 89 ff             	mov    %r15,%rdi
  72df1d:	48 89 de             	mov    %rbx,%rsi
  72df20:	ff 15 a2 9d 3b 00    	call   *0x3b9da2(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  72df26:	4c 89 f7             	mov    %r14,%rdi
  72df29:	e8 22 a5 38 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
