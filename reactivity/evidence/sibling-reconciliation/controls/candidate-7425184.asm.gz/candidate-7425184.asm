
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000714ca0 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_>:
  714ca0:	41 57                	push   %r15
  714ca2:	41 56                	push   %r14
  714ca4:	41 54                	push   %r12
  714ca6:	53                   	push   %rbx
  714ca7:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  714cae:	48 89 fb             	mov    %rdi,%rbx
  714cb1:	0f 10 06             	movups (%rsi),%xmm0
  714cb4:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  714cb8:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  714cbc:	0f 10 5e 30          	movups 0x30(%rsi),%xmm3
  714cc0:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
  714cc5:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  714cca:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  714ccf:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  714cd4:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  714cd9:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  714cde:	e8 fd ec ff ff       	call   7139e0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_>
  714ce3:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  714ce8:	4d 85 ff             	test   %r15,%r15
  714ceb:	0f 84 b4 00 00 00    	je     714da5 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x105>
  714cf1:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  714cf6:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  714cfb:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  714d00:	49 83 ff 01          	cmp    $0x1,%r15
  714d04:	0f 85 de 00 00 00    	jne    714de8 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x148>
  714d0a:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  714d0f:	ff 15 cb 2f 3d 00    	call   *0x3d2fcb(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  714d15:	bf 18 01 00 00       	mov    $0x118,%edi
  714d1a:	be 08 00 00 00       	mov    $0x8,%esi
  714d1f:	ff 15 9b 2f 3d 00    	call   *0x3d2f9b(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  714d25:	48 85 c0             	test   %rax,%rax
  714d28:	0f 84 da 00 00 00    	je     714e08 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x168>
  714d2e:	48 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%rax)
  714d35:	00 00 00 00 
  714d39:	66 c7 80 12 01 00 00 	movw   $0x0,0x112(%rax)
  714d40:	00 00 
  714d42:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  714d49:	00 00 
  714d4b:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  714d50:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  714d57:	00 00 
  714d59:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
  714d5d:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
  714d61:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  714d68:	00 00 
  714d6a:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  714d6f:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  714d74:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  714d79:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  714d7e:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  714d83:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  714d88:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  714d8d:	e8 9e 60 fd ff       	call   6eae30 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBV_6marker5OwnedjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1B_8RowDraftENtB1f_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterjB1y_INtNtNtB9_3vec9into_iter8IntoIterTjB1y_EEENtNtB9_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  714d92:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
  714d97:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  714d9c:	0f 11 03             	movups %xmm0,(%rbx)
  714d9f:	48 89 43 10          	mov    %rax,0x10(%rbx)
  714da3:	eb 31                	jmp    714dd6 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x136>
  714da5:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  714dac:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  714db3:	00 
  714db4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  714db9:	48 85 c0             	test   %rax,%rax
  714dbc:	74 18                	je     714dd6 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x136>
  714dbe:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  714dc3:	48 c1 e0 03          	shl    $0x3,%rax
  714dc7:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  714dcb:	ba 08 00 00 00       	mov    $0x8,%edx
  714dd0:	ff 15 f2 2e 3d 00    	call   *0x3d2ef2(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  714dd6:	48 89 d8             	mov    %rbx,%rax
  714dd9:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  714de0:	5b                   	pop    %rbx
  714de1:	41 5c                	pop    %r12
  714de3:	41 5e                	pop    %r14
  714de5:	41 5f                	pop    %r15
  714de7:	c3                   	ret
  714de8:	49 83 ff 15          	cmp    $0x15,%r15
  714dec:	73 2c                	jae    714e1a <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x17a>
  714dee:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
  714df3:	ba 01 00 00 00       	mov    $0x1,%edx
  714df8:	4c 89 f7             	mov    %r14,%rdi
  714dfb:	4c 89 fe             	mov    %r15,%rsi
  714dfe:	e8 7d c5 ff ff       	call   711380 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_>
  714e03:	e9 02 ff ff ff       	jmp    714d0a <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x6a>
  714e08:	bf 08 00 00 00       	mov    $0x8,%edi
  714e0d:	be 18 01 00 00       	mov    $0x118,%esi
  714e12:	ff 15 e0 2e 3d 00    	call   *0x3d2ee0(%rip)        # ae7cf8 <_DYNAMIC+0x278>
  714e18:	0f 0b                	ud2
  714e1a:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
  714e1f:	4c 89 f7             	mov    %r14,%rdi
  714e22:	4c 89 fe             	mov    %r15,%rsi
  714e25:	e8 06 91 01 00       	call   72df30 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_>
  714e2a:	e9 db fe ff ff       	jmp    714d0a <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x6a>
  714e2f:	48 89 c3             	mov    %rax,%rbx
  714e32:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  714e37:	eb 03                	jmp    714e3c <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x19c>
  714e39:	48 89 c3             	mov    %rax,%rbx
  714e3c:	4d 85 e4             	test   %r12,%r12
  714e3f:	74 16                	je     714e57 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x1b7>
  714e41:	49 c1 e4 03          	shl    $0x3,%r12
  714e45:	4b 8d 34 64          	lea    (%r12,%r12,2),%rsi
  714e49:	ba 08 00 00 00       	mov    $0x8,%edx
  714e4e:	4c 89 f7             	mov    %r14,%rdi
  714e51:	ff 15 71 2e 3d 00    	call   *0x3d2e71(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  714e57:	48 89 df             	mov    %rbx,%rdi
  714e5a:	e8 f1 35 3a 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
