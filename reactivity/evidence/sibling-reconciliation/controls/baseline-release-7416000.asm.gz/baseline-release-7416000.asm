
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000007128c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_>:
  7128c0:	55                   	push   %rbp
  7128c1:	41 57                	push   %r15
  7128c3:	41 56                	push   %r14
  7128c5:	41 55                	push   %r13
  7128c7:	41 54                	push   %r12
  7128c9:	53                   	push   %rbx
  7128ca:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
  7128d1:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  7128d6:	48 83 fe 02          	cmp    $0x2,%rsi
  7128da:	0f 82 2e 06 00 00    	jb     712f0e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x64e>
  7128e0:	49 89 f5             	mov    %rsi,%r13
  7128e3:	48 83 fe 20          	cmp    $0x20,%rsi
  7128e7:	0f 87 6c 06 00 00    	ja     712f59 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x699>
  7128ed:	4d 89 ec             	mov    %r13,%r12
  7128f0:	49 d1 ec             	shr    $1,%r12
  7128f3:	49 83 fd 12          	cmp    $0x12,%r13
  7128f7:	4c 89 e2             	mov    %r12,%rdx
  7128fa:	49 0f 42 d5          	cmovb  %r13,%rdx
  7128fe:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  712903:	4f 8d 3c a0          	lea    (%r8,%r12,4),%r15
  712907:	4c 89 e8             	mov    %r13,%rax
  71290a:	4c 29 e0             	sub    %r12,%rax
  71290d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  712912:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
  712917:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  71291c:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  712921:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  712928:	0f 1f 84 00 00 00 00 
  71292f:	00 
  712930:	48 83 fa 0c          	cmp    $0xc,%rdx
  712934:	0f 86 f6 02 00 00    	jbe    712c30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x370>
  71293a:	41 8b 40 30          	mov    0x30(%r8),%eax
  71293e:	45 8b 30             	mov    (%r8),%r14d
  712941:	41 8b 48 04          	mov    0x4(%r8),%ecx
  712945:	44 39 f0             	cmp    %r14d,%eax
  712948:	44 89 f6             	mov    %r14d,%esi
  71294b:	0f 47 f0             	cmova  %eax,%esi
  71294e:	44 0f 42 f0          	cmovb  %eax,%r14d
  712952:	41 8b 40 28          	mov    0x28(%r8),%eax
  712956:	39 c8                	cmp    %ecx,%eax
  712958:	41 89 cf             	mov    %ecx,%r15d
  71295b:	44 0f 47 f8          	cmova  %eax,%r15d
  71295f:	0f 42 c8             	cmovb  %eax,%ecx
  712962:	41 8b 40 24          	mov    0x24(%r8),%eax
  712966:	41 8b 68 08          	mov    0x8(%r8),%ebp
  71296a:	39 e8                	cmp    %ebp,%eax
  71296c:	41 89 ec             	mov    %ebp,%r12d
  71296f:	44 0f 47 e0          	cmova  %eax,%r12d
  712973:	0f 42 e8             	cmovb  %eax,%ebp
  712976:	41 8b 40 1c          	mov    0x1c(%r8),%eax
  71297a:	41 8b 58 0c          	mov    0xc(%r8),%ebx
  71297e:	39 d8                	cmp    %ebx,%eax
  712980:	41 89 da             	mov    %ebx,%r10d
  712983:	44 0f 47 d0          	cmova  %eax,%r10d
  712987:	0f 42 d8             	cmovb  %eax,%ebx
  71298a:	41 8b 40 2c          	mov    0x2c(%r8),%eax
  71298e:	41 8b 78 14          	mov    0x14(%r8),%edi
  712992:	39 f8                	cmp    %edi,%eax
  712994:	41 89 fd             	mov    %edi,%r13d
  712997:	44 0f 47 e8          	cmova  %eax,%r13d
  71299b:	0f 42 f8             	cmovb  %eax,%edi
  71299e:	89 7c 24 04          	mov    %edi,0x4(%rsp)
  7129a2:	41 8b 40 20          	mov    0x20(%r8),%eax
  7129a6:	45 8b 58 18          	mov    0x18(%r8),%r11d
  7129aa:	44 39 d8             	cmp    %r11d,%eax
  7129ad:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  7129b2:	44 89 da             	mov    %r11d,%edx
  7129b5:	0f 47 d0             	cmova  %eax,%edx
  7129b8:	44 0f 42 d8          	cmovb  %eax,%r11d
  7129bc:	41 39 cb             	cmp    %ecx,%r11d
  7129bf:	41 89 c9             	mov    %ecx,%r9d
  7129c2:	45 0f 47 cb          	cmova  %r11d,%r9d
  7129c6:	44 0f 43 d9          	cmovae %ecx,%r11d
  7129ca:	39 eb                	cmp    %ebp,%ebx
  7129cc:	89 e9                	mov    %ebp,%ecx
  7129ce:	0f 47 cb             	cmova  %ebx,%ecx
  7129d1:	0f 43 dd             	cmovae %ebp,%ebx
  7129d4:	41 8b 40 10          	mov    0x10(%r8),%eax
  7129d8:	41 39 c5             	cmp    %eax,%r13d
  7129db:	89 c5                	mov    %eax,%ebp
  7129dd:	41 0f 47 ed          	cmova  %r13d,%ebp
  7129e1:	44 0f 43 e8          	cmovae %eax,%r13d
  7129e5:	45 39 d4             	cmp    %r10d,%r12d
  7129e8:	44 89 d0             	mov    %r10d,%eax
  7129eb:	41 0f 47 c4          	cmova  %r12d,%eax
  7129ef:	45 0f 42 d4          	cmovb  %r12d,%r10d
  7129f3:	41 39 d7             	cmp    %edx,%r15d
  7129f6:	41 89 d4             	mov    %edx,%r12d
  7129f9:	45 0f 47 e7          	cmova  %r15d,%r12d
  7129fd:	41 0f 42 d7          	cmovb  %r15d,%edx
  712a01:	45 39 f5             	cmp    %r14d,%r13d
  712a04:	44 89 f7             	mov    %r14d,%edi
  712a07:	41 0f 47 fd          	cmova  %r13d,%edi
  712a0b:	45 0f 43 ee          	cmovae %r14d,%r13d
  712a0f:	44 39 db             	cmp    %r11d,%ebx
  712a12:	45 89 de             	mov    %r11d,%r14d
  712a15:	44 0f 47 f3          	cmova  %ebx,%r14d
  712a19:	44 89 34 24          	mov    %r14d,(%rsp)
  712a1d:	41 0f 43 db          	cmovae %r11d,%ebx
  712a21:	41 39 c9             	cmp    %ecx,%r9d
  712a24:	41 89 cf             	mov    %ecx,%r15d
  712a27:	45 0f 47 f9          	cmova  %r9d,%r15d
  712a2b:	41 0f 42 c9          	cmovb  %r9d,%ecx
  712a2f:	44 39 d2             	cmp    %r10d,%edx
  712a32:	45 89 d1             	mov    %r10d,%r9d
  712a35:	44 0f 47 ca          	cmova  %edx,%r9d
  712a39:	41 0f 43 d2          	cmovae %r10d,%edx
  712a3d:	41 39 c4             	cmp    %eax,%r12d
  712a40:	41 89 c6             	mov    %eax,%r14d
  712a43:	45 0f 47 f4          	cmova  %r12d,%r14d
  712a47:	44 0f 43 e0          	cmovae %eax,%r12d
  712a4b:	39 ee                	cmp    %ebp,%esi
  712a4d:	41 89 ea             	mov    %ebp,%r10d
  712a50:	44 0f 47 d6          	cmova  %esi,%r10d
  712a54:	0f 42 ee             	cmovb  %esi,%ebp
  712a57:	41 39 ff             	cmp    %edi,%r15d
  712a5a:	89 fe                	mov    %edi,%esi
  712a5c:	41 0f 47 f7          	cmova  %r15d,%esi
  712a60:	44 0f 43 ff          	cmovae %edi,%r15d
  712a64:	8b 44 24 04          	mov    0x4(%rsp),%eax
  712a68:	41 39 c4             	cmp    %eax,%r12d
  712a6b:	41 89 c3             	mov    %eax,%r11d
  712a6e:	45 0f 47 dc          	cmova  %r12d,%r11d
  712a72:	44 0f 43 e0          	cmovae %eax,%r12d
  712a76:	44 39 cd             	cmp    %r9d,%ebp
  712a79:	44 89 c8             	mov    %r9d,%eax
  712a7c:	0f 47 c5             	cmova  %ebp,%eax
  712a7f:	41 0f 43 e9          	cmovae %r9d,%ebp
  712a83:	45 39 f2             	cmp    %r14d,%r10d
  712a86:	44 89 f7             	mov    %r14d,%edi
  712a89:	41 0f 47 fa          	cmova  %r10d,%edi
  712a8d:	89 7c 24 04          	mov    %edi,0x4(%rsp)
  712a91:	45 0f 43 d6          	cmovae %r14d,%r10d
  712a95:	45 39 ec             	cmp    %r13d,%r12d
  712a98:	45 89 ee             	mov    %r13d,%r14d
  712a9b:	45 0f 47 f4          	cmova  %r12d,%r14d
  712a9f:	45 0f 43 e5          	cmovae %r13d,%r12d
  712aa3:	39 cd                	cmp    %ecx,%ebp
  712aa5:	89 cf                	mov    %ecx,%edi
  712aa7:	0f 47 fd             	cmova  %ebp,%edi
  712aaa:	0f 43 e9             	cmovae %ecx,%ebp
  712aad:	44 39 fa             	cmp    %r15d,%edx
  712ab0:	45 89 fd             	mov    %r15d,%r13d
  712ab3:	44 0f 47 ea          	cmova  %edx,%r13d
  712ab7:	44 0f 42 fa          	cmovb  %edx,%r15d
  712abb:	39 f0                	cmp    %esi,%eax
  712abd:	41 89 f1             	mov    %esi,%r9d
  712ac0:	44 0f 47 c8          	cmova  %eax,%r9d
  712ac4:	0f 43 c6             	cmovae %esi,%eax
  712ac7:	45 39 da             	cmp    %r11d,%r10d
  712aca:	44 89 da             	mov    %r11d,%edx
  712acd:	41 0f 47 d2          	cmova  %r10d,%edx
  712ad1:	45 0f 43 d3          	cmovae %r11d,%r10d
  712ad5:	44 39 e3             	cmp    %r12d,%ebx
  712ad8:	45 89 e3             	mov    %r12d,%r11d
  712adb:	44 0f 47 db          	cmova  %ebx,%r11d
  712adf:	44 0f 42 e3          	cmovb  %ebx,%r12d
  712ae3:	8b 34 24             	mov    (%rsp),%esi
  712ae6:	41 39 f6             	cmp    %esi,%r14d
  712ae9:	89 f1                	mov    %esi,%ecx
  712aeb:	41 0f 47 ce          	cmova  %r14d,%ecx
  712aef:	44 0f 43 f6          	cmovae %esi,%r14d
  712af3:	41 39 c2             	cmp    %eax,%r10d
  712af6:	89 c6                	mov    %eax,%esi
  712af8:	41 0f 47 f2          	cmova  %r10d,%esi
  712afc:	44 0f 43 d0          	cmovae %eax,%r10d
  712b00:	44 39 ef             	cmp    %r13d,%edi
  712b03:	44 89 e8             	mov    %r13d,%eax
  712b06:	0f 47 c7             	cmova  %edi,%eax
  712b09:	44 0f 42 ef          	cmovb  %edi,%r13d
  712b0d:	41 39 d1             	cmp    %edx,%r9d
  712b10:	89 d7                	mov    %edx,%edi
  712b12:	41 0f 47 f9          	cmova  %r9d,%edi
  712b16:	89 3c 24             	mov    %edi,(%rsp)
  712b19:	41 0f 42 d1          	cmovb  %r9d,%edx
  712b1d:	44 39 dd             	cmp    %r11d,%ebp
  712b20:	45 89 d9             	mov    %r11d,%r9d
  712b23:	44 0f 47 cd          	cmova  %ebp,%r9d
  712b27:	44 0f 42 dd          	cmovb  %ebp,%r11d
  712b2b:	45 39 f7             	cmp    %r14d,%r15d
  712b2e:	44 89 f3             	mov    %r14d,%ebx
  712b31:	41 0f 47 df          	cmova  %r15d,%ebx
  712b35:	45 0f 42 f7          	cmovb  %r15d,%r14d
  712b39:	41 39 ca             	cmp    %ecx,%r10d
  712b3c:	89 cf                	mov    %ecx,%edi
  712b3e:	41 0f 47 fa          	cmova  %r10d,%edi
  712b42:	44 0f 43 d1          	cmovae %ecx,%r10d
  712b46:	39 f2                	cmp    %esi,%edx
  712b48:	89 f5                	mov    %esi,%ebp
  712b4a:	0f 47 ea             	cmova  %edx,%ebp
  712b4d:	0f 43 d6             	cmovae %esi,%edx
  712b50:	45 39 de             	cmp    %r11d,%r14d
  712b53:	45 89 df             	mov    %r11d,%r15d
  712b56:	45 0f 47 fe          	cmova  %r14d,%r15d
  712b5a:	45 0f 43 f3          	cmovae %r11d,%r14d
  712b5e:	44 39 cb             	cmp    %r9d,%ebx
  712b61:	45 89 cb             	mov    %r9d,%r11d
  712b64:	44 0f 47 db          	cmova  %ebx,%r11d
  712b68:	8b 4c 24 04          	mov    0x4(%rsp),%ecx
  712b6c:	41 89 48 30          	mov    %ecx,0x30(%r8)
  712b70:	41 0f 43 d9          	cmovae %r9d,%ebx
  712b74:	45 39 d5             	cmp    %r10d,%r13d
  712b77:	45 89 d1             	mov    %r10d,%r9d
  712b7a:	45 0f 47 cd          	cmova  %r13d,%r9d
  712b7e:	45 89 20             	mov    %r12d,(%r8)
  712b81:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  712b86:	45 0f 42 d5          	cmovb  %r13d,%r10d
  712b8a:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  712b8f:	39 f8                	cmp    %edi,%eax
  712b91:	89 f9                	mov    %edi,%ecx
  712b93:	0f 47 c8             	cmova  %eax,%ecx
  712b96:	8b 34 24             	mov    (%rsp),%esi
  712b99:	41 89 70 2c          	mov    %esi,0x2c(%r8)
  712b9d:	0f 42 f8             	cmovb  %eax,%edi
  712ba0:	44 39 fb             	cmp    %r15d,%ebx
  712ba3:	44 89 fe             	mov    %r15d,%esi
  712ba6:	0f 47 f3             	cmova  %ebx,%esi
  712ba9:	41 89 68 28          	mov    %ebp,0x28(%r8)
  712bad:	41 0f 43 df          	cmovae %r15d,%ebx
  712bb1:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  712bb6:	45 39 da             	cmp    %r11d,%r10d
  712bb9:	44 89 d8             	mov    %r11d,%eax
  712bbc:	41 0f 47 c2          	cmova  %r10d,%eax
  712bc0:	45 89 70 04          	mov    %r14d,0x4(%r8)
  712bc4:	45 0f 43 d3          	cmovae %r11d,%r10d
  712bc8:	41 39 f9             	cmp    %edi,%r9d
  712bcb:	41 89 fb             	mov    %edi,%r11d
  712bce:	45 0f 47 d9          	cmova  %r9d,%r11d
  712bd2:	41 89 58 08          	mov    %ebx,0x8(%r8)
  712bd6:	41 0f 42 f9          	cmovb  %r9d,%edi
  712bda:	39 ca                	cmp    %ecx,%edx
  712bdc:	41 89 c9             	mov    %ecx,%r9d
  712bdf:	44 0f 47 ca          	cmova  %edx,%r9d
  712be3:	45 89 58 1c          	mov    %r11d,0x1c(%r8)
  712be7:	0f 42 ca             	cmovb  %edx,%ecx
  712bea:	41 39 f2             	cmp    %esi,%r10d
  712bed:	89 f2                	mov    %esi,%edx
  712bef:	41 0f 47 d2          	cmova  %r10d,%edx
  712bf3:	41 89 48 20          	mov    %ecx,0x20(%r8)
  712bf7:	44 0f 43 d6          	cmovae %esi,%r10d
  712bfb:	39 c7                	cmp    %eax,%edi
  712bfd:	89 c1                	mov    %eax,%ecx
  712bff:	0f 47 cf             	cmova  %edi,%ecx
  712c02:	45 89 48 24          	mov    %r9d,0x24(%r8)
  712c06:	45 89 50 0c          	mov    %r10d,0xc(%r8)
  712c0a:	0f 43 f8             	cmovae %eax,%edi
  712c0d:	41 89 50 10          	mov    %edx,0x10(%r8)
  712c11:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  712c16:	41 89 78 14          	mov    %edi,0x14(%r8)
  712c1a:	41 89 48 18          	mov    %ecx,0x18(%r8)
  712c1e:	b9 0d 00 00 00       	mov    $0xd,%ecx
  712c23:	e9 ae 01 00 00       	jmp    712dd6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x516>
  712c28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  712c2f:	00 
  712c30:	b9 01 00 00 00       	mov    $0x1,%ecx
  712c35:	48 83 fa 08          	cmp    $0x8,%rdx
  712c39:	0f 86 97 01 00 00    	jbe    712dd6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x516>
  712c3f:	41 8b 40 0c          	mov    0xc(%r8),%eax
  712c43:	45 8b 08             	mov    (%r8),%r9d
  712c46:	41 8b 48 04          	mov    0x4(%r8),%ecx
  712c4a:	44 39 c8             	cmp    %r9d,%eax
  712c4d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  712c52:	44 89 ca             	mov    %r9d,%edx
  712c55:	0f 47 d0             	cmova  %eax,%edx
  712c58:	44 0f 42 c8          	cmovb  %eax,%r9d
  712c5c:	41 8b 40 1c          	mov    0x1c(%r8),%eax
  712c60:	39 c8                	cmp    %ecx,%eax
  712c62:	89 cf                	mov    %ecx,%edi
  712c64:	0f 47 f8             	cmova  %eax,%edi
  712c67:	0f 42 c8             	cmovb  %eax,%ecx
  712c6a:	41 8b 40 14          	mov    0x14(%r8),%eax
  712c6e:	45 8b 58 08          	mov    0x8(%r8),%r11d
  712c72:	44 39 d8             	cmp    %r11d,%eax
  712c75:	45 89 da             	mov    %r11d,%r10d
  712c78:	44 0f 47 d0          	cmova  %eax,%r10d
  712c7c:	44 0f 42 d8          	cmovb  %eax,%r11d
  712c80:	41 8b 58 20          	mov    0x20(%r8),%ebx
  712c84:	41 8b 70 10          	mov    0x10(%r8),%esi
  712c88:	39 f3                	cmp    %esi,%ebx
  712c8a:	89 f0                	mov    %esi,%eax
  712c8c:	0f 47 c3             	cmova  %ebx,%eax
  712c8f:	0f 42 f3             	cmovb  %ebx,%esi
  712c92:	44 39 cf             	cmp    %r9d,%edi
  712c95:	44 89 cb             	mov    %r9d,%ebx
  712c98:	0f 47 df             	cmova  %edi,%ebx
  712c9b:	41 0f 43 f9          	cmovae %r9d,%edi
  712c9f:	44 39 de             	cmp    %r11d,%esi
  712ca2:	44 89 dd             	mov    %r11d,%ebp
  712ca5:	0f 47 ee             	cmova  %esi,%ebp
  712ca8:	41 0f 43 f3          	cmovae %r11d,%esi
  712cac:	39 d0                	cmp    %edx,%eax
  712cae:	41 89 d3             	mov    %edx,%r11d
  712cb1:	44 0f 47 d8          	cmova  %eax,%r11d
  712cb5:	0f 43 c2             	cmovae %edx,%eax
  712cb8:	41 8b 50 18          	mov    0x18(%r8),%edx
  712cbc:	44 39 d2             	cmp    %r10d,%edx
  712cbf:	45 89 d1             	mov    %r10d,%r9d
  712cc2:	44 0f 47 ca          	cmova  %edx,%r9d
  712cc6:	44 0f 42 d2          	cmovb  %edx,%r10d
  712cca:	39 fe                	cmp    %edi,%esi
  712ccc:	89 fa                	mov    %edi,%edx
  712cce:	0f 47 d6             	cmova  %esi,%edx
  712cd1:	0f 43 f7             	cmovae %edi,%esi
  712cd4:	39 c8                	cmp    %ecx,%eax
  712cd6:	89 cf                	mov    %ecx,%edi
  712cd8:	0f 47 f8             	cmova  %eax,%edi
  712cdb:	0f 43 c1             	cmovae %ecx,%eax
  712cde:	41 39 ea             	cmp    %ebp,%r10d
  712ce1:	41 89 ec             	mov    %ebp,%r12d
  712ce4:	45 0f 47 e2          	cmova  %r10d,%r12d
  712ce8:	44 0f 43 d5          	cmovae %ebp,%r10d
  712cec:	41 39 db             	cmp    %ebx,%r11d
  712cef:	41 89 df             	mov    %ebx,%r15d
  712cf2:	45 0f 47 fb          	cmova  %r11d,%r15d
  712cf6:	44 0f 43 db          	cmovae %ebx,%r11d
  712cfa:	41 39 c2             	cmp    %eax,%r10d
  712cfd:	41 89 c6             	mov    %eax,%r14d
  712d00:	45 0f 47 f2          	cmova  %r10d,%r14d
  712d04:	44 0f 43 d0          	cmovae %eax,%r10d
  712d08:	41 39 f9             	cmp    %edi,%r9d
  712d0b:	89 f9                	mov    %edi,%ecx
  712d0d:	41 0f 47 c9          	cmova  %r9d,%ecx
  712d11:	41 0f 42 f9          	cmovb  %r9d,%edi
  712d15:	45 39 e3             	cmp    %r12d,%r11d
  712d18:	44 89 e5             	mov    %r12d,%ebp
  712d1b:	41 0f 47 eb          	cmova  %r11d,%ebp
  712d1f:	45 0f 43 dc          	cmovae %r12d,%r11d
  712d23:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  712d28:	41 39 f2             	cmp    %esi,%r10d
  712d2b:	89 f3                	mov    %esi,%ebx
  712d2d:	41 0f 47 da          	cmova  %r10d,%ebx
  712d31:	44 0f 43 d6          	cmovae %esi,%r10d
  712d35:	41 39 d6             	cmp    %edx,%r14d
  712d38:	89 d6                	mov    %edx,%esi
  712d3a:	41 0f 47 f6          	cmova  %r14d,%esi
  712d3e:	44 0f 43 f2          	cmovae %edx,%r14d
  712d42:	41 39 fb             	cmp    %edi,%r11d
  712d45:	89 f8                	mov    %edi,%eax
  712d47:	41 0f 47 c3          	cmova  %r11d,%eax
  712d4b:	44 0f 43 df          	cmovae %edi,%r11d
  712d4f:	41 39 cf             	cmp    %ecx,%r15d
  712d52:	89 cf                	mov    %ecx,%edi
  712d54:	41 0f 47 ff          	cmova  %r15d,%edi
  712d58:	41 0f 42 cf          	cmovb  %r15d,%ecx
  712d5c:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  712d61:	45 39 f3             	cmp    %r14d,%r11d
  712d64:	45 89 f1             	mov    %r14d,%r9d
  712d67:	45 0f 47 cb          	cmova  %r11d,%r9d
  712d6b:	45 0f 43 de          	cmovae %r14d,%r11d
  712d6f:	39 f0                	cmp    %esi,%eax
  712d71:	89 f2                	mov    %esi,%edx
  712d73:	0f 47 d0             	cmova  %eax,%edx
  712d76:	45 89 10             	mov    %r10d,(%r8)
  712d79:	0f 43 c6             	cmovae %esi,%eax
  712d7c:	39 cd                	cmp    %ecx,%ebp
  712d7e:	89 ce                	mov    %ecx,%esi
  712d80:	0f 47 f5             	cmova  %ebp,%esi
  712d83:	41 89 78 20          	mov    %edi,0x20(%r8)
  712d87:	0f 42 cd             	cmovb  %ebp,%ecx
  712d8a:	41 39 db             	cmp    %ebx,%r11d
  712d8d:	89 df                	mov    %ebx,%edi
  712d8f:	41 0f 47 fb          	cmova  %r11d,%edi
  712d93:	41 89 70 1c          	mov    %esi,0x1c(%r8)
  712d97:	44 0f 43 db          	cmovae %ebx,%r11d
  712d9b:	44 39 c8             	cmp    %r9d,%eax
  712d9e:	44 89 ce             	mov    %r9d,%esi
  712da1:	0f 47 f0             	cmova  %eax,%esi
  712da4:	45 89 58 04          	mov    %r11d,0x4(%r8)
  712da8:	41 0f 43 c1          	cmovae %r9d,%eax
  712dac:	39 d1                	cmp    %edx,%ecx
  712dae:	41 89 d1             	mov    %edx,%r9d
  712db1:	44 0f 47 c9          	cmova  %ecx,%r9d
  712db5:	41 89 78 08          	mov    %edi,0x8(%r8)
  712db9:	41 89 40 0c          	mov    %eax,0xc(%r8)
  712dbd:	0f 43 ca             	cmovae %edx,%ecx
  712dc0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  712dc5:	41 89 70 10          	mov    %esi,0x10(%r8)
  712dc9:	41 89 48 14          	mov    %ecx,0x14(%r8)
  712dcd:	45 89 48 18          	mov    %r9d,0x18(%r8)
  712dd1:	b9 09 00 00 00       	mov    $0x9,%ecx
  712dd6:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
  712dda:	48 39 d0             	cmp    %rdx,%rax
  712ddd:	0f 83 76 01 00 00    	jae    712f59 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x699>
  712de3:	48 39 d1             	cmp    %rdx,%rcx
  712de6:	75 28                	jne    712e10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x550>
  712de8:	49 83 fd 12          	cmp    $0x12,%r13
  712dec:	0f 82 1c 01 00 00    	jb     712f0e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x64e>
  712df2:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  712df7:	4c 3b 44 24 08       	cmp    0x8(%rsp),%r8
  712dfc:	4d 89 f8             	mov    %r15,%r8
  712dff:	0f 84 2b fb ff ff    	je     712930 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x70>
  712e05:	eb 56                	jmp    712e5d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x59d>
  712e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  712e0e:	00 00 
  712e10:	49 8d 34 90          	lea    (%r8,%rdx,4),%rsi
  712e14:	c1 e1 02             	shl    $0x2,%ecx
  712e17:	49 8d 04 08          	lea    (%r8,%rcx,1),%rax
  712e1b:	eb 15                	jmp    712e32 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x572>
  712e1d:	0f 1f 00             	nopl   (%rax)
  712e20:	4c 89 c7             	mov    %r8,%rdi
  712e23:	89 17                	mov    %edx,(%rdi)
  712e25:	48 83 c0 04          	add    $0x4,%rax
  712e29:	48 83 c1 04          	add    $0x4,%rcx
  712e2d:	48 39 f0             	cmp    %rsi,%rax
  712e30:	74 b6                	je     712de8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x528>
  712e32:	44 8b 48 fc          	mov    -0x4(%rax),%r9d
  712e36:	8b 10                	mov    (%rax),%edx
  712e38:	44 39 ca             	cmp    %r9d,%edx
  712e3b:	73 e8                	jae    712e25 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x565>
  712e3d:	48 89 cf             	mov    %rcx,%rdi
  712e40:	45 89 0c 38          	mov    %r9d,(%r8,%rdi,1)
  712e44:	48 83 ff 04          	cmp    $0x4,%rdi
  712e48:	74 d6                	je     712e20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x560>
  712e4a:	45 8b 4c 38 f8       	mov    -0x8(%r8,%rdi,1),%r9d
  712e4f:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  712e53:	44 39 ca             	cmp    %r9d,%edx
  712e56:	72 e8                	jb     712e40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x580>
  712e58:	4c 01 c7             	add    %r8,%rdi
  712e5b:	eb c6                	jmp    712e23 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x563>
  712e5d:	49 8d 7d ff          	lea    -0x1(%r13),%rdi
  712e61:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  712e66:	4f 8d 04 a9          	lea    (%r9,%r13,4),%r8
  712e6a:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  712e6e:	49 8d 77 fc          	lea    -0x4(%r15),%rsi
  712e72:	31 c9                	xor    %ecx,%ecx
  712e74:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  712e7b:	00 00 00 00 00 
  712e80:	41 8b 07             	mov    (%r15),%eax
  712e83:	41 8b 11             	mov    (%r9),%edx
  712e86:	45 31 d2             	xor    %r10d,%r10d
  712e89:	45 31 db             	xor    %r11d,%r11d
  712e8c:	39 d0                	cmp    %edx,%eax
  712e8e:	41 0f 93 c2          	setae  %r10b
  712e92:	41 0f 92 c3          	setb   %r11b
  712e96:	0f 42 d0             	cmovb  %eax,%edx
  712e99:	41 8b 00             	mov    (%r8),%eax
  712e9c:	8b 1e                	mov    (%rsi),%ebx
  712e9e:	39 d8                	cmp    %ebx,%eax
  712ea0:	41 be 00 00 00 00    	mov    $0x0,%r14d
  712ea6:	49 83 d6 ff          	adc    $0xffffffffffffffff,%r14
  712eaa:	39 d8                	cmp    %ebx,%eax
  712eac:	0f 47 d8             	cmova  %eax,%ebx
  712eaf:	89 54 8c 38          	mov    %edx,0x38(%rsp,%rcx,4)
  712eb3:	b8 00 00 00 00       	mov    $0x0,%eax
  712eb8:	48 19 c0             	sbb    %rax,%rax
  712ebb:	48 ff c1             	inc    %rcx
  712ebe:	4f 8d 3c 9f          	lea    (%r15,%r11,4),%r15
  712ec2:	4f 8d 0c 91          	lea    (%r9,%r10,4),%r9
  712ec6:	89 5c bc 38          	mov    %ebx,0x38(%rsp,%rdi,4)
  712eca:	4f 8d 04 b0          	lea    (%r8,%r14,4),%r8
  712ece:	48 8d 34 86          	lea    (%rsi,%rax,4),%rsi
  712ed2:	48 ff cf             	dec    %rdi
  712ed5:	49 39 cc             	cmp    %rcx,%r12
  712ed8:	75 a6                	jne    712e80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x5c0>
  712eda:	48 83 c6 04          	add    $0x4,%rsi
  712ede:	49 83 c0 04          	add    $0x4,%r8
  712ee2:	41 f6 c5 01          	test   $0x1,%r13b
  712ee6:	75 38                	jne    712f20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x660>
  712ee8:	4d 39 c7             	cmp    %r8,%r15
  712eeb:	0f 95 c0             	setne  %al
  712eee:	49 39 f1             	cmp    %rsi,%r9
  712ef1:	75 5a                	jne    712f4d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x68d>
  712ef3:	84 c0                	test   %al,%al
  712ef5:	75 5c                	jne    712f53 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x693>
  712ef7:	49 c1 e5 02          	shl    $0x2,%r13
  712efb:	48 8d 74 24 38       	lea    0x38(%rsp),%rsi
  712f00:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  712f05:	4c 89 ea             	mov    %r13,%rdx
  712f08:	ff 15 da 79 3d 00    	call   *0x3d79da(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  712f0e:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
  712f15:	5b                   	pop    %rbx
  712f16:	41 5c                	pop    %r12
  712f18:	41 5d                	pop    %r13
  712f1a:	41 5e                	pop    %r14
  712f1c:	41 5f                	pop    %r15
  712f1e:	5d                   	pop    %rbp
  712f1f:	c3                   	ret
  712f20:	31 c0                	xor    %eax,%eax
  712f22:	31 d2                	xor    %edx,%edx
  712f24:	49 39 f1             	cmp    %rsi,%r9
  712f27:	0f 93 c0             	setae  %al
  712f2a:	0f 92 c2             	setb   %dl
  712f2d:	4c 89 ff             	mov    %r15,%rdi
  712f30:	49 0f 42 f9          	cmovb  %r9,%rdi
  712f34:	8b 3f                	mov    (%rdi),%edi
  712f36:	89 7c 8c 38          	mov    %edi,0x38(%rsp,%rcx,4)
  712f3a:	4d 8d 0c 91          	lea    (%r9,%rdx,4),%r9
  712f3e:	4d 8d 3c 87          	lea    (%r15,%rax,4),%r15
  712f42:	4d 39 c7             	cmp    %r8,%r15
  712f45:	0f 95 c0             	setne  %al
  712f48:	49 39 f1             	cmp    %rsi,%r9
  712f4b:	74 a6                	je     712ef3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x633>
  712f4d:	b0 01                	mov    $0x1,%al
  712f4f:	84 c0                	test   %al,%al
  712f51:	74 a4                	je     712ef7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x637>
  712f53:	ff 15 e7 7d 3d 00    	call   *0x3d7de7(%rip)        # aead40 <_DYNAMIC+0x6c8>
  712f59:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
