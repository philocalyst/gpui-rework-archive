
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000710100 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_>:
  710100:	41 57                	push   %r15
  710102:	41 56                	push   %r14
  710104:	41 55                	push   %r13
  710106:	41 54                	push   %r12
  710108:	53                   	push   %rbx
  710109:	48 8b 47 10          	mov    0x10(%rdi),%rax
  71010d:	48 8b 4f 30          	mov    0x30(%rdi),%rcx
  710111:	45 31 db             	xor    %r11d,%r11d
  710114:	45 31 c9             	xor    %r9d,%r9d
  710117:	48 3b 07             	cmp    (%rdi),%rax
  71011a:	41 0f 93 c3          	setae  %r11b
  71011e:	41 0f 92 c1          	setb   %r9b
  710122:	45 31 c0             	xor    %r8d,%r8d
  710125:	48 3b 4f 20          	cmp    0x20(%rdi),%rcx
  710129:	41 0f 92 c0          	setb   %r8b
  71012d:	41 c1 e1 04          	shl    $0x4,%r9d
  710131:	4a 8d 04 0f          	lea    (%rdi,%r9,1),%rax
  710135:	41 c1 e3 04          	shl    $0x4,%r11d
  710139:	4a 8d 0c 1f          	lea    (%rdi,%r11,1),%rcx
  71013d:	44 89 c3             	mov    %r8d,%ebx
  710140:	c1 e3 04             	shl    $0x4,%ebx
  710143:	4c 8d 14 1f          	lea    (%rdi,%rbx,1),%r10
  710147:	49 83 c2 20          	add    $0x20,%r10
  71014b:	41 83 f0 03          	xor    $0x3,%r8d
  71014f:	41 c1 e0 04          	shl    $0x4,%r8d
  710153:	48 8b 5c 1f 20       	mov    0x20(%rdi,%rbx,1),%rbx
  710158:	4e 8b 34 07          	mov    (%rdi,%r8,1),%r14
  71015c:	4e 8b 1c 1f          	mov    (%rdi,%r11,1),%r11
  710160:	4d 39 de             	cmp    %r11,%r14
  710163:	49 89 cf             	mov    %rcx,%r15
  710166:	4d 0f 42 fa          	cmovb  %r10,%r15
  71016a:	4a 3b 1c 0f          	cmp    (%rdi,%r9,1),%rbx
  71016e:	4c 0f 42 f8          	cmovb  %rax,%r15
  710172:	49 0f 42 c2          	cmovb  %r10,%rax
  710176:	4e 8d 04 07          	lea    (%rdi,%r8,1),%r8
  71017a:	4c 0f 42 d1          	cmovb  %rcx,%r10
  71017e:	4d 39 de             	cmp    %r11,%r14
  710181:	49 0f 43 c8          	cmovae %r8,%rcx
  710185:	4d 0f 42 d0          	cmovb  %r8,%r10
  710189:	4d 8b 02             	mov    (%r10),%r8
  71018c:	4d 3b 07             	cmp    (%r15),%r8
  71018f:	4d 89 f8             	mov    %r15,%r8
  710192:	4d 0f 42 c2          	cmovb  %r10,%r8
  710196:	4d 0f 42 d7          	cmovb  %r15,%r10
  71019a:	0f 10 00             	movups (%rax),%xmm0
  71019d:	0f 11 02             	movups %xmm0,(%rdx)
  7101a0:	41 0f 10 00          	movups (%r8),%xmm0
  7101a4:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  7101a8:	41 0f 10 02          	movups (%r10),%xmm0
  7101ac:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  7101b0:	0f 10 01             	movups (%rcx),%xmm0
  7101b3:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  7101b7:	48 8b 47 50          	mov    0x50(%rdi),%rax
  7101bb:	48 8b 4f 70          	mov    0x70(%rdi),%rcx
  7101bf:	45 31 db             	xor    %r11d,%r11d
  7101c2:	45 31 d2             	xor    %r10d,%r10d
  7101c5:	48 3b 47 40          	cmp    0x40(%rdi),%rax
  7101c9:	41 0f 93 c3          	setae  %r11b
  7101cd:	41 0f 92 c2          	setb   %r10b
  7101d1:	45 31 c0             	xor    %r8d,%r8d
  7101d4:	48 3b 4f 60          	cmp    0x60(%rdi),%rcx
  7101d8:	41 0f 92 c0          	setb   %r8b
  7101dc:	41 c1 e2 04          	shl    $0x4,%r10d
  7101e0:	4a 8d 04 17          	lea    (%rdi,%r10,1),%rax
  7101e4:	48 83 c0 40          	add    $0x40,%rax
  7101e8:	41 c1 e3 04          	shl    $0x4,%r11d
  7101ec:	4a 8d 0c 1f          	lea    (%rdi,%r11,1),%rcx
  7101f0:	48 83 c1 40          	add    $0x40,%rcx
  7101f4:	44 89 c3             	mov    %r8d,%ebx
  7101f7:	c1 e3 04             	shl    $0x4,%ebx
  7101fa:	4c 8d 0c 1f          	lea    (%rdi,%rbx,1),%r9
  7101fe:	49 83 c1 60          	add    $0x60,%r9
  710202:	41 83 f0 03          	xor    $0x3,%r8d
  710206:	41 c1 e0 04          	shl    $0x4,%r8d
  71020a:	48 8b 5c 1f 60       	mov    0x60(%rdi,%rbx,1),%rbx
  71020f:	4e 8b 74 07 40       	mov    0x40(%rdi,%r8,1),%r14
  710214:	4e 8b 5c 1f 40       	mov    0x40(%rdi,%r11,1),%r11
  710219:	4d 39 de             	cmp    %r11,%r14
  71021c:	49 89 cf             	mov    %rcx,%r15
  71021f:	4d 0f 42 f9          	cmovb  %r9,%r15
  710223:	4a 3b 5c 17 40       	cmp    0x40(%rdi,%r10,1),%rbx
  710228:	4c 0f 42 f8          	cmovb  %rax,%r15
  71022c:	49 0f 42 c1          	cmovb  %r9,%rax
  710230:	4c 0f 42 c9          	cmovb  %rcx,%r9
  710234:	4d 39 de             	cmp    %r11,%r14
  710237:	4a 8d 7c 07 40       	lea    0x40(%rdi,%r8,1),%rdi
  71023c:	48 0f 43 cf          	cmovae %rdi,%rcx
  710240:	4c 0f 42 cf          	cmovb  %rdi,%r9
  710244:	49 8b 39             	mov    (%r9),%rdi
  710247:	49 3b 3f             	cmp    (%r15),%rdi
  71024a:	48 8d 7a 40          	lea    0x40(%rdx),%rdi
  71024e:	4d 89 f8             	mov    %r15,%r8
  710251:	4d 0f 42 c1          	cmovb  %r9,%r8
  710255:	4d 0f 42 cf          	cmovb  %r15,%r9
  710259:	0f 10 00             	movups (%rax),%xmm0
  71025c:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  710260:	41 0f 10 00          	movups (%r8),%xmm0
  710264:	0f 11 42 50          	movups %xmm0,0x50(%rdx)
  710268:	41 0f 10 01          	movups (%r9),%xmm0
  71026c:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  710270:	0f 10 01             	movups (%rcx),%xmm0
  710273:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
  710277:	48 8b 42 40          	mov    0x40(%rdx),%rax
  71027b:	31 c9                	xor    %ecx,%ecx
  71027d:	45 31 db             	xor    %r11d,%r11d
  710280:	48 3b 02             	cmp    (%rdx),%rax
  710283:	0f 93 c1             	setae  %cl
  710286:	41 0f 92 c3          	setb   %r11b
  71028a:	48 0f 43 fa          	cmovae %rdx,%rdi
  71028e:	0f 10 07             	movups (%rdi),%xmm0
  710291:	0f 11 06             	movups %xmm0,(%rsi)
  710294:	48 8b 7a 70          	mov    0x70(%rdx),%rdi
  710298:	4c 8b 42 30          	mov    0x30(%rdx),%r8
  71029c:	31 c0                	xor    %eax,%eax
  71029e:	4c 39 c7             	cmp    %r8,%rdi
  7102a1:	41 b9 00 00 00 00    	mov    $0x0,%r9d
  7102a7:	49 83 d1 ff          	adc    $0xffffffffffffffff,%r9
  7102ab:	4c 39 c7             	cmp    %r8,%rdi
  7102ae:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  7102b4:	4d 19 d2             	sbb    %r10,%r10
  7102b7:	48 8d 5a 30          	lea    0x30(%rdx),%rbx
  7102bb:	4c 8d 72 70          	lea    0x70(%rdx),%r14
  7102bf:	4c 39 c7             	cmp    %r8,%rdi
  7102c2:	4c 0f 42 f3          	cmovb  %rbx,%r14
  7102c6:	41 c1 e3 04          	shl    $0x4,%r11d
  7102ca:	4a 8d 3c 1a          	lea    (%rdx,%r11,1),%rdi
  7102ce:	48 83 c7 40          	add    $0x40,%rdi
  7102d2:	c1 e1 04             	shl    $0x4,%ecx
  7102d5:	41 0f 10 06          	movups (%r14),%xmm0
  7102d9:	0f 11 46 70          	movups %xmm0,0x70(%rsi)
  7102dd:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  7102e1:	49 c1 e1 04          	shl    $0x4,%r9
  7102e5:	49 c1 e2 04          	shl    $0x4,%r10
  7102e9:	4a 8b 5c 1a 40       	mov    0x40(%rdx,%r11,1),%rbx
  7102ee:	45 31 ff             	xor    %r15d,%r15d
  7102f1:	45 31 db             	xor    %r11d,%r11d
  7102f4:	48 3b 1c 0a          	cmp    (%rdx,%rcx,1),%rbx
  7102f8:	41 0f 93 c7          	setae  %r15b
  7102fc:	41 0f 92 c3          	setb   %r11b
  710300:	4c 89 c1             	mov    %r8,%rcx
  710303:	48 0f 42 cf          	cmovb  %rdi,%rcx
  710307:	0f 10 01             	movups (%rcx),%xmm0
  71030a:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
  71030e:	4a 8b 5c 0a 70       	mov    0x70(%rdx,%r9,1),%rbx
  710313:	4e 8b 74 12 30       	mov    0x30(%rdx,%r10,1),%r14
  710318:	4c 39 f3             	cmp    %r14,%rbx
  71031b:	b9 00 00 00 00       	mov    $0x0,%ecx
  710320:	48 83 d1 ff          	adc    $0xffffffffffffffff,%rcx
  710324:	4c 39 f3             	cmp    %r14,%rbx
  710327:	4e 8d 74 0a 70       	lea    0x70(%rdx,%r9,1),%r14
  71032c:	4a 8d 5c 12 30       	lea    0x30(%rdx,%r10,1),%rbx
  710331:	4d 89 f2             	mov    %r14,%r10
  710334:	4c 0f 42 d3          	cmovb  %rbx,%r10
  710338:	ba 00 00 00 00       	mov    $0x0,%edx
  71033d:	48 19 d2             	sbb    %rdx,%rdx
  710340:	41 c1 e3 04          	shl    $0x4,%r11d
  710344:	4e 8d 0c 1f          	lea    (%rdi,%r11,1),%r9
  710348:	41 c1 e7 04          	shl    $0x4,%r15d
  71034c:	41 0f 10 02          	movups (%r10),%xmm0
  710350:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  710354:	4f 8d 14 38          	lea    (%r8,%r15,1),%r10
  710358:	48 c1 e1 04          	shl    $0x4,%rcx
  71035c:	48 c1 e2 04          	shl    $0x4,%rdx
  710360:	49 8b 3c 3b          	mov    (%r11,%rdi,1),%rdi
  710364:	45 31 db             	xor    %r11d,%r11d
  710367:	45 31 e4             	xor    %r12d,%r12d
  71036a:	4b 3b 3c 07          	cmp    (%r15,%r8,1),%rdi
  71036e:	41 0f 93 c3          	setae  %r11b
  710372:	41 0f 92 c4          	setb   %r12b
  710376:	4c 89 d7             	mov    %r10,%rdi
  710379:	49 0f 42 f9          	cmovb  %r9,%rdi
  71037d:	0f 10 07             	movups (%rdi),%xmm0
  710380:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
  710384:	4e 8b 3c 31          	mov    (%rcx,%r14,1),%r15
  710388:	4c 8b 2c 1a          	mov    (%rdx,%rbx,1),%r13
  71038c:	4d 39 ef             	cmp    %r13,%r15
  71038f:	bf 00 00 00 00       	mov    $0x0,%edi
  710394:	48 83 d7 ff          	adc    $0xffffffffffffffff,%rdi
  710398:	4d 39 ef             	cmp    %r13,%r15
  71039b:	41 b8 00 00 00 00    	mov    $0x0,%r8d
  7103a1:	4d 19 c0             	sbb    %r8,%r8
  7103a4:	4c 01 f1             	add    %r14,%rcx
  7103a7:	48 01 da             	add    %rbx,%rdx
  7103aa:	4d 39 ef             	cmp    %r13,%r15
  7103ad:	48 89 cb             	mov    %rcx,%rbx
  7103b0:	48 0f 42 da          	cmovb  %rdx,%rbx
  7103b4:	41 c1 e4 04          	shl    $0x4,%r12d
  7103b8:	4f 8d 3c 21          	lea    (%r9,%r12,1),%r15
  7103bc:	41 c1 e3 04          	shl    $0x4,%r11d
  7103c0:	0f 10 03             	movups (%rbx),%xmm0
  7103c3:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  7103c7:	4b 8d 1c 1a          	lea    (%r10,%r11,1),%rbx
  7103cb:	48 c1 e7 04          	shl    $0x4,%rdi
  7103cf:	49 c1 e0 04          	shl    $0x4,%r8
  7103d3:	4f 8b 24 0c          	mov    (%r12,%r9,1),%r12
  7103d7:	45 31 c9             	xor    %r9d,%r9d
  7103da:	45 31 f6             	xor    %r14d,%r14d
  7103dd:	4f 3b 24 13          	cmp    (%r11,%r10,1),%r12
  7103e1:	41 0f 93 c1          	setae  %r9b
  7103e5:	41 0f 92 c6          	setb   %r14b
  7103e9:	49 89 da             	mov    %rbx,%r10
  7103ec:	4d 0f 42 d7          	cmovb  %r15,%r10
  7103f0:	41 0f 10 02          	movups (%r10),%xmm0
  7103f4:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
  7103f8:	4c 8b 1c 0f          	mov    (%rdi,%rcx,1),%r11
  7103fc:	4d 8b 24 10          	mov    (%r8,%rdx,1),%r12
  710400:	4d 39 e3             	cmp    %r12,%r11
  710403:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  710409:	49 83 d2 ff          	adc    $0xffffffffffffffff,%r10
  71040d:	4d 39 e3             	cmp    %r12,%r11
  710410:	48 19 c0             	sbb    %rax,%rax
  710413:	48 01 cf             	add    %rcx,%rdi
  710416:	49 01 d0             	add    %rdx,%r8
  710419:	4d 39 e3             	cmp    %r12,%r11
  71041c:	48 89 f9             	mov    %rdi,%rcx
  71041f:	49 0f 42 c8          	cmovb  %r8,%rcx
  710423:	41 c1 e6 04          	shl    $0x4,%r14d
  710427:	4d 01 fe             	add    %r15,%r14
  71042a:	41 c1 e1 04          	shl    $0x4,%r9d
  71042e:	0f 10 01             	movups (%rcx),%xmm0
  710431:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  710435:	49 01 d9             	add    %rbx,%r9
  710438:	49 c1 e2 04          	shl    $0x4,%r10
  71043c:	48 c1 e0 04          	shl    $0x4,%rax
  710440:	4a 8d 0c 00          	lea    (%rax,%r8,1),%rcx
  710444:	48 83 c1 10          	add    $0x10,%rcx
  710448:	49 8d 04 3a          	lea    (%r10,%rdi,1),%rax
  71044c:	48 83 c0 10          	add    $0x10,%rax
  710450:	49 39 c6             	cmp    %rax,%r14
  710453:	0f 95 c0             	setne  %al
  710456:	49 39 c9             	cmp    %rcx,%r9
  710459:	75 0e                	jne    710469 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x369>
  71045b:	84 c0                	test   %al,%al
  71045d:	75 10                	jne    71046f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x36f>
  71045f:	5b                   	pop    %rbx
  710460:	41 5c                	pop    %r12
  710462:	41 5d                	pop    %r13
  710464:	41 5e                	pop    %r14
  710466:	41 5f                	pop    %r15
  710468:	c3                   	ret
  710469:	b0 01                	mov    $0x1,%al
  71046b:	84 c0                	test   %al,%al
  71046d:	74 f0                	je     71045f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x35f>
  71046f:	ff 15 cb a8 3d 00    	call   *0x3da8cb(%rip)        # aead40 <_DYNAMIC+0x6c8>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
