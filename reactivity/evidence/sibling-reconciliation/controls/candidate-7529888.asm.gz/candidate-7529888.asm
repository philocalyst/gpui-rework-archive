
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072e5a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>:
  72e5a0:	55                   	push   %rbp
  72e5a1:	41 57                	push   %r15
  72e5a3:	41 56                	push   %r14
  72e5a5:	41 55                	push   %r13
  72e5a7:	41 54                	push   %r12
  72e5a9:	53                   	push   %rbx
  72e5aa:	50                   	push   %rax
  72e5ab:	49 89 d7             	mov    %rdx,%r15
  72e5ae:	48 89 f3             	mov    %rsi,%rbx
  72e5b1:	49 89 fe             	mov    %rdi,%r14
  72e5b4:	48 b8 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rax
  72e5bb:	ff ff 1f 
  72e5be:	48 85 c1             	test   %rax,%rcx
  72e5c1:	74 68                	je     72e62b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_+0x8b>
  72e5c3:	48 c1 e9 03          	shr    $0x3,%rcx
  72e5c7:	48 89 c8             	mov    %rcx,%rax
  72e5ca:	48 c1 e0 05          	shl    $0x5,%rax
  72e5ce:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
  72e5d2:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
  72e5d6:	4c 69 e9 a8 00 00 00 	imul   $0xa8,%rcx,%r13
  72e5dd:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
  72e5e1:	4c 89 f7             	mov    %r14,%rdi
  72e5e4:	48 89 cd             	mov    %rcx,%rbp
  72e5e7:	4c 89 04 24          	mov    %r8,(%rsp)
  72e5eb:	e8 b0 ff ff ff       	call   72e5a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>
  72e5f0:	49 89 c6             	mov    %rax,%r14
  72e5f3:	4a 8d 34 23          	lea    (%rbx,%r12,1),%rsi
  72e5f7:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
  72e5fb:	48 89 df             	mov    %rbx,%rdi
  72e5fe:	48 89 e9             	mov    %rbp,%rcx
  72e601:	4c 8b 04 24          	mov    (%rsp),%r8
  72e605:	e8 96 ff ff ff       	call   72e5a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>
  72e60a:	48 89 c3             	mov    %rax,%rbx
  72e60d:	4d 01 fc             	add    %r15,%r12
  72e610:	4d 01 fd             	add    %r15,%r13
  72e613:	4c 89 ff             	mov    %r15,%rdi
  72e616:	4c 89 e6             	mov    %r12,%rsi
  72e619:	4c 89 ea             	mov    %r13,%rdx
  72e61c:	48 89 e9             	mov    %rbp,%rcx
  72e61f:	4c 8b 04 24          	mov    (%rsp),%r8
  72e623:	e8 78 ff ff ff       	call   72e5a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>
  72e628:	49 89 c7             	mov    %rax,%r15
  72e62b:	49 8b 06             	mov    (%r14),%rax
  72e62e:	48 8b 0b             	mov    (%rbx),%rcx
  72e631:	48 39 c8             	cmp    %rcx,%rax
  72e634:	0f 92 c2             	setb   %dl
  72e637:	49 8b 37             	mov    (%r15),%rsi
  72e63a:	48 39 f0             	cmp    %rsi,%rax
  72e63d:	0f 92 c0             	setb   %al
  72e640:	30 d0                	xor    %dl,%al
  72e642:	48 39 f1             	cmp    %rsi,%rcx
  72e645:	0f 92 c1             	setb   %cl
  72e648:	30 d1                	xor    %dl,%cl
  72e64a:	49 0f 45 df          	cmovne %r15,%rbx
  72e64e:	84 c0                	test   %al,%al
  72e650:	49 0f 45 de          	cmovne %r14,%rbx
  72e654:	48 89 d8             	mov    %rbx,%rax
  72e657:	48 83 c4 08          	add    $0x8,%rsp
  72e65b:	5b                   	pop    %rbx
  72e65c:	41 5c                	pop    %r12
  72e65e:	41 5d                	pop    %r13
  72e660:	41 5e                	pop    %r14
  72e662:	41 5f                	pop    %r15
  72e664:	5d                   	pop    %rbp
  72e665:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
