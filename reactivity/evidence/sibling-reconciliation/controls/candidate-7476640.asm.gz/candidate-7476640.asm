
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000007215a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_>:
  7215a0:	55                   	push   %rbp
  7215a1:	41 57                	push   %r15
  7215a3:	41 56                	push   %r14
  7215a5:	41 55                	push   %r13
  7215a7:	41 54                	push   %r12
  7215a9:	53                   	push   %rbx
  7215aa:	48 83 ec 28          	sub    $0x28,%rsp
  7215ae:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  7215b3:	49 89 f6             	mov    %rsi,%r14
  7215b6:	49 89 ff             	mov    %rdi,%r15
  7215b9:	48 83 fe 21          	cmp    $0x21,%rsi
  7215bd:	73 1e                	jae    7215dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x3d>
  7215bf:	4c 89 ff             	mov    %r15,%rdi
  7215c2:	4c 89 f6             	mov    %r14,%rsi
  7215c5:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  7215ca:	48 83 c4 28          	add    $0x28,%rsp
  7215ce:	5b                   	pop    %rbx
  7215cf:	41 5c                	pop    %r12
  7215d1:	41 5d                	pop    %r13
  7215d3:	41 5e                	pop    %r14
  7215d5:	41 5f                	pop    %r15
  7215d7:	5d                   	pop    %rbp
  7215d8:	e9 43 e9 fe ff       	jmp    70ff20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_>
  7215dd:	89 cb                	mov    %ecx,%ebx
  7215df:	49 89 d4             	mov    %rdx,%r12
  7215e2:	49 89 e5             	mov    %rsp,%r13
  7215e5:	eb 5e                	jmp    721645 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0xa5>
  7215e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  7215ee:	00 00 
  7215f0:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  7215f4:	49 8b 57 10          	mov    0x10(%r15),%rdx
  7215f8:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  7215fd:	41 0f 10 07          	movups (%r15),%xmm0
  721601:	0f 29 04 24          	movaps %xmm0,(%rsp)
  721605:	49 8b 54 cf 10       	mov    0x10(%r15,%rcx,8),%rdx
  72160a:	41 0f 10 04 cf       	movups (%r15,%rcx,8),%xmm0
  72160f:	41 0f 11 07          	movups %xmm0,(%r15)
  721613:	49 89 57 10          	mov    %rdx,0x10(%r15)
  721617:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72161c:	49 89 54 cf 10       	mov    %rdx,0x10(%r15,%rcx,8)
  721621:	0f 28 04 24          	movaps (%rsp),%xmm0
  721625:	41 0f 11 04 cf       	movups %xmm0,(%r15,%rcx,8)
  72162a:	48 f7 d0             	not    %rax
  72162d:	49 01 c6             	add    %rax,%r14
  721630:	4d 8d 3c cf          	lea    (%r15,%rcx,8),%r15
  721634:	49 83 c7 18          	add    $0x18,%r15
  721638:	45 31 e4             	xor    %r12d,%r12d
  72163b:	49 83 fe 21          	cmp    $0x21,%r14
  72163f:	0f 82 7a ff ff ff    	jb     7215bf <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x1f>
  721645:	85 db                	test   %ebx,%ebx
  721647:	0f 84 44 03 00 00    	je     721991 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x3f1>
  72164d:	4c 89 f1             	mov    %r14,%rcx
  721650:	48 c1 e9 03          	shr    $0x3,%rcx
  721654:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  721658:	48 c1 e0 05          	shl    $0x5,%rax
  72165c:	4c 01 f8             	add    %r15,%rax
  72165f:	48 69 d1 a8 00 00 00 	imul   $0xa8,%rcx,%rdx
  721666:	4c 01 fa             	add    %r15,%rdx
  721669:	49 83 fe 40          	cmp    $0x40,%r14
  72166d:	73 41                	jae    7216b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x110>
  72166f:	49 8b 0f             	mov    (%r15),%rcx
  721672:	48 8b 30             	mov    (%rax),%rsi
  721675:	48 39 f1             	cmp    %rsi,%rcx
  721678:	40 0f 92 c7          	setb   %dil
  72167c:	4c 8b 02             	mov    (%rdx),%r8
  72167f:	4c 39 c1             	cmp    %r8,%rcx
  721682:	0f 92 c1             	setb   %cl
  721685:	40 30 f9             	xor    %dil,%cl
  721688:	4c 39 c6             	cmp    %r8,%rsi
  72168b:	40 0f 92 c6          	setb   %sil
  72168f:	40 30 fe             	xor    %dil,%sil
  721692:	48 0f 45 c2          	cmovne %rdx,%rax
  721696:	84 c9                	test   %cl,%cl
  721698:	49 0f 45 c7          	cmovne %r15,%rax
  72169c:	ff cb                	dec    %ebx
  72169e:	4c 29 f8             	sub    %r15,%rax
  7216a1:	4d 85 e4             	test   %r12,%r12
  7216a4:	75 24                	jne    7216ca <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x12a>
  7216a6:	eb 30                	jmp    7216d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x138>
  7216a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  7216af:	00 
  7216b0:	4c 89 ff             	mov    %r15,%rdi
  7216b3:	48 89 c6             	mov    %rax,%rsi
  7216b6:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  7216bb:	e8 e0 ce 00 00       	call   72e5a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>
  7216c0:	ff cb                	dec    %ebx
  7216c2:	4c 29 f8             	sub    %r15,%rax
  7216c5:	4d 85 e4             	test   %r12,%r12
  7216c8:	74 0e                	je     7216d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x138>
  7216ca:	49 8b 0c 24          	mov    (%r12),%rcx
  7216ce:	49 3b 0c 07          	cmp    (%r15,%rax,1),%rcx
  7216d2:	0f 83 98 01 00 00    	jae    721870 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x2d0>
  7216d8:	89 5c 24 24          	mov    %ebx,0x24(%rsp)
  7216dc:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  7216e0:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  7216e5:	41 0f 10 07          	movups (%r15),%xmm0
  7216e9:	0f 29 04 24          	movaps %xmm0,(%rsp)
  7216ed:	49 8b 4c 07 10       	mov    0x10(%r15,%rax,1),%rcx
  7216f2:	41 0f 10 04 07       	movups (%r15,%rax,1),%xmm0
  7216f7:	41 0f 11 07          	movups %xmm0,(%r15)
  7216fb:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  7216ff:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  721704:	49 89 4c 07 10       	mov    %rcx,0x10(%r15,%rax,1)
  721709:	0f 28 04 24          	movaps (%rsp),%xmm0
  72170d:	41 0f 11 04 07       	movups %xmm0,(%r15,%rax,1)
  721712:	49 8d 47 18          	lea    0x18(%r15),%rax
  721716:	49 8b 4f 28          	mov    0x28(%r15),%rcx
  72171a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72171f:	41 0f 10 47 18       	movups 0x18(%r15),%xmm0
  721724:	0f 29 04 24          	movaps %xmm0,(%rsp)
  721728:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
  72172f:	00 
  721730:	48 8d 3c 76          	lea    (%rsi,%rsi,2),%rdi
  721734:	4c 01 ff             	add    %r15,%rdi
  721737:	49 8d 4f 30          	lea    0x30(%r15),%rcx
  72173b:	49 8b 17             	mov    (%r15),%rdx
  72173e:	4c 8d 1c 76          	lea    (%rsi,%rsi,2),%r11
  721742:	49 83 c3 b8          	add    $0xffffffffffffffb8,%r11
  721746:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  72174a:	49 83 c2 d0          	add    $0xffffffffffffffd0,%r10
  72174e:	31 f6                	xor    %esi,%esi
  721750:	4c 8b 41 10          	mov    0x10(%rcx),%r8
  721754:	48 39 11             	cmp    %rdx,(%rcx)
  721757:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  72175b:	4a 8b 5c c8 10       	mov    0x10(%rax,%r9,8),%rbx
  721760:	42 0f 10 04 c8       	movups (%rax,%r9,8),%xmm0
  721765:	0f 11 41 e8          	movups %xmm0,-0x18(%rcx)
  721769:	48 89 59 f8          	mov    %rbx,-0x8(%rcx)
  72176d:	4e 89 44 c8 10       	mov    %r8,0x10(%rax,%r9,8)
  721772:	0f 10 01             	movups (%rcx),%xmm0
  721775:	42 0f 11 04 c8       	movups %xmm0,(%rax,%r9,8)
  72177a:	48 83 d6 00          	adc    $0x0,%rsi
  72177e:	48 83 c1 18          	add    $0x18,%rcx
  721782:	4d 89 d8             	mov    %r11,%r8
  721785:	49 83 c3 e8          	add    $0xffffffffffffffe8,%r11
  721789:	4d 89 d1             	mov    %r10,%r9
  72178c:	49 83 c2 e8          	add    $0xffffffffffffffe8,%r10
  721790:	48 39 f9             	cmp    %rdi,%rcx
  721793:	72 bb                	jb     721750 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x1b0>
  721795:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72179c:	00 00 00 00 
  7217a0:	4d 85 c0             	test   %r8,%r8
  7217a3:	48 89 cf             	mov    %rcx,%rdi
  7217a6:	49 0f 44 fd          	cmove  %r13,%rdi
  7217aa:	48 39 17             	cmp    %rdx,(%rdi)
  7217ad:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  7217b1:	42 0f 10 04 d0       	movups (%rax,%r10,8),%xmm0
  7217b6:	4e 8b 5c d0 10       	mov    0x10(%rax,%r10,8),%r11
  7217bb:	4c 89 59 f8          	mov    %r11,-0x8(%rcx)
  7217bf:	0f 11 41 e8          	movups %xmm0,-0x18(%rcx)
  7217c3:	4c 8b 5f 10          	mov    0x10(%rdi),%r11
  7217c7:	4e 89 5c d0 10       	mov    %r11,0x10(%rax,%r10,8)
  7217cc:	0f 10 07             	movups (%rdi),%xmm0
  7217cf:	48 83 d6 00          	adc    $0x0,%rsi
  7217d3:	42 0f 11 04 d0       	movups %xmm0,(%rax,%r10,8)
  7217d8:	48 83 c1 18          	add    $0x18,%rcx
  7217dc:	49 83 c0 e8          	add    $0xffffffffffffffe8,%r8
  7217e0:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  7217e4:	75 ba                	jne    7217a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x200>
  7217e6:	4c 39 f6             	cmp    %r14,%rsi
  7217e9:	0f 83 a0 01 00 00    	jae    72198f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x3ef>
  7217ef:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
  7217f3:	49 8d 1c c7          	lea    (%r15,%rax,8),%rbx
  7217f7:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  7217fb:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  721800:	41 0f 10 07          	movups (%r15),%xmm0
  721804:	0f 29 04 24          	movaps %xmm0,(%rsp)
  721808:	49 8b 4c c7 10       	mov    0x10(%r15,%rax,8),%rcx
  72180d:	41 0f 10 04 c7       	movups (%r15,%rax,8),%xmm0
  721812:	41 0f 11 07          	movups %xmm0,(%r15)
  721816:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  72181a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  72181f:	49 89 4c c7 10       	mov    %rcx,0x10(%r15,%rax,8)
  721824:	0f 28 04 24          	movaps (%rsp),%xmm0
  721828:	41 0f 11 04 c7       	movups %xmm0,(%r15,%rax,8)
  72182d:	49 8d 2c c7          	lea    (%r15,%rax,8),%rbp
  721831:	48 83 c5 18          	add    $0x18,%rbp
  721835:	48 89 f0             	mov    %rsi,%rax
  721838:	48 f7 d0             	not    %rax
  72183b:	49 01 c6             	add    %rax,%r14
  72183e:	4c 89 ff             	mov    %r15,%rdi
  721841:	4c 89 e2             	mov    %r12,%rdx
  721844:	44 8b 7c 24 24       	mov    0x24(%rsp),%r15d
  721849:	44 89 f9             	mov    %r15d,%ecx
  72184c:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  721851:	e8 4a fd ff ff       	call   7215a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_>
  721856:	49 89 dc             	mov    %rbx,%r12
  721859:	44 89 fb             	mov    %r15d,%ebx
  72185c:	49 89 ef             	mov    %rbp,%r15
  72185f:	49 83 fe 21          	cmp    $0x21,%r14
  721863:	0f 83 dc fd ff ff    	jae    721645 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0xa5>
  721869:	e9 51 fd ff ff       	jmp    7215bf <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x1f>
  72186e:	66 90                	xchg   %ax,%ax
  721870:	4c 01 f8             	add    %r15,%rax
  721873:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  721877:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72187c:	41 0f 10 07          	movups (%r15),%xmm0
  721880:	0f 29 04 24          	movaps %xmm0,(%rsp)
  721884:	48 8b 48 10          	mov    0x10(%rax),%rcx
  721888:	0f 10 00             	movups (%rax),%xmm0
  72188b:	41 0f 11 07          	movups %xmm0,(%r15)
  72188f:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  721893:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  721898:	48 89 48 10          	mov    %rcx,0x10(%rax)
  72189c:	0f 28 04 24          	movaps (%rsp),%xmm0
  7218a0:	0f 11 00             	movups %xmm0,(%rax)
  7218a3:	49 8d 4f 18          	lea    0x18(%r15),%rcx
  7218a7:	49 8b 47 28          	mov    0x28(%r15),%rax
  7218ab:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  7218b0:	41 0f 10 47 18       	movups 0x18(%r15),%xmm0
  7218b5:	0f 29 04 24          	movaps %xmm0,(%rsp)
  7218b9:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
  7218c0:	00 
  7218c1:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
  7218c5:	4c 01 ff             	add    %r15,%rdi
  7218c8:	49 8d 57 30          	lea    0x30(%r15),%rdx
  7218cc:	49 8b 37             	mov    (%r15),%rsi
  7218cf:	4c 8d 1c 40          	lea    (%rax,%rax,2),%r11
  7218d3:	49 83 c3 b8          	add    $0xffffffffffffffb8,%r11
  7218d7:	4c 8d 14 40          	lea    (%rax,%rax,2),%r10
  7218db:	49 83 c2 d0          	add    $0xffffffffffffffd0,%r10
  7218df:	31 c0                	xor    %eax,%eax
  7218e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7218e8:	0f 1f 84 00 00 00 00 
  7218ef:	00 
  7218f0:	48 3b 32             	cmp    (%rdx),%rsi
  7218f3:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
  7218f7:	4e 8b 4c c1 10       	mov    0x10(%rcx,%r8,8),%r9
  7218fc:	42 0f 10 04 c1       	movups (%rcx,%r8,8),%xmm0
  721901:	0f 11 42 e8          	movups %xmm0,-0x18(%rdx)
  721905:	4c 89 4a f8          	mov    %r9,-0x8(%rdx)
  721909:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
  72190d:	4e 89 4c c1 10       	mov    %r9,0x10(%rcx,%r8,8)
  721912:	0f 10 02             	movups (%rdx),%xmm0
  721915:	42 0f 11 04 c1       	movups %xmm0,(%rcx,%r8,8)
  72191a:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72191e:	48 83 c2 18          	add    $0x18,%rdx
  721922:	4d 89 d8             	mov    %r11,%r8
  721925:	49 83 c3 e8          	add    $0xffffffffffffffe8,%r11
  721929:	4d 89 d1             	mov    %r10,%r9
  72192c:	49 83 c2 e8          	add    $0xffffffffffffffe8,%r10
  721930:	48 39 fa             	cmp    %rdi,%rdx
  721933:	72 bb                	jb     7218f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x350>
  721935:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72193c:	00 00 00 00 
  721940:	4d 85 c0             	test   %r8,%r8
  721943:	48 89 d7             	mov    %rdx,%rdi
  721946:	49 0f 44 fd          	cmove  %r13,%rdi
  72194a:	48 3b 37             	cmp    (%rdi),%rsi
  72194d:	4c 8d 14 40          	lea    (%rax,%rax,2),%r10
  721951:	42 0f 10 04 d1       	movups (%rcx,%r10,8),%xmm0
  721956:	4e 8b 5c d1 10       	mov    0x10(%rcx,%r10,8),%r11
  72195b:	4c 89 5a f8          	mov    %r11,-0x8(%rdx)
  72195f:	0f 11 42 e8          	movups %xmm0,-0x18(%rdx)
  721963:	4c 8b 5f 10          	mov    0x10(%rdi),%r11
  721967:	4e 89 5c d1 10       	mov    %r11,0x10(%rcx,%r10,8)
  72196c:	0f 10 07             	movups (%rdi),%xmm0
  72196f:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  721973:	42 0f 11 04 d1       	movups %xmm0,(%rcx,%r10,8)
  721978:	48 83 c2 18          	add    $0x18,%rdx
  72197c:	49 83 c0 e8          	add    $0xffffffffffffffe8,%r8
  721980:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  721984:	75 ba                	jne    721940 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x3a0>
  721986:	4c 39 f0             	cmp    %r14,%rax
  721989:	0f 82 61 fc ff ff    	jb     7215f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x50>
  72198f:	0f 0b                	ud2
  721991:	4c 89 ff             	mov    %r15,%rdi
  721994:	4c 89 f6             	mov    %r14,%rsi
  721997:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  72199c:	48 83 c4 28          	add    $0x28,%rsp
  7219a0:	5b                   	pop    %rbx
  7219a1:	41 5c                	pop    %r12
  7219a3:	41 5d                	pop    %r13
  7219a5:	41 5e                	pop    %r14
  7219a7:	41 5f                	pop    %r15
  7219a9:	5d                   	pop    %rbp
  7219aa:	e9 a1 c1 00 00       	jmp    72db50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
