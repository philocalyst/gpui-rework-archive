
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000728ac0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>:
  728ac0:	55                   	push   %rbp
  728ac1:	41 57                	push   %r15
  728ac3:	41 56                	push   %r14
  728ac5:	41 55                	push   %r13
  728ac7:	41 54                	push   %r12
  728ac9:	53                   	push   %rbx
  728aca:	50                   	push   %rax
  728acb:	4c 89 04 24          	mov    %r8,(%rsp)
  728acf:	49 89 f6             	mov    %rsi,%r14
  728ad2:	49 89 ff             	mov    %rdi,%r15
  728ad5:	48 83 fe 21          	cmp    $0x21,%rsi
  728ad9:	73 1d                	jae    728af8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x38>
  728adb:	4c 89 ff             	mov    %r15,%rdi
  728ade:	4c 89 f6             	mov    %r14,%rsi
  728ae1:	48 8b 14 24          	mov    (%rsp),%rdx
  728ae5:	48 83 c4 08          	add    $0x8,%rsp
  728ae9:	5b                   	pop    %rbx
  728aea:	41 5c                	pop    %r12
  728aec:	41 5d                	pop    %r13
  728aee:	41 5e                	pop    %r14
  728af0:	41 5f                	pop    %r15
  728af2:	5d                   	pop    %rbp
  728af3:	e9 c8 9d fe ff       	jmp    7128c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_>
  728af8:	89 cd                	mov    %ecx,%ebp
  728afa:	49 89 d4             	mov    %rdx,%r12
  728afd:	eb 3f                	jmp    728b3e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x7e>
  728aff:	90                   	nop
  728b00:	39 d6                	cmp    %edx,%esi
  728b02:	8b 34 81             	mov    (%rcx,%rax,4),%esi
  728b05:	41 89 30             	mov    %esi,(%r8)
  728b08:	89 14 81             	mov    %edx,(%rcx,%rax,4)
  728b0b:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  728b0f:	4c 39 f0             	cmp    %r14,%rax
  728b12:	0f 83 c2 02 00 00    	jae    728dda <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x31a>
  728b18:	41 8b 0f             	mov    (%r15),%ecx
  728b1b:	41 8b 14 87          	mov    (%r15,%rax,4),%edx
  728b1f:	41 89 17             	mov    %edx,(%r15)
  728b22:	41 89 0c 87          	mov    %ecx,(%r15,%rax,4)
  728b26:	48 8d 48 01          	lea    0x1(%rax),%rcx
  728b2a:	49 29 ce             	sub    %rcx,%r14
  728b2d:	4d 8d 3c 87          	lea    (%r15,%rax,4),%r15
  728b31:	49 83 c7 04          	add    $0x4,%r15
  728b35:	45 31 e4             	xor    %r12d,%r12d
  728b38:	49 83 fe 21          	cmp    $0x21,%r14
  728b3c:	72 9d                	jb     728adb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1b>
  728b3e:	85 ed                	test   %ebp,%ebp
  728b40:	0f 84 77 02 00 00    	je     728dbd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2fd>
  728b46:	4c 89 f1             	mov    %r14,%rcx
  728b49:	48 c1 e9 03          	shr    $0x3,%rcx
  728b4d:	48 89 c8             	mov    %rcx,%rax
  728b50:	48 c1 e0 04          	shl    $0x4,%rax
  728b54:	4c 01 f8             	add    %r15,%rax
  728b57:	48 8d 14 c9          	lea    (%rcx,%rcx,8),%rdx
  728b5b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  728b5f:	4c 01 fa             	add    %r15,%rdx
  728b62:	48 01 ca             	add    %rcx,%rdx
  728b65:	49 83 fe 40          	cmp    $0x40,%r14
  728b69:	0f 83 d1 00 00 00    	jae    728c40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x180>
  728b6f:	41 8b 0f             	mov    (%r15),%ecx
  728b72:	8b 30                	mov    (%rax),%esi
  728b74:	39 f1                	cmp    %esi,%ecx
  728b76:	40 0f 92 c7          	setb   %dil
  728b7a:	44 8b 02             	mov    (%rdx),%r8d
  728b7d:	44 39 c1             	cmp    %r8d,%ecx
  728b80:	0f 92 c1             	setb   %cl
  728b83:	40 30 f9             	xor    %dil,%cl
  728b86:	44 39 c6             	cmp    %r8d,%esi
  728b89:	40 0f 92 c6          	setb   %sil
  728b8d:	40 30 fe             	xor    %dil,%sil
  728b90:	48 0f 45 c2          	cmovne %rdx,%rax
  728b94:	84 c9                	test   %cl,%cl
  728b96:	49 0f 45 c7          	cmovne %r15,%rax
  728b9a:	ff cd                	dec    %ebp
  728b9c:	4c 29 f8             	sub    %r15,%rax
  728b9f:	4d 85 e4             	test   %r12,%r12
  728ba2:	0f 84 b5 00 00 00    	je     728c5d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x19d>
  728ba8:	41 8b 14 07          	mov    (%r15,%rax,1),%edx
  728bac:	41 8b 0f             	mov    (%r15),%ecx
  728baf:	41 39 14 24          	cmp    %edx,(%r12)
  728bb3:	0f 82 ab 00 00 00    	jb     728c64 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1a4>
  728bb9:	41 89 17             	mov    %edx,(%r15)
  728bbc:	41 89 0c 07          	mov    %ecx,(%r15,%rax,1)
  728bc0:	49 8d 4f 04          	lea    0x4(%r15),%rcx
  728bc4:	41 8b 37             	mov    (%r15),%esi
  728bc7:	41 8b 57 04          	mov    0x4(%r15),%edx
  728bcb:	4f 8d 04 b7          	lea    (%r15,%r14,4),%r8
  728bcf:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  728bd3:	49 8d 7f 08          	lea    0x8(%r15),%rdi
  728bd7:	4c 39 c7             	cmp    %r8,%rdi
  728bda:	0f 83 99 01 00 00    	jae    728d79 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2b9>
  728be0:	31 c0                	xor    %eax,%eax
  728be2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  728be9:	1f 84 00 00 00 00 00 
  728bf0:	44 8b 0f             	mov    (%rdi),%r9d
  728bf3:	44 39 ce             	cmp    %r9d,%esi
  728bf6:	44 8b 14 81          	mov    (%rcx,%rax,4),%r10d
  728bfa:	44 89 57 fc          	mov    %r10d,-0x4(%rdi)
  728bfe:	44 89 0c 81          	mov    %r9d,(%rcx,%rax,4)
  728c02:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  728c06:	44 8b 4f 04          	mov    0x4(%rdi),%r9d
  728c0a:	44 39 ce             	cmp    %r9d,%esi
  728c0d:	44 8b 14 81          	mov    (%rcx,%rax,4),%r10d
  728c11:	44 89 17             	mov    %r10d,(%rdi)
  728c14:	44 89 0c 81          	mov    %r9d,(%rcx,%rax,4)
  728c18:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  728c1c:	48 83 c7 08          	add    $0x8,%rdi
  728c20:	4c 39 c7             	cmp    %r8,%rdi
  728c23:	72 cb                	jb     728bf0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x130>
  728c25:	4c 8d 47 fc          	lea    -0x4(%rdi),%r8
  728c29:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  728c2d:	4c 39 cf             	cmp    %r9,%rdi
  728c30:	0f 85 5a 01 00 00    	jne    728d90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2d0>
  728c36:	e9 c5 fe ff ff       	jmp    728b00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  728c3b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  728c40:	4c 89 ff             	mov    %r15,%rdi
  728c43:	48 89 c6             	mov    %rax,%rsi
  728c46:	4c 8b 04 24          	mov    (%rsp),%r8
  728c4a:	e8 11 10 00 00       	call   729c60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  728c4f:	ff cd                	dec    %ebp
  728c51:	4c 29 f8             	sub    %r15,%rax
  728c54:	4d 85 e4             	test   %r12,%r12
  728c57:	0f 85 4b ff ff ff    	jne    728ba8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0xe8>
  728c5d:	41 8b 0f             	mov    (%r15),%ecx
  728c60:	41 8b 14 07          	mov    (%r15,%rax,1),%edx
  728c64:	41 89 17             	mov    %edx,(%r15)
  728c67:	41 89 0c 07          	mov    %ecx,(%r15,%rax,1)
  728c6b:	49 8d 47 04          	lea    0x4(%r15),%rax
  728c6f:	41 8b 17             	mov    (%r15),%edx
  728c72:	41 8b 4f 04          	mov    0x4(%r15),%ecx
  728c76:	4f 8d 04 b7          	lea    (%r15,%r14,4),%r8
  728c7a:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  728c7e:	49 8d 7f 08          	lea    0x8(%r15),%rdi
  728c82:	4c 39 c7             	cmp    %r8,%rdi
  728c85:	73 59                	jae    728ce0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x220>
  728c87:	31 f6                	xor    %esi,%esi
  728c89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  728c90:	44 8b 0f             	mov    (%rdi),%r9d
  728c93:	45 31 d2             	xor    %r10d,%r10d
  728c96:	41 39 d1             	cmp    %edx,%r9d
  728c99:	41 0f 92 c2          	setb   %r10b
  728c9d:	44 8b 1c b0          	mov    (%rax,%rsi,4),%r11d
  728ca1:	44 89 5f fc          	mov    %r11d,-0x4(%rdi)
  728ca5:	44 89 0c b0          	mov    %r9d,(%rax,%rsi,4)
  728ca9:	4e 8d 0c 16          	lea    (%rsi,%r10,1),%r9
  728cad:	44 8b 5f 04          	mov    0x4(%rdi),%r11d
  728cb1:	41 39 d3             	cmp    %edx,%r11d
  728cb4:	46 8b 2c 88          	mov    (%rax,%r9,4),%r13d
  728cb8:	44 89 2f             	mov    %r13d,(%rdi)
  728cbb:	46 89 1c 88          	mov    %r11d,(%rax,%r9,4)
  728cbf:	4c 11 d6             	adc    %r10,%rsi
  728cc2:	48 83 c7 08          	add    $0x8,%rdi
  728cc6:	4c 39 c7             	cmp    %r8,%rdi
  728cc9:	72 c5                	jb     728c90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1d0>
  728ccb:	4c 8d 47 fc          	lea    -0x4(%rdi),%r8
  728ccf:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  728cd3:	4c 39 cf             	cmp    %r9,%rdi
  728cd6:	75 18                	jne    728cf0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x230>
  728cd8:	eb 3e                	jmp    728d18 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x258>
  728cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  728ce0:	49 89 c0             	mov    %rax,%r8
  728ce3:	31 f6                	xor    %esi,%esi
  728ce5:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  728ce9:	4c 39 cf             	cmp    %r9,%rdi
  728cec:	74 2a                	je     728d18 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x258>
  728cee:	66 90                	xchg   %ax,%ax
  728cf0:	4d 89 c2             	mov    %r8,%r10
  728cf3:	49 89 f8             	mov    %rdi,%r8
  728cf6:	8b 3f                	mov    (%rdi),%edi
  728cf8:	39 d7                	cmp    %edx,%edi
  728cfa:	44 8b 1c b0          	mov    (%rax,%rsi,4),%r11d
  728cfe:	45 89 1a             	mov    %r11d,(%r10)
  728d01:	89 3c b0             	mov    %edi,(%rax,%rsi,4)
  728d04:	48 83 d6 00          	adc    $0x0,%rsi
  728d08:	49 8d 78 04          	lea    0x4(%r8),%rdi
  728d0c:	4c 39 cf             	cmp    %r9,%rdi
  728d0f:	75 df                	jne    728cf0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x230>
  728d11:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  728d15:	49 89 f8             	mov    %rdi,%r8
  728d18:	39 d1                	cmp    %edx,%ecx
  728d1a:	8b 14 b0             	mov    (%rax,%rsi,4),%edx
  728d1d:	41 89 10             	mov    %edx,(%r8)
  728d20:	89 0c b0             	mov    %ecx,(%rax,%rsi,4)
  728d23:	48 83 d6 00          	adc    $0x0,%rsi
  728d27:	4c 39 f6             	cmp    %r14,%rsi
  728d2a:	0f 83 aa 00 00 00    	jae    728dda <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x31a>
  728d30:	4d 8d 2c b7          	lea    (%r15,%rsi,4),%r13
  728d34:	41 8b 07             	mov    (%r15),%eax
  728d37:	41 8b 0c b7          	mov    (%r15,%rsi,4),%ecx
  728d3b:	41 89 0f             	mov    %ecx,(%r15)
  728d3e:	41 89 04 b7          	mov    %eax,(%r15,%rsi,4)
  728d42:	49 8d 1c b7          	lea    (%r15,%rsi,4),%rbx
  728d46:	48 83 c3 04          	add    $0x4,%rbx
  728d4a:	48 89 f0             	mov    %rsi,%rax
  728d4d:	48 f7 d0             	not    %rax
  728d50:	49 01 c6             	add    %rax,%r14
  728d53:	4c 89 ff             	mov    %r15,%rdi
  728d56:	4c 89 e2             	mov    %r12,%rdx
  728d59:	89 e9                	mov    %ebp,%ecx
  728d5b:	4c 8b 04 24          	mov    (%rsp),%r8
  728d5f:	e8 5c fd ff ff       	call   728ac0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>
  728d64:	4d 89 ec             	mov    %r13,%r12
  728d67:	49 89 df             	mov    %rbx,%r15
  728d6a:	49 83 fe 21          	cmp    $0x21,%r14
  728d6e:	0f 83 ca fd ff ff    	jae    728b3e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x7e>
  728d74:	e9 62 fd ff ff       	jmp    728adb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1b>
  728d79:	49 89 c8             	mov    %rcx,%r8
  728d7c:	31 c0                	xor    %eax,%eax
  728d7e:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  728d82:	4c 39 cf             	cmp    %r9,%rdi
  728d85:	0f 84 75 fd ff ff    	je     728b00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  728d8b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  728d90:	4d 89 c2             	mov    %r8,%r10
  728d93:	49 89 f8             	mov    %rdi,%r8
  728d96:	8b 3f                	mov    (%rdi),%edi
  728d98:	39 fe                	cmp    %edi,%esi
  728d9a:	44 8b 1c 81          	mov    (%rcx,%rax,4),%r11d
  728d9e:	45 89 1a             	mov    %r11d,(%r10)
  728da1:	89 3c 81             	mov    %edi,(%rcx,%rax,4)
  728da4:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  728da8:	49 8d 78 04          	lea    0x4(%r8),%rdi
  728dac:	4c 39 cf             	cmp    %r9,%rdi
  728daf:	75 df                	jne    728d90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2d0>
  728db1:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  728db5:	49 89 f8             	mov    %rdi,%r8
  728db8:	e9 43 fd ff ff       	jmp    728b00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  728dbd:	4c 89 ff             	mov    %r15,%rdi
  728dc0:	4c 89 f6             	mov    %r14,%rsi
  728dc3:	48 8b 14 24          	mov    (%rsp),%rdx
  728dc7:	48 83 c4 08          	add    $0x8,%rsp
  728dcb:	5b                   	pop    %rbx
  728dcc:	41 5c                	pop    %r12
  728dce:	41 5d                	pop    %r13
  728dd0:	41 5e                	pop    %r14
  728dd2:	41 5f                	pop    %r15
  728dd4:	5d                   	pop    %rbp
  728dd5:	e9 e6 9f 00 00       	jmp    732dc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_>
  728dda:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
