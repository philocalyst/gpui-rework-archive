
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000007108f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_>:
  7108f0:	55                   	push   %rbp
  7108f1:	41 57                	push   %r15
  7108f3:	41 56                	push   %r14
  7108f5:	41 55                	push   %r13
  7108f7:	41 54                	push   %r12
  7108f9:	53                   	push   %rbx
  7108fa:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
  710901:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  710906:	48 83 fe 02          	cmp    $0x2,%rsi
  71090a:	0f 82 2e 06 00 00    	jb     710f3e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x64e>
  710910:	49 89 f5             	mov    %rsi,%r13
  710913:	48 83 fe 20          	cmp    $0x20,%rsi
  710917:	0f 87 6c 06 00 00    	ja     710f89 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x699>
  71091d:	4d 89 ec             	mov    %r13,%r12
  710920:	49 d1 ec             	shr    $1,%r12
  710923:	49 83 fd 12          	cmp    $0x12,%r13
  710927:	4c 89 e2             	mov    %r12,%rdx
  71092a:	49 0f 42 d5          	cmovb  %r13,%rdx
  71092e:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  710933:	4f 8d 3c a0          	lea    (%r8,%r12,4),%r15
  710937:	4c 89 e8             	mov    %r13,%rax
  71093a:	4c 29 e0             	sub    %r12,%rax
  71093d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  710942:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
  710947:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  71094c:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  710951:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  710958:	0f 1f 84 00 00 00 00 
  71095f:	00 
  710960:	48 83 fa 0c          	cmp    $0xc,%rdx
  710964:	0f 86 f6 02 00 00    	jbe    710c60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x370>
  71096a:	41 8b 40 30          	mov    0x30(%r8),%eax
  71096e:	45 8b 30             	mov    (%r8),%r14d
  710971:	41 8b 48 04          	mov    0x4(%r8),%ecx
  710975:	44 39 f0             	cmp    %r14d,%eax
  710978:	44 89 f6             	mov    %r14d,%esi
  71097b:	0f 47 f0             	cmova  %eax,%esi
  71097e:	44 0f 42 f0          	cmovb  %eax,%r14d
  710982:	41 8b 40 28          	mov    0x28(%r8),%eax
  710986:	39 c8                	cmp    %ecx,%eax
  710988:	41 89 cf             	mov    %ecx,%r15d
  71098b:	44 0f 47 f8          	cmova  %eax,%r15d
  71098f:	0f 42 c8             	cmovb  %eax,%ecx
  710992:	41 8b 40 24          	mov    0x24(%r8),%eax
  710996:	41 8b 68 08          	mov    0x8(%r8),%ebp
  71099a:	39 e8                	cmp    %ebp,%eax
  71099c:	41 89 ec             	mov    %ebp,%r12d
  71099f:	44 0f 47 e0          	cmova  %eax,%r12d
  7109a3:	0f 42 e8             	cmovb  %eax,%ebp
  7109a6:	41 8b 40 1c          	mov    0x1c(%r8),%eax
  7109aa:	41 8b 58 0c          	mov    0xc(%r8),%ebx
  7109ae:	39 d8                	cmp    %ebx,%eax
  7109b0:	41 89 da             	mov    %ebx,%r10d
  7109b3:	44 0f 47 d0          	cmova  %eax,%r10d
  7109b7:	0f 42 d8             	cmovb  %eax,%ebx
  7109ba:	41 8b 40 2c          	mov    0x2c(%r8),%eax
  7109be:	41 8b 78 14          	mov    0x14(%r8),%edi
  7109c2:	39 f8                	cmp    %edi,%eax
  7109c4:	41 89 fd             	mov    %edi,%r13d
  7109c7:	44 0f 47 e8          	cmova  %eax,%r13d
  7109cb:	0f 42 f8             	cmovb  %eax,%edi
  7109ce:	89 7c 24 04          	mov    %edi,0x4(%rsp)
  7109d2:	41 8b 40 20          	mov    0x20(%r8),%eax
  7109d6:	45 8b 58 18          	mov    0x18(%r8),%r11d
  7109da:	44 39 d8             	cmp    %r11d,%eax
  7109dd:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  7109e2:	44 89 da             	mov    %r11d,%edx
  7109e5:	0f 47 d0             	cmova  %eax,%edx
  7109e8:	44 0f 42 d8          	cmovb  %eax,%r11d
  7109ec:	41 39 cb             	cmp    %ecx,%r11d
  7109ef:	41 89 c9             	mov    %ecx,%r9d
  7109f2:	45 0f 47 cb          	cmova  %r11d,%r9d
  7109f6:	44 0f 43 d9          	cmovae %ecx,%r11d
  7109fa:	39 eb                	cmp    %ebp,%ebx
  7109fc:	89 e9                	mov    %ebp,%ecx
  7109fe:	0f 47 cb             	cmova  %ebx,%ecx
  710a01:	0f 43 dd             	cmovae %ebp,%ebx
  710a04:	41 8b 40 10          	mov    0x10(%r8),%eax
  710a08:	41 39 c5             	cmp    %eax,%r13d
  710a0b:	89 c5                	mov    %eax,%ebp
  710a0d:	41 0f 47 ed          	cmova  %r13d,%ebp
  710a11:	44 0f 43 e8          	cmovae %eax,%r13d
  710a15:	45 39 d4             	cmp    %r10d,%r12d
  710a18:	44 89 d0             	mov    %r10d,%eax
  710a1b:	41 0f 47 c4          	cmova  %r12d,%eax
  710a1f:	45 0f 42 d4          	cmovb  %r12d,%r10d
  710a23:	41 39 d7             	cmp    %edx,%r15d
  710a26:	41 89 d4             	mov    %edx,%r12d
  710a29:	45 0f 47 e7          	cmova  %r15d,%r12d
  710a2d:	41 0f 42 d7          	cmovb  %r15d,%edx
  710a31:	45 39 f5             	cmp    %r14d,%r13d
  710a34:	44 89 f7             	mov    %r14d,%edi
  710a37:	41 0f 47 fd          	cmova  %r13d,%edi
  710a3b:	45 0f 43 ee          	cmovae %r14d,%r13d
  710a3f:	44 39 db             	cmp    %r11d,%ebx
  710a42:	45 89 de             	mov    %r11d,%r14d
  710a45:	44 0f 47 f3          	cmova  %ebx,%r14d
  710a49:	44 89 34 24          	mov    %r14d,(%rsp)
  710a4d:	41 0f 43 db          	cmovae %r11d,%ebx
  710a51:	41 39 c9             	cmp    %ecx,%r9d
  710a54:	41 89 cf             	mov    %ecx,%r15d
  710a57:	45 0f 47 f9          	cmova  %r9d,%r15d
  710a5b:	41 0f 42 c9          	cmovb  %r9d,%ecx
  710a5f:	44 39 d2             	cmp    %r10d,%edx
  710a62:	45 89 d1             	mov    %r10d,%r9d
  710a65:	44 0f 47 ca          	cmova  %edx,%r9d
  710a69:	41 0f 43 d2          	cmovae %r10d,%edx
  710a6d:	41 39 c4             	cmp    %eax,%r12d
  710a70:	41 89 c6             	mov    %eax,%r14d
  710a73:	45 0f 47 f4          	cmova  %r12d,%r14d
  710a77:	44 0f 43 e0          	cmovae %eax,%r12d
  710a7b:	39 ee                	cmp    %ebp,%esi
  710a7d:	41 89 ea             	mov    %ebp,%r10d
  710a80:	44 0f 47 d6          	cmova  %esi,%r10d
  710a84:	0f 42 ee             	cmovb  %esi,%ebp
  710a87:	41 39 ff             	cmp    %edi,%r15d
  710a8a:	89 fe                	mov    %edi,%esi
  710a8c:	41 0f 47 f7          	cmova  %r15d,%esi
  710a90:	44 0f 43 ff          	cmovae %edi,%r15d
  710a94:	8b 44 24 04          	mov    0x4(%rsp),%eax
  710a98:	41 39 c4             	cmp    %eax,%r12d
  710a9b:	41 89 c3             	mov    %eax,%r11d
  710a9e:	45 0f 47 dc          	cmova  %r12d,%r11d
  710aa2:	44 0f 43 e0          	cmovae %eax,%r12d
  710aa6:	44 39 cd             	cmp    %r9d,%ebp
  710aa9:	44 89 c8             	mov    %r9d,%eax
  710aac:	0f 47 c5             	cmova  %ebp,%eax
  710aaf:	41 0f 43 e9          	cmovae %r9d,%ebp
  710ab3:	45 39 f2             	cmp    %r14d,%r10d
  710ab6:	44 89 f7             	mov    %r14d,%edi
  710ab9:	41 0f 47 fa          	cmova  %r10d,%edi
  710abd:	89 7c 24 04          	mov    %edi,0x4(%rsp)
  710ac1:	45 0f 43 d6          	cmovae %r14d,%r10d
  710ac5:	45 39 ec             	cmp    %r13d,%r12d
  710ac8:	45 89 ee             	mov    %r13d,%r14d
  710acb:	45 0f 47 f4          	cmova  %r12d,%r14d
  710acf:	45 0f 43 e5          	cmovae %r13d,%r12d
  710ad3:	39 cd                	cmp    %ecx,%ebp
  710ad5:	89 cf                	mov    %ecx,%edi
  710ad7:	0f 47 fd             	cmova  %ebp,%edi
  710ada:	0f 43 e9             	cmovae %ecx,%ebp
  710add:	44 39 fa             	cmp    %r15d,%edx
  710ae0:	45 89 fd             	mov    %r15d,%r13d
  710ae3:	44 0f 47 ea          	cmova  %edx,%r13d
  710ae7:	44 0f 42 fa          	cmovb  %edx,%r15d
  710aeb:	39 f0                	cmp    %esi,%eax
  710aed:	41 89 f1             	mov    %esi,%r9d
  710af0:	44 0f 47 c8          	cmova  %eax,%r9d
  710af4:	0f 43 c6             	cmovae %esi,%eax
  710af7:	45 39 da             	cmp    %r11d,%r10d
  710afa:	44 89 da             	mov    %r11d,%edx
  710afd:	41 0f 47 d2          	cmova  %r10d,%edx
  710b01:	45 0f 43 d3          	cmovae %r11d,%r10d
  710b05:	44 39 e3             	cmp    %r12d,%ebx
  710b08:	45 89 e3             	mov    %r12d,%r11d
  710b0b:	44 0f 47 db          	cmova  %ebx,%r11d
  710b0f:	44 0f 42 e3          	cmovb  %ebx,%r12d
  710b13:	8b 34 24             	mov    (%rsp),%esi
  710b16:	41 39 f6             	cmp    %esi,%r14d
  710b19:	89 f1                	mov    %esi,%ecx
  710b1b:	41 0f 47 ce          	cmova  %r14d,%ecx
  710b1f:	44 0f 43 f6          	cmovae %esi,%r14d
  710b23:	41 39 c2             	cmp    %eax,%r10d
  710b26:	89 c6                	mov    %eax,%esi
  710b28:	41 0f 47 f2          	cmova  %r10d,%esi
  710b2c:	44 0f 43 d0          	cmovae %eax,%r10d
  710b30:	44 39 ef             	cmp    %r13d,%edi
  710b33:	44 89 e8             	mov    %r13d,%eax
  710b36:	0f 47 c7             	cmova  %edi,%eax
  710b39:	44 0f 42 ef          	cmovb  %edi,%r13d
  710b3d:	41 39 d1             	cmp    %edx,%r9d
  710b40:	89 d7                	mov    %edx,%edi
  710b42:	41 0f 47 f9          	cmova  %r9d,%edi
  710b46:	89 3c 24             	mov    %edi,(%rsp)
  710b49:	41 0f 42 d1          	cmovb  %r9d,%edx
  710b4d:	44 39 dd             	cmp    %r11d,%ebp
  710b50:	45 89 d9             	mov    %r11d,%r9d
  710b53:	44 0f 47 cd          	cmova  %ebp,%r9d
  710b57:	44 0f 42 dd          	cmovb  %ebp,%r11d
  710b5b:	45 39 f7             	cmp    %r14d,%r15d
  710b5e:	44 89 f3             	mov    %r14d,%ebx
  710b61:	41 0f 47 df          	cmova  %r15d,%ebx
  710b65:	45 0f 42 f7          	cmovb  %r15d,%r14d
  710b69:	41 39 ca             	cmp    %ecx,%r10d
  710b6c:	89 cf                	mov    %ecx,%edi
  710b6e:	41 0f 47 fa          	cmova  %r10d,%edi
  710b72:	44 0f 43 d1          	cmovae %ecx,%r10d
  710b76:	39 f2                	cmp    %esi,%edx
  710b78:	89 f5                	mov    %esi,%ebp
  710b7a:	0f 47 ea             	cmova  %edx,%ebp
  710b7d:	0f 43 d6             	cmovae %esi,%edx
  710b80:	45 39 de             	cmp    %r11d,%r14d
  710b83:	45 89 df             	mov    %r11d,%r15d
  710b86:	45 0f 47 fe          	cmova  %r14d,%r15d
  710b8a:	45 0f 43 f3          	cmovae %r11d,%r14d
  710b8e:	44 39 cb             	cmp    %r9d,%ebx
  710b91:	45 89 cb             	mov    %r9d,%r11d
  710b94:	44 0f 47 db          	cmova  %ebx,%r11d
  710b98:	8b 4c 24 04          	mov    0x4(%rsp),%ecx
  710b9c:	41 89 48 30          	mov    %ecx,0x30(%r8)
  710ba0:	41 0f 43 d9          	cmovae %r9d,%ebx
  710ba4:	45 39 d5             	cmp    %r10d,%r13d
  710ba7:	45 89 d1             	mov    %r10d,%r9d
  710baa:	45 0f 47 cd          	cmova  %r13d,%r9d
  710bae:	45 89 20             	mov    %r12d,(%r8)
  710bb1:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  710bb6:	45 0f 42 d5          	cmovb  %r13d,%r10d
  710bba:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  710bbf:	39 f8                	cmp    %edi,%eax
  710bc1:	89 f9                	mov    %edi,%ecx
  710bc3:	0f 47 c8             	cmova  %eax,%ecx
  710bc6:	8b 34 24             	mov    (%rsp),%esi
  710bc9:	41 89 70 2c          	mov    %esi,0x2c(%r8)
  710bcd:	0f 42 f8             	cmovb  %eax,%edi
  710bd0:	44 39 fb             	cmp    %r15d,%ebx
  710bd3:	44 89 fe             	mov    %r15d,%esi
  710bd6:	0f 47 f3             	cmova  %ebx,%esi
  710bd9:	41 89 68 28          	mov    %ebp,0x28(%r8)
  710bdd:	41 0f 43 df          	cmovae %r15d,%ebx
  710be1:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  710be6:	45 39 da             	cmp    %r11d,%r10d
  710be9:	44 89 d8             	mov    %r11d,%eax
  710bec:	41 0f 47 c2          	cmova  %r10d,%eax
  710bf0:	45 89 70 04          	mov    %r14d,0x4(%r8)
  710bf4:	45 0f 43 d3          	cmovae %r11d,%r10d
  710bf8:	41 39 f9             	cmp    %edi,%r9d
  710bfb:	41 89 fb             	mov    %edi,%r11d
  710bfe:	45 0f 47 d9          	cmova  %r9d,%r11d
  710c02:	41 89 58 08          	mov    %ebx,0x8(%r8)
  710c06:	41 0f 42 f9          	cmovb  %r9d,%edi
  710c0a:	39 ca                	cmp    %ecx,%edx
  710c0c:	41 89 c9             	mov    %ecx,%r9d
  710c0f:	44 0f 47 ca          	cmova  %edx,%r9d
  710c13:	45 89 58 1c          	mov    %r11d,0x1c(%r8)
  710c17:	0f 42 ca             	cmovb  %edx,%ecx
  710c1a:	41 39 f2             	cmp    %esi,%r10d
  710c1d:	89 f2                	mov    %esi,%edx
  710c1f:	41 0f 47 d2          	cmova  %r10d,%edx
  710c23:	41 89 48 20          	mov    %ecx,0x20(%r8)
  710c27:	44 0f 43 d6          	cmovae %esi,%r10d
  710c2b:	39 c7                	cmp    %eax,%edi
  710c2d:	89 c1                	mov    %eax,%ecx
  710c2f:	0f 47 cf             	cmova  %edi,%ecx
  710c32:	45 89 48 24          	mov    %r9d,0x24(%r8)
  710c36:	45 89 50 0c          	mov    %r10d,0xc(%r8)
  710c3a:	0f 43 f8             	cmovae %eax,%edi
  710c3d:	41 89 50 10          	mov    %edx,0x10(%r8)
  710c41:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  710c46:	41 89 78 14          	mov    %edi,0x14(%r8)
  710c4a:	41 89 48 18          	mov    %ecx,0x18(%r8)
  710c4e:	b9 0d 00 00 00       	mov    $0xd,%ecx
  710c53:	e9 ae 01 00 00       	jmp    710e06 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x516>
  710c58:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  710c5f:	00 
  710c60:	b9 01 00 00 00       	mov    $0x1,%ecx
  710c65:	48 83 fa 08          	cmp    $0x8,%rdx
  710c69:	0f 86 97 01 00 00    	jbe    710e06 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x516>
  710c6f:	41 8b 40 0c          	mov    0xc(%r8),%eax
  710c73:	45 8b 08             	mov    (%r8),%r9d
  710c76:	41 8b 48 04          	mov    0x4(%r8),%ecx
  710c7a:	44 39 c8             	cmp    %r9d,%eax
  710c7d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  710c82:	44 89 ca             	mov    %r9d,%edx
  710c85:	0f 47 d0             	cmova  %eax,%edx
  710c88:	44 0f 42 c8          	cmovb  %eax,%r9d
  710c8c:	41 8b 40 1c          	mov    0x1c(%r8),%eax
  710c90:	39 c8                	cmp    %ecx,%eax
  710c92:	89 cf                	mov    %ecx,%edi
  710c94:	0f 47 f8             	cmova  %eax,%edi
  710c97:	0f 42 c8             	cmovb  %eax,%ecx
  710c9a:	41 8b 40 14          	mov    0x14(%r8),%eax
  710c9e:	45 8b 58 08          	mov    0x8(%r8),%r11d
  710ca2:	44 39 d8             	cmp    %r11d,%eax
  710ca5:	45 89 da             	mov    %r11d,%r10d
  710ca8:	44 0f 47 d0          	cmova  %eax,%r10d
  710cac:	44 0f 42 d8          	cmovb  %eax,%r11d
  710cb0:	41 8b 58 20          	mov    0x20(%r8),%ebx
  710cb4:	41 8b 70 10          	mov    0x10(%r8),%esi
  710cb8:	39 f3                	cmp    %esi,%ebx
  710cba:	89 f0                	mov    %esi,%eax
  710cbc:	0f 47 c3             	cmova  %ebx,%eax
  710cbf:	0f 42 f3             	cmovb  %ebx,%esi
  710cc2:	44 39 cf             	cmp    %r9d,%edi
  710cc5:	44 89 cb             	mov    %r9d,%ebx
  710cc8:	0f 47 df             	cmova  %edi,%ebx
  710ccb:	41 0f 43 f9          	cmovae %r9d,%edi
  710ccf:	44 39 de             	cmp    %r11d,%esi
  710cd2:	44 89 dd             	mov    %r11d,%ebp
  710cd5:	0f 47 ee             	cmova  %esi,%ebp
  710cd8:	41 0f 43 f3          	cmovae %r11d,%esi
  710cdc:	39 d0                	cmp    %edx,%eax
  710cde:	41 89 d3             	mov    %edx,%r11d
  710ce1:	44 0f 47 d8          	cmova  %eax,%r11d
  710ce5:	0f 43 c2             	cmovae %edx,%eax
  710ce8:	41 8b 50 18          	mov    0x18(%r8),%edx
  710cec:	44 39 d2             	cmp    %r10d,%edx
  710cef:	45 89 d1             	mov    %r10d,%r9d
  710cf2:	44 0f 47 ca          	cmova  %edx,%r9d
  710cf6:	44 0f 42 d2          	cmovb  %edx,%r10d
  710cfa:	39 fe                	cmp    %edi,%esi
  710cfc:	89 fa                	mov    %edi,%edx
  710cfe:	0f 47 d6             	cmova  %esi,%edx
  710d01:	0f 43 f7             	cmovae %edi,%esi
  710d04:	39 c8                	cmp    %ecx,%eax
  710d06:	89 cf                	mov    %ecx,%edi
  710d08:	0f 47 f8             	cmova  %eax,%edi
  710d0b:	0f 43 c1             	cmovae %ecx,%eax
  710d0e:	41 39 ea             	cmp    %ebp,%r10d
  710d11:	41 89 ec             	mov    %ebp,%r12d
  710d14:	45 0f 47 e2          	cmova  %r10d,%r12d
  710d18:	44 0f 43 d5          	cmovae %ebp,%r10d
  710d1c:	41 39 db             	cmp    %ebx,%r11d
  710d1f:	41 89 df             	mov    %ebx,%r15d
  710d22:	45 0f 47 fb          	cmova  %r11d,%r15d
  710d26:	44 0f 43 db          	cmovae %ebx,%r11d
  710d2a:	41 39 c2             	cmp    %eax,%r10d
  710d2d:	41 89 c6             	mov    %eax,%r14d
  710d30:	45 0f 47 f2          	cmova  %r10d,%r14d
  710d34:	44 0f 43 d0          	cmovae %eax,%r10d
  710d38:	41 39 f9             	cmp    %edi,%r9d
  710d3b:	89 f9                	mov    %edi,%ecx
  710d3d:	41 0f 47 c9          	cmova  %r9d,%ecx
  710d41:	41 0f 42 f9          	cmovb  %r9d,%edi
  710d45:	45 39 e3             	cmp    %r12d,%r11d
  710d48:	44 89 e5             	mov    %r12d,%ebp
  710d4b:	41 0f 47 eb          	cmova  %r11d,%ebp
  710d4f:	45 0f 43 dc          	cmovae %r12d,%r11d
  710d53:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  710d58:	41 39 f2             	cmp    %esi,%r10d
  710d5b:	89 f3                	mov    %esi,%ebx
  710d5d:	41 0f 47 da          	cmova  %r10d,%ebx
  710d61:	44 0f 43 d6          	cmovae %esi,%r10d
  710d65:	41 39 d6             	cmp    %edx,%r14d
  710d68:	89 d6                	mov    %edx,%esi
  710d6a:	41 0f 47 f6          	cmova  %r14d,%esi
  710d6e:	44 0f 43 f2          	cmovae %edx,%r14d
  710d72:	41 39 fb             	cmp    %edi,%r11d
  710d75:	89 f8                	mov    %edi,%eax
  710d77:	41 0f 47 c3          	cmova  %r11d,%eax
  710d7b:	44 0f 43 df          	cmovae %edi,%r11d
  710d7f:	41 39 cf             	cmp    %ecx,%r15d
  710d82:	89 cf                	mov    %ecx,%edi
  710d84:	41 0f 47 ff          	cmova  %r15d,%edi
  710d88:	41 0f 42 cf          	cmovb  %r15d,%ecx
  710d8c:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  710d91:	45 39 f3             	cmp    %r14d,%r11d
  710d94:	45 89 f1             	mov    %r14d,%r9d
  710d97:	45 0f 47 cb          	cmova  %r11d,%r9d
  710d9b:	45 0f 43 de          	cmovae %r14d,%r11d
  710d9f:	39 f0                	cmp    %esi,%eax
  710da1:	89 f2                	mov    %esi,%edx
  710da3:	0f 47 d0             	cmova  %eax,%edx
  710da6:	45 89 10             	mov    %r10d,(%r8)
  710da9:	0f 43 c6             	cmovae %esi,%eax
  710dac:	39 cd                	cmp    %ecx,%ebp
  710dae:	89 ce                	mov    %ecx,%esi
  710db0:	0f 47 f5             	cmova  %ebp,%esi
  710db3:	41 89 78 20          	mov    %edi,0x20(%r8)
  710db7:	0f 42 cd             	cmovb  %ebp,%ecx
  710dba:	41 39 db             	cmp    %ebx,%r11d
  710dbd:	89 df                	mov    %ebx,%edi
  710dbf:	41 0f 47 fb          	cmova  %r11d,%edi
  710dc3:	41 89 70 1c          	mov    %esi,0x1c(%r8)
  710dc7:	44 0f 43 db          	cmovae %ebx,%r11d
  710dcb:	44 39 c8             	cmp    %r9d,%eax
  710dce:	44 89 ce             	mov    %r9d,%esi
  710dd1:	0f 47 f0             	cmova  %eax,%esi
  710dd4:	45 89 58 04          	mov    %r11d,0x4(%r8)
  710dd8:	41 0f 43 c1          	cmovae %r9d,%eax
  710ddc:	39 d1                	cmp    %edx,%ecx
  710dde:	41 89 d1             	mov    %edx,%r9d
  710de1:	44 0f 47 c9          	cmova  %ecx,%r9d
  710de5:	41 89 78 08          	mov    %edi,0x8(%r8)
  710de9:	41 89 40 0c          	mov    %eax,0xc(%r8)
  710ded:	0f 43 ca             	cmovae %edx,%ecx
  710df0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  710df5:	41 89 70 10          	mov    %esi,0x10(%r8)
  710df9:	41 89 48 14          	mov    %ecx,0x14(%r8)
  710dfd:	45 89 48 18          	mov    %r9d,0x18(%r8)
  710e01:	b9 09 00 00 00       	mov    $0x9,%ecx
  710e06:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
  710e0a:	48 39 d0             	cmp    %rdx,%rax
  710e0d:	0f 83 76 01 00 00    	jae    710f89 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x699>
  710e13:	48 39 d1             	cmp    %rdx,%rcx
  710e16:	75 28                	jne    710e40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x550>
  710e18:	49 83 fd 12          	cmp    $0x12,%r13
  710e1c:	0f 82 1c 01 00 00    	jb     710f3e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x64e>
  710e22:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  710e27:	4c 3b 44 24 08       	cmp    0x8(%rsp),%r8
  710e2c:	4d 89 f8             	mov    %r15,%r8
  710e2f:	0f 84 2b fb ff ff    	je     710960 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x70>
  710e35:	eb 56                	jmp    710e8d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x59d>
  710e37:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  710e3e:	00 00 
  710e40:	49 8d 34 90          	lea    (%r8,%rdx,4),%rsi
  710e44:	c1 e1 02             	shl    $0x2,%ecx
  710e47:	49 8d 04 08          	lea    (%r8,%rcx,1),%rax
  710e4b:	eb 15                	jmp    710e62 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x572>
  710e4d:	0f 1f 00             	nopl   (%rax)
  710e50:	4c 89 c7             	mov    %r8,%rdi
  710e53:	89 17                	mov    %edx,(%rdi)
  710e55:	48 83 c0 04          	add    $0x4,%rax
  710e59:	48 83 c1 04          	add    $0x4,%rcx
  710e5d:	48 39 f0             	cmp    %rsi,%rax
  710e60:	74 b6                	je     710e18 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x528>
  710e62:	44 8b 48 fc          	mov    -0x4(%rax),%r9d
  710e66:	8b 10                	mov    (%rax),%edx
  710e68:	44 39 ca             	cmp    %r9d,%edx
  710e6b:	73 e8                	jae    710e55 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x565>
  710e6d:	48 89 cf             	mov    %rcx,%rdi
  710e70:	45 89 0c 38          	mov    %r9d,(%r8,%rdi,1)
  710e74:	48 83 ff 04          	cmp    $0x4,%rdi
  710e78:	74 d6                	je     710e50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x560>
  710e7a:	45 8b 4c 38 f8       	mov    -0x8(%r8,%rdi,1),%r9d
  710e7f:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  710e83:	44 39 ca             	cmp    %r9d,%edx
  710e86:	72 e8                	jb     710e70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x580>
  710e88:	4c 01 c7             	add    %r8,%rdi
  710e8b:	eb c6                	jmp    710e53 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x563>
  710e8d:	49 8d 7d ff          	lea    -0x1(%r13),%rdi
  710e91:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  710e96:	4f 8d 04 a9          	lea    (%r9,%r13,4),%r8
  710e9a:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  710e9e:	49 8d 77 fc          	lea    -0x4(%r15),%rsi
  710ea2:	31 c9                	xor    %ecx,%ecx
  710ea4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  710eab:	00 00 00 00 00 
  710eb0:	41 8b 07             	mov    (%r15),%eax
  710eb3:	41 8b 11             	mov    (%r9),%edx
  710eb6:	45 31 d2             	xor    %r10d,%r10d
  710eb9:	45 31 db             	xor    %r11d,%r11d
  710ebc:	39 d0                	cmp    %edx,%eax
  710ebe:	41 0f 93 c2          	setae  %r10b
  710ec2:	41 0f 92 c3          	setb   %r11b
  710ec6:	0f 42 d0             	cmovb  %eax,%edx
  710ec9:	41 8b 00             	mov    (%r8),%eax
  710ecc:	8b 1e                	mov    (%rsi),%ebx
  710ece:	39 d8                	cmp    %ebx,%eax
  710ed0:	41 be 00 00 00 00    	mov    $0x0,%r14d
  710ed6:	49 83 d6 ff          	adc    $0xffffffffffffffff,%r14
  710eda:	39 d8                	cmp    %ebx,%eax
  710edc:	0f 47 d8             	cmova  %eax,%ebx
  710edf:	89 54 8c 38          	mov    %edx,0x38(%rsp,%rcx,4)
  710ee3:	b8 00 00 00 00       	mov    $0x0,%eax
  710ee8:	48 19 c0             	sbb    %rax,%rax
  710eeb:	48 ff c1             	inc    %rcx
  710eee:	4f 8d 3c 9f          	lea    (%r15,%r11,4),%r15
  710ef2:	4f 8d 0c 91          	lea    (%r9,%r10,4),%r9
  710ef6:	89 5c bc 38          	mov    %ebx,0x38(%rsp,%rdi,4)
  710efa:	4f 8d 04 b0          	lea    (%r8,%r14,4),%r8
  710efe:	48 8d 34 86          	lea    (%rsi,%rax,4),%rsi
  710f02:	48 ff cf             	dec    %rdi
  710f05:	49 39 cc             	cmp    %rcx,%r12
  710f08:	75 a6                	jne    710eb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x5c0>
  710f0a:	48 83 c6 04          	add    $0x4,%rsi
  710f0e:	49 83 c0 04          	add    $0x4,%r8
  710f12:	41 f6 c5 01          	test   $0x1,%r13b
  710f16:	75 38                	jne    710f50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x660>
  710f18:	4d 39 c7             	cmp    %r8,%r15
  710f1b:	0f 95 c0             	setne  %al
  710f1e:	49 39 f1             	cmp    %rsi,%r9
  710f21:	75 5a                	jne    710f7d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x68d>
  710f23:	84 c0                	test   %al,%al
  710f25:	75 5c                	jne    710f83 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x693>
  710f27:	49 c1 e5 02          	shl    $0x2,%r13
  710f2b:	48 8d 74 24 38       	lea    0x38(%rsp),%rsi
  710f30:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  710f35:	4c 89 ea             	mov    %r13,%rdx
  710f38:	ff 15 b2 6d 3d 00    	call   *0x3d6db2(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  710f3e:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
  710f45:	5b                   	pop    %rbx
  710f46:	41 5c                	pop    %r12
  710f48:	41 5d                	pop    %r13
  710f4a:	41 5e                	pop    %r14
  710f4c:	41 5f                	pop    %r15
  710f4e:	5d                   	pop    %rbp
  710f4f:	c3                   	ret
  710f50:	31 c0                	xor    %eax,%eax
  710f52:	31 d2                	xor    %edx,%edx
  710f54:	49 39 f1             	cmp    %rsi,%r9
  710f57:	0f 93 c0             	setae  %al
  710f5a:	0f 92 c2             	setb   %dl
  710f5d:	4c 89 ff             	mov    %r15,%rdi
  710f60:	49 0f 42 f9          	cmovb  %r9,%rdi
  710f64:	8b 3f                	mov    (%rdi),%edi
  710f66:	89 7c 8c 38          	mov    %edi,0x38(%rsp,%rcx,4)
  710f6a:	4d 8d 0c 91          	lea    (%r9,%rdx,4),%r9
  710f6e:	4d 8d 3c 87          	lea    (%r15,%rax,4),%r15
  710f72:	4d 39 c7             	cmp    %r8,%r15
  710f75:	0f 95 c0             	setne  %al
  710f78:	49 39 f1             	cmp    %rsi,%r9
  710f7b:	74 a6                	je     710f23 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x633>
  710f7d:	b0 01                	mov    $0x1,%al
  710f7f:	84 c0                	test   %al,%al
  710f81:	74 a4                	je     710f27 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x637>
  710f83:	ff 15 cf 71 3d 00    	call   *0x3d71cf(%rip)        # ae8158 <_DYNAMIC+0x6d8>
  710f89:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
