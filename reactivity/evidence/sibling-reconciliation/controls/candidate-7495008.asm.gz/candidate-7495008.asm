
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000725d60 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_>:
  725d60:	48 83 fe 02          	cmp    $0x2,%rsi
  725d64:	0f 82 4e 01 00 00    	jb     725eb8 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  725d6a:	49 89 d0             	mov    %rdx,%r8
  725d6d:	8b 07                	mov    (%rdi),%eax
  725d6f:	8b 4f 04             	mov    0x4(%rdi),%ecx
  725d72:	ba 02 00 00 00       	mov    $0x2,%edx
  725d77:	39 c1                	cmp    %eax,%ecx
  725d79:	73 2b                	jae    725da6 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x46>
  725d7b:	48 83 fe 02          	cmp    $0x2,%rsi
  725d7f:	74 2b                	je     725dac <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  725d81:	41 89 c9             	mov    %ecx,%r9d
  725d84:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  725d8b:	00 00 00 00 00 
  725d90:	45 89 ca             	mov    %r9d,%r10d
  725d93:	44 8b 0c 97          	mov    (%rdi,%rdx,4),%r9d
  725d97:	45 39 d1             	cmp    %r10d,%r9d
  725d9a:	73 10                	jae    725dac <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  725d9c:	48 ff c2             	inc    %rdx
  725d9f:	48 39 d6             	cmp    %rdx,%rsi
  725da2:	75 ec                	jne    725d90 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x30>
  725da4:	eb 3e                	jmp    725de4 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x84>
  725da6:	48 83 fe 02          	cmp    $0x2,%rsi
  725daa:	75 1f                	jne    725dcb <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x6b>
  725dac:	48 39 f2             	cmp    %rsi,%rdx
  725daf:	74 33                	je     725de4 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x84>
  725db1:	48 89 f0             	mov    %rsi,%rax
  725db4:	48 83 c8 01          	or     $0x1,%rax
  725db8:	48 0f bd c8          	bsr    %rax,%rcx
  725dbc:	83 f1 3f             	xor    $0x3f,%ecx
  725dbf:	01 c9                	add    %ecx,%ecx
  725dc1:	83 f1 7e             	xor    $0x7e,%ecx
  725dc4:	31 d2                	xor    %edx,%edx
  725dc6:	e9 b5 b4 ff ff       	jmp    721280 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>
  725dcb:	41 89 c9             	mov    %ecx,%r9d
  725dce:	66 90                	xchg   %ax,%ax
  725dd0:	45 89 ca             	mov    %r9d,%r10d
  725dd3:	44 8b 0c 97          	mov    (%rdi,%rdx,4),%r9d
  725dd7:	45 39 d1             	cmp    %r10d,%r9d
  725dda:	72 d0                	jb     725dac <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  725ddc:	48 ff c2             	inc    %rdx
  725ddf:	48 39 d6             	cmp    %rdx,%rsi
  725de2:	75 ec                	jne    725dd0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x70>
  725de4:	39 c1                	cmp    %eax,%ecx
  725de6:	0f 83 cc 00 00 00    	jae    725eb8 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  725dec:	48 89 f0             	mov    %rsi,%rax
  725def:	48 d1 e8             	shr    $1,%rax
  725df2:	48 83 fe 10          	cmp    $0x10,%rsi
  725df6:	73 07                	jae    725dff <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x9f>
  725df8:	31 c9                	xor    %ecx,%ecx
  725dfa:	e9 87 00 00 00       	jmp    725e86 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x126>
  725dff:	48 b9 f8 ff ff ff ff 	movabs $0xffffffffffffff8,%rcx
  725e06:	ff ff 0f 
  725e09:	48 21 c1             	and    %rax,%rcx
  725e0c:	48 89 c2             	mov    %rax,%rdx
  725e0f:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
  725e13:	48 f7 da             	neg    %rdx
  725e16:	4c 8d 47 10          	lea    0x10(%rdi),%r8
  725e1a:	4c 8d 0c b7          	lea    (%rdi,%rsi,4),%r9
  725e1e:	49 83 c1 f0          	add    $0xfffffffffffffff0,%r9
  725e22:	45 31 d2             	xor    %r10d,%r10d
  725e25:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  725e2c:	00 00 00 00 
  725e30:	f3 41 0f 6f 40 f0    	movdqu -0x10(%r8),%xmm0
  725e36:	f3 41 0f 6f 08       	movdqu (%r8),%xmm1
  725e3b:	f3 43 0f 6f 54 91 f0 	movdqu -0x10(%r9,%r10,4),%xmm2
  725e42:	f3 43 0f 6f 1c 91    	movdqu (%r9,%r10,4),%xmm3
  725e48:	66 0f 70 db 1b       	pshufd $0x1b,%xmm3,%xmm3
  725e4d:	66 0f 70 d2 1b       	pshufd $0x1b,%xmm2,%xmm2
  725e52:	f3 41 0f 7f 58 f0    	movdqu %xmm3,-0x10(%r8)
  725e58:	f3 41 0f 7f 10       	movdqu %xmm2,(%r8)
  725e5d:	66 0f 70 c0 1b       	pshufd $0x1b,%xmm0,%xmm0
  725e62:	66 0f 70 c9 1b       	pshufd $0x1b,%xmm1,%xmm1
  725e67:	f3 43 0f 7f 04 91    	movdqu %xmm0,(%r9,%r10,4)
  725e6d:	f3 43 0f 7f 4c 91 f0 	movdqu %xmm1,-0x10(%r9,%r10,4)
  725e74:	49 83 c2 f8          	add    $0xfffffffffffffff8,%r10
  725e78:	49 83 c0 20          	add    $0x20,%r8
  725e7c:	4c 39 d2             	cmp    %r10,%rdx
  725e7f:	75 af                	jne    725e30 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0xd0>
  725e81:	48 39 c8             	cmp    %rcx,%rax
  725e84:	74 32                	je     725eb8 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  725e86:	48 f7 d8             	neg    %rax
  725e89:	48 8d 14 8f          	lea    (%rdi,%rcx,4),%rdx
  725e8d:	48 f7 d9             	neg    %rcx
  725e90:	48 8d 34 b7          	lea    (%rdi,%rsi,4),%rsi
  725e94:	48 83 c6 fc          	add    $0xfffffffffffffffc,%rsi
  725e98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  725e9f:	00 
  725ea0:	8b 3a                	mov    (%rdx),%edi
  725ea2:	44 8b 04 8e          	mov    (%rsi,%rcx,4),%r8d
  725ea6:	44 89 02             	mov    %r8d,(%rdx)
  725ea9:	89 3c 8e             	mov    %edi,(%rsi,%rcx,4)
  725eac:	48 ff c9             	dec    %rcx
  725eaf:	48 83 c2 04          	add    $0x4,%rdx
  725eb3:	48 39 c8             	cmp    %rcx,%rax
  725eb6:	75 e8                	jne    725ea0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x140>
  725eb8:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
