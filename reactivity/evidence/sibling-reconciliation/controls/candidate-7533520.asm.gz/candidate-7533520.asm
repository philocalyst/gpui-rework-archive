
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072f3d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>:
  72f3d0:	55                   	push   %rbp
  72f3d1:	41 57                	push   %r15
  72f3d3:	41 56                	push   %r14
  72f3d5:	41 55                	push   %r13
  72f3d7:	41 54                	push   %r12
  72f3d9:	53                   	push   %rbx
  72f3da:	48 83 ec 58          	sub    $0x58,%rsp
  72f3de:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  72f3e3:	49 89 ce             	mov    %rcx,%r14
  72f3e6:	49 89 d7             	mov    %rdx,%r15
  72f3e9:	49 89 f5             	mov    %rsi,%r13
  72f3ec:	49 89 fc             	mov    %rdi,%r12
  72f3ef:	48 83 fe 21          	cmp    $0x21,%rsi
  72f3f3:	73 1e                	jae    72f413 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x43>
  72f3f5:	4c 89 e7             	mov    %r12,%rdi
  72f3f8:	4c 89 ee             	mov    %r13,%rsi
  72f3fb:	4c 89 fa             	mov    %r15,%rdx
  72f3fe:	4c 89 f1             	mov    %r14,%rcx
  72f401:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  72f408:	00 
  72f409:	e8 92 20 fe ff       	call   7114a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2c_11collections5btree3mapINtB2Y_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB3Y_8adapters3map3MapINtNtB8_4iter4IterNtB1w_9ListDraftENCNvMst_NtB1y_7runtimeINtB5Z_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6u_>
  72f40e:	e9 a9 05 00 00       	jmp    72f9bc <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5ec>
  72f413:	44 89 c3             	mov    %r8d,%ebx
  72f416:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  72f41b:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72f420:	85 db                	test   %ebx,%ebx
  72f422:	0f 84 73 05 00 00    	je     72f99b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5cb>
  72f428:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72f42d:	48 89 f1             	mov    %rsi,%rcx
  72f430:	48 c1 e9 03          	shr    $0x3,%rcx
  72f434:	48 89 c8             	mov    %rcx,%rax
  72f437:	48 c1 e0 06          	shl    $0x6,%rax
  72f43b:	4c 01 e0             	add    %r12,%rax
  72f43e:	48 6b d1 70          	imul   $0x70,%rcx,%rdx
  72f442:	4c 01 e2             	add    %r12,%rdx
  72f445:	48 83 fe 40          	cmp    $0x40,%rsi
  72f449:	73 35                	jae    72f480 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xb0>
  72f44b:	49 8b 0c 24          	mov    (%r12),%rcx
  72f44f:	48 8b 30             	mov    (%rax),%rsi
  72f452:	48 39 f1             	cmp    %rsi,%rcx
  72f455:	40 0f 92 c7          	setb   %dil
  72f459:	4c 8b 02             	mov    (%rdx),%r8
  72f45c:	4c 39 c1             	cmp    %r8,%rcx
  72f45f:	0f 92 c1             	setb   %cl
  72f462:	40 30 f9             	xor    %dil,%cl
  72f465:	4c 39 c6             	cmp    %r8,%rsi
  72f468:	40 0f 92 c6          	setb   %sil
  72f46c:	40 30 fe             	xor    %dil,%sil
  72f46f:	48 0f 45 c2          	cmovne %rdx,%rax
  72f473:	84 c9                	test   %cl,%cl
  72f475:	49 0f 45 c4          	cmovne %r12,%rax
  72f479:	eb 10                	jmp    72f48b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xbb>
  72f47b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72f480:	4c 89 e7             	mov    %r12,%rdi
  72f483:	48 89 c6             	mov    %rax,%rsi
  72f486:	e8 e5 f1 ff ff       	call   72e670 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72f48b:	ff cb                	dec    %ebx
  72f48d:	89 5c 24 2c          	mov    %ebx,0x2c(%rsp)
  72f491:	48 89 c5             	mov    %rax,%rbp
  72f494:	4c 29 e5             	sub    %r12,%rbp
  72f497:	48 89 e9             	mov    %rbp,%rcx
  72f49a:	48 c1 e9 04          	shr    $0x4,%rcx
  72f49e:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  72f4a3:	0f 10 00             	movups (%rax),%xmm0
  72f4a6:	48 8b 00             	mov    (%rax),%rax
  72f4a9:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  72f4ae:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  72f4b4:	74 0e                	je     72f4c4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xf4>
  72f4b6:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  72f4bb:	48 39 01             	cmp    %rax,(%rcx)
  72f4be:	0f 83 8c 02 00 00    	jae    72f750 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x380>
  72f4c4:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  72f4c9:	49 39 de             	cmp    %rbx,%r14
  72f4cc:	0f 82 0e 05 00 00    	jb     72f9e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x610>
  72f4d2:	49 89 de             	mov    %rbx,%r14
  72f4d5:	49 c1 e6 04          	shl    $0x4,%r14
  72f4d9:	4b 8d 0c 37          	lea    (%r15,%r14,1),%rcx
  72f4dd:	45 31 ed             	xor    %r13d,%r13d
  72f4e0:	4c 89 e0             	mov    %r12,%rax
  72f4e3:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72f4e8:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  72f4ed:	0f 1f 00             	nopl   (%rax)
  72f4f0:	48 89 d7             	mov    %rdx,%rdi
  72f4f3:	48 83 ef 03          	sub    $0x3,%rdi
  72f4f7:	be 00 00 00 00       	mov    $0x0,%esi
  72f4fc:	48 0f 43 f7          	cmovae %rdi,%rsi
  72f500:	48 c1 e6 04          	shl    $0x4,%rsi
  72f504:	4c 01 e6             	add    %r12,%rsi
  72f507:	48 39 f0             	cmp    %rsi,%rax
  72f50a:	0f 83 a4 00 00 00    	jae    72f5b4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x1e4>
  72f510:	48 8b 38             	mov    (%rax),%rdi
  72f513:	4c 8d 41 f0          	lea    -0x10(%rcx),%r8
  72f517:	45 31 c9             	xor    %r9d,%r9d
  72f51a:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72f51e:	4d 0f 42 c7          	cmovb  %r15,%r8
  72f522:	41 0f 92 c1          	setb   %r9b
  72f526:	4c 89 ef             	mov    %r13,%rdi
  72f529:	48 c1 e7 04          	shl    $0x4,%rdi
  72f52d:	4f 8d 14 29          	lea    (%r9,%r13,1),%r10
  72f531:	4c 8b 58 10          	mov    0x10(%rax),%r11
  72f535:	49 c1 e2 04          	shl    $0x4,%r10
  72f539:	4d 3b 1c 2c          	cmp    (%r12,%rbp,1),%r11
  72f53d:	0f 10 00             	movups (%rax),%xmm0
  72f540:	4c 8d 59 e0          	lea    -0x20(%rcx),%r11
  72f544:	4d 0f 42 df          	cmovb  %r15,%r11
  72f548:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72f54d:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72f551:	4d 11 cd             	adc    %r9,%r13
  72f554:	43 0f 11 04 13       	movups %xmm0,(%r11,%r10,1)
  72f559:	48 8b 78 20          	mov    0x20(%rax),%rdi
  72f55d:	4c 8d 41 d0          	lea    -0x30(%rcx),%r8
  72f561:	45 31 c9             	xor    %r9d,%r9d
  72f564:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72f568:	4d 0f 42 c7          	cmovb  %r15,%r8
  72f56c:	41 0f 92 c1          	setb   %r9b
  72f570:	4c 89 ef             	mov    %r13,%rdi
  72f573:	48 c1 e7 04          	shl    $0x4,%rdi
  72f577:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72f57b:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72f580:	4b 8d 3c 29          	lea    (%r9,%r13,1),%rdi
  72f584:	4c 8b 40 30          	mov    0x30(%rax),%r8
  72f588:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72f58c:	48 c1 e7 04          	shl    $0x4,%rdi
  72f590:	4d 3b 04 2c          	cmp    (%r12,%rbp,1),%r8
  72f594:	49 89 c8             	mov    %rcx,%r8
  72f597:	4d 0f 42 c7          	cmovb  %r15,%r8
  72f59b:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72f59f:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72f5a4:	4d 11 cd             	adc    %r9,%r13
  72f5a7:	48 83 c0 40          	add    $0x40,%rax
  72f5ab:	48 39 f0             	cmp    %rsi,%rax
  72f5ae:	0f 82 5c ff ff ff    	jb     72f510 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x140>
  72f5b4:	48 89 d6             	mov    %rdx,%rsi
  72f5b7:	48 c1 e6 04          	shl    $0x4,%rsi
  72f5bb:	4c 01 e6             	add    %r12,%rsi
  72f5be:	48 39 f0             	cmp    %rsi,%rax
  72f5c1:	73 3b                	jae    72f5fe <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x22e>
  72f5c3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f5ca:	84 00 00 00 00 00 
  72f5d0:	48 8b 38             	mov    (%rax),%rdi
  72f5d3:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72f5d7:	4d 89 e8             	mov    %r13,%r8
  72f5da:	49 c1 e0 04          	shl    $0x4,%r8
  72f5de:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72f5e2:	48 89 cf             	mov    %rcx,%rdi
  72f5e5:	49 0f 42 ff          	cmovb  %r15,%rdi
  72f5e9:	0f 10 00             	movups (%rax),%xmm0
  72f5ec:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72f5f1:	49 83 d5 00          	adc    $0x0,%r13
  72f5f5:	48 83 c0 10          	add    $0x10,%rax
  72f5f9:	48 39 f0             	cmp    %rsi,%rax
  72f5fc:	72 d2                	jb     72f5d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x200>
  72f5fe:	48 39 da             	cmp    %rbx,%rdx
  72f601:	74 2d                	je     72f630 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x260>
  72f603:	4c 89 ea             	mov    %r13,%rdx
  72f606:	48 c1 e2 04          	shl    $0x4,%rdx
  72f60a:	0f 10 00             	movups (%rax),%xmm0
  72f60d:	0f 11 44 11 f0       	movups %xmm0,-0x10(%rcx,%rdx,1)
  72f612:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72f616:	48 83 c0 10          	add    $0x10,%rax
  72f61a:	48 89 da             	mov    %rbx,%rdx
  72f61d:	e9 ce fe ff ff       	jmp    72f4f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x120>
  72f622:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f629:	1f 84 00 00 00 00 00 
  72f630:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  72f635:	4c 89 eb             	mov    %r13,%rbx
  72f638:	48 c1 e3 04          	shl    $0x4,%rbx
  72f63c:	4c 89 e7             	mov    %r12,%rdi
  72f63f:	4c 89 fe             	mov    %r15,%rsi
  72f642:	48 89 da             	mov    %rbx,%rdx
  72f645:	ff 15 a5 86 3b 00    	call   *0x3b86a5(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72f64b:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72f650:	4c 29 ee             	sub    %r13,%rsi
  72f653:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72f65a:	ff ff 0f 
  72f65d:	4b 8d 3c 37          	lea    (%r15,%r14,1),%rdi
  72f661:	0f 84 8e 00 00 00    	je     72f6f5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x325>
  72f667:	49 8d 45 01          	lea    0x1(%r13),%rax
  72f66b:	48 39 44 24 10       	cmp    %rax,0x10(%rsp)
  72f670:	75 0e                	jne    72f680 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x2b0>
  72f672:	31 c0                	xor    %eax,%eax
  72f674:	eb 65                	jmp    72f6db <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x30b>
  72f676:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72f67d:	00 00 00 
  72f680:	48 89 f1             	mov    %rsi,%rcx
  72f683:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72f687:	49 8d 44 24 10       	lea    0x10(%r12),%rax
  72f68c:	48 8d 14 18          	lea    (%rax,%rbx,1),%rdx
  72f690:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72f694:	49 01 c6             	add    %rax,%r14
  72f697:	31 c0                	xor    %eax,%eax
  72f699:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72f6a0:	48 89 c7             	mov    %rax,%rdi
  72f6a3:	41 0f 10 06          	movups (%r14),%xmm0
  72f6a7:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72f6ab:	48 83 c0 02          	add    $0x2,%rax
  72f6af:	4c 31 c7             	xor    %r8,%rdi
  72f6b2:	48 c1 e7 04          	shl    $0x4,%rdi
  72f6b6:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72f6bb:	41 0f 10 04 39       	movups (%r9,%rdi,1),%xmm0
  72f6c0:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  72f6c5:	0f 11 02             	movups %xmm0,(%rdx)
  72f6c8:	48 83 c2 20          	add    $0x20,%rdx
  72f6cc:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
  72f6d0:	48 39 c1             	cmp    %rax,%rcx
  72f6d3:	75 cb                	jne    72f6a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x2d0>
  72f6d5:	40 f6 c6 01          	test   $0x1,%sil
  72f6d9:	74 1a                	je     72f6f5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x325>
  72f6db:	49 8d 0c 1c          	lea    (%r12,%rbx,1),%rcx
  72f6df:	48 89 c2             	mov    %rax,%rdx
  72f6e2:	48 f7 d2             	not    %rdx
  72f6e5:	48 c1 e2 04          	shl    $0x4,%rdx
  72f6e9:	48 c1 e0 04          	shl    $0x4,%rax
  72f6ed:	0f 10 04 17          	movups (%rdi,%rdx,1),%xmm0
  72f6f1:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  72f6f5:	4d 85 ed             	test   %r13,%r13
  72f6f8:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72f6fd:	74 51                	je     72f750 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x380>
  72f6ff:	4c 39 6c 24 10       	cmp    %r13,0x10(%rsp)
  72f704:	0f 82 d8 02 00 00    	jb     72f9e2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x612>
  72f70a:	4c 01 e3             	add    %r12,%rbx
  72f70d:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  72f714:	00 
  72f715:	48 89 04 24          	mov    %rax,(%rsp)
  72f719:	48 89 df             	mov    %rbx,%rdi
  72f71c:	4c 89 fa             	mov    %r15,%rdx
  72f71f:	4c 89 f1             	mov    %r14,%rcx
  72f722:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72f726:	41 89 d8             	mov    %ebx,%r8d
  72f729:	4c 8d 4c 24 40       	lea    0x40(%rsp),%r9
  72f72e:	e8 9d fc ff ff       	call   72f3d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72f733:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72f738:	49 83 fd 21          	cmp    $0x21,%r13
  72f73c:	0f 83 de fc ff ff    	jae    72f420 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x50>
  72f742:	e9 ae fc ff ff       	jmp    72f3f5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x25>
  72f747:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72f74e:	00 00 
  72f750:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72f755:	49 39 c6             	cmp    %rax,%r14
  72f758:	0f 82 82 02 00 00    	jb     72f9e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x610>
  72f75e:	48 c1 e0 04          	shl    $0x4,%rax
  72f762:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72f767:	49 8d 0c 07          	lea    (%r15,%rax,1),%rcx
  72f76b:	31 db                	xor    %ebx,%ebx
  72f76d:	4c 89 e0             	mov    %r12,%rax
  72f770:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72f775:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
  72f77a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  72f780:	4c 89 d6             	mov    %r10,%rsi
  72f783:	48 83 ee 03          	sub    $0x3,%rsi
  72f787:	ba 00 00 00 00       	mov    $0x0,%edx
  72f78c:	48 0f 43 d6          	cmovae %rsi,%rdx
  72f790:	48 c1 e2 04          	shl    $0x4,%rdx
  72f794:	4c 01 e2             	add    %r12,%rdx
  72f797:	48 39 d0             	cmp    %rdx,%rax
  72f79a:	0f 83 9d 00 00 00    	jae    72f83d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x46d>
  72f7a0:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72f7a4:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
  72f7a8:	49 89 d8             	mov    %rbx,%r8
  72f7ab:	49 c1 e0 04          	shl    $0x4,%r8
  72f7af:	48 3b 30             	cmp    (%rax),%rsi
  72f7b2:	49 0f 43 ff          	cmovae %r15,%rdi
  72f7b6:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f7ba:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72f7be:	49 89 d9             	mov    %rbx,%r9
  72f7c1:	49 c1 e1 04          	shl    $0x4,%r9
  72f7c5:	48 3b 70 10          	cmp    0x10(%rax),%rsi
  72f7c9:	0f 10 00             	movups (%rax),%xmm0
  72f7cc:	48 8d 71 e0          	lea    -0x20(%rcx),%rsi
  72f7d0:	49 0f 43 f7          	cmovae %r15,%rsi
  72f7d4:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72f7d9:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f7dd:	49 8b 3c 2c          	mov    (%r12,%rbp,1),%rdi
  72f7e1:	49 89 d8             	mov    %rbx,%r8
  72f7e4:	49 c1 e0 04          	shl    $0x4,%r8
  72f7e8:	48 3b 78 20          	cmp    0x20(%rax),%rdi
  72f7ec:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72f7f0:	48 8d 79 d0          	lea    -0x30(%rcx),%rdi
  72f7f4:	49 0f 43 ff          	cmovae %r15,%rdi
  72f7f8:	42 0f 11 04 0e       	movups %xmm0,(%rsi,%r9,1)
  72f7fd:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72f801:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f805:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72f80a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72f80e:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72f812:	48 89 df             	mov    %rbx,%rdi
  72f815:	48 c1 e7 04          	shl    $0x4,%rdi
  72f819:	48 3b 70 30          	cmp    0x30(%rax),%rsi
  72f81d:	48 89 ce             	mov    %rcx,%rsi
  72f820:	49 0f 43 f7          	cmovae %r15,%rsi
  72f824:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72f828:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72f82c:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f830:	48 83 c0 40          	add    $0x40,%rax
  72f834:	48 39 d0             	cmp    %rdx,%rax
  72f837:	0f 82 63 ff ff ff    	jb     72f7a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x3d0>
  72f83d:	4c 89 d2             	mov    %r10,%rdx
  72f840:	48 c1 e2 04          	shl    $0x4,%rdx
  72f844:	4c 01 e2             	add    %r12,%rdx
  72f847:	48 39 d0             	cmp    %rdx,%rax
  72f84a:	73 31                	jae    72f87d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4ad>
  72f84c:	0f 1f 40 00          	nopl   0x0(%rax)
  72f850:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72f854:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72f858:	48 89 df             	mov    %rbx,%rdi
  72f85b:	48 c1 e7 04          	shl    $0x4,%rdi
  72f85f:	48 3b 30             	cmp    (%rax),%rsi
  72f862:	48 89 ce             	mov    %rcx,%rsi
  72f865:	49 0f 43 f7          	cmovae %r15,%rsi
  72f869:	0f 10 00             	movups (%rax),%xmm0
  72f86c:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72f870:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f874:	48 83 c0 10          	add    $0x10,%rax
  72f878:	48 39 d0             	cmp    %rdx,%rax
  72f87b:	72 d3                	jb     72f850 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x480>
  72f87d:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  72f882:	4d 39 f2             	cmp    %r14,%r10
  72f885:	74 29                	je     72f8b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4e0>
  72f887:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72f88b:	48 89 da             	mov    %rbx,%rdx
  72f88e:	48 c1 e2 04          	shl    $0x4,%rdx
  72f892:	0f 10 00             	movups (%rax),%xmm0
  72f895:	41 0f 11 04 17       	movups %xmm0,(%r15,%rdx,1)
  72f89a:	48 ff c3             	inc    %rbx
  72f89d:	48 83 c0 10          	add    $0x10,%rax
  72f8a1:	4d 89 f2             	mov    %r14,%r10
  72f8a4:	e9 d7 fe ff ff       	jmp    72f780 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x3b0>
  72f8a9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72f8b0:	48 89 dd             	mov    %rbx,%rbp
  72f8b3:	48 c1 e5 04          	shl    $0x4,%rbp
  72f8b7:	4c 89 e7             	mov    %r12,%rdi
  72f8ba:	4c 89 fe             	mov    %r15,%rsi
  72f8bd:	48 89 ea             	mov    %rbp,%rdx
  72f8c0:	ff 15 2a 84 3b 00    	call   *0x3b842a(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72f8c6:	4d 89 f5             	mov    %r14,%r13
  72f8c9:	49 29 dd             	sub    %rbx,%r13
  72f8cc:	0f 84 f9 00 00 00    	je     72f9cb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5fb>
  72f8d2:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
  72f8d6:	48 8d 43 01          	lea    0x1(%rbx),%rax
  72f8da:	49 39 c6             	cmp    %rax,%r14
  72f8dd:	75 09                	jne    72f8e8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x518>
  72f8df:	31 c0                	xor    %eax,%eax
  72f8e1:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72f8e6:	eb 69                	jmp    72f951 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x581>
  72f8e8:	4c 89 e9             	mov    %r13,%rcx
  72f8eb:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72f8ef:	49 8d 14 2c          	lea    (%r12,%rbp,1),%rdx
  72f8f3:	48 83 c2 10          	add    $0x10,%rdx
  72f8f7:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72f8fb:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  72f900:	49 01 c2             	add    %rax,%r10
  72f903:	31 c0                	xor    %eax,%eax
  72f905:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72f90c:	ff ff 0f 
  72f90f:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72f914:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f91b:	00 00 00 00 00 
  72f920:	48 89 c6             	mov    %rax,%rsi
  72f923:	41 0f 10 02          	movups (%r10),%xmm0
  72f927:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72f92b:	48 83 c0 02          	add    $0x2,%rax
  72f92f:	4c 31 c6             	xor    %r8,%rsi
  72f932:	48 c1 e6 04          	shl    $0x4,%rsi
  72f936:	41 0f 10 04 31       	movups (%r9,%rsi,1),%xmm0
  72f93b:	0f 11 02             	movups %xmm0,(%rdx)
  72f93e:	48 83 c2 20          	add    $0x20,%rdx
  72f942:	49 83 c2 e0          	add    $0xffffffffffffffe0,%r10
  72f946:	48 39 c1             	cmp    %rax,%rcx
  72f949:	75 d5                	jne    72f920 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x550>
  72f94b:	41 f6 c5 01          	test   $0x1,%r13b
  72f94f:	74 17                	je     72f968 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x598>
  72f951:	48 89 c1             	mov    %rax,%rcx
  72f954:	48 f7 d1             	not    %rcx
  72f957:	48 c1 e1 04          	shl    $0x4,%rcx
  72f95b:	48 c1 e0 04          	shl    $0x4,%rax
  72f95f:	41 0f 10 04 09       	movups (%r9,%rcx,1),%xmm0
  72f964:	0f 11 04 07          	movups %xmm0,(%rdi,%rax,1)
  72f968:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72f96d:	48 39 da             	cmp    %rbx,%rdx
  72f970:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72f975:	0f 82 80 00 00 00    	jb     72f9fb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x62b>
  72f97b:	49 89 fc             	mov    %rdi,%r12
  72f97e:	b8 00 00 00 00       	mov    $0x0,%eax
  72f983:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72f988:	49 83 fd 21          	cmp    $0x21,%r13
  72f98c:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72f990:	0f 83 85 fa ff ff    	jae    72f41b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4b>
  72f996:	e9 5d fa ff ff       	jmp    72f3f8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x28>
  72f99b:	4c 89 e7             	mov    %r12,%rdi
  72f99e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72f9a3:	4c 89 fa             	mov    %r15,%rdx
  72f9a6:	4c 89 f1             	mov    %r14,%rcx
  72f9a9:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72f9af:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  72f9b6:	00 
  72f9b7:	e8 14 d6 ff ff       	call   72cfd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>
  72f9bc:	48 83 c4 58          	add    $0x58,%rsp
  72f9c0:	5b                   	pop    %rbx
  72f9c1:	41 5c                	pop    %r12
  72f9c3:	41 5d                	pop    %r13
  72f9c5:	41 5e                	pop    %r14
  72f9c7:	41 5f                	pop    %r15
  72f9c9:	5d                   	pop    %rbp
  72f9ca:	c3                   	ret
  72f9cb:	4c 03 64 24 18       	add    0x18(%rsp),%r12
  72f9d0:	45 31 ed             	xor    %r13d,%r13d
  72f9d3:	4c 89 e7             	mov    %r12,%rdi
  72f9d6:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72f9db:	e9 18 fa ff ff       	jmp    72f3f8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x28>
  72f9e0:	0f 0b                	ud2
  72f9e2:	48 8d 3d 3b 9c 93 ff 	lea    -0x6c63c5(%rip),%rdi        # 69624 <anon.82a788e7fdd98d311675b83eb91f04ac.0.llvm.15086054616281437909+0x27>
  72f9e9:	48 8d 15 f8 b8 38 00 	lea    0x38b8f8(%rip),%rdx        # abb2e8 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x38>
  72f9f0:	be 13 00 00 00       	mov    $0x13,%esi
  72f9f5:	ff 15 25 83 3b 00    	call   *0x3b8325(%rip)        # ae7d20 <_DYNAMIC+0x2a0>
  72f9fb:	48 8d 0d fe b8 38 00 	lea    0x38b8fe(%rip),%rcx        # abb300 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x50>
  72fa02:	48 89 df             	mov    %rbx,%rdi
  72fa05:	48 89 d6             	mov    %rdx,%rsi
  72fa08:	ff 15 02 83 3b 00    	call   *0x3b8302(%rip)        # ae7d10 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
