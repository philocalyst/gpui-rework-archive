
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072df30 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_>:
  72df30:	55                   	push   %rbp
  72df31:	41 57                	push   %r15
  72df33:	41 56                	push   %r14
  72df35:	41 55                	push   %r13
  72df37:	41 54                	push   %r12
  72df39:	53                   	push   %rbx
  72df3a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  72df41:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  72df48:	00 
  72df49:	50                   	push   %rax
  72df4a:	48 89 d3             	mov    %rdx,%rbx
  72df4d:	48 89 f1             	mov    %rsi,%rcx
  72df50:	48 d1 e9             	shr    $1,%rcx
  72df53:	48 89 f0             	mov    %rsi,%rax
  72df56:	48 29 c8             	sub    %rcx,%rax
  72df59:	48 81 fe 15 16 05 00 	cmp    $0x51615,%rsi
  72df60:	41 bd 15 16 05 00    	mov    $0x51615,%r13d
  72df66:	4c 0f 42 ee          	cmovb  %rsi,%r13
  72df6a:	49 39 c5             	cmp    %rax,%r13
  72df6d:	4c 0f 46 e8          	cmovbe %rax,%r13
  72df71:	49 81 fd ab 00 00 00 	cmp    $0xab,%r13
  72df78:	73 0c                	jae    72df86 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x56>
  72df7a:	4c 8d 74 24 08       	lea    0x8(%rsp),%r14
  72df7f:	b9 aa 00 00 00       	mov    $0xaa,%ecx
  72df84:	eb 5b                	jmp    72dfe1 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0xb1>
  72df86:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
  72df8d:	00 
  72df8e:	4c 8d 3c 49          	lea    (%rcx,%rcx,2),%r15
  72df92:	48 b9 55 55 55 55 55 	movabs $0x555555555555555,%rcx
  72df99:	55 55 05 
  72df9c:	48 39 c8             	cmp    %rcx,%rax
  72df9f:	76 0f                	jbe    72dfb0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x80>
  72dfa1:	45 31 e4             	xor    %r12d,%r12d
  72dfa4:	4c 89 e7             	mov    %r12,%rdi
  72dfa7:	4c 89 fe             	mov    %r15,%rsi
  72dfaa:	ff 15 f8 9d 3b 00    	call   *0x3b9df8(%rip)        # ae7da8 <_DYNAMIC+0x328>
  72dfb0:	49 89 f6             	mov    %rsi,%r14
  72dfb3:	48 89 fd             	mov    %rdi,%rbp
  72dfb6:	ff 15 24 9d 3b 00    	call   *0x3b9d24(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  72dfbc:	41 bc 08 00 00 00    	mov    $0x8,%r12d
  72dfc2:	be 08 00 00 00       	mov    $0x8,%esi
  72dfc7:	4c 89 ff             	mov    %r15,%rdi
  72dfca:	ff 15 f0 9c 3b 00    	call   *0x3b9cf0(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  72dfd0:	48 89 ef             	mov    %rbp,%rdi
  72dfd3:	4c 89 f6             	mov    %r14,%rsi
  72dfd6:	49 89 c6             	mov    %rax,%r14
  72dfd9:	4c 89 e9             	mov    %r13,%rcx
  72dfdc:	48 85 c0             	test   %rax,%rax
  72dfdf:	74 c3                	je     72dfa4 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x74>
  72dfe1:	45 31 c0             	xor    %r8d,%r8d
  72dfe4:	48 83 fe 41          	cmp    $0x41,%rsi
  72dfe8:	41 0f 92 c0          	setb   %r8b
  72dfec:	4c 89 f2             	mov    %r14,%rdx
  72dfef:	49 89 d9             	mov    %rbx,%r9
  72dff2:	e8 99 e9 ff ff       	call   72c990 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>
  72dff7:	49 81 fd aa 00 00 00 	cmp    $0xaa,%r13
  72dffe:	76 1d                	jbe    72e01d <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0xed>
  72e000:	49 c1 e5 03          	shl    $0x3,%r13
  72e004:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
  72e00b:	00 
  72e00c:	4c 01 ee             	add    %r13,%rsi
  72e00f:	ba 08 00 00 00       	mov    $0x8,%edx
  72e014:	4c 89 f7             	mov    %r14,%rdi
  72e017:	ff 15 ab 9c 3b 00    	call   *0x3b9cab(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  72e01d:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  72e024:	5b                   	pop    %rbx
  72e025:	41 5c                	pop    %r12
  72e027:	41 5d                	pop    %r13
  72e029:	41 5e                	pop    %r14
  72e02b:	41 5f                	pop    %r15
  72e02d:	5d                   	pop    %rbp
  72e02e:	c3                   	ret
  72e02f:	48 89 c3             	mov    %rax,%rbx
  72e032:	49 81 fd ab 00 00 00 	cmp    $0xab,%r13
  72e039:	73 08                	jae    72e043 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x113>
  72e03b:	48 89 df             	mov    %rbx,%rdi
  72e03e:	e8 0d a4 38 00       	call   ab8450 <_Unwind_Resume@plt>
  72e043:	49 c1 e5 03          	shl    $0x3,%r13
  72e047:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
  72e04e:	00 
  72e04f:	4c 01 ee             	add    %r13,%rsi
  72e052:	ba 08 00 00 00       	mov    $0x8,%edx
  72e057:	4c 89 f7             	mov    %r14,%rdi
  72e05a:	ff 15 68 9c 3b 00    	call   *0x3b9c68(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  72e060:	48 89 df             	mov    %rbx,%rdi
  72e063:	e8 e8 a3 38 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
