
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000007144e0 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_>:
  7144e0:	41 57                	push   %r15
  7144e2:	41 56                	push   %r14
  7144e4:	41 54                	push   %r12
  7144e6:	53                   	push   %rbx
  7144e7:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  7144ee:	48 89 fb             	mov    %rdi,%rbx
  7144f1:	0f 10 06             	movups (%rsi),%xmm0
  7144f4:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  7144f8:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  7144fc:	0f 10 5e 30          	movups 0x30(%rsi),%xmm3
  714500:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
  714505:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  71450a:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  71450f:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  714514:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  714519:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  71451e:	e8 ad 65 00 00       	call   71aad0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_>
  714523:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  714528:	4d 85 ff             	test   %r15,%r15
  71452b:	0f 84 b4 00 00 00    	je     7145e5 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x105>
  714531:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  714536:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  71453b:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  714540:	49 83 ff 01          	cmp    $0x1,%r15
  714544:	0f 85 de 00 00 00    	jne    714628 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x148>
  71454a:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  71454f:	ff 15 83 63 3d 00    	call   *0x3d6383(%rip)        # aea8d8 <_DYNAMIC+0x260>
  714555:	bf 18 01 00 00       	mov    $0x118,%edi
  71455a:	be 08 00 00 00       	mov    $0x8,%esi
  71455f:	ff 15 53 63 3d 00    	call   *0x3d6353(%rip)        # aea8b8 <_DYNAMIC+0x240>
  714565:	48 85 c0             	test   %rax,%rax
  714568:	0f 84 da 00 00 00    	je     714648 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x168>
  71456e:	48 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%rax)
  714575:	00 00 00 00 
  714579:	66 c7 80 12 01 00 00 	movw   $0x0,0x112(%rax)
  714580:	00 00 
  714582:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  714589:	00 00 
  71458b:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  714590:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  714597:	00 00 
  714599:	4b 8d 04 7f          	lea    (%r15,%r15,2),%rax
  71459d:	49 8d 04 c6          	lea    (%r14,%rax,8),%rax
  7145a1:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  7145a8:	00 00 
  7145aa:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  7145af:	4c 89 74 24 68       	mov    %r14,0x68(%rsp)
  7145b4:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  7145b9:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  7145be:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  7145c3:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  7145c8:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  7145cd:	e8 6e 6d fd ff       	call   6eb340 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBV_6marker5OwnedjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1B_8RowDraftENtB1f_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterjB1y_INtNtNtB9_3vec9into_iter8IntoIterTjB1y_EEENtNtB9_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  7145d2:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
  7145d7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  7145dc:	0f 11 03             	movups %xmm0,(%rbx)
  7145df:	48 89 43 10          	mov    %rax,0x10(%rbx)
  7145e3:	eb 31                	jmp    714616 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x136>
  7145e5:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  7145ec:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  7145f3:	00 
  7145f4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  7145f9:	48 85 c0             	test   %rax,%rax
  7145fc:	74 18                	je     714616 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x136>
  7145fe:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  714603:	48 c1 e0 03          	shl    $0x3,%rax
  714607:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  71460b:	ba 08 00 00 00       	mov    $0x8,%edx
  714610:	ff 15 aa 62 3d 00    	call   *0x3d62aa(%rip)        # aea8c0 <_DYNAMIC+0x248>
  714616:	48 89 d8             	mov    %rbx,%rax
  714619:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  714620:	5b                   	pop    %rbx
  714621:	41 5c                	pop    %r12
  714623:	41 5e                	pop    %r14
  714625:	41 5f                	pop    %r15
  714627:	c3                   	ret
  714628:	49 83 ff 15          	cmp    $0x15,%r15
  71462c:	73 2c                	jae    71465a <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x17a>
  71462e:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
  714633:	ba 01 00 00 00       	mov    $0x1,%edx
  714638:	4c 89 f7             	mov    %r14,%rdi
  71463b:	4c 89 fe             	mov    %r15,%rsi
  71463e:	e8 0d ed ff ff       	call   713350 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1r_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB2o_11collections5btree3mapINtB3a_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB4a_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1r_9ListDraftEINtNtB57_3map3MapIB5D_B1Z_ENCNCNvMst_NtB1t_7runtimeINtB6M_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6G_s2_0EE0E0EB7h_>
  714643:	e9 02 ff ff ff       	jmp    71454a <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x6a>
  714648:	bf 08 00 00 00       	mov    $0x8,%edi
  71464d:	be 18 01 00 00       	mov    $0x118,%esi
  714652:	ff 15 98 62 3d 00    	call   *0x3d6298(%rip)        # aea8f0 <_DYNAMIC+0x278>
  714658:	0f 0b                	ud2
  71465a:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
  71465f:	4c 89 f7             	mov    %r14,%rdi
  714662:	4c 89 fe             	mov    %r15,%rsi
  714665:	e8 56 50 01 00       	call   7296c0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_>
  71466a:	e9 db fe ff ff       	jmp    71454a <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x6a>
  71466f:	48 89 c3             	mov    %rax,%rbx
  714672:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  714677:	eb 03                	jmp    71467c <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x19c>
  714679:	48 89 c3             	mov    %rax,%rbx
  71467c:	4d 85 e4             	test   %r12,%r12
  71467f:	74 16                	je     714697 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1c_8RowDraftEEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB28_8adapters7flatten7FlatMapINtNtNtB2a_5slice4iter4IterNtB1c_9ListDraftEINtNtB3o_3map3MapIB3U_B1K_ENCNCNvMst_NtB1e_7runtimeINtB5c_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB56_s2_0EEB5H_+0x1b7>
  714681:	49 c1 e4 03          	shl    $0x3,%r12
  714685:	4b 8d 34 64          	lea    (%r12,%r12,2),%rsi
  714689:	ba 08 00 00 00       	mov    $0x8,%edx
  71468e:	4c 89 f7             	mov    %r14,%rdi
  714691:	ff 15 29 62 3d 00    	call   *0x3d6229(%rip)        # aea8c0 <_DYNAMIC+0x248>
  714697:	48 89 df             	mov    %rbx,%rdi
  71469a:	e8 01 6a 3a 00       	call   abb0a0 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
