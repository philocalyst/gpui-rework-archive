
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
