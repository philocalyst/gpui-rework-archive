
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000072b1a0 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_>:
  72b1a0:	55                   	push   %rbp
  72b1a1:	41 57                	push   %r15
  72b1a3:	41 56                	push   %r14
  72b1a5:	41 55                	push   %r13
  72b1a7:	41 54                	push   %r12
  72b1a9:	53                   	push   %rbx
  72b1aa:	48 81 ec e8 00 00 00 	sub    $0xe8,%rsp
  72b1b1:	0f 10 07             	movups (%rdi),%xmm0
  72b1b4:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  72b1b8:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  72b1bd:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  72b1c2:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  72b1c7:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  72b1cc:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  72b1d1:	48 39 c1             	cmp    %rax,%rcx
  72b1d4:	0f 84 b2 00 00 00    	je     72b28c <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_+0xec>
  72b1da:	48 8b 4e 18          	mov    0x18(%rsi),%rcx
  72b1de:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72b1e3:	4c 8b 7e 08          	mov    0x8(%rsi),%r15
  72b1e7:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  72b1ec:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  72b1f0:	49 69 d7 e0 00 00 00 	imul   $0xe0,%r15,%rdx
  72b1f7:	48 8d 2c 0a          	lea    (%rdx,%rcx,1),%rbp
  72b1fb:	48 81 c5 b8 00 00 00 	add    $0xb8,%rbp
  72b202:	48 05 50 ff ff ff    	add    $0xffffffffffffff50,%rax
  72b208:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72b20f:	00 
  72b210:	49 89 c5             	mov    %rax,%r13
  72b213:	4c 8b 20             	mov    (%rax),%r12
  72b216:	49 83 fc ff          	cmp    $0xffffffffffffffff,%r12
  72b21a:	74 64                	je     72b280 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_+0xe0>
  72b21c:	49 8d 75 08          	lea    0x8(%r13),%rsi
  72b220:	ba a8 00 00 00       	mov    $0xa8,%edx
  72b225:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  72b22a:	48 8b 1d b7 f6 3b 00 	mov    0x3bf6b7(%rip),%rbx        # aea8e8 <memcpy@GLIBC_2.14>
  72b231:	ff d3                	call   *%rbx
  72b233:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72b238:	44 8b 30             	mov    (%rax),%r14d
  72b23b:	4c 89 a5 48 ff ff ff 	mov    %r12,-0xb8(%rbp)
  72b242:	48 8d bd 50 ff ff ff 	lea    -0xb0(%rbp),%rdi
  72b249:	ba a8 00 00 00       	mov    $0xa8,%edx
  72b24e:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  72b253:	ff d3                	call   *%rbx
  72b255:	c7 45 f8 01 00 00 00 	movl   $0x1,-0x8(%rbp)
  72b25c:	44 89 75 fc          	mov    %r14d,-0x4(%rbp)
  72b260:	48 c7 45 00 00 00 00 	movq   $0x0,0x0(%rbp)
  72b267:	00 
  72b268:	49 ff c7             	inc    %r15
  72b26b:	48 81 c5 e0 00 00 00 	add    $0xe0,%rbp
  72b272:	49 8d 85 50 ff ff ff 	lea    -0xb0(%r13),%rax
  72b279:	4c 3b 6c 24 18       	cmp    0x18(%rsp),%r13
  72b27e:	75 90                	jne    72b210 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_+0x70>
  72b280:	4c 89 6c 24 38       	mov    %r13,0x38(%rsp)
  72b285:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  72b28a:	eb 04                	jmp    72b290 <_RINvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3revINtB5_3RevINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElEENtNtNtB9_6traits8iterator8Iterator4folduNCINvNtB7_3map8map_foldB1J_TINtNtBb_6option6OptionmEB1J_IB3q_TjNtNtB1N_4list7ItemKeymffEEEuNCINvMs5_B1L_B1J_13flatten_listsNCNvMst_NtB1N_7runtimeINtB54_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners_0Es0_0NCINvNvB2j_8for_each4callB3o_NCINvMsj_B11_INtB11_3VecB3o_E14extend_trustedINtB32_3MapBM_B4q_EE0E0E0EB5z_+0xf0>
  72b28c:	4c 8b 7e 08          	mov    0x8(%rsi),%r15
  72b290:	48 8b 06             	mov    (%rsi),%rax
  72b293:	4c 89 38             	mov    %r15,(%rax)
  72b296:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  72b29b:	e8 90 1f ff ff       	call   71d230 <_RNvXse_NtNtCscdodAO9FK5_5alloc3vec9into_iterINtB5_8IntoIterNtNtCshBhuxcId5D0_4gpui7element2ElENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  72b2a0:	48 81 c4 e8 00 00 00 	add    $0xe8,%rsp
  72b2a7:	5b                   	pop    %rbx
  72b2a8:	41 5c                	pop    %r12
  72b2aa:	41 5d                	pop    %r13
  72b2ac:	41 5e                	pop    %r14
  72b2ae:	41 5f                	pop    %r15
  72b2b0:	5d                   	pop    %rbp
  72b2b1:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
