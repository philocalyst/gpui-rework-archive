
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072c310 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>:
  72c310:	55                   	push   %rbp
  72c311:	41 57                	push   %r15
  72c313:	41 56                	push   %r14
  72c315:	41 55                	push   %r13
  72c317:	41 54                	push   %r12
  72c319:	53                   	push   %rbx
  72c31a:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
  72c321:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  72c326:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  72c32b:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  72c330:	48 83 fe 02          	cmp    $0x2,%rsi
  72c334:	0f 82 44 06 00 00    	jb     72c97e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x66e>
  72c33a:	49 89 cd             	mov    %rcx,%r13
  72c33d:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  72c344:	00 00 40 
  72c347:	48 89 d1             	mov    %rdx,%rcx
  72c34a:	31 d2                	xor    %edx,%edx
  72c34c:	48 f7 f6             	div    %rsi
  72c34f:	48 83 fa 01          	cmp    $0x1,%rdx
  72c353:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72c357:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  72c35c:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  72c363:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  72c368:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  72c36d:	73 1e                	jae    72c38d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x7d>
  72c36f:	48 89 ca             	mov    %rcx,%rdx
  72c372:	48 89 f0             	mov    %rsi,%rax
  72c375:	48 d1 e8             	shr    $1,%rax
  72c378:	48 89 f1             	mov    %rsi,%rcx
  72c37b:	48 29 c1             	sub    %rax,%rcx
  72c37e:	48 83 f9 40          	cmp    $0x40,%rcx
  72c382:	b8 40 00 00 00       	mov    $0x40,%eax
  72c387:	48 0f 42 c1          	cmovb  %rcx,%rax
  72c38b:	eb 0e                	jmp    72c39b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x8b>
  72c38d:	48 89 f7             	mov    %rsi,%rdi
  72c390:	ff 15 12 bf 3b 00    	call   *0x3bbf12(%rip)        # ae82a8 <_DYNAMIC+0x828>
  72c396:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c39b:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72c3a0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72c3a5:	48 8d 48 20          	lea    0x20(%rax),%rcx
  72c3a9:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  72c3ae:	48 8d 48 10          	lea    0x10(%rax),%rcx
  72c3b2:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  72c3b7:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  72c3bb:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  72c3c0:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  72c3c6:	31 ed                	xor    %ebp,%ebp
  72c3c8:	45 31 c9             	xor    %r9d,%r9d
  72c3cb:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  72c3d2:	00 
  72c3d3:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72c3d8:	48 29 ee             	sub    %rbp,%rsi
  72c3db:	77 23                	ja     72c400 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xf0>
  72c3dd:	0f 1f 00             	nopl   (%rax)
  72c3e0:	31 ff                	xor    %edi,%edi
  72c3e2:	be 01 00 00 00       	mov    $0x1,%esi
  72c3e7:	49 83 f9 02          	cmp    $0x2,%r9
  72c3eb:	0f 83 df 00 00 00    	jae    72c4d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1c0>
  72c3f1:	e9 80 03 00 00       	jmp    72c776 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  72c3f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72c3fd:	00 00 00 
  72c400:	48 89 e9             	mov    %rbp,%rcx
  72c403:	48 c1 e1 04          	shl    $0x4,%rcx
  72c407:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72c40c:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
  72c410:	48 3b 74 24 18       	cmp    0x18(%rsp),%rsi
  72c415:	73 49                	jae    72c460 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x150>
  72c417:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  72c41c:	74 62                	je     72c480 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x170>
  72c41e:	48 83 fe 20          	cmp    $0x20,%rsi
  72c422:	b8 20 00 00 00       	mov    $0x20,%eax
  72c427:	48 0f 43 f0          	cmovae %rax,%rsi
  72c42b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72c430:	48 89 04 24          	mov    %rax,(%rsp)
  72c434:	4c 89 e9             	mov    %r13,%rcx
  72c437:	45 31 c0             	xor    %r8d,%r8d
  72c43a:	4c 89 cb             	mov    %r9,%rbx
  72c43d:	45 31 c9             	xor    %r9d,%r9d
  72c440:	49 89 f6             	mov    %rsi,%r14
  72c443:	e8 48 24 00 00       	call   72e890 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72c448:	49 89 d9             	mov    %rbx,%r9
  72c44b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c450:	44 89 f0             	mov    %r14d,%eax
  72c453:	eb 18                	jmp    72c46d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72c45c:	00 00 00 00 
  72c460:	48 83 fe 02          	cmp    $0x2,%rsi
  72c464:	0f 83 56 03 00 00    	jae    72c7c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x4b0>
  72c46a:	48 89 f0             	mov    %rsi,%rax
  72c46d:	48 8d 34 45 01 00 00 	lea    0x1(,%rax,2),%rsi
  72c474:	00 
  72c475:	eb 18                	jmp    72c48f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x17f>
  72c477:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72c47e:	00 00 
  72c480:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72c485:	48 39 c6             	cmp    %rax,%rsi
  72c488:	48 0f 43 f0          	cmovae %rax,%rsi
  72c48c:	48 01 f6             	add    %rsi,%rsi
  72c48f:	4c 89 e0             	mov    %r12,%rax
  72c492:	48 d1 e8             	shr    $1,%rax
  72c495:	48 89 f1             	mov    %rsi,%rcx
  72c498:	48 d1 e9             	shr    $1,%rcx
  72c49b:	48 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%rdi
  72c4a2:	00 
  72c4a3:	48 29 c7             	sub    %rax,%rdi
  72c4a6:	48 8d 04 69          	lea    (%rcx,%rbp,2),%rax
  72c4aa:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  72c4af:	48 0f af f9          	imul   %rcx,%rdi
  72c4b3:	48 0f af c1          	imul   %rcx,%rax
  72c4b7:	48 31 f8             	xor    %rdi,%rax
  72c4ba:	bf 7f 00 00 00       	mov    $0x7f,%edi
  72c4bf:	48 0f bd f8          	bsr    %rax,%rdi
  72c4c3:	83 f7 3f             	xor    $0x3f,%edi
  72c4c6:	49 83 f9 02          	cmp    $0x2,%r9
  72c4ca:	0f 82 a6 02 00 00    	jb     72c776 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  72c4d0:	48 89 e9             	mov    %rbp,%rcx
  72c4d3:	48 c1 e1 04          	shl    $0x4,%rcx
  72c4d7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72c4dc:	48 01 c8             	add    %rcx,%rax
  72c4df:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  72c4e4:	48 03 4c 24 58       	add    0x58(%rsp),%rcx
  72c4e9:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  72c4ee:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  72c4f3:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  72c4f8:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  72c4ff:	00 
  72c500:	eb 4b                	jmp    72c54d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x23d>
  72c502:	4c 89 ed             	mov    %r13,%rbp
  72c505:	4c 89 c6             	mov    %r8,%rsi
  72c508:	49 29 f4             	sub    %rsi,%r12
  72c50b:	48 89 ef             	mov    %rbp,%rdi
  72c50e:	4c 89 e2             	mov    %r12,%rdx
  72c511:	ff 15 d9 b7 3b 00    	call   *0x3bb7d9(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72c517:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  72c51e:	00 
  72c51f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c524:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72c529:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72c52e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72c533:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  72c53a:	00 
  72c53b:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
  72c542:	00 
  72c543:	49 83 f9 01          	cmp    $0x1,%r9
  72c547:	0f 86 23 02 00 00    	jbe    72c770 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x460>
  72c54d:	42 38 bc 0c 95 00 00 	cmp    %dil,0x95(%rsp,%r9,1)
  72c554:	00 
  72c555:	0f 82 1b 02 00 00    	jb     72c776 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  72c55b:	49 ff c9             	dec    %r9
  72c55e:	4a 8b 84 cc d8 00 00 	mov    0xd8(%rsp,%r9,8),%rax
  72c565:	00 
  72c566:	48 89 c3             	mov    %rax,%rbx
  72c569:	48 d1 eb             	shr    $1,%rbx
  72c56c:	4d 89 e7             	mov    %r12,%r15
  72c56f:	49 d1 ef             	shr    $1,%r15
  72c572:	4e 8d 34 3b          	lea    (%rbx,%r15,1),%r14
  72c576:	4d 39 ee             	cmp    %r13,%r14
  72c579:	77 25                	ja     72c5a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x290>
  72c57b:	89 c1                	mov    %eax,%ecx
  72c57d:	44 09 e1             	or     %r12d,%ecx
  72c580:	83 e1 01             	and    $0x1,%ecx
  72c583:	75 1b                	jne    72c5a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x290>
  72c585:	4d 01 f6             	add    %r14,%r14
  72c588:	4d 89 f4             	mov    %r14,%r12
  72c58b:	49 83 f9 01          	cmp    $0x1,%r9
  72c58f:	77 bc                	ja     72c54d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x23d>
  72c591:	e9 da 01 00 00       	jmp    72c770 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x460>
  72c596:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72c59d:	00 00 00 
  72c5a0:	4c 29 f5             	sub    %r14,%rbp
  72c5a3:	48 c1 e5 04          	shl    $0x4,%rbp
  72c5a7:	48 03 6c 24 10       	add    0x10(%rsp),%rbp
  72c5ac:	a8 01                	test   $0x1,%al
  72c5ae:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  72c5b3:	75 5b                	jne    72c610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x300>
  72c5b5:	48 89 d8             	mov    %rbx,%rax
  72c5b8:	48 83 c8 01          	or     $0x1,%rax
  72c5bc:	4c 0f bd c0          	bsr    %rax,%r8
  72c5c0:	41 83 f0 3f          	xor    $0x3f,%r8d
  72c5c4:	45 01 c0             	add    %r8d,%r8d
  72c5c7:	41 83 f0 7e          	xor    $0x7e,%r8d
  72c5cb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72c5d0:	48 89 04 24          	mov    %rax,(%rsp)
  72c5d4:	48 89 ef             	mov    %rbp,%rdi
  72c5d7:	48 89 de             	mov    %rbx,%rsi
  72c5da:	4c 89 e9             	mov    %r13,%rcx
  72c5dd:	45 31 c9             	xor    %r9d,%r9d
  72c5e0:	e8 ab 22 00 00       	call   72e890 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72c5e5:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72c5ea:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72c5ef:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72c5f4:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c5f9:	41 f6 c4 01          	test   $0x1,%r12b
  72c5fd:	74 17                	je     72c616 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x306>
  72c5ff:	4d 85 ff             	test   %r15,%r15
  72c602:	75 66                	jne    72c66a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x35a>
  72c604:	e9 2a ff ff ff       	jmp    72c533 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  72c609:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72c610:	41 f6 c4 01          	test   $0x1,%r12b
  72c614:	75 e9                	jne    72c5ff <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x2ef>
  72c616:	48 89 df             	mov    %rbx,%rdi
  72c619:	48 c1 e7 04          	shl    $0x4,%rdi
  72c61d:	48 01 ef             	add    %rbp,%rdi
  72c620:	4c 89 f8             	mov    %r15,%rax
  72c623:	48 83 c8 01          	or     $0x1,%rax
  72c627:	4c 0f bd c0          	bsr    %rax,%r8
  72c62b:	41 83 f0 3f          	xor    $0x3f,%r8d
  72c62f:	45 01 c0             	add    %r8d,%r8d
  72c632:	41 83 f0 7e          	xor    $0x7e,%r8d
  72c636:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72c63b:	48 89 04 24          	mov    %rax,(%rsp)
  72c63f:	4c 89 fe             	mov    %r15,%rsi
  72c642:	4c 89 e9             	mov    %r13,%rcx
  72c645:	45 31 c9             	xor    %r9d,%r9d
  72c648:	e8 43 22 00 00       	call   72e890 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72c64d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72c652:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72c657:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72c65c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c661:	4d 85 ff             	test   %r15,%r15
  72c664:	0f 84 c9 fe ff ff    	je     72c533 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  72c66a:	48 85 db             	test   %rbx,%rbx
  72c66d:	0f 84 c0 fe ff ff    	je     72c533 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  72c673:	49 39 df             	cmp    %rbx,%r15
  72c676:	49 89 dc             	mov    %rbx,%r12
  72c679:	4d 0f 42 e7          	cmovb  %r15,%r12
  72c67d:	4d 39 e5             	cmp    %r12,%r13
  72c680:	0f 82 ad fe ff ff    	jb     72c533 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  72c686:	49 89 dd             	mov    %rbx,%r13
  72c689:	49 c1 e5 04          	shl    $0x4,%r13
  72c68d:	49 01 ed             	add    %rbp,%r13
  72c690:	4c 39 fb             	cmp    %r15,%rbx
  72c693:	48 89 ee             	mov    %rbp,%rsi
  72c696:	49 0f 47 f5          	cmova  %r13,%rsi
  72c69a:	49 c1 e4 04          	shl    $0x4,%r12
  72c69e:	48 89 d7             	mov    %rdx,%rdi
  72c6a1:	4c 89 e2             	mov    %r12,%rdx
  72c6a4:	ff 15 46 b6 3b 00    	call   *0x3bb646(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72c6aa:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  72c6af:	4d 01 c4             	add    %r8,%r12
  72c6b2:	4c 39 fb             	cmp    %r15,%rbx
  72c6b5:	76 5c                	jbe    72c713 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x403>
  72c6b7:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  72c6bc:	0f 1f 40 00          	nopl   0x0(%rax)
  72c6c0:	49 8d 4d f0          	lea    -0x10(%r13),%rcx
  72c6c4:	49 8b 54 24 f0       	mov    -0x10(%r12),%rdx
  72c6c9:	31 f6                	xor    %esi,%esi
  72c6cb:	31 ff                	xor    %edi,%edi
  72c6cd:	49 3b 55 f0          	cmp    -0x10(%r13),%rdx
  72c6d1:	49 8d 54 24 f0       	lea    -0x10(%r12),%rdx
  72c6d6:	40 0f 92 c6          	setb   %sil
  72c6da:	48 0f 42 d1          	cmovb  %rcx,%rdx
  72c6de:	40 0f 93 c7          	setae  %dil
  72c6e2:	0f 10 02             	movups (%rdx),%xmm0
  72c6e5:	0f 11 00             	movups %xmm0,(%rax)
  72c6e8:	c1 e7 04             	shl    $0x4,%edi
  72c6eb:	49 01 fd             	add    %rdi,%r13
  72c6ee:	49 83 c5 f0          	add    $0xfffffffffffffff0,%r13
  72c6f2:	c1 e6 04             	shl    $0x4,%esi
  72c6f5:	49 01 f4             	add    %rsi,%r12
  72c6f8:	49 83 c4 f0          	add    $0xfffffffffffffff0,%r12
  72c6fc:	49 39 ed             	cmp    %rbp,%r13
  72c6ff:	0f 84 fd fd ff ff    	je     72c502 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f2>
  72c705:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  72c709:	4d 39 c4             	cmp    %r8,%r12
  72c70c:	75 b2                	jne    72c6c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x3b0>
  72c70e:	e9 ef fd ff ff       	jmp    72c502 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f2>
  72c713:	4c 89 c6             	mov    %r8,%rsi
  72c716:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  72c71b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72c720:	48 89 f2             	mov    %rsi,%rdx
  72c723:	49 8b 4d 00          	mov    0x0(%r13),%rcx
  72c727:	31 c0                	xor    %eax,%eax
  72c729:	31 f6                	xor    %esi,%esi
  72c72b:	48 3b 0a             	cmp    (%rdx),%rcx
  72c72e:	0f 92 c1             	setb   %cl
  72c731:	40 0f 93 c6          	setae  %sil
  72c735:	48 89 d7             	mov    %rdx,%rdi
  72c738:	49 0f 42 fd          	cmovb  %r13,%rdi
  72c73c:	0f 10 07             	movups (%rdi),%xmm0
  72c73f:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
  72c743:	c1 e6 04             	shl    $0x4,%esi
  72c746:	48 01 d6             	add    %rdx,%rsi
  72c749:	48 83 c5 10          	add    $0x10,%rbp
  72c74d:	4c 39 e6             	cmp    %r12,%rsi
  72c750:	0f 84 b2 fd ff ff    	je     72c508 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f8>
  72c756:	88 c8                	mov    %cl,%al
  72c758:	c1 e0 04             	shl    $0x4,%eax
  72c75b:	49 01 c5             	add    %rax,%r13
  72c75e:	4d 39 c5             	cmp    %r8,%r13
  72c761:	75 bd                	jne    72c720 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x410>
  72c763:	e9 a0 fd ff ff       	jmp    72c508 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f8>
  72c768:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72c76f:	00 
  72c770:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  72c776:	4e 89 a4 cc d8 00 00 	mov    %r12,0xd8(%rsp,%r9,8)
  72c77d:	00 
  72c77e:	42 88 bc 0c 96 00 00 	mov    %dil,0x96(%rsp,%r9,1)
  72c785:	00 
  72c786:	48 39 6c 24 28       	cmp    %rbp,0x28(%rsp)
  72c78b:	0f 86 b3 01 00 00    	jbe    72c944 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x634>
  72c791:	49 ff c1             	inc    %r9
  72c794:	48 89 f0             	mov    %rsi,%rax
  72c797:	48 d1 e8             	shr    $1,%rax
  72c79a:	48 01 c5             	add    %rax,%rbp
  72c79d:	49 89 f4             	mov    %rsi,%r12
  72c7a0:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72c7a5:	48 29 ee             	sub    %rbp,%rsi
  72c7a8:	0f 87 52 fc ff ff    	ja     72c400 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xf0>
  72c7ae:	e9 2d fc ff ff       	jmp    72c3e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xd0>
  72c7b3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72c7ba:	84 00 00 00 00 00 
  72c7c0:	4c 8b 1f             	mov    (%rdi),%r11
  72c7c3:	4c 8b 77 10          	mov    0x10(%rdi),%r14
  72c7c7:	4d 39 de             	cmp    %r11,%r14
  72c7ca:	49 89 f7             	mov    %rsi,%r15
  72c7cd:	73 15                	jae    72c7e4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x4d4>
  72c7cf:	48 83 fe 02          	cmp    $0x2,%rsi
  72c7d3:	75 54                	jne    72c829 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x519>
  72c7d5:	b8 02 00 00 00       	mov    $0x2,%eax
  72c7da:	be 01 00 00 00       	mov    $0x1,%esi
  72c7df:	e9 af 00 00 00       	jmp    72c893 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x583>
  72c7e4:	b8 02 00 00 00       	mov    $0x2,%eax
  72c7e9:	48 83 fe 02          	cmp    $0x2,%rsi
  72c7ed:	0f 84 7a fc ff ff    	je     72c46d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c7f3:	4c 89 cb             	mov    %r9,%rbx
  72c7f6:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72c7fb:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  72c7ff:	b8 02 00 00 00       	mov    $0x2,%eax
  72c804:	4d 89 f1             	mov    %r14,%r9
  72c807:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72c80e:	00 00 
  72c810:	4d 89 ca             	mov    %r9,%r10
  72c813:	4d 8b 08             	mov    (%r8),%r9
  72c816:	4d 39 d1             	cmp    %r10,%r9
  72c819:	72 52                	jb     72c86d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x55d>
  72c81b:	48 ff c0             	inc    %rax
  72c81e:	49 83 c0 10          	add    $0x10,%r8
  72c822:	49 39 c7             	cmp    %rax,%r15
  72c825:	75 e9                	jne    72c810 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x500>
  72c827:	eb 2e                	jmp    72c857 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x547>
  72c829:	4c 89 cb             	mov    %r9,%rbx
  72c82c:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72c831:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  72c835:	b8 02 00 00 00       	mov    $0x2,%eax
  72c83a:	4d 89 f1             	mov    %r14,%r9
  72c83d:	0f 1f 00             	nopl   (%rax)
  72c840:	4d 89 ca             	mov    %r9,%r10
  72c843:	4d 8b 08             	mov    (%r8),%r9
  72c846:	4d 39 d1             	cmp    %r10,%r9
  72c849:	73 22                	jae    72c86d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x55d>
  72c84b:	48 ff c0             	inc    %rax
  72c84e:	49 83 c0 10          	add    $0x10,%r8
  72c852:	49 39 c7             	cmp    %rax,%r15
  72c855:	75 e9                	jne    72c840 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x530>
  72c857:	4c 89 fe             	mov    %r15,%rsi
  72c85a:	4c 89 f8             	mov    %r15,%rax
  72c85d:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  72c862:	49 89 d9             	mov    %rbx,%r9
  72c865:	0f 82 ac fb ff ff    	jb     72c417 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x107>
  72c86b:	eb 11                	jmp    72c87e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x56e>
  72c86d:	4c 89 fe             	mov    %r15,%rsi
  72c870:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  72c875:	49 89 d9             	mov    %rbx,%r9
  72c878:	0f 82 99 fb ff ff    	jb     72c417 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x107>
  72c87e:	4d 39 de             	cmp    %r11,%r14
  72c881:	0f 83 e6 fb ff ff    	jae    72c46d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c887:	48 89 c6             	mov    %rax,%rsi
  72c88a:	48 d1 ee             	shr    $1,%rsi
  72c88d:	0f 84 da fb ff ff    	je     72c46d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c893:	49 89 c0             	mov    %rax,%r8
  72c896:	49 c1 e0 04          	shl    $0x4,%r8
  72c89a:	4a 8d 1c 07          	lea    (%rdi,%r8,1),%rbx
  72c89e:	48 83 fe 01          	cmp    $0x1,%rsi
  72c8a2:	75 04                	jne    72c8a8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x598>
  72c8a4:	31 c9                	xor    %ecx,%ecx
  72c8a6:	eb 79                	jmp    72c921 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x611>
  72c8a8:	4d 89 ce             	mov    %r9,%r14
  72c8ab:	49 89 f1             	mov    %rsi,%r9
  72c8ae:	49 83 e1 fe          	and    $0xfffffffffffffffe,%r9
  72c8b2:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  72c8b7:	4c 8d 14 0a          	lea    (%rdx,%rcx,1),%r10
  72c8bb:	49 01 c8             	add    %rcx,%r8
  72c8be:	4c 03 44 24 58       	add    0x58(%rsp),%r8
  72c8c3:	31 c9                	xor    %ecx,%ecx
  72c8c5:	48 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%rdx
  72c8cc:	ff ff 0f 
  72c8cf:	90                   	nop
  72c8d0:	41 0f 10 42 f0       	movups -0x10(%r10),%xmm0
  72c8d5:	41 0f 10 08          	movups (%r8),%xmm1
  72c8d9:	41 0f 11 4a f0       	movups %xmm1,-0x10(%r10)
  72c8de:	41 0f 11 00          	movups %xmm0,(%r8)
  72c8e2:	49 89 cb             	mov    %rcx,%r11
  72c8e5:	49 31 d3             	xor    %rdx,%r11
  72c8e8:	49 c1 e3 04          	shl    $0x4,%r11
  72c8ec:	41 0f 10 02          	movups (%r10),%xmm0
  72c8f0:	42 0f 10 0c 1b       	movups (%rbx,%r11,1),%xmm1
  72c8f5:	41 0f 11 0a          	movups %xmm1,(%r10)
  72c8f9:	42 0f 11 04 1b       	movups %xmm0,(%rbx,%r11,1)
  72c8fe:	48 83 c1 02          	add    $0x2,%rcx
  72c902:	49 83 c2 20          	add    $0x20,%r10
  72c906:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
  72c90a:	49 39 c9             	cmp    %rcx,%r9
  72c90d:	75 c1                	jne    72c8d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x5c0>
  72c90f:	40 f6 c6 01          	test   $0x1,%sil
  72c913:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c918:	4d 89 f1             	mov    %r14,%r9
  72c91b:	0f 84 4c fb ff ff    	je     72c46d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c921:	48 89 ce             	mov    %rcx,%rsi
  72c924:	48 f7 d6             	not    %rsi
  72c927:	48 c1 e1 04          	shl    $0x4,%rcx
  72c92b:	48 c1 e6 04          	shl    $0x4,%rsi
  72c92f:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  72c933:	0f 10 0c 33          	movups (%rbx,%rsi,1),%xmm1
  72c937:	0f 11 0c 0f          	movups %xmm1,(%rdi,%rcx,1)
  72c93b:	0f 11 04 33          	movups %xmm0,(%rbx,%rsi,1)
  72c93f:	e9 29 fb ff ff       	jmp    72c46d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c944:	41 f6 c4 01          	test   $0x1,%r12b
  72c948:	75 34                	jne    72c97e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x66e>
  72c94a:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72c94f:	48 89 f0             	mov    %rsi,%rax
  72c952:	48 83 c8 01          	or     $0x1,%rax
  72c956:	4c 0f bd c0          	bsr    %rax,%r8
  72c95a:	41 83 f0 3f          	xor    $0x3f,%r8d
  72c95e:	45 01 c0             	add    %r8d,%r8d
  72c961:	41 83 f0 7e          	xor    $0x7e,%r8d
  72c965:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72c96a:	48 89 04 24          	mov    %rax,(%rsp)
  72c96e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  72c973:	4c 89 e9             	mov    %r13,%rcx
  72c976:	45 31 c9             	xor    %r9d,%r9d
  72c979:	e8 12 1f 00 00       	call   72e890 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72c97e:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
  72c985:	5b                   	pop    %rbx
  72c986:	41 5c                	pop    %r12
  72c988:	41 5d                	pop    %r13
  72c98a:	41 5e                	pop    %r14
  72c98c:	41 5f                	pop    %r15
  72c98e:	5d                   	pop    %rbp
  72c98f:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
