
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000071f9c0 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_>:
  71f9c0:	55                   	push   %rbp
  71f9c1:	41 57                	push   %r15
  71f9c3:	41 56                	push   %r14
  71f9c5:	41 55                	push   %r13
  71f9c7:	41 54                	push   %r12
  71f9c9:	53                   	push   %rbx
  71f9ca:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
  71f9d1:	49 89 fd             	mov    %rdi,%r13
  71f9d4:	48 8b 46 10          	mov    0x10(%rsi),%rax
  71f9d8:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  71f9dd:	48 8b 2e             	mov    (%rsi),%rbp
  71f9e0:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
  71f9e4:	4c 8b 46 18          	mov    0x18(%rsi),%r8
  71f9e8:	4c 39 c3             	cmp    %r8,%rbx
  71f9eb:	0f 84 fd 00 00 00    	je     71faee <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x12e>
  71f9f1:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  71f9f6:	4c 8b 6e 20          	mov    0x20(%rsi),%r13
  71f9fa:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
  71f9ff:	4c 8b 35 ea 82 3c 00 	mov    0x3c82ea(%rip),%r14        # ae7cf0 <memcpy@GLIBC_2.14>
  71fa06:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  71fa0b:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  71fa10:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  71fa15:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  71fa1a:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
  71fa1f:	eb 58                	jmp    71fa79 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xb9>
  71fa21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71fa28:	0f 1f 84 00 00 00 00 
  71fa2f:	00 
  71fa30:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71fa35:	4d 89 65 00          	mov    %r12,0x0(%r13)
  71fa39:	4d 89 7d 08          	mov    %r15,0x8(%r13)
  71fa3d:	41 88 6d 10          	mov    %bpl,0x10(%r13)
  71fa41:	49 8d 7d 11          	lea    0x11(%r13),%rdi
  71fa45:	ba 97 00 00 00       	mov    $0x97,%edx
  71fa4a:	48 8d 74 24 41       	lea    0x41(%rsp),%rsi
  71fa4f:	41 ff d6             	call   *%r14
  71fa52:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  71fa59:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  71fa5e:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
  71fa63:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
  71fa68:	4c 39 c3             	cmp    %r8,%rbx
  71fa6b:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
  71fa70:	4c 8b 35 79 82 3c 00 	mov    0x3c8279(%rip),%r14        # ae7cf0 <memcpy@GLIBC_2.14>
  71fa77:	74 5c                	je     71fad5 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x115>
  71fa79:	4c 8b 23             	mov    (%rbx),%r12
  71fa7c:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
  71fa80:	0f b6 6b 10          	movzbl 0x10(%rbx),%ebp
  71fa84:	48 8d 73 11          	lea    0x11(%rbx),%rsi
  71fa88:	ba 97 00 00 00       	mov    $0x97,%edx
  71fa8d:	41 ff d6             	call   *%r14
  71fa90:	48 81 c3 a8 00 00 00 	add    $0xa8,%rbx
  71fa97:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  71fa9c:	48 89 58 08          	mov    %rbx,0x8(%rax)
  71faa0:	49 83 fc 02          	cmp    $0x2,%r12
  71faa4:	75 8a                	jne    71fa30 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x70>
  71faa6:	4d 8b 65 10          	mov    0x10(%r13),%r12
  71faaa:	4d 3b 65 00          	cmp    0x0(%r13),%r12
  71faae:	75 08                	jne    71fab8 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xf8>
  71fab0:	4c 89 ef             	mov    %r13,%rdi
  71fab3:	e8 08 67 00 00       	call   7261c0 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecAINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCshBhuxcId5D0_4gpui6source7FieldIdEj2_E8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71fab8:	49 8b 45 08          	mov    0x8(%r13),%rax
  71fabc:	4c 89 e1             	mov    %r12,%rcx
  71fabf:	48 c1 e1 04          	shl    $0x4,%rcx
  71fac3:	4c 89 3c 08          	mov    %r15,(%rax,%rcx,1)
  71fac7:	40 88 6c 08 08       	mov    %bpl,0x8(%rax,%rcx,1)
  71facc:	49 ff c4             	inc    %r12
  71facf:	4d 89 65 10          	mov    %r12,0x10(%r13)
  71fad3:	eb 8e                	jmp    71fa63 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xa3>
  71fad5:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  71fada:	48 8b 58 08          	mov    0x8(%rax),%rbx
  71fade:	4c 8b 40 18          	mov    0x18(%rax),%r8
  71fae2:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  71fae7:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
  71faec:	eb 05                	jmp    71faf3 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x133>
  71faee:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  71faf3:	4c 89 c0             	mov    %r8,%rax
  71faf6:	48 29 d8             	sub    %rbx,%rax
  71faf9:	48 c1 e8 03          	shr    $0x3,%rax
  71fafd:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  71fb04:	c3 30 0c 
  71fb07:	48 f7 e1             	mul    %rcx
  71fb0a:	49 39 d8             	cmp    %rbx,%r8
  71fb0d:	74 69                	je     71fb78 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x1b8>
  71fb0f:	49 89 d4             	mov    %rdx,%r12
  71fb12:	48 81 c3 88 00 00 00 	add    $0x88,%rbx
  71fb19:	4c 8b 35 a8 81 3c 00 	mov    0x3c81a8(%rip),%r14        # ae7cc8 <_DYNAMIC+0x248>
  71fb20:	eb 1a                	jmp    71fb3c <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x17c>
  71fb22:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71fb29:	1f 84 00 00 00 00 00 
  71fb30:	48 81 c3 a8 00 00 00 	add    $0xa8,%rbx
  71fb37:	49 ff cc             	dec    %r12
  71fb3a:	74 3c                	je     71fb78 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x1b8>
  71fb3c:	83 bb 78 ff ff ff 02 	cmpl   $0x2,-0x88(%rbx)
  71fb43:	74 eb                	je     71fb30 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71fb45:	48 8b 73 90          	mov    -0x70(%rbx),%rsi
  71fb49:	48 85 f6             	test   %rsi,%rsi
  71fb4c:	74 10                	je     71fb5e <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x19e>
  71fb4e:	48 8b 7b 98          	mov    -0x68(%rbx),%rdi
  71fb52:	48 c1 e6 03          	shl    $0x3,%rsi
  71fb56:	ba 08 00 00 00       	mov    $0x8,%edx
  71fb5b:	41 ff d6             	call   *%r14
  71fb5e:	48 8b 73 f8          	mov    -0x8(%rbx),%rsi
  71fb62:	48 85 f6             	test   %rsi,%rsi
  71fb65:	74 c9                	je     71fb30 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71fb67:	48 8b 3b             	mov    (%rbx),%rdi
  71fb6a:	48 c1 e6 05          	shl    $0x5,%rsi
  71fb6e:	ba 08 00 00 00       	mov    $0x8,%edx
  71fb73:	41 ff d6             	call   *%r14
  71fb76:	eb b8                	jmp    71fb30 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71fb78:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  71fb7d:	48 29 e9             	sub    %rbp,%rcx
  71fb80:	48 c1 e9 03          	shr    $0x3,%rcx
  71fb84:	48 b8 3d cf f3 3c cf 	movabs $0xcf3cf3cf3cf3cf3d,%rax
  71fb8b:	f3 3c cf 
  71fb8e:	48 0f af c1          	imul   %rcx,%rax
  71fb92:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  71fb97:	49 89 4d 00          	mov    %rcx,0x0(%r13)
  71fb9b:	49 89 6d 08          	mov    %rbp,0x8(%r13)
  71fb9f:	49 89 45 10          	mov    %rax,0x10(%r13)
  71fba3:	4c 89 e8             	mov    %r13,%rax
  71fba6:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
  71fbad:	5b                   	pop    %rbx
  71fbae:	41 5c                	pop    %r12
  71fbb0:	41 5d                	pop    %r13
  71fbb2:	41 5e                	pop    %r14
  71fbb4:	41 5f                	pop    %r15
  71fbb6:	5d                   	pop    %rbp
  71fbb7:	c3                   	ret
  71fbb8:	49 89 c6             	mov    %rax,%r14
  71fbbb:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  71fbc0:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  71fbc5:	e8 76 f6 ff ff       	call   71f240 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCscdodAO9FK5_5alloc3vec13in_place_drop11InPlaceDropNtNtCshBhuxcId5D0_4gpui4list9ListDraftEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71fbca:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  71fbcf:	e8 6c f7 ff ff       	call   71f340 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_>
  71fbd4:	4c 89 f7             	mov    %r14,%rdi
  71fbd7:	e8 74 88 39 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
