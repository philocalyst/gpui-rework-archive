
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

00000000006ebc90 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_>:
  6ebc90:	53                   	push   %rbx
  6ebc91:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
  6ebc98:	48 89 fb             	mov    %rdi,%rbx
  6ebc9b:	48 8b 06             	mov    (%rsi),%rax
  6ebc9e:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6ebca2:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6ebca6:	48 85 ff             	test   %rdi,%rdi
  6ebca9:	0f 84 c3 02 00 00    	je     6ebf72 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x2e2>
  6ebcaf:	48 8b 8c c8 38 05 00 	mov    0x538(%rax,%rcx,8),%rcx
  6ebcb6:	00 
  6ebcb7:	48 89 f8             	mov    %rdi,%rax
  6ebcba:	48 ff c8             	dec    %rax
  6ebcbd:	0f 84 cb 00 00 00    	je     6ebd8e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0xfe>
  6ebcc3:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6ebcc7:	48 89 c6             	mov    %rax,%rsi
  6ebcca:	48 83 e6 07          	and    $0x7,%rsi
  6ebcce:	74 2b                	je     6ebcfb <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x6b>
  6ebcd0:	45 31 c0             	xor    %r8d,%r8d
  6ebcd3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ebcda:	84 00 00 00 00 00 
  6ebce0:	44 0f b7 89 32 05 00 	movzwl 0x532(%rcx),%r9d
  6ebce7:	00 
  6ebce8:	4a 8b 8c c9 38 05 00 	mov    0x538(%rcx,%r9,8),%rcx
  6ebcef:	00 
  6ebcf0:	49 ff c0             	inc    %r8
  6ebcf3:	4c 39 c6             	cmp    %r8,%rsi
  6ebcf6:	75 e8                	jne    6ebce0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x50>
  6ebcf8:	4c 29 c0             	sub    %r8,%rax
  6ebcfb:	48 83 ff 07          	cmp    $0x7,%rdi
  6ebcff:	0f 82 89 00 00 00    	jb     6ebd8e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0xfe>
  6ebd05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6ebd0c:	00 00 00 00 
  6ebd10:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd17:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd1e:	00 
  6ebd1f:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd26:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd2d:	00 
  6ebd2e:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd35:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd3c:	00 
  6ebd3d:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd44:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd4b:	00 
  6ebd4c:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd53:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd5a:	00 
  6ebd5b:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd62:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd69:	00 
  6ebd6a:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd71:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd78:	00 
  6ebd79:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd80:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd87:	00 
  6ebd88:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6ebd8c:	75 82                	jne    6ebd10 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x80>
  6ebd8e:	0f b7 81 32 05 00 00 	movzwl 0x532(%rcx),%eax
  6ebd95:	48 ff c8             	dec    %rax
  6ebd98:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6ebd9f:	00 
  6ebda0:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  6ebda7:	00 00 00 00 00 
  6ebdac:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6ebdb3:	00 
  6ebdb4:	48 89 e7             	mov    %rsp,%rdi
  6ebdb7:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
  6ebdbe:	00 
  6ebdbf:	e8 4c 67 00 00       	call   6f2510 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>
  6ebdc4:	48 8b 3c 24          	mov    (%rsp),%rdi
  6ebdc8:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6ebdcd:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  6ebdd4:	00 
  6ebdd5:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6ebdda:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  6ebde1:	00 
  6ebde2:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  6ebde7:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6ebdee:	00 
  6ebdef:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  6ebdf4:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  6ebdfb:	00 
  6ebdfc:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  6ebe01:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  6ebe08:	00 
  6ebe09:	0f 10 44 24 58       	movups 0x58(%rsp),%xmm0
  6ebe0e:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  6ebe15:	00 
  6ebe16:	0f 10 44 24 68       	movups 0x68(%rsp),%xmm0
  6ebe1b:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  6ebe22:	00 
  6ebe23:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6ebe28:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6ebe2f:	00 
  6ebe30:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  6ebe37:	00 
  6ebe38:	0f b7 90 32 05 00 00 	movzwl 0x532(%rax),%edx
  6ebe3f:	48 39 d1             	cmp    %rdx,%rcx
  6ebe42:	72 26                	jb     6ebe6a <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x1da>
  6ebe44:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ebe4b:	00 00 00 00 00 
  6ebe50:	0f b7 88 30 05 00 00 	movzwl 0x530(%rax),%ecx
  6ebe57:	48 8b 80 d0 04 00 00 	mov    0x4d0(%rax),%rax
  6ebe5e:	48 ff c6             	inc    %rsi
  6ebe61:	66 3b 88 32 05 00 00 	cmp    0x532(%rax),%cx
  6ebe68:	73 e6                	jae    6ebe50 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x1c0>
  6ebe6a:	4c 6b c1 70          	imul   $0x70,%rcx,%r8
  6ebe6e:	48 8b 94 c8 d8 04 00 	mov    0x4d8(%rax,%rcx,8),%rdx
  6ebe75:	00 
  6ebe76:	48 89 bc c8 d8 04 00 	mov    %rdi,0x4d8(%rax,%rcx,8)
  6ebe7d:	00 
  6ebe7e:	42 0f 10 44 00 60    	movups 0x60(%rax,%r8,1),%xmm0
  6ebe84:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6ebe89:	42 0f 10 44 00 50    	movups 0x50(%rax,%r8,1),%xmm0
  6ebe8f:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  6ebe94:	42 0f 10 44 00 40    	movups 0x40(%rax,%r8,1),%xmm0
  6ebe9a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  6ebe9f:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6ebea4:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6ebeaa:	42 0f 10 54 00 20    	movups 0x20(%rax,%r8,1),%xmm2
  6ebeb0:	42 0f 10 5c 00 30    	movups 0x30(%rax,%r8,1),%xmm3
  6ebeb6:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  6ebebb:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
  6ebec0:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6ebec5:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6ebec9:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
  6ebed0:	00 
  6ebed1:	0f 28 8c 24 c0 00 00 	movaps 0xc0(%rsp),%xmm1
  6ebed8:	00 
  6ebed9:	0f 28 94 24 d0 00 00 	movaps 0xd0(%rsp),%xmm2
  6ebee0:	00 
  6ebee1:	0f 28 9c 24 e0 00 00 	movaps 0xe0(%rsp),%xmm3
  6ebee8:	00 
  6ebee9:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6ebeee:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6ebef4:	42 0f 11 54 00 20    	movups %xmm2,0x20(%rax,%r8,1)
  6ebefa:	42 0f 11 5c 00 30    	movups %xmm3,0x30(%rax,%r8,1)
  6ebf00:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
  6ebf07:	00 
  6ebf08:	42 0f 11 44 00 40    	movups %xmm0,0x40(%rax,%r8,1)
  6ebf0e:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  6ebf15:	00 
  6ebf16:	42 0f 11 44 00 50    	movups %xmm0,0x50(%rax,%r8,1)
  6ebf1c:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  6ebf23:	00 
  6ebf24:	42 0f 11 44 00 60    	movups %xmm0,0x60(%rax,%r8,1)
  6ebf2a:	48 85 f6             	test   %rsi,%rsi
  6ebf2d:	74 6c                	je     6ebf9b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x30b>
  6ebf2f:	48 8d 3c c8          	lea    (%rax,%rcx,8),%rdi
  6ebf33:	48 81 c7 40 05 00 00 	add    $0x540,%rdi
  6ebf3a:	48 89 f1             	mov    %rsi,%rcx
  6ebf3d:	48 83 e1 07          	and    $0x7,%rcx
  6ebf41:	74 5d                	je     6ebfa0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x310>
  6ebf43:	45 31 c9             	xor    %r9d,%r9d
  6ebf46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6ebf4d:	00 00 00 
  6ebf50:	48 8b 07             	mov    (%rdi),%rax
  6ebf53:	48 8d b8 38 05 00 00 	lea    0x538(%rax),%rdi
  6ebf5a:	49 ff c1             	inc    %r9
  6ebf5d:	4c 39 c9             	cmp    %r9,%rcx
  6ebf60:	75 ee                	jne    6ebf50 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x2c0>
  6ebf62:	49 89 f0             	mov    %rsi,%r8
  6ebf65:	4d 29 c8             	sub    %r9,%r8
  6ebf68:	31 c9                	xor    %ecx,%ecx
  6ebf6a:	48 83 fe 08          	cmp    $0x8,%rsi
  6ebf6e:	73 40                	jae    6ebfb0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x320>
  6ebf70:	eb 7f                	jmp    6ebff1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ebf72:	48 89 04 24          	mov    %rax,(%rsp)
  6ebf76:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6ebf7d:	00 00 
  6ebf7f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6ebf84:	48 89 e6             	mov    %rsp,%rsi
  6ebf87:	48 89 df             	mov    %rbx,%rdi
  6ebf8a:	e8 81 65 00 00       	call   6f2510 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>
  6ebf8f:	48 89 d8             	mov    %rbx,%rax
  6ebf92:	48 81 c4 20 01 00 00 	add    $0x120,%rsp
  6ebf99:	5b                   	pop    %rbx
  6ebf9a:	c3                   	ret
  6ebf9b:	48 ff c1             	inc    %rcx
  6ebf9e:	eb 51                	jmp    6ebff1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ebfa0:	49 89 f0             	mov    %rsi,%r8
  6ebfa3:	31 c9                	xor    %ecx,%ecx
  6ebfa5:	48 83 fe 08          	cmp    $0x8,%rsi
  6ebfa9:	72 46                	jb     6ebff1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ebfab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ebfb0:	48 8b 07             	mov    (%rdi),%rax
  6ebfb3:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ebfba:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ebfc1:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ebfc8:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ebfcf:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ebfd6:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ebfdd:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ebfe4:	48 8d b8 38 05 00 00 	lea    0x538(%rax),%rdi
  6ebfeb:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6ebfef:	75 bf                	jne    6ebfb0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x320>
  6ebff1:	48 89 13             	mov    %rdx,(%rbx)
  6ebff4:	0f 28 04 24          	movaps (%rsp),%xmm0
  6ebff8:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6ebffd:	0f 28 54 24 20       	movaps 0x20(%rsp),%xmm2
  6ec002:	0f 28 5c 24 30       	movaps 0x30(%rsp),%xmm3
  6ec007:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6ec00b:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6ec00f:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  6ec013:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  6ec017:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  6ec01c:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
  6ec020:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  6ec025:	0f 11 43 58          	movups %xmm0,0x58(%rbx)
  6ec029:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6ec02e:	0f 11 43 68          	movups %xmm0,0x68(%rbx)
  6ec032:	48 89 43 78          	mov    %rax,0x78(%rbx)
  6ec036:	48 c7 83 80 00 00 00 	movq   $0x0,0x80(%rbx)
  6ec03d:	00 00 00 00 
  6ec041:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
  6ec048:	48 89 d8             	mov    %rbx,%rax
  6ec04b:	48 81 c4 20 01 00 00 	add    $0x120,%rsp
  6ec052:	5b                   	pop    %rbx
  6ec053:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
