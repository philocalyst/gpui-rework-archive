
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

0000000000714e60 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_>:
  714e60:	41 57                	push   %r15
  714e62:	41 56                	push   %r14
  714e64:	41 54                	push   %r12
  714e66:	53                   	push   %rbx
  714e67:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  714e6e:	48 89 fb             	mov    %rdi,%rbx
  714e71:	48 8b 46 40          	mov    0x40(%rsi),%rax
  714e75:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  714e7c:	00 
  714e7d:	0f 10 06             	movups (%rsi),%xmm0
  714e80:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  714e84:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  714e88:	0f 10 5e 30          	movups 0x30(%rsi),%xmm3
  714e8c:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
  714e91:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  714e96:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  714e9b:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  714ea0:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  714ea5:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  714eaa:	e8 f1 ee ff ff       	call   713da0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_>
  714eaf:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  714eb4:	4d 85 ff             	test   %r15,%r15
  714eb7:	0f 84 af 00 00 00    	je     714f6c <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x10c>
  714ebd:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  714ec2:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  714ec7:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  714ecc:	49 83 ff 01          	cmp    $0x1,%r15
  714ed0:	0f 85 d5 00 00 00    	jne    714fab <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x14b>
  714ed6:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  714edb:	ff 15 ff 2d 3d 00    	call   *0x3d2dff(%rip)        # ae7ce0 <_DYNAMIC+0x260>
  714ee1:	bf c0 00 00 00       	mov    $0xc0,%edi
  714ee6:	be 08 00 00 00       	mov    $0x8,%esi
  714eeb:	ff 15 cf 2d 3d 00    	call   *0x3d2dcf(%rip)        # ae7cc0 <_DYNAMIC+0x240>
  714ef1:	48 85 c0             	test   %rax,%rax
  714ef4:	0f 84 d1 00 00 00    	je     714fcb <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x16b>
  714efa:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  714f01:	66 c7 80 ba 00 00 00 	movw   $0x0,0xba(%rax)
  714f08:	00 00 
  714f0a:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  714f11:	00 00 
  714f13:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  714f18:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  714f1f:	00 00 
  714f21:	49 c1 e7 04          	shl    $0x4,%r15
  714f25:	4d 01 f7             	add    %r14,%r15
  714f28:	48 c7 44 24 40 02 00 	movq   $0x2,0x40(%rsp)
  714f2f:	00 00 
  714f31:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
  714f36:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  714f3b:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
  714f40:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  714f45:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  714f4a:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  714f4f:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  714f54:	e8 97 56 fd ff       	call   6ea5f0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBV_6marker5OwnedjNtNtCshBhuxcId5D0_4gpui4list6ListIdNtB1f_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterjB1y_INtNtNtB9_3vec9into_iter8IntoIterTjB1y_EEENtNtB9_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  714f59:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
  714f5e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  714f63:	0f 11 03             	movups %xmm0,(%rbx)
  714f66:	48 89 43 10          	mov    %rax,0x10(%rbx)
  714f6a:	eb 2d                	jmp    714f99 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x139>
  714f6c:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  714f73:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  714f7a:	00 
  714f7b:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  714f80:	48 85 f6             	test   %rsi,%rsi
  714f83:	74 14                	je     714f99 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x139>
  714f85:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  714f8a:	48 c1 e6 04          	shl    $0x4,%rsi
  714f8e:	ba 08 00 00 00       	mov    $0x8,%edx
  714f93:	ff 15 2f 2d 3d 00    	call   *0x3d2d2f(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  714f99:	48 89 d8             	mov    %rbx,%rax
  714f9c:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  714fa3:	5b                   	pop    %rbx
  714fa4:	41 5c                	pop    %r12
  714fa6:	41 5e                	pop    %r14
  714fa8:	41 5f                	pop    %r15
  714faa:	c3                   	ret
  714fab:	49 83 ff 15          	cmp    $0x15,%r15
  714faf:	73 2c                	jae    714fdd <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x17d>
  714fb1:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
  714fb6:	ba 01 00 00 00       	mov    $0x1,%edx
  714fbb:	4c 89 f7             	mov    %r14,%rdi
  714fbe:	4c 89 fe             	mov    %r15,%rsi
  714fc1:	e8 3a c3 ff ff       	call   711300 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB3S_8adapters3map3MapINtNtB8_4iter4IterNtB1q_9ListDraftENCNvMst_NtB1s_7runtimeINtB5T_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6o_>
  714fc6:	e9 0b ff ff ff       	jmp    714ed6 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x76>
  714fcb:	bf 08 00 00 00       	mov    $0x8,%edi
  714fd0:	be c0 00 00 00       	mov    $0xc0,%esi
  714fd5:	ff 15 1d 2d 3d 00    	call   *0x3d2d1d(%rip)        # ae7cf8 <_DYNAMIC+0x278>
  714fdb:	0f 0b                	ud2
  714fdd:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
  714fe2:	4c 89 f7             	mov    %r14,%rdi
  714fe5:	4c 89 fe             	mov    %r15,%rsi
  714fe8:	e8 83 90 01 00       	call   72e070 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_>
  714fed:	e9 e4 fe ff ff       	jmp    714ed6 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x76>
  714ff2:	48 89 c3             	mov    %rax,%rbx
  714ff5:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  714ffa:	eb 03                	jmp    714fff <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x19f>
  714ffc:	48 89 c3             	mov    %rax,%rbx
  714fff:	4d 85 e4             	test   %r12,%r12
  715002:	74 15                	je     715019 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x1b9>
  715004:	49 c1 e4 04          	shl    $0x4,%r12
  715008:	ba 08 00 00 00       	mov    $0x8,%edx
  71500d:	4c 89 f7             	mov    %r14,%rdi
  715010:	4c 89 e6             	mov    %r12,%rsi
  715013:	ff 15 af 2c 3d 00    	call   *0x3d2caf(%rip)        # ae7cc8 <_DYNAMIC+0x248>
  715019:	48 89 df             	mov    %rbx,%rdi
  71501c:	e8 2f 34 3a 00       	call   ab8450 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
