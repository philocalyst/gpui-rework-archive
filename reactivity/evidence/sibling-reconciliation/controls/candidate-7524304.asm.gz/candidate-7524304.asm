
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072cfd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>:
  72cfd0:	55                   	push   %rbp
  72cfd1:	41 57                	push   %r15
  72cfd3:	41 56                	push   %r14
  72cfd5:	41 55                	push   %r13
  72cfd7:	41 54                	push   %r12
  72cfd9:	53                   	push   %rbx
  72cfda:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
  72cfe1:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  72cfe6:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  72cfeb:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  72cff0:	48 83 fe 02          	cmp    $0x2,%rsi
  72cff4:	0f 82 44 06 00 00    	jb     72d63e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x66e>
  72cffa:	49 89 cd             	mov    %rcx,%r13
  72cffd:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  72d004:	00 00 40 
  72d007:	48 89 d1             	mov    %rdx,%rcx
  72d00a:	31 d2                	xor    %edx,%edx
  72d00c:	48 f7 f6             	div    %rsi
  72d00f:	48 83 fa 01          	cmp    $0x1,%rdx
  72d013:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72d017:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  72d01c:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  72d023:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  72d028:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  72d02d:	73 1e                	jae    72d04d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x7d>
  72d02f:	48 89 ca             	mov    %rcx,%rdx
  72d032:	48 89 f0             	mov    %rsi,%rax
  72d035:	48 d1 e8             	shr    $1,%rax
  72d038:	48 89 f1             	mov    %rsi,%rcx
  72d03b:	48 29 c1             	sub    %rax,%rcx
  72d03e:	48 83 f9 40          	cmp    $0x40,%rcx
  72d042:	b8 40 00 00 00       	mov    $0x40,%eax
  72d047:	48 0f 42 c1          	cmovb  %rcx,%rax
  72d04b:	eb 0e                	jmp    72d05b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x8b>
  72d04d:	48 89 f7             	mov    %rsi,%rdi
  72d050:	ff 15 52 b2 3b 00    	call   *0x3bb252(%rip)        # ae82a8 <_DYNAMIC+0x828>
  72d056:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d05b:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72d060:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72d065:	48 8d 48 20          	lea    0x20(%rax),%rcx
  72d069:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  72d06e:	48 8d 48 10          	lea    0x10(%rax),%rcx
  72d072:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  72d077:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  72d07b:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  72d080:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  72d086:	31 ed                	xor    %ebp,%ebp
  72d088:	45 31 c9             	xor    %r9d,%r9d
  72d08b:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  72d092:	00 
  72d093:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72d098:	48 29 ee             	sub    %rbp,%rsi
  72d09b:	77 23                	ja     72d0c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xf0>
  72d09d:	0f 1f 00             	nopl   (%rax)
  72d0a0:	31 ff                	xor    %edi,%edi
  72d0a2:	be 01 00 00 00       	mov    $0x1,%esi
  72d0a7:	49 83 f9 02          	cmp    $0x2,%r9
  72d0ab:	0f 83 df 00 00 00    	jae    72d190 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1c0>
  72d0b1:	e9 80 03 00 00       	jmp    72d436 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  72d0b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72d0bd:	00 00 00 
  72d0c0:	48 89 e9             	mov    %rbp,%rcx
  72d0c3:	48 c1 e1 04          	shl    $0x4,%rcx
  72d0c7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72d0cc:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
  72d0d0:	48 3b 74 24 18       	cmp    0x18(%rsp),%rsi
  72d0d5:	73 49                	jae    72d120 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x150>
  72d0d7:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  72d0dc:	74 62                	je     72d140 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x170>
  72d0de:	48 83 fe 20          	cmp    $0x20,%rsi
  72d0e2:	b8 20 00 00 00       	mov    $0x20,%eax
  72d0e7:	48 0f 43 f0          	cmovae %rax,%rsi
  72d0eb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72d0f0:	48 89 04 24          	mov    %rax,(%rsp)
  72d0f4:	4c 89 e9             	mov    %r13,%rcx
  72d0f7:	45 31 c0             	xor    %r8d,%r8d
  72d0fa:	4c 89 cb             	mov    %r9,%rbx
  72d0fd:	45 31 c9             	xor    %r9d,%r9d
  72d100:	49 89 f6             	mov    %rsi,%r14
  72d103:	e8 c8 22 00 00       	call   72f3d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72d108:	49 89 d9             	mov    %rbx,%r9
  72d10b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d110:	44 89 f0             	mov    %r14d,%eax
  72d113:	eb 18                	jmp    72d12d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d115:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72d11c:	00 00 00 00 
  72d120:	48 83 fe 02          	cmp    $0x2,%rsi
  72d124:	0f 83 56 03 00 00    	jae    72d480 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x4b0>
  72d12a:	48 89 f0             	mov    %rsi,%rax
  72d12d:	48 8d 34 45 01 00 00 	lea    0x1(,%rax,2),%rsi
  72d134:	00 
  72d135:	eb 18                	jmp    72d14f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x17f>
  72d137:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72d13e:	00 00 
  72d140:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72d145:	48 39 c6             	cmp    %rax,%rsi
  72d148:	48 0f 43 f0          	cmovae %rax,%rsi
  72d14c:	48 01 f6             	add    %rsi,%rsi
  72d14f:	4c 89 e0             	mov    %r12,%rax
  72d152:	48 d1 e8             	shr    $1,%rax
  72d155:	48 89 f1             	mov    %rsi,%rcx
  72d158:	48 d1 e9             	shr    $1,%rcx
  72d15b:	48 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%rdi
  72d162:	00 
  72d163:	48 29 c7             	sub    %rax,%rdi
  72d166:	48 8d 04 69          	lea    (%rcx,%rbp,2),%rax
  72d16a:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  72d16f:	48 0f af f9          	imul   %rcx,%rdi
  72d173:	48 0f af c1          	imul   %rcx,%rax
  72d177:	48 31 f8             	xor    %rdi,%rax
  72d17a:	bf 7f 00 00 00       	mov    $0x7f,%edi
  72d17f:	48 0f bd f8          	bsr    %rax,%rdi
  72d183:	83 f7 3f             	xor    $0x3f,%edi
  72d186:	49 83 f9 02          	cmp    $0x2,%r9
  72d18a:	0f 82 a6 02 00 00    	jb     72d436 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  72d190:	48 89 e9             	mov    %rbp,%rcx
  72d193:	48 c1 e1 04          	shl    $0x4,%rcx
  72d197:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72d19c:	48 01 c8             	add    %rcx,%rax
  72d19f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  72d1a4:	48 03 4c 24 58       	add    0x58(%rsp),%rcx
  72d1a9:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  72d1ae:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  72d1b3:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  72d1b8:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  72d1bf:	00 
  72d1c0:	eb 4b                	jmp    72d20d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x23d>
  72d1c2:	4c 89 ed             	mov    %r13,%rbp
  72d1c5:	4c 89 c6             	mov    %r8,%rsi
  72d1c8:	49 29 f4             	sub    %rsi,%r12
  72d1cb:	48 89 ef             	mov    %rbp,%rdi
  72d1ce:	4c 89 e2             	mov    %r12,%rdx
  72d1d1:	ff 15 19 ab 3b 00    	call   *0x3bab19(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72d1d7:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  72d1de:	00 
  72d1df:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d1e4:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72d1e9:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72d1ee:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72d1f3:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  72d1fa:	00 
  72d1fb:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
  72d202:	00 
  72d203:	49 83 f9 01          	cmp    $0x1,%r9
  72d207:	0f 86 23 02 00 00    	jbe    72d430 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x460>
  72d20d:	42 38 bc 0c 95 00 00 	cmp    %dil,0x95(%rsp,%r9,1)
  72d214:	00 
  72d215:	0f 82 1b 02 00 00    	jb     72d436 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  72d21b:	49 ff c9             	dec    %r9
  72d21e:	4a 8b 84 cc d8 00 00 	mov    0xd8(%rsp,%r9,8),%rax
  72d225:	00 
  72d226:	48 89 c3             	mov    %rax,%rbx
  72d229:	48 d1 eb             	shr    $1,%rbx
  72d22c:	4d 89 e7             	mov    %r12,%r15
  72d22f:	49 d1 ef             	shr    $1,%r15
  72d232:	4e 8d 34 3b          	lea    (%rbx,%r15,1),%r14
  72d236:	4d 39 ee             	cmp    %r13,%r14
  72d239:	77 25                	ja     72d260 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x290>
  72d23b:	89 c1                	mov    %eax,%ecx
  72d23d:	44 09 e1             	or     %r12d,%ecx
  72d240:	83 e1 01             	and    $0x1,%ecx
  72d243:	75 1b                	jne    72d260 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x290>
  72d245:	4d 01 f6             	add    %r14,%r14
  72d248:	4d 89 f4             	mov    %r14,%r12
  72d24b:	49 83 f9 01          	cmp    $0x1,%r9
  72d24f:	77 bc                	ja     72d20d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x23d>
  72d251:	e9 da 01 00 00       	jmp    72d430 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x460>
  72d256:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72d25d:	00 00 00 
  72d260:	4c 29 f5             	sub    %r14,%rbp
  72d263:	48 c1 e5 04          	shl    $0x4,%rbp
  72d267:	48 03 6c 24 10       	add    0x10(%rsp),%rbp
  72d26c:	a8 01                	test   $0x1,%al
  72d26e:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  72d273:	75 5b                	jne    72d2d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x300>
  72d275:	48 89 d8             	mov    %rbx,%rax
  72d278:	48 83 c8 01          	or     $0x1,%rax
  72d27c:	4c 0f bd c0          	bsr    %rax,%r8
  72d280:	41 83 f0 3f          	xor    $0x3f,%r8d
  72d284:	45 01 c0             	add    %r8d,%r8d
  72d287:	41 83 f0 7e          	xor    $0x7e,%r8d
  72d28b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72d290:	48 89 04 24          	mov    %rax,(%rsp)
  72d294:	48 89 ef             	mov    %rbp,%rdi
  72d297:	48 89 de             	mov    %rbx,%rsi
  72d29a:	4c 89 e9             	mov    %r13,%rcx
  72d29d:	45 31 c9             	xor    %r9d,%r9d
  72d2a0:	e8 2b 21 00 00       	call   72f3d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72d2a5:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72d2aa:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72d2af:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72d2b4:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d2b9:	41 f6 c4 01          	test   $0x1,%r12b
  72d2bd:	74 17                	je     72d2d6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x306>
  72d2bf:	4d 85 ff             	test   %r15,%r15
  72d2c2:	75 66                	jne    72d32a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x35a>
  72d2c4:	e9 2a ff ff ff       	jmp    72d1f3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  72d2c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72d2d0:	41 f6 c4 01          	test   $0x1,%r12b
  72d2d4:	75 e9                	jne    72d2bf <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x2ef>
  72d2d6:	48 89 df             	mov    %rbx,%rdi
  72d2d9:	48 c1 e7 04          	shl    $0x4,%rdi
  72d2dd:	48 01 ef             	add    %rbp,%rdi
  72d2e0:	4c 89 f8             	mov    %r15,%rax
  72d2e3:	48 83 c8 01          	or     $0x1,%rax
  72d2e7:	4c 0f bd c0          	bsr    %rax,%r8
  72d2eb:	41 83 f0 3f          	xor    $0x3f,%r8d
  72d2ef:	45 01 c0             	add    %r8d,%r8d
  72d2f2:	41 83 f0 7e          	xor    $0x7e,%r8d
  72d2f6:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72d2fb:	48 89 04 24          	mov    %rax,(%rsp)
  72d2ff:	4c 89 fe             	mov    %r15,%rsi
  72d302:	4c 89 e9             	mov    %r13,%rcx
  72d305:	45 31 c9             	xor    %r9d,%r9d
  72d308:	e8 c3 20 00 00       	call   72f3d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72d30d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72d312:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72d317:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72d31c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d321:	4d 85 ff             	test   %r15,%r15
  72d324:	0f 84 c9 fe ff ff    	je     72d1f3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  72d32a:	48 85 db             	test   %rbx,%rbx
  72d32d:	0f 84 c0 fe ff ff    	je     72d1f3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  72d333:	49 39 df             	cmp    %rbx,%r15
  72d336:	49 89 dc             	mov    %rbx,%r12
  72d339:	4d 0f 42 e7          	cmovb  %r15,%r12
  72d33d:	4d 39 e5             	cmp    %r12,%r13
  72d340:	0f 82 ad fe ff ff    	jb     72d1f3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  72d346:	49 89 dd             	mov    %rbx,%r13
  72d349:	49 c1 e5 04          	shl    $0x4,%r13
  72d34d:	49 01 ed             	add    %rbp,%r13
  72d350:	4c 39 fb             	cmp    %r15,%rbx
  72d353:	48 89 ee             	mov    %rbp,%rsi
  72d356:	49 0f 47 f5          	cmova  %r13,%rsi
  72d35a:	49 c1 e4 04          	shl    $0x4,%r12
  72d35e:	48 89 d7             	mov    %rdx,%rdi
  72d361:	4c 89 e2             	mov    %r12,%rdx
  72d364:	ff 15 86 a9 3b 00    	call   *0x3ba986(%rip)        # ae7cf0 <memcpy@GLIBC_2.14>
  72d36a:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  72d36f:	4d 01 c4             	add    %r8,%r12
  72d372:	4c 39 fb             	cmp    %r15,%rbx
  72d375:	76 5c                	jbe    72d3d3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x403>
  72d377:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  72d37c:	0f 1f 40 00          	nopl   0x0(%rax)
  72d380:	49 8d 4d f0          	lea    -0x10(%r13),%rcx
  72d384:	49 8b 54 24 f0       	mov    -0x10(%r12),%rdx
  72d389:	31 f6                	xor    %esi,%esi
  72d38b:	31 ff                	xor    %edi,%edi
  72d38d:	49 3b 55 f0          	cmp    -0x10(%r13),%rdx
  72d391:	49 8d 54 24 f0       	lea    -0x10(%r12),%rdx
  72d396:	40 0f 92 c6          	setb   %sil
  72d39a:	48 0f 42 d1          	cmovb  %rcx,%rdx
  72d39e:	40 0f 93 c7          	setae  %dil
  72d3a2:	0f 10 02             	movups (%rdx),%xmm0
  72d3a5:	0f 11 00             	movups %xmm0,(%rax)
  72d3a8:	c1 e7 04             	shl    $0x4,%edi
  72d3ab:	49 01 fd             	add    %rdi,%r13
  72d3ae:	49 83 c5 f0          	add    $0xfffffffffffffff0,%r13
  72d3b2:	c1 e6 04             	shl    $0x4,%esi
  72d3b5:	49 01 f4             	add    %rsi,%r12
  72d3b8:	49 83 c4 f0          	add    $0xfffffffffffffff0,%r12
  72d3bc:	49 39 ed             	cmp    %rbp,%r13
  72d3bf:	0f 84 fd fd ff ff    	je     72d1c2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f2>
  72d3c5:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  72d3c9:	4d 39 c4             	cmp    %r8,%r12
  72d3cc:	75 b2                	jne    72d380 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x3b0>
  72d3ce:	e9 ef fd ff ff       	jmp    72d1c2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f2>
  72d3d3:	4c 89 c6             	mov    %r8,%rsi
  72d3d6:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  72d3db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72d3e0:	48 89 f2             	mov    %rsi,%rdx
  72d3e3:	49 8b 4d 00          	mov    0x0(%r13),%rcx
  72d3e7:	31 c0                	xor    %eax,%eax
  72d3e9:	31 f6                	xor    %esi,%esi
  72d3eb:	48 3b 0a             	cmp    (%rdx),%rcx
  72d3ee:	0f 92 c1             	setb   %cl
  72d3f1:	40 0f 93 c6          	setae  %sil
  72d3f5:	48 89 d7             	mov    %rdx,%rdi
  72d3f8:	49 0f 42 fd          	cmovb  %r13,%rdi
  72d3fc:	0f 10 07             	movups (%rdi),%xmm0
  72d3ff:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
  72d403:	c1 e6 04             	shl    $0x4,%esi
  72d406:	48 01 d6             	add    %rdx,%rsi
  72d409:	48 83 c5 10          	add    $0x10,%rbp
  72d40d:	4c 39 e6             	cmp    %r12,%rsi
  72d410:	0f 84 b2 fd ff ff    	je     72d1c8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f8>
  72d416:	88 c8                	mov    %cl,%al
  72d418:	c1 e0 04             	shl    $0x4,%eax
  72d41b:	49 01 c5             	add    %rax,%r13
  72d41e:	4d 39 c5             	cmp    %r8,%r13
  72d421:	75 bd                	jne    72d3e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x410>
  72d423:	e9 a0 fd ff ff       	jmp    72d1c8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f8>
  72d428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72d42f:	00 
  72d430:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  72d436:	4e 89 a4 cc d8 00 00 	mov    %r12,0xd8(%rsp,%r9,8)
  72d43d:	00 
  72d43e:	42 88 bc 0c 96 00 00 	mov    %dil,0x96(%rsp,%r9,1)
  72d445:	00 
  72d446:	48 39 6c 24 28       	cmp    %rbp,0x28(%rsp)
  72d44b:	0f 86 b3 01 00 00    	jbe    72d604 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x634>
  72d451:	49 ff c1             	inc    %r9
  72d454:	48 89 f0             	mov    %rsi,%rax
  72d457:	48 d1 e8             	shr    $1,%rax
  72d45a:	48 01 c5             	add    %rax,%rbp
  72d45d:	49 89 f4             	mov    %rsi,%r12
  72d460:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72d465:	48 29 ee             	sub    %rbp,%rsi
  72d468:	0f 87 52 fc ff ff    	ja     72d0c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xf0>
  72d46e:	e9 2d fc ff ff       	jmp    72d0a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xd0>
  72d473:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72d47a:	84 00 00 00 00 00 
  72d480:	4c 8b 1f             	mov    (%rdi),%r11
  72d483:	4c 8b 77 10          	mov    0x10(%rdi),%r14
  72d487:	4d 39 de             	cmp    %r11,%r14
  72d48a:	49 89 f7             	mov    %rsi,%r15
  72d48d:	73 15                	jae    72d4a4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x4d4>
  72d48f:	48 83 fe 02          	cmp    $0x2,%rsi
  72d493:	75 54                	jne    72d4e9 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x519>
  72d495:	b8 02 00 00 00       	mov    $0x2,%eax
  72d49a:	be 01 00 00 00       	mov    $0x1,%esi
  72d49f:	e9 af 00 00 00       	jmp    72d553 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x583>
  72d4a4:	b8 02 00 00 00       	mov    $0x2,%eax
  72d4a9:	48 83 fe 02          	cmp    $0x2,%rsi
  72d4ad:	0f 84 7a fc ff ff    	je     72d12d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d4b3:	4c 89 cb             	mov    %r9,%rbx
  72d4b6:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72d4bb:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  72d4bf:	b8 02 00 00 00       	mov    $0x2,%eax
  72d4c4:	4d 89 f1             	mov    %r14,%r9
  72d4c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72d4ce:	00 00 
  72d4d0:	4d 89 ca             	mov    %r9,%r10
  72d4d3:	4d 8b 08             	mov    (%r8),%r9
  72d4d6:	4d 39 d1             	cmp    %r10,%r9
  72d4d9:	72 52                	jb     72d52d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x55d>
  72d4db:	48 ff c0             	inc    %rax
  72d4de:	49 83 c0 10          	add    $0x10,%r8
  72d4e2:	49 39 c7             	cmp    %rax,%r15
  72d4e5:	75 e9                	jne    72d4d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x500>
  72d4e7:	eb 2e                	jmp    72d517 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x547>
  72d4e9:	4c 89 cb             	mov    %r9,%rbx
  72d4ec:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72d4f1:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  72d4f5:	b8 02 00 00 00       	mov    $0x2,%eax
  72d4fa:	4d 89 f1             	mov    %r14,%r9
  72d4fd:	0f 1f 00             	nopl   (%rax)
  72d500:	4d 89 ca             	mov    %r9,%r10
  72d503:	4d 8b 08             	mov    (%r8),%r9
  72d506:	4d 39 d1             	cmp    %r10,%r9
  72d509:	73 22                	jae    72d52d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x55d>
  72d50b:	48 ff c0             	inc    %rax
  72d50e:	49 83 c0 10          	add    $0x10,%r8
  72d512:	49 39 c7             	cmp    %rax,%r15
  72d515:	75 e9                	jne    72d500 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x530>
  72d517:	4c 89 fe             	mov    %r15,%rsi
  72d51a:	4c 89 f8             	mov    %r15,%rax
  72d51d:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  72d522:	49 89 d9             	mov    %rbx,%r9
  72d525:	0f 82 ac fb ff ff    	jb     72d0d7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x107>
  72d52b:	eb 11                	jmp    72d53e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x56e>
  72d52d:	4c 89 fe             	mov    %r15,%rsi
  72d530:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  72d535:	49 89 d9             	mov    %rbx,%r9
  72d538:	0f 82 99 fb ff ff    	jb     72d0d7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x107>
  72d53e:	4d 39 de             	cmp    %r11,%r14
  72d541:	0f 83 e6 fb ff ff    	jae    72d12d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d547:	48 89 c6             	mov    %rax,%rsi
  72d54a:	48 d1 ee             	shr    $1,%rsi
  72d54d:	0f 84 da fb ff ff    	je     72d12d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d553:	49 89 c0             	mov    %rax,%r8
  72d556:	49 c1 e0 04          	shl    $0x4,%r8
  72d55a:	4a 8d 1c 07          	lea    (%rdi,%r8,1),%rbx
  72d55e:	48 83 fe 01          	cmp    $0x1,%rsi
  72d562:	75 04                	jne    72d568 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x598>
  72d564:	31 c9                	xor    %ecx,%ecx
  72d566:	eb 79                	jmp    72d5e1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x611>
  72d568:	4d 89 ce             	mov    %r9,%r14
  72d56b:	49 89 f1             	mov    %rsi,%r9
  72d56e:	49 83 e1 fe          	and    $0xfffffffffffffffe,%r9
  72d572:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  72d577:	4c 8d 14 0a          	lea    (%rdx,%rcx,1),%r10
  72d57b:	49 01 c8             	add    %rcx,%r8
  72d57e:	4c 03 44 24 58       	add    0x58(%rsp),%r8
  72d583:	31 c9                	xor    %ecx,%ecx
  72d585:	48 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%rdx
  72d58c:	ff ff 0f 
  72d58f:	90                   	nop
  72d590:	41 0f 10 42 f0       	movups -0x10(%r10),%xmm0
  72d595:	41 0f 10 08          	movups (%r8),%xmm1
  72d599:	41 0f 11 4a f0       	movups %xmm1,-0x10(%r10)
  72d59e:	41 0f 11 00          	movups %xmm0,(%r8)
  72d5a2:	49 89 cb             	mov    %rcx,%r11
  72d5a5:	49 31 d3             	xor    %rdx,%r11
  72d5a8:	49 c1 e3 04          	shl    $0x4,%r11
  72d5ac:	41 0f 10 02          	movups (%r10),%xmm0
  72d5b0:	42 0f 10 0c 1b       	movups (%rbx,%r11,1),%xmm1
  72d5b5:	41 0f 11 0a          	movups %xmm1,(%r10)
  72d5b9:	42 0f 11 04 1b       	movups %xmm0,(%rbx,%r11,1)
  72d5be:	48 83 c1 02          	add    $0x2,%rcx
  72d5c2:	49 83 c2 20          	add    $0x20,%r10
  72d5c6:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
  72d5ca:	49 39 c9             	cmp    %rcx,%r9
  72d5cd:	75 c1                	jne    72d590 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x5c0>
  72d5cf:	40 f6 c6 01          	test   $0x1,%sil
  72d5d3:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d5d8:	4d 89 f1             	mov    %r14,%r9
  72d5db:	0f 84 4c fb ff ff    	je     72d12d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d5e1:	48 89 ce             	mov    %rcx,%rsi
  72d5e4:	48 f7 d6             	not    %rsi
  72d5e7:	48 c1 e1 04          	shl    $0x4,%rcx
  72d5eb:	48 c1 e6 04          	shl    $0x4,%rsi
  72d5ef:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  72d5f3:	0f 10 0c 33          	movups (%rbx,%rsi,1),%xmm1
  72d5f7:	0f 11 0c 0f          	movups %xmm1,(%rdi,%rcx,1)
  72d5fb:	0f 11 04 33          	movups %xmm0,(%rbx,%rsi,1)
  72d5ff:	e9 29 fb ff ff       	jmp    72d12d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d604:	41 f6 c4 01          	test   $0x1,%r12b
  72d608:	75 34                	jne    72d63e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x66e>
  72d60a:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72d60f:	48 89 f0             	mov    %rsi,%rax
  72d612:	48 83 c8 01          	or     $0x1,%rax
  72d616:	4c 0f bd c0          	bsr    %rax,%r8
  72d61a:	41 83 f0 3f          	xor    $0x3f,%r8d
  72d61e:	45 01 c0             	add    %r8d,%r8d
  72d621:	41 83 f0 7e          	xor    $0x7e,%r8d
  72d625:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72d62a:	48 89 04 24          	mov    %rax,(%rsp)
  72d62e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  72d633:	4c 89 e9             	mov    %r13,%rcx
  72d636:	45 31 c9             	xor    %r9d,%r9d
  72d639:	e8 92 1d 00 00       	call   72f3d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72d63e:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
  72d645:	5b                   	pop    %rbx
  72d646:	41 5c                	pop    %r12
  72d648:	41 5d                	pop    %r13
  72d64a:	41 5e                	pop    %r14
  72d64c:	41 5f                	pop    %r15
  72d64e:	5d                   	pop    %rbp
  72d64f:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
