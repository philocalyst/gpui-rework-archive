
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006f6390 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0EB28_>:
  6f6390:	48 83 ec 18          	sub    $0x18,%rsp
  6f6394:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  6f6399:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f639e:	48 83 fe 02          	cmp    $0x2,%rsi
  6f63a2:	73 05                	jae    6f63a9 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0EB28_+0x19>
  6f63a4:	48 83 c4 18          	add    $0x18,%rsp
  6f63a8:	c3                   	ret
  6f63a9:	48 83 fe 15          	cmp    $0x15,%rsi
  6f63ad:	73 14                	jae    6f63c3 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0EB28_+0x33>
  6f63af:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
  6f63b4:	ba 01 00 00 00       	mov    $0x1,%edx
  6f63b9:	e8 72 ce 01 00       	call   713230 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB3f_>
  6f63be:	48 83 c4 18          	add    $0x18,%rsp
  6f63c2:	c3                   	ret
  6f63c3:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  6f63c8:	e8 73 7d 03 00       	call   72e140 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersF_0E0EB2J_>
  6f63cd:	48 83 c4 18          	add    $0x18,%rsp
  6f63d1:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
