
/tmp/gpui-sibling-controls/candidate:     file format elf64-x86-64


Disassembly of section .text:

000000000072db50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_>:
  72db50:	48 89 f0             	mov    %rsi,%rax
  72db53:	48 d1 e8             	shr    $1,%rax
  72db56:	48 01 f0             	add    %rsi,%rax
  72db59:	75 0a                	jne    72db65 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x15>
  72db5b:	c3                   	ret
  72db5c:	0f 1f 40 00          	nopl   0x0(%rax)
  72db60:	48 85 c0             	test   %rax,%rax
  72db63:	74 f6                	je     72db5b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0xb>
  72db65:	48 ff c8             	dec    %rax
  72db68:	48 89 c2             	mov    %rax,%rdx
  72db6b:	48 29 f2             	sub    %rsi,%rdx
  72db6e:	73 3a                	jae    72dbaa <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x5a>
  72db70:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  72db74:	48 8b 57 10          	mov    0x10(%rdi),%rdx
  72db78:	48 89 54 24 f8       	mov    %rdx,-0x8(%rsp)
  72db7d:	0f 10 07             	movups (%rdi),%xmm0
  72db80:	0f 29 44 24 e8       	movaps %xmm0,-0x18(%rsp)
  72db85:	48 8b 54 cf 10       	mov    0x10(%rdi,%rcx,8),%rdx
  72db8a:	0f 10 04 cf          	movups (%rdi,%rcx,8),%xmm0
  72db8e:	0f 11 07             	movups %xmm0,(%rdi)
  72db91:	48 89 57 10          	mov    %rdx,0x10(%rdi)
  72db95:	48 8b 54 24 f8       	mov    -0x8(%rsp),%rdx
  72db9a:	48 89 54 cf 10       	mov    %rdx,0x10(%rdi,%rcx,8)
  72db9f:	0f 28 44 24 e8       	movaps -0x18(%rsp),%xmm0
  72dba4:	0f 11 04 cf          	movups %xmm0,(%rdi,%rcx,8)
  72dba8:	31 d2                	xor    %edx,%edx
  72dbaa:	48 39 c6             	cmp    %rax,%rsi
  72dbad:	48 89 c1             	mov    %rax,%rcx
  72dbb0:	48 0f 42 ce          	cmovb  %rsi,%rcx
  72dbb4:	4c 8d 04 55 01 00 00 	lea    0x1(,%rdx,2),%r8
  72dbbb:	00 
  72dbbc:	49 39 c8             	cmp    %rcx,%r8
  72dbbf:	73 9f                	jae    72db60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x10>
  72dbc1:	4c 8d 14 12          	lea    (%rdx,%rdx,1),%r10
  72dbc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72dbcc:	00 00 00 00 
  72dbd0:	49 83 c2 02          	add    $0x2,%r10
  72dbd4:	49 39 ca             	cmp    %rcx,%r10
  72dbd7:	73 14                	jae    72dbed <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x9d>
  72dbd9:	4f 8d 0c 40          	lea    (%r8,%r8,2),%r9
  72dbdd:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  72dbe1:	4e 8b 0c cf          	mov    (%rdi,%r9,8),%r9
  72dbe5:	4e 3b 0c d7          	cmp    (%rdi,%r10,8),%r9
  72dbe9:	49 83 d0 00          	adc    $0x0,%r8
  72dbed:	4d 89 c1             	mov    %r8,%r9
  72dbf0:	4c 8d 04 52          	lea    (%rdx,%rdx,2),%r8
  72dbf4:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  72dbf8:	4a 8b 14 c7          	mov    (%rdi,%r8,8),%rdx
  72dbfc:	4e 8b 1c d7          	mov    (%rdi,%r10,8),%r11
  72dc00:	4c 39 da             	cmp    %r11,%rdx
  72dc03:	0f 83 57 ff ff ff    	jae    72db60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x10>
  72dc09:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
  72dc0d:	4e 8d 14 d7          	lea    (%rdi,%r10,8),%r10
  72dc11:	4d 89 18             	mov    %r11,(%r8)
  72dc14:	49 89 12             	mov    %rdx,(%r10)
  72dc17:	41 0f 10 40 08       	movups 0x8(%r8),%xmm0
  72dc1c:	41 0f 10 4a 08       	movups 0x8(%r10),%xmm1
  72dc21:	41 0f 11 48 08       	movups %xmm1,0x8(%r8)
  72dc26:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  72dc2b:	4f 8d 14 09          	lea    (%r9,%r9,1),%r10
  72dc2f:	4e 8d 04 4d 01 00 00 	lea    0x1(,%r9,2),%r8
  72dc36:	00 
  72dc37:	4c 89 ca             	mov    %r9,%rdx
  72dc3a:	49 39 c8             	cmp    %rcx,%r8
  72dc3d:	72 91                	jb     72dbd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x80>
  72dc3f:	e9 1c ff ff ff       	jmp    72db60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x10>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
