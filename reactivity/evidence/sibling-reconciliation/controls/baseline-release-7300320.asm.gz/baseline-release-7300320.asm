
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006f64e0 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersB_0EB2U_>:
  6f64e0:	41 56                	push   %r14
  6f64e2:	53                   	push   %rbx
  6f64e3:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
  6f64ea:	48 83 3f 00          	cmpq   $0x0,(%rdi)
  6f64ee:	0f 85 c3 00 00 00    	jne    6f65b7 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersB_0EB2U_+0xd7>
  6f64f4:	49 89 fe             	mov    %rdi,%r14
  6f64f7:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
  6f64fe:	00 00 00 00 00 
  6f6503:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f6506:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f650d:	00 
  6f650e:	48 c7 84 24 c8 00 00 	movq   $0x8,0xc8(%rsp)
  6f6515:	00 08 00 00 00 
  6f651a:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  6f6521:	00 00 00 00 00 
  6f6526:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  6f652d:	00 00 00 00 00 
  6f6532:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
  6f6539:	00 
  6f653a:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  6f6541:	00 
  6f6542:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  6f6549:	00 00 
  6f654b:	48 c7 44 24 20 08 00 	movq   $0x8,0x20(%rsp)
  6f6552:	00 00 
  6f6554:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
  6f6559:	48 c7 44 24 38 08 00 	movq   $0x8,0x38(%rsp)
  6f6560:	00 00 
  6f6562:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
  6f6567:	48 c7 44 24 50 08 00 	movq   $0x8,0x50(%rsp)
  6f656e:	00 00 
  6f6570:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f6577:	00 00 
  6f6579:	48 c7 44 24 60 ff ff 	movq   $0xffffffffffffffff,0x60(%rsp)
  6f6580:	ff ff 
  6f6582:	ff 15 50 43 3f 00    	call   *0x3f4350(%rip)        # aea8d8 <_DYNAMIC+0x260>
  6f6588:	bf 08 01 00 00       	mov    $0x108,%edi
  6f658d:	be 08 00 00 00       	mov    $0x8,%esi
  6f6592:	ff 15 20 43 3f 00    	call   *0x3f4320(%rip)        # aea8b8 <_DYNAMIC+0x240>
  6f6598:	48 85 c0             	test   %rax,%rax
  6f659b:	74 28                	je     6f65c5 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersB_0EB2U_+0xe5>
  6f659d:	48 89 c3             	mov    %rax,%rbx
  6f65a0:	48 89 e6             	mov    %rsp,%rsi
  6f65a3:	ba 08 01 00 00       	mov    $0x108,%edx
  6f65a8:	48 89 c7             	mov    %rax,%rdi
  6f65ab:	ff 15 37 43 3f 00    	call   *0x3f4337(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  6f65b1:	4c 89 f7             	mov    %r14,%rdi
  6f65b4:	49 89 1e             	mov    %rbx,(%r14)
  6f65b7:	48 89 f8             	mov    %rdi,%rax
  6f65ba:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
  6f65c1:	5b                   	pop    %rbx
  6f65c2:	41 5e                	pop    %r14
  6f65c4:	c3                   	ret
  6f65c5:	bf 08 00 00 00       	mov    $0x8,%edi
  6f65ca:	be 08 01 00 00       	mov    $0x108,%esi
  6f65cf:	ff 15 1b 43 3f 00    	call   *0x3f431b(%rip)        # aea8f0 <_DYNAMIC+0x278>
  6f65d5:	0f 0b                	ud2
  6f65d7:	48 89 c3             	mov    %rax,%rbx
  6f65da:	48 89 e7             	mov    %rsp,%rdi
  6f65dd:	e8 3e 52 00 00       	call   6fb820 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f65e2:	48 89 df             	mov    %rbx,%rdi
  6f65e5:	e8 b6 4a 3c 00       	call   abb0a0 <_Unwind_Resume@plt>
  6f65ea:	ff 15 20 43 3f 00    	call   *0x3f4320(%rip)        # aea910 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
