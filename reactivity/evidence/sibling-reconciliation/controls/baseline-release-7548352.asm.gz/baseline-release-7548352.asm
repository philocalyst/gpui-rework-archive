
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

0000000000732dc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_>:
  732dc0:	48 89 f0             	mov    %rsi,%rax
  732dc3:	48 d1 e8             	shr    $1,%rax
  732dc6:	48 01 f0             	add    %rsi,%rax
  732dc9:	75 0a                	jne    732dd5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x15>
  732dcb:	c3                   	ret
  732dcc:	0f 1f 40 00          	nopl   0x0(%rax)
  732dd0:	48 85 c0             	test   %rax,%rax
  732dd3:	74 f6                	je     732dcb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0xb>
  732dd5:	48 ff c8             	dec    %rax
  732dd8:	48 89 c1             	mov    %rax,%rcx
  732ddb:	48 29 f1             	sub    %rsi,%rcx
  732dde:	73 0c                	jae    732dec <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x2c>
  732de0:	8b 0f                	mov    (%rdi),%ecx
  732de2:	8b 14 87             	mov    (%rdi,%rax,4),%edx
  732de5:	89 17                	mov    %edx,(%rdi)
  732de7:	89 0c 87             	mov    %ecx,(%rdi,%rax,4)
  732dea:	31 c9                	xor    %ecx,%ecx
  732dec:	48 39 c6             	cmp    %rax,%rsi
  732def:	48 89 c2             	mov    %rax,%rdx
  732df2:	48 0f 42 d6          	cmovb  %rsi,%rdx
  732df6:	4c 8d 04 4d 01 00 00 	lea    0x1(,%rcx,2),%r8
  732dfd:	00 
  732dfe:	49 39 d0             	cmp    %rdx,%r8
  732e01:	73 cd                	jae    732dd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>
  732e03:	4c 8d 0c 09          	lea    (%rcx,%rcx,1),%r9
  732e07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  732e0e:	00 00 
  732e10:	4d 8d 51 02          	lea    0x2(%r9),%r10
  732e14:	49 39 d2             	cmp    %rdx,%r10
  732e17:	73 0d                	jae    732e26 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x66>
  732e19:	46 8b 14 87          	mov    (%rdi,%r8,4),%r10d
  732e1d:	46 3b 54 8f 08       	cmp    0x8(%rdi,%r9,4),%r10d
  732e22:	49 83 d0 00          	adc    $0x0,%r8
  732e26:	4d 89 c2             	mov    %r8,%r10
  732e29:	44 8b 04 8f          	mov    (%rdi,%rcx,4),%r8d
  732e2d:	46 8b 0c 97          	mov    (%rdi,%r10,4),%r9d
  732e31:	45 39 c8             	cmp    %r9d,%r8d
  732e34:	73 9a                	jae    732dd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>
  732e36:	44 89 0c 8f          	mov    %r9d,(%rdi,%rcx,4)
  732e3a:	46 89 04 97          	mov    %r8d,(%rdi,%r10,4)
  732e3e:	4f 8d 0c 12          	lea    (%r10,%r10,1),%r9
  732e42:	4e 8d 04 55 01 00 00 	lea    0x1(,%r10,2),%r8
  732e49:	00 
  732e4a:	4c 89 d1             	mov    %r10,%rcx
  732e4d:	49 39 d0             	cmp    %rdx,%r8
  732e50:	72 be                	jb     732e10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x50>
  732e52:	e9 79 ff ff ff       	jmp    732dd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
