
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

00000000006ebee0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_>:
  6ebee0:	53                   	push   %rbx
  6ebee1:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  6ebee8:	48 89 fb             	mov    %rdi,%rbx
  6ebeeb:	48 8b 06             	mov    (%rsi),%rax
  6ebeee:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6ebef2:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6ebef6:	48 85 ff             	test   %rdi,%rdi
  6ebef9:	0f 84 e3 01 00 00    	je     6ec0e2 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x202>
  6ebeff:	48 8b 8c c8 c8 01 00 	mov    0x1c8(%rax,%rcx,8),%rcx
  6ebf06:	00 
  6ebf07:	48 89 f8             	mov    %rdi,%rax
  6ebf0a:	48 ff c8             	dec    %rax
  6ebf0d:	0f 84 cb 00 00 00    	je     6ebfde <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0xfe>
  6ebf13:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6ebf17:	48 89 c6             	mov    %rax,%rsi
  6ebf1a:	48 83 e6 07          	and    $0x7,%rsi
  6ebf1e:	74 2b                	je     6ebf4b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x6b>
  6ebf20:	45 31 c0             	xor    %r8d,%r8d
  6ebf23:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ebf2a:	84 00 00 00 00 00 
  6ebf30:	44 0f b7 89 c2 01 00 	movzwl 0x1c2(%rcx),%r9d
  6ebf37:	00 
  6ebf38:	4a 8b 8c c9 c8 01 00 	mov    0x1c8(%rcx,%r9,8),%rcx
  6ebf3f:	00 
  6ebf40:	49 ff c0             	inc    %r8
  6ebf43:	4c 39 c6             	cmp    %r8,%rsi
  6ebf46:	75 e8                	jne    6ebf30 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x50>
  6ebf48:	4c 29 c0             	sub    %r8,%rax
  6ebf4b:	48 83 ff 07          	cmp    $0x7,%rdi
  6ebf4f:	0f 82 89 00 00 00    	jb     6ebfde <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0xfe>
  6ebf55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6ebf5c:	00 00 00 00 
  6ebf60:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebf67:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebf6e:	00 
  6ebf6f:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebf76:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebf7d:	00 
  6ebf7e:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebf85:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebf8c:	00 
  6ebf8d:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebf94:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebf9b:	00 
  6ebf9c:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebfa3:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebfaa:	00 
  6ebfab:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebfb2:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebfb9:	00 
  6ebfba:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebfc1:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebfc8:	00 
  6ebfc9:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebfd0:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebfd7:	00 
  6ebfd8:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6ebfdc:	75 82                	jne    6ebf60 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x80>
  6ebfde:	0f b7 81 c2 01 00 00 	movzwl 0x1c2(%rcx),%eax
  6ebfe5:	48 ff c8             	dec    %rax
  6ebfe8:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6ebfed:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6ebff4:	00 00 
  6ebff6:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6ebffb:	48 89 e7             	mov    %rsp,%rdi
  6ebffe:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6ec003:	e8 78 78 00 00       	call   6f3880 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>
  6ec008:	48 8b 3c 24          	mov    (%rsp),%rdi
  6ec00c:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6ec011:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6ec016:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6ec01b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  6ec020:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6ec025:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6ec02a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6ec02f:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  6ec036:	48 39 ce             	cmp    %rcx,%rsi
  6ec039:	72 1f                	jb     6ec05a <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x17a>
  6ec03b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ec040:	0f b7 b0 c0 01 00 00 	movzwl 0x1c0(%rax),%esi
  6ec047:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6ec04e:	48 ff c2             	inc    %rdx
  6ec051:	66 3b b0 c2 01 00 00 	cmp    0x1c2(%rax),%si
  6ec058:	73 e6                	jae    6ec040 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x160>
  6ec05a:	49 89 f0             	mov    %rsi,%r8
  6ec05d:	49 c1 e0 05          	shl    $0x5,%r8
  6ec061:	48 8b 8c f0 68 01 00 	mov    0x168(%rax,%rsi,8),%rcx
  6ec068:	00 
  6ec069:	48 89 bc f0 68 01 00 	mov    %rdi,0x168(%rax,%rsi,8)
  6ec070:	00 
  6ec071:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6ec076:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6ec07c:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6ec081:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6ec085:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6ec08a:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6ec08f:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6ec094:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6ec09a:	48 85 d2             	test   %rdx,%rdx
  6ec09d:	74 6c                	je     6ec10b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x22b>
  6ec09f:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  6ec0a3:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6ec0aa:	48 89 d6             	mov    %rdx,%rsi
  6ec0ad:	48 83 e6 07          	and    $0x7,%rsi
  6ec0b1:	74 5d                	je     6ec110 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x230>
  6ec0b3:	45 31 c9             	xor    %r9d,%r9d
  6ec0b6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6ec0bd:	00 00 00 
  6ec0c0:	48 8b 07             	mov    (%rdi),%rax
  6ec0c3:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6ec0ca:	49 ff c1             	inc    %r9
  6ec0cd:	4c 39 ce             	cmp    %r9,%rsi
  6ec0d0:	75 ee                	jne    6ec0c0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x1e0>
  6ec0d2:	49 89 d0             	mov    %rdx,%r8
  6ec0d5:	4d 29 c8             	sub    %r9,%r8
  6ec0d8:	31 f6                	xor    %esi,%esi
  6ec0da:	48 83 fa 08          	cmp    $0x8,%rdx
  6ec0de:	73 40                	jae    6ec120 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x240>
  6ec0e0:	eb 7f                	jmp    6ec161 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ec0e2:	48 89 04 24          	mov    %rax,(%rsp)
  6ec0e6:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6ec0ed:	00 00 
  6ec0ef:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6ec0f4:	48 89 e6             	mov    %rsp,%rsi
  6ec0f7:	48 89 df             	mov    %rbx,%rdi
  6ec0fa:	e8 81 77 00 00       	call   6f3880 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>
  6ec0ff:	48 89 d8             	mov    %rbx,%rax
  6ec102:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6ec109:	5b                   	pop    %rbx
  6ec10a:	c3                   	ret
  6ec10b:	48 ff c6             	inc    %rsi
  6ec10e:	eb 51                	jmp    6ec161 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ec110:	49 89 d0             	mov    %rdx,%r8
  6ec113:	31 f6                	xor    %esi,%esi
  6ec115:	48 83 fa 08          	cmp    $0x8,%rdx
  6ec119:	72 46                	jb     6ec161 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ec11b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ec120:	48 8b 07             	mov    (%rdi),%rax
  6ec123:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ec12a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ec131:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ec138:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ec13f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ec146:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ec14d:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ec154:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6ec15b:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6ec15f:	75 bf                	jne    6ec120 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x240>
  6ec161:	48 89 0b             	mov    %rcx,(%rbx)
  6ec164:	0f 28 04 24          	movaps (%rsp),%xmm0
  6ec168:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6ec16d:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6ec171:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6ec175:	48 89 43 28          	mov    %rax,0x28(%rbx)
  6ec179:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
  6ec180:	00 
  6ec181:	48 89 73 38          	mov    %rsi,0x38(%rbx)
  6ec185:	48 89 d8             	mov    %rbx,%rax
  6ec188:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6ec18f:	5b                   	pop    %rbx
  6ec190:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
