
/tmp/gpui-sibling-controls/baseline-release:     file format elf64-x86-64


Disassembly of section .text:

000000000072a660 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>:
  72a660:	55                   	push   %rbp
  72a661:	41 57                	push   %r15
  72a663:	41 56                	push   %r14
  72a665:	41 55                	push   %r13
  72a667:	41 54                	push   %r12
  72a669:	53                   	push   %rbx
  72a66a:	48 83 ec 48          	sub    $0x48,%rsp
  72a66e:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  72a673:	48 89 cd             	mov    %rcx,%rbp
  72a676:	49 89 d7             	mov    %rdx,%r15
  72a679:	49 89 f5             	mov    %rsi,%r13
  72a67c:	49 89 fc             	mov    %rdi,%r12
  72a67f:	48 83 fe 21          	cmp    $0x21,%rsi
  72a683:	73 1e                	jae    72a6a3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x43>
  72a685:	4c 89 e7             	mov    %r12,%rdi
  72a688:	4c 89 ee             	mov    %r13,%rsi
  72a68b:	4c 89 fa             	mov    %r15,%rdx
  72a68e:	48 89 e9             	mov    %rbp,%rcx
  72a691:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  72a698:	00 
  72a699:	e8 72 92 fe ff       	call   713910 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_>
  72a69e:	e9 5f 04 00 00       	jmp    72ab02 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4a2>
  72a6a3:	45 89 c6             	mov    %r8d,%r14d
  72a6a6:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  72a6ab:	4c 89 eb             	mov    %r13,%rbx
  72a6ae:	66 90                	xchg   %ax,%ax
  72a6b0:	45 85 f6             	test   %r14d,%r14d
  72a6b3:	0f 84 2a 04 00 00    	je     72aae3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x483>
  72a6b9:	44 89 74 24 14       	mov    %r14d,0x14(%rsp)
  72a6be:	48 89 d9             	mov    %rbx,%rcx
  72a6c1:	48 c1 e9 03          	shr    $0x3,%rcx
  72a6c5:	4c 8d 34 49          	lea    (%rcx,%rcx,2),%r14
  72a6c9:	49 c1 e6 05          	shl    $0x5,%r14
  72a6cd:	4d 01 e6             	add    %r12,%r14
  72a6d0:	48 69 d1 a8 00 00 00 	imul   $0xa8,%rcx,%rdx
  72a6d7:	4c 01 e2             	add    %r12,%rdx
  72a6da:	48 83 fb 40          	cmp    $0x40,%rbx
  72a6de:	73 30                	jae    72a710 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0xb0>
  72a6e0:	49 8b 04 24          	mov    (%r12),%rax
  72a6e4:	49 8b 0e             	mov    (%r14),%rcx
  72a6e7:	48 39 c8             	cmp    %rcx,%rax
  72a6ea:	40 0f 92 c6          	setb   %sil
  72a6ee:	48 8b 3a             	mov    (%rdx),%rdi
  72a6f1:	48 39 f8             	cmp    %rdi,%rax
  72a6f4:	0f 92 c0             	setb   %al
  72a6f7:	40 30 f0             	xor    %sil,%al
  72a6fa:	48 39 f9             	cmp    %rdi,%rcx
  72a6fd:	0f 92 c1             	setb   %cl
  72a700:	40 30 f1             	xor    %sil,%cl
  72a703:	4c 0f 45 f2          	cmovne %rdx,%r14
  72a707:	84 c0                	test   %al,%al
  72a709:	4d 0f 45 f4          	cmovne %r12,%r14
  72a70d:	eb 0f                	jmp    72a71e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0xbe>
  72a70f:	90                   	nop
  72a710:	4c 89 e7             	mov    %r12,%rdi
  72a713:	4c 89 f6             	mov    %r14,%rsi
  72a716:	e8 95 f7 ff ff       	call   729eb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  72a71b:	49 89 c6             	mov    %rax,%r14
  72a71e:	ff 4c 24 14          	decl   0x14(%rsp)
  72a722:	4d 89 f2             	mov    %r14,%r10
  72a725:	4d 29 e2             	sub    %r12,%r10
  72a728:	49 c1 ea 03          	shr    $0x3,%r10
  72a72c:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
  72a733:	aa aa aa 
  72a736:	4c 0f af d0          	imul   %rax,%r10
  72a73a:	49 8b 46 10          	mov    0x10(%r14),%rax
  72a73e:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  72a743:	41 0f 10 06          	movups (%r14),%xmm0
  72a747:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  72a74c:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  72a752:	74 11                	je     72a765 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x105>
  72a754:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72a759:	48 8b 00             	mov    (%rax),%rax
  72a75c:	49 3b 06             	cmp    (%r14),%rax
  72a75f:	0f 83 db 01 00 00    	jae    72a940 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x2e0>
  72a765:	48 39 dd             	cmp    %rbx,%rbp
  72a768:	0f 82 b9 03 00 00    	jb     72ab27 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c7>
  72a76e:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
  72a772:	49 8d 2c c7          	lea    (%r15,%rax,8),%rbp
  72a776:	45 31 ed             	xor    %r13d,%r13d
  72a779:	4c 89 e0             	mov    %r12,%rax
  72a77c:	48 89 e9             	mov    %rbp,%rcx
  72a77f:	4c 89 d2             	mov    %r10,%rdx
  72a782:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72a789:	1f 84 00 00 00 00 00 
  72a790:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
  72a794:	49 8d 34 f4          	lea    (%r12,%rsi,8),%rsi
  72a798:	48 39 f0             	cmp    %rsi,%rax
  72a79b:	73 37                	jae    72a7d4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x174>
  72a79d:	0f 1f 00             	nopl   (%rax)
  72a7a0:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72a7a4:	48 8b 38             	mov    (%rax),%rdi
  72a7a7:	49 3b 3e             	cmp    (%r14),%rdi
  72a7aa:	48 8b 78 10          	mov    0x10(%rax),%rdi
  72a7ae:	49 89 c8             	mov    %rcx,%r8
  72a7b1:	4d 0f 42 c7          	cmovb  %r15,%r8
  72a7b5:	4f 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%r9
  72a7ba:	4b 89 7c c8 10       	mov    %rdi,0x10(%r8,%r9,8)
  72a7bf:	0f 10 00             	movups (%rax),%xmm0
  72a7c2:	43 0f 11 04 c8       	movups %xmm0,(%r8,%r9,8)
  72a7c7:	49 83 d5 00          	adc    $0x0,%r13
  72a7cb:	48 83 c0 18          	add    $0x18,%rax
  72a7cf:	48 39 f0             	cmp    %rsi,%rax
  72a7d2:	72 cc                	jb     72a7a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x140>
  72a7d4:	48 39 da             	cmp    %rbx,%rdx
  72a7d7:	74 37                	je     72a810 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x1b0>
  72a7d9:	4a 8d 14 6d 00 00 00 	lea    0x0(,%r13,2),%rdx
  72a7e0:	00 
  72a7e1:	4c 01 ea             	add    %r13,%rdx
  72a7e4:	48 8b 70 10          	mov    0x10(%rax),%rsi
  72a7e8:	48 89 74 d1 f8       	mov    %rsi,-0x8(%rcx,%rdx,8)
  72a7ed:	0f 10 00             	movups (%rax),%xmm0
  72a7f0:	0f 11 44 d1 e8       	movups %xmm0,-0x18(%rcx,%rdx,8)
  72a7f5:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72a7f9:	48 83 c0 18          	add    $0x18,%rax
  72a7fd:	48 89 da             	mov    %rbx,%rdx
  72a800:	eb 8e                	jmp    72a790 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x130>
  72a802:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72a809:	1f 84 00 00 00 00 00 
  72a810:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
  72a815:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
  72a81c:	00 
  72a81d:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
  72a821:	4c 89 e7             	mov    %r12,%rdi
  72a824:	4c 89 fe             	mov    %r15,%rsi
  72a827:	ff 15 bb 00 3c 00    	call   *0x3c00bb(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  72a82d:	49 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r10
  72a834:	ff ff 1f 
  72a837:	48 89 de             	mov    %rbx,%rsi
  72a83a:	4c 29 ee             	sub    %r13,%rsi
  72a83d:	0f 84 9f 00 00 00    	je     72a8e2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x282>
  72a843:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  72a84a:	00 
  72a84b:	4c 01 e8             	add    %r13,%rax
  72a84e:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
  72a852:	49 8d 4d 01          	lea    0x1(%r13),%rcx
  72a856:	48 39 cb             	cmp    %rcx,%rbx
  72a859:	75 05                	jne    72a860 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x200>
  72a85b:	31 d2                	xor    %edx,%edx
  72a85d:	eb 65                	jmp    72a8c4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x264>
  72a85f:	90                   	nop
  72a860:	48 89 f1             	mov    %rsi,%rcx
  72a863:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72a867:	49 8d 57 e8          	lea    -0x18(%r15),%rdx
  72a86b:	48 8d 3c 5b          	lea    (%rbx,%rbx,2),%rdi
  72a86f:	48 8d 3c fa          	lea    (%rdx,%rdi,8),%rdi
  72a873:	49 89 c0             	mov    %rax,%r8
  72a876:	31 d2                	xor    %edx,%edx
  72a878:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72a87f:	00 
  72a880:	49 89 d1             	mov    %rdx,%r9
  72a883:	48 8b 57 10          	mov    0x10(%rdi),%rdx
  72a887:	49 89 50 10          	mov    %rdx,0x10(%r8)
  72a88b:	0f 10 07             	movups (%rdi),%xmm0
  72a88e:	41 0f 11 00          	movups %xmm0,(%r8)
  72a892:	49 8d 51 02          	lea    0x2(%r9),%rdx
  72a896:	4d 31 d1             	xor    %r10,%r9
  72a899:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
  72a89d:	42 0f 10 44 cd 00    	movups 0x0(%rbp,%r9,8),%xmm0
  72a8a3:	41 0f 11 40 18       	movups %xmm0,0x18(%r8)
  72a8a8:	4e 8b 4c cd 10       	mov    0x10(%rbp,%r9,8),%r9
  72a8ad:	4d 89 48 28          	mov    %r9,0x28(%r8)
  72a8b1:	49 83 c0 30          	add    $0x30,%r8
  72a8b5:	48 83 c7 d0          	add    $0xffffffffffffffd0,%rdi
  72a8b9:	48 39 d1             	cmp    %rdx,%rcx
  72a8bc:	75 c2                	jne    72a880 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x220>
  72a8be:	40 f6 c6 01          	test   $0x1,%sil
  72a8c2:	74 1e                	je     72a8e2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x282>
  72a8c4:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  72a8c8:	48 f7 d2             	not    %rdx
  72a8cb:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  72a8cf:	48 8b 7c d5 10       	mov    0x10(%rbp,%rdx,8),%rdi
  72a8d4:	48 89 7c c8 10       	mov    %rdi,0x10(%rax,%rcx,8)
  72a8d9:	0f 10 44 d5 00       	movups 0x0(%rbp,%rdx,8),%xmm0
  72a8de:	0f 11 04 c8          	movups %xmm0,(%rax,%rcx,8)
  72a8e2:	4d 85 ed             	test   %r13,%r13
  72a8e5:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72a8ea:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
  72a8ef:	74 4f                	je     72a940 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x2e0>
  72a8f1:	4c 39 eb             	cmp    %r13,%rbx
  72a8f4:	0f 82 2f 02 00 00    	jb     72ab29 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c9>
  72a8fa:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  72a901:	00 
  72a902:	4c 01 e8             	add    %r13,%rax
  72a905:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
  72a909:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  72a910:	00 
  72a911:	48 89 04 24          	mov    %rax,(%rsp)
  72a915:	4c 89 fa             	mov    %r15,%rdx
  72a918:	48 89 e9             	mov    %rbp,%rcx
  72a91b:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72a920:	45 89 f0             	mov    %r14d,%r8d
  72a923:	4c 8d 4c 24 30       	lea    0x30(%rsp),%r9
  72a928:	e8 33 fd ff ff       	call   72a660 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72a92d:	4c 89 eb             	mov    %r13,%rbx
  72a930:	49 83 fd 21          	cmp    $0x21,%r13
  72a934:	0f 83 76 fd ff ff    	jae    72a6b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x50>
  72a93a:	e9 46 fd ff ff       	jmp    72a685 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72a93f:	90                   	nop
  72a940:	48 39 dd             	cmp    %rbx,%rbp
  72a943:	0f 82 de 01 00 00    	jb     72ab27 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c7>
  72a949:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
  72a94d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  72a952:	4d 8d 0c c7          	lea    (%r15,%rax,8),%r9
  72a956:	31 ed                	xor    %ebp,%ebp
  72a958:	4c 89 e0             	mov    %r12,%rax
  72a95b:	4c 89 c9             	mov    %r9,%rcx
  72a95e:	66 90                	xchg   %ax,%ax
  72a960:	4b 8d 14 52          	lea    (%r10,%r10,2),%rdx
  72a964:	49 8d 14 d4          	lea    (%r12,%rdx,8),%rdx
  72a968:	48 39 d0             	cmp    %rdx,%rax
  72a96b:	73 36                	jae    72a9a3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x343>
  72a96d:	0f 1f 00             	nopl   (%rax)
  72a970:	49 8b 36             	mov    (%r14),%rsi
  72a973:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72a977:	48 3b 30             	cmp    (%rax),%rsi
  72a97a:	48 89 ce             	mov    %rcx,%rsi
  72a97d:	49 0f 43 f7          	cmovae %r15,%rsi
  72a981:	48 8d 7c 6d 00       	lea    0x0(%rbp,%rbp,2),%rdi
  72a986:	4c 8b 40 10          	mov    0x10(%rax),%r8
  72a98a:	4c 89 44 fe 10       	mov    %r8,0x10(%rsi,%rdi,8)
  72a98f:	0f 10 00             	movups (%rax),%xmm0
  72a992:	0f 11 04 fe          	movups %xmm0,(%rsi,%rdi,8)
  72a996:	48 83 dd ff          	sbb    $0xffffffffffffffff,%rbp
  72a99a:	48 83 c0 18          	add    $0x18,%rax
  72a99e:	48 39 d0             	cmp    %rdx,%rax
  72a9a1:	72 cd                	jb     72a970 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x310>
  72a9a3:	49 39 da             	cmp    %rbx,%r10
  72a9a6:	74 38                	je     72a9e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x380>
  72a9a8:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72a9ac:	48 8d 14 6d 00 00 00 	lea    0x0(,%rbp,2),%rdx
  72a9b3:	00 
  72a9b4:	48 01 ea             	add    %rbp,%rdx
  72a9b7:	48 8b 70 10          	mov    0x10(%rax),%rsi
  72a9bb:	49 89 74 d7 10       	mov    %rsi,0x10(%r15,%rdx,8)
  72a9c0:	0f 10 00             	movups (%rax),%xmm0
  72a9c3:	41 0f 11 04 d7       	movups %xmm0,(%r15,%rdx,8)
  72a9c8:	48 ff c5             	inc    %rbp
  72a9cb:	48 83 c0 18          	add    $0x18,%rax
  72a9cf:	49 89 da             	mov    %rbx,%r10
  72a9d2:	eb 8c                	jmp    72a960 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x300>
  72a9d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72a9db:	00 00 00 00 00 
  72a9e0:	4d 89 ce             	mov    %r9,%r14
  72a9e3:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
  72a9ea:	00 
  72a9eb:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
  72a9ef:	4c 89 e7             	mov    %r12,%rdi
  72a9f2:	4c 89 fe             	mov    %r15,%rsi
  72a9f5:	ff 15 ed fe 3b 00    	call   *0x3bfeed(%rip)        # aea8e8 <memcpy@GLIBC_2.14>
  72a9fb:	49 89 dd             	mov    %rbx,%r13
  72a9fe:	49 29 ed             	sub    %rbp,%r13
  72aa01:	0f 84 0a 01 00 00    	je     72ab11 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4b1>
  72aa07:	48 8d 04 6d 00 00 00 	lea    0x0(,%rbp,2),%rax
  72aa0e:	00 
  72aa0f:	48 01 e8             	add    %rbp,%rax
  72aa12:	4d 8d 24 c4          	lea    (%r12,%rax,8),%r12
  72aa16:	48 8d 45 01          	lea    0x1(%rbp),%rax
  72aa1a:	48 39 c3             	cmp    %rax,%rbx
  72aa1d:	4d 89 f1             	mov    %r14,%r9
  72aa20:	75 09                	jne    72aa2b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x3cb>
  72aa22:	31 c9                	xor    %ecx,%ecx
  72aa24:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72aa29:	eb 76                	jmp    72aaa1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x441>
  72aa2b:	4c 89 e8             	mov    %r13,%rax
  72aa2e:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
  72aa32:	49 8d 4f e8          	lea    -0x18(%r15),%rcx
  72aa36:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
  72aa3a:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
  72aa3e:	4c 89 e6             	mov    %r12,%rsi
  72aa41:	31 c9                	xor    %ecx,%ecx
  72aa43:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72aa48:	49 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r8
  72aa4f:	ff ff 1f 
  72aa52:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72aa59:	1f 84 00 00 00 00 00 
  72aa60:	48 89 cf             	mov    %rcx,%rdi
  72aa63:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  72aa67:	48 89 4e 10          	mov    %rcx,0x10(%rsi)
  72aa6b:	0f 10 02             	movups (%rdx),%xmm0
  72aa6e:	0f 11 06             	movups %xmm0,(%rsi)
  72aa71:	48 8d 4f 02          	lea    0x2(%rdi),%rcx
  72aa75:	4c 31 c7             	xor    %r8,%rdi
  72aa78:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
  72aa7c:	41 0f 10 04 f9       	movups (%r9,%rdi,8),%xmm0
  72aa81:	0f 11 46 18          	movups %xmm0,0x18(%rsi)
  72aa85:	49 8b 7c f9 10       	mov    0x10(%r9,%rdi,8),%rdi
  72aa8a:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
  72aa8e:	48 83 c6 30          	add    $0x30,%rsi
  72aa92:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
  72aa96:	48 39 c8             	cmp    %rcx,%rax
  72aa99:	75 c5                	jne    72aa60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x400>
  72aa9b:	41 f6 c5 01          	test   $0x1,%r13b
  72aa9f:	74 1f                	je     72aac0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x460>
  72aaa1:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  72aaa5:	48 f7 d1             	not    %rcx
  72aaa8:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  72aaac:	49 8b 54 c9 10       	mov    0x10(%r9,%rcx,8),%rdx
  72aab1:	49 89 54 c4 10       	mov    %rdx,0x10(%r12,%rax,8)
  72aab6:	41 0f 10 04 c9       	movups (%r9,%rcx,8),%xmm0
  72aabb:	41 0f 11 04 c4       	movups %xmm0,(%r12,%rax,8)
  72aac0:	48 39 eb             	cmp    %rbp,%rbx
  72aac3:	72 7d                	jb     72ab42 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4e2>
  72aac5:	b8 00 00 00 00       	mov    $0x0,%eax
  72aaca:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  72aacf:	49 83 fd 21          	cmp    $0x21,%r13
  72aad3:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72aad8:	0f 83 cd fb ff ff    	jae    72a6ab <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4b>
  72aade:	e9 a2 fb ff ff       	jmp    72a685 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72aae3:	4c 89 e7             	mov    %r12,%rdi
  72aae6:	48 89 de             	mov    %rbx,%rsi
  72aae9:	4c 89 fa             	mov    %r15,%rdx
  72aaec:	48 89 e9             	mov    %rbp,%rcx
  72aaef:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72aaf5:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
  72aafc:	00 
  72aafd:	e8 9e 71 00 00       	call   731ca0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>
  72ab02:	48 83 c4 48          	add    $0x48,%rsp
  72ab06:	5b                   	pop    %rbx
  72ab07:	41 5c                	pop    %r12
  72ab09:	41 5d                	pop    %r13
  72ab0b:	41 5e                	pop    %r14
  72ab0d:	41 5f                	pop    %r15
  72ab0f:	5d                   	pop    %rbp
  72ab10:	c3                   	ret
  72ab11:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72ab16:	4d 8d 24 c4          	lea    (%r12,%rax,8),%r12
  72ab1a:	45 31 ed             	xor    %r13d,%r13d
  72ab1d:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72ab22:	e9 5e fb ff ff       	jmp    72a685 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72ab27:	0f 0b                	ud2
  72ab29:	48 8d 3d 44 e6 93 ff 	lea    -0x6c19bc(%rip),%rdi        # 69174 <anon.845a5de654f5e1fb5213dc527790f4a9.0.llvm.5591148014433919328+0x19c>
  72ab30:	48 8d 15 71 2f 39 00 	lea    0x392f71(%rip),%rdx        # abdaa8 <anon.845a5de654f5e1fb5213dc527790f4a9.6.llvm.5591148014433919328+0x120>
  72ab37:	be 13 00 00 00       	mov    $0x13,%esi
  72ab3c:	ff 15 d6 fd 3b 00    	call   *0x3bfdd6(%rip)        # aea918 <_DYNAMIC+0x2a0>
  72ab42:	48 8d 0d 77 2f 39 00 	lea    0x392f77(%rip),%rcx        # abdac0 <anon.845a5de654f5e1fb5213dc527790f4a9.6.llvm.5591148014433919328+0x138>
  72ab49:	48 89 ef             	mov    %rbp,%rdi
  72ab4c:	48 89 de             	mov    %rbx,%rsi
  72ab4f:	48 89 da             	mov    %rbx,%rdx
  72ab52:	ff 15 b0 fd 3b 00    	call   *0x3bfdb0(%rip)        # aea908 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
