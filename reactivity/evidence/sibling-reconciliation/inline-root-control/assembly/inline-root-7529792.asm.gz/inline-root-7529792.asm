
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072e540 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>:
  72e540:	55                   	push   %rbp
  72e541:	41 57                	push   %r15
  72e543:	41 56                	push   %r14
  72e545:	41 55                	push   %r13
  72e547:	41 54                	push   %r12
  72e549:	53                   	push   %rbx
  72e54a:	50                   	push   %rax
  72e54b:	49 89 d7             	mov    %rdx,%r15
  72e54e:	48 89 f3             	mov    %rsi,%rbx
  72e551:	49 89 fe             	mov    %rdi,%r14
  72e554:	48 b8 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rax
  72e55b:	ff ff 1f 
  72e55e:	48 85 c1             	test   %rax,%rcx
  72e561:	74 68                	je     72e5cb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_+0x8b>
  72e563:	48 c1 e9 03          	shr    $0x3,%rcx
  72e567:	49 89 cc             	mov    %rcx,%r12
  72e56a:	49 c1 e4 04          	shl    $0x4,%r12
  72e56e:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
  72e572:	48 8d 04 c9          	lea    (%rcx,%rcx,8),%rax
  72e576:	4c 8d 2c 40          	lea    (%rax,%rax,2),%r13
  72e57a:	49 01 cd             	add    %rcx,%r13
  72e57d:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
  72e581:	4c 89 f7             	mov    %r14,%rdi
  72e584:	48 89 cd             	mov    %rcx,%rbp
  72e587:	4c 89 04 24          	mov    %r8,(%rsp)
  72e58b:	e8 b0 ff ff ff       	call   72e540 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  72e590:	49 89 c6             	mov    %rax,%r14
  72e593:	4a 8d 34 23          	lea    (%rbx,%r12,1),%rsi
  72e597:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
  72e59b:	48 89 df             	mov    %rbx,%rdi
  72e59e:	48 89 e9             	mov    %rbp,%rcx
  72e5a1:	4c 8b 04 24          	mov    (%rsp),%r8
  72e5a5:	e8 96 ff ff ff       	call   72e540 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  72e5aa:	48 89 c3             	mov    %rax,%rbx
  72e5ad:	4d 01 fc             	add    %r15,%r12
  72e5b0:	4d 01 fd             	add    %r15,%r13
  72e5b3:	4c 89 ff             	mov    %r15,%rdi
  72e5b6:	4c 89 e6             	mov    %r12,%rsi
  72e5b9:	4c 89 ea             	mov    %r13,%rdx
  72e5bc:	48 89 e9             	mov    %rbp,%rcx
  72e5bf:	4c 8b 04 24          	mov    (%rsp),%r8
  72e5c3:	e8 78 ff ff ff       	call   72e540 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  72e5c8:	49 89 c7             	mov    %rax,%r15
  72e5cb:	41 8b 06             	mov    (%r14),%eax
  72e5ce:	8b 0b                	mov    (%rbx),%ecx
  72e5d0:	39 c8                	cmp    %ecx,%eax
  72e5d2:	0f 92 c2             	setb   %dl
  72e5d5:	41 8b 37             	mov    (%r15),%esi
  72e5d8:	39 f0                	cmp    %esi,%eax
  72e5da:	0f 92 c0             	setb   %al
  72e5dd:	30 d0                	xor    %dl,%al
  72e5df:	39 f1                	cmp    %esi,%ecx
  72e5e1:	0f 92 c1             	setb   %cl
  72e5e4:	30 d1                	xor    %dl,%cl
  72e5e6:	49 0f 45 df          	cmovne %r15,%rbx
  72e5ea:	84 c0                	test   %al,%al
  72e5ec:	49 0f 45 de          	cmovne %r14,%rbx
  72e5f0:	48 89 d8             	mov    %rbx,%rax
  72e5f3:	48 83 c4 08          	add    $0x8,%rsp
  72e5f7:	5b                   	pop    %rbx
  72e5f8:	41 5c                	pop    %r12
  72e5fa:	41 5d                	pop    %r13
  72e5fc:	41 5e                	pop    %r14
  72e5fe:	41 5f                	pop    %r15
  72e600:	5d                   	pop    %rbp
  72e601:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
