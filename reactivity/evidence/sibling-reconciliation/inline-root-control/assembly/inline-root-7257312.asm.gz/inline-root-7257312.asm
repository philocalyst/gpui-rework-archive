
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006ebce0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_>:
  6ebce0:	53                   	push   %rbx
  6ebce1:	48 81 ec 20 01 00 00 	sub    $0x120,%rsp
  6ebce8:	48 89 fb             	mov    %rdi,%rbx
  6ebceb:	48 8b 06             	mov    (%rsi),%rax
  6ebcee:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6ebcf2:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6ebcf6:	48 85 ff             	test   %rdi,%rdi
  6ebcf9:	0f 84 c3 02 00 00    	je     6ebfc2 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x2e2>
  6ebcff:	48 8b 8c c8 38 05 00 	mov    0x538(%rax,%rcx,8),%rcx
  6ebd06:	00 
  6ebd07:	48 89 f8             	mov    %rdi,%rax
  6ebd0a:	48 ff c8             	dec    %rax
  6ebd0d:	0f 84 cb 00 00 00    	je     6ebdde <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0xfe>
  6ebd13:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6ebd17:	48 89 c6             	mov    %rax,%rsi
  6ebd1a:	48 83 e6 07          	and    $0x7,%rsi
  6ebd1e:	74 2b                	je     6ebd4b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x6b>
  6ebd20:	45 31 c0             	xor    %r8d,%r8d
  6ebd23:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ebd2a:	84 00 00 00 00 00 
  6ebd30:	44 0f b7 89 32 05 00 	movzwl 0x532(%rcx),%r9d
  6ebd37:	00 
  6ebd38:	4a 8b 8c c9 38 05 00 	mov    0x538(%rcx,%r9,8),%rcx
  6ebd3f:	00 
  6ebd40:	49 ff c0             	inc    %r8
  6ebd43:	4c 39 c6             	cmp    %r8,%rsi
  6ebd46:	75 e8                	jne    6ebd30 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x50>
  6ebd48:	4c 29 c0             	sub    %r8,%rax
  6ebd4b:	48 83 ff 07          	cmp    $0x7,%rdi
  6ebd4f:	0f 82 89 00 00 00    	jb     6ebdde <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0xfe>
  6ebd55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6ebd5c:	00 00 00 00 
  6ebd60:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd67:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd6e:	00 
  6ebd6f:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd76:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd7d:	00 
  6ebd7e:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd85:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd8c:	00 
  6ebd8d:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebd94:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebd9b:	00 
  6ebd9c:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebda3:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebdaa:	00 
  6ebdab:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebdb2:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebdb9:	00 
  6ebdba:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebdc1:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebdc8:	00 
  6ebdc9:	0f b7 b1 32 05 00 00 	movzwl 0x532(%rcx),%esi
  6ebdd0:	48 8b 8c f1 38 05 00 	mov    0x538(%rcx,%rsi,8),%rcx
  6ebdd7:	00 
  6ebdd8:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6ebddc:	75 82                	jne    6ebd60 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x80>
  6ebdde:	0f b7 81 32 05 00 00 	movzwl 0x532(%rcx),%eax
  6ebde5:	48 ff c8             	dec    %rax
  6ebde8:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  6ebdef:	00 
  6ebdf0:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  6ebdf7:	00 00 00 00 00 
  6ebdfc:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6ebe03:	00 
  6ebe04:	48 89 e7             	mov    %rsp,%rdi
  6ebe07:	48 8d b4 24 98 00 00 	lea    0x98(%rsp),%rsi
  6ebe0e:	00 
  6ebe0f:	e8 4c 67 00 00       	call   6f2560 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>
  6ebe14:	48 8b 3c 24          	mov    (%rsp),%rdi
  6ebe18:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6ebe1d:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  6ebe24:	00 
  6ebe25:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6ebe2a:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  6ebe31:	00 
  6ebe32:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  6ebe37:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  6ebe3e:	00 
  6ebe3f:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  6ebe44:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  6ebe4b:	00 
  6ebe4c:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  6ebe51:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  6ebe58:	00 
  6ebe59:	0f 10 44 24 58       	movups 0x58(%rsp),%xmm0
  6ebe5e:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  6ebe65:	00 
  6ebe66:	0f 10 44 24 68       	movups 0x68(%rsp),%xmm0
  6ebe6b:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  6ebe72:	00 
  6ebe73:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6ebe78:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  6ebe7f:	00 
  6ebe80:	48 8b 8c 24 88 00 00 	mov    0x88(%rsp),%rcx
  6ebe87:	00 
  6ebe88:	0f b7 90 32 05 00 00 	movzwl 0x532(%rax),%edx
  6ebe8f:	48 39 d1             	cmp    %rdx,%rcx
  6ebe92:	72 26                	jb     6ebeba <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x1da>
  6ebe94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6ebe9b:	00 00 00 00 00 
  6ebea0:	0f b7 88 30 05 00 00 	movzwl 0x530(%rax),%ecx
  6ebea7:	48 8b 80 d0 04 00 00 	mov    0x4d0(%rax),%rax
  6ebeae:	48 ff c6             	inc    %rsi
  6ebeb1:	66 3b 88 32 05 00 00 	cmp    0x532(%rax),%cx
  6ebeb8:	73 e6                	jae    6ebea0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x1c0>
  6ebeba:	4c 6b c1 70          	imul   $0x70,%rcx,%r8
  6ebebe:	48 8b 94 c8 d8 04 00 	mov    0x4d8(%rax,%rcx,8),%rdx
  6ebec5:	00 
  6ebec6:	48 89 bc c8 d8 04 00 	mov    %rdi,0x4d8(%rax,%rcx,8)
  6ebecd:	00 
  6ebece:	42 0f 10 44 00 60    	movups 0x60(%rax,%r8,1),%xmm0
  6ebed4:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6ebed9:	42 0f 10 44 00 50    	movups 0x50(%rax,%r8,1),%xmm0
  6ebedf:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  6ebee4:	42 0f 10 44 00 40    	movups 0x40(%rax,%r8,1),%xmm0
  6ebeea:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  6ebeef:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6ebef4:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6ebefa:	42 0f 10 54 00 20    	movups 0x20(%rax,%r8,1),%xmm2
  6ebf00:	42 0f 10 5c 00 30    	movups 0x30(%rax,%r8,1),%xmm3
  6ebf06:	0f 29 5c 24 30       	movaps %xmm3,0x30(%rsp)
  6ebf0b:	0f 29 54 24 20       	movaps %xmm2,0x20(%rsp)
  6ebf10:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6ebf15:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6ebf19:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
  6ebf20:	00 
  6ebf21:	0f 28 8c 24 c0 00 00 	movaps 0xc0(%rsp),%xmm1
  6ebf28:	00 
  6ebf29:	0f 28 94 24 d0 00 00 	movaps 0xd0(%rsp),%xmm2
  6ebf30:	00 
  6ebf31:	0f 28 9c 24 e0 00 00 	movaps 0xe0(%rsp),%xmm3
  6ebf38:	00 
  6ebf39:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6ebf3e:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6ebf44:	42 0f 11 54 00 20    	movups %xmm2,0x20(%rax,%r8,1)
  6ebf4a:	42 0f 11 5c 00 30    	movups %xmm3,0x30(%rax,%r8,1)
  6ebf50:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
  6ebf57:	00 
  6ebf58:	42 0f 11 44 00 40    	movups %xmm0,0x40(%rax,%r8,1)
  6ebf5e:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
  6ebf65:	00 
  6ebf66:	42 0f 11 44 00 50    	movups %xmm0,0x50(%rax,%r8,1)
  6ebf6c:	0f 28 84 24 10 01 00 	movaps 0x110(%rsp),%xmm0
  6ebf73:	00 
  6ebf74:	42 0f 11 44 00 60    	movups %xmm0,0x60(%rax,%r8,1)
  6ebf7a:	48 85 f6             	test   %rsi,%rsi
  6ebf7d:	74 6c                	je     6ebfeb <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x30b>
  6ebf7f:	48 8d 3c c8          	lea    (%rax,%rcx,8),%rdi
  6ebf83:	48 81 c7 40 05 00 00 	add    $0x540,%rdi
  6ebf8a:	48 89 f1             	mov    %rsi,%rcx
  6ebf8d:	48 83 e1 07          	and    $0x7,%rcx
  6ebf91:	74 5d                	je     6ebff0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x310>
  6ebf93:	45 31 c9             	xor    %r9d,%r9d
  6ebf96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6ebf9d:	00 00 00 
  6ebfa0:	48 8b 07             	mov    (%rdi),%rax
  6ebfa3:	48 8d b8 38 05 00 00 	lea    0x538(%rax),%rdi
  6ebfaa:	49 ff c1             	inc    %r9
  6ebfad:	4c 39 c9             	cmp    %r9,%rcx
  6ebfb0:	75 ee                	jne    6ebfa0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x2c0>
  6ebfb2:	49 89 f0             	mov    %rsi,%r8
  6ebfb5:	4d 29 c8             	sub    %r9,%r8
  6ebfb8:	31 c9                	xor    %ecx,%ecx
  6ebfba:	48 83 fe 08          	cmp    $0x8,%rsi
  6ebfbe:	73 40                	jae    6ec000 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x320>
  6ebfc0:	eb 7f                	jmp    6ec041 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ebfc2:	48 89 04 24          	mov    %rax,(%rsp)
  6ebfc6:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6ebfcd:	00 00 
  6ebfcf:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6ebfd4:	48 89 e6             	mov    %rsp,%rsi
  6ebfd7:	48 89 df             	mov    %rbx,%rdi
  6ebfda:	e8 81 65 00 00       	call   6f2560 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>
  6ebfdf:	48 89 d8             	mov    %rbx,%rax
  6ebfe2:	48 81 c4 20 01 00 00 	add    $0x120,%rsp
  6ebfe9:	5b                   	pop    %rbx
  6ebfea:	c3                   	ret
  6ebfeb:	48 ff c1             	inc    %rcx
  6ebfee:	eb 51                	jmp    6ec041 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ebff0:	49 89 f0             	mov    %rsi,%r8
  6ebff3:	31 c9                	xor    %ecx,%ecx
  6ebff5:	48 83 fe 08          	cmp    $0x8,%rsi
  6ebff9:	72 46                	jb     6ec041 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x361>
  6ebffb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ec000:	48 8b 07             	mov    (%rdi),%rax
  6ec003:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec00a:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec011:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec018:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec01f:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec026:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec02d:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  6ec034:	48 8d b8 38 05 00 00 	lea    0x538(%rax),%rdi
  6ec03b:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6ec03f:	75 bf                	jne    6ec000 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_+0x320>
  6ec041:	48 89 13             	mov    %rdx,(%rbx)
  6ec044:	0f 28 04 24          	movaps (%rsp),%xmm0
  6ec048:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6ec04d:	0f 28 54 24 20       	movaps 0x20(%rsp),%xmm2
  6ec052:	0f 28 5c 24 30       	movaps 0x30(%rsp),%xmm3
  6ec057:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6ec05b:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6ec05f:	0f 11 53 28          	movups %xmm2,0x28(%rbx)
  6ec063:	0f 11 5b 38          	movups %xmm3,0x38(%rbx)
  6ec067:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  6ec06c:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
  6ec070:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  6ec075:	0f 11 43 58          	movups %xmm0,0x58(%rbx)
  6ec079:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6ec07e:	0f 11 43 68          	movups %xmm0,0x68(%rbx)
  6ec082:	48 89 43 78          	mov    %rax,0x78(%rbx)
  6ec086:	48 c7 83 80 00 00 00 	movq   $0x0,0x80(%rbx)
  6ec08d:	00 00 00 00 
  6ec091:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
  6ec098:	48 89 d8             	mov    %rbx,%rax
  6ec09b:	48 81 c4 20 01 00 00 	add    $0x120,%rsp
  6ec0a2:	5b                   	pop    %rbx
  6ec0a3:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
