
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072dfa0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_>:
  72dfa0:	55                   	push   %rbp
  72dfa1:	41 57                	push   %r15
  72dfa3:	41 56                	push   %r14
  72dfa5:	41 55                	push   %r13
  72dfa7:	41 54                	push   %r12
  72dfa9:	53                   	push   %rbx
  72dfaa:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  72dfb1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  72dfb8:	00 
  72dfb9:	50                   	push   %rax
  72dfba:	48 89 d3             	mov    %rdx,%rbx
  72dfbd:	48 89 f1             	mov    %rsi,%rcx
  72dfc0:	48 d1 e9             	shr    $1,%rcx
  72dfc3:	48 89 f0             	mov    %rsi,%rax
  72dfc6:	48 29 c8             	sub    %rcx,%rax
  72dfc9:	48 81 fe 15 16 05 00 	cmp    $0x51615,%rsi
  72dfd0:	41 bd 15 16 05 00    	mov    $0x51615,%r13d
  72dfd6:	4c 0f 42 ee          	cmovb  %rsi,%r13
  72dfda:	49 39 c5             	cmp    %rax,%r13
  72dfdd:	4c 0f 46 e8          	cmovbe %rax,%r13
  72dfe1:	49 81 fd ab 00 00 00 	cmp    $0xab,%r13
  72dfe8:	73 0c                	jae    72dff6 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x56>
  72dfea:	4c 8d 74 24 08       	lea    0x8(%rsp),%r14
  72dfef:	b9 aa 00 00 00       	mov    $0xaa,%ecx
  72dff4:	eb 5b                	jmp    72e051 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0xb1>
  72dff6:	4a 8d 0c ed 00 00 00 	lea    0x0(,%r13,8),%rcx
  72dffd:	00 
  72dffe:	4c 8d 3c 49          	lea    (%rcx,%rcx,2),%r15
  72e002:	48 b9 55 55 55 55 55 	movabs $0x555555555555555,%rcx
  72e009:	55 55 05 
  72e00c:	48 39 c8             	cmp    %rcx,%rax
  72e00f:	76 0f                	jbe    72e020 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x80>
  72e011:	45 31 e4             	xor    %r12d,%r12d
  72e014:	4c 89 e7             	mov    %r12,%rdi
  72e017:	4c 89 fe             	mov    %r15,%rsi
  72e01a:	ff 15 a0 9e 3b 00    	call   *0x3b9ea0(%rip)        # ae7ec0 <_DYNAMIC+0x328>
  72e020:	49 89 f6             	mov    %rsi,%r14
  72e023:	48 89 fd             	mov    %rdi,%rbp
  72e026:	ff 15 cc 9d 3b 00    	call   *0x3b9dcc(%rip)        # ae7df8 <_DYNAMIC+0x260>
  72e02c:	41 bc 08 00 00 00    	mov    $0x8,%r12d
  72e032:	be 08 00 00 00       	mov    $0x8,%esi
  72e037:	4c 89 ff             	mov    %r15,%rdi
  72e03a:	ff 15 98 9d 3b 00    	call   *0x3b9d98(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  72e040:	48 89 ef             	mov    %rbp,%rdi
  72e043:	4c 89 f6             	mov    %r14,%rsi
  72e046:	49 89 c6             	mov    %rax,%r14
  72e049:	4c 89 e9             	mov    %r13,%rcx
  72e04c:	48 85 c0             	test   %rax,%rax
  72e04f:	74 c3                	je     72e014 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x74>
  72e051:	45 31 c0             	xor    %r8d,%r8d
  72e054:	48 83 fe 41          	cmp    $0x41,%rsi
  72e058:	41 0f 92 c0          	setb   %r8b
  72e05c:	4c 89 f2             	mov    %r14,%rdx
  72e05f:	49 89 d9             	mov    %rbx,%r9
  72e062:	e8 99 e9 ff ff       	call   72ca00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>
  72e067:	49 81 fd aa 00 00 00 	cmp    $0xaa,%r13
  72e06e:	76 1d                	jbe    72e08d <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0xed>
  72e070:	49 c1 e5 03          	shl    $0x3,%r13
  72e074:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
  72e07b:	00 
  72e07c:	4c 01 ee             	add    %r13,%rsi
  72e07f:	ba 08 00 00 00       	mov    $0x8,%edx
  72e084:	4c 89 f7             	mov    %r14,%rdi
  72e087:	ff 15 53 9d 3b 00    	call   *0x3b9d53(%rip)        # ae7de0 <_DYNAMIC+0x248>
  72e08d:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  72e094:	5b                   	pop    %rbx
  72e095:	41 5c                	pop    %r12
  72e097:	41 5d                	pop    %r13
  72e099:	41 5e                	pop    %r14
  72e09b:	41 5f                	pop    %r15
  72e09d:	5d                   	pop    %rbp
  72e09e:	c3                   	ret
  72e09f:	48 89 c3             	mov    %rax,%rbx
  72e0a2:	49 81 fd ab 00 00 00 	cmp    $0xab,%r13
  72e0a9:	73 08                	jae    72e0b3 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB14_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB21_11collections5btree3mapINtB2M_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3M_8adapters7flatten7FlatMapINtNtB6_4iter4IterNtB14_9ListDraftEINtNtB4I_3map3MapIB5e_B1C_ENCNCNvMst_NtB16_7runtimeINtB6n_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6h_s2_0EE0E0INtNtB21_3vec3VecBZ_EEB6S_+0x113>
  72e0ab:	48 89 df             	mov    %rbx,%rdi
  72e0ae:	e8 9d a4 38 00       	call   ab8550 <_Unwind_Resume@plt>
  72e0b3:	49 c1 e5 03          	shl    $0x3,%r13
  72e0b7:	4a 8d 34 6d 00 00 00 	lea    0x0(,%r13,2),%rsi
  72e0be:	00 
  72e0bf:	4c 01 ee             	add    %r13,%rsi
  72e0c2:	ba 08 00 00 00       	mov    $0x8,%edx
  72e0c7:	4c 89 f7             	mov    %r14,%rdi
  72e0ca:	ff 15 10 9d 3b 00    	call   *0x3b9d10(%rip)        # ae7de0 <_DYNAMIC+0x248>
  72e0d0:	48 89 df             	mov    %rbx,%rdi
  72e0d3:	e8 78 a4 38 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
