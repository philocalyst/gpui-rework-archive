
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006f46f0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_>:
  6f46f0:	55                   	push   %rbp
  6f46f1:	41 57                	push   %r15
  6f46f3:	41 56                	push   %r14
  6f46f5:	41 55                	push   %r13
  6f46f7:	41 54                	push   %r12
  6f46f9:	53                   	push   %rbx
  6f46fa:	48 83 ec 68          	sub    $0x68,%rsp
  6f46fe:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  6f4703:	48 8b 07             	mov    (%rdi),%rax
  6f4706:	48 85 c0             	test   %rax,%rax
  6f4709:	74 45                	je     6f4750 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x60>
  6f470b:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
  6f470f:	48 85 c9             	test   %rcx,%rcx
  6f4712:	0f 84 96 00 00 00    	je     6f47ae <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0xbe>
  6f4718:	48 89 ca             	mov    %rcx,%rdx
  6f471b:	48 83 e2 07          	and    $0x7,%rdx
  6f471f:	74 35                	je     6f4756 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x66>
  6f4721:	31 f6                	xor    %esi,%esi
  6f4723:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f472a:	84 00 00 00 00 00 
  6f4730:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4737:	48 ff c6             	inc    %rsi
  6f473a:	48 39 f2             	cmp    %rsi,%rdx
  6f473d:	75 f1                	jne    6f4730 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x40>
  6f473f:	48 89 ca             	mov    %rcx,%rdx
  6f4742:	48 29 f2             	sub    %rsi,%rdx
  6f4745:	48 89 fe             	mov    %rdi,%rsi
  6f4748:	48 83 f9 08          	cmp    $0x8,%rcx
  6f474c:	73 22                	jae    6f4770 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x80>
  6f474e:	eb 61                	jmp    6f47b1 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0xc1>
  6f4750:	31 c0                	xor    %eax,%eax
  6f4752:	31 f6                	xor    %esi,%esi
  6f4754:	eb 5b                	jmp    6f47b1 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0xc1>
  6f4756:	48 89 ca             	mov    %rcx,%rdx
  6f4759:	48 89 fe             	mov    %rdi,%rsi
  6f475c:	48 83 f9 08          	cmp    $0x8,%rcx
  6f4760:	72 4f                	jb     6f47b1 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0xc1>
  6f4762:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f4769:	1f 84 00 00 00 00 00 
  6f4770:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4777:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f477e:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4785:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f478c:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f4793:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f479a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f47a1:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6f47a8:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  6f47ac:	75 c2                	jne    6f4770 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x80>
  6f47ae:	48 89 fe             	mov    %rdi,%rsi
  6f47b1:	48 83 c7 10          	add    $0x10,%rdi
  6f47b5:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
  6f47ba:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  6f47bf:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  6f47c4:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
  6f47c9:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6f47ce:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f47d1:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
  6f47d6:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6f47db:	48 8d 74 24 38       	lea    0x38(%rsp),%rsi
  6f47e0:	e8 0b 44 02 00       	call   718bf0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>
  6f47e5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f47ea:	48 83 f8 02          	cmp    $0x2,%rax
  6f47ee:	75 0f                	jne    6f47ff <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x10f>
  6f47f0:	48 83 c4 68          	add    $0x68,%rsp
  6f47f4:	5b                   	pop    %rbx
  6f47f5:	41 5c                	pop    %r12
  6f47f7:	41 5d                	pop    %r13
  6f47f9:	41 5e                	pop    %r14
  6f47fb:	41 5f                	pop    %r15
  6f47fd:	5d                   	pop    %rbp
  6f47fe:	c3                   	ret
  6f47ff:	48 8d 5c 24 10       	lea    0x10(%rsp),%rbx
  6f4804:	4c 8d 74 24 38       	lea    0x38(%rsp),%r14
  6f4809:	4c 8b 2d 30 36 3f 00 	mov    0x3f3630(%rip),%r13        # ae7e40 <_DYNAMIC+0x2a8>
  6f4810:	eb 24                	jmp    6f4836 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x146>
  6f4812:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f4819:	1f 84 00 00 00 00 00 
  6f4820:	48 89 df             	mov    %rbx,%rdi
  6f4823:	4c 89 f6             	mov    %r14,%rsi
  6f4826:	e8 c5 43 02 00       	call   718bf0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>
  6f482b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f4830:	48 83 f8 02          	cmp    $0x2,%rax
  6f4834:	74 ba                	je     6f47f0 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x100>
  6f4836:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6f483b:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  6f4840:	48 85 c0             	test   %rax,%rax
  6f4843:	74 2b                	je     6f4870 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f4845:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f484a:	48 85 ff             	test   %rdi,%rdi
  6f484d:	74 21                	je     6f4870 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f484f:	f6 07 01             	testb  $0x1,(%rdi)
  6f4852:	75 1c                	jne    6f4870 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f4854:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6f4858:	a8 01                	test   $0x1,%al
  6f485a:	75 14                	jne    6f4870 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f485c:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6f4860:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6f4865:	74 42                	je     6f48a9 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x1b9>
  6f4867:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f486e:	00 00 
  6f4870:	4d 85 ff             	test   %r15,%r15
  6f4873:	74 ab                	je     6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f4875:	4d 85 e4             	test   %r12,%r12
  6f4878:	74 a6                	je     6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f487a:	41 f6 04 24 01       	testb  $0x1,(%r12)
  6f487f:	75 9f                	jne    6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f4881:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f4886:	a8 01                	test   $0x1,%al
  6f4888:	75 96                	jne    6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f488a:	49 8d 44 24 08       	lea    0x8(%r12),%rax
  6f488f:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6f4894:	75 8a                	jne    6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f4896:	49 8b 44 24 08       	mov    0x8(%r12),%rax
  6f489b:	40 b5 01             	mov    $0x1,%bpl
  6f489e:	4c 89 e7             	mov    %r12,%rdi
  6f48a1:	41 ff d5             	call   *%r13
  6f48a4:	e9 77 ff ff ff       	jmp    6f4820 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x130>
  6f48a9:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6f48ad:	31 ed                	xor    %ebp,%ebp
  6f48af:	41 ff d5             	call   *%r13
  6f48b2:	eb bc                	jmp    6f4870 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x180>
  6f48b4:	48 89 c3             	mov    %rax,%rbx
  6f48b7:	40 84 ed             	test   %bpl,%bpl
  6f48ba:	75 0b                	jne    6f48c7 <_RINvMsi_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB6_8BTreeMapyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_E6retainNCNvMst_NtB1e_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0EB3T_+0x1d7>
  6f48bc:	4c 89 ff             	mov    %r15,%rdi
  6f48bf:	4c 89 e6             	mov    %r12,%rsi
  6f48c2:	e8 c9 2b 00 00       	call   6f7490 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtB4_6option6OptionNtNtBG_11shared_text10SharedTextEEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f48c7:	48 89 df             	mov    %rbx,%rdi
  6f48ca:	e8 81 3c 3c 00       	call   ab8550 <_Unwind_Resume@plt>
  6f48cf:	ff 15 5b 35 3f 00    	call   *0x3f355b(%rip)        # ae7e30 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
