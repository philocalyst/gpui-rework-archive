
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072e6e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>:
  72e6e0:	55                   	push   %rbp
  72e6e1:	41 57                	push   %r15
  72e6e3:	41 56                	push   %r14
  72e6e5:	41 55                	push   %r13
  72e6e7:	41 54                	push   %r12
  72e6e9:	53                   	push   %rbx
  72e6ea:	50                   	push   %rax
  72e6eb:	49 89 d6             	mov    %rdx,%r14
  72e6ee:	48 89 f3             	mov    %rsi,%rbx
  72e6f1:	48 83 f9 08          	cmp    $0x8,%rcx
  72e6f5:	72 55                	jb     72e74c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_+0x6c>
  72e6f7:	48 c1 e9 03          	shr    $0x3,%rcx
  72e6fb:	49 89 cf             	mov    %rcx,%r15
  72e6fe:	49 c1 e7 06          	shl    $0x6,%r15
  72e702:	4a 8d 34 3f          	lea    (%rdi,%r15,1),%rsi
  72e706:	4c 6b e1 70          	imul   $0x70,%rcx,%r12
  72e70a:	4a 8d 14 27          	lea    (%rdi,%r12,1),%rdx
  72e70e:	49 89 cd             	mov    %rcx,%r13
  72e711:	e8 ca ff ff ff       	call   72e6e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72e716:	48 89 c5             	mov    %rax,%rbp
  72e719:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
  72e71d:	4a 8d 14 23          	lea    (%rbx,%r12,1),%rdx
  72e721:	48 89 df             	mov    %rbx,%rdi
  72e724:	4c 89 e9             	mov    %r13,%rcx
  72e727:	e8 b4 ff ff ff       	call   72e6e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72e72c:	48 89 c3             	mov    %rax,%rbx
  72e72f:	4d 01 f7             	add    %r14,%r15
  72e732:	4d 01 f4             	add    %r14,%r12
  72e735:	4c 89 f7             	mov    %r14,%rdi
  72e738:	4c 89 fe             	mov    %r15,%rsi
  72e73b:	4c 89 e2             	mov    %r12,%rdx
  72e73e:	4c 89 e9             	mov    %r13,%rcx
  72e741:	e8 9a ff ff ff       	call   72e6e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72e746:	48 89 ef             	mov    %rbp,%rdi
  72e749:	49 89 c6             	mov    %rax,%r14
  72e74c:	48 8b 07             	mov    (%rdi),%rax
  72e74f:	48 8b 0b             	mov    (%rbx),%rcx
  72e752:	48 39 c8             	cmp    %rcx,%rax
  72e755:	0f 92 c2             	setb   %dl
  72e758:	49 8b 36             	mov    (%r14),%rsi
  72e75b:	48 39 f0             	cmp    %rsi,%rax
  72e75e:	0f 92 c0             	setb   %al
  72e761:	30 d0                	xor    %dl,%al
  72e763:	48 39 f1             	cmp    %rsi,%rcx
  72e766:	0f 92 c1             	setb   %cl
  72e769:	30 d1                	xor    %dl,%cl
  72e76b:	49 0f 45 de          	cmovne %r14,%rbx
  72e76f:	84 c0                	test   %al,%al
  72e771:	48 0f 45 df          	cmovne %rdi,%rbx
  72e775:	48 89 d8             	mov    %rbx,%rax
  72e778:	48 83 c4 08          	add    $0x8,%rsp
  72e77c:	5b                   	pop    %rbx
  72e77d:	41 5c                	pop    %r12
  72e77f:	41 5d                	pop    %r13
  72e781:	41 5e                	pop    %r14
  72e783:	41 5f                	pop    %r15
  72e785:	5d                   	pop    %rbp
  72e786:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
