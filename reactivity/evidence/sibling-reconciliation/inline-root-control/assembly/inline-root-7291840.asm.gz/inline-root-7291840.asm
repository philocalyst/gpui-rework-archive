
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006f43c0 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB28_>:
  6f43c0:	48 83 ec 18          	sub    $0x18,%rsp
  6f43c4:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  6f43c9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f43ce:	48 83 fe 02          	cmp    $0x2,%rsi
  6f43d2:	73 05                	jae    6f43d9 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB28_+0x19>
  6f43d4:	48 83 c4 18          	add    $0x18,%rsp
  6f43d8:	c3                   	ret
  6f43d9:	48 83 fe 15          	cmp    $0x15,%rsi
  6f43dd:	73 14                	jae    6f43f3 <_RINvMNtCs4NRVxsYgnAr_4core5sliceSNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8Declared20sort_unstable_by_keyyNCNvMst_Bz_INtBz_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0EB28_+0x33>
  6f43df:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
  6f43e4:	ba 01 00 00 00       	mov    $0x1,%edx
  6f43e9:	e8 e2 ce 01 00       	call   7112d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_>
  6f43ee:	48 83 c4 18          	add    $0x18,%rsp
  6f43f2:	c3                   	ret
  6f43f3:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  6f43f8:	e8 33 1b 03 00       	call   725f30 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_>
  6f43fd:	48 83 c4 18          	add    $0x18,%rsp
  6f4401:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
