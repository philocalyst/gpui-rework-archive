
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000725dd0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_>:
  725dd0:	48 83 fe 02          	cmp    $0x2,%rsi
  725dd4:	0f 82 4e 01 00 00    	jb     725f28 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  725dda:	49 89 d0             	mov    %rdx,%r8
  725ddd:	8b 07                	mov    (%rdi),%eax
  725ddf:	8b 4f 04             	mov    0x4(%rdi),%ecx
  725de2:	ba 02 00 00 00       	mov    $0x2,%edx
  725de7:	39 c1                	cmp    %eax,%ecx
  725de9:	73 2b                	jae    725e16 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x46>
  725deb:	48 83 fe 02          	cmp    $0x2,%rsi
  725def:	74 2b                	je     725e1c <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  725df1:	41 89 c9             	mov    %ecx,%r9d
  725df4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  725dfb:	00 00 00 00 00 
  725e00:	45 89 ca             	mov    %r9d,%r10d
  725e03:	44 8b 0c 97          	mov    (%rdi,%rdx,4),%r9d
  725e07:	45 39 d1             	cmp    %r10d,%r9d
  725e0a:	73 10                	jae    725e1c <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  725e0c:	48 ff c2             	inc    %rdx
  725e0f:	48 39 d6             	cmp    %rdx,%rsi
  725e12:	75 ec                	jne    725e00 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x30>
  725e14:	eb 3e                	jmp    725e54 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x84>
  725e16:	48 83 fe 02          	cmp    $0x2,%rsi
  725e1a:	75 1f                	jne    725e3b <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x6b>
  725e1c:	48 39 f2             	cmp    %rsi,%rdx
  725e1f:	74 33                	je     725e54 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x84>
  725e21:	48 89 f0             	mov    %rsi,%rax
  725e24:	48 83 c8 01          	or     $0x1,%rax
  725e28:	48 0f bd c8          	bsr    %rax,%rcx
  725e2c:	83 f1 3f             	xor    $0x3f,%ecx
  725e2f:	01 c9                	add    %ecx,%ecx
  725e31:	83 f1 7e             	xor    $0x7e,%ecx
  725e34:	31 d2                	xor    %edx,%edx
  725e36:	e9 b5 b4 ff ff       	jmp    7212f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>
  725e3b:	41 89 c9             	mov    %ecx,%r9d
  725e3e:	66 90                	xchg   %ax,%ax
  725e40:	45 89 ca             	mov    %r9d,%r10d
  725e43:	44 8b 0c 97          	mov    (%rdi,%rdx,4),%r9d
  725e47:	45 39 d1             	cmp    %r10d,%r9d
  725e4a:	72 d0                	jb     725e1c <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x4c>
  725e4c:	48 ff c2             	inc    %rdx
  725e4f:	48 39 d6             	cmp    %rdx,%rsi
  725e52:	75 ec                	jne    725e40 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x70>
  725e54:	39 c1                	cmp    %eax,%ecx
  725e56:	0f 83 cc 00 00 00    	jae    725f28 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  725e5c:	48 89 f0             	mov    %rsi,%rax
  725e5f:	48 d1 e8             	shr    $1,%rax
  725e62:	48 83 fe 10          	cmp    $0x10,%rsi
  725e66:	73 07                	jae    725e6f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x9f>
  725e68:	31 c9                	xor    %ecx,%ecx
  725e6a:	e9 87 00 00 00       	jmp    725ef6 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x126>
  725e6f:	48 b9 f8 ff ff ff ff 	movabs $0xffffffffffffff8,%rcx
  725e76:	ff ff 0f 
  725e79:	48 21 c1             	and    %rax,%rcx
  725e7c:	48 89 c2             	mov    %rax,%rdx
  725e7f:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
  725e83:	48 f7 da             	neg    %rdx
  725e86:	4c 8d 47 10          	lea    0x10(%rdi),%r8
  725e8a:	4c 8d 0c b7          	lea    (%rdi,%rsi,4),%r9
  725e8e:	49 83 c1 f0          	add    $0xfffffffffffffff0,%r9
  725e92:	45 31 d2             	xor    %r10d,%r10d
  725e95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  725e9c:	00 00 00 00 
  725ea0:	f3 41 0f 6f 40 f0    	movdqu -0x10(%r8),%xmm0
  725ea6:	f3 41 0f 6f 08       	movdqu (%r8),%xmm1
  725eab:	f3 43 0f 6f 54 91 f0 	movdqu -0x10(%r9,%r10,4),%xmm2
  725eb2:	f3 43 0f 6f 1c 91    	movdqu (%r9,%r10,4),%xmm3
  725eb8:	66 0f 70 db 1b       	pshufd $0x1b,%xmm3,%xmm3
  725ebd:	66 0f 70 d2 1b       	pshufd $0x1b,%xmm2,%xmm2
  725ec2:	f3 41 0f 7f 58 f0    	movdqu %xmm3,-0x10(%r8)
  725ec8:	f3 41 0f 7f 10       	movdqu %xmm2,(%r8)
  725ecd:	66 0f 70 c0 1b       	pshufd $0x1b,%xmm0,%xmm0
  725ed2:	66 0f 70 c9 1b       	pshufd $0x1b,%xmm1,%xmm1
  725ed7:	f3 43 0f 7f 04 91    	movdqu %xmm0,(%r9,%r10,4)
  725edd:	f3 43 0f 7f 4c 91 f0 	movdqu %xmm1,-0x10(%r9,%r10,4)
  725ee4:	49 83 c2 f8          	add    $0xfffffffffffffff8,%r10
  725ee8:	49 83 c0 20          	add    $0x20,%r8
  725eec:	4c 39 d2             	cmp    %r10,%rdx
  725eef:	75 af                	jne    725ea0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0xd0>
  725ef1:	48 39 c8             	cmp    %rcx,%rax
  725ef4:	74 32                	je     725f28 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x158>
  725ef6:	48 f7 d8             	neg    %rax
  725ef9:	48 8d 14 8f          	lea    (%rdi,%rcx,4),%rdx
  725efd:	48 f7 d9             	neg    %rcx
  725f00:	48 8d 34 b7          	lea    (%rdi,%rsi,4),%rsi
  725f04:	48 83 c6 fc          	add    $0xfffffffffffffffc,%rsi
  725f08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  725f0f:	00 
  725f10:	8b 3a                	mov    (%rdx),%edi
  725f12:	44 8b 04 8e          	mov    (%rsi,%rcx,4),%r8d
  725f16:	44 89 02             	mov    %r8d,(%rdx)
  725f19:	89 3c 8e             	mov    %edi,(%rsi,%rcx,4)
  725f1c:	48 ff c9             	dec    %rcx
  725f1f:	48 83 c2 04          	add    $0x4,%rdx
  725f23:	48 39 c8             	cmp    %rcx,%rax
  725f26:	75 e8                	jne    725f10 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB6_SBT_20sort_unstable_by_keymNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB2N_+0x140>
  725f28:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
