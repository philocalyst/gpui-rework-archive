
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072e610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>:
  72e610:	55                   	push   %rbp
  72e611:	41 57                	push   %r15
  72e613:	41 56                	push   %r14
  72e615:	41 55                	push   %r13
  72e617:	41 54                	push   %r12
  72e619:	53                   	push   %rbx
  72e61a:	50                   	push   %rax
  72e61b:	49 89 d7             	mov    %rdx,%r15
  72e61e:	48 89 f3             	mov    %rsi,%rbx
  72e621:	49 89 fe             	mov    %rdi,%r14
  72e624:	48 b8 f8 ff ff ff ff 	movabs $0x1ffffffffffffff8,%rax
  72e62b:	ff ff 1f 
  72e62e:	48 85 c1             	test   %rax,%rcx
  72e631:	74 68                	je     72e69b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_+0x8b>
  72e633:	48 c1 e9 03          	shr    $0x3,%rcx
  72e637:	48 89 c8             	mov    %rcx,%rax
  72e63a:	48 c1 e0 05          	shl    $0x5,%rax
  72e63e:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
  72e642:	4b 8d 34 26          	lea    (%r14,%r12,1),%rsi
  72e646:	4c 69 e9 a8 00 00 00 	imul   $0xa8,%rcx,%r13
  72e64d:	4b 8d 14 2e          	lea    (%r14,%r13,1),%rdx
  72e651:	4c 89 f7             	mov    %r14,%rdi
  72e654:	48 89 cd             	mov    %rcx,%rbp
  72e657:	4c 89 04 24          	mov    %r8,(%rsp)
  72e65b:	e8 b0 ff ff ff       	call   72e610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>
  72e660:	49 89 c6             	mov    %rax,%r14
  72e663:	4a 8d 34 23          	lea    (%rbx,%r12,1),%rsi
  72e667:	4a 8d 14 2b          	lea    (%rbx,%r13,1),%rdx
  72e66b:	48 89 df             	mov    %rbx,%rdi
  72e66e:	48 89 e9             	mov    %rbp,%rcx
  72e671:	4c 8b 04 24          	mov    (%rsp),%r8
  72e675:	e8 96 ff ff ff       	call   72e610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>
  72e67a:	48 89 c3             	mov    %rax,%rbx
  72e67d:	4d 01 fc             	add    %r15,%r12
  72e680:	4d 01 fd             	add    %r15,%r13
  72e683:	4c 89 ff             	mov    %r15,%rdi
  72e686:	4c 89 e6             	mov    %r12,%rsi
  72e689:	4c 89 ea             	mov    %r13,%rdx
  72e68c:	48 89 e9             	mov    %rbp,%rcx
  72e68f:	4c 8b 04 24          	mov    (%rsp),%r8
  72e693:	e8 78 ff ff ff       	call   72e610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>
  72e698:	49 89 c7             	mov    %rax,%r15
  72e69b:	49 8b 06             	mov    (%r14),%rax
  72e69e:	48 8b 0b             	mov    (%rbx),%rcx
  72e6a1:	48 39 c8             	cmp    %rcx,%rax
  72e6a4:	0f 92 c2             	setb   %dl
  72e6a7:	49 8b 37             	mov    (%r15),%rsi
  72e6aa:	48 39 f0             	cmp    %rsi,%rax
  72e6ad:	0f 92 c0             	setb   %al
  72e6b0:	30 d0                	xor    %dl,%al
  72e6b2:	48 39 f1             	cmp    %rsi,%rcx
  72e6b5:	0f 92 c1             	setb   %cl
  72e6b8:	30 d1                	xor    %dl,%cl
  72e6ba:	49 0f 45 df          	cmovne %r15,%rbx
  72e6be:	84 c0                	test   %al,%al
  72e6c0:	49 0f 45 de          	cmovne %r14,%rbx
  72e6c4:	48 89 d8             	mov    %rbx,%rax
  72e6c7:	48 83 c4 08          	add    $0x8,%rsp
  72e6cb:	5b                   	pop    %rbx
  72e6cc:	41 5c                	pop    %r12
  72e6ce:	41 5d                	pop    %r13
  72e6d0:	41 5e                	pop    %r14
  72e6d2:	41 5f                	pop    %r15
  72e6d4:	5d                   	pop    %rbp
  72e6d5:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
