
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072e900 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>:
  72e900:	55                   	push   %rbp
  72e901:	41 57                	push   %r15
  72e903:	41 56                	push   %r14
  72e905:	41 55                	push   %r13
  72e907:	41 54                	push   %r12
  72e909:	53                   	push   %rbx
  72e90a:	48 83 ec 58          	sub    $0x58,%rsp
  72e90e:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  72e913:	49 89 ce             	mov    %rcx,%r14
  72e916:	49 89 d7             	mov    %rdx,%r15
  72e919:	49 89 f5             	mov    %rsi,%r13
  72e91c:	49 89 fc             	mov    %rdi,%r12
  72e91f:	48 83 fe 21          	cmp    $0x21,%rsi
  72e923:	73 1e                	jae    72e943 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x43>
  72e925:	4c 89 e7             	mov    %r12,%rdi
  72e928:	4c 89 ee             	mov    %r13,%rsi
  72e92b:	4c 89 fa             	mov    %r15,%rdx
  72e92e:	4c 89 f1             	mov    %r14,%rcx
  72e931:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  72e938:	00 
  72e939:	e8 d2 2b fe ff       	call   711510 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2c_11collections5btree3mapINtB2Y_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB3Y_8adapters3map3MapINtNtB8_4iter4IterNtB1w_9ListDraftENCNvMst_NtB1y_7runtimeINtB5Z_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6u_>
  72e93e:	e9 a9 05 00 00       	jmp    72eeec <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5ec>
  72e943:	44 89 c3             	mov    %r8d,%ebx
  72e946:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  72e94b:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72e950:	85 db                	test   %ebx,%ebx
  72e952:	0f 84 73 05 00 00    	je     72eecb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5cb>
  72e958:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72e95d:	48 89 f1             	mov    %rsi,%rcx
  72e960:	48 c1 e9 03          	shr    $0x3,%rcx
  72e964:	48 89 c8             	mov    %rcx,%rax
  72e967:	48 c1 e0 06          	shl    $0x6,%rax
  72e96b:	4c 01 e0             	add    %r12,%rax
  72e96e:	48 6b d1 70          	imul   $0x70,%rcx,%rdx
  72e972:	4c 01 e2             	add    %r12,%rdx
  72e975:	48 83 fe 40          	cmp    $0x40,%rsi
  72e979:	73 35                	jae    72e9b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xb0>
  72e97b:	49 8b 0c 24          	mov    (%r12),%rcx
  72e97f:	48 8b 30             	mov    (%rax),%rsi
  72e982:	48 39 f1             	cmp    %rsi,%rcx
  72e985:	40 0f 92 c7          	setb   %dil
  72e989:	4c 8b 02             	mov    (%rdx),%r8
  72e98c:	4c 39 c1             	cmp    %r8,%rcx
  72e98f:	0f 92 c1             	setb   %cl
  72e992:	40 30 f9             	xor    %dil,%cl
  72e995:	4c 39 c6             	cmp    %r8,%rsi
  72e998:	40 0f 92 c6          	setb   %sil
  72e99c:	40 30 fe             	xor    %dil,%sil
  72e99f:	48 0f 45 c2          	cmovne %rdx,%rax
  72e9a3:	84 c9                	test   %cl,%cl
  72e9a5:	49 0f 45 c4          	cmovne %r12,%rax
  72e9a9:	eb 10                	jmp    72e9bb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xbb>
  72e9ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72e9b0:	4c 89 e7             	mov    %r12,%rdi
  72e9b3:	48 89 c6             	mov    %rax,%rsi
  72e9b6:	e8 25 fd ff ff       	call   72e6e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72e9bb:	ff cb                	dec    %ebx
  72e9bd:	89 5c 24 2c          	mov    %ebx,0x2c(%rsp)
  72e9c1:	48 89 c5             	mov    %rax,%rbp
  72e9c4:	4c 29 e5             	sub    %r12,%rbp
  72e9c7:	48 89 e9             	mov    %rbp,%rcx
  72e9ca:	48 c1 e9 04          	shr    $0x4,%rcx
  72e9ce:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  72e9d3:	0f 10 00             	movups (%rax),%xmm0
  72e9d6:	48 8b 00             	mov    (%rax),%rax
  72e9d9:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  72e9de:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  72e9e4:	74 0e                	je     72e9f4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0xf4>
  72e9e6:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  72e9eb:	48 39 01             	cmp    %rax,(%rcx)
  72e9ee:	0f 83 8c 02 00 00    	jae    72ec80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x380>
  72e9f4:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  72e9f9:	49 39 de             	cmp    %rbx,%r14
  72e9fc:	0f 82 0e 05 00 00    	jb     72ef10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x610>
  72ea02:	49 89 de             	mov    %rbx,%r14
  72ea05:	49 c1 e6 04          	shl    $0x4,%r14
  72ea09:	4b 8d 0c 37          	lea    (%r15,%r14,1),%rcx
  72ea0d:	45 31 ed             	xor    %r13d,%r13d
  72ea10:	4c 89 e0             	mov    %r12,%rax
  72ea13:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72ea18:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  72ea1d:	0f 1f 00             	nopl   (%rax)
  72ea20:	48 89 d7             	mov    %rdx,%rdi
  72ea23:	48 83 ef 03          	sub    $0x3,%rdi
  72ea27:	be 00 00 00 00       	mov    $0x0,%esi
  72ea2c:	48 0f 43 f7          	cmovae %rdi,%rsi
  72ea30:	48 c1 e6 04          	shl    $0x4,%rsi
  72ea34:	4c 01 e6             	add    %r12,%rsi
  72ea37:	48 39 f0             	cmp    %rsi,%rax
  72ea3a:	0f 83 a4 00 00 00    	jae    72eae4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x1e4>
  72ea40:	48 8b 38             	mov    (%rax),%rdi
  72ea43:	4c 8d 41 f0          	lea    -0x10(%rcx),%r8
  72ea47:	45 31 c9             	xor    %r9d,%r9d
  72ea4a:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72ea4e:	4d 0f 42 c7          	cmovb  %r15,%r8
  72ea52:	41 0f 92 c1          	setb   %r9b
  72ea56:	4c 89 ef             	mov    %r13,%rdi
  72ea59:	48 c1 e7 04          	shl    $0x4,%rdi
  72ea5d:	4f 8d 14 29          	lea    (%r9,%r13,1),%r10
  72ea61:	4c 8b 58 10          	mov    0x10(%rax),%r11
  72ea65:	49 c1 e2 04          	shl    $0x4,%r10
  72ea69:	4d 3b 1c 2c          	cmp    (%r12,%rbp,1),%r11
  72ea6d:	0f 10 00             	movups (%rax),%xmm0
  72ea70:	4c 8d 59 e0          	lea    -0x20(%rcx),%r11
  72ea74:	4d 0f 42 df          	cmovb  %r15,%r11
  72ea78:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72ea7d:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72ea81:	4d 11 cd             	adc    %r9,%r13
  72ea84:	43 0f 11 04 13       	movups %xmm0,(%r11,%r10,1)
  72ea89:	48 8b 78 20          	mov    0x20(%rax),%rdi
  72ea8d:	4c 8d 41 d0          	lea    -0x30(%rcx),%r8
  72ea91:	45 31 c9             	xor    %r9d,%r9d
  72ea94:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72ea98:	4d 0f 42 c7          	cmovb  %r15,%r8
  72ea9c:	41 0f 92 c1          	setb   %r9b
  72eaa0:	4c 89 ef             	mov    %r13,%rdi
  72eaa3:	48 c1 e7 04          	shl    $0x4,%rdi
  72eaa7:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72eaab:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72eab0:	4b 8d 3c 29          	lea    (%r9,%r13,1),%rdi
  72eab4:	4c 8b 40 30          	mov    0x30(%rax),%r8
  72eab8:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72eabc:	48 c1 e7 04          	shl    $0x4,%rdi
  72eac0:	4d 3b 04 2c          	cmp    (%r12,%rbp,1),%r8
  72eac4:	49 89 c8             	mov    %rcx,%r8
  72eac7:	4d 0f 42 c7          	cmovb  %r15,%r8
  72eacb:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72eacf:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72ead4:	4d 11 cd             	adc    %r9,%r13
  72ead7:	48 83 c0 40          	add    $0x40,%rax
  72eadb:	48 39 f0             	cmp    %rsi,%rax
  72eade:	0f 82 5c ff ff ff    	jb     72ea40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x140>
  72eae4:	48 89 d6             	mov    %rdx,%rsi
  72eae7:	48 c1 e6 04          	shl    $0x4,%rsi
  72eaeb:	4c 01 e6             	add    %r12,%rsi
  72eaee:	48 39 f0             	cmp    %rsi,%rax
  72eaf1:	73 3b                	jae    72eb2e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x22e>
  72eaf3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72eafa:	84 00 00 00 00 00 
  72eb00:	48 8b 38             	mov    (%rax),%rdi
  72eb03:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72eb07:	4d 89 e8             	mov    %r13,%r8
  72eb0a:	49 c1 e0 04          	shl    $0x4,%r8
  72eb0e:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72eb12:	48 89 cf             	mov    %rcx,%rdi
  72eb15:	49 0f 42 ff          	cmovb  %r15,%rdi
  72eb19:	0f 10 00             	movups (%rax),%xmm0
  72eb1c:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72eb21:	49 83 d5 00          	adc    $0x0,%r13
  72eb25:	48 83 c0 10          	add    $0x10,%rax
  72eb29:	48 39 f0             	cmp    %rsi,%rax
  72eb2c:	72 d2                	jb     72eb00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x200>
  72eb2e:	48 39 da             	cmp    %rbx,%rdx
  72eb31:	74 2d                	je     72eb60 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x260>
  72eb33:	4c 89 ea             	mov    %r13,%rdx
  72eb36:	48 c1 e2 04          	shl    $0x4,%rdx
  72eb3a:	0f 10 00             	movups (%rax),%xmm0
  72eb3d:	0f 11 44 11 f0       	movups %xmm0,-0x10(%rcx,%rdx,1)
  72eb42:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72eb46:	48 83 c0 10          	add    $0x10,%rax
  72eb4a:	48 89 da             	mov    %rbx,%rdx
  72eb4d:	e9 ce fe ff ff       	jmp    72ea20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x120>
  72eb52:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72eb59:	1f 84 00 00 00 00 00 
  72eb60:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  72eb65:	4c 89 eb             	mov    %r13,%rbx
  72eb68:	48 c1 e3 04          	shl    $0x4,%rbx
  72eb6c:	4c 89 e7             	mov    %r12,%rdi
  72eb6f:	4c 89 fe             	mov    %r15,%rsi
  72eb72:	48 89 da             	mov    %rbx,%rdx
  72eb75:	ff 15 8d 92 3b 00    	call   *0x3b928d(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72eb7b:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72eb80:	4c 29 ee             	sub    %r13,%rsi
  72eb83:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72eb8a:	ff ff 0f 
  72eb8d:	4b 8d 3c 37          	lea    (%r15,%r14,1),%rdi
  72eb91:	0f 84 8e 00 00 00    	je     72ec25 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x325>
  72eb97:	49 8d 45 01          	lea    0x1(%r13),%rax
  72eb9b:	48 39 44 24 10       	cmp    %rax,0x10(%rsp)
  72eba0:	75 0e                	jne    72ebb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x2b0>
  72eba2:	31 c0                	xor    %eax,%eax
  72eba4:	eb 65                	jmp    72ec0b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x30b>
  72eba6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72ebad:	00 00 00 
  72ebb0:	48 89 f1             	mov    %rsi,%rcx
  72ebb3:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72ebb7:	49 8d 44 24 10       	lea    0x10(%r12),%rax
  72ebbc:	48 8d 14 18          	lea    (%rax,%rbx,1),%rdx
  72ebc0:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72ebc4:	49 01 c6             	add    %rax,%r14
  72ebc7:	31 c0                	xor    %eax,%eax
  72ebc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72ebd0:	48 89 c7             	mov    %rax,%rdi
  72ebd3:	41 0f 10 06          	movups (%r14),%xmm0
  72ebd7:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72ebdb:	48 83 c0 02          	add    $0x2,%rax
  72ebdf:	4c 31 c7             	xor    %r8,%rdi
  72ebe2:	48 c1 e7 04          	shl    $0x4,%rdi
  72ebe6:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72ebeb:	41 0f 10 04 39       	movups (%r9,%rdi,1),%xmm0
  72ebf0:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  72ebf5:	0f 11 02             	movups %xmm0,(%rdx)
  72ebf8:	48 83 c2 20          	add    $0x20,%rdx
  72ebfc:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
  72ec00:	48 39 c1             	cmp    %rax,%rcx
  72ec03:	75 cb                	jne    72ebd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x2d0>
  72ec05:	40 f6 c6 01          	test   $0x1,%sil
  72ec09:	74 1a                	je     72ec25 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x325>
  72ec0b:	49 8d 0c 1c          	lea    (%r12,%rbx,1),%rcx
  72ec0f:	48 89 c2             	mov    %rax,%rdx
  72ec12:	48 f7 d2             	not    %rdx
  72ec15:	48 c1 e2 04          	shl    $0x4,%rdx
  72ec19:	48 c1 e0 04          	shl    $0x4,%rax
  72ec1d:	0f 10 04 17          	movups (%rdi,%rdx,1),%xmm0
  72ec21:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  72ec25:	4d 85 ed             	test   %r13,%r13
  72ec28:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72ec2d:	74 51                	je     72ec80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x380>
  72ec2f:	4c 39 6c 24 10       	cmp    %r13,0x10(%rsp)
  72ec34:	0f 82 d8 02 00 00    	jb     72ef12 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x612>
  72ec3a:	4c 01 e3             	add    %r12,%rbx
  72ec3d:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  72ec44:	00 
  72ec45:	48 89 04 24          	mov    %rax,(%rsp)
  72ec49:	48 89 df             	mov    %rbx,%rdi
  72ec4c:	4c 89 fa             	mov    %r15,%rdx
  72ec4f:	4c 89 f1             	mov    %r14,%rcx
  72ec52:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72ec56:	41 89 d8             	mov    %ebx,%r8d
  72ec59:	4c 8d 4c 24 40       	lea    0x40(%rsp),%r9
  72ec5e:	e8 9d fc ff ff       	call   72e900 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72ec63:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72ec68:	49 83 fd 21          	cmp    $0x21,%r13
  72ec6c:	0f 83 de fc ff ff    	jae    72e950 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x50>
  72ec72:	e9 ae fc ff ff       	jmp    72e925 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x25>
  72ec77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72ec7e:	00 00 
  72ec80:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72ec85:	49 39 c6             	cmp    %rax,%r14
  72ec88:	0f 82 82 02 00 00    	jb     72ef10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x610>
  72ec8e:	48 c1 e0 04          	shl    $0x4,%rax
  72ec92:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72ec97:	49 8d 0c 07          	lea    (%r15,%rax,1),%rcx
  72ec9b:	31 db                	xor    %ebx,%ebx
  72ec9d:	4c 89 e0             	mov    %r12,%rax
  72eca0:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72eca5:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
  72ecaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  72ecb0:	4c 89 d6             	mov    %r10,%rsi
  72ecb3:	48 83 ee 03          	sub    $0x3,%rsi
  72ecb7:	ba 00 00 00 00       	mov    $0x0,%edx
  72ecbc:	48 0f 43 d6          	cmovae %rsi,%rdx
  72ecc0:	48 c1 e2 04          	shl    $0x4,%rdx
  72ecc4:	4c 01 e2             	add    %r12,%rdx
  72ecc7:	48 39 d0             	cmp    %rdx,%rax
  72ecca:	0f 83 9d 00 00 00    	jae    72ed6d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x46d>
  72ecd0:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72ecd4:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
  72ecd8:	49 89 d8             	mov    %rbx,%r8
  72ecdb:	49 c1 e0 04          	shl    $0x4,%r8
  72ecdf:	48 3b 30             	cmp    (%rax),%rsi
  72ece2:	49 0f 43 ff          	cmovae %r15,%rdi
  72ece6:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ecea:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72ecee:	49 89 d9             	mov    %rbx,%r9
  72ecf1:	49 c1 e1 04          	shl    $0x4,%r9
  72ecf5:	48 3b 70 10          	cmp    0x10(%rax),%rsi
  72ecf9:	0f 10 00             	movups (%rax),%xmm0
  72ecfc:	48 8d 71 e0          	lea    -0x20(%rcx),%rsi
  72ed00:	49 0f 43 f7          	cmovae %r15,%rsi
  72ed04:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72ed09:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ed0d:	49 8b 3c 2c          	mov    (%r12,%rbp,1),%rdi
  72ed11:	49 89 d8             	mov    %rbx,%r8
  72ed14:	49 c1 e0 04          	shl    $0x4,%r8
  72ed18:	48 3b 78 20          	cmp    0x20(%rax),%rdi
  72ed1c:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72ed20:	48 8d 79 d0          	lea    -0x30(%rcx),%rdi
  72ed24:	49 0f 43 ff          	cmovae %r15,%rdi
  72ed28:	42 0f 11 04 0e       	movups %xmm0,(%rsi,%r9,1)
  72ed2d:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72ed31:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ed35:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72ed3a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72ed3e:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72ed42:	48 89 df             	mov    %rbx,%rdi
  72ed45:	48 c1 e7 04          	shl    $0x4,%rdi
  72ed49:	48 3b 70 30          	cmp    0x30(%rax),%rsi
  72ed4d:	48 89 ce             	mov    %rcx,%rsi
  72ed50:	49 0f 43 f7          	cmovae %r15,%rsi
  72ed54:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72ed58:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72ed5c:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72ed60:	48 83 c0 40          	add    $0x40,%rax
  72ed64:	48 39 d0             	cmp    %rdx,%rax
  72ed67:	0f 82 63 ff ff ff    	jb     72ecd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x3d0>
  72ed6d:	4c 89 d2             	mov    %r10,%rdx
  72ed70:	48 c1 e2 04          	shl    $0x4,%rdx
  72ed74:	4c 01 e2             	add    %r12,%rdx
  72ed77:	48 39 d0             	cmp    %rdx,%rax
  72ed7a:	73 31                	jae    72edad <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4ad>
  72ed7c:	0f 1f 40 00          	nopl   0x0(%rax)
  72ed80:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72ed84:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72ed88:	48 89 df             	mov    %rbx,%rdi
  72ed8b:	48 c1 e7 04          	shl    $0x4,%rdi
  72ed8f:	48 3b 30             	cmp    (%rax),%rsi
  72ed92:	48 89 ce             	mov    %rcx,%rsi
  72ed95:	49 0f 43 f7          	cmovae %r15,%rsi
  72ed99:	0f 10 00             	movups (%rax),%xmm0
  72ed9c:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72eda0:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72eda4:	48 83 c0 10          	add    $0x10,%rax
  72eda8:	48 39 d0             	cmp    %rdx,%rax
  72edab:	72 d3                	jb     72ed80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x480>
  72edad:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  72edb2:	4d 39 f2             	cmp    %r14,%r10
  72edb5:	74 29                	je     72ede0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4e0>
  72edb7:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72edbb:	48 89 da             	mov    %rbx,%rdx
  72edbe:	48 c1 e2 04          	shl    $0x4,%rdx
  72edc2:	0f 10 00             	movups (%rax),%xmm0
  72edc5:	41 0f 11 04 17       	movups %xmm0,(%r15,%rdx,1)
  72edca:	48 ff c3             	inc    %rbx
  72edcd:	48 83 c0 10          	add    $0x10,%rax
  72edd1:	4d 89 f2             	mov    %r14,%r10
  72edd4:	e9 d7 fe ff ff       	jmp    72ecb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x3b0>
  72edd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72ede0:	48 89 dd             	mov    %rbx,%rbp
  72ede3:	48 c1 e5 04          	shl    $0x4,%rbp
  72ede7:	4c 89 e7             	mov    %r12,%rdi
  72edea:	4c 89 fe             	mov    %r15,%rsi
  72eded:	48 89 ea             	mov    %rbp,%rdx
  72edf0:	ff 15 12 90 3b 00    	call   *0x3b9012(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72edf6:	4d 89 f5             	mov    %r14,%r13
  72edf9:	49 29 dd             	sub    %rbx,%r13
  72edfc:	0f 84 f9 00 00 00    	je     72eefb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x5fb>
  72ee02:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
  72ee06:	48 8d 43 01          	lea    0x1(%rbx),%rax
  72ee0a:	49 39 c6             	cmp    %rax,%r14
  72ee0d:	75 09                	jne    72ee18 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x518>
  72ee0f:	31 c0                	xor    %eax,%eax
  72ee11:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72ee16:	eb 69                	jmp    72ee81 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x581>
  72ee18:	4c 89 e9             	mov    %r13,%rcx
  72ee1b:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72ee1f:	49 8d 14 2c          	lea    (%r12,%rbp,1),%rdx
  72ee23:	48 83 c2 10          	add    $0x10,%rdx
  72ee27:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72ee2b:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  72ee30:	49 01 c2             	add    %rax,%r10
  72ee33:	31 c0                	xor    %eax,%eax
  72ee35:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72ee3c:	ff ff 0f 
  72ee3f:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72ee44:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72ee4b:	00 00 00 00 00 
  72ee50:	48 89 c6             	mov    %rax,%rsi
  72ee53:	41 0f 10 02          	movups (%r10),%xmm0
  72ee57:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72ee5b:	48 83 c0 02          	add    $0x2,%rax
  72ee5f:	4c 31 c6             	xor    %r8,%rsi
  72ee62:	48 c1 e6 04          	shl    $0x4,%rsi
  72ee66:	41 0f 10 04 31       	movups (%r9,%rsi,1),%xmm0
  72ee6b:	0f 11 02             	movups %xmm0,(%rdx)
  72ee6e:	48 83 c2 20          	add    $0x20,%rdx
  72ee72:	49 83 c2 e0          	add    $0xffffffffffffffe0,%r10
  72ee76:	48 39 c1             	cmp    %rax,%rcx
  72ee79:	75 d5                	jne    72ee50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x550>
  72ee7b:	41 f6 c5 01          	test   $0x1,%r13b
  72ee7f:	74 17                	je     72ee98 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x598>
  72ee81:	48 89 c1             	mov    %rax,%rcx
  72ee84:	48 f7 d1             	not    %rcx
  72ee87:	48 c1 e1 04          	shl    $0x4,%rcx
  72ee8b:	48 c1 e0 04          	shl    $0x4,%rax
  72ee8f:	41 0f 10 04 09       	movups (%r9,%rcx,1),%xmm0
  72ee94:	0f 11 04 07          	movups %xmm0,(%rdi,%rax,1)
  72ee98:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72ee9d:	48 39 da             	cmp    %rbx,%rdx
  72eea0:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72eea5:	0f 82 80 00 00 00    	jb     72ef2b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x62b>
  72eeab:	49 89 fc             	mov    %rdi,%r12
  72eeae:	b8 00 00 00 00       	mov    $0x0,%eax
  72eeb3:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72eeb8:	49 83 fd 21          	cmp    $0x21,%r13
  72eebc:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72eec0:	0f 83 85 fa ff ff    	jae    72e94b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x4b>
  72eec6:	e9 5d fa ff ff       	jmp    72e928 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x28>
  72eecb:	4c 89 e7             	mov    %r12,%rdi
  72eece:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72eed3:	4c 89 fa             	mov    %r15,%rdx
  72eed6:	4c 89 f1             	mov    %r14,%rcx
  72eed9:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72eedf:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  72eee6:	00 
  72eee7:	e8 94 d4 ff ff       	call   72c380 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>
  72eeec:	48 83 c4 58          	add    $0x58,%rsp
  72eef0:	5b                   	pop    %rbx
  72eef1:	41 5c                	pop    %r12
  72eef3:	41 5d                	pop    %r13
  72eef5:	41 5e                	pop    %r14
  72eef7:	41 5f                	pop    %r15
  72eef9:	5d                   	pop    %rbp
  72eefa:	c3                   	ret
  72eefb:	4c 03 64 24 18       	add    0x18(%rsp),%r12
  72ef00:	45 31 ed             	xor    %r13d,%r13d
  72ef03:	4c 89 e7             	mov    %r12,%rdi
  72ef06:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72ef0b:	e9 18 fa ff ff       	jmp    72e928 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_+0x28>
  72ef10:	0f 0b                	ud2
  72ef12:	48 8d 3d 1b a7 93 ff 	lea    -0x6c58e5(%rip),%rdi        # 69634 <anon.82a788e7fdd98d311675b83eb91f04ac.0.llvm.15086054616281437909+0x27>
  72ef19:	48 8d 15 c8 c4 38 00 	lea    0x38c4c8(%rip),%rdx        # abb3e8 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x38>
  72ef20:	be 13 00 00 00       	mov    $0x13,%esi
  72ef25:	ff 15 0d 8f 3b 00    	call   *0x3b8f0d(%rip)        # ae7e38 <_DYNAMIC+0x2a0>
  72ef2b:	48 8d 0d ce c4 38 00 	lea    0x38c4ce(%rip),%rcx        # abb400 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x50>
  72ef32:	48 89 df             	mov    %rbx,%rdi
  72ef35:	48 89 d6             	mov    %rdx,%rsi
  72ef38:	ff 15 ea 8e 3b 00    	call   *0x3b8eea(%rip)        # ae7e28 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
