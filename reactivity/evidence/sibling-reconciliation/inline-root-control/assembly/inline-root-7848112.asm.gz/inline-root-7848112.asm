
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000077c0b0 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new>:
  77c0b0:	55                   	push   %rbp
  77c0b1:	41 57                	push   %r15
  77c0b3:	41 56                	push   %r14
  77c0b5:	41 55                	push   %r13
  77c0b7:	41 54                	push   %r12
  77c0b9:	53                   	push   %rbx
  77c0ba:	50                   	push   %rax
  77c0bb:	48 83 fa 01          	cmp    $0x1,%rdx
  77c0bf:	74 11                	je     77c0d2 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x22>
  77c0c1:	48 85 d2             	test   %rdx,%rdx
  77c0c4:	75 21                	jne    77c0e7 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x37>
  77c0c6:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
  77c0cd:	00 00 80 
  77c0d0:	eb 0d                	jmp    77c0df <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x2f>
  77c0d2:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
  77c0d9:	00 00 80 
  77c0dc:	48 ff c0             	inc    %rax
  77c0df:	48 89 07             	mov    %rax,(%rdi)
  77c0e2:	e9 8b 01 00 00       	jmp    77c272 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1c2>
  77c0e7:	49 89 f4             	mov    %rsi,%r12
  77c0ea:	49 89 ff             	mov    %rdi,%r15
  77c0ed:	49 89 d6             	mov    %rdx,%r14
  77c0f0:	48 8d 04 12          	lea    (%rdx,%rdx,1),%rax
  77c0f4:	48 8d 1c 85 08 00 00 	lea    0x8(,%rax,4),%rbx
  77c0fb:	00 
  77c0fc:	ff 15 f6 bc 36 00    	call   *0x36bcf6(%rip)        # ae7df8 <_DYNAMIC+0x260>
  77c102:	be 04 00 00 00       	mov    $0x4,%esi
  77c107:	48 89 1c 24          	mov    %rbx,(%rsp)
  77c10b:	48 89 df             	mov    %rbx,%rdi
  77c10e:	ff 15 dc bc 36 00    	call   *0x36bcdc(%rip)        # ae7df0 <_DYNAMIC+0x258>
  77c114:	48 85 c0             	test   %rax,%rax
  77c117:	0f 84 8f 01 00 00    	je     77c2ac <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1fc>
  77c11d:	4d 89 f1             	mov    %r14,%r9
  77c120:	4a 8d 34 75 02 00 00 	lea    0x2(,%r14,2),%rsi
  77c127:	00 
  77c128:	4d 8d 46 02          	lea    0x2(%r14),%r8
  77c12c:	4e 8d 14 b0          	lea    (%rax,%r14,4),%r10
  77c130:	49 83 c2 08          	add    $0x8,%r10
  77c134:	4a 8d 0c f5 00 00 00 	lea    0x0(,%r14,8),%rcx
  77c13b:	00 
  77c13c:	4c 8d 1c 89          	lea    (%rcx,%rcx,4),%r11
  77c140:	45 31 ed             	xor    %r13d,%r13d
  77c143:	bd ff ff ff ff       	mov    $0xffffffff,%ebp
  77c148:	bb 01 00 00 00       	mov    $0x1,%ebx
  77c14d:	48 8d 15 2c 4d 34 00 	lea    0x344d2c(%rip),%rdx        # ac0e80 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0x58>
  77c154:	4c 89 ff             	mov    %r15,%rdi
  77c157:	4d 89 e7             	mov    %r12,%r15
  77c15a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  77c160:	47 8b 64 2f 18       	mov    0x18(%r15,%r13,1),%r12d
  77c165:	49 8d 4c 24 02       	lea    0x2(%r12),%rcx
  77c16a:	49 39 ec             	cmp    %rbp,%r12
  77c16d:	49 89 cc             	mov    %rcx,%r12
  77c170:	4c 0f 44 e3          	cmove  %rbx,%r12
  77c174:	4d 39 c4             	cmp    %r8,%r12
  77c177:	0f 83 07 01 00 00    	jae    77c284 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1d4>
  77c17d:	42 ff 04 a0          	incl   (%rax,%r12,4)
  77c181:	49 83 c5 28          	add    $0x28,%r13
  77c185:	4d 39 eb             	cmp    %r13,%r11
  77c188:	75 d6                	jne    77c160 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0xb0>
  77c18a:	8b 08                	mov    (%rax),%ecx
  77c18c:	4d 8d 69 01          	lea    0x1(%r9),%r13
  77c190:	44 89 ea             	mov    %r13d,%edx
  77c193:	83 e2 03             	and    $0x3,%edx
  77c196:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  77c19c:	49 83 f9 03          	cmp    $0x3,%r9
  77c1a0:	72 57                	jb     77c1f9 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x149>
  77c1a2:	48 bb fc ff ff ff ff 	movabs $0x7fffffffffffffc,%rbx
  77c1a9:	ff ff 07 
  77c1ac:	49 21 dd             	and    %rbx,%r13
  77c1af:	45 31 e4             	xor    %r12d,%r12d
  77c1b2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c1b9:	1f 84 00 00 00 00 00 
  77c1c0:	42 03 4c a0 04       	add    0x4(%rax,%r12,4),%ecx
  77c1c5:	42 89 4c a0 04       	mov    %ecx,0x4(%rax,%r12,4)
  77c1ca:	42 03 4c a0 08       	add    0x8(%rax,%r12,4),%ecx
  77c1cf:	42 89 4c a0 08       	mov    %ecx,0x8(%rax,%r12,4)
  77c1d4:	42 03 4c a0 0c       	add    0xc(%rax,%r12,4),%ecx
  77c1d9:	42 89 4c a0 0c       	mov    %ecx,0xc(%rax,%r12,4)
  77c1de:	42 03 4c a0 10       	add    0x10(%rax,%r12,4),%ecx
  77c1e3:	42 89 4c a0 10       	mov    %ecx,0x10(%rax,%r12,4)
  77c1e8:	49 83 c4 04          	add    $0x4,%r12
  77c1ec:	4d 39 e5             	cmp    %r12,%r13
  77c1ef:	75 cf                	jne    77c1c0 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x110>
  77c1f1:	48 85 d2             	test   %rdx,%rdx
  77c1f4:	74 1a                	je     77c210 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x160>
  77c1f6:	49 ff c4             	inc    %r12
  77c1f9:	4a 8d 1c a0          	lea    (%rax,%r12,4),%rbx
  77c1fd:	45 31 e4             	xor    %r12d,%r12d
  77c200:	42 03 0c a3          	add    (%rbx,%r12,4),%ecx
  77c204:	42 89 0c a3          	mov    %ecx,(%rbx,%r12,4)
  77c208:	49 ff c4             	inc    %r12
  77c20b:	4c 39 e2             	cmp    %r12,%rdx
  77c20e:	75 f0                	jne    77c200 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x150>
  77c210:	45 31 ed             	xor    %r13d,%r13d
  77c213:	bd ff ff ff ff       	mov    $0xffffffff,%ebp
  77c218:	48 8d 15 91 4c 34 00 	lea    0x344c91(%rip),%rdx        # ac0eb0 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0x88>
  77c21f:	45 31 e4             	xor    %r12d,%r12d
  77c222:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  77c229:	1f 84 00 00 00 00 00 
  77c230:	43 8b 5c 27 18       	mov    0x18(%r15,%r12,1),%ebx
  77c235:	48 8d 4b 01          	lea    0x1(%rbx),%rcx
  77c239:	48 39 eb             	cmp    %rbp,%rbx
  77c23c:	bb 00 00 00 00       	mov    $0x0,%ebx
  77c241:	48 0f 45 d9          	cmovne %rcx,%rbx
  77c245:	4c 39 c3             	cmp    %r8,%rbx
  77c248:	73 47                	jae    77c291 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1e1>
  77c24a:	43 8b 4c 27 1c       	mov    0x1c(%r15,%r12,1),%ecx
  77c24f:	03 0c 98             	add    (%rax,%rbx,4),%ecx
  77c252:	49 39 c9             	cmp    %rcx,%r9
  77c255:	76 35                	jbe    77c28c <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1dc>
  77c257:	45 89 2c 8a          	mov    %r13d,(%r10,%rcx,4)
  77c25b:	49 83 c4 28          	add    $0x28,%r12
  77c25f:	41 ff c5             	inc    %r13d
  77c262:	4d 39 e3             	cmp    %r12,%r11
  77c265:	75 c9                	jne    77c230 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x180>
  77c267:	48 89 37             	mov    %rsi,(%rdi)
  77c26a:	48 89 47 08          	mov    %rax,0x8(%rdi)
  77c26e:	48 89 77 10          	mov    %rsi,0x10(%rdi)
  77c272:	48 89 f8             	mov    %rdi,%rax
  77c275:	48 83 c4 08          	add    $0x8,%rsp
  77c279:	5b                   	pop    %rbx
  77c27a:	41 5c                	pop    %r12
  77c27c:	41 5d                	pop    %r13
  77c27e:	41 5e                	pop    %r14
  77c280:	41 5f                	pop    %r15
  77c282:	5d                   	pop    %rbp
  77c283:	c3                   	ret
  77c284:	49 89 c7             	mov    %rax,%r15
  77c287:	4d 89 c6             	mov    %r8,%r14
  77c28a:	eb 12                	jmp    77c29e <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1ee>
  77c28c:	49 89 c7             	mov    %rax,%r15
  77c28f:	eb 0d                	jmp    77c29e <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings3new+0x1ee>
  77c291:	49 89 c7             	mov    %rax,%r15
  77c294:	4d 89 c6             	mov    %r8,%r14
  77c297:	48 8d 15 fa 4b 34 00 	lea    0x344bfa(%rip),%rdx        # ac0e98 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0x70>
  77c29e:	48 89 cf             	mov    %rcx,%rdi
  77c2a1:	4c 89 f6             	mov    %r14,%rsi
  77c2a4:	ff 15 46 bc 36 00    	call   *0x36bc46(%rip)        # ae7ef0 <_DYNAMIC+0x358>
  77c2aa:	0f 0b                	ud2
  77c2ac:	bf 04 00 00 00       	mov    $0x4,%edi
  77c2b1:	48 8b 34 24          	mov    (%rsp),%rsi
  77c2b5:	ff 15 05 bc 36 00    	call   *0x36bc05(%rip)        # ae7ec0 <_DYNAMIC+0x328>
  77c2bb:	49 89 c6             	mov    %rax,%r14
  77c2be:	ba 04 00 00 00       	mov    $0x4,%edx
  77c2c3:	4c 89 ff             	mov    %r15,%rdi
  77c2c6:	48 8b 34 24          	mov    (%rsp),%rsi
  77c2ca:	ff 15 10 bb 36 00    	call   *0x36bb10(%rip)        # ae7de0 <_DYNAMIC+0x248>
  77c2d0:	4c 89 f7             	mov    %r14,%rdi
  77c2d3:	e8 78 c2 33 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
