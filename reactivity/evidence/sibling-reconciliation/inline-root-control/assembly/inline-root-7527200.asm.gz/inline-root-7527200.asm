
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072db20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_>:
  72db20:	48 89 f0             	mov    %rsi,%rax
  72db23:	48 d1 e8             	shr    $1,%rax
  72db26:	48 01 f0             	add    %rsi,%rax
  72db29:	75 0a                	jne    72db35 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x15>
  72db2b:	c3                   	ret
  72db2c:	0f 1f 40 00          	nopl   0x0(%rax)
  72db30:	48 85 c0             	test   %rax,%rax
  72db33:	74 f6                	je     72db2b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0xb>
  72db35:	48 ff c8             	dec    %rax
  72db38:	48 89 c1             	mov    %rax,%rcx
  72db3b:	48 29 f1             	sub    %rsi,%rcx
  72db3e:	73 0c                	jae    72db4c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x2c>
  72db40:	8b 0f                	mov    (%rdi),%ecx
  72db42:	8b 14 87             	mov    (%rdi,%rax,4),%edx
  72db45:	89 17                	mov    %edx,(%rdi)
  72db47:	89 0c 87             	mov    %ecx,(%rdi,%rax,4)
  72db4a:	31 c9                	xor    %ecx,%ecx
  72db4c:	48 39 c6             	cmp    %rax,%rsi
  72db4f:	48 89 c2             	mov    %rax,%rdx
  72db52:	48 0f 42 d6          	cmovb  %rsi,%rdx
  72db56:	4c 8d 04 4d 01 00 00 	lea    0x1(,%rcx,2),%r8
  72db5d:	00 
  72db5e:	49 39 d0             	cmp    %rdx,%r8
  72db61:	73 cd                	jae    72db30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>
  72db63:	4c 8d 0c 09          	lea    (%rcx,%rcx,1),%r9
  72db67:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72db6e:	00 00 
  72db70:	4d 8d 51 02          	lea    0x2(%r9),%r10
  72db74:	49 39 d2             	cmp    %rdx,%r10
  72db77:	73 0d                	jae    72db86 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x66>
  72db79:	46 8b 14 87          	mov    (%rdi,%r8,4),%r10d
  72db7d:	46 3b 54 8f 08       	cmp    0x8(%rdi,%r9,4),%r10d
  72db82:	49 83 d0 00          	adc    $0x0,%r8
  72db86:	4d 89 c2             	mov    %r8,%r10
  72db89:	44 8b 04 8f          	mov    (%rdi,%rcx,4),%r8d
  72db8d:	46 8b 0c 97          	mov    (%rdi,%r10,4),%r9d
  72db91:	45 39 c8             	cmp    %r9d,%r8d
  72db94:	73 9a                	jae    72db30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>
  72db96:	44 89 0c 8f          	mov    %r9d,(%rdi,%rcx,4)
  72db9a:	46 89 04 97          	mov    %r8d,(%rdi,%r10,4)
  72db9e:	4f 8d 0c 12          	lea    (%r10,%r10,1),%r9
  72dba2:	4e 8d 04 55 01 00 00 	lea    0x1(,%r10,2),%r8
  72dba9:	00 
  72dbaa:	4c 89 d1             	mov    %r10,%rcx
  72dbad:	49 39 d0             	cmp    %rdx,%r8
  72dbb0:	72 be                	jb     72db70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x50>
  72dbb2:	e9 79 ff ff ff       	jmp    72db30 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_+0x10>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
