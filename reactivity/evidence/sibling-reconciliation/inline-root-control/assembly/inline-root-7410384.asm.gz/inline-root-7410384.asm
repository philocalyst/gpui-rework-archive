
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000007112d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_>:
  7112d0:	48 8d 42 ff          	lea    -0x1(%rdx),%rax
  7112d4:	48 39 f0             	cmp    %rsi,%rax
  7112d7:	0f 83 91 00 00 00    	jae    71136e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x9e>
  7112dd:	48 39 f2             	cmp    %rsi,%rdx
  7112e0:	75 01                	jne    7112e3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x13>
  7112e2:	c3                   	ret
  7112e3:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
  7112e7:	48 8d 04 c7          	lea    (%rdi,%rax,8),%rax
  7112eb:	48 c1 e2 03          	shl    $0x3,%rdx
  7112ef:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  7112f3:	48 8d 14 0f          	lea    (%rdi,%rcx,1),%rdx
  7112f7:	eb 24                	jmp    71131d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x4d>
  7112f9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  711300:	49 89 f8             	mov    %rdi,%r8
  711303:	49 89 30             	mov    %rsi,(%r8)
  711306:	0f 28 44 24 e8       	movaps -0x18(%rsp),%xmm0
  71130b:	41 0f 11 40 08       	movups %xmm0,0x8(%r8)
  711310:	48 83 c2 18          	add    $0x18,%rdx
  711314:	48 83 c1 18          	add    $0x18,%rcx
  711318:	48 39 c2             	cmp    %rax,%rdx
  71131b:	74 c5                	je     7112e2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x12>
  71131d:	48 8b 32             	mov    (%rdx),%rsi
  711320:	48 3b 72 e8          	cmp    -0x18(%rdx),%rsi
  711324:	73 ea                	jae    711310 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x40>
  711326:	0f 10 42 08          	movups 0x8(%rdx),%xmm0
  71132a:	0f 29 44 24 e8       	movaps %xmm0,-0x18(%rsp)
  71132f:	49 89 c9             	mov    %rcx,%r9
  711332:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  711339:	1f 84 00 00 00 00 00 
  711340:	4e 8b 44 0f f8       	mov    -0x8(%rdi,%r9,1),%r8
  711345:	4e 89 44 0f 10       	mov    %r8,0x10(%rdi,%r9,1)
  71134a:	42 0f 10 44 0f e8    	movups -0x18(%rdi,%r9,1),%xmm0
  711350:	42 0f 11 04 0f       	movups %xmm0,(%rdi,%r9,1)
  711355:	49 83 f9 18          	cmp    $0x18,%r9
  711359:	74 a5                	je     711300 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x30>
  71135b:	4d 8d 41 e8          	lea    -0x18(%r9),%r8
  71135f:	4a 3b 74 0f d0       	cmp    -0x30(%rdi,%r9,1),%rsi
  711364:	4d 89 c1             	mov    %r8,%r9
  711367:	72 d7                	jb     711340 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x70>
  711369:	49 01 f8             	add    %rdi,%r8
  71136c:	eb 95                	jmp    711303 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1m_20sort_unstable_by_keyyNCNvMst_B1q_INtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB3f_+0x33>
  71136e:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
