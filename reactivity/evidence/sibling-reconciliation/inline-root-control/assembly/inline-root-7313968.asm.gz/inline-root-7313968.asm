
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006f9a30 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCshBhuxcId5D0_4gpui7runtime8siblings8SiblingsECs4gwBMgNbBwV_27sibling_reconciliation_cost>:
  6f9a30:	48 b8 02 00 00 00 00 	movabs $0x8000000000000002,%rax
  6f9a37:	00 00 80 
  6f9a3a:	48 39 c7             	cmp    %rax,%rdi
  6f9a3d:	7c 05                	jl     6f9a44 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCshBhuxcId5D0_4gpui7runtime8siblings8SiblingsECs4gwBMgNbBwV_27sibling_reconciliation_cost+0x14>
  6f9a3f:	48 85 ff             	test   %rdi,%rdi
  6f9a42:	75 01                	jne    6f9a45 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCshBhuxcId5D0_4gpui7runtime8siblings8SiblingsECs4gwBMgNbBwV_27sibling_reconciliation_cost+0x15>
  6f9a44:	c3                   	ret
  6f9a45:	48 c1 e7 02          	shl    $0x2,%rdi
  6f9a49:	ba 04 00 00 00       	mov    $0x4,%edx
  6f9a4e:	48 89 f8             	mov    %rdi,%rax
  6f9a51:	48 89 f7             	mov    %rsi,%rdi
  6f9a54:	48 89 c6             	mov    %rax,%rsi
  6f9a57:	ff 25 83 e3 3e 00    	jmp    *0x3ee383(%rip)        # ae7de0 <_DYNAMIC+0x248>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
