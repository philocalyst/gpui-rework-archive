
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072c380 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>:
  72c380:	55                   	push   %rbp
  72c381:	41 57                	push   %r15
  72c383:	41 56                	push   %r14
  72c385:	41 55                	push   %r13
  72c387:	41 54                	push   %r12
  72c389:	53                   	push   %rbx
  72c38a:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
  72c391:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  72c396:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  72c39b:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  72c3a0:	48 83 fe 02          	cmp    $0x2,%rsi
  72c3a4:	0f 82 44 06 00 00    	jb     72c9ee <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x66e>
  72c3aa:	49 89 cd             	mov    %rcx,%r13
  72c3ad:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  72c3b4:	00 00 40 
  72c3b7:	48 89 d1             	mov    %rdx,%rcx
  72c3ba:	31 d2                	xor    %edx,%edx
  72c3bc:	48 f7 f6             	div    %rsi
  72c3bf:	48 83 fa 01          	cmp    $0x1,%rdx
  72c3c3:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72c3c7:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  72c3cc:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  72c3d3:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  72c3d8:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  72c3dd:	73 1e                	jae    72c3fd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x7d>
  72c3df:	48 89 ca             	mov    %rcx,%rdx
  72c3e2:	48 89 f0             	mov    %rsi,%rax
  72c3e5:	48 d1 e8             	shr    $1,%rax
  72c3e8:	48 89 f1             	mov    %rsi,%rcx
  72c3eb:	48 29 c1             	sub    %rax,%rcx
  72c3ee:	48 83 f9 40          	cmp    $0x40,%rcx
  72c3f2:	b8 40 00 00 00       	mov    $0x40,%eax
  72c3f7:	48 0f 42 c1          	cmovb  %rcx,%rax
  72c3fb:	eb 0e                	jmp    72c40b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x8b>
  72c3fd:	48 89 f7             	mov    %rsi,%rdi
  72c400:	ff 15 ba bf 3b 00    	call   *0x3bbfba(%rip)        # ae83c0 <_DYNAMIC+0x828>
  72c406:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c40b:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72c410:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72c415:	48 8d 48 20          	lea    0x20(%rax),%rcx
  72c419:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  72c41e:	48 8d 48 10          	lea    0x10(%rax),%rcx
  72c422:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  72c427:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  72c42b:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  72c430:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  72c436:	31 ed                	xor    %ebp,%ebp
  72c438:	45 31 c9             	xor    %r9d,%r9d
  72c43b:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  72c442:	00 
  72c443:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72c448:	48 29 ee             	sub    %rbp,%rsi
  72c44b:	77 23                	ja     72c470 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xf0>
  72c44d:	0f 1f 00             	nopl   (%rax)
  72c450:	31 ff                	xor    %edi,%edi
  72c452:	be 01 00 00 00       	mov    $0x1,%esi
  72c457:	49 83 f9 02          	cmp    $0x2,%r9
  72c45b:	0f 83 df 00 00 00    	jae    72c540 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1c0>
  72c461:	e9 80 03 00 00       	jmp    72c7e6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  72c466:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72c46d:	00 00 00 
  72c470:	48 89 e9             	mov    %rbp,%rcx
  72c473:	48 c1 e1 04          	shl    $0x4,%rcx
  72c477:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72c47c:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
  72c480:	48 3b 74 24 18       	cmp    0x18(%rsp),%rsi
  72c485:	73 49                	jae    72c4d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x150>
  72c487:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  72c48c:	74 62                	je     72c4f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x170>
  72c48e:	48 83 fe 20          	cmp    $0x20,%rsi
  72c492:	b8 20 00 00 00       	mov    $0x20,%eax
  72c497:	48 0f 43 f0          	cmovae %rax,%rsi
  72c49b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72c4a0:	48 89 04 24          	mov    %rax,(%rsp)
  72c4a4:	4c 89 e9             	mov    %r13,%rcx
  72c4a7:	45 31 c0             	xor    %r8d,%r8d
  72c4aa:	4c 89 cb             	mov    %r9,%rbx
  72c4ad:	45 31 c9             	xor    %r9d,%r9d
  72c4b0:	49 89 f6             	mov    %rsi,%r14
  72c4b3:	e8 48 24 00 00       	call   72e900 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72c4b8:	49 89 d9             	mov    %rbx,%r9
  72c4bb:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c4c0:	44 89 f0             	mov    %r14d,%eax
  72c4c3:	eb 18                	jmp    72c4dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c4c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72c4cc:	00 00 00 00 
  72c4d0:	48 83 fe 02          	cmp    $0x2,%rsi
  72c4d4:	0f 83 56 03 00 00    	jae    72c830 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x4b0>
  72c4da:	48 89 f0             	mov    %rsi,%rax
  72c4dd:	48 8d 34 45 01 00 00 	lea    0x1(,%rax,2),%rsi
  72c4e4:	00 
  72c4e5:	eb 18                	jmp    72c4ff <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x17f>
  72c4e7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72c4ee:	00 00 
  72c4f0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72c4f5:	48 39 c6             	cmp    %rax,%rsi
  72c4f8:	48 0f 43 f0          	cmovae %rax,%rsi
  72c4fc:	48 01 f6             	add    %rsi,%rsi
  72c4ff:	4c 89 e0             	mov    %r12,%rax
  72c502:	48 d1 e8             	shr    $1,%rax
  72c505:	48 89 f1             	mov    %rsi,%rcx
  72c508:	48 d1 e9             	shr    $1,%rcx
  72c50b:	48 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%rdi
  72c512:	00 
  72c513:	48 29 c7             	sub    %rax,%rdi
  72c516:	48 8d 04 69          	lea    (%rcx,%rbp,2),%rax
  72c51a:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  72c51f:	48 0f af f9          	imul   %rcx,%rdi
  72c523:	48 0f af c1          	imul   %rcx,%rax
  72c527:	48 31 f8             	xor    %rdi,%rax
  72c52a:	bf 7f 00 00 00       	mov    $0x7f,%edi
  72c52f:	48 0f bd f8          	bsr    %rax,%rdi
  72c533:	83 f7 3f             	xor    $0x3f,%edi
  72c536:	49 83 f9 02          	cmp    $0x2,%r9
  72c53a:	0f 82 a6 02 00 00    	jb     72c7e6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  72c540:	48 89 e9             	mov    %rbp,%rcx
  72c543:	48 c1 e1 04          	shl    $0x4,%rcx
  72c547:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72c54c:	48 01 c8             	add    %rcx,%rax
  72c54f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  72c554:	48 03 4c 24 58       	add    0x58(%rsp),%rcx
  72c559:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  72c55e:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  72c563:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  72c568:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  72c56f:	00 
  72c570:	eb 4b                	jmp    72c5bd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x23d>
  72c572:	4c 89 ed             	mov    %r13,%rbp
  72c575:	4c 89 c6             	mov    %r8,%rsi
  72c578:	49 29 f4             	sub    %rsi,%r12
  72c57b:	48 89 ef             	mov    %rbp,%rdi
  72c57e:	4c 89 e2             	mov    %r12,%rdx
  72c581:	ff 15 81 b8 3b 00    	call   *0x3bb881(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72c587:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  72c58e:	00 
  72c58f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c594:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72c599:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72c59e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72c5a3:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  72c5aa:	00 
  72c5ab:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
  72c5b2:	00 
  72c5b3:	49 83 f9 01          	cmp    $0x1,%r9
  72c5b7:	0f 86 23 02 00 00    	jbe    72c7e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x460>
  72c5bd:	42 38 bc 0c 95 00 00 	cmp    %dil,0x95(%rsp,%r9,1)
  72c5c4:	00 
  72c5c5:	0f 82 1b 02 00 00    	jb     72c7e6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x466>
  72c5cb:	49 ff c9             	dec    %r9
  72c5ce:	4a 8b 84 cc d8 00 00 	mov    0xd8(%rsp,%r9,8),%rax
  72c5d5:	00 
  72c5d6:	48 89 c3             	mov    %rax,%rbx
  72c5d9:	48 d1 eb             	shr    $1,%rbx
  72c5dc:	4d 89 e7             	mov    %r12,%r15
  72c5df:	49 d1 ef             	shr    $1,%r15
  72c5e2:	4e 8d 34 3b          	lea    (%rbx,%r15,1),%r14
  72c5e6:	4d 39 ee             	cmp    %r13,%r14
  72c5e9:	77 25                	ja     72c610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x290>
  72c5eb:	89 c1                	mov    %eax,%ecx
  72c5ed:	44 09 e1             	or     %r12d,%ecx
  72c5f0:	83 e1 01             	and    $0x1,%ecx
  72c5f3:	75 1b                	jne    72c610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x290>
  72c5f5:	4d 01 f6             	add    %r14,%r14
  72c5f8:	4d 89 f4             	mov    %r14,%r12
  72c5fb:	49 83 f9 01          	cmp    $0x1,%r9
  72c5ff:	77 bc                	ja     72c5bd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x23d>
  72c601:	e9 da 01 00 00       	jmp    72c7e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x460>
  72c606:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72c60d:	00 00 00 
  72c610:	4c 29 f5             	sub    %r14,%rbp
  72c613:	48 c1 e5 04          	shl    $0x4,%rbp
  72c617:	48 03 6c 24 10       	add    0x10(%rsp),%rbp
  72c61c:	a8 01                	test   $0x1,%al
  72c61e:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  72c623:	75 5b                	jne    72c680 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x300>
  72c625:	48 89 d8             	mov    %rbx,%rax
  72c628:	48 83 c8 01          	or     $0x1,%rax
  72c62c:	4c 0f bd c0          	bsr    %rax,%r8
  72c630:	41 83 f0 3f          	xor    $0x3f,%r8d
  72c634:	45 01 c0             	add    %r8d,%r8d
  72c637:	41 83 f0 7e          	xor    $0x7e,%r8d
  72c63b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72c640:	48 89 04 24          	mov    %rax,(%rsp)
  72c644:	48 89 ef             	mov    %rbp,%rdi
  72c647:	48 89 de             	mov    %rbx,%rsi
  72c64a:	4c 89 e9             	mov    %r13,%rcx
  72c64d:	45 31 c9             	xor    %r9d,%r9d
  72c650:	e8 ab 22 00 00       	call   72e900 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72c655:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72c65a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72c65f:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72c664:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c669:	41 f6 c4 01          	test   $0x1,%r12b
  72c66d:	74 17                	je     72c686 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x306>
  72c66f:	4d 85 ff             	test   %r15,%r15
  72c672:	75 66                	jne    72c6da <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x35a>
  72c674:	e9 2a ff ff ff       	jmp    72c5a3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  72c679:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72c680:	41 f6 c4 01          	test   $0x1,%r12b
  72c684:	75 e9                	jne    72c66f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x2ef>
  72c686:	48 89 df             	mov    %rbx,%rdi
  72c689:	48 c1 e7 04          	shl    $0x4,%rdi
  72c68d:	48 01 ef             	add    %rbp,%rdi
  72c690:	4c 89 f8             	mov    %r15,%rax
  72c693:	48 83 c8 01          	or     $0x1,%rax
  72c697:	4c 0f bd c0          	bsr    %rax,%r8
  72c69b:	41 83 f0 3f          	xor    $0x3f,%r8d
  72c69f:	45 01 c0             	add    %r8d,%r8d
  72c6a2:	41 83 f0 7e          	xor    $0x7e,%r8d
  72c6a6:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72c6ab:	48 89 04 24          	mov    %rax,(%rsp)
  72c6af:	4c 89 fe             	mov    %r15,%rsi
  72c6b2:	4c 89 e9             	mov    %r13,%rcx
  72c6b5:	45 31 c9             	xor    %r9d,%r9d
  72c6b8:	e8 43 22 00 00       	call   72e900 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72c6bd:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72c6c2:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72c6c7:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72c6cc:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c6d1:	4d 85 ff             	test   %r15,%r15
  72c6d4:	0f 84 c9 fe ff ff    	je     72c5a3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  72c6da:	48 85 db             	test   %rbx,%rbx
  72c6dd:	0f 84 c0 fe ff ff    	je     72c5a3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  72c6e3:	49 39 df             	cmp    %rbx,%r15
  72c6e6:	49 89 dc             	mov    %rbx,%r12
  72c6e9:	4d 0f 42 e7          	cmovb  %r15,%r12
  72c6ed:	4d 39 e5             	cmp    %r12,%r13
  72c6f0:	0f 82 ad fe ff ff    	jb     72c5a3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x223>
  72c6f6:	49 89 dd             	mov    %rbx,%r13
  72c6f9:	49 c1 e5 04          	shl    $0x4,%r13
  72c6fd:	49 01 ed             	add    %rbp,%r13
  72c700:	4c 39 fb             	cmp    %r15,%rbx
  72c703:	48 89 ee             	mov    %rbp,%rsi
  72c706:	49 0f 47 f5          	cmova  %r13,%rsi
  72c70a:	49 c1 e4 04          	shl    $0x4,%r12
  72c70e:	48 89 d7             	mov    %rdx,%rdi
  72c711:	4c 89 e2             	mov    %r12,%rdx
  72c714:	ff 15 ee b6 3b 00    	call   *0x3bb6ee(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72c71a:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  72c71f:	4d 01 c4             	add    %r8,%r12
  72c722:	4c 39 fb             	cmp    %r15,%rbx
  72c725:	76 5c                	jbe    72c783 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x403>
  72c727:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  72c72c:	0f 1f 40 00          	nopl   0x0(%rax)
  72c730:	49 8d 4d f0          	lea    -0x10(%r13),%rcx
  72c734:	49 8b 54 24 f0       	mov    -0x10(%r12),%rdx
  72c739:	31 f6                	xor    %esi,%esi
  72c73b:	31 ff                	xor    %edi,%edi
  72c73d:	49 3b 55 f0          	cmp    -0x10(%r13),%rdx
  72c741:	49 8d 54 24 f0       	lea    -0x10(%r12),%rdx
  72c746:	40 0f 92 c6          	setb   %sil
  72c74a:	48 0f 42 d1          	cmovb  %rcx,%rdx
  72c74e:	40 0f 93 c7          	setae  %dil
  72c752:	0f 10 02             	movups (%rdx),%xmm0
  72c755:	0f 11 00             	movups %xmm0,(%rax)
  72c758:	c1 e7 04             	shl    $0x4,%edi
  72c75b:	49 01 fd             	add    %rdi,%r13
  72c75e:	49 83 c5 f0          	add    $0xfffffffffffffff0,%r13
  72c762:	c1 e6 04             	shl    $0x4,%esi
  72c765:	49 01 f4             	add    %rsi,%r12
  72c768:	49 83 c4 f0          	add    $0xfffffffffffffff0,%r12
  72c76c:	49 39 ed             	cmp    %rbp,%r13
  72c76f:	0f 84 fd fd ff ff    	je     72c572 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f2>
  72c775:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  72c779:	4d 39 c4             	cmp    %r8,%r12
  72c77c:	75 b2                	jne    72c730 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x3b0>
  72c77e:	e9 ef fd ff ff       	jmp    72c572 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f2>
  72c783:	4c 89 c6             	mov    %r8,%rsi
  72c786:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  72c78b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72c790:	48 89 f2             	mov    %rsi,%rdx
  72c793:	49 8b 4d 00          	mov    0x0(%r13),%rcx
  72c797:	31 c0                	xor    %eax,%eax
  72c799:	31 f6                	xor    %esi,%esi
  72c79b:	48 3b 0a             	cmp    (%rdx),%rcx
  72c79e:	0f 92 c1             	setb   %cl
  72c7a1:	40 0f 93 c6          	setae  %sil
  72c7a5:	48 89 d7             	mov    %rdx,%rdi
  72c7a8:	49 0f 42 fd          	cmovb  %r13,%rdi
  72c7ac:	0f 10 07             	movups (%rdi),%xmm0
  72c7af:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
  72c7b3:	c1 e6 04             	shl    $0x4,%esi
  72c7b6:	48 01 d6             	add    %rdx,%rsi
  72c7b9:	48 83 c5 10          	add    $0x10,%rbp
  72c7bd:	4c 39 e6             	cmp    %r12,%rsi
  72c7c0:	0f 84 b2 fd ff ff    	je     72c578 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f8>
  72c7c6:	88 c8                	mov    %cl,%al
  72c7c8:	c1 e0 04             	shl    $0x4,%eax
  72c7cb:	49 01 c5             	add    %rax,%r13
  72c7ce:	4d 39 c5             	cmp    %r8,%r13
  72c7d1:	75 bd                	jne    72c790 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x410>
  72c7d3:	e9 a0 fd ff ff       	jmp    72c578 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x1f8>
  72c7d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72c7df:	00 
  72c7e0:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  72c7e6:	4e 89 a4 cc d8 00 00 	mov    %r12,0xd8(%rsp,%r9,8)
  72c7ed:	00 
  72c7ee:	42 88 bc 0c 96 00 00 	mov    %dil,0x96(%rsp,%r9,1)
  72c7f5:	00 
  72c7f6:	48 39 6c 24 28       	cmp    %rbp,0x28(%rsp)
  72c7fb:	0f 86 b3 01 00 00    	jbe    72c9b4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x634>
  72c801:	49 ff c1             	inc    %r9
  72c804:	48 89 f0             	mov    %rsi,%rax
  72c807:	48 d1 e8             	shr    $1,%rax
  72c80a:	48 01 c5             	add    %rax,%rbp
  72c80d:	49 89 f4             	mov    %rsi,%r12
  72c810:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72c815:	48 29 ee             	sub    %rbp,%rsi
  72c818:	0f 87 52 fc ff ff    	ja     72c470 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xf0>
  72c81e:	e9 2d fc ff ff       	jmp    72c450 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0xd0>
  72c823:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72c82a:	84 00 00 00 00 00 
  72c830:	4c 8b 1f             	mov    (%rdi),%r11
  72c833:	4c 8b 77 10          	mov    0x10(%rdi),%r14
  72c837:	4d 39 de             	cmp    %r11,%r14
  72c83a:	49 89 f7             	mov    %rsi,%r15
  72c83d:	73 15                	jae    72c854 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x4d4>
  72c83f:	48 83 fe 02          	cmp    $0x2,%rsi
  72c843:	75 54                	jne    72c899 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x519>
  72c845:	b8 02 00 00 00       	mov    $0x2,%eax
  72c84a:	be 01 00 00 00       	mov    $0x1,%esi
  72c84f:	e9 af 00 00 00       	jmp    72c903 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x583>
  72c854:	b8 02 00 00 00       	mov    $0x2,%eax
  72c859:	48 83 fe 02          	cmp    $0x2,%rsi
  72c85d:	0f 84 7a fc ff ff    	je     72c4dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c863:	4c 89 cb             	mov    %r9,%rbx
  72c866:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72c86b:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  72c86f:	b8 02 00 00 00       	mov    $0x2,%eax
  72c874:	4d 89 f1             	mov    %r14,%r9
  72c877:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72c87e:	00 00 
  72c880:	4d 89 ca             	mov    %r9,%r10
  72c883:	4d 8b 08             	mov    (%r8),%r9
  72c886:	4d 39 d1             	cmp    %r10,%r9
  72c889:	72 52                	jb     72c8dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x55d>
  72c88b:	48 ff c0             	inc    %rax
  72c88e:	49 83 c0 10          	add    $0x10,%r8
  72c892:	49 39 c7             	cmp    %rax,%r15
  72c895:	75 e9                	jne    72c880 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x500>
  72c897:	eb 2e                	jmp    72c8c7 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x547>
  72c899:	4c 89 cb             	mov    %r9,%rbx
  72c89c:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72c8a1:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  72c8a5:	b8 02 00 00 00       	mov    $0x2,%eax
  72c8aa:	4d 89 f1             	mov    %r14,%r9
  72c8ad:	0f 1f 00             	nopl   (%rax)
  72c8b0:	4d 89 ca             	mov    %r9,%r10
  72c8b3:	4d 8b 08             	mov    (%r8),%r9
  72c8b6:	4d 39 d1             	cmp    %r10,%r9
  72c8b9:	73 22                	jae    72c8dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x55d>
  72c8bb:	48 ff c0             	inc    %rax
  72c8be:	49 83 c0 10          	add    $0x10,%r8
  72c8c2:	49 39 c7             	cmp    %rax,%r15
  72c8c5:	75 e9                	jne    72c8b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x530>
  72c8c7:	4c 89 fe             	mov    %r15,%rsi
  72c8ca:	4c 89 f8             	mov    %r15,%rax
  72c8cd:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  72c8d2:	49 89 d9             	mov    %rbx,%r9
  72c8d5:	0f 82 ac fb ff ff    	jb     72c487 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x107>
  72c8db:	eb 11                	jmp    72c8ee <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x56e>
  72c8dd:	4c 89 fe             	mov    %r15,%rsi
  72c8e0:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  72c8e5:	49 89 d9             	mov    %rbx,%r9
  72c8e8:	0f 82 99 fb ff ff    	jb     72c487 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x107>
  72c8ee:	4d 39 de             	cmp    %r11,%r14
  72c8f1:	0f 83 e6 fb ff ff    	jae    72c4dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c8f7:	48 89 c6             	mov    %rax,%rsi
  72c8fa:	48 d1 ee             	shr    $1,%rsi
  72c8fd:	0f 84 da fb ff ff    	je     72c4dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c903:	49 89 c0             	mov    %rax,%r8
  72c906:	49 c1 e0 04          	shl    $0x4,%r8
  72c90a:	4a 8d 1c 07          	lea    (%rdi,%r8,1),%rbx
  72c90e:	48 83 fe 01          	cmp    $0x1,%rsi
  72c912:	75 04                	jne    72c918 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x598>
  72c914:	31 c9                	xor    %ecx,%ecx
  72c916:	eb 79                	jmp    72c991 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x611>
  72c918:	4d 89 ce             	mov    %r9,%r14
  72c91b:	49 89 f1             	mov    %rsi,%r9
  72c91e:	49 83 e1 fe          	and    $0xfffffffffffffffe,%r9
  72c922:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  72c927:	4c 8d 14 0a          	lea    (%rdx,%rcx,1),%r10
  72c92b:	49 01 c8             	add    %rcx,%r8
  72c92e:	4c 03 44 24 58       	add    0x58(%rsp),%r8
  72c933:	31 c9                	xor    %ecx,%ecx
  72c935:	48 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%rdx
  72c93c:	ff ff 0f 
  72c93f:	90                   	nop
  72c940:	41 0f 10 42 f0       	movups -0x10(%r10),%xmm0
  72c945:	41 0f 10 08          	movups (%r8),%xmm1
  72c949:	41 0f 11 4a f0       	movups %xmm1,-0x10(%r10)
  72c94e:	41 0f 11 00          	movups %xmm0,(%r8)
  72c952:	49 89 cb             	mov    %rcx,%r11
  72c955:	49 31 d3             	xor    %rdx,%r11
  72c958:	49 c1 e3 04          	shl    $0x4,%r11
  72c95c:	41 0f 10 02          	movups (%r10),%xmm0
  72c960:	42 0f 10 0c 1b       	movups (%rbx,%r11,1),%xmm1
  72c965:	41 0f 11 0a          	movups %xmm1,(%r10)
  72c969:	42 0f 11 04 1b       	movups %xmm0,(%rbx,%r11,1)
  72c96e:	48 83 c1 02          	add    $0x2,%rcx
  72c972:	49 83 c2 20          	add    $0x20,%r10
  72c976:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
  72c97a:	49 39 c9             	cmp    %rcx,%r9
  72c97d:	75 c1                	jne    72c940 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x5c0>
  72c97f:	40 f6 c6 01          	test   $0x1,%sil
  72c983:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72c988:	4d 89 f1             	mov    %r14,%r9
  72c98b:	0f 84 4c fb ff ff    	je     72c4dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c991:	48 89 ce             	mov    %rcx,%rsi
  72c994:	48 f7 d6             	not    %rsi
  72c997:	48 c1 e1 04          	shl    $0x4,%rcx
  72c99b:	48 c1 e6 04          	shl    $0x4,%rsi
  72c99f:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  72c9a3:	0f 10 0c 33          	movups (%rbx,%rsi,1),%xmm1
  72c9a7:	0f 11 0c 0f          	movups %xmm1,(%rdi,%rcx,1)
  72c9ab:	0f 11 04 33          	movups %xmm0,(%rbx,%rsi,1)
  72c9af:	e9 29 fb ff ff       	jmp    72c4dd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x15d>
  72c9b4:	41 f6 c4 01          	test   $0x1,%r12b
  72c9b8:	75 34                	jne    72c9ee <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_+0x66e>
  72c9ba:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72c9bf:	48 89 f0             	mov    %rsi,%rax
  72c9c2:	48 83 c8 01          	or     $0x1,%rax
  72c9c6:	4c 0f bd c0          	bsr    %rax,%r8
  72c9ca:	41 83 f0 3f          	xor    $0x3f,%r8d
  72c9ce:	45 01 c0             	add    %r8d,%r8d
  72c9d1:	41 83 f0 7e          	xor    $0x7e,%r8d
  72c9d5:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72c9da:	48 89 04 24          	mov    %rax,(%rsp)
  72c9de:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  72c9e3:	4c 89 e9             	mov    %r13,%rcx
  72c9e6:	45 31 c9             	xor    %r9d,%r9d
  72c9e9:	e8 12 1f 00 00       	call   72e900 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters3map3MapINtNtB8_4iter4IterNtB19_9ListDraftENCNvMst_NtB1b_7runtimeINtB5C_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB67_>
  72c9ee:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
  72c9f5:	5b                   	pop    %rbx
  72c9f6:	41 5c                	pop    %r12
  72c9f8:	41 5d                	pop    %r13
  72c9fa:	41 5e                	pop    %r14
  72c9fc:	41 5f                	pop    %r15
  72c9fe:	5d                   	pop    %rbp
  72c9ff:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
