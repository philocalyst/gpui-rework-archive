
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000070ff90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_>:
  70ff90:	41 57                	push   %r15
  70ff92:	41 56                	push   %r14
  70ff94:	41 55                	push   %r13
  70ff96:	41 54                	push   %r12
  70ff98:	53                   	push   %rbx
  70ff99:	48 81 ec 90 04 00 00 	sub    $0x490,%rsp
  70ffa0:	48 83 fe 02          	cmp    $0x2,%rsi
  70ffa4:	0f 82 6a 04 00 00    	jb     710414 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x484>
  70ffaa:	49 89 f6             	mov    %rsi,%r14
  70ffad:	48 83 fe 20          	cmp    $0x20,%rsi
  70ffb1:	0f 87 af 04 00 00    	ja     710466 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x4d6>
  70ffb7:	48 89 fb             	mov    %rdi,%rbx
  70ffba:	4c 89 f0             	mov    %r14,%rax
  70ffbd:	48 d1 e8             	shr    $1,%rax
  70ffc0:	49 83 fe 07          	cmp    $0x7,%r14
  70ffc4:	0f 86 ba 01 00 00    	jbe    710184 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x1f4>
  70ffca:	48 8b 4b 18          	mov    0x18(%rbx),%rcx
  70ffce:	48 8b 53 48          	mov    0x48(%rbx),%rdx
  70ffd2:	45 31 c0             	xor    %r8d,%r8d
  70ffd5:	31 f6                	xor    %esi,%esi
  70ffd7:	48 3b 0b             	cmp    (%rbx),%rcx
  70ffda:	41 0f 93 c0          	setae  %r8b
  70ffde:	40 0f 92 c6          	setb   %sil
  70ffe2:	48 8d 7b 48          	lea    0x48(%rbx),%rdi
  70ffe6:	4c 8d 4b 30          	lea    0x30(%rbx),%r9
  70ffea:	48 3b 53 30          	cmp    0x30(%rbx),%rdx
  70ffee:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  70fff2:	4a 8d 34 d3          	lea    (%rbx,%r10,8),%rsi
  70fff6:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  70fffa:	4c 89 ca             	mov    %r9,%rdx
  70fffd:	48 0f 42 d7          	cmovb  %rdi,%rdx
  710001:	4a 8d 0c c3          	lea    (%rbx,%r8,8),%rcx
  710005:	49 0f 42 f9          	cmovb  %r9,%rdi
  710009:	4c 8b 0a             	mov    (%rdx),%r9
  71000c:	4c 8b 1f             	mov    (%rdi),%r11
  71000f:	4e 8b 04 c3          	mov    (%rbx,%r8,8),%r8
  710013:	4d 39 c3             	cmp    %r8,%r11
  710016:	49 89 cf             	mov    %rcx,%r15
  710019:	4c 0f 42 fa          	cmovb  %rdx,%r15
  71001d:	4e 3b 0c d3          	cmp    (%rbx,%r10,8),%r9
  710021:	4c 0f 42 fe          	cmovb  %rsi,%r15
  710025:	48 0f 42 f2          	cmovb  %rdx,%rsi
  710029:	48 0f 42 d1          	cmovb  %rcx,%rdx
  71002d:	4d 39 c3             	cmp    %r8,%r11
  710030:	48 0f 43 cf          	cmovae %rdi,%rcx
  710034:	48 0f 42 d7          	cmovb  %rdi,%rdx
  710038:	48 8b 3a             	mov    (%rdx),%rdi
  71003b:	49 3b 3f             	cmp    (%r15),%rdi
  71003e:	4c 89 ff             	mov    %r15,%rdi
  710041:	48 0f 42 fa          	cmovb  %rdx,%rdi
  710045:	49 0f 42 d7          	cmovb  %r15,%rdx
  710049:	4c 8b 46 10          	mov    0x10(%rsi),%r8
  71004d:	4c 89 44 24 20       	mov    %r8,0x20(%rsp)
  710052:	0f 10 06             	movups (%rsi),%xmm0
  710055:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  71005a:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  71005e:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  710063:	0f 10 07             	movups (%rdi),%xmm0
  710066:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
  71006b:	48 8b 72 10          	mov    0x10(%rdx),%rsi
  71006f:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  710074:	0f 10 02             	movups (%rdx),%xmm0
  710077:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  71007c:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
  710083:	00 
  710084:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  710088:	4c 8d 0c 13          	lea    (%rbx,%rdx,1),%r9
  71008c:	48 8b 74 13 18       	mov    0x18(%rbx,%rdx,1),%rsi
  710091:	48 8b 7c 13 48       	mov    0x48(%rbx,%rdx,1),%rdi
  710096:	45 31 d2             	xor    %r10d,%r10d
  710099:	45 31 db             	xor    %r11d,%r11d
  71009c:	48 3b 34 13          	cmp    (%rbx,%rdx,1),%rsi
  7100a0:	41 0f 93 c2          	setae  %r10b
  7100a4:	41 0f 92 c3          	setb   %r11b
  7100a8:	4c 8d 04 13          	lea    (%rbx,%rdx,1),%r8
  7100ac:	49 83 c0 48          	add    $0x48,%r8
  7100b0:	4c 8d 3c 13          	lea    (%rbx,%rdx,1),%r15
  7100b4:	49 83 c7 30          	add    $0x30,%r15
  7100b8:	48 3b 7c 13 30       	cmp    0x30(%rbx,%rdx,1),%rdi
  7100bd:	4f 8d 1c 5b          	lea    (%r11,%r11,2),%r11
  7100c1:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  7100c5:	4b 8d 34 d1          	lea    (%r9,%r10,8),%rsi
  7100c9:	4c 89 ff             	mov    %r15,%rdi
  7100cc:	49 0f 42 f8          	cmovb  %r8,%rdi
  7100d0:	4d 0f 42 c7          	cmovb  %r15,%r8
  7100d4:	4d 8b 38             	mov    (%r8),%r15
  7100d7:	4f 8b 14 d1          	mov    (%r9,%r10,8),%r10
  7100db:	4d 39 d7             	cmp    %r10,%r15
  7100de:	49 89 f4             	mov    %rsi,%r12
  7100e1:	4c 0f 42 e7          	cmovb  %rdi,%r12
  7100e5:	4c 8b 2f             	mov    (%rdi),%r13
  7100e8:	4f 3b 2c d9          	cmp    (%r9,%r11,8),%r13
  7100ec:	4f 8d 0c d9          	lea    (%r9,%r11,8),%r9
  7100f0:	4d 0f 42 e1          	cmovb  %r9,%r12
  7100f4:	4c 0f 42 cf          	cmovb  %rdi,%r9
  7100f8:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  7100fc:	48 0f 42 fe          	cmovb  %rsi,%rdi
  710100:	4d 39 d7             	cmp    %r10,%r15
  710103:	49 0f 43 f0          	cmovae %r8,%rsi
  710107:	49 0f 42 f8          	cmovb  %r8,%rdi
  71010b:	4c 89 5c 24 68       	mov    %r11,0x68(%rsp)
  710110:	4c 8b 07             	mov    (%rdi),%r8
  710113:	4d 3b 04 24          	cmp    (%r12),%r8
  710117:	0f 10 01             	movups (%rcx),%xmm0
  71011a:	4c 89 e1             	mov    %r12,%rcx
  71011d:	48 0f 42 cf          	cmovb  %rdi,%rcx
  710121:	0f 11 44 24 58       	movups %xmm0,0x58(%rsp)
  710126:	49 0f 42 fc          	cmovb  %r12,%rdi
  71012a:	4d 8b 41 10          	mov    0x10(%r9),%r8
  71012e:	4c 89 44 14 20       	mov    %r8,0x20(%rsp,%rdx,1)
  710133:	41 0f 10 01          	movups (%r9),%xmm0
  710137:	0f 11 44 14 10       	movups %xmm0,0x10(%rsp,%rdx,1)
  71013c:	0f 10 01             	movups (%rcx),%xmm0
  71013f:	0f 11 44 14 28       	movups %xmm0,0x28(%rsp,%rdx,1)
  710144:	48 8b 49 10          	mov    0x10(%rcx),%rcx
  710148:	48 89 4c 14 38       	mov    %rcx,0x38(%rsp,%rdx,1)
  71014d:	0f 10 07             	movups (%rdi),%xmm0
  710150:	0f 11 44 14 40       	movups %xmm0,0x40(%rsp,%rdx,1)
  710155:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
  710159:	48 89 4c 14 50       	mov    %rcx,0x50(%rsp,%rdx,1)
  71015e:	0f 10 06             	movups (%rsi),%xmm0
  710161:	0f 11 44 14 58       	movups %xmm0,0x58(%rsp,%rdx,1)
  710166:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  71016a:	48 89 4c 14 68       	mov    %rcx,0x68(%rsp,%rdx,1)
  71016f:	ba 04 00 00 00       	mov    $0x4,%edx
  710174:	4c 89 f6             	mov    %r14,%rsi
  710177:	48 29 c6             	sub    %rax,%rsi
  71017a:	48 39 c2             	cmp    %rax,%rdx
  71017d:	72 49                	jb     7101c8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x238>
  71017f:	e9 f3 00 00 00       	jmp    710277 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x2e7>
  710184:	48 8b 4b 10          	mov    0x10(%rbx),%rcx
  710188:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  71018d:	0f 10 03             	movups (%rbx),%xmm0
  710190:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  710195:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
  71019c:	00 
  71019d:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  7101a1:	48 8b 54 0b 10       	mov    0x10(%rbx,%rcx,1),%rdx
  7101a6:	48 89 54 0c 20       	mov    %rdx,0x20(%rsp,%rcx,1)
  7101ab:	0f 10 04 0b          	movups (%rbx,%rcx,1),%xmm0
  7101af:	0f 11 44 0c 10       	movups %xmm0,0x10(%rsp,%rcx,1)
  7101b4:	ba 01 00 00 00       	mov    $0x1,%edx
  7101b9:	4c 89 f6             	mov    %r14,%rsi
  7101bc:	48 29 c6             	sub    %rax,%rsi
  7101bf:	48 39 c2             	cmp    %rax,%rdx
  7101c2:	0f 83 af 00 00 00    	jae    710277 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x2e7>
  7101c8:	8d 0c d5 00 00 00 00 	lea    0x0(,%rdx,8),%ecx
  7101cf:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  7101d3:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  7101d8:	49 89 d0             	mov    %rdx,%r8
  7101db:	eb 1e                	jmp    7101fb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x26b>
  7101dd:	0f 1f 00             	nopl   (%rax)
  7101e0:	49 89 fa             	mov    %rdi,%r10
  7101e3:	4d 89 0a             	mov    %r9,(%r10)
  7101e6:	0f 28 04 24          	movaps (%rsp),%xmm0
  7101ea:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  7101ef:	49 ff c0             	inc    %r8
  7101f2:	48 83 c1 18          	add    $0x18,%rcx
  7101f6:	49 39 c0             	cmp    %rax,%r8
  7101f9:	74 7c                	je     710277 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x2e7>
  7101fb:	4e 8d 0c c5 00 00 00 	lea    0x0(,%r8,8),%r9
  710202:	00 
  710203:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  710207:	42 0f 10 04 13       	movups (%rbx,%r10,1),%xmm0
  71020c:	42 0f 11 44 14 10    	movups %xmm0,0x10(%rsp,%r10,1)
  710212:	4e 8b 4c 13 10       	mov    0x10(%rbx,%r10,1),%r9
  710217:	4e 89 4c 14 20       	mov    %r9,0x20(%rsp,%r10,1)
  71021c:	4e 8b 4c 14 10       	mov    0x10(%rsp,%r10,1),%r9
  710221:	4e 3b 4c 14 f8       	cmp    -0x8(%rsp,%r10,1),%r9
  710226:	73 c7                	jae    7101ef <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x25f>
  710228:	49 01 da             	add    %rbx,%r10
  71022b:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  710230:	0f 29 04 24          	movaps %xmm0,(%rsp)
  710234:	49 89 ca             	mov    %rcx,%r10
  710237:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  71023e:	00 00 
  710240:	4e 8b 5c 14 08       	mov    0x8(%rsp,%r10,1),%r11
  710245:	4e 89 5c 14 20       	mov    %r11,0x20(%rsp,%r10,1)
  71024a:	42 0f 10 44 14 f8    	movups -0x8(%rsp,%r10,1),%xmm0
  710250:	42 0f 11 44 14 10    	movups %xmm0,0x10(%rsp,%r10,1)
  710256:	49 83 fa 18          	cmp    $0x18,%r10
  71025a:	74 84                	je     7101e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x250>
  71025c:	4d 8d 5a e8          	lea    -0x18(%r10),%r11
  710260:	4e 3b 4c 14 e0       	cmp    -0x20(%rsp,%r10,1),%r9
  710265:	4d 89 da             	mov    %r11,%r10
  710268:	72 d6                	jb     710240 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x2b0>
  71026a:	4e 8d 14 1c          	lea    (%rsp,%r11,1),%r10
  71026e:	49 83 c2 10          	add    $0x10,%r10
  710272:	e9 6c ff ff ff       	jmp    7101e3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x253>
  710277:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
  71027e:	00 
  71027f:	48 8d 3c 49          	lea    (%rcx,%rcx,2),%rdi
  710283:	48 8d 0c 3c          	lea    (%rsp,%rdi,1),%rcx
  710287:	48 83 c1 10          	add    $0x10,%rcx
  71028b:	48 39 f2             	cmp    %rsi,%rdx
  71028e:	0f 83 ad 00 00 00    	jae    710341 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x3b1>
  710294:	48 01 df             	add    %rbx,%rdi
  710297:	44 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%r8d
  71029e:	00 
  71029f:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  7102a3:	eb 26                	jmp    7102cb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x33b>
  7102a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  7102ac:	00 00 00 00 
  7102b0:	49 89 ca             	mov    %rcx,%r10
  7102b3:	4d 89 0a             	mov    %r9,(%r10)
  7102b6:	0f 28 04 24          	movaps (%rsp),%xmm0
  7102ba:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  7102bf:	48 ff c2             	inc    %rdx
  7102c2:	49 83 c0 18          	add    $0x18,%r8
  7102c6:	48 39 f2             	cmp    %rsi,%rdx
  7102c9:	74 76                	je     710341 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x3b1>
  7102cb:	4c 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%r9
  7102d2:	00 
  7102d3:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  7102d7:	42 0f 10 04 17       	movups (%rdi,%r10,1),%xmm0
  7102dc:	42 0f 11 04 11       	movups %xmm0,(%rcx,%r10,1)
  7102e1:	4e 8b 4c 17 10       	mov    0x10(%rdi,%r10,1),%r9
  7102e6:	4e 89 4c 11 10       	mov    %r9,0x10(%rcx,%r10,1)
  7102eb:	4e 8b 0c 11          	mov    (%rcx,%r10,1),%r9
  7102ef:	4e 3b 4c 11 e8       	cmp    -0x18(%rcx,%r10,1),%r9
  7102f4:	73 c9                	jae    7102bf <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x32f>
  7102f6:	49 01 fa             	add    %rdi,%r10
  7102f9:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  7102fe:	0f 29 04 24          	movaps %xmm0,(%rsp)
  710302:	4d 89 c3             	mov    %r8,%r11
  710305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71030c:	00 00 00 00 
  710310:	4e 8b 54 19 f8       	mov    -0x8(%rcx,%r11,1),%r10
  710315:	4e 89 54 19 10       	mov    %r10,0x10(%rcx,%r11,1)
  71031a:	42 0f 10 44 19 e8    	movups -0x18(%rcx,%r11,1),%xmm0
  710320:	42 0f 11 04 19       	movups %xmm0,(%rcx,%r11,1)
  710325:	49 83 fb 18          	cmp    $0x18,%r11
  710329:	74 85                	je     7102b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x320>
  71032b:	4d 8d 53 e8          	lea    -0x18(%r11),%r10
  71032f:	4e 3b 4c 19 d0       	cmp    -0x30(%rcx,%r11,1),%r9
  710334:	4d 89 d3             	mov    %r10,%r11
  710337:	72 d7                	jb     710310 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x380>
  710339:	49 01 ca             	add    %rcx,%r10
  71033c:	e9 72 ff ff ff       	jmp    7102b3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x323>
  710341:	4b 8d 14 76          	lea    (%r14,%r14,2),%rdx
  710345:	4c 8d 0c d3          	lea    (%rbx,%rdx,8),%r9
  710349:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  71034d:	48 8d 34 d4          	lea    (%rsp,%rdx,8),%rsi
  710351:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
  710355:	48 8d 51 e8          	lea    -0x18(%rcx),%rdx
  710359:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  71035e:	49 89 d8             	mov    %rbx,%r8
  710361:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  710368:	0f 1f 84 00 00 00 00 
  71036f:	00 
  710370:	49 89 ca             	mov    %rcx,%r10
  710373:	49 89 fb             	mov    %rdi,%r11
  710376:	48 8b 39             	mov    (%rcx),%rdi
  710379:	48 83 c1 18          	add    $0x18,%rcx
  71037d:	49 3b 3b             	cmp    (%r11),%rdi
  710380:	49 8d 7b 18          	lea    0x18(%r11),%rdi
  710384:	49 0f 42 fb          	cmovb  %r11,%rdi
  710388:	4d 0f 42 da          	cmovb  %r10,%r11
  71038c:	4d 8b 7b 10          	mov    0x10(%r11),%r15
  710390:	4d 89 78 10          	mov    %r15,0x10(%r8)
  710394:	49 0f 43 ca          	cmovae %r10,%rcx
  710398:	4c 8b 16             	mov    (%rsi),%r10
  71039b:	4c 8b 3a             	mov    (%rdx),%r15
  71039e:	4d 39 fa             	cmp    %r15,%r10
  7103a1:	41 bc 00 00 00 00    	mov    $0x0,%r12d
  7103a7:	49 83 d4 ff          	adc    $0xffffffffffffffff,%r12
  7103ab:	4d 39 fa             	cmp    %r15,%r10
  7103ae:	49 89 f2             	mov    %rsi,%r10
  7103b1:	4c 0f 42 d2          	cmovb  %rdx,%r10
  7103b5:	41 0f 10 03          	movups (%r11),%xmm0
  7103b9:	41 bb 00 00 00 00    	mov    $0x0,%r11d
  7103bf:	4d 19 db             	sbb    %r11,%r11
  7103c2:	41 0f 11 00          	movups %xmm0,(%r8)
  7103c6:	49 83 c0 18          	add    $0x18,%r8
  7103ca:	4d 8b 7a 10          	mov    0x10(%r10),%r15
  7103ce:	4d 89 79 10          	mov    %r15,0x10(%r9)
  7103d2:	41 0f 10 02          	movups (%r10),%xmm0
  7103d6:	41 0f 11 01          	movups %xmm0,(%r9)
  7103da:	4f 8d 14 64          	lea    (%r12,%r12,2),%r10
  7103de:	4a 8d 34 d6          	lea    (%rsi,%r10,8),%rsi
  7103e2:	4f 8d 14 5b          	lea    (%r11,%r11,2),%r10
  7103e6:	4a 8d 14 d2          	lea    (%rdx,%r10,8),%rdx
  7103ea:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  7103ee:	48 ff c8             	dec    %rax
  7103f1:	0f 85 79 ff ff ff    	jne    710370 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x3e0>
  7103f7:	48 83 c2 18          	add    $0x18,%rdx
  7103fb:	48 83 c6 18          	add    $0x18,%rsi
  7103ff:	41 f6 c6 01          	test   $0x1,%r14b
  710403:	75 20                	jne    710425 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x495>
  710405:	48 39 f1             	cmp    %rsi,%rcx
  710408:	0f 95 c0             	setne  %al
  71040b:	48 39 d7             	cmp    %rdx,%rdi
  71040e:	75 4a                	jne    71045a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x4ca>
  710410:	84 c0                	test   %al,%al
  710412:	75 4c                	jne    710460 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x4d0>
  710414:	48 81 c4 90 04 00 00 	add    $0x490,%rsp
  71041b:	5b                   	pop    %rbx
  71041c:	41 5c                	pop    %r12
  71041e:	41 5d                	pop    %r13
  710420:	41 5e                	pop    %r14
  710422:	41 5f                	pop    %r15
  710424:	c3                   	ret
  710425:	48 8d 47 18          	lea    0x18(%rdi),%rax
  710429:	4c 8d 49 18          	lea    0x18(%rcx),%r9
  71042d:	48 39 d7             	cmp    %rdx,%rdi
  710430:	49 89 ca             	mov    %rcx,%r10
  710433:	4c 0f 42 d7          	cmovb  %rdi,%r10
  710437:	4d 8b 5a 10          	mov    0x10(%r10),%r11
  71043b:	4d 89 58 10          	mov    %r11,0x10(%r8)
  71043f:	41 0f 10 02          	movups (%r10),%xmm0
  710443:	41 0f 11 00          	movups %xmm0,(%r8)
  710447:	48 0f 42 f8          	cmovb  %rax,%rdi
  71044b:	49 0f 43 c9          	cmovae %r9,%rcx
  71044f:	48 39 f1             	cmp    %rsi,%rcx
  710452:	0f 95 c0             	setne  %al
  710455:	48 39 d7             	cmp    %rdx,%rdi
  710458:	74 b6                	je     710410 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x480>
  71045a:	b0 01                	mov    $0x1,%al
  71045c:	84 c0                	test   %al,%al
  71045e:	74 b4                	je     710414 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_+0x484>
  710460:	ff 15 0a 7e 3d 00    	call   *0x3d7e0a(%rip)        # ae8270 <_DYNAMIC+0x6d8>
  710466:	0f 0b                	ud2
  710468:	49 89 c7             	mov    %rax,%r15
  71046b:	49 c1 e6 03          	shl    $0x3,%r14
  71046f:	4b 8d 14 76          	lea    (%r14,%r14,2),%rdx
  710473:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  710478:	48 89 df             	mov    %rbx,%rdi
  71047b:	ff 15 87 79 3d 00    	call   *0x3d7987(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  710481:	4c 89 ff             	mov    %r15,%rdi
  710484:	e8 c7 80 3a 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
