
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072ca00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>:
  72ca00:	55                   	push   %rbp
  72ca01:	41 57                	push   %r15
  72ca03:	41 56                	push   %r14
  72ca05:	41 55                	push   %r13
  72ca07:	41 54                	push   %r12
  72ca09:	53                   	push   %rbx
  72ca0a:	48 81 ec f8 02 00 00 	sub    $0x2f8,%rsp
  72ca11:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  72ca16:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  72ca1b:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  72ca20:	48 83 fe 02          	cmp    $0x2,%rsi
  72ca24:	0f 82 01 06 00 00    	jb     72d02b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x62b>
  72ca2a:	48 89 cd             	mov    %rcx,%rbp
  72ca2d:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  72ca34:	00 00 40 
  72ca37:	48 89 d1             	mov    %rdx,%rcx
  72ca3a:	31 d2                	xor    %edx,%edx
  72ca3c:	48 f7 f6             	div    %rsi
  72ca3f:	48 83 fa 01          	cmp    $0x1,%rdx
  72ca43:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72ca47:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  72ca4c:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  72ca53:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72ca58:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
  72ca5d:	73 1e                	jae    72ca7d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x7d>
  72ca5f:	48 89 ca             	mov    %rcx,%rdx
  72ca62:	48 89 f0             	mov    %rsi,%rax
  72ca65:	48 d1 e8             	shr    $1,%rax
  72ca68:	48 89 f1             	mov    %rsi,%rcx
  72ca6b:	48 29 c1             	sub    %rax,%rcx
  72ca6e:	48 83 f9 40          	cmp    $0x40,%rcx
  72ca72:	b8 40 00 00 00       	mov    $0x40,%eax
  72ca77:	48 0f 42 c1          	cmovb  %rcx,%rax
  72ca7b:	eb 0e                	jmp    72ca8b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x8b>
  72ca7d:	48 89 f7             	mov    %rsi,%rdi
  72ca80:	ff 15 3a b9 3b 00    	call   *0x3bb93a(%rip)        # ae83c0 <_DYNAMIC+0x828>
  72ca86:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72ca8b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  72ca90:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72ca95:	48 8d 48 30          	lea    0x30(%rax),%rcx
  72ca99:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  72ca9e:	48 8d 48 10          	lea    0x10(%rax),%rcx
  72caa2:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  72caa7:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
  72caab:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  72cab0:	48 83 c0 e8          	add    $0xffffffffffffffe8,%rax
  72cab4:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  72cab9:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  72cabf:	31 db                	xor    %ebx,%ebx
  72cac1:	45 31 db             	xor    %r11d,%r11d
  72cac4:	48 89 ac 24 90 00 00 	mov    %rbp,0x90(%rsp)
  72cacb:	00 
  72cacc:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
  72cad1:	49 29 d9             	sub    %rbx,%r9
  72cad4:	76 23                	jbe    72caf9 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0xf9>
  72cad6:	eb 38                	jmp    72cb10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x110>
  72cad8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72cadf:	00 
  72cae0:	49 ff c3             	inc    %r11
  72cae3:	4c 89 c8             	mov    %r9,%rax
  72cae6:	48 d1 e8             	shr    $1,%rax
  72cae9:	48 01 c3             	add    %rax,%rbx
  72caec:	4d 89 cc             	mov    %r9,%r12
  72caef:	4c 8b 4c 24 30       	mov    0x30(%rsp),%r9
  72caf4:	49 29 d9             	sub    %rbx,%r9
  72caf7:	77 17                	ja     72cb10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x110>
  72caf9:	31 f6                	xor    %esi,%esi
  72cafb:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  72cb01:	49 83 fb 02          	cmp    $0x2,%r11
  72cb05:	0f 83 fa 01 00 00    	jae    72cd05 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x305>
  72cb0b:	e9 c6 04 00 00       	jmp    72cfd6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  72cb10:	48 8d 34 5b          	lea    (%rbx,%rbx,2),%rsi
  72cb14:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72cb19:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  72cb1d:	4c 3b 4c 24 20       	cmp    0x20(%rsp),%r9
  72cb22:	73 4c                	jae    72cb70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x170>
  72cb24:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  72cb29:	74 55                	je     72cb80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x180>
  72cb2b:	49 83 f9 20          	cmp    $0x20,%r9
  72cb2f:	b8 20 00 00 00       	mov    $0x20,%eax
  72cb34:	4c 0f 43 c8          	cmovae %rax,%r9
  72cb38:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72cb3d:	48 89 04 24          	mov    %rax,(%rsp)
  72cb41:	4c 89 ce             	mov    %r9,%rsi
  72cb44:	48 89 e9             	mov    %rbp,%rcx
  72cb47:	45 31 c0             	xor    %r8d,%r8d
  72cb4a:	4d 89 cf             	mov    %r9,%r15
  72cb4d:	45 31 c9             	xor    %r9d,%r9d
  72cb50:	4d 89 de             	mov    %r11,%r14
  72cb53:	e8 e8 23 00 00       	call   72ef40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72cb58:	4d 89 f3             	mov    %r14,%r11
  72cb5b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72cb60:	44 89 f8             	mov    %r15d,%eax
  72cb63:	e9 58 01 00 00       	jmp    72ccc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  72cb68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72cb6f:	00 
  72cb70:	49 83 f9 02          	cmp    $0x2,%r9
  72cb74:	73 2a                	jae    72cba0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1a0>
  72cb76:	4c 89 c8             	mov    %r9,%rax
  72cb79:	e9 42 01 00 00       	jmp    72ccc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  72cb7e:	66 90                	xchg   %ax,%ax
  72cb80:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72cb85:	49 39 c1             	cmp    %rax,%r9
  72cb88:	4c 0f 43 c8          	cmovae %rax,%r9
  72cb8c:	4d 01 c9             	add    %r9,%r9
  72cb8f:	e9 34 01 00 00       	jmp    72ccc8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c8>
  72cb94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72cb9b:	00 00 00 00 00 
  72cba0:	48 8b 0f             	mov    (%rdi),%rcx
  72cba3:	4c 8b 57 18          	mov    0x18(%rdi),%r10
  72cba7:	49 39 ca             	cmp    %rcx,%r10
  72cbaa:	4d 89 ce             	mov    %r9,%r14
  72cbad:	72 3a                	jb     72cbe9 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1e9>
  72cbaf:	b8 02 00 00 00       	mov    $0x2,%eax
  72cbb4:	49 83 f9 02          	cmp    $0x2,%r9
  72cbb8:	0f 84 02 01 00 00    	je     72ccc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  72cbbe:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72cbc3:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
  72cbc7:	b8 02 00 00 00       	mov    $0x2,%eax
  72cbcc:	4d 89 d0             	mov    %r10,%r8
  72cbcf:	90                   	nop
  72cbd0:	4d 89 c1             	mov    %r8,%r9
  72cbd3:	4c 8b 06             	mov    (%rsi),%r8
  72cbd6:	4d 39 c8             	cmp    %r9,%r8
  72cbd9:	72 5f                	jb     72cc3a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x23a>
  72cbdb:	48 ff c0             	inc    %rax
  72cbde:	48 83 c6 18          	add    $0x18,%rsi
  72cbe2:	49 39 c6             	cmp    %rax,%r14
  72cbe5:	75 e9                	jne    72cbd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1d0>
  72cbe7:	eb 3e                	jmp    72cc27 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x227>
  72cbe9:	49 83 f9 02          	cmp    $0x2,%r9
  72cbed:	75 0c                	jne    72cbfb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x1fb>
  72cbef:	b8 02 00 00 00       	mov    $0x2,%eax
  72cbf4:	b9 01 00 00 00       	mov    $0x1,%ecx
  72cbf9:	eb 63                	jmp    72cc5e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x25e>
  72cbfb:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72cc00:	48 8d 34 f0          	lea    (%rax,%rsi,8),%rsi
  72cc04:	b8 02 00 00 00       	mov    $0x2,%eax
  72cc09:	4d 89 d0             	mov    %r10,%r8
  72cc0c:	0f 1f 40 00          	nopl   0x0(%rax)
  72cc10:	4d 89 c1             	mov    %r8,%r9
  72cc13:	4c 8b 06             	mov    (%rsi),%r8
  72cc16:	4d 39 c8             	cmp    %r9,%r8
  72cc19:	73 1f                	jae    72cc3a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x23a>
  72cc1b:	48 ff c0             	inc    %rax
  72cc1e:	48 83 c6 18          	add    $0x18,%rsi
  72cc22:	49 39 c6             	cmp    %rax,%r14
  72cc25:	75 e9                	jne    72cc10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x210>
  72cc27:	4d 89 f1             	mov    %r14,%r9
  72cc2a:	4c 89 f0             	mov    %r14,%rax
  72cc2d:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  72cc32:	0f 82 ec fe ff ff    	jb     72cb24 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x124>
  72cc38:	eb 0e                	jmp    72cc48 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x248>
  72cc3a:	4d 89 f1             	mov    %r14,%r9
  72cc3d:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
  72cc42:	0f 82 dc fe ff ff    	jb     72cb24 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x124>
  72cc48:	49 39 ca             	cmp    %rcx,%r10
  72cc4b:	40 0f 93 c7          	setae  %dil
  72cc4f:	48 89 c1             	mov    %rax,%rcx
  72cc52:	48 d1 e9             	shr    $1,%rcx
  72cc55:	40 0f 94 c6          	sete   %sil
  72cc59:	40 08 fe             	or     %dil,%sil
  72cc5c:	75 62                	jne    72ccc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x2c0>
  72cc5e:	48 8d 34 dd 00 00 00 	lea    0x0(,%rbx,8),%rsi
  72cc65:	00 
  72cc66:	48 8d 34 76          	lea    (%rsi,%rsi,2),%rsi
  72cc6a:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
  72cc6f:	4c 8d 0c 37          	lea    (%rdi,%rsi,1),%r9
  72cc73:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
  72cc77:	48 8d 34 fe          	lea    (%rsi,%rdi,8),%rsi
  72cc7b:	48 03 74 24 60       	add    0x60(%rsp),%rsi
  72cc80:	49 8b 79 f0          	mov    -0x10(%r9),%rdi
  72cc84:	4c 8b 46 f0          	mov    -0x10(%rsi),%r8
  72cc88:	4d 89 41 f0          	mov    %r8,-0x10(%r9)
  72cc8c:	48 89 7e f0          	mov    %rdi,-0x10(%rsi)
  72cc90:	49 8b 79 f8          	mov    -0x8(%r9),%rdi
  72cc94:	4c 8b 46 f8          	mov    -0x8(%rsi),%r8
  72cc98:	4d 89 41 f8          	mov    %r8,-0x8(%r9)
  72cc9c:	48 89 7e f8          	mov    %rdi,-0x8(%rsi)
  72cca0:	49 8b 39             	mov    (%r9),%rdi
  72cca3:	4c 8b 06             	mov    (%rsi),%r8
  72cca6:	4d 89 01             	mov    %r8,(%r9)
  72cca9:	48 89 3e             	mov    %rdi,(%rsi)
  72ccac:	49 83 c1 18          	add    $0x18,%r9
  72ccb0:	48 83 c6 e8          	add    $0xffffffffffffffe8,%rsi
  72ccb4:	48 ff c9             	dec    %rcx
  72ccb7:	75 c7                	jne    72cc80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x280>
  72ccb9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72ccc0:	4c 8d 0c 45 01 00 00 	lea    0x1(,%rax,2),%r9
  72ccc7:	00 
  72ccc8:	4c 89 e0             	mov    %r12,%rax
  72cccb:	48 d1 e8             	shr    $1,%rax
  72ccce:	4c 89 c9             	mov    %r9,%rcx
  72ccd1:	48 d1 e9             	shr    $1,%rcx
  72ccd4:	48 8d 34 1b          	lea    (%rbx,%rbx,1),%rsi
  72ccd8:	48 29 c6             	sub    %rax,%rsi
  72ccdb:	48 8d 04 59          	lea    (%rcx,%rbx,2),%rax
  72ccdf:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  72cce4:	48 0f af f1          	imul   %rcx,%rsi
  72cce8:	48 0f af c1          	imul   %rcx,%rax
  72ccec:	48 31 f0             	xor    %rsi,%rax
  72ccef:	be 7f 00 00 00       	mov    $0x7f,%esi
  72ccf4:	48 0f bd f0          	bsr    %rax,%rsi
  72ccf8:	83 f6 3f             	xor    $0x3f,%esi
  72ccfb:	49 83 fb 02          	cmp    $0x2,%r11
  72ccff:	0f 82 d1 02 00 00    	jb     72cfd6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  72cd05:	48 8d 04 dd 00 00 00 	lea    0x0(,%rbx,8),%rax
  72cd0c:	00 
  72cd0d:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  72cd11:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72cd16:	48 01 c8             	add    %rcx,%rax
  72cd19:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  72cd20:	00 
  72cd21:	48 03 4c 24 70       	add    0x70(%rsp),%rcx
  72cd26:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  72cd2d:	00 
  72cd2e:	4c 89 4c 24 38       	mov    %r9,0x38(%rsp)
  72cd33:	48 89 9c 24 98 00 00 	mov    %rbx,0x98(%rsp)
  72cd3a:	00 
  72cd3b:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  72cd40:	eb 4b                	jmp    72cd8d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x38d>
  72cd42:	48 89 eb             	mov    %rbp,%rbx
  72cd45:	4c 89 ce             	mov    %r9,%rsi
  72cd48:	49 29 f4             	sub    %rsi,%r12
  72cd4b:	48 89 df             	mov    %rbx,%rdi
  72cd4e:	4c 89 e2             	mov    %r12,%rdx
  72cd51:	ff 15 b1 b0 3b 00    	call   *0x3bb0b1(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72cd57:	48 8b ac 24 90 00 00 	mov    0x90(%rsp),%rbp
  72cd5e:	00 
  72cd5f:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72cd64:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  72cd69:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  72cd6e:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  72cd73:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  72cd7a:	00 
  72cd7b:	48 8b 9c 24 98 00 00 	mov    0x98(%rsp),%rbx
  72cd82:	00 
  72cd83:	49 83 fb 01          	cmp    $0x1,%r11
  72cd87:	0f 86 43 02 00 00    	jbe    72cfd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d0>
  72cd8d:	42 38 b4 1c a5 00 00 	cmp    %sil,0xa5(%rsp,%r11,1)
  72cd94:	00 
  72cd95:	0f 82 3b 02 00 00    	jb     72cfd6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d6>
  72cd9b:	49 ff cb             	dec    %r11
  72cd9e:	4a 8b 84 dc e8 00 00 	mov    0xe8(%rsp,%r11,8),%rax
  72cda5:	00 
  72cda6:	49 89 c5             	mov    %rax,%r13
  72cda9:	49 d1 ed             	shr    $1,%r13
  72cdac:	4d 89 e7             	mov    %r12,%r15
  72cdaf:	49 d1 ef             	shr    $1,%r15
  72cdb2:	4f 8d 34 2f          	lea    (%r15,%r13,1),%r14
  72cdb6:	49 39 ee             	cmp    %rbp,%r14
  72cdb9:	77 25                	ja     72cde0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x3e0>
  72cdbb:	89 c1                	mov    %eax,%ecx
  72cdbd:	44 09 e1             	or     %r12d,%ecx
  72cdc0:	83 e1 01             	and    $0x1,%ecx
  72cdc3:	75 1b                	jne    72cde0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x3e0>
  72cdc5:	4d 01 f6             	add    %r14,%r14
  72cdc8:	4d 89 f4             	mov    %r14,%r12
  72cdcb:	49 83 fb 01          	cmp    $0x1,%r11
  72cdcf:	77 bc                	ja     72cd8d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x38d>
  72cdd1:	e9 fa 01 00 00       	jmp    72cfd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x5d0>
  72cdd6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72cddd:	00 00 00 
  72cde0:	48 89 d9             	mov    %rbx,%rcx
  72cde3:	4c 29 f1             	sub    %r14,%rcx
  72cde6:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  72cdea:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  72cdef:	48 8d 1c ce          	lea    (%rsi,%rcx,8),%rbx
  72cdf3:	a8 01                	test   $0x1,%al
  72cdf5:	4c 89 5c 24 40       	mov    %r11,0x40(%rsp)
  72cdfa:	75 54                	jne    72ce50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x450>
  72cdfc:	4c 89 e8             	mov    %r13,%rax
  72cdff:	48 83 c8 01          	or     $0x1,%rax
  72ce03:	4c 0f bd c0          	bsr    %rax,%r8
  72ce07:	41 83 f0 3f          	xor    $0x3f,%r8d
  72ce0b:	45 01 c0             	add    %r8d,%r8d
  72ce0e:	41 83 f0 7e          	xor    $0x7e,%r8d
  72ce12:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72ce17:	48 89 04 24          	mov    %rax,(%rsp)
  72ce1b:	48 89 df             	mov    %rbx,%rdi
  72ce1e:	4c 89 ee             	mov    %r13,%rsi
  72ce21:	48 89 e9             	mov    %rbp,%rcx
  72ce24:	45 31 c9             	xor    %r9d,%r9d
  72ce27:	e8 14 21 00 00       	call   72ef40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72ce2c:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  72ce31:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  72ce36:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72ce3b:	41 f6 c4 01          	test   $0x1,%r12b
  72ce3f:	74 15                	je     72ce56 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x456>
  72ce41:	4d 85 ff             	test   %r15,%r15
  72ce44:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  72ce49:	75 64                	jne    72ceaf <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x4af>
  72ce4b:	e9 23 ff ff ff       	jmp    72cd73 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  72ce50:	41 f6 c4 01          	test   $0x1,%r12b
  72ce54:	75 eb                	jne    72ce41 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x441>
  72ce56:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  72ce5d:	00 
  72ce5e:	4c 01 e8             	add    %r13,%rax
  72ce61:	48 8d 3c c3          	lea    (%rbx,%rax,8),%rdi
  72ce65:	4c 89 f8             	mov    %r15,%rax
  72ce68:	48 83 c8 01          	or     $0x1,%rax
  72ce6c:	4c 0f bd c0          	bsr    %rax,%r8
  72ce70:	41 83 f0 3f          	xor    $0x3f,%r8d
  72ce74:	45 01 c0             	add    %r8d,%r8d
  72ce77:	41 83 f0 7e          	xor    $0x7e,%r8d
  72ce7b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72ce80:	48 89 04 24          	mov    %rax,(%rsp)
  72ce84:	4c 89 fe             	mov    %r15,%rsi
  72ce87:	48 89 e9             	mov    %rbp,%rcx
  72ce8a:	45 31 c9             	xor    %r9d,%r9d
  72ce8d:	e8 ae 20 00 00       	call   72ef40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72ce92:	4c 8b 4c 24 38       	mov    0x38(%rsp),%r9
  72ce97:	4c 8b 5c 24 40       	mov    0x40(%rsp),%r11
  72ce9c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72cea1:	4d 85 ff             	test   %r15,%r15
  72cea4:	48 8b 74 24 58       	mov    0x58(%rsp),%rsi
  72cea9:	0f 84 c4 fe ff ff    	je     72cd73 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  72ceaf:	4d 85 ed             	test   %r13,%r13
  72ceb2:	0f 84 bb fe ff ff    	je     72cd73 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  72ceb8:	4d 39 ef             	cmp    %r13,%r15
  72cebb:	4c 89 e8             	mov    %r13,%rax
  72cebe:	49 0f 42 c7          	cmovb  %r15,%rax
  72cec2:	48 39 c5             	cmp    %rax,%rbp
  72cec5:	0f 82 a8 fe ff ff    	jb     72cd73 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x373>
  72cecb:	4a 8d 0c 6d 00 00 00 	lea    0x0(,%r13,2),%rcx
  72ced2:	00 
  72ced3:	4c 01 e9             	add    %r13,%rcx
  72ced6:	48 8d 2c cb          	lea    (%rbx,%rcx,8),%rbp
  72ceda:	4d 39 fd             	cmp    %r15,%r13
  72cedd:	48 89 de             	mov    %rbx,%rsi
  72cee0:	48 0f 47 f5          	cmova  %rbp,%rsi
  72cee4:	48 c1 e0 03          	shl    $0x3,%rax
  72cee8:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
  72ceec:	48 89 d7             	mov    %rdx,%rdi
  72ceef:	4c 89 e2             	mov    %r12,%rdx
  72cef2:	ff 15 10 af 3b 00    	call   *0x3baf10(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72cef8:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
  72cefd:	4d 01 cc             	add    %r9,%r12
  72cf00:	4d 39 fd             	cmp    %r15,%r13
  72cf03:	76 68                	jbe    72cf6d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x56d>
  72cf05:	48 8b 84 24 88 00 00 	mov    0x88(%rsp),%rax
  72cf0c:	00 
  72cf0d:	0f 1f 00             	nopl   (%rax)
  72cf10:	48 8d 4d e8          	lea    -0x18(%rbp),%rcx
  72cf14:	49 8d 54 24 e8       	lea    -0x18(%r12),%rdx
  72cf19:	49 8b 74 24 e8       	mov    -0x18(%r12),%rsi
  72cf1e:	31 ff                	xor    %edi,%edi
  72cf20:	45 31 c0             	xor    %r8d,%r8d
  72cf23:	48 3b 75 e8          	cmp    -0x18(%rbp),%rsi
  72cf27:	40 0f 92 c7          	setb   %dil
  72cf2b:	41 0f 93 c0          	setae  %r8b
  72cf2f:	48 0f 42 d1          	cmovb  %rcx,%rdx
  72cf33:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  72cf37:	48 89 48 10          	mov    %rcx,0x10(%rax)
  72cf3b:	0f 10 02             	movups (%rdx),%xmm0
  72cf3e:	0f 11 00             	movups %xmm0,(%rax)
  72cf41:	4b 8d 0c 40          	lea    (%r8,%r8,2),%rcx
  72cf45:	48 8d 6c cd e8       	lea    -0x18(%rbp,%rcx,8),%rbp
  72cf4a:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  72cf4e:	4d 8d 24 cc          	lea    (%r12,%rcx,8),%r12
  72cf52:	49 83 c4 e8          	add    $0xffffffffffffffe8,%r12
  72cf56:	48 39 dd             	cmp    %rbx,%rbp
  72cf59:	0f 84 e3 fd ff ff    	je     72cd42 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x342>
  72cf5f:	48 83 c0 e8          	add    $0xffffffffffffffe8,%rax
  72cf63:	4d 39 cc             	cmp    %r9,%r12
  72cf66:	75 a8                	jne    72cf10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x510>
  72cf68:	e9 d5 fd ff ff       	jmp    72cd42 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x342>
  72cf6d:	4c 89 ce             	mov    %r9,%rsi
  72cf70:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
  72cf77:	00 
  72cf78:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72cf7f:	00 
  72cf80:	48 8b 4d 00          	mov    0x0(%rbp),%rcx
  72cf84:	31 c0                	xor    %eax,%eax
  72cf86:	31 d2                	xor    %edx,%edx
  72cf88:	48 3b 0e             	cmp    (%rsi),%rcx
  72cf8b:	0f 92 c1             	setb   %cl
  72cf8e:	0f 93 c2             	setae  %dl
  72cf91:	48 89 f7             	mov    %rsi,%rdi
  72cf94:	48 0f 42 fd          	cmovb  %rbp,%rdi
  72cf98:	4c 8b 47 10          	mov    0x10(%rdi),%r8
  72cf9c:	4c 89 43 10          	mov    %r8,0x10(%rbx)
  72cfa0:	0f 10 07             	movups (%rdi),%xmm0
  72cfa3:	0f 11 03             	movups %xmm0,(%rbx)
  72cfa6:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  72cfaa:	48 8d 34 d6          	lea    (%rsi,%rdx,8),%rsi
  72cfae:	48 83 c3 18          	add    $0x18,%rbx
  72cfb2:	4c 39 e6             	cmp    %r12,%rsi
  72cfb5:	0f 84 8d fd ff ff    	je     72cd48 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x348>
  72cfbb:	88 c8                	mov    %cl,%al
  72cfbd:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  72cfc1:	48 8d 6c c5 00       	lea    0x0(%rbp,%rax,8),%rbp
  72cfc6:	4c 39 cd             	cmp    %r9,%rbp
  72cfc9:	75 b5                	jne    72cf80 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x580>
  72cfcb:	e9 78 fd ff ff       	jmp    72cd48 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x348>
  72cfd0:	41 bb 01 00 00 00    	mov    $0x1,%r11d
  72cfd6:	4e 89 a4 dc e8 00 00 	mov    %r12,0xe8(%rsp,%r11,8)
  72cfdd:	00 
  72cfde:	42 88 b4 1c a6 00 00 	mov    %sil,0xa6(%rsp,%r11,1)
  72cfe5:	00 
  72cfe6:	48 39 5c 24 30       	cmp    %rbx,0x30(%rsp)
  72cfeb:	0f 87 ef fa ff ff    	ja     72cae0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0xe0>
  72cff1:	41 f6 c4 01          	test   $0x1,%r12b
  72cff5:	75 34                	jne    72d02b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_+0x62b>
  72cff7:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  72cffc:	48 89 f0             	mov    %rsi,%rax
  72cfff:	48 83 c8 01          	or     $0x1,%rax
  72d003:	4c 0f bd c0          	bsr    %rax,%r8
  72d007:	41 83 f0 3f          	xor    $0x3f,%r8d
  72d00b:	45 01 c0             	add    %r8d,%r8d
  72d00e:	41 83 f0 7e          	xor    $0x7e,%r8d
  72d012:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72d017:	48 89 04 24          	mov    %rax,(%rsp)
  72d01b:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  72d020:	48 89 e9             	mov    %rbp,%rcx
  72d023:	45 31 c9             	xor    %r9d,%r9d
  72d026:	e8 15 1f 00 00       	call   72ef40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72d02b:	48 81 c4 f8 02 00 00 	add    $0x2f8,%rsp
  72d032:	5b                   	pop    %rbx
  72d033:	41 5c                	pop    %r12
  72d035:	41 5d                	pop    %r13
  72d037:	41 5e                	pop    %r14
  72d039:	41 5f                	pop    %r15
  72d03b:	5d                   	pop    %rbp
  72d03c:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
