
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000725f30 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_>:
  725f30:	48 83 fe 02          	cmp    $0x2,%rsi
  725f34:	0f 82 e7 00 00 00    	jb     726021 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0xf1>
  725f3a:	49 89 d0             	mov    %rdx,%r8
  725f3d:	48 8b 07             	mov    (%rdi),%rax
  725f40:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  725f44:	ba 02 00 00 00       	mov    $0x2,%edx
  725f49:	48 39 c1             	cmp    %rax,%rcx
  725f4c:	73 2b                	jae    725f79 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x49>
  725f4e:	48 83 fe 02          	cmp    $0x2,%rsi
  725f52:	74 2b                	je     725f7f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x4f>
  725f54:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  725f58:	49 89 ca             	mov    %rcx,%r10
  725f5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  725f60:	4d 89 d3             	mov    %r10,%r11
  725f63:	4d 8b 11             	mov    (%r9),%r10
  725f66:	4d 39 da             	cmp    %r11,%r10
  725f69:	73 14                	jae    725f7f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x4f>
  725f6b:	48 ff c2             	inc    %rdx
  725f6e:	49 83 c1 18          	add    $0x18,%r9
  725f72:	48 39 d6             	cmp    %rdx,%rsi
  725f75:	75 e9                	jne    725f60 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x30>
  725f77:	eb 4e                	jmp    725fc7 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x97>
  725f79:	48 83 fe 02          	cmp    $0x2,%rsi
  725f7d:	75 1f                	jne    725f9e <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x6e>
  725f7f:	48 39 f2             	cmp    %rsi,%rdx
  725f82:	74 43                	je     725fc7 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x97>
  725f84:	48 89 f0             	mov    %rsi,%rax
  725f87:	48 83 c8 01          	or     $0x1,%rax
  725f8b:	48 0f bd c8          	bsr    %rax,%rcx
  725f8f:	83 f1 3f             	xor    $0x3f,%ecx
  725f92:	01 c9                	add    %ecx,%ecx
  725f94:	83 f1 7e             	xor    $0x7e,%ecx
  725f97:	31 d2                	xor    %edx,%edx
  725f99:	e9 72 b6 ff ff       	jmp    721610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_>
  725f9e:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  725fa2:	49 89 ca             	mov    %rcx,%r10
  725fa5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  725fac:	00 00 00 00 
  725fb0:	4d 89 d3             	mov    %r10,%r11
  725fb3:	4d 8b 11             	mov    (%r9),%r10
  725fb6:	4d 39 da             	cmp    %r11,%r10
  725fb9:	72 c4                	jb     725f7f <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x4f>
  725fbb:	48 ff c2             	inc    %rdx
  725fbe:	49 83 c1 18          	add    $0x18,%r9
  725fc2:	48 39 d6             	cmp    %rdx,%rsi
  725fc5:	75 e9                	jne    725fb0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0x80>
  725fc7:	48 39 c1             	cmp    %rax,%rcx
  725fca:	73 55                	jae    726021 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0xf1>
  725fcc:	48 8d 04 b5 00 00 00 	lea    0x0(,%rsi,4),%rax
  725fd3:	00 
  725fd4:	48 83 e0 f8          	and    $0xfffffffffffffff8,%rax
  725fd8:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  725fdc:	48 8d 0c 76          	lea    (%rsi,%rsi,2),%rcx
  725fe0:	48 8d 0c cd e8 ff ff 	lea    -0x18(,%rcx,8),%rcx
  725fe7:	ff 
  725fe8:	31 d2                	xor    %edx,%edx
  725fea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  725ff0:	0f 10 04 17          	movups (%rdi,%rdx,1),%xmm0
  725ff4:	0f 10 0c 0f          	movups (%rdi,%rcx,1),%xmm1
  725ff8:	0f 11 0c 17          	movups %xmm1,(%rdi,%rdx,1)
  725ffc:	0f 11 04 0f          	movups %xmm0,(%rdi,%rcx,1)
  726000:	48 8b 74 17 10       	mov    0x10(%rdi,%rdx,1),%rsi
  726005:	4c 8b 44 0f 10       	mov    0x10(%rdi,%rcx,1),%r8
  72600a:	4c 89 44 17 10       	mov    %r8,0x10(%rdi,%rdx,1)
  72600f:	48 89 74 0f 10       	mov    %rsi,0x10(%rdi,%rcx,1)
  726014:	48 83 c2 18          	add    $0x18,%rdx
  726018:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72601c:	48 39 d0             	cmp    %rdx,%rax
  72601f:	75 cf                	jne    725ff0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable7ipnsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB6_SBT_20sort_unstable_by_keyyNCNvMst_BX_INtBX_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2J_+0xc0>
  726021:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
