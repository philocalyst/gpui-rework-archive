
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072d040 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>:
  72d040:	55                   	push   %rbp
  72d041:	41 57                	push   %r15
  72d043:	41 56                	push   %r14
  72d045:	41 55                	push   %r13
  72d047:	41 54                	push   %r12
  72d049:	53                   	push   %rbx
  72d04a:	48 81 ec e8 02 00 00 	sub    $0x2e8,%rsp
  72d051:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  72d056:	44 89 44 24 4c       	mov    %r8d,0x4c(%rsp)
  72d05b:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  72d060:	48 83 fe 02          	cmp    $0x2,%rsi
  72d064:	0f 82 44 06 00 00    	jb     72d6ae <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x66e>
  72d06a:	49 89 cd             	mov    %rcx,%r13
  72d06d:	48 b8 00 00 00 00 00 	movabs $0x4000000000000000,%rax
  72d074:	00 00 40 
  72d077:	48 89 d1             	mov    %rdx,%rcx
  72d07a:	31 d2                	xor    %edx,%edx
  72d07c:	48 f7 f6             	div    %rsi
  72d07f:	48 83 fa 01          	cmp    $0x1,%rdx
  72d083:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72d087:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  72d08c:	48 81 fe 01 10 00 00 	cmp    $0x1001,%rsi
  72d093:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  72d098:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  72d09d:	73 1e                	jae    72d0bd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x7d>
  72d09f:	48 89 ca             	mov    %rcx,%rdx
  72d0a2:	48 89 f0             	mov    %rsi,%rax
  72d0a5:	48 d1 e8             	shr    $1,%rax
  72d0a8:	48 89 f1             	mov    %rsi,%rcx
  72d0ab:	48 29 c1             	sub    %rax,%rcx
  72d0ae:	48 83 f9 40          	cmp    $0x40,%rcx
  72d0b2:	b8 40 00 00 00       	mov    $0x40,%eax
  72d0b7:	48 0f 42 c1          	cmovb  %rcx,%rax
  72d0bb:	eb 0e                	jmp    72d0cb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x8b>
  72d0bd:	48 89 f7             	mov    %rsi,%rdi
  72d0c0:	ff 15 fa b2 3b 00    	call   *0x3bb2fa(%rip)        # ae83c0 <_DYNAMIC+0x828>
  72d0c6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d0cb:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72d0d0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72d0d5:	48 8d 48 20          	lea    0x20(%rax),%rcx
  72d0d9:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  72d0de:	48 8d 48 10          	lea    0x10(%rax),%rcx
  72d0e2:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  72d0e7:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  72d0eb:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  72d0f0:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  72d0f6:	31 ed                	xor    %ebp,%ebp
  72d0f8:	45 31 c9             	xor    %r9d,%r9d
  72d0fb:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  72d102:	00 
  72d103:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72d108:	48 29 ee             	sub    %rbp,%rsi
  72d10b:	77 23                	ja     72d130 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xf0>
  72d10d:	0f 1f 00             	nopl   (%rax)
  72d110:	31 ff                	xor    %edi,%edi
  72d112:	be 01 00 00 00       	mov    $0x1,%esi
  72d117:	49 83 f9 02          	cmp    $0x2,%r9
  72d11b:	0f 83 df 00 00 00    	jae    72d200 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1c0>
  72d121:	e9 80 03 00 00       	jmp    72d4a6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  72d126:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72d12d:	00 00 00 
  72d130:	48 89 e9             	mov    %rbp,%rcx
  72d133:	48 c1 e1 04          	shl    $0x4,%rcx
  72d137:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72d13c:	48 8d 3c 08          	lea    (%rax,%rcx,1),%rdi
  72d140:	48 3b 74 24 18       	cmp    0x18(%rsp),%rsi
  72d145:	73 49                	jae    72d190 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x150>
  72d147:	80 7c 24 4c 00       	cmpb   $0x0,0x4c(%rsp)
  72d14c:	74 62                	je     72d1b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x170>
  72d14e:	48 83 fe 20          	cmp    $0x20,%rsi
  72d152:	b8 20 00 00 00       	mov    $0x20,%eax
  72d157:	48 0f 43 f0          	cmovae %rax,%rsi
  72d15b:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72d160:	48 89 04 24          	mov    %rax,(%rsp)
  72d164:	4c 89 e9             	mov    %r13,%rcx
  72d167:	45 31 c0             	xor    %r8d,%r8d
  72d16a:	4c 89 cb             	mov    %r9,%rbx
  72d16d:	45 31 c9             	xor    %r9d,%r9d
  72d170:	49 89 f6             	mov    %rsi,%r14
  72d173:	e8 c8 22 00 00       	call   72f440 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72d178:	49 89 d9             	mov    %rbx,%r9
  72d17b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d180:	44 89 f0             	mov    %r14d,%eax
  72d183:	eb 18                	jmp    72d19d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d185:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72d18c:	00 00 00 00 
  72d190:	48 83 fe 02          	cmp    $0x2,%rsi
  72d194:	0f 83 56 03 00 00    	jae    72d4f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x4b0>
  72d19a:	48 89 f0             	mov    %rsi,%rax
  72d19d:	48 8d 34 45 01 00 00 	lea    0x1(,%rax,2),%rsi
  72d1a4:	00 
  72d1a5:	eb 18                	jmp    72d1bf <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x17f>
  72d1a7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72d1ae:	00 00 
  72d1b0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  72d1b5:	48 39 c6             	cmp    %rax,%rsi
  72d1b8:	48 0f 43 f0          	cmovae %rax,%rsi
  72d1bc:	48 01 f6             	add    %rsi,%rsi
  72d1bf:	4c 89 e0             	mov    %r12,%rax
  72d1c2:	48 d1 e8             	shr    $1,%rax
  72d1c5:	48 89 f1             	mov    %rsi,%rcx
  72d1c8:	48 d1 e9             	shr    $1,%rcx
  72d1cb:	48 8d 3c 6d 00 00 00 	lea    0x0(,%rbp,2),%rdi
  72d1d2:	00 
  72d1d3:	48 29 c7             	sub    %rax,%rdi
  72d1d6:	48 8d 04 69          	lea    (%rcx,%rbp,2),%rax
  72d1da:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  72d1df:	48 0f af f9          	imul   %rcx,%rdi
  72d1e3:	48 0f af c1          	imul   %rcx,%rax
  72d1e7:	48 31 f8             	xor    %rdi,%rax
  72d1ea:	bf 7f 00 00 00       	mov    $0x7f,%edi
  72d1ef:	48 0f bd f8          	bsr    %rax,%rdi
  72d1f3:	83 f7 3f             	xor    $0x3f,%edi
  72d1f6:	49 83 f9 02          	cmp    $0x2,%r9
  72d1fa:	0f 82 a6 02 00 00    	jb     72d4a6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  72d200:	48 89 e9             	mov    %rbp,%rcx
  72d203:	48 c1 e1 04          	shl    $0x4,%rcx
  72d207:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72d20c:	48 01 c8             	add    %rcx,%rax
  72d20f:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  72d214:	48 03 4c 24 58       	add    0x58(%rsp),%rcx
  72d219:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  72d21e:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  72d223:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  72d228:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  72d22f:	00 
  72d230:	eb 4b                	jmp    72d27d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x23d>
  72d232:	4c 89 ed             	mov    %r13,%rbp
  72d235:	4c 89 c6             	mov    %r8,%rsi
  72d238:	49 29 f4             	sub    %rsi,%r12
  72d23b:	48 89 ef             	mov    %rbp,%rdi
  72d23e:	4c 89 e2             	mov    %r12,%rdx
  72d241:	ff 15 c1 ab 3b 00    	call   *0x3babc1(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72d247:	4c 8b ac 24 80 00 00 	mov    0x80(%rsp),%r13
  72d24e:	00 
  72d24f:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d254:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72d259:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72d25e:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72d263:	4e 8d 24 75 01 00 00 	lea    0x1(,%r14,2),%r12
  72d26a:	00 
  72d26b:	48 8b ac 24 88 00 00 	mov    0x88(%rsp),%rbp
  72d272:	00 
  72d273:	49 83 f9 01          	cmp    $0x1,%r9
  72d277:	0f 86 23 02 00 00    	jbe    72d4a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x460>
  72d27d:	42 38 bc 0c 95 00 00 	cmp    %dil,0x95(%rsp,%r9,1)
  72d284:	00 
  72d285:	0f 82 1b 02 00 00    	jb     72d4a6 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x466>
  72d28b:	49 ff c9             	dec    %r9
  72d28e:	4a 8b 84 cc d8 00 00 	mov    0xd8(%rsp,%r9,8),%rax
  72d295:	00 
  72d296:	48 89 c3             	mov    %rax,%rbx
  72d299:	48 d1 eb             	shr    $1,%rbx
  72d29c:	4d 89 e7             	mov    %r12,%r15
  72d29f:	49 d1 ef             	shr    $1,%r15
  72d2a2:	4e 8d 34 3b          	lea    (%rbx,%r15,1),%r14
  72d2a6:	4d 39 ee             	cmp    %r13,%r14
  72d2a9:	77 25                	ja     72d2d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x290>
  72d2ab:	89 c1                	mov    %eax,%ecx
  72d2ad:	44 09 e1             	or     %r12d,%ecx
  72d2b0:	83 e1 01             	and    $0x1,%ecx
  72d2b3:	75 1b                	jne    72d2d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x290>
  72d2b5:	4d 01 f6             	add    %r14,%r14
  72d2b8:	4d 89 f4             	mov    %r14,%r12
  72d2bb:	49 83 f9 01          	cmp    $0x1,%r9
  72d2bf:	77 bc                	ja     72d27d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x23d>
  72d2c1:	e9 da 01 00 00       	jmp    72d4a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x460>
  72d2c6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72d2cd:	00 00 00 
  72d2d0:	4c 29 f5             	sub    %r14,%rbp
  72d2d3:	48 c1 e5 04          	shl    $0x4,%rbp
  72d2d7:	48 03 6c 24 10       	add    0x10(%rsp),%rbp
  72d2dc:	a8 01                	test   $0x1,%al
  72d2de:	4c 89 4c 24 40       	mov    %r9,0x40(%rsp)
  72d2e3:	75 5b                	jne    72d340 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x300>
  72d2e5:	48 89 d8             	mov    %rbx,%rax
  72d2e8:	48 83 c8 01          	or     $0x1,%rax
  72d2ec:	4c 0f bd c0          	bsr    %rax,%r8
  72d2f0:	41 83 f0 3f          	xor    $0x3f,%r8d
  72d2f4:	45 01 c0             	add    %r8d,%r8d
  72d2f7:	41 83 f0 7e          	xor    $0x7e,%r8d
  72d2fb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72d300:	48 89 04 24          	mov    %rax,(%rsp)
  72d304:	48 89 ef             	mov    %rbp,%rdi
  72d307:	48 89 de             	mov    %rbx,%rsi
  72d30a:	4c 89 e9             	mov    %r13,%rcx
  72d30d:	45 31 c9             	xor    %r9d,%r9d
  72d310:	e8 2b 21 00 00       	call   72f440 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72d315:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72d31a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72d31f:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72d324:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d329:	41 f6 c4 01          	test   $0x1,%r12b
  72d32d:	74 17                	je     72d346 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x306>
  72d32f:	4d 85 ff             	test   %r15,%r15
  72d332:	75 66                	jne    72d39a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x35a>
  72d334:	e9 2a ff ff ff       	jmp    72d263 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  72d339:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72d340:	41 f6 c4 01          	test   $0x1,%r12b
  72d344:	75 e9                	jne    72d32f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x2ef>
  72d346:	48 89 df             	mov    %rbx,%rdi
  72d349:	48 c1 e7 04          	shl    $0x4,%rdi
  72d34d:	48 01 ef             	add    %rbp,%rdi
  72d350:	4c 89 f8             	mov    %r15,%rax
  72d353:	48 83 c8 01          	or     $0x1,%rax
  72d357:	4c 0f bd c0          	bsr    %rax,%r8
  72d35b:	41 83 f0 3f          	xor    $0x3f,%r8d
  72d35f:	45 01 c0             	add    %r8d,%r8d
  72d362:	41 83 f0 7e          	xor    $0x7e,%r8d
  72d366:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72d36b:	48 89 04 24          	mov    %rax,(%rsp)
  72d36f:	4c 89 fe             	mov    %r15,%rsi
  72d372:	4c 89 e9             	mov    %r13,%rcx
  72d375:	45 31 c9             	xor    %r9d,%r9d
  72d378:	e8 c3 20 00 00       	call   72f440 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72d37d:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  72d382:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  72d387:	4c 8b 4c 24 40       	mov    0x40(%rsp),%r9
  72d38c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d391:	4d 85 ff             	test   %r15,%r15
  72d394:	0f 84 c9 fe ff ff    	je     72d263 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  72d39a:	48 85 db             	test   %rbx,%rbx
  72d39d:	0f 84 c0 fe ff ff    	je     72d263 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  72d3a3:	49 39 df             	cmp    %rbx,%r15
  72d3a6:	49 89 dc             	mov    %rbx,%r12
  72d3a9:	4d 0f 42 e7          	cmovb  %r15,%r12
  72d3ad:	4d 39 e5             	cmp    %r12,%r13
  72d3b0:	0f 82 ad fe ff ff    	jb     72d263 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x223>
  72d3b6:	49 89 dd             	mov    %rbx,%r13
  72d3b9:	49 c1 e5 04          	shl    $0x4,%r13
  72d3bd:	49 01 ed             	add    %rbp,%r13
  72d3c0:	4c 39 fb             	cmp    %r15,%rbx
  72d3c3:	48 89 ee             	mov    %rbp,%rsi
  72d3c6:	49 0f 47 f5          	cmova  %r13,%rsi
  72d3ca:	49 c1 e4 04          	shl    $0x4,%r12
  72d3ce:	48 89 d7             	mov    %rdx,%rdi
  72d3d1:	4c 89 e2             	mov    %r12,%rdx
  72d3d4:	ff 15 2e aa 3b 00    	call   *0x3baa2e(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72d3da:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  72d3df:	4d 01 c4             	add    %r8,%r12
  72d3e2:	4c 39 fb             	cmp    %r15,%rbx
  72d3e5:	76 5c                	jbe    72d443 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x403>
  72d3e7:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  72d3ec:	0f 1f 40 00          	nopl   0x0(%rax)
  72d3f0:	49 8d 4d f0          	lea    -0x10(%r13),%rcx
  72d3f4:	49 8b 54 24 f0       	mov    -0x10(%r12),%rdx
  72d3f9:	31 f6                	xor    %esi,%esi
  72d3fb:	31 ff                	xor    %edi,%edi
  72d3fd:	49 3b 55 f0          	cmp    -0x10(%r13),%rdx
  72d401:	49 8d 54 24 f0       	lea    -0x10(%r12),%rdx
  72d406:	40 0f 92 c6          	setb   %sil
  72d40a:	48 0f 42 d1          	cmovb  %rcx,%rdx
  72d40e:	40 0f 93 c7          	setae  %dil
  72d412:	0f 10 02             	movups (%rdx),%xmm0
  72d415:	0f 11 00             	movups %xmm0,(%rax)
  72d418:	c1 e7 04             	shl    $0x4,%edi
  72d41b:	49 01 fd             	add    %rdi,%r13
  72d41e:	49 83 c5 f0          	add    $0xfffffffffffffff0,%r13
  72d422:	c1 e6 04             	shl    $0x4,%esi
  72d425:	49 01 f4             	add    %rsi,%r12
  72d428:	49 83 c4 f0          	add    $0xfffffffffffffff0,%r12
  72d42c:	49 39 ed             	cmp    %rbp,%r13
  72d42f:	0f 84 fd fd ff ff    	je     72d232 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f2>
  72d435:	48 83 c0 f0          	add    $0xfffffffffffffff0,%rax
  72d439:	4d 39 c4             	cmp    %r8,%r12
  72d43c:	75 b2                	jne    72d3f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x3b0>
  72d43e:	e9 ef fd ff ff       	jmp    72d232 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f2>
  72d443:	4c 89 c6             	mov    %r8,%rsi
  72d446:	4c 8b 44 24 70       	mov    0x70(%rsp),%r8
  72d44b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72d450:	48 89 f2             	mov    %rsi,%rdx
  72d453:	49 8b 4d 00          	mov    0x0(%r13),%rcx
  72d457:	31 c0                	xor    %eax,%eax
  72d459:	31 f6                	xor    %esi,%esi
  72d45b:	48 3b 0a             	cmp    (%rdx),%rcx
  72d45e:	0f 92 c1             	setb   %cl
  72d461:	40 0f 93 c6          	setae  %sil
  72d465:	48 89 d7             	mov    %rdx,%rdi
  72d468:	49 0f 42 fd          	cmovb  %r13,%rdi
  72d46c:	0f 10 07             	movups (%rdi),%xmm0
  72d46f:	0f 11 45 00          	movups %xmm0,0x0(%rbp)
  72d473:	c1 e6 04             	shl    $0x4,%esi
  72d476:	48 01 d6             	add    %rdx,%rsi
  72d479:	48 83 c5 10          	add    $0x10,%rbp
  72d47d:	4c 39 e6             	cmp    %r12,%rsi
  72d480:	0f 84 b2 fd ff ff    	je     72d238 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f8>
  72d486:	88 c8                	mov    %cl,%al
  72d488:	c1 e0 04             	shl    $0x4,%eax
  72d48b:	49 01 c5             	add    %rax,%r13
  72d48e:	4d 39 c5             	cmp    %r8,%r13
  72d491:	75 bd                	jne    72d450 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x410>
  72d493:	e9 a0 fd ff ff       	jmp    72d238 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x1f8>
  72d498:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72d49f:	00 
  72d4a0:	41 b9 01 00 00 00    	mov    $0x1,%r9d
  72d4a6:	4e 89 a4 cc d8 00 00 	mov    %r12,0xd8(%rsp,%r9,8)
  72d4ad:	00 
  72d4ae:	42 88 bc 0c 96 00 00 	mov    %dil,0x96(%rsp,%r9,1)
  72d4b5:	00 
  72d4b6:	48 39 6c 24 28       	cmp    %rbp,0x28(%rsp)
  72d4bb:	0f 86 b3 01 00 00    	jbe    72d674 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x634>
  72d4c1:	49 ff c1             	inc    %r9
  72d4c4:	48 89 f0             	mov    %rsi,%rax
  72d4c7:	48 d1 e8             	shr    $1,%rax
  72d4ca:	48 01 c5             	add    %rax,%rbp
  72d4cd:	49 89 f4             	mov    %rsi,%r12
  72d4d0:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72d4d5:	48 29 ee             	sub    %rbp,%rsi
  72d4d8:	0f 87 52 fc ff ff    	ja     72d130 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xf0>
  72d4de:	e9 2d fc ff ff       	jmp    72d110 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0xd0>
  72d4e3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72d4ea:	84 00 00 00 00 00 
  72d4f0:	4c 8b 1f             	mov    (%rdi),%r11
  72d4f3:	4c 8b 77 10          	mov    0x10(%rdi),%r14
  72d4f7:	4d 39 de             	cmp    %r11,%r14
  72d4fa:	49 89 f7             	mov    %rsi,%r15
  72d4fd:	73 15                	jae    72d514 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x4d4>
  72d4ff:	48 83 fe 02          	cmp    $0x2,%rsi
  72d503:	75 54                	jne    72d559 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x519>
  72d505:	b8 02 00 00 00       	mov    $0x2,%eax
  72d50a:	be 01 00 00 00       	mov    $0x1,%esi
  72d50f:	e9 af 00 00 00       	jmp    72d5c3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x583>
  72d514:	b8 02 00 00 00       	mov    $0x2,%eax
  72d519:	48 83 fe 02          	cmp    $0x2,%rsi
  72d51d:	0f 84 7a fc ff ff    	je     72d19d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d523:	4c 89 cb             	mov    %r9,%rbx
  72d526:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72d52b:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  72d52f:	b8 02 00 00 00       	mov    $0x2,%eax
  72d534:	4d 89 f1             	mov    %r14,%r9
  72d537:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72d53e:	00 00 
  72d540:	4d 89 ca             	mov    %r9,%r10
  72d543:	4d 8b 08             	mov    (%r8),%r9
  72d546:	4d 39 d1             	cmp    %r10,%r9
  72d549:	72 52                	jb     72d59d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x55d>
  72d54b:	48 ff c0             	inc    %rax
  72d54e:	49 83 c0 10          	add    $0x10,%r8
  72d552:	49 39 c7             	cmp    %rax,%r15
  72d555:	75 e9                	jne    72d540 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x500>
  72d557:	eb 2e                	jmp    72d587 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x547>
  72d559:	4c 89 cb             	mov    %r9,%rbx
  72d55c:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  72d561:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  72d565:	b8 02 00 00 00       	mov    $0x2,%eax
  72d56a:	4d 89 f1             	mov    %r14,%r9
  72d56d:	0f 1f 00             	nopl   (%rax)
  72d570:	4d 89 ca             	mov    %r9,%r10
  72d573:	4d 8b 08             	mov    (%r8),%r9
  72d576:	4d 39 d1             	cmp    %r10,%r9
  72d579:	73 22                	jae    72d59d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x55d>
  72d57b:	48 ff c0             	inc    %rax
  72d57e:	49 83 c0 10          	add    $0x10,%r8
  72d582:	49 39 c7             	cmp    %rax,%r15
  72d585:	75 e9                	jne    72d570 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x530>
  72d587:	4c 89 fe             	mov    %r15,%rsi
  72d58a:	4c 89 f8             	mov    %r15,%rax
  72d58d:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  72d592:	49 89 d9             	mov    %rbx,%r9
  72d595:	0f 82 ac fb ff ff    	jb     72d147 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x107>
  72d59b:	eb 11                	jmp    72d5ae <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x56e>
  72d59d:	4c 89 fe             	mov    %r15,%rsi
  72d5a0:	48 3b 44 24 18       	cmp    0x18(%rsp),%rax
  72d5a5:	49 89 d9             	mov    %rbx,%r9
  72d5a8:	0f 82 99 fb ff ff    	jb     72d147 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x107>
  72d5ae:	4d 39 de             	cmp    %r11,%r14
  72d5b1:	0f 83 e6 fb ff ff    	jae    72d19d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d5b7:	48 89 c6             	mov    %rax,%rsi
  72d5ba:	48 d1 ee             	shr    $1,%rsi
  72d5bd:	0f 84 da fb ff ff    	je     72d19d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d5c3:	49 89 c0             	mov    %rax,%r8
  72d5c6:	49 c1 e0 04          	shl    $0x4,%r8
  72d5ca:	4a 8d 1c 07          	lea    (%rdi,%r8,1),%rbx
  72d5ce:	48 83 fe 01          	cmp    $0x1,%rsi
  72d5d2:	75 04                	jne    72d5d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x598>
  72d5d4:	31 c9                	xor    %ecx,%ecx
  72d5d6:	eb 79                	jmp    72d651 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x611>
  72d5d8:	4d 89 ce             	mov    %r9,%r14
  72d5db:	49 89 f1             	mov    %rsi,%r9
  72d5de:	49 83 e1 fe          	and    $0xfffffffffffffffe,%r9
  72d5e2:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  72d5e7:	4c 8d 14 0a          	lea    (%rdx,%rcx,1),%r10
  72d5eb:	49 01 c8             	add    %rcx,%r8
  72d5ee:	4c 03 44 24 58       	add    0x58(%rsp),%r8
  72d5f3:	31 c9                	xor    %ecx,%ecx
  72d5f5:	48 ba fe ff ff ff ff 	movabs $0xffffffffffffffe,%rdx
  72d5fc:	ff ff 0f 
  72d5ff:	90                   	nop
  72d600:	41 0f 10 42 f0       	movups -0x10(%r10),%xmm0
  72d605:	41 0f 10 08          	movups (%r8),%xmm1
  72d609:	41 0f 11 4a f0       	movups %xmm1,-0x10(%r10)
  72d60e:	41 0f 11 00          	movups %xmm0,(%r8)
  72d612:	49 89 cb             	mov    %rcx,%r11
  72d615:	49 31 d3             	xor    %rdx,%r11
  72d618:	49 c1 e3 04          	shl    $0x4,%r11
  72d61c:	41 0f 10 02          	movups (%r10),%xmm0
  72d620:	42 0f 10 0c 1b       	movups (%rbx,%r11,1),%xmm1
  72d625:	41 0f 11 0a          	movups %xmm1,(%r10)
  72d629:	42 0f 11 04 1b       	movups %xmm0,(%rbx,%r11,1)
  72d62e:	48 83 c1 02          	add    $0x2,%rcx
  72d632:	49 83 c2 20          	add    $0x20,%r10
  72d636:	49 83 c0 e0          	add    $0xffffffffffffffe0,%r8
  72d63a:	49 39 c9             	cmp    %rcx,%r9
  72d63d:	75 c1                	jne    72d600 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x5c0>
  72d63f:	40 f6 c6 01          	test   $0x1,%sil
  72d643:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  72d648:	4d 89 f1             	mov    %r14,%r9
  72d64b:	0f 84 4c fb ff ff    	je     72d19d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d651:	48 89 ce             	mov    %rcx,%rsi
  72d654:	48 f7 d6             	not    %rsi
  72d657:	48 c1 e1 04          	shl    $0x4,%rcx
  72d65b:	48 c1 e6 04          	shl    $0x4,%rsi
  72d65f:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  72d663:	0f 10 0c 33          	movups (%rbx,%rsi,1),%xmm1
  72d667:	0f 11 0c 0f          	movups %xmm1,(%rdi,%rcx,1)
  72d66b:	0f 11 04 33          	movups %xmm0,(%rbx,%rsi,1)
  72d66f:	e9 29 fb ff ff       	jmp    72d19d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x15d>
  72d674:	41 f6 c4 01          	test   $0x1,%r12b
  72d678:	75 34                	jne    72d6ae <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_+0x66e>
  72d67a:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  72d67f:	48 89 f0             	mov    %rsi,%rax
  72d682:	48 83 c8 01          	or     $0x1,%rax
  72d686:	4c 0f bd c0          	bsr    %rax,%r8
  72d68a:	41 83 f0 3f          	xor    $0x3f,%r8d
  72d68e:	45 01 c0             	add    %r8d,%r8d
  72d691:	41 83 f0 7e          	xor    $0x7e,%r8d
  72d695:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72d69a:	48 89 04 24          	mov    %rax,(%rsp)
  72d69e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  72d6a3:	4c 89 e9             	mov    %r13,%rcx
  72d6a6:	45 31 c9             	xor    %r9d,%r9d
  72d6a9:	e8 92 1d 00 00       	call   72f440 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72d6ae:	48 81 c4 e8 02 00 00 	add    $0x2e8,%rsp
  72d6b5:	5b                   	pop    %rbx
  72d6b6:	41 5c                	pop    %r12
  72d6b8:	41 5d                	pop    %r13
  72d6ba:	41 5e                	pop    %r14
  72d6bc:	41 5f                	pop    %r15
  72d6be:	5d                   	pop    %rbp
  72d6bf:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
