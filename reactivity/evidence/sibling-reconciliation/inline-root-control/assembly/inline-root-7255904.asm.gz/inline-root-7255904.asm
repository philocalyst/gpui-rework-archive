
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006eb760 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_>:
  6eb760:	53                   	push   %rbx
  6eb761:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  6eb768:	48 89 fb             	mov    %rdi,%rbx
  6eb76b:	48 8b 06             	mov    (%rsi),%rax
  6eb76e:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6eb772:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6eb776:	48 85 ff             	test   %rdi,%rdi
  6eb779:	0f 84 e3 01 00 00    	je     6eb962 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x202>
  6eb77f:	48 8b 8c c8 c8 01 00 	mov    0x1c8(%rax,%rcx,8),%rcx
  6eb786:	00 
  6eb787:	48 89 f8             	mov    %rdi,%rax
  6eb78a:	48 ff c8             	dec    %rax
  6eb78d:	0f 84 cb 00 00 00    	je     6eb85e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0xfe>
  6eb793:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6eb797:	48 89 c6             	mov    %rax,%rsi
  6eb79a:	48 83 e6 07          	and    $0x7,%rsi
  6eb79e:	74 2b                	je     6eb7cb <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x6b>
  6eb7a0:	45 31 c0             	xor    %r8d,%r8d
  6eb7a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6eb7aa:	84 00 00 00 00 00 
  6eb7b0:	44 0f b7 89 c2 01 00 	movzwl 0x1c2(%rcx),%r9d
  6eb7b7:	00 
  6eb7b8:	4a 8b 8c c9 c8 01 00 	mov    0x1c8(%rcx,%r9,8),%rcx
  6eb7bf:	00 
  6eb7c0:	49 ff c0             	inc    %r8
  6eb7c3:	4c 39 c6             	cmp    %r8,%rsi
  6eb7c6:	75 e8                	jne    6eb7b0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x50>
  6eb7c8:	4c 29 c0             	sub    %r8,%rax
  6eb7cb:	48 83 ff 07          	cmp    $0x7,%rdi
  6eb7cf:	0f 82 89 00 00 00    	jb     6eb85e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0xfe>
  6eb7d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6eb7dc:	00 00 00 00 
  6eb7e0:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb7e7:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb7ee:	00 
  6eb7ef:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb7f6:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb7fd:	00 
  6eb7fe:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb805:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb80c:	00 
  6eb80d:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb814:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb81b:	00 
  6eb81c:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb823:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb82a:	00 
  6eb82b:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb832:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb839:	00 
  6eb83a:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb841:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb848:	00 
  6eb849:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6eb850:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6eb857:	00 
  6eb858:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6eb85c:	75 82                	jne    6eb7e0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x80>
  6eb85e:	0f b7 81 c2 01 00 00 	movzwl 0x1c2(%rcx),%eax
  6eb865:	48 ff c8             	dec    %rax
  6eb868:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6eb86d:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6eb874:	00 00 
  6eb876:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6eb87b:	48 89 e7             	mov    %rsp,%rdi
  6eb87e:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6eb883:	e8 78 5b 00 00       	call   6f1400 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>
  6eb888:	48 8b 3c 24          	mov    (%rsp),%rdi
  6eb88c:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6eb891:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6eb896:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6eb89b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  6eb8a0:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6eb8a5:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6eb8aa:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6eb8af:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  6eb8b6:	48 39 ce             	cmp    %rcx,%rsi
  6eb8b9:	72 1f                	jb     6eb8da <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x17a>
  6eb8bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6eb8c0:	0f b7 b0 c0 01 00 00 	movzwl 0x1c0(%rax),%esi
  6eb8c7:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6eb8ce:	48 ff c2             	inc    %rdx
  6eb8d1:	66 3b b0 c2 01 00 00 	cmp    0x1c2(%rax),%si
  6eb8d8:	73 e6                	jae    6eb8c0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x160>
  6eb8da:	49 89 f0             	mov    %rsi,%r8
  6eb8dd:	49 c1 e0 05          	shl    $0x5,%r8
  6eb8e1:	48 8b 8c f0 68 01 00 	mov    0x168(%rax,%rsi,8),%rcx
  6eb8e8:	00 
  6eb8e9:	48 89 bc f0 68 01 00 	mov    %rdi,0x168(%rax,%rsi,8)
  6eb8f0:	00 
  6eb8f1:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6eb8f6:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6eb8fc:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6eb901:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6eb905:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6eb90a:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6eb90f:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6eb914:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6eb91a:	48 85 d2             	test   %rdx,%rdx
  6eb91d:	74 6c                	je     6eb98b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x22b>
  6eb91f:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  6eb923:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6eb92a:	48 89 d6             	mov    %rdx,%rsi
  6eb92d:	48 83 e6 07          	and    $0x7,%rsi
  6eb931:	74 5d                	je     6eb990 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x230>
  6eb933:	45 31 c9             	xor    %r9d,%r9d
  6eb936:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6eb93d:	00 00 00 
  6eb940:	48 8b 07             	mov    (%rdi),%rax
  6eb943:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6eb94a:	49 ff c1             	inc    %r9
  6eb94d:	4c 39 ce             	cmp    %r9,%rsi
  6eb950:	75 ee                	jne    6eb940 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x1e0>
  6eb952:	49 89 d0             	mov    %rdx,%r8
  6eb955:	4d 29 c8             	sub    %r9,%r8
  6eb958:	31 f6                	xor    %esi,%esi
  6eb95a:	48 83 fa 08          	cmp    $0x8,%rdx
  6eb95e:	73 40                	jae    6eb9a0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x240>
  6eb960:	eb 7f                	jmp    6eb9e1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6eb962:	48 89 04 24          	mov    %rax,(%rsp)
  6eb966:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6eb96d:	00 00 
  6eb96f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6eb974:	48 89 e6             	mov    %rsp,%rsi
  6eb977:	48 89 df             	mov    %rbx,%rdi
  6eb97a:	e8 81 5a 00 00       	call   6f1400 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>
  6eb97f:	48 89 d8             	mov    %rbx,%rax
  6eb982:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6eb989:	5b                   	pop    %rbx
  6eb98a:	c3                   	ret
  6eb98b:	48 ff c6             	inc    %rsi
  6eb98e:	eb 51                	jmp    6eb9e1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6eb990:	49 89 d0             	mov    %rdx,%r8
  6eb993:	31 f6                	xor    %esi,%esi
  6eb995:	48 83 fa 08          	cmp    $0x8,%rdx
  6eb999:	72 46                	jb     6eb9e1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x281>
  6eb99b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6eb9a0:	48 8b 07             	mov    (%rdi),%rax
  6eb9a3:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb9aa:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb9b1:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb9b8:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb9bf:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb9c6:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb9cd:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6eb9d4:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6eb9db:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6eb9df:	75 bf                	jne    6eb9a0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_+0x240>
  6eb9e1:	48 89 0b             	mov    %rcx,(%rbx)
  6eb9e4:	0f 28 04 24          	movaps (%rsp),%xmm0
  6eb9e8:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6eb9ed:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6eb9f1:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6eb9f5:	48 89 43 28          	mov    %rax,0x28(%rbx)
  6eb9f9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
  6eba00:	00 
  6eba01:	48 89 73 38          	mov    %rsi,0x38(%rbx)
  6eba05:	48 89 d8             	mov    %rbx,%rax
  6eba08:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6eba0f:	5b                   	pop    %rbx
  6eba10:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
