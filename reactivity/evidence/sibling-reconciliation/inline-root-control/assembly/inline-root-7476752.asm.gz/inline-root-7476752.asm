
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000721610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_>:
  721610:	55                   	push   %rbp
  721611:	41 57                	push   %r15
  721613:	41 56                	push   %r14
  721615:	41 55                	push   %r13
  721617:	41 54                	push   %r12
  721619:	53                   	push   %rbx
  72161a:	48 83 ec 28          	sub    $0x28,%rsp
  72161e:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  721623:	49 89 f6             	mov    %rsi,%r14
  721626:	49 89 ff             	mov    %rdi,%r15
  721629:	48 83 fe 21          	cmp    $0x21,%rsi
  72162d:	73 1e                	jae    72164d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x3d>
  72162f:	4c 89 ff             	mov    %r15,%rdi
  721632:	4c 89 f6             	mov    %r14,%rsi
  721635:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  72163a:	48 83 c4 28          	add    $0x28,%rsp
  72163e:	5b                   	pop    %rbx
  72163f:	41 5c                	pop    %r12
  721641:	41 5d                	pop    %r13
  721643:	41 5e                	pop    %r14
  721645:	41 5f                	pop    %r15
  721647:	5d                   	pop    %rbp
  721648:	e9 43 e9 fe ff       	jmp    70ff90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_generalNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB1f_20sort_unstable_by_keyyNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB38_>
  72164d:	89 cb                	mov    %ecx,%ebx
  72164f:	49 89 d4             	mov    %rdx,%r12
  721652:	49 89 e5             	mov    %rsp,%r13
  721655:	eb 5e                	jmp    7216b5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0xa5>
  721657:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72165e:	00 00 
  721660:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  721664:	49 8b 57 10          	mov    0x10(%r15),%rdx
  721668:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  72166d:	41 0f 10 07          	movups (%r15),%xmm0
  721671:	0f 29 04 24          	movaps %xmm0,(%rsp)
  721675:	49 8b 54 cf 10       	mov    0x10(%r15,%rcx,8),%rdx
  72167a:	41 0f 10 04 cf       	movups (%r15,%rcx,8),%xmm0
  72167f:	41 0f 11 07          	movups %xmm0,(%r15)
  721683:	49 89 57 10          	mov    %rdx,0x10(%r15)
  721687:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72168c:	49 89 54 cf 10       	mov    %rdx,0x10(%r15,%rcx,8)
  721691:	0f 28 04 24          	movaps (%rsp),%xmm0
  721695:	41 0f 11 04 cf       	movups %xmm0,(%r15,%rcx,8)
  72169a:	48 f7 d0             	not    %rax
  72169d:	49 01 c6             	add    %rax,%r14
  7216a0:	4d 8d 3c cf          	lea    (%r15,%rcx,8),%r15
  7216a4:	49 83 c7 18          	add    $0x18,%r15
  7216a8:	45 31 e4             	xor    %r12d,%r12d
  7216ab:	49 83 fe 21          	cmp    $0x21,%r14
  7216af:	0f 82 7a ff ff ff    	jb     72162f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x1f>
  7216b5:	85 db                	test   %ebx,%ebx
  7216b7:	0f 84 44 03 00 00    	je     721a01 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x3f1>
  7216bd:	4c 89 f1             	mov    %r14,%rcx
  7216c0:	48 c1 e9 03          	shr    $0x3,%rcx
  7216c4:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  7216c8:	48 c1 e0 05          	shl    $0x5,%rax
  7216cc:	4c 01 f8             	add    %r15,%rax
  7216cf:	48 69 d1 a8 00 00 00 	imul   $0xa8,%rcx,%rdx
  7216d6:	4c 01 fa             	add    %r15,%rdx
  7216d9:	49 83 fe 40          	cmp    $0x40,%r14
  7216dd:	73 41                	jae    721720 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x110>
  7216df:	49 8b 0f             	mov    (%r15),%rcx
  7216e2:	48 8b 30             	mov    (%rax),%rsi
  7216e5:	48 39 f1             	cmp    %rsi,%rcx
  7216e8:	40 0f 92 c7          	setb   %dil
  7216ec:	4c 8b 02             	mov    (%rdx),%r8
  7216ef:	4c 39 c1             	cmp    %r8,%rcx
  7216f2:	0f 92 c1             	setb   %cl
  7216f5:	40 30 f9             	xor    %dil,%cl
  7216f8:	4c 39 c6             	cmp    %r8,%rsi
  7216fb:	40 0f 92 c6          	setb   %sil
  7216ff:	40 30 fe             	xor    %dil,%sil
  721702:	48 0f 45 c2          	cmovne %rdx,%rax
  721706:	84 c9                	test   %cl,%cl
  721708:	49 0f 45 c7          	cmovne %r15,%rax
  72170c:	ff cb                	dec    %ebx
  72170e:	4c 29 f8             	sub    %r15,%rax
  721711:	4d 85 e4             	test   %r12,%r12
  721714:	75 24                	jne    72173a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x12a>
  721716:	eb 30                	jmp    721748 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x138>
  721718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72171f:	00 
  721720:	4c 89 ff             	mov    %r15,%rdi
  721723:	48 89 c6             	mov    %rax,%rsi
  721726:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  72172b:	e8 e0 ce 00 00       	call   72e610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB14_20sort_unstable_by_keyyNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2X_>
  721730:	ff cb                	dec    %ebx
  721732:	4c 29 f8             	sub    %r15,%rax
  721735:	4d 85 e4             	test   %r12,%r12
  721738:	74 0e                	je     721748 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x138>
  72173a:	49 8b 0c 24          	mov    (%r12),%rcx
  72173e:	49 3b 0c 07          	cmp    (%r15,%rax,1),%rcx
  721742:	0f 83 98 01 00 00    	jae    7218e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x2d0>
  721748:	89 5c 24 24          	mov    %ebx,0x24(%rsp)
  72174c:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  721750:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  721755:	41 0f 10 07          	movups (%r15),%xmm0
  721759:	0f 29 04 24          	movaps %xmm0,(%rsp)
  72175d:	49 8b 4c 07 10       	mov    0x10(%r15,%rax,1),%rcx
  721762:	41 0f 10 04 07       	movups (%r15,%rax,1),%xmm0
  721767:	41 0f 11 07          	movups %xmm0,(%r15)
  72176b:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  72176f:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  721774:	49 89 4c 07 10       	mov    %rcx,0x10(%r15,%rax,1)
  721779:	0f 28 04 24          	movaps (%rsp),%xmm0
  72177d:	41 0f 11 04 07       	movups %xmm0,(%r15,%rax,1)
  721782:	49 8d 47 18          	lea    0x18(%r15),%rax
  721786:	49 8b 4f 28          	mov    0x28(%r15),%rcx
  72178a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72178f:	41 0f 10 47 18       	movups 0x18(%r15),%xmm0
  721794:	0f 29 04 24          	movaps %xmm0,(%rsp)
  721798:	4a 8d 34 f5 00 00 00 	lea    0x0(,%r14,8),%rsi
  72179f:	00 
  7217a0:	48 8d 3c 76          	lea    (%rsi,%rsi,2),%rdi
  7217a4:	4c 01 ff             	add    %r15,%rdi
  7217a7:	49 8d 4f 30          	lea    0x30(%r15),%rcx
  7217ab:	49 8b 17             	mov    (%r15),%rdx
  7217ae:	4c 8d 1c 76          	lea    (%rsi,%rsi,2),%r11
  7217b2:	49 83 c3 b8          	add    $0xffffffffffffffb8,%r11
  7217b6:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  7217ba:	49 83 c2 d0          	add    $0xffffffffffffffd0,%r10
  7217be:	31 f6                	xor    %esi,%esi
  7217c0:	4c 8b 41 10          	mov    0x10(%rcx),%r8
  7217c4:	48 39 11             	cmp    %rdx,(%rcx)
  7217c7:	4c 8d 0c 76          	lea    (%rsi,%rsi,2),%r9
  7217cb:	4a 8b 5c c8 10       	mov    0x10(%rax,%r9,8),%rbx
  7217d0:	42 0f 10 04 c8       	movups (%rax,%r9,8),%xmm0
  7217d5:	0f 11 41 e8          	movups %xmm0,-0x18(%rcx)
  7217d9:	48 89 59 f8          	mov    %rbx,-0x8(%rcx)
  7217dd:	4e 89 44 c8 10       	mov    %r8,0x10(%rax,%r9,8)
  7217e2:	0f 10 01             	movups (%rcx),%xmm0
  7217e5:	42 0f 11 04 c8       	movups %xmm0,(%rax,%r9,8)
  7217ea:	48 83 d6 00          	adc    $0x0,%rsi
  7217ee:	48 83 c1 18          	add    $0x18,%rcx
  7217f2:	4d 89 d8             	mov    %r11,%r8
  7217f5:	49 83 c3 e8          	add    $0xffffffffffffffe8,%r11
  7217f9:	4d 89 d1             	mov    %r10,%r9
  7217fc:	49 83 c2 e8          	add    $0xffffffffffffffe8,%r10
  721800:	48 39 f9             	cmp    %rdi,%rcx
  721803:	72 bb                	jb     7217c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x1b0>
  721805:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72180c:	00 00 00 00 
  721810:	4d 85 c0             	test   %r8,%r8
  721813:	48 89 cf             	mov    %rcx,%rdi
  721816:	49 0f 44 fd          	cmove  %r13,%rdi
  72181a:	48 39 17             	cmp    %rdx,(%rdi)
  72181d:	4c 8d 14 76          	lea    (%rsi,%rsi,2),%r10
  721821:	42 0f 10 04 d0       	movups (%rax,%r10,8),%xmm0
  721826:	4e 8b 5c d0 10       	mov    0x10(%rax,%r10,8),%r11
  72182b:	4c 89 59 f8          	mov    %r11,-0x8(%rcx)
  72182f:	0f 11 41 e8          	movups %xmm0,-0x18(%rcx)
  721833:	4c 8b 5f 10          	mov    0x10(%rdi),%r11
  721837:	4e 89 5c d0 10       	mov    %r11,0x10(%rax,%r10,8)
  72183c:	0f 10 07             	movups (%rdi),%xmm0
  72183f:	48 83 d6 00          	adc    $0x0,%rsi
  721843:	42 0f 11 04 d0       	movups %xmm0,(%rax,%r10,8)
  721848:	48 83 c1 18          	add    $0x18,%rcx
  72184c:	49 83 c0 e8          	add    $0xffffffffffffffe8,%r8
  721850:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  721854:	75 ba                	jne    721810 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x200>
  721856:	4c 39 f6             	cmp    %r14,%rsi
  721859:	0f 83 a0 01 00 00    	jae    7219ff <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x3ef>
  72185f:	48 8d 04 76          	lea    (%rsi,%rsi,2),%rax
  721863:	49 8d 1c c7          	lea    (%r15,%rax,8),%rbx
  721867:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  72186b:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  721870:	41 0f 10 07          	movups (%r15),%xmm0
  721874:	0f 29 04 24          	movaps %xmm0,(%rsp)
  721878:	49 8b 4c c7 10       	mov    0x10(%r15,%rax,8),%rcx
  72187d:	41 0f 10 04 c7       	movups (%r15,%rax,8),%xmm0
  721882:	41 0f 11 07          	movups %xmm0,(%r15)
  721886:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  72188a:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  72188f:	49 89 4c c7 10       	mov    %rcx,0x10(%r15,%rax,8)
  721894:	0f 28 04 24          	movaps (%rsp),%xmm0
  721898:	41 0f 11 04 c7       	movups %xmm0,(%r15,%rax,8)
  72189d:	49 8d 2c c7          	lea    (%r15,%rax,8),%rbp
  7218a1:	48 83 c5 18          	add    $0x18,%rbp
  7218a5:	48 89 f0             	mov    %rsi,%rax
  7218a8:	48 f7 d0             	not    %rax
  7218ab:	49 01 c6             	add    %rax,%r14
  7218ae:	4c 89 ff             	mov    %r15,%rdi
  7218b1:	4c 89 e2             	mov    %r12,%rdx
  7218b4:	44 8b 7c 24 24       	mov    0x24(%rsp),%r15d
  7218b9:	44 89 f9             	mov    %r15d,%ecx
  7218bc:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  7218c1:	e8 4a fd ff ff       	call   721610 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_>
  7218c6:	49 89 dc             	mov    %rbx,%r12
  7218c9:	44 89 fb             	mov    %r15d,%ebx
  7218cc:	49 89 ef             	mov    %rbp,%r15
  7218cf:	49 83 fe 21          	cmp    $0x21,%r14
  7218d3:	0f 83 dc fd ff ff    	jae    7216b5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0xa5>
  7218d9:	e9 51 fd ff ff       	jmp    72162f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x1f>
  7218de:	66 90                	xchg   %ax,%ax
  7218e0:	4c 01 f8             	add    %r15,%rax
  7218e3:	49 8b 4f 10          	mov    0x10(%r15),%rcx
  7218e7:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  7218ec:	41 0f 10 07          	movups (%r15),%xmm0
  7218f0:	0f 29 04 24          	movaps %xmm0,(%rsp)
  7218f4:	48 8b 48 10          	mov    0x10(%rax),%rcx
  7218f8:	0f 10 00             	movups (%rax),%xmm0
  7218fb:	41 0f 11 07          	movups %xmm0,(%r15)
  7218ff:	49 89 4f 10          	mov    %rcx,0x10(%r15)
  721903:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  721908:	48 89 48 10          	mov    %rcx,0x10(%rax)
  72190c:	0f 28 04 24          	movaps (%rsp),%xmm0
  721910:	0f 11 00             	movups %xmm0,(%rax)
  721913:	49 8d 4f 18          	lea    0x18(%r15),%rcx
  721917:	49 8b 47 28          	mov    0x28(%r15),%rax
  72191b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  721920:	41 0f 10 47 18       	movups 0x18(%r15),%xmm0
  721925:	0f 29 04 24          	movaps %xmm0,(%rsp)
  721929:	4a 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%rax
  721930:	00 
  721931:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
  721935:	4c 01 ff             	add    %r15,%rdi
  721938:	49 8d 57 30          	lea    0x30(%r15),%rdx
  72193c:	49 8b 37             	mov    (%r15),%rsi
  72193f:	4c 8d 1c 40          	lea    (%rax,%rax,2),%r11
  721943:	49 83 c3 b8          	add    $0xffffffffffffffb8,%r11
  721947:	4c 8d 14 40          	lea    (%rax,%rax,2),%r10
  72194b:	49 83 c2 d0          	add    $0xffffffffffffffd0,%r10
  72194f:	31 c0                	xor    %eax,%eax
  721951:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  721958:	0f 1f 84 00 00 00 00 
  72195f:	00 
  721960:	48 3b 32             	cmp    (%rdx),%rsi
  721963:	4c 8d 04 40          	lea    (%rax,%rax,2),%r8
  721967:	4e 8b 4c c1 10       	mov    0x10(%rcx,%r8,8),%r9
  72196c:	42 0f 10 04 c1       	movups (%rcx,%r8,8),%xmm0
  721971:	0f 11 42 e8          	movups %xmm0,-0x18(%rdx)
  721975:	4c 89 4a f8          	mov    %r9,-0x8(%rdx)
  721979:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
  72197d:	4e 89 4c c1 10       	mov    %r9,0x10(%rcx,%r8,8)
  721982:	0f 10 02             	movups (%rdx),%xmm0
  721985:	42 0f 11 04 c1       	movups %xmm0,(%rcx,%r8,8)
  72198a:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72198e:	48 83 c2 18          	add    $0x18,%rdx
  721992:	4d 89 d8             	mov    %r11,%r8
  721995:	49 83 c3 e8          	add    $0xffffffffffffffe8,%r11
  721999:	4d 89 d1             	mov    %r10,%r9
  72199c:	49 83 c2 e8          	add    $0xffffffffffffffe8,%r10
  7219a0:	48 39 fa             	cmp    %rdi,%rdx
  7219a3:	72 bb                	jb     721960 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x350>
  7219a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  7219ac:	00 00 00 00 
  7219b0:	4d 85 c0             	test   %r8,%r8
  7219b3:	48 89 d7             	mov    %rdx,%rdi
  7219b6:	49 0f 44 fd          	cmove  %r13,%rdi
  7219ba:	48 3b 37             	cmp    (%rdi),%rsi
  7219bd:	4c 8d 14 40          	lea    (%rax,%rax,2),%r10
  7219c1:	42 0f 10 04 d1       	movups (%rcx,%r10,8),%xmm0
  7219c6:	4e 8b 5c d1 10       	mov    0x10(%rcx,%r10,8),%r11
  7219cb:	4c 89 5a f8          	mov    %r11,-0x8(%rdx)
  7219cf:	0f 11 42 e8          	movups %xmm0,-0x18(%rdx)
  7219d3:	4c 8b 5f 10          	mov    0x10(%rdi),%r11
  7219d7:	4e 89 5c d1 10       	mov    %r11,0x10(%rcx,%r10,8)
  7219dc:	0f 10 07             	movups (%rdi),%xmm0
  7219df:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  7219e3:	42 0f 11 04 d1       	movups %xmm0,(%rcx,%r10,8)
  7219e8:	48 83 c2 18          	add    $0x18,%rdx
  7219ec:	49 83 c0 e8          	add    $0xffffffffffffffe8,%r8
  7219f0:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  7219f4:	75 ba                	jne    7219b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x3a0>
  7219f6:	4c 39 f0             	cmp    %r14,%rax
  7219f9:	0f 82 61 fc ff ff    	jb     721660 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB17_20sort_unstable_by_keyyNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB30_+0x50>
  7219ff:	0f 0b                	ud2
  721a01:	4c 89 ff             	mov    %r15,%rdi
  721a04:	4c 89 f6             	mov    %r14,%rsi
  721a07:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  721a0c:	48 83 c4 28          	add    $0x28,%rsp
  721a10:	5b                   	pop    %rbx
  721a11:	41 5c                	pop    %r12
  721a13:	41 5d                	pop    %r13
  721a15:	41 5e                	pop    %r14
  721a17:	41 5f                	pop    %r15
  721a19:	5d                   	pop    %rbp
  721a1a:	e9 a1 c1 00 00       	jmp    72dbc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
