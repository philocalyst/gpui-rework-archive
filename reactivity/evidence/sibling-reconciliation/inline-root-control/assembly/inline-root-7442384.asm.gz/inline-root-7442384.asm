
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000718fd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>:
  718fd0:	55                   	push   %rbp
  718fd1:	41 57                	push   %r15
  718fd3:	41 56                	push   %r14
  718fd5:	41 55                	push   %r13
  718fd7:	41 54                	push   %r12
  718fd9:	53                   	push   %rbx
  718fda:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
  718fe1:	48 89 fb             	mov    %rdi,%rbx
  718fe4:	4c 8b 26             	mov    (%rsi),%r12
  718fe7:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718feb:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  718fef:	4c 8b 6e 28          	mov    0x28(%rsi),%r13
  718ff3:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718ffa:	00 
  718ffb:	48 85 c0             	test   %rax,%rax
  718ffe:	0f 84 36 01 00 00    	je     71913a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x16a>
  719004:	49 89 f6             	mov    %rsi,%r14
  719007:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  71900b:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  719010:	0f b7 88 32 05 00 00 	movzwl 0x532(%rax),%ecx
  719017:	49 39 cd             	cmp    %rcx,%r13
  71901a:	73 14                	jae    719030 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  71901c:	49 89 c7             	mov    %rax,%r15
  71901f:	eb 37                	jmp    719058 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x88>
  719021:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  719028:	0f 1f 84 00 00 00 00 
  71902f:	00 
  719030:	4c 8b b8 d0 04 00 00 	mov    0x4d0(%rax),%r15
  719037:	4d 85 ff             	test   %r15,%r15
  71903a:	0f 84 fa 00 00 00    	je     71913a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x16a>
  719040:	48 ff c5             	inc    %rbp
  719043:	44 0f b7 a8 30 05 00 	movzwl 0x530(%rax),%r13d
  71904a:	00 
  71904b:	4c 89 f8             	mov    %r15,%rax
  71904e:	66 45 3b af 32 05 00 	cmp    0x532(%r15),%r13w
  719055:	00 
  719056:	73 d8                	jae    719030 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  719058:	4b 8b b4 ef d8 04 00 	mov    0x4d8(%r15,%r13,8),%rsi
  71905f:	00 
  719060:	49 8b 04 24          	mov    (%r12),%rax
  719064:	48 8b 38             	mov    (%rax),%rdi
  719067:	ff 15 23 f2 3c 00    	call   *0x3cf223(%rip)        # ae8290 <_DYNAMIC+0x6f8>
  71906d:	84 c0                	test   %al,%al
  71906f:	0f 84 e1 00 00 00    	je     719156 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x186>
  719075:	48 85 ed             	test   %rbp,%rbp
  719078:	0f 84 88 00 00 00    	je     719106 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x136>
  71907e:	4b 8d 04 ef          	lea    (%r15,%r13,8),%rax
  719082:	48 05 40 05 00 00    	add    $0x540,%rax
  719088:	48 89 e9             	mov    %rbp,%rcx
  71908b:	48 83 e1 07          	and    $0x7,%rcx
  71908f:	0f 84 9a 00 00 00    	je     71912f <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x15f>
  719095:	31 d2                	xor    %edx,%edx
  719097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  71909e:	00 00 
  7190a0:	4c 8b 38             	mov    (%rax),%r15
  7190a3:	49 8d 87 38 05 00 00 	lea    0x538(%r15),%rax
  7190aa:	48 ff c2             	inc    %rdx
  7190ad:	48 39 d1             	cmp    %rdx,%rcx
  7190b0:	75 ee                	jne    7190a0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xd0>
  7190b2:	48 89 e9             	mov    %rbp,%rcx
  7190b5:	48 29 d1             	sub    %rdx,%rcx
  7190b8:	48 83 fd 08          	cmp    $0x8,%rbp
  7190bc:	72 43                	jb     719101 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x131>
  7190be:	66 90                	xchg   %ax,%ax
  7190c0:	48 8b 00             	mov    (%rax),%rax
  7190c3:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7190ca:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7190d1:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7190d8:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7190df:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7190e6:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7190ed:	4c 8b b8 38 05 00 00 	mov    0x538(%rax),%r15
  7190f4:	49 8d 87 38 05 00 00 	lea    0x538(%r15),%rax
  7190fb:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  7190ff:	75 bf                	jne    7190c0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xf0>
  719101:	45 31 ed             	xor    %r13d,%r13d
  719104:	eb 03                	jmp    719109 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x139>
  719106:	49 ff c5             	inc    %r13
  719109:	4d 89 6e 28          	mov    %r13,0x28(%r14)
  71910d:	0f 57 c0             	xorps  %xmm0,%xmm0
  719110:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  719115:	31 ed                	xor    %ebp,%ebp
  719117:	4c 89 f8             	mov    %r15,%rax
  71911a:	0f b7 88 32 05 00 00 	movzwl 0x532(%rax),%ecx
  719121:	49 39 cd             	cmp    %rcx,%r13
  719124:	0f 83 06 ff ff ff    	jae    719030 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x60>
  71912a:	e9 ed fe ff ff       	jmp    71901c <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x4c>
  71912f:	48 89 e9             	mov    %rbp,%rcx
  719132:	48 83 fd 08          	cmp    $0x8,%rbp
  719136:	73 88                	jae    7190c0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0xf0>
  719138:	eb c7                	jmp    719101 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x131>
  71913a:	c7 43 08 02 00 00 00 	movl   $0x2,0x8(%rbx)
  719141:	48 89 d8             	mov    %rbx,%rax
  719144:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
  71914b:	5b                   	pop    %rbx
  71914c:	41 5c                	pop    %r12
  71914e:	41 5d                	pop    %r13
  719150:	41 5e                	pop    %r14
  719152:	41 5f                	pop    %r15
  719154:	5d                   	pop    %rbp
  719155:	c3                   	ret
  719156:	49 8b 46 08          	mov    0x8(%r14),%rax
  71915a:	48 ff 08             	decq   (%rax)
  71915d:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
  719162:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  719167:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  71916c:	49 83 c6 10          	add    $0x10,%r14
  719170:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  719175:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  71917a:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  71917f:	4c 89 f2             	mov    %r14,%rdx
  719182:	e8 59 2b fd ff       	call   6ebce0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1O_5style5StyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3J_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3J_INtB3J_8BTreeMapyB1J_E6retainNCINvMsi_B1M_NtB1M_9Overrides6retainNCNvMst_NtB1O_7runtimeINtB6x_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtB9_5alloc6GlobalE0B8d_EB72_>
  719187:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  71918e:	00 
  71918f:	48 89 43 70          	mov    %rax,0x70(%rbx)
  719193:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  71919a:	00 
  71919b:	0f 11 43 60          	movups %xmm0,0x60(%rbx)
  71919f:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  7191a6:	00 
  7191a7:	0f 11 43 50          	movups %xmm0,0x50(%rbx)
  7191ab:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  7191b0:	0f 11 43 40          	movups %xmm0,0x40(%rbx)
  7191b4:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  7191b9:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  7191be:	0f 10 54 24 58       	movups 0x58(%rsp),%xmm2
  7191c3:	0f 10 5c 24 68       	movups 0x68(%rsp),%xmm3
  7191c8:	0f 11 5b 30          	movups %xmm3,0x30(%rbx)
  7191cc:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
  7191d0:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  7191d4:	0f 11 03             	movups %xmm0,(%rbx)
  7191d7:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  7191de:	00 
  7191df:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  7191e4:	0f 10 84 24 b0 00 00 	movups 0xb0(%rsp),%xmm0
  7191eb:	00 
  7191ec:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  7191f1:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  7191f6:	48 89 41 10          	mov    %rax,0x10(%rcx)
  7191fa:	0f 11 01             	movups %xmm0,(%rcx)
  7191fd:	e9 3f ff ff ff       	jmp    719141 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_+0x171>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
