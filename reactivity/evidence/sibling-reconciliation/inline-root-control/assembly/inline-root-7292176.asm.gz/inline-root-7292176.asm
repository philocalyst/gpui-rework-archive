
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006f4510 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersE_0EB2U_>:
  6f4510:	41 56                	push   %r14
  6f4512:	53                   	push   %rbx
  6f4513:	48 81 ec 08 01 00 00 	sub    $0x108,%rsp
  6f451a:	48 83 3f 00          	cmpq   $0x0,(%rdi)
  6f451e:	0f 85 c3 00 00 00    	jne    6f45e7 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersE_0EB2U_+0xd7>
  6f4524:	49 89 fe             	mov    %rdi,%r14
  6f4527:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
  6f452e:	00 00 00 00 00 
  6f4533:	0f 57 c0             	xorps  %xmm0,%xmm0
  6f4536:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f453d:	00 
  6f453e:	48 c7 84 24 c8 00 00 	movq   $0x8,0xc8(%rsp)
  6f4545:	00 08 00 00 00 
  6f454a:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  6f4551:	00 00 00 00 00 
  6f4556:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
  6f455d:	00 00 00 00 00 
  6f4562:	0f 11 84 24 f8 00 00 	movups %xmm0,0xf8(%rsp)
  6f4569:	00 
  6f456a:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  6f4571:	00 
  6f4572:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  6f4579:	00 00 
  6f457b:	48 c7 44 24 20 08 00 	movq   $0x8,0x20(%rsp)
  6f4582:	00 00 
  6f4584:	0f 11 44 24 28       	movups %xmm0,0x28(%rsp)
  6f4589:	48 c7 44 24 38 08 00 	movq   $0x8,0x38(%rsp)
  6f4590:	00 00 
  6f4592:	0f 11 44 24 40       	movups %xmm0,0x40(%rsp)
  6f4597:	48 c7 44 24 50 08 00 	movq   $0x8,0x50(%rsp)
  6f459e:	00 00 
  6f45a0:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f45a7:	00 00 
  6f45a9:	48 c7 44 24 60 ff ff 	movq   $0xffffffffffffffff,0x60(%rsp)
  6f45b0:	ff ff 
  6f45b2:	ff 15 40 38 3f 00    	call   *0x3f3840(%rip)        # ae7df8 <_DYNAMIC+0x260>
  6f45b8:	bf 08 01 00 00       	mov    $0x108,%edi
  6f45bd:	be 08 00 00 00       	mov    $0x8,%esi
  6f45c2:	ff 15 10 38 3f 00    	call   *0x3f3810(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  6f45c8:	48 85 c0             	test   %rax,%rax
  6f45cb:	74 28                	je     6f45f5 <_RINvMNtCs4NRVxsYgnAr_4core6optionINtB3_6OptionINtNtCscdodAO9FK5_5alloc5boxed3BoxNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataEE18get_or_insert_withNCNvMst_B1k_INtB1k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersE_0EB2U_+0xe5>
  6f45cd:	48 89 c3             	mov    %rax,%rbx
  6f45d0:	48 89 e6             	mov    %rsp,%rsi
  6f45d3:	ba 08 01 00 00       	mov    $0x108,%edx
  6f45d8:	48 89 c7             	mov    %rax,%rdi
  6f45db:	ff 15 27 38 3f 00    	call   *0x3f3827(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  6f45e1:	4c 89 f7             	mov    %r14,%rdi
  6f45e4:	49 89 1e             	mov    %rbx,(%r14)
  6f45e7:	48 89 f8             	mov    %rdi,%rax
  6f45ea:	48 81 c4 08 01 00 00 	add    $0x108,%rsp
  6f45f1:	5b                   	pop    %rbx
  6f45f2:	41 5e                	pop    %r14
  6f45f4:	c3                   	ret
  6f45f5:	bf 08 00 00 00       	mov    $0x8,%edi
  6f45fa:	be 08 01 00 00       	mov    $0x108,%esi
  6f45ff:	ff 15 0b 38 3f 00    	call   *0x3f380b(%rip)        # ae7e10 <_DYNAMIC+0x278>
  6f4605:	0f 0b                	ud2
  6f4607:	48 89 c3             	mov    %rax,%rbx
  6f460a:	48 89 e7             	mov    %rsp,%rdi
  6f460d:	e8 3e 52 00 00       	call   6f9850 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8MetadataECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f4612:	48 89 df             	mov    %rbx,%rdi
  6f4615:	e8 36 3f 3c 00       	call   ab8550 <_Unwind_Resume@plt>
  6f461a:	ff 15 10 38 3f 00    	call   *0x3f3810(%rip)        # ae7e30 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
