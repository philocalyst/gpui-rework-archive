
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000714ab0 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_>:
  714ab0:	55                   	push   %rbp
  714ab1:	41 57                	push   %r15
  714ab3:	41 56                	push   %r14
  714ab5:	41 55                	push   %r13
  714ab7:	41 54                	push   %r12
  714ab9:	53                   	push   %rbx
  714aba:	48 83 ec 58          	sub    $0x58,%rsp
  714abe:	49 89 d5             	mov    %rdx,%r13
  714ac1:	48 89 fb             	mov    %rdi,%rbx
  714ac4:	48 89 d0             	mov    %rdx,%rax
  714ac7:	48 29 f0             	sub    %rsi,%rax
  714aca:	48 c1 e8 03          	shr    $0x3,%rax
  714ace:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  714ad5:	c3 30 0c 
  714ad8:	48 f7 e1             	mul    %rcx
  714adb:	49 29 f5             	sub    %rsi,%r13
  714ade:	74 42                	je     714b22 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x72>
  714ae0:	48 89 f5             	mov    %rsi,%rbp
  714ae3:	49 89 d4             	mov    %rdx,%r12
  714ae6:	49 89 d6             	mov    %rdx,%r14
  714ae9:	49 c1 e6 04          	shl    $0x4,%r14
  714aed:	ff 15 05 33 3d 00    	call   *0x3d3305(%rip)        # ae7df8 <_DYNAMIC+0x260>
  714af3:	be 08 00 00 00       	mov    $0x8,%esi
  714af8:	4c 89 f7             	mov    %r14,%rdi
  714afb:	ff 15 d7 32 3d 00    	call   *0x3d32d7(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  714b01:	48 85 c0             	test   %rax,%rax
  714b04:	0f 84 b9 01 00 00    	je     714cc3 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x213>
  714b0a:	49 89 c7             	mov    %rax,%r15
  714b0d:	49 8d 44 24 ff       	lea    -0x1(%r12),%rax
  714b12:	44 89 e1             	mov    %r12d,%ecx
  714b15:	83 e1 03             	and    $0x3,%ecx
  714b18:	48 83 f8 03          	cmp    $0x3,%rax
  714b1c:	73 18                	jae    714b36 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x86>
  714b1e:	31 c0                	xor    %eax,%eax
  714b20:	eb 6e                	jmp    714b90 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0xe0>
  714b22:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  714b29:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  714b30:	00 
  714b31:	e9 46 01 00 00       	jmp    714c7c <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x1cc>
  714b36:	4c 89 e2             	mov    %r12,%rdx
  714b39:	48 83 e2 fc          	and    $0xfffffffffffffffc,%rdx
  714b3d:	48 8d b5 90 02 00 00 	lea    0x290(%rbp),%rsi
  714b44:	49 8d 7f 30          	lea    0x30(%r15),%rdi
  714b48:	31 c0                	xor    %eax,%eax
  714b4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  714b50:	0f 10 86 08 fe ff ff 	movups -0x1f8(%rsi),%xmm0
  714b57:	0f 11 47 d0          	movups %xmm0,-0x30(%rdi)
  714b5b:	0f 10 86 b0 fe ff ff 	movups -0x150(%rsi),%xmm0
  714b62:	0f 11 47 e0          	movups %xmm0,-0x20(%rdi)
  714b66:	0f 10 86 58 ff ff ff 	movups -0xa8(%rsi),%xmm0
  714b6d:	0f 11 47 f0          	movups %xmm0,-0x10(%rdi)
  714b71:	0f 10 06             	movups (%rsi),%xmm0
  714b74:	0f 11 07             	movups %xmm0,(%rdi)
  714b77:	48 83 c0 04          	add    $0x4,%rax
  714b7b:	48 81 c6 a0 02 00 00 	add    $0x2a0,%rsi
  714b82:	48 83 c7 40          	add    $0x40,%rdi
  714b86:	48 39 c2             	cmp    %rax,%rdx
  714b89:	75 c5                	jne    714b50 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0xa0>
  714b8b:	48 85 c9             	test   %rcx,%rcx
  714b8e:	74 47                	je     714bd7 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x127>
  714b90:	48 69 d0 a8 00 00 00 	imul   $0xa8,%rax,%rdx
  714b97:	48 c1 e0 04          	shl    $0x4,%rax
  714b9b:	4c 01 f8             	add    %r15,%rax
  714b9e:	48 01 ea             	add    %rbp,%rdx
  714ba1:	48 81 c2 98 00 00 00 	add    $0x98,%rdx
  714ba8:	48 69 c9 a8 00 00 00 	imul   $0xa8,%rcx,%rcx
  714baf:	31 f6                	xor    %esi,%esi
  714bb1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  714bb8:	0f 1f 84 00 00 00 00 
  714bbf:	00 
  714bc0:	0f 10 04 32          	movups (%rdx,%rsi,1),%xmm0
  714bc4:	0f 11 00             	movups %xmm0,(%rax)
  714bc7:	48 83 c0 10          	add    $0x10,%rax
  714bcb:	48 81 c6 a8 00 00 00 	add    $0xa8,%rsi
  714bd2:	48 39 f1             	cmp    %rsi,%rcx
  714bd5:	75 e9                	jne    714bc0 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x110>
  714bd7:	48 8d 44 24 07       	lea    0x7(%rsp),%rax
  714bdc:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  714be1:	49 81 fd a8 00 00 00 	cmp    $0xa8,%r13
  714be8:	0f 85 a0 00 00 00    	jne    714c8e <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x1de>
  714bee:	ff 15 04 32 3d 00    	call   *0x3d3204(%rip)        # ae7df8 <_DYNAMIC+0x260>
  714bf4:	bf c0 00 00 00       	mov    $0xc0,%edi
  714bf9:	be 08 00 00 00       	mov    $0x8,%esi
  714bfe:	ff 15 d4 31 3d 00    	call   *0x3d31d4(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  714c04:	48 85 c0             	test   %rax,%rax
  714c07:	0f 84 a4 00 00 00    	je     714cb1 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x201>
  714c0d:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  714c14:	66 c7 80 ba 00 00 00 	movw   $0x0,0xba(%rax)
  714c1b:	00 00 
  714c1d:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  714c24:	00 00 
  714c26:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  714c2b:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  714c32:	00 00 
  714c34:	4c 89 f8             	mov    %r15,%rax
  714c37:	4c 01 f0             	add    %r14,%rax
  714c3a:	48 c7 44 24 20 02 00 	movq   $0x2,0x20(%rsp)
  714c41:	00 00 
  714c43:	4c 89 7c 24 38       	mov    %r15,0x38(%rsp)
  714c48:	4c 89 7c 24 40       	mov    %r15,0x40(%rsp)
  714c4d:	4c 89 64 24 48       	mov    %r12,0x48(%rsp)
  714c52:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  714c57:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  714c5c:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  714c61:	48 8d 54 24 08       	lea    0x8(%rsp),%rdx
  714c66:	e8 d5 59 fd ff       	call   6ea640 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBV_6marker5OwnedjNtNtCshBhuxcId5D0_4gpui4list6ListIdNtB1f_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterjB1y_INtNtNtB9_3vec9into_iter8IntoIterTjB1y_EEENtNtB9_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  714c6b:	0f 10 44 24 10       	movups 0x10(%rsp),%xmm0
  714c70:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  714c75:	0f 11 03             	movups %xmm0,(%rbx)
  714c78:	48 89 43 10          	mov    %rax,0x10(%rbx)
  714c7c:	48 89 d8             	mov    %rbx,%rax
  714c7f:	48 83 c4 58          	add    $0x58,%rsp
  714c83:	5b                   	pop    %rbx
  714c84:	41 5c                	pop    %r12
  714c86:	41 5d                	pop    %r13
  714c88:	41 5e                	pop    %r14
  714c8a:	41 5f                	pop    %r15
  714c8c:	5d                   	pop    %rbp
  714c8d:	c3                   	ret
  714c8e:	49 81 fd c8 0d 00 00 	cmp    $0xdc8,%r13
  714c95:	73 3a                	jae    714cd1 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x221>
  714c97:	48 8d 4c 24 20       	lea    0x20(%rsp),%rcx
  714c9c:	ba 01 00 00 00       	mov    $0x1,%edx
  714ca1:	4c 89 ff             	mov    %r15,%rdi
  714ca4:	4c 89 e6             	mov    %r12,%rsi
  714ca7:	e8 c4 c6 ff ff       	call   711370 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB3S_8adapters3map3MapINtNtB8_4iter4IterNtB1q_9ListDraftENCNvMst_NtB1s_7runtimeINtB5T_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6o_>
  714cac:	e9 3d ff ff ff       	jmp    714bee <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x13e>
  714cb1:	bf 08 00 00 00       	mov    $0x8,%edi
  714cb6:	be c0 00 00 00       	mov    $0xc0,%esi
  714cbb:	ff 15 4f 31 3d 00    	call   *0x3d314f(%rip)        # ae7e10 <_DYNAMIC+0x278>
  714cc1:	0f 0b                	ud2
  714cc3:	bf 08 00 00 00       	mov    $0x8,%edi
  714cc8:	4c 89 f6             	mov    %r14,%rsi
  714ccb:	ff 15 ef 31 3d 00    	call   *0x3d31ef(%rip)        # ae7ec0 <_DYNAMIC+0x328>
  714cd1:	48 8d 54 24 20       	lea    0x20(%rsp),%rdx
  714cd6:	4c 89 ff             	mov    %r15,%rdi
  714cd9:	4c 89 e6             	mov    %r12,%rsi
  714cdc:	e8 8f 91 01 00       	call   72de70 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_>
  714ce1:	e9 08 ff ff ff       	jmp    714bee <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x13e>
  714ce6:	eb 00                	jmp    714ce8 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapjNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTjB19_EE9from_iterINtNtNtB1Q_8adapters3map3MapINtNtNtB1S_5slice4iter4IterNtB1b_9ListDraftENCNvMst_NtB1d_7runtimeINtB4j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EEB4O_+0x238>
  714ce8:	48 89 c3             	mov    %rax,%rbx
  714ceb:	ba 08 00 00 00       	mov    $0x8,%edx
  714cf0:	4c 89 ff             	mov    %r15,%rdi
  714cf3:	4c 89 f6             	mov    %r14,%rsi
  714cf6:	ff 15 e4 30 3d 00    	call   *0x3d30e4(%rip)        # ae7de0 <_DYNAMIC+0x248>
  714cfc:	48 89 df             	mov    %rbx,%rdi
  714cff:	e8 4c 38 3a 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
