
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000007212f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>:
  7212f0:	55                   	push   %rbp
  7212f1:	41 57                	push   %r15
  7212f3:	41 56                	push   %r14
  7212f5:	41 55                	push   %r13
  7212f7:	41 54                	push   %r12
  7212f9:	53                   	push   %rbx
  7212fa:	50                   	push   %rax
  7212fb:	4c 89 04 24          	mov    %r8,(%rsp)
  7212ff:	49 89 f6             	mov    %rsi,%r14
  721302:	49 89 ff             	mov    %rdi,%r15
  721305:	48 83 fe 21          	cmp    $0x21,%rsi
  721309:	73 1d                	jae    721328 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x38>
  72130b:	4c 89 ff             	mov    %r15,%rdi
  72130e:	4c 89 f6             	mov    %r14,%rsi
  721311:	48 8b 14 24          	mov    (%rsp),%rdx
  721315:	48 83 c4 08          	add    $0x8,%rsp
  721319:	5b                   	pop    %rbx
  72131a:	41 5c                	pop    %r12
  72131c:	41 5d                	pop    %r13
  72131e:	41 5e                	pop    %r14
  721320:	41 5f                	pop    %r15
  721322:	5d                   	pop    %rbp
  721323:	e9 38 f6 fe ff       	jmp    710960 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_>
  721328:	89 cd                	mov    %ecx,%ebp
  72132a:	49 89 d4             	mov    %rdx,%r12
  72132d:	eb 3f                	jmp    72136e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x7e>
  72132f:	90                   	nop
  721330:	39 d6                	cmp    %edx,%esi
  721332:	8b 34 81             	mov    (%rcx,%rax,4),%esi
  721335:	41 89 30             	mov    %esi,(%r8)
  721338:	89 14 81             	mov    %edx,(%rcx,%rax,4)
  72133b:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72133f:	4c 39 f0             	cmp    %r14,%rax
  721342:	0f 83 c2 02 00 00    	jae    72160a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x31a>
  721348:	41 8b 0f             	mov    (%r15),%ecx
  72134b:	41 8b 14 87          	mov    (%r15,%rax,4),%edx
  72134f:	41 89 17             	mov    %edx,(%r15)
  721352:	41 89 0c 87          	mov    %ecx,(%r15,%rax,4)
  721356:	48 8d 48 01          	lea    0x1(%rax),%rcx
  72135a:	49 29 ce             	sub    %rcx,%r14
  72135d:	4d 8d 3c 87          	lea    (%r15,%rax,4),%r15
  721361:	49 83 c7 04          	add    $0x4,%r15
  721365:	45 31 e4             	xor    %r12d,%r12d
  721368:	49 83 fe 21          	cmp    $0x21,%r14
  72136c:	72 9d                	jb     72130b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1b>
  72136e:	85 ed                	test   %ebp,%ebp
  721370:	0f 84 77 02 00 00    	je     7215ed <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2fd>
  721376:	4c 89 f1             	mov    %r14,%rcx
  721379:	48 c1 e9 03          	shr    $0x3,%rcx
  72137d:	48 89 c8             	mov    %rcx,%rax
  721380:	48 c1 e0 04          	shl    $0x4,%rax
  721384:	4c 01 f8             	add    %r15,%rax
  721387:	48 8d 14 c9          	lea    (%rcx,%rcx,8),%rdx
  72138b:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  72138f:	4c 01 fa             	add    %r15,%rdx
  721392:	48 01 ca             	add    %rcx,%rdx
  721395:	49 83 fe 40          	cmp    $0x40,%r14
  721399:	0f 83 d1 00 00 00    	jae    721470 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x180>
  72139f:	41 8b 0f             	mov    (%r15),%ecx
  7213a2:	8b 30                	mov    (%rax),%esi
  7213a4:	39 f1                	cmp    %esi,%ecx
  7213a6:	40 0f 92 c7          	setb   %dil
  7213aa:	44 8b 02             	mov    (%rdx),%r8d
  7213ad:	44 39 c1             	cmp    %r8d,%ecx
  7213b0:	0f 92 c1             	setb   %cl
  7213b3:	40 30 f9             	xor    %dil,%cl
  7213b6:	44 39 c6             	cmp    %r8d,%esi
  7213b9:	40 0f 92 c6          	setb   %sil
  7213bd:	40 30 fe             	xor    %dil,%sil
  7213c0:	48 0f 45 c2          	cmovne %rdx,%rax
  7213c4:	84 c9                	test   %cl,%cl
  7213c6:	49 0f 45 c7          	cmovne %r15,%rax
  7213ca:	ff cd                	dec    %ebp
  7213cc:	4c 29 f8             	sub    %r15,%rax
  7213cf:	4d 85 e4             	test   %r12,%r12
  7213d2:	0f 84 b5 00 00 00    	je     72148d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x19d>
  7213d8:	41 8b 14 07          	mov    (%r15,%rax,1),%edx
  7213dc:	41 8b 0f             	mov    (%r15),%ecx
  7213df:	41 39 14 24          	cmp    %edx,(%r12)
  7213e3:	0f 82 ab 00 00 00    	jb     721494 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1a4>
  7213e9:	41 89 17             	mov    %edx,(%r15)
  7213ec:	41 89 0c 07          	mov    %ecx,(%r15,%rax,1)
  7213f0:	49 8d 4f 04          	lea    0x4(%r15),%rcx
  7213f4:	41 8b 37             	mov    (%r15),%esi
  7213f7:	41 8b 57 04          	mov    0x4(%r15),%edx
  7213fb:	4f 8d 04 b7          	lea    (%r15,%r14,4),%r8
  7213ff:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  721403:	49 8d 7f 08          	lea    0x8(%r15),%rdi
  721407:	4c 39 c7             	cmp    %r8,%rdi
  72140a:	0f 83 99 01 00 00    	jae    7215a9 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2b9>
  721410:	31 c0                	xor    %eax,%eax
  721412:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  721419:	1f 84 00 00 00 00 00 
  721420:	44 8b 0f             	mov    (%rdi),%r9d
  721423:	44 39 ce             	cmp    %r9d,%esi
  721426:	44 8b 14 81          	mov    (%rcx,%rax,4),%r10d
  72142a:	44 89 57 fc          	mov    %r10d,-0x4(%rdi)
  72142e:	44 89 0c 81          	mov    %r9d,(%rcx,%rax,4)
  721432:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  721436:	44 8b 4f 04          	mov    0x4(%rdi),%r9d
  72143a:	44 39 ce             	cmp    %r9d,%esi
  72143d:	44 8b 14 81          	mov    (%rcx,%rax,4),%r10d
  721441:	44 89 17             	mov    %r10d,(%rdi)
  721444:	44 89 0c 81          	mov    %r9d,(%rcx,%rax,4)
  721448:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  72144c:	48 83 c7 08          	add    $0x8,%rdi
  721450:	4c 39 c7             	cmp    %r8,%rdi
  721453:	72 cb                	jb     721420 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x130>
  721455:	4c 8d 47 fc          	lea    -0x4(%rdi),%r8
  721459:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  72145d:	4c 39 cf             	cmp    %r9,%rdi
  721460:	0f 85 5a 01 00 00    	jne    7215c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2d0>
  721466:	e9 c5 fe ff ff       	jmp    721330 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  72146b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  721470:	4c 89 ff             	mov    %r15,%rdi
  721473:	48 89 c6             	mov    %rax,%rsi
  721476:	4c 8b 04 24          	mov    (%rsp),%r8
  72147a:	e8 c1 d0 00 00       	call   72e540 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB14_20sort_unstable_by_keymNCNvMst_B18_INtB18_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB31_>
  72147f:	ff cd                	dec    %ebp
  721481:	4c 29 f8             	sub    %r15,%rax
  721484:	4d 85 e4             	test   %r12,%r12
  721487:	0f 85 4b ff ff ff    	jne    7213d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0xe8>
  72148d:	41 8b 0f             	mov    (%r15),%ecx
  721490:	41 8b 14 07          	mov    (%r15,%rax,1),%edx
  721494:	41 89 17             	mov    %edx,(%r15)
  721497:	41 89 0c 07          	mov    %ecx,(%r15,%rax,1)
  72149b:	49 8d 47 04          	lea    0x4(%r15),%rax
  72149f:	41 8b 17             	mov    (%r15),%edx
  7214a2:	41 8b 4f 04          	mov    0x4(%r15),%ecx
  7214a6:	4f 8d 04 b7          	lea    (%r15,%r14,4),%r8
  7214aa:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  7214ae:	49 8d 7f 08          	lea    0x8(%r15),%rdi
  7214b2:	4c 39 c7             	cmp    %r8,%rdi
  7214b5:	73 59                	jae    721510 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x220>
  7214b7:	31 f6                	xor    %esi,%esi
  7214b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  7214c0:	44 8b 0f             	mov    (%rdi),%r9d
  7214c3:	45 31 d2             	xor    %r10d,%r10d
  7214c6:	41 39 d1             	cmp    %edx,%r9d
  7214c9:	41 0f 92 c2          	setb   %r10b
  7214cd:	44 8b 1c b0          	mov    (%rax,%rsi,4),%r11d
  7214d1:	44 89 5f fc          	mov    %r11d,-0x4(%rdi)
  7214d5:	44 89 0c b0          	mov    %r9d,(%rax,%rsi,4)
  7214d9:	4e 8d 0c 16          	lea    (%rsi,%r10,1),%r9
  7214dd:	44 8b 5f 04          	mov    0x4(%rdi),%r11d
  7214e1:	41 39 d3             	cmp    %edx,%r11d
  7214e4:	46 8b 2c 88          	mov    (%rax,%r9,4),%r13d
  7214e8:	44 89 2f             	mov    %r13d,(%rdi)
  7214eb:	46 89 1c 88          	mov    %r11d,(%rax,%r9,4)
  7214ef:	4c 11 d6             	adc    %r10,%rsi
  7214f2:	48 83 c7 08          	add    $0x8,%rdi
  7214f6:	4c 39 c7             	cmp    %r8,%rdi
  7214f9:	72 c5                	jb     7214c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1d0>
  7214fb:	4c 8d 47 fc          	lea    -0x4(%rdi),%r8
  7214ff:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  721503:	4c 39 cf             	cmp    %r9,%rdi
  721506:	75 18                	jne    721520 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x230>
  721508:	eb 3e                	jmp    721548 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x258>
  72150a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  721510:	49 89 c0             	mov    %rax,%r8
  721513:	31 f6                	xor    %esi,%esi
  721515:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  721519:	4c 39 cf             	cmp    %r9,%rdi
  72151c:	74 2a                	je     721548 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x258>
  72151e:	66 90                	xchg   %ax,%ax
  721520:	4d 89 c2             	mov    %r8,%r10
  721523:	49 89 f8             	mov    %rdi,%r8
  721526:	8b 3f                	mov    (%rdi),%edi
  721528:	39 d7                	cmp    %edx,%edi
  72152a:	44 8b 1c b0          	mov    (%rax,%rsi,4),%r11d
  72152e:	45 89 1a             	mov    %r11d,(%r10)
  721531:	89 3c b0             	mov    %edi,(%rax,%rsi,4)
  721534:	48 83 d6 00          	adc    $0x0,%rsi
  721538:	49 8d 78 04          	lea    0x4(%r8),%rdi
  72153c:	4c 39 cf             	cmp    %r9,%rdi
  72153f:	75 df                	jne    721520 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x230>
  721541:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  721545:	49 89 f8             	mov    %rdi,%r8
  721548:	39 d1                	cmp    %edx,%ecx
  72154a:	8b 14 b0             	mov    (%rax,%rsi,4),%edx
  72154d:	41 89 10             	mov    %edx,(%r8)
  721550:	89 0c b0             	mov    %ecx,(%rax,%rsi,4)
  721553:	48 83 d6 00          	adc    $0x0,%rsi
  721557:	4c 39 f6             	cmp    %r14,%rsi
  72155a:	0f 83 aa 00 00 00    	jae    72160a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x31a>
  721560:	4d 8d 2c b7          	lea    (%r15,%rsi,4),%r13
  721564:	41 8b 07             	mov    (%r15),%eax
  721567:	41 8b 0c b7          	mov    (%r15,%rsi,4),%ecx
  72156b:	41 89 0f             	mov    %ecx,(%r15)
  72156e:	41 89 04 b7          	mov    %eax,(%r15,%rsi,4)
  721572:	49 8d 1c b7          	lea    (%r15,%rsi,4),%rbx
  721576:	48 83 c3 04          	add    $0x4,%rbx
  72157a:	48 89 f0             	mov    %rsi,%rax
  72157d:	48 f7 d0             	not    %rax
  721580:	49 01 c6             	add    %rax,%r14
  721583:	4c 89 ff             	mov    %r15,%rdi
  721586:	4c 89 e2             	mov    %r12,%rdx
  721589:	89 e9                	mov    %ebp,%ecx
  72158b:	4c 8b 04 24          	mov    (%rsp),%r8
  72158f:	e8 5c fd ff ff       	call   7212f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_>
  721594:	4d 89 ec             	mov    %r13,%r12
  721597:	49 89 df             	mov    %rbx,%r15
  72159a:	49 83 fe 21          	cmp    $0x21,%r14
  72159e:	0f 83 ca fd ff ff    	jae    72136e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x7e>
  7215a4:	e9 62 fd ff ff       	jmp    72130b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x1b>
  7215a9:	49 89 c8             	mov    %rcx,%r8
  7215ac:	31 c0                	xor    %eax,%eax
  7215ae:	4f 8d 0c b7          	lea    (%r15,%r14,4),%r9
  7215b2:	4c 39 cf             	cmp    %r9,%rdi
  7215b5:	0f 84 75 fd ff ff    	je     721330 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  7215bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  7215c0:	4d 89 c2             	mov    %r8,%r10
  7215c3:	49 89 f8             	mov    %rdi,%r8
  7215c6:	8b 3f                	mov    (%rdi),%edi
  7215c8:	39 fe                	cmp    %edi,%esi
  7215ca:	44 8b 1c 81          	mov    (%rcx,%rax,4),%r11d
  7215ce:	45 89 1a             	mov    %r11d,(%r10)
  7215d1:	89 3c 81             	mov    %edi,(%rcx,%rax,4)
  7215d4:	48 83 d8 ff          	sbb    $0xffffffffffffffff,%rax
  7215d8:	49 8d 78 04          	lea    0x4(%r8),%rdi
  7215dc:	4c 39 cf             	cmp    %r9,%rdi
  7215df:	75 df                	jne    7215c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x2d0>
  7215e1:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  7215e5:	49 89 f8             	mov    %rdi,%r8
  7215e8:	e9 43 fd ff ff       	jmp    721330 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable9quicksort9quicksortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB17_20sort_unstable_by_keymNCNvMst_B1b_INtB1b_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB34_+0x40>
  7215ed:	4c 89 ff             	mov    %r15,%rdi
  7215f0:	4c 89 f6             	mov    %r14,%rsi
  7215f3:	48 8b 14 24          	mov    (%rsp),%rdx
  7215f7:	48 83 c4 08          	add    $0x8,%rsp
  7215fb:	5b                   	pop    %rbx
  7215fc:	41 5c                	pop    %r12
  7215fe:	41 5d                	pop    %r13
  721600:	41 5e                	pop    %r14
  721602:	41 5f                	pop    %r15
  721604:	5d                   	pop    %rbp
  721605:	e9 16 c5 00 00       	jmp    72db20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB15_20sort_unstable_by_keymNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB32_>
  72160a:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
