
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072e0e0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_>:
  72e0e0:	55                   	push   %rbp
  72e0e1:	41 57                	push   %r15
  72e0e3:	41 56                	push   %r14
  72e0e5:	41 55                	push   %r13
  72e0e7:	41 54                	push   %r12
  72e0e9:	53                   	push   %rbx
  72e0ea:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  72e0f1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  72e0f8:	00 
  72e0f9:	50                   	push   %rax
  72e0fa:	49 89 d6             	mov    %rdx,%r14
  72e0fd:	48 89 f1             	mov    %rsi,%rcx
  72e100:	48 d1 e9             	shr    $1,%rcx
  72e103:	48 89 f0             	mov    %rsi,%rax
  72e106:	48 29 c8             	sub    %rcx,%rax
  72e109:	48 81 fe 20 a1 07 00 	cmp    $0x7a120,%rsi
  72e110:	bb 20 a1 07 00       	mov    $0x7a120,%ebx
  72e115:	48 0f 42 de          	cmovb  %rsi,%rbx
  72e119:	48 39 c3             	cmp    %rax,%rbx
  72e11c:	48 0f 46 d8          	cmovbe %rax,%rbx
  72e120:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  72e127:	73 0c                	jae    72e135 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x55>
  72e129:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
  72e12e:	b9 00 01 00 00       	mov    $0x100,%ecx
  72e133:	eb 62                	jmp    72e197 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0xb7>
  72e135:	49 89 dc             	mov    %rbx,%r12
  72e138:	49 c1 e4 04          	shl    $0x4,%r12
  72e13c:	48 c1 e8 3c          	shr    $0x3c,%rax
  72e140:	0f 95 c0             	setne  %al
  72e143:	48 b9 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rcx
  72e14a:	ff ff 7f 
  72e14d:	49 39 cc             	cmp    %rcx,%r12
  72e150:	0f 97 c1             	seta   %cl
  72e153:	08 c1                	or     %al,%cl
  72e155:	74 0f                	je     72e166 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x86>
  72e157:	45 31 ed             	xor    %r13d,%r13d
  72e15a:	4c 89 ef             	mov    %r13,%rdi
  72e15d:	4c 89 e6             	mov    %r12,%rsi
  72e160:	ff 15 5a 9d 3b 00    	call   *0x3b9d5a(%rip)        # ae7ec0 <_DYNAMIC+0x328>
  72e166:	49 89 f7             	mov    %rsi,%r15
  72e169:	48 89 fd             	mov    %rdi,%rbp
  72e16c:	ff 15 86 9c 3b 00    	call   *0x3b9c86(%rip)        # ae7df8 <_DYNAMIC+0x260>
  72e172:	41 bd 08 00 00 00    	mov    $0x8,%r13d
  72e178:	be 08 00 00 00       	mov    $0x8,%esi
  72e17d:	4c 89 e7             	mov    %r12,%rdi
  72e180:	ff 15 52 9c 3b 00    	call   *0x3b9c52(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  72e186:	48 89 ef             	mov    %rbp,%rdi
  72e189:	4c 89 fe             	mov    %r15,%rsi
  72e18c:	49 89 c7             	mov    %rax,%r15
  72e18f:	48 89 d9             	mov    %rbx,%rcx
  72e192:	48 85 c0             	test   %rax,%rax
  72e195:	74 c3                	je     72e15a <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x7a>
  72e197:	45 31 c0             	xor    %r8d,%r8d
  72e19a:	48 83 fe 41          	cmp    $0x41,%rsi
  72e19e:	41 0f 92 c0          	setb   %r8b
  72e1a2:	4c 89 fa             	mov    %r15,%rdx
  72e1a5:	4d 89 f1             	mov    %r14,%r9
  72e1a8:	e8 93 ee ff ff       	call   72d040 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>
  72e1ad:	48 81 fb 00 01 00 00 	cmp    $0x100,%rbx
  72e1b4:	76 15                	jbe    72e1cb <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0xeb>
  72e1b6:	48 c1 e3 04          	shl    $0x4,%rbx
  72e1ba:	ba 08 00 00 00       	mov    $0x8,%edx
  72e1bf:	4c 89 ff             	mov    %r15,%rdi
  72e1c2:	48 89 de             	mov    %rbx,%rsi
  72e1c5:	ff 15 15 9c 3b 00    	call   *0x3b9c15(%rip)        # ae7de0 <_DYNAMIC+0x248>
  72e1cb:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  72e1d2:	5b                   	pop    %rbx
  72e1d3:	41 5c                	pop    %r12
  72e1d5:	41 5d                	pop    %r13
  72e1d7:	41 5e                	pop    %r14
  72e1d9:	41 5f                	pop    %r15
  72e1db:	5d                   	pop    %rbp
  72e1dc:	c3                   	ret
  72e1dd:	49 89 c6             	mov    %rax,%r14
  72e1e0:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  72e1e7:	73 08                	jae    72e1f1 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_+0x111>
  72e1e9:	4c 89 f7             	mov    %r14,%rdi
  72e1ec:	e8 5f a3 38 00       	call   ab8550 <_Unwind_Resume@plt>
  72e1f1:	48 c1 e3 04          	shl    $0x4,%rbx
  72e1f5:	ba 08 00 00 00       	mov    $0x8,%edx
  72e1fa:	4c 89 ff             	mov    %r15,%rdi
  72e1fd:	48 89 de             	mov    %rbx,%rsi
  72e200:	ff 15 da 9b 3b 00    	call   *0x3b9bda(%rip)        # ae7de0 <_DYNAMIC+0x248>
  72e206:	4c 89 f7             	mov    %r14,%rdi
  72e209:	e8 42 a3 38 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
