
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072fcc0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_>:
  72fcc0:	55                   	push   %rbp
  72fcc1:	41 57                	push   %r15
  72fcc3:	41 56                	push   %r14
  72fcc5:	41 55                	push   %r13
  72fcc7:	41 54                	push   %r12
  72fcc9:	53                   	push   %rbx
  72fcca:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
  72fcd1:	48 89 fb             	mov    %rdi,%rbx
  72fcd4:	48 89 34 24          	mov    %rsi,(%rsp)
  72fcd8:	48 89 e0             	mov    %rsp,%rax
  72fcdb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  72fce0:	48 8b 07             	mov    (%rdi),%rax
  72fce3:	48 85 c0             	test   %rax,%rax
  72fce6:	74 38                	je     72fd20 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x60>
  72fce8:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  72fcec:	48 85 c9             	test   %rcx,%rcx
  72fcef:	0f 84 89 00 00 00    	je     72fd7e <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0xbe>
  72fcf5:	48 89 ca             	mov    %rcx,%rdx
  72fcf8:	48 83 e2 07          	and    $0x7,%rdx
  72fcfc:	74 28                	je     72fd26 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x66>
  72fcfe:	31 f6                	xor    %esi,%esi
  72fd00:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd07:	48 ff c6             	inc    %rsi
  72fd0a:	48 39 f2             	cmp    %rsi,%rdx
  72fd0d:	75 f1                	jne    72fd00 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x40>
  72fd0f:	48 89 ca             	mov    %rcx,%rdx
  72fd12:	48 29 f2             	sub    %rsi,%rdx
  72fd15:	48 89 de             	mov    %rbx,%rsi
  72fd18:	48 83 f9 08          	cmp    $0x8,%rcx
  72fd1c:	73 22                	jae    72fd40 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x80>
  72fd1e:	eb 61                	jmp    72fd81 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0xc1>
  72fd20:	31 c0                	xor    %eax,%eax
  72fd22:	31 f6                	xor    %esi,%esi
  72fd24:	eb 5b                	jmp    72fd81 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0xc1>
  72fd26:	48 89 ca             	mov    %rcx,%rdx
  72fd29:	48 89 de             	mov    %rbx,%rsi
  72fd2c:	48 83 f9 08          	cmp    $0x8,%rcx
  72fd30:	72 4f                	jb     72fd81 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0xc1>
  72fd32:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72fd39:	1f 84 00 00 00 00 00 
  72fd40:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd47:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd4e:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd55:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd5c:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd63:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd6a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd71:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  72fd78:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  72fd7c:	75 c2                	jne    72fd40 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x80>
  72fd7e:	48 89 de             	mov    %rbx,%rsi
  72fd81:	4c 8d 6b 10          	lea    0x10(%rbx),%r13
  72fd85:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
  72fd8a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  72fd8f:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
  72fd94:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
  72fd99:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  72fd9e:	0f 57 c0             	xorps  %xmm0,%xmm0
  72fda1:	0f 11 44 24 30       	movups %xmm0,0x30(%rsp)
  72fda6:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  72fdab:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  72fdb0:	e8 2b 90 fe ff       	call   718de0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>
  72fdb5:	83 7c 24 40 01       	cmpl   $0x1,0x40(%rsp)
  72fdba:	75 4f                	jne    72fe0b <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x14b>
  72fdbc:	48 8d 6c 24 48       	lea    0x48(%rsp),%rbp
  72fdc1:	4c 8d 74 24 78       	lea    0x78(%rsp),%r14
  72fdc6:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
  72fdcb:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
  72fdd0:	48 8b 45 20          	mov    0x20(%rbp),%rax
  72fdd4:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  72fddb:	00 
  72fddc:	0f 10 45 00          	movups 0x0(%rbp),%xmm0
  72fde0:	0f 10 4d 10          	movups 0x10(%rbp),%xmm1
  72fde4:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
  72fdeb:	00 
  72fdec:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  72fdf1:	4c 89 f7             	mov    %r14,%rdi
  72fdf4:	e8 57 7d fe ff       	call   717b50 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  72fdf9:	4c 89 ff             	mov    %r15,%rdi
  72fdfc:	4c 89 e6             	mov    %r12,%rsi
  72fdff:	e8 dc 8f fe ff       	call   718de0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>
  72fe04:	80 7c 24 40 00       	cmpb   $0x0,0x40(%rsp)
  72fe09:	75 c5                	jne    72fdd0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x110>
  72fe0b:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
  72fe10:	75 17                	jne    72fe29 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyINtB6_9OverridesNtB6_13GeometryStyleE6retainNCNvMst_NtB8_7runtimeINtB1q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0EB1U_+0x169>
  72fe12:	48 89 df             	mov    %rbx,%rdi
  72fe15:	e8 36 8c fe ff       	call   718a50 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB17_13GeometryStyleEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  72fe1a:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  72fe21:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  72fe28:	00 
  72fe29:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
  72fe30:	5b                   	pop    %rbx
  72fe31:	41 5c                	pop    %r12
  72fe33:	41 5d                	pop    %r13
  72fe35:	41 5e                	pop    %r14
  72fe37:	41 5f                	pop    %r15
  72fe39:	5d                   	pop    %rbp
  72fe3a:	c3                   	ret
  72fe3b:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  72fe42:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  72fe49:	00 
  72fe4a:	48 89 c7             	mov    %rax,%rdi
  72fe4d:	e8 fe 86 38 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
