
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000713e10 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_>:
  713e10:	55                   	push   %rbp
  713e11:	41 57                	push   %r15
  713e13:	41 56                	push   %r14
  713e15:	41 55                	push   %r13
  713e17:	41 54                	push   %r12
  713e19:	53                   	push   %rbx
  713e1a:	48 83 ec 28          	sub    $0x28,%rsp
  713e1e:	49 89 f6             	mov    %rsi,%r14
  713e21:	48 89 fb             	mov    %rdi,%rbx
  713e24:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  713e2b:	00 00 00 00 00 
  713e30:	4c 89 f7             	mov    %r14,%rdi
  713e33:	e8 d8 53 00 00       	call   719210 <_RNvXsk_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_4IterNtNtNtCshBhuxcId5D0_4gpui7runtime6scroll11ViewportKeyNtB14_13ViewportStateENtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator4nextCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  713e38:	48 85 c0             	test   %rax,%rax
  713e3b:	0f 84 f1 02 00 00    	je     714132 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x322>
  713e41:	80 38 00             	cmpb   $0x0,(%rax)
  713e44:	75 ea                	jne    713e30 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x20>
  713e46:	48 83 3a 02          	cmpq   $0x2,(%rdx)
  713e4a:	74 e4                	je     713e30 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x20>
  713e4c:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  713e51:	4c 8b 7a 18          	mov    0x18(%rdx),%r15
  713e55:	4c 8b 60 08          	mov    0x8(%rax),%r12
  713e59:	ff 15 99 3f 3d 00    	call   *0x3d3f99(%rip)        # ae7df8 <_DYNAMIC+0x260>
  713e5f:	bf 40 00 00 00       	mov    $0x40,%edi
  713e64:	be 08 00 00 00       	mov    $0x8,%esi
  713e69:	ff 15 69 3f 3d 00    	call   *0x3d3f69(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  713e6f:	48 85 c0             	test   %rax,%rax
  713e72:	0f 84 18 03 00 00    	je     714190 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x380>
  713e78:	4c 89 38             	mov    %r15,(%rax)
  713e7b:	4c 89 60 08          	mov    %r12,0x8(%rax)
  713e7f:	48 c7 04 24 04 00 00 	movq   $0x4,(%rsp)
  713e86:	00 
  713e87:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  713e8c:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
  713e93:	00 00 
  713e95:	45 0f b6 1e          	movzbl (%r14),%r11d
  713e99:	4d 8b 6e 08          	mov    0x8(%r14),%r13
  713e9d:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  713ea1:	49 8b 6e 18          	mov    0x18(%r14),%rbp
  713ea5:	4d 8b 66 40          	mov    0x40(%r14),%r12
  713ea9:	be 01 00 00 00       	mov    $0x1,%esi
  713eae:	48 89 e7             	mov    %rsp,%rdi
  713eb1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  713eb8:	0f 1f 84 00 00 00 00 
  713ebf:	00 
  713ec0:	4d 85 e4             	test   %r12,%r12
  713ec3:	0f 84 82 02 00 00    	je     71414b <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x33b>
  713ec9:	41 f6 c3 01          	test   $0x1,%r11b
  713ecd:	0f 84 ae 02 00 00    	je     714181 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x371>
  713ed3:	4d 85 ed             	test   %r13,%r13
  713ed6:	74 28                	je     713f00 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xf0>
  713ed8:	41 0f b7 95 8a 05 00 	movzwl 0x58a(%r13),%edx
  713edf:	00 
  713ee0:	48 39 d5             	cmp    %rdx,%rbp
  713ee3:	0f 83 c7 00 00 00    	jae    713fb0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1a0>
  713ee9:	4c 89 ea             	mov    %r13,%rdx
  713eec:	49 89 ea             	mov    %rbp,%r10
  713eef:	e9 e4 00 00 00       	jmp    713fd8 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1c8>
  713ef4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  713efb:	00 00 00 00 00 
  713f00:	48 85 ed             	test   %rbp,%rbp
  713f03:	74 38                	je     713f3d <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x12d>
  713f05:	48 89 ea             	mov    %rbp,%rdx
  713f08:	49 89 cd             	mov    %rcx,%r13
  713f0b:	48 83 e2 07          	and    $0x7,%rdx
  713f0f:	74 31                	je     713f42 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x132>
  713f11:	45 31 c0             	xor    %r8d,%r8d
  713f14:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  713f1b:	00 00 00 00 00 
  713f20:	4d 8b ad 90 05 00 00 	mov    0x590(%r13),%r13
  713f27:	49 ff c0             	inc    %r8
  713f2a:	4c 39 c2             	cmp    %r8,%rdx
  713f2d:	75 f1                	jne    713f20 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x110>
  713f2f:	48 89 e9             	mov    %rbp,%rcx
  713f32:	4c 29 c1             	sub    %r8,%rcx
  713f35:	48 83 fd 08          	cmp    $0x8,%rbp
  713f39:	73 15                	jae    713f50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x140>
  713f3b:	eb 51                	jmp    713f8e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  713f3d:	49 89 cd             	mov    %rcx,%r13
  713f40:	eb 4c                	jmp    713f8e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  713f42:	48 89 e9             	mov    %rbp,%rcx
  713f45:	48 83 fd 08          	cmp    $0x8,%rbp
  713f49:	72 43                	jb     713f8e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x17e>
  713f4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  713f50:	49 8b 95 90 05 00 00 	mov    0x590(%r13),%rdx
  713f57:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f5e:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f65:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f6c:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f73:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f7a:	48 8b 92 90 05 00 00 	mov    0x590(%rdx),%rdx
  713f81:	4c 8b aa 90 05 00 00 	mov    0x590(%rdx),%r13
  713f88:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  713f8c:	75 c2                	jne    713f50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x140>
  713f8e:	31 c9                	xor    %ecx,%ecx
  713f90:	31 ed                	xor    %ebp,%ebp
  713f92:	41 0f b7 95 8a 05 00 	movzwl 0x58a(%r13),%edx
  713f99:	00 
  713f9a:	48 39 d5             	cmp    %rdx,%rbp
  713f9d:	0f 82 46 ff ff ff    	jb     713ee9 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xd9>
  713fa3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  713faa:	84 00 00 00 00 00 
  713fb0:	49 8b 95 80 05 00 00 	mov    0x580(%r13),%rdx
  713fb7:	48 85 d2             	test   %rdx,%rdx
  713fba:	0f 84 b2 01 00 00    	je     714172 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x362>
  713fc0:	48 ff c1             	inc    %rcx
  713fc3:	45 0f b7 95 88 05 00 	movzwl 0x588(%r13),%r10d
  713fca:	00 
  713fcb:	49 89 d5             	mov    %rdx,%r13
  713fce:	66 44 3b 92 8a 05 00 	cmp    0x58a(%rdx),%r10w
  713fd5:	00 
  713fd6:	73 d8                	jae    713fb0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1a0>
  713fd8:	48 85 c9             	test   %rcx,%rcx
  713fdb:	0f 84 8f 00 00 00    	je     714070 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x260>
  713fe1:	4e 8d 1c d2          	lea    (%rdx,%r10,8),%r11
  713fe5:	49 81 c3 98 05 00 00 	add    $0x598,%r11
  713fec:	49 89 c8             	mov    %rcx,%r8
  713fef:	49 83 e0 07          	and    $0x7,%r8
  713ff3:	0f 84 27 01 00 00    	je     714120 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x310>
  713ff9:	45 31 c9             	xor    %r9d,%r9d
  713ffc:	0f 1f 40 00          	nopl   0x0(%rax)
  714000:	4d 8b 2b             	mov    (%r11),%r13
  714003:	4d 8d 9d 90 05 00 00 	lea    0x590(%r13),%r11
  71400a:	49 ff c1             	inc    %r9
  71400d:	4d 39 c8             	cmp    %r9,%r8
  714010:	75 ee                	jne    714000 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x1f0>
  714012:	49 89 c8             	mov    %rcx,%r8
  714015:	4d 29 c8             	sub    %r9,%r8
  714018:	48 83 f9 08          	cmp    $0x8,%rcx
  71401c:	72 43                	jb     714061 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x251>
  71401e:	66 90                	xchg   %ax,%ax
  714020:	49 8b 0b             	mov    (%r11),%rcx
  714023:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71402a:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  714031:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  714038:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71403f:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  714046:	48 8b 89 90 05 00 00 	mov    0x590(%rcx),%rcx
  71404d:	4c 8b a9 90 05 00 00 	mov    0x590(%rcx),%r13
  714054:	4d 8d 9d 90 05 00 00 	lea    0x590(%r13),%r11
  71405b:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  71405f:	75 bf                	jne    714020 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x210>
  714061:	31 ed                	xor    %ebp,%ebp
  714063:	eb 12                	jmp    714077 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x267>
  714065:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  71406c:	00 00 00 00 
  714070:	49 8d 6a 01          	lea    0x1(%r10),%rbp
  714074:	49 89 d5             	mov    %rdx,%r13
  714077:	49 ff cc             	dec    %r12
  71407a:	4d 89 d0             	mov    %r10,%r8
  71407d:	49 c1 e0 04          	shl    $0x4,%r8
  714081:	41 b3 01             	mov    $0x1,%r11b
  714084:	42 80 3c 02 00       	cmpb   $0x0,(%rdx,%r8,1)
  714089:	b9 00 00 00 00       	mov    $0x0,%ecx
  71408e:	0f 85 2c fe ff ff    	jne    713ec0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  714094:	4d 6b ca 70          	imul   $0x70,%r10,%r9
  714098:	4a 83 bc 0a b0 00 00 	cmpq   $0x2,0xb0(%rdx,%r9,1)
  71409f:	00 02 
  7140a1:	b9 00 00 00 00       	mov    $0x0,%ecx
  7140a6:	0f 84 14 fe ff ff    	je     713ec0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  7140ac:	4a 8d 0c 0a          	lea    (%rdx,%r9,1),%rcx
  7140b0:	48 81 c1 b0 00 00 00 	add    $0xb0,%rcx
  7140b7:	49 01 d0             	add    %rdx,%r8
  7140ba:	4c 8b 79 18          	mov    0x18(%rcx),%r15
  7140be:	49 8b 48 08          	mov    0x8(%r8),%rcx
  7140c2:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  7140c7:	48 3b 34 24          	cmp    (%rsp),%rsi
  7140cb:	75 26                	jne    7140f3 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x2e3>
  7140cd:	ba 01 00 00 00       	mov    $0x1,%edx
  7140d2:	b9 08 00 00 00       	mov    $0x8,%ecx
  7140d7:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  7140dd:	49 89 fe             	mov    %rdi,%r14
  7140e0:	48 89 f3             	mov    %rsi,%rbx
  7140e3:	e8 b8 20 01 00       	call   7261a0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  7140e8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  7140ed:	48 89 de             	mov    %rbx,%rsi
  7140f0:	4c 89 f7             	mov    %r14,%rdi
  7140f3:	48 89 f1             	mov    %rsi,%rcx
  7140f6:	48 c1 e1 04          	shl    $0x4,%rcx
  7140fa:	4c 89 3c 08          	mov    %r15,(%rax,%rcx,1)
  7140fe:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  714103:	48 89 54 08 08       	mov    %rdx,0x8(%rax,%rcx,1)
  714108:	48 ff c6             	inc    %rsi
  71410b:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  714110:	41 b3 01             	mov    $0x1,%r11b
  714113:	31 c9                	xor    %ecx,%ecx
  714115:	e9 a6 fd ff ff       	jmp    713ec0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0xb0>
  71411a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  714120:	49 89 c8             	mov    %rcx,%r8
  714123:	48 83 f9 08          	cmp    $0x8,%rcx
  714127:	0f 82 34 ff ff ff    	jb     714061 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x251>
  71412d:	e9 ee fe ff ff       	jmp    714020 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x210>
  714132:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  714139:	48 c7 43 08 08 00 00 	movq   $0x8,0x8(%rbx)
  714140:	00 
  714141:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  714148:	00 
  714149:	eb 15                	jmp    714160 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x350>
  71414b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  714150:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
  714155:	48 89 43 10          	mov    %rax,0x10(%rbx)
  714159:	0f 10 04 24          	movups (%rsp),%xmm0
  71415d:	0f 11 03             	movups %xmm0,(%rbx)
  714160:	48 89 d8             	mov    %rbx,%rax
  714163:	48 83 c4 28          	add    $0x28,%rsp
  714167:	5b                   	pop    %rbx
  714168:	41 5c                	pop    %r12
  71416a:	41 5d                	pop    %r13
  71416c:	41 5e                	pop    %r14
  71416e:	41 5f                	pop    %r15
  714170:	5d                   	pop    %rbp
  714171:	c3                   	ret
  714172:	48 8d 3d c7 65 3a 00 	lea    0x3a65c7(%rip),%rdi        # aba740 <anon.5876dccaaaaea8cd2b0f61f3651112ee.3.llvm.17218317146265502647>
  714179:	ff 15 a1 3c 3d 00    	call   *0x3d3ca1(%rip)        # ae7e20 <_DYNAMIC+0x288>
  71417f:	eb 0d                	jmp    71418e <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x37e>
  714181:	48 8d 3d d0 65 3a 00 	lea    0x3a65d0(%rip),%rdi        # aba758 <anon.5876dccaaaaea8cd2b0f61f3651112ee.4.llvm.17218317146265502647>
  714188:	ff 15 92 3c 3d 00    	call   *0x3d3c92(%rip)        # ae7e20 <_DYNAMIC+0x288>
  71418e:	0f 0b                	ud2
  714190:	bf 08 00 00 00       	mov    $0x8,%edi
  714195:	be 40 00 00 00       	mov    $0x40,%esi
  71419a:	ff 15 20 3d 3d 00    	call   *0x3d3d20(%rip)        # ae7ec0 <_DYNAMIC+0x328>
  7141a0:	eb 00                	jmp    7141a2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x392>
  7141a2:	48 89 c3             	mov    %rax,%rbx
  7141a5:	48 8b 34 24          	mov    (%rsp),%rsi
  7141a9:	48 85 f6             	test   %rsi,%rsi
  7141ac:	74 14                	je     7141c2 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_+0x3b2>
  7141ae:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  7141b3:	48 c1 e6 04          	shl    $0x4,%rsi
  7141b7:	ba 08 00 00 00       	mov    $0x8,%edx
  7141bc:	ff 15 1e 3c 3d 00    	call   *0x3d3c1e(%rip)        # ae7de0 <_DYNAMIC+0x248>
  7141c2:	48 89 df             	mov    %rbx,%rdi
  7141c5:	e8 86 43 3a 00       	call   ab8550 <_Unwind_Resume@plt>
  7141ca:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
