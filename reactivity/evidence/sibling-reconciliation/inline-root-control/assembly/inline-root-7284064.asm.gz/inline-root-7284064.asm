
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006f2560 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_>:
  6f2560:	55                   	push   %rbp
  6f2561:	41 57                	push   %r15
  6f2563:	41 56                	push   %r14
  6f2565:	41 55                	push   %r13
  6f2567:	41 54                	push   %r12
  6f2569:	53                   	push   %rbx
  6f256a:	48 81 ec e8 01 00 00 	sub    $0x1e8,%rsp
  6f2571:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
  6f2578:	00 
  6f2579:	49 89 f4             	mov    %rsi,%r12
  6f257c:	48 89 bc 24 e0 00 00 	mov    %rdi,0xe0(%rsp)
  6f2583:	00 
  6f2584:	48 8b 2e             	mov    (%rsi),%rbp
  6f2587:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f258b:	0f b7 9d 32 05 00 00 	movzwl 0x532(%rbp),%ebx
  6f2592:	4a 8d bc ed d8 04 00 	lea    0x4d8(%rbp,%r13,8),%rdi
  6f2599:	00 
  6f259a:	4a 8b 84 ed d8 04 00 	mov    0x4d8(%rbp,%r13,8),%rax
  6f25a1:	00 
  6f25a2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6f25a7:	4a 8d 34 ed e0 04 00 	lea    0x4e0(,%r13,8),%rsi
  6f25ae:	00 
  6f25af:	48 01 ee             	add    %rbp,%rsi
  6f25b2:	4d 89 ef             	mov    %r13,%r15
  6f25b5:	49 f7 d7             	not    %r15
  6f25b8:	49 01 df             	add    %rbx,%r15
  6f25bb:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f25c2:	00 
  6f25c3:	4c 8b 35 36 58 3f 00 	mov    0x3f5836(%rip),%r14        # ae7e00 <memmove@GLIBC_2.2.5>
  6f25ca:	41 ff d6             	call   *%r14
  6f25cd:	4c 89 2c 24          	mov    %r13,(%rsp)
  6f25d1:	49 6b c5 70          	imul   $0x70,%r13,%rax
  6f25d5:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f25d9:	0f 10 44 05 60       	movups 0x60(%rbp,%rax,1),%xmm0
  6f25de:	0f 11 84 24 68 01 00 	movups %xmm0,0x168(%rsp)
  6f25e5:	00 
  6f25e6:	0f 10 44 05 50       	movups 0x50(%rbp,%rax,1),%xmm0
  6f25eb:	0f 11 84 24 58 01 00 	movups %xmm0,0x158(%rsp)
  6f25f2:	00 
  6f25f3:	0f 10 44 05 40       	movups 0x40(%rbp,%rax,1),%xmm0
  6f25f8:	0f 11 84 24 48 01 00 	movups %xmm0,0x148(%rsp)
  6f25ff:	00 
  6f2600:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f2605:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f260a:	0f 10 54 05 20       	movups 0x20(%rbp,%rax,1),%xmm2
  6f260f:	0f 10 5c 05 30       	movups 0x30(%rbp,%rax,1),%xmm3
  6f2614:	0f 11 9c 24 38 01 00 	movups %xmm3,0x138(%rsp)
  6f261b:	00 
  6f261c:	0f 11 94 24 28 01 00 	movups %xmm2,0x128(%rsp)
  6f2623:	00 
  6f2624:	0f 11 8c 24 18 01 00 	movups %xmm1,0x118(%rsp)
  6f262b:	00 
  6f262c:	0f 11 84 24 08 01 00 	movups %xmm0,0x108(%rsp)
  6f2633:	00 
  6f2634:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f2638:	48 83 c6 70          	add    $0x70,%rsi
  6f263c:	49 6b d7 70          	imul   $0x70,%r15,%rdx
  6f2640:	41 ff d6             	call   *%r14
  6f2643:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f2646:	66 89 85 32 05 00 00 	mov    %ax,0x532(%rbp)
  6f264d:	4d 8b 7c 24 08       	mov    0x8(%r12),%r15
  6f2652:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f2657:	48 89 8c 24 00 01 00 	mov    %rcx,0x100(%rsp)
  6f265e:	00 
  6f265f:	66 83 f8 04          	cmp    $0x4,%ax
  6f2663:	0f 87 65 01 00 00    	ja     6f27ce <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2669:	48 8b 85 d0 04 00 00 	mov    0x4d0(%rbp),%rax
  6f2670:	48 85 c0             	test   %rax,%rax
  6f2673:	0f 84 11 01 00 00    	je     6f278a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x22a>
  6f2679:	49 8d 4f 01          	lea    0x1(%r15),%rcx
  6f267d:	0f b7 95 30 05 00 00 	movzwl 0x530(%rbp),%edx
  6f2684:	48 85 d2             	test   %rdx,%rdx
  6f2687:	74 66                	je     6f26ef <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x18f>
  6f2689:	48 8b b4 d0 30 05 00 	mov    0x530(%rax,%rdx,8),%rsi
  6f2690:	00 
  6f2691:	48 ff ca             	dec    %rdx
  6f2694:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f2699:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6f269e:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6f26a3:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6f26a8:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f26af:	00 
  6f26b0:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  6f26b7:	00 
  6f26b8:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f26bf:	00 
  6f26c0:	0f b7 86 32 05 00 00 	movzwl 0x532(%rsi),%eax
  6f26c7:	01 c3                	add    %eax,%ebx
  6f26c9:	83 fb 0c             	cmp    $0xc,%ebx
  6f26cc:	0f 83 87 00 00 00    	jae    6f2759 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x1f9>
  6f26d2:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f26d7:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6f26dc:	ba 01 00 00 00       	mov    $0x1,%edx
  6f26e1:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f26e5:	e8 f6 9d ff ff       	call   6ec4e0 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1o_5style5StyleEE25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f26ea:	e9 ae 00 00 00       	jmp    6f279d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x23d>
  6f26ef:	66 83 b8 32 05 00 00 	cmpw   $0x0,0x532(%rax)
  6f26f6:	00 
  6f26f7:	0f 84 92 07 00 00    	je     6f2e8f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x92f>
  6f26fd:	48 8b 90 40 05 00 00 	mov    0x540(%rax),%rdx
  6f2704:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f2709:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6f270e:	48 c7 44 24 70 00 00 	movq   $0x0,0x70(%rsp)
  6f2715:	00 00 
  6f2717:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f271c:	4c 89 bc 24 80 00 00 	mov    %r15,0x80(%rsp)
  6f2723:	00 
  6f2724:	48 89 94 24 88 00 00 	mov    %rdx,0x88(%rsp)
  6f272b:	00 
  6f272c:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
  6f2733:	00 
  6f2734:	0f b7 82 32 05 00 00 	movzwl 0x532(%rdx),%eax
  6f273b:	01 c3                	add    %eax,%ebx
  6f273d:	83 fb 0c             	cmp    $0xc,%ebx
  6f2740:	73 39                	jae    6f277b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x21b>
  6f2742:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6f2747:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6f274c:	31 d2                	xor    %edx,%edx
  6f274e:	48 8b 0c 24          	mov    (%rsp),%rcx
  6f2752:	e8 89 9d ff ff       	call   6ec4e0 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1o_5style5StyleEE25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2757:	eb 44                	jmp    6f279d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x23d>
  6f2759:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6f275e:	be 01 00 00 00       	mov    $0x1,%esi
  6f2763:	e8 78 13 00 00       	call   6f3ae0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2768:	48 8b 04 24          	mov    (%rsp),%rax
  6f276c:	48 ff c0             	inc    %rax
  6f276f:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  6f2774:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  6f2779:	eb 1d                	jmp    6f2798 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x238>
  6f277b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6f2780:	be 01 00 00 00       	mov    $0x1,%esi
  6f2785:	e8 96 17 00 00       	call   6f3f20 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f278a:	48 89 6c 24 20       	mov    %rbp,0x20(%rsp)
  6f278f:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
  6f2794:	48 8b 04 24          	mov    (%rsp),%rax
  6f2798:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6f279d:	48 8b 6c 24 20       	mov    0x20(%rsp),%rbp
  6f27a2:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6f27a7:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6f27ac:	48 89 04 24          	mov    %rax,(%rsp)
  6f27b0:	4c 8b b5 d0 04 00 00 	mov    0x4d0(%rbp),%r14
  6f27b7:	4d 85 f6             	test   %r14,%r14
  6f27ba:	74 12                	je     6f27ce <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f27bc:	41 0f b7 86 32 05 00 	movzwl 0x532(%r14),%eax
  6f27c3:	00 
  6f27c4:	66 83 f8 04          	cmp    $0x4,%ax
  6f27c8:	0f 86 9b 00 00 00    	jbe    6f2869 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x309>
  6f27ce:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
  6f27d5:	00 
  6f27d6:	48 8b 94 24 e0 00 00 	mov    0xe0(%rsp),%rdx
  6f27dd:	00 
  6f27de:	48 89 42 70          	mov    %rax,0x70(%rdx)
  6f27e2:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  6f27e9:	00 
  6f27ea:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  6f27ee:	0f 10 84 24 50 01 00 	movups 0x150(%rsp),%xmm0
  6f27f5:	00 
  6f27f6:	0f 11 42 50          	movups %xmm0,0x50(%rdx)
  6f27fa:	0f 10 84 24 40 01 00 	movups 0x140(%rsp),%xmm0
  6f2801:	00 
  6f2802:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  6f2806:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  6f280d:	00 
  6f280e:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  6f2815:	00 
  6f2816:	0f 10 84 24 10 01 00 	movups 0x110(%rsp),%xmm0
  6f281d:	00 
  6f281e:	0f 10 8c 24 20 01 00 	movups 0x120(%rsp),%xmm1
  6f2825:	00 
  6f2826:	0f 10 94 24 30 01 00 	movups 0x130(%rsp),%xmm2
  6f282d:	00 
  6f282e:	0f 11 52 30          	movups %xmm2,0x30(%rdx)
  6f2832:	0f 11 4a 20          	movups %xmm1,0x20(%rdx)
  6f2836:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f283a:	48 89 02             	mov    %rax,(%rdx)
  6f283d:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f2841:	48 89 6a 78          	mov    %rbp,0x78(%rdx)
  6f2845:	4c 89 ba 80 00 00 00 	mov    %r15,0x80(%rdx)
  6f284c:	48 8b 04 24          	mov    (%rsp),%rax
  6f2850:	48 89 82 88 00 00 00 	mov    %rax,0x88(%rdx)
  6f2857:	48 81 c4 e8 01 00 00 	add    $0x1e8,%rsp
  6f285e:	5b                   	pop    %rbx
  6f285f:	41 5c                	pop    %r12
  6f2861:	41 5d                	pop    %r13
  6f2863:	41 5e                	pop    %r14
  6f2865:	41 5f                	pop    %r15
  6f2867:	5d                   	pop    %rbp
  6f2868:	c3                   	ret
  6f2869:	4d 8d 67 01          	lea    0x1(%r15),%r12
  6f286d:	48 8d 0d 2c 71 3c 00 	lea    0x3c712c(%rip),%rcx        # ab99a0 <__frame_dummy_init_array_entry+0x98>
  6f2874:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f2879:	48 8d 0d 3c 0d 97 ff 	lea    -0x68f2c4(%rip),%rcx        # 635bc <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f2880:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  6f2885:	48 89 ac 24 d8 00 00 	mov    %rbp,0xd8(%rsp)
  6f288c:	00 
  6f288d:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
  6f2892:	eb 2c                	jmp    6f28c0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x360>
  6f2894:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f289b:	00 00 00 00 00 
  6f28a0:	ba 08 00 00 00       	mov    $0x8,%edx
  6f28a5:	4c 89 ef             	mov    %r13,%rdi
  6f28a8:	ff 15 32 55 3f 00    	call   *0x3f5532(%rip)        # ae7de0 <_DYNAMIC+0x248>
  6f28ae:	41 0f b7 86 32 05 00 	movzwl 0x532(%r14),%eax
  6f28b5:	00 
  6f28b6:	66 83 f8 04          	cmp    $0x4,%ax
  6f28ba:	0f 87 0e ff ff ff    	ja     6f27ce <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f28c0:	4c 89 f1             	mov    %r14,%rcx
  6f28c3:	0f b7 c0             	movzwl %ax,%eax
  6f28c6:	4d 8b b6 d0 04 00 00 	mov    0x4d0(%r14),%r14
  6f28cd:	4d 85 f6             	test   %r14,%r14
  6f28d0:	0f 84 06 05 00 00    	je     6f2ddc <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x87c>
  6f28d6:	4c 89 e6             	mov    %r12,%rsi
  6f28d9:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  6f28de:	44 0f b7 a1 30 05 00 	movzwl 0x530(%rcx),%r12d
  6f28e5:	00 
  6f28e6:	4d 85 e4             	test   %r12,%r12
  6f28e9:	48 89 bc 24 f8 00 00 	mov    %rdi,0xf8(%rsp)
  6f28f0:	00 
  6f28f1:	0f 84 89 00 00 00    	je     6f2980 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x420>
  6f28f7:	4b 8b 9c e6 30 05 00 	mov    0x530(%r14,%r12,8),%rbx
  6f28fe:	00 
  6f28ff:	49 ff cc             	dec    %r12
  6f2902:	4c 89 b4 24 78 01 00 	mov    %r14,0x178(%rsp)
  6f2909:	00 
  6f290a:	48 89 bc 24 80 01 00 	mov    %rdi,0x180(%rsp)
  6f2911:	00 
  6f2912:	4c 89 a4 24 88 01 00 	mov    %r12,0x188(%rsp)
  6f2919:	00 
  6f291a:	48 89 9c 24 90 01 00 	mov    %rbx,0x190(%rsp)
  6f2921:	00 
  6f2922:	48 89 b4 24 98 01 00 	mov    %rsi,0x198(%rsp)
  6f2929:	00 
  6f292a:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  6f2931:	00 
  6f2932:	48 89 b4 24 a8 01 00 	mov    %rsi,0x1a8(%rsp)
  6f2939:	00 
  6f293a:	0f b7 b3 32 05 00 00 	movzwl 0x532(%rbx),%esi
  6f2941:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f2944:	ff c2                	inc    %edx
  6f2946:	83 fa 0c             	cmp    $0xc,%edx
  6f2949:	0f 83 f5 04 00 00    	jae    6f2e44 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x8e4>
  6f294f:	41 0f b7 96 32 05 00 	movzwl 0x532(%r14),%edx
  6f2956:	00 
  6f2957:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f295b:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6f2960:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  6f2965:	48 01 c6             	add    %rax,%rsi
  6f2968:	48 ff c6             	inc    %rsi
  6f296b:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  6f2970:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f2975:	e9 91 00 00 00       	jmp    6f2a0b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x4ab>
  6f297a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f2980:	41 0f b7 96 32 05 00 	movzwl 0x532(%r14),%edx
  6f2987:	00 
  6f2988:	66 85 d2             	test   %dx,%dx
  6f298b:	0f 84 fe 04 00 00    	je     6f2e8f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x92f>
  6f2991:	4d 8b 86 40 05 00 00 	mov    0x540(%r14),%r8
  6f2998:	4c 89 b4 24 b0 01 00 	mov    %r14,0x1b0(%rsp)
  6f299f:	00 
  6f29a0:	48 89 bc 24 b8 01 00 	mov    %rdi,0x1b8(%rsp)
  6f29a7:	00 
  6f29a8:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
  6f29af:	00 00 00 00 00 
  6f29b4:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
  6f29bb:	00 
  6f29bc:	48 89 b4 24 d0 01 00 	mov    %rsi,0x1d0(%rsp)
  6f29c3:	00 
  6f29c4:	4c 89 84 24 d8 01 00 	mov    %r8,0x1d8(%rsp)
  6f29cb:	00 
  6f29cc:	48 89 b4 24 e0 01 00 	mov    %rsi,0x1e0(%rsp)
  6f29d3:	00 
  6f29d4:	45 0f b7 88 32 05 00 	movzwl 0x532(%r8),%r9d
  6f29db:	00 
  6f29dc:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f29e0:	48 ff c6             	inc    %rsi
  6f29e3:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f29e7:	0f 83 71 04 00 00    	jae    6f2e5e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x8fe>
  6f29ed:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f29f1:	48 89 7c 24 10       	mov    %rdi,0x10(%rsp)
  6f29f6:	48 89 cb             	mov    %rcx,%rbx
  6f29f9:	45 31 e4             	xor    %r12d,%r12d
  6f29fc:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f2a01:	4c 89 44 24 08       	mov    %r8,0x8(%rsp)
  6f2a06:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  6f2a0b:	0f b7 c2             	movzwl %dx,%eax
  6f2a0e:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  6f2a15:	00 
  6f2a16:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  6f2a1b:	66 89 b3 32 05 00 00 	mov    %si,0x532(%rbx)
  6f2a22:	4b 8d 3c e6          	lea    (%r14,%r12,8),%rdi
  6f2a26:	48 81 c7 d8 04 00 00 	add    $0x4d8,%rdi
  6f2a2d:	4f 8b bc e6 d8 04 00 	mov    0x4d8(%r14,%r12,8),%r15
  6f2a34:	00 
  6f2a35:	4b 8d 34 e6          	lea    (%r14,%r12,8),%rsi
  6f2a39:	48 81 c6 e0 04 00 00 	add    $0x4e0,%rsi
  6f2a40:	4c 89 e5             	mov    %r12,%rbp
  6f2a43:	48 f7 d5             	not    %rbp
  6f2a46:	48 01 c5             	add    %rax,%rbp
  6f2a49:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
  6f2a50:	00 
  6f2a51:	48 89 94 24 e8 00 00 	mov    %rdx,0xe8(%rsp)
  6f2a58:	00 
  6f2a59:	48 8b 05 a0 53 3f 00 	mov    0x3f53a0(%rip),%rax        # ae7e00 <memmove@GLIBC_2.2.5>
  6f2a60:	ff d0                	call   *%rax
  6f2a62:	4c 8b 6c 24 38       	mov    0x38(%rsp),%r13
  6f2a67:	4e 89 bc eb d8 04 00 	mov    %r15,0x4d8(%rbx,%r13,8)
  6f2a6e:	00 
  6f2a6f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f2a74:	48 8d b0 d8 04 00 00 	lea    0x4d8(%rax),%rsi
  6f2a7b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f2a80:	48 8d bc c3 d8 04 00 	lea    0x4d8(%rbx,%rax,8),%rdi
  6f2a87:	00 
  6f2a88:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f2a8d:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f2a94:	4c 8b 3d 6d 53 3f 00 	mov    0x3f536d(%rip),%r15        # ae7e08 <memcpy@GLIBC_2.14>
  6f2a9b:	41 ff d7             	call   *%r15
  6f2a9e:	49 6b c4 70          	imul   $0x70,%r12,%rax
  6f2aa2:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f2aa6:	41 0f 10 44 06 60    	movups 0x60(%r14,%rax,1),%xmm0
  6f2aac:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  6f2ab3:	00 
  6f2ab4:	41 0f 10 44 06 50    	movups 0x50(%r14,%rax,1),%xmm0
  6f2aba:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
  6f2ac1:	00 
  6f2ac2:	41 0f 10 44 06 40    	movups 0x40(%r14,%rax,1),%xmm0
  6f2ac8:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6f2acf:	00 
  6f2ad0:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f2ad5:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f2adb:	41 0f 10 54 06 20    	movups 0x20(%r14,%rax,1),%xmm2
  6f2ae1:	41 0f 10 5c 06 30    	movups 0x30(%r14,%rax,1),%xmm3
  6f2ae7:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
  6f2aee:	00 
  6f2aef:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
  6f2af6:	00 
  6f2af7:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  6f2afc:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6f2b01:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f2b05:	48 83 c6 70          	add    $0x70,%rsi
  6f2b09:	48 6b d5 70          	imul   $0x70,%rbp,%rdx
  6f2b0d:	4c 8b 3d ec 52 3f 00 	mov    0x3f52ec(%rip),%r15        # ae7e00 <memmove@GLIBC_2.2.5>
  6f2b14:	41 ff d7             	call   *%r15
  6f2b17:	49 6b c5 70          	imul   $0x70,%r13,%rax
  6f2b1b:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6f2b20:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6f2b25:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
  6f2b2c:	00 
  6f2b2d:	0f 28 9c 24 90 00 00 	movaps 0x90(%rsp),%xmm3
  6f2b34:	00 
  6f2b35:	0f 11 04 03          	movups %xmm0,(%rbx,%rax,1)
  6f2b39:	0f 11 4c 03 10       	movups %xmm1,0x10(%rbx,%rax,1)
  6f2b3e:	0f 11 54 03 20       	movups %xmm2,0x20(%rbx,%rax,1)
  6f2b43:	0f 11 5c 03 30       	movups %xmm3,0x30(%rbx,%rax,1)
  6f2b48:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6f2b4f:	00 
  6f2b50:	0f 11 44 03 40       	movups %xmm0,0x40(%rbx,%rax,1)
  6f2b55:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
  6f2b5c:	00 
  6f2b5d:	0f 11 44 03 50       	movups %xmm0,0x50(%rbx,%rax,1)
  6f2b62:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  6f2b69:	00 
  6f2b6a:	0f 11 44 03 60       	movups %xmm0,0x60(%rbx,%rax,1)
  6f2b6f:	48 6b 7c 24 10 70    	imul   $0x70,0x10(%rsp),%rdi
  6f2b75:	48 01 df             	add    %rbx,%rdi
  6f2b78:	48 6b 54 24 18 70    	imul   $0x70,0x18(%rsp),%rdx
  6f2b7e:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  6f2b83:	ff 15 7f 52 3f 00    	call   *0x3f527f(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  6f2b89:	49 8d 6c 24 01       	lea    0x1(%r12),%rbp
  6f2b8e:	4b 8d 3c e6          	lea    (%r14,%r12,8),%rdi
  6f2b92:	48 81 c7 40 05 00 00 	add    $0x540,%rdi
  6f2b99:	4b 8d 34 e6          	lea    (%r14,%r12,8),%rsi
  6f2b9d:	48 81 c6 48 05 00 00 	add    $0x548,%rsi
  6f2ba4:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
  6f2bab:	00 
  6f2bac:	41 ff d7             	call   *%r15
  6f2baf:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  6f2bb6:	00 
  6f2bb7:	48 39 ee             	cmp    %rbp,%rsi
  6f2bba:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6f2bbf:	0f 86 c5 00 00 00    	jbe    6f2c8a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f2bc5:	89 f1                	mov    %esi,%ecx
  6f2bc7:	29 e9                	sub    %ebp,%ecx
  6f2bc9:	83 e1 03             	and    $0x3,%ecx
  6f2bcc:	0f 84 ee 01 00 00    	je     6f2dc0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x860>
  6f2bd2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f2bd9:	1f 84 00 00 00 00 00 
  6f2be0:	48 8d 45 01          	lea    0x1(%rbp),%rax
  6f2be4:	49 8b 94 ee 38 05 00 	mov    0x538(%r14,%rbp,8),%rdx
  6f2beb:	00 
  6f2bec:	4c 89 b2 d0 04 00 00 	mov    %r14,0x4d0(%rdx)
  6f2bf3:	66 89 aa 30 05 00 00 	mov    %bp,0x530(%rdx)
  6f2bfa:	48 89 c5             	mov    %rax,%rbp
  6f2bfd:	48 ff c9             	dec    %rcx
  6f2c00:	75 de                	jne    6f2be0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x680>
  6f2c02:	49 f7 dc             	neg    %r12
  6f2c05:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
  6f2c09:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f2c0d:	83 f9 03             	cmp    $0x3,%ecx
  6f2c10:	72 78                	jb     6f2c8a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f2c12:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f2c19:	1f 84 00 00 00 00 00 
  6f2c20:	49 8b 8c c6 38 05 00 	mov    0x538(%r14,%rax,8),%rcx
  6f2c27:	00 
  6f2c28:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f2c2f:	66 89 81 30 05 00 00 	mov    %ax,0x530(%rcx)
  6f2c36:	49 8b 8c c6 40 05 00 	mov    0x540(%r14,%rax,8),%rcx
  6f2c3d:	00 
  6f2c3e:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f2c45:	8d 50 01             	lea    0x1(%rax),%edx
  6f2c48:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2c4f:	49 8b 8c c6 48 05 00 	mov    0x548(%r14,%rax,8),%rcx
  6f2c56:	00 
  6f2c57:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f2c5e:	8d 50 02             	lea    0x2(%rax),%edx
  6f2c61:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2c68:	49 8b 8c c6 50 05 00 	mov    0x550(%r14,%rax,8),%rcx
  6f2c6f:	00 
  6f2c70:	4c 89 b1 d0 04 00 00 	mov    %r14,0x4d0(%rcx)
  6f2c77:	8d 50 03             	lea    0x3(%rax),%edx
  6f2c7a:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2c81:	48 83 c0 04          	add    $0x4,%rax
  6f2c85:	48 39 f0             	cmp    %rsi,%rax
  6f2c88:	75 96                	jne    6f2c20 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x6c0>
  6f2c8a:	66 41 ff 8e 32 05 00 	decw   0x532(%r14)
  6f2c91:	00 
  6f2c92:	be 38 05 00 00       	mov    $0x538,%esi
  6f2c97:	4c 8b a4 24 f8 00 00 	mov    0xf8(%rsp),%r12
  6f2c9e:	00 
  6f2c9f:	49 83 fc 02          	cmp    $0x2,%r12
  6f2ca3:	48 8b ac 24 d8 00 00 	mov    0xd8(%rsp),%rbp
  6f2caa:	00 
  6f2cab:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  6f2cb0:	0f 82 ea fb ff ff    	jb     6f28a0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f2cb6:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6f2cbb:	48 ff c2             	inc    %rdx
  6f2cbe:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  6f2cc3:	48 2b 44 24 38       	sub    0x38(%rsp),%rax
  6f2cc8:	48 39 c2             	cmp    %rax,%rdx
  6f2ccb:	0f 85 a7 01 00 00    	jne    6f2e78 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x918>
  6f2cd1:	48 8d 83 38 05 00 00 	lea    0x538(%rbx),%rax
  6f2cd8:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  6f2cdd:	4a 8d 3c f8          	lea    (%rax,%r15,8),%rdi
  6f2ce1:	49 8d b5 38 05 00 00 	lea    0x538(%r13),%rsi
  6f2ce8:	c1 e2 03             	shl    $0x3,%edx
  6f2ceb:	ff 15 17 51 3f 00    	call   *0x3f5117(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  6f2cf1:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6f2cf6:	89 f9                	mov    %edi,%ecx
  6f2cf8:	44 29 f9             	sub    %r15d,%ecx
  6f2cfb:	ff c1                	inc    %ecx
  6f2cfd:	4c 89 f8             	mov    %r15,%rax
  6f2d00:	83 e1 03             	and    $0x3,%ecx
  6f2d03:	74 2d                	je     6f2d32 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7d2>
  6f2d05:	4c 89 fa             	mov    %r15,%rdx
  6f2d08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  6f2d0f:	00 
  6f2d10:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f2d14:	48 8b b4 d3 38 05 00 	mov    0x538(%rbx,%rdx,8),%rsi
  6f2d1b:	00 
  6f2d1c:	48 89 9e d0 04 00 00 	mov    %rbx,0x4d0(%rsi)
  6f2d23:	66 89 96 30 05 00 00 	mov    %dx,0x530(%rsi)
  6f2d2a:	48 89 c2             	mov    %rax,%rdx
  6f2d2d:	48 ff c9             	dec    %rcx
  6f2d30:	75 de                	jne    6f2d10 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7b0>
  6f2d32:	48 89 f9             	mov    %rdi,%rcx
  6f2d35:	4c 29 f9             	sub    %r15,%rcx
  6f2d38:	be 98 05 00 00       	mov    $0x598,%esi
  6f2d3d:	83 f9 03             	cmp    $0x3,%ecx
  6f2d40:	4c 8b 7c 24 50       	mov    0x50(%rsp),%r15
  6f2d45:	0f 82 55 fb ff ff    	jb     6f28a0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f2d4b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6f2d50:	48 8b 8c c3 38 05 00 	mov    0x538(%rbx,%rax,8),%rcx
  6f2d57:	00 
  6f2d58:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f2d5f:	66 89 81 30 05 00 00 	mov    %ax,0x530(%rcx)
  6f2d66:	48 8b 8c c3 40 05 00 	mov    0x540(%rbx,%rax,8),%rcx
  6f2d6d:	00 
  6f2d6e:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f2d75:	8d 50 01             	lea    0x1(%rax),%edx
  6f2d78:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2d7f:	48 8b 8c c3 48 05 00 	mov    0x548(%rbx,%rax,8),%rcx
  6f2d86:	00 
  6f2d87:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f2d8e:	8d 50 02             	lea    0x2(%rax),%edx
  6f2d91:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2d98:	48 8b 8c c3 50 05 00 	mov    0x550(%rbx,%rax,8),%rcx
  6f2d9f:	00 
  6f2da0:	48 89 99 d0 04 00 00 	mov    %rbx,0x4d0(%rcx)
  6f2da7:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f2dab:	66 89 91 30 05 00 00 	mov    %dx,0x530(%rcx)
  6f2db2:	48 83 c0 04          	add    $0x4,%rax
  6f2db6:	48 39 fa             	cmp    %rdi,%rdx
  6f2db9:	75 95                	jne    6f2d50 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x7f0>
  6f2dbb:	e9 e0 fa ff ff       	jmp    6f28a0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x340>
  6f2dc0:	48 89 e8             	mov    %rbp,%rax
  6f2dc3:	49 f7 dc             	neg    %r12
  6f2dc6:	4a 8d 0c 26          	lea    (%rsi,%r12,1),%rcx
  6f2dca:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f2dce:	83 f9 03             	cmp    $0x3,%ecx
  6f2dd1:	0f 83 49 fe ff ff    	jae    6f2c20 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x6c0>
  6f2dd7:	e9 ae fe ff ff       	jmp    6f2c8a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x72a>
  6f2ddc:	48 85 c0             	test   %rax,%rax
  6f2ddf:	0f 85 e9 f9 ff ff    	jne    6f27ce <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2de5:	4c 8b b4 24 d0 00 00 	mov    0xd0(%rsp),%r14
  6f2dec:	00 
  6f2ded:	49 8b 1e             	mov    (%r14),%rbx
  6f2df0:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f2df7:	48 85 db             	test   %rbx,%rbx
  6f2dfa:	0f 84 aa 00 00 00    	je     6f2eaa <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x94a>
  6f2e00:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f2e04:	48 85 c0             	test   %rax,%rax
  6f2e07:	0f 84 ac 00 00 00    	je     6f2eb9 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x959>
  6f2e0d:	48 8b 3b             	mov    (%rbx),%rdi
  6f2e10:	48 8b 8f 38 05 00 00 	mov    0x538(%rdi),%rcx
  6f2e17:	48 89 0b             	mov    %rcx,(%rbx)
  6f2e1a:	48 ff c8             	dec    %rax
  6f2e1d:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f2e21:	48 c7 81 d0 04 00 00 	movq   $0x0,0x4d0(%rcx)
  6f2e28:	00 00 00 00 
  6f2e2c:	be 98 05 00 00       	mov    $0x598,%esi
  6f2e31:	ba 08 00 00 00       	mov    $0x8,%edx
  6f2e36:	ff 15 a4 4f 3f 00    	call   *0x3f4fa4(%rip)        # ae7de0 <_DYNAMIC+0x248>
  6f2e3c:	49 89 1e             	mov    %rbx,(%r14)
  6f2e3f:	e9 8a f9 ff ff       	jmp    6f27ce <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2e44:	be 05 00 00 00       	mov    $0x5,%esi
  6f2e49:	48 29 c6             	sub    %rax,%rsi
  6f2e4c:	48 8d bc 24 78 01 00 	lea    0x178(%rsp),%rdi
  6f2e53:	00 
  6f2e54:	e8 87 0c 00 00       	call   6f3ae0 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2e59:	e9 70 f9 ff ff       	jmp    6f27ce <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2e5e:	be 05 00 00 00       	mov    $0x5,%esi
  6f2e63:	48 29 c6             	sub    %rax,%rsi
  6f2e66:	48 8d bc 24 b0 01 00 	lea    0x1b0(%rsp),%rdi
  6f2e6d:	00 
  6f2e6e:	e8 ad 10 00 00       	call   6f3f20 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1n_5style5StyleEE16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2e73:	e9 56 f9 ff ff       	jmp    6f27ce <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x26e>
  6f2e78:	be 28 00 00 00       	mov    $0x28,%esi
  6f2e7d:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6f2e82:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  6f2e87:	ff 15 8b 4f 3f 00    	call   *0x3f4f8b(%rip)        # ae7e18 <_DYNAMIC+0x280>
  6f2e8d:	eb 28                	jmp    6f2eb7 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x957>
  6f2e8f:	48 8d 3d 43 08 97 ff 	lea    -0x68f7bd(%rip),%rdi        # 636d9 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f2e96:	48 8d 15 0b 6c 3c 00 	lea    0x3c6c0b(%rip),%rdx        # ab9aa8 <__frame_dummy_init_array_entry+0x1a0>
  6f2e9d:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f2ea2:	ff 15 90 4f 3f 00    	call   *0x3f4f90(%rip)        # ae7e38 <_DYNAMIC+0x2a0>
  6f2ea8:	eb 0d                	jmp    6f2eb7 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x957>
  6f2eaa:	48 8d 3d 07 6b 3c 00 	lea    0x3c6b07(%rip),%rdi        # ab99b8 <__frame_dummy_init_array_entry+0xb0>
  6f2eb1:	ff 15 69 4f 3f 00    	call   *0x3f4f69(%rip)        # ae7e20 <_DYNAMIC+0x288>
  6f2eb7:	0f 0b                	ud2
  6f2eb9:	48 8d 05 c8 6a 3c 00 	lea    0x3c6ac8(%rip),%rax        # ab9988 <__frame_dummy_init_array_entry+0x80>
  6f2ec0:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f2ec5:	be 21 00 00 00       	mov    $0x21,%esi
  6f2eca:	48 8d 05 ca 06 97 ff 	lea    -0x68f936(%rip),%rax        # 6359b <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f2ed1:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f2ed6:	eb a5                	jmp    6f2e7d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1Q_5style5StyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3w_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3w_INtB3w_8BTreeMapyB1L_E6retainNCINvMsi_B1O_NtB1O_9Overrides6retainNCNvMst_NtB1Q_7runtimeINtB6k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0NtNtBb_5alloc6GlobalE0B80_EB6P_+0x91d>
  6f2ed8:	48 89 c3             	mov    %rax,%rbx
  6f2edb:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  6f2ee2:	00 
  6f2ee3:	e8 68 4c 02 00       	call   717b50 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f2ee8:	48 89 df             	mov    %rbx,%rdi
  6f2eeb:	e8 60 56 3c 00       	call   ab8550 <_Unwind_Resume@plt>
  6f2ef0:	ff 15 3a 4f 3f 00    	call   *0x3f4f3a(%rip)        # ae7e30 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
