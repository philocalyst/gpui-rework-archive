
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072ef40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>:
  72ef40:	55                   	push   %rbp
  72ef41:	41 57                	push   %r15
  72ef43:	41 56                	push   %r14
  72ef45:	41 55                	push   %r13
  72ef47:	41 54                	push   %r12
  72ef49:	53                   	push   %rbx
  72ef4a:	48 83 ec 48          	sub    $0x48,%rsp
  72ef4e:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  72ef53:	48 89 cd             	mov    %rcx,%rbp
  72ef56:	49 89 d7             	mov    %rdx,%r15
  72ef59:	49 89 f5             	mov    %rsi,%r13
  72ef5c:	49 89 fc             	mov    %rdi,%r12
  72ef5f:	48 83 fe 21          	cmp    $0x21,%rsi
  72ef63:	73 1e                	jae    72ef83 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x43>
  72ef65:	4c 89 e7             	mov    %r12,%rdi
  72ef68:	4c 89 ee             	mov    %r13,%rsi
  72ef6b:	4c 89 fa             	mov    %r15,%rdx
  72ef6e:	48 89 e9             	mov    %rbp,%rcx
  72ef71:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  72ef78:	00 
  72ef79:	e8 32 2a fe ff       	call   7119b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_>
  72ef7e:	e9 5f 04 00 00       	jmp    72f3e2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4a2>
  72ef83:	45 89 c6             	mov    %r8d,%r14d
  72ef86:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  72ef8b:	4c 89 eb             	mov    %r13,%rbx
  72ef8e:	66 90                	xchg   %ax,%ax
  72ef90:	45 85 f6             	test   %r14d,%r14d
  72ef93:	0f 84 2a 04 00 00    	je     72f3c3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x483>
  72ef99:	44 89 74 24 14       	mov    %r14d,0x14(%rsp)
  72ef9e:	48 89 d9             	mov    %rbx,%rcx
  72efa1:	48 c1 e9 03          	shr    $0x3,%rcx
  72efa5:	4c 8d 34 49          	lea    (%rcx,%rcx,2),%r14
  72efa9:	49 c1 e6 05          	shl    $0x5,%r14
  72efad:	4d 01 e6             	add    %r12,%r14
  72efb0:	48 69 d1 a8 00 00 00 	imul   $0xa8,%rcx,%rdx
  72efb7:	4c 01 e2             	add    %r12,%rdx
  72efba:	48 83 fb 40          	cmp    $0x40,%rbx
  72efbe:	73 30                	jae    72eff0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0xb0>
  72efc0:	49 8b 04 24          	mov    (%r12),%rax
  72efc4:	49 8b 0e             	mov    (%r14),%rcx
  72efc7:	48 39 c8             	cmp    %rcx,%rax
  72efca:	40 0f 92 c6          	setb   %sil
  72efce:	48 8b 3a             	mov    (%rdx),%rdi
  72efd1:	48 39 f8             	cmp    %rdi,%rax
  72efd4:	0f 92 c0             	setb   %al
  72efd7:	40 30 f0             	xor    %sil,%al
  72efda:	48 39 f9             	cmp    %rdi,%rcx
  72efdd:	0f 92 c1             	setb   %cl
  72efe0:	40 30 f1             	xor    %sil,%cl
  72efe3:	4c 0f 45 f2          	cmovne %rdx,%r14
  72efe7:	84 c0                	test   %al,%al
  72efe9:	4d 0f 45 f4          	cmovne %r12,%r14
  72efed:	eb 0f                	jmp    72effe <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0xbe>
  72efef:	90                   	nop
  72eff0:	4c 89 e7             	mov    %r12,%rdi
  72eff3:	4c 89 f6             	mov    %r14,%rsi
  72eff6:	e8 95 f7 ff ff       	call   72e790 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB19_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3S_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB19_9ListDraftEINtNtB4P_3map3MapIB5l_B1H_ENCNCNvMst_NtB1b_7runtimeINtB6u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6o_s2_0EE0E0EB6Z_>
  72effb:	49 89 c6             	mov    %rax,%r14
  72effe:	ff 4c 24 14          	decl   0x14(%rsp)
  72f002:	4d 89 f2             	mov    %r14,%r10
  72f005:	4d 29 e2             	sub    %r12,%r10
  72f008:	49 c1 ea 03          	shr    $0x3,%r10
  72f00c:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
  72f013:	aa aa aa 
  72f016:	4c 0f af d0          	imul   %rax,%r10
  72f01a:	49 8b 46 10          	mov    0x10(%r14),%rax
  72f01e:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  72f023:	41 0f 10 06          	movups (%r14),%xmm0
  72f027:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  72f02c:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  72f032:	74 11                	je     72f045 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x105>
  72f034:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  72f039:	48 8b 00             	mov    (%rax),%rax
  72f03c:	49 3b 06             	cmp    (%r14),%rax
  72f03f:	0f 83 db 01 00 00    	jae    72f220 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x2e0>
  72f045:	48 39 dd             	cmp    %rbx,%rbp
  72f048:	0f 82 b9 03 00 00    	jb     72f407 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c7>
  72f04e:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
  72f052:	49 8d 2c c7          	lea    (%r15,%rax,8),%rbp
  72f056:	45 31 ed             	xor    %r13d,%r13d
  72f059:	4c 89 e0             	mov    %r12,%rax
  72f05c:	48 89 e9             	mov    %rbp,%rcx
  72f05f:	4c 89 d2             	mov    %r10,%rdx
  72f062:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f069:	1f 84 00 00 00 00 00 
  72f070:	48 8d 34 52          	lea    (%rdx,%rdx,2),%rsi
  72f074:	49 8d 34 f4          	lea    (%r12,%rsi,8),%rsi
  72f078:	48 39 f0             	cmp    %rsi,%rax
  72f07b:	73 37                	jae    72f0b4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x174>
  72f07d:	0f 1f 00             	nopl   (%rax)
  72f080:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72f084:	48 8b 38             	mov    (%rax),%rdi
  72f087:	49 3b 3e             	cmp    (%r14),%rdi
  72f08a:	48 8b 78 10          	mov    0x10(%rax),%rdi
  72f08e:	49 89 c8             	mov    %rcx,%r8
  72f091:	4d 0f 42 c7          	cmovb  %r15,%r8
  72f095:	4f 8d 4c 6d 00       	lea    0x0(%r13,%r13,2),%r9
  72f09a:	4b 89 7c c8 10       	mov    %rdi,0x10(%r8,%r9,8)
  72f09f:	0f 10 00             	movups (%rax),%xmm0
  72f0a2:	43 0f 11 04 c8       	movups %xmm0,(%r8,%r9,8)
  72f0a7:	49 83 d5 00          	adc    $0x0,%r13
  72f0ab:	48 83 c0 18          	add    $0x18,%rax
  72f0af:	48 39 f0             	cmp    %rsi,%rax
  72f0b2:	72 cc                	jb     72f080 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x140>
  72f0b4:	48 39 da             	cmp    %rbx,%rdx
  72f0b7:	74 37                	je     72f0f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x1b0>
  72f0b9:	4a 8d 14 6d 00 00 00 	lea    0x0(,%r13,2),%rdx
  72f0c0:	00 
  72f0c1:	4c 01 ea             	add    %r13,%rdx
  72f0c4:	48 8b 70 10          	mov    0x10(%rax),%rsi
  72f0c8:	48 89 74 d1 f8       	mov    %rsi,-0x8(%rcx,%rdx,8)
  72f0cd:	0f 10 00             	movups (%rax),%xmm0
  72f0d0:	0f 11 44 d1 e8       	movups %xmm0,-0x18(%rcx,%rdx,8)
  72f0d5:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72f0d9:	48 83 c0 18          	add    $0x18,%rax
  72f0dd:	48 89 da             	mov    %rbx,%rdx
  72f0e0:	eb 8e                	jmp    72f070 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x130>
  72f0e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f0e9:	1f 84 00 00 00 00 00 
  72f0f0:	4c 89 54 24 28       	mov    %r10,0x28(%rsp)
  72f0f5:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
  72f0fc:	00 
  72f0fd:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
  72f101:	4c 89 e7             	mov    %r12,%rdi
  72f104:	4c 89 fe             	mov    %r15,%rsi
  72f107:	ff 15 fb 8c 3b 00    	call   *0x3b8cfb(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72f10d:	49 ba fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r10
  72f114:	ff ff 1f 
  72f117:	48 89 de             	mov    %rbx,%rsi
  72f11a:	4c 29 ee             	sub    %r13,%rsi
  72f11d:	0f 84 9f 00 00 00    	je     72f1c2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x282>
  72f123:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  72f12a:	00 
  72f12b:	4c 01 e8             	add    %r13,%rax
  72f12e:	49 8d 04 c4          	lea    (%r12,%rax,8),%rax
  72f132:	49 8d 4d 01          	lea    0x1(%r13),%rcx
  72f136:	48 39 cb             	cmp    %rcx,%rbx
  72f139:	75 05                	jne    72f140 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x200>
  72f13b:	31 d2                	xor    %edx,%edx
  72f13d:	eb 65                	jmp    72f1a4 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x264>
  72f13f:	90                   	nop
  72f140:	48 89 f1             	mov    %rsi,%rcx
  72f143:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72f147:	49 8d 57 e8          	lea    -0x18(%r15),%rdx
  72f14b:	48 8d 3c 5b          	lea    (%rbx,%rbx,2),%rdi
  72f14f:	48 8d 3c fa          	lea    (%rdx,%rdi,8),%rdi
  72f153:	49 89 c0             	mov    %rax,%r8
  72f156:	31 d2                	xor    %edx,%edx
  72f158:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  72f15f:	00 
  72f160:	49 89 d1             	mov    %rdx,%r9
  72f163:	48 8b 57 10          	mov    0x10(%rdi),%rdx
  72f167:	49 89 50 10          	mov    %rdx,0x10(%r8)
  72f16b:	0f 10 07             	movups (%rdi),%xmm0
  72f16e:	41 0f 11 00          	movups %xmm0,(%r8)
  72f172:	49 8d 51 02          	lea    0x2(%r9),%rdx
  72f176:	4d 31 d1             	xor    %r10,%r9
  72f179:	4f 8d 0c 49          	lea    (%r9,%r9,2),%r9
  72f17d:	42 0f 10 44 cd 00    	movups 0x0(%rbp,%r9,8),%xmm0
  72f183:	41 0f 11 40 18       	movups %xmm0,0x18(%r8)
  72f188:	4e 8b 4c cd 10       	mov    0x10(%rbp,%r9,8),%r9
  72f18d:	4d 89 48 28          	mov    %r9,0x28(%r8)
  72f191:	49 83 c0 30          	add    $0x30,%r8
  72f195:	48 83 c7 d0          	add    $0xffffffffffffffd0,%rdi
  72f199:	48 39 d1             	cmp    %rdx,%rcx
  72f19c:	75 c2                	jne    72f160 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x220>
  72f19e:	40 f6 c6 01          	test   $0x1,%sil
  72f1a2:	74 1e                	je     72f1c2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x282>
  72f1a4:	48 8d 0c 52          	lea    (%rdx,%rdx,2),%rcx
  72f1a8:	48 f7 d2             	not    %rdx
  72f1ab:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  72f1af:	48 8b 7c d5 10       	mov    0x10(%rbp,%rdx,8),%rdi
  72f1b4:	48 89 7c c8 10       	mov    %rdi,0x10(%rax,%rcx,8)
  72f1b9:	0f 10 44 d5 00       	movups 0x0(%rbp,%rdx,8),%xmm0
  72f1be:	0f 11 04 c8          	movups %xmm0,(%rax,%rcx,8)
  72f1c2:	4d 85 ed             	test   %r13,%r13
  72f1c5:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72f1ca:	4c 8b 54 24 28       	mov    0x28(%rsp),%r10
  72f1cf:	74 4f                	je     72f220 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x2e0>
  72f1d1:	4c 39 eb             	cmp    %r13,%rbx
  72f1d4:	0f 82 2f 02 00 00    	jb     72f409 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c9>
  72f1da:	4a 8d 04 6d 00 00 00 	lea    0x0(,%r13,2),%rax
  72f1e1:	00 
  72f1e2:	4c 01 e8             	add    %r13,%rax
  72f1e5:	49 8d 3c c4          	lea    (%r12,%rax,8),%rdi
  72f1e9:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  72f1f0:	00 
  72f1f1:	48 89 04 24          	mov    %rax,(%rsp)
  72f1f5:	4c 89 fa             	mov    %r15,%rdx
  72f1f8:	48 89 e9             	mov    %rbp,%rcx
  72f1fb:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72f200:	45 89 f0             	mov    %r14d,%r8d
  72f203:	4c 8d 4c 24 30       	lea    0x30(%rsp),%r9
  72f208:	e8 33 fd ff ff       	call   72ef40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_>
  72f20d:	4c 89 eb             	mov    %r13,%rbx
  72f210:	49 83 fd 21          	cmp    $0x21,%r13
  72f214:	0f 83 76 fd ff ff    	jae    72ef90 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x50>
  72f21a:	e9 46 fd ff ff       	jmp    72ef65 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72f21f:	90                   	nop
  72f220:	48 39 dd             	cmp    %rbx,%rbp
  72f223:	0f 82 de 01 00 00    	jb     72f407 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4c7>
  72f229:	48 8d 04 5b          	lea    (%rbx,%rbx,2),%rax
  72f22d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  72f232:	4d 8d 0c c7          	lea    (%r15,%rax,8),%r9
  72f236:	31 ed                	xor    %ebp,%ebp
  72f238:	4c 89 e0             	mov    %r12,%rax
  72f23b:	4c 89 c9             	mov    %r9,%rcx
  72f23e:	66 90                	xchg   %ax,%ax
  72f240:	4b 8d 14 52          	lea    (%r10,%r10,2),%rdx
  72f244:	49 8d 14 d4          	lea    (%r12,%rdx,8),%rdx
  72f248:	48 39 d0             	cmp    %rdx,%rax
  72f24b:	73 36                	jae    72f283 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x343>
  72f24d:	0f 1f 00             	nopl   (%rax)
  72f250:	49 8b 36             	mov    (%r14),%rsi
  72f253:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72f257:	48 3b 30             	cmp    (%rax),%rsi
  72f25a:	48 89 ce             	mov    %rcx,%rsi
  72f25d:	49 0f 43 f7          	cmovae %r15,%rsi
  72f261:	48 8d 7c 6d 00       	lea    0x0(%rbp,%rbp,2),%rdi
  72f266:	4c 8b 40 10          	mov    0x10(%rax),%r8
  72f26a:	4c 89 44 fe 10       	mov    %r8,0x10(%rsi,%rdi,8)
  72f26f:	0f 10 00             	movups (%rax),%xmm0
  72f272:	0f 11 04 fe          	movups %xmm0,(%rsi,%rdi,8)
  72f276:	48 83 dd ff          	sbb    $0xffffffffffffffff,%rbp
  72f27a:	48 83 c0 18          	add    $0x18,%rax
  72f27e:	48 39 d0             	cmp    %rdx,%rax
  72f281:	72 cd                	jb     72f250 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x310>
  72f283:	49 39 da             	cmp    %rbx,%r10
  72f286:	74 38                	je     72f2c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x380>
  72f288:	48 83 c1 e8          	add    $0xffffffffffffffe8,%rcx
  72f28c:	48 8d 14 6d 00 00 00 	lea    0x0(,%rbp,2),%rdx
  72f293:	00 
  72f294:	48 01 ea             	add    %rbp,%rdx
  72f297:	48 8b 70 10          	mov    0x10(%rax),%rsi
  72f29b:	49 89 74 d7 10       	mov    %rsi,0x10(%r15,%rdx,8)
  72f2a0:	0f 10 00             	movups (%rax),%xmm0
  72f2a3:	41 0f 11 04 d7       	movups %xmm0,(%r15,%rdx,8)
  72f2a8:	48 ff c5             	inc    %rbp
  72f2ab:	48 83 c0 18          	add    $0x18,%rax
  72f2af:	49 89 da             	mov    %rbx,%r10
  72f2b2:	eb 8c                	jmp    72f240 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x300>
  72f2b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f2bb:	00 00 00 00 00 
  72f2c0:	4d 89 ce             	mov    %r9,%r14
  72f2c3:	48 8d 04 ed 00 00 00 	lea    0x0(,%rbp,8),%rax
  72f2ca:	00 
  72f2cb:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
  72f2cf:	4c 89 e7             	mov    %r12,%rdi
  72f2d2:	4c 89 fe             	mov    %r15,%rsi
  72f2d5:	ff 15 2d 8b 3b 00    	call   *0x3b8b2d(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72f2db:	49 89 dd             	mov    %rbx,%r13
  72f2de:	49 29 ed             	sub    %rbp,%r13
  72f2e1:	0f 84 0a 01 00 00    	je     72f3f1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4b1>
  72f2e7:	48 8d 04 6d 00 00 00 	lea    0x0(,%rbp,2),%rax
  72f2ee:	00 
  72f2ef:	48 01 e8             	add    %rbp,%rax
  72f2f2:	4d 8d 24 c4          	lea    (%r12,%rax,8),%r12
  72f2f6:	48 8d 45 01          	lea    0x1(%rbp),%rax
  72f2fa:	48 39 c3             	cmp    %rax,%rbx
  72f2fd:	4d 89 f1             	mov    %r14,%r9
  72f300:	75 09                	jne    72f30b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x3cb>
  72f302:	31 c9                	xor    %ecx,%ecx
  72f304:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72f309:	eb 76                	jmp    72f381 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x441>
  72f30b:	4c 89 e8             	mov    %r13,%rax
  72f30e:	48 83 e0 fe          	and    $0xfffffffffffffffe,%rax
  72f312:	49 8d 4f e8          	lea    -0x18(%r15),%rcx
  72f316:	48 8d 14 5b          	lea    (%rbx,%rbx,2),%rdx
  72f31a:	48 8d 14 d1          	lea    (%rcx,%rdx,8),%rdx
  72f31e:	4c 89 e6             	mov    %r12,%rsi
  72f321:	31 c9                	xor    %ecx,%ecx
  72f323:	44 8b 74 24 14       	mov    0x14(%rsp),%r14d
  72f328:	49 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%r8
  72f32f:	ff ff 1f 
  72f332:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f339:	1f 84 00 00 00 00 00 
  72f340:	48 89 cf             	mov    %rcx,%rdi
  72f343:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
  72f347:	48 89 4e 10          	mov    %rcx,0x10(%rsi)
  72f34b:	0f 10 02             	movups (%rdx),%xmm0
  72f34e:	0f 11 06             	movups %xmm0,(%rsi)
  72f351:	48 8d 4f 02          	lea    0x2(%rdi),%rcx
  72f355:	4c 31 c7             	xor    %r8,%rdi
  72f358:	48 8d 3c 7f          	lea    (%rdi,%rdi,2),%rdi
  72f35c:	41 0f 10 04 f9       	movups (%r9,%rdi,8),%xmm0
  72f361:	0f 11 46 18          	movups %xmm0,0x18(%rsi)
  72f365:	49 8b 7c f9 10       	mov    0x10(%r9,%rdi,8),%rdi
  72f36a:	48 89 7e 28          	mov    %rdi,0x28(%rsi)
  72f36e:	48 83 c6 30          	add    $0x30,%rsi
  72f372:	48 83 c2 d0          	add    $0xffffffffffffffd0,%rdx
  72f376:	48 39 c8             	cmp    %rcx,%rax
  72f379:	75 c5                	jne    72f340 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x400>
  72f37b:	41 f6 c5 01          	test   $0x1,%r13b
  72f37f:	74 1f                	je     72f3a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x460>
  72f381:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  72f385:	48 f7 d1             	not    %rcx
  72f388:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  72f38c:	49 8b 54 c9 10       	mov    0x10(%r9,%rcx,8),%rdx
  72f391:	49 89 54 c4 10       	mov    %rdx,0x10(%r12,%rax,8)
  72f396:	41 0f 10 04 c9       	movups (%r9,%rcx,8),%xmm0
  72f39b:	41 0f 11 04 c4       	movups %xmm0,(%r12,%rax,8)
  72f3a0:	48 39 eb             	cmp    %rbp,%rbx
  72f3a3:	72 7d                	jb     72f422 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4e2>
  72f3a5:	b8 00 00 00 00       	mov    $0x0,%eax
  72f3aa:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  72f3af:	49 83 fd 21          	cmp    $0x21,%r13
  72f3b3:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72f3b8:	0f 83 cd fb ff ff    	jae    72ef8b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x4b>
  72f3be:	e9 a2 fb ff ff       	jmp    72ef65 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72f3c3:	4c 89 e7             	mov    %r12,%rdi
  72f3c6:	48 89 de             	mov    %rbx,%rsi
  72f3c9:	4c 89 fa             	mov    %r15,%rdx
  72f3cc:	48 89 e9             	mov    %rbp,%rcx
  72f3cf:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72f3d5:	4c 8b 8c 24 80 00 00 	mov    0x80(%rsp),%r9
  72f3dc:	00 
  72f3dd:	e8 1e d6 ff ff       	call   72ca00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB11_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1Y_11collections5btree3mapINtB2J_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3I_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB11_9ListDraftEINtNtB4E_3map3MapIB5a_B1z_ENCNCNvMst_NtB13_7runtimeINtB6j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6d_s2_0EE0E0EB6O_>
  72f3e2:	48 83 c4 48          	add    $0x48,%rsp
  72f3e6:	5b                   	pop    %rbx
  72f3e7:	41 5c                	pop    %r12
  72f3e9:	41 5d                	pop    %r13
  72f3eb:	41 5e                	pop    %r14
  72f3ed:	41 5f                	pop    %r15
  72f3ef:	5d                   	pop    %rbp
  72f3f0:	c3                   	ret
  72f3f1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  72f3f6:	4d 8d 24 c4          	lea    (%r12,%rax,8),%r12
  72f3fa:	45 31 ed             	xor    %r13d,%r13d
  72f3fd:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  72f402:	e9 5e fb ff ff       	jmp    72ef65 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1a_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB27_11collections5btree3mapINtB2T_8BTreeMapjB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3T_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1a_9ListDraftEINtNtB4Q_3map3MapIB5m_B1I_ENCNCNvMst_NtB1c_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6p_s2_0EE0E0EB70_+0x25>
  72f407:	0f 0b                	ud2
  72f409:	48 8d 3d 24 a2 93 ff 	lea    -0x6c5ddc(%rip),%rdi        # 69634 <anon.82a788e7fdd98d311675b83eb91f04ac.0.llvm.15086054616281437909+0x27>
  72f410:	48 8d 15 d1 bf 38 00 	lea    0x38bfd1(%rip),%rdx        # abb3e8 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x38>
  72f417:	be 13 00 00 00       	mov    $0x13,%esi
  72f41c:	ff 15 16 8a 3b 00    	call   *0x3b8a16(%rip)        # ae7e38 <_DYNAMIC+0x2a0>
  72f422:	48 8d 0d d7 bf 38 00 	lea    0x38bfd7(%rip),%rcx        # abb400 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x50>
  72f429:	48 89 ef             	mov    %rbp,%rdi
  72f42c:	48 89 de             	mov    %rbx,%rsi
  72f42f:	48 89 da             	mov    %rbx,%rdx
  72f432:	ff 15 f0 89 3b 00    	call   *0x3b89f0(%rip)        # ae7e28 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
