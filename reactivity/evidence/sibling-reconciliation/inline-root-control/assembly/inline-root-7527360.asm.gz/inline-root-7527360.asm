
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072dbc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_>:
  72dbc0:	48 89 f0             	mov    %rsi,%rax
  72dbc3:	48 d1 e8             	shr    $1,%rax
  72dbc6:	48 01 f0             	add    %rsi,%rax
  72dbc9:	75 0a                	jne    72dbd5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x15>
  72dbcb:	c3                   	ret
  72dbcc:	0f 1f 40 00          	nopl   0x0(%rax)
  72dbd0:	48 85 c0             	test   %rax,%rax
  72dbd3:	74 f6                	je     72dbcb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0xb>
  72dbd5:	48 ff c8             	dec    %rax
  72dbd8:	48 89 c2             	mov    %rax,%rdx
  72dbdb:	48 29 f2             	sub    %rsi,%rdx
  72dbde:	73 3a                	jae    72dc1a <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x5a>
  72dbe0:	48 8d 0c 40          	lea    (%rax,%rax,2),%rcx
  72dbe4:	48 8b 57 10          	mov    0x10(%rdi),%rdx
  72dbe8:	48 89 54 24 f8       	mov    %rdx,-0x8(%rsp)
  72dbed:	0f 10 07             	movups (%rdi),%xmm0
  72dbf0:	0f 29 44 24 e8       	movaps %xmm0,-0x18(%rsp)
  72dbf5:	48 8b 54 cf 10       	mov    0x10(%rdi,%rcx,8),%rdx
  72dbfa:	0f 10 04 cf          	movups (%rdi,%rcx,8),%xmm0
  72dbfe:	0f 11 07             	movups %xmm0,(%rdi)
  72dc01:	48 89 57 10          	mov    %rdx,0x10(%rdi)
  72dc05:	48 8b 54 24 f8       	mov    -0x8(%rsp),%rdx
  72dc0a:	48 89 54 cf 10       	mov    %rdx,0x10(%rdi,%rcx,8)
  72dc0f:	0f 28 44 24 e8       	movaps -0x18(%rsp),%xmm0
  72dc14:	0f 11 04 cf          	movups %xmm0,(%rdi,%rcx,8)
  72dc18:	31 d2                	xor    %edx,%edx
  72dc1a:	48 39 c6             	cmp    %rax,%rsi
  72dc1d:	48 89 c1             	mov    %rax,%rcx
  72dc20:	48 0f 42 ce          	cmovb  %rsi,%rcx
  72dc24:	4c 8d 04 55 01 00 00 	lea    0x1(,%rdx,2),%r8
  72dc2b:	00 
  72dc2c:	49 39 c8             	cmp    %rcx,%r8
  72dc2f:	73 9f                	jae    72dbd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x10>
  72dc31:	4c 8d 14 12          	lea    (%rdx,%rdx,1),%r10
  72dc35:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  72dc3c:	00 00 00 00 
  72dc40:	49 83 c2 02          	add    $0x2,%r10
  72dc44:	49 39 ca             	cmp    %rcx,%r10
  72dc47:	73 14                	jae    72dc5d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x9d>
  72dc49:	4f 8d 0c 40          	lea    (%r8,%r8,2),%r9
  72dc4d:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  72dc51:	4e 8b 0c cf          	mov    (%rdi,%r9,8),%r9
  72dc55:	4e 3b 0c d7          	cmp    (%rdi,%r10,8),%r9
  72dc59:	49 83 d0 00          	adc    $0x0,%r8
  72dc5d:	4d 89 c1             	mov    %r8,%r9
  72dc60:	4c 8d 04 52          	lea    (%rdx,%rdx,2),%r8
  72dc64:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  72dc68:	4a 8b 14 c7          	mov    (%rdi,%r8,8),%rdx
  72dc6c:	4e 8b 1c d7          	mov    (%rdi,%r10,8),%r11
  72dc70:	4c 39 da             	cmp    %r11,%rdx
  72dc73:	0f 83 57 ff ff ff    	jae    72dbd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x10>
  72dc79:	4e 8d 04 c7          	lea    (%rdi,%r8,8),%r8
  72dc7d:	4e 8d 14 d7          	lea    (%rdi,%r10,8),%r10
  72dc81:	4d 89 18             	mov    %r11,(%r8)
  72dc84:	49 89 12             	mov    %rdx,(%r10)
  72dc87:	41 0f 10 40 08       	movups 0x8(%r8),%xmm0
  72dc8c:	41 0f 10 4a 08       	movups 0x8(%r10),%xmm1
  72dc91:	41 0f 11 48 08       	movups %xmm1,0x8(%r8)
  72dc96:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  72dc9b:	4f 8d 14 09          	lea    (%r9,%r9,1),%r10
  72dc9f:	4e 8d 04 4d 01 00 00 	lea    0x1(,%r9,2),%r8
  72dca6:	00 
  72dca7:	4c 89 ca             	mov    %r9,%rdx
  72dcaa:	49 39 c8             	cmp    %rcx,%r8
  72dcad:	72 91                	jb     72dc40 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x80>
  72dcaf:	e9 1c ff ff ff       	jmp    72dbd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort8unstable8heapsort8heapsortNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata8DeclaredNCINvMB8_SB15_20sort_unstable_by_keyyNCNvMst_B19_INtB19_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersI_0E0EB2Y_+0x10>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
