
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072f440 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>:
  72f440:	55                   	push   %rbp
  72f441:	41 57                	push   %r15
  72f443:	41 56                	push   %r14
  72f445:	41 55                	push   %r13
  72f447:	41 54                	push   %r12
  72f449:	53                   	push   %rbx
  72f44a:	48 83 ec 58          	sub    $0x58,%rsp
  72f44e:	4c 89 4c 24 18       	mov    %r9,0x18(%rsp)
  72f453:	49 89 ce             	mov    %rcx,%r14
  72f456:	49 89 d7             	mov    %rdx,%r15
  72f459:	49 89 f5             	mov    %rsi,%r13
  72f45c:	49 89 fc             	mov    %rdi,%r12
  72f45f:	48 83 fe 21          	cmp    $0x21,%rsi
  72f463:	73 1e                	jae    72f483 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x43>
  72f465:	4c 89 e7             	mov    %r12,%rdi
  72f468:	4c 89 ee             	mov    %r13,%rsi
  72f46b:	4c 89 fa             	mov    %r15,%rdx
  72f46e:	4c 89 f1             	mov    %r14,%rcx
  72f471:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  72f478:	00 
  72f479:	e8 92 20 fe ff       	call   711510 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2c_11collections5btree3mapINtB2Y_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB3Y_8adapters3map3MapINtNtB8_4iter4IterNtB1w_9ListDraftENCNvMst_NtB1y_7runtimeINtB5Z_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6u_>
  72f47e:	e9 a9 05 00 00       	jmp    72fa2c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5ec>
  72f483:	44 89 c3             	mov    %r8d,%ebx
  72f486:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
  72f48b:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72f490:	85 db                	test   %ebx,%ebx
  72f492:	0f 84 73 05 00 00    	je     72fa0b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5cb>
  72f498:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72f49d:	48 89 f1             	mov    %rsi,%rcx
  72f4a0:	48 c1 e9 03          	shr    $0x3,%rcx
  72f4a4:	48 89 c8             	mov    %rcx,%rax
  72f4a7:	48 c1 e0 06          	shl    $0x6,%rax
  72f4ab:	4c 01 e0             	add    %r12,%rax
  72f4ae:	48 6b d1 70          	imul   $0x70,%rcx,%rdx
  72f4b2:	4c 01 e2             	add    %r12,%rdx
  72f4b5:	48 83 fe 40          	cmp    $0x40,%rsi
  72f4b9:	73 35                	jae    72f4f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xb0>
  72f4bb:	49 8b 0c 24          	mov    (%r12),%rcx
  72f4bf:	48 8b 30             	mov    (%rax),%rsi
  72f4c2:	48 39 f1             	cmp    %rsi,%rcx
  72f4c5:	40 0f 92 c7          	setb   %dil
  72f4c9:	4c 8b 02             	mov    (%rdx),%r8
  72f4cc:	4c 39 c1             	cmp    %r8,%rcx
  72f4cf:	0f 92 c1             	setb   %cl
  72f4d2:	40 30 f9             	xor    %dil,%cl
  72f4d5:	4c 39 c6             	cmp    %r8,%rsi
  72f4d8:	40 0f 92 c6          	setb   %sil
  72f4dc:	40 30 fe             	xor    %dil,%sil
  72f4df:	48 0f 45 c2          	cmovne %rdx,%rax
  72f4e3:	84 c9                	test   %cl,%cl
  72f4e5:	49 0f 45 c4          	cmovne %r12,%rax
  72f4e9:	eb 10                	jmp    72f4fb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xbb>
  72f4eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  72f4f0:	4c 89 e7             	mov    %r12,%rdi
  72f4f3:	48 89 c6             	mov    %rax,%rsi
  72f4f6:	e8 e5 f1 ff ff       	call   72e6e0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared5pivot11median3_recTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB14_7sort_byNCINvXs1o_NtNtNtB1O_11collections5btree3mapINtB2A_8BTreeMapjB16_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB14_E9from_iterINtNtNtB3A_8adapters3map3MapINtNtB8_4iter4IterNtB18_9ListDraftENCNvMst_NtB1a_7runtimeINtB5B_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB66_>
  72f4fb:	ff cb                	dec    %ebx
  72f4fd:	89 5c 24 2c          	mov    %ebx,0x2c(%rsp)
  72f501:	48 89 c5             	mov    %rax,%rbp
  72f504:	4c 29 e5             	sub    %r12,%rbp
  72f507:	48 89 e9             	mov    %rbp,%rcx
  72f50a:	48 c1 e9 04          	shr    $0x4,%rcx
  72f50e:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  72f513:	0f 10 00             	movups (%rax),%xmm0
  72f516:	48 8b 00             	mov    (%rax),%rax
  72f519:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  72f51e:	48 83 7c 24 18 00    	cmpq   $0x0,0x18(%rsp)
  72f524:	74 0e                	je     72f534 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0xf4>
  72f526:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  72f52b:	48 39 01             	cmp    %rax,(%rcx)
  72f52e:	0f 83 8c 02 00 00    	jae    72f7c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x380>
  72f534:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  72f539:	49 39 de             	cmp    %rbx,%r14
  72f53c:	0f 82 0e 05 00 00    	jb     72fa50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x610>
  72f542:	49 89 de             	mov    %rbx,%r14
  72f545:	49 c1 e6 04          	shl    $0x4,%r14
  72f549:	4b 8d 0c 37          	lea    (%r15,%r14,1),%rcx
  72f54d:	45 31 ed             	xor    %r13d,%r13d
  72f550:	4c 89 e0             	mov    %r12,%rax
  72f553:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72f558:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  72f55d:	0f 1f 00             	nopl   (%rax)
  72f560:	48 89 d7             	mov    %rdx,%rdi
  72f563:	48 83 ef 03          	sub    $0x3,%rdi
  72f567:	be 00 00 00 00       	mov    $0x0,%esi
  72f56c:	48 0f 43 f7          	cmovae %rdi,%rsi
  72f570:	48 c1 e6 04          	shl    $0x4,%rsi
  72f574:	4c 01 e6             	add    %r12,%rsi
  72f577:	48 39 f0             	cmp    %rsi,%rax
  72f57a:	0f 83 a4 00 00 00    	jae    72f624 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x1e4>
  72f580:	48 8b 38             	mov    (%rax),%rdi
  72f583:	4c 8d 41 f0          	lea    -0x10(%rcx),%r8
  72f587:	45 31 c9             	xor    %r9d,%r9d
  72f58a:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72f58e:	4d 0f 42 c7          	cmovb  %r15,%r8
  72f592:	41 0f 92 c1          	setb   %r9b
  72f596:	4c 89 ef             	mov    %r13,%rdi
  72f599:	48 c1 e7 04          	shl    $0x4,%rdi
  72f59d:	4f 8d 14 29          	lea    (%r9,%r13,1),%r10
  72f5a1:	4c 8b 58 10          	mov    0x10(%rax),%r11
  72f5a5:	49 c1 e2 04          	shl    $0x4,%r10
  72f5a9:	4d 3b 1c 2c          	cmp    (%r12,%rbp,1),%r11
  72f5ad:	0f 10 00             	movups (%rax),%xmm0
  72f5b0:	4c 8d 59 e0          	lea    -0x20(%rcx),%r11
  72f5b4:	4d 0f 42 df          	cmovb  %r15,%r11
  72f5b8:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72f5bd:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72f5c1:	4d 11 cd             	adc    %r9,%r13
  72f5c4:	43 0f 11 04 13       	movups %xmm0,(%r11,%r10,1)
  72f5c9:	48 8b 78 20          	mov    0x20(%rax),%rdi
  72f5cd:	4c 8d 41 d0          	lea    -0x30(%rcx),%r8
  72f5d1:	45 31 c9             	xor    %r9d,%r9d
  72f5d4:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72f5d8:	4d 0f 42 c7          	cmovb  %r15,%r8
  72f5dc:	41 0f 92 c1          	setb   %r9b
  72f5e0:	4c 89 ef             	mov    %r13,%rdi
  72f5e3:	48 c1 e7 04          	shl    $0x4,%rdi
  72f5e7:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72f5eb:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72f5f0:	4b 8d 3c 29          	lea    (%r9,%r13,1),%rdi
  72f5f4:	4c 8b 40 30          	mov    0x30(%rax),%r8
  72f5f8:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72f5fc:	48 c1 e7 04          	shl    $0x4,%rdi
  72f600:	4d 3b 04 2c          	cmp    (%r12,%rbp,1),%r8
  72f604:	49 89 c8             	mov    %rcx,%r8
  72f607:	4d 0f 42 c7          	cmovb  %r15,%r8
  72f60b:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72f60f:	41 0f 11 04 38       	movups %xmm0,(%r8,%rdi,1)
  72f614:	4d 11 cd             	adc    %r9,%r13
  72f617:	48 83 c0 40          	add    $0x40,%rax
  72f61b:	48 39 f0             	cmp    %rsi,%rax
  72f61e:	0f 82 5c ff ff ff    	jb     72f580 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x140>
  72f624:	48 89 d6             	mov    %rdx,%rsi
  72f627:	48 c1 e6 04          	shl    $0x4,%rsi
  72f62b:	4c 01 e6             	add    %r12,%rsi
  72f62e:	48 39 f0             	cmp    %rsi,%rax
  72f631:	73 3b                	jae    72f66e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x22e>
  72f633:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f63a:	84 00 00 00 00 00 
  72f640:	48 8b 38             	mov    (%rax),%rdi
  72f643:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72f647:	4d 89 e8             	mov    %r13,%r8
  72f64a:	49 c1 e0 04          	shl    $0x4,%r8
  72f64e:	49 3b 3c 2c          	cmp    (%r12,%rbp,1),%rdi
  72f652:	48 89 cf             	mov    %rcx,%rdi
  72f655:	49 0f 42 ff          	cmovb  %r15,%rdi
  72f659:	0f 10 00             	movups (%rax),%xmm0
  72f65c:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72f661:	49 83 d5 00          	adc    $0x0,%r13
  72f665:	48 83 c0 10          	add    $0x10,%rax
  72f669:	48 39 f0             	cmp    %rsi,%rax
  72f66c:	72 d2                	jb     72f640 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x200>
  72f66e:	48 39 da             	cmp    %rbx,%rdx
  72f671:	74 2d                	je     72f6a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x260>
  72f673:	4c 89 ea             	mov    %r13,%rdx
  72f676:	48 c1 e2 04          	shl    $0x4,%rdx
  72f67a:	0f 10 00             	movups (%rax),%xmm0
  72f67d:	0f 11 44 11 f0       	movups %xmm0,-0x10(%rcx,%rdx,1)
  72f682:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72f686:	48 83 c0 10          	add    $0x10,%rax
  72f68a:	48 89 da             	mov    %rbx,%rdx
  72f68d:	e9 ce fe ff ff       	jmp    72f560 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x120>
  72f692:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f699:	1f 84 00 00 00 00 00 
  72f6a0:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  72f6a5:	4c 89 eb             	mov    %r13,%rbx
  72f6a8:	48 c1 e3 04          	shl    $0x4,%rbx
  72f6ac:	4c 89 e7             	mov    %r12,%rdi
  72f6af:	4c 89 fe             	mov    %r15,%rsi
  72f6b2:	48 89 da             	mov    %rbx,%rdx
  72f6b5:	ff 15 4d 87 3b 00    	call   *0x3b874d(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72f6bb:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72f6c0:	4c 29 ee             	sub    %r13,%rsi
  72f6c3:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72f6ca:	ff ff 0f 
  72f6cd:	4b 8d 3c 37          	lea    (%r15,%r14,1),%rdi
  72f6d1:	0f 84 8e 00 00 00    	je     72f765 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x325>
  72f6d7:	49 8d 45 01          	lea    0x1(%r13),%rax
  72f6db:	48 39 44 24 10       	cmp    %rax,0x10(%rsp)
  72f6e0:	75 0e                	jne    72f6f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x2b0>
  72f6e2:	31 c0                	xor    %eax,%eax
  72f6e4:	eb 65                	jmp    72f74b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x30b>
  72f6e6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  72f6ed:	00 00 00 
  72f6f0:	48 89 f1             	mov    %rsi,%rcx
  72f6f3:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72f6f7:	49 8d 44 24 10       	lea    0x10(%r12),%rax
  72f6fc:	48 8d 14 18          	lea    (%rax,%rbx,1),%rdx
  72f700:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72f704:	49 01 c6             	add    %rax,%r14
  72f707:	31 c0                	xor    %eax,%eax
  72f709:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72f710:	48 89 c7             	mov    %rax,%rdi
  72f713:	41 0f 10 06          	movups (%r14),%xmm0
  72f717:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72f71b:	48 83 c0 02          	add    $0x2,%rax
  72f71f:	4c 31 c7             	xor    %r8,%rdi
  72f722:	48 c1 e7 04          	shl    $0x4,%rdi
  72f726:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72f72b:	41 0f 10 04 39       	movups (%r9,%rdi,1),%xmm0
  72f730:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  72f735:	0f 11 02             	movups %xmm0,(%rdx)
  72f738:	48 83 c2 20          	add    $0x20,%rdx
  72f73c:	49 83 c6 e0          	add    $0xffffffffffffffe0,%r14
  72f740:	48 39 c1             	cmp    %rax,%rcx
  72f743:	75 cb                	jne    72f710 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x2d0>
  72f745:	40 f6 c6 01          	test   $0x1,%sil
  72f749:	74 1a                	je     72f765 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x325>
  72f74b:	49 8d 0c 1c          	lea    (%r12,%rbx,1),%rcx
  72f74f:	48 89 c2             	mov    %rax,%rdx
  72f752:	48 f7 d2             	not    %rdx
  72f755:	48 c1 e2 04          	shl    $0x4,%rdx
  72f759:	48 c1 e0 04          	shl    $0x4,%rax
  72f75d:	0f 10 04 17          	movups (%rdi,%rdx,1),%xmm0
  72f761:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  72f765:	4d 85 ed             	test   %r13,%r13
  72f768:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72f76d:	74 51                	je     72f7c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x380>
  72f76f:	4c 39 6c 24 10       	cmp    %r13,0x10(%rsp)
  72f774:	0f 82 d8 02 00 00    	jb     72fa52 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x612>
  72f77a:	4c 01 e3             	add    %r12,%rbx
  72f77d:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  72f784:	00 
  72f785:	48 89 04 24          	mov    %rax,(%rsp)
  72f789:	48 89 df             	mov    %rbx,%rdi
  72f78c:	4c 89 fa             	mov    %r15,%rdx
  72f78f:	4c 89 f1             	mov    %r14,%rcx
  72f792:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72f796:	41 89 d8             	mov    %ebx,%r8d
  72f799:	4c 8d 4c 24 40       	lea    0x40(%rsp),%r9
  72f79e:	e8 9d fc ff ff       	call   72f440 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_>
  72f7a3:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  72f7a8:	49 83 fd 21          	cmp    $0x21,%r13
  72f7ac:	0f 83 de fc ff ff    	jae    72f490 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x50>
  72f7b2:	e9 ae fc ff ff       	jmp    72f465 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x25>
  72f7b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  72f7be:	00 00 
  72f7c0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  72f7c5:	49 39 c6             	cmp    %rax,%r14
  72f7c8:	0f 82 82 02 00 00    	jb     72fa50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x610>
  72f7ce:	48 c1 e0 04          	shl    $0x4,%rax
  72f7d2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72f7d7:	49 8d 0c 07          	lea    (%r15,%rax,1),%rcx
  72f7db:	31 db                	xor    %ebx,%ebx
  72f7dd:	4c 89 e0             	mov    %r12,%rax
  72f7e0:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  72f7e5:	4c 8b 54 24 38       	mov    0x38(%rsp),%r10
  72f7ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  72f7f0:	4c 89 d6             	mov    %r10,%rsi
  72f7f3:	48 83 ee 03          	sub    $0x3,%rsi
  72f7f7:	ba 00 00 00 00       	mov    $0x0,%edx
  72f7fc:	48 0f 43 d6          	cmovae %rsi,%rdx
  72f800:	48 c1 e2 04          	shl    $0x4,%rdx
  72f804:	4c 01 e2             	add    %r12,%rdx
  72f807:	48 39 d0             	cmp    %rdx,%rax
  72f80a:	0f 83 9d 00 00 00    	jae    72f8ad <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x46d>
  72f810:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72f814:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
  72f818:	49 89 d8             	mov    %rbx,%r8
  72f81b:	49 c1 e0 04          	shl    $0x4,%r8
  72f81f:	48 3b 30             	cmp    (%rax),%rsi
  72f822:	49 0f 43 ff          	cmovae %r15,%rdi
  72f826:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f82a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72f82e:	49 89 d9             	mov    %rbx,%r9
  72f831:	49 c1 e1 04          	shl    $0x4,%r9
  72f835:	48 3b 70 10          	cmp    0x10(%rax),%rsi
  72f839:	0f 10 00             	movups (%rax),%xmm0
  72f83c:	48 8d 71 e0          	lea    -0x20(%rcx),%rsi
  72f840:	49 0f 43 f7          	cmovae %r15,%rsi
  72f844:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72f849:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f84d:	49 8b 3c 2c          	mov    (%r12,%rbp,1),%rdi
  72f851:	49 89 d8             	mov    %rbx,%r8
  72f854:	49 c1 e0 04          	shl    $0x4,%r8
  72f858:	48 3b 78 20          	cmp    0x20(%rax),%rdi
  72f85c:	0f 10 40 10          	movups 0x10(%rax),%xmm0
  72f860:	48 8d 79 d0          	lea    -0x30(%rcx),%rdi
  72f864:	49 0f 43 ff          	cmovae %r15,%rdi
  72f868:	42 0f 11 04 0e       	movups %xmm0,(%rsi,%r9,1)
  72f86d:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  72f871:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f875:	42 0f 11 04 07       	movups %xmm0,(%rdi,%r8,1)
  72f87a:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72f87e:	48 83 c1 c0          	add    $0xffffffffffffffc0,%rcx
  72f882:	48 89 df             	mov    %rbx,%rdi
  72f885:	48 c1 e7 04          	shl    $0x4,%rdi
  72f889:	48 3b 70 30          	cmp    0x30(%rax),%rsi
  72f88d:	48 89 ce             	mov    %rcx,%rsi
  72f890:	49 0f 43 f7          	cmovae %r15,%rsi
  72f894:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  72f898:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72f89c:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f8a0:	48 83 c0 40          	add    $0x40,%rax
  72f8a4:	48 39 d0             	cmp    %rdx,%rax
  72f8a7:	0f 82 63 ff ff ff    	jb     72f810 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x3d0>
  72f8ad:	4c 89 d2             	mov    %r10,%rdx
  72f8b0:	48 c1 e2 04          	shl    $0x4,%rdx
  72f8b4:	4c 01 e2             	add    %r12,%rdx
  72f8b7:	48 39 d0             	cmp    %rdx,%rax
  72f8ba:	73 31                	jae    72f8ed <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4ad>
  72f8bc:	0f 1f 40 00          	nopl   0x0(%rax)
  72f8c0:	49 8b 34 2c          	mov    (%r12,%rbp,1),%rsi
  72f8c4:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72f8c8:	48 89 df             	mov    %rbx,%rdi
  72f8cb:	48 c1 e7 04          	shl    $0x4,%rdi
  72f8cf:	48 3b 30             	cmp    (%rax),%rsi
  72f8d2:	48 89 ce             	mov    %rcx,%rsi
  72f8d5:	49 0f 43 f7          	cmovae %r15,%rsi
  72f8d9:	0f 10 00             	movups (%rax),%xmm0
  72f8dc:	0f 11 04 3e          	movups %xmm0,(%rsi,%rdi,1)
  72f8e0:	48 83 db ff          	sbb    $0xffffffffffffffff,%rbx
  72f8e4:	48 83 c0 10          	add    $0x10,%rax
  72f8e8:	48 39 d0             	cmp    %rdx,%rax
  72f8eb:	72 d3                	jb     72f8c0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x480>
  72f8ed:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  72f8f2:	4d 39 f2             	cmp    %r14,%r10
  72f8f5:	74 29                	je     72f920 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4e0>
  72f8f7:	48 83 c1 f0          	add    $0xfffffffffffffff0,%rcx
  72f8fb:	48 89 da             	mov    %rbx,%rdx
  72f8fe:	48 c1 e2 04          	shl    $0x4,%rdx
  72f902:	0f 10 00             	movups (%rax),%xmm0
  72f905:	41 0f 11 04 17       	movups %xmm0,(%r15,%rdx,1)
  72f90a:	48 ff c3             	inc    %rbx
  72f90d:	48 83 c0 10          	add    $0x10,%rax
  72f911:	4d 89 f2             	mov    %r14,%r10
  72f914:	e9 d7 fe ff ff       	jmp    72f7f0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x3b0>
  72f919:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  72f920:	48 89 dd             	mov    %rbx,%rbp
  72f923:	48 c1 e5 04          	shl    $0x4,%rbp
  72f927:	4c 89 e7             	mov    %r12,%rdi
  72f92a:	4c 89 fe             	mov    %r15,%rsi
  72f92d:	48 89 ea             	mov    %rbp,%rdx
  72f930:	ff 15 d2 84 3b 00    	call   *0x3b84d2(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  72f936:	4d 89 f5             	mov    %r14,%r13
  72f939:	49 29 dd             	sub    %rbx,%r13
  72f93c:	0f 84 f9 00 00 00    	je     72fa3b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x5fb>
  72f942:	49 8d 3c 2c          	lea    (%r12,%rbp,1),%rdi
  72f946:	48 8d 43 01          	lea    0x1(%rbx),%rax
  72f94a:	49 39 c6             	cmp    %rax,%r14
  72f94d:	75 09                	jne    72f958 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x518>
  72f94f:	31 c0                	xor    %eax,%eax
  72f951:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72f956:	eb 69                	jmp    72f9c1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x581>
  72f958:	4c 89 e9             	mov    %r13,%rcx
  72f95b:	48 83 e1 fe          	and    $0xfffffffffffffffe,%rcx
  72f95f:	49 8d 14 2c          	lea    (%r12,%rbp,1),%rdx
  72f963:	48 83 c2 10          	add    $0x10,%rdx
  72f967:	49 8d 47 f0          	lea    -0x10(%r15),%rax
  72f96b:	4c 8b 54 24 18       	mov    0x18(%rsp),%r10
  72f970:	49 01 c2             	add    %rax,%r10
  72f973:	31 c0                	xor    %eax,%eax
  72f975:	49 b8 fe ff ff ff ff 	movabs $0xffffffffffffffe,%r8
  72f97c:	ff ff 0f 
  72f97f:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  72f984:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72f98b:	00 00 00 00 00 
  72f990:	48 89 c6             	mov    %rax,%rsi
  72f993:	41 0f 10 02          	movups (%r10),%xmm0
  72f997:	0f 11 42 f0          	movups %xmm0,-0x10(%rdx)
  72f99b:	48 83 c0 02          	add    $0x2,%rax
  72f99f:	4c 31 c6             	xor    %r8,%rsi
  72f9a2:	48 c1 e6 04          	shl    $0x4,%rsi
  72f9a6:	41 0f 10 04 31       	movups (%r9,%rsi,1),%xmm0
  72f9ab:	0f 11 02             	movups %xmm0,(%rdx)
  72f9ae:	48 83 c2 20          	add    $0x20,%rdx
  72f9b2:	49 83 c2 e0          	add    $0xffffffffffffffe0,%r10
  72f9b6:	48 39 c1             	cmp    %rax,%rcx
  72f9b9:	75 d5                	jne    72f990 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x550>
  72f9bb:	41 f6 c5 01          	test   $0x1,%r13b
  72f9bf:	74 17                	je     72f9d8 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x598>
  72f9c1:	48 89 c1             	mov    %rax,%rcx
  72f9c4:	48 f7 d1             	not    %rcx
  72f9c7:	48 c1 e1 04          	shl    $0x4,%rcx
  72f9cb:	48 c1 e0 04          	shl    $0x4,%rax
  72f9cf:	41 0f 10 04 09       	movups (%r9,%rcx,1),%xmm0
  72f9d4:	0f 11 04 07          	movups %xmm0,(%rdi,%rax,1)
  72f9d8:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  72f9dd:	48 39 da             	cmp    %rbx,%rdx
  72f9e0:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72f9e5:	0f 82 80 00 00 00    	jb     72fa6b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x62b>
  72f9eb:	49 89 fc             	mov    %rdi,%r12
  72f9ee:	b8 00 00 00 00       	mov    $0x0,%eax
  72f9f3:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  72f9f8:	49 83 fd 21          	cmp    $0x21,%r13
  72f9fc:	8b 5c 24 2c          	mov    0x2c(%rsp),%ebx
  72fa00:	0f 83 85 fa ff ff    	jae    72f48b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x4b>
  72fa06:	e9 5d fa ff ff       	jmp    72f468 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x28>
  72fa0b:	4c 89 e7             	mov    %r12,%rdi
  72fa0e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  72fa13:	4c 89 fa             	mov    %r15,%rdx
  72fa16:	4c 89 f1             	mov    %r14,%rcx
  72fa19:	41 b8 01 00 00 00    	mov    $0x1,%r8d
  72fa1f:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  72fa26:	00 
  72fa27:	e8 14 d6 ff ff       	call   72d040 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapyBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters10filter_map9FilterMapINtB2r_4IterNtNtNtB12_7runtime6scroll11ViewportKeyNtB5b_13ViewportStateENCNvMst_B5d_INtB5d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6A_>
  72fa2c:	48 83 c4 58          	add    $0x58,%rsp
  72fa30:	5b                   	pop    %rbx
  72fa31:	41 5c                	pop    %r12
  72fa33:	41 5d                	pop    %r13
  72fa35:	41 5e                	pop    %r14
  72fa37:	41 5f                	pop    %r15
  72fa39:	5d                   	pop    %rbp
  72fa3a:	c3                   	ret
  72fa3b:	4c 03 64 24 18       	add    0x18(%rsp),%r12
  72fa40:	45 31 ed             	xor    %r13d,%r13d
  72fa43:	4c 89 e7             	mov    %r12,%rdi
  72fa46:	4c 8b 74 24 30       	mov    0x30(%rsp),%r14
  72fa4b:	e9 18 fa ff ff       	jmp    72f468 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable9quicksort9quicksortTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB15_7sort_byNCINvXs1o_NtNtNtB1P_11collections5btree3mapINtB2B_8BTreeMapyB17_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB15_E9from_iterINtNtNtB3B_8adapters10filter_map9FilterMapINtB2B_4IterNtNtNtB1b_7runtime6scroll11ViewportKeyNtB5n_13ViewportStateENCNvMst_B5p_INtB5p_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0EB6M_+0x28>
  72fa50:	0f 0b                	ud2
  72fa52:	48 8d 3d db 9b 93 ff 	lea    -0x6c6425(%rip),%rdi        # 69634 <anon.82a788e7fdd98d311675b83eb91f04ac.0.llvm.15086054616281437909+0x27>
  72fa59:	48 8d 15 88 b9 38 00 	lea    0x38b988(%rip),%rdx        # abb3e8 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x38>
  72fa60:	be 13 00 00 00       	mov    $0x13,%esi
  72fa65:	ff 15 cd 83 3b 00    	call   *0x3b83cd(%rip)        # ae7e38 <_DYNAMIC+0x2a0>
  72fa6b:	48 8d 0d 8e b9 38 00 	lea    0x38b98e(%rip),%rcx        # abb400 <anon.82a788e7fdd98d311675b83eb91f04ac.2.llvm.15086054616281437909+0x50>
  72fa72:	48 89 df             	mov    %rbx,%rdi
  72fa75:	48 89 d6             	mov    %rdx,%rsi
  72fa78:	ff 15 aa 83 3b 00    	call   *0x3b83aa(%rip)        # ae7e28 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
