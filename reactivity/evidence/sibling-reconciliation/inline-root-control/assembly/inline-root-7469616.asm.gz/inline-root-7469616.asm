
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000071fa30 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_>:
  71fa30:	55                   	push   %rbp
  71fa31:	41 57                	push   %r15
  71fa33:	41 56                	push   %r14
  71fa35:	41 55                	push   %r13
  71fa37:	41 54                	push   %r12
  71fa39:	53                   	push   %rbx
  71fa3a:	48 81 ec d8 00 00 00 	sub    $0xd8,%rsp
  71fa41:	49 89 fd             	mov    %rdi,%r13
  71fa44:	48 8b 46 10          	mov    0x10(%rsi),%rax
  71fa48:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  71fa4d:	48 8b 2e             	mov    (%rsi),%rbp
  71fa50:	48 8b 5e 08          	mov    0x8(%rsi),%rbx
  71fa54:	4c 8b 46 18          	mov    0x18(%rsi),%r8
  71fa58:	4c 39 c3             	cmp    %r8,%rbx
  71fa5b:	0f 84 fd 00 00 00    	je     71fb5e <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x12e>
  71fa61:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  71fa66:	4c 8b 6e 20          	mov    0x20(%rsi),%r13
  71fa6a:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
  71fa6f:	4c 8b 35 92 83 3c 00 	mov    0x3c8392(%rip),%r14        # ae7e08 <memcpy@GLIBC_2.14>
  71fa76:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  71fa7b:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  71fa80:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
  71fa85:	4c 89 44 24 38       	mov    %r8,0x38(%rsp)
  71fa8a:	4c 89 6c 24 30       	mov    %r13,0x30(%rsp)
  71fa8f:	eb 58                	jmp    71fae9 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xb9>
  71fa91:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71fa98:	0f 1f 84 00 00 00 00 
  71fa9f:	00 
  71faa0:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  71faa5:	4d 89 65 00          	mov    %r12,0x0(%r13)
  71faa9:	4d 89 7d 08          	mov    %r15,0x8(%r13)
  71faad:	41 88 6d 10          	mov    %bpl,0x10(%r13)
  71fab1:	49 8d 7d 11          	lea    0x11(%r13),%rdi
  71fab5:	ba 97 00 00 00       	mov    $0x97,%edx
  71faba:	48 8d 74 24 41       	lea    0x41(%rsp),%rsi
  71fabf:	41 ff d6             	call   *%r14
  71fac2:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  71fac9:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  71face:	4c 8b 6c 24 30       	mov    0x30(%rsp),%r13
  71fad3:	4c 8b 44 24 38       	mov    0x38(%rsp),%r8
  71fad8:	4c 39 c3             	cmp    %r8,%rbx
  71fadb:	48 8d 7c 24 41       	lea    0x41(%rsp),%rdi
  71fae0:	4c 8b 35 21 83 3c 00 	mov    0x3c8321(%rip),%r14        # ae7e08 <memcpy@GLIBC_2.14>
  71fae7:	74 5c                	je     71fb45 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x115>
  71fae9:	4c 8b 23             	mov    (%rbx),%r12
  71faec:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
  71faf0:	0f b6 6b 10          	movzbl 0x10(%rbx),%ebp
  71faf4:	48 8d 73 11          	lea    0x11(%rbx),%rsi
  71faf8:	ba 97 00 00 00       	mov    $0x97,%edx
  71fafd:	41 ff d6             	call   *%r14
  71fb00:	48 81 c3 a8 00 00 00 	add    $0xa8,%rbx
  71fb07:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  71fb0c:	48 89 58 08          	mov    %rbx,0x8(%rax)
  71fb10:	49 83 fc 02          	cmp    $0x2,%r12
  71fb14:	75 8a                	jne    71faa0 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x70>
  71fb16:	4d 8b 65 10          	mov    0x10(%r13),%r12
  71fb1a:	4d 3b 65 00          	cmp    0x0(%r13),%r12
  71fb1e:	75 08                	jne    71fb28 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xf8>
  71fb20:	4c 89 ef             	mov    %r13,%rdi
  71fb23:	e8 08 67 00 00       	call   726230 <_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecAINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtCshBhuxcId5D0_4gpui6source7FieldIdEj2_E8grow_oneCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71fb28:	49 8b 45 08          	mov    0x8(%r13),%rax
  71fb2c:	4c 89 e1             	mov    %r12,%rcx
  71fb2f:	48 c1 e1 04          	shl    $0x4,%rcx
  71fb33:	4c 89 3c 08          	mov    %r15,(%rax,%rcx,1)
  71fb37:	40 88 6c 08 08       	mov    %bpl,0x8(%rax,%rcx,1)
  71fb3c:	49 ff c4             	inc    %r12
  71fb3f:	4d 89 65 10          	mov    %r12,0x10(%r13)
  71fb43:	eb 8e                	jmp    71fad3 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0xa3>
  71fb45:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  71fb4a:	48 8b 58 08          	mov    0x8(%rax),%rbx
  71fb4e:	4c 8b 40 18          	mov    0x18(%rax),%r8
  71fb52:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  71fb57:	4c 8b 6c 24 20       	mov    0x20(%rsp),%r13
  71fb5c:	eb 05                	jmp    71fb63 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x133>
  71fb5e:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  71fb63:	4c 89 c0             	mov    %r8,%rax
  71fb66:	48 29 d8             	sub    %rbx,%rax
  71fb69:	48 c1 e8 03          	shr    $0x3,%rax
  71fb6d:	48 b9 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rcx
  71fb74:	c3 30 0c 
  71fb77:	48 f7 e1             	mul    %rcx
  71fb7a:	49 39 d8             	cmp    %rbx,%r8
  71fb7d:	74 69                	je     71fbe8 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x1b8>
  71fb7f:	49 89 d4             	mov    %rdx,%r12
  71fb82:	48 81 c3 88 00 00 00 	add    $0x88,%rbx
  71fb89:	4c 8b 35 50 82 3c 00 	mov    0x3c8250(%rip),%r14        # ae7de0 <_DYNAMIC+0x248>
  71fb90:	eb 1a                	jmp    71fbac <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x17c>
  71fb92:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71fb99:	1f 84 00 00 00 00 00 
  71fba0:	48 81 c3 a8 00 00 00 	add    $0xa8,%rbx
  71fba7:	49 ff cc             	dec    %r12
  71fbaa:	74 3c                	je     71fbe8 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x1b8>
  71fbac:	83 bb 78 ff ff ff 02 	cmpl   $0x2,-0x88(%rbx)
  71fbb3:	74 eb                	je     71fba0 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71fbb5:	48 8b 73 90          	mov    -0x70(%rbx),%rsi
  71fbb9:	48 85 f6             	test   %rsi,%rsi
  71fbbc:	74 10                	je     71fbce <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x19e>
  71fbbe:	48 8b 7b 98          	mov    -0x68(%rbx),%rdi
  71fbc2:	48 c1 e6 03          	shl    $0x3,%rsi
  71fbc6:	ba 08 00 00 00       	mov    $0x8,%edx
  71fbcb:	41 ff d6             	call   *%r14
  71fbce:	48 8b 73 f8          	mov    -0x8(%rbx),%rsi
  71fbd2:	48 85 f6             	test   %rsi,%rsi
  71fbd5:	74 c9                	je     71fba0 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71fbd7:	48 8b 3b             	mov    (%rbx),%rdi
  71fbda:	48 c1 e6 05          	shl    $0x5,%rsi
  71fbde:	ba 08 00 00 00       	mov    $0x8,%edx
  71fbe3:	41 ff d6             	call   *%r14
  71fbe6:	eb b8                	jmp    71fba0 <_RINvNtNtCscdodAO9FK5_5alloc3vec16in_place_collect18from_iter_in_placeINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtB4_9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2C_7runtimeINtB3o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0ENtB2A_9ListDraftEB3T_+0x170>
  71fbe8:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  71fbed:	48 29 e9             	sub    %rbp,%rcx
  71fbf0:	48 c1 e9 03          	shr    $0x3,%rcx
  71fbf4:	48 b8 3d cf f3 3c cf 	movabs $0xcf3cf3cf3cf3cf3d,%rax
  71fbfb:	f3 3c cf 
  71fbfe:	48 0f af c1          	imul   %rcx,%rax
  71fc02:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  71fc07:	49 89 4d 00          	mov    %rcx,0x0(%r13)
  71fc0b:	49 89 6d 08          	mov    %rbp,0x8(%r13)
  71fc0f:	49 89 45 10          	mov    %rax,0x10(%r13)
  71fc13:	4c 89 e8             	mov    %r13,%rax
  71fc16:	48 81 c4 d8 00 00 00 	add    $0xd8,%rsp
  71fc1d:	5b                   	pop    %rbx
  71fc1e:	41 5c                	pop    %r12
  71fc20:	41 5d                	pop    %r13
  71fc22:	41 5e                	pop    %r14
  71fc24:	41 5f                	pop    %r15
  71fc26:	5d                   	pop    %rbp
  71fc27:	c3                   	ret
  71fc28:	49 89 c6             	mov    %rax,%r14
  71fc2b:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  71fc30:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  71fc35:	e8 76 f6 ff ff       	call   71f2b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCscdodAO9FK5_5alloc3vec13in_place_drop11InPlaceDropNtNtCshBhuxcId5D0_4gpui4list9ListDraftEECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  71fc3a:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  71fc3f:	e8 6c f7 ff ff       	call   71f3b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_>
  71fc44:	4c 89 f7             	mov    %r14,%rdi
  71fc47:	e8 04 89 39 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
