
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000714ed0 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_>:
  714ed0:	41 57                	push   %r15
  714ed2:	41 56                	push   %r14
  714ed4:	41 54                	push   %r12
  714ed6:	53                   	push   %rbx
  714ed7:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
  714ede:	48 89 fb             	mov    %rdi,%rbx
  714ee1:	48 8b 46 40          	mov    0x40(%rsi),%rax
  714ee5:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  714eec:	00 
  714eed:	0f 10 06             	movups (%rsi),%xmm0
  714ef0:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  714ef4:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  714ef8:	0f 10 5e 30          	movups 0x30(%rsi),%xmm3
  714efc:	0f 29 5c 24 70       	movaps %xmm3,0x70(%rsp)
  714f01:	0f 29 54 24 60       	movaps %xmm2,0x60(%rsp)
  714f06:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  714f0b:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  714f10:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  714f15:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  714f1a:	e8 f1 ee ff ff       	call   713e10 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTyNtNtCshBhuxcId5D0_4gpui4list6ListIdEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters10filter_map9FilterMapINtNtNtNtB6_11collections5btree3map4IterNtNtNtBZ_7runtime6scroll11ViewportKeyNtB3B_13ViewportStateENCNvMst_B3D_INtB3D_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE9from_iterB4Z_>
  714f1f:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  714f24:	4d 85 ff             	test   %r15,%r15
  714f27:	0f 84 af 00 00 00    	je     714fdc <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x10c>
  714f2d:	4c 8b 74 24 20       	mov    0x20(%rsp),%r14
  714f32:	48 8d 44 24 0f       	lea    0xf(%rsp),%rax
  714f37:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  714f3c:	49 83 ff 01          	cmp    $0x1,%r15
  714f40:	0f 85 d5 00 00 00    	jne    71501b <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x14b>
  714f46:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  714f4b:	ff 15 a7 2e 3d 00    	call   *0x3d2ea7(%rip)        # ae7df8 <_DYNAMIC+0x260>
  714f51:	bf c0 00 00 00       	mov    $0xc0,%edi
  714f56:	be 08 00 00 00       	mov    $0x8,%esi
  714f5b:	ff 15 77 2e 3d 00    	call   *0x3d2e77(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  714f61:	48 85 c0             	test   %rax,%rax
  714f64:	0f 84 d1 00 00 00    	je     71503b <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x16b>
  714f6a:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  714f71:	66 c7 80 ba 00 00 00 	movw   $0x0,0xba(%rax)
  714f78:	00 00 
  714f7a:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
  714f81:	00 00 
  714f83:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  714f88:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  714f8f:	00 00 
  714f91:	49 c1 e7 04          	shl    $0x4,%r15
  714f95:	4d 01 f7             	add    %r14,%r15
  714f98:	48 c7 44 24 40 02 00 	movq   $0x2,0x40(%rsp)
  714f9f:	00 00 
  714fa1:	4c 89 74 24 58       	mov    %r14,0x58(%rsp)
  714fa6:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
  714fab:	4c 89 64 24 68       	mov    %r12,0x68(%rsp)
  714fb0:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  714fb5:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  714fba:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  714fbf:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  714fc4:	e8 77 56 fd ff       	call   6ea640 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6appendINtNtB5_4node7NodeRefNtNtBV_6marker5OwnedjNtNtCshBhuxcId5D0_4gpui4list6ListIdNtB1f_14LeafOrInternalE9bulk_pushINtNtB5_17dedup_sorted_iter15DedupSortedIterjB1y_INtNtNtB9_3vec9into_iter8IntoIterTjB1y_EEENtNtB9_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  714fc9:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
  714fce:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  714fd3:	0f 11 03             	movups %xmm0,(%rbx)
  714fd6:	48 89 43 10          	mov    %rax,0x10(%rbx)
  714fda:	eb 2d                	jmp    715009 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x139>
  714fdc:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  714fe3:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  714fea:	00 
  714feb:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  714ff0:	48 85 f6             	test   %rsi,%rsi
  714ff3:	74 14                	je     715009 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x139>
  714ff5:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  714ffa:	48 c1 e6 04          	shl    $0x4,%rsi
  714ffe:	ba 08 00 00 00       	mov    $0x8,%edx
  715003:	ff 15 d7 2d 3d 00    	call   *0x3d2dd7(%rip)        # ae7de0 <_DYNAMIC+0x248>
  715009:	48 89 d8             	mov    %rbx,%rax
  71500c:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
  715013:	5b                   	pop    %rbx
  715014:	41 5c                	pop    %r12
  715016:	41 5e                	pop    %r14
  715018:	41 5f                	pop    %r15
  71501a:	c3                   	ret
  71501b:	49 83 ff 15          	cmp    $0x15,%r15
  71501f:	73 2c                	jae    71504d <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x17d>
  715021:	48 8d 4c 24 40       	lea    0x40(%rsp),%rcx
  715026:	ba 01 00 00 00       	mov    $0x1,%edx
  71502b:	4c 89 f7             	mov    %r14,%rdi
  71502e:	4c 89 fe             	mov    %r15,%rsi
  715031:	e8 3a c3 ff ff       	call   711370 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB26_11collections5btree3mapINtB2S_8BTreeMapjB1o_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtNtB3S_8adapters3map3MapINtNtB8_4iter4IterNtB1q_9ListDraftENCNvMst_NtB1s_7runtimeINtB5T_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6o_>
  715036:	e9 0b ff ff ff       	jmp    714f46 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x76>
  71503b:	bf 08 00 00 00       	mov    $0x8,%edi
  715040:	be c0 00 00 00       	mov    $0xc0,%esi
  715045:	ff 15 c5 2d 3d 00    	call   *0x3d2dc5(%rip)        # ae7e10 <_DYNAMIC+0x278>
  71504b:	0f 0b                	ud2
  71504d:	48 8d 54 24 40       	lea    0x40(%rsp),%rdx
  715052:	4c 89 f7             	mov    %r14,%rdi
  715055:	4c 89 fe             	mov    %r15,%rsi
  715058:	e8 83 90 01 00       	call   72e0e0 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTyNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapyB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters10filter_map9FilterMapINtB2u_4IterNtNtNtB15_7runtime6scroll11ViewportKeyNtB5f_13ViewportStateENCNvMst_B5h_INtB5h_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EE0E0INtNtB1J_3vec3VecBZ_EEB6E_>
  71505d:	e9 e4 fe ff ff       	jmp    714f46 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x76>
  715062:	48 89 c3             	mov    %rax,%rbx
  715065:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  71506a:	eb 03                	jmp    71506f <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x19f>
  71506c:	48 89 c3             	mov    %rax,%rbx
  71506f:	4d 85 e4             	test   %r12,%r12
  715072:	74 15                	je     715089 <_RINvXs1o_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB7_8BTreeMapyNtNtCshBhuxcId5D0_4gpui4list6ListIdEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratorTyB19_EE9from_iterINtNtNtB1Q_8adapters10filter_map9FilterMapINtB7_4IterNtNtNtB1d_7runtime6scroll11ViewportKeyNtB3U_13ViewportStateENCNvMst_B3W_INtB3W_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersd_0EEB5j_+0x1b9>
  715074:	49 c1 e4 04          	shl    $0x4,%r12
  715078:	ba 08 00 00 00       	mov    $0x8,%edx
  71507d:	4c 89 f7             	mov    %r14,%rdi
  715080:	4c 89 e6             	mov    %r12,%rsi
  715083:	ff 15 57 2d 3d 00    	call   *0x3d2d57(%rip)        # ae7de0 <_DYNAMIC+0x248>
  715089:	48 89 df             	mov    %rbx,%rdi
  71508c:	e8 bf 34 3a 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
