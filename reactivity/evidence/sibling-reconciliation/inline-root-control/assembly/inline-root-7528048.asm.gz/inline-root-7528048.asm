
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000072de70 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_>:
  72de70:	55                   	push   %rbp
  72de71:	41 57                	push   %r15
  72de73:	41 56                	push   %r14
  72de75:	41 55                	push   %r13
  72de77:	41 54                	push   %r12
  72de79:	53                   	push   %rbx
  72de7a:	48 81 ec 00 10 00 00 	sub    $0x1000,%rsp
  72de81:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
  72de88:	00 
  72de89:	50                   	push   %rax
  72de8a:	49 89 d6             	mov    %rdx,%r14
  72de8d:	48 89 f1             	mov    %rsi,%rcx
  72de90:	48 d1 e9             	shr    $1,%rcx
  72de93:	48 89 f0             	mov    %rsi,%rax
  72de96:	48 29 c8             	sub    %rcx,%rax
  72de99:	48 81 fe 20 a1 07 00 	cmp    $0x7a120,%rsi
  72dea0:	bb 20 a1 07 00       	mov    $0x7a120,%ebx
  72dea5:	48 0f 42 de          	cmovb  %rsi,%rbx
  72dea9:	48 39 c3             	cmp    %rax,%rbx
  72deac:	48 0f 46 d8          	cmovbe %rax,%rbx
  72deb0:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  72deb7:	73 0c                	jae    72dec5 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x55>
  72deb9:	4c 8d 7c 24 08       	lea    0x8(%rsp),%r15
  72debe:	b9 00 01 00 00       	mov    $0x100,%ecx
  72dec3:	eb 62                	jmp    72df27 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0xb7>
  72dec5:	49 89 dc             	mov    %rbx,%r12
  72dec8:	49 c1 e4 04          	shl    $0x4,%r12
  72decc:	48 c1 e8 3c          	shr    $0x3c,%rax
  72ded0:	0f 95 c0             	setne  %al
  72ded3:	48 b9 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rcx
  72deda:	ff ff 7f 
  72dedd:	49 39 cc             	cmp    %rcx,%r12
  72dee0:	0f 97 c1             	seta   %cl
  72dee3:	08 c1                	or     %al,%cl
  72dee5:	74 0f                	je     72def6 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x86>
  72dee7:	45 31 ed             	xor    %r13d,%r13d
  72deea:	4c 89 ef             	mov    %r13,%rdi
  72deed:	4c 89 e6             	mov    %r12,%rsi
  72def0:	ff 15 ca 9f 3b 00    	call   *0x3b9fca(%rip)        # ae7ec0 <_DYNAMIC+0x328>
  72def6:	49 89 f7             	mov    %rsi,%r15
  72def9:	48 89 fd             	mov    %rdi,%rbp
  72defc:	ff 15 f6 9e 3b 00    	call   *0x3b9ef6(%rip)        # ae7df8 <_DYNAMIC+0x260>
  72df02:	41 bd 08 00 00 00    	mov    $0x8,%r13d
  72df08:	be 08 00 00 00       	mov    $0x8,%esi
  72df0d:	4c 89 e7             	mov    %r12,%rdi
  72df10:	ff 15 c2 9e 3b 00    	call   *0x3b9ec2(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  72df16:	48 89 ef             	mov    %rbp,%rdi
  72df19:	4c 89 fe             	mov    %r15,%rsi
  72df1c:	49 89 c7             	mov    %rax,%r15
  72df1f:	48 89 d9             	mov    %rbx,%rcx
  72df22:	48 85 c0             	test   %rax,%rax
  72df25:	74 c3                	je     72deea <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x7a>
  72df27:	45 31 c0             	xor    %r8d,%r8d
  72df2a:	48 83 fe 41          	cmp    $0x41,%rsi
  72df2e:	41 0f 92 c0          	setb   %r8b
  72df32:	4c 89 fa             	mov    %r15,%rdx
  72df35:	4d 89 f1             	mov    %r14,%r9
  72df38:	e8 43 e4 ff ff       	call   72c380 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable5drift4sortTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBW_7sort_byNCINvXs1o_NtNtNtB1G_11collections5btree3mapINtB2r_8BTreeMapjBY_EINtNtNtNtBa_4iter6traits7collect12FromIteratorBW_E9from_iterINtNtNtB3q_8adapters3map3MapINtNtB8_4iter4IterNtB10_9ListDraftENCNvMst_NtB12_7runtimeINtB5q_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB5V_>
  72df3d:	48 81 fb 00 01 00 00 	cmp    $0x100,%rbx
  72df44:	76 15                	jbe    72df5b <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0xeb>
  72df46:	48 c1 e3 04          	shl    $0x4,%rbx
  72df4a:	ba 08 00 00 00       	mov    $0x8,%edx
  72df4f:	4c 89 ff             	mov    %r15,%rdi
  72df52:	48 89 de             	mov    %rbx,%rsi
  72df55:	ff 15 85 9e 3b 00    	call   *0x3b9e85(%rip)        # ae7de0 <_DYNAMIC+0x248>
  72df5b:	48 81 c4 08 10 00 00 	add    $0x1008,%rsp
  72df62:	5b                   	pop    %rbx
  72df63:	41 5c                	pop    %r12
  72df65:	41 5d                	pop    %r13
  72df67:	41 5e                	pop    %r14
  72df69:	41 5f                	pop    %r15
  72df6b:	5d                   	pop    %rbp
  72df6c:	c3                   	ret
  72df6d:	49 89 c6             	mov    %rax,%r14
  72df70:	48 81 fb 01 01 00 00 	cmp    $0x101,%rbx
  72df77:	73 08                	jae    72df81 <_RINvNtNtNtCs4NRVxsYgnAr_4core5slice4sort6stable14driftsort_mainTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1J_11collections5btree3mapINtB2u_8BTreeMapjB11_EINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB3u_8adapters3map3MapINtNtB6_4iter4IterNtB13_9ListDraftENCNvMst_NtB15_7runtimeINtB5u_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0INtNtB1J_3vec3VecBZ_EEB5Z_+0x111>
  72df79:	4c 89 f7             	mov    %r14,%rdi
  72df7c:	e8 cf a5 38 00       	call   ab8550 <_Unwind_Resume@plt>
  72df81:	48 c1 e3 04          	shl    $0x4,%rbx
  72df85:	ba 08 00 00 00       	mov    $0x8,%edx
  72df8a:	4c 89 ff             	mov    %r15,%rdi
  72df8d:	48 89 de             	mov    %rbx,%rsi
  72df90:	ff 15 4a 9e 3b 00    	call   *0x3b9e4a(%rip)        # ae7de0 <_DYNAMIC+0x248>
  72df96:	4c 89 f7             	mov    %r14,%rdi
  72df99:	e8 b2 a5 38 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
