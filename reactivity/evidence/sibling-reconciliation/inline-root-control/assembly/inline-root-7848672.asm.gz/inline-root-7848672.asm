
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000077c2e0 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children>:
  77c2e0:	50                   	push   %rax
  77c2e1:	48 8b 07             	mov    (%rdi),%rax
  77c2e4:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  77c2eb:	00 00 80 
  77c2ee:	48 31 c1             	xor    %rax,%rcx
  77c2f1:	48 85 c0             	test   %rax,%rax
  77c2f4:	ba 02 00 00 00       	mov    $0x2,%edx
  77c2f9:	48 0f 48 d1          	cmovs  %rcx,%rdx
  77c2fd:	b8 04 00 00 00       	mov    $0x4,%eax
  77c302:	48 85 d2             	test   %rdx,%rdx
  77c305:	74 6e                	je     77c375 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0x95>
  77c307:	48 83 fa 01          	cmp    $0x1,%rdx
  77c30b:	75 15                	jne    77c322 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0x42>
  77c30d:	31 d2                	xor    %edx,%edx
  77c30f:	83 fe ff             	cmp    $0xffffffff,%esi
  77c312:	0f 94 c2             	sete   %dl
  77c315:	48 8d 0d 08 76 8e ff 	lea    -0x7189f8(%rip),%rcx        # 63924 <anon.079f5e587c394fcac2765eb4d0cf0bc2.312.llvm.6319143315422321905+0x3c>
  77c31c:	48 0f 44 c1          	cmove  %rcx,%rax
  77c320:	59                   	pop    %rcx
  77c321:	c3                   	ret
  77c322:	4c 8b 47 10          	mov    0x10(%rdi),%r8
  77c326:	4d 85 c0             	test   %r8,%r8
  77c329:	74 4c                	je     77c377 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0x97>
  77c32b:	4c 89 c1             	mov    %r8,%rcx
  77c32e:	48 d1 e9             	shr    $1,%rcx
  77c331:	4c 8d 51 01          	lea    0x1(%rcx),%r10
  77c335:	41 89 f1             	mov    %esi,%r9d
  77c338:	49 ff c1             	inc    %r9
  77c33b:	31 d2                	xor    %edx,%edx
  77c33d:	83 fe ff             	cmp    $0xffffffff,%esi
  77c340:	4c 0f 44 ca          	cmove  %rdx,%r9
  77c344:	49 8d 71 02          	lea    0x2(%r9),%rsi
  77c348:	4c 39 d6             	cmp    %r10,%rsi
  77c34b:	77 28                	ja     77c375 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0x95>
  77c34d:	48 8b 47 08          	mov    0x8(%rdi),%rax
  77c351:	4d 29 d0             	sub    %r10,%r8
  77c354:	42 8b 3c 88          	mov    (%rax,%r9,4),%edi
  77c358:	42 8b 54 88 04       	mov    0x4(%rax,%r9,4),%edx
  77c35d:	39 fa                	cmp    %edi,%edx
  77c35f:	72 2f                	jb     77c390 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0xb0>
  77c361:	49 39 d0             	cmp    %rdx,%r8
  77c364:	72 2a                	jb     77c390 <_RNvMNtNtCshBhuxcId5D0_4gpui7runtime8siblingsNtB2_8Siblings8children+0xb0>
  77c366:	48 8d 04 88          	lea    (%rax,%rcx,4),%rax
  77c36a:	48 83 c0 04          	add    $0x4,%rax
  77c36e:	48 29 fa             	sub    %rdi,%rdx
  77c371:	48 8d 04 b8          	lea    (%rax,%rdi,4),%rax
  77c375:	59                   	pop    %rcx
  77c376:	c3                   	ret
  77c377:	48 8d 3d 4e 1c 8f ff 	lea    -0x70e3b2(%rip),%rdi        # 6dfcc <anon.f12d40f2b0f13288e08d9440d61987ca.25.llvm.2097837586694663591+0x1c0>
  77c37e:	48 8d 15 43 4b 34 00 	lea    0x344b43(%rip),%rdx        # ac0ec8 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0xa0>
  77c385:	be 13 00 00 00       	mov    $0x13,%esi
  77c38a:	ff 15 a8 ba 36 00    	call   *0x36baa8(%rip)        # ae7e38 <_DYNAMIC+0x2a0>
  77c390:	48 8d 0d 49 4b 34 00 	lea    0x344b49(%rip),%rcx        # ac0ee0 <anon.f12d40f2b0f13288e08d9440d61987ca.26.llvm.2097837586694663591+0xb8>
  77c397:	48 89 d6             	mov    %rdx,%rsi
  77c39a:	4c 89 c2             	mov    %r8,%rdx
  77c39d:	ff 15 85 ba 36 00    	call   *0x36ba85(%rip)        # ae7e28 <_DYNAMIC+0x290>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
