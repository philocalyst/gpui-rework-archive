
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000710960 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_>:
  710960:	55                   	push   %rbp
  710961:	41 57                	push   %r15
  710963:	41 56                	push   %r14
  710965:	41 55                	push   %r13
  710967:	41 54                	push   %r12
  710969:	53                   	push   %rbx
  71096a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
  710971:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  710976:	48 83 fe 02          	cmp    $0x2,%rsi
  71097a:	0f 82 2e 06 00 00    	jb     710fae <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x64e>
  710980:	49 89 f5             	mov    %rsi,%r13
  710983:	48 83 fe 20          	cmp    $0x20,%rsi
  710987:	0f 87 6c 06 00 00    	ja     710ff9 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x699>
  71098d:	4d 89 ec             	mov    %r13,%r12
  710990:	49 d1 ec             	shr    $1,%r12
  710993:	49 83 fd 12          	cmp    $0x12,%r13
  710997:	4c 89 e2             	mov    %r12,%rdx
  71099a:	49 0f 42 d5          	cmovb  %r13,%rdx
  71099e:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
  7109a3:	4f 8d 3c a0          	lea    (%r8,%r12,4),%r15
  7109a7:	4c 89 e8             	mov    %r13,%rax
  7109aa:	4c 29 e0             	sub    %r12,%rax
  7109ad:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  7109b2:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
  7109b7:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
  7109bc:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  7109c1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7109c8:	0f 1f 84 00 00 00 00 
  7109cf:	00 
  7109d0:	48 83 fa 0c          	cmp    $0xc,%rdx
  7109d4:	0f 86 f6 02 00 00    	jbe    710cd0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x370>
  7109da:	41 8b 40 30          	mov    0x30(%r8),%eax
  7109de:	45 8b 30             	mov    (%r8),%r14d
  7109e1:	41 8b 48 04          	mov    0x4(%r8),%ecx
  7109e5:	44 39 f0             	cmp    %r14d,%eax
  7109e8:	44 89 f6             	mov    %r14d,%esi
  7109eb:	0f 47 f0             	cmova  %eax,%esi
  7109ee:	44 0f 42 f0          	cmovb  %eax,%r14d
  7109f2:	41 8b 40 28          	mov    0x28(%r8),%eax
  7109f6:	39 c8                	cmp    %ecx,%eax
  7109f8:	41 89 cf             	mov    %ecx,%r15d
  7109fb:	44 0f 47 f8          	cmova  %eax,%r15d
  7109ff:	0f 42 c8             	cmovb  %eax,%ecx
  710a02:	41 8b 40 24          	mov    0x24(%r8),%eax
  710a06:	41 8b 68 08          	mov    0x8(%r8),%ebp
  710a0a:	39 e8                	cmp    %ebp,%eax
  710a0c:	41 89 ec             	mov    %ebp,%r12d
  710a0f:	44 0f 47 e0          	cmova  %eax,%r12d
  710a13:	0f 42 e8             	cmovb  %eax,%ebp
  710a16:	41 8b 40 1c          	mov    0x1c(%r8),%eax
  710a1a:	41 8b 58 0c          	mov    0xc(%r8),%ebx
  710a1e:	39 d8                	cmp    %ebx,%eax
  710a20:	41 89 da             	mov    %ebx,%r10d
  710a23:	44 0f 47 d0          	cmova  %eax,%r10d
  710a27:	0f 42 d8             	cmovb  %eax,%ebx
  710a2a:	41 8b 40 2c          	mov    0x2c(%r8),%eax
  710a2e:	41 8b 78 14          	mov    0x14(%r8),%edi
  710a32:	39 f8                	cmp    %edi,%eax
  710a34:	41 89 fd             	mov    %edi,%r13d
  710a37:	44 0f 47 e8          	cmova  %eax,%r13d
  710a3b:	0f 42 f8             	cmovb  %eax,%edi
  710a3e:	89 7c 24 04          	mov    %edi,0x4(%rsp)
  710a42:	41 8b 40 20          	mov    0x20(%r8),%eax
  710a46:	45 8b 58 18          	mov    0x18(%r8),%r11d
  710a4a:	44 39 d8             	cmp    %r11d,%eax
  710a4d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  710a52:	44 89 da             	mov    %r11d,%edx
  710a55:	0f 47 d0             	cmova  %eax,%edx
  710a58:	44 0f 42 d8          	cmovb  %eax,%r11d
  710a5c:	41 39 cb             	cmp    %ecx,%r11d
  710a5f:	41 89 c9             	mov    %ecx,%r9d
  710a62:	45 0f 47 cb          	cmova  %r11d,%r9d
  710a66:	44 0f 43 d9          	cmovae %ecx,%r11d
  710a6a:	39 eb                	cmp    %ebp,%ebx
  710a6c:	89 e9                	mov    %ebp,%ecx
  710a6e:	0f 47 cb             	cmova  %ebx,%ecx
  710a71:	0f 43 dd             	cmovae %ebp,%ebx
  710a74:	41 8b 40 10          	mov    0x10(%r8),%eax
  710a78:	41 39 c5             	cmp    %eax,%r13d
  710a7b:	89 c5                	mov    %eax,%ebp
  710a7d:	41 0f 47 ed          	cmova  %r13d,%ebp
  710a81:	44 0f 43 e8          	cmovae %eax,%r13d
  710a85:	45 39 d4             	cmp    %r10d,%r12d
  710a88:	44 89 d0             	mov    %r10d,%eax
  710a8b:	41 0f 47 c4          	cmova  %r12d,%eax
  710a8f:	45 0f 42 d4          	cmovb  %r12d,%r10d
  710a93:	41 39 d7             	cmp    %edx,%r15d
  710a96:	41 89 d4             	mov    %edx,%r12d
  710a99:	45 0f 47 e7          	cmova  %r15d,%r12d
  710a9d:	41 0f 42 d7          	cmovb  %r15d,%edx
  710aa1:	45 39 f5             	cmp    %r14d,%r13d
  710aa4:	44 89 f7             	mov    %r14d,%edi
  710aa7:	41 0f 47 fd          	cmova  %r13d,%edi
  710aab:	45 0f 43 ee          	cmovae %r14d,%r13d
  710aaf:	44 39 db             	cmp    %r11d,%ebx
  710ab2:	45 89 de             	mov    %r11d,%r14d
  710ab5:	44 0f 47 f3          	cmova  %ebx,%r14d
  710ab9:	44 89 34 24          	mov    %r14d,(%rsp)
  710abd:	41 0f 43 db          	cmovae %r11d,%ebx
  710ac1:	41 39 c9             	cmp    %ecx,%r9d
  710ac4:	41 89 cf             	mov    %ecx,%r15d
  710ac7:	45 0f 47 f9          	cmova  %r9d,%r15d
  710acb:	41 0f 42 c9          	cmovb  %r9d,%ecx
  710acf:	44 39 d2             	cmp    %r10d,%edx
  710ad2:	45 89 d1             	mov    %r10d,%r9d
  710ad5:	44 0f 47 ca          	cmova  %edx,%r9d
  710ad9:	41 0f 43 d2          	cmovae %r10d,%edx
  710add:	41 39 c4             	cmp    %eax,%r12d
  710ae0:	41 89 c6             	mov    %eax,%r14d
  710ae3:	45 0f 47 f4          	cmova  %r12d,%r14d
  710ae7:	44 0f 43 e0          	cmovae %eax,%r12d
  710aeb:	39 ee                	cmp    %ebp,%esi
  710aed:	41 89 ea             	mov    %ebp,%r10d
  710af0:	44 0f 47 d6          	cmova  %esi,%r10d
  710af4:	0f 42 ee             	cmovb  %esi,%ebp
  710af7:	41 39 ff             	cmp    %edi,%r15d
  710afa:	89 fe                	mov    %edi,%esi
  710afc:	41 0f 47 f7          	cmova  %r15d,%esi
  710b00:	44 0f 43 ff          	cmovae %edi,%r15d
  710b04:	8b 44 24 04          	mov    0x4(%rsp),%eax
  710b08:	41 39 c4             	cmp    %eax,%r12d
  710b0b:	41 89 c3             	mov    %eax,%r11d
  710b0e:	45 0f 47 dc          	cmova  %r12d,%r11d
  710b12:	44 0f 43 e0          	cmovae %eax,%r12d
  710b16:	44 39 cd             	cmp    %r9d,%ebp
  710b19:	44 89 c8             	mov    %r9d,%eax
  710b1c:	0f 47 c5             	cmova  %ebp,%eax
  710b1f:	41 0f 43 e9          	cmovae %r9d,%ebp
  710b23:	45 39 f2             	cmp    %r14d,%r10d
  710b26:	44 89 f7             	mov    %r14d,%edi
  710b29:	41 0f 47 fa          	cmova  %r10d,%edi
  710b2d:	89 7c 24 04          	mov    %edi,0x4(%rsp)
  710b31:	45 0f 43 d6          	cmovae %r14d,%r10d
  710b35:	45 39 ec             	cmp    %r13d,%r12d
  710b38:	45 89 ee             	mov    %r13d,%r14d
  710b3b:	45 0f 47 f4          	cmova  %r12d,%r14d
  710b3f:	45 0f 43 e5          	cmovae %r13d,%r12d
  710b43:	39 cd                	cmp    %ecx,%ebp
  710b45:	89 cf                	mov    %ecx,%edi
  710b47:	0f 47 fd             	cmova  %ebp,%edi
  710b4a:	0f 43 e9             	cmovae %ecx,%ebp
  710b4d:	44 39 fa             	cmp    %r15d,%edx
  710b50:	45 89 fd             	mov    %r15d,%r13d
  710b53:	44 0f 47 ea          	cmova  %edx,%r13d
  710b57:	44 0f 42 fa          	cmovb  %edx,%r15d
  710b5b:	39 f0                	cmp    %esi,%eax
  710b5d:	41 89 f1             	mov    %esi,%r9d
  710b60:	44 0f 47 c8          	cmova  %eax,%r9d
  710b64:	0f 43 c6             	cmovae %esi,%eax
  710b67:	45 39 da             	cmp    %r11d,%r10d
  710b6a:	44 89 da             	mov    %r11d,%edx
  710b6d:	41 0f 47 d2          	cmova  %r10d,%edx
  710b71:	45 0f 43 d3          	cmovae %r11d,%r10d
  710b75:	44 39 e3             	cmp    %r12d,%ebx
  710b78:	45 89 e3             	mov    %r12d,%r11d
  710b7b:	44 0f 47 db          	cmova  %ebx,%r11d
  710b7f:	44 0f 42 e3          	cmovb  %ebx,%r12d
  710b83:	8b 34 24             	mov    (%rsp),%esi
  710b86:	41 39 f6             	cmp    %esi,%r14d
  710b89:	89 f1                	mov    %esi,%ecx
  710b8b:	41 0f 47 ce          	cmova  %r14d,%ecx
  710b8f:	44 0f 43 f6          	cmovae %esi,%r14d
  710b93:	41 39 c2             	cmp    %eax,%r10d
  710b96:	89 c6                	mov    %eax,%esi
  710b98:	41 0f 47 f2          	cmova  %r10d,%esi
  710b9c:	44 0f 43 d0          	cmovae %eax,%r10d
  710ba0:	44 39 ef             	cmp    %r13d,%edi
  710ba3:	44 89 e8             	mov    %r13d,%eax
  710ba6:	0f 47 c7             	cmova  %edi,%eax
  710ba9:	44 0f 42 ef          	cmovb  %edi,%r13d
  710bad:	41 39 d1             	cmp    %edx,%r9d
  710bb0:	89 d7                	mov    %edx,%edi
  710bb2:	41 0f 47 f9          	cmova  %r9d,%edi
  710bb6:	89 3c 24             	mov    %edi,(%rsp)
  710bb9:	41 0f 42 d1          	cmovb  %r9d,%edx
  710bbd:	44 39 dd             	cmp    %r11d,%ebp
  710bc0:	45 89 d9             	mov    %r11d,%r9d
  710bc3:	44 0f 47 cd          	cmova  %ebp,%r9d
  710bc7:	44 0f 42 dd          	cmovb  %ebp,%r11d
  710bcb:	45 39 f7             	cmp    %r14d,%r15d
  710bce:	44 89 f3             	mov    %r14d,%ebx
  710bd1:	41 0f 47 df          	cmova  %r15d,%ebx
  710bd5:	45 0f 42 f7          	cmovb  %r15d,%r14d
  710bd9:	41 39 ca             	cmp    %ecx,%r10d
  710bdc:	89 cf                	mov    %ecx,%edi
  710bde:	41 0f 47 fa          	cmova  %r10d,%edi
  710be2:	44 0f 43 d1          	cmovae %ecx,%r10d
  710be6:	39 f2                	cmp    %esi,%edx
  710be8:	89 f5                	mov    %esi,%ebp
  710bea:	0f 47 ea             	cmova  %edx,%ebp
  710bed:	0f 43 d6             	cmovae %esi,%edx
  710bf0:	45 39 de             	cmp    %r11d,%r14d
  710bf3:	45 89 df             	mov    %r11d,%r15d
  710bf6:	45 0f 47 fe          	cmova  %r14d,%r15d
  710bfa:	45 0f 43 f3          	cmovae %r11d,%r14d
  710bfe:	44 39 cb             	cmp    %r9d,%ebx
  710c01:	45 89 cb             	mov    %r9d,%r11d
  710c04:	44 0f 47 db          	cmova  %ebx,%r11d
  710c08:	8b 4c 24 04          	mov    0x4(%rsp),%ecx
  710c0c:	41 89 48 30          	mov    %ecx,0x30(%r8)
  710c10:	41 0f 43 d9          	cmovae %r9d,%ebx
  710c14:	45 39 d5             	cmp    %r10d,%r13d
  710c17:	45 89 d1             	mov    %r10d,%r9d
  710c1a:	45 0f 47 cd          	cmova  %r13d,%r9d
  710c1e:	45 89 20             	mov    %r12d,(%r8)
  710c21:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  710c26:	45 0f 42 d5          	cmovb  %r13d,%r10d
  710c2a:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  710c2f:	39 f8                	cmp    %edi,%eax
  710c31:	89 f9                	mov    %edi,%ecx
  710c33:	0f 47 c8             	cmova  %eax,%ecx
  710c36:	8b 34 24             	mov    (%rsp),%esi
  710c39:	41 89 70 2c          	mov    %esi,0x2c(%r8)
  710c3d:	0f 42 f8             	cmovb  %eax,%edi
  710c40:	44 39 fb             	cmp    %r15d,%ebx
  710c43:	44 89 fe             	mov    %r15d,%esi
  710c46:	0f 47 f3             	cmova  %ebx,%esi
  710c49:	41 89 68 28          	mov    %ebp,0x28(%r8)
  710c4d:	41 0f 43 df          	cmovae %r15d,%ebx
  710c51:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  710c56:	45 39 da             	cmp    %r11d,%r10d
  710c59:	44 89 d8             	mov    %r11d,%eax
  710c5c:	41 0f 47 c2          	cmova  %r10d,%eax
  710c60:	45 89 70 04          	mov    %r14d,0x4(%r8)
  710c64:	45 0f 43 d3          	cmovae %r11d,%r10d
  710c68:	41 39 f9             	cmp    %edi,%r9d
  710c6b:	41 89 fb             	mov    %edi,%r11d
  710c6e:	45 0f 47 d9          	cmova  %r9d,%r11d
  710c72:	41 89 58 08          	mov    %ebx,0x8(%r8)
  710c76:	41 0f 42 f9          	cmovb  %r9d,%edi
  710c7a:	39 ca                	cmp    %ecx,%edx
  710c7c:	41 89 c9             	mov    %ecx,%r9d
  710c7f:	44 0f 47 ca          	cmova  %edx,%r9d
  710c83:	45 89 58 1c          	mov    %r11d,0x1c(%r8)
  710c87:	0f 42 ca             	cmovb  %edx,%ecx
  710c8a:	41 39 f2             	cmp    %esi,%r10d
  710c8d:	89 f2                	mov    %esi,%edx
  710c8f:	41 0f 47 d2          	cmova  %r10d,%edx
  710c93:	41 89 48 20          	mov    %ecx,0x20(%r8)
  710c97:	44 0f 43 d6          	cmovae %esi,%r10d
  710c9b:	39 c7                	cmp    %eax,%edi
  710c9d:	89 c1                	mov    %eax,%ecx
  710c9f:	0f 47 cf             	cmova  %edi,%ecx
  710ca2:	45 89 48 24          	mov    %r9d,0x24(%r8)
  710ca6:	45 89 50 0c          	mov    %r10d,0xc(%r8)
  710caa:	0f 43 f8             	cmovae %eax,%edi
  710cad:	41 89 50 10          	mov    %edx,0x10(%r8)
  710cb1:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  710cb6:	41 89 78 14          	mov    %edi,0x14(%r8)
  710cba:	41 89 48 18          	mov    %ecx,0x18(%r8)
  710cbe:	b9 0d 00 00 00       	mov    $0xd,%ecx
  710cc3:	e9 ae 01 00 00       	jmp    710e76 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x516>
  710cc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  710ccf:	00 
  710cd0:	b9 01 00 00 00       	mov    $0x1,%ecx
  710cd5:	48 83 fa 08          	cmp    $0x8,%rdx
  710cd9:	0f 86 97 01 00 00    	jbe    710e76 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x516>
  710cdf:	41 8b 40 0c          	mov    0xc(%r8),%eax
  710ce3:	45 8b 08             	mov    (%r8),%r9d
  710ce6:	41 8b 48 04          	mov    0x4(%r8),%ecx
  710cea:	44 39 c8             	cmp    %r9d,%eax
  710ced:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  710cf2:	44 89 ca             	mov    %r9d,%edx
  710cf5:	0f 47 d0             	cmova  %eax,%edx
  710cf8:	44 0f 42 c8          	cmovb  %eax,%r9d
  710cfc:	41 8b 40 1c          	mov    0x1c(%r8),%eax
  710d00:	39 c8                	cmp    %ecx,%eax
  710d02:	89 cf                	mov    %ecx,%edi
  710d04:	0f 47 f8             	cmova  %eax,%edi
  710d07:	0f 42 c8             	cmovb  %eax,%ecx
  710d0a:	41 8b 40 14          	mov    0x14(%r8),%eax
  710d0e:	45 8b 58 08          	mov    0x8(%r8),%r11d
  710d12:	44 39 d8             	cmp    %r11d,%eax
  710d15:	45 89 da             	mov    %r11d,%r10d
  710d18:	44 0f 47 d0          	cmova  %eax,%r10d
  710d1c:	44 0f 42 d8          	cmovb  %eax,%r11d
  710d20:	41 8b 58 20          	mov    0x20(%r8),%ebx
  710d24:	41 8b 70 10          	mov    0x10(%r8),%esi
  710d28:	39 f3                	cmp    %esi,%ebx
  710d2a:	89 f0                	mov    %esi,%eax
  710d2c:	0f 47 c3             	cmova  %ebx,%eax
  710d2f:	0f 42 f3             	cmovb  %ebx,%esi
  710d32:	44 39 cf             	cmp    %r9d,%edi
  710d35:	44 89 cb             	mov    %r9d,%ebx
  710d38:	0f 47 df             	cmova  %edi,%ebx
  710d3b:	41 0f 43 f9          	cmovae %r9d,%edi
  710d3f:	44 39 de             	cmp    %r11d,%esi
  710d42:	44 89 dd             	mov    %r11d,%ebp
  710d45:	0f 47 ee             	cmova  %esi,%ebp
  710d48:	41 0f 43 f3          	cmovae %r11d,%esi
  710d4c:	39 d0                	cmp    %edx,%eax
  710d4e:	41 89 d3             	mov    %edx,%r11d
  710d51:	44 0f 47 d8          	cmova  %eax,%r11d
  710d55:	0f 43 c2             	cmovae %edx,%eax
  710d58:	41 8b 50 18          	mov    0x18(%r8),%edx
  710d5c:	44 39 d2             	cmp    %r10d,%edx
  710d5f:	45 89 d1             	mov    %r10d,%r9d
  710d62:	44 0f 47 ca          	cmova  %edx,%r9d
  710d66:	44 0f 42 d2          	cmovb  %edx,%r10d
  710d6a:	39 fe                	cmp    %edi,%esi
  710d6c:	89 fa                	mov    %edi,%edx
  710d6e:	0f 47 d6             	cmova  %esi,%edx
  710d71:	0f 43 f7             	cmovae %edi,%esi
  710d74:	39 c8                	cmp    %ecx,%eax
  710d76:	89 cf                	mov    %ecx,%edi
  710d78:	0f 47 f8             	cmova  %eax,%edi
  710d7b:	0f 43 c1             	cmovae %ecx,%eax
  710d7e:	41 39 ea             	cmp    %ebp,%r10d
  710d81:	41 89 ec             	mov    %ebp,%r12d
  710d84:	45 0f 47 e2          	cmova  %r10d,%r12d
  710d88:	44 0f 43 d5          	cmovae %ebp,%r10d
  710d8c:	41 39 db             	cmp    %ebx,%r11d
  710d8f:	41 89 df             	mov    %ebx,%r15d
  710d92:	45 0f 47 fb          	cmova  %r11d,%r15d
  710d96:	44 0f 43 db          	cmovae %ebx,%r11d
  710d9a:	41 39 c2             	cmp    %eax,%r10d
  710d9d:	41 89 c6             	mov    %eax,%r14d
  710da0:	45 0f 47 f2          	cmova  %r10d,%r14d
  710da4:	44 0f 43 d0          	cmovae %eax,%r10d
  710da8:	41 39 f9             	cmp    %edi,%r9d
  710dab:	89 f9                	mov    %edi,%ecx
  710dad:	41 0f 47 c9          	cmova  %r9d,%ecx
  710db1:	41 0f 42 f9          	cmovb  %r9d,%edi
  710db5:	45 39 e3             	cmp    %r12d,%r11d
  710db8:	44 89 e5             	mov    %r12d,%ebp
  710dbb:	41 0f 47 eb          	cmova  %r11d,%ebp
  710dbf:	45 0f 43 dc          	cmovae %r12d,%r11d
  710dc3:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  710dc8:	41 39 f2             	cmp    %esi,%r10d
  710dcb:	89 f3                	mov    %esi,%ebx
  710dcd:	41 0f 47 da          	cmova  %r10d,%ebx
  710dd1:	44 0f 43 d6          	cmovae %esi,%r10d
  710dd5:	41 39 d6             	cmp    %edx,%r14d
  710dd8:	89 d6                	mov    %edx,%esi
  710dda:	41 0f 47 f6          	cmova  %r14d,%esi
  710dde:	44 0f 43 f2          	cmovae %edx,%r14d
  710de2:	41 39 fb             	cmp    %edi,%r11d
  710de5:	89 f8                	mov    %edi,%eax
  710de7:	41 0f 47 c3          	cmova  %r11d,%eax
  710deb:	44 0f 43 df          	cmovae %edi,%r11d
  710def:	41 39 cf             	cmp    %ecx,%r15d
  710df2:	89 cf                	mov    %ecx,%edi
  710df4:	41 0f 47 ff          	cmova  %r15d,%edi
  710df8:	41 0f 42 cf          	cmovb  %r15d,%ecx
  710dfc:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  710e01:	45 39 f3             	cmp    %r14d,%r11d
  710e04:	45 89 f1             	mov    %r14d,%r9d
  710e07:	45 0f 47 cb          	cmova  %r11d,%r9d
  710e0b:	45 0f 43 de          	cmovae %r14d,%r11d
  710e0f:	39 f0                	cmp    %esi,%eax
  710e11:	89 f2                	mov    %esi,%edx
  710e13:	0f 47 d0             	cmova  %eax,%edx
  710e16:	45 89 10             	mov    %r10d,(%r8)
  710e19:	0f 43 c6             	cmovae %esi,%eax
  710e1c:	39 cd                	cmp    %ecx,%ebp
  710e1e:	89 ce                	mov    %ecx,%esi
  710e20:	0f 47 f5             	cmova  %ebp,%esi
  710e23:	41 89 78 20          	mov    %edi,0x20(%r8)
  710e27:	0f 42 cd             	cmovb  %ebp,%ecx
  710e2a:	41 39 db             	cmp    %ebx,%r11d
  710e2d:	89 df                	mov    %ebx,%edi
  710e2f:	41 0f 47 fb          	cmova  %r11d,%edi
  710e33:	41 89 70 1c          	mov    %esi,0x1c(%r8)
  710e37:	44 0f 43 db          	cmovae %ebx,%r11d
  710e3b:	44 39 c8             	cmp    %r9d,%eax
  710e3e:	44 89 ce             	mov    %r9d,%esi
  710e41:	0f 47 f0             	cmova  %eax,%esi
  710e44:	45 89 58 04          	mov    %r11d,0x4(%r8)
  710e48:	41 0f 43 c1          	cmovae %r9d,%eax
  710e4c:	39 d1                	cmp    %edx,%ecx
  710e4e:	41 89 d1             	mov    %edx,%r9d
  710e51:	44 0f 47 c9          	cmova  %ecx,%r9d
  710e55:	41 89 78 08          	mov    %edi,0x8(%r8)
  710e59:	41 89 40 0c          	mov    %eax,0xc(%r8)
  710e5d:	0f 43 ca             	cmovae %edx,%ecx
  710e60:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  710e65:	41 89 70 10          	mov    %esi,0x10(%r8)
  710e69:	41 89 48 14          	mov    %ecx,0x14(%r8)
  710e6d:	45 89 48 18          	mov    %r9d,0x18(%r8)
  710e71:	b9 09 00 00 00       	mov    $0x9,%ecx
  710e76:	48 8d 41 ff          	lea    -0x1(%rcx),%rax
  710e7a:	48 39 d0             	cmp    %rdx,%rax
  710e7d:	0f 83 76 01 00 00    	jae    710ff9 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x699>
  710e83:	48 39 d1             	cmp    %rdx,%rcx
  710e86:	75 28                	jne    710eb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x550>
  710e88:	49 83 fd 12          	cmp    $0x12,%r13
  710e8c:	0f 82 1c 01 00 00    	jb     710fae <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x64e>
  710e92:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  710e97:	4c 3b 44 24 08       	cmp    0x8(%rsp),%r8
  710e9c:	4d 89 f8             	mov    %r15,%r8
  710e9f:	0f 84 2b fb ff ff    	je     7109d0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x70>
  710ea5:	eb 56                	jmp    710efd <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x59d>
  710ea7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  710eae:	00 00 
  710eb0:	49 8d 34 90          	lea    (%r8,%rdx,4),%rsi
  710eb4:	c1 e1 02             	shl    $0x2,%ecx
  710eb7:	49 8d 04 08          	lea    (%r8,%rcx,1),%rax
  710ebb:	eb 15                	jmp    710ed2 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x572>
  710ebd:	0f 1f 00             	nopl   (%rax)
  710ec0:	4c 89 c7             	mov    %r8,%rdi
  710ec3:	89 17                	mov    %edx,(%rdi)
  710ec5:	48 83 c0 04          	add    $0x4,%rax
  710ec9:	48 83 c1 04          	add    $0x4,%rcx
  710ecd:	48 39 f0             	cmp    %rsi,%rax
  710ed0:	74 b6                	je     710e88 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x528>
  710ed2:	44 8b 48 fc          	mov    -0x4(%rax),%r9d
  710ed6:	8b 10                	mov    (%rax),%edx
  710ed8:	44 39 ca             	cmp    %r9d,%edx
  710edb:	73 e8                	jae    710ec5 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x565>
  710edd:	48 89 cf             	mov    %rcx,%rdi
  710ee0:	45 89 0c 38          	mov    %r9d,(%r8,%rdi,1)
  710ee4:	48 83 ff 04          	cmp    $0x4,%rdi
  710ee8:	74 d6                	je     710ec0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x560>
  710eea:	45 8b 4c 38 f8       	mov    -0x8(%r8,%rdi,1),%r9d
  710eef:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  710ef3:	44 39 ca             	cmp    %r9d,%edx
  710ef6:	72 e8                	jb     710ee0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x580>
  710ef8:	4c 01 c7             	add    %r8,%rdi
  710efb:	eb c6                	jmp    710ec3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x563>
  710efd:	49 8d 7d ff          	lea    -0x1(%r13),%rdi
  710f01:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
  710f06:	4f 8d 04 a9          	lea    (%r9,%r13,4),%r8
  710f0a:	49 83 c0 fc          	add    $0xfffffffffffffffc,%r8
  710f0e:	49 8d 77 fc          	lea    -0x4(%r15),%rsi
  710f12:	31 c9                	xor    %ecx,%ecx
  710f14:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  710f1b:	00 00 00 00 00 
  710f20:	41 8b 07             	mov    (%r15),%eax
  710f23:	41 8b 11             	mov    (%r9),%edx
  710f26:	45 31 d2             	xor    %r10d,%r10d
  710f29:	45 31 db             	xor    %r11d,%r11d
  710f2c:	39 d0                	cmp    %edx,%eax
  710f2e:	41 0f 93 c2          	setae  %r10b
  710f32:	41 0f 92 c3          	setb   %r11b
  710f36:	0f 42 d0             	cmovb  %eax,%edx
  710f39:	41 8b 00             	mov    (%r8),%eax
  710f3c:	8b 1e                	mov    (%rsi),%ebx
  710f3e:	39 d8                	cmp    %ebx,%eax
  710f40:	41 be 00 00 00 00    	mov    $0x0,%r14d
  710f46:	49 83 d6 ff          	adc    $0xffffffffffffffff,%r14
  710f4a:	39 d8                	cmp    %ebx,%eax
  710f4c:	0f 47 d8             	cmova  %eax,%ebx
  710f4f:	89 54 8c 38          	mov    %edx,0x38(%rsp,%rcx,4)
  710f53:	b8 00 00 00 00       	mov    $0x0,%eax
  710f58:	48 19 c0             	sbb    %rax,%rax
  710f5b:	48 ff c1             	inc    %rcx
  710f5e:	4f 8d 3c 9f          	lea    (%r15,%r11,4),%r15
  710f62:	4f 8d 0c 91          	lea    (%r9,%r10,4),%r9
  710f66:	89 5c bc 38          	mov    %ebx,0x38(%rsp,%rdi,4)
  710f6a:	4f 8d 04 b0          	lea    (%r8,%r14,4),%r8
  710f6e:	48 8d 34 86          	lea    (%rsi,%rax,4),%rsi
  710f72:	48 ff cf             	dec    %rdi
  710f75:	49 39 cc             	cmp    %rcx,%r12
  710f78:	75 a6                	jne    710f20 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x5c0>
  710f7a:	48 83 c6 04          	add    $0x4,%rsi
  710f7e:	49 83 c0 04          	add    $0x4,%r8
  710f82:	41 f6 c5 01          	test   $0x1,%r13b
  710f86:	75 38                	jne    710fc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x660>
  710f88:	4d 39 c7             	cmp    %r8,%r15
  710f8b:	0f 95 c0             	setne  %al
  710f8e:	49 39 f1             	cmp    %rsi,%r9
  710f91:	75 5a                	jne    710fed <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x68d>
  710f93:	84 c0                	test   %al,%al
  710f95:	75 5c                	jne    710ff3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x693>
  710f97:	49 c1 e5 02          	shl    $0x2,%r13
  710f9b:	48 8d 74 24 38       	lea    0x38(%rsp),%rsi
  710fa0:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  710fa5:	4c 89 ea             	mov    %r13,%rdx
  710fa8:	ff 15 5a 6e 3d 00    	call   *0x3d6e5a(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  710fae:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
  710fb5:	5b                   	pop    %rbx
  710fb6:	41 5c                	pop    %r12
  710fb8:	41 5d                	pop    %r13
  710fba:	41 5e                	pop    %r14
  710fbc:	41 5f                	pop    %r15
  710fbe:	5d                   	pop    %rbp
  710fbf:	c3                   	ret
  710fc0:	31 c0                	xor    %eax,%eax
  710fc2:	31 d2                	xor    %edx,%edx
  710fc4:	49 39 f1             	cmp    %rsi,%r9
  710fc7:	0f 93 c0             	setae  %al
  710fca:	0f 92 c2             	setb   %dl
  710fcd:	4c 89 ff             	mov    %r15,%rdi
  710fd0:	49 0f 42 f9          	cmovb  %r9,%rdi
  710fd4:	8b 3f                	mov    (%rdi),%edi
  710fd6:	89 7c 8c 38          	mov    %edi,0x38(%rsp,%rcx,4)
  710fda:	4d 8d 0c 91          	lea    (%r9,%rdx,4),%r9
  710fde:	4d 8d 3c 87          	lea    (%r15,%rax,4),%r15
  710fe2:	4d 39 c7             	cmp    %r8,%r15
  710fe5:	0f 95 c0             	setne  %al
  710fe8:	49 39 f1             	cmp    %rsi,%r9
  710feb:	74 a6                	je     710f93 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x633>
  710fed:	b0 01                	mov    $0x1,%al
  710fef:	84 c0                	test   %al,%al
  710ff1:	74 a4                	je     710f97 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort18small_sort_networkNtNtNtCshBhuxcId5D0_4gpui7runtime8metadata11DestinationNCINvMB8_SB1f_20sort_unstable_by_keymNCNvMst_B1j_INtB1j_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersc_0E0EB3c_+0x637>
  710ff3:	ff 15 77 72 3d 00    	call   *0x3d7277(%rip)        # ae8270 <_DYNAMIC+0x6d8>
  710ff9:	0f 0b                	ud2

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
