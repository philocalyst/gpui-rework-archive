
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006eba20 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_>:
  6eba20:	53                   	push   %rbx
  6eba21:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  6eba28:	48 89 fb             	mov    %rdi,%rbx
  6eba2b:	48 8b 06             	mov    (%rsi),%rax
  6eba2e:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  6eba32:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
  6eba36:	48 85 ff             	test   %rdi,%rdi
  6eba39:	0f 84 e3 01 00 00    	je     6ebc22 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x202>
  6eba3f:	48 8b 8c c8 c8 01 00 	mov    0x1c8(%rax,%rcx,8),%rcx
  6eba46:	00 
  6eba47:	48 89 f8             	mov    %rdi,%rax
  6eba4a:	48 ff c8             	dec    %rax
  6eba4d:	0f 84 cb 00 00 00    	je     6ebb1e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0xfe>
  6eba53:	48 83 c7 fe          	add    $0xfffffffffffffffe,%rdi
  6eba57:	48 89 c6             	mov    %rax,%rsi
  6eba5a:	48 83 e6 07          	and    $0x7,%rsi
  6eba5e:	74 2b                	je     6eba8b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x6b>
  6eba60:	45 31 c0             	xor    %r8d,%r8d
  6eba63:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6eba6a:	84 00 00 00 00 00 
  6eba70:	44 0f b7 89 c2 01 00 	movzwl 0x1c2(%rcx),%r9d
  6eba77:	00 
  6eba78:	4a 8b 8c c9 c8 01 00 	mov    0x1c8(%rcx,%r9,8),%rcx
  6eba7f:	00 
  6eba80:	49 ff c0             	inc    %r8
  6eba83:	4c 39 c6             	cmp    %r8,%rsi
  6eba86:	75 e8                	jne    6eba70 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x50>
  6eba88:	4c 29 c0             	sub    %r8,%rax
  6eba8b:	48 83 ff 07          	cmp    $0x7,%rdi
  6eba8f:	0f 82 89 00 00 00    	jb     6ebb1e <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0xfe>
  6eba95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6eba9c:	00 00 00 00 
  6ebaa0:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebaa7:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebaae:	00 
  6ebaaf:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebab6:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebabd:	00 
  6ebabe:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebac5:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebacc:	00 
  6ebacd:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebad4:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebadb:	00 
  6ebadc:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebae3:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebaea:	00 
  6ebaeb:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebaf2:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebaf9:	00 
  6ebafa:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebb01:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebb08:	00 
  6ebb09:	0f b7 b1 c2 01 00 00 	movzwl 0x1c2(%rcx),%esi
  6ebb10:	48 8b 8c f1 c8 01 00 	mov    0x1c8(%rcx,%rsi,8),%rcx
  6ebb17:	00 
  6ebb18:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  6ebb1c:	75 82                	jne    6ebaa0 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x80>
  6ebb1e:	0f b7 81 c2 01 00 00 	movzwl 0x1c2(%rcx),%eax
  6ebb25:	48 ff c8             	dec    %rax
  6ebb28:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6ebb2d:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6ebb34:	00 00 
  6ebb36:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  6ebb3b:	48 89 e7             	mov    %rsp,%rdi
  6ebb3e:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6ebb43:	e8 78 61 00 00       	call   6f1cc0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>
  6ebb48:	48 8b 3c 24          	mov    (%rsp),%rdi
  6ebb4c:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  6ebb51:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6ebb56:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  6ebb5b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  6ebb60:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6ebb65:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6ebb6a:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  6ebb6f:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  6ebb76:	48 39 ce             	cmp    %rcx,%rsi
  6ebb79:	72 1f                	jb     6ebb9a <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x17a>
  6ebb7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ebb80:	0f b7 b0 c0 01 00 00 	movzwl 0x1c0(%rax),%esi
  6ebb87:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6ebb8e:	48 ff c2             	inc    %rdx
  6ebb91:	66 3b b0 c2 01 00 00 	cmp    0x1c2(%rax),%si
  6ebb98:	73 e6                	jae    6ebb80 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x160>
  6ebb9a:	49 89 f0             	mov    %rsi,%r8
  6ebb9d:	49 c1 e0 05          	shl    $0x5,%r8
  6ebba1:	48 8b 8c f0 68 01 00 	mov    0x168(%rax,%rsi,8),%rcx
  6ebba8:	00 
  6ebba9:	48 89 bc f0 68 01 00 	mov    %rdi,0x168(%rax,%rsi,8)
  6ebbb0:	00 
  6ebbb1:	42 0f 10 04 00       	movups (%rax,%r8,1),%xmm0
  6ebbb6:	42 0f 10 4c 00 10    	movups 0x10(%rax,%r8,1),%xmm1
  6ebbbc:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
  6ebbc1:	0f 29 04 24          	movaps %xmm0,(%rsp)
  6ebbc5:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6ebbca:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6ebbcf:	42 0f 11 04 00       	movups %xmm0,(%rax,%r8,1)
  6ebbd4:	42 0f 11 4c 00 10    	movups %xmm1,0x10(%rax,%r8,1)
  6ebbda:	48 85 d2             	test   %rdx,%rdx
  6ebbdd:	74 6c                	je     6ebc4b <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x22b>
  6ebbdf:	48 8d 3c f0          	lea    (%rax,%rsi,8),%rdi
  6ebbe3:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6ebbea:	48 89 d6             	mov    %rdx,%rsi
  6ebbed:	48 83 e6 07          	and    $0x7,%rsi
  6ebbf1:	74 5d                	je     6ebc50 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x230>
  6ebbf3:	45 31 c9             	xor    %r9d,%r9d
  6ebbf6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6ebbfd:	00 00 00 
  6ebc00:	48 8b 07             	mov    (%rdi),%rax
  6ebc03:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6ebc0a:	49 ff c1             	inc    %r9
  6ebc0d:	4c 39 ce             	cmp    %r9,%rsi
  6ebc10:	75 ee                	jne    6ebc00 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x1e0>
  6ebc12:	49 89 d0             	mov    %rdx,%r8
  6ebc15:	4d 29 c8             	sub    %r9,%r8
  6ebc18:	31 f6                	xor    %esi,%esi
  6ebc1a:	48 83 fa 08          	cmp    $0x8,%rdx
  6ebc1e:	73 40                	jae    6ebc60 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x240>
  6ebc20:	eb 7f                	jmp    6ebca1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ebc22:	48 89 04 24          	mov    %rax,(%rsp)
  6ebc26:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6ebc2d:	00 00 
  6ebc2f:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6ebc34:	48 89 e6             	mov    %rsp,%rsi
  6ebc37:	48 89 df             	mov    %rbx,%rdi
  6ebc3a:	e8 81 60 00 00       	call   6f1cc0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>
  6ebc3f:	48 89 d8             	mov    %rbx,%rax
  6ebc42:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6ebc49:	5b                   	pop    %rbx
  6ebc4a:	c3                   	ret
  6ebc4b:	48 ff c6             	inc    %rsi
  6ebc4e:	eb 51                	jmp    6ebca1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ebc50:	49 89 d0             	mov    %rdx,%r8
  6ebc53:	31 f6                	xor    %esi,%esi
  6ebc55:	48 83 fa 08          	cmp    $0x8,%rdx
  6ebc59:	72 46                	jb     6ebca1 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x281>
  6ebc5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  6ebc60:	48 8b 07             	mov    (%rdi),%rax
  6ebc63:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc6a:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc71:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc78:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc7f:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc86:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc8d:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  6ebc94:	48 8d b8 c8 01 00 00 	lea    0x1c8(%rax),%rdi
  6ebc9b:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
  6ebc9f:	75 bf                	jne    6ebc60 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_+0x240>
  6ebca1:	48 89 0b             	mov    %rcx,(%rbx)
  6ebca4:	0f 28 04 24          	movaps (%rsp),%xmm0
  6ebca8:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
  6ebcad:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  6ebcb1:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  6ebcb5:	48 89 43 28          	mov    %rax,0x28(%rbx)
  6ebcb9:	48 c7 43 30 00 00 00 	movq   $0x0,0x30(%rbx)
  6ebcc0:	00 
  6ebcc1:	48 89 73 38          	mov    %rsi,0x38(%rbx)
  6ebcc5:	48 89 d8             	mov    %rbx,%rax
  6ebcc8:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  6ebccf:	5b                   	pop    %rbx
  6ebcd0:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
