
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006f1400 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_>:
  6f1400:	55                   	push   %rbp
  6f1401:	41 57                	push   %r15
  6f1403:	41 56                	push   %r14
  6f1405:	41 55                	push   %r13
  6f1407:	41 54                	push   %r12
  6f1409:	53                   	push   %rbx
  6f140a:	48 81 ec 58 01 00 00 	sub    $0x158,%rsp
  6f1411:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f1418:	00 
  6f1419:	49 89 f4             	mov    %rsi,%r12
  6f141c:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  6f1423:	00 
  6f1424:	48 8b 2e             	mov    (%rsi),%rbp
  6f1427:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f142b:	0f b7 9d c2 01 00 00 	movzwl 0x1c2(%rbp),%ebx
  6f1432:	4a 8d bc ed 68 01 00 	lea    0x168(%rbp,%r13,8),%rdi
  6f1439:	00 
  6f143a:	4a 8b 84 ed 68 01 00 	mov    0x168(%rbp,%r13,8),%rax
  6f1441:	00 
  6f1442:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6f1447:	4a 8d 34 ed 70 01 00 	lea    0x170(,%r13,8),%rsi
  6f144e:	00 
  6f144f:	48 01 ee             	add    %rbp,%rsi
  6f1452:	4d 89 ef             	mov    %r13,%r15
  6f1455:	49 f7 d7             	not    %r15
  6f1458:	49 01 df             	add    %rbx,%r15
  6f145b:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f1462:	00 
  6f1463:	4c 8b 35 96 69 3f 00 	mov    0x3f6996(%rip),%r14        # ae7e00 <memmove@GLIBC_2.2.5>
  6f146a:	41 ff d6             	call   *%r14
  6f146d:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
  6f1472:	4c 89 e8             	mov    %r13,%rax
  6f1475:	48 c1 e0 05          	shl    $0x5,%rax
  6f1479:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f147d:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f1482:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f1487:	0f 11 8c 24 e8 00 00 	movups %xmm1,0xe8(%rsp)
  6f148e:	00 
  6f148f:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f1496:	00 
  6f1497:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f149b:	48 83 c6 20          	add    $0x20,%rsi
  6f149f:	49 c1 e7 05          	shl    $0x5,%r15
  6f14a3:	4c 89 fa             	mov    %r15,%rdx
  6f14a6:	41 ff d6             	call   *%r14
  6f14a9:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f14ac:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
  6f14b1:	66 89 85 c2 01 00 00 	mov    %ax,0x1c2(%rbp)
  6f14b8:	49 8b 6c 24 08       	mov    0x8(%r12),%rbp
  6f14bd:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6f14c2:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f14c9:	00 
  6f14ca:	66 83 f8 04          	cmp    $0x4,%ax
  6f14ce:	0f 87 77 01 00 00    	ja     6f164b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f14d4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f14d9:	48 8b 80 60 01 00 00 	mov    0x160(%rax),%rax
  6f14e0:	48 85 c0             	test   %rax,%rax
  6f14e3:	0f 84 16 01 00 00    	je     6f15ff <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1ff>
  6f14e9:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
  6f14ed:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  6f14f2:	0f b7 92 c0 01 00 00 	movzwl 0x1c0(%rdx),%edx
  6f14f9:	48 85 d2             	test   %rdx,%rdx
  6f14fc:	74 63                	je     6f1561 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x161>
  6f14fe:	48 8b b4 d0 c0 01 00 	mov    0x1c0(%rax,%rdx,8),%rsi
  6f1505:	00 
  6f1506:	48 ff ca             	dec    %rdx
  6f1509:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f150e:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6f1513:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
  6f1518:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6f151d:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f1522:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1527:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  6f152c:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f1531:	0f b7 86 c2 01 00 00 	movzwl 0x1c2(%rsi),%eax
  6f1538:	01 c3                	add    %eax,%ebx
  6f153a:	83 fb 0c             	cmp    $0xc,%ebx
  6f153d:	0f 83 85 00 00 00    	jae    6f15c8 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1c8>
  6f1543:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f1548:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6f154d:	ba 01 00 00 00       	mov    $0x1,%edx
  6f1552:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f1557:	e8 54 ab ff ff       	call   6ec0b0 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f155c:	e9 b7 00 00 00       	jmp    6f1618 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x218>
  6f1561:	66 83 b8 c2 01 00 00 	cmpw   $0x0,0x1c2(%rax)
  6f1568:	00 
  6f1569:	0f 84 e3 06 00 00    	je     6f1c52 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x852>
  6f156f:	48 8b 90 d0 01 00 00 	mov    0x1d0(%rax),%rdx
  6f1576:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6f157b:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6f1580:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f1587:	00 00 
  6f1589:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f158e:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6f1593:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f1598:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6f159d:	48 89 6c 24 78       	mov    %rbp,0x78(%rsp)
  6f15a2:	0f b7 82 c2 01 00 00 	movzwl 0x1c2(%rdx),%eax
  6f15a9:	01 c3                	add    %eax,%ebx
  6f15ab:	83 fb 0c             	cmp    $0xc,%ebx
  6f15ae:	73 40                	jae    6f15f0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x1f0>
  6f15b0:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  6f15b5:	48 8d 74 24 48       	lea    0x48(%rsp),%rsi
  6f15ba:	31 d2                	xor    %edx,%edx
  6f15bc:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f15c1:	e8 ea aa ff ff       	call   6ec0b0 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f15c6:	eb 50                	jmp    6f1618 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x218>
  6f15c8:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f15cd:	be 01 00 00 00       	mov    $0x1,%esi
  6f15d2:	e8 49 1e 00 00       	call   6f3420 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f15d7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f15dc:	48 ff c0             	inc    %rax
  6f15df:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f15e4:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6f15e9:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  6f15ee:	eb 23                	jmp    6f1613 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x213>
  6f15f0:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f15f5:	be 01 00 00 00       	mov    $0x1,%esi
  6f15fa:	e8 61 21 00 00       	call   6f3760 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f15ff:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1604:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6f1609:	48 89 6c 24 38       	mov    %rbp,0x38(%rsp)
  6f160e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f1613:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f1618:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6f161d:	48 8b 6c 24 38       	mov    0x38(%rsp),%rbp
  6f1622:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6f1627:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f162c:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  6f1631:	4c 8b b1 60 01 00 00 	mov    0x160(%rcx),%r14
  6f1638:	4d 85 f6             	test   %r14,%r14
  6f163b:	74 0e                	je     6f164b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f163d:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f1644:	00 
  6f1645:	66 83 f8 04          	cmp    $0x4,%ax
  6f1649:	76 5f                	jbe    6f16aa <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2aa>
  6f164b:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  6f1652:	00 
  6f1653:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  6f165a:	00 
  6f165b:	48 89 42 20          	mov    %rax,0x20(%rdx)
  6f165f:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6f1666:	00 
  6f1667:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  6f166e:	00 
  6f166f:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6f1676:	00 
  6f1677:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f167b:	48 89 02             	mov    %rax,(%rdx)
  6f167e:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f1682:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1687:	48 89 42 28          	mov    %rax,0x28(%rdx)
  6f168b:	48 89 6a 30          	mov    %rbp,0x30(%rdx)
  6f168f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f1694:	48 89 42 38          	mov    %rax,0x38(%rdx)
  6f1698:	48 81 c4 58 01 00 00 	add    $0x158,%rsp
  6f169f:	5b                   	pop    %rbx
  6f16a0:	41 5c                	pop    %r12
  6f16a2:	41 5d                	pop    %r13
  6f16a4:	41 5e                	pop    %r14
  6f16a6:	41 5f                	pop    %r15
  6f16a8:	5d                   	pop    %rbp
  6f16a9:	c3                   	ret
  6f16aa:	4c 8d 65 01          	lea    0x1(%rbp),%r12
  6f16ae:	48 8d 0d eb 82 3c 00 	lea    0x3c82eb(%rip),%rcx        # ab99a0 <__frame_dummy_init_array_entry+0x98>
  6f16b5:	48 89 8c 24 88 00 00 	mov    %rcx,0x88(%rsp)
  6f16bc:	00 
  6f16bd:	48 8d 0d f8 1e 97 ff 	lea    -0x68e108(%rip),%rcx        # 635bc <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f16c4:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6f16cb:	00 
  6f16cc:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  6f16d3:	00 
  6f16d4:	eb 2a                	jmp    6f1700 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x300>
  6f16d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f16dd:	00 00 00 
  6f16e0:	ba 08 00 00 00       	mov    $0x8,%edx
  6f16e5:	4c 89 ef             	mov    %r13,%rdi
  6f16e8:	ff 15 f2 66 3f 00    	call   *0x3f66f2(%rip)        # ae7de0 <_DYNAMIC+0x248>
  6f16ee:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f16f5:	00 
  6f16f6:	66 83 f8 04          	cmp    $0x4,%ax
  6f16fa:	0f 87 4b ff ff ff    	ja     6f164b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1700:	4c 89 f1             	mov    %r14,%rcx
  6f1703:	0f b7 c0             	movzwl %ax,%eax
  6f1706:	4d 8b b6 60 01 00 00 	mov    0x160(%r14),%r14
  6f170d:	4d 85 f6             	test   %r14,%r14
  6f1710:	0f 84 86 04 00 00    	je     6f1b9c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x79c>
  6f1716:	4c 89 e6             	mov    %r12,%rsi
  6f1719:	49 8d 7c 24 01       	lea    0x1(%r12),%rdi
  6f171e:	44 0f b7 a9 c0 01 00 	movzwl 0x1c0(%rcx),%r13d
  6f1725:	00 
  6f1726:	4d 85 ed             	test   %r13,%r13
  6f1729:	48 89 bc 24 c8 00 00 	mov    %rdi,0xc8(%rsp)
  6f1730:	00 
  6f1731:	0f 84 89 00 00 00    	je     6f17c0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x3c0>
  6f1737:	4b 8b 9c ee c0 01 00 	mov    0x1c0(%r14,%r13,8),%rbx
  6f173e:	00 
  6f173f:	49 ff cd             	dec    %r13
  6f1742:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  6f1749:	00 
  6f174a:	48 89 bc 24 00 01 00 	mov    %rdi,0x100(%rsp)
  6f1751:	00 
  6f1752:	4c 89 ac 24 08 01 00 	mov    %r13,0x108(%rsp)
  6f1759:	00 
  6f175a:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
  6f1761:	00 
  6f1762:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
  6f1769:	00 
  6f176a:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6f1771:	00 
  6f1772:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
  6f1779:	00 
  6f177a:	0f b7 b3 c2 01 00 00 	movzwl 0x1c2(%rbx),%esi
  6f1781:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f1784:	ff c2                	inc    %edx
  6f1786:	83 fa 0c             	cmp    $0xc,%edx
  6f1789:	0f 83 75 04 00 00    	jae    6f1c04 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x804>
  6f178f:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f1796:	00 
  6f1797:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f179b:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  6f17a0:	49 89 f4             	mov    %rsi,%r12
  6f17a3:	48 01 c6             	add    %rax,%rsi
  6f17a6:	48 ff c6             	inc    %rsi
  6f17a9:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6f17ae:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6f17b3:	eb 7f                	jmp    6f1834 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x434>
  6f17b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6f17bc:	00 00 00 00 
  6f17c0:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f17c7:	00 
  6f17c8:	66 85 d2             	test   %dx,%dx
  6f17cb:	0f 84 81 04 00 00    	je     6f1c52 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x852>
  6f17d1:	4d 8b 86 d0 01 00 00 	mov    0x1d0(%r14),%r8
  6f17d8:	4c 89 74 24 48       	mov    %r14,0x48(%rsp)
  6f17dd:	48 89 7c 24 50       	mov    %rdi,0x50(%rsp)
  6f17e2:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  6f17e9:	00 00 
  6f17eb:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  6f17f0:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
  6f17f5:	4c 89 44 24 70       	mov    %r8,0x70(%rsp)
  6f17fa:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6f17ff:	45 0f b7 88 c2 01 00 	movzwl 0x1c2(%r8),%r9d
  6f1806:	00 
  6f1807:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f180b:	48 ff c6             	inc    %rsi
  6f180e:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f1812:	0f 83 06 04 00 00    	jae    6f1c1e <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x81e>
  6f1818:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f181c:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  6f1821:	48 89 cb             	mov    %rcx,%rbx
  6f1824:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  6f1829:	45 31 ed             	xor    %r13d,%r13d
  6f182c:	49 89 c4             	mov    %rax,%r12
  6f182f:	4c 89 4c 24 28       	mov    %r9,0x28(%rsp)
  6f1834:	0f b7 c2             	movzwl %dx,%eax
  6f1837:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f183e:	00 
  6f183f:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
  6f1846:	00 
  6f1847:	66 89 b3 c2 01 00 00 	mov    %si,0x1c2(%rbx)
  6f184e:	4b 8d 3c ee          	lea    (%r14,%r13,8),%rdi
  6f1852:	48 81 c7 68 01 00 00 	add    $0x168,%rdi
  6f1859:	4b 8b ac ee 68 01 00 	mov    0x168(%r14,%r13,8),%rbp
  6f1860:	00 
  6f1861:	4b 8d 34 ee          	lea    (%r14,%r13,8),%rsi
  6f1865:	48 81 c6 70 01 00 00 	add    $0x170,%rsi
  6f186c:	4d 89 ef             	mov    %r13,%r15
  6f186f:	49 f7 d7             	not    %r15
  6f1872:	49 01 c7             	add    %rax,%r15
  6f1875:	4a 8d 14 fd 00 00 00 	lea    0x0(,%r15,8),%rdx
  6f187c:	00 
  6f187d:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  6f1884:	00 
  6f1885:	48 8b 05 74 65 3f 00 	mov    0x3f6574(%rip),%rax        # ae7e00 <memmove@GLIBC_2.2.5>
  6f188c:	ff d0                	call   *%rax
  6f188e:	4a 89 ac e3 68 01 00 	mov    %rbp,0x168(%rbx,%r12,8)
  6f1895:	00 
  6f1896:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f189b:	48 8d b0 68 01 00 00 	lea    0x168(%rax),%rsi
  6f18a2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f18a7:	48 8d bc c3 68 01 00 	lea    0x168(%rbx,%rax,8),%rdi
  6f18ae:	00 
  6f18af:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  6f18b4:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f18bb:	48 8b 2d 46 65 3f 00 	mov    0x3f6546(%rip),%rbp        # ae7e08 <memcpy@GLIBC_2.14>
  6f18c2:	ff d5                	call   *%rbp
  6f18c4:	4c 89 e8             	mov    %r13,%rax
  6f18c7:	48 c1 e0 05          	shl    $0x5,%rax
  6f18cb:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f18cf:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f18d4:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f18da:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  6f18e1:	00 
  6f18e2:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  6f18e9:	00 
  6f18ea:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f18ee:	48 83 c6 20          	add    $0x20,%rsi
  6f18f2:	49 c1 e7 05          	shl    $0x5,%r15
  6f18f6:	4c 89 fa             	mov    %r15,%rdx
  6f18f9:	48 8b 2d 00 65 3f 00 	mov    0x3f6500(%rip),%rbp        # ae7e00 <memmove@GLIBC_2.2.5>
  6f1900:	ff d5                	call   *%rbp
  6f1902:	4c 89 a4 24 b0 00 00 	mov    %r12,0xb0(%rsp)
  6f1909:	00 
  6f190a:	41 c1 e4 05          	shl    $0x5,%r12d
  6f190e:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  6f1915:	00 
  6f1916:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
  6f191d:	00 
  6f191e:	42 0f 11 04 23       	movups %xmm0,(%rbx,%r12,1)
  6f1923:	42 0f 11 4c 23 10    	movups %xmm1,0x10(%rbx,%r12,1)
  6f1929:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6f192e:	c1 e7 05             	shl    $0x5,%edi
  6f1931:	48 01 df             	add    %rbx,%rdi
  6f1934:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6f1939:	c1 e2 05             	shl    $0x5,%edx
  6f193c:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6f1941:	ff 15 c1 64 3f 00    	call   *0x3f64c1(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  6f1947:	4d 8d 7d 01          	lea    0x1(%r13),%r15
  6f194b:	4b 8d 3c ee          	lea    (%r14,%r13,8),%rdi
  6f194f:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6f1956:	4b 8d 34 ee          	lea    (%r14,%r13,8),%rsi
  6f195a:	48 81 c6 d8 01 00 00 	add    $0x1d8,%rsi
  6f1961:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  6f1968:	00 
  6f1969:	ff d5                	call   *%rbp
  6f196b:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6f1972:	00 
  6f1973:	4c 39 fe             	cmp    %r15,%rsi
  6f1976:	0f 86 be 00 00 00    	jbe    6f1a3a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f197c:	89 f1                	mov    %esi,%ecx
  6f197e:	44 29 f9             	sub    %r15d,%ecx
  6f1981:	83 e1 03             	and    $0x3,%ecx
  6f1984:	0f 84 f6 01 00 00    	je     6f1b80 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x780>
  6f198a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  6f1990:	49 8d 47 01          	lea    0x1(%r15),%rax
  6f1994:	4b 8b 94 fe c8 01 00 	mov    0x1c8(%r14,%r15,8),%rdx
  6f199b:	00 
  6f199c:	4c 89 b2 60 01 00 00 	mov    %r14,0x160(%rdx)
  6f19a3:	66 44 89 ba c0 01 00 	mov    %r15w,0x1c0(%rdx)
  6f19aa:	00 
  6f19ab:	49 89 c7             	mov    %rax,%r15
  6f19ae:	48 ff c9             	dec    %rcx
  6f19b1:	75 dd                	jne    6f1990 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x590>
  6f19b3:	49 f7 dd             	neg    %r13
  6f19b6:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
  6f19ba:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f19be:	83 f9 03             	cmp    $0x3,%ecx
  6f19c1:	72 77                	jb     6f1a3a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f19c3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f19ca:	84 00 00 00 00 00 
  6f19d0:	49 8b 8c c6 c8 01 00 	mov    0x1c8(%r14,%rax,8),%rcx
  6f19d7:	00 
  6f19d8:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f19df:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f19e6:	49 8b 8c c6 d0 01 00 	mov    0x1d0(%r14,%rax,8),%rcx
  6f19ed:	00 
  6f19ee:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f19f5:	8d 50 01             	lea    0x1(%rax),%edx
  6f19f8:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f19ff:	49 8b 8c c6 d8 01 00 	mov    0x1d8(%r14,%rax,8),%rcx
  6f1a06:	00 
  6f1a07:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f1a0e:	8d 50 02             	lea    0x2(%rax),%edx
  6f1a11:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f1a18:	49 8b 8c c6 e0 01 00 	mov    0x1e0(%r14,%rax,8),%rcx
  6f1a1f:	00 
  6f1a20:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f1a27:	8d 50 03             	lea    0x3(%rax),%edx
  6f1a2a:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f1a31:	48 83 c0 04          	add    $0x4,%rax
  6f1a35:	48 39 f0             	cmp    %rsi,%rax
  6f1a38:	75 96                	jne    6f19d0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x5d0>
  6f1a3a:	66 41 ff 8e c2 01 00 	decw   0x1c2(%r14)
  6f1a41:	00 
  6f1a42:	be c8 01 00 00       	mov    $0x1c8,%esi
  6f1a47:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
  6f1a4e:	00 
  6f1a4f:	49 83 fc 02          	cmp    $0x2,%r12
  6f1a53:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  6f1a5a:	00 
  6f1a5b:	4c 8b 6c 24 18       	mov    0x18(%rsp),%r13
  6f1a60:	0f 82 7a fc ff ff    	jb     6f16e0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f1a66:	48 8b 54 24 28       	mov    0x28(%rsp),%rdx
  6f1a6b:	48 ff c2             	inc    %rdx
  6f1a6e:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f1a75:	00 
  6f1a76:	48 2b 84 24 b0 00 00 	sub    0xb0(%rsp),%rax
  6f1a7d:	00 
  6f1a7e:	48 39 c2             	cmp    %rax,%rdx
  6f1a81:	0f 85 ae 01 00 00    	jne    6f1c35 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x835>
  6f1a87:	48 8d 83 c8 01 00 00 	lea    0x1c8(%rbx),%rax
  6f1a8e:	4c 8b 7c 24 20       	mov    0x20(%rsp),%r15
  6f1a93:	4a 8d 3c f8          	lea    (%rax,%r15,8),%rdi
  6f1a97:	49 8d b5 c8 01 00 00 	lea    0x1c8(%r13),%rsi
  6f1a9e:	c1 e2 03             	shl    $0x3,%edx
  6f1aa1:	ff 15 61 63 3f 00    	call   *0x3f6361(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  6f1aa7:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  6f1aae:	00 
  6f1aaf:	89 f9                	mov    %edi,%ecx
  6f1ab1:	44 29 f9             	sub    %r15d,%ecx
  6f1ab4:	ff c1                	inc    %ecx
  6f1ab6:	4c 89 f8             	mov    %r15,%rax
  6f1ab9:	83 e1 03             	and    $0x3,%ecx
  6f1abc:	74 34                	je     6f1af2 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x6f2>
  6f1abe:	4c 89 fa             	mov    %r15,%rdx
  6f1ac1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f1ac8:	0f 1f 84 00 00 00 00 
  6f1acf:	00 
  6f1ad0:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f1ad4:	48 8b b4 d3 c8 01 00 	mov    0x1c8(%rbx,%rdx,8),%rsi
  6f1adb:	00 
  6f1adc:	48 89 9e 60 01 00 00 	mov    %rbx,0x160(%rsi)
  6f1ae3:	66 89 96 c0 01 00 00 	mov    %dx,0x1c0(%rsi)
  6f1aea:	48 89 c2             	mov    %rax,%rdx
  6f1aed:	48 ff c9             	dec    %rcx
  6f1af0:	75 de                	jne    6f1ad0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x6d0>
  6f1af2:	48 89 f9             	mov    %rdi,%rcx
  6f1af5:	4c 29 f9             	sub    %r15,%rcx
  6f1af8:	be 28 02 00 00       	mov    $0x228,%esi
  6f1afd:	83 f9 03             	cmp    $0x3,%ecx
  6f1b00:	0f 82 da fb ff ff    	jb     6f16e0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f1b06:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  6f1b0d:	00 00 00 
  6f1b10:	48 8b 8c c3 c8 01 00 	mov    0x1c8(%rbx,%rax,8),%rcx
  6f1b17:	00 
  6f1b18:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f1b1f:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f1b26:	48 8b 8c c3 d0 01 00 	mov    0x1d0(%rbx,%rax,8),%rcx
  6f1b2d:	00 
  6f1b2e:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f1b35:	8d 50 01             	lea    0x1(%rax),%edx
  6f1b38:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f1b3f:	48 8b 8c c3 d8 01 00 	mov    0x1d8(%rbx,%rax,8),%rcx
  6f1b46:	00 
  6f1b47:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f1b4e:	8d 50 02             	lea    0x2(%rax),%edx
  6f1b51:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f1b58:	48 8b 8c c3 e0 01 00 	mov    0x1e0(%rbx,%rax,8),%rcx
  6f1b5f:	00 
  6f1b60:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f1b67:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f1b6b:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f1b72:	48 83 c0 04          	add    $0x4,%rax
  6f1b76:	48 39 fa             	cmp    %rdi,%rdx
  6f1b79:	75 95                	jne    6f1b10 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x710>
  6f1b7b:	e9 60 fb ff ff       	jmp    6f16e0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x2e0>
  6f1b80:	4c 89 f8             	mov    %r15,%rax
  6f1b83:	49 f7 dd             	neg    %r13
  6f1b86:	4a 8d 0c 2e          	lea    (%rsi,%r13,1),%rcx
  6f1b8a:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f1b8e:	83 f9 03             	cmp    $0x3,%ecx
  6f1b91:	0f 83 39 fe ff ff    	jae    6f19d0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x5d0>
  6f1b97:	e9 9e fe ff ff       	jmp    6f1a3a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x63a>
  6f1b9c:	48 85 c0             	test   %rax,%rax
  6f1b9f:	0f 85 a6 fa ff ff    	jne    6f164b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1ba5:	4c 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14
  6f1bac:	00 
  6f1bad:	49 8b 1e             	mov    (%r14),%rbx
  6f1bb0:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f1bb7:	48 85 db             	test   %rbx,%rbx
  6f1bba:	0f 84 ad 00 00 00    	je     6f1c6d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x86d>
  6f1bc0:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f1bc4:	48 85 c0             	test   %rax,%rax
  6f1bc7:	0f 84 af 00 00 00    	je     6f1c7c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87c>
  6f1bcd:	48 8b 3b             	mov    (%rbx),%rdi
  6f1bd0:	48 8b 8f c8 01 00 00 	mov    0x1c8(%rdi),%rcx
  6f1bd7:	48 89 0b             	mov    %rcx,(%rbx)
  6f1bda:	48 ff c8             	dec    %rax
  6f1bdd:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f1be1:	48 c7 81 60 01 00 00 	movq   $0x0,0x160(%rcx)
  6f1be8:	00 00 00 00 
  6f1bec:	be 28 02 00 00       	mov    $0x228,%esi
  6f1bf1:	ba 08 00 00 00       	mov    $0x8,%edx
  6f1bf6:	ff 15 e4 61 3f 00    	call   *0x3f61e4(%rip)        # ae7de0 <_DYNAMIC+0x248>
  6f1bfc:	49 89 1e             	mov    %rbx,(%r14)
  6f1bff:	e9 47 fa ff ff       	jmp    6f164b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1c04:	be 05 00 00 00       	mov    $0x5,%esi
  6f1c09:	48 29 c6             	sub    %rax,%rsi
  6f1c0c:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  6f1c13:	00 
  6f1c14:	e8 07 18 00 00       	call   6f3420 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1c19:	e9 2d fa ff ff       	jmp    6f164b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1c1e:	be 05 00 00 00       	mov    $0x5,%esi
  6f1c23:	48 29 c6             	sub    %rax,%rsi
  6f1c26:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  6f1c2b:	e8 30 1b 00 00       	call   6f3760 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1c30:	e9 16 fa ff ff       	jmp    6f164b <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x24b>
  6f1c35:	be 28 00 00 00       	mov    $0x28,%esi
  6f1c3a:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  6f1c41:	00 
  6f1c42:	48 8b 94 24 88 00 00 	mov    0x88(%rsp),%rdx
  6f1c49:	00 
  6f1c4a:	ff 15 c8 61 3f 00    	call   *0x3f61c8(%rip)        # ae7e18 <_DYNAMIC+0x280>
  6f1c50:	eb 28                	jmp    6f1c7a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87a>
  6f1c52:	48 8d 3d 80 1a 97 ff 	lea    -0x68e580(%rip),%rdi        # 636d9 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f1c59:	48 8d 15 48 7e 3c 00 	lea    0x3c7e48(%rip),%rdx        # ab9aa8 <__frame_dummy_init_array_entry+0x1a0>
  6f1c60:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f1c65:	ff 15 cd 61 3f 00    	call   *0x3f61cd(%rip)        # ae7e38 <_DYNAMIC+0x2a0>
  6f1c6b:	eb 0d                	jmp    6f1c7a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x87a>
  6f1c6d:	48 8d 3d 44 7d 3c 00 	lea    0x3c7d44(%rip),%rdi        # ab99b8 <__frame_dummy_init_array_entry+0xb0>
  6f1c74:	ff 15 a6 61 3f 00    	call   *0x3f61a6(%rip)        # ae7e20 <_DYNAMIC+0x288>
  6f1c7a:	0f 0b                	ud2
  6f1c7c:	48 8d 05 05 7d 3c 00 	lea    0x3c7d05(%rip),%rax        # ab9988 <__frame_dummy_init_array_entry+0x80>
  6f1c83:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  6f1c8a:	00 
  6f1c8b:	be 21 00 00 00       	mov    $0x21,%esi
  6f1c90:	48 8d 05 04 19 97 ff 	lea    -0x68e6fc(%rip),%rax        # 6359b <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f1c97:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f1c9e:	00 
  6f1c9f:	eb 99                	jmp    6f1c3a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1R_11shared_text10SharedTextEEj2_NtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB4w_14ExtractIfInneryB1L_NtNtNtB2C_3ops5range9RangeFullE4nextNCINvMsi_B4w_INtB4w_8BTreeMapyB1L_E6retainNCNvMst_NtB1R_7runtimeINtB6v_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtBb_5alloc6GlobalE0B89_EB70_+0x83a>
  6f1ca1:	48 89 c3             	mov    %rax,%rbx
  6f1ca4:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  6f1cab:	00 
  6f1cac:	e8 cf 16 00 00       	call   6f3380 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueTyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtB4_6option6OptionNtNtBJ_11shared_text10SharedTextEEj2_EECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1cb1:	48 89 df             	mov    %rbx,%rdi
  6f1cb4:	e8 97 68 3c 00       	call   ab8550 <_Unwind_Resume@plt>
  6f1cb9:	ff 15 71 61 3f 00    	call   *0x3f6171(%rip)        # ae7e30 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
