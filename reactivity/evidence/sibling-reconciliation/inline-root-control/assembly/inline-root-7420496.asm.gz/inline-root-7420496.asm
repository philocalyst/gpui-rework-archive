
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000713a50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_>:
  713a50:	55                   	push   %rbp
  713a51:	41 57                	push   %r15
  713a53:	41 56                	push   %r14
  713a55:	41 55                	push   %r13
  713a57:	41 54                	push   %r12
  713a59:	53                   	push   %rbx
  713a5a:	48 83 ec 58          	sub    $0x58,%rsp
  713a5e:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  713a63:	4c 8b 7e 10          	mov    0x10(%rsi),%r15
  713a67:	4c 8b 2e             	mov    (%rsi),%r13
  713a6a:	48 8b 7e 08          	mov    0x8(%rsi),%rdi
  713a6e:	48 8d 46 20          	lea    0x20(%rsi),%rax
  713a72:	48 8b 6e 18          	mov    0x18(%rsi),%rbp
  713a76:	4d 85 ff             	test   %r15,%r15
  713a79:	74 09                	je     713a84 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x34>
  713a7b:	49 39 ef             	cmp    %rbp,%r15
  713a7e:	0f 85 a4 00 00 00    	jne    713b28 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xd8>
  713a84:	4d 85 ed             	test   %r13,%r13
  713a87:	74 4e                	je     713ad7 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x87>
  713a89:	49 39 fd             	cmp    %rdi,%r13
  713a8c:	74 49                	je     713ad7 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x87>
  713a8e:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  713a95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  713a9c:	00 00 00 00 
  713aa0:	4d 8b 7d e0          	mov    -0x20(%r13),%r15
  713aa4:	49 8b 6d e8          	mov    -0x18(%r13),%rbp
  713aa8:	48 85 ed             	test   %rbp,%rbp
  713aab:	75 6a                	jne    713b17 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xc7>
  713aad:	49 8d 8d a8 00 00 00 	lea    0xa8(%r13),%rcx
  713ab4:	49 39 fd             	cmp    %rdi,%r13
  713ab7:	49 89 cd             	mov    %rcx,%r13
  713aba:	75 e4                	jne    713aa0 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x50>
  713abc:	48 8d 91 b0 fe ff ff 	lea    -0x150(%rcx),%rdx
  713ac3:	48 89 10             	mov    %rdx,(%rax)
  713ac6:	48 c1 e5 05          	shl    $0x5,%rbp
  713aca:	4c 01 fd             	add    %r15,%rbp
  713acd:	48 81 c1 58 ff ff ff 	add    $0xffffffffffffff58,%rcx
  713ad4:	49 89 cd             	mov    %rcx,%r13
  713ad7:	4c 8b 7e 28          	mov    0x28(%rsi),%r15
  713adb:	4d 85 ff             	test   %r15,%r15
  713ade:	74 16                	je     713af6 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xa6>
  713ae0:	4c 8b 46 30          	mov    0x30(%rsi),%r8
  713ae4:	4d 39 c7             	cmp    %r8,%r15
  713ae7:	74 0d                	je     713af6 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xa6>
  713ae9:	4d 8d 4f 20          	lea    0x20(%r15),%r9
  713aed:	48 8d 46 38          	lea    0x38(%rsi),%rax
  713af1:	45 31 d2             	xor    %r10d,%r10d
  713af4:	eb 3e                	jmp    713b34 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0xe4>
  713af6:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  713afb:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
  713b02:	48 c7 40 08 08 00 00 	movq   $0x8,0x8(%rax)
  713b09:	00 
  713b0a:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  713b11:	00 
  713b12:	e9 b8 02 00 00       	jmp    713dcf <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x37f>
  713b17:	49 8d 8d 58 ff ff ff 	lea    -0xa8(%r13),%rcx
  713b1e:	48 89 08             	mov    %rcx,(%rax)
  713b21:	48 c1 e5 05          	shl    $0x5,%rbp
  713b25:	4c 01 fd             	add    %r15,%rbp
  713b28:	4d 8d 57 20          	lea    0x20(%r15),%r10
  713b2c:	4c 8b 4e 28          	mov    0x28(%rsi),%r9
  713b30:	4c 8b 46 30          	mov    0x30(%rsi),%r8
  713b34:	48 89 e9             	mov    %rbp,%rcx
  713b37:	4c 29 d1             	sub    %r10,%rcx
  713b3a:	48 c1 e9 05          	shr    $0x5,%rcx
  713b3e:	4d 85 d2             	test   %r10,%r10
  713b41:	49 0f 44 ca          	cmove  %r10,%rcx
  713b45:	4c 89 c2             	mov    %r8,%rdx
  713b48:	4c 29 ca             	sub    %r9,%rdx
  713b4b:	48 c1 ea 05          	shr    $0x5,%rdx
  713b4f:	4d 85 c9             	test   %r9,%r9
  713b52:	49 0f 44 d1          	cmove  %r9,%rdx
  713b56:	48 01 ca             	add    %rcx,%rdx
  713b59:	48 83 fa 04          	cmp    $0x4,%rdx
  713b5d:	41 be 03 00 00 00    	mov    $0x3,%r14d
  713b63:	4c 0f 43 f2          	cmovae %rdx,%r14
  713b67:	48 b9 54 55 55 55 55 	movabs $0x555555555555554,%rcx
  713b6e:	55 55 05 
  713b71:	48 39 ca             	cmp    %rcx,%rdx
  713b74:	76 0b                	jbe    713b81 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x131>
  713b76:	31 ff                	xor    %edi,%edi
  713b78:	4c 89 e6             	mov    %r12,%rsi
  713b7b:	ff 15 3f 43 3d 00    	call   *0x3d433f(%rip)        # ae7ec0 <_DYNAMIC+0x328>
  713b81:	48 8b 00             	mov    (%rax),%rax
  713b84:	48 8b 88 a0 00 00 00 	mov    0xa0(%rax),%rcx
  713b8b:	49 8b 17             	mov    (%r15),%rdx
  713b8e:	4a 8d 04 f5 08 00 00 	lea    0x8(,%r14,8),%rax
  713b95:	00 
  713b96:	48 8d 1c 40          	lea    (%rax,%rax,2),%rbx
  713b9a:	48 85 db             	test   %rbx,%rbx
  713b9d:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  713ba2:	74 65                	je     713c09 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x1b9>
  713ba4:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  713ba9:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  713bae:	4c 89 14 24          	mov    %r10,(%rsp)
  713bb2:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  713bb7:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  713bbc:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
  713bc1:	ff 15 31 42 3d 00    	call   *0x3d4231(%rip)        # ae7df8 <_DYNAMIC+0x260>
  713bc7:	be 08 00 00 00       	mov    $0x8,%esi
  713bcc:	49 89 dc             	mov    %rbx,%r12
  713bcf:	48 89 df             	mov    %rbx,%rdi
  713bd2:	ff 15 00 42 3d 00    	call   *0x3d4200(%rip)        # ae7dd8 <_DYNAMIC+0x240>
  713bd8:	bf 08 00 00 00       	mov    $0x8,%edi
  713bdd:	48 85 c0             	test   %rax,%rax
  713be0:	74 96                	je     713b78 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x128>
  713be2:	49 ff c6             	inc    %r14
  713be5:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  713bea:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  713bef:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
  713bf4:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  713bf9:	4c 8b 14 24          	mov    (%rsp),%r10
  713bfd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  713c02:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  713c07:	eb 08                	jmp    713c11 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x1c1>
  713c09:	b8 08 00 00 00       	mov    $0x8,%eax
  713c0e:	45 31 f6             	xor    %r14d,%r14d
  713c11:	48 89 10             	mov    %rdx,(%rax)
  713c14:	48 89 48 08          	mov    %rcx,0x8(%rax)
  713c18:	4c 89 78 10          	mov    %r15,0x10(%rax)
  713c1c:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
  713c21:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  713c26:	48 c7 44 24 38 01 00 	movq   $0x1,0x38(%rsp)
  713c2d:	00 00 
  713c2f:	48 8b 4e 20          	mov    0x20(%rsi),%rcx
  713c33:	48 89 0c 24          	mov    %rcx,(%rsp)
  713c37:	48 8b 4e 38          	mov    0x38(%rsi),%rcx
  713c3b:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
  713c40:	be 01 00 00 00       	mov    $0x1,%esi
  713c45:	eb 26                	jmp    713c6d <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x21d>
  713c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  713c4e:	00 00 
  713c50:	48 8d 0c 76          	lea    (%rsi,%rsi,2),%rcx
  713c54:	48 89 1c c8          	mov    %rbx,(%rax,%rcx,8)
  713c58:	48 89 54 c8 08       	mov    %rdx,0x8(%rax,%rcx,8)
  713c5d:	4c 89 4c c8 10       	mov    %r9,0x10(%rax,%rcx,8)
  713c62:	48 ff c6             	inc    %rsi
  713c65:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  713c6a:	4d 89 d9             	mov    %r11,%r9
  713c6d:	4d 85 d2             	test   %r10,%r10
  713c70:	74 09                	je     713c7b <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x22b>
  713c72:	49 39 ea             	cmp    %rbp,%r10
  713c75:	0f 85 94 00 00 00    	jne    713d0f <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2bf>
  713c7b:	4d 85 ed             	test   %r13,%r13
  713c7e:	74 44                	je     713cc4 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x274>
  713c80:	49 39 fd             	cmp    %rdi,%r13
  713c83:	74 3f                	je     713cc4 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x274>
  713c85:	49 81 c5 a8 00 00 00 	add    $0xa8,%r13
  713c8c:	0f 1f 40 00          	nopl   0x0(%rax)
  713c90:	49 8b 6d e8          	mov    -0x18(%r13),%rbp
  713c94:	48 85 ed             	test   %rbp,%rbp
  713c97:	75 60                	jne    713cf9 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2a9>
  713c99:	49 8d 8d a8 00 00 00 	lea    0xa8(%r13),%rcx
  713ca0:	49 39 fd             	cmp    %rdi,%r13
  713ca3:	49 89 cd             	mov    %rcx,%r13
  713ca6:	75 e8                	jne    713c90 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x240>
  713ca8:	48 8b a9 38 ff ff ff 	mov    -0xc8(%rcx),%rbp
  713caf:	48 8d 91 b0 fe ff ff 	lea    -0x150(%rcx),%rdx
  713cb6:	48 89 14 24          	mov    %rdx,(%rsp)
  713cba:	48 81 c1 58 ff ff ff 	add    $0xffffffffffffff58,%rcx
  713cc1:	49 89 cd             	mov    %rcx,%r13
  713cc4:	4d 85 c9             	test   %r9,%r9
  713cc7:	0f 84 ec 00 00 00    	je     713db9 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x369>
  713ccd:	4d 39 c1             	cmp    %r8,%r9
  713cd0:	0f 84 e3 00 00 00    	je     713db9 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x369>
  713cd6:	4d 8d 59 20          	lea    0x20(%r9),%r11
  713cda:	45 31 d2             	xor    %r10d,%r10d
  713cdd:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  713ce2:	48 8b 91 a0 00 00 00 	mov    0xa0(%rcx),%rdx
  713ce9:	49 8b 19             	mov    (%r9),%rbx
  713cec:	48 3b 74 24 28       	cmp    0x28(%rsp),%rsi
  713cf1:	0f 85 59 ff ff ff    	jne    713c50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  713cf7:	eb 39                	jmp    713d32 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x2e2>
  713cf9:	4d 8b 55 e0          	mov    -0x20(%r13),%r10
  713cfd:	48 c1 e5 05          	shl    $0x5,%rbp
  713d01:	4c 01 d5             	add    %r10,%rbp
  713d04:	49 8d 8d 58 ff ff ff 	lea    -0xa8(%r13),%rcx
  713d0b:	48 89 0c 24          	mov    %rcx,(%rsp)
  713d0f:	4d 89 cb             	mov    %r9,%r11
  713d12:	4d 89 d1             	mov    %r10,%r9
  713d15:	49 83 c2 20          	add    $0x20,%r10
  713d19:	48 8b 0c 24          	mov    (%rsp),%rcx
  713d1d:	48 8b 91 a0 00 00 00 	mov    0xa0(%rcx),%rdx
  713d24:	49 8b 19             	mov    (%r9),%rbx
  713d27:	48 3b 74 24 28       	cmp    0x28(%rsp),%rsi
  713d2c:	0f 85 1e ff ff ff    	jne    713c50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  713d32:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
  713d37:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  713d3c:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  713d41:	4d 89 c4             	mov    %r8,%r12
  713d44:	4c 89 c2             	mov    %r8,%rdx
  713d47:	4c 29 da             	sub    %r11,%rdx
  713d4a:	48 c1 ea 05          	shr    $0x5,%rdx
  713d4e:	48 89 e8             	mov    %rbp,%rax
  713d51:	4c 29 d0             	sub    %r10,%rax
  713d54:	48 c1 e8 05          	shr    $0x5,%rax
  713d58:	4d 85 d2             	test   %r10,%r10
  713d5b:	4d 89 d6             	mov    %r10,%r14
  713d5e:	49 0f 44 c2          	cmove  %r10,%rax
  713d62:	48 ff c2             	inc    %rdx
  713d65:	4d 89 df             	mov    %r11,%r15
  713d68:	4d 85 db             	test   %r11,%r11
  713d6b:	b9 01 00 00 00       	mov    $0x1,%ecx
  713d70:	48 0f 44 d1          	cmove  %rcx,%rdx
  713d74:	48 01 c2             	add    %rax,%rdx
  713d77:	b9 08 00 00 00       	mov    $0x8,%ecx
  713d7c:	41 b8 18 00 00 00    	mov    $0x18,%r8d
  713d82:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  713d87:	48 89 f3             	mov    %rsi,%rbx
  713d8a:	e8 11 24 01 00       	call   7261a0 <_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  713d8f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  713d94:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  713d99:	4d 89 e0             	mov    %r12,%r8
  713d9c:	4c 8b 4c 24 20       	mov    0x20(%rsp),%r9
  713da1:	4d 89 f2             	mov    %r14,%r10
  713da4:	48 89 de             	mov    %rbx,%rsi
  713da7:	4d 89 fb             	mov    %r15,%r11
  713daa:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  713daf:	48 8b 5c 24 10       	mov    0x10(%rsp),%rbx
  713db4:	e9 97 fe ff ff       	jmp    713c50 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x200>
  713db9:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  713dbe:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  713dc3:	48 89 48 10          	mov    %rcx,0x10(%rax)
  713dc7:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  713dcc:	0f 11 00             	movups %xmm0,(%rax)
  713dcf:	48 83 c4 58          	add    $0x58,%rsp
  713dd3:	5b                   	pop    %rbx
  713dd4:	41 5c                	pop    %r12
  713dd6:	41 5d                	pop    %r13
  713dd8:	41 5e                	pop    %r14
  713dda:	41 5f                	pop    %r15
  713ddc:	5d                   	pop    %rbp
  713ddd:	c3                   	ret
  713dde:	48 89 c3             	mov    %rax,%rbx
  713de1:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  713de6:	48 85 c0             	test   %rax,%rax
  713de9:	74 18                	je     713e03 <_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtBY_8RowDraftEEEINtB2_12SpecFromIterBT_INtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters7flatten7FlatMapINtNtNtB2j_5slice4iter4IterNtBY_9ListDraftEINtNtB2f_3map3MapIB37_B1w_ENCNCNvMst_NtB10_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB4i_s2_0EE9from_iterB4T_+0x3b3>
  713deb:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  713df0:	48 c1 e0 03          	shl    $0x3,%rax
  713df4:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  713df8:	ba 08 00 00 00       	mov    $0x8,%edx
  713dfd:	ff 15 dd 3f 3d 00    	call   *0x3d3fdd(%rip)        # ae7de0 <_DYNAMIC+0x248>
  713e03:	48 89 df             	mov    %rbx,%rdi
  713e06:	e8 45 47 3a 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
