
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000070e1a0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_>:
  70e1a0:	41 57                	push   %r15
  70e1a2:	41 56                	push   %r14
  70e1a4:	41 55                	push   %r13
  70e1a6:	41 54                	push   %r12
  70e1a8:	53                   	push   %rbx
  70e1a9:	48 8b 47 10          	mov    0x10(%rdi),%rax
  70e1ad:	48 8b 4f 30          	mov    0x30(%rdi),%rcx
  70e1b1:	45 31 db             	xor    %r11d,%r11d
  70e1b4:	45 31 c9             	xor    %r9d,%r9d
  70e1b7:	48 3b 07             	cmp    (%rdi),%rax
  70e1ba:	41 0f 93 c3          	setae  %r11b
  70e1be:	41 0f 92 c1          	setb   %r9b
  70e1c2:	45 31 c0             	xor    %r8d,%r8d
  70e1c5:	48 3b 4f 20          	cmp    0x20(%rdi),%rcx
  70e1c9:	41 0f 92 c0          	setb   %r8b
  70e1cd:	41 c1 e1 04          	shl    $0x4,%r9d
  70e1d1:	4a 8d 04 0f          	lea    (%rdi,%r9,1),%rax
  70e1d5:	41 c1 e3 04          	shl    $0x4,%r11d
  70e1d9:	4a 8d 0c 1f          	lea    (%rdi,%r11,1),%rcx
  70e1dd:	44 89 c3             	mov    %r8d,%ebx
  70e1e0:	c1 e3 04             	shl    $0x4,%ebx
  70e1e3:	4c 8d 14 1f          	lea    (%rdi,%rbx,1),%r10
  70e1e7:	49 83 c2 20          	add    $0x20,%r10
  70e1eb:	41 83 f0 03          	xor    $0x3,%r8d
  70e1ef:	41 c1 e0 04          	shl    $0x4,%r8d
  70e1f3:	48 8b 5c 1f 20       	mov    0x20(%rdi,%rbx,1),%rbx
  70e1f8:	4e 8b 34 07          	mov    (%rdi,%r8,1),%r14
  70e1fc:	4e 8b 1c 1f          	mov    (%rdi,%r11,1),%r11
  70e200:	4d 39 de             	cmp    %r11,%r14
  70e203:	49 89 cf             	mov    %rcx,%r15
  70e206:	4d 0f 42 fa          	cmovb  %r10,%r15
  70e20a:	4a 3b 1c 0f          	cmp    (%rdi,%r9,1),%rbx
  70e20e:	4c 0f 42 f8          	cmovb  %rax,%r15
  70e212:	49 0f 42 c2          	cmovb  %r10,%rax
  70e216:	4e 8d 04 07          	lea    (%rdi,%r8,1),%r8
  70e21a:	4c 0f 42 d1          	cmovb  %rcx,%r10
  70e21e:	4d 39 de             	cmp    %r11,%r14
  70e221:	49 0f 43 c8          	cmovae %r8,%rcx
  70e225:	4d 0f 42 d0          	cmovb  %r8,%r10
  70e229:	4d 8b 02             	mov    (%r10),%r8
  70e22c:	4d 3b 07             	cmp    (%r15),%r8
  70e22f:	4d 89 f8             	mov    %r15,%r8
  70e232:	4d 0f 42 c2          	cmovb  %r10,%r8
  70e236:	4d 0f 42 d7          	cmovb  %r15,%r10
  70e23a:	0f 10 00             	movups (%rax),%xmm0
  70e23d:	0f 11 02             	movups %xmm0,(%rdx)
  70e240:	41 0f 10 00          	movups (%r8),%xmm0
  70e244:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  70e248:	41 0f 10 02          	movups (%r10),%xmm0
  70e24c:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  70e250:	0f 10 01             	movups (%rcx),%xmm0
  70e253:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  70e257:	48 8b 47 50          	mov    0x50(%rdi),%rax
  70e25b:	48 8b 4f 70          	mov    0x70(%rdi),%rcx
  70e25f:	45 31 db             	xor    %r11d,%r11d
  70e262:	45 31 d2             	xor    %r10d,%r10d
  70e265:	48 3b 47 40          	cmp    0x40(%rdi),%rax
  70e269:	41 0f 93 c3          	setae  %r11b
  70e26d:	41 0f 92 c2          	setb   %r10b
  70e271:	45 31 c0             	xor    %r8d,%r8d
  70e274:	48 3b 4f 60          	cmp    0x60(%rdi),%rcx
  70e278:	41 0f 92 c0          	setb   %r8b
  70e27c:	41 c1 e2 04          	shl    $0x4,%r10d
  70e280:	4a 8d 04 17          	lea    (%rdi,%r10,1),%rax
  70e284:	48 83 c0 40          	add    $0x40,%rax
  70e288:	41 c1 e3 04          	shl    $0x4,%r11d
  70e28c:	4a 8d 0c 1f          	lea    (%rdi,%r11,1),%rcx
  70e290:	48 83 c1 40          	add    $0x40,%rcx
  70e294:	44 89 c3             	mov    %r8d,%ebx
  70e297:	c1 e3 04             	shl    $0x4,%ebx
  70e29a:	4c 8d 0c 1f          	lea    (%rdi,%rbx,1),%r9
  70e29e:	49 83 c1 60          	add    $0x60,%r9
  70e2a2:	41 83 f0 03          	xor    $0x3,%r8d
  70e2a6:	41 c1 e0 04          	shl    $0x4,%r8d
  70e2aa:	48 8b 5c 1f 60       	mov    0x60(%rdi,%rbx,1),%rbx
  70e2af:	4e 8b 74 07 40       	mov    0x40(%rdi,%r8,1),%r14
  70e2b4:	4e 8b 5c 1f 40       	mov    0x40(%rdi,%r11,1),%r11
  70e2b9:	4d 39 de             	cmp    %r11,%r14
  70e2bc:	49 89 cf             	mov    %rcx,%r15
  70e2bf:	4d 0f 42 f9          	cmovb  %r9,%r15
  70e2c3:	4a 3b 5c 17 40       	cmp    0x40(%rdi,%r10,1),%rbx
  70e2c8:	4c 0f 42 f8          	cmovb  %rax,%r15
  70e2cc:	49 0f 42 c1          	cmovb  %r9,%rax
  70e2d0:	4c 0f 42 c9          	cmovb  %rcx,%r9
  70e2d4:	4d 39 de             	cmp    %r11,%r14
  70e2d7:	4a 8d 7c 07 40       	lea    0x40(%rdi,%r8,1),%rdi
  70e2dc:	48 0f 43 cf          	cmovae %rdi,%rcx
  70e2e0:	4c 0f 42 cf          	cmovb  %rdi,%r9
  70e2e4:	49 8b 39             	mov    (%r9),%rdi
  70e2e7:	49 3b 3f             	cmp    (%r15),%rdi
  70e2ea:	48 8d 7a 40          	lea    0x40(%rdx),%rdi
  70e2ee:	4d 89 f8             	mov    %r15,%r8
  70e2f1:	4d 0f 42 c1          	cmovb  %r9,%r8
  70e2f5:	4d 0f 42 cf          	cmovb  %r15,%r9
  70e2f9:	0f 10 00             	movups (%rax),%xmm0
  70e2fc:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  70e300:	41 0f 10 00          	movups (%r8),%xmm0
  70e304:	0f 11 42 50          	movups %xmm0,0x50(%rdx)
  70e308:	41 0f 10 01          	movups (%r9),%xmm0
  70e30c:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  70e310:	0f 10 01             	movups (%rcx),%xmm0
  70e313:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
  70e317:	48 8b 42 40          	mov    0x40(%rdx),%rax
  70e31b:	31 c9                	xor    %ecx,%ecx
  70e31d:	45 31 db             	xor    %r11d,%r11d
  70e320:	48 3b 02             	cmp    (%rdx),%rax
  70e323:	0f 93 c1             	setae  %cl
  70e326:	41 0f 92 c3          	setb   %r11b
  70e32a:	48 0f 43 fa          	cmovae %rdx,%rdi
  70e32e:	0f 10 07             	movups (%rdi),%xmm0
  70e331:	0f 11 06             	movups %xmm0,(%rsi)
  70e334:	48 8b 7a 70          	mov    0x70(%rdx),%rdi
  70e338:	4c 8b 42 30          	mov    0x30(%rdx),%r8
  70e33c:	31 c0                	xor    %eax,%eax
  70e33e:	4c 39 c7             	cmp    %r8,%rdi
  70e341:	41 b9 00 00 00 00    	mov    $0x0,%r9d
  70e347:	49 83 d1 ff          	adc    $0xffffffffffffffff,%r9
  70e34b:	4c 39 c7             	cmp    %r8,%rdi
  70e34e:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  70e354:	4d 19 d2             	sbb    %r10,%r10
  70e357:	48 8d 5a 30          	lea    0x30(%rdx),%rbx
  70e35b:	4c 8d 72 70          	lea    0x70(%rdx),%r14
  70e35f:	4c 39 c7             	cmp    %r8,%rdi
  70e362:	4c 0f 42 f3          	cmovb  %rbx,%r14
  70e366:	41 c1 e3 04          	shl    $0x4,%r11d
  70e36a:	4a 8d 3c 1a          	lea    (%rdx,%r11,1),%rdi
  70e36e:	48 83 c7 40          	add    $0x40,%rdi
  70e372:	c1 e1 04             	shl    $0x4,%ecx
  70e375:	41 0f 10 06          	movups (%r14),%xmm0
  70e379:	0f 11 46 70          	movups %xmm0,0x70(%rsi)
  70e37d:	4c 8d 04 0a          	lea    (%rdx,%rcx,1),%r8
  70e381:	49 c1 e1 04          	shl    $0x4,%r9
  70e385:	49 c1 e2 04          	shl    $0x4,%r10
  70e389:	4a 8b 5c 1a 40       	mov    0x40(%rdx,%r11,1),%rbx
  70e38e:	45 31 ff             	xor    %r15d,%r15d
  70e391:	45 31 db             	xor    %r11d,%r11d
  70e394:	48 3b 1c 0a          	cmp    (%rdx,%rcx,1),%rbx
  70e398:	41 0f 93 c7          	setae  %r15b
  70e39c:	41 0f 92 c3          	setb   %r11b
  70e3a0:	4c 89 c1             	mov    %r8,%rcx
  70e3a3:	48 0f 42 cf          	cmovb  %rdi,%rcx
  70e3a7:	0f 10 01             	movups (%rcx),%xmm0
  70e3aa:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
  70e3ae:	4a 8b 5c 0a 70       	mov    0x70(%rdx,%r9,1),%rbx
  70e3b3:	4e 8b 74 12 30       	mov    0x30(%rdx,%r10,1),%r14
  70e3b8:	4c 39 f3             	cmp    %r14,%rbx
  70e3bb:	b9 00 00 00 00       	mov    $0x0,%ecx
  70e3c0:	48 83 d1 ff          	adc    $0xffffffffffffffff,%rcx
  70e3c4:	4c 39 f3             	cmp    %r14,%rbx
  70e3c7:	4e 8d 74 0a 70       	lea    0x70(%rdx,%r9,1),%r14
  70e3cc:	4a 8d 5c 12 30       	lea    0x30(%rdx,%r10,1),%rbx
  70e3d1:	4d 89 f2             	mov    %r14,%r10
  70e3d4:	4c 0f 42 d3          	cmovb  %rbx,%r10
  70e3d8:	ba 00 00 00 00       	mov    $0x0,%edx
  70e3dd:	48 19 d2             	sbb    %rdx,%rdx
  70e3e0:	41 c1 e3 04          	shl    $0x4,%r11d
  70e3e4:	4e 8d 0c 1f          	lea    (%rdi,%r11,1),%r9
  70e3e8:	41 c1 e7 04          	shl    $0x4,%r15d
  70e3ec:	41 0f 10 02          	movups (%r10),%xmm0
  70e3f0:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  70e3f4:	4f 8d 14 38          	lea    (%r8,%r15,1),%r10
  70e3f8:	48 c1 e1 04          	shl    $0x4,%rcx
  70e3fc:	48 c1 e2 04          	shl    $0x4,%rdx
  70e400:	49 8b 3c 3b          	mov    (%r11,%rdi,1),%rdi
  70e404:	45 31 db             	xor    %r11d,%r11d
  70e407:	45 31 e4             	xor    %r12d,%r12d
  70e40a:	4b 3b 3c 07          	cmp    (%r15,%r8,1),%rdi
  70e40e:	41 0f 93 c3          	setae  %r11b
  70e412:	41 0f 92 c4          	setb   %r12b
  70e416:	4c 89 d7             	mov    %r10,%rdi
  70e419:	49 0f 42 f9          	cmovb  %r9,%rdi
  70e41d:	0f 10 07             	movups (%rdi),%xmm0
  70e420:	0f 11 46 20          	movups %xmm0,0x20(%rsi)
  70e424:	4e 8b 3c 31          	mov    (%rcx,%r14,1),%r15
  70e428:	4c 8b 2c 1a          	mov    (%rdx,%rbx,1),%r13
  70e42c:	4d 39 ef             	cmp    %r13,%r15
  70e42f:	bf 00 00 00 00       	mov    $0x0,%edi
  70e434:	48 83 d7 ff          	adc    $0xffffffffffffffff,%rdi
  70e438:	4d 39 ef             	cmp    %r13,%r15
  70e43b:	41 b8 00 00 00 00    	mov    $0x0,%r8d
  70e441:	4d 19 c0             	sbb    %r8,%r8
  70e444:	4c 01 f1             	add    %r14,%rcx
  70e447:	48 01 da             	add    %rbx,%rdx
  70e44a:	4d 39 ef             	cmp    %r13,%r15
  70e44d:	48 89 cb             	mov    %rcx,%rbx
  70e450:	48 0f 42 da          	cmovb  %rdx,%rbx
  70e454:	41 c1 e4 04          	shl    $0x4,%r12d
  70e458:	4f 8d 3c 21          	lea    (%r9,%r12,1),%r15
  70e45c:	41 c1 e3 04          	shl    $0x4,%r11d
  70e460:	0f 10 03             	movups (%rbx),%xmm0
  70e463:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  70e467:	4b 8d 1c 1a          	lea    (%r10,%r11,1),%rbx
  70e46b:	48 c1 e7 04          	shl    $0x4,%rdi
  70e46f:	49 c1 e0 04          	shl    $0x4,%r8
  70e473:	4f 8b 24 0c          	mov    (%r12,%r9,1),%r12
  70e477:	45 31 c9             	xor    %r9d,%r9d
  70e47a:	45 31 f6             	xor    %r14d,%r14d
  70e47d:	4f 3b 24 13          	cmp    (%r11,%r10,1),%r12
  70e481:	41 0f 93 c1          	setae  %r9b
  70e485:	41 0f 92 c6          	setb   %r14b
  70e489:	49 89 da             	mov    %rbx,%r10
  70e48c:	4d 0f 42 d7          	cmovb  %r15,%r10
  70e490:	41 0f 10 02          	movups (%r10),%xmm0
  70e494:	0f 11 46 30          	movups %xmm0,0x30(%rsi)
  70e498:	4c 8b 1c 0f          	mov    (%rdi,%rcx,1),%r11
  70e49c:	4d 8b 24 10          	mov    (%r8,%rdx,1),%r12
  70e4a0:	4d 39 e3             	cmp    %r12,%r11
  70e4a3:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  70e4a9:	49 83 d2 ff          	adc    $0xffffffffffffffff,%r10
  70e4ad:	4d 39 e3             	cmp    %r12,%r11
  70e4b0:	48 19 c0             	sbb    %rax,%rax
  70e4b3:	48 01 cf             	add    %rcx,%rdi
  70e4b6:	49 01 d0             	add    %rdx,%r8
  70e4b9:	4d 39 e3             	cmp    %r12,%r11
  70e4bc:	48 89 f9             	mov    %rdi,%rcx
  70e4bf:	49 0f 42 c8          	cmovb  %r8,%rcx
  70e4c3:	41 c1 e6 04          	shl    $0x4,%r14d
  70e4c7:	4d 01 fe             	add    %r15,%r14
  70e4ca:	41 c1 e1 04          	shl    $0x4,%r9d
  70e4ce:	0f 10 01             	movups (%rcx),%xmm0
  70e4d1:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  70e4d5:	49 01 d9             	add    %rbx,%r9
  70e4d8:	49 c1 e2 04          	shl    $0x4,%r10
  70e4dc:	48 c1 e0 04          	shl    $0x4,%rax
  70e4e0:	4a 8d 0c 00          	lea    (%rax,%r8,1),%rcx
  70e4e4:	48 83 c1 10          	add    $0x10,%rcx
  70e4e8:	49 8d 04 3a          	lea    (%r10,%rdi,1),%rax
  70e4ec:	48 83 c0 10          	add    $0x10,%rax
  70e4f0:	49 39 c6             	cmp    %rax,%r14
  70e4f3:	0f 95 c0             	setne  %al
  70e4f6:	49 39 c9             	cmp    %rcx,%r9
  70e4f9:	75 0e                	jne    70e509 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x369>
  70e4fb:	84 c0                	test   %al,%al
  70e4fd:	75 10                	jne    70e50f <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x36f>
  70e4ff:	5b                   	pop    %rbx
  70e500:	41 5c                	pop    %r12
  70e502:	41 5d                	pop    %r13
  70e504:	41 5e                	pop    %r14
  70e506:	41 5f                	pop    %r15
  70e508:	c3                   	ret
  70e509:	b0 01                	mov    $0x1,%al
  70e50b:	84 c0                	test   %al,%al
  70e50d:	74 f0                	je     70e4ff <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort12sort8_stableTjNtNtCshBhuxcId5D0_4gpui4list6ListIdENCINvMNtCscdodAO9FK5_5alloc5sliceSB19_7sort_byNCINvXs1o_NtNtNtB1T_11collections5btree3mapINtB2F_8BTreeMapjB1b_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB19_E9from_iterINtNtNtB3F_8adapters3map3MapINtNtB8_4iter4IterNtB1d_9ListDraftENCNvMst_NtB1f_7runtimeINtB5G_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners1_0EE0E0EB6b_+0x35f>
  70e50f:	ff 15 5b 9d 3d 00    	call   *0x3d9d5b(%rip)        # ae8270 <_DYNAMIC+0x6d8>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
