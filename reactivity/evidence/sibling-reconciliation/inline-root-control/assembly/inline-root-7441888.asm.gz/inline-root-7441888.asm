
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000718de0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_>:
  718de0:	55                   	push   %rbp
  718de1:	41 57                	push   %r15
  718de3:	41 56                	push   %r14
  718de5:	41 55                	push   %r13
  718de7:	41 54                	push   %r12
  718de9:	53                   	push   %rbx
  718dea:	48 83 ec 78          	sub    $0x78,%rsp
  718dee:	48 89 fb             	mov    %rdi,%rbx
  718df1:	4c 8b 2e             	mov    (%rsi),%r13
  718df4:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718df8:	4c 8b 7e 20          	mov    0x20(%rsi),%r15
  718dfc:	4c 8b 66 28          	mov    0x28(%rsi),%r12
  718e00:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718e07:	00 
  718e08:	48 85 c0             	test   %rax,%rax
  718e0b:	0f 84 2a 01 00 00    	je     718f3b <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15b>
  718e11:	49 89 f6             	mov    %rsi,%r14
  718e14:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  718e18:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  718e1d:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718e24:	49 39 cc             	cmp    %rcx,%r12
  718e27:	72 31                	jb     718e5a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7a>
  718e29:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  718e30:	48 8b a8 60 01 00 00 	mov    0x160(%rax),%rbp
  718e37:	48 85 ed             	test   %rbp,%rbp
  718e3a:	0f 84 fb 00 00 00    	je     718f3b <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15b>
  718e40:	49 ff c7             	inc    %r15
  718e43:	44 0f b7 a0 c0 01 00 	movzwl 0x1c0(%rax),%r12d
  718e4a:	00 
  718e4b:	48 89 e8             	mov    %rbp,%rax
  718e4e:	66 44 3b a5 c2 01 00 	cmp    0x1c2(%rbp),%r12w
  718e55:	00 
  718e56:	73 d8                	jae    718e30 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x50>
  718e58:	eb 03                	jmp    718e5d <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7d>
  718e5a:	48 89 c5             	mov    %rax,%rbp
  718e5d:	4a 8b b4 e5 68 01 00 	mov    0x168(%rbp,%r12,8),%rsi
  718e64:	00 
  718e65:	49 8b 45 00          	mov    0x0(%r13),%rax
  718e69:	48 8b 38             	mov    (%rax),%rdi
  718e6c:	ff 15 1e f4 3c 00    	call   *0x3cf41e(%rip)        # ae8290 <_DYNAMIC+0x6f8>
  718e72:	84 c0                	test   %al,%al
  718e74:	0f 84 d8 00 00 00    	je     718f52 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x172>
  718e7a:	4d 85 ff             	test   %r15,%r15
  718e7d:	0f 84 83 00 00 00    	je     718f06 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x126>
  718e83:	4a 8d 04 e5 d0 01 00 	lea    0x1d0(,%r12,8),%rax
  718e8a:	00 
  718e8b:	48 01 e8             	add    %rbp,%rax
  718e8e:	4c 89 f9             	mov    %r15,%rcx
  718e91:	48 83 e1 07          	and    $0x7,%rcx
  718e95:	0f 84 95 00 00 00    	je     718f30 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x150>
  718e9b:	31 d2                	xor    %edx,%edx
  718e9d:	0f 1f 00             	nopl   (%rax)
  718ea0:	48 8b 28             	mov    (%rax),%rbp
  718ea3:	48 8d 85 c8 01 00 00 	lea    0x1c8(%rbp),%rax
  718eaa:	48 ff c2             	inc    %rdx
  718ead:	48 39 d1             	cmp    %rdx,%rcx
  718eb0:	75 ee                	jne    718ea0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xc0>
  718eb2:	4c 89 f9             	mov    %r15,%rcx
  718eb5:	48 29 d1             	sub    %rdx,%rcx
  718eb8:	49 83 ff 08          	cmp    $0x8,%r15
  718ebc:	72 43                	jb     718f01 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x121>
  718ebe:	66 90                	xchg   %ax,%ax
  718ec0:	48 8b 00             	mov    (%rax),%rax
  718ec3:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718eca:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718ed1:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718ed8:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718edf:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718ee6:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718eed:	48 8b a8 c8 01 00 00 	mov    0x1c8(%rax),%rbp
  718ef4:	48 8d 85 c8 01 00 00 	lea    0x1c8(%rbp),%rax
  718efb:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  718eff:	75 bf                	jne    718ec0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xe0>
  718f01:	45 31 e4             	xor    %r12d,%r12d
  718f04:	eb 03                	jmp    718f09 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x129>
  718f06:	49 ff c4             	inc    %r12
  718f09:	4d 89 66 28          	mov    %r12,0x28(%r14)
  718f0d:	0f 57 c0             	xorps  %xmm0,%xmm0
  718f10:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  718f15:	45 31 ff             	xor    %r15d,%r15d
  718f18:	48 89 e8             	mov    %rbp,%rax
  718f1b:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718f22:	49 39 cc             	cmp    %rcx,%r12
  718f25:	0f 83 05 ff ff ff    	jae    718e30 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x50>
  718f2b:	e9 2a ff ff ff       	jmp    718e5a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x7a>
  718f30:	4c 89 f9             	mov    %r15,%rcx
  718f33:	49 83 ff 08          	cmp    $0x8,%r15
  718f37:	73 87                	jae    718ec0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0xe0>
  718f39:	eb c6                	jmp    718f01 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x121>
  718f3b:	31 c0                	xor    %eax,%eax
  718f3d:	48 89 03             	mov    %rax,(%rbx)
  718f40:	48 89 d8             	mov    %rbx,%rax
  718f43:	48 83 c4 78          	add    $0x78,%rsp
  718f47:	5b                   	pop    %rbx
  718f48:	41 5c                	pop    %r12
  718f4a:	41 5d                	pop    %r13
  718f4c:	41 5e                	pop    %r14
  718f4e:	41 5f                	pop    %r15
  718f50:	5d                   	pop    %rbp
  718f51:	c3                   	ret
  718f52:	49 8b 46 08          	mov    0x8(%r14),%rax
  718f56:	48 ff 08             	decq   (%rax)
  718f59:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  718f5e:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
  718f63:	4c 89 64 24 20       	mov    %r12,0x20(%rsp)
  718f68:	49 83 c6 10          	add    $0x10,%r14
  718f6c:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  718f71:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  718f76:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  718f7b:	4c 89 f2             	mov    %r14,%rdx
  718f7e:	e8 9d 2a fd ff       	call   6eba20 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1M_13GeometryStyleENtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB3K_14ExtractIfInneryB1J_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3K_INtB3K_8BTreeMapyB1J_E6retainNCINvMsi_B1M_INtB1M_9OverridesB2o_E6retainNCNvMst_NtB1O_7runtimeINtB6E_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtB9_5alloc6GlobalE0B8k_EB79_>
  718f83:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  718f88:	48 89 43 28          	mov    %rax,0x28(%rbx)
  718f8c:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  718f91:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  718f96:	0f 11 4b 18          	movups %xmm1,0x18(%rbx)
  718f9a:	0f 11 43 08          	movups %xmm0,0x8(%rbx)
  718f9e:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  718fa3:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  718fa8:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  718fad:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  718fb2:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  718fb7:	48 89 41 10          	mov    %rax,0x10(%rcx)
  718fbb:	0f 11 01             	movups %xmm0,(%rcx)
  718fbe:	b8 01 00 00 00       	mov    $0x1,%eax
  718fc3:	e9 75 ff ff ff       	jmp    718f3d <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1b_13GeometryStyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_INtB1b_9OverridesB1N_E6retainNCNvMst_NtB1d_7runtimeINtB4k_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0ENtNtNtNtB2f_4iter6traits8iterator8Iterator4nextB4P_+0x15d>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
