
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000730030 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_>:
  730030:	41 57                	push   %r15
  730032:	41 56                	push   %r14
  730034:	41 55                	push   %r13
  730036:	41 54                	push   %r12
  730038:	53                   	push   %rbx
  730039:	48 81 ec 40 01 00 00 	sub    $0x140,%rsp
  730040:	48 89 fb             	mov    %rdi,%rbx
  730043:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  730048:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  73004d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  730052:	48 8b 07             	mov    (%rdi),%rax
  730055:	48 85 c0             	test   %rax,%rax
  730058:	74 46                	je     7300a0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x70>
  73005a:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
  73005e:	48 85 c9             	test   %rcx,%rcx
  730061:	0f 84 97 00 00 00    	je     7300fe <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0xce>
  730067:	48 89 ca             	mov    %rcx,%rdx
  73006a:	48 83 e2 07          	and    $0x7,%rdx
  73006e:	74 36                	je     7300a6 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x76>
  730070:	31 f6                	xor    %esi,%esi
  730072:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  730079:	1f 84 00 00 00 00 00 
  730080:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  730087:	48 ff c6             	inc    %rsi
  73008a:	48 39 f2             	cmp    %rsi,%rdx
  73008d:	75 f1                	jne    730080 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x50>
  73008f:	48 89 ca             	mov    %rcx,%rdx
  730092:	48 29 f2             	sub    %rsi,%rdx
  730095:	48 89 de             	mov    %rbx,%rsi
  730098:	48 83 f9 08          	cmp    $0x8,%rcx
  73009c:	73 22                	jae    7300c0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x90>
  73009e:	eb 61                	jmp    730101 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0xd1>
  7300a0:	31 c0                	xor    %eax,%eax
  7300a2:	31 f6                	xor    %esi,%esi
  7300a4:	eb 5b                	jmp    730101 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0xd1>
  7300a6:	48 89 ca             	mov    %rcx,%rdx
  7300a9:	48 89 de             	mov    %rbx,%rsi
  7300ac:	48 83 f9 08          	cmp    $0x8,%rcx
  7300b0:	72 4f                	jb     730101 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0xd1>
  7300b2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  7300b9:	1f 84 00 00 00 00 00 
  7300c0:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7300c7:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7300ce:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7300d5:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7300dc:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7300e3:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7300ea:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7300f1:	48 8b 80 38 05 00 00 	mov    0x538(%rax),%rax
  7300f8:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
  7300fc:	75 c2                	jne    7300c0 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x90>
  7300fe:	48 89 de             	mov    %rbx,%rsi
  730101:	4c 8d 6b 10          	lea    0x10(%rbx),%r13
  730105:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
  73010a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  73010f:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  730114:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  730119:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  73011e:	0f 57 c0             	xorps  %xmm0,%xmm0
  730121:	0f 11 44 24 38       	movups %xmm0,0x38(%rsp)
  730126:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  73012b:	48 8d 74 24 18       	lea    0x18(%rsp),%rsi
  730130:	e8 9b 8e fe ff       	call   718fd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>
  730135:	83 7c 24 50 02       	cmpl   $0x2,0x50(%rsp)
  73013a:	0f 84 b2 00 00 00    	je     7301f2 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x1c2>
  730140:	4c 8d b4 24 20 01 00 	lea    0x120(%rsp),%r14
  730147:	00 
  730148:	4c 8d 7c 24 48       	lea    0x48(%rsp),%r15
  73014d:	4c 8d 64 24 18       	lea    0x18(%rsp),%r12
  730152:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  730159:	1f 84 00 00 00 00 00 
  730160:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  730167:	00 
  730168:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  73016f:	00 
  730170:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
  730177:	00 
  730178:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  73017f:	00 
  730180:	0f 10 84 24 98 00 00 	movups 0x98(%rsp),%xmm0
  730187:	00 
  730188:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
  73018f:	00 
  730190:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  730197:	00 
  730198:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  73019f:	00 
  7301a0:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  7301a5:	0f 10 4c 24 58       	movups 0x58(%rsp),%xmm1
  7301aa:	0f 10 54 24 68       	movups 0x68(%rsp),%xmm2
  7301af:	0f 10 5c 24 78       	movups 0x78(%rsp),%xmm3
  7301b4:	0f 29 9c 24 f0 00 00 	movaps %xmm3,0xf0(%rsp)
  7301bb:	00 
  7301bc:	0f 29 94 24 e0 00 00 	movaps %xmm2,0xe0(%rsp)
  7301c3:	00 
  7301c4:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
  7301cb:	00 
  7301cc:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  7301d3:	00 
  7301d4:	4c 89 f7             	mov    %r14,%rdi
  7301d7:	e8 74 79 fe ff       	call   717b50 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  7301dc:	4c 89 ff             	mov    %r15,%rdi
  7301df:	4c 89 e6             	mov    %r12,%rsi
  7301e2:	e8 e9 8d fe ff       	call   718fd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB1d_5style5StyleENtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCINvMsi_B1b_NtB1b_9Overrides6retainNCNvMst_NtB1d_7runtimeINtB4d_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0E0E0ENtNtNtNtB2e_4iter6traits8iterator8Iterator4nextB4I_>
  7301e7:	83 7c 24 50 02       	cmpl   $0x2,0x50(%rsp)
  7301ec:	0f 85 6e ff ff ff    	jne    730160 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x130>
  7301f2:	49 83 7d 00 00       	cmpq   $0x0,0x0(%r13)
  7301f7:	75 17                	jne    730210 <_RINvMsi_NtCshBhuxcId5D0_4gpui8propertyNtB6_9Overrides6retainNCNvMst_NtB8_7runtimeINtB14_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersJ_0EB1y_+0x1e0>
  7301f9:	48 89 df             	mov    %rbx,%rdi
  7301fc:	e8 1f 89 fe ff       	call   718b20 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtNtB19_5style5StyleEENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  730201:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  730208:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  73020f:	00 
  730210:	48 81 c4 40 01 00 00 	add    $0x140,%rsp
  730217:	5b                   	pop    %rbx
  730218:	41 5c                	pop    %r12
  73021a:	41 5d                	pop    %r13
  73021c:	41 5e                	pop    %r14
  73021e:	41 5f                	pop    %r15
  730220:	c3                   	ret
  730221:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  730228:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  73022f:	00 
  730230:	48 89 c7             	mov    %rax,%rdi
  730233:	e8 18 83 38 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
