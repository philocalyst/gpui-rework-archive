
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

000000000071f3b0 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_>:
  71f3b0:	41 57                	push   %r15
  71f3b2:	41 56                	push   %r14
  71f3b4:	41 54                	push   %r12
  71f3b6:	53                   	push   %rbx
  71f3b7:	50                   	push   %rax
  71f3b8:	48 89 fb             	mov    %rdi,%rbx
  71f3bb:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
  71f3bf:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  71f3c3:	48 89 c8             	mov    %rcx,%rax
  71f3c6:	4c 29 f8             	sub    %r15,%rax
  71f3c9:	48 c1 e8 03          	shr    $0x3,%rax
  71f3cd:	48 ba 31 0c c3 30 0c 	movabs $0xc30c30c30c30c31,%rdx
  71f3d4:	c3 30 0c 
  71f3d7:	48 f7 e2             	mul    %rdx
  71f3da:	4c 39 f9             	cmp    %r15,%rcx
  71f3dd:	74 6a                	je     71f449 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x99>
  71f3df:	49 89 d6             	mov    %rdx,%r14
  71f3e2:	49 81 c7 88 00 00 00 	add    $0x88,%r15
  71f3e9:	4c 8b 25 f0 89 3c 00 	mov    0x3c89f0(%rip),%r12        # ae7de0 <_DYNAMIC+0x248>
  71f3f0:	eb 1a                	jmp    71f40c <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x5c>
  71f3f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  71f3f9:	1f 84 00 00 00 00 00 
  71f400:	49 81 c7 a8 00 00 00 	add    $0xa8,%r15
  71f407:	49 ff ce             	dec    %r14
  71f40a:	74 3d                	je     71f449 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x99>
  71f40c:	41 83 bf 78 ff ff ff 	cmpl   $0x2,-0x88(%r15)
  71f413:	02 
  71f414:	74 ea                	je     71f400 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71f416:	49 8b 77 90          	mov    -0x70(%r15),%rsi
  71f41a:	48 85 f6             	test   %rsi,%rsi
  71f41d:	74 10                	je     71f42f <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x7f>
  71f41f:	49 8b 7f 98          	mov    -0x68(%r15),%rdi
  71f423:	48 c1 e6 03          	shl    $0x3,%rsi
  71f427:	ba 08 00 00 00       	mov    $0x8,%edx
  71f42c:	41 ff d4             	call   *%r12
  71f42f:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  71f433:	48 85 f6             	test   %rsi,%rsi
  71f436:	74 c8                	je     71f400 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71f438:	49 8b 3f             	mov    (%r15),%rdi
  71f43b:	48 c1 e6 05          	shl    $0x5,%rsi
  71f43f:	ba 08 00 00 00       	mov    $0x8,%edx
  71f444:	41 ff d4             	call   *%r12
  71f447:	eb b7                	jmp    71f400 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0x50>
  71f449:	48 8b 43 10          	mov    0x10(%rbx),%rax
  71f44d:	48 85 c0             	test   %rax,%rax
  71f450:	74 20                	je     71f472 <_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtNtB4_4iter8adapters10filter_map9FilterMapINtNtNtCscdodAO9FK5_5alloc3vec9into_iter8IntoIterNtNtCshBhuxcId5D0_4gpui4list13ViewportDraftENCNvMst_NtB2e_7runtimeINtB30_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners0_0EEB3v_+0xc2>
  71f452:	48 8b 3b             	mov    (%rbx),%rdi
  71f455:	48 69 f0 a8 00 00 00 	imul   $0xa8,%rax,%rsi
  71f45c:	ba 08 00 00 00       	mov    $0x8,%edx
  71f461:	48 83 c4 08          	add    $0x8,%rsp
  71f465:	5b                   	pop    %rbx
  71f466:	41 5c                	pop    %r12
  71f468:	41 5e                	pop    %r14
  71f46a:	41 5f                	pop    %r15
  71f46c:	ff 25 6e 89 3c 00    	jmp    *0x3c896e(%rip)        # ae7de0 <_DYNAMIC+0x248>
  71f472:	48 83 c4 08          	add    $0x8,%rsp
  71f476:	5b                   	pop    %rbx
  71f477:	41 5c                	pop    %r12
  71f479:	41 5e                	pop    %r14
  71f47b:	41 5f                	pop    %r15
  71f47d:	c3                   	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
