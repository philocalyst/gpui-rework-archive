
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000006f1cc0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_>:
  6f1cc0:	55                   	push   %rbp
  6f1cc1:	41 57                	push   %r15
  6f1cc3:	41 56                	push   %r14
  6f1cc5:	41 55                	push   %r13
  6f1cc7:	41 54                	push   %r12
  6f1cc9:	53                   	push   %rbx
  6f1cca:	48 81 ec 58 01 00 00 	sub    $0x158,%rsp
  6f1cd1:	48 89 94 24 98 00 00 	mov    %rdx,0x98(%rsp)
  6f1cd8:	00 
  6f1cd9:	49 89 f7             	mov    %rsi,%r15
  6f1cdc:	48 89 bc 24 a8 00 00 	mov    %rdi,0xa8(%rsp)
  6f1ce3:	00 
  6f1ce4:	48 8b 2e             	mov    (%rsi),%rbp
  6f1ce7:	4c 8b 6e 10          	mov    0x10(%rsi),%r13
  6f1ceb:	0f b7 9d c2 01 00 00 	movzwl 0x1c2(%rbp),%ebx
  6f1cf2:	4a 8d bc ed 68 01 00 	lea    0x168(%rbp,%r13,8),%rdi
  6f1cf9:	00 
  6f1cfa:	4a 8b 84 ed 68 01 00 	mov    0x168(%rbp,%r13,8),%rax
  6f1d01:	00 
  6f1d02:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6f1d07:	4a 8d 34 ed 70 01 00 	lea    0x170(,%r13,8),%rsi
  6f1d0e:	00 
  6f1d0f:	48 01 ee             	add    %rbp,%rsi
  6f1d12:	4d 89 ec             	mov    %r13,%r12
  6f1d15:	49 f7 d4             	not    %r12
  6f1d18:	49 01 dc             	add    %rbx,%r12
  6f1d1b:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
  6f1d22:	00 
  6f1d23:	4c 8b 35 d6 60 3f 00 	mov    0x3f60d6(%rip),%r14        # ae7e00 <memmove@GLIBC_2.2.5>
  6f1d2a:	41 ff d6             	call   *%r14
  6f1d2d:	4c 89 6c 24 08       	mov    %r13,0x8(%rsp)
  6f1d32:	4c 89 e8             	mov    %r13,%rax
  6f1d35:	48 c1 e0 05          	shl    $0x5,%rax
  6f1d39:	48 8d 3c 28          	lea    (%rax,%rbp,1),%rdi
  6f1d3d:	0f 10 44 05 00       	movups 0x0(%rbp,%rax,1),%xmm0
  6f1d42:	0f 10 4c 05 10       	movups 0x10(%rbp,%rax,1),%xmm1
  6f1d47:	0f 11 8c 24 e8 00 00 	movups %xmm1,0xe8(%rsp)
  6f1d4e:	00 
  6f1d4f:	0f 11 84 24 d8 00 00 	movups %xmm0,0xd8(%rsp)
  6f1d56:	00 
  6f1d57:	48 8d 34 28          	lea    (%rax,%rbp,1),%rsi
  6f1d5b:	48 83 c6 20          	add    $0x20,%rsi
  6f1d5f:	49 c1 e4 05          	shl    $0x5,%r12
  6f1d63:	4c 89 e2             	mov    %r12,%rdx
  6f1d66:	41 ff d6             	call   *%r14
  6f1d69:	8d 43 ff             	lea    -0x1(%rbx),%eax
  6f1d6c:	66 89 85 c2 01 00 00 	mov    %ax,0x1c2(%rbp)
  6f1d73:	4d 8b 67 08          	mov    0x8(%r15),%r12
  6f1d77:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6f1d7c:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6f1d83:	00 
  6f1d84:	66 83 f8 04          	cmp    $0x4,%ax
  6f1d88:	0f 87 55 01 00 00    	ja     6f1ee3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f1d8e:	48 8b 85 60 01 00 00 	mov    0x160(%rbp),%rax
  6f1d95:	48 85 c0             	test   %rax,%rax
  6f1d98:	0f 84 03 01 00 00    	je     6f1ea1 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1e1>
  6f1d9e:	49 8d 4c 24 01       	lea    0x1(%r12),%rcx
  6f1da3:	0f b7 95 c0 01 00 00 	movzwl 0x1c0(%rbp),%edx
  6f1daa:	48 85 d2             	test   %rdx,%rdx
  6f1dad:	74 5e                	je     6f1e0d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x14d>
  6f1daf:	48 8b b4 d0 c0 01 00 	mov    0x1c0(%rax,%rdx,8),%rsi
  6f1db6:	00 
  6f1db7:	48 ff ca             	dec    %rdx
  6f1dba:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f1dbf:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f1dc4:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  6f1dc9:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
  6f1dce:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
  6f1dd3:	48 89 6c 24 68       	mov    %rbp,0x68(%rsp)
  6f1dd8:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  6f1ddd:	0f b7 86 c2 01 00 00 	movzwl 0x1c2(%rsi),%eax
  6f1de4:	01 c3                	add    %eax,%ebx
  6f1de6:	83 fb 0c             	cmp    $0xc,%ebx
  6f1de9:	0f 83 80 00 00 00    	jae    6f1e6f <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1af>
  6f1def:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  6f1df4:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  6f1df9:	ba 01 00 00 00       	mov    $0x1,%edx
  6f1dfe:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f1e03:	e8 a8 a2 ff ff       	call   6ec0b0 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1e08:	e9 a8 00 00 00       	jmp    6f1eb5 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f5>
  6f1e0d:	66 83 b8 c2 01 00 00 	cmpw   $0x0,0x1c2(%rax)
  6f1e14:	00 
  6f1e15:	0f 84 d4 06 00 00    	je     6f24ef <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x82f>
  6f1e1b:	48 8b 90 d0 01 00 00 	mov    0x1d0(%rax),%rdx
  6f1e22:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6f1e27:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
  6f1e2c:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6f1e33:	00 00 
  6f1e35:	48 89 6c 24 58       	mov    %rbp,0x58(%rsp)
  6f1e3a:	4c 89 64 24 60       	mov    %r12,0x60(%rsp)
  6f1e3f:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
  6f1e44:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  6f1e49:	0f b7 82 c2 01 00 00 	movzwl 0x1c2(%rdx),%eax
  6f1e50:	01 c3                	add    %eax,%ebx
  6f1e52:	83 fb 0c             	cmp    $0xc,%ebx
  6f1e55:	73 3b                	jae    6f1e92 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1d2>
  6f1e57:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  6f1e5c:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
  6f1e61:	31 d2                	xor    %edx,%edx
  6f1e63:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  6f1e68:	e8 43 a2 ff ff       	call   6ec0b0 <_RINvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB7_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1p_11shared_text10SharedTextEEj2_E25merge_tracking_child_edgeNtNtBd_5alloc6GlobalECs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1e6d:	eb 46                	jmp    6f1eb5 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f5>
  6f1e6f:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f1e74:	be 01 00 00 00       	mov    $0x1,%esi
  6f1e79:	e8 a2 15 00 00       	call   6f3420 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1e7e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1e83:	48 ff c0             	inc    %rax
  6f1e86:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
  6f1e8b:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  6f1e90:	eb 1e                	jmp    6f1eb0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x1f0>
  6f1e92:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f1e97:	be 01 00 00 00       	mov    $0x1,%esi
  6f1e9c:	e8 bf 18 00 00       	call   6f3760 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f1ea1:	48 89 6c 24 28       	mov    %rbp,0x28(%rsp)
  6f1ea6:	4c 89 64 24 30       	mov    %r12,0x30(%rsp)
  6f1eab:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1eb0:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6f1eb5:	48 8b 6c 24 28       	mov    0x28(%rsp),%rbp
  6f1eba:	4c 8b 64 24 30       	mov    0x30(%rsp),%r12
  6f1ebf:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6f1ec4:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6f1ec9:	4c 8b b5 60 01 00 00 	mov    0x160(%rbp),%r14
  6f1ed0:	4d 85 f6             	test   %r14,%r14
  6f1ed3:	74 0e                	je     6f1ee3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f1ed5:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f1edc:	00 
  6f1edd:	66 83 f8 04          	cmp    $0x4,%ax
  6f1ee1:	76 5a                	jbe    6f1f3d <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x27d>
  6f1ee3:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  6f1eea:	00 
  6f1eeb:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
  6f1ef2:	00 
  6f1ef3:	48 89 42 20          	mov    %rax,0x20(%rdx)
  6f1ef7:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6f1efe:	00 
  6f1eff:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
  6f1f06:	00 
  6f1f07:	0f 10 84 24 e0 00 00 	movups 0xe0(%rsp),%xmm0
  6f1f0e:	00 
  6f1f0f:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  6f1f13:	48 89 02             	mov    %rax,(%rdx)
  6f1f16:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
  6f1f1a:	48 89 6a 28          	mov    %rbp,0x28(%rdx)
  6f1f1e:	4c 89 62 30          	mov    %r12,0x30(%rdx)
  6f1f22:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6f1f27:	48 89 42 38          	mov    %rax,0x38(%rdx)
  6f1f2b:	48 81 c4 58 01 00 00 	add    $0x158,%rsp
  6f1f32:	5b                   	pop    %rbx
  6f1f33:	41 5c                	pop    %r12
  6f1f35:	41 5d                	pop    %r13
  6f1f37:	41 5e                	pop    %r14
  6f1f39:	41 5f                	pop    %r15
  6f1f3b:	5d                   	pop    %rbp
  6f1f3c:	c3                   	ret
  6f1f3d:	4d 8d 6c 24 01       	lea    0x1(%r12),%r13
  6f1f42:	48 8d 0d 57 7a 3c 00 	lea    0x3c7a57(%rip),%rcx        # ab99a0 <__frame_dummy_init_array_entry+0x98>
  6f1f49:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6f1f50:	00 
  6f1f51:	48 8d 0d 64 16 97 ff 	lea    -0x68e99c(%rip),%rcx        # 635bc <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x20a>
  6f1f58:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  6f1f5d:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  6f1f64:	00 
  6f1f65:	4c 89 a4 24 88 00 00 	mov    %r12,0x88(%rsp)
  6f1f6c:	00 
  6f1f6d:	eb 21                	jmp    6f1f90 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2d0>
  6f1f6f:	90                   	nop
  6f1f70:	ba 08 00 00 00       	mov    $0x8,%edx
  6f1f75:	4c 89 ff             	mov    %r15,%rdi
  6f1f78:	ff 15 62 5e 3f 00    	call   *0x3f5e62(%rip)        # ae7de0 <_DYNAMIC+0x248>
  6f1f7e:	41 0f b7 86 c2 01 00 	movzwl 0x1c2(%r14),%eax
  6f1f85:	00 
  6f1f86:	66 83 f8 04          	cmp    $0x4,%ax
  6f1f8a:	0f 87 53 ff ff ff    	ja     6f1ee3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f1f90:	4c 89 f1             	mov    %r14,%rcx
  6f1f93:	0f b7 c0             	movzwl %ax,%eax
  6f1f96:	4d 8b b6 60 01 00 00 	mov    0x160(%r14),%r14
  6f1f9d:	4d 85 f6             	test   %r14,%r14
  6f1fa0:	0f 84 96 04 00 00    	je     6f243c <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x77c>
  6f1fa6:	4c 89 ee             	mov    %r13,%rsi
  6f1fa9:	49 8d 7d 01          	lea    0x1(%r13),%rdi
  6f1fad:	44 0f b7 b9 c0 01 00 	movzwl 0x1c0(%rcx),%r15d
  6f1fb4:	00 
  6f1fb5:	4d 85 ff             	test   %r15,%r15
  6f1fb8:	48 89 bc 24 c8 00 00 	mov    %rdi,0xc8(%rsp)
  6f1fbf:	00 
  6f1fc0:	0f 84 8a 00 00 00    	je     6f2050 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x390>
  6f1fc6:	4b 8b 9c fe c0 01 00 	mov    0x1c0(%r14,%r15,8),%rbx
  6f1fcd:	00 
  6f1fce:	49 ff cf             	dec    %r15
  6f1fd1:	4c 89 b4 24 f8 00 00 	mov    %r14,0xf8(%rsp)
  6f1fd8:	00 
  6f1fd9:	48 89 bc 24 00 01 00 	mov    %rdi,0x100(%rsp)
  6f1fe0:	00 
  6f1fe1:	4c 89 bc 24 08 01 00 	mov    %r15,0x108(%rsp)
  6f1fe8:	00 
  6f1fe9:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
  6f1ff0:	00 
  6f1ff1:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
  6f1ff8:	00 
  6f1ff9:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  6f2000:	00 
  6f2001:	48 89 b4 24 28 01 00 	mov    %rsi,0x128(%rsp)
  6f2008:	00 
  6f2009:	0f b7 b3 c2 01 00 00 	movzwl 0x1c2(%rbx),%esi
  6f2010:	8d 14 30             	lea    (%rax,%rsi,1),%edx
  6f2013:	ff c2                	inc    %edx
  6f2015:	83 fa 0c             	cmp    $0xc,%edx
  6f2018:	0f 83 86 04 00 00    	jae    6f24a4 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x7e4>
  6f201e:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f2025:	00 
  6f2026:	48 8d 7e 01          	lea    0x1(%rsi),%rdi
  6f202a:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  6f202f:	48 89 f5             	mov    %rsi,%rbp
  6f2032:	48 01 c6             	add    %rax,%rsi
  6f2035:	48 ff c6             	inc    %rsi
  6f2038:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6f203d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6f2042:	e9 7d 00 00 00       	jmp    6f20c4 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x404>
  6f2047:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  6f204e:	00 00 
  6f2050:	41 0f b7 96 c2 01 00 	movzwl 0x1c2(%r14),%edx
  6f2057:	00 
  6f2058:	66 85 d2             	test   %dx,%dx
  6f205b:	0f 84 8e 04 00 00    	je     6f24ef <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x82f>
  6f2061:	4d 8b 86 d0 01 00 00 	mov    0x1d0(%r14),%r8
  6f2068:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
  6f206d:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
  6f2072:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  6f2079:	00 00 
  6f207b:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6f2080:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  6f2085:	4c 89 44 24 68       	mov    %r8,0x68(%rsp)
  6f208a:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  6f208f:	45 0f b7 88 c2 01 00 	movzwl 0x1c2(%r8),%r9d
  6f2096:	00 
  6f2097:	4a 8d 34 08          	lea    (%rax,%r9,1),%rsi
  6f209b:	48 ff c6             	inc    %rsi
  6f209e:	48 83 fe 0c          	cmp    $0xc,%rsi
  6f20a2:	0f 83 16 04 00 00    	jae    6f24be <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x7fe>
  6f20a8:	48 8d 78 01          	lea    0x1(%rax),%rdi
  6f20ac:	48 89 7c 24 18       	mov    %rdi,0x18(%rsp)
  6f20b1:	48 89 cb             	mov    %rcx,%rbx
  6f20b4:	4c 89 44 24 10       	mov    %r8,0x10(%rsp)
  6f20b9:	45 31 ff             	xor    %r15d,%r15d
  6f20bc:	48 89 c5             	mov    %rax,%rbp
  6f20bf:	4c 89 4c 24 20       	mov    %r9,0x20(%rsp)
  6f20c4:	0f b7 c2             	movzwl %dx,%eax
  6f20c7:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6f20ce:	00 
  6f20cf:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
  6f20d6:	00 
  6f20d7:	66 89 b3 c2 01 00 00 	mov    %si,0x1c2(%rbx)
  6f20de:	4b 8d 3c fe          	lea    (%r14,%r15,8),%rdi
  6f20e2:	48 81 c7 68 01 00 00 	add    $0x168,%rdi
  6f20e9:	4f 8b ac fe 68 01 00 	mov    0x168(%r14,%r15,8),%r13
  6f20f0:	00 
  6f20f1:	4b 8d 34 fe          	lea    (%r14,%r15,8),%rsi
  6f20f5:	48 81 c6 70 01 00 00 	add    $0x170,%rsi
  6f20fc:	4d 89 fc             	mov    %r15,%r12
  6f20ff:	49 f7 d4             	not    %r12
  6f2102:	49 01 c4             	add    %rax,%r12
  6f2105:	4a 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%rdx
  6f210c:	00 
  6f210d:	48 89 94 24 b8 00 00 	mov    %rdx,0xb8(%rsp)
  6f2114:	00 
  6f2115:	48 8b 05 e4 5c 3f 00 	mov    0x3f5ce4(%rip),%rax        # ae7e00 <memmove@GLIBC_2.2.5>
  6f211c:	ff d0                	call   *%rax
  6f211e:	4c 89 ac eb 68 01 00 	mov    %r13,0x168(%rbx,%rbp,8)
  6f2125:	00 
  6f2126:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6f212b:	48 8d b0 68 01 00 00 	lea    0x168(%rax),%rsi
  6f2132:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6f2137:	48 8d bc c3 68 01 00 	lea    0x168(%rbx,%rax,8),%rdi
  6f213e:	00 
  6f213f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6f2144:	8d 14 c5 00 00 00 00 	lea    0x0(,%rax,8),%edx
  6f214b:	4c 8b 2d b6 5c 3f 00 	mov    0x3f5cb6(%rip),%r13        # ae7e08 <memcpy@GLIBC_2.14>
  6f2152:	41 ff d5             	call   *%r13
  6f2155:	4c 89 f8             	mov    %r15,%rax
  6f2158:	48 c1 e0 05          	shl    $0x5,%rax
  6f215c:	49 8d 3c 06          	lea    (%r14,%rax,1),%rdi
  6f2160:	41 0f 10 04 06       	movups (%r14,%rax,1),%xmm0
  6f2165:	41 0f 10 4c 06 10    	movups 0x10(%r14,%rax,1),%xmm1
  6f216b:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  6f2172:	00 
  6f2173:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  6f217a:	00 
  6f217b:	49 8d 34 06          	lea    (%r14,%rax,1),%rsi
  6f217f:	48 83 c6 20          	add    $0x20,%rsi
  6f2183:	49 c1 e4 05          	shl    $0x5,%r12
  6f2187:	4c 89 e2             	mov    %r12,%rdx
  6f218a:	4c 8b 2d 6f 5c 3f 00 	mov    0x3f5c6f(%rip),%r13        # ae7e00 <memmove@GLIBC_2.2.5>
  6f2191:	41 ff d5             	call   *%r13
  6f2194:	48 89 ac 24 b0 00 00 	mov    %rbp,0xb0(%rsp)
  6f219b:	00 
  6f219c:	c1 e5 05             	shl    $0x5,%ebp
  6f219f:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  6f21a6:	00 
  6f21a7:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
  6f21ae:	00 
  6f21af:	0f 11 04 2b          	movups %xmm0,(%rbx,%rbp,1)
  6f21b3:	0f 11 4c 2b 10       	movups %xmm1,0x10(%rbx,%rbp,1)
  6f21b8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  6f21bd:	c1 e7 05             	shl    $0x5,%edi
  6f21c0:	48 01 df             	add    %rbx,%rdi
  6f21c3:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f21c8:	c1 e2 05             	shl    $0x5,%edx
  6f21cb:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  6f21d0:	ff 15 32 5c 3f 00    	call   *0x3f5c32(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  6f21d6:	4d 8d 67 01          	lea    0x1(%r15),%r12
  6f21da:	4b 8d 3c fe          	lea    (%r14,%r15,8),%rdi
  6f21de:	48 81 c7 d0 01 00 00 	add    $0x1d0,%rdi
  6f21e5:	4b 8d 34 fe          	lea    (%r14,%r15,8),%rsi
  6f21e9:	48 81 c6 d8 01 00 00 	add    $0x1d8,%rsi
  6f21f0:	48 8b 94 24 b8 00 00 	mov    0xb8(%rsp),%rdx
  6f21f7:	00 
  6f21f8:	41 ff d5             	call   *%r13
  6f21fb:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6f2202:	00 
  6f2203:	4c 39 e6             	cmp    %r12,%rsi
  6f2206:	4c 8b ac 24 c8 00 00 	mov    0xc8(%rsp),%r13
  6f220d:	00 
  6f220e:	0f 86 c6 00 00 00    	jbe    6f22da <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f2214:	89 f1                	mov    %esi,%ecx
  6f2216:	44 29 e1             	sub    %r12d,%ecx
  6f2219:	83 e1 03             	and    $0x3,%ecx
  6f221c:	0f 84 fe 01 00 00    	je     6f2420 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x760>
  6f2222:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f2229:	1f 84 00 00 00 00 00 
  6f2230:	49 8d 44 24 01       	lea    0x1(%r12),%rax
  6f2235:	4b 8b 94 e6 c8 01 00 	mov    0x1c8(%r14,%r12,8),%rdx
  6f223c:	00 
  6f223d:	4c 89 b2 60 01 00 00 	mov    %r14,0x160(%rdx)
  6f2244:	66 44 89 a2 c0 01 00 	mov    %r12w,0x1c0(%rdx)
  6f224b:	00 
  6f224c:	49 89 c4             	mov    %rax,%r12
  6f224f:	48 ff c9             	dec    %rcx
  6f2252:	75 dc                	jne    6f2230 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x570>
  6f2254:	49 f7 df             	neg    %r15
  6f2257:	4a 8d 0c 3e          	lea    (%rsi,%r15,1),%rcx
  6f225b:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f225f:	83 f9 03             	cmp    $0x3,%ecx
  6f2262:	72 76                	jb     6f22da <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f2264:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f226b:	00 00 00 00 00 
  6f2270:	49 8b 8c c6 c8 01 00 	mov    0x1c8(%r14,%rax,8),%rcx
  6f2277:	00 
  6f2278:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f227f:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f2286:	49 8b 8c c6 d0 01 00 	mov    0x1d0(%r14,%rax,8),%rcx
  6f228d:	00 
  6f228e:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f2295:	8d 50 01             	lea    0x1(%rax),%edx
  6f2298:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f229f:	49 8b 8c c6 d8 01 00 	mov    0x1d8(%r14,%rax,8),%rcx
  6f22a6:	00 
  6f22a7:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f22ae:	8d 50 02             	lea    0x2(%rax),%edx
  6f22b1:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f22b8:	49 8b 8c c6 e0 01 00 	mov    0x1e0(%r14,%rax,8),%rcx
  6f22bf:	00 
  6f22c0:	4c 89 b1 60 01 00 00 	mov    %r14,0x160(%rcx)
  6f22c7:	8d 50 03             	lea    0x3(%rax),%edx
  6f22ca:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f22d1:	48 83 c0 04          	add    $0x4,%rax
  6f22d5:	48 39 f0             	cmp    %rsi,%rax
  6f22d8:	75 96                	jne    6f2270 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x5b0>
  6f22da:	66 41 ff 8e c2 01 00 	decw   0x1c2(%r14)
  6f22e1:	00 
  6f22e2:	be c8 01 00 00       	mov    $0x1c8,%esi
  6f22e7:	49 83 fd 02          	cmp    $0x2,%r13
  6f22eb:	48 8b ac 24 a0 00 00 	mov    0xa0(%rsp),%rbp
  6f22f2:	00 
  6f22f3:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
  6f22fa:	00 
  6f22fb:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  6f2300:	0f 82 6a fc ff ff    	jb     6f1f70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f2306:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6f230b:	48 ff c2             	inc    %rdx
  6f230e:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6f2315:	00 
  6f2316:	48 2b 84 24 b0 00 00 	sub    0xb0(%rsp),%rax
  6f231d:	00 
  6f231e:	48 39 c2             	cmp    %rax,%rdx
  6f2321:	0f 85 ae 01 00 00    	jne    6f24d5 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x815>
  6f2327:	48 8d 83 c8 01 00 00 	lea    0x1c8(%rbx),%rax
  6f232e:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  6f2333:	4a 8d 3c e0          	lea    (%rax,%r12,8),%rdi
  6f2337:	49 8d b7 c8 01 00 00 	lea    0x1c8(%r15),%rsi
  6f233e:	c1 e2 03             	shl    $0x3,%edx
  6f2341:	ff 15 c1 5a 3f 00    	call   *0x3f5ac1(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  6f2347:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  6f234e:	00 
  6f234f:	89 f9                	mov    %edi,%ecx
  6f2351:	44 29 e1             	sub    %r12d,%ecx
  6f2354:	ff c1                	inc    %ecx
  6f2356:	4c 89 e0             	mov    %r12,%rax
  6f2359:	83 e1 03             	and    $0x3,%ecx
  6f235c:	74 34                	je     6f2392 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6d2>
  6f235e:	4c 89 e2             	mov    %r12,%rdx
  6f2361:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  6f2368:	0f 1f 84 00 00 00 00 
  6f236f:	00 
  6f2370:	48 8d 42 01          	lea    0x1(%rdx),%rax
  6f2374:	48 8b b4 d3 c8 01 00 	mov    0x1c8(%rbx,%rdx,8),%rsi
  6f237b:	00 
  6f237c:	48 89 9e 60 01 00 00 	mov    %rbx,0x160(%rsi)
  6f2383:	66 89 96 c0 01 00 00 	mov    %dx,0x1c0(%rsi)
  6f238a:	48 89 c2             	mov    %rax,%rdx
  6f238d:	48 ff c9             	dec    %rcx
  6f2390:	75 de                	jne    6f2370 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6b0>
  6f2392:	48 89 f9             	mov    %rdi,%rcx
  6f2395:	4c 29 e1             	sub    %r12,%rcx
  6f2398:	be 28 02 00 00       	mov    $0x228,%esi
  6f239d:	83 f9 03             	cmp    $0x3,%ecx
  6f23a0:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
  6f23a7:	00 
  6f23a8:	0f 82 c2 fb ff ff    	jb     6f1f70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f23ae:	66 90                	xchg   %ax,%ax
  6f23b0:	48 8b 8c c3 c8 01 00 	mov    0x1c8(%rbx,%rax,8),%rcx
  6f23b7:	00 
  6f23b8:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f23bf:	66 89 81 c0 01 00 00 	mov    %ax,0x1c0(%rcx)
  6f23c6:	48 8b 8c c3 d0 01 00 	mov    0x1d0(%rbx,%rax,8),%rcx
  6f23cd:	00 
  6f23ce:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f23d5:	8d 50 01             	lea    0x1(%rax),%edx
  6f23d8:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f23df:	48 8b 8c c3 d8 01 00 	mov    0x1d8(%rbx,%rax,8),%rcx
  6f23e6:	00 
  6f23e7:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f23ee:	8d 50 02             	lea    0x2(%rax),%edx
  6f23f1:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f23f8:	48 8b 8c c3 e0 01 00 	mov    0x1e0(%rbx,%rax,8),%rcx
  6f23ff:	00 
  6f2400:	48 89 99 60 01 00 00 	mov    %rbx,0x160(%rcx)
  6f2407:	48 8d 50 03          	lea    0x3(%rax),%rdx
  6f240b:	66 89 91 c0 01 00 00 	mov    %dx,0x1c0(%rcx)
  6f2412:	48 83 c0 04          	add    $0x4,%rax
  6f2416:	48 39 fa             	cmp    %rdi,%rdx
  6f2419:	75 95                	jne    6f23b0 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x6f0>
  6f241b:	e9 50 fb ff ff       	jmp    6f1f70 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x2b0>
  6f2420:	4c 89 e0             	mov    %r12,%rax
  6f2423:	49 f7 df             	neg    %r15
  6f2426:	4a 8d 0c 3e          	lea    (%rsi,%r15,1),%rcx
  6f242a:	48 83 c1 fe          	add    $0xfffffffffffffffe,%rcx
  6f242e:	83 f9 03             	cmp    $0x3,%ecx
  6f2431:	0f 83 39 fe ff ff    	jae    6f2270 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x5b0>
  6f2437:	e9 9e fe ff ff       	jmp    6f22da <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x61a>
  6f243c:	48 85 c0             	test   %rax,%rax
  6f243f:	0f 85 9e fa ff ff    	jne    6f1ee3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f2445:	4c 8b b4 24 98 00 00 	mov    0x98(%rsp),%r14
  6f244c:	00 
  6f244d:	49 8b 1e             	mov    (%r14),%rbx
  6f2450:	49 c7 06 00 00 00 00 	movq   $0x0,(%r14)
  6f2457:	48 85 db             	test   %rbx,%rbx
  6f245a:	0f 84 aa 00 00 00    	je     6f250a <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x84a>
  6f2460:	48 8b 43 08          	mov    0x8(%rbx),%rax
  6f2464:	48 85 c0             	test   %rax,%rax
  6f2467:	0f 84 ac 00 00 00    	je     6f2519 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x859>
  6f246d:	48 8b 3b             	mov    (%rbx),%rdi
  6f2470:	48 8b 8f c8 01 00 00 	mov    0x1c8(%rdi),%rcx
  6f2477:	48 89 0b             	mov    %rcx,(%rbx)
  6f247a:	48 ff c8             	dec    %rax
  6f247d:	48 89 43 08          	mov    %rax,0x8(%rbx)
  6f2481:	48 c7 81 60 01 00 00 	movq   $0x0,0x160(%rcx)
  6f2488:	00 00 00 00 
  6f248c:	be 28 02 00 00       	mov    $0x228,%esi
  6f2491:	ba 08 00 00 00       	mov    $0x8,%edx
  6f2496:	ff 15 44 59 3f 00    	call   *0x3f5944(%rip)        # ae7de0 <_DYNAMIC+0x248>
  6f249c:	49 89 1e             	mov    %rbx,(%r14)
  6f249f:	e9 3f fa ff ff       	jmp    6f1ee3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f24a4:	be 05 00 00 00       	mov    $0x5,%esi
  6f24a9:	48 29 c6             	sub    %rax,%rsi
  6f24ac:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  6f24b3:	00 
  6f24b4:	e8 67 0f 00 00       	call   6f3420 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E15bulk_steal_leftCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f24b9:	e9 25 fa ff ff       	jmp    6f1ee3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f24be:	be 05 00 00 00       	mov    $0x5,%esi
  6f24c3:	48 29 c6             	sub    %rax,%rsi
  6f24c6:	48 8d 7c 24 40       	lea    0x40(%rsp),%rdi
  6f24cb:	e8 90 12 00 00       	call   6f3760 <_RNvMs10_NtNtNtCscdodAO9FK5_5alloc11collections5btree4nodeINtB6_16BalancingContextyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1o_11shared_text10SharedTextEEj2_E16bulk_steal_rightCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f24d0:	e9 0e fa ff ff       	jmp    6f1ee3 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x223>
  6f24d5:	be 28 00 00 00       	mov    $0x28,%esi
  6f24da:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  6f24df:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  6f24e6:	00 
  6f24e7:	ff 15 2b 59 3f 00    	call   *0x3f592b(%rip)        # ae7e18 <_DYNAMIC+0x280>
  6f24ed:	eb 28                	jmp    6f2517 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x857>
  6f24ef:	48 8d 3d e3 11 97 ff 	lea    -0x68ee1d(%rip),%rdi        # 636d9 <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x327>
  6f24f6:	48 8d 15 ab 75 3c 00 	lea    0x3c75ab(%rip),%rdx        # ab9aa8 <__frame_dummy_init_array_entry+0x1a0>
  6f24fd:	be 7b 00 00 00       	mov    $0x7b,%esi
  6f2502:	ff 15 30 59 3f 00    	call   *0x3f5930(%rip)        # ae7e38 <_DYNAMIC+0x2a0>
  6f2508:	eb 0d                	jmp    6f2517 <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x857>
  6f250a:	48 8d 3d a7 74 3c 00 	lea    0x3c74a7(%rip),%rdi        # ab99b8 <__frame_dummy_init_array_entry+0xb0>
  6f2511:	ff 15 09 59 3f 00    	call   *0x3f5909(%rip)        # ae7e20 <_DYNAMIC+0x288>
  6f2517:	0f 0b                	ud2
  6f2519:	48 8d 05 68 74 3c 00 	lea    0x3c7468(%rip),%rax        # ab9988 <__frame_dummy_init_array_entry+0x80>
  6f2520:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6f2527:	00 
  6f2528:	be 21 00 00 00       	mov    $0x21,%esi
  6f252d:	48 8d 05 67 10 97 ff 	lea    -0x68ef99(%rip),%rax        # 6359b <anon.c45b175f03bc4a8e35c2fa0979443901.27.llvm.11789694239044747101+0x1e9>
  6f2534:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  6f2539:	eb 9f                	jmp    6f24da <_RINvMs_NtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB7_4node6HandleINtBX_7NodeRefNtNtBX_6marker3MutyINtNtCshBhuxcId5D0_4gpui8property7OverlayNtB1O_13GeometryStyleENtB1u_4LeafENtB1u_2KVE14remove_leaf_kvNCINvMsV_NtB7_3mapINtB3x_14ExtractIfInneryB1L_NtNtNtCs4NRVxsYgnAr_4core3ops5range9RangeFullE4nextNCINvMsi_B3x_INtB3x_8BTreeMapyB1L_E6retainNCINvMsi_B1O_INtB1O_9OverridesB2q_E6retainNCNvMst_NtB1Q_7runtimeINtB6r_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersL_0E0E0NtNtBb_5alloc6GlobalE0B87_EB6W_+0x81a>
  6f253b:	48 89 c3             	mov    %rax,%rbx
  6f253e:	48 8d bc 24 d8 00 00 	lea    0xd8(%rsp),%rdi
  6f2545:	00 
  6f2546:	e8 05 56 02 00       	call   717b50 <_RNvXNtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtCshBhuxcId5D0_4gpui8property10PropertyIdNtB15_13PropertyValueENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs4gwBMgNbBwV_27sibling_reconciliation_cost>
  6f254b:	48 89 df             	mov    %rbx,%rdi
  6f254e:	e8 fd 5f 3c 00       	call   ab8550 <_Unwind_Resume@plt>
  6f2553:	ff 15 d7 58 3f 00    	call   *0x3f58d7(%rip)        # ae7e30 <_DYNAMIC+0x298>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
