
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

00000000007119b0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_>:
  7119b0:	55                   	push   %rbp
  7119b1:	41 57                	push   %r15
  7119b3:	41 56                	push   %r14
  7119b5:	41 55                	push   %r13
  7119b7:	41 54                	push   %r12
  7119b9:	53                   	push   %rbx
  7119ba:	48 83 ec 38          	sub    $0x38,%rsp
  7119be:	48 83 fe 02          	cmp    $0x2,%rsi
  7119c2:	0f 82 76 04 00 00    	jb     711e3e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x48e>
  7119c8:	48 8d 46 10          	lea    0x10(%rsi),%rax
  7119cc:	48 39 c1             	cmp    %rax,%rcx
  7119cf:	0f 82 c8 04 00 00    	jb     711e9d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4ed>
  7119d5:	48 89 d3             	mov    %rdx,%rbx
  7119d8:	48 89 f5             	mov    %rsi,%rbp
  7119db:	48 d1 ed             	shr    $1,%rbp
  7119de:	48 83 fe 07          	cmp    $0x7,%rsi
  7119e2:	0f 86 b3 01 00 00    	jbe    711b9b <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x1eb>
  7119e8:	48 8b 4f 18          	mov    0x18(%rdi),%rcx
  7119ec:	48 8b 57 48          	mov    0x48(%rdi),%rdx
  7119f0:	45 31 c0             	xor    %r8d,%r8d
  7119f3:	45 31 d2             	xor    %r10d,%r10d
  7119f6:	48 3b 0f             	cmp    (%rdi),%rcx
  7119f9:	41 0f 93 c0          	setae  %r8b
  7119fd:	41 0f 92 c2          	setb   %r10b
  711a01:	48 8d 47 48          	lea    0x48(%rdi),%rax
  711a05:	4c 8d 4f 30          	lea    0x30(%rdi),%r9
  711a09:	48 3b 57 30          	cmp    0x30(%rdi),%rdx
  711a0d:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  711a11:	4e 8d 34 d7          	lea    (%rdi,%r10,8),%r14
  711a15:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  711a19:	4c 89 ca             	mov    %r9,%rdx
  711a1c:	48 0f 42 d0          	cmovb  %rax,%rdx
  711a20:	4a 8d 0c c7          	lea    (%rdi,%r8,8),%rcx
  711a24:	49 0f 42 c1          	cmovb  %r9,%rax
  711a28:	4c 8b 0a             	mov    (%rdx),%r9
  711a2b:	4c 8b 18             	mov    (%rax),%r11
  711a2e:	4e 8b 04 c7          	mov    (%rdi,%r8,8),%r8
  711a32:	4d 39 c3             	cmp    %r8,%r11
  711a35:	49 89 cf             	mov    %rcx,%r15
  711a38:	4c 0f 42 fa          	cmovb  %rdx,%r15
  711a3c:	4e 3b 0c d7          	cmp    (%rdi,%r10,8),%r9
  711a40:	4d 0f 42 fe          	cmovb  %r14,%r15
  711a44:	4c 0f 42 f2          	cmovb  %rdx,%r14
  711a48:	48 0f 42 d1          	cmovb  %rcx,%rdx
  711a4c:	4d 39 c3             	cmp    %r8,%r11
  711a4f:	48 0f 43 c8          	cmovae %rax,%rcx
  711a53:	48 0f 42 d0          	cmovb  %rax,%rdx
  711a57:	48 8b 02             	mov    (%rdx),%rax
  711a5a:	49 3b 07             	cmp    (%r15),%rax
  711a5d:	4c 89 f8             	mov    %r15,%rax
  711a60:	48 0f 42 c2          	cmovb  %rdx,%rax
  711a64:	49 0f 42 d7          	cmovb  %r15,%rdx
  711a68:	4d 8b 46 10          	mov    0x10(%r14),%r8
  711a6c:	4c 89 43 10          	mov    %r8,0x10(%rbx)
  711a70:	41 0f 10 06          	movups (%r14),%xmm0
  711a74:	0f 11 03             	movups %xmm0,(%rbx)
  711a77:	4c 8b 40 10          	mov    0x10(%rax),%r8
  711a7b:	4c 89 43 28          	mov    %r8,0x28(%rbx)
  711a7f:	0f 10 00             	movups (%rax),%xmm0
  711a82:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
  711a86:	48 8b 42 10          	mov    0x10(%rdx),%rax
  711a8a:	48 89 43 40          	mov    %rax,0x40(%rbx)
  711a8e:	0f 10 02             	movups (%rdx),%xmm0
  711a91:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  711a95:	48 8d 14 ed 00 00 00 	lea    0x0(,%rbp,8),%rdx
  711a9c:	00 
  711a9d:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  711aa1:	4c 8d 0c 17          	lea    (%rdi,%rdx,1),%r9
  711aa5:	4c 8b 44 17 18       	mov    0x18(%rdi,%rdx,1),%r8
  711aaa:	48 8b 44 17 48       	mov    0x48(%rdi,%rdx,1),%rax
  711aaf:	45 31 d2             	xor    %r10d,%r10d
  711ab2:	45 31 db             	xor    %r11d,%r11d
  711ab5:	4c 3b 04 17          	cmp    (%rdi,%rdx,1),%r8
  711ab9:	41 0f 93 c2          	setae  %r10b
  711abd:	41 0f 92 c3          	setb   %r11b
  711ac1:	4c 8d 04 17          	lea    (%rdi,%rdx,1),%r8
  711ac5:	49 83 c0 48          	add    $0x48,%r8
  711ac9:	4c 8d 3c 17          	lea    (%rdi,%rdx,1),%r15
  711acd:	49 83 c7 30          	add    $0x30,%r15
  711ad1:	48 3b 44 17 30       	cmp    0x30(%rdi,%rdx,1),%rax
  711ad6:	4f 8d 1c 5b          	lea    (%r11,%r11,2),%r11
  711ada:	4f 8d 14 52          	lea    (%r10,%r10,2),%r10
  711ade:	4f 8d 34 d1          	lea    (%r9,%r10,8),%r14
  711ae2:	4c 89 f8             	mov    %r15,%rax
  711ae5:	49 0f 42 c0          	cmovb  %r8,%rax
  711ae9:	4d 0f 42 c7          	cmovb  %r15,%r8
  711aed:	4d 8b 38             	mov    (%r8),%r15
  711af0:	4f 8b 14 d1          	mov    (%r9,%r10,8),%r10
  711af4:	4d 39 d7             	cmp    %r10,%r15
  711af7:	4d 89 f4             	mov    %r14,%r12
  711afa:	4c 0f 42 e0          	cmovb  %rax,%r12
  711afe:	4c 8b 28             	mov    (%rax),%r13
  711b01:	4f 3b 2c d9          	cmp    (%r9,%r11,8),%r13
  711b05:	4f 8d 0c d9          	lea    (%r9,%r11,8),%r9
  711b09:	4d 0f 42 e1          	cmovb  %r9,%r12
  711b0d:	4c 0f 42 c8          	cmovb  %rax,%r9
  711b11:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  711b15:	49 0f 42 c6          	cmovb  %r14,%rax
  711b19:	4d 39 d7             	cmp    %r10,%r15
  711b1c:	4d 0f 43 f0          	cmovae %r8,%r14
  711b20:	49 0f 42 c0          	cmovb  %r8,%rax
  711b24:	4c 89 5b 58          	mov    %r11,0x58(%rbx)
  711b28:	4c 8b 00             	mov    (%rax),%r8
  711b2b:	4d 3b 04 24          	cmp    (%r12),%r8
  711b2f:	0f 10 01             	movups (%rcx),%xmm0
  711b32:	4c 89 e1             	mov    %r12,%rcx
  711b35:	48 0f 42 c8          	cmovb  %rax,%rcx
  711b39:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
  711b3d:	49 0f 42 c4          	cmovb  %r12,%rax
  711b41:	4d 8b 41 10          	mov    0x10(%r9),%r8
  711b45:	4c 89 44 13 10       	mov    %r8,0x10(%rbx,%rdx,1)
  711b4a:	41 0f 10 01          	movups (%r9),%xmm0
  711b4e:	0f 11 04 13          	movups %xmm0,(%rbx,%rdx,1)
  711b52:	0f 10 01             	movups (%rcx),%xmm0
  711b55:	0f 11 44 13 18       	movups %xmm0,0x18(%rbx,%rdx,1)
  711b5a:	48 8b 49 10          	mov    0x10(%rcx),%rcx
  711b5e:	48 89 4c 13 28       	mov    %rcx,0x28(%rbx,%rdx,1)
  711b63:	0f 10 00             	movups (%rax),%xmm0
  711b66:	0f 11 44 13 30       	movups %xmm0,0x30(%rbx,%rdx,1)
  711b6b:	48 8b 48 10          	mov    0x10(%rax),%rcx
  711b6f:	48 89 4c 13 40       	mov    %rcx,0x40(%rbx,%rdx,1)
  711b74:	41 0f 10 06          	movups (%r14),%xmm0
  711b78:	0f 11 44 13 48       	movups %xmm0,0x48(%rbx,%rdx,1)
  711b7d:	49 8b 4e 10          	mov    0x10(%r14),%rcx
  711b81:	48 89 4c 13 58       	mov    %rcx,0x58(%rbx,%rdx,1)
  711b86:	ba 04 00 00 00       	mov    $0x4,%edx
  711b8b:	49 89 f6             	mov    %rsi,%r14
  711b8e:	49 29 ee             	sub    %rbp,%r14
  711b91:	48 39 ea             	cmp    %rbp,%rdx
  711b94:	72 45                	jb     711bdb <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x22b>
  711b96:	e9 e6 00 00 00       	jmp    711c81 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  711b9b:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
  711b9f:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
  711ba3:	0f 10 07             	movups (%rdi),%xmm0
  711ba6:	0f 11 03             	movups %xmm0,(%rbx)
  711ba9:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  711bb0:	00 
  711bb1:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  711bb5:	48 8b 54 0f 10       	mov    0x10(%rdi,%rcx,1),%rdx
  711bba:	48 89 54 0b 10       	mov    %rdx,0x10(%rbx,%rcx,1)
  711bbf:	0f 10 04 0f          	movups (%rdi,%rcx,1),%xmm0
  711bc3:	0f 11 04 0b          	movups %xmm0,(%rbx,%rcx,1)
  711bc7:	ba 01 00 00 00       	mov    $0x1,%edx
  711bcc:	49 89 f6             	mov    %rsi,%r14
  711bcf:	49 29 ee             	sub    %rbp,%r14
  711bd2:	48 39 ea             	cmp    %rbp,%rdx
  711bd5:	0f 83 a6 00 00 00    	jae    711c81 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  711bdb:	8d 0c d5 00 00 00 00 	lea    0x0(,%rdx,8),%ecx
  711be2:	48 8d 0c 49          	lea    (%rcx,%rcx,2),%rcx
  711be6:	49 89 d3             	mov    %rdx,%r11
  711be9:	eb 21                	jmp    711c0c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x25c>
  711beb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  711bf0:	49 89 d9             	mov    %rbx,%r9
  711bf3:	4d 89 01             	mov    %r8,(%r9)
  711bf6:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  711bfb:	41 0f 11 41 08       	movups %xmm0,0x8(%r9)
  711c00:	49 ff c3             	inc    %r11
  711c03:	48 83 c1 18          	add    $0x18,%rcx
  711c07:	49 39 eb             	cmp    %rbp,%r11
  711c0a:	74 75                	je     711c81 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2d1>
  711c0c:	4a 8d 04 dd 00 00 00 	lea    0x0(,%r11,8),%rax
  711c13:	00 
  711c14:	4c 8d 0c 40          	lea    (%rax,%rax,2),%r9
  711c18:	42 0f 10 04 0f       	movups (%rdi,%r9,1),%xmm0
  711c1d:	42 0f 11 04 0b       	movups %xmm0,(%rbx,%r9,1)
  711c22:	4a 8b 44 0f 10       	mov    0x10(%rdi,%r9,1),%rax
  711c27:	4a 89 44 0b 10       	mov    %rax,0x10(%rbx,%r9,1)
  711c2c:	4e 8b 04 0b          	mov    (%rbx,%r9,1),%r8
  711c30:	4e 3b 44 0b e8       	cmp    -0x18(%rbx,%r9,1),%r8
  711c35:	73 c9                	jae    711c00 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x250>
  711c37:	49 01 f9             	add    %rdi,%r9
  711c3a:	41 0f 10 41 08       	movups 0x8(%r9),%xmm0
  711c3f:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  711c44:	49 89 ca             	mov    %rcx,%r10
  711c47:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  711c4e:	00 00 
  711c50:	4a 8b 44 13 f8       	mov    -0x8(%rbx,%r10,1),%rax
  711c55:	4a 89 44 13 10       	mov    %rax,0x10(%rbx,%r10,1)
  711c5a:	42 0f 10 44 13 e8    	movups -0x18(%rbx,%r10,1),%xmm0
  711c60:	42 0f 11 04 13       	movups %xmm0,(%rbx,%r10,1)
  711c65:	49 83 fa 18          	cmp    $0x18,%r10
  711c69:	74 85                	je     711bf0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x240>
  711c6b:	4d 8d 4a e8          	lea    -0x18(%r10),%r9
  711c6f:	4e 3b 44 13 d0       	cmp    -0x30(%rbx,%r10,1),%r8
  711c74:	4d 89 ca             	mov    %r9,%r10
  711c77:	72 d7                	jb     711c50 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x2a0>
  711c79:	49 01 d9             	add    %rbx,%r9
  711c7c:	e9 72 ff ff ff       	jmp    711bf3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x243>
  711c81:	48 8d 0c ed 00 00 00 	lea    0x0(,%rbp,8),%rcx
  711c88:	00 
  711c89:	48 8d 04 49          	lea    (%rcx,%rcx,2),%rax
  711c8d:	48 8d 0c 03          	lea    (%rbx,%rax,1),%rcx
  711c91:	4c 39 f2             	cmp    %r14,%rdx
  711c94:	0f 83 a7 00 00 00    	jae    711d41 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x391>
  711c9a:	48 01 f8             	add    %rdi,%rax
  711c9d:	44 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%r8d
  711ca4:	00 
  711ca5:	4f 8d 04 40          	lea    (%r8,%r8,2),%r8
  711ca9:	eb 21                	jmp    711ccc <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x31c>
  711cab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
  711cb0:	49 89 ca             	mov    %rcx,%r10
  711cb3:	4d 89 0a             	mov    %r9,(%r10)
  711cb6:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  711cbb:	41 0f 11 42 08       	movups %xmm0,0x8(%r10)
  711cc0:	48 ff c2             	inc    %rdx
  711cc3:	49 83 c0 18          	add    $0x18,%r8
  711cc7:	4c 39 f2             	cmp    %r14,%rdx
  711cca:	74 75                	je     711d41 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x391>
  711ccc:	4c 8d 0c d5 00 00 00 	lea    0x0(,%rdx,8),%r9
  711cd3:	00 
  711cd4:	4f 8d 14 49          	lea    (%r9,%r9,2),%r10
  711cd8:	42 0f 10 04 10       	movups (%rax,%r10,1),%xmm0
  711cdd:	42 0f 11 04 11       	movups %xmm0,(%rcx,%r10,1)
  711ce2:	4e 8b 4c 10 10       	mov    0x10(%rax,%r10,1),%r9
  711ce7:	4e 89 4c 11 10       	mov    %r9,0x10(%rcx,%r10,1)
  711cec:	4e 8b 0c 11          	mov    (%rcx,%r10,1),%r9
  711cf0:	4e 3b 4c 11 e8       	cmp    -0x18(%rcx,%r10,1),%r9
  711cf5:	73 c9                	jae    711cc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x310>
  711cf7:	49 01 c2             	add    %rax,%r10
  711cfa:	41 0f 10 42 08       	movups 0x8(%r10),%xmm0
  711cff:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  711d04:	4d 89 c3             	mov    %r8,%r11
  711d07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  711d0e:	00 00 
  711d10:	4e 8b 54 19 f8       	mov    -0x8(%rcx,%r11,1),%r10
  711d15:	4e 89 54 19 10       	mov    %r10,0x10(%rcx,%r11,1)
  711d1a:	42 0f 10 44 19 e8    	movups -0x18(%rcx,%r11,1),%xmm0
  711d20:	42 0f 11 04 19       	movups %xmm0,(%rcx,%r11,1)
  711d25:	49 83 fb 18          	cmp    $0x18,%r11
  711d29:	74 85                	je     711cb0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x300>
  711d2b:	4d 8d 53 e8          	lea    -0x18(%r11),%r10
  711d2f:	4e 3b 4c 19 d0       	cmp    -0x30(%rcx,%r11,1),%r9
  711d34:	4d 89 d3             	mov    %r10,%r11
  711d37:	72 d7                	jb     711d10 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x360>
  711d39:	49 01 ca             	add    %rcx,%r10
  711d3c:	e9 72 ff ff ff       	jmp    711cb3 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x303>
  711d41:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  711d46:	48 8d 14 76          	lea    (%rsi,%rsi,2),%rdx
  711d4a:	4c 8d 0c d7          	lea    (%rdi,%rdx,8),%r9
  711d4e:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  711d52:	48 8d 74 d3 e8       	lea    -0x18(%rbx,%rdx,8),%rsi
  711d57:	4c 8d 79 e8          	lea    -0x18(%rcx),%r15
  711d5b:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  711d60:	49 89 f8             	mov    %rdi,%r8
  711d63:	48 89 df             	mov    %rbx,%rdi
  711d66:	eb 58                	jmp    711dc0 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x410>
  711d68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  711d6f:	00 
  711d70:	45 88 eb             	mov    %r13b,%r11b
  711d73:	4b 8d 04 5b          	lea    (%r11,%r11,2),%rax
  711d77:	48 8d 0c c1          	lea    (%rcx,%rax,8),%rcx
  711d7b:	41 88 ea             	mov    %bpl,%r10b
  711d7e:	4b 8d 04 52          	lea    (%r10,%r10,2),%rax
  711d82:	41 ba 00 00 00 00    	mov    $0x0,%r10d
  711d88:	4d 19 d2             	sbb    %r10,%r10
  711d8b:	48 8d 3c c7          	lea    (%rdi,%rax,8),%rdi
  711d8f:	49 83 c0 18          	add    $0x18,%r8
  711d93:	48 8b 42 10          	mov    0x10(%rdx),%rax
  711d97:	49 89 41 10          	mov    %rax,0x10(%r9)
  711d9b:	0f 10 02             	movups (%rdx),%xmm0
  711d9e:	41 0f 11 01          	movups %xmm0,(%r9)
  711da2:	4b 8d 04 64          	lea    (%r12,%r12,2),%rax
  711da6:	48 8d 34 c6          	lea    (%rsi,%rax,8),%rsi
  711daa:	4b 8d 04 52          	lea    (%r10,%r10,2),%rax
  711dae:	4d 8d 3c c7          	lea    (%r15,%rax,8),%r15
  711db2:	49 83 c1 e8          	add    $0xffffffffffffffe8,%r9
  711db6:	48 8b 6c 24 30       	mov    0x30(%rsp),%rbp
  711dbb:	48 ff cd             	dec    %rbp
  711dbe:	74 57                	je     711e17 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x467>
  711dc0:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
  711dc5:	4c 8b 21             	mov    (%rcx),%r12
  711dc8:	45 31 d2             	xor    %r10d,%r10d
  711dcb:	45 31 db             	xor    %r11d,%r11d
  711dce:	48 89 ca             	mov    %rcx,%rdx
  711dd1:	4c 3b 27             	cmp    (%rdi),%r12
  711dd4:	40 0f 93 c5          	setae  %bpl
  711dd8:	41 0f 92 c5          	setb   %r13b
  711ddc:	72 03                	jb     711de1 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x431>
  711dde:	48 89 fa             	mov    %rdi,%rdx
  711de1:	4c 8b 62 10          	mov    0x10(%rdx),%r12
  711de5:	4d 89 60 10          	mov    %r12,0x10(%r8)
  711de9:	0f 10 02             	movups (%rdx),%xmm0
  711dec:	41 0f 11 00          	movups %xmm0,(%r8)
  711df0:	4c 8b 36             	mov    (%rsi),%r14
  711df3:	49 8b 07             	mov    (%r15),%rax
  711df6:	49 39 c6             	cmp    %rax,%r14
  711df9:	41 bc 00 00 00 00    	mov    $0x0,%r12d
  711dff:	49 83 d4 ff          	adc    $0xffffffffffffffff,%r12
  711e03:	4c 89 fa             	mov    %r15,%rdx
  711e06:	49 39 c6             	cmp    %rax,%r14
  711e09:	0f 82 61 ff ff ff    	jb     711d70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x3c0>
  711e0f:	48 89 f2             	mov    %rsi,%rdx
  711e12:	e9 59 ff ff ff       	jmp    711d70 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x3c0>
  711e17:	49 83 c7 18          	add    $0x18,%r15
  711e1b:	48 83 c6 18          	add    $0x18,%rsi
  711e1f:	4c 8b 6c 24 28       	mov    0x28(%rsp),%r13
  711e24:	41 f6 c5 01          	test   $0x1,%r13b
  711e28:	75 23                	jne    711e4d <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x49d>
  711e2a:	48 39 f1             	cmp    %rsi,%rcx
  711e2d:	0f 95 c0             	setne  %al
  711e30:	4c 39 ff             	cmp    %r15,%rdi
  711e33:	75 57                	jne    711e8c <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4dc>
  711e35:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  711e3a:	84 c0                	test   %al,%al
  711e3c:	75 59                	jne    711e97 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x4e7>
  711e3e:	48 83 c4 38          	add    $0x38,%rsp
  711e42:	5b                   	pop    %rbx
  711e43:	41 5c                	pop    %r12
  711e45:	41 5d                	pop    %r13
  711e47:	41 5e                	pop    %r14
  711e49:	41 5f                	pop    %r15
  711e4b:	5d                   	pop    %rbp
  711e4c:	c3                   	ret
  711e4d:	31 c0                	xor    %eax,%eax
  711e4f:	31 d2                	xor    %edx,%edx
  711e51:	4c 39 ff             	cmp    %r15,%rdi
  711e54:	0f 93 c0             	setae  %al
  711e57:	0f 92 c2             	setb   %dl
  711e5a:	49 89 c9             	mov    %rcx,%r9
  711e5d:	4c 0f 42 cf          	cmovb  %rdi,%r9
  711e61:	4d 8b 51 10          	mov    0x10(%r9),%r10
  711e65:	4d 89 50 10          	mov    %r10,0x10(%r8)
  711e69:	41 0f 10 01          	movups (%r9),%xmm0
  711e6d:	41 0f 11 00          	movups %xmm0,(%r8)
  711e71:	48 8d 14 52          	lea    (%rdx,%rdx,2),%rdx
  711e75:	48 8d 3c d7          	lea    (%rdi,%rdx,8),%rdi
  711e79:	48 8d 04 40          	lea    (%rax,%rax,2),%rax
  711e7d:	48 8d 0c c1          	lea    (%rcx,%rax,8),%rcx
  711e81:	48 39 f1             	cmp    %rsi,%rcx
  711e84:	0f 95 c0             	setne  %al
  711e87:	4c 39 ff             	cmp    %r15,%rdi
  711e8a:	74 a9                	je     711e35 <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x485>
  711e8c:	b0 01                	mov    $0x1,%al
  711e8e:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  711e93:	84 c0                	test   %al,%al
  711e95:	74 a7                	je     711e3e <_RINvNtNtNtNtCs4NRVxsYgnAr_4core5slice4sort6shared9smallsort31small_sort_general_with_scratchTjTNtNtCshBhuxcId5D0_4gpui4list6ListIdRNtB1x_8RowDraftEENCINvMNtCscdodAO9FK5_5alloc5sliceSB1s_7sort_byNCINvXs1o_NtNtNtB2u_11collections5btree3mapINtB3g_8BTreeMapjB1u_EINtNtNtNtBa_4iter6traits7collect12FromIteratorB1s_E9from_iterINtNtNtB4g_8adapters7flatten7FlatMapINtNtB8_4iter4IterNtB1x_9ListDraftEINtNtB5d_3map3MapIB5J_B25_ENCNCNvMst_NtB1z_7runtimeINtB6S_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_inners2_00ENCB6M_s2_0EE0E0EB7n_+0x48e>
  711e97:	ff 15 d3 63 3d 00    	call   *0x3d63d3(%rip)        # ae8270 <_DYNAMIC+0x6d8>
  711e9d:	0f 0b                	ud2
  711e9f:	49 89 c4             	mov    %rax,%r12
  711ea2:	49 c1 e5 03          	shl    $0x3,%r13
  711ea6:	4a 8d 14 6d 00 00 00 	lea    0x0(,%r13,2),%rdx
  711ead:	00 
  711eae:	4c 01 ea             	add    %r13,%rdx
  711eb1:	4c 89 f7             	mov    %r14,%rdi
  711eb4:	48 89 de             	mov    %rbx,%rsi
  711eb7:	ff 15 4b 5f 3d 00    	call   *0x3d5f4b(%rip)        # ae7e08 <memcpy@GLIBC_2.14>
  711ebd:	4c 89 e7             	mov    %r12,%rdi
  711ec0:	e8 8b 66 3a 00       	call   ab8550 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
