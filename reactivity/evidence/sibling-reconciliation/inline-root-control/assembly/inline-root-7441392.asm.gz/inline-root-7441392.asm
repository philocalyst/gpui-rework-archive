
/tmp/gpui-sibling-controls/inline-root:     file format elf64-x86-64


Disassembly of section .text:

0000000000718bf0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_>:
  718bf0:	55                   	push   %rbp
  718bf1:	41 57                	push   %r15
  718bf3:	41 56                	push   %r14
  718bf5:	41 55                	push   %r13
  718bf7:	41 54                	push   %r12
  718bf9:	53                   	push   %rbx
  718bfa:	48 83 ec 78          	sub    $0x78,%rsp
  718bfe:	48 89 fb             	mov    %rdi,%rbx
  718c01:	4c 8b 26             	mov    (%rsi),%r12
  718c04:	48 8b 46 18          	mov    0x18(%rsi),%rax
  718c08:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  718c0c:	4c 8b 6e 28          	mov    0x28(%rsi),%r13
  718c10:	48 c7 46 18 00 00 00 	movq   $0x0,0x18(%rsi)
  718c17:	00 
  718c18:	48 85 c0             	test   %rax,%rax
  718c1b:	0f 84 29 01 00 00    	je     718d4a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x15a>
  718c21:	49 89 f6             	mov    %rsi,%r14
  718c24:	48 8d 4e 18          	lea    0x18(%rsi),%rcx
  718c28:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  718c2d:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718c34:	49 39 cd             	cmp    %rcx,%r13
  718c37:	73 07                	jae    718c40 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  718c39:	49 89 c7             	mov    %rax,%r15
  718c3c:	eb 2a                	jmp    718c68 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x78>
  718c3e:	66 90                	xchg   %ax,%ax
  718c40:	4c 8b b8 60 01 00 00 	mov    0x160(%rax),%r15
  718c47:	4d 85 ff             	test   %r15,%r15
  718c4a:	0f 84 fa 00 00 00    	je     718d4a <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x15a>
  718c50:	48 ff c5             	inc    %rbp
  718c53:	44 0f b7 a8 c0 01 00 	movzwl 0x1c0(%rax),%r13d
  718c5a:	00 
  718c5b:	4c 89 f8             	mov    %r15,%rax
  718c5e:	66 45 3b af c2 01 00 	cmp    0x1c2(%r15),%r13w
  718c65:	00 
  718c66:	73 d8                	jae    718c40 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  718c68:	4b 8b b4 ef 68 01 00 	mov    0x168(%r15,%r13,8),%rsi
  718c6f:	00 
  718c70:	49 8b 3c 24          	mov    (%r12),%rdi
  718c74:	ff 15 16 f6 3c 00    	call   *0x3cf616(%rip)        # ae8290 <_DYNAMIC+0x6f8>
  718c7a:	84 c0                	test   %al,%al
  718c7c:	0f 84 e2 00 00 00    	je     718d64 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x174>
  718c82:	48 85 ed             	test   %rbp,%rbp
  718c85:	0f 84 8b 00 00 00    	je     718d16 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x126>
  718c8b:	4b 8d 04 ef          	lea    (%r15,%r13,8),%rax
  718c8f:	48 05 d0 01 00 00    	add    $0x1d0,%rax
  718c95:	48 89 e9             	mov    %rbp,%rcx
  718c98:	48 83 e1 07          	and    $0x7,%rcx
  718c9c:	0f 84 9d 00 00 00    	je     718d3f <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x14f>
  718ca2:	31 d2                	xor    %edx,%edx
  718ca4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
  718cab:	00 00 00 00 00 
  718cb0:	4c 8b 38             	mov    (%rax),%r15
  718cb3:	49 8d 87 c8 01 00 00 	lea    0x1c8(%r15),%rax
  718cba:	48 ff c2             	inc    %rdx
  718cbd:	48 39 d1             	cmp    %rdx,%rcx
  718cc0:	75 ee                	jne    718cb0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xc0>
  718cc2:	48 89 e9             	mov    %rbp,%rcx
  718cc5:	48 29 d1             	sub    %rdx,%rcx
  718cc8:	48 83 fd 08          	cmp    $0x8,%rbp
  718ccc:	72 43                	jb     718d11 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x121>
  718cce:	66 90                	xchg   %ax,%ax
  718cd0:	48 8b 00             	mov    (%rax),%rax
  718cd3:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718cda:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718ce1:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718ce8:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718cef:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718cf6:	48 8b 80 c8 01 00 00 	mov    0x1c8(%rax),%rax
  718cfd:	4c 8b b8 c8 01 00 00 	mov    0x1c8(%rax),%r15
  718d04:	49 8d 87 c8 01 00 00 	lea    0x1c8(%r15),%rax
  718d0b:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
  718d0f:	75 bf                	jne    718cd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xe0>
  718d11:	45 31 ed             	xor    %r13d,%r13d
  718d14:	eb 03                	jmp    718d19 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x129>
  718d16:	49 ff c5             	inc    %r13
  718d19:	4d 89 6e 28          	mov    %r13,0x28(%r14)
  718d1d:	0f 57 c0             	xorps  %xmm0,%xmm0
  718d20:	41 0f 11 46 18       	movups %xmm0,0x18(%r14)
  718d25:	31 ed                	xor    %ebp,%ebp
  718d27:	4c 89 f8             	mov    %r15,%rax
  718d2a:	0f b7 88 c2 01 00 00 	movzwl 0x1c2(%rax),%ecx
  718d31:	49 39 cd             	cmp    %rcx,%r13
  718d34:	0f 83 06 ff ff ff    	jae    718c40 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x50>
  718d3a:	e9 fa fe ff ff       	jmp    718c39 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x49>
  718d3f:	48 89 e9             	mov    %rbp,%rcx
  718d42:	48 83 fd 08          	cmp    $0x8,%rbp
  718d46:	73 88                	jae    718cd0 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0xe0>
  718d48:	eb c7                	jmp    718d11 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x121>
  718d4a:	48 c7 43 08 02 00 00 	movq   $0x2,0x8(%rbx)
  718d51:	00 
  718d52:	48 89 d8             	mov    %rbx,%rax
  718d55:	48 83 c4 78          	add    $0x78,%rsp
  718d59:	5b                   	pop    %rbx
  718d5a:	41 5c                	pop    %r12
  718d5c:	41 5d                	pop    %r13
  718d5e:	41 5e                	pop    %r14
  718d60:	41 5f                	pop    %r15
  718d62:	5d                   	pop    %rbp
  718d63:	c3                   	ret
  718d64:	49 8b 46 08          	mov    0x8(%r14),%rax
  718d68:	48 ff 08             	decq   (%rax)
  718d6b:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
  718d70:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  718d75:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
  718d7a:	49 83 c6 10          	add    $0x10,%r14
  718d7e:	48 8d 7c 24 38       	lea    0x38(%rsp),%rdi
  718d83:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  718d88:	48 8d 4c 24 0f       	lea    0xf(%rsp),%rcx
  718d8d:	4c 89 f2             	mov    %r14,%rdx
  718d90:	e8 cb 29 fd ff       	call   6eb760 <_RINvMNtNtNtCscdodAO9FK5_5alloc11collections5btree6removeINtNtB5_4node6HandleINtBV_7NodeRefNtNtBV_6marker3MutyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1P_11shared_text10SharedTextEEj2_NtB1s_14LeafOrInternalENtB1s_2KVE18remove_kv_trackingNCINvMsV_NtB5_3mapINtB4J_14ExtractIfInneryB1J_NtNtNtB2A_3ops5range9RangeFullE4nextNCINvMsi_B4J_INtB4J_8BTreeMapyB1J_E6retainNCNvMst_NtB1P_7runtimeINtB6I_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0NtNtB9_5alloc6GlobalE0B8m_EB7d_>
  718d95:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  718d9a:	48 89 43 20          	mov    %rax,0x20(%rbx)
  718d9e:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  718da3:	0f 10 4c 24 48       	movups 0x48(%rsp),%xmm1
  718da8:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  718dac:	0f 11 03             	movups %xmm0,(%rbx)
  718daf:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  718db4:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  718db9:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  718dbe:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  718dc3:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  718dc8:	48 89 41 10          	mov    %rax,0x10(%rcx)
  718dcc:	0f 11 01             	movups %xmm0,(%rcx)
  718dcf:	eb 81                	jmp    718d52 <_RNvXsU_NtNtNtCscdodAO9FK5_5alloc11collections5btree3mapINtB5_9ExtractIfyAINtNtCshBhuxcId5D0_4gpui8property12ContributionINtNtCs4NRVxsYgnAr_4core6option6OptionNtNtB1e_11shared_text10SharedTextEEj2_NtNtNtB1Z_3ops5range9RangeFullNCINvMsi_B5_INtB5_8BTreeMapyB18_E6retainNCNvMst_NtB1e_7runtimeINtB4o_7RuntimeNtCs4gwBMgNbBwV_27sibling_reconciliation_cost4TreeE14describe_innersK_0E0ENtNtNtNtB1Z_4iter6traits8iterator8Iterator4nextB4T_+0x162>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
