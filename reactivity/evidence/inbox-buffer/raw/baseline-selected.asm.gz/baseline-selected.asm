00000000006e3160 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready>:
  6e3160:	55                   	push   %rbp
  6e3161:	41 57                	push   %r15
  6e3163:	41 56                	push   %r14
  6e3165:	41 55                	push   %r13
  6e3167:	41 54                	push   %r12
  6e3169:	53                   	push   %rbx
  6e316a:	48 81 ec 58 01 00 00 	sub    $0x158,%rsp
  6e3171:	48 89 fb             	mov    %rdi,%rbx
  6e3174:	4c 8b 66 48          	mov    0x48(%rsi),%r12
  6e3178:	4d 85 e4             	test   %r12,%r12
  6e317b:	0f 84 ad 00 00 00    	je     6e322e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xce>
  6e3181:	49 89 f7             	mov    %rsi,%r15
  6e3184:	41 80 bc 24 26 07 00 	cmpb   $0x0,0x726(%r12)
  6e318b:	00 00 
  6e318d:	0f 84 af 00 00 00    	je     6e3242 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xe2>
  6e3193:	48 c7 44 24 20 0e 00 	movq   $0xe,0x20(%rsp)
  6e319a:	00 00 
  6e319c:	49 8b 07             	mov    (%r15),%rax
  6e319f:	49 8b 4f 08          	mov    0x8(%r15),%rcx
  6e31a3:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  6e31aa:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6e31b1:	00 
  6e31b2:	48 89 8c 24 a8 00 00 	mov    %rcx,0xa8(%rsp)
  6e31b9:	00 
  6e31ba:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6e31be:	74 0d                	je     6e31cd <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6d>
  6e31c0:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6e31c7:	00 
  6e31c8:	e8 13 44 02 00       	call   7075e0 <<std::sync::mpmc::Receiver<u64> as core::ops::drop::Drop>::drop>
  6e31cd:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  6e31d4:	49 83 7f 28 00       	cmpq   $0x0,0x28(%r15)
  6e31d9:	74 08                	je     6e31e3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x83>
  6e31db:	49 c7 47 28 00 00 00 	movq   $0x0,0x28(%r15)
  6e31e2:	00 
  6e31e3:	49 c7 47 20 00 00 00 	movq   $0x0,0x20(%r15)
  6e31ea:	00 
  6e31eb:	49 c7 47 30 00 00 00 	movq   $0x0,0x30(%r15)
  6e31f2:	00 
  6e31f3:	41 0f 10 84 24 68 06 	movups 0x668(%r12),%xmm0
  6e31fa:	00 00 
  6e31fc:	41 0f b6 84 24 24 07 	movzbl 0x724(%r12),%eax
  6e3203:	00 00 
  6e3205:	49 83 bc 24 88 06 00 	cmpq   $0x0,0x688(%r12)
  6e320c:	00 00 
  6e320e:	74 17                	je     6e3227 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xc7>
  6e3210:	84 c0                	test   %al,%al
  6e3212:	0f 84 9a 00 00 00    	je     6e32b2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x152>
  6e3218:	49 83 bc 24 88 05 00 	cmpq   $0xffffffffffffffff,0x588(%r12)
  6e321f:	00 ff 
  6e3221:	0f 85 8b 00 00 00    	jne    6e32b2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x152>
  6e3227:	31 c9                	xor    %ecx,%ecx
  6e3229:	e9 91 00 00 00       	jmp    6e32bf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x15f>
  6e322e:	48 c7 03 02 00 00 00 	movq   $0x2,(%rbx)
  6e3235:	48 c7 43 48 0d 00 00 	movq   $0xd,0x48(%rbx)
  6e323c:	00 
  6e323d:	e9 e1 07 00 00       	jmp    6e3a23 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8c3>
  6e3242:	48 89 d5             	mov    %rdx,%rbp
  6e3245:	49 c7 84 24 10 07 00 	movq   $0x0,0x710(%r12)
  6e324c:	00 00 00 00 00 
  6e3251:	48 85 d2             	test   %rdx,%rdx
  6e3254:	74 0f                	je     6e3265 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x105>
  6e3256:	49 83 bc 24 68 06 00 	cmpq   $0xffffffffffffffff,0x668(%r12)
  6e325d:	00 ff 
  6e325f:	0f 84 a8 00 00 00    	je     6e330d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1ad>
  6e3265:	48 89 5c 24 58       	mov    %rbx,0x58(%rsp)
  6e326a:	4d 8b 6f 28          	mov    0x28(%r15),%r13
  6e326e:	49 8b 77 40          	mov    0x40(%r15),%rsi
  6e3272:	c6 44 24 07 01       	movb   $0x1,0x7(%rsp)
  6e3277:	49 89 ee             	mov    %rbp,%r14
  6e327a:	4d 29 ee             	sub    %r13,%r14
  6e327d:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  6e3282:	76 26                	jbe    6e32aa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x14a>
  6e3284:	4c 89 ff             	mov    %r15,%rdi
  6e3287:	e8 74 56 03 00       	call   718900 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage>
  6e328c:	3c 02                	cmp    $0x2,%al
  6e328e:	0f 84 f7 00 00 00    	je     6e338b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x22b>
  6e3294:	0f b6 c0             	movzbl %al,%eax
  6e3297:	83 f8 01             	cmp    $0x1,%eax
  6e329a:	0f 85 f5 00 00 00    	jne    6e3395 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x235>
  6e32a0:	45 31 f6             	xor    %r14d,%r14d
  6e32a3:	31 c0                	xor    %eax,%eax
  6e32a5:	e9 b5 01 00 00       	jmp    6e345f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2ff>
  6e32aa:	45 31 f6             	xor    %r14d,%r14d
  6e32ad:	e9 bb 01 00 00       	jmp    6e346d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x30d>
  6e32b2:	49 8b 94 24 98 06 00 	mov    0x698(%r12),%rdx
  6e32b9:	00 
  6e32ba:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e32bf:	49 8b b4 24 10 07 00 	mov    0x710(%r12),%rsi
  6e32c6:	00 
  6e32c7:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6e32cc:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
  6e32d0:	0f 10 4c 24 20       	movups 0x20(%rsp),%xmm1
  6e32d5:	0f 10 54 24 30       	movups 0x30(%rsp),%xmm2
  6e32da:	0f 10 5c 24 40       	movups 0x40(%rsp),%xmm3
  6e32df:	0f 11 5b 68          	movups %xmm3,0x68(%rbx)
  6e32e3:	0f 11 53 58          	movups %xmm2,0x58(%rbx)
  6e32e7:	0f 11 4b 48          	movups %xmm1,0x48(%rbx)
  6e32eb:	48 89 0b             	mov    %rcx,(%rbx)
  6e32ee:	48 89 53 08          	mov    %rdx,0x8(%rbx)
  6e32f2:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6e32f6:	48 89 73 20          	mov    %rsi,0x20(%rbx)
  6e32fa:	88 43 28             	mov    %al,0x28(%rbx)
  6e32fd:	0f 57 c0             	xorps  %xmm0,%xmm0
  6e3300:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  6e3304:	c6 43 40 00          	movb   $0x0,0x40(%rbx)
  6e3308:	e9 16 07 00 00       	jmp    6e3a23 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8c3>
  6e330d:	49 8b 07             	mov    (%r15),%rax
  6e3310:	49 8b 4f 08          	mov    0x8(%r15),%rcx
  6e3314:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  6e331b:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6e3320:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  6e3325:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6e3329:	74 0a                	je     6e3335 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d5>
  6e332b:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6e3330:	e8 ab 42 02 00       	call   7075e0 <<std::sync::mpmc::Receiver<u64> as core::ops::drop::Drop>::drop>
  6e3335:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  6e333c:	49 83 7f 28 00       	cmpq   $0x0,0x28(%r15)
  6e3341:	74 08                	je     6e334b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1eb>
  6e3343:	49 c7 47 28 00 00 00 	movq   $0x0,0x28(%r15)
  6e334a:	00 
  6e334b:	49 c7 47 20 00 00 00 	movq   $0x0,0x20(%r15)
  6e3352:	00 
  6e3353:	49 c7 47 30 00 00 00 	movq   $0x0,0x30(%r15)
  6e335a:	00 
  6e335b:	41 0f 10 84 24 68 06 	movups 0x668(%r12),%xmm0
  6e3362:	00 00 
  6e3364:	41 0f b6 84 24 24 07 	movzbl 0x724(%r12),%eax
  6e336b:	00 00 
  6e336d:	49 83 bc 24 88 06 00 	cmpq   $0x0,0x688(%r12)
  6e3374:	00 00 
  6e3376:	74 0f                	je     6e3387 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x227>
  6e3378:	84 c0                	test   %al,%al
  6e337a:	74 32                	je     6e33ae <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24e>
  6e337c:	49 83 bc 24 88 05 00 	cmpq   $0xffffffffffffffff,0x588(%r12)
  6e3383:	00 ff 
  6e3385:	75 27                	jne    6e33ae <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24e>
  6e3387:	31 c9                	xor    %ecx,%ecx
  6e3389:	eb 30                	jmp    6e33bb <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x25b>
  6e338b:	b0 01                	mov    $0x1,%al
  6e338d:	45 31 f6             	xor    %r14d,%r14d
  6e3390:	e9 ca 00 00 00       	jmp    6e345f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2ff>
  6e3395:	49 83 fe 01          	cmp    $0x1,%r14
  6e3399:	75 52                	jne    6e33ed <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x28d>
  6e339b:	31 f6                	xor    %esi,%esi
  6e339d:	41 be 01 00 00 00    	mov    $0x1,%r14d
  6e33a3:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  6e33a9:	e9 bf 00 00 00       	jmp    6e346d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x30d>
  6e33ae:	49 8b 94 24 98 06 00 	mov    0x698(%r12),%rdx
  6e33b5:	00 
  6e33b6:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e33bb:	49 8b b4 24 10 07 00 	mov    0x710(%r12),%rsi
  6e33c2:	00 
  6e33c3:	48 89 0b             	mov    %rcx,(%rbx)
  6e33c6:	48 89 53 08          	mov    %rdx,0x8(%rbx)
  6e33ca:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6e33ce:	48 89 73 20          	mov    %rsi,0x20(%rbx)
  6e33d2:	88 43 28             	mov    %al,0x28(%rbx)
  6e33d5:	0f 57 c0             	xorps  %xmm0,%xmm0
  6e33d8:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  6e33dc:	c6 43 40 00          	movb   $0x0,0x40(%rbx)
  6e33e0:	48 c7 43 48 20 00 00 	movq   $0x20,0x48(%rbx)
  6e33e7:	00 
  6e33e8:	e9 36 06 00 00       	jmp    6e3a23 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8c3>
  6e33ed:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6e33f2:	4d 89 e6             	mov    %r12,%r14
  6e33f5:	48 89 e8             	mov    %rbp,%rax
  6e33f8:	4c 89 ed             	mov    %r13,%rbp
  6e33fb:	48 29 c5             	sub    %rax,%rbp
  6e33fe:	49 c7 c4 ff ff ff ff 	mov    $0xffffffffffffffff,%r12
  6e3405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6e340c:	00 00 00 00 
  6e3410:	4c 89 ff             	mov    %r15,%rdi
  6e3413:	31 f6                	xor    %esi,%esi
  6e3415:	e8 e6 54 03 00       	call   718900 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage>
  6e341a:	84 c0                	test   %al,%al
  6e341c:	75 1f                	jne    6e343d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2dd>
  6e341e:	49 ff cc             	dec    %r12
  6e3421:	4c 39 e5             	cmp    %r12,%rbp
  6e3424:	75 ea                	jne    6e3410 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2b0>
  6e3426:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  6e342c:	31 f6                	xor    %esi,%esi
  6e342e:	4d 89 f4             	mov    %r14,%r12
  6e3431:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  6e3436:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  6e343b:	eb 30                	jmp    6e346d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x30d>
  6e343d:	0f b6 c0             	movzbl %al,%eax
  6e3440:	4d 29 e5             	sub    %r12,%r13
  6e3443:	49 f7 dc             	neg    %r12
  6e3446:	83 f8 01             	cmp    $0x1,%eax
  6e3449:	75 04                	jne    6e344f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2ef>
  6e344b:	31 c0                	xor    %eax,%eax
  6e344d:	eb 02                	jmp    6e3451 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2f1>
  6e344f:	b0 01                	mov    $0x1,%al
  6e3451:	4c 89 e1             	mov    %r12,%rcx
  6e3454:	4d 89 f4             	mov    %r14,%r12
  6e3457:	49 89 ce             	mov    %rcx,%r14
  6e345a:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  6e345f:	49 39 ed             	cmp    %rbp,%r13
  6e3462:	0f 93 c1             	setae  %cl
  6e3465:	08 c1                	or     %al,%cl
  6e3467:	88 4c 24 07          	mov    %cl,0x7(%rsp)
  6e346b:	31 f6                	xor    %esi,%esi
  6e346d:	49 89 77 40          	mov    %rsi,0x40(%r15)
  6e3471:	48 85 ed             	test   %rbp,%rbp
  6e3474:	74 1e                	je     6e3494 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x334>
  6e3476:	4d 85 ed             	test   %r13,%r13
  6e3479:	74 19                	je     6e3494 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x334>
  6e347b:	41 80 bc 24 26 07 00 	cmpb   $0x1,0x726(%r12)
  6e3482:	00 01 
  6e3484:	75 52                	jne    6e34d8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x378>
  6e3486:	48 c7 44 24 60 0e 00 	movq   $0xe,0x60(%rsp)
  6e348d:	00 00 
  6e348f:	e9 da 03 00 00       	jmp    6e386e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x70e>
  6e3494:	41 0f 10 84 24 68 06 	movups 0x668(%r12),%xmm0
  6e349b:	00 00 
  6e349d:	41 0f b6 84 24 24 07 	movzbl 0x724(%r12),%eax
  6e34a4:	00 00 
  6e34a6:	49 83 bc 24 88 06 00 	cmpq   $0x0,0x688(%r12)
  6e34ad:	00 00 
  6e34af:	0f 84 33 01 00 00    	je     6e35e8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x488>
  6e34b5:	84 c0                	test   %al,%al
  6e34b7:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  6e34bc:	0f 84 2f 01 00 00    	je     6e35f1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x491>
  6e34c2:	49 83 bc 24 88 05 00 	cmpq   $0xffffffffffffffff,0x588(%r12)
  6e34c9:	00 ff 
  6e34cb:	0f 85 20 01 00 00    	jne    6e35f1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x491>
  6e34d1:	31 c9                	xor    %ecx,%ecx
  6e34d3:	e9 26 01 00 00       	jmp    6e35fe <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x49e>
  6e34d8:	49 8b 9c 24 68 06 00 	mov    0x668(%r12),%rbx
  6e34df:	00 
  6e34e0:	48 ff c3             	inc    %rbx
  6e34e3:	0f 84 b3 06 00 00    	je     6e3b9c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa3c>
  6e34e9:	4d 8b 6f 28          	mov    0x28(%r15),%r13
  6e34ed:	4d 85 ed             	test   %r13,%r13
  6e34f0:	0f 84 c8 01 00 00    	je     6e36be <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x55e>
  6e34f6:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
  6e34fb:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
  6e3500:	49 8d bc 24 c0 05 00 	lea    0x5c0(%r12),%rdi
  6e3507:	00 
  6e3508:	4d 8b 67 10          	mov    0x10(%r15),%r12
  6e350c:	49 8b 77 18          	mov    0x18(%r15),%rsi
  6e3510:	4d 8b 47 38          	mov    0x38(%r15),%r8
  6e3514:	49 8b 47 20          	mov    0x20(%r15),%rax
  6e3518:	48 8d 48 01          	lea    0x1(%rax),%rcx
  6e351c:	31 d2                	xor    %edx,%edx
  6e351e:	4c 39 e1             	cmp    %r12,%rcx
  6e3521:	49 0f 43 d4          	cmovae %r12,%rdx
  6e3525:	48 f7 da             	neg    %rdx
  6e3528:	4c 8d 34 10          	lea    (%rax,%rdx,1),%r14
  6e352c:	49 ff c6             	inc    %r14
  6e352f:	4d 89 77 20          	mov    %r14,0x20(%r15)
  6e3533:	49 8d 4d ff          	lea    -0x1(%r13),%rcx
  6e3537:	49 89 4f 28          	mov    %rcx,0x28(%r15)
  6e353b:	48 89 b4 24 f0 00 00 	mov    %rsi,0xf0(%rsp)
  6e3542:	00 
  6e3543:	48 8b 34 c6          	mov    (%rsi,%rax,8),%rsi
  6e3547:	48 89 bc 24 f8 00 00 	mov    %rdi,0xf8(%rsp)
  6e354e:	00 
  6e354f:	4c 89 84 24 e8 00 00 	mov    %r8,0xe8(%rsp)
  6e3556:	00 
  6e3557:	41 ff d0             	call   *%r8
  6e355a:	48 83 fd 01          	cmp    $0x1,%rbp
  6e355e:	0f 84 d1 00 00 00    	je     6e3635 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x4d5>
  6e3564:	48 89 9c 24 e0 00 00 	mov    %rbx,0xe0(%rsp)
  6e356b:	00 
  6e356c:	49 83 c5 fe          	add    $0xfffffffffffffffe,%r13
  6e3570:	bb 01 00 00 00       	mov    $0x1,%ebx
  6e3575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  6e357c:	00 00 00 00 
  6e3580:	49 83 fd ff          	cmp    $0xffffffffffffffff,%r13
  6e3584:	0f 84 bd 00 00 00    	je     6e3647 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x4e7>
  6e358a:	49 8d 46 01          	lea    0x1(%r14),%rax
  6e358e:	4c 39 e0             	cmp    %r12,%rax
  6e3591:	4c 89 e0             	mov    %r12,%rax
  6e3594:	b9 00 00 00 00       	mov    $0x0,%ecx
  6e3599:	48 0f 42 c1          	cmovb  %rcx,%rax
  6e359d:	48 f7 d8             	neg    %rax
  6e35a0:	49 8d 2c 06          	lea    (%r14,%rax,1),%rbp
  6e35a4:	48 ff c5             	inc    %rbp
  6e35a7:	49 89 6f 20          	mov    %rbp,0x20(%r15)
  6e35ab:	4d 89 6f 28          	mov    %r13,0x28(%r15)
  6e35af:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  6e35b6:	00 
  6e35b7:	4a 8b 34 f0          	mov    (%rax,%r14,8),%rsi
  6e35bb:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  6e35c2:	00 
  6e35c3:	ff 94 24 e8 00 00 00 	call   *0xe8(%rsp)
  6e35ca:	48 89 d8             	mov    %rbx,%rax
  6e35cd:	48 ff c0             	inc    %rax
  6e35d0:	49 ff cd             	dec    %r13
  6e35d3:	49 89 ee             	mov    %rbp,%r14
  6e35d6:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  6e35db:	48 89 c3             	mov    %rax,%rbx
  6e35de:	48 39 c5             	cmp    %rax,%rbp
  6e35e1:	75 9d                	jne    6e3580 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x420>
  6e35e3:	49 89 ed             	mov    %rbp,%r13
  6e35e6:	eb 62                	jmp    6e364a <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x4ea>
  6e35e8:	31 c9                	xor    %ecx,%ecx
  6e35ea:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
  6e35ef:	eb 0d                	jmp    6e35fe <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x49e>
  6e35f1:	49 8b 94 24 98 06 00 	mov    0x698(%r12),%rdx
  6e35f8:	00 
  6e35f9:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e35fe:	49 8b b4 24 10 07 00 	mov    0x710(%r12),%rsi
  6e3605:	00 
  6e3606:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
  6e360a:	48 89 53 10          	mov    %rdx,0x10(%rbx)
  6e360e:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
  6e3612:	48 89 73 28          	mov    %rsi,0x28(%rbx)
  6e3616:	88 43 30             	mov    %al,0x30(%rbx)
  6e3619:	4c 89 73 38          	mov    %r14,0x38(%rbx)
  6e361d:	48 c7 43 40 00 00 00 	movq   $0x0,0x40(%rbx)
  6e3624:	00 
  6e3625:	c6 43 48 00          	movb   $0x0,0x48(%rbx)
  6e3629:	48 c7 03 ff ff ff ff 	movq   $0xffffffffffffffff,(%rbx)
  6e3630:	e9 ee 03 00 00       	jmp    6e3a23 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8c3>
  6e3635:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  6e363b:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  6e3640:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  6e3645:	eb 1a                	jmp    6e3661 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x501>
  6e3647:	49 89 dd             	mov    %rbx,%r13
  6e364a:	4d 85 ed             	test   %r13,%r13
  6e364d:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  6e3652:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  6e3657:	48 8b 9c 24 e0 00 00 	mov    0xe0(%rsp),%rbx
  6e365e:	00 
  6e365f:	74 5d                	je     6e36be <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x55e>
  6e3661:	49 89 9c 24 68 06 00 	mov    %rbx,0x668(%r12)
  6e3668:	00 
  6e3669:	49 ff 84 24 b8 06 00 	incq   0x6b8(%r12)
  6e3670:	00 
  6e3671:	48 c7 84 24 20 01 00 	movq   $0xfffffffffffffffe,0x120(%rsp)
  6e3678:	00 fe ff ff ff 
  6e367d:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
  6e3684:	00 00 00 00 00 
  6e3689:	49 ff 84 24 08 07 00 	incq   0x708(%r12)
  6e3690:	00 
  6e3691:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6e3696:	4c 89 e6             	mov    %r12,%rsi
  6e3699:	4c 89 fa             	mov    %r15,%rdx
  6e369c:	e8 4f f7 ff ff       	call   6e2df0 <<gpui::runtime::RuntimeMut<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::describe_with_changed>
  6e36a1:	83 7c 24 20 fe       	cmpl   $0xfffffffe,0x20(%rsp)
  6e36a6:	75 51                	jne    6e36f9 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x599>
  6e36a8:	c6 84 24 a8 00 00 00 	movb   $0x0,0xa8(%rsp)
  6e36af:	00 
  6e36b0:	48 c7 84 24 a0 00 00 	movq   $0xfffffffffffffffe,0xa0(%rsp)
  6e36b7:	00 fe ff ff ff 
  6e36bc:	eb 7e                	jmp    6e373c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5dc>
  6e36be:	41 0f 10 84 24 68 06 	movups 0x668(%r12),%xmm0
  6e36c5:	00 00 
  6e36c7:	41 0f b6 84 24 24 07 	movzbl 0x724(%r12),%eax
  6e36ce:	00 00 
  6e36d0:	49 83 bc 24 88 06 00 	cmpq   $0x0,0x688(%r12)
  6e36d7:	00 00 
  6e36d9:	74 17                	je     6e36f2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x592>
  6e36db:	84 c0                	test   %al,%al
  6e36dd:	0f 84 4f 01 00 00    	je     6e3832 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6d2>
  6e36e3:	49 83 bc 24 88 05 00 	cmpq   $0xffffffffffffffff,0x588(%r12)
  6e36ea:	00 ff 
  6e36ec:	0f 85 40 01 00 00    	jne    6e3832 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6d2>
  6e36f2:	31 c9                	xor    %ecx,%ecx
  6e36f4:	e9 46 01 00 00       	jmp    6e383f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6df>
  6e36f9:	0f 10 44 24 20       	movups 0x20(%rsp),%xmm0
  6e36fe:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
  6e3703:	0f 10 54 24 40       	movups 0x40(%rsp),%xmm2
  6e3708:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6e370f:	00 
  6e3710:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6e3715:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6e371c:	00 
  6e371d:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
  6e3724:	00 
  6e3725:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
  6e372c:	00 
  6e372d:	48 83 bc 24 a0 00 00 	cmpq   $0xfffffffffffffffe,0xa0(%rsp)
  6e3734:	00 fe 
  6e3736:	0f 85 fc 02 00 00    	jne    6e3a38 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8d8>
  6e373c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6e3741:	48 8d 94 24 00 01 00 	lea    0x100(%rsp),%rdx
  6e3748:	00 
  6e3749:	4c 89 e6             	mov    %r12,%rsi
  6e374c:	e8 5f 0b 00 00       	call   6e42b0 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::reconcile_editing>
  6e3751:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6e3756:	44 0f b6 64 24 28    	movzbl 0x28(%rsp),%r12d
  6e375c:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6e3760:	0f 85 9a 00 00 00    	jne    6e3800 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6a0>
  6e3766:	48 8d 35 cb 40 97 ff 	lea    -0x68bf35(%rip),%rsi        # 57838 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x15c8>
  6e376d:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6e3774:	00 
  6e3775:	e8 76 2b 01 00       	call   6f62f0 <<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error> as core::cmp::PartialEq>::eq>
  6e377a:	84 c0                	test   %al,%al
  6e377c:	74 2b                	je     6e37a9 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x649>
  6e377e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6e3783:	48 8b 80 18 06 00 00 	mov    0x618(%rax),%rax
  6e378a:	48 85 c0             	test   %rax,%rax
  6e378d:	0f 84 70 03 00 00    	je     6e3b03 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9a3>
  6e3793:	48 83 b8 d8 00 00 00 	cmpq   $0x0,0xd8(%rax)
  6e379a:	00 
  6e379b:	0f 95 c0             	setne  %al
  6e379e:	44 08 e0             	or     %r12b,%al
  6e37a1:	a8 01                	test   $0x1,%al
  6e37a3:	0f 84 64 03 00 00    	je     6e3b0d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9ad>
  6e37a9:	48 8d 35 c0 40 97 ff 	lea    -0x68bf40(%rip),%rsi        # 57870 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x1600>
  6e37b0:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6e37b7:	00 
  6e37b8:	e8 33 2b 01 00       	call   6f62f0 <<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error> as core::cmp::PartialEq>::eq>
  6e37bd:	84 c0                	test   %al,%al
  6e37bf:	74 2b                	je     6e37ec <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x68c>
  6e37c1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6e37c6:	48 8b 80 18 06 00 00 	mov    0x618(%rax),%rax
  6e37cd:	48 85 c0             	test   %rax,%rax
  6e37d0:	0f 84 6c 03 00 00    	je     6e3b42 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9e2>
  6e37d6:	48 83 b8 d8 00 00 00 	cmpq   $0x0,0xd8(%rax)
  6e37dd:	00 
  6e37de:	0f 95 c0             	setne  %al
  6e37e1:	44 08 e0             	or     %r12b,%al
  6e37e4:	a8 01                	test   $0x1,%al
  6e37e6:	0f 84 60 03 00 00    	je     6e3b4c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9ec>
  6e37ec:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e37f1:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  6e37f6:	4c 89 e6             	mov    %r12,%rsi
  6e37f9:	e8 f2 1b 01 00       	call   6f53f0 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::present>
  6e37fe:	eb 71                	jmp    6e3871 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x711>
  6e3800:	0f 10 44 24 29       	movups 0x29(%rsp),%xmm0
  6e3805:	0f 10 4c 24 39       	movups 0x39(%rsp),%xmm1
  6e380a:	0f 10 54 24 48       	movups 0x48(%rsp),%xmm2
  6e380f:	0f 11 94 24 88 00 00 	movups %xmm2,0x88(%rsp)
  6e3816:	00 
  6e3817:	0f 11 4c 24 79       	movups %xmm1,0x79(%rsp)
  6e381c:	0f 11 44 24 69       	movups %xmm0,0x69(%rsp)
  6e3821:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6e3826:	44 88 64 24 68       	mov    %r12b,0x68(%rsp)
  6e382b:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  6e3830:	eb 3f                	jmp    6e3871 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x711>
  6e3832:	49 8b 94 24 98 06 00 	mov    0x698(%r12),%rdx
  6e3839:	00 
  6e383a:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e383f:	49 8b b4 24 10 07 00 	mov    0x710(%r12),%rsi
  6e3846:	00 
  6e3847:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6e384c:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6e3851:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
  6e3856:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
  6e385d:	00 
  6e385e:	88 84 24 90 00 00 00 	mov    %al,0x90(%rsp)
  6e3865:	48 c7 44 24 60 fe ff 	movq   $0xfffffffffffffffe,0x60(%rsp)
  6e386c:	ff ff 
  6e386e:	45 31 ed             	xor    %r13d,%r13d
  6e3871:	41 80 bc 24 26 07 00 	cmpb   $0x0,0x726(%r12)
  6e3878:	00 00 
  6e387a:	75 10                	jne    6e388c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x72c>
  6e387c:	49 8b 84 24 68 06 00 	mov    0x668(%r12),%rax
  6e3883:	00 
  6e3884:	b1 01                	mov    $0x1,%cl
  6e3886:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6e388a:	75 62                	jne    6e38ee <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x78e>
  6e388c:	49 8b 07             	mov    (%r15),%rax
  6e388f:	49 8b 4f 08          	mov    0x8(%r15),%rcx
  6e3893:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  6e389a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6e389f:	48 89 4c 24 28       	mov    %rcx,0x28(%rsp)
  6e38a4:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6e38a8:	74 0a                	je     6e38b4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x754>
  6e38aa:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6e38af:	e8 2c 3d 02 00       	call   7075e0 <<std::sync::mpmc::Receiver<u64> as core::ops::drop::Drop>::drop>
  6e38b4:	49 c7 07 ff ff ff ff 	movq   $0xffffffffffffffff,(%r15)
  6e38bb:	49 83 7f 28 00       	cmpq   $0x0,0x28(%r15)
  6e38c0:	74 08                	je     6e38ca <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x76a>
  6e38c2:	49 c7 47 28 00 00 00 	movq   $0x0,0x28(%r15)
  6e38c9:	00 
  6e38ca:	49 c7 47 20 00 00 00 	movq   $0x0,0x20(%r15)
  6e38d1:	00 
  6e38d2:	49 c7 47 30 00 00 00 	movq   $0x0,0x30(%r15)
  6e38d9:	00 
  6e38da:	41 0f b6 8c 24 26 07 	movzbl 0x726(%r12),%ecx
  6e38e1:	00 00 
  6e38e3:	49 8b 84 24 68 06 00 	mov    0x668(%r12),%rax
  6e38ea:	00 
  6e38eb:	80 f1 01             	xor    $0x1,%cl
  6e38ee:	48 85 ed             	test   %rbp,%rbp
  6e38f1:	41 0f 95 c2          	setne  %r10b
  6e38f5:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
  6e38fa:	4d 8b 5f 28          	mov    0x28(%r15),%r11
  6e38fe:	44 22 54 24 07       	and    0x7(%rsp),%r10b
  6e3903:	41 0f b6 94 24 24 07 	movzbl 0x724(%r12),%edx
  6e390a:	00 00 
  6e390c:	49 83 bc 24 88 06 00 	cmpq   $0x0,0x688(%r12)
  6e3913:	00 00 
  6e3915:	74 24                	je     6e393b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x7db>
  6e3917:	4c 89 eb             	mov    %r13,%rbx
  6e391a:	84 d2                	test   %dl,%dl
  6e391c:	74 0b                	je     6e3929 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x7c9>
  6e391e:	49 83 bc 24 88 05 00 	cmpq   $0xffffffffffffffff,0x588(%r12)
  6e3925:	00 ff 
  6e3927:	74 15                	je     6e393e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x7de>
  6e3929:	4d 89 f5             	mov    %r14,%r13
  6e392c:	49 8b bc 24 98 06 00 	mov    0x698(%r12),%rdi
  6e3933:	00 
  6e3934:	be 01 00 00 00       	mov    $0x1,%esi
  6e3939:	eb 08                	jmp    6e3943 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x7e3>
  6e393b:	4c 89 eb             	mov    %r13,%rbx
  6e393e:	4d 89 f5             	mov    %r14,%r13
  6e3941:	31 f6                	xor    %esi,%esi
  6e3943:	4d 8b 84 24 70 06 00 	mov    0x670(%r12),%r8
  6e394a:	00 
  6e394b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6e394f:	40 0f 95 c5          	setne  %bpl
  6e3953:	4d 85 db             	test   %r11,%r11
  6e3956:	41 0f 95 c3          	setne  %r11b
  6e395a:	49 83 f9 fe          	cmp    $0xfffffffffffffffe,%r9
  6e395e:	41 0f 95 c6          	setne  %r14b
  6e3962:	45 20 de             	and    %r11b,%r14b
  6e3965:	45 08 f2             	or     %r14b,%r10b
  6e3968:	40 20 e9             	and    %bpl,%cl
  6e396b:	44 20 d1             	and    %r10b,%cl
  6e396e:	4d 8b 94 24 10 07 00 	mov    0x710(%r12),%r10
  6e3975:	00 
  6e3976:	49 83 f9 fe          	cmp    $0xfffffffffffffffe,%r9
  6e397a:	74 52                	je     6e39ce <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x86e>
  6e397c:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
  6e3983:	00 
  6e3984:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
  6e3989:	4c 89 4d 78          	mov    %r9,0x78(%rbp)
  6e398d:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  6e3992:	0f 28 4c 24 70       	movaps 0x70(%rsp),%xmm1
  6e3997:	0f 28 94 24 80 00 00 	movaps 0x80(%rsp),%xmm2
  6e399e:	00 
  6e399f:	0f 11 55 68          	movups %xmm2,0x68(%rbp)
  6e39a3:	0f 11 4d 58          	movups %xmm1,0x58(%rbp)
  6e39a7:	0f 11 45 48          	movups %xmm0,0x48(%rbp)
  6e39ab:	41 b9 40 00 00 00    	mov    $0x40,%r9d
  6e39b1:	41 bb 30 00 00 00    	mov    $0x30,%r11d
  6e39b7:	41 be 28 00 00 00    	mov    $0x28,%r14d
  6e39bd:	4d 89 ef             	mov    %r13,%r15
  6e39c0:	49 89 fc             	mov    %rdi,%r12
  6e39c3:	48 89 c7             	mov    %rax,%rdi
  6e39c6:	4c 89 c0             	mov    %r8,%rax
  6e39c9:	49 89 dd             	mov    %rbx,%r13
  6e39cc:	eb 2b                	jmp    6e39f9 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x899>
  6e39ce:	48 8b 6c 24 58       	mov    0x58(%rsp),%rbp
  6e39d3:	4c 89 55 28          	mov    %r10,0x28(%rbp)
  6e39d7:	41 b9 48 00 00 00    	mov    $0x48,%r9d
  6e39dd:	41 bb 40 00 00 00    	mov    $0x40,%r11d
  6e39e3:	41 be 30 00 00 00    	mov    $0x30,%r14d
  6e39e9:	49 89 df             	mov    %rbx,%r15
  6e39ec:	49 89 f4             	mov    %rsi,%r12
  6e39ef:	4d 89 c2             	mov    %r8,%r10
  6e39f2:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  6e39f9:	42 88 54 35 00       	mov    %dl,0x0(%rbp,%r14,1)
  6e39fe:	4e 89 7c 1d 00       	mov    %r15,0x0(%rbp,%r11,1)
  6e3a03:	42 88 4c 0d 00       	mov    %cl,0x0(%rbp,%r9,1)
  6e3a08:	4c 89 65 08          	mov    %r12,0x8(%rbp)
  6e3a0c:	48 89 7d 10          	mov    %rdi,0x10(%rbp)
  6e3a10:	48 89 45 18          	mov    %rax,0x18(%rbp)
  6e3a14:	4c 89 55 20          	mov    %r10,0x20(%rbp)
  6e3a18:	4c 89 6d 38          	mov    %r13,0x38(%rbp)
  6e3a1c:	48 89 75 00          	mov    %rsi,0x0(%rbp)
  6e3a20:	48 89 eb             	mov    %rbp,%rbx
  6e3a23:	48 89 d8             	mov    %rbx,%rax
  6e3a26:	48 81 c4 58 01 00 00 	add    $0x158,%rsp
  6e3a2d:	5b                   	pop    %rbx
  6e3a2e:	41 5c                	pop    %r12
  6e3a30:	41 5d                	pop    %r13
  6e3a32:	41 5e                	pop    %r14
  6e3a34:	41 5f                	pop    %r15
  6e3a36:	5d                   	pop    %rbp
  6e3a37:	c3                   	ret
  6e3a38:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6e3a3f:	00 
  6e3a40:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6e3a45:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6e3a4c:	00 
  6e3a4d:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
  6e3a54:	00 
  6e3a55:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
  6e3a5c:	00 
  6e3a5d:	0f 29 54 24 40       	movaps %xmm2,0x40(%rsp)
  6e3a62:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  6e3a67:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  6e3a6c:	49 8b 84 24 18 06 00 	mov    0x618(%r12),%rax
  6e3a73:	00 
  6e3a74:	48 85 c0             	test   %rax,%rax
  6e3a77:	74 42                	je     6e3abb <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x95b>
  6e3a79:	48 8b 80 e0 00 00 00 	mov    0xe0(%rax),%rax
  6e3a80:	48 85 c0             	test   %rax,%rax
  6e3a83:	74 36                	je     6e3abb <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x95b>
  6e3a85:	48 8b 78 10          	mov    0x10(%rax),%rdi
  6e3a89:	0f b6 48 24          	movzbl 0x24(%rax),%ecx
  6e3a8d:	c6 40 24 02          	movb   $0x2,0x24(%rax)
  6e3a91:	80 f9 02             	cmp    $0x2,%cl
  6e3a94:	74 25                	je     6e3abb <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x95b>
  6e3a96:	f6 07 01             	testb  $0x1,(%rdi)
  6e3a99:	75 17                	jne    6e3ab2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x952>
  6e3a9b:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e3a9f:	a8 01                	test   $0x1,%al
  6e3aa1:	75 0f                	jne    6e3ab2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x952>
  6e3aa3:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6e3aa7:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e3aac:	0f 84 f8 00 00 00    	je     6e3baa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa4a>
  6e3ab2:	41 c6 84 24 23 07 00 	movb   $0x1,0x723(%r12)
  6e3ab9:	00 01 
  6e3abb:	41 c6 84 24 22 07 00 	movb   $0x0,0x722(%r12)
  6e3ac2:	00 00 
  6e3ac4:	49 c7 84 24 f0 05 00 	movq   $0x0,0x5f0(%r12)
  6e3acb:	00 00 00 00 00 
  6e3ad0:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6e3ad5:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6e3adc:	00 
  6e3add:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  6e3ae2:	0f 28 4c 24 30       	movaps 0x30(%rsp),%xmm1
  6e3ae7:	0f 28 54 24 40       	movaps 0x40(%rsp),%xmm2
  6e3aec:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
  6e3af3:	00 
  6e3af4:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  6e3af9:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6e3afe:	e9 6e fd ff ff       	jmp    6e3871 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x711>
  6e3b03:	41 80 fc 01          	cmp    $0x1,%r12b
  6e3b07:	0f 84 9c fc ff ff    	je     6e37a9 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x649>
  6e3b0d:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  6e3b12:	41 0f 10 84 24 68 06 	movups 0x668(%r12),%xmm0
  6e3b19:	00 00 
  6e3b1b:	41 0f b6 84 24 24 07 	movzbl 0x724(%r12),%eax
  6e3b22:	00 00 
  6e3b24:	49 83 bc 24 88 06 00 	cmpq   $0x0,0x688(%r12)
  6e3b2b:	00 00 
  6e3b2d:	74 0f                	je     6e3b3e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9de>
  6e3b2f:	84 c0                	test   %al,%al
  6e3b31:	74 28                	je     6e3b5b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9fb>
  6e3b33:	49 83 bc 24 88 05 00 	cmpq   $0xffffffffffffffff,0x588(%r12)
  6e3b3a:	00 ff 
  6e3b3c:	75 1d                	jne    6e3b5b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9fb>
  6e3b3e:	31 c9                	xor    %ecx,%ecx
  6e3b40:	eb 26                	jmp    6e3b68 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa08>
  6e3b42:	41 80 fc 01          	cmp    $0x1,%r12b
  6e3b46:	0f 84 a0 fc ff ff    	je     6e37ec <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x68c>
  6e3b4c:	48 8d 3d 8d 39 37 00 	lea    0x37398d(%rip),%rdi        # a574e0 <__frame_dummy_init_array_entry+0x628>
  6e3b53:	ff 15 8f c4 39 00    	call   *0x39c48f(%rip)        # a7ffe8 <_DYNAMIC+0x288>
  6e3b59:	0f 0b                	ud2
  6e3b5b:	49 8b 94 24 98 06 00 	mov    0x698(%r12),%rdx
  6e3b62:	00 
  6e3b63:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e3b68:	49 8b b4 24 10 07 00 	mov    0x710(%r12),%rsi
  6e3b6f:	00 
  6e3b70:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6e3b75:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  6e3b7a:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
  6e3b7f:	48 89 b4 24 88 00 00 	mov    %rsi,0x88(%rsp)
  6e3b86:	00 
  6e3b87:	88 84 24 90 00 00 00 	mov    %al,0x90(%rsp)
  6e3b8e:	48 c7 44 24 60 fe ff 	movq   $0xfffffffffffffffe,0x60(%rsp)
  6e3b95:	ff ff 
  6e3b97:	e9 d5 fc ff ff       	jmp    6e3871 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x711>
  6e3b9c:	48 c7 44 24 60 20 00 	movq   $0x20,0x60(%rsp)
  6e3ba3:	00 00 
  6e3ba5:	e9 c4 fc ff ff       	jmp    6e386e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x70e>
  6e3baa:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e3bae:	ff 15 54 c4 39 00    	call   *0x39c454(%rip)        # a80008 <_DYNAMIC+0x2a8>
  6e3bb4:	e9 f9 fe ff ff       	jmp    6e3ab2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x952>
  6e3bb9:	48 89 c3             	mov    %rax,%rbx
  6e3bbc:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6e3bc1:	e8 2a c7 ff ff       	call   6e02f0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3bc6:	eb 19                	jmp    6e3be1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa81>
  6e3bc8:	31 db                	xor    %ebx,%ebx
  6e3bca:	eb 6e                	jmp    6e3c3a <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xada>
  6e3bcc:	48 89 c3             	mov    %rax,%rbx
  6e3bcf:	48 83 7c 24 60 fe    	cmpq   $0xfffffffffffffffe,0x60(%rsp)
  6e3bd5:	74 5b                	je     6e3c32 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xad2>
  6e3bd7:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e3bdc:	eb 4f                	jmp    6e3c2d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xacd>
  6e3bde:	48 89 c3             	mov    %rax,%rbx
  6e3be1:	83 bc 24 20 01 00 00 	cmpl   $0xfffffffe,0x120(%rsp)
  6e3be8:	fe 
  6e3be9:	74 0d                	je     6e3bf8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa98>
  6e3beb:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
  6e3bf2:	00 
  6e3bf3:	e8 f8 c6 ff ff       	call   6e02f0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3bf8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6e3bfd:	80 b8 26 07 00 00 00 	cmpb   $0x0,0x726(%rax)
  6e3c04:	75 0f                	jne    6e3c15 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xab5>
  6e3c06:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  6e3c0b:	48 83 b8 68 06 00 00 	cmpq   $0xffffffffffffffff,0x668(%rax)
  6e3c12:	ff 
  6e3c13:	75 1d                	jne    6e3c32 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xad2>
  6e3c15:	4c 89 ff             	mov    %r15,%rdi
  6e3c18:	e8 33 4e 03 00       	call   718a50 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e3c1d:	eb 13                	jmp    6e3c32 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xad2>
  6e3c1f:	ff 15 d3 c3 39 00    	call   *0x39c3d3(%rip)        # a7fff8 <_DYNAMIC+0x298>
  6e3c25:	48 89 c3             	mov    %rax,%rbx
  6e3c28:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6e3c2d:	e8 be c6 ff ff       	call   6e02f0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3c32:	48 89 df             	mov    %rbx,%rdi
  6e3c35:	e8 c6 1e 37 00       	call   a55b00 <_Unwind_Resume@plt>
  6e3c3a:	48 89 c7             	mov    %rax,%rdi
  6e3c3d:	ff 15 a5 c4 39 00    	call   *0x39c4a5(%rip)        # a800e8 <_DYNAMIC+0x388>
  6e3c43:	49 89 c6             	mov    %rax,%r14
  6e3c46:	49 89 d5             	mov    %rdx,%r13
  6e3c49:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  6e3c4e:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  6e3c53:	48 c7 44 24 20 fd ff 	movq   $0xfffffffffffffffd,0x20(%rsp)
  6e3c5a:	ff ff 
  6e3c5c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  6e3c61:	e8 ba 15 01 00       	call   6f5220 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::poison>
  6e3c66:	48 c7 44 24 60 0f 00 	movq   $0xf,0x60(%rsp)
  6e3c6d:	00 00 
  6e3c6f:	49 8b 45 00          	mov    0x0(%r13),%rax
  6e3c73:	48 85 c0             	test   %rax,%rax
  6e3c76:	74 05                	je     6e3c7d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb1d>
  6e3c78:	4c 89 f7             	mov    %r14,%rdi
  6e3c7b:	ff d0                	call   *%rax
  6e3c7d:	49 8b 75 08          	mov    0x8(%r13),%rsi
  6e3c81:	48 85 f6             	test   %rsi,%rsi
  6e3c84:	74 0d                	je     6e3c93 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb33>
  6e3c86:	49 8b 55 10          	mov    0x10(%r13),%rdx
  6e3c8a:	4c 89 f7             	mov    %r14,%rdi
  6e3c8d:	ff 15 15 c3 39 00    	call   *0x39c315(%rip)        # a7ffa8 <_DYNAMIC+0x248>
  6e3c93:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
  6e3c98:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
  6e3c9d:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  6e3ca2:	49 89 dd             	mov    %rbx,%r13
  6e3ca5:	e9 c7 fb ff ff       	jmp    6e3871 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x711>
  6e3caa:	48 89 c3             	mov    %rax,%rbx
  6e3cad:	49 8b 75 08          	mov    0x8(%r13),%rsi
  6e3cb1:	48 85 f6             	test   %rsi,%rsi
  6e3cb4:	0f 84 3e ff ff ff    	je     6e3bf8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa98>
  6e3cba:	49 8b 55 10          	mov    0x10(%r13),%rdx
  6e3cbe:	4c 89 f7             	mov    %r14,%rdi
  6e3cc1:	ff 15 e1 c2 39 00    	call   *0x39c2e1(%rip)        # a7ffa8 <_DYNAMIC+0x248>
  6e3cc7:	e9 2c ff ff ff       	jmp    6e3bf8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa98>
  6e3ccc:	48 89 c3             	mov    %rax,%rbx
  6e3ccf:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  6e3cd4:	e8 d7 9e ff ff       	call   6ddbb0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<(), gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e3cd9:	e9 1a ff ff ff       	jmp    6e3bf8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa98>
  6e3cde:	ff 15 14 c3 39 00    	call   *0x39c314(%rip)        # a7fff8 <_DYNAMIC+0x298>
  6e3ce4:	ff 15 06 c4 39 00    	call   *0x39c406(%rip)        # a800f0 <_DYNAMIC+0x390>
  6e3cea:	cc                   	int3
  6e3ceb:	cc                   	int3
  6e3cec:	cc                   	int3
  6e3ced:	cc                   	int3
  6e3cee:	cc                   	int3
  6e3cef:	cc                   	int3

0000000000716da0 <inbox_storage_control::clone_drop>:
  716da0:	48 83 ec 18          	sub    $0x18,%rsp
  716da4:	48 8b 07             	mov    (%rdi),%rax
  716da7:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
  716dab:	48 85 c0             	test   %rax,%rax
  716dae:	74 28                	je     716dd8 <inbox_storage_control::clone_drop+0x38>
  716db0:	83 f8 01             	cmp    $0x1,%eax
  716db3:	75 33                	jne    716de8 <inbox_storage_control::clone_drop+0x48>
  716db5:	f0 48 ff 81 80 01 00 	lock incq 0x180(%rcx)
  716dbc:	00 
  716dbd:	7e 23                	jle    716de2 <inbox_storage_control::clone_drop+0x42>
  716dbf:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  716dc4:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  716dc9:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  716dce:	e8 ed 05 ff ff       	call   7073c0 <<std::sync::mpmc::Sender<u64> as core::ops::drop::Drop>::drop>
  716dd3:	48 83 c4 18          	add    $0x18,%rsp
  716dd7:	c3                   	ret
  716dd8:	f0 48 ff 81 00 02 00 	lock incq 0x200(%rcx)
  716ddf:	00 
  716de0:	7f dd                	jg     716dbf <inbox_storage_control::clone_drop+0x1f>
  716de2:	ff 15 c8 96 36 00    	call   *0x3696c8(%rip)        # a804b0 <_DYNAMIC+0x750>
  716de8:	f0 48 ff 41 70       	lock incq 0x70(%rcx)
  716ded:	7f d0                	jg     716dbf <inbox_storage_control::clone_drop+0x1f>
  716def:	eb f1                	jmp    716de2 <inbox_storage_control::clone_drop+0x42>
  716df1:	cc                   	int3
  716df2:	cc                   	int3
  716df3:	cc                   	int3
  716df4:	cc                   	int3
  716df5:	cc                   	int3
  716df6:	cc                   	int3
  716df7:	cc                   	int3
  716df8:	cc                   	int3
  716df9:	cc                   	int3
  716dfa:	cc                   	int3
  716dfb:	cc                   	int3
  716dfc:	cc                   	int3
  716dfd:	cc                   	int3
  716dfe:	cc                   	int3
  716dff:	cc                   	int3

0000000000717520 <inbox_storage_control::send>:
  717520:	50                   	push   %rax
  717521:	48 8b 07             	mov    (%rdi),%rax
  717524:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
  717528:	48 85 c0             	test   %rax,%rax
  71752b:	74 13                	je     717540 <inbox_storage_control::send+0x20>
  71752d:	83 f8 01             	cmp    $0x1,%eax
  717530:	75 1c                	jne    71754e <inbox_storage_control::send+0x2e>
  717532:	e8 19 52 ff ff       	call   70c750 <<std::sync::mpmc::list::Channel<u64>>::try_send>
  717537:	48 83 f8 02          	cmp    $0x2,%rax
  71753b:	0f 94 c0             	sete   %al
  71753e:	59                   	pop    %rcx
  71753f:	c3                   	ret
  717540:	e8 1b 5e ff ff       	call   70d360 <<std::sync::mpmc::array::Channel<u64>>::try_send>
  717545:	48 83 f8 02          	cmp    $0x2,%rax
  717549:	0f 94 c0             	sete   %al
  71754c:	59                   	pop    %rcx
  71754d:	c3                   	ret
  71754e:	e8 0d 0c ff ff       	call   708160 <<std::sync::mpmc::zero::Channel<u64>>::try_send>
  717553:	48 83 f8 02          	cmp    $0x2,%rax
  717557:	0f 94 c0             	sete   %al
  71755a:	59                   	pop    %rcx
  71755b:	c3                   	ret
  71755c:	cc                   	int3
  71755d:	cc                   	int3
  71755e:	cc                   	int3
  71755f:	cc                   	int3

0000000000717560 <inbox_storage_control::deliver>:
  717560:	53                   	push   %rbx
  717561:	48 81 ec 00 01 00 00 	sub    $0x100,%rsp
  717568:	48 89 fb             	mov    %rdi,%rbx
  71756b:	48 89 e7             	mov    %rsp,%rdi
  71756e:	e8 ed bb fc ff       	call   6e3160 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready>
  717573:	83 3c 24 ff          	cmpl   $0xffffffff,(%rsp)
  717577:	75 38                	jne    7175b1 <inbox_storage_control::deliver+0x51>
  717579:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  71757e:	48 89 43 40          	mov    %rax,0x40(%rbx)
  717582:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  717587:	0f 10 4c 24 18       	movups 0x18(%rsp),%xmm1
  71758c:	0f 10 54 24 28       	movups 0x28(%rsp),%xmm2
  717591:	0f 10 5c 24 38       	movups 0x38(%rsp),%xmm3
  717596:	0f 11 5b 30          	movups %xmm3,0x30(%rbx)
  71759a:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
  71759e:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  7175a2:	0f 11 03             	movups %xmm0,(%rbx)
  7175a5:	48 89 d8             	mov    %rbx,%rax
  7175a8:	48 81 c4 00 01 00 00 	add    $0x100,%rsp
  7175af:	5b                   	pop    %rbx
  7175b0:	c3                   	ret
  7175b1:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
  7175b6:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  7175bd:	00 
  7175be:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  7175c3:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  7175ca:	00 
  7175cb:	0f 10 44 24 50       	movups 0x50(%rsp),%xmm0
  7175d0:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  7175d7:	00 
  7175d8:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
  7175dd:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  7175e4:	00 
  7175e5:	0f 10 04 24          	movups (%rsp),%xmm0
  7175e9:	0f 10 4c 24 10       	movups 0x10(%rsp),%xmm1
  7175ee:	0f 10 54 24 20       	movups 0x20(%rsp),%xmm2
  7175f3:	0f 10 5c 24 30       	movups 0x30(%rsp),%xmm3
  7175f8:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
  7175ff:	00 
  717600:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
  717607:	00 
  717608:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
  71760f:	00 
  717610:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  717617:	00 
  717618:	48 8d 3d 36 3d 94 ff 	lea    -0x6bc2ca(%rip),%rdi        # 5b355 <anon.14d7052634883c98ae045598a29fc04b.5.llvm.16790327002530131697+0x495>
  71761f:	48 8d 0d ea 0f 34 00 	lea    0x340fea(%rip),%rcx        # a58610 <anon.14d7052634883c98ae045598a29fc04b.0.llvm.16790327002530131697+0x248>
  717626:	4c 8d 05 b3 0f 34 00 	lea    0x340fb3(%rip),%r8        # a585e0 <anon.14d7052634883c98ae045598a29fc04b.0.llvm.16790327002530131697+0x218>
  71762d:	48 8d 94 24 80 00 00 	lea    0x80(%rsp),%rdx
  717634:	00 
  717635:	be 2b 00 00 00       	mov    $0x2b,%esi
  71763a:	ff 15 90 8a 36 00    	call   *0x368a90(%rip)        # a800d0 <_DYNAMIC+0x370>
  717640:	0f 0b                	ud2
  717642:	48 89 c3             	mov    %rax,%rbx
  717645:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
  71764c:	00 
  71764d:	e8 fe eb ff ff       	call   716250 <core::ptr::drop_glue::<gpui::runtime::Error>>
  717652:	48 89 df             	mov    %rbx,%rdi
  717655:	e8 a6 e4 33 00       	call   a55b00 <_Unwind_Resume@plt>
  71765a:	cc                   	int3
  71765b:	cc                   	int3
  71765c:	cc                   	int3
  71765d:	cc                   	int3
  71765e:	cc                   	int3
  71765f:	cc                   	int3

0000000000717660 <inbox_storage_control::ordinary>:
  717660:	53                   	push   %rbx
  717661:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  717668:	48 89 f8             	mov    %rdi,%rax
  71766b:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  717670:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  717675:	48 8d 54 24 08       	lea    0x8(%rsp),%rdx
  71767a:	48 89 c6             	mov    %rax,%rsi
  71767d:	e8 de 4c fc ff       	call   6dc360 <<gpui::runtime::Win<inbox_storage_control::Page>>::update::<inbox_storage_control::ordinary::{closure#0}>>
  717682:	83 7c 24 48 fe       	cmpl   $0xfffffffe,0x48(%rsp)
  717687:	75 09                	jne    717692 <inbox_storage_control::ordinary+0x32>
  717689:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  717690:	5b                   	pop    %rbx
  717691:	c3                   	ret
  717692:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  717697:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  71769c:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  7176a1:	0f 10 4c 24 58       	movups 0x58(%rsp),%xmm1
  7176a6:	0f 10 54 24 68       	movups 0x68(%rsp),%xmm2
  7176ab:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
  7176b0:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
  7176b5:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  7176ba:	48 8d 3d 94 3c 94 ff 	lea    -0x6bc36c(%rip),%rdi        # 5b355 <anon.14d7052634883c98ae045598a29fc04b.5.llvm.16790327002530131697+0x495>
  7176c1:	48 8d 0d 68 0f 34 00 	lea    0x340f68(%rip),%rcx        # a58630 <anon.14d7052634883c98ae045598a29fc04b.0.llvm.16790327002530131697+0x268>
  7176c8:	4c 8d 05 29 0f 34 00 	lea    0x340f29(%rip),%r8        # a585f8 <anon.14d7052634883c98ae045598a29fc04b.0.llvm.16790327002530131697+0x230>
  7176cf:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  7176d4:	be 2b 00 00 00       	mov    $0x2b,%esi
  7176d9:	ff 15 f1 89 36 00    	call   *0x3689f1(%rip)        # a800d0 <_DYNAMIC+0x370>
  7176df:	0f 0b                	ud2
  7176e1:	48 89 c3             	mov    %rax,%rbx
  7176e4:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  7176e9:	e8 62 eb ff ff       	call   716250 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7176ee:	48 89 df             	mov    %rbx,%rdi
  7176f1:	e8 0a e4 33 00       	call   a55b00 <_Unwind_Resume@plt>
  7176f6:	cc                   	int3
  7176f7:	cc                   	int3
  7176f8:	cc                   	int3
  7176f9:	cc                   	int3
  7176fa:	cc                   	int3
  7176fb:	cc                   	int3
  7176fc:	cc                   	int3
  7176fd:	cc                   	int3
  7176fe:	cc                   	int3
  7176ff:	cc                   	int3

0000000000717700 <inbox_storage_control::transport>:
  717700:	55                   	push   %rbp
  717701:	41 57                	push   %r15
  717703:	41 56                	push   %r14
  717705:	41 55                	push   %r13
  717707:	41 54                	push   %r12
  717709:	53                   	push   %rbx
  71770a:	48 83 ec 38          	sub    $0x38,%rsp
  71770e:	49 89 f6             	mov    %rsi,%r14
  717711:	48 89 fb             	mov    %rdi,%rbx
  717714:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  717719:	e8 e2 e7 fe ff       	call   705f00 <std::sync::mpmc::sync_channel::<u64>>
  71771e:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  717723:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  717728:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
  71772d:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  717732:	4c 89 6c 24 28       	mov    %r13,0x28(%rsp)
  717737:	48 89 6c 24 30       	mov    %rbp,0x30(%rsp)
  71773c:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
  717741:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  717746:	4e 8d 3c f5 00 00 00 	lea    0x0(,%r14,8),%r15
  71774d:	00 
  71774e:	4c 89 f0             	mov    %r14,%rax
  717751:	48 c1 e8 3d          	shr    $0x3d,%rax
  717755:	0f 95 c0             	setne  %al
  717758:	48 b9 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rcx
  71775f:	ff ff 7f 
  717762:	49 39 cf             	cmp    %rcx,%r15
  717765:	0f 97 c1             	seta   %cl
  717768:	08 c1                	or     %al,%cl
  71776a:	74 0d                	je     717779 <inbox_storage_control::transport+0x79>
  71776c:	31 ff                	xor    %edi,%edi
  71776e:	4c 89 fe             	mov    %r15,%rsi
  717771:	ff 15 11 89 36 00    	call   *0x368911(%rip)        # a80088 <_DYNAMIC+0x328>
  717777:	0f 0b                	ud2
  717779:	4d 85 ff             	test   %r15,%r15
  71777c:	74 2b                	je     7177a9 <inbox_storage_control::transport+0xa9>
  71777e:	48 89 14 24          	mov    %rdx,(%rsp)
  717782:	ff 15 38 88 36 00    	call   *0x368838(%rip)        # a7ffc0 <_DYNAMIC+0x260>
  717788:	be 08 00 00 00       	mov    $0x8,%esi
  71778d:	4c 89 ff             	mov    %r15,%rdi
  717790:	ff 15 0a 88 36 00    	call   *0x36880a(%rip)        # a7ffa0 <_DYNAMIC+0x240>
  717796:	bf 08 00 00 00       	mov    $0x8,%edi
  71779b:	48 85 c0             	test   %rax,%rax
  71779e:	74 ce                	je     71776e <inbox_storage_control::transport+0x6e>
  7177a0:	4c 89 f1             	mov    %r14,%rcx
  7177a3:	48 8b 14 24          	mov    (%rsp),%rdx
  7177a7:	eb 07                	jmp    7177b0 <inbox_storage_control::transport+0xb0>
  7177a9:	b8 08 00 00 00       	mov    $0x8,%eax
  7177ae:	31 c9                	xor    %ecx,%ecx
  7177b0:	4c 89 2b             	mov    %r13,(%rbx)
  7177b3:	48 89 6b 08          	mov    %rbp,0x8(%rbx)
  7177b7:	4c 89 63 10          	mov    %r12,0x10(%rbx)
  7177bb:	48 89 53 18          	mov    %rdx,0x18(%rbx)
  7177bf:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
  7177c3:	48 89 43 28          	mov    %rax,0x28(%rbx)
  7177c7:	0f 57 c0             	xorps  %xmm0,%xmm0
  7177ca:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  7177ce:	4c 89 73 40          	mov    %r14,0x40(%rbx)
  7177d2:	48 89 d8             	mov    %rbx,%rax
  7177d5:	48 83 c4 38          	add    $0x38,%rsp
  7177d9:	5b                   	pop    %rbx
  7177da:	41 5c                	pop    %r12
  7177dc:	41 5d                	pop    %r13
  7177de:	41 5e                	pop    %r14
  7177e0:	41 5f                	pop    %r15
  7177e2:	5d                   	pop    %rbp
  7177e3:	c3                   	ret
  7177e4:	48 89 c3             	mov    %rax,%rbx
  7177e7:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  7177ec:	e8 ef fd fe ff       	call   7075e0 <<std::sync::mpmc::Receiver<u64> as core::ops::drop::Drop>::drop>
  7177f1:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  7177f6:	e8 c5 fb fe ff       	call   7073c0 <<std::sync::mpmc::Sender<u64> as core::ops::drop::Drop>::drop>
  7177fb:	48 89 df             	mov    %rbx,%rdi
  7177fe:	e8 fd e2 33 00       	call   a55b00 <_Unwind_Resume@plt>
  717803:	ff 15 ef 87 36 00    	call   *0x3687ef(%rip)        # a7fff8 <_DYNAMIC+0x298>
  717809:	cc                   	int3
  71780a:	cc                   	int3
  71780b:	cc                   	int3
  71780c:	cc                   	int3
  71780d:	cc                   	int3
  71780e:	cc                   	int3
  71780f:	cc                   	int3

0000000000718900 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage>:
  718900:	48 85 f6             	test   %rsi,%rsi
  718903:	74 03                	je     718908 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x8>
  718905:	b0 01                	mov    $0x1,%al
  718907:	c3                   	ret
  718908:	48 8b 4f 30          	mov    0x30(%rdi),%rcx
  71890c:	48 85 c9             	test   %rcx,%rcx
  71890f:	74 f4                	je     718905 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x5>
  718911:	41 57                	push   %r15
  718913:	41 56                	push   %r14
  718915:	53                   	push   %rbx
  718916:	48 83 ec 10          	sub    $0x10,%rsp
  71891a:	48 8b 5f 28          	mov    0x28(%rdi),%rbx
  71891e:	b0 02                	mov    $0x2,%al
  718920:	48 39 cb             	cmp    %rcx,%rbx
  718923:	0f 84 85 00 00 00    	je     7189ae <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0xae>
  718929:	48 8b 07             	mov    (%rdi),%rax
  71892c:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  718930:	74 1b                	je     71894d <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x4d>
  718932:	48 8b 77 08          	mov    0x8(%rdi),%rsi
  718936:	48 85 c0             	test   %rax,%rax
  718939:	49 89 fe             	mov    %rdi,%r14
  71893c:	48 89 e7             	mov    %rsp,%rdi
  71893f:	74 10                	je     718951 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x51>
  718941:	83 f8 01             	cmp    $0x1,%eax
  718944:	75 12                	jne    718958 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x58>
  718946:	e8 e5 39 ff ff       	call   70c330 <<std::sync::mpmc::list::Channel<u64>>::try_recv>
  71894b:	eb 10                	jmp    71895d <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x5d>
  71894d:	b0 01                	mov    $0x1,%al
  71894f:	eb 5d                	jmp    7189ae <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0xae>
  718951:	e8 ca 47 ff ff       	call   70d120 <<std::sync::mpmc::array::Channel<u64>>::try_recv>
  718956:	eb 05                	jmp    71895d <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x5d>
  718958:	e8 f3 f3 fe ff       	call   707d50 <<std::sync::mpmc::zero::Channel<u64>>::try_recv>
  71895d:	80 3c 24 00          	cmpb   $0x0,(%rsp)
  718961:	b0 01                	mov    $0x1,%al
  718963:	75 49                	jne    7189ae <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0xae>
  718965:	4c 89 f1             	mov    %r14,%rcx
  718968:	49 8d 7e 10          	lea    0x10(%r14),%rdi
  71896c:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
  718971:	48 8b 17             	mov    (%rdi),%rdx
  718974:	48 39 d3             	cmp    %rdx,%rbx
  718977:	75 10                	jne    718989 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x89>
  718979:	e8 32 8f ff ff       	call   7118b0 <<alloc::collections::vec_deque::VecDeque<u64>>::grow>
  71897e:	4c 89 f1             	mov    %r14,%rcx
  718981:	49 8b 56 10          	mov    0x10(%r14),%rdx
  718985:	49 8b 5e 28          	mov    0x28(%r14),%rbx
  718989:	48 8d 43 01          	lea    0x1(%rbx),%rax
  71898d:	48 89 41 28          	mov    %rax,0x28(%rcx)
  718991:	48 03 59 20          	add    0x20(%rcx),%rbx
  718995:	31 c0                	xor    %eax,%eax
  718997:	48 39 d3             	cmp    %rdx,%rbx
  71899a:	be 00 00 00 00       	mov    $0x0,%esi
  71899f:	48 0f 43 f2          	cmovae %rdx,%rsi
  7189a3:	48 29 f3             	sub    %rsi,%rbx
  7189a6:	48 8b 49 18          	mov    0x18(%rcx),%rcx
  7189aa:	4c 89 3c d9          	mov    %r15,(%rcx,%rbx,8)
  7189ae:	48 83 c4 10          	add    $0x10,%rsp
  7189b2:	5b                   	pop    %rbx
  7189b3:	41 5e                	pop    %r14
  7189b5:	41 5f                	pop    %r15
  7189b7:	c3                   	ret
  7189b8:	cc                   	int3
  7189b9:	cc                   	int3
  7189ba:	cc                   	int3
  7189bb:	cc                   	int3
  7189bc:	cc                   	int3
  7189bd:	cc                   	int3
  7189be:	cc                   	int3
  7189bf:	cc                   	int3

