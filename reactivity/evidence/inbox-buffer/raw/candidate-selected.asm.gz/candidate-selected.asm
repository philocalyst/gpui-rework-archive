00000000006e31f0 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready>:
  6e31f0:	55                   	push   %rbp
  6e31f1:	41 57                	push   %r15
  6e31f3:	41 56                	push   %r14
  6e31f5:	41 55                	push   %r13
  6e31f7:	41 54                	push   %r12
  6e31f9:	53                   	push   %rbx
  6e31fa:	48 81 ec e8 04 00 00 	sub    $0x4e8,%rsp
  6e3201:	49 89 fe             	mov    %rdi,%r14
  6e3204:	48 8b 1e             	mov    (%rsi),%rbx
  6e3207:	48 85 db             	test   %rbx,%rbx
  6e320a:	74 54                	je     6e3260 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x70>
  6e320c:	4c 8d 66 08          	lea    0x8(%rsi),%r12
  6e3210:	80 bb 26 07 00 00 00 	cmpb   $0x0,0x726(%rbx)
  6e3217:	74 5b                	je     6e3274 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x84>
  6e3219:	48 c7 44 24 60 0e 00 	movq   $0xe,0x60(%rsp)
  6e3220:	00 00 
  6e3222:	4c 89 e7             	mov    %r12,%rdi
  6e3225:	e8 66 37 02 00       	call   706990 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e322a:	f3 0f 6f 83 68 06 00 	movdqu 0x668(%rbx),%xmm0
  6e3231:	00 
  6e3232:	0f b6 83 24 07 00 00 	movzbl 0x724(%rbx),%eax
  6e3239:	48 83 bb 88 06 00 00 	cmpq   $0x0,0x688(%rbx)
  6e3240:	00 
  6e3241:	74 16                	je     6e3259 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x69>
  6e3243:	84 c0                	test   %al,%al
  6e3245:	0f 84 a9 00 00 00    	je     6e32f4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x104>
  6e324b:	48 83 bb 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rbx)
  6e3252:	ff 
  6e3253:	0f 85 9b 00 00 00    	jne    6e32f4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x104>
  6e3259:	31 c9                	xor    %ecx,%ecx
  6e325b:	e9 a0 00 00 00       	jmp    6e3300 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x110>
  6e3260:	49 c7 06 02 00 00 00 	movq   $0x2,(%r14)
  6e3267:	49 c7 46 48 0d 00 00 	movq   $0xd,0x48(%r14)
  6e326e:	00 
  6e326f:	e9 b2 06 00 00       	jmp    6e3926 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x736>
  6e3274:	48 c7 83 10 07 00 00 	movq   $0x0,0x710(%rbx)
  6e327b:	00 00 00 00 
  6e327f:	48 85 d2             	test   %rdx,%rdx
  6e3282:	74 0e                	je     6e3292 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa2>
  6e3284:	48 83 bb 68 06 00 00 	cmpq   $0xffffffffffffffff,0x668(%rbx)
  6e328b:	ff 
  6e328c:	0f 84 cd 00 00 00    	je     6e335f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x16f>
  6e3292:	45 31 ed             	xor    %r13d,%r13d
  6e3295:	80 7e 28 01          	cmpb   $0x1,0x28(%rsi)
  6e3299:	41 0f 94 c5          	sete   %r13b
  6e329d:	4c 03 6e 20          	add    0x20(%rsi),%r13
  6e32a1:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  6e32a6:	48 8b 76 08          	mov    0x8(%rsi),%rsi
  6e32aa:	41 b7 01             	mov    $0x1,%r15b
  6e32ad:	31 c9                	xor    %ecx,%ecx
  6e32af:	49 39 d5             	cmp    %rdx,%r13
  6e32b2:	73 32                	jae    6e32e6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xf6>
  6e32b4:	4c 89 e7             	mov    %r12,%rdi
  6e32b7:	49 89 d4             	mov    %rdx,%r12
  6e32ba:	48 89 fd             	mov    %rdi,%rbp
  6e32bd:	e8 ce 34 02 00       	call   706790 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage>
  6e32c2:	3c 02                	cmp    $0x2,%al
  6e32c4:	0f 84 d3 00 00 00    	je     6e339d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1ad>
  6e32ca:	0f b6 c0             	movzbl %al,%eax
  6e32cd:	83 f8 01             	cmp    $0x1,%eax
  6e32d0:	0f 85 ef 00 00 00    	jne    6e33c5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d5>
  6e32d6:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6e32dd:	00 00 
  6e32df:	31 c0                	xor    %eax,%eax
  6e32e1:	e9 c2 00 00 00       	jmp    6e33a8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1b8>
  6e32e6:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6e32ed:	00 00 
  6e32ef:	e9 7f 01 00 00       	jmp    6e3473 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x283>
  6e32f4:	48 8b 93 98 06 00 00 	mov    0x698(%rbx),%rdx
  6e32fb:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e3300:	48 8b b3 10 07 00 00 	mov    0x710(%rbx),%rsi
  6e3307:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  6e330e:	00 
  6e330f:	49 89 7e 78          	mov    %rdi,0x78(%r14)
  6e3313:	f3 0f 6f 4c 24 60    	movdqu 0x60(%rsp),%xmm1
  6e3319:	0f 10 54 24 70       	movups 0x70(%rsp),%xmm2
  6e331e:	0f 10 9c 24 80 00 00 	movups 0x80(%rsp),%xmm3
  6e3325:	00 
  6e3326:	41 0f 11 5e 68       	movups %xmm3,0x68(%r14)
  6e332b:	41 0f 11 56 58       	movups %xmm2,0x58(%r14)
  6e3330:	f3 41 0f 7f 4e 48    	movdqu %xmm1,0x48(%r14)
  6e3336:	49 89 0e             	mov    %rcx,(%r14)
  6e3339:	49 89 56 08          	mov    %rdx,0x8(%r14)
  6e333d:	f3 41 0f 7f 46 10    	movdqu %xmm0,0x10(%r14)
  6e3343:	49 89 76 20          	mov    %rsi,0x20(%r14)
  6e3347:	41 88 46 28          	mov    %al,0x28(%r14)
  6e334b:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6e334f:	f3 41 0f 7f 46 30    	movdqu %xmm0,0x30(%r14)
  6e3355:	41 c6 46 40 00       	movb   $0x0,0x40(%r14)
  6e335a:	e9 c7 05 00 00       	jmp    6e3926 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x736>
  6e335f:	4c 89 e7             	mov    %r12,%rdi
  6e3362:	e8 29 36 02 00       	call   706990 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e3367:	f3 0f 6f 83 68 06 00 	movdqu 0x668(%rbx),%xmm0
  6e336e:	00 
  6e336f:	0f b6 83 24 07 00 00 	movzbl 0x724(%rbx),%eax
  6e3376:	48 83 bb 88 06 00 00 	cmpq   $0x0,0x688(%rbx)
  6e337d:	00 
  6e337e:	74 16                	je     6e3396 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1a6>
  6e3380:	84 c0                	test   %al,%al
  6e3382:	0f 84 90 00 00 00    	je     6e3418 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x228>
  6e3388:	48 83 bb 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rbx)
  6e338f:	ff 
  6e3390:	0f 85 82 00 00 00    	jne    6e3418 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x228>
  6e3396:	31 c9                	xor    %ecx,%ecx
  6e3398:	e9 87 00 00 00       	jmp    6e3424 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x234>
  6e339d:	b0 01                	mov    $0x1,%al
  6e339f:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  6e33a6:	00 00 
  6e33a8:	4c 89 e2             	mov    %r12,%rdx
  6e33ab:	49 89 ec             	mov    %rbp,%r12
  6e33ae:	49 39 d5             	cmp    %rdx,%r13
  6e33b1:	0f b6 c0             	movzbl %al,%eax
  6e33b4:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  6e33ba:	44 0f 42 f8          	cmovb  %eax,%r15d
  6e33be:	31 f6                	xor    %esi,%esi
  6e33c0:	e9 ac 00 00 00       	jmp    6e3471 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x281>
  6e33c5:	4c 89 e2             	mov    %r12,%rdx
  6e33c8:	49 8d 45 01          	lea    0x1(%r13),%rax
  6e33cc:	4c 39 e0             	cmp    %r12,%rax
  6e33cf:	0f 83 87 00 00 00    	jae    6e345c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26c>
  6e33d5:	b8 01 00 00 00       	mov    $0x1,%eax
  6e33da:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6e33df:	90                   	nop
  6e33e0:	48 89 ef             	mov    %rbp,%rdi
  6e33e3:	31 f6                	xor    %esi,%esi
  6e33e5:	e8 a6 33 02 00       	call   706790 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage>
  6e33ea:	84 c0                	test   %al,%al
  6e33ec:	0f 85 f1 05 00 00    	jne    6e39e3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x7f3>
  6e33f2:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6e33f7:	4a 8d 04 29          	lea    (%rcx,%r13,1),%rax
  6e33fb:	48 ff c0             	inc    %rax
  6e33fe:	48 ff c1             	inc    %rcx
  6e3401:	48 89 4c 24 40       	mov    %rcx,0x40(%rsp)
  6e3406:	4c 39 e0             	cmp    %r12,%rax
  6e3409:	72 d5                	jb     6e33e0 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1f0>
  6e340b:	4c 89 e2             	mov    %r12,%rdx
  6e340e:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  6e3414:	31 f6                	xor    %esi,%esi
  6e3416:	eb 56                	jmp    6e346e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x27e>
  6e3418:	48 8b 93 98 06 00 00 	mov    0x698(%rbx),%rdx
  6e341f:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e3424:	48 8b b3 10 07 00 00 	mov    0x710(%rbx),%rsi
  6e342b:	49 89 0e             	mov    %rcx,(%r14)
  6e342e:	49 89 56 08          	mov    %rdx,0x8(%r14)
  6e3432:	f3 41 0f 7f 46 10    	movdqu %xmm0,0x10(%r14)
  6e3438:	49 89 76 20          	mov    %rsi,0x20(%r14)
  6e343c:	41 88 46 28          	mov    %al,0x28(%r14)
  6e3440:	66 0f ef c0          	pxor   %xmm0,%xmm0
  6e3444:	f3 41 0f 7f 46 30    	movdqu %xmm0,0x30(%r14)
  6e344a:	41 c6 46 40 00       	movb   $0x0,0x40(%r14)
  6e344f:	49 c7 46 48 20 00 00 	movq   $0x20,0x48(%r14)
  6e3456:	00 
  6e3457:	e9 ca 04 00 00       	jmp    6e3926 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x736>
  6e345c:	b8 01 00 00 00       	mov    $0x1,%eax
  6e3461:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6e3466:	31 f6                	xor    %esi,%esi
  6e3468:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  6e346e:	49 89 ec             	mov    %rbp,%r12
  6e3471:	31 c9                	xor    %ecx,%ecx
  6e3473:	49 89 34 24          	mov    %rsi,(%r12)
  6e3477:	48 85 d2             	test   %rdx,%rdx
  6e347a:	41 0f b6 c7          	movzbl %r15b,%eax
  6e347e:	0f 44 c1             	cmove  %ecx,%eax
  6e3481:	89 44 24 4c          	mov    %eax,0x4c(%rsp)
  6e3485:	74 35                	je     6e34bc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2cc>
  6e3487:	4d 85 ed             	test   %r13,%r13
  6e348a:	74 30                	je     6e34bc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2cc>
  6e348c:	80 bb 26 07 00 00 01 	cmpb   $0x1,0x726(%rbx)
  6e3493:	75 5d                	jne    6e34f2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x302>
  6e3495:	48 c7 84 24 f0 00 00 	movq   $0xe,0xf0(%rsp)
  6e349c:	00 0e 00 00 00 
  6e34a1:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  6e34a8:	00 00 00 00 00 
  6e34ad:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e34b2:	44 8b 6c 24 4c       	mov    0x4c(%rsp),%r13d
  6e34b7:	e9 13 03 00 00       	jmp    6e37cf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5df>
  6e34bc:	f3 0f 6f 83 68 06 00 	movdqu 0x668(%rbx),%xmm0
  6e34c3:	00 
  6e34c4:	0f b6 83 24 07 00 00 	movzbl 0x724(%rbx),%eax
  6e34cb:	48 83 bb 88 06 00 00 	cmpq   $0x0,0x688(%rbx)
  6e34d2:	00 
  6e34d3:	74 16                	je     6e34eb <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2fb>
  6e34d5:	84 c0                	test   %al,%al
  6e34d7:	0f 84 5b 01 00 00    	je     6e3638 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x448>
  6e34dd:	48 83 bb 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rbx)
  6e34e4:	ff 
  6e34e5:	0f 85 4d 01 00 00    	jne    6e3638 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x448>
  6e34eb:	31 c9                	xor    %ecx,%ecx
  6e34ed:	e9 52 01 00 00       	jmp    6e3644 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x454>
  6e34f2:	4c 8b bb 68 06 00 00 	mov    0x668(%rbx),%r15
  6e34f9:	49 ff c7             	inc    %r15
  6e34fc:	0f 84 91 1a 00 00    	je     6e4f93 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1da3>
  6e3502:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
  6e3509:	00 00 00 00 00 
  6e350e:	48 c7 84 24 38 02 00 	movq   $0x0,0x238(%rsp)
  6e3515:	00 00 00 00 00 
  6e351a:	48 89 94 24 e0 03 00 	mov    %rdx,0x3e0(%rsp)
  6e3521:	00 
  6e3522:	48 8d 93 c0 05 00 00 	lea    0x5c0(%rbx),%rdx
  6e3529:	48 8d 8b 28 02 00 00 	lea    0x228(%rbx),%rcx
  6e3530:	48 8d 84 24 e0 03 00 	lea    0x3e0(%rsp),%rax
  6e3537:	00 
  6e3538:	48 89 04 24          	mov    %rax,(%rsp)
  6e353c:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e3541:	4c 8d 84 24 b8 01 00 	lea    0x1b8(%rsp),%r8
  6e3548:	00 
  6e3549:	4c 8d 8c 24 38 02 00 	lea    0x238(%rsp),%r9
  6e3550:	00 
  6e3551:	4c 89 e6             	mov    %r12,%rsi
  6e3554:	e8 47 30 02 00       	call   7065a0 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply>
  6e3559:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6e355e:	48 8b 6c 24 68       	mov    0x68(%rsp),%rbp
  6e3563:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6e356a:	00 
  6e356b:	f3 0f 6f 44 24 70    	movdqu 0x70(%rsp),%xmm0
  6e3571:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
  6e3576:	f3 0f 6f 8c 24 80 00 	movdqu 0x80(%rsp),%xmm1
  6e357d:	00 00 
  6e357f:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
  6e3586:	00 
  6e3587:	48 89 ac 24 c8 01 00 	mov    %rbp,0x1c8(%rsp)
  6e358e:	00 
  6e358f:	f3 0f 7f 84 24 d0 01 	movdqu %xmm0,0x1d0(%rsp)
  6e3596:	00 00 
  6e3598:	f3 0f 7f 8c 24 e0 01 	movdqu %xmm1,0x1e0(%rsp)
  6e359f:	00 00 
  6e35a1:	48 89 8c 24 f0 01 00 	mov    %rcx,0x1f0(%rsp)
  6e35a8:	00 
  6e35a9:	48 83 f8 fd          	cmp    $0xfffffffffffffffd,%rax
  6e35ad:	0f 84 67 22 00 00    	je     6e581a <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x262a>
  6e35b3:	48 8d 8c 24 d0 01 00 	lea    0x1d0(%rsp),%rcx
  6e35ba:	00 
  6e35bb:	48 8b 51 20          	mov    0x20(%rcx),%rdx
  6e35bf:	48 89 94 24 80 04 00 	mov    %rdx,0x480(%rsp)
  6e35c6:	00 
  6e35c7:	0f 10 01             	movups (%rcx),%xmm0
  6e35ca:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  6e35ce:	0f 29 8c 24 70 04 00 	movaps %xmm1,0x470(%rsp)
  6e35d5:	00 
  6e35d6:	0f 29 84 24 60 04 00 	movaps %xmm0,0x460(%rsp)
  6e35dd:	00 
  6e35de:	48 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%rdx
  6e35e5:	00 
  6e35e6:	48 89 94 24 e0 00 00 	mov    %rdx,0xe0(%rsp)
  6e35ed:	00 
  6e35ee:	48 85 d2             	test   %rdx,%rdx
  6e35f1:	74 0e                	je     6e3601 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x411>
  6e35f3:	4c 89 bb 68 06 00 00 	mov    %r15,0x668(%rbx)
  6e35fa:	48 ff 83 b8 06 00 00 	incq   0x6b8(%rbx)
  6e3601:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6e3605:	44 8b 6c 24 4c       	mov    0x4c(%rsp),%r13d
  6e360a:	74 77                	je     6e3683 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x493>
  6e360c:	48 8b 8c 24 80 04 00 	mov    0x480(%rsp),%rcx
  6e3613:	00 
  6e3614:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  6e361b:	00 
  6e361c:	0f 28 84 24 60 04 00 	movaps 0x460(%rsp),%xmm0
  6e3623:	00 
  6e3624:	0f 28 8c 24 70 04 00 	movaps 0x470(%rsp),%xmm1
  6e362b:	00 
  6e362c:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  6e3631:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6e3636:	eb 4b                	jmp    6e3683 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x493>
  6e3638:	48 8b 93 98 06 00 00 	mov    0x698(%rbx),%rdx
  6e363f:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e3644:	48 8b b3 10 07 00 00 	mov    0x710(%rbx),%rsi
  6e364b:	49 89 4e 08          	mov    %rcx,0x8(%r14)
  6e364f:	49 89 56 10          	mov    %rdx,0x10(%r14)
  6e3653:	f3 41 0f 7f 46 18    	movdqu %xmm0,0x18(%r14)
  6e3659:	49 89 76 28          	mov    %rsi,0x28(%r14)
  6e365d:	41 88 46 30          	mov    %al,0x30(%r14)
  6e3661:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6e3666:	49 89 46 38          	mov    %rax,0x38(%r14)
  6e366a:	49 c7 46 40 00 00 00 	movq   $0x0,0x40(%r14)
  6e3671:	00 
  6e3672:	41 c6 46 48 00       	movb   $0x0,0x48(%r14)
  6e3677:	49 c7 06 ff ff ff ff 	movq   $0xffffffffffffffff,(%r14)
  6e367e:	e9 a3 02 00 00       	jmp    6e3926 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x736>
  6e3683:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e3688:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  6e368f:	00 
  6e3690:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  6e3696:	66 0f 6f 4c 24 70    	movdqa 0x70(%rsp),%xmm1
  6e369c:	f3 0f 7f 84 24 18 04 	movdqu %xmm0,0x418(%rsp)
  6e36a3:	00 00 
  6e36a5:	f3 0f 7f 8c 24 28 04 	movdqu %xmm1,0x428(%rsp)
  6e36ac:	00 00 
  6e36ae:	48 89 8c 24 38 04 00 	mov    %rcx,0x438(%rsp)
  6e36b5:	00 
  6e36b6:	48 89 84 24 08 04 00 	mov    %rax,0x408(%rsp)
  6e36bd:	00 
  6e36be:	48 89 ac 24 10 04 00 	mov    %rbp,0x410(%rsp)
  6e36c5:	00 
  6e36c6:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6e36ca:	0f 84 6b 02 00 00    	je     6e393b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x74b>
  6e36d0:	48 8b 84 24 38 04 00 	mov    0x438(%rsp),%rax
  6e36d7:	00 
  6e36d8:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
  6e36df:	00 
  6e36e0:	48 8b 84 24 08 04 00 	mov    0x408(%rsp),%rax
  6e36e7:	00 
  6e36e8:	48 8b 8c 24 10 04 00 	mov    0x410(%rsp),%rcx
  6e36ef:	00 
  6e36f0:	f3 0f 6f 84 24 18 04 	movdqu 0x418(%rsp),%xmm0
  6e36f7:	00 00 
  6e36f9:	f3 0f 6f 8c 24 28 04 	movdqu 0x428(%rsp),%xmm1
  6e3700:	00 00 
  6e3702:	66 0f 7f 8c 24 80 00 	movdqa %xmm1,0x80(%rsp)
  6e3709:	00 00 
  6e370b:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
  6e3711:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6e3716:	48 89 4c 24 68       	mov    %rcx,0x68(%rsp)
  6e371b:	48 83 bc 24 e0 00 00 	cmpq   $0x0,0xe0(%rsp)
  6e3722:	00 00 
  6e3724:	74 5e                	je     6e3784 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x594>
  6e3726:	48 8b 83 18 06 00 00 	mov    0x618(%rbx),%rax
  6e372d:	48 85 c0             	test   %rax,%rax
  6e3730:	74 40                	je     6e3772 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x582>
  6e3732:	48 8b 80 e0 00 00 00 	mov    0xe0(%rax),%rax
  6e3739:	48 85 c0             	test   %rax,%rax
  6e373c:	74 34                	je     6e3772 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x582>
  6e373e:	48 8b 78 10          	mov    0x10(%rax),%rdi
  6e3742:	0f b6 48 24          	movzbl 0x24(%rax),%ecx
  6e3746:	c6 40 24 02          	movb   $0x2,0x24(%rax)
  6e374a:	80 f9 02             	cmp    $0x2,%cl
  6e374d:	74 23                	je     6e3772 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x582>
  6e374f:	f6 07 01             	testb  $0x1,(%rdi)
  6e3752:	75 17                	jne    6e376b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x57b>
  6e3754:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e3758:	a8 01                	test   $0x1,%al
  6e375a:	75 0f                	jne    6e376b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x57b>
  6e375c:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6e3760:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e3765:	0f 84 bd 1d 00 00    	je     6e5528 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2338>
  6e376b:	c6 83 23 07 00 00 01 	movb   $0x1,0x723(%rbx)
  6e3772:	c6 83 22 07 00 00 00 	movb   $0x0,0x722(%rbx)
  6e3779:	48 c7 83 f0 05 00 00 	movq   $0x0,0x5f0(%rbx)
  6e3780:	00 00 00 00 
  6e3784:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6e378b:	00 
  6e378c:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  6e3793:	00 
  6e3794:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6e3799:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  6e379e:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
  6e37a4:	66 0f 6f 8c 24 80 00 	movdqa 0x80(%rsp),%xmm1
  6e37ab:	00 00 
  6e37ad:	66 0f 7f 8c 24 10 01 	movdqa %xmm1,0x110(%rsp)
  6e37b4:	00 00 
  6e37b6:	66 0f 7f 84 24 00 01 	movdqa %xmm0,0x100(%rsp)
  6e37bd:	00 00 
  6e37bf:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  6e37c6:	00 
  6e37c7:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
  6e37ce:	00 
  6e37cf:	80 bb 26 07 00 00 00 	cmpb   $0x0,0x726(%rbx)
  6e37d6:	75 0a                	jne    6e37e2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5f2>
  6e37d8:	48 83 bb 68 06 00 00 	cmpq   $0xffffffffffffffff,0x668(%rbx)
  6e37df:	ff 
  6e37e0:	75 08                	jne    6e37ea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5fa>
  6e37e2:	4c 89 e7             	mov    %r12,%rdi
  6e37e5:	e8 a6 31 02 00       	call   706990 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e37ea:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  6e37f1:	00 
  6e37f2:	48 83 ff fe          	cmp    $0xfffffffffffffffe,%rdi
  6e37f6:	74 1a                	je     6e3812 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x622>
  6e37f8:	31 c0                	xor    %eax,%eax
  6e37fa:	41 80 7f 28 01       	cmpb   $0x1,0x28(%r15)
  6e37ff:	0f 94 c0             	sete   %al
  6e3802:	48 f7 d8             	neg    %rax
  6e3805:	49 39 47 20          	cmp    %rax,0x20(%r15)
  6e3809:	0f 95 c0             	setne  %al
  6e380c:	44 08 e8             	or     %r13b,%al
  6e380f:	41 89 c5             	mov    %eax,%r13d
  6e3812:	4c 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%r15
  6e3819:	00 
  6e381a:	44 0f b6 83 26 07 00 	movzbl 0x726(%rbx),%r8d
  6e3821:	00 
  6e3822:	48 8b 83 68 06 00 00 	mov    0x668(%rbx),%rax
  6e3829:	41 80 f0 01          	xor    $0x1,%r8b
  6e382d:	0f b6 8b 24 07 00 00 	movzbl 0x724(%rbx),%ecx
  6e3834:	48 83 bb 88 06 00 00 	cmpq   $0x0,0x688(%rbx)
  6e383b:	00 
  6e383c:	74 0e                	je     6e384c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x65c>
  6e383e:	84 c9                	test   %cl,%cl
  6e3840:	74 0e                	je     6e3850 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x660>
  6e3842:	48 83 bb 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rbx)
  6e3849:	ff 
  6e384a:	75 04                	jne    6e3850 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x660>
  6e384c:	31 d2                	xor    %edx,%edx
  6e384e:	eb 0c                	jmp    6e385c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x66c>
  6e3850:	48 8b b3 98 06 00 00 	mov    0x698(%rbx),%rsi
  6e3857:	ba 01 00 00 00       	mov    $0x1,%edx
  6e385c:	4c 8b 8b 70 06 00 00 	mov    0x670(%rbx),%r9
  6e3863:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6e3867:	41 0f 95 c2          	setne  %r10b
  6e386b:	45 20 c5             	and    %r8b,%r13b
  6e386e:	45 20 d5             	and    %r10b,%r13b
  6e3871:	4c 8b 83 10 07 00 00 	mov    0x710(%rbx),%r8
  6e3878:	48 83 ff fe          	cmp    $0xfffffffffffffffe,%rdi
  6e387c:	75 2c                	jne    6e38aa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6ba>
  6e387e:	4d 89 46 28          	mov    %r8,0x28(%r14)
  6e3882:	bf 48 00 00 00       	mov    $0x48,%edi
  6e3887:	41 ba 40 00 00 00    	mov    $0x40,%r10d
  6e388d:	41 bb 30 00 00 00    	mov    $0x30,%r11d
  6e3893:	4c 89 fb             	mov    %r15,%rbx
  6e3896:	49 89 d7             	mov    %rdx,%r15
  6e3899:	4d 89 c8             	mov    %r9,%r8
  6e389c:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
  6e38a1:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6e38a8:	eb 59                	jmp    6e3903 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x713>
  6e38aa:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
  6e38b1:	00 
  6e38b2:	49 89 7e 78          	mov    %rdi,0x78(%r14)
  6e38b6:	66 0f 6f 84 24 f0 00 	movdqa 0xf0(%rsp),%xmm0
  6e38bd:	00 00 
  6e38bf:	66 0f 6f 8c 24 00 01 	movdqa 0x100(%rsp),%xmm1
  6e38c6:	00 00 
  6e38c8:	0f 28 94 24 10 01 00 	movaps 0x110(%rsp),%xmm2
  6e38cf:	00 
  6e38d0:	41 0f 11 56 68       	movups %xmm2,0x68(%r14)
  6e38d5:	f3 41 0f 7f 4e 58    	movdqu %xmm1,0x58(%r14)
  6e38db:	f3 41 0f 7f 46 48    	movdqu %xmm0,0x48(%r14)
  6e38e1:	bf 40 00 00 00       	mov    $0x40,%edi
  6e38e6:	41 ba 30 00 00 00    	mov    $0x30,%r10d
  6e38ec:	41 bb 28 00 00 00    	mov    $0x28,%r11d
  6e38f2:	48 8b 5c 24 40       	mov    0x40(%rsp),%rbx
  6e38f7:	4d 89 fc             	mov    %r15,%r12
  6e38fa:	49 89 f7             	mov    %rsi,%r15
  6e38fd:	48 89 c6             	mov    %rax,%rsi
  6e3900:	4c 89 c8             	mov    %r9,%rax
  6e3903:	43 88 0c 1e          	mov    %cl,(%r14,%r11,1)
  6e3907:	4b 89 1c 16          	mov    %rbx,(%r14,%r10,1)
  6e390b:	45 88 2c 3e          	mov    %r13b,(%r14,%rdi,1)
  6e390f:	4d 89 7e 08          	mov    %r15,0x8(%r14)
  6e3913:	49 89 76 10          	mov    %rsi,0x10(%r14)
  6e3917:	49 89 46 18          	mov    %rax,0x18(%r14)
  6e391b:	4d 89 46 20          	mov    %r8,0x20(%r14)
  6e391f:	4d 89 66 38          	mov    %r12,0x38(%r14)
  6e3923:	49 89 16             	mov    %rdx,(%r14)
  6e3926:	4c 89 f0             	mov    %r14,%rax
  6e3929:	48 81 c4 e8 04 00 00 	add    $0x4e8,%rsp
  6e3930:	5b                   	pop    %rbx
  6e3931:	41 5c                	pop    %r12
  6e3933:	41 5d                	pop    %r13
  6e3935:	41 5e                	pop    %r14
  6e3937:	41 5f                	pop    %r15
  6e3939:	5d                   	pop    %rbp
  6e393a:	c3                   	ret
  6e393b:	48 83 bc 24 e0 00 00 	cmpq   $0x0,0xe0(%rsp)
  6e3942:	00 00 
  6e3944:	0f 84 bc 00 00 00    	je     6e3a06 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x816>
  6e394a:	48 8b 8c 24 38 02 00 	mov    0x238(%rsp),%rcx
  6e3951:	00 
  6e3952:	48 c7 84 24 a0 04 00 	movq   $0x0,0x4a0(%rsp)
  6e3959:	00 00 00 00 00 
  6e395e:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6e3965:	00 
  6e3966:	48 85 c9             	test   %rcx,%rcx
  6e3969:	0f 84 d5 00 00 00    	je     6e3a44 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x854>
  6e396f:	80 bb 22 07 00 00 01 	cmpb   $0x1,0x722(%rbx)
  6e3976:	0f 85 c8 00 00 00    	jne    6e3a44 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x854>
  6e397c:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e3981:	48 8d b3 28 02 00 00 	lea    0x228(%rbx),%rsi
  6e3988:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
  6e398f:	00 
  6e3990:	e8 1b 19 03 00       	call   7152b0 <<gpui::source::Sources<inbox_storage_control::Page>>::invalidates_owner>
  6e3995:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  6e399a:	0f b6 44 24 68       	movzbl 0x68(%rsp),%eax
  6e399f:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
  6e39a3:	0f 84 93 00 00 00    	je     6e3a3c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x84c>
  6e39a9:	48 8b 54 24 69       	mov    0x69(%rsp),%rdx
  6e39ae:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  6e39b3:	48 89 b4 24 08 01 00 	mov    %rsi,0x108(%rsp)
  6e39ba:	00 
  6e39bb:	48 89 94 24 01 01 00 	mov    %rdx,0x101(%rsp)
  6e39c2:	00 
  6e39c3:	48 c7 84 24 f0 00 00 	movq   $0x21,0xf0(%rsp)
  6e39ca:	00 21 00 00 00 
  6e39cf:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
  6e39d6:	00 
  6e39d7:	88 84 24 00 01 00 00 	mov    %al,0x100(%rsp)
  6e39de:	e9 ec fd ff ff       	jmp    6e37cf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5df>
  6e39e3:	0f b6 c0             	movzbl %al,%eax
  6e39e6:	83 f8 01             	cmp    $0x1,%eax
  6e39e9:	4c 89 e2             	mov    %r12,%rdx
  6e39ec:	75 0c                	jne    6e39fa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x80a>
  6e39ee:	4c 03 6c 24 40       	add    0x40(%rsp),%r13
  6e39f3:	31 c0                	xor    %eax,%eax
  6e39f5:	e9 b1 f9 ff ff       	jmp    6e33ab <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1bb>
  6e39fa:	4c 03 6c 24 40       	add    0x40(%rsp),%r13
  6e39ff:	b0 01                	mov    $0x1,%al
  6e3a01:	e9 a5 f9 ff ff       	jmp    6e33ab <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1bb>
  6e3a06:	f3 0f 6f 83 68 06 00 	movdqu 0x668(%rbx),%xmm0
  6e3a0d:	00 
  6e3a0e:	0f b6 83 24 07 00 00 	movzbl 0x724(%rbx),%eax
  6e3a15:	48 83 bb 88 06 00 00 	cmpq   $0x0,0x688(%rbx)
  6e3a1c:	00 
  6e3a1d:	74 16                	je     6e3a35 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x845>
  6e3a1f:	84 c0                	test   %al,%al
  6e3a21:	0f 84 d5 04 00 00    	je     6e3efc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xd0c>
  6e3a27:	48 83 bb 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%rbx)
  6e3a2e:	ff 
  6e3a2f:	0f 85 c7 04 00 00    	jne    6e3efc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xd0c>
  6e3a35:	31 c9                	xor    %ecx,%ecx
  6e3a37:	e9 cc 04 00 00       	jmp    6e3f08 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xd18>
  6e3a3c:	a8 01                	test   $0x1,%al
  6e3a3e:	0f 84 a7 01 00 00    	je     6e3beb <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9fb>
  6e3a44:	48 ff 83 08 07 00 00 	incq   0x708(%rbx)
  6e3a4b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e3a50:	48 89 de             	mov    %rbx,%rsi
  6e3a53:	4c 89 e2             	mov    %r12,%rdx
  6e3a56:	e8 15 f1 ff ff       	call   6e2b70 <<gpui::runtime::RuntimeMut<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::describe_with_changed>
  6e3a5b:	83 7c 24 60 fe       	cmpl   $0xfffffffe,0x60(%rsp)
  6e3a60:	75 16                	jne    6e3a78 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x888>
  6e3a62:	c6 84 24 a8 02 00 00 	movb   $0x0,0x2a8(%rsp)
  6e3a69:	00 
  6e3a6a:	48 c7 84 24 a0 02 00 	movq   $0xfffffffffffffffe,0x2a0(%rsp)
  6e3a71:	00 fe ff ff ff 
  6e3a76:	eb 3e                	jmp    6e3ab6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8c6>
  6e3a78:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6e3a7f:	00 
  6e3a80:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  6e3a87:	00 
  6e3a88:	f3 0f 6f 44 24 60    	movdqu 0x60(%rsp),%xmm0
  6e3a8e:	f3 0f 6f 4c 24 70    	movdqu 0x70(%rsp),%xmm1
  6e3a94:	0f 10 94 24 80 00 00 	movups 0x80(%rsp),%xmm2
  6e3a9b:	00 
  6e3a9c:	0f 29 94 24 c0 02 00 	movaps %xmm2,0x2c0(%rsp)
  6e3aa3:	00 
  6e3aa4:	66 0f 7f 8c 24 b0 02 	movdqa %xmm1,0x2b0(%rsp)
  6e3aab:	00 00 
  6e3aad:	66 0f 7f 84 24 a0 02 	movdqa %xmm0,0x2a0(%rsp)
  6e3ab4:	00 00 
  6e3ab6:	40 b5 01             	mov    $0x1,%bpl
  6e3ab9:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
  6e3ac0:	00 00 00 00 00 
  6e3ac5:	48 83 bc 24 a0 02 00 	cmpq   $0xfffffffffffffffe,0x2a0(%rsp)
  6e3acc:	00 fe 
  6e3ace:	0f 85 51 18 00 00    	jne    6e5325 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2135>
  6e3ad4:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  6e3adb:	00 
  6e3adc:	48 8d 94 24 a0 04 00 	lea    0x4a0(%rsp),%rdx
  6e3ae3:	00 
  6e3ae4:	48 89 de             	mov    %rbx,%rsi
  6e3ae7:	e8 f4 24 00 00       	call   6e5fe0 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::reconcile_editing>
  6e3aec:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6e3af3:	00 
  6e3af4:	44 0f b6 bc 24 58 01 	movzbl 0x158(%rsp),%r15d
  6e3afb:	00 00 
  6e3afd:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6e3b01:	0f 85 96 00 00 00    	jne    6e3b9d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9ad>
  6e3b07:	48 8d 35 c2 3b 97 ff 	lea    -0x68c43e(%rip),%rsi        # 576d0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x1640>
  6e3b0e:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  6e3b15:	00 
  6e3b16:	e8 15 45 01 00       	call   6f8030 <<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error> as core::cmp::PartialEq>::eq>
  6e3b1b:	84 c0                	test   %al,%al
  6e3b1d:	74 26                	je     6e3b45 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x955>
  6e3b1f:	48 8b 83 18 06 00 00 	mov    0x618(%rbx),%rax
  6e3b26:	48 85 c0             	test   %rax,%rax
  6e3b29:	0f 84 99 03 00 00    	je     6e3ec8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xcd8>
  6e3b2f:	48 83 b8 d8 00 00 00 	cmpq   $0x0,0xd8(%rax)
  6e3b36:	00 
  6e3b37:	0f 95 c0             	setne  %al
  6e3b3a:	44 08 f8             	or     %r15b,%al
  6e3b3d:	a8 01                	test   $0x1,%al
  6e3b3f:	0f 84 8d 03 00 00    	je     6e3ed2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xce2>
  6e3b45:	48 8d 35 bc 3b 97 ff 	lea    -0x68c444(%rip),%rsi        # 57708 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x1678>
  6e3b4c:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
  6e3b53:	00 
  6e3b54:	e8 d7 44 01 00       	call   6f8030 <<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error> as core::cmp::PartialEq>::eq>
  6e3b59:	84 c0                	test   %al,%al
  6e3b5b:	74 26                	je     6e3b83 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x993>
  6e3b5d:	48 8b 83 18 06 00 00 	mov    0x618(%rbx),%rax
  6e3b64:	48 85 c0             	test   %rax,%rax
  6e3b67:	0f 84 db 03 00 00    	je     6e3f48 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xd58>
  6e3b6d:	48 83 b8 d8 00 00 00 	cmpq   $0x0,0xd8(%rax)
  6e3b74:	00 
  6e3b75:	0f 95 c0             	setne  %al
  6e3b78:	44 08 f8             	or     %r15b,%al
  6e3b7b:	a8 01                	test   $0x1,%al
  6e3b7d:	0f 84 cf 03 00 00    	je     6e3f52 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xd62>
  6e3b83:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  6e3b8a:	00 
  6e3b8b:	48 89 de             	mov    %rbx,%rsi
  6e3b8e:	e8 8d 35 01 00       	call   6f7120 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::present>
  6e3b93:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e3b98:	e9 32 fc ff ff       	jmp    6e37cf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5df>
  6e3b9d:	f3 0f 6f 84 24 59 01 	movdqu 0x159(%rsp),%xmm0
  6e3ba4:	00 00 
  6e3ba6:	f3 0f 6f 8c 24 69 01 	movdqu 0x169(%rsp),%xmm1
  6e3bad:	00 00 
  6e3baf:	0f 10 94 24 78 01 00 	movups 0x178(%rsp),%xmm2
  6e3bb6:	00 
  6e3bb7:	0f 11 94 24 18 01 00 	movups %xmm2,0x118(%rsp)
  6e3bbe:	00 
  6e3bbf:	f3 0f 7f 8c 24 09 01 	movdqu %xmm1,0x109(%rsp)
  6e3bc6:	00 00 
  6e3bc8:	f3 0f 7f 84 24 f9 00 	movdqu %xmm0,0xf9(%rsp)
  6e3bcf:	00 00 
  6e3bd1:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  6e3bd8:	00 
  6e3bd9:	44 88 bc 24 f8 00 00 	mov    %r15b,0xf8(%rsp)
  6e3be0:	00 
  6e3be1:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e3be6:	e9 e4 fb ff ff       	jmp    6e37cf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5df>
  6e3beb:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6e3bf2:	00 
  6e3bf3:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  6e3bfa:	00 
  6e3bfb:	48 ff 83 00 07 00 00 	incq   0x700(%rbx)
  6e3c02:	48 8d bb 20 06 00 00 	lea    0x620(%rbx),%rdi
  6e3c09:	e8 02 c6 01 00       	call   700210 <<alloc::collections::btree::map::BTreeMap<gpui::runtime::scroll::ViewportKey, gpui::runtime::scroll::ViewportState>>::first_key_value>
  6e3c0e:	48 85 c0             	test   %rax,%rax
  6e3c11:	0f 84 fb 01 00 00    	je     6e3e12 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xc22>
  6e3c17:	80 38 00             	cmpb   $0x0,(%rax)
  6e3c1a:	0f 85 f2 01 00 00    	jne    6e3e12 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xc22>
  6e3c20:	48 8d bb d0 05 00 00 	lea    0x5d0(%rbx),%rdi
  6e3c27:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  6e3c2e:	00 
  6e3c2f:	e8 dc b8 01 00       	call   6ff510 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::runtime::Fanout>>::get::<gpui::source::FieldId>>
  6e3c34:	48 85 c0             	test   %rax,%rax
  6e3c37:	0f 84 d5 01 00 00    	je     6e3e12 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xc22>
  6e3c3d:	48 8b 48 10          	mov    0x10(%rax),%rcx
  6e3c41:	48 c1 e1 02          	shl    $0x2,%rcx
  6e3c45:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  6e3c4c:	00 00 00 00 00 
  6e3c51:	48 83 38 ff          	cmpq   $0xffffffffffffffff,(%rax)
  6e3c55:	ba 04 00 00 00       	mov    $0x4,%edx
  6e3c5a:	48 0f 45 50 08       	cmovne 0x8(%rax),%rdx
  6e3c5f:	bd 00 00 00 00       	mov    $0x0,%ebp
  6e3c64:	48 0f 45 e9          	cmovne %rcx,%rbp
  6e3c68:	48 85 ed             	test   %rbp,%rbp
  6e3c6b:	0f 84 00 13 00 00    	je     6e4f71 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d81>
  6e3c71:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e3c76:	45 31 ed             	xor    %r13d,%r13d
  6e3c79:	48 8b 0d 80 d3 39 00 	mov    0x39d380(%rip),%rcx        # a81000 <_DYNAMIC+0x3b0>
  6e3c80:	48 83 c1 20          	add    $0x20,%rcx
  6e3c84:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  6e3c89:	48 8b 0d 78 d3 39 00 	mov    0x39d378(%rip),%rcx        # a81008 <_DYNAMIC+0x3b8>
  6e3c90:	48 83 c1 20          	add    $0x20,%rcx
  6e3c94:	48 89 8c 24 c8 00 00 	mov    %rcx,0xc8(%rsp)
  6e3c9b:	00 
  6e3c9c:	48 8b 0d 6d d3 39 00 	mov    0x39d36d(%rip),%rcx        # a81010 <_DYNAMIC+0x3c0>
  6e3ca3:	48 83 c1 20          	add    $0x20,%rcx
  6e3ca7:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  6e3cac:	48 8b 0d 65 d3 39 00 	mov    0x39d365(%rip),%rcx        # a81018 <_DYNAMIC+0x3c8>
  6e3cb3:	48 83 c1 20          	add    $0x20,%rcx
  6e3cb7:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6e3cbc:	48 8b 0d 5d d3 39 00 	mov    0x39d35d(%rip),%rcx        # a81020 <_DYNAMIC+0x3d0>
  6e3cc3:	48 83 c1 20          	add    $0x20,%rcx
  6e3cc7:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6e3ccc:	48 8b 0d 55 d3 39 00 	mov    0x39d355(%rip),%rcx        # a81028 <_DYNAMIC+0x3d8>
  6e3cd3:	48 83 c1 20          	add    $0x20,%rcx
  6e3cd7:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6e3cdc:	48 8b 0d 4d d3 39 00 	mov    0x39d34d(%rip),%rcx        # a81030 <_DYNAMIC+0x3e0>
  6e3ce3:	48 83 c1 20          	add    $0x20,%rcx
  6e3ce7:	48 89 8c 24 28 01 00 	mov    %rcx,0x128(%rsp)
  6e3cee:	00 
  6e3cef:	48 8b 0d 42 d3 39 00 	mov    0x39d342(%rip),%rcx        # a81038 <_DYNAMIC+0x3e8>
  6e3cf6:	48 83 c1 20          	add    $0x20,%rcx
  6e3cfa:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  6e3d01:	00 
  6e3d02:	48 8b 0d 37 d3 39 00 	mov    0x39d337(%rip),%rcx        # a81040 <_DYNAMIC+0x3f0>
  6e3d09:	48 83 c1 20          	add    $0x20,%rcx
  6e3d0d:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6e3d12:	48 8b 0d 2f d3 39 00 	mov    0x39d32f(%rip),%rcx        # a81048 <_DYNAMIC+0x3f8>
  6e3d19:	48 83 c1 20          	add    $0x20,%rcx
  6e3d1d:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
  6e3d24:	00 
  6e3d25:	48 8b 0d 24 d3 39 00 	mov    0x39d324(%rip),%rcx        # a81050 <_DYNAMIC+0x400>
  6e3d2c:	48 83 c1 20          	add    $0x20,%rcx
  6e3d30:	48 89 8c 24 b0 01 00 	mov    %rcx,0x1b0(%rsp)
  6e3d37:	00 
  6e3d38:	48 8b 0d 19 d3 39 00 	mov    0x39d319(%rip),%rcx        # a81058 <_DYNAMIC+0x408>
  6e3d3f:	48 83 c1 20          	add    $0x20,%rcx
  6e3d43:	48 89 8c 24 a8 01 00 	mov    %rcx,0x1a8(%rsp)
  6e3d4a:	00 
  6e3d4b:	48 8b 0d 0e d3 39 00 	mov    0x39d30e(%rip),%rcx        # a81060 <_DYNAMIC+0x410>
  6e3d52:	48 83 c1 20          	add    $0x20,%rcx
  6e3d56:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  6e3d5d:	00 
  6e3d5e:	4c 8d 3d 9b 35 97 ff 	lea    -0x68ca65(%rip),%r15        # 57300 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x1270>
  6e3d65:	49 89 d4             	mov    %rdx,%r12
  6e3d68:	43 8b 3c 2c          	mov    (%r12,%r13,1),%edi
  6e3d6c:	ff 15 f6 d2 39 00    	call   *0x39d2f6(%rip)        # a81068 <_DYNAMIC+0x418>
  6e3d72:	0f b7 c0             	movzwl %ax,%eax
  6e3d75:	49 63 0c 87          	movslq (%r15,%rax,4),%rcx
  6e3d79:	4c 01 f9             	add    %r15,%rcx
  6e3d7c:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6e3d81:	ff e1                	jmp    *%rcx
  6e3d83:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  6e3d8a:	00 
  6e3d8b:	eb 5d                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3d8d:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  6e3d94:	00 
  6e3d95:	eb 53                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3d97:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6e3d9c:	eb 4c                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3d9e:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6e3da5:	00 
  6e3da6:	eb 42                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3da8:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  6e3dad:	eb 3b                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3daf:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  6e3db4:	eb 34                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3db6:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  6e3dbd:	00 
  6e3dbe:	eb 2a                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3dc0:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  6e3dc5:	eb 23                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3dc7:	48 8b 84 24 d8 00 00 	mov    0xd8(%rsp),%rax
  6e3dce:	00 
  6e3dcf:	eb 19                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3dd1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e3dd6:	eb 12                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3dd8:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  6e3ddf:	00 
  6e3de0:	eb 08                	jmp    6e3dea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xbfa>
  6e3de2:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  6e3de9:	00 
  6e3dea:	80 78 13 00          	cmpb   $0x0,0x13(%rax)
  6e3dee:	0f 85 87 11 00 00    	jne    6e4f7b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d8b>
  6e3df4:	49 83 c5 04          	add    $0x4,%r13
  6e3df8:	4c 39 ed             	cmp    %r13,%rbp
  6e3dfb:	0f 85 67 ff ff ff    	jne    6e3d68 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb78>
  6e3e01:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  6e3e08:	00 00 00 00 00 
  6e3e0d:	e9 73 11 00 00       	jmp    6e4f85 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d95>
  6e3e12:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  6e3e19:	00 00 00 00 00 
  6e3e1e:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6e3e25:	00 
  6e3e26:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
  6e3e2d:	00 
  6e3e2e:	4c 8d ab d0 05 00 00 	lea    0x5d0(%rbx),%r13
  6e3e35:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
  6e3e3c:	00 
  6e3e3d:	4c 89 ef             	mov    %r13,%rdi
  6e3e40:	e8 cb b6 01 00       	call   6ff510 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::runtime::Fanout>>::get::<gpui::source::FieldId>>
  6e3e45:	48 85 c0             	test   %rax,%rax
  6e3e48:	74 0a                	je     6e3e54 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xc64>
  6e3e4a:	48 83 38 ff          	cmpq   $0xffffffffffffffff,(%rax)
  6e3e4e:	0f 84 4a 01 00 00    	je     6e3f9e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xdae>
  6e3e54:	48 8d b4 24 40 02 00 	lea    0x240(%rsp),%rsi
  6e3e5b:	00 
  6e3e5c:	4c 89 ef             	mov    %r13,%rdi
  6e3e5f:	e8 ac b6 01 00       	call   6ff510 <<alloc::collections::btree::map::BTreeMap<gpui::source::FieldId, gpui::runtime::Fanout>>::get::<gpui::source::FieldId>>
  6e3e64:	48 89 c5             	mov    %rax,%rbp
  6e3e67:	48 85 c0             	test   %rax,%rax
  6e3e6a:	0f 84 27 01 00 00    	je     6e3f97 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xda7>
  6e3e70:	48 8b 45 00          	mov    0x0(%rbp),%rax
  6e3e74:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6e3e79:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6e3e7d:	0f 84 80 01 00 00    	je     6e4003 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xe13>
  6e3e83:	48 8b 45 10          	mov    0x10(%rbp),%rax
  6e3e87:	48 85 c0             	test   %rax,%rax
  6e3e8a:	0f 84 92 02 00 00    	je     6e4122 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xf32>
  6e3e90:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
  6e3e94:	48 ff c8             	dec    %rax
  6e3e97:	48 ba ff ff ff ff ff 	movabs $0x3fffffffffffffff,%rdx
  6e3e9e:	ff ff 3f 
  6e3ea1:	48 21 c2             	and    %rax,%rdx
  6e3ea4:	48 8d 7a 01          	lea    0x1(%rdx),%rdi
  6e3ea8:	89 fe                	mov    %edi,%esi
  6e3eaa:	83 e6 03             	and    $0x3,%esi
  6e3ead:	48 83 fa 03          	cmp    $0x3,%rdx
  6e3eb1:	0f 83 7c 02 00 00    	jae    6e4133 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xf43>
  6e3eb7:	31 c0                	xor    %eax,%eax
  6e3eb9:	45 31 ed             	xor    %r13d,%r13d
  6e3ebc:	48 8d 93 c0 05 00 00 	lea    0x5c0(%rbx),%rdx
  6e3ec3:	e9 0c 03 00 00       	jmp    6e41d4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xfe4>
  6e3ec8:	41 80 ff 01          	cmp    $0x1,%r15b
  6e3ecc:	0f 84 73 fc ff ff    	je     6e3b45 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x955>
  6e3ed2:	f3 0f 6f 83 68 06 00 	movdqu 0x668(%rbx),%xmm0
  6e3ed9:	00 
  6e3eda:	0f b6 83 24 07 00 00 	movzbl 0x724(%rbx),%eax
  6e3ee1:	48 83 bb 88 06 00 00 	cmpq   $0x0,0x688(%rbx)
  6e3ee8:	00 
  6e3ee9:	0f 84 9c 00 00 00    	je     6e3f8b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xd9b>
  6e3eef:	84 c0                	test   %al,%al
  6e3ef1:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e3ef6:	0f 85 2b fb ff ff    	jne    6e3a27 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x837>
  6e3efc:	48 8b 93 98 06 00 00 	mov    0x698(%rbx),%rdx
  6e3f03:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e3f08:	48 8b b3 10 07 00 00 	mov    0x710(%rbx),%rsi
  6e3f0f:	48 89 8c 24 f8 00 00 	mov    %rcx,0xf8(%rsp)
  6e3f16:	00 
  6e3f17:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
  6e3f1e:	00 
  6e3f1f:	f3 0f 7f 84 24 08 01 	movdqu %xmm0,0x108(%rsp)
  6e3f26:	00 00 
  6e3f28:	48 89 b4 24 18 01 00 	mov    %rsi,0x118(%rsp)
  6e3f2f:	00 
  6e3f30:	88 84 24 20 01 00 00 	mov    %al,0x120(%rsp)
  6e3f37:	48 c7 84 24 f0 00 00 	movq   $0xfffffffffffffffe,0xf0(%rsp)
  6e3f3e:	00 fe ff ff ff 
  6e3f43:	e9 87 f8 ff ff       	jmp    6e37cf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5df>
  6e3f48:	41 80 ff 01          	cmp    $0x1,%r15b
  6e3f4c:	0f 84 31 fc ff ff    	je     6e3b83 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x993>
  6e3f52:	40 84 ed             	test   %bpl,%bpl
  6e3f55:	0f 85 dc 15 00 00    	jne    6e5537 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2347>
  6e3f5b:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  6e3f62:	00 
  6e3f63:	48 89 de             	mov    %rbx,%rsi
  6e3f66:	31 d2                	xor    %edx,%edx
  6e3f68:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  6e3f6f:	00 
  6e3f70:	e8 5b 26 00 00       	call   6e65d0 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::publish_metadata>
  6e3f75:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e3f7a:	48 c7 84 24 f0 00 00 	movq   $0xfffffffffffffffe,0xf0(%rsp)
  6e3f81:	00 fe ff ff ff 
  6e3f86:	e9 44 f8 ff ff       	jmp    6e37cf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5df>
  6e3f8b:	31 c9                	xor    %ecx,%ecx
  6e3f8d:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e3f92:	e9 71 ff ff ff       	jmp    6e3f08 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xd18>
  6e3f97:	31 ff                	xor    %edi,%edi
  6e3f99:	e9 93 12 00 00       	jmp    6e5231 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2041>
  6e3f9e:	44 8b 68 08          	mov    0x8(%rax),%r13d
  6e3fa2:	48 ff 83 c0 06 00 00 	incq   0x6c0(%rbx)
  6e3fa9:	c7 04 24 01 00 00 00 	movl   $0x1,(%rsp)
  6e3fb0:	4c 8d 05 31 49 37 00 	lea    0x374931(%rip),%r8        # a588e8 <__frame_dummy_init_array_entry+0xc38>
  6e3fb7:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e3fbc:	48 8d b3 28 02 00 00 	lea    0x228(%rbx),%rsi
  6e3fc3:	48 8d 93 c0 05 00 00 	lea    0x5c0(%rbx),%rdx
  6e3fca:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  6e3fd1:	00 
  6e3fd2:	45 31 c9             	xor    %r9d,%r9d
  6e3fd5:	e8 06 14 03 00       	call   7153e0 <<gpui::source::Sources<inbox_storage_control::Page>>::freeze>
  6e3fda:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  6e3fdf:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  6e3fe4:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6e3fe9:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6e3fee:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
  6e3ff3:	48 83 fa fd          	cmp    $0xfffffffffffffffd,%rdx
  6e3ff7:	75 29                	jne    6e4022 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xe32>
  6e3ff9:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  6e3ffe:	e9 4a 02 00 00       	jmp    6e424d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x105d>
  6e4003:	48 ff 83 c0 06 00 00 	incq   0x6c0(%rbx)
  6e400a:	4c 8d 05 d7 48 37 00 	lea    0x3748d7(%rip),%r8        # a588e8 <__frame_dummy_init_array_entry+0xc38>
  6e4011:	31 c0                	xor    %eax,%eax
  6e4013:	45 31 ed             	xor    %r13d,%r13d
  6e4016:	48 8d 93 c0 05 00 00 	lea    0x5c0(%rbx),%rdx
  6e401d:	e9 e1 01 00 00       	jmp    6e4203 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1013>
  6e4022:	49 89 cf             	mov    %rcx,%r15
  6e4025:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e402a:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6e4031:	00 
  6e4032:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  6e4039:	00 
  6e403a:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
  6e4041:	00 00 
  6e4043:	66 0f 7f 84 24 40 03 	movdqa %xmm0,0x340(%rsp)
  6e404a:	00 00 
  6e404c:	83 7c 24 38 02       	cmpl   $0x2,0x38(%rsp)
  6e4051:	0f 84 63 15 00 00    	je     6e55ba <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x23ca>
  6e4057:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6e405c:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6e4061:	66 0f 6f 84 24 40 03 	movdqa 0x340(%rsp),%xmm0
  6e4068:	00 00 
  6e406a:	f3 0f 7f 44 24 68    	movdqu %xmm0,0x68(%rsp)
  6e4070:	48 8b 84 24 50 03 00 	mov    0x350(%rsp),%rax
  6e4077:	00 
  6e4078:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  6e407d:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  6e4084:	00 
  6e4085:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6e408a:	ba 06 00 00 00       	mov    $0x6,%edx
  6e408f:	ff 15 db cf 39 00    	call   *0x39cfdb(%rip)        # a81070 <_DYNAMIC+0x420>
  6e4095:	0f b6 94 24 48 02 00 	movzbl 0x248(%rsp),%edx
  6e409c:	00 
  6e409d:	80 fa ff             	cmp    $0xff,%dl
  6e40a0:	0f 84 fe 0e 00 00    	je     6e4fa4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1db4>
  6e40a6:	8b 8c 24 4b 02 00 00 	mov    0x24b(%rsp),%ecx
  6e40ad:	0f b6 84 24 4f 02 00 	movzbl 0x24f(%rsp),%eax
  6e40b4:	00 
  6e40b5:	f3 0f 6f 84 24 50 02 	movdqu 0x250(%rsp),%xmm0
  6e40bc:	00 00 
  6e40be:	66 0f 7f 84 24 40 04 	movdqa %xmm0,0x440(%rsp)
  6e40c5:	00 00 
  6e40c7:	8b b4 24 60 02 00 00 	mov    0x260(%rsp),%esi
  6e40ce:	89 b4 24 50 04 00 00 	mov    %esi,0x450(%rsp)
  6e40d5:	80 fa 02             	cmp    $0x2,%dl
  6e40d8:	0f 85 f3 0e 00 00    	jne    6e4fd1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1de1>
  6e40de:	48 c1 e0 20          	shl    $0x20,%rax
  6e40e2:	48 09 c8             	or     %rcx,%rax
  6e40e5:	48 c1 e8 08          	shr    $0x8,%rax
  6e40e9:	89 84 24 e0 02 00 00 	mov    %eax,0x2e0(%rsp)
  6e40f0:	8b 84 24 48 04 00 00 	mov    0x448(%rsp),%eax
  6e40f7:	89 84 24 ec 02 00 00 	mov    %eax,0x2ec(%rsp)
  6e40fe:	48 8b 84 24 40 04 00 	mov    0x440(%rsp),%rax
  6e4105:	00 
  6e4106:	48 89 84 24 e4 02 00 	mov    %rax,0x2e4(%rsp)
  6e410d:	00 
  6e410e:	80 bb 23 07 00 00 00 	cmpb   $0x0,0x723(%rbx)
  6e4115:	0f 84 d6 0e 00 00    	je     6e4ff1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1e01>
  6e411b:	31 ed                	xor    %ebp,%ebp
  6e411d:	e9 ee 0e 00 00       	jmp    6e5010 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1e20>
  6e4122:	45 31 ed             	xor    %r13d,%r13d
  6e4125:	31 c0                	xor    %eax,%eax
  6e4127:	48 8d 93 c0 05 00 00 	lea    0x5c0(%rbx),%rdx
  6e412e:	e9 c5 00 00 00       	jmp    6e41f8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1008>
  6e4133:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  6e4138:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
  6e413f:	00 00 80 
  6e4142:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
  6e4146:	48 21 c7             	and    %rax,%rdi
  6e4149:	31 c0                	xor    %eax,%eax
  6e414b:	45 31 ed             	xor    %r13d,%r13d
  6e414e:	44 8b 01             	mov    (%rcx),%r8d
  6e4151:	44 8b 49 04          	mov    0x4(%rcx),%r9d
  6e4155:	45 89 c2             	mov    %r8d,%r10d
  6e4158:	41 f7 d2             	not    %r10d
  6e415b:	41 f6 c2 03          	test   $0x3,%r10b
  6e415f:	41 0f 94 c2          	sete   %r10b
  6e4163:	45 89 cb             	mov    %r9d,%r11d
  6e4166:	41 f7 d3             	not    %r11d
  6e4169:	41 f6 c3 03          	test   $0x3,%r11b
  6e416d:	41 0f 94 c3          	sete   %r11b
  6e4171:	45 08 d3             	or     %r10b,%r11b
  6e4174:	44 8b 51 08          	mov    0x8(%rcx),%r10d
  6e4178:	44 89 d5             	mov    %r10d,%ebp
  6e417b:	f7 d5                	not    %ebp
  6e417d:	40 f6 c5 03          	test   $0x3,%bpl
  6e4181:	40 0f 94 c5          	sete   %bpl
  6e4185:	44 8b 79 0c          	mov    0xc(%rcx),%r15d
  6e4189:	48 83 c1 10          	add    $0x10,%rcx
  6e418d:	45 21 fa             	and    %r15d,%r10d
  6e4190:	41 f7 d7             	not    %r15d
  6e4193:	41 f6 c7 03          	test   $0x3,%r15b
  6e4197:	41 0f 94 c7          	sete   %r15b
  6e419b:	41 08 ef             	or     %bpl,%r15b
  6e419e:	45 08 df             	or     %r11b,%r15b
  6e41a1:	45 08 fd             	or     %r15b,%r13b
  6e41a4:	45 21 c8             	and    %r9d,%r8d
  6e41a7:	45 21 d0             	and    %r10d,%r8d
  6e41aa:	41 f7 d0             	not    %r8d
  6e41ad:	41 f6 c0 03          	test   $0x3,%r8b
  6e41b1:	41 0f 95 c0          	setne  %r8b
  6e41b5:	44 08 c0             	or     %r8b,%al
  6e41b8:	48 83 c7 fc          	add    $0xfffffffffffffffc,%rdi
  6e41bc:	75 90                	jne    6e414e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xf5e>
  6e41be:	48 85 f6             	test   %rsi,%rsi
  6e41c1:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e41c6:	48 8d 93 c0 05 00 00 	lea    0x5c0(%rbx),%rdx
  6e41cd:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
  6e41d2:	74 24                	je     6e41f8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1008>
  6e41d4:	31 ff                	xor    %edi,%edi
  6e41d6:	44 8b 04 b9          	mov    (%rcx,%rdi,4),%r8d
  6e41da:	41 83 e0 03          	and    $0x3,%r8d
  6e41de:	41 83 f8 03          	cmp    $0x3,%r8d
  6e41e2:	41 0f 95 c0          	setne  %r8b
  6e41e6:	41 0f 94 c1          	sete   %r9b
  6e41ea:	45 08 cd             	or     %r9b,%r13b
  6e41ed:	44 08 c0             	or     %r8b,%al
  6e41f0:	48 ff c7             	inc    %rdi
  6e41f3:	48 39 fe             	cmp    %rdi,%rsi
  6e41f6:	75 de                	jne    6e41d6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xfe6>
  6e41f8:	48 ff 83 c0 06 00 00 	incq   0x6c0(%rbx)
  6e41ff:	4c 8b 45 18          	mov    0x18(%rbp),%r8
  6e4203:	41 0f b6 cd          	movzbl %r13b,%ecx
  6e4207:	83 e1 01             	and    $0x1,%ecx
  6e420a:	89 0c 24             	mov    %ecx,(%rsp)
  6e420d:	44 0f b6 c8          	movzbl %al,%r9d
  6e4211:	41 83 e1 01          	and    $0x1,%r9d
  6e4215:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e421a:	48 8d b3 28 02 00 00 	lea    0x228(%rbx),%rsi
  6e4221:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
  6e4228:	00 
  6e4229:	e8 b2 11 03 00       	call   7153e0 <<gpui::source::Sources<inbox_storage_control::Page>>::freeze>
  6e422e:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6e4233:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  6e4238:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  6e423d:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  6e4242:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
  6e4247:	48 83 f8 fd          	cmp    $0xfffffffffffffffd,%rax
  6e424b:	75 36                	jne    6e4283 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1093>
  6e424d:	48 89 cd             	mov    %rcx,%rbp
  6e4250:	48 c1 ed 08          	shr    $0x8,%rbp
  6e4254:	41 bd 21 00 00 00    	mov    $0x21,%r13d
  6e425a:	89 cf                	mov    %ecx,%edi
  6e425c:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  6e4263:	00 
  6e4264:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
  6e426b:	00 
  6e426c:	66 0f 6f 84 24 a0 03 	movdqa 0x3a0(%rsp),%xmm0
  6e4273:	00 00 
  6e4275:	66 0f 7f 84 24 c0 01 	movdqa %xmm0,0x1c0(%rsp)
  6e427c:	00 00 
  6e427e:	e9 e9 0f 00 00       	jmp    6e526c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x207c>
  6e4283:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  6e428a:	00 
  6e428b:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6e4292:	00 
  6e4293:	48 89 84 24 d0 03 00 	mov    %rax,0x3d0(%rsp)
  6e429a:	00 
  6e429b:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
  6e42a2:	00 00 
  6e42a4:	66 0f 7f 84 24 c0 03 	movdqa %xmm0,0x3c0(%rsp)
  6e42ab:	00 00 
  6e42ad:	48 83 7c 24 20 ff    	cmpq   $0xffffffffffffffff,0x20(%rsp)
  6e42b3:	48 89 8c 24 d8 00 00 	mov    %rcx,0xd8(%rsp)
  6e42ba:	00 
  6e42bb:	0f 84 7e 0c 00 00    	je     6e4f3f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d4f>
  6e42c1:	48 89 74 24 30       	mov    %rsi,0x30(%rsp)
  6e42c6:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e42cb:	4c 8b 6d 10          	mov    0x10(%rbp),%r13
  6e42cf:	4d 85 ed             	test   %r13,%r13
  6e42d2:	0f 84 67 0c 00 00    	je     6e4f3f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d4f>
  6e42d8:	48 89 6c 24 18       	mov    %rbp,0x18(%rsp)
  6e42dd:	48 8b 6d 08          	mov    0x8(%rbp),%rbp
  6e42e1:	49 c1 e5 02          	shl    $0x2,%r13
  6e42e5:	8b 44 24 38          	mov    0x38(%rsp),%eax
  6e42e9:	48 89 84 24 d8 03 00 	mov    %rax,0x3d8(%rsp)
  6e42f0:	00 
  6e42f1:	45 31 ff             	xor    %r15d,%r15d
  6e42f4:	4c 8b 25 6d cd 39 00 	mov    0x39cd6d(%rip),%r12        # a81068 <_DYNAMIC+0x418>
  6e42fb:	48 83 f8 02          	cmp    $0x2,%rax
  6e42ff:	0f 85 37 01 00 00    	jne    6e443c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x124c>
  6e4305:	42 8b 7c 3d 00       	mov    0x0(%rbp,%r15,1),%edi
  6e430a:	41 ff d4             	call   *%r12
  6e430d:	66 85 c0             	test   %ax,%ax
  6e4310:	0f 85 09 14 00 00    	jne    6e571f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x252f>
  6e4316:	49 83 c7 04          	add    $0x4,%r15
  6e431a:	4d 39 fd             	cmp    %r15,%r13
  6e431d:	75 e6                	jne    6e4305 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1115>
  6e431f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6e4324:	48 8b 40 10          	mov    0x10(%rax),%rax
  6e4328:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
  6e432f:	00 
  6e4330:	48 85 c0             	test   %rax,%rax
  6e4333:	0f 84 06 0c 00 00    	je     6e4f3f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d4f>
  6e4339:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  6e433e:	48 8b 40 08          	mov    0x8(%rax),%rax
  6e4342:	48 89 84 24 a8 01 00 	mov    %rax,0x1a8(%rsp)
  6e4349:	00 
  6e434a:	48 c1 a4 24 48 01 00 	shlq   $0x2,0x148(%rsp)
  6e4351:	00 02 
  6e4353:	f3 0f 7e 44 24 30    	movq   0x30(%rsp),%xmm0
  6e4359:	66 0f 6f 0d 2f 26 97 	movdqa -0x68d9d1(%rip),%xmm1        # 56990 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x900>
  6e4360:	ff 
  6e4361:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
  6e4365:	66 0f 7f 8c 24 90 04 	movdqa %xmm1,0x490(%rsp)
  6e436c:	00 00 
  6e436e:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
  6e4375:	00 00 00 00 00 
  6e437a:	48 8d 05 a7 45 37 00 	lea    0x3745a7(%rip),%rax        # a58928 <__frame_dummy_init_array_entry+0xc78>
  6e4381:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  6e4388:	00 
  6e4389:	48 b8 00 00 00 00 00 	movabs $0x8000000000000000,%rax
  6e4390:	00 00 80 
  6e4393:	48 ff c0             	inc    %rax
  6e4396:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  6e439d:	00 
  6e439e:	48 8d 05 5f 5e 97 ff 	lea    -0x68a1a1(%rip),%rax        # 5a204 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x4174>
  6e43a5:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  6e43ac:	00 
  6e43ad:	48 8d 05 04 46 37 00 	lea    0x374604(%rip),%rax        # a589b8 <__frame_dummy_init_array_entry+0xd08>
  6e43b4:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  6e43bb:	00 
  6e43bc:	48 8d 05 bd 41 37 00 	lea    0x3741bd(%rip),%rax        # a58580 <__frame_dummy_init_array_entry+0x8d0>
  6e43c3:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  6e43ca:	00 
  6e43cb:	48 8d 05 15 5d 97 ff 	lea    -0x68a2eb(%rip),%rax        # 5a0e7 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x4057>
  6e43d2:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
  6e43d9:	00 
  6e43da:	48 8d 05 5f 45 37 00 	lea    0x37455f(%rip),%rax        # a58940 <__frame_dummy_init_array_entry+0xc90>
  6e43e1:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  6e43e8:	00 
  6e43e9:	48 8d 05 eb 5d 97 ff 	lea    -0x68a215(%rip),%rax        # 5a1db <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x414b>
  6e43f0:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  6e43f7:	00 
  6e43f8:	48 8d 05 b1 3b 37 00 	lea    0x373bb1(%rip),%rax        # a57fb0 <__frame_dummy_init_array_entry+0x300>
  6e43ff:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
  6e4406:	00 
  6e4407:	31 c9                	xor    %ecx,%ecx
  6e4409:	48 c7 84 24 a0 01 00 	movq   $0x0,0x1a0(%rsp)
  6e4410:	00 00 00 00 00 
  6e4415:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  6e441c:	00 00 00 00 00 
  6e4421:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  6e4428:	00 00 
  6e442a:	e9 f1 00 00 00       	jmp    6e4520 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1330>
  6e442f:	49 83 c7 04          	add    $0x4,%r15
  6e4433:	4d 39 fd             	cmp    %r15,%r13
  6e4436:	0f 84 e3 fe ff ff    	je     6e431f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x112f>
  6e443c:	42 8b 7c 3d 00       	mov    0x0(%rbp,%r15,1),%edi
  6e4441:	41 ff d4             	call   *%r12
  6e4444:	66 85 c0             	test   %ax,%ax
  6e4447:	74 e6                	je     6e442f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x123f>
  6e4449:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6e444e:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  6e4453:	48 8b 8c 24 d0 03 00 	mov    0x3d0(%rsp),%rcx
  6e445a:	00 
  6e445b:	48 8d 54 24 68       	lea    0x68(%rsp),%rdx
  6e4460:	48 89 4a 10          	mov    %rcx,0x10(%rdx)
  6e4464:	66 0f 6f 84 24 c0 03 	movdqa 0x3c0(%rsp),%xmm0
  6e446b:	00 00 
  6e446d:	f3 0f 7f 02          	movdqu %xmm0,(%rdx)
  6e4471:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  6e4478:	00 
  6e4479:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6e447e:	89 c2                	mov    %eax,%edx
  6e4480:	ff 15 ea cb 39 00    	call   *0x39cbea(%rip)        # a81070 <_DYNAMIC+0x420>
  6e4486:	80 bc 24 48 02 00 00 	cmpb   $0xff,0x248(%rsp)
  6e448d:	ff 
  6e448e:	75 9f                	jne    6e442f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x123f>
  6e4490:	0f b6 84 24 4a 02 00 	movzbl 0x24a(%rsp),%eax
  6e4497:	00 
  6e4498:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6e449c:	8b 84 24 4b 02 00 00 	mov    0x24b(%rsp),%eax
  6e44a3:	0f b6 ac 24 4f 02 00 	movzbl 0x24f(%rsp),%ebp
  6e44aa:	00 
  6e44ab:	48 c1 e5 20          	shl    $0x20,%rbp
  6e44af:	48 09 c5             	or     %rax,%rbp
  6e44b2:	41 bd 25 00 00 00    	mov    $0x25,%r13d
  6e44b8:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  6e44bf:	00 00 
  6e44c1:	7e 1b                	jle    6e44de <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x12ee>
  6e44c3:	ba 01 00 00 00       	mov    $0x1,%edx
  6e44c8:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  6e44cf:	00 
  6e44d0:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6e44d7:	00 
  6e44d8:	ff 15 ba c9 39 00    	call   *0x39c9ba(%rip)        # a80e98 <_DYNAMIC+0x248>
  6e44de:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e44e3:	4d 8d 67 08          	lea    0x8(%r15),%r12
  6e44e7:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  6e44ec:	8b 7c 24 18          	mov    0x18(%rsp),%edi
  6e44f0:	e9 67 fd ff ff       	jmp    6e425c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x106c>
  6e44f5:	48 ff 83 10 07 00 00 	incq   0x710(%rbx)
  6e44fc:	b0 01                	mov    $0x1,%al
  6e44fe:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  6e4505:	00 
  6e4506:	48 89 94 24 b0 01 00 	mov    %rdx,0x1b0(%rsp)
  6e450d:	00 
  6e450e:	48 83 c1 04          	add    $0x4,%rcx
  6e4512:	48 39 8c 24 48 01 00 	cmp    %rcx,0x148(%rsp)
  6e4519:	00 
  6e451a:	0f 84 93 0b 00 00    	je     6e50b3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1ec3>
  6e4520:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
  6e4527:	00 
  6e4528:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  6e452d:	8b 2c 08             	mov    (%rax,%rcx,1),%ebp
  6e4530:	48 ff 83 c8 06 00 00 	incq   0x6c8(%rbx)
  6e4537:	89 e8                	mov    %ebp,%eax
  6e4539:	c1 e8 0f             	shr    $0xf,%eax
  6e453c:	48 8b b3 a0 02 00 00 	mov    0x2a0(%rbx),%rsi
  6e4543:	48 39 c6             	cmp    %rax,%rsi
  6e4546:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6e454b:	0f 86 8d 11 00 00    	jbe    6e56de <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24ee>
  6e4551:	4c 8b bb 98 02 00 00 	mov    0x298(%rbx),%r15
  6e4558:	4c 8d 24 80          	lea    (%rax,%rax,4),%r12
  6e455c:	4b 8b 04 e7          	mov    (%r15,%r12,8),%rax
  6e4560:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  6e4565:	89 ef                	mov    %ebp,%edi
  6e4567:	ff 15 fb ca 39 00    	call   *0x39cafb(%rip)        # a81068 <_DYNAMIC+0x418>
  6e456d:	41 89 c5             	mov    %eax,%r13d
  6e4570:	4f 8d 3c e7          	lea    (%r15,%r12,8),%r15
  6e4574:	66 85 c0             	test   %ax,%ax
  6e4577:	0f 84 10 01 00 00    	je     6e468d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x149d>
  6e457d:	83 bc 24 d8 03 00 00 	cmpl   $0x2,0x3d8(%rsp)
  6e4584:	02 
  6e4585:	0f 84 cd 0f 00 00    	je     6e5558 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2368>
  6e458b:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  6e4590:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  6e4595:	48 8b 84 24 d0 03 00 	mov    0x3d0(%rsp),%rax
  6e459c:	00 
  6e459d:	48 8d 4c 24 68       	lea    0x68(%rsp),%rcx
  6e45a2:	48 89 41 10          	mov    %rax,0x10(%rcx)
  6e45a6:	66 0f 6f 84 24 c0 03 	movdqa 0x3c0(%rsp),%xmm0
  6e45ad:	00 00 
  6e45af:	f3 0f 7f 01          	movdqu %xmm0,(%rcx)
  6e45b3:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  6e45ba:	00 
  6e45bb:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
  6e45c0:	44 89 ea             	mov    %r13d,%edx
  6e45c3:	ff 15 a7 ca 39 00    	call   *0x39caa7(%rip)        # a81070 <_DYNAMIC+0x420>
  6e45c9:	0f b6 84 24 48 02 00 	movzbl 0x248(%rsp),%eax
  6e45d0:	00 
  6e45d1:	3c ff                	cmp    $0xff,%al
  6e45d3:	0f 84 9c 0b 00 00    	je     6e5175 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1f85>
  6e45d9:	0f b7 8c 24 49 02 00 	movzwl 0x249(%rsp),%ecx
  6e45e0:	00 
  6e45e1:	8b 94 24 4b 02 00 00 	mov    0x24b(%rsp),%edx
  6e45e8:	0f b6 b4 24 4f 02 00 	movzbl 0x24f(%rsp),%esi
  6e45ef:	00 
  6e45f0:	4c 8d 84 24 50 02 00 	lea    0x250(%rsp),%r8
  6e45f7:	00 
  6e45f8:	41 8b 78 10          	mov    0x10(%r8),%edi
  6e45fc:	4c 8d 8c 24 f4 03 00 	lea    0x3f4(%rsp),%r9
  6e4603:	00 
  6e4604:	41 89 79 10          	mov    %edi,0x10(%r9)
  6e4608:	f3 41 0f 6f 00       	movdqu (%r8),%xmm0
  6e460d:	f3 41 0f 7f 01       	movdqu %xmm0,(%r9)
  6e4612:	88 84 24 ec 03 00 00 	mov    %al,0x3ec(%rsp)
  6e4619:	66 89 8c 24 ed 03 00 	mov    %cx,0x3ed(%rsp)
  6e4620:	00 
  6e4621:	40 88 b4 24 f3 03 00 	mov    %sil,0x3f3(%rsp)
  6e4628:	00 
  6e4629:	89 94 24 ef 03 00 00 	mov    %edx,0x3ef(%rsp)
  6e4630:	45 0f b7 e5          	movzwl %r13w,%r12d
  6e4634:	48 8d 05 55 46 37 00 	lea    0x374655(%rip),%rax        # a58c90 <__frame_dummy_init_array_entry+0xfe0>
  6e463b:	4a 8b 44 e0 f8       	mov    -0x8(%rax,%r12,8),%rax
  6e4640:	80 78 12 01          	cmpb   $0x1,0x12(%rax)
  6e4644:	0f 85 a0 00 00 00    	jne    6e46ea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x14fa>
  6e464a:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e464f:	48 8d b3 18 06 00 00 	lea    0x618(%rbx),%rsi
  6e4656:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6e465b:	44 89 e9             	mov    %r13d,%ecx
  6e465e:	4c 8d 84 24 ec 03 00 	lea    0x3ec(%rsp),%r8
  6e4665:	00 
  6e4666:	ff 15 0c ca 39 00    	call   *0x39ca0c(%rip)        # a81078 <_DYNAMIC+0x428>
  6e466c:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  6e4671:	0f b6 44 24 68       	movzbl 0x68(%rsp),%eax
  6e4676:	49 83 fd fe          	cmp    $0xfffffffffffffffe,%r13
  6e467a:	0f 85 e8 0d 00 00    	jne    6e5468 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2278>
  6e4680:	3c 01                	cmp    $0x1,%al
  6e4682:	0f 84 48 08 00 00    	je     6e4ed0 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1ce0>
  6e4688:	e9 92 07 00 00       	jmp    6e4e1f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c2f>
  6e468d:	48 83 bc 24 c0 00 00 	cmpq   $0xfffffffffffffffe,0xc0(%rsp)
  6e4694:	00 fe 
  6e4696:	0f 84 dc 0e 00 00    	je     6e5578 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2388>
  6e469c:	83 e5 03             	and    $0x3,%ebp
  6e469f:	8d 45 ff             	lea    -0x1(%rbp),%eax
  6e46a2:	83 f8 02             	cmp    $0x2,%eax
  6e46a5:	0f 83 84 00 00 00    	jae    6e472f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x153f>
  6e46ab:	48 8d 83 18 06 00 00 	lea    0x618(%rbx),%rax
  6e46b2:	48 8b 38             	mov    (%rax),%rdi
  6e46b5:	41 bd 2b 00 00 00    	mov    $0x2b,%r13d
  6e46bb:	48 85 ff             	test   %rdi,%rdi
  6e46be:	0f 84 9c 0e 00 00    	je     6e5560 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2370>
  6e46c4:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6e46c9:	ff 15 b1 c9 39 00    	call   *0x39c9b1(%rip)        # a81080 <_DYNAMIC+0x430>
  6e46cf:	48 85 c0             	test   %rax,%rax
  6e46d2:	0f 84 88 0e 00 00    	je     6e5560 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2370>
  6e46d8:	83 fd 01             	cmp    $0x1,%ebp
  6e46db:	0f 85 a7 00 00 00    	jne    6e4788 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1598>
  6e46e1:	48 8b 78 08          	mov    0x8(%rax),%rdi
  6e46e5:	e9 a2 00 00 00       	jmp    6e478c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x159c>
  6e46ea:	48 8d 83 00 02 00 00 	lea    0x200(%rbx),%rax
  6e46f1:	48 8b 00             	mov    (%rax),%rax
  6e46f4:	48 8d 15 3d 2c 97 ff 	lea    -0x68d3c3(%rip),%rdx        # 57338 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x12a8>
  6e46fb:	48 63 0c 82          	movslq (%rdx,%rax,4),%rcx
  6e46ff:	48 01 d1             	add    %rdx,%rcx
  6e4702:	48 8d 05 13 2f 97 ff 	lea    -0x68d0ed(%rip),%rax        # 5761c <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x158c>
  6e4709:	ff e1                	jmp    *%rcx
  6e470b:	48 8b b3 18 02 00 00 	mov    0x218(%rbx),%rsi
  6e4712:	48 3b 74 24 20       	cmp    0x20(%rsp),%rsi
  6e4717:	0f 86 8d 0f 00 00    	jbe    6e56aa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24ba>
  6e471d:	48 6b 44 24 20 58    	imul   $0x58,0x20(%rsp),%rax
  6e4723:	48 03 83 10 02 00 00 	add    0x210(%rbx),%rax
  6e472a:	e9 81 03 00 00       	jmp    6e4ab0 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x18c0>
  6e472f:	85 ed                	test   %ebp,%ebp
  6e4731:	0f 85 a1 0e 00 00    	jne    6e55d8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x23e8>
  6e4737:	41 8b 47 20          	mov    0x20(%r15),%eax
  6e473b:	89 c1                	mov    %eax,%ecx
  6e473d:	83 e1 0f             	and    $0xf,%ecx
  6e4740:	83 f9 09             	cmp    $0x9,%ecx
  6e4743:	0f 87 1c 0f 00 00    	ja     6e5665 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2475>
  6e4749:	83 f9 06             	cmp    $0x6,%ecx
  6e474c:	74 79                	je     6e47c7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x15d7>
  6e474e:	c1 e8 04             	shr    $0x4,%eax
  6e4751:	74 74                	je     6e47c7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x15d7>
  6e4753:	48 8b b3 b8 02 00 00 	mov    0x2b8(%rbx),%rsi
  6e475a:	ff c8                	dec    %eax
  6e475c:	48 39 c6             	cmp    %rax,%rsi
  6e475f:	0f 86 65 0f 00 00    	jbe    6e56ca <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24da>
  6e4765:	48 8b 8b b0 02 00 00 	mov    0x2b0(%rbx),%rcx
  6e476c:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  6e4770:	48 c1 e0 04          	shl    $0x4,%rax
  6e4774:	48 83 3c 01 fe       	cmpq   $0xfffffffffffffffe,(%rcx,%rax,1)
  6e4779:	0f 84 c4 0e 00 00    	je     6e5643 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2453>
  6e477f:	48 01 c1             	add    %rax,%rcx
  6e4782:	48 8b 79 40          	mov    0x40(%rcx),%rdi
  6e4786:	eb 13                	jmp    6e479b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x15ab>
  6e4788:	48 8b 78 10          	mov    0x10(%rax),%rdi
  6e478c:	b0 01                	mov    $0x1,%al
  6e478e:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  6e4795:	00 
  6e4796:	48 85 ff             	test   %rdi,%rdi
  6e4799:	74 2c                	je     6e47c7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x15d7>
  6e479b:	48 8b 07             	mov    (%rdi),%rax
  6e479e:	48 d1 e8             	shr    $1,%rax
  6e47a1:	48 3b 44 24 30       	cmp    0x30(%rsp),%rax
  6e47a6:	75 1f                	jne    6e47c7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x15d7>
  6e47a8:	48 83 c7 10          	add    $0x10,%rdi
  6e47ac:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  6e47b3:	00 
  6e47b4:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6e47b9:	ff 15 c9 c8 39 00    	call   *0x39c8c9(%rip)        # a81088 <bcmp@GLIBC_2.2.5>
  6e47bf:	85 c0                	test   %eax,%eax
  6e47c1:	0f 84 58 06 00 00    	je     6e4e1f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c2f>
  6e47c7:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6e47cd:	75 7a                	jne    6e4849 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1659>
  6e47cf:	48 8d 05 2a 29 97 ff 	lea    -0x68d6d6(%rip),%rax        # 57100 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x1070>
  6e47d6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6e47db:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
  6e47e1:	74 4d                	je     6e4830 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1640>
  6e47e3:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  6e47ea:	00 00 
  6e47ec:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e47f1:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  6e47f6:	31 d2                	xor    %edx,%edx
  6e47f8:	31 c9                	xor    %ecx,%ecx
  6e47fa:	ff 15 90 c8 39 00    	call   *0x39c890(%rip)        # a81090 <_DYNAMIC+0x440>
  6e4800:	48 8b 7c 24 60       	mov    0x60(%rsp),%rdi
  6e4805:	48 83 ff ff          	cmp    $0xffffffffffffffff,%rdi
  6e4809:	0f 85 e4 0e 00 00    	jne    6e56f3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2503>
  6e480f:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  6e4814:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  6e4819:	48 8d 79 10          	lea    0x10(%rcx),%rdi
  6e481d:	48 8b b4 24 d8 00 00 	mov    0xd8(%rsp),%rsi
  6e4824:	00 
  6e4825:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  6e482a:	ff 15 90 c6 39 00    	call   *0x39c690(%rip)        # a80ec0 <memcpy@GLIBC_2.14>
  6e4830:	f3 0f 6f 83 d0 06 00 	movdqu 0x6d0(%rbx),%xmm0
  6e4837:	00 
  6e4838:	66 0f d4 84 24 90 04 	paddq  0x490(%rsp),%xmm0
  6e483f:	00 00 
  6e4841:	f3 0f 7f 83 d0 06 00 	movdqu %xmm0,0x6d0(%rbx)
  6e4848:	00 
  6e4849:	85 ed                	test   %ebp,%ebp
  6e484b:	0f 84 b3 00 00 00    	je     6e4904 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1714>
  6e4851:	48 8d 83 18 06 00 00 	lea    0x618(%rbx),%rax
  6e4858:	48 8b 38             	mov    (%rax),%rdi
  6e485b:	41 bd 2b 00 00 00    	mov    $0x2b,%r13d
  6e4861:	48 85 ff             	test   %rdi,%rdi
  6e4864:	0f 84 50 09 00 00    	je     6e51ba <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1fca>
  6e486a:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6e486f:	ff 15 23 c8 39 00    	call   *0x39c823(%rip)        # a81098 <_DYNAMIC+0x448>
  6e4875:	49 89 c7             	mov    %rax,%r15
  6e4878:	48 85 c0             	test   %rax,%rax
  6e487b:	0f 84 39 09 00 00    	je     6e51ba <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1fca>
  6e4881:	83 fd 01             	cmp    $0x1,%ebp
  6e4884:	0f 85 6f 01 00 00    	jne    6e49f9 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1809>
  6e488a:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6e4890:	74 3f                	je     6e48d1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x16e1>
  6e4892:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e4897:	f6 00 01             	testb  $0x1,(%rax)
  6e489a:	75 35                	jne    6e48d1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x16e1>
  6e489c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e48a1:	48 8b 40 08          	mov    0x8(%rax),%rax
  6e48a5:	a8 01                	test   $0x1,%al
  6e48a7:	75 28                	jne    6e48d1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x16e1>
  6e48a9:	b8 02 00 00 00       	mov    $0x2,%eax
  6e48ae:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6e48b3:	f0 48 0f c1 41 08    	lock xadd %rax,0x8(%rcx)
  6e48b9:	48 23 84 24 98 01 00 	and    0x198(%rsp),%rax
  6e48c0:	00 
  6e48c1:	48 f7 d8             	neg    %rax
  6e48c4:	71 0b                	jno    6e48d1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x16e1>
  6e48c6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e48cb:	f0 48 83 48 08 01    	lock orq $0x1,0x8(%rax)
  6e48d1:	49 8b 7f 08          	mov    0x8(%r15),%rdi
  6e48d5:	48 85 ff             	test   %rdi,%rdi
  6e48d8:	74 1c                	je     6e48f6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1706>
  6e48da:	f6 07 01             	testb  $0x1,(%rdi)
  6e48dd:	75 17                	jne    6e48f6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1706>
  6e48df:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e48e3:	a8 01                	test   $0x1,%al
  6e48e5:	75 0f                	jne    6e48f6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1706>
  6e48e7:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6e48eb:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e48f0:	0f 84 2b 06 00 00    	je     6e4f21 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d31>
  6e48f6:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e48fb:	49 89 47 08          	mov    %rax,0x8(%r15)
  6e48ff:	e9 dd 05 00 00       	jmp    6e4ee1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1cf1>
  6e4904:	41 8b 7f 20          	mov    0x20(%r15),%edi
  6e4908:	89 f8                	mov    %edi,%eax
  6e490a:	83 e0 0f             	and    $0xf,%eax
  6e490d:	83 f8 09             	cmp    $0x9,%eax
  6e4910:	0f 87 56 0d 00 00    	ja     6e566c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x247c>
  6e4916:	41 bd 16 00 00 00    	mov    $0x16,%r13d
  6e491c:	83 f8 06             	cmp    $0x6,%eax
  6e491f:	0f 84 77 08 00 00    	je     6e519c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1fac>
  6e4925:	c1 ef 04             	shr    $0x4,%edi
  6e4928:	0f 84 6e 08 00 00    	je     6e519c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1fac>
  6e492e:	48 8b b3 b8 02 00 00 	mov    0x2b8(%rbx),%rsi
  6e4935:	ff cf                	dec    %edi
  6e4937:	48 39 fe             	cmp    %rdi,%rsi
  6e493a:	0f 86 4a 0d 00 00    	jbe    6e568a <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x249a>
  6e4940:	4c 8b ab b0 02 00 00 	mov    0x2b0(%rbx),%r13
  6e4947:	48 8d 04 bf          	lea    (%rdi,%rdi,4),%rax
  6e494b:	48 c1 e0 04          	shl    $0x4,%rax
  6e494f:	49 83 7c 05 00 fe    	cmpq   $0xfffffffffffffffe,0x0(%r13,%rax,1)
  6e4955:	0f 84 bb 0c 00 00    	je     6e5616 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2426>
  6e495b:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6e4961:	0f 84 c1 0c 00 00    	je     6e5628 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2438>
  6e4967:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6e496c:	f6 01 01             	testb  $0x1,(%rcx)
  6e496f:	75 36                	jne    6e49a7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x17b7>
  6e4971:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6e4976:	48 8b 49 08          	mov    0x8(%rcx),%rcx
  6e497a:	f6 c1 01             	test   $0x1,%cl
  6e497d:	75 28                	jne    6e49a7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x17b7>
  6e497f:	b9 02 00 00 00       	mov    $0x2,%ecx
  6e4984:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  6e4989:	f0 48 0f c1 4a 08    	lock xadd %rcx,0x8(%rdx)
  6e498f:	48 23 8c 24 98 01 00 	and    0x198(%rsp),%rcx
  6e4996:	00 
  6e4997:	48 f7 d9             	neg    %rcx
  6e499a:	71 0b                	jno    6e49a7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x17b7>
  6e499c:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6e49a1:	f0 48 83 49 08 01    	lock orq $0x1,0x8(%rcx)
  6e49a7:	49 01 c5             	add    %rax,%r13
  6e49aa:	49 8b 7d 40          	mov    0x40(%r13),%rdi
  6e49ae:	f6 07 01             	testb  $0x1,(%rdi)
  6e49b1:	75 17                	jne    6e49ca <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x17da>
  6e49b3:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e49b7:	a8 01                	test   $0x1,%al
  6e49b9:	75 0f                	jne    6e49ca <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x17da>
  6e49bb:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6e49bf:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e49c4:	0f 84 48 05 00 00    	je     6e4f12 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d22>
  6e49ca:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e49cf:	49 89 45 40          	mov    %rax,0x40(%r13)
  6e49d3:	4c 89 ef             	mov    %r13,%rdi
  6e49d6:	e8 a5 8b ff ff       	call   6dd580 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6e49db:	49 c7 45 00 ff ff ff 	movq   $0xffffffffffffffff,0x0(%r13)
  6e49e2:	ff 
  6e49e3:	48 8d bb 50 06 00 00 	lea    0x650(%rbx),%rdi
  6e49ea:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6e49ef:	e8 cc b8 01 00       	call   7002c0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6e49f4:	e9 d7 04 00 00       	jmp    6e4ed0 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1ce0>
  6e49f9:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6e49ff:	74 3f                	je     6e4a40 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1850>
  6e4a01:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e4a06:	f6 00 01             	testb  $0x1,(%rax)
  6e4a09:	75 35                	jne    6e4a40 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1850>
  6e4a0b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e4a10:	48 8b 40 08          	mov    0x8(%rax),%rax
  6e4a14:	a8 01                	test   $0x1,%al
  6e4a16:	75 28                	jne    6e4a40 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1850>
  6e4a18:	b8 02 00 00 00       	mov    $0x2,%eax
  6e4a1d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  6e4a22:	f0 48 0f c1 41 08    	lock xadd %rax,0x8(%rcx)
  6e4a28:	48 23 84 24 98 01 00 	and    0x198(%rsp),%rax
  6e4a2f:	00 
  6e4a30:	48 f7 d8             	neg    %rax
  6e4a33:	71 0b                	jno    6e4a40 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1850>
  6e4a35:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e4a3a:	f0 48 83 48 08 01    	lock orq $0x1,0x8(%rax)
  6e4a40:	49 8b 7f 10          	mov    0x10(%r15),%rdi
  6e4a44:	48 85 ff             	test   %rdi,%rdi
  6e4a47:	74 1c                	je     6e4a65 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1875>
  6e4a49:	f6 07 01             	testb  $0x1,(%rdi)
  6e4a4c:	75 17                	jne    6e4a65 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1875>
  6e4a4e:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e4a52:	a8 01                	test   $0x1,%al
  6e4a54:	75 0f                	jne    6e4a65 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1875>
  6e4a56:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6e4a5a:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e4a5f:	0f 84 cb 04 00 00    	je     6e4f30 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d40>
  6e4a65:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e4a6a:	49 89 47 10          	mov    %rax,0x10(%r15)
  6e4a6e:	e9 6e 04 00 00       	jmp    6e4ee1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1cf1>
  6e4a73:	48 8b b3 20 02 00 00 	mov    0x220(%rbx),%rsi
  6e4a7a:	48 3b 74 24 20       	cmp    0x20(%rsp),%rsi
  6e4a7f:	0f 86 2e 0c 00 00    	jbe    6e56b3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24c3>
  6e4a85:	48 8b b3 10 02 00 00 	mov    0x210(%rbx),%rsi
  6e4a8c:	48 8b 83 18 02 00 00 	mov    0x218(%rbx),%rax
  6e4a93:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  6e4a98:	0f b6 04 08          	movzbl (%rax,%rcx,1),%eax
  6e4a9c:	48 39 c6             	cmp    %rax,%rsi
  6e4a9f:	0f 86 17 0c 00 00    	jbe    6e56bc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24cc>
  6e4aa5:	48 6b c0 58          	imul   $0x58,%rax,%rax
  6e4aa9:	48 03 83 08 02 00 00 	add    0x208(%rbx),%rax
  6e4ab0:	48 8b 48 50          	mov    0x50(%rax),%rcx
  6e4ab4:	48 89 8c 24 30 03 00 	mov    %rcx,0x330(%rsp)
  6e4abb:	00 
  6e4abc:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  6e4ac0:	0f 29 84 24 20 03 00 	movaps %xmm0,0x320(%rsp)
  6e4ac7:	00 
  6e4ac8:	f3 0f 6f 00          	movdqu (%rax),%xmm0
  6e4acc:	f3 0f 6f 48 10       	movdqu 0x10(%rax),%xmm1
  6e4ad1:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  6e4ad5:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  6e4ad9:	0f 29 9c 24 10 03 00 	movaps %xmm3,0x310(%rsp)
  6e4ae0:	00 
  6e4ae1:	0f 29 94 24 00 03 00 	movaps %xmm2,0x300(%rsp)
  6e4ae8:	00 
  6e4ae9:	66 0f 7f 8c 24 f0 02 	movdqa %xmm1,0x2f0(%rsp)
  6e4af0:	00 00 
  6e4af2:	66 0f 7f 84 24 e0 02 	movdqa %xmm0,0x2e0(%rsp)
  6e4af9:	00 00 
  6e4afb:	eb 1a                	jmp    6e4b17 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1927>
  6e4afd:	48 8b b3 08 02 00 00 	mov    0x208(%rbx),%rsi
  6e4b04:	48 8d bc 24 e0 02 00 	lea    0x2e0(%rsp),%rdi
  6e4b0b:	00 
  6e4b0c:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6e4b11:	ff 15 91 c4 39 00    	call   *0x39c491(%rip)        # a80fa8 <_DYNAMIC+0x358>
  6e4b17:	48 8b 84 24 30 03 00 	mov    0x330(%rsp),%rax
  6e4b1e:	00 
  6e4b1f:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  6e4b26:	00 
  6e4b27:	0f 28 84 24 20 03 00 	movaps 0x320(%rsp),%xmm0
  6e4b2e:	00 
  6e4b2f:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6e4b36:	00 
  6e4b37:	66 0f 6f 84 24 e0 02 	movdqa 0x2e0(%rsp),%xmm0
  6e4b3e:	00 00 
  6e4b40:	66 0f 6f 8c 24 f0 02 	movdqa 0x2f0(%rsp),%xmm1
  6e4b47:	00 00 
  6e4b49:	0f 28 94 24 00 03 00 	movaps 0x300(%rsp),%xmm2
  6e4b50:	00 
  6e4b51:	0f 28 9c 24 10 03 00 	movaps 0x310(%rsp),%xmm3
  6e4b58:	00 
  6e4b59:	0f 29 9c 24 90 00 00 	movaps %xmm3,0x90(%rsp)
  6e4b60:	00 
  6e4b61:	0f 29 94 24 80 00 00 	movaps %xmm2,0x80(%rsp)
  6e4b68:	00 
  6e4b69:	66 0f 7f 4c 24 70    	movdqa %xmm1,0x70(%rsp)
  6e4b6f:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
  6e4b75:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  6e4b7c:	00 
  6e4b7d:	48 8d b3 00 06 00 00 	lea    0x600(%rbx),%rsi
  6e4b84:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  6e4b89:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
  6e4b8e:	45 89 e8             	mov    %r13d,%r8d
  6e4b91:	4c 8d 8c 24 ec 03 00 	lea    0x3ec(%rsp),%r9
  6e4b98:	00 
  6e4b99:	e8 42 02 02 00       	call   704de0 <<gpui::property::Overrides>::update_base>
  6e4b9e:	8b 84 24 48 02 00 00 	mov    0x248(%rsp),%eax
  6e4ba5:	8b 8c 24 4d 02 00 00 	mov    0x24d(%rsp),%ecx
  6e4bac:	0f b6 ac 24 51 02 00 	movzbl 0x251(%rsp),%ebp
  6e4bb3:	00 
  6e4bb4:	48 c1 e5 20          	shl    $0x20,%rbp
  6e4bb8:	48 09 cd             	or     %rcx,%rbp
  6e4bbb:	0f b6 b4 24 4c 02 00 	movzbl 0x24c(%rsp),%esi
  6e4bc2:	00 
  6e4bc3:	83 f8 02             	cmp    $0x2,%eax
  6e4bc6:	0f 84 f2 08 00 00    	je     6e54be <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x22ce>
  6e4bcc:	48 8d 8c 24 50 02 00 	lea    0x250(%rsp),%rcx
  6e4bd3:	00 
  6e4bd4:	0f 10 41 40          	movups 0x40(%rcx),%xmm0
  6e4bd8:	48 8d 94 24 ca 01 00 	lea    0x1ca(%rsp),%rdx
  6e4bdf:	00 
  6e4be0:	0f 11 42 3e          	movups %xmm0,0x3e(%rdx)
  6e4be4:	0f 10 41 02          	movups 0x2(%rcx),%xmm0
  6e4be8:	0f 10 49 12          	movups 0x12(%rcx),%xmm1
  6e4bec:	0f 10 51 22          	movups 0x22(%rcx),%xmm2
  6e4bf0:	0f 10 59 32          	movups 0x32(%rcx),%xmm3
  6e4bf4:	0f 11 5a 30          	movups %xmm3,0x30(%rdx)
  6e4bf8:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  6e4bfc:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  6e4c00:	0f 11 02             	movups %xmm0,(%rdx)
  6e4c03:	89 84 24 c0 01 00 00 	mov    %eax,0x1c0(%rsp)
  6e4c0a:	40 88 b4 24 c4 01 00 	mov    %sil,0x1c4(%rsp)
  6e4c11:	00 
  6e4c12:	48 89 e8             	mov    %rbp,%rax
  6e4c15:	48 c1 e8 20          	shr    $0x20,%rax
  6e4c19:	88 84 24 c9 01 00 00 	mov    %al,0x1c9(%rsp)
  6e4c20:	89 ac 24 c5 01 00 00 	mov    %ebp,0x1c5(%rsp)
  6e4c27:	f3 0f 6f 84 24 d0 01 	movdqu 0x1d0(%rsp),%xmm0
  6e4c2e:	00 00 
  6e4c30:	f3 0f 6f 8c 24 e0 01 	movdqu 0x1e0(%rsp),%xmm1
  6e4c37:	00 00 
  6e4c39:	0f 10 94 24 f0 01 00 	movups 0x1f0(%rsp),%xmm2
  6e4c40:	00 
  6e4c41:	0f 10 9c 24 00 02 00 	movups 0x200(%rsp),%xmm3
  6e4c48:	00 
  6e4c49:	66 0f 7f 84 24 50 03 	movdqa %xmm0,0x350(%rsp)
  6e4c50:	00 00 
  6e4c52:	66 0f 7f 8c 24 60 03 	movdqa %xmm1,0x360(%rsp)
  6e4c59:	00 00 
  6e4c5b:	0f 29 94 24 70 03 00 	movaps %xmm2,0x370(%rsp)
  6e4c62:	00 
  6e4c63:	0f 29 9c 24 80 03 00 	movaps %xmm3,0x380(%rsp)
  6e4c6a:	00 
  6e4c6b:	48 8b 84 24 10 02 00 	mov    0x210(%rsp),%rax
  6e4c72:	00 
  6e4c73:	48 89 84 24 90 03 00 	mov    %rax,0x390(%rsp)
  6e4c7a:	00 
  6e4c7b:	8b 84 24 c0 01 00 00 	mov    0x1c0(%rsp),%eax
  6e4c82:	89 84 24 40 03 00 00 	mov    %eax,0x340(%rsp)
  6e4c89:	0f b6 84 24 c4 01 00 	movzbl 0x1c4(%rsp),%eax
  6e4c90:	00 
  6e4c91:	88 84 24 44 03 00 00 	mov    %al,0x344(%rsp)
  6e4c98:	8b 84 24 c5 01 00 00 	mov    0x1c5(%rsp),%eax
  6e4c9f:	89 84 24 45 03 00 00 	mov    %eax,0x345(%rsp)
  6e4ca6:	0f b6 84 24 c9 01 00 	movzbl 0x1c9(%rsp),%eax
  6e4cad:	00 
  6e4cae:	88 84 24 49 03 00 00 	mov    %al,0x349(%rsp)
  6e4cb5:	8b 84 24 ca 01 00 00 	mov    0x1ca(%rsp),%eax
  6e4cbc:	89 84 24 4a 03 00 00 	mov    %eax,0x34a(%rsp)
  6e4cc3:	0f b7 84 24 ce 01 00 	movzwl 0x1ce(%rsp),%eax
  6e4cca:	00 
  6e4ccb:	66 89 84 24 4e 03 00 	mov    %ax,0x34e(%rsp)
  6e4cd2:	00 
  6e4cd3:	0f b6 84 24 40 03 00 	movzbl 0x340(%rsp),%eax
  6e4cda:	00 
  6e4cdb:	83 bc 24 e0 02 00 00 	cmpl   $0x1,0x2e0(%rsp)
  6e4ce2:	01 
  6e4ce3:	75 1a                	jne    6e4cff <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1b0f>
  6e4ce5:	8b 8c 24 44 03 00 00 	mov    0x344(%rsp),%ecx
  6e4cec:	39 8c 24 e4 02 00 00 	cmp    %ecx,0x2e4(%rsp)
  6e4cf3:	0f 94 c1             	sete   %cl
  6e4cf6:	84 c8                	test   %cl,%al
  6e4cf8:	75 0d                	jne    6e4d07 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1b17>
  6e4cfa:	e9 2a 01 00 00       	jmp    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4cff:	a8 01                	test   $0x1,%al
  6e4d01:	0f 85 22 01 00 00    	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4d07:	0f b6 84 24 48 03 00 	movzbl 0x348(%rsp),%eax
  6e4d0e:	00 
  6e4d0f:	83 bc 24 e8 02 00 00 	cmpl   $0x1,0x2e8(%rsp)
  6e4d16:	01 
  6e4d17:	75 1b                	jne    6e4d34 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1b44>
  6e4d19:	8b 8c 24 4c 03 00 00 	mov    0x34c(%rsp),%ecx
  6e4d20:	39 8c 24 ec 02 00 00 	cmp    %ecx,0x2ec(%rsp)
  6e4d27:	0f 94 c1             	sete   %cl
  6e4d2a:	84 c8                	test   %cl,%al
  6e4d2c:	0f 84 f7 00 00 00    	je     6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4d32:	eb 08                	jmp    6e4d3c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1b4c>
  6e4d34:	a8 01                	test   $0x1,%al
  6e4d36:	0f 85 ed 00 00 00    	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4d3c:	8b 84 24 f0 02 00 00 	mov    0x2f0(%rsp),%eax
  6e4d43:	3b 84 24 50 03 00 00 	cmp    0x350(%rsp),%eax
  6e4d4a:	0f 85 d9 00 00 00    	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4d50:	8b 84 24 f4 02 00 00 	mov    0x2f4(%rsp),%eax
  6e4d57:	3b 84 24 54 03 00 00 	cmp    0x354(%rsp),%eax
  6e4d5e:	0f 85 c5 00 00 00    	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4d64:	8b 84 24 f8 02 00 00 	mov    0x2f8(%rsp),%eax
  6e4d6b:	3b 84 24 58 03 00 00 	cmp    0x358(%rsp),%eax
  6e4d72:	0f 85 b1 00 00 00    	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4d78:	0f b6 84 24 34 03 00 	movzbl 0x334(%rsp),%eax
  6e4d7f:	00 
  6e4d80:	3a 84 24 94 03 00 00 	cmp    0x394(%rsp),%al
  6e4d87:	0f 85 9c 00 00 00    	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4d8d:	0f b6 84 24 36 03 00 	movzbl 0x336(%rsp),%eax
  6e4d94:	00 
  6e4d95:	3a 84 24 96 03 00 00 	cmp    0x396(%rsp),%al
  6e4d9c:	0f 85 87 00 00 00    	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4da2:	0f b6 84 24 37 03 00 	movzbl 0x337(%rsp),%eax
  6e4da9:	00 
  6e4daa:	3a 84 24 97 03 00 00 	cmp    0x397(%rsp),%al
  6e4db1:	75 76                	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4db3:	0f b6 84 24 35 03 00 	movzbl 0x335(%rsp),%eax
  6e4dba:	00 
  6e4dbb:	3a 84 24 95 03 00 00 	cmp    0x395(%rsp),%al
  6e4dc2:	75 65                	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4dc4:	48 8d bc 24 1c 03 00 	lea    0x31c(%rsp),%rdi
  6e4dcb:	00 
  6e4dcc:	48 8d b4 24 7c 03 00 	lea    0x37c(%rsp),%rsi
  6e4dd3:	00 
  6e4dd4:	e8 27 2d 01 00       	call   6f7b00 <<gpui_reactivity_core::geometry::Affine as gpui::property::ExactValue>::same>
  6e4dd9:	84 c0                	test   %al,%al
  6e4ddb:	74 4c                	je     6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4ddd:	f3 0f 6f 84 24 fc 02 	movdqu 0x2fc(%rsp),%xmm0
  6e4de4:	00 00 
  6e4de6:	f3 0f 6f 8c 24 5c 03 	movdqu 0x35c(%rsp),%xmm1
  6e4ded:	00 00 
  6e4def:	66 0f 74 c8          	pcmpeqb %xmm0,%xmm1
  6e4df3:	66 0f d7 c1          	pmovmskb %xmm1,%eax
  6e4df7:	3d ff ff 00 00       	cmp    $0xffff,%eax
  6e4dfc:	75 2b                	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4dfe:	f3 0f 6f 84 24 0c 03 	movdqu 0x30c(%rsp),%xmm0
  6e4e05:	00 00 
  6e4e07:	f3 0f 6f 8c 24 6c 03 	movdqu 0x36c(%rsp),%xmm1
  6e4e0e:	00 00 
  6e4e10:	66 0f 74 c8          	pcmpeqb %xmm0,%xmm1
  6e4e14:	66 0f d7 c1          	pmovmskb %xmm1,%eax
  6e4e18:	3d ff ff 00 00       	cmp    $0xffff,%eax
  6e4e1d:	75 0a                	jne    6e4e29 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c39>
  6e4e1f:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6e4e24:	e9 e5 f6 ff ff       	jmp    6e450e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x131e>
  6e4e29:	48 8d 05 60 3e 37 00 	lea    0x373e60(%rip),%rax        # a58c90 <__frame_dummy_init_array_entry+0xfe0>
  6e4e30:	4a 8b 44 e0 f8       	mov    -0x8(%rax,%r12,8),%rax
  6e4e35:	80 78 13 02          	cmpb   $0x2,0x13(%rax)
  6e4e39:	75 11                	jne    6e4e4c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c5c>
  6e4e3b:	48 8d bb 50 06 00 00 	lea    0x650(%rbx),%rdi
  6e4e42:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6e4e47:	e8 74 b4 01 00       	call   7002c0 <<alloc::collections::btree::map::BTreeMap<u64, alloc::collections::btree::set_val::SetValZST>>::insert>
  6e4e4c:	66 41 83 fd 05       	cmp    $0x5,%r13w
  6e4e51:	75 5c                	jne    6e4eaf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1cbf>
  6e4e53:	41 8b 47 20          	mov    0x20(%r15),%eax
  6e4e57:	89 c1                	mov    %eax,%ecx
  6e4e59:	83 e1 0f             	and    $0xf,%ecx
  6e4e5c:	83 f9 09             	cmp    $0x9,%ecx
  6e4e5f:	0f 87 00 08 00 00    	ja     6e5665 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2475>
  6e4e65:	83 f9 06             	cmp    $0x6,%ecx
  6e4e68:	74 45                	je     6e4eaf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1cbf>
  6e4e6a:	c1 e8 04             	shr    $0x4,%eax
  6e4e6d:	74 40                	je     6e4eaf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1cbf>
  6e4e6f:	48 8b b3 b8 02 00 00 	mov    0x2b8(%rbx),%rsi
  6e4e76:	ff c8                	dec    %eax
  6e4e78:	48 39 c6             	cmp    %rax,%rsi
  6e4e7b:	0f 86 1b 08 00 00    	jbe    6e569c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24ac>
  6e4e81:	4c 8b ab b0 02 00 00 	mov    0x2b0(%rbx),%r13
  6e4e88:	48 8d 04 80          	lea    (%rax,%rax,4),%rax
  6e4e8c:	48 c1 e0 04          	shl    $0x4,%rax
  6e4e90:	49 83 7c 05 00 fe    	cmpq   $0xfffffffffffffffe,0x0(%r13,%rax,1)
  6e4e96:	0f 84 b6 07 00 00    	je     6e5652 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2462>
  6e4e9c:	49 01 c5             	add    %rax,%r13
  6e4e9f:	4c 89 ef             	mov    %r13,%rdi
  6e4ea2:	e8 d9 86 ff ff       	call   6dd580 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::Shaped>>>
  6e4ea7:	49 c7 45 00 ff ff ff 	movq   $0xffffffffffffffff,0x0(%r13)
  6e4eae:	ff 
  6e4eaf:	48 8b 8b a0 02 00 00 	mov    0x2a0(%rbx),%rcx
  6e4eb6:	48 8d bb 00 02 00 00 	lea    0x200(%rbx),%rdi
  6e4ebd:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6e4ec2:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
  6e4ec9:	00 
  6e4eca:	ff 15 d0 c1 39 00    	call   *0x39c1d0(%rip)        # a810a0 <_DYNAMIC+0x450>
  6e4ed0:	c6 83 23 07 00 00 01 	movb   $0x1,0x723(%rbx)
  6e4ed7:	b0 01                	mov    $0x1,%al
  6e4ed9:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  6e4ee0:	00 
  6e4ee1:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  6e4ee6:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6e4eeb:	48 39 94 24 b0 01 00 	cmp    %rdx,0x1b0(%rsp)
  6e4ef2:	00 
  6e4ef3:	0f 94 c0             	sete   %al
  6e4ef6:	84 84 24 28 01 00 00 	test   %al,0x128(%rsp)
  6e4efd:	0f 84 f2 f5 ff ff    	je     6e44f5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1305>
  6e4f03:	b0 01                	mov    $0x1,%al
  6e4f05:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  6e4f0c:	00 
  6e4f0d:	e9 fc f5 ff ff       	jmp    6e450e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x131e>
  6e4f12:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e4f16:	ff 15 dc bf 39 00    	call   *0x39bfdc(%rip)        # a80ef8 <_DYNAMIC+0x2a8>
  6e4f1c:	e9 a9 fa ff ff       	jmp    6e49ca <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x17da>
  6e4f21:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e4f25:	ff 15 cd bf 39 00    	call   *0x39bfcd(%rip)        # a80ef8 <_DYNAMIC+0x2a8>
  6e4f2b:	e9 c6 f9 ff ff       	jmp    6e48f6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1706>
  6e4f30:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e4f34:	ff 15 be bf 39 00    	call   *0x39bfbe(%rip)        # a80ef8 <_DYNAMIC+0x2a8>
  6e4f3a:	e9 26 fb ff ff       	jmp    6e4a65 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1875>
  6e4f3f:	31 ed                	xor    %ebp,%ebp
  6e4f41:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6e4f48:	00 
  6e4f49:	48 85 f6             	test   %rsi,%rsi
  6e4f4c:	7e 13                	jle    6e4f61 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d71>
  6e4f4e:	ba 01 00 00 00       	mov    $0x1,%edx
  6e4f53:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  6e4f5a:	00 
  6e4f5b:	ff 15 37 bf 39 00    	call   *0x39bf37(%rip)        # a80e98 <_DYNAMIC+0x248>
  6e4f61:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e4f66:	4d 8d 67 08          	lea    0x8(%r15),%r12
  6e4f6a:	89 ef                	mov    %ebp,%edi
  6e4f6c:	e9 c0 02 00 00       	jmp    6e5231 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2041>
  6e4f71:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e4f76:	e9 a3 ee ff ff       	jmp    6e3e1e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xc2e>
  6e4f7b:	b0 01                	mov    $0x1,%al
  6e4f7d:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
  6e4f84:	00 
  6e4f85:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e4f8a:	4d 8d 67 08          	lea    0x8(%r15),%r12
  6e4f8e:	e9 8b ee ff ff       	jmp    6e3e1e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xc2e>
  6e4f93:	48 c7 84 24 f0 00 00 	movq   $0x20,0xf0(%rsp)
  6e4f9a:	00 20 00 00 00 
  6e4f9f:	e9 fd e4 ff ff       	jmp    6e34a1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2b1>
  6e4fa4:	0f b6 84 24 4a 02 00 	movzbl 0x24a(%rsp),%eax
  6e4fab:	00 
  6e4fac:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6e4fb0:	8b 84 24 4b 02 00 00 	mov    0x24b(%rsp),%eax
  6e4fb7:	0f b6 ac 24 4f 02 00 	movzbl 0x24f(%rsp),%ebp
  6e4fbe:	00 
  6e4fbf:	48 c1 e5 20          	shl    $0x20,%rbp
  6e4fc3:	48 09 c5             	or     %rax,%rbp
  6e4fc6:	41 bd 25 00 00 00    	mov    $0x25,%r13d
  6e4fcc:	e9 29 02 00 00       	jmp    6e51fa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x200a>
  6e4fd1:	41 bd 21 00 00 00    	mov    $0x21,%r13d
  6e4fd7:	b0 0c                	mov    $0xc,%al
  6e4fd9:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6e4fdd:	31 ed                	xor    %ebp,%ebp
  6e4fdf:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6e4fe6:	00 
  6e4fe7:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6e4fec:	e9 09 02 00 00       	jmp    6e51fa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x200a>
  6e4ff1:	48 8b 83 98 06 00 00 	mov    0x698(%rbx),%rax
  6e4ff8:	48 8d 48 01          	lea    0x1(%rax),%rcx
  6e4ffc:	48 3b 8b 68 06 00 00 	cmp    0x668(%rbx),%rcx
  6e5003:	40 0f 94 c5          	sete   %bpl
  6e5007:	48 ff c0             	inc    %rax
  6e500a:	0f 84 0b f1 ff ff    	je     6e411b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xf2b>
  6e5010:	48 8d b3 00 02 00 00 	lea    0x200(%rbx),%rsi
  6e5017:	48 8d bc 24 48 02 00 	lea    0x248(%rsp),%rdi
  6e501e:	00 
  6e501f:	48 8d 8c 24 e0 02 00 	lea    0x2e0(%rsp),%rcx
  6e5026:	00 
  6e5027:	44 89 ea             	mov    %r13d,%edx
  6e502a:	ff 15 78 c0 39 00    	call   *0x39c078(%rip)        # a810a8 <_DYNAMIC+0x458>
  6e5030:	80 bc 24 48 02 00 00 	cmpb   $0x0,0x248(%rsp)
  6e5037:	00 
  6e5038:	74 21                	je     6e505b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1e6b>
  6e503a:	8b 94 24 6c 02 00 00 	mov    0x26c(%rsp),%edx
  6e5041:	48 89 93 10 07 00 00 	mov    %rdx,0x710(%rbx)
  6e5048:	40 84 ed             	test   %bpl,%bpl
  6e504b:	0f 84 8e 01 00 00    	je     6e51df <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1fef>
  6e5051:	48 8d 94 24 4c 02 00 	lea    0x24c(%rsp),%rdx
  6e5058:	00 
  6e5059:	eb 16                	jmp    6e5071 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1e81>
  6e505b:	48 c7 83 10 07 00 00 	movq   $0x0,0x710(%rbx)
  6e5062:	00 00 00 00 
  6e5066:	31 d2                	xor    %edx,%edx
  6e5068:	40 84 ed             	test   %bpl,%bpl
  6e506b:	0f 84 6e 01 00 00    	je     6e51df <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1fef>
  6e5071:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e5076:	48 89 de             	mov    %rbx,%rsi
  6e5079:	e8 e2 df ff ff       	call   6e3060 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::finish_color_slot>
  6e507e:	4c 8b 6c 24 60       	mov    0x60(%rsp),%r13
  6e5083:	0f b6 44 24 68       	movzbl 0x68(%rsp),%eax
  6e5088:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6e508c:	49 83 fd fe          	cmp    $0xfffffffffffffffe,%r13
  6e5090:	0f 85 8a 00 00 00    	jne    6e5120 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1f30>
  6e5096:	f6 44 24 18 01       	testb  $0x1,0x18(%rsp)
  6e509b:	0f 84 37 01 00 00    	je     6e51d8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1fe8>
  6e50a1:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
  6e50a8:	b0 02                	mov    $0x2,%al
  6e50aa:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6e50ae:	e9 47 01 00 00       	jmp    6e51fa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x200a>
  6e50b3:	48 8b 84 24 40 01 00 	mov    0x140(%rsp),%rax
  6e50ba:	00 
  6e50bb:	34 01                	xor    $0x1,%al
  6e50bd:	0f b6 c0             	movzbl %al,%eax
  6e50c0:	31 ed                	xor    %ebp,%ebp
  6e50c2:	f6 84 24 a0 01 00 00 	testb  $0x1,0x1a0(%rsp)
  6e50c9:	01 
  6e50ca:	0f 45 e8             	cmovne %eax,%ebp
  6e50cd:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6e50d3:	0f 84 68 fe ff ff    	je     6e4f41 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d51>
  6e50d9:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e50de:	f6 00 01             	testb  $0x1,(%rax)
  6e50e1:	0f 85 5a fe ff ff    	jne    6e4f41 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d51>
  6e50e7:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e50ec:	48 8b 40 08          	mov    0x8(%rax),%rax
  6e50f0:	a8 01                	test   $0x1,%al
  6e50f2:	0f 85 49 fe ff ff    	jne    6e4f41 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d51>
  6e50f8:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e50fd:	48 83 c0 08          	add    $0x8,%rax
  6e5101:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e5106:	0f 85 35 fe ff ff    	jne    6e4f41 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d51>
  6e510c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6e5111:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e5115:	ff 15 dd bd 39 00    	call   *0x39bddd(%rip)        # a80ef8 <_DYNAMIC+0x2a8>
  6e511b:	e9 21 fe ff ff       	jmp    6e4f41 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1d51>
  6e5120:	0f b6 44 24 6f       	movzbl 0x6f(%rsp),%eax
  6e5125:	c1 e0 10             	shl    $0x10,%eax
  6e5128:	0f b7 4c 24 6d       	movzwl 0x6d(%rsp),%ecx
  6e512d:	09 c1                	or     %eax,%ecx
  6e512f:	48 c1 e1 20          	shl    $0x20,%rcx
  6e5133:	8b 6c 24 69          	mov    0x69(%rsp),%ebp
  6e5137:	48 09 cd             	or     %rcx,%rbp
  6e513a:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6e513f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6e5144:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6e5149:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6e514e:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
  6e5155:	00 00 
  6e5157:	66 0f 7f 84 24 a0 03 	movdqa %xmm0,0x3a0(%rsp)
  6e515e:	00 00 
  6e5160:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6e5167:	00 
  6e5168:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  6e516f:	00 
  6e5170:	e9 85 00 00 00       	jmp    6e51fa <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x200a>
  6e5175:	0f b6 84 24 4a 02 00 	movzbl 0x24a(%rsp),%eax
  6e517c:	00 
  6e517d:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6e5181:	8b 84 24 4b 02 00 00 	mov    0x24b(%rsp),%eax
  6e5188:	0f b6 ac 24 4f 02 00 	movzbl 0x24f(%rsp),%ebp
  6e518f:	00 
  6e5190:	48 c1 e5 20          	shl    $0x20,%rbp
  6e5194:	48 09 c5             	or     %rax,%rbp
  6e5197:	e9 33 03 00 00       	jmp    6e54cf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x22df>
  6e519c:	48 8d 05 8c 50 97 ff 	lea    -0x68af74(%rip),%rax        # 5a22f <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x419f>
  6e51a3:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  6e51aa:	00 
  6e51ab:	48 8d 05 d6 37 37 00 	lea    0x3737d6(%rip),%rax        # a58988 <__frame_dummy_init_array_entry+0xcd8>
  6e51b2:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  6e51b9:	00 
  6e51ba:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  6e51c1:	00 
  6e51c2:	4c 89 ee             	mov    %r13,%rsi
  6e51c5:	48 8b 94 24 88 01 00 	mov    0x188(%rsp),%rdx
  6e51cc:	00 
  6e51cd:	ff 15 e5 bd 39 00    	call   *0x39bde5(%rip)        # a80fb8 <_DYNAMIC+0x368>
  6e51d3:	e9 60 05 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e51d8:	48 8b 93 10 07 00 00 	mov    0x710(%rbx),%rdx
  6e51df:	48 85 d2             	test   %rdx,%rdx
  6e51e2:	0f 95 c0             	setne  %al
  6e51e5:	08 83 23 07 00 00    	or     %al,0x723(%rbx)
  6e51eb:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
  6e51f2:	c7 44 24 18 00 00 00 	movl   $0x0,0x18(%rsp)
  6e51f9:	00 
  6e51fa:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  6e5200:	7e 13                	jle    6e5215 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2025>
  6e5202:	ba 01 00 00 00       	mov    $0x1,%edx
  6e5207:	4c 89 ff             	mov    %r15,%rdi
  6e520a:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6e520f:	ff 15 83 bc 39 00    	call   *0x39bc83(%rip)        # a80e98 <_DYNAMIC+0x248>
  6e5215:	41 83 fd fe          	cmp    $0xfffffffe,%r13d
  6e5219:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e521e:	4d 8d 67 08          	lea    0x8(%r15),%r12
  6e5222:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  6e5227:	8b 7c 24 18          	mov    0x18(%rsp),%edi
  6e522b:	0f 85 2b f0 ff ff    	jne    6e425c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x106c>
  6e5231:	49 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%r13
  6e5238:	80 bc 24 c8 00 00 00 	cmpb   $0x0,0xc8(%rsp)
  6e523f:	00 
  6e5240:	74 2a                	je     6e526c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x207c>
  6e5242:	80 bb 23 07 00 00 01 	cmpb   $0x1,0x723(%rbx)
  6e5249:	75 21                	jne    6e526c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x207c>
  6e524b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e5250:	48 89 de             	mov    %rbx,%rsi
  6e5253:	4c 89 e2             	mov    %r12,%rdx
  6e5256:	e8 15 d9 ff ff       	call   6e2b70 <<gpui::runtime::RuntimeMut<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::describe_with_changed>
  6e525b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  6e5260:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6e5264:	0f 85 a6 01 00 00    	jne    6e5410 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2220>
  6e526a:	31 ff                	xor    %edi,%edi
  6e526c:	40 0f b6 c7          	movzbl %dil,%eax
  6e5270:	48 c1 e5 08          	shl    $0x8,%rbp
  6e5274:	48 09 c5             	or     %rax,%rbp
  6e5277:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
  6e527e:	00 
  6e527f:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  6e5286:	00 
  6e5287:	66 0f 6f 84 24 c0 01 	movdqa 0x1c0(%rsp),%xmm0
  6e528e:	00 00 
  6e5290:	f3 0f 7f 84 24 70 01 	movdqu %xmm0,0x170(%rsp)
  6e5297:	00 00 
  6e5299:	4c 89 ac 24 50 01 00 	mov    %r13,0x150(%rsp)
  6e52a0:	00 
  6e52a1:	48 89 ac 24 58 01 00 	mov    %rbp,0x158(%rsp)
  6e52a8:	00 
  6e52a9:	48 89 b4 24 60 01 00 	mov    %rsi,0x160(%rsp)
  6e52b0:	00 
  6e52b1:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  6e52b6:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  6e52bd:	00 
  6e52be:	66 0f 7f 84 24 c0 02 	movdqa %xmm0,0x2c0(%rsp)
  6e52c5:	00 00 
  6e52c7:	48 89 84 24 d0 02 00 	mov    %rax,0x2d0(%rsp)
  6e52ce:	00 
  6e52cf:	48 8b 84 24 60 01 00 	mov    0x160(%rsp),%rax
  6e52d6:	00 
  6e52d7:	48 89 84 24 b0 02 00 	mov    %rax,0x2b0(%rsp)
  6e52de:	00 
  6e52df:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  6e52e6:	00 
  6e52e7:	48 89 84 24 b8 02 00 	mov    %rax,0x2b8(%rsp)
  6e52ee:	00 
  6e52ef:	48 8b 84 24 50 01 00 	mov    0x150(%rsp),%rax
  6e52f6:	00 
  6e52f7:	48 89 84 24 a0 02 00 	mov    %rax,0x2a0(%rsp)
  6e52fe:	00 
  6e52ff:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  6e5306:	00 
  6e5307:	48 89 84 24 a8 02 00 	mov    %rax,0x2a8(%rsp)
  6e530e:	00 
  6e530f:	31 ed                	xor    %ebp,%ebp
  6e5311:	44 8b 6c 24 4c       	mov    0x4c(%rsp),%r13d
  6e5316:	48 83 bc 24 a0 02 00 	cmpq   $0xfffffffffffffffe,0x2a0(%rsp)
  6e531d:	00 fe 
  6e531f:	0f 84 af e7 ff ff    	je     6e3ad4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8e4>
  6e5325:	48 8b 84 24 d0 02 00 	mov    0x2d0(%rsp),%rax
  6e532c:	00 
  6e532d:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  6e5334:	00 
  6e5335:	66 0f 6f 84 24 a0 02 	movdqa 0x2a0(%rsp),%xmm0
  6e533c:	00 00 
  6e533e:	66 0f 6f 8c 24 b0 02 	movdqa 0x2b0(%rsp),%xmm1
  6e5345:	00 00 
  6e5347:	0f 28 94 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm2
  6e534e:	00 
  6e534f:	0f 29 94 24 70 01 00 	movaps %xmm2,0x170(%rsp)
  6e5356:	00 
  6e5357:	66 0f 7f 8c 24 60 01 	movdqa %xmm1,0x160(%rsp)
  6e535e:	00 00 
  6e5360:	66 0f 7f 84 24 50 01 	movdqa %xmm0,0x150(%rsp)
  6e5367:	00 00 
  6e5369:	48 8b 83 18 06 00 00 	mov    0x618(%rbx),%rax
  6e5370:	48 85 c0             	test   %rax,%rax
  6e5373:	74 40                	je     6e53b5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x21c5>
  6e5375:	48 8b 80 e0 00 00 00 	mov    0xe0(%rax),%rax
  6e537c:	48 85 c0             	test   %rax,%rax
  6e537f:	74 34                	je     6e53b5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x21c5>
  6e5381:	48 8b 78 10          	mov    0x10(%rax),%rdi
  6e5385:	0f b6 48 24          	movzbl 0x24(%rax),%ecx
  6e5389:	c6 40 24 02          	movb   $0x2,0x24(%rax)
  6e538d:	80 f9 02             	cmp    $0x2,%cl
  6e5390:	74 23                	je     6e53b5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x21c5>
  6e5392:	f6 07 01             	testb  $0x1,(%rdi)
  6e5395:	75 17                	jne    6e53ae <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x21be>
  6e5397:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e539b:	a8 01                	test   $0x1,%al
  6e539d:	75 0f                	jne    6e53ae <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x21be>
  6e539f:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6e53a3:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e53a8:	0f 84 9b 01 00 00    	je     6e5549 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2359>
  6e53ae:	c6 83 23 07 00 00 01 	movb   $0x1,0x723(%rbx)
  6e53b5:	c6 83 22 07 00 00 00 	movb   $0x0,0x722(%rbx)
  6e53bc:	48 c7 83 f0 05 00 00 	movq   $0x0,0x5f0(%rbx)
  6e53c3:	00 00 00 00 
  6e53c7:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
  6e53ce:	00 
  6e53cf:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  6e53d6:	00 
  6e53d7:	66 0f 6f 84 24 50 01 	movdqa 0x150(%rsp),%xmm0
  6e53de:	00 00 
  6e53e0:	66 0f 6f 8c 24 60 01 	movdqa 0x160(%rsp),%xmm1
  6e53e7:	00 00 
  6e53e9:	0f 28 94 24 70 01 00 	movaps 0x170(%rsp),%xmm2
  6e53f0:	00 
  6e53f1:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
  6e53f8:	00 
  6e53f9:	66 0f 7f 8c 24 00 01 	movdqa %xmm1,0x100(%rsp)
  6e5400:	00 00 
  6e5402:	66 0f 7f 84 24 f0 00 	movdqa %xmm0,0xf0(%rsp)
  6e5409:	00 00 
  6e540b:	e9 bf e3 ff ff       	jmp    6e37cf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5df>
  6e5410:	0f b6 7c 24 68       	movzbl 0x68(%rsp),%edi
  6e5415:	0f b6 4c 24 6f       	movzbl 0x6f(%rsp),%ecx
  6e541a:	c1 e1 10             	shl    $0x10,%ecx
  6e541d:	0f b7 54 24 6d       	movzwl 0x6d(%rsp),%edx
  6e5422:	09 ca                	or     %ecx,%edx
  6e5424:	48 c1 e2 20          	shl    $0x20,%rdx
  6e5428:	8b 6c 24 69          	mov    0x69(%rsp),%ebp
  6e542c:	48 09 d5             	or     %rdx,%rbp
  6e542f:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  6e5434:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  6e5439:	48 89 4c 24 38       	mov    %rcx,0x38(%rsp)
  6e543e:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
  6e5445:	00 00 
  6e5447:	66 0f 7f 84 24 c0 01 	movdqa %xmm0,0x1c0(%rsp)
  6e544e:	00 00 
  6e5450:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  6e5457:	00 
  6e5458:	48 89 8c 24 d0 01 00 	mov    %rcx,0x1d0(%rsp)
  6e545f:	00 
  6e5460:	49 89 c5             	mov    %rax,%r13
  6e5463:	e9 04 fe ff ff       	jmp    6e526c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x207c>
  6e5468:	89 44 24 18          	mov    %eax,0x18(%rsp)
  6e546c:	0f b6 44 24 6f       	movzbl 0x6f(%rsp),%eax
  6e5471:	c1 e0 10             	shl    $0x10,%eax
  6e5474:	0f b7 4c 24 6d       	movzwl 0x6d(%rsp),%ecx
  6e5479:	09 c1                	or     %eax,%ecx
  6e547b:	48 c1 e1 20          	shl    $0x20,%rcx
  6e547f:	8b 6c 24 69          	mov    0x69(%rsp),%ebp
  6e5483:	48 09 cd             	or     %rcx,%rbp
  6e5486:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  6e548b:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  6e5490:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  6e5495:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  6e549a:	f3 0f 6f 84 24 80 00 	movdqu 0x80(%rsp),%xmm0
  6e54a1:	00 00 
  6e54a3:	66 0f 7f 84 24 a0 03 	movdqa %xmm0,0x3a0(%rsp)
  6e54aa:	00 00 
  6e54ac:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6e54b3:	00 
  6e54b4:	48 89 84 24 b0 03 00 	mov    %rax,0x3b0(%rsp)
  6e54bb:	00 
  6e54bc:	eb 17                	jmp    6e54d5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x22e5>
  6e54be:	89 74 24 18          	mov    %esi,0x18(%rsp)
  6e54c2:	48 b8 ff ff ff ff ff 	movabs $0xffffffffff,%rax
  6e54c9:	00 00 00 
  6e54cc:	48 21 c5             	and    %rax,%rbp
  6e54cf:	41 bd 25 00 00 00    	mov    $0x25,%r13d
  6e54d5:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
  6e54db:	0f 84 d7 ef ff ff    	je     6e44b8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x12c8>
  6e54e1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e54e6:	f6 00 01             	testb  $0x1,(%rax)
  6e54e9:	0f 85 c9 ef ff ff    	jne    6e44b8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x12c8>
  6e54ef:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e54f4:	48 8b 40 08          	mov    0x8(%rax),%rax
  6e54f8:	a8 01                	test   $0x1,%al
  6e54fa:	0f 85 b8 ef ff ff    	jne    6e44b8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x12c8>
  6e5500:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e5505:	48 83 c0 08          	add    $0x8,%rax
  6e5509:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e550e:	0f 85 a4 ef ff ff    	jne    6e44b8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x12c8>
  6e5514:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6e5519:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e551d:	ff 15 d5 b9 39 00    	call   *0x39b9d5(%rip)        # a80ef8 <_DYNAMIC+0x2a8>
  6e5523:	e9 90 ef ff ff       	jmp    6e44b8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x12c8>
  6e5528:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e552c:	ff 15 c6 b9 39 00    	call   *0x39b9c6(%rip)        # a80ef8 <_DYNAMIC+0x2a8>
  6e5532:	e9 34 e2 ff ff       	jmp    6e376b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x57b>
  6e5537:	48 8d 3d 9a 2d 37 00 	lea    0x372d9a(%rip),%rdi        # a582d8 <__frame_dummy_init_array_entry+0x628>
  6e553e:	ff 15 94 b9 39 00    	call   *0x39b994(%rip)        # a80ed8 <_DYNAMIC+0x288>
  6e5544:	e9 ef 01 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e5549:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e554d:	ff 15 a5 b9 39 00    	call   *0x39b9a5(%rip)        # a80ef8 <_DYNAMIC+0x2a8>
  6e5553:	e9 56 fe ff ff       	jmp    6e53ae <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x21be>
  6e5558:	41 bd 15 00 00 00    	mov    $0x15,%r13d
  6e555e:	eb 3c                	jmp    6e559c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x23ac>
  6e5560:	48 8d 05 9d 4c 97 ff 	lea    -0x68b363(%rip),%rax        # 5a204 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x4174>
  6e5567:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  6e556e:	00 
  6e556f:	48 8d 05 fa 33 37 00 	lea    0x3733fa(%rip),%rax        # a58970 <__frame_dummy_init_array_entry+0xcc0>
  6e5576:	eb 1c                	jmp    6e5594 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x23a4>
  6e5578:	41 bd 14 00 00 00    	mov    $0x14,%r13d
  6e557e:	48 8d 05 6b 4c 97 ff 	lea    -0x68b395(%rip),%rax        # 5a1f0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x4160>
  6e5585:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  6e558c:	00 
  6e558d:	48 8d 05 c4 33 37 00 	lea    0x3733c4(%rip),%rax        # a58958 <__frame_dummy_init_array_entry+0xca8>
  6e5594:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  6e559b:	00 
  6e559c:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
  6e55a3:	00 
  6e55a4:	4c 89 ee             	mov    %r13,%rsi
  6e55a7:	48 8b 94 24 30 01 00 	mov    0x130(%rsp),%rdx
  6e55ae:	00 
  6e55af:	ff 15 03 ba 39 00    	call   *0x39ba03(%rip)        # a80fb8 <_DYNAMIC+0x368>
  6e55b5:	e9 7e 01 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e55ba:	48 8d 3d 07 4c 97 ff 	lea    -0x68b3f9(%rip),%rdi        # 5a1c8 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x4138>
  6e55c1:	48 8d 15 30 33 37 00 	lea    0x373330(%rip),%rdx        # a588f8 <__frame_dummy_init_array_entry+0xc48>
  6e55c8:	be 13 00 00 00       	mov    $0x13,%esi
  6e55cd:	ff 15 e5 b9 39 00    	call   *0x39b9e5(%rip)        # a80fb8 <_DYNAMIC+0x368>
  6e55d3:	e9 60 01 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e55d8:	be 93 00 00 00       	mov    $0x93,%esi
  6e55dd:	48 8d 05 61 4c 97 ff 	lea    -0x68b39f(%rip),%rax        # 5a245 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x41b5>
  6e55e4:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
  6e55eb:	00 
  6e55ec:	48 8d 05 dd 33 37 00 	lea    0x3733dd(%rip),%rax        # a589d0 <__frame_dummy_init_array_entry+0xd20>
  6e55f3:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  6e55fa:	00 
  6e55fb:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
  6e5602:	00 
  6e5603:	48 8b 94 24 30 02 00 	mov    0x230(%rsp),%rdx
  6e560a:	00 
  6e560b:	ff 15 df b8 39 00    	call   *0x39b8df(%rip)        # a80ef0 <_DYNAMIC+0x2a0>
  6e5611:	e9 22 01 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e5616:	48 8d 3d 93 29 37 00 	lea    0x372993(%rip),%rdi        # a57fb0 <__frame_dummy_init_array_entry+0x300>
  6e561d:	ff 15 b5 b8 39 00    	call   *0x39b8b5(%rip)        # a80ed8 <_DYNAMIC+0x288>
  6e5623:	e9 10 01 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e5628:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  6e562f:	00 00 
  6e5631:	48 8d 3d 68 33 37 00 	lea    0x373368(%rip),%rdi        # a589a0 <__frame_dummy_init_array_entry+0xcf0>
  6e5638:	ff 15 9a b8 39 00    	call   *0x39b89a(%rip)        # a80ed8 <_DYNAMIC+0x288>
  6e563e:	e9 f5 00 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e5643:	48 8d 05 36 29 37 00 	lea    0x372936(%rip),%rax        # a57f80 <__frame_dummy_init_array_entry+0x2d0>
  6e564a:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
  6e5651:	00 
  6e5652:	48 8b bc 24 20 02 00 	mov    0x220(%rsp),%rdi
  6e5659:	00 
  6e565a:	ff 15 78 b8 39 00    	call   *0x39b878(%rip)        # a80ed8 <_DYNAMIC+0x288>
  6e5660:	e9 d3 00 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e5665:	be 83 00 00 00       	mov    $0x83,%esi
  6e566a:	eb 8f                	jmp    6e55fb <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x240b>
  6e566c:	48 8d 3d 74 4a 97 ff 	lea    -0x68b58c(%rip),%rdi        # 5a0e7 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x4057>
  6e5673:	48 8d 15 06 2f 37 00 	lea    0x372f06(%rip),%rdx        # a58580 <__frame_dummy_init_array_entry+0x8d0>
  6e567a:	be 83 00 00 00       	mov    $0x83,%esi
  6e567f:	ff 15 6b b8 39 00    	call   *0x39b86b(%rip)        # a80ef0 <_DYNAMIC+0x2a0>
  6e5685:	e9 ae 00 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e568a:	48 8d 15 07 29 37 00 	lea    0x372907(%rip),%rdx        # a57f98 <__frame_dummy_init_array_entry+0x2e8>
  6e5691:	ff 15 31 b9 39 00    	call   *0x39b931(%rip)        # a80fc8 <_DYNAMIC+0x378>
  6e5697:	e9 9c 00 00 00       	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e569c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6e56a1:	48 8d 05 f0 28 37 00 	lea    0x3728f0(%rip),%rax        # a57f98 <__frame_dummy_init_array_entry+0x2e8>
  6e56a8:	eb 2c                	jmp    6e56d6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24e6>
  6e56aa:	48 8d 05 3f 2c 37 00 	lea    0x372c3f(%rip),%rax        # a582f0 <__frame_dummy_init_array_entry+0x640>
  6e56b1:	eb 23                	jmp    6e56d6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24e6>
  6e56b3:	48 8d 05 4e 2c 37 00 	lea    0x372c4e(%rip),%rax        # a58308 <__frame_dummy_init_array_entry+0x658>
  6e56ba:	eb 1a                	jmp    6e56d6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24e6>
  6e56bc:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6e56c1:	48 8d 05 58 2c 37 00 	lea    0x372c58(%rip),%rax        # a58320 <__frame_dummy_init_array_entry+0x670>
  6e56c8:	eb 0c                	jmp    6e56d6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x24e6>
  6e56ca:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  6e56cf:	48 8d 05 92 28 37 00 	lea    0x372892(%rip),%rax        # a57f68 <__frame_dummy_init_array_entry+0x2b8>
  6e56d6:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  6e56dd:	00 
  6e56de:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  6e56e3:	48 8b 94 24 e8 00 00 	mov    0xe8(%rsp),%rdx
  6e56ea:	00 
  6e56eb:	ff 15 d7 b8 39 00    	call   *0x39b8d7(%rip)        # a80fc8 <_DYNAMIC+0x378>
  6e56f1:	eb 45                	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e56f3:	48 85 ff             	test   %rdi,%rdi
  6e56f6:	75 11                	jne    6e5709 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2519>
  6e56f8:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  6e56ff:	00 00 
  6e5701:	ff 15 a9 b9 39 00    	call   *0x39b9a9(%rip)        # a810b0 <_DYNAMIC+0x460>
  6e5707:	eb 2f                	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e5709:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  6e570e:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  6e5715:	00 00 
  6e5717:	ff 15 ab b7 39 00    	call   *0x39b7ab(%rip)        # a80ec8 <_DYNAMIC+0x278>
  6e571d:	eb 19                	jmp    6e5738 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2548>
  6e571f:	48 8d 3d b5 4a 97 ff 	lea    -0x68b54b(%rip),%rdi        # 5a1db <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x414b>
  6e5726:	48 8d 15 e3 31 37 00 	lea    0x3731e3(%rip),%rdx        # a58910 <__frame_dummy_init_array_entry+0xc60>
  6e572d:	be 15 00 00 00       	mov    $0x15,%esi
  6e5732:	ff 15 80 b8 39 00    	call   *0x39b880(%rip)        # a80fb8 <_DYNAMIC+0x368>
  6e5738:	0f 0b                	ud2
  6e573a:	49 89 c4             	mov    %rax,%r12
  6e573d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e5742:	49 89 47 10          	mov    %rax,0x10(%r15)
  6e5746:	e9 dc 01 00 00       	jmp    6e5927 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2737>
  6e574b:	49 89 c4             	mov    %rax,%r12
  6e574e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e5753:	49 89 47 08          	mov    %rax,0x8(%r15)
  6e5757:	e9 cb 01 00 00       	jmp    6e5927 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2737>
  6e575c:	49 89 c4             	mov    %rax,%r12
  6e575f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e5764:	49 89 45 40          	mov    %rax,0x40(%r13)
  6e5768:	e9 ba 01 00 00       	jmp    6e5927 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2737>
  6e576d:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e5772:	49 89 c6             	mov    %rax,%r14
  6e5775:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  6e577c:	00 
  6e577d:	e8 ee a8 ff ff       	call   6e0070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e5782:	e9 4c 01 00 00       	jmp    6e58d3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26e3>
  6e5787:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e578c:	49 89 c6             	mov    %rax,%r14
  6e578f:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e5794:	e9 4c 01 00 00       	jmp    6e58e5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26f5>
  6e5799:	eb 2b                	jmp    6e57c6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x25d6>
  6e579b:	eb 29                	jmp    6e57c6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x25d6>
  6e579d:	eb 00                	jmp    6e579f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x25af>
  6e579f:	49 89 c4             	mov    %rax,%r12
  6e57a2:	49 c7 45 00 ff ff ff 	movq   $0xffffffffffffffff,0x0(%r13)
  6e57a9:	ff 
  6e57aa:	e9 78 01 00 00       	jmp    6e5927 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2737>
  6e57af:	e9 70 01 00 00       	jmp    6e5924 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2734>
  6e57b4:	e9 17 01 00 00       	jmp    6e58d0 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26e0>
  6e57b9:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e57be:	49 89 c4             	mov    %rax,%r12
  6e57c1:	e9 91 01 00 00       	jmp    6e5957 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2767>
  6e57c6:	49 89 c4             	mov    %rax,%r12
  6e57c9:	e9 63 01 00 00       	jmp    6e5931 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2741>
  6e57ce:	49 89 c4             	mov    %rax,%r12
  6e57d1:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
  6e57d7:	0f 8e 7a 01 00 00    	jle    6e5957 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2767>
  6e57dd:	ba 01 00 00 00       	mov    $0x1,%edx
  6e57e2:	4c 89 ff             	mov    %r15,%rdi
  6e57e5:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  6e57ea:	e9 62 01 00 00       	jmp    6e5951 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2761>
  6e57ef:	48 89 c7             	mov    %rax,%rdi
  6e57f2:	ff 15 e0 b7 39 00    	call   *0x39b7e0(%rip)        # a80fd8 <_DYNAMIC+0x388>
  6e57f8:	48 89 c5             	mov    %rax,%rbp
  6e57fb:	49 89 d5             	mov    %rdx,%r13
  6e57fe:	48 89 84 24 c8 01 00 	mov    %rax,0x1c8(%rsp)
  6e5805:	00 
  6e5806:	48 89 94 24 d0 01 00 	mov    %rdx,0x1d0(%rsp)
  6e580d:	00 
  6e580e:	48 c7 84 24 c0 01 00 	movq   $0xfffffffffffffffd,0x1c0(%rsp)
  6e5815:	00 fd ff ff ff 
  6e581a:	48 8b 84 24 b8 01 00 	mov    0x1b8(%rsp),%rax
  6e5821:	00 
  6e5822:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
  6e5829:	00 
  6e582a:	48 89 df             	mov    %rbx,%rdi
  6e582d:	e8 1e 17 01 00       	call   6f6f50 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::poison>
  6e5832:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e5837:	48 c7 84 24 f0 00 00 	movq   $0xf,0xf0(%rsp)
  6e583e:	00 0f 00 00 00 
  6e5843:	49 8b 45 00          	mov    0x0(%r13),%rax
  6e5847:	48 85 c0             	test   %rax,%rax
  6e584a:	74 05                	je     6e5851 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2661>
  6e584c:	48 89 ef             	mov    %rbp,%rdi
  6e584f:	ff d0                	call   *%rax
  6e5851:	49 8b 75 08          	mov    0x8(%r13),%rsi
  6e5855:	48 85 f6             	test   %rsi,%rsi
  6e5858:	0f 84 54 dc ff ff    	je     6e34b2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2c2>
  6e585e:	49 8b 55 10          	mov    0x10(%r13),%rdx
  6e5862:	48 89 ef             	mov    %rbp,%rdi
  6e5865:	ff 15 2d b6 39 00    	call   *0x39b62d(%rip)        # a80e98 <_DYNAMIC+0x248>
  6e586b:	e9 42 dc ff ff       	jmp    6e34b2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2c2>
  6e5870:	ff 15 6a b7 39 00    	call   *0x39b76a(%rip)        # a80fe0 <_DYNAMIC+0x390>
  6e5876:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e587b:	49 89 c6             	mov    %rax,%r14
  6e587e:	49 8b 75 08          	mov    0x8(%r13),%rsi
  6e5882:	48 85 f6             	test   %rsi,%rsi
  6e5885:	74 63                	je     6e58ea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26fa>
  6e5887:	49 8b 55 10          	mov    0x10(%r13),%rdx
  6e588b:	48 89 ef             	mov    %rbp,%rdi
  6e588e:	ff 15 04 b6 39 00    	call   *0x39b604(%rip)        # a80e98 <_DYNAMIC+0x248>
  6e5894:	eb 54                	jmp    6e58ea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26fa>
  6e5896:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e589b:	49 89 c6             	mov    %rax,%r14
  6e589e:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
  6e58a5:	00 
  6e58a6:	e8 95 80 ff ff       	call   6dd940 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e58ab:	eb 3d                	jmp    6e58ea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26fa>
  6e58ad:	ff 15 35 b6 39 00    	call   *0x39b635(%rip)        # a80ee8 <_DYNAMIC+0x298>
  6e58b3:	49 89 c6             	mov    %rax,%r14
  6e58b6:	48 83 bc 24 f0 00 00 	cmpq   $0xfffffffffffffffe,0xf0(%rsp)
  6e58bd:	00 fe 
  6e58bf:	74 5b                	je     6e591c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x272c>
  6e58c1:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  6e58c8:	00 
  6e58c9:	eb 4c                	jmp    6e5917 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2727>
  6e58cb:	4c 89 64 24 58       	mov    %r12,0x58(%rsp)
  6e58d0:	49 89 c6             	mov    %rax,%r14
  6e58d3:	83 bc 24 08 04 00 00 	cmpl   $0xfffffffe,0x408(%rsp)
  6e58da:	fe 
  6e58db:	74 0d                	je     6e58ea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26fa>
  6e58dd:	48 8d bc 24 08 04 00 	lea    0x408(%rsp),%rdi
  6e58e4:	00 
  6e58e5:	e8 86 a7 ff ff       	call   6e0070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e58ea:	80 bb 26 07 00 00 00 	cmpb   $0x0,0x726(%rbx)
  6e58f1:	75 0a                	jne    6e58fd <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x270d>
  6e58f3:	48 83 bb 68 06 00 00 	cmpq   $0xffffffffffffffff,0x668(%rbx)
  6e58fa:	ff 
  6e58fb:	75 1f                	jne    6e591c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x272c>
  6e58fd:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  6e5902:	e8 89 10 02 00       	call   706990 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e5907:	eb 13                	jmp    6e591c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x272c>
  6e5909:	ff 15 d9 b5 39 00    	call   *0x39b5d9(%rip)        # a80ee8 <_DYNAMIC+0x298>
  6e590f:	49 89 c6             	mov    %rax,%r14
  6e5912:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  6e5917:	e8 54 a7 ff ff       	call   6e0070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e591c:	4c 89 f7             	mov    %r14,%rdi
  6e591f:	e8 dc 0f 37 00       	call   a56900 <_Unwind_Resume@plt>
  6e5924:	49 89 c4             	mov    %rax,%r12
  6e5927:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  6e592c:	e8 bf 7b ff ff       	call   6dd4f0 <core::ptr::drop_glue::<core::option::Option<gpui::shared_text::SharedText>>>
  6e5931:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  6e5938:	00 00 
  6e593a:	7e 1b                	jle    6e5957 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2767>
  6e593c:	ba 01 00 00 00       	mov    $0x1,%edx
  6e5941:	48 8b bc 24 d8 00 00 	mov    0xd8(%rsp),%rdi
  6e5948:	00 
  6e5949:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
  6e5950:	00 
  6e5951:	ff 15 41 b5 39 00    	call   *0x39b541(%rip)        # a80e98 <_DYNAMIC+0x248>
  6e5957:	4c 89 e7             	mov    %r12,%rdi
  6e595a:	ff 15 78 b6 39 00    	call   *0x39b678(%rip)        # a80fd8 <_DYNAMIC+0x388>
  6e5960:	49 89 c5             	mov    %rax,%r13
  6e5963:	48 89 d5             	mov    %rdx,%rbp
  6e5966:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
  6e596d:	00 
  6e596e:	48 89 94 24 60 01 00 	mov    %rdx,0x160(%rsp)
  6e5975:	00 
  6e5976:	48 c7 84 24 50 01 00 	movq   $0xfffffffffffffffd,0x150(%rsp)
  6e597d:	00 fd ff ff ff 
  6e5982:	48 89 df             	mov    %rbx,%rdi
  6e5985:	e8 c6 15 01 00       	call   6f6f50 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::poison>
  6e598a:	48 c7 84 24 a0 02 00 	movq   $0xf,0x2a0(%rsp)
  6e5991:	00 0f 00 00 00 
  6e5996:	48 8b 45 00          	mov    0x0(%rbp),%rax
  6e599a:	48 85 c0             	test   %rax,%rax
  6e599d:	74 05                	je     6e59a4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x27b4>
  6e599f:	4c 89 ef             	mov    %r13,%rdi
  6e59a2:	ff d0                	call   *%rax
  6e59a4:	48 8b 75 08          	mov    0x8(%rbp),%rsi
  6e59a8:	48 85 f6             	test   %rsi,%rsi
  6e59ab:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
  6e59b0:	4d 8d 67 08          	lea    0x8(%r15),%r12
  6e59b4:	0f 84 55 f9 ff ff    	je     6e530f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x211f>
  6e59ba:	48 8b 55 10          	mov    0x10(%rbp),%rdx
  6e59be:	4c 89 ef             	mov    %r13,%rdi
  6e59c1:	ff 15 d1 b4 39 00    	call   *0x39b4d1(%rip)        # a80e98 <_DYNAMIC+0x248>
  6e59c7:	e9 43 f9 ff ff       	jmp    6e530f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x211f>
  6e59cc:	49 89 c6             	mov    %rax,%r14
  6e59cf:	48 8b 75 08          	mov    0x8(%rbp),%rsi
  6e59d3:	48 85 f6             	test   %rsi,%rsi
  6e59d6:	0f 84 f7 fe ff ff    	je     6e58d3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26e3>
  6e59dc:	48 8b 55 10          	mov    0x10(%rbp),%rdx
  6e59e0:	4c 89 ef             	mov    %r13,%rdi
  6e59e3:	ff 15 af b4 39 00    	call   *0x39b4af(%rip)        # a80e98 <_DYNAMIC+0x248>
  6e59e9:	e9 e5 fe ff ff       	jmp    6e58d3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26e3>
  6e59ee:	ff 15 f4 b4 39 00    	call   *0x39b4f4(%rip)        # a80ee8 <_DYNAMIC+0x298>
  6e59f4:	49 89 c6             	mov    %rax,%r14
  6e59f7:	48 8d bc 24 50 01 00 	lea    0x150(%rsp),%rdi
  6e59fe:	00 
  6e59ff:	e8 3c 7f ff ff       	call   6dd940 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e5a04:	e9 ca fe ff ff       	jmp    6e58d3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x26e3>
  6e5a09:	ff 15 d9 b4 39 00    	call   *0x39b4d9(%rip)        # a80ee8 <_DYNAMIC+0x298>
  6e5a0f:	ff 15 cb b5 39 00    	call   *0x39b5cb(%rip)        # a80fe0 <_DYNAMIC+0x390>
  6e5a15:	cc                   	int3
  6e5a16:	cc                   	int3
  6e5a17:	cc                   	int3
  6e5a18:	cc                   	int3
  6e5a19:	cc                   	int3
  6e5a1a:	cc                   	int3
  6e5a1b:	cc                   	int3
  6e5a1c:	cc                   	int3
  6e5a1d:	cc                   	int3
  6e5a1e:	cc                   	int3
  6e5a1f:	cc                   	int3

0000000000705890 <<gpui::remote::Remote<u64>>::bounded>:
  705890:	41 57                	push   %r15
  705892:	41 56                	push   %r14
  705894:	41 55                	push   %r13
  705896:	41 54                	push   %r12
  705898:	53                   	push   %rbx
  705899:	4c 8d 24 f5 00 00 00 	lea    0x0(,%rsi,8),%r12
  7058a0:	00 
  7058a1:	48 89 f0             	mov    %rsi,%rax
  7058a4:	48 c1 e8 3d          	shr    $0x3d,%rax
  7058a8:	0f 95 c0             	setne  %al
  7058ab:	48 b9 f8 ff ff ff ff 	movabs $0x7ffffffffffffff8,%rcx
  7058b2:	ff ff 7f 
  7058b5:	49 39 cc             	cmp    %rcx,%r12
  7058b8:	0f 97 c1             	seta   %cl
  7058bb:	08 c1                	or     %al,%cl
  7058bd:	74 0f                	je     7058ce <<gpui::remote::Remote<u64>>::bounded+0x3e>
  7058bf:	45 31 ed             	xor    %r13d,%r13d
  7058c2:	4c 89 ef             	mov    %r13,%rdi
  7058c5:	4c 89 e6             	mov    %r12,%rsi
  7058c8:	ff 15 aa b6 37 00    	call   *0x37b6aa(%rip)        # a80f78 <_DYNAMIC+0x328>
  7058ce:	49 89 f6             	mov    %rsi,%r14
  7058d1:	48 89 fb             	mov    %rdi,%rbx
  7058d4:	4d 85 e4             	test   %r12,%r12
  7058d7:	74 27                	je     705900 <<gpui::remote::Remote<u64>>::bounded+0x70>
  7058d9:	ff 15 d1 b5 37 00    	call   *0x37b5d1(%rip)        # a80eb0 <_DYNAMIC+0x260>
  7058df:	41 bd 08 00 00 00    	mov    $0x8,%r13d
  7058e5:	be 08 00 00 00       	mov    $0x8,%esi
  7058ea:	4c 89 e7             	mov    %r12,%rdi
  7058ed:	ff 15 9d b5 37 00    	call   *0x37b59d(%rip)        # a80e90 <_DYNAMIC+0x240>
  7058f3:	48 85 c0             	test   %rax,%rax
  7058f6:	74 ca                	je     7058c2 <<gpui::remote::Remote<u64>>::bounded+0x32>
  7058f8:	49 89 c7             	mov    %rax,%r15
  7058fb:	4d 89 f4             	mov    %r14,%r12
  7058fe:	eb 09                	jmp    705909 <<gpui::remote::Remote<u64>>::bounded+0x79>
  705900:	41 bf 08 00 00 00    	mov    $0x8,%r15d
  705906:	45 31 e4             	xor    %r12d,%r12d
  705909:	ff 15 a1 b5 37 00    	call   *0x37b5a1(%rip)        # a80eb0 <_DYNAMIC+0x260>
  70590f:	bf 50 00 00 00       	mov    $0x50,%edi
  705914:	be 08 00 00 00       	mov    $0x8,%esi
  705919:	ff 15 71 b5 37 00    	call   *0x37b571(%rip)        # a80e90 <_DYNAMIC+0x240>
  70591f:	48 85 c0             	test   %rax,%rax
  705922:	74 61                	je     705985 <<gpui::remote::Remote<u64>>::bounded+0xf5>
  705924:	48 c7 00 01 00 00 00 	movq   $0x1,(%rax)
  70592b:	48 c7 40 08 01 00 00 	movq   $0x1,0x8(%rax)
  705932:	00 
  705933:	c7 40 10 00 00 00 00 	movl   $0x0,0x10(%rax)
  70593a:	c6 40 14 00          	movb   $0x0,0x14(%rax)
  70593e:	4c 89 60 18          	mov    %r12,0x18(%rax)
  705942:	4c 89 78 20          	mov    %r15,0x20(%rax)
  705946:	0f 57 c0             	xorps  %xmm0,%xmm0
  705949:	0f 11 40 28          	movups %xmm0,0x28(%rax)
  70594d:	4c 89 70 38          	mov    %r14,0x38(%rax)
  705951:	48 c7 40 40 01 00 00 	movq   $0x1,0x40(%rax)
  705958:	00 
  705959:	66 c7 40 48 01 00    	movw   $0x1,0x48(%rax)
  70595f:	f0 48 ff 00          	lock incq (%rax)
  705963:	7e 30                	jle    705995 <<gpui::remote::Remote<u64>>::bounded+0x105>
  705965:	48 89 03             	mov    %rax,(%rbx)
  705968:	48 89 43 08          	mov    %rax,0x8(%rbx)
  70596c:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
  705973:	00 
  705974:	c6 43 18 00          	movb   $0x0,0x18(%rbx)
  705978:	48 89 d8             	mov    %rbx,%rax
  70597b:	5b                   	pop    %rbx
  70597c:	41 5c                	pop    %r12
  70597e:	41 5d                	pop    %r13
  705980:	41 5e                	pop    %r14
  705982:	41 5f                	pop    %r15
  705984:	c3                   	ret
  705985:	bf 08 00 00 00       	mov    $0x8,%edi
  70598a:	be 50 00 00 00       	mov    $0x50,%esi
  70598f:	ff 15 33 b5 37 00    	call   *0x37b533(%rip)        # a80ec8 <_DYNAMIC+0x278>
  705995:	0f 0b                	ud2
  705997:	48 89 c3             	mov    %rax,%rbx
  70599a:	4d 85 e4             	test   %r12,%r12
  70599d:	74 15                	je     7059b4 <<gpui::remote::Remote<u64>>::bounded+0x124>
  70599f:	49 c1 e4 03          	shl    $0x3,%r12
  7059a3:	ba 08 00 00 00       	mov    $0x8,%edx
  7059a8:	4c 89 ff             	mov    %r15,%rdi
  7059ab:	4c 89 e6             	mov    %r12,%rsi
  7059ae:	ff 15 e4 b4 37 00    	call   *0x37b4e4(%rip)        # a80e98 <_DYNAMIC+0x248>
  7059b4:	48 89 df             	mov    %rbx,%rdi
  7059b7:	e8 44 0f 35 00       	call   a56900 <_Unwind_Resume@plt>
  7059bc:	cc                   	int3
  7059bd:	cc                   	int3
  7059be:	cc                   	int3
  7059bf:	cc                   	int3

00000000007059c0 <<gpui::remote::Remote<u64>>::try_send>:
  7059c0:	55                   	push   %rbp
  7059c1:	41 57                	push   %r15
  7059c3:	41 56                	push   %r14
  7059c5:	41 55                	push   %r13
  7059c7:	41 54                	push   %r12
  7059c9:	53                   	push   %rbx
  7059ca:	50                   	push   %rax
  7059cb:	48 89 f3             	mov    %rsi,%rbx
  7059ce:	4c 8b 3f             	mov    (%rdi),%r15
  7059d1:	4d 8d 77 10          	lea    0x10(%r15),%r14
  7059d5:	b9 01 00 00 00       	mov    $0x1,%ecx
  7059da:	31 c0                	xor    %eax,%eax
  7059dc:	f0 41 0f b1 4f 10    	lock cmpxchg %ecx,0x10(%r15)
  7059e2:	0f 85 e0 00 00 00    	jne    705ac8 <<gpui::remote::Remote<u64>>::try_send+0x108>
  7059e8:	4c 8b 25 d1 b9 37 00 	mov    0x37b9d1(%rip),%r12        # a813c0 <_DYNAMIC+0x770>
  7059ef:	49 8b 04 24          	mov    (%r12),%rax
  7059f3:	48 d1 e0             	shl    $1,%rax
  7059f6:	48 85 c0             	test   %rax,%rax
  7059f9:	0f 85 d7 00 00 00    	jne    705ad6 <<gpui::remote::Remote<u64>>::try_send+0x116>
  7059ff:	31 ed                	xor    %ebp,%ebp
  705a01:	49 bd ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r13
  705a08:	ff ff 7f 
  705a0b:	41 0f b6 47 14       	movzbl 0x14(%r15),%eax
  705a10:	b8 01 00 00 00       	mov    $0x1,%eax
  705a15:	41 80 7f 48 01       	cmpb   $0x1,0x48(%r15)
  705a1a:	75 0c                	jne    705a28 <<gpui::remote::Remote<u64>>::try_send+0x68>
  705a1c:	49 8b 47 30          	mov    0x30(%r15),%rax
  705a20:	49 3b 47 38          	cmp    0x38(%r15),%rax
  705a24:	75 30                	jne    705a56 <<gpui::remote::Remote<u64>>::try_send+0x96>
  705a26:	31 c0                	xor    %eax,%eax
  705a28:	40 84 ed             	test   %bpl,%bpl
  705a2b:	75 0d                	jne    705a3a <<gpui::remote::Remote<u64>>::try_send+0x7a>
  705a2d:	49 8b 0c 24          	mov    (%r12),%rcx
  705a31:	4c 85 e9             	test   %r13,%rcx
  705a34:	0f 85 ad 00 00 00    	jne    705ae7 <<gpui::remote::Remote<u64>>::try_send+0x127>
  705a3a:	31 c9                	xor    %ecx,%ecx
  705a3c:	41 87 0e             	xchg   %ecx,(%r14)
  705a3f:	83 f9 02             	cmp    $0x2,%ecx
  705a42:	74 70                	je     705ab4 <<gpui::remote::Remote<u64>>::try_send+0xf4>
  705a44:	48 89 da             	mov    %rbx,%rdx
  705a47:	48 83 c4 08          	add    $0x8,%rsp
  705a4b:	5b                   	pop    %rbx
  705a4c:	41 5c                	pop    %r12
  705a4e:	41 5d                	pop    %r13
  705a50:	41 5e                	pop    %r14
  705a52:	41 5f                	pop    %r15
  705a54:	5d                   	pop    %rbp
  705a55:	c3                   	ret
  705a56:	49 8d 7f 18          	lea    0x18(%r15),%rdi
  705a5a:	48 8b 0f             	mov    (%rdi),%rcx
  705a5d:	48 39 c8             	cmp    %rcx,%rax
  705a60:	75 0d                	jne    705a6f <<gpui::remote::Remote<u64>>::try_send+0xaf>
  705a62:	e8 b9 bc 00 00       	call   711720 <<alloc::collections::vec_deque::VecDeque<u64>>::grow>
  705a67:	49 8b 4f 18          	mov    0x18(%r15),%rcx
  705a6b:	49 8b 47 30          	mov    0x30(%r15),%rax
  705a6f:	4c 89 ee             	mov    %r13,%rsi
  705a72:	48 8d 50 01          	lea    0x1(%rax),%rdx
  705a76:	49 89 57 30          	mov    %rdx,0x30(%r15)
  705a7a:	49 03 47 28          	add    0x28(%r15),%rax
  705a7e:	45 31 ed             	xor    %r13d,%r13d
  705a81:	48 39 c8             	cmp    %rcx,%rax
  705a84:	ba 00 00 00 00       	mov    $0x0,%edx
  705a89:	48 0f 43 d1          	cmovae %rcx,%rdx
  705a8d:	48 29 d0             	sub    %rdx,%rax
  705a90:	49 8b 4f 20          	mov    0x20(%r15),%rcx
  705a94:	48 89 1c c1          	mov    %rbx,(%rcx,%rax,8)
  705a98:	40 84 ed             	test   %bpl,%bpl
  705a9b:	75 09                	jne    705aa6 <<gpui::remote::Remote<u64>>::try_send+0xe6>
  705a9d:	49 8b 04 24          	mov    (%r12),%rax
  705aa1:	48 85 f0             	test   %rsi,%rax
  705aa4:	75 61                	jne    705b07 <<gpui::remote::Remote<u64>>::try_send+0x147>
  705aa6:	45 87 2e             	xchg   %r13d,(%r14)
  705aa9:	b8 02 00 00 00       	mov    $0x2,%eax
  705aae:	41 83 fd 02          	cmp    $0x2,%r13d
  705ab2:	75 90                	jne    705a44 <<gpui::remote::Remote<u64>>::try_send+0x84>
  705ab4:	4c 89 f7             	mov    %r14,%rdi
  705ab7:	49 89 c6             	mov    %rax,%r14
  705aba:	ff 15 08 b9 37 00    	call   *0x37b908(%rip)        # a813c8 <_DYNAMIC+0x778>
  705ac0:	4c 89 f0             	mov    %r14,%rax
  705ac3:	e9 7c ff ff ff       	jmp    705a44 <<gpui::remote::Remote<u64>>::try_send+0x84>
  705ac8:	4c 89 f7             	mov    %r14,%rdi
  705acb:	ff 15 07 b9 37 00    	call   *0x37b907(%rip)        # a813d8 <_DYNAMIC+0x788>
  705ad1:	e9 12 ff ff ff       	jmp    7059e8 <<gpui::remote::Remote<u64>>::try_send+0x28>
  705ad6:	ff 15 f4 b8 37 00    	call   *0x37b8f4(%rip)        # a813d0 <_DYNAMIC+0x780>
  705adc:	89 c5                	mov    %eax,%ebp
  705ade:	40 80 f5 01          	xor    $0x1,%bpl
  705ae2:	e9 1a ff ff ff       	jmp    705a01 <<gpui::remote::Remote<u64>>::try_send+0x41>
  705ae7:	49 89 c4             	mov    %rax,%r12
  705aea:	ff 15 e0 b8 37 00    	call   *0x37b8e0(%rip)        # a813d0 <_DYNAMIC+0x780>
  705af0:	89 c1                	mov    %eax,%ecx
  705af2:	4c 89 e0             	mov    %r12,%rax
  705af5:	84 c9                	test   %cl,%cl
  705af7:	0f 85 3d ff ff ff    	jne    705a3a <<gpui::remote::Remote<u64>>::try_send+0x7a>
  705afd:	41 c6 47 14 01       	movb   $0x1,0x14(%r15)
  705b02:	e9 33 ff ff ff       	jmp    705a3a <<gpui::remote::Remote<u64>>::try_send+0x7a>
  705b07:	ff 15 c3 b8 37 00    	call   *0x37b8c3(%rip)        # a813d0 <_DYNAMIC+0x780>
  705b0d:	84 c0                	test   %al,%al
  705b0f:	75 95                	jne    705aa6 <<gpui::remote::Remote<u64>>::try_send+0xe6>
  705b11:	41 c6 47 14 01       	movb   $0x1,0x14(%r15)
  705b16:	eb 8e                	jmp    705aa6 <<gpui::remote::Remote<u64>>::try_send+0xe6>
  705b18:	48 89 c3             	mov    %rax,%rbx
  705b1b:	40 0f b6 f5          	movzbl %bpl,%esi
  705b1f:	4c 89 f7             	mov    %r14,%rdi
  705b22:	e8 19 fd ff ff       	call   705840 <core::ptr::drop_glue::<std::sync::poison::mutex::MutexGuard<gpui::remote::State<u64>>>>
  705b27:	48 89 df             	mov    %rbx,%rdi
  705b2a:	e8 d1 0d 35 00       	call   a56900 <_Unwind_Resume@plt>
  705b2f:	ff 15 b3 b3 37 00    	call   *0x37b3b3(%rip)        # a80ee8 <_DYNAMIC+0x298>
  705b35:	cc                   	int3
  705b36:	cc                   	int3
  705b37:	cc                   	int3
  705b38:	cc                   	int3
  705b39:	cc                   	int3
  705b3a:	cc                   	int3
  705b3b:	cc                   	int3
  705b3c:	cc                   	int3
  705b3d:	cc                   	int3
  705b3e:	cc                   	int3
  705b3f:	cc                   	int3

00000000007065a0 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply>:
  7065a0:	55                   	push   %rbp
  7065a1:	41 57                	push   %r15
  7065a3:	41 56                	push   %r14
  7065a5:	41 55                	push   %r13
  7065a7:	41 54                	push   %r12
  7065a9:	53                   	push   %rbx
  7065aa:	48 83 ec 18          	sub    $0x18,%rsp
  7065ae:	4d 89 c6             	mov    %r8,%r14
  7065b1:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  7065b6:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  7065bb:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  7065c0:	49 8b 28             	mov    (%r8),%rbp
  7065c3:	48 85 ed             	test   %rbp,%rbp
  7065c6:	0f 84 a4 01 00 00    	je     706770 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x1d0>
  7065cc:	4d 89 cf             	mov    %r9,%r15
  7065cf:	49 89 f4             	mov    %rsi,%r12
  7065d2:	49 8b 5c 24 18       	mov    0x18(%r12),%rbx
  7065d7:	48 85 db             	test   %rbx,%rbx
  7065da:	0f 84 6d 01 00 00    	je     70674d <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x1ad>
  7065e0:	49 8b 6c 24 10       	mov    0x10(%r12),%rbp
  7065e5:	31 c0                	xor    %eax,%eax
  7065e7:	b9 01 00 00 00       	mov    $0x1,%ecx
  7065ec:	f0 0f b1 4d 10       	lock cmpxchg %ecx,0x10(%rbp)
  7065f1:	0f 85 f1 00 00 00    	jne    7066e8 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x148>
  7065f7:	48 8b 05 c2 ad 37 00 	mov    0x37adc2(%rip),%rax        # a813c0 <_DYNAMIC+0x770>
  7065fe:	48 8b 00             	mov    (%rax),%rax
  706601:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
  706608:	ff ff 7f 
  70660b:	48 85 c8             	test   %rcx,%rax
  70660e:	0f 85 e9 00 00 00    	jne    7066fd <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x15d>
  706614:	31 c0                	xor    %eax,%eax
  706616:	0f b6 4d 14          	movzbl 0x14(%rbp),%ecx
  70661a:	48 ff cb             	dec    %rbx
  70661d:	49 89 5c 24 18       	mov    %rbx,0x18(%r12)
  706622:	4c 8b 6d 30          	mov    0x30(%rbp),%r13
  706626:	4d 85 ed             	test   %r13,%r13
  706629:	74 35                	je     706660 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0xc0>
  70662b:	48 8b 4d 28          	mov    0x28(%rbp),%rcx
  70662f:	48 8d 51 01          	lea    0x1(%rcx),%rdx
  706633:	48 8b 75 18          	mov    0x18(%rbp),%rsi
  706637:	48 8b 7d 20          	mov    0x20(%rbp),%rdi
  70663b:	48 39 f2             	cmp    %rsi,%rdx
  70663e:	ba 00 00 00 00       	mov    $0x0,%edx
  706643:	48 0f 43 d6          	cmovae %rsi,%rdx
  706647:	48 f7 da             	neg    %rdx
  70664a:	48 01 ca             	add    %rcx,%rdx
  70664d:	48 ff c2             	inc    %rdx
  706650:	48 89 55 28          	mov    %rdx,0x28(%rbp)
  706654:	49 8d 55 ff          	lea    -0x1(%r13),%rdx
  706658:	48 89 55 30          	mov    %rdx,0x30(%rbp)
  70665c:	48 8b 1c cf          	mov    (%rdi,%rcx,8),%rbx
  706660:	84 c0                	test   %al,%al
  706662:	75 1d                	jne    706681 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0xe1>
  706664:	48 8b 05 55 ad 37 00 	mov    0x37ad55(%rip),%rax        # a813c0 <_DYNAMIC+0x770>
  70666b:	48 8b 00             	mov    (%rax),%rax
  70666e:	48 b9 ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rcx
  706675:	ff ff 7f 
  706678:	48 85 c8             	test   %rcx,%rax
  70667b:	0f 85 b0 00 00 00    	jne    706731 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x191>
  706681:	31 c0                	xor    %eax,%eax
  706683:	87 45 10             	xchg   %eax,0x10(%rbp)
  706686:	83 f8 02             	cmp    $0x2,%eax
  706689:	0f 84 81 00 00 00    	je     706710 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x170>
  70668f:	49 8b 28             	mov    (%r8),%rbp
  706692:	4d 85 ed             	test   %r13,%r13
  706695:	0f 84 b2 00 00 00    	je     70674d <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x1ad>
  70669b:	48 ff cd             	dec    %rbp
  70669e:	4d 89 c5             	mov    %r8,%r13
  7066a1:	49 89 28             	mov    %rbp,(%r8)
  7066a4:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  7066a9:	48 89 de             	mov    %rbx,%rsi
  7066ac:	41 ff 54 24 08       	call   *0x8(%r12)
  7066b1:	49 8b 06             	mov    (%r14),%rax
  7066b4:	48 85 c0             	test   %rax,%rax
  7066b7:	74 06                	je     7066bf <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x11f>
  7066b9:	49 83 3f 00          	cmpq   $0x0,(%r15)
  7066bd:	74 07                	je     7066c6 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x126>
  7066bf:	49 c7 07 00 00 00 00 	movq   $0x0,(%r15)
  7066c6:	48 ff c0             	inc    %rax
  7066c9:	49 89 06             	mov    %rax,(%r14)
  7066cc:	48 85 ed             	test   %rbp,%rbp
  7066cf:	0f 84 9b 00 00 00    	je     706770 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x1d0>
  7066d5:	4d 89 e8             	mov    %r13,%r8
  7066d8:	49 8b 5c 24 18       	mov    0x18(%r12),%rbx
  7066dd:	48 85 db             	test   %rbx,%rbx
  7066e0:	0f 85 fa fe ff ff    	jne    7065e0 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x40>
  7066e6:	eb 65                	jmp    70674d <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x1ad>
  7066e8:	48 8d 7d 10          	lea    0x10(%rbp),%rdi
  7066ec:	4d 89 c5             	mov    %r8,%r13
  7066ef:	ff 15 e3 ac 37 00    	call   *0x37ace3(%rip)        # a813d8 <_DYNAMIC+0x788>
  7066f5:	4d 89 e8             	mov    %r13,%r8
  7066f8:	e9 fa fe ff ff       	jmp    7065f7 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x57>
  7066fd:	4d 89 c5             	mov    %r8,%r13
  706700:	ff 15 ca ac 37 00    	call   *0x37acca(%rip)        # a813d0 <_DYNAMIC+0x780>
  706706:	4d 89 e8             	mov    %r13,%r8
  706709:	34 01                	xor    $0x1,%al
  70670b:	e9 06 ff ff ff       	jmp    706616 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x76>
  706710:	48 83 c5 10          	add    $0x10,%rbp
  706714:	48 89 ef             	mov    %rbp,%rdi
  706717:	4c 89 c5             	mov    %r8,%rbp
  70671a:	ff 15 a8 ac 37 00    	call   *0x37aca8(%rip)        # a813c8 <_DYNAMIC+0x778>
  706720:	49 89 e8             	mov    %rbp,%r8
  706723:	49 8b 28             	mov    (%r8),%rbp
  706726:	4d 85 ed             	test   %r13,%r13
  706729:	0f 85 6c ff ff ff    	jne    70669b <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0xfb>
  70672f:	eb 1c                	jmp    70674d <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x1ad>
  706731:	ff 15 99 ac 37 00    	call   *0x37ac99(%rip)        # a813d0 <_DYNAMIC+0x780>
  706737:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  70673c:	84 c0                	test   %al,%al
  70673e:	0f 85 3d ff ff ff    	jne    706681 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0xe1>
  706744:	c6 45 14 01          	movb   $0x1,0x14(%rbp)
  706748:	e9 34 ff ff ff       	jmp    706681 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0xe1>
  70674d:	48 85 ed             	test   %rbp,%rbp
  706750:	74 1e                	je     706770 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x1d0>
  706752:	41 80 7c 24 20 01    	cmpb   $0x1,0x20(%r12)
  706758:	75 16                	jne    706770 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply+0x1d0>
  70675a:	48 ff cd             	dec    %rbp
  70675d:	49 89 28             	mov    %rbp,(%r8)
  706760:	41 c6 44 24 20 02    	movb   $0x2,0x20(%r12)
  706766:	49 c7 07 00 00 00 00 	movq   $0x0,(%r15)
  70676d:	49 ff 06             	incq   (%r14)
  706770:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  706775:	48 c7 00 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rax)
  70677c:	48 83 c4 18          	add    $0x18,%rsp
  706780:	5b                   	pop    %rbx
  706781:	41 5c                	pop    %r12
  706783:	41 5d                	pop    %r13
  706785:	41 5e                	pop    %r14
  706787:	41 5f                	pop    %r15
  706789:	5d                   	pop    %rbp
  70678a:	c3                   	ret
  70678b:	cc                   	int3
  70678c:	cc                   	int3
  70678d:	cc                   	int3
  70678e:	cc                   	int3
  70678f:	cc                   	int3

0000000000706790 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage>:
  706790:	b0 01                	mov    $0x1,%al
  706792:	48 85 f6             	test   %rsi,%rsi
  706795:	74 01                	je     706798 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x8>
  706797:	c3                   	ret
  706798:	80 7f 20 00          	cmpb   $0x0,0x20(%rdi)
  70679c:	75 f9                	jne    706797 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x7>
  70679e:	55                   	push   %rbp
  70679f:	41 57                	push   %r15
  7067a1:	41 56                	push   %r14
  7067a3:	53                   	push   %rbx
  7067a4:	50                   	push   %rax
  7067a5:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
  7067a9:	b9 01 00 00 00       	mov    $0x1,%ecx
  7067ae:	31 c0                	xor    %eax,%eax
  7067b0:	f0 0f b1 4b 10       	lock cmpxchg %ecx,0x10(%rbx)
  7067b5:	75 70                	jne    706827 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x97>
  7067b7:	4c 8b 35 02 ac 37 00 	mov    0x37ac02(%rip),%r14        # a813c0 <_DYNAMIC+0x770>
  7067be:	49 8b 06             	mov    (%r14),%rax
  7067c1:	48 d1 e0             	shl    $1,%rax
  7067c4:	48 85 c0             	test   %rax,%rax
  7067c7:	75 76                	jne    70683f <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0xaf>
  7067c9:	31 c9                	xor    %ecx,%ecx
  7067cb:	48 ba ff ff ff ff ff 	movabs $0x7fffffffffffffff,%rdx
  7067d2:	ff ff 7f 
  7067d5:	0f b6 43 14          	movzbl 0x14(%rbx),%eax
  7067d9:	b0 01                	mov    $0x1,%al
  7067db:	80 7b 48 01          	cmpb   $0x1,0x48(%rbx)
  7067df:	75 25                	jne    706806 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x76>
  7067e1:	4c 8b 43 38          	mov    0x38(%rbx),%r8
  7067e5:	4d 85 c0             	test   %r8,%r8
  7067e8:	74 1c                	je     706806 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x76>
  7067ea:	48 8b 77 18          	mov    0x18(%rdi),%rsi
  7067ee:	b0 02                	mov    $0x2,%al
  7067f0:	4c 39 c6             	cmp    %r8,%rsi
  7067f3:	74 11                	je     706806 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x76>
  7067f5:	b0 01                	mov    $0x1,%al
  7067f7:	48 3b 73 30          	cmp    0x30(%rbx),%rsi
  7067fb:	73 09                	jae    706806 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x76>
  7067fd:	48 ff c6             	inc    %rsi
  706800:	48 89 77 18          	mov    %rsi,0x18(%rdi)
  706804:	31 c0                	xor    %eax,%eax
  706806:	84 c9                	test   %cl,%cl
  706808:	75 08                	jne    706812 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x82>
  70680a:	49 8b 0e             	mov    (%r14),%rcx
  70680d:	48 85 d1             	test   %rdx,%rcx
  706810:	75 56                	jne    706868 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0xd8>
  706812:	31 c9                	xor    %ecx,%ecx
  706814:	87 4b 10             	xchg   %ecx,0x10(%rbx)
  706817:	83 f9 02             	cmp    $0x2,%ecx
  70681a:	74 39                	je     706855 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0xc5>
  70681c:	48 83 c4 08          	add    $0x8,%rsp
  706820:	5b                   	pop    %rbx
  706821:	41 5e                	pop    %r14
  706823:	41 5f                	pop    %r15
  706825:	5d                   	pop    %rbp
  706826:	c3                   	ret
  706827:	48 8d 43 10          	lea    0x10(%rbx),%rax
  70682b:	49 89 fe             	mov    %rdi,%r14
  70682e:	48 89 c7             	mov    %rax,%rdi
  706831:	ff 15 a1 ab 37 00    	call   *0x37aba1(%rip)        # a813d8 <_DYNAMIC+0x788>
  706837:	4c 89 f7             	mov    %r14,%rdi
  70683a:	e9 78 ff ff ff       	jmp    7067b7 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x27>
  70683f:	49 89 ff             	mov    %rdi,%r15
  706842:	ff 15 88 ab 37 00    	call   *0x37ab88(%rip)        # a813d0 <_DYNAMIC+0x780>
  706848:	4c 89 ff             	mov    %r15,%rdi
  70684b:	89 c1                	mov    %eax,%ecx
  70684d:	80 f1 01             	xor    $0x1,%cl
  706850:	e9 76 ff ff ff       	jmp    7067cb <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x3b>
  706855:	48 83 c3 10          	add    $0x10,%rbx
  706859:	48 89 df             	mov    %rbx,%rdi
  70685c:	89 c3                	mov    %eax,%ebx
  70685e:	ff 15 64 ab 37 00    	call   *0x37ab64(%rip)        # a813c8 <_DYNAMIC+0x778>
  706864:	89 d8                	mov    %ebx,%eax
  706866:	eb b4                	jmp    70681c <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x8c>
  706868:	89 c5                	mov    %eax,%ebp
  70686a:	ff 15 60 ab 37 00    	call   *0x37ab60(%rip)        # a813d0 <_DYNAMIC+0x780>
  706870:	89 c1                	mov    %eax,%ecx
  706872:	89 e8                	mov    %ebp,%eax
  706874:	84 c9                	test   %cl,%cl
  706876:	75 9a                	jne    706812 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x82>
  706878:	c6 43 14 01          	movb   $0x1,0x14(%rbx)
  70687c:	eb 94                	jmp    706812 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage+0x82>
  70687e:	cc                   	int3
  70687f:	cc                   	int3

00000000007149b0 <inbox_storage_control::clone_drop>:
  7149b0:	41 56                	push   %r14
  7149b2:	53                   	push   %rbx
  7149b3:	50                   	push   %rax
  7149b4:	e8 d7 11 ff ff       	call   705b90 <<gpui::remote::Remote<u64> as core::clone::Clone>::clone>
  7149b9:	49 89 c6             	mov    %rax,%r14
  7149bc:	48 89 04 24          	mov    %rax,(%rsp)
  7149c0:	48 89 e7             	mov    %rsp,%rdi
  7149c3:	e8 68 13 ff ff       	call   705d30 <<gpui::remote::Remote<u64> as core::ops::drop::Drop>::drop>
  7149c8:	f0 49 ff 0e          	lock decq (%r14)
  7149cc:	75 08                	jne    7149d6 <inbox_storage_control::clone_drop+0x26>
  7149ce:	48 89 e7             	mov    %rsp,%rdi
  7149d1:	e8 6a 11 ff ff       	call   705b40 <<alloc::sync::Arc<gpui::remote::Shared<u64>>>::drop_slow>
  7149d6:	48 83 c4 08          	add    $0x8,%rsp
  7149da:	5b                   	pop    %rbx
  7149db:	41 5e                	pop    %r14
  7149dd:	c3                   	ret
  7149de:	48 89 c3             	mov    %rax,%rbx
  7149e1:	f0 49 ff 0e          	lock decq (%r14)
  7149e5:	75 08                	jne    7149ef <inbox_storage_control::clone_drop+0x3f>
  7149e7:	48 89 e7             	mov    %rsp,%rdi
  7149ea:	e8 51 11 ff ff       	call   705b40 <<alloc::sync::Arc<gpui::remote::Shared<u64>>>::drop_slow>
  7149ef:	48 89 df             	mov    %rbx,%rdi
  7149f2:	e8 09 1f 34 00       	call   a56900 <_Unwind_Resume@plt>
  7149f7:	ff 15 eb c4 36 00    	call   *0x36c4eb(%rip)        # a80ee8 <_DYNAMIC+0x298>
  7149fd:	cc                   	int3
  7149fe:	cc                   	int3
  7149ff:	cc                   	int3

00000000007150f0 <inbox_storage_control::send>:
  7150f0:	50                   	push   %rax
  7150f1:	e8 ca 08 ff ff       	call   7059c0 <<gpui::remote::Remote<u64>>::try_send>
  7150f6:	48 83 f8 02          	cmp    $0x2,%rax
  7150fa:	0f 94 c0             	sete   %al
  7150fd:	59                   	pop    %rcx
  7150fe:	c3                   	ret
  7150ff:	cc                   	int3

0000000000715100 <inbox_storage_control::deliver>:
  715100:	53                   	push   %rbx
  715101:	48 81 ec 00 01 00 00 	sub    $0x100,%rsp
  715108:	48 89 fb             	mov    %rdi,%rbx
  71510b:	48 89 e7             	mov    %rsp,%rdi
  71510e:	e8 dd e0 fc ff       	call   6e31f0 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready>
  715113:	83 3c 24 ff          	cmpl   $0xffffffff,(%rsp)
  715117:	75 38                	jne    715151 <inbox_storage_control::deliver+0x51>
  715119:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  71511e:	48 89 43 40          	mov    %rax,0x40(%rbx)
  715122:	0f 10 44 24 08       	movups 0x8(%rsp),%xmm0
  715127:	0f 10 4c 24 18       	movups 0x18(%rsp),%xmm1
  71512c:	0f 10 54 24 28       	movups 0x28(%rsp),%xmm2
  715131:	0f 10 5c 24 38       	movups 0x38(%rsp),%xmm3
  715136:	0f 11 5b 30          	movups %xmm3,0x30(%rbx)
  71513a:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
  71513e:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
  715142:	0f 11 03             	movups %xmm0,(%rbx)
  715145:	48 89 d8             	mov    %rbx,%rax
  715148:	48 81 c4 00 01 00 00 	add    $0x100,%rsp
  71514f:	5b                   	pop    %rbx
  715150:	c3                   	ret
  715151:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
  715156:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  71515d:	00 
  71515e:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  715163:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
  71516a:	00 
  71516b:	0f 10 44 24 50       	movups 0x50(%rsp),%xmm0
  715170:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  715177:	00 
  715178:	0f 10 44 24 40       	movups 0x40(%rsp),%xmm0
  71517d:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  715184:	00 
  715185:	0f 10 04 24          	movups (%rsp),%xmm0
  715189:	0f 10 4c 24 10       	movups 0x10(%rsp),%xmm1
  71518e:	0f 10 54 24 20       	movups 0x20(%rsp),%xmm2
  715193:	0f 10 5c 24 30       	movups 0x30(%rsp),%xmm3
  715198:	0f 29 9c 24 b0 00 00 	movaps %xmm3,0xb0(%rsp)
  71519f:	00 
  7151a0:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
  7151a7:	00 
  7151a8:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
  7151af:	00 
  7151b0:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  7151b7:	00 
  7151b8:	48 8d 3d ae 5d 94 ff 	lea    -0x6ba252(%rip),%rdi        # 5af6d <anon.7788376359c7d3ee46b8d62b33bf1a87.10.llvm.13353374387775562354+0x28f>
  7151bf:	48 8d 0d 7a 44 34 00 	lea    0x34447a(%rip),%rcx        # a59640 <anon.7788376359c7d3ee46b8d62b33bf1a87.13.llvm.13353374387775562354+0x248>
  7151c6:	4c 8d 05 43 44 34 00 	lea    0x344443(%rip),%r8        # a59610 <anon.7788376359c7d3ee46b8d62b33bf1a87.13.llvm.13353374387775562354+0x218>
  7151cd:	48 8d 94 24 80 00 00 	lea    0x80(%rsp),%rdx
  7151d4:	00 
  7151d5:	be 2b 00 00 00       	mov    $0x2b,%esi
  7151da:	ff 15 e0 bd 36 00    	call   *0x36bde0(%rip)        # a80fc0 <_DYNAMIC+0x370>
  7151e0:	0f 0b                	ud2
  7151e2:	48 89 c3             	mov    %rax,%rbx
  7151e5:	48 8d bc 24 c8 00 00 	lea    0xc8(%rsp),%rdi
  7151ec:	00 
  7151ed:	e8 8e ed ff ff       	call   713f80 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7151f2:	48 89 df             	mov    %rbx,%rdi
  7151f5:	e8 06 17 34 00       	call   a56900 <_Unwind_Resume@plt>
  7151fa:	cc                   	int3
  7151fb:	cc                   	int3
  7151fc:	cc                   	int3
  7151fd:	cc                   	int3
  7151fe:	cc                   	int3
  7151ff:	cc                   	int3

0000000000715200 <inbox_storage_control::ordinary>:
  715200:	53                   	push   %rbx
  715201:	48 81 ec 80 00 00 00 	sub    $0x80,%rsp
  715208:	48 89 f8             	mov    %rdi,%rax
  71520b:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  715210:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
  715215:	48 8d 54 24 08       	lea    0x8(%rsp),%rdx
  71521a:	48 89 c6             	mov    %rax,%rsi
  71521d:	e8 ce 6e fc ff       	call   6dc0f0 <<gpui::runtime::Win<inbox_storage_control::Page>>::update::<inbox_storage_control::ordinary::{closure#0}>>
  715222:	83 7c 24 48 fe       	cmpl   $0xfffffffe,0x48(%rsp)
  715227:	75 09                	jne    715232 <inbox_storage_control::ordinary+0x32>
  715229:	48 81 c4 80 00 00 00 	add    $0x80,%rsp
  715230:	5b                   	pop    %rbx
  715231:	c3                   	ret
  715232:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  715237:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  71523c:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  715241:	0f 10 4c 24 58       	movups 0x58(%rsp),%xmm1
  715246:	0f 10 54 24 68       	movups 0x68(%rsp),%xmm2
  71524b:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
  715250:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
  715255:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  71525a:	48 8d 3d 0c 5d 94 ff 	lea    -0x6ba2f4(%rip),%rdi        # 5af6d <anon.7788376359c7d3ee46b8d62b33bf1a87.10.llvm.13353374387775562354+0x28f>
  715261:	48 8d 0d f8 43 34 00 	lea    0x3443f8(%rip),%rcx        # a59660 <anon.7788376359c7d3ee46b8d62b33bf1a87.13.llvm.13353374387775562354+0x268>
  715268:	4c 8d 05 b9 43 34 00 	lea    0x3443b9(%rip),%r8        # a59628 <anon.7788376359c7d3ee46b8d62b33bf1a87.13.llvm.13353374387775562354+0x230>
  71526f:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  715274:	be 2b 00 00 00       	mov    $0x2b,%esi
  715279:	ff 15 41 bd 36 00    	call   *0x36bd41(%rip)        # a80fc0 <_DYNAMIC+0x370>
  71527f:	0f 0b                	ud2
  715281:	48 89 c3             	mov    %rax,%rbx
  715284:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  715289:	e8 f2 ec ff ff       	call   713f80 <core::ptr::drop_glue::<gpui::runtime::Error>>
  71528e:	48 89 df             	mov    %rbx,%rdi
  715291:	e8 6a 16 34 00       	call   a56900 <_Unwind_Resume@plt>
  715296:	cc                   	int3
  715297:	cc                   	int3
  715298:	cc                   	int3
  715299:	cc                   	int3
  71529a:	cc                   	int3
  71529b:	cc                   	int3
  71529c:	cc                   	int3
  71529d:	cc                   	int3
  71529e:	cc                   	int3
  71529f:	cc                   	int3

00000000007152a0 <inbox_storage_control::transport>:
  7152a0:	e9 eb 05 ff ff       	jmp    705890 <<gpui::remote::Remote<u64>>::bounded>
  7152a5:	cc                   	int3
  7152a6:	cc                   	int3
  7152a7:	cc                   	int3
  7152a8:	cc                   	int3
  7152a9:	cc                   	int3
  7152aa:	cc                   	int3
  7152ab:	cc                   	int3
  7152ac:	cc                   	int3
  7152ad:	cc                   	int3
  7152ae:	cc                   	int3
  7152af:	cc                   	int3

