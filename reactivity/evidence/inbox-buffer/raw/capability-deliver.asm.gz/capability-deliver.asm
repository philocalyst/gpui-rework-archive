00000000006e2560 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready>:
  6e2560:	55                   	push   %rbp
  6e2561:	41 57                	push   %r15
  6e2563:	41 56                	push   %r14
  6e2565:	41 55                	push   %r13
  6e2567:	41 54                	push   %r12
  6e2569:	53                   	push   %rbx
  6e256a:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
  6e2571:	48 89 fb             	mov    %rdi,%rbx
  6e2574:	4c 8b 36             	mov    (%rsi),%r14
  6e2577:	4d 85 f6             	test   %r14,%r14
  6e257a:	74 56                	je     6e25d2 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x72>
  6e257c:	49 89 f4             	mov    %rsi,%r12
  6e257f:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
  6e2583:	41 80 be 26 07 00 00 	cmpb   $0x0,0x726(%r14)
  6e258a:	00 
  6e258b:	74 59                	je     6e25e6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x86>
  6e258d:	48 c7 44 24 10 0e 00 	movq   $0xe,0x10(%rsp)
  6e2594:	00 00 
  6e2596:	e8 a5 16 02 00       	call   703c40 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e259b:	41 0f 10 86 68 06 00 	movups 0x668(%r14),%xmm0
  6e25a2:	00 
  6e25a3:	41 0f b6 86 24 07 00 	movzbl 0x724(%r14),%eax
  6e25aa:	00 
  6e25ab:	49 83 be 88 06 00 00 	cmpq   $0x0,0x688(%r14)
  6e25b2:	00 
  6e25b3:	74 16                	je     6e25cb <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6b>
  6e25b5:	84 c0                	test   %al,%al
  6e25b7:	0f 84 a3 00 00 00    	je     6e2660 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x100>
  6e25bd:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6e25c4:	ff 
  6e25c5:	0f 85 95 00 00 00    	jne    6e2660 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x100>
  6e25cb:	31 c9                	xor    %ecx,%ecx
  6e25cd:	e9 9a 00 00 00       	jmp    6e266c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x10c>
  6e25d2:	48 c7 03 02 00 00 00 	movq   $0x2,(%rbx)
  6e25d9:	48 c7 43 48 0d 00 00 	movq   $0xd,0x48(%rbx)
  6e25e0:	00 
  6e25e1:	e9 88 06 00 00       	jmp    6e2c6e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x70e>
  6e25e6:	49 c7 86 10 07 00 00 	movq   $0x0,0x710(%r14)
  6e25ed:	00 00 00 00 
  6e25f1:	48 85 d2             	test   %rdx,%rdx
  6e25f4:	74 0e                	je     6e2604 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa4>
  6e25f6:	49 83 be 68 06 00 00 	cmpq   $0xffffffffffffffff,0x668(%r14)
  6e25fd:	ff 
  6e25fe:	0f 84 b5 00 00 00    	je     6e26b9 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x159>
  6e2604:	45 31 ff             	xor    %r15d,%r15d
  6e2607:	41 80 7c 24 28 01    	cmpb   $0x1,0x28(%r12)
  6e260d:	41 0f 94 c7          	sete   %r15b
  6e2611:	4d 03 7c 24 20       	add    0x20(%r12),%r15
  6e2616:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
  6e261b:	b1 01                	mov    $0x1,%cl
  6e261d:	31 c0                	xor    %eax,%eax
  6e261f:	49 39 d7             	cmp    %rdx,%r15
  6e2622:	48 89 bc 24 e8 00 00 	mov    %rdi,0xe8(%rsp)
  6e2629:	00 
  6e262a:	73 2d                	jae    6e2659 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xf9>
  6e262c:	49 89 d5             	mov    %rdx,%r13
  6e262f:	e8 0c 14 02 00       	call   703a40 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage>
  6e2634:	3c 02                	cmp    $0x2,%al
  6e2636:	0f 84 ae 00 00 00    	je     6e26ea <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x18a>
  6e263c:	0f b6 c0             	movzbl %al,%eax
  6e263f:	83 f8 01             	cmp    $0x1,%eax
  6e2642:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
  6e2647:	0f 85 be 00 00 00    	jne    6e270b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1ab>
  6e264d:	31 ed                	xor    %ebp,%ebp
  6e264f:	31 c0                	xor    %eax,%eax
  6e2651:	4c 89 ea             	mov    %r13,%rdx
  6e2654:	e9 9d 00 00 00       	jmp    6e26f6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x196>
  6e2659:	31 ed                	xor    %ebp,%ebp
  6e265b:	e9 39 01 00 00       	jmp    6e2799 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x239>
  6e2660:	49 8b 96 98 06 00 00 	mov    0x698(%r14),%rdx
  6e2667:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e266c:	49 8b b6 10 07 00 00 	mov    0x710(%r14),%rsi
  6e2673:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  6e2678:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
  6e267c:	0f 10 4c 24 10       	movups 0x10(%rsp),%xmm1
  6e2681:	0f 10 54 24 20       	movups 0x20(%rsp),%xmm2
  6e2686:	0f 10 5c 24 30       	movups 0x30(%rsp),%xmm3
  6e268b:	0f 11 5b 68          	movups %xmm3,0x68(%rbx)
  6e268f:	0f 11 53 58          	movups %xmm2,0x58(%rbx)
  6e2693:	0f 11 4b 48          	movups %xmm1,0x48(%rbx)
  6e2697:	48 89 0b             	mov    %rcx,(%rbx)
  6e269a:	48 89 53 08          	mov    %rdx,0x8(%rbx)
  6e269e:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6e26a2:	48 89 73 20          	mov    %rsi,0x20(%rbx)
  6e26a6:	88 43 28             	mov    %al,0x28(%rbx)
  6e26a9:	0f 57 c0             	xorps  %xmm0,%xmm0
  6e26ac:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  6e26b0:	c6 43 40 00          	movb   $0x0,0x40(%rbx)
  6e26b4:	e9 b5 05 00 00       	jmp    6e2c6e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x70e>
  6e26b9:	e8 82 15 02 00       	call   703c40 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e26be:	41 0f 10 86 68 06 00 	movups 0x668(%r14),%xmm0
  6e26c5:	00 
  6e26c6:	41 0f b6 86 24 07 00 	movzbl 0x724(%r14),%eax
  6e26cd:	00 
  6e26ce:	49 83 be 88 06 00 00 	cmpq   $0x0,0x688(%r14)
  6e26d5:	00 
  6e26d6:	74 0e                	je     6e26e6 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x186>
  6e26d8:	84 c0                	test   %al,%al
  6e26da:	74 74                	je     6e2750 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1f0>
  6e26dc:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6e26e3:	ff 
  6e26e4:	75 6a                	jne    6e2750 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1f0>
  6e26e6:	31 c9                	xor    %ecx,%ecx
  6e26e8:	eb 72                	jmp    6e275c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1fc>
  6e26ea:	b0 01                	mov    $0x1,%al
  6e26ec:	31 ed                	xor    %ebp,%ebp
  6e26ee:	4c 89 ea             	mov    %r13,%rdx
  6e26f1:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
  6e26f6:	49 39 d7             	cmp    %rdx,%r15
  6e26f9:	0f b6 c0             	movzbl %al,%eax
  6e26fc:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e2701:	0f 42 c8             	cmovb  %eax,%ecx
  6e2704:	31 f6                	xor    %esi,%esi
  6e2706:	e9 8c 00 00 00       	jmp    6e2797 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x237>
  6e270b:	4c 89 ea             	mov    %r13,%rdx
  6e270e:	49 8d 47 01          	lea    0x1(%r15),%rax
  6e2712:	bd 01 00 00 00       	mov    $0x1,%ebp
  6e2717:	4c 39 e8             	cmp    %r13,%rax
  6e271a:	73 71                	jae    6e278d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x22d>
  6e271c:	0f 1f 40 00          	nopl   0x0(%rax)
  6e2720:	31 f6                	xor    %esi,%esi
  6e2722:	e8 19 13 02 00       	call   703a40 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::stage>
  6e2727:	84 c0                	test   %al,%al
  6e2729:	0f 85 9f 05 00 00    	jne    6e2cce <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x76e>
  6e272f:	49 8d 04 2f          	lea    (%r15,%rbp,1),%rax
  6e2733:	48 ff c0             	inc    %rax
  6e2736:	48 ff c5             	inc    %rbp
  6e2739:	4c 39 e8             	cmp    %r13,%rax
  6e273c:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
  6e2741:	72 dd                	jb     6e2720 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x1c0>
  6e2743:	4c 89 ea             	mov    %r13,%rdx
  6e2746:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  6e274c:	31 f6                	xor    %esi,%esi
  6e274e:	eb 45                	jmp    6e2795 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x235>
  6e2750:	49 8b 96 98 06 00 00 	mov    0x698(%r14),%rdx
  6e2757:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e275c:	49 8b b6 10 07 00 00 	mov    0x710(%r14),%rsi
  6e2763:	48 89 0b             	mov    %rcx,(%rbx)
  6e2766:	48 89 53 08          	mov    %rdx,0x8(%rbx)
  6e276a:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  6e276e:	48 89 73 20          	mov    %rsi,0x20(%rbx)
  6e2772:	88 43 28             	mov    %al,0x28(%rbx)
  6e2775:	0f 57 c0             	xorps  %xmm0,%xmm0
  6e2778:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  6e277c:	c6 43 40 00          	movb   $0x0,0x40(%rbx)
  6e2780:	48 c7 43 48 20 00 00 	movq   $0x20,0x48(%rbx)
  6e2787:	00 
  6e2788:	e9 e1 04 00 00       	jmp    6e2c6e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x70e>
  6e278d:	31 f6                	xor    %esi,%esi
  6e278f:	41 bf 01 00 00 00    	mov    $0x1,%r15d
  6e2795:	b1 01                	mov    $0x1,%cl
  6e2797:	31 c0                	xor    %eax,%eax
  6e2799:	48 89 37             	mov    %rsi,(%rdi)
  6e279c:	48 85 d2             	test   %rdx,%rdx
  6e279f:	89 8c 24 9c 00 00 00 	mov    %ecx,0x9c(%rsp)
  6e27a6:	44 0f b6 e9          	movzbl %cl,%r13d
  6e27aa:	44 0f 44 e8          	cmove  %eax,%r13d
  6e27ae:	74 34                	je     6e27e4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x284>
  6e27b0:	4d 85 ff             	test   %r15,%r15
  6e27b3:	74 2f                	je     6e27e4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x284>
  6e27b5:	41 80 be 26 07 00 00 	cmpb   $0x1,0x726(%r14)
  6e27bc:	01 
  6e27bd:	75 5c                	jne    6e281b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2bb>
  6e27bf:	48 c7 44 24 50 0e 00 	movq   $0xe,0x50(%rsp)
  6e27c6:	00 00 
  6e27c8:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6e27cf:	00 00 
  6e27d1:	41 80 be 26 07 00 00 	cmpb   $0x0,0x726(%r14)
  6e27d8:	00 
  6e27d9:	0f 84 5c 03 00 00    	je     6e2b3b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5db>
  6e27df:	e9 61 03 00 00       	jmp    6e2b45 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5e5>
  6e27e4:	41 0f 10 86 68 06 00 	movups 0x668(%r14),%xmm0
  6e27eb:	00 
  6e27ec:	41 0f b6 86 24 07 00 	movzbl 0x724(%r14),%eax
  6e27f3:	00 
  6e27f4:	49 83 be 88 06 00 00 	cmpq   $0x0,0x688(%r14)
  6e27fb:	00 
  6e27fc:	74 16                	je     6e2814 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x2b4>
  6e27fe:	84 c0                	test   %al,%al
  6e2800:	0f 84 60 01 00 00    	je     6e2966 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x406>
  6e2806:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6e280d:	ff 
  6e280e:	0f 85 52 01 00 00    	jne    6e2966 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x406>
  6e2814:	31 c9                	xor    %ecx,%ecx
  6e2816:	e9 57 01 00 00       	jmp    6e2972 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x412>
  6e281b:	4d 8b be 68 06 00 00 	mov    0x668(%r14),%r15
  6e2822:	49 ff c7             	inc    %r15
  6e2825:	0f 84 ba 07 00 00    	je     6e2fe5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa85>
  6e282b:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
  6e2832:	00 00 00 00 00 
  6e2837:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  6e283e:	00 00 00 00 00 
  6e2843:	48 89 94 24 f0 00 00 	mov    %rdx,0xf0(%rsp)
  6e284a:	00 
  6e284b:	49 8d 96 c0 05 00 00 	lea    0x5c0(%r14),%rdx
  6e2852:	49 8d 8e 28 02 00 00 	lea    0x228(%r14),%rcx
  6e2859:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
  6e2860:	00 
  6e2861:	48 89 04 24          	mov    %rax,(%rsp)
  6e2865:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6e286a:	4c 8d 84 24 90 00 00 	lea    0x90(%rsp),%r8
  6e2871:	00 
  6e2872:	4c 8d 8c 24 e0 00 00 	lea    0xe0(%rsp),%r9
  6e2879:	00 
  6e287a:	49 8d 74 24 08       	lea    0x8(%r12),%rsi
  6e287f:	e8 cc 0f 02 00       	call   703850 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::apply>
  6e2884:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e2889:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  6e288e:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
  6e2893:	0f 10 44 24 20       	movups 0x20(%rsp),%xmm0
  6e2898:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  6e289d:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
  6e28a2:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  6e28a9:	00 
  6e28aa:	48 89 b4 24 a8 00 00 	mov    %rsi,0xa8(%rsp)
  6e28b1:	00 
  6e28b2:	0f 11 84 24 b0 00 00 	movups %xmm0,0xb0(%rsp)
  6e28b9:	00 
  6e28ba:	0f 11 8c 24 c0 00 00 	movups %xmm1,0xc0(%rsp)
  6e28c1:	00 
  6e28c2:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  6e28c9:	00 
  6e28ca:	48 83 f8 fd          	cmp    $0xfffffffffffffffd,%rax
  6e28ce:	0f 84 d4 00 00 00    	je     6e29a8 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x448>
  6e28d4:	48 8d 8c 24 b0 00 00 	lea    0xb0(%rsp),%rcx
  6e28db:	00 
  6e28dc:	48 8b 51 20          	mov    0x20(%rcx),%rdx
  6e28e0:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
  6e28e7:	00 
  6e28e8:	0f 10 01             	movups (%rcx),%xmm0
  6e28eb:	0f 10 49 10          	movups 0x10(%rcx),%xmm1
  6e28ef:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  6e28f6:	00 
  6e28f7:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  6e28fe:	00 
  6e28ff:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  6e2906:	00 00 00 00 00 
  6e290b:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  6e2912:	00 
  6e2913:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  6e2918:	48 85 d2             	test   %rdx,%rdx
  6e291b:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
  6e2920:	74 0e                	je     6e2930 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x3d0>
  6e2922:	4d 89 be 68 06 00 00 	mov    %r15,0x668(%r14)
  6e2929:	49 ff 86 b8 06 00 00 	incq   0x6b8(%r14)
  6e2930:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6e2934:	0f 84 d3 00 00 00    	je     6e2a0d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x4ad>
  6e293a:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
  6e2941:	00 
  6e2942:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  6e2947:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  6e294e:	00 
  6e294f:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
  6e2956:	00 
  6e2957:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
  6e295c:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  6e2961:	e9 a7 00 00 00       	jmp    6e2a0d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x4ad>
  6e2966:	49 8b 96 98 06 00 00 	mov    0x698(%r14),%rdx
  6e296d:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e2972:	49 8b b6 10 07 00 00 	mov    0x710(%r14),%rsi
  6e2979:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
  6e297d:	48 89 53 10          	mov    %rdx,0x10(%rbx)
  6e2981:	0f 11 43 18          	movups %xmm0,0x18(%rbx)
  6e2985:	48 89 73 28          	mov    %rsi,0x28(%rbx)
  6e2989:	88 43 30             	mov    %al,0x30(%rbx)
  6e298c:	48 89 6b 38          	mov    %rbp,0x38(%rbx)
  6e2990:	48 c7 43 40 00 00 00 	movq   $0x0,0x40(%rbx)
  6e2997:	00 
  6e2998:	c6 43 48 00          	movb   $0x0,0x48(%rbx)
  6e299c:	48 c7 03 ff ff ff ff 	movq   $0xffffffffffffffff,(%rbx)
  6e29a3:	e9 c6 02 00 00       	jmp    6e2c6e <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x70e>
  6e29a8:	49 89 d7             	mov    %rdx,%r15
  6e29ab:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
  6e29b0:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  6e29b7:	00 
  6e29b8:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  6e29bd:	4c 89 f7             	mov    %r14,%rdi
  6e29c0:	e8 7b 1c 01 00       	call   6f4640 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::poison>
  6e29c5:	48 c7 44 24 50 0f 00 	movq   $0xf,0x50(%rsp)
  6e29cc:	00 00 
  6e29ce:	49 8b 07             	mov    (%r15),%rax
  6e29d1:	48 85 c0             	test   %rax,%rax
  6e29d4:	74 07                	je     6e29dd <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x47d>
  6e29d6:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6e29db:	ff d0                	call   *%rax
  6e29dd:	49 8b 77 08          	mov    0x8(%r15),%rsi
  6e29e1:	48 85 f6             	test   %rsi,%rsi
  6e29e4:	74 0f                	je     6e29f5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x495>
  6e29e6:	49 8b 57 10          	mov    0x10(%r15),%rdx
  6e29ea:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6e29ef:	ff 15 6b a5 39 00    	call   *0x39a56b(%rip)        # a7cf60 <_DYNAMIC+0x248>
  6e29f5:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
  6e29fa:	41 80 be 26 07 00 00 	cmpb   $0x0,0x726(%r14)
  6e2a01:	00 
  6e2a02:	0f 84 33 01 00 00    	je     6e2b3b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5db>
  6e2a08:	e9 38 01 00 00       	jmp    6e2b45 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5e5>
  6e2a0d:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  6e2a12:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  6e2a17:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
  6e2a1c:	0f 11 84 24 08 01 00 	movups %xmm0,0x108(%rsp)
  6e2a23:	00 
  6e2a24:	0f 11 8c 24 18 01 00 	movups %xmm1,0x118(%rsp)
  6e2a2b:	00 
  6e2a2c:	48 89 8c 24 28 01 00 	mov    %rcx,0x128(%rsp)
  6e2a33:	00 
  6e2a34:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  6e2a3b:	00 
  6e2a3c:	48 89 b4 24 00 01 00 	mov    %rsi,0x100(%rsp)
  6e2a43:	00 
  6e2a44:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6e2a48:	0f 84 35 02 00 00    	je     6e2c83 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x723>
  6e2a4e:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
  6e2a55:	00 
  6e2a56:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6e2a5b:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
  6e2a62:	00 
  6e2a63:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  6e2a6a:	00 
  6e2a6b:	0f 10 84 24 08 01 00 	movups 0x108(%rsp),%xmm0
  6e2a72:	00 
  6e2a73:	0f 10 8c 24 18 01 00 	movups 0x118(%rsp),%xmm1
  6e2a7a:	00 
  6e2a7b:	0f 29 4c 24 30       	movaps %xmm1,0x30(%rsp)
  6e2a80:	0f 29 44 24 20       	movaps %xmm0,0x20(%rsp)
  6e2a85:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  6e2a8a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  6e2a8f:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
  6e2a95:	74 65                	je     6e2afc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x59c>
  6e2a97:	49 8b 86 18 06 00 00 	mov    0x618(%r14),%rax
  6e2a9e:	48 85 c0             	test   %rax,%rax
  6e2aa1:	74 41                	je     6e2ae4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x584>
  6e2aa3:	48 8b 80 e0 00 00 00 	mov    0xe0(%rax),%rax
  6e2aaa:	48 85 c0             	test   %rax,%rax
  6e2aad:	74 35                	je     6e2ae4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x584>
  6e2aaf:	48 8b 78 10          	mov    0x10(%rax),%rdi
  6e2ab3:	0f b6 48 24          	movzbl 0x24(%rax),%ecx
  6e2ab7:	c6 40 24 02          	movb   $0x2,0x24(%rax)
  6e2abb:	80 f9 02             	cmp    $0x2,%cl
  6e2abe:	74 24                	je     6e2ae4 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x584>
  6e2ac0:	f6 07 01             	testb  $0x1,(%rdi)
  6e2ac3:	75 17                	jne    6e2adc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x57c>
  6e2ac5:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e2ac9:	a8 01                	test   $0x1,%al
  6e2acb:	75 0f                	jne    6e2adc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x57c>
  6e2acd:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6e2ad1:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e2ad6:	0f 84 20 05 00 00    	je     6e2ffc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa9c>
  6e2adc:	41 c6 86 23 07 00 00 	movb   $0x1,0x723(%r14)
  6e2ae3:	01 
  6e2ae4:	41 c6 86 22 07 00 00 	movb   $0x0,0x722(%r14)
  6e2aeb:	00 
  6e2aec:	49 c7 86 f0 05 00 00 	movq   $0x0,0x5f0(%r14)
  6e2af3:	00 00 00 00 
  6e2af7:	49 8d 7c 24 08       	lea    0x8(%r12),%rdi
  6e2afc:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6e2b01:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6e2b08:	00 
  6e2b09:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e2b0e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  6e2b13:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
  6e2b18:	0f 28 4c 24 30       	movaps 0x30(%rsp),%xmm1
  6e2b1d:	0f 29 4c 24 70       	movaps %xmm1,0x70(%rsp)
  6e2b22:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  6e2b27:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6e2b2c:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6e2b31:	41 80 be 26 07 00 00 	cmpb   $0x0,0x726(%r14)
  6e2b38:	00 
  6e2b39:	75 0a                	jne    6e2b45 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5e5>
  6e2b3b:	49 83 be 68 06 00 00 	cmpq   $0xffffffffffffffff,0x668(%r14)
  6e2b42:	ff 
  6e2b43:	75 05                	jne    6e2b4a <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5ea>
  6e2b45:	e8 f6 10 02 00       	call   703c40 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e2b4a:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  6e2b4f:	48 83 ff fe          	cmp    $0xfffffffffffffffe,%rdi
  6e2b53:	74 1f                	je     6e2b74 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x614>
  6e2b55:	31 c0                	xor    %eax,%eax
  6e2b57:	41 80 7c 24 28 01    	cmpb   $0x1,0x28(%r12)
  6e2b5d:	0f 94 c0             	sete   %al
  6e2b60:	48 f7 d8             	neg    %rax
  6e2b63:	49 39 44 24 20       	cmp    %rax,0x20(%r12)
  6e2b68:	41 0f 95 c5          	setne  %r13b
  6e2b6c:	44 0a ac 24 9c 00 00 	or     0x9c(%rsp),%r13b
  6e2b73:	00 
  6e2b74:	45 0f b6 86 26 07 00 	movzbl 0x726(%r14),%r8d
  6e2b7b:	00 
  6e2b7c:	49 8b 86 68 06 00 00 	mov    0x668(%r14),%rax
  6e2b83:	41 80 f0 01          	xor    $0x1,%r8b
  6e2b87:	41 0f b6 8e 24 07 00 	movzbl 0x724(%r14),%ecx
  6e2b8e:	00 
  6e2b8f:	49 83 be 88 06 00 00 	cmpq   $0x0,0x688(%r14)
  6e2b96:	00 
  6e2b97:	74 0e                	je     6e2ba7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x647>
  6e2b99:	84 c9                	test   %cl,%cl
  6e2b9b:	74 0e                	je     6e2bab <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x64b>
  6e2b9d:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6e2ba4:	ff 
  6e2ba5:	75 04                	jne    6e2bab <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x64b>
  6e2ba7:	31 d2                	xor    %edx,%edx
  6e2ba9:	eb 0c                	jmp    6e2bb7 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x657>
  6e2bab:	49 8b b6 98 06 00 00 	mov    0x698(%r14),%rsi
  6e2bb2:	ba 01 00 00 00       	mov    $0x1,%edx
  6e2bb7:	4d 8b 8e 70 06 00 00 	mov    0x670(%r14),%r9
  6e2bbe:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  6e2bc2:	41 0f 95 c2          	setne  %r10b
  6e2bc6:	45 20 c5             	and    %r8b,%r13b
  6e2bc9:	45 20 d5             	and    %r10b,%r13b
  6e2bcc:	4d 8b 86 10 07 00 00 	mov    0x710(%r14),%r8
  6e2bd3:	48 83 ff fe          	cmp    $0xfffffffffffffffe,%rdi
  6e2bd7:	75 29                	jne    6e2c02 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6a2>
  6e2bd9:	4c 89 43 28          	mov    %r8,0x28(%rbx)
  6e2bdd:	bf 48 00 00 00       	mov    $0x48,%edi
  6e2be2:	41 ba 40 00 00 00    	mov    $0x40,%r10d
  6e2be8:	41 bb 30 00 00 00    	mov    $0x30,%r11d
  6e2bee:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
  6e2bf3:	49 89 d7             	mov    %rdx,%r15
  6e2bf6:	4d 89 c8             	mov    %r9,%r8
  6e2bf9:	48 c7 c2 ff ff ff ff 	mov    $0xffffffffffffffff,%rdx
  6e2c00:	eb 49                	jmp    6e2c4b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x6eb>
  6e2c02:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  6e2c09:	00 
  6e2c0a:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
  6e2c0e:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  6e2c13:	0f 28 4c 24 60       	movaps 0x60(%rsp),%xmm1
  6e2c18:	0f 28 54 24 70       	movaps 0x70(%rsp),%xmm2
  6e2c1d:	0f 11 53 68          	movups %xmm2,0x68(%rbx)
  6e2c21:	0f 11 4b 58          	movups %xmm1,0x58(%rbx)
  6e2c25:	0f 11 43 48          	movups %xmm0,0x48(%rbx)
  6e2c29:	bf 40 00 00 00       	mov    $0x40,%edi
  6e2c2e:	41 ba 30 00 00 00    	mov    $0x30,%r10d
  6e2c34:	41 bb 28 00 00 00    	mov    $0x28,%r11d
  6e2c3a:	49 89 ee             	mov    %rbp,%r14
  6e2c3d:	49 89 f7             	mov    %rsi,%r15
  6e2c40:	48 89 c6             	mov    %rax,%rsi
  6e2c43:	4c 89 c8             	mov    %r9,%rax
  6e2c46:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
  6e2c4b:	42 88 0c 1b          	mov    %cl,(%rbx,%r11,1)
  6e2c4f:	4e 89 34 13          	mov    %r14,(%rbx,%r10,1)
  6e2c53:	44 88 2c 3b          	mov    %r13b,(%rbx,%rdi,1)
  6e2c57:	4c 89 7b 08          	mov    %r15,0x8(%rbx)
  6e2c5b:	48 89 73 10          	mov    %rsi,0x10(%rbx)
  6e2c5f:	48 89 43 18          	mov    %rax,0x18(%rbx)
  6e2c63:	4c 89 43 20          	mov    %r8,0x20(%rbx)
  6e2c67:	48 89 6b 38          	mov    %rbp,0x38(%rbx)
  6e2c6b:	48 89 13             	mov    %rdx,(%rbx)
  6e2c6e:	48 89 d8             	mov    %rbx,%rax
  6e2c71:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
  6e2c78:	5b                   	pop    %rbx
  6e2c79:	41 5c                	pop    %r12
  6e2c7b:	41 5d                	pop    %r13
  6e2c7d:	41 5e                	pop    %r14
  6e2c7f:	41 5f                	pop    %r15
  6e2c81:	5d                   	pop    %rbp
  6e2c82:	c3                   	ret
  6e2c83:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
  6e2c89:	74 62                	je     6e2ced <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x78d>
  6e2c8b:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  6e2c92:	00 00 00 00 00 
  6e2c97:	49 ff 86 08 07 00 00 	incq   0x708(%r14)
  6e2c9e:	48 89 fa             	mov    %rdi,%rdx
  6e2ca1:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6e2ca6:	4c 89 f6             	mov    %r14,%rsi
  6e2ca9:	e8 42 f5 ff ff       	call   6e21f0 <<gpui::runtime::RuntimeMut<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::describe_with_changed>
  6e2cae:	83 7c 24 10 fe       	cmpl   $0xfffffffe,0x10(%rsp)
  6e2cb3:	75 6f                	jne    6e2d24 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x7c4>
  6e2cb5:	c6 84 24 a8 00 00 00 	movb   $0x0,0xa8(%rsp)
  6e2cbc:	00 
  6e2cbd:	48 c7 84 24 a0 00 00 	movq   $0xfffffffffffffffe,0xa0(%rsp)
  6e2cc4:	00 fe ff ff ff 
  6e2cc9:	e9 99 00 00 00       	jmp    6e2d67 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x807>
  6e2cce:	0f b6 c0             	movzbl %al,%eax
  6e2cd1:	83 f8 01             	cmp    $0x1,%eax
  6e2cd4:	4c 89 ea             	mov    %r13,%rdx
  6e2cd7:	75 0a                	jne    6e2ce3 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x783>
  6e2cd9:	49 01 ef             	add    %rbp,%r15
  6e2cdc:	31 c0                	xor    %eax,%eax
  6e2cde:	e9 0e fa ff ff       	jmp    6e26f1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x191>
  6e2ce3:	49 01 ef             	add    %rbp,%r15
  6e2ce6:	b0 01                	mov    $0x1,%al
  6e2ce8:	e9 04 fa ff ff       	jmp    6e26f1 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x191>
  6e2ced:	41 0f 10 86 68 06 00 	movups 0x668(%r14),%xmm0
  6e2cf4:	00 
  6e2cf5:	41 0f b6 86 24 07 00 	movzbl 0x724(%r14),%eax
  6e2cfc:	00 
  6e2cfd:	49 83 be 88 06 00 00 	cmpq   $0x0,0x688(%r14)
  6e2d04:	00 
  6e2d05:	74 16                	je     6e2d1d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x7bd>
  6e2d07:	84 c0                	test   %al,%al
  6e2d09:	0f 84 01 02 00 00    	je     6e2f10 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9b0>
  6e2d0f:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6e2d16:	ff 
  6e2d17:	0f 85 f3 01 00 00    	jne    6e2f10 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9b0>
  6e2d1d:	31 c9                	xor    %ecx,%ecx
  6e2d1f:	e9 f8 01 00 00       	jmp    6e2f1c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9bc>
  6e2d24:	0f 10 44 24 10       	movups 0x10(%rsp),%xmm0
  6e2d29:	0f 10 4c 24 20       	movups 0x20(%rsp),%xmm1
  6e2d2e:	0f 10 54 24 30       	movups 0x30(%rsp),%xmm2
  6e2d33:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
  6e2d3a:	00 
  6e2d3b:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6e2d40:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  6e2d47:	00 
  6e2d48:	0f 29 94 24 c0 00 00 	movaps %xmm2,0xc0(%rsp)
  6e2d4f:	00 
  6e2d50:	0f 29 8c 24 b0 00 00 	movaps %xmm1,0xb0(%rsp)
  6e2d57:	00 
  6e2d58:	48 83 bc 24 a0 00 00 	cmpq   $0xfffffffffffffffe,0xa0(%rsp)
  6e2d5f:	00 fe 
  6e2d61:	0f 85 e5 00 00 00    	jne    6e2e4c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8ec>
  6e2d67:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6e2d6c:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  6e2d73:	00 
  6e2d74:	4c 89 f6             	mov    %r14,%rsi
  6e2d77:	e8 54 09 00 00       	call   6e36d0 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::reconcile_editing>
  6e2d7c:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  6e2d81:	44 0f b6 7c 24 18    	movzbl 0x18(%rsp),%r15d
  6e2d87:	48 83 f8 fe          	cmp    $0xfffffffffffffffe,%rax
  6e2d8b:	0f 85 8e 00 00 00    	jne    6e2e1f <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8bf>
  6e2d91:	48 8d 35 a0 45 97 ff 	lea    -0x68ba60(%rip),%rsi        # 57338 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x15c8>
  6e2d98:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6e2d9f:	00 
  6e2da0:	e8 7b 29 01 00       	call   6f5720 <<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error> as core::cmp::PartialEq>::eq>
  6e2da5:	84 c0                	test   %al,%al
  6e2da7:	74 26                	je     6e2dcf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x86f>
  6e2da9:	49 8b 86 18 06 00 00 	mov    0x618(%r14),%rax
  6e2db0:	48 85 c0             	test   %rax,%rax
  6e2db3:	0f 84 a1 01 00 00    	je     6e2f5a <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x9fa>
  6e2db9:	48 83 b8 d8 00 00 00 	cmpq   $0x0,0xd8(%rax)
  6e2dc0:	00 
  6e2dc1:	0f 95 c0             	setne  %al
  6e2dc4:	44 08 f8             	or     %r15b,%al
  6e2dc7:	a8 01                	test   $0x1,%al
  6e2dc9:	0f 84 95 01 00 00    	je     6e2f64 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa04>
  6e2dcf:	48 8d 35 9a 45 97 ff 	lea    -0x68ba66(%rip),%rsi        # 57370 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0x1600>
  6e2dd6:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6e2ddd:	00 
  6e2dde:	e8 3d 29 01 00       	call   6f5720 <<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error> as core::cmp::PartialEq>::eq>
  6e2de3:	84 c0                	test   %al,%al
  6e2de5:	74 26                	je     6e2e0d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8ad>
  6e2de7:	49 8b 86 18 06 00 00 	mov    0x618(%r14),%rax
  6e2dee:	48 85 c0             	test   %rax,%rax
  6e2df1:	0f 84 99 01 00 00    	je     6e2f90 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa30>
  6e2df7:	48 83 b8 d8 00 00 00 	cmpq   $0x0,0xd8(%rax)
  6e2dfe:	00 
  6e2dff:	0f 95 c0             	setne  %al
  6e2e02:	44 08 f8             	or     %r15b,%al
  6e2e05:	a8 01                	test   $0x1,%al
  6e2e07:	0f 84 8d 01 00 00    	je     6e2f9a <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa3a>
  6e2e0d:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  6e2e12:	4c 89 f6             	mov    %r14,%rsi
  6e2e15:	e8 f6 19 01 00       	call   6f4810 <<gpui::runtime::Runtime<inbox_storage_control::Page>>::present>
  6e2e1a:	e9 d6 fb ff ff       	jmp    6e29f5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x495>
  6e2e1f:	0f 10 44 24 19       	movups 0x19(%rsp),%xmm0
  6e2e24:	0f 10 4c 24 29       	movups 0x29(%rsp),%xmm1
  6e2e29:	0f 10 54 24 38       	movups 0x38(%rsp),%xmm2
  6e2e2e:	0f 11 54 24 78       	movups %xmm2,0x78(%rsp)
  6e2e33:	0f 11 4c 24 69       	movups %xmm1,0x69(%rsp)
  6e2e38:	0f 11 44 24 59       	movups %xmm0,0x59(%rsp)
  6e2e3d:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  6e2e42:	44 88 7c 24 58       	mov    %r15b,0x58(%rsp)
  6e2e47:	e9 a9 fb ff ff       	jmp    6e29f5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x495>
  6e2e4c:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
  6e2e53:	00 
  6e2e54:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  6e2e59:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  6e2e60:	00 
  6e2e61:	0f 28 8c 24 b0 00 00 	movaps 0xb0(%rsp),%xmm1
  6e2e68:	00 
  6e2e69:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
  6e2e70:	00 
  6e2e71:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
  6e2e76:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
  6e2e7b:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  6e2e80:	49 8b 86 18 06 00 00 	mov    0x618(%r14),%rax
  6e2e87:	48 85 c0             	test   %rax,%rax
  6e2e8a:	74 41                	je     6e2ecd <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x96d>
  6e2e8c:	48 8b 80 e0 00 00 00 	mov    0xe0(%rax),%rax
  6e2e93:	48 85 c0             	test   %rax,%rax
  6e2e96:	74 35                	je     6e2ecd <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x96d>
  6e2e98:	48 8b 78 10          	mov    0x10(%rax),%rdi
  6e2e9c:	0f b6 48 24          	movzbl 0x24(%rax),%ecx
  6e2ea0:	c6 40 24 02          	movb   $0x2,0x24(%rax)
  6e2ea4:	80 f9 02             	cmp    $0x2,%cl
  6e2ea7:	74 24                	je     6e2ecd <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x96d>
  6e2ea9:	f6 07 01             	testb  $0x1,(%rdi)
  6e2eac:	75 17                	jne    6e2ec5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x965>
  6e2eae:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e2eb2:	a8 01                	test   $0x1,%al
  6e2eb4:	75 0f                	jne    6e2ec5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x965>
  6e2eb6:	48 8d 47 08          	lea    0x8(%rdi),%rax
  6e2eba:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  6e2ebf:	0f 84 46 01 00 00    	je     6e300b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xaab>
  6e2ec5:	41 c6 86 23 07 00 00 	movb   $0x1,0x723(%r14)
  6e2ecc:	01 
  6e2ecd:	41 c6 86 22 07 00 00 	movb   $0x0,0x722(%r14)
  6e2ed4:	00 
  6e2ed5:	49 c7 86 f0 05 00 00 	movq   $0x0,0x5f0(%r14)
  6e2edc:	00 00 00 00 
  6e2ee0:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  6e2ee5:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  6e2eec:	00 
  6e2eed:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  6e2ef2:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
  6e2ef7:	0f 28 54 24 30       	movaps 0x30(%rsp),%xmm2
  6e2efc:	0f 29 54 24 70       	movaps %xmm2,0x70(%rsp)
  6e2f01:	0f 29 4c 24 60       	movaps %xmm1,0x60(%rsp)
  6e2f06:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  6e2f0b:	e9 e5 fa ff ff       	jmp    6e29f5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x495>
  6e2f10:	49 8b 96 98 06 00 00 	mov    0x698(%r14),%rdx
  6e2f17:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e2f1c:	49 8b b6 10 07 00 00 	mov    0x710(%r14),%rsi
  6e2f23:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6e2f28:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  6e2f2d:	0f 11 44 24 68       	movups %xmm0,0x68(%rsp)
  6e2f32:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6e2f37:	88 84 24 80 00 00 00 	mov    %al,0x80(%rsp)
  6e2f3e:	48 c7 44 24 50 fe ff 	movq   $0xfffffffffffffffe,0x50(%rsp)
  6e2f45:	ff ff 
  6e2f47:	41 80 be 26 07 00 00 	cmpb   $0x0,0x726(%r14)
  6e2f4e:	00 
  6e2f4f:	0f 84 e6 fb ff ff    	je     6e2b3b <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5db>
  6e2f55:	e9 eb fb ff ff       	jmp    6e2b45 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x5e5>
  6e2f5a:	41 80 ff 01          	cmp    $0x1,%r15b
  6e2f5e:	0f 84 6b fe ff ff    	je     6e2dcf <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x86f>
  6e2f64:	41 0f 10 86 68 06 00 	movups 0x668(%r14),%xmm0
  6e2f6b:	00 
  6e2f6c:	41 0f b6 86 24 07 00 	movzbl 0x724(%r14),%eax
  6e2f73:	00 
  6e2f74:	49 83 be 88 06 00 00 	cmpq   $0x0,0x688(%r14)
  6e2f7b:	00 
  6e2f7c:	74 0e                	je     6e2f8c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa2c>
  6e2f7e:	84 c0                	test   %al,%al
  6e2f80:	74 27                	je     6e2fa9 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa49>
  6e2f82:	49 83 be 88 05 00 00 	cmpq   $0xffffffffffffffff,0x588(%r14)
  6e2f89:	ff 
  6e2f8a:	75 1d                	jne    6e2fa9 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa49>
  6e2f8c:	31 c9                	xor    %ecx,%ecx
  6e2f8e:	eb 25                	jmp    6e2fb5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xa55>
  6e2f90:	41 80 ff 01          	cmp    $0x1,%r15b
  6e2f94:	0f 84 73 fe ff ff    	je     6e2e0d <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x8ad>
  6e2f9a:	48 8d 3d a7 15 37 00 	lea    0x3715a7(%rip),%rdi        # a54548 <__frame_dummy_init_array_entry+0x628>
  6e2fa1:	ff 15 f9 9f 39 00    	call   *0x399ff9(%rip)        # a7cfa0 <_DYNAMIC+0x288>
  6e2fa7:	0f 0b                	ud2
  6e2fa9:	49 8b 96 98 06 00 00 	mov    0x698(%r14),%rdx
  6e2fb0:	b9 01 00 00 00       	mov    $0x1,%ecx
  6e2fb5:	49 8b b6 10 07 00 00 	mov    0x710(%r14),%rsi
  6e2fbc:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  6e2fc1:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  6e2fc6:	0f 11 44 24 68       	movups %xmm0,0x68(%rsp)
  6e2fcb:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  6e2fd0:	88 84 24 80 00 00 00 	mov    %al,0x80(%rsp)
  6e2fd7:	48 c7 44 24 50 fe ff 	movq   $0xfffffffffffffffe,0x50(%rsp)
  6e2fde:	ff ff 
  6e2fe0:	e9 10 fa ff ff       	jmp    6e29f5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x495>
  6e2fe5:	48 c7 44 24 50 20 00 	movq   $0x20,0x50(%rsp)
  6e2fec:	00 00 
  6e2fee:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  6e2ff5:	00 00 
  6e2ff7:	e9 f9 f9 ff ff       	jmp    6e29f5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x495>
  6e2ffc:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e3000:	ff 15 ba 9f 39 00    	call   *0x399fba(%rip)        # a7cfc0 <_DYNAMIC+0x2a8>
  6e3006:	e9 d1 fa ff ff       	jmp    6e2adc <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x57c>
  6e300b:	48 8b 47 08          	mov    0x8(%rdi),%rax
  6e300f:	ff 15 ab 9f 39 00    	call   *0x399fab(%rip)        # a7cfc0 <_DYNAMIC+0x2a8>
  6e3015:	e9 ab fe ff ff       	jmp    6e2ec5 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x965>
  6e301a:	48 89 c3             	mov    %rax,%rbx
  6e301d:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6e3022:	e8 c9 c6 ff ff       	call   6df6f0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3027:	eb 2a                	jmp    6e3053 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xaf3>
  6e3029:	48 89 c3             	mov    %rax,%rbx
  6e302c:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6e3031:	eb 32                	jmp    6e3065 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb05>
  6e3033:	48 89 c3             	mov    %rax,%rbx
  6e3036:	49 8b 77 08          	mov    0x8(%r15),%rsi
  6e303a:	48 85 f6             	test   %rsi,%rsi
  6e303d:	74 3d                	je     6e307c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb1c>
  6e303f:	49 8b 57 10          	mov    0x10(%r15),%rdx
  6e3043:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  6e3048:	ff 15 12 9f 39 00    	call   *0x399f12(%rip)        # a7cf60 <_DYNAMIC+0x248>
  6e304e:	eb 2c                	jmp    6e307c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb1c>
  6e3050:	48 89 c3             	mov    %rax,%rbx
  6e3053:	83 bc 24 f8 00 00 00 	cmpl   $0xfffffffe,0xf8(%rsp)
  6e305a:	fe 
  6e305b:	74 1f                	je     6e307c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb1c>
  6e305d:	48 8d bc 24 f8 00 00 	lea    0xf8(%rsp),%rdi
  6e3064:	00 
  6e3065:	e8 86 c6 ff ff       	call   6df6f0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e306a:	eb 10                	jmp    6e307c <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb1c>
  6e306c:	48 89 c3             	mov    %rax,%rbx
  6e306f:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  6e3076:	00 
  6e3077:	e8 44 9f ff ff       	call   6dcfc0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<(), gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e307c:	41 80 be 26 07 00 00 	cmpb   $0x0,0x726(%r14)
  6e3083:	00 
  6e3084:	75 0a                	jne    6e3090 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xb30>
  6e3086:	49 83 be 68 06 00 00 	cmpq   $0xffffffffffffffff,0x668(%r14)
  6e308d:	ff 
  6e308e:	75 77                	jne    6e3107 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xba7>
  6e3090:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
  6e3097:	00 
  6e3098:	e8 a3 0b 02 00       	call   703c40 <<gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()> as gpui::remote::LaneSet<inbox_storage_control::Page>>::close>
  6e309d:	eb 68                	jmp    6e3107 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xba7>
  6e309f:	ff 15 0b 9f 39 00    	call   *0x399f0b(%rip)        # a7cfb0 <_DYNAMIC+0x298>
  6e30a5:	ff 15 05 9f 39 00    	call   *0x399f05(%rip)        # a7cfb0 <_DYNAMIC+0x298>
  6e30ab:	48 89 c7             	mov    %rax,%rdi
  6e30ae:	ff 15 ec 9f 39 00    	call   *0x399fec(%rip)        # a7d0a0 <_DYNAMIC+0x388>
  6e30b4:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  6e30b9:	49 89 d7             	mov    %rdx,%r15
  6e30bc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  6e30c1:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
  6e30c8:	00 
  6e30c9:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
  6e30d0:	00 
  6e30d1:	48 c7 84 24 a0 00 00 	movq   $0xfffffffffffffffd,0xa0(%rsp)
  6e30d8:	00 fd ff ff ff 
  6e30dd:	e9 ce f8 ff ff       	jmp    6e29b0 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0x450>
  6e30e2:	ff 15 c0 9f 39 00    	call   *0x399fc0(%rip)        # a7d0a8 <_DYNAMIC+0x390>
  6e30e8:	48 89 c3             	mov    %rax,%rbx
  6e30eb:	48 83 7c 24 50 fe    	cmpq   $0xfffffffffffffffe,0x50(%rsp)
  6e30f1:	74 14                	je     6e3107 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xba7>
  6e30f3:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  6e30f8:	eb 08                	jmp    6e3102 <<gpui::runtime::Win<inbox_storage_control::Page, gpui::remote::Lane<u64, for<'a> fn(&'a mut inbox_storage_control::Page, u64), ()>>>::deliver_ready+0xba2>
  6e30fa:	48 89 c3             	mov    %rax,%rbx
  6e30fd:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  6e3102:	e8 e9 c5 ff ff       	call   6df6f0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  6e3107:	48 89 df             	mov    %rbx,%rdi
  6e310a:	e8 61 fa 36 00       	call   a52b70 <_Unwind_Resume@plt>
  6e310f:	cc                   	int3

