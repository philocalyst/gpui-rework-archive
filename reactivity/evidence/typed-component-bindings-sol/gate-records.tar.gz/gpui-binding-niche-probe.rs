#[path="/root/gpui-typed-binding-sol-20261024/reactivity/crates/inline-call/src/lib.rs"] mod inline;
use inline::{InlineCall,TooLarge};
type Recipe=InlineCall<Option<[u32;4]>>;
struct Selection { build:InlineCall<Result<Recipe,TooLarge>>,colors:[[u32;4];2] }
enum Deferred { Rejected{size:u32,alignment:u32}, Large(Box<TooLarge>), Select(Box<Selection>) }
enum Pending { Inline(Recipe), Deferred(Deferred) }
struct OriginalOperand<'a> { source:&'a dyn std::any::Any, recipe:Result<Recipe,TooLarge> }
struct OwnedOperand<'a> { source:&'a dyn std::any::Any, recipe:Pending }
struct Binding<'a> { sink:u16, operand:OwnedOperand<'a> }
struct Draft<'a> { node:u32,sink:u16,value:Option<[u32;4]>,operand:OwnedOperand<'a> }
fn main() { println!("Recipe={} OriginalResult={} Deferred={} Pending={} OriginalOperand={} OwnedOperand={} Binding={} Selection={} exampleDraftValue20={}",size_of::<Recipe>(),size_of::<Result<Recipe,TooLarge>>(),size_of::<Deferred>(),size_of::<Pending>(),size_of::<OriginalOperand>(),size_of::<OwnedOperand>(),size_of::<Binding>(),size_of::<Selection>(),size_of::<Draft>()); }
