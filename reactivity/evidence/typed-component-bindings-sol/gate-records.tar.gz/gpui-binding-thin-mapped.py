from pathlib import Path
b=Path('/root/gpui-typed-binding-sol-20261024/reactivity/crates/gpui/src')
p=b/'style_port.rs';s=p.read_text();a=s.index('pub struct Mapped<');z=s.index('// The largest variant',a)
s=s[:a]+'''pub struct Mapped<'a, T, U, F> {
    signal: &'a Signal<T>,
    map: F,
    output: std::marker::PhantomData<fn() -> U>,
}
impl<T, U, F: Copy> Copy for Mapped<'_, T, U, F> {}
impl<T, U, F: Copy> Clone for Mapped<'_, T, U, F> { fn clone(&self) -> Self { *self } }
impl<'a, T: 'static, U: MapValue, F> Mapped<'a, T, U, F>
where F: Fn(&T) -> U + Copy + Send + Sync + 'static {
    fn operand(self) -> MapOperand<'a> {
        let map = self.map;
        MapOperand { signal: self.signal, recipe: Recipe::new(move |input: &dyn std::any::Any| {
            input.downcast_ref::<Signal<T>>().map(|signal| map(&**signal).scalar())
        }) }
    }
}
''' +s[z:]
s=s.replace('''pub(crate) enum PendingRecipe {
    Inline(Recipe),
    Rejected(gpui_inline_call::TooLarge),
    Select(Box<ColorSelection>),
}''','''pub(crate) enum PendingRecipe {
    Inline(Recipe),
    Deferred(DeferredRecipe),
}
// A small cold alternative fits the inline function pointer's existing niche.
// Exceptional large rejection diagnostics retain their complete usize payload.
#[derive(Clone)]
pub(crate) enum DeferredRecipe {
    Rejected { size: u32, alignment: u32 },
    RejectedLarge(Box<gpui_inline_call::TooLarge>),
    Select(Box<ColorSelection>),
}''')
i=s.index('impl PendingRecipe {');s=s[:i]+s[i:].replace('impl PendingRecipe {','''impl PendingRecipe {
    fn rejected(error: gpui_inline_call::TooLarge) -> Self {
        Self::Deferred(match (u32::try_from(error.size), u32::try_from(error.alignment)) {
            (Ok(size), Ok(alignment)) => DeferredRecipe::Rejected { size, alignment },
            _ => DeferredRecipe::RejectedLarge(Box::new(error)),
        })
    }
    fn deferred_error(error: &DeferredRecipe) -> crate::Error {
        Self::error(match error {
            DeferredRecipe::Rejected { size, alignment } => gpui_inline_call::TooLarge { size: *size as usize, alignment: *alignment as usize },
            DeferredRecipe::RejectedLarge(error) => **error,
            DeferredRecipe::Select(_) => unreachable!("selection is not a rejection"),
        })
    }''',1)
s=s.replace('Self::Rejected(error) => Err(Self::error(*error)),','Self::Deferred(error @ (DeferredRecipe::Rejected { .. } | DeferredRecipe::RejectedLarge(_))) => Err(Self::deferred_error(error)),')
s=s.replace('Self::Select(selection) => {','Self::Deferred(DeferredRecipe::Select(selection)) => {')
s=s.replace('Self::Rejected(error) => Err(Self::error(error)),','Self::Deferred(error @ (DeferredRecipe::Rejected { .. } | DeferredRecipe::RejectedLarge(_))) => Err(Self::deferred_error(&error)),')
s=s.replace('Self::Select(selection) => selection','Self::Deferred(DeferredRecipe::Select(selection)) => selection')
s=s.replace('Err(error) => PendingRecipe::Rejected(error),','Err(error) => PendingRecipe::rejected(error),')
# Rewrite typed color selector input before shared lowering.
a=s.index('pub struct SelectedColors');z=s.index('/// Allocation-free source mapping.',a)
s=s[:a]+'''pub struct SelectedColors<'a, T, F> {
    signal: &'a Signal<T>,
    map: F,
    colors: [Color; 2],
}
impl<T, F: Copy> Copy for SelectedColors<'_, T, F> {}
impl<T, F: Copy> Clone for SelectedColors<'_, T, F> { fn clone(&self) -> Self { *self } }
impl<T, F> sealed::ColorInput for SelectedColors<'_, T, F> {}
impl<'a, T: 'static, F> IntoColor<'a> for SelectedColors<'a, T, F>
where F: Fn(&T) -> bool + Copy + Send + Sync + 'static {
    fn into_color(self) -> ColorInput<'a> {
        let map = self.map;
        let build = gpui_inline_call::InlineCall::new(move |input: &dyn std::any::Any| {
            let codes = *input.downcast_ref::<[u32; 2]>().expect("internal palette pair");
            Recipe::new(move |input: &dyn std::any::Any| input.downcast_ref::<Signal<T>>().map(|signal| Scalar::ColorSlot(codes[usize::from(map(&**signal))])))
        });
        let recipe = match build { Ok(build) => PendingRecipe::Deferred(DeferredRecipe::Select(Box::new(ColorSelection { build, colors: self.colors }))), Err(error) => PendingRecipe::rejected(error) };
        ColorInput(ColorOperand::Selection(OwnedMapOperand { signal: self.signal, recipe }))
    }
}
''' +s[z:]
a=s.index('pub trait SignalMap<T>');z=s.index('/// A boolean operand',a)
s=s[:a]+'''pub trait SignalMap<T> {
    fn map<U: MapValue, F>(&self, map: F) -> Mapped<'_, T, U, F>
    where F: Fn(&T) -> U + Copy + Send + Sync + 'static;
    fn map_with<P, U: MapValue, F>(&self, parameter: P, map: F) -> Mapped<'_, T, U, impl Fn(&T) -> U + Copy + Send + Sync + 'static>
    where P: Copy + Send + Sync + 'static, F: Fn(&T, P) -> U + Copy + Send + Sync + 'static;
}
impl<T: 'static> SignalMap<T> for Signal<T> {
    fn map<U: MapValue, F>(&self, map: F) -> Mapped<'_, T, U, F>
    where F: Fn(&T) -> U + Copy + Send + Sync + 'static {
        Mapped { signal: self, map, output: std::marker::PhantomData }
    }
    fn map_with<P, U: MapValue, F>(&self, parameter: P, map: F) -> Mapped<'_, T, U, impl Fn(&T) -> U + Copy + Send + Sync + 'static>
    where P: Copy + Send + Sync + 'static, F: Fn(&T, P) -> U + Copy + Send + Sync + 'static {
        self.map(move |value| map(value, parameter))
    }
}
''' +s[z:]
s=s.replace('''            map: |input: &dyn std::any::Any| {
                input.downcast_ref::<Signal<bool>>().map(|value| **value)
            },''','''            map: |value: &bool| *value,''')
s=s.replace("impl<'a, F> BoolInput<'a> for Mapped<'a, bool, F>\nwhere\n    F: Fn(&dyn std::any::Any) -> Option<bool> + Copy + Send + Sync + 'static,", "impl<'a, T: 'static, F> BoolInput<'a> for Mapped<'a, T, bool, F>\nwhere\n    F: Fn(&T) -> bool + Copy + Send + Sync + 'static,")
s=s.replace("impl<U, F> sealed::Input<U> for Mapped<'_, U, F>", "impl<T, U, F> sealed::Input<U> for Mapped<'_, T, U, F>")
s=s.replace("impl<'a, U: MapValue, F> IntoProp<'a, U> for Mapped<'a, U, F>\nwhere\n    F: Fn(&dyn std::any::Any) -> Option<U> + Copy + Send + Sync + 'static,", "impl<'a, T: 'static, U: MapValue, F> IntoProp<'a, U> for Mapped<'a, T, U, F>\nwhere\n    F: Fn(&T) -> U + Copy + Send + Sync + 'static,")
s=s.replace("impl<F> sealed::Input<f64> for Mapped<'_, $ty, F>","impl<T, F> sealed::Input<f64> for Mapped<'_, T, $ty, F>")
s=s.replace("impl<'a, F> IntoProp<'a, f64> for Mapped<'a, $ty, F> where F: Fn(&dyn std::any::Any) -> Option<$ty>","impl<'a, T: 'static, F> IntoProp<'a, f64> for Mapped<'a, T, $ty, F> where F: Fn(&T) -> $ty")
s=s.replace("impl<F> sealed::Input<Length> for Mapped<'_, $ty, F>","impl<T, F> sealed::Input<Length> for Mapped<'_, T, $ty, F>")
s=s.replace("impl<'a, F> IntoProp<'a, Length> for Mapped<'a, $ty, F> where F: Fn(&dyn std::any::Any) -> Option<$ty>","impl<'a, T: 'static, F> IntoProp<'a, Length> for Mapped<'a, T, $ty, F> where F: Fn(&T) -> $ty")
# Keep source diagnostics/conversion exact at the sole erased operand boundary.
s=s.replace('PendingRecipe::Rejected(error)', 'PendingRecipe::rejected(error)')
p.write_text(s)
# A checked-bit change needs no inherited-disabled scan or focus reconciliation.
p=b/'runtime.rs';s=p.read_text().replace('let mut controls_changed = false;', 'let mut disabled_changed = false;').replace('controls_changed = true;', 'disabled_changed |= control == crate::style_port::Sink::DISABLED;').replace('if controls_changed {','if disabled_changed {');p.write_text(s)
# Release obsolete dynamic intrinsic storage when a literal erases the last port.
p=b/'element.rs';s=p.read_text();needle='''        } else if let Some(signal) = input.signal() {
            self.extra''';start=s.index(needle,s.index('    fn control_input('));s=s[:start]+'''            if self.extra.as_deref().is_some_and(crate::semantic::ElementExtra::empty) { self.extra = None; }
''' +s[start:];p.write_text(s)
