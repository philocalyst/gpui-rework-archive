#[path="/root/gpui-typed-binding-sol-20261024/reactivity/crates/inline-call/src/lib.rs"]
mod inline;
use inline::{InlineCall,TooLarge};
use std::any::Any;
#[derive(Clone,Copy)]
enum Scalar { Flag(bool), Color([u32;4]), ColorSlot(u32) }
type Recipe=InlineCall<Option<Scalar>>;
struct Selection { build:InlineCall<Result<Recipe,TooLarge>>, colors:[[u32;4];2] }
enum Pending { Inline(Recipe), Rejected(TooLarge), Select(Box<Selection>) }
struct Operand<'a> { source:&'a dyn Any, recipe:Pending }
struct Record { destination:u32, recipe:Recipe, color:u32 }
struct Typed<'a,U,F> { source:&'a dyn Any, map:F, marker:std::marker::PhantomData<U> }
impl<'a,F:Fn(&dyn Any)->Option<bool>+Copy+Send+Sync+'static> Typed<'a,bool,F> {
 fn select(self, colors:[[u32;4];2])->Operand<'a> {
  let map=self.map;
  let build=InlineCall::new(move |input:&dyn Any| {
   let slots=*input.downcast_ref::<[u32;2]>().unwrap();
   Recipe::new(move |input:&dyn Any| map(input).map(|value|Scalar::ColorSlot(slots[usize::from(value)])))
  });
  Operand { source:self.source, recipe:match build {Ok(build)=>Pending::Select(Box::new(Selection{build,colors})),Err(error)=>Pending::Rejected(error)} }
 }
}
fn main() {
 let value=String::from("ab");
 let expression=Typed { source:&value, map:|input:&dyn Any| input.downcast_ref::<String>().map(|s|s.len()<3),marker:std::marker::PhantomData };
 let operand=expression.select([[0;4],[1;4]]);
 let Pending::Select(selection)=operand.recipe else {panic!("selector")};
 let recipe=selection.build.call(&[5u32,6]).unwrap();
 assert!(matches!(recipe.call(operand.source),Some(Scalar::ColorSlot(6))));
 println!("Recipe={} Pending={} Operand={} Selection={} Record={}",size_of::<Recipe>(),size_of::<Pending>(),size_of::<Operand>(),size_of::<Selection>(),size_of::<Record>());
 let capture=[1_u32;3];
 let expression=Typed {source:&value,map:move |input:&dyn Any| input.downcast_ref::<String>().map(|s| s.len()<std::hint::black_box(capture)[0] as usize),marker:std::marker::PhantomData};
 let operand=expression.select([[0;4],[1;4]]);
 let Pending::Select(selection)=operand.recipe else {panic!("factory12 fits")};
 let error=selection.build.call(&[5u32,6]).err().unwrap();
 assert_eq!(error,TooLarge{size:20,alignment:4});
 println!("composed_capture_rejection={error:?}");
}
