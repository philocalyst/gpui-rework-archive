from pathlib import Path
base=Path('/root/gpui-typed-binding-sol-20261024/reactivity/crates')
p=base/'gpui/src/element.rs';s=p.read_text();needle='    fn invoke(&self, receiver: &mut dyn Any) -> Result<(), BindError>;';s=s.replace(needle,needle+'''\n    fn invoke_control(&self, receiver: &mut dyn Any, _next: Option<bool>) -> Result<(), BindError> { self.invoke(receiver) }''',1)
needle='''    pub(crate) fn invoke(&self, receiver: &mut dyn Any) -> Result<(), BindError> {
        self.0.invoke(receiver)
    }''';s=s.replace(needle,needle+'''\n    pub(crate) fn invoke_control(&self, receiver: &mut dyn Any, next: Option<bool>) -> Result<(), BindError> { self.0.invoke_control(receiver, next) }''',1)
needle='''    fn property(&self, phase: PropertyPhase<'_>) -> Result<(), BindError> {''';i=s.index(needle,s.index('impl<P:'));s=s[:i]+'''    fn invoke_control(&self, receiver: &mut dyn Any, next: Option<bool>) -> Result<(), BindError> {
        let parent = receiver.downcast_mut::<P>().ok_or(BindError::ReceiverMismatch)?;
        self.handler.invoke_control(self.component.project_mut(parent)?, next)
    }
''' +s[i:]
i=s.index('// Validation and invocation share')
s=s[:i]+'''struct CheckRoute<M, F> { callback: F, model: PhantomData<fn(M)> }
impl<M: 'static, F: Fn(&mut M, bool)> Route for CheckRoute<M, F> {
    fn admit(&self, receiver: &dyn Any, _: &dyn Any) -> Result<Admission, BindError> {
        if receiver.is::<M>() { Ok(Admission::Model { exact: None }) } else { Err(BindError::ReceiverMismatch) }
    }
    fn invoke(&self, _: &mut dyn Any) -> Result<(), BindError> { Err(BindError::ReceiverMismatch) }
    fn invoke_control(&self, receiver: &mut dyn Any, next: Option<bool>) -> Result<(), BindError> {
        let receiver = receiver.downcast_mut::<M>().ok_or(BindError::ReceiverMismatch)?;
        (self.callback)(receiver, next.ok_or(BindError::ReceiverMismatch)?);
        Ok(())
    }
}

''' +s[i:]
i=s.index('    fn bind_mapped_property(');s=s[:i]+'''    /// Replace the checkbox route with a controlled intent callback. Every
    /// activation computes intent from current logical checked state, including
    /// direct source publications, before exposing the mutable model.
    pub fn on_check<M: 'static>(mut self, callback: impl Fn(&mut M, bool) + 'static) -> Self {
        assert!(matches!(self.kind, NodeKind::CheckBox(_)), "checked intent belongs to a checkbox");
        self.on_click = Some(Handler(Box::new(CheckRoute { callback, model: PhantomData })));
        self
    }
''' +s[i:];p.write_text(s)
p=base/'gpui/src/runtime/turn.rs';s=p.read_text();needle='''        match catch_unwind(AssertUnwindSafe(|| handler.invoke(&mut self.runtime.model))) {''';assert needle in s;s=s.replace(needle,'''        let next = match self.runtime.nodes[index].kind() { NodeKind::CheckBox(checked) => Some(!checked), _ => None };
        match catch_unwind(AssertUnwindSafe(|| handler.invoke_control(&mut self.runtime.model, next))) {''');p.write_text(s)
# Checkbox accepts a shared typed bool input, and draws persistent mark geometry
# with source-controlled paint, eliminating structural owner snapshot dependency.
p=base/'component/src/checkbox.rs';s=p.read_text().replace('use gpui::{Align, El, Flex, IntoHandler, Source};','use gpui::{Align, BoolInput, Color, El, Flex, IntoHandler, Source};')
s=s.replace('    checked: bool,\n','')
s=s.replace("pub fn new(label: &'a str, checked: bool, theme: &'a Theme)","pub fn new(label: &'a str, checked: impl BoolInput<'a>, theme: &'a Theme)")
a=s.index('            .bg(if checked {');b=s.index('        Self {',a)
s=s[:a]+'''            .bg(checked.select(theme.border(), theme.accent()))
            .child({
                let unit = theme.rem(1.0 / 14.0) as f32;
                let stroke = |width, a, b, x, y| {
                    gpui::div()
                        .w(theme.rem(width / 14.0))
                        .h(theme.rem(2.0 / 14.0))
                        .bg(checked.select(Color::TRANSPARENT, theme.on_accent()))
                        .transform(gpui::Affine { a, b, c: -b, d: a, tx: x * unit, ty: y * unit })
                };
                gpui::div().size(theme.rem(6.0 / 7.0)).child((
                    stroke(4.0, 0.707, 0.707, 1.0, 4.0),
                    stroke(8.0, 0.707, -0.707, 3.0, 4.0),
                ))
            });
''' +s[b:]
s=s.replace('            checked,\n','')
a=s.index('        let next = !self.checked;');b=s.index('        self\n',a);s=s[:a]+'''        self.parts.root = self.parts.root.on_check(handler);
''' +s[b:]
s=s.replace('''    /// `checked` is a snapshot: register its source with `Sources::field` (and
    /// parent snapshot reads with `Sources::component`) so writes re-describe
    /// the controlled value. A direct-only declaration cannot observe that read.''','''    /// Pass `&Signal<bool>` for direct checked/appearance bindings. A by-value
    /// bool remains a snapshot and requires `Sources::field` (and component
    /// dependencies for parent snapshot branches).''')
s=s.replace('pub fn disabled(mut self, disabled: bool)',"pub fn disabled(mut self, disabled: impl BoolInput<'a>)")
s=s.replace('''        if disabled {
            self.parts.label = self.parts.label.fg(self.theme.muted());
            self.parts.indicator = self.parts.indicator.bg(self.theme.raised());
        }''','''        // Disabled paint is a caller policy, expressed through the same input.
        self.parts.label = self.parts.label.fg(disabled.select(self.theme.foreground(), self.theme.muted()));''')
p.write_text(s)
p=base/'component/src/button.rs';s=p.read_text().replace('use gpui::{El, IntoHandler, IntoText};','use gpui::{BoolInput, El, IntoHandler, IntoText};').replace('pub fn disabled(mut self, disabled: bool)',"pub fn disabled(mut self, disabled: impl BoolInput<'a>)")
# Keep variant background policy; choose only standard foreground by disabled.
s=s.replace('''        if disabled {
            self.element = self.element.fg(self.theme.muted()).bg(self.theme.surface());
        }''','''        self.element = self.element.fg(disabled.select(self.theme.foreground(), self.theme.muted()));''')
p.write_text(s)
p=base/'component/src/input.rs';s=p.read_text().replace('use gpui::{El, Signal};','use gpui::{BoolInput, El, Signal};').replace('pub fn invalid(mut self, invalid: bool)',"pub fn invalid(mut self, invalid: impl BoolInput<'a>)").replace('''self.parts.frame.bg(if invalid {
            self.theme.danger()
        } else {
            self.theme.border()
        })''','''self.parts.frame.bg(invalid.select(self.theme.border(), self.theme.danger()))''').replace('pub fn disabled(mut self, disabled: bool)',"pub fn disabled(mut self, disabled: impl BoolInput<'a>)").replace('''        if disabled {
            self.parts.control = self.parts.control.fg(self.theme.muted());
        }''','''        self.parts.control = self.parts.control.fg(disabled.select(self.theme.foreground(), self.theme.muted()));''');p.write_text(s)
