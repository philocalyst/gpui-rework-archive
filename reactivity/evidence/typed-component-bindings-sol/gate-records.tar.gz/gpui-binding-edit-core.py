from pathlib import Path
base=Path('/root/gpui-typed-binding-sol-20261024/reactivity/crates/gpui/src')
p=base/'style_port.rs';s=p.read_text();s=s.replace('pub(crate) enum PendingRecipe {','#[derive(Clone)]\npub(crate) enum PendingRecipe {').replace('pub(crate) struct ColorSelection {','#[derive(Clone)]\npub(crate) struct ColorSelection {').replace("pub(crate) struct MapOperand<'a> {","#[derive(Clone)]\npub(crate) struct MapOperand<'a> {")
s=s.replace('enum Operand<', '#[derive(Clone)]\nenum Operand<')
s=s.replace("pub struct PropInput<'a, T>(Operand<'a, T>);", "#[derive(Clone)]\npub struct PropInput<'a, T>(Operand<'a, T>);")
# closed two-byte sink selector; no style registry expansion
pos=s.index('pub(crate) struct MapBinding')
s=s[:pos]+'''/// Private destination tags share the existing two-byte binding slot. Control
/// state is intrinsic semantics, not an inspector style-property declaration.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) struct Sink(u16);
impl Sink {
    pub const CHECKED: Self = Self(0x8000);
    pub const DISABLED: Self = Self(0x8001);
    pub fn property(self) -> Option<PropertyId> { PropertyId::from_code(self.0) }
    pub fn control_code(self) -> u16 { assert!(self.property().is_none()); self.0 - 0x7fff }
    pub fn control(code: u16) -> Option<Self> { match code { 1 => Some(Self::CHECKED), 2 => Some(Self::DISABLED), _ => None } }
    pub fn admit(self, scalar: Scalar) -> Result<PropertyValue, crate::Error> {
        if let Some(id) = self.property() { return Ok(scalar.admit(id)?); }
        match scalar { Scalar::Value(value @ PropertyValue::Flag(_)) => Ok(value), _ => Err(crate::Error::MapInput) }
    }
}
impl From<PropertyId> for Sink { fn from(id: PropertyId) -> Self { Self(id as u16) } }
''' +s[pos:]
s=s.replace('pub property: PropertyId,','pub sink: Sink,')
p.write_text(s)
# Generalize cold binding accumulator only; public property functions still accept PropertyId.
p=base/'semantic.rs';s=p.read_text();s=s.replace('property: crate::property::PropertyId','property: crate::style_port::Sink').replace('binding.property','binding.sink').replace('Binding { property, signal }','Binding { sink: property, signal }').replace('MapBinding { property, operand }','MapBinding { sink: property, operand }')
s=s.replace('if property == crate::property::PropertyId::Background {','if property.property() == Some(crate::property::PropertyId::Background) {')
s=s.replace('self.unbind(crate::property::PropertyId::Background);','self.unbind(crate::property::PropertyId::Background.into());')
p.write_text(s)
# Existing property builder calls into the generalized private accumulator.
p=base/'element.rs';s=p.read_text();s=s.replace('.bind_map(id, operand);','.bind_map(id.into(), operand);').replace('.bind(id, signal);','.bind(id.into(), signal);').replace('value.unbind(id);','value.unbind(id.into());')
s=s.replace('self.bind_mapped_property(id, map);\n                if SIZE {\n                    self.bind_mapped_property(PropertyId::Height, map);','self.bind_mapped_property(id, map.clone());\n                if SIZE {\n                    self.bind_mapped_property(PropertyId::Height, map);')
# scalar install uses shared sink, changing local intrinsic values before Draft creation.
s=s.replace('let mut shape = shape.unwrap_or_default();','let mut shape = shape.unwrap_or_default();\n            let mut disabled = control.disabled;')
a=s.index('            for binding in bindings {');b=s.index('            if let Some(axes) = axes {',a)
s=s[:a]+'''            for binding in bindings {
                let value = binding.sink.admit(binding.signal.scalar())?;
                Self::apply_sink(binding.sink, value, &mut element, &mut disabled, &mut shape)?;
                style_ports.push(crate::style_port::Draft { node: index, sink: binding.sink, signal: binding.signal });
            }
            for binding in mapped {
                let value = binding.sink.admit(binding.operand.scalar()?)?;
                Self::apply_sink(binding.sink, value, &mut element, &mut disabled, &mut shape)?;
                mapped_ports.push(crate::style_port::MapDraft { node: index, sink: binding.sink, operand: binding.operand });
            }
''' +s[b:]
s=s.replace('            let disabled = control.disabled;\n','')
# shared direct semantic input path
start=s.index('    pub fn disabled(mut self, disabled: bool) -> Self {');end=s.index('    pub fn child',start)
s=s[:start]+'''    pub fn disabled(mut self, disabled: impl IntoProp<'a, bool>) -> Self {
        self.control_input(crate::style_port::Sink::DISABLED, disabled.into_prop());
        self
    }
    fn control_input(&mut self, sink: crate::style_port::Sink, input: crate::PropInput<'a, bool>) {
        assert!(matches!(self.kind, NodeKind::Input | NodeKind::Button | NodeKind::CheckBox(_)), "intrinsic state belongs to a semantic control");
        if let Some(value) = input.literal() {
            if let Some(extra) = &mut self.extra { extra.unbind(sink); }
            if sink == crate::style_port::Sink::CHECKED { self.kind = NodeKind::CheckBox(value); }
            else if value || self.extra.is_some() {
                self.extra.get_or_insert_with(|| Box::new(crate::semantic::ElementExtra::Semantic(Default::default()))).set_disabled(value);
            }
        } else if let Some(signal) = input.signal() {
            self.extra.get_or_insert_with(|| Box::new(crate::semantic::ElementExtra::Semantic(Default::default()))).bind(sink, signal);
        } else if let Some(map) = input.mapped() {
            self.extra.get_or_insert_with(|| Box::new(crate::semantic::ElementExtra::Semantic(Default::default()))).bind_map(sink, map);
        }
    }
    fn apply_sink(sink: crate::style_port::Sink, value: crate::PropertyValue, element: &mut Self, disabled: &mut bool, shape: &mut crate::property::GeometryStyle) -> Result<(), crate::Error> {
        if let Some(property) = sink.property() {
            match property.info().destination {
                crate::property::PropertyDestination::Style | crate::property::PropertyDestination::Paint => property.set_erased(&mut element.style, value)?,
                crate::property::PropertyDestination::Geometry => property.set_geometry(shape, value)?,
            }
        } else {
            let crate::PropertyValue::Flag(value) = value else { return Err(crate::Error::MapInput); };
            if sink == crate::style_port::Sink::CHECKED { element.kind = NodeKind::CheckBox(value); }
            else { *disabled = value; }
        }
        Ok(())
    }

''' +s[end:]
s=s.replace("pub fn checkbox<'a>(label: impl IntoText<'a>, checked: bool) -> El<'a> {\n    El::new(NodeKind::CheckBox(checked), Some(label.into_text()))\n}","pub fn checkbox<'a>(label: impl IntoText<'a>, checked: impl IntoProp<'a, bool>) -> El<'a> {\n    let mut element = El::new(NodeKind::CheckBox(false), Some(label.into_text()));\n    element.control_input(crate::style_port::Sink::CHECKED, checked.into_prop());\n    element\n}")
p.write_text(s)
p=base/'lib.rs';s=p.read_text().replace('pub use style_port::{IntoProp,','pub use style_port::{BoolInput, IntoProp,');p.write_text(s)
