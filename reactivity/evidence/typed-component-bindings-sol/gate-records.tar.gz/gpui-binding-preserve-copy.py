from pathlib import Path
b=Path('/root/gpui-typed-binding-sol-20261024/reactivity/crates/gpui/src')
p=b/'style_port.rs';s=p.read_text()
s=s.replace('''            recipe: PendingRecipe::new(move |input| map(input).map(Value::scalar)),''','''            recipe: Recipe::new(move |input| map(input).map(Value::scalar)),''',1)
s=s.replace('''    fn new<F>(map: F) -> Self
    where
        F: Fn(&dyn std::any::Any) -> Option<Scalar> + Copy + Send + Sync + 'static,
    {
        match Recipe::new(map) {
            Ok(recipe) => Self::Inline(recipe),
            Err(error) => Self::Rejected(error),
        }
    }
''','')
# Keep old Copy erased property operand. Only an El's cold owned map needs Select.
a=s.index('#[derive(Clone)]\npub(crate) struct MapOperand');z=s.index('/// Allocation-free source mapping.',a)
s=s[:a]+'''#[derive(Clone, Copy)]
pub(crate) struct MapOperand<'a> {
    pub signal: &'a dyn ErasedSignal,
    pub recipe: Result<Recipe, gpui_inline_call::TooLarge>,
}
impl MapOperand<'_> {
    pub fn scalar(self) -> Result<Scalar, crate::Error> {
        self.recipe.map_err(PendingRecipe::error)?.call(self.signal.as_any()).ok_or(crate::Error::MapInput)
    }
}
#[derive(Clone)]
pub(crate) struct OwnedMapOperand<'a> {
    pub signal: &'a dyn ErasedSignal,
    pub recipe: PendingRecipe,
}
impl OwnedMapOperand<'_> {
    pub fn scalar(&self) -> Result<Scalar, crate::Error> { self.recipe.scalar(self.signal.as_any()) }
}
impl<'a> From<MapOperand<'a>> for OwnedMapOperand<'a> {
    fn from(value: MapOperand<'a>) -> Self {
        Self { signal: value.signal, recipe: match value.recipe { Ok(recipe) => PendingRecipe::Inline(recipe), Err(error) => PendingRecipe::Rejected(error) } }
    }
}
/// A color operand, lowered by the shared foreground/background path. Ordinary
/// property operands remain Copy; explicitly erasing this new owned selection
/// family uses ColorInput, whose descriptor is consumed by the element.
pub struct ColorInput<'a>(ColorOperand<'a>);
pub(crate) enum ColorOperand<'a> {
    Property(PropInput<'a, Color>),
    Selection(OwnedMapOperand<'a>),
}
impl<'a> ColorInput<'a> {
    pub(crate) fn operand(self) -> ColorOperand<'a> { self.0 }
}
/// The closed solid-color input family, including typed boolean selections.
pub trait IntoColor<'a>: sealed::ColorInput {
    #[doc(hidden)]
    fn into_color(self) -> ColorInput<'a>;
}
impl<I: IntoProp<'_, Color>> sealed::ColorInput for I {}
impl<'a, I: IntoProp<'a, Color>> IntoColor<'a> for I {
    fn into_color(self) -> ColorInput<'a> { ColorInput(ColorOperand::Property(self.into_prop())) }
}
/// A concrete, Copy selection recipe. Its palette is owned by value until the
/// element consumes it; it never retains a borrow of an application theme.
pub struct SelectedColors<'a, F> {
    signal: &'a dyn ErasedSignal,
    map: F,
    colors: [Color; 2],
}
impl<F: Copy> Copy for SelectedColors<'_, F> {}
impl<F: Copy> Clone for SelectedColors<'_, F> { fn clone(&self) -> Self { *self } }
impl<F> sealed::ColorInput for SelectedColors<'_, F> {}
impl<'a, F> IntoColor<'a> for SelectedColors<'a, F>
where F: Fn(&dyn std::any::Any) -> Option<bool> + Copy + Send + Sync + 'static {
    fn into_color(self) -> ColorInput<'a> {
        let map = self.map;
        let build = gpui_inline_call::InlineCall::new(move |input: &dyn std::any::Any| {
            let codes = *input.downcast_ref::<[u32; 2]>().expect("internal palette pair");
            Recipe::new(move |input: &dyn std::any::Any| map(input).map(|flag| Scalar::ColorSlot(codes[usize::from(flag)])))
        });
        let recipe = match build { Ok(build) => PendingRecipe::Select(Box::new(ColorSelection { build, colors: self.colors })), Err(error) => PendingRecipe::Rejected(error) };
        ColorInput(ColorOperand::Selection(OwnedMapOperand { signal: self.signal, recipe }))
    }
}
''' +s[z:]
# BoolInput static output retained until color-specific lowering; no PropInput box.
a=s.index('pub trait BoolInput');z=s.index('/// Private destination tags',a)
s=s[:a]+'''pub trait BoolInput<'a>: IntoProp<'a, bool> + Copy {
    fn select(self, when_false: Color, when_true: Color) -> impl IntoColor<'a> + Copy;
}
impl<'a> BoolInput<'a> for bool {
    fn select(self, when_false: Color, when_true: Color) -> impl IntoColor<'a> + Copy { if self { when_true } else { when_false } }
}
impl<'a> BoolInput<'a> for &bool {
    fn select(self, when_false: Color, when_true: Color) -> impl IntoColor<'a> + Copy { (*self).select(when_false, when_true) }
}
impl<'a> BoolInput<'a> for &'a Signal<bool> {
    fn select(self, when_false: Color, when_true: Color) -> impl IntoColor<'a> + Copy {
        SelectedColors { signal: self, map: |input: &dyn std::any::Any| input.downcast_ref::<Signal<bool>>().map(|value| **value), colors: [when_false, when_true] }
    }
}
impl<'a, F> BoolInput<'a> for Mapped<'a, bool, F>
where F: Fn(&dyn std::any::Any) -> Option<bool> + Copy + Send + Sync + 'static {
    fn select(self, when_false: Color, when_true: Color) -> impl IntoColor<'a> + Copy { SelectedColors { signal: self.signal, map: self.map, colors: [when_false, when_true] } }
}
''' +s[z:]
s=s.replace("pub operand: MapOperand<'a>,","pub operand: OwnedMapOperand<'a>,")
s=s.replace('mod sealed {\n','mod sealed {\n    pub trait ColorInput {}\n',1)
s=s.replace('#[derive(Clone)]\npub struct PropInput','#[derive(Clone, Copy)]\npub struct PropInput').replace('#[derive(Clone)]\nenum Operand','#[derive(Clone, Copy)]\nenum Operand')
# Blanket bound lifetime cannot use placeholder in item bound; handled by higher lifetime below.
s=s.replace("impl<I: IntoProp<'_, Color>> sealed::ColorInput for I {}", "impl<'a, I: IntoProp<'a, Color>> sealed::ColorInput for I {}")
p.write_text(s)
# Shared accumulator owns map description, regardless of input family.
p=b/'semantic.rs';s=p.read_text().replace("operand: crate::style_port::MapOperand<'a>","operand: crate::style_port::OwnedMapOperand<'a>");p.write_text(s)
p=b/'element.rs';s=p.read_text().replace('radius.clone().mapped()', 'radius.mapped()').replace('clipped.clone().mapped()', 'clipped.mapped()').replace('self.bind_mapped_property(id, map.clone());','self.bind_mapped_property(id, map);')
s=s.replace('.bind_map(sink, map);','.bind_map(sink, map.into());')
old='''    fn bind_mapped_property(&mut self, id: PropertyId, operand: crate::style_port::MapOperand<'a>) {
        self.extra''';assert old in s
s=s.replace(old,'''    fn bind_mapped_property(&mut self, id: PropertyId, operand: crate::style_port::MapOperand<'a>) {
        self.bind_owned_map(id, operand.into());
    }
    fn bind_owned_map(&mut self, id: PropertyId, operand: crate::style_port::OwnedMapOperand<'a>) {
        self.extra''',1)
s=s.replace('''    pub fn fg(mut self, color: impl IntoProp<'a, Color>) -> Self {
        self.property_input::<{ PropertyId::Foreground as u16 }, false, Color, _>(color);
        self
    }''','''    fn color_input<const FOREGROUND: bool>(&mut self, color: impl crate::IntoColor<'a>) {
        match color.into_color().operand() {
            crate::style_port::ColorOperand::Property(input) => {
                if FOREGROUND { self.property_input::<{ PropertyId::Foreground as u16 }, false, Color, _>(input); }
                else { self.property_input::<{ PropertyId::Background as u16 }, false, Color, _>(input); }
            }
            crate::style_port::ColorOperand::Selection(operand) => self.bind_owned_map(if FOREGROUND { PropertyId::Foreground } else { PropertyId::Background }, operand),
        }
    }
    pub fn fg(mut self, color: impl crate::IntoColor<'a>) -> Self {
        self.color_input::<true>(color);
        self
    }''')
# Solid IntoBackground implementation shares the color-specific consumer.
s=s.replace("impl<'a, I: IntoProp<'a, Color>> IntoBackground<'a, background_shape::Solid> for I", "impl<'a, I: crate::IntoColor<'a>> IntoBackground<'a, background_shape::Solid> for I")
s=s.replace('element.property_input::<{ PropertyId::Background as u16 }, false, Color, _>(self);','element.color_input::<false>(self);')
p.write_text(s)
p=b/'lib.rs';s=p.read_text().replace('pub use style_port::{BoolInput, IntoProp, MapValue, Mapped, PropInput, SignalMap};','pub use style_port::{BoolInput, ColorInput, IntoColor, IntoProp, MapValue, Mapped, PropInput, SelectedColors, SignalMap};');p.write_text(s)
