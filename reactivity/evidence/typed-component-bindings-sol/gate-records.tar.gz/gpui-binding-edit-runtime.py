from pathlib import Path
base=Path('/root/gpui-typed-binding-sol-20261024/reactivity/crates/gpui/src')
p=base/'runtime/metadata.rs';s=p.read_text();needle='    pub fn packed(self) -> u32 {';i=s.index(needle);s=s[:i]+'''    pub fn sink(node: usize, sink: crate::style_port::Sink) -> Self {
        match sink.property() {
            Some(property) => Self::style(node, property),
            None => { assert!(node < MAX_NODES); Self((node as u32) << 15 | (sink.control_code() as u32) << 2) }
        }
    }
    pub fn control(self) -> Option<crate::style_port::Sink> {
        (self.port() == Port::Visual).then(|| crate::style_port::Sink::control(((self.0 >> 2) & 8191) as u16)).flatten()
    }
    pub fn target_sink(self) -> Option<crate::style_port::Sink> {
        self.property().map(Into::into).or_else(|| self.control())
    }
''' +s[i:];p.write_text(s)
p=base/'runtime/styles/colours.rs';s=p.read_text();i=s.index('    pub(in crate::runtime) fn register(&mut self,');s=s[:i]+'''    pub(in crate::runtime) fn literal_code(&mut self, color: Color) -> u32 { self.bank.literal(color).0 }
''' +s[i:];i=s.index('    pub(in crate::runtime) fn get(&self, slot: Slot)');s=s[:i]+'''    pub(in crate::runtime) fn literal_code(&self, code: u32) -> Color { assert!(code < SOURCE); self.get(Slot(code)) }
''' +s[i:];
# expose immutable bank lookup through Bound
pos=s.index('impl Bound {');s=s[:pos]+s[pos:].replace('impl Bound {','impl Bound {\n    pub(in crate::runtime) fn literal_code(&self, code: u32) -> Color { self.bank.literal_code(code) }',1);p.write_text(s)
p=base/'runtime/styles.rs';s=p.read_text();i=s.index('    /// Borrow ordinary lanes directly.');s=s[:i]+'''    pub(super) fn resolve_scalar(&self, scalar: crate::style_port::Scalar) -> crate::style_port::Scalar {
        match scalar {
            crate::style_port::Scalar::ColorSlot(code) => {
                let Self::Colors(values) = self else { unreachable!("selected color has owner color bank"); };
                crate::style_port::Scalar::Value(crate::PropertyValue::Color(values.literal_code(code)))
            }
            value => value,
        }
    }
''' +s[i:];p.write_text(s)
p=base/'runtime.rs';s=p.read_text();s=s.replace('const BITS: u32 = 23;\n    const DISABLED: u32 = 1 << (Self::BITS - 1);','const BITS: u32 = 24;\n    const DISABLED: u32 = 1 << 22;\n    const OWN_DISABLED: u32 = 1 << 23;\n    const FLAGS: u32 = Self::DISABLED | Self::OWN_DISABLED;\n    fn with_own_disabled(self, disabled: bool) -> Self {\n        Self((self.0 & !Self::OWN_DISABLED) | (u32::from(disabled) * Self::OWN_DISABLED))\n    }\n    fn own_disabled(self) -> bool { self.0 & Self::OWN_DISABLED != 0 }\n    fn with_checked(self, checked: bool) -> Self {\n        assert!(matches!(self.kind(), NodeKind::CheckBox(_)));\n        Self((self.0 & !15) | 8 | u32::from(checked))\n    }')
s=s.replace('(Content::BITS - 1 - 4)', '(Content::BITS - 2 - 4)').replace('self.0 & !Self::DISABLED) >> 4','self.0 & !Self::FLAGS) >> 4')
s=s.replace('.with_disabled(disabled);\n            if property_changed', '.with_own_disabled(draft.disabled).with_disabled(disabled);\n            if property_changed')
s=s.replace('fn map(&mut self, draft: crate::style_port::MapDraft<\'_>) -> Result<(), Error> {\n        let recipe = draft.operand.recipe()?;\n        let value = draft.operand.scalar()?.admit(draft.property)?;', 'fn map(&mut self, draft: crate::style_port::MapDraft<\'_>, colors: &mut styles::ColorDiscovery) -> Result<(), Error> {\n        let value = draft.sink.admit(draft.operand.scalar()?)?;\n        let recipe = draft.operand.recipe.lower(|color| colors.literal_code(color))?;')
s=s.replace('destination: Destination::style(draft.node as usize, draft.property),','destination: Destination::sink(draft.node as usize, draft.sink),')
s=s.replace("        field: FieldId,\n    ) -> Result<crate::source::Frozen<'a>, Error> {", "        field: FieldId,\n        styles: &styles::Styles,\n    ) -> Result<crate::source::Frozen<'a>, Error> {")
s=s.replace('if destination.port() == Port::Style {\n                needs.style', 'if destination.target_sink().is_some() {\n                needs.style')
a='''                *value = record
                    .recipe
                    .call(source)
                    .ok_or(BindError::TypeMismatch(field))?
                    .admit(record.destination.property().expect("mapped property"))?;'''
b='''                *value = record.destination.target_sink().expect("mapped sink").admit(styles.resolve_scalar(record.recipe.call(source).ok_or(BindError::TypeMismatch(field))?))?;'''
assert a in s;s=s.replace(a,b)
s=s.replace('if let Some(id) = destination.property() {\n                frozen.style.expect("style codec requested").admit(id)?;','if let Some(sink) = destination.target_sink() {\n                sink.admit(frozen.style.expect("scalar codec requested"))?;')
s=s.replace('        for draft in mapped_ports {','        let mut color_discovery = styles::ColorDiscovery::default();\n        for draft in mapped_ports {').replace('.map(draft)?;', '.map(draft, &mut color_discovery)?;')
s=s.replace('        let mut color_discovery = styles::ColorDiscovery::default();\n        for draft in style_ports {','        for draft in style_ports {')
# style input ports now include semantic boolean sinks
s=s.replace('draft.property,\n                        PropertyId::Foreground', 'draft.sink.property(),\n                        Some(PropertyId::Foreground')
# replace full color registration small block safely
start=s.index('                if !matches!(fanout.get(&field), Some(Fanout::Mapped(_)))');end=s.index('                let entry = fanout',start)
s=s[:start]+'''                if !matches!(fanout.get(&field), Some(Fanout::Mapped(_))) && matches!(draft.sink.property(), Some(PropertyId::Foreground | PropertyId::Background)) {
                    let foreground = draft.sink.property() == Some(PropertyId::Foreground);
                    let style = drafts[draft.node as usize].style;
                    color_discovery.register(field, if foreground { style.fg } else { style.bg });
                }
''' +s[end:]
s=s.replace('.push(Destination::style(draft.node as usize, draft.property));','.push(Destination::sink(draft.node as usize, draft.sink));')
s=s.replace('fanout.freeze(self.sources.signal(&self.model, field)?.as_any(), field)?','fanout.freeze(self.sources.signal(&self.model, field)?.as_any(), field, &self.styles)?')
s=s.replace('        let mut visual_changed = false;\n        let mut last_changed', '        let mut visual_changed = false;\n        let mut controls_changed = false;\n        let mut last_changed')
needle='''            let changed = if let Some(id) = destination.property() {'''
assert needle in s
s=s.replace(needle,'''            let changed = if let Some(control) = destination.control() {
                let crate::PropertyValue::Flag(value) = mapped_value.unwrap_or_else(|| match frozen.style { Some(crate::style_port::Scalar::Value(value)) => value, _ => unreachable!("admitted bool source") }) else { unreachable!("admitted bool sink"); };
                let before = node.content;
                let after = if control == crate::style_port::Sink::CHECKED { before.with_checked(value) } else { before.with_own_disabled(value) };
                let changed = before.0 != after.0;
                if changed {
                    self.nodes[index].content = after;
                    self.dirty = true;
                    visual_changed = true;
                    controls_changed = true;
                }
                changed
            } else if let Some(id) = destination.property() {''',1)
needle='''        Ok(if semantic && !visual_changed {'''
assert needle in s;s=s.replace(needle,'''        if controls_changed {
            for index in 0..self.nodes.len() {
                let node = &self.nodes[index];
                let disabled = node.content.own_disabled() || node.parent().index().is_some_and(|parent| self.nodes[parent].content.disabled());
                self.nodes[index].content = node.content.with_disabled(disabled);
            }
            self.prune_focus();
        }
        Ok(if semantic && !visual_changed {''',1)
p.write_text(s)
