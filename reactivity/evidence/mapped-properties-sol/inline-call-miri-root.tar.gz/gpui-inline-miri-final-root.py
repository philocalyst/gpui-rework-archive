from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

source = Path('/tmp/gpui-inline-miri-root')
evidence = Path('/tmp/gpui-inline-miri-root-evidence')
origin = Path('/tmp/gpui-mapped-properties-sol/reactivity/crates/inline-call/src/lib.rs')
body = origin.read_bytes()
old = (source / 'src/lib.rs').read_bytes()
assert old.split(b'#[cfg(test)]')[0] == body.split(b'#[cfg(test)]')[0]
(source / 'src/lib.rs').write_bytes(body)
assert origin.read_bytes() == body
subprocess.run(['git', '-C', str(source), 'add', 'src/lib.rs'], check=True)
subprocess.run(['git', '-C', str(source), 'commit', '-q', '-m',
                'Freeze final lint-clean helper tests with identical unsafe implementation'], check=True)
pin = subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True).strip()
(evidence / 'final-source-equivalence.json').write_text(json.dumps({
    'source_pin': pin, 'origin': str(origin), 'byte_identical': True,
    'sha256': hashlib.sha256(body).hexdigest(),
    'implementation_unchanged_from_first_qualification': True,
}, indent=2) + '\n')
results = []
for model, extra in [('stacked', ''), ('tree', ' -Zmiri-tree-borrows')]:
    for seed in range(8):
        env = dict(os.environ, MIRIFLAGS=f'-Zmiri-strict-provenance -Zmiri-seed={seed}{extra}')
        name = f'{model}-{seed}'
        status = subprocess.run([
            sys.executable, '/tmp/gpui-run-frozen-gate-root.py',
            '--source', str(source), '--pin', pin,
            '--out', str(evidence / name), '--timeout', '120',
            '--', 'cargo', 'miri', 'test', '--offline', '--locked', '--', '--test-threads=1',
        ], env=env).returncode
        result = json.loads((evidence / name / 'result.json').read_text())
        assert result['passed'] == 4 and result['failed'] == 0 and result['guards_match']
        results.append({'name': name, 'exit': status, 'result': result})
        (evidence / 'final-results.json').write_text(json.dumps(results, indent=2) + '\n')
        if status:
            raise SystemExit(status)
print(json.dumps({'invocations': len(results), 'tests_passed': sum(r['result']['passed'] for r in results),
                  'all_exit_zero': True, 'models': ['stacked', 'tree'], 'strict_provenance': True}), flush=True)
