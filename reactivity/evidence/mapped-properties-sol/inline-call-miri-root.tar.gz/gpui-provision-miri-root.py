from pathlib import Path
import hashlib
import json
import os
import subprocess
import tarfile
import tomllib

records = Path('/tmp/gpui-miri-provision-root')
records.mkdir(exist_ok=True)
prefix = Path('/tmp/gpui-miri-2026-10-23')
manifest = Path('/tmp/gpui-nightly-channel.toml')
data = tomllib.loads(manifest.read_text())
assert data['date'] == '2026-10-23'
entry = data['pkg']['miri-preview']['target']['x86_64-unknown-linux-gnu']
assert entry['available']
archive = records / entry['xz_url'].rsplit('/', 1)[1]
if not archive.exists():
    with (records / 'fetch.log').open('w') as log:
        subprocess.run(['curl', '--fail', '--location', '--max-time', '180',
                        '--output', str(archive), entry['xz_url']],
                       stdout=log, stderr=subprocess.STDOUT, timeout=190, check=True)
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert digest(archive) == entry['xz_hash']
unpacked = records / 'unpacked'
if not unpacked.exists():
    unpacked.mkdir()
    with tarfile.open(archive, 'r:xz') as bundle:
        bundle.extractall(unpacked, filter='data')
installers = list(unpacked.glob('*/install.sh'))
assert len(installers) == 1
if not prefix.exists():
    with (records / 'install.log').open('w') as log:
        subprocess.run(['bash', str(installers[0]), '--prefix=' + str(prefix),
                        '--disable-ldconfig'], stdout=log, stderr=subprocess.STDOUT,
                       timeout=60, check=True)
patchelf = '/nix/store/if2h609psbpg1ysf1m27dpshjk2wzpk4-patchelf-0.15.2/bin/patchelf'
objcopy = '/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/objcopy'
loader = '/nix/store/znb3q6g1ik34454j3vcjx824h1871asg-glibc-2.42-84/lib/ld-linux-x86-64.so.2'
libraries = [
    '/tmp/gpui-nightly-2026-10-23/lib',
    '/nix/store/znb3q6g1ik34454j3vcjx824h1871asg-glibc-2.42-84/lib',
    '/nix/store/hna4zsz4rdnl4mdbmwmks7cx3cdkkyqc-xgcc-15.3.0-libgcc/lib',
    '/nix/store/2ga5nd1m56n5cx2wh8vbf6nrdhqk2f0q-gcc-15.3.0-lib/lib',
    '/nix/store/b2swxfi8srrbsafvh9iyyhd26mz9giwf-zlib-1.3.2/lib',
]
adapted = []
env = dict(os.environ, RUSTC='/tmp/gpui-nightly-2026-10-23/bin/rustc')
for binary in sorted((prefix / 'bin').iterdir()):
    before = digest(binary)
    text_before = records / (binary.name + '.text.before')
    subprocess.run([objcopy, '--dump-section', '.text=' + str(text_before), str(binary)], check=True)
    subprocess.run([patchelf, '--set-interpreter', loader, str(binary)], check=True)
    subprocess.run([patchelf, '--set-rpath', ':'.join(libraries), str(binary)], check=True)
    text_after = records / (binary.name + '.text.after')
    subprocess.run([objcopy, '--dump-section', '.text=' + str(text_after), str(binary)], check=True)
    assert digest(text_before) == digest(text_after)
    arguments = ['miri', '--version'] if binary.name == 'cargo-miri' else ['--version']
    version = subprocess.check_output([str(binary), *arguments], text=True, env=env).strip()
    adapted.append({'path': str(binary), 'original_sha256': before,
                    'adapted_sha256': digest(binary), 'text_sha256': digest(text_after),
                    'text_unchanged': True, 'version': version})
report = {'prefix': str(prefix), 'official_url': entry['xz_url'],
          'official_archive_sha256': digest(archive),
          'manifest_sha256': digest(manifest), 'files': adapted,
          'scope': 'Only isolated Miri ELF interpreter/RPATH adapted; existing toolchain untouched.'}
(records / 'receipt.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report), flush=True)
