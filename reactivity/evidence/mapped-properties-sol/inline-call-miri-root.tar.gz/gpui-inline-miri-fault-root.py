from pathlib import Path
import json
import subprocess

source = Path('/tmp/gpui-inline-miri-root')
fault = Path('/tmp/gpui-inline-miri-fault-root')
subprocess.run(['git', '-C', str(source), 'worktree', 'add', '--detach', str(fault),
                '817a0cd3a39851a08e52c86f3d7a3a48b4dcba97'], check=True,
               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
path = fault / 'src/lib.rs'
body = path.read_text()
needle = 'size_of::<F>() > size_of::<Payload>()'
assert body.count(needle) == 1
path.write_text(body.replace(needle, 'size_of::<F>() > 2 * size_of::<Payload>()'))
subprocess.run(['git', '-C', str(fault), 'add', 'src/lib.rs'], check=True)
subprocess.run(['git', '-C', str(fault), 'commit', '-q', '-m',
                'Inject oversized callable admission for independent Miri fault control'], check=True)
pin = subprocess.check_output(['git', '-C', str(fault), 'rev-parse', 'HEAD'], text=True).strip()
Path('/tmp/gpui-inline-miri-root-evidence/fault-source.json').write_text(json.dumps({
    'source_pin': pin, 'qualified_parent': '817a0cd3a39851a08e52c86f3d7a3a48b4dcba97',
    'fault': 'Accept a 24-byte Copy callable into the 16-byte payload.'
}, indent=2) + '\n')
print(pin, flush=True)
