from pathlib import Path
import json
import subprocess

root = Path('/root/gpui-ce3')
git = ['git', '-c', f'safe.directory={root}', '-C', str(root)]
base = 'fea3dc224b440dd807cebd088cc959b8626668de'
source = '69aca81557374bb25142ab2f73a01b7e9358a545'
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == base
assert not subprocess.check_output(git + ['status', '--porcelain'], text=True).strip()
for name in ['build', 'strict', 'execute']:
    report = json.loads(Path(f'/tmp/gpui-todo-phase-{name}-root/result.json').read_text())
    assert report['source'] == source and report['exit'] == 0 and report['guards_match']
report = json.loads(Path('/tmp/gpui-todo-phase-executable-root/result.json').read_text())
assert [row['rows'] for row in report['results']] == [0, 1, 2, 1000, 10000]
assert all(row['exit'] == 0 and row['full_model_checkpoints'] == 9 for row in report['results'])
for name, expected in [('mutant', 101), ('old-oracle', 0)]:
    report = json.loads(Path(f'/tmp/gpui-todo-phase-{name}-executable-root/result.json').read_text())
    assert report['actual_exit'] == expected and report['expected_behavior_confirmed']
path = 'reactivity/crates/gpui/examples/todo_recording_cost.rs'
patch = subprocess.check_output(git + ['diff', '--binary', base, source, '--', path])
Path('/tmp/gpui-todo-phase-adoption-root.patch').write_bytes(patch)
subprocess.run(git + ['apply', '--check', '-'], input=patch, check=True)
subprocess.run(git + ['apply', '-'], input=patch, check=True)
assert (root / path).read_bytes() == subprocess.check_output(git + ['show', f'{source}:{path}'])
subprocess.run(git + ['add', '--', path], check=True)
message = Path('/tmp/gpui-todo-phase-adoption-commit-root.txt')
message.write_text('''Validate every acknowledged Todo model instead of only its final state

Active and Done can both be ignored while all callbacks and the eventual All
model remain correct. A final canonical-state assertion therefore cannot prove
the intermediate workload. Track an independent explicit expected model and
check ordinary source_json after mount, typing and each of seven actions.
Every row ID/title/completion, filter, draft, next ID and deleted payload is
compared. No application-private inspection or separate runtime is introduced.

Validation and expected-row construction stay outside edit/ACK allocation and
timing scopes; initial expected construction follows measured mount and ACK.
Extra oracle work and cache effects still change whole-process behavior. Keep
earlier recordings pinned to their original fixture and rerun matched variants
on this revision before drawing new timing or RSS conclusions.

The frozen source passes strict Clippy and all 45 full-model checkpoints over
0, 1, 2, 1,000 and 10,000 seeded rows through the actual release ELF. A bounded mutant
records every original filter callback but always retains All: the old actual
final-only fixture passes, while this fixture rejects Active with a semantic
assertion and exit 101. Actual executables and both controls remain preserved.

Shipping libraries, dependencies and native acceptance gates are unchanged.
The adopted whole Git tree equals the qualified 69aca815 tree byte for byte.
''')
subprocess.run(git + ['commit', '-F', str(message)], check=True)
assert subprocess.check_output(git + ['rev-parse', 'HEAD^{tree}']) == subprocess.check_output(git + ['rev-parse', f'{source}^{{tree}}'])
print(subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip())
