from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

root = Path('/root/gpui-ce3')
git = ['git', '-c', f'safe.directory={root}', '-C', str(root)]
adopted = 'ec6babe88c511efb9ba44406f19dc9d53c376d14'
qualified = '69aca81557374bb25142ab2f73a01b7e9358a545'
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == adopted
assert subprocess.check_output(git + ['rev-parse', f'{adopted}^{{tree}}']) == subprocess.check_output(git + ['rev-parse', f'{qualified}^{{tree}}'])
raw = Path('/tmp/gpui-todo-phase-capsule-root')
out = Path('/tmp/gpui-todo-phase-dossier-root')
raw.mkdir()
out.mkdir()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
executables = []
for label in ['build', 'strict', 'execute', 'executable', 'mutant-build', 'mutant-execute', 'mutant-executable', 'old-oracle-build', 'old-oracle-execute', 'old-oracle-executable']:
    source = Path(f'/tmp/gpui-todo-phase-{label}-root')
    for path in sorted(source.rglob('*')):
        if not path.is_file():
            continue
        if path.name == 'todo_recording_cost':
            executables.append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)})
            continue
        destination = raw / label / path.relative_to(source)
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
for path in [Path('/tmp/gpui-run-frozen-gate-root.py'), Path('/tmp/gpui-run-todo-phase-root.py'), Path('/tmp/gpui-run-todo-phase-mutant-root.py'), Path('/tmp/gpui-todo-phase-adoption-root.patch'), Path('/tmp/gpui-todo-phase-adoption-commit-root.txt'), Path('/tmp/gpui-adopt-todo-phase-root.py'), Path('/tmp/gpui-seal-todo-phase-root.py'), Path('/tmp/gpui-todo-phase-clean-root.stdout'), Path('/tmp/gpui-todo-phase-clean-root.stderr')]:
    shutil.copy2(path, raw / path.name)
for pin, name in [(qualified, 'qualified'), ('d586f55877789ed311de465eb963371e190d0f92', 'per-phase-mutant'), ('7b479bcb8713830ab234394b0702cf55685cf6f7', 'final-only-mutant')]:
    for source in ['reactivity/crates/gpui/examples/todo_recording_cost.rs', 'reactivity/crates/gpui/examples/support/todo_five.rs']:
        path = raw / 'source' / name / Path(source).name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(subprocess.check_output(git + ['show', f'{pin}:{source}']))
members = {str(path.relative_to(raw)): digest(path) for path in sorted(raw.rglob('*')) if path.is_file()}
(raw / 'manifest.json').write_text(json.dumps(members, indent=2) + '\n')
with tarfile.open(out / 'logs.tar.gz', 'w:gz', compresslevel=9) as archive:
    for path in sorted(raw.rglob('*')):
        if path.is_file():
            archive.add(path, arcname=str(path.relative_to(raw)), recursive=False)
with tarfile.open(out / 'logs.tar.gz') as archive:
    for name, expected in members.items():
        file = archive.extractfile(name)
        assert file and hashlib.sha256(file.read()).hexdigest() == expected
report = {
    'adopted_source': adopted,
    'qualified_source': qualified,
    'whole_git_trees_identical': True,
    'functional_results': json.loads(Path('/tmp/gpui-todo-phase-executable-root/result.json').read_text()),
    'strict': json.loads(Path('/tmp/gpui-todo-phase-strict-root/result.json').read_text()),
    'negative_controls': {label: json.loads(Path(f'/tmp/gpui-todo-phase-{label}-executable-root/result.json').read_text()) for label in ['mutant', 'old-oracle']},
    'source_guards': {'inputs': 2075, 'all_before_after_match': True},
    'shipping_cost': {'core_lines': 35863, 'shipping_line_delta': 0, 'library_or_dependency_changes': False},
    'logs': {'bytes': (out / 'logs.tar.gz').stat().st_size, 'sha256': digest(out / 'logs.tar.gz'), 'verified_metadata_members': len(members)},
    'actual_executables_external': executables,
    'limits': ['Recording functional evidence only, not native rendering or performance.', 'Expected model creation follows measured mount and initial ACK; later checks stay outside edit/ACK timers and counters.', 'Whole-process CPU/RSS and cache conditions change; previous fixture timing remains separately pinned.', 'Native ordered callback, drawable revision, presentation and latency gates remain unchanged and separately required.', 'The bounded wrong-filter mutant establishes one concrete detection improvement, not complete bug coverage.'],
}
assert all(row['full_model_checkpoints'] == 9 for row in report['functional_results']['results'])
assert report['negative_controls']['mutant']['actual_exit'] == 101
assert report['negative_controls']['old-oracle']['actual_exit'] == 0
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'out': str(out), 'logs': report['logs']}))
