from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--build', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
build = json.loads((args.build / 'result.json').read_text())
assert build['exit'] == 0
rows = [json.loads(line) for line in (args.build / 'stdout.log').read_text().splitlines()]
assert any(row.get('reason') == 'compiler-artifact' and row['target']['name'] == 'gpui' and not row['fresh'] for row in rows)
artifact, = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['target']['name'] == 'todo_recording_cost']
assert not artifact['fresh'] and artifact['profile']['opt_level'] == '3'
args.out.mkdir()
binary = args.out / 'todo_recording_cost'
shutil.copy2(artifact['executable'], binary)
binary.chmod(0o555)
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
(args.out / 'binary.json').write_text(json.dumps({'source': build['source'], 'sha256': digest, 'bytes': binary.stat().st_size, 'cargo': artifact}, indent=2) + '\n')
results = []
phases = ['mounted', 'typed', 'add', 'complete', 'active', 'done', 'all', 'delete', 'undo']
for count in [0, 1, 2, 1000, 10000]:
    with (args.out / f'rows-{count}.stdout').open('w') as stdout, (args.out / f'rows-{count}.stderr').open('w') as stderr:
        child = subprocess.run([str(binary), str(count)], stdout=stdout, stderr=stderr, timeout=180)
    output = (args.out / f'rows-{count}.stdout').read_text()
    states = [json.loads(line.split(',', 1)[1]) for line in output.splitlines() if line.startswith('TODO_RECORDING_STATE,')]
    assert child.returncode == 0 and hashlib.sha256(binary.read_bytes()).hexdigest() == digest
    assert [state['phase'] for state in states] == phases and all(state['full_model_validated'] for state in states)
    assert f'TODO_RECORDING_VALIDATED,rows={count + 1},operations=8' in output
    costs = [json.loads(line.split(',', 1)[1]) for line in output.splitlines() if line.startswith('TODO_RECORDING_COST,')]
    assert all(cost['success'] for cost in costs)
    row = {'rows': count, 'exit': child.returncode, 'full_model_checkpoints': len(states), 'operations': 8, 'binary_hash_matches': True}
    results.append(row)
    (args.out / 'result.json').write_text(json.dumps({'source': build['source'], 'binary_sha256': digest, 'results': results, 'scope': 'Functional ordinary recording fixture, validation outside per-edit and ACK timers; no paired performance claim.'}, indent=2) + '\n')
    print(json.dumps(row), flush=True)
