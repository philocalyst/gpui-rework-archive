from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--build', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
parser.add_argument('--oracle', choices=['per-phase', 'final-only'], required=True)
args = parser.parse_args()
build = json.loads((args.build / 'result.json').read_text())
assert build['exit'] == 0
rows = [json.loads(line) for line in (args.build / 'stdout.log').read_text().splitlines()]
artifact, = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['target']['name'] == 'todo_recording_cost']
assert not artifact['fresh'] and artifact['profile']['opt_level'] == '3'
args.out.mkdir()
binary = args.out / 'todo_recording_cost'
shutil.copy2(artifact['executable'], binary)
binary.chmod(0o555)
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
(args.out / 'binary.json').write_text(json.dumps({'source': build['source'], 'sha256': digest, 'bytes': binary.stat().st_size, 'cargo': artifact}, indent=2) + '\n')
with (args.out / 'stdout').open('w') as stdout, (args.out / 'stderr').open('w') as stderr:
    child = subprocess.run([str(binary), '2'], stdout=stdout, stderr=stderr, timeout=60)
output = (args.out / 'stdout').read_text()
error = (args.out / 'stderr').read_text()
if args.oracle == 'per-phase':
    assert child.returncode == 101 and 'canonical source after active' in error and 'assertion `left == right` failed' in error
    states = [json.loads(line.split(',', 1)[1]) for line in output.splitlines() if line.startswith('TODO_RECORDING_STATE,')]
    assert [state['phase'] for state in states] == ['mounted', 'typed', 'add', 'complete']
else:
    assert child.returncode == 0 and 'TODO_RECORDING_VALIDATED,rows=3,operations=8' in output
    actions = [json.loads(line.split(',', 1)[1])['action'] for line in error.splitlines() if line.startswith('TODO_ACTION,')]
    assert actions == ['add', 'complete', 'active', 'done', 'all', 'delete', 'undo']
assert hashlib.sha256(binary.read_bytes()).hexdigest() == digest
report = {'source': build['source'], 'oracle': args.oracle, 'actual_exit': child.returncode, 'expected_behavior_confirmed': True, 'binary_sha256': digest, 'scope': 'Bounded wrong-filter mutant preserves callbacks and final model; per-phase canonical source assertion must reject it.'}
(args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
