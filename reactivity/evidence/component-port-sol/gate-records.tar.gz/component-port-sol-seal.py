from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil
root=Path('/root/gpui-component-port-sol-20261024')
ev=root/'reactivity/evidence/component-port-sol'
ev.mkdir(parents=True,exist_ok=True)
assert not list(ev.iterdir())
py='/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3'
binutils=Path('/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin')
codegen={}
for kind,p in [('headless_release',Path('/root/targets/component-port-sol-release-20261024/release/examples/halloween')),('native_dev',Path('/root/targets/component-port-sol-native-20261024/debug/examples/halloween'))]:
 syms=subprocess.check_output([binutils/'nm','--demangle','--print-size','--size-sort',p],text=True)
 (ev/f'{kind}-symbols.txt').write_text(syms)
 sections={}
 for line in subprocess.check_output([binutils/'size','-A',p],text=True).splitlines():
  f=line.split()
  if len(f)==3 and f[0].startswith('.'): sections[f[0]]=int(f[1])
 chosen=[line for line in syms.splitlines() if 'gpui_component::' in line and len(line.split())>=4 and line.split()[2] in ('t','T')]
 codegen[kind]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'elf_bytes':p.stat().st_size,'sections':sections,'component_named_text_symbols':len(chosen),'component_named_text_bytes':sum(int(s.split()[1],16) for s in chosen),'attribution_limit':'Named symbols exclude inlined code and shared generic helpers; whole ELF and sections charge the dependency closure.'}
(ev/'codegen.json').write_text(json.dumps(codegen,indent=2)+'\n')
Path('/tmp/component-port-sol-codegen.json').write_text(json.dumps(codegen,indent=2)+'\n')
files={'feature-inventory.json':'feature-inventory.json','inventory-final.json':'shipping-inventory.json','release-costs-final.log':'allocations.log','metadata-ledger.log':'headers-and-ledger.log','toolchain.txt':'toolchain.txt','native-capture.json':'native-capture.json','native-run.log':'native-run.log','native-capture.py':'native-capture.py','headless-final.json':'headless-semantics.json','inputs.py':'input-guard.py','deps-headless.txt':'dependencies-headless.txt','deps-native.txt':'dependencies-native.txt','halloween-native-draft.png':'native-draft.png','halloween-native-focus.png':'native-focus.png','halloween-native-ready.png':'native-ready.png'}
for src,dst in files.items(): shutil.copyfile('/tmp/component-port-sol-'+src,ev/dst)
subprocess.run(['/nix/store/1zns14x0dv9krcnbznbxkqlj28jxmdcp-imagemagick-7.1.2-31/bin/magick','/tmp/component-port-sol-halloween-headless-final.ppm',str(ev/'headless.png')],check=True)
logs=[p for p in Path('/tmp').glob('component-port-sol-*') if p.is_file() and p.suffix in ('.log','.json','.jsonl','.txt','.py')]
with tarfile.open(ev/'gate-records.tar.gz','w:gz') as t:
 for p in sorted(logs):t.add(p,arcname=p.name)
 for p in sorted(Path('/tmp/component-port-sol-native-rejected').glob('*')):t.add(p,arcname='native-no-ack-rejected/'+p.name)
checks=[]
for kind in ('native','release'):
 rows=[json.loads(line) for line in Path(f'/tmp/component-port-sol-{kind}-artifacts-16.jsonl').read_text().splitlines() if line.startswith('{')]
 artifacts=[{'package_id':r['package_id'],'target':r['target']['name'],'kind':r['target']['kind'],'fresh':r['fresh'],'executable':r.get('executable')} for r in rows if r.get('reason')=='compiler-artifact' and (r['target']['name'] in ('gpui','gpui-component','halloween','costs'))]
 assert all(r['fresh'] for r in artifacts),artifacts
 assert rows[-1]['reason']=='build-finished' and rows[-1]['success']
 checks.append({'profile':kind,'artifacts':artifacts})
(ev/'cargo-freshness.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(codegen,indent=2))
