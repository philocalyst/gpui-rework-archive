from pathlib import Path
import re,json
reference=Path('/tmp/gpui-component-reference-root-20261024/crates/component/src/lib.rs')
modules=re.findall(r'^(?:pub )?mod (\w+);',reference.read_text(),re.M)
status={
 'button':('partial','Reusable command Button; sizes, semantic variants, disabled/focus, one replaceable activation route. ButtonGroup, dropdown, toggle/loading/tooltip compatibility APIs unported.'),
 'checkbox':('partial','Controlled binary Checkbox, explicit root/indicator/label parts, default Source<bool> toggle replaceable by owner intent callback. No mixed/indeterminate or legacy API compatibility.'),
 'input':('partial','Single-line writable Signal<String>, accessible name/description, disabled editing, frame/control parts, validation presentation. No password, mask, textarea/editor/number/OTP/autocomplete/context menu facades; IME is a separate lane.'),
 'label':('partial','Primary/secondary borrowed text and explicit instance recipe. No mask or highlight matching.'),
 'badge':('different_subset','Textual status badge; reference count/dot/icon overlay Badge contracts are not implemented.'),
 'form':('partial','Explicit Field label/control/help/error composition. No form engine or implicit descendant discovery.'),
 'theme':('partial','Application-owned semantic Oklch light/Halloween palettes, radius/font/spacing/size scales; static borrowed recipes. No global Theme compatibility surface, typography family catalog, shadows, motion or generic inspector theme schema.'),
 'sizing':('partial','Shared XSmall/Small/Medium/Large tokens used by Button/Input; not all reference sizing traits.'),
 'styled':('adapted','Ordinary El typed property builders + concrete FnOnce recipes; no duplicate per-control property catalog.'),
 'element_ext':('adapted','Core ordinary borrowed El composition; subset helpers only, no compatibility extension traits.'),
 'inspector':('runtime_reused','Existing Win/Window inspector used by actual application; closed14 typed style catalog remains explicit.'),
 'root':('runtime_reused','Exclusive Win root and contained Component<P,C> owner projections; no Entity/Root plugin architecture.'),
 'scroll':('runtime_only','Existing runtime scroll interfaces remain available; no styled Scrollbar family port.'),
 'virtual_list':('runtime_only','Existing runtime uniform_list remains available; no reference virtualization facade port.'),
}
rows=[]
for module in modules:
 st,detail=status.get(module,('unported','Not implemented in this port.'))
 rows.append({'reference_module':module,'status':st,'detail':detail})
out={'reference_repository':'https://github.com/gpui-ce/gpui-component','reference_revision':'c08206932417f863062d2ab70cc2854c6ca04238','scope':'Initial reusable foundation/control subset; not a drop-in source-compatible or all-components port.','reference_module_count':len(rows),'modules':rows,'new_modules':['recipe','layout'],'boundaries':{'style_reflection':'Existing closed14 typed properties only. El.disabled/focus_indicator and semantic Part.disabled are explicit separate APIs.','ordinary_use':'Macro-free concrete borrowed builders and FnOnce recipes. Erased PropertyValue remains at the existing deliberate inspector boundary.','ownership':'App-owned Signals and exclusive Win; builders borrow Theme. No new production Rc, Cell, RefCell, dynamic schema registry, per-control reflection table or TypeId map.'}}
Path('/tmp/component-port-sol-feature-inventory.json').write_text(json.dumps(out,indent=2)+'\n')
print('Reference modules inventoried:',len(rows))
