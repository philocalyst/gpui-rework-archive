from pathlib import Path
import os,sys,json,hashlib,subprocess,shutil,time
role=sys.argv[1]; assert role in ('control','candidate')
w=Path('/home/user/gpui-slot-chain-cost'+('-control' if role=='control' else '')+'-lab'); target=Path(str(w).replace('-lab','-target'))
r=Path(__file__).parent/(role+'-gate');r.mkdir(exist_ok=False)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def guard():return {n:sha(w/n) for n in subprocess.check_output(['git','ls-files','-z'],cwd=w).decode().split('\0') if n and (w/n).is_file()}
def save(n,v):(r/n).write_text(json.dumps(v,indent=2))
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w).strip()
assert not target.exists();assert shutil.disk_usage(w).free>=8*1024**3
before=guard();save('inputs-before.json',before);(r/'source.txt').write_bytes(subprocess.check_output(['git','rev-parse','HEAD'],cwd=w));(r/'toolchain.txt').write_bytes(subprocess.check_output(['rustc','+nightly-2026-10-23','-vV']))
env=dict(os.environ,CARGO_TARGET_DIR=str(target),CARGO_BUILD_JOBS='4',CARGO_INCREMENTAL='0',CARGO_PROFILE_RELEASE_DEBUG='0',VK_ICD_FILENAMES='/usr/share/vulkan/icd.d/lvp_icd.json',LP_NUM_THREADS='4',XDG_RUNTIME_DIR='/home/user/gpui-xdg')
save('environment.json',{k:env.get(k) for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_RELEASE_DEBUG','RUSTFLAGS','VK_ICD_FILENAMES','LP_NUM_THREADS','XDG_RUNTIME_DIR']})
def run(name,args,extra={}):
 start=time.time()
 with (r/(name+'.out')).open('wb') as out,(r/(name+'.err')).open('wb') as err:p=subprocess.run(args,cwd=w/'reactivity',env=dict(env,**extra),stdout=out,stderr=err)
 save(name+'.status.json',dict(args=args,exit=p.returncode,elapsed_seconds=time.time()-start));print(role,name,p.returncode,flush=True);assert p.returncode==0,name
prefix=['cargo','+nightly-2026-10-23','-Z','checksum-freshness','--config','build.fingerprint="content"'];common=['--locked','--offline','--release','-p','gpui','--no-default-features','--features','x11-minimal']
try:
 run('build',prefix+['test']+common+['--lib','--no-run','--message-format=json'])
 rows=[json.loads(line) for line in (r/'build.out').read_text().splitlines()]
 artifacts=[x for x in rows if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']=='gpui'];assert len(artifacts)==1 and not artifacts[0]['fresh']
 p=Path(artifacts[0]['executable']);h=sha(p);canonical=Path('/home/user/gpui-preserved-test-binaries')/h
 if not canonical.exists():shutil.copy2(p,canonical)
 assert sha(canonical)==h;save('artifact.json',dict(preserved=str(canonical),sha256=h,bytes=p.stat().st_size,cargo_fresh=artifacts[0]['fresh']))
 shaders={};elf=canonical.read_bytes()
 for p in (target/'release/build').rglob('ui.wgsl'):
  data=p.read_bytes();offset=elf.find(data)
  if offset>=0:shaders[str(p)]=dict(sha256=sha(p),bytes=len(data),elf_offset=offset);shutil.copy2(p,r/'ui.wgsl')
 assert shaders;save('shaders.json',shaders)
 for n in [1,9,32,256,1024]:
  for mode in ['single','coalesced','return-original']+(['geometry'] if n in [1,1024] else []):
   cell=f'{mode}-{n}';config=r/(cell+'.config.json');config.write_text(json.dumps(dict(n=n,mode=mode)))
   run('preflight-'+cell,[str(canonical),'native::slot_chain_cost::live_chain_cost','--exact','--ignored','--nocapture','--test-threads=1'],dict(GPUI_CHAIN_COST_CONFIG=str(config),GPUI_CHAIN_COST_OUTPUT=str(r/cell),GPUI_CHAIN_COST_PREFLIGHT='1'))
 run('clippy',prefix+['clippy']+common+['--all-targets','--','-D','warnings'])
finally:
 after=guard();save('guard.json',[n for n in before.keys()|after.keys() if before.get(n)!=after.get(n)]);save('disk.json',dict(free=shutil.disk_usage(w).free));assert before==after
