from pathlib import Path
import json,hashlib,shutil,sys
root=Path(__file__).parent;role=sys.argv[1];gate=root/(role+'-gate');target=Path('/home/user/gpui-slot-chain-cost'+('-control' if role=='control' else '')+'-target')
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert json.loads((gate/'guard.json').read_text())==[]
assert json.loads((gate/'clippy.status.json').read_text())['exit']==0
artifact=json.loads((gate/'artifact.json').read_text());assert sha(Path(artifact['preserved']))==artifact['sha256']
assert len(list(gate.glob('preflight-*.status.json')))==17
assert all(json.loads(p.read_text())['exit']==0 for p in gate.glob('*.status.json'))
files=[p for p in (target/'release/deps').iterdir() if p.is_file() and (p.suffix in ['.rmeta','.rlib','.so'] or (p.name.startswith('gpui-') and sha(p)==artifact['sha256']))]
files += [p for p in (target/'release/build').rglob('*') if p.is_file() and p.name.startswith('build-script-') and p.suffix!='.d']
plan=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
(root/(role+'-reclaim-plan.json')).write_text(json.dumps(plan,indent=2))
for p,entry in zip(files,plan):
 assert sha(p)==entry['sha256'];p.unlink()
(root/(role+'-reclaim.json')).write_text(json.dumps(dict(files=len(files),bytes=sum(x['bytes'] for x in plan),canonical_unchanged=sha(Path(artifact['preserved']))==artifact['sha256'],free=shutil.disk_usage(root).free),indent=2))
print(role,'reclaimed',sum(x['bytes'] for x in plan),'bytes; canonical ELF and evidence retained')
