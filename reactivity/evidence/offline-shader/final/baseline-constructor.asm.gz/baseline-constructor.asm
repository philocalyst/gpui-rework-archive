000000000016c470 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}>:
  16c470:	55                   	push   %rbp
  16c471:	41 57                	push   %r15
  16c473:	41 56                	push   %r14
  16c475:	41 55                	push   %r13
  16c477:	41 54                	push   %r12
  16c479:	53                   	push   %rbx
  16c47a:	48 81 ec b8 01 00 00 	sub    $0x1b8,%rsp
  16c481:	49 89 d7             	mov    %rdx,%r15
  16c484:	48 89 f3             	mov    %rsi,%rbx
  16c487:	49 89 fe             	mov    %rdi,%r14
  16c48a:	0f b6 46 63          	movzbl 0x63(%rsi),%eax
  16c48e:	48 8d 0d 2b 08 f1 ff 	lea    -0xef7d5(%rip),%rcx        # 7ccc0 <anon.fd4379edd0b71335c3c29b3337cd5ea0.200.llvm.353578272256937679+0x190>
  16c495:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  16c499:	48 01 c8             	add    %rcx,%rax
  16c49c:	ff e0                	jmp    *%rax
  16c49e:	66 c7 43 60 00 01    	movw   $0x100,0x60(%rbx)
  16c4a4:	c6 43 62 01          	movb   $0x1,0x62(%rbx)
  16c4a8:	48 8b 43 40          	mov    0x40(%rbx),%rax
  16c4ac:	0f 10 43 38          	movups 0x38(%rbx),%xmm0
  16c4b0:	0f 11 43 10          	movups %xmm0,0x10(%rbx)
  16c4b4:	48 8b 4b 54          	mov    0x54(%rbx),%rcx
  16c4b8:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
  16c4bc:	8b 53 5c             	mov    0x5c(%rbx),%edx
  16c4bf:	89 53 50             	mov    %edx,0x50(%rbx)
  16c4c2:	41 89 cc             	mov    %ecx,%r12d
  16c4c5:	49 83 fc 28          	cmp    $0x28,%r12
  16c4c9:	0f 87 e3 03 00 00    	ja     16c8b2 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x442>
  16c4cf:	48 b9 00 00 40 08 00 	movabs $0x10008400000,%rcx
  16c4d6:	01 00 00 
  16c4d9:	4c 0f a3 e1          	bt     %r12,%rcx
  16c4dd:	0f 83 cf 03 00 00    	jae    16c8b2 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x442>
  16c4e3:	4c 8d 63 10          	lea    0x10(%rbx),%r12
  16c4e7:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  16c4ec:	4c 89 e6             	mov    %r12,%rsi
  16c4ef:	ba 01 00 00 00       	mov    $0x1,%edx
  16c4f4:	ff 15 4e 3e 37 00    	call   *0x373e4e(%rip)        # 4e0348 <_DYNAMIC+0x300>
  16c4fa:	c6 43 60 01          	movb   $0x1,0x60(%rbx)
  16c4fe:	4c 8d 2d e5 5c f2 ff 	lea    -0xda31b(%rip),%r13        # 921ea <anon.61af28c3fe8c7804ff4d203082ca1370.12.llvm.12879250341671926273+0x25>
  16c505:	4c 89 ac 24 88 00 00 	mov    %r13,0x88(%rsp)
  16c50c:	00 
  16c50d:	48 c7 84 24 90 00 00 	movq   $0x14,0x90(%rsp)
  16c514:	00 14 00 00 00 
  16c519:	48 c7 44 24 70 ff ff 	movq   $0xffffffffffffffff,0x70(%rsp)
  16c520:	ff ff 
  16c522:	48 8d 05 d5 5c f2 ff 	lea    -0xda32b(%rip),%rax        # 921fe <anon.61af28c3fe8c7804ff4d203082ca1370.12.llvm.12879250341671926273+0x39>
  16c529:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  16c52e:	48 c7 84 24 80 00 00 	movq   $0x3b4c,0x80(%rsp)
  16c535:	00 4c 3b 00 00 
  16c53a:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
  16c53f:	4c 89 e7             	mov    %r12,%rdi
  16c542:	ff 15 08 3e 37 00    	call   *0x373e08(%rip)        # 4e0350 <_DYNAMIC+0x308>
  16c548:	48 8d 53 48          	lea    0x48(%rbx),%rdx
  16c54c:	48 8d 4b 20          	lea    0x20(%rbx),%rcx
  16c550:	48 89 43 20          	mov    %rax,0x20(%rbx)
  16c554:	8b 42 08             	mov    0x8(%rdx),%eax
  16c557:	89 44 24 30          	mov    %eax,0x30(%rsp)
  16c55b:	48 8b 02             	mov    (%rdx),%rax
  16c55e:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  16c563:	48 b8 ff ff ff ff 0f 	movabs $0xfffffffff,%rax
  16c56a:	00 00 00 
  16c56d:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  16c572:	4c 89 ac 24 f0 00 00 	mov    %r13,0xf0(%rsp)
  16c579:	00 
  16c57a:	48 c7 84 24 f8 00 00 	movq   $0x14,0xf8(%rsp)
  16c581:	00 14 00 00 00 
  16c586:	48 c7 84 24 00 01 00 	movq   $0x0,0x100(%rsp)
  16c58d:	00 00 00 00 00 
  16c592:	48 8d 05 b1 97 f2 ff 	lea    -0xd684f(%rip),%rax        # 95d4a <anon.61af28c3fe8c7804ff4d203082ca1370.12.llvm.12879250341671926273+0x3b85>
  16c599:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  16c5a0:	00 
  16c5a1:	48 c7 84 24 b8 00 00 	movq   $0x6,0xb8(%rsp)
  16c5a8:	00 06 00 00 00 
  16c5ad:	48 c7 84 24 c0 00 00 	movq   $0x8,0xc0(%rsp)
  16c5b4:	00 08 00 00 00 
  16c5b9:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  16c5c0:	00 00 00 00 00 
  16c5c5:	48 89 8c 24 d0 00 00 	mov    %rcx,0xd0(%rsp)
  16c5cc:	00 
  16c5cd:	48 c7 84 24 d8 00 00 	movq   $0x8,0xd8(%rsp)
  16c5d4:	00 08 00 00 00 
  16c5d9:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  16c5e0:	00 00 00 00 00 
  16c5e5:	c6 84 24 e8 00 00 00 	movb   $0x1,0xe8(%rsp)
  16c5ec:	01 
  16c5ed:	c7 84 24 80 01 00 00 	movl   $0x2,0x180(%rsp)
  16c5f4:	02 00 00 00 
  16c5f8:	c6 84 24 84 01 00 00 	movb   $0x0,0x184(%rsp)
  16c5ff:	00 
  16c600:	c7 84 24 88 01 00 00 	movl   $0x0,0x188(%rsp)
  16c607:	00 00 00 00 
  16c60b:	c6 84 24 8c 01 00 00 	movb   $0x0,0x18c(%rsp)
  16c612:	00 
  16c613:	c7 84 24 3c 01 00 00 	movl   $0x0,0x13c(%rsp)
  16c61a:	00 00 00 00 
  16c61e:	c7 84 24 10 01 00 00 	movl   $0x1,0x110(%rsp)
  16c625:	01 00 00 00 
  16c629:	48 c7 84 24 18 01 00 	movq   $0xffffffffffffffff,0x118(%rsp)
  16c630:	00 ff ff ff ff 
  16c635:	c6 84 24 20 01 00 00 	movb   $0x0,0x120(%rsp)
  16c63c:	00 
  16c63d:	48 8d 05 64 08 f1 ff 	lea    -0xef79c(%rip),%rax        # 7cea8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x18>
  16c644:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  16c649:	48 c7 44 24 78 08 00 	movq   $0x8,0x78(%rsp)
  16c650:	00 00 
  16c652:	48 8d 44 24 28       	lea    0x28(%rsp),%rax
  16c657:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  16c65e:	00 
  16c65f:	48 c7 84 24 88 00 00 	movq   $0x1,0x88(%rsp)
  16c666:	00 01 00 00 00 
  16c66b:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  16c672:	00 
  16c673:	48 c7 84 24 98 00 00 	movq   $0x8,0x98(%rsp)
  16c67a:	00 08 00 00 00 
  16c67f:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  16c686:	00 00 00 00 00 
  16c68b:	c6 84 24 a8 00 00 00 	movb   $0x1,0xa8(%rsp)
  16c692:	01 
  16c693:	0f 28 05 d6 fe f0 ff 	movaps -0xf012a(%rip),%xmm0        # 7c570 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x10>
  16c69a:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
  16c6a1:	00 
  16c6a2:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
  16c6a9:	00 00 00 00 00 
  16c6ae:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
  16c6b3:	4c 89 e7             	mov    %r12,%rdi
  16c6b6:	ff 15 9c 3c 37 00    	call   *0x373c9c(%rip)        # 4e0358 <_DYNAMIC+0x310>
  16c6bc:	48 8d 7b 28          	lea    0x28(%rbx),%rdi
  16c6c0:	48 89 43 28          	mov    %rax,0x28(%rbx)
  16c6c4:	31 f6                	xor    %esi,%esi
  16c6c6:	ff 15 94 3c 37 00    	call   *0x373c94(%rip)        # 4e0360 <_DYNAMIC+0x318>
  16c6cc:	48 89 43 30          	mov    %rax,0x30(%rbx)
  16c6d0:	c6 43 60 00          	movb   $0x0,0x60(%rbx)
  16c6d4:	0f 10 44 24 60       	movups 0x60(%rsp),%xmm0
  16c6d9:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  16c6de:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  16c6e3:	ff 15 7f 3c 37 00    	call   *0x373c7f(%rip)        # 4e0368 <_DYNAMIC+0x320>
  16c6e9:	48 89 c6             	mov    %rax,%rsi
  16c6ec:	48 89 d0             	mov    %rdx,%rax
  16c6ef:	48 89 33             	mov    %rsi,(%rbx)
  16c6f2:	48 89 43 08          	mov    %rax,0x8(%rbx)
  16c6f6:	eb 07                	jmp    16c6ff <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x28f>
  16c6f8:	48 8b 33             	mov    (%rbx),%rsi
  16c6fb:	48 8b 43 08          	mov    0x8(%rbx),%rax
  16c6ff:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  16c704:	4c 89 fa             	mov    %r15,%rdx
  16c707:	ff 50 18             	call   *0x18(%rax)
  16c70a:	4c 8b 64 24 70       	mov    0x70(%rsp),%r12
  16c70f:	49 83 fc fe          	cmp    $0xfffffffffffffffe,%r12
  16c713:	75 0f                	jne    16c724 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x2b4>
  16c715:	41 c7 46 20 fe ff ff 	movl   $0xfffffffe,0x20(%r14)
  16c71c:	ff 
  16c71d:	b0 03                	mov    $0x3,%al
  16c71f:	e9 e6 01 00 00       	jmp    16c90a <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x49a>
  16c724:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  16c72b:	00 
  16c72c:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  16c733:	00 
  16c734:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  16c739:	0f 10 8c 24 88 00 00 	movups 0x88(%rsp),%xmm1
  16c740:	00 
  16c741:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  16c748:	00 
  16c749:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  16c750:	00 
  16c751:	4c 8b 3b             	mov    (%rbx),%r15
  16c754:	4c 8b 6b 08          	mov    0x8(%rbx),%r13
  16c758:	49 8b 45 00          	mov    0x0(%r13),%rax
  16c75c:	48 85 c0             	test   %rax,%rax
  16c75f:	74 05                	je     16c766 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x2f6>
  16c761:	4c 89 ff             	mov    %r15,%rdi
  16c764:	ff d0                	call   *%rax
  16c766:	49 8b 75 08          	mov    0x8(%r13),%rsi
  16c76a:	48 85 f6             	test   %rsi,%rsi
  16c76d:	74 0d                	je     16c77c <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x30c>
  16c76f:	49 8b 55 10          	mov    0x10(%r13),%rdx
  16c773:	4c 89 ff             	mov    %r15,%rdi
  16c776:	ff 15 14 3b 37 00    	call   *0x373b14(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16c77c:	41 83 fc ff          	cmp    $0xffffffff,%r12d
  16c780:	0f 84 ee 00 00 00    	je     16c874 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x404>
  16c786:	4c 89 64 24 70       	mov    %r12,0x70(%rsp)
  16c78b:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  16c792:	00 
  16c793:	0f 28 8c 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm1
  16c79a:	00 
  16c79b:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
  16c7a0:	0f 11 8c 24 88 00 00 	movups %xmm1,0x88(%rsp)
  16c7a7:	00 
  16c7a8:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  16c7af:	00 
  16c7b0:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  16c7b7:	00 
  16c7b8:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  16c7bf:	00 00 
  16c7c1:	48 c7 44 24 18 01 00 	movq   $0x1,0x18(%rsp)
  16c7c8:	00 00 
  16c7ca:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  16c7d1:	00 00 
  16c7d3:	48 c7 44 24 38 20 00 	movq   $0x60000020,0x38(%rsp)
  16c7da:	00 60 
  16c7dc:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
  16c7e1:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  16c7e6:	48 8d 05 2b 82 34 00 	lea    0x34822b(%rip),%rax        # 4b4a18 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0x228>
  16c7ed:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  16c7f2:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  16c7f7:	48 8d 74 24 28       	lea    0x28(%rsp),%rsi
  16c7fc:	ff 15 6e 3b 37 00    	call   *0x373b6e(%rip)        # 4e0370 <_DYNAMIC+0x328>
  16c802:	84 c0                	test   %al,%al
  16c804:	0f 85 15 01 00 00    	jne    16c91f <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x4af>
  16c80a:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
  16c80f:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  16c814:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  16c819:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  16c81e:	e8 1d f8 ff ff       	call   16c040 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  16c823:	48 8b 43 30          	mov    0x30(%rbx),%rax
  16c827:	f0 48 ff 08          	lock decq (%rax)
  16c82b:	75 0a                	jne    16c837 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x3c7>
  16c82d:	48 8d 7b 30          	lea    0x30(%rbx),%rdi
  16c831:	ff 15 c1 3a 37 00    	call   *0x373ac1(%rip)        # 4e02f8 <_DYNAMIC+0x2b0>
  16c837:	48 8b 43 28          	mov    0x28(%rbx),%rax
  16c83b:	f0 48 ff 08          	lock decq (%rax)
  16c83f:	75 09                	jne    16c84a <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x3da>
  16c841:	48 8d 7b 28          	lea    0x28(%rbx),%rdi
  16c845:	e8 46 71 00 00       	call   173990 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  16c84a:	48 8b 43 20          	mov    0x20(%rbx),%rax
  16c84e:	f0 48 ff 08          	lock decq (%rax)
  16c852:	75 0a                	jne    16c85e <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x3ee>
  16c854:	48 8d 7b 20          	lea    0x20(%rbx),%rdi
  16c858:	ff 15 a2 3a 37 00    	call   *0x373aa2(%rip)        # 4e0300 <_DYNAMIC+0x2b8>
  16c85e:	c6 43 60 00          	movb   $0x0,0x60(%rbx)
  16c862:	48 8b 43 18          	mov    0x18(%rbx),%rax
  16c866:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  16c86c:	f0 48 ff 08          	lock decq (%rax)
  16c870:	74 52                	je     16c8c4 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x454>
  16c872:	eb 5a                	jmp    16c8ce <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x45e>
  16c874:	4c 8b 63 10          	mov    0x10(%rbx),%r12
  16c878:	4c 8b 7b 18          	mov    0x18(%rbx),%r15
  16c87c:	66 c7 43 61 00 00    	movw   $0x0,0x61(%rbx)
  16c882:	8b 6b 48             	mov    0x48(%rbx),%ebp
  16c885:	4c 8b 6b 4c          	mov    0x4c(%rbx),%r13
  16c889:	0f 10 43 28          	movups 0x28(%rbx),%xmm0
  16c88d:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  16c892:	48 8b 43 20          	mov    0x20(%rbx),%rax
  16c896:	f0 48 ff 08          	lock decq (%rax)
  16c89a:	75 0a                	jne    16c8a6 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x436>
  16c89c:	48 8d 7b 20          	lea    0x20(%rbx),%rdi
  16c8a0:	ff 15 5a 3a 37 00    	call   *0x373a5a(%rip)        # 4e0300 <_DYNAMIC+0x2b8>
  16c8a6:	c6 43 60 00          	movb   $0x0,0x60(%rbx)
  16c8aa:	66 c7 43 61 00 00    	movw   $0x0,0x61(%rbx)
  16c8b0:	eb 3d                	jmp    16c8ef <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x47f>
  16c8b2:	4c 8b 7b 4c          	mov    0x4c(%rbx),%r15
  16c8b6:	49 c1 e4 20          	shl    $0x20,%r12
  16c8ba:	49 83 cc 02          	or     $0x2,%r12
  16c8be:	f0 48 ff 08          	lock decq (%rax)
  16c8c2:	75 0a                	jne    16c8ce <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x45e>
  16c8c4:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
  16c8c8:	ff 15 3a 3a 37 00    	call   *0x373a3a(%rip)        # 4e0308 <_DYNAMIC+0x2c0>
  16c8ce:	c6 43 61 00          	movb   $0x0,0x61(%rbx)
  16c8d2:	48 8b 43 10          	mov    0x10(%rbx),%rax
  16c8d6:	f0 48 ff 08          	lock decq (%rax)
  16c8da:	75 0a                	jne    16c8e6 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x476>
  16c8dc:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
  16c8e0:	ff 15 2a 3a 37 00    	call   *0x373a2a(%rip)        # 4e0310 <_DYNAMIC+0x2c8>
  16c8e6:	c6 43 62 00          	movb   $0x0,0x62(%rbx)
  16c8ea:	bd ff ff ff ff       	mov    $0xffffffff,%ebp
  16c8ef:	4d 89 26             	mov    %r12,(%r14)
  16c8f2:	4d 89 7e 08          	mov    %r15,0x8(%r14)
  16c8f6:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  16c8fb:	41 0f 11 46 10       	movups %xmm0,0x10(%r14)
  16c900:	41 89 6e 20          	mov    %ebp,0x20(%r14)
  16c904:	4d 89 6e 24          	mov    %r13,0x24(%r14)
  16c908:	b0 01                	mov    $0x1,%al
  16c90a:	88 43 63             	mov    %al,0x63(%rbx)
  16c90d:	48 81 c4 b8 01 00 00 	add    $0x1b8,%rsp
  16c914:	5b                   	pop    %rbx
  16c915:	41 5c                	pop    %r12
  16c917:	41 5d                	pop    %r13
  16c919:	41 5e                	pop    %r14
  16c91b:	41 5f                	pop    %r15
  16c91d:	5d                   	pop    %rbp
  16c91e:	c3                   	ret
  16c91f:	48 8d 3d a9 99 f2 ff 	lea    -0xd6657(%rip),%rdi        # 962cf <anon.630a3fff68f6bca64b568be97512ab45.187.llvm.826976926275214120+0xb7>
  16c926:	48 8d 0d ab 7f 34 00 	lea    0x347fab(%rip),%rcx        # 4b48d8 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0xe8>
  16c92d:	4c 8d 05 14 81 34 00 	lea    0x348114(%rip),%r8        # 4b4a48 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0x258>
  16c934:	48 8d 54 24 0f       	lea    0xf(%rsp),%rdx
  16c939:	be 37 00 00 00       	mov    $0x37,%esi
  16c93e:	ff 15 34 3a 37 00    	call   *0x373a34(%rip)        # 4e0378 <_DYNAMIC+0x330>
  16c944:	0f 0b                	ud2
  16c946:	48 8d 3d eb 7e 34 00 	lea    0x347eeb(%rip),%rdi        # 4b4838 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0x48>
  16c94d:	ff 15 7d 39 37 00    	call   *0x37397d(%rip)        # 4e02d0 <_DYNAMIC+0x288>
  16c953:	48 8d 3d de 7e 34 00 	lea    0x347ede(%rip),%rdi        # 4b4838 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0x48>
  16c95a:	ff 15 68 39 37 00    	call   *0x373968(%rip)        # 4e02c8 <_DYNAMIC+0x280>
  16c960:	49 89 c6             	mov    %rax,%r14
  16c963:	e9 c1 00 00 00       	jmp    16ca29 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5b9>
  16c968:	49 89 c6             	mov    %rax,%r14
  16c96b:	e9 a6 00 00 00       	jmp    16ca16 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5a6>
  16c970:	49 89 c6             	mov    %rax,%r14
  16c973:	66 c7 43 62 00 02    	movw   $0x200,0x62(%rbx)
  16c979:	4c 89 f7             	mov    %r14,%rdi
  16c97c:	e8 4f 6d 34 00       	call   4b36d0 <_Unwind_Resume@plt>
  16c981:	49 89 c6             	mov    %rax,%r14
  16c984:	e9 e2 00 00 00       	jmp    16ca6b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5fb>
  16c989:	49 89 c6             	mov    %rax,%r14
  16c98c:	e9 ac 00 00 00       	jmp    16ca3d <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5cd>
  16c991:	eb 1b                	jmp    16c9ae <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x53e>
  16c993:	49 89 c6             	mov    %rax,%r14
  16c996:	49 8b 75 08          	mov    0x8(%r13),%rsi
  16c99a:	48 85 f6             	test   %rsi,%rsi
  16c99d:	74 63                	je     16ca02 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x592>
  16c99f:	49 8b 55 10          	mov    0x10(%r13),%rdx
  16c9a3:	4c 89 ff             	mov    %r15,%rdi
  16c9a6:	ff 15 e4 38 37 00    	call   *0x3738e4(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16c9ac:	eb 54                	jmp    16ca02 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x592>
  16c9ae:	49 89 c6             	mov    %rax,%r14
  16c9b1:	eb 4f                	jmp    16ca02 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x592>
  16c9b3:	49 89 c6             	mov    %rax,%r14
  16c9b6:	eb 5e                	jmp    16ca16 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5a6>
  16c9b8:	49 89 c6             	mov    %rax,%r14
  16c9bb:	eb 6c                	jmp    16ca29 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5b9>
  16c9bd:	49 89 c6             	mov    %rax,%r14
  16c9c0:	eb 7b                	jmp    16ca3d <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5cd>
  16c9c2:	49 89 c6             	mov    %rax,%r14
  16c9c5:	e9 83 00 00 00       	jmp    16ca4d <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5dd>
  16c9ca:	49 89 c6             	mov    %rax,%r14
  16c9cd:	48 8b 3b             	mov    (%rbx),%rdi
  16c9d0:	48 8b 73 08          	mov    0x8(%rbx),%rsi
  16c9d4:	e8 b7 e0 ff ff       	call   16aa90 <core::ptr::drop_glue::<core::pin::Pin<alloc::boxed::Box<dyn wgpu::dispatch::PopErrorScopeFuture<Output = core::option::Option<wgpu::api::device::Error>>>>>>
  16c9d9:	eb 27                	jmp    16ca02 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x592>
  16c9db:	49 89 c6             	mov    %rax,%r14
  16c9de:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  16c9e3:	48 85 f6             	test   %rsi,%rsi
  16c9e6:	74 10                	je     16c9f8 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x588>
  16c9e8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  16c9ed:	ba 01 00 00 00       	mov    $0x1,%edx
  16c9f2:	ff 15 98 38 37 00    	call   *0x373898(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16c9f8:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  16c9fd:	e8 3e f6 ff ff       	call   16c040 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  16ca02:	48 8b 43 30          	mov    0x30(%rbx),%rax
  16ca06:	f0 48 ff 08          	lock decq (%rax)
  16ca0a:	75 0a                	jne    16ca16 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5a6>
  16ca0c:	48 8d 7b 30          	lea    0x30(%rbx),%rdi
  16ca10:	ff 15 e2 38 37 00    	call   *0x3738e2(%rip)        # 4e02f8 <_DYNAMIC+0x2b0>
  16ca16:	48 8b 43 28          	mov    0x28(%rbx),%rax
  16ca1a:	f0 48 ff 08          	lock decq (%rax)
  16ca1e:	75 09                	jne    16ca29 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5b9>
  16ca20:	48 8d 7b 28          	lea    0x28(%rbx),%rdi
  16ca24:	e8 67 6f 00 00       	call   173990 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  16ca29:	48 8b 43 20          	mov    0x20(%rbx),%rax
  16ca2d:	f0 48 ff 08          	lock decq (%rax)
  16ca31:	75 0a                	jne    16ca3d <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5cd>
  16ca33:	48 8d 7b 20          	lea    0x20(%rbx),%rdi
  16ca37:	ff 15 c3 38 37 00    	call   *0x3738c3(%rip)        # 4e0300 <_DYNAMIC+0x2b8>
  16ca3d:	80 7b 60 00          	cmpb   $0x0,0x60(%rbx)
  16ca41:	74 0a                	je     16ca4d <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5dd>
  16ca43:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
  16ca48:	e8 e3 f1 ff ff       	call   16bc30 <core::ptr::drop_glue::<wgpu::api::device::ErrorScopeGuard>>
  16ca4d:	c6 43 60 00          	movb   $0x0,0x60(%rbx)
  16ca51:	80 7b 61 00          	cmpb   $0x0,0x61(%rbx)
  16ca55:	74 14                	je     16ca6b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5fb>
  16ca57:	48 8b 43 18          	mov    0x18(%rbx),%rax
  16ca5b:	f0 48 ff 08          	lock decq (%rax)
  16ca5f:	75 0a                	jne    16ca6b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5fb>
  16ca61:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
  16ca65:	ff 15 9d 38 37 00    	call   *0x37389d(%rip)        # 4e0308 <_DYNAMIC+0x2c0>
  16ca6b:	c6 43 61 00          	movb   $0x0,0x61(%rbx)
  16ca6f:	80 7b 62 00          	cmpb   $0x0,0x62(%rbx)
  16ca73:	74 14                	je     16ca89 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x619>
  16ca75:	48 8b 43 10          	mov    0x10(%rbx),%rax
  16ca79:	f0 48 ff 08          	lock decq (%rax)
  16ca7d:	75 0a                	jne    16ca89 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x619>
  16ca7f:	48 8d 7b 10          	lea    0x10(%rbx),%rdi
  16ca83:	ff 15 87 38 37 00    	call   *0x373887(%rip)        # 4e0310 <_DYNAMIC+0x2c8>
  16ca89:	66 c7 43 62 00 02    	movw   $0x200,0x62(%rbx)
  16ca8f:	4c 89 f7             	mov    %r14,%rdi
  16ca92:	e8 39 6c 34 00       	call   4b36d0 <_Unwind_Resume@plt>
  16ca97:	ff 15 43 38 37 00    	call   *0x373843(%rip)        # 4e02e0 <_DYNAMIC+0x298>
  16ca9d:	cc                   	int3
  16ca9e:	cc                   	int3
  16ca9f:	cc                   	int3

000000000016caa0 <first::main>:
  16caa0:	55                   	push   %rbp
  16caa1:	41 57                	push   %r15
  16caa3:	41 56                	push   %r14
  16caa5:	41 54                	push   %r12
  16caa7:	53                   	push   %rbx
  16caa8:	48 81 ec f0 07 00 00 	sub    $0x7f0,%rsp
  16caaf:	48 8d 9c 24 f0 00 00 	lea    0xf0(%rsp),%rbx
  16cab6:	00 
  16cab7:	48 89 df             	mov    %rbx,%rdi
  16caba:	ff 15 c0 38 37 00    	call   *0x3738c0(%rip)        # 4e0380 <_DYNAMIC+0x338>
  16cac0:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  16cac7:	00 
  16cac8:	48 89 de             	mov    %rbx,%rsi
  16cacb:	ff 15 b7 38 37 00    	call   *0x3738b7(%rip)        # 4e0388 <_DYNAMIC+0x340>
  16cad1:	48 8b b4 24 70 04 00 	mov    0x470(%rsp),%rsi
  16cad8:	00 
  16cad9:	48 85 f6             	test   %rsi,%rsi
  16cadc:	74 1d                	je     16cafb <first::main+0x5b>
  16cade:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  16cae2:	0f 84 39 08 00 00    	je     16d321 <first::main+0x881>
  16cae8:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  16caef:	00 
  16caf0:	ba 01 00 00 00       	mov    $0x1,%edx
  16caf5:	ff 15 95 37 37 00    	call   *0x373795(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16cafb:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  16cb02:	00 
  16cb03:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16cb0a:	00 
  16cb0b:	ff 15 77 38 37 00    	call   *0x373877(%rip)        # 4e0388 <_DYNAMIC+0x340>
  16cb11:	48 83 bc 24 70 04 00 	cmpq   $0xffffffffffffffff,0x470(%rsp)
  16cb18:	00 ff 
  16cb1a:	0f 84 01 08 00 00    	je     16d321 <first::main+0x881>
  16cb20:	4c 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%r15
  16cb27:	00 
  16cb28:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  16cb2f:	00 
  16cb30:	48 89 c8             	mov    %rcx,%rax
  16cb33:	4c 29 f8             	sub    %r15,%rax
  16cb36:	49 be ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r14
  16cb3d:	aa aa aa 
  16cb40:	49 f7 e6             	mul    %r14
  16cb43:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  16cb4a:	00 
  16cb4b:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  16cb50:	0f 10 84 24 70 04 00 	movups 0x470(%rsp),%xmm0
  16cb57:	00 
  16cb58:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  16cb5d:	4c 39 f9             	cmp    %r15,%rcx
  16cb60:	74 3d                	je     16cb9f <first::main+0xff>
  16cb62:	48 89 d3             	mov    %rdx,%rbx
  16cb65:	48 c1 eb 04          	shr    $0x4,%rbx
  16cb69:	49 83 c7 08          	add    $0x8,%r15
  16cb6d:	4c 8b 25 1c 37 37 00 	mov    0x37371c(%rip),%r12        # 4e0290 <_DYNAMIC+0x248>
  16cb74:	eb 13                	jmp    16cb89 <first::main+0xe9>
  16cb76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  16cb7d:	00 00 00 
  16cb80:	49 83 c7 18          	add    $0x18,%r15
  16cb84:	48 ff cb             	dec    %rbx
  16cb87:	74 16                	je     16cb9f <first::main+0xff>
  16cb89:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  16cb8d:	48 85 f6             	test   %rsi,%rsi
  16cb90:	74 ee                	je     16cb80 <first::main+0xe0>
  16cb92:	49 8b 3f             	mov    (%r15),%rdi
  16cb95:	ba 01 00 00 00       	mov    $0x1,%edx
  16cb9a:	41 ff d4             	call   *%r12
  16cb9d:	eb e1                	jmp    16cb80 <first::main+0xe0>
  16cb9f:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  16cba6:	00 
  16cba7:	48 85 c0             	test   %rax,%rax
  16cbaa:	74 1b                	je     16cbc7 <first::main+0x127>
  16cbac:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  16cbb3:	00 
  16cbb4:	48 c1 e0 03          	shl    $0x3,%rax
  16cbb8:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  16cbbc:	ba 08 00 00 00       	mov    $0x8,%edx
  16cbc1:	ff 15 c9 36 37 00    	call   *0x3736c9(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16cbc7:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  16cbce:	00 
  16cbcf:	ff 15 ab 37 37 00    	call   *0x3737ab(%rip)        # 4e0380 <_DYNAMIC+0x338>
  16cbd5:	48 8d 9c 24 70 04 00 	lea    0x470(%rsp),%rbx
  16cbdc:	00 
  16cbdd:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16cbe4:	00 
  16cbe5:	48 89 df             	mov    %rbx,%rdi
  16cbe8:	ff 15 9a 37 37 00    	call   *0x37379a(%rip)        # 4e0388 <_DYNAMIC+0x340>
  16cbee:	48 8b b4 24 70 04 00 	mov    0x470(%rsp),%rsi
  16cbf5:	00 
  16cbf6:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  16cbfa:	0f 84 ab 00 00 00    	je     16ccab <first::main+0x20b>
  16cc00:	48 85 f6             	test   %rsi,%rsi
  16cc03:	74 13                	je     16cc18 <first::main+0x178>
  16cc05:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  16cc0c:	00 
  16cc0d:	ba 01 00 00 00       	mov    $0x1,%edx
  16cc12:	ff 15 78 36 37 00    	call   *0x373678(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16cc18:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  16cc1f:	00 
  16cc20:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16cc27:	00 
  16cc28:	ff 15 5a 37 37 00    	call   *0x37375a(%rip)        # 4e0388 <_DYNAMIC+0x340>
  16cc2e:	48 8b b4 24 70 04 00 	mov    0x470(%rsp),%rsi
  16cc35:	00 
  16cc36:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  16cc3a:	74 6f                	je     16ccab <first::main+0x20b>
  16cc3c:	48 85 f6             	test   %rsi,%rsi
  16cc3f:	74 13                	je     16cc54 <first::main+0x1b4>
  16cc41:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  16cc48:	00 
  16cc49:	ba 01 00 00 00       	mov    $0x1,%edx
  16cc4e:	ff 15 3c 36 37 00    	call   *0x37363c(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16cc54:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  16cc5b:	00 
  16cc5c:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16cc63:	00 
  16cc64:	ff 15 1e 37 37 00    	call   *0x37371e(%rip)        # 4e0388 <_DYNAMIC+0x340>
  16cc6a:	48 8b b4 24 70 04 00 	mov    0x470(%rsp),%rsi
  16cc71:	00 
  16cc72:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  16cc76:	74 38                	je     16ccb0 <first::main+0x210>
  16cc78:	48 83 bc 24 80 04 00 	cmpq   $0xa,0x480(%rsp)
  16cc7f:	00 0a 
  16cc81:	75 2d                	jne    16ccb0 <first::main+0x210>
  16cc83:	48 8b 84 24 78 04 00 	mov    0x478(%rsp),%rax
  16cc8a:	00 
  16cc8b:	48 b9 6e 6f 2d 66 65 	movabs $0x75746165662d6f6e,%rcx
  16cc92:	61 74 75 
  16cc95:	48 33 08             	xor    (%rax),%rcx
  16cc98:	0f b7 40 08          	movzwl 0x8(%rax),%eax
  16cc9c:	48 35 72 65 00 00    	xor    $0x6572,%rax
  16cca2:	48 09 c8             	or     %rcx,%rax
  16cca5:	40 0f 95 c5          	setne  %bpl
  16cca9:	eb 0e                	jmp    16ccb9 <first::main+0x219>
  16ccab:	40 b5 01             	mov    $0x1,%bpl
  16ccae:	eb 21                	jmp    16ccd1 <first::main+0x231>
  16ccb0:	40 b5 01             	mov    $0x1,%bpl
  16ccb3:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  16ccb7:	74 18                	je     16ccd1 <first::main+0x231>
  16ccb9:	48 85 f6             	test   %rsi,%rsi
  16ccbc:	74 13                	je     16ccd1 <first::main+0x231>
  16ccbe:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  16ccc5:	00 
  16ccc6:	ba 01 00 00 00       	mov    $0x1,%edx
  16cccb:	ff 15 bf 35 37 00    	call   *0x3735bf(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16ccd1:	4c 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%r15
  16ccd8:	00 
  16ccd9:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  16cce0:	00 
  16cce1:	48 89 c8             	mov    %rcx,%rax
  16cce4:	4c 29 f8             	sub    %r15,%rax
  16cce7:	49 f7 e6             	mul    %r14
  16ccea:	4c 39 f9             	cmp    %r15,%rcx
  16cced:	74 40                	je     16cd2f <first::main+0x28f>
  16ccef:	49 89 d6             	mov    %rdx,%r14
  16ccf2:	49 c1 ee 04          	shr    $0x4,%r14
  16ccf6:	49 83 c7 08          	add    $0x8,%r15
  16ccfa:	4c 8b 25 8f 35 37 00 	mov    0x37358f(%rip),%r12        # 4e0290 <_DYNAMIC+0x248>
  16cd01:	eb 16                	jmp    16cd19 <first::main+0x279>
  16cd03:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  16cd0a:	84 00 00 00 00 00 
  16cd10:	49 83 c7 18          	add    $0x18,%r15
  16cd14:	49 ff ce             	dec    %r14
  16cd17:	74 16                	je     16cd2f <first::main+0x28f>
  16cd19:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  16cd1d:	48 85 f6             	test   %rsi,%rsi
  16cd20:	74 ee                	je     16cd10 <first::main+0x270>
  16cd22:	49 8b 3f             	mov    (%r15),%rdi
  16cd25:	ba 01 00 00 00       	mov    $0x1,%edx
  16cd2a:	41 ff d4             	call   *%r12
  16cd2d:	eb e1                	jmp    16cd10 <first::main+0x270>
  16cd2f:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  16cd36:	00 
  16cd37:	48 85 c0             	test   %rax,%rax
  16cd3a:	74 1b                	je     16cd57 <first::main+0x2b7>
  16cd3c:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  16cd43:	00 
  16cd44:	48 c1 e0 03          	shl    $0x3,%rax
  16cd48:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  16cd4c:	ba 08 00 00 00       	mov    $0x8,%edx
  16cd51:	ff 15 39 35 37 00    	call   *0x373539(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16cd57:	ff 15 33 36 37 00    	call   *0x373633(%rip)        # 4e0390 <_DYNAMIC+0x348>
  16cd5d:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  16cd62:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  16cd67:	40 84 ed             	test   %bpl,%bpl
  16cd6a:	74 28                	je     16cd94 <first::main+0x2f4>
  16cd6c:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  16cd71:	ff 15 21 36 37 00    	call   *0x373621(%rip)        # 4e0398 <_DYNAMIC+0x350>
  16cd77:	48 b9 00 00 00 00 00 	movabs $0x10000000000000,%rcx
  16cd7e:	00 10 00 
  16cd81:	48 21 c8             	and    %rcx,%rax
  16cd84:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  16cd89:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  16cd90:	00 00 
  16cd92:	eb 0a                	jmp    16cd9e <first::main+0x2fe>
  16cd94:	0f 57 c0             	xorps  %xmm0,%xmm0
  16cd97:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  16cd9c:	31 c0                	xor    %eax,%eax
  16cd9e:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
  16cda5:	00 00 00 00 00 
  16cdaa:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  16cdb1:	00 
  16cdb2:	48 c7 84 24 20 01 00 	movq   $0x0,0x120(%rsp)
  16cdb9:	00 00 00 00 00 
  16cdbe:	0f 28 05 7b d5 f0 ff 	movaps -0xf2a85(%rip),%xmm0        # 7a340 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0x1d0>
  16cdc5:	0f 11 84 24 28 01 00 	movups %xmm0,0x128(%rsp)
  16cdcc:	00 
  16cdcd:	0f 28 05 cc fd f0 ff 	movaps -0xf0234(%rip),%xmm0        # 7cba0 <anon.fd4379edd0b71335c3c29b3337cd5ea0.200.llvm.353578272256937679+0x70>
  16cdd4:	0f 11 84 24 38 01 00 	movups %xmm0,0x138(%rsp)
  16cddb:	00 
  16cddc:	0f 28 05 8d ea f0 ff 	movaps -0xf1573(%rip),%xmm0        # 7b870 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x130>
  16cde3:	0f 11 84 24 48 01 00 	movups %xmm0,0x148(%rsp)
  16cdea:	00 
  16cdeb:	f2 0f 10 05 3d e0 f0 	movsd  -0xf1fc3(%rip),%xmm0        # 7ae30 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x20>
  16cdf2:	ff 
  16cdf3:	0f 11 84 24 58 01 00 	movups %xmm0,0x158(%rsp)
  16cdfa:	00 
  16cdfb:	c7 84 24 68 01 00 00 	movl   $0x0,0x168(%rsp)
  16ce02:	00 00 00 00 
  16ce06:	48 c7 84 24 70 01 00 	movq   $0x10000,0x170(%rsp)
  16ce0d:	00 00 00 01 00 
  16ce12:	48 c7 84 24 78 01 00 	movq   $0x8000000,0x178(%rsp)
  16ce19:	00 00 00 00 08 
  16ce1e:	c7 84 24 80 01 00 00 	movl   $0x8,0x180(%rsp)
  16ce25:	08 00 00 00 
  16ce29:	48 c7 84 24 88 01 00 	movq   $0x10000000,0x188(%rsp)
  16ce30:	00 00 00 00 10 
  16ce35:	0f 28 05 c4 e4 f0 ff 	movaps -0xf1b3c(%rip),%xmm0        # 7b300 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0xb0>
  16ce3c:	0f 11 84 24 90 01 00 	movups %xmm0,0x190(%rsp)
  16ce43:	00 
  16ce44:	0f 28 05 85 e7 f0 ff 	movaps -0xf187b(%rip),%xmm0        # 7b5d0 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x380>
  16ce4b:	0f 11 84 24 a0 01 00 	movups %xmm0,0x1a0(%rsp)
  16ce52:	00 
  16ce53:	0f 28 05 26 f7 f0 ff 	movaps -0xf08da(%rip),%xmm0        # 7c580 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x20>
  16ce5a:	0f 11 84 24 b0 01 00 	movups %xmm0,0x1b0(%rsp)
  16ce61:	00 
  16ce62:	48 c7 84 24 c0 01 00 	movq   $0xffff,0x1c0(%rsp)
  16ce69:	00 ff ff 00 00 
  16ce6e:	c7 84 24 c8 01 00 00 	movl   $0xf4240,0x1c8(%rsp)
  16ce75:	40 42 0f 00 
  16ce79:	0f 57 c0             	xorps  %xmm0,%xmm0
  16ce7c:	0f 11 84 24 cc 01 00 	movups %xmm0,0x1cc(%rsp)
  16ce83:	00 
  16ce84:	0f 11 84 24 dc 01 00 	movups %xmm0,0x1dc(%rsp)
  16ce8b:	00 
  16ce8c:	0f 11 84 24 ec 01 00 	movups %xmm0,0x1ec(%rsp)
  16ce93:	00 
  16ce94:	0f 11 84 24 fc 01 00 	movups %xmm0,0x1fc(%rsp)
  16ce9b:	00 
  16ce9c:	c7 84 24 0c 02 00 00 	movl   $0x0,0x20c(%rsp)
  16cea3:	00 00 00 00 
  16cea7:	c7 84 24 10 02 00 00 	movl   $0x1c,0x210(%rsp)
  16ceae:	1c 00 00 00 
  16ceb2:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
  16ceb9:	00 00 00 00 00 
  16cebe:	48 c7 84 24 19 02 00 	movq   $0x0,0x219(%rsp)
  16cec5:	00 00 00 00 00 
  16ceca:	48 c7 84 24 14 02 00 	movq   $0x0,0x214(%rsp)
  16ced1:	00 00 00 00 00 
  16ced6:	4c 8d 7c 24 78       	lea    0x78(%rsp),%r15
  16cedb:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  16cee0:	48 8d 94 24 f0 00 00 	lea    0xf0(%rsp),%rdx
  16cee7:	00 
  16cee8:	4c 89 ff             	mov    %r15,%rdi
  16ceeb:	ff 15 af 34 37 00    	call   *0x3734af(%rip)        # 4e03a0 <_DYNAMIC+0x358>
  16cef1:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  16cef8:	00 
  16cef9:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
  16cf00:	00 
  16cf01:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  16cf06:	0f 10 8c 24 88 00 00 	movups 0x88(%rsp),%xmm1
  16cf0d:	00 
  16cf0e:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
  16cf15:	00 
  16cf16:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  16cf1d:	00 
  16cf1e:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  16cf23:	48 8d 35 36 89 34 00 	lea    0x348936(%rip),%rsi        # 4b5860 <anon.e1ff42821536cedf7a8930704368b812.1.llvm.14089006013123978678>
  16cf2a:	4c 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%r14
  16cf31:	00 
  16cf32:	48 8d 54 24 28       	lea    0x28(%rsp),%rdx
  16cf37:	4c 89 f7             	mov    %r14,%rdi
  16cf3a:	e8 81 d6 ff ff       	call   16a5c0 <<std::thread::local::LocalKey<core::task::wake::Waker>>::with::<pollster::block_on<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>::{closure#0}, core::result::Result<(wgpu::api::device::Device, wgpu::api::queue::Queue), wgpu::api::device::RequestDeviceError>>>
  16cf3f:	48 8d 9c 24 70 04 00 	lea    0x470(%rsp),%rbx
  16cf46:	00 
  16cf47:	48 89 df             	mov    %rbx,%rdi
  16cf4a:	e8 b1 56 00 00       	call   172600 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  16cf4f:	80 bc 24 a8 00 00 00 	cmpb   $0xff,0xa8(%rsp)
  16cf56:	ff 
  16cf57:	0f 85 00 04 00 00    	jne    16d35d <first::main+0x8bd>
  16cf5d:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  16cf64:	00 
  16cf65:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  16cf6c:	00 
  16cf6d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  16cf72:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  16cf77:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
  16cf7c:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  16cf83:	00 
  16cf84:	48 8d 05 75 16 00 00 	lea    0x1675(%rip),%rax        # 16e600 <<wgpu_types::features::Features as core::fmt::Debug>::fmt>
  16cf8b:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  16cf92:	00 
  16cf93:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
  16cf98:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  16cf9f:	00 
  16cfa0:	48 8d 05 39 16 00 00 	lea    0x1639(%rip),%rax        # 16e5e0 <<alloc::string::String as core::fmt::Display>::fmt>
  16cfa7:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  16cfae:	00 
  16cfaf:	48 8d 3d b3 c7 f1 ff 	lea    -0xe384d(%rip),%rdi        # 89769 <anon.8f7cdc0594fd4f0c7116fd8b126176fb.94.llvm.10099564126919119806+0x603>
  16cfb6:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16cfbd:	00 
  16cfbe:	ff 15 e4 33 37 00    	call   *0x3733e4(%rip)        # 4e03a8 <_DYNAMIC+0x360>
  16cfc4:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  16cfc9:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  16cfce:	48 83 f9 07          	cmp    $0x7,%rcx
  16cfd2:	0f 85 6e 01 00 00    	jne    16d146 <first::main+0x6a6>
  16cfd8:	b9 63 6f 6e 74       	mov    $0x746e6f63,%ecx
  16cfdd:	33 08                	xor    (%rax),%ecx
  16cfdf:	ba 74 65 78 74       	mov    $0x74786574,%edx
  16cfe4:	33 50 03             	xor    0x3(%rax),%edx
  16cfe7:	09 ca                	or     %ecx,%edx
  16cfe9:	0f 85 50 03 00 00    	jne    16d33f <first::main+0x89f>
  16cfef:	c7 84 24 98 00 00 00 	movl   $0xffffffff,0x98(%rsp)
  16cff6:	ff ff ff ff 
  16cffa:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
  16d001:	00 
  16d002:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  16d007:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  16d00e:	00 
  16d00f:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  16d014:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  16d01b:	00 
  16d01c:	4c 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%r14
  16d023:	00 
  16d024:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16d02b:	00 
  16d02c:	4c 89 f7             	mov    %r14,%rdi
  16d02f:	e8 7c 4a 00 00       	call   171ab0 <allocation_counter::measure::<first::capture<gpui_gpu::renderer::GpuContext, first::main::{closure#0}>::{closure#0}>>
  16d034:	48 c7 84 24 70 04 00 	movq   $0x30,0x470(%rsp)
  16d03b:	00 30 00 00 00 
  16d040:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
  16d047:	00 
  16d048:	4c 8d 3d d1 10 00 00 	lea    0x10d1(%rip),%r15        # 16e120 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  16d04f:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
  16d056:	00 
  16d057:	48 8d 05 2a 02 f1 ff 	lea    -0xefdd6(%rip),%rax        # 7d288 <anon.fd4379edd0b71335c3c29b3337cd5ea0.54.llvm.353578272256937679+0x18>
  16d05e:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  16d065:	00 
  16d066:	48 8b 05 43 33 37 00 	mov    0x373343(%rip),%rax        # 4e03b0 <_DYNAMIC+0x368>
  16d06d:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  16d074:	00 
  16d075:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
  16d07c:	00 
  16d07d:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  16d084:	00 
  16d085:	48 8d 3d 07 47 f2 ff 	lea    -0xdb8f9(%rip),%rdi        # 91793 <anon.64e6f0481017532cdf8621924f26dedf.26.llvm.17848240609198249692+0x551>
  16d08c:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16d093:	00 
  16d094:	ff 15 0e 33 37 00    	call   *0x37330e(%rip)        # 4e03a8 <_DYNAMIC+0x360>
  16d09a:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  16d09f:	0f 10 8c 24 88 00 00 	movups 0x88(%rsp),%xmm1
  16d0a6:	00 
  16d0a7:	0f 10 94 24 98 00 00 	movups 0x98(%rsp),%xmm2
  16d0ae:	00 
  16d0af:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
  16d0b6:	00 
  16d0b7:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
  16d0be:	00 
  16d0bf:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  16d0c6:	00 
  16d0c7:	4c 8d b4 24 70 04 00 	lea    0x470(%rsp),%r14
  16d0ce:	00 
  16d0cf:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16d0d6:	00 
  16d0d7:	4c 89 f7             	mov    %r14,%rdi
  16d0da:	e8 61 4d 00 00       	call   171e40 <allocation_counter::measure::<first::capture<gpui_gpu::renderer::GpuContext, first::main::{closure#0}>::{closure#1}>>
  16d0df:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
  16d0e6:	00 00 00 00 00 
  16d0eb:	c7 84 24 08 01 00 00 	movl   $0xffffffff,0x108(%rsp)
  16d0f2:	ff ff ff ff 
  16d0f6:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  16d0fb:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  16d100:	48 8d 9c 24 f0 00 00 	lea    0xf0(%rsp),%rbx
  16d107:	00 
  16d108:	48 89 da             	mov    %rbx,%rdx
  16d10b:	ff 15 a7 32 37 00    	call   *0x3732a7(%rip)        # 4e03b8 <_DYNAMIC+0x370>
  16d111:	83 7c 24 28 02       	cmpl   $0x2,0x28(%rsp)
  16d116:	0f 85 bb 02 00 00    	jne    16d3d7 <first::main+0x937>
  16d11c:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
  16d123:	00 
  16d124:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
  16d12b:	00 
  16d12c:	48 8d 3d 03 f0 f1 ff 	lea    -0xe0ffd(%rip),%rdi        # 8c136 <anon.068260129a360d3c14a88deb110120c9.55.llvm.7357624670875813013+0x552>
  16d133:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16d13a:	00 
  16d13b:	ff 15 67 32 37 00    	call   *0x373267(%rip)        # 4e03a8 <_DYNAMIC+0x360>
  16d141:	e9 59 01 00 00       	jmp    16d29f <first::main+0x7ff>
  16d146:	48 83 f9 08          	cmp    $0x8,%rcx
  16d14a:	0f 85 ef 01 00 00    	jne    16d33f <first::main+0x89f>
  16d150:	48 b9 72 65 6e 64 65 	movabs $0x72657265646e6572,%rcx
  16d157:	72 65 72 
  16d15a:	48 39 08             	cmp    %rcx,(%rax)
  16d15d:	0f 85 dc 01 00 00    	jne    16d33f <first::main+0x89f>
  16d163:	48 c7 84 24 70 04 00 	movq   $0xffffffffffffffff,0x470(%rsp)
  16d16a:	00 ff ff ff ff 
  16d16f:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
  16d176:	00 
  16d177:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  16d17c:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  16d183:	00 
  16d184:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  16d189:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  16d190:	00 
  16d191:	48 8d 5c 24 78       	lea    0x78(%rsp),%rbx
  16d196:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16d19d:	00 
  16d19e:	48 89 df             	mov    %rbx,%rdi
  16d1a1:	e8 ea 4d 00 00       	call   171f90 <allocation_counter::measure::<first::capture<gpui_gpu::renderer::Renderer, first::main::{closure#1}>::{closure#0}>>
  16d1a6:	48 c7 84 24 a8 00 00 	movq   $0x378,0xa8(%rsp)
  16d1ad:	00 78 03 00 00 
  16d1b2:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
  16d1b9:	00 
  16d1ba:	4c 8d 3d 5f 0f 00 00 	lea    0xf5f(%rip),%r15        # 16e120 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  16d1c1:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
  16d1c8:	00 
  16d1c9:	48 8d 05 28 04 f1 ff 	lea    -0xefbd8(%rip),%rax        # 7d5f8 <anon.fd4379edd0b71335c3c29b3337cd5ea0.173.llvm.353578272256937679+0x18>
  16d1d0:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  16d1d7:	00 
  16d1d8:	48 8b 05 d1 31 37 00 	mov    0x3731d1(%rip),%rax        # 4e03b0 <_DYNAMIC+0x368>
  16d1df:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  16d1e6:	00 
  16d1e7:	4c 89 b4 24 10 01 00 	mov    %r14,0x110(%rsp)
  16d1ee:	00 
  16d1ef:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  16d1f6:	00 
  16d1f7:	48 8d 3d 95 45 f2 ff 	lea    -0xdba6b(%rip),%rdi        # 91793 <anon.64e6f0481017532cdf8621924f26dedf.26.llvm.17848240609198249692+0x551>
  16d1fe:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16d205:	00 
  16d206:	ff 15 9c 31 37 00    	call   *0x37319c(%rip)        # 4e03a8 <_DYNAMIC+0x360>
  16d20c:	48 8d 9c 24 f0 00 00 	lea    0xf0(%rsp),%rbx
  16d213:	00 
  16d214:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  16d21b:	00 
  16d21c:	ba 78 03 00 00       	mov    $0x378,%edx
  16d221:	48 89 df             	mov    %rbx,%rdi
  16d224:	ff 15 c6 30 37 00    	call   *0x3730c6(%rip)        # 4e02f0 <memcpy@GLIBC_2.14>
  16d22a:	4c 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%r14
  16d231:	00 
  16d232:	4c 89 f7             	mov    %r14,%rdi
  16d235:	48 89 de             	mov    %rbx,%rsi
  16d238:	e8 83 50 00 00       	call   1722c0 <allocation_counter::measure::<first::capture<gpui_gpu::renderer::Renderer, first::main::{closure#1}>::{closure#1}>>
  16d23d:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
  16d244:	00 00 00 00 00 
  16d249:	c7 84 24 08 01 00 00 	movl   $0xffffffff,0x108(%rsp)
  16d250:	ff ff ff ff 
  16d254:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  16d259:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  16d25e:	48 8d 9c 24 f0 00 00 	lea    0xf0(%rsp),%rbx
  16d265:	00 
  16d266:	48 89 da             	mov    %rbx,%rdx
  16d269:	ff 15 49 31 37 00    	call   *0x373149(%rip)        # 4e03b8 <_DYNAMIC+0x370>
  16d26f:	83 7c 24 28 02       	cmpl   $0x2,0x28(%rsp)
  16d274:	0f 85 5d 01 00 00    	jne    16d3d7 <first::main+0x937>
  16d27a:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
  16d281:	00 
  16d282:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
  16d289:	00 
  16d28a:	48 8d 3d a5 ee f1 ff 	lea    -0xe115b(%rip),%rdi        # 8c136 <anon.068260129a360d3c14a88deb110120c9.55.llvm.7357624670875813013+0x552>
  16d291:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  16d298:	00 
  16d299:	ff 15 09 31 37 00    	call   *0x373109(%rip)        # 4e03a8 <_DYNAMIC+0x360>
  16d29f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  16d2a4:	f0 48 ff 08          	lock decq (%rax)
  16d2a8:	75 0b                	jne    16d2b5 <first::main+0x815>
  16d2aa:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  16d2af:	ff 15 53 30 37 00    	call   *0x373053(%rip)        # 4e0308 <_DYNAMIC+0x2c0>
  16d2b5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  16d2ba:	f0 48 ff 08          	lock decq (%rax)
  16d2be:	75 0b                	jne    16d2cb <first::main+0x82b>
  16d2c0:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  16d2c5:	ff 15 45 30 37 00    	call   *0x373045(%rip)        # 4e0310 <_DYNAMIC+0x2c8>
  16d2cb:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  16d2d0:	f0 48 ff 08          	lock decq (%rax)
  16d2d4:	75 0b                	jne    16d2e1 <first::main+0x841>
  16d2d6:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  16d2db:	ff 15 df 30 37 00    	call   *0x3730df(%rip)        # 4e03c0 <_DYNAMIC+0x378>
  16d2e1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  16d2e6:	f0 48 ff 08          	lock decq (%rax)
  16d2ea:	75 0b                	jne    16d2f7 <first::main+0x857>
  16d2ec:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  16d2f1:	ff 15 d1 30 37 00    	call   *0x3730d1(%rip)        # 4e03c8 <_DYNAMIC+0x380>
  16d2f7:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  16d2fc:	48 85 f6             	test   %rsi,%rsi
  16d2ff:	74 10                	je     16d311 <first::main+0x871>
  16d301:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  16d306:	ba 01 00 00 00       	mov    $0x1,%edx
  16d30b:	ff 15 7f 2f 37 00    	call   *0x372f7f(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16d311:	48 81 c4 f0 07 00 00 	add    $0x7f0,%rsp
  16d318:	5b                   	pop    %rbx
  16d319:	41 5c                	pop    %r12
  16d31b:	41 5e                	pop    %r14
  16d31d:	41 5f                	pop    %r15
  16d31f:	5d                   	pop    %rbp
  16d320:	c3                   	ret
  16d321:	48 8d 3d 44 8a f2 ff 	lea    -0xd75bc(%rip),%rdi        # 95d6c <anon.61af28c3fe8c7804ff4d203082ca1370.12.llvm.12879250341671926273+0x3ba7>
  16d328:	48 8d 15 51 75 34 00 	lea    0x347551(%rip),%rdx        # 4b4880 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0x90>
  16d32f:	be 13 00 00 00       	mov    $0x13,%esi
  16d334:	ff 15 96 30 37 00    	call   *0x373096(%rip)        # 4e03d0 <_DYNAMIC+0x388>
  16d33a:	e9 d5 00 00 00       	jmp    16d414 <first::main+0x974>
  16d33f:	48 8d 3d 0a 8a f2 ff 	lea    -0xd75f6(%rip),%rdi        # 95d50 <anon.61af28c3fe8c7804ff4d203082ca1370.12.llvm.12879250341671926273+0x3b8b>
  16d346:	48 8d 15 1b 75 34 00 	lea    0x34751b(%rip),%rdx        # 4b4868 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0x78>
  16d34d:	be 39 00 00 00       	mov    $0x39,%esi
  16d352:	ff 15 58 2f 37 00    	call   *0x372f58(%rip)        # 4e02b0 <_DYNAMIC+0x268>
  16d358:	e9 b7 00 00 00       	jmp    16d414 <first::main+0x974>
  16d35d:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  16d364:	00 
  16d365:	48 89 84 24 b0 04 00 	mov    %rax,0x4b0(%rsp)
  16d36c:	00 
  16d36d:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
  16d374:	00 
  16d375:	0f 10 8c 24 b8 00 00 	movups 0xb8(%rsp),%xmm1
  16d37c:	00 
  16d37d:	0f 10 94 24 c8 00 00 	movups 0xc8(%rsp),%xmm2
  16d384:	00 
  16d385:	0f 10 9c 24 d8 00 00 	movups 0xd8(%rsp),%xmm3
  16d38c:	00 
  16d38d:	0f 29 9c 24 a0 04 00 	movaps %xmm3,0x4a0(%rsp)
  16d394:	00 
  16d395:	0f 29 94 24 90 04 00 	movaps %xmm2,0x490(%rsp)
  16d39c:	00 
  16d39d:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
  16d3a4:	00 
  16d3a5:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  16d3ac:	00 
  16d3ad:	48 8d 3d cb 89 f2 ff 	lea    -0xd7635(%rip),%rdi        # 95d7f <anon.61af28c3fe8c7804ff4d203082ca1370.12.llvm.12879250341671926273+0x3bba>
  16d3b4:	48 8d 0d fd 74 34 00 	lea    0x3474fd(%rip),%rcx        # 4b48b8 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0xc8>
  16d3bb:	4c 8d 05 8e 74 34 00 	lea    0x34748e(%rip),%r8        # 4b4850 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0x60>
  16d3c2:	48 8d 94 24 70 04 00 	lea    0x470(%rsp),%rdx
  16d3c9:	00 
  16d3ca:	be 2b 00 00 00       	mov    $0x2b,%esi
  16d3cf:	ff 15 a3 2f 37 00    	call   *0x372fa3(%rip)        # 4e0378 <_DYNAMIC+0x330>
  16d3d5:	eb 3d                	jmp    16d414 <first::main+0x974>
  16d3d7:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  16d3dc:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  16d3e3:	00 
  16d3e4:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  16d3e9:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  16d3f0:	00 
  16d3f1:	48 8d 3d 87 89 f2 ff 	lea    -0xd7679(%rip),%rdi        # 95d7f <anon.61af28c3fe8c7804ff4d203082ca1370.12.llvm.12879250341671926273+0x3bba>
  16d3f8:	48 8d 0d 99 74 34 00 	lea    0x347499(%rip),%rcx        # 4b4898 <anon.61af28c3fe8c7804ff4d203082ca1370.18.llvm.12879250341671926273+0xa8>
  16d3ff:	4c 8d 05 12 73 34 00 	lea    0x347312(%rip),%r8        # 4b4718 <__frame_dummy_init_array_entry+0x8>
  16d406:	be 2b 00 00 00       	mov    $0x2b,%esi
  16d40b:	48 89 da             	mov    %rbx,%rdx
  16d40e:	ff 15 64 2f 37 00    	call   *0x372f64(%rip)        # 4e0378 <_DYNAMIC+0x330>
  16d414:	0f 0b                	ud2
  16d416:	eb 62                	jmp    16d47a <first::main+0x9da>
  16d418:	48 89 c3             	mov    %rax,%rbx
  16d41b:	e9 e5 00 00 00       	jmp    16d505 <first::main+0xa65>
  16d420:	48 89 c3             	mov    %rax,%rbx
  16d423:	e9 b1 00 00 00       	jmp    16d4d9 <first::main+0xa39>
  16d428:	48 89 c3             	mov    %rax,%rbx
  16d42b:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  16d432:	00 
  16d433:	e8 28 d7 ff ff       	call   16ab60 <core::ptr::drop_glue::<core::option::Option<gpui_gpu::renderer::Renderer>>>
  16d438:	e9 86 00 00 00       	jmp    16d4c3 <first::main+0xa23>
  16d43d:	ff 15 9d 2e 37 00    	call   *0x372e9d(%rip)        # 4e02e0 <_DYNAMIC+0x298>
  16d443:	48 89 c3             	mov    %rax,%rbx
  16d446:	83 bc 24 98 00 00 00 	cmpl   $0xffffffff,0x98(%rsp)
  16d44d:	ff 
  16d44e:	74 73                	je     16d4c3 <first::main+0xa23>
  16d450:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
  16d455:	e8 b6 df ff ff       	call   16b410 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>
  16d45a:	eb 67                	jmp    16d4c3 <first::main+0xa23>
  16d45c:	ff 15 7e 2e 37 00    	call   *0x372e7e(%rip)        # 4e02e0 <_DYNAMIC+0x298>
  16d462:	48 89 c3             	mov    %rax,%rbx
  16d465:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  16d46c:	00 
  16d46d:	e8 8e 51 00 00       	call   172600 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  16d472:	eb 7b                	jmp    16d4ef <first::main+0xa4f>
  16d474:	ff 15 66 2e 37 00    	call   *0x372e66(%rip)        # 4e02e0 <_DYNAMIC+0x298>
  16d47a:	48 89 c3             	mov    %rax,%rbx
  16d47d:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  16d484:	00 
  16d485:	e8 b6 41 00 00       	call   171640 <<alloc::vec::into_iter::IntoIter<std::ffi::os_str::OsString> as core::ops::drop::Drop>::drop>
  16d48a:	e9 8c 00 00 00       	jmp    16d51b <first::main+0xa7b>
  16d48f:	48 89 c3             	mov    %rax,%rbx
  16d492:	e9 84 00 00 00       	jmp    16d51b <first::main+0xa7b>
  16d497:	48 89 c3             	mov    %rax,%rbx
  16d49a:	eb 53                	jmp    16d4ef <first::main+0xa4f>
  16d49c:	48 89 c3             	mov    %rax,%rbx
  16d49f:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  16d4a6:	00 
  16d4a7:	e8 e4 e7 ff ff       	call   16bc90 <core::ptr::drop_glue::<wgpu::api::device::RequestDeviceError>>
  16d4ac:	eb 41                	jmp    16d4ef <first::main+0xa4f>
  16d4ae:	48 89 c3             	mov    %rax,%rbx
  16d4b1:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  16d4b8:	00 
  16d4b9:	e8 82 41 00 00       	call   171640 <<alloc::vec::into_iter::IntoIter<std::ffi::os_str::OsString> as core::ops::drop::Drop>::drop>
  16d4be:	eb 75                	jmp    16d535 <first::main+0xa95>
  16d4c0:	48 89 c3             	mov    %rax,%rbx
  16d4c3:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  16d4c8:	f0 48 ff 08          	lock decq (%rax)
  16d4cc:	75 0b                	jne    16d4d9 <first::main+0xa39>
  16d4ce:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  16d4d3:	ff 15 2f 2e 37 00    	call   *0x372e2f(%rip)        # 4e0308 <_DYNAMIC+0x2c0>
  16d4d9:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  16d4de:	f0 48 ff 08          	lock decq (%rax)
  16d4e2:	75 0b                	jne    16d4ef <first::main+0xa4f>
  16d4e4:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  16d4e9:	ff 15 21 2e 37 00    	call   *0x372e21(%rip)        # 4e0310 <_DYNAMIC+0x2c8>
  16d4ef:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  16d4f4:	f0 48 ff 08          	lock decq (%rax)
  16d4f8:	75 0b                	jne    16d505 <first::main+0xa65>
  16d4fa:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  16d4ff:	ff 15 bb 2e 37 00    	call   *0x372ebb(%rip)        # 4e03c0 <_DYNAMIC+0x378>
  16d505:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  16d50a:	f0 48 ff 08          	lock decq (%rax)
  16d50e:	75 0b                	jne    16d51b <first::main+0xa7b>
  16d510:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  16d515:	ff 15 ad 2e 37 00    	call   *0x372ead(%rip)        # 4e03c8 <_DYNAMIC+0x380>
  16d51b:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  16d520:	48 85 f6             	test   %rsi,%rsi
  16d523:	74 10                	je     16d535 <first::main+0xa95>
  16d525:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  16d52a:	ba 01 00 00 00       	mov    $0x1,%edx
  16d52f:	ff 15 5b 2d 37 00    	call   *0x372d5b(%rip)        # 4e0290 <_DYNAMIC+0x248>
  16d535:	48 89 df             	mov    %rbx,%rdi
  16d538:	e8 93 61 34 00       	call   4b36d0 <_Unwind_Resume@plt>
  16d53d:	ff 15 9d 2d 37 00    	call   *0x372d9d(%rip)        # 4e02e0 <_DYNAMIC+0x298>
  16d543:	cc                   	int3
  16d544:	cc                   	int3
  16d545:	cc                   	int3
  16d546:	cc                   	int3
  16d547:	cc                   	int3
  16d548:	cc                   	int3
  16d549:	cc                   	int3
  16d54a:	cc                   	int3
  16d54b:	cc                   	int3
  16d54c:	cc                   	int3
  16d54d:	cc                   	int3
  16d54e:	cc                   	int3
  16d54f:	cc                   	int3
