000000000019b440 <first::main>:
  19b440:	55                   	push   %rbp
  19b441:	41 57                	push   %r15
  19b443:	41 56                	push   %r14
  19b445:	41 54                	push   %r12
  19b447:	53                   	push   %rbx
  19b448:	48 81 ec f0 07 00 00 	sub    $0x7f0,%rsp
  19b44f:	48 8d 9c 24 f0 00 00 	lea    0xf0(%rsp),%rbx
  19b456:	00 
  19b457:	48 89 df             	mov    %rbx,%rdi
  19b45a:	ff 15 98 1f 37 00    	call   *0x371f98(%rip)        # 50d3f8 <_DYNAMIC+0x4c8>
  19b460:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  19b467:	00 
  19b468:	48 89 de             	mov    %rbx,%rsi
  19b46b:	ff 15 8f 1f 37 00    	call   *0x371f8f(%rip)        # 50d400 <_DYNAMIC+0x4d0>
  19b471:	48 8b b4 24 70 04 00 	mov    0x470(%rsp),%rsi
  19b478:	00 
  19b479:	48 85 f6             	test   %rsi,%rsi
  19b47c:	74 1d                	je     19b49b <first::main+0x5b>
  19b47e:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  19b482:	0f 84 39 08 00 00    	je     19bcc1 <first::main+0x881>
  19b488:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  19b48f:	00 
  19b490:	ba 01 00 00 00       	mov    $0x1,%edx
  19b495:	ff 15 dd 1c 37 00    	call   *0x371cdd(%rip)        # 50d178 <_DYNAMIC+0x248>
  19b49b:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  19b4a2:	00 
  19b4a3:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19b4aa:	00 
  19b4ab:	ff 15 4f 1f 37 00    	call   *0x371f4f(%rip)        # 50d400 <_DYNAMIC+0x4d0>
  19b4b1:	48 83 bc 24 70 04 00 	cmpq   $0xffffffffffffffff,0x470(%rsp)
  19b4b8:	00 ff 
  19b4ba:	0f 84 01 08 00 00    	je     19bcc1 <first::main+0x881>
  19b4c0:	4c 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%r15
  19b4c7:	00 
  19b4c8:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  19b4cf:	00 
  19b4d0:	48 89 c8             	mov    %rcx,%rax
  19b4d3:	4c 29 f8             	sub    %r15,%rax
  19b4d6:	49 be ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%r14
  19b4dd:	aa aa aa 
  19b4e0:	49 f7 e6             	mul    %r14
  19b4e3:	48 8b 84 24 80 04 00 	mov    0x480(%rsp),%rax
  19b4ea:	00 
  19b4eb:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  19b4f0:	0f 10 84 24 70 04 00 	movups 0x470(%rsp),%xmm0
  19b4f7:	00 
  19b4f8:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  19b4fd:	4c 39 f9             	cmp    %r15,%rcx
  19b500:	74 3d                	je     19b53f <first::main+0xff>
  19b502:	48 89 d3             	mov    %rdx,%rbx
  19b505:	48 c1 eb 04          	shr    $0x4,%rbx
  19b509:	49 83 c7 08          	add    $0x8,%r15
  19b50d:	4c 8b 25 64 1c 37 00 	mov    0x371c64(%rip),%r12        # 50d178 <_DYNAMIC+0x248>
  19b514:	eb 13                	jmp    19b529 <first::main+0xe9>
  19b516:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  19b51d:	00 00 00 
  19b520:	49 83 c7 18          	add    $0x18,%r15
  19b524:	48 ff cb             	dec    %rbx
  19b527:	74 16                	je     19b53f <first::main+0xff>
  19b529:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  19b52d:	48 85 f6             	test   %rsi,%rsi
  19b530:	74 ee                	je     19b520 <first::main+0xe0>
  19b532:	49 8b 3f             	mov    (%r15),%rdi
  19b535:	ba 01 00 00 00       	mov    $0x1,%edx
  19b53a:	41 ff d4             	call   *%r12
  19b53d:	eb e1                	jmp    19b520 <first::main+0xe0>
  19b53f:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  19b546:	00 
  19b547:	48 85 c0             	test   %rax,%rax
  19b54a:	74 1b                	je     19b567 <first::main+0x127>
  19b54c:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  19b553:	00 
  19b554:	48 c1 e0 03          	shl    $0x3,%rax
  19b558:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  19b55c:	ba 08 00 00 00       	mov    $0x8,%edx
  19b561:	ff 15 11 1c 37 00    	call   *0x371c11(%rip)        # 50d178 <_DYNAMIC+0x248>
  19b567:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  19b56e:	00 
  19b56f:	ff 15 83 1e 37 00    	call   *0x371e83(%rip)        # 50d3f8 <_DYNAMIC+0x4c8>
  19b575:	48 8d 9c 24 70 04 00 	lea    0x470(%rsp),%rbx
  19b57c:	00 
  19b57d:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19b584:	00 
  19b585:	48 89 df             	mov    %rbx,%rdi
  19b588:	ff 15 72 1e 37 00    	call   *0x371e72(%rip)        # 50d400 <_DYNAMIC+0x4d0>
  19b58e:	48 8b b4 24 70 04 00 	mov    0x470(%rsp),%rsi
  19b595:	00 
  19b596:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  19b59a:	0f 84 ab 00 00 00    	je     19b64b <first::main+0x20b>
  19b5a0:	48 85 f6             	test   %rsi,%rsi
  19b5a3:	74 13                	je     19b5b8 <first::main+0x178>
  19b5a5:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  19b5ac:	00 
  19b5ad:	ba 01 00 00 00       	mov    $0x1,%edx
  19b5b2:	ff 15 c0 1b 37 00    	call   *0x371bc0(%rip)        # 50d178 <_DYNAMIC+0x248>
  19b5b8:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  19b5bf:	00 
  19b5c0:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19b5c7:	00 
  19b5c8:	ff 15 32 1e 37 00    	call   *0x371e32(%rip)        # 50d400 <_DYNAMIC+0x4d0>
  19b5ce:	48 8b b4 24 70 04 00 	mov    0x470(%rsp),%rsi
  19b5d5:	00 
  19b5d6:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  19b5da:	74 6f                	je     19b64b <first::main+0x20b>
  19b5dc:	48 85 f6             	test   %rsi,%rsi
  19b5df:	74 13                	je     19b5f4 <first::main+0x1b4>
  19b5e1:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  19b5e8:	00 
  19b5e9:	ba 01 00 00 00       	mov    $0x1,%edx
  19b5ee:	ff 15 84 1b 37 00    	call   *0x371b84(%rip)        # 50d178 <_DYNAMIC+0x248>
  19b5f4:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  19b5fb:	00 
  19b5fc:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19b603:	00 
  19b604:	ff 15 f6 1d 37 00    	call   *0x371df6(%rip)        # 50d400 <_DYNAMIC+0x4d0>
  19b60a:	48 8b b4 24 70 04 00 	mov    0x470(%rsp),%rsi
  19b611:	00 
  19b612:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  19b616:	74 38                	je     19b650 <first::main+0x210>
  19b618:	48 83 bc 24 80 04 00 	cmpq   $0xa,0x480(%rsp)
  19b61f:	00 0a 
  19b621:	75 2d                	jne    19b650 <first::main+0x210>
  19b623:	48 8b 84 24 78 04 00 	mov    0x478(%rsp),%rax
  19b62a:	00 
  19b62b:	48 b9 6e 6f 2d 66 65 	movabs $0x75746165662d6f6e,%rcx
  19b632:	61 74 75 
  19b635:	48 33 08             	xor    (%rax),%rcx
  19b638:	0f b7 40 08          	movzwl 0x8(%rax),%eax
  19b63c:	48 35 72 65 00 00    	xor    $0x6572,%rax
  19b642:	48 09 c8             	or     %rcx,%rax
  19b645:	40 0f 95 c5          	setne  %bpl
  19b649:	eb 0e                	jmp    19b659 <first::main+0x219>
  19b64b:	40 b5 01             	mov    $0x1,%bpl
  19b64e:	eb 21                	jmp    19b671 <first::main+0x231>
  19b650:	40 b5 01             	mov    $0x1,%bpl
  19b653:	48 83 fe ff          	cmp    $0xffffffffffffffff,%rsi
  19b657:	74 18                	je     19b671 <first::main+0x231>
  19b659:	48 85 f6             	test   %rsi,%rsi
  19b65c:	74 13                	je     19b671 <first::main+0x231>
  19b65e:	48 8b bc 24 78 04 00 	mov    0x478(%rsp),%rdi
  19b665:	00 
  19b666:	ba 01 00 00 00       	mov    $0x1,%edx
  19b66b:	ff 15 07 1b 37 00    	call   *0x371b07(%rip)        # 50d178 <_DYNAMIC+0x248>
  19b671:	4c 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%r15
  19b678:	00 
  19b679:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
  19b680:	00 
  19b681:	48 89 c8             	mov    %rcx,%rax
  19b684:	4c 29 f8             	sub    %r15,%rax
  19b687:	49 f7 e6             	mul    %r14
  19b68a:	4c 39 f9             	cmp    %r15,%rcx
  19b68d:	74 40                	je     19b6cf <first::main+0x28f>
  19b68f:	49 89 d6             	mov    %rdx,%r14
  19b692:	49 c1 ee 04          	shr    $0x4,%r14
  19b696:	49 83 c7 08          	add    $0x8,%r15
  19b69a:	4c 8b 25 d7 1a 37 00 	mov    0x371ad7(%rip),%r12        # 50d178 <_DYNAMIC+0x248>
  19b6a1:	eb 16                	jmp    19b6b9 <first::main+0x279>
  19b6a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  19b6aa:	84 00 00 00 00 00 
  19b6b0:	49 83 c7 18          	add    $0x18,%r15
  19b6b4:	49 ff ce             	dec    %r14
  19b6b7:	74 16                	je     19b6cf <first::main+0x28f>
  19b6b9:	49 8b 77 f8          	mov    -0x8(%r15),%rsi
  19b6bd:	48 85 f6             	test   %rsi,%rsi
  19b6c0:	74 ee                	je     19b6b0 <first::main+0x270>
  19b6c2:	49 8b 3f             	mov    (%r15),%rdi
  19b6c5:	ba 01 00 00 00       	mov    $0x1,%edx
  19b6ca:	41 ff d4             	call   *%r12
  19b6cd:	eb e1                	jmp    19b6b0 <first::main+0x270>
  19b6cf:	48 8b 84 24 00 01 00 	mov    0x100(%rsp),%rax
  19b6d6:	00 
  19b6d7:	48 85 c0             	test   %rax,%rax
  19b6da:	74 1b                	je     19b6f7 <first::main+0x2b7>
  19b6dc:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
  19b6e3:	00 
  19b6e4:	48 c1 e0 03          	shl    $0x3,%rax
  19b6e8:	48 8d 34 40          	lea    (%rax,%rax,2),%rsi
  19b6ec:	ba 08 00 00 00       	mov    $0x8,%edx
  19b6f1:	ff 15 81 1a 37 00    	call   *0x371a81(%rip)        # 50d178 <_DYNAMIC+0x248>
  19b6f7:	ff 15 0b 1d 37 00    	call   *0x371d0b(%rip)        # 50d408 <_DYNAMIC+0x4d8>
  19b6fd:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  19b702:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  19b707:	40 84 ed             	test   %bpl,%bpl
  19b70a:	74 28                	je     19b734 <first::main+0x2f4>
  19b70c:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  19b711:	ff 15 f9 1c 37 00    	call   *0x371cf9(%rip)        # 50d410 <_DYNAMIC+0x4e0>
  19b717:	48 b9 00 00 00 00 00 	movabs $0x10000000000000,%rcx
  19b71e:	00 10 00 
  19b721:	48 21 c8             	and    %rcx,%rax
  19b724:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  19b729:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  19b730:	00 00 
  19b732:	eb 0a                	jmp    19b73e <first::main+0x2fe>
  19b734:	0f 57 c0             	xorps  %xmm0,%xmm0
  19b737:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  19b73c:	31 c0                	xor    %eax,%eax
  19b73e:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
  19b745:	00 00 00 00 00 
  19b74a:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  19b751:	00 
  19b752:	48 c7 84 24 20 01 00 	movq   $0x0,0x120(%rsp)
  19b759:	00 00 00 00 00 
  19b75e:	0f 28 05 ab 47 ef ff 	movaps -0x10b855(%rip),%xmm0        # 8ff10 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0x1f0>
  19b765:	0f 11 84 24 28 01 00 	movups %xmm0,0x128(%rsp)
  19b76c:	00 
  19b76d:	0f 28 05 ec 6f ef ff 	movaps -0x109014(%rip),%xmm0        # 92760 <anon.fd4379edd0b71335c3c29b3337cd5ea0.200.llvm.353578272256937679+0x70>
  19b774:	0f 11 84 24 38 01 00 	movups %xmm0,0x138(%rsp)
  19b77b:	00 
  19b77c:	0f 28 05 ad 5c ef ff 	movaps -0x10a353(%rip),%xmm0        # 91430 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x130>
  19b783:	0f 11 84 24 48 01 00 	movups %xmm0,0x148(%rsp)
  19b78a:	00 
  19b78b:	f2 0f 10 05 5d 52 ef 	movsd  -0x10ada3(%rip),%xmm0        # 909f0 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x20>
  19b792:	ff 
  19b793:	0f 11 84 24 58 01 00 	movups %xmm0,0x158(%rsp)
  19b79a:	00 
  19b79b:	c7 84 24 68 01 00 00 	movl   $0x0,0x168(%rsp)
  19b7a2:	00 00 00 00 
  19b7a6:	48 c7 84 24 70 01 00 	movq   $0x10000,0x170(%rsp)
  19b7ad:	00 00 00 01 00 
  19b7b2:	48 c7 84 24 78 01 00 	movq   $0x8000000,0x178(%rsp)
  19b7b9:	00 00 00 00 08 
  19b7be:	c7 84 24 80 01 00 00 	movl   $0x8,0x180(%rsp)
  19b7c5:	08 00 00 00 
  19b7c9:	48 c7 84 24 88 01 00 	movq   $0x10000000,0x188(%rsp)
  19b7d0:	00 00 00 00 10 
  19b7d5:	0f 28 05 f4 56 ef ff 	movaps -0x10a90c(%rip),%xmm0        # 90ed0 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0xc0>
  19b7dc:	0f 11 84 24 90 01 00 	movups %xmm0,0x190(%rsp)
  19b7e3:	00 
  19b7e4:	0f 28 05 b5 59 ef ff 	movaps -0x10a64b(%rip),%xmm0        # 911a0 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x390>
  19b7eb:	0f 11 84 24 a0 01 00 	movups %xmm0,0x1a0(%rsp)
  19b7f2:	00 
  19b7f3:	0f 28 05 36 69 ef ff 	movaps -0x1096ca(%rip),%xmm0        # 92130 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x10>
  19b7fa:	0f 11 84 24 b0 01 00 	movups %xmm0,0x1b0(%rsp)
  19b801:	00 
  19b802:	48 c7 84 24 c0 01 00 	movq   $0xffff,0x1c0(%rsp)
  19b809:	00 ff ff 00 00 
  19b80e:	c7 84 24 c8 01 00 00 	movl   $0xf4240,0x1c8(%rsp)
  19b815:	40 42 0f 00 
  19b819:	0f 57 c0             	xorps  %xmm0,%xmm0
  19b81c:	0f 11 84 24 cc 01 00 	movups %xmm0,0x1cc(%rsp)
  19b823:	00 
  19b824:	0f 11 84 24 dc 01 00 	movups %xmm0,0x1dc(%rsp)
  19b82b:	00 
  19b82c:	0f 11 84 24 ec 01 00 	movups %xmm0,0x1ec(%rsp)
  19b833:	00 
  19b834:	0f 11 84 24 fc 01 00 	movups %xmm0,0x1fc(%rsp)
  19b83b:	00 
  19b83c:	c7 84 24 0c 02 00 00 	movl   $0x0,0x20c(%rsp)
  19b843:	00 00 00 00 
  19b847:	c7 84 24 10 02 00 00 	movl   $0x1c,0x210(%rsp)
  19b84e:	1c 00 00 00 
  19b852:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
  19b859:	00 00 00 00 00 
  19b85e:	48 c7 84 24 19 02 00 	movq   $0x0,0x219(%rsp)
  19b865:	00 00 00 00 00 
  19b86a:	48 c7 84 24 14 02 00 	movq   $0x0,0x214(%rsp)
  19b871:	00 00 00 00 00 
  19b876:	4c 8d 7c 24 78       	lea    0x78(%rsp),%r15
  19b87b:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  19b880:	48 8d 94 24 f0 00 00 	lea    0xf0(%rsp),%rdx
  19b887:	00 
  19b888:	4c 89 ff             	mov    %r15,%rdi
  19b88b:	ff 15 87 1b 37 00    	call   *0x371b87(%rip)        # 50d418 <_DYNAMIC+0x4e8>
  19b891:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  19b898:	00 
  19b899:	48 89 84 24 90 04 00 	mov    %rax,0x490(%rsp)
  19b8a0:	00 
  19b8a1:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  19b8a6:	0f 10 8c 24 88 00 00 	movups 0x88(%rsp),%xmm1
  19b8ad:	00 
  19b8ae:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
  19b8b5:	00 
  19b8b6:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  19b8bd:	00 
  19b8be:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
  19b8c3:	48 8d 35 0e 72 34 00 	lea    0x34720e(%rip),%rsi        # 4e2ad8 <anon.bd81d6341d40e5d7397faad37186b22d.0.llvm.8757217068975972983>
  19b8ca:	4c 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%r14
  19b8d1:	00 
  19b8d2:	48 8d 54 24 28       	lea    0x28(%rsp),%rdx
  19b8d7:	4c 89 f7             	mov    %r14,%rdi
  19b8da:	e8 e1 1d 00 00       	call   19d6c0 <<std::thread::local::LocalKey<core::task::wake::Waker>>::with::<pollster::block_on<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>::{closure#0}, core::result::Result<(wgpu::api::device::Device, wgpu::api::queue::Queue), wgpu::api::device::RequestDeviceError>>>
  19b8df:	48 8d 9c 24 70 04 00 	lea    0x470(%rsp),%rbx
  19b8e6:	00 
  19b8e7:	48 89 df             	mov    %rbx,%rdi
  19b8ea:	e8 61 aa ff ff       	call   196350 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  19b8ef:	80 bc 24 a8 00 00 00 	cmpb   $0xff,0xa8(%rsp)
  19b8f6:	ff 
  19b8f7:	0f 85 00 04 00 00    	jne    19bcfd <first::main+0x8bd>
  19b8fd:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  19b904:	00 
  19b905:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  19b90c:	00 
  19b90d:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  19b912:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  19b917:	48 8d 44 24 60       	lea    0x60(%rsp),%rax
  19b91c:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
  19b923:	00 
  19b924:	48 8d 05 b5 17 00 00 	lea    0x17b5(%rip),%rax        # 19d0e0 <<wgpu_types::features::Features as core::fmt::Debug>::fmt>
  19b92b:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  19b932:	00 
  19b933:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
  19b938:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  19b93f:	00 
  19b940:	48 8d 05 89 10 00 00 	lea    0x1089(%rip),%rax        # 19c9d0 <<alloc::string::String as core::fmt::Display>::fmt>
  19b947:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  19b94e:	00 
  19b94f:	48 8d 3d d3 b1 ee ff 	lea    -0x114e2d(%rip),%rdi        # 86b29 <anon.0fc1e49a820022d47496a38d02c135f6.1.llvm.14900840715270527467+0x98>
  19b956:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19b95d:	00 
  19b95e:	ff 15 bc 1a 37 00    	call   *0x371abc(%rip)        # 50d420 <_DYNAMIC+0x4f0>
  19b964:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  19b969:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  19b96e:	48 83 f9 07          	cmp    $0x7,%rcx
  19b972:	0f 85 6e 01 00 00    	jne    19bae6 <first::main+0x6a6>
  19b978:	b9 63 6f 6e 74       	mov    $0x746e6f63,%ecx
  19b97d:	33 08                	xor    (%rax),%ecx
  19b97f:	ba 74 65 78 74       	mov    $0x74786574,%edx
  19b984:	33 50 03             	xor    0x3(%rax),%edx
  19b987:	09 ca                	or     %ecx,%edx
  19b989:	0f 85 50 03 00 00    	jne    19bcdf <first::main+0x89f>
  19b98f:	c7 84 24 98 00 00 00 	movl   $0xffffffff,0x98(%rsp)
  19b996:	ff ff ff ff 
  19b99a:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
  19b9a1:	00 
  19b9a2:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  19b9a7:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  19b9ae:	00 
  19b9af:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  19b9b4:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  19b9bb:	00 
  19b9bc:	4c 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%r14
  19b9c3:	00 
  19b9c4:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19b9cb:	00 
  19b9cc:	4c 89 f7             	mov    %r14,%rdi
  19b9cf:	e8 cc 64 ff ff       	call   191ea0 <allocation_counter::measure::<first::capture<gpui_gpu::renderer::GpuContext, first::main::{closure#0}>::{closure#0}>>
  19b9d4:	48 c7 84 24 70 04 00 	movq   $0x30,0x470(%rsp)
  19b9db:	00 30 00 00 00 
  19b9e0:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
  19b9e7:	00 
  19b9e8:	4c 8d 3d 41 0c 00 00 	lea    0xc41(%rip),%r15        # 19c630 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  19b9ef:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
  19b9f6:	00 
  19b9f7:	48 8d 05 82 73 ef ff 	lea    -0x108c7e(%rip),%rax        # 92d80 <anon.fd4379edd0b71335c3c29b3337cd5ea0.54.llvm.353578272256937679+0x28>
  19b9fe:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  19ba05:	00 
  19ba06:	48 8b 05 73 18 37 00 	mov    0x371873(%rip),%rax        # 50d280 <_DYNAMIC+0x350>
  19ba0d:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  19ba14:	00 
  19ba15:	48 89 9c 24 10 01 00 	mov    %rbx,0x110(%rsp)
  19ba1c:	00 
  19ba1d:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  19ba24:	00 
  19ba25:	48 8d 3d cc 30 ef ff 	lea    -0x10cf34(%rip),%rdi        # 8eaf8 <anon.64e6f0481017532cdf8621924f26dedf.26.llvm.17848240609198249692+0x551>
  19ba2c:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19ba33:	00 
  19ba34:	ff 15 e6 19 37 00    	call   *0x3719e6(%rip)        # 50d420 <_DYNAMIC+0x4f0>
  19ba3a:	0f 10 44 24 78       	movups 0x78(%rsp),%xmm0
  19ba3f:	0f 10 8c 24 88 00 00 	movups 0x88(%rsp),%xmm1
  19ba46:	00 
  19ba47:	0f 10 94 24 98 00 00 	movups 0x98(%rsp),%xmm2
  19ba4e:	00 
  19ba4f:	0f 29 94 24 10 01 00 	movaps %xmm2,0x110(%rsp)
  19ba56:	00 
  19ba57:	0f 29 8c 24 00 01 00 	movaps %xmm1,0x100(%rsp)
  19ba5e:	00 
  19ba5f:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  19ba66:	00 
  19ba67:	4c 8d b4 24 70 04 00 	lea    0x470(%rsp),%r14
  19ba6e:	00 
  19ba6f:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19ba76:	00 
  19ba77:	4c 89 f7             	mov    %r14,%rdi
  19ba7a:	e8 61 66 ff ff       	call   1920e0 <allocation_counter::measure::<first::capture<gpui_gpu::renderer::GpuContext, first::main::{closure#0}>::{closure#1}>>
  19ba7f:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
  19ba86:	00 00 00 00 00 
  19ba8b:	c7 84 24 08 01 00 00 	movl   $0xffffffff,0x108(%rsp)
  19ba92:	ff ff ff ff 
  19ba96:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  19ba9b:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  19baa0:	48 8d 9c 24 f0 00 00 	lea    0xf0(%rsp),%rbx
  19baa7:	00 
  19baa8:	48 89 da             	mov    %rbx,%rdx
  19baab:	ff 15 77 19 37 00    	call   *0x371977(%rip)        # 50d428 <_DYNAMIC+0x4f8>
  19bab1:	83 7c 24 28 02       	cmpl   $0x2,0x28(%rsp)
  19bab6:	0f 85 bb 02 00 00    	jne    19bd77 <first::main+0x937>
  19babc:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
  19bac3:	00 
  19bac4:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
  19bacb:	00 
  19bacc:	48 8d 3d b0 d9 ee ff 	lea    -0x112650(%rip),%rdi        # 89483 <anon.068260129a360d3c14a88deb110120c9.55.llvm.7357624670875813013+0x552>
  19bad3:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19bada:	00 
  19badb:	ff 15 3f 19 37 00    	call   *0x37193f(%rip)        # 50d420 <_DYNAMIC+0x4f0>
  19bae1:	e9 59 01 00 00       	jmp    19bc3f <first::main+0x7ff>
  19bae6:	48 83 f9 08          	cmp    $0x8,%rcx
  19baea:	0f 85 ef 01 00 00    	jne    19bcdf <first::main+0x89f>
  19baf0:	48 b9 72 65 6e 64 65 	movabs $0x72657265646e6572,%rcx
  19baf7:	72 65 72 
  19bafa:	48 39 08             	cmp    %rcx,(%rax)
  19bafd:	0f 85 dc 01 00 00    	jne    19bcdf <first::main+0x89f>
  19bb03:	48 c7 84 24 70 04 00 	movq   $0xffffffffffffffff,0x470(%rsp)
  19bb0a:	00 ff ff ff ff 
  19bb0f:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
  19bb16:	00 
  19bb17:	48 8d 44 24 08       	lea    0x8(%rsp),%rax
  19bb1c:	48 89 84 24 f8 00 00 	mov    %rax,0xf8(%rsp)
  19bb23:	00 
  19bb24:	48 8d 44 24 18       	lea    0x18(%rsp),%rax
  19bb29:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  19bb30:	00 
  19bb31:	48 8d 5c 24 78       	lea    0x78(%rsp),%rbx
  19bb36:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19bb3d:	00 
  19bb3e:	48 89 df             	mov    %rbx,%rdi
  19bb41:	e8 ea 66 ff ff       	call   192230 <allocation_counter::measure::<first::capture<gpui_gpu::renderer::Renderer, first::main::{closure#1}>::{closure#0}>>
  19bb46:	48 c7 84 24 a8 00 00 	movq   $0x378,0xa8(%rsp)
  19bb4d:	00 78 03 00 00 
  19bb52:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
  19bb59:	00 
  19bb5a:	4c 8d 3d cf 0a 00 00 	lea    0xacf(%rip),%r15        # 19c630 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  19bb61:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
  19bb68:	00 
  19bb69:	48 8d 05 80 75 ef ff 	lea    -0x108a80(%rip),%rax        # 930f0 <anon.fd4379edd0b71335c3c29b3337cd5ea0.173.llvm.353578272256937679+0x28>
  19bb70:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  19bb77:	00 
  19bb78:	48 8b 05 01 17 37 00 	mov    0x371701(%rip),%rax        # 50d280 <_DYNAMIC+0x350>
  19bb7f:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
  19bb86:	00 
  19bb87:	4c 89 b4 24 10 01 00 	mov    %r14,0x110(%rsp)
  19bb8e:	00 
  19bb8f:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
  19bb96:	00 
  19bb97:	48 8d 3d 5a 2f ef ff 	lea    -0x10d0a6(%rip),%rdi        # 8eaf8 <anon.64e6f0481017532cdf8621924f26dedf.26.llvm.17848240609198249692+0x551>
  19bb9e:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19bba5:	00 
  19bba6:	ff 15 74 18 37 00    	call   *0x371874(%rip)        # 50d420 <_DYNAMIC+0x4f0>
  19bbac:	48 8d 9c 24 f0 00 00 	lea    0xf0(%rsp),%rbx
  19bbb3:	00 
  19bbb4:	48 8d b4 24 70 04 00 	lea    0x470(%rsp),%rsi
  19bbbb:	00 
  19bbbc:	ba 78 03 00 00       	mov    $0x378,%edx
  19bbc1:	48 89 df             	mov    %rbx,%rdi
  19bbc4:	ff 15 c6 15 37 00    	call   *0x3715c6(%rip)        # 50d190 <memcpy@GLIBC_2.14>
  19bbca:	4c 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%r14
  19bbd1:	00 
  19bbd2:	4c 89 f7             	mov    %r14,%rdi
  19bbd5:	48 89 de             	mov    %rbx,%rsi
  19bbd8:	e8 f3 68 ff ff       	call   1924d0 <allocation_counter::measure::<first::capture<gpui_gpu::renderer::Renderer, first::main::{closure#1}>::{closure#1}>>
  19bbdd:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
  19bbe4:	00 00 00 00 00 
  19bbe9:	c7 84 24 08 01 00 00 	movl   $0xffffffff,0x108(%rsp)
  19bbf0:	ff ff ff ff 
  19bbf4:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  19bbf9:	48 8d 74 24 08       	lea    0x8(%rsp),%rsi
  19bbfe:	48 8d 9c 24 f0 00 00 	lea    0xf0(%rsp),%rbx
  19bc05:	00 
  19bc06:	48 89 da             	mov    %rbx,%rdx
  19bc09:	ff 15 19 18 37 00    	call   *0x371819(%rip)        # 50d428 <_DYNAMIC+0x4f8>
  19bc0f:	83 7c 24 28 02       	cmpl   $0x2,0x28(%rsp)
  19bc14:	0f 85 5d 01 00 00    	jne    19bd77 <first::main+0x937>
  19bc1a:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
  19bc21:	00 
  19bc22:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
  19bc29:	00 
  19bc2a:	48 8d 3d 52 d8 ee ff 	lea    -0x1127ae(%rip),%rdi        # 89483 <anon.068260129a360d3c14a88deb110120c9.55.llvm.7357624670875813013+0x552>
  19bc31:	48 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%rsi
  19bc38:	00 
  19bc39:	ff 15 e1 17 37 00    	call   *0x3717e1(%rip)        # 50d420 <_DYNAMIC+0x4f0>
  19bc3f:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  19bc44:	f0 48 ff 08          	lock decq (%rax)
  19bc48:	75 0b                	jne    19bc55 <first::main+0x815>
  19bc4a:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  19bc4f:	ff 15 ab 16 37 00    	call   *0x3716ab(%rip)        # 50d300 <_DYNAMIC+0x3d0>
  19bc55:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  19bc5a:	f0 48 ff 08          	lock decq (%rax)
  19bc5e:	75 0b                	jne    19bc6b <first::main+0x82b>
  19bc60:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  19bc65:	ff 15 8d 16 37 00    	call   *0x37168d(%rip)        # 50d2f8 <_DYNAMIC+0x3c8>
  19bc6b:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  19bc70:	f0 48 ff 08          	lock decq (%rax)
  19bc74:	75 0b                	jne    19bc81 <first::main+0x841>
  19bc76:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  19bc7b:	ff 15 af 17 37 00    	call   *0x3717af(%rip)        # 50d430 <_DYNAMIC+0x500>
  19bc81:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  19bc86:	f0 48 ff 08          	lock decq (%rax)
  19bc8a:	75 0b                	jne    19bc97 <first::main+0x857>
  19bc8c:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  19bc91:	ff 15 a1 17 37 00    	call   *0x3717a1(%rip)        # 50d438 <_DYNAMIC+0x508>
  19bc97:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  19bc9c:	48 85 f6             	test   %rsi,%rsi
  19bc9f:	74 10                	je     19bcb1 <first::main+0x871>
  19bca1:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  19bca6:	ba 01 00 00 00       	mov    $0x1,%edx
  19bcab:	ff 15 c7 14 37 00    	call   *0x3714c7(%rip)        # 50d178 <_DYNAMIC+0x248>
  19bcb1:	48 81 c4 f0 07 00 00 	add    $0x7f0,%rsp
  19bcb8:	5b                   	pop    %rbx
  19bcb9:	41 5c                	pop    %r12
  19bcbb:	41 5e                	pop    %r14
  19bcbd:	41 5f                	pop    %r15
  19bcbf:	5d                   	pop    %rbp
  19bcc0:	c3                   	ret
  19bcc1:	48 8d 3d e2 c7 ef ff 	lea    -0x10381e(%rip),%rdi        # 984aa <anon.5ec6f27932c70eb97d1626e428d8aee9.7.llvm.1983821808713283309+0x72>
  19bcc8:	48 8d 15 d1 7a 34 00 	lea    0x347ad1(%rip),%rdx        # 4e37a0 <anon.5ec6f27932c70eb97d1626e428d8aee9.9.llvm.1983821808713283309+0x48>
  19bccf:	be 13 00 00 00       	mov    $0x13,%esi
  19bcd4:	ff 15 66 17 37 00    	call   *0x371766(%rip)        # 50d440 <_DYNAMIC+0x510>
  19bcda:	e9 d5 00 00 00       	jmp    19bdb4 <first::main+0x974>
  19bcdf:	48 8d 3d a8 c7 ef ff 	lea    -0x103858(%rip),%rdi        # 9848e <anon.5ec6f27932c70eb97d1626e428d8aee9.7.llvm.1983821808713283309+0x56>
  19bce6:	48 8d 15 9b 7a 34 00 	lea    0x347a9b(%rip),%rdx        # 4e3788 <anon.5ec6f27932c70eb97d1626e428d8aee9.9.llvm.1983821808713283309+0x30>
  19bced:	be 39 00 00 00       	mov    $0x39,%esi
  19bcf2:	ff 15 f0 15 37 00    	call   *0x3715f0(%rip)        # 50d2e8 <_DYNAMIC+0x3b8>
  19bcf8:	e9 b7 00 00 00       	jmp    19bdb4 <first::main+0x974>
  19bcfd:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
  19bd04:	00 
  19bd05:	48 89 84 24 b0 04 00 	mov    %rax,0x4b0(%rsp)
  19bd0c:	00 
  19bd0d:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
  19bd14:	00 
  19bd15:	0f 10 8c 24 b8 00 00 	movups 0xb8(%rsp),%xmm1
  19bd1c:	00 
  19bd1d:	0f 10 94 24 c8 00 00 	movups 0xc8(%rsp),%xmm2
  19bd24:	00 
  19bd25:	0f 10 9c 24 d8 00 00 	movups 0xd8(%rsp),%xmm3
  19bd2c:	00 
  19bd2d:	0f 29 9c 24 a0 04 00 	movaps %xmm3,0x4a0(%rsp)
  19bd34:	00 
  19bd35:	0f 29 94 24 90 04 00 	movaps %xmm2,0x490(%rsp)
  19bd3c:	00 
  19bd3d:	0f 29 8c 24 80 04 00 	movaps %xmm1,0x480(%rsp)
  19bd44:	00 
  19bd45:	0f 29 84 24 70 04 00 	movaps %xmm0,0x470(%rsp)
  19bd4c:	00 
  19bd4d:	48 8d 3d 69 c7 ef ff 	lea    -0x103897(%rip),%rdi        # 984bd <anon.5ec6f27932c70eb97d1626e428d8aee9.7.llvm.1983821808713283309+0x85>
  19bd54:	48 8d 0d 7d 7a 34 00 	lea    0x347a7d(%rip),%rcx        # 4e37d8 <anon.5ec6f27932c70eb97d1626e428d8aee9.9.llvm.1983821808713283309+0x80>
  19bd5b:	4c 8d 05 0e 7a 34 00 	lea    0x347a0e(%rip),%r8        # 4e3770 <anon.5ec6f27932c70eb97d1626e428d8aee9.9.llvm.1983821808713283309+0x18>
  19bd62:	48 8d 94 24 70 04 00 	lea    0x470(%rsp),%rdx
  19bd69:	00 
  19bd6a:	be 2b 00 00 00       	mov    $0x2b,%esi
  19bd6f:	ff 15 7b 15 37 00    	call   *0x37157b(%rip)        # 50d2f0 <_DYNAMIC+0x3c0>
  19bd75:	eb 3d                	jmp    19bdb4 <first::main+0x974>
  19bd77:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  19bd7c:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  19bd83:	00 
  19bd84:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  19bd89:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
  19bd90:	00 
  19bd91:	48 8d 3d 25 c7 ef ff 	lea    -0x1038db(%rip),%rdi        # 984bd <anon.5ec6f27932c70eb97d1626e428d8aee9.7.llvm.1983821808713283309+0x85>
  19bd98:	48 8d 0d 19 7a 34 00 	lea    0x347a19(%rip),%rcx        # 4e37b8 <anon.5ec6f27932c70eb97d1626e428d8aee9.9.llvm.1983821808713283309+0x60>
  19bd9f:	4c 8d 05 6a 79 34 00 	lea    0x34796a(%rip),%r8        # 4e3710 <anon.bd81d6341d40e5d7397faad37186b22d.1.llvm.8757217068975972983+0xc30>
  19bda6:	be 2b 00 00 00       	mov    $0x2b,%esi
  19bdab:	48 89 da             	mov    %rbx,%rdx
  19bdae:	ff 15 3c 15 37 00    	call   *0x37153c(%rip)        # 50d2f0 <_DYNAMIC+0x3c0>
  19bdb4:	0f 0b                	ud2
  19bdb6:	eb 62                	jmp    19be1a <first::main+0x9da>
  19bdb8:	48 89 c3             	mov    %rax,%rbx
  19bdbb:	e9 e5 00 00 00       	jmp    19bea5 <first::main+0xa65>
  19bdc0:	48 89 c3             	mov    %rax,%rbx
  19bdc3:	e9 b1 00 00 00       	jmp    19be79 <first::main+0xa39>
  19bdc8:	48 89 c3             	mov    %rax,%rbx
  19bdcb:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  19bdd2:	00 
  19bdd3:	e8 b8 e0 ff ff       	call   199e90 <core::ptr::drop_glue::<core::option::Option<gpui_gpu::renderer::Renderer>>>
  19bdd8:	e9 86 00 00 00       	jmp    19be63 <first::main+0xa23>
  19bddd:	ff 15 ed 13 37 00    	call   *0x3713ed(%rip)        # 50d1d0 <_DYNAMIC+0x2a0>
  19bde3:	48 89 c3             	mov    %rax,%rbx
  19bde6:	83 bc 24 98 00 00 00 	cmpl   $0xffffffff,0x98(%rsp)
  19bded:	ff 
  19bdee:	74 73                	je     19be63 <first::main+0xa23>
  19bdf0:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
  19bdf5:	e8 26 e6 ff ff       	call   19a420 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>
  19bdfa:	eb 67                	jmp    19be63 <first::main+0xa23>
  19bdfc:	ff 15 ce 13 37 00    	call   *0x3713ce(%rip)        # 50d1d0 <_DYNAMIC+0x2a0>
  19be02:	48 89 c3             	mov    %rax,%rbx
  19be05:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  19be0c:	00 
  19be0d:	e8 3e a5 ff ff       	call   196350 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  19be12:	eb 7b                	jmp    19be8f <first::main+0xa4f>
  19be14:	ff 15 b6 13 37 00    	call   *0x3713b6(%rip)        # 50d1d0 <_DYNAMIC+0x2a0>
  19be1a:	48 89 c3             	mov    %rax,%rbx
  19be1d:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  19be24:	00 
  19be25:	e8 26 a0 ff ff       	call   195e50 <<alloc::vec::into_iter::IntoIter<std::ffi::os_str::OsString> as core::ops::drop::Drop>::drop>
  19be2a:	e9 8c 00 00 00       	jmp    19bebb <first::main+0xa7b>
  19be2f:	48 89 c3             	mov    %rax,%rbx
  19be32:	e9 84 00 00 00       	jmp    19bebb <first::main+0xa7b>
  19be37:	48 89 c3             	mov    %rax,%rbx
  19be3a:	eb 53                	jmp    19be8f <first::main+0xa4f>
  19be3c:	48 89 c3             	mov    %rax,%rbx
  19be3f:	48 8d bc 24 70 04 00 	lea    0x470(%rsp),%rdi
  19be46:	00 
  19be47:	e8 14 ef ff ff       	call   19ad60 <core::ptr::drop_glue::<wgpu::api::device::RequestDeviceError>>
  19be4c:	eb 41                	jmp    19be8f <first::main+0xa4f>
  19be4e:	48 89 c3             	mov    %rax,%rbx
  19be51:	48 8d bc 24 f0 00 00 	lea    0xf0(%rsp),%rdi
  19be58:	00 
  19be59:	e8 f2 9f ff ff       	call   195e50 <<alloc::vec::into_iter::IntoIter<std::ffi::os_str::OsString> as core::ops::drop::Drop>::drop>
  19be5e:	eb 75                	jmp    19bed5 <first::main+0xa95>
  19be60:	48 89 c3             	mov    %rax,%rbx
  19be63:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  19be68:	f0 48 ff 08          	lock decq (%rax)
  19be6c:	75 0b                	jne    19be79 <first::main+0xa39>
  19be6e:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  19be73:	ff 15 87 14 37 00    	call   *0x371487(%rip)        # 50d300 <_DYNAMIC+0x3d0>
  19be79:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  19be7e:	f0 48 ff 08          	lock decq (%rax)
  19be82:	75 0b                	jne    19be8f <first::main+0xa4f>
  19be84:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  19be89:	ff 15 69 14 37 00    	call   *0x371469(%rip)        # 50d2f8 <_DYNAMIC+0x3c8>
  19be8f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  19be94:	f0 48 ff 08          	lock decq (%rax)
  19be98:	75 0b                	jne    19bea5 <first::main+0xa65>
  19be9a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  19be9f:	ff 15 8b 15 37 00    	call   *0x37158b(%rip)        # 50d430 <_DYNAMIC+0x500>
  19bea5:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  19beaa:	f0 48 ff 08          	lock decq (%rax)
  19beae:	75 0b                	jne    19bebb <first::main+0xa7b>
  19beb0:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  19beb5:	ff 15 7d 15 37 00    	call   *0x37157d(%rip)        # 50d438 <_DYNAMIC+0x508>
  19bebb:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  19bec0:	48 85 f6             	test   %rsi,%rsi
  19bec3:	74 10                	je     19bed5 <first::main+0xa95>
  19bec5:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  19beca:	ba 01 00 00 00       	mov    $0x1,%edx
  19becf:	ff 15 a3 12 37 00    	call   *0x3712a3(%rip)        # 50d178 <_DYNAMIC+0x248>
  19bed5:	48 89 df             	mov    %rbx,%rdi
  19bed8:	e8 e3 44 34 00       	call   4e03c0 <_Unwind_Resume@plt>
  19bedd:	ff 15 ed 12 37 00    	call   *0x3712ed(%rip)        # 50d1d0 <_DYNAMIC+0x2a0>
  19bee3:	cc                   	int3
  19bee4:	cc                   	int3
  19bee5:	cc                   	int3
  19bee6:	cc                   	int3
  19bee7:	cc                   	int3
  19bee8:	cc                   	int3
  19bee9:	cc                   	int3
  19beea:	cc                   	int3
  19beeb:	cc                   	int3
  19beec:	cc                   	int3
  19beed:	cc                   	int3
  19beee:	cc                   	int3
  19beef:	cc                   	int3

000000000019e080 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}>:
  19e080:	55                   	push   %rbp
  19e081:	41 57                	push   %r15
  19e083:	41 56                	push   %r14
  19e085:	41 55                	push   %r13
  19e087:	41 54                	push   %r12
  19e089:	53                   	push   %rbx
  19e08a:	48 81 ec 48 02 00 00 	sub    $0x248,%rsp
  19e091:	49 89 d7             	mov    %rdx,%r15
  19e094:	48 89 f3             	mov    %rsi,%rbx
  19e097:	49 89 fe             	mov    %rdi,%r14
  19e09a:	0f b6 86 02 01 00 00 	movzbl 0x102(%rsi),%eax
  19e0a1:	48 8d 0d 48 aa ef ff 	lea    -0x1055b8(%rip),%rcx        # 98af0 <anon.5ec6f27932c70eb97d1626e428d8aee9.194.llvm.1983821808713283309+0x17d>
  19e0a8:	48 63 04 81          	movslq (%rcx,%rax,4),%rax
  19e0ac:	48 01 c8             	add    %rcx,%rax
  19e0af:	ff e0                	jmp    *%rax
  19e0b1:	48 c7 83 f8 00 00 00 	movq   $0x0,0xf8(%rbx)
  19e0b8:	00 00 00 00 
  19e0bc:	66 c7 83 00 01 00 00 	movw   $0x101,0x100(%rbx)
  19e0c3:	01 01 
  19e0c5:	48 8b 83 d8 00 00 00 	mov    0xd8(%rbx),%rax
  19e0cc:	0f 10 83 d0 00 00 00 	movups 0xd0(%rbx),%xmm0
  19e0d3:	0f 11 83 90 00 00 00 	movups %xmm0,0x90(%rbx)
  19e0da:	48 8b 8b ec 00 00 00 	mov    0xec(%rbx),%rcx
  19e0e1:	48 89 8b e0 00 00 00 	mov    %rcx,0xe0(%rbx)
  19e0e8:	8b 93 f4 00 00 00    	mov    0xf4(%rbx),%edx
  19e0ee:	89 93 e8 00 00 00    	mov    %edx,0xe8(%rbx)
  19e0f4:	41 89 cc             	mov    %ecx,%r12d
  19e0f7:	49 83 fc 28          	cmp    $0x28,%r12
  19e0fb:	0f 87 72 07 00 00    	ja     19e873 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x7f3>
  19e101:	48 b9 00 00 40 08 00 	movabs $0x10008400000,%rcx
  19e108:	01 00 00 
  19e10b:	4c 0f a3 e1          	bt     %r12,%rcx
  19e10f:	0f 83 5e 07 00 00    	jae    19e873 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x7f3>
  19e115:	4c 8d a3 90 00 00 00 	lea    0x90(%rbx),%r12
  19e11c:	48 8d 7b 20          	lea    0x20(%rbx),%rdi
  19e120:	4c 89 e6             	mov    %r12,%rsi
  19e123:	ba 02 00 00 00       	mov    $0x2,%edx
  19e128:	ff 15 7a f3 36 00    	call   *0x36f37a(%rip)        # 50d4a8 <_DYNAMIC+0x578>
  19e12e:	c6 83 f9 00 00 00 01 	movb   $0x1,0xf9(%rbx)
  19e135:	48 8d bb 08 01 00 00 	lea    0x108(%rbx),%rdi
  19e13c:	4c 89 e6             	mov    %r12,%rsi
  19e13f:	31 d2                	xor    %edx,%edx
  19e141:	ff 15 61 f3 36 00    	call   *0x36f361(%rip)        # 50d4a8 <_DYNAMIC+0x578>
  19e147:	c6 83 f8 00 00 00 01 	movb   $0x1,0xf8(%rbx)
  19e14e:	48 8d bc 24 d8 01 00 	lea    0x1d8(%rsp),%rdi
  19e155:	00 
  19e156:	4c 89 e6             	mov    %r12,%rsi
  19e159:	ba 01 00 00 00       	mov    $0x1,%edx
  19e15e:	ff 15 44 f3 36 00    	call   *0x36f344(%rip)        # 50d4a8 <_DYNAMIC+0x578>
  19e164:	c6 83 ff 00 00 00 01 	movb   $0x1,0xff(%rbx)
  19e16b:	48 89 df             	mov    %rbx,%rdi
  19e16e:	4c 89 e6             	mov    %r12,%rsi
  19e171:	ff 15 39 f3 36 00    	call   *0x36f339(%rip)        # 50d4b0 <_DYNAMIC+0x580>
  19e177:	48 8b 03             	mov    (%rbx),%rax
  19e17a:	48 8d 2d ac a9 ef ff 	lea    -0x105654(%rip),%rbp        # 98b2d <anon.da59e8131a022f4b4f3ef8e3eb443d3a.2.llvm.12540191330197700236+0x25>
  19e181:	48 85 c0             	test   %rax,%rax
  19e184:	74 43                	je     19e1c9 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x149>
  19e186:	48 8b 53 08          	mov    0x8(%rbx),%rdx
  19e18a:	0f 10 43 10          	movups 0x10(%rbx),%xmm0
  19e18e:	eb 7e                	jmp    19e20e <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x18e>
  19e190:	48 8b b3 08 01 00 00 	mov    0x108(%rbx),%rsi
  19e197:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
  19e19e:	e9 58 03 00 00       	jmp    19e4fb <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x47b>
  19e1a3:	48 8b b3 08 01 00 00 	mov    0x108(%rbx),%rsi
  19e1aa:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
  19e1b1:	e9 fb 03 00 00       	jmp    19e5b1 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x531>
  19e1b6:	48 8b b3 18 01 00 00 	mov    0x118(%rbx),%rsi
  19e1bd:	48 8b 83 20 01 00 00 	mov    0x120(%rbx),%rax
  19e1c4:	e9 7c 02 00 00       	jmp    19e445 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x3c5>
  19e1c9:	48 89 ac 24 88 00 00 	mov    %rbp,0x88(%rsp)
  19e1d0:	00 
  19e1d1:	48 c7 84 24 90 00 00 	movq   $0x14,0x90(%rsp)
  19e1d8:	00 14 00 00 00 
  19e1dd:	48 c7 44 24 70 ff ff 	movq   $0xffffffffffffffff,0x70(%rsp)
  19e1e4:	ff ff 
  19e1e6:	48 8d 05 54 a9 ef ff 	lea    -0x1056ac(%rip),%rax        # 98b41 <anon.da59e8131a022f4b4f3ef8e3eb443d3a.2.llvm.12540191330197700236+0x39>
  19e1ed:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  19e1f2:	48 c7 84 24 80 00 00 	movq   $0x3b4c,0x80(%rsp)
  19e1f9:	00 4c 3b 00 00 
  19e1fe:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
  19e203:	4c 89 e7             	mov    %r12,%rdi
  19e206:	ff 15 ac f2 36 00    	call   *0x36f2ac(%rip)        # 50d4b8 <_DYNAMIC+0x588>
  19e20c:	31 d2                	xor    %edx,%edx
  19e20e:	4c 8d ab a8 00 00 00 	lea    0xa8(%rbx),%r13
  19e215:	48 85 d2             	test   %rdx,%rdx
  19e218:	4c 89 ee             	mov    %r13,%rsi
  19e21b:	48 0f 44 f2          	cmove  %rdx,%rsi
  19e21f:	48 8d bb a0 00 00 00 	lea    0xa0(%rbx),%rdi
  19e226:	4c 89 e9             	mov    %r13,%rcx
  19e229:	48 0f 44 cf          	cmove  %rdi,%rcx
  19e22d:	4c 8d 83 e0 00 00 00 	lea    0xe0(%rbx),%r8
  19e234:	48 83 c6 10          	add    $0x10,%rsi
  19e238:	48 85 d2             	test   %rdx,%rdx
  19e23b:	48 89 83 a0 00 00 00 	mov    %rax,0xa0(%rbx)
  19e242:	c6 83 fe 00 00 00 01 	movb   $0x1,0xfe(%rbx)
  19e249:	48 89 93 a8 00 00 00 	mov    %rdx,0xa8(%rbx)
  19e250:	48 0f 44 f2          	cmove  %rdx,%rsi
  19e254:	0f 11 83 b0 00 00 00 	movups %xmm0,0xb0(%rbx)
  19e25b:	41 8b 40 08          	mov    0x8(%r8),%eax
  19e25f:	89 44 24 18          	mov    %eax,0x18(%rsp)
  19e263:	49 8b 00             	mov    (%r8),%rax
  19e266:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  19e26b:	48 b8 ff ff ff ff 0f 	movabs $0xfffffffff,%rax
  19e272:	00 00 00 
  19e275:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  19e27a:	48 89 ac 24 f0 00 00 	mov    %rbp,0xf0(%rsp)
  19e281:	00 
  19e282:	48 c7 84 24 f8 00 00 	movq   $0x14,0xf8(%rsp)
  19e289:	00 14 00 00 00 
  19e28e:	48 89 b4 24 00 01 00 	mov    %rsi,0x100(%rsp)
  19e295:	00 
  19e296:	48 8d 05 f0 e3 ef ff 	lea    -0x101c10(%rip),%rax        # 9c68d <anon.da59e8131a022f4b4f3ef8e3eb443d3a.2.llvm.12540191330197700236+0x3b85>
  19e29d:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
  19e2a4:	00 
  19e2a5:	48 c7 84 24 b8 00 00 	movq   $0x6,0xb8(%rsp)
  19e2ac:	00 06 00 00 00 
  19e2b1:	48 c7 84 24 c0 00 00 	movq   $0x8,0xc0(%rsp)
  19e2b8:	00 08 00 00 00 
  19e2bd:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
  19e2c4:	00 00 00 00 00 
  19e2c9:	48 89 bc 24 d0 00 00 	mov    %rdi,0xd0(%rsp)
  19e2d0:	00 
  19e2d1:	48 c7 84 24 d8 00 00 	movq   $0x8,0xd8(%rsp)
  19e2d8:	00 08 00 00 00 
  19e2dd:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  19e2e4:	00 00 00 00 00 
  19e2e9:	c6 84 24 e8 00 00 00 	movb   $0x1,0xe8(%rsp)
  19e2f0:	01 
  19e2f1:	c7 84 24 80 01 00 00 	movl   $0x2,0x180(%rsp)
  19e2f8:	02 00 00 00 
  19e2fc:	c6 84 24 84 01 00 00 	movb   $0x0,0x184(%rsp)
  19e303:	00 
  19e304:	c7 84 24 88 01 00 00 	movl   $0x0,0x188(%rsp)
  19e30b:	00 00 00 00 
  19e30f:	c6 84 24 8c 01 00 00 	movb   $0x0,0x18c(%rsp)
  19e316:	00 
  19e317:	c7 84 24 3c 01 00 00 	movl   $0x0,0x13c(%rsp)
  19e31e:	00 00 00 00 
  19e322:	c7 84 24 10 01 00 00 	movl   $0x1,0x110(%rsp)
  19e329:	01 00 00 00 
  19e32d:	48 c7 84 24 18 01 00 	movq   $0xffffffffffffffff,0x118(%rsp)
  19e334:	00 ff ff ff ff 
  19e339:	c6 84 24 20 01 00 00 	movb   $0x0,0x120(%rsp)
  19e340:	00 
  19e341:	48 8d 05 60 46 ef ff 	lea    -0x10b9a0(%rip),%rax        # 929a8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  19e348:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  19e34d:	48 c7 44 24 78 08 00 	movq   $0x8,0x78(%rsp)
  19e354:	00 00 
  19e356:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
  19e35b:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  19e362:	00 
  19e363:	48 c7 84 24 88 00 00 	movq   $0x1,0x88(%rsp)
  19e36a:	00 01 00 00 00 
  19e36f:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  19e376:	00 
  19e377:	48 c7 84 24 98 00 00 	movq   $0x8,0x98(%rsp)
  19e37e:	00 08 00 00 00 
  19e383:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
  19e38a:	00 00 00 00 00 
  19e38f:	c6 84 24 a8 00 00 00 	movb   $0x1,0xa8(%rsp)
  19e396:	01 
  19e397:	0f 28 05 a2 3d ef ff 	movaps -0x10c25e(%rip),%xmm0        # 92140 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x20>
  19e39e:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
  19e3a5:	00 
  19e3a6:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
  19e3ad:	00 00 00 00 00 
  19e3b2:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
  19e3b7:	4c 89 e7             	mov    %r12,%rdi
  19e3ba:	ff 15 00 f1 36 00    	call   *0x36f100(%rip)        # 50d4c0 <_DYNAMIC+0x590>
  19e3c0:	48 89 83 c0 00 00 00 	mov    %rax,0xc0(%rbx)
  19e3c7:	c6 83 fd 00 00 00 01 	movb   $0x1,0xfd(%rbx)
  19e3ce:	c6 83 fe 00 00 00 00 	movb   $0x0,0xfe(%rbx)
  19e3d5:	49 8b 45 10          	mov    0x10(%r13),%rax
  19e3d9:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  19e3e0:	00 
  19e3e1:	41 0f 10 45 00       	movups 0x0(%r13),%xmm0
  19e3e6:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  19e3eb:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e3f0:	e8 3b f5 ff ff       	call   19d930 <core::ptr::drop_glue::<core::option::Option<(wgpu::api::shader_module::ShaderModule, wgpu::api::bind_group_layout::BindGroupLayout, wgpu::api::pipeline_layout::PipelineLayout)>>>
  19e3f5:	48 8d bb c0 00 00 00 	lea    0xc0(%rbx),%rdi
  19e3fc:	31 f6                	xor    %esi,%esi
  19e3fe:	ff 15 c4 f0 36 00    	call   *0x36f0c4(%rip)        # 50d4c8 <_DYNAMIC+0x598>
  19e404:	48 89 83 c8 00 00 00 	mov    %rax,0xc8(%rbx)
  19e40b:	c6 83 fc 00 00 00 01 	movb   $0x1,0xfc(%rbx)
  19e412:	c6 83 ff 00 00 00 00 	movb   $0x0,0xff(%rbx)
  19e419:	0f 10 84 24 d8 01 00 	movups 0x1d8(%rsp),%xmm0
  19e420:	00 
  19e421:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  19e426:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e42b:	ff 15 9f f0 36 00    	call   *0x36f09f(%rip)        # 50d4d0 <_DYNAMIC+0x5a0>
  19e431:	48 89 c6             	mov    %rax,%rsi
  19e434:	48 89 d0             	mov    %rdx,%rax
  19e437:	48 89 b3 18 01 00 00 	mov    %rsi,0x118(%rbx)
  19e43e:	48 89 83 20 01 00 00 	mov    %rax,0x120(%rbx)
  19e445:	48 8d bc 24 e8 01 00 	lea    0x1e8(%rsp),%rdi
  19e44c:	00 
  19e44d:	4c 89 fa             	mov    %r15,%rdx
  19e450:	ff 50 18             	call   *0x18(%rax)
  19e453:	83 bc 24 e8 01 00 00 	cmpl   $0xfffffffe,0x1e8(%rsp)
  19e45a:	fe 
  19e45b:	75 0f                	jne    19e46c <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x3ec>
  19e45d:	41 c7 46 20 fe ff ff 	movl   $0xfffffffe,0x20(%r14)
  19e464:	ff 
  19e465:	b0 03                	mov    $0x3,%al
  19e467:	e9 74 04 00 00       	jmp    19e8e0 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x860>
  19e46c:	c6 83 fb 00 00 00 01 	movb   $0x1,0xfb(%rbx)
  19e473:	0f 10 84 24 e8 01 00 	movups 0x1e8(%rsp),%xmm0
  19e47a:	00 
  19e47b:	0f 10 8c 24 f8 01 00 	movups 0x1f8(%rsp),%xmm1
  19e482:	00 
  19e483:	0f 10 94 24 08 02 00 	movups 0x208(%rsp),%xmm2
  19e48a:	00 
  19e48b:	0f 11 43 30          	movups %xmm0,0x30(%rbx)
  19e48f:	0f 11 4b 40          	movups %xmm1,0x40(%rbx)
  19e493:	0f 11 53 50          	movups %xmm2,0x50(%rbx)
  19e497:	4c 8b a3 18 01 00 00 	mov    0x118(%rbx),%r12
  19e49e:	4c 8b ab 20 01 00 00 	mov    0x120(%rbx),%r13
  19e4a5:	49 8b 45 00          	mov    0x0(%r13),%rax
  19e4a9:	48 85 c0             	test   %rax,%rax
  19e4ac:	74 05                	je     19e4b3 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x433>
  19e4ae:	4c 89 e7             	mov    %r12,%rdi
  19e4b1:	ff d0                	call   *%rax
  19e4b3:	49 8b 75 08          	mov    0x8(%r13),%rsi
  19e4b7:	48 85 f6             	test   %rsi,%rsi
  19e4ba:	74 0d                	je     19e4c9 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x449>
  19e4bc:	49 8b 55 10          	mov    0x10(%r13),%rdx
  19e4c0:	4c 89 e7             	mov    %r12,%rdi
  19e4c3:	ff 15 af ec 36 00    	call   *0x36ecaf(%rip)        # 50d178 <_DYNAMIC+0x248>
  19e4c9:	c6 83 f8 00 00 00 00 	movb   $0x0,0xf8(%rbx)
  19e4d0:	0f 10 83 08 01 00 00 	movups 0x108(%rbx),%xmm0
  19e4d7:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  19e4dc:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e4e1:	ff 15 e9 ef 36 00    	call   *0x36efe9(%rip)        # 50d4d0 <_DYNAMIC+0x5a0>
  19e4e7:	48 89 c6             	mov    %rax,%rsi
  19e4ea:	48 89 d0             	mov    %rdx,%rax
  19e4ed:	48 89 b3 08 01 00 00 	mov    %rsi,0x108(%rbx)
  19e4f4:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
  19e4fb:	48 8d bc 24 18 02 00 	lea    0x218(%rsp),%rdi
  19e502:	00 
  19e503:	4c 89 fa             	mov    %r15,%rdx
  19e506:	ff 50 18             	call   *0x18(%rax)
  19e509:	83 bc 24 18 02 00 00 	cmpl   $0xfffffffe,0x218(%rsp)
  19e510:	fe 
  19e511:	75 0f                	jne    19e522 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x4a2>
  19e513:	41 c7 46 20 fe ff ff 	movl   $0xfffffffe,0x20(%r14)
  19e51a:	ff 
  19e51b:	b0 04                	mov    $0x4,%al
  19e51d:	e9 be 03 00 00       	jmp    19e8e0 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x860>
  19e522:	c6 83 fa 00 00 00 01 	movb   $0x1,0xfa(%rbx)
  19e529:	0f 10 84 24 18 02 00 	movups 0x218(%rsp),%xmm0
  19e530:	00 
  19e531:	0f 10 8c 24 28 02 00 	movups 0x228(%rsp),%xmm1
  19e538:	00 
  19e539:	0f 10 94 24 38 02 00 	movups 0x238(%rsp),%xmm2
  19e540:	00 
  19e541:	0f 11 43 60          	movups %xmm0,0x60(%rbx)
  19e545:	0f 11 4b 70          	movups %xmm1,0x70(%rbx)
  19e549:	0f 11 93 80 00 00 00 	movups %xmm2,0x80(%rbx)
  19e550:	4c 8b a3 08 01 00 00 	mov    0x108(%rbx),%r12
  19e557:	4c 8b ab 10 01 00 00 	mov    0x110(%rbx),%r13
  19e55e:	49 8b 45 00          	mov    0x0(%r13),%rax
  19e562:	48 85 c0             	test   %rax,%rax
  19e565:	74 05                	je     19e56c <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x4ec>
  19e567:	4c 89 e7             	mov    %r12,%rdi
  19e56a:	ff d0                	call   *%rax
  19e56c:	49 8b 75 08          	mov    0x8(%r13),%rsi
  19e570:	48 85 f6             	test   %rsi,%rsi
  19e573:	74 0d                	je     19e582 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x502>
  19e575:	49 8b 55 10          	mov    0x10(%r13),%rdx
  19e579:	4c 89 e7             	mov    %r12,%rdi
  19e57c:	ff 15 f6 eb 36 00    	call   *0x36ebf6(%rip)        # 50d178 <_DYNAMIC+0x248>
  19e582:	c6 83 f9 00 00 00 00 	movb   $0x0,0xf9(%rbx)
  19e589:	0f 10 43 20          	movups 0x20(%rbx),%xmm0
  19e58d:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  19e592:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e597:	ff 15 33 ef 36 00    	call   *0x36ef33(%rip)        # 50d4d0 <_DYNAMIC+0x5a0>
  19e59d:	48 89 c6             	mov    %rax,%rsi
  19e5a0:	48 89 d0             	mov    %rdx,%rax
  19e5a3:	48 89 b3 08 01 00 00 	mov    %rsi,0x108(%rbx)
  19e5aa:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
  19e5b1:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e5b6:	4c 89 fa             	mov    %r15,%rdx
  19e5b9:	ff 50 18             	call   *0x18(%rax)
  19e5bc:	83 7c 24 70 fe       	cmpl   $0xfffffffe,0x70(%rsp)
  19e5c1:	75 0f                	jne    19e5d2 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x552>
  19e5c3:	41 c7 46 20 fe ff ff 	movl   $0xfffffffe,0x20(%r14)
  19e5ca:	ff 
  19e5cb:	b0 05                	mov    $0x5,%al
  19e5cd:	e9 0e 03 00 00       	jmp    19e8e0 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x860>
  19e5d2:	0f 10 44 24 70       	movups 0x70(%rsp),%xmm0
  19e5d7:	0f 10 8c 24 80 00 00 	movups 0x80(%rsp),%xmm1
  19e5de:	00 
  19e5df:	0f 10 94 24 90 00 00 	movups 0x90(%rsp),%xmm2
  19e5e6:	00 
  19e5e7:	0f 29 54 24 30       	movaps %xmm2,0x30(%rsp)
  19e5ec:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
  19e5f1:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
  19e5f6:	4c 8b bb 08 01 00 00 	mov    0x108(%rbx),%r15
  19e5fd:	4c 8b a3 10 01 00 00 	mov    0x110(%rbx),%r12
  19e604:	49 8b 04 24          	mov    (%r12),%rax
  19e608:	48 85 c0             	test   %rax,%rax
  19e60b:	74 05                	je     19e612 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x592>
  19e60d:	4c 89 ff             	mov    %r15,%rdi
  19e610:	ff d0                	call   *%rax
  19e612:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
  19e617:	48 85 f6             	test   %rsi,%rsi
  19e61a:	74 0e                	je     19e62a <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x5aa>
  19e61c:	49 8b 54 24 10       	mov    0x10(%r12),%rdx
  19e621:	4c 89 ff             	mov    %r15,%rdi
  19e624:	ff 15 4e eb 36 00    	call   *0x36eb4e(%rip)        # 50d178 <_DYNAMIC+0x248>
  19e62a:	c6 83 fb 00 00 00 00 	movb   $0x0,0xfb(%rbx)
  19e631:	4c 8b 7b 30          	mov    0x30(%rbx),%r15
  19e635:	c6 83 fa 00 00 00 00 	movb   $0x0,0xfa(%rbx)
  19e63c:	0f 10 43 60          	movups 0x60(%rbx),%xmm0
  19e640:	0f 10 4b 70          	movups 0x70(%rbx),%xmm1
  19e644:	0f 10 93 80 00 00 00 	movups 0x80(%rbx),%xmm2
  19e64b:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
  19e652:	00 
  19e653:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
  19e65a:	00 
  19e65b:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  19e660:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  19e664:	74 53                	je     19e6b9 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x639>
  19e666:	48 8b 43 58          	mov    0x58(%rbx),%rax
  19e66a:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  19e66f:	0f 10 43 38          	movups 0x38(%rbx),%xmm0
  19e673:	0f 10 4b 48          	movups 0x48(%rbx),%xmm1
  19e677:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  19e67c:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  19e681:	48 83 7c 24 70 ff    	cmpq   $0xffffffffffffffff,0x70(%rsp)
  19e687:	74 0a                	je     19e693 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x613>
  19e689:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e68e:	e8 ed f8 ff ff       	call   19df80 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  19e693:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  19e698:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
  19e69d:	0f 28 54 24 30       	movaps 0x30(%rsp),%xmm2
  19e6a2:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
  19e6a9:	00 
  19e6aa:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
  19e6b1:	00 
  19e6b2:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  19e6b7:	eb 51                	jmp    19e70a <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x68a>
  19e6b9:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  19e6be:	0f 10 43 68          	movups 0x68(%rbx),%xmm0
  19e6c2:	0f 10 4b 78          	movups 0x78(%rbx),%xmm1
  19e6c6:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
  19e6cb:	0f 29 4c 24 50       	movaps %xmm1,0x50(%rsp)
  19e6d0:	48 8b 83 88 00 00 00 	mov    0x88(%rbx),%rax
  19e6d7:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  19e6dc:	0f 28 44 24 10       	movaps 0x10(%rsp),%xmm0
  19e6e1:	0f 28 4c 24 20       	movaps 0x20(%rsp),%xmm1
  19e6e6:	0f 28 54 24 30       	movaps 0x30(%rsp),%xmm2
  19e6eb:	0f 29 94 24 90 00 00 	movaps %xmm2,0x90(%rsp)
  19e6f2:	00 
  19e6f3:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
  19e6fa:	00 
  19e6fb:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
  19e700:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  19e704:	0f 84 ee 01 00 00    	je     19e8f8 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x878>
  19e70a:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  19e70f:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  19e716:	00 
  19e717:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
  19e71c:	0f 28 4c 24 50       	movaps 0x50(%rsp),%xmm1
  19e721:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  19e728:	00 
  19e729:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  19e730:	00 
  19e731:	48 83 7c 24 70 ff    	cmpq   $0xffffffffffffffff,0x70(%rsp)
  19e737:	74 0a                	je     19e743 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x6c3>
  19e739:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e73e:	e8 3d f8 ff ff       	call   19df80 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  19e743:	c6 83 fa 00 00 00 00 	movb   $0x0,0xfa(%rbx)
  19e74a:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
  19e74f:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
  19e756:	00 
  19e757:	0f 28 8c 24 a0 01 00 	movaps 0x1a0(%rsp),%xmm1
  19e75e:	00 
  19e75f:	0f 11 44 24 78       	movups %xmm0,0x78(%rsp)
  19e764:	0f 11 8c 24 88 00 00 	movups %xmm1,0x88(%rsp)
  19e76b:	00 
  19e76c:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
  19e773:	00 
  19e774:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  19e77b:	00 
  19e77c:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  19e783:	00 00 
  19e785:	48 c7 44 24 48 01 00 	movq   $0x1,0x48(%rsp)
  19e78c:	00 00 
  19e78e:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  19e795:	00 00 
  19e797:	48 c7 44 24 20 20 00 	movq   $0x60000020,0x20(%rsp)
  19e79e:	00 60 
  19e7a0:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
  19e7a5:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  19e7aa:	48 8d 05 8f 54 34 00 	lea    0x34548f(%rip),%rax        # 4e3c40 <anon.da59e8131a022f4b4f3ef8e3eb443d3a.8.llvm.12540191330197700236+0x80>
  19e7b1:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  19e7b6:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e7bb:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
  19e7c0:	ff 15 12 ed 36 00    	call   *0x36ed12(%rip)        # 50d4d8 <_DYNAMIC+0x5a8>
  19e7c6:	84 c0                	test   %al,%al
  19e7c8:	0f 85 dc 01 00 00    	jne    19e9aa <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x92a>
  19e7ce:	4c 8b 7c 24 40       	mov    0x40(%rsp),%r15
  19e7d3:	0f 10 44 24 48       	movups 0x48(%rsp),%xmm0
  19e7d8:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  19e7df:	00 
  19e7e0:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19e7e5:	e8 96 f7 ff ff       	call   19df80 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  19e7ea:	c6 83 fb 00 00 00 00 	movb   $0x0,0xfb(%rbx)
  19e7f1:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
  19e7f8:	f0 48 ff 08          	lock decq (%rax)
  19e7fc:	75 0d                	jne    19e80b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x78b>
  19e7fe:	48 8d bb c8 00 00 00 	lea    0xc8(%rbx),%rdi
  19e805:	ff 15 fd ea 36 00    	call   *0x36eafd(%rip)        # 50d308 <_DYNAMIC+0x3d8>
  19e80b:	c6 83 fc 00 00 00 00 	movb   $0x0,0xfc(%rbx)
  19e812:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
  19e819:	f0 48 ff 08          	lock decq (%rax)
  19e81d:	75 0c                	jne    19e82b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x7ab>
  19e81f:	48 8d bb c0 00 00 00 	lea    0xc0(%rbx),%rdi
  19e826:	e8 55 51 ff ff       	call   193980 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  19e82b:	66 c7 83 fd 00 00 00 	movw   $0x0,0xfd(%rbx)
  19e832:	00 00 
  19e834:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  19e83b:	f0 48 ff 08          	lock decq (%rax)
  19e83f:	75 0d                	jne    19e84e <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x7ce>
  19e841:	48 8d bb a0 00 00 00 	lea    0xa0(%rbx),%rdi
  19e848:	ff 15 5a eb 36 00    	call   *0x36eb5a(%rip)        # 50d3a8 <_DYNAMIC+0x478>
  19e84e:	c6 83 ff 00 00 00 00 	movb   $0x0,0xff(%rbx)
  19e855:	66 c7 83 f8 00 00 00 	movw   $0x0,0xf8(%rbx)
  19e85c:	00 00 
  19e85e:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  19e865:	41 bc 01 00 00 00    	mov    $0x1,%r12d
  19e86b:	f0 48 ff 08          	lock decq (%rax)
  19e86f:	74 17                	je     19e888 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x808>
  19e871:	eb 22                	jmp    19e895 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x815>
  19e873:	4c 8b bb e4 00 00 00 	mov    0xe4(%rbx),%r15
  19e87a:	49 c1 e4 20          	shl    $0x20,%r12
  19e87e:	49 83 cc 02          	or     $0x2,%r12
  19e882:	f0 48 ff 08          	lock decq (%rax)
  19e886:	75 0d                	jne    19e895 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x815>
  19e888:	48 8d bb 98 00 00 00 	lea    0x98(%rbx),%rdi
  19e88f:	ff 15 6b ea 36 00    	call   *0x36ea6b(%rip)        # 50d300 <_DYNAMIC+0x3d0>
  19e895:	c6 83 00 01 00 00 00 	movb   $0x0,0x100(%rbx)
  19e89c:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  19e8a3:	f0 48 ff 08          	lock decq (%rax)
  19e8a7:	75 0d                	jne    19e8b6 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x836>
  19e8a9:	48 8d bb 90 00 00 00 	lea    0x90(%rbx),%rdi
  19e8b0:	ff 15 42 ea 36 00    	call   *0x36ea42(%rip)        # 50d2f8 <_DYNAMIC+0x3c8>
  19e8b6:	c6 83 01 01 00 00 00 	movb   $0x0,0x101(%rbx)
  19e8bd:	bd ff ff ff ff       	mov    $0xffffffff,%ebp
  19e8c2:	4d 89 26             	mov    %r12,(%r14)
  19e8c5:	4d 89 7e 08          	mov    %r15,0x8(%r14)
  19e8c9:	0f 28 84 24 c0 01 00 	movaps 0x1c0(%rsp),%xmm0
  19e8d0:	00 
  19e8d1:	41 0f 11 46 10       	movups %xmm0,0x10(%r14)
  19e8d6:	41 89 6e 20          	mov    %ebp,0x20(%r14)
  19e8da:	4d 89 6e 24          	mov    %r13,0x24(%r14)
  19e8de:	b0 01                	mov    $0x1,%al
  19e8e0:	88 83 02 01 00 00    	mov    %al,0x102(%rbx)
  19e8e6:	48 81 c4 48 02 00 00 	add    $0x248,%rsp
  19e8ed:	5b                   	pop    %rbx
  19e8ee:	41 5c                	pop    %r12
  19e8f0:	41 5d                	pop    %r13
  19e8f2:	41 5e                	pop    %r14
  19e8f4:	41 5f                	pop    %r15
  19e8f6:	5d                   	pop    %rbp
  19e8f7:	c3                   	ret
  19e8f8:	4c 8b 7c 24 70       	mov    0x70(%rsp),%r15
  19e8fd:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  19e902:	0f 10 4c 24 28       	movups 0x28(%rsp),%xmm1
  19e907:	0f 29 84 24 90 01 00 	movaps %xmm0,0x190(%rsp)
  19e90e:	00 
  19e90f:	0f 29 8c 24 a0 01 00 	movaps %xmm1,0x1a0(%rsp)
  19e916:	00 
  19e917:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  19e91c:	48 89 84 24 b0 01 00 	mov    %rax,0x1b0(%rsp)
  19e923:	00 
  19e924:	c6 83 fa 00 00 00 00 	movb   $0x0,0xfa(%rbx)
  19e92b:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
  19e92f:	0f 85 15 fe ff ff    	jne    19e74a <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x6ca>
  19e935:	4c 8b a3 90 00 00 00 	mov    0x90(%rbx),%r12
  19e93c:	4c 8b bb 98 00 00 00 	mov    0x98(%rbx),%r15
  19e943:	66 c7 83 00 01 00 00 	movw   $0x0,0x100(%rbx)
  19e94a:	00 00 
  19e94c:	8b ab e0 00 00 00    	mov    0xe0(%rbx),%ebp
  19e952:	4c 8b ab e4 00 00 00 	mov    0xe4(%rbx),%r13
  19e959:	0f 10 83 c0 00 00 00 	movups 0xc0(%rbx),%xmm0
  19e960:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
  19e967:	00 
  19e968:	c7 83 fb 00 00 00 00 	movl   $0x0,0xfb(%rbx)
  19e96f:	00 00 00 
  19e972:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  19e979:	f0 48 ff 08          	lock decq (%rax)
  19e97d:	75 0d                	jne    19e98c <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x90c>
  19e97f:	48 8d bb a0 00 00 00 	lea    0xa0(%rbx),%rdi
  19e986:	ff 15 1c ea 36 00    	call   *0x36ea1c(%rip)        # 50d3a8 <_DYNAMIC+0x478>
  19e98c:	c6 83 ff 00 00 00 00 	movb   $0x0,0xff(%rbx)
  19e993:	66 c7 83 f8 00 00 00 	movw   $0x0,0xf8(%rbx)
  19e99a:	00 00 
  19e99c:	66 c7 83 00 01 00 00 	movw   $0x0,0x100(%rbx)
  19e9a3:	00 00 
  19e9a5:	e9 18 ff ff ff       	jmp    19e8c2 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0x842>
  19e9aa:	48 8d 3d e2 dc ef ff 	lea    -0x10231e(%rip),%rdi        # 9c693 <anon.da59e8131a022f4b4f3ef8e3eb443d3a.2.llvm.12540191330197700236+0x3b8b>
  19e9b1:	48 8d 0d 68 52 34 00 	lea    0x345268(%rip),%rcx        # 4e3c20 <anon.da59e8131a022f4b4f3ef8e3eb443d3a.8.llvm.12540191330197700236+0x60>
  19e9b8:	4c 8d 05 b1 52 34 00 	lea    0x3452b1(%rip),%r8        # 4e3c70 <anon.da59e8131a022f4b4f3ef8e3eb443d3a.8.llvm.12540191330197700236+0xb0>
  19e9bf:	48 8d 54 24 0f       	lea    0xf(%rsp),%rdx
  19e9c4:	be 37 00 00 00       	mov    $0x37,%esi
  19e9c9:	ff 15 21 e9 36 00    	call   *0x36e921(%rip)        # 50d2f0 <_DYNAMIC+0x3c0>
  19e9cf:	0f 0b                	ud2
  19e9d1:	48 8d 3d 30 52 34 00 	lea    0x345230(%rip),%rdi        # 4e3c08 <anon.da59e8131a022f4b4f3ef8e3eb443d3a.8.llvm.12540191330197700236+0x48>
  19e9d8:	ff 15 b2 ea 36 00    	call   *0x36eab2(%rip)        # 50d490 <_DYNAMIC+0x560>
  19e9de:	48 8d 3d 23 52 34 00 	lea    0x345223(%rip),%rdi        # 4e3c08 <anon.da59e8131a022f4b4f3ef8e3eb443d3a.8.llvm.12540191330197700236+0x48>
  19e9e5:	ff 15 9d ea 36 00    	call   *0x36ea9d(%rip)        # 50d488 <_DYNAMIC+0x558>
  19e9eb:	e9 e0 00 00 00       	jmp    19ead0 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xa50>
  19e9f0:	49 89 c6             	mov    %rax,%r14
  19e9f3:	48 83 7c 24 10 ff    	cmpq   $0xffffffffffffffff,0x10(%rsp)
  19e9f9:	0f 84 4c 01 00 00    	je     19eb4b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xacb>
  19e9ff:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  19ea04:	e8 77 f5 ff ff       	call   19df80 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  19ea09:	e9 3d 01 00 00       	jmp    19eb4b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xacb>
  19ea0e:	49 89 c6             	mov    %rax,%r14
  19ea11:	e9 e8 01 00 00       	jmp    19ebfe <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb7e>
  19ea16:	e9 9d 00 00 00       	jmp    19eab8 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xa38>
  19ea1b:	e9 b0 00 00 00       	jmp    19ead0 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xa50>
  19ea20:	e9 d8 00 00 00       	jmp    19eafd <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xa7d>
  19ea25:	49 89 c6             	mov    %rax,%r14
  19ea28:	49 8b 75 08          	mov    0x8(%r13),%rsi
  19ea2c:	48 85 f6             	test   %rsi,%rsi
  19ea2f:	0f 84 76 01 00 00    	je     19ebab <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb2b>
  19ea35:	49 8b 55 10          	mov    0x10(%r13),%rdx
  19ea39:	4c 89 e7             	mov    %r12,%rdi
  19ea3c:	ff 15 36 e7 36 00    	call   *0x36e736(%rip)        # 50d178 <_DYNAMIC+0x248>
  19ea42:	e9 64 01 00 00       	jmp    19ebab <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb2b>
  19ea47:	49 89 c6             	mov    %rax,%r14
  19ea4a:	66 c7 83 01 01 00 00 	movw   $0x200,0x101(%rbx)
  19ea51:	00 02 
  19ea53:	4c 89 f7             	mov    %r14,%rdi
  19ea56:	e8 65 19 34 00       	call   4e03c0 <_Unwind_Resume@plt>
  19ea5b:	49 89 c6             	mov    %rax,%r14
  19ea5e:	e9 4d 02 00 00       	jmp    19ecb0 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xc30>
  19ea63:	49 89 c6             	mov    %rax,%r14
  19ea66:	49 8b 75 08          	mov    0x8(%r13),%rsi
  19ea6a:	48 85 f6             	test   %rsi,%rsi
  19ea6d:	0f 84 f0 00 00 00    	je     19eb63 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xae3>
  19ea73:	49 8b 55 10          	mov    0x10(%r13),%rdx
  19ea77:	4c 89 e7             	mov    %r12,%rdi
  19ea7a:	ff 15 f8 e6 36 00    	call   *0x36e6f8(%rip)        # 50d178 <_DYNAMIC+0x248>
  19ea80:	c6 83 fa 00 00 00 00 	movb   $0x0,0xfa(%rbx)
  19ea87:	e9 07 01 00 00       	jmp    19eb93 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb13>
  19ea8c:	49 89 c6             	mov    %rax,%r14
  19ea8f:	49 8b 74 24 08       	mov    0x8(%r12),%rsi
  19ea94:	48 85 f6             	test   %rsi,%rsi
  19ea97:	0f 84 ae 00 00 00    	je     19eb4b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xacb>
  19ea9d:	49 8b 54 24 10       	mov    0x10(%r12),%rdx
  19eaa2:	4c 89 ff             	mov    %r15,%rdi
  19eaa5:	ff 15 cd e6 36 00    	call   *0x36e6cd(%rip)        # 50d178 <_DYNAMIC+0x248>
  19eaab:	e9 9b 00 00 00       	jmp    19eb4b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xacb>
  19eab0:	49 89 c6             	mov    %rax,%r14
  19eab3:	e9 f3 00 00 00       	jmp    19ebab <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb2b>
  19eab8:	49 89 c6             	mov    %rax,%r14
  19eabb:	e9 15 01 00 00       	jmp    19ebd5 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb55>
  19eac0:	49 89 c6             	mov    %rax,%r14
  19eac3:	e9 14 01 00 00       	jmp    19ebdc <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb5c>
  19eac8:	49 89 c6             	mov    %rax,%r14
  19eacb:	e9 2e 01 00 00       	jmp    19ebfe <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb7e>
  19ead0:	49 89 c6             	mov    %rax,%r14
  19ead3:	e9 63 01 00 00       	jmp    19ec3b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xbbb>
  19ead8:	49 89 c6             	mov    %rax,%r14
  19eadb:	e9 71 01 00 00       	jmp    19ec51 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xbd1>
  19eae0:	49 89 c6             	mov    %rax,%r14
  19eae3:	e9 85 01 00 00       	jmp    19ec6d <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xbed>
  19eae8:	49 89 c6             	mov    %rax,%r14
  19eaeb:	e9 96 01 00 00       	jmp    19ec86 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xc06>
  19eaf0:	49 89 c6             	mov    %rax,%r14
  19eaf3:	eb 6e                	jmp    19eb63 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xae3>
  19eaf5:	49 89 c6             	mov    %rax,%r14
  19eaf8:	e9 96 00 00 00       	jmp    19eb93 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb13>
  19eafd:	49 89 c6             	mov    %rax,%r14
  19eb00:	eb 49                	jmp    19eb4b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xacb>
  19eb02:	49 89 c6             	mov    %rax,%r14
  19eb05:	48 8b bb 18 01 00 00 	mov    0x118(%rbx),%rdi
  19eb0c:	48 8b b3 20 01 00 00 	mov    0x120(%rbx),%rsi
  19eb13:	e8 b8 ed ff ff       	call   19d8d0 <core::ptr::drop_glue::<core::pin::Pin<alloc::boxed::Box<dyn wgpu::dispatch::PopErrorScopeFuture<Output = core::option::Option<wgpu::api::device::Error>>>>>>
  19eb18:	e9 8e 00 00 00       	jmp    19ebab <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb2b>
  19eb1d:	49 89 c6             	mov    %rax,%r14
  19eb20:	48 8b bb 08 01 00 00 	mov    0x108(%rbx),%rdi
  19eb27:	48 8b b3 10 01 00 00 	mov    0x110(%rbx),%rsi
  19eb2e:	e8 9d ed ff ff       	call   19d8d0 <core::ptr::drop_glue::<core::pin::Pin<alloc::boxed::Box<dyn wgpu::dispatch::PopErrorScopeFuture<Output = core::option::Option<wgpu::api::device::Error>>>>>>
  19eb33:	eb 2e                	jmp    19eb63 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xae3>
  19eb35:	49 89 c6             	mov    %rax,%r14
  19eb38:	48 8b bb 08 01 00 00 	mov    0x108(%rbx),%rdi
  19eb3f:	48 8b b3 10 01 00 00 	mov    0x110(%rbx),%rsi
  19eb46:	e8 85 ed ff ff       	call   19d8d0 <core::ptr::drop_glue::<core::pin::Pin<alloc::boxed::Box<dyn wgpu::dispatch::PopErrorScopeFuture<Output = core::option::Option<wgpu::api::device::Error>>>>>>
  19eb4b:	80 bb fa 00 00 00 00 	cmpb   $0x0,0xfa(%rbx)
  19eb52:	74 0f                	je     19eb63 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xae3>
  19eb54:	83 7b 60 ff          	cmpl   $0xffffffff,0x60(%rbx)
  19eb58:	74 09                	je     19eb63 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xae3>
  19eb5a:	48 8d 7b 60          	lea    0x60(%rbx),%rdi
  19eb5e:	e8 1d f4 ff ff       	call   19df80 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  19eb63:	c6 83 fa 00 00 00 00 	movb   $0x0,0xfa(%rbx)
  19eb6a:	eb 27                	jmp    19eb93 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb13>
  19eb6c:	49 89 c6             	mov    %rax,%r14
  19eb6f:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  19eb74:	48 85 f6             	test   %rsi,%rsi
  19eb77:	74 10                	je     19eb89 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb09>
  19eb79:	48 8b 7c 24 48       	mov    0x48(%rsp),%rdi
  19eb7e:	ba 01 00 00 00       	mov    $0x1,%edx
  19eb83:	ff 15 ef e5 36 00    	call   *0x36e5ef(%rip)        # 50d178 <_DYNAMIC+0x248>
  19eb89:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
  19eb8e:	e8 ed f3 ff ff       	call   19df80 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  19eb93:	80 bb fb 00 00 00 00 	cmpb   $0x0,0xfb(%rbx)
  19eb9a:	74 0f                	je     19ebab <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb2b>
  19eb9c:	83 7b 30 ff          	cmpl   $0xffffffff,0x30(%rbx)
  19eba0:	74 09                	je     19ebab <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb2b>
  19eba2:	48 8d 7b 30          	lea    0x30(%rbx),%rdi
  19eba6:	e8 d5 f3 ff ff       	call   19df80 <core::ptr::drop_glue::<wgpu::api::device::Error>>
  19ebab:	c6 83 fb 00 00 00 00 	movb   $0x0,0xfb(%rbx)
  19ebb2:	80 bb fc 00 00 00 00 	cmpb   $0x0,0xfc(%rbx)
  19ebb9:	74 1a                	je     19ebd5 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb55>
  19ebbb:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
  19ebc2:	f0 48 ff 08          	lock decq (%rax)
  19ebc6:	75 0d                	jne    19ebd5 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb55>
  19ebc8:	48 8d bb c8 00 00 00 	lea    0xc8(%rbx),%rdi
  19ebcf:	ff 15 33 e7 36 00    	call   *0x36e733(%rip)        # 50d308 <_DYNAMIC+0x3d8>
  19ebd5:	c6 83 fc 00 00 00 00 	movb   $0x0,0xfc(%rbx)
  19ebdc:	80 bb fd 00 00 00 00 	cmpb   $0x0,0xfd(%rbx)
  19ebe3:	74 19                	je     19ebfe <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb7e>
  19ebe5:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
  19ebec:	f0 48 ff 08          	lock decq (%rax)
  19ebf0:	75 0c                	jne    19ebfe <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb7e>
  19ebf2:	48 8d bb c0 00 00 00 	lea    0xc0(%rbx),%rdi
  19ebf9:	e8 82 4d ff ff       	call   193980 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  19ebfe:	c6 83 fd 00 00 00 00 	movb   $0x0,0xfd(%rbx)
  19ec05:	80 bb fe 00 00 00 00 	cmpb   $0x0,0xfe(%rbx)
  19ec0c:	74 0c                	je     19ec1a <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xb9a>
  19ec0e:	48 8d bb a8 00 00 00 	lea    0xa8(%rbx),%rdi
  19ec15:	e8 16 ed ff ff       	call   19d930 <core::ptr::drop_glue::<core::option::Option<(wgpu::api::shader_module::ShaderModule, wgpu::api::bind_group_layout::BindGroupLayout, wgpu::api::pipeline_layout::PipelineLayout)>>>
  19ec1a:	c6 83 fe 00 00 00 00 	movb   $0x0,0xfe(%rbx)
  19ec21:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
  19ec28:	f0 48 ff 08          	lock decq (%rax)
  19ec2c:	75 0d                	jne    19ec3b <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xbbb>
  19ec2e:	48 8d bb a0 00 00 00 	lea    0xa0(%rbx),%rdi
  19ec35:	ff 15 6d e7 36 00    	call   *0x36e76d(%rip)        # 50d3a8 <_DYNAMIC+0x478>
  19ec3b:	80 bb ff 00 00 00 00 	cmpb   $0x0,0xff(%rbx)
  19ec42:	74 0d                	je     19ec51 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xbd1>
  19ec44:	48 8d bc 24 d8 01 00 	lea    0x1d8(%rsp),%rdi
  19ec4b:	00 
  19ec4c:	e8 cf f2 ff ff       	call   19df20 <core::ptr::drop_glue::<wgpu::api::device::ErrorScopeGuard>>
  19ec51:	c6 83 ff 00 00 00 00 	movb   $0x0,0xff(%rbx)
  19ec58:	80 bb f8 00 00 00 00 	cmpb   $0x0,0xf8(%rbx)
  19ec5f:	74 0c                	je     19ec6d <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xbed>
  19ec61:	48 8d bb 08 01 00 00 	lea    0x108(%rbx),%rdi
  19ec68:	e8 b3 f2 ff ff       	call   19df20 <core::ptr::drop_glue::<wgpu::api::device::ErrorScopeGuard>>
  19ec6d:	c6 83 f8 00 00 00 00 	movb   $0x0,0xf8(%rbx)
  19ec74:	80 bb f9 00 00 00 00 	cmpb   $0x0,0xf9(%rbx)
  19ec7b:	74 09                	je     19ec86 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xc06>
  19ec7d:	48 8d 7b 20          	lea    0x20(%rbx),%rdi
  19ec81:	e8 9a f2 ff ff       	call   19df20 <core::ptr::drop_glue::<wgpu::api::device::ErrorScopeGuard>>
  19ec86:	c6 83 f9 00 00 00 00 	movb   $0x0,0xf9(%rbx)
  19ec8d:	80 bb 00 01 00 00 00 	cmpb   $0x0,0x100(%rbx)
  19ec94:	74 1a                	je     19ecb0 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xc30>
  19ec96:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
  19ec9d:	f0 48 ff 08          	lock decq (%rax)
  19eca1:	75 0d                	jne    19ecb0 <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xc30>
  19eca3:	48 8d bb 98 00 00 00 	lea    0x98(%rbx),%rdi
  19ecaa:	ff 15 50 e6 36 00    	call   *0x36e650(%rip)        # 50d300 <_DYNAMIC+0x3d0>
  19ecb0:	c6 83 00 01 00 00 00 	movb   $0x0,0x100(%rbx)
  19ecb7:	80 bb 01 01 00 00 00 	cmpb   $0x0,0x101(%rbx)
  19ecbe:	74 1a                	je     19ecda <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xc5a>
  19ecc0:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
  19ecc7:	f0 48 ff 08          	lock decq (%rax)
  19eccb:	75 0d                	jne    19ecda <<gpui_gpu::renderer::GpuContext>::new::{closure#0}+0xc5a>
  19eccd:	48 8d bb 90 00 00 00 	lea    0x90(%rbx),%rdi
  19ecd4:	ff 15 1e e6 36 00    	call   *0x36e61e(%rip)        # 50d2f8 <_DYNAMIC+0x3c8>
  19ecda:	66 c7 83 01 01 00 00 	movw   $0x200,0x101(%rbx)
  19ece1:	00 02 
  19ece3:	4c 89 f7             	mov    %r14,%rdi
  19ece6:	e8 d5 16 34 00       	call   4e03c0 <_Unwind_Resume@plt>
  19eceb:	ff 15 df e4 36 00    	call   *0x36e4df(%rip)        # 50d1d0 <_DYNAMIC+0x2a0>
  19ecf1:	cc                   	int3
  19ecf2:	cc                   	int3
  19ecf3:	cc                   	int3
  19ecf4:	cc                   	int3
  19ecf5:	cc                   	int3
  19ecf6:	cc                   	int3
  19ecf7:	cc                   	int3
  19ecf8:	cc                   	int3
  19ecf9:	cc                   	int3
  19ecfa:	cc                   	int3
  19ecfb:	cc                   	int3
  19ecfc:	cc                   	int3
  19ecfd:	cc                   	int3
  19ecfe:	cc                   	int3
  19ecff:	cc                   	int3
