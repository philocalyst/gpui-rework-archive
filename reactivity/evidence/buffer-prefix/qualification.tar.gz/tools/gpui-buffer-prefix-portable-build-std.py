from pathlib import Path
import hashlib, json, os, signal, subprocess, traceback
root=Path('/tmp/gpui-buffer-prefix-root'); cwd=root/'reactivity'; out=Path('/tmp/gpui-buffer-prefix-gates')
git=['git','-c',f'safe.directory={root}','-C',str(root)]
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=subprocess.check_output(git+['ls-files','.cargo/config.toml','reactivity/Cargo.toml','reactivity/Cargo.lock','reactivity/.cargo','reactivity/vendor','reactivity/crates'],text=True).splitlines()
guard=lambda:{name:digest(root/name) for name in files}
before=guard(); previous=json.loads((out/'source-guard.json').read_text()); assert before==previous
env=os.environ.copy();env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
env.update(CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/tmp/gpui-buffer-prefix-target',RUSTC_BOOTSTRAP='1',GPUI_SPIRV_VAL='/nix/store/z5hs3p3inrq3w8cv71jycz7l4y3ny5xk-spirv-tools-1.4.363.0/bin/spirv-val')
result={'source':subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip(),'guarded_files':len(files),'shipping_tests_log_sha256':digest(Path('/tmp/gpui-buffer-prefix-shipping-tests.log')),'checks':[],'limits':'Foreign target compilation only; no foreign linking or runtime.'}
try:
 for target in ['x86_64-apple-darwin','x86_64-pc-windows-msvc']:
  command=['cargo','check','--offline','--locked','-p','gpui_gpu','--lib','--features','offline-shader','--target',target,'-Zbuild-std=std,panic_abort']
  log=out/('shipping-check-'+target+'.log')
  with log.open('w') as output:
   p=subprocess.Popen(command,cwd=cwd,env=env,stdout=output,stderr=subprocess.STDOUT,start_new_session=True)
   try:code=p.wait(timeout=1200)
   except BaseException:
    os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
    raise
  row={'target':target,'command':command,'exit':code,'log_sha256':digest(log)}
  result['checks'].append(row);print(json.dumps(row),flush=True)
  assert code==0,row
  assert guard()==before
 result['status']='passed'
except BaseException:
 result.update(status='failed',failure=traceback.format_exc());raise
finally:
 result['source_unchanged']=guard()==before
 (out/'portable-build-std.json').write_text(json.dumps(result,indent=2)+'\n')
