from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,tempfile,re
root=Path('/tmp/gpui-buffer-prefix-root');cwd=root/'reactivity';out=Path('/tmp/gpui-buffer-prefix-gates')
destination=cwd/'evidence/buffer-prefix'
assert not destination.exists()
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=['git','-c',f'safe.directory={root}','-C',str(root)]
meta=json.loads((out/'metadata.json').read_text());cross=json.loads((out/'portable-build-std.json').read_text())
assert meta['status']=='passed' and meta['restored_source_unchanged'] and cross['status']=='passed' and cross['source_unchanged']
assert subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip()==cross['source']
guards=json.loads((out/'source-guard.json').read_text())
assert all(digest(root/name)==h for name,h in guards.items())
assert all(digest(Path(name))==h for name,h in meta['executables'].items())
baseline=json.loads((out/'baseline-build-guard.json').read_text());candidate=json.loads((out/'candidate-build-guard.json').read_text())
assert {name for name,h in baseline.items() if h!=guards[name]}=={'reactivity/vendor/wgpu-core/src/command/memory_init.rs','reactivity/crates/gpu/src/renderer.rs'}
assert {name for name,h in candidate.items() if h!=guards[name]}=={'reactivity/vendor/wgpu-core/src/command/memory_init.rs'}
summary={'source':cross['source'],'baseline':meta['source'],'guarded_files':len(guards),'shipping_files':{name:digest(root/name) for name in ['reactivity/crates/gpu/src/renderer.rs','reactivity/crates/gpu/tests/render.rs']},'clear_dispatches':{}}
for variant in ['baseline','candidate']:
 rows=[]
 for label,start,end in re.findall(r'GPUI_PREFIX_CLEAR "([^"]*)" (\d+) (\d+)',(out/(variant+'-prefix-clear-control.log')).read_text()):
  rows.append({'label':label,'start':int(start),'end':int(end),'bytes':int(end)-int(start)})
 summary['clear_dispatches'][variant]={'rows':rows,'scene':{'calls':sum(r['label']!='readback' for r in rows),'bytes':sum(r['bytes'] for r in rows if r['label']!='readback')},'readback':{'calls':sum(r['label']=='readback' for r in rows),'bytes':sum(r['bytes'] for r in rows if r['label']=='readback')}}
b=summary['clear_dispatches']['baseline'];c=summary['clear_dispatches']['candidate']
assert b['scene']=={'calls':8,'bytes':1360} and c['scene']=={'calls':2,'bytes':20}
assert b['readback']==c['readback']
summary['removed_tail_clears']={'calls':6,'bytes':1340}
shipping=Path('/tmp/gpui-buffer-prefix-shipping-tests.log')
rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',shipping.read_text())
summary['shipping_tests']={'groups':len(rows),'passed':sum(int(r[0]) for r in rows),'failed':sum(int(r[1]) for r in rows),'ignored':sum(int(r[2]) for r in rows)}
assert summary['shipping_tests']=={'groups':4,'passed':62,'failed':0,'ignored':0}
counter=json.loads(Path('/tmp/gpui-buffer-prefix-core-lines.json').read_text());assert counter['core_non_test_code_lines']==30692
summary.update(core_code_lines=30692,core_delta=11,limits=meta['limits'])
with tempfile.TemporaryDirectory(prefix='gpui-buffer-prefix-archive-') as folder:
 stage=Path(folder)
 for p in out.rglob('*'):
  if p.is_file() and not p.name.endswith('-frozen'):
   target=stage/'qualification'/p.relative_to(out);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
 (stage/'tools').mkdir()
 for name in ['/tmp/gpui-buffer-prefix-gates.py','/tmp/gpui-buffer-prefix-portable.py','/tmp/gpui-buffer-prefix-portable-build-std.py','/tmp/gpui-native-env.sh',__file__]:shutil.copyfile(name,stage/'tools'/Path(name).name)
 shutil.copyfile(shipping,stage/'shipping-tests.log')
 shutil.copyfile('/tmp/gpui-buffer-prefix-review.md',stage/'independent-review.md')
 shutil.copyfile('/tmp/gpui-gpu-initialization-elision-luna.md',stage/'initialization-frontier-luna.md')
 (stage/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 shutil.copyfile('/tmp/gpui-buffer-prefix-core-lines.json',stage/'core-lines.json')
 manifest={str(p.relative_to(stage)):digest(p) for p in sorted(stage.rglob('*')) if p.is_file()}
 (stage/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
 destination.mkdir()
 archive=destination/'qualification.tar.gz'
 with tarfile.open(archive,'w:gz') as tar:
  for p in sorted(stage.rglob('*')):
   if p.is_file():
    info=tar.gettarinfo(str(p),arcname=str(p.relative_to(stage)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
    with p.open('rb') as content:tar.addfile(info,content)
 with tarfile.open(archive,'r:gz') as tar:
  sealed=json.load(tar.extractfile('MANIFEST.json'));assert len(tar.getmembers())==len(sealed)+1
  for name,h in sealed.items():assert hashlib.sha256(tar.extractfile(name).read()).hexdigest()==h,name
 summary.update(archive_sha256=digest(archive),archive_bytes=archive.stat().st_size,verified_archive_files=len(sealed))
 (destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 (destination/'qualification.tar.gz.sha256').write_text(digest(archive)+'  qualification.tar.gz\n')
 shutil.copyfile('/tmp/gpui-buffer-prefix-core-lines.json',destination/'core-lines.json')
print(json.dumps({k:v for k,v in summary.items() if k!='clear_dispatches'},indent=2))
