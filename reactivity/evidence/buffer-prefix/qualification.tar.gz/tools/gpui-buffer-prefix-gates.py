from pathlib import Path
import hashlib, json, os, shutil, signal, subprocess, traceback

root = Path('/tmp/gpui-buffer-prefix-root')
cwd = root / 'reactivity'
out = Path('/tmp/gpui-buffer-prefix-gates')
out.mkdir(exist_ok=False)
renderer = cwd / 'crates/gpu/src/renderer.rs'
core = cwd / 'vendor/wgpu-core/src/command/memory_init.rs'
original_core = core.read_bytes()
candidate = renderer.read_bytes()
git = ['git', '-c', f'safe.directory={root}', '-C', str(root)]
baseline = subprocess.check_output(git + ['show', 'HEAD:reactivity/crates/gpu/src/renderer.rs'])
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
files = subprocess.check_output(git + ['ls-files', '.cargo/config.toml', 'reactivity/Cargo.toml', 'reactivity/Cargo.lock', 'reactivity/.cargo', 'reactivity/vendor', 'reactivity/crates'], text=True).splitlines()
def guard():
    return {name: digest(root / name) for name in files}
before = guard()
(out / 'source-guard.json').write_text(json.dumps(before, indent=2) + '\n')
(out / 'candidate-renderer.rs').write_bytes(candidate)
(out / 'baseline-renderer.rs').write_bytes(baseline)
(out / 'source.patch').write_bytes(subprocess.check_output(git + ['diff', '--', 'reactivity/crates/gpu']))
metadata = {'source': subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip(), 'rustc': subprocess.check_output(['rustc','-vV'],text=True), 'cargo': subprocess.check_output(['cargo','-V'],text=True), 'guarded_files':len(files), 'limits':'Core clear dispatch observations and Vulkan software pixel validation; no timing, RSS, driver heap, VRAM, or foreign runtime claim.'}
env = os.environ.copy()
env.pop('RUSTFLAGS', None)
env.pop('CARGO_ENCODED_RUSTFLAGS', None)
env['CARGO_BUILD_JOBS'] = '1'
env['CARGO_TARGET_DIR'] = '/tmp/gpui-buffer-prefix-target'
env['GPUI_SPIRV_VAL'] = '/nix/store/z5hs3p3inrq3w8cv71jycz7l4y3ny5xk-spirv-tools-1.4.363.0/bin/spirv-val'
results = []
frozen = {}
def run(name, command, timeout=1200):
    with (out / (name + '.log')).open('w') as log:
        p = subprocess.Popen(command, cwd=cwd, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        try:
            code = p.wait(timeout=timeout)
        except BaseException:
            os.killpg(p.pid, signal.SIGTERM)
            try: p.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(p.pid, signal.SIGKILL)
                p.wait()
            raise
    row = {'case':name,'command':command,'exit':code,'log_sha256':digest(out/(name+'.log'))}
    results.append(row)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(row), flush=True)
    assert code == 0, row

try:
    old = b'                unsafe {\n                    self.encoder.raw.clear_buffer(raw_buf, range.clone());'
    new = b'                std::eprintln!("GPUI_PREFIX_CLEAR {:?} {} {}", buffer.label, range.start, range.end);\n'+old
    assert original_core.count(old) == 1
    instrumented = original_core.replace(old,new)
    (out/'core-instrumentation.patch').write_text('Temporary std::eprintln immediately before each actual Core initialization clear_buffer dispatch, printing the buffer label and start/end range. Exact bytes in instrumented-core.rs; shipping original in original-core.rs.\n')
    (out/'instrumented-core.rs').write_bytes(instrumented)
    (out/'original-core.rs').write_bytes(original_core)
    core.write_bytes(instrumented)
    for name, source in [('baseline', baseline), ('candidate', candidate)]:
        renderer.write_bytes(source)
        build_guard = guard()
        (out/(name+'-build-guard.json')).write_text(json.dumps(build_guard,indent=2)+'\n')
        run(name+'-build', ['cargo','test','--offline','--locked','-p','gpui_gpu','--features','vulkan-tests,offline-shader','--no-run','--message-format=json'])
        assert guard() == build_guard
        artifacts=[]
        for line in (out/(name+'-build.log')).read_text().splitlines():
            try: row=json.loads(line)
            except ValueError: continue
            if row.get('reason')=='compiler-artifact' and row.get('executable') and row['profile']['test']:
                artifacts.append(row)
        assert {x['target']['name'] for x in artifacts} == {'gpui_gpu','render','presentation'}, artifacts
        (out/(name+'-artifacts.json')).write_text(json.dumps(artifacts,indent=2)+'\n')
        fp=out/(name+'-fingerprints'); fp.mkdir()
        for package in ['gpui_gpu','wgpu-core','wgpu','gpui_canvas']:
            for directory in (Path(env['CARGO_TARGET_DIR'])/'debug/.fingerprint').glob(package+'-*'):
                for file in directory.glob('*.json'):
                    shutil.copyfile(file,fp/(directory.name+'-'+file.name))
        binaries={}
        for artifact in artifacts:
            binary=out/(name+'-'+artifact['target']['name']+'-frozen')
            shutil.copyfile(artifact['executable'],binary);binary.chmod(0o555)
            frozen[str(binary)]=digest(binary)
            binaries[artifact['target']['name']]=binary
        run(name+'-prefix-clear-control', [str(binaries['render']),'scene_buffer_growth_and_shrinking_prefixes_preserve_pixels_and_replay','--test-threads=1','--nocapture'])
        for target,binary in binaries.items():
            run(name+'-'+target, [str(binary),'--test-threads=1'])
        assert all(digest(Path(path))==value for path,value in frozen.items())
    renderer.write_bytes(candidate)
    core.write_bytes(original_core)
    assert guard() == before
    run('shipping-strict', ['cargo','clippy','--offline','--locked','-p','gpui_gpu','--features','vulkan-tests,offline-shader','--all-targets','--','-D','warnings'])
    run('shipping-format', ['cargo','fmt','--package','gpui_gpu','--','--check'])
    assert guard() == before
    metadata.update(status='passed', source_unchanged=True, executables=frozen)
except BaseException:
    metadata.update(status='failed',failure=traceback.format_exc(),executables=frozen)
    raise
finally:
    renderer.write_bytes(candidate)
    core.write_bytes(original_core)
    metadata['restored_source_unchanged']=guard()==before
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
