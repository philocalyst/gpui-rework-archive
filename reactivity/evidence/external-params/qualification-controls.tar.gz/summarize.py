from pathlib import Path
import hashlib,json,re,subprocess
root=Path('/tmp/gpui-external-params-evidence')
summary={}
fields=['rustc','features','target','profile','rustflags','config','compile_kind']
for variant in ['baseline-counts','candidate-counts']:
 d=root/variant
 text=(d/'run.log').read_text()
 counts={}
 for backend in ['NOOP','VULKAN']:
  rows=[json.loads(s) for s in re.findall(r'constructor backend=Backends\('+backend+r'\).*?allocations=(\[[^\]]+\])',text)]
  assert len(rows)==3 and all(x==rows[0] for x in rows)
  counts[backend]=rows
 fps=[json.loads(p.read_text()) for p in (d/'fingerprints').glob('*test-lib-wgpu_core.json')]
 assert len(fps)==1
 artifacts=[json.loads(line) for line in (d/'artifacts.jsonl').read_text().splitlines()]
 artifact=next(x for x in artifacts if x.get('executable') and x.get('target',{}).get('name')=='wgpu_core')
 assert not artifact['fresh']
 summary[variant]={'counts':counts,'header':re.search(r'^headers Device=.*',text,re.M)[0], 'actual_fingerprint':{k:fps[0][k] for k in fields},'binary_sha256':hashlib.sha256((d/'probe').read_bytes()).hexdigest(),'artifact':artifact}
assert summary['baseline-counts']['actual_fingerprint']==summary['candidate-counts']['actual_fingerprint']
summary['fingerprint_match']=True
summary['candidate_checks']={'without_trace':(root/'candidate-counts/all-tests.log').read_text().split('test result:')[-1].strip(),'with_trace':(root/'candidate-tests/run.log').read_text().split('test result:')[-1].strip(),'baseline_enabled':(root/'baseline-counts/enabled-tests.log').read_text().split('test result:')[-1].strip()}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:{x:v[x] for x in ['counts','header','binary_sha256']} for k,v in summary.items() if k.endswith('counts')},indent=2))
