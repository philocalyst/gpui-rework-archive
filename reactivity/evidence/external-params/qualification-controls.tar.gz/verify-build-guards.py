from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
matched=sha((root/'matched-core.Cargo.lock').read_bytes())
for directory in root.iterdir():
    guard=directory/'source-guards.json'
    if not guard.is_file():continue
    rows=json.loads(guard.read_text())
    qualification=next(key for key in rows if key.endswith('/qualification.rs'))
    source=next(key for key in rows if key.endswith('/src/device/resource.rs'))
    lock=next(key for key in rows if key.endswith('/Cargo.lock'))
    assert sha((directory/'qualification.rs').read_bytes())==rows[qualification]
    footer='\n#[cfg(test)]\n#[allow(unused_imports, dead_code)]\n#[path = '+json.dumps(qualification)+']\nmod external_params_qualification;\n'
    assert sha((directory/'shipping-resource.rs').read_bytes()+footer.encode())==rows[source]
    assert matched==rows[lock]
    assert sha((root/'root-cargo-config.toml').read_bytes())==next(value for key,value in rows.items() if key.endswith('/.cargo/config.toml'))
    probe=directory/'probe'
    if probe.is_file():assert sha(probe.read_bytes())==next(value for key,value in rows.items() if key.endswith('/probe'))
    print(directory.name, 'source, qualification, lock, config and available executable guards PASS')
