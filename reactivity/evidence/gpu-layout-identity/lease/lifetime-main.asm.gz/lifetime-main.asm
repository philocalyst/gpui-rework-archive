
/tmp/gpui-layout-identity-controls/lease/layout-lifetime:     file format elf64-x86-64


Disassembly of section .text:

000000000016e3f0 <layout_lifetime::main>:
  16e3f0:	55                   	push   %rbp
  16e3f1:	41 57                	push   %r15
  16e3f3:	41 56                	push   %r14
  16e3f5:	53                   	push   %rbx
  16e3f6:	48 81 ec f8 07 00 00 	sub    $0x7f8,%rsp
  16e3fd:	ff 15 0d 53 37 00    	call   *0x37530d(%rip)        # 4e3710 <_DYNAMIC+0x3e8>
  16e403:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  16e408:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  16e40d:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  16e412:	ff 15 00 53 37 00    	call   *0x375300(%rip)        # 4e3718 <_DYNAMIC+0x3f0>
  16e418:	48 89 04 24          	mov    %rax,(%rsp)
  16e41c:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  16e421:	48 8d 35 d8 95 34 00 	lea    0x3495d8(%rip),%rsi        # 4b7a00 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0x58>
  16e428:	48 89 e7             	mov    %rsp,%rdi
  16e42b:	ff 15 ef 52 37 00    	call   *0x3752ef(%rip)        # 4e3720 <_DYNAMIC+0x3f8>
  16e431:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  16e436:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  16e43d:	00 00 
  16e43f:	48 8d 9c 24 d0 00 00 	lea    0xd0(%rsp),%rbx
  16e446:	00 
  16e447:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  16e44c:	48 8d 54 24 18       	lea    0x18(%rsp),%rdx
  16e451:	48 89 df             	mov    %rbx,%rdi
  16e454:	e8 57 d2 ff ff       	call   16b6b0 <allocation_counter::measure::<layout_lifetime::main::{closure#0}>>
  16e459:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  16e45e:	4c 8d b4 24 00 01 00 	lea    0x100(%rsp),%r14
  16e465:	00 
  16e466:	4c 89 f7             	mov    %r14,%rdi
  16e469:	e8 52 d9 ff ff       	call   16bdc0 <allocation_counter::measure::<layout_lifetime::main::{closure#1}>>
  16e46e:	48 83 bc 24 d0 00 00 	cmpq   $0x0,0xd0(%rsp)
  16e475:	00 00 
  16e477:	0f 85 51 03 00 00    	jne    16e7ce <layout_lifetime::main+0x3de>
  16e47d:	48 83 bc 24 00 01 00 	cmpq   $0x0,0x100(%rsp)
  16e484:	00 00 
  16e486:	0f 85 4b 03 00 00    	jne    16e7d7 <layout_lifetime::main+0x3e7>
  16e48c:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
  16e493:	00 
  16e494:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  16e49b:	00 
  16e49c:	4c 8d 3d ed 0d 00 00 	lea    0xded(%rip),%r15        # 16f290 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  16e4a3:	4c 89 bc 24 68 01 00 	mov    %r15,0x168(%rsp)
  16e4aa:	00 
  16e4ab:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  16e4b2:	00 
  16e4b3:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  16e4ba:	00 
  16e4bb:	4c 89 bc 24 78 01 00 	mov    %r15,0x178(%rsp)
  16e4c2:	00 
  16e4c3:	48 8d 3d 71 1d f1 ff 	lea    -0xee28f(%rip),%rdi        # 8023b <anon.8f7cdc0594fd4f0c7116fd8b126176fb.552.llvm.10099564126919119806+0x38c>
  16e4ca:	48 8d 9c 24 60 01 00 	lea    0x160(%rsp),%rbx
  16e4d1:	00 
  16e4d2:	48 89 de             	mov    %rbx,%rsi
  16e4d5:	ff 15 4d 52 37 00    	call   *0x37524d(%rip)        # 4e3728 <_DYNAMIC+0x400>
  16e4db:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  16e4e0:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  16e4e7:	00 
  16e4e8:	f0 48 ff 08          	lock decq (%rax)
  16e4ec:	75 0e                	jne    16e4fc <layout_lifetime::main+0x10c>
  16e4ee:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  16e4f5:	00 
  16e4f6:	ff 15 8c 50 37 00    	call   *0x37508c(%rip)        # 4e3588 <_DYNAMIC+0x260>
  16e4fc:	48 8b 04 24          	mov    (%rsp),%rax
  16e500:	f0 48 ff 00          	lock incq (%rax)
  16e504:	0f 8e cb 03 00 00    	jle    16e8d5 <layout_lifetime::main+0x4e5>
  16e50a:	48 8b 04 24          	mov    (%rsp),%rax
  16e50e:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  16e513:	48 c7 44 24 5c 16 00 	movq   $0x16,0x5c(%rsp)
  16e51a:	00 00 
  16e51c:	c7 44 24 64 00 00 00 	movl   $0x0,0x64(%rsp)
  16e523:	00 
  16e524:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  16e52b:	00 
  16e52c:	48 89 8c 24 a0 01 00 	mov    %rcx,0x1a0(%rsp)
  16e533:	00 
  16e534:	0f 10 44 24 50       	movups 0x50(%rsp),%xmm0
  16e539:	0f 11 84 24 a8 01 00 	movups %xmm0,0x1a8(%rsp)
  16e540:	00 
  16e541:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  16e546:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
  16e54d:	00 
  16e54e:	c6 84 24 c3 01 00 00 	movb   $0x0,0x1c3(%rsp)
  16e555:	00 
  16e556:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
  16e55d:	00 
  16e55e:	48 8d 35 5b 94 34 00 	lea    0x34945b(%rip),%rsi        # 4b79c0 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0x18>
  16e565:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  16e56c:	00 
  16e56d:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
  16e574:	00 
  16e575:	e8 a6 da ff ff       	call   16c020 <<std::thread::local::LocalKey<core::task::wake::Waker>>::with::<pollster::block_on<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>::{closure#0}, core::result::Result<gpui_gpu::renderer::GpuContext, gpui_gpu::renderer::Error>>>
  16e57a:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  16e581:	00 
  16e582:	e8 09 f4 ff ff       	call   16d990 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  16e587:	83 bc 24 d0 04 00 00 	cmpl   $0xffffffff,0x4d0(%rsp)
  16e58e:	ff 
  16e58f:	0f 84 65 02 00 00    	je     16e7fa <layout_lifetime::main+0x40a>
  16e595:	0f 10 84 24 b0 04 00 	movups 0x4b0(%rsp),%xmm0
  16e59c:	00 
  16e59d:	0f 10 8c 24 c0 04 00 	movups 0x4c0(%rsp),%xmm1
  16e5a4:	00 
  16e5a5:	0f 10 94 24 d0 04 00 	movups 0x4d0(%rsp),%xmm2
  16e5ac:	00 
  16e5ad:	0f 29 94 24 a0 00 00 	movaps %xmm2,0xa0(%rsp)
  16e5b4:	00 
  16e5b5:	0f 29 8c 24 90 00 00 	movaps %xmm1,0x90(%rsp)
  16e5bc:	00 
  16e5bd:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  16e5c4:	00 
  16e5c5:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  16e5cc:	00 
  16e5cd:	48 8d b4 24 80 00 00 	lea    0x80(%rsp),%rsi
  16e5d4:	00 
  16e5d5:	ff 15 55 51 37 00    	call   *0x375155(%rip)        # 4e3730 <_DYNAMIC+0x408>
  16e5db:	48 8d 05 de 71 f2 ff 	lea    -0xd8e22(%rip),%rax        # 957c0 <anon.fd4379edd0b71335c3c29b3337cd5ea0.54.llvm.353578272256937679+0x18>
  16e5e2:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  16e5e9:	00 
  16e5ea:	48 8b 05 a7 50 37 00 	mov    0x3750a7(%rip),%rax        # 4e3698 <_DYNAMIC+0x370>
  16e5f1:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  16e5f8:	00 
  16e5f9:	48 8d 0d 58 73 f2 ff 	lea    -0xd8ca8(%rip),%rcx        # 95958 <anon.a16d5d421a76dfd8c37a17b53540311d.145.llvm.14190004212411149437+0x70>
  16e600:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  16e607:	00 
  16e608:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  16e60f:	00 
  16e610:	40 b5 01             	mov    $0x1,%bpl
  16e613:	48 8d 3d 0e bd f1 ff 	lea    -0xe42f2(%rip),%rdi        # 8a328 <anon.46a3e2b798de606f8dc289e9df67b47d.1112.llvm.2527675475217510166+0x40a>
  16e61a:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  16e621:	00 
  16e622:	ff 15 00 51 37 00    	call   *0x375100(%rip)        # 4e3728 <_DYNAMIC+0x400>
  16e628:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  16e62f:	00 
  16e630:	0f 28 8c 24 90 00 00 	movaps 0x90(%rsp),%xmm1
  16e637:	00 
  16e638:	0f 28 94 24 a0 00 00 	movaps 0xa0(%rsp),%xmm2
  16e63f:	00 
  16e640:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
  16e647:	00 
  16e648:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  16e64f:	00 
  16e650:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  16e657:	00 
  16e658:	31 ed                	xor    %ebp,%ebp
  16e65a:	48 8d 9c 24 30 01 00 	lea    0x130(%rsp),%rbx
  16e661:	00 
  16e662:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  16e669:	00 
  16e66a:	48 89 df             	mov    %rbx,%rdi
  16e66d:	e8 8e d2 ff ff       	call   16b900 <allocation_counter::measure::<layout_lifetime::main::{closure#2}>>
  16e672:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  16e679:	00 00 
  16e67b:	c7 44 24 48 ff ff ff 	movl   $0xffffffff,0x48(%rsp)
  16e682:	ff 
  16e683:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  16e688:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  16e68f:	00 
  16e690:	8b 44 24 48          	mov    0x48(%rsp),%eax
  16e694:	89 84 24 78 01 00 00 	mov    %eax,0x178(%rsp)
  16e69b:	8b 44 24 4c          	mov    0x4c(%rsp),%eax
  16e69f:	89 84 24 7c 01 00 00 	mov    %eax,0x17c(%rsp)
  16e6a6:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  16e6ab:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  16e6b2:	00 
  16e6b3:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  16e6b8:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  16e6bf:	00 
  16e6c0:	31 ed                	xor    %ebp,%ebp
  16e6c2:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
  16e6c7:	48 89 e6             	mov    %rsp,%rsi
  16e6ca:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  16e6d1:	00 
  16e6d2:	ff 15 60 50 37 00    	call   *0x375060(%rip)        # 4e3738 <_DYNAMIC+0x410>
  16e6d8:	83 7c 24 50 02       	cmpl   $0x2,0x50(%rsp)
  16e6dd:	0f 85 64 01 00 00    	jne    16e847 <layout_lifetime::main+0x457>
  16e6e3:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
  16e6ea:	00 
  16e6eb:	4c 89 bc 24 68 01 00 	mov    %r15,0x168(%rsp)
  16e6f2:	00 
  16e6f3:	31 ed                	xor    %ebp,%ebp
  16e6f5:	48 8d 3d a9 10 f2 ff 	lea    -0xdef57(%rip),%rdi        # 8f7a5 <anon.bf7e3e8257110be5986cfdd74163f765.35.llvm.2336547866852174585+0x38a>
  16e6fc:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  16e703:	00 
  16e704:	ff 15 1e 50 37 00    	call   *0x37501e(%rip)        # 4e3728 <_DYNAMIC+0x400>
  16e70a:	4c 8d b4 24 60 01 00 	lea    0x160(%rsp),%r14
  16e711:	00 
  16e712:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  16e719:	00 
  16e71a:	ba 48 03 00 00       	mov    $0x348,%edx
  16e71f:	4c 89 f7             	mov    %r14,%rdi
  16e722:	ff 15 90 4e 37 00    	call   *0x374e90(%rip)        # 4e35b8 <memcpy@GLIBC_2.14>
  16e728:	48 8d 5c 24 50       	lea    0x50(%rsp),%rbx
  16e72d:	48 89 df             	mov    %rbx,%rdi
  16e730:	4c 89 f6             	mov    %r14,%rsi
  16e733:	e8 28 d4 ff ff       	call   16bb60 <allocation_counter::measure::<layout_lifetime::main::{closure#3}>>
  16e738:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
  16e73f:	00 
  16e740:	48 89 e6             	mov    %rsp,%rsi
  16e743:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
  16e748:	ff 15 ea 4f 37 00    	call   *0x374fea(%rip)        # 4e3738 <_DYNAMIC+0x410>
  16e74e:	83 bc 24 b8 00 00 00 	cmpl   $0x2,0xb8(%rsp)
  16e755:	02 
  16e756:	0f 85 31 01 00 00    	jne    16e88d <layout_lifetime::main+0x49d>
  16e75c:	48 89 9c 24 60 01 00 	mov    %rbx,0x160(%rsp)
  16e763:	00 
  16e764:	4c 89 bc 24 68 01 00 	mov    %r15,0x168(%rsp)
  16e76b:	00 
  16e76c:	48 8d 3d 7d 8f f1 ff 	lea    -0xe7083(%rip),%rdi        # 876f0 <anon.068260129a360d3c14a88deb110120c9.25.llvm.7357624670875813013+0x6e4>
  16e773:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  16e77a:	00 
  16e77b:	ff 15 a7 4f 37 00    	call   *0x374fa7(%rip)        # 4e3728 <_DYNAMIC+0x400>
  16e781:	48 8b 04 24          	mov    (%rsp),%rax
  16e785:	f0 48 ff 08          	lock decq (%rax)
  16e789:	75 09                	jne    16e794 <layout_lifetime::main+0x3a4>
  16e78b:	48 89 e7             	mov    %rsp,%rdi
  16e78e:	ff 15 6c 4e 37 00    	call   *0x374e6c(%rip)        # 4e3600 <_DYNAMIC+0x2d8>
  16e794:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  16e799:	f0 48 ff 08          	lock decq (%rax)
  16e79d:	75 0b                	jne    16e7aa <layout_lifetime::main+0x3ba>
  16e79f:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  16e7a4:	ff 15 96 4f 37 00    	call   *0x374f96(%rip)        # 4e3740 <_DYNAMIC+0x418>
  16e7aa:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  16e7af:	f0 48 ff 08          	lock decq (%rax)
  16e7b3:	75 0b                	jne    16e7c0 <layout_lifetime::main+0x3d0>
  16e7b5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  16e7ba:	ff 15 88 4f 37 00    	call   *0x374f88(%rip)        # 4e3748 <_DYNAMIC+0x420>
  16e7c0:	48 81 c4 f8 07 00 00 	add    $0x7f8,%rsp
  16e7c7:	5b                   	pop    %rbx
  16e7c8:	41 5e                	pop    %r14
  16e7ca:	41 5f                	pop    %r15
  16e7cc:	5d                   	pop    %rbp
  16e7cd:	c3                   	ret
  16e7ce:	4c 8d 0d ab 92 34 00 	lea    0x3492ab(%rip),%r9        # 4b7a80 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0xd8>
  16e7d5:	eb 0a                	jmp    16e7e1 <layout_lifetime::main+0x3f1>
  16e7d7:	4c 8d 0d 8a 92 34 00 	lea    0x34928a(%rip),%r9        # 4b7a68 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0xc0>
  16e7de:	4c 89 f3             	mov    %r14,%rbx
  16e7e1:	48 8d 15 b0 6e f2 ff 	lea    -0xd9150(%rip),%rdx        # 95698 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x50>
  16e7e8:	31 ff                	xor    %edi,%edi
  16e7ea:	48 89 de             	mov    %rbx,%rsi
  16e7ed:	31 c9                	xor    %ecx,%ecx
  16e7ef:	ff 15 5b 4f 37 00    	call   *0x374f5b(%rip)        # 4e3750 <_DYNAMIC+0x428>
  16e7f5:	e9 db 00 00 00       	jmp    16e8d5 <layout_lifetime::main+0x4e5>
  16e7fa:	0f 10 84 24 b0 04 00 	movups 0x4b0(%rsp),%xmm0
  16e801:	00 
  16e802:	0f 10 8c 24 c0 04 00 	movups 0x4c0(%rsp),%xmm1
  16e809:	00 
  16e80a:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  16e811:	00 
  16e812:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  16e819:	00 
  16e81a:	48 8d 3d 48 75 f2 ff 	lea    -0xd8ab8(%rip),%rdi        # 95d69 <anon.eb723a5be78547e123b9808189a7561d.26.llvm.7487865912334444517+0x1b5>
  16e821:	48 8d 0d 90 92 34 00 	lea    0x349290(%rip),%rcx        # 4b7ab8 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0x110>
  16e828:	4c 8d 05 f1 91 34 00 	lea    0x3491f1(%rip),%r8        # 4b7a20 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0x78>
  16e82f:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  16e836:	00 
  16e837:	be 2b 00 00 00       	mov    $0x2b,%esi
  16e83c:	ff 15 e6 4d 37 00    	call   *0x374de6(%rip)        # 4e3628 <_DYNAMIC+0x300>
  16e842:	e9 8e 00 00 00       	jmp    16e8d5 <layout_lifetime::main+0x4e5>
  16e847:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  16e84c:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  16e853:	00 
  16e854:	0f 10 44 24 50       	movups 0x50(%rsp),%xmm0
  16e859:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  16e860:	00 
  16e861:	31 ed                	xor    %ebp,%ebp
  16e863:	48 8d 3d ff 74 f2 ff 	lea    -0xd8b01(%rip),%rdi        # 95d69 <anon.eb723a5be78547e123b9808189a7561d.26.llvm.7487865912334444517+0x1b5>
  16e86a:	48 8d 0d 27 92 34 00 	lea    0x349227(%rip),%rcx        # 4b7a98 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0xf0>
  16e871:	4c 8d 05 c0 91 34 00 	lea    0x3491c0(%rip),%r8        # 4b7a38 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0x90>
  16e878:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  16e87f:	00 
  16e880:	be 2b 00 00 00       	mov    $0x2b,%esi
  16e885:	ff 15 9d 4d 37 00    	call   *0x374d9d(%rip)        # 4e3628 <_DYNAMIC+0x300>
  16e88b:	eb 48                	jmp    16e8d5 <layout_lifetime::main+0x4e5>
  16e88d:	48 8b 84 24 c8 00 00 	mov    0xc8(%rsp),%rax
  16e894:	00 
  16e895:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  16e89c:	00 
  16e89d:	0f 10 84 24 b8 00 00 	movups 0xb8(%rsp),%xmm0
  16e8a4:	00 
  16e8a5:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  16e8ac:	00 
  16e8ad:	48 8d 3d b5 74 f2 ff 	lea    -0xd8b4b(%rip),%rdi        # 95d69 <anon.eb723a5be78547e123b9808189a7561d.26.llvm.7487865912334444517+0x1b5>
  16e8b4:	48 8d 0d dd 91 34 00 	lea    0x3491dd(%rip),%rcx        # 4b7a98 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0xf0>
  16e8bb:	4c 8d 05 8e 91 34 00 	lea    0x34918e(%rip),%r8        # 4b7a50 <anon.eb723a5be78547e123b9808189a7561d.28.llvm.7487865912334444517+0xa8>
  16e8c2:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  16e8c9:	00 
  16e8ca:	be 2b 00 00 00       	mov    $0x2b,%esi
  16e8cf:	ff 15 53 4d 37 00    	call   *0x374d53(%rip)        # 4e3628 <_DYNAMIC+0x300>
  16e8d5:	0f 0b                	ud2
  16e8d7:	48 89 c3             	mov    %rax,%rbx
  16e8da:	e9 e1 00 00 00       	jmp    16e9c0 <layout_lifetime::main+0x5d0>
  16e8df:	eb 42                	jmp    16e923 <layout_lifetime::main+0x533>
  16e8e1:	48 89 c3             	mov    %rax,%rbx
  16e8e4:	eb 73                	jmp    16e959 <layout_lifetime::main+0x569>
  16e8e6:	eb 57                	jmp    16e93f <layout_lifetime::main+0x54f>
  16e8e8:	48 89 c3             	mov    %rax,%rbx
  16e8eb:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  16e8f2:	00 
  16e8f3:	e8 98 f0 ff ff       	call   16d990 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  16e8f8:	e9 9a 00 00 00       	jmp    16e997 <layout_lifetime::main+0x5a7>
  16e8fd:	ff 15 ad 4c 37 00    	call   *0x374cad(%rip)        # 4e35b0 <_DYNAMIC+0x288>
  16e903:	48 89 c3             	mov    %rax,%rbx
  16e906:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  16e90b:	48 85 c0             	test   %rax,%rax
  16e90e:	74 5b                	je     16e96b <layout_lifetime::main+0x57b>
  16e910:	f0 48 ff 08          	lock decq (%rax)
  16e914:	75 55                	jne    16e96b <layout_lifetime::main+0x57b>
  16e916:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  16e91b:	ff 15 67 4c 37 00    	call   *0x374c67(%rip)        # 4e3588 <_DYNAMIC+0x260>
  16e921:	eb 48                	jmp    16e96b <layout_lifetime::main+0x57b>
  16e923:	48 89 c3             	mov    %rax,%rbx
  16e926:	eb 59                	jmp    16e981 <layout_lifetime::main+0x591>
  16e928:	48 89 c3             	mov    %rax,%rbx
  16e92b:	eb 7d                	jmp    16e9aa <layout_lifetime::main+0x5ba>
  16e92d:	48 89 c3             	mov    %rax,%rbx
  16e930:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  16e937:	00 
  16e938:	e8 c3 f8 ff ff       	call   16e200 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>
  16e93d:	eb 58                	jmp    16e997 <layout_lifetime::main+0x5a7>
  16e93f:	48 89 c3             	mov    %rax,%rbx
  16e942:	eb 53                	jmp    16e997 <layout_lifetime::main+0x5a7>
  16e944:	48 89 c3             	mov    %rax,%rbx
  16e947:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  16e94e:	00 
  16e94f:	e8 dc f2 ff ff       	call   16dc30 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>
  16e954:	40 84 ed             	test   %bpl,%bpl
  16e957:	74 3e                	je     16e997 <layout_lifetime::main+0x5a7>
  16e959:	48 8d bc 24 80 00 00 	lea    0x80(%rsp),%rdi
  16e960:	00 
  16e961:	e8 0a f2 ff ff       	call   16db70 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>
  16e966:	eb 2f                	jmp    16e997 <layout_lifetime::main+0x5a7>
  16e968:	48 89 c3             	mov    %rax,%rbx
  16e96b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  16e970:	f0 48 ff 08          	lock decq (%rax)
  16e974:	75 0b                	jne    16e981 <layout_lifetime::main+0x591>
  16e976:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  16e97b:	ff 15 07 4c 37 00    	call   *0x374c07(%rip)        # 4e3588 <_DYNAMIC+0x260>
  16e981:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  16e986:	f0 48 ff 08          	lock decq (%rax)
  16e98a:	75 0b                	jne    16e997 <layout_lifetime::main+0x5a7>
  16e98c:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  16e991:	ff 15 61 4c 37 00    	call   *0x374c61(%rip)        # 4e35f8 <_DYNAMIC+0x2d0>
  16e997:	48 8b 04 24          	mov    (%rsp),%rax
  16e99b:	f0 48 ff 08          	lock decq (%rax)
  16e99f:	75 09                	jne    16e9aa <layout_lifetime::main+0x5ba>
  16e9a1:	48 89 e7             	mov    %rsp,%rdi
  16e9a4:	ff 15 56 4c 37 00    	call   *0x374c56(%rip)        # 4e3600 <_DYNAMIC+0x2d8>
  16e9aa:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  16e9af:	f0 48 ff 08          	lock decq (%rax)
  16e9b3:	75 0b                	jne    16e9c0 <layout_lifetime::main+0x5d0>
  16e9b5:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  16e9ba:	ff 15 80 4d 37 00    	call   *0x374d80(%rip)        # 4e3740 <_DYNAMIC+0x418>
  16e9c0:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  16e9c5:	f0 48 ff 08          	lock decq (%rax)
  16e9c9:	75 0b                	jne    16e9d6 <layout_lifetime::main+0x5e6>
  16e9cb:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  16e9d0:	ff 15 72 4d 37 00    	call   *0x374d72(%rip)        # 4e3748 <_DYNAMIC+0x420>
  16e9d6:	48 89 df             	mov    %rbx,%rdi
  16e9d9:	e8 e2 7d 34 00       	call   4b67c0 <_Unwind_Resume@plt>
  16e9de:	ff 15 cc 4b 37 00    	call   *0x374bcc(%rip)        # 4e35b0 <_DYNAMIC+0x288>
