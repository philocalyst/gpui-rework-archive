
/tmp/gpui-layout-identity-controls/lease/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845aa0 <<gpui_gpu::renderer::RendererState>::redraw>:
  845aa0:	48 89 f8             	mov    %rdi,%rax
  845aa3:	4c 8b 86 28 02 00 00 	mov    0x228(%rsi),%r8
  845aaa:	4c 8b 4a 18          	mov    0x18(%rdx),%r9
  845aae:	4d 39 c8             	cmp    %r9,%r8
  845ab1:	74 1c                	je     845acf <<gpui_gpu::renderer::RendererState>::redraw+0x2f>
  845ab3:	4d 8b 50 10          	mov    0x10(%r8),%r10
  845ab7:	bf 04 00 00 00       	mov    $0x4,%edi
  845abc:	4d 3b 51 10          	cmp    0x10(%r9),%r10
  845ac0:	74 03                	je     845ac5 <<gpui_gpu::renderer::RendererState>::redraw+0x25>
  845ac2:	89 38                	mov    %edi,(%rax)
  845ac4:	c3                   	ret
  845ac5:	4d 8b 40 18          	mov    0x18(%r8),%r8
  845ac9:	4d 3b 41 18          	cmp    0x18(%r9),%r8
  845acd:	75 f3                	jne    845ac2 <<gpui_gpu::renderer::RendererState>::redraw+0x22>
  845acf:	48 83 be 30 03 00 00 	cmpq   $0x0,0x330(%rsi)
  845ad6:	00 
  845ad7:	0f 84 fe 00 00 00    	je     845bdb <<gpui_gpu::renderer::RendererState>::redraw+0x13b>
  845add:	8b be 38 03 00 00    	mov    0x338(%rsi),%edi
  845ae3:	44 8b 86 3c 03 00 00 	mov    0x33c(%rsi),%r8d
  845aea:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  845af0:	49 c1 e0 20          	shl    $0x20,%r8
  845af4:	49 09 f8             	or     %rdi,%r8
  845af7:	bf 03 00 00 00       	mov    $0x3,%edi
  845afc:	4c 39 41 20          	cmp    %r8,0x20(%rcx)
  845b00:	75 c0                	jne    845ac2 <<gpui_gpu::renderer::RendererState>::redraw+0x22>
  845b02:	44 8b 41 38          	mov    0x38(%rcx),%r8d
  845b06:	44 3b 42 20          	cmp    0x20(%rdx),%r8d
  845b0a:	75 b6                	jne    845ac2 <<gpui_gpu::renderer::RendererState>::redraw+0x22>
  845b0c:	41 83 f8 4c          	cmp    $0x4c,%r8d
  845b10:	75 1e                	jne    845b30 <<gpui_gpu::renderer::RendererState>::redraw+0x90>
  845b12:	f3 0f 7e 41 3c       	movq   0x3c(%rcx),%xmm0
  845b17:	f3 0f 7e 4a 24       	movq   0x24(%rdx),%xmm1
  845b1c:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  845b20:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  845b25:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
  845b2a:	41 83 f8 03          	cmp    $0x3,%r8d
  845b2e:	75 92                	jne    845ac2 <<gpui_gpu::renderer::RendererState>::redraw+0x22>
  845b30:	41 56                	push   %r14
  845b32:	53                   	push   %rbx
  845b33:	50                   	push   %rax
  845b34:	48 89 c3             	mov    %rax,%rbx
  845b37:	48 8d 86 30 03 00 00 	lea    0x330(%rsi),%rax
  845b3e:	48 89 d7             	mov    %rdx,%rdi
  845b41:	49 89 f6             	mov    %rsi,%r14
  845b44:	48 89 ce             	mov    %rcx,%rsi
  845b47:	48 89 c2             	mov    %rax,%rdx
  845b4a:	e8 f1 f0 ff ff       	call   844c40 <<gpui_gpu::renderer::GpuContext>::submit>
  845b4f:	48 89 c1             	mov    %rax,%rcx
  845b52:	49 8b 96 60 01 00 00 	mov    0x160(%r14),%rdx
  845b59:	49 8b 86 28 03 00 00 	mov    0x328(%r14),%rax
  845b60:	48 ff c2             	inc    %rdx
  845b63:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  845b6a:	48 0f 45 f2          	cmovne %rdx,%rsi
  845b6e:	49 89 b6 60 01 00 00 	mov    %rsi,0x160(%r14)
  845b75:	41 c6 86 20 02 00 00 	movb   $0x1,0x220(%r14)
  845b7c:	01 
  845b7d:	49 c7 86 b8 01 00 00 	movq   $0x0,0x1b8(%r14)
  845b84:	00 00 00 00 
  845b88:	49 c7 86 e0 01 00 00 	movq   $0x0,0x1e0(%r14)
  845b8f:	00 00 00 00 
  845b93:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  845b97:	66 41 0f 11 86 68 01 	movupd %xmm0,0x168(%r14)
  845b9e:	00 00 
  845ba0:	49 c7 86 78 01 00 00 	movq   $0x0,0x178(%r14)
  845ba7:	00 00 00 00 
  845bab:	48 85 c0             	test   %rax,%rax
  845bae:	74 08                	je     845bb8 <<gpui_gpu::renderer::RendererState>::redraw+0x118>
  845bb0:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
