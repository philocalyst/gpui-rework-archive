
/tmp/gpui-layout-identity-controls/lease/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845bf0 <<gpui_gpu::renderer::RendererState>::render>:
  845bf0:	55                   	push   %rbp
  845bf1:	41 57                	push   %r15
  845bf3:	41 56                	push   %r14
  845bf5:	41 55                	push   %r13
  845bf7:	41 54                	push   %r12
  845bf9:	53                   	push   %rbx
  845bfa:	48 81 ec 68 05 00 00 	sub    $0x568,%rsp
  845c01:	48 8b 86 28 02 00 00 	mov    0x228(%rsi),%rax
  845c08:	4c 8b 4a 18          	mov    0x18(%rdx),%r9
  845c0c:	4c 39 c8             	cmp    %r9,%rax
  845c0f:	74 1c                	je     845c2d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  845c11:	4c 8b 50 10          	mov    0x10(%rax),%r10
  845c15:	4d 3b 51 10          	cmp    0x10(%r9),%r10
  845c19:	0f 85 dc 00 00 00    	jne    845cfb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  845c1f:	48 8b 40 18          	mov    0x18(%rax),%rax
  845c23:	49 3b 41 18          	cmp    0x18(%r9),%rax
  845c27:	0f 85 ce 00 00 00    	jne    845cfb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  845c2d:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  845c34:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  845c3b:	48 85 c0             	test   %rax,%rax
  845c3e:	74 2d                	je     845c6d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  845c40:	f0 48 ff 08          	lock decq (%rax)
  845c44:	75 27                	jne    845c6d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  845c46:	49 89 fe             	mov    %rdi,%r14
  845c49:	48 89 df             	mov    %rbx,%rdi
  845c4c:	49 89 f4             	mov    %rsi,%r12
  845c4f:	4d 89 c5             	mov    %r8,%r13
  845c52:	49 89 d7             	mov    %rdx,%r15
  845c55:	48 89 cd             	mov    %rcx,%rbp
  845c58:	ff 15 ea 84 67 00    	call   *0x6784ea(%rip)        # ebe148 <_DYNAMIC+0x490>
  845c5e:	48 89 e9             	mov    %rbp,%rcx
  845c61:	4c 89 fa             	mov    %r15,%rdx
  845c64:	4d 89 e8             	mov    %r13,%r8
  845c67:	4c 89 e6             	mov    %r12,%rsi
  845c6a:	4c 89 f7             	mov    %r14,%rdi
  845c6d:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  845c74:	00 00 00 00 
  845c78:	44 8b 29             	mov    (%rcx),%r13d
  845c7b:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  845c7f:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  845c83:	45 85 c9             	test   %r9d,%r9d
  845c86:	41 0f 98 c2          	sets   %r10b
  845c8a:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845c91:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  845c98:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  845c9f:	41 0f 92 c3          	setb   %r11b
  845ca3:	45 20 d3             	and    %r10b,%r11b
  845ca6:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  845caa:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  845cb0:	40 0f 92 c5          	setb   %bpl
  845cb4:	44 20 d5             	and    %r10b,%bpl
  845cb7:	45 85 c9             	test   %r9d,%r9d
  845cba:	41 0f 94 c2          	sete   %r10b
  845cbe:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  845cc5:	41 0f 94 c6          	sete   %r14b
  845cc9:	45 08 d6             	or     %r10b,%r14b
  845ccc:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  845cd3:	41 0f 9d c1          	setge  %r9b
  845cd7:	45 08 f1             	or     %r14b,%r9b
  845cda:	41 08 e9             	or     %bpl,%r9b
  845cdd:	45 85 ed             	test   %r13d,%r13d
  845ce0:	41 0f 95 c2          	setne  %r10b
  845ce4:	41 20 c2             	and    %al,%r10b
  845ce7:	45 08 da             	or     %r11b,%r10b
  845cea:	45 08 ca             	or     %r9b,%r10b
  845ced:	41 f6 c2 01          	test   $0x1,%r10b
  845cf1:	74 23                	je     845d16 <<gpui_gpu::renderer::RendererState>::render+0x126>
  845cf3:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  845cf9:	eb 06                	jmp    845d01 <<gpui_gpu::renderer::RendererState>::render+0x111>
  845cfb:	c7 07 04 00 00 00    	movl   $0x4,(%rdi)
  845d01:	48 89 f8             	mov    %rdi,%rax
  845d04:	48 81 c4 68 05 00 00 	add    $0x568,%rsp
  845d0b:	5b                   	pop    %rbx
  845d0c:	41 5c                	pop    %r12
  845d0e:	41 5d                	pop    %r13
  845d10:	41 5e                	pop    %r14
  845d12:	41 5f                	pop    %r15
  845d14:	5d                   	pop    %rbp
  845d15:	c3                   	ret
  845d16:	66 0f 6e 51 04       	movd   0x4(%rcx),%xmm2
  845d1b:	44 0f b6 61 0c       	movzbl 0xc(%rcx),%r12d
  845d20:	41 f6 c5 01          	test   $0x1,%r13b
  845d24:	74 75                	je     845d9b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  845d26:	66 41 0f 7e d1       	movd   %xmm2,%r9d
  845d2b:	45 85 c9             	test   %r9d,%r9d
  845d2e:	41 0f 98 c2          	sets   %r10b
  845d32:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845d39:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  845d40:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  845d47:	41 0f 92 c3          	setb   %r11b
  845d4b:	45 20 d3             	and    %r10b,%r11b
  845d4e:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  845d52:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  845d58:	40 0f 92 c5          	setb   %bpl
  845d5c:	44 20 d5             	and    %r10b,%bpl
  845d5f:	45 85 c9             	test   %r9d,%r9d
  845d62:	41 0f 94 c2          	sete   %r10b
  845d66:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  845d6d:	41 0f 94 c6          	sete   %r14b
  845d71:	45 08 d6             	or     %r10b,%r14b
  845d74:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  845d7b:	41 0f 9d c1          	setge  %r9b
  845d7f:	45 08 f1             	or     %r14b,%r9b
  845d82:	41 08 e9             	or     %bpl,%r9b
  845d85:	45 08 d9             	or     %r11b,%r9b
  845d88:	0f 85 65 ff ff ff    	jne    845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845d8e:	0f 2e 15 63 ad 88 ff 	ucomiss -0x77529d(%rip),%xmm2        # d0af8 <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x24>
  845d95:	0f 87 58 ff ff ff    	ja     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845d9b:	44 8b 71 28          	mov    0x28(%rcx),%r14d
  845d9f:	45 39 70 20          	cmp    %r14d,0x20(%r8)
  845da3:	0f 85 4a ff ff ff    	jne    845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845da9:	44 8b 79 2c          	mov    0x2c(%rcx),%r15d
  845dad:	45 39 78 24          	cmp    %r15d,0x24(%r8)
  845db1:	0f 85 3c ff ff ff    	jne    845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845db7:	41 8b 68 38          	mov    0x38(%r8),%ebp
  845dbb:	3b 6a 20             	cmp    0x20(%rdx),%ebp
  845dbe:	0f 85 2f ff ff ff    	jne    845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845dc4:	83 fd 4c             	cmp    $0x4c,%ebp
  845dc7:	75 23                	jne    845dec <<gpui_gpu::renderer::RendererState>::render+0x1fc>
  845dc9:	f3 41 0f 7e 40 3c    	movq   0x3c(%r8),%xmm0
  845dcf:	f3 0f 7e 4a 24       	movq   0x24(%rdx),%xmm1
  845dd4:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  845dd8:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  845ddd:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
  845de2:	41 83 f9 03          	cmp    $0x3,%r9d
  845de6:	0f 85 07 ff ff ff    	jne    845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845dec:	41 81 ff 00 40 00 00 	cmp    $0x4000,%r15d
  845df3:	77 34                	ja     845e29 <<gpui_gpu::renderer::RendererState>::render+0x239>
  845df5:	41 81 fe 00 40 00 00 	cmp    $0x4000,%r14d
  845dfc:	77 2b                	ja     845e29 <<gpui_gpu::renderer::RendererState>::render+0x239>
  845dfe:	4d 89 f9             	mov    %r15,%r9
  845e01:	4d 0f af ce          	imul   %r14,%r9
  845e05:	49 81 c1 ff ff ff fe 	add    $0xfffffffffeffffff,%r9
  845e0c:	49 81 f9 00 00 00 ff 	cmp    $0xffffffffff000000,%r9
  845e13:	72 14                	jb     845e29 <<gpui_gpu::renderer::RendererState>::render+0x239>
  845e15:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  845e19:	4d 8b 93 80 00 00 00 	mov    0x80(%r11),%r10
  845e20:	49 81 fa 00 00 01 00 	cmp    $0x10000,%r10
  845e27:	76 0b                	jbe    845e34 <<gpui_gpu::renderer::RendererState>::render+0x244>
  845e29:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  845e2f:	e9 cd fe ff ff       	jmp    845d01 <<gpui_gpu::renderer::RendererState>::render+0x111>
  845e34:	66 0f 6e 41 18       	movd   0x18(%rcx),%xmm0
  845e39:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  845e3e:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845e45:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  845e4c:	0f 8f a1 fe ff ff    	jg     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845e52:	66 0f db 05 36 de 88 	pand   -0x7721ca(%rip),%xmm0        # d3c90 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x4c0>
  845e59:	ff 
  845e5a:	0f 2e 05 ef ae 88 ff 	ucomiss -0x775111(%rip),%xmm0        # d0d50 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  845e61:	0f 87 8c fe ff ff    	ja     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845e67:	66 0f 6e 41 1c       	movd   0x1c(%rcx),%xmm0
  845e6c:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  845e71:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845e78:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  845e7f:	0f 8f 6e fe ff ff    	jg     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845e85:	66 0f db 05 03 de 88 	pand   -0x7721fd(%rip),%xmm0        # d3c90 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x4c0>
  845e8c:	ff 
  845e8d:	0f 2e 05 bc ae 88 ff 	ucomiss -0x775144(%rip),%xmm0        # d0d50 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  845e94:	0f 87 59 fe ff ff    	ja     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845e9a:	66 0f 6e 41 20       	movd   0x20(%rcx),%xmm0
  845e9f:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  845ea4:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845eab:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  845eb2:	0f 8f 3b fe ff ff    	jg     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845eb8:	66 0f db 05 d0 dd 88 	pand   -0x772230(%rip),%xmm0        # d3c90 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x4c0>
  845ebf:	ff 
  845ec0:	0f 2e 05 89 ae 88 ff 	ucomiss -0x775177(%rip),%xmm0        # d0d50 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  845ec7:	0f 87 26 fe ff ff    	ja     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845ecd:	66 0f 6e 41 24       	movd   0x24(%rcx),%xmm0
  845ed2:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  845ed7:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845ede:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  845ee5:	0f 8f 08 fe ff ff    	jg     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845eeb:	66 0f 6f 0d 9d dd 88 	movdqa -0x772263(%rip),%xmm1        # d3c90 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x4c0>
  845ef2:	ff 
  845ef3:	66 0f db c8          	pand   %xmm0,%xmm1
  845ef7:	0f 2e 0d 52 ae 88 ff 	ucomiss -0x7751ae(%rip),%xmm1        # d0d50 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  845efe:	0f 87 ef fd ff ff    	ja     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845f04:	0f 57 c9             	xorps  %xmm1,%xmm1
  845f07:	0f 2e c1             	ucomiss %xmm1,%xmm0
  845f0a:	0f 82 e3 fd ff ff    	jb     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845f10:	f3 0f 10 0d b4 aa 88 	movss  -0x77554c(%rip),%xmm1        # d09cc <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  845f17:	ff 
  845f18:	0f 2e c8             	ucomiss %xmm0,%xmm1
  845f1b:	0f 82 d2 fd ff ff    	jb     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845f21:	44 0f b7 49 30       	movzwl 0x30(%rcx),%r9d
  845f26:	66 44 89 4c 24 10    	mov    %r9w,0x10(%rsp)
  845f2c:	44 0f b7 49 32       	movzwl 0x32(%rcx),%r9d
  845f31:	66 44 89 4c 24 18    	mov    %r9w,0x18(%rsp)
  845f37:	83 fd 28             	cmp    $0x28,%ebp
  845f3a:	75 0a                	jne    845f46 <<gpui_gpu::renderer::RendererState>::render+0x356>
  845f3c:	a8 01                	test   $0x1,%al
  845f3e:	0f 84 af fd ff ff    	je     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845f44:	eb 1b                	jmp    845f61 <<gpui_gpu::renderer::RendererState>::render+0x371>
  845f46:	a8 01                	test   $0x1,%al
  845f48:	0f 85 a5 fd ff ff    	jne    845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845f4e:	0f 2e 05 77 aa 88 ff 	ucomiss -0x775589(%rip),%xmm0        # d09cc <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  845f55:	0f 85 98 fd ff ff    	jne    845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845f5b:	0f 8a 92 fd ff ff    	jp     845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  845f61:	4c 89 9c 24 b8 00 00 	mov    %r11,0xb8(%rsp)
  845f68:	00 
  845f69:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
  845f70:	00 
  845f71:	f3 0f 11 8c 24 ec 00 	movss  %xmm1,0xec(%rsp)
  845f78:	00 00 
  845f7a:	66 0f 7e 94 24 5c 01 	movd   %xmm2,0x15c(%rsp)
  845f81:	00 00 
  845f83:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
  845f8a:	00 
  845f8b:	4c 89 84 24 00 04 00 	mov    %r8,0x400(%rsp)
  845f92:	00 
  845f93:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  845f98:	49 8d 46 0f          	lea    0xf(%r14),%rax
  845f9c:	48 c1 e8 04          	shr    $0x4,%rax
  845fa0:	41 8d 57 0f          	lea    0xf(%r15),%edx
  845fa4:	c1 ea 04             	shr    $0x4,%edx
  845fa7:	48 8d 7e 18          	lea    0x18(%rsi),%rdi
  845fab:	48 c7 46 28 00 00 00 	movq   $0x0,0x28(%rsi)
  845fb2:	00 
  845fb3:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  845fb8:	0f af d0             	imul   %eax,%edx
  845fbb:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  845fc2:	00 
  845fc3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  845fc8:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  845fcd:	48 89 d6             	mov    %rdx,%rsi
  845fd0:	31 d2                	xor    %edx,%edx
  845fd2:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  845fd9:	00 
  845fda:	e8 a1 43 00 00       	call   84a380 <<alloc::vec::Vec<[u32; 2]>>::resize>
  845fdf:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  845fe4:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  845feb:	00 
  845fec:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  845ff3:	00 
  845ff4:	ff 15 b6 84 67 00    	call   *0x6784b6(%rip)        # ebe4b0 <_DYNAMIC+0x7f8>
  845ffa:	48 89 d1             	mov    %rdx,%rcx
  845ffd:	48 29 c1             	sub    %rax,%rcx
  846000:	48 81 f9 00 00 30 00 	cmp    $0x300000,%rcx
  846007:	76 10                	jbe    846019 <<gpui_gpu::renderer::RendererState>::render+0x429>
  846009:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  84600e:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  846014:	e9 e8 fc ff ff       	jmp    845d01 <<gpui_gpu::renderer::RendererState>::render+0x111>
  846019:	48 89 ce             	mov    %rcx,%rsi
  84601c:	48 c1 e9 03          	shr    $0x3,%rcx
  846020:	48 bf ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdi
  846027:	aa aa aa 
  84602a:	48 0f af f9          	imul   %rcx,%rdi
  84602e:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  846033:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  84603a:	00 
  84603b:	48 89 94 24 b0 03 00 	mov    %rdx,0x3b0(%rsp)
  846042:	00 
  846043:	48 39 c2             	cmp    %rax,%rdx
  846046:	74 2f                	je     846077 <<gpui_gpu::renderer::RendererState>::render+0x487>
  846048:	b8 ab aa aa aa       	mov    $0xaaaaaaab,%eax
  84604d:	48 0f af f0          	imul   %rax,%rsi
  846051:	48 c1 ee 2a          	shr    $0x2a,%rsi
  846055:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  84605a:	89 c8                	mov    %ecx,%eax
  84605c:	83 e0 3f             	and    $0x3f,%eax
  84605f:	48 01 ce             	add    %rcx,%rsi
  846062:	48 83 f8 01          	cmp    $0x1,%rax
  846066:	48 83 de ff          	sbb    $0xffffffffffffffff,%rsi
  84606a:	48 ff c6             	inc    %rsi
  84606d:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
  846074:	00 
  846075:	eb 0c                	jmp    846083 <<gpui_gpu::renderer::RendererState>::render+0x493>
  846077:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  84607e:	00 00 00 00 00 
  846083:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  84608a:	00 
  84608b:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
  846092:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  846099:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  8460a0:	00 
  8460a1:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  8460a6:	66 89 84 24 80 01 00 	mov    %ax,0x180(%rsp)
  8460ad:	00 
  8460ae:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  8460b3:	66 89 84 24 82 01 00 	mov    %ax,0x182(%rsp)
  8460ba:	00 
  8460bb:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  8460c2:	00 00 00 00 00 
  8460c7:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  8460ce:	00 
  8460cf:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  8460d6:	00 
  8460d7:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
  8460de:	00 
  8460df:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  8460e6:	00 
  8460e7:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8460ec:	0f b6 90 41 03 00 00 	movzbl 0x341(%rax),%edx
  8460f3:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  8460fa:	00 
  8460fb:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  846102:	00 
  846103:	e8 48 e1 ff ff       	call   844250 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  846108:	8b 84 24 48 04 00 00 	mov    0x448(%rsp),%eax
  84610f:	83 f8 ff             	cmp    $0xffffffff,%eax
  846112:	74 2e                	je     846142 <<gpui_gpu::renderer::RendererState>::render+0x552>
  846114:	8b 8c 24 4c 04 00 00 	mov    0x44c(%rsp),%ecx
  84611b:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  846122:	00 
  846123:	0f 10 84 24 58 04 00 	movups 0x458(%rsp),%xmm0
  84612a:	00 
  84612b:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  846130:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
  846134:	89 07                	mov    %eax,(%rdi)
  846136:	89 4f 04             	mov    %ecx,0x4(%rdi)
  846139:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  84613d:	e9 bf fb ff ff       	jmp    845d01 <<gpui_gpu::renderer::RendererState>::render+0x111>
  846142:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  846149:	00 
  84614a:	48 03 94 24 e0 00 00 	add    0xe0(%rsp),%rdx
  846151:	00 
  846152:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846157:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  84615b:	b9 04 00 00 00       	mov    $0x4,%ecx
  846160:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  846166:	e8 d5 55 00 00       	call   84b740 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  84616b:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  84616f:	0f 85 94 fe ff ff    	jne    846009 <<gpui_gpu::renderer::RendererState>::render+0x419>
  846175:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  84617a:	89 44 24 10          	mov    %eax,0x10(%rsp)
  84617e:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  846183:	89 44 24 78          	mov    %eax,0x78(%rsp)
  846187:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  84618c:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  846193:	00 
  846194:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  846199:	e8 02 75 00 00       	call   84d6a0 <gpui_gpu::renderer::slots::write_prefix>
  84619e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8461a3:	48 8d 78 48          	lea    0x48(%rax),%rdi
  8461a7:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  8461ae:	00 
  8461af:	48 89 bc 24 08 04 00 	mov    %rdi,0x408(%rsp)
  8461b6:	00 
  8461b7:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  8461bc:	31 d2                	xor    %edx,%edx
  8461be:	e8 dd 42 00 00       	call   84a4a0 <<alloc::vec::Vec<u32>>::resize>
  8461c3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8461c8:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
  8461cf:	00 
  8461d0:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
  8461d5:	75 0f                	jne    8461e6 <<gpui_gpu::renderer::RendererState>::render+0x5f6>
  8461d7:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8461dc:	48 8d 78 60          	lea    0x60(%rax),%rdi
  8461e0:	ff 15 d2 82 67 00    	call   *0x6782d2(%rip)        # ebe4b8 <_DYNAMIC+0x800>
  8461e6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8461eb:	48 8b 48 68          	mov    0x68(%rax),%rcx
  8461ef:	0f 57 c0             	xorps  %xmm0,%xmm0
  8461f2:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  8461f6:	0f 11 01             	movups %xmm0,(%rcx)
  8461f9:	48 c7 40 70 01 00 00 	movq   $0x1,0x70(%rax)
  846200:	00 
  846201:	48 8d b8 f8 02 00 00 	lea    0x2f8(%rax),%rdi
  846208:	e8 43 6e 00 00       	call   84d050 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  84620d:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  846211:	c1 e1 10             	shl    $0x10,%ecx
  846214:	03 4c 24 10          	add    0x10(%rsp),%ecx
  846218:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  84621f:	00 
  846220:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  846227:	00 
  846228:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  84622f:	00 00 00 00 00 
  846234:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  84623b:	00 
  84623c:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  846243:	00 
  846244:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  84624b:	00 
  84624c:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  846253:	00 
  846254:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  846258:	89 8c 24 08 03 00 00 	mov    %ecx,0x308(%rsp)
  84625f:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  846266:	00 
  846267:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  84626e:	00 
  84626f:	ff 15 4b 82 67 00    	call   *0x67824b(%rip)        # ebe4c0 <_DYNAMIC+0x808>
  846275:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  84627c:	00 
  84627d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  846282:	48 85 c0             	test   %rax,%rax
  846285:	0f 84 31 0d 00 00    	je     846fbc <<gpui_gpu::renderer::RendererState>::render+0x13cc>
  84628b:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  846292:	00 00 00 00 00 
  846297:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  84629e:	00 00 
  8462a0:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  8462a7:	00 00 
  8462a9:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  8462b0:	00 00 00 00 00 
  8462b5:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  8462bc:	00 00 00 00 00 
  8462c1:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  8462c8:	00 
  8462c9:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  8462d0:	00 
  8462d1:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  8462d8:	00 
  8462d9:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
  8462e0:	00 
  8462e1:	0f 10 07             	movups (%rdi),%xmm0
  8462e4:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  8462e8:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  8462ec:	0f 29 94 24 30 03 00 	movaps %xmm2,0x330(%rsp)
  8462f3:	00 
  8462f4:	0f 29 8c 24 20 03 00 	movaps %xmm1,0x320(%rsp)
  8462fb:	00 
  8462fc:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
  846303:	00 
  846304:	4c 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%r8
  84630b:	00 
  84630c:	41 0f 10 00          	movups (%r8),%xmm0
  846310:	0f 29 84 24 10 05 00 	movaps %xmm0,0x510(%rsp)
  846317:	00 
  846318:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  84631c:	0f 29 84 24 30 04 00 	movaps %xmm0,0x430(%rsp)
  846323:	00 
  846324:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846329:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  846330:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846335:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  84633c:	00 
  84633d:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  846342:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  846349:	00 
  84634a:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
  846351:	00 
  846352:	0f 10 07             	movups (%rdi),%xmm0
  846355:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  846359:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  84635d:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  846364:	00 
  846365:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  846369:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  84636d:	0f 11 00             	movups %xmm0,(%rax)
  846370:	41 0f 10 00          	movups (%r8),%xmm0
  846374:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  846378:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  84637c:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  846380:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  846387:	00 
  846388:	e8 53 2d 00 00       	call   8490e0 <gpui_gpu::renderer::compact_group>
  84638d:	88 44 24 60          	mov    %al,0x60(%rsp)
  846391:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
  846398:	00 
  846399:	0f 10 06             	movups (%rsi),%xmm0
  84639c:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  8463a0:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  8463a4:	0f 29 84 24 20 05 00 	movaps %xmm0,0x520(%rsp)
  8463ab:	00 
  8463ac:	0f 29 8c 24 30 05 00 	movaps %xmm1,0x530(%rsp)
  8463b3:	00 
  8463b4:	0f 29 94 24 40 05 00 	movaps %xmm2,0x540(%rsp)
  8463bb:	00 
  8463bc:	48 8d 94 24 a0 02 00 	lea    0x2a0(%rsp),%rdx
  8463c3:	00 
  8463c4:	0f 10 02             	movups (%rdx),%xmm0
  8463c7:	0f 29 84 24 50 05 00 	movaps %xmm0,0x550(%rsp)
  8463ce:	00 
  8463cf:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  8463d4:	e8 47 ea ff ff       	call   844e20 <<gpui_gpu::renderer::RendererState>::correction>
  8463d9:	89 44 24 7c          	mov    %eax,0x7c(%rsp)
  8463dd:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  8463e4:	00 
  8463e5:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  8463ec:	00 
  8463ed:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  8463f4:	00 
  8463f5:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
  8463fa:	0f 84 d5 01 00 00    	je     8465d5 <<gpui_gpu::renderer::RendererState>::render+0x9e5>
  846400:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  846405:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  84640c:	00 
  84640d:	48 8d 04 81          	lea    (%rcx,%rax,4),%rax
  846411:	48 89 8c 24 10 04 00 	mov    %rcx,0x410(%rsp)
  846418:	00 
  846419:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
  846420:	00 
  846421:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846426:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  84642d:	00 
  84642e:	48 c7 84 24 28 04 00 	movq   $0x0,0x428(%rsp)
  846435:	00 00 00 00 00 
  84643a:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  846441:	00 
  846442:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  846449:	00 
  84644a:	e8 21 33 00 00       	call   849770 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  84644f:	80 bc 24 48 03 00 00 	cmpb   $0xff,0x348(%rsp)
  846456:	ff 
  846457:	0f 84 b1 06 00 00    	je     846b0e <<gpui_gpu::renderer::RendererState>::render+0xf1e>
  84645d:	0f 57 c0             	xorps  %xmm0,%xmm0
  846460:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  846467:	00 
  846468:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  84646d:	48 8b 94 24 40 03 00 	mov    0x340(%rsp),%rdx
  846474:	00 
  846475:	48 03 54 24 48       	add    0x48(%rsp),%rdx
  84647a:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
  846481:	00 
  846482:	0f 10 46 38          	movups 0x38(%rsi),%xmm0
  846486:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  84648d:	00 
  84648e:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  846492:	0f 10 46 48          	movups 0x48(%rsi),%xmm0
  846496:	0f 11 41 70          	movups %xmm0,0x70(%rcx)
  84649a:	48 8b 46 30          	mov    0x30(%rsi),%rax
  84649e:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  8464a5:	00 
  8464a6:	0f 10 06             	movups (%rsi),%xmm0
  8464a9:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  8464ad:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  8464b1:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
  8464b8:	00 
  8464b9:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  8464c0:	00 
  8464c1:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  8464c8:	00 
  8464c9:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  8464d0:	00 
  8464d1:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  8464d5:	0f 11 81 80 00 00 00 	movups %xmm0,0x80(%rcx)
  8464dc:	0f 10 00             	movups (%rax),%xmm0
  8464df:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  8464e3:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  8464e7:	0f 11 51 50          	movups %xmm2,0x50(%rcx)
  8464eb:	0f 11 49 40          	movups %xmm1,0x40(%rcx)
  8464ef:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  8464f3:	48 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%rax
  8464fa:	00 
  8464fb:	0f 10 00             	movups (%rax),%xmm0
  8464fe:	0f 11 41 60          	movups %xmm0,0x60(%rcx)
  846502:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  846509:	00 
  84650a:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  846511:	00 
  846512:	44 89 f1             	mov    %r14d,%ecx
  846515:	45 89 f8             	mov    %r15d,%r8d
  846518:	e8 13 2c 00 00       	call   849130 <gpui_gpu::renderer::validate_draw>
  84651d:	8b 8c 24 00 01 00 00 	mov    0x100(%rsp),%ecx
  846524:	48 8b 84 24 04 01 00 	mov    0x104(%rsp),%rax
  84652b:	00 
  84652c:	83 f9 ff             	cmp    $0xffffffff,%ecx
  84652f:	0f 85 3f 0b 00 00    	jne    847074 <<gpui_gpu::renderer::RendererState>::render+0x1484>
  846535:	89 c1                	mov    %eax,%ecx
  846537:	48 c1 e8 20          	shr    $0x20,%rax
  84653b:	66 0f 6e c1          	movd   %ecx,%xmm0
  84653f:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
  846546:	00 
  846547:	0f 28 ca             	movaps %xmm2,%xmm1
  84654a:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  84654e:	0f 28 d9             	movaps %xmm1,%xmm3
  846551:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  846556:	0f 28 c3             	movaps %xmm3,%xmm0
  846559:	0f 55 c1             	andnps %xmm1,%xmm0
  84655c:	0f 54 da             	andps  %xmm2,%xmm3
  84655f:	0f 56 d8             	orps   %xmm0,%xmm3
  846562:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
  846567:	66 0f 6e c0          	movd   %eax,%xmm0
  84656b:	0f 28 54 24 50       	movaps 0x50(%rsp),%xmm2
  846570:	0f 28 ca             	movaps %xmm2,%xmm1
  846573:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  846577:	0f 28 d9             	movaps %xmm1,%xmm3
  84657a:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  84657f:	0f 28 c3             	movaps %xmm3,%xmm0
  846582:	0f 55 c1             	andnps %xmm1,%xmm0
  846585:	0f 54 da             	andps  %xmm2,%xmm3
  846588:	0f 56 d8             	orps   %xmm0,%xmm3
  84658b:	0f 29 9c 24 80 00 00 	movaps %xmm3,0x80(%rsp)
  846592:	00 
  846593:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  84659a:	00 
  84659b:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  8465a2:	00 
  8465a3:	e8 c8 31 00 00       	call   849770 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  8465a8:	80 bc 24 48 03 00 00 	cmpb   $0xff,0x348(%rsp)
  8465af:	ff 
  8465b0:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  8465b5:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  8465bc:	00 
  8465bd:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  8465c4:	00 
  8465c5:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  8465ca:	0f 85 9d fe ff ff    	jne    84646d <<gpui_gpu::renderer::RendererState>::render+0x87d>
  8465d0:	e9 49 05 00 00       	jmp    846b1e <<gpui_gpu::renderer::RendererState>::render+0xf2e>
  8465d5:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
  8465dc:	00 00 
  8465de:	0f 84 82 09 00 00    	je     846f66 <<gpui_gpu::renderer::RendererState>::render+0x1376>
  8465e4:	8b 44 24 7c          	mov    0x7c(%rsp),%eax
  8465e8:	0d 00 00 00 80       	or     $0x80000000,%eax
  8465ed:	89 84 24 58 01 00 00 	mov    %eax,0x158(%rsp)
  8465f4:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
  8465fb:	00 00 00 00 00 
  846600:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846605:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  84660c:	00 
  84660d:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  846610:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  846617:	00 
  846618:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  84661d:	e8 7e dd ff ff       	call   8443a0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  846622:	0f b6 bc 24 60 01 00 	movzbl 0x160(%rsp),%edi
  846629:	00 
  84662a:	48 8d 94 24 61 01 00 	lea    0x161(%rsp),%rdx
  846631:	00 
  846632:	8b 02                	mov    (%rdx),%eax
  846634:	8b 4a 03             	mov    0x3(%rdx),%ecx
  846637:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
  84663e:	00 
  84663f:	89 4e cc             	mov    %ecx,-0x34(%rsi)
  846642:	89 46 c9             	mov    %eax,-0x37(%rsi)
  846645:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  84664c:	00 
  84664d:	48 8b 42 2f          	mov    0x2f(%rdx),%rax
  846651:	48 89 46 f8          	mov    %rax,-0x8(%rsi)
  846655:	0f 10 42 0f          	movups 0xf(%rdx),%xmm0
  846659:	0f 10 4a 1f          	movups 0x1f(%rdx),%xmm1
  84665d:	0f 11 4e e8          	movups %xmm1,-0x18(%rsi)
  846661:	0f 11 46 d8          	movups %xmm0,-0x28(%rsi)
  846665:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  84666c:	00 
  84666d:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  846671:	0f 11 06             	movups %xmm0,(%rsi)
  846674:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  846678:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  84667c:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  846683:	00 
  846684:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  846688:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  84668c:	0f 10 00             	movups (%rax),%xmm0
  84668f:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  846693:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  846697:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
  84669b:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
  84669f:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
  8466a3:	48 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%rax
  8466aa:	00 
  8466ab:	0f 10 00             	movups (%rax),%xmm0
  8466ae:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  8466b2:	40 88 7c 24 50       	mov    %dil,0x50(%rsp)
  8466b7:	40 88 bc 24 48 04 00 	mov    %dil,0x448(%rsp)
  8466be:	00 
  8466bf:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  8466c6:	00 
  8466c7:	48 89 8c 24 50 04 00 	mov    %rcx,0x450(%rsp)
  8466ce:	00 
  8466cf:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8466d6:	00 
  8466d7:	48 8d b4 24 48 04 00 	lea    0x448(%rsp),%rsi
  8466de:	00 
  8466df:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  8466e4:	44 89 f1             	mov    %r14d,%ecx
  8466e7:	45 89 f8             	mov    %r15d,%r8d
  8466ea:	e8 41 2a 00 00       	call   849130 <gpui_gpu::renderer::validate_draw>
  8466ef:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  8466f6:	48 8b 8c 24 64 01 00 	mov    0x164(%rsp),%rcx
  8466fd:	00 
  8466fe:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  846703:	83 f8 ff             	cmp    $0xffffffff,%eax
  846706:	0f 85 fe 09 00 00    	jne    84710a <<gpui_gpu::renderer::RendererState>::render+0x151a>
  84670c:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
  846711:	3c 02                	cmp    $0x2,%al
  846713:	0f 94 44 24 2f       	sete   0x2f(%rsp)
  846718:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  84671f:	00 00 
  846721:	0f 95 44 24 2e       	setne  0x2e(%rsp)
  846726:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
  84672d:	00 
  84672e:	0f 29 84 24 d0 02 00 	movaps %xmm0,0x2d0(%rsp)
  846735:	00 
  846736:	3c 03                	cmp    $0x3,%al
  846738:	0f 85 8c 00 00 00    	jne    8467ca <<gpui_gpu::renderer::RendererState>::render+0xbda>
  84673e:	f3 0f 10 84 24 4c 04 	movss  0x44c(%rsp),%xmm0
  846745:	00 00 
  846747:	0f 57 c9             	xorps  %xmm1,%xmm1
  84674a:	0f 2e c1             	ucomiss %xmm1,%xmm0
  84674d:	75 02                	jne    846751 <<gpui_gpu::renderer::RendererState>::render+0xb61>
  84674f:	7b 79                	jnp    8467ca <<gpui_gpu::renderer::RendererState>::render+0xbda>
  846751:	0f 28 ac 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm5
  846758:	00 
  846759:	0f 28 cd             	movaps %xmm5,%xmm1
  84675c:	66 0f 15 cd          	unpckhpd %xmm5,%xmm1
  846760:	f3 0f 10 25 4c a4 88 	movss  -0x775bb4(%rip),%xmm4        # d0bb4 <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  846767:	ff 
  846768:	f3 0f 59 cc          	mulss  %xmm4,%xmm1
  84676c:	0f 28 d0             	movaps %xmm0,%xmm2
  84676f:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  846773:	0f 28 ca             	movaps %xmm2,%xmm1
  846776:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  84677b:	0f 28 d9             	movaps %xmm1,%xmm3
  84677e:	0f 55 da             	andnps %xmm2,%xmm3
  846781:	0f 54 c8             	andps  %xmm0,%xmm1
  846784:	0f 56 cb             	orps   %xmm3,%xmm1
  846787:	0f 28 c5             	movaps %xmm5,%xmm0
  84678a:	0f c6 c5 ff          	shufps $0xff,%xmm5,%xmm0
  84678e:	f3 0f 59 c4          	mulss  %xmm4,%xmm0
  846792:	0f 28 d1             	movaps %xmm1,%xmm2
  846795:	f3 0f 5d d0          	minss  %xmm0,%xmm2
  846799:	0f 28 c2             	movaps %xmm2,%xmm0
  84679c:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  8467a1:	0f 54 c8             	andps  %xmm0,%xmm1
  8467a4:	0f 55 c2             	andnps %xmm2,%xmm0
  8467a7:	0f 56 c1             	orps   %xmm1,%xmm0
  8467aa:	66 0f 7e c0          	movd   %xmm0,%eax
  8467ae:	89 44 24 50          	mov    %eax,0x50(%rsp)
  8467b2:	25 00 00 80 ff       	and    $0xff800000,%eax
  8467b7:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  8467bc:	29 c1                	sub    %eax,%ecx
  8467be:	89 8c 24 c0 00 00 00 	mov    %ecx,0xc0(%rsp)
  8467c5:	0f 57 c0             	xorps  %xmm0,%xmm0
  8467c8:	eb 22                	jmp    8467ec <<gpui_gpu::renderer::RendererState>::render+0xbfc>
  8467ca:	8b 84 24 e0 04 00 00 	mov    0x4e0(%rsp),%eax
  8467d1:	89 44 24 50          	mov    %eax,0x50(%rsp)
  8467d5:	8b 84 24 e4 04 00 00 	mov    0x4e4(%rsp),%eax
  8467dc:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
  8467e3:	f2 0f 10 84 24 e8 04 	movsd  0x4e8(%rsp),%xmm0
  8467ea:	00 00 
  8467ec:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  8467f3:	00 
  8467f4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8467f9:	8b 48 10             	mov    0x10(%rax),%ecx
  8467fc:	b8 00 00 00 80       	mov    $0x80000000,%eax
  846801:	09 c1                	or     %eax,%ecx
  846803:	89 8c 24 a0 03 00 00 	mov    %ecx,0x3a0(%rsp)
  84680a:	0f 10 84 24 90 04 00 	movups 0x490(%rsp),%xmm0
  846811:	00 
  846812:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  846819:	00 
  84681a:	0f 10 84 24 98 04 00 	movups 0x498(%rsp),%xmm0
  846821:	00 
  846822:	0f 29 84 24 00 05 00 	movaps %xmm0,0x500(%rsp)
  846829:	00 
  84682a:	f2 0f 10 84 24 a0 04 	movsd  0x4a0(%rsp),%xmm0
  846831:	00 00 
  846833:	0f 29 84 24 c0 03 00 	movaps %xmm0,0x3c0(%rsp)
  84683a:	00 
  84683b:	f2 0f 10 84 24 a8 04 	movsd  0x4a8(%rsp),%xmm0
  846842:	00 00 
  846844:	0f 29 84 24 f0 04 00 	movaps %xmm0,0x4f0(%rsp)
  84684b:	00 
  84684c:	f2 0f 10 84 24 b0 04 	movsd  0x4b0(%rsp),%xmm0
  846853:	00 00 
  846855:	f2 0f 11 84 24 f8 03 	movsd  %xmm0,0x3f8(%rsp)
  84685c:	00 00 
  84685e:	f2 0f 10 84 24 b8 04 	movsd  0x4b8(%rsp),%xmm0
  846865:	00 00 
  846867:	f2 0f 11 84 24 f0 03 	movsd  %xmm0,0x3f0(%rsp)
  84686e:	00 00 
  846870:	0f 10 84 24 c0 04 00 	movups 0x4c0(%rsp),%xmm0
  846877:	00 
  846878:	0f 29 84 24 c0 02 00 	movaps %xmm0,0x2c0(%rsp)
  84687f:	00 
  846880:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846885:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  84688c:	00 
  84688d:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846892:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  846899:	00 
  84689a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  8468a1:	00 
  8468a2:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  8468a9:	00 
  8468aa:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
  8468b1:	00 
  8468b2:	0f 28 8c 24 20 03 00 	movaps 0x320(%rsp),%xmm1
  8468b9:	00 
  8468ba:	0f 28 94 24 30 03 00 	movaps 0x330(%rsp),%xmm2
  8468c1:	00 
  8468c2:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  8468c9:	00 
  8468ca:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  8468ce:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  8468d2:	0f 11 00             	movups %xmm0,(%rax)
  8468d5:	0f 28 84 24 10 05 00 	movaps 0x510(%rsp),%xmm0
  8468dc:	00 
  8468dd:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  8468e1:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  8468e8:	00 
  8468e9:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  8468ed:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8468f4:	00 
  8468f5:	ff 15 cd 7b 67 00    	call   *0x677bcd(%rip)        # ebe4c8 <_DYNAMIC+0x810>
  8468fb:	8b 4c 24 7c          	mov    0x7c(%rsp),%ecx
  8468ff:	89 8c 24 f0 00 00 00 	mov    %ecx,0xf0(%rsp)
  846906:	85 c0                	test   %eax,%eax
  846908:	74 34                	je     84693e <<gpui_gpu::renderer::RendererState>::render+0xd4e>
  84690a:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  84690f:	89 c6                	mov    %eax,%esi
  846911:	e8 4a 6d 00 00       	call   84d660 <gpui_gpu::renderer::slots::color_word>
  846916:	89 44 24 50          	mov    %eax,0x50(%rsp)
  84691a:	0f 57 c0             	xorps  %xmm0,%xmm0
  84691d:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  846924:	00 
  846925:	c7 84 24 c0 00 00 00 	movl   $0x0,0xc0(%rsp)
  84692c:	00 00 00 00 
  846930:	8b 84 24 58 01 00 00 	mov    0x158(%rsp),%eax
  846937:	89 84 24 f0 00 00 00 	mov    %eax,0xf0(%rsp)
  84693e:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  846943:	48 c1 e8 20          	shr    $0x20,%rax
  846947:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  84694e:	00 
  84694f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846954:	48 8b 08             	mov    (%rax),%rcx
  846957:	48 8b 70 10          	mov    0x10(%rax),%rsi
  84695b:	48 29 f1             	sub    %rsi,%rcx
  84695e:	48 83 f9 05          	cmp    $0x5,%rcx
  846962:	0f 86 7e 01 00 00    	jbe    846ae6 <<gpui_gpu::renderer::RendererState>::render+0xef6>
  846968:	f2 0f 10 84 24 f0 03 	movsd  0x3f0(%rsp),%xmm0
  84696f:	00 00 
  846971:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  846975:	f2 0f 10 8c 24 f8 03 	movsd  0x3f8(%rsp),%xmm1
  84697c:	00 00 
  84697e:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  846982:	66 0f 28 94 24 00 05 	movapd 0x500(%rsp),%xmm2
  846989:	00 00 
  84698b:	66 0f 14 94 24 f0 04 	unpcklpd 0x4f0(%rsp),%xmm2
  846992:	00 00 
  846994:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  846998:	66 0f 28 9c 24 d0 03 	movapd 0x3d0(%rsp),%xmm3
  84699f:	00 00 
  8469a1:	66 0f 14 9c 24 c0 03 	unpcklpd 0x3c0(%rsp),%xmm3
  8469a8:	00 00 
  8469aa:	66 0f 5a db          	cvtpd2ps %xmm3,%xmm3
  8469ae:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8469b3:	48 8b 50 08          	mov    0x8(%rax),%rdx
  8469b7:	48 c1 e6 04          	shl    $0x4,%rsi
  8469bb:	0f 28 a4 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm4
  8469c2:	00 
  8469c3:	0f 11 24 32          	movups %xmm4,(%rdx,%rsi,1)
  8469c7:	66 0f 13 5c 32 10    	movlpd %xmm3,0x10(%rdx,%rsi,1)
  8469cd:	f3 0f 11 4c 32 18    	movss  %xmm1,0x18(%rdx,%rsi,1)
  8469d3:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  8469d8:	89 4c 32 1c          	mov    %ecx,0x1c(%rdx,%rsi,1)
  8469dc:	66 0f 13 54 32 20    	movlpd %xmm2,0x20(%rdx,%rsi,1)
  8469e2:	f3 0f 11 44 32 28    	movss  %xmm0,0x28(%rdx,%rsi,1)
  8469e8:	48 8b bc 24 e8 03 00 	mov    0x3e8(%rsp),%rdi
  8469ef:	00 
  8469f0:	89 7c 32 2c          	mov    %edi,0x2c(%rdx,%rsi,1)
  8469f4:	0f 28 84 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm0
  8469fb:	00 
  8469fc:	0f 11 44 32 30       	movups %xmm0,0x30(%rdx,%rsi,1)
  846a01:	8b 7c 24 50          	mov    0x50(%rsp),%edi
  846a05:	89 7c 32 40          	mov    %edi,0x40(%rdx,%rsi,1)
  846a09:	8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%edi
  846a10:	89 7c 32 44          	mov    %edi,0x44(%rdx,%rsi,1)
  846a14:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
  846a1b:	00 
  846a1c:	0f 13 44 32 48       	movlps %xmm0,0x48(%rdx,%rsi,1)
  846a21:	48 c7 44 32 50 00 00 	movq   $0x0,0x50(%rdx,%rsi,1)
  846a28:	00 00 
  846a2a:	c7 44 32 58 00 00 00 	movl   $0x0,0x58(%rdx,%rsi,1)
  846a31:	00 
  846a32:	8b bc 24 f0 00 00 00 	mov    0xf0(%rsp),%edi
  846a39:	89 7c 32 5c          	mov    %edi,0x5c(%rdx,%rsi,1)
  846a3d:	48 83 40 10 06       	addq   $0x6,0x10(%rax)
  846a42:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  846a49:	00 
  846a4a:	48 89 c6             	mov    %rax,%rsi
  846a4d:	48 8d 94 24 48 04 00 	lea    0x448(%rsp),%rdx
  846a54:	00 
  846a55:	44 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%r8d
  846a5c:	00 
  846a5d:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  846a62:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  846a69:	41 57                	push   %r15
  846a6b:	41 56                	push   %r14
  846a6d:	ff 74 24 50          	push   0x50(%rsp)
  846a71:	e8 0a 16 00 00       	call   848080 <<gpui_gpu::renderer::RendererState>::bin_draw>
  846a76:	48 83 c4 20          	add    $0x20,%rsp
  846a7a:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  846a81:	83 f8 ff             	cmp    $0xffffffff,%eax
  846a84:	0f 85 48 06 00 00    	jne    8470d2 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  846a8a:	0f b6 4c 24 2f       	movzbl 0x2f(%rsp),%ecx
  846a8f:	22 4c 24 2e          	and    0x2e(%rsp),%cl
  846a93:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  846a98:	08 c8                	or     %cl,%al
  846a9a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  846a9f:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  846aa6:	00 
  846aa7:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  846aae:	00 
  846aaf:	48 ff 44 24 48       	incq   0x48(%rsp)
  846ab4:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  846abb:	00 
  846abc:	48 83 c2 04          	add    $0x4,%rdx
  846ac0:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846ac7:	00 
  846ac8:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  846acf:	00 
  846ad0:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  846ad7:	00 
  846ad8:	48 39 d0             	cmp    %rdx,%rax
  846adb:	0f 85 1f fb ff ff    	jne    846600 <<gpui_gpu::renderer::RendererState>::render+0xa10>
  846ae1:	e9 74 04 00 00       	jmp    846f5a <<gpui_gpu::renderer::RendererState>::render+0x136a>
  846ae6:	ba 06 00 00 00       	mov    $0x6,%edx
  846aeb:	b9 04 00 00 00       	mov    $0x4,%ecx
  846af0:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  846af6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846afb:	e8 b0 4b 00 00       	call   84b6b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  846b00:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846b05:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846b09:	e9 5a fe ff ff       	jmp    846968 <<gpui_gpu::renderer::RendererState>::render+0xd78>
  846b0e:	0f 57 c0             	xorps  %xmm0,%xmm0
  846b11:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  846b18:	00 
  846b19:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  846b1e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846b23:	8b 40 10             	mov    0x10(%rax),%eax
  846b26:	89 84 24 20 01 00 00 	mov    %eax,0x120(%rsp)
  846b2d:	0f 10 8c 24 70 02 00 	movups 0x270(%rsp),%xmm1
  846b34:	00 
  846b35:	0f 10 94 24 78 02 00 	movups 0x278(%rsp),%xmm2
  846b3c:	00 
  846b3d:	f2 0f 10 84 24 90 02 	movsd  0x290(%rsp),%xmm0
  846b44:	00 00 
  846b46:	f2 0f 11 84 24 f0 00 	movsd  %xmm0,0xf0(%rsp)
  846b4d:	00 00 
  846b4f:	f2 0f 10 84 24 98 02 	movsd  0x298(%rsp),%xmm0
  846b56:	00 00 
  846b58:	f2 0f 11 84 24 d0 02 	movsd  %xmm0,0x2d0(%rsp)
  846b5f:	00 00 
  846b61:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
  846b68:	00 
  846b69:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  846b70:	00 
  846b71:	0f 16 8c 24 80 02 00 	movhps 0x280(%rsp),%xmm1
  846b78:	00 
  846b79:	0f 29 8c 24 a0 03 00 	movaps %xmm1,0x3a0(%rsp)
  846b80:	00 
  846b81:	0f 10 84 24 b0 02 00 	movups 0x2b0(%rsp),%xmm0
  846b88:	00 
  846b89:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  846b8e:	0f 16 94 24 88 02 00 	movhps 0x288(%rsp),%xmm2
  846b95:	00 
  846b96:	0f 29 94 24 c0 02 00 	movaps %xmm2,0x2c0(%rsp)
  846b9d:	00 
  846b9e:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846ba3:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846baa:	00 
  846bab:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846bb0:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  846bb7:	00 
  846bb8:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846bbf:	00 
  846bc0:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  846bc7:	00 
  846bc8:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  846bcf:	00 
  846bd0:	0f 10 00             	movups (%rax),%xmm0
  846bd3:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  846bd7:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  846bdb:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  846be2:	00 
  846be3:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  846be7:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  846beb:	0f 11 02             	movups %xmm0,(%rdx)
  846bee:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  846bf5:	00 
  846bf6:	0f 10 01             	movups (%rcx),%xmm0
  846bf9:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  846bfd:	f3 0f 6f 40 40       	movdqu 0x40(%rax),%xmm0
  846c02:	f3 0f 7f 42 40       	movdqu %xmm0,0x40(%rdx)
  846c07:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  846c0e:	00 
  846c0f:	ff 15 b3 78 67 00    	call   *0x6778b3(%rip)        # ebe4c8 <_DYNAMIC+0x810>
  846c15:	85 c0                	test   %eax,%eax
  846c17:	74 1e                	je     846c37 <<gpui_gpu::renderer::RendererState>::render+0x1047>
  846c19:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  846c1e:	89 c6                	mov    %eax,%esi
  846c20:	e8 3b 6a 00 00       	call   84d660 <gpui_gpu::renderer::slots::color_word>
  846c25:	81 4c 24 7c 00 00 00 	orl    $0x80000000,0x7c(%rsp)
  846c2c:	80 
  846c2d:	66 0f 6e c0          	movd   %eax,%xmm0
  846c31:	66 0f 7f 44 24 50    	movdqa %xmm0,0x50(%rsp)
  846c37:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846c3c:	48 8b 08             	mov    (%rax),%rcx
  846c3f:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846c43:	48 29 f1             	sub    %rsi,%rcx
  846c46:	48 83 f9 04          	cmp    $0x4,%rcx
  846c4a:	0f 86 44 03 00 00    	jbe    846f94 <<gpui_gpu::renderer::RendererState>::render+0x13a4>
  846c50:	66 0f 5a 84 24 a0 03 	cvtpd2ps 0x3a0(%rsp),%xmm0
  846c57:	00 00 
  846c59:	66 0f 5a 8c 24 c0 02 	cvtpd2ps 0x2c0(%rsp),%xmm1
  846c60:	00 00 
  846c62:	f2 0f 10 94 24 f0 00 	movsd  0xf0(%rsp),%xmm2
  846c69:	00 00 
  846c6b:	f2 0f 5a d2          	cvtsd2ss %xmm2,%xmm2
  846c6f:	f2 0f 10 9c 24 d0 02 	movsd  0x2d0(%rsp),%xmm3
  846c76:	00 00 
  846c78:	f2 0f 5a db          	cvtsd2ss %xmm3,%xmm3
  846c7c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846c81:	48 8b 48 08          	mov    0x8(%rax),%rcx
  846c85:	48 c1 e6 04          	shl    $0x4,%rsi
  846c89:	66 0f 13 04 31       	movlpd %xmm0,(%rcx,%rsi,1)
  846c8e:	f3 0f 11 54 31 08    	movss  %xmm2,0x8(%rcx,%rsi,1)
  846c94:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  846c99:	f3 0f 11 44 31 0c    	movss  %xmm0,0xc(%rcx,%rsi,1)
  846c9f:	66 0f 13 4c 31 10    	movlpd %xmm1,0x10(%rcx,%rsi,1)
  846ca5:	f3 0f 11 5c 31 18    	movss  %xmm3,0x18(%rcx,%rsi,1)
  846cab:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  846cb2:	00 
  846cb3:	f3 0f 11 44 31 1c    	movss  %xmm0,0x1c(%rcx,%rsi,1)
  846cb9:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  846cc0:	00 
  846cc1:	0f 11 44 31 20       	movups %xmm0,0x20(%rcx,%rsi,1)
  846cc6:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  846ccb:	0f 11 44 31 30       	movups %xmm0,0x30(%rcx,%rsi,1)
  846cd0:	8b 54 24 7c          	mov    0x7c(%rsp),%edx
  846cd4:	89 54 31 40          	mov    %edx,0x40(%rcx,%rsi,1)
  846cd8:	48 c7 44 31 44 00 00 	movq   $0x0,0x44(%rcx,%rsi,1)
  846cdf:	00 00 
  846ce1:	c7 44 31 4c 00 00 00 	movl   $0x0,0x4c(%rcx,%rsi,1)
  846ce8:	00 
  846ce9:	48 83 40 10 05       	addq   $0x5,0x10(%rax)
  846cee:	48 ff 84 24 38 01 00 	incq   0x138(%rsp)
  846cf5:	00 
  846cf6:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846cfd:	00 
  846cfe:	48 01 84 24 40 01 00 	add    %rax,0x140(%rsp)
  846d05:	00 
  846d06:	48 85 c0             	test   %rax,%rax
  846d09:	0f 84 57 02 00 00    	je     846f66 <<gpui_gpu::renderer::RendererState>::render+0x1376>
  846d0f:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  846d15:	66 0f 7e c1          	movd   %xmm0,%ecx
  846d19:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  846d20:	00 00 
  846d22:	66 0f 7e c0          	movd   %xmm0,%eax
  846d26:	48 c1 e0 20          	shl    $0x20,%rax
  846d2a:	48 09 c1             	or     %rax,%rcx
  846d2d:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  846d34:	00 
  846d35:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  846d3c:	00 00 
  846d3e:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846d43:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  846d48:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  846d4b:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  846d52:	00 
  846d53:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  846d58:	e8 43 d6 ff ff       	call   8443a0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  846d5d:	0f b6 bc 24 40 03 00 	movzbl 0x340(%rsp),%edi
  846d64:	00 
  846d65:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
  846d6c:	00 
  846d6d:	8b 46 f9             	mov    -0x7(%rsi),%eax
  846d70:	8b 4e fc             	mov    -0x4(%rsi),%ecx
  846d73:	48 8d 94 24 61 01 00 	lea    0x161(%rsp),%rdx
  846d7a:	00 
  846d7b:	89 4a 03             	mov    %ecx,0x3(%rdx)
  846d7e:	89 02                	mov    %eax,(%rdx)
  846d80:	48 8b 8c 24 48 03 00 	mov    0x348(%rsp),%rcx
  846d87:	00 
  846d88:	48 8b 46 28          	mov    0x28(%rsi),%rax
  846d8c:	48 89 42 2f          	mov    %rax,0x2f(%rdx)
  846d90:	0f 10 46 08          	movups 0x8(%rsi),%xmm0
  846d94:	0f 10 4e 18          	movups 0x18(%rsi),%xmm1
  846d98:	0f 11 4a 1f          	movups %xmm1,0x1f(%rdx)
  846d9c:	0f 11 42 0f          	movups %xmm0,0xf(%rdx)
  846da0:	0f 10 8c 24 78 03 00 	movups 0x378(%rsp),%xmm1
  846da7:	00 
  846da8:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  846daf:	00 
  846db0:	0f 10 00             	movups (%rax),%xmm0
  846db3:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  846dba:	00 
  846dbb:	0f 11 40 70          	movups %xmm0,0x70(%rax)
  846dbf:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  846dc6:	00 
  846dc7:	0f 11 80 80 00 00 00 	movups %xmm0,0x80(%rax)
  846dce:	0f 29 8c 24 a0 00 00 	movaps %xmm1,0xa0(%rsp)
  846dd5:	00 
  846dd6:	0f 11 8c 24 98 01 00 	movups %xmm1,0x198(%rsp)
  846ddd:	00 
  846dde:	0f 28 84 24 20 05 00 	movaps 0x520(%rsp),%xmm0
  846de5:	00 
  846de6:	0f 28 8c 24 30 05 00 	movaps 0x530(%rsp),%xmm1
  846ded:	00 
  846dee:	66 0f 28 94 24 40 05 	movapd 0x540(%rsp),%xmm2
  846df5:	00 00 
  846df7:	66 0f 11 50 50       	movupd %xmm2,0x50(%rax)
  846dfc:	0f 11 48 40          	movups %xmm1,0x40(%rax)
  846e00:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  846e04:	0f 28 84 24 50 05 00 	movaps 0x550(%rsp),%xmm0
  846e0b:	00 
  846e0c:	0f 11 40 60          	movups %xmm0,0x60(%rax)
  846e10:	40 88 7c 24 50       	mov    %dil,0x50(%rsp)
  846e15:	40 88 bc 24 60 01 00 	mov    %dil,0x160(%rsp)
  846e1c:	00 
  846e1d:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  846e24:	00 
  846e25:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  846e2c:	00 
  846e2d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846e32:	48 8b 08             	mov    (%rax),%rcx
  846e35:	48 8b 40 10          	mov    0x10(%rax),%rax
  846e39:	48 29 c1             	sub    %rax,%rcx
  846e3c:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  846e43:	00 
  846e44:	48 83 f9 01          	cmp    $0x1,%rcx
  846e48:	0f 86 dc 00 00 00    	jbe    846f2a <<gpui_gpu::renderer::RendererState>::render+0x133a>
  846e4e:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  846e53:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  846e57:	48 c1 e0 04          	shl    $0x4,%rax
  846e5b:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  846e62:	00 
  846e63:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  846e67:	48 c7 44 01 10 00 00 	movq   $0x0,0x10(%rcx,%rax,1)
  846e6e:	00 00 
  846e70:	c7 44 01 18 00 00 00 	movl   $0x0,0x18(%rcx,%rax,1)
  846e77:	00 
  846e78:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  846e7f:	89 54 01 1c          	mov    %edx,0x1c(%rcx,%rax,1)
  846e83:	48 83 46 10 02       	addq   $0x2,0x10(%rsi)
  846e88:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  846e8f:	00 
  846e90:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  846e97:	00 
  846e98:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  846e9f:	00 
  846ea0:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  846ea7:	00 
  846ea8:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  846ead:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  846eb4:	41 57                	push   %r15
  846eb6:	41 56                	push   %r14
  846eb8:	ff 74 24 50          	push   0x50(%rsp)
  846ebc:	e8 bf 11 00 00       	call   848080 <<gpui_gpu::renderer::RendererState>::bin_draw>
  846ec1:	48 83 c4 20          	add    $0x20,%rsp
  846ec5:	8b 84 24 40 03 00 00 	mov    0x340(%rsp),%eax
  846ecc:	83 f8 ff             	cmp    $0xffffffff,%eax
  846ecf:	0f 85 19 02 00 00    	jne    8470ee <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  846ed5:	80 7c 24 50 02       	cmpb   $0x2,0x50(%rsp)
  846eda:	0f 94 c0             	sete   %al
  846edd:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  846ee4:	00 00 
  846ee6:	0f 95 c1             	setne  %cl
  846ee9:	20 c1                	and    %al,%cl
  846eeb:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  846ef0:	08 c8                	or     %cl,%al
  846ef2:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  846ef7:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  846efe:	00 
  846eff:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  846f06:	00 
  846f07:	48 ff 44 24 48       	incq   0x48(%rsp)
  846f0c:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  846f11:	48 83 c1 04          	add    $0x4,%rcx
  846f15:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  846f1a:	48 39 8c 24 e0 03 00 	cmp    %rcx,0x3e0(%rsp)
  846f21:	00 
  846f22:	0f 85 16 fe ff ff    	jne    846d3e <<gpui_gpu::renderer::RendererState>::render+0x114e>
  846f28:	eb 30                	jmp    846f5a <<gpui_gpu::renderer::RendererState>::render+0x136a>
  846f2a:	ba 02 00 00 00       	mov    $0x2,%edx
  846f2f:	b9 04 00 00 00       	mov    $0x4,%ecx
  846f34:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  846f3a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846f3f:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  846f46:	00 
  846f47:	e8 64 47 00 00       	call   84b6b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  846f4c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846f51:	48 8b 40 10          	mov    0x10(%rax),%rax
  846f55:	e9 f4 fe ff ff       	jmp    846e4e <<gpui_gpu::renderer::RendererState>::render+0x125e>
  846f5a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  846f5f:	24 01                	and    $0x1,%al
  846f61:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  846f66:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  846f6d:	00 
  846f6e:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  846f75:	00 
  846f76:	ff 15 44 75 67 00    	call   *0x677544(%rip)        # ebe4c0 <_DYNAMIC+0x808>
  846f7c:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  846f83:	00 
  846f84:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  846f89:	48 85 c0             	test   %rax,%rax
  846f8c:	0f 85 2f f3 ff ff    	jne    8462c1 <<gpui_gpu::renderer::RendererState>::render+0x6d1>
  846f92:	eb 5e                	jmp    846ff2 <<gpui_gpu::renderer::RendererState>::render+0x1402>
  846f94:	ba 05 00 00 00       	mov    $0x5,%edx
  846f99:	b9 04 00 00 00       	mov    $0x4,%ecx
  846f9e:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  846fa4:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846fa9:	e8 02 47 00 00       	call   84b6b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  846fae:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846fb3:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846fb7:	e9 94 fc ff ff       	jmp    846c50 <<gpui_gpu::renderer::RendererState>::render+0x1060>
  846fbc:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  846fc3:	00 00 00 00 00 
  846fc8:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  846fcf:	00 00 00 00 00 
  846fd4:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  846fdb:	00 00 
  846fdd:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  846fe4:	00 00 
  846fe6:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  846fed:	00 00 00 00 00 
  846ff2:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  846ff9:	00 
  846ffa:	48 8d 56 08          	lea    0x8(%rsi),%rdx
  846ffe:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847003:	48 8d 88 58 02 00 00 	lea    0x258(%rax),%rcx
  84700a:	4c 8d 80 28 03 00 00 	lea    0x328(%rax),%r8
  847011:	4c 8b 48 10          	mov    0x10(%rax),%r9
  847015:	48 83 ec 08          	sub    $0x8,%rsp
  847019:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  847020:	00 
  847021:	48 89 94 24 d8 03 00 	mov    %rdx,0x3d8(%rsp)
  847028:	00 
  847029:	48 89 8c 24 c8 02 00 	mov    %rcx,0x2c8(%rsp)
  847030:	00 
  847031:	4c 89 84 24 d8 02 00 	mov    %r8,0x2d8(%rsp)
  847038:	00 
  847039:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
  847040:	e8 ab 35 00 00       	call   84a5f0 <gpui_gpu::renderer::images::prepare>
  847045:	48 83 c4 10          	add    $0x10,%rsp
  847049:	83 bc 24 60 01 00 00 	cmpl   $0xffffffff,0x160(%rsp)
  847050:	ff 
  847051:	74 47                	je     84709a <<gpui_gpu::renderer::RendererState>::render+0x14aa>
  847053:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  84705a:	00 
  84705b:	0f 10 8c 24 70 01 00 	movups 0x170(%rsp),%xmm1
  847062:	00 
  847063:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847068:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  84706c:	0f 11 07             	movups %xmm0,(%rdi)
  84706f:	e9 8d ec ff ff       	jmp    845d01 <<gpui_gpu::renderer::RendererState>::render+0x111>
  847074:	8b 94 24 1c 01 00 00 	mov    0x11c(%rsp),%edx
  84707b:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847080:	89 57 1c             	mov    %edx,0x1c(%rdi)
  847083:	0f 10 84 24 0c 01 00 	movups 0x10c(%rsp),%xmm0
  84708a:	00 
  84708b:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  84708f:	89 0f                	mov    %ecx,(%rdi)
  847091:	48 89 47 04          	mov    %rax,0x4(%rdi)
  847095:	e9 67 ec ff ff       	jmp    845d01 <<gpui_gpu::renderer::RendererState>::render+0x111>
  84709a:	44 0f b6 44 24 10    	movzbl 0x10(%rsp),%r8d
  8470a0:	41 83 e0 01          	and    $0x1,%r8d
  8470a4:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8470ab:	00 
  8470ac:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  8470b1:	48 8b 94 24 50 01 00 	mov    0x150(%rsp),%rdx
  8470b8:	00 
  8470b9:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  8470c0:	00 
  8470c1:	e8 3a e1 ff ff       	call   845200 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  8470c6:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  8470cd:	83 f8 ff             	cmp    $0xffffffff,%eax
  8470d0:	74 63                	je     847135 <<gpui_gpu::renderer::RendererState>::render+0x1545>
  8470d2:	8b 8c 24 64 01 00 00 	mov    0x164(%rsp),%ecx
  8470d9:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  8470e0:	00 
  8470e1:	0f 10 84 24 70 01 00 	movups 0x170(%rsp),%xmm0
  8470e8:	00 
  8470e9:	e9 3d f0 ff ff       	jmp    84612b <<gpui_gpu::renderer::RendererState>::render+0x53b>
  8470ee:	8b 8c 24 44 03 00 00 	mov    0x344(%rsp),%ecx
  8470f5:	48 8b 94 24 48 03 00 	mov    0x348(%rsp),%rdx
  8470fc:	00 
  8470fd:	0f 10 84 24 50 03 00 	movups 0x350(%rsp),%xmm0
  847104:	00 
  847105:	e9 21 f0 ff ff       	jmp    84612b <<gpui_gpu::renderer::RendererState>::render+0x53b>
  84710a:	8b 8c 24 7c 01 00 00 	mov    0x17c(%rsp),%ecx
  847111:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847116:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  847119:	0f 10 84 24 6c 01 00 	movups 0x16c(%rsp),%xmm0
  847120:	00 
  847121:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  847125:	89 07                	mov    %eax,(%rdi)
  847127:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  84712c:	48 89 47 04          	mov    %rax,0x4(%rdi)
  847130:	e9 cc eb ff ff       	jmp    845d01 <<gpui_gpu::renderer::RendererState>::render+0x111>
  847135:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  84713c:	00 
  84713d:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  847144:	00 
  847145:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  84714c:	00 
  84714d:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  847154:	00 
  847155:	48 c7 84 24 48 03 00 	movq   $0x0,0x348(%rsp)
  84715c:	00 00 00 00 00 
  847161:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  847168:	00 
  847169:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  847170:	00 
  847171:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  847178:	00 
  847179:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  847180:	00 
  847181:	8b 44 24 78          	mov    0x78(%rsp),%eax
  847185:	89 84 24 60 03 00 00 	mov    %eax,0x360(%rsp)
  84718c:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847193:	00 
  847194:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  84719b:	00 
  84719c:	ff 15 1e 73 67 00    	call   *0x67731e(%rip)        # ebe4c0 <_DYNAMIC+0x808>
  8471a2:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  8471a9:	00 
  8471aa:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  8471b1:	00 
  8471b2:	48 85 c0             	test   %rax,%rax
  8471b5:	0f 84 d7 03 00 00    	je     847592 <<gpui_gpu::renderer::RendererState>::render+0x19a2>
  8471bb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8471c0:	48 05 20 01 00 00    	add    $0x120,%rax
  8471c6:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  8471cd:	00 
  8471ce:	eb 3c                	jmp    84720c <<gpui_gpu::renderer::RendererState>::render+0x161c>
  8471d0:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  8471d7:	00 
  8471d8:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  8471df:	00 
  8471e0:	ff 15 da 72 67 00    	call   *0x6772da(%rip)        # ebe4c0 <_DYNAMIC+0x808>
  8471e6:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  8471ed:	00 
  8471ee:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  8471f3:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  8471fa:	00 
  8471fb:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  847202:	00 
  847203:	48 85 c0             	test   %rax,%rax
  847206:	0f 84 86 03 00 00    	je     847592 <<gpui_gpu::renderer::RendererState>::render+0x19a2>
  84720c:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  847213:	00 
  847214:	48 8b bc 24 68 02 00 	mov    0x268(%rsp),%rdi
  84721b:	00 
  84721c:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  847223:	00 
  847224:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  84722b:	00 
  84722c:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847230:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  847237:	00 
  847238:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  84723c:	0f 10 00             	movups (%rax),%xmm0
  84723f:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847243:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  847247:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  84724b:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  84724f:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  847253:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  847257:	0f 11 01             	movups %xmm0,(%rcx)
  84725a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84725f:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  847266:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  84726d:	00 
  84726e:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  847275:	00 
  847276:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  84727b:	48 89 94 24 68 01 00 	mov    %rdx,0x168(%rsp)
  847282:	00 
  847283:	48 89 bc 24 70 01 00 	mov    %rdi,0x170(%rsp)
  84728a:	00 
  84728b:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847292:	00 
  847293:	e8 48 1e 00 00       	call   8490e0 <gpui_gpu::renderer::compact_group>
  847298:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  84729f:	00 
  8472a0:	48 8d 51 05          	lea    0x5(%rcx),%rdx
  8472a4:	84 c0                	test   %al,%al
  8472a6:	48 0f 44 d1          	cmove  %rcx,%rdx
  8472aa:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  8472af:	48 83 bc 24 80 00 00 	cmpq   $0x0,0x80(%rsp)
  8472b6:	00 00 
  8472b8:	0f 84 12 ff ff ff    	je     8471d0 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  8472be:	48 c1 a4 24 80 00 00 	shlq   $0x2,0x80(%rsp)
  8472c5:	00 02 
  8472c7:	34 01                	xor    $0x1,%al
  8472c9:	0f b6 c8             	movzbl %al,%ecx
  8472cc:	c1 e1 02             	shl    $0x2,%ecx
  8472cf:	48 8d 41 01          	lea    0x1(%rcx),%rax
  8472d3:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  8472da:	00 
  8472db:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  8472e0:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  8472e4:	49 ff c0             	inc    %r8
  8472e7:	48 83 c9 02          	or     $0x2,%rcx
  8472eb:	49 c1 e0 04          	shl    $0x4,%r8
  8472ef:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  8472f6:	00 
  8472f7:	c1 e1 04             	shl    $0x4,%ecx
  8472fa:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  847301:	00 
  847302:	31 c9                	xor    %ecx,%ecx
  847304:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  847309:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  84730e:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  847313:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  847316:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84731d:	00 
  84731e:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  847325:	00 
  847326:	e8 75 d0 ff ff       	call   8443a0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  84732b:	0f b6 8c 24 60 01 00 	movzbl 0x160(%rsp),%ecx
  847332:	00 
  847333:	0f b6 84 24 61 01 00 	movzbl 0x161(%rsp),%eax
  84733a:	00 
  84733b:	f3 0f 10 a4 24 64 01 	movss  0x164(%rsp),%xmm4
  847342:	00 00 
  847344:	48 8d b4 24 68 01 00 	lea    0x168(%rsp),%rsi
  84734b:	00 
  84734c:	48 8b 56 10          	mov    0x10(%rsi),%rdx
  847350:	48 89 94 24 20 03 00 	mov    %rdx,0x320(%rsp)
  847357:	00 
  847358:	0f 10 06             	movups (%rsi),%xmm0
  84735b:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
  847362:	00 
  847363:	83 f9 01             	cmp    $0x1,%ecx
  847366:	0f 84 8f 00 00 00    	je     8473fb <<gpui_gpu::renderer::RendererState>::render+0x180b>
  84736c:	0f 29 a4 24 f0 00 00 	movaps %xmm4,0xf0(%rsp)
  847373:	00 
  847374:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  84737b:	00 
  84737c:	8b 94 24 88 01 00 00 	mov    0x188(%rsp),%edx
  847383:	89 54 24 60          	mov    %edx,0x60(%rsp)
  847387:	8b 94 24 8c 01 00 00 	mov    0x18c(%rsp),%edx
  84738e:	89 54 24 20          	mov    %edx,0x20(%rsp)
  847392:	83 f9 03             	cmp    $0x3,%ecx
  847395:	0f 85 e5 00 00 00    	jne    847480 <<gpui_gpu::renderer::RendererState>::render+0x1890>
  84739b:	48 8b 8c 24 d0 02 00 	mov    0x2d0(%rsp),%rcx
  8473a2:	00 
  8473a3:	48 8b 39             	mov    (%rcx),%rdi
  8473a6:	48 85 ff             	test   %rdi,%rdi
  8473a9:	0f 84 4c 0c 00 00    	je     847ffb <<gpui_gpu::renderer::RendererState>::render+0x240b>
  8473af:	0f b6 d0             	movzbl %al,%edx
  8473b2:	e8 c9 2e 00 00       	call   84a280 <<gpui_gpu::renderer::images::Images>::metadata>
  8473b7:	89 c1                	mov    %eax,%ecx
  8473b9:	48 c1 e8 20          	shr    $0x20,%rax
  8473bd:	89 c2                	mov    %eax,%edx
  8473bf:	83 ca 10             	or     $0x10,%edx
  8473c2:	0f 57 c0             	xorps  %xmm0,%xmm0
  8473c5:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
  8473cc:	00 
  8473cd:	0f 2e c8             	ucomiss %xmm0,%xmm1
  8473d0:	0f 45 c2             	cmovne %edx,%eax
  8473d3:	0f 4a c2             	cmovp  %edx,%eax
  8473d6:	8b 54 24 20          	mov    0x20(%rsp),%edx
  8473da:	c1 e2 10             	shl    $0x10,%edx
  8473dd:	0b 54 24 60          	or     0x60(%rsp),%edx
  8473e1:	89 8c 24 00 01 00 00 	mov    %ecx,0x100(%rsp)
  8473e8:	89 84 24 04 01 00 00 	mov    %eax,0x104(%rsp)
  8473ef:	89 94 24 08 01 00 00 	mov    %edx,0x108(%rsp)
  8473f6:	e9 22 01 00 00       	jmp    84751d <<gpui_gpu::renderer::RendererState>::render+0x192d>
  8473fb:	f3 0f 10 84 24 a0 01 	movss  0x1a0(%rsp),%xmm0
  847402:	00 00 
  847404:	f3 0f 10 1d a8 97 88 	movss  -0x776858(%rip),%xmm3        # d0bb4 <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  84740b:	ff 
  84740c:	f3 0f 59 c3          	mulss  %xmm3,%xmm0
  847410:	0f 28 cc             	movaps %xmm4,%xmm1
  847413:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  847417:	0f 28 c1             	movaps %xmm1,%xmm0
  84741a:	f3 0f c2 c1 03       	cmpunordss %xmm1,%xmm0
  84741f:	0f 28 d0             	movaps %xmm0,%xmm2
  847422:	0f 55 d1             	andnps %xmm1,%xmm2
  847425:	0f 54 c4             	andps  %xmm4,%xmm0
  847428:	0f 56 c2             	orps   %xmm2,%xmm0
  84742b:	f3 0f 10 8c 24 a4 01 	movss  0x1a4(%rsp),%xmm1
  847432:	00 00 
  847434:	f3 0f 59 cb          	mulss  %xmm3,%xmm1
  847438:	0f 28 d0             	movaps %xmm0,%xmm2
  84743b:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  84743f:	0f 28 ca             	movaps %xmm2,%xmm1
  847442:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  847447:	0f 54 c1             	andps  %xmm1,%xmm0
  84744a:	0f 55 ca             	andnps %xmm2,%xmm1
  84744d:	0f 56 c8             	orps   %xmm0,%xmm1
  847450:	66 0f 7e c8          	movd   %xmm1,%eax
  847454:	25 00 00 80 ff       	and    $0xff800000,%eax
  847459:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  84745e:	29 c1                	sub    %eax,%ecx
  847460:	c7 84 24 00 01 00 00 	movl   $0x40000000,0x100(%rsp)
  847467:	00 00 00 40 
  84746b:	f3 0f 11 8c 24 04 01 	movss  %xmm1,0x104(%rsp)
  847472:	00 00 
  847474:	89 8c 24 08 01 00 00 	mov    %ecx,0x108(%rsp)
  84747b:	e9 9d 00 00 00       	jmp    84751d <<gpui_gpu::renderer::RendererState>::render+0x192d>
  847480:	80 f9 02             	cmp    $0x2,%cl
  847483:	75 50                	jne    8474d5 <<gpui_gpu::renderer::RendererState>::render+0x18e5>
  847485:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  84748c:	00 
  84748d:	48 8b 8c 24 20 03 00 	mov    0x320(%rsp),%rcx
  847494:	00 
  847495:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  84749c:	00 
  84749d:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
  8474a4:	00 
  8474a5:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  8474ac:	00 
  8474ad:	48 89 b4 24 78 01 00 	mov    %rsi,0x178(%rsp)
  8474b4:	00 
  8474b5:	8b 4c 24 60          	mov    0x60(%rsp),%ecx
  8474b9:	89 8c 24 80 01 00 00 	mov    %ecx,0x180(%rsp)
  8474c0:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
  8474c4:	89 8c 24 84 01 00 00 	mov    %ecx,0x184(%rsp)
  8474cb:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  8474d2:	00 
  8474d3:	eb 0c                	jmp    8474e1 <<gpui_gpu::renderer::RendererState>::render+0x18f1>
  8474d5:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  8474dc:	00 00 00 00 00 
  8474e1:	c7 84 24 f0 02 00 00 	movl   $0x0,0x2f0(%rsp)
  8474e8:	00 00 00 00 
  8474ec:	48 c7 84 24 e8 02 00 	movq   $0x0,0x2e8(%rsp)
  8474f3:	00 00 00 00 00 
  8474f8:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  8474ff:	00 
  847500:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  847507:	00 
  847508:	48 8d 94 24 e8 02 00 	lea    0x2e8(%rsp),%rdx
  84750f:	00 
  847510:	48 8b 8c 24 a0 03 00 	mov    0x3a0(%rsp),%rcx
  847517:	00 
  847518:	e8 03 bc ff ff       	call   843120 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  84751d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  847522:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  847529:	00 
  84752a:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
  84752e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847533:	48 8b 70 10          	mov    0x10(%rax),%rsi
  847537:	48 39 f7             	cmp    %rsi,%rdi
  84753a:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  84753f:	0f 83 c3 0a 00 00    	jae    848008 <<gpui_gpu::renderer::RendererState>::render+0x2418>
  847545:	48 8b 40 08          	mov    0x8(%rax),%rax
  847549:	8b 8c 24 08 01 00 00 	mov    0x108(%rsp),%ecx
  847550:	42 89 4c 00 08       	mov    %ecx,0x8(%rax,%r8,1)
  847555:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  84755c:	00 
  84755d:	4a 89 0c 00          	mov    %rcx,(%rax,%r8,1)
  847561:	48 03 94 24 e0 00 00 	add    0xe0(%rsp),%rdx
  847568:	00 
  847569:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  84756e:	4c 03 84 24 20 01 00 	add    0x120(%rsp),%r8
  847575:	00 
  847576:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  84757b:	48 83 c1 04          	add    $0x4,%rcx
  84757f:	48 39 8c 24 80 00 00 	cmp    %rcx,0x80(%rsp)
  847586:	00 
  847587:	0f 85 77 fd ff ff    	jne    847304 <<gpui_gpu::renderer::RendererState>::render+0x1714>
  84758d:	e9 3e fc ff ff       	jmp    8471d0 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  847592:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847597:	48 8b 40 28          	mov    0x28(%rax),%rax
  84759b:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  8475a2:	00 00 
  8475a4:	48 85 c0             	test   %rax,%rax
  8475a7:	74 6b                	je     847614 <<gpui_gpu::renderer::RendererState>::render+0x1a24>
  8475a9:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  8475ae:	48 8b 49 20          	mov    0x20(%rcx),%rcx
  8475b2:	48 c1 e0 03          	shl    $0x3,%rax
  8475b6:	31 ff                	xor    %edi,%edi
  8475b8:	eb 1c                	jmp    8475d6 <<gpui_gpu::renderer::RendererState>::render+0x19e6>
  8475ba:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  8475bf:	01 f2                	add    %esi,%edx
  8475c1:	89 14 f9             	mov    %edx,(%rcx,%rdi,8)
  8475c4:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  8475c9:	89 54 f9 04          	mov    %edx,0x4(%rcx,%rdi,8)
  8475cd:	48 ff c7             	inc    %rdi
  8475d0:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  8475d4:	74 32                	je     847608 <<gpui_gpu::renderer::RendererState>::render+0x1a18>
  8475d6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  8475db:	48 8b 72 58          	mov    0x58(%rdx),%rsi
  8475df:	48 39 f7             	cmp    %rsi,%rdi
  8475e2:	0f 83 2d 0a 00 00    	jae    848015 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  8475e8:	8b 74 f9 04          	mov    0x4(%rcx,%rdi,8),%esi
  8475ec:	83 fe 01             	cmp    $0x1,%esi
  8475ef:	75 c9                	jne    8475ba <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  8475f1:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  8475f6:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  8475fa:	ba 00 00 00 80       	mov    $0x80000000,%edx
  8475ff:	41 83 3c b8 00       	cmpl   $0x0,(%r8,%rdi,4)
  847604:	75 c3                	jne    8475c9 <<gpui_gpu::renderer::RendererState>::render+0x19d9>
  847606:	eb b2                	jmp    8475ba <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  847608:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  84760d:	89 c0                	mov    %eax,%eax
  84760f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  847614:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847619:	48 8d 78 30          	lea    0x30(%rax),%rdi
  84761d:	48 c7 40 40 00 00 00 	movq   $0x0,0x40(%rax)
  847624:	00 
  847625:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  84762c:	00 
  84762d:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  847632:	31 d2                	xor    %edx,%edx
  847634:	e8 67 2e 00 00       	call   84a4a0 <<alloc::vec::Vec<u32>>::resize>
  847639:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84763e:	48 8b 40 10          	mov    0x10(%rax),%rax
  847642:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  847647:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  84764c:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  847653:	00 
  847654:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  84765b:	00 
  84765c:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  847663:	00 
  847664:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  84766b:	00 00 00 00 00 
  847670:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  847677:	00 
  847678:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  84767f:	00 
  847680:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  847687:	00 
  847688:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  84768f:	00 
  847690:	8b 44 24 78          	mov    0x78(%rsp),%eax
  847694:	89 84 24 08 03 00 00 	mov    %eax,0x308(%rsp)
  84769b:	eb 1a                	jmp    8476b7 <<gpui_gpu::renderer::RendererState>::render+0x1ac7>
  84769d:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  8476a2:	48 8d 41 fb          	lea    -0x5(%rcx),%rax
  8476a6:	80 bc 24 b0 00 00 00 	cmpb   $0x0,0xb0(%rsp)
  8476ad:	00 
  8476ae:	48 0f 45 c8          	cmovne %rax,%rcx
  8476b2:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  8476b7:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  8476be:	00 
  8476bf:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  8476c6:	00 
  8476c7:	ff 15 03 6e 67 00    	call   *0x676e03(%rip)        # ebe4d0 <_DYNAMIC+0x818>
  8476cd:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  8476d4:	00 
  8476d5:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  8476da:	48 85 c0             	test   %rax,%rax
  8476dd:	0f 84 55 02 00 00    	je     847938 <<gpui_gpu::renderer::RendererState>::render+0x1d48>
  8476e3:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  8476ea:	00 
  8476eb:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  8476f2:	00 
  8476f3:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  8476f8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8476fd:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  847704:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  847709:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  847710:	00 
  847711:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  847718:	00 
  847719:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  847720:	00 
  847721:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
  847728:	00 
  847729:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847730:	00 
  847731:	0f 10 00             	movups (%rax),%xmm0
  847734:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847738:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  84773d:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  847744:	00 
  847745:	f3 0f 7f 52 20       	movdqu %xmm2,0x20(%rdx)
  84774a:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  84774e:	0f 11 02             	movups %xmm0,(%rdx)
  847751:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  847758:	00 
  847759:	0f 10 01             	movups (%rcx),%xmm0
  84775c:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  847760:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847764:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  847768:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84776f:	00 
  847770:	e8 6b 19 00 00       	call   8490e0 <gpui_gpu::renderer::compact_group>
  847775:	88 84 24 b0 00 00 00 	mov    %al,0xb0(%rsp)
  84777c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  847781:	48 85 c0             	test   %rax,%rax
  847784:	0f 84 13 ff ff ff    	je     84769d <<gpui_gpu::renderer::RendererState>::render+0x1aad>
  84778a:	48 89 c1             	mov    %rax,%rcx
  84778d:	48 c1 e1 02          	shl    $0x2,%rcx
  847791:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
  847798:	00 
  847799:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
  8477a0:	48 83 ca fa          	or     $0xfffffffffffffffa,%rdx
  8477a4:	31 f6                	xor    %esi,%esi
  8477a6:	84 c0                	test   %al,%al
  8477a8:	40 0f 94 c6          	sete   %sil
  8477ac:	c1 e6 1f             	shl    $0x1f,%esi
  8477af:	89 b4 24 b8 00 00 00 	mov    %esi,0xb8(%rsp)
  8477b6:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  8477bb:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  8477c0:	01 d0                	add    %edx,%eax
  8477c2:	89 44 24 10          	mov    %eax,0x10(%rsp)
  8477c6:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  8477cb:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  8477d2:	00 
  8477d3:	8b 54 08 fc          	mov    -0x4(%rax,%rcx,1),%edx
  8477d7:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  8477de:	00 
  8477df:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  8477e4:	e8 b7 cb ff ff       	call   8443a0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8477e9:	48 ff 8c 24 00 01 00 	decq   0x100(%rsp)
  8477f0:	00 
  8477f1:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  8477f6:	48 01 44 24 20       	add    %rax,0x20(%rsp)
  8477fb:	8b 84 24 b8 00 00 00 	mov    0xb8(%rsp),%eax
  847802:	0b 44 24 10          	or     0x10(%rsp),%eax
  847806:	89 84 24 10 04 00 00 	mov    %eax,0x410(%rsp)
  84780d:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847814:	00 
  847815:	0f 10 00             	movups (%rax),%xmm0
  847818:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  84781c:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  847820:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  847827:	00 
  847828:	0f 11 52 50          	movups %xmm2,0x50(%rdx)
  84782c:	0f 11 4a 40          	movups %xmm1,0x40(%rdx)
  847830:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  847834:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  84783b:	00 
  84783c:	0f 10 01             	movups (%rcx),%xmm0
  84783f:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  847843:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847847:	0f 11 82 80 00 00 00 	movups %xmm0,0x80(%rdx)
  84784e:	48 8d 84 24 78 03 00 	lea    0x378(%rsp),%rax
  847855:	00 
  847856:	0f 10 00             	movups (%rax),%xmm0
  847859:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  84785d:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  847864:	00 
  847865:	0f 10 00             	movups (%rax),%xmm0
  847868:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
  84786c:	48 8b 84 24 70 03 00 	mov    0x370(%rsp),%rax
  847873:	00 
  847874:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  84787b:	00 
  84787c:	0f 10 84 24 40 03 00 	movups 0x340(%rsp),%xmm0
  847883:	00 
  847884:	0f 10 8c 24 50 03 00 	movups 0x350(%rsp),%xmm1
  84788b:	00 
  84788c:	f3 0f 6f 94 24 60 03 	movdqu 0x360(%rsp),%xmm2
  847893:	00 00 
  847895:	66 0f 7f 94 24 80 01 	movdqa %xmm2,0x180(%rsp)
  84789c:	00 00 
  84789e:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  8478a5:	00 
  8478a6:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  8478ad:	00 
  8478ae:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  8478b5:	00 
  8478b6:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  8478bd:	00 
  8478be:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  8478c5:	00 
  8478c6:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
  8478cd:	00 
  8478ce:	48 8b 84 24 08 04 00 	mov    0x408(%rsp),%rax
  8478d5:	00 
  8478d6:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  8478dd:	00 
  8478de:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  8478e5:	00 
  8478e6:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  8478ed:	00 
  8478ee:	48 8d 84 24 10 04 00 	lea    0x410(%rsp),%rax
  8478f5:	00 
  8478f6:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  8478fd:	00 
  8478fe:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847905:	00 
  847906:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  84790b:	48 8d 94 24 10 03 00 	lea    0x310(%rsp),%rdx
  847912:	00 
  847913:	e8 c8 c6 ff ff       	call   843fe0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  847918:	8b 44 24 10          	mov    0x10(%rsp),%eax
  84791c:	03 44 24 30          	add    0x30(%rsp),%eax
  847920:	89 44 24 10          	mov    %eax,0x10(%rsp)
  847924:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  847929:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
  84792d:	0f 85 93 fe ff ff    	jne    8477c6 <<gpui_gpu::renderer::RendererState>::render+0x1bd6>
  847933:	e9 65 fd ff ff       	jmp    84769d <<gpui_gpu::renderer::RendererState>::render+0x1aad>
  847938:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84793d:	48 8b 78 28          	mov    0x28(%rax),%rdi
  847941:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  847948:	00 00 00 00 00 
  84794d:	48 85 ff             	test   %rdi,%rdi
  847950:	0f 84 ca 00 00 00    	je     847a20 <<gpui_gpu::renderer::RendererState>::render+0x1e30>
  847956:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84795b:	4c 8b 40 20          	mov    0x20(%rax),%r8
  84795f:	48 c1 e7 03          	shl    $0x3,%rdi
  847963:	83 7c 24 38 00       	cmpl   $0x0,0x38(%rsp)
  847968:	0f 84 47 06 00 00    	je     847fb5 <<gpui_gpu::renderer::RendererState>::render+0x23c5>
  84796e:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  847975:	00 00 
  847977:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  84797e:	00 00 
  847980:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847987:	00 00 
  847989:	45 31 c9             	xor    %r9d,%r9d
  84798c:	31 c9                	xor    %ecx,%ecx
  84798e:	eb 23                	jmp    8479b3 <<gpui_gpu::renderer::RendererState>::render+0x1dc3>
  847990:	48 ff 44 24 10       	incq   0x10(%rsp)
  847995:	49 ff c1             	inc    %r9
  847998:	4c 3b 4c 24 38       	cmp    0x38(%rsp),%r9
  84799d:	b8 00 00 00 00       	mov    $0x0,%eax
  8479a2:	4c 0f 44 c8          	cmove  %rax,%r9
  8479a6:	48 ff c1             	inc    %rcx
  8479a9:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  8479ad:	0f 84 88 00 00 00    	je     847a3b <<gpui_gpu::renderer::RendererState>::render+0x1e4b>
  8479b3:	45 8b 54 c8 04       	mov    0x4(%r8,%rcx,8),%r10d
  8479b8:	44 89 d0             	mov    %r10d,%eax
  8479bb:	f7 d8                	neg    %eax
  8479bd:	70 d1                	jo     847990 <<gpui_gpu::renderer::RendererState>::render+0x1da0>
  8479bf:	45 2b 14 c8          	sub    (%r8,%rcx,8),%r10d
  8479c3:	74 d0                	je     847995 <<gpui_gpu::renderer::RendererState>::render+0x1da5>
  8479c5:	48 89 c8             	mov    %rcx,%rax
  8479c8:	48 c1 e8 20          	shr    $0x20,%rax
  8479cc:	74 0f                	je     8479dd <<gpui_gpu::renderer::RendererState>::render+0x1ded>
  8479ce:	48 89 c8             	mov    %rcx,%rax
  8479d1:	31 d2                	xor    %edx,%edx
  8479d3:	48 f7 74 24 38       	divq   0x38(%rsp)
  8479d8:	4c 89 ca             	mov    %r9,%rdx
  8479db:	eb 08                	jmp    8479e5 <<gpui_gpu::renderer::RendererState>::render+0x1df5>
  8479dd:	89 c8                	mov    %ecx,%eax
  8479df:	31 d2                	xor    %edx,%edx
  8479e1:	f7 74 24 38          	divl   0x38(%rsp)
  8479e5:	c1 e2 04             	shl    $0x4,%edx
  8479e8:	c1 e0 04             	shl    $0x4,%eax
  8479eb:	44 8d 5a 10          	lea    0x10(%rdx),%r11d
  8479ef:	45 39 de             	cmp    %r11d,%r14d
  8479f2:	45 0f 42 de          	cmovb  %r14d,%r11d
  8479f6:	8d 70 10             	lea    0x10(%rax),%esi
  8479f9:	41 39 f7             	cmp    %esi,%r15d
  8479fc:	41 0f 42 f7          	cmovb  %r15d,%esi
  847a00:	41 29 d3             	sub    %edx,%r11d
  847a03:	29 c6                	sub    %eax,%esi
  847a05:	41 0f af f3          	imul   %r11d,%esi
  847a09:	48 c1 e6 04          	shl    $0x4,%rsi
  847a0d:	48 01 74 24 18       	add    %rsi,0x18(%rsp)
  847a12:	4c 0f af d6          	imul   %rsi,%r10
  847a16:	4c 01 54 24 30       	add    %r10,0x30(%rsp)
  847a1b:	e9 75 ff ff ff       	jmp    847995 <<gpui_gpu::renderer::RendererState>::render+0x1da5>
  847a20:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847a27:	00 00 
  847a29:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  847a30:	00 00 
  847a32:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  847a39:	00 00 
  847a3b:	41 f6 c5 01          	test   $0x1,%r13b
  847a3f:	74 53                	je     847a94 <<gpui_gpu::renderer::RendererState>::render+0x1ea4>
  847a41:	66 0f 6e 84 24 5c 01 	movd   0x15c(%rsp),%xmm0
  847a48:	00 00 
  847a4a:	66 0f 7e c0          	movd   %xmm0,%eax
  847a4e:	85 c0                	test   %eax,%eax
  847a50:	0f 99 c1             	setns  %cl
  847a53:	89 c2                	mov    %eax,%edx
  847a55:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  847a5b:	81 c2 00 00 80 ff    	add    $0xff800000,%edx
  847a61:	81 fa 00 00 00 7f    	cmp    $0x7f000000,%edx
  847a67:	0f 92 c2             	setb   %dl
  847a6a:	20 ca                	and    %cl,%dl
  847a6c:	ff c8                	dec    %eax
  847a6e:	3d ff ff 7f 00       	cmp    $0x7fffff,%eax
  847a73:	0f 92 c0             	setb   %al
  847a76:	08 d0                	or     %dl,%al
  847a78:	b8 02 00 00 00       	mov    $0x2,%eax
  847a7d:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  847a84:	00 
  847a85:	66 0f 7e 84 24 ec 00 	movd   %xmm0,0xec(%rsp)
  847a8c:	00 00 
  847a8e:	0f 84 17 05 00 00    	je     847fab <<gpui_gpu::renderer::RendererState>::render+0x23bb>
  847a94:	4c 8b ac 24 50 01 00 	mov    0x150(%rsp),%r13
  847a9b:	00 
  847a9c:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  847aa3:	00 
  847aa4:	48 83 c1 18          	add    $0x18,%rcx
  847aa8:	31 d2                	xor    %edx,%edx
  847aaa:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  847ab1:	00 
  847ab2:	48 3b 84 24 b8 03 00 	cmp    0x3b8(%rsp),%rax
  847ab9:	00 
  847aba:	0f 95 c2             	setne  %dl
  847abd:	31 c0                	xor    %eax,%eax
  847abf:	83 fd 28             	cmp    $0x28,%ebp
  847ac2:	0f 94 c0             	sete   %al
  847ac5:	41 83 e4 01          	and    $0x1,%r12d
  847ac9:	41 8d 04 84          	lea    (%r12,%rax,4),%eax
  847acd:	8d 04 d0             	lea    (%rax,%rdx,8),%eax
  847ad0:	0b 84 24 98 00 00 00 	or     0x98(%rsp),%eax
  847ad7:	0f 10 01             	movups (%rcx),%xmm0
  847ada:	0f 11 84 24 68 02 00 	movups %xmm0,0x268(%rsp)
  847ae1:	00 
  847ae2:	44 89 b4 24 58 02 00 	mov    %r14d,0x258(%rsp)
  847ae9:	00 
  847aea:	44 89 bc 24 5c 02 00 	mov    %r15d,0x25c(%rsp)
  847af1:	00 
  847af2:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  847af7:	89 8c 24 60 02 00 00 	mov    %ecx,0x260(%rsp)
  847afe:	89 84 24 64 02 00 00 	mov    %eax,0x264(%rsp)
  847b05:	f3 0f 10 84 24 ec 00 	movss  0xec(%rsp),%xmm0
  847b0c:	00 00 
  847b0e:	f3 0f 11 84 24 78 02 	movss  %xmm0,0x278(%rsp)
  847b15:	00 00 
  847b17:	48 c7 84 24 7c 02 00 	movq   $0x0,0x27c(%rsp)
  847b1e:	00 00 00 00 00 
  847b23:	c7 84 24 84 02 00 00 	movl   $0x0,0x284(%rsp)
  847b2a:	00 00 00 00 
  847b2e:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
  847b33:	48 8d b5 30 02 00 00 	lea    0x230(%rbp),%rsi
  847b3a:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  847b3f:	48 8d 8c 24 58 02 00 	lea    0x258(%rsp),%rcx
  847b46:	00 
  847b47:	41 b8 30 00 00 00    	mov    $0x30,%r8d
  847b4d:	4c 8b a4 24 d0 03 00 	mov    0x3d0(%rsp),%r12
  847b54:	00 
  847b55:	4c 89 e7             	mov    %r12,%rdi
  847b58:	31 d2                	xor    %edx,%edx
  847b5a:	ff 15 78 69 67 00    	call   *0x676978(%rip)        # ebe4d8 <_DYNAMIC+0x820>
  847b60:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
  847b64:	4c 8b 45 10          	mov    0x10(%rbp),%r8
  847b68:	49 c1 e0 04          	shl    $0x4,%r8
  847b6c:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  847b73:	00 
  847b74:	4c 89 ee             	mov    %r13,%rsi
  847b77:	4c 89 e2             	mov    %r12,%rdx
  847b7a:	e8 61 ca ff ff       	call   8445e0 <<gpui_gpu::renderer::Buffer>::write>
  847b7f:	48 8d bd 80 02 00 00 	lea    0x280(%rbp),%rdi
  847b86:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  847b8d:	00 
  847b8e:	48 8b 4d 20          	mov    0x20(%rbp),%rcx
  847b92:	4c 8b 45 28          	mov    0x28(%rbp),%r8
  847b96:	49 c1 e0 03          	shl    $0x3,%r8
  847b9a:	4c 89 ee             	mov    %r13,%rsi
  847b9d:	4c 89 e2             	mov    %r12,%rdx
  847ba0:	e8 3b ca ff ff       	call   8445e0 <<gpui_gpu::renderer::Buffer>::write>
  847ba5:	48 8d bd a8 02 00 00 	lea    0x2a8(%rbp),%rdi
  847bac:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  847bb3:	00 
  847bb4:	48 8b 4d 38          	mov    0x38(%rbp),%rcx
  847bb8:	4c 8b 45 40          	mov    0x40(%rbp),%r8
  847bbc:	49 c1 e0 02          	shl    $0x2,%r8
  847bc0:	4c 89 ee             	mov    %r13,%rsi
  847bc3:	4c 89 e2             	mov    %r12,%rdx
  847bc6:	e8 15 ca ff ff       	call   8445e0 <<gpui_gpu::renderer::Buffer>::write>
  847bcb:	48 8d bd d0 02 00 00 	lea    0x2d0(%rbp),%rdi
  847bd2:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  847bd7:	48 8b 4d 68          	mov    0x68(%rbp),%rcx
  847bdb:	4c 8b 45 70          	mov    0x70(%rbp),%r8
  847bdf:	49 c1 e0 05          	shl    $0x5,%r8
  847be3:	4c 89 ee             	mov    %r13,%rsi
  847be6:	4c 89 e2             	mov    %r12,%rdx
  847be9:	e8 f2 c9 ff ff       	call   8445e0 <<gpui_gpu::renderer::Buffer>::write>
  847bee:	48 8d 85 c8 00 00 00 	lea    0xc8(%rbp),%rax
  847bf5:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  847bfc:	00 00 00 00 00 
  847c01:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  847c06:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  847c0d:	00 
  847c0e:	48 c7 84 24 88 01 00 	movq   $0x0,0x188(%rsp)
  847c15:	00 00 00 00 00 
  847c1a:	0f 57 c0             	xorps  %xmm0,%xmm0
  847c1d:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
  847c24:	00 
  847c25:	c7 84 24 80 01 00 00 	movl   $0x0,0x180(%rsp)
  847c2c:	00 00 00 00 
  847c30:	48 8b 8c 24 c0 02 00 	mov    0x2c0(%rsp),%rcx
  847c37:	00 
  847c38:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
  847c3f:	00 
  847c40:	0f 11 84 24 98 01 00 	movups %xmm0,0x198(%rsp)
  847c47:	00 
  847c48:	c7 84 24 a8 01 00 00 	movl   $0x1,0x1a8(%rsp)
  847c4f:	01 00 00 00 
  847c53:	48 c7 84 24 b0 01 00 	movq   $0x0,0x1b0(%rsp)
  847c5a:	00 00 00 00 00 
  847c5f:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  847c66:	00 
  847c67:	48 89 8c 24 b8 01 00 	mov    %rcx,0x1b8(%rsp)
  847c6e:	00 
  847c6f:	0f 11 84 24 c0 01 00 	movups %xmm0,0x1c0(%rsp)
  847c76:	00 
  847c77:	c7 84 24 d0 01 00 00 	movl   $0x2,0x1d0(%rsp)
  847c7e:	02 00 00 00 
  847c82:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
  847c89:	00 00 00 00 00 
  847c8e:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  847c95:	00 
  847c96:	48 89 8c 24 e0 01 00 	mov    %rcx,0x1e0(%rsp)
  847c9d:	00 
  847c9e:	0f 11 84 24 e8 01 00 	movups %xmm0,0x1e8(%rsp)
  847ca5:	00 
  847ca6:	c7 84 24 f8 01 00 00 	movl   $0x3,0x1f8(%rsp)
  847cad:	03 00 00 00 
  847cb1:	48 c7 84 24 00 02 00 	movq   $0x4,0x200(%rsp)
  847cb8:	00 04 00 00 00 
  847cbd:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  847cc4:	00 
  847cc5:	c7 84 24 20 02 00 00 	movl   $0x4,0x220(%rsp)
  847ccc:	04 00 00 00 
  847cd0:	48 c7 84 24 28 02 00 	movq   $0x0,0x228(%rsp)
  847cd7:	00 00 00 00 00 
  847cdc:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847ce1:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
  847ce8:	00 
  847ce9:	0f 11 84 24 38 02 00 	movups %xmm0,0x238(%rsp)
  847cf0:	00 
  847cf1:	c7 84 24 48 02 00 00 	movl   $0x5,0x248(%rsp)
  847cf8:	05 00 00 00 
  847cfc:	48 8d 05 01 8f 89 ff 	lea    -0x7670ff(%rip),%rax        # e0c04 <anon.fd87c01464a3e1b3301f7c003a8d34c5.0.llvm.18422474119301403747+0x2c50>
  847d03:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  847d0a:	00 
  847d0b:	48 c7 84 24 60 03 00 	movq   $0xa,0x360(%rsp)
  847d12:	00 0a 00 00 00 
  847d17:	49 8d 45 18          	lea    0x18(%r13),%rax
  847d1b:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  847d22:	00 
  847d23:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  847d2a:	00 
  847d2b:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  847d32:	00 
  847d33:	48 c7 84 24 50 03 00 	movq   $0x6,0x350(%rsp)
  847d3a:	00 06 00 00 00 
  847d3f:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  847d46:	00 
  847d47:	4c 89 ef             	mov    %r13,%rdi
  847d4a:	ff 15 90 67 67 00    	call   *0x676790(%rip)        # ebe4e0 <_DYNAMIC+0x828>
  847d50:	48 89 c5             	mov    %rax,%rbp
  847d53:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  847d5a:	00 
  847d5b:	48 8d 94 24 10 03 00 	lea    0x310(%rsp),%rdx
  847d62:	00 
  847d63:	4c 89 ef             	mov    %r13,%rdi
  847d66:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  847d6d:	00 
  847d6e:	e8 cd ce ff ff       	call   844c40 <<gpui_gpu::renderer::GpuContext>::submit>
  847d73:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  847d78:	45 31 ed             	xor    %r13d,%r13d
  847d7b:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  847d82:	00 
  847d83:	48 3b 84 24 b8 03 00 	cmp    0x3b8(%rsp),%rax
  847d8a:	00 
  847d8b:	41 0f 95 c5          	setne  %r13b
  847d8f:	41 c1 e5 1f          	shl    $0x1f,%r13d
  847d93:	45 09 f5             	or     %r14d,%r13d
  847d96:	49 c1 e7 20          	shl    $0x20,%r15
  847d9a:	4d 09 fd             	or     %r15,%r13
  847d9d:	48 8b 03             	mov    (%rbx),%rax
  847da0:	48 85 c0             	test   %rax,%rax
  847da3:	74 0f                	je     847db4 <<gpui_gpu::renderer::RendererState>::render+0x21c4>
  847da5:	f0 48 ff 08          	lock decq (%rax)
  847da9:	75 09                	jne    847db4 <<gpui_gpu::renderer::RendererState>::render+0x21c4>
  847dab:	48 89 df             	mov    %rbx,%rdi
  847dae:	ff 15 94 63 67 00    	call   *0x676394(%rip)        # ebe148 <_DYNAMIC+0x490>
  847db4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847db9:	48 89 a8 30 03 00 00 	mov    %rbp,0x330(%rax)
  847dc0:	4c 89 a8 38 03 00 00 	mov    %r13,0x338(%rax)
  847dc7:	4c 8b 40 10          	mov    0x10(%rax),%r8
  847dcb:	48 8b 70 28          	mov    0x28(%rax),%rsi
  847dcf:	48 8b 48 70          	mov    0x70(%rax),%rcx
  847dd3:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  847dda:	00 
  847ddb:	49 c1 e0 04          	shl    $0x4,%r8
  847ddf:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  847de4:	49 8d 3c 90          	lea    (%r8,%rdx,4),%rdi
  847de8:	48 8d 34 f7          	lea    (%rdi,%rsi,8),%rsi
  847dec:	48 89 cf             	mov    %rcx,%rdi
  847def:	48 c1 e7 05          	shl    $0x5,%rdi
  847df3:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
  847df7:	48 83 c1 30          	add    $0x30,%rcx
  847dfb:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  847e02:	00 
  847e03:	48 8b b8 78 02 00 00 	mov    0x278(%rax),%rdi
  847e0a:	48 03 b8 50 02 00 00 	add    0x250(%rax),%rdi
  847e11:	48 03 b8 a0 02 00 00 	add    0x2a0(%rax),%rdi
  847e18:	48 03 b8 c8 02 00 00 	add    0x2c8(%rax),%rdi
  847e1f:	48 03 b8 f0 02 00 00 	add    0x2f0(%rax),%rdi
  847e26:	48 8b b0 08 03 00 00 	mov    0x308(%rax),%rsi
  847e2d:	48 03 b0 10 03 00 00 	add    0x310(%rax),%rsi
  847e34:	44 8b 88 50 01 00 00 	mov    0x150(%rax),%r9d
  847e3b:	4d 0f af c9          	imul   %r9,%r9
  847e3f:	4c 8b 9c 24 d8 00 00 	mov    0xd8(%rsp),%r11
  847e46:	00 
  847e47:	4c 89 d9             	mov    %r11,%rcx
  847e4a:	48 29 d1             	sub    %rdx,%rcx
  847e4d:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
  847e52:	4d 89 d4             	mov    %r10,%r12
  847e55:	48 8b ac 24 40 01 00 	mov    0x140(%rsp),%rbp
  847e5c:	00 
  847e5d:	49 29 ec             	sub    %rbp,%r12
  847e60:	48 8b 98 60 01 00 00 	mov    0x160(%rax),%rbx
  847e67:	48 ff c3             	inc    %rbx
  847e6a:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  847e71:	4c 0f 45 f3          	cmovne %rbx,%r14
  847e75:	48 8b 18             	mov    (%rax),%rbx
  847e78:	48 c1 e3 04          	shl    $0x4,%rbx
  847e7c:	4c 8b 78 48          	mov    0x48(%rax),%r15
  847e80:	4c 03 78 30          	add    0x30(%rax),%r15
  847e84:	4c 8b 68 18          	mov    0x18(%rax),%r13
  847e88:	4a 8d 1c eb          	lea    (%rbx,%r13,8),%rbx
  847e8c:	4a 8d 1c bb          	lea    (%rbx,%r15,4),%rbx
  847e90:	4c 8b 78 60          	mov    0x60(%rax),%r15
  847e94:	49 c1 e7 05          	shl    $0x5,%r15
  847e98:	49 01 df             	add    %rbx,%r15
  847e9b:	48 8b 98 38 01 00 00 	mov    0x138(%rax),%rbx
  847ea2:	4c 8b a8 30 01 00 00 	mov    0x130(%rax),%r13
  847ea9:	4c 89 b0 60 01 00 00 	mov    %r14,0x160(%rax)
  847eb0:	4c 89 90 68 01 00 00 	mov    %r10,0x168(%rax)
  847eb7:	4f 8d 34 1b          	lea    (%r11,%r11,1),%r14
  847ebb:	4c 89 b0 70 01 00 00 	mov    %r14,0x170(%rax)
  847ec2:	48 c7 80 78 01 00 00 	movq   $0x1,0x178(%rax)
  847ec9:	01 00 00 00 
  847ecd:	4c 89 90 80 01 00 00 	mov    %r10,0x180(%rax)
  847ed4:	48 89 90 88 01 00 00 	mov    %rdx,0x188(%rax)
  847edb:	4c 89 98 90 01 00 00 	mov    %r11,0x190(%rax)
  847ee2:	48 89 88 98 01 00 00 	mov    %rcx,0x198(%rax)
  847ee9:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  847eee:	48 89 88 a0 01 00 00 	mov    %rcx,0x1a0(%rax)
  847ef5:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  847efa:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
  847f01:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  847f06:	48 89 88 b0 01 00 00 	mov    %rcx,0x1b0(%rax)
  847f0d:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  847f14:	00 
  847f15:	48 89 88 b8 01 00 00 	mov    %rcx,0x1b8(%rax)
  847f1c:	4c 89 80 c0 01 00 00 	mov    %r8,0x1c0(%rax)
  847f23:	48 8b 94 24 38 01 00 	mov    0x138(%rsp),%rdx
  847f2a:	00 
  847f2b:	48 89 90 c8 01 00 00 	mov    %rdx,0x1c8(%rax)
  847f32:	48 89 a8 d0 01 00 00 	mov    %rbp,0x1d0(%rax)
  847f39:	4c 89 a0 d8 01 00 00 	mov    %r12,0x1d8(%rax)
  847f40:	48 8b 8c 24 c0 03 00 	mov    0x3c0(%rsp),%rcx
  847f47:	00 
  847f48:	48 89 88 e0 01 00 00 	mov    %rcx,0x1e0(%rax)
  847f4f:	48 89 b8 e8 01 00 00 	mov    %rdi,0x1e8(%rax)
  847f56:	4c 89 88 f0 01 00 00 	mov    %r9,0x1f0(%rax)
  847f5d:	49 01 dd             	add    %rbx,%r13
  847f60:	48 89 98 f8 01 00 00 	mov    %rbx,0x1f8(%rax)
  847f67:	4c 89 a8 00 02 00 00 	mov    %r13,0x200(%rax)
  847f6e:	4c 89 b8 08 02 00 00 	mov    %r15,0x208(%rax)
  847f75:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  847f7c:	00 
  847f7d:	48 89 88 10 02 00 00 	mov    %rcx,0x210(%rax)
  847f84:	48 89 b0 18 02 00 00 	mov    %rsi,0x218(%rax)
  847f8b:	c6 80 20 02 00 00 00 	movb   $0x0,0x220(%rax)
  847f92:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847f97:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  847f9c:	48 89 47 08          	mov    %rax,0x8(%rdi)
  847fa0:	c7 07 ff ff ff ff    	movl   $0xffffffff,(%rdi)
  847fa6:	e9 56 dd ff ff       	jmp    845d01 <<gpui_gpu::renderer::RendererState>::render+0x111>
  847fab:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847fb0:	e9 3e dd ff ff       	jmp    845cf3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  847fb5:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  847fbc:	00 00 
  847fbe:	31 c0                	xor    %eax,%eax
  847fc0:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847fc7:	00 00 
  847fc9:	eb 12                	jmp    847fdd <<gpui_gpu::renderer::RendererState>::render+0x23ed>
  847fcb:	48 ff 44 24 10       	incq   0x10(%rsp)
  847fd0:	48 83 c0 08          	add    $0x8,%rax
  847fd4:	48 39 c7             	cmp    %rax,%rdi
  847fd7:	0f 84 55 fa ff ff    	je     847a32 <<gpui_gpu::renderer::RendererState>::render+0x1e42>
  847fdd:	41 8b 4c 00 04       	mov    0x4(%r8,%rax,1),%ecx
  847fe2:	89 ca                	mov    %ecx,%edx
  847fe4:	f7 da                	neg    %edx
  847fe6:	70 e3                	jo     847fcb <<gpui_gpu::renderer::RendererState>::render+0x23db>
  847fe8:	41 39 0c 00          	cmp    %ecx,(%r8,%rax,1)
  847fec:	74 e2                	je     847fd0 <<gpui_gpu::renderer::RendererState>::render+0x23e0>
  847fee:	48 8d 3d 0b 41 62 00 	lea    0x62410b(%rip),%rdi        # e6c100 <anon.ca7974afd5d3cc0a502e508af20e0901.29.llvm.15378138995035259094+0x10>
  847ff5:	ff 15 ed 64 67 00    	call   *0x6764ed(%rip)        # ebe4e8 <_DYNAMIC+0x830>
  847ffb:	48 8d 3d 66 3f 62 00 	lea    0x623f66(%rip),%rdi        # e6bf68 <anon.e1d0e6d22dab240d16e467862c9a25f9.3.llvm.3223857199548621548+0x1098>
  848002:	ff 15 18 60 67 00    	call   *0x676018(%rip)        # ebe020 <_DYNAMIC+0x368>
  848008:	48 8d 15 71 3f 62 00 	lea    0x623f71(%rip),%rdx        # e6bf80 <anon.e1d0e6d22dab240d16e467862c9a25f9.3.llvm.3223857199548621548+0x10b0>
  84800f:	ff 15 83 61 67 00    	call   *0x676183(%rip)        # ebe198 <_DYNAMIC+0x4e0>
  848015:	48 8d 15 34 3f 62 00 	lea    0x623f34(%rip),%rdx        # e6bf50 <anon.e1d0e6d22dab240d16e467862c9a25f9.3.llvm.3223857199548621548+0x1080>
  84801c:	ff 15 76 61 67 00    	call   *0x676176(%rip)        # ebe198 <_DYNAMIC+0x4e0>
  848022:	49 89 c6             	mov    %rax,%r14
  848025:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84802a:	48 89 a8 30 03 00 00 	mov    %rbp,0x330(%rax)
  848031:	4c 89 a8 38 03 00 00 	mov    %r13,0x338(%rax)
  848038:	4c 89 f7             	mov    %r14,%rdi
  84803b:	e8 f0 ef 61 00       	call   e67030 <_Unwind_Resume@plt>
  848040:	49 89 c6             	mov    %rax,%r14
  848043:	f0 48 ff 4d 00       	lock decq 0x0(%rbp)
  848048:	75 20                	jne    84806a <<gpui_gpu::renderer::RendererState>::render+0x247a>
  84804a:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
  848051:	00 
  848052:	ff 15 f0 60 67 00    	call   *0x6760f0(%rip)        # ebe148 <_DYNAMIC+0x490>
  848058:	eb 10                	jmp    84806a <<gpui_gpu::renderer::RendererState>::render+0x247a>
  84805a:	ff 15 c0 5e 67 00    	call   *0x675ec0(%rip)        # ebdf20 <_DYNAMIC+0x268>
  848060:	49 89 c6             	mov    %rax,%r14
  848063:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  84806a:	4c 89 f7             	mov    %r14,%rdi
  84806d:	e8 be ef 61 00       	call   e67030 <_Unwind_Resume@plt>
