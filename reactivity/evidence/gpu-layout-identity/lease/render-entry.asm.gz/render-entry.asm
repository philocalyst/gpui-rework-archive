
/tmp/gpui-layout-identity-controls/lease/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845bf0 <<gpui_gpu::renderer::RendererState>::render>:
  845bf0:	55                   	push   %rbp
  845bf1:	41 57                	push   %r15
  845bf3:	41 56                	push   %r14
  845bf5:	41 55                	push   %r13
  845bf7:	41 54                	push   %r12
  845bf9:	53                   	push   %rbx
  845bfa:	48 81 ec 68 05 00 00 	sub    $0x568,%rsp
  845c01:	48 8b 86 28 02 00 00 	mov    0x228(%rsi),%rax
  845c08:	4c 8b 4a 18          	mov    0x18(%rdx),%r9
  845c0c:	4c 39 c8             	cmp    %r9,%rax
  845c0f:	74 1c                	je     845c2d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  845c11:	4c 8b 50 10          	mov    0x10(%rax),%r10
  845c15:	4d 3b 51 10          	cmp    0x10(%r9),%r10
  845c19:	0f 85 dc 00 00 00    	jne    845cfb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  845c1f:	48 8b 40 18          	mov    0x18(%rax),%rax
  845c23:	49 3b 41 18          	cmp    0x18(%r9),%rax
  845c27:	0f 85 ce 00 00 00    	jne    845cfb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  845c2d:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  845c34:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  845c3b:	48 85 c0             	test   %rax,%rax
  845c3e:	74 2d                	je     845c6d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  845c40:	f0 48 ff 08          	lock decq (%rax)
  845c44:	75 27                	jne    845c6d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  845c46:	49 89 fe             	mov    %rdi,%r14
  845c49:	48 89 df             	mov    %rbx,%rdi
  845c4c:	49 89 f4             	mov    %rsi,%r12
  845c4f:	4d 89 c5             	mov    %r8,%r13
  845c52:	49 89 d7             	mov    %rdx,%r15
  845c55:	48 89 cd             	mov    %rcx,%rbp
  845c58:	ff 15 ea 84 67 00    	call   *0x6784ea(%rip)        # ebe148 <_DYNAMIC+0x490>
  845c5e:	48 89 e9             	mov    %rbp,%rcx
  845c61:	4c 89 fa             	mov    %r15,%rdx
  845c64:	4d 89 e8             	mov    %r13,%r8
  845c67:	4c 89 e6             	mov    %r12,%rsi
  845c6a:	4c 89 f7             	mov    %r14,%rdi
  845c6d:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  845c74:	00 00 00 00 
  845c78:	44 8b 29             	mov    (%rcx),%r13d
  845c7b:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  845c7f:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  845c83:	45 85 c9             	test   %r9d,%r9d
  845c86:	41 0f 98 c2          	sets   %r10b
  845c8a:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845c91:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  845c98:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  845c9f:	41 0f 92 c3          	setb   %r11b
  845ca3:	45 20 d3             	and    %r10b,%r11b
  845ca6:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  845caa:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  845cb0:	40 0f 92 c5          	setb   %bpl
  845cb4:	44 20 d5             	and    %r10b,%bpl
  845cb7:	45 85 c9             	test   %r9d,%r9d
  845cba:	41 0f 94 c2          	sete   %r10b
  845cbe:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  845cc5:	41 0f 94 c6          	sete   %r14b
  845cc9:	45 08 d6             	or     %r10b,%r14b
  845ccc:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  845cd3:	41 0f 9d c1          	setge  %r9b
  845cd7:	45 08 f1             	or     %r14b,%r9b
  845cda:	41 08 e9             	or     %bpl,%r9b
  845cdd:	45 85 ed             	test   %r13d,%r13d
  845ce0:	41 0f 95 c2          	setne  %r10b
  845ce4:	41 20 c2             	and    %al,%r10b
  845ce7:	45 08 da             	or     %r11b,%r10b
  845cea:	45 08 ca             	or     %r9b,%r10b
  845ced:	41 f6 c2 01          	test   $0x1,%r10b
  845cf1:	74 23                	je     845d16 <<gpui_gpu::renderer::RendererState>::render+0x126>
  845cf3:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
