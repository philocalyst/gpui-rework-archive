
/tmp/gpui-layout-identity-controls/numeric/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845ed0 <<gpui_gpu::renderer::RendererState>::render>:
  845ed0:	55                   	push   %rbp
  845ed1:	41 57                	push   %r15
  845ed3:	41 56                	push   %r14
  845ed5:	41 55                	push   %r13
  845ed7:	41 54                	push   %r12
  845ed9:	53                   	push   %rbx
  845eda:	48 81 ec 68 05 00 00 	sub    $0x568,%rsp
  845ee1:	48 8b 86 20 03 00 00 	mov    0x320(%rsi),%rax
  845ee8:	48 3b 42 20          	cmp    0x20(%rdx),%rax
  845eec:	0f 85 ce 00 00 00    	jne    845fc0 <<gpui_gpu::renderer::RendererState>::render+0xf0>
  845ef2:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  845ef9:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  845f00:	48 85 c0             	test   %rax,%rax
  845f03:	74 2d                	je     845f32 <<gpui_gpu::renderer::RendererState>::render+0x62>
  845f05:	f0 48 ff 08          	lock decq (%rax)
  845f09:	75 27                	jne    845f32 <<gpui_gpu::renderer::RendererState>::render+0x62>
  845f0b:	49 89 fe             	mov    %rdi,%r14
  845f0e:	48 89 df             	mov    %rbx,%rdi
  845f11:	49 89 f4             	mov    %rsi,%r12
  845f14:	4d 89 c5             	mov    %r8,%r13
  845f17:	49 89 d7             	mov    %rdx,%r15
  845f1a:	48 89 cd             	mov    %rcx,%rbp
  845f1d:	ff 15 65 84 67 00    	call   *0x678465(%rip)        # ebe388 <_DYNAMIC+0x490>
  845f23:	48 89 e9             	mov    %rbp,%rcx
  845f26:	4c 89 fa             	mov    %r15,%rdx
  845f29:	4d 89 e8             	mov    %r13,%r8
  845f2c:	4c 89 e6             	mov    %r12,%rsi
  845f2f:	4c 89 f7             	mov    %r14,%rdi
  845f32:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  845f39:	00 00 00 00 
  845f3d:	44 8b 29             	mov    (%rcx),%r13d
  845f40:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  845f44:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  845f48:	45 85 c9             	test   %r9d,%r9d
  845f4b:	41 0f 98 c2          	sets   %r10b
  845f4f:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845f56:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  845f5d:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  845f64:	41 0f 92 c3          	setb   %r11b
  845f68:	45 20 d3             	and    %r10b,%r11b
  845f6b:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  845f6f:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  845f75:	40 0f 92 c5          	setb   %bpl
  845f79:	44 20 d5             	and    %r10b,%bpl
  845f7c:	45 85 c9             	test   %r9d,%r9d
  845f7f:	41 0f 94 c2          	sete   %r10b
  845f83:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  845f8a:	41 0f 94 c6          	sete   %r14b
  845f8e:	45 08 d6             	or     %r10b,%r14b
  845f91:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  845f98:	41 0f 9d c1          	setge  %r9b
  845f9c:	45 08 f1             	or     %r14b,%r9b
  845f9f:	41 08 e9             	or     %bpl,%r9b
  845fa2:	45 85 ed             	test   %r13d,%r13d
  845fa5:	41 0f 95 c2          	setne  %r10b
  845fa9:	41 20 c2             	and    %al,%r10b
  845fac:	45 08 da             	or     %r11b,%r10b
  845faf:	45 08 ca             	or     %r9b,%r10b
  845fb2:	41 f6 c2 01          	test   $0x1,%r10b
  845fb6:	74 23                	je     845fdb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  845fb8:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  845fbe:	eb 06                	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  845fc0:	c7 07 04 00 00 00    	movl   $0x4,(%rdi)
  845fc6:	48 89 f8             	mov    %rdi,%rax
  845fc9:	48 81 c4 68 05 00 00 	add    $0x568,%rsp
  845fd0:	5b                   	pop    %rbx
  845fd1:	41 5c                	pop    %r12
  845fd3:	41 5d                	pop    %r13
