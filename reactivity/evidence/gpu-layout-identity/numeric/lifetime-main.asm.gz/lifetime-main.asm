
/tmp/gpui-layout-identity-controls/numeric/layout-lifetime:     file format elf64-x86-64


Disassembly of section .text:

000000000016e5e0 <layout_lifetime::main>:
  16e5e0:	55                   	push   %rbp
  16e5e1:	41 57                	push   %r15
  16e5e3:	41 56                	push   %r14
  16e5e5:	53                   	push   %rbx
  16e5e6:	48 81 ec f8 07 00 00 	sub    $0x7f8,%rsp
  16e5ed:	ff 15 ed 52 37 00    	call   *0x3752ed(%rip)        # 4e38e0 <_DYNAMIC+0x3f8>
  16e5f3:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  16e5f8:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  16e5fd:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  16e602:	ff 15 e0 52 37 00    	call   *0x3752e0(%rip)        # 4e38e8 <_DYNAMIC+0x400>
  16e608:	48 89 04 24          	mov    %rax,(%rsp)
  16e60c:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  16e611:	48 8d 35 e8 95 34 00 	lea    0x3495e8(%rip),%rsi        # 4b7c00 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0x58>
  16e618:	48 89 e7             	mov    %rsp,%rdi
  16e61b:	ff 15 cf 52 37 00    	call   *0x3752cf(%rip)        # 4e38f0 <_DYNAMIC+0x408>
  16e621:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  16e626:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  16e62d:	00 00 
  16e62f:	48 8d 9c 24 d0 00 00 	lea    0xd0(%rsp),%rbx
  16e636:	00 
  16e637:	48 8d 74 24 20       	lea    0x20(%rsp),%rsi
  16e63c:	48 8d 54 24 18       	lea    0x18(%rsp),%rdx
  16e641:	48 89 df             	mov    %rbx,%rdi
  16e644:	e8 07 d0 ff ff       	call   16b650 <allocation_counter::measure::<layout_lifetime::main::{closure#0}>>
  16e649:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  16e64e:	4c 8d b4 24 00 01 00 	lea    0x100(%rsp),%r14
  16e655:	00 
  16e656:	4c 89 f7             	mov    %r14,%rdi
  16e659:	e8 12 d7 ff ff       	call   16bd70 <allocation_counter::measure::<layout_lifetime::main::{closure#1}>>
  16e65e:	48 83 bc 24 d0 00 00 	cmpq   $0x0,0xd0(%rsp)
  16e665:	00 00 
  16e667:	0f 85 68 03 00 00    	jne    16e9d5 <layout_lifetime::main+0x3f5>
  16e66d:	48 83 bc 24 00 01 00 	cmpq   $0x0,0x100(%rsp)
  16e674:	00 00 
  16e676:	0f 85 62 03 00 00    	jne    16e9de <layout_lifetime::main+0x3fe>
  16e67c:	48 8d 84 24 d0 00 00 	lea    0xd0(%rsp),%rax
  16e683:	00 
  16e684:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  16e68b:	00 
  16e68c:	4c 8d 3d fd 0d 00 00 	lea    0xdfd(%rip),%r15        # 16f490 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  16e693:	4c 89 bc 24 38 01 00 	mov    %r15,0x138(%rsp)
  16e69a:	00 
  16e69b:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  16e6a2:	00 
  16e6a3:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  16e6aa:	00 
  16e6ab:	4c 89 bc 24 48 01 00 	mov    %r15,0x148(%rsp)
  16e6b2:	00 
  16e6b3:	48 8d 3d 81 1b f1 ff 	lea    -0xee47f(%rip),%rdi        # 8023b <anon.8f7cdc0594fd4f0c7116fd8b126176fb.552.llvm.10099564126919119806+0x38c>
  16e6ba:	48 8d 9c 24 30 01 00 	lea    0x130(%rsp),%rbx
  16e6c1:	00 
  16e6c2:	48 89 de             	mov    %rbx,%rsi
  16e6c5:	ff 15 2d 52 37 00    	call   *0x37522d(%rip)        # 4e38f8 <_DYNAMIC+0x410>
  16e6cb:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  16e6d0:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  16e6d7:	00 
  16e6d8:	f0 48 ff 08          	lock decq (%rax)
  16e6dc:	75 0e                	jne    16e6ec <layout_lifetime::main+0x10c>
  16e6de:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  16e6e5:	00 
  16e6e6:	ff 15 5c 50 37 00    	call   *0x37505c(%rip)        # 4e3748 <_DYNAMIC+0x260>
  16e6ec:	48 8b 04 24          	mov    (%rsp),%rax
  16e6f0:	f0 48 ff 00          	lock incq (%rax)
  16e6f4:	0f 8e e8 03 00 00    	jle    16eae2 <layout_lifetime::main+0x502>
  16e6fa:	48 8b 04 24          	mov    (%rsp),%rax
  16e6fe:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  16e703:	48 c7 44 24 3c 16 00 	movq   $0x16,0x3c(%rsp)
  16e70a:	00 00 
  16e70c:	c7 44 24 44 00 00 00 	movl   $0x0,0x44(%rsp)
  16e713:	00 
  16e714:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  16e71b:	00 
  16e71c:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  16e723:	00 
  16e724:	0f 10 44 24 30       	movups 0x30(%rsp),%xmm0
  16e729:	0f 11 84 24 78 01 00 	movups %xmm0,0x178(%rsp)
  16e730:	00 
  16e731:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  16e736:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  16e73d:	00 
  16e73e:	c6 84 24 95 01 00 00 	movb   $0x0,0x195(%rsp)
  16e745:	00 
  16e746:	48 89 9c 24 a0 00 00 	mov    %rbx,0xa0(%rsp)
  16e74d:	00 
  16e74e:	48 8d 35 6b 94 34 00 	lea    0x34946b(%rip),%rsi        # 4b7bc0 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0x18>
  16e755:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  16e75c:	00 
  16e75d:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
  16e764:	00 
  16e765:	e8 66 d8 ff ff       	call   16bfd0 <<std::thread::local::LocalKey<core::task::wake::Waker>>::with::<pollster::block_on<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>::{closure#0}, core::result::Result<gpui_gpu::renderer::GpuContext, gpui_gpu::renderer::Error>>>
  16e76a:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  16e771:	00 
  16e772:	e8 29 f4 ff ff       	call   16dba0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  16e777:	83 bc 24 d8 04 00 00 	cmpl   $0xffffffff,0x4d8(%rsp)
  16e77e:	ff 
  16e77f:	0f 84 7c 02 00 00    	je     16ea01 <layout_lifetime::main+0x421>
  16e785:	48 8b 84 24 e0 04 00 	mov    0x4e0(%rsp),%rax
  16e78c:	00 
  16e78d:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  16e792:	0f 10 84 24 b0 04 00 	movups 0x4b0(%rsp),%xmm0
  16e799:	00 
  16e79a:	0f 10 8c 24 c0 04 00 	movups 0x4c0(%rsp),%xmm1
  16e7a1:	00 
  16e7a2:	0f 10 94 24 d0 04 00 	movups 0x4d0(%rsp),%xmm2
  16e7a9:	00 
  16e7aa:	0f 29 54 24 50       	movaps %xmm2,0x50(%rsp)
  16e7af:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
  16e7b4:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
  16e7b9:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  16e7c0:	00 
  16e7c1:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
  16e7c6:	ff 15 34 51 37 00    	call   *0x375134(%rip)        # 4e3900 <_DYNAMIC+0x418>
  16e7cc:	48 8d 05 b5 6c f2 ff 	lea    -0xd934b(%rip),%rax        # 95488 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x8>
  16e7d3:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  16e7da:	00 
  16e7db:	48 8b 05 86 50 37 00 	mov    0x375086(%rip),%rax        # 4e3868 <_DYNAMIC+0x380>
  16e7e2:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  16e7e9:	00 
  16e7ea:	48 8d 0d 67 71 f2 ff 	lea    -0xd8e99(%rip),%rcx        # 95958 <anon.a16d5d421a76dfd8c37a17b53540311d.145.llvm.14190004212411149437+0x70>
  16e7f1:	48 89 8c 24 40 01 00 	mov    %rcx,0x140(%rsp)
  16e7f8:	00 
  16e7f9:	48 89 84 24 48 01 00 	mov    %rax,0x148(%rsp)
  16e800:	00 
  16e801:	40 b5 01             	mov    $0x1,%bpl
  16e804:	48 8d 3d 1d bb f1 ff 	lea    -0xe44e3(%rip),%rdi        # 8a328 <anon.46a3e2b798de606f8dc289e9df67b47d.1112.llvm.2527675475217510166+0x40a>
  16e80b:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
  16e812:	00 
  16e813:	ff 15 df 50 37 00    	call   *0x3750df(%rip)        # 4e38f8 <_DYNAMIC+0x410>
  16e819:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  16e81e:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  16e825:	00 
  16e826:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
  16e82b:	0f 28 4c 24 40       	movaps 0x40(%rsp),%xmm1
  16e830:	0f 28 54 24 50       	movaps 0x50(%rsp),%xmm2
  16e835:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
  16e83c:	00 
  16e83d:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  16e844:	00 
  16e845:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  16e84c:	00 
  16e84d:	31 ed                	xor    %ebp,%ebp
  16e84f:	48 8d 9c 24 80 04 00 	lea    0x480(%rsp),%rbx
  16e856:	00 
  16e857:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
  16e85e:	00 
  16e85f:	48 89 df             	mov    %rbx,%rdi
  16e862:	e8 39 d0 ff ff       	call   16b8a0 <allocation_counter::measure::<layout_lifetime::main::{closure#2}>>
  16e867:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  16e86e:	00 00 
  16e870:	c7 84 24 80 00 00 00 	movl   $0xffffffff,0x80(%rsp)
  16e877:	ff ff ff ff 
  16e87b:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  16e880:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  16e887:	00 
  16e888:	8b 84 24 80 00 00 00 	mov    0x80(%rsp),%eax
  16e88f:	89 84 24 48 01 00 00 	mov    %eax,0x148(%rsp)
  16e896:	8b 84 24 84 00 00 00 	mov    0x84(%rsp),%eax
  16e89d:	89 84 24 4c 01 00 00 	mov    %eax,0x14c(%rsp)
  16e8a4:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
  16e8a9:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
  16e8b0:	00 
  16e8b1:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  16e8b6:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
  16e8bd:	00 
  16e8be:	31 ed                	xor    %ebp,%ebp
  16e8c0:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  16e8c7:	00 
  16e8c8:	48 89 e6             	mov    %rsp,%rsi
  16e8cb:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
  16e8d2:	00 
  16e8d3:	ff 15 2f 50 37 00    	call   *0x37502f(%rip)        # 4e3908 <_DYNAMIC+0x420>
  16e8d9:	83 bc 24 a0 00 00 00 	cmpl   $0x2,0xa0(%rsp)
  16e8e0:	02 
  16e8e1:	0f 85 67 01 00 00    	jne    16ea4e <layout_lifetime::main+0x46e>
  16e8e7:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
  16e8ee:	00 
  16e8ef:	4c 89 bc 24 38 01 00 	mov    %r15,0x138(%rsp)
  16e8f6:	00 
  16e8f7:	31 ed                	xor    %ebp,%ebp
  16e8f9:	48 8d 3d a5 0e f2 ff 	lea    -0xdf15b(%rip),%rdi        # 8f7a5 <anon.bf7e3e8257110be5986cfdd74163f765.35.llvm.2336547866852174585+0x38a>
  16e900:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
  16e907:	00 
  16e908:	ff 15 ea 4f 37 00    	call   *0x374fea(%rip)        # 4e38f8 <_DYNAMIC+0x410>
  16e90e:	4c 8d b4 24 30 01 00 	lea    0x130(%rsp),%r14
  16e915:	00 
  16e916:	48 8d b4 24 b0 04 00 	lea    0x4b0(%rsp),%rsi
  16e91d:	00 
  16e91e:	ba 48 03 00 00       	mov    $0x348,%edx
  16e923:	4c 89 f7             	mov    %r14,%rdi
  16e926:	ff 15 4c 4e 37 00    	call   *0x374e4c(%rip)        # 4e3778 <memcpy@GLIBC_2.14>
  16e92c:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
  16e933:	00 
  16e934:	48 89 df             	mov    %rbx,%rdi
  16e937:	4c 89 f6             	mov    %r14,%rsi
  16e93a:	e8 d1 d1 ff ff       	call   16bb10 <allocation_counter::measure::<layout_lifetime::main::{closure#3}>>
  16e93f:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
  16e946:	00 
  16e947:	48 89 e6             	mov    %rsp,%rsi
  16e94a:	48 8d 54 24 68       	lea    0x68(%rsp),%rdx
  16e94f:	ff 15 b3 4f 37 00    	call   *0x374fb3(%rip)        # 4e3908 <_DYNAMIC+0x420>
  16e955:	83 bc 24 88 00 00 00 	cmpl   $0x2,0x88(%rsp)
  16e95c:	02 
  16e95d:	0f 85 37 01 00 00    	jne    16ea9a <layout_lifetime::main+0x4ba>
  16e963:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
  16e96a:	00 
  16e96b:	4c 89 bc 24 38 01 00 	mov    %r15,0x138(%rsp)
  16e972:	00 
  16e973:	48 8d 3d 76 8d f1 ff 	lea    -0xe728a(%rip),%rdi        # 876f0 <anon.068260129a360d3c14a88deb110120c9.25.llvm.7357624670875813013+0x6e4>
  16e97a:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
  16e981:	00 
  16e982:	ff 15 70 4f 37 00    	call   *0x374f70(%rip)        # 4e38f8 <_DYNAMIC+0x410>
  16e988:	48 8b 04 24          	mov    (%rsp),%rax
  16e98c:	f0 48 ff 08          	lock decq (%rax)
  16e990:	75 09                	jne    16e99b <layout_lifetime::main+0x3bb>
  16e992:	48 89 e7             	mov    %rsp,%rdi
  16e995:	ff 15 25 4e 37 00    	call   *0x374e25(%rip)        # 4e37c0 <_DYNAMIC+0x2d8>
  16e99b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  16e9a0:	f0 48 ff 08          	lock decq (%rax)
  16e9a4:	75 0b                	jne    16e9b1 <layout_lifetime::main+0x3d1>
  16e9a6:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  16e9ab:	ff 15 5f 4f 37 00    	call   *0x374f5f(%rip)        # 4e3910 <_DYNAMIC+0x428>
  16e9b1:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  16e9b6:	f0 48 ff 08          	lock decq (%rax)
  16e9ba:	75 0b                	jne    16e9c7 <layout_lifetime::main+0x3e7>
  16e9bc:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  16e9c1:	ff 15 51 4f 37 00    	call   *0x374f51(%rip)        # 4e3918 <_DYNAMIC+0x430>
  16e9c7:	48 81 c4 f8 07 00 00 	add    $0x7f8,%rsp
  16e9ce:	5b                   	pop    %rbx
  16e9cf:	41 5e                	pop    %r14
  16e9d1:	41 5f                	pop    %r15
  16e9d3:	5d                   	pop    %rbp
  16e9d4:	c3                   	ret
  16e9d5:	4c 8d 0d a4 92 34 00 	lea    0x3492a4(%rip),%r9        # 4b7c80 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0xd8>
  16e9dc:	eb 0a                	jmp    16e9e8 <layout_lifetime::main+0x408>
  16e9de:	4c 8d 0d 83 92 34 00 	lea    0x349283(%rip),%r9        # 4b7c68 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0xc0>
  16e9e5:	4c 89 f3             	mov    %r14,%rbx
  16e9e8:	48 8d 15 b1 6c f2 ff 	lea    -0xd934f(%rip),%rdx        # 956a0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x50>
  16e9ef:	31 ff                	xor    %edi,%edi
  16e9f1:	48 89 de             	mov    %rbx,%rsi
  16e9f4:	31 c9                	xor    %ecx,%ecx
  16e9f6:	ff 15 24 4f 37 00    	call   *0x374f24(%rip)        # 4e3920 <_DYNAMIC+0x438>
  16e9fc:	e9 e1 00 00 00       	jmp    16eae2 <layout_lifetime::main+0x502>
  16ea01:	0f 10 84 24 b0 04 00 	movups 0x4b0(%rsp),%xmm0
  16ea08:	00 
  16ea09:	0f 10 8c 24 c0 04 00 	movups 0x4c0(%rsp),%xmm1
  16ea10:	00 
  16ea11:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  16ea18:	00 
  16ea19:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  16ea20:	00 
  16ea21:	48 8d 3d 41 73 f2 ff 	lea    -0xd8cbf(%rip),%rdi        # 95d69 <anon.bc329d565e882899ad0ec25b9ca21a02.26.llvm.11544637286324592738+0x1b5>
  16ea28:	48 8d 0d 89 92 34 00 	lea    0x349289(%rip),%rcx        # 4b7cb8 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0x110>
  16ea2f:	4c 8d 05 ea 91 34 00 	lea    0x3491ea(%rip),%r8        # 4b7c20 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0x78>
  16ea36:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
  16ea3d:	00 
  16ea3e:	be 2b 00 00 00       	mov    $0x2b,%esi
  16ea43:	ff 15 af 4d 37 00    	call   *0x374daf(%rip)        # 4e37f8 <_DYNAMIC+0x310>
  16ea49:	e9 94 00 00 00       	jmp    16eae2 <layout_lifetime::main+0x502>
  16ea4e:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  16ea55:	00 
  16ea56:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  16ea5d:	00 
  16ea5e:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
  16ea65:	00 
  16ea66:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  16ea6d:	00 
  16ea6e:	31 ed                	xor    %ebp,%ebp
  16ea70:	48 8d 3d f2 72 f2 ff 	lea    -0xd8d0e(%rip),%rdi        # 95d69 <anon.bc329d565e882899ad0ec25b9ca21a02.26.llvm.11544637286324592738+0x1b5>
  16ea77:	48 8d 0d 1a 92 34 00 	lea    0x34921a(%rip),%rcx        # 4b7c98 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0xf0>
  16ea7e:	4c 8d 05 b3 91 34 00 	lea    0x3491b3(%rip),%r8        # 4b7c38 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0x90>
  16ea85:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
  16ea8c:	00 
  16ea8d:	be 2b 00 00 00       	mov    $0x2b,%esi
  16ea92:	ff 15 60 4d 37 00    	call   *0x374d60(%rip)        # 4e37f8 <_DYNAMIC+0x310>
  16ea98:	eb 48                	jmp    16eae2 <layout_lifetime::main+0x502>
  16ea9a:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  16eaa1:	00 
  16eaa2:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  16eaa9:	00 
  16eaaa:	0f 10 84 24 88 00 00 	movups 0x88(%rsp),%xmm0
  16eab1:	00 
  16eab2:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  16eab9:	00 
  16eaba:	48 8d 3d a8 72 f2 ff 	lea    -0xd8d58(%rip),%rdi        # 95d69 <anon.bc329d565e882899ad0ec25b9ca21a02.26.llvm.11544637286324592738+0x1b5>
  16eac1:	48 8d 0d d0 91 34 00 	lea    0x3491d0(%rip),%rcx        # 4b7c98 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0xf0>
  16eac8:	4c 8d 05 81 91 34 00 	lea    0x349181(%rip),%r8        # 4b7c50 <anon.bc329d565e882899ad0ec25b9ca21a02.28.llvm.11544637286324592738+0xa8>
  16eacf:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
  16ead6:	00 
  16ead7:	be 2b 00 00 00       	mov    $0x2b,%esi
  16eadc:	ff 15 16 4d 37 00    	call   *0x374d16(%rip)        # 4e37f8 <_DYNAMIC+0x310>
  16eae2:	0f 0b                	ud2
  16eae4:	48 89 c3             	mov    %rax,%rbx
  16eae7:	e9 de 00 00 00       	jmp    16ebca <layout_lifetime::main+0x5ea>
  16eaec:	eb 42                	jmp    16eb30 <layout_lifetime::main+0x550>
  16eaee:	48 89 c3             	mov    %rax,%rbx
  16eaf1:	eb 73                	jmp    16eb66 <layout_lifetime::main+0x586>
  16eaf3:	eb 57                	jmp    16eb4c <layout_lifetime::main+0x56c>
  16eaf5:	48 89 c3             	mov    %rax,%rbx
  16eaf8:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  16eaff:	00 
  16eb00:	e8 9b f0 ff ff       	call   16dba0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  16eb05:	e9 97 00 00 00       	jmp    16eba1 <layout_lifetime::main+0x5c1>
  16eb0a:	ff 15 60 4c 37 00    	call   *0x374c60(%rip)        # 4e3770 <_DYNAMIC+0x288>
  16eb10:	48 89 c3             	mov    %rax,%rbx
  16eb13:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  16eb18:	48 85 c0             	test   %rax,%rax
  16eb1b:	74 58                	je     16eb75 <layout_lifetime::main+0x595>
  16eb1d:	f0 48 ff 08          	lock decq (%rax)
  16eb21:	75 52                	jne    16eb75 <layout_lifetime::main+0x595>
  16eb23:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  16eb28:	ff 15 1a 4c 37 00    	call   *0x374c1a(%rip)        # 4e3748 <_DYNAMIC+0x260>
  16eb2e:	eb 45                	jmp    16eb75 <layout_lifetime::main+0x595>
  16eb30:	48 89 c3             	mov    %rax,%rbx
  16eb33:	eb 56                	jmp    16eb8b <layout_lifetime::main+0x5ab>
  16eb35:	48 89 c3             	mov    %rax,%rbx
  16eb38:	eb 7a                	jmp    16ebb4 <layout_lifetime::main+0x5d4>
  16eb3a:	48 89 c3             	mov    %rax,%rbx
  16eb3d:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
  16eb44:	00 
  16eb45:	e8 a6 f8 ff ff       	call   16e3f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>
  16eb4a:	eb 55                	jmp    16eba1 <layout_lifetime::main+0x5c1>
  16eb4c:	48 89 c3             	mov    %rax,%rbx
  16eb4f:	eb 50                	jmp    16eba1 <layout_lifetime::main+0x5c1>
  16eb51:	48 89 c3             	mov    %rax,%rbx
  16eb54:	48 8d bc 24 b0 04 00 	lea    0x4b0(%rsp),%rdi
  16eb5b:	00 
  16eb5c:	e8 ef f2 ff ff       	call   16de50 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>
  16eb61:	40 84 ed             	test   %bpl,%bpl
  16eb64:	74 3b                	je     16eba1 <layout_lifetime::main+0x5c1>
  16eb66:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  16eb6b:	e8 20 f2 ff ff       	call   16dd90 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>
  16eb70:	eb 2f                	jmp    16eba1 <layout_lifetime::main+0x5c1>
  16eb72:	48 89 c3             	mov    %rax,%rbx
  16eb75:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  16eb7a:	f0 48 ff 08          	lock decq (%rax)
  16eb7e:	75 0b                	jne    16eb8b <layout_lifetime::main+0x5ab>
  16eb80:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
  16eb85:	ff 15 bd 4b 37 00    	call   *0x374bbd(%rip)        # 4e3748 <_DYNAMIC+0x260>
  16eb8b:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  16eb90:	f0 48 ff 08          	lock decq (%rax)
  16eb94:	75 0b                	jne    16eba1 <layout_lifetime::main+0x5c1>
  16eb96:	48 8d 7c 24 28       	lea    0x28(%rsp),%rdi
  16eb9b:	ff 15 17 4c 37 00    	call   *0x374c17(%rip)        # 4e37b8 <_DYNAMIC+0x2d0>
  16eba1:	48 8b 04 24          	mov    (%rsp),%rax
  16eba5:	f0 48 ff 08          	lock decq (%rax)
  16eba9:	75 09                	jne    16ebb4 <layout_lifetime::main+0x5d4>
  16ebab:	48 89 e7             	mov    %rsp,%rdi
  16ebae:	ff 15 0c 4c 37 00    	call   *0x374c0c(%rip)        # 4e37c0 <_DYNAMIC+0x2d8>
  16ebb4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  16ebb9:	f0 48 ff 08          	lock decq (%rax)
  16ebbd:	75 0b                	jne    16ebca <layout_lifetime::main+0x5ea>
  16ebbf:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
  16ebc4:	ff 15 46 4d 37 00    	call   *0x374d46(%rip)        # 4e3910 <_DYNAMIC+0x428>
  16ebca:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  16ebcf:	f0 48 ff 08          	lock decq (%rax)
  16ebd3:	75 0b                	jne    16ebe0 <layout_lifetime::main+0x600>
  16ebd5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  16ebda:	ff 15 38 4d 37 00    	call   *0x374d38(%rip)        # 4e3918 <_DYNAMIC+0x430>
  16ebe0:	48 89 df             	mov    %rbx,%rdi
  16ebe3:	e8 d8 7d 34 00       	call   4b69c0 <_Unwind_Resume@plt>
  16ebe8:	ff 15 82 4b 37 00    	call   *0x374b82(%rip)        # 4e3770 <_DYNAMIC+0x288>
