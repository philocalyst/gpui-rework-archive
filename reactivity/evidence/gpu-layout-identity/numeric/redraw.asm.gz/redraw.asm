
/tmp/gpui-layout-identity-controls/numeric/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845d90 <<gpui_gpu::renderer::RendererState>::redraw>:
  845d90:	48 89 f8             	mov    %rdi,%rax
  845d93:	4c 8b 86 20 03 00 00 	mov    0x320(%rsi),%r8
  845d9a:	bf 04 00 00 00       	mov    $0x4,%edi
  845d9f:	4c 3b 42 20          	cmp    0x20(%rdx),%r8
  845da3:	0f 85 1e 01 00 00    	jne    845ec7 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  845da9:	48 83 be 30 03 00 00 	cmpq   $0x0,0x330(%rsi)
  845db0:	00 
  845db1:	0f 84 00 01 00 00    	je     845eb7 <<gpui_gpu::renderer::RendererState>::redraw+0x127>
  845db7:	8b be 38 03 00 00    	mov    0x338(%rsi),%edi
  845dbd:	44 8b 86 3c 03 00 00 	mov    0x33c(%rsi),%r8d
  845dc4:	81 e7 ff ff ff 7f    	and    $0x7fffffff,%edi
  845dca:	49 c1 e0 20          	shl    $0x20,%r8
  845dce:	49 09 f8             	or     %rdi,%r8
  845dd1:	bf 03 00 00 00       	mov    $0x3,%edi
  845dd6:	4c 39 41 20          	cmp    %r8,0x20(%rcx)
  845dda:	0f 85 e7 00 00 00    	jne    845ec7 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  845de0:	44 8b 41 38          	mov    0x38(%rcx),%r8d
  845de4:	44 3b 42 28          	cmp    0x28(%rdx),%r8d
  845de8:	0f 85 d9 00 00 00    	jne    845ec7 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  845dee:	41 83 f8 4c          	cmp    $0x4c,%r8d
  845df2:	75 22                	jne    845e16 <<gpui_gpu::renderer::RendererState>::redraw+0x86>
  845df4:	f3 0f 7e 41 3c       	movq   0x3c(%rcx),%xmm0
  845df9:	f3 0f 7e 4a 2c       	movq   0x2c(%rdx),%xmm1
  845dfe:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  845e02:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  845e07:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
  845e0c:	41 83 f8 03          	cmp    $0x3,%r8d
  845e10:	0f 85 b1 00 00 00    	jne    845ec7 <<gpui_gpu::renderer::RendererState>::redraw+0x137>
  845e16:	41 56                	push   %r14
  845e18:	53                   	push   %rbx
  845e19:	50                   	push   %rax
  845e1a:	48 89 c3             	mov    %rax,%rbx
  845e1d:	48 8d 86 30 03 00 00 	lea    0x330(%rsi),%rax
  845e24:	48 89 d7             	mov    %rdx,%rdi
  845e27:	49 89 f6             	mov    %rsi,%r14
  845e2a:	48 89 ce             	mov    %rcx,%rsi
  845e2d:	48 89 c2             	mov    %rax,%rdx
  845e30:	e8 3b f1 ff ff       	call   844f70 <<gpui_gpu::renderer::GpuContext>::submit>
  845e35:	48 89 c1             	mov    %rax,%rcx
  845e38:	49 8b 96 60 01 00 00 	mov    0x160(%r14),%rdx
  845e3f:	49 8b 86 28 03 00 00 	mov    0x328(%r14),%rax
  845e46:	48 ff c2             	inc    %rdx
  845e49:	48 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%rsi
  845e50:	48 0f 45 f2          	cmovne %rdx,%rsi
  845e54:	49 89 b6 60 01 00 00 	mov    %rsi,0x160(%r14)
  845e5b:	41 c6 86 20 02 00 00 	movb   $0x1,0x220(%r14)
  845e62:	01 
  845e63:	49 c7 86 b8 01 00 00 	movq   $0x0,0x1b8(%r14)
  845e6a:	00 00 00 00 
  845e6e:	49 c7 86 e0 01 00 00 	movq   $0x0,0x1e0(%r14)
  845e75:	00 00 00 00 
  845e79:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
  845e7d:	66 41 0f 11 86 68 01 	movupd %xmm0,0x168(%r14)
  845e84:	00 00 
  845e86:	49 c7 86 78 01 00 00 	movq   $0x0,0x178(%r14)
  845e8d:	00 00 00 00 
  845e91:	48 85 c0             	test   %rax,%rax
  845e94:	74 08                	je     845e9e <<gpui_gpu::renderer::RendererState>::redraw+0x10e>
  845e96:	48 c7 40 60 00 00 00 	movq   $0x0,0x60(%rax)
  845e9d:	00 
  845e9e:	48 89 d8             	mov    %rbx,%rax
  845ea1:	48 c7 43 08 01 00 00 	movq   $0x1,0x8(%rbx)
  845ea8:	00 
  845ea9:	ba 10 00 00 00       	mov    $0x10,%edx
  845eae:	48 83 c4 08          	add    $0x8,%rsp
  845eb2:	5b                   	pop    %rbx
  845eb3:	41 5e                	pop    %r14
  845eb5:	eb 07                	jmp    845ebe <<gpui_gpu::renderer::RendererState>::redraw+0x12e>
  845eb7:	ba 08 00 00 00       	mov    $0x8,%edx
  845ebc:	31 c9                	xor    %ecx,%ecx
  845ebe:	48 89 0c 10          	mov    %rcx,(%rax,%rdx,1)
  845ec2:	bf ff ff ff ff       	mov    $0xffffffff,%edi
  845ec7:	89 38                	mov    %edi,(%rax)
  845ec9:	c3                   	ret
