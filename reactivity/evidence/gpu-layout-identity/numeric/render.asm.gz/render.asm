
/tmp/gpui-layout-identity-controls/numeric/owned:     file format elf64-x86-64


Disassembly of section .text:

0000000000845ed0 <<gpui_gpu::renderer::RendererState>::render>:
  845ed0:	55                   	push   %rbp
  845ed1:	41 57                	push   %r15
  845ed3:	41 56                	push   %r14
  845ed5:	41 55                	push   %r13
  845ed7:	41 54                	push   %r12
  845ed9:	53                   	push   %rbx
  845eda:	48 81 ec 68 05 00 00 	sub    $0x568,%rsp
  845ee1:	48 8b 86 20 03 00 00 	mov    0x320(%rsi),%rax
  845ee8:	48 3b 42 20          	cmp    0x20(%rdx),%rax
  845eec:	0f 85 ce 00 00 00    	jne    845fc0 <<gpui_gpu::renderer::RendererState>::render+0xf0>
  845ef2:	48 8d 9e 30 03 00 00 	lea    0x330(%rsi),%rbx
  845ef9:	48 8b 86 30 03 00 00 	mov    0x330(%rsi),%rax
  845f00:	48 85 c0             	test   %rax,%rax
  845f03:	74 2d                	je     845f32 <<gpui_gpu::renderer::RendererState>::render+0x62>
  845f05:	f0 48 ff 08          	lock decq (%rax)
  845f09:	75 27                	jne    845f32 <<gpui_gpu::renderer::RendererState>::render+0x62>
  845f0b:	49 89 fe             	mov    %rdi,%r14
  845f0e:	48 89 df             	mov    %rbx,%rdi
  845f11:	49 89 f4             	mov    %rsi,%r12
  845f14:	4d 89 c5             	mov    %r8,%r13
  845f17:	49 89 d7             	mov    %rdx,%r15
  845f1a:	48 89 cd             	mov    %rcx,%rbp
  845f1d:	ff 15 65 84 67 00    	call   *0x678465(%rip)        # ebe388 <_DYNAMIC+0x490>
  845f23:	48 89 e9             	mov    %rbp,%rcx
  845f26:	4c 89 fa             	mov    %r15,%rdx
  845f29:	4d 89 e8             	mov    %r13,%r8
  845f2c:	4c 89 e6             	mov    %r12,%rsi
  845f2f:	4c 89 f7             	mov    %r14,%rdi
  845f32:	48 c7 86 30 03 00 00 	movq   $0x0,0x330(%rsi)
  845f39:	00 00 00 00 
  845f3d:	44 8b 29             	mov    (%rcx),%r13d
  845f40:	44 8b 49 08          	mov    0x8(%rcx),%r9d
  845f44:	0f b6 41 0d          	movzbl 0xd(%rcx),%eax
  845f48:	45 85 c9             	test   %r9d,%r9d
  845f4b:	41 0f 98 c2          	sets   %r10b
  845f4f:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845f56:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  845f5d:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  845f64:	41 0f 92 c3          	setb   %r11b
  845f68:	45 20 d3             	and    %r10b,%r11b
  845f6b:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  845f6f:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  845f75:	40 0f 92 c5          	setb   %bpl
  845f79:	44 20 d5             	and    %r10b,%bpl
  845f7c:	45 85 c9             	test   %r9d,%r9d
  845f7f:	41 0f 94 c2          	sete   %r10b
  845f83:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  845f8a:	41 0f 94 c6          	sete   %r14b
  845f8e:	45 08 d6             	or     %r10b,%r14b
  845f91:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  845f98:	41 0f 9d c1          	setge  %r9b
  845f9c:	45 08 f1             	or     %r14b,%r9b
  845f9f:	41 08 e9             	or     %bpl,%r9b
  845fa2:	45 85 ed             	test   %r13d,%r13d
  845fa5:	41 0f 95 c2          	setne  %r10b
  845fa9:	41 20 c2             	and    %al,%r10b
  845fac:	45 08 da             	or     %r11b,%r10b
  845faf:	45 08 ca             	or     %r9b,%r10b
  845fb2:	41 f6 c2 01          	test   $0x1,%r10b
  845fb6:	74 23                	je     845fdb <<gpui_gpu::renderer::RendererState>::render+0x10b>
  845fb8:	c7 07 03 00 00 00    	movl   $0x3,(%rdi)
  845fbe:	eb 06                	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  845fc0:	c7 07 04 00 00 00    	movl   $0x4,(%rdi)
  845fc6:	48 89 f8             	mov    %rdi,%rax
  845fc9:	48 81 c4 68 05 00 00 	add    $0x568,%rsp
  845fd0:	5b                   	pop    %rbx
  845fd1:	41 5c                	pop    %r12
  845fd3:	41 5d                	pop    %r13
  845fd5:	41 5e                	pop    %r14
  845fd7:	41 5f                	pop    %r15
  845fd9:	5d                   	pop    %rbp
  845fda:	c3                   	ret
  845fdb:	66 0f 6e 51 04       	movd   0x4(%rcx),%xmm2
  845fe0:	44 0f b6 61 0c       	movzbl 0xc(%rcx),%r12d
  845fe5:	41 f6 c5 01          	test   $0x1,%r13b
  845fe9:	74 75                	je     846060 <<gpui_gpu::renderer::RendererState>::render+0x190>
  845feb:	66 41 0f 7e d1       	movd   %xmm2,%r9d
  845ff0:	45 85 c9             	test   %r9d,%r9d
  845ff3:	41 0f 98 c2          	sets   %r10b
  845ff7:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  845ffe:	45 8d 99 00 00 80 ff 	lea    -0x800000(%r9),%r11d
  846005:	41 81 fb 00 00 00 7f 	cmp    $0x7f000000,%r11d
  84600c:	41 0f 92 c3          	setb   %r11b
  846010:	45 20 d3             	and    %r10b,%r11b
  846013:	41 8d 69 ff          	lea    -0x1(%r9),%ebp
  846017:	81 fd ff ff 7f 00    	cmp    $0x7fffff,%ebp
  84601d:	40 0f 92 c5          	setb   %bpl
  846021:	44 20 d5             	and    %r10b,%bpl
  846024:	45 85 c9             	test   %r9d,%r9d
  846027:	41 0f 94 c2          	sete   %r10b
  84602b:	41 81 f9 00 00 80 7f 	cmp    $0x7f800000,%r9d
  846032:	41 0f 94 c6          	sete   %r14b
  846036:	45 08 d6             	or     %r10b,%r14b
  846039:	41 81 f9 01 00 80 7f 	cmp    $0x7f800001,%r9d
  846040:	41 0f 9d c1          	setge  %r9b
  846044:	45 08 f1             	or     %r14b,%r9b
  846047:	41 08 e9             	or     %bpl,%r9b
  84604a:	45 08 d9             	or     %r11b,%r9b
  84604d:	0f 85 65 ff ff ff    	jne    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846053:	0f 2e 15 9e aa 88 ff 	ucomiss -0x775562(%rip),%xmm2        # d0af8 <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x24>
  84605a:	0f 87 58 ff ff ff    	ja     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846060:	44 8b 71 28          	mov    0x28(%rcx),%r14d
  846064:	45 39 70 20          	cmp    %r14d,0x20(%r8)
  846068:	0f 85 4a ff ff ff    	jne    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  84606e:	44 8b 79 2c          	mov    0x2c(%rcx),%r15d
  846072:	45 39 78 24          	cmp    %r15d,0x24(%r8)
  846076:	0f 85 3c ff ff ff    	jne    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  84607c:	41 8b 68 38          	mov    0x38(%r8),%ebp
  846080:	3b 6a 28             	cmp    0x28(%rdx),%ebp
  846083:	0f 85 2f ff ff ff    	jne    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846089:	83 fd 4c             	cmp    $0x4c,%ebp
  84608c:	75 23                	jne    8460b1 <<gpui_gpu::renderer::RendererState>::render+0x1e1>
  84608e:	f3 41 0f 7e 40 3c    	movq   0x3c(%r8),%xmm0
  846094:	f3 0f 7e 4a 2c       	movq   0x2c(%rdx),%xmm1
  846099:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
  84609d:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
  8460a2:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
  8460a7:	41 83 f9 03          	cmp    $0x3,%r9d
  8460ab:	0f 85 07 ff ff ff    	jne    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  8460b1:	41 81 ff 00 40 00 00 	cmp    $0x4000,%r15d
  8460b8:	77 34                	ja     8460ee <<gpui_gpu::renderer::RendererState>::render+0x21e>
  8460ba:	41 81 fe 00 40 00 00 	cmp    $0x4000,%r14d
  8460c1:	77 2b                	ja     8460ee <<gpui_gpu::renderer::RendererState>::render+0x21e>
  8460c3:	4d 89 f9             	mov    %r15,%r9
  8460c6:	4d 0f af ce          	imul   %r14,%r9
  8460ca:	49 81 c1 ff ff ff fe 	add    $0xfffffffffeffffff,%r9
  8460d1:	49 81 f9 00 00 00 ff 	cmp    $0xffffffffff000000,%r9
  8460d8:	72 14                	jb     8460ee <<gpui_gpu::renderer::RendererState>::render+0x21e>
  8460da:	4c 8b 59 10          	mov    0x10(%rcx),%r11
  8460de:	4d 8b 93 80 00 00 00 	mov    0x80(%r11),%r10
  8460e5:	49 81 fa 00 00 01 00 	cmp    $0x10000,%r10
  8460ec:	76 0b                	jbe    8460f9 <<gpui_gpu::renderer::RendererState>::render+0x229>
  8460ee:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  8460f4:	e9 cd fe ff ff       	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  8460f9:	66 0f 6e 41 18       	movd   0x18(%rcx),%xmm0
  8460fe:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846103:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  84610a:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846111:	0f 8f a1 fe ff ff    	jg     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846117:	66 0f db 05 71 db 88 	pand   -0x77248f(%rip),%xmm0        # d3c90 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x4c0>
  84611e:	ff 
  84611f:	0f 2e 05 2a ac 88 ff 	ucomiss -0x7753d6(%rip),%xmm0        # d0d50 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846126:	0f 87 8c fe ff ff    	ja     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  84612c:	66 0f 6e 41 1c       	movd   0x1c(%rcx),%xmm0
  846131:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846136:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  84613d:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846144:	0f 8f 6e fe ff ff    	jg     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  84614a:	66 0f db 05 3e db 88 	pand   -0x7724c2(%rip),%xmm0        # d3c90 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x4c0>
  846151:	ff 
  846152:	0f 2e 05 f7 ab 88 ff 	ucomiss -0x775409(%rip),%xmm0        # d0d50 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  846159:	0f 87 59 fe ff ff    	ja     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  84615f:	66 0f 6e 41 20       	movd   0x20(%rcx),%xmm0
  846164:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  846169:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  846170:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  846177:	0f 8f 3b fe ff ff    	jg     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  84617d:	66 0f db 05 0b db 88 	pand   -0x7724f5(%rip),%xmm0        # d3c90 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x4c0>
  846184:	ff 
  846185:	0f 2e 05 c4 ab 88 ff 	ucomiss -0x77543c(%rip),%xmm0        # d0d50 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  84618c:	0f 87 26 fe ff ff    	ja     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846192:	66 0f 6e 41 24       	movd   0x24(%rcx),%xmm0
  846197:	66 41 0f 7e c1       	movd   %xmm0,%r9d
  84619c:	41 81 e1 ff ff ff 7f 	and    $0x7fffffff,%r9d
  8461a3:	41 81 f9 ff ff 7f 7f 	cmp    $0x7f7fffff,%r9d
  8461aa:	0f 8f 08 fe ff ff    	jg     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  8461b0:	66 0f 6f 0d d8 da 88 	movdqa -0x772528(%rip),%xmm1        # d3c90 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x4c0>
  8461b7:	ff 
  8461b8:	66 0f db c8          	pand   %xmm0,%xmm1
  8461bc:	0f 2e 0d 8d ab 88 ff 	ucomiss -0x775473(%rip),%xmm1        # d0d50 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x28>
  8461c3:	0f 87 ef fd ff ff    	ja     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  8461c9:	0f 57 c9             	xorps  %xmm1,%xmm1
  8461cc:	0f 2e c1             	ucomiss %xmm1,%xmm0
  8461cf:	0f 82 e3 fd ff ff    	jb     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  8461d5:	f3 0f 10 0d ef a7 88 	movss  -0x775811(%rip),%xmm1        # d09cc <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  8461dc:	ff 
  8461dd:	0f 2e c8             	ucomiss %xmm0,%xmm1
  8461e0:	0f 82 d2 fd ff ff    	jb     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  8461e6:	44 0f b7 49 30       	movzwl 0x30(%rcx),%r9d
  8461eb:	66 44 89 4c 24 10    	mov    %r9w,0x10(%rsp)
  8461f1:	44 0f b7 49 32       	movzwl 0x32(%rcx),%r9d
  8461f6:	66 44 89 4c 24 18    	mov    %r9w,0x18(%rsp)
  8461fc:	83 fd 28             	cmp    $0x28,%ebp
  8461ff:	75 09                	jne    84620a <<gpui_gpu::renderer::RendererState>::render+0x33a>
  846201:	a8 01                	test   $0x1,%al
  846203:	75 20                	jne    846225 <<gpui_gpu::renderer::RendererState>::render+0x355>
  846205:	e9 ae fd ff ff       	jmp    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  84620a:	a8 01                	test   $0x1,%al
  84620c:	0f 85 a6 fd ff ff    	jne    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846212:	0f 2e 05 b3 a7 88 ff 	ucomiss -0x77584d(%rip),%xmm0        # d09cc <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x10>
  846219:	0f 85 99 fd ff ff    	jne    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  84621f:	0f 8a 93 fd ff ff    	jp     845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  846225:	4c 89 9c 24 b8 00 00 	mov    %r11,0xb8(%rsp)
  84622c:	00 
  84622d:	4c 89 94 24 b0 00 00 	mov    %r10,0xb0(%rsp)
  846234:	00 
  846235:	f3 0f 11 8c 24 ec 00 	movss  %xmm1,0xec(%rsp)
  84623c:	00 00 
  84623e:	66 0f 7e 94 24 5c 01 	movd   %xmm2,0x15c(%rsp)
  846245:	00 00 
  846247:	48 89 94 24 50 01 00 	mov    %rdx,0x150(%rsp)
  84624e:	00 
  84624f:	4c 89 84 24 00 04 00 	mov    %r8,0x400(%rsp)
  846256:	00 
  846257:	48 89 7c 24 40       	mov    %rdi,0x40(%rsp)
  84625c:	49 8d 46 0f          	lea    0xf(%r14),%rax
  846260:	48 c1 e8 04          	shr    $0x4,%rax
  846264:	41 8d 57 0f          	lea    0xf(%r15),%edx
  846268:	c1 ea 04             	shr    $0x4,%edx
  84626b:	48 8d 7e 18          	lea    0x18(%rsi),%rdi
  84626f:	48 c7 46 28 00 00 00 	movq   $0x0,0x28(%rsi)
  846276:	00 
  846277:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  84627c:	0f af d0             	imul   %eax,%edx
  84627f:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  846286:	00 
  846287:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
  84628c:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
  846291:	48 89 d6             	mov    %rdx,%rsi
  846294:	31 d2                	xor    %edx,%edx
  846296:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  84629d:	00 
  84629e:	e8 9d 43 00 00       	call   84a640 <<alloc::vec::Vec<[u32; 2]>>::resize>
  8462a3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8462a8:	48 c7 40 10 00 00 00 	movq   $0x0,0x10(%rax)
  8462af:	00 
  8462b0:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
  8462b7:	00 
  8462b8:	ff 15 42 84 67 00    	call   *0x678442(%rip)        # ebe700 <_DYNAMIC+0x808>
  8462be:	48 89 d1             	mov    %rdx,%rcx
  8462c1:	48 29 c1             	sub    %rax,%rcx
  8462c4:	48 81 f9 00 00 30 00 	cmp    $0x300000,%rcx
  8462cb:	76 10                	jbe    8462dd <<gpui_gpu::renderer::RendererState>::render+0x40d>
  8462cd:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  8462d2:	c7 07 06 00 00 00    	movl   $0x6,(%rdi)
  8462d8:	e9 e9 fc ff ff       	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  8462dd:	48 89 ce             	mov    %rcx,%rsi
  8462e0:	48 c1 e9 03          	shr    $0x3,%rcx
  8462e4:	48 bf ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rdi
  8462eb:	aa aa aa 
  8462ee:	48 0f af f9          	imul   %rcx,%rdi
  8462f2:	48 89 7c 24 30       	mov    %rdi,0x30(%rsp)
  8462f7:	48 89 84 24 b8 03 00 	mov    %rax,0x3b8(%rsp)
  8462fe:	00 
  8462ff:	48 89 94 24 b0 03 00 	mov    %rdx,0x3b0(%rsp)
  846306:	00 
  846307:	48 39 c2             	cmp    %rax,%rdx
  84630a:	74 2f                	je     84633b <<gpui_gpu::renderer::RendererState>::render+0x46b>
  84630c:	b8 ab aa aa aa       	mov    $0xaaaaaaab,%eax
  846311:	48 0f af f0          	imul   %rax,%rsi
  846315:	48 c1 ee 2a          	shr    $0x2a,%rsi
  846319:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  84631e:	89 c8                	mov    %ecx,%eax
  846320:	83 e0 3f             	and    $0x3f,%eax
  846323:	48 01 ce             	add    %rcx,%rsi
  846326:	48 83 f8 01          	cmp    $0x1,%rax
  84632a:	48 83 de ff          	sbb    $0xffffffffffffffff,%rsi
  84632e:	48 ff c6             	inc    %rsi
  846331:	48 89 b4 24 e0 00 00 	mov    %rsi,0xe0(%rsp)
  846338:	00 
  846339:	eb 0c                	jmp    846347 <<gpui_gpu::renderer::RendererState>::render+0x477>
  84633b:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
  846342:	00 00 00 00 00 
  846347:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  84634e:	00 
  84634f:	48 8b 88 98 00 00 00 	mov    0x98(%rax),%rcx
  846356:	48 03 88 b0 00 00 00 	add    0xb0(%rax),%rcx
  84635d:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846364:	00 
  846365:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  84636a:	66 89 84 24 80 01 00 	mov    %ax,0x180(%rsp)
  846371:	00 
  846372:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  846377:	66 89 84 24 82 01 00 	mov    %ax,0x182(%rsp)
  84637e:	00 
  84637f:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
  846386:	00 00 00 00 00 
  84638b:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  846392:	00 
  846393:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  84639a:	00 
  84639b:	48 89 8c 24 48 01 00 	mov    %rcx,0x148(%rsp)
  8463a2:	00 
  8463a3:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
  8463aa:	00 
  8463ab:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8463b0:	0f b6 90 41 03 00 00 	movzbl 0x341(%rax),%edx
  8463b7:	48 8d bc 24 48 04 00 	lea    0x448(%rsp),%rdi
  8463be:	00 
  8463bf:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  8463c6:	00 
  8463c7:	e8 74 e1 ff ff       	call   844540 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  8463cc:	8b 84 24 48 04 00 00 	mov    0x448(%rsp),%eax
  8463d3:	83 f8 ff             	cmp    $0xffffffff,%eax
  8463d6:	74 2e                	je     846406 <<gpui_gpu::renderer::RendererState>::render+0x536>
  8463d8:	8b 8c 24 4c 04 00 00 	mov    0x44c(%rsp),%ecx
  8463df:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  8463e6:	00 
  8463e7:	0f 10 84 24 58 04 00 	movups 0x458(%rsp),%xmm0
  8463ee:	00 
  8463ef:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  8463f4:	0f 11 47 10          	movups %xmm0,0x10(%rdi)
  8463f8:	89 07                	mov    %eax,(%rdi)
  8463fa:	89 4f 04             	mov    %ecx,0x4(%rdi)
  8463fd:	48 89 57 08          	mov    %rdx,0x8(%rdi)
  846401:	e9 c0 fb ff ff       	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  846406:	48 8b 94 24 50 04 00 	mov    0x450(%rsp),%rdx
  84640d:	00 
  84640e:	48 03 94 24 e0 00 00 	add    0xe0(%rsp),%rdx
  846415:	00 
  846416:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  84641b:	48 8b 77 10          	mov    0x10(%rdi),%rsi
  84641f:	b9 04 00 00 00       	mov    $0x4,%ecx
  846424:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  84642a:	e8 d1 55 00 00       	call   84ba00 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  84642f:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  846433:	0f 85 94 fe ff ff    	jne    8462cd <<gpui_gpu::renderer::RendererState>::render+0x3fd>
  846439:	0f b7 44 24 10       	movzwl 0x10(%rsp),%eax
  84643e:	89 44 24 10          	mov    %eax,0x10(%rsp)
  846442:	0f b7 44 24 18       	movzwl 0x18(%rsp),%eax
  846447:	89 44 24 78          	mov    %eax,0x78(%rsp)
  84644b:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846450:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  846457:	00 
  846458:	48 8b 54 24 30       	mov    0x30(%rsp),%rdx
  84645d:	e8 fe 74 00 00       	call   84d960 <gpui_gpu::renderer::slots::write_prefix>
  846462:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846467:	48 8d 78 48          	lea    0x48(%rax),%rdi
  84646b:	48 c7 40 58 00 00 00 	movq   $0x0,0x58(%rax)
  846472:	00 
  846473:	48 89 bc 24 08 04 00 	mov    %rdi,0x408(%rsp)
  84647a:	00 
  84647b:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  846480:	31 d2                	xor    %edx,%edx
  846482:	e8 d9 42 00 00       	call   84a760 <<alloc::vec::Vec<u32>>::resize>
  846487:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84648c:	48 c7 40 70 00 00 00 	movq   $0x0,0x70(%rax)
  846493:	00 
  846494:	48 83 78 60 00       	cmpq   $0x0,0x60(%rax)
  846499:	75 0f                	jne    8464aa <<gpui_gpu::renderer::RendererState>::render+0x5da>
  84649b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8464a0:	48 8d 78 60          	lea    0x60(%rax),%rdi
  8464a4:	ff 15 5e 82 67 00    	call   *0x67825e(%rip)        # ebe708 <_DYNAMIC+0x810>
  8464aa:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8464af:	48 8b 48 68          	mov    0x68(%rax),%rcx
  8464b3:	0f 57 c0             	xorps  %xmm0,%xmm0
  8464b6:	0f 11 41 10          	movups %xmm0,0x10(%rcx)
  8464ba:	0f 11 01             	movups %xmm0,(%rcx)
  8464bd:	48 c7 40 70 01 00 00 	movq   $0x1,0x70(%rax)
  8464c4:	00 
  8464c5:	48 8d b8 f0 02 00 00 	lea    0x2f0(%rax),%rdi
  8464cc:	e8 3f 6e 00 00       	call   84d310 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  8464d1:	8b 4c 24 78          	mov    0x78(%rsp),%ecx
  8464d5:	c1 e1 10             	shl    $0x10,%ecx
  8464d8:	03 4c 24 10          	add    0x10(%rsp),%ecx
  8464dc:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  8464e3:	00 
  8464e4:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  8464eb:	00 
  8464ec:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  8464f3:	00 00 00 00 00 
  8464f8:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  8464ff:	00 
  846500:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  846507:	00 
  846508:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  84650f:	00 
  846510:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  846517:	00 
  846518:	89 4c 24 78          	mov    %ecx,0x78(%rsp)
  84651c:	89 8c 24 08 03 00 00 	mov    %ecx,0x308(%rsp)
  846523:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  84652a:	00 
  84652b:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  846532:	00 
  846533:	ff 15 d7 81 67 00    	call   *0x6781d7(%rip)        # ebe710 <_DYNAMIC+0x818>
  846539:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  846540:	00 
  846541:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  846546:	48 85 c0             	test   %rax,%rax
  846549:	0f 84 31 0d 00 00    	je     847280 <<gpui_gpu::renderer::RendererState>::render+0x13b0>
  84654f:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  846556:	00 00 00 00 00 
  84655b:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  846562:	00 00 
  846564:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  84656b:	00 00 
  84656d:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  846574:	00 00 00 00 00 
  846579:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  846580:	00 00 00 00 00 
  846585:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  84658c:	00 
  84658d:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  846594:	00 
  846595:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
  84659c:	00 
  84659d:	48 8d bc 24 70 02 00 	lea    0x270(%rsp),%rdi
  8465a4:	00 
  8465a5:	0f 10 07             	movups (%rdi),%xmm0
  8465a8:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  8465ac:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  8465b0:	0f 29 94 24 30 03 00 	movaps %xmm2,0x330(%rsp)
  8465b7:	00 
  8465b8:	0f 29 8c 24 20 03 00 	movaps %xmm1,0x320(%rsp)
  8465bf:	00 
  8465c0:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
  8465c7:	00 
  8465c8:	4c 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%r8
  8465cf:	00 
  8465d0:	41 0f 10 00          	movups (%r8),%xmm0
  8465d4:	0f 29 84 24 10 05 00 	movaps %xmm0,0x510(%rsp)
  8465db:	00 
  8465dc:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  8465e0:	0f 29 84 24 30 04 00 	movaps %xmm0,0x430(%rsp)
  8465e7:	00 
  8465e8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8465ed:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  8465f4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  8465f9:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846600:	00 
  846601:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  846606:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  84660d:	00 
  84660e:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
  846615:	00 
  846616:	0f 10 07             	movups (%rdi),%xmm0
  846619:	0f 10 4f 10          	movups 0x10(%rdi),%xmm1
  84661d:	0f 10 57 20          	movups 0x20(%rdi),%xmm2
  846621:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  846628:	00 
  846629:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  84662d:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  846631:	0f 11 00             	movups %xmm0,(%rax)
  846634:	41 0f 10 00          	movups (%r8),%xmm0
  846638:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  84663c:	0f 10 47 40          	movups 0x40(%rdi),%xmm0
  846640:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  846644:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84664b:	00 
  84664c:	e8 4f 2d 00 00       	call   8493a0 <gpui_gpu::renderer::compact_group>
  846651:	88 44 24 60          	mov    %al,0x60(%rsp)
  846655:	48 8d b4 24 70 02 00 	lea    0x270(%rsp),%rsi
  84665c:	00 
  84665d:	0f 10 06             	movups (%rsi),%xmm0
  846660:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  846664:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  846668:	0f 29 84 24 20 05 00 	movaps %xmm0,0x520(%rsp)
  84666f:	00 
  846670:	0f 29 8c 24 30 05 00 	movaps %xmm1,0x530(%rsp)
  846677:	00 
  846678:	0f 29 94 24 40 05 00 	movaps %xmm2,0x540(%rsp)
  84667f:	00 
  846680:	48 8d 94 24 a0 02 00 	lea    0x2a0(%rsp),%rdx
  846687:	00 
  846688:	0f 10 02             	movups (%rdx),%xmm0
  84668b:	0f 29 84 24 50 05 00 	movaps %xmm0,0x550(%rsp)
  846692:	00 
  846693:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846698:	e8 b3 ea ff ff       	call   845150 <<gpui_gpu::renderer::RendererState>::correction>
  84669d:	89 44 24 7c          	mov    %eax,0x7c(%rsp)
  8466a1:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  8466a8:	00 
  8466a9:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  8466b0:	00 
  8466b1:	48 89 84 24 e0 03 00 	mov    %rax,0x3e0(%rsp)
  8466b8:	00 
  8466b9:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
  8466be:	0f 84 d5 01 00 00    	je     846899 <<gpui_gpu::renderer::RendererState>::render+0x9c9>
  8466c4:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  8466c9:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  8466d0:	00 
  8466d1:	48 8d 04 81          	lea    (%rcx,%rax,4),%rax
  8466d5:	48 89 8c 24 10 04 00 	mov    %rcx,0x410(%rsp)
  8466dc:	00 
  8466dd:	48 89 84 24 18 04 00 	mov    %rax,0x418(%rsp)
  8466e4:	00 
  8466e5:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  8466ea:	48 89 84 24 20 04 00 	mov    %rax,0x420(%rsp)
  8466f1:	00 
  8466f2:	48 c7 84 24 28 04 00 	movq   $0x0,0x428(%rsp)
  8466f9:	00 00 00 00 00 
  8466fe:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  846705:	00 
  846706:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  84670d:	00 
  84670e:	e8 1d 33 00 00       	call   849a30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  846713:	80 bc 24 48 03 00 00 	cmpb   $0xff,0x348(%rsp)
  84671a:	ff 
  84671b:	0f 84 b1 06 00 00    	je     846dd2 <<gpui_gpu::renderer::RendererState>::render+0xf02>
  846721:	0f 57 c0             	xorps  %xmm0,%xmm0
  846724:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  84672b:	00 
  84672c:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  846731:	48 8b 94 24 40 03 00 	mov    0x340(%rsp),%rdx
  846738:	00 
  846739:	48 03 54 24 48       	add    0x48(%rsp),%rdx
  84673e:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
  846745:	00 
  846746:	0f 10 46 38          	movups 0x38(%rsi),%xmm0
  84674a:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  846751:	00 
  846752:	0f 11 41 20          	movups %xmm0,0x20(%rcx)
  846756:	0f 10 46 48          	movups 0x48(%rsi),%xmm0
  84675a:	0f 11 41 70          	movups %xmm0,0x70(%rcx)
  84675e:	48 8b 46 30          	mov    0x30(%rsi),%rax
  846762:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  846769:	00 
  84676a:	0f 10 06             	movups (%rsi),%xmm0
  84676d:	0f 10 4e 10          	movups 0x10(%rsi),%xmm1
  846771:	0f 10 56 20          	movups 0x20(%rsi),%xmm2
  846775:	0f 29 94 24 80 01 00 	movaps %xmm2,0x180(%rsp)
  84677c:	00 
  84677d:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  846784:	00 
  846785:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  84678c:	00 
  84678d:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  846794:	00 
  846795:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  846799:	0f 11 81 80 00 00 00 	movups %xmm0,0x80(%rcx)
  8467a0:	0f 10 00             	movups (%rax),%xmm0
  8467a3:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  8467a7:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  8467ab:	0f 11 51 50          	movups %xmm2,0x50(%rcx)
  8467af:	0f 11 49 40          	movups %xmm1,0x40(%rcx)
  8467b3:	0f 11 41 30          	movups %xmm0,0x30(%rcx)
  8467b7:	48 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%rax
  8467be:	00 
  8467bf:	0f 10 00             	movups (%rax),%xmm0
  8467c2:	0f 11 41 60          	movups %xmm0,0x60(%rcx)
  8467c6:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  8467cd:	00 
  8467ce:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  8467d5:	00 
  8467d6:	44 89 f1             	mov    %r14d,%ecx
  8467d9:	45 89 f8             	mov    %r15d,%r8d
  8467dc:	e8 0f 2c 00 00       	call   8493f0 <gpui_gpu::renderer::validate_draw>
  8467e1:	8b 8c 24 00 01 00 00 	mov    0x100(%rsp),%ecx
  8467e8:	48 8b 84 24 04 01 00 	mov    0x104(%rsp),%rax
  8467ef:	00 
  8467f0:	83 f9 ff             	cmp    $0xffffffff,%ecx
  8467f3:	0f 85 3f 0b 00 00    	jne    847338 <<gpui_gpu::renderer::RendererState>::render+0x1468>
  8467f9:	89 c1                	mov    %eax,%ecx
  8467fb:	48 c1 e8 20          	shr    $0x20,%rax
  8467ff:	66 0f 6e c1          	movd   %ecx,%xmm0
  846803:	0f 28 94 24 c0 00 00 	movaps 0xc0(%rsp),%xmm2
  84680a:	00 
  84680b:	0f 28 ca             	movaps %xmm2,%xmm1
  84680e:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  846812:	0f 28 d9             	movaps %xmm1,%xmm3
  846815:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  84681a:	0f 28 c3             	movaps %xmm3,%xmm0
  84681d:	0f 55 c1             	andnps %xmm1,%xmm0
  846820:	0f 54 da             	andps  %xmm2,%xmm3
  846823:	0f 56 d8             	orps   %xmm0,%xmm3
  846826:	0f 29 5c 24 60       	movaps %xmm3,0x60(%rsp)
  84682b:	66 0f 6e c0          	movd   %eax,%xmm0
  84682f:	0f 28 54 24 50       	movaps 0x50(%rsp),%xmm2
  846834:	0f 28 ca             	movaps %xmm2,%xmm1
  846837:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
  84683b:	0f 28 d9             	movaps %xmm1,%xmm3
  84683e:	f3 0f c2 d9 03       	cmpunordss %xmm1,%xmm3
  846843:	0f 28 c3             	movaps %xmm3,%xmm0
  846846:	0f 55 c1             	andnps %xmm1,%xmm0
  846849:	0f 54 da             	andps  %xmm2,%xmm3
  84684c:	0f 56 d8             	orps   %xmm0,%xmm3
  84684f:	0f 29 9c 24 80 00 00 	movaps %xmm3,0x80(%rsp)
  846856:	00 
  846857:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  84685e:	00 
  84685f:	48 8d b4 24 10 04 00 	lea    0x410(%rsp),%rsi
  846866:	00 
  846867:	e8 c4 31 00 00       	call   849a30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  84686c:	80 bc 24 48 03 00 00 	cmpb   $0xff,0x348(%rsp)
  846873:	ff 
  846874:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  846879:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  846880:	00 
  846881:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  846888:	00 
  846889:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  84688e:	0f 85 9d fe ff ff    	jne    846731 <<gpui_gpu::renderer::RendererState>::render+0x861>
  846894:	e9 49 05 00 00       	jmp    846de2 <<gpui_gpu::renderer::RendererState>::render+0xf12>
  846899:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
  8468a0:	00 00 
  8468a2:	0f 84 82 09 00 00    	je     84722a <<gpui_gpu::renderer::RendererState>::render+0x135a>
  8468a8:	8b 44 24 7c          	mov    0x7c(%rsp),%eax
  8468ac:	0d 00 00 00 80       	or     $0x80000000,%eax
  8468b1:	89 84 24 58 01 00 00 	mov    %eax,0x158(%rsp)
  8468b8:	48 c7 84 24 80 00 00 	movq   $0x0,0x80(%rsp)
  8468bf:	00 00 00 00 00 
  8468c4:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  8468c9:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  8468d0:	00 
  8468d1:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  8468d4:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8468db:	00 
  8468dc:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  8468e1:	e8 aa dd ff ff       	call   844690 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8468e6:	0f b6 bc 24 60 01 00 	movzbl 0x160(%rsp),%edi
  8468ed:	00 
  8468ee:	48 8d 94 24 61 01 00 	lea    0x161(%rsp),%rdx
  8468f5:	00 
  8468f6:	8b 02                	mov    (%rdx),%eax
  8468f8:	8b 4a 03             	mov    0x3(%rdx),%ecx
  8468fb:	48 8d b4 24 80 04 00 	lea    0x480(%rsp),%rsi
  846902:	00 
  846903:	89 4e cc             	mov    %ecx,-0x34(%rsi)
  846906:	89 46 c9             	mov    %eax,-0x37(%rsi)
  846909:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
  846910:	00 
  846911:	48 8b 42 2f          	mov    0x2f(%rdx),%rax
  846915:	48 89 46 f8          	mov    %rax,-0x8(%rsi)
  846919:	0f 10 42 0f          	movups 0xf(%rdx),%xmm0
  84691d:	0f 10 4a 1f          	movups 0x1f(%rdx),%xmm1
  846921:	0f 11 4e e8          	movups %xmm1,-0x18(%rsi)
  846925:	0f 11 46 d8          	movups %xmm0,-0x28(%rsi)
  846929:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  846930:	00 
  846931:	0f 10 40 20          	movups 0x20(%rax),%xmm0
  846935:	0f 11 06             	movups %xmm0,(%rsi)
  846938:	0f 10 40 30          	movups 0x30(%rax),%xmm0
  84693c:	0f 11 46 50          	movups %xmm0,0x50(%rsi)
  846940:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  846947:	00 
  846948:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  84694c:	0f 11 46 60          	movups %xmm0,0x60(%rsi)
  846950:	0f 10 00             	movups (%rax),%xmm0
  846953:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  846957:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  84695b:	0f 11 56 30          	movups %xmm2,0x30(%rsi)
  84695f:	0f 11 4e 20          	movups %xmm1,0x20(%rsi)
  846963:	0f 11 46 10          	movups %xmm0,0x10(%rsi)
  846967:	48 8d 84 24 a0 02 00 	lea    0x2a0(%rsp),%rax
  84696e:	00 
  84696f:	0f 10 00             	movups (%rax),%xmm0
  846972:	0f 11 46 40          	movups %xmm0,0x40(%rsi)
  846976:	40 88 7c 24 50       	mov    %dil,0x50(%rsp)
  84697b:	40 88 bc 24 48 04 00 	mov    %dil,0x448(%rsp)
  846982:	00 
  846983:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  84698a:	00 
  84698b:	48 89 8c 24 50 04 00 	mov    %rcx,0x450(%rsp)
  846992:	00 
  846993:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84699a:	00 
  84699b:	48 8d b4 24 48 04 00 	lea    0x448(%rsp),%rsi
  8469a2:	00 
  8469a3:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
  8469a8:	44 89 f1             	mov    %r14d,%ecx
  8469ab:	45 89 f8             	mov    %r15d,%r8d
  8469ae:	e8 3d 2a 00 00       	call   8493f0 <gpui_gpu::renderer::validate_draw>
  8469b3:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  8469ba:	48 8b 8c 24 64 01 00 	mov    0x164(%rsp),%rcx
  8469c1:	00 
  8469c2:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  8469c7:	83 f8 ff             	cmp    $0xffffffff,%eax
  8469ca:	0f 85 fe 09 00 00    	jne    8473ce <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  8469d0:	0f b6 44 24 50       	movzbl 0x50(%rsp),%eax
  8469d5:	3c 02                	cmp    $0x2,%al
  8469d7:	0f 94 44 24 2f       	sete   0x2f(%rsp)
  8469dc:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  8469e3:	00 00 
  8469e5:	0f 95 44 24 2e       	setne  0x2e(%rsp)
  8469ea:	0f 10 84 24 80 04 00 	movups 0x480(%rsp),%xmm0
  8469f1:	00 
  8469f2:	0f 29 84 24 d0 02 00 	movaps %xmm0,0x2d0(%rsp)
  8469f9:	00 
  8469fa:	3c 03                	cmp    $0x3,%al
  8469fc:	0f 85 8c 00 00 00    	jne    846a8e <<gpui_gpu::renderer::RendererState>::render+0xbbe>
  846a02:	f3 0f 10 84 24 4c 04 	movss  0x44c(%rsp),%xmm0
  846a09:	00 00 
  846a0b:	0f 57 c9             	xorps  %xmm1,%xmm1
  846a0e:	0f 2e c1             	ucomiss %xmm1,%xmm0
  846a11:	75 02                	jne    846a15 <<gpui_gpu::renderer::RendererState>::render+0xb45>
  846a13:	7b 79                	jnp    846a8e <<gpui_gpu::renderer::RendererState>::render+0xbbe>
  846a15:	0f 28 ac 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm5
  846a1c:	00 
  846a1d:	0f 28 cd             	movaps %xmm5,%xmm1
  846a20:	66 0f 15 cd          	unpckhpd %xmm5,%xmm1
  846a24:	f3 0f 10 25 88 a1 88 	movss  -0x775e78(%rip),%xmm4        # d0bb4 <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  846a2b:	ff 
  846a2c:	f3 0f 59 cc          	mulss  %xmm4,%xmm1
  846a30:	0f 28 d0             	movaps %xmm0,%xmm2
  846a33:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  846a37:	0f 28 ca             	movaps %xmm2,%xmm1
  846a3a:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  846a3f:	0f 28 d9             	movaps %xmm1,%xmm3
  846a42:	0f 55 da             	andnps %xmm2,%xmm3
  846a45:	0f 54 c8             	andps  %xmm0,%xmm1
  846a48:	0f 56 cb             	orps   %xmm3,%xmm1
  846a4b:	0f 28 c5             	movaps %xmm5,%xmm0
  846a4e:	0f c6 c5 ff          	shufps $0xff,%xmm5,%xmm0
  846a52:	f3 0f 59 c4          	mulss  %xmm4,%xmm0
  846a56:	0f 28 d1             	movaps %xmm1,%xmm2
  846a59:	f3 0f 5d d0          	minss  %xmm0,%xmm2
  846a5d:	0f 28 c2             	movaps %xmm2,%xmm0
  846a60:	f3 0f c2 c2 03       	cmpunordss %xmm2,%xmm0
  846a65:	0f 54 c8             	andps  %xmm0,%xmm1
  846a68:	0f 55 c2             	andnps %xmm2,%xmm0
  846a6b:	0f 56 c1             	orps   %xmm1,%xmm0
  846a6e:	66 0f 7e c0          	movd   %xmm0,%eax
  846a72:	89 44 24 50          	mov    %eax,0x50(%rsp)
  846a76:	25 00 00 80 ff       	and    $0xff800000,%eax
  846a7b:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  846a80:	29 c1                	sub    %eax,%ecx
  846a82:	89 8c 24 c0 00 00 00 	mov    %ecx,0xc0(%rsp)
  846a89:	0f 57 c0             	xorps  %xmm0,%xmm0
  846a8c:	eb 22                	jmp    846ab0 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  846a8e:	8b 84 24 e0 04 00 00 	mov    0x4e0(%rsp),%eax
  846a95:	89 44 24 50          	mov    %eax,0x50(%rsp)
  846a99:	8b 84 24 e4 04 00 00 	mov    0x4e4(%rsp),%eax
  846aa0:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
  846aa7:	f2 0f 10 84 24 e8 04 	movsd  0x4e8(%rsp),%xmm0
  846aae:	00 00 
  846ab0:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  846ab7:	00 
  846ab8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846abd:	8b 48 10             	mov    0x10(%rax),%ecx
  846ac0:	b8 00 00 00 80       	mov    $0x80000000,%eax
  846ac5:	09 c1                	or     %eax,%ecx
  846ac7:	89 8c 24 a0 03 00 00 	mov    %ecx,0x3a0(%rsp)
  846ace:	0f 10 84 24 90 04 00 	movups 0x490(%rsp),%xmm0
  846ad5:	00 
  846ad6:	0f 29 84 24 d0 03 00 	movaps %xmm0,0x3d0(%rsp)
  846add:	00 
  846ade:	0f 10 84 24 98 04 00 	movups 0x498(%rsp),%xmm0
  846ae5:	00 
  846ae6:	0f 29 84 24 00 05 00 	movaps %xmm0,0x500(%rsp)
  846aed:	00 
  846aee:	f2 0f 10 84 24 a0 04 	movsd  0x4a0(%rsp),%xmm0
  846af5:	00 00 
  846af7:	0f 29 84 24 c0 03 00 	movaps %xmm0,0x3c0(%rsp)
  846afe:	00 
  846aff:	f2 0f 10 84 24 a8 04 	movsd  0x4a8(%rsp),%xmm0
  846b06:	00 00 
  846b08:	0f 29 84 24 f0 04 00 	movaps %xmm0,0x4f0(%rsp)
  846b0f:	00 
  846b10:	f2 0f 10 84 24 b0 04 	movsd  0x4b0(%rsp),%xmm0
  846b17:	00 00 
  846b19:	f2 0f 11 84 24 f8 03 	movsd  %xmm0,0x3f8(%rsp)
  846b20:	00 00 
  846b22:	f2 0f 10 84 24 b8 04 	movsd  0x4b8(%rsp),%xmm0
  846b29:	00 00 
  846b2b:	f2 0f 11 84 24 f0 03 	movsd  %xmm0,0x3f0(%rsp)
  846b32:	00 00 
  846b34:	0f 10 84 24 c0 04 00 	movups 0x4c0(%rsp),%xmm0
  846b3b:	00 
  846b3c:	0f 29 84 24 c0 02 00 	movaps %xmm0,0x2c0(%rsp)
  846b43:	00 
  846b44:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846b49:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846b50:	00 
  846b51:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846b56:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  846b5d:	00 
  846b5e:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846b65:	00 
  846b66:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  846b6d:	00 
  846b6e:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
  846b75:	00 
  846b76:	0f 28 8c 24 20 03 00 	movaps 0x320(%rsp),%xmm1
  846b7d:	00 
  846b7e:	0f 28 94 24 30 03 00 	movaps 0x330(%rsp),%xmm2
  846b85:	00 
  846b86:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  846b8d:	00 
  846b8e:	0f 11 50 20          	movups %xmm2,0x20(%rax)
  846b92:	0f 11 48 10          	movups %xmm1,0x10(%rax)
  846b96:	0f 11 00             	movups %xmm0,(%rax)
  846b99:	0f 28 84 24 10 05 00 	movaps 0x510(%rsp),%xmm0
  846ba0:	00 
  846ba1:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  846ba5:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  846bac:	00 
  846bad:	0f 11 40 40          	movups %xmm0,0x40(%rax)
  846bb1:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  846bb8:	00 
  846bb9:	ff 15 59 7b 67 00    	call   *0x677b59(%rip)        # ebe718 <_DYNAMIC+0x820>
  846bbf:	8b 4c 24 7c          	mov    0x7c(%rsp),%ecx
  846bc3:	89 8c 24 f0 00 00 00 	mov    %ecx,0xf0(%rsp)
  846bca:	85 c0                	test   %eax,%eax
  846bcc:	74 34                	je     846c02 <<gpui_gpu::renderer::RendererState>::render+0xd32>
  846bce:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  846bd3:	89 c6                	mov    %eax,%esi
  846bd5:	e8 46 6d 00 00       	call   84d920 <gpui_gpu::renderer::slots::color_word>
  846bda:	89 44 24 50          	mov    %eax,0x50(%rsp)
  846bde:	0f 57 c0             	xorps  %xmm0,%xmm0
  846be1:	0f 29 84 24 20 01 00 	movaps %xmm0,0x120(%rsp)
  846be8:	00 
  846be9:	c7 84 24 c0 00 00 00 	movl   $0x0,0xc0(%rsp)
  846bf0:	00 00 00 00 
  846bf4:	8b 84 24 58 01 00 00 	mov    0x158(%rsp),%eax
  846bfb:	89 84 24 f0 00 00 00 	mov    %eax,0xf0(%rsp)
  846c02:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  846c07:	48 c1 e8 20          	shr    $0x20,%rax
  846c0b:	48 89 84 24 e8 03 00 	mov    %rax,0x3e8(%rsp)
  846c12:	00 
  846c13:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846c18:	48 8b 08             	mov    (%rax),%rcx
  846c1b:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846c1f:	48 29 f1             	sub    %rsi,%rcx
  846c22:	48 83 f9 05          	cmp    $0x5,%rcx
  846c26:	0f 86 7e 01 00 00    	jbe    846daa <<gpui_gpu::renderer::RendererState>::render+0xeda>
  846c2c:	f2 0f 10 84 24 f0 03 	movsd  0x3f0(%rsp),%xmm0
  846c33:	00 00 
  846c35:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
  846c39:	f2 0f 10 8c 24 f8 03 	movsd  0x3f8(%rsp),%xmm1
  846c40:	00 00 
  846c42:	f2 0f 5a c9          	cvtsd2ss %xmm1,%xmm1
  846c46:	66 0f 28 94 24 00 05 	movapd 0x500(%rsp),%xmm2
  846c4d:	00 00 
  846c4f:	66 0f 14 94 24 f0 04 	unpcklpd 0x4f0(%rsp),%xmm2
  846c56:	00 00 
  846c58:	66 0f 5a d2          	cvtpd2ps %xmm2,%xmm2
  846c5c:	66 0f 28 9c 24 d0 03 	movapd 0x3d0(%rsp),%xmm3
  846c63:	00 00 
  846c65:	66 0f 14 9c 24 c0 03 	unpcklpd 0x3c0(%rsp),%xmm3
  846c6c:	00 00 
  846c6e:	66 0f 5a db          	cvtpd2ps %xmm3,%xmm3
  846c72:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846c77:	48 8b 50 08          	mov    0x8(%rax),%rdx
  846c7b:	48 c1 e6 04          	shl    $0x4,%rsi
  846c7f:	0f 28 a4 24 d0 02 00 	movaps 0x2d0(%rsp),%xmm4
  846c86:	00 
  846c87:	0f 11 24 32          	movups %xmm4,(%rdx,%rsi,1)
  846c8b:	66 0f 13 5c 32 10    	movlpd %xmm3,0x10(%rdx,%rsi,1)
  846c91:	f3 0f 11 4c 32 18    	movss  %xmm1,0x18(%rdx,%rsi,1)
  846c97:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  846c9c:	89 4c 32 1c          	mov    %ecx,0x1c(%rdx,%rsi,1)
  846ca0:	66 0f 13 54 32 20    	movlpd %xmm2,0x20(%rdx,%rsi,1)
  846ca6:	f3 0f 11 44 32 28    	movss  %xmm0,0x28(%rdx,%rsi,1)
  846cac:	48 8b bc 24 e8 03 00 	mov    0x3e8(%rsp),%rdi
  846cb3:	00 
  846cb4:	89 7c 32 2c          	mov    %edi,0x2c(%rdx,%rsi,1)
  846cb8:	0f 28 84 24 c0 02 00 	movaps 0x2c0(%rsp),%xmm0
  846cbf:	00 
  846cc0:	0f 11 44 32 30       	movups %xmm0,0x30(%rdx,%rsi,1)
  846cc5:	8b 7c 24 50          	mov    0x50(%rsp),%edi
  846cc9:	89 7c 32 40          	mov    %edi,0x40(%rdx,%rsi,1)
  846ccd:	8b bc 24 c0 00 00 00 	mov    0xc0(%rsp),%edi
  846cd4:	89 7c 32 44          	mov    %edi,0x44(%rdx,%rsi,1)
  846cd8:	0f 28 84 24 20 01 00 	movaps 0x120(%rsp),%xmm0
  846cdf:	00 
  846ce0:	0f 13 44 32 48       	movlps %xmm0,0x48(%rdx,%rsi,1)
  846ce5:	48 c7 44 32 50 00 00 	movq   $0x0,0x50(%rdx,%rsi,1)
  846cec:	00 00 
  846cee:	c7 44 32 58 00 00 00 	movl   $0x0,0x58(%rdx,%rsi,1)
  846cf5:	00 
  846cf6:	8b bc 24 f0 00 00 00 	mov    0xf0(%rsp),%edi
  846cfd:	89 7c 32 5c          	mov    %edi,0x5c(%rdx,%rsi,1)
  846d01:	48 83 40 10 06       	addq   $0x6,0x10(%rax)
  846d06:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  846d0d:	00 
  846d0e:	48 89 c6             	mov    %rax,%rsi
  846d11:	48 8d 94 24 48 04 00 	lea    0x448(%rsp),%rdx
  846d18:	00 
  846d19:	44 8b 84 24 a0 03 00 	mov    0x3a0(%rsp),%r8d
  846d20:	00 
  846d21:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  846d26:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  846d2d:	41 57                	push   %r15
  846d2f:	41 56                	push   %r14
  846d31:	ff 74 24 50          	push   0x50(%rsp)
  846d35:	e8 06 16 00 00       	call   848340 <<gpui_gpu::renderer::RendererState>::bin_draw>
  846d3a:	48 83 c4 20          	add    $0x20,%rsp
  846d3e:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  846d45:	83 f8 ff             	cmp    $0xffffffff,%eax
  846d48:	0f 85 48 06 00 00    	jne    847396 <<gpui_gpu::renderer::RendererState>::render+0x14c6>
  846d4e:	0f b6 4c 24 2f       	movzbl 0x2f(%rsp),%ecx
  846d53:	22 4c 24 2e          	and    0x2e(%rsp),%cl
  846d57:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  846d5c:	08 c8                	or     %cl,%al
  846d5e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  846d63:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  846d6a:	00 
  846d6b:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  846d72:	00 
  846d73:	48 ff 44 24 48       	incq   0x48(%rsp)
  846d78:	48 8b 94 24 80 00 00 	mov    0x80(%rsp),%rdx
  846d7f:	00 
  846d80:	48 83 c2 04          	add    $0x4,%rdx
  846d84:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846d8b:	00 
  846d8c:	48 8d 04 85 00 00 00 	lea    0x0(,%rax,4),%rax
  846d93:	00 
  846d94:	48 89 94 24 80 00 00 	mov    %rdx,0x80(%rsp)
  846d9b:	00 
  846d9c:	48 39 d0             	cmp    %rdx,%rax
  846d9f:	0f 85 1f fb ff ff    	jne    8468c4 <<gpui_gpu::renderer::RendererState>::render+0x9f4>
  846da5:	e9 74 04 00 00       	jmp    84721e <<gpui_gpu::renderer::RendererState>::render+0x134e>
  846daa:	ba 06 00 00 00       	mov    $0x6,%edx
  846daf:	b9 04 00 00 00       	mov    $0x4,%ecx
  846db4:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  846dba:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  846dbf:	e8 ac 4b 00 00       	call   84b970 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  846dc4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846dc9:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846dcd:	e9 5a fe ff ff       	jmp    846c2c <<gpui_gpu::renderer::RendererState>::render+0xd5c>
  846dd2:	0f 57 c0             	xorps  %xmm0,%xmm0
  846dd5:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
  846ddc:	00 
  846ddd:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
  846de2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846de7:	8b 40 10             	mov    0x10(%rax),%eax
  846dea:	89 84 24 20 01 00 00 	mov    %eax,0x120(%rsp)
  846df1:	0f 10 8c 24 70 02 00 	movups 0x270(%rsp),%xmm1
  846df8:	00 
  846df9:	0f 10 94 24 78 02 00 	movups 0x278(%rsp),%xmm2
  846e00:	00 
  846e01:	f2 0f 10 84 24 90 02 	movsd  0x290(%rsp),%xmm0
  846e08:	00 00 
  846e0a:	f2 0f 11 84 24 f0 00 	movsd  %xmm0,0xf0(%rsp)
  846e11:	00 00 
  846e13:	f2 0f 10 84 24 98 02 	movsd  0x298(%rsp),%xmm0
  846e1a:	00 00 
  846e1c:	f2 0f 11 84 24 d0 02 	movsd  %xmm0,0x2d0(%rsp)
  846e23:	00 00 
  846e25:	0f 10 84 24 a0 02 00 	movups 0x2a0(%rsp),%xmm0
  846e2c:	00 
  846e2d:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
  846e34:	00 
  846e35:	0f 16 8c 24 80 02 00 	movhps 0x280(%rsp),%xmm1
  846e3c:	00 
  846e3d:	0f 29 8c 24 a0 03 00 	movaps %xmm1,0x3a0(%rsp)
  846e44:	00 
  846e45:	0f 10 84 24 b0 02 00 	movups 0x2b0(%rsp),%xmm0
  846e4c:	00 
  846e4d:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
  846e52:	0f 16 94 24 88 02 00 	movhps 0x288(%rsp),%xmm2
  846e59:	00 
  846e5a:	0f 29 94 24 c0 02 00 	movaps %xmm2,0x2c0(%rsp)
  846e61:	00 
  846e62:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  846e67:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  846e6e:	00 
  846e6f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  846e74:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  846e7b:	00 
  846e7c:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846e83:	00 
  846e84:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  846e8b:	00 
  846e8c:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  846e93:	00 
  846e94:	0f 10 00             	movups (%rax),%xmm0
  846e97:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  846e9b:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  846e9f:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  846ea6:	00 
  846ea7:	0f 11 52 20          	movups %xmm2,0x20(%rdx)
  846eab:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  846eaf:	0f 11 02             	movups %xmm0,(%rdx)
  846eb2:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  846eb9:	00 
  846eba:	0f 10 01             	movups (%rcx),%xmm0
  846ebd:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  846ec1:	f3 0f 6f 40 40       	movdqu 0x40(%rax),%xmm0
  846ec6:	f3 0f 7f 42 40       	movdqu %xmm0,0x40(%rdx)
  846ecb:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  846ed2:	00 
  846ed3:	ff 15 3f 78 67 00    	call   *0x67783f(%rip)        # ebe718 <_DYNAMIC+0x820>
  846ed9:	85 c0                	test   %eax,%eax
  846edb:	74 1e                	je     846efb <<gpui_gpu::renderer::RendererState>::render+0x102b>
  846edd:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  846ee2:	89 c6                	mov    %eax,%esi
  846ee4:	e8 37 6a 00 00       	call   84d920 <gpui_gpu::renderer::slots::color_word>
  846ee9:	81 4c 24 7c 00 00 00 	orl    $0x80000000,0x7c(%rsp)
  846ef0:	80 
  846ef1:	66 0f 6e c0          	movd   %eax,%xmm0
  846ef5:	66 0f 7f 44 24 50    	movdqa %xmm0,0x50(%rsp)
  846efb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846f00:	48 8b 08             	mov    (%rax),%rcx
  846f03:	48 8b 70 10          	mov    0x10(%rax),%rsi
  846f07:	48 29 f1             	sub    %rsi,%rcx
  846f0a:	48 83 f9 04          	cmp    $0x4,%rcx
  846f0e:	0f 86 44 03 00 00    	jbe    847258 <<gpui_gpu::renderer::RendererState>::render+0x1388>
  846f14:	66 0f 5a 84 24 a0 03 	cvtpd2ps 0x3a0(%rsp),%xmm0
  846f1b:	00 00 
  846f1d:	66 0f 5a 8c 24 c0 02 	cvtpd2ps 0x2c0(%rsp),%xmm1
  846f24:	00 00 
  846f26:	f2 0f 10 94 24 f0 00 	movsd  0xf0(%rsp),%xmm2
  846f2d:	00 00 
  846f2f:	f2 0f 5a d2          	cvtsd2ss %xmm2,%xmm2
  846f33:	f2 0f 10 9c 24 d0 02 	movsd  0x2d0(%rsp),%xmm3
  846f3a:	00 00 
  846f3c:	f2 0f 5a db          	cvtsd2ss %xmm3,%xmm3
  846f40:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  846f45:	48 8b 48 08          	mov    0x8(%rax),%rcx
  846f49:	48 c1 e6 04          	shl    $0x4,%rsi
  846f4d:	66 0f 13 04 31       	movlpd %xmm0,(%rcx,%rsi,1)
  846f52:	f3 0f 11 54 31 08    	movss  %xmm2,0x8(%rcx,%rsi,1)
  846f58:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
  846f5d:	f3 0f 11 44 31 0c    	movss  %xmm0,0xc(%rcx,%rsi,1)
  846f63:	66 0f 13 4c 31 10    	movlpd %xmm1,0x10(%rcx,%rsi,1)
  846f69:	f3 0f 11 5c 31 18    	movss  %xmm3,0x18(%rcx,%rsi,1)
  846f6f:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
  846f76:	00 
  846f77:	f3 0f 11 44 31 1c    	movss  %xmm0,0x1c(%rcx,%rsi,1)
  846f7d:	0f 28 84 24 c0 00 00 	movaps 0xc0(%rsp),%xmm0
  846f84:	00 
  846f85:	0f 11 44 31 20       	movups %xmm0,0x20(%rcx,%rsi,1)
  846f8a:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
  846f8f:	0f 11 44 31 30       	movups %xmm0,0x30(%rcx,%rsi,1)
  846f94:	8b 54 24 7c          	mov    0x7c(%rsp),%edx
  846f98:	89 54 31 40          	mov    %edx,0x40(%rcx,%rsi,1)
  846f9c:	48 c7 44 31 44 00 00 	movq   $0x0,0x44(%rcx,%rsi,1)
  846fa3:	00 00 
  846fa5:	c7 44 31 4c 00 00 00 	movl   $0x0,0x4c(%rcx,%rsi,1)
  846fac:	00 
  846fad:	48 83 40 10 05       	addq   $0x5,0x10(%rax)
  846fb2:	48 ff 84 24 38 01 00 	incq   0x138(%rsp)
  846fb9:	00 
  846fba:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  846fc1:	00 
  846fc2:	48 01 84 24 40 01 00 	add    %rax,0x140(%rsp)
  846fc9:	00 
  846fca:	48 85 c0             	test   %rax,%rax
  846fcd:	0f 84 57 02 00 00    	je     84722a <<gpui_gpu::renderer::RendererState>::render+0x135a>
  846fd3:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  846fd9:	66 0f 7e c1          	movd   %xmm0,%ecx
  846fdd:	66 0f 6f 84 24 80 00 	movdqa 0x80(%rsp),%xmm0
  846fe4:	00 00 
  846fe6:	66 0f 7e c0          	movd   %xmm0,%eax
  846fea:	48 c1 e0 20          	shl    $0x20,%rax
  846fee:	48 09 c1             	or     %rax,%rcx
  846ff1:	48 89 8c 24 f0 00 00 	mov    %rcx,0xf0(%rsp)
  846ff8:	00 
  846ff9:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
  847000:	00 00 
  847002:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847007:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  84700c:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  84700f:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  847016:	00 
  847017:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  84701c:	e8 6f d6 ff ff       	call   844690 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  847021:	0f b6 bc 24 40 03 00 	movzbl 0x340(%rsp),%edi
  847028:	00 
  847029:	48 8d b4 24 48 03 00 	lea    0x348(%rsp),%rsi
  847030:	00 
  847031:	8b 46 f9             	mov    -0x7(%rsi),%eax
  847034:	8b 4e fc             	mov    -0x4(%rsi),%ecx
  847037:	48 8d 94 24 61 01 00 	lea    0x161(%rsp),%rdx
  84703e:	00 
  84703f:	89 4a 03             	mov    %ecx,0x3(%rdx)
  847042:	89 02                	mov    %eax,(%rdx)
  847044:	48 8b 8c 24 48 03 00 	mov    0x348(%rsp),%rcx
  84704b:	00 
  84704c:	48 8b 46 28          	mov    0x28(%rsi),%rax
  847050:	48 89 42 2f          	mov    %rax,0x2f(%rdx)
  847054:	0f 10 46 08          	movups 0x8(%rsi),%xmm0
  847058:	0f 10 4e 18          	movups 0x18(%rsi),%xmm1
  84705c:	0f 11 4a 1f          	movups %xmm1,0x1f(%rdx)
  847060:	0f 11 42 0f          	movups %xmm0,0xf(%rdx)
  847064:	0f 10 8c 24 78 03 00 	movups 0x378(%rsp),%xmm1
  84706b:	00 
  84706c:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  847073:	00 
  847074:	0f 10 00             	movups (%rax),%xmm0
  847077:	48 8d 84 24 78 01 00 	lea    0x178(%rsp),%rax
  84707e:	00 
  84707f:	0f 11 40 70          	movups %xmm0,0x70(%rax)
  847083:	0f 28 84 24 30 04 00 	movaps 0x430(%rsp),%xmm0
  84708a:	00 
  84708b:	0f 11 80 80 00 00 00 	movups %xmm0,0x80(%rax)
  847092:	0f 29 8c 24 a0 00 00 	movaps %xmm1,0xa0(%rsp)
  847099:	00 
  84709a:	0f 11 8c 24 98 01 00 	movups %xmm1,0x198(%rsp)
  8470a1:	00 
  8470a2:	0f 28 84 24 20 05 00 	movaps 0x520(%rsp),%xmm0
  8470a9:	00 
  8470aa:	0f 28 8c 24 30 05 00 	movaps 0x530(%rsp),%xmm1
  8470b1:	00 
  8470b2:	66 0f 28 94 24 40 05 	movapd 0x540(%rsp),%xmm2
  8470b9:	00 00 
  8470bb:	66 0f 11 50 50       	movupd %xmm2,0x50(%rax)
  8470c0:	0f 11 48 40          	movups %xmm1,0x40(%rax)
  8470c4:	0f 11 40 30          	movups %xmm0,0x30(%rax)
  8470c8:	0f 28 84 24 50 05 00 	movaps 0x550(%rsp),%xmm0
  8470cf:	00 
  8470d0:	0f 11 40 60          	movups %xmm0,0x60(%rax)
  8470d4:	40 88 7c 24 50       	mov    %dil,0x50(%rsp)
  8470d9:	40 88 bc 24 60 01 00 	mov    %dil,0x160(%rsp)
  8470e0:	00 
  8470e1:	48 89 8c 24 c0 00 00 	mov    %rcx,0xc0(%rsp)
  8470e8:	00 
  8470e9:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  8470f0:	00 
  8470f1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8470f6:	48 8b 08             	mov    (%rax),%rcx
  8470f9:	48 8b 40 10          	mov    0x10(%rax),%rax
  8470fd:	48 29 c1             	sub    %rax,%rcx
  847100:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  847107:	00 
  847108:	48 83 f9 01          	cmp    $0x1,%rcx
  84710c:	0f 86 dc 00 00 00    	jbe    8471ee <<gpui_gpu::renderer::RendererState>::render+0x131e>
  847112:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  847117:	48 8b 4e 08          	mov    0x8(%rsi),%rcx
  84711b:	48 c1 e0 04          	shl    $0x4,%rax
  84711f:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
  847126:	00 
  847127:	0f 11 04 01          	movups %xmm0,(%rcx,%rax,1)
  84712b:	48 c7 44 01 10 00 00 	movq   $0x0,0x10(%rcx,%rax,1)
  847132:	00 00 
  847134:	c7 44 01 18 00 00 00 	movl   $0x0,0x18(%rcx,%rax,1)
  84713b:	00 
  84713c:	8b 94 24 20 01 00 00 	mov    0x120(%rsp),%edx
  847143:	89 54 01 1c          	mov    %edx,0x1c(%rcx,%rax,1)
  847147:	48 83 46 10 02       	addq   $0x2,0x10(%rsi)
  84714c:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  847153:	00 
  847154:	48 8d 94 24 60 01 00 	lea    0x160(%rsp),%rdx
  84715b:	00 
  84715c:	48 8b 8c 24 f0 00 00 	mov    0xf0(%rsp),%rcx
  847163:	00 
  847164:	4c 8b 84 24 80 00 00 	mov    0x80(%rsp),%r8
  84716b:	00 
  84716c:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
  847171:	ff b4 24 d8 00 00 00 	push   0xd8(%rsp)
  847178:	41 57                	push   %r15
  84717a:	41 56                	push   %r14
  84717c:	ff 74 24 50          	push   0x50(%rsp)
  847180:	e8 bb 11 00 00       	call   848340 <<gpui_gpu::renderer::RendererState>::bin_draw>
  847185:	48 83 c4 20          	add    $0x20,%rsp
  847189:	8b 84 24 40 03 00 00 	mov    0x340(%rsp),%eax
  847190:	83 f8 ff             	cmp    $0xffffffff,%eax
  847193:	0f 85 19 02 00 00    	jne    8473b2 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  847199:	80 7c 24 50 02       	cmpb   $0x2,0x50(%rsp)
  84719e:	0f 94 c0             	sete   %al
  8471a1:	48 83 bc 24 c0 00 00 	cmpq   $0x0,0xc0(%rsp)
  8471a8:	00 00 
  8471aa:	0f 95 c1             	setne  %cl
  8471ad:	20 c1                	and    %al,%cl
  8471af:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  8471b4:	08 c8                	or     %cl,%al
  8471b6:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  8471bb:	48 8b 84 24 48 03 00 	mov    0x348(%rsp),%rax
  8471c2:	00 
  8471c3:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
  8471ca:	00 
  8471cb:	48 ff 44 24 48       	incq   0x48(%rsp)
  8471d0:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  8471d5:	48 83 c1 04          	add    $0x4,%rcx
  8471d9:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  8471de:	48 39 8c 24 e0 03 00 	cmp    %rcx,0x3e0(%rsp)
  8471e5:	00 
  8471e6:	0f 85 16 fe ff ff    	jne    847002 <<gpui_gpu::renderer::RendererState>::render+0x1132>
  8471ec:	eb 30                	jmp    84721e <<gpui_gpu::renderer::RendererState>::render+0x134e>
  8471ee:	ba 02 00 00 00       	mov    $0x2,%edx
  8471f3:	b9 04 00 00 00       	mov    $0x4,%ecx
  8471f8:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  8471fe:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  847203:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  84720a:	00 
  84720b:	e8 60 47 00 00       	call   84b970 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847210:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847215:	48 8b 40 10          	mov    0x10(%rax),%rax
  847219:	e9 f4 fe ff ff       	jmp    847112 <<gpui_gpu::renderer::RendererState>::render+0x1242>
  84721e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  847223:	24 01                	and    $0x1,%al
  847225:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  84722a:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847231:	00 
  847232:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  847239:	00 
  84723a:	ff 15 d0 74 67 00    	call   *0x6774d0(%rip)        # ebe710 <_DYNAMIC+0x818>
  847240:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847247:	00 
  847248:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  84724d:	48 85 c0             	test   %rax,%rax
  847250:	0f 85 2f f3 ff ff    	jne    846585 <<gpui_gpu::renderer::RendererState>::render+0x6b5>
  847256:	eb 5e                	jmp    8472b6 <<gpui_gpu::renderer::RendererState>::render+0x13e6>
  847258:	ba 05 00 00 00       	mov    $0x5,%edx
  84725d:	b9 04 00 00 00       	mov    $0x4,%ecx
  847262:	41 b8 10 00 00 00    	mov    $0x10,%r8d
  847268:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  84726d:	e8 fe 46 00 00       	call   84b970 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  847272:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847277:	48 8b 70 10          	mov    0x10(%rax),%rsi
  84727b:	e9 94 fc ff ff       	jmp    846f14 <<gpui_gpu::renderer::RendererState>::render+0x1044>
  847280:	48 c7 84 24 40 01 00 	movq   $0x0,0x140(%rsp)
  847287:	00 00 00 00 00 
  84728c:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
  847293:	00 00 00 00 00 
  847298:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
  84729f:	00 00 
  8472a1:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  8472a8:	00 00 
  8472aa:	48 c7 84 24 d8 00 00 	movq   $0x0,0xd8(%rsp)
  8472b1:	00 00 00 00 00 
  8472b6:	48 8b b4 24 50 01 00 	mov    0x150(%rsp),%rsi
  8472bd:	00 
  8472be:	48 8d 56 08          	lea    0x8(%rsi),%rdx
  8472c2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8472c7:	48 8d 88 50 02 00 00 	lea    0x250(%rax),%rcx
  8472ce:	4c 8d 80 28 03 00 00 	lea    0x328(%rax),%r8
  8472d5:	4c 8b 48 10          	mov    0x10(%rax),%r9
  8472d9:	48 83 ec 08          	sub    $0x8,%rsp
  8472dd:	48 8d bc 24 68 01 00 	lea    0x168(%rsp),%rdi
  8472e4:	00 
  8472e5:	48 89 94 24 d8 03 00 	mov    %rdx,0x3d8(%rsp)
  8472ec:	00 
  8472ed:	48 89 8c 24 c8 02 00 	mov    %rcx,0x2c8(%rsp)
  8472f4:	00 
  8472f5:	4c 89 84 24 d8 02 00 	mov    %r8,0x2d8(%rsp)
  8472fc:	00 
  8472fd:	ff b4 24 98 00 00 00 	push   0x98(%rsp)
  847304:	e8 a7 35 00 00       	call   84a8b0 <gpui_gpu::renderer::images::prepare>
  847309:	48 83 c4 10          	add    $0x10,%rsp
  84730d:	83 bc 24 60 01 00 00 	cmpl   $0xffffffff,0x160(%rsp)
  847314:	ff 
  847315:	74 47                	je     84735e <<gpui_gpu::renderer::RendererState>::render+0x148e>
  847317:	0f 10 84 24 60 01 00 	movups 0x160(%rsp),%xmm0
  84731e:	00 
  84731f:	0f 10 8c 24 70 01 00 	movups 0x170(%rsp),%xmm1
  847326:	00 
  847327:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  84732c:	0f 11 4f 10          	movups %xmm1,0x10(%rdi)
  847330:	0f 11 07             	movups %xmm0,(%rdi)
  847333:	e9 8e ec ff ff       	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  847338:	8b 94 24 1c 01 00 00 	mov    0x11c(%rsp),%edx
  84733f:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  847344:	89 57 1c             	mov    %edx,0x1c(%rdi)
  847347:	0f 10 84 24 0c 01 00 	movups 0x10c(%rsp),%xmm0
  84734e:	00 
  84734f:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  847353:	89 0f                	mov    %ecx,(%rdi)
  847355:	48 89 47 04          	mov    %rax,0x4(%rdi)
  847359:	e9 68 ec ff ff       	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  84735e:	44 0f b6 44 24 10    	movzbl 0x10(%rsp),%r8d
  847364:	41 83 e0 01          	and    $0x1,%r8d
  847368:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  84736f:	00 
  847370:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  847375:	48 8b 94 24 50 01 00 	mov    0x150(%rsp),%rdx
  84737c:	00 
  84737d:	48 8b 8c 24 b8 00 00 	mov    0xb8(%rsp),%rcx
  847384:	00 
  847385:	e8 a6 e1 ff ff       	call   845530 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  84738a:	8b 84 24 60 01 00 00 	mov    0x160(%rsp),%eax
  847391:	83 f8 ff             	cmp    $0xffffffff,%eax
  847394:	74 63                	je     8473f9 <<gpui_gpu::renderer::RendererState>::render+0x1529>
  847396:	8b 8c 24 64 01 00 00 	mov    0x164(%rsp),%ecx
  84739d:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  8473a4:	00 
  8473a5:	0f 10 84 24 70 01 00 	movups 0x170(%rsp),%xmm0
  8473ac:	00 
  8473ad:	e9 3d f0 ff ff       	jmp    8463ef <<gpui_gpu::renderer::RendererState>::render+0x51f>
  8473b2:	8b 8c 24 44 03 00 00 	mov    0x344(%rsp),%ecx
  8473b9:	48 8b 94 24 48 03 00 	mov    0x348(%rsp),%rdx
  8473c0:	00 
  8473c1:	0f 10 84 24 50 03 00 	movups 0x350(%rsp),%xmm0
  8473c8:	00 
  8473c9:	e9 21 f0 ff ff       	jmp    8463ef <<gpui_gpu::renderer::RendererState>::render+0x51f>
  8473ce:	8b 8c 24 7c 01 00 00 	mov    0x17c(%rsp),%ecx
  8473d5:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  8473da:	89 4f 1c             	mov    %ecx,0x1c(%rdi)
  8473dd:	0f 10 84 24 6c 01 00 	movups 0x16c(%rsp),%xmm0
  8473e4:	00 
  8473e5:	0f 11 47 0c          	movups %xmm0,0xc(%rdi)
  8473e9:	89 07                	mov    %eax,(%rdi)
  8473eb:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  8473f0:	48 89 47 04          	mov    %rax,0x4(%rdi)
  8473f4:	e9 cd eb ff ff       	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  8473f9:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  847400:	00 
  847401:	48 89 84 24 c0 03 00 	mov    %rax,0x3c0(%rsp)
  847408:	00 
  847409:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  847410:	00 
  847411:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  847418:	00 
  847419:	48 c7 84 24 48 03 00 	movq   $0x0,0x348(%rsp)
  847420:	00 00 00 00 00 
  847425:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  84742c:	00 
  84742d:	48 89 84 24 50 03 00 	mov    %rax,0x350(%rsp)
  847434:	00 
  847435:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  84743c:	00 
  84743d:	48 89 84 24 58 03 00 	mov    %rax,0x358(%rsp)
  847444:	00 
  847445:	8b 44 24 78          	mov    0x78(%rsp),%eax
  847449:	89 84 24 60 03 00 00 	mov    %eax,0x360(%rsp)
  847450:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847457:	00 
  847458:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  84745f:	00 
  847460:	ff 15 aa 72 67 00    	call   *0x6772aa(%rip)        # ebe710 <_DYNAMIC+0x818>
  847466:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  84746d:	00 
  84746e:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  847475:	00 
  847476:	48 85 c0             	test   %rax,%rax
  847479:	0f 84 d7 03 00 00    	je     847856 <<gpui_gpu::renderer::RendererState>::render+0x1986>
  84747f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847484:	48 05 20 01 00 00    	add    $0x120,%rax
  84748a:	48 89 84 24 a0 03 00 	mov    %rax,0x3a0(%rsp)
  847491:	00 
  847492:	eb 3c                	jmp    8474d0 <<gpui_gpu::renderer::RendererState>::render+0x1600>
  847494:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  84749b:	00 
  84749c:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  8474a3:	00 
  8474a4:	ff 15 66 72 67 00    	call   *0x677266(%rip)        # ebe710 <_DYNAMIC+0x818>
  8474aa:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  8474b1:	00 
  8474b2:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  8474b7:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  8474be:	00 
  8474bf:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
  8474c6:	00 
  8474c7:	48 85 c0             	test   %rax,%rax
  8474ca:	0f 84 86 03 00 00    	je     847856 <<gpui_gpu::renderer::RendererState>::render+0x1986>
  8474d0:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
  8474d7:	00 
  8474d8:	48 8b bc 24 68 02 00 	mov    0x268(%rsp),%rdi
  8474df:	00 
  8474e0:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  8474e7:	00 
  8474e8:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  8474ef:	00 
  8474f0:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  8474f4:	48 8d 8c 24 78 01 00 	lea    0x178(%rsp),%rcx
  8474fb:	00 
  8474fc:	0f 11 41 40          	movups %xmm0,0x40(%rcx)
  847500:	0f 10 00             	movups (%rax),%xmm0
  847503:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847507:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  84750b:	0f 10 58 30          	movups 0x30(%rax),%xmm3
  84750f:	0f 11 59 30          	movups %xmm3,0x30(%rcx)
  847513:	0f 11 51 20          	movups %xmm2,0x20(%rcx)
  847517:	0f 11 49 10          	movups %xmm1,0x10(%rcx)
  84751b:	0f 11 01             	movups %xmm0,(%rcx)
  84751e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847523:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  84752a:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847531:	00 
  847532:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  847539:	00 
  84753a:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  84753f:	48 89 94 24 68 01 00 	mov    %rdx,0x168(%rsp)
  847546:	00 
  847547:	48 89 bc 24 70 01 00 	mov    %rdi,0x170(%rsp)
  84754e:	00 
  84754f:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847556:	00 
  847557:	e8 44 1e 00 00       	call   8493a0 <gpui_gpu::renderer::compact_group>
  84755c:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
  847563:	00 
  847564:	48 8d 51 05          	lea    0x5(%rcx),%rdx
  847568:	84 c0                	test   %al,%al
  84756a:	48 0f 44 d1          	cmove  %rcx,%rdx
  84756e:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  847573:	48 83 bc 24 80 00 00 	cmpq   $0x0,0x80(%rsp)
  84757a:	00 00 
  84757c:	0f 84 12 ff ff ff    	je     847494 <<gpui_gpu::renderer::RendererState>::render+0x15c4>
  847582:	48 c1 a4 24 80 00 00 	shlq   $0x2,0x80(%rsp)
  847589:	00 02 
  84758b:	34 01                	xor    $0x1,%al
  84758d:	0f b6 c8             	movzbl %al,%ecx
  847590:	c1 e1 02             	shl    $0x2,%ecx
  847593:	48 8d 41 01          	lea    0x1(%rcx),%rax
  847597:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
  84759e:	00 
  84759f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  8475a4:	4c 8d 04 08          	lea    (%rax,%rcx,1),%r8
  8475a8:	49 ff c0             	inc    %r8
  8475ab:	48 83 c9 02          	or     $0x2,%rcx
  8475af:	49 c1 e0 04          	shl    $0x4,%r8
  8475b3:	48 89 8c 24 e0 00 00 	mov    %rcx,0xe0(%rsp)
  8475ba:	00 
  8475bb:	c1 e1 04             	shl    $0x4,%ecx
  8475be:	48 89 8c 24 20 01 00 	mov    %rcx,0x120(%rsp)
  8475c5:	00 
  8475c6:	31 c9                	xor    %ecx,%ecx
  8475c8:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  8475cd:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  8475d2:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  8475d7:	8b 14 08             	mov    (%rax,%rcx,1),%edx
  8475da:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  8475e1:	00 
  8475e2:	48 8b b4 24 a0 00 00 	mov    0xa0(%rsp),%rsi
  8475e9:	00 
  8475ea:	e8 a1 d0 ff ff       	call   844690 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8475ef:	0f b6 8c 24 60 01 00 	movzbl 0x160(%rsp),%ecx
  8475f6:	00 
  8475f7:	0f b6 84 24 61 01 00 	movzbl 0x161(%rsp),%eax
  8475fe:	00 
  8475ff:	f3 0f 10 a4 24 64 01 	movss  0x164(%rsp),%xmm4
  847606:	00 00 
  847608:	48 8d b4 24 68 01 00 	lea    0x168(%rsp),%rsi
  84760f:	00 
  847610:	48 8b 56 10          	mov    0x10(%rsi),%rdx
  847614:	48 89 94 24 20 03 00 	mov    %rdx,0x320(%rsp)
  84761b:	00 
  84761c:	0f 10 06             	movups (%rsi),%xmm0
  84761f:	0f 29 84 24 10 03 00 	movaps %xmm0,0x310(%rsp)
  847626:	00 
  847627:	83 f9 01             	cmp    $0x1,%ecx
  84762a:	0f 84 8f 00 00 00    	je     8476bf <<gpui_gpu::renderer::RendererState>::render+0x17ef>
  847630:	0f 29 a4 24 f0 00 00 	movaps %xmm4,0xf0(%rsp)
  847637:	00 
  847638:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
  84763f:	00 
  847640:	8b 94 24 88 01 00 00 	mov    0x188(%rsp),%edx
  847647:	89 54 24 60          	mov    %edx,0x60(%rsp)
  84764b:	8b 94 24 8c 01 00 00 	mov    0x18c(%rsp),%edx
  847652:	89 54 24 20          	mov    %edx,0x20(%rsp)
  847656:	83 f9 03             	cmp    $0x3,%ecx
  847659:	0f 85 e5 00 00 00    	jne    847744 <<gpui_gpu::renderer::RendererState>::render+0x1874>
  84765f:	48 8b 8c 24 d0 02 00 	mov    0x2d0(%rsp),%rcx
  847666:	00 
  847667:	48 8b 39             	mov    (%rcx),%rdi
  84766a:	48 85 ff             	test   %rdi,%rdi
  84766d:	0f 84 4b 0c 00 00    	je     8482be <<gpui_gpu::renderer::RendererState>::render+0x23ee>
  847673:	0f b6 d0             	movzbl %al,%edx
  847676:	e8 c5 2e 00 00       	call   84a540 <<gpui_gpu::renderer::images::Images>::metadata>
  84767b:	89 c1                	mov    %eax,%ecx
  84767d:	48 c1 e8 20          	shr    $0x20,%rax
  847681:	89 c2                	mov    %eax,%edx
  847683:	83 ca 10             	or     $0x10,%edx
  847686:	0f 57 c0             	xorps  %xmm0,%xmm0
  847689:	0f 28 8c 24 f0 00 00 	movaps 0xf0(%rsp),%xmm1
  847690:	00 
  847691:	0f 2e c8             	ucomiss %xmm0,%xmm1
  847694:	0f 45 c2             	cmovne %edx,%eax
  847697:	0f 4a c2             	cmovp  %edx,%eax
  84769a:	8b 54 24 20          	mov    0x20(%rsp),%edx
  84769e:	c1 e2 10             	shl    $0x10,%edx
  8476a1:	0b 54 24 60          	or     0x60(%rsp),%edx
  8476a5:	89 8c 24 00 01 00 00 	mov    %ecx,0x100(%rsp)
  8476ac:	89 84 24 04 01 00 00 	mov    %eax,0x104(%rsp)
  8476b3:	89 94 24 08 01 00 00 	mov    %edx,0x108(%rsp)
  8476ba:	e9 22 01 00 00       	jmp    8477e1 <<gpui_gpu::renderer::RendererState>::render+0x1911>
  8476bf:	f3 0f 10 84 24 a0 01 	movss  0x1a0(%rsp),%xmm0
  8476c6:	00 00 
  8476c8:	f3 0f 10 1d e4 94 88 	movss  -0x776b1c(%rip),%xmm3        # d0bb4 <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x14>
  8476cf:	ff 
  8476d0:	f3 0f 59 c3          	mulss  %xmm3,%xmm0
  8476d4:	0f 28 cc             	movaps %xmm4,%xmm1
  8476d7:	f3 0f 5d c8          	minss  %xmm0,%xmm1
  8476db:	0f 28 c1             	movaps %xmm1,%xmm0
  8476de:	f3 0f c2 c1 03       	cmpunordss %xmm1,%xmm0
  8476e3:	0f 28 d0             	movaps %xmm0,%xmm2
  8476e6:	0f 55 d1             	andnps %xmm1,%xmm2
  8476e9:	0f 54 c4             	andps  %xmm4,%xmm0
  8476ec:	0f 56 c2             	orps   %xmm2,%xmm0
  8476ef:	f3 0f 10 8c 24 a4 01 	movss  0x1a4(%rsp),%xmm1
  8476f6:	00 00 
  8476f8:	f3 0f 59 cb          	mulss  %xmm3,%xmm1
  8476fc:	0f 28 d0             	movaps %xmm0,%xmm2
  8476ff:	f3 0f 5d d1          	minss  %xmm1,%xmm2
  847703:	0f 28 ca             	movaps %xmm2,%xmm1
  847706:	f3 0f c2 ca 03       	cmpunordss %xmm2,%xmm1
  84770b:	0f 54 c1             	andps  %xmm1,%xmm0
  84770e:	0f 55 ca             	andnps %xmm2,%xmm1
  847711:	0f 56 c8             	orps   %xmm0,%xmm1
  847714:	66 0f 7e c8          	movd   %xmm1,%eax
  847718:	25 00 00 80 ff       	and    $0xff800000,%eax
  84771d:	b9 00 00 00 7f       	mov    $0x7f000000,%ecx
  847722:	29 c1                	sub    %eax,%ecx
  847724:	c7 84 24 00 01 00 00 	movl   $0x40000000,0x100(%rsp)
  84772b:	00 00 00 40 
  84772f:	f3 0f 11 8c 24 04 01 	movss  %xmm1,0x104(%rsp)
  847736:	00 00 
  847738:	89 8c 24 08 01 00 00 	mov    %ecx,0x108(%rsp)
  84773f:	e9 9d 00 00 00       	jmp    8477e1 <<gpui_gpu::renderer::RendererState>::render+0x1911>
  847744:	80 f9 02             	cmp    $0x2,%cl
  847747:	75 50                	jne    847799 <<gpui_gpu::renderer::RendererState>::render+0x18c9>
  847749:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
  847750:	00 
  847751:	48 8b 8c 24 20 03 00 	mov    0x320(%rsp),%rcx
  847758:	00 
  847759:	48 89 8c 24 70 01 00 	mov    %rcx,0x170(%rsp)
  847760:	00 
  847761:	0f 28 84 24 10 03 00 	movaps 0x310(%rsp),%xmm0
  847768:	00 
  847769:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  847770:	00 
  847771:	48 89 b4 24 78 01 00 	mov    %rsi,0x178(%rsp)
  847778:	00 
  847779:	8b 4c 24 60          	mov    0x60(%rsp),%ecx
  84777d:	89 8c 24 80 01 00 00 	mov    %ecx,0x180(%rsp)
  847784:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
  847788:	89 8c 24 84 01 00 00 	mov    %ecx,0x184(%rsp)
  84778f:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  847796:	00 
  847797:	eb 0c                	jmp    8477a5 <<gpui_gpu::renderer::RendererState>::render+0x18d5>
  847799:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  8477a0:	00 00 00 00 00 
  8477a5:	c7 84 24 f0 02 00 00 	movl   $0x0,0x2f0(%rsp)
  8477ac:	00 00 00 00 
  8477b0:	48 c7 84 24 e8 02 00 	movq   $0x0,0x2e8(%rsp)
  8477b7:	00 00 00 00 00 
  8477bc:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  8477c3:	00 
  8477c4:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
  8477cb:	00 
  8477cc:	48 8d 94 24 e8 02 00 	lea    0x2e8(%rsp),%rdx
  8477d3:	00 
  8477d4:	48 8b 8c 24 a0 03 00 	mov    0x3a0(%rsp),%rcx
  8477db:	00 
  8477dc:	e8 2f bc ff ff       	call   843410 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  8477e1:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  8477e6:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
  8477ed:	00 
  8477ee:	48 8d 3c 10          	lea    (%rax,%rdx,1),%rdi
  8477f2:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8477f7:	48 8b 70 10          	mov    0x10(%rax),%rsi
  8477fb:	48 39 f7             	cmp    %rsi,%rdi
  8477fe:	4c 8b 44 24 18       	mov    0x18(%rsp),%r8
  847803:	0f 83 c2 0a 00 00    	jae    8482cb <<gpui_gpu::renderer::RendererState>::render+0x23fb>
  847809:	48 8b 40 08          	mov    0x8(%rax),%rax
  84780d:	8b 8c 24 08 01 00 00 	mov    0x108(%rsp),%ecx
  847814:	42 89 4c 00 08       	mov    %ecx,0x8(%rax,%r8,1)
  847819:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
  847820:	00 
  847821:	4a 89 0c 00          	mov    %rcx,(%rax,%r8,1)
  847825:	48 03 94 24 e0 00 00 	add    0xe0(%rsp),%rdx
  84782c:	00 
  84782d:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  847832:	4c 03 84 24 20 01 00 	add    0x120(%rsp),%r8
  847839:	00 
  84783a:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  84783f:	48 83 c1 04          	add    $0x4,%rcx
  847843:	48 39 8c 24 80 00 00 	cmp    %rcx,0x80(%rsp)
  84784a:	00 
  84784b:	0f 85 77 fd ff ff    	jne    8475c8 <<gpui_gpu::renderer::RendererState>::render+0x16f8>
  847851:	e9 3e fc ff ff       	jmp    847494 <<gpui_gpu::renderer::RendererState>::render+0x15c4>
  847856:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84785b:	48 8b 40 28          	mov    0x28(%rax),%rax
  84785f:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
  847866:	00 00 
  847868:	48 85 c0             	test   %rax,%rax
  84786b:	74 6b                	je     8478d8 <<gpui_gpu::renderer::RendererState>::render+0x1a08>
  84786d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  847872:	48 8b 49 20          	mov    0x20(%rcx),%rcx
  847876:	48 c1 e0 03          	shl    $0x3,%rax
  84787a:	31 ff                	xor    %edi,%edi
  84787c:	eb 1c                	jmp    84789a <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  84787e:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  847883:	01 f2                	add    %esi,%edx
  847885:	89 14 f9             	mov    %edx,(%rcx,%rdi,8)
  847888:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
  84788d:	89 54 f9 04          	mov    %edx,0x4(%rcx,%rdi,8)
  847891:	48 ff c7             	inc    %rdi
  847894:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
  847898:	74 32                	je     8478cc <<gpui_gpu::renderer::RendererState>::render+0x19fc>
  84789a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  84789f:	48 8b 72 58          	mov    0x58(%rdx),%rsi
  8478a3:	48 39 f7             	cmp    %rsi,%rdi
  8478a6:	0f 83 2c 0a 00 00    	jae    8482d8 <<gpui_gpu::renderer::RendererState>::render+0x2408>
  8478ac:	8b 74 f9 04          	mov    0x4(%rcx,%rdi,8),%esi
  8478b0:	83 fe 01             	cmp    $0x1,%esi
  8478b3:	75 c9                	jne    84787e <<gpui_gpu::renderer::RendererState>::render+0x19ae>
  8478b5:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  8478ba:	4c 8b 42 50          	mov    0x50(%rdx),%r8
  8478be:	ba 00 00 00 80       	mov    $0x80000000,%edx
  8478c3:	41 83 3c b8 00       	cmpl   $0x0,(%r8,%rdi,4)
  8478c8:	75 c3                	jne    84788d <<gpui_gpu::renderer::RendererState>::render+0x19bd>
  8478ca:	eb b2                	jmp    84787e <<gpui_gpu::renderer::RendererState>::render+0x19ae>
  8478cc:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  8478d1:	89 c0                	mov    %eax,%eax
  8478d3:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  8478d8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8478dd:	48 8d 78 30          	lea    0x30(%rax),%rdi
  8478e1:	48 c7 40 40 00 00 00 	movq   $0x0,0x40(%rax)
  8478e8:	00 
  8478e9:	48 89 bc 24 a0 00 00 	mov    %rdi,0xa0(%rsp)
  8478f0:	00 
  8478f1:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  8478f6:	31 d2                	xor    %edx,%edx
  8478f8:	e8 63 2e 00 00       	call   84a760 <<alloc::vec::Vec<u32>>::resize>
  8478fd:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847902:	48 8b 40 10          	mov    0x10(%rax),%rax
  847906:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  84790b:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  847910:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
  847917:	00 
  847918:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
  84791f:	00 
  847920:	48 89 84 24 e8 02 00 	mov    %rax,0x2e8(%rsp)
  847927:	00 
  847928:	48 c7 84 24 f0 02 00 	movq   $0x0,0x2f0(%rsp)
  84792f:	00 00 00 00 00 
  847934:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
  84793b:	00 
  84793c:	48 89 84 24 f8 02 00 	mov    %rax,0x2f8(%rsp)
  847943:	00 
  847944:	48 8b 84 24 48 01 00 	mov    0x148(%rsp),%rax
  84794b:	00 
  84794c:	48 89 84 24 00 03 00 	mov    %rax,0x300(%rsp)
  847953:	00 
  847954:	8b 44 24 78          	mov    0x78(%rsp),%eax
  847958:	89 84 24 08 03 00 00 	mov    %eax,0x308(%rsp)
  84795f:	eb 1a                	jmp    84797b <<gpui_gpu::renderer::RendererState>::render+0x1aab>
  847961:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  847966:	48 8d 41 fb          	lea    -0x5(%rcx),%rax
  84796a:	80 bc 24 b0 00 00 00 	cmpb   $0x0,0xb0(%rsp)
  847971:	00 
  847972:	48 0f 45 c8          	cmovne %rax,%rcx
  847976:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  84797b:	48 8d bc 24 58 02 00 	lea    0x258(%rsp),%rdi
  847982:	00 
  847983:	48 8d b4 24 e8 02 00 	lea    0x2e8(%rsp),%rsi
  84798a:	00 
  84798b:	ff 15 8f 6d 67 00    	call   *0x676d8f(%rip)        # ebe720 <_DYNAMIC+0x828>
  847991:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
  847998:	00 
  847999:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  84799e:	48 85 c0             	test   %rax,%rax
  8479a1:	0f 84 55 02 00 00    	je     847bfc <<gpui_gpu::renderer::RendererState>::render+0x1d2c>
  8479a7:	48 8b 8c 24 60 02 00 	mov    0x260(%rsp),%rcx
  8479ae:	00 
  8479af:	48 8b 94 24 68 02 00 	mov    0x268(%rsp),%rdx
  8479b6:	00 
  8479b7:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
  8479bc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8479c1:	0f b6 b0 41 03 00 00 	movzbl 0x341(%rax),%esi
  8479c8:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  8479cd:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  8479d4:	00 
  8479d5:	48 89 8c 24 80 00 00 	mov    %rcx,0x80(%rsp)
  8479dc:	00 
  8479dd:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
  8479e4:	00 
  8479e5:	48 89 94 24 70 01 00 	mov    %rdx,0x170(%rsp)
  8479ec:	00 
  8479ed:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  8479f4:	00 
  8479f5:	0f 10 00             	movups (%rax),%xmm0
  8479f8:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  8479fc:	f3 0f 6f 50 20       	movdqu 0x20(%rax),%xmm2
  847a01:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  847a08:	00 
  847a09:	f3 0f 7f 52 20       	movdqu %xmm2,0x20(%rdx)
  847a0e:	0f 11 4a 10          	movups %xmm1,0x10(%rdx)
  847a12:	0f 11 02             	movups %xmm0,(%rdx)
  847a15:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  847a1c:	00 
  847a1d:	0f 10 01             	movups (%rcx),%xmm0
  847a20:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  847a24:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847a28:	0f 11 42 40          	movups %xmm0,0x40(%rdx)
  847a2c:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847a33:	00 
  847a34:	e8 67 19 00 00       	call   8493a0 <gpui_gpu::renderer::compact_group>
  847a39:	88 84 24 b0 00 00 00 	mov    %al,0xb0(%rsp)
  847a40:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  847a45:	48 85 c0             	test   %rax,%rax
  847a48:	0f 84 13 ff ff ff    	je     847961 <<gpui_gpu::renderer::RendererState>::render+0x1a91>
  847a4e:	48 89 c1             	mov    %rax,%rcx
  847a51:	48 c1 e1 02          	shl    $0x2,%rcx
  847a55:	0f b6 84 24 b0 00 00 	movzbl 0xb0(%rsp),%eax
  847a5c:	00 
  847a5d:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
  847a64:	48 83 ca fa          	or     $0xfffffffffffffffa,%rdx
  847a68:	31 f6                	xor    %esi,%esi
  847a6a:	84 c0                	test   %al,%al
  847a6c:	40 0f 94 c6          	sete   %sil
  847a70:	c1 e6 1f             	shl    $0x1f,%esi
  847a73:	89 b4 24 b8 00 00 00 	mov    %esi,0xb8(%rsp)
  847a7a:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  847a7f:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  847a84:	01 d0                	add    %edx,%eax
  847a86:	89 44 24 10          	mov    %eax,0x10(%rsp)
  847a8a:	48 89 4c 24 18       	mov    %rcx,0x18(%rsp)
  847a8f:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  847a96:	00 
  847a97:	8b 54 08 fc          	mov    -0x4(%rax,%rcx,1),%edx
  847a9b:	48 8d bc 24 40 03 00 	lea    0x340(%rsp),%rdi
  847aa2:	00 
  847aa3:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  847aa8:	e8 e3 cb ff ff       	call   844690 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  847aad:	48 ff 8c 24 00 01 00 	decq   0x100(%rsp)
  847ab4:	00 
  847ab5:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  847aba:	48 01 44 24 20       	add    %rax,0x20(%rsp)
  847abf:	8b 84 24 b8 00 00 00 	mov    0xb8(%rsp),%eax
  847ac6:	0b 44 24 10          	or     0x10(%rsp),%eax
  847aca:	89 84 24 10 04 00 00 	mov    %eax,0x410(%rsp)
  847ad1:	48 8d 84 24 70 02 00 	lea    0x270(%rsp),%rax
  847ad8:	00 
  847ad9:	0f 10 00             	movups (%rax),%xmm0
  847adc:	0f 10 48 10          	movups 0x10(%rax),%xmm1
  847ae0:	0f 10 50 20          	movups 0x20(%rax),%xmm2
  847ae4:	48 8d 94 24 78 01 00 	lea    0x178(%rsp),%rdx
  847aeb:	00 
  847aec:	0f 11 52 50          	movups %xmm2,0x50(%rdx)
  847af0:	0f 11 4a 40          	movups %xmm1,0x40(%rdx)
  847af4:	0f 11 42 30          	movups %xmm0,0x30(%rdx)
  847af8:	48 8d 8c 24 a0 02 00 	lea    0x2a0(%rsp),%rcx
  847aff:	00 
  847b00:	0f 10 01             	movups (%rcx),%xmm0
  847b03:	0f 11 42 60          	movups %xmm0,0x60(%rdx)
  847b07:	0f 10 40 40          	movups 0x40(%rax),%xmm0
  847b0b:	0f 11 82 80 00 00 00 	movups %xmm0,0x80(%rdx)
  847b12:	48 8d 84 24 78 03 00 	lea    0x378(%rsp),%rax
  847b19:	00 
  847b1a:	0f 10 00             	movups (%rax),%xmm0
  847b1d:	0f 11 42 20          	movups %xmm0,0x20(%rdx)
  847b21:	48 8d 84 24 88 03 00 	lea    0x388(%rsp),%rax
  847b28:	00 
  847b29:	0f 10 00             	movups (%rax),%xmm0
  847b2c:	0f 11 42 70          	movups %xmm0,0x70(%rdx)
  847b30:	48 8b 84 24 70 03 00 	mov    0x370(%rsp),%rax
  847b37:	00 
  847b38:	48 89 84 24 90 01 00 	mov    %rax,0x190(%rsp)
  847b3f:	00 
  847b40:	0f 10 84 24 40 03 00 	movups 0x340(%rsp),%xmm0
  847b47:	00 
  847b48:	0f 10 8c 24 50 03 00 	movups 0x350(%rsp),%xmm1
  847b4f:	00 
  847b50:	f3 0f 6f 94 24 60 03 	movdqu 0x360(%rsp),%xmm2
  847b57:	00 00 
  847b59:	66 0f 7f 94 24 80 01 	movdqa %xmm2,0x180(%rsp)
  847b60:	00 00 
  847b62:	0f 29 8c 24 70 01 00 	movaps %xmm1,0x170(%rsp)
  847b69:	00 
  847b6a:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  847b71:	00 
  847b72:	48 8b 84 24 98 00 00 	mov    0x98(%rsp),%rax
  847b79:	00 
  847b7a:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  847b81:	00 
  847b82:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
  847b89:	00 
  847b8a:	48 89 84 24 18 03 00 	mov    %rax,0x318(%rsp)
  847b91:	00 
  847b92:	48 8b 84 24 08 04 00 	mov    0x408(%rsp),%rax
  847b99:	00 
  847b9a:	48 89 84 24 20 03 00 	mov    %rax,0x320(%rsp)
  847ba1:	00 
  847ba2:	48 8d 84 24 00 01 00 	lea    0x100(%rsp),%rax
  847ba9:	00 
  847baa:	48 89 84 24 28 03 00 	mov    %rax,0x328(%rsp)
  847bb1:	00 
  847bb2:	48 8d 84 24 10 04 00 	lea    0x410(%rsp),%rax
  847bb9:	00 
  847bba:	48 89 84 24 30 03 00 	mov    %rax,0x330(%rsp)
  847bc1:	00 
  847bc2:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
  847bc9:	00 
  847bca:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  847bcf:	48 8d 94 24 10 03 00 	lea    0x310(%rsp),%rdx
  847bd6:	00 
  847bd7:	e8 f4 c6 ff ff       	call   8442d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  847bdc:	8b 44 24 10          	mov    0x10(%rsp),%eax
  847be0:	03 44 24 30          	add    0x30(%rsp),%eax
  847be4:	89 44 24 10          	mov    %eax,0x10(%rsp)
  847be8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  847bed:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
  847bf1:	0f 85 93 fe ff ff    	jne    847a8a <<gpui_gpu::renderer::RendererState>::render+0x1bba>
  847bf7:	e9 65 fd ff ff       	jmp    847961 <<gpui_gpu::renderer::RendererState>::render+0x1a91>
  847bfc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847c01:	48 8b 78 28          	mov    0x28(%rax),%rdi
  847c05:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
  847c0c:	00 00 00 00 00 
  847c11:	48 85 ff             	test   %rdi,%rdi
  847c14:	0f 84 ca 00 00 00    	je     847ce4 <<gpui_gpu::renderer::RendererState>::render+0x1e14>
  847c1a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  847c1f:	4c 8b 40 20          	mov    0x20(%rax),%r8
  847c23:	48 c1 e7 03          	shl    $0x3,%rdi
  847c27:	83 7c 24 38 00       	cmpl   $0x0,0x38(%rsp)
  847c2c:	0f 84 46 06 00 00    	je     848278 <<gpui_gpu::renderer::RendererState>::render+0x23a8>
  847c32:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  847c39:	00 00 
  847c3b:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  847c42:	00 00 
  847c44:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847c4b:	00 00 
  847c4d:	45 31 c9             	xor    %r9d,%r9d
  847c50:	31 c9                	xor    %ecx,%ecx
  847c52:	eb 23                	jmp    847c77 <<gpui_gpu::renderer::RendererState>::render+0x1da7>
  847c54:	48 ff 44 24 10       	incq   0x10(%rsp)
  847c59:	49 ff c1             	inc    %r9
  847c5c:	4c 3b 4c 24 38       	cmp    0x38(%rsp),%r9
  847c61:	b8 00 00 00 00       	mov    $0x0,%eax
  847c66:	4c 0f 44 c8          	cmove  %rax,%r9
  847c6a:	48 ff c1             	inc    %rcx
  847c6d:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
  847c71:	0f 84 88 00 00 00    	je     847cff <<gpui_gpu::renderer::RendererState>::render+0x1e2f>
  847c77:	45 8b 54 c8 04       	mov    0x4(%r8,%rcx,8),%r10d
  847c7c:	44 89 d0             	mov    %r10d,%eax
  847c7f:	f7 d8                	neg    %eax
  847c81:	70 d1                	jo     847c54 <<gpui_gpu::renderer::RendererState>::render+0x1d84>
  847c83:	45 2b 14 c8          	sub    (%r8,%rcx,8),%r10d
  847c87:	74 d0                	je     847c59 <<gpui_gpu::renderer::RendererState>::render+0x1d89>
  847c89:	48 89 c8             	mov    %rcx,%rax
  847c8c:	48 c1 e8 20          	shr    $0x20,%rax
  847c90:	74 0f                	je     847ca1 <<gpui_gpu::renderer::RendererState>::render+0x1dd1>
  847c92:	48 89 c8             	mov    %rcx,%rax
  847c95:	31 d2                	xor    %edx,%edx
  847c97:	48 f7 74 24 38       	divq   0x38(%rsp)
  847c9c:	4c 89 ca             	mov    %r9,%rdx
  847c9f:	eb 08                	jmp    847ca9 <<gpui_gpu::renderer::RendererState>::render+0x1dd9>
  847ca1:	89 c8                	mov    %ecx,%eax
  847ca3:	31 d2                	xor    %edx,%edx
  847ca5:	f7 74 24 38          	divl   0x38(%rsp)
  847ca9:	c1 e2 04             	shl    $0x4,%edx
  847cac:	c1 e0 04             	shl    $0x4,%eax
  847caf:	44 8d 5a 10          	lea    0x10(%rdx),%r11d
  847cb3:	45 39 de             	cmp    %r11d,%r14d
  847cb6:	45 0f 42 de          	cmovb  %r14d,%r11d
  847cba:	8d 70 10             	lea    0x10(%rax),%esi
  847cbd:	41 39 f7             	cmp    %esi,%r15d
  847cc0:	41 0f 42 f7          	cmovb  %r15d,%esi
  847cc4:	41 29 d3             	sub    %edx,%r11d
  847cc7:	29 c6                	sub    %eax,%esi
  847cc9:	41 0f af f3          	imul   %r11d,%esi
  847ccd:	48 c1 e6 04          	shl    $0x4,%rsi
  847cd1:	48 01 74 24 18       	add    %rsi,0x18(%rsp)
  847cd6:	4c 0f af d6          	imul   %rsi,%r10
  847cda:	4c 01 54 24 30       	add    %r10,0x30(%rsp)
  847cdf:	e9 75 ff ff ff       	jmp    847c59 <<gpui_gpu::renderer::RendererState>::render+0x1d89>
  847ce4:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  847ceb:	00 00 
  847ced:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  847cf4:	00 00 
  847cf6:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  847cfd:	00 00 
  847cff:	41 f6 c5 01          	test   $0x1,%r13b
  847d03:	74 53                	je     847d58 <<gpui_gpu::renderer::RendererState>::render+0x1e88>
  847d05:	66 0f 6e 84 24 5c 01 	movd   0x15c(%rsp),%xmm0
  847d0c:	00 00 
  847d0e:	66 0f 7e c0          	movd   %xmm0,%eax
  847d12:	85 c0                	test   %eax,%eax
  847d14:	0f 99 c1             	setns  %cl
  847d17:	89 c2                	mov    %eax,%edx
  847d19:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
  847d1f:	81 c2 00 00 80 ff    	add    $0xff800000,%edx
  847d25:	81 fa 00 00 00 7f    	cmp    $0x7f000000,%edx
  847d2b:	0f 92 c2             	setb   %dl
  847d2e:	20 ca                	and    %cl,%dl
  847d30:	ff c8                	dec    %eax
  847d32:	3d ff ff 7f 00       	cmp    $0x7fffff,%eax
  847d37:	0f 92 c0             	setb   %al
  847d3a:	08 d0                	or     %dl,%al
  847d3c:	b8 02 00 00 00       	mov    $0x2,%eax
  847d41:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  847d48:	00 
  847d49:	66 0f 7e 84 24 ec 00 	movd   %xmm0,0xec(%rsp)
  847d50:	00 00 
  847d52:	0f 84 16 05 00 00    	je     84826e <<gpui_gpu::renderer::RendererState>::render+0x239e>
  847d58:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  847d5f:	00 
  847d60:	48 83 c1 18          	add    $0x18,%rcx
  847d64:	31 d2                	xor    %edx,%edx
  847d66:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  847d6d:	00 
  847d6e:	48 3b 84 24 b8 03 00 	cmp    0x3b8(%rsp),%rax
  847d75:	00 
  847d76:	0f 95 c2             	setne  %dl
  847d79:	31 c0                	xor    %eax,%eax
  847d7b:	83 fd 28             	cmp    $0x28,%ebp
  847d7e:	0f 94 c0             	sete   %al
  847d81:	41 83 e4 01          	and    $0x1,%r12d
  847d85:	41 8d 04 84          	lea    (%r12,%rax,4),%eax
  847d89:	8d 04 d0             	lea    (%rax,%rdx,8),%eax
  847d8c:	0b 84 24 98 00 00 00 	or     0x98(%rsp),%eax
  847d93:	0f 10 01             	movups (%rcx),%xmm0
  847d96:	0f 11 84 24 68 02 00 	movups %xmm0,0x268(%rsp)
  847d9d:	00 
  847d9e:	44 89 b4 24 58 02 00 	mov    %r14d,0x258(%rsp)
  847da5:	00 
  847da6:	44 89 bc 24 5c 02 00 	mov    %r15d,0x25c(%rsp)
  847dad:	00 
  847dae:	48 8b 4c 24 38       	mov    0x38(%rsp),%rcx
  847db3:	89 8c 24 60 02 00 00 	mov    %ecx,0x260(%rsp)
  847dba:	89 84 24 64 02 00 00 	mov    %eax,0x264(%rsp)
  847dc1:	f3 0f 10 84 24 ec 00 	movss  0xec(%rsp),%xmm0
  847dc8:	00 00 
  847dca:	f3 0f 11 84 24 78 02 	movss  %xmm0,0x278(%rsp)
  847dd1:	00 00 
  847dd3:	48 c7 84 24 7c 02 00 	movq   $0x0,0x27c(%rsp)
  847dda:	00 00 00 00 00 
  847ddf:	c7 84 24 84 02 00 00 	movl   $0x0,0x284(%rsp)
  847de6:	00 00 00 00 
  847dea:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
  847def:	49 8d b5 28 02 00 00 	lea    0x228(%r13),%rsi
  847df6:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  847dfb:	48 8d 8c 24 58 02 00 	lea    0x258(%rsp),%rcx
  847e02:	00 
  847e03:	41 b8 30 00 00 00    	mov    $0x30,%r8d
  847e09:	48 8b ac 24 d0 03 00 	mov    0x3d0(%rsp),%rbp
  847e10:	00 
  847e11:	48 89 ef             	mov    %rbp,%rdi
  847e14:	31 d2                	xor    %edx,%edx
  847e16:	ff 15 0c 69 67 00    	call   *0x67690c(%rip)        # ebe728 <_DYNAMIC+0x830>
  847e1c:	49 8b 4d 08          	mov    0x8(%r13),%rcx
  847e20:	4d 8b 45 10          	mov    0x10(%r13),%r8
  847e24:	49 c1 e0 04          	shl    $0x4,%r8
  847e28:	48 8b bc 24 c0 02 00 	mov    0x2c0(%rsp),%rdi
  847e2f:	00 
  847e30:	4c 8b a4 24 50 01 00 	mov    0x150(%rsp),%r12
  847e37:	00 
  847e38:	4c 89 e6             	mov    %r12,%rsi
  847e3b:	48 89 ea             	mov    %rbp,%rdx
  847e3e:	e8 8d ca ff ff       	call   8448d0 <<gpui_gpu::renderer::Buffer>::write>
  847e43:	49 8d bd 78 02 00 00 	lea    0x278(%r13),%rdi
  847e4a:	48 89 bc 24 98 00 00 	mov    %rdi,0x98(%rsp)
  847e51:	00 
  847e52:	49 8b 4d 20          	mov    0x20(%r13),%rcx
  847e56:	4d 8b 45 28          	mov    0x28(%r13),%r8
  847e5a:	49 c1 e0 03          	shl    $0x3,%r8
  847e5e:	4c 89 e6             	mov    %r12,%rsi
  847e61:	48 89 ea             	mov    %rbp,%rdx
  847e64:	e8 67 ca ff ff       	call   8448d0 <<gpui_gpu::renderer::Buffer>::write>
  847e69:	49 8d bd a0 02 00 00 	lea    0x2a0(%r13),%rdi
  847e70:	48 89 bc 24 90 00 00 	mov    %rdi,0x90(%rsp)
  847e77:	00 
  847e78:	49 8b 4d 38          	mov    0x38(%r13),%rcx
  847e7c:	4d 8b 45 40          	mov    0x40(%r13),%r8
  847e80:	49 c1 e0 02          	shl    $0x2,%r8
  847e84:	4c 89 e6             	mov    %r12,%rsi
  847e87:	48 89 ea             	mov    %rbp,%rdx
  847e8a:	e8 41 ca ff ff       	call   8448d0 <<gpui_gpu::renderer::Buffer>::write>
  847e8f:	49 8d bd c8 02 00 00 	lea    0x2c8(%r13),%rdi
  847e96:	48 89 7c 24 20       	mov    %rdi,0x20(%rsp)
  847e9b:	49 8b 4d 68          	mov    0x68(%r13),%rcx
  847e9f:	4d 8b 45 70          	mov    0x70(%r13),%r8
  847ea3:	49 c1 e0 05          	shl    $0x5,%r8
  847ea7:	4c 89 e6             	mov    %r12,%rsi
  847eaa:	48 89 ea             	mov    %rbp,%rdx
  847ead:	e8 1e ca ff ff       	call   8448d0 <<gpui_gpu::renderer::Buffer>::write>
  847eb2:	49 8d 44 24 18       	lea    0x18(%r12),%rax
  847eb7:	49 8d 8d c8 00 00 00 	lea    0xc8(%r13),%rcx
  847ebe:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
  847ec5:	00 00 00 00 00 
  847eca:	48 8b 54 24 38       	mov    0x38(%rsp),%rdx
  847ecf:	48 89 94 24 68 01 00 	mov    %rdx,0x168(%rsp)
  847ed6:	00 
  847ed7:	48 c7 84 24 88 01 00 	movq   $0x0,0x188(%rsp)
  847ede:	00 00 00 00 00 
  847ee3:	0f 57 c0             	xorps  %xmm0,%xmm0
  847ee6:	0f 11 84 24 70 01 00 	movups %xmm0,0x170(%rsp)
  847eed:	00 
  847eee:	c7 84 24 80 01 00 00 	movl   $0x0,0x180(%rsp)
  847ef5:	00 00 00 00 
  847ef9:	48 8b 94 24 c0 02 00 	mov    0x2c0(%rsp),%rdx
  847f00:	00 
  847f01:	48 89 94 24 90 01 00 	mov    %rdx,0x190(%rsp)
  847f08:	00 
  847f09:	0f 11 84 24 98 01 00 	movups %xmm0,0x198(%rsp)
  847f10:	00 
  847f11:	c7 84 24 a8 01 00 00 	movl   $0x1,0x1a8(%rsp)
  847f18:	01 00 00 00 
  847f1c:	48 c7 84 24 b0 01 00 	movq   $0x0,0x1b0(%rsp)
  847f23:	00 00 00 00 00 
  847f28:	48 8b 94 24 98 00 00 	mov    0x98(%rsp),%rdx
  847f2f:	00 
  847f30:	48 89 94 24 b8 01 00 	mov    %rdx,0x1b8(%rsp)
  847f37:	00 
  847f38:	0f 11 84 24 c0 01 00 	movups %xmm0,0x1c0(%rsp)
  847f3f:	00 
  847f40:	c7 84 24 d0 01 00 00 	movl   $0x2,0x1d0(%rsp)
  847f47:	02 00 00 00 
  847f4b:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
  847f52:	00 00 00 00 00 
  847f57:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  847f5e:	00 
  847f5f:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
  847f66:	00 
  847f67:	0f 11 84 24 e8 01 00 	movups %xmm0,0x1e8(%rsp)
  847f6e:	00 
  847f6f:	c7 84 24 f8 01 00 00 	movl   $0x3,0x1f8(%rsp)
  847f76:	03 00 00 00 
  847f7a:	48 c7 84 24 00 02 00 	movq   $0x4,0x200(%rsp)
  847f81:	00 04 00 00 00 
  847f86:	48 89 8c 24 08 02 00 	mov    %rcx,0x208(%rsp)
  847f8d:	00 
  847f8e:	c7 84 24 20 02 00 00 	movl   $0x4,0x220(%rsp)
  847f95:	04 00 00 00 
  847f99:	48 c7 84 24 28 02 00 	movq   $0x0,0x228(%rsp)
  847fa0:	00 00 00 00 00 
  847fa5:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
  847faa:	48 89 8c 24 30 02 00 	mov    %rcx,0x230(%rsp)
  847fb1:	00 
  847fb2:	0f 11 84 24 38 02 00 	movups %xmm0,0x238(%rsp)
  847fb9:	00 
  847fba:	c7 84 24 48 02 00 00 	movl   $0x5,0x248(%rsp)
  847fc1:	05 00 00 00 
  847fc5:	48 8d 0d 38 8c 89 ff 	lea    -0x7673c8(%rip),%rcx        # e0c04 <anon.fd87c01464a3e1b3301f7c003a8d34c5.0.llvm.7974869727893897930+0x2c50>
  847fcc:	48 89 8c 24 58 03 00 	mov    %rcx,0x358(%rsp)
  847fd3:	00 
  847fd4:	48 c7 84 24 60 03 00 	movq   $0xa,0x360(%rsp)
  847fdb:	00 0a 00 00 00 
  847fe0:	48 89 84 24 40 03 00 	mov    %rax,0x340(%rsp)
  847fe7:	00 
  847fe8:	48 8d 84 24 60 01 00 	lea    0x160(%rsp),%rax
  847fef:	00 
  847ff0:	48 89 84 24 48 03 00 	mov    %rax,0x348(%rsp)
  847ff7:	00 
  847ff8:	48 c7 84 24 50 03 00 	movq   $0x6,0x350(%rsp)
  847fff:	00 06 00 00 00 
  848004:	48 8d b4 24 40 03 00 	lea    0x340(%rsp),%rsi
  84800b:	00 
  84800c:	4c 89 e7             	mov    %r12,%rdi
  84800f:	ff 15 1b 67 67 00    	call   *0x67671b(%rip)        # ebe730 <_DYNAMIC+0x838>
  848015:	49 89 c5             	mov    %rax,%r13
  848018:	48 89 84 24 10 03 00 	mov    %rax,0x310(%rsp)
  84801f:	00 
  848020:	48 8d 94 24 10 03 00 	lea    0x310(%rsp),%rdx
  848027:	00 
  848028:	4c 89 e7             	mov    %r12,%rdi
  84802b:	48 8b b4 24 00 04 00 	mov    0x400(%rsp),%rsi
  848032:	00 
  848033:	e8 38 cf ff ff       	call   844f70 <<gpui_gpu::renderer::GpuContext>::submit>
  848038:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  84803d:	31 ed                	xor    %ebp,%ebp
  84803f:	48 8b 84 24 b0 03 00 	mov    0x3b0(%rsp),%rax
  848046:	00 
  848047:	48 3b 84 24 b8 03 00 	cmp    0x3b8(%rsp),%rax
  84804e:	00 
  84804f:	40 0f 95 c5          	setne  %bpl
  848053:	c1 e5 1f             	shl    $0x1f,%ebp
  848056:	44 09 f5             	or     %r14d,%ebp
  848059:	49 c1 e7 20          	shl    $0x20,%r15
  84805d:	4c 09 fd             	or     %r15,%rbp
  848060:	48 8b 03             	mov    (%rbx),%rax
  848063:	48 85 c0             	test   %rax,%rax
  848066:	74 0f                	je     848077 <<gpui_gpu::renderer::RendererState>::render+0x21a7>
  848068:	f0 48 ff 08          	lock decq (%rax)
  84806c:	75 09                	jne    848077 <<gpui_gpu::renderer::RendererState>::render+0x21a7>
  84806e:	48 89 df             	mov    %rbx,%rdi
  848071:	ff 15 11 63 67 00    	call   *0x676311(%rip)        # ebe388 <_DYNAMIC+0x490>
  848077:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  84807c:	4c 89 a8 30 03 00 00 	mov    %r13,0x330(%rax)
  848083:	48 89 a8 38 03 00 00 	mov    %rbp,0x338(%rax)
  84808a:	4c 8b 40 10          	mov    0x10(%rax),%r8
  84808e:	48 8b 70 28          	mov    0x28(%rax),%rsi
  848092:	48 8b 48 70          	mov    0x70(%rax),%rcx
  848096:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
  84809d:	00 
  84809e:	49 c1 e0 04          	shl    $0x4,%r8
  8480a2:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  8480a7:	49 8d 3c 90          	lea    (%r8,%rdx,4),%rdi
  8480ab:	48 8d 34 f7          	lea    (%rdi,%rsi,8),%rsi
  8480af:	48 89 cf             	mov    %rcx,%rdi
  8480b2:	48 c1 e7 05          	shl    $0x5,%rdi
  8480b6:	48 8d 0c 37          	lea    (%rdi,%rsi,1),%rcx
  8480ba:	48 83 c1 30          	add    $0x30,%rcx
  8480be:	48 89 8c 24 90 00 00 	mov    %rcx,0x90(%rsp)
  8480c5:	00 
  8480c6:	48 8b b8 70 02 00 00 	mov    0x270(%rax),%rdi
  8480cd:	48 03 b8 48 02 00 00 	add    0x248(%rax),%rdi
  8480d4:	48 03 b8 98 02 00 00 	add    0x298(%rax),%rdi
  8480db:	48 03 b8 c0 02 00 00 	add    0x2c0(%rax),%rdi
  8480e2:	48 03 b8 e8 02 00 00 	add    0x2e8(%rax),%rdi
  8480e9:	48 8b b0 00 03 00 00 	mov    0x300(%rax),%rsi
  8480f0:	48 03 b0 08 03 00 00 	add    0x308(%rax),%rsi
  8480f7:	44 8b 88 50 01 00 00 	mov    0x150(%rax),%r9d
  8480fe:	4d 0f af c9          	imul   %r9,%r9
  848102:	4c 8b 9c 24 d8 00 00 	mov    0xd8(%rsp),%r11
  848109:	00 
  84810a:	4c 89 d9             	mov    %r11,%rcx
  84810d:	48 29 d1             	sub    %rdx,%rcx
  848110:	4c 8b 54 24 48       	mov    0x48(%rsp),%r10
  848115:	4d 89 d4             	mov    %r10,%r12
  848118:	48 8b ac 24 40 01 00 	mov    0x140(%rsp),%rbp
  84811f:	00 
  848120:	49 29 ec             	sub    %rbp,%r12
  848123:	48 8b 98 60 01 00 00 	mov    0x160(%rax),%rbx
  84812a:	48 ff c3             	inc    %rbx
  84812d:	49 c7 c6 ff ff ff ff 	mov    $0xffffffffffffffff,%r14
  848134:	4c 0f 45 f3          	cmovne %rbx,%r14
  848138:	48 8b 18             	mov    (%rax),%rbx
  84813b:	48 c1 e3 04          	shl    $0x4,%rbx
  84813f:	4c 8b 78 48          	mov    0x48(%rax),%r15
  848143:	4c 03 78 30          	add    0x30(%rax),%r15
  848147:	4c 8b 68 18          	mov    0x18(%rax),%r13
  84814b:	4a 8d 1c eb          	lea    (%rbx,%r13,8),%rbx
  84814f:	4a 8d 1c bb          	lea    (%rbx,%r15,4),%rbx
  848153:	4c 8b 78 60          	mov    0x60(%rax),%r15
  848157:	49 c1 e7 05          	shl    $0x5,%r15
  84815b:	49 01 df             	add    %rbx,%r15
  84815e:	48 8b 98 38 01 00 00 	mov    0x138(%rax),%rbx
  848165:	4c 8b a8 30 01 00 00 	mov    0x130(%rax),%r13
  84816c:	4c 89 b0 60 01 00 00 	mov    %r14,0x160(%rax)
  848173:	4c 89 90 68 01 00 00 	mov    %r10,0x168(%rax)
  84817a:	4f 8d 34 1b          	lea    (%r11,%r11,1),%r14
  84817e:	4c 89 b0 70 01 00 00 	mov    %r14,0x170(%rax)
  848185:	48 c7 80 78 01 00 00 	movq   $0x1,0x178(%rax)
  84818c:	01 00 00 00 
  848190:	4c 89 90 80 01 00 00 	mov    %r10,0x180(%rax)
  848197:	48 89 90 88 01 00 00 	mov    %rdx,0x188(%rax)
  84819e:	4c 89 98 90 01 00 00 	mov    %r11,0x190(%rax)
  8481a5:	48 89 88 98 01 00 00 	mov    %rcx,0x198(%rax)
  8481ac:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  8481b1:	48 89 88 a0 01 00 00 	mov    %rcx,0x1a0(%rax)
  8481b8:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
  8481bd:	48 89 88 a8 01 00 00 	mov    %rcx,0x1a8(%rax)
  8481c4:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  8481c9:	48 89 88 b0 01 00 00 	mov    %rcx,0x1b0(%rax)
  8481d0:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  8481d7:	00 
  8481d8:	48 89 88 b8 01 00 00 	mov    %rcx,0x1b8(%rax)
  8481df:	4c 89 80 c0 01 00 00 	mov    %r8,0x1c0(%rax)
  8481e6:	48 8b 94 24 38 01 00 	mov    0x138(%rsp),%rdx
  8481ed:	00 
  8481ee:	48 89 90 c8 01 00 00 	mov    %rdx,0x1c8(%rax)
  8481f5:	48 89 a8 d0 01 00 00 	mov    %rbp,0x1d0(%rax)
  8481fc:	4c 89 a0 d8 01 00 00 	mov    %r12,0x1d8(%rax)
  848203:	48 8b 8c 24 c0 03 00 	mov    0x3c0(%rsp),%rcx
  84820a:	00 
  84820b:	48 89 88 e0 01 00 00 	mov    %rcx,0x1e0(%rax)
  848212:	48 89 b8 e8 01 00 00 	mov    %rdi,0x1e8(%rax)
  848219:	4c 89 88 f0 01 00 00 	mov    %r9,0x1f0(%rax)
  848220:	49 01 dd             	add    %rbx,%r13
  848223:	48 89 98 f8 01 00 00 	mov    %rbx,0x1f8(%rax)
  84822a:	4c 89 a8 00 02 00 00 	mov    %r13,0x200(%rax)
  848231:	4c 89 b8 08 02 00 00 	mov    %r15,0x208(%rax)
  848238:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
  84823f:	00 
  848240:	48 89 88 10 02 00 00 	mov    %rcx,0x210(%rax)
  848247:	48 89 b0 18 02 00 00 	mov    %rsi,0x218(%rax)
  84824e:	c6 80 20 02 00 00 00 	movb   $0x0,0x220(%rax)
  848255:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  84825a:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  84825f:	48 89 47 08          	mov    %rax,0x8(%rdi)
  848263:	c7 07 ff ff ff ff    	movl   $0xffffffff,(%rdi)
  848269:	e9 58 dd ff ff       	jmp    845fc6 <<gpui_gpu::renderer::RendererState>::render+0xf6>
  84826e:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  848273:	e9 40 dd ff ff       	jmp    845fb8 <<gpui_gpu::renderer::RendererState>::render+0xe8>
  848278:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  84827f:	00 00 
  848281:	31 c0                	xor    %eax,%eax
  848283:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  84828a:	00 00 
  84828c:	eb 12                	jmp    8482a0 <<gpui_gpu::renderer::RendererState>::render+0x23d0>
  84828e:	48 ff 44 24 10       	incq   0x10(%rsp)
  848293:	48 83 c0 08          	add    $0x8,%rax
  848297:	48 39 c7             	cmp    %rax,%rdi
  84829a:	0f 84 56 fa ff ff    	je     847cf6 <<gpui_gpu::renderer::RendererState>::render+0x1e26>
  8482a0:	41 8b 4c 00 04       	mov    0x4(%r8,%rax,1),%ecx
  8482a5:	89 ca                	mov    %ecx,%edx
  8482a7:	f7 da                	neg    %edx
  8482a9:	70 e3                	jo     84828e <<gpui_gpu::renderer::RendererState>::render+0x23be>
  8482ab:	41 39 0c 00          	cmp    %ecx,(%r8,%rax,1)
  8482af:	74 e2                	je     848293 <<gpui_gpu::renderer::RendererState>::render+0x23c3>
  8482b1:	48 8d 3d 08 41 62 00 	lea    0x624108(%rip),%rdi        # e6c3c0 <anon.05208c8d5a610a9bacc83ca514c8f163.29.llvm.11505083265099729037+0x10>
  8482b8:	ff 15 7a 64 67 00    	call   *0x67647a(%rip)        # ebe738 <_DYNAMIC+0x840>
  8482be:	48 8d 3d 63 3f 62 00 	lea    0x623f63(%rip),%rdi        # e6c228 <anon.e1d0e6d22dab240d16e467862c9a25f9.3.llvm.16263298608435197549+0x1098>
  8482c5:	ff 15 95 5f 67 00    	call   *0x675f95(%rip)        # ebe260 <_DYNAMIC+0x368>
  8482cb:	48 8d 15 6e 3f 62 00 	lea    0x623f6e(%rip),%rdx        # e6c240 <anon.e1d0e6d22dab240d16e467862c9a25f9.3.llvm.16263298608435197549+0x10b0>
  8482d2:	ff 15 00 61 67 00    	call   *0x676100(%rip)        # ebe3d8 <_DYNAMIC+0x4e0>
  8482d8:	48 8d 15 31 3f 62 00 	lea    0x623f31(%rip),%rdx        # e6c210 <anon.e1d0e6d22dab240d16e467862c9a25f9.3.llvm.16263298608435197549+0x1080>
  8482df:	ff 15 f3 60 67 00    	call   *0x6760f3(%rip)        # ebe3d8 <_DYNAMIC+0x4e0>
  8482e5:	49 89 c6             	mov    %rax,%r14
  8482e8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  8482ed:	4c 89 a8 30 03 00 00 	mov    %r13,0x330(%rax)
  8482f4:	48 89 a8 38 03 00 00 	mov    %rbp,0x338(%rax)
  8482fb:	4c 89 f7             	mov    %r14,%rdi
  8482fe:	e8 ed ef 61 00       	call   e672f0 <_Unwind_Resume@plt>
  848303:	49 89 c6             	mov    %rax,%r14
  848306:	f0 49 ff 4d 00       	lock decq 0x0(%r13)
  84830b:	75 20                	jne    84832d <<gpui_gpu::renderer::RendererState>::render+0x245d>
  84830d:	48 8d bc 24 10 03 00 	lea    0x310(%rsp),%rdi
  848314:	00 
  848315:	ff 15 6d 60 67 00    	call   *0x67606d(%rip)        # ebe388 <_DYNAMIC+0x490>
  84831b:	eb 10                	jmp    84832d <<gpui_gpu::renderer::RendererState>::render+0x245d>
  84831d:	ff 15 3d 5e 67 00    	call   *0x675e3d(%rip)        # ebe160 <_DYNAMIC+0x268>
  848323:	49 89 c6             	mov    %rax,%r14
  848326:	48 c7 03 00 00 00 00 	movq   $0x0,(%rbx)
  84832d:	4c 89 f7             	mov    %r14,%rdi
  848330:	e8 bb ef 61 00       	call   e672f0 <_Unwind_Resume@plt>
