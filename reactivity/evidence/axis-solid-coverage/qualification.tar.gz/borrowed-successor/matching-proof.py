from pathlib import Path
import json
OUT=Path('/tmp/gpui-half-open-borrow-evidence');labels=['shipping','by-value','borrowed'];rows={}
for label in labels:
 p=OUT/('cost-'+label);build=json.loads((p/'build.json').read_text());manifest=json.loads((p/'manifest.json').read_text());assert build['exit']==0 and build['guards_match'];assert all(not a['fresh'] and a['profile']['opt_level']=='3' for a in manifest['artifacts'])
 rows[label]={'guard':build['guard_before'],'compiler':build['compiler'],'env':build['environment'],'artifacts':{a['target']['name']:{k:a[k] for k in ['profile','features']} for a in manifest['artifacts']},'shader_sha256':manifest['wgsl_sha256']}
reference=rows['shipping'];proof={'lanes':labels,'same_physical_source_path':'/tmp/gpui-half-open-borrow-sol','comparisons':{},'fresh_false_opt3_three_artifacts_each':True}
for label in labels[1:]:
 row=rows[label];assert reference['compiler']==row['compiler'];assert reference['env']==row['env'];assert reference['artifacts']==row['artifacts'];assert reference['shader_sha256']==row['shader_sha256'];assert reference['guard'].keys()==row['guard'].keys()
 changed=[k for k in reference['guard'] if reference['guard'][k]!=row['guard'][k]];assert sorted(changed)==['reactivity/crates/canvas/src/canvas.rs','reactivity/crates/gpu/src/renderer.rs'];proof['comparisons'][label]={'only_source_guard_changes':changed,'compiler_env_profiles_features_shader_equal':True}
proof['guarded_files']=len(reference['guard']);proof['shader_sha256']=reference['shader_sha256'];(OUT/'matching-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
