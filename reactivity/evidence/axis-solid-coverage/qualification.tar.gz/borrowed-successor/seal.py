from pathlib import Path
import datetime,gzip,hashlib,json,os,tarfile,time,subprocess
OUT=Path('/tmp/gpui-half-open-borrow-evidence');ARCHIVE=Path('/tmp/gpui-half-open-borrow-qualified.tar.gz');SEAL=Path('/tmp/gpui-half-open-borrow-qualified-seal.json')
ROOTS={'borrowed':OUT}
assert not ARCHIVE.exists() and not SEAL.exists()
assert not subprocess.check_output(['git','-c','safe.directory=/tmp/gpui-half-open-borrow-sol','-C','/tmp/gpui-half-open-borrow-sol','status','--porcelain'],text=True)
assert json.loads((OUT/'cost-capture.json').read_text())['clean_after']
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
files=[];external=[];last=time.monotonic()
for label,root in ROOTS.items():
 for path in sorted(root.rglob('*')):
  if not path.is_file():continue
  assert not path.is_symlink(),str(path)
  if path.name in ['payload-manifest.json','external-elf-manifest.json']:continue
  with path.open('rb') as f:elf=f.read(4)==b'\x7fELF'
  row={'archive_path':str(Path(label)/path.relative_to(root)),'original_path':str(path),'bytes':path.stat().st_size,'sha256':digest(path)}
  (external if elf else files).append(row)
  if time.monotonic()-last>30:print(json.dumps({'phase':'hash','payloads':len(files),'external_elfs':len(external)}),flush=True);last=time.monotonic()
manifest={'payloads':files,'bytes':sum(x['bytes'] for x in files),'scope':'Original evidence plus full static assembly/guards; all ELF instances remain external, separately hashed. Failed/incomplete controls retained.'}
(OUT/'payload-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');(OUT/'external-elf-manifest.json').write_text(json.dumps({'external_elfs':external,'bytes':sum(x['bytes'] for x in external)},indent=2)+'\n')
with ARCHIVE.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,compresslevel=1,mtime=0) as zipped,tarfile.open(fileobj=zipped,mode='w|') as tar:
 for row in files:
  tar.add(row['original_path'],arcname=row['archive_path'],recursive=False)
  if time.monotonic()-last>30:print(json.dumps({'phase':'archive','last':row['archive_path']}),flush=True);last=time.monotonic()
 for name in ['payload-manifest.json','external-elf-manifest.json']:tar.add(OUT/name,arcname='borrowed/'+name,recursive=False)
print(json.dumps({'phase':'archive-written','bytes':ARCHIVE.stat().st_size}),flush=True)
# Reopen every archived member and verify its exact recorded hash/size.
expected={r['archive_path']:r for r in files}
for name in ['payload-manifest.json','external-elf-manifest.json']:
 p=OUT/name;expected['borrowed/'+name]={'sha256':digest(p),'bytes':p.stat().st_size}
seen=set()
with tarfile.open(ARCHIVE,'r:gz') as tar:
 for entry in tar:
  assert entry.name in expected and entry.name not in seen and entry.isfile();seen.add(entry.name);h=hashlib.sha256();size=0
  stream=tar.extractfile(entry)
  for block in iter(lambda:stream.read(8*1024*1024),b''):h.update(block);size+=len(block)
  assert h.hexdigest()==expected[entry.name]['sha256'] and size==expected[entry.name]['bytes'],entry.name
  if time.monotonic()-last>30:print(json.dumps({'phase':'reopen','members':len(seen)}),flush=True);last=time.monotonic()
assert seen==set(expected)
seal={'utc':datetime.datetime.now(datetime.UTC).isoformat(),'source':'e872330f303deae4a7fba191af31e5bffa574054','archive':str(ARCHIVE),'archive_sha256':digest(ARCHIVE),'archive_bytes':ARCHIVE.stat().st_size,'payload_manifest_sha256':digest(OUT/'payload-manifest.json'),'external_manifest_sha256':digest(OUT/'external-elf-manifest.json'),'payload_files':len(files),'archive_members':len(seen),'payload_bytes':manifest['bytes'],'external_elfs':len(external),'external_elf_bytes':sum(x['bytes'] for x in external),'reopened_all_members':True,'performance_claim':False}
SEAL.write_text(json.dumps(seal,indent=2)+'\n');ARCHIVE.chmod(0o444);print(json.dumps(seal,indent=2),flush=True)
