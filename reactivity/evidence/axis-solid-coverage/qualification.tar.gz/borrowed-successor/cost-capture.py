from pathlib import Path
import datetime,hashlib,json,os,shutil,signal,subprocess
ROOT=Path('/tmp/gpui-half-open-borrow-sol');OUT=Path('/tmp/gpui-half-open-borrow-evidence');TARGET=Path('/tmp/gpui-half-open-borrow-cost-target');BASE='5381eb93e62e97573bbbb3577e8bd0512d4f0dde';PIN='e872330f303deae4a7fba191af31e5bffa574054'
GIT=['git','-c','safe.directory='+str(ROOT),'-C',str(ROOT)];BIN=Path('/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def guard():return {name:sha(ROOT/name) for name in subprocess.check_output(GIT+['ls-files'],text=True).splitlines() if (ROOT/name).is_file()}
def run(args,folder,name,limit,env):
 before=guard();row={'args':args,'started_utc':datetime.datetime.now(datetime.UTC).isoformat(),'timeout_seconds':limit,'guard_before':before,'compiler':subprocess.check_output(['rustc','-Vv'],text=True),'environment':{k:env.get(k) for k in ['RUSTC','RUSTDOC','RUSTC_BOOTSTRAP','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_JOBS','CARGO_TARGET_DIR','CLIPPY_CONF_DIR']}}
 with (folder/(name+'.stdout')).open('wb') as out,(folder/(name+'.stderr')).open('wb') as err:
  p=subprocess.Popen(args,cwd=ROOT,env=env,stdout=out,stderr=err,start_new_session=True)
  try:code=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=124
 row.update(exit=code,ended_utc=datetime.datetime.now(datetime.UTC).isoformat(),guard_after=guard());row['guards_match']=row['guard_before']==row['guard_after'];(folder/(name+'.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({'lane':folder.name,'phase':name,'exit':code,'guards_match':row['guards_match']}),flush=True);assert row['guards_match'] and code==0
assert subprocess.check_output(GIT+['rev-parse','HEAD'],text=True).strip()==PIN
assert not subprocess.check_output(GIT+['status','--porcelain'],text=True)
assert all(x['wrapper_exit']==0 for x in json.loads((OUT/'functional-results.json').read_text()))
paths=[ROOT/'reactivity/crates/canvas/src/canvas.rs',ROOT/'reactivity/crates/gpu/src/renderer.rs'];original={p:p.read_bytes() for p in paths};env=os.environ.copy();env['CARGO_TARGET_DIR']=str(TARGET);env['CARGO_BUILD_JOBS']='1';assert not any(env.get(k) for k in ['RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_BOOTSTRAP'])
report={'base':BASE,'candidate':PIN,'same_physical_source_path':str(ROOT),'compiler':subprocess.check_output(['rustc','-Vv'],text=True),'runner_sha256':sha(__file__),'lanes':[]}
try:
 for label,ref in [('shipping',BASE),('by-value','1ad7fee64b7387c4a708bf276d194f21f1bc7c82'),('borrowed',PIN)]:
  folder=OUT/('cost-'+label);folder.mkdir(exist_ok=False)
  for p in paths:p.write_bytes(subprocess.check_output(GIT+['show',ref+':'+str(p.relative_to(ROOT))]) if label!='borrowed' else original[p])
  run(['cargo','clean','--manifest-path','reactivity/Cargo.toml','--release','-p','gpui_gpu','-p','gpui_canvas'],folder,'clean',120,env)
  run(['cargo','test','--manifest-path','reactivity/Cargo.toml','--release','--offline','--locked','-p','gpui_gpu','--test','render','--features','vulkan-tests','--no-run','--message-format=json'],folder,'build',1800,env)
  messages=[json.loads(s) for s in (folder/'build.stdout').read_text().splitlines() if s.startswith('{')];artifacts=[m for m in messages if m.get('reason')=='compiler-artifact'];selected=[m for m in artifacts if m['target']['name'] in ['gpui_gpu','gpui_canvas','render'] and (m.get('executable') or any(f.endswith('.rlib') for f in m['filenames']))];assert len(selected)==3 and all(not m['fresh'] and m['profile']['opt_level']=='3' for m in selected)
  art=next(m for m in selected if m['target']['name']=='render');binary=folder/'render-tests.elf';shutil.copy2(art['executable'],binary);binary.chmod(0o555);digest=sha(binary)
  fingerprints={}
  for m in artifacts:
   for filename in m['filenames']:
    fp=Path(filename).parent.parent/'fingerprint'
    if fp.is_dir():
     for item in fp.glob('*.json'):fingerprints[str(item)]={'sha256':sha(item),'data':json.loads(item.read_text())}
  (folder/'fingerprints.json').write_text(json.dumps(fingerprints,indent=2)+'\n')
  scripts=[m for m in messages if m.get('reason')=='build-script-executed' and 'gpui_gpu' in m.get('package_id','')];assert len(scripts)==1;shutil.copy2(Path(scripts[0]['out_dir'])/'ui.wgsl',folder/'ui.wgsl')
  for tool,args,name in [('size',['-A'],'sections'),('nm',['-S','-C','--size-sort'],'symbols'),('objdump',['-d','-C'],'assembly')]:run([str(BIN/tool),*args,str(binary)],folder,name,120,env)
  assert sha(binary)==digest
  row={'label':label,'binary':str(binary),'sha256':digest,'bytes':binary.stat().st_size,'artifacts':selected,'wgsl_sha256':sha(folder/'ui.wgsl'),'source_identity':ref+' production files; current shared test fixture'};report['lanes'].append(row);(folder/'manifest.json').write_text(json.dumps(row,indent=2)+'\n')
finally:
 for p,b in original.items():p.write_bytes(b)
 report['restored']=all(p.read_bytes()==b for p,b in original.items());report['clean_after']=not subprocess.check_output(GIT+['status','--porcelain'],text=True);(OUT/'cost-capture.json').write_text(json.dumps(report,indent=2)+'\n');assert report['restored'] and report['clean_after']
