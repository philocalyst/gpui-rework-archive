from pathlib import Path
import json,subprocess
ROOT=Path('/tmp/gpui-half-open-borrow-sol');OUT=Path('/tmp/gpui-half-open-borrow-evidence');PIN='e872330f303deae4a7fba191af31e5bffa574054';PY='/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3';results=[]
def gate(name,seconds,args):
 cmd=[PY,'/tmp/gpui-run-frozen-gate-root.py','--source',str(ROOT),'--pin',PIN,'--out',str(OUT/name),'--timeout',str(seconds),'--']+args
 with (OUT/(name+'.wrapper.log')).open('wb') as log:r=subprocess.run(cmd,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'wrapper_exit':r.returncode,'result':json.loads((OUT/name/'result.json').read_text()) if (OUT/name/'result.json').exists() else None};results.append(row);(OUT/'functional-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True);return r.returncode==0
def execute(label,build):return gate(label,600,[PY,'/tmp/gpui-run-cargo-test-artifacts-root.py','--build',str(OUT/build),'--out',str(OUT/(label+'-artifacts')),'--per-binary-seconds','360'])
base=['cargo','test','--manifest-path','reactivity/Cargo.toml','--offline','--locked']
if gate('default-build',1800,base+['-p','gpui_gpu','--test','render','--features','vulkan-tests','--no-run','--message-format=json']):execute('default-execute','default-build')
if gate('scalar-build',1800,base+['-p','gpui_gpu','-p','gpui_canvas','--lib','--tests','--no-default-features','--features','gpui_gpu/vulkan-tests','--no-run','--message-format=json']):execute('scalar-execute','scalar-build')
strict=['cargo','clippy','--manifest-path','reactivity/Cargo.toml','--offline','--locked','-p','gpui_gpu','-p','gpui_canvas','--all-targets']
gate('strict-default',1800,strict+['--features','gpui_gpu/vulkan-tests','--','-D','warnings'])
gate('strict-scalar',1800,strict+['--no-default-features','--features','gpui_gpu/vulkan-tests','--','-D','warnings'])
print(json.dumps({'all_wrappers_pass':all(x['wrapper_exit']==0 for x in results)}),flush=True);raise SystemExit(0 if all(x['wrapper_exit']==0 for x in results) else 1)
