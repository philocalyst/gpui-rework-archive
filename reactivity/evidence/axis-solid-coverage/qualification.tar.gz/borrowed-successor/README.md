# Borrowed axis-solid numerical correction

Exact e872330f303deae4a7fba191af31e5bffa574054, isolated /tmp/gpui-half-open-borrow-sol, based exact first fix 1ad and original 5381. No Main writes or rebase. Net adoption patch is production.patch (two production files); full.patch also retains the independent regression tests. Root will compose and qualify on its current stack separately.

The first correction, its original test-assumption failure, bad/good raw pixels, native16lane diagnosis, failed uniform-prefix experiment, all offline/cross gates and its adverse code/frame costs are preserved in the immutable archive referenced by first-fix-immutable-seal.json. That archive is62,740,310B SHA256b091098448dd435f3b20e9f6efb8d9ad3f924198877e196ceb5c7c58b9d2a694. None of those original results is relabelled as a new successor run.

This successor changes exactly seven lines over 1ad: PreparedDraw and Mapping helper boundaries borrow their input views. The one checked domain entry and one canonical binary-search predicate remain unchanged. All shader/source-over/HDR/signed-zero/resolve operations and packet layouts remain unchanged. No inline annotation, unchecked API, new field, allocation, buffer, policy exception or arithmetic seed was added. See proof.md and unchanged-shader-and-tests.json.

Actual new e872 finite qualification, genuine 1.101.0-nightly7189d39d9 with rootv0/tokio flags, generic flags/bootstrap unset, locked/offline jobs1 and exact tracked clippy.toml:

- Default GPU integration 47/47 passed, including the unchanged 96-case boundary fixture (SDR/HDR, ordinary/banked, complementary edges, reflections, shear fallback and deep translucent stacks).
- Scalar full Canvas/GPU 254 passed, 0 failed, 3 existing ignores across 31 harnesses, including canonical inverse ULP/invalid-domain tests and existing image/mask/rounded/resource/failed-publication tests.
- Actual-policy all-target Canvas/GPU strict default and scalar both passed.
- All 2009 source/config guards before/after each gate match. Actual immutable test ELFs are separately hashed external records.
- 1ad offline58tests, offlineSPIR-V validation and Windows/Apple compile-only gates remain 1ad evidence, not successor executions. Shader/test sources are byte-identical1ad.

Matched static comparison uses one physical successor path, one new exclusive target, identical current GPU fixture, compiler/root flags/lock/features/defaultSIMD+vulkan-tests/opt3 and no emit-stack-sizes. Each lane package-cleans Canvas/GPU and requires all three artifacts fresh:false. Only exact canvas.rs and renderer.rs production overlays differ. Matching-proof.json independently checks compiler/environment/profile/features/source guards/shader equality. Full linked ELFs,173 Cargo fingerprints per lane, whole disassembly, all selected helpers/calls and own-stack analysis remain retained. No test executes during overlays. The source was restored clean after all readers exited.

Measured bill (shipping / first-by-value / borrowed):

| Item | shipping5381 | first1ad | borrowede872 |
| --- | ---: | ---: | ---: |
| Core lines |31318|31386|31386|
| Whole linked.text delta vs shipping |0|+2624B|+2656B|
| Ordinary renderer code |9209B|10263B|10293B|
| Ordinary renderer own frame |1496B|1672B|1320B|
| Paint-observed renderer code |9347B|10084B|10102B|
| Paint-observed own frame |1640B|1768B|1432B|
| Checked PreparedDraw method |absent|683B/frame104|668B/frame104|
| Shared lattice kernel |inlined|1119B/leaf0|1119B/leaf0|

The remaining +68core/+2656B linked.text are charged. Borrowing adds32B text versus1ad while removing352/336B from the two respective renderer own frames. These are per-function reachable own frames, including any negative-RSP red-zone usage and excluding return address/callees; never call-chain sums. No unknown stack operations occur in these listed functions. The wrapper remains137B/frame40. Forward sampled_rect_clip is1577B/frame232 shipping,454B/frame152 first,458B/frame152 borrowed. Whole.eh_frame+168B remains, rodata/data.rel.ro/gcc_except_table unchanged.

All three generated15139B WGSLs have exact SHAab3accf5a441b5eb03a9c7a690fdd40c13471ba6475b406183a7e86369b9605b, identical to the original reference. No GPU code/register/resource delta. No new timing campaign, speed claim or call-chain claim. Additional group eligibility scan and up to68binary-search predicate visits per eligible draw remain real host work. Luna's certified arithmetic-seed research is separate; no such shortcut is in this pin. Uniform-prefix optimization stays stopped under its original failed qualification. General shear/glyph/image numerical gaps are not claimed solved by this plain-axis-solid correction.
