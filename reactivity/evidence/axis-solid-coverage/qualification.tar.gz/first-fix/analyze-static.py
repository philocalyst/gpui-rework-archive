from pathlib import Path
import json,re
ROOT=Path('/tmp/gpui-half-open-fix-evidence')
def frame(body):
 ins={}
 for line in body:
  z=re.match(r'\s*([0-9a-f]+):\s+(?:[0-9a-f]{2} )+\s*\t([a-z][a-z0-9]*)\s*(.*)',line)
  if z:ins[int(z[1],16)]=(z[2],z[3])
 if not ins:return {'unknown':['no instructions parsed']}
 keys=sorted(ins);following=dict(zip(keys,keys[1:]));pending=[(keys[0],0)];seen=set();peak=0;unknown=[];calls=[]
 while pending:
  addr,depth=pending.pop()
  if (addr,depth) in seen:continue
  seen.add((addr,depth))
  if len(seen)>len(ins)*8:unknown.append('multiple/dynamic stack states');break
  op,args=ins[addr]
  if op.startswith('push'):depth+=8
  elif op.startswith('pop'):depth-=8
  elif op in ['sub','add'] and args.endswith(',%rsp'):
   z=re.match(r'\$0x([0-9a-f]+),%rsp',args)
   if z:depth+=(1 if op=='sub' else -1)*int(z[1],16)
   else:unknown.append(op+' '+args)
  elif '%rsp' in args and args.endswith(',%rsp') and op not in ['cmp','test']:unknown.append(op+' '+args)
  if op.startswith('call'):
   calls.append(args)
   if 'probestack' in args:unknown.append('stack probe call: '+args)
  # Include any reachable leaf red-zone access below the current RSP.
  for offset in re.findall(r'-0x([0-9a-f]+)\(%rsp\)',args):peak=max(peak,depth+int(offset,16))
  if '(%rsp,' in args:unknown.append('indexed RSP memory address: '+args)
  peak=max(peak,depth)
  if op.startswith('ret') or op in ['ud2','hlt']:continue
  if op.startswith('j'):
   z=re.match(r'([0-9a-f]+) ',args);target=int(z[1],16) if z else None
   if target in ins:pending.append((target,depth))
   elif op=='jmp' and '*' in args:unknown.append('indirect jump CFG not followed: '+args)
   if op=='jmp':continue
  if addr in following:pending.append((following[addr],depth))
 return {'reachable_own_stack_bytes_excluding_return_address':peak,'unknown':sorted(set(unknown)),'direct_and_indirect_calls':sorted(set(calls))}
def select(name):return 'gpui_gpu::renderer' in name or ('gpui_canvas' in name and any(x in name for x in ['sampled_rect','sampled_domain','sampled_solid','lower_sampled']))
report={}
for lane in ['baseline','candidate']:
 p=ROOT/('cost-'+lane);symbols={}
 for line in (p/'symbols.stdout').read_text().splitlines():
  m=re.match(r'([0-9a-f]+) ([0-9a-f]+) ([A-Za-z]) (.*)',line)
  if m:symbols.setdefault(m[4],[]).append({'address':int(m[1],16),'bytes':int(m[2],16),'kind':m[3]})
 sections={}
 for line in (p/'sections.stdout').read_text().splitlines():
  m=re.match(r'(\S+)\s+(\d+)\s+(\d+)',line)
  if m:sections[m[1]]=int(m[2])
 selected={};name=None;address=None;body=[]
 def flush():
  if name and select(name):selected.setdefault(name,[]).append({'address':address,'symbols':[v for v in symbols.get(name,[]) if v['address']==address],**frame(body)})
 with (p/'assembly.stdout').open() as f:
  for line in f:
   m=re.match(r'^([0-9a-f]+) <(.+)>:\n',line)
   if m:flush();name=m[2];address=int(m[1],16);body=[]
   elif name and select(name):body.append(line)
 flush()
 report[lane]={'sections':sections,'functions':selected,'all_gpui_code_symbols':{k:v for k,v in symbols.items() if ('gpui_gpu::' in k or 'gpui_canvas::' in k) and any(x['kind'].lower()=='t' for x in v)}}
 (p/'selected-frames.json').write_text(json.dumps(report[lane],indent=2)+'\n')
report['section_delta']={k:report['candidate']['sections'].get(k,0)-report['baseline']['sections'].get(k,0) for k in ['.text','.rodata','.data.rel.ro','.eh_frame','.gcc_except_table']}
report['scope']='Static same-path linked ELF and reachable own frames, excluding return address/callees. Unknown CFG/stack operations explicitly reported. No execution timing or hardware register evidence.'
(ROOT/'static-cost-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'sections':{k:report[k]['sections'] for k in ['baseline','candidate']},'delta':report['section_delta'],'functions':{k:{n:[(sum(s['bytes'] for s in a['symbols']),a.get('reachable_own_stack_bytes_excluding_return_address'),a['unknown']) for a in v] for n,v in report[k]['functions'].items()} for k in ['baseline','candidate']}},indent=2))
