# Evidence preservation scope

Original prefix experiment35d remains stopped and unadopted: exact5381 reference and prefix each46existingGPU tests pass and the new adversarial body fails;586paired raw GPU readbacks andStats match, which does NOT pass the independentCPU gate. All original raw files and actual bad ELFs remain in /tmp/gpui-pixel-uniform-evidence. No tolerance was enlarged.

The first native diagnosis compile was attempted before the new sparse worktree had been materialized, so reference-shader.rs was absent. The actual missing-file error was shown in the tool transcript; its first on-disk compile.stderr was subsequently overwritten by the successful native-trace build before a separate copy was made. The transcript remains the original failure evidence; no reconstructed file is labelled its original stderr. Later native trace source/ELF/logs are actual successful artifacts. Native tracev1 is preserved before adding exact hex-bit columns inv2. These are native executions of the original typed shader functions, not actual GPU register traces.

The good-public-capture observer initially selected a lib-test artifact with no .rlib and failedE0432; its exact source/command/stdout/stderr/exit are preserved as v1. The corrected selector requires a real .rlib artifact; actual successful compile/capture uses the final frozen default library artifacts and ordinary public Renderer/Canvas helpers.

Default functional sourcef1e had253passes,1newtest-assumption failure,3ignored. The erroneous one-ULP boundary assumption is retained. Test-only1ad corrects the expected f64 behavior; production files are byte-identicalf1e. The original full default execution is never relabelled as a passing1ad run. The corrected3test harness and all remaining gates carry their actual1ad source pin.

Initial no-run build-v1 preceded comment-only production changes. Its preserved ELF is labelled production-body-equivalent only. Exact frozen default-build and frozen test-artifact copies are separate actual final-source builds. No timing samples or hardware GPU register/performance evidence exist for this slice.
