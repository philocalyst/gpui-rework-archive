from pathlib import Path
import json,subprocess,hashlib
root=Path('/tmp/gpui-half-open-fix-evidence');messages=[json.loads(s) for s in (root/'default-build/stdout.log').read_text().splitlines() if s.startswith('{')];artifacts=[m for m in messages if m.get('reason')=='compiler-artifact'];dirs=sorted({str(Path(f).parent) for m in artifacts for f in m['filenames']})
args=['rustc','--edition=2024','-C','opt-level=3','-C','symbol-mangling-version=v0','--cfg','tokio_unstable',str(root/'public-good-capture.rs'),'-o',str(root/'public-good-capture')]
for name in ['gpui_canvas','gpui_gpu','pollster','bytemuck']:
 m=[m for m in artifacts if m['target']['name']==name and m['target']['kind']==['lib'] and any(f.endswith('.rlib') for f in m['filenames'])][-1]
 for f in m['filenames']:
  if f.endswith(('.rmeta','.rlib')):args+=['--extern',name+'='+f]
for d in dirs:args+=['-L','dependency='+d]
(root/'good-compile-command.json').write_text(json.dumps(args,indent=2)+'\n')
with (root/'good-compile.stdout').open('wb') as out,(root/'good-compile.stderr').open('wb') as err:r=subprocess.run(args,stdout=out,stderr=err,timeout=180)
(root/'good-compile.exit').write_text(str(r.returncode)+'\n');raise SystemExit(r.returncode)
