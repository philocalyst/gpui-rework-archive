#![allow(dead_code, unused_imports)]
include!("/tmp/gpui-half-open-fix-sol/reactivity/crates/gpu/tests/render.rs");
fn main() {
    pollster::block_on(async {
        for hdr in [false, true] {
            let format = if hdr { wgpu::TextureFormat::Rgba16Float } else { wgpu::TextureFormat::Rgba8UnormSrgb };
            let mut renderer = renderer(format).await;
            renderer.set_tile_proofs(false);
            for banked in [false, true] {
                let config = if hdr { ColorConfig::linear_hdr(gpui_canvas::OutputProfile::Srgb,203.0).unwrap() } else { ColorConfig::default() };
                let mut canvas = Canvas::recording(33,17,config).unwrap();
                canvas.clear(Color::linear_srgb(0.125,0.25,0.5,1.0).unwrap());
                let clip = Rect::new(0.0,0.0,33.0,17.0);
                let color = if hdr { Color::linear_srgb(2.0,-0.125,0.75,0.17).unwrap() } else { Color::rgba(31,89,173,43) };
                let slot=banked.then(||canvas.paint_slot(gpui_canvas::PaintColor::new(color)).unwrap());
                for _ in 0..32 {
                    let rect=Rect::new(-2.0,-2.0,37.0,21.0);
                    if let Some(slot)=slot {canvas.fill_rect_slot(rect,Affine::IDENTITY,clip,slot).unwrap();}
                    else {canvas.fill_rect(rect,Affine::IDENTITY,clip,color).unwrap();}
                }
                let transform=Affine::scale(1.25,0.75);
                canvas.fill_rect(Rect::new(0.0,0.0,8.5,17.0),transform,clip,Color::rgba(231,17,37,127)).unwrap();
                canvas.fill_rect(Rect::new(8.5,0.0,24.5,17.0),transform,clip,Color::rgba(19,227,83,191)).unwrap();
                let actual=readback(&mut renderer,&canvas);
                let stats=renderer.stats();let expected=canvas.pixels();
                let stem=format!("/tmp/gpui-half-open-fix-evidence/good-hdr{hdr}-banked{banked}");
                std::fs::write(format!("{stem}.gpu"),&actual).unwrap();
                std::fs::write(format!("{stem}.cpu"),expected).unwrap();
                std::fs::write(format!("{stem}.stats"),format!("{stats:?}\n")).unwrap();
                if !hdr { assert_eq!(&actual[40..44],&expected[40..44]);println!("fixed SDR banked{banked} pixel10,0 {:?}",&actual[40..44]); }
                else { println!("fixed HDR banked{banked} pixel10,0 {:?}",&actual[80..88]); }
            }
        }
    });
}
