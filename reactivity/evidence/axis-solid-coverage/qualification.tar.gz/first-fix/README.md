# Axis-solid half-open numerical correction — qualified source, no timing claim

Final 1ad7fee64b7387c4a708bf276d194f21f1bc7c82 in /tmp/gpui-half-open-fix-sol, based exact 5381. Production first froze f1e; 1ad changes only the new Canvas test's mistaken one-ULP assumption. Main was not edited. Current Main text integration will require a separate minimal composition; this dossier is not silently rebased.

The original prefix experiment 35d and exact 5381 both produce wrong GPU 150/121/125 at pixel 10,0 where CPU 125/155/122 is required. Their matching 586 raw images do not constitute correctness. Their actual failing ELFs/raws/native diagnosis are preserved under prefix-failed in the archive, with ELF files external by manifest. The prefix optimization remains stopped/unadopted. See proof-and-scope.md and preservation-notes.md for the coefficient/rounding diagnosis and preservation limits.

The scoped correction lowers plain canonical axis-aligned solids onto the existing finite quarter-pixel coverage lattice, using the original CPU rounded membership operations. The shared helper eliminates a forward/inverse roundtrip. Identity uploaded geometry with quarter endpoints makes the actual eighth-offset sample membership exact; all blend, HDR, signed-zero and resolve operations and the whole shader stay unchanged. Shear/rounded/image/glyph precision retains the inherited path and is not claimed solved. Empty coverage uses an outside positive size sentinel to avoid normalization0/0.

Actual functional scopes:

- Original frozen f1e default Canvas+GPU:253 passed, 1 failed, 3 ignored, 31 harnesses. All 47 GPU tests including the 96-case reproducer passed. The one failure is the new Canvas test's wrong one-ULP expectation; preserved, never retagged.
- Test-only1ad corrected sample_clip:3 passed. Two production files byte-identical f1e.
- 1ad scalar full Canvas+GPU:254 passed, 0 failed, 3 ignored, 31 harnesses.
- 1ad offline fullGPU:58 passed / 2 harnesses, including 48 integration and 10 library; actualSPIR-V validator and generated artifacts retained.
- 1ad actual tracked clippy policy default/scalar/offline all-target Canvas+GPU strict:PASS.
- 1ad WindowsMSVC and Appleaarch64 Canvas+GPU libraries:compile-onlyPASS.
- Genuine 1.101.0-nightly7189d39d9; rootv0/tokio flags; genericflags/bootstrap unset; 2009 tracked sparse source/config guards match for each gate. Only llvmpipe software Vulkan, no hardware claim.
- Four fresh public SDR/HDR ordinary/banked raw images pass the unchanged CPU tolerances. SDRbadpixel is exact125/155/122/255; HDR allows the existing 1-halfword difference. Entire images are not falsely claimed bit-exact CPU. The 96-case test uses unchanged original body/tolerances, verified by normalized body hash.

Actual costs are adverse and remain charged: core 31318→31386(+68); whole opt3 linked .text+2624B, .eh_frame+168B, rodata/data.rel.ro/exceptiontable unchanged. Ordinary prepare/render code 9209→10263B, own stack 1496→1672; paint observed 9347→10084B, own stack 1640→1768. New checked PreparedDraw method 683 B / frame 104 and wrapper 137 B / frame 40; shared lattice kernel 1119 B / leaf 0. Forward sampled_rect_clip shrinks 1577→454B/frame 232→152. These are own reachable frames excluding return address/callees, never sums. Full disassembly/selected helpers/unknowns and Cargo/source fingerprints remain in static-cost-report.json and cost-*.

Same physical source path, exclusive NEW target, identical current test fixture, compiler/flags/lock/features/opt3, fresh:false Canvas+GPU+render in both static lanes, no emit-stack-sizes. Exact5381 overlays only the two production files; no test execution during cost capture. Both actual preserved static ELFs and all 173 Cargo fingerprints are identified. Generated 15139 B WGSL SHA ab3accf5a441b5eb03a9c7a690fdd40c13471ba6475b406183a7e86369b9605b is identical in both lanes and original reference. No shader/register/resource delta. Extra per-group eligibility scan and at most 68 binary-search predicate visits per eligible draw are charged as logical work, not host time. No retained layout/ABI fields change. Historical correction/upload/capacity observations have different renderer histories; no matched memory benefit is claimed.

No new performance campaign or prefix continuation ran. Full failed/passed runs, observers, bad/good raw pixels, source patches, protocols, generated artifacts, static assembly and guards are retained. Initial native support-stderr overwrite is explicitly disclosed. The archive excludes ELF payloads and records their exact original paths/hashes/bytes; those actual instances remain external and immutable.
