#![allow(dead_code)]
#[path="/tmp/gpui-half-open-fix-evidence/reference-shader.rs"]
mod shader;
use gpui_canvas::{Affine,Canvas,Color,ColorConfig,Rect};
use wgsl_rs::std::*;
fn main() {
    let mut canvas = Canvas::recording(33,17,ColorConfig::default()).unwrap();
    canvas.clear(Color::linear_srgb(0.125,0.25,0.5,1.0).unwrap());
    let clip=Rect::new(0.0,0.0,33.0,17.0);
    for _ in 0..32 {
        canvas.fill_rect(Rect::new(-2.0,-2.0,37.0,21.0),Affine::IDENTITY,clip,Color::rgba(31,89,173,43)).unwrap();
    }
    let transform=Affine{a:1.25,d:0.75,..Affine::IDENTITY};
    canvas.fill_rect(Rect::new(0.0,0.0,8.5,17.0),transform,clip,Color::rgba(231,17,37,127)).unwrap();
    canvas.fill_rect(Rect::new(8.5,0.0,24.5,17.0),transform,clip,Color::rgba(19,227,83,191)).unwrap();
    let canonical:Vec<_>=canvas.prepared_scene().draws().collect();
    let mut colors=[canvas.prepared_scene().clear;16];
    println!("draw,lane,wx,wy,cpu_x,cpu_y,cpu_inside,raw_x,raw_y,position_x,position_y,error_x,error_y,pair_x_hi,pair_x_lo,pair_end_hi,pair_end_lo,native_inside,source_r,source_g,source_b,source_a,blend_r,blend_g,blend_b,blend_a");
    for (index,d) in canonical.iter().enumerate() {
        let hi=d.inverse.map(|v|v as f32);
        let low=std::array::from_fn::<_,6,_>(|i|(d.inverse[i]-f64::from(hi[i])) as f32);
        shader::ui::CORRECTIONS.set(RuntimeArray{data:vec![shader::ui::Correction{x:vec4f(low[0],low[2],low[4],0.0),y:vec4f(low[1],low[3],low[5],0.0)}]});
        let m=d.inverse;let r=d.local_rect;
        let arithmetic=8.0*f64::from(f32::EPSILON)*(m[0].abs()*33.0+m[2].abs()*17.0+m[4].abs()+m[1].abs()*33.0+m[3].abs()*17.0+m[5].abs()+1.0);
        let error=[((m[0]-f64::from(hi[0])).abs()*33.0+(m[2]-f64::from(hi[2])).abs()*17.0+(m[4]-f64::from(hi[4])).abs()+arithmetic+4.0*f64::from(f32::EPSILON)*(f64::from(r.x).abs()+f64::from(r.width).abs())) as f32,
        ((m[1]-f64::from(hi[1])).abs()*33.0+(m[3]-f64::from(hi[3])).abs()*17.0+(m[5]-f64::from(hi[5])).abs()+arithmetic+4.0*f64::from(f32::EPSILON)*(f64::from(r.y).abs()+f64::from(r.height).abs())) as f32];
        let draw=shader::ui::Draw{local:vec4f(r.x,r.y,r.width,r.height),inverse_x:vec4f(hi[0],hi[2],hi[4],error[0]),inverse_y:vec4f(hi[1],hi[3],hi[5],error[1]),clip:vec4f(d.clip.x,d.clip.y,d.clip.width,d.clip.height),color:vec4f(d.color[0],d.color[1],d.color[2],d.color[3]),atlas:vec4u(0,0,0,0)};
        for y in 0..4 {for x in 0..4 {
            let lane=y*4+x;let point=vec2f(10.125+x as f32*0.25,0.125+y as f32*0.25);
            let cpu_x=(m[0]*f64::from(point.x)+m[2]*f64::from(point.y))+m[4];
            let cpu_y=(m[1]*f64::from(point.x)+m[3]*f64::from(point.y))+m[5];
            let inside=cpu_x>=f64::from(r.x)&&cpu_x<f64::from(r.x)+f64::from(r.width)&&cpu_y>=f64::from(r.y)&&cpu_y<f64::from(r.y)+f64::from(r.height);
            let raw=vec2f(dot(draw.inverse_x.xyz(),vec3f(point.x,point.y,1.0)),dot(draw.inverse_y.xyz(),vec3f(point.x,point.y,1.0)));
            let position=raw-draw.local.xy();
            let pair=shader::ui::pair_add(shader::ui::pair_dot(draw.inverse_x.xyz(),vec3f(low[0],low[2],low[4]),point),vec2f(-r.x,0.0));
            let end=shader::ui::pair_add(pair,vec2f(-r.width,0.0));
            let source=shader::ui::sample_draw(draw,point);
            for channel in 0..4 { colors[lane][channel]=source[channel]+colors[lane][channel]*(1.0-source.w); }
            if index>=32 { eprintln!("trace_bits draw{index} lane{lane} rawx{:08x} rawy{:08x} posx{:08x} posy{:08x} pairxhi{:08x} pairxlo{:08x} endhi{:08x} endlo{:08x} source{:08x?} blend{:08x?}",raw.x.to_bits(),raw.y.to_bits(),position.x.to_bits(),position.y.to_bits(),pair.x.to_bits(),pair.y.to_bits(),end.x.to_bits(),end.y.to_bits(),[source.x.to_bits(),source.y.to_bits(),source.z.to_bits(),source.w.to_bits()],colors[lane].map(f32::to_bits)); }
            if index>=32 {println!("{index},{lane},{},{},{cpu_x:.17},{cpu_y:.17},{inside},{},{},{},{},{},{},{:.17},{:.17},{:.17},{:.17},{},{},{},{},{},{},{},{},{}",point.x,point.y,raw.x,raw.y,position.x,position.y,error[0],error[1],pair.x,pair.y,end.x,end.y,source.w!=0.0,source.x,source.y,source.z,source.w,colors[lane][0],colors[lane][1],colors[lane][2],colors[lane][3]);}
        }}
    }
    drop(canonical);
    let cpu=canvas.pixels();std::fs::write("/tmp/gpui-half-open-fix-evidence/cpu-reference.bin",cpu).unwrap();
    eprintln!("CPU pixel10,0 {:?}",&cpu[40..44]);
}
