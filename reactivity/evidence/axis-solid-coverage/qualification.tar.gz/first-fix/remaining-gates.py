from pathlib import Path
import json,os,subprocess
ROOT=Path('/tmp/gpui-half-open-fix-sol');OUT=Path('/tmp/gpui-half-open-fix-evidence');PIN='1ad7fee64b7387c4a708bf276d194f21f1bc7c82';PY='/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3'
results=[]
def gate(name,seconds,args):
 command=[PY,'/tmp/gpui-run-frozen-gate-root.py','--source',str(ROOT),'--pin',PIN,'--out',str(OUT/name),'--timeout',str(seconds),'--']+args
 with (OUT/(name+'.wrapper.log')).open('wb') as log:r=subprocess.run(command,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
 result={'name':name,'wrapper_exit':r.returncode,'result':json.loads((OUT/name/'result.json').read_text()) if (OUT/name/'result.json').exists() else None};results.append(result);(OUT/'remaining-results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(result),flush=True);return r.returncode==0

def execute(label,build):
 return gate(label,600,[PY,'/tmp/gpui-run-cargo-test-artifacts-root.py','--build',str(OUT/build),'--out',str(OUT/(label+'-artifacts')),'--per-binary-seconds','360'])
execute('corrected-test-execute','corrected-test-build')
base=['cargo','test','--manifest-path','reactivity/Cargo.toml','--offline','--locked','-p','gpui_gpu','-p','gpui_canvas','--lib','--tests','--no-run','--message-format=json']
if gate('scalar-build',1800,base+['--no-default-features','--features','gpui_gpu/vulkan-tests']):execute('scalar-execute','scalar-build')
strict=['cargo','clippy','--manifest-path','reactivity/Cargo.toml','--offline','--locked','-p','gpui_gpu','-p','gpui_canvas','--all-targets']
gate('strict-default',1800,strict+['--features','gpui_gpu/vulkan-tests','--','-D','warnings'])
gate('strict-scalar',1800,strict+['--no-default-features','--features','gpui_gpu/vulkan-tests','--','-D','warnings'])
offline=['cargo','test','--manifest-path','reactivity/Cargo.toml','--offline','--locked','-p','gpui_gpu','--lib','--test','render','--features','vulkan-tests,offline-shader','--no-run','--message-format=json']
if gate('offline-build',1800,offline):execute('offline-execute','offline-build')
gate('strict-offline',1800,strict+['--features','gpui_gpu/vulkan-tests,gpui_gpu/offline-shader','--','-D','warnings'])
for label,target in [('cross-windows','x86_64-pc-windows-msvc'),('cross-apple','aarch64-apple-darwin')]:
 gate(label,1800,['cargo','check','--manifest-path','reactivity/Cargo.toml','--offline','--locked','-p','gpui_gpu','-p','gpui_canvas','--lib','--target',target])
print(json.dumps({'all_wrappers_pass':all(x['wrapper_exit']==0 for x in results),'gates':len(results)}),flush=True)
raise SystemExit(0 if all(x['wrapper_exit']==0 for x in results) else 1)
