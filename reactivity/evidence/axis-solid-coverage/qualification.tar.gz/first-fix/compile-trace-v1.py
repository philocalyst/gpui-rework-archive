from pathlib import Path
import json,subprocess,hashlib
root=Path('/tmp/gpui-half-open-fix-evidence');messages=[json.loads(s) for s in Path('/tmp/gpui-pixel-uniform-evidence/matched-baseline/build.stdout').read_text().splitlines() if s.startswith('{')]
artifacts=[m for m in messages if m.get('reason')=='compiler-artifact'];dirs=sorted({str(Path(f).parent) for m in artifacts for f in m['filenames']})
args=['rustc','--edition=2024','-C','opt-level=3','-C','symbol-mangling-version=v0','--cfg','tokio_unstable',str(root/'trace.rs'),'-o',str(root/'trace')]
for name in ['gpui_canvas','wgsl_rs']:
 m=[m for m in artifacts if m['target']['name']==name and m['target']['kind']==['lib']][-1]
 for f in m['filenames']:
  if f.endswith(('.rmeta','.rlib')):args+=['--extern',name+'='+f]
for d in dirs:args+=['-L','dependency='+d]
(root/'compile-command.json').write_text(json.dumps(args,indent=2)+'\n')
with (root/'compile.stdout').open('wb') as out,(root/'compile.stderr').open('wb') as err:r=subprocess.run(args,stdout=out,stderr=err,timeout=180)
(root/'compile.exit').write_text(str(r.returncode)+'\n');raise SystemExit(r.returncode)
