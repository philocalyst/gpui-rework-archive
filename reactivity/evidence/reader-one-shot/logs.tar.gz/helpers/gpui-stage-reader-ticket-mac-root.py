from pathlib import Path
import base64,hashlib,io,json,subprocess,tarfile

pin='bcbee2b1a1d37e3c89ffe6253c8c161a53f52f54'
root=Path('/tmp/gpui-reader-ticket-sol-20261024')
local=Path('/tmp/gpui-reader-ticket-mac-root');local.mkdir()
manifest=json.loads(Path('/tmp/gpui-reader-ticket-sol-manifest.json').read_text())
assert manifest['source_pin']==pin
guard=manifest['build_input_sha256']
base=json.loads(Path('/tmp/gpui-portable-gpu-tests-root-build/before.json').read_text())
assert guard.keys()==base.keys()
sha=lambda b:hashlib.sha256(b).hexdigest()
changed=[n for n in guard if guard[n]!=base[n]]
archive=local/'overlay.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
    for n in changed:
        data=subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'show',pin+':'+n])
        assert sha(data)==guard[n],n
        member=tarfile.TarInfo(n);member.size=len(data);member.mode=0o644;tar.addfile(member,io.BytesIO(data))
    for n,data in [('source-manifest.json',json.dumps(guard,indent=2).encode()),('source-pin.txt',(pin+'\n').encode())]:
        member=tarfile.TarInfo(n);member.size=len(data);tar.addfile(member,io.BytesIO(data))
payload=archive.read_bytes()
receipt={'pin':pin,'bytes':len(payload),'sha256':sha(payload),'changed_from_5aff':changed,'guarded_inputs':len(guard),'extraction':'immutable git object; independent of agent mutant checkout'}
(local/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
remote='/Users/mileswirht/gpui-reactivity-20261024-root/reader-bcbee2b1'
def call(code,name):
    p=subprocess.run(['rex','--timeout','30s','-C','mac','do','mac.exec','--args',json.dumps({'argv':['/usr/bin/python3','-c',code]}),'--json'],capture_output=True,text=True,timeout=45)
    (local/(name+'.json')).write_text(p.stdout);assert p.returncode==0,p.stderr
    r=json.loads(p.stdout);assert r.get('ok') and r.get('code')==0,r
    return r['stdout']
print(call('from pathlib import Path;import shutil;p=Path('+repr(remote)+');assert shutil.disk_usage(p.parent).free>20*1024**3;p.mkdir();(p/"overlay.part").touch(exist_ok=False);print(p)','setup'),flush=True)
for offset in range(0,len(payload),24*1024):
    block=payload[offset:offset+24*1024]
    code='from pathlib import Path;import base64,hashlib;p=Path('+repr(remote+'/overlay.part')+');assert p.stat().st_size=='+str(offset)+';b=base64.b64decode('+repr(base64.b64encode(block).decode())+');assert hashlib.sha256(b).hexdigest()=='+repr(sha(block))+';f=p.open("ab");f.write(b);f.close();print(p.stat().st_size)'
    call(code,'chunk-'+str(offset))
extract=r'''from pathlib import Path
import fcntl,hashlib,json,tarfile
p=Path(REMOTE);a=p/'overlay.part';assert hashlib.sha256(a.read_bytes()).hexdigest()==DIGEST
with (p.parent/'host.lock').open('a') as lease:
    fcntl.flock(lease,fcntl.LOCK_SH)
    base=p.parent/'source.tar.gz';assert hashlib.sha256(base.read_bytes()).hexdigest()=='745cc816f784ce165e1b2fb54494bb77bc358bdd833bd8d6e257b10e93671b4b'
    s=p/'source';s.mkdir()
    for archive in [base,a]:
        with tarfile.open(archive) as tar:
            for member in tar:
                assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
                q=s/member.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(tar.extractfile(member).read());q.chmod(member.mode)
    guard=json.loads((s/'source-manifest.json').read_text())
    for n,h in guard.items():assert hashlib.sha256((s/n).read_bytes()).hexdigest()==h,n
    print(json.dumps({'source':PIN,'inputs':len(guard),'all_match':True}))
'''.replace('REMOTE',repr(remote)).replace('DIGEST',repr(sha(payload))).replace('PIN',repr(pin))
print(call(extract,'extract'),flush=True)
template=Path('/tmp/gpui-stage-typed-transport-mac-root.py').read_text()
start=template.index("job=r'''v") if "job=r'''v" in template else template.index("job=r'''")
end=template.index("'''.replace('REMOTE'",start)
job=template[start+8:end]
job=job.replace("'Unadopted typed owner/producer mailbox; unchanged first-poll allocation and Reader contracts only, not a full native-suite pass.'","'Reader bound ticket admission: actual Darwin unit/layout/first-poll and public questions. Not a full native suite or display timing.'")
job=job.replace("'-p','gpui'],'clean-debug'","'-p','gpui','--profile','dev'],'clean-debug'")
job=job.replace("'--lib','--no-run'","'--lib','--test','questions','--no-run'")
old="""assert len(tests)==1 and tests[0]['fresh'] is False
        q=Path(tests[0]['executable']);f=out/'gpui';q.rename(f);f.chmod(0o555);h=hashlib.sha256(f.read_bytes()).hexdigest();(out/'binary.json').write_text(json.dumps({'cargo':tests[0],'sha256':h,'bytes':f.stat().st_size},indent=2));check()"""
new="""assert len(tests)==2 and all(not row['fresh'] for row in tests)
        r['results']=[]
        for row in tests:
            q=Path(row['executable']);f=out/row['target']['name'];q.rename(f);f.chmod(0o555);h=hashlib.sha256(f.read_bytes()).hexdigest()
            record={'name':f.name,'sha256':h,'bytes':f.stat().st_size,'cargo':row};r['results'].append(record);(out/(f.name+'.binary.json')).write_text(json.dumps(record,indent=2))
        f=out/'gpui';check()"""
assert old in job;job=job.replace(old,new)
old="""assert hashlib.sha256(f.read_bytes()).hexdigest()==h;check();r.update(state='complete',source_hashes_match=True,binary_hash_matches=True);save()"""
new="""run([str(out/'questions'),'--nocapture','--test-threads=1'],'public-questions')
        for row in r['results']:assert hashlib.sha256((out/row['name']).read_bytes()).hexdigest()==row['sha256']
        check();r.update(state='complete',source_hashes_match=True,binary_hashes_match=True);save()"""
assert old in job;job=job.replace(old,new)
job=job.replace('REMOTE',repr(remote)).replace('PIN',repr(pin))
compile(job,'reader-job','exec');(local/'job.py').write_text(job)
launch='from pathlib import Path;import subprocess;p=Path('+repr(remote)+');q=p/"job.py";q.write_text('+repr(job)+');log=(p/"launcher.log").open("w");c=subprocess.Popen(["/usr/bin/python3",str(q)],stdout=log,stderr=log,start_new_session=True);print(c.pid)'
print(call(launch,'launch'),flush=True)
