from pathlib import Path
import json,subprocess

local=Path('/tmp/gpui-reader-ticket-mac-root')
template=Path('/tmp/gpui-mac-question-cost-retry1-root.py').read_text()
start=template.index("job=r'''")+8;end=template.index("'''.replace('REMOTE'",start)
job=template[start:end]
job=job.replace("out=p/'question-cost-pair-retry1'","out=p/'question-ticket-pair'")
job=job.replace("variants={'baseline':p/'source','typed':p/'transport-0176e16f/source'}","variants={'typed':p/'transport-0176e16f/source','ticket':p/'reader-bcbee2b1/source'}")
job=job.replace("{'baseline':'5aff5a1b30cd2518ecd69852fa586fbdeafcdbff','typed':'0176e16f7a2a2c0159162c73af470b74769be45d'}","{'typed':'0176e16f7a2a2c0159162c73af470b74769be45d','ticket':'bcbee2b1a1d37e3c89ffe6253c8c161a53f52f54'}")
job=job.replace("['baseline','typed'] if repeat%2==0 else ['typed','baseline']","['typed','ticket'] if repeat%2==0 else ['ticket','typed']")
job=job.replace("Paired existing public recording-window question_cost fixture on M3 Pro.","Paired typed mailbox versus bound-ticket admission public question_cost fixture on M3 Pro.")
remote='/Users/mileswirht/gpui-reactivity-20261024-root'
job=job.replace('REMOTE',repr(remote))
compile(job,'question-ticket-job','exec');(local/'cost-job.py').write_text(job)
launch='from pathlib import Path;import subprocess;p=Path('+repr(remote)+');q=p/"question-ticket-cost-job.py";q.write_text('+repr(job)+');log=(p/"question-ticket-cost-launcher.log").open("w");c=subprocess.Popen(["/usr/bin/python3",str(q)],stdout=log,stderr=log,start_new_session=True);print(c.pid)'
p=subprocess.run(['rex','--timeout','30s','-C','mac','do','mac.exec','--args',json.dumps({'argv':['/usr/bin/python3','-c',launch]}),'--json'],capture_output=True,text=True,timeout=45)
(local/'cost-launch.json').write_text(p.stdout);assert p.returncode==0,p.stderr
r=json.loads(p.stdout);assert r.get('ok') and r.get('code')==0,r
print(p.stdout)
