from pathlib import Path
import argparse,base64,hashlib,json,subprocess,tarfile

parser=argparse.ArgumentParser();parser.add_argument('profile',choices=['ime','diagnostics','observer','ime-a623','component','typed-transport','question-cost','reader-ticket','question-ticket','reader-unwind']);a=parser.parse_args()
top='/Users/mileswirht/gpui-reactivity-20261024-root'
local=Path('/tmp/gpui-mac-collected-root-20261024')/a.profile;local.mkdir(parents=True)
def call(code):
    p=subprocess.run(['rex','--timeout','30s','-C','mac','do','mac.exec','--args',json.dumps({'argv':['/usr/bin/python3','-c',code]}),'--json'],capture_output=True,text=True,timeout=45)
    assert p.returncode==0,p.stderr
    r=json.loads(p.stdout);assert r.get('ok') and r.get('code')==0,r
    return r['stdout']

pack=r'''from pathlib import Path
import hashlib,json,tarfile
p=Path(TOP);profile=PROFILE
paths={'ime':['ime-9e00c79f/result','ime-9e00c79f/native-suite'],'diagnostics':['gpu-diagnostics-nightly'],'observer':['native-observer-preflight'],'ime-a623':['ime-a623ee8e/result'],'component':['component-9b9500b9/result'],'typed-transport':['transport-0176e16f/result'],'question-cost':['question-cost-pair-retry1'],'reader-ticket':['reader-bcbee2b1/result'],'question-ticket':['question-ticket-pair'],'reader-unwind':['reader-c210a5e8/result']}[profile]
manifest={};external=[]
for name in paths:
    out=p/name;status=json.loads((out/'status.json').read_text());assert status['state']=='complete',status
    for q in sorted(out.rglob('*')):
        assert not q.is_symlink(),q
        if not q.is_file():continue
        with q.open('rb') as f:magic=f.read(4)
        h=hashlib.sha256(q.read_bytes()).hexdigest();relative=str(q.relative_to(p))
        if magic in [b'\xcf\xfa\xed\xfe',b'\xca\xfe\xba\xbe',b'\xfe\xed\xfa\xcf']:
            external.append({'path':relative,'bytes':q.stat().st_size,'sha256':h});continue
        manifest[relative]=h
    if profile in ['ime','ime-a623','component','reader-ticket','reader-unwind']:
        assert status['source_hashes_match'] and status['binary_hashes_match']
        for row in status['results']:
            filename=row.get('file',row['name']);assert hashlib.sha256((out/filename).read_bytes()).hexdigest()==row['sha256']
    if profile=='typed-transport':
        assert status['source_hashes_match'] and status['binary_hash_matches']
        row=json.loads((out/'binary.json').read_text())
        assert hashlib.sha256((out/'gpui').read_bytes()).hexdigest()==row['sha256']
    if profile in ['question-cost','question-ticket']:
        assert status['source_hashes_match'] and status['binary_hashes_match']
        for row in status['artifacts'].values():
            assert hashlib.sha256((out/row['file']).read_bytes()).hexdigest()==row['sha256']
if profile=='ime':
    for name in ['ime-9e00c79f/source/source-manifest.json','ime-9e00c79f/source/source-pin.txt','ime-9e00c79f/job.py','ime-9e00c79f/native-suite-job.py']:
        manifest[name]=hashlib.sha256((p/name).read_bytes()).hexdigest()
metadata={'ime-a623':['ime-a623ee8e/source/source-manifest.json','ime-a623ee8e/source/source-pin.txt','ime-a623ee8e/job.py'], 'component':['component-9b9500b9/source/source-manifest.json','component-9b9500b9/source/source-pin.txt','component-9b9500b9/job.py','component-9b9500b9/source-pin-correction.json'], 'typed-transport':['transport-0176e16f/source/source-manifest.json','transport-0176e16f/source/source-pin.txt','transport-0176e16f/job.py'],'reader-ticket':['reader-bcbee2b1/source/source-manifest.json','reader-bcbee2b1/source/source-pin.txt','reader-bcbee2b1/job.py'],'question-ticket':['question-ticket-cost-job.py'],'reader-unwind':['reader-c210a5e8/source/source-manifest.json','reader-c210a5e8/source/source-pin.txt','reader-c210a5e8/job.py']}
for name in metadata.get(profile,[]):
    if not (p/name).exists():continue
    manifest[name]=hashlib.sha256((p/name).read_bytes()).hexdigest()
archive=p/('collected-'+profile+'-root.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
    for name in manifest:t.add(p/name,arcname=name,recursive=False)
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members_sha256':manifest,'external_executables':external}
(p/('collected-'+profile+'-root-receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
'''.replace('TOP',repr(top)).replace('PROFILE',repr(a.profile))
receipt=json.loads(call(pack));(local/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
part=local/'logs.tar.gz.part'
with part.open('xb') as f:
    for offset in range(0,receipt['bytes'],24*1024):
        code='from pathlib import Path;import base64;f=Path('+repr(receipt['archive'])+').open("rb");f.seek('+str(offset)+');print(base64.b64encode(f.read(24576)).decode())'
        f.write(base64.b64decode(call(code)))
assert hashlib.sha256(part.read_bytes()).hexdigest()==receipt['sha256'];part.rename(local/'logs.tar.gz')
extracted=local/'extracted';extracted.mkdir()
with tarfile.open(local/'logs.tar.gz') as t:
    for m in t:
        assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
        q=extracted/m.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(t.extractfile(m).read())
for name,h in receipt['members_sha256'].items():assert hashlib.sha256((extracted/name).read_bytes()).hexdigest()==h,name
print(json.dumps({'profile':a.profile,'bytes':receipt['bytes'],'sha256':receipt['sha256'],'log_members':len(receipt['members_sha256']),'external_executables':len(receipt['external_executables']),'all_match':True}),flush=True)
