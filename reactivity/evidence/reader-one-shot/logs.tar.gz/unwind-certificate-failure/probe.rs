use gpui::Completion;
use std::{cell::Cell, convert::Infallible, panic::{RefUnwindSafe, UnwindSafe}};

fn assert_traits<T: Send + Sync + UnwindSafe + RefUnwindSafe>() {}

pub fn completion_traits() {
    assert_traits::<Completion<Cell<u8>, Infallible>>();
}
