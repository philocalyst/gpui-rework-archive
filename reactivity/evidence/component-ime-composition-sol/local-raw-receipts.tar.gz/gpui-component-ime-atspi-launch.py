from pathlib import Path
import json,os,signal,subprocess,sys,time
out=Path(sys.argv[1]);binary=sys.argv[2];test=sys.argv[3]
assert os.environ.get('DBUS_SESSION_BUS_ADDRESS')
launcher='/nix/store/4g39rajyrxqn3na1kd4pykdigsr82af5-at-spi2-core-2.60.6/libexec/at-spi-bus-launcher'
with (out/'atspi-launcher.log').open('w') as log:
 p=subprocess.Popen([launcher,'--launch-immediately','--a11y=1'],env=dict(os.environ,ATSPI_DBUS_IMPLEMENTATION='dbus-daemon'),stdout=log,stderr=log,start_new_session=True)
 try:
  deadline=time.monotonic()+20
  while True:
   r=subprocess.run(['busctl','--json=short','--timeout=2','--address='+os.environ['DBUS_SESSION_BUS_ADDRESS'],'call','org.a11y.Bus','/org/a11y/bus','org.a11y.Bus','GetAddress'],capture_output=True,text=True,timeout=3)
   if r.returncode==0:break
   assert p.poll() is None and time.monotonic()<deadline,'actual AT-SPI launcher readiness'
   time.sleep(.05)
  (out/'atspi-address.json').write_text(r.stdout)
  result=subprocess.run([binary,test,'--exact','--ignored','--nocapture','--test-threads=1'],timeout=55)
 finally:
  try:os.killpg(p.pid,signal.SIGTERM)
  except ProcessLookupError:pass
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
  (out/'atspi-launcher-reaped.json').write_text(json.dumps({'pid':p.pid,'exit':p.returncode,'process_group_terminated':True})+'\n')
sys.exit(result.returncode)
