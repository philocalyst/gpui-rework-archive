from pathlib import Path
import json,os,subprocess,tempfile,select,signal,sys
exe='/root/gpui-component-ime-sol-artifacts-20261024/native-unit-2-3ab1d96498/gpui-gpui-52fe618ddfae8b3f'
with tempfile.TemporaryDirectory(prefix='gpui-component-ime-native-') as runtime:
 os.chmod(runtime,0o700)
 r,w=os.pipe()
 with open('/tmp/gpui-component-ime-native-property-xvfb.log','w') as log:
  server=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb','-displayfd',str(w),'-screen','0','1200x800x24','-nolisten','tcp','-noreset'],pass_fds=(w,),stdout=log,stderr=log,start_new_session=True)
  os.close(w)
  try:
   assert select.select([r],[],[],10)[0]
   display=':'+os.read(r,32).decode().strip()
   env=dict(os.environ,DISPLAY=display,XDG_RUNTIME_DIR=runtime,WINIT_X11_SCALE_FACTOR='1')
   for name in ['WAYLAND_DISPLAY','AT_SPI_BUS_ADDRESS','NO_AT_BRIDGE']:env.pop(name,None)
   args=['/nix/store/8snmq54bp5d5vp5dihgn7xr53hayx629-dbus-1.16.2/bin/dbus-run-session','--',exe,'--ignored','--exact',sys.argv[1],'--nocapture','--test-threads=1']
   with open('/tmp/gpui-component-ime-native-'+sys.argv[2]+'.log','w') as output:
    app=subprocess.Popen(args,env=env,stdout=output,stderr=output,start_new_session=True)
    try:code=app.wait(timeout=50)
    finally:
     if app.poll() is None:os.killpg(app.pid,signal.SIGTERM);app.wait(timeout=5)
   print('native property test exit='+str(code))
   sys.exit(code)
  finally:
   os.close(r);os.killpg(server.pid,signal.SIGTERM);server.wait(timeout=5)
