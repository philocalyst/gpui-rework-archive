from pathlib import Path
import hashlib,json,subprocess,tarfile,shutil,io
root=Path('/root/gpui-component-ime-review-sol-20261024');pin='3ab1d964981f44d503f1df9b4947c929c6742160';parent='0e97be59c5a033f7ca146a45ab739477261ad900'
local=Path('/tmp/gpui-component-ime-mac-3ab1-sol');assert not local.exists() or not any(local.iterdir());local.mkdir(exist_ok=True)
guard=json.loads(Path('/tmp/gpui-component-ime-full-default.before.json').read_text())
after=dict(guard['files']);extra={}
for name in ['Cargo.toml','Cargo.lock']:
 data=subprocess.check_output(['git','-C',str(root),'show',pin+':'+name]);extra[name]=data;after[name]=hashlib.sha256(data).hexdigest()
(local/'after.json').write_text(json.dumps(after,indent=2)+'\n')
base=json.loads(Path('/tmp/gpui-component-review-mac-7a-sol/collected/incoming/before.json').read_text())
(local/'before.json').write_text(json.dumps(base,indent=2)+'\n')
delta=dict(added=sorted(set(after)-set(base)),changed=sorted(n for n in set(after)&set(base) if after[n]!=base[n]),deleted=sorted(set(base)-set(after)))
(local/'delta.json').write_text(json.dumps(delta,indent=2)+'\n')
(local/'pin.json').write_text(json.dumps(dict(build_input_commit=pin,parent=parent,source_guard_files=len(after),local_gate_guard=guard['aggregate'],local_gate_files=len(guard['files']),supplemental_root_files=['Cargo.toml','Cargo.lock']),indent=2)+'\n')
archive=local/'capsule.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for n in ['before.json','after.json','delta.json','pin.json']:tar.add(local/n,arcname=n)
 for n in delta['added']+delta['changed']:
  if n in extra:
   info=tarfile.TarInfo('overlay/'+n);info.size=len(extra[n]);info.mode=0o644;tar.addfile(info,io.BytesIO(extra[n]))
  else:tar.add(root/n,arcname='overlay/'+n)
receipt=dict(pin=pin,parent=parent,base='5aff5a1b30cd2518ecd69852fa586fbdeafcdbff',added=len(delta['added']),changed=len(delta['changed']),deleted=delta['deleted'],before_files=len(base),after_files=len(after),bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
(local/'capsule-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
# A separate exact Git feature delta is for Root's deliberate IME composition.
shipping=local/'shipping';shipping.mkdir()
patch=subprocess.check_output(['git','-C',str(root),'diff','--binary',parent,pin,'--'])
(shipping/'feature.patch').write_bytes(patch)
changes=subprocess.check_output(['git','-C',str(root),'diff','--name-status',parent,pin],text=True)
(shipping/'changed-names.txt').write_text(changes)
(shipping/'deleted-names.json').write_text(json.dumps([x.split('\t')[1] for x in changes.splitlines() if x.startswith('D\t')],indent=2)+'\n')
for n in ['after.json','pin.json']:shutil.copy2(local/n,shipping/n)
(shipping/'source-commit.txt').write_text(subprocess.check_output(['git','-C',str(root),'show','--no-patch','--format=fuller',pin],text=True))
with tarfile.open(local/'shipping-delta.tar.gz','w:gz') as tar:
 for p in sorted(shipping.iterdir()):tar.add(p,arcname=p.name)
p=local/'shipping-delta.tar.gz';(local/'shipping-receipt.json').write_text(json.dumps(dict(source=pin,parent=parent,files=len(changes.splitlines()),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),deleted=[]),indent=2)+'\n')
print(json.dumps(receipt));print((local/'shipping-receipt.json').read_text())
