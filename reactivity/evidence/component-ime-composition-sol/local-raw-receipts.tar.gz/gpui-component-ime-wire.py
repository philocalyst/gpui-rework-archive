from pathlib import Path
import hashlib,json,os,select,signal,subprocess,sys
out=Path(sys.argv[1]);out.mkdir();rows=[json.loads(l) for l in Path('/tmp/gpui-component-ime-native-unit-2.jsonl').read_text().splitlines() if l.startswith('{')];artifacts=[r for r in rows if r.get('reason')=='compiler-artifact' and r.get('executable') and r['profile']['test'] and r['target']['name']=='gpui'];assert len(artifacts)==1
row=artifacts[0];frozen=json.loads(Path('/root/gpui-component-ime-sol-artifacts-20261024/native-unit-2-3ab1d96498/manifest.json').read_text());binary=Path(frozen[0]['frozen'])
def digest():
 with binary.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
stat=binary.stat();before=digest();(out/'binary.json').write_text(json.dumps({'path':str(binary),'sha256':before,'bytes':stat.st_size,'inode':stat.st_ino,'mtime_ns':stat.st_mtime_ns,'features':row['features'],'fresh':row['fresh']},indent=2)+'\n')
results=[]
def run(label,argv,env=None):
 with (out/(label+'.stdout.log')).open('w') as stdout,(out/(label+'.stderr.log')).open('w') as stderr:
  p=subprocess.Popen(argv,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
  try: code=p.wait(timeout=60)
  except subprocess.TimeoutExpired:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   raise
  finally:
   try:os.killpg(p.pid,signal.SIGTERM)
   except ProcessLookupError:pass
 results.append({'label':label,'argv':argv,'exit':code});return code
r,w=os.pipe()
with (out/'xvfb.log').open('w') as log:
 server=subprocess.Popen(['/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb','-displayfd',str(w),'-screen','0','1024x768x24','-nolisten','tcp'],pass_fds=(w,),stdout=log,stderr=subprocess.STDOUT)
 os.close(w)
 try:
  assert select.select([r],[],[],20)[0],'Xvfb readiness watchdog'
  n=os.read(r,32).decode().strip();assert n.isdecimal()
  env=dict(os.environ,DISPLAY=':'+n,GSETTINGS_BACKEND='memory')
  runtime=out/'runtime';runtime.mkdir(mode=0o700)
  wire_env=dict(env,XDG_RUNTIME_DIR=str(runtime),WINIT_X11_SCALE_FACTOR='1.25')
  for key in ['WAYLAND_DISPLAY','AT_SPI_BUS_ADDRESS','NO_AT_BRIDGE']:wire_env.pop(key,None)
  run('atspi',['dbus-run-session','--','/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3','/tmp/gpui-component-ime-atspi-launch.py',str(out),str(binary),'native::accessibility::linux_tests::ime::native_atspi_ime_cjk_preview_old_candidate_ack_and_commit',],wire_env)
 finally:
  os.close(r);server.terminate()
  try:server.wait(timeout=5)
  except subprocess.TimeoutExpired:server.kill();server.wait()
assert digest()==before and binary.stat().st_ino==stat.st_ino and binary.stat().st_mtime_ns==stat.st_mtime_ns
(out/'result.json').write_text(json.dumps({'tests':results,'binary_unchanged':True,'children_reaped':True,'scope':'Real X11 native Window/CPU submission and complete server pixels; normalized Winit IME callbacks, not OS candidate-engine synthesis. AccessKit consumer P projection.'},indent=2)+'\n')
print(json.dumps(results));sys.exit(int(any(r['exit'] for r in results)))
