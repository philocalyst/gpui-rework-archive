from pathlib import Path
import hashlib, json, subprocess, sys, tempfile
sys.path.insert(0,'/root/gpui-ce3/reactivity/tools')
from core_lines import without_tests
from inventory import rust_analysis
helper=Path('/tmp/gpui-inventory-sol-target/release/inventory-rust')
tokei=Path('/tmp/gpui-qualified-tokei-root/bin/tokei')
source=Path('/tmp/gpui-close-integration-root')
paths=['reactivity/vendor/accesskit_atspi_common/src/adapter.rs','reactivity/vendor/accesskit_unix/src/adapter.rs','reactivity/vendor/accesskit_unix/tests/service_lifecycle.rs']
result={'scope':'Changed vendor files only; Syn strips test syntax and Tokei excludes comments/blanks. Test target service_lifecycle is entirely excluded. Not added to the six-library core count.','helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'tokei_sha256':hashlib.sha256(tokei.read_bytes()).hexdigest(),'versions':{}}
for version,pin in [('baseline','7617e15a22'),('candidate','34e9290b7ecaf882b069a048bae4a7160c66d489')]:
    sources=[(path,subprocess.check_output(['git','-c',f'safe.directory={source}','-C',str(source),'show',pin+':'+path]),'Rust') for path in paths]
    analysis=rust_analysis(sources,helper)
    rows={}
    with tempfile.TemporaryDirectory(prefix='gpui-close-vendor-count-') as temporary:
        root=Path(temporary)
        for path,data,_ in sources:
            detail=analysis[path]
            assert not detail['unclassified'],detail
            test_target='/tests/' in path
            content='' if test_target else without_tests(data.decode(),detail['test_ranges'])
            dest=root/path
            dest.parent.mkdir(parents=True,exist_ok=True)
            dest.write_text(content)
            rows[path]={'source_sha256':hashlib.sha256(data).hexdigest(),'test_target':test_target,'code_lines':0}
        counted=json.loads(subprocess.check_output([str(tokei),'--no-ignore','--files','--output','json',str(root)],text=True))
        for lang,summary in counted.items():
            if lang=='Total': continue
            for report in summary['reports']:
                path=Path(report['name']).relative_to(root).as_posix()
                rows[path]['code_lines']=report['stats']['code']
    result['versions'][version]={'source':subprocess.check_output(['git','-C',str(source),'rev-parse',pin],text=True).strip(),'total':sum(r['code_lines'] for r in rows.values()),'files':rows}
result['delta_non_test_code_lines']=result['versions']['candidate']['total']-result['versions']['baseline']['total']
out=Path('/tmp/gpui-close-composition-root-evidence/vendor-lines.json')
out.parent.mkdir(parents=True,exist_ok=True)
out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({key:value for key,value in result.items() if key!='versions'}))
print(json.dumps({key:row['total'] for key,row in result['versions'].items()}))
