
/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000006e8d10 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>>:
  6e8d10:	push   %rbp
  6e8d11:	push   %r15
  6e8d13:	push   %r14
  6e8d15:	push   %r13
  6e8d17:	push   %r12
  6e8d19:	push   %rbx
  6e8d1a:	sub    $0xe8,%rsp
  6e8d21:	mov    %rsi,%r14
  6e8d24:	mov    %rdi,%r15
  6e8d27:	mov    0x130(%rsi),%rbx
  6e8d2e:	test   %rbx,%rbx
  6e8d31:	je     6e8d4a <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x3a>
  6e8d33:	mov    %ecx,0x28(%rsp)
  6e8d37:	cmpb   $0x1,0x756(%rbx)
  6e8d3e:	jne    6e8d6e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x5e>
  6e8d40:	mov    $0xe,%ebp
  6e8d45:	jmp    6e900b <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x2fb>
  6e8d4a:	movq   $0x2,(%r15)
  6e8d51:	movq   $0xd,0x8(%r15)
  6e8d59:	movq   $0x0,0x10(%r15)
  6e8d61:	mov    %r14,0x18(%r15)
  6e8d65:	mov    %ecx,0x40(%r15)
  6e8d69:	jmp    6e91b9 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x4a9>
  6e8d6e:	mov    %rdx,%r13
  6e8d71:	mov    0x698(%rbx),%rax
  6e8d78:	mov    %rax,0x38(%rsp)
  6e8d7d:	lea    0x290(%rbx),%r12
  6e8d84:	mov    0x18(%rdx),%rax
  6e8d88:	mov    %r12,%rdi
  6e8d8b:	mov    %r14,0x8(%rsp)
  6e8d90:	mov    %rax,0x48(%rsp)
  6e8d95:	mov    %rbx,0x10(%rsp)
  6e8d9a:	call   *%rax
  6e8d9c:	mov    %rax,0x20(%rsp)
  6e8da1:	mov    %r12,0x18(%rsp)
  6e8da6:	mov    0x0(%r13),%r12
  6e8daa:	cmp    $0x1,%r12d
  6e8dae:	jne    6e8e16 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x106>
  6e8db0:	mov    0x248(%rbx),%rbp
  6e8db7:	mov    0x250(%rbx),%rbx
  6e8dbe:	shl    $0x4,%rbx
  6e8dc2:	xor    %r14d,%r14d
  6e8dc5:	data16 cs nopw 0x0(%rax,%rax,1)
  6e8dd0:	cmp    %r14,%rbx
  6e8dd3:	je     6e8f72 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x262>
  6e8dd9:	mov    0x0(%rbp,%r14,1),%rdi
  6e8dde:	mov    0x8(%rbp,%r14,1),%rax
  6e8de3:	call   *0x18(%rax)
  6e8de6:	add    $0x10,%r14
  6e8dea:	cmp    %r12,%rax
  6e8ded:	jne    6e8dd0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0xc0>
  6e8def:	mov    -0x10(%rbp,%r14,1),%rdi
  6e8df4:	mov    -0x8(%rbp,%r14,1),%rax
  6e8df9:	mov    0x18(%rsp),%rsi
  6e8dfe:	mov    0x8(%rsp),%r14
  6e8e03:	mov    0x10(%rsp),%rbx
  6e8e08:	call   *0x28(%rax)
  6e8e0b:	mov    %rax,%rdi
  6e8e0e:	mov    %rdx,%rax
  6e8e11:	jmp    6e8e9a <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x18a>
  6e8e16:	mov    0x278(%rbx),%rbp
  6e8e1d:	mov    0x280(%rbx),%rbx
  6e8e24:	shl    $0x4,%rbx
  6e8e28:	xor    %r14d,%r14d
  6e8e2b:	nopl   0x0(%rax,%rax,1)
  6e8e30:	cmp    %r14,%rbx
  6e8e33:	je     6e8f72 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x262>
  6e8e39:	mov    0x0(%rbp,%r14,1),%rdi
  6e8e3e:	mov    0x8(%rbp,%r14,1),%rax
  6e8e43:	mov    %r12,%rsi
  6e8e46:	call   *0x30(%rax)
  6e8e49:	add    $0x10,%r14
  6e8e4d:	test   %al,%al
  6e8e4f:	je     6e8e30 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x120>
  6e8e51:	mov    -0x10(%rbp,%r14,1),%rsi
  6e8e56:	mov    -0x8(%rbp,%r14,1),%rax
  6e8e5b:	lea    0xa8(%rsp),%rdi
  6e8e63:	mov    0x18(%rsp),%rdx
  6e8e68:	mov    %r12,%rcx
  6e8e6b:	mov    0x8(%rsp),%r14
  6e8e70:	mov    0x10(%rsp),%rbx
  6e8e75:	call   *0x58(%rax)
  6e8e78:	mov    0xa8(%rsp),%rcx
  6e8e80:	mov    0xb0(%rsp),%rdi
  6e8e88:	mov    0xb8(%rsp),%rax
  6e8e90:	cmp    $0xffffffffffffffff,%rcx
  6e8e94:	jne    6e8f84 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x274>
  6e8e9a:	lea    0x3924ef(%rip),%rdx        # a7b390 <anon.dff37607ed4abf3f332318fda1fd6b2c.5.llvm.11034051715724540866>
  6e8ea1:	mov    0x20(%rsp),%rsi
  6e8ea6:	call   *0x20(%rax)
  6e8ea9:	test   %al,%al
  6e8eab:	je     6e8f89 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x279>
  6e8eb1:	movq   $0x0,0x50(%rsp)
  6e8eba:	mov    $0xe,%ebp
  6e8ebf:	cmpb   $0x0,0x756(%rbx)
  6e8ec6:	jne    6e8fbc <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x2ac>
  6e8ecc:	mov    0x698(%rbx),%rax
  6e8ed3:	inc    %rax
  6e8ed6:	mov    %rax,0xe0(%rsp)
  6e8ede:	je     6e9271 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x561>
  6e8ee4:	mov    0x18(%rsp),%rbp
  6e8ee9:	mov    %rbp,%rdi
  6e8eec:	call   *0x48(%rsp)
  6e8ef0:	mov    %rax,0x20(%rsp)
  6e8ef5:	mov    %rbp,%rdi
  6e8ef8:	call   *0x20(%r13)
  6e8efc:	cmp    %rax,0x20(%rsp)
  6e8f01:	je     6e91ce <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x4be>
  6e8f07:	movq   $0xa,0xb0(%rsp)
  6e8f13:	mov    %r12,0xb8(%rsp)
  6e8f1b:	mov    %r14,0xc8(%rsp)
  6e8f23:	movups 0xd0(%rsp),%xmm0
  6e8f2b:	movups %xmm0,0x98(%rsp)
  6e8f33:	mov    0xb0(%rsp),%rax
  6e8f3b:	mov    %rax,0x78(%rsp)
  6e8f40:	mov    0xb8(%rsp),%rax
  6e8f48:	mov    %rax,0x80(%rsp)
  6e8f50:	mov    0xc0(%rsp),%rax
  6e8f58:	mov    %rax,0x88(%rsp)
  6e8f60:	mov    0xc8(%rsp),%rax
  6e8f68:	mov    %rax,0x90(%rsp)
  6e8f70:	jmp    6e8fb7 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x2a7>
  6e8f72:	mov    $0xb,%ecx
  6e8f77:	mov    %r12,%rdi
  6e8f7a:	mov    0x8(%rsp),%r14
  6e8f7f:	mov    0x10(%rsp),%rbx
  6e8f84:	mov    %rdi,%r12
  6e8f87:	jmp    6e8f8e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x27e>
  6e8f89:	mov    $0xa,%ecx
  6e8f8e:	mov    %r12,0x58(%rsp)
  6e8f93:	mov    %rax,0x60(%rsp)
  6e8f98:	mov    0x58(%rsp),%rax
  6e8f9d:	mov    %rax,0x80(%rsp)
  6e8fa5:	mov    0x60(%rsp),%rax
  6e8faa:	mov    %rax,0x88(%rsp)
  6e8fb2:	mov    %rcx,0x78(%rsp)
  6e8fb7:	mov    $0x20,%ebp
  6e8fbc:	mov    $0x1,%r8b
  6e8fbf:	mov    0x78(%rsp),%r9
  6e8fc4:	mov    0x80(%rsp),%rdi
  6e8fcc:	mov    0x88(%rsp),%rdx
  6e8fd4:	movzbl 0x90(%rsp),%esi
  6e8fdc:	mov    0x98(%rsp),%rax
  6e8fe4:	mov    0xa0(%rsp),%rcx
  6e8fec:	mov    0x94(%rsp),%r10d
  6e8ff4:	mov    %r10d,0x43(%rsp)
  6e8ff9:	mov    0x91(%rsp),%r10d
  6e9001:	mov    %r10d,0x40(%rsp)
  6e9006:	test   %r8b,%r8b
  6e9009:	je     6e9068 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x358>
  6e900b:	movq   $0x2,(%r15)
  6e9012:	mov    %rbp,0x8(%r15)
  6e9016:	mov    %r9,0x10(%r15)
  6e901a:	mov    %rdi,0x18(%r15)
  6e901e:	mov    %rdx,0x20(%r15)
  6e9022:	mov    %sil,0x28(%r15)
  6e9026:	mov    0x40(%rsp),%edx
  6e902a:	mov    0x43(%rsp),%esi
  6e902e:	mov    %edx,0x29(%r15)
  6e9032:	mov    %esi,0x2c(%r15)
  6e9036:	mov    %rax,0x30(%r15)
  6e903a:	mov    %rcx,0x38(%r15)
  6e903e:	mov    0x28(%rsp),%eax
  6e9042:	mov    %eax,0x40(%r15)
  6e9046:	mov    0x31(%rsp),%eax
  6e904a:	mov    0x34(%rsp),%ecx
  6e904e:	mov    %eax,0x51(%r15)
  6e9052:	mov    %ecx,0x54(%r15)
  6e9056:	cmpb   $0x0,0x756(%rbx)
  6e905d:	je     6e91a7 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x497>
  6e9063:	jmp    6e91b1 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x4a1>
  6e9068:	mov    0x698(%rbx),%r11
  6e906f:	cmp    0x38(%rsp),%r11
  6e9074:	jne    6e909d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x38d>
  6e9076:	mov    $0x4,%r12d
  6e907c:	lea    0x50(%rsp),%r13
  6e9081:	mov    %r8,0x28(%rsp)
  6e9086:	mov    %rax,0x8(%rsp)
  6e908b:	mov    %rcx,0x18(%rsp)
  6e9090:	mov    %r9,%r11
  6e9093:	mov    %rdx,0x38(%rsp)
  6e9098:	mov    %esi,%r8d
  6e909b:	jmp    6e9118 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x408>
  6e909d:	mov    %rdi,%r8
  6e90a0:	shr    $0x20,%r8
  6e90a4:	movzbl 0x754(%rbx),%r10d
  6e90ac:	cmpq   $0x0,0x6b8(%rbx)
  6e90b4:	mov    %r8,0x28(%rsp)
  6e90b9:	je     6e90ca <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x3ba>
  6e90bb:	test   %r10b,%r10b
  6e90be:	je     6e90d2 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x3c2>
  6e90c0:	cmpq   $0xffffffffffffffff,0x5c0(%rbx)
  6e90c8:	jne    6e90d2 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x3c2>
  6e90ca:	mov    %rbx,%r8
  6e90cd:	xor    %r12d,%r12d
  6e90d0:	jmp    6e90e7 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x3d7>
  6e90d2:	mov    %rbx,%r8
  6e90d5:	mov    0x6c8(%rbx),%rbx
  6e90dc:	mov    %rbx,0x48(%rsp)
  6e90e1:	mov    $0x1,%r12d
  6e90e7:	mov    %edi,0x20(%rsp)
  6e90eb:	mov    %r8,%rbx
  6e90ee:	mov    0x6a0(%r8),%rdi
  6e90f5:	mov    0x740(%r8),%r8
  6e90fc:	mov    %r8,0x38(%rsp)
  6e9101:	lea    0x31(%rsp),%r13
  6e9106:	mov    %rbp,0x8(%rsp)
  6e910b:	mov    %r9,0x18(%rsp)
  6e9110:	mov    0x48(%rsp),%rbp
  6e9115:	mov    %r10d,%r8d
  6e9118:	lea    0x91(%rsp),%r10
  6e9120:	mov    0x3(%r10),%r9d
  6e9124:	mov    %r9d,0x3(%r13)
  6e9128:	mov    (%r10),%r9d
  6e912b:	mov    %r9d,0x0(%r13)
  6e912f:	mov    %r12,(%r15)
  6e9132:	mov    %rbp,0x8(%r15)
  6e9136:	mov    %r11,0x10(%r15)
  6e913a:	mov    %rdi,0x18(%r15)
  6e913e:	mov    0x38(%rsp),%rdi
  6e9143:	mov    %rdi,0x20(%r15)
  6e9147:	mov    %r8b,0x28(%r15)
  6e914b:	mov    0x50(%rsp),%edi
  6e914f:	mov    %edi,0x29(%r15)
  6e9153:	mov    0x53(%rsp),%edi
  6e9157:	mov    %edi,0x2c(%r15)
  6e915b:	mov    0x8(%rsp),%rdi
  6e9160:	mov    %rdi,0x30(%r15)
  6e9164:	mov    0x18(%rsp),%rdi
  6e9169:	mov    %rdi,0x38(%r15)
  6e916d:	mov    0x20(%rsp),%edi
  6e9171:	mov    %edi,0x40(%r15)
  6e9175:	mov    0x28(%rsp),%rdi
  6e917a:	mov    %edi,0x44(%r15)
  6e917e:	mov    %rdx,0x48(%r15)
  6e9182:	mov    %sil,0x50(%r15)
  6e9186:	mov    0x31(%rsp),%edx
  6e918a:	mov    %edx,0x51(%r15)
  6e918e:	mov    0x34(%rsp),%edx
  6e9192:	mov    %edx,0x54(%r15)
  6e9196:	mov    %rax,0x58(%r15)
  6e919a:	mov    %rcx,0x60(%r15)
  6e919e:	cmpb   $0x0,0x756(%rbx)
  6e91a5:	jne    6e91b1 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x4a1>
  6e91a7:	cmpq   $0xffffffffffffffff,0x698(%rbx)
  6e91af:	jne    6e91b9 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x4a9>
  6e91b1:	mov    %r14,%rdi
  6e91b4:	call   72b2c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  6e91b9:	mov    %r15,%rax
  6e91bc:	add    $0xe8,%rsp
  6e91c3:	pop    %rbx
  6e91c4:	pop    %r12
  6e91c6:	pop    %r13
  6e91c8:	pop    %r14
  6e91ca:	pop    %r15
  6e91cc:	pop    %rbp
  6e91cd:	ret
  6e91ce:	mov    0x4(%rax),%ecx
  6e91d1:	cmp    $0xffffffff,%ecx
  6e91d4:	je     6e927b <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x56b>
  6e91da:	inc    %ecx
  6e91dc:	mov    %ecx,0x4(%rax)
  6e91df:	mov    0x28(%rsp),%ecx
  6e91e3:	mov    %ecx,(%rax)
  6e91e5:	mov    0xe0(%rsp),%rax
  6e91ed:	mov    %rax,0x698(%rbx)
  6e91f4:	incq   0x6e8(%rbx)
  6e91fb:	movq   $0x0,0x740(%rbx)
  6e9206:	lea    0x70(%rsp),%rdi
  6e920b:	lea    0x50(%rsp),%r8
  6e9210:	mov    %rbx,%rsi
  6e9213:	mov    %r14,%rdx
  6e9216:	mov    %r12,%rcx
  6e9219:	xor    %r9d,%r9d
  6e921c:	call   6f0a50 <<gpui::runtime::RuntimeMut<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::after_source_changed>
  6e9221:	mov    0x70(%rsp),%rbp
  6e9226:	cmp    $0xfffffffffffffffe,%rbp
  6e922a:	jne    6e9269 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x559>
  6e922c:	movups 0x78(%rsp),%xmm0
  6e9231:	movups 0x88(%rsp),%xmm1
  6e9239:	movups 0x98(%rsp),%xmm2
  6e9241:	movups %xmm2,0x28(%r15)
  6e9246:	movups %xmm1,0x18(%r15)
  6e924b:	movups %xmm0,0x8(%r15)
  6e9250:	movq   $0xffffffffffffffff,(%r15)
  6e9257:	cmpb   $0x0,0x756(%rbx)
  6e925e:	je     6e91a7 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x497>
  6e9264:	jmp    6e91b1 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x4a1>
  6e9269:	xor    %r8d,%r8d
  6e926c:	jmp    6e8fbf <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x2af>
  6e9271:	mov    $0x1f,%ebp
  6e9276:	jmp    6e8fbc <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x2ac>
  6e927b:	lea    -0x68b8ab(%rip),%rdi        # 5d9d7 <anon.d6806d9f56049ce1dff51ddf23659ee5.67.llvm.11139854418402343214>
  6e9282:	lea    0x3928a7(%rip),%rdx        # a7bb30 <anon.d6806d9f56049ce1dff51ddf23659ee5.69.llvm.11139854418402343214>
  6e9289:	mov    $0x19,%esi
  6e928e:	call   *0x3ba27c(%rip)        # aa3510 <_DYNAMIC+0x2b0>
  6e9294:	ud2
  6e9296:	mov    %rax,%r15
  6e9299:	mov    0x10(%rsp),%rax
  6e929e:	cmpb   $0x0,0x756(%rax)
  6e92a5:	jne    6e92b6 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x5a6>
  6e92a7:	mov    0x10(%rsp),%rax
  6e92ac:	cmpq   $0xffffffffffffffff,0x698(%rax)
  6e92b4:	jne    6e92c0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x5b0>
  6e92b6:	mov    0x8(%rsp),%rdi
  6e92bb:	call   72b2c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  6e92c0:	mov    %r15,%rdi
  6e92c3:	call   a78330 <_Unwind_Resume@plt>
  6e92c8:	call   *0x3ba22a(%rip)        # aa34f8 <_DYNAMIC+0x298>
  6e92ce:	jmp    6e92d2 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x5c2>
  6e92d0:	jmp    6e92d2 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x5c2>
  6e92d2:	mov    %rax,%rdi
  6e92d5:	call   *0x3ba23d(%rip)        # aa3518 <_DYNAMIC+0x2b8>
  6e92db:	mov    %rax,%r12
  6e92de:	mov    %rdx,%r13
  6e92e1:	mov    %rax,0x58(%rsp)
  6e92e6:	mov    %rdx,0x60(%rsp)
  6e92eb:	movq   $0xfffffffffffffffe,0x50(%rsp)
  6e92f4:	mov    0x10(%rsp),%rdi
  6e92f9:	call   70a2e0 <<gpui::runtime::Runtime<owner_source_control::Model>>::poison>
  6e92fe:	mov    0x0(%r13),%rax
  6e9302:	test   %rax,%rax
  6e9305:	je     6e9374 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x664>
  6e9307:	mov    %r12,%rdi
  6e930a:	call   *%rax
  6e930c:	jmp    6e9374 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x664>
  6e930e:	jmp    6e939e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x68e>
  6e9313:	mov    %rax,%r15
  6e9316:	lea    0x50(%rsp),%rdi
  6e931b:	call   6ea610 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::element::Admission, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e9320:	jmp    6e9299 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x589>
  6e9325:	call   *0x3ba1cd(%rip)        # aa34f8 <_DYNAMIC+0x298>
  6e932b:	call   *0x3ba1ef(%rip)        # aa3520 <_DYNAMIC+0x2c0>
  6e9331:	mov    %rax,%rdi
  6e9334:	call   *0x3ba1de(%rip)        # aa3518 <_DYNAMIC+0x2b8>
  6e933a:	mov    %rax,%r12
  6e933d:	mov    %rdx,%r13
  6e9340:	mov    %rax,0xb0(%rsp)
  6e9348:	mov    %rdx,0xb8(%rsp)
  6e9350:	movq   $0xfffffffffffffffd,0xa8(%rsp)
  6e935c:	mov    0x10(%rsp),%rdi
  6e9361:	call   70a2e0 <<gpui::runtime::Runtime<owner_source_control::Model>>::poison>
  6e9366:	mov    0x0(%r13),%rax
  6e936a:	test   %rax,%rax
  6e936d:	je     6e9374 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x664>
  6e936f:	mov    %r12,%rdi
  6e9372:	call   *%rax
  6e9374:	mov    0x8(%r13),%rsi
  6e9378:	mov    $0xf,%ebp
  6e937d:	test   %rsi,%rsi
  6e9380:	je     6e938f <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x67f>
  6e9382:	mov    0x10(%r13),%rdx
  6e9386:	mov    %r12,%rdi
  6e9389:	call   *0x3ba119(%rip)        # aa34a8 <_DYNAMIC+0x248>
  6e938f:	mov    0x8(%rsp),%r14
  6e9394:	mov    0x10(%rsp),%rbx
  6e9399:	jmp    6e8fbc <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x2ac>
  6e939e:	mov    %rax,%r15
  6e93a1:	mov    0x8(%r13),%rsi
  6e93a5:	test   %rsi,%rsi
  6e93a8:	je     6e9299 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x589>
  6e93ae:	mov    0x10(%r13),%rdx
  6e93b2:	mov    %r12,%rdi
  6e93b5:	call   *0x3ba0ed(%rip)        # aa34a8 <_DYNAMIC+0x248>
  6e93bb:	jmp    6e9299 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x589>
  6e93c0:	mov    %rax,%r15
  6e93c3:	lea    0xa8(%rsp),%rdi
  6e93cb:	call   6ea680 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e93d0:	jmp    6e9299 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>+0x589>
  6e93d5:	call   *0x3ba11d(%rip)        # aa34f8 <_DYNAMIC+0x298>
  6e93db:	call   *0x3ba13f(%rip)        # aa3520 <_DYNAMIC+0x2c0>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000701f20 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index>:
  701f20:	push   %rbx
  701f21:	mov    $0x11,%r9d
  701f27:	cmp    0x5e8(%rsi),%rdx
  701f2e:	jne    701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701f34:	cmpb   $0x1,0x752(%rsi)
  701f3b:	jne    701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701f41:	mov    0x1e8(%rsi),%rax
  701f48:	test   %rax,%rax
  701f4b:	je     701fdc <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xbc>
  701f51:	cmp    $0x1,%eax
  701f54:	jne    701ff6 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd6>
  701f5a:	mov    0x1f8(%rsi),%r8
  701f61:	test   %r8,%r8
  701f64:	je     701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701f6a:	mov    0x1f0(%rsi),%rax
  701f71:	xor    %edx,%edx
  701f73:	cmp    $0x1,%r8
  701f77:	je     701fa4 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x84>
  701f79:	nopl   0x0(%rax)
  701f80:	mov    %rdx,%r10
  701f83:	mov    %r8,%r11
  701f86:	shr    $1,%r11
  701f89:	add    %r11,%rdx
  701f8c:	mov    %rdx,%rbx
  701f8f:	shl    $0x4,%rbx
  701f93:	cmp    %rcx,(%rax,%rbx,1)
  701f97:	cmova  %r10,%rdx
  701f9b:	sub    %r11,%r8
  701f9e:	cmp    $0x1,%r8
  701fa2:	ja     701f80 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x60>
  701fa4:	mov    %rdx,%r10
  701fa7:	shl    $0x4,%r10
  701fab:	xor    %r8d,%r8d
  701fae:	cmp    %rcx,(%rax,%r10,1)
  701fb2:	setbe  %r8b
  701fb6:	add    %rdx,%r8
  701fb9:	je     701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701fbb:	shl    $0x4,%r8
  701fbf:	mov    %rcx,%rdx
  701fc2:	sub    -0x10(%rax,%r8,1),%rdx
  701fc7:	mov    -0x4(%rax,%r8,1),%r10d
  701fcc:	cmp    %r10,%rdx
  701fcf:	jae    701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701fd1:	add    %r8,%rax
  701fd4:	mov    -0x8(%rax),%eax
  701fd7:	add    %rax,%rdx
  701fda:	jmp    702052 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x132>
  701fdc:	mov    %rcx,%rdx
  701fdf:	sub    0x1f0(%rsi),%rdx
  701fe6:	jb     701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701fe8:	cmp    0x1f8(%rsi),%rdx
  701fef:	jb     702052 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x132>
  701ff1:	mov    %r9,(%rdi)
  701ff4:	pop    %rbx
  701ff5:	ret
  701ff6:	mov    0x1f8(%rsi),%rdx
  701ffd:	test   %rdx,%rdx
  702000:	je     701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  702002:	mov    0x1f0(%rsi),%rax
  702009:	cmp    $0x1,%rdx
  70200d:	jne    702016 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xf6>
  70200f:	cmp    %rcx,(%rax)
  702012:	jne    701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  702014:	jmp    70204f <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x12f>
  702016:	xor    %r8d,%r8d
  702019:	nopl   0x0(%rax)
  702020:	mov    %r8,%r10
  702023:	mov    %rdx,%r11
  702026:	shr    $1,%r11
  702029:	add    %r11,%r8
  70202c:	lea    (%r8,%r8,2),%rbx
  702030:	cmp    %rcx,(%rax,%rbx,4)
  702034:	cmova  %r10,%r8
  702038:	sub    %r11,%rdx
  70203b:	cmp    $0x1,%rdx
  70203f:	ja     702020 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x100>
  702041:	lea    (%r8,%r8,2),%rdx
  702045:	cmp    %rcx,(%rax,%rdx,4)
  702049:	jne    701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  70204b:	lea    (%rax,%rdx,4),%rax
  70204f:	mov    0x8(%rax),%edx
  702052:	mov    0x650(%rsi),%rax
  702059:	test   %rax,%rax
  70205c:	je     7020ee <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  702062:	mov    0x658(%rsi),%r8
  702069:	test   %r8,%r8
  70206c:	je     7020de <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1be>
  70206e:	mov    %r8,%r10
  702071:	and    $0x7,%r10
  702075:	je     702097 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x177>
  702077:	xor    %r11d,%r11d
  70207a:	nopw   0x0(%rax,%rax,1)
  702080:	mov    0x590(%rax),%rax
  702087:	inc    %r11
  70208a:	cmp    %r11,%r10
  70208d:	jne    702080 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x160>
  70208f:	mov    %r8,%r10
  702092:	sub    %r11,%r10
  702095:	jmp    70209a <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x17a>
  702097:	mov    %r8,%r10
  70209a:	cmp    $0x8,%r8
  70209e:	jb     7020de <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1be>
  7020a0:	mov    0x590(%rax),%rax
  7020a7:	mov    0x590(%rax),%rax
  7020ae:	mov    0x590(%rax),%rax
  7020b5:	mov    0x590(%rax),%rax
  7020bc:	mov    0x590(%rax),%rax
  7020c3:	mov    0x590(%rax),%rax
  7020ca:	mov    0x590(%rax),%rax
  7020d1:	mov    0x590(%rax),%rax
  7020d8:	add    $0xfffffffffffffff8,%r10
  7020dc:	jne    7020a0 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x180>
  7020de:	cmpw   $0x0,0x58a(%rax)
  7020e6:	je     7020ee <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  7020e8:	cmpq   $0x0,(%rax)
  7020ec:	je     7020fe <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1de>
  7020ee:	mov    %rdx,0x8(%rdi)
  7020f2:	mov    $0xfffffffffffffffe,%r9
  7020f9:	mov    %r9,(%rdi)
  7020fc:	pop    %rbx
  7020fd:	ret
  7020fe:	mov    0x2d8(%rsi),%rax
  702105:	cmp    %rax,%rdx
  702108:	jae    7021c2 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x2a2>
  70210e:	mov    0x2d0(%rsi),%r10
  702115:	mov    $0xffffffff,%r11d
  70211b:	mov    %rdx,%r8
  70211e:	lea    (%r8,%r8,4),%r8
  702122:	mov    0x20(%r10,%r8,8),%ebx
  702127:	and    $0xf,%ebx
  70212a:	cmp    $0x9,%ebx
  70212d:	ja     7021a9 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x289>
  70212f:	cmp    $0x5,%ebx
  702132:	je     702159 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x239>
  702134:	lea    (%r10,%r8,8),%r8
  702138:	mov    0x18(%r8),%r8d
  70213c:	cmp    %r11,%r8
  70213f:	je     7020ee <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  702141:	cmp    %r8,%rax
  702144:	ja     70211e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1fe>
  702146:	lea    0x378153(%rip),%rdx        # a7a2a0 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xb40>
  70214d:	mov    %r8,%rdi
  702150:	mov    %rax,%rsi
  702153:	call   *0x3a1457(%rip)        # aa35b0 <_DYNAMIC+0x350>
  702159:	cmpq   $0xffffffffffffffff,0x5c0(%rsi)
  702161:	mov    0x5b0(%rsi),%r8
  702168:	mov    0x5b8(%rsi),%rax
  70216f:	je     702189 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x269>
  702171:	cmpw   $0x0,0x5e0(%rsi)
  702179:	js     702189 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x269>
  70217b:	mov    0x5c8(%rsi),%r8
  702182:	mov    0x5d0(%rsi),%rax
  702189:	shl    $0x6,%rax
  70218d:	test   %rax,%rax
  702190:	je     701ff1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  702196:	add    $0xffffffffffffffc0,%rax
  70219a:	cmp    %rcx,0x20(%r8)
  70219e:	lea    0x40(%r8),%r8
  7021a2:	jne    70218d <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x26d>
  7021a4:	jmp    7020ee <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  7021a9:	lea    -0x6a5a1b(%rip),%rdi        # 5c795 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e6d>
  7021b0:	lea    0x378149(%rip),%rdx        # a7a300 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xba0>
  7021b7:	mov    $0x83,%esi
  7021bc:	call   *0x3a133e(%rip)        # aa3500 <_DYNAMIC+0x2a0>
  7021c2:	mov    %rdx,%r8
  7021c5:	lea    0x3780d4(%rip),%rdx        # a7a2a0 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xb40>
  7021cc:	mov    %r8,%rdi
  7021cf:	mov    %rax,%rsi
  7021d2:	call   *0x3a13d8(%rip)        # aa35b0 <_DYNAMIC+0x350>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072c8b0 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>>:
  72c8b0:	push   %rbp
  72c8b1:	push   %r15
  72c8b3:	push   %r14
  72c8b5:	push   %r13
  72c8b7:	push   %r12
  72c8b9:	push   %rbx
  72c8ba:	sub    $0x28,%rsp
  72c8be:	mov    %rcx,%r13
  72c8c1:	mov    %rdx,%r12
  72c8c4:	mov    %rsi,%r14
  72c8c7:	mov    %rdi,%rbx
  72c8ca:	mov    %rdx,%rdi
  72c8cd:	call   *0x18(%rsi)
  72c8d0:	mov    %rax,0x8(%rsp)
  72c8d5:	mov    (%r14),%r14
  72c8d8:	cmp    $0x1,%r14d
  72c8dc:	jne    72c927 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x77>
  72c8de:	mov    0x20(%r13),%rbp
  72c8e2:	mov    0x28(%r13),%r15
  72c8e6:	shl    $0x4,%r15
  72c8ea:	xor    %r13d,%r13d
  72c8ed:	nopl   (%rax)
  72c8f0:	cmp    %r13,%r15
  72c8f3:	je     72c9bc <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x10c>
  72c8f9:	mov    0x0(%rbp,%r13,1),%rdi
  72c8fe:	mov    0x8(%rbp,%r13,1),%rax
  72c903:	call   *0x18(%rax)
  72c906:	add    $0x10,%r13
  72c90a:	cmp    %r14,%rax
  72c90d:	jne    72c8f0 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x40>
  72c90f:	mov    -0x10(%rbp,%r13,1),%rdi
  72c914:	mov    -0x8(%rbp,%r13,1),%rax
  72c919:	mov    %r12,%rsi
  72c91c:	call   *0x28(%rax)
  72c91f:	mov    %rax,%rdi
  72c922:	mov    %rdx,%rax
  72c925:	jmp    72c98a <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0xda>
  72c927:	mov    0x50(%r13),%rbp
  72c92b:	mov    0x58(%r13),%r13
  72c92f:	shl    $0x4,%r13
  72c933:	xor    %r15d,%r15d
  72c936:	cs nopw 0x0(%rax,%rax,1)
  72c940:	cmp    %r15,%r13
  72c943:	je     72c9bc <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x10c>
  72c945:	mov    0x0(%rbp,%r15,1),%rdi
  72c94a:	mov    0x8(%rbp,%r15,1),%rax
  72c94f:	mov    %r14,%rsi
  72c952:	call   *0x30(%rax)
  72c955:	add    $0x10,%r15
  72c959:	test   %al,%al
  72c95b:	je     72c940 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x90>
  72c95d:	mov    -0x10(%rbp,%r15,1),%rsi
  72c962:	mov    -0x8(%rbp,%r15,1),%rax
  72c967:	lea    0x10(%rsp),%rdi
  72c96c:	mov    %r12,%rdx
  72c96f:	mov    %r14,%rcx
  72c972:	call   *0x58(%rax)
  72c975:	mov    0x10(%rsp),%rcx
  72c97a:	mov    0x18(%rsp),%rdi
  72c97f:	mov    0x20(%rsp),%rax
  72c984:	cmp    $0xffffffffffffffff,%rcx
  72c988:	jne    72c9c4 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x114>
  72c98a:	lea    0x34e9ff(%rip),%rdx        # a7b390 <anon.dff37607ed4abf3f332318fda1fd6b2c.5.llvm.11034051715724540866>
  72c991:	mov    0x8(%rsp),%r15
  72c996:	mov    %r15,%rsi
  72c999:	call   *0x20(%rax)
  72c99c:	test   %al,%al
  72c99e:	je     72c9c9 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x119>
  72c9a0:	mov    0x4(%r15),%eax
  72c9a4:	movq   $0x0,0x8(%rbx)
  72c9ac:	mov    %r15,0x10(%rbx)
  72c9b0:	mov    %eax,0x18(%rbx)
  72c9b3:	movq   $0xfffffffffffffffe,(%rbx)
  72c9ba:	jmp    72c9e1 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x131>
  72c9bc:	mov    $0xb,%ecx
  72c9c1:	mov    %r14,%rdi
  72c9c4:	mov    %rdi,%r14
  72c9c7:	jmp    72c9ce <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x11e>
  72c9c9:	mov    $0xa,%ecx
  72c9ce:	movq   $0x20,(%rbx)
  72c9d5:	mov    %rcx,0x8(%rbx)
  72c9d9:	mov    %r14,0x10(%rbx)
  72c9dd:	mov    %rax,0x18(%rbx)
  72c9e1:	mov    %rbx,%rax
  72c9e4:	add    $0x28,%rsp
  72c9e8:	pop    %rbx
  72c9e9:	pop    %r12
  72c9eb:	pop    %r13
  72c9ed:	pop    %r14
  72c9ef:	pop    %r15
  72c9f1:	pop    %rbp
  72c9f2:	ret


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072d2c0 <<gpui::source::Sources<owner_source_control::Model>>::resolve>:
  72d2c0:	push   %rbp
  72d2c1:	push   %r15
  72d2c3:	push   %r14
  72d2c5:	push   %r13
  72d2c7:	push   %r12
  72d2c9:	push   %rbx
  72d2ca:	sub    $0x58,%rsp
  72d2ce:	mov    %rdx,%r9
  72d2d1:	mov    (%rsi),%rax
  72d2d4:	cmp    $0xffffffffffffffff,%rax
  72d2d8:	lea    0x28(%rsp),%rdx
  72d2dd:	cmovne %rsi,%rdx
  72d2e1:	movups 0x8(%rdx),%xmm0
  72d2e5:	movaps %xmm0,0x40(%rsp)
  72d2ea:	je     72d2fd <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x3d>
  72d2ec:	movaps 0x40(%rsp),%xmm0
  72d2f1:	movups %xmm0,0x8(%rdi)
  72d2f5:	mov    %rax,(%rdi)
  72d2f8:	jmp    72d43e <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  72d2fd:	mov    %rcx,0x18(%rsp)
  72d302:	mov    %r8,%r12
  72d305:	mov    %rdi,0x8(%rsp)
  72d30a:	mov    0x28(%rsi),%rbx
  72d30e:	test   %rbx,%rbx
  72d311:	mov    %r9,0x10(%rsp)
  72d316:	mov    %rsi,0x20(%rsp)
  72d31b:	je     72d379 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xb9>
  72d31d:	mov    0x20(%rsi),%r14
  72d321:	shl    $0x4,%rbx
  72d325:	add    %r14,%rbx
  72d328:	xor    %ebp,%ebp
  72d32a:	jmp    72d33e <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x7e>
  72d32c:	nopl   0x0(%rax)
  72d330:	add    $0x10,%r14
  72d334:	cmp    %rbx,%r14
  72d337:	mov    0x10(%rsp),%r9
  72d33c:	je     72d37b <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xbb>
  72d33e:	mov    (%r14),%r13
  72d341:	mov    0x8(%r14),%r15
  72d345:	mov    %r13,%rdi
  72d348:	mov    %r9,%rsi
  72d34b:	call   *0x28(%r15)
  72d34f:	mov    %rdx,%rcx
  72d352:	mov    %rax,%rdi
  72d355:	mov    0x18(%rsp),%rsi
  72d35a:	mov    %r12,%rdx
  72d35d:	call   *0x20(%rcx)
  72d360:	test   %al,%al
  72d362:	je     72d330 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x70>
  72d364:	mov    %r13,%rdi
  72d367:	call   *0x18(%r15)
  72d36b:	test   %rbp,%rbp
  72d36e:	jne    72d42a <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x16a>
  72d374:	mov    %rax,%rbp
  72d377:	jmp    72d330 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x70>
  72d379:	xor    %ebp,%ebp
  72d37b:	mov    0x20(%rsp),%rax
  72d380:	mov    0x58(%rax),%rbx
  72d384:	test   %rbx,%rbx
  72d387:	je     72d418 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  72d38d:	mov    0x50(%rax),%r14
  72d391:	shl    $0x4,%rbx
  72d395:	add    %r14,%rbx
  72d398:	lea    0x28(%rsp),%r13
  72d39d:	mov    0x18(%rsp),%r15
  72d3a2:	jmp    72d3db <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x11b>
  72d3a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  72d3b0:	mov    0x10(%rsp),%r9
  72d3b5:	add    $0x10,%r14
  72d3b9:	cmp    %rbx,%r14
  72d3bc:	jne    72d3db <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x11b>
  72d3be:	jmp    72d418 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  72d3c0:	test   %rax,%rax
  72d3c3:	je     72d3b0 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xf0>
  72d3c5:	test   %rbp,%rbp
  72d3c8:	mov    0x10(%rsp),%r9
  72d3cd:	jne    72d42a <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x16a>
  72d3cf:	mov    %rax,%rbp
  72d3d2:	add    $0x10,%r14
  72d3d6:	cmp    %rbx,%r14
  72d3d9:	je     72d418 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  72d3db:	mov    (%r14),%rsi
  72d3de:	mov    0x8(%r14),%rax
  72d3e2:	mov    %r13,%rdi
  72d3e5:	mov    %r9,%rdx
  72d3e8:	mov    %r15,%rcx
  72d3eb:	mov    %r12,%r8
  72d3ee:	call   *0x50(%rax)
  72d3f1:	mov    0x28(%rsp),%rcx
  72d3f6:	mov    0x30(%rsp),%rax
  72d3fb:	cmp    $0xffffffffffffffff,%rcx
  72d3ff:	je     72d3c0 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x100>
  72d401:	mov    0x38(%rsp),%rdx
  72d406:	mov    0x8(%rsp),%rdi
  72d40b:	mov    %rcx,(%rdi)
  72d40e:	mov    %rax,0x8(%rdi)
  72d412:	mov    %rdx,0x10(%rdi)
  72d416:	jmp    72d43e <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  72d418:	mov    0x8(%rsp),%rdi
  72d41d:	mov    %rbp,0x8(%rdi)
  72d421:	movq   $0xffffffffffffffff,(%rdi)
  72d428:	jmp    72d43e <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  72d42a:	mov    0x8(%rsp),%rdi
  72d42f:	movq   $0x9,(%rdi)
  72d436:	mov    %rbp,0x8(%rdi)
  72d43a:	mov    %rax,0x10(%rdi)
  72d43e:	mov    %rdi,%rax
  72d441:	add    $0x58,%rsp
  72d445:	pop    %rbx
  72d446:	pop    %r12
  72d448:	pop    %r13
  72d44a:	pop    %r14
  72d44c:	pop    %r15
  72d44e:	pop    %rbp
  72d44f:	ret


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072dd80 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit>:
  72dd80:	push   %rbp
  72dd81:	push   %r15
  72dd83:	push   %r14
  72dd85:	push   %r13
  72dd87:	push   %r12
  72dd89:	push   %rbx
  72dd8a:	sub    $0x28,%rsp
  72dd8e:	mov    %r9,%r12
  72dd91:	mov    %r8,%r13
  72dd94:	mov    %rdx,%r15
  72dd97:	mov    %rsi,%r14
  72dd9a:	mov    %rdi,%rbx
  72dd9d:	mov    %rsp,%rdi
  72dda0:	mov    %rdx,%rsi
  72dda3:	call   *0x18(%rcx)
  72dda6:	movdqa (%rsp),%xmm0
  72ddab:	pcmpeqb -0x6d5d93(%rip),%xmm0        # 58020 <anon.079f5e587c394fcac2765eb4d0cf0bc2.360.llvm.6319143315422321905+0x5c>
  72ddb3:	pmovmskb %xmm0,%eax
  72ddb7:	cmp    $0xffff,%eax
  72ddbc:	jne    72de47 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xc7>
  72ddc2:	mov    %rsp,%rdi
  72ddc5:	mov    %r13,%rsi
  72ddc8:	call   *0x18(%r12)
  72ddcd:	movdqa (%rsp),%xmm0
  72ddd2:	pcmpeqb -0x6d511a(%rip),%xmm0        # 58cc0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0xa80>
  72ddda:	pmovmskb %xmm0,%eax
  72ddde:	cmp    $0xffff,%eax
  72dde3:	jne    72de47 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xc7>
  72dde5:	mov    %r15,%rdi
  72dde8:	call   *0x18(%r14)
  72ddec:	mov    %rax,0x20(%rsp)
  72ddf1:	mov    (%r14),%r14
  72ddf4:	cmp    $0x1,%r14d
  72ddf8:	jne    72de53 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xd3>
  72ddfa:	mov    0x20(%r13),%rbp
  72ddfe:	mov    0x28(%r13),%r12
  72de02:	shl    $0x4,%r12
  72de06:	xor    %r13d,%r13d
  72de09:	nopl   0x0(%rax)
  72de10:	cmp    %r13,%r12
  72de13:	je     72dedd <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x15d>
  72de19:	mov    0x0(%rbp,%r13,1),%rdi
  72de1e:	mov    0x8(%rbp,%r13,1),%rax
  72de23:	call   *0x18(%rax)
  72de26:	add    $0x10,%r13
  72de2a:	cmp    %r14,%rax
  72de2d:	jne    72de10 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x90>
  72de2f:	mov    -0x10(%rbp,%r13,1),%rdi
  72de34:	mov    -0x8(%rbp,%r13,1),%rax
  72de39:	mov    %r15,%rsi
  72de3c:	call   *0x28(%rax)
  72de3f:	mov    %rax,%rdi
  72de42:	mov    %rdx,%rax
  72de45:	jmp    72deb7 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x137>
  72de47:	movq   $0x1,(%rbx)
  72de4e:	jmp    72defa <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x17a>
  72de53:	mov    0x50(%r13),%rbp
  72de57:	mov    0x58(%r13),%r13
  72de5b:	shl    $0x4,%r13
  72de5f:	xor    %r12d,%r12d
  72de62:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  72de70:	cmp    %r12,%r13
  72de73:	je     72dedd <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x15d>
  72de75:	mov    0x0(%rbp,%r12,1),%rdi
  72de7a:	mov    0x8(%rbp,%r12,1),%rax
  72de7f:	mov    %r14,%rsi
  72de82:	call   *0x30(%rax)
  72de85:	add    $0x10,%r12
  72de89:	test   %al,%al
  72de8b:	je     72de70 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xf0>
  72de8d:	mov    -0x10(%rbp,%r12,1),%rsi
  72de92:	mov    -0x8(%rbp,%r12,1),%rax
  72de97:	mov    %rsp,%rdi
  72de9a:	mov    %r15,%rdx
  72de9d:	mov    %r14,%rcx
  72dea0:	call   *0x58(%rax)
  72dea3:	mov    (%rsp),%rcx
  72dea7:	mov    0x8(%rsp),%rdi
  72deac:	mov    0x10(%rsp),%rax
  72deb1:	cmp    $0xffffffffffffffff,%rcx
  72deb5:	jne    72dee5 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x165>
  72deb7:	lea    0x34d4d2(%rip),%rdx        # a7b390 <anon.dff37607ed4abf3f332318fda1fd6b2c.5.llvm.11034051715724540866>
  72debe:	mov    0x20(%rsp),%rsi
  72dec3:	call   *0x20(%rax)
  72dec6:	test   %al,%al
  72dec8:	je     72deea <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x16a>
  72deca:	movw   $0x0,0x8(%rbx)
  72ded0:	mov    %r14,0x10(%rbx)
  72ded4:	movq   $0xffffffffffffffff,(%rbx)
  72dedb:	jmp    72defa <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x17a>
  72dedd:	mov    $0xb,%ecx
  72dee2:	mov    %r14,%rdi
  72dee5:	mov    %rdi,%r14
  72dee8:	jmp    72deef <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x16f>
  72deea:	mov    $0xa,%ecx
  72deef:	mov    %rcx,(%rbx)
  72def2:	mov    %r14,0x8(%rbx)
  72def6:	mov    %rax,0x10(%rbx)
  72defa:	mov    %rbx,%rax
  72defd:	add    $0x28,%rsp
  72df01:	pop    %rbx
  72df02:	pop    %r12
  72df04:	pop    %r13
  72df06:	pop    %r14
  72df08:	pop    %r15
  72df0a:	pop    %rbp
  72df0b:	ret


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072df10 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke>:
  72df10:	push   %r15
  72df12:	push   %r14
  72df14:	push   %r12
  72df16:	push   %rbx
  72df17:	sub    $0x18,%rsp
  72df1b:	mov    %rdx,%r15
  72df1e:	mov    %rsi,%r14
  72df21:	mov    %rdi,%rbx
  72df24:	mov    %rsp,%rdi
  72df27:	mov    %rdx,%rsi
  72df2a:	call   *0x18(%rcx)
  72df2d:	movdqa (%rsp),%xmm0
  72df32:	pcmpeqb -0x6d5f1a(%rip),%xmm0        # 58020 <anon.079f5e587c394fcac2765eb4d0cf0bc2.360.llvm.6319143315422321905+0x5c>
  72df3a:	pmovmskb %xmm0,%ecx
  72df3e:	mov    $0x1,%eax
  72df43:	cmp    $0xffff,%ecx
  72df49:	jne    72df85 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x75>
  72df4b:	mov    %r15,%rdi
  72df4e:	call   *0x18(%r14)
  72df52:	mov    %rax,%r12
  72df55:	mov    %r15,%rdi
  72df58:	call   *0x20(%r14)
  72df5c:	cmp    %rax,%r12
  72df5f:	je     72df6f <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x5f>
  72df61:	mov    (%r14),%rax
  72df64:	mov    %rax,0x8(%rbx)
  72df68:	mov    $0xa,%eax
  72df6d:	jmp    72df85 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x75>
  72df6f:	mov    0x4(%rax),%ecx
  72df72:	cmp    $0xffffffff,%ecx
  72df75:	je     72df97 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x87>
  72df77:	inc    %ecx
  72df79:	mov    %ecx,0x4(%rax)
  72df7c:	incl   (%rax)
  72df7e:	mov    $0xffffffffffffffff,%rax
  72df85:	mov    %rax,(%rbx)
  72df88:	mov    %rbx,%rax
  72df8b:	add    $0x18,%rsp
  72df8f:	pop    %rbx
  72df90:	pop    %r12
  72df92:	pop    %r14
  72df94:	pop    %r15
  72df96:	ret
  72df97:	lea    -0x6d05c7(%rip),%rdi        # 5d9d7 <anon.d6806d9f56049ce1dff51ddf23659ee5.67.llvm.11139854418402343214>
  72df9e:	lea    0x34db8b(%rip),%rdx        # a7bb30 <anon.d6806d9f56049ce1dff51ddf23659ee5.69.llvm.11139854418402343214>
  72dfa5:	mov    $0x19,%esi
  72dfaa:	call   *0x375560(%rip)        # aa3510 <_DYNAMIC+0x2b0>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000732300 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  732300:	push   %rbx
  732301:	sub    $0x40,%rsp
  732305:	mov    0x130(%rdi),%rbx
  73230c:	test   %rbx,%rbx
  73230f:	je     7323b6 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xb6>
  732315:	cmpb   $0x0,0x756(%rbx)
  73231c:	jne    7323bd <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xbd>
  732322:	mov    $0x12,%eax
  732327:	cmpb   $0x1,0x752(%rbx)
  73232e:	jne    7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  732334:	cmpb   $0x0,0x753(%rbx)
  73233b:	jne    7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  732341:	cmpb   $0x0,0x754(%rbx)
  732348:	je     7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  73234a:	cmpq   $0xffffffffffffffff,0x5c0(%rbx)
  732352:	jne    7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  732354:	mov    0x698(%rbx),%rcx
  73235b:	cmp    0x6a0(%rbx),%rcx
  732362:	jne    7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  732364:	mov    0x6b0(%rbx),%rcx
  73236b:	cmp    0x6a8(%rbx),%rcx
  732372:	jne    7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  732374:	movss  0x748(%rbx),%xmm2
  73237c:	ucomiss 0x74c(%rbx),%xmm2
  732383:	jne    7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  732385:	jp     7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  732387:	mov    %rbx,%rdi
  73238a:	call   709f70 <<gpui::runtime::Runtime<owner_source_control::Model>>::hit>
  73238f:	cmp    $0x1,%rax
  732393:	jne    7323ae <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xae>
  732395:	add    $0x5e8,%rbx
  73239c:	mov    %rbx,%rdi
  73239f:	mov    %rdx,%rsi
  7323a2:	call   *0x371260(%rip)        # aa3608 <_DYNAMIC+0x3a8>
  7323a8:	add    $0x40,%rsp
  7323ac:	pop    %rbx
  7323ad:	ret
  7323ae:	xor    %eax,%eax
  7323b0:	add    $0x40,%rsp
  7323b4:	pop    %rbx
  7323b5:	ret
  7323b6:	mov    $0xd,%eax
  7323bb:	jmp    7323c2 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  7323bd:	mov    $0xe,%eax
  7323c2:	mov    %rax,0x8(%rsp)
  7323c7:	lea    -0x6d4a7e(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  7323ce:	lea    0x3495db(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  7323d5:	lea    0x349384(%rip),%r8        # a7b760 <anon.45c7c8279c913538b3a5e338378ef377.14.llvm.9004922692348905182+0xc8>
  7323dc:	lea    0x8(%rsp),%rdx
  7323e1:	mov    $0x2b,%esi
  7323e6:	call   *0x37120c(%rip)        # aa35f8 <_DYNAMIC+0x398>
  7323ec:	ud2
  7323ee:	mov    %rax,%rbx
  7323f1:	lea    0x8(%rsp),%rdi
  7323f6:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7323fb:	mov    %rbx,%rdi
  7323fe:	call   a78330 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000732410 <owner_source_control::source_set::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  732410:	push   %rbx
  732411:	sub    $0xd0,%rsp
  732418:	mov    %esi,%ecx
  73241a:	mov    %rdi,%rsi
  73241d:	mov    0x349374(%rip),%rax        # a7b798 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x20>
  732424:	mov    %rax,0x20(%rsp)
  732429:	movups 0x349358(%rip),%xmm0        # a7b788 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x10>
  732430:	movaps %xmm0,0x10(%rsp)
  732435:	movups 0x34933c(%rip),%xmm0        # a7b778 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214>
  73243c:	movaps %xmm0,(%rsp)
  732440:	lea    0x68(%rsp),%rdi
  732445:	mov    %rsp,%rdx
  732448:	call   6e8d10 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32>>
  73244d:	cmpl   $0xffffffff,0x68(%rsp)
  732452:	jne    73245d <owner_source_control::source_set::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x4d>
  732454:	add    $0xd0,%rsp
  73245b:	pop    %rbx
  73245c:	ret
  73245d:	mov    0xc8(%rsp),%rax
  732465:	mov    %rax,0x60(%rsp)
  73246a:	movups 0xb8(%rsp),%xmm0
  732472:	movaps %xmm0,0x50(%rsp)
  732477:	movups 0xa8(%rsp),%xmm0
  73247f:	movaps %xmm0,0x40(%rsp)
  732484:	movups 0x68(%rsp),%xmm0
  732489:	movups 0x78(%rsp),%xmm1
  73248e:	movups 0x88(%rsp),%xmm2
  732496:	movups 0x98(%rsp),%xmm3
  73249e:	movaps %xmm3,0x30(%rsp)
  7324a3:	movaps %xmm2,0x20(%rsp)
  7324a8:	movaps %xmm1,0x10(%rsp)
  7324ad:	movaps %xmm0,(%rsp)
  7324b1:	lea    -0x6d4b68(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  7324b8:	lea    0x349531(%rip),%rcx        # a7b9f0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x278>
  7324bf:	lea    0x3492da(%rip),%r8        # a7b7a0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x28>
  7324c6:	mov    %rsp,%rdx
  7324c9:	mov    $0x2b,%esi
  7324ce:	call   *0x371124(%rip)        # aa35f8 <_DYNAMIC+0x398>
  7324d4:	ud2
  7324d6:	mov    %rax,%rbx
  7324d9:	cmpq   $0x2,(%rsp)
  7324de:	lea    0x30(%rsp),%rax
  7324e3:	lea    0x8(%rsp),%rdi
  7324e8:	cmovb  %rax,%rdi
  7324ec:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7324f1:	mov    %rbx,%rdi
  7324f4:	call   a78330 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000732500 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  732500:	push   %rbx
  732501:	sub    $0x40,%rsp
  732505:	mov    0x130(%rsi),%rsi
  73250c:	test   %rsi,%rsi
  73250f:	je     732575 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x75>
  732511:	cmpb   $0x0,0x756(%rsi)
  732518:	jne    73257c <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x7c>
  73251a:	cmpb   $0x1,0x754(%rsi)
  732521:	jne    732583 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x83>
  732523:	mov    $0x11,%eax
  732528:	cmp    0x5e8(%rsi),%rdx
  73252f:	jne    732588 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  732531:	mov    0x5b0(%rsi),%rdx
  732538:	mov    0x5b8(%rsi),%rsi
  73253f:	shl    $0x6,%rsi
  732543:	xor    %r8d,%r8d
  732546:	mov    %rdx,%r9
  732549:	nopl   0x0(%rax)
  732550:	cmp    %r8,%rsi
  732553:	je     732588 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  732555:	add    $0x40,%r8
  732559:	cmp    %rcx,0x20(%r9)
  73255d:	lea    0x40(%r9),%r9
  732561:	jne    732550 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x50>
  732563:	movups -0x30(%rdx,%r8,1),%xmm0
  732569:	movups %xmm0,(%rdi)
  73256c:	mov    %rdi,%rax
  73256f:	add    $0x40,%rsp
  732573:	pop    %rbx
  732574:	ret
  732575:	mov    $0xd,%eax
  73257a:	jmp    732588 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  73257c:	mov    $0xe,%eax
  732581:	jmp    732588 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  732583:	mov    $0x12,%eax
  732588:	mov    %rax,0x8(%rsp)
  73258d:	lea    -0x6d4c44(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  732594:	lea    0x349415(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  73259b:	lea    0x349216(%rip),%r8        # a7b7b8 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x40>
  7325a2:	lea    0x8(%rsp),%rdx
  7325a7:	mov    $0x2b,%esi
  7325ac:	call   *0x371046(%rip)        # aa35f8 <_DYNAMIC+0x398>
  7325b2:	ud2
  7325b4:	mov    %rax,%rbx
  7325b7:	lea    0x8(%rsp),%rdi
  7325bc:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7325c1:	mov    %rbx,%rdi
  7325c4:	call   a78330 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000007325d0 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  7325d0:	push   %r15
  7325d2:	push   %r14
  7325d4:	push   %rbx
  7325d5:	sub    $0x70,%rsp
  7325d9:	mov    %rdi,%rbx
  7325dc:	mov    0x130(%rdi),%r15
  7325e3:	test   %r15,%r15
  7325e6:	je     732632 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x62>
  7325e8:	mov    %rdx,%rcx
  7325eb:	mov    %rsi,%rdx
  7325ee:	mov    %r15,(%rsp)
  7325f2:	mov    %rbx,0x8(%rsp)
  7325f7:	lea    0x38(%rsp),%rdi
  7325fc:	mov    %rsp,%rsi
  7325ff:	call   6f3050 <<gpui::runtime::RuntimeMut<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::activate>
  732604:	cmpb   $0x0,0x756(%r15)
  73260c:	jne    732618 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x48>
  73260e:	cmpq   $0xffffffffffffffff,0x698(%r15)
  732616:	jne    732620 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x50>
  732618:	mov    %rbx,%rdi
  73261b:	call   72b2c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  732620:	cmpq   $0xfffffffffffffffe,0x38(%rsp)
  732626:	jne    732649 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x79>
  732628:	add    $0x70,%rsp
  73262c:	pop    %rbx
  73262d:	pop    %r14
  73262f:	pop    %r15
  732631:	ret
  732632:	movq   $0xd,0x38(%rsp)
  73263b:	movq   $0x0,0x40(%rsp)
  732644:	mov    %rbx,0x48(%rsp)
  732649:	mov    0x68(%rsp),%rax
  73264e:	mov    %rax,0x30(%rsp)
  732653:	mov    0x38(%rsp),%rax
  732658:	mov    0x40(%rsp),%rcx
  73265d:	mov    0x48(%rsp),%rdx
  732662:	mov    0x50(%rsp),%rsi
  732667:	movups 0x58(%rsp),%xmm0
  73266c:	movaps %xmm0,0x20(%rsp)
  732671:	mov    %rdx,0x10(%rsp)
  732676:	mov    %rsi,0x18(%rsp)
  73267b:	mov    %rax,(%rsp)
  73267f:	mov    %rcx,0x8(%rsp)
  732684:	lea    -0x6d4d3b(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  73268b:	lea    0x34931e(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  732692:	lea    0x349137(%rip),%r8        # a7b7d0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x58>
  732699:	mov    %rsp,%rdx
  73269c:	mov    $0x2b,%esi
  7326a1:	call   *0x370f51(%rip)        # aa35f8 <_DYNAMIC+0x398>
  7326a7:	ud2
  7326a9:	mov    %rax,%r14
  7326ac:	cmpb   $0x0,0x756(%r15)
  7326b4:	jne    7326c0 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xf0>
  7326b6:	cmpq   $0xffffffffffffffff,0x698(%r15)
  7326be:	jne    7326c8 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xf8>
  7326c0:	mov    %rbx,%rdi
  7326c3:	call   72b2c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  7326c8:	mov    %r14,%rdi
  7326cb:	call   a78330 <_Unwind_Resume@plt>
  7326d0:	call   *0x370e22(%rip)        # aa34f8 <_DYNAMIC+0x298>
  7326d6:	mov    %rax,%r14
  7326d9:	mov    %rsp,%rdi
  7326dc:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7326e1:	mov    %r14,%rdi
  7326e4:	call   a78330 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000007326f0 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  7326f0:	push   %r14
  7326f2:	push   %rbx
  7326f3:	sub    $0x98,%rsp
  7326fa:	mov    %rdi,%rbx
  7326fd:	mov    $0xffffffff,%eax
  732702:	mov    %rax,0x78(%rsp)
  732707:	movq   $0x0,0x80(%rsp)
  732713:	movss  %xmm0,0x4(%rsp)
  732719:	movss  %xmm1,0x8(%rsp)
  73271f:	movl   $0x0,(%rsp)
  732726:	lea    0x40(%rsp),%rdi
  73272b:	lea    0x78(%rsp),%rdx
  732730:	mov    %rsp,%rcx
  732733:	mov    %rbx,%rsi
  732736:	call   6f5130 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  73273b:	cmpl   $0xfffffffe,0x40(%rsp)
  732740:	jne    73279b <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xab>
  732742:	movl   $0x2,(%rsp)
  732749:	lea    0x40(%rsp),%rdi
  73274e:	lea    0x78(%rsp),%rdx
  732753:	mov    %rsp,%rcx
  732756:	mov    %rbx,%rsi
  732759:	call   6f5130 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  73275e:	cmpl   $0xfffffffe,0x40(%rsp)
  732763:	jne    7327ed <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xfd>
  732769:	movl   $0x3,(%rsp)
  732770:	lea    0x40(%rsp),%rdi
  732775:	lea    0x78(%rsp),%rdx
  73277a:	mov    %rsp,%rcx
  73277d:	mov    %rbx,%rsi
  732780:	call   6f5130 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  732785:	cmpl   $0xfffffffe,0x40(%rsp)
  73278a:	jne    73283c <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x14c>
  732790:	add    $0x98,%rsp
  732797:	pop    %rbx
  732798:	pop    %r14
  73279a:	ret
  73279b:	mov    0x70(%rsp),%rax
  7327a0:	mov    %rax,0x30(%rsp)
  7327a5:	movups 0x40(%rsp),%xmm0
  7327aa:	movups 0x50(%rsp),%xmm1
  7327af:	movups 0x60(%rsp),%xmm2
  7327b4:	movaps %xmm2,0x20(%rsp)
  7327b9:	movaps %xmm1,0x10(%rsp)
  7327be:	movaps %xmm0,(%rsp)
  7327c2:	lea    -0x6d4e79(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  7327c9:	lea    0x3491e0(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  7327d0:	lea    0x349011(%rip),%r8        # a7b7e8 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x70>
  7327d7:	mov    %rsp,%rbx
  7327da:	mov    $0x2b,%esi
  7327df:	mov    %rbx,%rdx
  7327e2:	call   *0x370e10(%rip)        # aa35f8 <_DYNAMIC+0x398>
  7327e8:	jmp    732889 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x199>
  7327ed:	mov    0x70(%rsp),%rax
  7327f2:	mov    %rax,0x30(%rsp)
  7327f7:	movups 0x40(%rsp),%xmm0
  7327fc:	movups 0x50(%rsp),%xmm1
  732801:	movups 0x60(%rsp),%xmm2
  732806:	movaps %xmm2,0x20(%rsp)
  73280b:	movaps %xmm1,0x10(%rsp)
  732810:	movaps %xmm0,(%rsp)
  732814:	lea    -0x6d4ecb(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  73281b:	lea    0x34918e(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  732822:	lea    0x348fd7(%rip),%r8        # a7b800 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x88>
  732829:	mov    %rsp,%rbx
  73282c:	mov    $0x2b,%esi
  732831:	mov    %rbx,%rdx
  732834:	call   *0x370dbe(%rip)        # aa35f8 <_DYNAMIC+0x398>
  73283a:	jmp    732889 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x199>
  73283c:	mov    0x70(%rsp),%rax
  732841:	mov    %rax,0x30(%rsp)
  732846:	movups 0x40(%rsp),%xmm0
  73284b:	movups 0x50(%rsp),%xmm1
  732850:	movups 0x60(%rsp),%xmm2
  732855:	movaps %xmm2,0x20(%rsp)
  73285a:	movaps %xmm1,0x10(%rsp)
  73285f:	movaps %xmm0,(%rsp)
  732863:	lea    -0x6d4f1a(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  73286a:	lea    0x34913f(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  732871:	lea    0x348fa0(%rip),%r8        # a7b818 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0xa0>
  732878:	mov    %rsp,%rbx
  73287b:	mov    $0x2b,%esi
  732880:	mov    %rbx,%rdx
  732883:	call   *0x370d6f(%rip)        # aa35f8 <_DYNAMIC+0x398>
  732889:	ud2
  73288b:	jmp    73288f <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x19f>
  73288d:	jmp    73288f <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x19f>
  73288f:	mov    %rax,%r14
  732892:	mov    %rbx,%rdi
  732895:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  73289a:	mov    %r14,%rdi
  73289d:	call   a78330 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000007328b0 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  7328b0:	push   %rbx
  7328b1:	sub    $0x100,%rsp
  7328b8:	mov    %rdi,%rbx
  7328bb:	mov    %rsp,%rdi
  7328be:	mov    $0x8,%edx
  7328c3:	mov    %rbx,%rsi
  7328c6:	call   6f3770 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  7328cb:	cmpl   $0xffffffff,(%rsp)
  7328cf:	jne    7329cc <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  7328d5:	testb  $0x1,0x48(%rsp)
  7328da:	je     7329c3 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  7328e0:	mov    %rsp,%rdi
  7328e3:	mov    $0x8,%edx
  7328e8:	mov    %rbx,%rsi
  7328eb:	call   6f3770 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  7328f0:	cmpl   $0xffffffff,(%rsp)
  7328f4:	jne    7329cc <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  7328fa:	cmpb   $0x1,0x48(%rsp)
  7328ff:	jne    7329c3 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  732905:	mov    %rsp,%rdi
  732908:	mov    $0x8,%edx
  73290d:	mov    %rbx,%rsi
  732910:	call   6f3770 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  732915:	cmpl   $0xffffffff,(%rsp)
  732919:	jne    7329cc <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  73291f:	cmpb   $0x1,0x48(%rsp)
  732924:	jne    7329c3 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  73292a:	mov    %rsp,%rdi
  73292d:	mov    $0x8,%edx
  732932:	mov    %rbx,%rsi
  732935:	call   6f3770 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  73293a:	cmpl   $0xffffffff,(%rsp)
  73293e:	jne    7329cc <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  732944:	cmpb   $0x1,0x48(%rsp)
  732949:	jne    7329c3 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  73294b:	mov    %rsp,%rdi
  73294e:	mov    $0x8,%edx
  732953:	mov    %rbx,%rsi
  732956:	call   6f3770 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  73295b:	cmpl   $0xffffffff,(%rsp)
  73295f:	jne    7329cc <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  732961:	cmpb   $0x1,0x48(%rsp)
  732966:	jne    7329c3 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  732968:	mov    %rsp,%rdi
  73296b:	mov    $0x8,%edx
  732970:	mov    %rbx,%rsi
  732973:	call   6f3770 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  732978:	cmpl   $0xffffffff,(%rsp)
  73297c:	jne    7329cc <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  73297e:	cmpb   $0x1,0x48(%rsp)
  732983:	jne    7329c3 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  732985:	mov    %rsp,%rdi
  732988:	mov    $0x8,%edx
  73298d:	mov    %rbx,%rsi
  732990:	call   6f3770 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  732995:	cmpl   $0xffffffff,(%rsp)
  732999:	jne    7329cc <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  73299b:	cmpb   $0x1,0x48(%rsp)
  7329a0:	jne    7329c3 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  7329a2:	mov    %rsp,%rdi
  7329a5:	mov    $0x8,%edx
  7329aa:	mov    %rbx,%rsi
  7329ad:	call   6f3770 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  7329b2:	cmpl   $0xffffffff,(%rsp)
  7329b6:	jne    7329cc <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  7329b8:	cmpb   $0x1,0x48(%rsp)
  7329bd:	je     732a5d <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x1ad>
  7329c3:	add    $0x100,%rsp
  7329ca:	pop    %rbx
  7329cb:	ret
  7329cc:	movups 0x70(%rsp),%xmm0
  7329d1:	movaps %xmm0,0xf0(%rsp)
  7329d9:	movups 0x60(%rsp),%xmm0
  7329de:	movaps %xmm0,0xe0(%rsp)
  7329e6:	movups 0x50(%rsp),%xmm0
  7329eb:	movaps %xmm0,0xd0(%rsp)
  7329f3:	movups 0x40(%rsp),%xmm0
  7329f8:	movaps %xmm0,0xc0(%rsp)
  732a00:	movups (%rsp),%xmm0
  732a04:	movups 0x10(%rsp),%xmm1
  732a09:	movups 0x20(%rsp),%xmm2
  732a0e:	movups 0x30(%rsp),%xmm3
  732a13:	movaps %xmm3,0xb0(%rsp)
  732a1b:	movaps %xmm2,0xa0(%rsp)
  732a23:	movaps %xmm1,0x90(%rsp)
  732a2b:	movaps %xmm0,0x80(%rsp)
  732a33:	lea    -0x6d50ea(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  732a3a:	lea    0x348f8f(%rip),%rcx        # a7b9d0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x258>
  732a41:	lea    0x348e00(%rip),%r8        # a7b848 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0xd0>
  732a48:	lea    0x80(%rsp),%rdx
  732a50:	mov    $0x2b,%esi
  732a55:	call   *0x370b9d(%rip)        # aa35f8 <_DYNAMIC+0x398>
  732a5b:	ud2
  732a5d:	lea    -0x6d5277(%rip),%rdi        # 5d7ed <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x5>
  732a64:	lea    0x348dc5(%rip),%rdx        # a7b830 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0xb8>
  732a6b:	mov    $0x7b,%esi
  732a70:	call   *0x370a8a(%rip)        # aa3500 <_DYNAMIC+0x2a0>
  732a76:	mov    %rax,%rbx
  732a79:	lea    0xc8(%rsp),%rdi
  732a81:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  732a86:	mov    %rbx,%rdi
  732a89:	call   a78330 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000736940 <owner_source_control::main>:
  736940:	push   %rbp
  736941:	push   %r15
  736943:	push   %r14
  736945:	push   %r13
  736947:	push   %r12
  736949:	push   %rbx
  73694a:	sub    $0x428,%rsp
  736951:	movq   $0x2,0x2d0(%rsp)
  73695d:	lea    0x138(%rsp),%rdi
  736965:	lea    0x2d0(%rsp),%rsi
  73696d:	call   7189e0 <allocation_counter::measure::<owner_source_control::main::{closure#0}>>
  736972:	mov    0x2d0(%rsp),%rbx
  73697a:	cmp    $0x2,%rbx
  73697e:	je     736d86 <owner_source_control::main+0x446>
  736984:	mov    0x408(%rsp),%r14
  73698c:	mov    0x410(%rsp),%r15
  736994:	lea    0x2d8(%rsp),%rsi
  73699c:	mov    0x418(%rsp),%r12
  7369a4:	mov    0x420(%rsp),%r13
  7369ac:	lea    0x1a0(%rsp),%rdi
  7369b4:	mov    $0x130,%edx
  7369b9:	call   *0x36cb11(%rip)        # aa34d0 <memcpy@GLIBC_2.14>
  7369bf:	mov    %rbx,0x198(%rsp)
  7369c7:	mov    %r12,0xd8(%rsp)
  7369cf:	mov    %r13,0xe0(%rsp)
  7369d7:	lea    0x198(%rsp),%rdi
  7369df:	call   7328b0 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>
  7369e4:	lea    -0x6dec3b(%rip),%rcx        # 57db0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.312.llvm.6319143315422321905+0x58>
  7369eb:	lea    0x90(%rsp),%rdi
  7369f3:	lea    0x198(%rsp),%rbx
  7369fb:	mov    $0x4,%r8d
  736a01:	mov    %rbx,%rsi
  736a04:	mov    $0x5,%edx
  736a09:	call   6fbc20 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::find>
  736a0e:	cmpl   $0xfffffffe,0x90(%rsp)
  736a16:	jne    736d93 <owner_source_control::main+0x453>
  736a1c:	movups 0x98(%rsp),%xmm0
  736a24:	movaps %xmm0,0x120(%rsp)
  736a2c:	mov    0x2c8(%rsp),%rax
  736a34:	test   %rax,%rax
  736a37:	je     736ea5 <owner_source_control::main+0x565>
  736a3d:	xorps  %xmm0,%xmm0
  736a40:	movups %xmm0,0x728(%rax)
  736a47:	movups %xmm0,0x718(%rax)
  736a4e:	movups %xmm0,0x708(%rax)
  736a55:	movups %xmm0,0x6f8(%rax)
  736a5c:	movups %xmm0,0x6e8(%rax)
  736a63:	movups %xmm0,0x6d8(%rax)
  736a6a:	movq   $0x0,0x738(%rax)
  736a75:	cmpb   $0x0,0x756(%rax)
  736a7c:	jne    736a88 <owner_source_control::main+0x148>
  736a7e:	cmpq   $0xffffffffffffffff,0x698(%rax)
  736a86:	jne    736a95 <owner_source_control::main+0x155>
  736a88:	lea    0x198(%rsp),%rdi
  736a90:	call   72b2c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  736a95:	lea    0x168(%rsp),%rdi
  736a9d:	lea    0x198(%rsp),%rsi
  736aa5:	lea    0x120(%rsp),%rdx
  736aad:	call   718ca0 <allocation_counter::measure::<owner_source_control::main::{closure#1}>>
  736ab2:	mov    0x2c8(%rsp),%rbx
  736aba:	test   %rbx,%rbx
  736abd:	je     736dee <owner_source_control::main+0x4ae>
  736ac3:	cmpl   $0x2b,0x2c0(%rbx)
  736aca:	jne    736e1e <owner_source_control::main+0x4de>
  736ad0:	movq   $0x0,(%rsp)
  736ad8:	movq   $0x0,0x10(%rsp)
  736ae1:	movq   $0x0,0x20(%rsp)
  736aea:	mov    %rbx,0x30(%rsp)
  736aef:	lea    -0x6d923b(%rip),%rax        # 5d8bb <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0xd3>
  736af6:	mov    %rax,0x38(%rsp)
  736afb:	movq   $0x2,0x40(%rsp)
  736b04:	movb   $0x1,0x48(%rsp)
  736b09:	movb   $0xff,0x50(%rsp)
  736b0e:	lea    0x90(%rsp),%rbp
  736b16:	mov    %rsp,%rsi
  736b19:	mov    %rbp,%rdi
  736b1c:	call   723d30 <<gpui::runtime::query::Query<owner_source_control::Model>>::count>
  736b21:	mov    0x90(%rsp),%rcx
  736b29:	mov    0x98(%rsp),%rax
  736b31:	cmp    $0xfffffffffffffffe,%rcx
  736b35:	jne    736ee3 <owner_source_control::main+0x5a3>
  736b3b:	test   %rax,%rax
  736b3e:	je     736e35 <owner_source_control::main+0x4f5>
  736b44:	mov    0x2c8(%rsp),%rax
  736b4c:	mov    $0x2,%r13b
  736b4f:	test   %rax,%rax
  736b52:	je     736f50 <owner_source_control::main+0x610>
  736b58:	cmpb   $0x0,0x756(%rax)
  736b5f:	jne    736f57 <owner_source_control::main+0x617>
  736b65:	mov    %rsp,%rbx
  736b68:	lea    0x198(%rsp),%r12
  736b70:	mov    %rbx,%rdi
  736b73:	mov    %r12,%rsi
  736b76:	mov    %r14,%rdx
  736b79:	mov    %r15,%rcx
  736b7c:	call   72a5e0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::reader::ReaderValues>::read>
  736b81:	cmpl   $0x2,(%rsp)
  736b85:	je     736f5e <owner_source_control::main+0x61e>
  736b8b:	mov    0x18(%rsp),%rcx
  736b90:	movzbl 0x20(%rsp),%r13d
  736b96:	mov    0x21(%rsp),%rax
  736b9b:	mov    %rax,0xe8(%rsp)
  736ba3:	mov    0x28(%rsp),%rax
  736ba8:	mov    %rax,0xef(%rsp)
  736bb0:	mov    0x30(%rsp),%eax
  736bb4:	movups 0x34(%rsp),%xmm0
  736bb9:	movaps %xmm0,0x90(%rsp)
  736bc1:	movups 0x44(%rsp),%xmm0
  736bc6:	movaps %xmm0,0xa0(%rsp)
  736bce:	movups 0x54(%rsp),%xmm0
  736bd3:	movaps %xmm0,0xb0(%rsp)
  736bdb:	movups 0x61(%rsp),%xmm0
  736be0:	movups %xmm0,0xbd(%rsp)
  736be8:	cmpb   $0x2,0x71(%rsp)
  736bed:	je     736f63 <owner_source_control::main+0x623>
  736bf3:	test   %rcx,%rcx
  736bf6:	je     736e53 <owner_source_control::main+0x513>
  736bfc:	mov    %rcx,0x90(%rsp)
  736c04:	movabs $0x100000001,%rdx
  736c0e:	mov    %rdx,(%rsp)
  736c12:	cmp    %rdx,%rcx
  736c15:	jne    736e65 <owner_source_control::main+0x525>
  736c1b:	mov    %eax,(%rsp)
  736c1e:	cmp    $0x3,%eax
  736c21:	jne    736e85 <owner_source_control::main+0x545>
  736c27:	lea    0x138(%rsp),%rax
  736c2f:	mov    %rax,(%rsp)
  736c33:	lea    0xb06(%rip),%rbx        # 737740 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  736c3a:	mov    %rbx,0x8(%rsp)
  736c3f:	lea    -0x6e770f(%rip),%rdi        # 4f537 <anon.4fc0b732051cd9c0c5e7a6e9d819518c.14.llvm.5251204661969696906+0xdd>
  736c46:	mov    %rsp,%rsi
  736c49:	call   *0x36cff1(%rip)        # aa3c40 <_DYNAMIC+0x9e0>
  736c4f:	lea    0x168(%rsp),%rax
  736c57:	mov    %rax,(%rsp)
  736c5b:	mov    %rbx,0x8(%rsp)
  736c60:	lea    -0x6e17a4(%rip),%rdi        # 554c3 <anon.96bf6b34351ddc2adfd2386f8abf053b.13.llvm.9730795237915355246+0x1ec>
  736c67:	mov    %rsp,%rsi
  736c6a:	call   *0x36cfd0(%rip)        # aa3c40 <_DYNAMIC+0x9e0>
  736c70:	movq   $0x138,0x90(%rsp)
  736c7c:	lea    0xd8(%rsp),%rax
  736c84:	mov    %rax,(%rsp)
  736c88:	mov    0x36cde9(%rip),%rax        # aa3a78 <_DYNAMIC+0x818>
  736c8f:	mov    %rax,0x8(%rsp)
  736c94:	lea    0xe0(%rsp),%rcx
  736c9c:	mov    %rcx,0x10(%rsp)
  736ca1:	mov    %rax,0x18(%rsp)
  736ca6:	mov    %rbp,0x20(%rsp)
  736cab:	mov    %rax,0x28(%rsp)
  736cb0:	lea    -0x6e5870(%rip),%rdi        # 51447 <anon.7d84123d9385acd73700c435ae62cea9.21.llvm.12732996019173906566+0x92>
  736cb7:	mov    %rsp,%rbx
  736cba:	mov    %rbx,%rsi
  736cbd:	call   *0x36cf7d(%rip)        # aa3c40 <_DYNAMIC+0x9e0>
  736cc3:	mov    0x2c8(%rsp),%rax
  736ccb:	test   %rax,%rax
  736cce:	je     736fc9 <owner_source_control::main+0x689>
  736cd4:	mov    0x738(%rax),%rcx
  736cdb:	mov    %rcx,0x60(%rsp)
  736ce0:	movups 0x728(%rax),%xmm0
  736ce7:	movaps %xmm0,0x50(%rsp)
  736cec:	movups 0x718(%rax),%xmm0
  736cf3:	movaps %xmm0,0x40(%rsp)
  736cf8:	movups 0x6d8(%rax),%xmm0
  736cff:	movups 0x6e8(%rax),%xmm1
  736d06:	movups 0x6f8(%rax),%xmm2
  736d0d:	movups 0x708(%rax),%xmm3
  736d14:	movaps %xmm3,0x30(%rsp)
  736d19:	movaps %xmm2,0x20(%rsp)
  736d1e:	movaps %xmm1,0x10(%rsp)
  736d23:	movaps %xmm0,(%rsp)
  736d27:	mov    %rbx,0x90(%rsp)
  736d2f:	lea    0xfaa(%rip),%rax        # 737ce0 <<gpui::runtime::Counters as core::fmt::Debug>::fmt>
  736d36:	mov    %rax,0x98(%rsp)
  736d3e:	lea    -0x6e77f0(%rip),%rdi        # 4f555 <anon.4fc0b732051cd9c0c5e7a6e9d819518c.14.llvm.5251204661969696906+0xfb>
  736d45:	lea    0x90(%rsp),%rsi
  736d4d:	call   *0x36ceed(%rip)        # aa3c40 <_DYNAMIC+0x9e0>
  736d53:	lea    -0x6d9445(%rip),%rdi        # 5d915 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x12d>
  736d5a:	mov    $0x77,%esi
  736d5f:	call   *0x36cedb(%rip)        # aa3c40 <_DYNAMIC+0x9e0>
  736d65:	mov    %r12,(%rsp)
  736d69:	mov    %rsp,%rax
  736d6c:	mov    %r12,%rdi
  736d6f:	call   735010 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  736d74:	add    $0x428,%rsp
  736d7b:	pop    %rbx
  736d7c:	pop    %r12
  736d7e:	pop    %r13
  736d80:	pop    %r14
  736d82:	pop    %r15
  736d84:	pop    %rbp
  736d85:	ret
  736d86:	lea    0x344ad3(%rip),%rdi        # a7b860 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0xe8>
  736d8d:	call   *0x36c755(%rip)        # aa34e8 <_DYNAMIC+0x288>
  736d93:	mov    0xc0(%rsp),%rax
  736d9b:	mov    %rax,0x30(%rsp)
  736da0:	movups 0x90(%rsp),%xmm0
  736da8:	movups 0xa0(%rsp),%xmm1
  736db0:	movups 0xb0(%rsp),%xmm2
  736db8:	movaps %xmm2,0x20(%rsp)
  736dbd:	movaps %xmm1,0x10(%rsp)
  736dc2:	movaps %xmm0,(%rsp)
  736dc6:	lea    -0x6d953d(%rip),%rdi        # 5d890 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0xa8>
  736dcd:	lea    0x344bdc(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  736dd4:	lea    0x344a9d(%rip),%r8        # a7b878 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x100>
  736ddb:	mov    %rsp,%rdx
  736dde:	mov    $0x2b,%esi
  736de3:	call   *0x36c80f(%rip)        # aa35f8 <_DYNAMIC+0x398>
  736de9:	jmp    736ffd <owner_source_control::main+0x6bd>
  736dee:	movq   $0xd,(%rsp)
  736df6:	lea    -0x6d94ad(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  736dfd:	lea    0x344bac(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  736e04:	lea    0x344a9d(%rip),%r8        # a7b8a8 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x130>
  736e0b:	mov    %rsp,%rdx
  736e0e:	mov    $0x2b,%esi
  736e13:	call   *0x36c7df(%rip)        # aa35f8 <_DYNAMIC+0x398>
  736e19:	jmp    736ffd <owner_source_control::main+0x6bd>
  736e1e:	add    $0x2c0,%rbx
  736e25:	lea    0x344b3c(%rip),%r9        # a7b968 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x1f0>
  736e2c:	lea    -0x6def3f(%rip),%rdx        # 57ef4 <anon.b9a0c2ab0f2817fcb40a4a41c6d097bf.12.llvm.1156352485375507320+0x40>
  736e33:	jmp    736e93 <owner_source_control::main+0x553>
  736e35:	lea    -0x6d957f(%rip),%rdi        # 5d8bd <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0xd5>
  736e3c:	lea    0x344a95(%rip),%rdx        # a7b8d8 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x160>
  736e43:	mov    $0x34,%esi
  736e48:	call   *0x36c692(%rip)        # aa34e0 <_DYNAMIC+0x280>
  736e4e:	jmp    736ffd <owner_source_control::main+0x6bd>
  736e53:	lea    0x344aae(%rip),%rdi        # a7b908 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x190>
  736e5a:	call   *0x36c688(%rip)        # aa34e8 <_DYNAMIC+0x288>
  736e60:	jmp    736ffd <owner_source_control::main+0x6bd>
  736e65:	lea    0x344ae4(%rip),%r9        # a7b950 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x1d8>
  736e6c:	lea    0x90(%rsp),%rsi
  736e74:	mov    %rsp,%rdx
  736e77:	xor    %edi,%edi
  736e79:	xor    %ecx,%ecx
  736e7b:	call   731cf5 <core::panicking::assert_failed::<gpui::source::FieldId, gpui::source::FieldId>>
  736e80:	jmp    736ffd <owner_source_control::main+0x6bd>
  736e85:	lea    0x344aac(%rip),%r9        # a7b938 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x1c0>
  736e8c:	lea    -0x6df057(%rip),%rdx        # 57e3c <anon.305d07fa6d8a71cc44514f8a1dc6c220.98.llvm.16405730940860663774+0x18>
  736e93:	xor    %edi,%edi
  736e95:	mov    %rbx,%rsi
  736e98:	xor    %ecx,%ecx
  736e9a:	call   *0x36cda8(%rip)        # aa3c48 <_DYNAMIC+0x9e8>
  736ea0:	jmp    736ffd <owner_source_control::main+0x6bd>
  736ea5:	movq   $0xd,(%rsp)
  736ead:	movq   $0x0,0x8(%rsp)
  736eb6:	mov    %rbx,0x10(%rsp)
  736ebb:	lea    -0x6d9572(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  736ec2:	lea    0x344ae7(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  736ec9:	lea    0x3449c0(%rip),%r8        # a7b890 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x118>
  736ed0:	mov    %rsp,%rdx
  736ed3:	mov    $0x2b,%esi
  736ed8:	call   *0x36c71a(%rip)        # aa35f8 <_DYNAMIC+0x398>
  736ede:	jmp    736ffd <owner_source_control::main+0x6bd>
  736ee3:	mov    0xc0(%rsp),%rdx
  736eeb:	mov    %rdx,0x118(%rsp)
  736ef3:	movups 0xa0(%rsp),%xmm0
  736efb:	movups 0xb0(%rsp),%xmm1
  736f03:	movups %xmm1,0x108(%rsp)
  736f0b:	movups %xmm0,0xf8(%rsp)
  736f13:	mov    %rcx,0xe8(%rsp)
  736f1b:	mov    %rax,0xf0(%rsp)
  736f23:	lea    -0x6d95da(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  736f2a:	lea    0x344a7f(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  736f31:	lea    0x344988(%rip),%r8        # a7b8c0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x148>
  736f38:	lea    0xe8(%rsp),%rdx
  736f40:	mov    $0x2b,%esi
  736f45:	call   *0x36c6ad(%rip)        # aa35f8 <_DYNAMIC+0x398>
  736f4b:	jmp    736ffd <owner_source_control::main+0x6bd>
  736f50:	mov    $0xd,%ecx
  736f55:	jmp    736f63 <owner_source_control::main+0x623>
  736f57:	mov    $0xe,%ecx
  736f5c:	jmp    736f63 <owner_source_control::main+0x623>
  736f5e:	mov    $0x29,%ecx
  736f63:	mov    %rcx,(%rsp)
  736f67:	mov    %r13b,0x8(%rsp)
  736f6c:	mov    0xe8(%rsp),%rcx
  736f74:	mov    0xef(%rsp),%rdx
  736f7c:	mov    %rcx,0x9(%rsp)
  736f81:	mov    %rdx,0x10(%rsp)
  736f86:	mov    %eax,0x18(%rsp)
  736f8a:	movaps 0x90(%rsp),%xmm0
  736f92:	movups %xmm0,0x1c(%rsp)
  736f97:	movups 0x9c(%rsp),%xmm0
  736f9f:	movups %xmm0,0x28(%rsp)
  736fa4:	lea    -0x6d965b(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  736fab:	lea    0x3449fe(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  736fb2:	lea    0x344937(%rip),%r8        # a7b8f0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x178>
  736fb9:	mov    %rsp,%rdx
  736fbc:	mov    $0x2b,%esi
  736fc1:	call   *0x36c631(%rip)        # aa35f8 <_DYNAMIC+0x398>
  736fc7:	jmp    736ffd <owner_source_control::main+0x6bd>
  736fc9:	movq   $0xd,(%rsp)
  736fd1:	movq   $0x0,0x8(%rsp)
  736fda:	lea    -0x6d96f0(%rip),%rdi        # 5d8f1 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x109>
  736fe1:	lea    0x3449c8(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  736fe8:	lea    0x344931(%rip),%r8        # a7b920 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x1a8>
  736fef:	mov    %rsp,%rdx
  736ff2:	mov    $0x24,%esi
  736ff7:	call   *0x36c5fb(%rip)        # aa35f8 <_DYNAMIC+0x398>
  736ffd:	ud2
  736fff:	jmp    737035 <owner_source_control::main+0x6f5>
  737001:	mov    %rax,%rbx
  737004:	lea    0xe8(%rsp),%rdi
  73700c:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  737011:	jmp    737045 <owner_source_control::main+0x705>
  737013:	jmp    737035 <owner_source_control::main+0x6f5>
  737015:	mov    %rax,%rbx
  737018:	cmpl   $0x2,0x2d0(%rsp)
  737020:	je     737052 <owner_source_control::main+0x712>
  737022:	lea    0x2d0(%rsp),%rdi
  73702a:	call   735010 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  73702f:	jmp    737052 <owner_source_control::main+0x712>
  737031:	jmp    737035 <owner_source_control::main+0x6f5>
  737033:	jmp    737035 <owner_source_control::main+0x6f5>
  737035:	mov    %rax,%rbx
  737038:	mov    %rsp,%rdi
  73703b:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  737040:	jmp    737045 <owner_source_control::main+0x705>
  737042:	mov    %rax,%rbx
  737045:	lea    0x198(%rsp),%rdi
  73704d:	call   735010 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  737052:	mov    %rbx,%rdi
  737055:	call   a78330 <_Unwind_Resume@plt>
  73705a:	call   *0x36c498(%rip)        # aa34f8 <_DYNAMIC+0x298>


/tmp/gpui-projected-source-captures/release-baseline/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000737060 <owner_source_control::open>:
  737060:	push   %r15
  737062:	push   %r14
  737064:	push   %r12
  737066:	push   %rbx
  737067:	sub    $0x418,%rsp
  73706e:	mov    %rdi,%rbx
  737071:	movq   $0x0,0x68(%rsp)
  73707a:	call   *0x36c770(%rip)        # aa37f0 <_DYNAMIC+0x590>
  737080:	movq   $0x0,0x1b8(%rsp)
  73708c:	mov    %rax,0x1b0(%rsp)
  737094:	movq   $0x0,0x1c8(%rsp)
  7370a0:	mov    0x3446f1(%rip),%rax        # a7b798 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x20>
  7370a7:	mov    %rax,0x300(%rsp)
  7370af:	movups 0x3446d2(%rip),%xmm0        # a7b788 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x10>
  7370b6:	movaps %xmm0,0x2f0(%rsp)
  7370be:	movups 0x3446b3(%rip),%xmm0        # a7b778 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214>
  7370c5:	movaps %xmm0,0x2e0(%rsp)
  7370cd:	lea    0x68(%rsp),%rdi
  7370d2:	lea    0x1b0(%rsp),%rsi
  7370da:	lea    0x2e0(%rsp),%rdx
  7370e2:	call   727ee0 <<gpui::reader::question::Questions<owner_source_control::Model>>::question_with::<gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>>>
  7370e7:	cmpl   $0x2,0x68(%rsp)
  7370ec:	je     737250 <owner_source_control::open+0x1f0>
  7370f2:	lea    0x2e0(%rsp),%rdi
  7370fa:	lea    0x68(%rsp),%rsi
  7370ff:	mov    $0x138,%edx
  737104:	call   *0x36c3c6(%rip)        # aa34d0 <memcpy@GLIBC_2.14>
  73710a:	mov    0x1a0(%rsp),%r15
  737112:	mov    0x1a8(%rsp),%r12
  73711a:	call   *0x36c3a0(%rip)        # aa34c0 <_DYNAMIC+0x260>
  737120:	mov    $0x4,%edi
  737125:	mov    $0x1,%esi
  73712a:	call   *0x36c370(%rip)        # aa34a0 <_DYNAMIC+0x240>
  737130:	test   %rax,%rax
  737133:	je     7372eb <owner_source_control::open+0x28b>
  737139:	movl   $0x64656573,(%rax)
  73713f:	movq   $0x1,0x48(%rsp)
  737148:	movq   $0x4,0x18(%rsp)
  737151:	mov    %rax,0x20(%rsp)
  737156:	movq   $0x4,0x28(%rsp)
  73715f:	movl   $0x0,0x30(%rsp)
  737167:	mov    %r15,0x38(%rsp)
  73716c:	mov    %r12,0x40(%rsp)
  737171:	movups 0x400(%rsp),%xmm0
  737179:	movaps %xmm0,0x50(%rsp)
  73717e:	movabs $0xb400000118,%rax
  737188:	mov    %rax,0x10(%rsp)
  73718d:	movl   $0x0,(%rsp)
  737194:	movl   $0x434b0000,0x8(%rsp)
  73719c:	movw   $0x0,0xc(%rsp)
  7371a3:	lea    0x1b0(%rsp),%r14
  7371ab:	lea    0x2e0(%rsp),%rsi
  7371b3:	mov    $0x118,%edx
  7371b8:	mov    %r14,%rdi
  7371bb:	call   *0x36c30f(%rip)        # aa34d0 <memcpy@GLIBC_2.14>
  7371c1:	movaps 0x50(%rsp),%xmm0
  7371c6:	movups %xmm0,0x2c8(%rsp)
  7371ce:	movq   $0x0,0x2d8(%rsp)
  7371da:	lea    0x68(%rsp),%rdi
  7371df:	lea    0x18(%rsp),%rsi
  7371e4:	mov    %rsp,%rcx
  7371e7:	movss  -0x6df47f(%rip),%xmm0        # 57d70 <anon.079f5e587c394fcac2765eb4d0cf0bc2.312.llvm.6319143315422321905+0x18>
  7371ef:	mov    %r14,%rdx
  7371f2:	mov    $0x1,%r8d
  7371f8:	xor    %r9d,%r9d
  7371fb:	call   6faed0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::mount_lanes>
  737200:	cmpl   $0x2,0x68(%rsp)
  737205:	je     737284 <owner_source_control::open+0x224>
  737207:	lea    0x68(%rsp),%rsi
  73720c:	mov    $0x138,%edx
  737211:	mov    %rbx,%rdi
  737214:	call   *0x36c2b6(%rip)        # aa34d0 <memcpy@GLIBC_2.14>
  73721a:	mov    %r15,0x138(%rbx)
  737221:	mov    %r12,0x140(%rbx)
  737228:	movq   $0x28,0x148(%rbx)
  737233:	movq   $0x138,0x150(%rbx)
  73723e:	mov    %rbx,%rax
  737241:	add    $0x418,%rsp
  737248:	pop    %rbx
  737249:	pop    %r12
  73724b:	pop    %r14
  73724d:	pop    %r15
  73724f:	ret
  737250:	movzbl 0x70(%rsp),%eax
  737255:	mov    %al,0x2e0(%rsp)
  73725c:	lea    -0x6d9913(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  737263:	lea    0x3447a6(%rip),%rcx        # a7ba10 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x298>
  73726a:	lea    0x34470f(%rip),%r8        # a7b980 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x208>
  737271:	lea    0x2e0(%rsp),%rdx
  737279:	mov    $0x2b,%esi
  73727e:	call   *0x36c374(%rip)        # aa35f8 <_DYNAMIC+0x398>
  737284:	mov    0xa0(%rsp),%rax
  73728c:	mov    %rax,0x1e0(%rsp)
  737294:	movups 0x70(%rsp),%xmm0
  737299:	movups 0x80(%rsp),%xmm1
  7372a1:	movups 0x90(%rsp),%xmm2
  7372a9:	movaps %xmm2,0x1d0(%rsp)
  7372b1:	movaps %xmm1,0x1c0(%rsp)
  7372b9:	movaps %xmm0,0x1b0(%rsp)
  7372c1:	lea    -0x6d9978(%rip),%rdi        # 5d950 <anon.d6806d9f56049ce1dff51ddf23659ee5.2.llvm.11139854418402343214+0x168>
  7372c8:	lea    0x3446e1(%rip),%rcx        # a7b9b0 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x238>
  7372cf:	lea    0x3446c2(%rip),%r8        # a7b998 <anon.d6806d9f56049ce1dff51ddf23659ee5.3.llvm.11139854418402343214+0x220>
  7372d6:	lea    0x1b0(%rsp),%rdx
  7372de:	mov    $0x2b,%esi
  7372e3:	call   *0x36c30f(%rip)        # aa35f8 <_DYNAMIC+0x398>
  7372e9:	jmp    7372fb <owner_source_control::open+0x29b>
  7372eb:	mov    $0x1,%edi
  7372f0:	mov    $0x4,%esi
  7372f5:	call   *0x36c2bd(%rip)        # aa35b8 <_DYNAMIC+0x358>
  7372fb:	ud2
  7372fd:	mov    %rax,%rbx
  737300:	lea    0x2e0(%rsp),%rdi
  737308:	call   735230 <core::ptr::drop_glue::<gpui::reader::question::Questions<owner_source_control::Model, gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>>>>
  73730d:	jmp    737322 <owner_source_control::open+0x2c2>
  73730f:	call   *0x36c1e3(%rip)        # aa34f8 <_DYNAMIC+0x298>
  737315:	mov    %rax,%rbx
  737318:	lea    0x68(%rsp),%rdi
  73731d:	call   7287c0 <core::ptr::drop_glue::<core::option::Option<gpui_reactivity_state::request::OwnerScope>>>
  737322:	mov    %rbx,%rdi
  737325:	call   a78330 <_Unwind_Resume@plt>
  73732a:	call   *0x36c1c8(%rip)        # aa34f8 <_DYNAMIC+0x298>
  737330:	mov    %rax,%rbx
  737333:	lea    0x1b0(%rsp),%rdi
  73733b:	call   735ec0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  737340:	mov    %rbx,%rdi
  737343:	call   a78330 <_Unwind_Resume@plt>
