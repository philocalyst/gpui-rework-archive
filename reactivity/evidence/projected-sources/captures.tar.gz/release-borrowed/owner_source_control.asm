
/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000006e8d30 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>>:
  6e8d30:	push   %rbp
  6e8d31:	push   %r15
  6e8d33:	push   %r14
  6e8d35:	push   %r13
  6e8d37:	push   %r12
  6e8d39:	push   %rbx
  6e8d3a:	sub    $0xc8,%rsp
  6e8d41:	mov    %ecx,%ebp
  6e8d43:	mov    %rsi,%rbx
  6e8d46:	mov    %rdi,%r15
  6e8d49:	mov    0x110(%rsi),%r14
  6e8d50:	test   %r14,%r14
  6e8d53:	je     6e8d6a <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x3a>
  6e8d55:	cmpb   $0x1,0x756(%r14)
  6e8d5d:	jne    6e8d8e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x5e>
  6e8d5f:	mov    $0xe,%r12d
  6e8d65:	jmp    6e8e49 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x119>
  6e8d6a:	movq   $0x2,(%r15)
  6e8d71:	movq   $0xd,0x8(%r15)
  6e8d79:	movq   $0x0,0x10(%r15)
  6e8d81:	mov    %rbx,0x18(%r15)
  6e8d85:	mov    %ebp,0x40(%r15)
  6e8d89:	jmp    6e9084 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x354>
  6e8d8e:	mov    %rbx,(%rsp)
  6e8d92:	mov    0x698(%r14),%rax
  6e8d99:	mov    %rax,0x20(%rsp)
  6e8d9e:	lea    0x290(%r14),%r13
  6e8da5:	lea    0x228(%r14),%rcx
  6e8dac:	lea    0x70(%rsp),%rdi
  6e8db1:	mov    %rdx,%rbx
  6e8db4:	mov    %rdx,%rsi
  6e8db7:	mov    %r13,%rdx
  6e8dba:	call   728090 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve>
  6e8dbf:	mov    0x70(%rsp),%rax
  6e8dc4:	cmp    $0xffffffffffffffff,%rax
  6e8dc8:	je     6e8de1 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xb1>
  6e8dca:	movups 0x78(%rsp),%xmm0
  6e8dcf:	mov    %rax,0x40(%rsp)
  6e8dd4:	movups %xmm0,0x48(%rsp)
  6e8dd9:	mov    $0x20,%r12d
  6e8ddf:	jmp    6e8e0b <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xdb>
  6e8de1:	mov    0x78(%rsp),%rax
  6e8de6:	mov    %rax,0x18(%rsp)
  6e8deb:	movq   $0x0,0xa8(%rsp)
  6e8df7:	mov    $0xe,%r12d
  6e8dfd:	cmpb   $0x0,0x756(%r14)
  6e8e05:	je     6e8f17 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x1e7>
  6e8e0b:	mov    $0x1,%r8b
  6e8e0e:	mov    0x40(%rsp),%r9
  6e8e13:	mov    0x48(%rsp),%rdi
  6e8e18:	mov    0x50(%rsp),%rdx
  6e8e1d:	movzbl 0x58(%rsp),%esi
  6e8e22:	mov    0x60(%rsp),%rax
  6e8e27:	mov    0x68(%rsp),%rcx
  6e8e2c:	mov    0x5c(%rsp),%r10d
  6e8e31:	mov    %r10d,0x2f(%rsp)
  6e8e36:	mov    0x59(%rsp),%r10d
  6e8e3b:	mov    %r10d,0x2c(%rsp)
  6e8e40:	test   %r8b,%r8b
  6e8e43:	je     6e8ea3 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x173>
  6e8e45:	mov    (%rsp),%rbx
  6e8e49:	movq   $0x2,(%r15)
  6e8e50:	mov    %r12,0x8(%r15)
  6e8e54:	mov    %r9,0x10(%r15)
  6e8e58:	mov    %rdi,0x18(%r15)
  6e8e5c:	mov    %rdx,0x20(%r15)
  6e8e60:	mov    %sil,0x28(%r15)
  6e8e64:	mov    0x2c(%rsp),%edx
  6e8e68:	mov    0x2f(%rsp),%esi
  6e8e6c:	mov    %edx,0x29(%r15)
  6e8e70:	mov    %esi,0x2c(%r15)
  6e8e74:	mov    %rax,0x30(%r15)
  6e8e78:	mov    %rcx,0x38(%r15)
  6e8e7c:	mov    %ebp,0x40(%r15)
  6e8e80:	mov    0x9(%rsp),%eax
  6e8e84:	mov    0xc(%rsp),%ecx
  6e8e88:	mov    %eax,0x51(%r15)
  6e8e8c:	mov    %ecx,0x54(%r15)
  6e8e90:	cmpb   $0x0,0x756(%r14)
  6e8e98:	je     6e9072 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x342>
  6e8e9e:	jmp    6e907c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x34c>
  6e8ea3:	mov    0x698(%r14),%r11
  6e8eaa:	cmp    0x20(%rsp),%r11
  6e8eaf:	jne    6e8edb <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x1ab>
  6e8eb1:	mov    $0x4,%ebx
  6e8eb6:	lea    0xa8(%rsp),%r13
  6e8ebe:	mov    %r8,0x20(%rsp)
  6e8ec3:	mov    %rax,0x18(%rsp)
  6e8ec8:	mov    %rcx,0x10(%rsp)
  6e8ecd:	mov    %r9,%r11
  6e8ed0:	mov    %rdx,%r8
  6e8ed3:	mov    %esi,%r10d
  6e8ed6:	jmp    6e8fdf <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x2af>
  6e8edb:	mov    %rdi,%r8
  6e8ede:	shr    $0x20,%r8
  6e8ee2:	movzbl 0x754(%r14),%r10d
  6e8eea:	cmpq   $0x0,0x6b8(%r14)
  6e8ef2:	mov    %r8,0x20(%rsp)
  6e8ef7:	je     6e8f10 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x1e0>
  6e8ef9:	test   %r10b,%r10b
  6e8efc:	je     6e8faf <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x27f>
  6e8f02:	cmpq   $0xffffffffffffffff,0x5c0(%r14)
  6e8f0a:	jne    6e8faf <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x27f>
  6e8f10:	xor    %ebx,%ebx
  6e8f12:	jmp    6e8fbb <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x28b>
  6e8f17:	mov    0x698(%r14),%r12
  6e8f1e:	inc    %r12
  6e8f21:	je     6e9134 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x404>
  6e8f27:	mov    %r13,%rdi
  6e8f2a:	call   *0x18(%rbx)
  6e8f2d:	mov    %rax,0x10(%rsp)
  6e8f32:	mov    %r13,%rdi
  6e8f35:	call   *0x20(%rbx)
  6e8f38:	cmp    %rax,0x10(%rsp)
  6e8f3d:	je     6e9099 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x369>
  6e8f43:	mov    (%rbx),%rax
  6e8f46:	movq   $0xa,0x78(%rsp)
  6e8f4f:	mov    %rax,0x80(%rsp)
  6e8f57:	mov    (%rsp),%rax
  6e8f5b:	mov    %rax,0x90(%rsp)
  6e8f63:	movups 0x98(%rsp),%xmm0
  6e8f6b:	movups %xmm0,0x60(%rsp)
  6e8f70:	mov    0x78(%rsp),%rax
  6e8f75:	mov    %rax,0x40(%rsp)
  6e8f7a:	mov    0x80(%rsp),%rax
  6e8f82:	mov    %rax,0x48(%rsp)
  6e8f87:	mov    0x88(%rsp),%rax
  6e8f8f:	mov    %rax,0x50(%rsp)
  6e8f94:	mov    0x90(%rsp),%rax
  6e8f9c:	mov    %rax,0x58(%rsp)
  6e8fa1:	mov    $0x20,%r12d
  6e8fa7:	mov    $0x1,%r8b
  6e8faa:	jmp    6e8e0e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xde>
  6e8faf:	mov    0x6c8(%r14),%rbp
  6e8fb6:	mov    $0x1,%ebx
  6e8fbb:	mov    %edi,0x34(%rsp)
  6e8fbf:	mov    0x6a0(%r14),%rdi
  6e8fc6:	mov    0x740(%r14),%r8
  6e8fcd:	lea    0x9(%rsp),%r13
  6e8fd2:	mov    %r12,0x18(%rsp)
  6e8fd7:	mov    %r9,0x10(%rsp)
  6e8fdc:	mov    %rbp,%r12
  6e8fdf:	lea    0x59(%rsp),%rbp
  6e8fe4:	mov    0x3(%rbp),%r9d
  6e8fe8:	mov    %r9d,0x3(%r13)
  6e8fec:	mov    0x0(%rbp),%r9d
  6e8ff0:	mov    %r9d,0x0(%r13)
  6e8ff4:	mov    %rbx,(%r15)
  6e8ff7:	mov    %r12,0x8(%r15)
  6e8ffb:	mov    %r11,0x10(%r15)
  6e8fff:	mov    %rdi,0x18(%r15)
  6e9003:	mov    %r8,0x20(%r15)
  6e9007:	mov    %r10b,0x28(%r15)
  6e900b:	mov    0xa8(%rsp),%edi
  6e9012:	mov    %edi,0x29(%r15)
  6e9016:	mov    0xab(%rsp),%edi
  6e901d:	mov    %edi,0x2c(%r15)
  6e9021:	mov    0x18(%rsp),%rdi
  6e9026:	mov    %rdi,0x30(%r15)
  6e902a:	mov    0x10(%rsp),%rdi
  6e902f:	mov    %rdi,0x38(%r15)
  6e9033:	mov    0x34(%rsp),%edi
  6e9037:	mov    %edi,0x40(%r15)
  6e903b:	mov    0x20(%rsp),%rdi
  6e9040:	mov    %edi,0x44(%r15)
  6e9044:	mov    %rdx,0x48(%r15)
  6e9048:	mov    %sil,0x50(%r15)
  6e904c:	mov    0x9(%rsp),%edx
  6e9050:	mov    %edx,0x51(%r15)
  6e9054:	mov    0xc(%rsp),%edx
  6e9058:	mov    %edx,0x54(%r15)
  6e905c:	mov    %rax,0x58(%r15)
  6e9060:	mov    %rcx,0x60(%r15)
  6e9064:	mov    (%rsp),%rbx
  6e9068:	cmpb   $0x0,0x756(%r14)
  6e9070:	jne    6e907c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x34c>
  6e9072:	cmpq   $0xffffffffffffffff,0x698(%r14)
  6e907a:	jne    6e9084 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x354>
  6e907c:	mov    %rbx,%rdi
  6e907f:	call   736370 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  6e9084:	mov    %r15,%rax
  6e9087:	add    $0xc8,%rsp
  6e908e:	pop    %rbx
  6e908f:	pop    %r12
  6e9091:	pop    %r13
  6e9093:	pop    %r14
  6e9095:	pop    %r15
  6e9097:	pop    %rbp
  6e9098:	ret
  6e9099:	mov    0x4(%rax),%ecx
  6e909c:	cmp    $0xffffffff,%ecx
  6e909f:	je     6e913f <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x40f>
  6e90a5:	inc    %ecx
  6e90a7:	mov    %ecx,0x4(%rax)
  6e90aa:	mov    %ebp,(%rax)
  6e90ac:	mov    %r12,0x698(%r14)
  6e90b3:	incq   0x6e8(%r14)
  6e90ba:	movq   $0x0,0x740(%r14)
  6e90c5:	lea    0x38(%rsp),%rdi
  6e90ca:	lea    0xa8(%rsp),%r8
  6e90d2:	mov    %r14,%rsi
  6e90d5:	mov    (%rsp),%rbx
  6e90d9:	mov    %rbx,%rdx
  6e90dc:	mov    0x18(%rsp),%rcx
  6e90e1:	xor    %r9d,%r9d
  6e90e4:	call   6f0900 <<gpui::runtime::RuntimeMut<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::after_source_changed>
  6e90e9:	mov    0x38(%rsp),%r12
  6e90ee:	cmp    $0xfffffffffffffffe,%r12
  6e90f2:	jne    6e912c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x3fc>
  6e90f4:	movups 0x40(%rsp),%xmm0
  6e90f9:	movups 0x50(%rsp),%xmm1
  6e90fe:	movups 0x60(%rsp),%xmm2
  6e9103:	movups %xmm2,0x28(%r15)
  6e9108:	movups %xmm1,0x18(%r15)
  6e910d:	movups %xmm0,0x8(%r15)
  6e9112:	movq   $0xffffffffffffffff,(%r15)
  6e9119:	cmpb   $0x0,0x756(%r14)
  6e9121:	je     6e9072 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x342>
  6e9127:	jmp    6e907c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x34c>
  6e912c:	xor    %r8d,%r8d
  6e912f:	jmp    6e8e0e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xde>
  6e9134:	mov    $0x1f,%r12d
  6e913a:	jmp    6e8e0b <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xdb>
  6e913f:	lea    -0x68bac7(%rip),%rdi        # 5d67f <anon.4d76bc73d2ecf6d7439404264a8f75e0.68.llvm.16741567646709100845>
  6e9146:	lea    0x39254b(%rip),%rdx        # a7b698 <anon.4d76bc73d2ecf6d7439404264a8f75e0.70.llvm.16741567646709100845>
  6e914d:	mov    $0x19,%esi
  6e9152:	call   *0x3ba2f8(%rip)        # aa3450 <_DYNAMIC+0x2b0>
  6e9158:	ud2
  6e915a:	mov    %rax,%r15
  6e915d:	cmpb   $0x0,0x756(%r14)
  6e9165:	jne    6e9171 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x441>
  6e9167:	cmpq   $0xffffffffffffffff,0x698(%r14)
  6e916f:	jne    6e917a <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x44a>
  6e9171:	mov    (%rsp),%rdi
  6e9175:	call   736370 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  6e917a:	mov    %r15,%rdi
  6e917d:	call   a78270 <_Unwind_Resume@plt>
  6e9182:	call   *0x3ba2b0(%rip)        # aa3438 <_DYNAMIC+0x298>
  6e9188:	mov    %rax,%rdi
  6e918b:	call   *0x3ba2c7(%rip)        # aa3458 <_DYNAMIC+0x2b8>
  6e9191:	mov    %rax,%rbx
  6e9194:	mov    %rdx,%r13
  6e9197:	mov    %rax,0xb0(%rsp)
  6e919f:	mov    %rdx,0xb8(%rsp)
  6e91a7:	movq   $0xfffffffffffffffe,0xa8(%rsp)
  6e91b3:	mov    %r14,%rdi
  6e91b6:	call   70a160 <<gpui::runtime::Runtime<owner_source_control::Model>>::poison>
  6e91bb:	mov    0x0(%r13),%rax
  6e91bf:	test   %rax,%rax
  6e91c2:	je     6e922c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x4fc>
  6e91c4:	mov    %rbx,%rdi
  6e91c7:	call   *%rax
  6e91c9:	jmp    6e922c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x4fc>
  6e91cb:	jmp    6e9254 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x524>
  6e91d0:	mov    %rax,%r15
  6e91d3:	lea    0xa8(%rsp),%rdi
  6e91db:	call   6ea4c0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::source::FieldId, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e91e0:	jmp    6e915d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x42d>
  6e91e5:	call   *0x3ba24d(%rip)        # aa3438 <_DYNAMIC+0x298>
  6e91eb:	call   *0x3ba26f(%rip)        # aa3460 <_DYNAMIC+0x2c0>
  6e91f1:	mov    %rax,%rdi
  6e91f4:	call   *0x3ba25e(%rip)        # aa3458 <_DYNAMIC+0x2b8>
  6e91fa:	mov    %rax,%rbx
  6e91fd:	mov    %rdx,%r13
  6e9200:	mov    %rax,0x78(%rsp)
  6e9205:	mov    %rdx,0x80(%rsp)
  6e920d:	movq   $0xfffffffffffffffd,0x70(%rsp)
  6e9216:	mov    %r14,%rdi
  6e9219:	call   70a160 <<gpui::runtime::Runtime<owner_source_control::Model>>::poison>
  6e921e:	mov    0x0(%r13),%rax
  6e9222:	test   %rax,%rax
  6e9225:	je     6e922c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x4fc>
  6e9227:	mov    %rbx,%rdi
  6e922a:	call   *%rax
  6e922c:	mov    0x8(%r13),%rsi
  6e9230:	mov    $0xf,%r12d
  6e9236:	test   %rsi,%rsi
  6e9239:	je     6e8e0b <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xdb>
  6e923f:	mov    0x10(%r13),%rdx
  6e9243:	mov    %rbx,%rdi
  6e9246:	call   *0x3ba19c(%rip)        # aa33e8 <_DYNAMIC+0x248>
  6e924c:	mov    $0x1,%r8b
  6e924f:	jmp    6e8e0e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xde>
  6e9254:	mov    %rax,%r15
  6e9257:	mov    0x8(%r13),%rsi
  6e925b:	test   %rsi,%rsi
  6e925e:	je     6e915d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x42d>
  6e9264:	mov    0x10(%r13),%rdx
  6e9268:	mov    %rbx,%rdi
  6e926b:	call   *0x3ba177(%rip)        # aa33e8 <_DYNAMIC+0x248>
  6e9271:	jmp    6e915d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x42d>
  6e9276:	mov    %rax,%r15
  6e9279:	lea    0x70(%rsp),%rdi
  6e927e:	call   6ea530 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e9283:	jmp    6e915d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x42d>
  6e9288:	call   *0x3ba1aa(%rip)        # aa3438 <_DYNAMIC+0x298>
  6e928e:	call   *0x3ba1cc(%rip)        # aa3460 <_DYNAMIC+0x2c0>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000701da0 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index>:
  701da0:	push   %rbx
  701da1:	mov    $0x11,%r9d
  701da7:	cmp    0x5e8(%rsi),%rdx
  701dae:	jne    701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701db4:	cmpb   $0x1,0x752(%rsi)
  701dbb:	jne    701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701dc1:	mov    0x1e8(%rsi),%rax
  701dc8:	test   %rax,%rax
  701dcb:	je     701e5c <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xbc>
  701dd1:	cmp    $0x1,%eax
  701dd4:	jne    701e76 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd6>
  701dda:	mov    0x1f8(%rsi),%r8
  701de1:	test   %r8,%r8
  701de4:	je     701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701dea:	mov    0x1f0(%rsi),%rax
  701df1:	xor    %edx,%edx
  701df3:	cmp    $0x1,%r8
  701df7:	je     701e24 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x84>
  701df9:	nopl   0x0(%rax)
  701e00:	mov    %rdx,%r10
  701e03:	mov    %r8,%r11
  701e06:	shr    $1,%r11
  701e09:	add    %r11,%rdx
  701e0c:	mov    %rdx,%rbx
  701e0f:	shl    $0x4,%rbx
  701e13:	cmp    %rcx,(%rax,%rbx,1)
  701e17:	cmova  %r10,%rdx
  701e1b:	sub    %r11,%r8
  701e1e:	cmp    $0x1,%r8
  701e22:	ja     701e00 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x60>
  701e24:	mov    %rdx,%r10
  701e27:	shl    $0x4,%r10
  701e2b:	xor    %r8d,%r8d
  701e2e:	cmp    %rcx,(%rax,%r10,1)
  701e32:	setbe  %r8b
  701e36:	add    %rdx,%r8
  701e39:	je     701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e3b:	shl    $0x4,%r8
  701e3f:	mov    %rcx,%rdx
  701e42:	sub    -0x10(%rax,%r8,1),%rdx
  701e47:	mov    -0x4(%rax,%r8,1),%r10d
  701e4c:	cmp    %r10,%rdx
  701e4f:	jae    701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e51:	add    %r8,%rax
  701e54:	mov    -0x8(%rax),%eax
  701e57:	add    %rax,%rdx
  701e5a:	jmp    701ed2 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x132>
  701e5c:	mov    %rcx,%rdx
  701e5f:	sub    0x1f0(%rsi),%rdx
  701e66:	jb     701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e68:	cmp    0x1f8(%rsi),%rdx
  701e6f:	jb     701ed2 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x132>
  701e71:	mov    %r9,(%rdi)
  701e74:	pop    %rbx
  701e75:	ret
  701e76:	mov    0x1f8(%rsi),%rdx
  701e7d:	test   %rdx,%rdx
  701e80:	je     701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e82:	mov    0x1f0(%rsi),%rax
  701e89:	cmp    $0x1,%rdx
  701e8d:	jne    701e96 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xf6>
  701e8f:	cmp    %rcx,(%rax)
  701e92:	jne    701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e94:	jmp    701ecf <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x12f>
  701e96:	xor    %r8d,%r8d
  701e99:	nopl   0x0(%rax)
  701ea0:	mov    %r8,%r10
  701ea3:	mov    %rdx,%r11
  701ea6:	shr    $1,%r11
  701ea9:	add    %r11,%r8
  701eac:	lea    (%r8,%r8,2),%rbx
  701eb0:	cmp    %rcx,(%rax,%rbx,4)
  701eb4:	cmova  %r10,%r8
  701eb8:	sub    %r11,%rdx
  701ebb:	cmp    $0x1,%rdx
  701ebf:	ja     701ea0 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x100>
  701ec1:	lea    (%r8,%r8,2),%rdx
  701ec5:	cmp    %rcx,(%rax,%rdx,4)
  701ec9:	jne    701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701ecb:	lea    (%rax,%rdx,4),%rax
  701ecf:	mov    0x8(%rax),%edx
  701ed2:	mov    0x650(%rsi),%rax
  701ed9:	test   %rax,%rax
  701edc:	je     701f6e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  701ee2:	mov    0x658(%rsi),%r8
  701ee9:	test   %r8,%r8
  701eec:	je     701f5e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1be>
  701eee:	mov    %r8,%r10
  701ef1:	and    $0x7,%r10
  701ef5:	je     701f17 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x177>
  701ef7:	xor    %r11d,%r11d
  701efa:	nopw   0x0(%rax,%rax,1)
  701f00:	mov    0x590(%rax),%rax
  701f07:	inc    %r11
  701f0a:	cmp    %r11,%r10
  701f0d:	jne    701f00 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x160>
  701f0f:	mov    %r8,%r10
  701f12:	sub    %r11,%r10
  701f15:	jmp    701f1a <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x17a>
  701f17:	mov    %r8,%r10
  701f1a:	cmp    $0x8,%r8
  701f1e:	jb     701f5e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1be>
  701f20:	mov    0x590(%rax),%rax
  701f27:	mov    0x590(%rax),%rax
  701f2e:	mov    0x590(%rax),%rax
  701f35:	mov    0x590(%rax),%rax
  701f3c:	mov    0x590(%rax),%rax
  701f43:	mov    0x590(%rax),%rax
  701f4a:	mov    0x590(%rax),%rax
  701f51:	mov    0x590(%rax),%rax
  701f58:	add    $0xfffffffffffffff8,%r10
  701f5c:	jne    701f20 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x180>
  701f5e:	cmpw   $0x0,0x58a(%rax)
  701f66:	je     701f6e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  701f68:	cmpq   $0x0,(%rax)
  701f6c:	je     701f7e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1de>
  701f6e:	mov    %rdx,0x8(%rdi)
  701f72:	mov    $0xfffffffffffffffe,%r9
  701f79:	mov    %r9,(%rdi)
  701f7c:	pop    %rbx
  701f7d:	ret
  701f7e:	mov    0x2d8(%rsi),%rax
  701f85:	cmp    %rax,%rdx
  701f88:	jae    702042 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x2a2>
  701f8e:	mov    0x2d0(%rsi),%r10
  701f95:	mov    $0xffffffff,%r11d
  701f9b:	mov    %rdx,%r8
  701f9e:	lea    (%r8,%r8,4),%r8
  701fa2:	mov    0x20(%r10,%r8,8),%ebx
  701fa7:	and    $0xf,%ebx
  701faa:	cmp    $0x9,%ebx
  701fad:	ja     702029 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x289>
  701faf:	cmp    $0x5,%ebx
  701fb2:	je     701fd9 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x239>
  701fb4:	lea    (%r10,%r8,8),%r8
  701fb8:	mov    0x18(%r8),%r8d
  701fbc:	cmp    %r11,%r8
  701fbf:	je     701f6e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  701fc1:	cmp    %r8,%rax
  701fc4:	ja     701f9e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1fe>
  701fc6:	lea    0x378213(%rip),%rdx        # a7a1e0 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xb40>
  701fcd:	mov    %r8,%rdi
  701fd0:	mov    %rax,%rsi
  701fd3:	call   *0x3a1517(%rip)        # aa34f0 <_DYNAMIC+0x350>
  701fd9:	cmpq   $0xffffffffffffffff,0x5c0(%rsi)
  701fe1:	mov    0x5b0(%rsi),%r8
  701fe8:	mov    0x5b8(%rsi),%rax
  701fef:	je     702009 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x269>
  701ff1:	cmpw   $0x0,0x5e0(%rsi)
  701ff9:	js     702009 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x269>
  701ffb:	mov    0x5c8(%rsi),%r8
  702002:	mov    0x5d0(%rsi),%rax
  702009:	shl    $0x6,%rax
  70200d:	test   %rax,%rax
  702010:	je     701e71 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  702016:	add    $0xffffffffffffffc0,%rax
  70201a:	cmp    %rcx,0x20(%r8)
  70201e:	lea    0x40(%r8),%r8
  702022:	jne    70200d <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x26d>
  702024:	jmp    701f6e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  702029:	lea    -0x6a58bb(%rip),%rdi        # 5c775 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e6d>
  702030:	lea    0x378209(%rip),%rdx        # a7a240 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xba0>
  702037:	mov    $0x83,%esi
  70203c:	call   *0x3a13fe(%rip)        # aa3440 <_DYNAMIC+0x2a0>
  702042:	mov    %rdx,%r8
  702045:	lea    0x378194(%rip),%rdx        # a7a1e0 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xb40>
  70204c:	mov    %r8,%rdi
  70204f:	mov    %rax,%rsi
  702052:	call   *0x3a1498(%rip)        # aa34f0 <_DYNAMIC+0x350>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000726a70 <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>>:
  726a70:	push   %rbp
  726a71:	push   %r15
  726a73:	push   %r14
  726a75:	push   %r13
  726a77:	push   %r12
  726a79:	push   %rbx
  726a7a:	sub    $0x28,%rsp
  726a7e:	mov    %rcx,%r13
  726a81:	mov    %rdx,%r12
  726a84:	mov    %rdi,%rbx
  726a87:	mov    (%rsi),%rax
  726a8a:	mov    (%rax),%r14
  726a8d:	mov    %rdx,%rdi
  726a90:	call   *0x18(%rax)
  726a93:	mov    %rax,0x8(%rsp)
  726a98:	cmp    $0x1,%r14d
  726a9c:	jne    726ae7 <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x77>
  726a9e:	mov    0x20(%r13),%rbp
  726aa2:	mov    0x28(%r13),%r15
  726aa6:	shl    $0x4,%r15
  726aaa:	xor    %r13d,%r13d
  726aad:	nopl   (%rax)
  726ab0:	cmp    %r13,%r15
  726ab3:	je     726b7c <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x10c>
  726ab9:	mov    0x0(%rbp,%r13,1),%rdi
  726abe:	mov    0x8(%rbp,%r13,1),%rax
  726ac3:	call   *0x18(%rax)
  726ac6:	add    $0x10,%r13
  726aca:	cmp    %r14,%rax
  726acd:	jne    726ab0 <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x40>
  726acf:	mov    -0x10(%rbp,%r13,1),%rdi
  726ad4:	mov    -0x8(%rbp,%r13,1),%rax
  726ad9:	mov    %r12,%rsi
  726adc:	call   *0x28(%rax)
  726adf:	mov    %rax,%rdi
  726ae2:	mov    %rdx,%rax
  726ae5:	jmp    726b4a <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0xda>
  726ae7:	mov    0x50(%r13),%rbp
  726aeb:	mov    0x58(%r13),%r13
  726aef:	shl    $0x4,%r13
  726af3:	xor    %r15d,%r15d
  726af6:	cs nopw 0x0(%rax,%rax,1)
  726b00:	cmp    %r15,%r13
  726b03:	je     726b7c <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x10c>
  726b05:	mov    0x0(%rbp,%r15,1),%rdi
  726b0a:	mov    0x8(%rbp,%r15,1),%rax
  726b0f:	mov    %r14,%rsi
  726b12:	call   *0x30(%rax)
  726b15:	add    $0x10,%r15
  726b19:	test   %al,%al
  726b1b:	je     726b00 <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x90>
  726b1d:	mov    -0x10(%rbp,%r15,1),%rsi
  726b22:	mov    -0x8(%rbp,%r15,1),%rax
  726b27:	lea    0x10(%rsp),%rdi
  726b2c:	mov    %r12,%rdx
  726b2f:	mov    %r14,%rcx
  726b32:	call   *0x58(%rax)
  726b35:	mov    0x10(%rsp),%rcx
  726b3a:	mov    0x18(%rsp),%rdi
  726b3f:	mov    0x20(%rsp),%rax
  726b44:	cmp    $0xffffffffffffffff,%rcx
  726b48:	jne    726b84 <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x114>
  726b4a:	lea    0x3543d7(%rip),%rdx        # a7af28 <anon.daf501629c8031209a3f8e92524845e0.13.llvm.9161303705346218040+0xd8>
  726b51:	mov    0x8(%rsp),%r15
  726b56:	mov    %r15,%rsi
  726b59:	call   *0x20(%rax)
  726b5c:	test   %al,%al
  726b5e:	je     726b89 <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x119>
  726b60:	mov    0x4(%r15),%eax
  726b64:	movq   $0x0,0x8(%rbx)
  726b6c:	mov    %r15,0x10(%rbx)
  726b70:	mov    %eax,0x18(%rbx)
  726b73:	movq   $0xfffffffffffffffe,(%rbx)
  726b7a:	jmp    726ba1 <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x131>
  726b7c:	mov    $0xb,%ecx
  726b81:	mov    %r14,%rdi
  726b84:	mov    %rdi,%r14
  726b87:	jmp    726b8e <<&gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x11e>
  726b89:	mov    $0xa,%ecx
  726b8e:	movq   $0x20,(%rbx)
  726b95:	mov    %rcx,0x8(%rbx)
  726b99:	mov    %r14,0x10(%rbx)
  726b9d:	mov    %rax,0x18(%rbx)
  726ba1:	mov    %rbx,%rax
  726ba4:	add    $0x28,%rsp
  726ba8:	pop    %rbx
  726ba9:	pop    %r12
  726bab:	pop    %r13
  726bad:	pop    %r14
  726baf:	pop    %r15
  726bb1:	pop    %rbp
  726bb2:	ret


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000727480 <<gpui::source::Sources<owner_source_control::Model>>::resolve>:
  727480:	push   %rbp
  727481:	push   %r15
  727483:	push   %r14
  727485:	push   %r13
  727487:	push   %r12
  727489:	push   %rbx
  72748a:	sub    $0x58,%rsp
  72748e:	mov    %rdx,%r9
  727491:	mov    (%rsi),%rax
  727494:	cmp    $0xffffffffffffffff,%rax
  727498:	lea    0x28(%rsp),%rdx
  72749d:	cmovne %rsi,%rdx
  7274a1:	movups 0x8(%rdx),%xmm0
  7274a5:	movaps %xmm0,0x40(%rsp)
  7274aa:	je     7274bd <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x3d>
  7274ac:	movaps 0x40(%rsp),%xmm0
  7274b1:	movups %xmm0,0x8(%rdi)
  7274b5:	mov    %rax,(%rdi)
  7274b8:	jmp    7275fe <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  7274bd:	mov    %rcx,0x18(%rsp)
  7274c2:	mov    %r8,%r12
  7274c5:	mov    %rdi,0x8(%rsp)
  7274ca:	mov    0x28(%rsi),%rbx
  7274ce:	test   %rbx,%rbx
  7274d1:	mov    %r9,0x10(%rsp)
  7274d6:	mov    %rsi,0x20(%rsp)
  7274db:	je     727539 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xb9>
  7274dd:	mov    0x20(%rsi),%r14
  7274e1:	shl    $0x4,%rbx
  7274e5:	add    %r14,%rbx
  7274e8:	xor    %ebp,%ebp
  7274ea:	jmp    7274fe <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x7e>
  7274ec:	nopl   0x0(%rax)
  7274f0:	add    $0x10,%r14
  7274f4:	cmp    %rbx,%r14
  7274f7:	mov    0x10(%rsp),%r9
  7274fc:	je     72753b <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xbb>
  7274fe:	mov    (%r14),%r13
  727501:	mov    0x8(%r14),%r15
  727505:	mov    %r13,%rdi
  727508:	mov    %r9,%rsi
  72750b:	call   *0x28(%r15)
  72750f:	mov    %rdx,%rcx
  727512:	mov    %rax,%rdi
  727515:	mov    0x18(%rsp),%rsi
  72751a:	mov    %r12,%rdx
  72751d:	call   *0x20(%rcx)
  727520:	test   %al,%al
  727522:	je     7274f0 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x70>
  727524:	mov    %r13,%rdi
  727527:	call   *0x18(%r15)
  72752b:	test   %rbp,%rbp
  72752e:	jne    7275ea <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x16a>
  727534:	mov    %rax,%rbp
  727537:	jmp    7274f0 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x70>
  727539:	xor    %ebp,%ebp
  72753b:	mov    0x20(%rsp),%rax
  727540:	mov    0x58(%rax),%rbx
  727544:	test   %rbx,%rbx
  727547:	je     7275d8 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  72754d:	mov    0x50(%rax),%r14
  727551:	shl    $0x4,%rbx
  727555:	add    %r14,%rbx
  727558:	lea    0x28(%rsp),%r13
  72755d:	mov    0x18(%rsp),%r15
  727562:	jmp    72759b <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x11b>
  727564:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  727570:	mov    0x10(%rsp),%r9
  727575:	add    $0x10,%r14
  727579:	cmp    %rbx,%r14
  72757c:	jne    72759b <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x11b>
  72757e:	jmp    7275d8 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  727580:	test   %rax,%rax
  727583:	je     727570 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xf0>
  727585:	test   %rbp,%rbp
  727588:	mov    0x10(%rsp),%r9
  72758d:	jne    7275ea <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x16a>
  72758f:	mov    %rax,%rbp
  727592:	add    $0x10,%r14
  727596:	cmp    %rbx,%r14
  727599:	je     7275d8 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  72759b:	mov    (%r14),%rsi
  72759e:	mov    0x8(%r14),%rax
  7275a2:	mov    %r13,%rdi
  7275a5:	mov    %r9,%rdx
  7275a8:	mov    %r15,%rcx
  7275ab:	mov    %r12,%r8
  7275ae:	call   *0x50(%rax)
  7275b1:	mov    0x28(%rsp),%rcx
  7275b6:	mov    0x30(%rsp),%rax
  7275bb:	cmp    $0xffffffffffffffff,%rcx
  7275bf:	je     727580 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x100>
  7275c1:	mov    0x38(%rsp),%rdx
  7275c6:	mov    0x8(%rsp),%rdi
  7275cb:	mov    %rcx,(%rdi)
  7275ce:	mov    %rax,0x8(%rdi)
  7275d2:	mov    %rdx,0x10(%rdi)
  7275d6:	jmp    7275fe <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  7275d8:	mov    0x8(%rsp),%rdi
  7275dd:	mov    %rbp,0x8(%rdi)
  7275e1:	movq   $0xffffffffffffffff,(%rdi)
  7275e8:	jmp    7275fe <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  7275ea:	mov    0x8(%rsp),%rdi
  7275ef:	movq   $0x9,(%rdi)
  7275f6:	mov    %rbp,0x8(%rdi)
  7275fa:	mov    %rax,0x10(%rdi)
  7275fe:	mov    %rdi,%rax
  727601:	add    $0x58,%rsp
  727605:	pop    %rbx
  727606:	pop    %r12
  727608:	pop    %r13
  72760a:	pop    %r14
  72760c:	pop    %r15
  72760e:	pop    %rbp
  72760f:	ret


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000727e40 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit>:
  727e40:	push   %rbp
  727e41:	push   %r15
  727e43:	push   %r14
  727e45:	push   %r13
  727e47:	push   %r12
  727e49:	push   %rbx
  727e4a:	sub    $0x28,%rsp
  727e4e:	mov    %r9,%r14
  727e51:	mov    %r8,%r13
  727e54:	mov    %rdx,%r15
  727e57:	mov    %rsi,%r12
  727e5a:	mov    %rdi,%rbx
  727e5d:	mov    %rsp,%rdi
  727e60:	mov    %rdx,%rsi
  727e63:	call   *0x18(%rcx)
  727e66:	movdqa (%rsp),%xmm0
  727e6b:	pcmpeqb -0x6cfe73(%rip),%xmm0        # 58000 <anon.079f5e587c394fcac2765eb4d0cf0bc2.360.llvm.6319143315422321905+0x5c>
  727e73:	pmovmskb %xmm0,%eax
  727e77:	cmp    $0xffff,%eax
  727e7c:	jne    727f07 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xc7>
  727e82:	mov    %rsp,%rdi
  727e85:	mov    %r13,%rsi
  727e88:	call   *0x18(%r14)
  727e8c:	movdqa (%rsp),%xmm0
  727e91:	pcmpeqb -0x6cf1f9(%rip),%xmm0        # 58ca0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0xa80>
  727e99:	pmovmskb %xmm0,%eax
  727e9d:	cmp    $0xffff,%eax
  727ea2:	jne    727f07 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xc7>
  727ea4:	mov    (%r12),%r14
  727ea8:	mov    %r15,%rdi
  727eab:	call   *0x18(%r12)
  727eb0:	mov    %rax,0x20(%rsp)
  727eb5:	cmp    $0x1,%r14d
  727eb9:	jne    727f13 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xd3>
  727ebb:	mov    0x20(%r13),%rbp
  727ebf:	mov    0x28(%r13),%r12
  727ec3:	shl    $0x4,%r12
  727ec7:	xor    %r13d,%r13d
  727eca:	nopw   0x0(%rax,%rax,1)
  727ed0:	cmp    %r13,%r12
  727ed3:	je     727f9d <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x15d>
  727ed9:	mov    0x0(%rbp,%r13,1),%rdi
  727ede:	mov    0x8(%rbp,%r13,1),%rax
  727ee3:	call   *0x18(%rax)
  727ee6:	add    $0x10,%r13
  727eea:	cmp    %r14,%rax
  727eed:	jne    727ed0 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x90>
  727eef:	mov    -0x10(%rbp,%r13,1),%rdi
  727ef4:	mov    -0x8(%rbp,%r13,1),%rax
  727ef9:	mov    %r15,%rsi
  727efc:	call   *0x28(%rax)
  727eff:	mov    %rax,%rdi
  727f02:	mov    %rdx,%rax
  727f05:	jmp    727f77 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x137>
  727f07:	movq   $0x1,(%rbx)
  727f0e:	jmp    727fba <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x17a>
  727f13:	mov    0x50(%r13),%rbp
  727f17:	mov    0x58(%r13),%r13
  727f1b:	shl    $0x4,%r13
  727f1f:	xor    %r12d,%r12d
  727f22:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  727f30:	cmp    %r12,%r13
  727f33:	je     727f9d <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x15d>
  727f35:	mov    0x0(%rbp,%r12,1),%rdi
  727f3a:	mov    0x8(%rbp,%r12,1),%rax
  727f3f:	mov    %r14,%rsi
  727f42:	call   *0x30(%rax)
  727f45:	add    $0x10,%r12
  727f49:	test   %al,%al
  727f4b:	je     727f30 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xf0>
  727f4d:	mov    -0x10(%rbp,%r12,1),%rsi
  727f52:	mov    -0x8(%rbp,%r12,1),%rax
  727f57:	mov    %rsp,%rdi
  727f5a:	mov    %r15,%rdx
  727f5d:	mov    %r14,%rcx
  727f60:	call   *0x58(%rax)
  727f63:	mov    (%rsp),%rcx
  727f67:	mov    0x8(%rsp),%rdi
  727f6c:	mov    0x10(%rsp),%rax
  727f71:	cmp    $0xffffffffffffffff,%rcx
  727f75:	jne    727fa5 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x165>
  727f77:	lea    0x352faa(%rip),%rdx        # a7af28 <anon.daf501629c8031209a3f8e92524845e0.13.llvm.9161303705346218040+0xd8>
  727f7e:	mov    0x20(%rsp),%rsi
  727f83:	call   *0x20(%rax)
  727f86:	test   %al,%al
  727f88:	je     727faa <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x16a>
  727f8a:	movw   $0x0,0x8(%rbx)
  727f90:	mov    %r14,0x10(%rbx)
  727f94:	movq   $0xffffffffffffffff,(%rbx)
  727f9b:	jmp    727fba <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x17a>
  727f9d:	mov    $0xb,%ecx
  727fa2:	mov    %r14,%rdi
  727fa5:	mov    %rdi,%r14
  727fa8:	jmp    727faf <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x16f>
  727faa:	mov    $0xa,%ecx
  727faf:	mov    %rcx,(%rbx)
  727fb2:	mov    %r14,0x8(%rbx)
  727fb6:	mov    %rax,0x10(%rbx)
  727fba:	mov    %rbx,%rax
  727fbd:	add    $0x28,%rsp
  727fc1:	pop    %rbx
  727fc2:	pop    %r12
  727fc4:	pop    %r13
  727fc6:	pop    %r14
  727fc8:	pop    %r15
  727fca:	pop    %rbp
  727fcb:	ret


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000727fd0 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke>:
  727fd0:	push   %r15
  727fd2:	push   %r14
  727fd4:	push   %r12
  727fd6:	push   %rbx
  727fd7:	sub    $0x18,%rsp
  727fdb:	mov    %rdx,%r15
  727fde:	mov    %rsi,%r14
  727fe1:	mov    %rdi,%rbx
  727fe4:	mov    %rsp,%rdi
  727fe7:	mov    %rdx,%rsi
  727fea:	call   *0x18(%rcx)
  727fed:	movdqa (%rsp),%xmm0
  727ff2:	pcmpeqb -0x6cfffa(%rip),%xmm0        # 58000 <anon.079f5e587c394fcac2765eb4d0cf0bc2.360.llvm.6319143315422321905+0x5c>
  727ffa:	pmovmskb %xmm0,%ecx
  727ffe:	mov    $0x1,%eax
  728003:	cmp    $0xffff,%ecx
  728009:	jne    728045 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x75>
  72800b:	mov    %r15,%rdi
  72800e:	call   *0x18(%r14)
  728012:	mov    %rax,%r12
  728015:	mov    %r15,%rdi
  728018:	call   *0x20(%r14)
  72801c:	cmp    %rax,%r12
  72801f:	je     72802f <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x5f>
  728021:	mov    (%r14),%rax
  728024:	mov    %rax,0x8(%rbx)
  728028:	mov    $0xa,%eax
  72802d:	jmp    728045 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x75>
  72802f:	mov    0x4(%rax),%ecx
  728032:	cmp    $0xffffffff,%ecx
  728035:	je     728057 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x87>
  728037:	inc    %ecx
  728039:	mov    %ecx,0x4(%rax)
  72803c:	incl   (%rax)
  72803e:	mov    $0xffffffffffffffff,%rax
  728045:	mov    %rax,(%rbx)
  728048:	mov    %rbx,%rax
  72804b:	add    $0x18,%rsp
  72804f:	pop    %rbx
  728050:	pop    %r12
  728052:	pop    %r14
  728054:	pop    %r15
  728056:	ret
  728057:	lea    -0x6ca9df(%rip),%rdi        # 5d67f <anon.4d76bc73d2ecf6d7439404264a8f75e0.68.llvm.16741567646709100845>
  72805e:	lea    0x353633(%rip),%rdx        # a7b698 <anon.4d76bc73d2ecf6d7439404264a8f75e0.70.llvm.16741567646709100845>
  728065:	mov    $0x19,%esi
  72806a:	call   *0x37b3e0(%rip)        # aa3450 <_DYNAMIC+0x2b0>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000728090 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve>:
  728090:	push   %rbp
  728091:	push   %r15
  728093:	push   %r14
  728095:	push   %r13
  728097:	push   %r12
  728099:	push   %rbx
  72809a:	sub    $0x28,%rsp
  72809e:	mov    %rcx,%r13
  7280a1:	mov    %rdx,%r12
  7280a4:	mov    %rdi,%rbx
  7280a7:	mov    (%rsi),%r14
  7280aa:	mov    %rdx,%rdi
  7280ad:	call   *0x18(%rsi)
  7280b0:	mov    %rax,0x8(%rsp)
  7280b5:	cmp    $0x1,%r14d
  7280b9:	jne    728107 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x77>
  7280bb:	mov    0x20(%r13),%rbp
  7280bf:	mov    0x28(%r13),%r15
  7280c3:	shl    $0x4,%r15
  7280c7:	xor    %r13d,%r13d
  7280ca:	nopw   0x0(%rax,%rax,1)
  7280d0:	cmp    %r13,%r15
  7280d3:	je     728191 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x101>
  7280d9:	mov    0x0(%rbp,%r13,1),%rdi
  7280de:	mov    0x8(%rbp,%r13,1),%rax
  7280e3:	call   *0x18(%rax)
  7280e6:	add    $0x10,%r13
  7280ea:	cmp    %r14,%rax
  7280ed:	jne    7280d0 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x40>
  7280ef:	mov    -0x10(%rbp,%r13,1),%rdi
  7280f4:	mov    -0x8(%rbp,%r13,1),%rax
  7280f9:	mov    %r12,%rsi
  7280fc:	call   *0x28(%rax)
  7280ff:	mov    %rax,%rdi
  728102:	mov    %rdx,%rax
  728105:	jmp    72816a <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0xda>
  728107:	mov    0x50(%r13),%rbp
  72810b:	mov    0x58(%r13),%r13
  72810f:	shl    $0x4,%r13
  728113:	xor    %r15d,%r15d
  728116:	cs nopw 0x0(%rax,%rax,1)
  728120:	cmp    %r15,%r13
  728123:	je     728191 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x101>
  728125:	mov    0x0(%rbp,%r15,1),%rdi
  72812a:	mov    0x8(%rbp,%r15,1),%rax
  72812f:	mov    %r14,%rsi
  728132:	call   *0x30(%rax)
  728135:	add    $0x10,%r15
  728139:	test   %al,%al
  72813b:	je     728120 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x90>
  72813d:	mov    -0x10(%rbp,%r15,1),%rsi
  728142:	mov    -0x8(%rbp,%r15,1),%rax
  728147:	lea    0x10(%rsp),%rdi
  72814c:	mov    %r12,%rdx
  72814f:	mov    %r14,%rcx
  728152:	call   *0x58(%rax)
  728155:	mov    0x10(%rsp),%rcx
  72815a:	mov    0x18(%rsp),%rdi
  72815f:	mov    0x20(%rsp),%rax
  728164:	cmp    $0xffffffffffffffff,%rcx
  728168:	jne    728199 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x109>
  72816a:	lea    0x352db7(%rip),%rdx        # a7af28 <anon.daf501629c8031209a3f8e92524845e0.13.llvm.9161303705346218040+0xd8>
  728171:	mov    0x8(%rsp),%r15
  728176:	mov    %r15,%rsi
  728179:	call   *0x20(%rax)
  72817c:	test   %al,%al
  72817e:	je     72819e <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x10e>
  728180:	mov    %r14,0x8(%rbx)
  728184:	mov    %r15,0x10(%rbx)
  728188:	movq   $0xffffffffffffffff,(%rbx)
  72818f:	jmp    7281ae <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x11e>
  728191:	mov    $0xb,%ecx
  728196:	mov    %r14,%rdi
  728199:	mov    %rdi,%r14
  72819c:	jmp    7281a3 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x113>
  72819e:	mov    $0xa,%ecx
  7281a3:	mov    %rcx,(%rbx)
  7281a6:	mov    %r14,0x8(%rbx)
  7281aa:	mov    %rax,0x10(%rbx)
  7281ae:	mov    %rbx,%rax
  7281b1:	add    $0x28,%rsp
  7281b5:	pop    %rbx
  7281b6:	pop    %r12
  7281b8:	pop    %r13
  7281ba:	pop    %r14
  7281bc:	pop    %r15
  7281be:	pop    %rbp
  7281bf:	ret


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072c4c0 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  72c4c0:	push   %rbx
  72c4c1:	sub    $0x40,%rsp
  72c4c5:	mov    0x110(%rdi),%rbx
  72c4cc:	test   %rbx,%rbx
  72c4cf:	je     72c576 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xb6>
  72c4d5:	cmpb   $0x0,0x756(%rbx)
  72c4dc:	jne    72c57d <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xbd>
  72c4e2:	mov    $0x12,%eax
  72c4e7:	cmpb   $0x1,0x752(%rbx)
  72c4ee:	jne    72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c4f4:	cmpb   $0x0,0x753(%rbx)
  72c4fb:	jne    72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c501:	cmpb   $0x0,0x754(%rbx)
  72c508:	je     72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c50a:	cmpq   $0xffffffffffffffff,0x5c0(%rbx)
  72c512:	jne    72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c514:	mov    0x698(%rbx),%rcx
  72c51b:	cmp    0x6a0(%rbx),%rcx
  72c522:	jne    72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c524:	mov    0x6b0(%rbx),%rcx
  72c52b:	cmp    0x6a8(%rbx),%rcx
  72c532:	jne    72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c534:	movss  0x748(%rbx),%xmm2
  72c53c:	ucomiss 0x74c(%rbx),%xmm2
  72c543:	jne    72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c545:	jp     72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c547:	mov    %rbx,%rdi
  72c54a:	call   709df0 <<gpui::runtime::Runtime<owner_source_control::Model>>::hit>
  72c54f:	cmp    $0x1,%rax
  72c553:	jne    72c56e <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xae>
  72c555:	add    $0x5e8,%rbx
  72c55c:	mov    %rbx,%rdi
  72c55f:	mov    %rdx,%rsi
  72c562:	call   *0x376fe0(%rip)        # aa3548 <_DYNAMIC+0x3a8>
  72c568:	add    $0x40,%rsp
  72c56c:	pop    %rbx
  72c56d:	ret
  72c56e:	xor    %eax,%eax
  72c570:	add    $0x40,%rsp
  72c574:	pop    %rbx
  72c575:	ret
  72c576:	mov    $0xd,%eax
  72c57b:	jmp    72c582 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72c57d:	mov    $0xe,%eax
  72c582:	mov    %rax,0x8(%rsp)
  72c587:	lea    -0x6cef96(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  72c58e:	lea    0x34ef83(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  72c595:	lea    0x34ecfc(%rip),%r8        # a7b298 <anon.2c5f4fb4c1947b150052a90f1fdbb632.12.llvm.15417562268823727740+0xc8>
  72c59c:	lea    0x8(%rsp),%rdx
  72c5a1:	mov    $0x2b,%esi
  72c5a6:	call   *0x376f8c(%rip)        # aa3538 <_DYNAMIC+0x398>
  72c5ac:	ud2
  72c5ae:	mov    %rax,%rbx
  72c5b1:	lea    0x8(%rsp),%rdi
  72c5b6:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72c5bb:	mov    %rbx,%rdi
  72c5be:	call   a78270 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072c5d0 <owner_source_control::source_set::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  72c5d0:	push   %rbx
  72c5d1:	sub    $0xd0,%rsp
  72c5d8:	mov    %esi,%ecx
  72c5da:	mov    %rdi,%rsi
  72c5dd:	mov    0x34ecec(%rip),%rax        # a7b2d0 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x20>
  72c5e4:	mov    %rax,0x20(%rsp)
  72c5e9:	movups 0x34ecd0(%rip),%xmm0        # a7b2c0 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x10>
  72c5f0:	movaps %xmm0,0x10(%rsp)
  72c5f5:	movups 0x34ecb4(%rip),%xmm0        # a7b2b0 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845>
  72c5fc:	movaps %xmm0,(%rsp)
  72c600:	lea    0x68(%rsp),%rdi
  72c605:	mov    %rsp,%rdx
  72c608:	call   6e8d30 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>>
  72c60d:	cmpl   $0xffffffff,0x68(%rsp)
  72c612:	jne    72c61d <owner_source_control::source_set::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x4d>
  72c614:	add    $0xd0,%rsp
  72c61b:	pop    %rbx
  72c61c:	ret
  72c61d:	mov    0xc8(%rsp),%rax
  72c625:	mov    %rax,0x60(%rsp)
  72c62a:	movups 0xb8(%rsp),%xmm0
  72c632:	movaps %xmm0,0x50(%rsp)
  72c637:	movups 0xa8(%rsp),%xmm0
  72c63f:	movaps %xmm0,0x40(%rsp)
  72c644:	movups 0x68(%rsp),%xmm0
  72c649:	movups 0x78(%rsp),%xmm1
  72c64e:	movups 0x88(%rsp),%xmm2
  72c656:	movups 0x98(%rsp),%xmm3
  72c65e:	movaps %xmm3,0x30(%rsp)
  72c663:	movaps %xmm2,0x20(%rsp)
  72c668:	movaps %xmm1,0x10(%rsp)
  72c66d:	movaps %xmm0,(%rsp)
  72c671:	lea    -0x6cf080(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  72c678:	lea    0x34eed9(%rip),%rcx        # a7b558 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x2a8>
  72c67f:	lea    0x34ec52(%rip),%r8        # a7b2d8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x28>
  72c686:	mov    %rsp,%rdx
  72c689:	mov    $0x2b,%esi
  72c68e:	call   *0x376ea4(%rip)        # aa3538 <_DYNAMIC+0x398>
  72c694:	ud2
  72c696:	mov    %rax,%rbx
  72c699:	cmpq   $0x2,(%rsp)
  72c69e:	lea    0x30(%rsp),%rax
  72c6a3:	lea    0x8(%rsp),%rdi
  72c6a8:	cmovb  %rax,%rdi
  72c6ac:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72c6b1:	mov    %rbx,%rdi
  72c6b4:	call   a78270 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072c6c0 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  72c6c0:	push   %rbx
  72c6c1:	sub    $0x40,%rsp
  72c6c5:	mov    0x110(%rsi),%rsi
  72c6cc:	test   %rsi,%rsi
  72c6cf:	je     72c735 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x75>
  72c6d1:	cmpb   $0x0,0x756(%rsi)
  72c6d8:	jne    72c73c <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x7c>
  72c6da:	cmpb   $0x1,0x754(%rsi)
  72c6e1:	jne    72c743 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x83>
  72c6e3:	mov    $0x11,%eax
  72c6e8:	cmp    0x5e8(%rsi),%rdx
  72c6ef:	jne    72c748 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  72c6f1:	mov    0x5b0(%rsi),%rdx
  72c6f8:	mov    0x5b8(%rsi),%rsi
  72c6ff:	shl    $0x6,%rsi
  72c703:	xor    %r8d,%r8d
  72c706:	mov    %rdx,%r9
  72c709:	nopl   0x0(%rax)
  72c710:	cmp    %r8,%rsi
  72c713:	je     72c748 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  72c715:	add    $0x40,%r8
  72c719:	cmp    %rcx,0x20(%r9)
  72c71d:	lea    0x40(%r9),%r9
  72c721:	jne    72c710 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x50>
  72c723:	movups -0x30(%rdx,%r8,1),%xmm0
  72c729:	movups %xmm0,(%rdi)
  72c72c:	mov    %rdi,%rax
  72c72f:	add    $0x40,%rsp
  72c733:	pop    %rbx
  72c734:	ret
  72c735:	mov    $0xd,%eax
  72c73a:	jmp    72c748 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  72c73c:	mov    $0xe,%eax
  72c741:	jmp    72c748 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  72c743:	mov    $0x12,%eax
  72c748:	mov    %rax,0x8(%rsp)
  72c74d:	lea    -0x6cf15c(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  72c754:	lea    0x34edbd(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  72c75b:	lea    0x34eb8e(%rip),%r8        # a7b2f0 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x40>
  72c762:	lea    0x8(%rsp),%rdx
  72c767:	mov    $0x2b,%esi
  72c76c:	call   *0x376dc6(%rip)        # aa3538 <_DYNAMIC+0x398>
  72c772:	ud2
  72c774:	mov    %rax,%rbx
  72c777:	lea    0x8(%rsp),%rdi
  72c77c:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72c781:	mov    %rbx,%rdi
  72c784:	call   a78270 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072c790 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  72c790:	push   %r15
  72c792:	push   %r14
  72c794:	push   %rbx
  72c795:	sub    $0x70,%rsp
  72c799:	mov    %rdi,%rbx
  72c79c:	mov    0x110(%rdi),%r15
  72c7a3:	test   %r15,%r15
  72c7a6:	je     72c7f2 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x62>
  72c7a8:	mov    %rdx,%rcx
  72c7ab:	mov    %rsi,%rdx
  72c7ae:	mov    %r15,(%rsp)
  72c7b2:	mov    %rbx,0x8(%rsp)
  72c7b7:	lea    0x38(%rsp),%rdi
  72c7bc:	mov    %rsp,%rsi
  72c7bf:	call   6f2f00 <<gpui::runtime::RuntimeMut<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::activate>
  72c7c4:	cmpb   $0x0,0x756(%r15)
  72c7cc:	jne    72c7d8 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x48>
  72c7ce:	cmpq   $0xffffffffffffffff,0x698(%r15)
  72c7d6:	jne    72c7e0 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x50>
  72c7d8:	mov    %rbx,%rdi
  72c7db:	call   736370 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  72c7e0:	cmpq   $0xfffffffffffffffe,0x38(%rsp)
  72c7e6:	jne    72c809 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x79>
  72c7e8:	add    $0x70,%rsp
  72c7ec:	pop    %rbx
  72c7ed:	pop    %r14
  72c7ef:	pop    %r15
  72c7f1:	ret
  72c7f2:	movq   $0xd,0x38(%rsp)
  72c7fb:	movq   $0x0,0x40(%rsp)
  72c804:	mov    %rbx,0x48(%rsp)
  72c809:	mov    0x68(%rsp),%rax
  72c80e:	mov    %rax,0x30(%rsp)
  72c813:	mov    0x38(%rsp),%rax
  72c818:	mov    0x40(%rsp),%rcx
  72c81d:	mov    0x48(%rsp),%rdx
  72c822:	mov    0x50(%rsp),%rsi
  72c827:	movups 0x58(%rsp),%xmm0
  72c82c:	movaps %xmm0,0x20(%rsp)
  72c831:	mov    %rdx,0x10(%rsp)
  72c836:	mov    %rsi,0x18(%rsp)
  72c83b:	mov    %rax,(%rsp)
  72c83f:	mov    %rcx,0x8(%rsp)
  72c844:	lea    -0x6cf253(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  72c84b:	lea    0x34ecc6(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  72c852:	lea    0x34eaaf(%rip),%r8        # a7b308 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x58>
  72c859:	mov    %rsp,%rdx
  72c85c:	mov    $0x2b,%esi
  72c861:	call   *0x376cd1(%rip)        # aa3538 <_DYNAMIC+0x398>
  72c867:	ud2
  72c869:	mov    %rax,%r14
  72c86c:	cmpb   $0x0,0x756(%r15)
  72c874:	jne    72c880 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xf0>
  72c876:	cmpq   $0xffffffffffffffff,0x698(%r15)
  72c87e:	jne    72c888 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xf8>
  72c880:	mov    %rbx,%rdi
  72c883:	call   736370 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  72c888:	mov    %r14,%rdi
  72c88b:	call   a78270 <_Unwind_Resume@plt>
  72c890:	call   *0x376ba2(%rip)        # aa3438 <_DYNAMIC+0x298>
  72c896:	mov    %rax,%r14
  72c899:	mov    %rsp,%rdi
  72c89c:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72c8a1:	mov    %r14,%rdi
  72c8a4:	call   a78270 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072c8b0 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  72c8b0:	push   %r14
  72c8b2:	push   %rbx
  72c8b3:	sub    $0x98,%rsp
  72c8ba:	mov    %rdi,%rbx
  72c8bd:	mov    $0xffffffff,%eax
  72c8c2:	mov    %rax,0x78(%rsp)
  72c8c7:	movq   $0x0,0x80(%rsp)
  72c8d3:	movss  %xmm0,0x4(%rsp)
  72c8d9:	movss  %xmm1,0x8(%rsp)
  72c8df:	movl   $0x0,(%rsp)
  72c8e6:	lea    0x40(%rsp),%rdi
  72c8eb:	lea    0x78(%rsp),%rdx
  72c8f0:	mov    %rsp,%rcx
  72c8f3:	mov    %rbx,%rsi
  72c8f6:	call   6f4fd0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  72c8fb:	cmpl   $0xfffffffe,0x40(%rsp)
  72c900:	jne    72c95b <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xab>
  72c902:	movl   $0x2,(%rsp)
  72c909:	lea    0x40(%rsp),%rdi
  72c90e:	lea    0x78(%rsp),%rdx
  72c913:	mov    %rsp,%rcx
  72c916:	mov    %rbx,%rsi
  72c919:	call   6f4fd0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  72c91e:	cmpl   $0xfffffffe,0x40(%rsp)
  72c923:	jne    72c9ad <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xfd>
  72c929:	movl   $0x3,(%rsp)
  72c930:	lea    0x40(%rsp),%rdi
  72c935:	lea    0x78(%rsp),%rdx
  72c93a:	mov    %rsp,%rcx
  72c93d:	mov    %rbx,%rsi
  72c940:	call   6f4fd0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  72c945:	cmpl   $0xfffffffe,0x40(%rsp)
  72c94a:	jne    72c9fc <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x14c>
  72c950:	add    $0x98,%rsp
  72c957:	pop    %rbx
  72c958:	pop    %r14
  72c95a:	ret
  72c95b:	mov    0x70(%rsp),%rax
  72c960:	mov    %rax,0x30(%rsp)
  72c965:	movups 0x40(%rsp),%xmm0
  72c96a:	movups 0x50(%rsp),%xmm1
  72c96f:	movups 0x60(%rsp),%xmm2
  72c974:	movaps %xmm2,0x20(%rsp)
  72c979:	movaps %xmm1,0x10(%rsp)
  72c97e:	movaps %xmm0,(%rsp)
  72c982:	lea    -0x6cf391(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  72c989:	lea    0x34eb88(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  72c990:	lea    0x34e989(%rip),%r8        # a7b320 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x70>
  72c997:	mov    %rsp,%rbx
  72c99a:	mov    $0x2b,%esi
  72c99f:	mov    %rbx,%rdx
  72c9a2:	call   *0x376b90(%rip)        # aa3538 <_DYNAMIC+0x398>
  72c9a8:	jmp    72ca49 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x199>
  72c9ad:	mov    0x70(%rsp),%rax
  72c9b2:	mov    %rax,0x30(%rsp)
  72c9b7:	movups 0x40(%rsp),%xmm0
  72c9bc:	movups 0x50(%rsp),%xmm1
  72c9c1:	movups 0x60(%rsp),%xmm2
  72c9c6:	movaps %xmm2,0x20(%rsp)
  72c9cb:	movaps %xmm1,0x10(%rsp)
  72c9d0:	movaps %xmm0,(%rsp)
  72c9d4:	lea    -0x6cf3e3(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  72c9db:	lea    0x34eb36(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  72c9e2:	lea    0x34e94f(%rip),%r8        # a7b338 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x88>
  72c9e9:	mov    %rsp,%rbx
  72c9ec:	mov    $0x2b,%esi
  72c9f1:	mov    %rbx,%rdx
  72c9f4:	call   *0x376b3e(%rip)        # aa3538 <_DYNAMIC+0x398>
  72c9fa:	jmp    72ca49 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x199>
  72c9fc:	mov    0x70(%rsp),%rax
  72ca01:	mov    %rax,0x30(%rsp)
  72ca06:	movups 0x40(%rsp),%xmm0
  72ca0b:	movups 0x50(%rsp),%xmm1
  72ca10:	movups 0x60(%rsp),%xmm2
  72ca15:	movaps %xmm2,0x20(%rsp)
  72ca1a:	movaps %xmm1,0x10(%rsp)
  72ca1f:	movaps %xmm0,(%rsp)
  72ca23:	lea    -0x6cf432(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  72ca2a:	lea    0x34eae7(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  72ca31:	lea    0x34e918(%rip),%r8        # a7b350 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0xa0>
  72ca38:	mov    %rsp,%rbx
  72ca3b:	mov    $0x2b,%esi
  72ca40:	mov    %rbx,%rdx
  72ca43:	call   *0x376aef(%rip)        # aa3538 <_DYNAMIC+0x398>
  72ca49:	ud2
  72ca4b:	jmp    72ca4f <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x19f>
  72ca4d:	jmp    72ca4f <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x19f>
  72ca4f:	mov    %rax,%r14
  72ca52:	mov    %rbx,%rdi
  72ca55:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72ca5a:	mov    %r14,%rdi
  72ca5d:	call   a78270 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072ca70 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  72ca70:	push   %rbx
  72ca71:	sub    $0x100,%rsp
  72ca78:	mov    %rdi,%rbx
  72ca7b:	mov    %rsp,%rdi
  72ca7e:	mov    $0x8,%edx
  72ca83:	mov    %rbx,%rsi
  72ca86:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  72ca8b:	cmpl   $0xffffffff,(%rsp)
  72ca8f:	jne    72cb8c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  72ca95:	testb  $0x1,0x48(%rsp)
  72ca9a:	je     72cb83 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  72caa0:	mov    %rsp,%rdi
  72caa3:	mov    $0x8,%edx
  72caa8:	mov    %rbx,%rsi
  72caab:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  72cab0:	cmpl   $0xffffffff,(%rsp)
  72cab4:	jne    72cb8c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  72caba:	cmpb   $0x1,0x48(%rsp)
  72cabf:	jne    72cb83 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  72cac5:	mov    %rsp,%rdi
  72cac8:	mov    $0x8,%edx
  72cacd:	mov    %rbx,%rsi
  72cad0:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  72cad5:	cmpl   $0xffffffff,(%rsp)
  72cad9:	jne    72cb8c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  72cadf:	cmpb   $0x1,0x48(%rsp)
  72cae4:	jne    72cb83 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  72caea:	mov    %rsp,%rdi
  72caed:	mov    $0x8,%edx
  72caf2:	mov    %rbx,%rsi
  72caf5:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  72cafa:	cmpl   $0xffffffff,(%rsp)
  72cafe:	jne    72cb8c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  72cb04:	cmpb   $0x1,0x48(%rsp)
  72cb09:	jne    72cb83 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  72cb0b:	mov    %rsp,%rdi
  72cb0e:	mov    $0x8,%edx
  72cb13:	mov    %rbx,%rsi
  72cb16:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  72cb1b:	cmpl   $0xffffffff,(%rsp)
  72cb1f:	jne    72cb8c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  72cb21:	cmpb   $0x1,0x48(%rsp)
  72cb26:	jne    72cb83 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  72cb28:	mov    %rsp,%rdi
  72cb2b:	mov    $0x8,%edx
  72cb30:	mov    %rbx,%rsi
  72cb33:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  72cb38:	cmpl   $0xffffffff,(%rsp)
  72cb3c:	jne    72cb8c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  72cb3e:	cmpb   $0x1,0x48(%rsp)
  72cb43:	jne    72cb83 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  72cb45:	mov    %rsp,%rdi
  72cb48:	mov    $0x8,%edx
  72cb4d:	mov    %rbx,%rsi
  72cb50:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  72cb55:	cmpl   $0xffffffff,(%rsp)
  72cb59:	jne    72cb8c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  72cb5b:	cmpb   $0x1,0x48(%rsp)
  72cb60:	jne    72cb83 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  72cb62:	mov    %rsp,%rdi
  72cb65:	mov    $0x8,%edx
  72cb6a:	mov    %rbx,%rsi
  72cb6d:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  72cb72:	cmpl   $0xffffffff,(%rsp)
  72cb76:	jne    72cb8c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  72cb78:	cmpb   $0x1,0x48(%rsp)
  72cb7d:	je     72cc1d <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x1ad>
  72cb83:	add    $0x100,%rsp
  72cb8a:	pop    %rbx
  72cb8b:	ret
  72cb8c:	movups 0x70(%rsp),%xmm0
  72cb91:	movaps %xmm0,0xf0(%rsp)
  72cb99:	movups 0x60(%rsp),%xmm0
  72cb9e:	movaps %xmm0,0xe0(%rsp)
  72cba6:	movups 0x50(%rsp),%xmm0
  72cbab:	movaps %xmm0,0xd0(%rsp)
  72cbb3:	movups 0x40(%rsp),%xmm0
  72cbb8:	movaps %xmm0,0xc0(%rsp)
  72cbc0:	movups (%rsp),%xmm0
  72cbc4:	movups 0x10(%rsp),%xmm1
  72cbc9:	movups 0x20(%rsp),%xmm2
  72cbce:	movups 0x30(%rsp),%xmm3
  72cbd3:	movaps %xmm3,0xb0(%rsp)
  72cbdb:	movaps %xmm2,0xa0(%rsp)
  72cbe3:	movaps %xmm1,0x90(%rsp)
  72cbeb:	movaps %xmm0,0x80(%rsp)
  72cbf3:	lea    -0x6cf602(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  72cbfa:	lea    0x34e937(%rip),%rcx        # a7b538 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x288>
  72cc01:	lea    0x34e778(%rip),%r8        # a7b380 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0xd0>
  72cc08:	lea    0x80(%rsp),%rdx
  72cc10:	mov    $0x2b,%esi
  72cc15:	call   *0x37691d(%rip)        # aa3538 <_DYNAMIC+0x398>
  72cc1b:	ud2
  72cc1d:	lea    -0x6cf78f(%rip),%rdi        # 5d495 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x5>
  72cc24:	lea    0x34e73d(%rip),%rdx        # a7b368 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0xb8>
  72cc2b:	mov    $0x7b,%esi
  72cc30:	call   *0x37680a(%rip)        # aa3440 <_DYNAMIC+0x2a0>
  72cc36:	mov    %rax,%rbx
  72cc39:	lea    0xc8(%rsp),%rdi
  72cc41:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72cc46:	mov    %rbx,%rdi
  72cc49:	call   a78270 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000730b00 <owner_source_control::main>:
  730b00:	push   %rbp
  730b01:	push   %r15
  730b03:	push   %r14
  730b05:	push   %r13
  730b07:	push   %r12
  730b09:	push   %rbx
  730b0a:	sub    $0x3e8,%rsp
  730b11:	movq   $0x2,0x2b0(%rsp)
  730b1d:	lea    0x250(%rsp),%rdi
  730b25:	lea    0x2b0(%rsp),%rsi
  730b2d:	call   718860 <allocation_counter::measure::<owner_source_control::main::{closure#0}>>
  730b32:	mov    0x2b0(%rsp),%rbx
  730b3a:	cmp    $0x2,%rbx
  730b3e:	je     730f46 <owner_source_control::main+0x446>
  730b44:	mov    0x3c8(%rsp),%r14
  730b4c:	mov    0x3d0(%rsp),%r15
  730b54:	lea    0x2b8(%rsp),%rsi
  730b5c:	mov    0x3d8(%rsp),%r12
  730b64:	mov    0x3e0(%rsp),%r13
  730b6c:	lea    0x140(%rsp),%rdi
  730b74:	mov    $0x110,%edx
  730b79:	call   *0x372891(%rip)        # aa3410 <memcpy@GLIBC_2.14>
  730b7f:	mov    %rbx,0x138(%rsp)
  730b87:	mov    %r12,0xd8(%rsp)
  730b8f:	mov    %r13,0xe0(%rsp)
  730b97:	lea    0x138(%rsp),%rdi
  730b9f:	call   72ca70 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>
  730ba4:	lea    -0x6d8e1b(%rip),%rcx        # 57d90 <anon.079f5e587c394fcac2765eb4d0cf0bc2.312.llvm.6319143315422321905+0x58>
  730bab:	lea    0x90(%rsp),%rdi
  730bb3:	lea    0x138(%rsp),%rbx
  730bbb:	mov    $0x4,%r8d
  730bc1:	mov    %rbx,%rsi
  730bc4:	mov    $0x5,%edx
  730bc9:	call   6fbac0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::find>
  730bce:	cmpl   $0xfffffffe,0x90(%rsp)
  730bd6:	jne    730f53 <owner_source_control::main+0x453>
  730bdc:	movups 0x98(%rsp),%xmm0
  730be4:	movaps %xmm0,0x120(%rsp)
  730bec:	mov    0x248(%rsp),%rax
  730bf4:	test   %rax,%rax
  730bf7:	je     731065 <owner_source_control::main+0x565>
  730bfd:	xorps  %xmm0,%xmm0
  730c00:	movups %xmm0,0x728(%rax)
  730c07:	movups %xmm0,0x718(%rax)
  730c0e:	movups %xmm0,0x708(%rax)
  730c15:	movups %xmm0,0x6f8(%rax)
  730c1c:	movups %xmm0,0x6e8(%rax)
  730c23:	movups %xmm0,0x6d8(%rax)
  730c2a:	movq   $0x0,0x738(%rax)
  730c35:	cmpb   $0x0,0x756(%rax)
  730c3c:	jne    730c48 <owner_source_control::main+0x148>
  730c3e:	cmpq   $0xffffffffffffffff,0x698(%rax)
  730c46:	jne    730c55 <owner_source_control::main+0x155>
  730c48:	lea    0x138(%rsp),%rdi
  730c50:	call   736370 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  730c55:	lea    0x280(%rsp),%rdi
  730c5d:	lea    0x138(%rsp),%rsi
  730c65:	lea    0x120(%rsp),%rdx
  730c6d:	call   718b20 <allocation_counter::measure::<owner_source_control::main::{closure#1}>>
  730c72:	mov    0x248(%rsp),%rbx
  730c7a:	test   %rbx,%rbx
  730c7d:	je     730fae <owner_source_control::main+0x4ae>
  730c83:	cmpl   $0x2b,0x2c0(%rbx)
  730c8a:	jne    730fde <owner_source_control::main+0x4de>
  730c90:	movq   $0x0,(%rsp)
  730c98:	movq   $0x0,0x10(%rsp)
  730ca1:	movq   $0x0,0x20(%rsp)
  730caa:	mov    %rbx,0x30(%rsp)
  730caf:	lea    -0x6d3753(%rip),%rax        # 5d563 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0xd3>
  730cb6:	mov    %rax,0x38(%rsp)
  730cbb:	movq   $0x2,0x40(%rsp)
  730cc4:	movb   $0x1,0x48(%rsp)
  730cc9:	movb   $0xff,0x50(%rsp)
  730cce:	lea    0x90(%rsp),%rbp
  730cd6:	mov    %rsp,%rsi
  730cd9:	mov    %rbp,%rdi
  730cdc:	call   723bb0 <<gpui::runtime::query::Query<owner_source_control::Model>>::count>
  730ce1:	mov    0x90(%rsp),%rcx
  730ce9:	mov    0x98(%rsp),%rax
  730cf1:	cmp    $0xfffffffffffffffe,%rcx
  730cf5:	jne    7310a3 <owner_source_control::main+0x5a3>
  730cfb:	test   %rax,%rax
  730cfe:	je     730ff5 <owner_source_control::main+0x4f5>
  730d04:	mov    0x248(%rsp),%rax
  730d0c:	mov    $0x2,%r13b
  730d0f:	test   %rax,%rax
  730d12:	je     731110 <owner_source_control::main+0x610>
  730d18:	cmpb   $0x0,0x756(%rax)
  730d1f:	jne    731117 <owner_source_control::main+0x617>
  730d25:	mov    %rsp,%rbx
  730d28:	lea    0x138(%rsp),%r12
  730d30:	mov    %rbx,%rdi
  730d33:	mov    %r12,%rsi
  730d36:	mov    %r14,%rdx
  730d39:	mov    %r15,%rcx
  730d3c:	call   735660 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::reader::ReaderValues>::read>
  730d41:	cmpl   $0x2,(%rsp)
  730d45:	je     73111e <owner_source_control::main+0x61e>
  730d4b:	mov    0x18(%rsp),%rcx
  730d50:	movzbl 0x20(%rsp),%r13d
  730d56:	mov    0x21(%rsp),%rax
  730d5b:	mov    %rax,0xe8(%rsp)
  730d63:	mov    0x28(%rsp),%rax
  730d68:	mov    %rax,0xef(%rsp)
  730d70:	mov    0x30(%rsp),%eax
  730d74:	movups 0x34(%rsp),%xmm0
  730d79:	movaps %xmm0,0x90(%rsp)
  730d81:	movups 0x44(%rsp),%xmm0
  730d86:	movaps %xmm0,0xa0(%rsp)
  730d8e:	movups 0x54(%rsp),%xmm0
  730d93:	movaps %xmm0,0xb0(%rsp)
  730d9b:	movups 0x61(%rsp),%xmm0
  730da0:	movups %xmm0,0xbd(%rsp)
  730da8:	cmpb   $0x2,0x71(%rsp)
  730dad:	je     731123 <owner_source_control::main+0x623>
  730db3:	test   %rcx,%rcx
  730db6:	je     731013 <owner_source_control::main+0x513>
  730dbc:	mov    %rcx,0x90(%rsp)
  730dc4:	movabs $0x100000001,%rdx
  730dce:	mov    %rdx,(%rsp)
  730dd2:	cmp    %rdx,%rcx
  730dd5:	jne    731025 <owner_source_control::main+0x525>
  730ddb:	mov    %eax,(%rsp)
  730dde:	cmp    $0x3,%eax
  730de1:	jne    731045 <owner_source_control::main+0x545>
  730de7:	lea    0x250(%rsp),%rax
  730def:	mov    %rax,(%rsp)
  730df3:	lea    0xad6(%rip),%rbx        # 7318d0 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  730dfa:	mov    %rbx,0x8(%rsp)
  730dff:	lea    -0x6e191c(%rip),%rdi        # 4f4ea <anon.4fc0b732051cd9c0c5e7a6e9d819518c.14.llvm.5251204661969696906+0xb0>
  730e06:	mov    %rsp,%rsi
  730e09:	call   *0x372cc1(%rip)        # aa3ad0 <_DYNAMIC+0x930>
  730e0f:	lea    0x280(%rsp),%rax
  730e17:	mov    %rax,(%rsp)
  730e1b:	mov    %rbx,0x8(%rsp)
  730e20:	lea    -0x6db984(%rip),%rdi        # 554a3 <anon.96bf6b34351ddc2adfd2386f8abf053b.13.llvm.9730795237915355246+0x1ec>
  730e27:	mov    %rsp,%rsi
  730e2a:	call   *0x372ca0(%rip)        # aa3ad0 <_DYNAMIC+0x930>
  730e30:	movq   $0x118,0x90(%rsp)
  730e3c:	lea    0xd8(%rsp),%rax
  730e44:	mov    %rax,(%rsp)
  730e48:	mov    0x372b69(%rip),%rax        # aa39b8 <_DYNAMIC+0x818>
  730e4f:	mov    %rax,0x8(%rsp)
  730e54:	lea    0xe0(%rsp),%rcx
  730e5c:	mov    %rcx,0x10(%rsp)
  730e61:	mov    %rax,0x18(%rsp)
  730e66:	mov    %rbp,0x20(%rsp)
  730e6b:	mov    %rax,0x28(%rsp)
  730e70:	lea    -0x6dfa50(%rip),%rdi        # 51427 <anon.7d84123d9385acd73700c435ae62cea9.21.llvm.12732996019173906566+0x92>
  730e77:	mov    %rsp,%rbx
  730e7a:	mov    %rbx,%rsi
  730e7d:	call   *0x372c4d(%rip)        # aa3ad0 <_DYNAMIC+0x930>
  730e83:	mov    0x248(%rsp),%rax
  730e8b:	test   %rax,%rax
  730e8e:	je     731189 <owner_source_control::main+0x689>
  730e94:	mov    0x738(%rax),%rcx
  730e9b:	mov    %rcx,0x60(%rsp)
  730ea0:	movups 0x728(%rax),%xmm0
  730ea7:	movaps %xmm0,0x50(%rsp)
  730eac:	movups 0x718(%rax),%xmm0
  730eb3:	movaps %xmm0,0x40(%rsp)
  730eb8:	movups 0x6d8(%rax),%xmm0
  730ebf:	movups 0x6e8(%rax),%xmm1
  730ec6:	movups 0x6f8(%rax),%xmm2
  730ecd:	movups 0x708(%rax),%xmm3
  730ed4:	movaps %xmm3,0x30(%rsp)
  730ed9:	movaps %xmm2,0x20(%rsp)
  730ede:	movaps %xmm1,0x10(%rsp)
  730ee3:	movaps %xmm0,(%rsp)
  730ee7:	mov    %rbx,0x90(%rsp)
  730eef:	lea    0xf7a(%rip),%rax        # 731e70 <<gpui::runtime::Counters as core::fmt::Debug>::fmt>
  730ef6:	mov    %rax,0x98(%rsp)
  730efe:	lea    -0x6e19fd(%rip),%rdi        # 4f508 <anon.4fc0b732051cd9c0c5e7a6e9d819518c.14.llvm.5251204661969696906+0xce>
  730f05:	lea    0x90(%rsp),%rsi
  730f0d:	call   *0x372bbd(%rip)        # aa3ad0 <_DYNAMIC+0x930>
  730f13:	lea    -0x6d395d(%rip),%rdi        # 5d5bd <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x12d>
  730f1a:	mov    $0x77,%esi
  730f1f:	call   *0x372bab(%rip)        # aa3ad0 <_DYNAMIC+0x930>
  730f25:	mov    %r12,(%rsp)
  730f29:	mov    %rsp,%rax
  730f2c:	mov    %r12,%rdi
  730f2f:	call   72f1d0 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  730f34:	add    $0x3e8,%rsp
  730f3b:	pop    %rbx
  730f3c:	pop    %r12
  730f3e:	pop    %r13
  730f40:	pop    %r14
  730f42:	pop    %r15
  730f44:	pop    %rbp
  730f45:	ret
  730f46:	lea    0x34a47b(%rip),%rdi        # a7b3c8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x118>
  730f4d:	call   *0x3724d5(%rip)        # aa3428 <_DYNAMIC+0x288>
  730f53:	mov    0xc0(%rsp),%rax
  730f5b:	mov    %rax,0x30(%rsp)
  730f60:	movups 0x90(%rsp),%xmm0
  730f68:	movups 0xa0(%rsp),%xmm1
  730f70:	movups 0xb0(%rsp),%xmm2
  730f78:	movaps %xmm2,0x20(%rsp)
  730f7d:	movaps %xmm1,0x10(%rsp)
  730f82:	movaps %xmm0,(%rsp)
  730f86:	lea    -0x6d3a55(%rip),%rdi        # 5d538 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0xa8>
  730f8d:	lea    0x34a584(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  730f94:	lea    0x34a445(%rip),%r8        # a7b3e0 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x130>
  730f9b:	mov    %rsp,%rdx
  730f9e:	mov    $0x2b,%esi
  730fa3:	call   *0x37258f(%rip)        # aa3538 <_DYNAMIC+0x398>
  730fa9:	jmp    7311bd <owner_source_control::main+0x6bd>
  730fae:	movq   $0xd,(%rsp)
  730fb6:	lea    -0x6d39c5(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  730fbd:	lea    0x34a554(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  730fc4:	lea    0x34a445(%rip),%r8        # a7b410 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x160>
  730fcb:	mov    %rsp,%rdx
  730fce:	mov    $0x2b,%esi
  730fd3:	call   *0x37255f(%rip)        # aa3538 <_DYNAMIC+0x398>
  730fd9:	jmp    7311bd <owner_source_control::main+0x6bd>
  730fde:	add    $0x2c0,%rbx
  730fe5:	lea    0x34a4e4(%rip),%r9        # a7b4d0 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x220>
  730fec:	lea    -0x6d9123(%rip),%rdx        # 57ed0 <anon.b9a0c2ab0f2817fcb40a4a41c6d097bf.12.llvm.1156352485375507320+0x3c>
  730ff3:	jmp    731053 <owner_source_control::main+0x553>
  730ff5:	lea    -0x6d3a97(%rip),%rdi        # 5d565 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0xd5>
  730ffc:	lea    0x34a43d(%rip),%rdx        # a7b440 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x190>
  731003:	mov    $0x34,%esi
  731008:	call   *0x372412(%rip)        # aa3420 <_DYNAMIC+0x280>
  73100e:	jmp    7311bd <owner_source_control::main+0x6bd>
  731013:	lea    0x34a456(%rip),%rdi        # a7b470 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x1c0>
  73101a:	call   *0x372408(%rip)        # aa3428 <_DYNAMIC+0x288>
  731020:	jmp    7311bd <owner_source_control::main+0x6bd>
  731025:	lea    0x34a48c(%rip),%r9        # a7b4b8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x208>
  73102c:	lea    0x90(%rsp),%rsi
  731034:	mov    %rsp,%rdx
  731037:	xor    %edi,%edi
  731039:	xor    %ecx,%ecx
  73103b:	call   738a5b <core::panicking::assert_failed::<gpui::source::FieldId, gpui::source::FieldId>>
  731040:	jmp    7311bd <owner_source_control::main+0x6bd>
  731045:	lea    0x34a454(%rip),%r9        # a7b4a0 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x1f0>
  73104c:	lea    -0x6d9237(%rip),%rdx        # 57e1c <anon.305d07fa6d8a71cc44514f8a1dc6c220.98.llvm.16405730940860663774+0x18>
  731053:	xor    %edi,%edi
  731055:	mov    %rbx,%rsi
  731058:	xor    %ecx,%ecx
  73105a:	call   *0x372a78(%rip)        # aa3ad8 <_DYNAMIC+0x938>
  731060:	jmp    7311bd <owner_source_control::main+0x6bd>
  731065:	movq   $0xd,(%rsp)
  73106d:	movq   $0x0,0x8(%rsp)
  731076:	mov    %rbx,0x10(%rsp)
  73107b:	lea    -0x6d3a8a(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  731082:	lea    0x34a48f(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  731089:	lea    0x34a368(%rip),%r8        # a7b3f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x148>
  731090:	mov    %rsp,%rdx
  731093:	mov    $0x2b,%esi
  731098:	call   *0x37249a(%rip)        # aa3538 <_DYNAMIC+0x398>
  73109e:	jmp    7311bd <owner_source_control::main+0x6bd>
  7310a3:	mov    0xc0(%rsp),%rdx
  7310ab:	mov    %rdx,0x118(%rsp)
  7310b3:	movups 0xa0(%rsp),%xmm0
  7310bb:	movups 0xb0(%rsp),%xmm1
  7310c3:	movups %xmm1,0x108(%rsp)
  7310cb:	movups %xmm0,0xf8(%rsp)
  7310d3:	mov    %rcx,0xe8(%rsp)
  7310db:	mov    %rax,0xf0(%rsp)
  7310e3:	lea    -0x6d3af2(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  7310ea:	lea    0x34a427(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  7310f1:	lea    0x34a330(%rip),%r8        # a7b428 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x178>
  7310f8:	lea    0xe8(%rsp),%rdx
  731100:	mov    $0x2b,%esi
  731105:	call   *0x37242d(%rip)        # aa3538 <_DYNAMIC+0x398>
  73110b:	jmp    7311bd <owner_source_control::main+0x6bd>
  731110:	mov    $0xd,%ecx
  731115:	jmp    731123 <owner_source_control::main+0x623>
  731117:	mov    $0xe,%ecx
  73111c:	jmp    731123 <owner_source_control::main+0x623>
  73111e:	mov    $0x29,%ecx
  731123:	mov    %rcx,(%rsp)
  731127:	mov    %r13b,0x8(%rsp)
  73112c:	mov    0xe8(%rsp),%rcx
  731134:	mov    0xef(%rsp),%rdx
  73113c:	mov    %rcx,0x9(%rsp)
  731141:	mov    %rdx,0x10(%rsp)
  731146:	mov    %eax,0x18(%rsp)
  73114a:	movaps 0x90(%rsp),%xmm0
  731152:	movups %xmm0,0x1c(%rsp)
  731157:	movups 0x9c(%rsp),%xmm0
  73115f:	movups %xmm0,0x28(%rsp)
  731164:	lea    -0x6d3b73(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  73116b:	lea    0x34a3a6(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  731172:	lea    0x34a2df(%rip),%r8        # a7b458 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x1a8>
  731179:	mov    %rsp,%rdx
  73117c:	mov    $0x2b,%esi
  731181:	call   *0x3723b1(%rip)        # aa3538 <_DYNAMIC+0x398>
  731187:	jmp    7311bd <owner_source_control::main+0x6bd>
  731189:	movq   $0xd,(%rsp)
  731191:	movq   $0x0,0x8(%rsp)
  73119a:	lea    -0x6d3c08(%rip),%rdi        # 5d599 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x109>
  7311a1:	lea    0x34a370(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  7311a8:	lea    0x34a2d9(%rip),%r8        # a7b488 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x1d8>
  7311af:	mov    %rsp,%rdx
  7311b2:	mov    $0x24,%esi
  7311b7:	call   *0x37237b(%rip)        # aa3538 <_DYNAMIC+0x398>
  7311bd:	ud2
  7311bf:	jmp    7311f5 <owner_source_control::main+0x6f5>
  7311c1:	mov    %rax,%rbx
  7311c4:	lea    0xe8(%rsp),%rdi
  7311cc:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7311d1:	jmp    731205 <owner_source_control::main+0x705>
  7311d3:	jmp    7311f5 <owner_source_control::main+0x6f5>
  7311d5:	mov    %rax,%rbx
  7311d8:	cmpl   $0x2,0x2b0(%rsp)
  7311e0:	je     731212 <owner_source_control::main+0x712>
  7311e2:	lea    0x2b0(%rsp),%rdi
  7311ea:	call   72f1d0 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  7311ef:	jmp    731212 <owner_source_control::main+0x712>
  7311f1:	jmp    7311f5 <owner_source_control::main+0x6f5>
  7311f3:	jmp    7311f5 <owner_source_control::main+0x6f5>
  7311f5:	mov    %rax,%rbx
  7311f8:	mov    %rsp,%rdi
  7311fb:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  731200:	jmp    731205 <owner_source_control::main+0x705>
  731202:	mov    %rax,%rbx
  731205:	lea    0x138(%rsp),%rdi
  73120d:	call   72f1d0 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  731212:	mov    %rbx,%rdi
  731215:	call   a78270 <_Unwind_Resume@plt>
  73121a:	call   *0x372218(%rip)        # aa3438 <_DYNAMIC+0x298>


/tmp/gpui-projected-source-captures/release-borrowed/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000731220 <owner_source_control::open>:
  731220:	push   %r15
  731222:	push   %r14
  731224:	push   %r12
  731226:	push   %rbx
  731227:	sub    $0x3b8,%rsp
  73122e:	mov    %rdi,%rbx
  731231:	movq   $0x0,0x60(%rsp)
  73123a:	call   *0x3724f0(%rip)        # aa3730 <_DYNAMIC+0x590>
  731240:	movq   $0x0,0x190(%rsp)
  73124c:	mov    %rax,0x188(%rsp)
  731254:	movq   $0x0,0x1a0(%rsp)
  731260:	lea    0x34a049(%rip),%rdx        # a7b2b0 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845>
  731267:	lea    0x60(%rsp),%rdi
  73126c:	lea    0x188(%rsp),%rsi
  731274:	call   732ea0 <<gpui::reader::question::Questions<owner_source_control::Model>>::question_with::<&gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>>>
  731279:	cmpl   $0x2,0x60(%rsp)
  73127e:	je     7313e2 <owner_source_control::open+0x1c2>
  731284:	lea    0x188(%rsp),%rdi
  73128c:	lea    0x60(%rsp),%rsi
  731291:	mov    $0x118,%edx
  731296:	call   *0x372174(%rip)        # aa3410 <memcpy@GLIBC_2.14>
  73129c:	mov    0x178(%rsp),%r15
  7312a4:	mov    0x180(%rsp),%r12
  7312ac:	call   *0x37214e(%rip)        # aa3400 <_DYNAMIC+0x260>
  7312b2:	mov    $0x4,%edi
  7312b7:	mov    $0x1,%esi
  7312bc:	call   *0x37211e(%rip)        # aa33e0 <_DYNAMIC+0x240>
  7312c2:	test   %rax,%rax
  7312c5:	je     73147a <owner_source_control::open+0x25a>
  7312cb:	movl   $0x64656573,(%rax)
  7312d1:	movq   $0x1,0x48(%rsp)
  7312da:	movq   $0x4,0x18(%rsp)
  7312e3:	mov    %rax,0x20(%rsp)
  7312e8:	movq   $0x4,0x28(%rsp)
  7312f1:	movl   $0x0,0x30(%rsp)
  7312f9:	mov    %r15,0x38(%rsp)
  7312fe:	mov    %r12,0x40(%rsp)
  731303:	movups 0x288(%rsp),%xmm0
  73130b:	movaps %xmm0,0x50(%rsp)
  731310:	movabs $0xb400000118,%rax
  73131a:	mov    %rax,0x10(%rsp)
  73131f:	movl   $0x0,(%rsp)
  731326:	movl   $0x434b0000,0x8(%rsp)
  73132e:	movw   $0x0,0xc(%rsp)
  731335:	lea    0x2a0(%rsp),%r14
  73133d:	lea    0x188(%rsp),%rsi
  731345:	mov    $0xf8,%edx
  73134a:	mov    %r14,%rdi
  73134d:	call   *0x3720bd(%rip)        # aa3410 <memcpy@GLIBC_2.14>
  731353:	movaps 0x50(%rsp),%xmm0
  731358:	movups %xmm0,0x398(%rsp)
  731360:	movq   $0x0,0x3a8(%rsp)
  73136c:	lea    0x60(%rsp),%rdi
  731371:	lea    0x18(%rsp),%rsi
  731376:	mov    %rsp,%rcx
  731379:	movss  -0x6d9631(%rip),%xmm0        # 57d50 <anon.079f5e587c394fcac2765eb4d0cf0bc2.312.llvm.6319143315422321905+0x18>
  731381:	mov    %r14,%rdx
  731384:	mov    $0x1,%r8d
  73138a:	xor    %r9d,%r9d
  73138d:	call   6fad70 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::mount_lanes>
  731392:	cmpl   $0x2,0x60(%rsp)
  731397:	je     731416 <owner_source_control::open+0x1f6>
  731399:	lea    0x60(%rsp),%rsi
  73139e:	mov    $0x118,%edx
  7313a3:	mov    %rbx,%rdi
  7313a6:	call   *0x372064(%rip)        # aa3410 <memcpy@GLIBC_2.14>
  7313ac:	mov    %r15,0x118(%rbx)
  7313b3:	mov    %r12,0x120(%rbx)
  7313ba:	movq   $0x8,0x128(%rbx)
  7313c5:	movq   $0x118,0x130(%rbx)
  7313d0:	mov    %rbx,%rax
  7313d3:	add    $0x3b8,%rsp
  7313da:	pop    %rbx
  7313db:	pop    %r12
  7313dd:	pop    %r14
  7313df:	pop    %r15
  7313e1:	ret
  7313e2:	movzbl 0x68(%rsp),%eax
  7313e7:	mov    %al,0x188(%rsp)
  7313ee:	lea    -0x6d3dfd(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  7313f5:	lea    0x34a17c(%rip),%rcx        # a7b578 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x2c8>
  7313fc:	lea    0x34a0e5(%rip),%r8        # a7b4e8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x238>
  731403:	lea    0x188(%rsp),%rdx
  73140b:	mov    $0x2b,%esi
  731410:	call   *0x372122(%rip)        # aa3538 <_DYNAMIC+0x398>
  731416:	mov    0x98(%rsp),%rax
  73141e:	mov    %rax,0x2d0(%rsp)
  731426:	movups 0x68(%rsp),%xmm0
  73142b:	movups 0x78(%rsp),%xmm1
  731430:	movups 0x88(%rsp),%xmm2
  731438:	movaps %xmm2,0x2c0(%rsp)
  731440:	movaps %xmm1,0x2b0(%rsp)
  731448:	movaps %xmm0,0x2a0(%rsp)
  731450:	lea    -0x6d3e5f(%rip),%rdi        # 5d5f8 <anon.4d76bc73d2ecf6d7439404264a8f75e0.2.llvm.16741567646709100845+0x168>
  731457:	lea    0x34a0ba(%rip),%rcx        # a7b518 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x268>
  73145e:	lea    0x34a09b(%rip),%r8        # a7b500 <anon.4d76bc73d2ecf6d7439404264a8f75e0.3.llvm.16741567646709100845+0x250>
  731465:	lea    0x2a0(%rsp),%rdx
  73146d:	mov    $0x2b,%esi
  731472:	call   *0x3720c0(%rip)        # aa3538 <_DYNAMIC+0x398>
  731478:	jmp    73148a <owner_source_control::open+0x26a>
  73147a:	mov    $0x1,%edi
  73147f:	mov    $0x4,%esi
  731484:	call   *0x37206e(%rip)        # aa34f8 <_DYNAMIC+0x358>
  73148a:	ud2
  73148c:	mov    %rax,%rbx
  73148f:	lea    0x188(%rsp),%rdi
  731497:	call   72f3e0 <core::ptr::drop_glue::<gpui::reader::question::Questions<owner_source_control::Model, gpui::reader::question::QuestionLane<owner_source_control::Model, &gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>>>>
  73149c:	jmp    7314b1 <owner_source_control::open+0x291>
  73149e:	call   *0x371f94(%rip)        # aa3438 <_DYNAMIC+0x298>
  7314a4:	mov    %rax,%rbx
  7314a7:	lea    0x60(%rsp),%rdi
  7314ac:	call   733750 <core::ptr::drop_glue::<core::option::Option<gpui_reactivity_state::request::OwnerScope>>>
  7314b1:	mov    %rbx,%rdi
  7314b4:	call   a78270 <_Unwind_Resume@plt>
  7314b9:	call   *0x371f79(%rip)        # aa3438 <_DYNAMIC+0x298>
  7314bf:	mov    %rax,%rbx
  7314c2:	lea    0x2a0(%rsp),%rdi
  7314ca:	call   730070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7314cf:	mov    %rbx,%rdi
  7314d2:	call   a78270 <_Unwind_Resume@plt>
