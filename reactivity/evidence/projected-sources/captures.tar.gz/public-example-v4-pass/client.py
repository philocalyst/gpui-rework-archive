"""Frozen ordinary Window::document; real Registry actions, no private owner access."""
import ctypes, hashlib, json, os, pathlib, subprocess, time

CAP = pathlib.Path('/tmp/gpui-projected-source-captures')
OUT = CAP / 'public-example'
OUT.mkdir(exist_ok=True)
BINARY = CAP / 'native-example/component_sources'
ENV = dict(os.environ, DISPLAY=':247', GSETTINGS_BACKEND='memory')
TOOL = '/nix/store/qvckv6m6ycsa8f26w0f20mzk5w4v9ciq-xdotool-4.20260303.1/bin/xdotool'
Xvfb = '/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb'
LAUNCHER = '/nix/store/4g39rajyrxqn3na1kd4pykdigsr82af5-at-spi2-core-2.60.6/libexec/at-spi-bus-launcher'
TITLE = 'Reusable component sources'
A = 'org.a11y.atspi.Accessible'
deadline = time.monotonic() + 90
children = []
events = []

def wait(label, check):
    print('PHASE', label, flush=True)
    while time.monotonic() < deadline:
        value = check()
        if value:
            return value
        if children and children[-1].poll() is not None:
            raise AssertionError((label, 'owned child exited', children[-1].returncode))
        time.sleep(.02)
    raise AssertionError(('fixed 90s watchdog', label))

def call(address, node, interface, method, *args):
    result = subprocess.run(['busctl', '--timeout=2', '--json=short', '--address='+address,
        '--', 'call', node[0], node[1], interface, method, *args], capture_output=True, text=True, timeout=3)
    return (json.loads(result.stdout)['data'] if result.stdout.strip() else []) if result.returncode == 0 else None

def prop(node, name):
    value = call(bus, node, 'org.freedesktop.DBus.Properties', 'Get', 'ss', A, name)
    return value[0]['data'] if value else None

def tree(root):
    pending = [(root, None)]
    result = []
    while pending:
        node, parent = pending.pop(0)
        assert len(result) < 150, 'bounded public example tree'
        role = call(bus, node, A, 'GetRole')
        interfaces = call(bus, node, A, 'GetInterfaces')
        if not role or not interfaces:
            return None
        entry = {'node': node, 'parent': parent, 'role': role[0], 'name': prop(node, 'Name'),
                 'id': prop(node, 'AccessibleId'), 'interfaces': interfaces[0]}
        if 'org.a11y.atspi.Text' in interfaces[0]:
            text = call(bus, node, 'org.a11y.atspi.Text', 'GetText', 'ii', '0', '-1')
            entry['text'] = text[0] if text else None
        if 'org.a11y.atspi.Component' in interfaces[0]:
            entry['extents'] = call(bus, node, 'org.a11y.atspi.Component', 'GetExtents', 'u', '0')
        result.append(entry)
        nested = call(bus, node, A, 'GetChildren')
        if nested is None:
            return None
        pending.extend((child, node) for child in nested[0])
    return result

def snapshot(label):
    rows = wait(label, lambda: tree(window_provider))
    (OUT / (label+'.json')).write_text(json.dumps(rows, indent=2)+'\n')
    return rows

def state(left, right):
    def check():
        rows = tree(window_provider)
        if not rows:
            return None
        texts = [row.get('text') for row in rows]
        counts = [row for row in rows if row.get('text', '').isdigit()]
        counts.sort(key=lambda row:row['extents'][0][0])
        return rows if [row['text'] for row in counts] == [str(left),str(right)] and f'Twice the left count: {left*2}' in texts else None
    return check

def action(node, label):
    result = call(bus, node, 'org.a11y.atspi.Action', 'DoAction', 'i', '0')
    assert result == [True], (label, node, result)
    events.append({'action': label, 'original_provider': node, 'accepted': True})

def close(window):
    class Message(ctypes.Structure):
        _fields_ = [('kind',ctypes.c_int),('serial',ctypes.c_ulong),('send',ctypes.c_int),
            ('display',ctypes.c_void_p),('window',ctypes.c_ulong),('type',ctypes.c_ulong),
            ('format',ctypes.c_int),('data',ctypes.c_long*5)]
    class Event(ctypes.Union):
        _fields_ = [('message',Message),('padding',ctypes.c_long*24)]
    x = ctypes.CDLL('libX11.so.6')
    x.XOpenDisplay.argtypes=[ctypes.c_char_p]; x.XOpenDisplay.restype=ctypes.c_void_p
    x.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int]; x.XInternAtom.restype=ctypes.c_ulong
    x.XSendEvent.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_int,ctypes.c_long,ctypes.POINTER(Event)]
    x.XFlush.argtypes=[ctypes.c_void_p]; x.XCloseDisplay.argtypes=[ctypes.c_void_p]
    display=x.XOpenDisplay(ENV['DISPLAY'].encode()); assert display
    event=Event();event.message=Message(33,0,1,display,window,x.XInternAtom(display,b'WM_PROTOCOLS',0),32,
        (ctypes.c_long*5)(x.XInternAtom(display,b'WM_DELETE_WINDOW',0),0,0,0,0))
    assert x.XSendEvent(display,window,0,0,ctypes.byref(event))
    x.XFlush(display);x.XCloseDisplay(display)

try:
    with (OUT/'services.log').open('w') as services:
        children.append(subprocess.Popen([Xvfb,ENV['DISPLAY'],'-screen','0','1024x768x24','-nolisten','tcp'],env=ENV,stdout=services,stderr=services))
        wait('Xvfb',lambda:pathlib.Path('/tmp/.X11-unix/X247').exists())
        children.append(subprocess.Popen([LAUNCHER,'--launch-immediately','--a11y=0'],env=ENV,stdout=services,stderr=services))
        session=os.environ['DBUS_SESSION_BUS_ADDRESS']
        service=['org.a11y.Bus','/org/a11y/bus']
        bus=wait('AT bus',lambda:call(session,service,'org.a11y.Bus','GetAddress'))[0]
        assert call(session,service,'org.freedesktop.DBus.Properties','Set','ssv','org.a11y.Status','IsEnabled','b','true') == []
        with (OUT/'application.log').open('w') as app_log:
            app=subprocess.Popen([str(BINARY),'--cpu'],env=ENV,stdout=app_log,stderr=app_log);children.append(app)
            def mapped():
                result=subprocess.run([TOOL,'search','--onlyvisible','--pid',str(app.pid)],env=ENV,capture_output=True,text=True,timeout=3)
                return int(result.stdout.splitlines()[0]) if result.returncode==0 else None
            window=wait('mapped window',mapped)
            def provider():
                desktop=['org.a11y.atspi.Registry','/org/a11y/atspi/accessible/root']
                roots=call(bus,desktop,A,'GetChildren')
                if not roots:return None
                for root in roots[0]:
                    nested=call(bus,root,A,'GetChildren')
                    for node in nested[0] if nested else []:
                        if prop(node,'Name')==TITLE:return node
                return None
            window_provider=wait('real named window provider',provider)
            snapshot('first-public-tree')
            initial=wait('initial derived value',state(0,0));snapshot('initial')
            buttons=[row for row in initial if row['role']==43 and row['name']=='Increase']
            assert len(buttons)==2,buttons
            buttons.sort(key=lambda row:row['extents'][0][0])
            left,right=[row['node'] for row in buttons]
            parent=next(row['node'] for row in initial if row['role']==43 and row['name']=='Increase left from parent')
            action(left,'child-left');wait('left 1/right 0/derived 2',state(1,0));snapshot('left-1')
            action(right,'child-right');wait('left 1/right 1/derived still 2',state(1,1));snapshot('right-1')
            action(parent,'projected-parent');wait('left 2/right 1/derived 4',state(2,1));snapshot('parent-2')
            action(left,'original-child-provider-after-updates');wait('left 3/right 1/derived 6',state(3,1));final=snapshot('final')
            assert {tuple(row['node']) for row in final if row['role']==43}=={tuple(row['node']) for row in initial if row['role']==43}
            close(window);assert app.wait(timeout=10)==0
        assert 'panicked' not in (OUT/'application.log').read_text()
        (OUT/'result.json').write_text(json.dumps({'binary_sha256':hashlib.sha256(BINARY.read_bytes()).hexdigest(),
            'window':window,'provider':window_provider,'events':events,'final':{'left':3,'right':1,'derived':6},
            'original_action_providers_stable':True,'close':'WM_DELETE_WINDOW','exit':0},indent=2)+'\n')
finally:
    (OUT/'events.json').write_text(json.dumps(events,indent=2)+'\n')
    for child in reversed(children):
        if child.poll() is None:child.terminate()
    for child in reversed(children):
        try:child.wait(timeout=5)
        except subprocess.TimeoutExpired:child.kill();child.wait()
