//! NONSHIPPING matched source/question owner control. No clocks or timings.
use gpui::{Completion, LaneSet, Questions, Reader, StartError, WindowOptions, prelude::*};
use std::{convert::Infallible, hint::black_box, mem::size_of_val};
struct Model {
    count: Signal<u32>,
    caption: Signal<String>,
    answer: Reader<u32>,
}
impl Model {
    const COUNT: Source<Self, u32> =
        Source::new(FieldId::new(1), "count", |m| &m.count, |m| &mut m.count);
    const CAPTION: Source<Self, String> = Source::new(
        FieldId::new(2),
        "caption",
        |m| &m.caption,
        |m| &mut m.caption,
    );
}
impl View for Model {
    fn sources() -> Sources<Self> {
        Sources::new().direct(Self::COUNT).direct(Self::CAPTION)
    }
    fn view(&self) -> El<'_> {
        column((
            text(&self.count).h(24),
            text_input(&self.caption).w(220).h(32),
            button("Bump")
                .w(120)
                .h(32)
                .on_click(Self::COUNT.update(|count| *count += 1)),
            self.answer
                .project(|n| text(n.to_string()))
                .loading(|| text("Pending")),
        ))
        .gap(4)
    }
}
fn start(count: u32, completion: Completion<u32, Infallible>) -> Result<(), StartError> {
    let _ = completion.complete(Ok(count * 2));
    Ok(())
}
fn open() -> (Win<Model, impl LaneSet<Model>>, Reader<u32>, usize, usize) {
    #[cfg(not(borrowed_inputs))]
    let input = Model::COUNT;
    #[cfg(borrowed_inputs)]
    let input = &Model::COUNT;
    let input_bytes = size_of_val(&input);
    let (questions, answer) = Questions::new()
        .question(input, |count| *count, start)
        .unwrap();
    let plan_bytes = size_of_val(&questions);
    let owner = Win::with_questions(
        Model {
            count: Signal::new(1),
            caption: Signal::new("seed".into()),
            answer,
        },
        questions,
        WindowOptions {
            size: [280, 180],
            ..Default::default()
        },
    )
    .unwrap();
    (owner, answer, input_bytes, plan_bytes)
}
#[inline(never)]
fn drain<L: LaneSet<Model>>(owner: &mut Win<Model, L>) {
    for _ in 0..8 {
        if !owner.deliver_ready(8).unwrap().more {
            return;
        }
    }
    panic!("bounded synchronous questions did not settle in eight batches");
}
#[inline(never)]
fn source_set<L: LaneSet<Model>>(owner: &mut Win<Model, L>, value: u32) {
    owner.set(Model::COUNT, value).unwrap();
}
#[inline(never)]
fn source_action<L: LaneSet<Model>>(owner: &mut Win<Model, L>, target: Target) {
    owner.activate(target).unwrap();
}
#[inline(never)]
fn source_query<L: LaneSet<Model>>(owner: &Win<Model, L>, target: Target) -> Rect {
    owner.bounds(target).unwrap()
}
#[inline(never)]
fn source_hit<L: LaneSet<Model>>(owner: &Win<Model, L>, point: Point) -> Option<Target> {
    owner.hit_target(point).unwrap()
}
#[inline(never)]
fn source_pointer<L: LaneSet<Model>>(owner: &mut Win<Model, L>, point: Point) {
    let mut session = PointerSession::default();
    owner
        .pointer_event(&mut session, PointerEvent::Move(point))
        .unwrap();
    owner
        .pointer_event(&mut session, PointerEvent::Press)
        .unwrap();
    owner
        .pointer_event(&mut session, PointerEvent::Release)
        .unwrap();
}
fn main() {
    let mut built = None;
    let constructor = allocation_counter::measure(|| built = Some(open()));
    let (mut owner, answer, input_bytes, plan_bytes) = built.unwrap();
    drain(&mut owner);
    let target = owner.button("Bump");
    owner.reset_counters().unwrap();
    let update = allocation_counter::measure(|| {
        source_set(&mut owner, black_box(41));
        drain(&mut owner);
        source_action(&mut owner, target);
        drain(&mut owner);
        let bounds = source_query(&owner, target);
        let point = Point {
            x: bounds.x + bounds.width * 0.5,
            y: bounds.y + bounds.height * 0.5,
        };
        assert_eq!(source_hit(&owner, point), Some(target));
        source_pointer(&mut owner, point);
        drain(&mut owner);
    });
    assert_eq!(*owner.root().unwrap().count, 43);
    assert!(owner.contains_text("86").unwrap());
    let input = owner.question_info(answer).unwrap().input.unwrap();
    assert_eq!(input.source(), Model::COUNT.id());
    assert_eq!(input.revision(), 3);
    println!("OWNER_SOURCE_CONSTRUCTOR {constructor:?}");
    println!("OWNER_SOURCE_UPDATE {update:?}");
    println!(
        "OWNER_SOURCE_LAYOUT input={input_bytes} plan={plan_bytes} owner={}",
        size_of_val(&owner)
    );
    println!("OWNER_SOURCE_COUNTERS {:?}", owner.counters());
    println!("OWNER_SOURCE_ORACLE count=43 answer=86 source=1 revision=3");
    black_box(&owner);
}
