//! NONSHIPPING whole nested owner; model/View copied byte-for-byte from projected_sources tests.
use gpui::{Completion, LaneSet, Questions, StartError, WindowOptions, prelude::*};
use std::{convert::Infallible, hint::black_box, mem::size_of_val};
struct Leaf {
    value: Signal<String>,
    other: Signal<String>,
}
impl Leaf {
    const VALUE: Source<Self, String> =
        Source::new(FieldId::new(1), "value", |m| &m.value, |m| &mut m.value);
    fn new(value: &str) -> Self {
        Self {
            value: Signal::new(value.into()),
            other: Signal::new("other".into()),
        }
    }
}
impl View for Leaf {
    fn sources() -> Sources<Self> {
        Sources::new().direct(Self::VALUE)
    }
    fn view(&self) -> El<'_> {
        text(&self.value).w(140).h(40)
    }
}
struct Panel {
    leaf: Leaf,
}
impl Panel {
    const LEAF: Component<Self, Leaf> =
        Component::new(FieldId::new(1), "leaf", |m| &m.leaf, |m| &mut m.leaf);
}
impl View for Panel {
    fn sources() -> Sources<Self> {
        Sources::new().direct_component(Self::LEAF)
    }
    fn view(&self) -> El<'_> {
        Self::LEAF.view(self)
    }
}
struct Page {
    left: Panel,
    right: Panel,
}
impl Page {
    const LEFT: Component<Self, Panel> =
        Component::new(FieldId::new(1), "left", |m| &m.left, |m| &mut m.left);
    const RIGHT: Component<Self, Panel> =
        Component::new(FieldId::new(2), "right", |m| &m.right, |m| &mut m.right);
    fn new() -> Self {
        Self {
            left: Panel {
                leaf: Leaf::new("left"),
            },
            right: Panel {
                leaf: Leaf::new("right"),
            },
        }
    }
}
impl View for Page {
    fn sources() -> Sources<Self> {
        Sources::new()
            .direct_component(Self::LEFT)
            .direct_component(Self::RIGHT)
    }
    fn view(&self) -> El<'_> {
        column((
            Self::LEFT.view(self),
            Self::RIGHT.view(self),
            button("Bump left").on_click(
                Self::LEFT
                    .source(Panel::LEAF.source(&Leaf::VALUE))
                    .update(|value| value.push('!')),
            ),
        ))
    }
}
struct QuestionPage {
    page: Page,
}
impl QuestionPage {
    const PAGE: Component<Self, Page> =
        Component::new(FieldId::new(1), "page", |m| &m.page, |m| &mut m.page);
}
impl View for QuestionPage {
    fn sources() -> Sources<Self> {
        Sources::new().direct_component(Self::PAGE)
    }
    fn view(&self) -> El<'_> {
        Self::PAGE.view(self)
    }
}
fn finish(_: String, completion: Completion<(), Infallible>) -> Result<(), StartError> {
    completion.complete(Ok(())).unwrap();
    Ok(())
}
fn open() -> (Win<QuestionPage, impl LaneSet<QuestionPage>>, usize, usize) {
    #[cfg(not(borrowed_inputs))]
    let input = QuestionPage::PAGE.source(Page::LEFT.source(Panel::LEAF.source(&Leaf::VALUE)));
    #[cfg(borrowed_inputs)]
    let input =
        &const { QuestionPage::PAGE.source(Page::LEFT.source(Panel::LEAF.source(&Leaf::VALUE))) };
    let input_bytes = size_of_val(&input);
    let (questions, _) = Questions::new()
        .question(input, Clone::clone, finish)
        .unwrap();
    let plan_bytes = size_of_val(&questions);
    let owner = Win::with_questions(
        QuestionPage { page: Page::new() },
        questions,
        WindowOptions {
            size: [300, 180],
            ..Default::default()
        },
    )
    .unwrap();
    (owner, input_bytes, plan_bytes)
}
fn main() {
    let mut built = None;
    let constructor = allocation_counter::measure(|| built = Some(open()));
    let (mut owner, input_bytes, plan_bytes) = built.unwrap();
    for _ in 0..8 {
        if !owner.deliver_ready(8).unwrap().more {
            break;
        }
    }
    let left = QuestionPage::PAGE.source(Page::LEFT.source(Panel::LEAF.source(&Leaf::VALUE)));
    let right = QuestionPage::PAGE.source(Page::RIGHT.source(Panel::LEAF.source(&Leaf::VALUE)));
    owner.reset_counters().unwrap();
    let update = allocation_counter::measure(|| {
        owner.set(left, "changed".into()).unwrap();
        owner.activate(owner.button("Bump left")).unwrap();
    });
    assert_eq!(owner.read(left).unwrap(), "changed!");
    assert_eq!(owner.read(right).unwrap(), "right");
    // Changing a Question input publishes its new status; the existing barrier
    // conservatively describes the owner even when no Reader is displayed.
    assert_eq!(owner.counters().owner_reruns, 2);
    assert_eq!(owner.counters().descriptions, 2);
    assert_eq!(owner.counters().coarse_updates, 2);
    println!("NESTED_OWNER_CONSTRUCTOR {constructor:?}");
    println!("NESTED_OWNER_UPDATE {update:?}");
    println!(
        "NESTED_OWNER_LAYOUT input={input_bytes} plan={plan_bytes} owner={}",
        size_of_val(&owner)
    );
    println!("NESTED_OWNER_COUNTERS {:?}", owner.counters());
    println!("NESTED_OWNER_ORACLE left=changed! right=right coarse=2 owner_reruns=2");
    black_box(&owner);
}
