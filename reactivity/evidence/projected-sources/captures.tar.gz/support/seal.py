"""Archive immutable source-qualified captures; keep large executables external."""
import gzip,hashlib,json,pathlib,tarfile

cap=pathlib.Path('/tmp/gpui-projected-source-captures')
out=pathlib.Path('/tmp/gpui-projected-source-sol/reactivity/evidence/projected-sources')
included=[];external=[]
for path in sorted(cap.rglob('*')):
    if not path.is_file():continue
    relative=path.relative_to(cap).as_posix()
    with path.open('rb') as stream:magic=stream.read(4)
    row={'path':relative,'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
    (external if magic==b'\x7fELF' or path.name.endswith('.elf.json') else included).append(row)
with (out/'captures.tar.gz').open('wb') as raw:
    with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w|') as archive:
            for row in included:
                path=cap/row['path'];info=tarfile.TarInfo(row['path']);info.size=row['bytes'];info.mode=0o644
                with path.open('rb') as stream:archive.addfile(info,stream)
archive=out/'captures.tar.gz'
manifest={'external_root':str(cap),'included':included,'external':external,
    'archive':{'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},
    'external_reason':'Frozen ELF executables/full ELF inventories remain at the external root; compact GPUI frame inventories are archived.'}
(out/'capture-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary=json.loads((out/'summary.json').read_text())
summary['support_physical_lines']={p.name:len(p.read_text().splitlines()) for p in (cap/'support').iterdir() if p.suffix in ('.py','.rs','.toml')}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('archived',len(included),'files',sum(r['bytes'] for r in included),'B; external',len(external),'; compressed',archive.stat().st_size)
with tarfile.open(archive,'r:gz') as check:
    names=check.getnames();assert names==[r['path'] for r in included]
    for row in included:
        assert hashlib.sha256(check.extractfile(row['path']).read()).hexdigest()==row['sha256'],row['path']
for row in external:
    assert hashlib.sha256((cap/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
print('archive and all external guards PASS')
