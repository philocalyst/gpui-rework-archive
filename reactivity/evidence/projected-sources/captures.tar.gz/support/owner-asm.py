"""Selected static caller/callee bodies, including relative GOT resolution."""
import importlib.util,json,pathlib,re,struct,subprocess

cap=pathlib.Path('/tmp/gpui-projected-source-captures')
spec=importlib.util.spec_from_file_location('elf',cap/'support/elf.py')
elf=importlib.util.module_from_spec(spec);spec.loader.exec_module(elf)
for label in ('baseline','candidate','borrowed'):
    path=cap/('release-'+label)/'owner_source_control'
    if not path.exists():continue
    result=elf.inspect(path);data=path.read_bytes();header=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
    sections=[struct.unpack_from('<IIQQQQIIQQ',data,header[6]+i*header[11]) for i in range(header[12])]
    section=sections[header[13]];names=data[section[4]:section[4]+section[5]]
    named={names[s[0]:names.index(0,s[0])].decode():s for s in sections};relocations={}
    section=named['.rela.dyn']
    for offset in range(section[4],section[4]+section[5],section[9]):
        address,info,addend=struct.unpack_from('<QQq',data,offset)
        if info&0xffffffff==8:relocations[address]=addend
    functions={f['address']:f for f in result['all_frames']};symbols={f['address']:f['normalized_name'] for f in result['symbols']}
    selected=[f for f in result['all_frames'] if
        f['normalized_name'].startswith('owner_source_control::') or
        ('owner_source_control::Model' in f['normalized_name'] and any(n in f['normalized_name'] for n in ('::set::<','::resolve','::validate_source','::admit','::invoke')))]
    bodies=[];calls=[]
    for function in selected:
        start=function['address']
        assembly=subprocess.check_output([elf.BIN+'objdump','-d','--no-show-raw-insn','--demangle=rust',f'--start-address={start}',f'--stop-address={start+function["code_bytes"]}',str(path)],text=True)
        bodies.append(assembly)
        for line in assembly.splitlines():
            if not re.search(r'\bcall\b',line):continue
            direct=re.search(r'\bcall\s+([0-9a-f]+)',line);got=re.search(r'# ([0-9a-f]+)',line)
            address=int(direct[1],16) if direct else relocations.get(int(got[1],16)) if got else None
            target=functions.get(address)
            calls.append({'caller':function['normalized_name'],'caller_frame':function['stack_bytes'],
                'instruction':line.strip(),'target':symbols.get(address),
                'target_frame':target['stack_bytes'] if target else None})
    path.with_suffix('.asm').write_text('\n'.join(bodies))
    path.with_suffix('.calls.json').write_text(json.dumps(calls,indent=2)+'\n')
