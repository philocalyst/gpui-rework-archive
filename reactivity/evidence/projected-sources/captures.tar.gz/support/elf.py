import hashlib,json,pathlib,re,struct,subprocess,sys
BIN='/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/'
def inspect(path):
 data=path.read_bytes();assert data[:6]==b'\x7fELF\x02\x01'
 head=struct.unpack_from('<16sHHIQQQIHHHHHH',data)
 sections=[struct.unpack_from('<IIQQQQIIQQ',data,head[6]+i*head[11]) for i in range(head[12])]
 def content(s):return data[s[4]:s[4]+s[5]]
 def string(table,start):return table[start:table.index(0,start)].decode()
 strings=content(sections[head[13]]);byname={string(strings,s[0]):s for s in sections}
 symtab=byname['.symtab'];names=content(sections[symtab[6]]);funcs=[]
 for offset in range(symtab[4],symtab[4]+symtab[5],symtab[9]):
  name,info,other,index,value,size=struct.unpack_from('<IBBHQQ',data,offset)
  if info&15==2 and index and value:funcs.append({'address':value,'code_bytes':size,'mangled':string(names,name)})
 decoded=subprocess.check_output([BIN+'c++filt','--format=rust'],input='\n'.join(f['mangled'] for f in funcs).encode()).decode().splitlines();lookup={}
 for f,name in zip(funcs,decoded):f['name']=name;f['normalized_name']=re.sub(r'\[[0-9a-f]+\]', '', name);lookup.setdefault(f['address'],[]).append(f)
 stack=content(byname['.stack_sizes']);cursor=0;frames=[]
 while cursor<len(stack):
  address=struct.unpack_from('<Q',stack,cursor)[0];cursor+=8;size=0;shift=0
  while True:
   byte=stack[cursor];cursor+=1;size|=(byte&127)<<shift
   if byte<128:break
   shift+=7
  for f in lookup.get(address,[]):frames.append({**f,'stack_bytes':size})
 selected=[f for f in frames if any(n in f['normalized_name'] for n in ('gpui::native', 'gpui::tween', 'SourceTween', 'TweenFrames', 'tween_inputs', 'source_tween::', 'source_tween_plain::'))]
 return {'binary':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'sections':{n:s[5] for n,s in byname.items() if n in ('.text','.rodata','.data.rel.ro','.stack_sizes')},'selected':selected,'all_gpui_frames':[f for f in frames if 'gpui::' in f['normalized_name']], 'all_frames':frames,'symbols':funcs,'metadata_functions':len(frames),'limits':'Static compiler frames, not call-depth or dynamic stack. No timing.'}
if __name__=='__main__':
 for name in sys.argv[1:]:
  path=pathlib.Path(name);result=inspect(path);path.with_suffix('.elf.json').write_text(json.dumps(result,indent=2)+'\n')
  print(path.name,result['sections'],len(result['all_gpui_frames']))
