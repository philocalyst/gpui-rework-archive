"""NONSHIPPING same-path compiler/owner control. No timing or queued successor."""
import hashlib,json,os,pathlib,shutil,subprocess,sys

label=sys.argv[1]
assert label in ('baseline','candidate','borrowed')
root=pathlib.Path('/tmp/gpui-projected-source-control-sol')
cap=pathlib.Path('/tmp/gpui-projected-source-captures')
out=cap/('release-'+label);out.mkdir(exist_ok=True)
assert not os.environ.get('RUSTFLAGS') and not os.environ.get('CARGO_ENCODED_RUSTFLAGS')
assert os.environ['CARGO_TARGET_DIR']=='/tmp/gpui-projected-source-control-target'
assert os.environ['CARGO_BUILD_JOBS']=='1'
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain'])
base='f102ef111c7214c7ace900f76a74c9d3e7ca14e2'
shipping=base if label=='baseline' else 'df66f5985d'
changed=subprocess.check_output(['git','-C',str(root),'diff','--name-only',base,'df66f5985d','--','reactivity/crates/gpui/src']).decode().splitlines()
for name in changed:
    expected=subprocess.run(['git','-C',str(root),'show',shipping+':'+name],capture_output=True)
    path=root/name
    assert (path.read_bytes()==expected.stdout) if expected.returncode==0 else not path.exists(),name
fixture_names=['reactivity/crates/gpui/examples/owner_source_control.rs','.cargo/config.toml','reactivity/Cargo.toml','reactivity/Cargo.lock']
(out/'fixture.json').write_text(json.dumps({name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in fixture_names},indent=2)+'\n')
def guard(name):
    with (out/name).open('w') as log:
        subprocess.run([sys.executable,str(cap/'support/guard.py'),str(root)],stdout=log,check=True)
guard('guard-before.json')
(out/'rustc.txt').write_bytes(subprocess.check_output(['rustc','-Vv']))
with (out/'clean.log').open('w') as log:
    subprocess.run(['cargo','clean','-p','gpui','--release'],cwd=root/'reactivity',stdout=log,stderr=log,check=True)
cmd=['cargo','rustc','--offline','--locked','-p','gpui','--release','--config',str(cap/'support/stack-metadata.toml'),
     '--example','owner_source_control','--message-format=json','--','--check-cfg','cfg(borrowed_inputs)']
if label=='borrowed':cmd+=['--cfg','borrowed_inputs']
(out/'command.json').write_text(json.dumps(cmd,indent=2)+'\n')
with (out/'cargo.jsonl').open('w') as log,(out/'cargo.log').open('w') as errors:
    subprocess.run(cmd,cwd=root/'reactivity',stdout=log,stderr=errors,check=True)
artifacts=[]
for line in (out/'cargo.jsonl').read_text().splitlines():
    row=json.loads(line)
    if row.get('reason')=='compiler-artifact' and row.get('executable'):
        assert row['target']['name']=='owner_source_control' and not row['fresh'],row
        path=pathlib.Path(row['executable']);dest=out/path.name;shutil.copy2(path,dest)
        row.update(frozen_binary=str(dest),sha256=hashlib.sha256(dest.read_bytes()).hexdigest());artifacts.append(row)
assert len(artifacts)==1,artifacts
(out/'artifacts.json').write_text(json.dumps(artifacts,indent=2)+'\n')
fingerprints=out/'fingerprints';fingerprints.mkdir(exist_ok=True)
for path in (pathlib.Path(os.environ['CARGO_TARGET_DIR'])/'release/.fingerprint').glob('gpui-*/*.json'):
    shutil.copy2(path,fingerprints/(path.parent.name+'-'+path.name))
binary=artifacts[0]['frozen_binary']
with (out/'oracle.log').open('w') as log:
    subprocess.run([binary],stdout=log,stderr=log,timeout=30,check=True)
subprocess.run([sys.executable,str(cap/'support/elf.py'),binary],check=True)
guard('guard-after.json')
assert (out/'guard-before.json').read_bytes()==(out/'guard-after.json').read_bytes()
(out/'status').write_text('0\n')
