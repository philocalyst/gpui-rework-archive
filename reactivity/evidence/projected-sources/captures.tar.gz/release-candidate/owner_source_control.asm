
/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000006e8d30 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>>:
  6e8d30:	push   %rbp
  6e8d31:	push   %r15
  6e8d33:	push   %r14
  6e8d35:	push   %r13
  6e8d37:	push   %r12
  6e8d39:	push   %rbx
  6e8d3a:	sub    $0xc8,%rsp
  6e8d41:	mov    %ecx,%ebp
  6e8d43:	mov    %rsi,%rbx
  6e8d46:	mov    %rdi,%r15
  6e8d49:	mov    0x130(%rsi),%r14
  6e8d50:	test   %r14,%r14
  6e8d53:	je     6e8d6a <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x3a>
  6e8d55:	cmpb   $0x1,0x756(%r14)
  6e8d5d:	jne    6e8d8e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x5e>
  6e8d5f:	mov    $0xe,%r12d
  6e8d65:	jmp    6e8e49 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x119>
  6e8d6a:	movq   $0x2,(%r15)
  6e8d71:	movq   $0xd,0x8(%r15)
  6e8d79:	movq   $0x0,0x10(%r15)
  6e8d81:	mov    %rbx,0x18(%r15)
  6e8d85:	mov    %ebp,0x40(%r15)
  6e8d89:	jmp    6e9084 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x354>
  6e8d8e:	mov    %rbx,(%rsp)
  6e8d92:	mov    0x698(%r14),%rax
  6e8d99:	mov    %rax,0x20(%rsp)
  6e8d9e:	lea    0x290(%r14),%r13
  6e8da5:	lea    0x228(%r14),%rcx
  6e8dac:	lea    0x70(%rsp),%rdi
  6e8db1:	mov    %rdx,%rbx
  6e8db4:	mov    %rdx,%rsi
  6e8db7:	mov    %r13,%rdx
  6e8dba:	call   73a7a0 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve>
  6e8dbf:	mov    0x70(%rsp),%rax
  6e8dc4:	cmp    $0xffffffffffffffff,%rax
  6e8dc8:	je     6e8de1 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xb1>
  6e8dca:	movups 0x78(%rsp),%xmm0
  6e8dcf:	mov    %rax,0x40(%rsp)
  6e8dd4:	movups %xmm0,0x48(%rsp)
  6e8dd9:	mov    $0x20,%r12d
  6e8ddf:	jmp    6e8e0b <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xdb>
  6e8de1:	mov    0x78(%rsp),%rax
  6e8de6:	mov    %rax,0x18(%rsp)
  6e8deb:	movq   $0x0,0xa8(%rsp)
  6e8df7:	mov    $0xe,%r12d
  6e8dfd:	cmpb   $0x0,0x756(%r14)
  6e8e05:	je     6e8f17 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x1e7>
  6e8e0b:	mov    $0x1,%r8b
  6e8e0e:	mov    0x40(%rsp),%r9
  6e8e13:	mov    0x48(%rsp),%rdi
  6e8e18:	mov    0x50(%rsp),%rdx
  6e8e1d:	movzbl 0x58(%rsp),%esi
  6e8e22:	mov    0x60(%rsp),%rax
  6e8e27:	mov    0x68(%rsp),%rcx
  6e8e2c:	mov    0x5c(%rsp),%r10d
  6e8e31:	mov    %r10d,0x2f(%rsp)
  6e8e36:	mov    0x59(%rsp),%r10d
  6e8e3b:	mov    %r10d,0x2c(%rsp)
  6e8e40:	test   %r8b,%r8b
  6e8e43:	je     6e8ea3 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x173>
  6e8e45:	mov    (%rsp),%rbx
  6e8e49:	movq   $0x2,(%r15)
  6e8e50:	mov    %r12,0x8(%r15)
  6e8e54:	mov    %r9,0x10(%r15)
  6e8e58:	mov    %rdi,0x18(%r15)
  6e8e5c:	mov    %rdx,0x20(%r15)
  6e8e60:	mov    %sil,0x28(%r15)
  6e8e64:	mov    0x2c(%rsp),%edx
  6e8e68:	mov    0x2f(%rsp),%esi
  6e8e6c:	mov    %edx,0x29(%r15)
  6e8e70:	mov    %esi,0x2c(%r15)
  6e8e74:	mov    %rax,0x30(%r15)
  6e8e78:	mov    %rcx,0x38(%r15)
  6e8e7c:	mov    %ebp,0x40(%r15)
  6e8e80:	mov    0x9(%rsp),%eax
  6e8e84:	mov    0xc(%rsp),%ecx
  6e8e88:	mov    %eax,0x51(%r15)
  6e8e8c:	mov    %ecx,0x54(%r15)
  6e8e90:	cmpb   $0x0,0x756(%r14)
  6e8e98:	je     6e9072 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x342>
  6e8e9e:	jmp    6e907c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x34c>
  6e8ea3:	mov    0x698(%r14),%r11
  6e8eaa:	cmp    0x20(%rsp),%r11
  6e8eaf:	jne    6e8edb <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x1ab>
  6e8eb1:	mov    $0x4,%ebx
  6e8eb6:	lea    0xa8(%rsp),%r13
  6e8ebe:	mov    %r8,0x20(%rsp)
  6e8ec3:	mov    %rax,0x18(%rsp)
  6e8ec8:	mov    %rcx,0x10(%rsp)
  6e8ecd:	mov    %r9,%r11
  6e8ed0:	mov    %rdx,%r8
  6e8ed3:	mov    %esi,%r10d
  6e8ed6:	jmp    6e8fdf <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x2af>
  6e8edb:	mov    %rdi,%r8
  6e8ede:	shr    $0x20,%r8
  6e8ee2:	movzbl 0x754(%r14),%r10d
  6e8eea:	cmpq   $0x0,0x6b8(%r14)
  6e8ef2:	mov    %r8,0x20(%rsp)
  6e8ef7:	je     6e8f10 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x1e0>
  6e8ef9:	test   %r10b,%r10b
  6e8efc:	je     6e8faf <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x27f>
  6e8f02:	cmpq   $0xffffffffffffffff,0x5c0(%r14)
  6e8f0a:	jne    6e8faf <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x27f>
  6e8f10:	xor    %ebx,%ebx
  6e8f12:	jmp    6e8fbb <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x28b>
  6e8f17:	mov    0x698(%r14),%r12
  6e8f1e:	inc    %r12
  6e8f21:	je     6e9134 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x404>
  6e8f27:	mov    %r13,%rdi
  6e8f2a:	call   *0x18(%rbx)
  6e8f2d:	mov    %rax,0x10(%rsp)
  6e8f32:	mov    %r13,%rdi
  6e8f35:	call   *0x20(%rbx)
  6e8f38:	cmp    %rax,0x10(%rsp)
  6e8f3d:	je     6e9099 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x369>
  6e8f43:	mov    (%rbx),%rax
  6e8f46:	movq   $0xa,0x78(%rsp)
  6e8f4f:	mov    %rax,0x80(%rsp)
  6e8f57:	mov    (%rsp),%rax
  6e8f5b:	mov    %rax,0x90(%rsp)
  6e8f63:	movups 0x98(%rsp),%xmm0
  6e8f6b:	movups %xmm0,0x60(%rsp)
  6e8f70:	mov    0x78(%rsp),%rax
  6e8f75:	mov    %rax,0x40(%rsp)
  6e8f7a:	mov    0x80(%rsp),%rax
  6e8f82:	mov    %rax,0x48(%rsp)
  6e8f87:	mov    0x88(%rsp),%rax
  6e8f8f:	mov    %rax,0x50(%rsp)
  6e8f94:	mov    0x90(%rsp),%rax
  6e8f9c:	mov    %rax,0x58(%rsp)
  6e8fa1:	mov    $0x20,%r12d
  6e8fa7:	mov    $0x1,%r8b
  6e8faa:	jmp    6e8e0e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xde>
  6e8faf:	mov    0x6c8(%r14),%rbp
  6e8fb6:	mov    $0x1,%ebx
  6e8fbb:	mov    %edi,0x34(%rsp)
  6e8fbf:	mov    0x6a0(%r14),%rdi
  6e8fc6:	mov    0x740(%r14),%r8
  6e8fcd:	lea    0x9(%rsp),%r13
  6e8fd2:	mov    %r12,0x18(%rsp)
  6e8fd7:	mov    %r9,0x10(%rsp)
  6e8fdc:	mov    %rbp,%r12
  6e8fdf:	lea    0x59(%rsp),%rbp
  6e8fe4:	mov    0x3(%rbp),%r9d
  6e8fe8:	mov    %r9d,0x3(%r13)
  6e8fec:	mov    0x0(%rbp),%r9d
  6e8ff0:	mov    %r9d,0x0(%r13)
  6e8ff4:	mov    %rbx,(%r15)
  6e8ff7:	mov    %r12,0x8(%r15)
  6e8ffb:	mov    %r11,0x10(%r15)
  6e8fff:	mov    %rdi,0x18(%r15)
  6e9003:	mov    %r8,0x20(%r15)
  6e9007:	mov    %r10b,0x28(%r15)
  6e900b:	mov    0xa8(%rsp),%edi
  6e9012:	mov    %edi,0x29(%r15)
  6e9016:	mov    0xab(%rsp),%edi
  6e901d:	mov    %edi,0x2c(%r15)
  6e9021:	mov    0x18(%rsp),%rdi
  6e9026:	mov    %rdi,0x30(%r15)
  6e902a:	mov    0x10(%rsp),%rdi
  6e902f:	mov    %rdi,0x38(%r15)
  6e9033:	mov    0x34(%rsp),%edi
  6e9037:	mov    %edi,0x40(%r15)
  6e903b:	mov    0x20(%rsp),%rdi
  6e9040:	mov    %edi,0x44(%r15)
  6e9044:	mov    %rdx,0x48(%r15)
  6e9048:	mov    %sil,0x50(%r15)
  6e904c:	mov    0x9(%rsp),%edx
  6e9050:	mov    %edx,0x51(%r15)
  6e9054:	mov    0xc(%rsp),%edx
  6e9058:	mov    %edx,0x54(%r15)
  6e905c:	mov    %rax,0x58(%r15)
  6e9060:	mov    %rcx,0x60(%r15)
  6e9064:	mov    (%rsp),%rbx
  6e9068:	cmpb   $0x0,0x756(%r14)
  6e9070:	jne    6e907c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x34c>
  6e9072:	cmpq   $0xffffffffffffffff,0x698(%r14)
  6e907a:	jne    6e9084 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x354>
  6e907c:	mov    %rbx,%rdi
  6e907f:	call   7355c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  6e9084:	mov    %r15,%rax
  6e9087:	add    $0xc8,%rsp
  6e908e:	pop    %rbx
  6e908f:	pop    %r12
  6e9091:	pop    %r13
  6e9093:	pop    %r14
  6e9095:	pop    %r15
  6e9097:	pop    %rbp
  6e9098:	ret
  6e9099:	mov    0x4(%rax),%ecx
  6e909c:	cmp    $0xffffffff,%ecx
  6e909f:	je     6e913f <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x40f>
  6e90a5:	inc    %ecx
  6e90a7:	mov    %ecx,0x4(%rax)
  6e90aa:	mov    %ebp,(%rax)
  6e90ac:	mov    %r12,0x698(%r14)
  6e90b3:	incq   0x6e8(%r14)
  6e90ba:	movq   $0x0,0x740(%r14)
  6e90c5:	lea    0x38(%rsp),%rdi
  6e90ca:	lea    0xa8(%rsp),%r8
  6e90d2:	mov    %r14,%rsi
  6e90d5:	mov    (%rsp),%rbx
  6e90d9:	mov    %rbx,%rdx
  6e90dc:	mov    0x18(%rsp),%rcx
  6e90e1:	xor    %r9d,%r9d
  6e90e4:	call   6f0900 <<gpui::runtime::RuntimeMut<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::after_source_changed>
  6e90e9:	mov    0x38(%rsp),%r12
  6e90ee:	cmp    $0xfffffffffffffffe,%r12
  6e90f2:	jne    6e912c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x3fc>
  6e90f4:	movups 0x40(%rsp),%xmm0
  6e90f9:	movups 0x50(%rsp),%xmm1
  6e90fe:	movups 0x60(%rsp),%xmm2
  6e9103:	movups %xmm2,0x28(%r15)
  6e9108:	movups %xmm1,0x18(%r15)
  6e910d:	movups %xmm0,0x8(%r15)
  6e9112:	movq   $0xffffffffffffffff,(%r15)
  6e9119:	cmpb   $0x0,0x756(%r14)
  6e9121:	je     6e9072 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x342>
  6e9127:	jmp    6e907c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x34c>
  6e912c:	xor    %r8d,%r8d
  6e912f:	jmp    6e8e0e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xde>
  6e9134:	mov    $0x1f,%r12d
  6e913a:	jmp    6e8e0b <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xdb>
  6e913f:	lea    -0x68bcff(%rip),%rdi        # 5d447 <anon.9e1adc519e45ee0094feacbcca2f7d65.68.llvm.16917318406874983744>
  6e9146:	lea    0x392343(%rip),%rdx        # a7b490 <anon.9e1adc519e45ee0094feacbcca2f7d65.70.llvm.16917318406874983744>
  6e914d:	mov    $0x19,%esi
  6e9152:	call   *0x3ba398(%rip)        # aa34f0 <_DYNAMIC+0x2b0>
  6e9158:	ud2
  6e915a:	mov    %rax,%r15
  6e915d:	cmpb   $0x0,0x756(%r14)
  6e9165:	jne    6e9171 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x441>
  6e9167:	cmpq   $0xffffffffffffffff,0x698(%r14)
  6e916f:	jne    6e917a <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x44a>
  6e9171:	mov    (%rsp),%rdi
  6e9175:	call   7355c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  6e917a:	mov    %r15,%rdi
  6e917d:	call   a78310 <_Unwind_Resume@plt>
  6e9182:	call   *0x3ba350(%rip)        # aa34d8 <_DYNAMIC+0x298>
  6e9188:	mov    %rax,%rdi
  6e918b:	call   *0x3ba367(%rip)        # aa34f8 <_DYNAMIC+0x2b8>
  6e9191:	mov    %rax,%rbx
  6e9194:	mov    %rdx,%r13
  6e9197:	mov    %rax,0xb0(%rsp)
  6e919f:	mov    %rdx,0xb8(%rsp)
  6e91a7:	movq   $0xfffffffffffffffe,0xa8(%rsp)
  6e91b3:	mov    %r14,%rdi
  6e91b6:	call   70a190 <<gpui::runtime::Runtime<owner_source_control::Model>>::poison>
  6e91bb:	mov    0x0(%r13),%rax
  6e91bf:	test   %rax,%rax
  6e91c2:	je     6e922c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x4fc>
  6e91c4:	mov    %rbx,%rdi
  6e91c7:	call   *%rax
  6e91c9:	jmp    6e922c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x4fc>
  6e91cb:	jmp    6e9254 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x524>
  6e91d0:	mov    %rax,%r15
  6e91d3:	lea    0xa8(%rsp),%rdi
  6e91db:	call   6ea4c0 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::source::FieldId, gpui::source::BindError>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e91e0:	jmp    6e915d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x42d>
  6e91e5:	call   *0x3ba2ed(%rip)        # aa34d8 <_DYNAMIC+0x298>
  6e91eb:	call   *0x3ba30f(%rip)        # aa3500 <_DYNAMIC+0x2c0>
  6e91f1:	mov    %rax,%rdi
  6e91f4:	call   *0x3ba2fe(%rip)        # aa34f8 <_DYNAMIC+0x2b8>
  6e91fa:	mov    %rax,%rbx
  6e91fd:	mov    %rdx,%r13
  6e9200:	mov    %rax,0x78(%rsp)
  6e9205:	mov    %rdx,0x80(%rsp)
  6e920d:	movq   $0xfffffffffffffffd,0x70(%rsp)
  6e9216:	mov    %r14,%rdi
  6e9219:	call   70a190 <<gpui::runtime::Runtime<owner_source_control::Model>>::poison>
  6e921e:	mov    0x0(%r13),%rax
  6e9222:	test   %rax,%rax
  6e9225:	je     6e922c <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x4fc>
  6e9227:	mov    %rbx,%rdi
  6e922a:	call   *%rax
  6e922c:	mov    0x8(%r13),%rsi
  6e9230:	mov    $0xf,%r12d
  6e9236:	test   %rsi,%rsi
  6e9239:	je     6e8e0b <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xdb>
  6e923f:	mov    0x10(%r13),%rdx
  6e9243:	mov    %rbx,%rdi
  6e9246:	call   *0x3ba23c(%rip)        # aa3488 <_DYNAMIC+0x248>
  6e924c:	mov    $0x1,%r8b
  6e924f:	jmp    6e8e0e <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0xde>
  6e9254:	mov    %rax,%r15
  6e9257:	mov    0x8(%r13),%rsi
  6e925b:	test   %rsi,%rsi
  6e925e:	je     6e915d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x42d>
  6e9264:	mov    0x10(%r13),%rdx
  6e9268:	mov    %rbx,%rdi
  6e926b:	call   *0x3ba217(%rip)        # aa3488 <_DYNAMIC+0x248>
  6e9271:	jmp    6e915d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x42d>
  6e9276:	mov    %rax,%r15
  6e9279:	lea    0x70(%rsp),%rdi
  6e927e:	call   6ea530 <core::ptr::drop_glue::<core::result::Result<core::result::Result<gpui::runtime::paint::PatchOutcome, gpui::runtime::Error>, alloc::boxed::Box<dyn core::any::Any + core::marker::Send>>>>
  6e9283:	jmp    6e915d <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>+0x42d>
  6e9288:	call   *0x3ba24a(%rip)        # aa34d8 <_DYNAMIC+0x298>
  6e928e:	call   *0x3ba26c(%rip)        # aa3500 <_DYNAMIC+0x2c0>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000701dd0 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index>:
  701dd0:	push   %rbx
  701dd1:	mov    $0x11,%r9d
  701dd7:	cmp    0x5e8(%rsi),%rdx
  701dde:	jne    701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701de4:	cmpb   $0x1,0x752(%rsi)
  701deb:	jne    701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701df1:	mov    0x1e8(%rsi),%rax
  701df8:	test   %rax,%rax
  701dfb:	je     701e8c <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xbc>
  701e01:	cmp    $0x1,%eax
  701e04:	jne    701ea6 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd6>
  701e0a:	mov    0x1f8(%rsi),%r8
  701e11:	test   %r8,%r8
  701e14:	je     701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e1a:	mov    0x1f0(%rsi),%rax
  701e21:	xor    %edx,%edx
  701e23:	cmp    $0x1,%r8
  701e27:	je     701e54 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x84>
  701e29:	nopl   0x0(%rax)
  701e30:	mov    %rdx,%r10
  701e33:	mov    %r8,%r11
  701e36:	shr    $1,%r11
  701e39:	add    %r11,%rdx
  701e3c:	mov    %rdx,%rbx
  701e3f:	shl    $0x4,%rbx
  701e43:	cmp    %rcx,(%rax,%rbx,1)
  701e47:	cmova  %r10,%rdx
  701e4b:	sub    %r11,%r8
  701e4e:	cmp    $0x1,%r8
  701e52:	ja     701e30 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x60>
  701e54:	mov    %rdx,%r10
  701e57:	shl    $0x4,%r10
  701e5b:	xor    %r8d,%r8d
  701e5e:	cmp    %rcx,(%rax,%r10,1)
  701e62:	setbe  %r8b
  701e66:	add    %rdx,%r8
  701e69:	je     701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e6b:	shl    $0x4,%r8
  701e6f:	mov    %rcx,%rdx
  701e72:	sub    -0x10(%rax,%r8,1),%rdx
  701e77:	mov    -0x4(%rax,%r8,1),%r10d
  701e7c:	cmp    %r10,%rdx
  701e7f:	jae    701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e81:	add    %r8,%rax
  701e84:	mov    -0x8(%rax),%eax
  701e87:	add    %rax,%rdx
  701e8a:	jmp    701f02 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x132>
  701e8c:	mov    %rcx,%rdx
  701e8f:	sub    0x1f0(%rsi),%rdx
  701e96:	jb     701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701e98:	cmp    0x1f8(%rsi),%rdx
  701e9f:	jb     701f02 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x132>
  701ea1:	mov    %r9,(%rdi)
  701ea4:	pop    %rbx
  701ea5:	ret
  701ea6:	mov    0x1f8(%rsi),%rdx
  701ead:	test   %rdx,%rdx
  701eb0:	je     701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701eb2:	mov    0x1f0(%rsi),%rax
  701eb9:	cmp    $0x1,%rdx
  701ebd:	jne    701ec6 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xf6>
  701ebf:	cmp    %rcx,(%rax)
  701ec2:	jne    701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701ec4:	jmp    701eff <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x12f>
  701ec6:	xor    %r8d,%r8d
  701ec9:	nopl   0x0(%rax)
  701ed0:	mov    %r8,%r10
  701ed3:	mov    %rdx,%r11
  701ed6:	shr    $1,%r11
  701ed9:	add    %r11,%r8
  701edc:	lea    (%r8,%r8,2),%rbx
  701ee0:	cmp    %rcx,(%rax,%rbx,4)
  701ee4:	cmova  %r10,%r8
  701ee8:	sub    %r11,%rdx
  701eeb:	cmp    $0x1,%rdx
  701eef:	ja     701ed0 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x100>
  701ef1:	lea    (%r8,%r8,2),%rdx
  701ef5:	cmp    %rcx,(%rax,%rdx,4)
  701ef9:	jne    701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  701efb:	lea    (%rax,%rdx,4),%rax
  701eff:	mov    0x8(%rax),%edx
  701f02:	mov    0x650(%rsi),%rax
  701f09:	test   %rax,%rax
  701f0c:	je     701f9e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  701f12:	mov    0x658(%rsi),%r8
  701f19:	test   %r8,%r8
  701f1c:	je     701f8e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1be>
  701f1e:	mov    %r8,%r10
  701f21:	and    $0x7,%r10
  701f25:	je     701f47 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x177>
  701f27:	xor    %r11d,%r11d
  701f2a:	nopw   0x0(%rax,%rax,1)
  701f30:	mov    0x590(%rax),%rax
  701f37:	inc    %r11
  701f3a:	cmp    %r11,%r10
  701f3d:	jne    701f30 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x160>
  701f3f:	mov    %r8,%r10
  701f42:	sub    %r11,%r10
  701f45:	jmp    701f4a <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x17a>
  701f47:	mov    %r8,%r10
  701f4a:	cmp    $0x8,%r8
  701f4e:	jb     701f8e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1be>
  701f50:	mov    0x590(%rax),%rax
  701f57:	mov    0x590(%rax),%rax
  701f5e:	mov    0x590(%rax),%rax
  701f65:	mov    0x590(%rax),%rax
  701f6c:	mov    0x590(%rax),%rax
  701f73:	mov    0x590(%rax),%rax
  701f7a:	mov    0x590(%rax),%rax
  701f81:	mov    0x590(%rax),%rax
  701f88:	add    $0xfffffffffffffff8,%r10
  701f8c:	jne    701f50 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x180>
  701f8e:	cmpw   $0x0,0x58a(%rax)
  701f96:	je     701f9e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  701f98:	cmpq   $0x0,(%rax)
  701f9c:	je     701fae <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1de>
  701f9e:	mov    %rdx,0x8(%rdi)
  701fa2:	mov    $0xfffffffffffffffe,%r9
  701fa9:	mov    %r9,(%rdi)
  701fac:	pop    %rbx
  701fad:	ret
  701fae:	mov    0x2d8(%rsi),%rax
  701fb5:	cmp    %rax,%rdx
  701fb8:	jae    702072 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x2a2>
  701fbe:	mov    0x2d0(%rsi),%r10
  701fc5:	mov    $0xffffffff,%r11d
  701fcb:	mov    %rdx,%r8
  701fce:	lea    (%r8,%r8,4),%r8
  701fd2:	mov    0x20(%r10,%r8,8),%ebx
  701fd7:	and    $0xf,%ebx
  701fda:	cmp    $0x9,%ebx
  701fdd:	ja     702059 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x289>
  701fdf:	cmp    $0x5,%ebx
  701fe2:	je     702009 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x239>
  701fe4:	lea    (%r10,%r8,8),%r8
  701fe8:	mov    0x18(%r8),%r8d
  701fec:	cmp    %r11,%r8
  701fef:	je     701f9e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  701ff1:	cmp    %r8,%rax
  701ff4:	ja     701fce <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1fe>
  701ff6:	lea    0x378283(%rip),%rdx        # a7a280 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xb40>
  701ffd:	mov    %r8,%rdi
  702000:	mov    %rax,%rsi
  702003:	call   *0x3a1587(%rip)        # aa3590 <_DYNAMIC+0x350>
  702009:	cmpq   $0xffffffffffffffff,0x5c0(%rsi)
  702011:	mov    0x5b0(%rsi),%r8
  702018:	mov    0x5b8(%rsi),%rax
  70201f:	je     702039 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x269>
  702021:	cmpw   $0x0,0x5e0(%rsi)
  702029:	js     702039 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x269>
  70202b:	mov    0x5c8(%rsi),%r8
  702032:	mov    0x5d0(%rsi),%rax
  702039:	shl    $0x6,%rax
  70203d:	test   %rax,%rax
  702040:	je     701ea1 <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0xd1>
  702046:	add    $0xffffffffffffffc0,%rax
  70204a:	cmp    %rcx,0x20(%r8)
  70204e:	lea    0x40(%r8),%r8
  702052:	jne    70203d <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x26d>
  702054:	jmp    701f9e <<gpui::runtime::Runtime<owner_source_control::Model>>::resolve_index+0x1ce>
  702059:	lea    -0x6a58eb(%rip),%rdi        # 5c775 <anon.079f5e587c394fcac2765eb4d0cf0bc2.119.llvm.6319143315422321905+0x2e6d>
  702060:	lea    0x378279(%rip),%rdx        # a7a2e0 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xba0>
  702067:	mov    $0x83,%esi
  70206c:	call   *0x3a146e(%rip)        # aa34e0 <_DYNAMIC+0x2a0>
  702072:	mov    %rdx,%r8
  702075:	lea    0x378204(%rip),%rdx        # a7a280 <anon.5e03974c1bf71bf1d53a773ad2c8bd97.10.llvm.5361482046767298352+0xb40>
  70207c:	mov    %r8,%rdi
  70207f:	mov    %rax,%rsi
  702082:	call   *0x3a1508(%rip)        # aa3590 <_DYNAMIC+0x350>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000007294b0 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  7294b0:	push   %rbx
  7294b1:	sub    $0x40,%rsp
  7294b5:	mov    0x130(%rdi),%rbx
  7294bc:	test   %rbx,%rbx
  7294bf:	je     729566 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xb6>
  7294c5:	cmpb   $0x0,0x756(%rbx)
  7294cc:	jne    72956d <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xbd>
  7294d2:	mov    $0x12,%eax
  7294d7:	cmpb   $0x1,0x752(%rbx)
  7294de:	jne    729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  7294e4:	cmpb   $0x0,0x753(%rbx)
  7294eb:	jne    729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  7294f1:	cmpb   $0x0,0x754(%rbx)
  7294f8:	je     729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  7294fa:	cmpq   $0xffffffffffffffff,0x5c0(%rbx)
  729502:	jne    729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  729504:	mov    0x698(%rbx),%rcx
  72950b:	cmp    0x6a0(%rbx),%rcx
  729512:	jne    729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  729514:	mov    0x6b0(%rbx),%rcx
  72951b:	cmp    0x6a8(%rbx),%rcx
  729522:	jne    729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  729524:	movss  0x748(%rbx),%xmm2
  72952c:	ucomiss 0x74c(%rbx),%xmm2
  729533:	jne    729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  729535:	jp     729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  729537:	mov    %rbx,%rdi
  72953a:	call   709e20 <<gpui::runtime::Runtime<owner_source_control::Model>>::hit>
  72953f:	cmp    $0x1,%rax
  729543:	jne    72955e <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xae>
  729545:	add    $0x5e8,%rbx
  72954c:	mov    %rbx,%rdi
  72954f:	mov    %rdx,%rsi
  729552:	call   *0x37a090(%rip)        # aa35e8 <_DYNAMIC+0x3a8>
  729558:	add    $0x40,%rsp
  72955c:	pop    %rbx
  72955d:	ret
  72955e:	xor    %eax,%eax
  729560:	add    $0x40,%rsp
  729564:	pop    %rbx
  729565:	ret
  729566:	mov    $0xd,%eax
  72956b:	jmp    729572 <owner_source_control::source_hit::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xc2>
  72956d:	mov    $0xe,%eax
  729572:	mov    %rax,0x8(%rsp)
  729577:	lea    -0x6cc1be(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  72957e:	lea    0x351d8b(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  729585:	lea    0x351b04(%rip),%r8        # a7b090 <anon.2c5f4fb4c1947b150052a90f1fdbb632.12.llvm.17652699647177372958+0xc8>
  72958c:	lea    0x8(%rsp),%rdx
  729591:	mov    $0x2b,%esi
  729596:	call   *0x37a03c(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72959c:	ud2
  72959e:	mov    %rax,%rbx
  7295a1:	lea    0x8(%rsp),%rdi
  7295a6:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7295ab:	mov    %rbx,%rdi
  7295ae:	call   a78310 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000007295c0 <owner_source_control::source_set::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  7295c0:	push   %rbx
  7295c1:	sub    $0xd0,%rsp
  7295c8:	mov    %esi,%ecx
  7295ca:	mov    %rdi,%rsi
  7295cd:	mov    0x351af4(%rip),%rax        # a7b0c8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x20>
  7295d4:	mov    %rax,0x20(%rsp)
  7295d9:	movups 0x351ad8(%rip),%xmm0        # a7b0b8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x10>
  7295e0:	movaps %xmm0,0x10(%rsp)
  7295e5:	movups 0x351abc(%rip),%xmm0        # a7b0a8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744>
  7295ec:	movaps %xmm0,(%rsp)
  7295f0:	lea    0x68(%rsp),%rdi
  7295f5:	mov    %rsp,%rdx
  7295f8:	call   6e8d30 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::set::<u32, gpui::source::Source<owner_source_control::Model, u32>>>
  7295fd:	cmpl   $0xffffffff,0x68(%rsp)
  729602:	jne    72960d <owner_source_control::source_set::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x4d>
  729604:	add    $0xd0,%rsp
  72960b:	pop    %rbx
  72960c:	ret
  72960d:	mov    0xc8(%rsp),%rax
  729615:	mov    %rax,0x60(%rsp)
  72961a:	movups 0xb8(%rsp),%xmm0
  729622:	movaps %xmm0,0x50(%rsp)
  729627:	movups 0xa8(%rsp),%xmm0
  72962f:	movaps %xmm0,0x40(%rsp)
  729634:	movups 0x68(%rsp),%xmm0
  729639:	movups 0x78(%rsp),%xmm1
  72963e:	movups 0x88(%rsp),%xmm2
  729646:	movups 0x98(%rsp),%xmm3
  72964e:	movaps %xmm3,0x30(%rsp)
  729653:	movaps %xmm2,0x20(%rsp)
  729658:	movaps %xmm1,0x10(%rsp)
  72965d:	movaps %xmm0,(%rsp)
  729661:	lea    -0x6cc2a8(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  729668:	lea    0x351ce1(%rip),%rcx        # a7b350 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x2a8>
  72966f:	lea    0x351a5a(%rip),%r8        # a7b0d0 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x28>
  729676:	mov    %rsp,%rdx
  729679:	mov    $0x2b,%esi
  72967e:	call   *0x379f54(%rip)        # aa35d8 <_DYNAMIC+0x398>
  729684:	ud2
  729686:	mov    %rax,%rbx
  729689:	cmpq   $0x2,(%rsp)
  72968e:	lea    0x30(%rsp),%rax
  729693:	lea    0x8(%rsp),%rdi
  729698:	cmovb  %rax,%rdi
  72969c:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  7296a1:	mov    %rbx,%rdi
  7296a4:	call   a78310 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000007296b0 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  7296b0:	push   %rbx
  7296b1:	sub    $0x40,%rsp
  7296b5:	mov    0x130(%rsi),%rsi
  7296bc:	test   %rsi,%rsi
  7296bf:	je     729725 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x75>
  7296c1:	cmpb   $0x0,0x756(%rsi)
  7296c8:	jne    72972c <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x7c>
  7296ca:	cmpb   $0x1,0x754(%rsi)
  7296d1:	jne    729733 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x83>
  7296d3:	mov    $0x11,%eax
  7296d8:	cmp    0x5e8(%rsi),%rdx
  7296df:	jne    729738 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  7296e1:	mov    0x5b0(%rsi),%rdx
  7296e8:	mov    0x5b8(%rsi),%rsi
  7296ef:	shl    $0x6,%rsi
  7296f3:	xor    %r8d,%r8d
  7296f6:	mov    %rdx,%r9
  7296f9:	nopl   0x0(%rax)
  729700:	cmp    %r8,%rsi
  729703:	je     729738 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  729705:	add    $0x40,%r8
  729709:	cmp    %rcx,0x20(%r9)
  72970d:	lea    0x40(%r9),%r9
  729711:	jne    729700 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x50>
  729713:	movups -0x30(%rdx,%r8,1),%xmm0
  729719:	movups %xmm0,(%rdi)
  72971c:	mov    %rdi,%rax
  72971f:	add    $0x40,%rsp
  729723:	pop    %rbx
  729724:	ret
  729725:	mov    $0xd,%eax
  72972a:	jmp    729738 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  72972c:	mov    $0xe,%eax
  729731:	jmp    729738 <owner_source_control::source_query::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x88>
  729733:	mov    $0x12,%eax
  729738:	mov    %rax,0x8(%rsp)
  72973d:	lea    -0x6cc384(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  729744:	lea    0x351bc5(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  72974b:	lea    0x351996(%rip),%r8        # a7b0e8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x40>
  729752:	lea    0x8(%rsp),%rdx
  729757:	mov    $0x2b,%esi
  72975c:	call   *0x379e76(%rip)        # aa35d8 <_DYNAMIC+0x398>
  729762:	ud2
  729764:	mov    %rax,%rbx
  729767:	lea    0x8(%rsp),%rdi
  72976c:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  729771:	mov    %rbx,%rdi
  729774:	call   a78310 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000729780 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  729780:	push   %r15
  729782:	push   %r14
  729784:	push   %rbx
  729785:	sub    $0x70,%rsp
  729789:	mov    %rdi,%rbx
  72978c:	mov    0x130(%rdi),%r15
  729793:	test   %r15,%r15
  729796:	je     7297e2 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x62>
  729798:	mov    %rdx,%rcx
  72979b:	mov    %rsi,%rdx
  72979e:	mov    %r15,(%rsp)
  7297a2:	mov    %rbx,0x8(%rsp)
  7297a7:	lea    0x38(%rsp),%rdi
  7297ac:	mov    %rsp,%rsi
  7297af:	call   6f2f00 <<gpui::runtime::RuntimeMut<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::activate>
  7297b4:	cmpb   $0x0,0x756(%r15)
  7297bc:	jne    7297c8 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x48>
  7297be:	cmpq   $0xffffffffffffffff,0x698(%r15)
  7297c6:	jne    7297d0 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x50>
  7297c8:	mov    %rbx,%rdi
  7297cb:	call   7355c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  7297d0:	cmpq   $0xfffffffffffffffe,0x38(%rsp)
  7297d6:	jne    7297f9 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x79>
  7297d8:	add    $0x70,%rsp
  7297dc:	pop    %rbx
  7297dd:	pop    %r14
  7297df:	pop    %r15
  7297e1:	ret
  7297e2:	movq   $0xd,0x38(%rsp)
  7297eb:	movq   $0x0,0x40(%rsp)
  7297f4:	mov    %rbx,0x48(%rsp)
  7297f9:	mov    0x68(%rsp),%rax
  7297fe:	mov    %rax,0x30(%rsp)
  729803:	mov    0x38(%rsp),%rax
  729808:	mov    0x40(%rsp),%rcx
  72980d:	mov    0x48(%rsp),%rdx
  729812:	mov    0x50(%rsp),%rsi
  729817:	movups 0x58(%rsp),%xmm0
  72981c:	movaps %xmm0,0x20(%rsp)
  729821:	mov    %rdx,0x10(%rsp)
  729826:	mov    %rsi,0x18(%rsp)
  72982b:	mov    %rax,(%rsp)
  72982f:	mov    %rcx,0x8(%rsp)
  729834:	lea    -0x6cc47b(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  72983b:	lea    0x351ace(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  729842:	lea    0x3518b7(%rip),%r8        # a7b100 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x58>
  729849:	mov    %rsp,%rdx
  72984c:	mov    $0x2b,%esi
  729851:	call   *0x379d81(%rip)        # aa35d8 <_DYNAMIC+0x398>
  729857:	ud2
  729859:	mov    %rax,%r14
  72985c:	cmpb   $0x0,0x756(%r15)
  729864:	jne    729870 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xf0>
  729866:	cmpq   $0xffffffffffffffff,0x698(%r15)
  72986e:	jne    729878 <owner_source_control::source_action::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xf8>
  729870:	mov    %rbx,%rdi
  729873:	call   7355c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  729878:	mov    %r14,%rdi
  72987b:	call   a78310 <_Unwind_Resume@plt>
  729880:	call   *0x379c52(%rip)        # aa34d8 <_DYNAMIC+0x298>
  729886:	mov    %rax,%r14
  729889:	mov    %rsp,%rdi
  72988c:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  729891:	mov    %r14,%rdi
  729894:	call   a78310 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000007298a0 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  7298a0:	push   %r14
  7298a2:	push   %rbx
  7298a3:	sub    $0x98,%rsp
  7298aa:	mov    %rdi,%rbx
  7298ad:	mov    $0xffffffff,%eax
  7298b2:	mov    %rax,0x78(%rsp)
  7298b7:	movq   $0x0,0x80(%rsp)
  7298c3:	movss  %xmm0,0x4(%rsp)
  7298c9:	movss  %xmm1,0x8(%rsp)
  7298cf:	movl   $0x0,(%rsp)
  7298d6:	lea    0x40(%rsp),%rdi
  7298db:	lea    0x78(%rsp),%rdx
  7298e0:	mov    %rsp,%rcx
  7298e3:	mov    %rbx,%rsi
  7298e6:	call   6f4fe0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  7298eb:	cmpl   $0xfffffffe,0x40(%rsp)
  7298f0:	jne    72994b <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xab>
  7298f2:	movl   $0x2,(%rsp)
  7298f9:	lea    0x40(%rsp),%rdi
  7298fe:	lea    0x78(%rsp),%rdx
  729903:	mov    %rsp,%rcx
  729906:	mov    %rbx,%rsi
  729909:	call   6f4fe0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  72990e:	cmpl   $0xfffffffe,0x40(%rsp)
  729913:	jne    72999d <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0xfd>
  729919:	movl   $0x3,(%rsp)
  729920:	lea    0x40(%rsp),%rdi
  729925:	lea    0x78(%rsp),%rdx
  72992a:	mov    %rsp,%rcx
  72992d:	mov    %rbx,%rsi
  729930:	call   6f4fe0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::pointer_event>
  729935:	cmpl   $0xfffffffe,0x40(%rsp)
  72993a:	jne    7299ec <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x14c>
  729940:	add    $0x98,%rsp
  729947:	pop    %rbx
  729948:	pop    %r14
  72994a:	ret
  72994b:	mov    0x70(%rsp),%rax
  729950:	mov    %rax,0x30(%rsp)
  729955:	movups 0x40(%rsp),%xmm0
  72995a:	movups 0x50(%rsp),%xmm1
  72995f:	movups 0x60(%rsp),%xmm2
  729964:	movaps %xmm2,0x20(%rsp)
  729969:	movaps %xmm1,0x10(%rsp)
  72996e:	movaps %xmm0,(%rsp)
  729972:	lea    -0x6cc5b9(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  729979:	lea    0x351990(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  729980:	lea    0x351791(%rip),%r8        # a7b118 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x70>
  729987:	mov    %rsp,%rbx
  72998a:	mov    $0x2b,%esi
  72998f:	mov    %rbx,%rdx
  729992:	call   *0x379c40(%rip)        # aa35d8 <_DYNAMIC+0x398>
  729998:	jmp    729a39 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x199>
  72999d:	mov    0x70(%rsp),%rax
  7299a2:	mov    %rax,0x30(%rsp)
  7299a7:	movups 0x40(%rsp),%xmm0
  7299ac:	movups 0x50(%rsp),%xmm1
  7299b1:	movups 0x60(%rsp),%xmm2
  7299b6:	movaps %xmm2,0x20(%rsp)
  7299bb:	movaps %xmm1,0x10(%rsp)
  7299c0:	movaps %xmm0,(%rsp)
  7299c4:	lea    -0x6cc60b(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  7299cb:	lea    0x35193e(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  7299d2:	lea    0x351757(%rip),%r8        # a7b130 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x88>
  7299d9:	mov    %rsp,%rbx
  7299dc:	mov    $0x2b,%esi
  7299e1:	mov    %rbx,%rdx
  7299e4:	call   *0x379bee(%rip)        # aa35d8 <_DYNAMIC+0x398>
  7299ea:	jmp    729a39 <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x199>
  7299ec:	mov    0x70(%rsp),%rax
  7299f1:	mov    %rax,0x30(%rsp)
  7299f6:	movups 0x40(%rsp),%xmm0
  7299fb:	movups 0x50(%rsp),%xmm1
  729a00:	movups 0x60(%rsp),%xmm2
  729a05:	movaps %xmm2,0x20(%rsp)
  729a0a:	movaps %xmm1,0x10(%rsp)
  729a0f:	movaps %xmm0,(%rsp)
  729a13:	lea    -0x6cc65a(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  729a1a:	lea    0x3518ef(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  729a21:	lea    0x351720(%rip),%r8        # a7b148 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0xa0>
  729a28:	mov    %rsp,%rbx
  729a2b:	mov    $0x2b,%esi
  729a30:	mov    %rbx,%rdx
  729a33:	call   *0x379b9f(%rip)        # aa35d8 <_DYNAMIC+0x398>
  729a39:	ud2
  729a3b:	jmp    729a3f <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x19f>
  729a3d:	jmp    729a3f <owner_source_control::source_pointer::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x19f>
  729a3f:	mov    %rax,%r14
  729a42:	mov    %rbx,%rdi
  729a45:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  729a4a:	mov    %r14,%rdi
  729a4d:	call   a78310 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000729a60 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>:
  729a60:	push   %rbx
  729a61:	sub    $0x100,%rsp
  729a68:	mov    %rdi,%rbx
  729a6b:	mov    %rsp,%rdi
  729a6e:	mov    $0x8,%edx
  729a73:	mov    %rbx,%rsi
  729a76:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  729a7b:	cmpl   $0xffffffff,(%rsp)
  729a7f:	jne    729b7c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  729a85:	testb  $0x1,0x48(%rsp)
  729a8a:	je     729b73 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  729a90:	mov    %rsp,%rdi
  729a93:	mov    $0x8,%edx
  729a98:	mov    %rbx,%rsi
  729a9b:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  729aa0:	cmpl   $0xffffffff,(%rsp)
  729aa4:	jne    729b7c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  729aaa:	cmpb   $0x1,0x48(%rsp)
  729aaf:	jne    729b73 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  729ab5:	mov    %rsp,%rdi
  729ab8:	mov    $0x8,%edx
  729abd:	mov    %rbx,%rsi
  729ac0:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  729ac5:	cmpl   $0xffffffff,(%rsp)
  729ac9:	jne    729b7c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  729acf:	cmpb   $0x1,0x48(%rsp)
  729ad4:	jne    729b73 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  729ada:	mov    %rsp,%rdi
  729add:	mov    $0x8,%edx
  729ae2:	mov    %rbx,%rsi
  729ae5:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  729aea:	cmpl   $0xffffffff,(%rsp)
  729aee:	jne    729b7c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  729af4:	cmpb   $0x1,0x48(%rsp)
  729af9:	jne    729b73 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  729afb:	mov    %rsp,%rdi
  729afe:	mov    $0x8,%edx
  729b03:	mov    %rbx,%rsi
  729b06:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  729b0b:	cmpl   $0xffffffff,(%rsp)
  729b0f:	jne    729b7c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  729b11:	cmpb   $0x1,0x48(%rsp)
  729b16:	jne    729b73 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  729b18:	mov    %rsp,%rdi
  729b1b:	mov    $0x8,%edx
  729b20:	mov    %rbx,%rsi
  729b23:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  729b28:	cmpl   $0xffffffff,(%rsp)
  729b2c:	jne    729b7c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  729b2e:	cmpb   $0x1,0x48(%rsp)
  729b33:	jne    729b73 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  729b35:	mov    %rsp,%rdi
  729b38:	mov    $0x8,%edx
  729b3d:	mov    %rbx,%rsi
  729b40:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  729b45:	cmpl   $0xffffffff,(%rsp)
  729b49:	jne    729b7c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  729b4b:	cmpb   $0x1,0x48(%rsp)
  729b50:	jne    729b73 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x113>
  729b52:	mov    %rsp,%rdi
  729b55:	mov    $0x8,%edx
  729b5a:	mov    %rbx,%rsi
  729b5d:	call   6f3620 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::deliver_ready>
  729b62:	cmpl   $0xffffffff,(%rsp)
  729b66:	jne    729b7c <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x11c>
  729b68:	cmpb   $0x1,0x48(%rsp)
  729b6d:	je     729c0d <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>+0x1ad>
  729b73:	add    $0x100,%rsp
  729b7a:	pop    %rbx
  729b7b:	ret
  729b7c:	movups 0x70(%rsp),%xmm0
  729b81:	movaps %xmm0,0xf0(%rsp)
  729b89:	movups 0x60(%rsp),%xmm0
  729b8e:	movaps %xmm0,0xe0(%rsp)
  729b96:	movups 0x50(%rsp),%xmm0
  729b9b:	movaps %xmm0,0xd0(%rsp)
  729ba3:	movups 0x40(%rsp),%xmm0
  729ba8:	movaps %xmm0,0xc0(%rsp)
  729bb0:	movups (%rsp),%xmm0
  729bb4:	movups 0x10(%rsp),%xmm1
  729bb9:	movups 0x20(%rsp),%xmm2
  729bbe:	movups 0x30(%rsp),%xmm3
  729bc3:	movaps %xmm3,0xb0(%rsp)
  729bcb:	movaps %xmm2,0xa0(%rsp)
  729bd3:	movaps %xmm1,0x90(%rsp)
  729bdb:	movaps %xmm0,0x80(%rsp)
  729be3:	lea    -0x6cc82a(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  729bea:	lea    0x35173f(%rip),%rcx        # a7b330 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x288>
  729bf1:	lea    0x351580(%rip),%r8        # a7b178 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0xd0>
  729bf8:	lea    0x80(%rsp),%rdx
  729c00:	mov    $0x2b,%esi
  729c05:	call   *0x3799cd(%rip)        # aa35d8 <_DYNAMIC+0x398>
  729c0b:	ud2
  729c0d:	lea    -0x6cc9b7(%rip),%rdi        # 5d25d <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x5>
  729c14:	lea    0x351545(%rip),%rdx        # a7b160 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0xb8>
  729c1b:	mov    $0x7b,%esi
  729c20:	call   *0x3798ba(%rip)        # aa34e0 <_DYNAMIC+0x2a0>
  729c26:	mov    %rax,%rbx
  729c29:	lea    0xc8(%rsp),%rdi
  729c31:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  729c36:	mov    %rbx,%rdi
  729c39:	call   a78310 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072db00 <owner_source_control::main>:
  72db00:	push   %rbp
  72db01:	push   %r15
  72db03:	push   %r14
  72db05:	push   %r13
  72db07:	push   %r12
  72db09:	push   %rbx
  72db0a:	sub    $0x428,%rsp
  72db11:	movq   $0x2,0x2d0(%rsp)
  72db1d:	lea    0x138(%rsp),%rdi
  72db25:	lea    0x2d0(%rsp),%rsi
  72db2d:	call   718890 <allocation_counter::measure::<owner_source_control::main::{closure#0}>>
  72db32:	mov    0x2d0(%rsp),%rbx
  72db3a:	cmp    $0x2,%rbx
  72db3e:	je     72df46 <owner_source_control::main+0x446>
  72db44:	mov    0x408(%rsp),%r14
  72db4c:	mov    0x410(%rsp),%r15
  72db54:	lea    0x2d8(%rsp),%rsi
  72db5c:	mov    0x418(%rsp),%r12
  72db64:	mov    0x420(%rsp),%r13
  72db6c:	lea    0x1a0(%rsp),%rdi
  72db74:	mov    $0x130,%edx
  72db79:	call   *0x375931(%rip)        # aa34b0 <memcpy@GLIBC_2.14>
  72db7f:	mov    %rbx,0x198(%rsp)
  72db87:	mov    %r12,0xd8(%rsp)
  72db8f:	mov    %r13,0xe0(%rsp)
  72db97:	lea    0x198(%rsp),%rdi
  72db9f:	call   729a60 <owner_source_control::drain::<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>
  72dba4:	lea    -0x6d5e1b(%rip),%rcx        # 57d90 <anon.079f5e587c394fcac2765eb4d0cf0bc2.312.llvm.6319143315422321905+0x58>
  72dbab:	lea    0x90(%rsp),%rdi
  72dbb3:	lea    0x198(%rsp),%rbx
  72dbbb:	mov    $0x4,%r8d
  72dbc1:	mov    %rbx,%rsi
  72dbc4:	mov    $0x5,%edx
  72dbc9:	call   6fbad0 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::find>
  72dbce:	cmpl   $0xfffffffe,0x90(%rsp)
  72dbd6:	jne    72df53 <owner_source_control::main+0x453>
  72dbdc:	movups 0x98(%rsp),%xmm0
  72dbe4:	movaps %xmm0,0x120(%rsp)
  72dbec:	mov    0x2c8(%rsp),%rax
  72dbf4:	test   %rax,%rax
  72dbf7:	je     72e065 <owner_source_control::main+0x565>
  72dbfd:	xorps  %xmm0,%xmm0
  72dc00:	movups %xmm0,0x728(%rax)
  72dc07:	movups %xmm0,0x718(%rax)
  72dc0e:	movups %xmm0,0x708(%rax)
  72dc15:	movups %xmm0,0x6f8(%rax)
  72dc1c:	movups %xmm0,0x6e8(%rax)
  72dc23:	movups %xmm0,0x6d8(%rax)
  72dc2a:	movq   $0x0,0x738(%rax)
  72dc35:	cmpb   $0x0,0x756(%rax)
  72dc3c:	jne    72dc48 <owner_source_control::main+0x148>
  72dc3e:	cmpq   $0xffffffffffffffff,0x698(%rax)
  72dc46:	jne    72dc55 <owner_source_control::main+0x155>
  72dc48:	lea    0x198(%rsp),%rdi
  72dc50:	call   7355c0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::remote::LaneSet<owner_source_control::Model>>::close>
  72dc55:	lea    0x168(%rsp),%rdi
  72dc5d:	lea    0x198(%rsp),%rsi
  72dc65:	lea    0x120(%rsp),%rdx
  72dc6d:	call   718b50 <allocation_counter::measure::<owner_source_control::main::{closure#1}>>
  72dc72:	mov    0x2c8(%rsp),%rbx
  72dc7a:	test   %rbx,%rbx
  72dc7d:	je     72dfae <owner_source_control::main+0x4ae>
  72dc83:	cmpl   $0x2b,0x2c0(%rbx)
  72dc8a:	jne    72dfde <owner_source_control::main+0x4de>
  72dc90:	movq   $0x0,(%rsp)
  72dc98:	movq   $0x0,0x10(%rsp)
  72dca1:	movq   $0x0,0x20(%rsp)
  72dcaa:	mov    %rbx,0x30(%rsp)
  72dcaf:	lea    -0x6d098b(%rip),%rax        # 5d32b <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0xd3>
  72dcb6:	mov    %rax,0x38(%rsp)
  72dcbb:	movq   $0x2,0x40(%rsp)
  72dcc4:	movb   $0x1,0x48(%rsp)
  72dcc9:	movb   $0xff,0x50(%rsp)
  72dcce:	lea    0x90(%rsp),%rbp
  72dcd6:	mov    %rsp,%rsi
  72dcd9:	mov    %rbp,%rdi
  72dcdc:	call   723be0 <<gpui::runtime::query::Query<owner_source_control::Model>>::count>
  72dce1:	mov    0x90(%rsp),%rcx
  72dce9:	mov    0x98(%rsp),%rax
  72dcf1:	cmp    $0xfffffffffffffffe,%rcx
  72dcf5:	jne    72e0a3 <owner_source_control::main+0x5a3>
  72dcfb:	test   %rax,%rax
  72dcfe:	je     72dff5 <owner_source_control::main+0x4f5>
  72dd04:	mov    0x2c8(%rsp),%rax
  72dd0c:	mov    $0x2,%r13b
  72dd0f:	test   %rax,%rax
  72dd12:	je     72e110 <owner_source_control::main+0x610>
  72dd18:	cmpb   $0x0,0x756(%rax)
  72dd1f:	jne    72e117 <owner_source_control::main+0x617>
  72dd25:	mov    %rsp,%rbx
  72dd28:	lea    0x198(%rsp),%r12
  72dd30:	mov    %rbx,%rdi
  72dd33:	mov    %r12,%rsi
  72dd36:	mov    %r14,%rdx
  72dd39:	mov    %r15,%rcx
  72dd3c:	call   7348e0 <<gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()> as gpui::reader::ReaderValues>::read>
  72dd41:	cmpl   $0x2,(%rsp)
  72dd45:	je     72e11e <owner_source_control::main+0x61e>
  72dd4b:	mov    0x18(%rsp),%rcx
  72dd50:	movzbl 0x20(%rsp),%r13d
  72dd56:	mov    0x21(%rsp),%rax
  72dd5b:	mov    %rax,0xe8(%rsp)
  72dd63:	mov    0x28(%rsp),%rax
  72dd68:	mov    %rax,0xef(%rsp)
  72dd70:	mov    0x30(%rsp),%eax
  72dd74:	movups 0x34(%rsp),%xmm0
  72dd79:	movaps %xmm0,0x90(%rsp)
  72dd81:	movups 0x44(%rsp),%xmm0
  72dd86:	movaps %xmm0,0xa0(%rsp)
  72dd8e:	movups 0x54(%rsp),%xmm0
  72dd93:	movaps %xmm0,0xb0(%rsp)
  72dd9b:	movups 0x61(%rsp),%xmm0
  72dda0:	movups %xmm0,0xbd(%rsp)
  72dda8:	cmpb   $0x2,0x71(%rsp)
  72ddad:	je     72e123 <owner_source_control::main+0x623>
  72ddb3:	test   %rcx,%rcx
  72ddb6:	je     72e013 <owner_source_control::main+0x513>
  72ddbc:	mov    %rcx,0x90(%rsp)
  72ddc4:	movabs $0x100000001,%rdx
  72ddce:	mov    %rdx,(%rsp)
  72ddd2:	cmp    %rdx,%rcx
  72ddd5:	jne    72e025 <owner_source_control::main+0x525>
  72dddb:	mov    %eax,(%rsp)
  72ddde:	cmp    $0x3,%eax
  72dde1:	jne    72e045 <owner_source_control::main+0x545>
  72dde7:	lea    0x138(%rsp),%rax
  72ddef:	mov    %rax,(%rsp)
  72ddf3:	lea    0xb06(%rip),%rbx        # 72e900 <<allocation_counter::AllocationInfo as core::fmt::Debug>::fmt>
  72ddfa:	mov    %rbx,0x8(%rsp)
  72ddff:	lea    -0x6de91c(%rip),%rdi        # 4f4ea <anon.4fc0b732051cd9c0c5e7a6e9d819518c.14.llvm.5251204661969696906+0xb0>
  72de06:	mov    %rsp,%rsi
  72de09:	call   *0x375d39(%rip)        # aa3b48 <_DYNAMIC+0x908>
  72de0f:	lea    0x168(%rsp),%rax
  72de17:	mov    %rax,(%rsp)
  72de1b:	mov    %rbx,0x8(%rsp)
  72de20:	lea    -0x6d8984(%rip),%rdi        # 554a3 <anon.96bf6b34351ddc2adfd2386f8abf053b.13.llvm.9730795237915355246+0x1ec>
  72de27:	mov    %rsp,%rsi
  72de2a:	call   *0x375d18(%rip)        # aa3b48 <_DYNAMIC+0x908>
  72de30:	movq   $0x138,0x90(%rsp)
  72de3c:	lea    0xd8(%rsp),%rax
  72de44:	mov    %rax,(%rsp)
  72de48:	mov    0x375c09(%rip),%rax        # aa3a58 <_DYNAMIC+0x818>
  72de4f:	mov    %rax,0x8(%rsp)
  72de54:	lea    0xe0(%rsp),%rcx
  72de5c:	mov    %rcx,0x10(%rsp)
  72de61:	mov    %rax,0x18(%rsp)
  72de66:	mov    %rbp,0x20(%rsp)
  72de6b:	mov    %rax,0x28(%rsp)
  72de70:	lea    -0x6dca50(%rip),%rdi        # 51427 <anon.7d84123d9385acd73700c435ae62cea9.21.llvm.12732996019173906566+0x92>
  72de77:	mov    %rsp,%rbx
  72de7a:	mov    %rbx,%rsi
  72de7d:	call   *0x375cc5(%rip)        # aa3b48 <_DYNAMIC+0x908>
  72de83:	mov    0x2c8(%rsp),%rax
  72de8b:	test   %rax,%rax
  72de8e:	je     72e189 <owner_source_control::main+0x689>
  72de94:	mov    0x738(%rax),%rcx
  72de9b:	mov    %rcx,0x60(%rsp)
  72dea0:	movups 0x728(%rax),%xmm0
  72dea7:	movaps %xmm0,0x50(%rsp)
  72deac:	movups 0x718(%rax),%xmm0
  72deb3:	movaps %xmm0,0x40(%rsp)
  72deb8:	movups 0x6d8(%rax),%xmm0
  72debf:	movups 0x6e8(%rax),%xmm1
  72dec6:	movups 0x6f8(%rax),%xmm2
  72decd:	movups 0x708(%rax),%xmm3
  72ded4:	movaps %xmm3,0x30(%rsp)
  72ded9:	movaps %xmm2,0x20(%rsp)
  72dede:	movaps %xmm1,0x10(%rsp)
  72dee3:	movaps %xmm0,(%rsp)
  72dee7:	mov    %rbx,0x90(%rsp)
  72deef:	lea    0xfaa(%rip),%rax        # 72eea0 <<gpui::runtime::Counters as core::fmt::Debug>::fmt>
  72def6:	mov    %rax,0x98(%rsp)
  72defe:	lea    -0x6de9fd(%rip),%rdi        # 4f508 <anon.4fc0b732051cd9c0c5e7a6e9d819518c.14.llvm.5251204661969696906+0xce>
  72df05:	lea    0x90(%rsp),%rsi
  72df0d:	call   *0x375c35(%rip)        # aa3b48 <_DYNAMIC+0x908>
  72df13:	lea    -0x6d0b95(%rip),%rdi        # 5d385 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x12d>
  72df1a:	mov    $0x77,%esi
  72df1f:	call   *0x375c23(%rip)        # aa3b48 <_DYNAMIC+0x908>
  72df25:	mov    %r12,(%rsp)
  72df29:	mov    %rsp,%rax
  72df2c:	mov    %r12,%rdi
  72df2f:	call   72c1c0 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  72df34:	add    $0x428,%rsp
  72df3b:	pop    %rbx
  72df3c:	pop    %r12
  72df3e:	pop    %r13
  72df40:	pop    %r14
  72df42:	pop    %r15
  72df44:	pop    %rbp
  72df45:	ret
  72df46:	lea    0x34d273(%rip),%rdi        # a7b1c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x118>
  72df4d:	call   *0x375575(%rip)        # aa34c8 <_DYNAMIC+0x288>
  72df53:	mov    0xc0(%rsp),%rax
  72df5b:	mov    %rax,0x30(%rsp)
  72df60:	movups 0x90(%rsp),%xmm0
  72df68:	movups 0xa0(%rsp),%xmm1
  72df70:	movups 0xb0(%rsp),%xmm2
  72df78:	movaps %xmm2,0x20(%rsp)
  72df7d:	movaps %xmm1,0x10(%rsp)
  72df82:	movaps %xmm0,(%rsp)
  72df86:	lea    -0x6d0c8d(%rip),%rdi        # 5d300 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0xa8>
  72df8d:	lea    0x34d37c(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  72df94:	lea    0x34d23d(%rip),%r8        # a7b1d8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x130>
  72df9b:	mov    %rsp,%rdx
  72df9e:	mov    $0x2b,%esi
  72dfa3:	call   *0x37562f(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72dfa9:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72dfae:	movq   $0xd,(%rsp)
  72dfb6:	lea    -0x6d0bfd(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  72dfbd:	lea    0x34d34c(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  72dfc4:	lea    0x34d23d(%rip),%r8        # a7b208 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x160>
  72dfcb:	mov    %rsp,%rdx
  72dfce:	mov    $0x2b,%esi
  72dfd3:	call   *0x3755ff(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72dfd9:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72dfde:	add    $0x2c0,%rbx
  72dfe5:	lea    0x34d2dc(%rip),%r9        # a7b2c8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x220>
  72dfec:	lea    -0x6d6123(%rip),%rdx        # 57ed0 <anon.b9a0c2ab0f2817fcb40a4a41c6d097bf.12.llvm.1156352485375507320+0x3c>
  72dff3:	jmp    72e053 <owner_source_control::main+0x553>
  72dff5:	lea    -0x6d0ccf(%rip),%rdi        # 5d32d <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0xd5>
  72dffc:	lea    0x34d235(%rip),%rdx        # a7b238 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x190>
  72e003:	mov    $0x34,%esi
  72e008:	call   *0x3754b2(%rip)        # aa34c0 <_DYNAMIC+0x280>
  72e00e:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72e013:	lea    0x34d24e(%rip),%rdi        # a7b268 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x1c0>
  72e01a:	call   *0x3754a8(%rip)        # aa34c8 <_DYNAMIC+0x288>
  72e020:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72e025:	lea    0x34d284(%rip),%r9        # a7b2b0 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x208>
  72e02c:	lea    0x90(%rsp),%rsi
  72e034:	mov    %rsp,%rdx
  72e037:	xor    %edi,%edi
  72e039:	xor    %ecx,%ecx
  72e03b:	call   732c35 <core::panicking::assert_failed::<gpui::source::FieldId, gpui::source::FieldId>>
  72e040:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72e045:	lea    0x34d24c(%rip),%r9        # a7b298 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x1f0>
  72e04c:	lea    -0x6d6237(%rip),%rdx        # 57e1c <anon.305d07fa6d8a71cc44514f8a1dc6c220.98.llvm.16405730940860663774+0x18>
  72e053:	xor    %edi,%edi
  72e055:	mov    %rbx,%rsi
  72e058:	xor    %ecx,%ecx
  72e05a:	call   *0x375af0(%rip)        # aa3b50 <_DYNAMIC+0x910>
  72e060:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72e065:	movq   $0xd,(%rsp)
  72e06d:	movq   $0x0,0x8(%rsp)
  72e076:	mov    %rbx,0x10(%rsp)
  72e07b:	lea    -0x6d0cc2(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  72e082:	lea    0x34d287(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  72e089:	lea    0x34d160(%rip),%r8        # a7b1f0 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x148>
  72e090:	mov    %rsp,%rdx
  72e093:	mov    $0x2b,%esi
  72e098:	call   *0x37553a(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72e09e:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72e0a3:	mov    0xc0(%rsp),%rdx
  72e0ab:	mov    %rdx,0x118(%rsp)
  72e0b3:	movups 0xa0(%rsp),%xmm0
  72e0bb:	movups 0xb0(%rsp),%xmm1
  72e0c3:	movups %xmm1,0x108(%rsp)
  72e0cb:	movups %xmm0,0xf8(%rsp)
  72e0d3:	mov    %rcx,0xe8(%rsp)
  72e0db:	mov    %rax,0xf0(%rsp)
  72e0e3:	lea    -0x6d0d2a(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  72e0ea:	lea    0x34d21f(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  72e0f1:	lea    0x34d128(%rip),%r8        # a7b220 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x178>
  72e0f8:	lea    0xe8(%rsp),%rdx
  72e100:	mov    $0x2b,%esi
  72e105:	call   *0x3754cd(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72e10b:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72e110:	mov    $0xd,%ecx
  72e115:	jmp    72e123 <owner_source_control::main+0x623>
  72e117:	mov    $0xe,%ecx
  72e11c:	jmp    72e123 <owner_source_control::main+0x623>
  72e11e:	mov    $0x29,%ecx
  72e123:	mov    %rcx,(%rsp)
  72e127:	mov    %r13b,0x8(%rsp)
  72e12c:	mov    0xe8(%rsp),%rcx
  72e134:	mov    0xef(%rsp),%rdx
  72e13c:	mov    %rcx,0x9(%rsp)
  72e141:	mov    %rdx,0x10(%rsp)
  72e146:	mov    %eax,0x18(%rsp)
  72e14a:	movaps 0x90(%rsp),%xmm0
  72e152:	movups %xmm0,0x1c(%rsp)
  72e157:	movups 0x9c(%rsp),%xmm0
  72e15f:	movups %xmm0,0x28(%rsp)
  72e164:	lea    -0x6d0dab(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  72e16b:	lea    0x34d19e(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  72e172:	lea    0x34d0d7(%rip),%r8        # a7b250 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x1a8>
  72e179:	mov    %rsp,%rdx
  72e17c:	mov    $0x2b,%esi
  72e181:	call   *0x375451(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72e187:	jmp    72e1bd <owner_source_control::main+0x6bd>
  72e189:	movq   $0xd,(%rsp)
  72e191:	movq   $0x0,0x8(%rsp)
  72e19a:	lea    -0x6d0e40(%rip),%rdi        # 5d361 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x109>
  72e1a1:	lea    0x34d168(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  72e1a8:	lea    0x34d0d1(%rip),%r8        # a7b280 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x1d8>
  72e1af:	mov    %rsp,%rdx
  72e1b2:	mov    $0x24,%esi
  72e1b7:	call   *0x37541b(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72e1bd:	ud2
  72e1bf:	jmp    72e1f5 <owner_source_control::main+0x6f5>
  72e1c1:	mov    %rax,%rbx
  72e1c4:	lea    0xe8(%rsp),%rdi
  72e1cc:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72e1d1:	jmp    72e205 <owner_source_control::main+0x705>
  72e1d3:	jmp    72e1f5 <owner_source_control::main+0x6f5>
  72e1d5:	mov    %rax,%rbx
  72e1d8:	cmpl   $0x2,0x2d0(%rsp)
  72e1e0:	je     72e212 <owner_source_control::main+0x712>
  72e1e2:	lea    0x2d0(%rsp),%rdi
  72e1ea:	call   72c1c0 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  72e1ef:	jmp    72e212 <owner_source_control::main+0x712>
  72e1f1:	jmp    72e1f5 <owner_source_control::main+0x6f5>
  72e1f3:	jmp    72e1f5 <owner_source_control::main+0x6f5>
  72e1f5:	mov    %rax,%rbx
  72e1f8:	mov    %rsp,%rdi
  72e1fb:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72e200:	jmp    72e205 <owner_source_control::main+0x705>
  72e202:	mov    %rax,%rbx
  72e205:	lea    0x198(%rsp),%rdi
  72e20d:	call   72c1c0 <core::ptr::drop_glue::<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>>
  72e212:	mov    %rbx,%rdi
  72e215:	call   a78310 <_Unwind_Resume@plt>
  72e21a:	call   *0x3752b8(%rip)        # aa34d8 <_DYNAMIC+0x298>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000072e220 <owner_source_control::open>:
  72e220:	push   %r15
  72e222:	push   %r14
  72e224:	push   %r12
  72e226:	push   %rbx
  72e227:	sub    $0x418,%rsp
  72e22e:	mov    %rdi,%rbx
  72e231:	movq   $0x0,0x68(%rsp)
  72e23a:	call   *0x375590(%rip)        # aa37d0 <_DYNAMIC+0x590>
  72e240:	movq   $0x0,0x1b8(%rsp)
  72e24c:	mov    %rax,0x1b0(%rsp)
  72e254:	movq   $0x0,0x1c8(%rsp)
  72e260:	mov    0x34ce61(%rip),%rax        # a7b0c8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x20>
  72e267:	mov    %rax,0x300(%rsp)
  72e26f:	movups 0x34ce42(%rip),%xmm0        # a7b0b8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x10>
  72e276:	movaps %xmm0,0x2f0(%rsp)
  72e27e:	movups 0x34ce23(%rip),%xmm0        # a7b0a8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744>
  72e285:	movaps %xmm0,0x2e0(%rsp)
  72e28d:	lea    0x68(%rsp),%rdi
  72e292:	lea    0x1b0(%rsp),%rsi
  72e29a:	lea    0x2e0(%rsp),%rdx
  72e2a2:	call   732010 <<gpui::reader::question::Questions<owner_source_control::Model>>::question_with::<gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>>>
  72e2a7:	cmpl   $0x2,0x68(%rsp)
  72e2ac:	je     72e410 <owner_source_control::open+0x1f0>
  72e2b2:	lea    0x2e0(%rsp),%rdi
  72e2ba:	lea    0x68(%rsp),%rsi
  72e2bf:	mov    $0x138,%edx
  72e2c4:	call   *0x3751e6(%rip)        # aa34b0 <memcpy@GLIBC_2.14>
  72e2ca:	mov    0x1a0(%rsp),%r15
  72e2d2:	mov    0x1a8(%rsp),%r12
  72e2da:	call   *0x3751c0(%rip)        # aa34a0 <_DYNAMIC+0x260>
  72e2e0:	mov    $0x4,%edi
  72e2e5:	mov    $0x1,%esi
  72e2ea:	call   *0x375190(%rip)        # aa3480 <_DYNAMIC+0x240>
  72e2f0:	test   %rax,%rax
  72e2f3:	je     72e4ab <owner_source_control::open+0x28b>
  72e2f9:	movl   $0x64656573,(%rax)
  72e2ff:	movq   $0x1,0x48(%rsp)
  72e308:	movq   $0x4,0x18(%rsp)
  72e311:	mov    %rax,0x20(%rsp)
  72e316:	movq   $0x4,0x28(%rsp)
  72e31f:	movl   $0x0,0x30(%rsp)
  72e327:	mov    %r15,0x38(%rsp)
  72e32c:	mov    %r12,0x40(%rsp)
  72e331:	movups 0x400(%rsp),%xmm0
  72e339:	movaps %xmm0,0x50(%rsp)
  72e33e:	movabs $0xb400000118,%rax
  72e348:	mov    %rax,0x10(%rsp)
  72e34d:	movl   $0x0,(%rsp)
  72e354:	movl   $0x434b0000,0x8(%rsp)
  72e35c:	movw   $0x0,0xc(%rsp)
  72e363:	lea    0x1b0(%rsp),%r14
  72e36b:	lea    0x2e0(%rsp),%rsi
  72e373:	mov    $0x118,%edx
  72e378:	mov    %r14,%rdi
  72e37b:	call   *0x37512f(%rip)        # aa34b0 <memcpy@GLIBC_2.14>
  72e381:	movaps 0x50(%rsp),%xmm0
  72e386:	movups %xmm0,0x2c8(%rsp)
  72e38e:	movq   $0x0,0x2d8(%rsp)
  72e39a:	lea    0x68(%rsp),%rdi
  72e39f:	lea    0x18(%rsp),%rsi
  72e3a4:	mov    %rsp,%rcx
  72e3a7:	movss  -0x6d665f(%rip),%xmm0        # 57d50 <anon.079f5e587c394fcac2765eb4d0cf0bc2.312.llvm.6319143315422321905+0x18>
  72e3af:	mov    %r14,%rdx
  72e3b2:	mov    $0x1,%r8d
  72e3b8:	xor    %r9d,%r9d
  72e3bb:	call   6fad80 <<gpui::runtime::Win<owner_source_control::Model, gpui::reader::question::QuestionSet<gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>, ()>>>::mount_lanes>
  72e3c0:	cmpl   $0x2,0x68(%rsp)
  72e3c5:	je     72e444 <owner_source_control::open+0x224>
  72e3c7:	lea    0x68(%rsp),%rsi
  72e3cc:	mov    $0x138,%edx
  72e3d1:	mov    %rbx,%rdi
  72e3d4:	call   *0x3750d6(%rip)        # aa34b0 <memcpy@GLIBC_2.14>
  72e3da:	mov    %r15,0x138(%rbx)
  72e3e1:	mov    %r12,0x140(%rbx)
  72e3e8:	movq   $0x28,0x148(%rbx)
  72e3f3:	movq   $0x138,0x150(%rbx)
  72e3fe:	mov    %rbx,%rax
  72e401:	add    $0x418,%rsp
  72e408:	pop    %rbx
  72e409:	pop    %r12
  72e40b:	pop    %r14
  72e40d:	pop    %r15
  72e40f:	ret
  72e410:	movzbl 0x70(%rsp),%eax
  72e415:	mov    %al,0x2e0(%rsp)
  72e41c:	lea    -0x6d1063(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  72e423:	lea    0x34cf46(%rip),%rcx        # a7b370 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x2c8>
  72e42a:	lea    0x34ceaf(%rip),%r8        # a7b2e0 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x238>
  72e431:	lea    0x2e0(%rsp),%rdx
  72e439:	mov    $0x2b,%esi
  72e43e:	call   *0x375194(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72e444:	mov    0xa0(%rsp),%rax
  72e44c:	mov    %rax,0x1e0(%rsp)
  72e454:	movups 0x70(%rsp),%xmm0
  72e459:	movups 0x80(%rsp),%xmm1
  72e461:	movups 0x90(%rsp),%xmm2
  72e469:	movaps %xmm2,0x1d0(%rsp)
  72e471:	movaps %xmm1,0x1c0(%rsp)
  72e479:	movaps %xmm0,0x1b0(%rsp)
  72e481:	lea    -0x6d10c8(%rip),%rdi        # 5d3c0 <anon.9e1adc519e45ee0094feacbcca2f7d65.2.llvm.16917318406874983744+0x168>
  72e488:	lea    0x34ce81(%rip),%rcx        # a7b310 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x268>
  72e48f:	lea    0x34ce62(%rip),%r8        # a7b2f8 <anon.9e1adc519e45ee0094feacbcca2f7d65.3.llvm.16917318406874983744+0x250>
  72e496:	lea    0x1b0(%rsp),%rdx
  72e49e:	mov    $0x2b,%esi
  72e4a3:	call   *0x37512f(%rip)        # aa35d8 <_DYNAMIC+0x398>
  72e4a9:	jmp    72e4bb <owner_source_control::open+0x29b>
  72e4ab:	mov    $0x1,%edi
  72e4b0:	mov    $0x4,%esi
  72e4b5:	call   *0x3750dd(%rip)        # aa3598 <_DYNAMIC+0x358>
  72e4bb:	ud2
  72e4bd:	mov    %rax,%rbx
  72e4c0:	lea    0x2e0(%rsp),%rdi
  72e4c8:	call   72c3e0 <core::ptr::drop_glue::<gpui::reader::question::Questions<owner_source_control::Model, gpui::reader::question::QuestionLane<owner_source_control::Model, gpui::source::Source<owner_source_control::Model, u32>, u32, u32, core::convert::Infallible, owner_source_control::open::{closure#0}, gpui::reader::question::SyncStarter<owner_source_control::start>, ()>>>>
  72e4cd:	jmp    72e4e2 <owner_source_control::open+0x2c2>
  72e4cf:	call   *0x375003(%rip)        # aa34d8 <_DYNAMIC+0x298>
  72e4d5:	mov    %rax,%rbx
  72e4d8:	lea    0x68(%rsp),%rdi
  72e4dd:	call   7328f0 <core::ptr::drop_glue::<core::option::Option<gpui_reactivity_state::request::OwnerScope>>>
  72e4e2:	mov    %rbx,%rdi
  72e4e5:	call   a78310 <_Unwind_Resume@plt>
  72e4ea:	call   *0x374fe8(%rip)        # aa34d8 <_DYNAMIC+0x298>
  72e4f0:	mov    %rax,%rbx
  72e4f3:	lea    0x1b0(%rsp),%rdi
  72e4fb:	call   72d070 <core::ptr::drop_glue::<gpui::runtime::Error>>
  72e500:	mov    %rbx,%rdi
  72e503:	call   a78310 <_Unwind_Resume@plt>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

00000000007391b0 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>>:
  7391b0:	push   %rbp
  7391b1:	push   %r15
  7391b3:	push   %r14
  7391b5:	push   %r13
  7391b7:	push   %r12
  7391b9:	push   %rbx
  7391ba:	sub    $0x28,%rsp
  7391be:	mov    %rcx,%r13
  7391c1:	mov    %rdx,%r12
  7391c4:	mov    %rdi,%rbx
  7391c7:	mov    (%rsi),%r14
  7391ca:	mov    %rdx,%rdi
  7391cd:	call   *0x18(%rsi)
  7391d0:	mov    %rax,0x8(%rsp)
  7391d5:	cmp    $0x1,%r14d
  7391d9:	jne    739227 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x77>
  7391db:	mov    0x20(%r13),%rbp
  7391df:	mov    0x28(%r13),%r15
  7391e3:	shl    $0x4,%r15
  7391e7:	xor    %r13d,%r13d
  7391ea:	nopw   0x0(%rax,%rax,1)
  7391f0:	cmp    %r13,%r15
  7391f3:	je     7392bc <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x10c>
  7391f9:	mov    0x0(%rbp,%r13,1),%rdi
  7391fe:	mov    0x8(%rbp,%r13,1),%rax
  739203:	call   *0x18(%rax)
  739206:	add    $0x10,%r13
  73920a:	cmp    %r14,%rax
  73920d:	jne    7391f0 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x40>
  73920f:	mov    -0x10(%rbp,%r13,1),%rdi
  739214:	mov    -0x8(%rbp,%r13,1),%rax
  739219:	mov    %r12,%rsi
  73921c:	call   *0x28(%rax)
  73921f:	mov    %rax,%rdi
  739222:	mov    %rdx,%rax
  739225:	jmp    73928a <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0xda>
  739227:	mov    0x50(%r13),%rbp
  73922b:	mov    0x58(%r13),%r13
  73922f:	shl    $0x4,%r13
  739233:	xor    %r15d,%r15d
  739236:	cs nopw 0x0(%rax,%rax,1)
  739240:	cmp    %r15,%r13
  739243:	je     7392bc <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x10c>
  739245:	mov    0x0(%rbp,%r15,1),%rdi
  73924a:	mov    0x8(%rbp,%r15,1),%rax
  73924f:	mov    %r14,%rsi
  739252:	call   *0x30(%rax)
  739255:	add    $0x10,%r15
  739259:	test   %al,%al
  73925b:	je     739240 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x90>
  73925d:	mov    -0x10(%rbp,%r15,1),%rsi
  739262:	mov    -0x8(%rbp,%r15,1),%rax
  739267:	lea    0x10(%rsp),%rdi
  73926c:	mov    %r12,%rdx
  73926f:	mov    %r14,%rcx
  739272:	call   *0x58(%rax)
  739275:	mov    0x10(%rsp),%rcx
  73927a:	mov    0x18(%rsp),%rdi
  73927f:	mov    0x20(%rsp),%rax
  739284:	cmp    $0xffffffffffffffff,%rcx
  739288:	jne    7392c4 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x114>
  73928a:	lea    0x342a47(%rip),%rdx        # a7bcd8 <anon.b8826df01f5428373db055732cad4b13.46.llvm.13662383007610045890+0x168>
  739291:	mov    0x8(%rsp),%r15
  739296:	mov    %r15,%rsi
  739299:	call   *0x20(%rax)
  73929c:	test   %al,%al
  73929e:	je     7392c9 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x119>
  7392a0:	mov    0x4(%r15),%eax
  7392a4:	movq   $0x0,0x8(%rbx)
  7392ac:	mov    %r15,0x10(%rbx)
  7392b0:	mov    %eax,0x18(%rbx)
  7392b3:	movq   $0xfffffffffffffffe,(%rbx)
  7392ba:	jmp    7392e1 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x131>
  7392bc:	mov    $0xb,%ecx
  7392c1:	mov    %r14,%rdi
  7392c4:	mov    %rdi,%r14
  7392c7:	jmp    7392ce <<gpui::source::Source<owner_source_control::Model, u32> as gpui::reader::inputs::QuestionInputs<owner_source_control::Model>>::resolve::<()>+0x11e>
  7392c9:	mov    $0xa,%ecx
  7392ce:	movq   $0x20,(%rbx)
  7392d5:	mov    %rcx,0x8(%rbx)
  7392d9:	mov    %r14,0x10(%rbx)
  7392dd:	mov    %rax,0x18(%rbx)
  7392e1:	mov    %rbx,%rax
  7392e4:	add    $0x28,%rsp
  7392e8:	pop    %rbx
  7392e9:	pop    %r12
  7392eb:	pop    %r13
  7392ed:	pop    %r14
  7392ef:	pop    %r15
  7392f1:	pop    %rbp
  7392f2:	ret


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

0000000000739bc0 <<gpui::source::Sources<owner_source_control::Model>>::resolve>:
  739bc0:	push   %rbp
  739bc1:	push   %r15
  739bc3:	push   %r14
  739bc5:	push   %r13
  739bc7:	push   %r12
  739bc9:	push   %rbx
  739bca:	sub    $0x58,%rsp
  739bce:	mov    %rdx,%r9
  739bd1:	mov    (%rsi),%rax
  739bd4:	cmp    $0xffffffffffffffff,%rax
  739bd8:	lea    0x28(%rsp),%rdx
  739bdd:	cmovne %rsi,%rdx
  739be1:	movups 0x8(%rdx),%xmm0
  739be5:	movaps %xmm0,0x40(%rsp)
  739bea:	je     739bfd <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x3d>
  739bec:	movaps 0x40(%rsp),%xmm0
  739bf1:	movups %xmm0,0x8(%rdi)
  739bf5:	mov    %rax,(%rdi)
  739bf8:	jmp    739d3e <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  739bfd:	mov    %rcx,0x18(%rsp)
  739c02:	mov    %r8,%r12
  739c05:	mov    %rdi,0x8(%rsp)
  739c0a:	mov    0x28(%rsi),%rbx
  739c0e:	test   %rbx,%rbx
  739c11:	mov    %r9,0x10(%rsp)
  739c16:	mov    %rsi,0x20(%rsp)
  739c1b:	je     739c79 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xb9>
  739c1d:	mov    0x20(%rsi),%r14
  739c21:	shl    $0x4,%rbx
  739c25:	add    %r14,%rbx
  739c28:	xor    %ebp,%ebp
  739c2a:	jmp    739c3e <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x7e>
  739c2c:	nopl   0x0(%rax)
  739c30:	add    $0x10,%r14
  739c34:	cmp    %rbx,%r14
  739c37:	mov    0x10(%rsp),%r9
  739c3c:	je     739c7b <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xbb>
  739c3e:	mov    (%r14),%r13
  739c41:	mov    0x8(%r14),%r15
  739c45:	mov    %r13,%rdi
  739c48:	mov    %r9,%rsi
  739c4b:	call   *0x28(%r15)
  739c4f:	mov    %rdx,%rcx
  739c52:	mov    %rax,%rdi
  739c55:	mov    0x18(%rsp),%rsi
  739c5a:	mov    %r12,%rdx
  739c5d:	call   *0x20(%rcx)
  739c60:	test   %al,%al
  739c62:	je     739c30 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x70>
  739c64:	mov    %r13,%rdi
  739c67:	call   *0x18(%r15)
  739c6b:	test   %rbp,%rbp
  739c6e:	jne    739d2a <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x16a>
  739c74:	mov    %rax,%rbp
  739c77:	jmp    739c30 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x70>
  739c79:	xor    %ebp,%ebp
  739c7b:	mov    0x20(%rsp),%rax
  739c80:	mov    0x58(%rax),%rbx
  739c84:	test   %rbx,%rbx
  739c87:	je     739d18 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  739c8d:	mov    0x50(%rax),%r14
  739c91:	shl    $0x4,%rbx
  739c95:	add    %r14,%rbx
  739c98:	lea    0x28(%rsp),%r13
  739c9d:	mov    0x18(%rsp),%r15
  739ca2:	jmp    739cdb <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x11b>
  739ca4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  739cb0:	mov    0x10(%rsp),%r9
  739cb5:	add    $0x10,%r14
  739cb9:	cmp    %rbx,%r14
  739cbc:	jne    739cdb <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x11b>
  739cbe:	jmp    739d18 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  739cc0:	test   %rax,%rax
  739cc3:	je     739cb0 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0xf0>
  739cc5:	test   %rbp,%rbp
  739cc8:	mov    0x10(%rsp),%r9
  739ccd:	jne    739d2a <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x16a>
  739ccf:	mov    %rax,%rbp
  739cd2:	add    $0x10,%r14
  739cd6:	cmp    %rbx,%r14
  739cd9:	je     739d18 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x158>
  739cdb:	mov    (%r14),%rsi
  739cde:	mov    0x8(%r14),%rax
  739ce2:	mov    %r13,%rdi
  739ce5:	mov    %r9,%rdx
  739ce8:	mov    %r15,%rcx
  739ceb:	mov    %r12,%r8
  739cee:	call   *0x50(%rax)
  739cf1:	mov    0x28(%rsp),%rcx
  739cf6:	mov    0x30(%rsp),%rax
  739cfb:	cmp    $0xffffffffffffffff,%rcx
  739cff:	je     739cc0 <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x100>
  739d01:	mov    0x38(%rsp),%rdx
  739d06:	mov    0x8(%rsp),%rdi
  739d0b:	mov    %rcx,(%rdi)
  739d0e:	mov    %rax,0x8(%rdi)
  739d12:	mov    %rdx,0x10(%rdi)
  739d16:	jmp    739d3e <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  739d18:	mov    0x8(%rsp),%rdi
  739d1d:	mov    %rbp,0x8(%rdi)
  739d21:	movq   $0xffffffffffffffff,(%rdi)
  739d28:	jmp    739d3e <<gpui::source::Sources<owner_source_control::Model>>::resolve+0x17e>
  739d2a:	mov    0x8(%rsp),%rdi
  739d2f:	movq   $0x9,(%rdi)
  739d36:	mov    %rbp,0x8(%rdi)
  739d3a:	mov    %rax,0x10(%rdi)
  739d3e:	mov    %rdi,%rax
  739d41:	add    $0x58,%rsp
  739d45:	pop    %rbx
  739d46:	pop    %r12
  739d48:	pop    %r13
  739d4a:	pop    %r14
  739d4c:	pop    %r15
  739d4e:	pop    %rbp
  739d4f:	ret


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000073a550 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit>:
  73a550:	push   %rbp
  73a551:	push   %r15
  73a553:	push   %r14
  73a555:	push   %r13
  73a557:	push   %r12
  73a559:	push   %rbx
  73a55a:	sub    $0x28,%rsp
  73a55e:	mov    %r9,%r14
  73a561:	mov    %r8,%r13
  73a564:	mov    %rdx,%r15
  73a567:	mov    %rsi,%r12
  73a56a:	mov    %rdi,%rbx
  73a56d:	mov    %rsp,%rdi
  73a570:	mov    %rdx,%rsi
  73a573:	call   *0x18(%rcx)
  73a576:	movdqa (%rsp),%xmm0
  73a57b:	pcmpeqb -0x6e2583(%rip),%xmm0        # 58000 <anon.079f5e587c394fcac2765eb4d0cf0bc2.360.llvm.6319143315422321905+0x5c>
  73a583:	pmovmskb %xmm0,%eax
  73a587:	cmp    $0xffff,%eax
  73a58c:	jne    73a617 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xc7>
  73a592:	mov    %rsp,%rdi
  73a595:	mov    %r13,%rsi
  73a598:	call   *0x18(%r14)
  73a59c:	movdqa (%rsp),%xmm0
  73a5a1:	pcmpeqb -0x6e1909(%rip),%xmm0        # 58ca0 <anon.079f5e587c394fcac2765eb4d0cf0bc2.397.llvm.6319143315422321905+0xa80>
  73a5a9:	pmovmskb %xmm0,%eax
  73a5ad:	cmp    $0xffff,%eax
  73a5b2:	jne    73a617 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xc7>
  73a5b4:	mov    (%r12),%r14
  73a5b8:	mov    %r15,%rdi
  73a5bb:	call   *0x18(%r12)
  73a5c0:	mov    %rax,0x20(%rsp)
  73a5c5:	cmp    $0x1,%r14d
  73a5c9:	jne    73a623 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xd3>
  73a5cb:	mov    0x20(%r13),%rbp
  73a5cf:	mov    0x28(%r13),%r12
  73a5d3:	shl    $0x4,%r12
  73a5d7:	xor    %r13d,%r13d
  73a5da:	nopw   0x0(%rax,%rax,1)
  73a5e0:	cmp    %r13,%r12
  73a5e3:	je     73a6ad <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x15d>
  73a5e9:	mov    0x0(%rbp,%r13,1),%rdi
  73a5ee:	mov    0x8(%rbp,%r13,1),%rax
  73a5f3:	call   *0x18(%rax)
  73a5f6:	add    $0x10,%r13
  73a5fa:	cmp    %r14,%rax
  73a5fd:	jne    73a5e0 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x90>
  73a5ff:	mov    -0x10(%rbp,%r13,1),%rdi
  73a604:	mov    -0x8(%rbp,%r13,1),%rax
  73a609:	mov    %r15,%rsi
  73a60c:	call   *0x28(%rax)
  73a60f:	mov    %rax,%rdi
  73a612:	mov    %rdx,%rax
  73a615:	jmp    73a687 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x137>
  73a617:	movq   $0x1,(%rbx)
  73a61e:	jmp    73a6ca <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x17a>
  73a623:	mov    0x50(%r13),%rbp
  73a627:	mov    0x58(%r13),%r13
  73a62b:	shl    $0x4,%r13
  73a62f:	xor    %r12d,%r12d
  73a632:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  73a640:	cmp    %r12,%r13
  73a643:	je     73a6ad <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x15d>
  73a645:	mov    0x0(%rbp,%r12,1),%rdi
  73a64a:	mov    0x8(%rbp,%r12,1),%rax
  73a64f:	mov    %r14,%rsi
  73a652:	call   *0x30(%rax)
  73a655:	add    $0x10,%r12
  73a659:	test   %al,%al
  73a65b:	je     73a640 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0xf0>
  73a65d:	mov    -0x10(%rbp,%r12,1),%rsi
  73a662:	mov    -0x8(%rbp,%r12,1),%rax
  73a667:	mov    %rsp,%rdi
  73a66a:	mov    %r15,%rdx
  73a66d:	mov    %r14,%rcx
  73a670:	call   *0x58(%rax)
  73a673:	mov    (%rsp),%rcx
  73a677:	mov    0x8(%rsp),%rdi
  73a67c:	mov    0x10(%rsp),%rax
  73a681:	cmp    $0xffffffffffffffff,%rcx
  73a685:	jne    73a6b5 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x165>
  73a687:	lea    0x34164a(%rip),%rdx        # a7bcd8 <anon.b8826df01f5428373db055732cad4b13.46.llvm.13662383007610045890+0x168>
  73a68e:	mov    0x20(%rsp),%rsi
  73a693:	call   *0x20(%rax)
  73a696:	test   %al,%al
  73a698:	je     73a6ba <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x16a>
  73a69a:	movw   $0x0,0x8(%rbx)
  73a6a0:	mov    %r14,0x10(%rbx)
  73a6a4:	movq   $0xffffffffffffffff,(%rbx)
  73a6ab:	jmp    73a6ca <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x17a>
  73a6ad:	mov    $0xb,%ecx
  73a6b2:	mov    %r14,%rdi
  73a6b5:	mov    %rdi,%r14
  73a6b8:	jmp    73a6bf <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::admit+0x16f>
  73a6ba:	mov    $0xa,%ecx
  73a6bf:	mov    %rcx,(%rbx)
  73a6c2:	mov    %r14,0x8(%rbx)
  73a6c6:	mov    %rax,0x10(%rbx)
  73a6ca:	mov    %rbx,%rax
  73a6cd:	add    $0x28,%rsp
  73a6d1:	pop    %rbx
  73a6d2:	pop    %r12
  73a6d4:	pop    %r13
  73a6d6:	pop    %r14
  73a6d8:	pop    %r15
  73a6da:	pop    %rbp
  73a6db:	ret


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000073a6e0 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke>:
  73a6e0:	push   %r15
  73a6e2:	push   %r14
  73a6e4:	push   %r12
  73a6e6:	push   %rbx
  73a6e7:	sub    $0x18,%rsp
  73a6eb:	mov    %rdx,%r15
  73a6ee:	mov    %rsi,%r14
  73a6f1:	mov    %rdi,%rbx
  73a6f4:	mov    %rsp,%rdi
  73a6f7:	mov    %rdx,%rsi
  73a6fa:	call   *0x18(%rcx)
  73a6fd:	movdqa (%rsp),%xmm0
  73a702:	pcmpeqb -0x6e270a(%rip),%xmm0        # 58000 <anon.079f5e587c394fcac2765eb4d0cf0bc2.360.llvm.6319143315422321905+0x5c>
  73a70a:	pmovmskb %xmm0,%ecx
  73a70e:	mov    $0x1,%eax
  73a713:	cmp    $0xffff,%ecx
  73a719:	jne    73a755 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x75>
  73a71b:	mov    %r15,%rdi
  73a71e:	call   *0x18(%r14)
  73a722:	mov    %rax,%r12
  73a725:	mov    %r15,%rdi
  73a728:	call   *0x20(%r14)
  73a72c:	cmp    %rax,%r12
  73a72f:	je     73a73f <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x5f>
  73a731:	mov    (%r14),%rax
  73a734:	mov    %rax,0x8(%rbx)
  73a738:	mov    $0xa,%eax
  73a73d:	jmp    73a755 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x75>
  73a73f:	mov    0x4(%rax),%ecx
  73a742:	cmp    $0xffffffff,%ecx
  73a745:	je     73a767 <<gpui::source::FieldAction<owner_source_control::Model, u32, <owner_source_control::Model as gpui::View>::view::{closure#0}> as gpui::element::Route>::invoke+0x87>
  73a747:	inc    %ecx
  73a749:	mov    %ecx,0x4(%rax)
  73a74c:	incl   (%rax)
  73a74e:	mov    $0xffffffffffffffff,%rax
  73a755:	mov    %rax,(%rbx)
  73a758:	mov    %rbx,%rax
  73a75b:	add    $0x18,%rsp
  73a75f:	pop    %rbx
  73a760:	pop    %r12
  73a762:	pop    %r14
  73a764:	pop    %r15
  73a766:	ret
  73a767:	lea    -0x6dd327(%rip),%rdi        # 5d447 <anon.9e1adc519e45ee0094feacbcca2f7d65.68.llvm.16917318406874983744>
  73a76e:	lea    0x340d1b(%rip),%rdx        # a7b490 <anon.9e1adc519e45ee0094feacbcca2f7d65.70.llvm.16917318406874983744>
  73a775:	mov    $0x19,%esi
  73a77a:	call   *0x368d70(%rip)        # aa34f0 <_DYNAMIC+0x2b0>


/tmp/gpui-projected-source-captures/release-candidate/owner_source_control:     file format elf64-x86-64


Disassembly of section .text:

000000000073a7a0 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve>:
  73a7a0:	push   %rbp
  73a7a1:	push   %r15
  73a7a3:	push   %r14
  73a7a5:	push   %r13
  73a7a7:	push   %r12
  73a7a9:	push   %rbx
  73a7aa:	sub    $0x28,%rsp
  73a7ae:	mov    %rcx,%r13
  73a7b1:	mov    %rdx,%r12
  73a7b4:	mov    %rdi,%rbx
  73a7b7:	mov    (%rsi),%r14
  73a7ba:	mov    %rdx,%rdi
  73a7bd:	call   *0x18(%rsi)
  73a7c0:	mov    %rax,0x8(%rsp)
  73a7c5:	cmp    $0x1,%r14d
  73a7c9:	jne    73a817 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x77>
  73a7cb:	mov    0x20(%r13),%rbp
  73a7cf:	mov    0x28(%r13),%r15
  73a7d3:	shl    $0x4,%r15
  73a7d7:	xor    %r13d,%r13d
  73a7da:	nopw   0x0(%rax,%rax,1)
  73a7e0:	cmp    %r13,%r15
  73a7e3:	je     73a8a1 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x101>
  73a7e9:	mov    0x0(%rbp,%r13,1),%rdi
  73a7ee:	mov    0x8(%rbp,%r13,1),%rax
  73a7f3:	call   *0x18(%rax)
  73a7f6:	add    $0x10,%r13
  73a7fa:	cmp    %r14,%rax
  73a7fd:	jne    73a7e0 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x40>
  73a7ff:	mov    -0x10(%rbp,%r13,1),%rdi
  73a804:	mov    -0x8(%rbp,%r13,1),%rax
  73a809:	mov    %r12,%rsi
  73a80c:	call   *0x28(%rax)
  73a80f:	mov    %rax,%rdi
  73a812:	mov    %rdx,%rax
  73a815:	jmp    73a87a <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0xda>
  73a817:	mov    0x50(%r13),%rbp
  73a81b:	mov    0x58(%r13),%r13
  73a81f:	shl    $0x4,%r13
  73a823:	xor    %r15d,%r15d
  73a826:	cs nopw 0x0(%rax,%rax,1)
  73a830:	cmp    %r15,%r13
  73a833:	je     73a8a1 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x101>
  73a835:	mov    0x0(%rbp,%r15,1),%rdi
  73a83a:	mov    0x8(%rbp,%r15,1),%rax
  73a83f:	mov    %r14,%rsi
  73a842:	call   *0x30(%rax)
  73a845:	add    $0x10,%r15
  73a849:	test   %al,%al
  73a84b:	je     73a830 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x90>
  73a84d:	mov    -0x10(%rbp,%r15,1),%rsi
  73a852:	mov    -0x8(%rbp,%r15,1),%rax
  73a857:	lea    0x10(%rsp),%rdi
  73a85c:	mov    %r12,%rdx
  73a85f:	mov    %r14,%rcx
  73a862:	call   *0x58(%rax)
  73a865:	mov    0x10(%rsp),%rcx
  73a86a:	mov    0x18(%rsp),%rdi
  73a86f:	mov    0x20(%rsp),%rax
  73a874:	cmp    $0xffffffffffffffff,%rcx
  73a878:	jne    73a8a9 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x109>
  73a87a:	lea    0x341457(%rip),%rdx        # a7bcd8 <anon.b8826df01f5428373db055732cad4b13.46.llvm.13662383007610045890+0x168>
  73a881:	mov    0x8(%rsp),%r15
  73a886:	mov    %r15,%rsi
  73a889:	call   *0x20(%rax)
  73a88c:	test   %al,%al
  73a88e:	je     73a8ae <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x10e>
  73a890:	mov    %r14,0x8(%rbx)
  73a894:	mov    %r15,0x10(%rbx)
  73a898:	movq   $0xffffffffffffffff,(%rbx)
  73a89f:	jmp    73a8be <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x11e>
  73a8a1:	mov    $0xb,%ecx
  73a8a6:	mov    %r14,%rdi
  73a8a9:	mov    %rdi,%r14
  73a8ac:	jmp    73a8b3 <<gpui::source::Source<owner_source_control::Model, u32> as gpui::source::path::Path<owner_source_control::Model, u32>>::resolve+0x113>
  73a8ae:	mov    $0xa,%ecx
  73a8b3:	mov    %rcx,(%rbx)
  73a8b6:	mov    %r14,0x8(%rbx)
  73a8ba:	mov    %rax,0x10(%rbx)
  73a8be:	mov    %rbx,%rax
  73a8c1:	add    $0x28,%rsp
  73a8c5:	pop    %rbx
  73a8c6:	pop    %r12
  73a8c8:	pop    %r13
  73a8ca:	pop    %r14
  73a8cc:	pop    %r15
  73a8ce:	pop    %rbp
  73a8cf:	ret
