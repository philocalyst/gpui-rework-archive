from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

root = Path('/root/gpui-ce3')
git = ['git', '-c', f'safe.directory={root}', '-C', str(root)]
review = '63059517488141c35811f0bc197b4cd36c9ae6e1'
adopted = '373c9c6ba2665bcc452a92af835a4089b7b7e135'
assert subprocess.check_output(git + ['rev-parse', review + '^{tree}']) == subprocess.check_output(git + ['rev-parse', adopted + '^{tree}'])
sha = lambda path: hashlib.file_digest(Path(path).open('rb'), 'sha256').hexdigest()
load = lambda path: json.loads(Path(path).read_text())
out = Path('/tmp/gpui-ime-adoption-capsule-root')
raw = out / 'raw'
raw.mkdir(parents=True)

def copy(source, name):
    target = raw / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)

gates = {}
for name in ['build', 'execute', 'strict', 'hummingbird', 'docs']:
    directory = Path(f'/tmp/gpui-ime-composed-{name}-root')
    result = load(directory / 'result.json')
    assert result['source'] == review and result['exit'] == 0 and result['guards_match']
    before = load(directory / 'before.json')
    assert before == load(directory / 'after.json')
    assert all(hashlib.sha256((root / name).read_bytes()).hexdigest() == expected for name, expected in before.items())
    gates[name] = result
    for path in directory.iterdir():
        if path.is_file():
            copy(path, f'linux-{name}/{path.name}')

executables = Path('/tmp/gpui-ime-composed-executables-root')
execution = load(executables / 'result.json')
assert execution['all_exit_zero'] and execution['passed'] == 673 and execution['failed'] == 0
external = []
for path in sorted(executables.rglob('*')):
    if not path.is_file():
        continue
    if path.name == 'test':
        identity = load(path.parent / 'binary.json')
        assert sha(path) == identity['sha256'] and not identity['fresh']
        external.append(identity)
    else:
        copy(path, 'linux-executables/' + str(path.relative_to(executables)))
assert len(external) == 71

mac = Path('/tmp/gpui-ime-composed-mac-6305951-sol')
native = load(mac / 'verified-final-result.json')
assert native['passed'] == 744 and native['failed'] == 0 and native['documentation']['passed'] == 28
assert native['strict_native_clippy']['exit'] == 0 and native['final_required_gates_pass']
for name in ['README.md', 'verified-final-result.json', 'retention-handoff.json', 'source-manifest.json', 'source-archive-receipt.json', 'metadata-receipt.json', 'metadata-clippy-delta-receipt.json', 'metadata-dedup.tar.gz', 'metadata-clippy-delta.tar.gz', 'verify-metadata.py', 'verify-clippy-delta.py']:
    copy(mac / name, 'mac/' + name)
copy('/tmp/gpui-ime-composed-mac-independent-root.json', 'mac/root-independent.json')
handoff = load(mac / 'retention-handoff.json')
linux_capsule = handoff['linux_capsule']
assert sha(linux_capsule['path']) == linux_capsule['sha256']
assert sha(mac / 'ime-composed-6305951-darwin-handoff.tar.gz') == 'b8a1be622ce6401dcbd709da336afc84f1d47e383abb42a750f9e0e72af3e6a1'
copy('/tmp/gpui-ime-direct-lease-sol-20261024/reactivity/evidence/ime-direct-lease/README.md', 'original-slice/README.md')
copy('/tmp/gpui-ime-main-core-lines-root.json', 'core-lines.json')
copy('/tmp/gpui-run-frozen-gate-root.py', 'helpers/frozen-gate.py')
copy('/tmp/gpui-run-cargo-test-artifacts-root.py', 'helpers/execute-artifacts.py')
copy(__file__, 'helpers/seal.py')

core = load(raw / 'core-lines.json')
assert core['source_commit'] == adopted and core['core_non_test_code_lines'] == 35851
members = {str(path.relative_to(raw)): sha(path) for path in sorted(raw.rglob('*')) if path.is_file()}
archive_path = out / 'logs.tar.gz'
with tarfile.open(archive_path, 'w:gz') as archive:
    for name in members:
        archive.add(raw / name, arcname=name, recursive=False)
with tarfile.open(archive_path) as archive:
    assert {member.name: hashlib.sha256(archive.extractfile(member).read()).hexdigest() for member in archive if member.isfile()} == members
report = {
    'adopted_source': adopted,
    'qualified_review_source': review,
    'whole_tree_identical_at_adoption': True,
    'linux_gates': gates,
    'linux_execution': execution,
    'linux_frozen_executables': external,
    'darwin': native,
    'original_optimization_capsule': linux_capsule,
    'direct_constructor_identical_to_miri_qualified_source': (root / 'reactivity/crates/gpui/src/shared_text.rs').read_bytes() == subprocess.check_output(git + ['show', 'b1560c2a4c4d327701b19d6974875d51b6806393:reactivity/crates/gpui/src/shared_text.rs']),
    'core_lines': {'before': 34899, 'after': 35851, 'delta': 952, 'library_build_scripts': 18, 'exclusions': core['excluded']},
    'dependencies_or_vendors_changed': False,
    'log_archive': {'file': 'logs.tar.gz', 'bytes': archive_path.stat().st_size, 'sha256': sha(archive_path), 'members_sha256': members},
    'limits': [
        'Native requested turnover can quarantine until Disabled/window close, including ordinary Latin-source epoch changes.',
        'Physical AppKit candidate engines, VoiceOver and Windows runtime behavior remain unqualified.',
        'Actual normalized native contracts do not establish input-to-photon latency or hardware GPU performance.',
        'The original slice report preserves its older Reader/Remote Darwin failures; all three pass in the exact adopted composition.',
        'Hummingbird default all-target checking is not completion of the player port.',
        '71 actual Linux ELFs remain at recorded external local paths; 71 actual Darwin Mach-Os remain at recorded Mac paths.',
    ],
}
assert report['direct_constructor_identical_to_miri_qualified_source']
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'archive': str(archive_path), 'bytes': archive_path.stat().st_size, 'sha256': report['log_archive']['sha256'], 'members': len(members), 'core': core['core_non_test_code_lines']}))
