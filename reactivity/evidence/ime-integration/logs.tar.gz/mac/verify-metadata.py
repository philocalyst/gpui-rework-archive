from pathlib import Path
import json,hashlib,tarfile,re
p=Path('/tmp/gpui-ime-composed-mac-6305951-sol');receipt=json.loads((p/'metadata-receipt.json').read_text());a=p/'metadata-dedup.tar.gz';assert hashlib.file_digest(a.open('rb'),'sha256').hexdigest()==receipt['sha256'];dest=p/'metadata';dest.mkdir(exist_ok=True)
with tarfile.open(a) as t:
 m=json.load(t.extractfile('MANIFEST.json'));seen=set()
 for row in m['files']:
  data=t.extractfile(row['object']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];name=Path(row['path']);assert not name.is_absolute() and '..' not in name.parts;q=dest/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);seen.add(row['object'])
 assert seen=={x.name for x in t.getmembers()}-{'MANIFEST.json'}
q=dest/'qualification-corrected';s=json.loads((q/'status.json').read_text());guard=json.loads((p/'source-manifest.json').read_text());assert s['state']=='complete' and s['source']=='63059517488141c35811f0bc197b4cd36c9ae6e1';assert s['source_hashes_match'] and s['binary_hashes_match'] and s['native_all_exit_zero'] and not s['all_gates_exit_zero'];assert (s['passed'],s['failed'],s['ignored'])==(744,0,12)
assert len(s['binaries'])==71 and len(s['gates'])==75
for row in s['gates']:
 for suffix in ['before','after']:assert json.loads((q/(row['name']+'.'+suffix+'.json')).read_text())==guard
 assert row['exit']==(101 if row['name']=='strict-native-clippy' else 0) and row['inputs']==2075 and row['guards_match']
for file in ['initial-inputs.json','final-inputs.json']:assert json.loads((q/file).read_text())==guard
assert (dest/'job.py').read_bytes()==(p/'job.py').read_bytes();assert (dest/'job-corrected.py').read_bytes()==(p/'job-corrected.py').read_bytes()
rows=[json.loads(x) for x in (q/'full-native-build.stdout').read_text().splitlines()];libs={}
for name in ['gpui','gpui_canvas','gpui_gpu']:
 matches=[x for x in rows if x.get('reason')=='compiler-artifact' and x['target']['name']==name and not x['profile']['test']];assert matches and all(not x['fresh'] for x in matches);libs[name]=len(matches)
for row in s['binaries']:assert not row['cargo']['fresh'] and len(row['sha256'])==64
focus={};full=''
for i,row in enumerate(s['results']):
 text=(q/('native-run-'+str(i)+'.stdout')).read_text();full+=text
 if row['name'] in ['gpui','ime','property_selection']:focus[row['name']]=row
for name in ['future_wrapper_has_no_result_slot_or_poll_allocation','preallocated_frozen_prefix_has_no_per_message_allocations','preallocated_transport_and_idle_turns_do_not_allocate']:
 lines=[x for x in full.splitlines() if name in x];assert len(lines)==1 and re.search(r'^test [^\n]*'+re.escape(name)+r'[^\n]* \.\.\. (?:ok\n|[^\n]*\nok\n)',full,re.M),lines
assert 'ime_accesskit_uses_acknowledged_display_and_selection_without_preview_edit_authority ... ok' in full
release=json.loads((p/'release.log').read_text());assert release['exclusive_lock_available'] and not release['original_pid'] and not release['corrected_pid']
result=dict(source=s['source'],source_inputs=len(guard),gates=len(s['gates']),all_guards_match=True,actual_frozen_executables=len(s['binaries']),passed=s['passed'],failed=s['failed'],ignored=s['ignored'],focus=focus,all_gates_exit_zero=False,offline_blocked_gate='strict-native-clippy: core_maths v0.1.1 absent from offline cache; exact locked artifact supplied and separate retry pending',fresh_shipping_library_artifacts=libs,source_hashes_match=True,binary_hashes_match=True,metadata_archive=receipt,verified_metadata_files=len(m['files']),verified_unique_metadata_objects=len(seen),actual_machos_location='/Users/mileswirht/gpui-reactivity-20261024-root/ime-composed-6305951-sol/qualification-corrected',actual_machos_downloaded=False,release=release,known_baseline_allocation_tests_now_pass_in_this_exact_composition=True,docs=(q/'native-docs.stdout').read_text(),scope='Actual Darwin native contracts and normalized adapter tests. No physical candidate engine, VoiceOver, ScreenRecording/AX permission or UI-latency qualification. Native request-turnover quarantine remains until Disabled/close; no reusable lifecycle claim.')
(p/'verified-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['source','source_inputs','gates','actual_frozen_executables','passed','failed','ignored','verified_metadata_files','verified_unique_metadata_objects','docs','focus']},indent=2))
