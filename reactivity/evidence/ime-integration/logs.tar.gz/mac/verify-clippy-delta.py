from pathlib import Path
import json,hashlib,tarfile,re
p=Path('/tmp/gpui-ime-composed-mac-6305951-sol');dest=p/'metadata';expected=json.loads((p/'source-manifest.json').read_text());base=p/'metadata-dedup.tar.gz';delta=p/'metadata-clippy-delta.tar.gz';r=json.loads((p/'metadata-clippy-delta-receipt.json').read_text());assert hashlib.file_digest(delta.open('rb'),'sha256').hexdigest()==r['sha256']
with tarfile.open(base) as b,tarfile.open(delta) as d:
 m=json.load(d.extractfile('MANIFEST.json'));assert m['base_archive_sha256']==hashlib.file_digest(base.open('rb'),'sha256').hexdigest();base_objects={x.name for x in b.getmembers()}
 for row in m['files']:
  if row['object'] in base_objects:data=b.extractfile(row['object']).read()
  else:data=d.extractfile(row['object']).read()
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'];name=Path(row['path']);assert not name.is_absolute() and '..' not in name.parts;q=dest/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
q=dest/'qualification-clippy-prefetched';s=json.loads((q/'status.json').read_text());assert s['state']=='complete' and s['exit']==0 and s['source_hashes_match']
for name in ['before.json','prefetch-after.json','after.json']:assert json.loads((q/name).read_text())==expected
command=json.loads((q/'command.json').read_text());assert command==json.loads((dest/'qualification-corrected/strict-native-clippy.command.json').read_text())
assert 'Finished `dev` profile' in (q/'stderr').read_text();assert len(s['artifacts'])==11
for row in s['artifacts']:
 known=next(x for x in json.loads((p/'missing-cache.json').read_text())['missing'] if x['name']==row['name']);assert row['bytes']==known['bytes'] and row['sha256']==known['sha256']
assert (dest/'clippy-prefetch-job.py').read_bytes()==(p/'clippy-prefetch-job.py').read_bytes();assert (dest/'clippy-cache-retry-job.py').read_bytes()==(p/'clippy-cache-retry-job.py').read_bytes()
failure=json.loads((dest/'qualification-clippy-corrected/status.json').read_text());assert failure['state']=='complete' and failure['exit']==101 and failure['source_hashes_match'];assert 'foldhash v0.1.5' in (dest/'qualification-clippy-corrected/stderr').read_text()
for name in ['before.json','after.json']:assert json.loads((dest/'qualification-clippy-corrected'/name).read_text())==expected
seal=json.loads((dest/'final-seal.json').read_text());assert seal['source_inputs']==2075 and seal['source_hashes_match'] and seal['frozen_binary_hashes_match'] and len(seal['binaries'])==71 and all(not v for v in seal['pid_status'].values());catalog={r['file']:r for r in json.loads((dest/'qualification-corrected/status.json').read_text())['binaries']}
for row in seal['binaries']:assert row['sha256']==catalog[row['file']]['sha256'] and row['bytes']==catalog[row['file']]['bytes']
result=json.loads((p/'verified-result.json').read_text());docs=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',result['docs']);assert docs==[('2','0','0'),('26','0','0')]
result.update(final_required_gates_pass=True,strict_native_clippy=dict(exit=0,scope='GPUI/Canvas/GPU --features native --all-targets -D warnings; exact original command, locked/offline/checksum-freshness/content fingerprint',source_guards=2075,raw_directory=str(q),cache_added_files=12,cache_added_bytes=1259764),offline_blocked_gate='Resolved by exact locked cache artifacts; both original core_maths and subsequent foldhash offline failures remain archived.',documentation=dict(passed=28,failed=0,ignored=0),final_frozen_binary_hashes_match=True,owned_jobs_reaped=True,metadata_clippy_delta=r,final_seal=str(dest/'final-seal.json'))
(p/'verified-final-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'source':result['source'],'native':[result['passed'],result['failed'],result['ignored']],'docs':result['documentation'],'strict_native_clippy_exit':s['exit'],'full_input_guards':2075,'frozen_machos':len(seal['binaries']),'all_owned_jobs_reaped':True,'metadata_files':result['verified_metadata_files']+len(m['files'])},indent=2))
