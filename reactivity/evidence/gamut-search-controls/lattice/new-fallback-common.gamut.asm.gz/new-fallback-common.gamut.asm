000000000001f7d0 <<gpui_canvas::color::OutputProfile>::max_chroma>:
   1f7d0:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f7d4:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f7da:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f7df:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f7e5:	7f 38                	jg     1f81f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f7e7:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f7ea:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f7ed:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f7f2:	0f 28 d8             	movaps %xmm0,%xmm3
   1f7f5:	f3 0f c2 1d aa 60 fe 	cmpnless -0x19f56(%rip),%xmm3        # 58a8 <std::thread::current::id::ID+0x4c30>
   1f7fc:	ff 06 
   1f7fe:	0f 56 da             	orps   %xmm2,%xmm3
   1f801:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f805:	66 0f 7e ca          	movd   %xmm1,%edx
   1f809:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f80f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f815:	0f 9d c2             	setge  %dl
   1f818:	08 ca                	or     %cl,%dl
   1f81a:	f6 c2 01             	test   $0x1,%dl
   1f81d:	74 01                	je     1f820 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f81f:	c3                   	ret
   1f820:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f823:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f828:	75 02                	jne    1f82c <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f82a:	7b f3                	jnp    1f81f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f82c:	0f 2e 05 75 60 fe ff 	ucomiss -0x19f8b(%rip),%xmm0        # 58a8 <std::thread::current::id::ID+0x4c30>
   1f833:	75 02                	jne    1f837 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f835:	7b e8                	jnp    1f81f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f837:	53                   	push   %rbx
   1f838:	48 83 ec 10          	sub    $0x10,%rsp
   1f83c:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f842:	89 fb                	mov    %edi,%ebx
   1f844:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f847:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f84b:	f2 0f 10 0d 55 7b fe 	movsd  -0x184ab(%rip),%xmm1        # 73a8 <std::thread::current::id::ID+0x6730>
   1f852:	ff 
   1f853:	ff 15 a7 5f 04 00    	call   *0x45fa7(%rip)        # 65800 <_DYNAMIC+0x368>
   1f859:	f2 0f 10 1d 47 7b fe 	movsd  -0x184b9(%rip),%xmm3        # 73a8 <std::thread::current::id::ID+0x6730>
   1f860:	ff 
   1f861:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f865:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f869:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f86d:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f872:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f876:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f87a:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f87e:	66 0f 2e 15 5a 7a fe 	ucomisd -0x185a6(%rip),%xmm2        # 72e0 <std::thread::current::id::ID+0x6668>
   1f885:	ff 
   1f886:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f88a:	73 0f                	jae    1f89b <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f88c:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f88f:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f893:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f898:	0f 55 c8             	andnps %xmm0,%xmm1
   1f89b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f8a1:	0f b6 fb             	movzbl %bl,%edi
   1f8a4:	48 83 c4 10          	add    $0x10,%rsp
   1f8a8:	5b                   	pop    %rbx
   1f8a9:	e9 22 22 00 00       	jmp    21ad0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>
   1f8ae:	cc                   	int3
   1f8af:	cc                   	int3

00000000000203e0 <<gpui_canvas::color::Color>::fit_chroma>:
   203e0:	55                   	push   %rbp
   203e1:	41 57                	push   %r15
   203e3:	41 56                	push   %r14
   203e5:	41 54                	push   %r12
   203e7:	53                   	push   %rbx
   203e8:	48 83 ec 30          	sub    $0x30,%rsp
   203ec:	48 89 fb             	mov    %rdi,%rbx
   203ef:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   203f3:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   203f7:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   203fe:	0f 92 c0             	setb   %al
   20401:	45 85 e4             	test   %r12d,%r12d
   20404:	0f 99 c1             	setns  %cl
   20407:	08 c1                	or     %al,%cl
   20409:	80 f9 01             	cmp    $0x1,%cl
   2040c:	75 09                	jne    20417 <<gpui_canvas::color::Color>::fit_chroma+0x37>
   2040e:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   20415:	eb 4a                	jmp    20461 <<gpui_canvas::color::Color>::fit_chroma+0x81>
   20417:	49 89 f6             	mov    %rsi,%r14
   2041a:	0f 10 06             	movups (%rsi),%xmm0
   2041d:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   20422:	0f b6 ea             	movzbl %dl,%ebp
   20425:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2042a:	89 ee                	mov    %ebp,%esi
   2042c:	e8 2f 24 00 00       	call   22860 <gpui_canvas::color::gamut::in_gamut>
   20431:	84 c0                	test   %al,%al
   20433:	74 0c                	je     20441 <<gpui_canvas::color::Color>::fit_chroma+0x61>
   20435:	41 0f 10 06          	movups (%r14),%xmm0
   20439:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   2043d:	31 c0                	xor    %eax,%eax
   2043f:	eb 25                	jmp    20466 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   20441:	41 8b 16             	mov    (%r14),%edx
   20444:	89 d6                	mov    %edx,%esi
   20446:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   2044c:	b8 0d 00 00 00       	mov    $0xd,%eax
   20451:	31 c9                	xor    %ecx,%ecx
   20453:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   20459:	7e 1d                	jle    20478 <<gpui_canvas::color::Color>::fit_chroma+0x98>
   2045b:	89 43 04             	mov    %eax,0x4(%rbx)
   2045e:	89 4b 08             	mov    %ecx,0x8(%rbx)
   20461:	b8 01 00 00 00       	mov    $0x1,%eax
   20466:	89 03                	mov    %eax,(%rbx)
   20468:	48 89 d8             	mov    %rbx,%rax
   2046b:	48 83 c4 30          	add    $0x30,%rsp
   2046f:	5b                   	pop    %rbx
   20470:	41 5c                	pop    %r12
   20472:	41 5e                	pop    %r14
   20474:	41 5f                	pop    %r15
   20476:	5d                   	pop    %rbp
   20477:	c3                   	ret
   20478:	44 89 e6             	mov    %r12d,%esi
   2047b:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   20481:	66 0f 6e c6          	movd   %esi,%xmm0
   20485:	0f 2e 05 54 54 fe ff 	ucomiss -0x1abac(%rip),%xmm0        # 58e0 <std::thread::current::id::ID+0x4c68>
   2048c:	74 cd                	je     2045b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   2048e:	66 0f 6e d2          	movd   %edx,%xmm2
   20492:	0f 57 c9             	xorps  %xmm1,%xmm1
   20495:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20498:	72 c1                	jb     2045b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   2049a:	f3 0f 10 0d 06 54 fe 	movss  -0x1abfa(%rip),%xmm1        # 58a8 <std::thread::current::id::ID+0x4c30>
   204a1:	ff 
   204a2:	0f 2e ca             	ucomiss %xmm2,%xmm1
   204a5:	72 b4                	jb     2045b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   204a7:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   204ad:	31 c9                	xor    %ecx,%ecx
   204af:	0f 57 c9             	xorps  %xmm1,%xmm1
   204b2:	0f 2e d1             	ucomiss %xmm1,%xmm2
   204b5:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   204bb:	75 02                	jne    204bf <<gpui_canvas::color::Color>::fit_chroma+0xdf>
   204bd:	7b 63                	jnp    20522 <<gpui_canvas::color::Color>::fit_chroma+0x142>
   204bf:	0f 2e 15 e2 53 fe ff 	ucomiss -0x1ac1e(%rip),%xmm2        # 58a8 <std::thread::current::id::ID+0x4c30>
   204c6:	75 02                	jne    204ca <<gpui_canvas::color::Color>::fit_chroma+0xea>
   204c8:	7b 58                	jnp    20522 <<gpui_canvas::color::Color>::fit_chroma+0x142>
   204ca:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   204cf:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   204d3:	f2 0f 10 0d cd 6e fe 	movsd  -0x19133(%rip),%xmm1        # 73a8 <std::thread::current::id::ID+0x6730>
   204da:	ff 
   204db:	ff 15 1f 53 04 00    	call   *0x4531f(%rip)        # 65800 <_DYNAMIC+0x368>
   204e1:	66 0f 2e 05 f7 6d fe 	ucomisd -0x19209(%rip),%xmm0        # 72e0 <std::thread::current::id::ID+0x6668>
   204e8:	ff 
   204e9:	0f 57 c9             	xorps  %xmm1,%xmm1
   204ec:	73 0c                	jae    204fa <<gpui_canvas::color::Color>::fit_chroma+0x11a>
   204ee:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   204f2:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   204f7:	0f 55 c8             	andnps %xmm0,%xmm1
   204fa:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   20500:	89 ef                	mov    %ebp,%edi
   20502:	e8 c9 15 00 00       	call   21ad0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>
   20507:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   2050d:	48 89 c1             	mov    %rax,%rcx
   20510:	48 c1 e9 20          	shr    $0x20,%rcx
   20514:	83 f8 ff             	cmp    $0xffffffff,%eax
   20517:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   2051c:	0f 85 39 ff ff ff    	jne    2045b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   20522:	66 0f 6e c1          	movd   %ecx,%xmm0
   20526:	0f 28 cb             	movaps %xmm3,%xmm1
   20529:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   2052d:	0f 28 e1             	movaps %xmm1,%xmm4
   20530:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   20535:	0f 28 c4             	movaps %xmm4,%xmm0
   20538:	0f 55 c1             	andnps %xmm1,%xmm0
   2053b:	0f 54 e3             	andps  %xmm3,%xmm4
   2053e:	0f 56 e0             	orps   %xmm0,%xmm4
   20541:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   20547:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   2054c:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   20552:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   20557:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   2055c:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   20561:	89 ee                	mov    %ebp,%esi
   20563:	e8 f8 22 00 00       	call   22860 <gpui_canvas::color::gamut::in_gamut>
   20568:	84 c0                	test   %al,%al
   2056a:	74 24                	je     20590 <<gpui_canvas::color::Color>::fit_chroma+0x1b0>
   2056c:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   20571:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   20576:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   2057a:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   2057e:	31 c0                	xor    %eax,%eax
   20580:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   20586:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   2058b:	e9 d6 fe ff ff       	jmp    20466 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   20590:	b8 01 00 00 00       	mov    $0x1,%eax
   20595:	f3 0f 10 05 03 53 fe 	movss  -0x1acfd(%rip),%xmm0        # 58a0 <std::thread::current::id::ID+0x4c28>
   2059c:	ff 
   2059d:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   205a2:	e9 bf fe ff ff       	jmp    20466 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   205a7:	cc                   	int3
   205a8:	cc                   	int3
   205a9:	cc                   	int3
   205aa:	cc                   	int3
   205ab:	cc                   	int3
   205ac:	cc                   	int3
   205ad:	cc                   	int3
   205ae:	cc                   	int3
   205af:	cc                   	int3

0000000000020ab0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>:
   20ab0:	55                   	push   %rbp
   20ab1:	48 89 e5             	mov    %rsp,%rbp
   20ab4:	41 57                	push   %r15
   20ab6:	41 56                	push   %r14
   20ab8:	41 54                	push   %r12
   20aba:	53                   	push   %rbx
   20abb:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20abf:	48 81 ec 60 04 00 00 	sub    $0x460,%rsp
   20ac6:	0f 28 62 20          	movaps 0x20(%rdx),%xmm4
   20aca:	0f 28 4a 30          	movaps 0x30(%rdx),%xmm1
   20ace:	0f 29 a4 24 60 03 00 	movaps %xmm4,0x360(%rsp)
   20ad5:	00 
   20ad6:	0f 29 8c 24 70 03 00 	movaps %xmm1,0x370(%rsp)
   20add:	00 
   20ade:	0f 28 12             	movaps (%rdx),%xmm2
   20ae1:	0f 29 94 24 40 03 00 	movaps %xmm2,0x340(%rsp)
   20ae8:	00 
   20ae9:	0f 28 5a 10          	movaps 0x10(%rdx),%xmm3
   20aed:	0f 29 9c 24 50 03 00 	movaps %xmm3,0x350(%rsp)
   20af4:	00 
   20af5:	0f 29 94 24 10 04 00 	movaps %xmm2,0x410(%rsp)
   20afc:	00 
   20afd:	0f 29 9c 24 20 04 00 	movaps %xmm3,0x420(%rsp)
   20b04:	00 
   20b05:	0f 29 a4 24 30 04 00 	movaps %xmm4,0x430(%rsp)
   20b0c:	00 
   20b0d:	0f 29 8c 24 40 04 00 	movaps %xmm1,0x440(%rsp)
   20b14:	00 
   20b15:	0f 29 8c 24 d0 03 00 	movaps %xmm1,0x3d0(%rsp)
   20b1c:	00 
   20b1d:	0f 29 a4 24 c0 03 00 	movaps %xmm4,0x3c0(%rsp)
   20b24:	00 
   20b25:	0f 29 9c 24 b0 03 00 	movaps %xmm3,0x3b0(%rsp)
   20b2c:	00 
   20b2d:	0f 29 94 24 a0 03 00 	movaps %xmm2,0x3a0(%rsp)
   20b34:	00 
   20b35:	0f 28 8c 24 00 04 00 	movaps 0x400(%rsp),%xmm1
   20b3c:	00 
   20b3d:	0f 29 8c 24 90 03 00 	movaps %xmm1,0x390(%rsp)
   20b44:	00 
   20b45:	66 0f 28 0d 03 4c fe 	movapd -0x1b3fd(%rip),%xmm1        # 5750 <std::thread::current::id::ID+0x4ad8>
   20b4c:	ff 
   20b4d:	66 0f 29 8c 24 e0 03 	movapd %xmm1,0x3e0(%rsp)
   20b54:	00 00 
   20b56:	66 0f 29 8c 24 f0 03 	movapd %xmm1,0x3f0(%rsp)
   20b5d:	00 00 
   20b5f:	48 8d 84 24 a0 03 00 	lea    0x3a0(%rsp),%rax
   20b66:	00 
   20b67:	66 0f 28 26          	movapd (%rsi),%xmm4
   20b6b:	66 44 0f 28 46 10    	movapd 0x10(%rsi),%xmm8
   20b71:	66 44 0f 28 6e 20    	movapd 0x20(%rsi),%xmm13
   20b77:	66 44 0f 28 5e 60    	movapd 0x60(%rsi),%xmm11
   20b7d:	66 45 0f 57 e4       	xorpd  %xmm12,%xmm12
   20b82:	66 45 0f c2 e3 05    	cmpnltpd %xmm11,%xmm12
   20b88:	66 44 0f 54 e1       	andpd  %xmm1,%xmm12
   20b8d:	66 0f 28 15 4b 48 fe 	movapd -0x1b7b5(%rip),%xmm2        # 53e0 <std::thread::current::id::ID+0x4768>
   20b94:	ff 
   20b95:	66 0f 28 dc          	movapd %xmm4,%xmm3
   20b99:	66 0f 59 da          	mulpd  %xmm2,%xmm3
   20b9d:	66 0f 29 9c 24 c0 01 	movapd %xmm3,0x1c0(%rsp)
   20ba4:	00 00 
   20ba6:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   20bab:	66 41 0f 58 dd       	addpd  %xmm13,%xmm3
   20bb0:	66 0f 29 9c 24 b0 01 	movapd %xmm3,0x1b0(%rsp)
   20bb7:	00 00 
   20bb9:	66 44 0f 28 3d 5e 46 	movapd -0x1b9a2(%rip),%xmm15        # 5220 <std::thread::current::id::ID+0x45a8>
   20bc0:	fe ff 
   20bc2:	66 0f 29 a4 24 00 01 	movapd %xmm4,0x100(%rsp)
   20bc9:	00 00 
   20bcb:	66 0f 28 dc          	movapd %xmm4,%xmm3
   20bcf:	66 41 0f 54 df       	andpd  %xmm15,%xmm3
   20bd4:	66 0f 29 9c 24 70 02 	movapd %xmm3,0x270(%rsp)
   20bdb:	00 00 
   20bdd:	66 0f 59 da          	mulpd  %xmm2,%xmm3
   20be1:	66 0f 29 9c 24 a0 01 	movapd %xmm3,0x1a0(%rsp)
   20be8:	00 00 
   20bea:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   20bef:	66 41 0f 54 df       	andpd  %xmm15,%xmm3
   20bf4:	66 0f 28 66 70       	movapd 0x70(%rsi),%xmm4
   20bf9:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   20bfd:	66 0f c2 ec 05       	cmpnltpd %xmm4,%xmm5
   20c02:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   20c06:	66 0f 29 6c 24 20    	movapd %xmm5,0x20(%rsp)
   20c0c:	66 41 0f 28 e8       	movapd %xmm8,%xmm5
   20c11:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   20c15:	66 0f 28 76 30       	movapd 0x30(%rsi),%xmm6
   20c1a:	66 0f 28 fe          	movapd %xmm6,%xmm7
   20c1e:	66 0f 58 fe          	addpd  %xmm6,%xmm7
   20c22:	66 44 0f 29 84 24 70 	movapd %xmm8,0x170(%rsp)
   20c29:	01 00 00 
   20c2c:	66 45 0f 54 c7       	andpd  %xmm15,%xmm8
   20c31:	66 44 0f 29 84 24 40 	movapd %xmm8,0x240(%rsp)
   20c38:	02 00 00 
   20c3b:	66 41 0f 59 d0       	mulpd  %xmm8,%xmm2
   20c40:	66 0f 29 b4 24 50 01 	movapd %xmm6,0x150(%rsp)
   20c47:	00 00 
   20c49:	66 41 0f 54 f7       	andpd  %xmm15,%xmm6
   20c4e:	66 0f 29 9c 24 20 01 	movapd %xmm3,0x120(%rsp)
   20c55:	00 00 
   20c57:	66 0f 58 db          	addpd  %xmm3,%xmm3
   20c5b:	66 0f 29 9c 24 90 01 	movapd %xmm3,0x190(%rsp)
   20c62:	00 00 
   20c64:	66 0f 29 b4 24 30 02 	movapd %xmm6,0x230(%rsp)
   20c6b:	00 00 
   20c6d:	66 0f 58 f6          	addpd  %xmm6,%xmm6
   20c71:	66 0f 28 5e 40       	movapd 0x40(%rsi),%xmm3
   20c76:	66 0f 29 9c 24 c0 00 	movapd %xmm3,0xc0(%rsp)
   20c7d:	00 00 
   20c7f:	66 41 0f 54 df       	andpd  %xmm15,%xmm3
   20c84:	66 0f 29 9c 24 80 01 	movapd %xmm3,0x180(%rsp)
   20c8b:	00 00 
   20c8d:	66 0f 28 5e 50       	movapd 0x50(%rsi),%xmm3
   20c92:	66 44 0f 28 c3       	movapd %xmm3,%xmm8
   20c97:	66 45 0f 54 c7       	andpd  %xmm15,%xmm8
   20c9c:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   20ca1:	66 45 0f 54 cf       	andpd  %xmm15,%xmm9
   20ca6:	66 44 0f 29 8c 24 00 	movapd %xmm9,0x200(%rsp)
   20cad:	02 00 00 
   20cb0:	66 0f 29 a4 24 60 01 	movapd %xmm4,0x160(%rsp)
   20cb7:	00 00 
   20cb9:	66 41 0f 54 e7       	andpd  %xmm15,%xmm4
   20cbe:	66 0f 29 a4 24 f0 01 	movapd %xmm4,0x1f0(%rsp)
   20cc5:	00 00 
   20cc7:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   20cce:	00 
   20ccf:	0f 16 c0             	movlhps %xmm0,%xmm0
   20cd2:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
   20cd9:	00 
   20cda:	66 0f 29 9c 24 40 01 	movapd %xmm3,0x140(%rsp)
   20ce1:	00 00 
   20ce3:	66 0f c6 db 01       	shufpd $0x1,%xmm3,%xmm3
   20ce8:	66 0f 29 9c 24 30 03 	movapd %xmm3,0x330(%rsp)
   20cef:	00 00 
   20cf1:	66 0f 29 bc 24 50 02 	movapd %xmm7,0x250(%rsp)
   20cf8:	00 00 
   20cfa:	66 0f c6 ff 01       	shufpd $0x1,%xmm7,%xmm7
   20cff:	66 0f 29 bc 24 20 03 	movapd %xmm7,0x320(%rsp)
   20d06:	00 00 
   20d08:	66 0f 29 ac 24 60 02 	movapd %xmm5,0x260(%rsp)
   20d0f:	00 00 
   20d11:	66 0f c6 ed 01       	shufpd $0x1,%xmm5,%xmm5
   20d16:	66 0f 29 ac 24 10 03 	movapd %xmm5,0x310(%rsp)
   20d1d:	00 00 
   20d1f:	66 0f 29 b4 24 20 02 	movapd %xmm6,0x220(%rsp)
   20d26:	00 00 
   20d28:	66 0f c6 f6 01       	shufpd $0x1,%xmm6,%xmm6
   20d2d:	66 0f 29 b4 24 00 03 	movapd %xmm6,0x300(%rsp)
   20d34:	00 00 
   20d36:	66 0f 29 94 24 80 02 	movapd %xmm2,0x280(%rsp)
   20d3d:	00 00 
   20d3f:	66 0f c6 d2 01       	shufpd $0x1,%xmm2,%xmm2
   20d44:	66 0f 29 94 24 f0 02 	movapd %xmm2,0x2f0(%rsp)
   20d4b:	00 00 
   20d4d:	31 d2                	xor    %edx,%edx
   20d4f:	0f 28 01             	movaps (%rcx),%xmm0
   20d52:	0f 29 84 24 e0 01 00 	movaps %xmm0,0x1e0(%rsp)
   20d59:	00 
   20d5a:	0f 28 41 10          	movaps 0x10(%rcx),%xmm0
   20d5e:	0f 29 84 24 10 01 00 	movaps %xmm0,0x110(%rsp)
   20d65:	00 
   20d66:	66 44 0f 29 84 24 10 	movapd %xmm8,0x210(%rsp)
   20d6d:	02 00 00 
   20d70:	66 41 0f 70 c0 4e    	pshufd $0x4e,%xmm8,%xmm0
   20d76:	66 0f 7f 84 24 e0 02 	movdqa %xmm0,0x2e0(%rsp)
   20d7d:	00 00 
   20d7f:	66 0f 29 4c 24 40    	movapd %xmm1,0x40(%rsp)
   20d85:	66 0f ef c0          	pxor   %xmm0,%xmm0
   20d89:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
   20d8f:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   20d94:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20d98:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   20d9c:	66 44 0f 29 ac 24 f0 	movapd %xmm13,0xf0(%rsp)
   20da3:	00 00 00 
   20da6:	66 44 0f 29 9c 24 e0 	movapd %xmm11,0xe0(%rsp)
   20dad:	00 00 00 
   20db0:	e9 8c 00 00 00       	jmp    20e41 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x391>
   20db5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   20dbc:	00 00 00 00 
   20dc0:	66 44 0f 6f a4 24 90 	movdqa 0x90(%rsp),%xmm12
   20dc7:	00 00 00 
   20dca:	48 ff c2             	inc    %rdx
   20dcd:	0f 28 4c 24 60       	movaps 0x60(%rsp),%xmm1
   20dd2:	0f 55 8c 24 d0 02 00 	andnps 0x2d0(%rsp),%xmm1
   20dd9:	00 
   20dda:	0f 28 84 24 b0 00 00 	movaps 0xb0(%rsp),%xmm0
   20de1:	00 
   20de2:	0f 54 44 24 70       	andps  0x70(%rsp),%xmm0
   20de7:	0f 54 c8             	andps  %xmm0,%xmm1
   20dea:	0f 55 44 24 40       	andnps 0x40(%rsp),%xmm0
   20def:	0f 56 c1             	orps   %xmm1,%xmm0
   20df2:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   20df7:	66 0f 28 84 24 a0 00 	movapd 0xa0(%rsp),%xmm0
   20dfe:	00 00 
   20e00:	66 0f 55 84 24 c0 02 	andnpd 0x2c0(%rsp),%xmm0
   20e07:	00 00 
   20e09:	66 44 0f 54 44 24 10 	andpd  0x10(%rsp),%xmm8
   20e10:	66 41 0f 54 c0       	andpd  %xmm8,%xmm0
   20e15:	66 44 0f 55 44 24 30 	andnpd 0x30(%rsp),%xmm8
   20e1c:	66 44 0f 56 c0       	orpd   %xmm0,%xmm8
   20e21:	66 44 0f 29 44 24 30 	movapd %xmm8,0x30(%rsp)
   20e28:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   20e2d:	66 41 0f 28 ce       	movapd %xmm14,%xmm1
   20e32:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
   20e37:	48 83 fa 03          	cmp    $0x3,%rdx
   20e3b:	0f 84 5a 0c 00 00    	je     21a9b <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xfeb>
   20e41:	66 0f 29 94 24 90 02 	movapd %xmm2,0x290(%rsp)
   20e48:	00 00 
   20e4a:	66 0f 29 8c 24 a0 02 	movapd %xmm1,0x2a0(%rsp)
   20e51:	00 00 
   20e53:	66 0f 7f 84 24 d0 02 	movdqa %xmm0,0x2d0(%rsp)
   20e5a:	00 00 
   20e5c:	66 44 0f 29 a4 24 90 	movapd %xmm12,0x90(%rsp)
   20e63:	00 00 00 
   20e66:	66 44 0f 29 b4 24 c0 	movapd %xmm14,0x2c0(%rsp)
   20e6d:	02 00 00 
   20e70:	48 89 d1             	mov    %rdx,%rcx
   20e73:	48 c1 e1 05          	shl    $0x5,%rcx
   20e77:	66 0f 28 2c 08       	movapd (%rax,%rcx,1),%xmm5
   20e7c:	66 0f 28 64 08 10    	movapd 0x10(%rax,%rcx,1),%xmm4
   20e82:	66 0f 28 cc          	movapd %xmm4,%xmm1
   20e86:	66 0f 15 cc          	unpckhpd %xmm4,%xmm1
   20e8a:	66 0f 28 d5          	movapd %xmm5,%xmm2
   20e8e:	66 0f 28 1d ba 48 fe 	movapd -0x1b746(%rip),%xmm3        # 5750 <std::thread::current::id::ID+0x4ad8>
   20e95:	ff 
   20e96:	66 0f c2 d3 04       	cmpneqpd %xmm3,%xmm2
   20e9b:	66 0f 28 f5          	movapd %xmm5,%xmm6
   20e9f:	66 0f c2 f3 07       	cmpordpd %xmm3,%xmm6
   20ea4:	66 0f 54 f2          	andpd  %xmm2,%xmm6
   20ea8:	66 44 0f 28 c6       	movapd %xmm6,%xmm8
   20ead:	31 c9                	xor    %ecx,%ecx
   20eaf:	f2 0f 10 05 41 63 fe 	movsd  -0x19cbf(%rip),%xmm0        # 71f8 <std::thread::current::id::ID+0x6580>
   20eb6:	ff 
   20eb7:	66 0f 2e e0          	ucomisd %xmm0,%xmm4
   20ebb:	0f 95 c1             	setne  %cl
   20ebe:	31 f6                	xor    %esi,%esi
   20ec0:	66 0f 2e c8          	ucomisd %xmm0,%xmm1
   20ec4:	40 0f 94 c6          	sete   %sil
   20ec8:	66 0f 6e c9          	movd   %ecx,%xmm1
   20ecc:	66 0f c4 ce 04       	pinsrw $0x4,%esi,%xmm1
   20ed1:	66 0f 29 ac 24 b0 02 	movapd %xmm5,0x2b0(%rsp)
   20ed8:	00 00 
   20eda:	66 44 0f 54 c5       	andpd  %xmm5,%xmm8
   20edf:	66 0f 70 c1 a0       	pshufd $0xa0,%xmm1,%xmm0
   20ee4:	66 0f 72 f0 1f       	pslld  $0x1f,%xmm0
   20ee9:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   20eee:	f3 0f 7e ec          	movq   %xmm4,%xmm5
   20ef2:	66 0f ef c9          	pxor   %xmm1,%xmm1
   20ef6:	0f 29 64 24 70       	movaps %xmm4,0x70(%rsp)
   20efb:	66 0f c6 cc 02       	shufpd $0x2,%xmm4,%xmm1
   20f00:	66 0f 6f d0          	movdqa %xmm0,%xmm2
   20f04:	66 0f df d1          	pandn  %xmm1,%xmm2
   20f08:	66 0f 7f 84 24 80 00 	movdqa %xmm0,0x80(%rsp)
   20f0f:	00 00 
   20f11:	66 0f db e8          	pand   %xmm0,%xmm5
   20f15:	66 0f eb ea          	por    %xmm2,%xmm5
   20f19:	66 0f 7f ac 24 a0 00 	movdqa %xmm5,0xa0(%rsp)
   20f20:	00 00 
   20f22:	66 41 0f db ef       	pand   %xmm15,%xmm5
   20f27:	66 0f 28 05 71 47 fe 	movapd -0x1b88f(%rip),%xmm0        # 56a0 <std::thread::current::id::ID+0x4a28>
   20f2e:	ff 
   20f2f:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   20f33:	66 44 0f 29 84 24 b0 	movapd %xmm8,0xb0(%rsp)
   20f3a:	00 00 00 
   20f3d:	66 45 0f 54 c7       	andpd  %xmm15,%xmm8
   20f42:	66 44 0f 58 c0       	addpd  %xmm0,%xmm8
   20f47:	66 0f 28 05 d1 45 fe 	movapd -0x1ba2f(%rip),%xmm0        # 5520 <std::thread::current::id::ID+0x48a8>
   20f4e:	ff 
   20f4f:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   20f54:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   20f58:	66 0f 6e c6          	movd   %esi,%xmm0
   20f5c:	66 0f c4 c1 04       	pinsrw $0x4,%ecx,%xmm0
   20f61:	66 0f 7f 44 24 50    	movdqa %xmm0,0x50(%rsp)
   20f67:	66 0f 29 74 24 60    	movapd %xmm6,0x60(%rsp)
   20f6d:	66 0f 29 b4 24 d0 01 	movapd %xmm6,0x1d0(%rsp)
   20f74:	00 00 
   20f76:	0f b6 8c 24 d0 01 00 	movzbl 0x1d0(%rsp),%ecx
   20f7d:	00 
   20f7e:	0f b6 b4 24 d8 01 00 	movzbl 0x1d8(%rsp),%esi
   20f85:	00 
   20f86:	41 b8 1f 00 00 00    	mov    $0x1f,%r8d
   20f8c:	66 44 0f 28 eb       	movapd %xmm3,%xmm13
   20f91:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   20f98:	0f 1f 84 00 00 00 00 
   20f9f:	00 
   20fa0:	66 0f 29 6c 24 10    	movapd %xmm5,0x10(%rsp)
   20fa6:	66 44 0f 28 4c 24 10 	movapd 0x10(%rsp),%xmm9
   20fad:	f2 0f 10 25 43 62 fe 	movsd  -0x19dbd(%rip),%xmm4        # 71f8 <std::thread::current::id::ID+0x6580>
   20fb4:	ff 
   20fb5:	66 0f 28 44 24 70    	movapd 0x70(%rsp),%xmm0
   20fbb:	66 0f 2e c4          	ucomisd %xmm4,%xmm0
   20fbf:	66 45 0f 28 d8       	movapd %xmm8,%xmm11
   20fc4:	41 0f 95 c1          	setne  %r9b
   20fc8:	66 0f 28 cb          	movapd %xmm3,%xmm1
   20fcc:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   20fd1:	66 41 0f 15 f5       	unpckhpd %xmm13,%xmm6
   20fd6:	45 31 d2             	xor    %r10d,%r10d
   20fd9:	66 0f 2e f4          	ucomisd %xmm4,%xmm6
   20fdd:	66 0f c2 0d 6a 47 fe 	cmpeqpd -0x1b896(%rip),%xmm1        # 5750 <std::thread::current::id::ID+0x4ad8>
   20fe4:	ff 00 
   20fe6:	66 45 0f 58 c0       	addpd  %xmm8,%xmm8
   20feb:	66 0f 28 84 24 b0 00 	movapd 0xb0(%rsp),%xmm0
   20ff2:	00 00 
   20ff4:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
   20ff9:	66 45 0f 5c fb       	subpd  %xmm11,%xmm15
   20ffe:	66 0f ef d2          	pxor   %xmm2,%xmm2
   21002:	66 44 0f 5f fa       	maxpd  %xmm2,%xmm15
   21007:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
   2100c:	66 0f 28 bc 24 c0 01 	movapd 0x1c0(%rsp),%xmm7
   21013:	00 00 
   21015:	66 0f 28 f7          	movapd %xmm7,%xmm6
   21019:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   2101e:	66 44 0f 28 94 24 b0 	movapd 0x1b0(%rsp),%xmm10
   21025:	01 00 00 
   21028:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   2102d:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21032:	66 0f 28 ac 24 c0 00 	movapd 0xc0(%rsp),%xmm5
   21039:	00 00 
   2103b:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   2103f:	66 0f 28 84 24 a0 01 	movapd 0x1a0(%rsp),%xmm0
   21046:	00 00 
   21048:	66 44 0f 28 f0       	movapd %xmm0,%xmm14
   2104d:	66 45 0f 59 f7       	mulpd  %xmm15,%xmm14
   21052:	66 44 0f 28 a4 24 90 	movapd 0x190(%rsp),%xmm12
   21059:	01 00 00 
   2105c:	66 45 0f 58 f4       	addpd  %xmm12,%xmm14
   21061:	66 45 0f 59 f7       	mulpd  %xmm15,%xmm14
   21066:	66 0f 28 a4 24 80 01 	movapd 0x180(%rsp),%xmm4
   2106d:	00 00 
   2106f:	66 44 0f 58 f4       	addpd  %xmm4,%xmm14
   21074:	66 0f 28 15 a4 44 fe 	movapd -0x1bb5c(%rip),%xmm2        # 5520 <std::thread::current::id::ID+0x48a8>
   2107b:	ff 
   2107c:	66 44 0f 59 f2       	mulpd  %xmm2,%xmm14
   21081:	66 44 0f 28 ff       	movapd %xmm7,%xmm15
   21086:	66 45 0f 59 fb       	mulpd  %xmm11,%xmm15
   2108b:	66 45 0f 58 fa       	addpd  %xmm10,%xmm15
   21090:	66 45 0f 59 fb       	mulpd  %xmm11,%xmm15
   21095:	66 44 0f 58 fd       	addpd  %xmm5,%xmm15
   2109a:	66 41 0f 59 c3       	mulpd  %xmm11,%xmm0
   2109f:	66 41 0f 58 c4       	addpd  %xmm12,%xmm0
   210a4:	66 41 0f 59 c3       	mulpd  %xmm11,%xmm0
   210a9:	66 0f 58 c4          	addpd  %xmm4,%xmm0
   210ad:	66 0f 59 c2          	mulpd  %xmm2,%xmm0
   210b1:	66 45 0f 28 de       	movapd %xmm14,%xmm11
   210b6:	66 44 0f 28 15 d1 46 	movapd -0x1b92f(%rip),%xmm10        # 5790 <std::thread::current::id::ID+0x4b18>
   210bd:	fe ff 
   210bf:	66 45 0f 57 da       	xorpd  %xmm10,%xmm11
   210c4:	66 44 0f c2 f6 01    	cmpltpd %xmm6,%xmm14
   210ca:	66 41 0f c2 f3 01    	cmpltpd %xmm11,%xmm6
   210d0:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   210d5:	66 45 0f c2 df 01    	cmpltpd %xmm15,%xmm11
   210db:	66 44 0f 54 de       	andpd  %xmm6,%xmm11
   210e0:	66 41 0f 57 c2       	xorpd  %xmm10,%xmm0
   210e5:	66 44 0f c2 f8 01    	cmpltpd %xmm0,%xmm15
   210eb:	66 45 0f 54 fe       	andpd  %xmm14,%xmm15
   210f0:	66 45 0f 56 fb       	orpd   %xmm11,%xmm15
   210f5:	66 44 0f 54 f9       	andpd  %xmm1,%xmm15
   210fa:	66 44 0f 54 7c 24 60 	andpd  0x60(%rsp),%xmm15
   21101:	66 41 0f 28 c8       	movapd %xmm8,%xmm1
   21106:	66 41 0f 54 cf       	andpd  %xmm15,%xmm1
   2110b:	66 44 0f 55 fb       	andnpd %xmm3,%xmm15
   21110:	66 41 0f 28 df       	movapd %xmm15,%xmm3
   21115:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   21119:	66 0f 28 84 24 a0 00 	movapd 0xa0(%rsp),%xmm0
   21120:	00 00 
   21122:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21126:	66 41 0f 5c c9       	subpd  %xmm9,%xmm1
   2112b:	66 0f c6 c9 01       	shufpd $0x1,%xmm1,%xmm1
   21130:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21134:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   21138:	66 44 0f 58 c8       	addpd  %xmm0,%xmm9
   2113d:	66 45 0f c6 c9 01    	shufpd $0x1,%xmm9,%xmm9
   21143:	66 0f 28 ac 24 10 03 	movapd 0x310(%rsp),%xmm5
   2114a:	00 00 
   2114c:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
   21151:	66 44 0f 59 f9       	mulpd  %xmm1,%xmm15
   21156:	66 0f 28 a4 24 20 03 	movapd 0x320(%rsp),%xmm4
   2115d:	00 00 
   2115f:	66 44 0f 58 fc       	addpd  %xmm4,%xmm15
   21164:	66 44 0f 59 f9       	mulpd  %xmm1,%xmm15
   21169:	66 0f 28 84 24 30 03 	movapd 0x330(%rsp),%xmm0
   21170:	00 00 
   21172:	66 44 0f 58 f8       	addpd  %xmm0,%xmm15
   21177:	66 0f 28 b4 24 f0 02 	movapd 0x2f0(%rsp),%xmm6
   2117e:	00 00 
   21180:	66 44 0f 28 de       	movapd %xmm6,%xmm11
   21185:	66 44 0f 59 d9       	mulpd  %xmm1,%xmm11
   2118a:	66 0f 28 bc 24 00 03 	movapd 0x300(%rsp),%xmm7
   21191:	00 00 
   21193:	66 44 0f 58 df       	addpd  %xmm7,%xmm11
   21198:	66 44 0f 59 d9       	mulpd  %xmm1,%xmm11
   2119d:	66 44 0f 28 a4 24 e0 	movapd 0x2e0(%rsp),%xmm12
   211a4:	02 00 00 
   211a7:	66 45 0f 58 dc       	addpd  %xmm12,%xmm11
   211ac:	66 44 0f 28 35 6b 43 	movapd -0x1bc95(%rip),%xmm14        # 5520 <std::thread::current::id::ID+0x48a8>
   211b3:	fe ff 
   211b5:	66 45 0f 59 de       	mulpd  %xmm14,%xmm11
   211ba:	66 0f 28 cd          	movapd %xmm5,%xmm1
   211be:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   211c3:	66 0f 58 cc          	addpd  %xmm4,%xmm1
   211c7:	66 41 0f 59 c9       	mulpd  %xmm9,%xmm1
   211cc:	66 0f 58 c8          	addpd  %xmm0,%xmm1
   211d0:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
   211d5:	66 0f 58 f7          	addpd  %xmm7,%xmm6
   211d9:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
   211de:	66 41 0f 58 f4       	addpd  %xmm12,%xmm6
   211e3:	66 41 0f 59 f6       	mulpd  %xmm14,%xmm6
   211e8:	66 41 0f 28 fb       	movapd %xmm11,%xmm7
   211ed:	66 41 0f 57 fa       	xorpd  %xmm10,%xmm7
   211f2:	66 45 0f 28 cf       	movapd %xmm15,%xmm9
   211f7:	66 45 0f 28 f3       	movapd %xmm11,%xmm14
   211fc:	66 45 0f c2 f7 05    	cmpnltpd %xmm15,%xmm14
   21202:	66 45 0f c2 df 01    	cmpltpd %xmm15,%xmm11
   21208:	66 44 0f c2 ff 05    	cmpnltpd %xmm7,%xmm15
   2120e:	66 44 0f c2 cf 01    	cmpltpd %xmm7,%xmm9
   21214:	66 0f 28 fe          	movapd %xmm6,%xmm7
   21218:	66 0f c2 f9 05       	cmpnltpd %xmm1,%xmm7
   2121d:	66 41 0f 56 ff       	orpd   %xmm15,%xmm7
   21222:	66 44 0f 28 fe       	movapd %xmm6,%xmm15
   21227:	66 44 0f c2 f9 01    	cmpltpd %xmm1,%xmm15
   2122d:	66 45 0f 54 f9       	andpd  %xmm9,%xmm15
   21232:	66 41 0f 57 f2       	xorpd  %xmm10,%xmm6
   21237:	66 44 0f 28 c9       	movapd %xmm1,%xmm9
   2123c:	66 44 0f c2 ce 05    	cmpnltpd %xmm6,%xmm9
   21242:	66 45 0f 56 ce       	orpd   %xmm14,%xmm9
   21247:	66 44 0f 54 cf       	andpd  %xmm7,%xmm9
   2124c:	66 0f c2 ce 01       	cmpltpd %xmm6,%xmm1
   21251:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   21256:	41 0f 93 c2          	setae  %r10b
   2125a:	45 31 db             	xor    %r11d,%r11d
   2125d:	f2 0f 10 25 93 5f fe 	movsd  -0x1a06d(%rip),%xmm4        # 71f8 <std::thread::current::id::ID+0x6580>
   21264:	ff 
   21265:	66 44 0f 2e ec       	ucomisd %xmm4,%xmm13
   2126a:	41 0f 92 c3          	setb   %r11b
   2126e:	66 41 0f 56 cf       	orpd   %xmm15,%xmm1
   21273:	66 41 0f 6e f3       	movd   %r11d,%xmm6
   21278:	66 0f 6f 44 24 50    	movdqa 0x50(%rsp),%xmm0
   2127e:	66 0f eb f0          	por    %xmm0,%xmm6
   21282:	66 41 0f eb f1       	por    %xmm9,%xmm6
   21287:	66 0f 28 6c 24 10    	movapd 0x10(%rsp),%xmm5
   2128d:	66 41 0f 6e fa       	movd   %r10d,%xmm7
   21292:	66 0f 70 ff 44       	pshufd $0x44,%xmm7,%xmm7
   21297:	66 0f db f8          	pand   %xmm0,%xmm7
   2129b:	66 0f db f9          	pand   %xmm1,%xmm7
   2129f:	66 0f 58 ed          	addpd  %xmm5,%xmm5
   212a3:	0f c6 f7 a0          	shufps $0xa0,%xmm7,%xmm6
   212a7:	66 0f 72 f6 1f       	pslld  $0x1f,%xmm6
   212ac:	66 0f 72 e6 1f       	psrad  $0x1f,%xmm6
   212b1:	66 0f 28 cd          	movapd %xmm5,%xmm1
   212b5:	66 41 0f 15 cd       	unpckhpd %xmm13,%xmm1
   212ba:	66 44 0f 14 ed       	unpcklpd %xmm5,%xmm13
   212bf:	66 41 0f 28 fd       	movapd %xmm13,%xmm7
   212c4:	66 0f 54 fe          	andpd  %xmm6,%xmm7
   212c8:	66 0f 55 f1          	andnpd %xmm1,%xmm6
   212cc:	66 44 0f 28 ee       	movapd %xmm6,%xmm13
   212d1:	66 44 0f 56 ef       	orpd   %xmm7,%xmm13
   212d6:	66 0f 70 cb ee       	pshufd $0xee,%xmm3,%xmm1
   212db:	66 0f 2e dc          	ucomisd %xmm4,%xmm3
   212df:	41 0f 93 c2          	setae  %r10b
   212e3:	66 0f 2e cc          	ucomisd %xmm4,%xmm1
   212e7:	41 0f 93 c3          	setae  %r11b
   212eb:	66 41 0f 70 cd ee    	pshufd $0xee,%xmm13,%xmm1
   212f1:	66 0f 2e cc          	ucomisd %xmm4,%xmm1
   212f5:	0f 93 c3             	setae  %bl
   212f8:	41 20 ca             	and    %cl,%r10b
   212fb:	41 20 f3             	and    %sil,%r11b
   212fe:	45 08 d3             	or     %r10b,%r11b
   21301:	44 20 cb             	and    %r9b,%bl
   21304:	44 08 db             	or     %r11b,%bl
   21307:	41 83 c0 ff          	add    $0xffffffff,%r8d
   2130b:	41 0f 92 c1          	setb   %r9b
   2130f:	80 fb 01             	cmp    $0x1,%bl
   21312:	75 09                	jne    2131d <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x86d>
   21314:	45 84 c9             	test   %r9b,%r9b
   21317:	0f 85 83 fc ff ff    	jne    20fa0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x4f0>
   2131d:	66 44 0f 28 84 24 b0 	movapd 0x2b0(%rsp),%xmm8
   21324:	02 00 00 
   21327:	66 41 0f 28 c8       	movapd %xmm8,%xmm1
   2132c:	66 0f 28 84 24 e0 01 	movapd 0x1e0(%rsp),%xmm0
   21333:	00 00 
   21335:	66 0f 5d c8          	minpd  %xmm0,%xmm1
   21339:	66 44 0f 28 d9       	movapd %xmm1,%xmm11
   2133e:	66 44 0f c2 d9 03    	cmpunordpd %xmm1,%xmm11
   21344:	66 41 0f 28 d0       	movapd %xmm8,%xmm2
   21349:	66 41 0f 54 d3       	andpd  %xmm11,%xmm2
   2134e:	66 44 0f 55 d9       	andnpd %xmm1,%xmm11
   21353:	66 44 0f 56 da       	orpd   %xmm2,%xmm11
   21358:	66 0f 28 74 24 70    	movapd 0x70(%rsp),%xmm6
   2135e:	66 0f 28 ce          	movapd %xmm6,%xmm1
   21362:	66 0f 5d 8c 24 10 01 	minpd  0x110(%rsp),%xmm1
   21369:	00 00 
   2136b:	66 44 0f 28 f1       	movapd %xmm1,%xmm14
   21370:	66 44 0f c2 f1 03    	cmpunordpd %xmm1,%xmm14
   21376:	66 0f 28 d6          	movapd %xmm6,%xmm2
   2137a:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   2137f:	66 44 0f 55 f1       	andnpd %xmm1,%xmm14
   21384:	66 44 0f 56 f2       	orpd   %xmm2,%xmm14
   21389:	66 44 0f 28 4c 24 60 	movapd 0x60(%rsp),%xmm9
   21390:	66 44 0f 54 cb       	andpd  %xmm3,%xmm9
   21395:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21399:	66 41 0f 14 cd       	unpcklpd %xmm13,%xmm1
   2139e:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   213a2:	66 44 0f 15 ea       	unpckhpd %xmm2,%xmm13
   213a7:	66 0f 28 bc 24 80 00 	movapd 0x80(%rsp),%xmm7
   213ae:	00 00 
   213b0:	66 44 0f 54 ef       	andpd  %xmm7,%xmm13
   213b5:	66 0f 55 f9          	andnpd %xmm1,%xmm7
   213b9:	66 41 0f 56 fd       	orpd   %xmm13,%xmm7
   213be:	66 44 0f 28 ac 24 70 	movapd 0x270(%rsp),%xmm13
   213c5:	02 00 00 
   213c8:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   213cd:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   213d2:	66 0f 58 9c 24 20 01 	addpd  0x120(%rsp),%xmm3
   213d9:	00 00 
   213db:	66 0f 28 94 24 c0 01 	movapd 0x1c0(%rsp),%xmm2
   213e2:	00 00 
   213e4:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
   213e9:	66 0f 58 94 24 b0 01 	addpd  0x1b0(%rsp),%xmm2
   213f0:	00 00 
   213f2:	66 0f 28 8c 24 90 00 	movapd 0x90(%rsp),%xmm1
   213f9:	00 00 
   213fb:	66 0f 28 2d 4d 43 fe 	movapd -0x1bcb3(%rip),%xmm5        # 5750 <std::thread::current::id::ID+0x4ad8>
   21402:	ff 
   21403:	66 0f c2 cd 00       	cmpeqpd %xmm5,%xmm1
   21408:	66 0f 28 64 24 20    	movapd 0x20(%rsp),%xmm4
   2140e:	66 0f c2 e5 00       	cmpeqpd %xmm5,%xmm4
   21413:	66 44 0f 28 64 24 40 	movapd 0x40(%rsp),%xmm12
   2141a:	66 44 0f c2 e5 00    	cmpeqpd %xmm5,%xmm12
   21420:	66 44 0f 54 e1       	andpd  %xmm1,%xmm12
   21425:	66 0f 28 4c 24 30    	movapd 0x30(%rsp),%xmm1
   2142b:	66 0f c2 cd 00       	cmpeqpd %xmm5,%xmm1
   21430:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   21434:	66 0f 29 4c 24 10    	movapd %xmm1,0x10(%rsp)
   2143a:	66 41 0f 28 e0       	movapd %xmm8,%xmm4
   2143f:	66 41 0f 5c e1       	subpd  %xmm9,%xmm4
   21444:	66 45 0f 5c c3       	subpd  %xmm11,%xmm8
   21449:	66 44 0f 28 3d ce 3d 	movapd -0x1c232(%rip),%xmm15        # 5220 <std::thread::current::id::ID+0x45a8>
   21450:	fe ff 
   21452:	66 45 0f 54 c7       	andpd  %xmm15,%xmm8
   21457:	66 45 0f 58 c1       	addpd  %xmm9,%xmm8
   2145c:	66 0f c2 e0 01       	cmpltpd %xmm0,%xmm4
   21461:	66 41 0f 54 e0       	andpd  %xmm8,%xmm4
   21466:	66 0f 28 c4          	movapd %xmm4,%xmm0
   2146a:	66 0f c2 c5 00       	cmpeqpd %xmm5,%xmm0
   2146f:	66 0f 28 cc          	movapd %xmm4,%xmm1
   21473:	66 0f c2 cd 03       	cmpunordpd %xmm5,%xmm1
   21478:	66 0f 56 c8          	orpd   %xmm0,%xmm1
   2147c:	66 0f 28 e9          	movapd %xmm1,%xmm5
   21480:	66 0f 55 ec          	andnpd %xmm4,%xmm5
   21484:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
   21489:	66 44 0f 28 84 24 c0 	movapd 0xc0(%rsp),%xmm8
   21490:	00 00 00 
   21493:	66 41 0f 58 d0       	addpd  %xmm8,%xmm2
   21498:	66 0f 28 a4 24 a0 01 	movapd 0x1a0(%rsp),%xmm4
   2149f:	00 00 
   214a1:	66 41 0f 59 e3       	mulpd  %xmm11,%xmm4
   214a6:	66 0f 28 84 24 90 01 	movapd 0x190(%rsp),%xmm0
   214ad:	00 00 
   214af:	66 0f 58 c4          	addpd  %xmm4,%xmm0
   214b3:	66 41 0f 59 c3       	mulpd  %xmm11,%xmm0
   214b8:	66 44 0f 28 8c 24 80 	movapd 0x180(%rsp),%xmm9
   214bf:	01 00 00 
   214c2:	66 41 0f 58 c1       	addpd  %xmm9,%xmm0
   214c7:	66 44 0f 28 15 50 40 	movapd -0x1bfb0(%rip),%xmm10        # 5520 <std::thread::current::id::ID+0x48a8>
   214ce:	fe ff 
   214d0:	66 41 0f 59 c2       	mulpd  %xmm10,%xmm0
   214d5:	66 41 0f 54 d7       	andpd  %xmm15,%xmm2
   214da:	66 0f 58 d0          	addpd  %xmm0,%xmm2
   214de:	66 0f 28 84 24 60 02 	movapd 0x260(%rsp),%xmm0
   214e5:	00 00 
   214e7:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
   214ec:	66 0f 58 84 24 50 02 	addpd  0x250(%rsp),%xmm0
   214f3:	00 00 
   214f5:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   214fa:	66 41 0f 58 d9       	addpd  %xmm9,%xmm3
   214ff:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   21504:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   21509:	66 0f 58 9c 24 00 02 	addpd  0x200(%rsp),%xmm3
   21510:	00 00 
   21512:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
   21517:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   2151b:	66 0f 58 d3          	addpd  %xmm3,%xmm2
   2151f:	66 0f 58 a4 24 20 01 	addpd  0x120(%rsp),%xmm4
   21526:	00 00 
   21528:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   2152d:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   21531:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   21535:	66 0f 28 a4 24 00 01 	movapd 0x100(%rsp),%xmm4
   2153c:	00 00 
   2153e:	66 41 0f 59 e3       	mulpd  %xmm11,%xmm4
   21543:	66 0f 58 a4 24 f0 00 	addpd  0xf0(%rsp),%xmm4
   2154a:	00 00 
   2154c:	66 41 0f 59 e3       	mulpd  %xmm11,%xmm4
   21551:	66 41 0f 58 e0       	addpd  %xmm8,%xmm4
   21556:	66 41 0f 59 e3       	mulpd  %xmm11,%xmm4
   2155b:	66 0f 58 a4 24 e0 00 	addpd  0xe0(%rsp),%xmm4
   21562:	00 00 
   21564:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   21568:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   2156c:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21570:	66 44 0f 28 ec       	movapd %xmm4,%xmm13
   21575:	66 45 0f 54 ef       	andpd  %xmm15,%xmm13
   2157a:	66 44 0f c2 eb 02    	cmplepd %xmm3,%xmm13
   21580:	66 0f 29 4c 24 60    	movapd %xmm1,0x60(%rsp)
   21586:	66 44 0f 56 e9       	orpd   %xmm1,%xmm13
   2158b:	66 0f c2 dc 01       	cmpltpd %xmm4,%xmm3
   21590:	66 44 0f 29 ac 24 b0 	movapd %xmm13,0xb0(%rsp)
   21597:	00 00 00 
   2159a:	66 44 0f 55 eb       	andnpd %xmm3,%xmm13
   2159f:	66 0f 28 d6          	movapd %xmm6,%xmm2
   215a3:	66 0f 5c d7          	subpd  %xmm7,%xmm2
   215a7:	66 41 0f 5c f6       	subpd  %xmm14,%xmm6
   215ac:	66 41 0f 54 f7       	andpd  %xmm15,%xmm6
   215b1:	66 0f 58 f7          	addpd  %xmm7,%xmm6
   215b5:	66 0f c2 94 24 10 01 	cmpltpd 0x110(%rsp),%xmm2
   215bc:	00 00 01 
   215bf:	66 0f 54 d6          	andpd  %xmm6,%xmm2
   215c3:	66 0f 28 ca          	movapd %xmm2,%xmm1
   215c7:	66 0f 28 1d 81 41 fe 	movapd -0x1be7f(%rip),%xmm3        # 5750 <std::thread::current::id::ID+0x4ad8>
   215ce:	ff 
   215cf:	66 0f c2 cb 00       	cmpeqpd %xmm3,%xmm1
   215d4:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   215d9:	66 44 0f c2 db 03    	cmpunordpd %xmm3,%xmm11
   215df:	66 44 0f 56 d9       	orpd   %xmm1,%xmm11
   215e4:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   215e9:	66 0f 55 ca          	andnpd %xmm2,%xmm1
   215ed:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
   215f2:	66 0f 28 b4 24 40 01 	movapd 0x140(%rsp),%xmm6
   215f9:	00 00 
   215fb:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   215ff:	66 0f 28 94 24 80 02 	movapd 0x280(%rsp),%xmm2
   21606:	00 00 
   21608:	66 41 0f 59 d6       	mulpd  %xmm14,%xmm2
   2160d:	66 0f 28 9c 24 20 02 	movapd 0x220(%rsp),%xmm3
   21614:	00 00 
   21616:	66 0f 58 da          	addpd  %xmm2,%xmm3
   2161a:	66 41 0f 59 de       	mulpd  %xmm14,%xmm3
   2161f:	66 0f 28 bc 24 10 02 	movapd 0x210(%rsp),%xmm7
   21626:	00 00 
   21628:	66 0f 58 df          	addpd  %xmm7,%xmm3
   2162c:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
   21631:	66 41 0f 54 c7       	andpd  %xmm15,%xmm0
   21636:	66 0f 58 c3          	addpd  %xmm3,%xmm0
   2163a:	66 0f 28 a4 24 40 02 	movapd 0x240(%rsp),%xmm4
   21641:	00 00 
   21643:	66 0f 28 dc          	movapd %xmm4,%xmm3
   21647:	66 41 0f 59 de       	mulpd  %xmm14,%xmm3
   2164c:	66 0f 28 ac 24 30 02 	movapd 0x230(%rsp),%xmm5
   21653:	00 00 
   21655:	66 0f 58 dd          	addpd  %xmm5,%xmm3
   21659:	66 41 0f 59 de       	mulpd  %xmm14,%xmm3
   2165e:	66 0f 58 df          	addpd  %xmm7,%xmm3
   21662:	66 41 0f 59 de       	mulpd  %xmm14,%xmm3
   21667:	66 0f 58 9c 24 f0 01 	addpd  0x1f0(%rsp),%xmm3
   2166e:	00 00 
   21670:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
   21675:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21679:	66 0f 58 c3          	addpd  %xmm3,%xmm0
   2167d:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   21681:	66 0f 28 dc          	movapd %xmm4,%xmm3
   21685:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   21689:	66 0f 58 da          	addpd  %xmm2,%xmm3
   2168d:	66 44 0f 29 64 24 70 	movapd %xmm12,0x70(%rsp)
   21694:	66 45 0f 54 ec       	andpd  %xmm12,%xmm13
   21699:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   2169d:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   216a1:	66 0f 28 8c 24 70 01 	movapd 0x170(%rsp),%xmm1
   216a8:	00 00 
   216aa:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   216af:	66 0f 58 8c 24 50 01 	addpd  0x150(%rsp),%xmm1
   216b6:	00 00 
   216b8:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   216bd:	66 0f 58 ce          	addpd  %xmm6,%xmm1
   216c1:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   216c6:	66 0f 58 8c 24 60 01 	addpd  0x160(%rsp),%xmm1
   216cd:	00 00 
   216cf:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   216d3:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   216d8:	66 45 0f 54 c7       	andpd  %xmm15,%xmm8
   216dd:	66 44 0f c2 c3 02    	cmplepd %xmm3,%xmm8
   216e3:	66 44 0f 29 9c 24 a0 	movapd %xmm11,0xa0(%rsp)
   216ea:	00 00 00 
   216ed:	66 45 0f 56 c3       	orpd   %xmm11,%xmm8
   216f2:	66 0f c2 d9 01       	cmpltpd %xmm1,%xmm3
   216f7:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   216fc:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   21700:	66 0f 54 7c 24 10    	andpd  0x10(%rsp),%xmm7
   21706:	66 41 0f 70 c5 ee    	pshufd $0xee,%xmm13,%xmm0
   2170c:	66 41 0f eb c5       	por    %xmm13,%xmm0
   21711:	66 0f eb c7          	por    %xmm7,%xmm0
   21715:	66 0f 7e c1          	movd   %xmm0,%ecx
   21719:	f6 c1 01             	test   $0x1,%cl
   2171c:	0f 84 9e f6 ff ff    	je     20dc0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x310>
   21722:	66 0f 28 9c 24 30 01 	movapd 0x130(%rsp),%xmm3
   21729:	00 00 
   2172b:	66 0f 28 b4 24 a0 02 	movapd 0x2a0(%rsp),%xmm6
   21732:	00 00 
   21734:	66 0f 59 f3          	mulpd  %xmm3,%xmm6
   21738:	66 0f 28 8c 24 d0 00 	movapd 0xd0(%rsp),%xmm1
   2173f:	00 00 
   21741:	66 44 0f 29 74 24 50 	movapd %xmm14,0x50(%rsp)
   21748:	f2 41 0f 59 ce       	mulsd  %xmm14,%xmm1
   2174d:	0f 57 c0             	xorps  %xmm0,%xmm0
   21750:	f2 0f 5a c1          	cvtsd2ss %xmm1,%xmm0
   21754:	66 0f 28 ac 24 90 02 	movapd 0x290(%rsp),%xmm5
   2175b:	00 00 
   2175d:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   21761:	0f 57 d2             	xorps  %xmm2,%xmm2
   21764:	f3 0f 5a d0          	cvtss2sd %xmm0,%xmm2
   21768:	66 0f 28 25 d0 40 fe 	movapd -0x1bf30(%rip),%xmm4        # 5840 <std::thread::current::id::ID+0x4bc8>
   2176f:	ff 
   21770:	66 0f 5d ec          	minpd  %xmm4,%xmm5
   21774:	66 0f 5d f4          	minpd  %xmm4,%xmm6
   21778:	31 c9                	xor    %ecx,%ecx
   2177a:	66 0f 2e ca          	ucomisd %xmm2,%xmm1
   2177e:	66 0f 5a ce          	cvtpd2ps %xmm6,%xmm1
   21782:	66 0f 5a d5          	cvtpd2ps %xmm5,%xmm2
   21786:	66 0f 14 ca          	unpcklpd %xmm2,%xmm1
   2178a:	0f 5a d2             	cvtps2pd %xmm2,%xmm2
   2178d:	66 0f c2 ea 01       	cmpltpd %xmm2,%xmm5
   21792:	0f 5a d1             	cvtps2pd %xmm1,%xmm2
   21795:	66 0f c2 f2 01       	cmpltpd %xmm2,%xmm6
   2179a:	66 0f 7e fe          	movd   %xmm7,%esi
   2179e:	0f c6 f5 88          	shufps $0x88,%xmm5,%xmm6
   217a2:	66 0f 28 d3          	movapd %xmm3,%xmm2
   217a6:	66 44 0f 29 8c 24 80 	movapd %xmm9,0x80(%rsp)
   217ad:	00 00 00 
   217b0:	66 41 0f 59 d1       	mulpd  %xmm9,%xmm2
   217b5:	66 0f fe f1          	paddd  %xmm1,%xmm6
   217b9:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   217be:	0f 97 c1             	seta   %cl
   217c1:	44 01 c1             	add    %r8d,%ecx
   217c4:	66 41 0f 7e f0       	movd   %xmm6,%r8d
   217c9:	41 89 ca             	mov    %ecx,%r10d
   217cc:	45 29 c2             	sub    %r8d,%r10d
   217cf:	41 83 fa 02          	cmp    $0x2,%r10d
   217d3:	66 0f 5a c2          	cvtpd2ps %xmm2,%xmm0
   217d7:	0f 5a c8             	cvtps2pd %xmm0,%xmm1
   217da:	41 0f 93 c0          	setae  %r8b
   217de:	66 0f c2 ca 01       	cmpltpd %xmm2,%xmm1
   217e3:	0f c6 c9 e8          	shufps $0xe8,%xmm1,%xmm1
   217e7:	66 0f fa c1          	psubd  %xmm1,%xmm0
   217eb:	66 0f 70 ce ee       	pshufd $0xee,%xmm6,%xmm1
   217f0:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   217f4:	66 0f fa d9          	psubd  %xmm1,%xmm3
   217f8:	66 0f 70 d3 50       	pshufd $0x50,%xmm3,%xmm2
   217fd:	66 44 0f 6f 15 ba 3f 	movdqa -0x1c046(%rip),%xmm10        # 57c0 <std::thread::current::id::ID+0x4b48>
   21804:	fe ff 
   21806:	66 41 0f ef d2       	pxor   %xmm10,%xmm2
   2180b:	66 0f 66 15 fd 3d fe 	pcmpgtd -0x1c203(%rip),%xmm2        # 5610 <std::thread::current::id::ID+0x4998>
   21812:	ff 
   21813:	66 41 0f db d5       	pand   %xmm13,%xmm2
   21818:	41 20 f0             	and    %sil,%r8b
   2181b:	66 44 0f 50 ca       	movmskpd %xmm2,%r9d
   21820:	45 85 c9             	test   %r9d,%r9d
   21823:	41 0f 95 c1          	setne  %r9b
   21827:	45 84 c0             	test   %r8b,%r8b
   2182a:	66 45 0f 6f e5       	movdqa %xmm13,%xmm12
   2182f:	75 09                	jne    2183a <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xd8a>
   21831:	45 84 c9             	test   %r9b,%r9b
   21834:	0f 84 0f 02 00 00    	je     21a49 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xf99>
   2183a:	66 0f 70 4c 24 50 ee 	pshufd $0xee,0x50(%rsp),%xmm1
   21841:	f2 0f 59 8c 24 d0 00 	mulsd  0xd0(%rsp),%xmm1
   21848:	00 00 
   2184a:	0f 57 e4             	xorps  %xmm4,%xmm4
   2184d:	f2 0f 5a e1          	cvtsd2ss %xmm1,%xmm4
   21851:	0f 57 ed             	xorps  %xmm5,%xmm5
   21854:	f3 0f 5a ec          	cvtss2sd %xmm4,%xmm5
   21858:	45 31 c9             	xor    %r9d,%r9d
   2185b:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   2185f:	41 0f 97 c1          	seta   %r9b
   21863:	66 41 0f 7e e3       	movd   %xmm4,%r11d
   21868:	45 01 cb             	add    %r9d,%r11d
   2186b:	66 44 0f c5 cf 04    	pextrw $0x4,%xmm7,%r9d
   21871:	66 44 0f 28 b4 24 00 	movapd 0x100(%rsp),%xmm14
   21878:	01 00 00 
   2187b:	66 44 0f 28 ac 24 f0 	movapd 0xf0(%rsp),%xmm13
   21882:	00 00 00 
   21885:	66 44 0f 28 9c 24 e0 	movapd 0xe0(%rsp),%xmm11
   2188c:	00 00 00 
   2188f:	90                   	nop
   21890:	44 89 db             	mov    %r11d,%ebx
   21893:	66 0f 70 ce 55       	pshufd $0x55,%xmm6,%xmm1
   21898:	66 41 0f 7e cb       	movd   %xmm1,%r11d
   2189d:	41 89 df             	mov    %ebx,%r15d
   218a0:	45 29 df             	sub    %r11d,%r15d
   218a3:	41 83 ff 02          	cmp    $0x2,%r15d
   218a7:	41 0f 93 c6          	setae  %r14b
   218ab:	45 20 ce             	and    %r9b,%r14b
   218ae:	66 41 0f 6e cf       	movd   %r15d,%xmm1
   218b3:	66 41 0f 6e e2       	movd   %r10d,%xmm4
   218b8:	66 0f 62 e1          	punpckldq %xmm1,%xmm4
   218bc:	66 0f 6c e3          	punpcklqdq %xmm3,%xmm4
   218c0:	66 0f 72 d4 01       	psrld  $0x1,%xmm4
   218c5:	66 0f fe e6          	paddd  %xmm6,%xmm4
   218c9:	0f 5a cc             	cvtps2pd %xmm4,%xmm1
   218cc:	66 0f 70 dc ee       	pshufd $0xee,%xmm4,%xmm3
   218d1:	0f 5a eb             	cvtps2pd %xmm3,%xmm5
   218d4:	66 44 0f 6f fe       	movdqa %xmm6,%xmm15
   218d9:	66 0f 28 b4 24 30 01 	movapd 0x130(%rsp),%xmm6
   218e0:	00 00 
   218e2:	66 0f 5e ee          	divpd  %xmm6,%xmm5
   218e6:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   218ea:	66 0f 28 b4 24 70 01 	movapd 0x170(%rsp),%xmm6
   218f1:	00 00 
   218f3:	66 0f 59 f1          	mulpd  %xmm1,%xmm6
   218f7:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   218fc:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   21901:	66 45 0f 58 cd       	addpd  %xmm13,%xmm9
   21906:	66 0f 58 b4 24 50 01 	addpd  0x150(%rsp),%xmm6
   2190d:	00 00 
   2190f:	66 0f 59 f1          	mulpd  %xmm1,%xmm6
   21913:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   21918:	66 44 0f 58 8c 24 c0 	addpd  0xc0(%rsp),%xmm9
   2191f:	00 00 00 
   21922:	66 0f 58 b4 24 40 01 	addpd  0x140(%rsp),%xmm6
   21929:	00 00 
   2192b:	66 0f 59 f1          	mulpd  %xmm1,%xmm6
   2192f:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   21934:	66 45 0f 58 cb       	addpd  %xmm11,%xmm9
   21939:	66 0f 58 b4 24 60 01 	addpd  0x160(%rsp),%xmm6
   21940:	00 00 
   21942:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   21946:	66 0f c2 ee 01       	cmpltpd %xmm6,%xmm5
   2194b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2194f:	66 41 0f c2 c9 01    	cmpltpd %xmm9,%xmm1
   21955:	66 0f 70 f4 55       	pshufd $0x55,%xmm4,%xmm6
   2195a:	66 41 0f 7e f3       	movd   %xmm6,%r11d
   2195f:	45 0f b6 d6          	movzbl %r14b,%r10d
   21963:	45 0f b6 f8          	movzbl %r8b,%r15d
   21967:	66 41 0f 6e f2       	movd   %r10d,%xmm6
   2196c:	66 45 0f 6e cf       	movd   %r15d,%xmm9
   21971:	66 41 0f 6c f1       	punpcklqdq %xmm9,%xmm6
   21976:	66 44 0f c5 d5 04    	pextrw $0x4,%xmm5,%r10d
   2197c:	66 41 0f 7e ef       	movd   %xmm5,%r15d
   21981:	0f c6 e9 88          	shufps $0x88,%xmm1,%xmm5
   21985:	0f c6 f2 82          	shufps $0x82,%xmm2,%xmm6
   21989:	66 45 0f 76 c9       	pcmpeqd %xmm9,%xmm9
   2198e:	41 0f 57 f1          	xorps  %xmm9,%xmm6
   21992:	0f 56 f5             	orps   %xmm5,%xmm6
   21995:	41 89 cc             	mov    %ecx,%r12d
   21998:	66 0f 7e e1          	movd   %xmm4,%ecx
   2199c:	66 0f 72 f6 1f       	pslld  $0x1f,%xmm6
   219a1:	66 0f 72 e6 1f       	psrad  $0x1f,%xmm6
   219a6:	66 44 0f db fe       	pand   %xmm6,%xmm15
   219ab:	66 0f df f4          	pandn  %xmm4,%xmm6
   219af:	41 f6 c7 01          	test   $0x1,%r15b
   219b3:	41 0f 44 cc          	cmove  %r12d,%ecx
   219b7:	41 f6 c0 01          	test   $0x1,%r8b
   219bb:	41 0f 44 cc          	cmove  %r12d,%ecx
   219bf:	66 41 0f eb f7       	por    %xmm15,%xmm6
   219c4:	41 f6 c2 01          	test   $0x1,%r10b
   219c8:	44 0f 44 db          	cmove  %ebx,%r11d
   219cc:	0f 54 ca             	andps  %xmm2,%xmm1
   219cf:	45 84 f6             	test   %r14b,%r14b
   219d2:	44 0f 44 db          	cmove  %ebx,%r11d
   219d6:	66 41 0f 7e f0       	movd   %xmm6,%r8d
   219db:	41 89 ca             	mov    %ecx,%r10d
   219de:	45 29 c2             	sub    %r8d,%r10d
   219e1:	41 83 fa 02          	cmp    $0x2,%r10d
   219e5:	41 0f 93 c0          	setae  %r8b
   219e9:	66 0f 70 c9 e8       	pshufd $0xe8,%xmm1,%xmm1
   219ee:	66 0f 72 f1 1f       	pslld  $0x1f,%xmm1
   219f3:	66 0f 72 e1 1f       	psrad  $0x1f,%xmm1
   219f8:	66 0f db d9          	pand   %xmm1,%xmm3
   219fc:	66 0f df c8          	pandn  %xmm0,%xmm1
   21a00:	66 0f 6f c1          	movdqa %xmm1,%xmm0
   21a04:	66 0f eb c3          	por    %xmm3,%xmm0
   21a08:	66 0f 70 ce ee       	pshufd $0xee,%xmm6,%xmm1
   21a0d:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   21a11:	66 0f fa d9          	psubd  %xmm1,%xmm3
   21a15:	66 0f 70 d3 50       	pshufd $0x50,%xmm3,%xmm2
   21a1a:	66 41 0f ef d2       	pxor   %xmm10,%xmm2
   21a1f:	66 0f 66 15 e9 3b fe 	pcmpgtd -0x1c417(%rip),%xmm2        # 5610 <std::thread::current::id::ID+0x4998>
   21a26:	ff 
   21a27:	66 41 0f db d4       	pand   %xmm12,%xmm2
   21a2c:	41 20 f0             	and    %sil,%r8b
   21a2f:	66 0f 50 da          	movmskpd %xmm2,%ebx
   21a33:	85 db                	test   %ebx,%ebx
   21a35:	0f 95 c3             	setne  %bl
   21a38:	45 84 c0             	test   %r8b,%r8b
   21a3b:	0f 85 4f fe ff ff    	jne    21890 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xde0>
   21a41:	84 db                	test   %bl,%bl
   21a43:	0f 85 47 fe ff ff    	jne    21890 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xde0>
   21a49:	66 0f 70 c6 ee       	pshufd $0xee,%xmm6,%xmm0
   21a4e:	0f 5a c0             	cvtps2pd %xmm0,%xmm0
   21a51:	0f 5a ce             	cvtps2pd %xmm6,%xmm1
   21a54:	66 41 0f db c4       	pand   %xmm12,%xmm0
   21a59:	66 44 0f df a4 24 90 	pandn  0x90(%rsp),%xmm12
   21a60:	00 00 00 
   21a63:	66 44 0f eb e0       	por    %xmm0,%xmm12
   21a68:	66 0f 54 cf          	andpd  %xmm7,%xmm1
   21a6c:	66 0f 55 7c 24 20    	andnpd 0x20(%rsp),%xmm7
   21a72:	66 0f 56 f9          	orpd   %xmm1,%xmm7
   21a76:	66 0f 29 7c 24 20    	movapd %xmm7,0x20(%rsp)
   21a7c:	66 44 0f 28 3d 9b 37 	movapd -0x1c865(%rip),%xmm15        # 5220 <std::thread::current::id::ID+0x45a8>
   21a83:	fe ff 
   21a85:	66 44 0f 28 8c 24 80 	movapd 0x80(%rsp),%xmm9
   21a8c:	00 00 00 
   21a8f:	66 44 0f 28 74 24 50 	movapd 0x50(%rsp),%xmm14
   21a96:	e9 2f f3 ff ff       	jmp    20dca <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x31a>
   21a9b:	66 44 0f 29 27       	movapd %xmm12,(%rdi)
   21aa0:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   21aa5:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   21aa9:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   21aae:	0f 29 47 20          	movaps %xmm0,0x20(%rdi)
   21ab2:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   21ab7:	0f 29 47 30          	movaps %xmm0,0x30(%rdi)
   21abb:	48 8d 65 e0          	lea    -0x20(%rbp),%rsp
   21abf:	5b                   	pop    %rbx
   21ac0:	41 5c                	pop    %r12
   21ac2:	41 5e                	pop    %r14
   21ac4:	41 5f                	pop    %r15
   21ac6:	5d                   	pop    %rbp
   21ac7:	c3                   	ret
   21ac8:	cc                   	int3
   21ac9:	cc                   	int3
   21aca:	cc                   	int3
   21acb:	cc                   	int3
   21acc:	cc                   	int3
   21acd:	cc                   	int3
   21ace:	cc                   	int3
   21acf:	cc                   	int3

0000000000021ad0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>:
   21ad0:	55                   	push   %rbp
   21ad1:	48 89 e5             	mov    %rsp,%rbp
   21ad4:	41 57                	push   %r15
   21ad6:	41 56                	push   %r14
   21ad8:	41 55                	push   %r13
   21ada:	41 54                	push   %r12
   21adc:	53                   	push   %rbx
   21add:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   21ae1:	48 81 ec 40 02 00 00 	sub    $0x240,%rsp
   21ae8:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   21aee:	89 fb                	mov    %edi,%ebx
   21af0:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
   21af5:	0f 57 c0             	xorps  %xmm0,%xmm0
   21af8:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   21afc:	f2 0f 59 05 84 58 fe 	mulsd  -0x1a77c(%rip),%xmm0        # 7388 <std::thread::current::id::ID+0x6710>
   21b03:	ff 
   21b04:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   21b0b:	00 
   21b0c:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   21b13:	00 
   21b14:	ff 15 16 3d 04 00    	call   *0x43d16(%rip)        # 65830 <sincos@GLIBC_2.2.5>
   21b1a:	f2 0f 10 84 24 98 00 	movsd  0x98(%rsp),%xmm0
   21b21:	00 00 
   21b23:	f2 0f 10 8c 24 90 00 	movsd  0x90(%rsp),%xmm1
   21b2a:	00 00 
   21b2c:	f2 0f 10 15 2c 58 fe 	movsd  -0x1a7d4(%rip),%xmm2        # 7360 <std::thread::current::id::ID+0x66e8>
   21b33:	ff 
   21b34:	f2 0f 59 d1          	mulsd  %xmm1,%xmm2
   21b38:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   21b3c:	f2 0f 58 d4          	addsd  %xmm4,%xmm2
   21b40:	f2 0f 10 1d 70 57 fe 	movsd  -0x1a890(%rip),%xmm3        # 72b8 <std::thread::current::id::ID+0x6640>
   21b47:	ff 
   21b48:	f2 0f 59 d9          	mulsd  %xmm1,%xmm3
   21b4c:	f2 0f 58 dc          	addsd  %xmm4,%xmm3
   21b50:	f2 44 0f 10 0d 9f 57 	movsd  -0x1a861(%rip),%xmm9        # 72f8 <std::thread::current::id::ID+0x6680>
   21b57:	fe ff 
   21b59:	f2 44 0f 59 c8       	mulsd  %xmm0,%xmm9
   21b5e:	f2 44 0f 58 ca       	addsd  %xmm2,%xmm9
   21b63:	f2 0f 10 2d 55 58 fe 	movsd  -0x1a7ab(%rip),%xmm5        # 73c0 <std::thread::current::id::ID+0x6748>
   21b6a:	ff 
   21b6b:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21b6f:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   21b73:	f2 0f 59 0d cd 57 fe 	mulsd  -0x1a833(%rip),%xmm1        # 7348 <std::thread::current::id::ID+0x66d0>
   21b7a:	ff 
   21b7b:	f2 0f 58 cc          	addsd  %xmm4,%xmm1
   21b7f:	f2 0f 59 05 11 56 fe 	mulsd  -0x1a9ef(%rip),%xmm0        # 7198 <std::thread::current::id::ID+0x6520>
   21b86:	ff 
   21b87:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   21b8b:	85 db                	test   %ebx,%ebx
   21b8d:	74 3f                	je     21bce <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xfe>
   21b8f:	0f 28 0d 4a 3c fe ff 	movaps -0x1c3b6(%rip),%xmm1        # 57e0 <std::thread::current::id::ID+0x4b68>
   21b96:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21b9b:	66 0f 28 0d cd 3c fe 	movapd -0x1c333(%rip),%xmm1        # 5870 <std::thread::current::id::ID+0x4bf8>
   21ba2:	ff 
   21ba3:	66 0f 28 25 f5 37 fe 	movapd -0x1c80b(%rip),%xmm4        # 53a0 <std::thread::current::id::ID+0x4728>
   21baa:	ff 
   21bab:	66 0f 28 35 cd 3c fe 	movapd -0x1c333(%rip),%xmm6        # 5880 <std::thread::current::id::ID+0x4c08>
   21bb2:	ff 
   21bb3:	f3 0f 7e 1d 35 56 fe 	movq   -0x1a9cb(%rip),%xmm3        # 71f0 <std::thread::current::id::ID+0x6578>
   21bba:	ff 
   21bbb:	f2 44 0f 10 3d 14 57 	movsd  -0x1a8ec(%rip),%xmm15        # 72d8 <std::thread::current::id::ID+0x6660>
   21bc2:	fe ff 
   21bc4:	f3 0f 7e 15 34 56 fe 	movq   -0x1a9cc(%rip),%xmm2        # 7200 <std::thread::current::id::ID+0x6588>
   21bcb:	ff 
   21bcc:	eb 3d                	jmp    21c0b <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0x13b>
   21bce:	0f 28 0d ab 37 fe ff 	movaps -0x1c855(%rip),%xmm1        # 5380 <std::thread::current::id::ID+0x4708>
   21bd5:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21bda:	66 0f 28 0d 4e 39 fe 	movapd -0x1c6b2(%rip),%xmm1        # 5530 <std::thread::current::id::ID+0x48b8>
   21be1:	ff 
   21be2:	66 0f 28 25 56 37 fe 	movapd -0x1c8aa(%rip),%xmm4        # 5340 <std::thread::current::id::ID+0x46c8>
   21be9:	ff 
   21bea:	66 0f 28 35 de 3b fe 	movapd -0x1c422(%rip),%xmm6        # 57d0 <std::thread::current::id::ID+0x4b58>
   21bf1:	ff 
   21bf2:	f3 0f 7e 1d 2e 57 fe 	movq   -0x1a8d2(%rip),%xmm3        # 7328 <std::thread::current::id::ID+0x66b0>
   21bf9:	ff 
   21bfa:	f2 44 0f 10 3d 15 57 	movsd  -0x1a8eb(%rip),%xmm15        # 7318 <std::thread::current::id::ID+0x66a0>
   21c01:	fe ff 
   21c03:	f3 0f 7e 15 85 56 fe 	movq   -0x1a97b(%rip),%xmm2        # 7290 <std::thread::current::id::ID+0x6618>
   21c0a:	ff 
   21c0b:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   21c11:	66 44 0f 14 cd       	unpcklpd %xmm5,%xmm9
   21c16:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   21c1b:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   21c20:	66 0f 28 e8          	movapd %xmm0,%xmm5
   21c24:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21c28:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21c2c:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   21c31:	66 41 0f 28 fb       	movapd %xmm11,%xmm7
   21c36:	66 41 0f c6 fb 01    	shufpd $0x1,%xmm11,%xmm7
   21c3c:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   21c40:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   21c45:	66 44 0f 59 c6       	mulpd  %xmm6,%xmm8
   21c4a:	66 44 0f 58 c7       	addpd  %xmm7,%xmm8
   21c4f:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   21c53:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   21c58:	66 44 0f 59 f1       	mulpd  %xmm1,%xmm14
   21c5d:	66 45 0f 58 f0       	addpd  %xmm8,%xmm14
   21c62:	f3 0f 7e fa          	movq   %xmm2,%xmm7
   21c66:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   21c6a:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   21c6f:	66 45 0f 14 c7       	unpcklpd %xmm15,%xmm8
   21c74:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   21c79:	66 45 0f 59 d8       	mulpd  %xmm8,%xmm11
   21c7e:	66 45 0f c6 db 01    	shufpd $0x1,%xmm11,%xmm11
   21c84:	f3 44 0f 7e d3       	movq   %xmm3,%xmm10
   21c89:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   21c8e:	66 41 0f 58 d3       	addpd  %xmm11,%xmm2
   21c93:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   21c97:	66 0f 29 94 24 80 00 	movapd %xmm2,0x80(%rsp)
   21c9e:	00 00 
   21ca0:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   21ca5:	66 44 0f 59 1d 32 37 	mulpd  -0x1c8ce(%rip),%xmm11        # 53e0 <std::thread::current::id::ID+0x4768>
   21cac:	fe ff 
   21cae:	66 45 0f 59 cb       	mulpd  %xmm11,%xmm9
   21cb3:	66 0f 6f eb          	movdqa %xmm3,%xmm5
   21cb7:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   21cbc:	66 45 0f 28 e1       	movapd %xmm9,%xmm12
   21cc1:	66 45 0f c6 e1 01    	shufpd $0x1,%xmm9,%xmm12
   21cc7:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   21ccc:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
   21cd1:	66 44 0f 59 ee       	mulpd  %xmm6,%xmm13
   21cd6:	66 45 0f 58 ec       	addpd  %xmm12,%xmm13
   21cdb:	f2 0f 10 15 e5 55 fe 	movsd  -0x1aa1b(%rip),%xmm2        # 72c8 <std::thread::current::id::ID+0x6650>
   21ce2:	ff 
   21ce3:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   21ce7:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   21ceb:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   21cef:	66 44 0f 28 c8       	movapd %xmm0,%xmm9
   21cf4:	66 44 0f 59 c9       	mulpd  %xmm1,%xmm9
   21cf9:	66 45 0f 58 cd       	addpd  %xmm13,%xmm9
   21cfe:	66 44 0f 29 4c 24 60 	movapd %xmm9,0x60(%rsp)
   21d05:	66 44 0f 28 e3       	movapd %xmm3,%xmm12
   21d0a:	66 45 0f 59 e0       	mulpd  %xmm8,%xmm12
   21d0f:	66 45 0f c6 e4 01    	shufpd $0x1,%xmm12,%xmm12
   21d15:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
   21d1a:	66 41 0f 58 dc       	addpd  %xmm12,%xmm3
   21d1f:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   21d23:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   21d27:	66 0f 29 5c 24 70    	movapd %xmm3,0x70(%rsp)
   21d2d:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   21d32:	66 41 0f c6 c3 01    	shufpd $0x1,%xmm11,%xmm0
   21d38:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21d3c:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   21d41:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   21d45:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   21d49:	66 0f 28 c2          	movapd %xmm2,%xmm0
   21d4d:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21d51:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   21d55:	66 0f 28 f0          	movapd %xmm0,%xmm6
   21d59:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   21d5f:	66 45 0f 59 c3       	mulpd  %xmm11,%xmm8
   21d64:	66 45 0f c6 c0 01    	shufpd $0x1,%xmm8,%xmm8
   21d6a:	66 45 0f 59 da       	mulpd  %xmm10,%xmm11
   21d6f:	66 45 0f 58 d8       	addpd  %xmm8,%xmm11
   21d74:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   21d78:	66 41 0f 58 d3       	addpd  %xmm11,%xmm2
   21d7d:	66 0f 29 94 24 60 01 	movapd %xmm2,0x160(%rsp)
   21d84:	00 00 
   21d86:	f2 44 0f 58 fd       	addsd  %xmm5,%xmm15
   21d8b:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   21d91:	66 0f 58 c1          	addpd  %xmm1,%xmm0
   21d95:	66 0f 29 44 24 10    	movapd %xmm0,0x10(%rsp)
   21d9b:	f2 44 0f 58 7c 24 30 	addsd  0x30(%rsp),%xmm15
   21da2:	66 44 0f 29 7c 24 30 	movapd %xmm15,0x30(%rsp)
   21da9:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   21dae:	66 45 0f 28 fe       	movapd %xmm14,%xmm15
   21db3:	66 44 0f 29 b4 24 70 	movapd %xmm14,0x170(%rsp)
   21dba:	01 00 00 
   21dbd:	66 0f 59 1d 1b 36 fe 	mulpd  -0x1c9e5(%rip),%xmm3        # 53e0 <std::thread::current::id::ID+0x4768>
   21dc4:	ff 
   21dc5:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   21dca:	66 45 0f 58 c1       	addpd  %xmm9,%xmm8
   21dcf:	66 45 0f 28 d0       	movapd %xmm8,%xmm10
   21dd4:	66 45 0f 59 d0       	mulpd  %xmm8,%xmm10
   21dd9:	66 0f 59 f3          	mulpd  %xmm3,%xmm6
   21ddd:	66 0f 59 35 6b 36 fe 	mulpd  -0x1c995(%rip),%xmm6        # 5450 <std::thread::current::id::ID+0x47d8>
   21de4:	ff 
   21de5:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   21dea:	66 0f 5c fe          	subpd  %xmm6,%xmm7
   21dee:	66 45 0f 28 c8       	movapd %xmm8,%xmm9
   21df3:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21df7:	66 44 0f c2 c8 05    	cmpnltpd %xmm0,%xmm9
   21dfd:	66 0f 28 cf          	movapd %xmm7,%xmm1
   21e01:	66 0f 5f c8          	maxpd  %xmm0,%xmm1
   21e05:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21e09:	66 0f 51 e1          	sqrtpd %xmm1,%xmm4
   21e0d:	66 0f 28 2d 7b 39 fe 	movapd -0x1c685(%rip),%xmm5        # 5790 <std::thread::current::id::ID+0x4b18>
   21e14:	ff 
   21e15:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
   21e1a:	66 44 0f 57 dd       	xorpd  %xmm5,%xmm11
   21e1f:	66 41 0f 54 e1       	andpd  %xmm9,%xmm4
   21e24:	66 45 0f 55 cb       	andnpd %xmm11,%xmm9
   21e29:	66 44 0f 56 cc       	orpd   %xmm4,%xmm9
   21e2e:	66 0f 28 05 ea 33 fe 	movapd -0x1cc16(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   21e35:	ff 
   21e36:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   21e3a:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   21e3f:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   21e44:	66 44 0f c2 df 02    	cmplepd %xmm7,%xmm11
   21e4a:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   21e4e:	66 0f 59 35 ca 36 fe 	mulpd  -0x1c936(%rip),%xmm6        # 5520 <std::thread::current::id::ID+0x48a8>
   21e55:	ff 
   21e56:	66 0f c2 fe 02       	cmplepd %xmm6,%xmm7
   21e5b:	66 44 0f 28 d3       	movapd %xmm3,%xmm10
   21e60:	66 44 0f c2 d2 04    	cmpneqpd %xmm2,%xmm10
   21e66:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   21e6b:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   21e70:	66 0f c2 c2 00       	cmpeqpd %xmm2,%xmm0
   21e75:	66 0f 28 25 23 38 fe 	movapd -0x1c7dd(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   21e7c:	ff 
   21e7d:	66 44 0f 28 f4       	movapd %xmm4,%xmm14
   21e82:	66 44 0f 54 f0       	andpd  %xmm0,%xmm14
   21e87:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   21e8c:	66 44 0f 28 e0       	movapd %xmm0,%xmm12
   21e91:	66 41 0f 56 c2       	orpd   %xmm10,%xmm0
   21e96:	66 41 0f 54 fa       	andpd  %xmm10,%xmm7
   21e9b:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   21ea0:	66 0f 55 cc          	andnpd %xmm4,%xmm1
   21ea4:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   21ea8:	66 45 0f 58 c8       	addpd  %xmm8,%xmm9
   21ead:	66 44 0f 28 15 da 39 	movapd -0x1c626(%rip),%xmm10        # 5890 <std::thread::current::id::ID+0x4c18>
   21eb4:	fe ff 
   21eb6:	66 45 0f 59 ca       	mulpd  %xmm10,%xmm9
   21ebb:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   21ec0:	66 0f c2 da 04       	cmpneqpd %xmm2,%xmm3
   21ec5:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   21eca:	66 0f 54 f3          	andpd  %xmm3,%xmm6
   21ece:	66 45 0f 70 eb a0    	pshufd $0xa0,%xmm11,%xmm13
   21ed4:	66 44 0f 54 db       	andpd  %xmm3,%xmm11
   21ed9:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   21edd:	66 0f 56 de          	orpd   %xmm6,%xmm3
   21ee1:	66 45 0f 55 e0       	andnpd %xmm8,%xmm12
   21ee6:	66 45 0f 56 f4       	orpd   %xmm12,%xmm14
   21eeb:	66 44 0f 5e c9       	divpd  %xmm1,%xmm9
   21ef0:	66 44 0f 57 fd       	xorpd  %xmm5,%xmm15
   21ef5:	66 44 0f 29 7c 24 20 	movapd %xmm15,0x20(%rsp)
   21efc:	66 44 0f 29 bc 24 a0 	movapd %xmm15,0xa0(%rsp)
   21f03:	00 00 00 
   21f06:	66 0f 28 a4 24 80 00 	movapd 0x80(%rsp),%xmm4
   21f0d:	00 00 
   21f0f:	66 0f 28 cc          	movapd %xmm4,%xmm1
   21f13:	66 0f 57 cd          	xorpd  %xmm5,%xmm1
   21f17:	66 0f 29 8c 24 b0 00 	movapd %xmm1,0xb0(%rsp)
   21f1e:	00 00 
   21f20:	66 0f 28 74 24 60    	movapd 0x60(%rsp),%xmm6
   21f26:	66 0f 57 f5          	xorpd  %xmm5,%xmm6
   21f2a:	66 0f 29 b4 24 c0 00 	movapd %xmm6,0xc0(%rsp)
   21f31:	00 00 
   21f33:	66 0f 28 54 24 70    	movapd 0x70(%rsp),%xmm2
   21f39:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   21f3e:	66 44 0f 57 c5       	xorpd  %xmm5,%xmm8
   21f43:	66 44 0f 29 84 24 d0 	movapd %xmm8,0xd0(%rsp)
   21f4a:	00 00 00 
   21f4d:	66 0f 28 4c 24 50    	movapd 0x50(%rsp),%xmm1
   21f53:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   21f58:	66 44 0f 57 c5       	xorpd  %xmm5,%xmm8
   21f5d:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
   21f62:	66 44 0f 29 84 24 e0 	movapd %xmm8,0xe0(%rsp)
   21f69:	00 00 00 
   21f6c:	66 45 0f 5e c6       	divpd  %xmm14,%xmm8
   21f71:	66 0f 73 f0 3f       	psllq  $0x3f,%xmm0
   21f76:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   21f7b:	66 44 0f 70 e0 f5    	pshufd $0xf5,%xmm0,%xmm12
   21f81:	66 45 0f df e0       	pandn  %xmm8,%xmm12
   21f86:	66 44 0f 6f 35 c1 37 	movdqa -0x1c83f(%rip),%xmm14        # 5750 <std::thread::current::id::ID+0x4ad8>
   21f8d:	fe ff 
   21f8f:	66 41 0f db c6       	pand   %xmm14,%xmm0
   21f94:	66 41 0f eb c4       	por    %xmm12,%xmm0
   21f99:	66 45 0f 54 cd       	andpd  %xmm13,%xmm9
   21f9e:	66 44 0f df e8       	pandn  %xmm0,%xmm13
   21fa3:	66 45 0f eb e9       	por    %xmm9,%xmm13
   21fa8:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21fac:	66 0f 5e c3          	divpd  %xmm3,%xmm0
   21fb0:	66 41 0f 70 db a0    	pshufd $0xa0,%xmm11,%xmm3
   21fb6:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21fba:	66 41 0f df de       	pandn  %xmm14,%xmm3
   21fbf:	66 0f eb d8          	por    %xmm0,%xmm3
   21fc3:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21fc7:	66 41 0f c2 c5 05    	cmpnltpd %xmm13,%xmm0
   21fcd:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
   21fd2:	66 44 0f db c0       	pand   %xmm0,%xmm8
   21fd7:	66 41 0f df c5       	pandn  %xmm13,%xmm0
   21fdc:	66 41 0f eb c0       	por    %xmm8,%xmm0
   21fe1:	66 45 0f ef c0       	pxor   %xmm8,%xmm8
   21fe6:	66 44 0f c2 c3 05    	cmpnltpd %xmm3,%xmm8
   21fec:	66 45 0f 6f ce       	movdqa %xmm14,%xmm9
   21ff1:	66 45 0f db c8       	pand   %xmm8,%xmm9
   21ff6:	66 44 0f df c3       	pandn  %xmm3,%xmm8
   21ffb:	66 45 0f eb c1       	por    %xmm9,%xmm8
   22000:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   22004:	66 41 0f 5d d8       	minpd  %xmm8,%xmm3
   22009:	66 44 0f 28 cb       	movapd %xmm3,%xmm9
   2200e:	66 44 0f c2 cb 03    	cmpunordpd %xmm3,%xmm9
   22014:	66 44 0f 6f d8       	movdqa %xmm0,%xmm11
   22019:	66 45 0f db d9       	pand   %xmm9,%xmm11
   2201e:	66 44 0f 55 cb       	andnpd %xmm3,%xmm9
   22023:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   22028:	66 41 0f 55 f9       	andnpd %xmm9,%xmm7
   2202d:	66 0f 29 bc 24 c0 01 	movapd %xmm7,0x1c0(%rsp)
   22034:	00 00 
   22036:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   2203a:	66 41 0f 5f d8       	maxpd  %xmm8,%xmm3
   2203f:	66 0f 28 fb          	movapd %xmm3,%xmm7
   22043:	66 0f c2 fb 03       	cmpunordpd %xmm3,%xmm7
   22048:	66 0f db c7          	pand   %xmm7,%xmm0
   2204c:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   22050:	66 0f 56 f8          	orpd   %xmm0,%xmm7
   22054:	66 0f 29 bc 24 e0 01 	movapd %xmm7,0x1e0(%rsp)
   2205b:	00 00 
   2205d:	66 0f 28 0d 7b 33 fe 	movapd -0x1cc85(%rip),%xmm1        # 53e0 <std::thread::current::id::ID+0x4768>
   22064:	ff 
   22065:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   22069:	66 0f 28 ac 24 60 01 	movapd 0x160(%rsp),%xmm5
   22070:	00 00 
   22072:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22076:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   2207a:	66 0f 28 e1          	movapd %xmm1,%xmm4
   2207e:	66 0f 59 05 ca 33 fe 	mulpd  -0x1cc36(%rip),%xmm0        # 5450 <std::thread::current::id::ID+0x47d8>
   22085:	ff 
   22086:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   2208b:	66 44 0f 58 da       	addpd  %xmm2,%xmm11
   22090:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   22095:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   2209a:	66 0f 28 fb          	movapd %xmm3,%xmm7
   2209e:	66 0f 5c f8          	subpd  %xmm0,%xmm7
   220a2:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   220a7:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   220ab:	f2 44 0f 5f c1       	maxsd  %xmm1,%xmm8
   220b0:	45 0f 57 c9          	xorps  %xmm9,%xmm9
   220b4:	f2 45 0f 51 c8       	sqrtsd %xmm8,%xmm9
   220b9:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   220be:	f2 44 0f c2 c1 05    	cmpnltsd %xmm1,%xmm8
   220c4:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   220c9:	66 45 0f 54 e1       	andpd  %xmm9,%xmm12
   220ce:	66 45 0f 57 cf       	xorpd  %xmm15,%xmm9
   220d3:	66 45 0f 55 c1       	andnpd %xmm9,%xmm8
   220d8:	66 45 0f 56 c4       	orpd   %xmm12,%xmm8
   220dd:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   220e2:	66 44 0f 15 cf       	unpckhpd %xmm7,%xmm9
   220e7:	f2 44 0f 5f c9       	maxsd  %xmm1,%xmm9
   220ec:	f2 45 0f 51 c9       	sqrtsd %xmm9,%xmm9
   220f1:	66 45 0f 14 c1       	unpcklpd %xmm9,%xmm8
   220f6:	66 45 0f 58 c3       	addpd  %xmm11,%xmm8
   220fb:	66 45 0f 59 c2       	mulpd  %xmm10,%xmm8
   22100:	66 0f 28 0d 18 31 fe 	movapd -0x1cee8(%rip),%xmm1        # 5220 <std::thread::current::id::ID+0x45a8>
   22107:	ff 
   22108:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2210c:	66 0f 58 c3          	addpd  %xmm3,%xmm0
   22110:	66 0f 59 05 08 34 fe 	mulpd  -0x1cbf8(%rip),%xmm0        # 5520 <std::thread::current::id::ID+0x48a8>
   22117:	ff 
   22118:	66 45 0f 57 d2       	xorpd  %xmm10,%xmm10
   2211d:	66 44 0f c2 d7 02    	cmplepd %xmm7,%xmm10
   22123:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   22127:	66 0f c2 f8 02       	cmplepd %xmm0,%xmm7
   2212c:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22130:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22134:	66 0f c2 c1 04       	cmpneqpd %xmm1,%xmm0
   22139:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   2213d:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   22142:	66 44 0f c2 e1 00    	cmpeqpd %xmm1,%xmm12
   22148:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   2214d:	66 0f 28 15 4b 35 fe 	movapd -0x1cab5(%rip),%xmm2        # 56a0 <std::thread::current::id::ID+0x4a28>
   22154:	ff 
   22155:	66 0f 28 da          	movapd %xmm2,%xmm3
   22159:	66 41 0f 54 dc       	andpd  %xmm12,%xmm3
   2215e:	66 44 0f 54 d0       	andpd  %xmm0,%xmm10
   22163:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   22168:	66 44 0f 56 e0       	orpd   %xmm0,%xmm12
   2216d:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   22171:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   22175:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   22179:	66 45 0f 28 e8       	movapd %xmm8,%xmm13
   2217e:	66 45 0f c2 ef 04    	cmpneqpd %xmm15,%xmm13
   22184:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   22188:	66 45 0f 28 f8       	movapd %xmm8,%xmm15
   2218d:	66 45 0f 54 fd       	andpd  %xmm13,%xmm15
   22192:	66 41 0f 70 ca a0    	pshufd $0xa0,%xmm10,%xmm1
   22198:	66 45 0f 54 d5       	andpd  %xmm13,%xmm10
   2219d:	66 44 0f 55 ea       	andnpd %xmm2,%xmm13
   221a2:	66 45 0f 56 ef       	orpd   %xmm15,%xmm13
   221a7:	66 45 0f 55 cb       	andnpd %xmm11,%xmm9
   221ac:	66 41 0f 56 d9       	orpd   %xmm9,%xmm3
   221b1:	66 44 0f 5e c0       	divpd  %xmm0,%xmm8
   221b6:	66 0f 28 c5          	movapd %xmm5,%xmm0
   221ba:	66 44 0f 28 1d cd 35 	movapd -0x1ca33(%rip),%xmm11        # 5790 <std::thread::current::id::ID+0x4b18>
   221c1:	fe ff 
   221c3:	66 41 0f 57 c3       	xorpd  %xmm11,%xmm0
   221c8:	66 0f 29 84 24 f0 00 	movapd %xmm0,0xf0(%rsp)
   221cf:	00 00 
   221d1:	66 0f 5e c3          	divpd  %xmm3,%xmm0
   221d5:	66 41 0f 73 f4 3f    	psllq  $0x3f,%xmm12
   221db:	66 41 0f 72 e4 1f    	psrad  $0x1f,%xmm12
   221e1:	66 41 0f 70 dc f5    	pshufd $0xf5,%xmm12,%xmm3
   221e7:	66 0f df d8          	pandn  %xmm0,%xmm3
   221eb:	66 45 0f db e6       	pand   %xmm14,%xmm12
   221f0:	66 44 0f eb e3       	por    %xmm3,%xmm12
   221f5:	66 44 0f 54 c1       	andpd  %xmm1,%xmm8
   221fa:	66 41 0f df cc       	pandn  %xmm12,%xmm1
   221ff:	66 41 0f eb c8       	por    %xmm8,%xmm1
   22204:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22208:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   2220d:	66 41 0f 5e c5       	divpd  %xmm13,%xmm0
   22212:	66 41 0f 70 da a0    	pshufd $0xa0,%xmm10,%xmm3
   22218:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   2221c:	66 41 0f df de       	pandn  %xmm14,%xmm3
   22221:	66 0f eb d8          	por    %xmm0,%xmm3
   22225:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   22229:	66 0f c2 c1 05       	cmpnltpd %xmm1,%xmm0
   2222e:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
   22233:	66 44 0f db c0       	pand   %xmm0,%xmm8
   22238:	66 0f df c1          	pandn  %xmm1,%xmm0
   2223c:	66 41 0f eb c0       	por    %xmm8,%xmm0
   22241:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   22245:	66 0f c2 d3 05       	cmpnltpd %xmm3,%xmm2
   2224a:	66 44 0f db f2       	pand   %xmm2,%xmm14
   2224f:	66 0f df d3          	pandn  %xmm3,%xmm2
   22253:	66 41 0f eb d6       	por    %xmm14,%xmm2
   22258:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   2225c:	66 0f 5d ca          	minpd  %xmm2,%xmm1
   22260:	66 0f 28 d9          	movapd %xmm1,%xmm3
   22264:	66 0f c2 d9 03       	cmpunordpd %xmm1,%xmm3
   22269:	66 44 0f 6f c0       	movdqa %xmm0,%xmm8
   2226e:	66 44 0f db c3       	pand   %xmm3,%xmm8
   22273:	66 0f 55 d9          	andnpd %xmm1,%xmm3
   22277:	66 41 0f 56 d8       	orpd   %xmm8,%xmm3
   2227c:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   22280:	66 0f 29 bc 24 d0 01 	movapd %xmm7,0x1d0(%rsp)
   22287:	00 00 
   22289:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   2228d:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   22291:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22295:	66 0f c2 d1 03       	cmpunordpd %xmm1,%xmm2
   2229a:	66 0f db c2          	pand   %xmm2,%xmm0
   2229e:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   222a2:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   222a6:	66 0f 28 5c 24 70    	movapd 0x70(%rsp),%xmm3
   222ac:	66 0f 28 c3          	movapd %xmm3,%xmm0
   222b0:	66 0f 28 2d 68 2f fe 	movapd -0x1d098(%rip),%xmm5        # 5220 <std::thread::current::id::ID+0x45a8>
   222b7:	ff 
   222b8:	66 0f 54 c5          	andpd  %xmm5,%xmm0
   222bc:	66 41 0f 28 c9       	movapd %xmm9,%xmm1
   222c1:	66 0f 54 cd          	andpd  %xmm5,%xmm1
   222c5:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   222ca:	f2 0f c2 dc 00       	cmpeqsd %xmm4,%xmm3
   222cf:	66 0f 28 fb          	movapd %xmm3,%xmm7
   222d3:	66 0f 55 f8          	andnpd %xmm0,%xmm7
   222d7:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   222db:	66 0f 56 df          	orpd   %xmm7,%xmm3
   222df:	66 0f 28 ac 24 80 00 	movapd 0x80(%rsp),%xmm5
   222e6:	00 00 
   222e8:	66 0f 28 fd          	movapd %xmm5,%xmm7
   222ec:	66 41 0f 54 f9       	andpd  %xmm9,%xmm7
   222f1:	f2 0f c2 e5 00       	cmpeqsd %xmm5,%xmm4
   222f6:	66 44 0f 28 c4       	movapd %xmm4,%xmm8
   222fb:	66 44 0f 55 c7       	andnpd %xmm7,%xmm8
   22300:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   22304:	66 41 0f 56 e0       	orpd   %xmm8,%xmm4
   22309:	f2 0f 5f 25 0f 4f fe 	maxsd  -0x1b0f1(%rip),%xmm4        # 7220 <std::thread::current::id::ID+0x65a8>
   22310:	ff 
   22311:	66 0f 29 94 24 f0 01 	movapd %xmm2,0x1f0(%rsp)
   22318:	00 00 
   2231a:	66 0f 28 d0          	movapd %xmm0,%xmm2
   2231e:	f2 0f 5f d1          	maxsd  %xmm1,%xmm2
   22322:	66 0f 28 ca          	movapd %xmm2,%xmm1
   22326:	f2 0f c2 ca 03       	cmpunordsd %xmm2,%xmm1
   2232b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2232f:	66 0f 55 ca          	andnpd %xmm2,%xmm1
   22333:	66 0f 56 c8          	orpd   %xmm0,%xmm1
   22337:	66 0f 28 7c 24 30    	movapd 0x30(%rsp),%xmm7
   2233d:	66 0f 28 c7          	movapd %xmm7,%xmm0
   22341:	66 41 0f 54 c1       	andpd  %xmm9,%xmm0
   22346:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2234a:	f2 0f 5f d8          	maxsd  %xmm0,%xmm3
   2234e:	66 0f 28 d3          	movapd %xmm3,%xmm2
   22352:	f2 0f c2 d3 03       	cmpunordsd %xmm3,%xmm2
   22357:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   2235b:	66 0f 55 d3          	andnpd %xmm3,%xmm2
   2235f:	66 0f 56 d1          	orpd   %xmm1,%xmm2
   22363:	f2 0f 5e d4          	divsd  %xmm4,%xmm2
   22367:	66 0f 28 a4 24 70 01 	movapd 0x170(%rsp),%xmm4
   2236e:	00 00 
   22370:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22374:	66 0f c2 44 24 20 00 	cmpeqpd 0x20(%rsp),%xmm0
   2237b:	66 0f 28 5c 24 60    	movapd 0x60(%rsp),%xmm3
   22381:	66 0f 28 cb          	movapd %xmm3,%xmm1
   22385:	66 0f c2 ce 00       	cmpeqpd %xmm6,%xmm1
   2238a:	66 41 0f 54 d9       	andpd  %xmm9,%xmm3
   2238f:	66 0f 28 6c 24 50    	movapd 0x50(%rsp),%xmm5
   22395:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   2239a:	66 0f 28 f3          	movapd %xmm3,%xmm6
   2239e:	66 0f 5f f5          	maxpd  %xmm5,%xmm6
   223a2:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   223a6:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   223aa:	66 0f 56 cd          	orpd   %xmm5,%xmm1
   223ae:	66 0f 28 ec          	movapd %xmm4,%xmm5
   223b2:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   223b7:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   223bb:	66 0f 55 c5          	andnpd %xmm5,%xmm0
   223bf:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   223c3:	66 0f 28 ce          	movapd %xmm6,%xmm1
   223c7:	66 0f c2 ce 03       	cmpunordpd %xmm6,%xmm1
   223cc:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   223d0:	66 0f 55 ce          	andnpd %xmm6,%xmm1
   223d4:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   223d8:	66 0f 28 6c 24 10    	movapd 0x10(%rsp),%xmm5
   223de:	66 44 0f 54 cd       	andpd  %xmm5,%xmm9
   223e3:	66 0f 28 d9          	movapd %xmm1,%xmm3
   223e7:	66 41 0f 5f d9       	maxpd  %xmm9,%xmm3
   223ec:	66 0f 28 e3          	movapd %xmm3,%xmm4
   223f0:	66 0f c2 e3 03       	cmpunordpd %xmm3,%xmm4
   223f5:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   223f9:	66 0f 55 e3          	andnpd %xmm3,%xmm4
   223fd:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   22401:	66 0f 5f 05 b7 2e fe 	maxpd  -0x1d149(%rip),%xmm0        # 52c0 <std::thread::current::id::ID+0x4648>
   22408:	ff 
   22409:	66 0f 5e e0          	divpd  %xmm0,%xmm4
   2240d:	66 0f 58 25 8b 32 fe 	addpd  -0x1cd75(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   22414:	ff 
   22415:	66 0f 29 a4 24 80 01 	movapd %xmm4,0x180(%rsp)
   2241c:	00 00 
   2241e:	f2 0f 58 15 32 4e fe 	addsd  -0x1b1ce(%rip),%xmm2        # 7258 <std::thread::current::id::ID+0x65e0>
   22425:	ff 
   22426:	f2 0f 11 94 24 90 01 	movsd  %xmm2,0x190(%rsp)
   2242d:	00 00 
   2242f:	66 0f 28 c7          	movapd %xmm7,%xmm0
   22433:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   22438:	66 41 0f 57 c3       	xorpd  %xmm11,%xmm0
   2243d:	66 0f 57 d5          	xorpd  %xmm5,%xmm2
   22441:	66 0f 29 94 24 00 01 	movapd %xmm2,0x100(%rsp)
   22448:	00 00 
   2244a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   22451:	00 f0 3f 
   22454:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
   2245b:	00 
   2245c:	66 0f 13 84 24 10 01 	movlpd %xmm0,0x110(%rsp)
   22463:	00 00 
   22465:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   2246b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2246f:	48 b8 00 00 00 00 00 	movabs $0xbff0000000000000,%rax
   22476:	00 f0 bf 
   22479:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   22480:	00 
   22481:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   22488:	00 
   22489:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   22490:	00 
   22491:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
   22498:	00 
   22499:	48 8d 8c 24 80 01 00 	lea    0x180(%rsp),%rcx
   224a0:	00 
   224a1:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
   224a7:	e8 04 e6 ff ff       	call   20ab0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>
   224ac:	f2 0f 10 84 24 20 01 	movsd  0x120(%rsp),%xmm0
   224b3:	00 00 
   224b5:	f2 0f 10 8c 24 28 01 	movsd  0x128(%rsp),%xmm1
   224bc:	00 00 
   224be:	f2 0f 10 ac 24 30 01 	movsd  0x130(%rsp),%xmm5
   224c5:	00 00 
   224c7:	f2 0f 5d 05 29 4d fe 	minsd  -0x1b2d7(%rip),%xmm0        # 71f8 <std::thread::current::id::ID+0x6580>
   224ce:	ff 
   224cf:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   224d3:	f2 0f 5d e9          	minsd  %xmm1,%xmm5
   224d7:	66 48 0f 7e e8       	movq   %xmm5,%rax
   224dc:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   224e3:	ff ff 7f 
   224e6:	4c 21 f8             	and    %r15,%rax
   224e9:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   224ef:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   224f6:	ff ef 7f 
   224f9:	48 39 c8             	cmp    %rcx,%rax
   224fc:	7e 12                	jle    22510 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa40>
   224fe:	4c 89 f0             	mov    %r14,%rax
   22501:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   22505:	5b                   	pop    %rbx
   22506:	41 5c                	pop    %r12
   22508:	41 5d                	pop    %r13
   2250a:	41 5e                	pop    %r14
   2250c:	41 5f                	pop    %r15
   2250e:	5d                   	pop    %rbp
   2250f:	c3                   	ret
   22510:	f2 0f 10 84 24 40 01 	movsd  0x140(%rsp),%xmm0
   22517:	00 00 
   22519:	0f 29 84 24 b0 01 00 	movaps %xmm0,0x1b0(%rsp)
   22520:	00 
   22521:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   22528:	00 
   22529:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   22530:	00 
   22531:	f2 0f 10 4c 24 20    	movsd  0x20(%rsp),%xmm1
   22537:	66 0f 28 c1          	movapd %xmm1,%xmm0
   2253b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2253f:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22543:	66 0f 28 e1          	movapd %xmm1,%xmm4
   22547:	f2 0f 10 0d 09 4d fe 	movsd  -0x1b2f7(%rip),%xmm1        # 7258 <std::thread::current::id::ID+0x65e0>
   2254e:	ff 
   2254f:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22553:	f2 0f 5e d0          	divsd  %xmm0,%xmm2
   22557:	66 0f 28 5c 24 30    	movapd 0x30(%rsp),%xmm3
   2255d:	f2 0f 5c da          	subsd  %xmm2,%xmm3
   22561:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   22565:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   22569:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   2256f:	66 0f 5c c2          	subpd  %xmm2,%xmm0
   22573:	66 0f 29 84 24 00 01 	movapd %xmm0,0x100(%rsp)
   2257a:	00 00 
   2257c:	f2 0f 11 9c 24 10 01 	movsd  %xmm3,0x110(%rsp)
   22583:	00 00 
   22585:	f2 0f 11 8c 24 18 01 	movsd  %xmm1,0x118(%rsp)
   2258c:	00 00 
   2258e:	0f 28 84 24 70 01 00 	movaps 0x170(%rsp),%xmm0
   22595:	00 
   22596:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   2259d:	00 
   2259e:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   225a5:	00 
   225a6:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   225ad:	00 
   225ae:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   225b3:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   225ba:	00 
   225bb:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   225c0:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   225c7:	00 
   225c8:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   225cd:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   225d4:	00 
   225d5:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   225dc:	00 
   225dd:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   225e4:	00 
   225e5:	66 0f 28 cd          	movapd %xmm5,%xmm1
   225e9:	66 0f 28 c4          	movapd %xmm4,%xmm0
   225ed:	f2 0f 5e cc          	divsd  %xmm4,%xmm1
   225f1:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   225f5:	66 0f 29 8c 24 10 02 	movapd %xmm1,0x210(%rsp)
   225fc:	00 00 
   225fe:	66 0f 29 8c 24 00 02 	movapd %xmm1,0x200(%rsp)
   22605:	00 00 
   22607:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   2260e:	00 
   2260f:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   22616:	00 
   22617:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
   2261e:	00 
   2261f:	48 8d 8c 24 00 02 00 	lea    0x200(%rsp),%rcx
   22626:	00 
   22627:	0f 29 6c 24 10       	movaps %xmm5,0x10(%rsp)
   2262c:	e8 7f e4 ff ff       	call   20ab0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>
   22631:	66 0f 28 94 24 b0 01 	movapd 0x1b0(%rsp),%xmm2
   22638:	00 00 
   2263a:	66 0f 28 c2          	movapd %xmm2,%xmm0
   2263e:	f2 0f 5d 84 24 40 01 	minsd  0x140(%rsp),%xmm0
   22645:	00 00 
   22647:	66 0f 28 c8          	movapd %xmm0,%xmm1
   2264b:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   22650:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   22654:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   22658:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   2265c:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   22662:	66 0f 28 c3          	movapd %xmm3,%xmm0
   22666:	f2 0f 5d 84 24 20 01 	minsd  0x120(%rsp),%xmm0
   2266d:	00 00 
   2266f:	66 0f 28 d0          	movapd %xmm0,%xmm2
   22673:	f2 0f c2 d0 03       	cmpunordsd %xmm0,%xmm2
   22678:	66 0f 54 da          	andpd  %xmm2,%xmm3
   2267c:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   22680:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   22684:	f2 0f 10 84 24 28 01 	movsd  0x128(%rsp),%xmm0
   2268b:	00 00 
   2268d:	66 0f 28 da          	movapd %xmm2,%xmm3
   22691:	f2 0f 5d d8          	minsd  %xmm0,%xmm3
   22695:	66 0f 28 e3          	movapd %xmm3,%xmm4
   22699:	f2 0f c2 e3 03       	cmpunordsd %xmm3,%xmm4
   2269e:	66 0f 54 d4          	andpd  %xmm4,%xmm2
   226a2:	66 0f 55 e3          	andnpd %xmm3,%xmm4
   226a6:	66 0f 56 e2          	orpd   %xmm2,%xmm4
   226aa:	f2 0f 10 84 24 30 01 	movsd  0x130(%rsp),%xmm0
   226b1:	00 00 
   226b3:	66 0f 28 d4          	movapd %xmm4,%xmm2
   226b7:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   226bb:	66 0f 28 c2          	movapd %xmm2,%xmm0
   226bf:	f2 0f c2 c2 03       	cmpunordsd %xmm2,%xmm0
   226c4:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   226c8:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   226cc:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   226d0:	66 0f 28 d0          	movapd %xmm0,%xmm2
   226d4:	f2 0f 5e 54 24 20    	divsd  0x20(%rsp),%xmm2
   226da:	66 0f 2e d1          	ucomisd %xmm1,%xmm2
   226de:	0f 87 1a fe ff ff    	ja     224fe <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   226e4:	66 0f 10 8c 24 48 01 	movupd 0x148(%rsp),%xmm1
   226eb:	00 00 
   226ed:	66 0f 28 a4 24 a0 01 	movapd 0x1a0(%rsp),%xmm4
   226f4:	00 00 
   226f6:	66 0f 28 dc          	movapd %xmm4,%xmm3
   226fa:	66 0f 5d d9          	minpd  %xmm1,%xmm3
   226fe:	66 0f 28 cb          	movapd %xmm3,%xmm1
   22702:	66 0f c2 cb 03       	cmpunordpd %xmm3,%xmm1
   22707:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   2270b:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   2270f:	66 0f 56 cc          	orpd   %xmm4,%xmm1
   22713:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   22717:	66 0f c2 ca 01       	cmpltpd %xmm2,%xmm1
   2271c:	66 0f 50 c1          	movmskpd %xmm1,%eax
   22720:	a8 01                	test   $0x1,%al
   22722:	0f 85 d6 fd ff ff    	jne    224fe <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   22728:	d0 e8                	shr    $1,%al
   2272a:	0f 85 ce fd ff ff    	jne    224fe <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   22730:	66 48 0f 7e c0       	movq   %xmm0,%rax
   22735:	49 21 c7             	and    %rax,%r15
   22738:	49 8d 4f ff          	lea    -0x1(%r15),%rcx
   2273c:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%rdx
   22743:	ff 0f 00 
   22746:	48 39 d1             	cmp    %rdx,%rcx
   22749:	0f 92 c1             	setb   %cl
   2274c:	48 85 c0             	test   %rax,%rax
   2274f:	0f 98 c0             	sets   %al
   22752:	20 c1                	and    %al,%cl
   22754:	48 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdx
   2275b:	00 f0 7f 
   2275e:	49 39 d7             	cmp    %rdx,%r15
   22761:	0f 94 c2             	sete   %dl
   22764:	08 ca                	or     %cl,%dl
   22766:	48 b9 00 00 00 00 00 	movabs $0xfff0000000000000,%rcx
   2276d:	00 f0 ff 
   22770:	4c 01 f9             	add    %r15,%rcx
   22773:	48 c1 e9 35          	shr    $0x35,%rcx
   22777:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
   2277d:	0f 92 c1             	setb   %cl
   22780:	20 c1                	and    %al,%cl
   22782:	08 d1                	or     %dl,%cl
   22784:	0f 85 74 fd ff ff    	jne    224fe <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   2278a:	0f 57 c9             	xorps  %xmm1,%xmm1
   2278d:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   22791:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   22796:	0f 56 05 23 30 fe ff 	orps   -0x1cfdd(%rip),%xmm0        # 57c0 <std::thread::current::id::ID+0x4b48>
   2279d:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   227a2:	41 bc 40 00 00 00    	mov    $0x40,%r12d
   227a8:	0f b6 db             	movzbl %bl,%ebx
   227ab:	4c 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%r15
   227b2:	00 
   227b3:	eb 1b                	jmp    227d0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd00>
   227b5:	41 bd 01 00 00 80    	mov    $0x80000001,%r13d
   227bb:	66 41 0f 6e cd       	movd   %r13d,%xmm1
   227c0:	0f 57 c0             	xorps  %xmm0,%xmm0
   227c3:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   227c7:	41 ff cc             	dec    %r12d
   227ca:	0f 84 2e fd ff ff    	je     224fe <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   227d0:	66 41 0f 7e cd       	movd   %xmm1,%r13d
   227d5:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   227db:	f3 0f 11 84 24 a0 00 	movss  %xmm0,0xa0(%rsp)
   227e2:	00 00 
   227e4:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
   227ea:	f3 0f 11 8c 24 a4 00 	movss  %xmm1,0xa4(%rsp)
   227f1:	00 00 
   227f3:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   227f8:	f3 0f 11 84 24 a8 00 	movss  %xmm0,0xa8(%rsp)
   227ff:	00 00 
   22801:	c7 84 24 ac 00 00 00 	movl   $0xff800000,0xac(%rsp)
   22808:	00 00 80 ff 
   2280c:	4c 89 ff             	mov    %r15,%rdi
   2280f:	89 de                	mov    %ebx,%esi
   22811:	e8 4a 00 00 00       	call   22860 <gpui_canvas::color::gamut::in_gamut>
   22816:	84 c0                	test   %al,%al
   22818:	75 2e                	jne    22848 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd78>
   2281a:	41 81 fd 00 00 80 ff 	cmp    $0xff800000,%r13d
   22821:	66 0f 6e 4c 24 10    	movd   0x10(%rsp),%xmm1
   22827:	74 97                	je     227c0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcf0>
   22829:	44 89 e8             	mov    %r13d,%eax
   2282c:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   22831:	74 82                	je     227b5 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xce5>
   22833:	41 39 c5             	cmp    %eax,%r13d
   22836:	75 08                	jne    22840 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd70>
   22838:	41 ff cd             	dec    %r13d
   2283b:	e9 7b ff ff ff       	jmp    227bb <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xceb>
   22840:	41 ff c5             	inc    %r13d
   22843:	e9 73 ff ff ff       	jmp    227bb <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xceb>
   22848:	49 c1 e5 20          	shl    $0x20,%r13
   2284c:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   22852:	4d 09 ee             	or     %r13,%r14
   22855:	e9 a4 fc ff ff       	jmp    224fe <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   2285a:	cc                   	int3
   2285b:	cc                   	int3
   2285c:	cc                   	int3
   2285d:	cc                   	int3
   2285e:	cc                   	int3
   2285f:	cc                   	int3

0000000000022860 <gpui_canvas::color::gamut::in_gamut>:
   22860:	55                   	push   %rbp
   22861:	53                   	push   %rbx
   22862:	48 83 ec 68          	sub    $0x68,%rsp
   22866:	89 f3                	mov    %esi,%ebx
   22868:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   2286c:	8b 4f 08             	mov    0x8(%rdi),%ecx
   2286f:	8b 57 0c             	mov    0xc(%rdi),%edx
   22872:	89 c8                	mov    %ecx,%eax
   22874:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   2287a:	0f 82 ea 00 00 00    	jb     2296a <gpui_canvas::color::gamut::in_gamut+0x10a>
   22880:	89 c8                	mov    %ecx,%eax
   22882:	85 c9                	test   %ecx,%ecx
   22884:	0f 88 db 00 00 00    	js     22965 <gpui_canvas::color::gamut::in_gamut+0x105>
   2288a:	c1 e8 08             	shr    $0x8,%eax
   2288d:	89 ce                	mov    %ecx,%esi
   2288f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   22896:	48 c1 ee 2e          	shr    $0x2e,%rsi
   2289a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   228a1:	48 c1 ef 20          	shr    $0x20,%rdi
   228a5:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   228aa:	45 89 ca             	mov    %r9d,%r10d
   228ad:	41 c1 e2 08          	shl    $0x8,%r10d
   228b1:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   228b6:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   228bb:	45 89 c3             	mov    %r8d,%r11d
   228be:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   228c3:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   228c9:	c1 ed 16             	shr    $0x16,%ebp
   228cc:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   228d2:	29 ee                	sub    %ebp,%esi
   228d4:	44 89 dd             	mov    %r11d,%ebp
   228d7:	c1 e5 08             	shl    $0x8,%ebp
   228da:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   228e1:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   228e8:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   228ee:	44 09 dd             	or     %r11d,%ebp
   228f1:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   228f8:	45 09 d1             	or     %r10d,%r9d
   228fb:	c1 e6 17             	shl    $0x17,%esi
   228fe:	09 ee                	or     %ebp,%esi
   22900:	c1 e7 0f             	shl    $0xf,%edi
   22903:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   22909:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   2290e:	44 09 cf             	or     %r9d,%edi
   22911:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   22918:	49 c1 e9 20          	shr    $0x20,%r9
   2291c:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   22923:	44 29 c8             	sub    %r9d,%eax
   22926:	45 89 c1             	mov    %r8d,%r9d
   22929:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   22930:	41 c1 e0 08          	shl    $0x8,%r8d
   22934:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   2293b:	45 09 c8             	or     %r9d,%r8d
   2293e:	c1 e0 17             	shl    $0x17,%eax
   22941:	44 09 c0             	or     %r8d,%eax
   22944:	66 0f 6e c6          	movd   %esi,%xmm0
   22948:	66 0f 6e cf          	movd   %edi,%xmm1
   2294c:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   22950:	c1 ea 1e             	shr    $0x1e,%edx
   22953:	31 ed                	xor    %ebp,%ebp
   22955:	48 8d 35 90 4c fe ff 	lea    -0x1b370(%rip),%rsi        # 75ec <std::thread::current::id::ID+0x6974>
   2295c:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   22960:	48 01 f2             	add    %rsi,%rdx
   22963:	ff e2                	jmp    *%rdx
   22965:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   2296a:	c1 ea 1e             	shr    $0x1e,%edx
   2296d:	31 ed                	xor    %ebp,%ebp
   2296f:	48 8d 35 76 4c fe ff 	lea    -0x1b38a(%rip),%rsi        # 75ec <std::thread::current::id::ID+0x6974>
   22976:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   2297a:	48 01 f2             	add    %rsi,%rdx
   2297d:	ff e2                	jmp    *%rdx
   2297f:	40 b5 01             	mov    $0x1,%bpl
   22982:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   22986:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   2298b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   2298f:	66 0f 6e d0          	movd   %eax,%xmm2
   22993:	0f 28 05 86 28 fe ff 	movaps -0x1d77a(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   2299a:	0f 54 c5             	andps  %xmm5,%xmm0
   2299d:	f2 0f 10 1d 8b 48 fe 	movsd  -0x1b775(%rip),%xmm3        # 7230 <std::thread::current::id::ID+0x65b8>
   229a4:	ff 
   229a5:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   229a9:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   229af:	73 53                	jae    22a04 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   229b1:	0f 2e c9             	ucomiss %xmm1,%xmm1
   229b4:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   229b9:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   229be:	7a 4e                	jp     22a0e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   229c0:	0f 54 2d c9 2d fe ff 	andps  -0x1d237(%rip),%xmm5        # 5790 <std::thread::current::id::ID+0x4b18>
   229c7:	0f 56 2d d2 2c fe ff 	orps   -0x1d32e(%rip),%xmm5        # 56a0 <std::thread::current::id::ID+0x4a28>
   229ce:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   229d2:	eb 46                	jmp    22a1a <gpui_canvas::color::gamut::in_gamut+0x1ba>
   229d4:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   229d7:	66 0f 6e c0          	movd   %eax,%xmm0
   229db:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   229df:	e9 ad 01 00 00       	jmp    22b91 <gpui_canvas::color::gamut::in_gamut+0x331>
   229e4:	85 c9                	test   %ecx,%ecx
   229e6:	0f 88 86 02 00 00    	js     22c72 <gpui_canvas::color::gamut::in_gamut+0x412>
   229ec:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   229ef:	66 0f 6e c0          	movd   %eax,%xmm0
   229f3:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   229f7:	84 db                	test   %bl,%bl
   229f9:	0f 84 5e 02 00 00    	je     22c5d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   229ff:	e9 a7 02 00 00       	jmp    22cab <gpui_canvas::color::gamut::in_gamut+0x44b>
   22a04:	f2 0f 5e 2d 84 47 fe 	divsd  -0x1b87c(%rip),%xmm5        # 7190 <std::thread::current::id::ID+0x6518>
   22a0b:	ff 
   22a0c:	eb 4b                	jmp    22a59 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   22a0e:	f2 0f 10 0d da 48 fe 	movsd  -0x1b726(%rip),%xmm1        # 72f0 <std::thread::current::id::ID+0x6678>
   22a15:	ff 
   22a16:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   22a1a:	f2 0f 58 05 96 49 fe 	addsd  -0x1b66a(%rip),%xmm0        # 73b8 <std::thread::current::id::ID+0x6740>
   22a21:	ff 
   22a22:	f2 0f 5e 05 e6 48 fe 	divsd  -0x1b71a(%rip),%xmm0        # 7310 <std::thread::current::id::ID+0x6698>
   22a29:	ff 
   22a2a:	f2 0f 10 0d 76 48 fe 	movsd  -0x1b78a(%rip),%xmm1        # 72a8 <std::thread::current::id::ID+0x6630>
   22a31:	ff 
   22a32:	ff 15 d0 2d 04 00    	call   *0x42dd0(%rip)        # 65808 <pow@GLIBC_2.29>
   22a38:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22a3c:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   22a41:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   22a47:	f2 0f 10 1d e1 47 fe 	movsd  -0x1b81f(%rip),%xmm3        # 7230 <std::thread::current::id::ID+0x65b8>
   22a4e:	ff 
   22a4f:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   22a54:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   22a59:	0f 57 c9             	xorps  %xmm1,%xmm1
   22a5c:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22a60:	0f 28 05 b9 27 fe ff 	movaps -0x1d847(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22a67:	0f 54 c4             	andps  %xmm4,%xmm0
   22a6a:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22a6e:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   22a73:	73 1f                	jae    22a94 <gpui_canvas::color::gamut::in_gamut+0x234>
   22a75:	0f 2e f6             	ucomiss %xmm6,%xmm6
   22a78:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   22a7d:	7a 4b                	jp     22aca <gpui_canvas::color::gamut::in_gamut+0x26a>
   22a7f:	0f 54 25 0a 2d fe ff 	andps  -0x1d2f6(%rip),%xmm4        # 5790 <std::thread::current::id::ID+0x4b18>
   22a86:	0f 56 25 13 2c fe ff 	orps   -0x1d3ed(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   22a8d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22a92:	eb 43                	jmp    22ad7 <gpui_canvas::color::gamut::in_gamut+0x277>
   22a94:	f2 0f 5e 25 f4 46 fe 	divsd  -0x1b90c(%rip),%xmm4        # 7190 <std::thread::current::id::ID+0x6518>
   22a9b:	ff 
   22a9c:	0f 28 05 7d 27 fe ff 	movaps -0x1d883(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22aa3:	0f 54 c1             	andps  %xmm1,%xmm0
   22aa6:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22aaa:	72 7e                	jb     22b2a <gpui_canvas::color::gamut::in_gamut+0x2ca>
   22aac:	f2 0f 5e 0d dc 46 fe 	divsd  -0x1b924(%rip),%xmm1        # 7190 <std::thread::current::id::ID+0x6518>
   22ab3:	ff 
   22ab4:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22ab8:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22abc:	40 84 ed             	test   %bpl,%bpl
   22abf:	0f 85 cc 00 00 00    	jne    22b91 <gpui_canvas::color::gamut::in_gamut+0x331>
   22ac5:	e9 8f 01 00 00       	jmp    22c59 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22aca:	f2 0f 10 0d 1e 48 fe 	movsd  -0x1b7e2(%rip),%xmm1        # 72f0 <std::thread::current::id::ID+0x6678>
   22ad1:	ff 
   22ad2:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   22ad7:	f2 0f 58 05 d9 48 fe 	addsd  -0x1b727(%rip),%xmm0        # 73b8 <std::thread::current::id::ID+0x6740>
   22ade:	ff 
   22adf:	f2 0f 5e 05 29 48 fe 	divsd  -0x1b7d7(%rip),%xmm0        # 7310 <std::thread::current::id::ID+0x6698>
   22ae6:	ff 
   22ae7:	f2 0f 10 0d b9 47 fe 	movsd  -0x1b847(%rip),%xmm1        # 72a8 <std::thread::current::id::ID+0x6630>
   22aee:	ff 
   22aef:	ff 15 13 2d 04 00    	call   *0x42d13(%rip)        # 65808 <pow@GLIBC_2.29>
   22af5:	66 0f 28 e0          	movapd %xmm0,%xmm4
   22af9:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   22aff:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   22b04:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   22b0a:	f2 0f 10 1d 1e 47 fe 	movsd  -0x1b8e2(%rip),%xmm3        # 7230 <std::thread::current::id::ID+0x65b8>
   22b11:	ff 
   22b12:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   22b18:	66 0f 28 05 00 27 fe 	movapd -0x1d900(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22b1f:	ff 
   22b20:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   22b24:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22b28:	73 82                	jae    22aac <gpui_canvas::color::gamut::in_gamut+0x24c>
   22b2a:	0f 2e d2             	ucomiss %xmm2,%xmm2
   22b2d:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   22b33:	7a 12                	jp     22b47 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   22b35:	66 0f 54 0d 53 2c fe 	andpd  -0x1d3ad(%rip),%xmm1        # 5790 <std::thread::current::id::ID+0x4b18>
   22b3c:	ff 
   22b3d:	66 0f 56 0d 5b 2b fe 	orpd   -0x1d4a5(%rip),%xmm1        # 56a0 <std::thread::current::id::ID+0x4a28>
   22b44:	ff 
   22b45:	eb 08                	jmp    22b4f <gpui_canvas::color::gamut::in_gamut+0x2ef>
   22b47:	f2 0f 10 0d a1 47 fe 	movsd  -0x1b85f(%rip),%xmm1        # 72f0 <std::thread::current::id::ID+0x6678>
   22b4e:	ff 
   22b4f:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   22b55:	f2 0f 58 05 5b 48 fe 	addsd  -0x1b7a5(%rip),%xmm0        # 73b8 <std::thread::current::id::ID+0x6740>
   22b5c:	ff 
   22b5d:	f2 0f 5e 05 ab 47 fe 	divsd  -0x1b855(%rip),%xmm0        # 7310 <std::thread::current::id::ID+0x6698>
   22b64:	ff 
   22b65:	f2 0f 10 0d 3b 47 fe 	movsd  -0x1b8c5(%rip),%xmm1        # 72a8 <std::thread::current::id::ID+0x6630>
   22b6c:	ff 
   22b6d:	ff 15 95 2c 04 00    	call   *0x42c95(%rip)        # 65808 <pow@GLIBC_2.29>
   22b73:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   22b79:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   22b7e:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   22b84:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22b88:	40 84 ed             	test   %bpl,%bpl
   22b8b:	0f 84 c8 00 00 00    	je     22c59 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22b91:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22b95:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22b9a:	66 0f 59 15 1e 2b fe 	mulpd  -0x1d4e2(%rip),%xmm2        # 56c0 <std::thread::current::id::ID+0x4a48>
   22ba1:	ff 
   22ba2:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   22ba6:	66 0f 16 1d e2 47 fe 	movhpd -0x1b81e(%rip),%xmm3        # 7390 <std::thread::current::id::ID+0x6718>
   22bad:	ff 
   22bae:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   22bb2:	0f 28 c8             	movaps %xmm0,%xmm1
   22bb5:	0f 16 c8             	movlhps %xmm0,%xmm1
   22bb8:	66 0f 59 0d 80 26 fe 	mulpd  -0x1d980(%rip),%xmm1        # 5240 <std::thread::current::id::ID+0x45c8>
   22bbf:	ff 
   22bc0:	66 0f 58 da          	addpd  %xmm2,%xmm3
   22bc4:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22bc8:	f2 0f 10 15 18 46 fe 	movsd  -0x1b9e8(%rip),%xmm2        # 71e8 <std::thread::current::id::ID+0x6570>
   22bcf:	ff 
   22bd0:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   22bd4:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22bd8:	66 0f 59 2d 80 26 fe 	mulpd  -0x1d980(%rip),%xmm5        # 5260 <std::thread::current::id::ID+0x45e8>
   22bdf:	ff 
   22be0:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22be4:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22be8:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22bec:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22bf0:	f2 0f 10 15 b0 45 fe 	movsd  -0x1ba50(%rip),%xmm2        # 71a8 <std::thread::current::id::ID+0x6530>
   22bf7:	ff 
   22bf8:	66 0f 28 d9          	movapd %xmm1,%xmm3
   22bfc:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   22c00:	66 0f 59 1d 68 29 fe 	mulpd  -0x1d698(%rip),%xmm3        # 5570 <std::thread::current::id::ID+0x48f8>
   22c07:	ff 
   22c08:	66 0f 28 e1          	movapd %xmm1,%xmm4
   22c0c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   22c11:	66 0f 59 25 87 28 fe 	mulpd  -0x1d779(%rip),%xmm4        # 54a0 <std::thread::current::id::ID+0x4828>
   22c18:	ff 
   22c19:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22c1d:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   22c21:	66 0f 28 e9          	movapd %xmm1,%xmm5
   22c25:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   22c29:	66 0f 59 2d 6f 2b fe 	mulpd  -0x1d491(%rip),%xmm5        # 57a0 <std::thread::current::id::ID+0x4b28>
   22c30:	ff 
   22c31:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22c35:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   22c39:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   22c3d:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22c41:	66 0f 59 0d 07 29 fe 	mulpd  -0x1d6f9(%rip),%xmm1        # 5550 <std::thread::current::id::ID+0x48d8>
   22c48:	ff 
   22c49:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22c4d:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   22c51:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22c55:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22c59:	84 db                	test   %bl,%bl
   22c5b:	75 4e                	jne    22cab <gpui_canvas::color::gamut::in_gamut+0x44b>
   22c5d:	31 c0                	xor    %eax,%eax
   22c5f:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22c63:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22c67:	0f 83 08 01 00 00    	jae    22d75 <gpui_canvas::color::gamut::in_gamut+0x515>
   22c6d:	e9 41 01 00 00       	jmp    22db3 <gpui_canvas::color::gamut::in_gamut+0x553>
   22c72:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   22c76:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   22c7a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   22c7e:	0f 2e c8             	ucomiss %xmm0,%xmm1
   22c81:	0f 85 35 01 00 00    	jne    22dbc <gpui_canvas::color::gamut::in_gamut+0x55c>
   22c87:	0f 8a 2f 01 00 00    	jp     22dbc <gpui_canvas::color::gamut::in_gamut+0x55c>
   22c8d:	0f 57 c9             	xorps  %xmm1,%xmm1
   22c90:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22c94:	0f 28 c1             	movaps %xmm1,%xmm0
   22c97:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22c9b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22c9f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22ca3:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22ca7:	84 db                	test   %bl,%bl
   22ca9:	74 b2                	je     22c5d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   22cab:	66 0f 28 0d 1d 26 fe 	movapd -0x1d9e3(%rip),%xmm1        # 52d0 <std::thread::current::id::ID+0x4658>
   22cb2:	ff 
   22cb3:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   22cb7:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22cbb:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22cc0:	66 0f 59 15 58 2a fe 	mulpd  -0x1d5a8(%rip),%xmm2        # 5720 <std::thread::current::id::ID+0x4aa8>
   22cc7:	ff 
   22cc8:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   22ccc:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22cd0:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   22cd4:	66 0f 59 0d b4 26 fe 	mulpd  -0x1d94c(%rip),%xmm1        # 5390 <std::thread::current::id::ID+0x4718>
   22cdb:	ff 
   22cdc:	f2 0f 10 1d 5c 45 fe 	movsd  -0x1baa4(%rip),%xmm3        # 7240 <std::thread::current::id::ID+0x65c8>
   22ce3:	ff 
   22ce4:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   22ce8:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22cec:	66 0f 59 2d bc 26 fe 	mulpd  -0x1d944(%rip),%xmm5        # 53b0 <std::thread::current::id::ID+0x4738>
   22cf3:	ff 
   22cf4:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   22cf8:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22cfc:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22d00:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   22d04:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22d08:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   22d0d:	66 0f 59 15 3b 25 fe 	mulpd  -0x1dac5(%rip),%xmm2        # 5250 <std::thread::current::id::ID+0x45d8>
   22d14:	ff 
   22d15:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22d19:	66 0f 28 1d 8f 25 fe 	movapd -0x1da71(%rip),%xmm3        # 52b0 <std::thread::current::id::ID+0x4638>
   22d20:	ff 
   22d21:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   22d25:	66 0f 5c da          	subpd  %xmm2,%xmm3
   22d29:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22d2d:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22d31:	66 0f 59 2d 37 26 fe 	mulpd  -0x1d9c9(%rip),%xmm5        # 5370 <std::thread::current::id::ID+0x46f8>
   22d38:	ff 
   22d39:	66 0f 28 d3          	movapd %xmm3,%xmm2
   22d3d:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   22d41:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   22d45:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   22d49:	66 0f 59 0d af 28 fe 	mulpd  -0x1d751(%rip),%xmm1        # 5600 <std::thread::current::id::ID+0x4988>
   22d50:	ff 
   22d51:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22d55:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   22d59:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   22d5d:	f2 0f 59 05 83 45 fe 	mulsd  -0x1ba7d(%rip),%xmm0        # 72e8 <std::thread::current::id::ID+0x6670>
   22d64:	ff 
   22d65:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22d69:	31 c0                	xor    %eax,%eax
   22d6b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22d6f:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22d73:	72 3e                	jb     22db3 <gpui_canvas::color::gamut::in_gamut+0x553>
   22d75:	f2 0f 10 0d db 44 fe 	movsd  -0x1bb25(%rip),%xmm1        # 7258 <std::thread::current::id::ID+0x65e0>
   22d7c:	ff 
   22d7d:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22d81:	72 30                	jb     22db3 <gpui_canvas::color::gamut::in_gamut+0x553>
   22d83:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   22d87:	31 c0                	xor    %eax,%eax
   22d89:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   22d8d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   22d91:	72 20                	jb     22db3 <gpui_canvas::color::gamut::in_gamut+0x553>
   22d93:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22d97:	72 1a                	jb     22db3 <gpui_canvas::color::gamut::in_gamut+0x553>
   22d99:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22d9d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   22da2:	f2 0f c2 05 ad 44 fe 	cmplesd -0x1bb53(%rip),%xmm0        # 7258 <std::thread::current::id::ID+0x65e0>
   22da9:	ff 02 
   22dab:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   22daf:	66 0f 7e c0          	movd   %xmm0,%eax
   22db3:	24 01                	and    $0x1,%al
   22db5:	48 83 c4 68          	add    $0x68,%rsp
   22db9:	5b                   	pop    %rbx
   22dba:	5d                   	pop    %rbp
   22dbb:	c3                   	ret
   22dbc:	66 0f 6e c0          	movd   %eax,%xmm0
   22dc0:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22dc4:	f2 0f 59 05 bc 45 fe 	mulsd  -0x1ba44(%rip),%xmm0        # 7388 <std::thread::current::id::ID+0x6710>
   22dcb:	ff 
   22dcc:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   22dd1:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   22dd6:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   22dda:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   22de0:	ff 15 4a 2a 04 00    	call   *0x42a4a(%rip)        # 65830 <sincos@GLIBC_2.2.5>
   22de6:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   22deb:	0f 57 c9             	xorps  %xmm1,%xmm1
   22dee:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   22df2:	0f 28 04 24          	movaps (%rsp),%xmm0
   22df6:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22dfa:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   22e00:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22e04:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   22e0a:	f2 0f 10 1d 4e 45 fe 	movsd  -0x1bab2(%rip),%xmm3        # 7360 <std::thread::current::id::ID+0x66e8>
   22e11:	ff 
   22e12:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22e16:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   22e1a:	f2 0f 10 2d d6 44 fe 	movsd  -0x1bb2a(%rip),%xmm5        # 72f8 <std::thread::current::id::ID+0x6680>
   22e21:	ff 
   22e22:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   22e26:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   22e2a:	f2 0f 10 1d 86 44 fe 	movsd  -0x1bb7a(%rip),%xmm3        # 72b8 <std::thread::current::id::ID+0x6640>
   22e31:	ff 
   22e32:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22e36:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   22e3a:	f2 0f 10 35 7e 45 fe 	movsd  -0x1ba82(%rip),%xmm6        # 73c0 <std::thread::current::id::ID+0x6748>
   22e41:	ff 
   22e42:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   22e46:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   22e4a:	f2 0f 59 15 f6 44 fe 	mulsd  -0x1bb0a(%rip),%xmm2        # 7348 <std::thread::current::id::ID+0x66d0>
   22e51:	ff 
   22e52:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   22e56:	f2 0f 59 05 3a 43 fe 	mulsd  -0x1bcc6(%rip),%xmm0        # 7198 <std::thread::current::id::ID+0x6520>
   22e5d:	ff 
   22e5e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22e62:	66 0f 28 e5          	movapd %xmm5,%xmm4
   22e66:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   22e6a:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   22e6e:	66 0f 28 de          	movapd %xmm6,%xmm3
   22e72:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22e76:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22e7a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22e7e:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22e82:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22e86:	f2 0f 10 05 3a 45 fe 	movsd  -0x1bac6(%rip),%xmm0        # 73c8 <std::thread::current::id::ID+0x6750>
   22e8d:	ff 
   22e8e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   22e92:	f2 0f 10 15 d6 43 fe 	movsd  -0x1bc2a(%rip),%xmm2        # 7270 <std::thread::current::id::ID+0x65f8>
   22e99:	ff 
   22e9a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   22e9e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   22ea2:	f2 0f 10 05 ce 43 fe 	movsd  -0x1bc32(%rip),%xmm0        # 7278 <std::thread::current::id::ID+0x6600>
   22ea9:	ff 
   22eaa:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22eae:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22eb2:	f2 0f 10 15 ee 42 fe 	movsd  -0x1bd12(%rip),%xmm2        # 71a8 <std::thread::current::id::ID+0x6530>
   22eb9:	ff 
   22eba:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   22ebe:	66 0f 59 25 9a 28 fe 	mulpd  -0x1d766(%rip),%xmm4        # 5760 <std::thread::current::id::ID+0x4ae8>
   22ec5:	ff 
   22ec6:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   22eca:	66 0f 59 1d 9e 28 fe 	mulpd  -0x1d762(%rip),%xmm3        # 5770 <std::thread::current::id::ID+0x4af8>
   22ed1:	ff 
   22ed2:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   22ed6:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   22eda:	66 0f 59 0d 5e 26 fe 	mulpd  -0x1d9a2(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   22ee1:	ff 
   22ee2:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22ee6:	e9 0d fd ff ff       	jmp    22bf8 <gpui_canvas::color::gamut::in_gamut+0x398>
