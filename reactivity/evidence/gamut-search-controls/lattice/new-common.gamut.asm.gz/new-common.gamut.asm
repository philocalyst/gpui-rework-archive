000000000001f630 <<gpui_canvas::color::OutputProfile>::max_chroma>:
   1f630:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f634:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f63a:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f63f:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f645:	7f 38                	jg     1f67f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f647:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f64a:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f64d:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f652:	0f 28 d8             	movaps %xmm0,%xmm3
   1f655:	f3 0f c2 1d 4a 62 fe 	cmpnless -0x19db6(%rip),%xmm3        # 58a8 <std::thread::current::id::ID+0x4c30>
   1f65c:	ff 06 
   1f65e:	0f 56 da             	orps   %xmm2,%xmm3
   1f661:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f665:	66 0f 7e ca          	movd   %xmm1,%edx
   1f669:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f66f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f675:	0f 9d c2             	setge  %dl
   1f678:	08 ca                	or     %cl,%dl
   1f67a:	f6 c2 01             	test   $0x1,%dl
   1f67d:	74 01                	je     1f680 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f67f:	c3                   	ret
   1f680:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f683:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f688:	75 02                	jne    1f68c <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f68a:	7b f3                	jnp    1f67f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f68c:	0f 2e 05 15 62 fe ff 	ucomiss -0x19deb(%rip),%xmm0        # 58a8 <std::thread::current::id::ID+0x4c30>
   1f693:	75 02                	jne    1f697 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f695:	7b e8                	jnp    1f67f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f697:	53                   	push   %rbx
   1f698:	48 83 ec 10          	sub    $0x10,%rsp
   1f69c:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f6a2:	89 fb                	mov    %edi,%ebx
   1f6a4:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f6a7:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f6ab:	f2 0f 10 0d ed 7c fe 	movsd  -0x18313(%rip),%xmm1        # 73a0 <std::thread::current::id::ID+0x6728>
   1f6b2:	ff 
   1f6b3:	ff 15 d7 5c 04 00    	call   *0x45cd7(%rip)        # 65390 <_DYNAMIC+0x378>
   1f6b9:	f2 0f 10 1d df 7c fe 	movsd  -0x18321(%rip),%xmm3        # 73a0 <std::thread::current::id::ID+0x6728>
   1f6c0:	ff 
   1f6c1:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f6c5:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f6c9:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f6cd:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f6d2:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f6d6:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f6da:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f6de:	66 0f 2e 15 f2 7b fe 	ucomisd -0x1840e(%rip),%xmm2        # 72d8 <std::thread::current::id::ID+0x6660>
   1f6e5:	ff 
   1f6e6:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f6ea:	73 0f                	jae    1f6fb <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f6ec:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f6ef:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f6f3:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f6f8:	0f 55 c8             	andnps %xmm0,%xmm1
   1f6fb:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f701:	0f b6 fb             	movzbl %bl,%edi
   1f704:	48 83 c4 10          	add    $0x10,%rsp
   1f708:	5b                   	pop    %rbx
   1f709:	e9 f2 11 00 00       	jmp    20900 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f70e:	cc                   	int3
   1f70f:	cc                   	int3

0000000000020240 <<gpui_canvas::color::Color>::fit_chroma>:
   20240:	55                   	push   %rbp
   20241:	41 57                	push   %r15
   20243:	41 56                	push   %r14
   20245:	41 54                	push   %r12
   20247:	53                   	push   %rbx
   20248:	48 83 ec 30          	sub    $0x30,%rsp
   2024c:	48 89 fb             	mov    %rdi,%rbx
   2024f:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   20253:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   20257:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   2025e:	0f 92 c0             	setb   %al
   20261:	45 85 e4             	test   %r12d,%r12d
   20264:	0f 99 c1             	setns  %cl
   20267:	08 c1                	or     %al,%cl
   20269:	74 09                	je     20274 <<gpui_canvas::color::Color>::fit_chroma+0x34>
   2026b:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   20272:	eb 4a                	jmp    202be <<gpui_canvas::color::Color>::fit_chroma+0x7e>
   20274:	49 89 f6             	mov    %rsi,%r14
   20277:	0f 10 06             	movups (%rsi),%xmm0
   2027a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   2027f:	0f b6 ea             	movzbl %dl,%ebp
   20282:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   20287:	89 ee                	mov    %ebp,%esi
   20289:	e8 52 21 00 00       	call   223e0 <gpui_canvas::color::gamut::in_gamut>
   2028e:	84 c0                	test   %al,%al
   20290:	74 0c                	je     2029e <<gpui_canvas::color::Color>::fit_chroma+0x5e>
   20292:	41 0f 10 06          	movups (%r14),%xmm0
   20296:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   2029a:	31 c0                	xor    %eax,%eax
   2029c:	eb 25                	jmp    202c3 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   2029e:	41 8b 16             	mov    (%r14),%edx
   202a1:	89 d6                	mov    %edx,%esi
   202a3:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   202a9:	b8 0d 00 00 00       	mov    $0xd,%eax
   202ae:	31 c9                	xor    %ecx,%ecx
   202b0:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   202b6:	7e 1d                	jle    202d5 <<gpui_canvas::color::Color>::fit_chroma+0x95>
   202b8:	89 43 04             	mov    %eax,0x4(%rbx)
   202bb:	89 4b 08             	mov    %ecx,0x8(%rbx)
   202be:	b8 01 00 00 00       	mov    $0x1,%eax
   202c3:	89 03                	mov    %eax,(%rbx)
   202c5:	48 89 d8             	mov    %rbx,%rax
   202c8:	48 83 c4 30          	add    $0x30,%rsp
   202cc:	5b                   	pop    %rbx
   202cd:	41 5c                	pop    %r12
   202cf:	41 5e                	pop    %r14
   202d1:	41 5f                	pop    %r15
   202d3:	5d                   	pop    %rbp
   202d4:	c3                   	ret
   202d5:	44 89 e6             	mov    %r12d,%esi
   202d8:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   202de:	66 0f 6e c6          	movd   %esi,%xmm0
   202e2:	0f 2e 05 f7 55 fe ff 	ucomiss -0x1aa09(%rip),%xmm0        # 58e0 <std::thread::current::id::ID+0x4c68>
   202e9:	74 cd                	je     202b8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   202eb:	66 0f 6e d2          	movd   %edx,%xmm2
   202ef:	0f 57 c9             	xorps  %xmm1,%xmm1
   202f2:	0f 2e d1             	ucomiss %xmm1,%xmm2
   202f5:	72 c1                	jb     202b8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   202f7:	f3 0f 10 0d a9 55 fe 	movss  -0x1aa57(%rip),%xmm1        # 58a8 <std::thread::current::id::ID+0x4c30>
   202fe:	ff 
   202ff:	0f 2e ca             	ucomiss %xmm2,%xmm1
   20302:	72 b4                	jb     202b8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   20304:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   2030a:	31 c9                	xor    %ecx,%ecx
   2030c:	0f 57 c9             	xorps  %xmm1,%xmm1
   2030f:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20312:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   20318:	75 02                	jne    2031c <<gpui_canvas::color::Color>::fit_chroma+0xdc>
   2031a:	7b 63                	jnp    2037f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   2031c:	0f 2e 15 85 55 fe ff 	ucomiss -0x1aa7b(%rip),%xmm2        # 58a8 <std::thread::current::id::ID+0x4c30>
   20323:	75 02                	jne    20327 <<gpui_canvas::color::Color>::fit_chroma+0xe7>
   20325:	7b 58                	jnp    2037f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   20327:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   2032c:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   20330:	f2 0f 10 0d 68 70 fe 	movsd  -0x18f98(%rip),%xmm1        # 73a0 <std::thread::current::id::ID+0x6728>
   20337:	ff 
   20338:	ff 15 52 50 04 00    	call   *0x45052(%rip)        # 65390 <_DYNAMIC+0x378>
   2033e:	66 0f 2e 05 92 6f fe 	ucomisd -0x1906e(%rip),%xmm0        # 72d8 <std::thread::current::id::ID+0x6660>
   20345:	ff 
   20346:	0f 57 c9             	xorps  %xmm1,%xmm1
   20349:	73 0c                	jae    20357 <<gpui_canvas::color::Color>::fit_chroma+0x117>
   2034b:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   2034f:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   20354:	0f 55 c8             	andnps %xmm0,%xmm1
   20357:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   2035d:	89 ef                	mov    %ebp,%edi
   2035f:	e8 9c 05 00 00       	call   20900 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   20364:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   2036a:	48 89 c1             	mov    %rax,%rcx
   2036d:	48 c1 e9 20          	shr    $0x20,%rcx
   20371:	83 f8 ff             	cmp    $0xffffffff,%eax
   20374:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   20379:	0f 85 39 ff ff ff    	jne    202b8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   2037f:	66 0f 6e c1          	movd   %ecx,%xmm0
   20383:	0f 28 cb             	movaps %xmm3,%xmm1
   20386:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   2038a:	0f 28 e1             	movaps %xmm1,%xmm4
   2038d:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   20392:	0f 28 c4             	movaps %xmm4,%xmm0
   20395:	0f 55 c1             	andnps %xmm1,%xmm0
   20398:	0f 54 e3             	andps  %xmm3,%xmm4
   2039b:	0f 56 e0             	orps   %xmm0,%xmm4
   2039e:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   203a4:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   203a9:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   203af:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   203b4:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   203b9:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   203be:	89 ee                	mov    %ebp,%esi
   203c0:	e8 1b 20 00 00       	call   223e0 <gpui_canvas::color::gamut::in_gamut>
   203c5:	84 c0                	test   %al,%al
   203c7:	74 1c                	je     203e5 <<gpui_canvas::color::Color>::fit_chroma+0x1a5>
   203c9:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   203ce:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   203d3:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   203d7:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   203db:	31 c0                	xor    %eax,%eax
   203dd:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   203e3:	eb 0d                	jmp    203f2 <<gpui_canvas::color::Color>::fit_chroma+0x1b2>
   203e5:	b8 01 00 00 00       	mov    $0x1,%eax
   203ea:	f3 0f 10 05 ae 54 fe 	movss  -0x1ab52(%rip),%xmm0        # 58a0 <std::thread::current::id::ID+0x4c28>
   203f1:	ff 
   203f2:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   203f7:	e9 c7 fe ff ff       	jmp    202c3 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   203fc:	cc                   	int3
   203fd:	cc                   	int3
   203fe:	cc                   	int3
   203ff:	cc                   	int3

0000000000020900 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>:
   20900:	55                   	push   %rbp
   20901:	48 89 e5             	mov    %rsp,%rbp
   20904:	41 57                	push   %r15
   20906:	41 56                	push   %r14
   20908:	41 55                	push   %r13
   2090a:	41 54                	push   %r12
   2090c:	53                   	push   %rbx
   2090d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20911:	48 81 ec a0 02 00 00 	sub    $0x2a0,%rsp
   20918:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   2091e:	89 fb                	mov    %edi,%ebx
   20920:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
   20927:	00 
   20928:	0f 57 c0             	xorps  %xmm0,%xmm0
   2092b:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   2092f:	f2 0f 59 05 49 6a fe 	mulsd  -0x195b7(%rip),%xmm0        # 7380 <std::thread::current::id::ID+0x6708>
   20936:	ff 
   20937:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
   2093e:	00 
   2093f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
   20946:	00 
   20947:	ff 15 73 4a 04 00    	call   *0x44a73(%rip)        # 653c0 <sincos@GLIBC_2.2.5>
   2094d:	f2 0f 10 ac 24 18 01 	movsd  0x118(%rsp),%xmm5
   20954:	00 00 
   20956:	f2 0f 10 84 24 10 01 	movsd  0x110(%rsp),%xmm0
   2095d:	00 00 
   2095f:	f2 0f 10 0d f1 69 fe 	movsd  -0x1960f(%rip),%xmm1        # 7358 <std::thread::current::id::ID+0x66e0>
   20966:	ff 
   20967:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   2096b:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2096f:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   20973:	f2 0f 10 1d 35 69 fe 	movsd  -0x196cb(%rip),%xmm3        # 72b0 <std::thread::current::id::ID+0x6638>
   2097a:	ff 
   2097b:	f2 0f 59 d8          	mulsd  %xmm0,%xmm3
   2097f:	f2 0f 58 da          	addsd  %xmm2,%xmm3
   20983:	f2 0f 10 35 65 69 fe 	movsd  -0x1969b(%rip),%xmm6        # 72f0 <std::thread::current::id::ID+0x6678>
   2098a:	ff 
   2098b:	f2 0f 59 f5          	mulsd  %xmm5,%xmm6
   2098f:	f2 0f 58 f1          	addsd  %xmm1,%xmm6
   20993:	f2 0f 10 3d 1d 6a fe 	movsd  -0x195e3(%rip),%xmm7        # 73b8 <std::thread::current::id::ID+0x6740>
   2099a:	ff 
   2099b:	f2 0f 59 fd          	mulsd  %xmm5,%xmm7
   2099f:	f2 0f 58 fb          	addsd  %xmm3,%xmm7
   209a3:	f2 0f 59 05 95 69 fe 	mulsd  -0x1966b(%rip),%xmm0        # 7340 <std::thread::current::id::ID+0x66c8>
   209aa:	ff 
   209ab:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   209af:	f2 0f 59 2d e1 67 fe 	mulsd  -0x1981f(%rip),%xmm5        # 7198 <std::thread::current::id::ID+0x6520>
   209b6:	ff 
   209b7:	f2 0f 58 e8          	addsd  %xmm0,%xmm5
   209bb:	85 db                	test   %ebx,%ebx
   209bd:	74 35                	je     209f4 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xf4>
   209bf:	66 44 0f 28 2d e8 48 	movapd -0x1b718(%rip),%xmm13        # 52b0 <std::thread::current::id::ID+0x4638>
   209c6:	fe ff 
   209c8:	66 0f 28 05 f0 4d fe 	movapd -0x1b210(%rip),%xmm0        # 57c0 <std::thread::current::id::ID+0x4b48>
   209cf:	ff 
   209d0:	66 44 0f 28 1d 97 4e 	movapd -0x1b169(%rip),%xmm11        # 5870 <std::thread::current::id::ID+0x4bf8>
   209d7:	fe ff 
   209d9:	f3 0f 7e 15 0f 68 fe 	movq   -0x197f1(%rip),%xmm2        # 71f0 <std::thread::current::id::ID+0x6578>
   209e0:	ff 
   209e1:	f3 0f 7e 25 e7 68 fe 	movq   -0x19719(%rip),%xmm4        # 72d0 <std::thread::current::id::ID+0x6658>
   209e8:	ff 
   209e9:	f3 44 0f 7e 05 06 68 	movq   -0x197fa(%rip),%xmm8        # 71f8 <std::thread::current::id::ID+0x6580>
   209f0:	fe ff 
   209f2:	eb 33                	jmp    20a27 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x127>
   209f4:	66 44 0f 28 2d a3 4b 	movapd -0x1b45d(%rip),%xmm13        # 55a0 <std::thread::current::id::ID+0x4928>
   209fb:	fe ff 
   209fd:	66 0f 28 05 8b 4c fe 	movapd -0x1b375(%rip),%xmm0        # 5690 <std::thread::current::id::ID+0x4a18>
   20a04:	ff 
   20a05:	66 44 0f 28 1d 02 4b 	movapd -0x1b4fe(%rip),%xmm11        # 5510 <std::thread::current::id::ID+0x4898>
   20a0c:	fe ff 
   20a0e:	f3 0f 7e 15 0a 69 fe 	movq   -0x196f6(%rip),%xmm2        # 7320 <std::thread::current::id::ID+0x66a8>
   20a15:	ff 
   20a16:	f3 0f 7e 25 f2 68 fe 	movq   -0x1970e(%rip),%xmm4        # 7310 <std::thread::current::id::ID+0x6698>
   20a1d:	ff 
   20a1e:	f3 44 0f 7e 05 61 68 	movq   -0x1979f(%rip),%xmm8        # 7288 <std::thread::current::id::ID+0x6610>
   20a25:	fe ff 
   20a27:	f3 0f 7e da          	movq   %xmm2,%xmm3
   20a2b:	f3 0f 7e e4          	movq   %xmm4,%xmm4
   20a2f:	f3 41 0f 7e d0       	movq   %xmm8,%xmm2
   20a34:	66 0f 14 f7          	unpcklpd %xmm7,%xmm6
   20a38:	66 0f 28 fe          	movapd %xmm6,%xmm7
   20a3c:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   20a40:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20a45:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20a4a:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20a4f:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   20a53:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   20a59:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   20a60:	f2 0f 10 7c 24 40    	movsd  0x40(%rsp),%xmm7
   20a66:	66 0f 14 ff          	unpcklpd %xmm7,%xmm7
   20a6a:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20a6f:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   20a74:	66 0f 59 fb          	mulpd  %xmm3,%xmm7
   20a78:	66 44 0f 10 64 24 48 	movupd 0x48(%rsp),%xmm12
   20a7f:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   20a84:	66 45 0f 14 cc       	unpcklpd %xmm12,%xmm9
   20a89:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20a8e:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20a93:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   20a98:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   20a9d:	66 44 0f 58 cf       	addpd  %xmm7,%xmm9
   20aa2:	66 45 0f 15 e4       	unpckhpd %xmm12,%xmm12
   20aa7:	66 45 0f 28 fb       	movapd %xmm11,%xmm15
   20aac:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
   20ab1:	66 45 0f 58 fa       	addpd  %xmm10,%xmm15
   20ab6:	66 44 0f 29 bc 24 00 	movapd %xmm15,0x100(%rsp)
   20abd:	01 00 00 
   20ac0:	66 44 0f 59 e2       	mulpd  %xmm2,%xmm12
   20ac5:	66 45 0f 58 e1       	addpd  %xmm9,%xmm12
   20aca:	66 44 0f 29 64 24 20 	movapd %xmm12,0x20(%rsp)
   20ad1:	66 0f 28 fe          	movapd %xmm6,%xmm7
   20ad5:	66 0f 59 3d e3 48 fe 	mulpd  -0x1b71d(%rip),%xmm7        # 53c0 <std::thread::current::id::ID+0x4748>
   20adc:	ff 
   20add:	f2 44 0f 10 05 da 67 	movsd  -0x19826(%rip),%xmm8        # 72c0 <std::thread::current::id::ID+0x6648>
   20ae4:	fe ff 
   20ae6:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20aeb:	f2 41 0f 59 e8       	mulsd  %xmm8,%xmm5
   20af0:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   20af4:	66 0f 29 74 24 40    	movapd %xmm6,0x40(%rsp)
   20afa:	f2 0f 11 6c 24 50    	movsd  %xmm5,0x50(%rsp)
   20b00:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   20b06:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   20b0a:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   20b0f:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   20b13:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   20b17:	66 44 0f 10 74 24 48 	movupd 0x48(%rsp),%xmm14
   20b1e:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   20b23:	66 45 0f 14 ce       	unpcklpd %xmm14,%xmm9
   20b28:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20b2d:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20b32:	66 44 0f 58 d6       	addpd  %xmm6,%xmm10
   20b37:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   20b3c:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   20b41:	66 45 0f 15 f6       	unpckhpd %xmm14,%xmm14
   20b46:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20b4b:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   20b50:	66 41 0f 58 ca       	addpd  %xmm10,%xmm1
   20b55:	66 0f 29 8c 24 e0 00 	movapd %xmm1,0xe0(%rsp)
   20b5c:	00 00 
   20b5e:	66 44 0f 59 f2       	mulpd  %xmm2,%xmm14
   20b63:	66 45 0f 58 f1       	addpd  %xmm9,%xmm14
   20b68:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   20b6d:	66 44 0f 29 b4 24 f0 	movapd %xmm14,0xf0(%rsp)
   20b74:	00 00 00 
   20b77:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   20b7d:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   20b84:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   20b8a:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   20b8e:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   20b93:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   20b97:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   20b9b:	66 44 0f 10 54 24 48 	movupd 0x48(%rsp),%xmm10
   20ba2:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   20ba7:	66 41 0f 14 fa       	unpcklpd %xmm10,%xmm7
   20bac:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   20bb1:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   20bb6:	66 44 0f 58 c6       	addpd  %xmm6,%xmm8
   20bbb:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   20bbf:	66 0f 58 fd          	addpd  %xmm5,%xmm7
   20bc3:	66 45 0f 15 d2       	unpckhpd %xmm10,%xmm10
   20bc8:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   20bcd:	66 41 0f 59 ea       	mulpd  %xmm10,%xmm5
   20bd2:	66 41 0f 58 e8       	addpd  %xmm8,%xmm5
   20bd7:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20bdc:	66 0f 29 ac 24 80 01 	movapd %xmm5,0x180(%rsp)
   20be3:	00 00 
   20be5:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   20bea:	66 44 0f 58 d7       	addpd  %xmm7,%xmm10
   20bef:	66 44 0f 29 94 24 90 	movapd %xmm10,0x190(%rsp)
   20bf6:	01 00 00 
   20bf9:	0f 28 2d b0 4a fe ff 	movaps -0x1b550(%rip),%xmm5        # 56b0 <std::thread::current::id::ID+0x4a38>
   20c00:	0f 29 6c 24 40       	movaps %xmm5,0x40(%rsp)
   20c05:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   20c0c:	00 f0 3f 
   20c0f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   20c14:	66 0f 10 6c 24 48    	movupd 0x48(%rsp),%xmm5
   20c1a:	66 0f 28 f5          	movapd %xmm5,%xmm6
   20c1e:	66 0f 14 f5          	unpcklpd %xmm5,%xmm6
   20c22:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20c26:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   20c2a:	66 41 0f 58 c5       	addpd  %xmm13,%xmm0
   20c2f:	66 0f 58 f3          	addpd  %xmm3,%xmm6
   20c33:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   20c37:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   20c3c:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
   20c41:	66 44 0f 29 9c 24 a0 	movapd %xmm11,0x1a0(%rsp)
   20c48:	01 00 00 
   20c4b:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   20c4f:	66 0f 58 ee          	addpd  %xmm6,%xmm5
   20c53:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   20c58:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20c5c:	66 0f 16 05 ec 65 fe 	movhpd -0x19a14(%rip),%xmm0        # 7250 <std::thread::current::id::ID+0x65d8>
   20c63:	ff 
   20c64:	66 0f 58 c5          	addpd  %xmm5,%xmm0
   20c68:	66 0f 29 84 24 70 01 	movapd %xmm0,0x170(%rsp)
   20c6f:	00 00 
   20c71:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   20c76:	66 44 0f 28 3d 41 47 	movapd -0x1b8bf(%rip),%xmm15        # 53c0 <std::thread::current::id::ID+0x4748>
   20c7d:	fe ff 
   20c7f:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   20c84:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
   20c89:	66 44 0f 29 7c 24 30 	movapd %xmm15,0x30(%rsp)
   20c90:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20c94:	66 0f 58 e1          	addpd  %xmm1,%xmm4
   20c98:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20c9c:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   20ca1:	66 41 0f 59 d8       	mulpd  %xmm8,%xmm3
   20ca6:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   20cab:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
   20cb0:	66 0f 28 05 78 47 fe 	movapd -0x1b888(%rip),%xmm0        # 5430 <std::thread::current::id::ID+0x47b8>
   20cb7:	ff 
   20cb8:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   20cbc:	66 0f 28 f3          	movapd %xmm3,%xmm6
   20cc0:	66 0f 29 9c 24 f0 01 	movapd %xmm3,0x1f0(%rsp)
   20cc7:	00 00 
   20cc9:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   20ccd:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20cd1:	66 0f 29 8c 24 d0 01 	movapd %xmm1,0x1d0(%rsp)
   20cd8:	00 00 
   20cda:	66 0f 28 c4          	movapd %xmm4,%xmm0
   20cde:	66 41 0f c2 c6 01    	cmpltpd %xmm14,%xmm0
   20ce4:	66 0f 28 0d 94 4b fe 	movapd -0x1b46c(%rip),%xmm1        # 5880 <std::thread::current::id::ID+0x4c08>
   20ceb:	ff 
   20cec:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20cf0:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   20cf4:	66 44 0f 28 15 b3 49 	movapd -0x1b64d(%rip),%xmm10        # 56b0 <std::thread::current::id::ID+0x4a38>
   20cfb:	fe ff 
   20cfd:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   20d02:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   20d06:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
   20d0b:	66 45 0f 58 e9       	addpd  %xmm9,%xmm13
   20d10:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   20d15:	66 41 0f c2 de 01    	cmpltpd %xmm14,%xmm3
   20d1b:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   20d1f:	66 41 0f 55 da       	andnpd %xmm10,%xmm3
   20d24:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   20d28:	66 0f 28 fc          	movapd %xmm4,%xmm7
   20d2c:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   20d30:	66 0f 29 bc 24 c0 00 	movapd %xmm7,0xc0(%rsp)
   20d37:	00 00 
   20d39:	66 0f 5c fe          	subpd  %xmm6,%xmm7
   20d3d:	66 0f 28 cf          	movapd %xmm7,%xmm1
   20d41:	66 41 0f 5f ce       	maxpd  %xmm14,%xmm1
   20d46:	66 44 0f 51 e1       	sqrtpd %xmm1,%xmm12
   20d4b:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20d50:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20d55:	66 45 0f 59 c5       	mulpd  %xmm13,%xmm8
   20d5a:	66 44 0f 29 84 24 e0 	movapd %xmm8,0x1e0(%rsp)
   20d61:	01 00 00 
   20d64:	66 44 0f 5c c5       	subpd  %xmm5,%xmm8
   20d69:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   20d6e:	66 41 0f 5f c6       	maxpd  %xmm14,%xmm0
   20d73:	66 0f 51 d0          	sqrtpd %xmm0,%xmm2
   20d77:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   20d7b:	66 44 0f 58 e4       	addpd  %xmm4,%xmm12
   20d80:	66 41 0f 58 d5       	addpd  %xmm13,%xmm2
   20d85:	66 0f 28 05 03 4b fe 	movapd -0x1b4fd(%rip),%xmm0        # 5890 <std::thread::current::id::ID+0x4c18>
   20d8c:	ff 
   20d8d:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20d92:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   20d96:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20d9b:	66 44 0f 29 5c 24 10 	movapd %xmm11,0x10(%rsp)
   20da2:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   20da7:	66 41 0f c2 c6 00    	cmpeqpd %xmm14,%xmm0
   20dad:	66 44 0f 28 cc       	movapd %xmm4,%xmm9
   20db2:	66 45 0f c2 ce 00    	cmpeqpd %xmm14,%xmm9
   20db8:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   20dbd:	66 44 0f 55 cc       	andnpd %xmm4,%xmm9
   20dc2:	66 41 0f c2 e6 04    	cmpneqpd %xmm14,%xmm4
   20dc8:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   20dcc:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
   20dd1:	66 41 0f 54 c2       	andpd  %xmm10,%xmm0
   20dd6:	66 44 0f 55 f9       	andnpd %xmm1,%xmm15
   20ddb:	66 44 0f 56 f8       	orpd   %xmm0,%xmm15
   20de0:	66 0f 28 74 24 30    	movapd 0x30(%rsp),%xmm6
   20de6:	66 0f 28 ce          	movapd %xmm6,%xmm1
   20dea:	66 41 0f c2 ce 00    	cmpeqpd %xmm14,%xmm1
   20df0:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   20df5:	66 41 0f c2 ee 00    	cmpeqpd %xmm14,%xmm5
   20dfb:	66 0f 28 dd          	movapd %xmm5,%xmm3
   20dff:	66 41 0f 55 ed       	andnpd %xmm13,%xmm5
   20e04:	66 45 0f c2 ee 04    	cmpneqpd %xmm14,%xmm13
   20e0a:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   20e0f:	66 44 0f 29 ac 24 c0 	movapd %xmm13,0x1c0(%rsp)
   20e16:	01 00 00 
   20e19:	66 0f 28 c1          	movapd %xmm1,%xmm0
   20e1d:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e22:	66 0f 55 c6          	andnpd %xmm6,%xmm0
   20e26:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   20e2a:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   20e2f:	66 41 0f c2 f6 00    	cmpeqpd %xmm14,%xmm6
   20e35:	66 0f 28 ce          	movapd %xmm6,%xmm1
   20e39:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e3e:	66 41 0f 55 f4       	andnpd %xmm12,%xmm6
   20e43:	66 0f 56 f1          	orpd   %xmm1,%xmm6
   20e47:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   20e4c:	66 45 0f c2 ee 00    	cmpeqpd %xmm14,%xmm13
   20e52:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   20e57:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e5c:	66 44 0f 55 ea       	andnpd %xmm2,%xmm13
   20e61:	66 44 0f 56 e9       	orpd   %xmm1,%xmm13
   20e66:	66 44 0f 29 ac 24 b0 	movapd %xmm13,0x1b0(%rsp)
   20e6d:	01 00 00 
   20e70:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   20e75:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   20e7a:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   20e7f:	66 0f 56 eb          	orpd   %xmm3,%xmm5
   20e83:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
   20e88:	66 45 0f 5e df       	divpd  %xmm15,%xmm11
   20e8d:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   20e92:	66 44 0f 5e e8       	divpd  %xmm0,%xmm13
   20e97:	66 44 0f 28 3d 00 49 	movapd -0x1b700(%rip),%xmm15        # 57a0 <std::thread::current::id::ID+0x4b28>
   20e9e:	fe ff 
   20ea0:	66 0f 28 84 24 00 01 	movapd 0x100(%rsp),%xmm0
   20ea7:	00 00 
   20ea9:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20eae:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   20eb4:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   20eba:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ebf:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20ec5:	66 0f 28 84 24 e0 00 	movapd 0xe0(%rsp),%xmm0
   20ecc:	00 00 
   20ece:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ed3:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   20ed9:	66 0f 28 84 24 f0 00 	movapd 0xf0(%rsp),%xmm0
   20ee0:	00 00 
   20ee2:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ee7:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   20eed:	66 44 0f 28 94 24 80 	movapd 0x180(%rsp),%xmm10
   20ef4:	01 00 00 
   20ef7:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   20efc:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20f01:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
   20f08:	00 00 
   20f0a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   20f0e:	66 41 0f 5e c9       	divpd  %xmm9,%xmm1
   20f13:	66 44 0f 28 8c 24 90 	movapd 0x190(%rsp),%xmm9
   20f1a:	01 00 00 
   20f1d:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   20f22:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20f27:	66 0f 29 84 24 90 00 	movapd %xmm0,0x90(%rsp)
   20f2e:	00 00 
   20f30:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20f34:	66 0f 5e dd          	divpd  %xmm5,%xmm3
   20f38:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   20f3c:	66 0f 28 05 1c 48 fe 	movapd -0x1b7e4(%rip),%xmm0        # 5760 <std::thread::current::id::ID+0x4ae8>
   20f43:	ff 
   20f44:	66 0f 55 e0          	andnpd %xmm0,%xmm4
   20f48:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   20f4c:	66 0f 28 8c 24 c0 01 	movapd 0x1c0(%rsp),%xmm1
   20f53:	00 00 
   20f55:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   20f59:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   20f5d:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   20f61:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20f65:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   20f6b:	66 41 0f c2 de 04    	cmpneqpd %xmm14,%xmm3
   20f71:	66 0f 29 5c 24 10    	movapd %xmm3,0x10(%rsp)
   20f77:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20f7b:	66 0f c2 cf 02       	cmplepd %xmm7,%xmm1
   20f80:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   20f84:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   20f89:	66 45 0f c2 e6 04    	cmpneqpd %xmm14,%xmm12
   20f8f:	66 44 0f 54 e1       	andpd  %xmm1,%xmm12
   20f94:	66 0f 28 d9          	movapd %xmm1,%xmm3
   20f98:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   20f9c:	66 41 0f 56 db       	orpd   %xmm11,%xmm3
   20fa1:	66 44 0f 28 5c 24 30 	movapd 0x30(%rsp),%xmm11
   20fa8:	66 45 0f c2 de 04    	cmpneqpd %xmm14,%xmm11
   20fae:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20fb2:	66 41 0f c2 c8 02    	cmplepd %xmm8,%xmm1
   20fb8:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   20fbd:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   20fc2:	66 41 0f c2 d6 04    	cmpneqpd %xmm14,%xmm2
   20fc8:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   20fcc:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20fd0:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   20fd4:	66 41 0f 56 e5       	orpd   %xmm13,%xmm4
   20fd9:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   20fde:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   20fe2:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   20fe7:	66 0f 5e b4 24 b0 01 	divpd  0x1b0(%rsp),%xmm6
   20fee:	00 00 
   20ff0:	66 41 0f 54 cc       	andpd  %xmm12,%xmm1
   20ff5:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   20ffa:	66 44 0f 56 e1       	orpd   %xmm1,%xmm12
   20fff:	66 0f 54 f2          	andpd  %xmm2,%xmm6
   21003:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   21007:	66 0f 56 d6          	orpd   %xmm6,%xmm2
   2100b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2100f:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   21014:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   21018:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   2101c:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   21020:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21024:	66 0f c2 dc 01       	cmpltpd %xmm4,%xmm3
   21029:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   2102d:	66 0f 55 d8          	andnpd %xmm0,%xmm3
   21031:	66 0f 56 dc          	orpd   %xmm4,%xmm3
   21035:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   21039:	66 41 0f c2 e4 01    	cmpltpd %xmm12,%xmm4
   2103f:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   21044:	66 0f 55 e0          	andnpd %xmm0,%xmm4
   21048:	66 41 0f 56 e4       	orpd   %xmm12,%xmm4
   2104d:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   21051:	66 0f c2 ea 01       	cmpltpd %xmm2,%xmm5
   21056:	66 0f 54 d5          	andpd  %xmm5,%xmm2
   2105a:	66 0f 55 e8          	andnpd %xmm0,%xmm5
   2105e:	66 0f 56 ea          	orpd   %xmm2,%xmm5
   21062:	66 0f 28 05 b6 41 fe 	movapd -0x1be4a(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   21069:	ff 
   2106a:	66 44 0f 28 ac 24 f0 	movapd 0x1f0(%rsp),%xmm13
   21071:	01 00 00 
   21074:	66 44 0f 54 e8       	andpd  %xmm0,%xmm13
   21079:	66 44 0f 58 ac 24 c0 	addpd  0xc0(%rsp),%xmm13
   21080:	00 00 00 
   21083:	66 44 0f 28 a4 24 d0 	movapd 0x1d0(%rsp),%xmm12
   2108a:	01 00 00 
   2108d:	66 44 0f 54 e0       	andpd  %xmm0,%xmm12
   21092:	66 44 0f 58 a4 24 e0 	addpd  0x1e0(%rsp),%xmm12
   21099:	01 00 00 
   2109c:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   210a0:	66 0f 28 35 78 44 fe 	movapd -0x1bb88(%rip),%xmm6        # 5520 <std::thread::current::id::ID+0x48a8>
   210a7:	ff 
   210a8:	66 44 0f 59 ee       	mulpd  %xmm6,%xmm13
   210ad:	66 41 0f c2 fd 02    	cmplepd %xmm13,%xmm7
   210b3:	66 44 0f 59 e6       	mulpd  %xmm6,%xmm12
   210b8:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   210bd:	66 45 0f c2 c4 02    	cmplepd %xmm12,%xmm8
   210c3:	66 0f 54 7c 24 10    	andpd  0x10(%rsp),%xmm7
   210c9:	66 45 0f 54 c3       	andpd  %xmm11,%xmm8
   210ce:	66 0f 28 f1          	movapd %xmm1,%xmm6
   210d2:	66 0f 5d f4          	minpd  %xmm4,%xmm6
   210d6:	66 0f 55 fe          	andnpd %xmm6,%xmm7
   210da:	66 0f 28 f3          	movapd %xmm3,%xmm6
   210de:	66 0f 5d f5          	minpd  %xmm5,%xmm6
   210e2:	66 44 0f 55 c6       	andnpd %xmm6,%xmm8
   210e7:	66 0f 29 bc 24 00 02 	movapd %xmm7,0x200(%rsp)
   210ee:	00 00 
   210f0:	66 0f 5f cc          	maxpd  %xmm4,%xmm1
   210f4:	66 0f 5f dd          	maxpd  %xmm5,%xmm3
   210f8:	66 44 0f 29 84 24 10 	movapd %xmm8,0x210(%rsp)
   210ff:	02 00 00 
   21102:	66 0f 29 8c 24 20 02 	movapd %xmm1,0x220(%rsp)
   21109:	00 00 
   2110b:	66 0f 29 9c 24 30 02 	movapd %xmm3,0x230(%rsp)
   21112:	00 00 
   21114:	66 0f 28 8c 24 e0 00 	movapd 0xe0(%rsp),%xmm1
   2111b:	00 00 
   2111d:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21121:	66 41 0f c2 e6 04    	cmpneqpd %xmm14,%xmm4
   21127:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   2112b:	66 41 0f 28 ea       	movapd %xmm10,%xmm5
   21130:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   21134:	66 0f 28 dc          	movapd %xmm4,%xmm3
   21138:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   2113c:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   21140:	66 0f 56 e3          	orpd   %xmm3,%xmm4
   21144:	66 44 0f 28 9c 24 00 	movapd 0x100(%rsp),%xmm11
   2114b:	01 00 00 
   2114e:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   21153:	66 41 0f c2 f6 04    	cmpneqpd %xmm14,%xmm6
   21159:	66 44 0f 28 54 24 20 	movapd 0x20(%rsp),%xmm10
   21160:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   21165:	66 41 0f c2 fe 04    	cmpneqpd %xmm14,%xmm7
   2116b:	66 0f 28 9c 24 f0 00 	movapd 0xf0(%rsp),%xmm3
   21172:	00 00 
   21174:	66 44 0f c2 f3 04    	cmpneqpd %xmm3,%xmm14
   2117a:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   2117e:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   21183:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   21188:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   2118d:	66 44 0f 54 cb       	andpd  %xmm3,%xmm9
   21192:	66 45 0f 55 f0       	andnpd %xmm8,%xmm14
   21197:	66 45 0f 56 f1       	orpd   %xmm9,%xmm14
   2119c:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   211a1:	66 44 0f 54 c8       	andpd  %xmm0,%xmm9
   211a6:	66 44 0f 54 ce       	andpd  %xmm6,%xmm9
   211ab:	66 0f 55 f4          	andnpd %xmm4,%xmm6
   211af:	66 41 0f 56 f1       	orpd   %xmm9,%xmm6
   211b4:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
   211b9:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   211bd:	66 0f 54 e7          	andpd  %xmm7,%xmm4
   211c1:	66 41 0f 55 fe       	andnpd %xmm14,%xmm7
   211c6:	66 0f 56 fc          	orpd   %xmm4,%xmm7
   211ca:	66 0f 28 15 fe 40 fe 	movapd -0x1bf02(%rip),%xmm2        # 52d0 <std::thread::current::id::ID+0x4658>
   211d1:	ff 
   211d2:	66 0f 5f f2          	maxpd  %xmm2,%xmm6
   211d6:	66 0f 5f fa          	maxpd  %xmm2,%xmm7
   211da:	66 0f 5f cd          	maxpd  %xmm5,%xmm1
   211de:	66 41 0f 5f d8       	maxpd  %xmm8,%xmm3
   211e3:	66 0f 28 ac 24 a0 01 	movapd 0x1a0(%rsp),%xmm5
   211ea:	00 00 
   211ec:	66 0f 28 d5          	movapd %xmm5,%xmm2
   211f0:	66 0f 54 d0          	andpd  %xmm0,%xmm2
   211f4:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   211f8:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   211fc:	66 0f 28 a4 24 70 01 	movapd 0x170(%rsp),%xmm4
   21203:	00 00 
   21205:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   21209:	66 0f 5f d8          	maxpd  %xmm0,%xmm3
   2120d:	66 0f 5e df          	divpd  %xmm7,%xmm3
   21211:	f2 0f 10 05 37 60 fe 	movsd  -0x19fc9(%rip),%xmm0        # 7250 <std::thread::current::id::ID+0x65d8>
   21218:	ff 
   21219:	66 0f 28 15 8f 44 fe 	movapd -0x1bb71(%rip),%xmm2        # 56b0 <std::thread::current::id::ID+0x4a38>
   21220:	ff 
   21221:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21225:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21229:	66 0f c2 c2 00       	cmpeqpd %xmm2,%xmm0
   2122e:	66 0f c2 d2 00       	cmpeqpd %xmm2,%xmm2
   21233:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   21237:	66 0f 28 35 71 44 fe 	movapd -0x1bb8f(%rip),%xmm6        # 56b0 <std::thread::current::id::ID+0x4a38>
   2123e:	ff 
   2123f:	66 0f 55 d6          	andnpd %xmm6,%xmm2
   21243:	66 0f 56 d1          	orpd   %xmm1,%xmm2
   21247:	66 0f 29 94 24 40 02 	movapd %xmm2,0x240(%rsp)
   2124e:	00 00 
   21250:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   21254:	66 0f 55 c6          	andnpd %xmm6,%xmm0
   21258:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   2125c:	66 0f 29 84 24 50 02 	movapd %xmm0,0x250(%rsp)
   21263:	00 00 
   21265:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21269:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   2126e:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   21275:	00 00 
   21277:	66 44 0f 57 fc       	xorpd  %xmm4,%xmm15
   2127c:	66 44 0f 29 bc 24 b0 	movapd %xmm15,0xb0(%rsp)
   21283:	00 00 00 
   21286:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   2128c:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   21290:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   21297:	00 
   21298:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   2129d:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   212a4:	00 
   212a5:	48 8d 8c 24 40 02 00 	lea    0x240(%rsp),%rcx
   212ac:	00 
   212ad:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
   212b3:	e8 58 03 00 00       	call   21610 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>
   212b8:	f2 0f 10 84 24 20 01 	movsd  0x120(%rsp),%xmm0
   212bf:	00 00 
   212c1:	f2 0f 10 8c 24 28 01 	movsd  0x128(%rsp),%xmm1
   212c8:	00 00 
   212ca:	f2 0f 10 a4 24 30 01 	movsd  0x130(%rsp),%xmm4
   212d1:	00 00 
   212d3:	f2 0f 5d 05 25 5f fe 	minsd  -0x1a0db(%rip),%xmm0        # 7200 <std::thread::current::id::ID+0x6588>
   212da:	ff 
   212db:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   212df:	f2 0f 5d e1          	minsd  %xmm1,%xmm4
   212e3:	66 48 0f 7e e0       	movq   %xmm4,%rax
   212e8:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   212ef:	ff ff 7f 
   212f2:	4c 21 f8             	and    %r15,%rax
   212f5:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   212fb:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   21302:	ff ef 7f 
   21305:	48 39 c8             	cmp    %rcx,%rax
   21308:	7e 12                	jle    2131c <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa1c>
   2130a:	4c 89 f0             	mov    %r14,%rax
   2130d:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   21311:	5b                   	pop    %rbx
   21312:	41 5c                	pop    %r12
   21314:	41 5d                	pop    %r13
   21316:	41 5e                	pop    %r14
   21318:	41 5f                	pop    %r15
   2131a:	5d                   	pop    %rbp
   2131b:	c3                   	ret
   2131c:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
   21323:	00 
   21324:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
   21329:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   21330:	00 
   21331:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   21338:	00 
   21339:	f2 0f 10 4c 24 10    	movsd  0x10(%rsp),%xmm1
   2133f:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21343:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   21347:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2134b:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2134f:	f2 0f 10 0d f9 5e fe 	movsd  -0x1a107(%rip),%xmm1        # 7250 <std::thread::current::id::ID+0x65d8>
   21356:	ff 
   21357:	f2 0f 5e c8          	divsd  %xmm0,%xmm1
   2135b:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   2135f:	66 0f 28 84 24 a0 01 	movapd 0x1a0(%rsp),%xmm0
   21366:	00 00 
   21368:	66 0f 5c c1          	subpd  %xmm1,%xmm0
   2136c:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   21373:	00 00 
   21375:	66 0f 28 94 24 70 01 	movapd 0x170(%rsp),%xmm2
   2137c:	00 00 
   2137e:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   21382:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
   21389:	00 
   2138a:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   2138f:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   21394:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   21399:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   213a0:	00 
   213a1:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   213a6:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   213ad:	00 
   213ae:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   213b3:	0f 28 84 24 80 01 00 	movaps 0x180(%rsp),%xmm0
   213ba:	00 
   213bb:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   213c2:	00 
   213c3:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
   213ca:	00 
   213cb:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   213d2:	00 
   213d3:	66 0f 29 94 24 b0 00 	movapd %xmm2,0xb0(%rsp)
   213da:	00 00 
   213dc:	66 0f 28 cc          	movapd %xmm4,%xmm1
   213e0:	66 0f 28 c3          	movapd %xmm3,%xmm0
   213e4:	f2 0f 5e cb          	divsd  %xmm3,%xmm1
   213e8:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   213ec:	66 0f 29 8c 24 60 02 	movapd %xmm1,0x260(%rsp)
   213f3:	00 00 
   213f5:	66 0f 29 8c 24 70 02 	movapd %xmm1,0x270(%rsp)
   213fc:	00 00 
   213fe:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   21405:	00 
   21406:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   2140b:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   21412:	00 
   21413:	48 8d 8c 24 60 02 00 	lea    0x260(%rsp),%rcx
   2141a:	00 
   2141b:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   21420:	e8 eb 01 00 00       	call   21610 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>
   21425:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   2142b:	66 0f 28 c2          	movapd %xmm2,%xmm0
   2142f:	f2 0f 5d 84 24 20 01 	minsd  0x120(%rsp),%xmm0
   21436:	00 00 
   21438:	66 0f 28 c8          	movapd %xmm0,%xmm1
   2143c:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   21441:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   21445:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   21449:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   2144d:	f2 0f 10 84 24 28 01 	movsd  0x128(%rsp),%xmm0
   21454:	00 00 
   21456:	66 0f 28 d1          	movapd %xmm1,%xmm2
   2145a:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   2145e:	66 0f 28 da          	movapd %xmm2,%xmm3
   21462:	f2 0f c2 da 03       	cmpunordsd %xmm2,%xmm3
   21467:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   2146b:	66 0f 55 da          	andnpd %xmm2,%xmm3
   2146f:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   21475:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   21479:	f2 0f 10 84 24 30 01 	movsd  0x130(%rsp),%xmm0
   21480:	00 00 
   21482:	66 0f 28 cb          	movapd %xmm3,%xmm1
   21486:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   2148a:	66 0f 5d 94 24 40 01 	minpd  0x140(%rsp),%xmm2
   21491:	00 00 
   21493:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21497:	f2 0f c2 c1 03       	cmpunordsd %xmm1,%xmm0
   2149c:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   214a0:	66 0f 55 c1          	andnpd %xmm1,%xmm0
   214a4:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   214a8:	66 0f 28 c8          	movapd %xmm0,%xmm1
   214ac:	f2 0f 5e 4c 24 10    	divsd  0x10(%rsp),%xmm1
   214b2:	66 0f 2e ca          	ucomisd %xmm2,%xmm1
   214b6:	0f 87 4e fe ff ff    	ja     2130a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   214bc:	66 0f 15 d2          	unpckhpd %xmm2,%xmm2
   214c0:	66 0f 2e ca          	ucomisd %xmm2,%xmm1
   214c4:	0f 87 40 fe ff ff    	ja     2130a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   214ca:	66 0f 28 94 24 c0 00 	movapd 0xc0(%rsp),%xmm2
   214d1:	00 00 
   214d3:	f2 0f 5d 94 24 50 01 	minsd  0x150(%rsp),%xmm2
   214da:	00 00 
   214dc:	66 0f 2e ca          	ucomisd %xmm2,%xmm1
   214e0:	0f 87 24 fe ff ff    	ja     2130a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   214e6:	66 48 0f 7e c0       	movq   %xmm0,%rax
   214eb:	49 21 c7             	and    %rax,%r15
   214ee:	49 8d 4f ff          	lea    -0x1(%r15),%rcx
   214f2:	48 ba ff ff ff ff ff 	movabs $0xfffffffffffff,%rdx
   214f9:	ff 0f 00 
   214fc:	48 39 d1             	cmp    %rdx,%rcx
   214ff:	0f 92 c1             	setb   %cl
   21502:	48 85 c0             	test   %rax,%rax
   21505:	0f 98 c0             	sets   %al
   21508:	20 c1                	and    %al,%cl
   2150a:	48 ba 00 00 00 00 00 	movabs $0x7ff0000000000000,%rdx
   21511:	00 f0 7f 
   21514:	49 39 d7             	cmp    %rdx,%r15
   21517:	0f 94 c2             	sete   %dl
   2151a:	08 ca                	or     %cl,%dl
   2151c:	48 b9 00 00 00 00 00 	movabs $0xfff0000000000000,%rcx
   21523:	00 f0 ff 
   21526:	4c 01 f9             	add    %r15,%rcx
   21529:	48 c1 e9 35          	shr    $0x35,%rcx
   2152d:	81 f9 ff 03 00 00    	cmp    $0x3ff,%ecx
   21533:	0f 92 c1             	setb   %cl
   21536:	20 c1                	and    %al,%cl
   21538:	08 d1                	or     %dl,%cl
   2153a:	0f 85 ca fd ff ff    	jne    2130a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   21540:	0f 57 c9             	xorps  %xmm1,%xmm1
   21543:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   21547:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   2154e:	00 
   2154f:	0f 56 05 8a 42 fe ff 	orps   -0x1bd76(%rip),%xmm0        # 57e0 <std::thread::current::id::ID+0x4b68>
   21556:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   2155d:	00 
   2155e:	41 bc 40 00 00 00    	mov    $0x40,%r12d
   21564:	0f b6 db             	movzbl %bl,%ebx
   21567:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
   2156c:	eb 1b                	jmp    21589 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc89>
   2156e:	41 bd 01 00 00 80    	mov    $0x80000001,%r13d
   21574:	66 41 0f 6e cd       	movd   %r13d,%xmm1
   21579:	0f 57 c0             	xorps  %xmm0,%xmm0
   2157c:	f3 0f 5f c8          	maxss  %xmm0,%xmm1
   21580:	41 ff cc             	dec    %r12d
   21583:	0f 84 81 fd ff ff    	je     2130a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   21589:	66 41 0f 7e cd       	movd   %xmm1,%r13d
   2158e:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   21594:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
   2159a:	f3 0f 11 4c 24 10    	movss  %xmm1,0x10(%rsp)
   215a0:	f3 0f 11 4c 24 44    	movss  %xmm1,0x44(%rsp)
   215a6:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   215ad:	00 
   215ae:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
   215b4:	c7 44 24 4c 00 00 80 	movl   $0xff800000,0x4c(%rsp)
   215bb:	ff 
   215bc:	4c 89 ff             	mov    %r15,%rdi
   215bf:	89 de                	mov    %ebx,%esi
   215c1:	e8 1a 0e 00 00       	call   223e0 <gpui_canvas::color::gamut::in_gamut>
   215c6:	84 c0                	test   %al,%al
   215c8:	75 28                	jne    215f2 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcf2>
   215ca:	41 81 fd 00 00 80 ff 	cmp    $0xff800000,%r13d
   215d1:	66 0f 6e 4c 24 10    	movd   0x10(%rsp),%xmm1
   215d7:	74 a0                	je     21579 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc79>
   215d9:	44 89 e8             	mov    %r13d,%eax
   215dc:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   215e1:	74 8b                	je     2156e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc6e>
   215e3:	41 39 c5             	cmp    %eax,%r13d
   215e6:	75 05                	jne    215ed <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xced>
   215e8:	41 ff cd             	dec    %r13d
   215eb:	eb 87                	jmp    21574 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc74>
   215ed:	41 ff c5             	inc    %r13d
   215f0:	eb 82                	jmp    21574 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc74>
   215f2:	49 c1 e5 20          	shl    $0x20,%r13
   215f6:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   215fc:	4d 09 ee             	or     %r13,%r14
   215ff:	e9 06 fd ff ff       	jmp    2130a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   21604:	cc                   	int3
   21605:	cc                   	int3
   21606:	cc                   	int3
   21607:	cc                   	int3
   21608:	cc                   	int3
   21609:	cc                   	int3
   2160a:	cc                   	int3
   2160b:	cc                   	int3
   2160c:	cc                   	int3
   2160d:	cc                   	int3
   2160e:	cc                   	int3
   2160f:	cc                   	int3

0000000000021610 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>:
   21610:	55                   	push   %rbp
   21611:	48 89 e5             	mov    %rsp,%rbp
   21614:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   21618:	48 81 ec 00 04 00 00 	sub    $0x400,%rsp
   2161f:	66 44 0f 28 e8       	movapd %xmm0,%xmm13
   21624:	66 44 0f 28 3e       	movapd (%rsi),%xmm15
   21629:	66 44 0f 28 5e 10    	movapd 0x10(%rsi),%xmm11
   2162f:	66 0f 28 46 20       	movapd 0x20(%rsi),%xmm0
   21634:	66 44 0f 28 76 30    	movapd 0x30(%rsi),%xmm14
   2163a:	66 44 0f 28 4e 40    	movapd 0x40(%rsi),%xmm9
   21640:	66 44 0f 28 46 60    	movapd 0x60(%rsi),%xmm8
   21646:	66 44 0f 28 66 70    	movapd 0x70(%rsi),%xmm12
   2164c:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21650:	66 41 0f c2 d8 01    	cmpltpd %xmm8,%xmm3
   21656:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2165a:	66 41 0f c2 d4 01    	cmpltpd %xmm12,%xmm2
   21660:	66 0f 28 0d f8 40 fe 	movapd -0x1bf08(%rip),%xmm1        # 5760 <std::thread::current::id::ID+0x4ae8>
   21667:	ff 
   21668:	66 0f 55 d9          	andnpd %xmm1,%xmm3
   2166c:	66 0f 29 5c 24 30    	movapd %xmm3,0x30(%rsp)
   21672:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   21676:	66 0f 29 54 24 40    	movapd %xmm2,0x40(%rsp)
   2167c:	0f 28 52 20          	movaps 0x20(%rdx),%xmm2
   21680:	0f 28 4a 30          	movaps 0x30(%rdx),%xmm1
   21684:	0f 29 94 24 20 02 00 	movaps %xmm2,0x220(%rsp)
   2168b:	00 
   2168c:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   21693:	00 
   21694:	0f 28 0a             	movaps (%rdx),%xmm1
   21697:	0f 29 8c 24 00 02 00 	movaps %xmm1,0x200(%rsp)
   2169e:	00 
   2169f:	0f 28 4a 10          	movaps 0x10(%rdx),%xmm1
   216a3:	0f 29 8c 24 10 02 00 	movaps %xmm1,0x210(%rsp)
   216aa:	00 
   216ab:	0f 28 a4 24 00 02 00 	movaps 0x200(%rsp),%xmm4
   216b2:	00 
   216b3:	0f 28 8c 24 10 02 00 	movaps 0x210(%rsp),%xmm1
   216ba:	00 
   216bb:	0f 28 94 24 20 02 00 	movaps 0x220(%rsp),%xmm2
   216c2:	00 
   216c3:	0f 28 9c 24 30 02 00 	movaps 0x230(%rsp),%xmm3
   216ca:	00 
   216cb:	0f 29 9c 24 50 03 00 	movaps %xmm3,0x350(%rsp)
   216d2:	00 
   216d3:	0f 29 94 24 40 03 00 	movaps %xmm2,0x340(%rsp)
   216da:	00 
   216db:	0f 29 8c 24 30 03 00 	movaps %xmm1,0x330(%rsp)
   216e2:	00 
   216e3:	0f 29 a4 24 20 03 00 	movaps %xmm4,0x320(%rsp)
   216ea:	00 
   216eb:	0f 28 8c 24 50 03 00 	movaps 0x350(%rsp),%xmm1
   216f2:	00 
   216f3:	0f 29 8c 24 b0 03 00 	movaps %xmm1,0x3b0(%rsp)
   216fa:	00 
   216fb:	0f 28 a4 24 10 03 00 	movaps 0x310(%rsp),%xmm4
   21702:	00 
   21703:	0f 28 8c 24 20 03 00 	movaps 0x320(%rsp),%xmm1
   2170a:	00 
   2170b:	0f 28 94 24 30 03 00 	movaps 0x330(%rsp),%xmm2
   21712:	00 
   21713:	0f 28 9c 24 40 03 00 	movaps 0x340(%rsp),%xmm3
   2171a:	00 
   2171b:	0f 29 9c 24 a0 03 00 	movaps %xmm3,0x3a0(%rsp)
   21722:	00 
   21723:	0f 29 94 24 90 03 00 	movaps %xmm2,0x390(%rsp)
   2172a:	00 
   2172b:	0f 29 8c 24 80 03 00 	movaps %xmm1,0x380(%rsp)
   21732:	00 
   21733:	0f 29 a4 24 70 03 00 	movaps %xmm4,0x370(%rsp)
   2173a:	00 
   2173b:	66 0f 28 0d 1d 40 fe 	movapd -0x1bfe3(%rip),%xmm1        # 5760 <std::thread::current::id::ID+0x4ae8>
   21742:	ff 
   21743:	66 0f 29 8c 24 c0 03 	movapd %xmm1,0x3c0(%rsp)
   2174a:	00 00 
   2174c:	66 0f 29 8c 24 d0 03 	movapd %xmm1,0x3d0(%rsp)
   21753:	00 00 
   21755:	48 8d 84 24 80 03 00 	lea    0x380(%rsp),%rax
   2175c:	00 
   2175d:	66 0f 28 15 bb 3a fe 	movapd -0x1c545(%rip),%xmm2        # 5220 <std::thread::current::id::ID+0x45a8>
   21764:	ff 
   21765:	66 41 0f 28 df       	movapd %xmm15,%xmm3
   2176a:	66 0f 54 da          	andpd  %xmm2,%xmm3
   2176e:	66 41 0f 28 e3       	movapd %xmm11,%xmm4
   21773:	66 0f 54 e2          	andpd  %xmm2,%xmm4
   21777:	66 0f 28 e8          	movapd %xmm0,%xmm5
   2177b:	66 0f 54 ea          	andpd  %xmm2,%xmm5
   2177f:	66 41 0f 28 f6       	movapd %xmm14,%xmm6
   21784:	66 0f 54 f2          	andpd  %xmm2,%xmm6
   21788:	66 41 0f 28 f9       	movapd %xmm9,%xmm7
   2178d:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   21791:	66 0f 29 bc 24 f0 01 	movapd %xmm7,0x1f0(%rsp)
   21798:	00 00 
   2179a:	66 0f 28 7e 50       	movapd 0x50(%rsi),%xmm7
   2179f:	66 0f 29 bc 24 90 00 	movapd %xmm7,0x90(%rsp)
   217a6:	00 00 
   217a8:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   217ac:	66 0f 29 bc 24 30 01 	movapd %xmm7,0x130(%rsp)
   217b3:	00 00 
   217b5:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   217ba:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   217be:	66 0f 29 bc 24 90 02 	movapd %xmm7,0x290(%rsp)
   217c5:	00 00 
   217c7:	66 41 0f 28 fc       	movapd %xmm12,%xmm7
   217cc:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   217d0:	66 0f 29 bc 24 80 02 	movapd %xmm7,0x280(%rsp)
   217d7:	00 00 
   217d9:	66 45 0f 14 ed       	unpcklpd %xmm13,%xmm13
   217de:	66 0f 28 15 da 3b fe 	movapd -0x1c426(%rip),%xmm2        # 53c0 <std::thread::current::id::ID+0x4748>
   217e5:	ff 
   217e6:	66 41 0f 28 ff       	movapd %xmm15,%xmm7
   217eb:	66 0f 59 fa          	mulpd  %xmm2,%xmm7
   217ef:	66 0f 29 bc 24 e0 01 	movapd %xmm7,0x1e0(%rsp)
   217f6:	00 00 
   217f8:	66 41 0f 28 fb       	movapd %xmm11,%xmm7
   217fd:	66 0f 59 fa          	mulpd  %xmm2,%xmm7
   21801:	66 0f 29 bc 24 d0 01 	movapd %xmm7,0x1d0(%rsp)
   21808:	00 00 
   2180a:	66 0f 28 f8          	movapd %xmm0,%xmm7
   2180e:	66 0f 58 f8          	addpd  %xmm0,%xmm7
   21812:	66 0f 29 bc 24 c0 01 	movapd %xmm7,0x1c0(%rsp)
   21819:	00 00 
   2181b:	66 41 0f 28 fe       	movapd %xmm14,%xmm7
   21820:	66 41 0f 58 fe       	addpd  %xmm14,%xmm7
   21825:	66 0f 29 bc 24 b0 01 	movapd %xmm7,0x1b0(%rsp)
   2182c:	00 00 
   2182e:	66 0f 29 9c 24 d0 02 	movapd %xmm3,0x2d0(%rsp)
   21835:	00 00 
   21837:	66 0f 59 da          	mulpd  %xmm2,%xmm3
   2183b:	66 0f 29 9c 24 10 01 	movapd %xmm3,0x110(%rsp)
   21842:	00 00 
   21844:	66 0f 29 a4 24 c0 02 	movapd %xmm4,0x2c0(%rsp)
   2184b:	00 00 
   2184d:	66 0f 59 d4          	mulpd  %xmm4,%xmm2
   21851:	66 41 0f 28 e1       	movapd %xmm9,%xmm4
   21856:	66 0f 29 94 24 20 01 	movapd %xmm2,0x120(%rsp)
   2185d:	00 00 
   2185f:	66 0f 29 ac 24 b0 02 	movapd %xmm5,0x2b0(%rsp)
   21866:	00 00 
   21868:	66 0f 58 ed          	addpd  %xmm5,%xmm5
   2186c:	66 0f 29 ac 24 a0 01 	movapd %xmm5,0x1a0(%rsp)
   21873:	00 00 
   21875:	66 0f 29 b4 24 a0 02 	movapd %xmm6,0x2a0(%rsp)
   2187c:	00 00 
   2187e:	66 0f 58 f6          	addpd  %xmm6,%xmm6
   21882:	66 0f 29 b4 24 00 01 	movapd %xmm6,0x100(%rsp)
   21889:	00 00 
   2188b:	66 41 0f 28 fe       	movapd %xmm14,%xmm7
   21890:	31 d2                	xor    %edx,%edx
   21892:	0f 28 11             	movaps (%rcx),%xmm2
   21895:	0f 29 94 24 70 02 00 	movaps %xmm2,0x270(%rsp)
   2189c:	00 
   2189d:	66 0f 28 51 10       	movapd 0x10(%rcx),%xmm2
   218a2:	66 0f 29 94 24 60 02 	movapd %xmm2,0x260(%rsp)
   218a9:	00 00 
   218ab:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   218b0:	66 45 0f 57 c9       	xorpd  %xmm9,%xmm9
   218b5:	66 0f 29 4c 24 60    	movapd %xmm1,0x60(%rsp)
   218bb:	66 0f 29 4c 24 50    	movapd %xmm1,0x50(%rsp)
   218c1:	66 44 0f 29 ac 24 50 	movapd %xmm13,0x250(%rsp)
   218c8:	02 00 00 
   218cb:	66 44 0f 29 bc 24 f0 	movapd %xmm15,0x2f0(%rsp)
   218d2:	02 00 00 
   218d5:	66 44 0f 29 9c 24 60 	movapd %xmm11,0x160(%rsp)
   218dc:	01 00 00 
   218df:	66 0f 29 84 24 e0 02 	movapd %xmm0,0x2e0(%rsp)
   218e6:	00 00 
   218e8:	66 0f 29 bc 24 90 01 	movapd %xmm7,0x190(%rsp)
   218ef:	00 00 
   218f1:	66 0f 29 a4 24 80 00 	movapd %xmm4,0x80(%rsp)
   218f8:	00 00 
   218fa:	66 44 0f 29 84 24 50 	movapd %xmm8,0x150(%rsp)
   21901:	01 00 00 
   21904:	66 44 0f 29 a4 24 40 	movapd %xmm12,0x140(%rsp)
   2190b:	01 00 00 
   2190e:	e9 eb 00 00 00       	jmp    219fe <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x3ee>
   21913:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2191a:	84 00 00 00 00 00 
   21920:	0f 28 e3             	movaps %xmm3,%xmm4
   21923:	0f 5a dc             	cvtps2pd %xmm4,%xmm3
   21926:	66 0f 70 e4 ee       	pshufd $0xee,%xmm4,%xmm4
   2192b:	0f 5a e4             	cvtps2pd %xmm4,%xmm4
   2192e:	66 0f 28 94 24 a0 00 	movapd 0xa0(%rsp),%xmm2
   21935:	00 00 
   21937:	66 0f 54 da          	andpd  %xmm2,%xmm3
   2193b:	66 0f 55 54 24 30    	andnpd 0x30(%rsp),%xmm2
   21941:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   21945:	66 0f 28 9c 24 00 03 	movapd 0x300(%rsp),%xmm3
   2194c:	00 00 
   2194e:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   21952:	66 0f 55 5c 24 40    	andnpd 0x40(%rsp),%xmm3
   21958:	66 0f 56 dc          	orpd   %xmm4,%xmm3
   2195c:	66 0f 29 5c 24 40    	movapd %xmm3,0x40(%rsp)
   21962:	66 0f 29 54 24 30    	movapd %xmm2,0x30(%rsp)
   21968:	66 44 0f 28 74 24 70 	movapd 0x70(%rsp),%xmm14
   2196f:	66 44 0f 28 8c 24 d0 	movapd 0xd0(%rsp),%xmm9
   21976:	00 00 00 
   21979:	66 0f 28 9c 24 c0 00 	movapd 0xc0(%rsp),%xmm3
   21980:	00 00 
   21982:	66 44 0f 28 9c 24 b0 	movapd 0xb0(%rsp),%xmm11
   21989:	00 00 00 
   2198c:	48 ff c2             	inc    %rdx
   2198f:	66 0f 28 4c 24 10    	movapd 0x10(%rsp),%xmm1
   21995:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   21999:	66 0f 28 6c 24 20    	movapd 0x20(%rsp),%xmm5
   2199f:	66 41 0f 54 eb       	andpd  %xmm11,%xmm5
   219a4:	66 0f 28 9c 24 e0 00 	movapd 0xe0(%rsp),%xmm3
   219ab:	00 00 
   219ad:	66 0f 54 9c 24 70 01 	andpd  0x170(%rsp),%xmm3
   219b4:	00 00 
   219b6:	66 0f 28 94 24 f0 00 	movapd 0xf0(%rsp),%xmm2
   219bd:	00 00 
   219bf:	66 0f 54 94 24 80 01 	andpd  0x180(%rsp),%xmm2
   219c6:	00 00 
   219c8:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   219cc:	66 0f 55 4c 24 50    	andnpd 0x50(%rsp),%xmm1
   219d2:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   219d6:	66 0f 29 4c 24 50    	movapd %xmm1,0x50(%rsp)
   219dc:	66 0f 54 d5          	andpd  %xmm5,%xmm2
   219e0:	66 0f 55 6c 24 60    	andnpd 0x60(%rsp),%xmm5
   219e6:	66 0f 28 cd          	movapd %xmm5,%xmm1
   219ea:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   219ee:	66 0f 29 4c 24 60    	movapd %xmm1,0x60(%rsp)
   219f4:	48 83 fa 03          	cmp    $0x3,%rdx
   219f8:	0f 84 b8 09 00 00    	je     223b6 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0xda6>
   219fe:	66 44 0f 29 8c 24 70 	movapd %xmm9,0x170(%rsp)
   21a05:	01 00 00 
   21a08:	66 44 0f 29 b4 24 80 	movapd %xmm14,0x180(%rsp)
   21a0f:	01 00 00 
   21a12:	48 89 d1             	mov    %rdx,%rcx
   21a15:	48 c1 e1 05          	shl    $0x5,%rcx
   21a19:	66 0f 28 0c 08       	movapd (%rax,%rcx,1),%xmm1
   21a1e:	66 0f 28 44 08 10    	movapd 0x10(%rax,%rcx,1),%xmm0
   21a24:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21a28:	66 44 0f 28 15 2f 3d 	movapd -0x1c2d1(%rip),%xmm10        # 5760 <std::thread::current::id::ID+0x4ae8>
   21a2f:	fe ff 
   21a31:	66 41 0f c2 d2 01    	cmpltpd %xmm10,%xmm2
   21a37:	66 0f 28 d8          	movapd %xmm0,%xmm3
   21a3b:	66 41 0f c2 da 01    	cmpltpd %xmm10,%xmm3
   21a41:	66 0f 29 54 24 10    	movapd %xmm2,0x10(%rsp)
   21a47:	66 0f 29 8c 24 a0 00 	movapd %xmm1,0xa0(%rsp)
   21a4e:	00 00 
   21a50:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   21a54:	66 0f 29 5c 24 70    	movapd %xmm3,0x70(%rsp)
   21a5a:	66 0f 29 84 24 b0 00 	movapd %xmm0,0xb0(%rsp)
   21a61:	00 00 
   21a63:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   21a67:	66 0f 29 94 24 d0 00 	movapd %xmm2,0xd0(%rsp)
   21a6e:	00 00 
   21a70:	66 0f 28 f2          	movapd %xmm2,%xmm6
   21a74:	66 0f 28 05 a4 37 fe 	movapd -0x1c85c(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   21a7b:	ff 
   21a7c:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   21a80:	66 0f 29 9c 24 c0 00 	movapd %xmm3,0xc0(%rsp)
   21a87:	00 00 
   21a89:	66 44 0f 28 c3       	movapd %xmm3,%xmm8
   21a8e:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   21a93:	66 0f 28 05 15 3c fe 	movapd -0x1c3eb(%rip),%xmm0        # 56b0 <std::thread::current::id::ID+0x4a38>
   21a9a:	ff 
   21a9b:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   21a9f:	66 44 0f 58 c0       	addpd  %xmm0,%xmm8
   21aa4:	66 0f 28 05 74 3a fe 	movapd -0x1c58c(%rip),%xmm0        # 5520 <std::thread::current::id::ID+0x48a8>
   21aab:	ff 
   21aac:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   21ab0:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   21ab5:	b9 1f 00 00 00       	mov    $0x1f,%ecx
   21aba:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
   21abf:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   21ac6:	00 00 00 
   21ac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   21ad0:	66 0f 29 64 24 20    	movapd %xmm4,0x20(%rsp)
   21ad6:	66 44 0f 29 84 24 e0 	movapd %xmm8,0xe0(%rsp)
   21add:	00 00 00 
   21ae0:	66 0f 29 b4 24 f0 00 	movapd %xmm6,0xf0(%rsp)
   21ae7:	00 00 
   21ae9:	66 0f 28 8c 24 d0 00 	movapd 0xd0(%rsp),%xmm1
   21af0:	00 00 
   21af2:	66 0f 28 e9          	movapd %xmm1,%xmm5
   21af6:	66 0f 5c ee          	subpd  %xmm6,%xmm5
   21afa:	66 0f 28 94 24 c0 00 	movapd 0xc0(%rsp),%xmm2
   21b01:	00 00 
   21b03:	66 0f 28 fa          	movapd %xmm2,%xmm7
   21b07:	66 41 0f 5c f8       	subpd  %xmm8,%xmm7
   21b0c:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21b10:	66 0f 5f e8          	maxpd  %xmm0,%xmm5
   21b14:	66 0f 5f f8          	maxpd  %xmm0,%xmm7
   21b18:	66 0f 28 c6          	movapd %xmm6,%xmm0
   21b1c:	66 0f 58 c1          	addpd  %xmm1,%xmm0
   21b20:	66 41 0f 28 c8       	movapd %xmm8,%xmm1
   21b25:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21b29:	66 44 0f 28 84 24 e0 	movapd 0x1e0(%rsp),%xmm8
   21b30:	01 00 00 
   21b33:	66 45 0f 28 d8       	movapd %xmm8,%xmm11
   21b38:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   21b3d:	66 0f 28 b4 24 d0 01 	movapd 0x1d0(%rsp),%xmm6
   21b44:	00 00 
   21b46:	66 0f 28 e6          	movapd %xmm6,%xmm4
   21b4a:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   21b4e:	66 0f 28 94 24 c0 01 	movapd 0x1c0(%rsp),%xmm2
   21b55:	00 00 
   21b57:	66 44 0f 58 da       	addpd  %xmm2,%xmm11
   21b5c:	66 0f 28 9c 24 b0 01 	movapd 0x1b0(%rsp),%xmm3
   21b63:	00 00 
   21b65:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   21b69:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   21b6e:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   21b72:	66 44 0f 28 ac 24 80 	movapd 0x80(%rsp),%xmm13
   21b79:	00 00 00 
   21b7c:	66 45 0f 58 dd       	addpd  %xmm13,%xmm11
   21b81:	66 41 0f 58 e6       	addpd  %xmm14,%xmm4
   21b86:	66 44 0f 28 bc 24 10 	movapd 0x110(%rsp),%xmm15
   21b8d:	01 00 00 
   21b90:	66 44 0f 59 fd       	mulpd  %xmm5,%xmm15
   21b95:	66 44 0f 28 8c 24 20 	movapd 0x120(%rsp),%xmm9
   21b9c:	01 00 00 
   21b9f:	66 44 0f 59 cf       	mulpd  %xmm7,%xmm9
   21ba4:	66 44 0f 28 b4 24 a0 	movapd 0x1a0(%rsp),%xmm14
   21bab:	01 00 00 
   21bae:	66 45 0f 58 fe       	addpd  %xmm14,%xmm15
   21bb3:	66 44 0f 58 8c 24 00 	addpd  0x100(%rsp),%xmm9
   21bba:	01 00 00 
   21bbd:	66 44 0f 59 fd       	mulpd  %xmm5,%xmm15
   21bc2:	66 44 0f 59 cf       	mulpd  %xmm7,%xmm9
   21bc7:	66 44 0f 28 a4 24 f0 	movapd 0x1f0(%rsp),%xmm12
   21bce:	01 00 00 
   21bd1:	66 45 0f 58 fc       	addpd  %xmm12,%xmm15
   21bd6:	66 44 0f 58 8c 24 30 	addpd  0x130(%rsp),%xmm9
   21bdd:	01 00 00 
   21be0:	66 0f 28 2d 38 39 fe 	movapd -0x1c6c8(%rip),%xmm5        # 5520 <std::thread::current::id::ID+0x48a8>
   21be7:	ff 
   21be8:	66 44 0f 59 fd       	mulpd  %xmm5,%xmm15
   21bed:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   21bf2:	66 41 0f 28 f8       	movapd %xmm8,%xmm7
   21bf7:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   21bfb:	66 44 0f 28 c6       	movapd %xmm6,%xmm8
   21c00:	66 0f 28 b4 24 f0 00 	movapd 0xf0(%rsp),%xmm6
   21c07:	00 00 
   21c09:	66 44 0f 59 c1       	mulpd  %xmm1,%xmm8
   21c0e:	66 0f 58 fa          	addpd  %xmm2,%xmm7
   21c12:	66 44 0f 58 c3       	addpd  %xmm3,%xmm8
   21c17:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   21c1b:	66 44 0f 59 c1       	mulpd  %xmm1,%xmm8
   21c20:	66 41 0f 58 fd       	addpd  %xmm13,%xmm7
   21c25:	66 44 0f 58 84 24 90 	addpd  0x90(%rsp),%xmm8
   21c2c:	00 00 00 
   21c2f:	66 0f 28 ac 24 10 01 	movapd 0x110(%rsp),%xmm5
   21c36:	00 00 
   21c38:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   21c3c:	66 41 0f 58 ee       	addpd  %xmm14,%xmm5
   21c41:	66 0f 59 e8          	mulpd  %xmm0,%xmm5
   21c45:	66 0f 28 84 24 20 01 	movapd 0x120(%rsp),%xmm0
   21c4c:	00 00 
   21c4e:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21c52:	66 0f 58 84 24 00 01 	addpd  0x100(%rsp),%xmm0
   21c59:	00 00 
   21c5b:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21c5f:	66 41 0f 58 ec       	addpd  %xmm12,%xmm5
   21c64:	66 44 0f 28 b4 24 90 	movapd 0x90(%rsp),%xmm14
   21c6b:	00 00 00 
   21c6e:	66 0f 58 84 24 30 01 	addpd  0x130(%rsp),%xmm0
   21c75:	00 00 
   21c77:	66 0f 28 0d a1 38 fe 	movapd -0x1c75f(%rip),%xmm1        # 5520 <std::thread::current::id::ID+0x48a8>
   21c7e:	ff 
   21c7f:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   21c83:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21c87:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   21c8c:	66 0f 28 15 0c 3b fe 	movapd -0x1c4f4(%rip),%xmm2        # 57a0 <std::thread::current::id::ID+0x4b28>
   21c93:	ff 
   21c94:	66 0f 57 ca          	xorpd  %xmm2,%xmm1
   21c98:	66 45 0f c2 fb 01    	cmpltpd %xmm11,%xmm15
   21c9e:	66 44 0f c2 d9 01    	cmpltpd %xmm1,%xmm11
   21ca4:	66 41 0f 28 c9       	movapd %xmm9,%xmm1
   21ca9:	66 0f 57 ca          	xorpd  %xmm2,%xmm1
   21cad:	66 44 0f c2 cc 01    	cmpltpd %xmm4,%xmm9
   21cb3:	66 0f c2 e1 01       	cmpltpd %xmm1,%xmm4
   21cb8:	66 0f 28 cd          	movapd %xmm5,%xmm1
   21cbc:	66 0f c2 cf 01       	cmpltpd %xmm7,%xmm1
   21cc1:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   21cc6:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   21ccb:	66 45 0f c2 d8 01    	cmpltpd %xmm8,%xmm11
   21cd1:	66 44 0f 54 dc       	andpd  %xmm4,%xmm11
   21cd6:	66 0f 57 ea          	xorpd  %xmm2,%xmm5
   21cda:	66 0f c2 fd 01       	cmpltpd %xmm5,%xmm7
   21cdf:	66 41 0f 54 ff       	andpd  %xmm15,%xmm7
   21ce4:	66 0f 56 f9          	orpd   %xmm1,%xmm7
   21ce8:	66 0f 57 c2          	xorpd  %xmm2,%xmm0
   21cec:	66 44 0f c2 c0 01    	cmpltpd %xmm0,%xmm8
   21cf2:	66 45 0f 54 c1       	andpd  %xmm9,%xmm8
   21cf7:	66 45 0f 56 c3       	orpd   %xmm11,%xmm8
   21cfc:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   21d01:	66 0f 28 2d 57 3a fe 	movapd -0x1c5a9(%rip),%xmm5        # 5760 <std::thread::current::id::ID+0x4ae8>
   21d08:	ff 
   21d09:	66 0f c2 c5 00       	cmpeqpd %xmm5,%xmm0
   21d0e:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
   21d14:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   21d18:	66 0f 54 c7          	andpd  %xmm7,%xmm0
   21d1c:	66 0f 28 7c 24 20    	movapd 0x20(%rsp),%xmm7
   21d22:	66 0f 28 cf          	movapd %xmm7,%xmm1
   21d26:	66 0f c2 cd 00       	cmpeqpd %xmm5,%xmm1
   21d2b:	66 0f 28 5c 24 70    	movapd 0x70(%rsp),%xmm3
   21d31:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   21d35:	66 41 0f 54 c8       	andpd  %xmm8,%xmm1
   21d3a:	66 44 0f 28 84 24 e0 	movapd 0xe0(%rsp),%xmm8
   21d41:	00 00 00 
   21d44:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21d48:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   21d4d:	66 0f 58 f6          	addpd  %xmm6,%xmm6
   21d51:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   21d55:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   21d5a:	66 44 0f 56 d4       	orpd   %xmm4,%xmm10
   21d5f:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21d63:	66 0f 55 cf          	andnpd %xmm7,%xmm1
   21d67:	66 45 0f 58 c0       	addpd  %xmm8,%xmm8
   21d6c:	66 41 0f 54 c0       	andpd  %xmm8,%xmm0
   21d71:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21d75:	66 0f 56 e0          	orpd   %xmm0,%xmm4
   21d79:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   21d7e:	66 0f c2 c5 00       	cmpeqpd %xmm5,%xmm0
   21d83:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   21d87:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
   21d8c:	66 0f 28 c4          	movapd %xmm4,%xmm0
   21d90:	f2 0f c2 c5 00       	cmpeqsd %xmm5,%xmm0
   21d95:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21d99:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
   21d9e:	41 c1 e1 02          	shl    $0x2,%r9d
   21da2:	41 83 e1 04          	and    $0x4,%r9d
   21da6:	83 e9 01             	sub    $0x1,%ecx
   21da9:	40 0f 92 c6          	setb   %sil
   21dad:	45 09 c1             	or     %r8d,%r9d
   21db0:	74 09                	je     21dbb <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x7ab>
   21db2:	40 84 f6             	test   %sil,%sil
   21db5:	0f 84 15 fd ff ff    	je     21ad0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x4c0>
   21dbb:	66 0f 28 bc 24 a0 00 	movapd 0xa0(%rsp),%xmm7
   21dc2:	00 00 
   21dc4:	66 44 0f 28 ff       	movapd %xmm7,%xmm15
   21dc9:	66 0f 28 94 24 70 02 	movapd 0x270(%rsp),%xmm2
   21dd0:	00 00 
   21dd2:	66 44 0f 5d fa       	minpd  %xmm2,%xmm15
   21dd7:	66 44 0f 28 9c 24 b0 	movapd 0xb0(%rsp),%xmm11
   21dde:	00 00 00 
   21de1:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   21de6:	66 0f 28 9c 24 60 02 	movapd 0x260(%rsp),%xmm3
   21ded:	00 00 
   21def:	66 0f 5d eb          	minpd  %xmm3,%xmm5
   21df3:	66 44 0f 54 54 24 10 	andpd  0x10(%rsp),%xmm10
   21dfa:	66 0f 54 64 24 70    	andpd  0x70(%rsp),%xmm4
   21e00:	66 0f 28 c7          	movapd %xmm7,%xmm0
   21e04:	66 41 0f 5c c2       	subpd  %xmm10,%xmm0
   21e09:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   21e0e:	66 0f 5c cc          	subpd  %xmm4,%xmm1
   21e12:	66 0f c2 c2 01       	cmpltpd %xmm2,%xmm0
   21e17:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   21e1c:	66 41 0f 5c ff       	subpd  %xmm15,%xmm7
   21e21:	66 44 0f 5c dd       	subpd  %xmm5,%xmm11
   21e26:	66 44 0f 28 0d f1 33 	movapd -0x1cc0f(%rip),%xmm9        # 5220 <std::thread::current::id::ID+0x45a8>
   21e2d:	fe ff 
   21e2f:	66 41 0f 54 f9       	andpd  %xmm9,%xmm7
   21e34:	66 45 0f 54 d9       	andpd  %xmm9,%xmm11
   21e39:	66 41 0f 58 fa       	addpd  %xmm10,%xmm7
   21e3e:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   21e42:	66 44 0f 58 dc       	addpd  %xmm4,%xmm11
   21e47:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   21e4c:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   21e51:	66 0f 28 05 07 39 fe 	movapd -0x1c6f9(%rip),%xmm0        # 5760 <std::thread::current::id::ID+0x4ae8>
   21e58:	ff 
   21e59:	66 44 0f c2 c8 01    	cmpltpd %xmm0,%xmm9
   21e5f:	66 45 0f 28 eb       	movapd %xmm11,%xmm13
   21e64:	66 44 0f c2 e8 01    	cmpltpd %xmm0,%xmm13
   21e6a:	66 41 0f 54 f9       	andpd  %xmm9,%xmm7
   21e6f:	66 44 0f 29 8c 24 e0 	movapd %xmm9,0xe0(%rsp)
   21e76:	00 00 00 
   21e79:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   21e7d:	66 44 0f 57 ca       	xorpd  %xmm2,%xmm9
   21e82:	66 44 0f 29 4c 24 20 	movapd %xmm9,0x20(%rsp)
   21e89:	66 45 0f 54 dd       	andpd  %xmm13,%xmm11
   21e8e:	66 44 0f 29 ac 24 f0 	movapd %xmm13,0xf0(%rsp)
   21e95:	00 00 00 
   21e98:	66 44 0f 57 ea       	xorpd  %xmm2,%xmm13
   21e9d:	66 44 0f 29 6c 24 10 	movapd %xmm13,0x10(%rsp)
   21ea4:	66 0f 28 9c 24 e0 01 	movapd 0x1e0(%rsp),%xmm3
   21eab:	00 00 
   21ead:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   21eb2:	66 0f 28 94 24 d0 01 	movapd 0x1d0(%rsp),%xmm2
   21eb9:	00 00 
   21ebb:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21ebf:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   21ec3:	66 0f 58 9c 24 c0 01 	addpd  0x1c0(%rsp),%xmm3
   21eca:	00 00 
   21ecc:	66 0f 58 94 24 b0 01 	addpd  0x1b0(%rsp),%xmm2
   21ed3:	00 00 
   21ed5:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   21eda:	66 0f 59 d5          	mulpd  %xmm5,%xmm2
   21ede:	66 0f 58 9c 24 80 00 	addpd  0x80(%rsp),%xmm3
   21ee5:	00 00 
   21ee7:	66 41 0f 58 d6       	addpd  %xmm14,%xmm2
   21eec:	66 0f 28 ac 24 10 01 	movapd 0x110(%rsp),%xmm5
   21ef3:	00 00 
   21ef5:	66 41 0f 59 ef       	mulpd  %xmm15,%xmm5
   21efa:	66 0f 28 a4 24 20 01 	movapd 0x120(%rsp),%xmm4
   21f01:	00 00 
   21f03:	66 0f 59 e0          	mulpd  %xmm0,%xmm4
   21f07:	66 0f 28 b4 24 a0 01 	movapd 0x1a0(%rsp),%xmm6
   21f0e:	00 00 
   21f10:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   21f14:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21f19:	66 44 0f 28 84 24 f0 	movapd 0x1f0(%rsp),%xmm8
   21f20:	01 00 00 
   21f23:	66 41 0f 58 f0       	addpd  %xmm8,%xmm6
   21f28:	66 45 0f 28 d6       	movapd %xmm14,%xmm10
   21f2d:	66 44 0f 28 35 ea 35 	movapd -0x1ca16(%rip),%xmm14        # 5520 <std::thread::current::id::ID+0x48a8>
   21f34:	fe ff 
   21f36:	66 41 0f 59 f6       	mulpd  %xmm14,%xmm6
   21f3b:	66 0f 28 0d dd 32 fe 	movapd -0x1cd23(%rip),%xmm1        # 5220 <std::thread::current::id::ID+0x45a8>
   21f42:	ff 
   21f43:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   21f47:	66 0f 58 de          	addpd  %xmm6,%xmm3
   21f4b:	66 0f 28 b4 24 00 01 	movapd 0x100(%rsp),%xmm6
   21f52:	00 00 
   21f54:	66 0f 58 f4          	addpd  %xmm4,%xmm6
   21f58:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   21f5c:	66 44 0f 28 8c 24 30 	movapd 0x130(%rsp),%xmm9
   21f63:	01 00 00 
   21f66:	66 41 0f 58 f1       	addpd  %xmm9,%xmm6
   21f6b:	66 41 0f 59 f6       	mulpd  %xmm14,%xmm6
   21f70:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   21f74:	66 0f 58 d6          	addpd  %xmm6,%xmm2
   21f78:	66 44 0f 28 ac 24 d0 	movapd 0x2d0(%rsp),%xmm13
   21f7f:	02 00 00 
   21f82:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   21f87:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21f8c:	66 0f 28 8c 24 b0 02 	movapd 0x2b0(%rsp),%xmm1
   21f93:	00 00 
   21f95:	66 0f 58 f1          	addpd  %xmm1,%xmm6
   21f99:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21f9e:	66 41 0f 58 f0       	addpd  %xmm8,%xmm6
   21fa3:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21fa8:	66 0f 58 b4 24 90 02 	addpd  0x290(%rsp),%xmm6
   21faf:	00 00 
   21fb1:	66 41 0f 59 f6       	mulpd  %xmm14,%xmm6
   21fb6:	66 0f 59 df          	mulpd  %xmm7,%xmm3
   21fba:	66 0f 58 de          	addpd  %xmm6,%xmm3
   21fbe:	66 44 0f 28 84 24 c0 	movapd 0x2c0(%rsp),%xmm8
   21fc5:	02 00 00 
   21fc8:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   21fcd:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   21fd1:	66 44 0f 28 a4 24 a0 	movapd 0x2a0(%rsp),%xmm12
   21fd8:	02 00 00 
   21fdb:	66 41 0f 58 f4       	addpd  %xmm12,%xmm6
   21fe0:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   21fe4:	66 41 0f 58 f1       	addpd  %xmm9,%xmm6
   21fe9:	66 45 0f 28 cf       	movapd %xmm15,%xmm9
   21fee:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   21ff2:	66 0f 58 b4 24 80 02 	addpd  0x280(%rsp),%xmm6
   21ff9:	00 00 
   21ffb:	66 41 0f 59 f6       	mulpd  %xmm14,%xmm6
   22000:	66 44 0f 28 f0       	movapd %xmm0,%xmm14
   22005:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
   2200a:	66 0f 58 d6          	addpd  %xmm6,%xmm2
   2200e:	66 0f 58 e9          	addpd  %xmm1,%xmm5
   22012:	66 41 0f 58 e4       	addpd  %xmm12,%xmm4
   22017:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   2201c:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   22020:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   22024:	66 41 0f 28 e8       	movapd %xmm8,%xmm5
   22029:	66 41 0f 59 eb       	mulpd  %xmm11,%xmm5
   2202e:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   22032:	66 44 0f 28 bc 24 f0 	movapd 0x2f0(%rsp),%xmm15
   22039:	02 00 00 
   2203c:	66 41 0f 28 e7       	movapd %xmm15,%xmm4
   22041:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   22046:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   2204a:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   2204e:	66 0f 28 bc 24 60 01 	movapd 0x160(%rsp),%xmm7
   22055:	00 00 
   22057:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   2205b:	66 0f 28 84 24 e0 02 	movapd 0x2e0(%rsp),%xmm0
   22062:	00 00 
   22064:	66 0f 58 e0          	addpd  %xmm0,%xmm4
   22068:	66 0f 58 bc 24 90 01 	addpd  0x190(%rsp),%xmm7
   2206f:	00 00 
   22071:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   22076:	66 41 0f 59 fe       	mulpd  %xmm14,%xmm7
   2207b:	66 0f 58 a4 24 80 00 	addpd  0x80(%rsp),%xmm4
   22082:	00 00 
   22084:	66 41 0f 58 fa       	addpd  %xmm10,%xmm7
   22089:	66 41 0f 59 e1       	mulpd  %xmm9,%xmm4
   2208e:	66 41 0f 59 fe       	mulpd  %xmm14,%xmm7
   22093:	66 0f 58 a4 24 50 01 	addpd  0x150(%rsp),%xmm4
   2209a:	00 00 
   2209c:	66 44 0f 28 a4 24 40 	movapd 0x140(%rsp),%xmm12
   220a3:	01 00 00 
   220a6:	66 41 0f 58 fc       	addpd  %xmm12,%xmm7
   220ab:	66 41 0f 59 eb       	mulpd  %xmm11,%xmm5
   220b0:	66 0f 58 f3          	addpd  %xmm3,%xmm6
   220b4:	66 41 0f 59 eb       	mulpd  %xmm11,%xmm5
   220b9:	66 0f 58 ea          	addpd  %xmm2,%xmm5
   220bd:	66 0f 28 dc          	movapd %xmm4,%xmm3
   220c1:	66 0f 28 0d 57 31 fe 	movapd -0x1cea9(%rip),%xmm1        # 5220 <std::thread::current::id::ID+0x45a8>
   220c8:	ff 
   220c9:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   220cd:	66 44 0f 28 df       	movapd %xmm7,%xmm11
   220d2:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   220d7:	66 0f c2 de 02       	cmplepd %xmm6,%xmm3
   220dc:	66 0f 56 5c 24 20    	orpd   0x20(%rsp),%xmm3
   220e2:	66 44 0f c2 dd 02    	cmplepd %xmm5,%xmm11
   220e8:	66 44 0f 56 5c 24 10 	orpd   0x10(%rsp),%xmm11
   220ef:	66 0f 28 4c 24 30    	movapd 0x30(%rsp),%xmm1
   220f5:	66 44 0f 28 05 62 36 	movapd -0x1c99e(%rip),%xmm8        # 5760 <std::thread::current::id::ID+0x4ae8>
   220fc:	fe ff 
   220fe:	66 41 0f c2 c8 00    	cmpeqpd %xmm8,%xmm1
   22104:	66 0f 28 54 24 40    	movapd 0x40(%rsp),%xmm2
   2210a:	66 41 0f c2 d0 00    	cmpeqpd %xmm8,%xmm2
   22110:	66 44 0f 28 6c 24 50 	movapd 0x50(%rsp),%xmm13
   22117:	66 45 0f c2 e8 00    	cmpeqpd %xmm8,%xmm13
   2211d:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   22122:	66 0f 28 4c 24 60    	movapd 0x60(%rsp),%xmm1
   22128:	66 41 0f c2 c8 00    	cmpeqpd %xmm8,%xmm1
   2212e:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   22132:	66 0f c2 f4 01       	cmpltpd %xmm4,%xmm6
   22137:	66 0f c2 ef 01       	cmpltpd %xmm7,%xmm5
   2213c:	66 0f 28 d3          	movapd %xmm3,%xmm2
   22140:	66 0f 55 d6          	andnpd %xmm6,%xmm2
   22144:	66 41 0f 28 e3       	movapd %xmm11,%xmm4
   22149:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   2214d:	66 44 0f 29 6c 24 10 	movapd %xmm13,0x10(%rsp)
   22154:	66 41 0f 54 d5       	andpd  %xmm13,%xmm2
   22159:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   2215f:	66 0f 54 e1          	andpd  %xmm1,%xmm4
   22163:	66 0f 50 ca          	movmskpd %xmm2,%ecx
   22167:	66 0f 50 f4          	movmskpd %xmm4,%esi
   2216b:	c1 e6 02             	shl    $0x2,%esi
   2216e:	83 e6 04             	and    $0x4,%esi
   22171:	09 ce                	or     %ecx,%esi
   22173:	0f 84 13 f8 ff ff    	je     2198c <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x37c>
   22179:	66 44 0f 29 9c 24 b0 	movapd %xmm11,0xb0(%rsp)
   22180:	00 00 00 
   22183:	66 0f 29 9c 24 c0 00 	movapd %xmm3,0xc0(%rsp)
   2218a:	00 00 
   2218c:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   22191:	66 0f 28 94 24 50 02 	movapd 0x250(%rsp),%xmm2
   22198:	00 00 
   2219a:	66 44 0f 28 d4       	movapd %xmm4,%xmm10
   2219f:	66 0f 28 e2          	movapd %xmm2,%xmm4
   221a3:	66 0f 59 a4 24 70 01 	mulpd  0x170(%rsp),%xmm4
   221aa:	00 00 
   221ac:	66 0f 28 f2          	movapd %xmm2,%xmm6
   221b0:	66 0f 59 b4 24 80 01 	mulpd  0x180(%rsp),%xmm6
   221b7:	00 00 
   221b9:	66 0f 28 0d 7f 36 fe 	movapd -0x1c981(%rip),%xmm1        # 5840 <std::thread::current::id::ID+0x4bc8>
   221c0:	ff 
   221c1:	66 0f 5d e1          	minpd  %xmm1,%xmm4
   221c5:	66 0f 5d f1          	minpd  %xmm1,%xmm6
   221c9:	66 0f 28 ea          	movapd %xmm2,%xmm5
   221cd:	66 44 0f 29 8c 24 d0 	movapd %xmm9,0xd0(%rsp)
   221d4:	00 00 00 
   221d7:	66 41 0f 59 e9       	mulpd  %xmm9,%xmm5
   221dc:	66 0f 5a dc          	cvtpd2ps %xmm4,%xmm3
   221e0:	0f 5a fb             	cvtps2pd %xmm3,%xmm7
   221e3:	66 0f c2 e7 01       	cmpltpd %xmm7,%xmm4
   221e8:	66 0f 5a fe          	cvtpd2ps %xmm6,%xmm7
   221ec:	66 0f 14 df          	unpcklpd %xmm7,%xmm3
   221f0:	0f 5a ff             	cvtps2pd %xmm7,%xmm7
   221f3:	66 0f c2 f7 01       	cmpltpd %xmm7,%xmm6
   221f8:	66 0f 28 fa          	movapd %xmm2,%xmm7
   221fc:	66 44 0f 29 74 24 70 	movapd %xmm14,0x70(%rsp)
   22203:	66 41 0f 59 fe       	mulpd  %xmm14,%xmm7
   22208:	0f c6 e6 88          	shufps $0x88,%xmm6,%xmm4
   2220c:	66 0f 5a f5          	cvtpd2ps %xmm5,%xmm6
   22210:	0f 28 0d 79 32 fe ff 	movaps -0x1cd87(%rip),%xmm1        # 5490 <std::thread::current::id::ID+0x4818>
   22217:	0f 54 e1             	andps  %xmm1,%xmm4
   2221a:	66 0f fa dc          	psubd  %xmm4,%xmm3
   2221e:	44 0f 5a e6          	cvtps2pd %xmm6,%xmm12
   22222:	66 44 0f c2 e5 01    	cmpltpd %xmm5,%xmm12
   22228:	66 0f 5a e7          	cvtpd2ps %xmm7,%xmm4
   2222c:	66 0f 14 f4          	unpcklpd %xmm4,%xmm6
   22230:	0f 5a e4             	cvtps2pd %xmm4,%xmm4
   22233:	66 0f c2 e7 01       	cmpltpd %xmm7,%xmm4
   22238:	44 0f c6 e4 88       	shufps $0x88,%xmm4,%xmm12
   2223d:	44 0f 54 e1          	andps  %xmm1,%xmm12
   22241:	66 44 0f fe e6       	paddd  %xmm6,%xmm12
   22246:	66 44 0f 29 84 24 a0 	movapd %xmm8,0xa0(%rsp)
   2224d:	00 00 00 
   22250:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   22255:	66 44 0f 29 94 24 00 	movapd %xmm10,0x300(%rsp)
   2225c:	03 00 00 
   2225f:	66 41 0f 6b f2       	packssdw %xmm10,%xmm6
   22264:	66 45 0f 6f d4       	movdqa %xmm12,%xmm10
   22269:	66 44 0f fa d3       	psubd  %xmm3,%xmm10
   2226e:	66 45 0f 6f f2       	movdqa %xmm10,%xmm14
   22273:	66 0f 6f 0d 65 35 fe 	movdqa -0x1ca9b(%rip),%xmm1        # 57e0 <std::thread::current::id::ID+0x4b68>
   2227a:	ff 
   2227b:	66 44 0f ef f1       	pxor   %xmm1,%xmm14
   22280:	66 0f 6f 0d 88 33 fe 	movdqa -0x1cc78(%rip),%xmm1        # 5610 <std::thread::current::id::ID+0x4998>
   22287:	ff 
   22288:	66 44 0f 66 f1       	pcmpgtd %xmm1,%xmm14
   2228d:	66 44 0f db f6       	pand   %xmm6,%xmm14
   22292:	41 0f 50 ce          	movmskps %xmm14,%ecx
   22296:	f6 c1 07             	test   $0x7,%cl
   22299:	0f 84 81 f6 ff ff    	je     21920 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x310>
   2229f:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   222a4:	66 0f 6f e3          	movdqa %xmm3,%xmm4
   222a8:	66 44 0f 28 9c 24 50 	movapd 0x150(%rsp),%xmm11
   222af:	01 00 00 
   222b2:	66 0f 28 8c 24 40 01 	movapd 0x140(%rsp),%xmm1
   222b9:	00 00 
   222bb:	66 44 0f 28 8c 24 90 	movapd 0x90(%rsp),%xmm9
   222c2:	00 00 00 
   222c5:	66 0f 28 94 24 60 01 	movapd 0x160(%rsp),%xmm2
   222cc:	00 00 
   222ce:	66 90                	xchg   %ax,%ax
   222d0:	66 41 0f 72 d2 01    	psrld  $0x1,%xmm10
   222d6:	66 44 0f fe d4       	paddd  %xmm4,%xmm10
   222db:	41 0f 5a e2          	cvtps2pd %xmm10,%xmm4
   222df:	66 41 0f 70 ea ee    	pshufd $0xee,%xmm10,%xmm5
   222e5:	0f 5a ed             	cvtps2pd %xmm5,%xmm5
   222e8:	66 41 0f 5e e5       	divpd  %xmm13,%xmm4
   222ed:	66 41 0f 5e ed       	divpd  %xmm13,%xmm5
   222f2:	66 41 0f 28 ff       	movapd %xmm15,%xmm7
   222f7:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   222fb:	66 0f 58 f8          	addpd  %xmm0,%xmm7
   222ff:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   22303:	66 0f 58 bc 24 80 00 	addpd  0x80(%rsp),%xmm7
   2230a:	00 00 
   2230c:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   22310:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   22315:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   2231a:	66 44 0f 58 84 24 90 	addpd  0x190(%rsp),%xmm8
   22321:	01 00 00 
   22324:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   22329:	66 45 0f 58 c1       	addpd  %xmm9,%xmm8
   2232e:	66 44 0f 59 c5       	mulpd  %xmm5,%xmm8
   22333:	66 41 0f 58 fb       	addpd  %xmm11,%xmm7
   22338:	66 44 0f 58 c1       	addpd  %xmm1,%xmm8
   2233d:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   22341:	66 0f c2 e7 01       	cmpltpd %xmm7,%xmm4
   22346:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   2234a:	66 41 0f c2 e8 01    	cmpltpd %xmm8,%xmm5
   22350:	0f c6 e5 88          	shufps $0x88,%xmm5,%xmm4
   22354:	41 0f 28 ee          	movaps %xmm14,%xmm5
   22358:	0f 54 ec             	andps  %xmm4,%xmm5
   2235b:	0f 28 fd             	movaps %xmm5,%xmm7
   2235e:	41 0f 55 ec          	andnps %xmm12,%xmm5
   22362:	41 0f 54 fa          	andps  %xmm10,%xmm7
   22366:	0f 56 ef             	orps   %xmm7,%xmm5
   22369:	41 0f 55 e6          	andnps %xmm14,%xmm4
   2236d:	44 0f 54 d4          	andps  %xmm4,%xmm10
   22371:	0f 55 e3             	andnps %xmm3,%xmm4
   22374:	41 0f 56 e2          	orps   %xmm10,%xmm4
   22378:	44 0f 28 d5          	movaps %xmm5,%xmm10
   2237c:	66 44 0f fa d4       	psubd  %xmm4,%xmm10
   22381:	66 45 0f 6f f2       	movdqa %xmm10,%xmm14
   22386:	66 44 0f ef 35 51 34 	pxor   -0x1cbaf(%rip),%xmm14        # 57e0 <std::thread::current::id::ID+0x4b68>
   2238d:	fe ff 
   2238f:	66 44 0f 66 35 78 32 	pcmpgtd -0x1cd88(%rip),%xmm14        # 5610 <std::thread::current::id::ID+0x4998>
   22396:	fe ff 
   22398:	66 44 0f db f6       	pand   %xmm6,%xmm14
   2239d:	41 0f 50 ce          	movmskps %xmm14,%ecx
   223a1:	0f 28 dc             	movaps %xmm4,%xmm3
   223a4:	44 0f 28 e5          	movaps %xmm5,%xmm12
   223a8:	f6 c1 07             	test   $0x7,%cl
   223ab:	0f 85 1f ff ff ff    	jne    222d0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0xcc0>
   223b1:	e9 6d f5 ff ff       	jmp    21923 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x313>
   223b6:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   223bb:	0f 29 07             	movaps %xmm0,(%rdi)
   223be:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   223c3:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   223c7:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   223cc:	0f 29 47 20          	movaps %xmm0,0x20(%rdi)
   223d0:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   223d5:	0f 29 47 30          	movaps %xmm0,0x30(%rdi)
   223d9:	48 89 ec             	mov    %rbp,%rsp
   223dc:	5d                   	pop    %rbp
   223dd:	c3                   	ret
   223de:	cc                   	int3
   223df:	cc                   	int3

00000000000223e0 <gpui_canvas::color::gamut::in_gamut>:
   223e0:	55                   	push   %rbp
   223e1:	53                   	push   %rbx
   223e2:	48 83 ec 68          	sub    $0x68,%rsp
   223e6:	89 f3                	mov    %esi,%ebx
   223e8:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   223ec:	8b 4f 08             	mov    0x8(%rdi),%ecx
   223ef:	8b 57 0c             	mov    0xc(%rdi),%edx
   223f2:	89 c8                	mov    %ecx,%eax
   223f4:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   223fa:	0f 82 ea 00 00 00    	jb     224ea <gpui_canvas::color::gamut::in_gamut+0x10a>
   22400:	89 c8                	mov    %ecx,%eax
   22402:	85 c9                	test   %ecx,%ecx
   22404:	0f 88 db 00 00 00    	js     224e5 <gpui_canvas::color::gamut::in_gamut+0x105>
   2240a:	c1 e8 08             	shr    $0x8,%eax
   2240d:	89 ce                	mov    %ecx,%esi
   2240f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   22416:	48 c1 ee 2e          	shr    $0x2e,%rsi
   2241a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   22421:	48 c1 ef 20          	shr    $0x20,%rdi
   22425:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   2242a:	45 89 ca             	mov    %r9d,%r10d
   2242d:	41 c1 e2 08          	shl    $0x8,%r10d
   22431:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   22436:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   2243b:	45 89 c3             	mov    %r8d,%r11d
   2243e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   22443:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   22449:	c1 ed 16             	shr    $0x16,%ebp
   2244c:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   22452:	29 ee                	sub    %ebp,%esi
   22454:	44 89 dd             	mov    %r11d,%ebp
   22457:	c1 e5 08             	shl    $0x8,%ebp
   2245a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   22461:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   22468:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   2246e:	44 09 dd             	or     %r11d,%ebp
   22471:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   22478:	45 09 d1             	or     %r10d,%r9d
   2247b:	c1 e6 17             	shl    $0x17,%esi
   2247e:	09 ee                	or     %ebp,%esi
   22480:	c1 e7 0f             	shl    $0xf,%edi
   22483:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   22489:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   2248e:	44 09 cf             	or     %r9d,%edi
   22491:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   22498:	49 c1 e9 20          	shr    $0x20,%r9
   2249c:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   224a3:	44 29 c8             	sub    %r9d,%eax
   224a6:	45 89 c1             	mov    %r8d,%r9d
   224a9:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   224b0:	41 c1 e0 08          	shl    $0x8,%r8d
   224b4:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   224bb:	45 09 c8             	or     %r9d,%r8d
   224be:	c1 e0 17             	shl    $0x17,%eax
   224c1:	44 09 c0             	or     %r8d,%eax
   224c4:	66 0f 6e c6          	movd   %esi,%xmm0
   224c8:	66 0f 6e cf          	movd   %edi,%xmm1
   224cc:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   224d0:	c1 ea 1e             	shr    $0x1e,%edx
   224d3:	31 ed                	xor    %ebp,%ebp
   224d5:	48 8d 35 08 51 fe ff 	lea    -0x1aef8(%rip),%rsi        # 75e4 <std::thread::current::id::ID+0x696c>
   224dc:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   224e0:	48 01 f2             	add    %rsi,%rdx
   224e3:	ff e2                	jmp    *%rdx
   224e5:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   224ea:	c1 ea 1e             	shr    $0x1e,%edx
   224ed:	31 ed                	xor    %ebp,%ebp
   224ef:	48 8d 35 ee 50 fe ff 	lea    -0x1af12(%rip),%rsi        # 75e4 <std::thread::current::id::ID+0x696c>
   224f6:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   224fa:	48 01 f2             	add    %rsi,%rdx
   224fd:	ff e2                	jmp    *%rdx
   224ff:	40 b5 01             	mov    $0x1,%bpl
   22502:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   22506:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   2250b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   2250f:	66 0f 6e d0          	movd   %eax,%xmm2
   22513:	0f 28 05 06 2d fe ff 	movaps -0x1d2fa(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   2251a:	0f 54 c5             	andps  %xmm5,%xmm0
   2251d:	f2 0f 10 1d 03 4d fe 	movsd  -0x1b2fd(%rip),%xmm3        # 7228 <std::thread::current::id::ID+0x65b0>
   22524:	ff 
   22525:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22529:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   2252f:	73 53                	jae    22584 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   22531:	0f 2e c9             	ucomiss %xmm1,%xmm1
   22534:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22539:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   2253e:	7a 4e                	jp     2258e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   22540:	0f 54 2d 59 32 fe ff 	andps  -0x1cda7(%rip),%xmm5        # 57a0 <std::thread::current::id::ID+0x4b28>
   22547:	0f 56 2d 62 31 fe ff 	orps   -0x1ce9e(%rip),%xmm5        # 56b0 <std::thread::current::id::ID+0x4a38>
   2254e:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   22552:	eb 46                	jmp    2259a <gpui_canvas::color::gamut::in_gamut+0x1ba>
   22554:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   22557:	66 0f 6e c0          	movd   %eax,%xmm0
   2255b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2255f:	e9 ad 01 00 00       	jmp    22711 <gpui_canvas::color::gamut::in_gamut+0x331>
   22564:	85 c9                	test   %ecx,%ecx
   22566:	0f 88 86 02 00 00    	js     227f2 <gpui_canvas::color::gamut::in_gamut+0x412>
   2256c:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   2256f:	66 0f 6e c0          	movd   %eax,%xmm0
   22573:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22577:	84 db                	test   %bl,%bl
   22579:	0f 84 5e 02 00 00    	je     227dd <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2257f:	e9 a7 02 00 00       	jmp    2282b <gpui_canvas::color::gamut::in_gamut+0x44b>
   22584:	f2 0f 5e 2d 04 4c fe 	divsd  -0x1b3fc(%rip),%xmm5        # 7190 <std::thread::current::id::ID+0x6518>
   2258b:	ff 
   2258c:	eb 4b                	jmp    225d9 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   2258e:	f2 0f 10 0d 52 4d fe 	movsd  -0x1b2ae(%rip),%xmm1        # 72e8 <std::thread::current::id::ID+0x6670>
   22595:	ff 
   22596:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2259a:	f2 0f 58 05 0e 4e fe 	addsd  -0x1b1f2(%rip),%xmm0        # 73b0 <std::thread::current::id::ID+0x6738>
   225a1:	ff 
   225a2:	f2 0f 5e 05 5e 4d fe 	divsd  -0x1b2a2(%rip),%xmm0        # 7308 <std::thread::current::id::ID+0x6690>
   225a9:	ff 
   225aa:	f2 0f 10 0d ee 4c fe 	movsd  -0x1b312(%rip),%xmm1        # 72a0 <std::thread::current::id::ID+0x6628>
   225b1:	ff 
   225b2:	ff 15 e0 2d 04 00    	call   *0x42de0(%rip)        # 65398 <pow@GLIBC_2.29>
   225b8:	66 0f 28 e8          	movapd %xmm0,%xmm5
   225bc:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   225c1:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   225c7:	f2 0f 10 1d 59 4c fe 	movsd  -0x1b3a7(%rip),%xmm3        # 7228 <std::thread::current::id::ID+0x65b0>
   225ce:	ff 
   225cf:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   225d4:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   225d9:	0f 57 c9             	xorps  %xmm1,%xmm1
   225dc:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   225e0:	0f 28 05 39 2c fe ff 	movaps -0x1d3c7(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   225e7:	0f 54 c4             	andps  %xmm4,%xmm0
   225ea:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   225ee:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   225f3:	73 1f                	jae    22614 <gpui_canvas::color::gamut::in_gamut+0x234>
   225f5:	0f 2e f6             	ucomiss %xmm6,%xmm6
   225f8:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   225fd:	7a 4b                	jp     2264a <gpui_canvas::color::gamut::in_gamut+0x26a>
   225ff:	0f 54 25 9a 31 fe ff 	andps  -0x1ce66(%rip),%xmm4        # 57a0 <std::thread::current::id::ID+0x4b28>
   22606:	0f 56 25 a3 30 fe ff 	orps   -0x1cf5d(%rip),%xmm4        # 56b0 <std::thread::current::id::ID+0x4a38>
   2260d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22612:	eb 43                	jmp    22657 <gpui_canvas::color::gamut::in_gamut+0x277>
   22614:	f2 0f 5e 25 74 4b fe 	divsd  -0x1b48c(%rip),%xmm4        # 7190 <std::thread::current::id::ID+0x6518>
   2261b:	ff 
   2261c:	0f 28 05 fd 2b fe ff 	movaps -0x1d403(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22623:	0f 54 c1             	andps  %xmm1,%xmm0
   22626:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2262a:	72 7e                	jb     226aa <gpui_canvas::color::gamut::in_gamut+0x2ca>
   2262c:	f2 0f 5e 0d 5c 4b fe 	divsd  -0x1b4a4(%rip),%xmm1        # 7190 <std::thread::current::id::ID+0x6518>
   22633:	ff 
   22634:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22638:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   2263c:	40 84 ed             	test   %bpl,%bpl
   2263f:	0f 85 cc 00 00 00    	jne    22711 <gpui_canvas::color::gamut::in_gamut+0x331>
   22645:	e9 8f 01 00 00       	jmp    227d9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   2264a:	f2 0f 10 0d 96 4c fe 	movsd  -0x1b36a(%rip),%xmm1        # 72e8 <std::thread::current::id::ID+0x6670>
   22651:	ff 
   22652:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   22657:	f2 0f 58 05 51 4d fe 	addsd  -0x1b2af(%rip),%xmm0        # 73b0 <std::thread::current::id::ID+0x6738>
   2265e:	ff 
   2265f:	f2 0f 5e 05 a1 4c fe 	divsd  -0x1b35f(%rip),%xmm0        # 7308 <std::thread::current::id::ID+0x6690>
   22666:	ff 
   22667:	f2 0f 10 0d 31 4c fe 	movsd  -0x1b3cf(%rip),%xmm1        # 72a0 <std::thread::current::id::ID+0x6628>
   2266e:	ff 
   2266f:	ff 15 23 2d 04 00    	call   *0x42d23(%rip)        # 65398 <pow@GLIBC_2.29>
   22675:	66 0f 28 e0          	movapd %xmm0,%xmm4
   22679:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   2267f:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   22684:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   2268a:	f2 0f 10 1d 96 4b fe 	movsd  -0x1b46a(%rip),%xmm3        # 7228 <std::thread::current::id::ID+0x65b0>
   22691:	ff 
   22692:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   22698:	66 0f 28 05 80 2b fe 	movapd -0x1d480(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   2269f:	ff 
   226a0:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   226a4:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   226a8:	73 82                	jae    2262c <gpui_canvas::color::gamut::in_gamut+0x24c>
   226aa:	0f 2e d2             	ucomiss %xmm2,%xmm2
   226ad:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   226b3:	7a 12                	jp     226c7 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   226b5:	66 0f 54 0d e3 30 fe 	andpd  -0x1cf1d(%rip),%xmm1        # 57a0 <std::thread::current::id::ID+0x4b28>
   226bc:	ff 
   226bd:	66 0f 56 0d eb 2f fe 	orpd   -0x1d015(%rip),%xmm1        # 56b0 <std::thread::current::id::ID+0x4a38>
   226c4:	ff 
   226c5:	eb 08                	jmp    226cf <gpui_canvas::color::gamut::in_gamut+0x2ef>
   226c7:	f2 0f 10 0d 19 4c fe 	movsd  -0x1b3e7(%rip),%xmm1        # 72e8 <std::thread::current::id::ID+0x6670>
   226ce:	ff 
   226cf:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   226d5:	f2 0f 58 05 d3 4c fe 	addsd  -0x1b32d(%rip),%xmm0        # 73b0 <std::thread::current::id::ID+0x6738>
   226dc:	ff 
   226dd:	f2 0f 5e 05 23 4c fe 	divsd  -0x1b3dd(%rip),%xmm0        # 7308 <std::thread::current::id::ID+0x6690>
   226e4:	ff 
   226e5:	f2 0f 10 0d b3 4b fe 	movsd  -0x1b44d(%rip),%xmm1        # 72a0 <std::thread::current::id::ID+0x6628>
   226ec:	ff 
   226ed:	ff 15 a5 2c 04 00    	call   *0x42ca5(%rip)        # 65398 <pow@GLIBC_2.29>
   226f3:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   226f9:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   226fe:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   22704:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22708:	40 84 ed             	test   %bpl,%bpl
   2270b:	0f 84 c8 00 00 00    	je     227d9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22711:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22715:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   2271a:	66 0f 59 15 ae 2f fe 	mulpd  -0x1d052(%rip),%xmm2        # 56d0 <std::thread::current::id::ID+0x4a58>
   22721:	ff 
   22722:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   22726:	66 0f 16 1d 5a 4c fe 	movhpd -0x1b3a6(%rip),%xmm3        # 7388 <std::thread::current::id::ID+0x6710>
   2272d:	ff 
   2272e:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   22732:	0f 28 c8             	movaps %xmm0,%xmm1
   22735:	0f 16 c8             	movlhps %xmm0,%xmm1
   22738:	66 0f 59 0d 00 2b fe 	mulpd  -0x1d500(%rip),%xmm1        # 5240 <std::thread::current::id::ID+0x45c8>
   2273f:	ff 
   22740:	66 0f 58 da          	addpd  %xmm2,%xmm3
   22744:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22748:	f2 0f 10 15 98 4a fe 	movsd  -0x1b568(%rip),%xmm2        # 71e8 <std::thread::current::id::ID+0x6570>
   2274f:	ff 
   22750:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   22754:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22758:	66 0f 59 2d 00 2b fe 	mulpd  -0x1d500(%rip),%xmm5        # 5260 <std::thread::current::id::ID+0x45e8>
   2275f:	ff 
   22760:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22764:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22768:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   2276c:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22770:	f2 0f 10 15 30 4a fe 	movsd  -0x1b5d0(%rip),%xmm2        # 71a8 <std::thread::current::id::ID+0x6530>
   22777:	ff 
   22778:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2277c:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   22780:	66 0f 59 1d d8 2d fe 	mulpd  -0x1d228(%rip),%xmm3        # 5560 <std::thread::current::id::ID+0x48e8>
   22787:	ff 
   22788:	66 0f 28 e1          	movapd %xmm1,%xmm4
   2278c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   22791:	66 0f 59 25 e7 2c fe 	mulpd  -0x1d319(%rip),%xmm4        # 5480 <std::thread::current::id::ID+0x4808>
   22798:	ff 
   22799:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   2279d:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   227a1:	66 0f 28 e9          	movapd %xmm1,%xmm5
   227a5:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   227a9:	66 0f 59 2d ff 2f fe 	mulpd  -0x1d001(%rip),%xmm5        # 57b0 <std::thread::current::id::ID+0x4b38>
   227b0:	ff 
   227b1:	66 0f 28 c4          	movapd %xmm4,%xmm0
   227b5:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   227b9:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   227bd:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   227c1:	66 0f 59 0d 77 2d fe 	mulpd  -0x1d289(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   227c8:	ff 
   227c9:	66 0f 28 c1          	movapd %xmm1,%xmm0
   227cd:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   227d1:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   227d5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   227d9:	84 db                	test   %bl,%bl
   227db:	75 4e                	jne    2282b <gpui_canvas::color::gamut::in_gamut+0x44b>
   227dd:	31 c0                	xor    %eax,%eax
   227df:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   227e3:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   227e7:	0f 83 08 01 00 00    	jae    228f5 <gpui_canvas::color::gamut::in_gamut+0x515>
   227ed:	e9 41 01 00 00       	jmp    22933 <gpui_canvas::color::gamut::in_gamut+0x553>
   227f2:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   227f6:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   227fa:	66 0f ef c0          	pxor   %xmm0,%xmm0
   227fe:	0f 2e c8             	ucomiss %xmm0,%xmm1
   22801:	0f 85 35 01 00 00    	jne    2293c <gpui_canvas::color::gamut::in_gamut+0x55c>
   22807:	0f 8a 2f 01 00 00    	jp     2293c <gpui_canvas::color::gamut::in_gamut+0x55c>
   2280d:	0f 57 c9             	xorps  %xmm1,%xmm1
   22810:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22814:	0f 28 c1             	movaps %xmm1,%xmm0
   22817:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2281b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2281f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22823:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22827:	84 db                	test   %bl,%bl
   22829:	74 b2                	je     227dd <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2282b:	66 0f 28 0d ad 2a fe 	movapd -0x1d553(%rip),%xmm1        # 52e0 <std::thread::current::id::ID+0x4668>
   22832:	ff 
   22833:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   22837:	66 0f 28 d5          	movapd %xmm5,%xmm2
   2283b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22840:	66 0f 59 15 e8 2e fe 	mulpd  -0x1d118(%rip),%xmm2        # 5730 <std::thread::current::id::ID+0x4ab8>
   22847:	ff 
   22848:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   2284c:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22850:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   22854:	66 0f 59 0d 24 2b fe 	mulpd  -0x1d4dc(%rip),%xmm1        # 5380 <std::thread::current::id::ID+0x4708>
   2285b:	ff 
   2285c:	f2 0f 10 1d d4 49 fe 	movsd  -0x1b62c(%rip),%xmm3        # 7238 <std::thread::current::id::ID+0x65c0>
   22863:	ff 
   22864:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   22868:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   2286c:	66 0f 59 2d 1c 2b fe 	mulpd  -0x1d4e4(%rip),%xmm5        # 5390 <std::thread::current::id::ID+0x4718>
   22873:	ff 
   22874:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   22878:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2287c:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22880:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   22884:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22888:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   2288d:	66 0f 59 15 bb 29 fe 	mulpd  -0x1d645(%rip),%xmm2        # 5250 <std::thread::current::id::ID+0x45d8>
   22894:	ff 
   22895:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22899:	66 0f 28 1d 1f 2a fe 	movapd -0x1d5e1(%rip),%xmm3        # 52c0 <std::thread::current::id::ID+0x4648>
   228a0:	ff 
   228a1:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   228a5:	66 0f 5c da          	subpd  %xmm2,%xmm3
   228a9:	66 0f 28 e8          	movapd %xmm0,%xmm5
   228ad:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   228b1:	66 0f 59 2d b7 2a fe 	mulpd  -0x1d549(%rip),%xmm5        # 5370 <std::thread::current::id::ID+0x46f8>
   228b8:	ff 
   228b9:	66 0f 28 d3          	movapd %xmm3,%xmm2
   228bd:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   228c1:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   228c5:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   228c9:	66 0f 59 0d 2f 2d fe 	mulpd  -0x1d2d1(%rip),%xmm1        # 5600 <std::thread::current::id::ID+0x4988>
   228d0:	ff 
   228d1:	66 0f 28 d1          	movapd %xmm1,%xmm2
   228d5:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   228d9:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   228dd:	f2 0f 59 05 fb 49 fe 	mulsd  -0x1b605(%rip),%xmm0        # 72e0 <std::thread::current::id::ID+0x6668>
   228e4:	ff 
   228e5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   228e9:	31 c0                	xor    %eax,%eax
   228eb:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   228ef:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   228f3:	72 3e                	jb     22933 <gpui_canvas::color::gamut::in_gamut+0x553>
   228f5:	f2 0f 10 0d 53 49 fe 	movsd  -0x1b6ad(%rip),%xmm1        # 7250 <std::thread::current::id::ID+0x65d8>
   228fc:	ff 
   228fd:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22901:	72 30                	jb     22933 <gpui_canvas::color::gamut::in_gamut+0x553>
   22903:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   22907:	31 c0                	xor    %eax,%eax
   22909:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2290d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   22911:	72 20                	jb     22933 <gpui_canvas::color::gamut::in_gamut+0x553>
   22913:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22917:	72 1a                	jb     22933 <gpui_canvas::color::gamut::in_gamut+0x553>
   22919:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2291d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   22922:	f2 0f c2 05 25 49 fe 	cmplesd -0x1b6db(%rip),%xmm0        # 7250 <std::thread::current::id::ID+0x65d8>
   22929:	ff 02 
   2292b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2292f:	66 0f 7e c0          	movd   %xmm0,%eax
   22933:	24 01                	and    $0x1,%al
   22935:	48 83 c4 68          	add    $0x68,%rsp
   22939:	5b                   	pop    %rbx
   2293a:	5d                   	pop    %rbp
   2293b:	c3                   	ret
   2293c:	66 0f 6e c0          	movd   %eax,%xmm0
   22940:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22944:	f2 0f 59 05 34 4a fe 	mulsd  -0x1b5cc(%rip),%xmm0        # 7380 <std::thread::current::id::ID+0x6708>
   2294b:	ff 
   2294c:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   22951:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   22956:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2295a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   22960:	ff 15 5a 2a 04 00    	call   *0x42a5a(%rip)        # 653c0 <sincos@GLIBC_2.2.5>
   22966:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   2296b:	0f 57 c9             	xorps  %xmm1,%xmm1
   2296e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   22972:	0f 28 04 24          	movaps (%rsp),%xmm0
   22976:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2297a:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   22980:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22984:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   2298a:	f2 0f 10 1d c6 49 fe 	movsd  -0x1b63a(%rip),%xmm3        # 7358 <std::thread::current::id::ID+0x66e0>
   22991:	ff 
   22992:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22996:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   2299a:	f2 0f 10 2d 4e 49 fe 	movsd  -0x1b6b2(%rip),%xmm5        # 72f0 <std::thread::current::id::ID+0x6678>
   229a1:	ff 
   229a2:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   229a6:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   229aa:	f2 0f 10 1d fe 48 fe 	movsd  -0x1b702(%rip),%xmm3        # 72b0 <std::thread::current::id::ID+0x6638>
   229b1:	ff 
   229b2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   229b6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   229ba:	f2 0f 10 35 f6 49 fe 	movsd  -0x1b60a(%rip),%xmm6        # 73b8 <std::thread::current::id::ID+0x6740>
   229c1:	ff 
   229c2:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   229c6:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   229ca:	f2 0f 59 15 6e 49 fe 	mulsd  -0x1b692(%rip),%xmm2        # 7340 <std::thread::current::id::ID+0x66c8>
   229d1:	ff 
   229d2:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   229d6:	f2 0f 59 05 ba 47 fe 	mulsd  -0x1b846(%rip),%xmm0        # 7198 <std::thread::current::id::ID+0x6520>
   229dd:	ff 
   229de:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   229e2:	66 0f 28 e5          	movapd %xmm5,%xmm4
   229e6:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   229ea:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   229ee:	66 0f 28 de          	movapd %xmm6,%xmm3
   229f2:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   229f6:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   229fa:	66 0f 28 c8          	movapd %xmm0,%xmm1
   229fe:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22a02:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22a06:	f2 0f 10 05 b2 49 fe 	movsd  -0x1b64e(%rip),%xmm0        # 73c0 <std::thread::current::id::ID+0x6748>
   22a0d:	ff 
   22a0e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   22a12:	f2 0f 10 15 4e 48 fe 	movsd  -0x1b7b2(%rip),%xmm2        # 7268 <std::thread::current::id::ID+0x65f0>
   22a19:	ff 
   22a1a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   22a1e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   22a22:	f2 0f 10 05 46 48 fe 	movsd  -0x1b7ba(%rip),%xmm0        # 7270 <std::thread::current::id::ID+0x65f8>
   22a29:	ff 
   22a2a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22a2e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22a32:	f2 0f 10 15 6e 47 fe 	movsd  -0x1b892(%rip),%xmm2        # 71a8 <std::thread::current::id::ID+0x6530>
   22a39:	ff 
   22a3a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   22a3e:	66 0f 59 25 2a 2d fe 	mulpd  -0x1d2d6(%rip),%xmm4        # 5770 <std::thread::current::id::ID+0x4af8>
   22a45:	ff 
   22a46:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   22a4a:	66 0f 59 1d 2e 2d fe 	mulpd  -0x1d2d2(%rip),%xmm3        # 5780 <std::thread::current::id::ID+0x4b08>
   22a51:	ff 
   22a52:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   22a56:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   22a5a:	66 0f 59 0d ce 2a fe 	mulpd  -0x1d532(%rip),%xmm1        # 5530 <std::thread::current::id::ID+0x48b8>
   22a61:	ff 
   22a62:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22a66:	e9 0d fd ff ff       	jmp    22778 <gpui_canvas::color::gamut::in_gamut+0x398>
