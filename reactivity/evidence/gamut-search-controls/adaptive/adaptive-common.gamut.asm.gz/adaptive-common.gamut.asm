000000000001f650 <<gpui_canvas::color::OutputProfile>::max_chroma>:
   1f650:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f654:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f65a:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f65f:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f665:	7f 38                	jg     1f69f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f667:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f66a:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f66d:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f672:	0f 28 d8             	movaps %xmm0,%xmm3
   1f675:	f3 0f c2 1d 1a 62 fe 	cmpnless -0x19de6(%rip),%xmm3        # 5898 <std::thread::current::id::ID+0x4c20>
   1f67c:	ff 06 
   1f67e:	0f 56 da             	orps   %xmm2,%xmm3
   1f681:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f685:	66 0f 7e ca          	movd   %xmm1,%edx
   1f689:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f68f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f695:	0f 9d c2             	setge  %dl
   1f698:	08 ca                	or     %cl,%dl
   1f69a:	f6 c2 01             	test   $0x1,%dl
   1f69d:	74 01                	je     1f6a0 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f69f:	c3                   	ret
   1f6a0:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f6a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f6a8:	75 02                	jne    1f6ac <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f6aa:	7b f3                	jnp    1f69f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f6ac:	0f 2e 05 e5 61 fe ff 	ucomiss -0x19e1b(%rip),%xmm0        # 5898 <std::thread::current::id::ID+0x4c20>
   1f6b3:	75 02                	jne    1f6b7 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f6b5:	7b e8                	jnp    1f69f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f6b7:	53                   	push   %rbx
   1f6b8:	48 83 ec 10          	sub    $0x10,%rsp
   1f6bc:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f6c2:	89 fb                	mov    %edi,%ebx
   1f6c4:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f6c7:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f6cb:	f2 0f 10 0d bd 7c fe 	movsd  -0x18343(%rip),%xmm1        # 7390 <std::thread::current::id::ID+0x6718>
   1f6d2:	ff 
   1f6d3:	ff 15 f7 5c 04 00    	call   *0x45cf7(%rip)        # 653d0 <_DYNAMIC+0x378>
   1f6d9:	f2 0f 10 1d af 7c fe 	movsd  -0x18351(%rip),%xmm3        # 7390 <std::thread::current::id::ID+0x6718>
   1f6e0:	ff 
   1f6e1:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f6e5:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f6e9:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f6ed:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f6f2:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f6f6:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f6fa:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f6fe:	66 0f 2e 15 c2 7b fe 	ucomisd -0x1843e(%rip),%xmm2        # 72c8 <std::thread::current::id::ID+0x6650>
   1f705:	ff 
   1f706:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f70a:	73 0f                	jae    1f71b <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f70c:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f70f:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f713:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f718:	0f 55 c8             	andnps %xmm0,%xmm1
   1f71b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f721:	0f b6 fb             	movzbl %bl,%edi
   1f724:	48 83 c4 10          	add    $0x10,%rsp
   1f728:	5b                   	pop    %rbx
   1f729:	e9 f2 11 00 00       	jmp    20920 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   1f72e:	cc                   	int3
   1f72f:	cc                   	int3

0000000000020260 <<gpui_canvas::color::Color>::fit_chroma>:
   20260:	55                   	push   %rbp
   20261:	41 57                	push   %r15
   20263:	41 56                	push   %r14
   20265:	41 54                	push   %r12
   20267:	53                   	push   %rbx
   20268:	48 83 ec 30          	sub    $0x30,%rsp
   2026c:	48 89 fb             	mov    %rdi,%rbx
   2026f:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   20273:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   20277:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   2027e:	0f 92 c0             	setb   %al
   20281:	45 85 e4             	test   %r12d,%r12d
   20284:	0f 99 c1             	setns  %cl
   20287:	08 c1                	or     %al,%cl
   20289:	74 09                	je     20294 <<gpui_canvas::color::Color>::fit_chroma+0x34>
   2028b:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   20292:	eb 4a                	jmp    202de <<gpui_canvas::color::Color>::fit_chroma+0x7e>
   20294:	49 89 f6             	mov    %rsi,%r14
   20297:	0f 10 06             	movups (%rsi),%xmm0
   2029a:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   2029f:	0f b6 ea             	movzbl %dl,%ebp
   202a2:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   202a7:	89 ee                	mov    %ebp,%esi
   202a9:	e8 72 21 00 00       	call   22420 <gpui_canvas::color::gamut::in_gamut>
   202ae:	84 c0                	test   %al,%al
   202b0:	74 0c                	je     202be <<gpui_canvas::color::Color>::fit_chroma+0x5e>
   202b2:	41 0f 10 06          	movups (%r14),%xmm0
   202b6:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   202ba:	31 c0                	xor    %eax,%eax
   202bc:	eb 25                	jmp    202e3 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   202be:	41 8b 16             	mov    (%r14),%edx
   202c1:	89 d6                	mov    %edx,%esi
   202c3:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   202c9:	b8 0d 00 00 00       	mov    $0xd,%eax
   202ce:	31 c9                	xor    %ecx,%ecx
   202d0:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   202d6:	7e 1d                	jle    202f5 <<gpui_canvas::color::Color>::fit_chroma+0x95>
   202d8:	89 43 04             	mov    %eax,0x4(%rbx)
   202db:	89 4b 08             	mov    %ecx,0x8(%rbx)
   202de:	b8 01 00 00 00       	mov    $0x1,%eax
   202e3:	89 03                	mov    %eax,(%rbx)
   202e5:	48 89 d8             	mov    %rbx,%rax
   202e8:	48 83 c4 30          	add    $0x30,%rsp
   202ec:	5b                   	pop    %rbx
   202ed:	41 5c                	pop    %r12
   202ef:	41 5e                	pop    %r14
   202f1:	41 5f                	pop    %r15
   202f3:	5d                   	pop    %rbp
   202f4:	c3                   	ret
   202f5:	44 89 e6             	mov    %r12d,%esi
   202f8:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   202fe:	66 0f 6e c6          	movd   %esi,%xmm0
   20302:	0f 2e 05 c7 55 fe ff 	ucomiss -0x1aa39(%rip),%xmm0        # 58d0 <std::thread::current::id::ID+0x4c58>
   20309:	74 cd                	je     202d8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   2030b:	66 0f 6e d2          	movd   %edx,%xmm2
   2030f:	0f 57 c9             	xorps  %xmm1,%xmm1
   20312:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20315:	72 c1                	jb     202d8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   20317:	f3 0f 10 0d 79 55 fe 	movss  -0x1aa87(%rip),%xmm1        # 5898 <std::thread::current::id::ID+0x4c20>
   2031e:	ff 
   2031f:	0f 2e ca             	ucomiss %xmm2,%xmm1
   20322:	72 b4                	jb     202d8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   20324:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   2032a:	31 c9                	xor    %ecx,%ecx
   2032c:	0f 57 c9             	xorps  %xmm1,%xmm1
   2032f:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20332:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   20338:	75 02                	jne    2033c <<gpui_canvas::color::Color>::fit_chroma+0xdc>
   2033a:	7b 63                	jnp    2039f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   2033c:	0f 2e 15 55 55 fe ff 	ucomiss -0x1aaab(%rip),%xmm2        # 5898 <std::thread::current::id::ID+0x4c20>
   20343:	75 02                	jne    20347 <<gpui_canvas::color::Color>::fit_chroma+0xe7>
   20345:	7b 58                	jnp    2039f <<gpui_canvas::color::Color>::fit_chroma+0x13f>
   20347:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   2034c:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   20350:	f2 0f 10 0d 38 70 fe 	movsd  -0x18fc8(%rip),%xmm1        # 7390 <std::thread::current::id::ID+0x6718>
   20357:	ff 
   20358:	ff 15 72 50 04 00    	call   *0x45072(%rip)        # 653d0 <_DYNAMIC+0x378>
   2035e:	66 0f 2e 05 62 6f fe 	ucomisd -0x1909e(%rip),%xmm0        # 72c8 <std::thread::current::id::ID+0x6650>
   20365:	ff 
   20366:	0f 57 c9             	xorps  %xmm1,%xmm1
   20369:	73 0c                	jae    20377 <<gpui_canvas::color::Color>::fit_chroma+0x117>
   2036b:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   2036f:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   20374:	0f 55 c8             	andnps %xmm0,%xmm1
   20377:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   2037d:	89 ef                	mov    %ebp,%edi
   2037f:	e8 9c 05 00 00       	call   20920 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>
   20384:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   2038a:	48 89 c1             	mov    %rax,%rcx
   2038d:	48 c1 e9 20          	shr    $0x20,%rcx
   20391:	83 f8 ff             	cmp    $0xffffffff,%eax
   20394:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   20399:	0f 85 39 ff ff ff    	jne    202d8 <<gpui_canvas::color::Color>::fit_chroma+0x78>
   2039f:	66 0f 6e c1          	movd   %ecx,%xmm0
   203a3:	0f 28 cb             	movaps %xmm3,%xmm1
   203a6:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   203aa:	0f 28 e1             	movaps %xmm1,%xmm4
   203ad:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   203b2:	0f 28 c4             	movaps %xmm4,%xmm0
   203b5:	0f 55 c1             	andnps %xmm1,%xmm0
   203b8:	0f 54 e3             	andps  %xmm3,%xmm4
   203bb:	0f 56 e0             	orps   %xmm0,%xmm4
   203be:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   203c4:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   203c9:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   203cf:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   203d4:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   203d9:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   203de:	89 ee                	mov    %ebp,%esi
   203e0:	e8 3b 20 00 00       	call   22420 <gpui_canvas::color::gamut::in_gamut>
   203e5:	84 c0                	test   %al,%al
   203e7:	74 1c                	je     20405 <<gpui_canvas::color::Color>::fit_chroma+0x1a5>
   203e9:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   203ee:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   203f3:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   203f7:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   203fb:	31 c0                	xor    %eax,%eax
   203fd:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   20403:	eb 0d                	jmp    20412 <<gpui_canvas::color::Color>::fit_chroma+0x1b2>
   20405:	b8 01 00 00 00       	mov    $0x1,%eax
   2040a:	f3 0f 10 05 7e 54 fe 	movss  -0x1ab82(%rip),%xmm0        # 5890 <std::thread::current::id::ID+0x4c18>
   20411:	ff 
   20412:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   20417:	e9 c7 fe ff ff       	jmp    202e3 <<gpui_canvas::color::Color>::fit_chroma+0x83>
   2041c:	cc                   	int3
   2041d:	cc                   	int3
   2041e:	cc                   	int3
   2041f:	cc                   	int3

0000000000020920 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>>:
   20920:	55                   	push   %rbp
   20921:	48 89 e5             	mov    %rsp,%rbp
   20924:	41 57                	push   %r15
   20926:	41 56                	push   %r14
   20928:	41 55                	push   %r13
   2092a:	41 54                	push   %r12
   2092c:	53                   	push   %rbx
   2092d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20931:	48 81 ec a0 02 00 00 	sub    $0x2a0,%rsp
   20938:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   2093e:	89 fb                	mov    %edi,%ebx
   20940:	0f 29 8c 24 d0 00 00 	movaps %xmm1,0xd0(%rsp)
   20947:	00 
   20948:	0f 57 c0             	xorps  %xmm0,%xmm0
   2094b:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   2094f:	f2 0f 59 05 19 6a fe 	mulsd  -0x195e7(%rip),%xmm0        # 7370 <std::thread::current::id::ID+0x66f8>
   20956:	ff 
   20957:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
   2095e:	00 
   2095f:	48 8d b4 24 10 01 00 	lea    0x110(%rsp),%rsi
   20966:	00 
   20967:	ff 15 93 4a 04 00    	call   *0x44a93(%rip)        # 65400 <sincos@GLIBC_2.2.5>
   2096d:	f2 0f 10 ac 24 18 01 	movsd  0x118(%rsp),%xmm5
   20974:	00 00 
   20976:	f2 0f 10 84 24 10 01 	movsd  0x110(%rsp),%xmm0
   2097d:	00 00 
   2097f:	f2 0f 10 0d c1 69 fe 	movsd  -0x1963f(%rip),%xmm1        # 7348 <std::thread::current::id::ID+0x66d0>
   20986:	ff 
   20987:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   2098b:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2098f:	f2 0f 58 ca          	addsd  %xmm2,%xmm1
   20993:	f2 0f 10 1d 05 69 fe 	movsd  -0x196fb(%rip),%xmm3        # 72a0 <std::thread::current::id::ID+0x6628>
   2099a:	ff 
   2099b:	f2 0f 59 d8          	mulsd  %xmm0,%xmm3
   2099f:	f2 0f 58 da          	addsd  %xmm2,%xmm3
   209a3:	f2 0f 10 35 35 69 fe 	movsd  -0x196cb(%rip),%xmm6        # 72e0 <std::thread::current::id::ID+0x6668>
   209aa:	ff 
   209ab:	f2 0f 59 f5          	mulsd  %xmm5,%xmm6
   209af:	f2 0f 58 f1          	addsd  %xmm1,%xmm6
   209b3:	f2 0f 10 3d ed 69 fe 	movsd  -0x19613(%rip),%xmm7        # 73a8 <std::thread::current::id::ID+0x6730>
   209ba:	ff 
   209bb:	f2 0f 59 fd          	mulsd  %xmm5,%xmm7
   209bf:	f2 0f 58 fb          	addsd  %xmm3,%xmm7
   209c3:	f2 0f 59 05 65 69 fe 	mulsd  -0x1969b(%rip),%xmm0        # 7330 <std::thread::current::id::ID+0x66b8>
   209ca:	ff 
   209cb:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   209cf:	f2 0f 59 2d b1 67 fe 	mulsd  -0x1984f(%rip),%xmm5        # 7188 <std::thread::current::id::ID+0x6510>
   209d6:	ff 
   209d7:	f2 0f 58 e8          	addsd  %xmm0,%xmm5
   209db:	85 db                	test   %ebx,%ebx
   209dd:	74 35                	je     20a14 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xf4>
   209df:	66 44 0f 28 2d c8 48 	movapd -0x1b738(%rip),%xmm13        # 52b0 <std::thread::current::id::ID+0x4638>
   209e6:	fe ff 
   209e8:	66 0f 28 05 c0 4d fe 	movapd -0x1b240(%rip),%xmm0        # 57b0 <std::thread::current::id::ID+0x4b38>
   209ef:	ff 
   209f0:	66 44 0f 28 1d 67 4e 	movapd -0x1b199(%rip),%xmm11        # 5860 <std::thread::current::id::ID+0x4be8>
   209f7:	fe ff 
   209f9:	f3 0f 7e 15 df 67 fe 	movq   -0x19821(%rip),%xmm2        # 71e0 <std::thread::current::id::ID+0x6568>
   20a00:	ff 
   20a01:	f3 0f 7e 25 b7 68 fe 	movq   -0x19749(%rip),%xmm4        # 72c0 <std::thread::current::id::ID+0x6648>
   20a08:	ff 
   20a09:	f3 44 0f 7e 05 d6 67 	movq   -0x1982a(%rip),%xmm8        # 71e8 <std::thread::current::id::ID+0x6570>
   20a10:	fe ff 
   20a12:	eb 33                	jmp    20a47 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0x127>
   20a14:	66 44 0f 28 2d 83 4b 	movapd -0x1b47d(%rip),%xmm13        # 55a0 <std::thread::current::id::ID+0x4928>
   20a1b:	fe ff 
   20a1d:	66 0f 28 05 5b 4c fe 	movapd -0x1b3a5(%rip),%xmm0        # 5680 <std::thread::current::id::ID+0x4a08>
   20a24:	ff 
   20a25:	66 44 0f 28 1d e2 4a 	movapd -0x1b51e(%rip),%xmm11        # 5510 <std::thread::current::id::ID+0x4898>
   20a2c:	fe ff 
   20a2e:	f3 0f 7e 15 da 68 fe 	movq   -0x19726(%rip),%xmm2        # 7310 <std::thread::current::id::ID+0x6698>
   20a35:	ff 
   20a36:	f3 0f 7e 25 c2 68 fe 	movq   -0x1973e(%rip),%xmm4        # 7300 <std::thread::current::id::ID+0x6688>
   20a3d:	ff 
   20a3e:	f3 44 0f 7e 05 31 68 	movq   -0x197cf(%rip),%xmm8        # 7278 <std::thread::current::id::ID+0x6600>
   20a45:	fe ff 
   20a47:	f3 0f 7e da          	movq   %xmm2,%xmm3
   20a4b:	f3 0f 7e e4          	movq   %xmm4,%xmm4
   20a4f:	f3 41 0f 7e d0       	movq   %xmm8,%xmm2
   20a54:	66 0f 14 f7          	unpcklpd %xmm7,%xmm6
   20a58:	66 0f 28 fe          	movapd %xmm6,%xmm7
   20a5c:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   20a60:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20a65:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20a6a:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20a6f:	66 0f 59 fe          	mulpd  %xmm6,%xmm7
   20a73:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   20a79:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   20a80:	f2 0f 10 7c 24 40    	movsd  0x40(%rsp),%xmm7
   20a86:	66 0f 14 ff          	unpcklpd %xmm7,%xmm7
   20a8a:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20a8f:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   20a94:	66 0f 59 fb          	mulpd  %xmm3,%xmm7
   20a98:	66 44 0f 10 64 24 48 	movupd 0x48(%rsp),%xmm12
   20a9f:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   20aa4:	66 45 0f 14 cc       	unpcklpd %xmm12,%xmm9
   20aa9:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20aae:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20ab3:	66 45 0f 58 d0       	addpd  %xmm8,%xmm10
   20ab8:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   20abd:	66 44 0f 58 cf       	addpd  %xmm7,%xmm9
   20ac2:	66 45 0f 15 e4       	unpckhpd %xmm12,%xmm12
   20ac7:	66 45 0f 28 fb       	movapd %xmm11,%xmm15
   20acc:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
   20ad1:	66 45 0f 58 fa       	addpd  %xmm10,%xmm15
   20ad6:	66 44 0f 29 bc 24 00 	movapd %xmm15,0x100(%rsp)
   20add:	01 00 00 
   20ae0:	66 44 0f 59 e2       	mulpd  %xmm2,%xmm12
   20ae5:	66 45 0f 58 e1       	addpd  %xmm9,%xmm12
   20aea:	66 44 0f 29 64 24 20 	movapd %xmm12,0x20(%rsp)
   20af1:	66 0f 28 fe          	movapd %xmm6,%xmm7
   20af5:	66 0f 59 3d d3 48 fe 	mulpd  -0x1b72d(%rip),%xmm7        # 53d0 <std::thread::current::id::ID+0x4758>
   20afc:	ff 
   20afd:	f2 44 0f 10 05 aa 67 	movsd  -0x19856(%rip),%xmm8        # 72b0 <std::thread::current::id::ID+0x6638>
   20b04:	fe ff 
   20b06:	f2 44 0f 59 c5       	mulsd  %xmm5,%xmm8
   20b0b:	f2 41 0f 59 e8       	mulsd  %xmm8,%xmm5
   20b10:	66 0f 59 f7          	mulpd  %xmm7,%xmm6
   20b14:	66 0f 29 74 24 40    	movapd %xmm6,0x40(%rsp)
   20b1a:	f2 0f 11 6c 24 50    	movsd  %xmm5,0x50(%rsp)
   20b20:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   20b26:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   20b2a:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   20b2f:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   20b33:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   20b37:	66 44 0f 10 74 24 48 	movupd 0x48(%rsp),%xmm14
   20b3e:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   20b43:	66 45 0f 14 ce       	unpcklpd %xmm14,%xmm9
   20b48:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   20b4d:	66 45 0f 59 d1       	mulpd  %xmm9,%xmm10
   20b52:	66 44 0f 58 d6       	addpd  %xmm6,%xmm10
   20b57:	66 44 0f 59 cc       	mulpd  %xmm4,%xmm9
   20b5c:	66 44 0f 58 cd       	addpd  %xmm5,%xmm9
   20b61:	66 45 0f 15 f6       	unpckhpd %xmm14,%xmm14
   20b66:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20b6b:	66 41 0f 59 ce       	mulpd  %xmm14,%xmm1
   20b70:	66 41 0f 58 ca       	addpd  %xmm10,%xmm1
   20b75:	66 0f 29 8c 24 e0 00 	movapd %xmm1,0xe0(%rsp)
   20b7c:	00 00 
   20b7e:	66 44 0f 59 f2       	mulpd  %xmm2,%xmm14
   20b83:	66 45 0f 58 f1       	addpd  %xmm9,%xmm14
   20b88:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   20b8d:	66 44 0f 29 b4 24 f0 	movapd %xmm14,0xf0(%rsp)
   20b94:	00 00 00 
   20b97:	66 0f 29 7c 24 40    	movapd %xmm7,0x40(%rsp)
   20b9d:	f2 44 0f 11 44 24 50 	movsd  %xmm8,0x50(%rsp)
   20ba4:	f2 0f 10 6c 24 40    	movsd  0x40(%rsp),%xmm5
   20baa:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   20bae:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   20bb3:	66 0f 59 f5          	mulpd  %xmm5,%xmm6
   20bb7:	66 0f 59 eb          	mulpd  %xmm3,%xmm5
   20bbb:	66 44 0f 10 54 24 48 	movupd 0x48(%rsp),%xmm10
   20bc2:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   20bc7:	66 41 0f 14 fa       	unpcklpd %xmm10,%xmm7
   20bcc:	66 44 0f 28 c0       	movapd %xmm0,%xmm8
   20bd1:	66 44 0f 59 c7       	mulpd  %xmm7,%xmm8
   20bd6:	66 44 0f 58 c6       	addpd  %xmm6,%xmm8
   20bdb:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   20bdf:	66 0f 58 fd          	addpd  %xmm5,%xmm7
   20be3:	66 45 0f 15 d2       	unpckhpd %xmm10,%xmm10
   20be8:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   20bed:	66 41 0f 59 ea       	mulpd  %xmm10,%xmm5
   20bf2:	66 41 0f 58 e8       	addpd  %xmm8,%xmm5
   20bf7:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   20bfc:	66 0f 29 ac 24 80 01 	movapd %xmm5,0x180(%rsp)
   20c03:	00 00 
   20c05:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   20c0a:	66 44 0f 58 d7       	addpd  %xmm7,%xmm10
   20c0f:	66 44 0f 29 94 24 90 	movapd %xmm10,0x190(%rsp)
   20c16:	01 00 00 
   20c19:	0f 28 2d 80 4a fe ff 	movaps -0x1b580(%rip),%xmm5        # 56a0 <std::thread::current::id::ID+0x4a28>
   20c20:	0f 29 6c 24 40       	movaps %xmm5,0x40(%rsp)
   20c25:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   20c2c:	00 f0 3f 
   20c2f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   20c34:	66 0f 10 6c 24 48    	movupd 0x48(%rsp),%xmm5
   20c3a:	66 0f 28 f5          	movapd %xmm5,%xmm6
   20c3e:	66 0f 14 f5          	unpcklpd %xmm5,%xmm6
   20c42:	66 0f 59 c6          	mulpd  %xmm6,%xmm0
   20c46:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   20c4a:	66 41 0f 58 c5       	addpd  %xmm13,%xmm0
   20c4f:	66 0f 58 f3          	addpd  %xmm3,%xmm6
   20c53:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   20c57:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   20c5c:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
   20c61:	66 44 0f 29 9c 24 a0 	movapd %xmm11,0x1a0(%rsp)
   20c68:	01 00 00 
   20c6b:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   20c6f:	66 0f 58 ee          	addpd  %xmm6,%xmm5
   20c73:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   20c78:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   20c7c:	66 0f 16 05 bc 65 fe 	movhpd -0x19a44(%rip),%xmm0        # 7240 <std::thread::current::id::ID+0x65c8>
   20c83:	ff 
   20c84:	66 0f 58 c5          	addpd  %xmm5,%xmm0
   20c88:	66 0f 29 84 24 70 01 	movapd %xmm0,0x170(%rsp)
   20c8f:	00 00 
   20c91:	66 41 0f 28 c7       	movapd %xmm15,%xmm0
   20c96:	66 44 0f 28 3d 31 47 	movapd -0x1b8cf(%rip),%xmm15        # 53d0 <std::thread::current::id::ID+0x4758>
   20c9d:	fe ff 
   20c9f:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   20ca4:	66 45 0f 59 fc       	mulpd  %xmm12,%xmm15
   20ca9:	66 44 0f 29 7c 24 30 	movapd %xmm15,0x30(%rsp)
   20cb0:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20cb4:	66 0f 58 e1          	addpd  %xmm1,%xmm4
   20cb8:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20cbc:	66 44 0f 28 d8       	movapd %xmm0,%xmm11
   20cc1:	66 41 0f 59 d8       	mulpd  %xmm8,%xmm3
   20cc6:	66 41 0f 28 cf       	movapd %xmm15,%xmm1
   20ccb:	66 41 0f 59 ca       	mulpd  %xmm10,%xmm1
   20cd0:	66 0f 28 05 68 47 fe 	movapd -0x1b898(%rip),%xmm0        # 5440 <std::thread::current::id::ID+0x47c8>
   20cd7:	ff 
   20cd8:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   20cdc:	66 0f 28 f3          	movapd %xmm3,%xmm6
   20ce0:	66 0f 29 9c 24 f0 01 	movapd %xmm3,0x1f0(%rsp)
   20ce7:	00 00 
   20ce9:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   20ced:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20cf1:	66 0f 29 8c 24 d0 01 	movapd %xmm1,0x1d0(%rsp)
   20cf8:	00 00 
   20cfa:	66 0f 28 c4          	movapd %xmm4,%xmm0
   20cfe:	66 41 0f c2 c6 01    	cmpltpd %xmm14,%xmm0
   20d04:	66 0f 28 0d 64 4b fe 	movapd -0x1b49c(%rip),%xmm1        # 5870 <std::thread::current::id::ID+0x4bf8>
   20d0b:	ff 
   20d0c:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20d10:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   20d14:	66 44 0f 28 15 83 49 	movapd -0x1b67d(%rip),%xmm10        # 56a0 <std::thread::current::id::ID+0x4a28>
   20d1b:	fe ff 
   20d1d:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   20d22:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   20d26:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
   20d2b:	66 45 0f 58 e9       	addpd  %xmm9,%xmm13
   20d30:	66 41 0f 28 dd       	movapd %xmm13,%xmm3
   20d35:	66 41 0f c2 de 01    	cmpltpd %xmm14,%xmm3
   20d3b:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   20d3f:	66 41 0f 55 da       	andnpd %xmm10,%xmm3
   20d44:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   20d48:	66 0f 28 fc          	movapd %xmm4,%xmm7
   20d4c:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   20d50:	66 0f 29 bc 24 c0 00 	movapd %xmm7,0xc0(%rsp)
   20d57:	00 00 
   20d59:	66 0f 5c fe          	subpd  %xmm6,%xmm7
   20d5d:	66 0f 28 cf          	movapd %xmm7,%xmm1
   20d61:	66 41 0f 5f ce       	maxpd  %xmm14,%xmm1
   20d66:	66 44 0f 51 e1       	sqrtpd %xmm1,%xmm12
   20d6b:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20d70:	66 45 0f 28 c5       	movapd %xmm13,%xmm8
   20d75:	66 45 0f 59 c5       	mulpd  %xmm13,%xmm8
   20d7a:	66 44 0f 29 84 24 e0 	movapd %xmm8,0x1e0(%rsp)
   20d81:	01 00 00 
   20d84:	66 44 0f 5c c5       	subpd  %xmm5,%xmm8
   20d89:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   20d8e:	66 41 0f 5f c6       	maxpd  %xmm14,%xmm0
   20d93:	66 0f 51 d0          	sqrtpd %xmm0,%xmm2
   20d97:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   20d9b:	66 44 0f 58 e4       	addpd  %xmm4,%xmm12
   20da0:	66 41 0f 58 d5       	addpd  %xmm13,%xmm2
   20da5:	66 0f 28 05 d3 4a fe 	movapd -0x1b52d(%rip),%xmm0        # 5880 <std::thread::current::id::ID+0x4c08>
   20dac:	ff 
   20dad:	66 44 0f 59 e0       	mulpd  %xmm0,%xmm12
   20db2:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   20db6:	66 41 0f 28 cb       	movapd %xmm11,%xmm1
   20dbb:	66 44 0f 29 5c 24 10 	movapd %xmm11,0x10(%rsp)
   20dc2:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   20dc7:	66 41 0f c2 c6 00    	cmpeqpd %xmm14,%xmm0
   20dcd:	66 44 0f 28 cc       	movapd %xmm4,%xmm9
   20dd2:	66 45 0f c2 ce 00    	cmpeqpd %xmm14,%xmm9
   20dd8:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   20ddd:	66 44 0f 55 cc       	andnpd %xmm4,%xmm9
   20de2:	66 41 0f c2 e6 04    	cmpneqpd %xmm14,%xmm4
   20de8:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   20dec:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
   20df1:	66 41 0f 54 c2       	andpd  %xmm10,%xmm0
   20df6:	66 44 0f 55 f9       	andnpd %xmm1,%xmm15
   20dfb:	66 44 0f 56 f8       	orpd   %xmm0,%xmm15
   20e00:	66 0f 28 74 24 30    	movapd 0x30(%rsp),%xmm6
   20e06:	66 0f 28 ce          	movapd %xmm6,%xmm1
   20e0a:	66 41 0f c2 ce 00    	cmpeqpd %xmm14,%xmm1
   20e10:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   20e15:	66 41 0f c2 ee 00    	cmpeqpd %xmm14,%xmm5
   20e1b:	66 0f 28 dd          	movapd %xmm5,%xmm3
   20e1f:	66 41 0f 55 ed       	andnpd %xmm13,%xmm5
   20e24:	66 45 0f c2 ee 04    	cmpneqpd %xmm14,%xmm13
   20e2a:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   20e2f:	66 44 0f 29 ac 24 c0 	movapd %xmm13,0x1c0(%rsp)
   20e36:	01 00 00 
   20e39:	66 0f 28 c1          	movapd %xmm1,%xmm0
   20e3d:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e42:	66 0f 55 c6          	andnpd %xmm6,%xmm0
   20e46:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   20e4a:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   20e4f:	66 41 0f c2 f6 00    	cmpeqpd %xmm14,%xmm6
   20e55:	66 0f 28 ce          	movapd %xmm6,%xmm1
   20e59:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e5e:	66 41 0f 55 f4       	andnpd %xmm12,%xmm6
   20e63:	66 0f 56 f1          	orpd   %xmm1,%xmm6
   20e67:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   20e6c:	66 45 0f c2 ee 00    	cmpeqpd %xmm14,%xmm13
   20e72:	66 41 0f 28 cd       	movapd %xmm13,%xmm1
   20e77:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20e7c:	66 44 0f 55 ea       	andnpd %xmm2,%xmm13
   20e81:	66 44 0f 56 e9       	orpd   %xmm1,%xmm13
   20e86:	66 44 0f 29 ac 24 b0 	movapd %xmm13,0x1b0(%rsp)
   20e8d:	01 00 00 
   20e90:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   20e95:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   20e9a:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   20e9f:	66 0f 56 eb          	orpd   %xmm3,%xmm5
   20ea3:	66 45 0f 28 dc       	movapd %xmm12,%xmm11
   20ea8:	66 45 0f 5e df       	divpd  %xmm15,%xmm11
   20ead:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   20eb2:	66 44 0f 5e e8       	divpd  %xmm0,%xmm13
   20eb7:	66 44 0f 28 3d d0 48 	movapd -0x1b730(%rip),%xmm15        # 5790 <std::thread::current::id::ID+0x4b18>
   20ebe:	fe ff 
   20ec0:	66 0f 28 84 24 00 01 	movapd 0x100(%rsp),%xmm0
   20ec7:	00 00 
   20ec9:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ece:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   20ed4:	66 0f 28 44 24 20    	movapd 0x20(%rsp),%xmm0
   20eda:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20edf:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   20ee5:	66 0f 28 84 24 e0 00 	movapd 0xe0(%rsp),%xmm0
   20eec:	00 00 
   20eee:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20ef3:	66 0f 29 44 24 60    	movapd %xmm0,0x60(%rsp)
   20ef9:	66 0f 28 84 24 f0 00 	movapd 0xf0(%rsp),%xmm0
   20f00:	00 00 
   20f02:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20f07:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   20f0d:	66 44 0f 28 94 24 80 	movapd 0x180(%rsp),%xmm10
   20f14:	01 00 00 
   20f17:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   20f1c:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20f21:	66 0f 29 84 24 80 00 	movapd %xmm0,0x80(%rsp)
   20f28:	00 00 
   20f2a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   20f2e:	66 41 0f 5e c9       	divpd  %xmm9,%xmm1
   20f33:	66 44 0f 28 8c 24 90 	movapd 0x190(%rsp),%xmm9
   20f3a:	01 00 00 
   20f3d:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   20f42:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   20f47:	66 0f 29 84 24 90 00 	movapd %xmm0,0x90(%rsp)
   20f4e:	00 00 
   20f50:	66 0f 28 d8          	movapd %xmm0,%xmm3
   20f54:	66 0f 5e dd          	divpd  %xmm5,%xmm3
   20f58:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   20f5c:	66 0f 28 05 ec 47 fe 	movapd -0x1b814(%rip),%xmm0        # 5750 <std::thread::current::id::ID+0x4ad8>
   20f63:	ff 
   20f64:	66 0f 55 e0          	andnpd %xmm0,%xmm4
   20f68:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   20f6c:	66 0f 28 8c 24 c0 01 	movapd 0x1c0(%rsp),%xmm1
   20f73:	00 00 
   20f75:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   20f79:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   20f7d:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   20f81:	66 0f 28 e9          	movapd %xmm1,%xmm5
   20f85:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   20f8b:	66 41 0f c2 de 04    	cmpneqpd %xmm14,%xmm3
   20f91:	66 0f 29 5c 24 10    	movapd %xmm3,0x10(%rsp)
   20f97:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20f9b:	66 0f c2 cf 02       	cmplepd %xmm7,%xmm1
   20fa0:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   20fa4:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   20fa9:	66 45 0f c2 e6 04    	cmpneqpd %xmm14,%xmm12
   20faf:	66 44 0f 54 e1       	andpd  %xmm1,%xmm12
   20fb4:	66 0f 28 d9          	movapd %xmm1,%xmm3
   20fb8:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   20fbc:	66 41 0f 56 db       	orpd   %xmm11,%xmm3
   20fc1:	66 44 0f 28 5c 24 30 	movapd 0x30(%rsp),%xmm11
   20fc8:	66 45 0f c2 de 04    	cmpneqpd %xmm14,%xmm11
   20fce:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20fd2:	66 41 0f c2 c8 02    	cmplepd %xmm8,%xmm1
   20fd8:	66 41 0f 54 cb       	andpd  %xmm11,%xmm1
   20fdd:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   20fe2:	66 41 0f c2 d6 04    	cmpneqpd %xmm14,%xmm2
   20fe8:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   20fec:	66 0f 28 e1          	movapd %xmm1,%xmm4
   20ff0:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   20ff4:	66 41 0f 56 e5       	orpd   %xmm13,%xmm4
   20ff9:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   20ffe:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   21002:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   21007:	66 0f 5e b4 24 b0 01 	divpd  0x1b0(%rsp),%xmm6
   2100e:	00 00 
   21010:	66 41 0f 54 cc       	andpd  %xmm12,%xmm1
   21015:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   2101a:	66 44 0f 56 e1       	orpd   %xmm1,%xmm12
   2101f:	66 0f 54 f2          	andpd  %xmm2,%xmm6
   21023:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   21027:	66 0f 56 d6          	orpd   %xmm6,%xmm2
   2102b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2102f:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   21034:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   21038:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   2103c:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   21040:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   21044:	66 0f c2 dc 01       	cmpltpd %xmm4,%xmm3
   21049:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   2104d:	66 0f 55 d8          	andnpd %xmm0,%xmm3
   21051:	66 0f 56 dc          	orpd   %xmm4,%xmm3
   21055:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   21059:	66 41 0f c2 e4 01    	cmpltpd %xmm12,%xmm4
   2105f:	66 44 0f 54 e4       	andpd  %xmm4,%xmm12
   21064:	66 0f 55 e0          	andnpd %xmm0,%xmm4
   21068:	66 41 0f 56 e4       	orpd   %xmm12,%xmm4
   2106d:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   21071:	66 0f c2 ea 01       	cmpltpd %xmm2,%xmm5
   21076:	66 0f 54 d5          	andpd  %xmm5,%xmm2
   2107a:	66 0f 55 e8          	andnpd %xmm0,%xmm5
   2107e:	66 0f 56 ea          	orpd   %xmm2,%xmm5
   21082:	66 0f 28 05 96 41 fe 	movapd -0x1be6a(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   21089:	ff 
   2108a:	66 44 0f 28 ac 24 f0 	movapd 0x1f0(%rsp),%xmm13
   21091:	01 00 00 
   21094:	66 44 0f 54 e8       	andpd  %xmm0,%xmm13
   21099:	66 44 0f 58 ac 24 c0 	addpd  0xc0(%rsp),%xmm13
   210a0:	00 00 00 
   210a3:	66 44 0f 28 a4 24 d0 	movapd 0x1d0(%rsp),%xmm12
   210aa:	01 00 00 
   210ad:	66 44 0f 54 e0       	andpd  %xmm0,%xmm12
   210b2:	66 44 0f 58 a4 24 e0 	addpd  0x1e0(%rsp),%xmm12
   210b9:	01 00 00 
   210bc:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   210c0:	66 0f 28 35 58 44 fe 	movapd -0x1bba8(%rip),%xmm6        # 5520 <std::thread::current::id::ID+0x48a8>
   210c7:	ff 
   210c8:	66 44 0f 59 ee       	mulpd  %xmm6,%xmm13
   210cd:	66 41 0f c2 fd 02    	cmplepd %xmm13,%xmm7
   210d3:	66 44 0f 59 e6       	mulpd  %xmm6,%xmm12
   210d8:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   210dd:	66 45 0f c2 c4 02    	cmplepd %xmm12,%xmm8
   210e3:	66 0f 54 7c 24 10    	andpd  0x10(%rsp),%xmm7
   210e9:	66 45 0f 54 c3       	andpd  %xmm11,%xmm8
   210ee:	66 0f 28 f1          	movapd %xmm1,%xmm6
   210f2:	66 0f 5d f4          	minpd  %xmm4,%xmm6
   210f6:	66 0f 55 fe          	andnpd %xmm6,%xmm7
   210fa:	66 0f 28 f3          	movapd %xmm3,%xmm6
   210fe:	66 0f 5d f5          	minpd  %xmm5,%xmm6
   21102:	66 44 0f 55 c6       	andnpd %xmm6,%xmm8
   21107:	66 0f 29 bc 24 00 02 	movapd %xmm7,0x200(%rsp)
   2110e:	00 00 
   21110:	66 0f 5f cc          	maxpd  %xmm4,%xmm1
   21114:	66 0f 5f dd          	maxpd  %xmm5,%xmm3
   21118:	66 44 0f 29 84 24 10 	movapd %xmm8,0x210(%rsp)
   2111f:	02 00 00 
   21122:	66 0f 29 8c 24 20 02 	movapd %xmm1,0x220(%rsp)
   21129:	00 00 
   2112b:	66 0f 29 9c 24 30 02 	movapd %xmm3,0x230(%rsp)
   21132:	00 00 
   21134:	66 0f 28 8c 24 e0 00 	movapd 0xe0(%rsp),%xmm1
   2113b:	00 00 
   2113d:	66 0f 28 e1          	movapd %xmm1,%xmm4
   21141:	66 41 0f c2 e6 04    	cmpneqpd %xmm14,%xmm4
   21147:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   2114b:	66 41 0f 28 ea       	movapd %xmm10,%xmm5
   21150:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   21154:	66 0f 28 dc          	movapd %xmm4,%xmm3
   21158:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   2115c:	66 0f 55 e5          	andnpd %xmm5,%xmm4
   21160:	66 0f 56 e3          	orpd   %xmm3,%xmm4
   21164:	66 44 0f 28 9c 24 00 	movapd 0x100(%rsp),%xmm11
   2116b:	01 00 00 
   2116e:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   21173:	66 41 0f c2 f6 04    	cmpneqpd %xmm14,%xmm6
   21179:	66 44 0f 28 54 24 20 	movapd 0x20(%rsp),%xmm10
   21180:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   21185:	66 41 0f c2 fe 04    	cmpneqpd %xmm14,%xmm7
   2118b:	66 0f 28 9c 24 f0 00 	movapd 0xf0(%rsp),%xmm3
   21192:	00 00 
   21194:	66 44 0f c2 f3 04    	cmpneqpd %xmm3,%xmm14
   2119a:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   2119e:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   211a3:	66 44 0f 54 c0       	andpd  %xmm0,%xmm8
   211a8:	66 45 0f 28 ce       	movapd %xmm14,%xmm9
   211ad:	66 44 0f 54 cb       	andpd  %xmm3,%xmm9
   211b2:	66 45 0f 55 f0       	andnpd %xmm8,%xmm14
   211b7:	66 45 0f 56 f1       	orpd   %xmm9,%xmm14
   211bc:	66 45 0f 28 cb       	movapd %xmm11,%xmm9
   211c1:	66 44 0f 54 c8       	andpd  %xmm0,%xmm9
   211c6:	66 44 0f 54 ce       	andpd  %xmm6,%xmm9
   211cb:	66 0f 55 f4          	andnpd %xmm4,%xmm6
   211cf:	66 41 0f 56 f1       	orpd   %xmm9,%xmm6
   211d4:	66 41 0f 28 e2       	movapd %xmm10,%xmm4
   211d9:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   211dd:	66 0f 54 e7          	andpd  %xmm7,%xmm4
   211e1:	66 41 0f 55 fe       	andnpd %xmm14,%xmm7
   211e6:	66 0f 56 fc          	orpd   %xmm4,%xmm7
   211ea:	66 0f 28 15 de 40 fe 	movapd -0x1bf22(%rip),%xmm2        # 52d0 <std::thread::current::id::ID+0x4658>
   211f1:	ff 
   211f2:	66 0f 5f f2          	maxpd  %xmm2,%xmm6
   211f6:	66 0f 5f fa          	maxpd  %xmm2,%xmm7
   211fa:	66 0f 5f cd          	maxpd  %xmm5,%xmm1
   211fe:	66 41 0f 5f d8       	maxpd  %xmm8,%xmm3
   21203:	66 0f 28 ac 24 a0 01 	movapd 0x1a0(%rsp),%xmm5
   2120a:	00 00 
   2120c:	66 0f 28 d5          	movapd %xmm5,%xmm2
   21210:	66 0f 54 d0          	andpd  %xmm0,%xmm2
   21214:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   21218:	66 0f 5e ce          	divpd  %xmm6,%xmm1
   2121c:	66 0f 28 a4 24 70 01 	movapd 0x170(%rsp),%xmm4
   21223:	00 00 
   21225:	66 0f 54 c4          	andpd  %xmm4,%xmm0
   21229:	66 0f 5f d8          	maxpd  %xmm0,%xmm3
   2122d:	66 0f 5e df          	divpd  %xmm7,%xmm3
   21231:	f2 0f 10 05 07 60 fe 	movsd  -0x19ff9(%rip),%xmm0        # 7240 <std::thread::current::id::ID+0x65c8>
   21238:	ff 
   21239:	66 0f 28 15 5f 44 fe 	movapd -0x1bba1(%rip),%xmm2        # 56a0 <std::thread::current::id::ID+0x4a28>
   21240:	ff 
   21241:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21245:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21249:	66 0f c2 c2 00       	cmpeqpd %xmm2,%xmm0
   2124e:	66 0f c2 d2 00       	cmpeqpd %xmm2,%xmm2
   21253:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   21257:	66 0f 28 35 41 44 fe 	movapd -0x1bbbf(%rip),%xmm6        # 56a0 <std::thread::current::id::ID+0x4a28>
   2125e:	ff 
   2125f:	66 0f 55 d6          	andnpd %xmm6,%xmm2
   21263:	66 0f 56 d1          	orpd   %xmm1,%xmm2
   21267:	66 0f 29 94 24 40 02 	movapd %xmm2,0x240(%rsp)
   2126e:	00 00 
   21270:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   21274:	66 0f 55 c6          	andnpd %xmm6,%xmm0
   21278:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   2127c:	66 0f 29 84 24 50 02 	movapd %xmm0,0x250(%rsp)
   21283:	00 00 
   21285:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21289:	66 41 0f 57 c7       	xorpd  %xmm15,%xmm0
   2128e:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   21295:	00 00 
   21297:	66 44 0f 57 fc       	xorpd  %xmm4,%xmm15
   2129c:	66 44 0f 29 bc 24 b0 	movapd %xmm15,0xb0(%rsp)
   212a3:	00 00 00 
   212a6:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   212ac:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   212b0:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   212b7:	00 
   212b8:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   212bd:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   212c4:	00 
   212c5:	48 8d 8c 24 40 02 00 	lea    0x240(%rsp),%rcx
   212cc:	00 
   212cd:	f2 0f 11 44 24 10    	movsd  %xmm0,0x10(%rsp)
   212d3:	e8 98 03 00 00       	call   21670 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>
   212d8:	f2 0f 10 84 24 20 01 	movsd  0x120(%rsp),%xmm0
   212df:	00 00 
   212e1:	f2 0f 10 8c 24 28 01 	movsd  0x128(%rsp),%xmm1
   212e8:	00 00 
   212ea:	f2 0f 10 a4 24 30 01 	movsd  0x130(%rsp),%xmm4
   212f1:	00 00 
   212f3:	f2 0f 5d 05 f5 5e fe 	minsd  -0x1a10b(%rip),%xmm0        # 71f0 <std::thread::current::id::ID+0x6578>
   212fa:	ff 
   212fb:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   212ff:	f2 0f 5d e1          	minsd  %xmm1,%xmm4
   21303:	66 48 0f 7e e0       	movq   %xmm4,%rax
   21308:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   2130f:	ff ff 7f 
   21312:	4c 21 f8             	and    %r15,%rax
   21315:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   2131b:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   21322:	ff ef 7f 
   21325:	48 39 c8             	cmp    %rcx,%rax
   21328:	7e 12                	jle    2133c <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa1c>
   2132a:	4c 89 f0             	mov    %r14,%rax
   2132d:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   21331:	5b                   	pop    %rbx
   21332:	41 5c                	pop    %r12
   21334:	41 5d                	pop    %r13
   21336:	41 5e                	pop    %r14
   21338:	41 5f                	pop    %r15
   2133a:	5d                   	pop    %rbp
   2133b:	c3                   	ret
   2133c:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
   21343:	00 
   21344:	0f 29 44 24 30       	movaps %xmm0,0x30(%rsp)
   21349:	0f 28 84 24 50 01 00 	movaps 0x150(%rsp),%xmm0
   21350:	00 
   21351:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   21358:	00 
   21359:	f2 0f 10 5c 24 10    	movsd  0x10(%rsp),%xmm3
   2135f:	66 0f 28 c3          	movapd %xmm3,%xmm0
   21363:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
   21367:	f2 0f 59 c3          	mulsd  %xmm3,%xmm0
   2136b:	f2 0f 10 0d cd 5e fe 	movsd  -0x1a133(%rip),%xmm1        # 7240 <std::thread::current::id::ID+0x65c8>
   21372:	ff 
   21373:	f2 0f 5e c8          	divsd  %xmm0,%xmm1
   21377:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   2137b:	66 0f 28 84 24 a0 01 	movapd 0x1a0(%rsp),%xmm0
   21382:	00 00 
   21384:	66 0f 5c c1          	subpd  %xmm1,%xmm0
   21388:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   2138f:	00 00 
   21391:	66 0f 28 94 24 70 01 	movapd 0x170(%rsp),%xmm2
   21398:	00 00 
   2139a:	66 0f 5c d1          	subpd  %xmm1,%xmm2
   2139e:	0f 28 84 24 00 01 00 	movaps 0x100(%rsp),%xmm0
   213a5:	00 
   213a6:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   213ab:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   213b0:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   213b5:	0f 28 84 24 e0 00 00 	movaps 0xe0(%rsp),%xmm0
   213bc:	00 
   213bd:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   213c2:	0f 28 84 24 f0 00 00 	movaps 0xf0(%rsp),%xmm0
   213c9:	00 
   213ca:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   213cf:	0f 28 84 24 80 01 00 	movaps 0x180(%rsp),%xmm0
   213d6:	00 
   213d7:	0f 29 84 24 80 00 00 	movaps %xmm0,0x80(%rsp)
   213de:	00 
   213df:	0f 28 84 24 90 01 00 	movaps 0x190(%rsp),%xmm0
   213e6:	00 
   213e7:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   213ee:	00 
   213ef:	66 0f 29 94 24 b0 00 	movapd %xmm2,0xb0(%rsp)
   213f6:	00 00 
   213f8:	66 0f 28 c4          	movapd %xmm4,%xmm0
   213fc:	66 0f 14 c4          	unpcklpd %xmm4,%xmm0
   21400:	66 0f 29 84 24 60 02 	movapd %xmm0,0x260(%rsp)
   21407:	00 00 
   21409:	66 0f 29 84 24 70 02 	movapd %xmm0,0x270(%rsp)
   21410:	00 00 
   21412:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   21419:	00 
   2141a:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   2141f:	48 8d 94 24 00 02 00 	lea    0x200(%rsp),%rdx
   21426:	00 
   21427:	48 8d 8c 24 60 02 00 	lea    0x260(%rsp),%rcx
   2142e:	00 
   2142f:	66 0f 28 c3          	movapd %xmm3,%xmm0
   21433:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   21438:	e8 33 02 00 00       	call   21670 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>
   2143d:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   21443:	66 0f 28 c2          	movapd %xmm2,%xmm0
   21447:	f2 0f 5d 84 24 20 01 	minsd  0x120(%rsp),%xmm0
   2144e:	00 00 
   21450:	66 0f 28 c8          	movapd %xmm0,%xmm1
   21454:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   21459:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   2145d:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   21461:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   21465:	f2 0f 10 84 24 28 01 	movsd  0x128(%rsp),%xmm0
   2146c:	00 00 
   2146e:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21472:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   21476:	66 0f 28 da          	movapd %xmm2,%xmm3
   2147a:	f2 0f c2 da 03       	cmpunordsd %xmm2,%xmm3
   2147f:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   21483:	66 0f 55 da          	andnpd %xmm2,%xmm3
   21487:	66 0f 56 d9          	orpd   %xmm1,%xmm3
   2148b:	f2 0f 10 84 24 30 01 	movsd  0x130(%rsp),%xmm0
   21492:	00 00 
   21494:	66 0f 28 cb          	movapd %xmm3,%xmm1
   21498:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   2149e:	66 0f 5d 94 24 40 01 	minpd  0x140(%rsp),%xmm2
   214a5:	00 00 
   214a7:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   214ab:	66 0f 28 c1          	movapd %xmm1,%xmm0
   214af:	f2 0f c2 c1 03       	cmpunordsd %xmm1,%xmm0
   214b4:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   214b8:	66 0f 55 c1          	andnpd %xmm1,%xmm0
   214bc:	66 0f 56 c3          	orpd   %xmm3,%xmm0
   214c0:	66 0f 2e c2          	ucomisd %xmm2,%xmm0
   214c4:	0f 87 60 fe ff ff    	ja     2132a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   214ca:	66 0f 28 ca          	movapd %xmm2,%xmm1
   214ce:	66 0f 15 ca          	unpckhpd %xmm2,%xmm1
   214d2:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   214d6:	0f 87 4e fe ff ff    	ja     2132a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   214dc:	66 0f 28 8c 24 c0 00 	movapd 0xc0(%rsp),%xmm1
   214e3:	00 00 
   214e5:	f2 0f 5d 8c 24 50 01 	minsd  0x150(%rsp),%xmm1
   214ec:	00 00 
   214ee:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   214f2:	0f 87 32 fe ff ff    	ja     2132a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   214f8:	f2 0f 59 44 24 10    	mulsd  0x10(%rsp),%xmm0
   214fe:	66 48 0f 7e c0       	movq   %xmm0,%rax
   21503:	48 85 c0             	test   %rax,%rax
   21506:	0f 98 c1             	sets   %cl
   21509:	49 21 c7             	and    %rax,%r15
   2150c:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
   21513:	00 f0 ff 
   21516:	4c 01 f8             	add    %r15,%rax
   21519:	48 c1 e8 35          	shr    $0x35,%rax
   2151d:	3d ff 03 00 00       	cmp    $0x3ff,%eax
   21522:	0f 92 c0             	setb   %al
   21525:	20 c8                	and    %cl,%al
   21527:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
   2152b:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   21532:	ff 0f 00 
   21535:	48 39 f2             	cmp    %rsi,%rdx
   21538:	0f 92 c2             	setb   %dl
   2153b:	20 ca                	and    %cl,%dl
   2153d:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
   21544:	00 f0 7f 
   21547:	49 39 cf             	cmp    %rcx,%r15
   2154a:	0f 9f c1             	setg   %cl
   2154d:	40 0f 94 c6          	sete   %sil
   21551:	40 08 ce             	or     %cl,%sil
   21554:	40 08 d6             	or     %dl,%sil
   21557:	40 08 c6             	or     %al,%sil
   2155a:	0f 85 ca fd ff ff    	jne    2132a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   21560:	0f 57 c9             	xorps  %xmm1,%xmm1
   21563:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   21567:	0f 57 d2             	xorps  %xmm2,%xmm2
   2156a:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
   2156e:	66 0f 2e d0          	ucomisd %xmm0,%xmm2
   21572:	0f 97 c0             	seta   %al
   21575:	66 41 0f 7e cc       	movd   %xmm1,%r12d
   2157a:	41 81 fc 00 00 80 ff 	cmp    $0xff800000,%r12d
   21581:	0f 95 c1             	setne  %cl
   21584:	84 c8                	test   %cl,%al
   21586:	74 20                	je     215a8 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc88>
   21588:	66 0f 7e c8          	movd   %xmm1,%eax
   2158c:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   21591:	74 0a                	je     2159d <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc7d>
   21593:	41 39 c4             	cmp    %eax,%r12d
   21596:	75 0d                	jne    215a5 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc85>
   21598:	41 ff cc             	dec    %r12d
   2159b:	eb 0b                	jmp    215a8 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc88>
   2159d:	41 bc 01 00 00 80    	mov    $0x80000001,%r12d
   215a3:	eb 03                	jmp    215a8 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xc88>
   215a5:	41 ff c4             	inc    %r12d
   215a8:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   215af:	00 
   215b0:	0f 56 05 19 42 fe ff 	orps   -0x1bde7(%rip),%xmm0        # 57d0 <std::thread::current::id::ID+0x4b58>
   215b7:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   215be:	00 
   215bf:	41 bd 40 00 00 00    	mov    $0x40,%r13d
   215c5:	0f b6 db             	movzbl %bl,%ebx
   215c8:	4c 8d 7c 24 40       	lea    0x40(%rsp),%r15
   215cd:	eb 2b                	jmp    215fa <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcda>
   215cf:	41 bc 01 00 00 80    	mov    $0x80000001,%r12d
   215d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   215dc:	00 00 00 00 
   215e0:	66 41 0f 6e c4       	movd   %r12d,%xmm0
   215e5:	0f 57 c9             	xorps  %xmm1,%xmm1
   215e8:	f3 0f 5f c1          	maxss  %xmm1,%xmm0
   215ec:	66 41 0f 7e c4       	movd   %xmm0,%r12d
   215f1:	41 ff cd             	dec    %r13d
   215f4:	0f 84 30 fd ff ff    	je     2132a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   215fa:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   21600:	f3 0f 11 44 24 40    	movss  %xmm0,0x40(%rsp)
   21606:	44 89 64 24 44       	mov    %r12d,0x44(%rsp)
   2160b:	0f 28 84 24 d0 00 00 	movaps 0xd0(%rsp),%xmm0
   21612:	00 
   21613:	f3 0f 11 44 24 48    	movss  %xmm0,0x48(%rsp)
   21619:	c7 44 24 4c 00 00 80 	movl   $0xff800000,0x4c(%rsp)
   21620:	ff 
   21621:	4c 89 ff             	mov    %r15,%rdi
   21624:	89 de                	mov    %ebx,%esi
   21626:	e8 f5 0d 00 00       	call   22420 <gpui_canvas::color::gamut::in_gamut>
   2162b:	84 c0                	test   %al,%al
   2162d:	75 2b                	jne    2165a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xd3a>
   2162f:	41 81 fc 00 00 80 ff 	cmp    $0xff800000,%r12d
   21636:	74 a8                	je     215e0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcc0>
   21638:	66 41 0f 6e c4       	movd   %r12d,%xmm0
   2163d:	0f 2e c0             	ucomiss %xmm0,%xmm0
   21640:	7a 9e                	jp     215e0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcc0>
   21642:	41 f7 c4 ff ff ff 7f 	test   $0x7fffffff,%r12d
   21649:	74 84                	je     215cf <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcaf>
   2164b:	45 85 e4             	test   %r12d,%r12d
   2164e:	78 05                	js     21655 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xd35>
   21650:	41 ff cc             	dec    %r12d
   21653:	eb 8b                	jmp    215e0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcc0>
   21655:	41 ff c4             	inc    %r12d
   21658:	eb 86                	jmp    215e0 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xcc0>
   2165a:	49 c1 e4 20          	shl    $0x20,%r12
   2165e:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   21664:	4d 09 e6             	or     %r12,%r14
   21667:	e9 be fc ff ff       	jmp    2132a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::sse2::Sse2>+0xa0a>
   2166c:	cc                   	int3
   2166d:	cc                   	int3
   2166e:	cc                   	int3
   2166f:	cc                   	int3

0000000000021670 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>>:
   21670:	55                   	push   %rbp
   21671:	48 89 e5             	mov    %rsp,%rbp
   21674:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   21678:	48 81 ec e0 03 00 00 	sub    $0x3e0,%rsp
   2167f:	66 44 0f 28 e8       	movapd %xmm0,%xmm13
   21684:	66 0f 28 26          	movapd (%rsi),%xmm4
   21688:	66 0f 28 6e 10       	movapd 0x10(%rsi),%xmm5
   2168d:	66 0f 28 76 20       	movapd 0x20(%rsi),%xmm6
   21692:	66 0f 28 7e 30       	movapd 0x30(%rsi),%xmm7
   21697:	66 44 0f 28 46 40    	movapd 0x40(%rsi),%xmm8
   2169d:	66 44 0f 28 4e 60    	movapd 0x60(%rsi),%xmm9
   216a3:	66 44 0f 28 56 70    	movapd 0x70(%rsi),%xmm10
   216a9:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   216ad:	66 41 0f c2 d1 01    	cmpltpd %xmm9,%xmm2
   216b3:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   216b7:	66 41 0f c2 ca 01    	cmpltpd %xmm10,%xmm1
   216bd:	66 0f 28 05 8b 40 fe 	movapd -0x1bf75(%rip),%xmm0        # 5750 <std::thread::current::id::ID+0x4ad8>
   216c4:	ff 
   216c5:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   216c9:	66 0f 29 54 24 20    	movapd %xmm2,0x20(%rsp)
   216cf:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   216d3:	66 0f 29 4c 24 30    	movapd %xmm1,0x30(%rsp)
   216d9:	0f 28 42 20          	movaps 0x20(%rdx),%xmm0
   216dd:	0f 28 4a 30          	movaps 0x30(%rdx),%xmm1
   216e1:	0f 29 84 24 20 02 00 	movaps %xmm0,0x220(%rsp)
   216e8:	00 
   216e9:	0f 29 8c 24 30 02 00 	movaps %xmm1,0x230(%rsp)
   216f0:	00 
   216f1:	0f 28 02             	movaps (%rdx),%xmm0
   216f4:	0f 29 84 24 00 02 00 	movaps %xmm0,0x200(%rsp)
   216fb:	00 
   216fc:	0f 28 42 10          	movaps 0x10(%rdx),%xmm0
   21700:	0f 29 84 24 10 02 00 	movaps %xmm0,0x210(%rsp)
   21707:	00 
   21708:	0f 28 84 24 00 02 00 	movaps 0x200(%rsp),%xmm0
   2170f:	00 
   21710:	0f 28 8c 24 10 02 00 	movaps 0x210(%rsp),%xmm1
   21717:	00 
   21718:	0f 28 94 24 20 02 00 	movaps 0x220(%rsp),%xmm2
   2171f:	00 
   21720:	0f 28 9c 24 30 02 00 	movaps 0x230(%rsp),%xmm3
   21727:	00 
   21728:	0f 29 9c 24 30 03 00 	movaps %xmm3,0x330(%rsp)
   2172f:	00 
   21730:	0f 29 94 24 20 03 00 	movaps %xmm2,0x320(%rsp)
   21737:	00 
   21738:	0f 29 8c 24 10 03 00 	movaps %xmm1,0x310(%rsp)
   2173f:	00 
   21740:	0f 29 84 24 00 03 00 	movaps %xmm0,0x300(%rsp)
   21747:	00 
   21748:	0f 28 84 24 30 03 00 	movaps 0x330(%rsp),%xmm0
   2174f:	00 
   21750:	0f 29 84 24 90 03 00 	movaps %xmm0,0x390(%rsp)
   21757:	00 
   21758:	0f 28 84 24 f0 02 00 	movaps 0x2f0(%rsp),%xmm0
   2175f:	00 
   21760:	0f 28 8c 24 00 03 00 	movaps 0x300(%rsp),%xmm1
   21767:	00 
   21768:	0f 28 94 24 10 03 00 	movaps 0x310(%rsp),%xmm2
   2176f:	00 
   21770:	0f 28 9c 24 20 03 00 	movaps 0x320(%rsp),%xmm3
   21777:	00 
   21778:	0f 29 9c 24 80 03 00 	movaps %xmm3,0x380(%rsp)
   2177f:	00 
   21780:	0f 29 94 24 70 03 00 	movaps %xmm2,0x370(%rsp)
   21787:	00 
   21788:	0f 29 8c 24 60 03 00 	movaps %xmm1,0x360(%rsp)
   2178f:	00 
   21790:	0f 29 84 24 50 03 00 	movaps %xmm0,0x350(%rsp)
   21797:	00 
   21798:	66 0f 28 05 b0 3f fe 	movapd -0x1c050(%rip),%xmm0        # 5750 <std::thread::current::id::ID+0x4ad8>
   2179f:	ff 
   217a0:	66 0f 29 84 24 a0 03 	movapd %xmm0,0x3a0(%rsp)
   217a7:	00 00 
   217a9:	66 0f 29 84 24 b0 03 	movapd %xmm0,0x3b0(%rsp)
   217b0:	00 00 
   217b2:	48 8d 84 24 60 03 00 	lea    0x360(%rsp),%rax
   217b9:	00 
   217ba:	66 0f 28 0d 5e 3a fe 	movapd -0x1c5a2(%rip),%xmm1        # 5220 <std::thread::current::id::ID+0x45a8>
   217c1:	ff 
   217c2:	66 0f 28 d4          	movapd %xmm4,%xmm2
   217c6:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   217ca:	66 0f 28 dd          	movapd %xmm5,%xmm3
   217ce:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   217d2:	66 44 0f 28 de       	movapd %xmm6,%xmm11
   217d7:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   217dc:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   217e1:	66 44 0f 54 e1       	andpd  %xmm1,%xmm12
   217e6:	66 44 0f 29 84 24 90 	movapd %xmm8,0x90(%rsp)
   217ed:	00 00 00 
   217f0:	66 44 0f 54 c1       	andpd  %xmm1,%xmm8
   217f5:	66 44 0f 29 84 24 f0 	movapd %xmm8,0x1f0(%rsp)
   217fc:	01 00 00 
   217ff:	66 44 0f 28 46 50    	movapd 0x50(%rsi),%xmm8
   21805:	66 44 0f 29 84 24 80 	movapd %xmm8,0x80(%rsp)
   2180c:	00 00 00 
   2180f:	66 44 0f 54 c1       	andpd  %xmm1,%xmm8
   21814:	66 44 0f 29 84 24 20 	movapd %xmm8,0x120(%rsp)
   2181b:	01 00 00 
   2181e:	66 44 0f 29 8c 24 60 	movapd %xmm9,0x160(%rsp)
   21825:	01 00 00 
   21828:	66 44 0f 54 c9       	andpd  %xmm1,%xmm9
   2182d:	66 44 0f 29 8c 24 80 	movapd %xmm9,0x280(%rsp)
   21834:	02 00 00 
   21837:	66 44 0f 29 94 24 50 	movapd %xmm10,0x150(%rsp)
   2183e:	01 00 00 
   21841:	66 44 0f 54 d1       	andpd  %xmm1,%xmm10
   21846:	66 44 0f 29 94 24 70 	movapd %xmm10,0x270(%rsp)
   2184d:	02 00 00 
   21850:	66 45 0f 14 ed       	unpcklpd %xmm13,%xmm13
   21855:	66 0f 28 0d 73 3b fe 	movapd -0x1c48d(%rip),%xmm1        # 53d0 <std::thread::current::id::ID+0x4758>
   2185c:	ff 
   2185d:	66 0f 29 a4 24 a0 01 	movapd %xmm4,0x1a0(%rsp)
   21864:	00 00 
   21866:	66 0f 59 e1          	mulpd  %xmm1,%xmm4
   2186a:	66 0f 29 a4 24 e0 01 	movapd %xmm4,0x1e0(%rsp)
   21871:	00 00 
   21873:	66 0f 29 ac 24 90 01 	movapd %xmm5,0x190(%rsp)
   2187a:	00 00 
   2187c:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   21880:	66 0f 29 ac 24 d0 01 	movapd %xmm5,0x1d0(%rsp)
   21887:	00 00 
   21889:	66 0f 29 b4 24 80 01 	movapd %xmm6,0x180(%rsp)
   21890:	00 00 
   21892:	66 0f 58 f6          	addpd  %xmm6,%xmm6
   21896:	66 0f 29 b4 24 c0 01 	movapd %xmm6,0x1c0(%rsp)
   2189d:	00 00 
   2189f:	66 0f 29 bc 24 70 01 	movapd %xmm7,0x170(%rsp)
   218a6:	00 00 
   218a8:	66 0f 58 ff          	addpd  %xmm7,%xmm7
   218ac:	66 0f 29 bc 24 00 01 	movapd %xmm7,0x100(%rsp)
   218b3:	00 00 
   218b5:	66 0f 29 94 24 c0 02 	movapd %xmm2,0x2c0(%rsp)
   218bc:	00 00 
   218be:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   218c2:	66 0f 29 94 24 b0 01 	movapd %xmm2,0x1b0(%rsp)
   218c9:	00 00 
   218cb:	66 0f 29 9c 24 b0 02 	movapd %xmm3,0x2b0(%rsp)
   218d2:	00 00 
   218d4:	66 0f 59 cb          	mulpd  %xmm3,%xmm1
   218d8:	66 0f 29 8c 24 10 01 	movapd %xmm1,0x110(%rsp)
   218df:	00 00 
   218e1:	66 44 0f 29 9c 24 a0 	movapd %xmm11,0x2a0(%rsp)
   218e8:	02 00 00 
   218eb:	66 45 0f 58 db       	addpd  %xmm11,%xmm11
   218f0:	66 44 0f 29 9c 24 f0 	movapd %xmm11,0xf0(%rsp)
   218f7:	00 00 00 
   218fa:	66 44 0f 29 a4 24 90 	movapd %xmm12,0x290(%rsp)
   21901:	02 00 00 
   21904:	66 45 0f 58 e4       	addpd  %xmm12,%xmm12
   21909:	66 44 0f 29 a4 24 e0 	movapd %xmm12,0xe0(%rsp)
   21910:	00 00 00 
   21913:	31 d2                	xor    %edx,%edx
   21915:	0f 28 09             	movaps (%rcx),%xmm1
   21918:	0f 29 8c 24 60 02 00 	movaps %xmm1,0x260(%rsp)
   2191f:	00 
   21920:	66 0f 28 49 10       	movapd 0x10(%rcx),%xmm1
   21925:	66 0f 29 8c 24 50 02 	movapd %xmm1,0x250(%rsp)
   2192c:	00 00 
   2192e:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21932:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21936:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   2193c:	66 0f 29 44 24 40    	movapd %xmm0,0x40(%rsp)
   21942:	66 44 0f 29 ac 24 d0 	movapd %xmm13,0x2d0(%rsp)
   21949:	02 00 00 
   2194c:	e9 b9 00 00 00       	jmp    21a0a <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x39a>
   21951:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   21958:	0f 1f 84 00 00 00 00 
   2195f:	00 
   21960:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   21964:	66 0f 55 4c 24 20    	andnpd 0x20(%rsp),%xmm1
   2196a:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   2196e:	66 41 0f 54 d7       	andpd  %xmm15,%xmm2
   21973:	66 44 0f 55 7c 24 30 	andnpd 0x30(%rsp),%xmm15
   2197a:	66 44 0f 56 fa       	orpd   %xmm2,%xmm15
   2197f:	66 44 0f 29 7c 24 30 	movapd %xmm15,0x30(%rsp)
   21986:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   2198c:	48 ff c2             	inc    %rdx
   2198f:	0f 28 84 24 a0 00 00 	movaps 0xa0(%rsp),%xmm0
   21996:	00 
   21997:	0f 54 44 24 60       	andps  0x60(%rsp),%xmm0
   2199c:	66 0f 28 9c 24 b0 00 	movapd 0xb0(%rsp),%xmm3
   219a3:	00 00 
   219a5:	66 0f 54 9c 24 c0 00 	andpd  0xc0(%rsp),%xmm3
   219ac:	00 00 
   219ae:	0f 28 54 24 70       	movaps 0x70(%rsp),%xmm2
   219b3:	0f 54 94 24 30 01 00 	andps  0x130(%rsp),%xmm2
   219ba:	00 
   219bb:	66 0f 28 8c 24 d0 00 	movapd 0xd0(%rsp),%xmm1
   219c2:	00 00 
   219c4:	66 0f 54 8c 24 40 01 	andpd  0x140(%rsp),%xmm1
   219cb:	00 00 
   219cd:	0f 54 d0             	andps  %xmm0,%xmm2
   219d0:	0f 55 44 24 40       	andnps 0x40(%rsp),%xmm0
   219d5:	0f 56 c2             	orps   %xmm2,%xmm0
   219d8:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   219dd:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   219e1:	66 0f 55 5c 24 50    	andnpd 0x50(%rsp),%xmm3
   219e7:	66 0f 28 c3          	movapd %xmm3,%xmm0
   219eb:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   219ef:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   219f5:	48 83 fa 03          	cmp    $0x3,%rdx
   219f9:	66 0f 28 0c 24       	movapd (%rsp),%xmm1
   219fe:	66 0f 28 54 24 10    	movapd 0x10(%rsp),%xmm2
   21a04:	0f 84 eb 09 00 00    	je     223f5 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0xd85>
   21a0a:	66 0f 29 94 24 30 01 	movapd %xmm2,0x130(%rsp)
   21a11:	00 00 
   21a13:	66 0f 29 8c 24 40 01 	movapd %xmm1,0x140(%rsp)
   21a1a:	00 00 
   21a1c:	48 89 d1             	mov    %rdx,%rcx
   21a1f:	48 c1 e1 05          	shl    $0x5,%rcx
   21a23:	66 0f 28 0c 08       	movapd (%rax,%rcx,1),%xmm1
   21a28:	66 0f 28 44 08 10    	movapd 0x10(%rax,%rcx,1),%xmm0
   21a2e:	66 0f 28 d1          	movapd %xmm1,%xmm2
   21a32:	66 44 0f 28 15 15 3d 	movapd -0x1c2eb(%rip),%xmm10        # 5750 <std::thread::current::id::ID+0x4ad8>
   21a39:	fe ff 
   21a3b:	66 41 0f c2 d2 01    	cmpltpd %xmm10,%xmm2
   21a41:	66 0f 28 d8          	movapd %xmm0,%xmm3
   21a45:	66 41 0f c2 da 01    	cmpltpd %xmm10,%xmm3
   21a4b:	66 0f 29 54 24 70    	movapd %xmm2,0x70(%rsp)
   21a51:	66 0f 29 8c 24 e0 02 	movapd %xmm1,0x2e0(%rsp)
   21a58:	00 00 
   21a5a:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   21a5e:	66 0f 29 5c 24 60    	movapd %xmm3,0x60(%rsp)
   21a64:	66 0f 29 84 24 a0 00 	movapd %xmm0,0xa0(%rsp)
   21a6b:	00 00 
   21a6d:	66 0f 54 d8          	andpd  %xmm0,%xmm3
   21a71:	66 0f 29 94 24 c0 00 	movapd %xmm2,0xc0(%rsp)
   21a78:	00 00 
   21a7a:	66 0f 28 e2          	movapd %xmm2,%xmm4
   21a7e:	66 0f 28 05 9a 37 fe 	movapd -0x1c866(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   21a85:	ff 
   21a86:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   21a8a:	66 0f 29 9c 24 b0 00 	movapd %xmm3,0xb0(%rsp)
   21a91:	00 00 
   21a93:	66 44 0f 28 cb       	movapd %xmm3,%xmm9
   21a98:	66 44 0f 54 c8       	andpd  %xmm0,%xmm9
   21a9d:	66 0f 28 05 fb 3b fe 	movapd -0x1c405(%rip),%xmm0        # 56a0 <std::thread::current::id::ID+0x4a28>
   21aa4:	ff 
   21aa5:	66 0f 58 e0          	addpd  %xmm0,%xmm4
   21aa9:	66 44 0f 58 c8       	addpd  %xmm0,%xmm9
   21aae:	66 0f 28 05 6a 3a fe 	movapd -0x1c596(%rip),%xmm0        # 5520 <std::thread::current::id::ID+0x48a8>
   21ab5:	ff 
   21ab6:	66 0f 59 e0          	mulpd  %xmm0,%xmm4
   21aba:	66 44 0f 59 c8       	mulpd  %xmm0,%xmm9
   21abf:	b9 1f 00 00 00       	mov    $0x1f,%ecx
   21ac4:	66 41 0f 28 ea       	movapd %xmm10,%xmm5
   21ac9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   21ad0:	66 0f 29 ac 24 d0 00 	movapd %xmm5,0xd0(%rsp)
   21ad7:	00 00 
   21ad9:	66 44 0f 29 0c 24    	movapd %xmm9,(%rsp)
   21adf:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   21ae5:	66 0f 28 94 24 c0 00 	movapd 0xc0(%rsp),%xmm2
   21aec:	00 00 
   21aee:	66 0f 28 c2          	movapd %xmm2,%xmm0
   21af2:	66 0f 5c c4          	subpd  %xmm4,%xmm0
   21af6:	66 0f 28 9c 24 b0 00 	movapd 0xb0(%rsp),%xmm3
   21afd:	00 00 
   21aff:	66 0f 28 eb          	movapd %xmm3,%xmm5
   21b03:	66 41 0f 5c e9       	subpd  %xmm9,%xmm5
   21b08:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21b0c:	66 0f 5f c1          	maxpd  %xmm1,%xmm0
   21b10:	66 0f 5f e9          	maxpd  %xmm1,%xmm5
   21b14:	66 0f 28 cc          	movapd %xmm4,%xmm1
   21b18:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21b1c:	66 44 0f 28 3c 24    	movapd (%rsp),%xmm15
   21b22:	66 44 0f 58 fb       	addpd  %xmm3,%xmm15
   21b27:	66 0f 28 b4 24 e0 01 	movapd 0x1e0(%rsp),%xmm6
   21b2e:	00 00 
   21b30:	66 44 0f 28 c6       	movapd %xmm6,%xmm8
   21b35:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   21b3a:	66 0f 28 94 24 d0 01 	movapd 0x1d0(%rsp),%xmm2
   21b41:	00 00 
   21b43:	66 44 0f 28 ca       	movapd %xmm2,%xmm9
   21b48:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   21b4d:	66 0f 28 9c 24 c0 01 	movapd 0x1c0(%rsp),%xmm3
   21b54:	00 00 
   21b56:	66 44 0f 58 c3       	addpd  %xmm3,%xmm8
   21b5b:	66 44 0f 58 8c 24 00 	addpd  0x100(%rsp),%xmm9
   21b62:	01 00 00 
   21b65:	66 44 0f 59 c0       	mulpd  %xmm0,%xmm8
   21b6a:	66 44 0f 59 cd       	mulpd  %xmm5,%xmm9
   21b6f:	66 44 0f 28 ac 24 90 	movapd 0x90(%rsp),%xmm13
   21b76:	00 00 00 
   21b79:	66 45 0f 58 c5       	addpd  %xmm13,%xmm8
   21b7e:	66 0f 28 a4 24 80 00 	movapd 0x80(%rsp),%xmm4
   21b85:	00 00 
   21b87:	66 44 0f 58 cc       	addpd  %xmm4,%xmm9
   21b8c:	66 44 0f 28 b4 24 b0 	movapd 0x1b0(%rsp),%xmm14
   21b93:	01 00 00 
   21b96:	66 41 0f 28 fe       	movapd %xmm14,%xmm7
   21b9b:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   21b9f:	66 44 0f 28 9c 24 10 	movapd 0x110(%rsp),%xmm11
   21ba6:	01 00 00 
   21ba9:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   21bae:	66 0f 58 bc 24 f0 00 	addpd  0xf0(%rsp),%xmm7
   21bb5:	00 00 
   21bb7:	66 44 0f 58 9c 24 e0 	addpd  0xe0(%rsp),%xmm11
   21bbe:	00 00 00 
   21bc1:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   21bc5:	66 44 0f 59 dd       	mulpd  %xmm5,%xmm11
   21bca:	66 44 0f 28 a4 24 f0 	movapd 0x1f0(%rsp),%xmm12
   21bd1:	01 00 00 
   21bd4:	66 41 0f 58 fc       	addpd  %xmm12,%xmm7
   21bd9:	66 44 0f 58 9c 24 20 	addpd  0x120(%rsp),%xmm11
   21be0:	01 00 00 
   21be3:	66 0f 28 05 35 39 fe 	movapd -0x1c6cb(%rip),%xmm0        # 5520 <std::thread::current::id::ID+0x48a8>
   21bea:	ff 
   21beb:	66 0f 59 f8          	mulpd  %xmm0,%xmm7
   21bef:	66 44 0f 59 d8       	mulpd  %xmm0,%xmm11
   21bf4:	66 0f 28 ee          	movapd %xmm6,%xmm5
   21bf8:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   21bfc:	66 0f 28 f2          	movapd %xmm2,%xmm6
   21c00:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21c05:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   21c09:	66 0f 58 b4 24 00 01 	addpd  0x100(%rsp),%xmm6
   21c10:	00 00 
   21c12:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   21c16:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21c1b:	66 41 0f 58 ed       	addpd  %xmm13,%xmm5
   21c20:	66 0f 58 f4          	addpd  %xmm4,%xmm6
   21c24:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   21c2a:	66 44 0f 59 f1       	mulpd  %xmm1,%xmm14
   21c2f:	66 44 0f 58 b4 24 f0 	addpd  0xf0(%rsp),%xmm14
   21c36:	00 00 00 
   21c39:	66 44 0f 59 f1       	mulpd  %xmm1,%xmm14
   21c3e:	66 0f 28 8c 24 10 01 	movapd 0x110(%rsp),%xmm1
   21c45:	00 00 
   21c47:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
   21c4c:	66 0f 58 8c 24 e0 00 	addpd  0xe0(%rsp),%xmm1
   21c53:	00 00 
   21c55:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
   21c5a:	66 45 0f 58 f4       	addpd  %xmm12,%xmm14
   21c5f:	66 0f 58 8c 24 20 01 	addpd  0x120(%rsp),%xmm1
   21c66:	00 00 
   21c68:	66 0f 28 15 b0 38 fe 	movapd -0x1c750(%rip),%xmm2        # 5520 <std::thread::current::id::ID+0x48a8>
   21c6f:	ff 
   21c70:	66 44 0f 59 f2       	mulpd  %xmm2,%xmm14
   21c75:	66 0f 59 ca          	mulpd  %xmm2,%xmm1
   21c79:	66 44 0f 28 ff       	movapd %xmm7,%xmm15
   21c7e:	66 0f 28 15 0a 3b fe 	movapd -0x1c4f6(%rip),%xmm2        # 5790 <std::thread::current::id::ID+0x4b18>
   21c85:	ff 
   21c86:	66 44 0f 57 fa       	xorpd  %xmm2,%xmm15
   21c8b:	66 41 0f c2 f8 01    	cmpltpd %xmm8,%xmm7
   21c91:	66 45 0f c2 c7 01    	cmpltpd %xmm15,%xmm8
   21c97:	66 45 0f 28 fb       	movapd %xmm11,%xmm15
   21c9c:	66 44 0f 57 fa       	xorpd  %xmm2,%xmm15
   21ca1:	66 45 0f c2 d9 01    	cmpltpd %xmm9,%xmm11
   21ca7:	66 45 0f c2 cf 01    	cmpltpd %xmm15,%xmm9
   21cad:	66 45 0f 28 fe       	movapd %xmm14,%xmm15
   21cb2:	66 44 0f c2 fd 01    	cmpltpd %xmm5,%xmm15
   21cb8:	66 45 0f 54 f8       	andpd  %xmm8,%xmm15
   21cbd:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   21cc2:	66 44 0f c2 c6 01    	cmpltpd %xmm6,%xmm8
   21cc8:	66 45 0f 54 c1       	andpd  %xmm9,%xmm8
   21ccd:	66 44 0f 57 f2       	xorpd  %xmm2,%xmm14
   21cd2:	66 41 0f c2 ee 01    	cmpltpd %xmm14,%xmm5
   21cd8:	66 0f 54 ef          	andpd  %xmm7,%xmm5
   21cdc:	66 41 0f 56 ef       	orpd   %xmm15,%xmm5
   21ce1:	66 44 0f 28 0c 24    	movapd (%rsp),%xmm9
   21ce7:	66 0f 57 ca          	xorpd  %xmm2,%xmm1
   21ceb:	66 0f c2 f1 01       	cmpltpd %xmm1,%xmm6
   21cf0:	66 41 0f 54 f3       	andpd  %xmm11,%xmm6
   21cf5:	66 41 0f 56 f0       	orpd   %xmm8,%xmm6
   21cfa:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   21cff:	66 0f 28 3d 49 3a fe 	movapd -0x1c5b7(%rip),%xmm7        # 5750 <std::thread::current::id::ID+0x4ad8>
   21d06:	ff 
   21d07:	66 0f c2 c7 00       	cmpeqpd %xmm7,%xmm0
   21d0c:	66 0f 28 54 24 70    	movapd 0x70(%rsp),%xmm2
   21d12:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   21d16:	66 0f 54 c5          	andpd  %xmm5,%xmm0
   21d1a:	66 44 0f 28 84 24 d0 	movapd 0xd0(%rsp),%xmm8
   21d21:	00 00 00 
   21d24:	66 41 0f 28 c8       	movapd %xmm8,%xmm1
   21d29:	66 0f c2 cf 00       	cmpeqpd %xmm7,%xmm1
   21d2e:	66 0f 28 5c 24 60    	movapd 0x60(%rsp),%xmm3
   21d34:	66 0f 54 cb          	andpd  %xmm3,%xmm1
   21d38:	66 0f 54 ce          	andpd  %xmm6,%xmm1
   21d3c:	66 0f 28 e8          	movapd %xmm0,%xmm5
   21d40:	66 41 0f 55 c2       	andnpd %xmm10,%xmm0
   21d45:	66 0f 58 e4          	addpd  %xmm4,%xmm4
   21d49:	66 0f 54 ec          	andpd  %xmm4,%xmm5
   21d4d:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   21d52:	66 44 0f 56 d5       	orpd   %xmm5,%xmm10
   21d57:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21d5b:	66 41 0f 55 c8       	andnpd %xmm8,%xmm1
   21d60:	66 45 0f 58 c9       	addpd  %xmm9,%xmm9
   21d65:	66 41 0f 54 c1       	andpd  %xmm9,%xmm0
   21d6a:	66 0f 28 e9          	movapd %xmm1,%xmm5
   21d6e:	66 0f 56 e8          	orpd   %xmm0,%xmm5
   21d72:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   21d77:	66 0f c2 c7 00       	cmpeqpd %xmm7,%xmm0
   21d7c:	66 0f 54 c2          	andpd  %xmm2,%xmm0
   21d80:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
   21d85:	66 0f 28 c5          	movapd %xmm5,%xmm0
   21d89:	f2 0f c2 c7 00       	cmpeqsd %xmm7,%xmm0
   21d8e:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21d92:	66 44 0f 50 c8       	movmskpd %xmm0,%r9d
   21d97:	41 c1 e1 02          	shl    $0x2,%r9d
   21d9b:	41 83 e1 04          	and    $0x4,%r9d
   21d9f:	83 e9 01             	sub    $0x1,%ecx
   21da2:	40 0f 92 c6          	setb   %sil
   21da6:	45 09 c1             	or     %r8d,%r9d
   21da9:	74 09                	je     21db4 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x744>
   21dab:	40 84 f6             	test   %sil,%sil
   21dae:	0f 84 1c fd ff ff    	je     21ad0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x460>
   21db4:	66 0f 28 94 24 e0 02 	movapd 0x2e0(%rsp),%xmm2
   21dbb:	00 00 
   21dbd:	66 44 0f 28 fa       	movapd %xmm2,%xmm15
   21dc2:	66 0f 28 a4 24 60 02 	movapd 0x260(%rsp),%xmm4
   21dc9:	00 00 
   21dcb:	66 44 0f 5d fc       	minpd  %xmm4,%xmm15
   21dd0:	66 0f 28 bc 24 a0 00 	movapd 0xa0(%rsp),%xmm7
   21dd7:	00 00 
   21dd9:	66 44 0f 28 df       	movapd %xmm7,%xmm11
   21dde:	66 0f 28 9c 24 50 02 	movapd 0x250(%rsp),%xmm3
   21de5:	00 00 
   21de7:	66 44 0f 5d db       	minpd  %xmm3,%xmm11
   21dec:	66 44 0f 54 54 24 70 	andpd  0x70(%rsp),%xmm10
   21df3:	66 0f 54 6c 24 60    	andpd  0x60(%rsp),%xmm5
   21df9:	66 0f 28 c2          	movapd %xmm2,%xmm0
   21dfd:	66 41 0f 5c c2       	subpd  %xmm10,%xmm0
   21e02:	66 0f 28 cf          	movapd %xmm7,%xmm1
   21e06:	66 0f 5c cd          	subpd  %xmm5,%xmm1
   21e0a:	66 0f c2 c4 01       	cmpltpd %xmm4,%xmm0
   21e0f:	66 0f c2 cb 01       	cmpltpd %xmm3,%xmm1
   21e14:	66 41 0f 5c d7       	subpd  %xmm15,%xmm2
   21e19:	66 41 0f 5c fb       	subpd  %xmm11,%xmm7
   21e1e:	66 44 0f 28 35 f9 33 	movapd -0x1cc07(%rip),%xmm14        # 5220 <std::thread::current::id::ID+0x45a8>
   21e25:	fe ff 
   21e27:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   21e2c:	66 41 0f 54 fe       	andpd  %xmm14,%xmm7
   21e31:	66 41 0f 58 d2       	addpd  %xmm10,%xmm2
   21e36:	66 0f 54 d0          	andpd  %xmm0,%xmm2
   21e3a:	66 0f 58 fd          	addpd  %xmm5,%xmm7
   21e3e:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   21e42:	66 0f 28 c2          	movapd %xmm2,%xmm0
   21e46:	66 44 0f 28 05 01 39 	movapd -0x1c6ff(%rip),%xmm8        # 5750 <std::thread::current::id::ID+0x4ad8>
   21e4d:	fe ff 
   21e4f:	66 41 0f c2 c0 01    	cmpltpd %xmm8,%xmm0
   21e55:	66 0f 28 cf          	movapd %xmm7,%xmm1
   21e59:	66 41 0f c2 c8 01    	cmpltpd %xmm8,%xmm1
   21e5f:	66 0f 54 d0          	andpd  %xmm0,%xmm2
   21e63:	66 0f 29 44 24 70    	movapd %xmm0,0x70(%rsp)
   21e69:	66 0f 28 d8          	movapd %xmm0,%xmm3
   21e6d:	66 0f 76 c0          	pcmpeqd %xmm0,%xmm0
   21e71:	66 0f 57 d8          	xorpd  %xmm0,%xmm3
   21e75:	66 0f 29 1c 24       	movapd %xmm3,(%rsp)
   21e7a:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   21e7e:	66 0f 29 8c 24 d0 00 	movapd %xmm1,0xd0(%rsp)
   21e85:	00 00 
   21e87:	66 0f 57 c8          	xorpd  %xmm0,%xmm1
   21e8b:	66 0f 29 4c 24 10    	movapd %xmm1,0x10(%rsp)
   21e91:	66 0f 28 8c 24 a0 01 	movapd 0x1a0(%rsp),%xmm1
   21e98:	00 00 
   21e9a:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
   21e9f:	66 44 0f 28 94 24 e0 	movapd 0x1e0(%rsp),%xmm10
   21ea6:	01 00 00 
   21ea9:	66 45 0f 59 d7       	mulpd  %xmm15,%xmm10
   21eae:	66 0f 28 a4 24 d0 01 	movapd 0x1d0(%rsp),%xmm4
   21eb5:	00 00 
   21eb7:	66 41 0f 59 e3       	mulpd  %xmm11,%xmm4
   21ebc:	66 44 0f 58 94 24 c0 	addpd  0x1c0(%rsp),%xmm10
   21ec3:	01 00 00 
   21ec6:	66 0f 58 a4 24 00 01 	addpd  0x100(%rsp),%xmm4
   21ecd:	00 00 
   21ecf:	66 45 0f 59 d7       	mulpd  %xmm15,%xmm10
   21ed4:	66 41 0f 59 e3       	mulpd  %xmm11,%xmm4
   21ed9:	66 44 0f 58 94 24 90 	addpd  0x90(%rsp),%xmm10
   21ee0:	00 00 00 
   21ee3:	66 0f 58 a4 24 80 00 	addpd  0x80(%rsp),%xmm4
   21eea:	00 00 
   21eec:	66 0f 28 84 24 b0 01 	movapd 0x1b0(%rsp),%xmm0
   21ef3:	00 00 
   21ef5:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   21efa:	66 0f 28 ac 24 10 01 	movapd 0x110(%rsp),%xmm5
   21f01:	00 00 
   21f03:	66 41 0f 59 eb       	mulpd  %xmm11,%xmm5
   21f08:	66 0f 28 b4 24 f0 00 	movapd 0xf0(%rsp),%xmm6
   21f0f:	00 00 
   21f11:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   21f15:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21f1a:	66 44 0f 28 a4 24 f0 	movapd 0x1f0(%rsp),%xmm12
   21f21:	01 00 00 
   21f24:	66 41 0f 58 f4       	addpd  %xmm12,%xmm6
   21f29:	66 44 0f 28 0d ee 35 	movapd -0x1ca12(%rip),%xmm9        # 5520 <std::thread::current::id::ID+0x48a8>
   21f30:	fe ff 
   21f32:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
   21f37:	66 45 0f 54 d6       	andpd  %xmm14,%xmm10
   21f3c:	66 44 0f 58 d6       	addpd  %xmm6,%xmm10
   21f41:	66 0f 28 b4 24 e0 00 	movapd 0xe0(%rsp),%xmm6
   21f48:	00 00 
   21f4a:	66 0f 58 f5          	addpd  %xmm5,%xmm6
   21f4e:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   21f53:	66 0f 28 9c 24 20 01 	movapd 0x120(%rsp),%xmm3
   21f5a:	00 00 
   21f5c:	66 0f 58 f3          	addpd  %xmm3,%xmm6
   21f60:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
   21f65:	66 41 0f 54 e6       	andpd  %xmm14,%xmm4
   21f6a:	66 0f 58 e6          	addpd  %xmm6,%xmm4
   21f6e:	66 44 0f 28 84 24 c0 	movapd 0x2c0(%rsp),%xmm8
   21f75:	02 00 00 
   21f78:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   21f7d:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21f82:	66 44 0f 28 ac 24 a0 	movapd 0x2a0(%rsp),%xmm13
   21f89:	02 00 00 
   21f8c:	66 41 0f 58 f5       	addpd  %xmm13,%xmm6
   21f91:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21f96:	66 41 0f 58 f4       	addpd  %xmm12,%xmm6
   21f9b:	66 41 0f 59 f7       	mulpd  %xmm15,%xmm6
   21fa0:	66 0f 58 b4 24 80 02 	addpd  0x280(%rsp),%xmm6
   21fa7:	00 00 
   21fa9:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
   21fae:	66 44 0f 59 d2       	mulpd  %xmm2,%xmm10
   21fb3:	66 44 0f 58 d6       	addpd  %xmm6,%xmm10
   21fb8:	66 44 0f 28 a4 24 b0 	movapd 0x2b0(%rsp),%xmm12
   21fbf:	02 00 00 
   21fc2:	66 41 0f 28 f4       	movapd %xmm12,%xmm6
   21fc7:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   21fcc:	66 44 0f 28 b4 24 90 	movapd 0x290(%rsp),%xmm14
   21fd3:	02 00 00 
   21fd6:	66 41 0f 58 f6       	addpd  %xmm14,%xmm6
   21fdb:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   21fe0:	66 0f 58 f3          	addpd  %xmm3,%xmm6
   21fe4:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   21fe9:	66 0f 58 b4 24 70 02 	addpd  0x270(%rsp),%xmm6
   21ff0:	00 00 
   21ff2:	66 41 0f 59 f1       	mulpd  %xmm9,%xmm6
   21ff7:	66 0f 59 e7          	mulpd  %xmm7,%xmm4
   21ffb:	66 0f 58 e6          	addpd  %xmm6,%xmm4
   21fff:	66 41 0f 58 c5       	addpd  %xmm13,%xmm0
   22004:	66 41 0f 58 ee       	addpd  %xmm14,%xmm5
   22009:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   2200e:	66 0f 59 f2          	mulpd  %xmm2,%xmm6
   22012:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   22016:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   2201b:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   2201f:	66 0f 58 c5          	addpd  %xmm5,%xmm0
   22023:	66 0f 28 ac 24 90 01 	movapd 0x190(%rsp),%xmm5
   2202a:	00 00 
   2202c:	66 41 0f 59 eb       	mulpd  %xmm11,%xmm5
   22031:	66 0f 58 8c 24 80 01 	addpd  0x180(%rsp),%xmm1
   22038:	00 00 
   2203a:	66 0f 58 ac 24 70 01 	addpd  0x170(%rsp),%xmm5
   22041:	00 00 
   22043:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
   22048:	66 41 0f 59 eb       	mulpd  %xmm11,%xmm5
   2204d:	66 0f 58 8c 24 90 00 	addpd  0x90(%rsp),%xmm1
   22054:	00 00 
   22056:	66 0f 58 ac 24 80 00 	addpd  0x80(%rsp),%xmm5
   2205d:	00 00 
   2205f:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
   22064:	66 45 0f 28 e7       	movapd %xmm15,%xmm12
   22069:	66 41 0f 59 eb       	mulpd  %xmm11,%xmm5
   2206e:	66 0f 58 8c 24 60 01 	addpd  0x160(%rsp),%xmm1
   22075:	00 00 
   22077:	66 0f 58 ac 24 50 01 	addpd  0x150(%rsp),%xmm5
   2207e:	00 00 
   22080:	66 0f 59 f2          	mulpd  %xmm2,%xmm6
   22084:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   22088:	66 0f 59 f2          	mulpd  %xmm2,%xmm6
   2208c:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   22091:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   22095:	66 0f 58 c4          	addpd  %xmm4,%xmm0
   22099:	66 0f 28 e1          	movapd %xmm1,%xmm4
   2209d:	66 0f 28 15 7b 31 fe 	movapd -0x1ce85(%rip),%xmm2        # 5220 <std::thread::current::id::ID+0x45a8>
   220a4:	ff 
   220a5:	66 0f 54 e2          	andpd  %xmm2,%xmm4
   220a9:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
   220ae:	66 44 0f 54 fa       	andpd  %xmm2,%xmm15
   220b3:	66 0f c2 e6 02       	cmplepd %xmm6,%xmm4
   220b8:	66 0f 56 24 24       	orpd   (%rsp),%xmm4
   220bd:	66 44 0f c2 f8 02    	cmplepd %xmm0,%xmm15
   220c3:	66 44 0f 56 7c 24 10 	orpd   0x10(%rsp),%xmm15
   220ca:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   220d0:	66 44 0f 28 05 77 36 	movapd -0x1c989(%rip),%xmm8        # 5750 <std::thread::current::id::ID+0x4ad8>
   220d7:	fe ff 
   220d9:	66 41 0f c2 d0 00    	cmpeqpd %xmm8,%xmm2
   220df:	66 0f 28 5c 24 30    	movapd 0x30(%rsp),%xmm3
   220e5:	66 41 0f c2 d8 00    	cmpeqpd %xmm8,%xmm3
   220eb:	66 0f 28 7c 24 40    	movapd 0x40(%rsp),%xmm7
   220f1:	66 41 0f c2 f8 00    	cmpeqpd %xmm8,%xmm7
   220f7:	66 0f 54 fa          	andpd  %xmm2,%xmm7
   220fb:	66 0f 28 54 24 50    	movapd 0x50(%rsp),%xmm2
   22101:	66 41 0f c2 d0 00    	cmpeqpd %xmm8,%xmm2
   22107:	66 0f 54 d3          	andpd  %xmm3,%xmm2
   2210b:	66 0f c2 f1 01       	cmpltpd %xmm1,%xmm6
   22110:	66 0f c2 c5 01       	cmpltpd %xmm5,%xmm0
   22115:	66 0f 29 64 24 60    	movapd %xmm4,0x60(%rsp)
   2211b:	66 0f 28 cc          	movapd %xmm4,%xmm1
   2211f:	66 0f 55 ce          	andnpd %xmm6,%xmm1
   22123:	66 0f 29 bc 24 a0 00 	movapd %xmm7,0xa0(%rsp)
   2212a:	00 00 
   2212c:	66 0f 54 cf          	andpd  %xmm7,%xmm1
   22130:	66 44 0f 29 bc 24 c0 	movapd %xmm15,0xc0(%rsp)
   22137:	00 00 00 
   2213a:	66 44 0f 55 f8       	andnpd %xmm0,%xmm15
   2213f:	66 0f 29 94 24 b0 00 	movapd %xmm2,0xb0(%rsp)
   22146:	00 00 
   22148:	66 44 0f 54 fa       	andpd  %xmm2,%xmm15
   2214d:	66 0f 50 c9          	movmskpd %xmm1,%ecx
   22151:	66 41 0f 50 f7       	movmskpd %xmm15,%esi
   22156:	c1 e6 02             	shl    $0x2,%esi
   22159:	83 e6 04             	and    $0x4,%esi
   2215c:	09 ce                	or     %ecx,%esi
   2215e:	66 0f 28 9c 24 30 01 	movapd 0x130(%rsp),%xmm3
   22165:	00 00 
   22167:	66 0f 28 94 24 40 01 	movapd 0x140(%rsp),%xmm2
   2216e:	00 00 
   22170:	66 44 0f 29 64 24 10 	movapd %xmm12,0x10(%rsp)
   22177:	66 44 0f 29 1c 24    	movapd %xmm11,(%rsp)
   2217d:	66 45 0f 28 d3       	movapd %xmm11,%xmm10
   22182:	66 44 0f 28 ac 24 d0 	movapd 0x2d0(%rsp),%xmm13
   22189:	02 00 00 
   2218c:	0f 84 fa f7 ff ff    	je     2198c <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x31c>
   22192:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   22199:	1f 84 00 00 00 00 00 
   221a0:	66 41 0f 28 e4       	movapd %xmm12,%xmm4
   221a5:	66 41 0f 28 c5       	movapd %xmm13,%xmm0
   221aa:	66 0f 59 c3          	mulpd  %xmm3,%xmm0
   221ae:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   221b3:	66 0f 59 ea          	mulpd  %xmm2,%xmm5
   221b7:	66 44 0f 28 0d 70 36 	movapd -0x1c990(%rip),%xmm9        # 5830 <std::thread::current::id::ID+0x4bb8>
   221be:	fe ff 
   221c0:	66 41 0f 5d c1       	minpd  %xmm9,%xmm0
   221c5:	66 41 0f 5d e9       	minpd  %xmm9,%xmm5
   221ca:	66 0f 5a f0          	cvtpd2ps %xmm0,%xmm6
   221ce:	66 0f 5a fd          	cvtpd2ps %xmm5,%xmm7
   221d2:	44 0f 5a c6          	cvtps2pd %xmm6,%xmm8
   221d6:	66 0f 14 f7          	unpcklpd %xmm7,%xmm6
   221da:	0f 5a ff             	cvtps2pd %xmm7,%xmm7
   221dd:	66 41 0f c2 c0 01    	cmpltpd %xmm8,%xmm0
   221e3:	66 0f c2 ef 01       	cmpltpd %xmm7,%xmm5
   221e8:	0f c6 c5 88          	shufps $0x88,%xmm5,%xmm0
   221ec:	66 0f fe c6          	paddd  %xmm6,%xmm0
   221f0:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   221f5:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   221fa:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   221ff:	66 41 0f 59 f2       	mulpd  %xmm10,%xmm6
   22204:	66 41 0f 5d e9       	minpd  %xmm9,%xmm5
   22209:	66 0f 5a fd          	cvtpd2ps %xmm5,%xmm7
   2220d:	44 0f 5a c7          	cvtps2pd %xmm7,%xmm8
   22211:	66 41 0f 5d f1       	minpd  %xmm9,%xmm6
   22216:	66 41 0f c2 e8 01    	cmpltpd %xmm8,%xmm5
   2221c:	66 44 0f 5a c6       	cvtpd2ps %xmm6,%xmm8
   22221:	66 0f 5c e3          	subpd  %xmm3,%xmm4
   22225:	66 41 0f 14 f8       	unpcklpd %xmm8,%xmm7
   2222a:	45 0f 5a c0          	cvtps2pd %xmm8,%xmm8
   2222e:	66 41 0f c2 f0 01    	cmpltpd %xmm8,%xmm6
   22234:	66 45 0f 28 f2       	movapd %xmm10,%xmm14
   22239:	66 44 0f 5c f2       	subpd  %xmm2,%xmm14
   2223e:	66 44 0f 28 05 39 31 	movapd -0x1cec7(%rip),%xmm8        # 5380 <std::thread::current::id::ID+0x4708>
   22245:	fe ff 
   22247:	66 41 0f 59 e0       	mulpd  %xmm8,%xmm4
   2224c:	66 45 0f 59 f0       	mulpd  %xmm8,%xmm14
   22251:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   22255:	66 44 0f 58 f2       	addpd  %xmm2,%xmm14
   2225a:	0f c6 ee 88          	shufps $0x88,%xmm6,%xmm5
   2225e:	66 0f fe ef          	paddd  %xmm7,%xmm5
   22262:	66 0f 76 e8          	pcmpeqd %xmm0,%xmm5
   22266:	0f 50 cd             	movmskps %xmm5,%ecx
   22269:	89 ce                	mov    %ecx,%esi
   2226b:	40 c0 e6 04          	shl    $0x4,%sil
   2226f:	41 89 c8             	mov    %ecx,%r8d
   22272:	41 83 e0 01          	and    $0x1,%r8d
   22276:	49 f7 d8             	neg    %r8
   22279:	49 89 c9             	mov    %rcx,%r9
   2227c:	49 c1 e1 3e          	shl    $0x3e,%r9
   22280:	49 c1 f9 3f          	sar    $0x3f,%r9
   22284:	66 49 0f 6e c1       	movq   %r9,%xmm0
   22289:	66 4d 0f 6e c8       	movq   %r8,%xmm9
   2228e:	66 44 0f 6c c8       	punpcklqdq %xmm0,%xmm9
   22293:	48 c1 e1 3d          	shl    $0x3d,%rcx
   22297:	48 c1 f9 3f          	sar    $0x3f,%rcx
   2229b:	40 c0 fe 07          	sar    $0x7,%sil
   2229f:	48 0f be f6          	movsbq %sil,%rsi
   222a3:	66 48 0f 6e f1       	movq   %rcx,%xmm6
   222a8:	66 48 0f 6e c6       	movq   %rsi,%xmm0
   222ad:	66 0f 6c f0          	punpcklqdq %xmm0,%xmm6
   222b1:	66 0f 28 c3          	movapd %xmm3,%xmm0
   222b5:	66 0f c2 c4 01       	cmpltpd %xmm4,%xmm0
   222ba:	66 0f 28 ec          	movapd %xmm4,%xmm5
   222be:	66 41 0f c2 ec 01    	cmpltpd %xmm12,%xmm5
   222c4:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   222c8:	66 0f 28 c2          	movapd %xmm2,%xmm0
   222cc:	66 41 0f c2 c6 01    	cmpltpd %xmm14,%xmm0
   222d2:	66 44 0f df cd       	pandn  %xmm5,%xmm9
   222d7:	66 41 0f 28 ee       	movapd %xmm14,%xmm5
   222dc:	66 41 0f c2 ea 01    	cmpltpd %xmm10,%xmm5
   222e2:	66 0f 54 e8          	andpd  %xmm0,%xmm5
   222e6:	66 0f df f5          	pandn  %xmm5,%xmm6
   222ea:	66 44 0f db c9       	pand   %xmm1,%xmm9
   222ef:	66 41 0f db f7       	pand   %xmm15,%xmm6
   222f4:	66 41 0f 50 c9       	movmskpd %xmm9,%ecx
   222f9:	66 0f 50 f6          	movmskpd %xmm6,%esi
   222fd:	c1 e6 02             	shl    $0x2,%esi
   22300:	83 e6 04             	and    $0x4,%esi
   22303:	09 ce                	or     %ecx,%esi
   22305:	0f 84 55 f6 ff ff    	je     21960 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0x2f0>
   2230b:	66 0f 28 ac 24 a0 01 	movapd 0x1a0(%rsp),%xmm5
   22312:	00 00 
   22314:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   22318:	66 0f 28 bc 24 90 01 	movapd 0x190(%rsp),%xmm7
   2231f:	00 00 
   22321:	66 41 0f 59 fe       	mulpd  %xmm14,%xmm7
   22326:	66 0f 58 ac 24 80 01 	addpd  0x180(%rsp),%xmm5
   2232d:	00 00 
   2232f:	66 0f 58 bc 24 70 01 	addpd  0x170(%rsp),%xmm7
   22336:	00 00 
   22338:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   2233c:	66 41 0f 59 fe       	mulpd  %xmm14,%xmm7
   22341:	66 0f 58 ac 24 90 00 	addpd  0x90(%rsp),%xmm5
   22348:	00 00 
   2234a:	66 0f 58 bc 24 80 00 	addpd  0x80(%rsp),%xmm7
   22351:	00 00 
   22353:	66 0f 59 ec          	mulpd  %xmm4,%xmm5
   22357:	66 41 0f 59 fe       	mulpd  %xmm14,%xmm7
   2235c:	66 0f 58 ac 24 60 01 	addpd  0x160(%rsp),%xmm5
   22363:	00 00 
   22365:	66 0f 58 bc 24 50 01 	addpd  0x150(%rsp),%xmm7
   2236c:	00 00 
   2236e:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   22372:	66 0f c2 c5 01       	cmpltpd %xmm5,%xmm0
   22377:	66 0f 57 ed          	xorpd  %xmm5,%xmm5
   2237b:	66 0f c2 ef 01       	cmpltpd %xmm7,%xmm5
   22380:	66 41 0f 28 f9       	movapd %xmm9,%xmm7
   22385:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   22389:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   2238e:	66 41 0f 55 fc       	andnpd %xmm12,%xmm7
   22393:	66 44 0f 28 de       	movapd %xmm6,%xmm11
   22398:	66 44 0f 54 dd       	andpd  %xmm5,%xmm11
   2239d:	66 44 0f 54 c4       	andpd  %xmm4,%xmm8
   223a2:	66 41 0f 56 f8       	orpd   %xmm8,%xmm7
   223a7:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   223ac:	66 45 0f 55 da       	andnpd %xmm10,%xmm11
   223b1:	66 45 0f 54 c6       	andpd  %xmm14,%xmm8
   223b6:	66 45 0f 56 d8       	orpd   %xmm8,%xmm11
   223bb:	66 41 0f 55 c1       	andnpd %xmm9,%xmm0
   223c0:	66 0f 55 ee          	andnpd %xmm6,%xmm5
   223c4:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   223c8:	66 0f 55 c3          	andnpd %xmm3,%xmm0
   223cc:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   223d0:	66 44 0f 54 f5       	andpd  %xmm5,%xmm14
   223d5:	66 0f 55 ea          	andnpd %xmm2,%xmm5
   223d9:	66 41 0f 56 ee       	orpd   %xmm14,%xmm5
   223de:	66 0f 28 d8          	movapd %xmm0,%xmm3
   223e2:	66 0f 28 d5          	movapd %xmm5,%xmm2
   223e6:	66 44 0f 28 e7       	movapd %xmm7,%xmm12
   223eb:	66 45 0f 28 d3       	movapd %xmm11,%xmm10
   223f0:	e9 ab fd ff ff       	jmp    221a0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::entry::<fearless_simd::generated::sse2::Sse2, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::sse2::Sse2>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::sse2::Sse2>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::sse2::Sse2>; 2]>+0xb30>
   223f5:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   223fa:	0f 29 07             	movaps %xmm0,(%rdi)
   223fd:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   22402:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   22406:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   2240b:	0f 29 47 20          	movaps %xmm0,0x20(%rdi)
   2240f:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   22414:	0f 29 47 30          	movaps %xmm0,0x30(%rdi)
   22418:	48 89 ec             	mov    %rbp,%rsp
   2241b:	5d                   	pop    %rbp
   2241c:	c3                   	ret
   2241d:	cc                   	int3
   2241e:	cc                   	int3
   2241f:	cc                   	int3

0000000000022420 <gpui_canvas::color::gamut::in_gamut>:
   22420:	55                   	push   %rbp
   22421:	53                   	push   %rbx
   22422:	48 83 ec 68          	sub    $0x68,%rsp
   22426:	89 f3                	mov    %esi,%ebx
   22428:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   2242c:	8b 4f 08             	mov    0x8(%rdi),%ecx
   2242f:	8b 57 0c             	mov    0xc(%rdi),%edx
   22432:	89 c8                	mov    %ecx,%eax
   22434:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   2243a:	0f 82 ea 00 00 00    	jb     2252a <gpui_canvas::color::gamut::in_gamut+0x10a>
   22440:	89 c8                	mov    %ecx,%eax
   22442:	85 c9                	test   %ecx,%ecx
   22444:	0f 88 db 00 00 00    	js     22525 <gpui_canvas::color::gamut::in_gamut+0x105>
   2244a:	c1 e8 08             	shr    $0x8,%eax
   2244d:	89 ce                	mov    %ecx,%esi
   2244f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   22456:	48 c1 ee 2e          	shr    $0x2e,%rsi
   2245a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   22461:	48 c1 ef 20          	shr    $0x20,%rdi
   22465:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   2246a:	45 89 ca             	mov    %r9d,%r10d
   2246d:	41 c1 e2 08          	shl    $0x8,%r10d
   22471:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   22476:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   2247b:	45 89 c3             	mov    %r8d,%r11d
   2247e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   22483:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   22489:	c1 ed 16             	shr    $0x16,%ebp
   2248c:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   22492:	29 ee                	sub    %ebp,%esi
   22494:	44 89 dd             	mov    %r11d,%ebp
   22497:	c1 e5 08             	shl    $0x8,%ebp
   2249a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   224a1:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   224a8:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   224ae:	44 09 dd             	or     %r11d,%ebp
   224b1:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   224b8:	45 09 d1             	or     %r10d,%r9d
   224bb:	c1 e6 17             	shl    $0x17,%esi
   224be:	09 ee                	or     %ebp,%esi
   224c0:	c1 e7 0f             	shl    $0xf,%edi
   224c3:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   224c9:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   224ce:	44 09 cf             	or     %r9d,%edi
   224d1:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   224d8:	49 c1 e9 20          	shr    $0x20,%r9
   224dc:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   224e3:	44 29 c8             	sub    %r9d,%eax
   224e6:	45 89 c1             	mov    %r8d,%r9d
   224e9:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   224f0:	41 c1 e0 08          	shl    $0x8,%r8d
   224f4:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   224fb:	45 09 c8             	or     %r9d,%r8d
   224fe:	c1 e0 17             	shl    $0x17,%eax
   22501:	44 09 c0             	or     %r8d,%eax
   22504:	66 0f 6e c6          	movd   %esi,%xmm0
   22508:	66 0f 6e cf          	movd   %edi,%xmm1
   2250c:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   22510:	c1 ea 1e             	shr    $0x1e,%edx
   22513:	31 ed                	xor    %ebp,%ebp
   22515:	48 8d 35 b8 50 fe ff 	lea    -0x1af48(%rip),%rsi        # 75d4 <std::thread::current::id::ID+0x695c>
   2251c:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   22520:	48 01 f2             	add    %rsi,%rdx
   22523:	ff e2                	jmp    *%rdx
   22525:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   2252a:	c1 ea 1e             	shr    $0x1e,%edx
   2252d:	31 ed                	xor    %ebp,%ebp
   2252f:	48 8d 35 9e 50 fe ff 	lea    -0x1af62(%rip),%rsi        # 75d4 <std::thread::current::id::ID+0x695c>
   22536:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   2253a:	48 01 f2             	add    %rsi,%rdx
   2253d:	ff e2                	jmp    *%rdx
   2253f:	40 b5 01             	mov    $0x1,%bpl
   22542:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   22546:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   2254b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   2254f:	66 0f 6e d0          	movd   %eax,%xmm2
   22553:	0f 28 05 c6 2c fe ff 	movaps -0x1d33a(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   2255a:	0f 54 c5             	andps  %xmm5,%xmm0
   2255d:	f2 0f 10 1d b3 4c fe 	movsd  -0x1b34d(%rip),%xmm3        # 7218 <std::thread::current::id::ID+0x65a0>
   22564:	ff 
   22565:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22569:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   2256f:	73 53                	jae    225c4 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   22571:	0f 2e c9             	ucomiss %xmm1,%xmm1
   22574:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22579:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   2257e:	7a 4e                	jp     225ce <gpui_canvas::color::gamut::in_gamut+0x1ae>
   22580:	0f 54 2d 09 32 fe ff 	andps  -0x1cdf7(%rip),%xmm5        # 5790 <std::thread::current::id::ID+0x4b18>
   22587:	0f 56 2d 12 31 fe ff 	orps   -0x1ceee(%rip),%xmm5        # 56a0 <std::thread::current::id::ID+0x4a28>
   2258e:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   22592:	eb 46                	jmp    225da <gpui_canvas::color::gamut::in_gamut+0x1ba>
   22594:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   22597:	66 0f 6e c0          	movd   %eax,%xmm0
   2259b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   2259f:	e9 ad 01 00 00       	jmp    22751 <gpui_canvas::color::gamut::in_gamut+0x331>
   225a4:	85 c9                	test   %ecx,%ecx
   225a6:	0f 88 86 02 00 00    	js     22832 <gpui_canvas::color::gamut::in_gamut+0x412>
   225ac:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   225af:	66 0f 6e c0          	movd   %eax,%xmm0
   225b3:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   225b7:	84 db                	test   %bl,%bl
   225b9:	0f 84 5e 02 00 00    	je     2281d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   225bf:	e9 a7 02 00 00       	jmp    2286b <gpui_canvas::color::gamut::in_gamut+0x44b>
   225c4:	f2 0f 5e 2d b4 4b fe 	divsd  -0x1b44c(%rip),%xmm5        # 7180 <std::thread::current::id::ID+0x6508>
   225cb:	ff 
   225cc:	eb 4b                	jmp    22619 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   225ce:	f2 0f 10 0d 02 4d fe 	movsd  -0x1b2fe(%rip),%xmm1        # 72d8 <std::thread::current::id::ID+0x6660>
   225d5:	ff 
   225d6:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   225da:	f2 0f 58 05 be 4d fe 	addsd  -0x1b242(%rip),%xmm0        # 73a0 <std::thread::current::id::ID+0x6728>
   225e1:	ff 
   225e2:	f2 0f 5e 05 0e 4d fe 	divsd  -0x1b2f2(%rip),%xmm0        # 72f8 <std::thread::current::id::ID+0x6680>
   225e9:	ff 
   225ea:	f2 0f 10 0d 9e 4c fe 	movsd  -0x1b362(%rip),%xmm1        # 7290 <std::thread::current::id::ID+0x6618>
   225f1:	ff 
   225f2:	ff 15 e0 2d 04 00    	call   *0x42de0(%rip)        # 653d8 <pow@GLIBC_2.29>
   225f8:	66 0f 28 e8          	movapd %xmm0,%xmm5
   225fc:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   22601:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   22607:	f2 0f 10 1d 09 4c fe 	movsd  -0x1b3f7(%rip),%xmm3        # 7218 <std::thread::current::id::ID+0x65a0>
   2260e:	ff 
   2260f:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   22614:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   22619:	0f 57 c9             	xorps  %xmm1,%xmm1
   2261c:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22620:	0f 28 05 f9 2b fe ff 	movaps -0x1d407(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22627:	0f 54 c4             	andps  %xmm4,%xmm0
   2262a:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2262e:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   22633:	73 1f                	jae    22654 <gpui_canvas::color::gamut::in_gamut+0x234>
   22635:	0f 2e f6             	ucomiss %xmm6,%xmm6
   22638:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   2263d:	7a 4b                	jp     2268a <gpui_canvas::color::gamut::in_gamut+0x26a>
   2263f:	0f 54 25 4a 31 fe ff 	andps  -0x1ceb6(%rip),%xmm4        # 5790 <std::thread::current::id::ID+0x4b18>
   22646:	0f 56 25 53 30 fe ff 	orps   -0x1cfad(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   2264d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22652:	eb 43                	jmp    22697 <gpui_canvas::color::gamut::in_gamut+0x277>
   22654:	f2 0f 5e 25 24 4b fe 	divsd  -0x1b4dc(%rip),%xmm4        # 7180 <std::thread::current::id::ID+0x6508>
   2265b:	ff 
   2265c:	0f 28 05 bd 2b fe ff 	movaps -0x1d443(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22663:	0f 54 c1             	andps  %xmm1,%xmm0
   22666:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   2266a:	72 7e                	jb     226ea <gpui_canvas::color::gamut::in_gamut+0x2ca>
   2266c:	f2 0f 5e 0d 0c 4b fe 	divsd  -0x1b4f4(%rip),%xmm1        # 7180 <std::thread::current::id::ID+0x6508>
   22673:	ff 
   22674:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22678:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   2267c:	40 84 ed             	test   %bpl,%bpl
   2267f:	0f 85 cc 00 00 00    	jne    22751 <gpui_canvas::color::gamut::in_gamut+0x331>
   22685:	e9 8f 01 00 00       	jmp    22819 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   2268a:	f2 0f 10 0d 46 4c fe 	movsd  -0x1b3ba(%rip),%xmm1        # 72d8 <std::thread::current::id::ID+0x6660>
   22691:	ff 
   22692:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   22697:	f2 0f 58 05 01 4d fe 	addsd  -0x1b2ff(%rip),%xmm0        # 73a0 <std::thread::current::id::ID+0x6728>
   2269e:	ff 
   2269f:	f2 0f 5e 05 51 4c fe 	divsd  -0x1b3af(%rip),%xmm0        # 72f8 <std::thread::current::id::ID+0x6680>
   226a6:	ff 
   226a7:	f2 0f 10 0d e1 4b fe 	movsd  -0x1b41f(%rip),%xmm1        # 7290 <std::thread::current::id::ID+0x6618>
   226ae:	ff 
   226af:	ff 15 23 2d 04 00    	call   *0x42d23(%rip)        # 653d8 <pow@GLIBC_2.29>
   226b5:	66 0f 28 e0          	movapd %xmm0,%xmm4
   226b9:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   226bf:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   226c4:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   226ca:	f2 0f 10 1d 46 4b fe 	movsd  -0x1b4ba(%rip),%xmm3        # 7218 <std::thread::current::id::ID+0x65a0>
   226d1:	ff 
   226d2:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   226d8:	66 0f 28 05 40 2b fe 	movapd -0x1d4c0(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   226df:	ff 
   226e0:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   226e4:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   226e8:	73 82                	jae    2266c <gpui_canvas::color::gamut::in_gamut+0x24c>
   226ea:	0f 2e d2             	ucomiss %xmm2,%xmm2
   226ed:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   226f3:	7a 12                	jp     22707 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   226f5:	66 0f 54 0d 93 30 fe 	andpd  -0x1cf6d(%rip),%xmm1        # 5790 <std::thread::current::id::ID+0x4b18>
   226fc:	ff 
   226fd:	66 0f 56 0d 9b 2f fe 	orpd   -0x1d065(%rip),%xmm1        # 56a0 <std::thread::current::id::ID+0x4a28>
   22704:	ff 
   22705:	eb 08                	jmp    2270f <gpui_canvas::color::gamut::in_gamut+0x2ef>
   22707:	f2 0f 10 0d c9 4b fe 	movsd  -0x1b437(%rip),%xmm1        # 72d8 <std::thread::current::id::ID+0x6660>
   2270e:	ff 
   2270f:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   22715:	f2 0f 58 05 83 4c fe 	addsd  -0x1b37d(%rip),%xmm0        # 73a0 <std::thread::current::id::ID+0x6728>
   2271c:	ff 
   2271d:	f2 0f 5e 05 d3 4b fe 	divsd  -0x1b42d(%rip),%xmm0        # 72f8 <std::thread::current::id::ID+0x6680>
   22724:	ff 
   22725:	f2 0f 10 0d 63 4b fe 	movsd  -0x1b49d(%rip),%xmm1        # 7290 <std::thread::current::id::ID+0x6618>
   2272c:	ff 
   2272d:	ff 15 a5 2c 04 00    	call   *0x42ca5(%rip)        # 653d8 <pow@GLIBC_2.29>
   22733:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   22739:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   2273e:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   22744:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22748:	40 84 ed             	test   %bpl,%bpl
   2274b:	0f 84 c8 00 00 00    	je     22819 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22751:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22755:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   2275a:	66 0f 59 15 5e 2f fe 	mulpd  -0x1d0a2(%rip),%xmm2        # 56c0 <std::thread::current::id::ID+0x4a48>
   22761:	ff 
   22762:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   22766:	66 0f 16 1d 0a 4c fe 	movhpd -0x1b3f6(%rip),%xmm3        # 7378 <std::thread::current::id::ID+0x6700>
   2276d:	ff 
   2276e:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   22772:	0f 28 c8             	movaps %xmm0,%xmm1
   22775:	0f 16 c8             	movlhps %xmm0,%xmm1
   22778:	66 0f 59 0d c0 2a fe 	mulpd  -0x1d540(%rip),%xmm1        # 5240 <std::thread::current::id::ID+0x45c8>
   2277f:	ff 
   22780:	66 0f 58 da          	addpd  %xmm2,%xmm3
   22784:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22788:	f2 0f 10 15 48 4a fe 	movsd  -0x1b5b8(%rip),%xmm2        # 71d8 <std::thread::current::id::ID+0x6560>
   2278f:	ff 
   22790:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   22794:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22798:	66 0f 59 2d c0 2a fe 	mulpd  -0x1d540(%rip),%xmm5        # 5260 <std::thread::current::id::ID+0x45e8>
   2279f:	ff 
   227a0:	66 0f 28 c5          	movapd %xmm5,%xmm0
   227a4:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   227a8:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   227ac:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   227b0:	f2 0f 10 15 e0 49 fe 	movsd  -0x1b620(%rip),%xmm2        # 7198 <std::thread::current::id::ID+0x6520>
   227b7:	ff 
   227b8:	66 0f 28 d9          	movapd %xmm1,%xmm3
   227bc:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   227c0:	66 0f 59 1d 98 2d fe 	mulpd  -0x1d268(%rip),%xmm3        # 5560 <std::thread::current::id::ID+0x48e8>
   227c7:	ff 
   227c8:	66 0f 28 e1          	movapd %xmm1,%xmm4
   227cc:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   227d1:	66 0f 59 25 b7 2c fe 	mulpd  -0x1d349(%rip),%xmm4        # 5490 <std::thread::current::id::ID+0x4818>
   227d8:	ff 
   227d9:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   227dd:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   227e1:	66 0f 28 e9          	movapd %xmm1,%xmm5
   227e5:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   227e9:	66 0f 59 2d af 2f fe 	mulpd  -0x1d051(%rip),%xmm5        # 57a0 <std::thread::current::id::ID+0x4b28>
   227f0:	ff 
   227f1:	66 0f 28 c4          	movapd %xmm4,%xmm0
   227f5:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   227f9:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   227fd:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22801:	66 0f 59 0d 37 2d fe 	mulpd  -0x1d2c9(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   22808:	ff 
   22809:	66 0f 28 c1          	movapd %xmm1,%xmm0
   2280d:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   22811:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22815:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22819:	84 db                	test   %bl,%bl
   2281b:	75 4e                	jne    2286b <gpui_canvas::color::gamut::in_gamut+0x44b>
   2281d:	31 c0                	xor    %eax,%eax
   2281f:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22823:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22827:	0f 83 08 01 00 00    	jae    22935 <gpui_canvas::color::gamut::in_gamut+0x515>
   2282d:	e9 41 01 00 00       	jmp    22973 <gpui_canvas::color::gamut::in_gamut+0x553>
   22832:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   22836:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   2283a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2283e:	0f 2e c8             	ucomiss %xmm0,%xmm1
   22841:	0f 85 35 01 00 00    	jne    2297c <gpui_canvas::color::gamut::in_gamut+0x55c>
   22847:	0f 8a 2f 01 00 00    	jp     2297c <gpui_canvas::color::gamut::in_gamut+0x55c>
   2284d:	0f 57 c9             	xorps  %xmm1,%xmm1
   22850:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22854:	0f 28 c1             	movaps %xmm1,%xmm0
   22857:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2285b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   2285f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22863:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22867:	84 db                	test   %bl,%bl
   22869:	74 b2                	je     2281d <gpui_canvas::color::gamut::in_gamut+0x3fd>
   2286b:	66 0f 28 0d 6d 2a fe 	movapd -0x1d593(%rip),%xmm1        # 52e0 <std::thread::current::id::ID+0x4668>
   22872:	ff 
   22873:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   22877:	66 0f 28 d5          	movapd %xmm5,%xmm2
   2287b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22880:	66 0f 59 15 98 2e fe 	mulpd  -0x1d168(%rip),%xmm2        # 5720 <std::thread::current::id::ID+0x4aa8>
   22887:	ff 
   22888:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   2288c:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22890:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   22894:	66 0f 59 0d f4 2a fe 	mulpd  -0x1d50c(%rip),%xmm1        # 5390 <std::thread::current::id::ID+0x4718>
   2289b:	ff 
   2289c:	f2 0f 10 1d 84 49 fe 	movsd  -0x1b67c(%rip),%xmm3        # 7228 <std::thread::current::id::ID+0x65b0>
   228a3:	ff 
   228a4:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   228a8:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   228ac:	66 0f 59 2d ec 2a fe 	mulpd  -0x1d514(%rip),%xmm5        # 53a0 <std::thread::current::id::ID+0x4728>
   228b3:	ff 
   228b4:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   228b8:	66 0f 28 c5          	movapd %xmm5,%xmm0
   228bc:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   228c0:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   228c4:	66 0f 28 d1          	movapd %xmm1,%xmm2
   228c8:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   228cd:	66 0f 59 15 7b 29 fe 	mulpd  -0x1d685(%rip),%xmm2        # 5250 <std::thread::current::id::ID+0x45d8>
   228d4:	ff 
   228d5:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   228d9:	66 0f 28 1d df 29 fe 	movapd -0x1d621(%rip),%xmm3        # 52c0 <std::thread::current::id::ID+0x4648>
   228e0:	ff 
   228e1:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   228e5:	66 0f 5c da          	subpd  %xmm2,%xmm3
   228e9:	66 0f 28 e8          	movapd %xmm0,%xmm5
   228ed:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   228f1:	66 0f 59 2d 77 2a fe 	mulpd  -0x1d589(%rip),%xmm5        # 5370 <std::thread::current::id::ID+0x46f8>
   228f8:	ff 
   228f9:	66 0f 28 d3          	movapd %xmm3,%xmm2
   228fd:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   22901:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   22905:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   22909:	66 0f 59 0d ef 2c fe 	mulpd  -0x1d311(%rip),%xmm1        # 5600 <std::thread::current::id::ID+0x4988>
   22910:	ff 
   22911:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22915:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   22919:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   2291d:	f2 0f 59 05 ab 49 fe 	mulsd  -0x1b655(%rip),%xmm0        # 72d0 <std::thread::current::id::ID+0x6658>
   22924:	ff 
   22925:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22929:	31 c0                	xor    %eax,%eax
   2292b:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2292f:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22933:	72 3e                	jb     22973 <gpui_canvas::color::gamut::in_gamut+0x553>
   22935:	f2 0f 10 0d 03 49 fe 	movsd  -0x1b6fd(%rip),%xmm1        # 7240 <std::thread::current::id::ID+0x65c8>
   2293c:	ff 
   2293d:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22941:	72 30                	jb     22973 <gpui_canvas::color::gamut::in_gamut+0x553>
   22943:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   22947:	31 c0                	xor    %eax,%eax
   22949:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   2294d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   22951:	72 20                	jb     22973 <gpui_canvas::color::gamut::in_gamut+0x553>
   22953:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22957:	72 1a                	jb     22973 <gpui_canvas::color::gamut::in_gamut+0x553>
   22959:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   2295d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   22962:	f2 0f c2 05 d5 48 fe 	cmplesd -0x1b72b(%rip),%xmm0        # 7240 <std::thread::current::id::ID+0x65c8>
   22969:	ff 02 
   2296b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2296f:	66 0f 7e c0          	movd   %xmm0,%eax
   22973:	24 01                	and    $0x1,%al
   22975:	48 83 c4 68          	add    $0x68,%rsp
   22979:	5b                   	pop    %rbx
   2297a:	5d                   	pop    %rbp
   2297b:	c3                   	ret
   2297c:	66 0f 6e c0          	movd   %eax,%xmm0
   22980:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22984:	f2 0f 59 05 e4 49 fe 	mulsd  -0x1b61c(%rip),%xmm0        # 7370 <std::thread::current::id::ID+0x66f8>
   2298b:	ff 
   2298c:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   22991:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   22996:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   2299a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   229a0:	ff 15 5a 2a 04 00    	call   *0x42a5a(%rip)        # 65400 <sincos@GLIBC_2.2.5>
   229a6:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   229ab:	0f 57 c9             	xorps  %xmm1,%xmm1
   229ae:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   229b2:	0f 28 04 24          	movaps (%rsp),%xmm0
   229b6:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   229ba:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   229c0:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   229c4:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   229ca:	f2 0f 10 1d 76 49 fe 	movsd  -0x1b68a(%rip),%xmm3        # 7348 <std::thread::current::id::ID+0x66d0>
   229d1:	ff 
   229d2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   229d6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   229da:	f2 0f 10 2d fe 48 fe 	movsd  -0x1b702(%rip),%xmm5        # 72e0 <std::thread::current::id::ID+0x6668>
   229e1:	ff 
   229e2:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   229e6:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   229ea:	f2 0f 10 1d ae 48 fe 	movsd  -0x1b752(%rip),%xmm3        # 72a0 <std::thread::current::id::ID+0x6628>
   229f1:	ff 
   229f2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   229f6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   229fa:	f2 0f 10 35 a6 49 fe 	movsd  -0x1b65a(%rip),%xmm6        # 73a8 <std::thread::current::id::ID+0x6730>
   22a01:	ff 
   22a02:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   22a06:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   22a0a:	f2 0f 59 15 1e 49 fe 	mulsd  -0x1b6e2(%rip),%xmm2        # 7330 <std::thread::current::id::ID+0x66b8>
   22a11:	ff 
   22a12:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   22a16:	f2 0f 59 05 6a 47 fe 	mulsd  -0x1b896(%rip),%xmm0        # 7188 <std::thread::current::id::ID+0x6510>
   22a1d:	ff 
   22a1e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22a22:	66 0f 28 e5          	movapd %xmm5,%xmm4
   22a26:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   22a2a:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   22a2e:	66 0f 28 de          	movapd %xmm6,%xmm3
   22a32:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22a36:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22a3a:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22a3e:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22a42:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22a46:	f2 0f 10 05 62 49 fe 	movsd  -0x1b69e(%rip),%xmm0        # 73b0 <std::thread::current::id::ID+0x6738>
   22a4d:	ff 
   22a4e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   22a52:	f2 0f 10 15 fe 47 fe 	movsd  -0x1b802(%rip),%xmm2        # 7258 <std::thread::current::id::ID+0x65e0>
   22a59:	ff 
   22a5a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   22a5e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   22a62:	f2 0f 10 05 f6 47 fe 	movsd  -0x1b80a(%rip),%xmm0        # 7260 <std::thread::current::id::ID+0x65e8>
   22a69:	ff 
   22a6a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22a6e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22a72:	f2 0f 10 15 1e 47 fe 	movsd  -0x1b8e2(%rip),%xmm2        # 7198 <std::thread::current::id::ID+0x6520>
   22a79:	ff 
   22a7a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   22a7e:	66 0f 59 25 da 2c fe 	mulpd  -0x1d326(%rip),%xmm4        # 5760 <std::thread::current::id::ID+0x4ae8>
   22a85:	ff 
   22a86:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   22a8a:	66 0f 59 1d de 2c fe 	mulpd  -0x1d322(%rip),%xmm3        # 5770 <std::thread::current::id::ID+0x4af8>
   22a91:	ff 
   22a92:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   22a96:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   22a9a:	66 0f 59 0d 8e 2a fe 	mulpd  -0x1d572(%rip),%xmm1        # 5530 <std::thread::current::id::ID+0x48b8>
   22aa1:	ff 
   22aa2:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22aa6:	e9 0d fd ff ff       	jmp    227b8 <gpui_canvas::color::gamut::in_gamut+0x398>
