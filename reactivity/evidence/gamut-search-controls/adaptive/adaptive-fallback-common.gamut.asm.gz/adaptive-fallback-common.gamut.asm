000000000001f7d0 <<gpui_canvas::color::OutputProfile>::max_chroma>:
   1f7d0:	66 0f 7e c1          	movd   %xmm0,%ecx
   1f7d4:	81 e1 ff ff ff 7f    	and    $0x7fffffff,%ecx
   1f7da:	b8 0d 00 00 00       	mov    $0xd,%eax
   1f7df:	81 f9 ff ff 7f 7f    	cmp    $0x7f7fffff,%ecx
   1f7e5:	7f 38                	jg     1f81f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f7e7:	0f 57 e4             	xorps  %xmm4,%xmm4
   1f7ea:	0f 57 d2             	xorps  %xmm2,%xmm2
   1f7ed:	f3 0f c2 d0 06       	cmpnless %xmm0,%xmm2
   1f7f2:	0f 28 d8             	movaps %xmm0,%xmm3
   1f7f5:	f3 0f c2 1d aa 60 fe 	cmpnless -0x19f56(%rip),%xmm3        # 58a8 <std::thread::current::id::ID+0x4c30>
   1f7fc:	ff 06 
   1f7fe:	0f 56 da             	orps   %xmm2,%xmm3
   1f801:	66 0f 7e d9          	movd   %xmm3,%ecx
   1f805:	66 0f 7e ca          	movd   %xmm1,%edx
   1f809:	81 e2 ff ff ff 7f    	and    $0x7fffffff,%edx
   1f80f:	81 fa 00 00 80 7f    	cmp    $0x7f800000,%edx
   1f815:	0f 9d c2             	setge  %dl
   1f818:	08 ca                	or     %cl,%dl
   1f81a:	f6 c2 01             	test   $0x1,%dl
   1f81d:	74 01                	je     1f820 <<gpui_canvas::color::OutputProfile>::max_chroma+0x50>
   1f81f:	c3                   	ret
   1f820:	0f 2e c4             	ucomiss %xmm4,%xmm0
   1f823:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
   1f828:	75 02                	jne    1f82c <<gpui_canvas::color::OutputProfile>::max_chroma+0x5c>
   1f82a:	7b f3                	jnp    1f81f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f82c:	0f 2e 05 75 60 fe ff 	ucomiss -0x19f8b(%rip),%xmm0        # 58a8 <std::thread::current::id::ID+0x4c30>
   1f833:	75 02                	jne    1f837 <<gpui_canvas::color::OutputProfile>::max_chroma+0x67>
   1f835:	7b e8                	jnp    1f81f <<gpui_canvas::color::OutputProfile>::max_chroma+0x4f>
   1f837:	53                   	push   %rbx
   1f838:	48 83 ec 10          	sub    $0x10,%rsp
   1f83c:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   1f842:	89 fb                	mov    %edi,%ebx
   1f844:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f847:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   1f84b:	f2 0f 10 0d 5d 7b fe 	movsd  -0x184a3(%rip),%xmm1        # 73b0 <std::thread::current::id::ID+0x6738>
   1f852:	ff 
   1f853:	ff 15 27 60 04 00    	call   *0x46027(%rip)        # 65880 <_DYNAMIC+0x368>
   1f859:	f2 0f 10 1d 4f 7b fe 	movsd  -0x184b1(%rip),%xmm3        # 73b0 <std::thread::current::id::ID+0x6738>
   1f860:	ff 
   1f861:	f2 0f 58 d8          	addsd  %xmm0,%xmm3
   1f865:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f869:	66 0f 28 d0          	movapd %xmm0,%xmm2
   1f86d:	f2 0f c2 d1 01       	cmpltsd %xmm1,%xmm2
   1f872:	66 0f 54 da          	andpd  %xmm2,%xmm3
   1f876:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   1f87a:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   1f87e:	66 0f 2e 15 62 7a fe 	ucomisd -0x1859e(%rip),%xmm2        # 72e8 <std::thread::current::id::ID+0x6670>
   1f885:	ff 
   1f886:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   1f88a:	73 0f                	jae    1f89b <<gpui_canvas::color::OutputProfile>::max_chroma+0xcb>
   1f88c:	0f 57 c0             	xorps  %xmm0,%xmm0
   1f88f:	f2 0f 5a c2          	cvtsd2ss %xmm2,%xmm0
   1f893:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   1f898:	0f 55 c8             	andnps %xmm0,%xmm1
   1f89b:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   1f8a1:	0f b6 fb             	movzbl %bl,%edi
   1f8a4:	48 83 c4 10          	add    $0x10,%rsp
   1f8a8:	5b                   	pop    %rbx
   1f8a9:	e9 62 22 00 00       	jmp    21b10 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>
   1f8ae:	cc                   	int3
   1f8af:	cc                   	int3

00000000000203e0 <<gpui_canvas::color::Color>::fit_chroma>:
   203e0:	55                   	push   %rbp
   203e1:	41 57                	push   %r15
   203e3:	41 56                	push   %r14
   203e5:	41 54                	push   %r12
   203e7:	53                   	push   %rbx
   203e8:	48 83 ec 30          	sub    $0x30,%rsp
   203ec:	48 89 fb             	mov    %rdi,%rbx
   203ef:	44 8b 66 08          	mov    0x8(%rsi),%r12d
   203f3:	44 8b 7e 0c          	mov    0xc(%rsi),%r15d
   203f7:	41 81 ff 00 00 00 c0 	cmp    $0xc0000000,%r15d
   203fe:	0f 92 c0             	setb   %al
   20401:	45 85 e4             	test   %r12d,%r12d
   20404:	0f 99 c1             	setns  %cl
   20407:	08 c1                	or     %al,%cl
   20409:	80 f9 01             	cmp    $0x1,%cl
   2040c:	75 09                	jne    20417 <<gpui_canvas::color::Color>::fit_chroma+0x37>
   2040e:	c7 43 04 0d 00 00 00 	movl   $0xd,0x4(%rbx)
   20415:	eb 4a                	jmp    20461 <<gpui_canvas::color::Color>::fit_chroma+0x81>
   20417:	49 89 f6             	mov    %rsi,%r14
   2041a:	0f 10 06             	movups (%rsi),%xmm0
   2041d:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   20422:	0f b6 ea             	movzbl %dl,%ebp
   20425:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2042a:	89 ee                	mov    %ebp,%esi
   2042c:	e8 af 24 00 00       	call   228e0 <gpui_canvas::color::gamut::in_gamut>
   20431:	84 c0                	test   %al,%al
   20433:	74 0c                	je     20441 <<gpui_canvas::color::Color>::fit_chroma+0x61>
   20435:	41 0f 10 06          	movups (%r14),%xmm0
   20439:	0f 11 43 04          	movups %xmm0,0x4(%rbx)
   2043d:	31 c0                	xor    %eax,%eax
   2043f:	eb 25                	jmp    20466 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   20441:	41 8b 16             	mov    (%r14),%edx
   20444:	89 d6                	mov    %edx,%esi
   20446:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   2044c:	b8 0d 00 00 00       	mov    $0xd,%eax
   20451:	31 c9                	xor    %ecx,%ecx
   20453:	81 fe ff ff 7f 7f    	cmp    $0x7f7fffff,%esi
   20459:	7e 1d                	jle    20478 <<gpui_canvas::color::Color>::fit_chroma+0x98>
   2045b:	89 43 04             	mov    %eax,0x4(%rbx)
   2045e:	89 4b 08             	mov    %ecx,0x8(%rbx)
   20461:	b8 01 00 00 00       	mov    $0x1,%eax
   20466:	89 03                	mov    %eax,(%rbx)
   20468:	48 89 d8             	mov    %rbx,%rax
   2046b:	48 83 c4 30          	add    $0x30,%rsp
   2046f:	5b                   	pop    %rbx
   20470:	41 5c                	pop    %r12
   20472:	41 5e                	pop    %r14
   20474:	41 5f                	pop    %r15
   20476:	5d                   	pop    %rbp
   20477:	c3                   	ret
   20478:	44 89 e6             	mov    %r12d,%esi
   2047b:	81 e6 ff ff ff 7f    	and    $0x7fffffff,%esi
   20481:	66 0f 6e c6          	movd   %esi,%xmm0
   20485:	0f 2e 05 54 54 fe ff 	ucomiss -0x1abac(%rip),%xmm0        # 58e0 <std::thread::current::id::ID+0x4c68>
   2048c:	74 cd                	je     2045b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   2048e:	66 0f 6e d2          	movd   %edx,%xmm2
   20492:	0f 57 c9             	xorps  %xmm1,%xmm1
   20495:	0f 2e d1             	ucomiss %xmm1,%xmm2
   20498:	72 c1                	jb     2045b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   2049a:	f3 0f 10 0d 06 54 fe 	movss  -0x1abfa(%rip),%xmm1        # 58a8 <std::thread::current::id::ID+0x4c30>
   204a1:	ff 
   204a2:	0f 2e ca             	ucomiss %xmm2,%xmm1
   204a5:	72 b4                	jb     2045b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   204a7:	f3 41 0f 10 5e 04    	movss  0x4(%r14),%xmm3
   204ad:	31 c9                	xor    %ecx,%ecx
   204af:	0f 57 c9             	xorps  %xmm1,%xmm1
   204b2:	0f 2e d1             	ucomiss %xmm1,%xmm2
   204b5:	f3 0f 11 54 24 0c    	movss  %xmm2,0xc(%rsp)
   204bb:	75 02                	jne    204bf <<gpui_canvas::color::Color>::fit_chroma+0xdf>
   204bd:	7b 63                	jnp    20522 <<gpui_canvas::color::Color>::fit_chroma+0x142>
   204bf:	0f 2e 15 e2 53 fe ff 	ucomiss -0x1ac1e(%rip),%xmm2        # 58a8 <std::thread::current::id::ID+0x4c30>
   204c6:	75 02                	jne    204ca <<gpui_canvas::color::Color>::fit_chroma+0xea>
   204c8:	7b 58                	jnp    20522 <<gpui_canvas::color::Color>::fit_chroma+0x142>
   204ca:	0f 29 5c 24 20       	movaps %xmm3,0x20(%rsp)
   204cf:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   204d3:	f2 0f 10 0d d5 6e fe 	movsd  -0x1912b(%rip),%xmm1        # 73b0 <std::thread::current::id::ID+0x6738>
   204da:	ff 
   204db:	ff 15 9f 53 04 00    	call   *0x4539f(%rip)        # 65880 <_DYNAMIC+0x368>
   204e1:	66 0f 2e 05 ff 6d fe 	ucomisd -0x19201(%rip),%xmm0        # 72e8 <std::thread::current::id::ID+0x6670>
   204e8:	ff 
   204e9:	0f 57 c9             	xorps  %xmm1,%xmm1
   204ec:	73 0c                	jae    204fa <<gpui_canvas::color::Color>::fit_chroma+0x11a>
   204ee:	f2 0f 5a c0          	cvtsd2ss %xmm0,%xmm0
   204f2:	f3 0f c2 c8 00       	cmpeqss %xmm0,%xmm1
   204f7:	0f 55 c8             	andnps %xmm0,%xmm1
   204fa:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   20500:	89 ef                	mov    %ebp,%edi
   20502:	e8 09 16 00 00       	call   21b10 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>
   20507:	f3 0f 10 54 24 0c    	movss  0xc(%rsp),%xmm2
   2050d:	48 89 c1             	mov    %rax,%rcx
   20510:	48 c1 e9 20          	shr    $0x20,%rcx
   20514:	83 f8 ff             	cmp    $0xffffffff,%eax
   20517:	0f 28 5c 24 20       	movaps 0x20(%rsp),%xmm3
   2051c:	0f 85 39 ff ff ff    	jne    2045b <<gpui_canvas::color::Color>::fit_chroma+0x7b>
   20522:	66 0f 6e c1          	movd   %ecx,%xmm0
   20526:	0f 28 cb             	movaps %xmm3,%xmm1
   20529:	f3 0f 5d c8          	minss  %xmm0,%xmm1
   2052d:	0f 28 e1             	movaps %xmm1,%xmm4
   20530:	f3 0f c2 e1 03       	cmpunordss %xmm1,%xmm4
   20535:	0f 28 c4             	movaps %xmm4,%xmm0
   20538:	0f 55 c1             	andnps %xmm1,%xmm0
   2053b:	0f 54 e3             	andps  %xmm3,%xmm4
   2053e:	0f 56 e0             	orps   %xmm0,%xmm4
   20541:	f3 0f 11 54 24 10    	movss  %xmm2,0x10(%rsp)
   20547:	0f 29 64 24 20       	movaps %xmm4,0x20(%rsp)
   2054c:	f3 0f 11 64 24 14    	movss  %xmm4,0x14(%rsp)
   20552:	44 89 64 24 18       	mov    %r12d,0x18(%rsp)
   20557:	44 89 7c 24 1c       	mov    %r15d,0x1c(%rsp)
   2055c:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   20561:	89 ee                	mov    %ebp,%esi
   20563:	e8 78 23 00 00       	call   228e0 <gpui_canvas::color::gamut::in_gamut>
   20568:	84 c0                	test   %al,%al
   2056a:	74 24                	je     20590 <<gpui_canvas::color::Color>::fit_chroma+0x1b0>
   2056c:	0f 28 44 24 20       	movaps 0x20(%rsp),%xmm0
   20571:	f3 0f 11 43 08       	movss  %xmm0,0x8(%rbx)
   20576:	44 89 63 0c          	mov    %r12d,0xc(%rbx)
   2057a:	44 89 7b 10          	mov    %r15d,0x10(%rbx)
   2057e:	31 c0                	xor    %eax,%eax
   20580:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   20586:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   2058b:	e9 d6 fe ff ff       	jmp    20466 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   20590:	b8 01 00 00 00       	mov    $0x1,%eax
   20595:	f3 0f 10 05 03 53 fe 	movss  -0x1acfd(%rip),%xmm0        # 58a0 <std::thread::current::id::ID+0x4c28>
   2059c:	ff 
   2059d:	f3 0f 11 43 04       	movss  %xmm0,0x4(%rbx)
   205a2:	e9 bf fe ff ff       	jmp    20466 <<gpui_canvas::color::Color>::fit_chroma+0x86>
   205a7:	cc                   	int3
   205a8:	cc                   	int3
   205a9:	cc                   	int3
   205aa:	cc                   	int3
   205ab:	cc                   	int3
   205ac:	cc                   	int3
   205ad:	cc                   	int3
   205ae:	cc                   	int3
   205af:	cc                   	int3

0000000000020ab0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>:
   20ab0:	55                   	push   %rbp
   20ab1:	48 89 e5             	mov    %rsp,%rbp
   20ab4:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   20ab8:	48 81 ec 60 04 00 00 	sub    $0x460,%rsp
   20abf:	66 0f 28 2e          	movapd (%rsi),%xmm5
   20ac3:	66 0f 28 76 10       	movapd 0x10(%rsi),%xmm6
   20ac8:	66 0f 28 7e 20       	movapd 0x20(%rsi),%xmm7
   20acd:	66 44 0f 28 46 30    	movapd 0x30(%rsi),%xmm8
   20ad3:	66 44 0f 28 4e 60    	movapd 0x60(%rsi),%xmm9
   20ad9:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   20add:	66 41 0f c2 c9 05    	cmpnltpd %xmm9,%xmm1
   20ae3:	66 44 0f 28 15 64 4c 	movapd -0x1b39c(%rip),%xmm10        # 5750 <std::thread::current::id::ID+0x4ad8>
   20aea:	fe ff 
   20aec:	66 41 0f 54 ca       	andpd  %xmm10,%xmm1
   20af1:	66 0f 29 4c 24 40    	movapd %xmm1,0x40(%rsp)
   20af7:	0f 28 62 20          	movaps 0x20(%rdx),%xmm4
   20afb:	0f 28 4a 30          	movaps 0x30(%rdx),%xmm1
   20aff:	0f 29 8c 24 b0 03 00 	movaps %xmm1,0x3b0(%rsp)
   20b06:	00 
   20b07:	0f 29 a4 24 a0 03 00 	movaps %xmm4,0x3a0(%rsp)
   20b0e:	00 
   20b0f:	0f 28 52 10          	movaps 0x10(%rdx),%xmm2
   20b13:	0f 29 94 24 90 03 00 	movaps %xmm2,0x390(%rsp)
   20b1a:	00 
   20b1b:	0f 28 1a             	movaps (%rdx),%xmm3
   20b1e:	0f 29 9c 24 80 03 00 	movaps %xmm3,0x380(%rsp)
   20b25:	00 
   20b26:	0f 29 9c 24 40 03 00 	movaps %xmm3,0x340(%rsp)
   20b2d:	00 
   20b2e:	0f 29 94 24 50 03 00 	movaps %xmm2,0x350(%rsp)
   20b35:	00 
   20b36:	0f 29 8c 24 70 03 00 	movaps %xmm1,0x370(%rsp)
   20b3d:	00 
   20b3e:	0f 29 a4 24 60 03 00 	movaps %xmm4,0x360(%rsp)
   20b45:	00 
   20b46:	0f 28 8c 24 70 03 00 	movaps 0x370(%rsp),%xmm1
   20b4d:	00 
   20b4e:	0f 29 8c 24 10 04 00 	movaps %xmm1,0x410(%rsp)
   20b55:	00 
   20b56:	0f 28 a4 24 30 03 00 	movaps 0x330(%rsp),%xmm4
   20b5d:	00 
   20b5e:	0f 28 8c 24 40 03 00 	movaps 0x340(%rsp),%xmm1
   20b65:	00 
   20b66:	0f 28 94 24 50 03 00 	movaps 0x350(%rsp),%xmm2
   20b6d:	00 
   20b6e:	0f 28 9c 24 60 03 00 	movaps 0x360(%rsp),%xmm3
   20b75:	00 
   20b76:	0f 29 9c 24 00 04 00 	movaps %xmm3,0x400(%rsp)
   20b7d:	00 
   20b7e:	0f 29 94 24 f0 03 00 	movaps %xmm2,0x3f0(%rsp)
   20b85:	00 
   20b86:	0f 29 8c 24 e0 03 00 	movaps %xmm1,0x3e0(%rsp)
   20b8d:	00 
   20b8e:	0f 29 a4 24 d0 03 00 	movaps %xmm4,0x3d0(%rsp)
   20b95:	00 
   20b96:	66 44 0f 29 94 24 20 	movapd %xmm10,0x420(%rsp)
   20b9d:	04 00 00 
   20ba0:	66 44 0f 29 94 24 30 	movapd %xmm10,0x430(%rsp)
   20ba7:	04 00 00 
   20baa:	48 8d 84 24 e0 03 00 	lea    0x3e0(%rsp),%rax
   20bb1:	00 
   20bb2:	66 0f 28 0d 36 48 fe 	movapd -0x1b7ca(%rip),%xmm1        # 53f0 <std::thread::current::id::ID+0x4778>
   20bb9:	ff 
   20bba:	66 0f 28 d5          	movapd %xmm5,%xmm2
   20bbe:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   20bc2:	66 0f 29 94 24 c0 01 	movapd %xmm2,0x1c0(%rsp)
   20bc9:	00 00 
   20bcb:	66 0f 28 d6          	movapd %xmm6,%xmm2
   20bcf:	66 0f 59 d1          	mulpd  %xmm1,%xmm2
   20bd3:	66 0f 28 df          	movapd %xmm7,%xmm3
   20bd7:	66 0f 58 df          	addpd  %xmm7,%xmm3
   20bdb:	66 0f 29 9c 24 b0 01 	movapd %xmm3,0x1b0(%rsp)
   20be2:	00 00 
   20be4:	66 41 0f 28 d8       	movapd %xmm8,%xmm3
   20be9:	66 41 0f 58 d8       	addpd  %xmm8,%xmm3
   20bee:	66 0f 28 25 2a 46 fe 	movapd -0x1b9d6(%rip),%xmm4        # 5220 <std::thread::current::id::ID+0x45a8>
   20bf5:	ff 
   20bf6:	66 0f 29 ac 24 70 01 	movapd %xmm5,0x170(%rsp)
   20bfd:	00 00 
   20bff:	66 0f 54 ec          	andpd  %xmm4,%xmm5
   20c03:	66 0f 29 ac 24 90 02 	movapd %xmm5,0x290(%rsp)
   20c0a:	00 00 
   20c0c:	66 0f 59 e9          	mulpd  %xmm1,%xmm5
   20c10:	66 0f 29 ac 24 a0 01 	movapd %xmm5,0x1a0(%rsp)
   20c17:	00 00 
   20c19:	66 0f 29 bc 24 50 01 	movapd %xmm7,0x150(%rsp)
   20c20:	00 00 
   20c22:	66 0f 54 fc          	andpd  %xmm4,%xmm7
   20c26:	66 0f 28 6e 70       	movapd 0x70(%rsi),%xmm5
   20c2b:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   20c30:	66 44 0f c2 dd 05    	cmpnltpd %xmm5,%xmm11
   20c36:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   20c3b:	66 44 0f 29 5c 24 30 	movapd %xmm11,0x30(%rsp)
   20c42:	66 0f 29 b4 24 60 01 	movapd %xmm6,0x160(%rsp)
   20c49:	00 00 
   20c4b:	66 0f 54 f4          	andpd  %xmm4,%xmm6
   20c4f:	66 0f 29 b4 24 70 02 	movapd %xmm6,0x270(%rsp)
   20c56:	00 00 
   20c58:	66 0f 59 ce          	mulpd  %xmm6,%xmm1
   20c5c:	66 44 0f 29 84 24 40 	movapd %xmm8,0x140(%rsp)
   20c63:	01 00 00 
   20c66:	66 44 0f 54 c4       	andpd  %xmm4,%xmm8
   20c6b:	66 0f 29 bc 24 80 02 	movapd %xmm7,0x280(%rsp)
   20c72:	00 00 
   20c74:	66 0f 58 ff          	addpd  %xmm7,%xmm7
   20c78:	66 0f 29 bc 24 90 01 	movapd %xmm7,0x190(%rsp)
   20c7f:	00 00 
   20c81:	66 44 0f 29 84 24 60 	movapd %xmm8,0x260(%rsp)
   20c88:	02 00 00 
   20c8b:	66 45 0f 58 c0       	addpd  %xmm8,%xmm8
   20c90:	66 0f 28 76 40       	movapd 0x40(%rsi),%xmm6
   20c95:	66 0f 29 b4 24 d0 00 	movapd %xmm6,0xd0(%rsp)
   20c9c:	00 00 
   20c9e:	66 0f 54 f4          	andpd  %xmm4,%xmm6
   20ca2:	66 0f 29 b4 24 80 01 	movapd %xmm6,0x180(%rsp)
   20ca9:	00 00 
   20cab:	66 0f 28 76 50       	movapd 0x50(%rsi),%xmm6
   20cb0:	66 0f 28 fe          	movapd %xmm6,%xmm7
   20cb4:	66 0f 54 fc          	andpd  %xmm4,%xmm7
   20cb8:	66 44 0f 29 8c 24 30 	movapd %xmm9,0x130(%rsp)
   20cbf:	01 00 00 
   20cc2:	66 44 0f 54 cc       	andpd  %xmm4,%xmm9
   20cc7:	66 44 0f 29 8c 24 30 	movapd %xmm9,0x230(%rsp)
   20cce:	02 00 00 
   20cd1:	66 0f 29 ac 24 20 01 	movapd %xmm5,0x120(%rsp)
   20cd8:	00 00 
   20cda:	66 0f 54 ec          	andpd  %xmm4,%xmm5
   20cde:	66 0f 29 ac 24 20 02 	movapd %xmm5,0x220(%rsp)
   20ce5:	00 00 
   20ce7:	66 0f 29 b4 24 10 01 	movapd %xmm6,0x110(%rsp)
   20cee:	00 00 
   20cf0:	66 0f c6 f6 01       	shufpd $0x1,%xmm6,%xmm6
   20cf5:	66 0f 29 b4 24 20 03 	movapd %xmm6,0x320(%rsp)
   20cfc:	00 00 
   20cfe:	66 0f 29 9c 24 a0 02 	movapd %xmm3,0x2a0(%rsp)
   20d05:	00 00 
   20d07:	66 0f c6 db 01       	shufpd $0x1,%xmm3,%xmm3
   20d0c:	66 0f 29 9c 24 10 03 	movapd %xmm3,0x310(%rsp)
   20d13:	00 00 
   20d15:	66 0f 29 94 24 b0 02 	movapd %xmm2,0x2b0(%rsp)
   20d1c:	00 00 
   20d1e:	66 0f c6 d2 01       	shufpd $0x1,%xmm2,%xmm2
   20d23:	66 0f 29 94 24 00 03 	movapd %xmm2,0x300(%rsp)
   20d2a:	00 00 
   20d2c:	66 44 0f 29 84 24 50 	movapd %xmm8,0x250(%rsp)
   20d33:	02 00 00 
   20d36:	66 45 0f c6 c0 01    	shufpd $0x1,%xmm8,%xmm8
   20d3c:	66 44 0f 29 84 24 f0 	movapd %xmm8,0x2f0(%rsp)
   20d43:	02 00 00 
   20d46:	66 0f 29 8c 24 c0 02 	movapd %xmm1,0x2c0(%rsp)
   20d4d:	00 00 
   20d4f:	66 0f c6 c9 01       	shufpd $0x1,%xmm1,%xmm1
   20d54:	66 0f 29 8c 24 e0 02 	movapd %xmm1,0x2e0(%rsp)
   20d5b:	00 00 
   20d5d:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   20d61:	31 d2                	xor    %edx,%edx
   20d63:	0f 28 09             	movaps (%rcx),%xmm1
   20d66:	0f 29 8c 24 10 02 00 	movaps %xmm1,0x210(%rsp)
   20d6d:	00 
   20d6e:	0f 28 49 10          	movaps 0x10(%rcx),%xmm1
   20d72:	0f 29 8c 24 e0 00 00 	movaps %xmm1,0xe0(%rsp)
   20d79:	00 
   20d7a:	66 0f 29 bc 24 40 02 	movapd %xmm7,0x240(%rsp)
   20d81:	00 00 
   20d83:	66 0f 70 cf 4e       	pshufd $0x4e,%xmm7,%xmm1
   20d88:	66 0f 7f 8c 24 d0 02 	movdqa %xmm1,0x2d0(%rsp)
   20d8f:	00 00 
   20d91:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   20d96:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   20d9b:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   20da0:	66 0f 29 84 24 e0 01 	movapd %xmm0,0x1e0(%rsp)
   20da7:	00 00 
   20da9:	eb 70                	jmp    20e1b <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x36b>
   20dab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   20db0:	66 0f 28 9c 24 80 00 	movapd 0x80(%rsp),%xmm3
   20db7:	00 00 
   20db9:	66 0f 28 8c 24 90 00 	movapd 0x90(%rsp),%xmm1
   20dc0:	00 00 
   20dc2:	48 ff c2             	inc    %rdx
   20dc5:	66 0f 28 94 24 c0 00 	movapd 0xc0(%rsp),%xmm2
   20dcc:	00 00 
   20dce:	66 0f 55 94 24 f0 00 	andnpd 0xf0(%rsp),%xmm2
   20dd5:	00 00 
   20dd7:	66 44 0f 54 4c 24 50 	andpd  0x50(%rsp),%xmm9
   20dde:	66 41 0f 54 d1       	andpd  %xmm9,%xmm2
   20de3:	66 44 0f 55 c9       	andnpd %xmm1,%xmm9
   20de8:	66 41 0f 28 c9       	movapd %xmm9,%xmm1
   20ded:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   20df1:	66 44 0f 55 a4 24 00 	andnpd 0x100(%rsp),%xmm12
   20df8:	01 00 00 
   20dfb:	66 44 0f 54 54 24 10 	andpd  0x10(%rsp),%xmm10
   20e02:	66 45 0f 54 e2       	andpd  %xmm10,%xmm12
   20e07:	66 44 0f 55 d3       	andnpd %xmm3,%xmm10
   20e0c:	66 45 0f 56 d4       	orpd   %xmm12,%xmm10
   20e11:	48 83 fa 03          	cmp    $0x3,%rdx
   20e15:	0f 84 d3 0c 00 00    	je     21aee <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x103e>
   20e1b:	66 44 0f 29 94 24 80 	movapd %xmm10,0x80(%rsp)
   20e22:	00 00 00 
   20e25:	66 0f 29 8c 24 90 00 	movapd %xmm1,0x90(%rsp)
   20e2c:	00 00 
   20e2e:	66 44 0f 29 bc 24 00 	movapd %xmm15,0x100(%rsp)
   20e35:	01 00 00 
   20e38:	66 44 0f 29 b4 24 f0 	movapd %xmm14,0xf0(%rsp)
   20e3f:	00 00 00 
   20e42:	48 89 d1             	mov    %rdx,%rcx
   20e45:	48 c1 e1 05          	shl    $0x5,%rcx
   20e49:	66 0f 28 14 08       	movapd (%rax,%rcx,1),%xmm2
   20e4e:	66 0f 28 5c 08 10    	movapd 0x10(%rax,%rcx,1),%xmm3
   20e54:	66 0f 28 c2          	movapd %xmm2,%xmm0
   20e58:	66 44 0f 28 05 ef 48 	movapd -0x1b711(%rip),%xmm8        # 5750 <std::thread::current::id::ID+0x4ad8>
   20e5f:	fe ff 
   20e61:	66 41 0f c2 c0 04    	cmpneqpd %xmm8,%xmm0
   20e67:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   20e6c:	66 45 0f c2 d8 07    	cmpordpd %xmm8,%xmm11
   20e72:	66 44 0f 54 d8       	andpd  %xmm0,%xmm11
   20e77:	66 0f 28 cb          	movapd %xmm3,%xmm1
   20e7b:	66 0f 15 cb          	unpckhpd %xmm3,%xmm1
   20e7f:	66 44 0f 29 5c 24 10 	movapd %xmm11,0x10(%rsp)
   20e86:	66 0f 29 54 24 60    	movapd %xmm2,0x60(%rsp)
   20e8c:	66 44 0f 54 da       	andpd  %xmm2,%xmm11
   20e91:	66 44 0f 29 9c 24 c0 	movapd %xmm11,0xc0(%rsp)
   20e98:	00 00 00 
   20e9b:	66 0f 28 25 7d 43 fe 	movapd -0x1bc83(%rip),%xmm4        # 5220 <std::thread::current::id::ID+0x45a8>
   20ea2:	ff 
   20ea3:	66 44 0f 54 dc       	andpd  %xmm4,%xmm11
   20ea8:	66 0f 28 05 f0 47 fe 	movapd -0x1b810(%rip),%xmm0        # 56a0 <std::thread::current::id::ID+0x4a28>
   20eaf:	ff 
   20eb0:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
   20eb5:	31 c9                	xor    %ecx,%ecx
   20eb7:	f2 0f 10 15 39 63 fe 	movsd  -0x19cc7(%rip),%xmm2        # 71f8 <std::thread::current::id::ID+0x6580>
   20ebe:	ff 
   20ebf:	66 0f 2e da          	ucomisd %xmm2,%xmm3
   20ec3:	0f 95 c1             	setne  %cl
   20ec6:	31 f6                	xor    %esi,%esi
   20ec8:	66 0f 2e ca          	ucomisd %xmm2,%xmm1
   20ecc:	40 0f 94 c6          	sete   %sil
   20ed0:	66 0f 6e c9          	movd   %ecx,%xmm1
   20ed4:	66 0f c4 ce 04       	pinsrw $0x4,%esi,%xmm1
   20ed9:	66 0f 70 e9 a0       	pshufd $0xa0,%xmm1,%xmm5
   20ede:	66 0f 72 f5 1f       	pslld  $0x1f,%xmm5
   20ee3:	66 0f 72 e5 1f       	psrad  $0x1f,%xmm5
   20ee8:	f3 0f 7e fb          	movq   %xmm3,%xmm7
   20eec:	66 0f ef c9          	pxor   %xmm1,%xmm1
   20ef0:	0f 29 5c 24 50       	movaps %xmm3,0x50(%rsp)
   20ef5:	66 0f c6 cb 02       	shufpd $0x2,%xmm3,%xmm1
   20efa:	66 0f 6f d5          	movdqa %xmm5,%xmm2
   20efe:	66 0f df d1          	pandn  %xmm1,%xmm2
   20f02:	66 0f 7f 6c 24 70    	movdqa %xmm5,0x70(%rsp)
   20f08:	66 0f db fd          	pand   %xmm5,%xmm7
   20f0c:	66 0f eb fa          	por    %xmm2,%xmm7
   20f10:	66 0f 7f bc 24 b0 00 	movdqa %xmm7,0xb0(%rsp)
   20f17:	00 00 
   20f19:	66 0f 6f d7          	movdqa %xmm7,%xmm2
   20f1d:	66 0f db d4          	pand   %xmm4,%xmm2
   20f21:	66 0f 58 d0          	addpd  %xmm0,%xmm2
   20f25:	66 0f 28 05 03 46 fe 	movapd -0x1b9fd(%rip),%xmm0        # 5530 <std::thread::current::id::ID+0x48b8>
   20f2c:	ff 
   20f2d:	66 44 0f 59 d8       	mulpd  %xmm0,%xmm11
   20f32:	66 0f 6e ce          	movd   %esi,%xmm1
   20f36:	66 0f c4 c9 04       	pinsrw $0x4,%ecx,%xmm1
   20f3b:	66 0f 7f 8c 24 a0 00 	movdqa %xmm1,0xa0(%rsp)
   20f42:	00 00 
   20f44:	66 0f 59 d0          	mulpd  %xmm0,%xmm2
   20f48:	b9 1f 00 00 00       	mov    $0x1f,%ecx
   20f4d:	66 41 0f 28 c8       	movapd %xmm8,%xmm1
   20f52:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   20f59:	1f 84 00 00 00 00 00 
   20f60:	66 0f 29 54 24 20    	movapd %xmm2,0x20(%rsp)
   20f66:	66 44 0f 28 54 24 20 	movapd 0x20(%rsp),%xmm10
   20f6d:	f2 0f 10 1d 83 62 fe 	movsd  -0x19d7d(%rip),%xmm3        # 71f8 <std::thread::current::id::ID+0x6580>
   20f74:	ff 
   20f75:	66 0f 28 44 24 50    	movapd 0x50(%rsp),%xmm0
   20f7b:	66 0f 2e c3          	ucomisd %xmm3,%xmm0
   20f7f:	66 41 0f 28 e3       	movapd %xmm11,%xmm4
   20f84:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   20f89:	40 0f 95 c6          	setne  %sil
   20f8d:	66 0f 28 d1          	movapd %xmm1,%xmm2
   20f91:	66 41 0f 28 e8       	movapd %xmm8,%xmm5
   20f96:	66 41 0f 15 e8       	unpckhpd %xmm8,%xmm5
   20f9b:	45 31 c0             	xor    %r8d,%r8d
   20f9e:	66 0f 2e eb          	ucomisd %xmm3,%xmm5
   20fa2:	66 44 0f 28 0d a5 47 	movapd -0x1b85b(%rip),%xmm9        # 5750 <std::thread::current::id::ID+0x4ad8>
   20fa9:	fe ff 
   20fab:	66 41 0f c2 d1 00    	cmpeqpd %xmm9,%xmm2
   20fb1:	66 41 0f 58 e3       	addpd  %xmm11,%xmm4
   20fb6:	66 0f 28 84 24 c0 00 	movapd 0xc0(%rsp),%xmm0
   20fbd:	00 00 
   20fbf:	66 44 0f 28 f0       	movapd %xmm0,%xmm14
   20fc4:	66 45 0f 5c f3       	subpd  %xmm11,%xmm14
   20fc9:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   20fcd:	66 44 0f 5f f3       	maxpd  %xmm3,%xmm14
   20fd2:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   20fd6:	66 0f 28 bc 24 c0 01 	movapd 0x1c0(%rsp),%xmm7
   20fdd:	00 00 
   20fdf:	66 44 0f 28 ef       	movapd %xmm7,%xmm13
   20fe4:	66 45 0f 59 ee       	mulpd  %xmm14,%xmm13
   20fe9:	66 44 0f 28 bc 24 b0 	movapd 0x1b0(%rsp),%xmm15
   20ff0:	01 00 00 
   20ff3:	66 45 0f 58 ef       	addpd  %xmm15,%xmm13
   20ff8:	66 45 0f 59 ee       	mulpd  %xmm14,%xmm13
   20ffd:	66 44 0f 28 a4 24 d0 	movapd 0xd0(%rsp),%xmm12
   21004:	00 00 00 
   21007:	66 45 0f 58 ec       	addpd  %xmm12,%xmm13
   2100c:	66 44 0f 28 9c 24 a0 	movapd 0x1a0(%rsp),%xmm11
   21013:	01 00 00 
   21016:	66 41 0f 28 eb       	movapd %xmm11,%xmm5
   2101b:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   21020:	66 0f 28 9c 24 90 01 	movapd 0x190(%rsp),%xmm3
   21027:	00 00 
   21029:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   2102d:	66 41 0f 59 ee       	mulpd  %xmm14,%xmm5
   21032:	66 0f 28 84 24 80 01 	movapd 0x180(%rsp),%xmm0
   21039:	00 00 
   2103b:	66 0f 58 e8          	addpd  %xmm0,%xmm5
   2103f:	66 44 0f 28 0d e8 44 	movapd -0x1bb18(%rip),%xmm9        # 5530 <std::thread::current::id::ID+0x48b8>
   21046:	fe ff 
   21048:	66 41 0f 59 e9       	mulpd  %xmm9,%xmm5
   2104d:	66 44 0f 28 f7       	movapd %xmm7,%xmm14
   21052:	66 44 0f 59 f6       	mulpd  %xmm6,%xmm14
   21057:	66 45 0f 58 f7       	addpd  %xmm15,%xmm14
   2105c:	66 44 0f 59 f6       	mulpd  %xmm6,%xmm14
   21061:	66 45 0f 58 f4       	addpd  %xmm12,%xmm14
   21066:	66 44 0f 59 de       	mulpd  %xmm6,%xmm11
   2106b:	66 44 0f 58 db       	addpd  %xmm3,%xmm11
   21070:	66 44 0f 59 de       	mulpd  %xmm6,%xmm11
   21075:	66 44 0f 58 d8       	addpd  %xmm0,%xmm11
   2107a:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   2107f:	66 0f 28 f5          	movapd %xmm5,%xmm6
   21083:	66 44 0f 28 25 04 47 	movapd -0x1b8fc(%rip),%xmm12        # 5790 <std::thread::current::id::ID+0x4b18>
   2108a:	fe ff 
   2108c:	66 41 0f 57 f4       	xorpd  %xmm12,%xmm6
   21091:	66 41 0f c2 ed 01    	cmpltpd %xmm13,%xmm5
   21097:	66 44 0f c2 ee 01    	cmpltpd %xmm6,%xmm13
   2109d:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   210a2:	66 41 0f c2 f6 01    	cmpltpd %xmm14,%xmm6
   210a8:	66 41 0f 54 f5       	andpd  %xmm13,%xmm6
   210ad:	66 45 0f 57 dc       	xorpd  %xmm12,%xmm11
   210b2:	66 45 0f c2 f3 01    	cmpltpd %xmm11,%xmm14
   210b8:	66 44 0f 54 f5       	andpd  %xmm5,%xmm14
   210bd:	66 44 0f 56 f6       	orpd   %xmm6,%xmm14
   210c2:	66 44 0f 54 f2       	andpd  %xmm2,%xmm14
   210c7:	66 44 0f 28 7c 24 10 	movapd 0x10(%rsp),%xmm15
   210ce:	66 45 0f 54 f7       	andpd  %xmm15,%xmm14
   210d3:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
   210d8:	66 41 0f 54 e6       	andpd  %xmm14,%xmm4
   210dd:	66 44 0f 55 f1       	andnpd %xmm1,%xmm14
   210e2:	66 41 0f 28 ce       	movapd %xmm14,%xmm1
   210e7:	66 0f 56 cc          	orpd   %xmm4,%xmm1
   210eb:	66 0f 28 84 24 b0 00 	movapd 0xb0(%rsp),%xmm0
   210f2:	00 00 
   210f4:	66 0f 28 e0          	movapd %xmm0,%xmm4
   210f8:	66 41 0f 5c e2       	subpd  %xmm10,%xmm4
   210fd:	66 0f c6 e4 01       	shufpd $0x1,%xmm4,%xmm4
   21102:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21106:	66 0f 5f e2          	maxpd  %xmm2,%xmm4
   2110a:	66 44 0f 58 d0       	addpd  %xmm0,%xmm10
   2110f:	66 45 0f c6 d2 01    	shufpd $0x1,%xmm10,%xmm10
   21115:	66 0f 28 ac 24 00 03 	movapd 0x300(%rsp),%xmm5
   2111c:	00 00 
   2111e:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   21123:	66 44 0f 59 f4       	mulpd  %xmm4,%xmm14
   21128:	66 0f 28 9c 24 10 03 	movapd 0x310(%rsp),%xmm3
   2112f:	00 00 
   21131:	66 44 0f 58 f3       	addpd  %xmm3,%xmm14
   21136:	66 44 0f 59 f4       	mulpd  %xmm4,%xmm14
   2113b:	66 0f 28 84 24 20 03 	movapd 0x320(%rsp),%xmm0
   21142:	00 00 
   21144:	66 44 0f 58 f0       	addpd  %xmm0,%xmm14
   21149:	66 44 0f 28 ac 24 e0 	movapd 0x2e0(%rsp),%xmm13
   21150:	02 00 00 
   21153:	66 41 0f 28 f5       	movapd %xmm13,%xmm6
   21158:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   2115c:	66 0f 28 bc 24 f0 02 	movapd 0x2f0(%rsp),%xmm7
   21163:	00 00 
   21165:	66 0f 58 f7          	addpd  %xmm7,%xmm6
   21169:	66 0f 59 f4          	mulpd  %xmm4,%xmm6
   2116d:	66 44 0f 28 8c 24 d0 	movapd 0x2d0(%rsp),%xmm9
   21174:	02 00 00 
   21177:	66 41 0f 58 f1       	addpd  %xmm9,%xmm6
   2117c:	66 0f 28 15 ac 43 fe 	movapd -0x1bc54(%rip),%xmm2        # 5530 <std::thread::current::id::ID+0x48b8>
   21183:	ff 
   21184:	66 0f 59 f2          	mulpd  %xmm2,%xmm6
   21188:	66 0f 28 e5          	movapd %xmm5,%xmm4
   2118c:	66 41 0f 59 e2       	mulpd  %xmm10,%xmm4
   21191:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   21195:	66 41 0f 59 e2       	mulpd  %xmm10,%xmm4
   2119a:	66 0f 58 e0          	addpd  %xmm0,%xmm4
   2119e:	66 45 0f 59 ea       	mulpd  %xmm10,%xmm13
   211a3:	66 44 0f 58 ef       	addpd  %xmm7,%xmm13
   211a8:	66 45 0f 59 ea       	mulpd  %xmm10,%xmm13
   211ad:	66 45 0f 58 e9       	addpd  %xmm9,%xmm13
   211b2:	66 44 0f 59 ea       	mulpd  %xmm2,%xmm13
   211b7:	66 0f 28 ee          	movapd %xmm6,%xmm5
   211bb:	66 41 0f 57 ec       	xorpd  %xmm12,%xmm5
   211c0:	66 41 0f 28 fe       	movapd %xmm14,%xmm7
   211c5:	66 44 0f 28 d6       	movapd %xmm6,%xmm10
   211ca:	66 45 0f c2 d6 05    	cmpnltpd %xmm14,%xmm10
   211d0:	66 41 0f c2 f6 01    	cmpltpd %xmm14,%xmm6
   211d6:	66 44 0f c2 f5 05    	cmpnltpd %xmm5,%xmm14
   211dc:	66 0f c2 fd 01       	cmpltpd %xmm5,%xmm7
   211e1:	66 41 0f 28 ed       	movapd %xmm13,%xmm5
   211e6:	66 0f c2 ec 05       	cmpnltpd %xmm4,%xmm5
   211eb:	66 41 0f 56 ee       	orpd   %xmm14,%xmm5
   211f0:	66 45 0f 28 f5       	movapd %xmm13,%xmm14
   211f5:	66 44 0f c2 f4 01    	cmpltpd %xmm4,%xmm14
   211fb:	66 44 0f 54 f7       	andpd  %xmm7,%xmm14
   21200:	66 45 0f 57 ec       	xorpd  %xmm12,%xmm13
   21205:	66 0f 28 fc          	movapd %xmm4,%xmm7
   21209:	66 41 0f c2 fd 05    	cmpnltpd %xmm13,%xmm7
   2120f:	66 41 0f 56 fa       	orpd   %xmm10,%xmm7
   21214:	66 0f 28 54 24 20    	movapd 0x20(%rsp),%xmm2
   2121a:	66 0f 54 fd          	andpd  %xmm5,%xmm7
   2121e:	66 41 0f c2 e5 01    	cmpltpd %xmm13,%xmm4
   21224:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   21228:	41 0f 93 c0          	setae  %r8b
   2122c:	45 31 c9             	xor    %r9d,%r9d
   2122f:	f2 0f 10 1d c1 5f fe 	movsd  -0x1a03f(%rip),%xmm3        # 71f8 <std::thread::current::id::ID+0x6580>
   21236:	ff 
   21237:	66 44 0f 2e c3       	ucomisd %xmm3,%xmm8
   2123c:	41 0f 92 c1          	setb   %r9b
   21240:	66 41 0f 56 e6       	orpd   %xmm14,%xmm4
   21245:	66 41 0f 6e e9       	movd   %r9d,%xmm5
   2124a:	66 0f 6f 84 24 a0 00 	movdqa 0xa0(%rsp),%xmm0
   21251:	00 00 
   21253:	66 0f eb e8          	por    %xmm0,%xmm5
   21257:	66 0f eb ef          	por    %xmm7,%xmm5
   2125b:	66 41 0f 6e f0       	movd   %r8d,%xmm6
   21260:	66 0f 70 f6 44       	pshufd $0x44,%xmm6,%xmm6
   21265:	66 0f db f0          	pand   %xmm0,%xmm6
   21269:	66 0f db f4          	pand   %xmm4,%xmm6
   2126d:	66 0f 58 d2          	addpd  %xmm2,%xmm2
   21271:	0f c6 ee a0          	shufps $0xa0,%xmm6,%xmm5
   21275:	66 0f 72 f5 1f       	pslld  $0x1f,%xmm5
   2127a:	66 0f 72 e5 1f       	psrad  $0x1f,%xmm5
   2127f:	66 0f 28 e2          	movapd %xmm2,%xmm4
   21283:	66 41 0f 15 e0       	unpckhpd %xmm8,%xmm4
   21288:	66 44 0f 14 c2       	unpcklpd %xmm2,%xmm8
   2128d:	66 41 0f 28 f0       	movapd %xmm8,%xmm6
   21292:	66 0f 54 f5          	andpd  %xmm5,%xmm6
   21296:	66 0f 55 ec          	andnpd %xmm4,%xmm5
   2129a:	66 44 0f 28 c5       	movapd %xmm5,%xmm8
   2129f:	66 44 0f 56 c6       	orpd   %xmm6,%xmm8
   212a4:	66 41 0f 70 e0 ee    	pshufd $0xee,%xmm8,%xmm4
   212aa:	66 0f 2e e3          	ucomisd %xmm3,%xmm4
   212ae:	66 0f 28 e1          	movapd %xmm1,%xmm4
   212b2:	66 0f c2 25 95 44 fe 	cmpeqpd -0x1bb6b(%rip),%xmm4        # 5750 <std::thread::current::id::ID+0x4ad8>
   212b9:	ff 00 
   212bb:	66 41 0f 54 e7       	andpd  %xmm15,%xmm4
   212c0:	66 44 0f 50 c4       	movmskpd %xmm4,%r8d
   212c5:	41 0f 93 c1          	setae  %r9b
   212c9:	41 20 f1             	and    %sil,%r9b
   212cc:	45 85 c0             	test   %r8d,%r8d
   212cf:	41 0f 95 c0          	setne  %r8b
   212d3:	45 08 c8             	or     %r9b,%r8b
   212d6:	83 c1 ff             	add    $0xffffffff,%ecx
   212d9:	40 0f 92 c6          	setb   %sil
   212dd:	41 80 f8 01          	cmp    $0x1,%r8b
   212e1:	75 09                	jne    212ec <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x83c>
   212e3:	40 84 f6             	test   %sil,%sil
   212e6:	0f 85 74 fc ff ff    	jne    20f60 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x4b0>
   212ec:	66 44 0f 28 4c 24 60 	movapd 0x60(%rsp),%xmm9
   212f3:	66 41 0f 28 c1       	movapd %xmm9,%xmm0
   212f8:	66 44 0f 28 9c 24 10 	movapd 0x210(%rsp),%xmm11
   212ff:	02 00 00 
   21302:	66 41 0f 5d c3       	minpd  %xmm11,%xmm0
   21307:	66 44 0f 28 f0       	movapd %xmm0,%xmm14
   2130c:	66 44 0f c2 f0 03    	cmpunordpd %xmm0,%xmm14
   21312:	66 41 0f 28 d1       	movapd %xmm9,%xmm2
   21317:	66 41 0f 54 d6       	andpd  %xmm14,%xmm2
   2131c:	66 44 0f 55 f0       	andnpd %xmm0,%xmm14
   21321:	66 44 0f 56 f2       	orpd   %xmm2,%xmm14
   21326:	66 44 0f 28 54 24 50 	movapd 0x50(%rsp),%xmm10
   2132d:	66 41 0f 28 c2       	movapd %xmm10,%xmm0
   21332:	66 0f 5d 84 24 e0 00 	minpd  0xe0(%rsp),%xmm0
   21339:	00 00 
   2133b:	66 44 0f 28 f8       	movapd %xmm0,%xmm15
   21340:	66 44 0f c2 f8 03    	cmpunordpd %xmm0,%xmm15
   21346:	66 41 0f 28 d2       	movapd %xmm10,%xmm2
   2134b:	66 41 0f 54 d7       	andpd  %xmm15,%xmm2
   21350:	66 44 0f 55 f8       	andnpd %xmm0,%xmm15
   21355:	66 44 0f 56 fa       	orpd   %xmm2,%xmm15
   2135a:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   21360:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   21364:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21368:	66 41 0f 14 c0       	unpcklpd %xmm8,%xmm0
   2136d:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   21371:	66 44 0f 15 c1       	unpckhpd %xmm1,%xmm8
   21376:	66 44 0f 28 64 24 70 	movapd 0x70(%rsp),%xmm12
   2137d:	66 45 0f 54 c4       	andpd  %xmm12,%xmm8
   21382:	66 44 0f 55 e0       	andnpd %xmm0,%xmm12
   21387:	66 45 0f 56 e0       	orpd   %xmm8,%xmm12
   2138c:	66 0f 28 84 24 70 01 	movapd 0x170(%rsp),%xmm0
   21393:	00 00 
   21395:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
   2139a:	66 0f 58 84 24 50 01 	addpd  0x150(%rsp),%xmm0
   213a1:	00 00 
   213a3:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
   213a8:	66 0f 28 bc 24 d0 00 	movapd 0xd0(%rsp),%xmm7
   213af:	00 00 
   213b1:	66 0f 58 c7          	addpd  %xmm7,%xmm0
   213b5:	66 0f 28 4c 24 40    	movapd 0x40(%rsp),%xmm1
   213bb:	66 0f 28 2d 8d 43 fe 	movapd -0x1bc73(%rip),%xmm5        # 5750 <std::thread::current::id::ID+0x4ad8>
   213c2:	ff 
   213c3:	66 0f c2 cd 00       	cmpeqpd %xmm5,%xmm1
   213c8:	66 0f 28 54 24 30    	movapd 0x30(%rsp),%xmm2
   213ce:	66 0f c2 d5 00       	cmpeqpd %xmm5,%xmm2
   213d3:	66 44 0f 28 ac 24 90 	movapd 0x90(%rsp),%xmm13
   213da:	00 00 00 
   213dd:	66 44 0f c2 ed 00    	cmpeqpd %xmm5,%xmm13
   213e3:	66 44 0f 54 e9       	andpd  %xmm1,%xmm13
   213e8:	66 0f 28 8c 24 80 00 	movapd 0x80(%rsp),%xmm1
   213ef:	00 00 
   213f1:	66 0f c2 cd 00       	cmpeqpd %xmm5,%xmm1
   213f6:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   213fa:	66 0f 29 4c 24 10    	movapd %xmm1,0x10(%rsp)
   21400:	66 41 0f 28 e1       	movapd %xmm9,%xmm4
   21405:	66 0f 5c e3          	subpd  %xmm3,%xmm4
   21409:	66 45 0f 5c ce       	subpd  %xmm14,%xmm9
   2140e:	66 0f 28 35 0a 3e fe 	movapd -0x1c1f6(%rip),%xmm6        # 5220 <std::thread::current::id::ID+0x45a8>
   21415:	ff 
   21416:	66 44 0f 54 ce       	andpd  %xmm6,%xmm9
   2141b:	66 44 0f 58 cb       	addpd  %xmm3,%xmm9
   21420:	66 41 0f c2 e3 01    	cmpltpd %xmm11,%xmm4
   21426:	66 41 0f 54 e1       	andpd  %xmm9,%xmm4
   2142b:	66 0f 28 cc          	movapd %xmm4,%xmm1
   2142f:	66 0f 28 d5          	movapd %xmm5,%xmm2
   21433:	66 0f c2 cd 00       	cmpeqpd %xmm5,%xmm1
   21438:	66 0f 28 ec          	movapd %xmm4,%xmm5
   2143c:	66 0f c2 ea 03       	cmpunordpd %xmm2,%xmm5
   21441:	66 0f 56 e9          	orpd   %xmm1,%xmm5
   21445:	66 0f 28 94 24 a0 01 	movapd 0x1a0(%rsp),%xmm2
   2144c:	00 00 
   2144e:	66 41 0f 59 d6       	mulpd  %xmm14,%xmm2
   21453:	66 44 0f 28 84 24 80 	movapd 0x280(%rsp),%xmm8
   2145a:	02 00 00 
   2145d:	66 41 0f 28 c8       	movapd %xmm8,%xmm1
   21462:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   21466:	66 0f 28 dd          	movapd %xmm5,%xmm3
   2146a:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   2146e:	66 0f 28 a4 24 c0 01 	movapd 0x1c0(%rsp),%xmm4
   21475:	00 00 
   21477:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   2147c:	66 0f 58 a4 24 b0 01 	addpd  0x1b0(%rsp),%xmm4
   21483:	00 00 
   21485:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   2148a:	66 0f 58 e7          	addpd  %xmm7,%xmm4
   2148e:	66 0f 54 e6          	andpd  %xmm6,%xmm4
   21492:	66 0f 58 94 24 90 01 	addpd  0x190(%rsp),%xmm2
   21499:	00 00 
   2149b:	66 41 0f 59 d6       	mulpd  %xmm14,%xmm2
   214a0:	66 44 0f 28 8c 24 80 	movapd 0x180(%rsp),%xmm9
   214a7:	01 00 00 
   214aa:	66 41 0f 58 d1       	addpd  %xmm9,%xmm2
   214af:	66 44 0f 28 1d 78 40 	movapd -0x1bf88(%rip),%xmm11        # 5530 <std::thread::current::id::ID+0x48b8>
   214b6:	fe ff 
   214b8:	66 41 0f 59 d3       	mulpd  %xmm11,%xmm2
   214bd:	66 0f 58 d4          	addpd  %xmm4,%xmm2
   214c1:	66 0f 28 bc 24 90 02 	movapd 0x290(%rsp),%xmm7
   214c8:	00 00 
   214ca:	66 0f 28 e7          	movapd %xmm7,%xmm4
   214ce:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   214d3:	66 41 0f 58 e0       	addpd  %xmm8,%xmm4
   214d8:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   214dd:	66 41 0f 58 e1       	addpd  %xmm9,%xmm4
   214e2:	66 41 0f 59 e6       	mulpd  %xmm14,%xmm4
   214e7:	66 0f 58 a4 24 30 02 	addpd  0x230(%rsp),%xmm4
   214ee:	00 00 
   214f0:	66 41 0f 59 e3       	mulpd  %xmm11,%xmm4
   214f5:	66 0f 59 d3          	mulpd  %xmm3,%xmm2
   214f9:	66 0f 58 d4          	addpd  %xmm4,%xmm2
   214fd:	66 0f 28 e7          	movapd %xmm7,%xmm4
   21501:	66 0f 59 e3          	mulpd  %xmm3,%xmm4
   21505:	66 0f 58 e1          	addpd  %xmm1,%xmm4
   21509:	66 0f 28 8c 24 b0 02 	movapd 0x2b0(%rsp),%xmm1
   21510:	00 00 
   21512:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
   21517:	66 0f 58 8c 24 a0 02 	addpd  0x2a0(%rsp),%xmm1
   2151e:	00 00 
   21520:	66 41 0f 59 c6       	mulpd  %xmm14,%xmm0
   21525:	66 0f 58 84 24 30 01 	addpd  0x130(%rsp),%xmm0
   2152c:	00 00 
   2152e:	66 0f 59 e3          	mulpd  %xmm3,%xmm4
   21532:	66 0f 59 e3          	mulpd  %xmm3,%xmm4
   21536:	66 44 0f 28 c8       	movapd %xmm0,%xmm9
   2153b:	66 0f 28 de          	movapd %xmm6,%xmm3
   2153f:	66 44 0f 54 ce       	andpd  %xmm6,%xmm9
   21544:	66 0f 58 e2          	addpd  %xmm2,%xmm4
   21548:	66 44 0f c2 cc 02    	cmplepd %xmm4,%xmm9
   2154e:	66 0f 29 ac 24 c0 00 	movapd %xmm5,0xc0(%rsp)
   21555:	00 00 
   21557:	66 44 0f 56 cd       	orpd   %xmm5,%xmm9
   2155c:	66 0f c2 e0 01       	cmpltpd %xmm0,%xmm4
   21561:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   21566:	66 0f 55 f4          	andnpd %xmm4,%xmm6
   2156a:	66 41 0f 28 d2       	movapd %xmm10,%xmm2
   2156f:	66 41 0f 5c d4       	subpd  %xmm12,%xmm2
   21574:	66 45 0f 5c d7       	subpd  %xmm15,%xmm10
   21579:	66 44 0f 54 d3       	andpd  %xmm3,%xmm10
   2157e:	66 0f 28 e3          	movapd %xmm3,%xmm4
   21582:	66 45 0f 58 d4       	addpd  %xmm12,%xmm10
   21587:	66 0f c2 94 24 e0 00 	cmpltpd 0xe0(%rsp),%xmm2
   2158e:	00 00 01 
   21591:	66 41 0f 54 d2       	andpd  %xmm10,%xmm2
   21596:	66 0f 28 c2          	movapd %xmm2,%xmm0
   2159a:	66 0f 28 1d ae 41 fe 	movapd -0x1be52(%rip),%xmm3        # 5750 <std::thread::current::id::ID+0x4ad8>
   215a1:	ff 
   215a2:	66 0f c2 c3 00       	cmpeqpd %xmm3,%xmm0
   215a7:	66 44 0f 28 e2       	movapd %xmm2,%xmm12
   215ac:	66 44 0f c2 e3 03    	cmpunordpd %xmm3,%xmm12
   215b2:	66 44 0f 56 e0       	orpd   %xmm0,%xmm12
   215b7:	66 41 0f 28 c4       	movapd %xmm12,%xmm0
   215bc:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   215c0:	66 41 0f 59 cf       	mulpd  %xmm15,%xmm1
   215c5:	66 0f 28 bc 24 10 01 	movapd 0x110(%rsp),%xmm7
   215cc:	00 00 
   215ce:	66 0f 58 cf          	addpd  %xmm7,%xmm1
   215d2:	66 0f 28 94 24 c0 02 	movapd 0x2c0(%rsp),%xmm2
   215d9:	00 00 
   215db:	66 41 0f 59 d7       	mulpd  %xmm15,%xmm2
   215e0:	66 0f 28 9c 24 50 02 	movapd 0x250(%rsp),%xmm3
   215e7:	00 00 
   215e9:	66 0f 58 da          	addpd  %xmm2,%xmm3
   215ed:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   215f2:	66 44 0f 28 84 24 40 	movapd 0x240(%rsp),%xmm8
   215f9:	02 00 00 
   215fc:	66 41 0f 58 d8       	addpd  %xmm8,%xmm3
   21601:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   21606:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   2160a:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   2160e:	66 0f 28 a4 24 70 02 	movapd 0x270(%rsp),%xmm4
   21615:	00 00 
   21617:	66 0f 28 dc          	movapd %xmm4,%xmm3
   2161b:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   21620:	66 0f 28 ac 24 60 02 	movapd 0x260(%rsp),%xmm5
   21627:	00 00 
   21629:	66 0f 58 dd          	addpd  %xmm5,%xmm3
   2162d:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   21632:	66 41 0f 58 d8       	addpd  %xmm8,%xmm3
   21637:	66 41 0f 59 df       	mulpd  %xmm15,%xmm3
   2163c:	66 0f 58 9c 24 20 02 	addpd  0x220(%rsp),%xmm3
   21643:	00 00 
   21645:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   2164a:	66 0f 59 c8          	mulpd  %xmm0,%xmm1
   2164e:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   21652:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   21656:	66 0f 28 dc          	movapd %xmm4,%xmm3
   2165a:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   2165e:	66 0f 58 da          	addpd  %xmm2,%xmm3
   21662:	66 44 0f 29 6c 24 50 	movapd %xmm13,0x50(%rsp)
   21669:	66 41 0f 54 f5       	andpd  %xmm13,%xmm6
   2166e:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   21672:	66 0f 59 d8          	mulpd  %xmm0,%xmm3
   21676:	66 0f 28 84 24 60 01 	movapd 0x160(%rsp),%xmm0
   2167d:	00 00 
   2167f:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   21684:	66 0f 58 84 24 40 01 	addpd  0x140(%rsp),%xmm0
   2168b:	00 00 
   2168d:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   21692:	66 0f 58 c7          	addpd  %xmm7,%xmm0
   21696:	66 41 0f 59 c7       	mulpd  %xmm15,%xmm0
   2169b:	66 0f 58 84 24 20 01 	addpd  0x120(%rsp),%xmm0
   216a2:	00 00 
   216a4:	66 0f 58 d9          	addpd  %xmm1,%xmm3
   216a8:	66 44 0f 28 d0       	movapd %xmm0,%xmm10
   216ad:	66 44 0f 54 15 6a 3b 	andpd  -0x1c496(%rip),%xmm10        # 5220 <std::thread::current::id::ID+0x45a8>
   216b4:	fe ff 
   216b6:	66 44 0f c2 d3 02    	cmplepd %xmm3,%xmm10
   216bc:	66 45 0f 56 d4       	orpd   %xmm12,%xmm10
   216c1:	66 0f c2 d8 01       	cmpltpd %xmm0,%xmm3
   216c6:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   216cb:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   216cf:	66 0f 54 4c 24 10    	andpd  0x10(%rsp),%xmm1
   216d5:	66 0f 70 c6 ee       	pshufd $0xee,%xmm6,%xmm0
   216da:	0f 29 74 24 20       	movaps %xmm6,0x20(%rsp)
   216df:	66 0f eb c6          	por    %xmm6,%xmm0
   216e3:	66 0f eb c1          	por    %xmm1,%xmm0
   216e7:	66 0f 7e c1          	movd   %xmm0,%ecx
   216eb:	f6 c1 01             	test   $0x1,%cl
   216ee:	0f 84 bc f6 ff ff    	je     20db0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x300>
   216f4:	66 44 0f 29 94 24 00 	movapd %xmm10,0x200(%rsp)
   216fb:	02 00 00 
   216fe:	66 44 0f 29 64 24 60 	movapd %xmm12,0x60(%rsp)
   21705:	66 44 0f 29 4c 24 70 	movapd %xmm9,0x70(%rsp)
   2170c:	66 0f 7e c9          	movd   %xmm1,%ecx
   21710:	66 45 0f 28 ef       	movapd %xmm15,%xmm13
   21715:	66 45 0f 15 ef       	unpckhpd %xmm15,%xmm13
   2171a:	0f 29 8c 24 f0 01 00 	movaps %xmm1,0x1f0(%rsp)
   21721:	00 
   21722:	66 0f 70 c9 ee       	pshufd $0xee,%xmm1,%xmm1
   21727:	66 48 0f 7e ce       	movq   %xmm1,%rsi
   2172c:	66 44 0f 29 bc 24 a0 	movapd %xmm15,0xa0(%rsp)
   21733:	00 00 00 
   21736:	66 45 0f 28 d7       	movapd %xmm15,%xmm10
   2173b:	66 44 0f 28 84 24 f0 	movapd 0xf0(%rsp),%xmm8
   21742:	00 00 00 
   21745:	66 44 0f 29 b4 24 b0 	movapd %xmm14,0xb0(%rsp)
   2174c:	00 00 00 
   2174f:	66 41 0f 28 ce       	movapd %xmm14,%xmm1
   21754:	66 44 0f 28 9c 24 00 	movapd 0x100(%rsp),%xmm11
   2175b:	01 00 00 
   2175e:	66 0f 28 84 24 e0 01 	movapd 0x1e0(%rsp),%xmm0
   21765:	00 00 
   21767:	e9 a1 00 00 00       	jmp    2180d <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xd5d>
   2176c:	0f 1f 40 00          	nopl   0x0(%rax)
   21770:	66 41 0f 28 ee       	movapd %xmm14,%xmm5
   21775:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   2177a:	66 0f 76 ff          	pcmpeqd %xmm7,%xmm7
   2177e:	66 44 0f ef cf       	pxor   %xmm7,%xmm9
   21783:	66 0f 70 f5 a0       	pshufd $0xa0,%xmm5,%xmm6
   21788:	66 0f 72 f6 1f       	pslld  $0x1f,%xmm6
   2178d:	66 0f 72 e6 1f       	psrad  $0x1f,%xmm6
   21792:	66 41 0f 28 ef       	movapd %xmm15,%xmm5
   21797:	66 0f 54 ee          	andpd  %xmm6,%xmm5
   2179b:	66 0f 55 f1          	andnpd %xmm1,%xmm6
   2179f:	66 0f 56 f5          	orpd   %xmm5,%xmm6
   217a3:	66 45 0f eb ce       	por    %xmm14,%xmm9
   217a8:	66 41 0f 70 e9 a0    	pshufd $0xa0,%xmm9,%xmm5
   217ae:	66 0f 72 f5 1f       	pslld  $0x1f,%xmm5
   217b3:	66 0f 72 e5 1f       	psrad  $0x1f,%xmm5
   217b8:	66 44 0f 54 c5       	andpd  %xmm5,%xmm8
   217bd:	66 41 0f 55 ef       	andnpd %xmm15,%xmm5
   217c2:	45 0f b6 c9          	movzbl %r9b,%r9d
   217c6:	45 0f b6 c0          	movzbl %r8b,%r8d
   217ca:	66 41 0f 6e c8       	movd   %r8d,%xmm1
   217cf:	66 41 0f c4 c9 04    	pinsrw $0x4,%r9d,%xmm1
   217d5:	66 44 0f 56 c5       	orpd   %xmm5,%xmm8
   217da:	66 0f ef cf          	pxor   %xmm7,%xmm1
   217de:	0f 56 e1             	orps   %xmm1,%xmm4
   217e1:	66 0f 70 cc a0       	pshufd $0xa0,%xmm4,%xmm1
   217e6:	66 0f 72 f1 1f       	pslld  $0x1f,%xmm1
   217eb:	66 0f 72 e1 1f       	psrad  $0x1f,%xmm1
   217f0:	66 44 0f 54 d9       	andpd  %xmm1,%xmm11
   217f5:	66 41 0f 55 cc       	andnpd %xmm12,%xmm1
   217fa:	66 44 0f 56 d9       	orpd   %xmm1,%xmm11
   217ff:	66 44 0f 28 ea       	movapd %xmm2,%xmm13
   21804:	66 44 0f 28 d3       	movapd %xmm3,%xmm10
   21809:	66 0f 28 ce          	movapd %xmm6,%xmm1
   2180d:	66 0f 28 d0          	movapd %xmm0,%xmm2
   21811:	66 41 0f 59 d0       	mulpd  %xmm8,%xmm2
   21816:	66 44 0f 28 0d 21 40 	movapd -0x1bfdf(%rip),%xmm9        # 5840 <std::thread::current::id::ID+0x4bc8>
   2181d:	fe ff 
   2181f:	66 41 0f 5d d1       	minpd  %xmm9,%xmm2
   21824:	66 0f 5a da          	cvtpd2ps %xmm2,%xmm3
   21828:	0f 5a eb             	cvtps2pd %xmm3,%xmm5
   2182b:	66 41 0f 28 e3       	movapd %xmm11,%xmm4
   21830:	66 41 0f 14 e2       	unpcklpd %xmm10,%xmm4
   21835:	66 0f 59 e0          	mulpd  %xmm0,%xmm4
   21839:	66 41 0f 5d e1       	minpd  %xmm9,%xmm4
   2183e:	66 0f 5a f4          	cvtpd2ps %xmm4,%xmm6
   21842:	0f 5a fe             	cvtps2pd %xmm6,%xmm7
   21845:	66 0f c2 e7 01       	cmpltpd %xmm7,%xmm4
   2184a:	0f c6 e4 e8          	shufps $0xe8,%xmm4,%xmm4
   2184e:	66 0f fe e6          	paddd  %xmm6,%xmm4
   21852:	66 0f 70 f4 55       	pshufd $0x55,%xmm4,%xmm6
   21857:	66 0f 76 f4          	pcmpeqd %xmm4,%xmm6
   2185b:	66 41 0f 7e f1       	movd   %xmm6,%r9d
   21860:	66 0f 28 e0          	movapd %xmm0,%xmm4
   21864:	66 0f 59 e1          	mulpd  %xmm1,%xmm4
   21868:	66 41 0f 5d e1       	minpd  %xmm9,%xmm4
   2186d:	66 0f c2 d5 01       	cmpltpd %xmm5,%xmm2
   21872:	66 0f 5a ec          	cvtpd2ps %xmm4,%xmm5
   21876:	0f c6 d2 e8          	shufps $0xe8,%xmm2,%xmm2
   2187a:	66 0f fe d3          	paddd  %xmm3,%xmm2
   2187e:	0f 5a dd             	cvtps2pd %xmm5,%xmm3
   21881:	66 0f c2 e3 01       	cmpltpd %xmm3,%xmm4
   21886:	66 44 0f 28 f9       	movapd %xmm1,%xmm15
   2188b:	66 45 0f 5c f8       	subpd  %xmm8,%xmm15
   21890:	66 44 0f 59 3d e7 3a 	mulpd  -0x1c519(%rip),%xmm15        # 5380 <std::thread::current::id::ID+0x4708>
   21897:	fe ff 
   21899:	66 45 0f 58 f8       	addpd  %xmm8,%xmm15
   2189e:	0f c6 e4 e8          	shufps $0xe8,%xmm4,%xmm4
   218a2:	66 0f fe e5          	paddd  %xmm5,%xmm4
   218a6:	66 0f 76 e2          	pcmpeqd %xmm2,%xmm4
   218aa:	66 41 0f 28 d0       	movapd %xmm8,%xmm2
   218af:	66 41 0f c2 d7 01    	cmpltpd %xmm15,%xmm2
   218b5:	66 41 0f 28 df       	movapd %xmm15,%xmm3
   218ba:	66 0f c2 d9 01       	cmpltpd %xmm1,%xmm3
   218bf:	66 0f 54 da          	andpd  %xmm2,%xmm3
   218c3:	66 44 0f 70 cc 50    	pshufd $0x50,%xmm4,%xmm9
   218c9:	66 44 0f df cb       	pandn  %xmm3,%xmm9
   218ce:	66 45 0f 28 e2       	movapd %xmm10,%xmm12
   218d3:	f2 45 0f 5c e3       	subsd  %xmm11,%xmm12
   218d8:	f2 44 0f 59 25 bf 59 	mulsd  -0x1a641(%rip),%xmm12        # 72a0 <std::thread::current::id::ID+0x6628>
   218df:	fe ff 
   218e1:	f2 45 0f 58 e3       	addsd  %xmm11,%xmm12
   218e6:	41 f7 d1             	not    %r9d
   218e9:	66 45 0f 2e e3       	ucomisd %xmm11,%xmm12
   218ee:	41 0f 97 c2          	seta   %r10b
   218f2:	66 45 0f 2e d4       	ucomisd %xmm12,%xmm10
   218f7:	41 0f 97 c0          	seta   %r8b
   218fb:	66 44 0f db 4c 24 20 	pand   0x20(%rsp),%xmm9
   21902:	45 20 d0             	and    %r10b,%r8b
   21905:	45 20 c8             	and    %r9b,%r8b
   21908:	41 20 c8             	and    %cl,%r8b
   2190b:	66 45 0f 50 c9       	movmskpd %xmm9,%r9d
   21910:	45 85 c9             	test   %r9d,%r9d
   21913:	41 0f 95 c1          	setne  %r9b
   21917:	45 84 c0             	test   %r8b,%r8b
   2191a:	75 09                	jne    21925 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xe75>
   2191c:	45 84 c9             	test   %r9b,%r9b
   2191f:	0f 84 4b 01 00 00    	je     21a70 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xfc0>
   21925:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   2192a:	66 41 0f 15 db       	unpckhpd %xmm11,%xmm3
   2192f:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   21934:	f2 0f 5c d3          	subsd  %xmm3,%xmm2
   21938:	f2 0f 59 15 60 59 fe 	mulsd  -0x1a6a0(%rip),%xmm2        # 72a0 <std::thread::current::id::ID+0x6628>
   2193f:	ff 
   21940:	f2 0f 58 d3          	addsd  %xmm3,%xmm2
   21944:	66 44 0f 2e ea       	ucomisd %xmm2,%xmm13
   21949:	41 0f 97 c1          	seta   %r9b
   2194d:	66 41 0f 28 f3       	movapd %xmm11,%xmm6
   21952:	f2 41 0f 10 f5       	movsd  %xmm13,%xmm6
   21957:	66 0f 59 f0          	mulpd  %xmm0,%xmm6
   2195b:	66 0f 5d 35 dd 3e fe 	minpd  -0x1c123(%rip),%xmm6        # 5840 <std::thread::current::id::ID+0x4bc8>
   21962:	ff 
   21963:	66 0f 2e d3          	ucomisd %xmm3,%xmm2
   21967:	41 0f 97 c2          	seta   %r10b
   2196b:	66 41 0f 28 dc       	movapd %xmm12,%xmm3
   21970:	45 84 c0             	test   %r8b,%r8b
   21973:	75 05                	jne    2197a <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xeca>
   21975:	66 41 0f 28 da       	movapd %xmm10,%xmm3
   2197a:	66 44 0f 14 e2       	unpcklpd %xmm2,%xmm12
   2197f:	66 0f 28 ac 24 60 01 	movapd 0x160(%rsp),%xmm5
   21986:	00 00 
   21988:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   2198d:	66 0f 28 bc 24 70 01 	movapd 0x170(%rsp),%xmm7
   21994:	00 00 
   21996:	66 41 0f 59 ff       	mulpd  %xmm15,%xmm7
   2199b:	66 0f 58 bc 24 50 01 	addpd  0x150(%rsp),%xmm7
   219a2:	00 00 
   219a4:	66 0f 58 ac 24 40 01 	addpd  0x140(%rsp),%xmm5
   219ab:	00 00 
   219ad:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   219b2:	66 41 0f 59 ff       	mulpd  %xmm15,%xmm7
   219b7:	66 0f 58 ac 24 10 01 	addpd  0x110(%rsp),%xmm5
   219be:	00 00 
   219c0:	66 0f 58 bc 24 d0 00 	addpd  0xd0(%rsp),%xmm7
   219c7:	00 00 
   219c9:	66 41 0f 59 ec       	mulpd  %xmm12,%xmm5
   219ce:	66 41 0f 59 ff       	mulpd  %xmm15,%xmm7
   219d3:	66 0f 58 ac 24 20 01 	addpd  0x120(%rsp),%xmm5
   219da:	00 00 
   219dc:	66 0f 58 bc 24 30 01 	addpd  0x130(%rsp),%xmm7
   219e3:	00 00 
   219e5:	66 0f ef e4          	pxor   %xmm4,%xmm4
   219e9:	66 0f c2 e5 01       	cmpltpd %xmm5,%xmm4
   219ee:	66 45 0f 57 f6       	xorpd  %xmm14,%xmm14
   219f3:	66 44 0f c2 f7 01    	cmpltpd %xmm7,%xmm14
   219f9:	66 41 0f 28 ee       	movapd %xmm14,%xmm5
   219fe:	0f c6 ec 88          	shufps $0x88,%xmm4,%xmm5
   21a02:	0f 29 ac 24 d0 01 00 	movaps %xmm5,0x1d0(%rsp)
   21a09:	00 
   21a0a:	f6 84 24 d8 01 00 00 	testb  $0x1,0x1d8(%rsp)
   21a11:	01 
   21a12:	75 05                	jne    21a19 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xf69>
   21a14:	66 41 0f 28 da       	movapd %xmm10,%xmm3
   21a19:	66 0f 5a ee          	cvtpd2ps %xmm6,%xmm5
   21a1d:	0f 5a fd             	cvtps2pd %xmm5,%xmm7
   21a20:	66 0f c2 f7 01       	cmpltpd %xmm7,%xmm6
   21a25:	0f c6 f6 e8          	shufps $0xe8,%xmm6,%xmm6
   21a29:	66 0f fe f5          	paddd  %xmm5,%xmm6
   21a2d:	66 0f 70 ee 55       	pshufd $0x55,%xmm6,%xmm5
   21a32:	66 0f 76 ee          	pcmpeqd %xmm6,%xmm5
   21a36:	66 41 0f 7e eb       	movd   %xmm5,%r11d
   21a3b:	41 f7 d3             	not    %r11d
   21a3e:	45 20 d1             	and    %r10b,%r9b
   21a41:	41 20 f1             	and    %sil,%r9b
   21a44:	45 20 d9             	and    %r11b,%r9b
   21a47:	75 05                	jne    21a4e <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xf9e>
   21a49:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   21a4e:	f6 84 24 dc 01 00 00 	testb  $0x1,0x1dc(%rsp)
   21a55:	01 
   21a56:	0f 85 14 fd ff ff    	jne    21770 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xcc0>
   21a5c:	66 41 0f 28 d5       	movapd %xmm13,%xmm2
   21a61:	e9 0a fd ff ff       	jmp    21770 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0xcc0>
   21a66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   21a6d:	00 00 00 
   21a70:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   21a76:	66 44 0f 54 c1       	andpd  %xmm1,%xmm8
   21a7b:	66 0f 55 4c 24 40    	andnpd 0x40(%rsp),%xmm1
   21a81:	66 41 0f 56 c8       	orpd   %xmm8,%xmm1
   21a86:	66 0f 28 94 24 f0 01 	movapd 0x1f0(%rsp),%xmm2
   21a8d:	00 00 
   21a8f:	66 44 0f 54 da       	andpd  %xmm2,%xmm11
   21a94:	66 0f 55 54 24 30    	andnpd 0x30(%rsp),%xmm2
   21a9a:	66 41 0f 56 d3       	orpd   %xmm11,%xmm2
   21a9f:	66 0f 29 54 24 30    	movapd %xmm2,0x30(%rsp)
   21aa5:	66 0f 29 4c 24 40    	movapd %xmm1,0x40(%rsp)
   21aab:	66 0f 28 8c 24 90 00 	movapd 0x90(%rsp),%xmm1
   21ab2:	00 00 
   21ab4:	66 0f 28 9c 24 80 00 	movapd 0x80(%rsp),%xmm3
   21abb:	00 00 
   21abd:	66 44 0f 28 b4 24 b0 	movapd 0xb0(%rsp),%xmm14
   21ac4:	00 00 00 
   21ac7:	66 44 0f 28 bc 24 a0 	movapd 0xa0(%rsp),%xmm15
   21ace:	00 00 00 
   21ad1:	66 44 0f 28 4c 24 70 	movapd 0x70(%rsp),%xmm9
   21ad8:	66 44 0f 28 64 24 60 	movapd 0x60(%rsp),%xmm12
   21adf:	66 44 0f 28 94 24 00 	movapd 0x200(%rsp),%xmm10
   21ae6:	02 00 00 
   21ae9:	e9 d4 f2 ff ff       	jmp    20dc2 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>+0x312>
   21aee:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   21af3:	0f 29 07             	movaps %xmm0,(%rdi)
   21af6:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   21afb:	0f 29 47 10          	movaps %xmm0,0x10(%rdi)
   21aff:	66 0f 29 4f 20       	movapd %xmm1,0x20(%rdi)
   21b04:	66 44 0f 29 57 30    	movapd %xmm10,0x30(%rdi)
   21b0a:	48 89 ec             	mov    %rbp,%rsp
   21b0d:	5d                   	pop    %rbp
   21b0e:	c3                   	ret
   21b0f:	cc                   	int3

0000000000021b10 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>>:
   21b10:	55                   	push   %rbp
   21b11:	48 89 e5             	mov    %rsp,%rbp
   21b14:	41 57                	push   %r15
   21b16:	41 56                	push   %r14
   21b18:	41 55                	push   %r13
   21b1a:	41 54                	push   %r12
   21b1c:	53                   	push   %rbx
   21b1d:	48 83 e4 e0          	and    $0xffffffffffffffe0,%rsp
   21b21:	48 81 ec 40 02 00 00 	sub    $0x240,%rsp
   21b28:	f3 0f 11 44 24 0c    	movss  %xmm0,0xc(%rsp)
   21b2e:	89 fb                	mov    %edi,%ebx
   21b30:	0f 29 4c 24 40       	movaps %xmm1,0x40(%rsp)
   21b35:	0f 57 c0             	xorps  %xmm0,%xmm0
   21b38:	f3 0f 5a c1          	cvtss2sd %xmm1,%xmm0
   21b3c:	f2 0f 59 05 4c 58 fe 	mulsd  -0x1a7b4(%rip),%xmm0        # 7390 <std::thread::current::id::ID+0x6718>
   21b43:	ff 
   21b44:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
   21b4b:	00 
   21b4c:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   21b53:	00 
   21b54:	ff 15 5e 3d 04 00    	call   *0x43d5e(%rip)        # 658b8 <sincos@GLIBC_2.2.5>
   21b5a:	f2 0f 10 84 24 98 00 	movsd  0x98(%rsp),%xmm0
   21b61:	00 00 
   21b63:	f2 0f 10 8c 24 90 00 	movsd  0x90(%rsp),%xmm1
   21b6a:	00 00 
   21b6c:	f2 0f 10 15 f4 57 fe 	movsd  -0x1a80c(%rip),%xmm2        # 7368 <std::thread::current::id::ID+0x66f0>
   21b73:	ff 
   21b74:	f2 0f 59 d1          	mulsd  %xmm1,%xmm2
   21b78:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   21b7c:	f2 0f 58 d4          	addsd  %xmm4,%xmm2
   21b80:	f2 0f 10 1d 38 57 fe 	movsd  -0x1a8c8(%rip),%xmm3        # 72c0 <std::thread::current::id::ID+0x6648>
   21b87:	ff 
   21b88:	f2 0f 59 d9          	mulsd  %xmm1,%xmm3
   21b8c:	f2 0f 58 dc          	addsd  %xmm4,%xmm3
   21b90:	f2 44 0f 10 0d 67 57 	movsd  -0x1a899(%rip),%xmm9        # 7300 <std::thread::current::id::ID+0x6688>
   21b97:	fe ff 
   21b99:	f2 44 0f 59 c8       	mulsd  %xmm0,%xmm9
   21b9e:	f2 44 0f 58 ca       	addsd  %xmm2,%xmm9
   21ba3:	f2 0f 10 2d 1d 58 fe 	movsd  -0x1a7e3(%rip),%xmm5        # 73c8 <std::thread::current::id::ID+0x6750>
   21baa:	ff 
   21bab:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21baf:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   21bb3:	f2 0f 59 0d 95 57 fe 	mulsd  -0x1a86b(%rip),%xmm1        # 7350 <std::thread::current::id::ID+0x66d8>
   21bba:	ff 
   21bbb:	f2 0f 58 cc          	addsd  %xmm4,%xmm1
   21bbf:	f2 0f 59 05 d1 55 fe 	mulsd  -0x1aa2f(%rip),%xmm0        # 7198 <std::thread::current::id::ID+0x6520>
   21bc6:	ff 
   21bc7:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   21bcb:	85 db                	test   %ebx,%ebx
   21bcd:	74 3f                	je     21c0e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xfe>
   21bcf:	0f 28 0d fa 3b fe ff 	movaps -0x1c406(%rip),%xmm1        # 57d0 <std::thread::current::id::ID+0x4b58>
   21bd6:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21bdb:	66 0f 28 0d 8d 3c fe 	movapd -0x1c373(%rip),%xmm1        # 5870 <std::thread::current::id::ID+0x4bf8>
   21be2:	ff 
   21be3:	66 0f 28 25 c5 37 fe 	movapd -0x1c83b(%rip),%xmm4        # 53b0 <std::thread::current::id::ID+0x4738>
   21bea:	ff 
   21beb:	66 0f 28 35 8d 3c fe 	movapd -0x1c373(%rip),%xmm6        # 5880 <std::thread::current::id::ID+0x4c08>
   21bf2:	ff 
   21bf3:	f3 0f 7e 1d f5 55 fe 	movq   -0x1aa0b(%rip),%xmm3        # 71f0 <std::thread::current::id::ID+0x6578>
   21bfa:	ff 
   21bfb:	f2 44 0f 10 3d dc 56 	movsd  -0x1a924(%rip),%xmm15        # 72e0 <std::thread::current::id::ID+0x6668>
   21c02:	fe ff 
   21c04:	f3 0f 7e 15 f4 55 fe 	movq   -0x1aa0c(%rip),%xmm2        # 7200 <std::thread::current::id::ID+0x6588>
   21c0b:	ff 
   21c0c:	eb 3d                	jmp    21c4b <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0x13b>
   21c0e:	0f 28 0d 7b 37 fe ff 	movaps -0x1c885(%rip),%xmm1        # 5390 <std::thread::current::id::ID+0x4718>
   21c15:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   21c1a:	66 0f 28 0d 1e 39 fe 	movapd -0x1c6e2(%rip),%xmm1        # 5540 <std::thread::current::id::ID+0x48c8>
   21c21:	ff 
   21c22:	66 0f 28 25 16 37 fe 	movapd -0x1c8ea(%rip),%xmm4        # 5340 <std::thread::current::id::ID+0x46c8>
   21c29:	ff 
   21c2a:	66 0f 28 35 8e 3b fe 	movapd -0x1c472(%rip),%xmm6        # 57c0 <std::thread::current::id::ID+0x4b48>
   21c31:	ff 
   21c32:	f3 0f 7e 1d f6 56 fe 	movq   -0x1a90a(%rip),%xmm3        # 7330 <std::thread::current::id::ID+0x66b8>
   21c39:	ff 
   21c3a:	f2 44 0f 10 3d dd 56 	movsd  -0x1a923(%rip),%xmm15        # 7320 <std::thread::current::id::ID+0x66a8>
   21c41:	fe ff 
   21c43:	f3 0f 7e 15 45 56 fe 	movq   -0x1a9bb(%rip),%xmm2        # 7290 <std::thread::current::id::ID+0x6618>
   21c4a:	ff 
   21c4b:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   21c51:	66 44 0f 14 cd       	unpcklpd %xmm5,%xmm9
   21c56:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   21c5b:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   21c60:	66 0f 28 e8          	movapd %xmm0,%xmm5
   21c64:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21c68:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   21c6c:	66 45 0f 59 d9       	mulpd  %xmm9,%xmm11
   21c71:	66 41 0f 28 fb       	movapd %xmm11,%xmm7
   21c76:	66 41 0f c6 fb 01    	shufpd $0x1,%xmm11,%xmm7
   21c7c:	66 0f 59 fc          	mulpd  %xmm4,%xmm7
   21c80:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   21c85:	66 44 0f 59 c6       	mulpd  %xmm6,%xmm8
   21c8a:	66 44 0f 58 c7       	addpd  %xmm7,%xmm8
   21c8f:	66 0f 14 ed          	unpcklpd %xmm5,%xmm5
   21c93:	66 44 0f 28 f5       	movapd %xmm5,%xmm14
   21c98:	66 44 0f 59 f1       	mulpd  %xmm1,%xmm14
   21c9d:	66 45 0f 58 f0       	addpd  %xmm8,%xmm14
   21ca2:	f3 0f 7e fa          	movq   %xmm2,%xmm7
   21ca6:	66 0f 59 ef          	mulpd  %xmm7,%xmm5
   21caa:	66 45 0f 57 c0       	xorpd  %xmm8,%xmm8
   21caf:	66 45 0f 14 c7       	unpcklpd %xmm15,%xmm8
   21cb4:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   21cb9:	66 45 0f 59 d8       	mulpd  %xmm8,%xmm11
   21cbe:	66 45 0f c6 db 01    	shufpd $0x1,%xmm11,%xmm11
   21cc4:	f3 44 0f 7e d3       	movq   %xmm3,%xmm10
   21cc9:	66 41 0f 59 d2       	mulpd  %xmm10,%xmm2
   21cce:	66 41 0f 58 d3       	addpd  %xmm11,%xmm2
   21cd3:	66 0f 58 d5          	addpd  %xmm5,%xmm2
   21cd7:	66 0f 29 94 24 80 00 	movapd %xmm2,0x80(%rsp)
   21cde:	00 00 
   21ce0:	66 45 0f 28 d9       	movapd %xmm9,%xmm11
   21ce5:	66 44 0f 59 1d 02 37 	mulpd  -0x1c8fe(%rip),%xmm11        # 53f0 <std::thread::current::id::ID+0x4778>
   21cec:	fe ff 
   21cee:	66 45 0f 59 cb       	mulpd  %xmm11,%xmm9
   21cf3:	66 0f 6f eb          	movdqa %xmm3,%xmm5
   21cf7:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   21cfc:	66 45 0f 28 e1       	movapd %xmm9,%xmm12
   21d01:	66 45 0f c6 e1 01    	shufpd $0x1,%xmm9,%xmm12
   21d07:	66 44 0f 59 e4       	mulpd  %xmm4,%xmm12
   21d0c:	66 45 0f 28 e9       	movapd %xmm9,%xmm13
   21d11:	66 44 0f 59 ee       	mulpd  %xmm6,%xmm13
   21d16:	66 45 0f 58 ec       	addpd  %xmm12,%xmm13
   21d1b:	f2 0f 10 15 ad 55 fe 	movsd  -0x1aa53(%rip),%xmm2        # 72d0 <std::thread::current::id::ID+0x6658>
   21d22:	ff 
   21d23:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   21d27:	f2 0f 59 c2          	mulsd  %xmm2,%xmm0
   21d2b:	66 0f 14 c0          	unpcklpd %xmm0,%xmm0
   21d2f:	66 44 0f 28 c8       	movapd %xmm0,%xmm9
   21d34:	66 44 0f 59 c9       	mulpd  %xmm1,%xmm9
   21d39:	66 45 0f 58 cd       	addpd  %xmm13,%xmm9
   21d3e:	66 44 0f 29 4c 24 60 	movapd %xmm9,0x60(%rsp)
   21d45:	66 44 0f 28 e3       	movapd %xmm3,%xmm12
   21d4a:	66 45 0f 59 e0       	mulpd  %xmm8,%xmm12
   21d4f:	66 45 0f c6 e4 01    	shufpd $0x1,%xmm12,%xmm12
   21d55:	66 41 0f 59 da       	mulpd  %xmm10,%xmm3
   21d5a:	66 41 0f 58 dc       	addpd  %xmm12,%xmm3
   21d5f:	66 0f 59 c7          	mulpd  %xmm7,%xmm0
   21d63:	66 0f 58 d8          	addpd  %xmm0,%xmm3
   21d67:	66 0f 29 5c 24 70    	movapd %xmm3,0x70(%rsp)
   21d6d:	66 41 0f 28 c3       	movapd %xmm11,%xmm0
   21d72:	66 41 0f c6 c3 01    	shufpd $0x1,%xmm11,%xmm0
   21d78:	66 0f 59 c4          	mulpd  %xmm4,%xmm0
   21d7c:	66 41 0f 59 f3       	mulpd  %xmm11,%xmm6
   21d81:	66 0f 58 f0          	addpd  %xmm0,%xmm6
   21d85:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   21d89:	66 0f 28 c2          	movapd %xmm2,%xmm0
   21d8d:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   21d91:	66 0f 58 c6          	addpd  %xmm6,%xmm0
   21d95:	66 0f 28 f0          	movapd %xmm0,%xmm6
   21d99:	66 0f 29 44 24 50    	movapd %xmm0,0x50(%rsp)
   21d9f:	66 45 0f 59 c3       	mulpd  %xmm11,%xmm8
   21da4:	66 45 0f c6 c0 01    	shufpd $0x1,%xmm8,%xmm8
   21daa:	66 45 0f 59 da       	mulpd  %xmm10,%xmm11
   21daf:	66 45 0f 58 d8       	addpd  %xmm8,%xmm11
   21db4:	66 0f 59 d7          	mulpd  %xmm7,%xmm2
   21db8:	66 41 0f 58 d3       	addpd  %xmm11,%xmm2
   21dbd:	66 0f 29 94 24 60 01 	movapd %xmm2,0x160(%rsp)
   21dc4:	00 00 
   21dc6:	f2 44 0f 58 fd       	addsd  %xmm5,%xmm15
   21dcb:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   21dd1:	66 0f 58 c1          	addpd  %xmm1,%xmm0
   21dd5:	66 0f 29 44 24 10    	movapd %xmm0,0x10(%rsp)
   21ddb:	f2 44 0f 58 7c 24 30 	addsd  0x30(%rsp),%xmm15
   21de2:	66 44 0f 29 7c 24 30 	movapd %xmm15,0x30(%rsp)
   21de9:	66 41 0f 28 de       	movapd %xmm14,%xmm3
   21dee:	66 45 0f 28 fe       	movapd %xmm14,%xmm15
   21df3:	66 44 0f 29 b4 24 70 	movapd %xmm14,0x170(%rsp)
   21dfa:	01 00 00 
   21dfd:	66 0f 59 1d eb 35 fe 	mulpd  -0x1ca15(%rip),%xmm3        # 53f0 <std::thread::current::id::ID+0x4778>
   21e04:	ff 
   21e05:	66 45 0f 28 c1       	movapd %xmm9,%xmm8
   21e0a:	66 45 0f 58 c1       	addpd  %xmm9,%xmm8
   21e0f:	66 45 0f 28 d0       	movapd %xmm8,%xmm10
   21e14:	66 45 0f 59 d0       	mulpd  %xmm8,%xmm10
   21e19:	66 0f 59 f3          	mulpd  %xmm3,%xmm6
   21e1d:	66 0f 59 35 3b 36 fe 	mulpd  -0x1c9c5(%rip),%xmm6        # 5460 <std::thread::current::id::ID+0x47e8>
   21e24:	ff 
   21e25:	66 41 0f 28 fa       	movapd %xmm10,%xmm7
   21e2a:	66 0f 5c fe          	subpd  %xmm6,%xmm7
   21e2e:	66 45 0f 28 c8       	movapd %xmm8,%xmm9
   21e33:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   21e37:	66 44 0f c2 c8 05    	cmpnltpd %xmm0,%xmm9
   21e3d:	66 0f 28 cf          	movapd %xmm7,%xmm1
   21e41:	66 0f 5f c8          	maxpd  %xmm0,%xmm1
   21e45:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   21e49:	66 0f 51 e1          	sqrtpd %xmm1,%xmm4
   21e4d:	66 0f 28 2d 3b 39 fe 	movapd -0x1c6c5(%rip),%xmm5        # 5790 <std::thread::current::id::ID+0x4b18>
   21e54:	ff 
   21e55:	66 44 0f 28 dc       	movapd %xmm4,%xmm11
   21e5a:	66 44 0f 57 dd       	xorpd  %xmm5,%xmm11
   21e5f:	66 41 0f 54 e1       	andpd  %xmm9,%xmm4
   21e64:	66 45 0f 55 cb       	andnpd %xmm11,%xmm9
   21e69:	66 44 0f 56 cc       	orpd   %xmm4,%xmm9
   21e6e:	66 0f 28 05 aa 33 fe 	movapd -0x1cc56(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   21e75:	ff 
   21e76:	66 0f 54 f0          	andpd  %xmm0,%xmm6
   21e7a:	66 41 0f 58 f2       	addpd  %xmm10,%xmm6
   21e7f:	66 45 0f 57 db       	xorpd  %xmm11,%xmm11
   21e84:	66 44 0f c2 df 02    	cmplepd %xmm7,%xmm11
   21e8a:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   21e8e:	66 0f 59 35 9a 36 fe 	mulpd  -0x1c966(%rip),%xmm6        # 5530 <std::thread::current::id::ID+0x48b8>
   21e95:	ff 
   21e96:	66 0f c2 fe 02       	cmplepd %xmm6,%xmm7
   21e9b:	66 44 0f 28 d3       	movapd %xmm3,%xmm10
   21ea0:	66 44 0f c2 d2 04    	cmpneqpd %xmm2,%xmm10
   21ea6:	66 41 0f 54 da       	andpd  %xmm10,%xmm3
   21eab:	66 41 0f 28 c0       	movapd %xmm8,%xmm0
   21eb0:	66 0f c2 c2 00       	cmpeqpd %xmm2,%xmm0
   21eb5:	66 0f 28 25 e3 37 fe 	movapd -0x1c81d(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   21ebc:	ff 
   21ebd:	66 44 0f 28 f4       	movapd %xmm4,%xmm14
   21ec2:	66 44 0f 54 f0       	andpd  %xmm0,%xmm14
   21ec7:	66 45 0f 54 da       	andpd  %xmm10,%xmm11
   21ecc:	66 44 0f 28 e0       	movapd %xmm0,%xmm12
   21ed1:	66 41 0f 56 c2       	orpd   %xmm10,%xmm0
   21ed6:	66 41 0f 54 fa       	andpd  %xmm10,%xmm7
   21edb:	66 41 0f 28 ca       	movapd %xmm10,%xmm1
   21ee0:	66 0f 55 cc          	andnpd %xmm4,%xmm1
   21ee4:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   21ee8:	66 45 0f 58 c8       	addpd  %xmm8,%xmm9
   21eed:	66 44 0f 28 15 9a 39 	movapd -0x1c666(%rip),%xmm10        # 5890 <std::thread::current::id::ID+0x4c18>
   21ef4:	fe ff 
   21ef6:	66 45 0f 59 ca       	mulpd  %xmm10,%xmm9
   21efb:	66 41 0f 28 d9       	movapd %xmm9,%xmm3
   21f00:	66 0f c2 da 04       	cmpneqpd %xmm2,%xmm3
   21f05:	66 41 0f 28 f1       	movapd %xmm9,%xmm6
   21f0a:	66 0f 54 f3          	andpd  %xmm3,%xmm6
   21f0e:	66 45 0f 70 eb a0    	pshufd $0xa0,%xmm11,%xmm13
   21f14:	66 44 0f 54 db       	andpd  %xmm3,%xmm11
   21f19:	66 0f 55 dc          	andnpd %xmm4,%xmm3
   21f1d:	66 0f 56 de          	orpd   %xmm6,%xmm3
   21f21:	66 45 0f 55 e0       	andnpd %xmm8,%xmm12
   21f26:	66 45 0f 56 f4       	orpd   %xmm12,%xmm14
   21f2b:	66 44 0f 5e c9       	divpd  %xmm1,%xmm9
   21f30:	66 44 0f 57 fd       	xorpd  %xmm5,%xmm15
   21f35:	66 44 0f 29 7c 24 20 	movapd %xmm15,0x20(%rsp)
   21f3c:	66 44 0f 29 bc 24 a0 	movapd %xmm15,0xa0(%rsp)
   21f43:	00 00 00 
   21f46:	66 0f 28 a4 24 80 00 	movapd 0x80(%rsp),%xmm4
   21f4d:	00 00 
   21f4f:	66 0f 28 cc          	movapd %xmm4,%xmm1
   21f53:	66 0f 57 cd          	xorpd  %xmm5,%xmm1
   21f57:	66 0f 29 8c 24 b0 00 	movapd %xmm1,0xb0(%rsp)
   21f5e:	00 00 
   21f60:	66 0f 28 74 24 60    	movapd 0x60(%rsp),%xmm6
   21f66:	66 0f 57 f5          	xorpd  %xmm5,%xmm6
   21f6a:	66 0f 29 b4 24 c0 00 	movapd %xmm6,0xc0(%rsp)
   21f71:	00 00 
   21f73:	66 0f 28 54 24 70    	movapd 0x70(%rsp),%xmm2
   21f79:	66 44 0f 28 c2       	movapd %xmm2,%xmm8
   21f7e:	66 44 0f 57 c5       	xorpd  %xmm5,%xmm8
   21f83:	66 44 0f 29 84 24 d0 	movapd %xmm8,0xd0(%rsp)
   21f8a:	00 00 00 
   21f8d:	66 0f 28 4c 24 50    	movapd 0x50(%rsp),%xmm1
   21f93:	66 44 0f 28 c1       	movapd %xmm1,%xmm8
   21f98:	66 44 0f 57 c5       	xorpd  %xmm5,%xmm8
   21f9d:	66 44 0f 28 fd       	movapd %xmm5,%xmm15
   21fa2:	66 44 0f 29 84 24 e0 	movapd %xmm8,0xe0(%rsp)
   21fa9:	00 00 00 
   21fac:	66 45 0f 5e c6       	divpd  %xmm14,%xmm8
   21fb1:	66 0f 73 f0 3f       	psllq  $0x3f,%xmm0
   21fb6:	66 0f 72 e0 1f       	psrad  $0x1f,%xmm0
   21fbb:	66 44 0f 70 e0 f5    	pshufd $0xf5,%xmm0,%xmm12
   21fc1:	66 45 0f df e0       	pandn  %xmm8,%xmm12
   21fc6:	66 44 0f 6f 35 81 37 	movdqa -0x1c87f(%rip),%xmm14        # 5750 <std::thread::current::id::ID+0x4ad8>
   21fcd:	fe ff 
   21fcf:	66 41 0f db c6       	pand   %xmm14,%xmm0
   21fd4:	66 41 0f eb c4       	por    %xmm12,%xmm0
   21fd9:	66 45 0f 54 cd       	andpd  %xmm13,%xmm9
   21fde:	66 44 0f df e8       	pandn  %xmm0,%xmm13
   21fe3:	66 45 0f eb e9       	por    %xmm9,%xmm13
   21fe8:	66 0f 28 c1          	movapd %xmm1,%xmm0
   21fec:	66 0f 5e c3          	divpd  %xmm3,%xmm0
   21ff0:	66 41 0f 70 db a0    	pshufd $0xa0,%xmm11,%xmm3
   21ff6:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   21ffa:	66 41 0f df de       	pandn  %xmm14,%xmm3
   21fff:	66 0f eb d8          	por    %xmm0,%xmm3
   22003:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   22007:	66 41 0f c2 c5 05    	cmpnltpd %xmm13,%xmm0
   2200d:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
   22012:	66 44 0f db c0       	pand   %xmm0,%xmm8
   22017:	66 41 0f df c5       	pandn  %xmm13,%xmm0
   2201c:	66 41 0f eb c0       	por    %xmm8,%xmm0
   22021:	66 45 0f ef c0       	pxor   %xmm8,%xmm8
   22026:	66 44 0f c2 c3 05    	cmpnltpd %xmm3,%xmm8
   2202c:	66 45 0f 6f ce       	movdqa %xmm14,%xmm9
   22031:	66 45 0f db c8       	pand   %xmm8,%xmm9
   22036:	66 44 0f df c3       	pandn  %xmm3,%xmm8
   2203b:	66 45 0f eb c1       	por    %xmm9,%xmm8
   22040:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   22044:	66 41 0f 5d d8       	minpd  %xmm8,%xmm3
   22049:	66 44 0f 28 cb       	movapd %xmm3,%xmm9
   2204e:	66 44 0f c2 cb 03    	cmpunordpd %xmm3,%xmm9
   22054:	66 44 0f 6f d8       	movdqa %xmm0,%xmm11
   22059:	66 45 0f db d9       	pand   %xmm9,%xmm11
   2205e:	66 44 0f 55 cb       	andnpd %xmm3,%xmm9
   22063:	66 45 0f 56 cb       	orpd   %xmm11,%xmm9
   22068:	66 41 0f 55 f9       	andnpd %xmm9,%xmm7
   2206d:	66 0f 29 bc 24 c0 01 	movapd %xmm7,0x1c0(%rsp)
   22074:	00 00 
   22076:	66 0f 6f d8          	movdqa %xmm0,%xmm3
   2207a:	66 41 0f 5f d8       	maxpd  %xmm8,%xmm3
   2207f:	66 0f 28 fb          	movapd %xmm3,%xmm7
   22083:	66 0f c2 fb 03       	cmpunordpd %xmm3,%xmm7
   22088:	66 0f db c7          	pand   %xmm7,%xmm0
   2208c:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   22090:	66 0f 56 f8          	orpd   %xmm0,%xmm7
   22094:	66 0f 29 bc 24 e0 01 	movapd %xmm7,0x1e0(%rsp)
   2209b:	00 00 
   2209d:	66 0f 28 0d 4b 33 fe 	movapd -0x1ccb5(%rip),%xmm1        # 53f0 <std::thread::current::id::ID+0x4778>
   220a4:	ff 
   220a5:	66 0f 59 cc          	mulpd  %xmm4,%xmm1
   220a9:	66 0f 28 ac 24 60 01 	movapd 0x160(%rsp),%xmm5
   220b0:	00 00 
   220b2:	66 0f 28 c5          	movapd %xmm5,%xmm0
   220b6:	66 0f 59 c1          	mulpd  %xmm1,%xmm0
   220ba:	66 0f 28 e1          	movapd %xmm1,%xmm4
   220be:	66 0f 59 05 9a 33 fe 	mulpd  -0x1cc66(%rip),%xmm0        # 5460 <std::thread::current::id::ID+0x47e8>
   220c5:	ff 
   220c6:	66 44 0f 28 da       	movapd %xmm2,%xmm11
   220cb:	66 44 0f 58 da       	addpd  %xmm2,%xmm11
   220d0:	66 41 0f 28 db       	movapd %xmm11,%xmm3
   220d5:	66 41 0f 59 db       	mulpd  %xmm11,%xmm3
   220da:	66 0f 28 fb          	movapd %xmm3,%xmm7
   220de:	66 0f 5c f8          	subpd  %xmm0,%xmm7
   220e2:	66 44 0f 28 c7       	movapd %xmm7,%xmm8
   220e7:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   220eb:	f2 44 0f 5f c1       	maxsd  %xmm1,%xmm8
   220f0:	45 0f 57 c9          	xorps  %xmm9,%xmm9
   220f4:	f2 45 0f 51 c8       	sqrtsd %xmm8,%xmm9
   220f9:	66 45 0f 28 c3       	movapd %xmm11,%xmm8
   220fe:	f2 44 0f c2 c1 05    	cmpnltsd %xmm1,%xmm8
   22104:	66 45 0f 28 e0       	movapd %xmm8,%xmm12
   22109:	66 45 0f 54 e1       	andpd  %xmm9,%xmm12
   2210e:	66 45 0f 57 cf       	xorpd  %xmm15,%xmm9
   22113:	66 45 0f 55 c1       	andnpd %xmm9,%xmm8
   22118:	66 45 0f 56 c4       	orpd   %xmm12,%xmm8
   2211d:	66 44 0f 28 cf       	movapd %xmm7,%xmm9
   22122:	66 44 0f 15 cf       	unpckhpd %xmm7,%xmm9
   22127:	f2 44 0f 5f c9       	maxsd  %xmm1,%xmm9
   2212c:	f2 45 0f 51 c9       	sqrtsd %xmm9,%xmm9
   22131:	66 45 0f 14 c1       	unpcklpd %xmm9,%xmm8
   22136:	66 45 0f 58 c3       	addpd  %xmm11,%xmm8
   2213b:	66 45 0f 59 c2       	mulpd  %xmm10,%xmm8
   22140:	66 0f 28 0d d8 30 fe 	movapd -0x1cf28(%rip),%xmm1        # 5220 <std::thread::current::id::ID+0x45a8>
   22147:	ff 
   22148:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2214c:	66 0f 58 c3          	addpd  %xmm3,%xmm0
   22150:	66 0f 59 05 d8 33 fe 	mulpd  -0x1cc28(%rip),%xmm0        # 5530 <std::thread::current::id::ID+0x48b8>
   22157:	ff 
   22158:	66 45 0f 57 d2       	xorpd  %xmm10,%xmm10
   2215d:	66 44 0f c2 d7 02    	cmplepd %xmm7,%xmm10
   22163:	66 0f 54 f9          	andpd  %xmm1,%xmm7
   22167:	66 0f c2 f8 02       	cmplepd %xmm0,%xmm7
   2216c:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22170:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22174:	66 0f c2 c1 04       	cmpneqpd %xmm1,%xmm0
   22179:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   2217d:	66 45 0f 28 e3       	movapd %xmm11,%xmm12
   22182:	66 44 0f c2 e1 00    	cmpeqpd %xmm1,%xmm12
   22188:	66 45 0f 57 ff       	xorpd  %xmm15,%xmm15
   2218d:	66 0f 28 15 0b 35 fe 	movapd -0x1caf5(%rip),%xmm2        # 56a0 <std::thread::current::id::ID+0x4a28>
   22194:	ff 
   22195:	66 0f 28 da          	movapd %xmm2,%xmm3
   22199:	66 41 0f 54 dc       	andpd  %xmm12,%xmm3
   2219e:	66 44 0f 54 d0       	andpd  %xmm0,%xmm10
   221a3:	66 45 0f 28 cc       	movapd %xmm12,%xmm9
   221a8:	66 44 0f 56 e0       	orpd   %xmm0,%xmm12
   221ad:	66 0f 54 f8          	andpd  %xmm0,%xmm7
   221b1:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   221b5:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   221b9:	66 45 0f 28 e8       	movapd %xmm8,%xmm13
   221be:	66 45 0f c2 ef 04    	cmpneqpd %xmm15,%xmm13
   221c4:	66 0f 57 e4          	xorpd  %xmm4,%xmm4
   221c8:	66 45 0f 28 f8       	movapd %xmm8,%xmm15
   221cd:	66 45 0f 54 fd       	andpd  %xmm13,%xmm15
   221d2:	66 41 0f 70 ca a0    	pshufd $0xa0,%xmm10,%xmm1
   221d8:	66 45 0f 54 d5       	andpd  %xmm13,%xmm10
   221dd:	66 44 0f 55 ea       	andnpd %xmm2,%xmm13
   221e2:	66 45 0f 56 ef       	orpd   %xmm15,%xmm13
   221e7:	66 45 0f 55 cb       	andnpd %xmm11,%xmm9
   221ec:	66 41 0f 56 d9       	orpd   %xmm9,%xmm3
   221f1:	66 44 0f 5e c0       	divpd  %xmm0,%xmm8
   221f6:	66 0f 28 c5          	movapd %xmm5,%xmm0
   221fa:	66 44 0f 28 1d 8d 35 	movapd -0x1ca73(%rip),%xmm11        # 5790 <std::thread::current::id::ID+0x4b18>
   22201:	fe ff 
   22203:	66 41 0f 57 c3       	xorpd  %xmm11,%xmm0
   22208:	66 0f 29 84 24 f0 00 	movapd %xmm0,0xf0(%rsp)
   2220f:	00 00 
   22211:	66 0f 5e c3          	divpd  %xmm3,%xmm0
   22215:	66 41 0f 73 f4 3f    	psllq  $0x3f,%xmm12
   2221b:	66 41 0f 72 e4 1f    	psrad  $0x1f,%xmm12
   22221:	66 41 0f 70 dc f5    	pshufd $0xf5,%xmm12,%xmm3
   22227:	66 0f df d8          	pandn  %xmm0,%xmm3
   2222b:	66 45 0f db e6       	pand   %xmm14,%xmm12
   22230:	66 44 0f eb e3       	por    %xmm3,%xmm12
   22235:	66 44 0f 54 c1       	andpd  %xmm1,%xmm8
   2223a:	66 41 0f df cc       	pandn  %xmm12,%xmm1
   2223f:	66 41 0f eb c8       	por    %xmm8,%xmm1
   22244:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22248:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   2224d:	66 41 0f 5e c5       	divpd  %xmm13,%xmm0
   22252:	66 41 0f 70 da a0    	pshufd $0xa0,%xmm10,%xmm3
   22258:	66 0f 54 c3          	andpd  %xmm3,%xmm0
   2225c:	66 41 0f df de       	pandn  %xmm14,%xmm3
   22261:	66 0f eb d8          	por    %xmm0,%xmm3
   22265:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   22269:	66 0f c2 c1 05       	cmpnltpd %xmm1,%xmm0
   2226e:	66 45 0f 6f c6       	movdqa %xmm14,%xmm8
   22273:	66 44 0f db c0       	pand   %xmm0,%xmm8
   22278:	66 0f df c1          	pandn  %xmm1,%xmm0
   2227c:	66 41 0f eb c0       	por    %xmm8,%xmm0
   22281:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   22285:	66 0f c2 d3 05       	cmpnltpd %xmm3,%xmm2
   2228a:	66 44 0f db f2       	pand   %xmm2,%xmm14
   2228f:	66 0f df d3          	pandn  %xmm3,%xmm2
   22293:	66 41 0f eb d6       	por    %xmm14,%xmm2
   22298:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   2229c:	66 0f 5d ca          	minpd  %xmm2,%xmm1
   222a0:	66 0f 28 d9          	movapd %xmm1,%xmm3
   222a4:	66 0f c2 d9 03       	cmpunordpd %xmm1,%xmm3
   222a9:	66 44 0f 6f c0       	movdqa %xmm0,%xmm8
   222ae:	66 44 0f db c3       	pand   %xmm3,%xmm8
   222b3:	66 0f 55 d9          	andnpd %xmm1,%xmm3
   222b7:	66 41 0f 56 d8       	orpd   %xmm8,%xmm3
   222bc:	66 0f 55 fb          	andnpd %xmm3,%xmm7
   222c0:	66 0f 29 bc 24 d0 01 	movapd %xmm7,0x1d0(%rsp)
   222c7:	00 00 
   222c9:	66 0f 6f c8          	movdqa %xmm0,%xmm1
   222cd:	66 0f 5f ca          	maxpd  %xmm2,%xmm1
   222d1:	66 0f 28 d1          	movapd %xmm1,%xmm2
   222d5:	66 0f c2 d1 03       	cmpunordpd %xmm1,%xmm2
   222da:	66 0f db c2          	pand   %xmm2,%xmm0
   222de:	66 0f 55 d1          	andnpd %xmm1,%xmm2
   222e2:	66 0f 56 d0          	orpd   %xmm0,%xmm2
   222e6:	66 0f 28 5c 24 70    	movapd 0x70(%rsp),%xmm3
   222ec:	66 0f 28 c3          	movapd %xmm3,%xmm0
   222f0:	66 0f 28 2d 28 2f fe 	movapd -0x1d0d8(%rip),%xmm5        # 5220 <std::thread::current::id::ID+0x45a8>
   222f7:	ff 
   222f8:	66 0f 54 c5          	andpd  %xmm5,%xmm0
   222fc:	66 41 0f 28 c9       	movapd %xmm9,%xmm1
   22301:	66 0f 54 cd          	andpd  %xmm5,%xmm1
   22305:	66 44 0f 28 cd       	movapd %xmm5,%xmm9
   2230a:	f2 0f c2 dc 00       	cmpeqsd %xmm4,%xmm3
   2230f:	66 0f 28 fb          	movapd %xmm3,%xmm7
   22313:	66 0f 55 f8          	andnpd %xmm0,%xmm7
   22317:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   2231b:	66 0f 56 df          	orpd   %xmm7,%xmm3
   2231f:	66 0f 28 ac 24 80 00 	movapd 0x80(%rsp),%xmm5
   22326:	00 00 
   22328:	66 0f 28 fd          	movapd %xmm5,%xmm7
   2232c:	66 41 0f 54 f9       	andpd  %xmm9,%xmm7
   22331:	f2 0f c2 e5 00       	cmpeqsd %xmm5,%xmm4
   22336:	66 44 0f 28 c4       	movapd %xmm4,%xmm8
   2233b:	66 44 0f 55 c7       	andnpd %xmm7,%xmm8
   22340:	66 0f 54 e3          	andpd  %xmm3,%xmm4
   22344:	66 41 0f 56 e0       	orpd   %xmm8,%xmm4
   22349:	f2 0f 5f 25 cf 4e fe 	maxsd  -0x1b131(%rip),%xmm4        # 7220 <std::thread::current::id::ID+0x65a8>
   22350:	ff 
   22351:	66 0f 29 94 24 f0 01 	movapd %xmm2,0x1f0(%rsp)
   22358:	00 00 
   2235a:	66 0f 28 d0          	movapd %xmm0,%xmm2
   2235e:	f2 0f 5f d1          	maxsd  %xmm1,%xmm2
   22362:	66 0f 28 ca          	movapd %xmm2,%xmm1
   22366:	f2 0f c2 ca 03       	cmpunordsd %xmm2,%xmm1
   2236b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   2236f:	66 0f 55 ca          	andnpd %xmm2,%xmm1
   22373:	66 0f 56 c8          	orpd   %xmm0,%xmm1
   22377:	66 0f 28 7c 24 30    	movapd 0x30(%rsp),%xmm7
   2237d:	66 0f 28 c7          	movapd %xmm7,%xmm0
   22381:	66 41 0f 54 c1       	andpd  %xmm9,%xmm0
   22386:	66 0f 28 d9          	movapd %xmm1,%xmm3
   2238a:	f2 0f 5f d8          	maxsd  %xmm0,%xmm3
   2238e:	66 0f 28 d3          	movapd %xmm3,%xmm2
   22392:	f2 0f c2 d3 03       	cmpunordsd %xmm3,%xmm2
   22397:	66 0f 54 ca          	andpd  %xmm2,%xmm1
   2239b:	66 0f 55 d3          	andnpd %xmm3,%xmm2
   2239f:	66 0f 56 d1          	orpd   %xmm1,%xmm2
   223a3:	f2 0f 5e d4          	divsd  %xmm4,%xmm2
   223a7:	66 0f 28 a4 24 70 01 	movapd 0x170(%rsp),%xmm4
   223ae:	00 00 
   223b0:	66 0f 28 c4          	movapd %xmm4,%xmm0
   223b4:	66 0f c2 44 24 20 00 	cmpeqpd 0x20(%rsp),%xmm0
   223bb:	66 0f 28 5c 24 60    	movapd 0x60(%rsp),%xmm3
   223c1:	66 0f 28 cb          	movapd %xmm3,%xmm1
   223c5:	66 0f c2 ce 00       	cmpeqpd %xmm6,%xmm1
   223ca:	66 41 0f 54 d9       	andpd  %xmm9,%xmm3
   223cf:	66 0f 28 6c 24 50    	movapd 0x50(%rsp),%xmm5
   223d5:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   223da:	66 0f 28 f3          	movapd %xmm3,%xmm6
   223de:	66 0f 5f f5          	maxpd  %xmm5,%xmm6
   223e2:	66 0f 54 e9          	andpd  %xmm1,%xmm5
   223e6:	66 0f 55 cb          	andnpd %xmm3,%xmm1
   223ea:	66 0f 56 cd          	orpd   %xmm5,%xmm1
   223ee:	66 0f 28 ec          	movapd %xmm4,%xmm5
   223f2:	66 41 0f 54 e9       	andpd  %xmm9,%xmm5
   223f7:	66 0f 54 c8          	andpd  %xmm0,%xmm1
   223fb:	66 0f 55 c5          	andnpd %xmm5,%xmm0
   223ff:	66 0f 56 c1          	orpd   %xmm1,%xmm0
   22403:	66 0f 28 ce          	movapd %xmm6,%xmm1
   22407:	66 0f c2 ce 03       	cmpunordpd %xmm6,%xmm1
   2240c:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   22410:	66 0f 55 ce          	andnpd %xmm6,%xmm1
   22414:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   22418:	66 0f 28 6c 24 10    	movapd 0x10(%rsp),%xmm5
   2241e:	66 44 0f 54 cd       	andpd  %xmm5,%xmm9
   22423:	66 0f 28 d9          	movapd %xmm1,%xmm3
   22427:	66 41 0f 5f d9       	maxpd  %xmm9,%xmm3
   2242c:	66 0f 28 e3          	movapd %xmm3,%xmm4
   22430:	66 0f c2 e3 03       	cmpunordpd %xmm3,%xmm4
   22435:	66 0f 54 cc          	andpd  %xmm4,%xmm1
   22439:	66 0f 55 e3          	andnpd %xmm3,%xmm4
   2243d:	66 0f 56 e1          	orpd   %xmm1,%xmm4
   22441:	66 0f 5f 05 77 2e fe 	maxpd  -0x1d189(%rip),%xmm0        # 52c0 <std::thread::current::id::ID+0x4648>
   22448:	ff 
   22449:	66 0f 5e e0          	divpd  %xmm0,%xmm4
   2244d:	66 0f 58 25 4b 32 fe 	addpd  -0x1cdb5(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   22454:	ff 
   22455:	66 0f 29 a4 24 80 01 	movapd %xmm4,0x180(%rsp)
   2245c:	00 00 
   2245e:	f2 0f 58 15 f2 4d fe 	addsd  -0x1b20e(%rip),%xmm2        # 7258 <std::thread::current::id::ID+0x65e0>
   22465:	ff 
   22466:	f2 0f 11 94 24 90 01 	movsd  %xmm2,0x190(%rsp)
   2246d:	00 00 
   2246f:	66 0f 28 c7          	movapd %xmm7,%xmm0
   22473:	66 41 0f 28 d3       	movapd %xmm11,%xmm2
   22478:	66 41 0f 57 c3       	xorpd  %xmm11,%xmm0
   2247d:	66 0f 57 d5          	xorpd  %xmm5,%xmm2
   22481:	66 0f 29 94 24 00 01 	movapd %xmm2,0x100(%rsp)
   22488:	00 00 
   2248a:	48 b8 00 00 00 00 00 	movabs $0x3ff0000000000000,%rax
   22491:	00 f0 3f 
   22494:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
   2249b:	00 
   2249c:	66 0f 13 84 24 10 01 	movlpd %xmm0,0x110(%rsp)
   224a3:	00 00 
   224a5:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   224ab:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   224af:	48 b8 00 00 00 00 00 	movabs $0xbff0000000000000,%rax
   224b6:	00 f0 bf 
   224b9:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   224c0:	00 
   224c1:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   224c8:	00 
   224c9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   224d0:	00 
   224d1:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
   224d8:	00 
   224d9:	48 8d 8c 24 80 01 00 	lea    0x180(%rsp),%rcx
   224e0:	00 
   224e1:	f2 0f 11 44 24 20    	movsd  %xmm0,0x20(%rsp)
   224e7:	e8 c4 e5 ff ff       	call   20ab0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>
   224ec:	f2 0f 10 84 24 20 01 	movsd  0x120(%rsp),%xmm0
   224f3:	00 00 
   224f5:	f2 0f 10 8c 24 28 01 	movsd  0x128(%rsp),%xmm1
   224fc:	00 00 
   224fe:	f2 0f 10 a4 24 30 01 	movsd  0x130(%rsp),%xmm4
   22505:	00 00 
   22507:	f2 0f 5d 05 e9 4c fe 	minsd  -0x1b317(%rip),%xmm0        # 71f8 <std::thread::current::id::ID+0x6580>
   2250e:	ff 
   2250f:	f2 0f 5d c8          	minsd  %xmm0,%xmm1
   22513:	f2 0f 5d e1          	minsd  %xmm1,%xmm4
   22517:	66 48 0f 7e e0       	movq   %xmm4,%rax
   2251c:	49 bf ff ff ff ff ff 	movabs $0x7fffffffffffffff,%r15
   22523:	ff ff 7f 
   22526:	4c 21 f8             	and    %r15,%rax
   22529:	41 be 0e 00 00 00    	mov    $0xe,%r14d
   2252f:	48 b9 ff ff ff ff ff 	movabs $0x7fefffffffffffff,%rcx
   22536:	ff ef 7f 
   22539:	48 39 c8             	cmp    %rcx,%rax
   2253c:	7e 12                	jle    22550 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa40>
   2253e:	4c 89 f0             	mov    %r14,%rax
   22541:	48 8d 65 d8          	lea    -0x28(%rbp),%rsp
   22545:	5b                   	pop    %rbx
   22546:	41 5c                	pop    %r12
   22548:	41 5d                	pop    %r13
   2254a:	41 5e                	pop    %r14
   2254c:	41 5f                	pop    %r15
   2254e:	5d                   	pop    %rbp
   2254f:	c3                   	ret
   22550:	f2 0f 10 84 24 40 01 	movsd  0x140(%rsp),%xmm0
   22557:	00 00 
   22559:	0f 29 84 24 b0 01 00 	movaps %xmm0,0x1b0(%rsp)
   22560:	00 
   22561:	0f 10 84 24 48 01 00 	movups 0x148(%rsp),%xmm0
   22568:	00 
   22569:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
   22570:	00 
   22571:	f2 0f 10 6c 24 20    	movsd  0x20(%rsp),%xmm5
   22577:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2257b:	f2 0f 59 c5          	mulsd  %xmm5,%xmm0
   2257f:	f2 0f 59 c5          	mulsd  %xmm5,%xmm0
   22583:	f2 0f 10 0d cd 4c fe 	movsd  -0x1b333(%rip),%xmm1        # 7258 <std::thread::current::id::ID+0x65e0>
   2258a:	ff 
   2258b:	66 0f 28 d1          	movapd %xmm1,%xmm2
   2258f:	f2 0f 5e d0          	divsd  %xmm0,%xmm2
   22593:	66 0f 28 5c 24 30    	movapd 0x30(%rsp),%xmm3
   22599:	f2 0f 5c da          	subsd  %xmm2,%xmm3
   2259d:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   225a1:	66 0f 14 d2          	unpcklpd %xmm2,%xmm2
   225a5:	66 0f 28 44 24 10    	movapd 0x10(%rsp),%xmm0
   225ab:	66 0f 5c c2          	subpd  %xmm2,%xmm0
   225af:	66 0f 29 84 24 00 01 	movapd %xmm0,0x100(%rsp)
   225b6:	00 00 
   225b8:	f2 0f 11 9c 24 10 01 	movsd  %xmm3,0x110(%rsp)
   225bf:	00 00 
   225c1:	f2 0f 11 8c 24 18 01 	movsd  %xmm1,0x118(%rsp)
   225c8:	00 00 
   225ca:	0f 28 84 24 70 01 00 	movaps 0x170(%rsp),%xmm0
   225d1:	00 
   225d2:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   225d9:	00 
   225da:	0f 28 84 24 80 00 00 	movaps 0x80(%rsp),%xmm0
   225e1:	00 
   225e2:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   225e9:	00 
   225ea:	0f 28 44 24 60       	movaps 0x60(%rsp),%xmm0
   225ef:	0f 29 84 24 c0 00 00 	movaps %xmm0,0xc0(%rsp)
   225f6:	00 
   225f7:	0f 28 44 24 70       	movaps 0x70(%rsp),%xmm0
   225fc:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   22603:	00 
   22604:	0f 28 44 24 50       	movaps 0x50(%rsp),%xmm0
   22609:	0f 29 84 24 e0 00 00 	movaps %xmm0,0xe0(%rsp)
   22610:	00 
   22611:	0f 28 84 24 60 01 00 	movaps 0x160(%rsp),%xmm0
   22618:	00 
   22619:	0f 29 84 24 f0 00 00 	movaps %xmm0,0xf0(%rsp)
   22620:	00 
   22621:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22625:	66 0f 14 c4          	unpcklpd %xmm4,%xmm0
   22629:	66 0f 29 84 24 10 02 	movapd %xmm0,0x210(%rsp)
   22630:	00 00 
   22632:	66 0f 29 84 24 00 02 	movapd %xmm0,0x200(%rsp)
   22639:	00 00 
   2263b:	48 8d bc 24 20 01 00 	lea    0x120(%rsp),%rdi
   22642:	00 
   22643:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   2264a:	00 
   2264b:	48 8d 94 24 c0 01 00 	lea    0x1c0(%rsp),%rdx
   22652:	00 
   22653:	48 8d 8c 24 00 02 00 	lea    0x200(%rsp),%rcx
   2265a:	00 
   2265b:	66 0f 28 c5          	movapd %xmm5,%xmm0
   2265f:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22664:	e8 47 e4 ff ff       	call   20ab0 <<gpui_canvas::color::gamut::first_exit::__FearlessDispatch>::call::<fearless_simd::generated::fallback::Fallback, fearless_simd::generated::fallback::Fallback, gpui_canvas::color::gamut::Polynomial<fearless_simd::generated::fallback::Fallback>, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2], fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>, f64, gpui_canvas::color::gamut::first_exit<fearless_simd::generated::fallback::Fallback>::{closure#0}, [fearless_simd::generated::simd_types::f64x4<fearless_simd::generated::fallback::Fallback>; 2]>>
   22669:	66 0f 28 94 24 b0 01 	movapd 0x1b0(%rsp),%xmm2
   22670:	00 00 
   22672:	66 0f 28 c2          	movapd %xmm2,%xmm0
   22676:	f2 0f 5d 84 24 40 01 	minsd  0x140(%rsp),%xmm0
   2267d:	00 00 
   2267f:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22683:	f2 0f c2 c8 03       	cmpunordsd %xmm0,%xmm1
   22688:	66 0f 54 d1          	andpd  %xmm1,%xmm2
   2268c:	66 0f 55 c8          	andnpd %xmm0,%xmm1
   22690:	66 0f 28 5c 24 10    	movapd 0x10(%rsp),%xmm3
   22696:	66 0f 28 c3          	movapd %xmm3,%xmm0
   2269a:	f2 0f 5d 84 24 20 01 	minsd  0x120(%rsp),%xmm0
   226a1:	00 00 
   226a3:	66 0f 56 ca          	orpd   %xmm2,%xmm1
   226a7:	66 0f 28 d0          	movapd %xmm0,%xmm2
   226ab:	f2 0f c2 d0 03       	cmpunordsd %xmm0,%xmm2
   226b0:	66 0f 54 da          	andpd  %xmm2,%xmm3
   226b4:	66 0f 55 d0          	andnpd %xmm0,%xmm2
   226b8:	66 0f 56 d3          	orpd   %xmm3,%xmm2
   226bc:	f2 0f 10 84 24 28 01 	movsd  0x128(%rsp),%xmm0
   226c3:	00 00 
   226c5:	66 0f 28 da          	movapd %xmm2,%xmm3
   226c9:	f2 0f 5d d8          	minsd  %xmm0,%xmm3
   226cd:	66 0f 28 e3          	movapd %xmm3,%xmm4
   226d1:	f2 0f c2 e3 03       	cmpunordsd %xmm3,%xmm4
   226d6:	66 0f 54 d4          	andpd  %xmm4,%xmm2
   226da:	66 0f 55 e3          	andnpd %xmm3,%xmm4
   226de:	66 0f 56 e2          	orpd   %xmm2,%xmm4
   226e2:	f2 0f 10 84 24 30 01 	movsd  0x130(%rsp),%xmm0
   226e9:	00 00 
   226eb:	66 0f 28 d4          	movapd %xmm4,%xmm2
   226ef:	f2 0f 5d d0          	minsd  %xmm0,%xmm2
   226f3:	66 0f 28 c2          	movapd %xmm2,%xmm0
   226f7:	f2 0f c2 c2 03       	cmpunordsd %xmm2,%xmm0
   226fc:	66 0f 54 e0          	andpd  %xmm0,%xmm4
   22700:	66 0f 55 c2          	andnpd %xmm2,%xmm0
   22704:	66 0f 56 c4          	orpd   %xmm4,%xmm0
   22708:	66 0f 2e c1          	ucomisd %xmm1,%xmm0
   2270c:	0f 87 2c fe ff ff    	ja     2253e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   22712:	66 0f 10 8c 24 48 01 	movupd 0x148(%rsp),%xmm1
   22719:	00 00 
   2271b:	66 0f 28 9c 24 a0 01 	movapd 0x1a0(%rsp),%xmm3
   22722:	00 00 
   22724:	66 0f 28 d3          	movapd %xmm3,%xmm2
   22728:	66 0f 5d d1          	minpd  %xmm1,%xmm2
   2272c:	66 0f 28 ca          	movapd %xmm2,%xmm1
   22730:	66 0f c2 ca 03       	cmpunordpd %xmm2,%xmm1
   22735:	66 0f 54 d9          	andpd  %xmm1,%xmm3
   22739:	66 0f 55 ca          	andnpd %xmm2,%xmm1
   2273d:	66 0f 56 cb          	orpd   %xmm3,%xmm1
   22741:	66 0f 28 d0          	movapd %xmm0,%xmm2
   22745:	66 0f 14 d0          	unpcklpd %xmm0,%xmm2
   22749:	66 0f c2 ca 01       	cmpltpd %xmm2,%xmm1
   2274e:	66 0f 50 c1          	movmskpd %xmm1,%eax
   22752:	a8 01                	test   $0x1,%al
   22754:	0f 85 e4 fd ff ff    	jne    2253e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   2275a:	d0 e8                	shr    $1,%al
   2275c:	0f 85 dc fd ff ff    	jne    2253e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   22762:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   22768:	66 48 0f 7e c0       	movq   %xmm0,%rax
   2276d:	48 85 c0             	test   %rax,%rax
   22770:	0f 98 c1             	sets   %cl
   22773:	49 21 c7             	and    %rax,%r15
   22776:	48 b8 00 00 00 00 00 	movabs $0xfff0000000000000,%rax
   2277d:	00 f0 ff 
   22780:	4c 01 f8             	add    %r15,%rax
   22783:	48 c1 e8 35          	shr    $0x35,%rax
   22787:	3d ff 03 00 00       	cmp    $0x3ff,%eax
   2278c:	0f 92 c0             	setb   %al
   2278f:	20 c8                	and    %cl,%al
   22791:	49 8d 57 ff          	lea    -0x1(%r15),%rdx
   22795:	48 be ff ff ff ff ff 	movabs $0xfffffffffffff,%rsi
   2279c:	ff 0f 00 
   2279f:	48 39 f2             	cmp    %rsi,%rdx
   227a2:	0f 92 c2             	setb   %dl
   227a5:	20 ca                	and    %cl,%dl
   227a7:	48 b9 00 00 00 00 00 	movabs $0x7ff0000000000000,%rcx
   227ae:	00 f0 7f 
   227b1:	49 39 cf             	cmp    %rcx,%r15
   227b4:	0f 9f c1             	setg   %cl
   227b7:	40 0f 94 c6          	sete   %sil
   227bb:	40 08 ce             	or     %cl,%sil
   227be:	40 08 d6             	or     %dl,%sil
   227c1:	40 08 c6             	or     %al,%sil
   227c4:	0f 85 74 fd ff ff    	jne    2253e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   227ca:	0f 57 c9             	xorps  %xmm1,%xmm1
   227cd:	f2 0f 5a c8          	cvtsd2ss %xmm0,%xmm1
   227d1:	0f 57 d2             	xorps  %xmm2,%xmm2
   227d4:	f3 0f 5a d1          	cvtss2sd %xmm1,%xmm2
   227d8:	66 0f 2e d0          	ucomisd %xmm0,%xmm2
   227dc:	0f 97 c0             	seta   %al
   227df:	66 41 0f 7e cc       	movd   %xmm1,%r12d
   227e4:	41 81 fc 00 00 80 ff 	cmp    $0xff800000,%r12d
   227eb:	0f 95 c1             	setne  %cl
   227ee:	84 c8                	test   %cl,%al
   227f0:	74 20                	je     22812 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd02>
   227f2:	66 0f 7e c8          	movd   %xmm1,%eax
   227f6:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   227fb:	74 0a                	je     22807 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcf7>
   227fd:	41 39 c4             	cmp    %eax,%r12d
   22800:	75 0d                	jne    2280f <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xcff>
   22802:	41 ff cc             	dec    %r12d
   22805:	eb 0b                	jmp    22812 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd02>
   22807:	41 bc 01 00 00 80    	mov    $0x80000001,%r12d
   2280d:	eb 03                	jmp    22812 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd02>
   2280f:	41 ff c4             	inc    %r12d
   22812:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   22817:	0f 56 05 c2 2f fe ff 	orps   -0x1d03e(%rip),%xmm0        # 57e0 <std::thread::current::id::ID+0x4b68>
   2281e:	0f 29 44 24 40       	movaps %xmm0,0x40(%rsp)
   22823:	41 bd 40 00 00 00    	mov    $0x40,%r13d
   22829:	0f b6 db             	movzbl %bl,%ebx
   2282c:	4c 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%r15
   22833:	00 
   22834:	eb 24                	jmp    2285a <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd4a>
   22836:	41 bc 01 00 00 80    	mov    $0x80000001,%r12d
   2283c:	0f 1f 40 00          	nopl   0x0(%rax)
   22840:	66 41 0f 6e c4       	movd   %r12d,%xmm0
   22845:	0f 57 c9             	xorps  %xmm1,%xmm1
   22848:	f3 0f 5f c1          	maxss  %xmm1,%xmm0
   2284c:	66 41 0f 7e c4       	movd   %xmm0,%r12d
   22851:	41 ff cd             	dec    %r13d
   22854:	0f 84 e4 fc ff ff    	je     2253e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   2285a:	f3 0f 10 44 24 0c    	movss  0xc(%rsp),%xmm0
   22860:	f3 0f 11 84 24 a0 00 	movss  %xmm0,0xa0(%rsp)
   22867:	00 00 
   22869:	44 89 a4 24 a4 00 00 	mov    %r12d,0xa4(%rsp)
   22870:	00 
   22871:	0f 28 44 24 40       	movaps 0x40(%rsp),%xmm0
   22876:	f3 0f 11 84 24 a8 00 	movss  %xmm0,0xa8(%rsp)
   2287d:	00 00 
   2287f:	c7 84 24 ac 00 00 00 	movl   $0xff800000,0xac(%rsp)
   22886:	00 00 80 ff 
   2288a:	4c 89 ff             	mov    %r15,%rdi
   2288d:	89 de                	mov    %ebx,%esi
   2288f:	e8 4c 00 00 00       	call   228e0 <gpui_canvas::color::gamut::in_gamut>
   22894:	84 c0                	test   %al,%al
   22896:	75 2e                	jne    228c6 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xdb6>
   22898:	41 81 fc 00 00 80 ff 	cmp    $0xff800000,%r12d
   2289f:	74 9f                	je     22840 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd30>
   228a1:	66 41 0f 6e c4       	movd   %r12d,%xmm0
   228a6:	0f 2e c0             	ucomiss %xmm0,%xmm0
   228a9:	7a 95                	jp     22840 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd30>
   228ab:	41 f7 c4 ff ff ff 7f 	test   $0x7fffffff,%r12d
   228b2:	74 82                	je     22836 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd26>
   228b4:	45 85 e4             	test   %r12d,%r12d
   228b7:	78 05                	js     228be <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xdae>
   228b9:	41 ff cc             	dec    %r12d
   228bc:	eb 82                	jmp    22840 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd30>
   228be:	41 ff c4             	inc    %r12d
   228c1:	e9 7a ff ff ff       	jmp    22840 <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xd30>
   228c6:	49 c1 e4 20          	shl    $0x20,%r12
   228ca:	41 be ff ff ff ff    	mov    $0xffffffff,%r14d
   228d0:	4d 09 e6             	or     %r12,%r14
   228d3:	e9 66 fc ff ff       	jmp    2253e <gpui_canvas::color::gamut::limit::<fearless_simd::generated::fallback::Fallback>+0xa2e>
   228d8:	cc                   	int3
   228d9:	cc                   	int3
   228da:	cc                   	int3
   228db:	cc                   	int3
   228dc:	cc                   	int3
   228dd:	cc                   	int3
   228de:	cc                   	int3
   228df:	cc                   	int3

00000000000228e0 <gpui_canvas::color::gamut::in_gamut>:
   228e0:	55                   	push   %rbp
   228e1:	53                   	push   %rbx
   228e2:	48 83 ec 68          	sub    $0x68,%rsp
   228e6:	89 f3                	mov    %esi,%ebx
   228e8:	f3 0f 7e 0f          	movq   (%rdi),%xmm1
   228ec:	8b 4f 08             	mov    0x8(%rdi),%ecx
   228ef:	8b 57 0c             	mov    0xc(%rdi),%edx
   228f2:	89 c8                	mov    %ecx,%eax
   228f4:	81 fa 00 00 00 c0    	cmp    $0xc0000000,%edx
   228fa:	0f 82 ea 00 00 00    	jb     229ea <gpui_canvas::color::gamut::in_gamut+0x10a>
   22900:	89 c8                	mov    %ecx,%eax
   22902:	85 c9                	test   %ecx,%ecx
   22904:	0f 88 db 00 00 00    	js     229e5 <gpui_canvas::color::gamut::in_gamut+0x105>
   2290a:	c1 e8 08             	shr    $0x8,%eax
   2290d:	89 ce                	mov    %ecx,%esi
   2290f:	48 69 f6 8f e7 54 52 	imul   $0x5254e78f,%rsi,%rsi
   22916:	48 c1 ee 2e          	shr    $0x2e,%rsi
   2291a:	48 69 f8 09 a8 a7 01 	imul   $0x1a7a809,%rax,%rdi
   22921:	48 c1 ef 20          	shr    $0x20,%rdi
   22925:	66 41 0f 7e c9       	movd   %xmm1,%r9d
   2292a:	45 89 ca             	mov    %r9d,%r10d
   2292d:	41 c1 e2 08          	shl    $0x8,%r10d
   22931:	66 0f 70 c1 55       	pshufd $0x55,%xmm1,%xmm0
   22936:	66 41 0f 7e c0       	movd   %xmm0,%r8d
   2293b:	45 89 c3             	mov    %r8d,%r11d
   2293e:	45 0f a4 cb 08       	shld   $0x8,%r9d,%r11d
   22943:	69 ee 55 52 00 00    	imul   $0x5255,%esi,%ebp
   22949:	c1 ed 16             	shr    $0x16,%ebp
   2294c:	69 ed c7 00 00 00    	imul   $0xc7,%ebp,%ebp
   22952:	29 ee                	sub    %ebp,%esi
   22954:	44 89 dd             	mov    %r11d,%ebp
   22957:	c1 e5 08             	shl    $0x8,%ebp
   2295a:	41 81 e3 ff ff 7f 00 	and    $0x7fffff,%r11d
   22961:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
   22968:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
   2296e:	44 09 dd             	or     %r11d,%ebp
   22971:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   22978:	45 09 d1             	or     %r10d,%r9d
   2297b:	c1 e6 17             	shl    $0x17,%esi
   2297e:	09 ee                	or     %ebp,%esi
   22980:	c1 e7 0f             	shl    $0xf,%edi
   22983:	81 e7 00 00 80 ff    	and    $0xff800000,%edi
   22989:	41 0f ac c8 10       	shrd   $0x10,%ecx,%r8d
   2298e:	44 09 cf             	or     %r9d,%edi
   22991:	4c 69 c8 9f 53 49 01 	imul   $0x149539f,%rax,%r9
   22998:	49 c1 e9 20          	shr    $0x20,%r9
   2299c:	45 69 c9 c7 00 00 00 	imul   $0xc7,%r9d,%r9d
   229a3:	44 29 c8             	sub    %r9d,%eax
   229a6:	45 89 c1             	mov    %r8d,%r9d
   229a9:	41 81 e1 ff ff 7f 00 	and    $0x7fffff,%r9d
   229b0:	41 c1 e0 08          	shl    $0x8,%r8d
   229b4:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
   229bb:	45 09 c8             	or     %r9d,%r8d
   229be:	c1 e0 17             	shl    $0x17,%eax
   229c1:	44 09 c0             	or     %r8d,%eax
   229c4:	66 0f 6e c6          	movd   %esi,%xmm0
   229c8:	66 0f 6e cf          	movd   %edi,%xmm1
   229cc:	66 0f 62 c8          	punpckldq %xmm0,%xmm1
   229d0:	c1 ea 1e             	shr    $0x1e,%edx
   229d3:	31 ed                	xor    %ebp,%ebp
   229d5:	48 8d 35 18 4c fe ff 	lea    -0x1b3e8(%rip),%rsi        # 75f4 <std::thread::current::id::ID+0x697c>
   229dc:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   229e0:	48 01 f2             	add    %rsi,%rdx
   229e3:	ff e2                	jmp    *%rdx
   229e5:	25 ff ff ff 7f       	and    $0x7fffffff,%eax
   229ea:	c1 ea 1e             	shr    $0x1e,%edx
   229ed:	31 ed                	xor    %ebp,%ebp
   229ef:	48 8d 35 fe 4b fe ff 	lea    -0x1b402(%rip),%rsi        # 75f4 <std::thread::current::id::ID+0x697c>
   229f6:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   229fa:	48 01 f2             	add    %rsi,%rdx
   229fd:	ff e2                	jmp    *%rdx
   229ff:	40 b5 01             	mov    $0x1,%bpl
   22a02:	f3 0f 5a e9          	cvtss2sd %xmm1,%xmm5
   22a06:	66 0f 70 f1 55       	pshufd $0x55,%xmm1,%xmm6
   22a0b:	f3 0f 5a e6          	cvtss2sd %xmm6,%xmm4
   22a0f:	66 0f 6e d0          	movd   %eax,%xmm2
   22a13:	0f 28 05 06 28 fe ff 	movaps -0x1d7fa(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22a1a:	0f 54 c5             	andps  %xmm5,%xmm0
   22a1d:	f2 0f 10 1d 0b 48 fe 	movsd  -0x1b7f5(%rip),%xmm3        # 7230 <std::thread::current::id::ID+0x65b8>
   22a24:	ff 
   22a25:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22a29:	66 0f 7e 54 24 30    	movd   %xmm2,0x30(%rsp)
   22a2f:	73 53                	jae    22a84 <gpui_canvas::color::gamut::in_gamut+0x1a4>
   22a31:	0f 2e c9             	ucomiss %xmm1,%xmm1
   22a34:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22a39:	0f 29 74 24 50       	movaps %xmm6,0x50(%rsp)
   22a3e:	7a 4e                	jp     22a8e <gpui_canvas::color::gamut::in_gamut+0x1ae>
   22a40:	0f 54 2d 49 2d fe ff 	andps  -0x1d2b7(%rip),%xmm5        # 5790 <std::thread::current::id::ID+0x4b18>
   22a47:	0f 56 2d 52 2c fe ff 	orps   -0x1d3ae(%rip),%xmm5        # 56a0 <std::thread::current::id::ID+0x4a28>
   22a4e:	0f 29 2c 24          	movaps %xmm5,(%rsp)
   22a52:	eb 46                	jmp    22a9a <gpui_canvas::color::gamut::in_gamut+0x1ba>
   22a54:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   22a57:	66 0f 6e c0          	movd   %eax,%xmm0
   22a5b:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22a5f:	e9 ad 01 00 00       	jmp    22c11 <gpui_canvas::color::gamut::in_gamut+0x331>
   22a64:	85 c9                	test   %ecx,%ecx
   22a66:	0f 88 86 02 00 00    	js     22cf2 <gpui_canvas::color::gamut::in_gamut+0x412>
   22a6c:	0f 5a e9             	cvtps2pd %xmm1,%xmm5
   22a6f:	66 0f 6e c0          	movd   %eax,%xmm0
   22a73:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22a77:	84 db                	test   %bl,%bl
   22a79:	0f 84 5e 02 00 00    	je     22cdd <gpui_canvas::color::gamut::in_gamut+0x3fd>
   22a7f:	e9 a7 02 00 00       	jmp    22d2b <gpui_canvas::color::gamut::in_gamut+0x44b>
   22a84:	f2 0f 5e 2d 04 47 fe 	divsd  -0x1b8fc(%rip),%xmm5        # 7190 <std::thread::current::id::ID+0x6518>
   22a8b:	ff 
   22a8c:	eb 4b                	jmp    22ad9 <gpui_canvas::color::gamut::in_gamut+0x1f9>
   22a8e:	f2 0f 10 0d 62 48 fe 	movsd  -0x1b79e(%rip),%xmm1        # 72f8 <std::thread::current::id::ID+0x6680>
   22a95:	ff 
   22a96:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   22a9a:	f2 0f 58 05 1e 49 fe 	addsd  -0x1b6e2(%rip),%xmm0        # 73c0 <std::thread::current::id::ID+0x6748>
   22aa1:	ff 
   22aa2:	f2 0f 5e 05 6e 48 fe 	divsd  -0x1b792(%rip),%xmm0        # 7318 <std::thread::current::id::ID+0x66a0>
   22aa9:	ff 
   22aaa:	f2 0f 10 0d fe 47 fe 	movsd  -0x1b802(%rip),%xmm1        # 72b0 <std::thread::current::id::ID+0x6638>
   22ab1:	ff 
   22ab2:	ff 15 d0 2d 04 00    	call   *0x42dd0(%rip)        # 65888 <pow@GLIBC_2.29>
   22ab8:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22abc:	f2 0f 59 2c 24       	mulsd  (%rsp),%xmm5
   22ac1:	66 0f 6e 54 24 30    	movd   0x30(%rsp),%xmm2
   22ac7:	f2 0f 10 1d 61 47 fe 	movsd  -0x1b89f(%rip),%xmm3        # 7230 <std::thread::current::id::ID+0x65b8>
   22ace:	ff 
   22acf:	0f 28 64 24 10       	movaps 0x10(%rsp),%xmm4
   22ad4:	0f 28 74 24 50       	movaps 0x50(%rsp),%xmm6
   22ad9:	0f 57 c9             	xorps  %xmm1,%xmm1
   22adc:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22ae0:	0f 28 05 39 27 fe ff 	movaps -0x1d8c7(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22ae7:	0f 54 c4             	andps  %xmm4,%xmm0
   22aea:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22aee:	66 0f 29 2c 24       	movapd %xmm5,(%rsp)
   22af3:	73 1f                	jae    22b14 <gpui_canvas::color::gamut::in_gamut+0x234>
   22af5:	0f 2e f6             	ucomiss %xmm6,%xmm6
   22af8:	0f 29 4c 24 20       	movaps %xmm1,0x20(%rsp)
   22afd:	7a 4b                	jp     22b4a <gpui_canvas::color::gamut::in_gamut+0x26a>
   22aff:	0f 54 25 8a 2c fe ff 	andps  -0x1d376(%rip),%xmm4        # 5790 <std::thread::current::id::ID+0x4b18>
   22b06:	0f 56 25 93 2b fe ff 	orps   -0x1d46d(%rip),%xmm4        # 56a0 <std::thread::current::id::ID+0x4a28>
   22b0d:	0f 29 64 24 10       	movaps %xmm4,0x10(%rsp)
   22b12:	eb 43                	jmp    22b57 <gpui_canvas::color::gamut::in_gamut+0x277>
   22b14:	f2 0f 5e 25 74 46 fe 	divsd  -0x1b98c(%rip),%xmm4        # 7190 <std::thread::current::id::ID+0x6518>
   22b1b:	ff 
   22b1c:	0f 28 05 fd 26 fe ff 	movaps -0x1d903(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22b23:	0f 54 c1             	andps  %xmm1,%xmm0
   22b26:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22b2a:	72 7e                	jb     22baa <gpui_canvas::color::gamut::in_gamut+0x2ca>
   22b2c:	f2 0f 5e 0d 5c 46 fe 	divsd  -0x1b9a4(%rip),%xmm1        # 7190 <std::thread::current::id::ID+0x6518>
   22b33:	ff 
   22b34:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22b38:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22b3c:	40 84 ed             	test   %bpl,%bpl
   22b3f:	0f 85 cc 00 00 00    	jne    22c11 <gpui_canvas::color::gamut::in_gamut+0x331>
   22b45:	e9 8f 01 00 00       	jmp    22cd9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22b4a:	f2 0f 10 0d a6 47 fe 	movsd  -0x1b85a(%rip),%xmm1        # 72f8 <std::thread::current::id::ID+0x6680>
   22b51:	ff 
   22b52:	0f 29 4c 24 10       	movaps %xmm1,0x10(%rsp)
   22b57:	f2 0f 58 05 61 48 fe 	addsd  -0x1b79f(%rip),%xmm0        # 73c0 <std::thread::current::id::ID+0x6748>
   22b5e:	ff 
   22b5f:	f2 0f 5e 05 b1 47 fe 	divsd  -0x1b84f(%rip),%xmm0        # 7318 <std::thread::current::id::ID+0x66a0>
   22b66:	ff 
   22b67:	f2 0f 10 0d 41 47 fe 	movsd  -0x1b8bf(%rip),%xmm1        # 72b0 <std::thread::current::id::ID+0x6638>
   22b6e:	ff 
   22b6f:	ff 15 13 2d 04 00    	call   *0x42d13(%rip)        # 65888 <pow@GLIBC_2.29>
   22b75:	66 0f 28 e0          	movapd %xmm0,%xmm4
   22b79:	f2 0f 59 64 24 10    	mulsd  0x10(%rsp),%xmm4
   22b7f:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   22b84:	f3 0f 10 54 24 30    	movss  0x30(%rsp),%xmm2
   22b8a:	f2 0f 10 1d 9e 46 fe 	movsd  -0x1b962(%rip),%xmm3        # 7230 <std::thread::current::id::ID+0x65b8>
   22b91:	ff 
   22b92:	66 0f 28 4c 24 20    	movapd 0x20(%rsp),%xmm1
   22b98:	66 0f 28 05 80 26 fe 	movapd -0x1d980(%rip),%xmm0        # 5220 <std::thread::current::id::ID+0x45a8>
   22b9f:	ff 
   22ba0:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   22ba4:	66 0f 2e d8          	ucomisd %xmm0,%xmm3
   22ba8:	73 82                	jae    22b2c <gpui_canvas::color::gamut::in_gamut+0x24c>
   22baa:	0f 2e d2             	ucomiss %xmm2,%xmm2
   22bad:	66 0f 29 64 24 10    	movapd %xmm4,0x10(%rsp)
   22bb3:	7a 12                	jp     22bc7 <gpui_canvas::color::gamut::in_gamut+0x2e7>
   22bb5:	66 0f 54 0d d3 2b fe 	andpd  -0x1d42d(%rip),%xmm1        # 5790 <std::thread::current::id::ID+0x4b18>
   22bbc:	ff 
   22bbd:	66 0f 56 0d db 2a fe 	orpd   -0x1d525(%rip),%xmm1        # 56a0 <std::thread::current::id::ID+0x4a28>
   22bc4:	ff 
   22bc5:	eb 08                	jmp    22bcf <gpui_canvas::color::gamut::in_gamut+0x2ef>
   22bc7:	f2 0f 10 0d 29 47 fe 	movsd  -0x1b8d7(%rip),%xmm1        # 72f8 <std::thread::current::id::ID+0x6680>
   22bce:	ff 
   22bcf:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   22bd5:	f2 0f 58 05 e3 47 fe 	addsd  -0x1b81d(%rip),%xmm0        # 73c0 <std::thread::current::id::ID+0x6748>
   22bdc:	ff 
   22bdd:	f2 0f 5e 05 33 47 fe 	divsd  -0x1b8cd(%rip),%xmm0        # 7318 <std::thread::current::id::ID+0x66a0>
   22be4:	ff 
   22be5:	f2 0f 10 0d c3 46 fe 	movsd  -0x1b93d(%rip),%xmm1        # 72b0 <std::thread::current::id::ID+0x6638>
   22bec:	ff 
   22bed:	ff 15 95 2c 04 00    	call   *0x42c95(%rip)        # 65888 <pow@GLIBC_2.29>
   22bf3:	f2 0f 59 44 24 20    	mulsd  0x20(%rsp),%xmm0
   22bf9:	66 0f 28 2c 24       	movapd (%rsp),%xmm5
   22bfe:	66 0f 28 64 24 10    	movapd 0x10(%rsp),%xmm4
   22c04:	66 0f 14 ec          	unpcklpd %xmm4,%xmm5
   22c08:	40 84 ed             	test   %bpl,%bpl
   22c0b:	0f 84 c8 00 00 00    	je     22cd9 <gpui_canvas::color::gamut::in_gamut+0x3f9>
   22c11:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22c15:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22c1a:	66 0f 59 15 9e 2a fe 	mulpd  -0x1d562(%rip),%xmm2        # 56c0 <std::thread::current::id::ID+0x4a48>
   22c21:	ff 
   22c22:	66 0f 57 db          	xorpd  %xmm3,%xmm3
   22c26:	66 0f 16 1d 6a 47 fe 	movhpd -0x1b896(%rip),%xmm3        # 7398 <std::thread::current::id::ID+0x6720>
   22c2d:	ff 
   22c2e:	66 0f 59 dd          	mulpd  %xmm5,%xmm3
   22c32:	0f 28 c8             	movaps %xmm0,%xmm1
   22c35:	0f 16 c8             	movlhps %xmm0,%xmm1
   22c38:	66 0f 59 0d 00 26 fe 	mulpd  -0x1da00(%rip),%xmm1        # 5240 <std::thread::current::id::ID+0x45c8>
   22c3f:	ff 
   22c40:	66 0f 58 da          	addpd  %xmm2,%xmm3
   22c44:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22c48:	f2 0f 10 15 98 45 fe 	movsd  -0x1ba68(%rip),%xmm2        # 71e8 <std::thread::current::id::ID+0x6570>
   22c4f:	ff 
   22c50:	f2 0f 59 d5          	mulsd  %xmm5,%xmm2
   22c54:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22c58:	66 0f 59 2d 00 26 fe 	mulpd  -0x1da00(%rip),%xmm5        # 5260 <std::thread::current::id::ID+0x45e8>
   22c5f:	ff 
   22c60:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22c64:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22c68:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22c6c:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22c70:	f2 0f 10 15 30 45 fe 	movsd  -0x1bad0(%rip),%xmm2        # 71a8 <std::thread::current::id::ID+0x6530>
   22c77:	ff 
   22c78:	66 0f 28 d9          	movapd %xmm1,%xmm3
   22c7c:	f2 0f 10 d8          	movsd  %xmm0,%xmm3
   22c80:	66 0f 59 1d f8 28 fe 	mulpd  -0x1d708(%rip),%xmm3        # 5580 <std::thread::current::id::ID+0x4908>
   22c87:	ff 
   22c88:	66 0f 28 e1          	movapd %xmm1,%xmm4
   22c8c:	66 0f c6 e0 01       	shufpd $0x1,%xmm0,%xmm4
   22c91:	66 0f 59 25 17 28 fe 	mulpd  -0x1d7e9(%rip),%xmm4        # 54b0 <std::thread::current::id::ID+0x4838>
   22c98:	ff 
   22c99:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22c9d:	66 0f 58 e3          	addpd  %xmm3,%xmm4
   22ca1:	66 0f 28 e9          	movapd %xmm1,%xmm5
   22ca5:	66 0f 14 e9          	unpcklpd %xmm1,%xmm5
   22ca9:	66 0f 59 2d ef 2a fe 	mulpd  -0x1d511(%rip),%xmm5        # 57a0 <std::thread::current::id::ID+0x4b28>
   22cb0:	ff 
   22cb1:	66 0f 28 c4          	movapd %xmm4,%xmm0
   22cb5:	66 0f 5c c5          	subpd  %xmm5,%xmm0
   22cb9:	66 0f 58 ec          	addpd  %xmm4,%xmm5
   22cbd:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22cc1:	66 0f 59 0d 97 28 fe 	mulpd  -0x1d769(%rip),%xmm1        # 5560 <std::thread::current::id::ID+0x48e8>
   22cc8:	ff 
   22cc9:	66 0f 28 c1          	movapd %xmm1,%xmm0
   22ccd:	66 0f 15 c1          	unpckhpd %xmm1,%xmm0
   22cd1:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22cd5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22cd9:	84 db                	test   %bl,%bl
   22cdb:	75 4e                	jne    22d2b <gpui_canvas::color::gamut::in_gamut+0x44b>
   22cdd:	31 c0                	xor    %eax,%eax
   22cdf:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22ce3:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22ce7:	0f 83 08 01 00 00    	jae    22df5 <gpui_canvas::color::gamut::in_gamut+0x515>
   22ced:	e9 41 01 00 00       	jmp    22e33 <gpui_canvas::color::gamut::in_gamut+0x553>
   22cf2:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   22cf6:	0f c6 c9 55          	shufps $0x55,%xmm1,%xmm1
   22cfa:	66 0f ef c0          	pxor   %xmm0,%xmm0
   22cfe:	0f 2e c8             	ucomiss %xmm0,%xmm1
   22d01:	0f 85 35 01 00 00    	jne    22e3c <gpui_canvas::color::gamut::in_gamut+0x55c>
   22d07:	0f 8a 2f 01 00 00    	jp     22e3c <gpui_canvas::color::gamut::in_gamut+0x55c>
   22d0d:	0f 57 c9             	xorps  %xmm1,%xmm1
   22d10:	f3 0f 5a ca          	cvtss2sd %xmm2,%xmm1
   22d14:	0f 28 c1             	movaps %xmm1,%xmm0
   22d17:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22d1b:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22d1f:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22d23:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22d27:	84 db                	test   %bl,%bl
   22d29:	74 b2                	je     22cdd <gpui_canvas::color::gamut::in_gamut+0x3fd>
   22d2b:	66 0f 28 0d 9d 25 fe 	movapd -0x1da63(%rip),%xmm1        # 52d0 <std::thread::current::id::ID+0x4658>
   22d32:	ff 
   22d33:	66 0f 59 cd          	mulpd  %xmm5,%xmm1
   22d37:	66 0f 28 d5          	movapd %xmm5,%xmm2
   22d3b:	66 0f c6 d5 01       	shufpd $0x1,%xmm5,%xmm2
   22d40:	66 0f 59 15 d8 29 fe 	mulpd  -0x1d628(%rip),%xmm2        # 5720 <std::thread::current::id::ID+0x4aa8>
   22d47:	ff 
   22d48:	66 0f 58 d1          	addpd  %xmm1,%xmm2
   22d4c:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22d50:	66 0f 14 c8          	unpcklpd %xmm0,%xmm1
   22d54:	66 0f 59 0d 44 26 fe 	mulpd  -0x1d9bc(%rip),%xmm1        # 53a0 <std::thread::current::id::ID+0x4728>
   22d5b:	ff 
   22d5c:	f2 0f 10 1d dc 44 fe 	movsd  -0x1bb24(%rip),%xmm3        # 7240 <std::thread::current::id::ID+0x65c8>
   22d63:	ff 
   22d64:	f2 0f 59 dd          	mulsd  %xmm5,%xmm3
   22d68:	f2 0f 10 e8          	movsd  %xmm0,%xmm5
   22d6c:	66 0f 59 2d 4c 26 fe 	mulpd  -0x1d9b4(%rip),%xmm5        # 53c0 <std::thread::current::id::ID+0x4748>
   22d73:	ff 
   22d74:	66 0f 58 ca          	addpd  %xmm2,%xmm1
   22d78:	66 0f 28 c5          	movapd %xmm5,%xmm0
   22d7c:	66 0f 15 c5          	unpckhpd %xmm5,%xmm0
   22d80:	f2 0f 58 c3          	addsd  %xmm3,%xmm0
   22d84:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22d88:	66 0f c6 d1 01       	shufpd $0x1,%xmm1,%xmm2
   22d8d:	66 0f 59 15 bb 24 fe 	mulpd  -0x1db45(%rip),%xmm2        # 5250 <std::thread::current::id::ID+0x45d8>
   22d94:	ff 
   22d95:	f2 0f 58 c5          	addsd  %xmm5,%xmm0
   22d99:	66 0f 28 1d 0f 25 fe 	movapd -0x1daf1(%rip),%xmm3        # 52b0 <std::thread::current::id::ID+0x4638>
   22da0:	ff 
   22da1:	66 0f 59 d9          	mulpd  %xmm1,%xmm3
   22da5:	66 0f 5c da          	subpd  %xmm2,%xmm3
   22da9:	66 0f 28 e8          	movapd %xmm0,%xmm5
   22dad:	66 0f 14 e8          	unpcklpd %xmm0,%xmm5
   22db1:	66 0f 59 2d b7 25 fe 	mulpd  -0x1da49(%rip),%xmm5        # 5370 <std::thread::current::id::ID+0x46f8>
   22db8:	ff 
   22db9:	66 0f 28 d3          	movapd %xmm3,%xmm2
   22dbd:	66 0f 5c d5          	subpd  %xmm5,%xmm2
   22dc1:	66 0f 58 eb          	addpd  %xmm3,%xmm5
   22dc5:	f2 0f 10 ea          	movsd  %xmm2,%xmm5
   22dc9:	66 0f 59 0d 3f 28 fe 	mulpd  -0x1d7c1(%rip),%xmm1        # 5610 <std::thread::current::id::ID+0x4998>
   22dd0:	ff 
   22dd1:	66 0f 28 d1          	movapd %xmm1,%xmm2
   22dd5:	66 0f 15 d1          	unpckhpd %xmm1,%xmm2
   22dd9:	f2 0f 5c ca          	subsd  %xmm2,%xmm1
   22ddd:	f2 0f 59 05 0b 45 fe 	mulsd  -0x1baf5(%rip),%xmm0        # 72f0 <std::thread::current::id::ID+0x6678>
   22de4:	ff 
   22de5:	f2 0f 58 c1          	addsd  %xmm1,%xmm0
   22de9:	31 c0                	xor    %eax,%eax
   22deb:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22def:	66 0f 2e e9          	ucomisd %xmm1,%xmm5
   22df3:	72 3e                	jb     22e33 <gpui_canvas::color::gamut::in_gamut+0x553>
   22df5:	f2 0f 10 0d 5b 44 fe 	movsd  -0x1bba5(%rip),%xmm1        # 7258 <std::thread::current::id::ID+0x65e0>
   22dfc:	ff 
   22dfd:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22e01:	72 30                	jb     22e33 <gpui_canvas::color::gamut::in_gamut+0x553>
   22e03:	66 0f 15 ed          	unpckhpd %xmm5,%xmm5
   22e07:	31 c0                	xor    %eax,%eax
   22e09:	66 0f 57 d2          	xorpd  %xmm2,%xmm2
   22e0d:	66 0f 2e ea          	ucomisd %xmm2,%xmm5
   22e11:	72 20                	jb     22e33 <gpui_canvas::color::gamut::in_gamut+0x553>
   22e13:	66 0f 2e cd          	ucomisd %xmm5,%xmm1
   22e17:	72 1a                	jb     22e33 <gpui_canvas::color::gamut::in_gamut+0x553>
   22e19:	66 0f 57 c9          	xorpd  %xmm1,%xmm1
   22e1d:	f2 0f c2 c8 02       	cmplesd %xmm0,%xmm1
   22e22:	f2 0f c2 05 2d 44 fe 	cmplesd -0x1bbd3(%rip),%xmm0        # 7258 <std::thread::current::id::ID+0x65e0>
   22e29:	ff 02 
   22e2b:	66 0f 54 c1          	andpd  %xmm1,%xmm0
   22e2f:	66 0f 7e c0          	movd   %xmm0,%eax
   22e33:	24 01                	and    $0x1,%al
   22e35:	48 83 c4 68          	add    $0x68,%rsp
   22e39:	5b                   	pop    %rbx
   22e3a:	5d                   	pop    %rbp
   22e3b:	c3                   	ret
   22e3c:	66 0f 6e c0          	movd   %eax,%xmm0
   22e40:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22e44:	f2 0f 59 05 44 45 fe 	mulsd  -0x1babc(%rip),%xmm0        # 7390 <std::thread::current::id::ID+0x6718>
   22e4b:	ff 
   22e4c:	48 8d 7c 24 48       	lea    0x48(%rsp),%rdi
   22e51:	48 8d 74 24 40       	lea    0x40(%rsp),%rsi
   22e56:	0f 29 0c 24          	movaps %xmm1,(%rsp)
   22e5a:	66 0f 7f 54 24 30    	movdqa %xmm2,0x30(%rsp)
   22e60:	ff 15 52 2a 04 00    	call   *0x42a52(%rip)        # 658b8 <sincos@GLIBC_2.2.5>
   22e66:	0f 28 44 24 30       	movaps 0x30(%rsp),%xmm0
   22e6b:	0f 57 c9             	xorps  %xmm1,%xmm1
   22e6e:	f3 0f 5a c8          	cvtss2sd %xmm0,%xmm1
   22e72:	0f 28 04 24          	movaps (%rsp),%xmm0
   22e76:	f3 0f 5a c0          	cvtss2sd %xmm0,%xmm0
   22e7a:	f2 0f 10 54 24 40    	movsd  0x40(%rsp),%xmm2
   22e80:	f2 0f 59 d0          	mulsd  %xmm0,%xmm2
   22e84:	f2 0f 59 44 24 48    	mulsd  0x48(%rsp),%xmm0
   22e8a:	f2 0f 10 1d d6 44 fe 	movsd  -0x1bb2a(%rip),%xmm3        # 7368 <std::thread::current::id::ID+0x66f0>
   22e91:	ff 
   22e92:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22e96:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   22e9a:	f2 0f 10 2d 5e 44 fe 	movsd  -0x1bba2(%rip),%xmm5        # 7300 <std::thread::current::id::ID+0x6688>
   22ea1:	ff 
   22ea2:	f2 0f 59 e8          	mulsd  %xmm0,%xmm5
   22ea6:	f2 0f 58 eb          	addsd  %xmm3,%xmm5
   22eaa:	f2 0f 10 1d 0e 44 fe 	movsd  -0x1bbf2(%rip),%xmm3        # 72c0 <std::thread::current::id::ID+0x6648>
   22eb1:	ff 
   22eb2:	f2 0f 59 da          	mulsd  %xmm2,%xmm3
   22eb6:	f2 0f 58 d9          	addsd  %xmm1,%xmm3
   22eba:	f2 0f 10 35 06 45 fe 	movsd  -0x1bafa(%rip),%xmm6        # 73c8 <std::thread::current::id::ID+0x6750>
   22ec1:	ff 
   22ec2:	f2 0f 59 f0          	mulsd  %xmm0,%xmm6
   22ec6:	f2 0f 58 f3          	addsd  %xmm3,%xmm6
   22eca:	f2 0f 59 15 7e 44 fe 	mulsd  -0x1bb82(%rip),%xmm2        # 7350 <std::thread::current::id::ID+0x66d8>
   22ed1:	ff 
   22ed2:	f2 0f 58 d1          	addsd  %xmm1,%xmm2
   22ed6:	f2 0f 59 05 ba 42 fe 	mulsd  -0x1bd46(%rip),%xmm0        # 7198 <std::thread::current::id::ID+0x6520>
   22edd:	ff 
   22ede:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22ee2:	66 0f 28 e5          	movapd %xmm5,%xmm4
   22ee6:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   22eea:	f2 0f 59 e5          	mulsd  %xmm5,%xmm4
   22eee:	66 0f 28 de          	movapd %xmm6,%xmm3
   22ef2:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22ef6:	f2 0f 59 de          	mulsd  %xmm6,%xmm3
   22efa:	66 0f 28 c8          	movapd %xmm0,%xmm1
   22efe:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22f02:	f2 0f 59 c8          	mulsd  %xmm0,%xmm1
   22f06:	f2 0f 10 05 c2 44 fe 	movsd  -0x1bb3e(%rip),%xmm0        # 73d0 <std::thread::current::id::ID+0x6758>
   22f0d:	ff 
   22f0e:	f2 0f 59 c4          	mulsd  %xmm4,%xmm0
   22f12:	f2 0f 10 15 56 43 fe 	movsd  -0x1bcaa(%rip),%xmm2        # 7270 <std::thread::current::id::ID+0x65f8>
   22f19:	ff 
   22f1a:	f2 0f 59 d3          	mulsd  %xmm3,%xmm2
   22f1e:	f2 0f 58 d0          	addsd  %xmm0,%xmm2
   22f22:	f2 0f 10 05 4e 43 fe 	movsd  -0x1bcb2(%rip),%xmm0        # 7278 <std::thread::current::id::ID+0x6600>
   22f29:	ff 
   22f2a:	f2 0f 59 c1          	mulsd  %xmm1,%xmm0
   22f2e:	f2 0f 58 c2          	addsd  %xmm2,%xmm0
   22f32:	f2 0f 10 15 6e 42 fe 	movsd  -0x1bd92(%rip),%xmm2        # 71a8 <std::thread::current::id::ID+0x6530>
   22f39:	ff 
   22f3a:	66 0f 14 e4          	unpcklpd %xmm4,%xmm4
   22f3e:	66 0f 59 25 1a 28 fe 	mulpd  -0x1d7e6(%rip),%xmm4        # 5760 <std::thread::current::id::ID+0x4ae8>
   22f45:	ff 
   22f46:	66 0f 14 db          	unpcklpd %xmm3,%xmm3
   22f4a:	66 0f 59 1d 1e 28 fe 	mulpd  -0x1d7e2(%rip),%xmm3        # 5770 <std::thread::current::id::ID+0x4af8>
   22f51:	ff 
   22f52:	66 0f 58 dc          	addpd  %xmm4,%xmm3
   22f56:	66 0f 14 c9          	unpcklpd %xmm1,%xmm1
   22f5a:	66 0f 59 0d ee 25 fe 	mulpd  -0x1da12(%rip),%xmm1        # 5550 <std::thread::current::id::ID+0x48d8>
   22f61:	ff 
   22f62:	66 0f 58 cb          	addpd  %xmm3,%xmm1
   22f66:	e9 0d fd ff ff       	jmp    22c78 <gpui_canvas::color::gamut::in_gamut+0x398>
