from pathlib import Path
p=Path('/root/gpui-gamut-lattice/reactivity/crates/canvas/src/color/gamut.rs');s=p.read_text().replace('use fearless_simd::{Simd, f64x4, prelude::*};','use fearless_simd::{Simd, f32x4, f64x4, mask32x4, mask64x4, u32x4, prelude::*};')
a=s.index('// Allowed is polynomial');s=s[:a]+'''#[inline(always)]
fn widen<S: Simd>(value: f32x4<S>) -> f64x4<S> {
    let (low, high) = value.widen();
    low.combine(high)
}
#[inline(always)]
fn narrow<S: Simd>(value: f64x4<S>) -> f32x4<S> {
    let (low, high) = value.split();
    low.narrow(high)
}
#[inline(always)]
fn narrow_mask<S: Simd>(mask: mask64x4<S>) -> mask32x4<S> {
    let (low, high) = mask.to_vector().split();
    mask32x4::from_vector(low.narrow(high))
}

// Earlier intervals must be certified no-exit: flooring start can precede this
// interval. High is exclusive, not an assumed outside sample. Strict midpoints
// remain below end even when ceil(end) crosses a local extremum or reentry.
// Infinity's bits are a sentinel only, retaining f32MAX as a searchable value.
#[inline(always)]
fn lattice_exit<S: Simd>(
    p: Polynomial<S>,
    start: f64x4<S>,
    end: f64x4<S>,
    lightness: f64,
    active: mask64x4<S>,
) -> (f64x4<S>, usize) {
    let simd = start.token();
    let zero = u32x4::splat(simd, 0);
    let one = u32x4::splat(simd, 1);
    let start = (start * lightness).min(f32::MAX as f64);
    let end = end * lightness;
    let low_float = narrow(start);
    let high_float = narrow(end);
    let mut low = low_float.bitcast::<u32x4<S>>()
        - narrow_mask(widen(low_float).simd_gt(start)).select(one, zero);
    let mut high = high_float.bitcast::<u32x4<S>>()
        + narrow_mask(widen(high_float).simd_lt(end)).select(one, zero);
    let active = narrow_mask(active);
    let mut evaluations = 0;
    loop {
        let searching = active & (high - low).simd_gt(1);
        if searching.to_bitmask() & 7 == 0 {
            break;
        }
        let middle = low + ((high - low) >> 1);
        let chroma = widen(middle.bitcast::<f32x4<S>>());
        let outside = narrow_mask(p.evaluate(chroma / lightness).simd_gt(0.0));
        high = (searching & outside).select(middle, high);
        low = (searching & !outside).select(middle, low);
        evaluations += 1;
    }
    (widen(low.bitcast::<f32x4<S>>()), evaluations)
}

'''+s[a:]
s=s.replace('''    iterations: usize,''','''    lightness: f64,''')
a=s.index('''            let mut low = start;''');b=s.index('''        }
        start = end;''',a)
s=s[:a]+'''            let (chroma, _) = lattice_exit(p, start, end, lightness, active);
            result = active.select(chroma, result);
'''+s[b:]
s=s.replace('''    let [lower, lower_unresolved] = first_exit(simd, p.lower(), turns, bound, 96);''','''    let l = lightness as f64;
    let [lower, lower_unresolved] = first_exit(simd, p.lower(), turns, bound, l);''')
s=s.replace('''    let l = lightness as f64;
    let [upper, upper_unresolved]''','''    let [upper, upper_unresolved]''')
s=s.replace('''        f64x4::splat(simd, lower),
        64,''','''        f64x4::splat(simd, lower / l),
        l,''')
s=s.replace('''if unresolved[..3].iter().any(|&t| t < cap)''','''if unresolved[..3].iter().any(|&t| t < cap / l)''')
s=s.replace('''    let limit = cap * l;''','''    let limit = cap;''')
s=s.replace('''// No whole-gamut monotonicity is assumed. All RGB lanes share the same solve.''','''// Results are exact f32 chroma widened to f64; uncertainty stays in t=C/L.
// No whole-gamut monotonicity is assumed. All RGB lanes share the same solve.''')
p.write_text(s)
p=Path('/root/gpui-gamut-lattice/reactivity/crates/canvas/src/color/gamut/tests.rs');s=p.read_text().replace('''        96,
''','''        1.0,
''').replace('''f64x4::splat(s, 4.0), 96''','''f64x4::splat(s, 4.0), 1.0''');p.write_text(s)
