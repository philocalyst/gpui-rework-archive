from pathlib import Path
p=Path('/root/gpui-gamut-adaptive/reactivity/crates/canvas/src/color/gamut.rs');s=p.read_text().replace('use fearless_simd::{Simd, f64x4, prelude::*};','use fearless_simd::{Simd, f64x4, mask64x4, u32x4, prelude::*};')
a=s.index('// Allowed is polynomial');s=s[:a]+'''// Positive f32 bits are used only to recognize convergence. Samples remain
// f64 t values; clamping here describes the finite representable chroma domain.
#[inline(always)]
fn chroma_floor<S: Simd>(value: f64x4<S>, lightness: f64) -> u32x4<S> {
    let value = (value * lightness).min(f32::MAX as f64);
    let (low, high) = value.split();
    let rounded = low.narrow(high);
    let (low, high) = rounded.widen();
    let down = low.combine(high).simd_gt(value).to_vector();
    let (low, high) = down.split();
    // Canonical true masks are -1, so adding their narrowed bits steps inward.
    rounded.bitcast::<u32x4<S>>() + low.narrow(high).bitcast::<u32x4<S>>()
}

'''+s[a:]
s=s.replace('''    iterations: usize,''','''    lightness: f64,''')
s=s.replace('''            for _ in 0..iterations {
                let middle = low + (high - low) * 0.5;
                let outside = p.evaluate(middle).simd_gt(0.0);
                high = (active & outside).select(middle, high);
                low = (active & !outside).select(middle, low);
            }''','''            loop {
                let middle = low + (high - low) * 0.5;
                let same = chroma_floor(low, lightness)
                    .simd_eq(chroma_floor(high, lightness)).to_bitmask();
                let refining = active & !mask64x4::from_bitmask(simd, same)
                    & middle.simd_gt(low) & middle.simd_lt(high);
                if refining.to_bitmask() & 7 == 0 {
                    break;
                }
                let outside = p.evaluate(middle).simd_gt(0.0);
                high = (refining & outside).select(middle, high);
                low = (refining & !outside).select(middle, low);
            }''')
s=s.replace('''    let [lower, lower_unresolved] = first_exit(simd, p.lower(), turns, bound, 96);''','''    let l = lightness as f64;
    let [lower, lower_unresolved] = first_exit(simd, p.lower(), turns, bound, l);''')
s=s.replace('''    let l = lightness as f64;
    let [upper, upper_unresolved]''','''    let [upper, upper_unresolved]''').replace('''        64,
''','''        l,
''')
s=s.replace('''    let mut chroma = limit as f32;''','''    let mut chroma = limit as f32;
    if chroma as f64 > limit {
        chroma = chroma.next_down();
    }''')
p.write_text(s)
p=Path('/root/gpui-gamut-adaptive/reactivity/crates/canvas/src/color/gamut/tests.rs');s=p.read_text().replace('''        96,
''','''        1.0,
''').replace('''f64x4::splat(s, 4.0), 96''','''f64x4::splat(s, 4.0), 1.0''');p.write_text(s)
