from fractions import Fraction as Q
from pathlib import Path
import struct,json,hashlib
FMAX=Q.from_float(struct.unpack('<f',struct.pack('<I',0x7f7fffff))[0]);MIN=Q(1,2**149);ULP=Q(1,2**23)
def bits(v):return struct.unpack('<I',struct.pack('<f',float(v)))[0]
def value(b):return Q.from_float(struct.unpack('<f',struct.pack('<I',b))[0])
def floorbits(v):
 if v>=FMAX:return 0x7f7fffff
 b=bits(v);return b-1 if value(b)>v else b
def ceilbits(v):
 if v>FMAX:return 0x7f800000
 b=bits(v);return b+1 if value(b)<v else b
def evaluate(p,t):
 v=Q(0)
 for x in p:v=v*t+x
 return v
cases=[('linear',[Q(0),Q(0),Q(1),Q(-1)],Q(1),Q(0),Q(3,2),Q(1)),('sub-ulp excursion',[Q(0),Q(-1),2+ULP,-(1+ULP/4)*(1+3*ULP/4)],Q(1),Q(0),1+ULP/2,Q(1)),('floor start',[Q(0),Q(0),Q(1),-(1+2*ULP)],Q(1),1+ULP/4,1+3*ULP,1+2*ULP),('subnormal L',[Q(0),Q(0),Q(1),Q(-1,4)],MIN,Q(0),Q(1,2),Q(0)),('finite sentinel',[Q(0),Q(0),Q(1),-(FMAX/2)/MIN],MIN,Q(0),FMAX*2/MIN,FMAX/2),('cubic finite sentinel',[Q(1),Q(0),Q(0),-((FMAX/2)/MIN)**3],MIN,Q(0),FMAX*2/MIN,FMAX/2),('zero boundary',[Q(0),Q(0),Q(1),Q(0)],Q(1),Q(0),Q(1,2),Q(0))]
rows=[]
for name,p,L,start,end,expected in cases:
 assert evaluate(p,end)>0
 lo=floorbits(start*L);hi=ceilbits(end*L);count=0
 while hi-lo>1:
  mid=lo+(hi-lo)//2;assert mid<0x7f800000;assert value(mid)/L<end
  if evaluate(p,value(mid)/L)>0:hi=mid
  else:lo=mid
  count+=1
 assert lo==bits(expected),(name,hex(lo),hex(bits(expected)))
 rows.append(dict(name=name,p=[str(v) for v in p],L=str(L),start=str(start),end=str(end),expected_bits=lo,evaluations=count,exclusive_high_bits=ceilbits(end*L)))
Path('/tmp/gpui-gamut-lattice-controls/model.json').write_text(json.dumps(dict(label='Exact-rational search geometry controls frozen before lattice source edits; not production polynomial admission',rows=rows),indent=2)+'\n');print([(r['name'],r['evaluations']) for r in rows])
Path('/tmp/gpui-gamut-lattice-controls/model-pins.json').write_text(json.dumps({f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in Path('/tmp/gpui-gamut-lattice-controls').iterdir() if f.is_file() and f.name!='model-pins.json'},indent=2)+'\n')
