use gamut_count::OutputProfile;
fn row(kind: &str, index: usize, profile: OutputProfile, l: f32, h: f32) {
    let cap = profile.max_chroma(std::hint::black_box(l), std::hint::black_box(h)).unwrap();
    let evaluations=gamut_count::take_count();
    println!("{kind},{index},{profile:?},{},{},{},{}",l.to_bits(),h.to_bits(),cap.to_bits(),evaluations);
}
fn main() {
    println!("kind,index,profile,L_bits,h_bits,cap_bits,evaluations");
    for (i,line) in include_str!("/root/gpui-designer-gamut/reactivity/crates/canvas/tests/fixtures/gamut_limits.csv").lines().skip(1).enumerate() {
        let mut fields=line.split(',');let profile=if fields.next().unwrap()=="srgb" {OutputProfile::Srgb} else {OutputProfile::DisplayP3};
        let l=f32::from_bits(fields.next().unwrap().parse().unwrap());let h=f32::from_bits(fields.next().unwrap().parse().unwrap());
        row("oracle",i,profile,l,h);
    }
    let mut seed=0x91e1_0da5_u32;
    for i in 0..10000 {
        seed=seed.wrapping_mul(1664525).wrapping_add(1013904223);let l=f32::from_bits(seed%0x3f800000);
        seed=seed.wrapping_mul(1664525).wrapping_add(1013904223);let h=(seed as f64*(360.0/4294967296.0)) as f32;let h=if h>=360.0 {0.0} else {h};
        for profile in [OutputProfile::Srgb,OutputProfile::DisplayP3] {row("sweep",i,profile,l,h);}
    }
}
