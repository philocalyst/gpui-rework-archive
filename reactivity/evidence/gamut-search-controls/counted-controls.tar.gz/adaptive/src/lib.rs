#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Error {
    InvalidDimensions,
    InvalidGeometry,
    InvalidPaintSlot,
    InvalidFont,
    UnsupportedFontFormat,
    InvalidFontSize,
    InvalidWidth,
    ResourceLimit,
    UnsupportedDirection,
    UnsupportedScript(char),
    UnsupportedControl(char),
    MissingGlyph(char),
    ForeignLayout,
    InvalidColor,
    ColorOutOfRange,
    UnsupportedPixelFormat,
    UnsupportedOutputProfile,
    NonOpaqueOutput,
    InvalidImageLength,
    InvalidImageAlpha,
}
mod color;
pub use color::*;
mod canvas {
pub(crate) trait PixelWriter: Copy + Send + Sync {
    type Element: Copy + Default + Send + Sync;
    const ELEMENTS: usize;
    fn write(self, color: [f32; 4], destination: &mut [Self::Element]);
}
}
pub fn take_count()->usize { color::gamut::EVALUATIONS.with(|n|n.replace(0)) }
