#!/usr/bin/env bash
set -euo pipefail
source /tmp/gpui-native-env.sh
source /tmp/gpui-nightly-env.sh
cd /tmp/gpui-text-navigation-sol
native_binary=$(/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3 - <<'PY'
import re
s=open('/tmp/gpui-text-navigation-native-suite.log').read()
print(re.search(r'Running unittests [^\n]+ \(([^)]+)\)',s)[1])
PY
)
git diff --exit-code
sha256sum "$native_binary" > /tmp/gpui-text-navigation-native-elf-before.sha256
git diff 64162234a00b1a0ecb32535e020566f1b59568e8 HEAD --binary | sha256sum > /tmp/gpui-text-navigation-native-source-before.sha256
native_display_file=$(mktemp /tmp/gpui-text-navigation-display.XXXXXX)
/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb -displayfd 3 -screen 0 1024x768x24 -nolisten tcp -ac 3>"$native_display_file" > /tmp/gpui-text-navigation-xvfb.log 2>&1 &
native_xvfb_pid=$!
finish_native() {
    native_status=$?
    sha256sum "$native_binary" > /tmp/gpui-text-navigation-native-elf-after.sha256
    git diff 64162234a00b1a0ecb32535e020566f1b59568e8 HEAD --binary | sha256sum > /tmp/gpui-text-navigation-native-source-after.sha256
    cmp /tmp/gpui-text-navigation-native-elf-before.sha256 /tmp/gpui-text-navigation-native-elf-after.sha256 || native_status=1
    cmp /tmp/gpui-text-navigation-native-source-before.sha256 /tmp/gpui-text-navigation-native-source-after.sha256 || native_status=1
    git diff --exit-code || native_status=1
    kill "$native_xvfb_pid" 2>/dev/null || true
    wait "$native_xvfb_pid" 2>/dev/null || true
    rm -f "$native_display_file"
    exit "$native_status"
}
trap finish_native EXIT
for attempt in $(seq 1 100); do
    [[ -s "$native_display_file" ]] && break
    kill -0 "$native_xvfb_pid"
    sleep 0.05
done
[[ -s "$native_display_file" ]]
export DISPLAY=":"$(cat "$native_display_file")
/nix/store/8snmq54bp5d5vp5dihgn7xr53hayx629-dbus-1.16.2/bin/dbus-run-session -- "$native_binary" native::unicode_tests::native_unicode_keyboard_and_surface_match_complete_cpu_pixels --ignored --exact --nocapture > /tmp/gpui-text-navigation-real-native.log 2>&1
sha256sum "$native_binary" > /tmp/gpui-text-navigation-native-elf-after.sha256
git diff --exit-code
git diff 64162234a00b1a0ecb32535e020566f1b59568e8 HEAD --binary | sha256sum > /tmp/gpui-text-navigation-native-source-after.sha256
cmp /tmp/gpui-text-navigation-native-elf-before.sha256 /tmp/gpui-text-navigation-native-elf-after.sha256
cmp /tmp/gpui-text-navigation-native-source-before.sha256 /tmp/gpui-text-navigation-native-source-after.sha256
