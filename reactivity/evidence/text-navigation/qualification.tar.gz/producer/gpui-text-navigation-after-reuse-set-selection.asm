
/tmp/gpui-text-navigation-after-reuse-debug.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000091dfa0 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection>:
  91dfa0:	48 81 ec a8 01 00 00 	sub    $0x1a8,%rsp
  91dfa7:	48 89 7c 24 78       	mov    %rdi,0x78(%rsp)
  91dfac:	48 89 b4 24 80 00 00 	mov    %rsi,0x80(%rsp)
  91dfb3:	00 
  91dfb4:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
  91dfb9:	89 4c 24 70          	mov    %ecx,0x70(%rsp)
  91dfbd:	f3 0f 11 44 24 74    	movss  %xmm0,0x74(%rsp)
  91dfc3:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
  91dfca:	00 
  91dfcb:	48 89 b4 24 10 01 00 	mov    %rsi,0x110(%rsp)
  91dfd2:	00 
  91dfd3:	89 8c 24 18 01 00 00 	mov    %ecx,0x118(%rsp)
  91dfda:	f3 0f 11 84 24 1c 01 	movss  %xmm0,0x11c(%rsp)
  91dfe1:	00 00 
  91dfe3:	c6 84 24 07 01 00 00 	movb   $0x0,0x107(%rsp)
  91dfea:	00 
  91dfeb:	48 81 c7 d8 02 00 00 	add    $0x2d8,%rdi
  91dff2:	48 8d 15 0f b7 a6 00 	lea    0xa6b70f(%rip),%rdx        # 1389708 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x50d8>
  91dff9:	e8 62 46 fb ff       	call   8d2660 <<alloc::vec::Vec<gpui::runtime::Node> as core::ops::index::Index<usize>>::index>
  91dffe:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e003:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  91e00a:	00 
  91e00b:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  91e012:	00 
  91e013:	48 89 84 24 20 01 00 	mov    %rax,0x120(%rsp)
  91e01a:	00 
  91e01b:	e8 60 f7 ff ff       	call   91d780 <<gpui::runtime::Runtime<text_selection::Page>>::editing_at>
  91e020:	48 89 84 24 98 00 00 	mov    %rax,0x98(%rsp)
  91e027:	00 
  91e028:	48 8d bc 24 98 00 00 	lea    0x98(%rsp),%rdi
  91e02f:	00 
  91e030:	e8 4b 14 09 00       	call   9af480 <<core::option::Option<&gpui::runtime::editing::LogicalSelection>>::is_some>
  91e035:	a8 01                	test   $0x1,%al
  91e037:	0f 85 93 01 00 00    	jne    91e1d0 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x230>
  91e03d:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  91e044:	00 
  91e045:	e8 06 f1 09 00       	call   9bd150 <<gpui::runtime::Node>::text_slot>
  91e04a:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e04f:	89 44 24 64          	mov    %eax,0x64(%rsp)
  91e053:	48 81 c7 f0 02 00 00 	add    $0x2f0,%rdi
  91e05a:	e8 d1 33 fb ff       	call   8d1430 <<alloc::vec::Vec<core::option::Option<gpui::runtime::TextSite>> as core::ops::deref::Deref>::deref>
  91e05f:	8b 7c 24 64          	mov    0x64(%rsp),%edi
  91e063:	48 89 c6             	mov    %rax,%rsi
  91e066:	e8 a5 ed 09 00       	call   9bce10 <<gpui::runtime::TextSlot>::get>
  91e06b:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
  91e072:	00 
  91e073:	48 8b 94 24 98 01 00 	mov    0x198(%rsp),%rdx
  91e07a:	00 
  91e07b:	b8 01 00 00 00       	mov    $0x1,%eax
  91e080:	31 c9                	xor    %ecx,%ecx
  91e082:	48 83 fa 00          	cmp    $0x0,%rdx
  91e086:	48 0f 44 c1          	cmove  %rcx,%rax
  91e08a:	48 a9 01 00 00 00    	test   $0x1,%rax
  91e090:	75 0d                	jne    91e09f <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0xff>
  91e092:	48 8d 3d 87 b6 a6 00 	lea    0xa6b687(%rip),%rdi        # 1389720 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x50f0>
  91e099:	ff 15 f9 40 ac 00    	call   *0xac40f9(%rip)        # 13e2198 <_DYNAMIC+0x370>
  91e09f:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  91e0a6:	00 
  91e0a7:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
  91e0ae:	00 
  91e0af:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  91e0b4:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
  91e0bb:	00 
  91e0bc:	48 89 84 24 28 01 00 	mov    %rax,0x128(%rsp)
  91e0c3:	00 
  91e0c4:	e8 77 f0 09 00       	call   9bd140 <<gpui::runtime::Node>::identity>
  91e0c9:	48 89 c1             	mov    %rax,%rcx
  91e0cc:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  91e0d1:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  91e0d6:	48 8b 40 40          	mov    0x40(%rax),%rax
  91e0da:	48 89 84 24 58 01 00 	mov    %rax,0x158(%rsp)
  91e0e1:	00 
  91e0e2:	b8 01 00 00 00       	mov    $0x1,%eax
  91e0e7:	31 c9                	xor    %ecx,%ecx
  91e0e9:	48 83 bc 24 58 01 00 	cmpq   $0x0,0x158(%rsp)
  91e0f0:	00 00 
  91e0f2:	48 0f 44 c1          	cmove  %rcx,%rax
  91e0f6:	48 a9 01 00 00 00    	test   $0x1,%rax
  91e0fc:	75 0d                	jne    91e10b <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x16b>
  91e0fe:	48 8d 3d 33 b6 a6 00 	lea    0xa6b633(%rip),%rdi        # 1389738 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5108>
  91e105:	ff 15 8d 40 ac 00    	call   *0xac408d(%rip)        # 13e2198 <_DYNAMIC+0x370>
  91e10b:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  91e110:	48 8b 84 24 58 01 00 	mov    0x158(%rsp),%rax
  91e117:	00 
  91e118:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  91e11d:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
  91e124:	00 
  91e125:	48 83 c7 38          	add    $0x38,%rdi
  91e129:	e8 12 fc fd ff       	call   8fdd40 <<gpui::shared_text::SharedText as core::clone::Clone>::clone>
  91e12e:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
  91e133:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  91e138:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
  91e13d:	f3 0f 10 44 24 74    	movss  0x74(%rsp),%xmm0
  91e143:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e148:	48 89 c2             	mov    %rax,%rdx
  91e14b:	8b 44 24 70          	mov    0x70(%rsp),%eax
  91e14f:	4c 89 84 24 c8 00 00 	mov    %r8,0xc8(%rsp)
  91e156:	00 
  91e157:	48 89 b4 24 b8 00 00 	mov    %rsi,0xb8(%rsp)
  91e15e:	00 
  91e15f:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
  91e166:	00 
  91e167:	0f 10 09             	movups (%rcx),%xmm1
  91e16a:	0f 11 8c 24 a8 00 00 	movups %xmm1,0xa8(%rsp)
  91e171:	00 
  91e172:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
  91e179:	f3 0f 11 84 24 a4 00 	movss  %xmm0,0xa4(%rsp)
  91e180:	00 00 
  91e182:	c6 84 24 07 01 00 00 	movb   $0x1,0x107(%rsp)
  91e189:	01 
  91e18a:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
  91e191:	00 
  91e192:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
  91e199:	00 
  91e19a:	0f 10 94 24 c0 00 00 	movups 0xc0(%rsp),%xmm2
  91e1a1:	00 
  91e1a2:	0f 29 94 24 f0 00 00 	movaps %xmm2,0xf0(%rsp)
  91e1a9:	00 
  91e1aa:	0f 29 8c 24 e0 00 00 	movaps %xmm1,0xe0(%rsp)
  91e1b1:	00 
  91e1b2:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
  91e1b9:	00 
  91e1ba:	48 81 c7 58 06 00 00 	add    $0x658,%rdi
  91e1c1:	e8 ea 24 08 00       	call   9a06b0 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<gpui::runtime::Runtime<text_selection::Page>>::set_selection::{closure#0}>>
  91e1c6:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  91e1cb:	e9 99 00 00 00       	jmp    91e269 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x2c9>
  91e1d0:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e1d5:	48 81 c7 58 06 00 00 	add    $0x658,%rdi
  91e1dc:	e8 5f 00 09 00       	call   9ae240 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::as_mut>
  91e1e1:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
  91e1e8:	00 
  91e1e9:	48 8b 94 24 78 01 00 	mov    0x178(%rsp),%rdx
  91e1f0:	00 
  91e1f1:	b8 01 00 00 00       	mov    $0x1,%eax
  91e1f6:	31 c9                	xor    %ecx,%ecx
  91e1f8:	48 83 fa 00          	cmp    $0x0,%rdx
  91e1fc:	48 0f 44 c1          	cmove  %rcx,%rax
  91e200:	48 a9 01 00 00 00    	test   $0x1,%rax
  91e206:	75 0d                	jne    91e215 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x275>
  91e208:	48 8d 3d 59 b5 a6 00 	lea    0xa6b559(%rip),%rdi        # 1389768 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5138>
  91e20f:	ff 15 83 3f ac 00    	call   *0xac3f83(%rip)        # 13e2198 <_DYNAMIC+0x370>
  91e215:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
  91e21c:	00 
  91e21d:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  91e224:	00 
  91e225:	48 8b 00             	mov    (%rax),%rax
  91e228:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  91e22d:	48 83 e0 07          	and    $0x7,%rax
  91e231:	48 83 f8 00          	cmp    $0x0,%rax
  91e235:	0f 84 03 02 00 00    	je     91e43e <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x49e>
  91e23b:	e9 17 02 00 00       	jmp    91e457 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x4b7>
  91e240:	f6 84 24 07 01 00 00 	testb  $0x1,0x107(%rsp)
  91e247:	01 
  91e248:	0f 85 d7 01 00 00    	jne    91e425 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x485>
  91e24e:	e9 c5 01 00 00       	jmp    91e418 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x478>
  91e253:	48 89 c1             	mov    %rax,%rcx
  91e256:	89 d0                	mov    %edx,%eax
  91e258:	48 89 8c 24 30 01 00 	mov    %rcx,0x130(%rsp)
  91e25f:	00 
  91e260:	89 84 24 38 01 00 00 	mov    %eax,0x138(%rsp)
  91e267:	eb d7                	jmp    91e240 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x2a0>
  91e269:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
  91e26e:	48 8b 00             	mov    (%rax),%rax
  91e271:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  91e276:	48 83 e0 07          	and    $0x7,%rax
  91e27a:	48 83 f8 00          	cmp    $0x0,%rax
  91e27e:	75 16                	jne    91e296 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x2f6>
  91e280:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  91e285:	48 83 f8 00          	cmp    $0x0,%rax
  91e289:	0f 94 c0             	sete   %al
  91e28c:	24 ff                	and    $0xff,%al
  91e28e:	34 ff                	xor    $0xff,%al
  91e290:	a8 01                	test   $0x1,%al
  91e292:	75 19                	jne    91e2ad <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x30d>
  91e294:	eb 2f                	jmp    91e2c5 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x325>
  91e296:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  91e29b:	bf 08 00 00 00       	mov    $0x8,%edi
  91e2a0:	48 8d 15 a9 b4 a6 00 	lea    0xa6b4a9(%rip),%rdx        # 1389750 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5120>
  91e2a7:	ff 15 33 3e ac 00    	call   *0xac3e33(%rip)        # 13e20e0 <_DYNAMIC+0x2b8>
  91e2ad:	48 8b 7c 24 30       	mov    0x30(%rsp),%rdi
  91e2b2:	48 81 c7 e0 00 00 00 	add    $0xe0,%rdi
  91e2b9:	e8 e2 22 08 00       	call   9a05a0 <<core::option::Option<alloc::boxed::Box<gpui::runtime::editing::Editing>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::editing::Editing> as core::default::Default>::default>>
  91e2be:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  91e2c3:	eb 0d                	jmp    91e2d2 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x332>
  91e2c5:	48 8d 3d 84 b4 a6 00 	lea    0xa6b484(%rip),%rdi        # 1389750 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5120>
  91e2cc:	ff 15 1e 3e ac 00    	call   *0xac3e1e(%rip)        # 13e20f0 <_DYNAMIC+0x2c8>
  91e2d2:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  91e2d7:	48 8b 38             	mov    (%rax),%rdi
  91e2da:	48 8b 05 1f 4b ac 00 	mov    0xac4b1f(%rip),%rax        # 13e2e00 <_DYNAMIC+0xfd8>
  91e2e1:	ff d0                	call   *%rax
  91e2e3:	eb 3e                	jmp    91e323 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x383>
  91e2e5:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  91e2ea:	48 8b 00             	mov    (%rax),%rax
  91e2ed:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  91e2f2:	c6 84 24 07 01 00 00 	movb   $0x0,0x107(%rsp)
  91e2f9:	00 
  91e2fa:	48 83 e0 07          	and    $0x7,%rax
  91e2fe:	48 83 f8 00          	cmp    $0x0,%rax
  91e302:	0f 84 ba 00 00 00    	je     91e3c2 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x422>
  91e308:	e9 cb 00 00 00       	jmp    91e3d8 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x438>
  91e30d:	48 89 c1             	mov    %rax,%rcx
  91e310:	89 d0                	mov    %edx,%eax
  91e312:	48 89 8c 24 30 01 00 	mov    %rcx,0x130(%rsp)
  91e319:	00 
  91e31a:	89 84 24 38 01 00 00 	mov    %eax,0x138(%rsp)
  91e321:	eb c2                	jmp    91e2e5 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x345>
  91e323:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  91e328:	48 8b 00             	mov    (%rax),%rax
  91e32b:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  91e330:	c6 84 24 07 01 00 00 	movb   $0x0,0x107(%rsp)
  91e337:	00 
  91e338:	48 83 e0 07          	and    $0x7,%rax
  91e33c:	48 83 f8 00          	cmp    $0x0,%rax
  91e340:	75 16                	jne    91e358 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x3b8>
  91e342:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  91e347:	48 83 f8 00          	cmp    $0x0,%rax
  91e34b:	0f 94 c0             	sete   %al
  91e34e:	24 ff                	and    $0xff,%al
  91e350:	34 ff                	xor    $0xff,%al
  91e352:	a8 01                	test   $0x1,%al
  91e354:	75 19                	jne    91e36f <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x3cf>
  91e356:	eb 4c                	jmp    91e3a4 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x404>
  91e358:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  91e35d:	bf 08 00 00 00       	mov    $0x8,%edi
  91e362:	48 8d 15 e7 b3 a6 00 	lea    0xa6b3e7(%rip),%rdx        # 1389750 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5120>
  91e369:	ff 15 71 3d ac 00    	call   *0xac3d71(%rip)        # 13e20e0 <_DYNAMIC+0x2b8>
  91e36f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  91e374:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
  91e37b:	00 
  91e37c:	ba 30 00 00 00       	mov    $0x30,%edx
  91e381:	e8 1a 42 a6 00       	call   13825a0 <memcpy@plt>
  91e386:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  91e38b:	c6 84 24 07 01 00 00 	movb   $0x0,0x107(%rsp)
  91e392:	00 
  91e393:	c6 80 63 07 00 00 01 	movb   $0x1,0x763(%rax)
  91e39a:	c6 84 24 97 00 00 00 	movb   $0x1,0x97(%rsp)
  91e3a1:	01 
  91e3a2:	eb 0d                	jmp    91e3b1 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x411>
  91e3a4:	48 8d 3d a5 b3 a6 00 	lea    0xa6b3a5(%rip),%rdi        # 1389750 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5120>
  91e3ab:	ff 15 47 42 ac 00    	call   *0xac4247(%rip)        # 13e25f8 <_DYNAMIC+0x7d0>
  91e3b1:	8a 84 24 97 00 00 00 	mov    0x97(%rsp),%al
  91e3b8:	24 01                	and    $0x1,%al
  91e3ba:	48 81 c4 a8 01 00 00 	add    $0x1a8,%rsp
  91e3c1:	c3                   	ret
  91e3c2:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  91e3c7:	48 83 f8 00          	cmp    $0x0,%rax
  91e3cb:	0f 94 c0             	sete   %al
  91e3ce:	24 ff                	and    $0xff,%al
  91e3d0:	34 ff                	xor    $0xff,%al
  91e3d2:	a8 01                	test   $0x1,%al
  91e3d4:	75 19                	jne    91e3ef <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x44f>
  91e3d6:	eb 33                	jmp    91e40b <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x46b>
  91e3d8:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  91e3dd:	bf 08 00 00 00       	mov    $0x8,%edi
  91e3e2:	48 8d 15 67 b3 a6 00 	lea    0xa6b367(%rip),%rdx        # 1389750 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5120>
  91e3e9:	ff 15 f1 3c ac 00    	call   *0xac3cf1(%rip)        # 13e20e0 <_DYNAMIC+0x2b8>
  91e3ef:	48 8b 7c 24 20       	mov    0x20(%rsp),%rdi
  91e3f4:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
  91e3fb:	00 
  91e3fc:	ba 30 00 00 00       	mov    $0x30,%edx
  91e401:	e8 9a 41 a6 00       	call   13825a0 <memcpy@plt>
  91e406:	e9 35 fe ff ff       	jmp    91e240 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x2a0>
  91e40b:	48 8d 3d 3e b3 a6 00 	lea    0xa6b33e(%rip),%rdi        # 1389750 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5120>
  91e412:	ff 15 e0 41 ac 00    	call   *0xac41e0(%rip)        # 13e25f8 <_DYNAMIC+0x7d0>
  91e418:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
  91e41f:	00 
  91e420:	e8 8b 41 a6 00       	call   13825b0 <_Unwind_Resume@plt>
  91e425:	48 8b 05 d4 49 ac 00 	mov    0xac49d4(%rip),%rax        # 13e2e00 <_DYNAMIC+0xfd8>
  91e42c:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  91e433:	00 
  91e434:	ff d0                	call   *%rax
  91e436:	eb e0                	jmp    91e418 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x478>
  91e438:	ff 15 92 3c ac 00    	call   *0xac3c92(%rip)        # 13e20d0 <_DYNAMIC+0x2a8>
  91e43e:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
  91e443:	48 83 f8 00          	cmp    $0x0,%rax
  91e447:	0f 94 c0             	sete   %al
  91e44a:	24 ff                	and    $0xff,%al
  91e44c:	34 ff                	xor    $0xff,%al
  91e44e:	a8 01                	test   $0x1,%al
  91e450:	75 1c                	jne    91e46e <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x4ce>
  91e452:	e9 88 00 00 00       	jmp    91e4df <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x53f>
  91e457:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  91e45c:	bf 08 00 00 00       	mov    $0x8,%edi
  91e461:	48 8d 15 18 b3 a6 00 	lea    0xa6b318(%rip),%rdx        # 1389780 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5150>
  91e468:	ff 15 72 3c ac 00    	call   *0xac3c72(%rip)        # 13e20e0 <_DYNAMIC+0x2b8>
  91e46e:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  91e473:	48 81 c7 e0 00 00 00 	add    $0xe0,%rdi
  91e47a:	e8 51 fc 08 00       	call   9ae0d0 <<core::option::Option<alloc::boxed::Box<gpui::runtime::editing::Editing>>>::as_mut>
  91e47f:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
  91e486:	00 
  91e487:	48 8b 94 24 68 01 00 	mov    0x168(%rsp),%rdx
  91e48e:	00 
  91e48f:	b8 01 00 00 00       	mov    $0x1,%eax
  91e494:	31 c9                	xor    %ecx,%ecx
  91e496:	48 83 fa 00          	cmp    $0x0,%rdx
  91e49a:	48 0f 44 c1          	cmove  %rcx,%rax
  91e49e:	48 a9 01 00 00 00    	test   $0x1,%rax
  91e4a4:	75 0d                	jne    91e4b3 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x513>
  91e4a6:	48 8d 3d eb b2 a6 00 	lea    0xa6b2eb(%rip),%rdi        # 1389798 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5168>
  91e4ad:	ff 15 e5 3c ac 00    	call   *0xac3ce5(%rip)        # 13e2198 <_DYNAMIC+0x370>
  91e4b3:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
  91e4ba:	00 
  91e4bb:	48 89 84 24 70 01 00 	mov    %rax,0x170(%rsp)
  91e4c2:	00 
  91e4c3:	48 89 84 24 40 01 00 	mov    %rax,0x140(%rsp)
  91e4ca:	00 
  91e4cb:	48 8b 00             	mov    (%rax),%rax
  91e4ce:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  91e4d3:	48 83 e0 07          	and    $0x7,%rax
  91e4d7:	48 83 f8 00          	cmp    $0x0,%rax
  91e4db:	74 0f                	je     91e4ec <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x54c>
  91e4dd:	eb 26                	jmp    91e505 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x565>
  91e4df:	48 8d 3d 9a b2 a6 00 	lea    0xa6b29a(%rip),%rdi        # 1389780 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5150>
  91e4e6:	ff 15 04 3c ac 00    	call   *0xac3c04(%rip)        # 13e20f0 <_DYNAMIC+0x2c8>
  91e4ec:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  91e4f1:	48 83 f8 00          	cmp    $0x0,%rax
  91e4f5:	0f 94 c0             	sete   %al
  91e4f8:	24 ff                	and    $0xff,%al
  91e4fa:	34 ff                	xor    $0xff,%al
  91e4fc:	a8 01                	test   $0x1,%al
  91e4fe:	75 1c                	jne    91e51c <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x57c>
  91e500:	e9 dd 00 00 00       	jmp    91e5e2 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x642>
  91e505:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  91e50a:	bf 08 00 00 00       	mov    $0x8,%edi
  91e50f:	48 8d 15 9a b2 a6 00 	lea    0xa6b29a(%rip),%rdx        # 13897b0 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5180>
  91e516:	ff 15 c4 3b ac 00    	call   *0xac3bc4(%rip)        # 13e20e0 <_DYNAMIC+0x2b8>
  91e51c:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  91e521:	e8 4a 0a 09 00       	call   9aef70 <<core::option::Option<gpui::runtime::editing::LogicalSelection>>::as_mut>
  91e526:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  91e52d:	00 
  91e52e:	48 8b 94 24 88 01 00 	mov    0x188(%rsp),%rdx
  91e535:	00 
  91e536:	b8 01 00 00 00       	mov    $0x1,%eax
  91e53b:	31 c9                	xor    %ecx,%ecx
  91e53d:	48 83 fa 00          	cmp    $0x0,%rdx
  91e541:	48 0f 44 c1          	cmove  %rcx,%rax
  91e545:	48 a9 01 00 00 00    	test   $0x1,%rax
  91e54b:	75 0d                	jne    91e55a <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x5ba>
  91e54d:	48 8d 3d 74 b2 a6 00 	lea    0xa6b274(%rip),%rdi        # 13897c8 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5198>
  91e554:	ff 15 3e 3c ac 00    	call   *0xac3c3e(%rip)        # 13e2198 <_DYNAMIC+0x370>
  91e55a:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
  91e55f:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
  91e566:	00 
  91e567:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  91e56c:	48 89 bc 24 90 01 00 	mov    %rdi,0x190(%rsp)
  91e573:	00 
  91e574:	48 89 bc 24 48 01 00 	mov    %rdi,0x148(%rsp)
  91e57b:	00 
  91e57c:	48 83 c7 08          	add    $0x8,%rdi
  91e580:	e8 8b 8b ed ff       	call   7f7110 <<gpui_canvas::text::layout::TextSelection as core::cmp::PartialEq>::ne>
  91e585:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
  91e58a:	8b 74 24 70          	mov    0x70(%rsp),%esi
  91e58e:	f3 0f 10 44 24 74    	movss  0x74(%rsp),%xmm0
  91e594:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  91e599:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  91e59e:	41 88 c0             	mov    %al,%r8b
  91e5a1:	41 80 e0 01          	and    $0x1,%r8b
  91e5a5:	44 88 84 24 57 01 00 	mov    %r8b,0x157(%rsp)
  91e5ac:	00 
  91e5ad:	4c 8b 07             	mov    (%rdi),%r8
  91e5b0:	4c 89 42 08          	mov    %r8,0x8(%rdx)
  91e5b4:	48 8b 7f 08          	mov    0x8(%rdi),%rdi
  91e5b8:	48 89 7a 10          	mov    %rdi,0x10(%rdx)
  91e5bc:	89 32                	mov    %esi,(%rdx)
  91e5be:	f3 0f 11 42 04       	movss  %xmm0,0x4(%rdx)
  91e5c3:	8a 91 63 07 00 00    	mov    0x763(%rcx),%dl
  91e5c9:	08 c2                	or     %al,%dl
  91e5cb:	80 e2 01             	and    $0x1,%dl
  91e5ce:	88 91 63 07 00 00    	mov    %dl,0x763(%rcx)
  91e5d4:	24 01                	and    $0x1,%al
  91e5d6:	88 84 24 97 00 00 00 	mov    %al,0x97(%rsp)
  91e5dd:	e9 cf fd ff ff       	jmp    91e3b1 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x411>
  91e5e2:	48 8d 3d c7 b1 a6 00 	lea    0xa6b1c7(%rip),%rdi        # 13897b0 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5180>
  91e5e9:	ff 15 01 3b ac 00    	call   *0xac3b01(%rip)        # 13e20f0 <_DYNAMIC+0x2c8>
