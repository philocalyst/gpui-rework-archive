import json,re,subprocess,sys
p=subprocess.Popen(['readelf','--debug-dump=info',sys.argv[1]],stdout=subprocess.PIPE,text=True)
stack=[];rows={}
die=re.compile(r'^ <(\d+)><[0-9a-f]+>: Abbrev Number: \d+ \((DW_TAG_\w+)\)')
for line in p.stdout:
 m=die.match(line)
 if m:
  depth=int(m[1]);stack=[x for x in stack if x['depth']<depth]
  stack.append({'depth':depth,'tag':m[2],'name':None})
  continue
 if not stack:continue
 if 'DW_AT_name' in line:
  value=line.split('DW_AT_name',1)[1].split(': ',1)[1].strip()
  if value.startswith('(indirect string,'):value=value.split('): ',1)[1]
  stack[-1]['name']=value
 elif 'DW_AT_byte_size' in line:
  current=stack[-1];name=current['name']
  if name in ['LogicalSelection','Editing','Metadata','Node','TextSite','TextLayout','TextGeometry','Key','Runtime<text_selection::Page>'] or name and ('Option<gpui::runtime::editing::LogicalSelection>' in name or 'Option<alloc::boxed::Box<gpui::runtime::editing::Editing>>' in name):
   path='::'.join(x['name'] for x in stack if x['name'] and (x is current or x['tag']=='DW_TAG_namespace'))
   if path.startswith(('gpui::','gpui_canvas::','core::option::')):
    size=int(line.split('DW_AT_byte_size',1)[1].split(':',1)[1].strip())
    rows.setdefault(path,set()).add(size)
assert p.wait()==0
print(json.dumps({'binary':sys.argv[1],'actual_dwarf_sizes':{k:sorted(v) for k,v in rows.items()}},indent=2))
