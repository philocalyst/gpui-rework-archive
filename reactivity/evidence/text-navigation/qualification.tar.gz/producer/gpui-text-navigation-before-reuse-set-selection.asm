
/tmp/gpui-text-navigation-before-reuse-debug.elf:     file format elf64-x86-64


Disassembly of section .text:

000000000091e570 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection>:
  91e570:	48 81 ec 28 02 00 00 	sub    $0x228,%rsp
  91e577:	48 89 7c 24 78       	mov    %rdi,0x78(%rsp)
  91e57c:	48 89 b4 24 80 00 00 	mov    %rsi,0x80(%rsp)
  91e583:	00 
  91e584:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
  91e58b:	00 
  91e58c:	89 4c 24 70          	mov    %ecx,0x70(%rsp)
  91e590:	f3 0f 11 44 24 74    	movss  %xmm0,0x74(%rsp)
  91e596:	48 89 bc 24 68 01 00 	mov    %rdi,0x168(%rsp)
  91e59d:	00 
  91e59e:	48 89 b4 24 70 01 00 	mov    %rsi,0x170(%rsp)
  91e5a5:	00 
  91e5a6:	89 8c 24 78 01 00 00 	mov    %ecx,0x178(%rsp)
  91e5ad:	f3 0f 11 84 24 7c 01 	movss  %xmm0,0x17c(%rsp)
  91e5b4:	00 00 
  91e5b6:	c6 84 24 67 01 00 00 	movb   $0x0,0x167(%rsp)
  91e5bd:	00 
  91e5be:	c6 84 24 66 01 00 00 	movb   $0x0,0x166(%rsp)
  91e5c5:	00 
  91e5c6:	48 81 c7 d8 02 00 00 	add    $0x2d8,%rdi
  91e5cd:	48 8d 15 44 bc a6 00 	lea    0xa6bc44(%rip),%rdx        # 138a218 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5108>
  91e5d4:	e8 47 46 fb ff       	call   8d2c20 <<alloc::vec::Vec<gpui::runtime::Node> as core::ops::index::Index<usize>>::index>
  91e5d9:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e5de:	48 8b b4 24 80 00 00 	mov    0x80(%rsp),%rsi
  91e5e5:	00 
  91e5e6:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
  91e5ed:	00 
  91e5ee:	48 89 84 24 80 01 00 	mov    %rax,0x180(%rsp)
  91e5f5:	00 
  91e5f6:	e8 55 f7 ff ff       	call   91dd50 <<gpui::runtime::Runtime<text_selection::Page>>::editing_at>
  91e5fb:	48 8b b4 24 90 00 00 	mov    0x90(%rsp),%rsi
  91e602:	00 
  91e603:	48 89 c7             	mov    %rax,%rdi
  91e606:	e8 15 af 08 00       	call   9a9520 <<core::option::Option<&gpui::runtime::editing::LogicalSelection>>::is_some_and::<<gpui::runtime::Runtime<text_selection::Page>>::set_selection::{closure#0}>>
  91e60b:	a8 01                	test   $0x1,%al
  91e60d:	0f 85 66 01 00 00    	jne    91e779 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x209>
  91e613:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  91e61a:	00 
  91e61b:	e8 10 f6 09 00       	call   9bdc30 <<gpui::runtime::Node>::text_slot>
  91e620:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e625:	89 44 24 6c          	mov    %eax,0x6c(%rsp)
  91e629:	48 81 c7 f0 02 00 00 	add    $0x2f0,%rdi
  91e630:	e8 bb 33 fb ff       	call   8d19f0 <<alloc::vec::Vec<core::option::Option<gpui::runtime::TextSite>> as core::ops::deref::Deref>::deref>
  91e635:	8b 7c 24 6c          	mov    0x6c(%rsp),%edi
  91e639:	48 89 c6             	mov    %rax,%rsi
  91e63c:	e8 af f2 09 00       	call   9bd8f0 <<gpui::runtime::TextSlot>::get>
  91e641:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
  91e648:	00 
  91e649:	48 8b 94 24 18 02 00 	mov    0x218(%rsp),%rdx
  91e650:	00 
  91e651:	b8 01 00 00 00       	mov    $0x1,%eax
  91e656:	31 c9                	xor    %ecx,%ecx
  91e658:	48 83 fa 00          	cmp    $0x0,%rdx
  91e65c:	48 0f 44 c1          	cmove  %rcx,%rax
  91e660:	48 a9 01 00 00 00    	test   $0x1,%rax
  91e666:	75 0d                	jne    91e675 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x105>
  91e668:	48 8d 3d c1 bb a6 00 	lea    0xa6bbc1(%rip),%rdi        # 138a230 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5120>
  91e66f:	ff 15 1b 46 ac 00    	call   *0xac461b(%rip)        # 13e2c90 <_DYNAMIC+0x370>
  91e675:	48 8b bc 24 88 00 00 	mov    0x88(%rsp),%rdi
  91e67c:	00 
  91e67d:	48 8b 84 24 18 02 00 	mov    0x218(%rsp),%rax
  91e684:	00 
  91e685:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  91e68a:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
  91e691:	00 
  91e692:	48 89 84 24 88 01 00 	mov    %rax,0x188(%rsp)
  91e699:	00 
  91e69a:	e8 81 f5 09 00       	call   9bdc20 <<gpui::runtime::Node>::identity>
  91e69f:	48 89 c1             	mov    %rax,%rcx
  91e6a2:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  91e6a7:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
  91e6ac:	48 8b 40 40          	mov    0x40(%rax),%rax
  91e6b0:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
  91e6b7:	00 
  91e6b8:	b8 01 00 00 00       	mov    $0x1,%eax
  91e6bd:	31 c9                	xor    %ecx,%ecx
  91e6bf:	48 83 bc 24 d8 01 00 	cmpq   $0x0,0x1d8(%rsp)
  91e6c6:	00 00 
  91e6c8:	48 0f 44 c1          	cmove  %rcx,%rax
  91e6cc:	48 a9 01 00 00 00    	test   $0x1,%rax
  91e6d2:	75 0d                	jne    91e6e1 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x171>
  91e6d4:	48 8d 3d 6d bb a6 00 	lea    0xa6bb6d(%rip),%rdi        # 138a248 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5138>
  91e6db:	ff 15 af 45 ac 00    	call   *0xac45af(%rip)        # 13e2c90 <_DYNAMIC+0x370>
  91e6e1:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
  91e6e6:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
  91e6ed:	00 
  91e6ee:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
  91e6f3:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
  91e6fa:	00 
  91e6fb:	48 83 c7 38          	add    $0x38,%rdi
  91e6ff:	e8 0c fc fd ff       	call   8fe310 <<gpui::shared_text::SharedText as core::clone::Clone>::clone>
  91e704:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
  91e709:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
  91e70e:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  91e715:	00 
  91e716:	f3 0f 10 44 24 74    	movss  0x74(%rsp),%xmm0
  91e71c:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e721:	48 89 c2             	mov    %rax,%rdx
  91e724:	8b 44 24 70          	mov    0x70(%rsp),%eax
  91e728:	c6 84 24 67 01 00 00 	movb   $0x1,0x167(%rsp)
  91e72f:	01 
  91e730:	4c 89 84 24 c8 00 00 	mov    %r8,0xc8(%rsp)
  91e737:	00 
  91e738:	48 89 b4 24 b8 00 00 	mov    %rsi,0xb8(%rsp)
  91e73f:	00 
  91e740:	48 89 94 24 c0 00 00 	mov    %rdx,0xc0(%rsp)
  91e747:	00 
  91e748:	0f 10 09             	movups (%rcx),%xmm1
  91e74b:	0f 11 8c 24 a8 00 00 	movups %xmm1,0xa8(%rsp)
  91e752:	00 
  91e753:	89 84 24 a0 00 00 00 	mov    %eax,0xa0(%rsp)
  91e75a:	f3 0f 11 84 24 a4 00 	movss  %xmm0,0xa4(%rsp)
  91e761:	00 00 
  91e763:	48 81 c7 58 06 00 00 	add    $0x658,%rdi
  91e76a:	e8 e1 05 09 00       	call   9aed50 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::as_mut>
  91e76f:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  91e774:	e9 99 00 00 00       	jmp    91e812 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x2a2>
  91e779:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e77e:	48 81 c7 58 06 00 00 	add    $0x658,%rdi
  91e785:	e8 c6 05 09 00       	call   9aed50 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::as_mut>
  91e78a:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
  91e791:	00 
  91e792:	48 8b 94 24 f8 01 00 	mov    0x1f8(%rsp),%rdx
  91e799:	00 
  91e79a:	b8 01 00 00 00       	mov    $0x1,%eax
  91e79f:	31 c9                	xor    %ecx,%ecx
  91e7a1:	48 83 fa 00          	cmp    $0x0,%rdx
  91e7a5:	48 0f 44 c1          	cmove  %rcx,%rax
  91e7a9:	48 a9 01 00 00 00    	test   $0x1,%rax
  91e7af:	75 0d                	jne    91e7be <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x24e>
  91e7b1:	48 8d 3d c0 ba a6 00 	lea    0xa6bac0(%rip),%rdi        # 138a278 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5168>
  91e7b8:	ff 15 d2 44 ac 00    	call   *0xac44d2(%rip)        # 13e2c90 <_DYNAMIC+0x370>
  91e7be:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
  91e7c5:	00 
  91e7c6:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
  91e7cd:	00 
  91e7ce:	48 8b 00             	mov    (%rax),%rax
  91e7d1:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
  91e7d6:	48 83 e0 07          	and    $0x7,%rax
  91e7da:	48 83 f8 00          	cmp    $0x0,%rax
  91e7de:	0f 84 36 03 00 00    	je     91eb1a <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x5aa>
  91e7e4:	e9 4a 03 00 00       	jmp    91eb33 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x5c3>
  91e7e9:	f6 84 24 67 01 00 00 	testb  $0x1,0x167(%rsp)
  91e7f0:	01 
  91e7f1:	0f 85 10 03 00 00    	jne    91eb07 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x597>
  91e7f7:	e9 fe 02 00 00       	jmp    91eafa <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x58a>
  91e7fc:	48 89 c1             	mov    %rax,%rcx
  91e7ff:	89 d0                	mov    %edx,%eax
  91e801:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
  91e808:	00 
  91e809:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  91e810:	eb d7                	jmp    91e7e9 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x279>
  91e812:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  91e817:	e8 c4 54 08 00       	call   9a3ce0 <<core::option::Option<&mut alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::and_then::<&mut alloc::boxed::Box<gpui::runtime::editing::Editing>, <gpui::runtime::Runtime<text_selection::Page>>::set_selection::{closure#1}>>
  91e81c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  91e821:	eb 00                	jmp    91e823 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x2b3>
  91e823:	48 8b 74 24 38       	mov    0x38(%rsp),%rsi
  91e828:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
  91e82f:	00 
  91e830:	e8 7b 52 08 00       	call   9a3ab0 <<core::option::Option<&mut alloc::boxed::Box<gpui::runtime::editing::Editing>>>::and_then::<gpui::runtime::editing::LogicalSelection, <gpui::runtime::Runtime<text_selection::Page>>::set_selection::{closure#2}>>
  91e835:	eb 00                	jmp    91e837 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x2c7>
  91e837:	0f 10 84 24 d0 00 00 	movups 0xd0(%rsp),%xmm0
  91e83e:	00 
  91e83f:	0f 10 8c 24 e0 00 00 	movups 0xe0(%rsp),%xmm1
  91e846:	00 
  91e847:	0f 10 94 24 f0 00 00 	movups 0xf0(%rsp),%xmm2
  91e84e:	00 
  91e84f:	0f 29 94 24 c0 01 00 	movaps %xmm2,0x1c0(%rsp)
  91e856:	00 
  91e857:	0f 29 8c 24 b0 01 00 	movaps %xmm1,0x1b0(%rsp)
  91e85e:	00 
  91e85f:	0f 29 84 24 a0 01 00 	movaps %xmm0,0x1a0(%rsp)
  91e866:	00 
  91e867:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
  91e86e:	00 
  91e86f:	e8 ac 0b fc ff       	call   8df420 <core::mem::drop::<core::option::Option<gpui::runtime::editing::LogicalSelection>>>
  91e874:	eb 00                	jmp    91e876 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x306>
  91e876:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
  91e87b:	c6 84 24 67 01 00 00 	movb   $0x0,0x167(%rsp)
  91e882:	00 
  91e883:	0f 10 84 24 a0 00 00 	movups 0xa0(%rsp),%xmm0
  91e88a:	00 
  91e88b:	0f 10 8c 24 b0 00 00 	movups 0xb0(%rsp),%xmm1
  91e892:	00 
  91e893:	0f 10 94 24 c0 00 00 	movups 0xc0(%rsp),%xmm2
  91e89a:	00 
  91e89b:	0f 29 94 24 50 01 00 	movaps %xmm2,0x150(%rsp)
  91e8a2:	00 
  91e8a3:	0f 29 8c 24 40 01 00 	movaps %xmm1,0x140(%rsp)
  91e8aa:	00 
  91e8ab:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
  91e8b2:	00 
  91e8b3:	c6 84 24 66 01 00 00 	movb   $0x1,0x166(%rsp)
  91e8ba:	01 
  91e8bb:	0f 28 84 24 30 01 00 	movaps 0x130(%rsp),%xmm0
  91e8c2:	00 
  91e8c3:	0f 28 8c 24 40 01 00 	movaps 0x140(%rsp),%xmm1
  91e8ca:	00 
  91e8cb:	0f 28 94 24 50 01 00 	movaps 0x150(%rsp),%xmm2
  91e8d2:	00 
  91e8d3:	0f 29 94 24 20 01 00 	movaps %xmm2,0x120(%rsp)
  91e8da:	00 
  91e8db:	0f 29 8c 24 10 01 00 	movaps %xmm1,0x110(%rsp)
  91e8e2:	00 
  91e8e3:	0f 29 84 24 00 01 00 	movaps %xmm0,0x100(%rsp)
  91e8ea:	00 
  91e8eb:	48 81 c7 58 06 00 00 	add    $0x658,%rdi
  91e8f2:	e8 99 25 08 00       	call   9a0e90 <<core::option::Option<alloc::boxed::Box<gpui::runtime::metadata::Metadata>>>::get_or_insert_with::<<gpui::runtime::Runtime<text_selection::Page>>::set_selection::{closure#3}>>
  91e8f7:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
  91e8fc:	eb 29                	jmp    91e927 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x3b7>
  91e8fe:	f6 84 24 66 01 00 00 	testb  $0x1,0x166(%rsp)
  91e905:	01 
  91e906:	0f 85 d2 01 00 00    	jne    91eade <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x56e>
  91e90c:	e9 d8 fe ff ff       	jmp    91e7e9 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x279>
  91e911:	48 89 c1             	mov    %rax,%rcx
  91e914:	89 d0                	mov    %edx,%eax
  91e916:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
  91e91d:	00 
  91e91e:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  91e925:	eb d7                	jmp    91e8fe <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x38e>
  91e927:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  91e92c:	48 8b 00             	mov    (%rax),%rax
  91e92f:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  91e934:	48 83 e0 07          	and    $0x7,%rax
  91e938:	48 83 f8 00          	cmp    $0x0,%rax
  91e93c:	75 16                	jne    91e954 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x3e4>
  91e93e:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
  91e943:	48 83 f8 00          	cmp    $0x0,%rax
  91e947:	0f 94 c0             	sete   %al
  91e94a:	24 ff                	and    $0xff,%al
  91e94c:	34 ff                	xor    $0xff,%al
  91e94e:	a8 01                	test   $0x1,%al
  91e950:	75 19                	jne    91e96b <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x3fb>
  91e952:	eb 2f                	jmp    91e983 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x413>
  91e954:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
  91e959:	bf 08 00 00 00       	mov    $0x8,%edi
  91e95e:	48 8d 15 fb b8 a6 00 	lea    0xa6b8fb(%rip),%rdx        # 138a260 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5150>
  91e965:	ff 15 6d 42 ac 00    	call   *0xac426d(%rip)        # 13e2bd8 <_DYNAMIC+0x2b8>
  91e96b:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  91e970:	48 81 c7 e0 00 00 00 	add    $0xe0,%rdi
  91e977:	e8 04 24 08 00       	call   9a0d80 <<core::option::Option<alloc::boxed::Box<gpui::runtime::editing::Editing>>>::get_or_insert_with::<<alloc::boxed::Box<gpui::runtime::editing::Editing> as core::default::Default>::default>>
  91e97c:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  91e981:	eb 0d                	jmp    91e990 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x420>
  91e983:	48 8d 3d d6 b8 a6 00 	lea    0xa6b8d6(%rip),%rdi        # 138a260 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5150>
  91e98a:	ff 15 58 42 ac 00    	call   *0xac4258(%rip)        # 13e2be8 <_DYNAMIC+0x2c8>
  91e990:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  91e995:	48 8b 38             	mov    (%rax),%rdi
  91e998:	48 8b 05 41 4a ac 00 	mov    0xac4a41(%rip),%rax        # 13e33e0 <_DYNAMIC+0xac0>
  91e99f:	ff d0                	call   *%rax
  91e9a1:	eb 3e                	jmp    91e9e1 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x471>
  91e9a3:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  91e9a8:	48 8b 00             	mov    (%rax),%rax
  91e9ab:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  91e9b0:	c6 84 24 66 01 00 00 	movb   $0x0,0x166(%rsp)
  91e9b7:	00 
  91e9b8:	48 83 e0 07          	and    $0x7,%rax
  91e9bc:	48 83 f8 00          	cmp    $0x0,%rax
  91e9c0:	0f 84 c2 00 00 00    	je     91ea88 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x518>
  91e9c6:	e9 d3 00 00 00       	jmp    91ea9e <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x52e>
  91e9cb:	48 89 c1             	mov    %rax,%rcx
  91e9ce:	89 d0                	mov    %edx,%eax
  91e9d0:	48 89 8c 24 90 01 00 	mov    %rcx,0x190(%rsp)
  91e9d7:	00 
  91e9d8:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
  91e9df:	eb c2                	jmp    91e9a3 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x433>
  91e9e1:	48 8b 44 24 20       	mov    0x20(%rsp),%rax
  91e9e6:	48 8b 00             	mov    (%rax),%rax
  91e9e9:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
  91e9ee:	c6 84 24 66 01 00 00 	movb   $0x0,0x166(%rsp)
  91e9f5:	00 
  91e9f6:	48 83 e0 07          	and    $0x7,%rax
  91e9fa:	48 83 f8 00          	cmp    $0x0,%rax
  91e9fe:	75 16                	jne    91ea16 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x4a6>
  91ea00:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  91ea05:	48 83 f8 00          	cmp    $0x0,%rax
  91ea09:	0f 94 c0             	sete   %al
  91ea0c:	24 ff                	and    $0xff,%al
  91ea0e:	34 ff                	xor    $0xff,%al
  91ea10:	a8 01                	test   $0x1,%al
  91ea12:	75 19                	jne    91ea2d <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x4bd>
  91ea14:	eb 54                	jmp    91ea6a <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x4fa>
  91ea16:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  91ea1b:	bf 08 00 00 00       	mov    $0x8,%edi
  91ea20:	48 8d 15 39 b8 a6 00 	lea    0xa6b839(%rip),%rdx        # 138a260 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5150>
  91ea27:	ff 15 ab 41 ac 00    	call   *0xac41ab(%rip)        # 13e2bd8 <_DYNAMIC+0x2b8>
  91ea2d:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
  91ea32:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
  91ea39:	00 
  91ea3a:	ba 30 00 00 00       	mov    $0x30,%edx
  91ea3f:	e8 3c 46 a6 00       	call   1383080 <memcpy@plt>
  91ea44:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  91ea49:	c6 84 24 66 01 00 00 	movb   $0x0,0x166(%rsp)
  91ea50:	00 
  91ea51:	c6 80 63 07 00 00 01 	movb   $0x1,0x763(%rax)
  91ea58:	c6 84 24 9f 00 00 00 	movb   $0x1,0x9f(%rsp)
  91ea5f:	01 
  91ea60:	c6 84 24 67 01 00 00 	movb   $0x0,0x167(%rsp)
  91ea67:	00 
  91ea68:	eb 0d                	jmp    91ea77 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x507>
  91ea6a:	48 8d 3d ef b7 a6 00 	lea    0xa6b7ef(%rip),%rdi        # 138a260 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5150>
  91ea71:	ff 15 79 46 ac 00    	call   *0xac4679(%rip)        # 13e30f0 <_DYNAMIC+0x7d0>
  91ea77:	8a 84 24 9f 00 00 00 	mov    0x9f(%rsp),%al
  91ea7e:	24 01                	and    $0x1,%al
  91ea80:	48 81 c4 28 02 00 00 	add    $0x228,%rsp
  91ea87:	c3                   	ret
  91ea88:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  91ea8d:	48 83 f8 00          	cmp    $0x0,%rax
  91ea91:	0f 94 c0             	sete   %al
  91ea94:	24 ff                	and    $0xff,%al
  91ea96:	34 ff                	xor    $0xff,%al
  91ea98:	a8 01                	test   $0x1,%al
  91ea9a:	75 19                	jne    91eab5 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x545>
  91ea9c:	eb 33                	jmp    91ead1 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x561>
  91ea9e:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
  91eaa3:	bf 08 00 00 00       	mov    $0x8,%edi
  91eaa8:	48 8d 15 b1 b7 a6 00 	lea    0xa6b7b1(%rip),%rdx        # 138a260 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5150>
  91eaaf:	ff 15 23 41 ac 00    	call   *0xac4123(%rip)        # 13e2bd8 <_DYNAMIC+0x2b8>
  91eab5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  91eaba:	48 8d b4 24 00 01 00 	lea    0x100(%rsp),%rsi
  91eac1:	00 
  91eac2:	ba 30 00 00 00       	mov    $0x30,%edx
  91eac7:	e8 b4 45 a6 00       	call   1383080 <memcpy@plt>
  91eacc:	e9 2d fe ff ff       	jmp    91e8fe <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x38e>
  91ead1:	48 8d 3d 88 b7 a6 00 	lea    0xa6b788(%rip),%rdi        # 138a260 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5150>
  91ead8:	ff 15 12 46 ac 00    	call   *0xac4612(%rip)        # 13e30f0 <_DYNAMIC+0x7d0>
  91eade:	48 8b 05 fb 48 ac 00 	mov    0xac48fb(%rip),%rax        # 13e33e0 <_DYNAMIC+0xac0>
  91eae5:	48 8d bc 24 00 01 00 	lea    0x100(%rsp),%rdi
  91eaec:	00 
  91eaed:	ff d0                	call   *%rax
  91eaef:	e9 f5 fc ff ff       	jmp    91e7e9 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x279>
  91eaf4:	ff 15 ce 40 ac 00    	call   *0xac40ce(%rip)        # 13e2bc8 <_DYNAMIC+0x2a8>
  91eafa:	48 8b bc 24 90 01 00 	mov    0x190(%rsp),%rdi
  91eb01:	00 
  91eb02:	e8 89 45 a6 00       	call   1383090 <_Unwind_Resume@plt>
  91eb07:	48 8b 05 f2 4d ac 00 	mov    0xac4df2(%rip),%rax        # 13e3900 <_DYNAMIC+0xfe0>
  91eb0e:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  91eb15:	00 
  91eb16:	ff d0                	call   *%rax
  91eb18:	eb e0                	jmp    91eafa <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x58a>
  91eb1a:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  91eb1f:	48 83 f8 00          	cmp    $0x0,%rax
  91eb23:	0f 94 c0             	sete   %al
  91eb26:	24 ff                	and    $0xff,%al
  91eb28:	34 ff                	xor    $0xff,%al
  91eb2a:	a8 01                	test   $0x1,%al
  91eb2c:	75 1c                	jne    91eb4a <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x5da>
  91eb2e:	e9 80 00 00 00       	jmp    91ebb3 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x643>
  91eb33:	48 8b 74 24 40       	mov    0x40(%rsp),%rsi
  91eb38:	bf 08 00 00 00       	mov    $0x8,%edi
  91eb3d:	48 8d 15 4c b7 a6 00 	lea    0xa6b74c(%rip),%rdx        # 138a290 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5180>
  91eb44:	ff 15 8e 40 ac 00    	call   *0xac408e(%rip)        # 13e2bd8 <_DYNAMIC+0x2b8>
  91eb4a:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
  91eb4f:	48 81 c7 e0 00 00 00 	add    $0xe0,%rdi
  91eb56:	e8 85 00 09 00       	call   9aebe0 <<core::option::Option<alloc::boxed::Box<gpui::runtime::editing::Editing>>>::as_mut>
  91eb5b:	48 89 84 24 e8 01 00 	mov    %rax,0x1e8(%rsp)
  91eb62:	00 
  91eb63:	48 8b 94 24 e8 01 00 	mov    0x1e8(%rsp),%rdx
  91eb6a:	00 
  91eb6b:	b8 01 00 00 00       	mov    $0x1,%eax
  91eb70:	31 c9                	xor    %ecx,%ecx
  91eb72:	48 83 fa 00          	cmp    $0x0,%rdx
  91eb76:	48 0f 44 c1          	cmove  %rcx,%rax
  91eb7a:	48 a9 01 00 00 00    	test   $0x1,%rax
  91eb80:	75 0d                	jne    91eb8f <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x61f>
  91eb82:	48 8d 3d 1f b7 a6 00 	lea    0xa6b71f(%rip),%rdi        # 138a2a8 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5198>
  91eb89:	ff 15 01 41 ac 00    	call   *0xac4101(%rip)        # 13e2c90 <_DYNAMIC+0x370>
  91eb8f:	48 8b 84 24 e8 01 00 	mov    0x1e8(%rsp),%rax
  91eb96:	00 
  91eb97:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
  91eb9e:	00 
  91eb9f:	48 8b 00             	mov    (%rax),%rax
  91eba2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
  91eba7:	48 83 e0 07          	and    $0x7,%rax
  91ebab:	48 83 f8 00          	cmp    $0x0,%rax
  91ebaf:	74 0f                	je     91ebc0 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x650>
  91ebb1:	eb 26                	jmp    91ebd9 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x669>
  91ebb3:	48 8d 3d d6 b6 a6 00 	lea    0xa6b6d6(%rip),%rdi        # 138a290 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5180>
  91ebba:	ff 15 28 40 ac 00    	call   *0xac4028(%rip)        # 13e2be8 <_DYNAMIC+0x2c8>
  91ebc0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  91ebc5:	48 83 f8 00          	cmp    $0x0,%rax
  91ebc9:	0f 94 c0             	sete   %al
  91ebcc:	24 ff                	and    $0xff,%al
  91ebce:	34 ff                	xor    $0xff,%al
  91ebd0:	a8 01                	test   $0x1,%al
  91ebd2:	75 1c                	jne    91ebf0 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x680>
  91ebd4:	e9 83 00 00 00       	jmp    91ec5c <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x6ec>
  91ebd9:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
  91ebde:	bf 08 00 00 00       	mov    $0x8,%edi
  91ebe3:	48 8d 15 a6 b6 a6 00 	lea    0xa6b6a6(%rip),%rdx        # 138a290 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5180>
  91ebea:	ff 15 e8 3f ac 00    	call   *0xac3fe8(%rip)        # 13e2bd8 <_DYNAMIC+0x2b8>
  91ebf0:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
  91ebf5:	e8 86 0e 09 00       	call   9afa80 <<core::option::Option<gpui::runtime::editing::LogicalSelection>>::as_mut>
  91ebfa:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
  91ec01:	00 
  91ec02:	48 8b 94 24 08 02 00 	mov    0x208(%rsp),%rdx
  91ec09:	00 
  91ec0a:	b8 01 00 00 00       	mov    $0x1,%eax
  91ec0f:	31 c9                	xor    %ecx,%ecx
  91ec11:	48 83 fa 00          	cmp    $0x0,%rdx
  91ec15:	48 0f 44 c1          	cmove  %rcx,%rax
  91ec19:	48 a9 01 00 00 00    	test   $0x1,%rax
  91ec1f:	75 0d                	jne    91ec2e <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x6be>
  91ec21:	48 8d 3d 98 b6 a6 00 	lea    0xa6b698(%rip),%rdi        # 138a2c0 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x51b0>
  91ec28:	ff 15 62 40 ac 00    	call   *0xac4062(%rip)        # 13e2c90 <_DYNAMIC+0x370>
  91ec2e:	f3 0f 10 44 24 74    	movss  0x74(%rsp),%xmm0
  91ec34:	8b 4c 24 70          	mov    0x70(%rsp),%ecx
  91ec38:	48 8b 84 24 08 02 00 	mov    0x208(%rsp),%rax
  91ec3f:	00 
  91ec40:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
  91ec47:	00 
  91ec48:	89 08                	mov    %ecx,(%rax)
  91ec4a:	f3 0f 11 40 04       	movss  %xmm0,0x4(%rax)
  91ec4f:	c6 84 24 9f 00 00 00 	movb   $0x0,0x9f(%rsp)
  91ec56:	00 
  91ec57:	e9 1b fe ff ff       	jmp    91ea77 <<gpui::runtime::Runtime<text_selection::Page>>::set_selection+0x507>
  91ec5c:	48 8d 3d 2d b6 a6 00 	lea    0xa6b62d(%rip),%rdi        # 138a290 <text_selection::ordinary_replace_typing_keyboard_and_accessibility_share_selection_aware_source_edits+0x5180>
  91ec63:	ff 15 7f 3f ac 00    	call   *0xac3f7f(%rip)        # 13e2be8 <_DYNAMIC+0x2c8>
