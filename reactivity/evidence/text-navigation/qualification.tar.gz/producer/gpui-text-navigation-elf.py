import json,re,subprocess,sys
binary=sys.argv[1]
rows=[]
for line in subprocess.check_output(['nm','-S','-C',binary],text=True).splitlines():
    m=re.match(r'([0-9a-f]+) ([0-9a-f]+) \w (.*)',line)
    if not m: continue
    addr,size,name=m.groups()
    if name not in ['<gpui::runtime::Win<text_selection::Page>>::key','<gpui::runtime::RuntimeMut<text_selection::Page, ()>>::move_selection','<gpui::runtime::RuntimeMut<text_selection::Page, ()>>::move_line_selection']: continue
    start=int(addr,16)
    asm=subprocess.check_output(['objdump','-d',f'--start-address={start}',f'--stop-address={start+96}',binary],text=True)
    prologue=asm.split('Disassembly of section .text:')[-1]
    reserved=0
    for line in prologue.splitlines():
        insn=re.match(r'^\s*[0-9a-f]+:\s+(?:[0-9a-f]{2}\s+)+\s*(\w+)\s*(.*)',line)
        if not insn: continue
        op,args=insn.groups()
        if op=='push': reserved+=8
        elif op=='sub' and re.fullmatch(r'\$0x[0-9a-f]+,%rsp',args): reserved+=int(args.split(',')[0][3:],16)
        elif op=='mov' and args=='%rsp,%rbp': pass
        elif op in ('endbr64','nop','nopl','nopw'): pass
        else: break

    rows.append({'symbol':name,'linked_code_bytes':int(size,16),'prologue_reserved_bytes_including_register_pushes_excluding_return_address':reserved,'prologue':prologue})
print(json.dumps({'binary':binary,'symbols':rows},indent=2))
