from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time,traceback
p=Path('/Users/mileswirht/gpui-reactivity-20261024-root'); s=p/'source'; out=p/'metal-stable';out.mkdir()
g=json.loads((s/'source-manifest.json').read_text())
def check():
    for name,h in g.items():assert hashlib.sha256((s/name).read_bytes()).hexdigest()==h,name
def save(r):
    q=out/'status.tmp';q.write_text(json.dumps(r,indent=2)+'\n');q.replace(out/'status.json')
r={'state':'starting','source':'5aff5a1b30cd2518ecd69852fa586fbdeafcdbff','pid':os.getpid(),'profile':'hardware Metal oracle; stable host compiler explicitly recorded','results':[]};save(r)
child=None
try:
    check();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(p/'target'),CARGO_HOME=str(p/'cargo-home'),CARGO_BUILD_JOBS='4',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
    (out/'toolchain.txt').write_text(subprocess.check_output(['rustc','--version','--verbose'],env=env,text=True)+'\n'+subprocess.check_output(['cargo','--version'],env=env,text=True))
    cmd=['cargo','test','--manifest-path',str(s/'reactivity/Cargo.toml'),'--locked','-p','gpui_gpu','--features','gpu-tests','--lib','--test','render','--no-run','--message-format=json']
    (out/'command.json').write_text(json.dumps(cmd,indent=2)); r['state']='building';save(r)
    with (out/'build.jsonl').open('w') as stdout,(out/'build.stderr').open('w') as stderr:
        child=subprocess.Popen(cmd,cwd=s,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        while child.poll() is None:
            if shutil.disk_usage(p).free<20*1024**3:os.killpg(child.pid,signal.SIGTERM);raise RuntimeError('task disk floor')
            time.sleep(.5)
        assert child.returncode==0,('build',child.returncode)
    check()
    rows=[json.loads(x) for x in (out/'build.jsonl').read_text().splitlines()]
    artifacts=[x for x in rows if x.get('reason')=='compiler-artifact' and x.get('executable') and x['profile']['test']]
    assert len(artifacts)==2
    r['state']='executing';save(r)
    for i,row in enumerate(artifacts):
        original=Path(row['executable']);f=out/('test-'+str(i));original.rename(f);f.chmod(0o555)
        h=hashlib.sha256(f.read_bytes()).hexdigest(); item={'target':row['target']['name'],'sha256':h,'features':row['features'],'bytes':f.stat().st_size}
        (out/('binary-'+str(i)+'.json')).write_text(json.dumps(item|{'cargo':row},indent=2))
        with (out/('test-'+str(i)+'.stdout')).open('w') as stdout,(out/('test-'+str(i)+'.stderr')).open('w') as stderr:
            child=subprocess.Popen([str(f),'--nocapture','--test-threads=1'],env=env,stdout=stdout,stderr=stderr,start_new_session=True)
            try:item['exit']=child.wait(timeout=600)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGTERM);child.wait(timeout=10);raise
        assert hashlib.sha256(f.read_bytes()).hexdigest()==h
        r['results'].append(item);save(r)
    check();r['state']='complete';r['source_hashes_match']=True;r['all_exit_zero']=all(x['exit']==0 for x in r['results']);save(r)
except BaseException:
    if child and child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
    r['state']='failed';r['error']=traceback.format_exc();save(r)
