set -euo pipefail
source /tmp/gpui-native-env.sh
source /tmp/gpui-nightly-env.sh
export CARGO_TARGET_DIR=/tmp/gpui-hummingbird-compose-root-target
export CARGO_BUILD_JOBS=2
py=/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3
runner=/root/gpui-ce3/reactivity/evidence/clipping-gradients-integration/gpui-run-frozen-gate-root.py
pin=5aff5a1b30cd2518ecd69852fa586fbdeafcdbff
input=/tmp/gpui-portable-gpu-tests-root
scopes=(--scope .cargo --scope clippy.toml --scope reactivity/Cargo.toml --scope reactivity/Cargo.lock --scope reactivity/rust-toolchain.toml --scope reactivity/crates --scope reactivity/vendor)
"$py" "$runner" --source "$input" --pin "$pin" --out /tmp/gpui-portable-gpu-tests-root-clean --timeout 600 "${scopes[@]}" -- cargo clean --manifest-path reactivity/Cargo.toml -p gpui_gpu
"$py" "$runner" --source "$input" --pin "$pin" --out /tmp/gpui-portable-gpu-tests-root-build --timeout 1800 "${scopes[@]}" -- cargo test --manifest-path reactivity/Cargo.toml --locked --offline -p gpui_gpu --features vulkan-tests --all-targets --no-run --message-format=json -Z checksum-freshness --config 'build.fingerprint="content"'
"$py" "$runner" --source "$input" --pin "$pin" --out /tmp/gpui-portable-gpu-tests-root-execute --timeout 900 "${scopes[@]}" -- "$py" /tmp/gpui-run-moved-test-artifacts-root.py --build /tmp/gpui-portable-gpu-tests-root-build --out /tmp/gpui-portable-gpu-tests-root-artifacts --per-binary-seconds 240
"$py" "$runner" --source "$input" --pin "$pin" --out /tmp/gpui-portable-gpu-tests-root-strict --timeout 1800 "${scopes[@]}" -- cargo clippy --manifest-path reactivity/Cargo.toml --locked --offline -p gpui_gpu --features vulkan-tests --all-targets -Z checksum-freshness --config 'build.fingerprint="content"' -- -D warnings
"$py" "$runner" --source "$input" --pin "$pin" --out /tmp/gpui-portable-gpu-tests-root-hardware-build --timeout 1200 "${scopes[@]}" -- cargo test --manifest-path reactivity/Cargo.toml --locked --offline -p gpui_gpu --features gpu-tests --test render --no-run --message-format=json -Z checksum-freshness --config 'build.fingerprint="content"'
