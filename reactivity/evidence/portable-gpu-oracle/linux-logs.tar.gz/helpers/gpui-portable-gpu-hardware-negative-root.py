from pathlib import Path
import hashlib,json,subprocess
build=Path('/tmp/gpui-portable-gpu-tests-root-hardware-build')
out=Path('/tmp/gpui-portable-gpu-tests-root-hardware-negative');out.mkdir(exist_ok=False)
rows=[json.loads(x) for x in (build/'stdout.log').read_text().splitlines()]
row=next(x for x in rows if x.get('reason')=='compiler-artifact' and x.get('executable') and x['target']['name']=='render')
assert row['features']==['default','gpu-tests','simd'],row['features']
f=Path(row['executable']);assert f.stat().st_nlink==1
binary=out/'render';f.rename(binary);binary.chmod(0o555)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
h=sha(binary);(out/'binary.json').write_text(json.dumps({'sha256':h,'bytes':binary.stat().st_size,'cargo':row},indent=2)+'\n')
cmd=[str(binary),'unsupported_context_format_does_not_request_a_device','--exact','--nocapture','--test-threads=1']
with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
    r=subprocess.run(cmd,stdout=stdout,stderr=stderr,timeout=120)
assert sha(binary)==h
stdout=(out/'stdout.log').read_text();stderr=(out/'stderr.log').read_text()
assert r.returncode==101 and '1 failed' in stdout and 'running 1 test' in stdout
assert 'software_requested=false' in stderr and 'device_type: Cpu' in stderr and 'hardware oracle requires a physical GPU' in stderr
result={'source':'5aff5a1b30cd2518ecd69852fa586fbdeafcdbff','command':cmd,'exit':r.returncode,'one_test_entered':True,'software_adapter_rejected_by_hardware_profile':True,'sha256_matches_after':True,'hardware_pass_claim':False}
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
