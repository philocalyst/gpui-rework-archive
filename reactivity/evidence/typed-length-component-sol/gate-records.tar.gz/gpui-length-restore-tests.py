from pathlib import Path
import re,subprocess
p=Path('reactivity/crates/gpui/tests/dimensions.rs')
s=subprocess.check_output(['git','-c','safe.directory=/root/gpui-length-port-sol-20261024','show','HEAD:'+str(p)],text=True)
start=s.index('fn bounds<');end=s.index('\n#[test]',start)
s=s[:start]+'''// Canonical geometry is exact. Win::bounds is deliberately outward-rounded
// for conservative clipping and is not the dimension's authored-size oracle.
fn bounds<M: View + 'static>(win: &Win<M>, name: &str) -> Rect {
    let mut result = None;
    win.visit(|part| {
        if part.name() == Some(name) {
            let local = part.local_bounds();
            let map = part.transform().unwrap();
            result = Some(Rect { x: map.tx, y: map.ty, ..local });
        }
    }).unwrap();
    result.unwrap()
}
'''+s[end:]
pattern=r'assert!\(\s*win\.snapshot\(\)\s*\.unwrap\(\)\s*\.nodes\s*\.iter\(\)\s*\.any\(\|n\| n\.bounds\[2\] == 285\.0\)\s*\);'
s,n=re.subn(pattern,'assert_eq!(bounds(&win, "panel").width, 285.0);',s)
assert n==1,n
s=s.replace('win.query().name("GPUI Inspector").one().unwrap()', 'win.role(gpui::Role::ScrollView).name("GPUI Inspector").one().unwrap()')
marker='    assert_eq!(bounds(&win, "panel").height, 40.0);\n'
assert marker in s
s=s.replace(marker,marker+'''    for value in [Length::Percent(-0.0), Length::Percent(0.0)] {
        win.set(Panel::SIZE, value).unwrap();
        assert!(WIDTH.same_authoring(&win.property(target, WIDTH).unwrap(), &value));
    }
''')
assert s.count('#[test]')==7
p.write_text(s)
