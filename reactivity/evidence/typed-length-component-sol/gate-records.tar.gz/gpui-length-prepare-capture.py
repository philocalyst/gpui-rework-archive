from pathlib import Path
s=Path('/tmp/component-port-sol-native-capture.py').read_text()
s=s.replace('component-port-sol','gpui-length').replace('component-port-native-','gpui-length-native-')
s=s.replace('/root/targets/gpui-length-native-20261024/debug/examples/halloween','/root/targets/typed-length-port-sol-native-20261024/debug/examples/halloween')
marker="     result={'binary':str(binary)"
assert marker in s
s=s.replace(marker,"""     subprocess.run([xdotool,'windowsize','--sync',window,'960','700'],env=env,check=True)
     resize_epoch=presented_after(epoch)
     geometry=subprocess.check_output([xdotool,'getwindowgeometry','--shell',window],env=env,text=True)
     assert 'WIDTH=960' in geometry and 'HEIGHT=700' in geometry,geometry
     subprocess.run([import_image,'-window',window,'/tmp/gpui-length-halloween-native-resized.png'],env=env,check=True)
"""+marker)
s=s.replace("'screenshots':['draft','focus','ready']", "'screenshots':['draft','focus','ready','resized']")
s=s.replace("'final_acknowledged_epoch':epoch", "'final_acknowledged_epoch':epoch,'resize_acknowledged_epoch':resize_epoch,'resized_geometry':geometry")
Path('/tmp/gpui-length-native-capture.py').write_text(s)
