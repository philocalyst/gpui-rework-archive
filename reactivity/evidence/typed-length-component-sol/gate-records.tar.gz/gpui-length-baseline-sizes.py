from pathlib import Path
import json,subprocess,hashlib
rows=[json.loads(s) for s in Path('/tmp/component-port-sol-release-artifacts-16.jsonl').read_text().splitlines() if s.startswith('{')]
libs=[r for r in rows if r.get('reason')=='compiler-artifact' and 'lib' in r['target']['kind']]
gpui=next(r for r in libs if r['target']['name']=='gpui')
rlib=next(f for f in gpui['filenames'] if f.endswith('.rmeta'))
dirs=sorted({str(Path(f).parent) for r in rows if r.get('reason')=='compiler-artifact' for f in r['filenames']})
p=Path('/tmp/gpui-length-baseline-sizes.rs');p.write_text('''fn main() {
 println!("baseline PropInputNumber={} PropInputColor={} Style={} El={} SignalNumber={} SignalOptionPoints={}",
 std::mem::size_of::<gpui::PropInput<'static,f64>>(),std::mem::size_of::<gpui::PropInput<'static,gpui::Color>>(),
 std::mem::size_of::<gpui::Style>(),std::mem::size_of::<gpui::El<'static>>(),std::mem::size_of::<gpui::Signal<f64>>(),std::mem::size_of::<gpui::Signal<Option<f32>>>());
}
''')
args=['/tmp/gpui-nightly-2026-10-23/bin/rustc','--edition','2024','--crate-name','dimension_baseline_sizes',str(p),'--extern','gpui='+rlib,'-o','/tmp/gpui-length-baseline-sizes']
for d in dirs:args+=['-L','dependency='+d]
subprocess.run(args,check=True)
output=subprocess.check_output(['/tmp/gpui-length-baseline-sizes'],text=True)
Path('/tmp/gpui-length-baseline-sizes.log').write_text(output)
Path('/tmp/gpui-length-baseline-sizes.json').write_text(json.dumps({'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rlib':rlib,'rlib_sha256':hashlib.sha256(Path(rlib).read_bytes()).hexdigest(),'command':args,'output':output},indent=2)+'\n')
print(output)
