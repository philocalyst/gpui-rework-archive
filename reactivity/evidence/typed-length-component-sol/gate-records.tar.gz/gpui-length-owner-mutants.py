from pathlib import Path
import subprocess,os,json,hashlib
root=Path('/root/gpui-length-port-sol-20261024')
relative='reactivity/crates/component/examples/support/party.rs'
file=root/relative
base=file.read_bytes()
git=['git','-c',f'safe.directory={root}','-C',str(root)]
receipts=[]
command=['cargo','-Z','checksum-freshness','--config','build.fingerprint="content"','test','--manifest-path','reactivity/Cargo.toml','--locked','--offline','--release','-p','gpui-component','--test','contracts','--message-format=json','--','--exact','party_default_toggle_and_title_edits_refresh_checked_validation_and_parent_policy']
env=dict(os.environ,CARGO_TARGET_DIR='/root/targets/typed-length-port-sol-release-20261024',CARGO_BUILD_JOBS='4')
try:
 for name,source in [('child_direct',base.decode().replace('Sources::new().field(Self::LANTERNS).field(Self::TREATS)','Sources::new().direct(Self::LANTERNS).direct(Self::TREATS)').replace('.component(Self::PREPARATION)','.direct_component(Self::PREPARATION)')),('title_direct',base.decode().replace('.field(Self::TITLE)','.direct(Self::TITLE)'))]:
  assert source.encode()!=base
  file.write_text(source)
  subprocess.run(git+['add',relative],check=True)
  subprocess.run(git+['commit','-m',f'Bounded regression mutant: remove {name} snapshot dependency'],check=True)
  prefix=f'/tmp/gpui-length-mutant-{name}'
  subprocess.run(['/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3','/tmp/gpui-length-inputs.py',prefix+'-before.json'],check=True)
  with open(prefix+'.log','w') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
  subprocess.run(['/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3','/tmp/gpui-length-inputs.py',prefix+'-after.json'],check=True)
  log=Path(prefix+'.log').read_text()
  artifacts=[]
  for line in log.splitlines():
   if not line.startswith('{'):continue
   row=json.loads(line)
   if row.get('reason')=='compiler-artifact' and row['target']['name']=='contracts':artifacts.append(row)
  assert artifacts and not artifacts[-1]['fresh']
  exe=Path(artifacts[-1]['executable'])
  receipt={'mutant':name,'exit_code':result.returncode,'source_commit':subprocess.check_output(git+['rev-parse','HEAD'],text=True).strip(),'executable':str(exe),'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'test_recompiled':True,'expected_failure':result.returncode==101 and 'test result: FAILED. 0 passed; 1 failed' in log}
  receipts.append(receipt)
  print(json.dumps(receipt),flush=True)
  assert receipt['expected_failure']
finally:
 file.write_bytes(base)
 subprocess.run(git+['add',relative],check=True)
 # On every path leave a concrete correct candidate, never a mutant source.
 subprocess.run(git+['commit','-m','Restore snapshot dependencies after bounded ordinary-interface mutants'],check=True)
 Path('/tmp/gpui-length-owner-mutants.json').write_text(json.dumps(receipts,indent=2)+'\n')
