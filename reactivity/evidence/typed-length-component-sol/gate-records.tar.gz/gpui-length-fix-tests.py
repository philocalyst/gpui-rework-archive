from pathlib import Path
p=Path('/root/gpui-length-port-sol-20261024/reactivity/crates/gpui/tests/dimensions.rs')
s=p.read_text().replace('.property_override(','.contribution(')
s=s.replace('win.snapshot().unwrap().nodes.iter().any(|n| n.name.as_deref()==Some("panel") && n.bounds.width==285.0)','win.snapshot().unwrap().nodes.iter().any(|n| n.bounds[2]==285.0)')
p.write_text(s)
