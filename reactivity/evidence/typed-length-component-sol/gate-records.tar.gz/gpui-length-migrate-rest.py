from pathlib import Path
import re
root=Path('/root/gpui-length-port-sol-20261024/reactivity/crates')
for p in root.rglob('*.rs'):
 if p.parts[len(root.parts)+1] not in ('src','tests','examples'):continue
 s=p.read_text();old=s
 ns='crate::Length' if 'src' in p.relative_to(root).parts[:2] else 'gpui::Length'
 s=re.sub(r'(Contribution::Set\()Some\((?=-?\d+\.\d*|f32::)',rf'\1{ns}::Points(',s)
 s=s.replace('Contribution::Set(Some(if n % 2 == 0 { 2. } else { 3. }))',f'Contribution::Set({ns}::Points(if n % 2 == 0 {{ 2. }} else {{ 3. }}))')
 if s!=old:p.write_text(s)
p=root/'component/examples/support/party.rs';s=p.read_text();s=s.replace('.parts(|parts| parts.frame(|e: El<\'_>| e.w(t.rem(29.0))))','.parts(|parts| parts.frame(|e: El<\'_>| e.w(gpui::Length::Percent(100.0))))');s=s.replace('.gap(t.space(Space::Group))\n        .p(','.size(gpui::Length::Percent(100.0))\n        .gap(t.space(Space::Group))\n        .p(');p.write_text(s)
