fn main() {
 println!("baseline PropInputNumber={} PropInputColor={} Style={} El={} SignalNumber={} SignalOptionPoints={}",
 std::mem::size_of::<gpui::PropInput<'static,f64>>(),std::mem::size_of::<gpui::PropInput<'static,gpui::Color>>(),
 std::mem::size_of::<gpui::Style>(),std::mem::size_of::<gpui::El<'static>>(),std::mem::size_of::<gpui::Signal<f64>>(),std::mem::size_of::<gpui::Signal<Option<f32>>>());
}
