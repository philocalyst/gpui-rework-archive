from pathlib import Path
root=Path('/root/gpui-length-port-sol-20261024/reactivity/crates/gpui')
p=root/'tests/dimensions.rs';s=p.read_text();start=s.index('fn bounds<');end=s.index('\n#[test]',start)
s=s[:start]+'''// Canonical geometry is exact. Win::bounds is deliberately outward-rounded
// for conservative clipping and is not the dimension's authored-size oracle.
fn bounds<M: View + 'static>(win: &Win<M>, name: &str) -> Rect {
    let mut result = None;
    win.visit(|part| {
        if part.name() == Some(name) {
            let local = part.local_bounds();
            let map = part.transform().unwrap();
            result = Some(Rect { x: map.tx, y: map.ty, ..local });
        }
    }).unwrap();
    result.unwrap()
}
'''+s[end:]
s=s.replace('assert!(\n        win.snapshot()\n            .unwrap()\n            .nodes\n            .iter()\n            .any(|n| n.bounds[2] == 285.0)\n    );','assert_eq!(bounds(&win, "panel").width, 285.0);')
# Handle the formatter's exact shape independently of whitespace.
start=s.index('assert!(',s.index('win.presented(pending).unwrap();'))
end=s.index('    assert!(',start+1)
s=s[:start]+'assert_eq!(bounds(&win, "panel").width, 285.0);\n'+s[end:]
s=s.replace('win.query().name("GPUI Inspector").one().unwrap()', 'win.role(gpui::Role::ScrollView).name("GPUI Inspector").one().unwrap()')
marker='''    assert_eq!(bounds(&win, "panel").height, 40.0);
'''
assert marker in s
s=s.replace(marker,marker+'''    for value in [Length::Percent(-0.0), Length::Percent(0.0)] {
        win.set(Panel::SIZE, value).unwrap();
        assert!(WIDTH.same_authoring(&win.property(target, WIDTH).unwrap(), &value));
    }
''')
p.write_text(s)
p=root/'tests/property_selection.rs';s=p.read_text();s+='''
#[test]
fn cold_value_editor_roundtrips_percent_units_and_rejects_invalid_authored_values() {
    let mut win = Win::with_size(Companion::default(), 800, 400).unwrap();
    let target = select_application(&mut win);
    draft(&mut win, "125%");
    win.activate(win.button("Apply")).unwrap();
    assert_eq!(win.property(target, gpui::property::WIDTH).unwrap(), Length::Percent(125.0));
    assert_eq!(&**win.root().unwrap().editor.draft, "125%");
    for invalid in ["-1%", "NaN%", "inf%"] {
        draft(&mut win, invalid);
        win.activate(win.button("Apply")).unwrap();
        assert_eq!(win.property(target, gpui::property::WIDTH).unwrap(), Length::Percent(125.0));
        assert!(win.root().unwrap().editor.status.starts_with("Rejected:"));
    }
    draft(&mut win, "auto");
    win.activate(win.button("Apply")).unwrap();
    assert_eq!(win.contribution(target, gpui::property::WIDTH).unwrap(), Contribution::Set(Length::Auto));
    win.activate(win.button("Inherit")).unwrap();
    assert_eq!(win.property(target, gpui::property::WIDTH).unwrap(), Length::Points(120.0));
}
''';p.write_text(s)
