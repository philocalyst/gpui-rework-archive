from pathlib import Path
import re
root=Path('/root/gpui-length-port-sol-20261024/reactivity/crates')
for crate in ['gpui','component']:
 for base in ['src','tests','examples']:
  for p in (root/crate/base).rglob('*.rs'):
   s=p.read_text();old=s;ns='crate::Length' if base=='src' else 'gpui::Length'
   s=re.sub(r'(\.property\([^\n]*, (?:gpui::property::|crate::property::)?(?:WIDTH|HEIGHT)\)(?:\.unwrap\(\)|\?),\s*)Some\(',rf'\1{ns}::Points(',s)
   if s!=old:p.write_text(s)
p=root/'gpui/tests/rounded.rs';s=p.read_text();old='''assert_eq!(
        win.property(target, WIDTH).unwrap().unwrap().to_bits(),
        (-0.0_f32).to_bits()
    );''';new='''assert!(WIDTH.same_authoring(
        &win.property(target, WIDTH).unwrap(),
        &gpui::Length::Points(-0.0),
    ));''';assert old in s;s=s.replace(old,new);p.write_text(s)
p=root/'gpui/tests/style_ports.rs';s=p.read_text().replace('property(target, WIDTH).unwrap().unwrap()', 'property(target, WIDTH).unwrap()');s=s.replace('assert_eq!(actual.to_bits(), expected.to_bits(), "literal={literal}");','let Length::Points(actual) = actual else { panic!("point dimension") };\n                assert_eq!(actual.to_bits(), expected.to_bits(), "literal={literal}");');p.write_text(s)
