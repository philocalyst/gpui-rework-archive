from pathlib import Path
import re
root=Path('/root/gpui-length-port-sol-20261024/reactivity/crates')
changed=[]
for crate in ['gpui','component']:
 for base in ['src','tests','examples']:
  for p in (root/crate/base).rglob('*.rs'):
   s=p.read_text();old=s
   ns='crate::Length' if base=='src' else 'gpui::Length'
   s=s.replace('PropertyValue::Dimension(Some(',f'PropertyValue::Dimension({ns}::Points(')
   s=s.replace('PropertyValue::Dimension(None)',f'PropertyValue::Dimension({ns}::Auto)')
   # Assertions against the typed width/height selectors.
   s=re.sub(r'(\.property\([^\n]*, (?:WIDTH|HEIGHT)\)\.unwrap\(\),\s*)Some\(',rf'\1{ns}::Points(',s)
   s=re.sub(r'(\.property\([^\n]*, (?:WIDTH|HEIGHT)\)\.unwrap\(\),\s*)None\b',rf'\1{ns}::Auto',s)
   if p.name in ['inspector.rs','style_ports.rs','contracts.rs'] and base=='tests':
    s=s.replace('Contribution::Set(Some(',f'Contribution::Set({ns}::Points(').replace('Contribution::Set(None)',f'Contribution::Set({ns}::Auto)')
   if p.name=='property.rs' and base=='src':
    start=s.index('#[cfg(test)]\nmod tests')
    tests=s[start:].replace('Some(', 'Length::Points(')
    tests=re.sub(r'\bNone\b','Length::Auto',tests)
    # Already explicit erased dimension expressions were handled above.
    s=s[:start]+tests
   if p.name=='style_port.rs':
    s=s.replace('let style = (&signal).into_prop().signal().unwrap();','let input: PropInput<\'_, f64> = (&signal).into_prop();\n            let style = input.signal().unwrap();')
   if p.name=='element.rs':
    s=s.replace('nodes[0].style.width, Some(', 'nodes[0].style.width, crate::Length::Points(').replace('nodes[0].style.height, Some(', 'nodes[0].style.height, crate::Length::Points(')
   if p.name=='inspector.rs' and base=='src':
    s=s.replace('WIDTH.get(&node.style), Some(', 'WIDTH.get(&node.style), Length::Points(').replace('crate::property::HEIGHT.get(&node.style), Some(', 'crate::property::HEIGHT.get(&node.style), Length::Points(')
   if p.name in ['colours.rs','styles.rs'] and base=='src':
    s=re.sub(r'(\b(?:width|height): )Some\(',r'\1crate::Length::Points(',s)
   if p.name=='colours.rs': s=s.replace('use crate::{Affine, Align, Color, Flow, Justify};','use crate::{Affine, Align, Color, Flow, Justify, Length};')
   if s!=old:p.write_text(s);changed.append(str(p))
# The editor delegates dimension text syntax to Length's one parser/display pair.
for path in ['gpui/examples/support/value_entry.rs','gpui/examples/contained_owner_spike.rs']:
 p=root/path;s=p.read_text()
 s=s.replace('PropertyValue::Number(value) | PropertyValue::Dimension(crate::Length::Points(value))', 'PropertyValue::Number(value)')
 s=s.replace('PropertyValue::Number(value) | PropertyValue::Dimension(gpui::Length::Points(value))', 'PropertyValue::Number(value)')
 s=s.replace('PropertyValue::Dimension(gpui::Length::Auto) => "auto".into(),','PropertyValue::Dimension(value) => value.to_string(),')
 old='''PropertyValue::Dimension(_) => PropertyValue::Dimension(if source == "auto" {
                None
            } else {
                Some(scalar()?)
            }),'''
 new='''PropertyValue::Dimension(_) => PropertyValue::Dimension(
                source.parse().map_err(|_| "Expected auto, points or a percentage")?,
            ),'''
 assert old in s,path
 s=s.replace(old,new);p.write_text(s)
 if str(p) not in changed:changed.append(str(p))
Path('/tmp/gpui-length-changed-files.txt').write_text('\n'.join(changed)+'\n')
print('\n'.join(changed))
