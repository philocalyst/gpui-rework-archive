from pathlib import Path
import subprocess,hashlib,json,gzip
binutils=Path('/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin')
r={}
for kind,p in [('headless_release',Path('/root/targets/typed-length-port-sol-release-20261024/release/examples/halloween')),('native_dev',Path('/root/targets/typed-length-port-sol-native-20261024/debug/examples/halloween'))]:
 syms=subprocess.check_output([binutils/'nm','--demangle','--print-size','--size-sort',p],text=True)
 with gzip.open(f'/tmp/gpui-length-{kind}-symbols.txt.gz','wb') as f:f.write(syms.encode())
 sec={}
 for line in subprocess.check_output([binutils/'size','-A',p],text=True).splitlines():
  f=line.split()
  if len(f)==3 and f[0].startswith('.'):sec[f[0]]=int(f[1])
 comp=[s for s in syms.splitlines() if 'gpui_component::' in s and len(s.split())>=4 and s.split()[2] in ('t','T')]
 r[kind]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'elf_bytes':p.stat().st_size,'sections':sec,'component_named_text_symbols':len(comp),'component_named_text_bytes':sum(int(s.split()[1],16) for s in comp),'attribution_limit':'Named symbols exclude inlined code/shared helpers. Whole ELF charges the dependency closure. App changed from natural dimensions to relative fill, so deltas include that model change and are not an isolated compiler-cost benchmark.'}
base=json.loads(Path('/root/gpui-component-port-sol-20261024/reactivity/evidence/component-port-sol/codegen.json').read_text())
r['delta_from_natural_size_port']={kind:{'elf_bytes':r[kind]['elf_bytes']-base[kind]['elf_bytes'],'text_bytes':r[kind]['sections']['.text']-base[kind]['sections']['.text'],'rodata_bytes':r[kind]['sections']['.rodata']-base[kind]['sections']['.rodata']} for kind in base}
Path('/tmp/gpui-length-codegen.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:{name:v[name] for name in ['sha256','elf_bytes','component_named_text_symbols','component_named_text_bytes']} for k,v in r.items() if k!='delta_from_natural_size_port'},indent=2))
print(r['delta_from_natural_size_port'])
