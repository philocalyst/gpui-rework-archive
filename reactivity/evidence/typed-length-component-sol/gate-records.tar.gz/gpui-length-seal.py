from pathlib import Path
import subprocess,hashlib,json,shutil,tarfile
root=Path('/root/gpui-length-port-sol-20261024')
ev=root/'reactivity/evidence/typed-length-component-sol'
ev.mkdir(parents=True,exist_ok=False)
source=subprocess.check_output(['git','-c',f'safe.directory={root}','-C',str(root),'rev-parse','HEAD'],text=True).strip()
guard=json.loads(Path('/tmp/gpui-length-after-21.json').read_text())
assert guard['commit']==source and guard['aggregate']=='f204da313c244a0ede2b3d7536256d196c082919905926dbd82153f0a29effcd'
report=Path('/tmp/gpui-length-report.txt').read_text()
report=report.replace('The source/evidence seal receipts name the final commits and input aggregates.',f'Qualified source commit: {source}\nBuild-input aggregate: {guard["aggregate"]} (2078 files).\nAn evidence-only seal follows this source; it is not a compiled source commit.')
report=report.replace('The same Halloween Party model now gives its root size Percent(100)', 'The same Halloween Party model now gives its root size Percent(100)')
report=report.replace('S7/P7 and a further acknowledged resize at the same source epoch to960x700.', 'S9/P9, including default treats off/on and parent disabled state, and a further\nacknowledged resize at the same source epoch to960x700.')
report=report.replace('Ten optimized reusable component contracts\npass.', 'After the app dependency correction,11 optimized reusable component contracts\npass, with4 compile-fails rechecked.')
report=report.replace('one unused test value lint, and the old native parser-message expectation.', 'one unused test value lint, the old native parser-message expectation, and the\napp owner-dependency declaration bug described below.')
report=report.replace('measures955 allocations/316565 requested/89931 retained; retained bytes match the\nnatural-size fixture.', 'measures957 allocations/316629 requested/89995 retained. Correct owner\ndependencies add2 allocations/64 retained bytes versus the pre-correction model.')
report=report.replace('Whole optimized headless ELF9,955,192B (.text3,147,671B), +3,768 ELF/+2,432 text\nversus the natural-size port. Native dev(debug0) ELF71,204,880B (.text25,756,423B),\n+3,032 ELF/+2,640 text. Rodata sizes remain unchanged. Component-named text symbols\nare9,411B/27 release and20,930B/94 native', 'Whole optimized headless ELF9,955,488B (.text3,147,847B), +4,064 ELF/+2,608 text\nversus the natural-size port. Native dev(debug0) ELF71,207,120B (.text25,757,287B),\n+5,272 ELF/+3,504 text. Release rodata is64B smaller; native rodata is unchanged.\nComponent-named text symbols are8,983B/26 release and20,930B/94 native')
report+='''\nCorrection to the initial component seal\n\nThe source audit found that the initial Party/Preparation example declared\nordinary bool/validation/ready snapshot reads as direct/direct_component. That\ncontract explicitly promises those reads are absent. The custom lantern callback\nhappened to re-describe coarsely, masking stale default-treats and title-validation\npresentation. This composed seal supersedes those app declarations: Preparation\nuses field for both checked snapshots; Party uses field(TITLE) and\ncomponent(PREPARATION). Checkbox::toggle documents the snapshot seam. Core direct\npublication remains unchanged; there is no blanket re-description workaround.\nThe initial foundation/header tests still apply, but its app/cost qualification\nmust be read with this correction.\n\nOne ordinary external contract now exercises the reusable default Source toggle,\ncontrolled checked output, parent disabled policy, input replacement, validation\nhelp and recovery. Two bounded mutants independently reinstate the invalid\nchild/parent direct declarations and the invalid title direct declaration. Both\nrecompiled actual test executables and fail the intended public semantic\nassertion (checked state, then validation help). The correct source is restored\nbyte-for-byte before final gates. The receipts include source guards and distinct\nexecutable hashes; no test-only route bypass was used. Dependency storage is\ncharged: two existing owner_fields vectors retain32B each (+64B), no new header.\n\nThe final native disabled image exercises default-treats off and the disabled\nparent command; default-treats on restores readiness before finishing at S9/P9.\nEarlier pre-owner-correction captures are retained in gate records and do not\nsubstitute for this final flow. Full default660 was measured before this app\ncorrection; the final app's11 optimized contracts,4 compile-fails, clippy and\nactual native flow were then rerun. Shipping core code is unchanged by that fix.\n'''
(ev/'report.txt').write_text(report)
for src,dst in {'inventory-final.json':'shipping-inventory.json','codegen.json':'codegen.json','costs-final.log':'allocations.log','headless.json':'headless-semantics.json','halloween-headless.png':'headless.png','native-capture.json':'native-capture.json','native-run.log':'native-run.log','native-capture-final.py':'native-capture.py','native-property-final.py':'native-property-test.py','native-property-test-15.log':'native-property-test.log','owner-mutants.json':'owner-mutants.json','inputs.py':'input-guard.py','port-inputs.py':'port-input-guard.py','headless_release-symbols.txt.gz':'headless-symbols.txt.gz','native_dev-symbols.txt.gz':'native-symbols.txt.gz'}.items():shutil.copyfile('/tmp/gpui-length-'+src,ev/dst)
for name in ['draft','focus','disabled','ready','resized']:shutil.copyfile(f'/tmp/gpui-length-halloween-native-{name}.png',ev/f'native-{name}.png')
shutil.copyfile('/tmp/component-port-sol-toolchain.txt',ev/'toolchain.txt')
checks=[]
for kind in ['native','release']:
 rows=[json.loads(s) for s in Path(f'/tmp/gpui-length-{kind}-artifacts-21.jsonl').read_text().splitlines() if s.startswith('{')]
 assert rows[-1].get('reason')=='build-finished' and rows[-1]['success']
 artifacts=[{'package_id':r['package_id'],'target':r['target']['name'],'kind':r['target']['kind'],'fresh':r['fresh'],'executable':r.get('executable')} for r in rows if r.get('reason')=='compiler-artifact' and r['target']['name'] in ['gpui','gpui_component','halloween','costs']]
 assert all(a['fresh'] for a in artifacts)
 checks.append({'profile':kind,'artifacts':artifacts})
(ev/'cargo-freshness.json').write_text(json.dumps(checks,indent=2)+'\n')
with tarfile.open(ev/'gate-records.tar.gz','w:gz') as t:
 for p in sorted(Path('/tmp').glob('gpui-length-*')):
  if p.is_file() and p.suffix in ['.log','.json','.jsonl','.txt','.py','.rs']:t.add(p,arcname=p.name)
 for p in sorted(Path('/tmp/gpui-length-pre-owner-correction').iterdir()):t.add(p,arcname='pre-owner-correction/'+p.name)
archive=Path('/root/gpui-length-port-sol-artifacts-20261024');archive.mkdir(exist_ok=False)
a=archive/'qualified-executables.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for kind,path in [('release/halloween','/root/targets/typed-length-port-sol-release-20261024/release/examples/halloween'),('release/costs','/root/targets/typed-length-port-sol-release-20261024/release/examples/costs'),('native/halloween','/root/targets/typed-length-port-sol-native-20261024/debug/examples/halloween')]:t.add(path,arcname=kind)
(ev/'executable-archive.sha256').write_text(hashlib.sha256(a.read_bytes()).hexdigest()+'  '+str(a)+'\n')
stat=subprocess.check_output(['git','-c',f'safe.directory={root}','-C',str(root),'diff','0103a0e70ce7d5359a746693775d83b94064f862','--stat'],text=True)
(ev/'shipping-diff-stat.txt').write_text(stat)
(ev/'evidence.sha256').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in sorted(ev.iterdir()) if p.is_file() and p.name!='evidence.sha256'))
print(source,guard['aggregate'],len(list(ev.iterdir())))
