#!/usr/bin/env bash
set -euo pipefail
base=/home/miles/gpui-ce3-compute-20261024
exec 9>"$base/host.lock"
flock -s 9
source "$base/env.sh"
export PKG_CONFIG_PATH="$base/build-inputs/five-app/pkg-config"
export CARGO_TARGET_DIR="$base/targets/mapped-cost-sol"
export CARGO_BUILD_JOBS=2 CARGO_PROFILE_RELEASE_DEBUG=0
out="$base/evidence/gradient-paint-cost-sol-final-a2dd"
current="$base/src/mapped-cost-sol-shared/source"
pin=a2dd48e908d6bb5e999f5b613af3a82407353ee5
lane=gradientfinal
[[ ! -e "$current" ]]
free_kib=$(df --output=avail "$base" | tail -1)
(( free_kib > 9*1024*1024 )) || exit 90
mkdir "$current"
tar xzf "$out/source-a2dd.tar.gz" -C "$current"
find "$current/reactivity/crates/gpui" "$current/reactivity/crates/canvas" "$current/reactivity/crates/gpu" -name '*.rs' -exec touch {} +
manifest() { (cd "$current" && find . -type f -print0 | sort -z | xargs -0 sha256sum); }
echo "$pin" > "$out/$lane.pin"
manifest > "$out/$lane-source-before.sha256"
cd "$current/reactivity"
cargo clean --release -p gpui_gpu > "$out/$lane-gpu-clean.log" 2>&1
for example in counter gradient_backgrounds; do
 label="$lane-$example"
 set +e
 cargo build --offline --locked --release -p gpui --example "$example" --features x11 --message-format=json > "$out/$label-build.jsonl" 2> "$out/$label-build.log"
 status=$?
 set -e
 echo "$status" > "$out/$label-build.exit"
 [[ $status == 0 ]] || exit "$status"
 cp "$CARGO_TARGET_DIR/release/examples/$example" "$out/$label.elf"
 python3 "$out/assert-wgsl.py" "$out/$label-build.jsonl" "$out/$label.elf" "$out/$label.wgsl" "$lane"
done
manifest > "$out/$lane-source-after.sha256"
cmp "$out/$lane-source-before.sha256" "$out/$lane-source-after.sha256"
cd "$base"
mv "$current" "$base/src/mapped-cost-sol-shared/frozen/gradient-cost-$pin"
sha256sum "$out/"*.elf "$out/"*.wgsl > "$out/artifacts.sha256"
rustc -vV > "$out/rustc.txt"
cargo -V > "$out/cargo.txt"
df -B1 "$base" > "$out/disk.txt"
free_kib=$(df --output=avail "$base" | tail -1)
(( free_kib > 8*1024*1024 )) || exit 91
echo COMPLETE > "$out/build.complete"
