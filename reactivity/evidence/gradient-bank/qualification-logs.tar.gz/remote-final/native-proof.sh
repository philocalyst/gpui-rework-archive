#!/usr/bin/env bash
set -euo pipefail
source /tmp/gpui-native-env.sh
out=/tmp/gpui-gradient-bank-sol-evidence/remote-final
elf="$out/gradientfinal-gradient_backgrounds.elf"
sha256sum "$elf" > "$out/native-elf-before.sha256"
/nix/store/iw8dx6lhrkdc5wzszjzqzl677y68y88r-xvfb-21.1.24/bin/Xvfb -displayfd 3 -screen 0 800x600x24 -nolisten tcp 3> "$out/xvfb.ready" > "$out/xvfb.log" 2>&1 &
xpid=$!
trap 'kill "$xpid" 2>/dev/null || true; wait "$xpid" 2>/dev/null || true' EXIT
for _ in $(seq 1 80); do [[ ! -s "$out/xvfb.ready" ]] || break;sleep 0.05;done
[[ -s "$out/xvfb.ready" ]]
export DISPLAY=":$(cat "$out/xvfb.ready")"
for mode in cpu gpu; do
 set +e
 timeout 30s "$elf" "--$mode" --proof > "$out/native-$mode.log" 2>&1
 code=$?
 set -e
 echo "$code" > "$out/native-$mode.exit"
done
sha256sum "$elf" > "$out/native-elf-after.sha256"
cmp "$out/native-elf-before.sha256" "$out/native-elf-after.sha256"
