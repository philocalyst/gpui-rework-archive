import json,pathlib,sys,hashlib
records=[json.loads(line) for line in pathlib.Path(sys.argv[1]).read_text().splitlines()]
paths=[pathlib.Path(r['out_dir'])/'ui.wgsl' for r in records if r.get('reason')=='build-script-executed' and 'gpui_gpu' in r.get('package_id','')]
assert paths, 'missing actual gpui_gpu build-script output'
source=paths[-1].read_bytes()
assert (b'gradient_color' in source)==sys.argv[4].startswith('gradient'),(paths[-1],sys.argv[4])
elf=pathlib.Path(sys.argv[2]).read_bytes()
assert elf.count(source)>=1, 'actual generated WGSL must be embedded in this linked ELF'
start=pathlib.Path(sys.argv[1]).parent/(sys.argv[4]+'-source-before.sha256')
assert paths[-1].stat().st_mtime_ns>=start.stat().st_mtime_ns,'generated WGSL predates lane source guard'
pathlib.Path(sys.argv[3]).write_bytes(source)
pathlib.Path(sys.argv[3]+'.json').write_text(json.dumps({'build_script_output':str(paths[-1]),'sha256':hashlib.sha256(source).hexdigest(),'elf_embedded_count':elf.count(source),'gradient':b'gradient_color' in source,'generated_mtime_ns':paths[-1].stat().st_mtime_ns,'lane_guard_mtime_ns':start.stat().st_mtime_ns},indent=2))
