#!/usr/bin/env bash
set -euo pipefail
source /tmp/gpui-native-env.sh
source /tmp/gpui-nightly-env.sh
export CARGO_TARGET_DIR=/tmp/gpui-gradient-paint-sol-target CARGO_BUILD_JOBS=2 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_DEV_DEBUG=0
src=/tmp/gpui-gradient-bank-sol
out=/tmp/gpui-gradient-bank-sol-evidence
py=/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3
cd "$src"
git diff --exit-code HEAD
git rev-parse HEAD > "$out/qualified-pin.txt"
"$py" "$out/sourceguard.py" "$src" > "$out/source-before.json"
rustc -vV > "$out/rustc.txt"
cargo -V > "$out/cargo.txt"
run() { local label=$1;shift; set +e; "$@" > "$out/$label.log" 2>&1; local status=$?;set -e;echo "$status" > "$out/$label.exit";return "$status"; }
run default cargo test --no-fail-fast --locked --manifest-path reactivity/Cargo.toml -p gpui_canvas -p gpui
run gpu cargo test --locked --manifest-path reactivity/Cargo.toml -p gpui_gpu --features vulkan-tests
run scalar cargo test --locked --manifest-path reactivity/Cargo.toml -p gpui_canvas --no-default-features --test gradients
run strict cargo clippy --locked --manifest-path reactivity/Cargo.toml -p gpui_canvas -p gpui -p gpui_gpu --all-targets -- -D warnings
"$py" "$out/sourceguard.py" "$src" > "$out/source-after.json"
cmp "$out/source-before.json" "$out/source-after.json"
git diff --exit-code HEAD
