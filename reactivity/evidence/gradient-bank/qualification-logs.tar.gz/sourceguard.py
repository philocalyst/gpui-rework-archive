import hashlib,pathlib,subprocess,sys,json
root=pathlib.Path(sys.argv[1])
paths=subprocess.check_output(['git','ls-files','-z','reactivity/crates','reactivity/vendor','reactivity/Cargo.toml','reactivity/Cargo.lock','reactivity/.cargo'],cwd=root).split(b'\0')
result={p.decode():hashlib.sha256((root/p.decode()).read_bytes()).hexdigest() for p in paths if p}
print(json.dumps(result,sort_keys=True,indent=2))
