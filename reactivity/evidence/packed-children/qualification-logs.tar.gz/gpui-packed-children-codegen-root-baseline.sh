set -euo pipefail
source /tmp/gpui-native-env.sh
source /tmp/gpui-nightly-env.sh
export CARGO_TARGET_DIR=/tmp/gpui-packed-children-codegen-root-target
export CARGO_BUILD_JOBS=2
py=/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3
"$py" /root/gpui-ce3/reactivity/evidence/clipping-gradients-integration/gpui-run-frozen-gate-root.py --source /tmp/gpui-component-scope-root --pin 8f0b9725ddf7ab71edc0f390f0ce57f527cd0638 --timeout 1800 --scope .cargo --scope clippy.toml --scope reactivity/Cargo.toml --scope reactivity/Cargo.lock --scope reactivity/rust-toolchain.toml --scope reactivity/crates --scope reactivity/vendor --out /tmp/gpui-packed-children-codegen-root-baseline-build -- cargo build --manifest-path reactivity/Cargo.toml --locked --offline -p gpui --release --example counter --message-format=json
