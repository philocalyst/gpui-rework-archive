from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('label', choices=['baseline', 'candidate'])
parser.add_argument('--pin', required=True)
args = parser.parse_args()
prefix = Path('/tmp/gpui-packed-children-codegen-root-' + args.label)
build = Path(str(prefix) + '-build')
out = Path(str(prefix) + '-artifacts')
out.mkdir(exist_ok=False)
report = json.loads((build / 'result.json').read_text())
assert report['source'] == args.pin and report['exit'] == 0 and report['guards_match']
rows = [json.loads(line) for line in (build / 'stdout.log').read_text().splitlines()]
matches = [row for row in rows if row.get('reason') == 'compiler-artifact'
           and row.get('executable') and row['target']['name'] == 'counter']
assert len(matches) == 1 and not matches[0]['fresh'], matches
row = matches[0]
original = Path(row['executable'])
binary = out / 'counter.elf'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
before = sha(original)
if original.stat().st_nlink == 1:
    original.rename(binary)
    method = 'atomic rename of uniquely linked executable'
else:
    with original.open('rb') as source, binary.open('xb') as target:
        shutil.copyfileobj(source, target)
    method = 'independent exclusive copy of multiply linked executable'
binary.chmod(0o555)
assert sha(binary) == before and binary.stat().st_nlink == 1
identity = {'source': args.pin, 'cargo': row, 'path': str(binary), 'sha256': before,
            'bytes': binary.stat().st_size, 'freeze_method': method}
(out / 'binary.json').write_text(json.dumps(identity, indent=2) + '\n')
run = subprocess.run([str(binary)], capture_output=True, timeout=90)
(out / 'stdout.log').write_bytes(run.stdout)
(out / 'stderr.log').write_bytes(run.stderr)
assert run.returncode == 0
tools = Path('/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin')
nm = subprocess.check_output([str(tools / 'nm'), '-S', '-C', '--size-sort', str(binary)], text=True)
(out / 'symbols.txt').write_text(nm)
sizes = subprocess.check_output([str(tools / 'size'), '-A', '-d', str(binary)], text=True)
(out / 'sections.txt').write_text(sizes)
sections = {}
for line in sizes.splitlines():
    fields = line.split()
    if len(fields) == 3 and fields[0].startswith('.') and fields[1].isdigit():
        sections[fields[0]] = int(fields[1])
selected = []
for line in nm.splitlines():
    match = re.fullmatch(r'([0-9a-f]+)\s+([0-9a-f]+)\s+([tT])\s+(.+)', line)
    if not match:
        continue
    name = match[4]
    if any(term in name for term in ['counter::Counter', '::describe_inner',
                                     'El::append_children', '::shape_mode']):
        selected.append({'name': name, 'address': match[1], 'bytes': int(match[2], 16)})
plain = out / 'assembly.txt'
with plain.open('wb') as stream:
    subprocess.run([str(tools / 'objdump'), '-Cd', str(binary)], stdout=stream, check=True)
with plain.open('rb') as source, gzip.open(out / 'assembly.txt.gz', 'wb') as target:
    shutil.copyfileobj(source, target)
plain.unlink()
assert sha(binary) == before
result = {'source': args.pin, 'identity': identity, 'sections': sections,
          'selected_symbols': selected, 'exit': run.returncode,
          'stdout_sha256': sha(out / 'stdout.log'), 'sha256_matches_after': True,
          'scope': 'Optimized headless SIMD Counter executable and complete x86 disassembly; no native startup, RSS or CPU timing claim.'}
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'label': args.label, 'bytes': identity['bytes'], 'text': sections['.text'],
                  'selected_symbol_count': len(selected)}))
