set -euo pipefail
source /tmp/gpui-native-env.sh
source /tmp/gpui-nightly-env.sh
export VK_DRIVER_FILES=/nix/store/dv3gad7cjnnnzbfsv7jslvj9fmn5420j-mesa-26.1.4/share/vulkan/icd.d/lvp_icd.x86_64.json
py=/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3
"$py" /root/gpui-ce3/reactivity/evidence/clipping-gradients-integration/gpui-run-frozen-gate-root.py --source /tmp/gpui-packed-nodes-compose-root --pin ce79d00fb004859994c8574254bbd091e964a2d4 --timeout 600 --scope .cargo --scope clippy.toml --scope reactivity/Cargo.toml --scope reactivity/Cargo.lock --scope reactivity/rust-toolchain.toml --scope reactivity/crates --scope reactivity/vendor --out /tmp/gpui-packed-children-root-wire-guard -- "$py" /tmp/gpui-packed-children-root-native-wire.py
"$py" /tmp/gpui-packed-children-root-shader-audit.py
