from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import tarfile

source = 'ce79d00fb004859994c8574254bbd091e964a2d4'
root = Path('/tmp/gpui-packed-nodes-compose-root')
out = Path('/tmp/gpui-packed-children-root-handoff')
out.mkdir(exist_ok=False)
load = lambda path: json.loads(Path(path).read_text())
sha = lambda data: hashlib.sha256(data).hexdigest()
gates = {}
for suffix in ['clean', 'build', 'execute-guard', 'strict', 'docs', 'scalar',
               'wire-guard', 'probe-guard', 'hummingbird-clean', 'hummingbird-build',
               'hummingbird-execute']:
    report = load('/tmp/gpui-packed-children-root-' + suffix + '/result.json')
    assert report['source'] == source and report['exit'] == 0 and report['guards_match']
    gates[suffix] = report
functional = load('/tmp/gpui-packed-children-root-artifacts/result.json')
assert functional['all_exit_zero'] and functional['passed'] == 712 and functional['harnesses'] == 70
assert gates['docs']['passed'] == 28 and gates['scalar']['passed'] == 194
port = load('/tmp/gpui-packed-children-root-hummingbird-artifacts/result.json')
assert port['all_exit_zero'] and port['passed'] == 70 and port['harnesses'] == 18
native = load('/tmp/gpui-packed-children-root-wire/native-execute/result.json')
assert native['all_exit_zero'] and native['passed'] == 2
frontier = load('/tmp/gpui-packed-children-root-probe/result.json')
assert frontier['exact_public_artifacts'] == 120
children = load('/tmp/gpui-child-capacity-root-probe/result.json')
assert children['source'] == source and len(children['rows']) == 14
mutant = load('/tmp/gpui-child-sizing-mutant-root/result.json')
assert mutant['expected_semantic_failure'] and mutant['one_test_entered']
restored = load('/tmp/gpui-child-sizing-mutant-root/restored.json')
assert restored['source'] == source and restored['all_hashes_match']
shader = load('/tmp/gpui-packed-children-root-shader-audit/result.json')
assert shader['source'] == source and len(shader['spirv']) == 8 and len(shader['elfs']) == 1
codegen = load('/tmp/gpui-packed-children-codegen-root-comparison/result.json')
assert codegen['candidate_gpui_rebuilt'] and codegen['headless_counter_stdout_exact']
assert codegen['whole_elf_bytes']['delta'] == 928 and codegen['section_deltas']['.text'] == 1440
core = load('/tmp/gpui-packed-children-root-core-lines.json')
assert core['source_commit'] == source and core['core_non_test_code_lines'] == 34852
guard = load('/tmp/gpui-packed-children-root-hummingbird-build/before.json')
assert len(guard) == 2781
for path, digest in guard.items():
    assert sha((root / path).read_bytes()) == digest, path
producer = Path('/tmp/gpui-component-routing-sol-c9-evidence-v2.tar.gz')
assert sha(producer.read_bytes()) == '6523f9e8e4faf74c83e2859b1aadf29baec4fb068b93d0a3cb726ed5cd519dac'
external = {'isolated_route_producer': {'path': str(producer), 'bytes': producer.stat().st_size,
             'sha256': sha(producer.read_bytes()), 'source': 'c9d3f13ece29faff315e2ff95976123f87c1f1ab'},
            'optimized_executables_and_full_assembly': {}}
for label in ['baseline', 'candidate']:
    folder = Path('/tmp/gpui-packed-children-codegen-root-' + label + '-artifacts')
    external['optimized_executables_and_full_assembly'][label] = {
        path.name: {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())}
        for path in folder.iterdir() if path.name in ['counter.elf', 'assembly.txt.gz']}
summary = {'source': source, 'previous_main': 'f2874c35fc914e9002425112be5ebf8aa9717b16',
           'gates': gates, 'gpui': {k:v for k,v in functional.items() if k != 'results'},
           'hummingbird': {k:v for k,v in port.items() if k != 'results'}, 'native': native,
           'exact_public_artifacts': 120, 'child_census_shapes': 14,
           'shipping_non_test_non_comment_code_lines': 34852, 'core_delta_vs_main': 155,
           'scope': 'Actual functional, identity, allocation and optimized machine-code qualification. Counts overlap; no timing, RSS, startup or hardware-GPU improvement is claimed.'}
for name, data in [('qualification.json', summary), ('scene-allocations.json', frontier),
                   ('child-allocations.json', children), ('machine-code.json', codegen),
                   ('external-artifacts.json', external)]:
    (out / name).write_text(json.dumps(data, indent=2) + '\n')
(out / 'core-lines.json.gz').write_bytes(gzip.compress(json.dumps(core, indent=2).encode(), mtime=0))
(out / 'qualified-inputs.json.gz').write_bytes(gzip.compress(json.dumps(guard, indent=2).encode(), mtime=0))
git = ['git', '-c', f'safe.directory={root}', '-C', str(root)]
(out / 'production-and-tests.patch').write_bytes(subprocess.check_output(git + [
    'diff', '--binary', 'f2874c35fc914e9002425112be5ebf8aa9717b16', source, '--', 'reactivity/crates/gpui']))
roots = [Path('/tmp/gpui-packed-children-root-' + suffix) for suffix in
         ['clean', 'build', 'execute-guard', 'artifacts', 'strict', 'docs', 'scalar', 'wire',
          'wire-guard', 'probe', 'probe-guard', 'shader-audit', 'hummingbird-clean',
          'hummingbird-build', 'hummingbird-execute', 'hummingbird-artifacts']]
roots += [Path('/tmp/gpui-child-capacity-root-' + suffix) for suffix in
          ['baseline-build', 'baseline-execute', 'baseline-artifacts', 'baseline-probe',
           'clean', 'build', 'execute', 'artifacts', 'probe']]
roots += [Path('/tmp/gpui-child-sizing-mutant-root')]
roots += [Path('/tmp/gpui-packed-children-codegen-root-' + suffix) for suffix in
          ['baseline-build', 'baseline-artifacts', 'candidate-build', 'candidate-artifacts',
           'candidate-clean', 'candidate-release-clean', 'candidate-unqualified-build',
           'candidate-unqualified-artifacts', 'candidate-unqualified-two-build',
           'candidate-unqualified-two-artifacts', 'comparison']]
paths = []
for folder in roots:
    assert folder.is_dir(), folder
    paths += [path for path in folder.rglob('*') if path.is_file() and path.suffix in
              ['.json', '.txt', '.log', '.wgsl', '.spv', '.patch', '.hits', '.rgba', '.rs']]
producer_root = Path('/tmp/gpui-component-routing-sol-c9-evidence')
paths += [producer_root / name for name in ['REPORT.txt', 'manifest.json', 'actual-elf-index.json']]
for path in (producer_root / 'files').rglob('*'):
    if path.is_file() and any(part in str(path) for part in
            ['gpui-handler-drop-order-sol', 'gpui-handler-mutant-sol', 'gpui-handler-owner-mutant-sol']):
        paths.append(path)
names = ['gpui-packed-children-root-' + suffix for suffix in
         ['gates.sh', 'hummingbird.sh', 'native-wire.py', 'shader-audit.py', 'wire-run.sh', 'probe.py', 'package.py']]
names += ['gpui-child-capacity-root-focused.sh', 'gpui-child-sizing-mutant-root-run.py']
names += ['gpui-packed-children-codegen-root-' + suffix for suffix in
          ['baseline.sh', 'candidate.sh', 'candidate-fresh.sh', 'candidate-release-fresh.sh',
           'freeze.py', 'candidate.stderr.log', 'candidate-fresh.stderr.log',
           'candidate-unqualified.json', 'candidate-unqualified-two.json']]
paths += [Path('/tmp') / name for name in names]
manifest = {}
archive = out / 'qualification-logs.tar.gz'
with tarfile.open(archive, 'w:gz', compresslevel=6) as tar:
    for path in sorted(set(paths)):
        assert path.is_file(), path
        name = str(path.relative_to('/tmp'))
        data = path.read_bytes()
        manifest[name] = {'bytes': len(data), 'sha256': sha(data)}
        tar.add(path, arcname=name, recursive=False)
with tarfile.open(archive, 'r:gz') as tar:
    for member in tar:
        assert sha(tar.extractfile(member).read()) == manifest[member.name]['sha256']
(out / 'archive-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(out / 'archive-receipt.json').write_text(json.dumps({'sha256': sha(archive.read_bytes()),
    'bytes': archive.stat().st_size, 'members': len(manifest), 'all_payload_hashes_reverified': True,
    'scope': 'Commands, source guards, logs, ELF identities, shaders, public outputs and focused disassembly. Large executable/full-disassembly payloads remain at hashed external paths.'}, indent=2) + '\n')
print(json.dumps({'members': len(manifest), 'archive_bytes': archive.stat().st_size}))
