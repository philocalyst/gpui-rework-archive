set -euo pipefail
source /tmp/gpui-native-env.sh
source /tmp/gpui-nightly-env.sh
unset DISPLAY
export CARGO_TARGET_DIR=/tmp/gpui-hummingbird-compose-root-target
export CARGO_BUILD_JOBS=2
py=/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3
base=("$py" /root/gpui-ce3/reactivity/evidence/clipping-gradients-integration/gpui-run-frozen-gate-root.py
  --source /tmp/gpui-packed-nodes-compose-root --pin ce79d00fb004859994c8574254bbd091e964a2d4 --timeout 2400
  --scope .cargo --scope clippy.toml --scope reactivity/Cargo.toml --scope reactivity/Cargo.lock
  --scope reactivity/rust-toolchain.toml --scope reactivity/crates --scope reactivity/vendor
  --scope reactivity/ports/hummingbird)
"${base[@]}" --out /tmp/gpui-packed-children-root-hummingbird-clean -- cargo clean --manifest-path reactivity/Cargo.toml --locked --offline -p gpui
"${base[@]}" --out /tmp/gpui-packed-children-root-hummingbird-build -- cargo test --manifest-path reactivity/ports/hummingbird/Cargo.toml --locked --offline --lib --tests --no-run --message-format=json
"${base[@]}" --out /tmp/gpui-packed-children-root-hummingbird-execute -- "$py" /tmp/gpui-run-moved-test-artifacts-root.py --build /tmp/gpui-packed-children-root-hummingbird-build --out /tmp/gpui-packed-children-root-hummingbird-artifacts --per-binary-seconds 300
