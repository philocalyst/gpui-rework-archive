set -euo pipefail
source /tmp/gpui-native-env.sh
source /tmp/gpui-nightly-env.sh
unset DISPLAY
export CARGO_TARGET_DIR=/tmp/gpui-hummingbird-compose-root-target
export CARGO_BUILD_JOBS=2
export GPUI_SPIRV_VAL=/nix/store/z5hs3p3inrq3w8cv71jycz7l4y3ny5xk-spirv-tools-1.4.363.0/bin/spirv-val
export XDG_RUNTIME_DIR=/tmp/gpui-frontier-text-compose-root-runtime
py=/nix/store/9r02ykx9y35lf4gk6gc30gnag1y8ncp7-python3-3.13.15/bin/python3
base=("$py" /root/gpui-ce3/reactivity/evidence/clipping-gradients-integration/gpui-run-frozen-gate-root.py
  --source /tmp/gpui-packed-nodes-compose-root --pin ce79d00fb004859994c8574254bbd091e964a2d4 --timeout 2400
  --scope .cargo --scope clippy.toml --scope reactivity/Cargo.toml --scope reactivity/Cargo.lock
  --scope reactivity/rust-toolchain.toml --scope reactivity/crates --scope reactivity/vendor)
"${base[@]}" --out /tmp/gpui-child-capacity-root-clean -- cargo clean --manifest-path reactivity/Cargo.toml --locked --offline -p gpui
"${base[@]}" --out /tmp/gpui-child-capacity-root-build -- cargo test --manifest-path reactivity/Cargo.toml --locked --offline -p gpui --no-default-features --test child_capacity --test handler_storage --test frontier --test components --no-run --message-format=json
"${base[@]}" --out /tmp/gpui-child-capacity-root-execute -- "$py" /tmp/gpui-run-moved-test-artifacts-root.py --build /tmp/gpui-child-capacity-root-build --out /tmp/gpui-child-capacity-root-artifacts --per-binary-seconds 300
