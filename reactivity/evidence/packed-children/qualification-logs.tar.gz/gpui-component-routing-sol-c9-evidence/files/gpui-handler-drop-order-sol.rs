use gpui::{prelude::*, Error, Win};
use std::sync::{Arc, Mutex};
struct Probe { generation: u8, index: usize, log: Arc<Mutex<Vec<(u8,usize)>>> }
impl Drop for Probe {
 fn drop(&mut self) {
  self.log.lock().unwrap().push((self.generation,self.index));
  assert!(!(self.generation==0 && self.index==1),"route destructor");
 }
}
struct Owner { generation: u8, log: Arc<Mutex<Vec<(u8,usize)>>> }
impl View for Owner {
 fn view(&self) -> El<'_> {
  column((0..4).map(|index|{
   let probe=Probe{generation:self.generation,index,log:self.log.clone()};
   div().size(1).on_click(move |_:&mut Self|{std::hint::black_box(&probe);})
  }))
 }
}
fn main() {
 let log=Arc::new(Mutex::new(Vec::new()));
 let mut win=Win::demo(Owner{generation:0,log:log.clone()});
 assert_eq!(win.update(|m|m.generation=1),Err(Error::OwnerPanicked));
 println!("ORDER {:?}",log.lock().unwrap());
 win.close();
}
