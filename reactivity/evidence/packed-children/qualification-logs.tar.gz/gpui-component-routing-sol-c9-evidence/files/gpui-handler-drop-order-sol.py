from pathlib import Path
import json,hashlib,subprocess
out=Path('/tmp/gpui-handler-drop-order-sol');out.mkdir(exist_ok=False)
source=Path('/tmp/gpui-handler-drop-order-sol.rs');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,build in [('baseline',Path('/tmp/gpui-handler-baseline-sol-build2')),('candidate',Path('/tmp/gpui-component-routing-sol-final-build'))]:
 rows=[json.loads(l) for l in (build/'stdout.log').read_text().splitlines()]
 artifacts=[r for r in rows if r.get('reason')=='compiler-artifact']
 def library(name):
  matches=[r for r in artifacts if r['target']['name']==name and r['target']['kind']==['lib'] and not r['profile']['test']]
  assert len(matches)==1,(name,len(matches))
  paths=[Path(f) for f in matches[0]['filenames'] if f.endswith('.rlib')];assert len(paths)==1
  return paths[0]
 gpui,allocator=library('gpui'),library('allocation_counter')
 deps=sorted({str(Path(f).parent) for r in artifacts for f in r['filenames']})
 binary=out/label
 cmd=['/tmp/gpui-nightly-2026-10-23/bin/rustc','--edition=2024','-C','symbol-mangling-version=v0',str(source),'--extern',f'gpui={gpui.with_suffix(".rmeta")}','--extern',f'allocation_counter={allocator.with_suffix(".rmeta")}']
 for dep in deps:cmd+=['-L',f'dependency={dep}']
 cmd+=['--extern',f'gpui={gpui}','--extern',f'allocation_counter={allocator}','-o',str(binary)]
 r=subprocess.run(cmd,capture_output=True,text=True);(out/f'{label}-compile.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
 with (out/f'{label}.log').open('w') as f:r=subprocess.run([str(binary)],stdout=f,stderr=subprocess.STDOUT,timeout=180)
 assert r.returncode==0
 (out/f'{label}.json').write_text(json.dumps({'build_source':json.loads((build/'result.json').read_text())['source'],'fixture_sha256':sha(source),'gpui_rlib':str(gpui),'gpui_rlib_sha256':sha(gpui),'allocator_rlib_sha256':sha(allocator),'elf_sha256':sha(binary),'elf_bytes':binary.stat().st_size,'exit':r.returncode,'command':cmd},indent=2))
 print(label,(out/f'{label}.log').read_text())
