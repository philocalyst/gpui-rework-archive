from pathlib import Path
import hashlib,json,os,shutil,subprocess,sys
root=Path('/tmp/gpui-a11y-action-poll-root');cap=Path('/tmp/gpui-a11y-action-poll-captures')
source=root/'reactivity/crates/gpui/src/native.rs';original=source.read_bytes()
environment=dict(os.environ,CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/tmp/gpui-a11y-action-poll-target')
environment.pop('RUSTFLAGS',None);environment.pop('CARGO_ENCODED_RUSTFLAGS',None)
start=original.index(b'    #[cfg(feature = "accessibility")]\n    fn accessibility_work(')
end=original.index(b'    fn key_input(',start)
fault=b'''    #[cfg(feature = "accessibility")]
    fn accessibility_work(&mut self) -> Result<(), NativeError> {
        let mut results: [Option<Result<Commit, Error>>; accessibility::APPLY_BUDGET] =
            std::array::from_fn(|_| None);
        let mut full = true;
        for result in &mut results {
            let action = match (&mut self.accessibility, &mut self.owner) {
                (Some(bridge), Some(owner)) => bridge.poll(owner),
                _ => return Ok(()),
            };
            match action {
                Ok(accessibility::ActionPoll::Empty) => { full = false; break; }
                Ok(accessibility::ActionPoll::Discarded) => {}
                Ok(accessibility::ActionPoll::Applied(applied)) => *result = Some(applied),
                Err(error) => { self.accessibility = None; return Err(error); }
            }
        }
        if full && let Some(bridge) = &self.accessibility { bridge.rearm(); }
        for result in results.into_iter().flatten() { self.input_result(result)?; }
        Ok(())
    }
'''
fault_source=original[:start]+fault+original[end:]
negative=cap/'batch-fault';negative.mkdir()
(negative/'normal-native.rs').write_bytes(original)
(negative/'batch-fault-native.rs').write_bytes(fault_source)
def build(label):
    with (cap/(label+'-build.log')).open('w') as log:
        subprocess.run(['cargo','test','--offline','--locked','-p','gpui','--features','x11','--lib','native::accessibility','--no-run'],cwd=root/'reactivity',env=environment,stdout=log,stderr=subprocess.STDOUT,check=True)
def freeze(label):
    path=Path('/tmp/gpui-a11y-action-poll-target/debug/deps/gpui-e5c9359d761e98c0')
    dest=cap/'binaries'/label;shutil.copy2(path,dest);dest.chmod(0o555)
    return {'path':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
try:
    source.write_bytes(fault_source)
    (negative/'fault.patch').write_bytes(subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),'diff','--',str(source)]))
    build('batch-fault');binary=freeze('batch-fault')
    result=subprocess.run([sys.executable,'/tmp/gpui-a11y-action-poll-run.py','native-batch-negative'],env=environment)
    assert result.returncode != 0
    log=(cap/'native-batch-negative/stderr.log').read_text()
    assert 'the command after a fatal action must remain unconsumed' in log and 'Empty' in log
    (negative/'result.json').write_text(json.dumps({'expected_failure':True,'assertion':'fatal action must leave the following command unconsumed','binary':binary},indent=2)+'\n')
finally:
    source.write_bytes(original)
assert source.read_bytes()==original
build('restored');binary=freeze('restored')
subprocess.run([sys.executable,'/tmp/gpui-a11y-action-poll-run.py','native-restored'],env=environment,check=True)
with (cap/'native-full-lib.log').open('w') as log:
    subprocess.run([binary['path'],'--test-threads=1'],stdout=log,stderr=subprocess.STDOUT,env=environment,check=True)
assert source.read_bytes()==original
(cap/'restoration.json').write_text(json.dumps({'source_sha256':hashlib.sha256(original).hexdigest(),'binary':binary,'full_native_lib':True},indent=2)+'\n')
print('NEGATIVE DETECTED; EXACT SOURCE RESTORED; NATIVE AND LIB PASS',flush=True)
