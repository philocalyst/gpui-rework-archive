from pathlib import Path
import hashlib,json,os,subprocess
root=Path('/tmp/gpui-a11y-owner-channel-control-sol');out=Path('/tmp/gpui-a11y-action-poll-cross');out.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),*args])
assert not git('status','--porcelain')
paths=['reactivity/crates/gpui/src/native.rs','reactivity/crates/gpui/src/native/accessibility.rs']
original={p:(root/p).read_bytes() for p in paths}
wanted={p:git('show','5b4a2d7fc792a4e9929589eaf4c0ac94f144de39:'+p) for p in paths}
env=dict(os.environ,CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/tmp/gpui-a11y-owner-channel-target',RUSTC_BOOTSTRAP='1')
env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
record={'source':'5b4a2d7fc792a4e9929589eaf4c0ac94f144de39','scope':'installed-source foreign compile checks, no foreign runtime claim','source_sha256':{p:hashlib.sha256(v).hexdigest() for p,v in wanted.items()},'targets':{}}
try:
    for p,v in wanted.items():(root/p).write_bytes(v)
    for target in ['aarch64-apple-darwin','x86_64-pc-windows-msvc']:
        args=['cargo','check','--offline','--locked','-Z','build-std=std,panic_abort','--target',target,'-p','gpui','--features','native','--lib','--message-format=json']
        with (out/(target+'.jsonl')).open('w') as stdout,(out/(target+'.log')).open('w') as stderr:
            subprocess.run(args,cwd=root/'reactivity',env=env,stdout=stdout,stderr=stderr,check=True)
        assert all((root/p).read_bytes()==v for p,v in wanted.items())
        rows=[]
        for fp in (Path(env['CARGO_TARGET_DIR'])/target/'debug/.fingerprint').glob('gpui-*/lib-gpui.json'):
            d=json.loads(fp.read_text());rows.append({'path':str(fp),'features':d['features'],'rustflags':d['rustflags']})
        record['targets'][target]={'args':args,'status':0,'fingerprints':rows}
        (out/'metadata.json').write_text(json.dumps(record,indent=2)+'\n');print(target,'PASS',flush=True)
finally:
    for p,v in original.items():(root/p).write_bytes(v)
    assert all((root/p).read_bytes()==v for p,v in original.items())
    record['restored_status']=git('status','--porcelain').decode()
    (out/'metadata.json').write_text(json.dumps(record,indent=2)+'\n')
assert not record['restored_status'];print('RESTORED',flush=True)
