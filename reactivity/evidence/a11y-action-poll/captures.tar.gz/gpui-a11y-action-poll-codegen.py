from pathlib import Path
import hashlib, importlib.util, json, os, shutil, subprocess

root=Path('/tmp/gpui-a11y-owner-channel-control-sol')
source=Path('/tmp/gpui-a11y-action-poll-root')
out=Path('/tmp/gpui-a11y-action-poll-codegen');out.mkdir(exist_ok=False)
config=Path('/tmp/gpui-a11y-owner-channel-captures/support/stack-metadata.toml')
spec=importlib.util.spec_from_file_location('elf','/tmp/gpui-a11y-owner-channel-captures/support/elf.py')
elf=importlib.util.module_from_spec(spec);spec.loader.exec_module(elf)
def git(*args):
    return subprocess.check_output(['git','-c','safe.directory='+str(root),'-C',str(root),*args])
def sha(data):return hashlib.sha256(data).hexdigest()
assert not git('status','--porcelain')
paths=['reactivity/crates/gpui/src/native.rs','reactivity/crates/gpui/src/native/accessibility.rs']
saved={p:(root/p).read_bytes() for p in paths}
allpaths=git('ls-files','.cargo','reactivity/Cargo.toml','reactivity/Cargo.lock','reactivity/crates','reactivity/vendor').decode().splitlines()
allpaths=[p for p in allpaths if (root/p).is_file() and (Path(p).suffix in ('.rs','.wgsl','.toml') or Path(p).name=='Cargo.lock')]
def guard():return {p:sha((root/p).read_bytes()) for p in allpaths}
initial=guard()
baseline={p:git('show','69b442fa3b:'+p) for p in paths}
candidate={p:(source/p).read_bytes() for p in paths}
environment=dict(os.environ,CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/tmp/gpui-a11y-owner-channel-target',RUSTC_BOOTSTRAP='1')
environment.pop('RUSTFLAGS',None);environment.pop('CARGO_ENCODED_RUSTFLAGS',None)
metadata={'baseline':'69b442fa3b','candidate':'5b4a2d7fc792a4e9929589eaf4c0ac94f144de39','control_commit':git('rev-parse','HEAD').decode().strip(),'same_physical_path':str(root),'config_sha256':sha(config.read_bytes()),'rustc':subprocess.check_output(['rustc','-vV'],text=True),'lanes':{},'scope':'actual optimized ordinary public empty Window; static frames/code only, no dynamic stack or timing'}
try:
    for label,wanted in [('baseline',baseline),('candidate',candidate)]:
        lane=out/label;lane.mkdir()
        for p,data in wanted.items():(root/p).write_bytes(data)
        before=guard();assert all(before[p]==initial[p] for p in allpaths if p not in paths)
        (lane/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
        with (lane/'clean.log').open('w') as log:
            subprocess.run(['cargo','clean','-p','gpui','--release'],cwd=root/'reactivity',env=environment,stdout=log,stderr=subprocess.STDOUT,check=True)
        args=['cargo','build','--offline','--locked','-p','gpui','--features','x11','--release','--config',str(config),'--example','empty','--message-format=json','-vv']
        with (lane/'cargo.jsonl').open('w') as stdout,(lane/'cargo.log').open('w') as stderr:
            subprocess.run(args,cwd=root/'reactivity',env=environment,stdout=stdout,stderr=stderr,check=True)
        artifacts=[json.loads(line) for line in (lane/'cargo.jsonl').read_text().splitlines() if line.startswith('{')]
        library=next(a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='gpui' and a['target']['kind']==['lib'])
        consumer=next(a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='empty' and 'example' in a['target']['kind'])
        assert not library['fresh'] and not consumer['fresh']
        binary=lane/'empty';shutil.copy2(consumer['executable'],binary);binary.chmod(0o555)
        report=elf.inspect(binary);(lane/'empty.elf.json').write_text(json.dumps(report,indent=2)+'\n')
        selected=[f for f in report['all_frames'] if 'NativeHost<empty::Empty>' in f['normalized_name'] or 'gpui::native::accessibility::' in f['normalized_name'] or f['normalized_name']=='empty::main']
        seen=set()
        with (lane/'native.asm').open('w') as log:
            for f in selected:
                if f['address'] in seen:continue
                seen.add(f['address']);log.write('\n'+json.dumps(f)+'\n')
                subprocess.run(['/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/objdump','-d','--no-show-raw-insn','--demangle=rust',f"--start-address={f['address']}",f"--stop-address={f['address']+f['code_bytes']}",str(binary)],stdout=log,check=True)
        (lane/'fingerprints').mkdir()
        for p in Path(environment['CARGO_TARGET_DIR']).glob('release/.fingerprint/gpui-*/*.json'):
            shutil.copy2(p,lane/'fingerprints'/(p.parent.name+'-'+p.name))
        after=guard();assert after==before
        (lane/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
        metadata['lanes'][label]={'library_artifact':library,'consumer_artifact':consumer,'binary_sha256':sha(binary.read_bytes()),'sections':report['sections'],'selected_functions':selected,'args':args}
        (out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n');print(label,'DONE',flush=True)
finally:
    for p,data in saved.items():(root/p).write_bytes(data)
    assert guard()==initial
    metadata['restored_status']=git('status','--porcelain').decode()
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
assert not metadata['restored_status'];print('RESTORED',flush=True)
