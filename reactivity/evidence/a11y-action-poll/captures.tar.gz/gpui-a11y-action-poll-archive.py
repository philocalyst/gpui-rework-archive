from pathlib import Path
import hashlib,io,json,subprocess,tarfile

root=Path('/root/gpui-ce3');producer=Path('/tmp/gpui-a11y-action-poll-root')
dest=root/'reactivity/evidence/a11y-action-poll';dest.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(producer),'-C',str(producer),*args])
def sha(data):return hashlib.sha256(data).hexdigest()
assert not git('status','--porcelain')
pin=git('rev-parse','HEAD').decode().strip();assert pin=='e96c1b748e49ae3988fffcab154a36090ff5ac68'
sourcepaths=['reactivity/crates/gpui/src/native.rs','reactivity/crates/gpui/src/native/accessibility.rs']
testpaths=['reactivity/crates/gpui/src/native/accessibility/poll_tests.rs']
for name,paths in [('shipping.patch',sourcepaths),('tests.patch',testpaths)]:
    (dest/name).write_bytes(git('diff','--binary','a6ac3ea81f3610cc70cdab56536e75f34d3337a2',pin,'--',*paths))
files=set()
for directory in ['/tmp/gpui-a11y-action-poll-captures','/tmp/gpui-a11y-action-poll-codegen','/tmp/gpui-a11y-action-poll-cross']:
    files.update(p for p in Path(directory).rglob('*') if p.is_file())
files.update(p for p in Path('/tmp').glob('gpui-a11y-action-poll-*') if p.is_file())
manifest=[];external=[]
with tarfile.open(dest/'captures.tar.gz','w:gz',compresslevel=9) as tar:
    for p in sorted(files):
        data=p.read_bytes();name=str(p.relative_to('/tmp'));row={'path':name,'bytes':len(data),'sha256':sha(data)}
        if data[:4]==b'\x7fELF':external.append(row);continue
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o444;info.mtime=0
        tar.addfile(info,io.BytesIO(data));manifest.append(row)
with tarfile.open(dest/'captures.tar.gz') as tar:
    members=tar.getmembers();assert len(members)==len(manifest)
    for member,row in zip(members,manifest):
        data=tar.extractfile(member).read();assert member.name==row['path'] and len(data)==row['bytes'] and sha(data)==row['sha256']
(dest/'capture-manifest.json').write_text(json.dumps({'archived':manifest,'external_executables':external},indent=2)+'\n')
(dest/'core-lines.json').write_bytes(Path('/tmp/gpui-a11y-action-poll-core-lines.json').read_bytes())
m=json.loads(Path('/tmp/gpui-a11y-action-poll-codegen/metadata.json').read_text())
summary={'production':'5b4a2d7fc792a4e9929589eaf4c0ac94f144de39','final_test_source':pin,'base':'a6ac3ea81f3610cc70cdab56536e75f34d3337a2','noncomment_nontest_core':30696,'prior_core':30686,'core_delta':10,
'linked_empty_delta':{k:m['lanes']['candidate']['sections'][k]-m['lanes']['baseline']['sections'][k] for k in m['lanes']['baseline']['sections']},
'native_full_lib':{'passed':216,'ignored':27,'source':'normal source restored after negative; before adding already-qualified112c provider fixture'},
'actual_native_driver_scenarios':['fatal leaves next command unconsumed','recoverable glyph presentation failure then repair','sixteen stale sessions consume budget and rearm'],
'negative_control':'delayed sixteen-result batch consumes next command; intended actual native assertion fails; exact restore passes',
'actual_registry_failure_repair':{'passed':True,'source':pin},'strict_alltargets_x11':True,'apple_arm64_native_lib_check':True,'windows_msvc_native_lib_check':True,
'limits':'Static code/frame and functional checks. No dynamic stack peak, timing, RSS, hardware GPU or foreign runtime claim.'}
(dest/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'archived_files':len(manifest),'raw_bytes':sum(r['bytes'] for r in manifest),'archive_bytes':(dest/'captures.tar.gz').stat().st_size,'excluded_executables':len(external),'pin':pin}))
