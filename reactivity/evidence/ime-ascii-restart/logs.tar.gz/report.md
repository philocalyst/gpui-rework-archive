# ASCII restart window for IME grapheme geometry

## Conclusion and exact precondition

A zero-retained-state fast path is correct when the current source prefix `source[..start]` passes `str::is_ascii()`. Restart ICU at the previous complete grapheme in that prefix, segment the **entire remaining joined display suffix**, translate local ICU offsets by the restart base, and run the same cursor/decoration loop. If the prefix contains non-ASCII, use the current full-display path.

For UTF-8 byte offset `start`, the restart base is `0` when `start == 0`; otherwise it is `start - 1`, except when the two bytes immediately before `start` are CR LF, in which case use `start - 2`. A replacement can start between CR and LF: in that case `start - 1` is CR, so the ordinary branch already includes the CR. When it starts after the pair, the adjustment includes both bytes. Never stop the ICU input at `marked.end`: the untouched source suffix can extend the final preedit grapheme and determine the decoration end.

The condition should inspect only the source prefix before the replaced range. Requiring the entire source to be ASCII would safely skip some cases where only the suffix is Unicode, but would unnecessarily miss the optimization there. This needs no Active field and adds no retained bytes.

## Proof against the exact ICU rules

The frozen checkout uses ICU4X `icu_segmenter` 2.3.0. Its source documents the grapheme segmenter as UAX #29 Unicode 17.0.0, revision 47, and links the revision 47 text. The matching primary Unicode sources are therefore UAX #29 revision 47 and Unicode 17.0.0 UCD data, rather than the newer Unicode 18 revision 49 sources cited in the first draft.

In the Unicode 17 GraphemeBreakProperty data, ASCII code points are either Control, CR, LF, or the default Other. In a run restricted to ASCII, CR LF is the only multi-byte grapheme; controls form single-code-point graphemes, and every other ASCII code point is an individual grapheme. The ordered UAX rules break after Control/CR/LF (GB4) except for the CR × LF pair (GB3). Every other ASCII grapheme has a break before it under GB999 because the preceding ASCII code point cannot be Prepend, Hangul, RI, Extend, ZWJ, or SpacingMark. The independent Unicode 17 Indic_Conjunct_Break and Extended_Pictographic data also assign none of those contextual classes to ASCII.

Thus the previous complete ASCII grapheme is a boundary at which all relevant preceding context has ended. Retaining that grapheme in the restarted input preserves every possible seam interaction with the first preedit code point. In particular, GB9 can join a leading Extend to an ASCII base; the keycap sequence's `#`, `*`, or digit base must be retained. CRLF must be restarted at CR when the prefix ends in the pair. Since the restarted iterator sees the complete suffix, GB11 and other rightward joins still resolve against source text following the mark.

That is the proof argument; the test grid below is finite evidence, not the proof. UAX #29's boundary tables and the corresponding primary property files are linked here:

- [UAX #29, revision 47, Unicode 17.0.0, grapheme rules GB3–GB13 and GB999](https://www.unicode.org/reports/tr29/tr29-47.html#Grapheme_Cluster_Boundary_Rules)
- [Unicode 17.0.0 GraphemeBreakProperty.txt](https://www.unicode.org/Public/17.0.0/ucd/auxiliary/GraphemeBreakProperty.txt)
- [Unicode 17.0.0 DerivedCoreProperties.txt, including Indic_Conjunct_Break](https://www.unicode.org/Public/17.0.0/ucd/DerivedCoreProperties.txt)
- [Unicode 17.0.0 emoji-data.txt, including Extended_Pictographic](https://www.unicode.org/Public/17.0.0/ucd/emoji/emoji-data.txt)
- [ICU4X 2.3.0 GraphemeClusterSegmenter API](https://docs.rs/icu_segmenter/2.3.0/icu_segmenter/struct.GraphemeClusterSegmenter.html)
- [ICU4X 2.3.0 grapheme source documenting UAX #29 Unicode 17.0.0](https://github.com/unicode-org/icu4x/blob/icu@2.3.0/components/segmenter/src/grapheme.rs)

## Exact geometry comparison and mutants

`src/main.rs` contains the frozen `preview_selections` loop copied from b1560. The full oracle runs that loop over the full display with initial state at byte zero. The candidate runs the same loop over `value[base..]`, translates each iterator boundary by `base`, and initializes `previous`, `anchor`, `focus`, and `left` at the known full-text boundary `base`. Both return the exact byte pairs for the directed cursor selection and decoration selection, which is the geometry before production's downstream-affinity `TextPosition` wrapper. The comparison includes raw cursor absence, all ordered pairs of valid UTF-8 character boundaries inside each preedit, reversed pairs, nearest-boundary ties (downstream), and decoration floor/ceiling.

The final probe compared 91,209 cases with zero mismatches, including 78,514 valid cursor-pair rows. It covers every ASCII byte as the last prefix code point, varied preedits and untouched suffixes, all cursor endpoint pairs for those preedits, replacement ranges, controls, CRLF starts at byte zero, at/between CR and LF, after the pair, and ranges crossing the pair. It also covers combining marks, realistic keycap sequences, Indic conjuncts, ZWJ emoji, RI pairs, spacing marks, and fallback cases with a non-ASCII source prefix. For an earlier case, cursor `(0, 8)` was outside the four-byte preedit `🇦`; the frozen `update_preedit` admission rejects it because it is beyond the text boundary. That pair is now recorded as rejected and is not counted as admitted geometry input.

Two broken variants were run against the exact full oracle. Skipping the previous ASCII grapheme on source `a` plus preedit U+0301 changes geometry from cursor/decor `[0,3]` to `[1,3]`. Truncating the ICU slice at `marked.end` for prefix `x`, preedit `👩‍`, and untouched suffix `💻` changes the correct decoration `[1,12]` to `[1,8]`. Both assertions fail as expected, showing why the retained left grapheme and full suffix are necessary.

## Per-event ASCII branch and measurement

The release probe loads its 32,769-byte source from a runtime file so rustc cannot prove its contents at compile time. On every adaptive iteration it calls the same `source[..start].is_ascii()` predicate proposed for production, then runs the complete early-stop geometry loop from the calculated restart base. The full comparison also runs that exact loop from byte zero. Both paths produce identical geometry before timing.

Across the final three runs, the full scan measured 224–228 µs/op and visited 32,769 boundaries. The prefix predicate plus restart measured 399–427 ns/op and visited two boundaries, a 524–570× improvement in this deliberately prefix-dominated 32 KiB case. This direct measurement includes the vectorized ASCII prefix check on each event; it does not depend on caching a certificate in Active. The branch is useful for large ASCII prefixes and becomes less beneficial as the prefix shrinks. These figures establish a prototype workload result, not a whole-API performance claim.

Pinned-nightly optimized assembly was emitted from the same probe and contains the concrete measured `source[..start].is_ascii()` call. For the 32 KiB branch it uses 64-byte vector loads (`movdqu`), combines sign bits (`por`), and checks them with `pmovmskb`; short blocks use 8-byte mask tests and a scalar tail. This is the call in the actual benchmark binary, not only a separate helper. The detached `ascii_check.rs`/`.s` probe from the first draft is retained for history but is not needed for this result.

The earlier Active layout mirror measured 56 bytes without a cache and 64 bytes with a bool, so a retained certificate would add 8 bytes rather than fit in padding. The tested per-event prefix predicate makes that storage unnecessary.

## Reproduction and provenance

From `/root`:

```sh
source /tmp/gpui-native-env.sh
source /tmp/gpui-nightly-env.sh
CARGO_TARGET_DIR=/tmp/gpui-ime-ascii-context-luna-20261024/target \
  cargo run --release --offline --locked \
  --manifest-path /tmp/gpui-ime-ascii-context-luna-20261024/Cargo.toml \
  -- /tmp/gpui-ime-ascii-context-luna-20261024/bench-source.txt
```

The source fixture is 32,768 ASCII `a` bytes followed by `x`, 32,769 bytes total. The prototype manifest pins ICU4X `icu_segmenter = 2.3.0` and `arcstr = 1.2.0`; its lockfile began from the frozen worktree lock. Compiler: `rustc 1.101.0-nightly (7189d39d9 2026-10-22)`, LLVM 23.1.4; Cargo 1.101.0-nightly. Host: x86_64 Linux. Release profile uses Cargo defaults with no CPU-specific flags. The timing spread reflects local runs without affinity or statistical controls.

Frozen reference checkout: `/tmp/gpui-ime-direct-lease-sol-20261024`, clean at `b1560c2a4c4d327701b19d6974875d51b6806393`. The referenced IME source SHA-256 is `52113e68fb506670be204c7efeb4c568f000c0579648425f9332984b7289d57e`. No reference or production source was edited.

Hashes:

- `src/main.rs`: `a5f44ab35842ac4c43fb3efcb9c54da41ef7fed0ce06781e6e591a1c4e577df7`
- `Cargo.toml`: `001b1a9f871851213b937462511a3e722a7ebe63fe83d5780fd5219c43c040f8`
- `Cargo.lock`: `a120a12c945ee9ef0d9e2c2b2922dd583087443b9805eeb336a674a0c72d77aa`
- release executable: `ab43edac0c8ab2594902fc9c69a34b69e37222bb532cddc9d8f7fcad824fe79b`
- source fixture: `1a7130c149a506cf44f537b9644ee5ca9064ccd4749ecbda0eb49df629df2d76`
- concrete optimized assembly: `e809bd8b8a4e1f7e89265626b60825b26e30ab1bc90fd77d369035d0e85322c1`
- `ascii_check.rs`: `88910dc4f5d15f53edaa70170a098e69197f5f42db7fc2891440d510ffa57eb1`
- `ascii_check.s`: `cee75880a84b59cc17a9f345d4448148f08957fa7c71b2f2a562e0360323608f`

## Preserved failed attempts

The first Cargo build failed because this environment had no `cc`; using `rust-lld` directly failed because system C libraries were unavailable. I stopped Nix provisioning when the pinned native environment path was identified, then built offline with `/tmp/gpui-native-env.sh` and `/tmp/gpui-nightly-env.sh`. Python was unavailable when creating the runtime fixture, so I generated its ASCII bytes with the available coreutils `head` and `tr`; one attempted run before the fixture existed failed with file-not-found and was rerun after fixture creation.

An early semantic grid supplied a non-ASCII prefix to the restart slice and panicked inside a UTF-8 character. It was corrected so the false ASCII-prefix certificate takes the full scan. An early cursor case used endpoint 8 for a four-byte emoji preedit; it now exercises admission rejection instead of geometry. An early timing version built the ASCII source in the benchmark and rustc could know its contents; the final timing reads the bytes from a runtime fixture, and optimized assembly verifies that the prefix check remains in the timed loop. The first-draft assembly check used a detached helper; the final report uses the main probe assembly. An early benchmark collected all boundaries into vectors; the final benchmark copies the frozen early-stop loop and compares its exact geometry outputs.
