
/tmp/gpui-ime-ascii-relative-release-executable-root/ime_cursor_cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000574540 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event>:
  574540:	55                   	push   %rbp
  574541:	41 57                	push   %r15
  574543:	41 56                	push   %r14
  574545:	41 55                	push   %r13
  574547:	41 54                	push   %r12
  574549:	53                   	push   %rbx
  57454a:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
  574551:	49 89 f5             	mov    %rsi,%r13
  574554:	4c 8b 21             	mov    (%rcx),%r12
  574557:	4c 89 e0             	mov    %r12,%rax
  57455a:	48 83 e8 02          	sub    $0x2,%rax
  57455e:	bd 01 00 00 00       	mov    $0x1,%ebp
  574563:	48 0f 43 e8          	cmovae %rax,%rbp
  574567:	48 89 fb             	mov    %rdi,%rbx
  57456a:	4c 8d 7d fd          	lea    -0x3(%rbp),%r15
  57456e:	48 8b 02             	mov    (%rdx),%rax
  574571:	49 83 ff 01          	cmp    $0x1,%r15
  574575:	77 07                	ja     57457e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x3e>
  574577:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
  57457e:	4d 8b 75 00          	mov    0x0(%r13),%r14
  574582:	4d 85 f6             	test   %r14,%r14
  574585:	0f 84 e0 00 00 00    	je     57466b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12b>
  57458b:	49 8b b6 20 06 00 00 	mov    0x620(%r14),%rsi
  574592:	48 85 f6             	test   %rsi,%rsi
  574595:	0f 84 04 01 00 00    	je     57469f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x15f>
  57459b:	48 8b be e0 00 00 00 	mov    0xe0(%rsi),%rdi
  5745a2:	48 85 ff             	test   %rdi,%rdi
  5745a5:	0f 84 d4 00 00 00    	je     57467f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  5745ab:	48 8b 7f 60          	mov    0x60(%rdi),%rdi
  5745af:	48 85 ff             	test   %rdi,%rdi
  5745b2:	0f 84 c7 00 00 00    	je     57467f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  5745b8:	48 8b 3f             	mov    (%rdi),%rdi
  5745bb:	48 85 ff             	test   %rdi,%rdi
  5745be:	0f 84 bb 00 00 00    	je     57467f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  5745c4:	4c 8b 47 08          	mov    0x8(%rdi),%r8
  5745c8:	48 8b 7f 10          	mov    0x10(%rdi),%rdi
  5745cc:	48 89 bc 24 28 01 00 	mov    %rdi,0x128(%rsp)
  5745d3:	00 
  5745d4:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  5745db:	00 
  5745dc:	0f 85 ae 00 00 00    	jne    574690 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x150>
  5745e2:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  5745e9:	49 c7 86 18 07 00 00 	movq   $0x0,0x718(%r14)
  5745f0:	00 00 00 00 
  5745f4:	48 8b b6 e0 00 00 00 	mov    0xe0(%rsi),%rsi
  5745fb:	48 85 f6             	test   %rsi,%rsi
  5745fe:	0f 84 5d 01 00 00    	je     574761 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  574604:	48 8b 76 60          	mov    0x60(%rsi),%rsi
  574608:	48 85 f6             	test   %rsi,%rsi
  57460b:	0f 84 50 01 00 00    	je     574761 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  574611:	48 8b 36             	mov    (%rsi),%rsi
  574614:	48 85 f6             	test   %rsi,%rsi
  574617:	0f 84 44 01 00 00    	je     574761 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  57461d:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  574624:	00 
  574625:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  57462a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  57462f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  574634:	4c 89 f7             	mov    %r14,%rdi
  574637:	e8 f4 ed ff ff       	call   573430 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::ime_valid>
  57463c:	84 c0                	test   %al,%al
  57463e:	75 08                	jne    574648 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x108>
  574640:	4c 89 f7             	mov    %r14,%rdi
  574643:	e8 08 e5 ff ff       	call   572b50 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  574648:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  57464d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574652:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  574657:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
  57465e:	00 
  57465f:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  574666:	e9 f6 00 00 00       	jmp    574761 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  57466b:	48 c7 03 0d 00 00 00 	movq   $0xd,(%rbx)
  574672:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
  574679:	00 
  57467a:	e9 67 04 00 00       	jmp    574ae6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5a6>
  57467f:	45 31 c0             	xor    %r8d,%r8d
  574682:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  574689:	00 
  57468a:	0f 84 52 ff ff ff    	je     5745e2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xa2>
  574690:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  574697:	00 
  574698:	bd 0e 00 00 00       	mov    $0xe,%ebp
  57469d:	eb 1f                	jmp    5746be <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x17e>
  57469f:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  5746a6:	00 
  5746a7:	0f 84 9f 00 00 00    	je     57474c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x20c>
  5746ad:	bd 0e 00 00 00       	mov    $0xe,%ebp
  5746b2:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  5746b9:	00 00 00 00 00 
  5746be:	45 31 ff             	xor    %r15d,%r15d
  5746c1:	45 31 e4             	xor    %r12d,%r12d
  5746c4:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  5746c9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  5746ce:	f3 0f 7f 4c 24 20    	movdqu %xmm1,0x20(%rsp)
  5746d4:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  5746d9:	41 0f b6 c4          	movzbl %r12b,%eax
  5746dd:	4c 09 f8             	or     %r15,%rax
  5746e0:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  5746e5:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
  5746ea:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
  5746f1:	4c 89 f7             	mov    %r14,%rdi
  5746f4:	e8 57 e4 ff ff       	call   572b50 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  5746f9:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  574700:	00 
  574701:	48 85 f6             	test   %rsi,%rsi
  574704:	74 10                	je     574716 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1d6>
  574706:	4c 89 f7             	mov    %r14,%rdi
  574709:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
  574710:	00 
  574711:	e8 3a eb ff ff       	call   573250 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  574716:	4c 89 f7             	mov    %r14,%rdi
  574719:	e8 a2 e7 ff ff       	call   572ec0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::reclaim_ime>
  57471e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  574723:	48 89 43 30          	mov    %rax,0x30(%rbx)
  574727:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
  57472d:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  574733:	f3 0f 6f 54 24 30    	movdqu 0x30(%rsp),%xmm2
  574739:	f3 0f 7f 53 20       	movdqu %xmm2,0x20(%rbx)
  57473e:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  574743:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  574747:	e9 9a 03 00 00       	jmp    574ae6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5a6>
  57474c:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  574753:	49 c7 86 18 07 00 00 	movq   $0x0,0x718(%r14)
  57475a:	00 00 00 00 
  57475e:	45 31 c0             	xor    %r8d,%r8d
  574761:	48 85 ed             	test   %rbp,%rbp
  574764:	0f 84 12 01 00 00    	je     57487c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x33c>
  57476a:	49 8b b6 20 06 00 00 	mov    0x620(%r14),%rsi
  574771:	48 85 f6             	test   %rsi,%rsi
  574774:	0f 84 cb 00 00 00    	je     574845 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  57477a:	48 8b b6 e0 00 00 00 	mov    0xe0(%rsi),%rsi
  574781:	48 85 f6             	test   %rsi,%rsi
  574784:	0f 84 bb 00 00 00    	je     574845 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  57478a:	48 8b 76 60          	mov    0x60(%rsi),%rsi
  57478e:	48 85 f6             	test   %rsi,%rsi
  574791:	0f 84 ae 00 00 00    	je     574845 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  574797:	48 8b 3e             	mov    (%rsi),%rdi
  57479a:	48 89 3c 24          	mov    %rdi,(%rsp)
  57479e:	48 85 ff             	test   %rdi,%rdi
  5747a1:	0f 84 9e 00 00 00    	je     574845 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  5747a7:	48 85 c0             	test   %rax,%rax
  5747aa:	0f 84 95 00 00 00    	je     574845 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  5747b0:	48 8b 3c 24          	mov    (%rsp),%rdi
  5747b4:	48 39 07             	cmp    %rax,(%rdi)
  5747b7:	0f 85 88 00 00 00    	jne    574845 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  5747bd:	49 83 ff 01          	cmp    $0x1,%r15
  5747c1:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  5747c6:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  5747cd:	00 
  5747ce:	0f 87 a4 03 00 00    	ja     574b78 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x638>
  5747d4:	4d 89 cf             	mov    %r9,%r15
  5747d7:	4c 89 f7             	mov    %r14,%rdi
  5747da:	e8 71 e3 ff ff       	call   572b50 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  5747df:	84 c0                	test   %al,%al
  5747e1:	0f 84 2d 04 00 00    	je     574c14 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6d4>
  5747e7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  5747ec:	4c 89 f6             	mov    %r14,%rsi
  5747ef:	e8 cc 60 01 00       	call   58a8c0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  5747f4:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  5747f9:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5747fd:	0f 85 e3 03 00 00    	jne    574be6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6a6>
  574803:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  574808:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  57480e:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  574813:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574818:	44 0f b6 6c 24 40    	movzbl 0x40(%rsp),%r13d
  57481e:	0f b6 44 24 47       	movzbl 0x47(%rsp),%eax
  574823:	c1 e0 10             	shl    $0x10,%eax
  574826:	0f b7 4c 24 45       	movzwl 0x45(%rsp),%ecx
  57482b:	09 c1                	or     %eax,%ecx
  57482d:	48 c1 e1 20          	shl    $0x20,%rcx
  574831:	44 8b 74 24 41       	mov    0x41(%rsp),%r14d
  574836:	49 09 ce             	or     %rcx,%r14
  574839:	31 c0                	xor    %eax,%eax
  57483b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574840:	e9 77 02 00 00       	jmp    574abc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  574845:	49 8b 86 70 06 00 00 	mov    0x670(%r14),%rax
  57484c:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  574853:	00 
  574854:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  57485b:	00 
  57485c:	74 17                	je     574875 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x335>
  57485e:	45 84 ed             	test   %r13b,%r13b
  574861:	0f 84 2f 02 00 00    	je     574a96 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x556>
  574867:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  57486e:	ff 
  57486f:	0f 85 21 02 00 00    	jne    574a96 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x556>
  574875:	31 ff                	xor    %edi,%edi
  574877:	e9 26 02 00 00       	jmp    574aa2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x562>
  57487c:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
  574881:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  574888:	00 
  574889:	4c 89 f7             	mov    %r14,%rdi
  57488c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  574891:	e8 ba e2 ff ff       	call   572b50 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  574896:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  57489b:	48 8b 0d 7e b5 2e 00 	mov    0x2eb57e(%rip),%rcx        # 85fe20 <_DYNAMIC+0x428>
  5748a2:	48 8b 01             	mov    (%rcx),%rax
  5748a5:	45 31 ff             	xor    %r15d,%r15d
  5748a8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  5748af:	00 
  5748b0:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  5748b4:	0f 84 d2 01 00 00    	je     574a8c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x54c>
  5748ba:	48 8d 70 01          	lea    0x1(%rax),%rsi
  5748be:	f0 48 0f b1 31       	lock cmpxchg %rsi,(%rcx)
  5748c3:	75 eb                	jne    5748b0 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x370>
  5748c5:	48 85 c0             	test   %rax,%rax
  5748c8:	0f 84 05 0c 00 00    	je     5754d3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf93>
  5748ce:	4d 8b ae f8 05 00 00 	mov    0x5f8(%r14),%r13
  5748d5:	4d 85 ed             	test   %r13,%r13
  5748d8:	0f 84 1d 02 00 00    	je     574afb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5bb>
  5748de:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  5748e3:	4d 8b a6 00 06 00 00 	mov    0x600(%r14),%r12
  5748ea:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  5748ef:	4c 89 f6             	mov    %r14,%rsi
  5748f2:	4c 89 ea             	mov    %r13,%rdx
  5748f5:	4c 89 e1             	mov    %r12,%rcx
  5748f8:	e8 23 d3 ff ff       	call   571c20 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  5748fd:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574902:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  574907:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  57490b:	0f 85 f1 01 00 00    	jne    574b02 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5c2>
  574911:	49 8b b6 a8 02 00 00 	mov    0x2a8(%r14),%rsi
  574918:	48 39 f7             	cmp    %rsi,%rdi
  57491b:	0f 83 53 0f 00 00    	jae    575874 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1334>
  574921:	49 8b 86 a0 02 00 00 	mov    0x2a0(%r14),%rax
  574928:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  57492c:	8b 7c c8 10          	mov    0x10(%rax,%rcx,8),%edi
  574930:	89 f8                	mov    %edi,%eax
  574932:	83 e0 0f             	and    $0xf,%eax
  574935:	83 f8 09             	cmp    $0x9,%eax
  574938:	0f 87 bf 0e 00 00    	ja     5757fd <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12bd>
  57493e:	83 f8 06             	cmp    $0x6,%eax
  574941:	0f 84 87 03 00 00    	je     574cce <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x78e>
  574947:	c1 ef 04             	shr    $0x4,%edi
  57494a:	0f 84 7e 03 00 00    	je     574cce <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x78e>
  574950:	49 8b b6 c0 02 00 00 	mov    0x2c0(%r14),%rsi
  574957:	ff cf                	dec    %edi
  574959:	48 39 fe             	cmp    %rdi,%rsi
  57495c:	0f 86 1f 0f 00 00    	jbe    575881 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1341>
  574962:	49 8b 86 b8 02 00 00 	mov    0x2b8(%r14),%rax
  574969:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  57496d:	48 c1 e1 04          	shl    $0x4,%rcx
  574971:	83 3c 08 ff          	cmpl   $0xffffffff,(%rax,%rcx,1)
  574975:	0f 84 53 0e 00 00    	je     5757ce <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x128e>
  57497b:	48 01 c8             	add    %rcx,%rax
  57497e:	4c 8b 78 48          	mov    0x48(%rax),%r15
  574982:	4d 85 ff             	test   %r15,%r15
  574985:	0f 84 50 0e 00 00    	je     5757db <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x129b>
  57498b:	49 8b 8e 70 06 00 00 	mov    0x670(%r14),%rcx
  574992:	48 89 0c 24          	mov    %rcx,(%rsp)
  574996:	48 8b 68 40          	mov    0x40(%rax),%rbp
  57499a:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
  57499e:	75 2e                	jne    5749ce <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  5749a0:	48 8b 45 08          	mov    0x8(%rbp),%rax
  5749a4:	a8 01                	test   $0x1,%al
  5749a6:	75 26                	jne    5749ce <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  5749a8:	b8 02 00 00 00       	mov    $0x2,%eax
  5749ad:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  5749b3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  5749ba:	00 00 80 
  5749bd:	48 ff c1             	inc    %rcx
  5749c0:	48 21 c1             	and    %rax,%rcx
  5749c3:	48 f7 d9             	neg    %rcx
  5749c6:	71 06                	jno    5749ce <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  5749c8:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  5749ce:	ff 15 6c b2 2e 00    	call   *0x2eb26c(%rip)        # 85fc40 <_DYNAMIC+0x248>
  5749d4:	bf 38 00 00 00       	mov    $0x38,%edi
  5749d9:	be 08 00 00 00       	mov    $0x8,%esi
  5749de:	ff 15 64 b2 2e 00    	call   *0x2eb264(%rip)        # 85fc48 <_DYNAMIC+0x250>
  5749e4:	48 85 c0             	test   %rax,%rax
  5749e7:	0f 84 fb 0d 00 00    	je     5757e8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12a8>
  5749ed:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  5749f2:	48 89 08             	mov    %rcx,(%rax)
  5749f5:	4c 89 68 08          	mov    %r13,0x8(%rax)
  5749f9:	4c 89 60 10          	mov    %r12,0x10(%rax)
  5749fd:	4c 89 78 18          	mov    %r15,0x18(%rax)
  574a01:	48 89 68 20          	mov    %rbp,0x20(%rax)
  574a05:	48 8b 0c 24          	mov    (%rsp),%rcx
  574a09:	48 89 48 28          	mov    %rcx,0x28(%rax)
  574a0d:	48 c7 40 30 00 00 00 	movq   $0x0,0x30(%rax)
  574a14:	00 
  574a15:	4c 89 f7             	mov    %r14,%rdi
  574a18:	48 89 c6             	mov    %rax,%rsi
  574a1b:	e8 90 e2 ff ff       	call   572cb0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  574a20:	41 80 be 2b 07 00 00 	cmpb   $0x0,0x72b(%r14)
  574a27:	00 
  574a28:	0f 84 00 01 00 00    	je     574b2e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5ee>
  574a2e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574a33:	4c 89 f6             	mov    %r14,%rsi
  574a36:	e8 85 5e 01 00       	call   58a8c0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  574a3b:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574a40:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574a44:	0f 85 9c 01 00 00    	jne    574be6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6a6>
  574a4a:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  574a4f:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  574a55:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  574a5a:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574a5f:	44 0f b6 6c 24 40    	movzbl 0x40(%rsp),%r13d
  574a65:	0f b6 44 24 47       	movzbl 0x47(%rsp),%eax
  574a6a:	c1 e0 10             	shl    $0x10,%eax
  574a6d:	0f b7 4c 24 45       	movzwl 0x45(%rsp),%ecx
  574a72:	09 c1                	or     %eax,%ecx
  574a74:	48 c1 e1 20          	shl    $0x20,%rcx
  574a78:	44 8b 74 24 41       	mov    0x41(%rsp),%r14d
  574a7d:	49 09 ce             	or     %rcx,%r14
  574a80:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574a85:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574a8a:	eb 30                	jmp    574abc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  574a8c:	bd 21 00 00 00       	mov    $0x21,%ebp
  574a91:	e9 2b fc ff ff       	jmp    5746c1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x181>
  574a96:	49 8b 8e a0 06 00 00 	mov    0x6a0(%r14),%rcx
  574a9d:	bf 01 00 00 00       	mov    $0x1,%edi
  574aa2:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  574aa9:	4d 8b 21             	mov    (%r9),%r12
  574aac:	66 48 0f 6e c0       	movq   %rax,%xmm0
  574ab1:	66 48 0f 6e c9       	movq   %rcx,%xmm1
  574ab6:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
  574aba:	31 c0                	xor    %eax,%eax
  574abc:	49 c1 e6 08          	shl    $0x8,%r14
  574ac0:	41 0f b6 cd          	movzbl %r13b,%ecx
  574ac4:	4c 09 f1             	or     %r14,%rcx
  574ac7:	48 89 02             	mov    %rax,(%rdx)
  574aca:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
  574ace:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  574ad3:	4c 89 7b 20          	mov    %r15,0x20(%rbx)
  574ad7:	4c 89 63 28          	mov    %r12,0x28(%rbx)
  574adb:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
  574adf:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
  574ae6:	48 89 d8             	mov    %rbx,%rax
  574ae9:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
  574af0:	5b                   	pop    %rbx
  574af1:	41 5c                	pop    %r12
  574af3:	41 5d                	pop    %r13
  574af5:	41 5e                	pop    %r14
  574af7:	41 5f                	pop    %r15
  574af9:	5d                   	pop    %rbp
  574afa:	c3                   	ret
  574afb:	bd 19 00 00 00       	mov    $0x19,%ebp
  574b00:	eb 18                	jmp    574b1a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  574b02:	48 89 f8             	mov    %rdi,%rax
  574b05:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  574b0b:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  574b10:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574b15:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  574b1a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574b1f:	4d 89 e7             	mov    %r12,%r15
  574b22:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  574b29:	e9 96 fb ff ff       	jmp    5746c4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  574b2e:	49 8b 8e 70 06 00 00 	mov    0x670(%r14),%rcx
  574b35:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  574b3c:	00 
  574b3d:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  574b44:	00 
  574b45:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574b4a:	0f 84 47 01 00 00    	je     574c97 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x757>
  574b50:	45 84 ed             	test   %r13b,%r13b
  574b53:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574b58:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  574b5d:	0f 84 42 01 00 00    	je     574ca5 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x765>
  574b63:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  574b6a:	ff 
  574b6b:	0f 85 34 01 00 00    	jne    574ca5 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x765>
  574b71:	31 ff                	xor    %edi,%edi
  574b73:	e9 39 01 00 00       	jmp    574cb1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x771>
  574b78:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
  574b7f:	48 83 fd 01          	cmp    $0x1,%rbp
  574b83:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  574b88:	0f 84 c9 00 00 00    	je     574c57 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x717>
  574b8e:	4c 8b 79 08          	mov    0x8(%rcx),%r15
  574b92:	4c 8b 61 10          	mov    0x10(%rcx),%r12
  574b96:	48 8b 04 24          	mov    (%rsp),%rax
  574b9a:	48 8b 50 08          	mov    0x8(%rax),%rdx
  574b9e:	48 8b 48 10          	mov    0x10(%rax),%rcx
  574ba2:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574ba7:	4c 89 f6             	mov    %r14,%rsi
  574baa:	e8 71 d0 ff ff       	call   571c20 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  574baf:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574bb4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  574bb9:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  574bbe:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574bc2:	0f 85 4b 05 00 00    	jne    575113 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbd3>
  574bc8:	48 8b 04 24          	mov    (%rsp),%rax
  574bcc:	48 8b 40 30          	mov    0x30(%rax),%rax
  574bd0:	48 85 c0             	test   %rax,%rax
  574bd3:	0f 84 24 01 00 00    	je     574cfd <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7bd>
  574bd9:	0f 10 00             	movups (%rax),%xmm0
  574bdc:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  574be1:	e9 38 01 00 00       	jmp    574d1e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7de>
  574be6:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  574beb:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  574bf1:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  574bf6:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574bfb:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  574c00:	4d 89 e7             	mov    %r12,%r15
  574c03:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  574c0a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574c0f:	e9 b0 fa ff ff       	jmp    5746c4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  574c14:	49 8b 86 70 06 00 00 	mov    0x670(%r14),%rax
  574c1b:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  574c22:	00 
  574c23:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  574c2a:	00 
  574c2b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574c30:	0f 84 a5 00 00 00    	je     574cdb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x79b>
  574c36:	45 84 ed             	test   %r13b,%r13b
  574c39:	4c 89 fe             	mov    %r15,%rsi
  574c3c:	0f 84 a0 00 00 00    	je     574ce2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7a2>
  574c42:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  574c49:	ff 
  574c4a:	0f 85 92 00 00 00    	jne    574ce2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7a2>
  574c50:	31 ff                	xor    %edi,%edi
  574c52:	e9 97 00 00 00       	jmp    574cee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7ae>
  574c57:	4c 8b 79 18          	mov    0x18(%rcx),%r15
  574c5b:	4c 8b 51 20          	mov    0x20(%rcx),%r10
  574c5f:	49 83 fc 01          	cmp    $0x1,%r12
  574c63:	4c 8b 0c 24          	mov    (%rsp),%r9
  574c67:	0f 85 d5 01 00 00    	jne    574e42 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  574c6d:	48 8b 79 08          	mov    0x8(%rcx),%rdi
  574c71:	48 8b 71 10          	mov    0x10(%rcx),%rsi
  574c75:	48 85 ff             	test   %rdi,%rdi
  574c78:	0f 84 9c 01 00 00    	je     574e1a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8da>
  574c7e:	4c 39 d7             	cmp    %r10,%rdi
  574c81:	0f 83 91 01 00 00    	jae    574e18 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8d8>
  574c87:	41 80 3c 3f bf       	cmpb   $0xbf,(%r15,%rdi,1)
  574c8c:	0f 8f 88 01 00 00    	jg     574e1a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8da>
  574c92:	e9 94 01 00 00       	jmp    574e2b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  574c97:	31 ff                	xor    %edi,%edi
  574c99:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574c9e:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  574ca3:	eb 0c                	jmp    574cb1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x771>
  574ca5:	49 8b b6 a0 06 00 00 	mov    0x6a0(%r14),%rsi
  574cac:	bf 01 00 00 00       	mov    $0x1,%edi
  574cb1:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  574cb8:	4d 8b 20             	mov    (%r8),%r12
  574cbb:	66 48 0f 6e c1       	movq   %rcx,%xmm0
  574cc0:	66 48 0f 6e ce       	movq   %rsi,%xmm1
  574cc5:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
  574cc9:	e9 ee fd ff ff       	jmp    574abc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  574cce:	48 8d 3d 4b 2e 2d 00 	lea    0x2d2e4b(%rip),%rdi        # 847b20 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x860>
  574cd5:	ff 15 9d af 2e 00    	call   *0x2eaf9d(%rip)        # 85fc78 <_DYNAMIC+0x280>
  574cdb:	31 ff                	xor    %edi,%edi
  574cdd:	4c 89 fe             	mov    %r15,%rsi
  574ce0:	eb 0c                	jmp    574cee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7ae>
  574ce2:	49 8b 8e a0 06 00 00 	mov    0x6a0(%r14),%rcx
  574ce9:	bf 01 00 00 00       	mov    $0x1,%edi
  574cee:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  574cf5:	4c 8b 26             	mov    (%rsi),%r12
  574cf8:	e9 af fd ff ff       	jmp    574aac <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x56c>
  574cfd:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574d02:	4c 89 f6             	mov    %r14,%rsi
  574d05:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  574d0a:	e8 41 d0 ff ff       	call   571d50 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::selection_at>
  574d0f:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574d14:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574d18:	0f 85 eb 03 00 00    	jne    575109 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbc9>
  574d1e:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  574d24:	66 0f 7f 84 24 30 01 	movdqa %xmm0,0x130(%rsp)
  574d2b:	00 00 
  574d2d:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
  574d34:	00 
  574d35:	4c 89 f7             	mov    %r14,%rdi
  574d38:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  574d3d:	e8 6e d1 ff ff       	call   571eb0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::set_selection>
  574d42:	48 8b 2c 24          	mov    (%rsp),%rbp
  574d46:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
  574d4a:	e8 31 61 ff ff       	call   56ae80 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  574d4f:	48 c7 45 30 00 00 00 	movq   $0x0,0x30(%rbp)
  574d56:	00 
  574d57:	48 8b 75 08          	mov    0x8(%rbp),%rsi
  574d5b:	48 8b 55 10          	mov    0x10(%rbp),%rdx
  574d5f:	4c 89 f7             	mov    %r14,%rdi
  574d62:	e8 e9 e4 ff ff       	call   573250 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  574d67:	49 83 c5 08          	add    $0x8,%r13
  574d6b:	48 8b 04 24          	mov    (%rsp),%rax
  574d6f:	48 8b 48 08          	mov    0x8(%rax),%rcx
  574d73:	4c 8b 40 10          	mov    0x10(%rax),%r8
  574d77:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574d7c:	4c 8d 8c 24 30 01 00 	lea    0x130(%rsp),%r9
  574d83:	00 
  574d84:	4c 89 f6             	mov    %r14,%rsi
  574d87:	4c 89 ea             	mov    %r13,%rdx
  574d8a:	41 54                	push   %r12
  574d8c:	41 57                	push   %r15
  574d8e:	e8 2d 0d 00 00       	call   575ac0 <<gpui::runtime::RuntimeMut<ime_cursor_cost::Input, ()>>::replace_input>
  574d93:	48 83 c4 10          	add    $0x10,%rsp
  574d97:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574d9c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  574da1:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  574da6:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  574dac:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  574db3:	00 00 
  574db5:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  574dba:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574dbf:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  574dc4:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574dc8:	75 44                	jne    574e0e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8ce>
  574dca:	4c 89 f7             	mov    %r14,%rdi
  574dcd:	48 8b 34 24          	mov    (%rsp),%rsi
  574dd1:	e8 4a e2 ff ff       	call   573020 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::refresh_ime>
  574dd6:	84 c0                	test   %al,%al
  574dd8:	0f 84 d3 02 00 00    	je     5750b1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb71>
  574dde:	4c 89 f7             	mov    %r14,%rdi
  574de1:	48 8b 34 24          	mov    (%rsp),%rsi
  574de5:	e8 c6 de ff ff       	call   572cb0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  574dea:	4d 89 ee             	mov    %r13,%r14
  574ded:	49 c1 ee 08          	shr    $0x8,%r14
  574df1:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574df6:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574dfb:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  574e00:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  574e07:	00 00 
  574e09:	e9 ae fc ff ff       	jmp    574abc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  574e0e:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
  574e13:	e9 1e 03 00 00       	jmp    575136 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbf6>
  574e18:	75 11                	jne    574e2b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  574e1a:	48 85 f6             	test   %rsi,%rsi
  574e1d:	74 23                	je     574e42 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  574e1f:	4c 39 d6             	cmp    %r10,%rsi
  574e22:	73 1c                	jae    574e40 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x900>
  574e24:	41 80 3c 37 bf       	cmpb   $0xbf,(%r15,%rsi,1)
  574e29:	7f 17                	jg     574e42 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  574e2b:	49 8b 71 08          	mov    0x8(%r9),%rsi
  574e2f:	49 8b 51 10          	mov    0x10(%r9),%rdx
  574e33:	4c 89 f7             	mov    %r14,%rdi
  574e36:	e8 15 e4 ff ff       	call   573250 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  574e3b:	e9 d7 01 00 00       	jmp    575017 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xad7>
  574e40:	75 e9                	jne    574e2b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  574e42:	4c 89 94 24 90 00 00 	mov    %r10,0x90(%rsp)
  574e49:	00 
  574e4a:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  574e4f:	49 8b 51 08          	mov    0x8(%r9),%rdx
  574e53:	49 8b 49 10          	mov    0x10(%r9),%rcx
  574e57:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574e5c:	4c 89 f6             	mov    %r14,%rsi
  574e5f:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
  574e66:	00 
  574e67:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
  574e6e:	00 
  574e6f:	e8 ac cd ff ff       	call   571c20 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  574e74:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574e79:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  574e7e:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574e82:	75 24                	jne    574ea8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x968>
  574e84:	48 8b 34 24          	mov    (%rsp),%rsi
  574e88:	48 8b 46 30          	mov    0x30(%rsi),%rax
  574e8c:	48 85 c0             	test   %rax,%rax
  574e8f:	48 89 94 24 f8 00 00 	mov    %rdx,0xf8(%rsp)
  574e96:	00 
  574e97:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  574e9c:	74 4a                	je     574ee8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x9a8>
  574e9e:	0f 10 00             	movups (%rax),%xmm0
  574ea1:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  574ea6:	eb 60                	jmp    574f08 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x9c8>
  574ea8:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  574ead:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  574eb4:	00 
  574eb5:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  574ebb:	f3 0f 6f 4c 24 30    	movdqu 0x30(%rsp),%xmm1
  574ec1:	f3 0f 7f 8c 24 c0 00 	movdqu %xmm1,0xc0(%rsp)
  574ec8:	00 00 
  574eca:	f3 0f 7f 84 24 b0 00 	movdqu %xmm0,0xb0(%rsp)
  574ed1:	00 00 
  574ed3:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  574eda:	00 
  574edb:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  574ee2:	00 
  574ee3:	e9 40 01 00 00       	jmp    575028 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  574ee8:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574eed:	4c 89 f6             	mov    %r14,%rsi
  574ef0:	e8 5b ce ff ff       	call   571d50 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::selection_at>
  574ef5:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574efa:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574efe:	48 8b 34 24          	mov    (%rsp),%rsi
  574f02:	0f 85 c9 02 00 00    	jne    5751d1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc91>
  574f08:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  574f0e:	8b 44 24 24          	mov    0x24(%rsp),%eax
  574f12:	89 84 24 e4 00 00 00 	mov    %eax,0xe4(%rsp)
  574f19:	8b 44 24 20          	mov    0x20(%rsp),%eax
  574f1d:	89 84 24 e0 00 00 00 	mov    %eax,0xe0(%rsp)
  574f24:	8b 44 24 18          	mov    0x18(%rsp),%eax
  574f28:	89 84 24 dc 00 00 00 	mov    %eax,0xdc(%rsp)
  574f2f:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  574f33:	89 84 24 d8 00 00 00 	mov    %eax,0xd8(%rsp)
  574f3a:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  574f3e:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  574f42:	48 d1 ee             	shr    $1,%rsi
  574f45:	4c 8d 6d 10          	lea    0x10(%rbp),%r13
  574f49:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
  574f4f:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
  574f55:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  574f5a:	4c 89 ef             	mov    %r13,%rdi
  574f5d:	ff 15 a5 ae 2e 00    	call   *0x2eaea5(%rip)        # 85fe08 <_DYNAMIC+0x410>
  574f63:	84 c0                	test   %al,%al
  574f65:	0f 84 ac 00 00 00    	je     575017 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xad7>
  574f6b:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  574f72:	00 
  574f73:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
  574f7a:	00 
  574f7b:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  574f81:	66 41 0f 7e c7       	movd   %xmm0,%r15d
  574f86:	66 0f 70 c0 ee       	pshufd $0xee,%xmm0,%xmm0
  574f8b:	66 0f 7e c0          	movd   %xmm0,%eax
  574f8f:	49 39 c7             	cmp    %rax,%r15
  574f92:	48 89 c2             	mov    %rax,%rdx
  574f95:	49 0f 42 d7          	cmovb  %r15,%rdx
  574f99:	48 89 c6             	mov    %rax,%rsi
  574f9c:	49 0f 47 f7          	cmova  %r15,%rsi
  574fa0:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
  574fa4:	49 d1 ed             	shr    $1,%r13
  574fa7:	89 c1                	mov    %eax,%ecx
  574fa9:	44 29 f9             	sub    %r15d,%ecx
  574fac:	41 29 c7             	sub    %eax,%r15d
  574faf:	44 0f 42 f9          	cmovb  %ecx,%r15d
  574fb3:	4d 29 fd             	sub    %r15,%r13
  574fb6:	72 4c                	jb     575004 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  574fb8:	4c 03 ac 24 90 00 00 	add    0x90(%rsp),%r13
  574fbf:	00 
  574fc0:	72 42                	jb     575004 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  574fc2:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  574fc7:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  574fcc:	48 c7 44 24 10 20 00 	movq   $0x20,0x10(%rsp)
  574fd3:	00 00 
  574fd5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574fda:	e8 a1 99 ff ff       	call   56e980 <core::ptr::drop_glue::<gpui::runtime::Error>>
  574fdf:	49 81 fd 00 80 00 00 	cmp    $0x8000,%r13
  574fe6:	0f 86 1f 02 00 00    	jbe    57520b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xccb>
  574fec:	4c 89 f7             	mov    %r14,%rdi
  574fef:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  574ff6:	00 
  574ff7:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  574ffe:	00 
  574fff:	e8 4c e2 ff ff       	call   573250 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  575004:	48 c7 84 24 a0 00 00 	movq   $0x20,0xa0(%rsp)
  57500b:	00 20 00 00 00 
  575010:	bd 20 00 00 00       	mov    $0x20,%ebp
  575015:	eb 11                	jmp    575028 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  575017:	48 c7 84 24 a0 00 00 	movq   $0x1a,0xa0(%rsp)
  57501e:	00 1a 00 00 00 
  575023:	bd 1a 00 00 00       	mov    $0x1a,%ebp
  575028:	48 8b 34 24          	mov    (%rsp),%rsi
  57502c:	4c 89 f7             	mov    %r14,%rdi
  57502f:	e8 7c dc ff ff       	call   572cb0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  575034:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  575038:	75 3e                	jne    575078 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb38>
  57503a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  57503f:	4c 89 f6             	mov    %r14,%rsi
  575042:	e8 79 58 01 00       	call   58a8c0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  575047:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  57504c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  575051:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  575057:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  57505c:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  575061:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  575066:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  57506a:	75 3a                	jne    5750a6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb66>
  57506c:	4d 89 ee             	mov    %r13,%r14
  57506f:	49 c1 ee 08          	shr    $0x8,%r14
  575073:	e9 08 fa ff ff       	jmp    574a80 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x540>
  575078:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  57507f:	00 
  575080:	f3 0f 6f 8c 24 b0 00 	movdqu 0xb0(%rsp),%xmm1
  575087:	00 00 
  575089:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  575090:	00 
  575091:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
  575098:	00 
  575099:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
  5750a0:	00 
  5750a1:	e9 74 fa ff ff       	jmp    574b1a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  5750a6:	4c 89 f9             	mov    %r15,%rcx
  5750a9:	48 89 f8             	mov    %rdi,%rax
  5750ac:	e9 69 fa ff ff       	jmp    574b1a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  5750b1:	4c 89 f7             	mov    %r14,%rdi
  5750b4:	e8 07 de ff ff       	call   572ec0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::reclaim_ime>
  5750b9:	4c 89 fd             	mov    %r15,%rbp
  5750bc:	4c 8b 3c 24          	mov    (%rsp),%r15
  5750c0:	49 8b 7f 20          	mov    0x20(%r15),%rdi
  5750c4:	e8 f7 96 ff ff       	call   56e7c0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  5750c9:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  5750cd:	e8 ae 5d ff ff       	call   56ae80 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  5750d2:	4d 89 ee             	mov    %r13,%r14
  5750d5:	49 c1 ee 08          	shr    $0x8,%r14
  5750d9:	be 38 00 00 00       	mov    $0x38,%esi
  5750de:	ba 08 00 00 00       	mov    $0x8,%edx
  5750e3:	4c 89 ff             	mov    %r15,%rdi
  5750e6:	ff 15 64 ab 2e 00    	call   *0x2eab64(%rip)        # 85fc50 <_DYNAMIC+0x258>
  5750ec:	31 c0                	xor    %eax,%eax
  5750ee:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  5750f3:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  5750f8:	49 89 ef             	mov    %rbp,%r15
  5750fb:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  575102:	00 00 
  575104:	e9 b3 f9 ff ff       	jmp    574abc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  575109:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  57510e:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  575113:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  575119:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  575120:	00 00 
  575122:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  575127:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  57512c:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  575131:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  575136:	4c 8b 3c 24          	mov    (%rsp),%r15
  57513a:	49 8b 7f 20          	mov    0x20(%r15),%rdi
  57513e:	f6 07 01             	testb  $0x1,(%rdi)
  575141:	75 17                	jne    57515a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  575143:	48 8b 47 08          	mov    0x8(%rdi),%rax
  575147:	a8 01                	test   $0x1,%al
  575149:	75 0f                	jne    57515a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  57514b:	48 8d 47 08          	lea    0x8(%rdi),%rax
  57514f:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  575154:	0f 84 bc 06 00 00    	je     575816 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12d6>
  57515a:	4d 8b 7f 30          	mov    0x30(%r15),%r15
  57515e:	4d 85 ff             	test   %r15,%r15
  575161:	74 33                	je     575196 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc56>
  575163:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  575167:	f6 07 01             	testb  $0x1,(%rdi)
  57516a:	75 17                	jne    575183 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  57516c:	48 8b 47 08          	mov    0x8(%rdi),%rax
  575170:	a8 01                	test   $0x1,%al
  575172:	75 0f                	jne    575183 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  575174:	48 8d 47 08          	lea    0x8(%rdi),%rax
  575178:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  57517d:	0f 84 a2 06 00 00    	je     575825 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12e5>
  575183:	be 60 00 00 00       	mov    $0x60,%esi
  575188:	ba 08 00 00 00       	mov    $0x8,%edx
  57518d:	4c 89 ff             	mov    %r15,%rdi
  575190:	ff 15 ba aa 2e 00    	call   *0x2eaaba(%rip)        # 85fc50 <_DYNAMIC+0x258>
  575196:	4d 89 e7             	mov    %r12,%r15
  575199:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  5751a0:	be 38 00 00 00       	mov    $0x38,%esi
  5751a5:	ba 08 00 00 00       	mov    $0x8,%edx
  5751aa:	48 8b 3c 24          	mov    (%rsp),%rdi
  5751ae:	ff 15 9c aa 2e 00    	call   *0x2eaa9c(%rip)        # 85fc50 <_DYNAMIC+0x258>
  5751b4:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  5751b9:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  5751be:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  5751c3:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  5751ca:	00 00 
  5751cc:	e9 f3 f4 ff ff       	jmp    5746c4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  5751d1:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  5751d7:	f3 0f 6f 4c 24 28    	movdqu 0x28(%rsp),%xmm1
  5751dd:	f3 0f 6f 54 24 38    	movdqu 0x38(%rsp),%xmm2
  5751e3:	f3 0f 7f 94 24 c8 00 	movdqu %xmm2,0xc8(%rsp)
  5751ea:	00 00 
  5751ec:	f3 0f 7f 8c 24 b8 00 	movdqu %xmm1,0xb8(%rsp)
  5751f3:	00 00 
  5751f5:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  5751fc:	00 
  5751fd:	f3 0f 7f 84 24 a8 00 	movdqu %xmm0,0xa8(%rsp)
  575204:	00 00 
  575206:	e9 21 fe ff ff       	jmp    57502c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xaec>
  57520b:	49 8b b6 a8 02 00 00 	mov    0x2a8(%r14),%rsi
  575212:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  575219:	00 
  57521a:	48 39 f7             	cmp    %rsi,%rdi
  57521d:	0f 83 6b 06 00 00    	jae    57588e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x134e>
  575223:	49 8b 86 a0 02 00 00 	mov    0x2a0(%r14),%rax
  57522a:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  57522e:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
  575232:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  575239:	00 
  57523a:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  57523f:	48 85 f6             	test   %rsi,%rsi
  575242:	0f 85 d1 00 00 00    	jne    575319 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xdd9>
  575248:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
  57524c:	75 2e                	jne    57527c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  57524e:	48 8b 45 08          	mov    0x8(%rbp),%rax
  575252:	a8 01                	test   $0x1,%al
  575254:	75 26                	jne    57527c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  575256:	b8 02 00 00 00       	mov    $0x2,%eax
  57525b:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  575261:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  575268:	00 00 80 
  57526b:	48 ff c1             	inc    %rcx
  57526e:	48 21 c1             	and    %rax,%rcx
  575271:	48 f7 d9             	neg    %rcx
  575274:	71 06                	jno    57527c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  575276:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  57527c:	48 8b 04 24          	mov    (%rsp),%rax
  575280:	4c 8b 28             	mov    (%rax),%r13
  575283:	ff 15 b7 a9 2e 00    	call   *0x2ea9b7(%rip)        # 85fc40 <_DYNAMIC+0x248>
  575289:	bf 60 00 00 00       	mov    $0x60,%edi
  57528e:	be 08 00 00 00       	mov    $0x8,%esi
  575293:	ff 15 af a9 2e 00    	call   *0x2ea9af(%rip)        # 85fc48 <_DYNAMIC+0x250>
  575299:	48 85 c0             	test   %rax,%rax
  57529c:	0f 84 c0 05 00 00    	je     575862 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1322>
  5752a2:	48 89 c6             	mov    %rax,%rsi
  5752a5:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  5752aa:	48 89 c8             	mov    %rcx,%rax
  5752ad:	48 c1 e0 20          	shl    $0x20,%rax
  5752b1:	48 09 c8             	or     %rcx,%rax
  5752b4:	66 0f 6e 84 24 dc 00 	movd   0xdc(%rsp),%xmm0
  5752bb:	00 00 
  5752bd:	66 0f 6e 8c 24 d8 00 	movd   0xd8(%rsp),%xmm1
  5752c4:	00 00 
  5752c6:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
  5752ca:	66 0f 6e 8c 24 e0 00 	movd   0xe0(%rsp),%xmm1
  5752d1:	00 00 
  5752d3:	66 0f 6e 94 24 e4 00 	movd   0xe4(%rsp),%xmm2
  5752da:	00 00 
  5752dc:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
  5752e0:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
  5752e4:	f3 0f 7f 06          	movdqu %xmm0,(%rsi)
  5752e8:	f3 0f 7f 46 10       	movdqu %xmm0,0x10(%rsi)
  5752ed:	f3 0f 7f 46 20       	movdqu %xmm0,0x20(%rsi)
  5752f2:	48 89 6e 30          	mov    %rbp,0x30(%rsi)
  5752f6:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  5752fd:	00 
  5752fe:	48 89 4e 38          	mov    %rcx,0x38(%rsi)
  575302:	4c 89 6e 40          	mov    %r13,0x40(%rsi)
  575306:	48 89 46 48          	mov    %rax,0x48(%rsi)
  57530a:	c7 46 50 00 00 00 00 	movl   $0x0,0x50(%rsi)
  575311:	48 8b 04 24          	mov    (%rsp),%rax
  575315:	48 89 70 30          	mov    %rsi,0x30(%rax)
  575319:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
  575320:	00 00 
  575322:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  575327:	0f 84 80 00 00 00    	je     5753ad <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe6d>
  57532d:	48 8b 46 48          	mov    0x48(%rsi),%rax
  575331:	89 c2                	mov    %eax,%edx
  575333:	48 c1 e8 20          	shr    $0x20,%rax
  575337:	48 89 c1             	mov    %rax,%rcx
  57533a:	48 29 d1             	sub    %rdx,%rcx
  57533d:	0f 85 cc 00 00 00    	jne    57540f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xecf>
  575343:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  575347:	48 d1 ee             	shr    $1,%rsi
  57534a:	4c 8d 05 af 29 2d 00 	lea    0x2d29af(%rip),%r8        # 847d00 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa40>
  575351:	48 39 74 24 78       	cmp    %rsi,0x78(%rsp)
  575356:	0f 87 d8 04 00 00    	ja     575834 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  57535c:	48 39 74 24 60       	cmp    %rsi,0x60(%rsp)
  575361:	74 35                	je     575398 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe58>
  575363:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  575369:	74 13                	je     57537e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe3e>
  57536b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575370:	48 8d 4d 10          	lea    0x10(%rbp),%rcx
  575374:	80 3c 01 bf          	cmpb   $0xbf,(%rcx,%rax,1)
  575378:	0f 8e b6 04 00 00    	jle    575834 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  57537e:	48 39 74 24 78       	cmp    %rsi,0x78(%rsp)
  575383:	74 13                	je     575398 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe58>
  575385:	48 8d 45 10          	lea    0x10(%rbp),%rax
  575389:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  57538e:	80 3c 08 bf          	cmpb   $0xbf,(%rax,%rcx,1)
  575392:	0f 8e 9c 04 00 00    	jle    575834 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  575398:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  57539d:	48 8d 4d 10          	lea    0x10(%rbp),%rcx
  5753a1:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
  5753a5:	4c 89 f9             	mov    %r15,%rcx
  5753a8:	e9 ae 00 00 00       	jmp    57545b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf1b>
  5753ad:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
  5753b1:	48 8b 45 00          	mov    0x0(%rbp),%rax
  5753b5:	48 39 e9             	cmp    %rbp,%rcx
  5753b8:	75 10                	jne    5753ca <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe8a>
  5753ba:	48 8b 09             	mov    (%rcx),%rcx
  5753bd:	48 31 c1             	xor    %rax,%rcx
  5753c0:	48 83 f9 01          	cmp    $0x1,%rcx
  5753c4:	0f 86 e7 00 00 00    	jbe    5754b1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf71>
  5753ca:	a8 01                	test   $0x1,%al
  5753cc:	75 2e                	jne    5753fc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  5753ce:	48 8b 45 08          	mov    0x8(%rbp),%rax
  5753d2:	a8 01                	test   $0x1,%al
  5753d4:	75 26                	jne    5753fc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  5753d6:	b8 02 00 00 00       	mov    $0x2,%eax
  5753db:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  5753e1:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  5753e8:	00 00 80 
  5753eb:	48 ff c1             	inc    %rcx
  5753ee:	48 21 c1             	and    %rax,%rcx
  5753f1:	48 f7 d9             	neg    %rcx
  5753f4:	71 06                	jno    5753fc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  5753f6:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  5753fc:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  575401:	48 8b 78 30          	mov    0x30(%rax),%rdi
  575405:	e8 b6 93 ff ff       	call   56e7c0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  57540a:	e9 9c 01 00 00       	jmp    5755ab <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x106b>
  57540f:	48 8b 7e 30          	mov    0x30(%rsi),%rdi
  575413:	48 8b 37             	mov    (%rdi),%rsi
  575416:	48 d1 ee             	shr    $1,%rsi
  575419:	48 83 c7 10          	add    $0x10,%rdi
  57541d:	4c 8d 05 c4 28 2d 00 	lea    0x2d28c4(%rip),%r8        # 847ce8 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa28>
  575424:	39 d0                	cmp    %edx,%eax
  575426:	0f 82 14 04 00 00    	jb     575840 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  57542c:	48 39 f0             	cmp    %rsi,%rax
  57542f:	0f 87 0b 04 00 00    	ja     575840 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  575435:	48 39 f2             	cmp    %rsi,%rdx
  575438:	74 1e                	je     575458 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf18>
  57543a:	48 85 d2             	test   %rdx,%rdx
  57543d:	74 0a                	je     575449 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf09>
  57543f:	80 3c 17 bf          	cmpb   $0xbf,(%rdi,%rdx,1)
  575443:	0f 8e f7 03 00 00    	jle    575840 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  575449:	48 39 f0             	cmp    %rsi,%rax
  57544c:	74 0a                	je     575458 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf18>
  57544e:	80 3c 07 bf          	cmpb   $0xbf,(%rdi,%rax,1)
  575452:	0f 8e e8 03 00 00    	jle    575840 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  575458:	48 01 d7             	add    %rdx,%rdi
  57545b:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  575462:	00 
  575463:	48 39 ca             	cmp    %rcx,%rdx
  575466:	75 12                	jne    57547a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf3a>
  575468:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  57546f:	00 
  575470:	ff 15 62 a8 2e 00    	call   *0x2ea862(%rip)        # 85fcd8 <bcmp@GLIBC_2.2.5>
  575476:	85 c0                	test   %eax,%eax
  575478:	74 37                	je     5754b1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf71>
  57547a:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  57547e:	48 d1 ee             	shr    $1,%rsi
  575481:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575486:	48 85 c0             	test   %rax,%rax
  575489:	74 68                	je     5754f3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfb3>
  57548b:	48 39 f0             	cmp    %rsi,%rax
  57548e:	73 5c                	jae    5754ec <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfac>
  575490:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575495:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  57549c:	00 
  57549d:	80 3c 01 c0          	cmpb   $0xc0,(%rcx,%rax,1)
  5754a1:	7d 50                	jge    5754f3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfb3>
  5754a3:	4c 8d 05 6e 28 2d 00 	lea    0x2d286e(%rip),%r8        # 847d18 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa58>
  5754aa:	31 d2                	xor    %edx,%edx
  5754ac:	e9 9c 03 00 00       	jmp    57584d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x130d>
  5754b1:	45 31 ff             	xor    %r15d,%r15d
  5754b4:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  5754b9:	48 01 8c 24 90 00 00 	add    %rcx,0x90(%rsp)
  5754c0:	00 
  5754c1:	41 f6 c4 01          	test   $0x1,%r12b
  5754c5:	0f 85 03 01 00 00    	jne    5755ce <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x108e>
  5754cb:	45 31 ed             	xor    %r13d,%r13d
  5754ce:	e9 19 01 00 00       	jmp    5755ec <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x10ac>
  5754d3:	48 8d 3d 56 13 ad ff 	lea    -0x52ecaa(%rip),%rdi        # 46830 <anon.72786b07d16308d9adbd85e9b0d1bfa8.348.llvm.9246593494314379644+0x2d50>
  5754da:	48 8d 15 67 28 2d 00 	lea    0x2d2867(%rip),%rdx        # 847d48 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa88>
  5754e1:	be 17 00 00 00       	mov    $0x17,%esi
  5754e6:	ff 15 d4 a8 2e 00    	call   *0x2ea8d4(%rip)        # 85fdc0 <_DYNAMIC+0x3c8>
  5754ec:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  5754f1:	75 b0                	jne    5754a3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf63>
  5754f3:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  5754f8:	48 85 d2             	test   %rdx,%rdx
  5754fb:	74 3a                	je     575537 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xff7>
  5754fd:	48 39 d6             	cmp    %rdx,%rsi
  575500:	76 29                	jbe    57552b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfeb>
  575502:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  575509:	00 
  57550a:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  57550f:	80 3c 10 c0          	cmpb   $0xc0,(%rax,%rdx,1)
  575513:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575518:	7d 1d                	jge    575537 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xff7>
  57551a:	4c 8d 05 0f 28 2d 00 	lea    0x2d280f(%rip),%r8        # 847d30 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa70>
  575521:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  575526:	e9 22 03 00 00       	jmp    57584d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x130d>
  57552b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575530:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  575535:	75 e3                	jne    57551a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfda>
  575537:	48 29 d6             	sub    %rdx,%rsi
  57553a:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  575541:	00 
  575542:	48 01 ca             	add    %rcx,%rdx
  575545:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  57554a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  57554f:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  575556:	00 
  575557:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  57555c:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  575563:	00 
  575564:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  575569:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  57556e:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  575573:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  575578:	ff 15 aa a8 2e 00    	call   *0x2ea8aa(%rip)        # 85fe28 <_DYNAMIC+0x430>
  57557e:	48 89 c5             	mov    %rax,%rbp
  575581:	48 c7 44 24 10 20 00 	movq   $0x20,0x10(%rsp)
  575588:	00 00 
  57558a:	48 85 c0             	test   %rax,%rax
  57558d:	0f 84 71 fa ff ff    	je     575004 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  575593:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  575598:	e8 e3 93 ff ff       	call   56e980 <core::ptr::drop_glue::<gpui::runtime::Error>>
  57559d:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  5755a2:	48 8b 78 30          	mov    0x30(%rax),%rdi
  5755a6:	e8 15 92 ff ff       	call   56e7c0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  5755ab:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  5755b0:	48 89 68 30          	mov    %rbp,0x30(%rax)
  5755b4:	41 b7 01             	mov    $0x1,%r15b
  5755b7:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  5755bc:	48 01 8c 24 90 00 00 	add    %rcx,0x90(%rsp)
  5755c3:	00 
  5755c4:	41 f6 c4 01          	test   $0x1,%r12b
  5755c8:	0f 84 fd fe ff ff    	je     5754cb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf8b>
  5755ce:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  5755d3:	44 8b 60 08          	mov    0x8(%rax),%r12d
  5755d7:	41 01 cc             	add    %ecx,%r12d
  5755da:	8b 40 10             	mov    0x10(%rax),%eax
  5755dd:	01 c8                	add    %ecx,%eax
  5755df:	48 c1 e0 20          	shl    $0x20,%rax
  5755e3:	49 09 c4             	or     %rax,%r12
  5755e6:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  5755ec:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  5755f1:	48 8b 70 30          	mov    0x30(%rax),%rsi
  5755f5:	48 8b 16             	mov    (%rsi),%rdx
  5755f8:	48 d1 ea             	shr    $1,%rdx
  5755fb:	48 83 c6 10          	add    $0x10,%rsi
  5755ff:	44 89 ac 24 10 01 00 	mov    %r13d,0x110(%rsp)
  575606:	00 
  575607:	4c 89 a4 24 14 01 00 	mov    %r12,0x114(%rsp)
  57560e:	00 
  57560f:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  575614:	4c 8d 8c 24 10 01 00 	lea    0x110(%rsp),%r9
  57561b:	00 
  57561c:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  575623:	00 
  575624:	ff 15 06 a8 2e 00    	call   *0x2ea806(%rip)        # 85fe30 <_DYNAMIC+0x438>
  57562a:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  57562f:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  575634:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
  57563b:	00 
  57563c:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  575641:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
  575648:	00 
  575649:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  57564d:	0f 85 f5 00 00 00    	jne    575748 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1208>
  575653:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
  57565a:	00 
  57565b:	66 0f 6f 8c 24 50 01 	movdqa 0x150(%rsp),%xmm1
  575662:	00 00 
  575664:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  57566b:	00 
  57566c:	66 0f 7f 8c 24 10 01 	movdqa %xmm1,0x110(%rsp)
  575673:	00 00 
  575675:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  57567a:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  57567e:	66 0f 6f 84 24 10 01 	movdqa 0x110(%rsp),%xmm0
  575685:	00 00 
  575687:	f3 0f 7f 42 20       	movdqu %xmm0,0x20(%rdx)
  57568c:	48 8b 04 24          	mov    (%rsp),%rax
  575690:	48 8b 00             	mov    (%rax),%rax
  575693:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  57569a:	00 
  57569b:	48 c1 e1 20          	shl    $0x20,%rcx
  57569f:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  5756a4:	48 09 f1             	or     %rsi,%rcx
  5756a7:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
  5756ae:	00 
  5756af:	48 89 7a 38          	mov    %rdi,0x38(%rdx)
  5756b3:	48 89 42 40          	mov    %rax,0x40(%rdx)
  5756b7:	48 89 4a 48          	mov    %rcx,0x48(%rdx)
  5756bb:	44 89 6a 50          	mov    %r13d,0x50(%rdx)
  5756bf:	4c 89 62 54          	mov    %r12,0x54(%rdx)
  5756c3:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  5756c8:	ff 15 2a a7 2e 00    	call   *0x2ea72a(%rip)        # 85fdf8 <_DYNAMIC+0x400>
  5756ce:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  5756d3:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
  5756d7:	0f b6 44 24 1c       	movzbl 0x1c(%rsp),%eax
  5756dc:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5756e0:	0f 85 a0 00 00 00    	jne    575786 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1246>
  5756e6:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
  5756ea:	88 44 24 14          	mov    %al,0x14(%rsp)
  5756ee:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
  5756f2:	88 44 24 1c          	mov    %al,0x1c(%rsp)
  5756f6:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  5756fb:	4c 89 f7             	mov    %r14,%rdi
  5756fe:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  575705:	00 
  575706:	e8 a5 c7 ff ff       	call   571eb0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::set_selection>
  57570b:	45 84 ff             	test   %r15b,%r15b
  57570e:	74 18                	je     575728 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x11e8>
  575710:	4c 89 f7             	mov    %r14,%rdi
  575713:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  57571a:	00 
  57571b:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  575722:	00 
  575723:	e8 28 db ff ff       	call   573250 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  575728:	41 c6 86 2b 07 00 00 	movb   $0x1,0x72b(%r14)
  57572f:	01 
  575730:	48 c7 84 24 a0 00 00 	movq   $0xfffffffffffffffe,0xa0(%rsp)
  575737:	00 fe ff ff ff 
  57573c:	48 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%rbp
  575743:	e9 e0 f8 ff ff       	jmp    575028 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  575748:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  57574d:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
  575754:	00 
  575755:	66 0f 6f 84 24 40 01 	movdqa 0x140(%rsp),%xmm0
  57575c:	00 00 
  57575e:	66 0f 6f 8c 24 50 01 	movdqa 0x150(%rsp),%xmm1
  575765:	00 00 
  575767:	f3 0f 7f 84 24 a8 00 	movdqu %xmm0,0xa8(%rsp)
  57576e:	00 00 
  575770:	f3 0f 7f 8c 24 b8 00 	movdqu %xmm1,0xb8(%rsp)
  575777:	00 00 
  575779:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  575780:	00 
  575781:	e9 a2 f8 ff ff       	jmp    575028 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  575786:	f3 0f 6f 44 24 1d    	movdqu 0x1d(%rsp),%xmm0
  57578c:	f3 0f 6f 4c 24 2d    	movdqu 0x2d(%rsp),%xmm1
  575792:	f3 0f 6f 54 24 38    	movdqu 0x38(%rsp),%xmm2
  575798:	f3 0f 7f 94 24 c8 00 	movdqu %xmm2,0xc8(%rsp)
  57579f:	00 00 
  5757a1:	f3 0f 7f 8c 24 bd 00 	movdqu %xmm1,0xbd(%rsp)
  5757a8:	00 00 
  5757aa:	f3 0f 7f 84 24 ad 00 	movdqu %xmm0,0xad(%rsp)
  5757b1:	00 00 
  5757b3:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  5757ba:	00 
  5757bb:	89 8c 24 a8 00 00 00 	mov    %ecx,0xa8(%rsp)
  5757c2:	88 84 24 ac 00 00 00 	mov    %al,0xac(%rsp)
  5757c9:	e9 5a f8 ff ff       	jmp    575028 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  5757ce:	48 8d 3d db 1d 2d 00 	lea    0x2d1ddb(%rip),%rdi        # 8475b0 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x2f0>
  5757d5:	ff 15 9d a4 2e 00    	call   *0x2ea49d(%rip)        # 85fc78 <_DYNAMIC+0x280>
  5757db:	48 8d 3d 56 23 2d 00 	lea    0x2d2356(%rip),%rdi        # 847b38 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x878>
  5757e2:	ff 15 90 a4 2e 00    	call   *0x2ea490(%rip)        # 85fc78 <_DYNAMIC+0x280>
  5757e8:	bf 08 00 00 00       	mov    $0x8,%edi
  5757ed:	be 38 00 00 00       	mov    $0x38,%esi
  5757f2:	ff 15 70 a4 2e 00    	call   *0x2ea470(%rip)        # 85fc68 <_DYNAMIC+0x270>
  5757f8:	e9 9e 00 00 00       	jmp    57589b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  5757fd:	48 8d 3d d0 10 ad ff 	lea    -0x52ef30(%rip),%rdi        # 468d4 <anon.72786b07d16308d9adbd85e9b0d1bfa8.348.llvm.9246593494314379644+0x2df4>
  575804:	48 8d 15 e5 25 2d 00 	lea    0x2d25e5(%rip),%rdx        # 847df0 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xb30>
  57580b:	be 83 00 00 00       	mov    $0x83,%esi
  575810:	ff 15 7a a4 2e 00    	call   *0x2ea47a(%rip)        # 85fc90 <_DYNAMIC+0x298>
  575816:	48 8b 47 08          	mov    0x8(%rdi),%rax
  57581a:	ff 15 88 a4 2e 00    	call   *0x2ea488(%rip)        # 85fca8 <_DYNAMIC+0x2b0>
  575820:	e9 35 f9 ff ff       	jmp    57515a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  575825:	48 8b 47 08          	mov    0x8(%rdi),%rax
  575829:	ff 15 79 a4 2e 00    	call   *0x2ea479(%rip)        # 85fca8 <_DYNAMIC+0x2b0>
  57582f:	e9 4f f9 ff ff       	jmp    575183 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  575834:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  575839:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  57583e:	eb 08                	jmp    575848 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1308>
  575840:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  575847:	00 
  575848:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  57584d:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  575854:	00 
  575855:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  57585a:	ff 15 d8 a5 2e 00    	call   *0x2ea5d8(%rip)        # 85fe38 <_DYNAMIC+0x440>
  575860:	eb 39                	jmp    57589b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  575862:	bf 08 00 00 00       	mov    $0x8,%edi
  575867:	be 60 00 00 00       	mov    $0x60,%esi
  57586c:	ff 15 f6 a3 2e 00    	call   *0x2ea3f6(%rip)        # 85fc68 <_DYNAMIC+0x270>
  575872:	eb 27                	jmp    57589b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  575874:	48 8d 15 8d 22 2d 00 	lea    0x2d228d(%rip),%rdx        # 847b08 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x848>
  57587b:	ff 15 1f a5 2e 00    	call   *0x2ea51f(%rip)        # 85fda0 <_DYNAMIC+0x3a8>
  575881:	48 8d 15 10 1d 2d 00 	lea    0x2d1d10(%rip),%rdx        # 847598 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x2d8>
  575888:	ff 15 12 a5 2e 00    	call   *0x2ea512(%rip)        # 85fda0 <_DYNAMIC+0x3a8>
  57588e:	48 8d 15 3b 24 2d 00 	lea    0x2d243b(%rip),%rdx        # 847cd0 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa10>
  575895:	ff 15 05 a5 2e 00    	call   *0x2ea505(%rip)        # 85fda0 <_DYNAMIC+0x3a8>
  57589b:	0f 0b                	ud2
  57589d:	48 89 c3             	mov    %rax,%rbx
  5758a0:	be 60 00 00 00       	mov    $0x60,%esi
  5758a5:	ba 08 00 00 00       	mov    $0x8,%edx
  5758aa:	4c 89 ff             	mov    %r15,%rdi
  5758ad:	ff 15 9d a3 2e 00    	call   *0x2ea39d(%rip)        # 85fc50 <_DYNAMIC+0x258>
  5758b3:	e9 93 00 00 00       	jmp    57594b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  5758b8:	48 89 c3             	mov    %rax,%rbx
  5758bb:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  5758bf:	e8 bc 55 ff ff       	call   56ae80 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  5758c4:	e9 82 00 00 00       	jmp    57594b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  5758c9:	eb 00                	jmp    5758cb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x138b>
  5758cb:	48 89 c3             	mov    %rax,%rbx
  5758ce:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  5758d3:	48 89 68 30          	mov    %rbp,0x30(%rax)
  5758d7:	eb 58                	jmp    575931 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  5758d9:	48 89 c3             	mov    %rax,%rbx
  5758dc:	eb 6d                	jmp    57594b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  5758de:	48 89 c3             	mov    %rax,%rbx
  5758e1:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  5758e5:	e8 96 55 ff ff       	call   56ae80 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  5758ea:	eb 5f                	jmp    57594b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  5758ec:	48 89 c3             	mov    %rax,%rbx
  5758ef:	48 c7 45 30 00 00 00 	movq   $0x0,0x30(%rbp)
  5758f6:	00 
  5758f7:	eb 38                	jmp    575931 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  5758f9:	48 89 c3             	mov    %rax,%rbx
  5758fc:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  575900:	0f 84 89 00 00 00    	je     57598f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x144f>
  575906:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  57590d:	00 
  57590e:	e8 6d 90 ff ff       	call   56e980 <core::ptr::drop_glue::<gpui::runtime::Error>>
  575913:	48 89 df             	mov    %rbx,%rdi
  575916:	e8 05 05 2d 00       	call   845e20 <_Unwind_Resume@plt>
  57591b:	48 89 c3             	mov    %rax,%rbx
  57591e:	48 89 ef             	mov    %rbp,%rdi
  575921:	e8 ba 62 ff ff       	call   56bbe0 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::editing::LogicalSelection>>>
  575926:	eb 09                	jmp    575931 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  575928:	ff 15 5a a3 2e 00    	call   *0x2ea35a(%rip)        # 85fc88 <_DYNAMIC+0x290>
  57592e:	48 89 c3             	mov    %rax,%rbx
  575931:	48 8b 04 24          	mov    (%rsp),%rax
  575935:	48 8b 78 20          	mov    0x20(%rax),%rdi
  575939:	e8 82 8e ff ff       	call   56e7c0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  57593e:	48 8b 04 24          	mov    (%rsp),%rax
  575942:	48 8b 78 30          	mov    0x30(%rax),%rdi
  575946:	e8 35 55 ff ff       	call   56ae80 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  57594b:	be 38 00 00 00       	mov    $0x38,%esi
  575950:	ba 08 00 00 00       	mov    $0x8,%edx
  575955:	48 8b 3c 24          	mov    (%rsp),%rdi
  575959:	ff 15 f1 a2 2e 00    	call   *0x2ea2f1(%rip)        # 85fc50 <_DYNAMIC+0x258>
  57595f:	48 89 df             	mov    %rbx,%rdi
  575962:	e8 b9 04 2d 00       	call   845e20 <_Unwind_Resume@plt>
  575967:	ff 15 1b a3 2e 00    	call   *0x2ea31b(%rip)        # 85fc88 <_DYNAMIC+0x290>
  57596d:	48 89 c3             	mov    %rax,%rbx
  575970:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  575975:	e8 06 90 ff ff       	call   56e980 <core::ptr::drop_glue::<gpui::runtime::Error>>
  57597a:	48 89 df             	mov    %rbx,%rdi
  57597d:	e8 9e 04 2d 00       	call   845e20 <_Unwind_Resume@plt>
  575982:	48 89 c3             	mov    %rax,%rbx
  575985:	48 89 ef             	mov    %rbp,%rdi
  575988:	31 f6                	xor    %esi,%esi
  57598a:	e8 31 a1 ff ff       	call   56fac0 <core::ptr::drop_glue::<gpui::runtime::ime::Active>>
  57598f:	48 89 df             	mov    %rbx,%rdi
  575992:	e8 89 04 2d 00       	call   845e20 <_Unwind_Resume@plt>
  575997:	ff 15 eb a2 2e 00    	call   *0x2ea2eb(%rip)        # 85fc88 <_DYNAMIC+0x290>
