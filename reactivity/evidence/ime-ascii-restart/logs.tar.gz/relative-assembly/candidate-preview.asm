
/tmp/gpui-ime-ascii-relative-release-executable-root/ime_cursor_cost:     file format elf64-x86-64


Disassembly of section .text:

00000000005ced00 <gpui::runtime::ime::preview_selections>:
  5ced00:	55                   	push   %rbp
  5ced01:	41 57                	push   %r15
  5ced03:	41 56                	push   %r14
  5ced05:	41 55                	push   %r13
  5ced07:	41 54                	push   %r12
  5ced09:	53                   	push   %rbx
  5ced0a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
  5ced11:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  5ced16:	49 89 d3             	mov    %rdx,%r11
  5ced19:	49 89 fa             	mov    %rdi,%r10
  5ced1c:	48 39 d1             	cmp    %rdx,%rcx
  5ced1f:	76 50                	jbe    5ced71 <gpui::runtime::ime::preview_selections+0x71>
  5ced21:	31 db                	xor    %ebx,%ebx
  5ced23:	31 d2                	xor    %edx,%edx
  5ced25:	49 8b 41 04          	mov    0x4(%r9),%rax
  5ced29:	49 89 c6             	mov    %rax,%r14
  5ced2c:	49 c1 ee 20          	shr    $0x20,%r14
  5ced30:	41 80 39 00          	cmpb   $0x0,(%r9)
  5ced34:	4c 0f 44 f1          	cmove  %rcx,%r14
  5ced38:	41 89 c7             	mov    %eax,%r15d
  5ced3b:	4c 0f 44 f9          	cmove  %rcx,%r15
  5ced3f:	48 85 d2             	test   %rdx,%rdx
  5ced42:	0f 84 03 01 00 00    	je     5cee4b <gpui::runtime::ime::preview_selections+0x14b>
  5ced48:	49 39 d3             	cmp    %rdx,%r11
  5ced4b:	0f 86 f4 00 00 00    	jbe    5cee45 <gpui::runtime::ime::preview_selections+0x145>
  5ced51:	80 3c 16 c0          	cmpb   $0xc0,(%rsi,%rdx,1)
  5ced55:	0f 8d f0 00 00 00    	jge    5cee4b <gpui::runtime::ime::preview_selections+0x14b>
  5ced5b:	4c 8d 05 6e b3 27 00 	lea    0x27b36e(%rip),%r8        # 84a0d0 <anon.cd78562aee332f96f44b11cbbe34fbad.7.llvm.11188030356063827792+0x128>
  5ced62:	48 89 f7             	mov    %rsi,%rdi
  5ced65:	4c 89 de             	mov    %r11,%rsi
  5ced68:	4c 89 d9             	mov    %r11,%rcx
  5ced6b:	ff 15 c7 10 29 00    	call   *0x2910c7(%rip)        # 85fe38 <_DYNAMIC+0x440>
  5ced71:	48 83 f9 40          	cmp    $0x40,%rcx
  5ced75:	0f 83 98 02 00 00    	jae    5cf013 <gpui::runtime::ime::preview_selections+0x313>
  5ced7b:	48 89 c8             	mov    %rcx,%rax
  5ced7e:	48 83 e0 38          	and    $0x38,%rax
  5ced82:	74 2f                	je     5cedb3 <gpui::runtime::ime::preview_selections+0xb3>
  5ced84:	31 db                	xor    %ebx,%ebx
  5ced86:	48 ba 80 80 80 80 80 	movabs $0x8080808080808080,%rdx
  5ced8d:	80 80 80 
  5ced90:	31 ff                	xor    %edi,%edi
  5ced92:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  5ced99:	1f 84 00 00 00 00 00 
  5ceda0:	48 85 14 3e          	test   %rdx,(%rsi,%rdi,1)
  5ceda4:	0f 85 79 ff ff ff    	jne    5ced23 <gpui::runtime::ime::preview_selections+0x23>
  5cedaa:	48 83 c7 08          	add    $0x8,%rdi
  5cedae:	48 39 f8             	cmp    %rdi,%rax
  5cedb1:	75 ed                	jne    5ceda0 <gpui::runtime::ime::preview_selections+0xa0>
  5cedb3:	89 ca                	mov    %ecx,%edx
  5cedb5:	83 e2 07             	and    $0x7,%edx
  5cedb8:	0f 84 c4 02 00 00    	je     5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cedbe:	80 3c 06 00          	cmpb   $0x0,(%rsi,%rax,1)
  5cedc2:	0f 88 59 ff ff ff    	js     5ced21 <gpui::runtime::ime::preview_selections+0x21>
  5cedc8:	83 fa 01             	cmp    $0x1,%edx
  5cedcb:	0f 84 b1 02 00 00    	je     5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cedd1:	80 7c 06 01 00       	cmpb   $0x0,0x1(%rsi,%rax,1)
  5cedd6:	0f 88 45 ff ff ff    	js     5ced21 <gpui::runtime::ime::preview_selections+0x21>
  5ceddc:	83 fa 02             	cmp    $0x2,%edx
  5ceddf:	0f 84 9d 02 00 00    	je     5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cede5:	80 7c 06 02 00       	cmpb   $0x0,0x2(%rsi,%rax,1)
  5cedea:	0f 88 31 ff ff ff    	js     5ced21 <gpui::runtime::ime::preview_selections+0x21>
  5cedf0:	83 fa 03             	cmp    $0x3,%edx
  5cedf3:	0f 84 89 02 00 00    	je     5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cedf9:	80 7c 06 03 00       	cmpb   $0x0,0x3(%rsi,%rax,1)
  5cedfe:	0f 88 1d ff ff ff    	js     5ced21 <gpui::runtime::ime::preview_selections+0x21>
  5cee04:	83 fa 04             	cmp    $0x4,%edx
  5cee07:	0f 84 75 02 00 00    	je     5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cee0d:	80 7c 06 04 00       	cmpb   $0x0,0x4(%rsi,%rax,1)
  5cee12:	0f 88 09 ff ff ff    	js     5ced21 <gpui::runtime::ime::preview_selections+0x21>
  5cee18:	83 fa 05             	cmp    $0x5,%edx
  5cee1b:	0f 84 61 02 00 00    	je     5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cee21:	80 7c 06 05 00       	cmpb   $0x0,0x5(%rsi,%rax,1)
  5cee26:	0f 88 f5 fe ff ff    	js     5ced21 <gpui::runtime::ime::preview_selections+0x21>
  5cee2c:	83 fa 06             	cmp    $0x6,%edx
  5cee2f:	0f 84 4d 02 00 00    	je     5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cee35:	80 7c 06 06 00       	cmpb   $0x0,0x6(%rsi,%rax,1)
  5cee3a:	0f 89 42 02 00 00    	jns    5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cee40:	e9 dc fe ff ff       	jmp    5ced21 <gpui::runtime::ime::preview_selections+0x21>
  5cee45:	0f 85 10 ff ff ff    	jne    5ced5b <gpui::runtime::ime::preview_selections+0x5b>
  5cee4b:	4c 89 54 24 08       	mov    %r10,0x8(%rsp)
  5cee50:	49 29 df             	sub    %rbx,%r15
  5cee53:	49 29 de             	sub    %rbx,%r14
  5cee56:	48 29 d1             	sub    %rdx,%rcx
  5cee59:	48 89 cd             	mov    %rcx,%rbp
  5cee5c:	48 29 54 24 18       	sub    %rdx,0x18(%rsp)
  5cee61:	48 8d 04 16          	lea    (%rsi,%rdx,1),%rax
  5cee65:	4c 01 de             	add    %r11,%rsi
  5cee68:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
  5cee6d:	49 29 d3             	sub    %rdx,%r11
  5cee70:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  5cee77:	00 00 
  5cee79:	48 c7 44 24 38 08 00 	movq   $0x8,0x38(%rsp)
  5cee80:	00 00 
  5cee82:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  5cee89:	00 00 
  5cee8b:	c7 44 24 50 ff ff ff 	movl   $0xffffffff,0x50(%rsp)
  5cee92:	ff 
  5cee93:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  5cee98:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  5cee9d:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  5ceea4:	00 00 
  5ceea6:	48 8d 05 a3 b1 27 00 	lea    0x27b1a3(%rip),%rax        # 84a050 <anon.cd78562aee332f96f44b11cbbe34fbad.7.llvm.11188030356063827792+0xa8>
  5ceead:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  5ceeb2:	48 8d 05 23 ee ff ff 	lea    -0x11dd(%rip),%rax        # 5cdcdc <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  5ceeb9:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
  5ceebe:	4c 89 5c 24 20       	mov    %r11,0x20(%rsp)
  5ceec3:	4c 89 9c 24 80 00 00 	mov    %r11,0x80(%rsp)
  5ceeca:	00 
  5ceecb:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  5ceed2:	00 00 00 00 00 
  5ceed7:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  5ceede:	00 00 00 00 00 
  5ceee3:	c6 84 24 c0 00 00 00 	movb   $0x0,0xc0(%rsp)
  5ceeea:	00 
  5ceeeb:	45 31 ed             	xor    %r13d,%r13d
  5ceeee:	45 31 e4             	xor    %r12d,%r12d
  5ceef1:	31 db                	xor    %ebx,%ebx
  5ceef3:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
  5ceefa:	00 00 
  5ceefc:	eb 13                	jmp    5cef11 <gpui::runtime::ime::preview_selections+0x211>
  5ceefe:	66 90                	xchg   %ax,%ax
  5cef00:	48 39 ea             	cmp    %rbp,%rdx
  5cef03:	48 0f 46 da          	cmovbe %rdx,%rbx
  5cef07:	49 89 d4             	mov    %rdx,%r12
  5cef0a:	48 3b 54 24 18       	cmp    0x18(%rsp),%rdx
  5cef0f:	73 7e                	jae    5cef8f <gpui::runtime::ime::preview_selections+0x28f>
  5cef11:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  5cef16:	e8 25 8f 00 00       	call   5d7e40 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  5cef1b:	48 83 f8 01          	cmp    $0x1,%rax
  5cef1f:	75 69                	jne    5cef8a <gpui::runtime::ime::preview_selections+0x28a>
  5cef21:	4c 89 f8             	mov    %r15,%rax
  5cef24:	4c 29 e0             	sub    %r12,%rax
  5cef27:	0f 93 c1             	setae  %cl
  5cef2a:	4c 39 fa             	cmp    %r15,%rdx
  5cef2d:	40 0f 93 c6          	setae  %sil
  5cef31:	40 84 f1             	test   %sil,%cl
  5cef34:	74 1a                	je     5cef50 <gpui::runtime::ime::preview_selections+0x250>
  5cef36:	4c 89 f9             	mov    %r15,%rcx
  5cef39:	48 29 d1             	sub    %rdx,%rcx
  5cef3c:	48 89 d6             	mov    %rdx,%rsi
  5cef3f:	4c 29 fe             	sub    %r15,%rsi
  5cef42:	48 0f 42 f1          	cmovb  %rcx,%rsi
  5cef46:	48 39 f0             	cmp    %rsi,%rax
  5cef49:	49 89 d5             	mov    %rdx,%r13
  5cef4c:	4d 0f 42 ec          	cmovb  %r12,%r13
  5cef50:	4c 89 f0             	mov    %r14,%rax
  5cef53:	4c 29 e0             	sub    %r12,%rax
  5cef56:	0f 93 c1             	setae  %cl
  5cef59:	4c 39 f2             	cmp    %r14,%rdx
  5cef5c:	40 0f 93 c6          	setae  %sil
  5cef60:	40 20 ce             	and    %cl,%sil
  5cef63:	40 80 fe 01          	cmp    $0x1,%sil
  5cef67:	75 97                	jne    5cef00 <gpui::runtime::ime::preview_selections+0x200>
  5cef69:	4c 89 f1             	mov    %r14,%rcx
  5cef6c:	48 29 d1             	sub    %rdx,%rcx
  5cef6f:	48 89 d6             	mov    %rdx,%rsi
  5cef72:	4c 29 f6             	sub    %r14,%rsi
  5cef75:	48 0f 42 f1          	cmovb  %rcx,%rsi
  5cef79:	48 39 f0             	cmp    %rsi,%rax
  5cef7c:	4c 0f 43 e2          	cmovae %rdx,%r12
  5cef80:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
  5cef85:	e9 76 ff ff ff       	jmp    5cef00 <gpui::runtime::ime::preview_selections+0x200>
  5cef8a:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
  5cef8f:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  5cef94:	48 85 f6             	test   %rsi,%rsi
  5cef97:	74 1a                	je     5cefb3 <gpui::runtime::ime::preview_selections+0x2b3>
  5cef99:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  5cef9e:	48 c1 e6 03          	shl    $0x3,%rsi
  5cefa2:	49 89 d6             	mov    %rdx,%r14
  5cefa5:	ba 08 00 00 00       	mov    $0x8,%edx
  5cefaa:	ff 15 a0 0c 29 00    	call   *0x290ca0(%rip)        # 85fc50 <_DYNAMIC+0x258>
  5cefb0:	4c 89 f2             	mov    %r14,%rdx
  5cefb3:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
  5cefb8:	49 01 cd             	add    %rcx,%r13
  5cefbb:	4c 89 e8             	mov    %r13,%rax
  5cefbe:	48 c1 e8 20          	shr    $0x20,%rax
  5cefc2:	75 2d                	jne    5ceff1 <gpui::runtime::ime::preview_selections+0x2f1>
  5cefc4:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
  5cefc9:	48 01 ce             	add    %rcx,%rsi
  5cefcc:	48 89 f0             	mov    %rsi,%rax
  5cefcf:	48 c1 e8 20          	shr    $0x20,%rax
  5cefd3:	75 1c                	jne    5ceff1 <gpui::runtime::ime::preview_selections+0x2f1>
  5cefd5:	48 01 cb             	add    %rcx,%rbx
  5cefd8:	48 89 d8             	mov    %rbx,%rax
  5cefdb:	48 c1 e8 20          	shr    $0x20,%rax
  5cefdf:	75 10                	jne    5ceff1 <gpui::runtime::ime::preview_selections+0x2f1>
  5cefe1:	48 01 ca             	add    %rcx,%rdx
  5cefe4:	48 89 d0             	mov    %rdx,%rax
  5cefe7:	48 c1 e8 20          	shr    $0x20,%rax
  5cefeb:	0f 84 c9 00 00 00    	je     5cf0ba <gpui::runtime::ime::preview_selections+0x3ba>
  5ceff1:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5ceff6:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  5ceffd:	c6 40 0c 01          	movb   $0x1,0xc(%rax)
  5cf001:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
  5cf008:	5b                   	pop    %rbx
  5cf009:	41 5c                	pop    %r12
  5cf00b:	41 5d                	pop    %r13
  5cf00d:	41 5e                	pop    %r14
  5cf00f:	41 5f                	pop    %r15
  5cf011:	5d                   	pop    %rbp
  5cf012:	c3                   	ret
  5cf013:	48 b8 c0 ff ff ff ff 	movabs $0x7fffffffffffffc0,%rax
  5cf01a:	ff ff 7f 
  5cf01d:	48 21 c8             	and    %rcx,%rax
  5cf020:	48 01 f0             	add    %rsi,%rax
  5cf023:	89 ca                	mov    %ecx,%edx
  5cf025:	83 e2 3f             	and    $0x3f,%edx
  5cf028:	31 db                	xor    %ebx,%ebx
  5cf02a:	48 89 f7             	mov    %rsi,%rdi
  5cf02d:	0f 1f 00             	nopl   (%rax)
  5cf030:	f3 0f 6f 07          	movdqu (%rdi),%xmm0
  5cf034:	f3 0f 6f 4f 10       	movdqu 0x10(%rdi),%xmm1
  5cf039:	66 0f eb c8          	por    %xmm0,%xmm1
  5cf03d:	f3 0f 6f 47 20       	movdqu 0x20(%rdi),%xmm0
  5cf042:	f3 0f 6f 57 30       	movdqu 0x30(%rdi),%xmm2
  5cf047:	66 0f eb d0          	por    %xmm0,%xmm2
  5cf04b:	66 0f eb d1          	por    %xmm1,%xmm2
  5cf04f:	66 44 0f d7 c2       	pmovmskb %xmm2,%r8d
  5cf054:	45 85 c0             	test   %r8d,%r8d
  5cf057:	0f 85 c6 fc ff ff    	jne    5ced23 <gpui::runtime::ime::preview_selections+0x23>
  5cf05d:	48 83 c7 40          	add    $0x40,%rdi
  5cf061:	48 39 c7             	cmp    %rax,%rdi
  5cf064:	75 ca                	jne    5cf030 <gpui::runtime::ime::preview_selections+0x330>
  5cf066:	48 85 d2             	test   %rdx,%rdx
  5cf069:	74 17                	je     5cf082 <gpui::runtime::ime::preview_selections+0x382>
  5cf06b:	31 db                	xor    %ebx,%ebx
  5cf06d:	31 ff                	xor    %edi,%edi
  5cf06f:	90                   	nop
  5cf070:	80 3c 38 00          	cmpb   $0x0,(%rax,%rdi,1)
  5cf074:	0f 88 a9 fc ff ff    	js     5ced23 <gpui::runtime::ime::preview_selections+0x23>
  5cf07a:	48 ff c7             	inc    %rdi
  5cf07d:	48 39 fa             	cmp    %rdi,%rdx
  5cf080:	75 ee                	jne    5cf070 <gpui::runtime::ime::preview_selections+0x370>
  5cf082:	31 d2                	xor    %edx,%edx
  5cf084:	48 89 cb             	mov    %rcx,%rbx
  5cf087:	48 83 eb 01          	sub    $0x1,%rbx
  5cf08b:	48 0f 42 da          	cmovb  %rdx,%rbx
  5cf08f:	0f 86 90 fc ff ff    	jbe    5ced25 <gpui::runtime::ime::preview_selections+0x25>
  5cf095:	48 8d 7b ff          	lea    -0x1(%rbx),%rdi
  5cf099:	4c 39 db             	cmp    %r11,%rbx
  5cf09c:	73 4a                	jae    5cf0e8 <gpui::runtime::ime::preview_selections+0x3e8>
  5cf09e:	48 8d 43 01          	lea    0x1(%rbx),%rax
  5cf0a2:	48 39 f8             	cmp    %rdi,%rax
  5cf0a5:	72 44                	jb     5cf0eb <gpui::runtime::ime::preview_selections+0x3eb>
  5cf0a7:	66 81 7c 1e ff 0d 0a 	cmpw   $0xa0d,-0x1(%rsi,%rbx,1)
  5cf0ae:	48 0f 44 df          	cmove  %rdi,%rbx
  5cf0b2:	48 89 da             	mov    %rbx,%rdx
  5cf0b5:	e9 6b fc ff ff       	jmp    5ced25 <gpui::runtime::ime::preview_selections+0x25>
  5cf0ba:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5cf0bf:	44 89 68 08          	mov    %r13d,0x8(%rax)
  5cf0c3:	c6 40 0c 01          	movb   $0x1,0xc(%rax)
  5cf0c7:	89 70 10             	mov    %esi,0x10(%rax)
  5cf0ca:	c6 40 14 01          	movb   $0x1,0x14(%rax)
  5cf0ce:	89 58 18             	mov    %ebx,0x18(%rax)
  5cf0d1:	c6 40 1c 01          	movb   $0x1,0x1c(%rax)
  5cf0d5:	89 50 20             	mov    %edx,0x20(%rax)
  5cf0d8:	c6 40 24 01          	movb   $0x1,0x24(%rax)
  5cf0dc:	48 c7 00 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rax)
  5cf0e3:	e9 19 ff ff ff       	jmp    5cf001 <gpui::runtime::ime::preview_selections+0x301>
  5cf0e8:	48 89 d8             	mov    %rbx,%rax
  5cf0eb:	48 8d 0d 46 af 27 00 	lea    0x27af46(%rip),%rcx        # 84a038 <anon.cd78562aee332f96f44b11cbbe34fbad.7.llvm.11188030356063827792+0x90>
  5cf0f2:	48 89 c6             	mov    %rax,%rsi
  5cf0f5:	4c 89 da             	mov    %r11,%rdx
  5cf0f8:	ff 15 82 0b 29 00    	call   *0x290b82(%rip)        # 85fc80 <_DYNAMIC+0x288>
  5cf0fe:	48 89 c3             	mov    %rax,%rbx
  5cf101:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  5cf106:	48 85 f6             	test   %rsi,%rsi
  5cf109:	74 14                	je     5cf11f <gpui::runtime::ime::preview_selections+0x41f>
  5cf10b:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  5cf110:	48 c1 e6 03          	shl    $0x3,%rsi
  5cf114:	ba 08 00 00 00       	mov    $0x8,%edx
  5cf119:	ff 15 31 0b 29 00    	call   *0x290b31(%rip)        # 85fc50 <_DYNAMIC+0x258>
  5cf11f:	48 89 df             	mov    %rbx,%rdi
  5cf122:	e8 f9 6c 27 00       	call   845e20 <_Unwind_Resume@plt>
