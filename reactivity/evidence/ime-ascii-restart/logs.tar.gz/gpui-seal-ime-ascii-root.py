from pathlib import Path
import hashlib
import json
import shutil
import tarfile

raw = Path('/tmp/gpui-ime-ascii-capsule-root')
out = Path('/tmp/gpui-ime-ascii-dossier-root')
raw.mkdir()
out.mkdir()
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
gates = [
    'build', 'execute', 'control-build', 'control-execute',
    'candidate-build', 'candidate-execute', 'strict',
    'left-mutant-build', 'left-mutant-execute',
    'right-mutant-build', 'right-mutant-execute',
    'byte-build', 'byte-execute', 'byte-release-build', 'byte-release-execute', 'byte-strict',
    'relative-build', 'relative-execute', 'relative-release-build', 'relative-strict',
    'relative-left-build', 'relative-left-execute',
    'relative-left-semantic-build', 'relative-left-semantic-execute',
    'relative-right-build', 'relative-right-execute',
    'main-build', 'main-execute', 'main-strict',
]
artifacts = [
    'executables', 'control-executable', 'candidate-executable',
    'left-mutant-executables', 'right-mutant-executable',
    'byte-executables', 'byte-release-executable',
    'relative-executables', 'relative-release-executable',
    'relative-left-executable', 'relative-left-semantic-executable',
    'relative-right-executable', 'main-executables',
]
extra_directories = [
    'assembly', 'relative-assembly', 'mothership-results',
    'byte-mothership-results', 'relative-mothership-results',
]
executables = []
def copy_metadata(source, destination):
    destination.mkdir(parents=True)
    for path in sorted(source.rglob('*')):
        if not path.is_file():
            continue
        if path.name in ['test', 'ime_cursor_cost']:
            executables.append({'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size})
            continue
        target = destination / path.relative_to(source)
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, target)

gate_results = {}
for name in gates:
    source = Path(f'/tmp/gpui-ime-ascii-{name}-root')
    copy_metadata(source, raw / 'gates' / name)
    gate_results[name] = json.loads((source / 'result.json').read_text())
for name in artifacts:
    copy_metadata(Path(f'/tmp/gpui-ime-ascii-{name}-root'), raw / 'artifacts' / name)
for name in extra_directories:
    copy_metadata(Path(f'/tmp/gpui-ime-ascii-{name}-root'), raw / name)
for name in ['mothership-stage', 'byte-mothership-stage', 'relative-mothership-stage']:
    source = Path(f'/tmp/gpui-ime-ascii-{name}-root')
    target = raw / name
    target.mkdir()
    for path in source.iterdir():
        if path.name.endswith('.json') or path.name == 'run.py':
            shutil.copy2(path, target / path.name)
for path in [
    Path('/tmp/gpui-ime-ascii-relative-core-lines-root.json'),
    Path('/tmp/gpui-ime-ascii-core-lines-root.json'),
    Path('/tmp/gpui-ime-ascii-relative-mothership-lock-released-root.txt'),
    Path('/tmp/gpui-ime-ascii-main-clean-root.stdout'),
    Path('/tmp/gpui-ime-ascii-main-clean-root.stderr'),
    Path('/tmp/gpui-ime-ascii-adoption-root.patch'),
    Path('/tmp/gpui-ime-ascii-adoption-commit-root.txt'),
    Path('/tmp/gpui-ime-ascii-context-luna-20261024/report.md'),
    Path('/tmp/gpui-run-frozen-gate-root.py'),
    Path('/tmp/gpui-run-cargo-test-artifacts-root.py'),
    Path('/tmp/gpui-freeze-ime-example-root.py'),
    Path('/tmp/gpui-execute-seam-mutant-root.py'),
    Path('/tmp/gpui-stage-ime-relative-root.py'),
    Path('/tmp/gpui-ime-ascii-remote-root.py'),
    Path('/tmp/gpui-ime-relative-assembly-root.py'),
    Path('/tmp/gpui-adopt-ime-relative-root.py'),
    Path('/tmp/gpui-seal-ime-ascii-root.py'),
]:
    shutil.copy2(path, raw / path.name)
for name in ['relative-build', 'relative-execute', 'relative-release-build', 'relative-strict', 'main-build', 'main-execute', 'main-strict']:
    assert gate_results[name]['exit'] == 0 and gate_results[name]['guards_match']
actual = json.loads(Path('/tmp/gpui-ime-ascii-main-executables-root/result.json').read_text())
assert (actual['passed'], actual['failed'], actual['ignored']) == (209, 0, 5)
build_rows = [json.loads(line) for line in Path('/tmp/gpui-ime-ascii-main-build-root/stdout.log').read_text().splitlines()]
first_party = [row for row in build_rows if row.get('reason') == 'compiler-artifact' and row.get('package_id', '').endswith('/reactivity/crates/gpui#0.1.0')]
assert first_party and all(not row['fresh'] for row in first_party)
for side in ['left-semantic', 'right']:
    result = json.loads(Path(f'/tmp/gpui-ime-ascii-relative-{side}-executable-root/result.json').read_text())
    assert result['actual_test_exit'] == 101 and result['one_semantic_assertion_failed']
qualified = json.loads(Path('/tmp/gpui-ime-ascii-relative-build-root/before.json').read_text())
adopted = json.loads(Path('/tmp/gpui-ime-ascii-main-build-root/before.json').read_text())
assert qualified.keys() == adopted.keys()
changed = [name for name in qualified if qualified[name] != adopted[name]]
assert changed == ['reactivity/crates/gpui/README.md']
source_members = {str(path.relative_to(raw)): digest(path) for path in sorted(raw.rglob('*')) if path.is_file()}
(raw / 'manifest.json').write_text(json.dumps(source_members, indent=2) + '\n')
with tarfile.open(out / 'logs.tar.gz', 'w:gz', compresslevel=9) as archive:
    for path in sorted(raw.rglob('*')):
        if path.is_file():
            archive.add(path, arcname=str(path.relative_to(raw)), recursive=False)
with tarfile.open(out / 'logs.tar.gz') as archive:
    for name, expected in source_members.items():
        member = archive.extractfile(name)
        assert member and hashlib.sha256(member.read()).hexdigest() == expected
report = {
    'adopted_source': 'ce75a3511be000c18a9b356a4be103585cdb5a21',
    'qualified_source': 'fb8b775315642eef8c9415b5e35185248f19c27c',
    'restored_tree_equivalent_source': '4b2e6d3df78e32269fbe1767230a1bd6b682ddbc',
    'control_source': '6fa774ce9816ea83cf8acd4892e24a1ae84798ed',
    'source_closure': {'guarded_inputs': len(qualified), 'main_differs_only_in': changed},
    'main_actual_execution': actual,
    'main_strict': gate_results['main-strict'],
    'qualified_cpu_experiment': json.loads(Path('/tmp/gpui-ime-ascii-relative-mothership-results-root/result.json').read_text()),
    'earlier_experiments': {name: json.loads(Path(f'/tmp/gpui-ime-ascii-{name}mothership-results-root/result.json').read_text())['summary'] for name in ['', 'byte-']},
    'assembly': json.loads(Path('/tmp/gpui-ime-ascii-relative-assembly-root/result.json').read_text()),
    'source_cost': {'core_including_build_scripts': 35863, 'previous': 35851, 'delta': 12, 'build_script_lines': 18},
    'seam_cases': {'existing_raw_byte_directed_pairs': 79333, 'new_valid_utf8_directed_pairs': 43008, 'hidden_caret_checks_extra': True},
    'negative_controls': {
        'left_context_bounds_only_not_certificate': {'source': '320d6f978147154d85891a4b93866faade2f616c', 'helper_exit': 1},
        'left_context_semantic': {'source': '5b0cbbd6cb80acd41c78775d49175da19210d044', 'actual_test_exit': 101, 'semantic_assertion': True},
        'right_context_semantic': {'source': '106d04892cb3ece325f4b70d0a6dd3dab53c5618', 'actual_test_exit': 101, 'semantic_assertion': True},
    },
    'executables_external': executables,
    'remote': '/home/miles/gpui-ce3-compute-20261024/evidence/ime-ascii-relative-root-fb8b775',
    'stage_bundle': {'path': '/tmp/gpui-ime-ascii-relative-mothership-stage-root.tar', 'bytes': Path('/tmp/gpui-ime-ascii-relative-mothership-stage-root.tar').stat().st_size, 'sha256': digest(Path('/tmp/gpui-ime-ascii-relative-mothership-stage-root.tar'))},
    'logs': {'bytes': (out / 'logs.tar.gz').stat().st_size, 'sha256': digest(out / 'logs.tar.gz'), 'verified_metadata_members': len(source_members)},
    'limits': ['Ordinary recording calls only; no native rasterization, scanout, click-to-pixel or hardware GPU timing.', 'Three process medians per variant on one pinned CPU; descriptive paired measurement, not a universal bound.', 'ASCII certification still scans prefix bytes with vectorized standard-library code; no retained certificate or boundary cache.', 'No dependency, new unsafe or retained-state change. No allocator savings claim.', 'No fresh macOS or Windows execution for this private optimization; predecessor native composition evidence remains separately pinned.', 'Native composition quarantine and physical candidate-engine limitations remain.'],
}
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'out': str(out), 'logs': report['logs'], 'actual_main': actual['passed']}))
