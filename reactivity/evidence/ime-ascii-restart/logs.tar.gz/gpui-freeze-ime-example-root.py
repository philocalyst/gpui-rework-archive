from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--build', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert json.loads((args.build / 'result.json').read_text())['exit'] == 0
rows = [json.loads(line) for line in (args.build / 'stdout.log').read_text().splitlines()]
assert any(row.get('reason') == 'compiler-artifact' and row['target']['name'] == 'gpui' and not row['fresh'] for row in rows)
artifact, = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['target']['name'] == 'ime_cursor_cost']
assert not artifact['fresh'] and artifact['profile']['opt_level'] == '3'
args.out.mkdir()
binary = args.out / 'ime_cursor_cost'
shutil.copy2(artifact['executable'], binary)
binary.chmod(0o555)
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
(args.out / 'binary.json').write_text(json.dumps({'source': json.loads((args.build / 'result.json').read_text())['source'], 'sha256': digest, 'bytes': binary.stat().st_size, 'cargo': artifact}, indent=2) + '\n')
with (args.out / 'stdout').open('w') as stdout, (args.out / 'stderr').open('w') as stderr:
    result = subprocess.run([str(binary)], stdout=stdout, stderr=stderr, timeout=180)
cases = [json.loads(line.split(',', 1)[1]) for line in (args.out / 'stdout').read_text().splitlines() if line.startswith('IME_CURSOR_COST,')]
report = {'exit': result.returncode, 'cases': cases, 'binary_hash_matches': hashlib.sha256(binary.read_bytes()).hexdigest() == digest, 'scope': 'Local functional smoke of complete ordinary API consumer; unpaired timing is not a performance result.'}
(args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
assert result.returncode == 0 and report['binary_hash_matches']
assert [row['case'] for row in cases] == ['short_ascii', 'ascii_4k', 'ascii_32k', 'unicode_32k']
assert all(row['model_and_display_validated'] for row in cases)
print(json.dumps({'source': json.loads((args.build / 'result.json').read_text())['source'], 'exit': result.returncode, 'cases_validated': len(cases), 'binary_sha256': digest}))
