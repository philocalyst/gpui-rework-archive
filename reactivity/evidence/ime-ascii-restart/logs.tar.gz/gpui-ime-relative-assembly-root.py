from pathlib import Path
import hashlib
import json
import re
import subprocess

out = Path('/tmp/gpui-ime-ascii-relative-assembly-root')
out.mkdir()
binutils = Path('/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin')
variants = {
    'control': Path('/tmp/gpui-ime-ascii-control-executable-root/ime_cursor_cost'),
    'candidate': Path('/tmp/gpui-ime-ascii-relative-release-executable-root/ime_cursor_cost'),
}
result = {'scope': 'Actual executed release ELF, x86_64 Linux only; caller and kernel own fixed frames exclude child frames and return addresses.'}
for label, binary in variants.items():
    names = subprocess.check_output([str(binutils / 'nm'), '-S', '--demangle', str(binary)], text=True)
    (out / f'{label}-symbols.txt').write_text(names)
    sections = subprocess.check_output([str(binutils / 'size'), '-A', str(binary)], text=True)
    (out / f'{label}-sections.txt').write_text(sections)
    symbols = {}
    for alias, suffix in [('preview', 'gpui::runtime::ime::preview_selections'), ('event', '<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event')]:
        row, = [line for line in names.splitlines() if line.endswith(' ' + suffix)]
        address, size, kind, name = row.split(' ', 3)
        start, length = int(address, 16), int(size, 16)
        assembly = subprocess.check_output([str(binutils / 'objdump'), '-d', '--demangle', f'--start-address={start}', f'--stop-address={start + length}', str(binary)], text=True)
        (out / f'{label}-{alias}.asm').write_text(assembly)
        instructions = [line for line in assembly.splitlines() if re.match(r'\s*[0-9a-f]+:', line)]
        symbols[alias] = {'code_bytes': length, 'symbol': name, 'prologue': instructions[:16]}
        if alias == 'preview':
            symbols[alias]['vector_instructions'] = [line.strip() for line in instructions if re.search(r'\b(movdqu|por|pmovmskb)\b', line)]
    result[label] = {
        'sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
        'file_bytes': binary.stat().st_size,
        'text_bytes': int(re.search(r'^\.text\s+(\d+)', sections, re.M)[1]),
        **symbols,
    }
(out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({label: {'file_bytes': result[label]['file_bytes'], 'text_bytes': result[label]['text_bytes'], 'preview_code_bytes': result[label]['preview']['code_bytes'], 'event_code_bytes': result[label]['event']['code_bytes']} for label in variants}))
