from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess

parser = argparse.ArgumentParser()
parser.add_argument('--build', type=Path, required=True)
parser.add_argument('--out', type=Path, required=True)
args = parser.parse_args()
assert json.loads((args.build / 'result.json').read_text())['exit'] == 0
rows = [json.loads(line) for line in (args.build / 'stdout.log').read_text().splitlines()]
artifact, = [row for row in rows if row.get('reason') == 'compiler-artifact' and row.get('executable') and row['target']['name'] == 'gpui']
assert not artifact['fresh']
args.out.mkdir()
binary = args.out / 'test'
shutil.copy2(artifact['executable'], binary)
binary.chmod(0o555)
digest = hashlib.sha256(binary.read_bytes()).hexdigest()
(args.out / 'binary.json').write_text(json.dumps({'sha256': digest, 'bytes': binary.stat().st_size, 'cargo': artifact}, indent=2) + '\n')
command = [str(binary), '--exact', 'runtime::ime::tests::ascii_restart_preserves_both_unicode_seams_and_full_scan_geometry', '--nocapture', '--test-threads=1']
with (args.out / 'stdout').open('w') as stdout, (args.out / 'stderr').open('w') as stderr:
    result = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=60)
output = (args.out / 'stdout').read_text()
error = (args.out / 'stderr').read_text()
report = {'actual_test_exit': result.returncode, 'argv': command, 'one_semantic_assertion_failed': '0 passed; 1 failed;' in output and 'assertion `left == right` failed' in error, 'binary_hash_matches': hashlib.sha256(binary.read_bytes()).hexdigest() == digest, 'scope': 'Expected negative control: exact full-ICU geometry comparison over valid UTF-8 seams.'}
(args.out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
assert result.returncode == 101 and report['one_semantic_assertion_failed'] and report['binary_hash_matches']
print(json.dumps(report))
