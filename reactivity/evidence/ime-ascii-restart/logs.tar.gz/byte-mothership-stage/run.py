from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import os
import shutil
import statistics
import subprocess

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'manifest.json').read_text())
digest = lambda path: hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
assert all(digest(root / name) == expected for name, expected in manifest['files'].items())
loader = Path('/nix/store/pqyiidz5mi73wv5f91d48s9plcqyj5bz-glibc-2.44-57/lib/ld-linux-x86-64.so.2')
library = f'{loader.parent}:/nix/store/8lahnh9pn3lrrnhax5nk7ibvjcbjmnkm-gcc-15.2.0-lib/lib'
out = root / 'run-1'
out.mkdir()
report = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'loader': str(loader), 'loader_sha256': digest(loader), 'library_path': library, 'scope': 'Counterbalanced whole ordinary API recording calls with default SIMD; no native rendering, input-to-photon or GPU result.', 'runs': []}
save = lambda: (out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
save()
with Path('/home/miles/gpui-ce3-compute-20261024/host.lock').open('a') as lease:
    fcntl.flock(lease, fcntl.LOCK_EX)
    assert shutil.disk_usage(root).free >= 8 * 1024**3
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    report['cpu_affinity'] = sorted(os.sched_getaffinity(0))
    report['cpuinfo'] = Path('/proc/cpuinfo').read_text()
    report['uname'] = list(os.uname())
    report['locked_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    for index, name in enumerate(['control', 'candidate', 'candidate', 'control', 'control', 'candidate']):
        binary = root / name
        command = [str(loader), '--library-path', library, str(binary)]
        with (out / f'{index}-{name}.stdout').open('w') as stdout, (out / f'{index}-{name}.stderr').open('w') as stderr:
            result = subprocess.run(command, stdout=stdout, stderr=stderr, env={**os.environ, 'LD_LIBRARY_PATH': library}, timeout=180)
        cases = [json.loads(line.split(',', 1)[1]) for line in (out / f'{index}-{name}.stdout').read_text().splitlines() if line.startswith('IME_CURSOR_COST,')]
        row = {'index': index, 'variant': name, 'exit': result.returncode, 'argv': command, 'binary_hash_matches': digest(binary) == manifest['files'][name], 'cases': cases}
        report['runs'].append(row)
        save()
        assert result.returncode == 0 and row['binary_hash_matches']
        assert [case['case'] for case in cases] == ['short_ascii', 'ascii_4k', 'ascii_32k', 'unicode_32k']
        assert all(case['model_and_display_validated'] and len(case['samples_ns']) == 9 for case in cases)
        print(json.dumps({'index': index, 'variant': name, 'validated_cases': len(cases)}), flush=True)
    summaries = []
    for case_name in ['short_ascii', 'ascii_4k', 'ascii_32k', 'unicode_32k']:
        variants = {}
        for variant in ['control', 'candidate']:
            medians = [statistics.median(case['samples_ns']) for row in report['runs'] if row['variant'] == variant for case in row['cases'] if case['case'] == case_name]
            variants[variant] = {'process_medians_ns': medians, 'median_ns': statistics.median(medians)}
        summaries.append({'case': case_name, **variants, 'candidate_over_control': variants['candidate']['median_ns'] / variants['control']['median_ns']})
    report['summary'] = summaries
    report['all_file_hashes_match'] = all(digest(root / name) == expected for name, expected in manifest['files'].items())
    report['completed_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    report['complete'] = True
    save()
    assert report['all_file_hashes_match'] and shutil.disk_usage(root).free >= 8 * 1024**3
    print(json.dumps({'complete': True, 'summary': summaries}), flush=True)
