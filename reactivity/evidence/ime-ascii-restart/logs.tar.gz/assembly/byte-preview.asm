
/tmp/gpui-ime-ascii-byte-release-executable-root/ime_cursor_cost:     file format elf64-x86-64


Disassembly of section .text:

00000000005d6d10 <gpui::runtime::ime::preview_selections>:
  5d6d10:	55                   	push   %rbp
  5d6d11:	41 57                	push   %r15
  5d6d13:	41 56                	push   %r14
  5d6d15:	41 55                	push   %r13
  5d6d17:	41 54                	push   %r12
  5d6d19:	53                   	push   %rbx
  5d6d1a:	48 81 ec c8 00 00 00 	sub    $0xc8,%rsp
  5d6d21:	4c 89 44 24 28       	mov    %r8,0x28(%rsp)
  5d6d26:	49 89 d2             	mov    %rdx,%r10
  5d6d29:	49 8b 41 04          	mov    0x4(%r9),%rax
  5d6d2d:	48 89 c5             	mov    %rax,%rbp
  5d6d30:	48 c1 ed 20          	shr    $0x20,%rbp
  5d6d34:	41 80 39 00          	cmpb   $0x0,(%r9)
  5d6d38:	48 0f 44 e9          	cmove  %rcx,%rbp
  5d6d3c:	89 c3                	mov    %eax,%ebx
  5d6d3e:	48 0f 44 d9          	cmove  %rcx,%rbx
  5d6d42:	48 39 d1             	cmp    %rdx,%rcx
  5d6d45:	76 08                	jbe    5d6d4f <gpui::runtime::ime::preview_selections+0x3f>
  5d6d47:	45 31 db             	xor    %r11d,%r11d
  5d6d4a:	e9 c3 01 00 00       	jmp    5d6f12 <gpui::runtime::ime::preview_selections+0x202>
  5d6d4f:	48 83 f9 40          	cmp    $0x40,%rcx
  5d6d53:	0f 83 c0 00 00 00    	jae    5d6e19 <gpui::runtime::ime::preview_selections+0x109>
  5d6d59:	48 89 c8             	mov    %rcx,%rax
  5d6d5c:	48 83 e0 38          	and    $0x38,%rax
  5d6d60:	74 31                	je     5d6d93 <gpui::runtime::ime::preview_selections+0x83>
  5d6d62:	45 31 db             	xor    %r11d,%r11d
  5d6d65:	49 b8 80 80 80 80 80 	movabs $0x8080808080808080,%r8
  5d6d6c:	80 80 80 
  5d6d6f:	31 d2                	xor    %edx,%edx
  5d6d71:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  5d6d78:	0f 1f 84 00 00 00 00 
  5d6d7f:	00 
  5d6d80:	4c 85 04 16          	test   %r8,(%rsi,%rdx,1)
  5d6d84:	0f 85 88 01 00 00    	jne    5d6f12 <gpui::runtime::ime::preview_selections+0x202>
  5d6d8a:	48 83 c2 08          	add    $0x8,%rdx
  5d6d8e:	48 39 d0             	cmp    %rdx,%rax
  5d6d91:	75 ed                	jne    5d6d80 <gpui::runtime::ime::preview_selections+0x70>
  5d6d93:	89 ca                	mov    %ecx,%edx
  5d6d95:	83 e2 07             	and    $0x7,%edx
  5d6d98:	0f 84 00 01 00 00    	je     5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6d9e:	80 3c 06 00          	cmpb   $0x0,(%rsi,%rax,1)
  5d6da2:	78 a3                	js     5d6d47 <gpui::runtime::ime::preview_selections+0x37>
  5d6da4:	83 fa 01             	cmp    $0x1,%edx
  5d6da7:	0f 84 f1 00 00 00    	je     5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6dad:	80 7c 06 01 00       	cmpb   $0x0,0x1(%rsi,%rax,1)
  5d6db2:	78 93                	js     5d6d47 <gpui::runtime::ime::preview_selections+0x37>
  5d6db4:	83 fa 02             	cmp    $0x2,%edx
  5d6db7:	0f 84 e1 00 00 00    	je     5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6dbd:	80 7c 06 02 00       	cmpb   $0x0,0x2(%rsi,%rax,1)
  5d6dc2:	78 83                	js     5d6d47 <gpui::runtime::ime::preview_selections+0x37>
  5d6dc4:	83 fa 03             	cmp    $0x3,%edx
  5d6dc7:	0f 84 d1 00 00 00    	je     5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6dcd:	80 7c 06 03 00       	cmpb   $0x0,0x3(%rsi,%rax,1)
  5d6dd2:	0f 88 6f ff ff ff    	js     5d6d47 <gpui::runtime::ime::preview_selections+0x37>
  5d6dd8:	83 fa 04             	cmp    $0x4,%edx
  5d6ddb:	0f 84 bd 00 00 00    	je     5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6de1:	80 7c 06 04 00       	cmpb   $0x0,0x4(%rsi,%rax,1)
  5d6de6:	0f 88 5b ff ff ff    	js     5d6d47 <gpui::runtime::ime::preview_selections+0x37>
  5d6dec:	83 fa 05             	cmp    $0x5,%edx
  5d6def:	0f 84 a9 00 00 00    	je     5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6df5:	80 7c 06 05 00       	cmpb   $0x0,0x5(%rsi,%rax,1)
  5d6dfa:	0f 88 47 ff ff ff    	js     5d6d47 <gpui::runtime::ime::preview_selections+0x37>
  5d6e00:	83 fa 06             	cmp    $0x6,%edx
  5d6e03:	0f 84 95 00 00 00    	je     5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6e09:	80 7c 06 06 00       	cmpb   $0x0,0x6(%rsi,%rax,1)
  5d6e0e:	0f 89 8a 00 00 00    	jns    5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6e14:	e9 2e ff ff ff       	jmp    5d6d47 <gpui::runtime::ime::preview_selections+0x37>
  5d6e19:	49 89 f8             	mov    %rdi,%r8
  5d6e1c:	48 b8 c0 ff ff ff ff 	movabs $0x7fffffffffffffc0,%rax
  5d6e23:	ff ff 7f 
  5d6e26:	48 21 c8             	and    %rcx,%rax
  5d6e29:	48 01 f0             	add    %rsi,%rax
  5d6e2c:	41 89 c9             	mov    %ecx,%r9d
  5d6e2f:	41 83 e1 3f          	and    $0x3f,%r9d
  5d6e33:	45 31 db             	xor    %r11d,%r11d
  5d6e36:	48 89 f2             	mov    %rsi,%rdx
  5d6e39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  5d6e40:	f3 0f 6f 02          	movdqu (%rdx),%xmm0
  5d6e44:	f3 0f 6f 4a 10       	movdqu 0x10(%rdx),%xmm1
  5d6e49:	66 0f eb c8          	por    %xmm0,%xmm1
  5d6e4d:	f3 0f 6f 42 20       	movdqu 0x20(%rdx),%xmm0
  5d6e52:	f3 0f 6f 52 30       	movdqu 0x30(%rdx),%xmm2
  5d6e57:	66 0f eb d0          	por    %xmm0,%xmm2
  5d6e5b:	66 0f eb d1          	por    %xmm1,%xmm2
  5d6e5f:	66 0f d7 fa          	pmovmskb %xmm2,%edi
  5d6e63:	85 ff                	test   %edi,%edi
  5d6e65:	0f 85 a4 00 00 00    	jne    5d6f0f <gpui::runtime::ime::preview_selections+0x1ff>
  5d6e6b:	48 83 c2 40          	add    $0x40,%rdx
  5d6e6f:	48 39 c2             	cmp    %rax,%rdx
  5d6e72:	75 cc                	jne    5d6e40 <gpui::runtime::ime::preview_selections+0x130>
  5d6e74:	4d 85 c9             	test   %r9,%r9
  5d6e77:	4c 89 c7             	mov    %r8,%rdi
  5d6e7a:	74 22                	je     5d6e9e <gpui::runtime::ime::preview_selections+0x18e>
  5d6e7c:	45 31 db             	xor    %r11d,%r11d
  5d6e7f:	31 d2                	xor    %edx,%edx
  5d6e81:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  5d6e88:	0f 1f 84 00 00 00 00 
  5d6e8f:	00 
  5d6e90:	80 3c 10 00          	cmpb   $0x0,(%rax,%rdx,1)
  5d6e94:	78 7c                	js     5d6f12 <gpui::runtime::ime::preview_selections+0x202>
  5d6e96:	48 ff c2             	inc    %rdx
  5d6e99:	49 39 d1             	cmp    %rdx,%r9
  5d6e9c:	75 f2                	jne    5d6e90 <gpui::runtime::ime::preview_selections+0x180>
  5d6e9e:	45 31 db             	xor    %r11d,%r11d
  5d6ea1:	48 89 ca             	mov    %rcx,%rdx
  5d6ea4:	48 83 ea 01          	sub    $0x1,%rdx
  5d6ea8:	49 0f 42 d3          	cmovb  %r11,%rdx
  5d6eac:	76 64                	jbe    5d6f12 <gpui::runtime::ime::preview_selections+0x202>
  5d6eae:	49 89 f8             	mov    %rdi,%r8
  5d6eb1:	48 8d 7a ff          	lea    -0x1(%rdx),%rdi
  5d6eb5:	4c 39 d2             	cmp    %r10,%rdx
  5d6eb8:	0f 83 35 02 00 00    	jae    5d70f3 <gpui::runtime::ime::preview_selections+0x3e3>
  5d6ebe:	48 8d 42 01          	lea    0x1(%rdx),%rax
  5d6ec2:	48 39 f8             	cmp    %rdi,%rax
  5d6ec5:	0f 82 2b 02 00 00    	jb     5d70f6 <gpui::runtime::ime::preview_selections+0x3e6>
  5d6ecb:	66 81 3c 3e 0d 0a    	cmpw   $0xa0d,(%rsi,%rdi,1)
  5d6ed1:	75 08                	jne    5d6edb <gpui::runtime::ime::preview_selections+0x1cb>
  5d6ed3:	48 89 fa             	mov    %rdi,%rdx
  5d6ed6:	48 85 ff             	test   %rdi,%rdi
  5d6ed9:	74 31                	je     5d6f0c <gpui::runtime::ime::preview_selections+0x1fc>
  5d6edb:	4c 39 d2             	cmp    %r10,%rdx
  5d6ede:	73 0e                	jae    5d6eee <gpui::runtime::ime::preview_selections+0x1de>
  5d6ee0:	80 3c 16 bf          	cmpb   $0xbf,(%rsi,%rdx,1)
  5d6ee4:	7e 10                	jle    5d6ef6 <gpui::runtime::ime::preview_selections+0x1e6>
  5d6ee6:	4c 89 c7             	mov    %r8,%rdi
  5d6ee9:	49 89 d3             	mov    %rdx,%r11
  5d6eec:	eb 24                	jmp    5d6f12 <gpui::runtime::ime::preview_selections+0x202>
  5d6eee:	4d 89 d3             	mov    %r10,%r11
  5d6ef1:	4c 89 c7             	mov    %r8,%rdi
  5d6ef4:	74 1c                	je     5d6f12 <gpui::runtime::ime::preview_selections+0x202>
  5d6ef6:	4c 8d 05 a3 36 27 00 	lea    0x2736a3(%rip),%r8        # 84a5a0 <anon.264db3f39825aebd95ae3dea1aacaf67.9.llvm.2110878676530160188+0x538>
  5d6efd:	48 89 f7             	mov    %rsi,%rdi
  5d6f00:	4c 89 d6             	mov    %r10,%rsi
  5d6f03:	4c 89 d1             	mov    %r10,%rcx
  5d6f06:	ff 15 2c 8f 28 00    	call   *0x288f2c(%rip)        # 85fe38 <_DYNAMIC+0x440>
  5d6f0c:	45 31 db             	xor    %r11d,%r11d
  5d6f0f:	4c 89 c7             	mov    %r8,%rdi
  5d6f12:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
  5d6f17:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
  5d6f1c:	4c 89 d0             	mov    %r10,%rax
  5d6f1f:	4c 29 d8             	sub    %r11,%rax
  5d6f22:	4a 8d 0c 1e          	lea    (%rsi,%r11,1),%rcx
  5d6f26:	4c 89 54 24 18       	mov    %r10,0x18(%rsp)
  5d6f2b:	4c 01 d6             	add    %r10,%rsi
  5d6f2e:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  5d6f35:	00 00 
  5d6f37:	48 c7 44 24 38 08 00 	movq   $0x8,0x38(%rsp)
  5d6f3e:	00 00 
  5d6f40:	48 c7 44 24 40 00 00 	movq   $0x0,0x40(%rsp)
  5d6f47:	00 00 
  5d6f49:	c7 44 24 50 ff ff ff 	movl   $0xffffffff,0x50(%rsp)
  5d6f50:	ff 
  5d6f51:	48 89 4c 24 58       	mov    %rcx,0x58(%rsp)
  5d6f56:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  5d6f5b:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
  5d6f62:	00 00 
  5d6f64:	48 8d 0d b5 35 27 00 	lea    0x2735b5(%rip),%rcx        # 84a520 <anon.264db3f39825aebd95ae3dea1aacaf67.9.llvm.2110878676530160188+0x4b8>
  5d6f6b:	48 89 4c 24 70       	mov    %rcx,0x70(%rsp)
  5d6f70:	48 8d 0d 75 ed ff ff 	lea    -0x128b(%rip),%rcx        # 5d5cec <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  5d6f77:	48 89 4c 24 78       	mov    %rcx,0x78(%rsp)
  5d6f7c:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
  5d6f83:	00 
  5d6f84:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  5d6f8b:	00 00 00 00 00 
  5d6f90:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
  5d6f97:	00 00 00 00 00 
  5d6f9c:	c6 84 24 c0 00 00 00 	movb   $0x0,0xc0(%rsp)
  5d6fa3:	00 
  5d6fa4:	4d 89 df             	mov    %r11,%r15
  5d6fa7:	4d 89 dc             	mov    %r11,%r12
  5d6faa:	4d 89 de             	mov    %r11,%r14
  5d6fad:	4d 89 dd             	mov    %r11,%r13
  5d6fb0:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
  5d6fb5:	eb 20                	jmp    5d6fd7 <gpui::runtime::ime::preview_selections+0x2c7>
  5d6fb7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  5d6fbe:	00 00 
  5d6fc0:	48 3b 54 24 20       	cmp    0x20(%rsp),%rdx
  5d6fc5:	4c 0f 46 f2          	cmovbe %rdx,%r14
  5d6fc9:	49 89 d4             	mov    %rdx,%r12
  5d6fcc:	48 3b 54 24 28       	cmp    0x28(%rsp),%rdx
  5d6fd1:	0f 83 81 00 00 00    	jae    5d7058 <gpui::runtime::ime::preview_selections+0x348>
  5d6fd7:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
  5d6fdc:	e8 0f db ff ff       	call   5d4af0 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  5d6fe1:	48 83 f8 01          	cmp    $0x1,%rax
  5d6fe5:	75 6c                	jne    5d7053 <gpui::runtime::ime::preview_selections+0x343>
  5d6fe7:	4c 01 ea             	add    %r13,%rdx
  5d6fea:	48 89 d8             	mov    %rbx,%rax
  5d6fed:	4c 29 e0             	sub    %r12,%rax
  5d6ff0:	0f 93 c1             	setae  %cl
  5d6ff3:	48 39 da             	cmp    %rbx,%rdx
  5d6ff6:	40 0f 93 c6          	setae  %sil
  5d6ffa:	40 84 f1             	test   %sil,%cl
  5d6ffd:	74 1a                	je     5d7019 <gpui::runtime::ime::preview_selections+0x309>
  5d6fff:	48 89 d9             	mov    %rbx,%rcx
  5d7002:	48 29 d1             	sub    %rdx,%rcx
  5d7005:	48 89 d6             	mov    %rdx,%rsi
  5d7008:	48 29 de             	sub    %rbx,%rsi
  5d700b:	48 0f 42 f1          	cmovb  %rcx,%rsi
  5d700f:	48 39 f0             	cmp    %rsi,%rax
  5d7012:	49 89 d7             	mov    %rdx,%r15
  5d7015:	4d 0f 42 fc          	cmovb  %r12,%r15
  5d7019:	48 89 e8             	mov    %rbp,%rax
  5d701c:	4c 29 e0             	sub    %r12,%rax
  5d701f:	0f 93 c1             	setae  %cl
  5d7022:	48 39 ea             	cmp    %rbp,%rdx
  5d7025:	40 0f 93 c6          	setae  %sil
  5d7029:	40 20 ce             	and    %cl,%sil
  5d702c:	40 80 fe 01          	cmp    $0x1,%sil
  5d7030:	75 8e                	jne    5d6fc0 <gpui::runtime::ime::preview_selections+0x2b0>
  5d7032:	48 89 e9             	mov    %rbp,%rcx
  5d7035:	48 29 d1             	sub    %rdx,%rcx
  5d7038:	48 89 d6             	mov    %rdx,%rsi
  5d703b:	48 29 ee             	sub    %rbp,%rsi
  5d703e:	48 0f 42 f1          	cmovb  %rcx,%rsi
  5d7042:	48 39 f0             	cmp    %rsi,%rax
  5d7045:	4c 0f 43 e2          	cmovae %rdx,%r12
  5d7049:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
  5d704e:	e9 6d ff ff ff       	jmp    5d6fc0 <gpui::runtime::ime::preview_selections+0x2b0>
  5d7053:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  5d7058:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  5d705d:	48 85 f6             	test   %rsi,%rsi
  5d7060:	74 1a                	je     5d707c <gpui::runtime::ime::preview_selections+0x36c>
  5d7062:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  5d7067:	48 c1 e6 03          	shl    $0x3,%rsi
  5d706b:	48 89 d3             	mov    %rdx,%rbx
  5d706e:	ba 08 00 00 00       	mov    $0x8,%edx
  5d7073:	ff 15 d7 8b 28 00    	call   *0x288bd7(%rip)        # 85fc50 <_DYNAMIC+0x258>
  5d7079:	48 89 da             	mov    %rbx,%rdx
  5d707c:	4c 89 f8             	mov    %r15,%rax
  5d707f:	48 c1 e8 20          	shr    $0x20,%rax
  5d7083:	75 20                	jne    5d70a5 <gpui::runtime::ime::preview_selections+0x395>
  5d7085:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
  5d708a:	48 89 c8             	mov    %rcx,%rax
  5d708d:	48 c1 e8 20          	shr    $0x20,%rax
  5d7091:	75 12                	jne    5d70a5 <gpui::runtime::ime::preview_selections+0x395>
  5d7093:	4c 89 f0             	mov    %r14,%rax
  5d7096:	48 c1 e8 20          	shr    $0x20,%rax
  5d709a:	75 09                	jne    5d70a5 <gpui::runtime::ime::preview_selections+0x395>
  5d709c:	48 89 d0             	mov    %rdx,%rax
  5d709f:	48 c1 e8 20          	shr    $0x20,%rax
  5d70a3:	74 22                	je     5d70c7 <gpui::runtime::ime::preview_selections+0x3b7>
  5d70a5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5d70aa:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  5d70b1:	c6 40 0c 01          	movb   $0x1,0xc(%rax)
  5d70b5:	48 81 c4 c8 00 00 00 	add    $0xc8,%rsp
  5d70bc:	5b                   	pop    %rbx
  5d70bd:	41 5c                	pop    %r12
  5d70bf:	41 5d                	pop    %r13
  5d70c1:	41 5e                	pop    %r14
  5d70c3:	41 5f                	pop    %r15
  5d70c5:	5d                   	pop    %rbp
  5d70c6:	c3                   	ret
  5d70c7:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
  5d70cc:	44 89 78 08          	mov    %r15d,0x8(%rax)
  5d70d0:	c6 40 0c 01          	movb   $0x1,0xc(%rax)
  5d70d4:	89 48 10             	mov    %ecx,0x10(%rax)
  5d70d7:	c6 40 14 01          	movb   $0x1,0x14(%rax)
  5d70db:	44 89 70 18          	mov    %r14d,0x18(%rax)
  5d70df:	c6 40 1c 01          	movb   $0x1,0x1c(%rax)
  5d70e3:	89 50 20             	mov    %edx,0x20(%rax)
  5d70e6:	c6 40 24 01          	movb   $0x1,0x24(%rax)
  5d70ea:	48 c7 00 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rax)
  5d70f1:	eb c2                	jmp    5d70b5 <gpui::runtime::ime::preview_selections+0x3a5>
  5d70f3:	48 89 d0             	mov    %rdx,%rax
  5d70f6:	48 8d 0d 0b 34 27 00 	lea    0x27340b(%rip),%rcx        # 84a508 <anon.264db3f39825aebd95ae3dea1aacaf67.9.llvm.2110878676530160188+0x4a0>
  5d70fd:	48 89 c6             	mov    %rax,%rsi
  5d7100:	4c 89 d2             	mov    %r10,%rdx
  5d7103:	ff 15 77 8b 28 00    	call   *0x288b77(%rip)        # 85fc80 <_DYNAMIC+0x288>
  5d7109:	48 89 c3             	mov    %rax,%rbx
  5d710c:	48 8b 74 24 30       	mov    0x30(%rsp),%rsi
  5d7111:	48 85 f6             	test   %rsi,%rsi
  5d7114:	74 14                	je     5d712a <gpui::runtime::ime::preview_selections+0x41a>
  5d7116:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
  5d711b:	48 c1 e6 03          	shl    $0x3,%rsi
  5d711f:	ba 08 00 00 00       	mov    $0x8,%edx
  5d7124:	ff 15 26 8b 28 00    	call   *0x288b26(%rip)        # 85fc50 <_DYNAMIC+0x258>
  5d712a:	48 89 df             	mov    %rbx,%rdi
  5d712d:	e8 ee ec 26 00       	call   845e20 <_Unwind_Resume@plt>
