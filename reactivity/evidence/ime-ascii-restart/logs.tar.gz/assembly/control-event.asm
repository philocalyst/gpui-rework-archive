
/tmp/gpui-ime-ascii-control-executable-root/ime_cursor_cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000571c60 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event>:
  571c60:	55                   	push   %rbp
  571c61:	41 57                	push   %r15
  571c63:	41 56                	push   %r14
  571c65:	41 55                	push   %r13
  571c67:	41 54                	push   %r12
  571c69:	53                   	push   %rbx
  571c6a:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
  571c71:	49 89 f5             	mov    %rsi,%r13
  571c74:	4c 8b 21             	mov    (%rcx),%r12
  571c77:	4c 89 e0             	mov    %r12,%rax
  571c7a:	48 83 e8 02          	sub    $0x2,%rax
  571c7e:	bd 01 00 00 00       	mov    $0x1,%ebp
  571c83:	48 0f 43 e8          	cmovae %rax,%rbp
  571c87:	48 89 fb             	mov    %rdi,%rbx
  571c8a:	4c 8d 7d fd          	lea    -0x3(%rbp),%r15
  571c8e:	48 8b 02             	mov    (%rdx),%rax
  571c91:	49 83 ff 01          	cmp    $0x1,%r15
  571c95:	77 07                	ja     571c9e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x3e>
  571c97:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
  571c9e:	4d 8b 75 00          	mov    0x0(%r13),%r14
  571ca2:	4d 85 f6             	test   %r14,%r14
  571ca5:	0f 84 e0 00 00 00    	je     571d8b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12b>
  571cab:	49 8b b6 20 06 00 00 	mov    0x620(%r14),%rsi
  571cb2:	48 85 f6             	test   %rsi,%rsi
  571cb5:	0f 84 04 01 00 00    	je     571dbf <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x15f>
  571cbb:	48 8b be e0 00 00 00 	mov    0xe0(%rsi),%rdi
  571cc2:	48 85 ff             	test   %rdi,%rdi
  571cc5:	0f 84 d4 00 00 00    	je     571d9f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  571ccb:	48 8b 7f 60          	mov    0x60(%rdi),%rdi
  571ccf:	48 85 ff             	test   %rdi,%rdi
  571cd2:	0f 84 c7 00 00 00    	je     571d9f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  571cd8:	48 8b 3f             	mov    (%rdi),%rdi
  571cdb:	48 85 ff             	test   %rdi,%rdi
  571cde:	0f 84 bb 00 00 00    	je     571d9f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  571ce4:	4c 8b 47 08          	mov    0x8(%rdi),%r8
  571ce8:	48 8b 7f 10          	mov    0x10(%rdi),%rdi
  571cec:	48 89 bc 24 28 01 00 	mov    %rdi,0x128(%rsp)
  571cf3:	00 
  571cf4:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  571cfb:	00 
  571cfc:	0f 85 ae 00 00 00    	jne    571db0 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x150>
  571d02:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  571d09:	49 c7 86 18 07 00 00 	movq   $0x0,0x718(%r14)
  571d10:	00 00 00 00 
  571d14:	48 8b b6 e0 00 00 00 	mov    0xe0(%rsi),%rsi
  571d1b:	48 85 f6             	test   %rsi,%rsi
  571d1e:	0f 84 5d 01 00 00    	je     571e81 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  571d24:	48 8b 76 60          	mov    0x60(%rsi),%rsi
  571d28:	48 85 f6             	test   %rsi,%rsi
  571d2b:	0f 84 50 01 00 00    	je     571e81 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  571d31:	48 8b 36             	mov    (%rsi),%rsi
  571d34:	48 85 f6             	test   %rsi,%rsi
  571d37:	0f 84 44 01 00 00    	je     571e81 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  571d3d:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  571d44:	00 
  571d45:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  571d4a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  571d4f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  571d54:	4c 89 f7             	mov    %r14,%rdi
  571d57:	e8 f4 ed ff ff       	call   570b50 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::ime_valid>
  571d5c:	84 c0                	test   %al,%al
  571d5e:	75 08                	jne    571d68 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x108>
  571d60:	4c 89 f7             	mov    %r14,%rdi
  571d63:	e8 08 e5 ff ff       	call   570270 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  571d68:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  571d6d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  571d72:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  571d77:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
  571d7e:	00 
  571d7f:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  571d86:	e9 f6 00 00 00       	jmp    571e81 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  571d8b:	48 c7 03 0d 00 00 00 	movq   $0xd,(%rbx)
  571d92:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
  571d99:	00 
  571d9a:	e9 67 04 00 00       	jmp    572206 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5a6>
  571d9f:	45 31 c0             	xor    %r8d,%r8d
  571da2:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  571da9:	00 
  571daa:	0f 84 52 ff ff ff    	je     571d02 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xa2>
  571db0:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  571db7:	00 
  571db8:	bd 0e 00 00 00       	mov    $0xe,%ebp
  571dbd:	eb 1f                	jmp    571dde <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x17e>
  571dbf:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  571dc6:	00 
  571dc7:	0f 84 9f 00 00 00    	je     571e6c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x20c>
  571dcd:	bd 0e 00 00 00       	mov    $0xe,%ebp
  571dd2:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  571dd9:	00 00 00 00 00 
  571dde:	45 31 ff             	xor    %r15d,%r15d
  571de1:	45 31 e4             	xor    %r12d,%r12d
  571de4:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  571de9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  571dee:	f3 0f 7f 4c 24 20    	movdqu %xmm1,0x20(%rsp)
  571df4:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  571df9:	41 0f b6 c4          	movzbl %r12b,%eax
  571dfd:	4c 09 f8             	or     %r15,%rax
  571e00:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  571e05:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
  571e0a:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
  571e11:	4c 89 f7             	mov    %r14,%rdi
  571e14:	e8 57 e4 ff ff       	call   570270 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  571e19:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  571e20:	00 
  571e21:	48 85 f6             	test   %rsi,%rsi
  571e24:	74 10                	je     571e36 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1d6>
  571e26:	4c 89 f7             	mov    %r14,%rdi
  571e29:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
  571e30:	00 
  571e31:	e8 3a eb ff ff       	call   570970 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  571e36:	4c 89 f7             	mov    %r14,%rdi
  571e39:	e8 a2 e7 ff ff       	call   5705e0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::reclaim_ime>
  571e3e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  571e43:	48 89 43 30          	mov    %rax,0x30(%rbx)
  571e47:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
  571e4d:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  571e53:	f3 0f 6f 54 24 30    	movdqu 0x30(%rsp),%xmm2
  571e59:	f3 0f 7f 53 20       	movdqu %xmm2,0x20(%rbx)
  571e5e:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  571e63:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  571e67:	e9 9a 03 00 00       	jmp    572206 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5a6>
  571e6c:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  571e73:	49 c7 86 18 07 00 00 	movq   $0x0,0x718(%r14)
  571e7a:	00 00 00 00 
  571e7e:	45 31 c0             	xor    %r8d,%r8d
  571e81:	48 85 ed             	test   %rbp,%rbp
  571e84:	0f 84 12 01 00 00    	je     571f9c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x33c>
  571e8a:	49 8b b6 20 06 00 00 	mov    0x620(%r14),%rsi
  571e91:	48 85 f6             	test   %rsi,%rsi
  571e94:	0f 84 cb 00 00 00    	je     571f65 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  571e9a:	48 8b b6 e0 00 00 00 	mov    0xe0(%rsi),%rsi
  571ea1:	48 85 f6             	test   %rsi,%rsi
  571ea4:	0f 84 bb 00 00 00    	je     571f65 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  571eaa:	48 8b 76 60          	mov    0x60(%rsi),%rsi
  571eae:	48 85 f6             	test   %rsi,%rsi
  571eb1:	0f 84 ae 00 00 00    	je     571f65 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  571eb7:	48 8b 3e             	mov    (%rsi),%rdi
  571eba:	48 89 3c 24          	mov    %rdi,(%rsp)
  571ebe:	48 85 ff             	test   %rdi,%rdi
  571ec1:	0f 84 9e 00 00 00    	je     571f65 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  571ec7:	48 85 c0             	test   %rax,%rax
  571eca:	0f 84 95 00 00 00    	je     571f65 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  571ed0:	48 8b 3c 24          	mov    (%rsp),%rdi
  571ed4:	48 39 07             	cmp    %rax,(%rdi)
  571ed7:	0f 85 88 00 00 00    	jne    571f65 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  571edd:	49 83 ff 01          	cmp    $0x1,%r15
  571ee1:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  571ee6:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  571eed:	00 
  571eee:	0f 87 a4 03 00 00    	ja     572298 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x638>
  571ef4:	4d 89 cf             	mov    %r9,%r15
  571ef7:	4c 89 f7             	mov    %r14,%rdi
  571efa:	e8 71 e3 ff ff       	call   570270 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  571eff:	84 c0                	test   %al,%al
  571f01:	0f 84 2d 04 00 00    	je     572334 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6d4>
  571f07:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  571f0c:	4c 89 f6             	mov    %r14,%rsi
  571f0f:	e8 cc 60 01 00       	call   587fe0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  571f14:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  571f19:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  571f1d:	0f 85 e3 03 00 00    	jne    572306 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6a6>
  571f23:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  571f28:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  571f2e:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  571f33:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  571f38:	44 0f b6 6c 24 40    	movzbl 0x40(%rsp),%r13d
  571f3e:	0f b6 44 24 47       	movzbl 0x47(%rsp),%eax
  571f43:	c1 e0 10             	shl    $0x10,%eax
  571f46:	0f b7 4c 24 45       	movzwl 0x45(%rsp),%ecx
  571f4b:	09 c1                	or     %eax,%ecx
  571f4d:	48 c1 e1 20          	shl    $0x20,%rcx
  571f51:	44 8b 74 24 41       	mov    0x41(%rsp),%r14d
  571f56:	49 09 ce             	or     %rcx,%r14
  571f59:	31 c0                	xor    %eax,%eax
  571f5b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  571f60:	e9 77 02 00 00       	jmp    5721dc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  571f65:	49 8b 86 70 06 00 00 	mov    0x670(%r14),%rax
  571f6c:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  571f73:	00 
  571f74:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  571f7b:	00 
  571f7c:	74 17                	je     571f95 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x335>
  571f7e:	45 84 ed             	test   %r13b,%r13b
  571f81:	0f 84 2f 02 00 00    	je     5721b6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x556>
  571f87:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  571f8e:	ff 
  571f8f:	0f 85 21 02 00 00    	jne    5721b6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x556>
  571f95:	31 ff                	xor    %edi,%edi
  571f97:	e9 26 02 00 00       	jmp    5721c2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x562>
  571f9c:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
  571fa1:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  571fa8:	00 
  571fa9:	4c 89 f7             	mov    %r14,%rdi
  571fac:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  571fb1:	e8 ba e2 ff ff       	call   570270 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  571fb6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  571fbb:	48 8b 0d de b2 2e 00 	mov    0x2eb2de(%rip),%rcx        # 85d2a0 <_DYNAMIC+0x428>
  571fc2:	48 8b 01             	mov    (%rcx),%rax
  571fc5:	45 31 ff             	xor    %r15d,%r15d
  571fc8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  571fcf:	00 
  571fd0:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  571fd4:	0f 84 d2 01 00 00    	je     5721ac <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x54c>
  571fda:	48 8d 70 01          	lea    0x1(%rax),%rsi
  571fde:	f0 48 0f b1 31       	lock cmpxchg %rsi,(%rcx)
  571fe3:	75 eb                	jne    571fd0 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x370>
  571fe5:	48 85 c0             	test   %rax,%rax
  571fe8:	0f 84 05 0c 00 00    	je     572bf3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf93>
  571fee:	4d 8b ae f8 05 00 00 	mov    0x5f8(%r14),%r13
  571ff5:	4d 85 ed             	test   %r13,%r13
  571ff8:	0f 84 1d 02 00 00    	je     57221b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5bb>
  571ffe:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  572003:	4d 8b a6 00 06 00 00 	mov    0x600(%r14),%r12
  57200a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  57200f:	4c 89 f6             	mov    %r14,%rsi
  572012:	4c 89 ea             	mov    %r13,%rdx
  572015:	4c 89 e1             	mov    %r12,%rcx
  572018:	e8 23 d3 ff ff       	call   56f340 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  57201d:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  572022:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  572027:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  57202b:	0f 85 f1 01 00 00    	jne    572222 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5c2>
  572031:	49 8b b6 a8 02 00 00 	mov    0x2a8(%r14),%rsi
  572038:	48 39 f7             	cmp    %rsi,%rdi
  57203b:	0f 83 53 0f 00 00    	jae    572f94 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1334>
  572041:	49 8b 86 a0 02 00 00 	mov    0x2a0(%r14),%rax
  572048:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  57204c:	8b 7c c8 10          	mov    0x10(%rax,%rcx,8),%edi
  572050:	89 f8                	mov    %edi,%eax
  572052:	83 e0 0f             	and    $0xf,%eax
  572055:	83 f8 09             	cmp    $0x9,%eax
  572058:	0f 87 bf 0e 00 00    	ja     572f1d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12bd>
  57205e:	83 f8 06             	cmp    $0x6,%eax
  572061:	0f 84 87 03 00 00    	je     5723ee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x78e>
  572067:	c1 ef 04             	shr    $0x4,%edi
  57206a:	0f 84 7e 03 00 00    	je     5723ee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x78e>
  572070:	49 8b b6 c0 02 00 00 	mov    0x2c0(%r14),%rsi
  572077:	ff cf                	dec    %edi
  572079:	48 39 fe             	cmp    %rdi,%rsi
  57207c:	0f 86 1f 0f 00 00    	jbe    572fa1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1341>
  572082:	49 8b 86 b8 02 00 00 	mov    0x2b8(%r14),%rax
  572089:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  57208d:	48 c1 e1 04          	shl    $0x4,%rcx
  572091:	83 3c 08 ff          	cmpl   $0xffffffff,(%rax,%rcx,1)
  572095:	0f 84 53 0e 00 00    	je     572eee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x128e>
  57209b:	48 01 c8             	add    %rcx,%rax
  57209e:	4c 8b 78 48          	mov    0x48(%rax),%r15
  5720a2:	4d 85 ff             	test   %r15,%r15
  5720a5:	0f 84 50 0e 00 00    	je     572efb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x129b>
  5720ab:	49 8b 8e 70 06 00 00 	mov    0x670(%r14),%rcx
  5720b2:	48 89 0c 24          	mov    %rcx,(%rsp)
  5720b6:	48 8b 68 40          	mov    0x40(%rax),%rbp
  5720ba:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
  5720be:	75 2e                	jne    5720ee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  5720c0:	48 8b 45 08          	mov    0x8(%rbp),%rax
  5720c4:	a8 01                	test   $0x1,%al
  5720c6:	75 26                	jne    5720ee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  5720c8:	b8 02 00 00 00       	mov    $0x2,%eax
  5720cd:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  5720d3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  5720da:	00 00 80 
  5720dd:	48 ff c1             	inc    %rcx
  5720e0:	48 21 c1             	and    %rax,%rcx
  5720e3:	48 f7 d9             	neg    %rcx
  5720e6:	71 06                	jno    5720ee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  5720e8:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  5720ee:	ff 15 cc af 2e 00    	call   *0x2eafcc(%rip)        # 85d0c0 <_DYNAMIC+0x248>
  5720f4:	bf 38 00 00 00       	mov    $0x38,%edi
  5720f9:	be 08 00 00 00       	mov    $0x8,%esi
  5720fe:	ff 15 c4 af 2e 00    	call   *0x2eafc4(%rip)        # 85d0c8 <_DYNAMIC+0x250>
  572104:	48 85 c0             	test   %rax,%rax
  572107:	0f 84 fb 0d 00 00    	je     572f08 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12a8>
  57210d:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  572112:	48 89 08             	mov    %rcx,(%rax)
  572115:	4c 89 68 08          	mov    %r13,0x8(%rax)
  572119:	4c 89 60 10          	mov    %r12,0x10(%rax)
  57211d:	4c 89 78 18          	mov    %r15,0x18(%rax)
  572121:	48 89 68 20          	mov    %rbp,0x20(%rax)
  572125:	48 8b 0c 24          	mov    (%rsp),%rcx
  572129:	48 89 48 28          	mov    %rcx,0x28(%rax)
  57212d:	48 c7 40 30 00 00 00 	movq   $0x0,0x30(%rax)
  572134:	00 
  572135:	4c 89 f7             	mov    %r14,%rdi
  572138:	48 89 c6             	mov    %rax,%rsi
  57213b:	e8 90 e2 ff ff       	call   5703d0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  572140:	41 80 be 2b 07 00 00 	cmpb   $0x0,0x72b(%r14)
  572147:	00 
  572148:	0f 84 00 01 00 00    	je     57224e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5ee>
  57214e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  572153:	4c 89 f6             	mov    %r14,%rsi
  572156:	e8 85 5e 01 00       	call   587fe0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  57215b:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  572160:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  572164:	0f 85 9c 01 00 00    	jne    572306 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6a6>
  57216a:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  57216f:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  572175:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  57217a:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  57217f:	44 0f b6 6c 24 40    	movzbl 0x40(%rsp),%r13d
  572185:	0f b6 44 24 47       	movzbl 0x47(%rsp),%eax
  57218a:	c1 e0 10             	shl    $0x10,%eax
  57218d:	0f b7 4c 24 45       	movzwl 0x45(%rsp),%ecx
  572192:	09 c1                	or     %eax,%ecx
  572194:	48 c1 e1 20          	shl    $0x20,%rcx
  572198:	44 8b 74 24 41       	mov    0x41(%rsp),%r14d
  57219d:	49 09 ce             	or     %rcx,%r14
  5721a0:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  5721a5:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  5721aa:	eb 30                	jmp    5721dc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  5721ac:	bd 21 00 00 00       	mov    $0x21,%ebp
  5721b1:	e9 2b fc ff ff       	jmp    571de1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x181>
  5721b6:	49 8b 8e a0 06 00 00 	mov    0x6a0(%r14),%rcx
  5721bd:	bf 01 00 00 00       	mov    $0x1,%edi
  5721c2:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  5721c9:	4d 8b 21             	mov    (%r9),%r12
  5721cc:	66 48 0f 6e c0       	movq   %rax,%xmm0
  5721d1:	66 48 0f 6e c9       	movq   %rcx,%xmm1
  5721d6:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
  5721da:	31 c0                	xor    %eax,%eax
  5721dc:	49 c1 e6 08          	shl    $0x8,%r14
  5721e0:	41 0f b6 cd          	movzbl %r13b,%ecx
  5721e4:	4c 09 f1             	or     %r14,%rcx
  5721e7:	48 89 02             	mov    %rax,(%rdx)
  5721ea:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
  5721ee:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  5721f3:	4c 89 7b 20          	mov    %r15,0x20(%rbx)
  5721f7:	4c 89 63 28          	mov    %r12,0x28(%rbx)
  5721fb:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
  5721ff:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
  572206:	48 89 d8             	mov    %rbx,%rax
  572209:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
  572210:	5b                   	pop    %rbx
  572211:	41 5c                	pop    %r12
  572213:	41 5d                	pop    %r13
  572215:	41 5e                	pop    %r14
  572217:	41 5f                	pop    %r15
  572219:	5d                   	pop    %rbp
  57221a:	c3                   	ret
  57221b:	bd 19 00 00 00       	mov    $0x19,%ebp
  572220:	eb 18                	jmp    57223a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  572222:	48 89 f8             	mov    %rdi,%rax
  572225:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  57222b:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  572230:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  572235:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  57223a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  57223f:	4d 89 e7             	mov    %r12,%r15
  572242:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  572249:	e9 96 fb ff ff       	jmp    571de4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  57224e:	49 8b 8e 70 06 00 00 	mov    0x670(%r14),%rcx
  572255:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  57225c:	00 
  57225d:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  572264:	00 
  572265:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  57226a:	0f 84 47 01 00 00    	je     5723b7 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x757>
  572270:	45 84 ed             	test   %r13b,%r13b
  572273:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  572278:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  57227d:	0f 84 42 01 00 00    	je     5723c5 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x765>
  572283:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  57228a:	ff 
  57228b:	0f 85 34 01 00 00    	jne    5723c5 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x765>
  572291:	31 ff                	xor    %edi,%edi
  572293:	e9 39 01 00 00       	jmp    5723d1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x771>
  572298:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
  57229f:	48 83 fd 01          	cmp    $0x1,%rbp
  5722a3:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  5722a8:	0f 84 c9 00 00 00    	je     572377 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x717>
  5722ae:	4c 8b 79 08          	mov    0x8(%rcx),%r15
  5722b2:	4c 8b 61 10          	mov    0x10(%rcx),%r12
  5722b6:	48 8b 04 24          	mov    (%rsp),%rax
  5722ba:	48 8b 50 08          	mov    0x8(%rax),%rdx
  5722be:	48 8b 48 10          	mov    0x10(%rax),%rcx
  5722c2:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  5722c7:	4c 89 f6             	mov    %r14,%rsi
  5722ca:	e8 71 d0 ff ff       	call   56f340 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  5722cf:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  5722d4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  5722d9:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  5722de:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5722e2:	0f 85 4b 05 00 00    	jne    572833 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbd3>
  5722e8:	48 8b 04 24          	mov    (%rsp),%rax
  5722ec:	48 8b 40 30          	mov    0x30(%rax),%rax
  5722f0:	48 85 c0             	test   %rax,%rax
  5722f3:	0f 84 24 01 00 00    	je     57241d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7bd>
  5722f9:	0f 10 00             	movups (%rax),%xmm0
  5722fc:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  572301:	e9 38 01 00 00       	jmp    57243e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7de>
  572306:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  57230b:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  572311:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  572316:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  57231b:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  572320:	4d 89 e7             	mov    %r12,%r15
  572323:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  57232a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  57232f:	e9 b0 fa ff ff       	jmp    571de4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  572334:	49 8b 86 70 06 00 00 	mov    0x670(%r14),%rax
  57233b:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  572342:	00 
  572343:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  57234a:	00 
  57234b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  572350:	0f 84 a5 00 00 00    	je     5723fb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x79b>
  572356:	45 84 ed             	test   %r13b,%r13b
  572359:	4c 89 fe             	mov    %r15,%rsi
  57235c:	0f 84 a0 00 00 00    	je     572402 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7a2>
  572362:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  572369:	ff 
  57236a:	0f 85 92 00 00 00    	jne    572402 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7a2>
  572370:	31 ff                	xor    %edi,%edi
  572372:	e9 97 00 00 00       	jmp    57240e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7ae>
  572377:	4c 8b 79 18          	mov    0x18(%rcx),%r15
  57237b:	4c 8b 51 20          	mov    0x20(%rcx),%r10
  57237f:	49 83 fc 01          	cmp    $0x1,%r12
  572383:	4c 8b 0c 24          	mov    (%rsp),%r9
  572387:	0f 85 d5 01 00 00    	jne    572562 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  57238d:	48 8b 79 08          	mov    0x8(%rcx),%rdi
  572391:	48 8b 71 10          	mov    0x10(%rcx),%rsi
  572395:	48 85 ff             	test   %rdi,%rdi
  572398:	0f 84 9c 01 00 00    	je     57253a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8da>
  57239e:	4c 39 d7             	cmp    %r10,%rdi
  5723a1:	0f 83 91 01 00 00    	jae    572538 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8d8>
  5723a7:	41 80 3c 3f bf       	cmpb   $0xbf,(%r15,%rdi,1)
  5723ac:	0f 8f 88 01 00 00    	jg     57253a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8da>
  5723b2:	e9 94 01 00 00       	jmp    57254b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  5723b7:	31 ff                	xor    %edi,%edi
  5723b9:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  5723be:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  5723c3:	eb 0c                	jmp    5723d1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x771>
  5723c5:	49 8b b6 a0 06 00 00 	mov    0x6a0(%r14),%rsi
  5723cc:	bf 01 00 00 00       	mov    $0x1,%edi
  5723d1:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  5723d8:	4d 8b 20             	mov    (%r8),%r12
  5723db:	66 48 0f 6e c1       	movq   %rcx,%xmm0
  5723e0:	66 48 0f 6e ce       	movq   %rsi,%xmm1
  5723e5:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
  5723e9:	e9 ee fd ff ff       	jmp    5721dc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  5723ee:	48 8d 3d 7b 2c 2d 00 	lea    0x2d2c7b(%rip),%rdi        # 845070 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x860>
  5723f5:	ff 15 fd ac 2e 00    	call   *0x2eacfd(%rip)        # 85d0f8 <_DYNAMIC+0x280>
  5723fb:	31 ff                	xor    %edi,%edi
  5723fd:	4c 89 fe             	mov    %r15,%rsi
  572400:	eb 0c                	jmp    57240e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7ae>
  572402:	49 8b 8e a0 06 00 00 	mov    0x6a0(%r14),%rcx
  572409:	bf 01 00 00 00       	mov    $0x1,%edi
  57240e:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  572415:	4c 8b 26             	mov    (%rsi),%r12
  572418:	e9 af fd ff ff       	jmp    5721cc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x56c>
  57241d:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  572422:	4c 89 f6             	mov    %r14,%rsi
  572425:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  57242a:	e8 41 d0 ff ff       	call   56f470 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::selection_at>
  57242f:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  572434:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  572438:	0f 85 eb 03 00 00    	jne    572829 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbc9>
  57243e:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  572444:	66 0f 7f 84 24 30 01 	movdqa %xmm0,0x130(%rsp)
  57244b:	00 00 
  57244d:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
  572454:	00 
  572455:	4c 89 f7             	mov    %r14,%rdi
  572458:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  57245d:	e8 6e d1 ff ff       	call   56f5d0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::set_selection>
  572462:	48 8b 2c 24          	mov    (%rsp),%rbp
  572466:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
  57246a:	e8 31 61 ff ff       	call   5685a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  57246f:	48 c7 45 30 00 00 00 	movq   $0x0,0x30(%rbp)
  572476:	00 
  572477:	48 8b 75 08          	mov    0x8(%rbp),%rsi
  57247b:	48 8b 55 10          	mov    0x10(%rbp),%rdx
  57247f:	4c 89 f7             	mov    %r14,%rdi
  572482:	e8 e9 e4 ff ff       	call   570970 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  572487:	49 83 c5 08          	add    $0x8,%r13
  57248b:	48 8b 04 24          	mov    (%rsp),%rax
  57248f:	48 8b 48 08          	mov    0x8(%rax),%rcx
  572493:	4c 8b 40 10          	mov    0x10(%rax),%r8
  572497:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  57249c:	4c 8d 8c 24 30 01 00 	lea    0x130(%rsp),%r9
  5724a3:	00 
  5724a4:	4c 89 f6             	mov    %r14,%rsi
  5724a7:	4c 89 ea             	mov    %r13,%rdx
  5724aa:	41 54                	push   %r12
  5724ac:	41 57                	push   %r15
  5724ae:	e8 2d 0d 00 00       	call   5731e0 <<gpui::runtime::RuntimeMut<ime_cursor_cost::Input, ()>>::replace_input>
  5724b3:	48 83 c4 10          	add    $0x10,%rsp
  5724b7:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  5724bc:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  5724c1:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  5724c6:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  5724cc:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  5724d3:	00 00 
  5724d5:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  5724da:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  5724df:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  5724e4:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5724e8:	75 44                	jne    57252e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8ce>
  5724ea:	4c 89 f7             	mov    %r14,%rdi
  5724ed:	48 8b 34 24          	mov    (%rsp),%rsi
  5724f1:	e8 4a e2 ff ff       	call   570740 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::refresh_ime>
  5724f6:	84 c0                	test   %al,%al
  5724f8:	0f 84 d3 02 00 00    	je     5727d1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb71>
  5724fe:	4c 89 f7             	mov    %r14,%rdi
  572501:	48 8b 34 24          	mov    (%rsp),%rsi
  572505:	e8 c6 de ff ff       	call   5703d0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  57250a:	4d 89 ee             	mov    %r13,%r14
  57250d:	49 c1 ee 08          	shr    $0x8,%r14
  572511:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  572516:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  57251b:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  572520:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  572527:	00 00 
  572529:	e9 ae fc ff ff       	jmp    5721dc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  57252e:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
  572533:	e9 1e 03 00 00       	jmp    572856 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbf6>
  572538:	75 11                	jne    57254b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  57253a:	48 85 f6             	test   %rsi,%rsi
  57253d:	74 23                	je     572562 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  57253f:	4c 39 d6             	cmp    %r10,%rsi
  572542:	73 1c                	jae    572560 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x900>
  572544:	41 80 3c 37 bf       	cmpb   $0xbf,(%r15,%rsi,1)
  572549:	7f 17                	jg     572562 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  57254b:	49 8b 71 08          	mov    0x8(%r9),%rsi
  57254f:	49 8b 51 10          	mov    0x10(%r9),%rdx
  572553:	4c 89 f7             	mov    %r14,%rdi
  572556:	e8 15 e4 ff ff       	call   570970 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  57255b:	e9 d7 01 00 00       	jmp    572737 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xad7>
  572560:	75 e9                	jne    57254b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  572562:	4c 89 94 24 90 00 00 	mov    %r10,0x90(%rsp)
  572569:	00 
  57256a:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  57256f:	49 8b 51 08          	mov    0x8(%r9),%rdx
  572573:	49 8b 49 10          	mov    0x10(%r9),%rcx
  572577:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  57257c:	4c 89 f6             	mov    %r14,%rsi
  57257f:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
  572586:	00 
  572587:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
  57258e:	00 
  57258f:	e8 ac cd ff ff       	call   56f340 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  572594:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  572599:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  57259e:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5725a2:	75 24                	jne    5725c8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x968>
  5725a4:	48 8b 34 24          	mov    (%rsp),%rsi
  5725a8:	48 8b 46 30          	mov    0x30(%rsi),%rax
  5725ac:	48 85 c0             	test   %rax,%rax
  5725af:	48 89 94 24 f8 00 00 	mov    %rdx,0xf8(%rsp)
  5725b6:	00 
  5725b7:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  5725bc:	74 4a                	je     572608 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x9a8>
  5725be:	0f 10 00             	movups (%rax),%xmm0
  5725c1:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  5725c6:	eb 60                	jmp    572628 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x9c8>
  5725c8:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  5725cd:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  5725d4:	00 
  5725d5:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  5725db:	f3 0f 6f 4c 24 30    	movdqu 0x30(%rsp),%xmm1
  5725e1:	f3 0f 7f 8c 24 c0 00 	movdqu %xmm1,0xc0(%rsp)
  5725e8:	00 00 
  5725ea:	f3 0f 7f 84 24 b0 00 	movdqu %xmm0,0xb0(%rsp)
  5725f1:	00 00 
  5725f3:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  5725fa:	00 
  5725fb:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  572602:	00 
  572603:	e9 40 01 00 00       	jmp    572748 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  572608:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  57260d:	4c 89 f6             	mov    %r14,%rsi
  572610:	e8 5b ce ff ff       	call   56f470 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::selection_at>
  572615:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  57261a:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  57261e:	48 8b 34 24          	mov    (%rsp),%rsi
  572622:	0f 85 c9 02 00 00    	jne    5728f1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc91>
  572628:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  57262e:	8b 44 24 24          	mov    0x24(%rsp),%eax
  572632:	89 84 24 e4 00 00 00 	mov    %eax,0xe4(%rsp)
  572639:	8b 44 24 20          	mov    0x20(%rsp),%eax
  57263d:	89 84 24 e0 00 00 00 	mov    %eax,0xe0(%rsp)
  572644:	8b 44 24 18          	mov    0x18(%rsp),%eax
  572648:	89 84 24 dc 00 00 00 	mov    %eax,0xdc(%rsp)
  57264f:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  572653:	89 84 24 d8 00 00 00 	mov    %eax,0xd8(%rsp)
  57265a:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  57265e:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  572662:	48 d1 ee             	shr    $1,%rsi
  572665:	4c 8d 6d 10          	lea    0x10(%rbp),%r13
  572669:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
  57266f:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
  572675:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  57267a:	4c 89 ef             	mov    %r13,%rdi
  57267d:	ff 15 05 ac 2e 00    	call   *0x2eac05(%rip)        # 85d288 <_DYNAMIC+0x410>
  572683:	84 c0                	test   %al,%al
  572685:	0f 84 ac 00 00 00    	je     572737 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xad7>
  57268b:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  572692:	00 
  572693:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
  57269a:	00 
  57269b:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  5726a1:	66 41 0f 7e c7       	movd   %xmm0,%r15d
  5726a6:	66 0f 70 c0 ee       	pshufd $0xee,%xmm0,%xmm0
  5726ab:	66 0f 7e c0          	movd   %xmm0,%eax
  5726af:	49 39 c7             	cmp    %rax,%r15
  5726b2:	48 89 c2             	mov    %rax,%rdx
  5726b5:	49 0f 42 d7          	cmovb  %r15,%rdx
  5726b9:	48 89 c6             	mov    %rax,%rsi
  5726bc:	49 0f 47 f7          	cmova  %r15,%rsi
  5726c0:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
  5726c4:	49 d1 ed             	shr    $1,%r13
  5726c7:	89 c1                	mov    %eax,%ecx
  5726c9:	44 29 f9             	sub    %r15d,%ecx
  5726cc:	41 29 c7             	sub    %eax,%r15d
  5726cf:	44 0f 42 f9          	cmovb  %ecx,%r15d
  5726d3:	4d 29 fd             	sub    %r15,%r13
  5726d6:	72 4c                	jb     572724 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  5726d8:	4c 03 ac 24 90 00 00 	add    0x90(%rsp),%r13
  5726df:	00 
  5726e0:	72 42                	jb     572724 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  5726e2:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  5726e7:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  5726ec:	48 c7 44 24 10 20 00 	movq   $0x20,0x10(%rsp)
  5726f3:	00 00 
  5726f5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  5726fa:	e8 a1 99 ff ff       	call   56c0a0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  5726ff:	49 81 fd 00 80 00 00 	cmp    $0x8000,%r13
  572706:	0f 86 1f 02 00 00    	jbe    57292b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xccb>
  57270c:	4c 89 f7             	mov    %r14,%rdi
  57270f:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  572716:	00 
  572717:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  57271e:	00 
  57271f:	e8 4c e2 ff ff       	call   570970 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  572724:	48 c7 84 24 a0 00 00 	movq   $0x20,0xa0(%rsp)
  57272b:	00 20 00 00 00 
  572730:	bd 20 00 00 00       	mov    $0x20,%ebp
  572735:	eb 11                	jmp    572748 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  572737:	48 c7 84 24 a0 00 00 	movq   $0x1a,0xa0(%rsp)
  57273e:	00 1a 00 00 00 
  572743:	bd 1a 00 00 00       	mov    $0x1a,%ebp
  572748:	48 8b 34 24          	mov    (%rsp),%rsi
  57274c:	4c 89 f7             	mov    %r14,%rdi
  57274f:	e8 7c dc ff ff       	call   5703d0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  572754:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  572758:	75 3e                	jne    572798 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb38>
  57275a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  57275f:	4c 89 f6             	mov    %r14,%rsi
  572762:	e8 79 58 01 00       	call   587fe0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  572767:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  57276c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  572771:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  572777:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  57277c:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  572781:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  572786:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  57278a:	75 3a                	jne    5727c6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb66>
  57278c:	4d 89 ee             	mov    %r13,%r14
  57278f:	49 c1 ee 08          	shr    $0x8,%r14
  572793:	e9 08 fa ff ff       	jmp    5721a0 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x540>
  572798:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  57279f:	00 
  5727a0:	f3 0f 6f 8c 24 b0 00 	movdqu 0xb0(%rsp),%xmm1
  5727a7:	00 00 
  5727a9:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  5727b0:	00 
  5727b1:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
  5727b8:	00 
  5727b9:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
  5727c0:	00 
  5727c1:	e9 74 fa ff ff       	jmp    57223a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  5727c6:	4c 89 f9             	mov    %r15,%rcx
  5727c9:	48 89 f8             	mov    %rdi,%rax
  5727cc:	e9 69 fa ff ff       	jmp    57223a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  5727d1:	4c 89 f7             	mov    %r14,%rdi
  5727d4:	e8 07 de ff ff       	call   5705e0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::reclaim_ime>
  5727d9:	4c 89 fd             	mov    %r15,%rbp
  5727dc:	4c 8b 3c 24          	mov    (%rsp),%r15
  5727e0:	49 8b 7f 20          	mov    0x20(%r15),%rdi
  5727e4:	e8 f7 96 ff ff       	call   56bee0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  5727e9:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  5727ed:	e8 ae 5d ff ff       	call   5685a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  5727f2:	4d 89 ee             	mov    %r13,%r14
  5727f5:	49 c1 ee 08          	shr    $0x8,%r14
  5727f9:	be 38 00 00 00       	mov    $0x38,%esi
  5727fe:	ba 08 00 00 00       	mov    $0x8,%edx
  572803:	4c 89 ff             	mov    %r15,%rdi
  572806:	ff 15 c4 a8 2e 00    	call   *0x2ea8c4(%rip)        # 85d0d0 <_DYNAMIC+0x258>
  57280c:	31 c0                	xor    %eax,%eax
  57280e:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  572813:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  572818:	49 89 ef             	mov    %rbp,%r15
  57281b:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  572822:	00 00 
  572824:	e9 b3 f9 ff ff       	jmp    5721dc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  572829:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  57282e:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  572833:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  572839:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  572840:	00 00 
  572842:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  572847:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  57284c:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  572851:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  572856:	4c 8b 3c 24          	mov    (%rsp),%r15
  57285a:	49 8b 7f 20          	mov    0x20(%r15),%rdi
  57285e:	f6 07 01             	testb  $0x1,(%rdi)
  572861:	75 17                	jne    57287a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  572863:	48 8b 47 08          	mov    0x8(%rdi),%rax
  572867:	a8 01                	test   $0x1,%al
  572869:	75 0f                	jne    57287a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  57286b:	48 8d 47 08          	lea    0x8(%rdi),%rax
  57286f:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  572874:	0f 84 bc 06 00 00    	je     572f36 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12d6>
  57287a:	4d 8b 7f 30          	mov    0x30(%r15),%r15
  57287e:	4d 85 ff             	test   %r15,%r15
  572881:	74 33                	je     5728b6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc56>
  572883:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  572887:	f6 07 01             	testb  $0x1,(%rdi)
  57288a:	75 17                	jne    5728a3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  57288c:	48 8b 47 08          	mov    0x8(%rdi),%rax
  572890:	a8 01                	test   $0x1,%al
  572892:	75 0f                	jne    5728a3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  572894:	48 8d 47 08          	lea    0x8(%rdi),%rax
  572898:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  57289d:	0f 84 a2 06 00 00    	je     572f45 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12e5>
  5728a3:	be 60 00 00 00       	mov    $0x60,%esi
  5728a8:	ba 08 00 00 00       	mov    $0x8,%edx
  5728ad:	4c 89 ff             	mov    %r15,%rdi
  5728b0:	ff 15 1a a8 2e 00    	call   *0x2ea81a(%rip)        # 85d0d0 <_DYNAMIC+0x258>
  5728b6:	4d 89 e7             	mov    %r12,%r15
  5728b9:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  5728c0:	be 38 00 00 00       	mov    $0x38,%esi
  5728c5:	ba 08 00 00 00       	mov    $0x8,%edx
  5728ca:	48 8b 3c 24          	mov    (%rsp),%rdi
  5728ce:	ff 15 fc a7 2e 00    	call   *0x2ea7fc(%rip)        # 85d0d0 <_DYNAMIC+0x258>
  5728d4:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  5728d9:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  5728de:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  5728e3:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  5728ea:	00 00 
  5728ec:	e9 f3 f4 ff ff       	jmp    571de4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  5728f1:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  5728f7:	f3 0f 6f 4c 24 28    	movdqu 0x28(%rsp),%xmm1
  5728fd:	f3 0f 6f 54 24 38    	movdqu 0x38(%rsp),%xmm2
  572903:	f3 0f 7f 94 24 c8 00 	movdqu %xmm2,0xc8(%rsp)
  57290a:	00 00 
  57290c:	f3 0f 7f 8c 24 b8 00 	movdqu %xmm1,0xb8(%rsp)
  572913:	00 00 
  572915:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  57291c:	00 
  57291d:	f3 0f 7f 84 24 a8 00 	movdqu %xmm0,0xa8(%rsp)
  572924:	00 00 
  572926:	e9 21 fe ff ff       	jmp    57274c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xaec>
  57292b:	49 8b b6 a8 02 00 00 	mov    0x2a8(%r14),%rsi
  572932:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  572939:	00 
  57293a:	48 39 f7             	cmp    %rsi,%rdi
  57293d:	0f 83 6b 06 00 00    	jae    572fae <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x134e>
  572943:	49 8b 86 a0 02 00 00 	mov    0x2a0(%r14),%rax
  57294a:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  57294e:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
  572952:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  572959:	00 
  57295a:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  57295f:	48 85 f6             	test   %rsi,%rsi
  572962:	0f 85 d1 00 00 00    	jne    572a39 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xdd9>
  572968:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
  57296c:	75 2e                	jne    57299c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  57296e:	48 8b 45 08          	mov    0x8(%rbp),%rax
  572972:	a8 01                	test   $0x1,%al
  572974:	75 26                	jne    57299c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  572976:	b8 02 00 00 00       	mov    $0x2,%eax
  57297b:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  572981:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  572988:	00 00 80 
  57298b:	48 ff c1             	inc    %rcx
  57298e:	48 21 c1             	and    %rax,%rcx
  572991:	48 f7 d9             	neg    %rcx
  572994:	71 06                	jno    57299c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  572996:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  57299c:	48 8b 04 24          	mov    (%rsp),%rax
  5729a0:	4c 8b 28             	mov    (%rax),%r13
  5729a3:	ff 15 17 a7 2e 00    	call   *0x2ea717(%rip)        # 85d0c0 <_DYNAMIC+0x248>
  5729a9:	bf 60 00 00 00       	mov    $0x60,%edi
  5729ae:	be 08 00 00 00       	mov    $0x8,%esi
  5729b3:	ff 15 0f a7 2e 00    	call   *0x2ea70f(%rip)        # 85d0c8 <_DYNAMIC+0x250>
  5729b9:	48 85 c0             	test   %rax,%rax
  5729bc:	0f 84 c0 05 00 00    	je     572f82 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1322>
  5729c2:	48 89 c6             	mov    %rax,%rsi
  5729c5:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  5729ca:	48 89 c8             	mov    %rcx,%rax
  5729cd:	48 c1 e0 20          	shl    $0x20,%rax
  5729d1:	48 09 c8             	or     %rcx,%rax
  5729d4:	66 0f 6e 84 24 dc 00 	movd   0xdc(%rsp),%xmm0
  5729db:	00 00 
  5729dd:	66 0f 6e 8c 24 d8 00 	movd   0xd8(%rsp),%xmm1
  5729e4:	00 00 
  5729e6:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
  5729ea:	66 0f 6e 8c 24 e0 00 	movd   0xe0(%rsp),%xmm1
  5729f1:	00 00 
  5729f3:	66 0f 6e 94 24 e4 00 	movd   0xe4(%rsp),%xmm2
  5729fa:	00 00 
  5729fc:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
  572a00:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
  572a04:	f3 0f 7f 06          	movdqu %xmm0,(%rsi)
  572a08:	f3 0f 7f 46 10       	movdqu %xmm0,0x10(%rsi)
  572a0d:	f3 0f 7f 46 20       	movdqu %xmm0,0x20(%rsi)
  572a12:	48 89 6e 30          	mov    %rbp,0x30(%rsi)
  572a16:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  572a1d:	00 
  572a1e:	48 89 4e 38          	mov    %rcx,0x38(%rsi)
  572a22:	4c 89 6e 40          	mov    %r13,0x40(%rsi)
  572a26:	48 89 46 48          	mov    %rax,0x48(%rsi)
  572a2a:	c7 46 50 00 00 00 00 	movl   $0x0,0x50(%rsi)
  572a31:	48 8b 04 24          	mov    (%rsp),%rax
  572a35:	48 89 70 30          	mov    %rsi,0x30(%rax)
  572a39:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
  572a40:	00 00 
  572a42:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  572a47:	0f 84 80 00 00 00    	je     572acd <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe6d>
  572a4d:	48 8b 46 48          	mov    0x48(%rsi),%rax
  572a51:	89 c2                	mov    %eax,%edx
  572a53:	48 c1 e8 20          	shr    $0x20,%rax
  572a57:	48 89 c1             	mov    %rax,%rcx
  572a5a:	48 29 d1             	sub    %rdx,%rcx
  572a5d:	0f 85 cc 00 00 00    	jne    572b2f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xecf>
  572a63:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  572a67:	48 d1 ee             	shr    $1,%rsi
  572a6a:	4c 8d 05 df 27 2d 00 	lea    0x2d27df(%rip),%r8        # 845250 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa40>
  572a71:	48 39 74 24 78       	cmp    %rsi,0x78(%rsp)
  572a76:	0f 87 d8 04 00 00    	ja     572f54 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  572a7c:	48 39 74 24 60       	cmp    %rsi,0x60(%rsp)
  572a81:	74 35                	je     572ab8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe58>
  572a83:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  572a89:	74 13                	je     572a9e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe3e>
  572a8b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  572a90:	48 8d 4d 10          	lea    0x10(%rbp),%rcx
  572a94:	80 3c 01 bf          	cmpb   $0xbf,(%rcx,%rax,1)
  572a98:	0f 8e b6 04 00 00    	jle    572f54 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  572a9e:	48 39 74 24 78       	cmp    %rsi,0x78(%rsp)
  572aa3:	74 13                	je     572ab8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe58>
  572aa5:	48 8d 45 10          	lea    0x10(%rbp),%rax
  572aa9:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  572aae:	80 3c 08 bf          	cmpb   $0xbf,(%rax,%rcx,1)
  572ab2:	0f 8e 9c 04 00 00    	jle    572f54 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  572ab8:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  572abd:	48 8d 4d 10          	lea    0x10(%rbp),%rcx
  572ac1:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
  572ac5:	4c 89 f9             	mov    %r15,%rcx
  572ac8:	e9 ae 00 00 00       	jmp    572b7b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf1b>
  572acd:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
  572ad1:	48 8b 45 00          	mov    0x0(%rbp),%rax
  572ad5:	48 39 e9             	cmp    %rbp,%rcx
  572ad8:	75 10                	jne    572aea <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe8a>
  572ada:	48 8b 09             	mov    (%rcx),%rcx
  572add:	48 31 c1             	xor    %rax,%rcx
  572ae0:	48 83 f9 01          	cmp    $0x1,%rcx
  572ae4:	0f 86 e7 00 00 00    	jbe    572bd1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf71>
  572aea:	a8 01                	test   $0x1,%al
  572aec:	75 2e                	jne    572b1c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  572aee:	48 8b 45 08          	mov    0x8(%rbp),%rax
  572af2:	a8 01                	test   $0x1,%al
  572af4:	75 26                	jne    572b1c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  572af6:	b8 02 00 00 00       	mov    $0x2,%eax
  572afb:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  572b01:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  572b08:	00 00 80 
  572b0b:	48 ff c1             	inc    %rcx
  572b0e:	48 21 c1             	and    %rax,%rcx
  572b11:	48 f7 d9             	neg    %rcx
  572b14:	71 06                	jno    572b1c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  572b16:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  572b1c:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  572b21:	48 8b 78 30          	mov    0x30(%rax),%rdi
  572b25:	e8 b6 93 ff ff       	call   56bee0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  572b2a:	e9 9c 01 00 00       	jmp    572ccb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x106b>
  572b2f:	48 8b 7e 30          	mov    0x30(%rsi),%rdi
  572b33:	48 8b 37             	mov    (%rdi),%rsi
  572b36:	48 d1 ee             	shr    $1,%rsi
  572b39:	48 83 c7 10          	add    $0x10,%rdi
  572b3d:	4c 8d 05 f4 26 2d 00 	lea    0x2d26f4(%rip),%r8        # 845238 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa28>
  572b44:	39 d0                	cmp    %edx,%eax
  572b46:	0f 82 14 04 00 00    	jb     572f60 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  572b4c:	48 39 f0             	cmp    %rsi,%rax
  572b4f:	0f 87 0b 04 00 00    	ja     572f60 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  572b55:	48 39 f2             	cmp    %rsi,%rdx
  572b58:	74 1e                	je     572b78 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf18>
  572b5a:	48 85 d2             	test   %rdx,%rdx
  572b5d:	74 0a                	je     572b69 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf09>
  572b5f:	80 3c 17 bf          	cmpb   $0xbf,(%rdi,%rdx,1)
  572b63:	0f 8e f7 03 00 00    	jle    572f60 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  572b69:	48 39 f0             	cmp    %rsi,%rax
  572b6c:	74 0a                	je     572b78 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf18>
  572b6e:	80 3c 07 bf          	cmpb   $0xbf,(%rdi,%rax,1)
  572b72:	0f 8e e8 03 00 00    	jle    572f60 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  572b78:	48 01 d7             	add    %rdx,%rdi
  572b7b:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  572b82:	00 
  572b83:	48 39 ca             	cmp    %rcx,%rdx
  572b86:	75 12                	jne    572b9a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf3a>
  572b88:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  572b8f:	00 
  572b90:	ff 15 c2 a5 2e 00    	call   *0x2ea5c2(%rip)        # 85d158 <bcmp@GLIBC_2.2.5>
  572b96:	85 c0                	test   %eax,%eax
  572b98:	74 37                	je     572bd1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf71>
  572b9a:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  572b9e:	48 d1 ee             	shr    $1,%rsi
  572ba1:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  572ba6:	48 85 c0             	test   %rax,%rax
  572ba9:	74 68                	je     572c13 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfb3>
  572bab:	48 39 f0             	cmp    %rsi,%rax
  572bae:	73 5c                	jae    572c0c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfac>
  572bb0:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  572bb5:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  572bbc:	00 
  572bbd:	80 3c 01 c0          	cmpb   $0xc0,(%rcx,%rax,1)
  572bc1:	7d 50                	jge    572c13 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfb3>
  572bc3:	4c 8d 05 9e 26 2d 00 	lea    0x2d269e(%rip),%r8        # 845268 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa58>
  572bca:	31 d2                	xor    %edx,%edx
  572bcc:	e9 9c 03 00 00       	jmp    572f6d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x130d>
  572bd1:	45 31 ff             	xor    %r15d,%r15d
  572bd4:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  572bd9:	48 01 8c 24 90 00 00 	add    %rcx,0x90(%rsp)
  572be0:	00 
  572be1:	41 f6 c4 01          	test   $0x1,%r12b
  572be5:	0f 85 03 01 00 00    	jne    572cee <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x108e>
  572beb:	45 31 ed             	xor    %r13d,%r13d
  572bee:	e9 19 01 00 00       	jmp    572d0c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x10ac>
  572bf3:	48 8d 3d b6 3b ad ff 	lea    -0x52c44a(%rip),%rdi        # 467b0 <anon.72786b07d16308d9adbd85e9b0d1bfa8.348.llvm.9246593494314379644+0x2d50>
  572bfa:	48 8d 15 97 26 2d 00 	lea    0x2d2697(%rip),%rdx        # 845298 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa88>
  572c01:	be 17 00 00 00       	mov    $0x17,%esi
  572c06:	ff 15 34 a6 2e 00    	call   *0x2ea634(%rip)        # 85d240 <_DYNAMIC+0x3c8>
  572c0c:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  572c11:	75 b0                	jne    572bc3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf63>
  572c13:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  572c18:	48 85 d2             	test   %rdx,%rdx
  572c1b:	74 3a                	je     572c57 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xff7>
  572c1d:	48 39 d6             	cmp    %rdx,%rsi
  572c20:	76 29                	jbe    572c4b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfeb>
  572c22:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  572c29:	00 
  572c2a:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  572c2f:	80 3c 10 c0          	cmpb   $0xc0,(%rax,%rdx,1)
  572c33:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  572c38:	7d 1d                	jge    572c57 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xff7>
  572c3a:	4c 8d 05 3f 26 2d 00 	lea    0x2d263f(%rip),%r8        # 845280 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa70>
  572c41:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  572c46:	e9 22 03 00 00       	jmp    572f6d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x130d>
  572c4b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  572c50:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  572c55:	75 e3                	jne    572c3a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfda>
  572c57:	48 29 d6             	sub    %rdx,%rsi
  572c5a:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  572c61:	00 
  572c62:	48 01 ca             	add    %rcx,%rdx
  572c65:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  572c6a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  572c6f:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  572c76:	00 
  572c77:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  572c7c:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  572c83:	00 
  572c84:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  572c89:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  572c8e:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  572c93:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  572c98:	ff 15 0a a6 2e 00    	call   *0x2ea60a(%rip)        # 85d2a8 <_DYNAMIC+0x430>
  572c9e:	48 89 c5             	mov    %rax,%rbp
  572ca1:	48 c7 44 24 10 20 00 	movq   $0x20,0x10(%rsp)
  572ca8:	00 00 
  572caa:	48 85 c0             	test   %rax,%rax
  572cad:	0f 84 71 fa ff ff    	je     572724 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  572cb3:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  572cb8:	e8 e3 93 ff ff       	call   56c0a0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  572cbd:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  572cc2:	48 8b 78 30          	mov    0x30(%rax),%rdi
  572cc6:	e8 15 92 ff ff       	call   56bee0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  572ccb:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  572cd0:	48 89 68 30          	mov    %rbp,0x30(%rax)
  572cd4:	41 b7 01             	mov    $0x1,%r15b
  572cd7:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  572cdc:	48 01 8c 24 90 00 00 	add    %rcx,0x90(%rsp)
  572ce3:	00 
  572ce4:	41 f6 c4 01          	test   $0x1,%r12b
  572ce8:	0f 84 fd fe ff ff    	je     572beb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf8b>
  572cee:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  572cf3:	44 8b 60 08          	mov    0x8(%rax),%r12d
  572cf7:	41 01 cc             	add    %ecx,%r12d
  572cfa:	8b 40 10             	mov    0x10(%rax),%eax
  572cfd:	01 c8                	add    %ecx,%eax
  572cff:	48 c1 e0 20          	shl    $0x20,%rax
  572d03:	49 09 c4             	or     %rax,%r12
  572d06:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  572d0c:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  572d11:	48 8b 70 30          	mov    0x30(%rax),%rsi
  572d15:	48 8b 16             	mov    (%rsi),%rdx
  572d18:	48 d1 ea             	shr    $1,%rdx
  572d1b:	48 83 c6 10          	add    $0x10,%rsi
  572d1f:	44 89 ac 24 10 01 00 	mov    %r13d,0x110(%rsp)
  572d26:	00 
  572d27:	4c 89 a4 24 14 01 00 	mov    %r12,0x114(%rsp)
  572d2e:	00 
  572d2f:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  572d34:	4c 8d 8c 24 10 01 00 	lea    0x110(%rsp),%r9
  572d3b:	00 
  572d3c:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  572d43:	00 
  572d44:	ff 15 66 a5 2e 00    	call   *0x2ea566(%rip)        # 85d2b0 <_DYNAMIC+0x438>
  572d4a:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  572d4f:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  572d54:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
  572d5b:	00 
  572d5c:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  572d61:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
  572d68:	00 
  572d69:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  572d6d:	0f 85 f5 00 00 00    	jne    572e68 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1208>
  572d73:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
  572d7a:	00 
  572d7b:	66 0f 6f 8c 24 50 01 	movdqa 0x150(%rsp),%xmm1
  572d82:	00 00 
  572d84:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  572d8b:	00 
  572d8c:	66 0f 7f 8c 24 10 01 	movdqa %xmm1,0x110(%rsp)
  572d93:	00 00 
  572d95:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  572d9a:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  572d9e:	66 0f 6f 84 24 10 01 	movdqa 0x110(%rsp),%xmm0
  572da5:	00 00 
  572da7:	f3 0f 7f 42 20       	movdqu %xmm0,0x20(%rdx)
  572dac:	48 8b 04 24          	mov    (%rsp),%rax
  572db0:	48 8b 00             	mov    (%rax),%rax
  572db3:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  572dba:	00 
  572dbb:	48 c1 e1 20          	shl    $0x20,%rcx
  572dbf:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  572dc4:	48 09 f1             	or     %rsi,%rcx
  572dc7:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
  572dce:	00 
  572dcf:	48 89 7a 38          	mov    %rdi,0x38(%rdx)
  572dd3:	48 89 42 40          	mov    %rax,0x40(%rdx)
  572dd7:	48 89 4a 48          	mov    %rcx,0x48(%rdx)
  572ddb:	44 89 6a 50          	mov    %r13d,0x50(%rdx)
  572ddf:	4c 89 62 54          	mov    %r12,0x54(%rdx)
  572de3:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  572de8:	ff 15 8a a4 2e 00    	call   *0x2ea48a(%rip)        # 85d278 <_DYNAMIC+0x400>
  572dee:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  572df3:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
  572df7:	0f b6 44 24 1c       	movzbl 0x1c(%rsp),%eax
  572dfc:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  572e00:	0f 85 a0 00 00 00    	jne    572ea6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1246>
  572e06:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
  572e0a:	88 44 24 14          	mov    %al,0x14(%rsp)
  572e0e:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
  572e12:	88 44 24 1c          	mov    %al,0x1c(%rsp)
  572e16:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  572e1b:	4c 89 f7             	mov    %r14,%rdi
  572e1e:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  572e25:	00 
  572e26:	e8 a5 c7 ff ff       	call   56f5d0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::set_selection>
  572e2b:	45 84 ff             	test   %r15b,%r15b
  572e2e:	74 18                	je     572e48 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x11e8>
  572e30:	4c 89 f7             	mov    %r14,%rdi
  572e33:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  572e3a:	00 
  572e3b:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  572e42:	00 
  572e43:	e8 28 db ff ff       	call   570970 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  572e48:	41 c6 86 2b 07 00 00 	movb   $0x1,0x72b(%r14)
  572e4f:	01 
  572e50:	48 c7 84 24 a0 00 00 	movq   $0xfffffffffffffffe,0xa0(%rsp)
  572e57:	00 fe ff ff ff 
  572e5c:	48 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%rbp
  572e63:	e9 e0 f8 ff ff       	jmp    572748 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  572e68:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  572e6d:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
  572e74:	00 
  572e75:	66 0f 6f 84 24 40 01 	movdqa 0x140(%rsp),%xmm0
  572e7c:	00 00 
  572e7e:	66 0f 6f 8c 24 50 01 	movdqa 0x150(%rsp),%xmm1
  572e85:	00 00 
  572e87:	f3 0f 7f 84 24 a8 00 	movdqu %xmm0,0xa8(%rsp)
  572e8e:	00 00 
  572e90:	f3 0f 7f 8c 24 b8 00 	movdqu %xmm1,0xb8(%rsp)
  572e97:	00 00 
  572e99:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  572ea0:	00 
  572ea1:	e9 a2 f8 ff ff       	jmp    572748 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  572ea6:	f3 0f 6f 44 24 1d    	movdqu 0x1d(%rsp),%xmm0
  572eac:	f3 0f 6f 4c 24 2d    	movdqu 0x2d(%rsp),%xmm1
  572eb2:	f3 0f 6f 54 24 38    	movdqu 0x38(%rsp),%xmm2
  572eb8:	f3 0f 7f 94 24 c8 00 	movdqu %xmm2,0xc8(%rsp)
  572ebf:	00 00 
  572ec1:	f3 0f 7f 8c 24 bd 00 	movdqu %xmm1,0xbd(%rsp)
  572ec8:	00 00 
  572eca:	f3 0f 7f 84 24 ad 00 	movdqu %xmm0,0xad(%rsp)
  572ed1:	00 00 
  572ed3:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  572eda:	00 
  572edb:	89 8c 24 a8 00 00 00 	mov    %ecx,0xa8(%rsp)
  572ee2:	88 84 24 ac 00 00 00 	mov    %al,0xac(%rsp)
  572ee9:	e9 5a f8 ff ff       	jmp    572748 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  572eee:	48 8d 3d 0b 1c 2d 00 	lea    0x2d1c0b(%rip),%rdi        # 844b00 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x2f0>
  572ef5:	ff 15 fd a1 2e 00    	call   *0x2ea1fd(%rip)        # 85d0f8 <_DYNAMIC+0x280>
  572efb:	48 8d 3d 86 21 2d 00 	lea    0x2d2186(%rip),%rdi        # 845088 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x878>
  572f02:	ff 15 f0 a1 2e 00    	call   *0x2ea1f0(%rip)        # 85d0f8 <_DYNAMIC+0x280>
  572f08:	bf 08 00 00 00       	mov    $0x8,%edi
  572f0d:	be 38 00 00 00       	mov    $0x38,%esi
  572f12:	ff 15 d0 a1 2e 00    	call   *0x2ea1d0(%rip)        # 85d0e8 <_DYNAMIC+0x270>
  572f18:	e9 9e 00 00 00       	jmp    572fbb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  572f1d:	48 8d 3d 30 39 ad ff 	lea    -0x52c6d0(%rip),%rdi        # 46854 <anon.72786b07d16308d9adbd85e9b0d1bfa8.348.llvm.9246593494314379644+0x2df4>
  572f24:	48 8d 15 15 24 2d 00 	lea    0x2d2415(%rip),%rdx        # 845340 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xb30>
  572f2b:	be 83 00 00 00       	mov    $0x83,%esi
  572f30:	ff 15 da a1 2e 00    	call   *0x2ea1da(%rip)        # 85d110 <_DYNAMIC+0x298>
  572f36:	48 8b 47 08          	mov    0x8(%rdi),%rax
  572f3a:	ff 15 e8 a1 2e 00    	call   *0x2ea1e8(%rip)        # 85d128 <_DYNAMIC+0x2b0>
  572f40:	e9 35 f9 ff ff       	jmp    57287a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  572f45:	48 8b 47 08          	mov    0x8(%rdi),%rax
  572f49:	ff 15 d9 a1 2e 00    	call   *0x2ea1d9(%rip)        # 85d128 <_DYNAMIC+0x2b0>
  572f4f:	e9 4f f9 ff ff       	jmp    5728a3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  572f54:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  572f59:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  572f5e:	eb 08                	jmp    572f68 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1308>
  572f60:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  572f67:	00 
  572f68:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  572f6d:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  572f74:	00 
  572f75:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  572f7a:	ff 15 38 a3 2e 00    	call   *0x2ea338(%rip)        # 85d2b8 <_DYNAMIC+0x440>
  572f80:	eb 39                	jmp    572fbb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  572f82:	bf 08 00 00 00       	mov    $0x8,%edi
  572f87:	be 60 00 00 00       	mov    $0x60,%esi
  572f8c:	ff 15 56 a1 2e 00    	call   *0x2ea156(%rip)        # 85d0e8 <_DYNAMIC+0x270>
  572f92:	eb 27                	jmp    572fbb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  572f94:	48 8d 15 bd 20 2d 00 	lea    0x2d20bd(%rip),%rdx        # 845058 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x848>
  572f9b:	ff 15 7f a2 2e 00    	call   *0x2ea27f(%rip)        # 85d220 <_DYNAMIC+0x3a8>
  572fa1:	48 8d 15 40 1b 2d 00 	lea    0x2d1b40(%rip),%rdx        # 844ae8 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x2d8>
  572fa8:	ff 15 72 a2 2e 00    	call   *0x2ea272(%rip)        # 85d220 <_DYNAMIC+0x3a8>
  572fae:	48 8d 15 6b 22 2d 00 	lea    0x2d226b(%rip),%rdx        # 845220 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa10>
  572fb5:	ff 15 65 a2 2e 00    	call   *0x2ea265(%rip)        # 85d220 <_DYNAMIC+0x3a8>
  572fbb:	0f 0b                	ud2
  572fbd:	48 89 c3             	mov    %rax,%rbx
  572fc0:	be 60 00 00 00       	mov    $0x60,%esi
  572fc5:	ba 08 00 00 00       	mov    $0x8,%edx
  572fca:	4c 89 ff             	mov    %r15,%rdi
  572fcd:	ff 15 fd a0 2e 00    	call   *0x2ea0fd(%rip)        # 85d0d0 <_DYNAMIC+0x258>
  572fd3:	e9 93 00 00 00       	jmp    57306b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  572fd8:	48 89 c3             	mov    %rax,%rbx
  572fdb:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  572fdf:	e8 bc 55 ff ff       	call   5685a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  572fe4:	e9 82 00 00 00       	jmp    57306b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  572fe9:	eb 00                	jmp    572feb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x138b>
  572feb:	48 89 c3             	mov    %rax,%rbx
  572fee:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  572ff3:	48 89 68 30          	mov    %rbp,0x30(%rax)
  572ff7:	eb 58                	jmp    573051 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  572ff9:	48 89 c3             	mov    %rax,%rbx
  572ffc:	eb 6d                	jmp    57306b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  572ffe:	48 89 c3             	mov    %rax,%rbx
  573001:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  573005:	e8 96 55 ff ff       	call   5685a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  57300a:	eb 5f                	jmp    57306b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  57300c:	48 89 c3             	mov    %rax,%rbx
  57300f:	48 c7 45 30 00 00 00 	movq   $0x0,0x30(%rbp)
  573016:	00 
  573017:	eb 38                	jmp    573051 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  573019:	48 89 c3             	mov    %rax,%rbx
  57301c:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  573020:	0f 84 89 00 00 00    	je     5730af <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x144f>
  573026:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  57302d:	00 
  57302e:	e8 6d 90 ff ff       	call   56c0a0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  573033:	48 89 df             	mov    %rbx,%rdi
  573036:	e8 35 03 2d 00       	call   843370 <_Unwind_Resume@plt>
  57303b:	48 89 c3             	mov    %rax,%rbx
  57303e:	48 89 ef             	mov    %rbp,%rdi
  573041:	e8 ba 62 ff ff       	call   569300 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::editing::LogicalSelection>>>
  573046:	eb 09                	jmp    573051 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  573048:	ff 15 ba a0 2e 00    	call   *0x2ea0ba(%rip)        # 85d108 <_DYNAMIC+0x290>
  57304e:	48 89 c3             	mov    %rax,%rbx
  573051:	48 8b 04 24          	mov    (%rsp),%rax
  573055:	48 8b 78 20          	mov    0x20(%rax),%rdi
  573059:	e8 82 8e ff ff       	call   56bee0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  57305e:	48 8b 04 24          	mov    (%rsp),%rax
  573062:	48 8b 78 30          	mov    0x30(%rax),%rdi
  573066:	e8 35 55 ff ff       	call   5685a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  57306b:	be 38 00 00 00       	mov    $0x38,%esi
  573070:	ba 08 00 00 00       	mov    $0x8,%edx
  573075:	48 8b 3c 24          	mov    (%rsp),%rdi
  573079:	ff 15 51 a0 2e 00    	call   *0x2ea051(%rip)        # 85d0d0 <_DYNAMIC+0x258>
  57307f:	48 89 df             	mov    %rbx,%rdi
  573082:	e8 e9 02 2d 00       	call   843370 <_Unwind_Resume@plt>
  573087:	ff 15 7b a0 2e 00    	call   *0x2ea07b(%rip)        # 85d108 <_DYNAMIC+0x290>
  57308d:	48 89 c3             	mov    %rax,%rbx
  573090:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  573095:	e8 06 90 ff ff       	call   56c0a0 <core::ptr::drop_glue::<gpui::runtime::Error>>
  57309a:	48 89 df             	mov    %rbx,%rdi
  57309d:	e8 ce 02 2d 00       	call   843370 <_Unwind_Resume@plt>
  5730a2:	48 89 c3             	mov    %rax,%rbx
  5730a5:	48 89 ef             	mov    %rbp,%rdi
  5730a8:	31 f6                	xor    %esi,%esi
  5730aa:	e8 31 a1 ff ff       	call   56d1e0 <core::ptr::drop_glue::<gpui::runtime::ime::Active>>
  5730af:	48 89 df             	mov    %rbx,%rdi
  5730b2:	e8 b9 02 2d 00       	call   843370 <_Unwind_Resume@plt>
  5730b7:	ff 15 4b a0 2e 00    	call   *0x2ea04b(%rip)        # 85d108 <_DYNAMIC+0x290>
