
/tmp/gpui-ime-ascii-candidate-executable-root/ime_cursor_cost:     file format elf64-x86-64


Disassembly of section .text:

0000000000574530 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event>:
  574530:	55                   	push   %rbp
  574531:	41 57                	push   %r15
  574533:	41 56                	push   %r14
  574535:	41 55                	push   %r13
  574537:	41 54                	push   %r12
  574539:	53                   	push   %rbx
  57453a:	48 81 ec 78 01 00 00 	sub    $0x178,%rsp
  574541:	49 89 f5             	mov    %rsi,%r13
  574544:	4c 8b 21             	mov    (%rcx),%r12
  574547:	4c 89 e0             	mov    %r12,%rax
  57454a:	48 83 e8 02          	sub    $0x2,%rax
  57454e:	bd 01 00 00 00       	mov    $0x1,%ebp
  574553:	48 0f 43 e8          	cmovae %rax,%rbp
  574557:	48 89 fb             	mov    %rdi,%rbx
  57455a:	4c 8d 7d fd          	lea    -0x3(%rbp),%r15
  57455e:	48 8b 02             	mov    (%rdx),%rax
  574561:	49 83 ff 01          	cmp    $0x1,%r15
  574565:	77 07                	ja     57456e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x3e>
  574567:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
  57456e:	4d 8b 75 00          	mov    0x0(%r13),%r14
  574572:	4d 85 f6             	test   %r14,%r14
  574575:	0f 84 e0 00 00 00    	je     57465b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12b>
  57457b:	49 8b b6 20 06 00 00 	mov    0x620(%r14),%rsi
  574582:	48 85 f6             	test   %rsi,%rsi
  574585:	0f 84 04 01 00 00    	je     57468f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x15f>
  57458b:	48 8b be e0 00 00 00 	mov    0xe0(%rsi),%rdi
  574592:	48 85 ff             	test   %rdi,%rdi
  574595:	0f 84 d4 00 00 00    	je     57466f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  57459b:	48 8b 7f 60          	mov    0x60(%rdi),%rdi
  57459f:	48 85 ff             	test   %rdi,%rdi
  5745a2:	0f 84 c7 00 00 00    	je     57466f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  5745a8:	48 8b 3f             	mov    (%rdi),%rdi
  5745ab:	48 85 ff             	test   %rdi,%rdi
  5745ae:	0f 84 bb 00 00 00    	je     57466f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f>
  5745b4:	4c 8b 47 08          	mov    0x8(%rdi),%r8
  5745b8:	48 8b 7f 10          	mov    0x10(%rdi),%rdi
  5745bc:	48 89 bc 24 28 01 00 	mov    %rdi,0x128(%rsp)
  5745c3:	00 
  5745c4:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  5745cb:	00 
  5745cc:	0f 85 ae 00 00 00    	jne    574680 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x150>
  5745d2:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  5745d9:	49 c7 86 18 07 00 00 	movq   $0x0,0x718(%r14)
  5745e0:	00 00 00 00 
  5745e4:	48 8b b6 e0 00 00 00 	mov    0xe0(%rsi),%rsi
  5745eb:	48 85 f6             	test   %rsi,%rsi
  5745ee:	0f 84 5d 01 00 00    	je     574751 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  5745f4:	48 8b 76 60          	mov    0x60(%rsi),%rsi
  5745f8:	48 85 f6             	test   %rsi,%rsi
  5745fb:	0f 84 50 01 00 00    	je     574751 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  574601:	48 8b 36             	mov    (%rsi),%rsi
  574604:	48 85 f6             	test   %rsi,%rsi
  574607:	0f 84 44 01 00 00    	je     574751 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  57460d:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  574614:	00 
  574615:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  57461a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  57461f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  574624:	4c 89 f7             	mov    %r14,%rdi
  574627:	e8 f4 ed ff ff       	call   573420 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::ime_valid>
  57462c:	84 c0                	test   %al,%al
  57462e:	75 08                	jne    574638 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x108>
  574630:	4c 89 f7             	mov    %r14,%rdi
  574633:	e8 08 e5 ff ff       	call   572b40 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  574638:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  57463d:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574642:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
  574647:	4c 8b 84 24 88 00 00 	mov    0x88(%rsp),%r8
  57464e:	00 
  57464f:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  574656:	e9 f6 00 00 00       	jmp    574751 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x221>
  57465b:	48 c7 03 0d 00 00 00 	movq   $0xd,(%rbx)
  574662:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
  574669:	00 
  57466a:	e9 67 04 00 00       	jmp    574ad6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5a6>
  57466f:	45 31 c0             	xor    %r8d,%r8d
  574672:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  574679:	00 
  57467a:	0f 84 52 ff ff ff    	je     5745d2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xa2>
  574680:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  574687:	00 
  574688:	bd 0e 00 00 00       	mov    $0xe,%ebp
  57468d:	eb 1f                	jmp    5746ae <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x17e>
  57468f:	41 80 be 2e 07 00 00 	cmpb   $0x0,0x72e(%r14)
  574696:	00 
  574697:	0f 84 9f 00 00 00    	je     57473c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x20c>
  57469d:	bd 0e 00 00 00       	mov    $0xe,%ebp
  5746a2:	48 c7 84 24 88 00 00 	movq   $0x0,0x88(%rsp)
  5746a9:	00 00 00 00 00 
  5746ae:	45 31 ff             	xor    %r15d,%r15d
  5746b1:	45 31 e4             	xor    %r12d,%r12d
  5746b4:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
  5746b9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  5746be:	f3 0f 7f 4c 24 20    	movdqu %xmm1,0x20(%rsp)
  5746c4:	48 89 4c 24 30       	mov    %rcx,0x30(%rsp)
  5746c9:	41 0f b6 c4          	movzbl %r12b,%eax
  5746cd:	4c 09 f8             	or     %r15,%rax
  5746d0:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
  5746d5:	4c 89 6c 24 40       	mov    %r13,0x40(%rsp)
  5746da:	48 c7 02 00 00 00 00 	movq   $0x0,(%rdx)
  5746e1:	4c 89 f7             	mov    %r14,%rdi
  5746e4:	e8 57 e4 ff ff       	call   572b40 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  5746e9:	48 8b b4 24 88 00 00 	mov    0x88(%rsp),%rsi
  5746f0:	00 
  5746f1:	48 85 f6             	test   %rsi,%rsi
  5746f4:	74 10                	je     574706 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1d6>
  5746f6:	4c 89 f7             	mov    %r14,%rdi
  5746f9:	48 8b 94 24 28 01 00 	mov    0x128(%rsp),%rdx
  574700:	00 
  574701:	e8 3a eb ff ff       	call   573240 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  574706:	4c 89 f7             	mov    %r14,%rdi
  574709:	e8 a2 e7 ff ff       	call   572eb0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::reclaim_ime>
  57470e:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  574713:	48 89 43 30          	mov    %rax,0x30(%rbx)
  574717:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
  57471d:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  574723:	f3 0f 6f 54 24 30    	movdqu 0x30(%rsp),%xmm2
  574729:	f3 0f 7f 53 20       	movdqu %xmm2,0x20(%rbx)
  57472e:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  574733:	f3 0f 7f 03          	movdqu %xmm0,(%rbx)
  574737:	e9 9a 03 00 00       	jmp    574ad6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5a6>
  57473c:	4d 8d 8e 18 07 00 00 	lea    0x718(%r14),%r9
  574743:	49 c7 86 18 07 00 00 	movq   $0x0,0x718(%r14)
  57474a:	00 00 00 00 
  57474e:	45 31 c0             	xor    %r8d,%r8d
  574751:	48 85 ed             	test   %rbp,%rbp
  574754:	0f 84 12 01 00 00    	je     57486c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x33c>
  57475a:	49 8b b6 20 06 00 00 	mov    0x620(%r14),%rsi
  574761:	48 85 f6             	test   %rsi,%rsi
  574764:	0f 84 cb 00 00 00    	je     574835 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  57476a:	48 8b b6 e0 00 00 00 	mov    0xe0(%rsi),%rsi
  574771:	48 85 f6             	test   %rsi,%rsi
  574774:	0f 84 bb 00 00 00    	je     574835 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  57477a:	48 8b 76 60          	mov    0x60(%rsi),%rsi
  57477e:	48 85 f6             	test   %rsi,%rsi
  574781:	0f 84 ae 00 00 00    	je     574835 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  574787:	48 8b 3e             	mov    (%rsi),%rdi
  57478a:	48 89 3c 24          	mov    %rdi,(%rsp)
  57478e:	48 85 ff             	test   %rdi,%rdi
  574791:	0f 84 9e 00 00 00    	je     574835 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  574797:	48 85 c0             	test   %rax,%rax
  57479a:	0f 84 95 00 00 00    	je     574835 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  5747a0:	48 8b 3c 24          	mov    (%rsp),%rdi
  5747a4:	48 39 07             	cmp    %rax,(%rdi)
  5747a7:	0f 85 88 00 00 00    	jne    574835 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x305>
  5747ad:	49 83 ff 01          	cmp    $0x1,%r15
  5747b1:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  5747b6:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  5747bd:	00 
  5747be:	0f 87 a4 03 00 00    	ja     574b68 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x638>
  5747c4:	4d 89 cf             	mov    %r9,%r15
  5747c7:	4c 89 f7             	mov    %r14,%rdi
  5747ca:	e8 71 e3 ff ff       	call   572b40 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  5747cf:	84 c0                	test   %al,%al
  5747d1:	0f 84 2d 04 00 00    	je     574c04 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6d4>
  5747d7:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  5747dc:	4c 89 f6             	mov    %r14,%rsi
  5747df:	e8 cc 60 01 00       	call   58a8b0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  5747e4:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  5747e9:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5747ed:	0f 85 e3 03 00 00    	jne    574bd6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6a6>
  5747f3:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  5747f8:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  5747fe:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  574803:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574808:	44 0f b6 6c 24 40    	movzbl 0x40(%rsp),%r13d
  57480e:	0f b6 44 24 47       	movzbl 0x47(%rsp),%eax
  574813:	c1 e0 10             	shl    $0x10,%eax
  574816:	0f b7 4c 24 45       	movzwl 0x45(%rsp),%ecx
  57481b:	09 c1                	or     %eax,%ecx
  57481d:	48 c1 e1 20          	shl    $0x20,%rcx
  574821:	44 8b 74 24 41       	mov    0x41(%rsp),%r14d
  574826:	49 09 ce             	or     %rcx,%r14
  574829:	31 c0                	xor    %eax,%eax
  57482b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574830:	e9 77 02 00 00       	jmp    574aac <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  574835:	49 8b 86 70 06 00 00 	mov    0x670(%r14),%rax
  57483c:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  574843:	00 
  574844:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  57484b:	00 
  57484c:	74 17                	je     574865 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x335>
  57484e:	45 84 ed             	test   %r13b,%r13b
  574851:	0f 84 2f 02 00 00    	je     574a86 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x556>
  574857:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  57485e:	ff 
  57485f:	0f 85 21 02 00 00    	jne    574a86 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x556>
  574865:	31 ff                	xor    %edi,%edi
  574867:	e9 26 02 00 00       	jmp    574a92 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x562>
  57486c:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
  574871:	4c 89 84 24 88 00 00 	mov    %r8,0x88(%rsp)
  574878:	00 
  574879:	4c 89 f7             	mov    %r14,%rdi
  57487c:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
  574881:	e8 ba e2 ff ff       	call   572b40 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::cancel_ime>
  574886:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  57488b:	48 8b 0d 9e b5 2e 00 	mov    0x2eb59e(%rip),%rcx        # 85fe30 <_DYNAMIC+0x428>
  574892:	48 8b 01             	mov    (%rcx),%rax
  574895:	45 31 ff             	xor    %r15d,%r15d
  574898:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  57489f:	00 
  5748a0:	48 83 f8 ff          	cmp    $0xffffffffffffffff,%rax
  5748a4:	0f 84 d2 01 00 00    	je     574a7c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x54c>
  5748aa:	48 8d 70 01          	lea    0x1(%rax),%rsi
  5748ae:	f0 48 0f b1 31       	lock cmpxchg %rsi,(%rcx)
  5748b3:	75 eb                	jne    5748a0 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x370>
  5748b5:	48 85 c0             	test   %rax,%rax
  5748b8:	0f 84 05 0c 00 00    	je     5754c3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf93>
  5748be:	4d 8b ae f8 05 00 00 	mov    0x5f8(%r14),%r13
  5748c5:	4d 85 ed             	test   %r13,%r13
  5748c8:	0f 84 1d 02 00 00    	je     574aeb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5bb>
  5748ce:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  5748d3:	4d 8b a6 00 06 00 00 	mov    0x600(%r14),%r12
  5748da:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  5748df:	4c 89 f6             	mov    %r14,%rsi
  5748e2:	4c 89 ea             	mov    %r13,%rdx
  5748e5:	4c 89 e1             	mov    %r12,%rcx
  5748e8:	e8 23 d3 ff ff       	call   571c10 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  5748ed:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  5748f2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  5748f7:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5748fb:	0f 85 f1 01 00 00    	jne    574af2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5c2>
  574901:	49 8b b6 a8 02 00 00 	mov    0x2a8(%r14),%rsi
  574908:	48 39 f7             	cmp    %rsi,%rdi
  57490b:	0f 83 53 0f 00 00    	jae    575864 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1334>
  574911:	49 8b 86 a0 02 00 00 	mov    0x2a0(%r14),%rax
  574918:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  57491c:	8b 7c c8 10          	mov    0x10(%rax,%rcx,8),%edi
  574920:	89 f8                	mov    %edi,%eax
  574922:	83 e0 0f             	and    $0xf,%eax
  574925:	83 f8 09             	cmp    $0x9,%eax
  574928:	0f 87 bf 0e 00 00    	ja     5757ed <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12bd>
  57492e:	83 f8 06             	cmp    $0x6,%eax
  574931:	0f 84 87 03 00 00    	je     574cbe <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x78e>
  574937:	c1 ef 04             	shr    $0x4,%edi
  57493a:	0f 84 7e 03 00 00    	je     574cbe <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x78e>
  574940:	49 8b b6 c0 02 00 00 	mov    0x2c0(%r14),%rsi
  574947:	ff cf                	dec    %edi
  574949:	48 39 fe             	cmp    %rdi,%rsi
  57494c:	0f 86 1f 0f 00 00    	jbe    575871 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1341>
  574952:	49 8b 86 b8 02 00 00 	mov    0x2b8(%r14),%rax
  574959:	48 8d 0c bf          	lea    (%rdi,%rdi,4),%rcx
  57495d:	48 c1 e1 04          	shl    $0x4,%rcx
  574961:	83 3c 08 ff          	cmpl   $0xffffffff,(%rax,%rcx,1)
  574965:	0f 84 53 0e 00 00    	je     5757be <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x128e>
  57496b:	48 01 c8             	add    %rcx,%rax
  57496e:	4c 8b 78 48          	mov    0x48(%rax),%r15
  574972:	4d 85 ff             	test   %r15,%r15
  574975:	0f 84 50 0e 00 00    	je     5757cb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x129b>
  57497b:	49 8b 8e 70 06 00 00 	mov    0x670(%r14),%rcx
  574982:	48 89 0c 24          	mov    %rcx,(%rsp)
  574986:	48 8b 68 40          	mov    0x40(%rax),%rbp
  57498a:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
  57498e:	75 2e                	jne    5749be <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  574990:	48 8b 45 08          	mov    0x8(%rbp),%rax
  574994:	a8 01                	test   $0x1,%al
  574996:	75 26                	jne    5749be <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  574998:	b8 02 00 00 00       	mov    $0x2,%eax
  57499d:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  5749a3:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  5749aa:	00 00 80 
  5749ad:	48 ff c1             	inc    %rcx
  5749b0:	48 21 c1             	and    %rax,%rcx
  5749b3:	48 f7 d9             	neg    %rcx
  5749b6:	71 06                	jno    5749be <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x48e>
  5749b8:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  5749be:	ff 15 8c b2 2e 00    	call   *0x2eb28c(%rip)        # 85fc50 <_DYNAMIC+0x248>
  5749c4:	bf 38 00 00 00       	mov    $0x38,%edi
  5749c9:	be 08 00 00 00       	mov    $0x8,%esi
  5749ce:	ff 15 84 b2 2e 00    	call   *0x2eb284(%rip)        # 85fc58 <_DYNAMIC+0x250>
  5749d4:	48 85 c0             	test   %rax,%rax
  5749d7:	0f 84 fb 0d 00 00    	je     5757d8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12a8>
  5749dd:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  5749e2:	48 89 08             	mov    %rcx,(%rax)
  5749e5:	4c 89 68 08          	mov    %r13,0x8(%rax)
  5749e9:	4c 89 60 10          	mov    %r12,0x10(%rax)
  5749ed:	4c 89 78 18          	mov    %r15,0x18(%rax)
  5749f1:	48 89 68 20          	mov    %rbp,0x20(%rax)
  5749f5:	48 8b 0c 24          	mov    (%rsp),%rcx
  5749f9:	48 89 48 28          	mov    %rcx,0x28(%rax)
  5749fd:	48 c7 40 30 00 00 00 	movq   $0x0,0x30(%rax)
  574a04:	00 
  574a05:	4c 89 f7             	mov    %r14,%rdi
  574a08:	48 89 c6             	mov    %rax,%rsi
  574a0b:	e8 90 e2 ff ff       	call   572ca0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  574a10:	41 80 be 2b 07 00 00 	cmpb   $0x0,0x72b(%r14)
  574a17:	00 
  574a18:	0f 84 00 01 00 00    	je     574b1e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5ee>
  574a1e:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574a23:	4c 89 f6             	mov    %r14,%rsi
  574a26:	e8 85 5e 01 00       	call   58a8b0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  574a2b:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574a30:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574a34:	0f 85 9c 01 00 00    	jne    574bd6 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x6a6>
  574a3a:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  574a3f:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  574a45:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  574a4a:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574a4f:	44 0f b6 6c 24 40    	movzbl 0x40(%rsp),%r13d
  574a55:	0f b6 44 24 47       	movzbl 0x47(%rsp),%eax
  574a5a:	c1 e0 10             	shl    $0x10,%eax
  574a5d:	0f b7 4c 24 45       	movzwl 0x45(%rsp),%ecx
  574a62:	09 c1                	or     %eax,%ecx
  574a64:	48 c1 e1 20          	shl    $0x20,%rcx
  574a68:	44 8b 74 24 41       	mov    0x41(%rsp),%r14d
  574a6d:	49 09 ce             	or     %rcx,%r14
  574a70:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574a75:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574a7a:	eb 30                	jmp    574aac <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  574a7c:	bd 21 00 00 00       	mov    $0x21,%ebp
  574a81:	e9 2b fc ff ff       	jmp    5746b1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x181>
  574a86:	49 8b 8e a0 06 00 00 	mov    0x6a0(%r14),%rcx
  574a8d:	bf 01 00 00 00       	mov    $0x1,%edi
  574a92:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  574a99:	4d 8b 21             	mov    (%r9),%r12
  574a9c:	66 48 0f 6e c0       	movq   %rax,%xmm0
  574aa1:	66 48 0f 6e c9       	movq   %rcx,%xmm1
  574aa6:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
  574aaa:	31 c0                	xor    %eax,%eax
  574aac:	49 c1 e6 08          	shl    $0x8,%r14
  574ab0:	41 0f b6 cd          	movzbl %r13b,%ecx
  574ab4:	4c 09 f1             	or     %r14,%rcx
  574ab7:	48 89 02             	mov    %rax,(%rdx)
  574aba:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
  574abe:	f3 0f 7f 4b 10       	movdqu %xmm1,0x10(%rbx)
  574ac3:	4c 89 7b 20          	mov    %r15,0x20(%rbx)
  574ac7:	4c 89 63 28          	mov    %r12,0x28(%rbx)
  574acb:	48 89 4b 30          	mov    %rcx,0x30(%rbx)
  574acf:	48 c7 03 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rbx)
  574ad6:	48 89 d8             	mov    %rbx,%rax
  574ad9:	48 81 c4 78 01 00 00 	add    $0x178,%rsp
  574ae0:	5b                   	pop    %rbx
  574ae1:	41 5c                	pop    %r12
  574ae3:	41 5d                	pop    %r13
  574ae5:	41 5e                	pop    %r14
  574ae7:	41 5f                	pop    %r15
  574ae9:	5d                   	pop    %rbp
  574aea:	c3                   	ret
  574aeb:	bd 19 00 00 00       	mov    $0x19,%ebp
  574af0:	eb 18                	jmp    574b0a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  574af2:	48 89 f8             	mov    %rdi,%rax
  574af5:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  574afb:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  574b00:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574b05:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  574b0a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574b0f:	4d 89 e7             	mov    %r12,%r15
  574b12:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  574b19:	e9 96 fb ff ff       	jmp    5746b4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  574b1e:	49 8b 8e 70 06 00 00 	mov    0x670(%r14),%rcx
  574b25:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  574b2c:	00 
  574b2d:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  574b34:	00 
  574b35:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574b3a:	0f 84 47 01 00 00    	je     574c87 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x757>
  574b40:	45 84 ed             	test   %r13b,%r13b
  574b43:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574b48:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  574b4d:	0f 84 42 01 00 00    	je     574c95 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x765>
  574b53:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  574b5a:	ff 
  574b5b:	0f 85 34 01 00 00    	jne    574c95 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x765>
  574b61:	31 ff                	xor    %edi,%edi
  574b63:	e9 39 01 00 00       	jmp    574ca1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x771>
  574b68:	48 c7 06 00 00 00 00 	movq   $0x0,(%rsi)
  574b6f:	48 83 fd 01          	cmp    $0x1,%rbp
  574b73:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  574b78:	0f 84 c9 00 00 00    	je     574c47 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x717>
  574b7e:	4c 8b 79 08          	mov    0x8(%rcx),%r15
  574b82:	4c 8b 61 10          	mov    0x10(%rcx),%r12
  574b86:	48 8b 04 24          	mov    (%rsp),%rax
  574b8a:	48 8b 50 08          	mov    0x8(%rax),%rdx
  574b8e:	48 8b 48 10          	mov    0x10(%rax),%rcx
  574b92:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574b97:	4c 89 f6             	mov    %r14,%rsi
  574b9a:	e8 71 d0 ff ff       	call   571c10 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  574b9f:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574ba4:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  574ba9:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  574bae:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574bb2:	0f 85 4b 05 00 00    	jne    575103 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbd3>
  574bb8:	48 8b 04 24          	mov    (%rsp),%rax
  574bbc:	48 8b 40 30          	mov    0x30(%rax),%rax
  574bc0:	48 85 c0             	test   %rax,%rax
  574bc3:	0f 84 24 01 00 00    	je     574ced <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7bd>
  574bc9:	0f 10 00             	movups (%rax),%xmm0
  574bcc:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  574bd1:	e9 38 01 00 00       	jmp    574d0e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7de>
  574bd6:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  574bdb:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  574be1:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
  574be6:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574beb:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  574bf0:	4d 89 e7             	mov    %r12,%r15
  574bf3:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  574bfa:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574bff:	e9 b0 fa ff ff       	jmp    5746b4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  574c04:	49 8b 86 70 06 00 00 	mov    0x670(%r14),%rax
  574c0b:	45 0f b6 ae 2c 07 00 	movzbl 0x72c(%r14),%r13d
  574c12:	00 
  574c13:	49 83 be 90 06 00 00 	cmpq   $0x0,0x690(%r14)
  574c1a:	00 
  574c1b:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574c20:	0f 84 a5 00 00 00    	je     574ccb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x79b>
  574c26:	45 84 ed             	test   %r13b,%r13b
  574c29:	4c 89 fe             	mov    %r15,%rsi
  574c2c:	0f 84 a0 00 00 00    	je     574cd2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7a2>
  574c32:	49 83 be 90 05 00 00 	cmpq   $0xffffffffffffffff,0x590(%r14)
  574c39:	ff 
  574c3a:	0f 85 92 00 00 00    	jne    574cd2 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7a2>
  574c40:	31 ff                	xor    %edi,%edi
  574c42:	e9 97 00 00 00       	jmp    574cde <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7ae>
  574c47:	4c 8b 79 18          	mov    0x18(%rcx),%r15
  574c4b:	4c 8b 51 20          	mov    0x20(%rcx),%r10
  574c4f:	49 83 fc 01          	cmp    $0x1,%r12
  574c53:	4c 8b 0c 24          	mov    (%rsp),%r9
  574c57:	0f 85 d5 01 00 00    	jne    574e32 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  574c5d:	48 8b 79 08          	mov    0x8(%rcx),%rdi
  574c61:	48 8b 71 10          	mov    0x10(%rcx),%rsi
  574c65:	48 85 ff             	test   %rdi,%rdi
  574c68:	0f 84 9c 01 00 00    	je     574e0a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8da>
  574c6e:	4c 39 d7             	cmp    %r10,%rdi
  574c71:	0f 83 91 01 00 00    	jae    574e08 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8d8>
  574c77:	41 80 3c 3f bf       	cmpb   $0xbf,(%r15,%rdi,1)
  574c7c:	0f 8f 88 01 00 00    	jg     574e0a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8da>
  574c82:	e9 94 01 00 00       	jmp    574e1b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  574c87:	31 ff                	xor    %edi,%edi
  574c89:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574c8e:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
  574c93:	eb 0c                	jmp    574ca1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x771>
  574c95:	49 8b b6 a0 06 00 00 	mov    0x6a0(%r14),%rsi
  574c9c:	bf 01 00 00 00       	mov    $0x1,%edi
  574ca1:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  574ca8:	4d 8b 20             	mov    (%r8),%r12
  574cab:	66 48 0f 6e c1       	movq   %rcx,%xmm0
  574cb0:	66 48 0f 6e ce       	movq   %rsi,%xmm1
  574cb5:	66 0f 6c c8          	punpcklqdq %xmm0,%xmm1
  574cb9:	e9 ee fd ff ff       	jmp    574aac <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  574cbe:	48 8d 3d 6b 2e 2d 00 	lea    0x2d2e6b(%rip),%rdi        # 847b30 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x860>
  574cc5:	ff 15 bd af 2e 00    	call   *0x2eafbd(%rip)        # 85fc88 <_DYNAMIC+0x280>
  574ccb:	31 ff                	xor    %edi,%edi
  574ccd:	4c 89 fe             	mov    %r15,%rsi
  574cd0:	eb 0c                	jmp    574cde <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x7ae>
  574cd2:	49 8b 8e a0 06 00 00 	mov    0x6a0(%r14),%rcx
  574cd9:	bf 01 00 00 00       	mov    $0x1,%edi
  574cde:	4d 8b be 78 06 00 00 	mov    0x678(%r14),%r15
  574ce5:	4c 8b 26             	mov    (%rsi),%r12
  574ce8:	e9 af fd ff ff       	jmp    574a9c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x56c>
  574ced:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574cf2:	4c 89 f6             	mov    %r14,%rsi
  574cf5:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
  574cfa:	e8 41 d0 ff ff       	call   571d40 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::selection_at>
  574cff:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574d04:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574d08:	0f 85 eb 03 00 00    	jne    5750f9 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbc9>
  574d0e:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  574d14:	66 0f 7f 84 24 30 01 	movdqa %xmm0,0x130(%rsp)
  574d1b:	00 00 
  574d1d:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
  574d24:	00 
  574d25:	4c 89 f7             	mov    %r14,%rdi
  574d28:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
  574d2d:	e8 6e d1 ff ff       	call   571ea0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::set_selection>
  574d32:	48 8b 2c 24          	mov    (%rsp),%rbp
  574d36:	48 8b 7d 30          	mov    0x30(%rbp),%rdi
  574d3a:	e8 31 61 ff ff       	call   56ae70 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  574d3f:	48 c7 45 30 00 00 00 	movq   $0x0,0x30(%rbp)
  574d46:	00 
  574d47:	48 8b 75 08          	mov    0x8(%rbp),%rsi
  574d4b:	48 8b 55 10          	mov    0x10(%rbp),%rdx
  574d4f:	4c 89 f7             	mov    %r14,%rdi
  574d52:	e8 e9 e4 ff ff       	call   573240 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  574d57:	49 83 c5 08          	add    $0x8,%r13
  574d5b:	48 8b 04 24          	mov    (%rsp),%rax
  574d5f:	48 8b 48 08          	mov    0x8(%rax),%rcx
  574d63:	4c 8b 40 10          	mov    0x10(%rax),%r8
  574d67:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574d6c:	4c 8d 8c 24 30 01 00 	lea    0x130(%rsp),%r9
  574d73:	00 
  574d74:	4c 89 f6             	mov    %r14,%rsi
  574d77:	4c 89 ea             	mov    %r13,%rdx
  574d7a:	41 54                	push   %r12
  574d7c:	41 57                	push   %r15
  574d7e:	e8 2d 0d 00 00       	call   575ab0 <<gpui::runtime::RuntimeMut<ime_cursor_cost::Input, ()>>::replace_input>
  574d83:	48 83 c4 10          	add    $0x10,%rsp
  574d87:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574d8c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  574d91:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  574d96:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  574d9c:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  574da3:	00 00 
  574da5:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  574daa:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  574daf:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  574db4:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574db8:	75 44                	jne    574dfe <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8ce>
  574dba:	4c 89 f7             	mov    %r14,%rdi
  574dbd:	48 8b 34 24          	mov    (%rsp),%rsi
  574dc1:	e8 4a e2 ff ff       	call   573010 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::refresh_ime>
  574dc6:	84 c0                	test   %al,%al
  574dc8:	0f 84 d3 02 00 00    	je     5750a1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb71>
  574dce:	4c 89 f7             	mov    %r14,%rdi
  574dd1:	48 8b 34 24          	mov    (%rsp),%rsi
  574dd5:	e8 c6 de ff ff       	call   572ca0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  574dda:	4d 89 ee             	mov    %r13,%r14
  574ddd:	49 c1 ee 08          	shr    $0x8,%r14
  574de1:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  574de6:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
  574deb:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  574df0:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  574df7:	00 00 
  574df9:	e9 ae fc ff ff       	jmp    574aac <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  574dfe:	4c 89 7c 24 58       	mov    %r15,0x58(%rsp)
  574e03:	e9 1e 03 00 00       	jmp    575126 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xbf6>
  574e08:	75 11                	jne    574e1b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  574e0a:	48 85 f6             	test   %rsi,%rsi
  574e0d:	74 23                	je     574e32 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  574e0f:	4c 39 d6             	cmp    %r10,%rsi
  574e12:	73 1c                	jae    574e30 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x900>
  574e14:	41 80 3c 37 bf       	cmpb   $0xbf,(%r15,%rsi,1)
  574e19:	7f 17                	jg     574e32 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x902>
  574e1b:	49 8b 71 08          	mov    0x8(%r9),%rsi
  574e1f:	49 8b 51 10          	mov    0x10(%r9),%rdx
  574e23:	4c 89 f7             	mov    %r14,%rdi
  574e26:	e8 15 e4 ff ff       	call   573240 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  574e2b:	e9 d7 01 00 00       	jmp    575007 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xad7>
  574e30:	75 e9                	jne    574e1b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x8eb>
  574e32:	4c 89 94 24 90 00 00 	mov    %r10,0x90(%rsp)
  574e39:	00 
  574e3a:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
  574e3f:	49 8b 51 08          	mov    0x8(%r9),%rdx
  574e43:	49 8b 49 10          	mov    0x10(%r9),%rcx
  574e47:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574e4c:	4c 89 f6             	mov    %r14,%rsi
  574e4f:	48 89 94 24 00 01 00 	mov    %rdx,0x100(%rsp)
  574e56:	00 
  574e57:	48 89 8c 24 08 01 00 	mov    %rcx,0x108(%rsp)
  574e5e:	00 
  574e5f:	e8 ac cd ff ff       	call   571c10 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::input_index>
  574e64:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574e69:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
  574e6e:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574e72:	75 24                	jne    574e98 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x968>
  574e74:	48 8b 34 24          	mov    (%rsp),%rsi
  574e78:	48 8b 46 30          	mov    0x30(%rsi),%rax
  574e7c:	48 85 c0             	test   %rax,%rax
  574e7f:	48 89 94 24 f8 00 00 	mov    %rdx,0xf8(%rsp)
  574e86:	00 
  574e87:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
  574e8c:	74 4a                	je     574ed8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x9a8>
  574e8e:	0f 10 00             	movups (%rax),%xmm0
  574e91:	0f 11 44 24 18       	movups %xmm0,0x18(%rsp)
  574e96:	eb 60                	jmp    574ef8 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x9c8>
  574e98:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
  574e9d:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
  574ea4:	00 
  574ea5:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  574eab:	f3 0f 6f 4c 24 30    	movdqu 0x30(%rsp),%xmm1
  574eb1:	f3 0f 7f 8c 24 c0 00 	movdqu %xmm1,0xc0(%rsp)
  574eb8:	00 00 
  574eba:	f3 0f 7f 84 24 b0 00 	movdqu %xmm0,0xb0(%rsp)
  574ec1:	00 00 
  574ec3:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  574eca:	00 
  574ecb:	48 89 94 24 a8 00 00 	mov    %rdx,0xa8(%rsp)
  574ed2:	00 
  574ed3:	e9 40 01 00 00       	jmp    575018 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  574ed8:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574edd:	4c 89 f6             	mov    %r14,%rsi
  574ee0:	e8 5b ce ff ff       	call   571d40 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::selection_at>
  574ee5:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  574eea:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  574eee:	48 8b 34 24          	mov    (%rsp),%rsi
  574ef2:	0f 85 c9 02 00 00    	jne    5751c1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc91>
  574ef8:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  574efe:	8b 44 24 24          	mov    0x24(%rsp),%eax
  574f02:	89 84 24 e4 00 00 00 	mov    %eax,0xe4(%rsp)
  574f09:	8b 44 24 20          	mov    0x20(%rsp),%eax
  574f0d:	89 84 24 e0 00 00 00 	mov    %eax,0xe0(%rsp)
  574f14:	8b 44 24 18          	mov    0x18(%rsp),%eax
  574f18:	89 84 24 dc 00 00 00 	mov    %eax,0xdc(%rsp)
  574f1f:	8b 44 24 1c          	mov    0x1c(%rsp),%eax
  574f23:	89 84 24 d8 00 00 00 	mov    %eax,0xd8(%rsp)
  574f2a:	48 8b 6e 20          	mov    0x20(%rsi),%rbp
  574f2e:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  574f32:	48 d1 ee             	shr    $1,%rsi
  574f35:	4c 8d 6d 10          	lea    0x10(%rbp),%r13
  574f39:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
  574f3f:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
  574f45:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  574f4a:	4c 89 ef             	mov    %r13,%rdi
  574f4d:	ff 15 c5 ae 2e 00    	call   *0x2eaec5(%rip)        # 85fe18 <_DYNAMIC+0x410>
  574f53:	84 c0                	test   %al,%al
  574f55:	0f 84 ac 00 00 00    	je     575007 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xad7>
  574f5b:	4c 89 ac 24 80 00 00 	mov    %r13,0x80(%rsp)
  574f62:	00 
  574f63:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
  574f6a:	00 
  574f6b:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
  574f71:	66 41 0f 7e c7       	movd   %xmm0,%r15d
  574f76:	66 0f 70 c0 ee       	pshufd $0xee,%xmm0,%xmm0
  574f7b:	66 0f 7e c0          	movd   %xmm0,%eax
  574f7f:	49 39 c7             	cmp    %rax,%r15
  574f82:	48 89 c2             	mov    %rax,%rdx
  574f85:	49 0f 42 d7          	cmovb  %r15,%rdx
  574f89:	48 89 c6             	mov    %rax,%rsi
  574f8c:	49 0f 47 f7          	cmova  %r15,%rsi
  574f90:	4c 8b 6d 00          	mov    0x0(%rbp),%r13
  574f94:	49 d1 ed             	shr    $1,%r13
  574f97:	89 c1                	mov    %eax,%ecx
  574f99:	44 29 f9             	sub    %r15d,%ecx
  574f9c:	41 29 c7             	sub    %eax,%r15d
  574f9f:	44 0f 42 f9          	cmovb  %ecx,%r15d
  574fa3:	4d 29 fd             	sub    %r15,%r13
  574fa6:	72 4c                	jb     574ff4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  574fa8:	4c 03 ac 24 90 00 00 	add    0x90(%rsp),%r13
  574faf:	00 
  574fb0:	72 42                	jb     574ff4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  574fb2:	48 89 74 24 78       	mov    %rsi,0x78(%rsp)
  574fb7:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
  574fbc:	48 c7 44 24 10 20 00 	movq   $0x20,0x10(%rsp)
  574fc3:	00 00 
  574fc5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  574fca:	e8 a1 99 ff ff       	call   56e970 <core::ptr::drop_glue::<gpui::runtime::Error>>
  574fcf:	49 81 fd 00 80 00 00 	cmp    $0x8000,%r13
  574fd6:	0f 86 1f 02 00 00    	jbe    5751fb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xccb>
  574fdc:	4c 89 f7             	mov    %r14,%rdi
  574fdf:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  574fe6:	00 
  574fe7:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  574fee:	00 
  574fef:	e8 4c e2 ff ff       	call   573240 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  574ff4:	48 c7 84 24 a0 00 00 	movq   $0x20,0xa0(%rsp)
  574ffb:	00 20 00 00 00 
  575000:	bd 20 00 00 00       	mov    $0x20,%ebp
  575005:	eb 11                	jmp    575018 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  575007:	48 c7 84 24 a0 00 00 	movq   $0x1a,0xa0(%rsp)
  57500e:	00 1a 00 00 00 
  575013:	bd 1a 00 00 00       	mov    $0x1a,%ebp
  575018:	48 8b 34 24          	mov    (%rsp),%rsi
  57501c:	4c 89 f7             	mov    %r14,%rdi
  57501f:	e8 7c dc ff ff       	call   572ca0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::install_ime>
  575024:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  575028:	75 3e                	jne    575068 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb38>
  57502a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  57502f:	4c 89 f6             	mov    %r14,%rsi
  575032:	e8 79 58 01 00       	call   58a8b0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::present>
  575037:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  57503c:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
  575041:	f3 0f 6f 4c 24 20    	movdqu 0x20(%rsp),%xmm1
  575047:	4c 8b 7c 24 30       	mov    0x30(%rsp),%r15
  57504c:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  575051:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  575056:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  57505a:	75 3a                	jne    575096 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xb66>
  57505c:	4d 89 ee             	mov    %r13,%r14
  57505f:	49 c1 ee 08          	shr    $0x8,%r14
  575063:	e9 08 fa ff ff       	jmp    574a70 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x540>
  575068:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
  57506f:	00 
  575070:	f3 0f 6f 8c 24 b0 00 	movdqu 0xb0(%rsp),%xmm1
  575077:	00 00 
  575079:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
  575080:	00 
  575081:	4c 8b a4 24 c8 00 00 	mov    0xc8(%rsp),%r12
  575088:	00 
  575089:	4c 8b ac 24 d0 00 00 	mov    0xd0(%rsp),%r13
  575090:	00 
  575091:	e9 74 fa ff ff       	jmp    574b0a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  575096:	4c 89 f9             	mov    %r15,%rcx
  575099:	48 89 f8             	mov    %rdi,%rax
  57509c:	e9 69 fa ff ff       	jmp    574b0a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x5da>
  5750a1:	4c 89 f7             	mov    %r14,%rdi
  5750a4:	e8 07 de ff ff       	call   572eb0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::reclaim_ime>
  5750a9:	4c 89 fd             	mov    %r15,%rbp
  5750ac:	4c 8b 3c 24          	mov    (%rsp),%r15
  5750b0:	49 8b 7f 20          	mov    0x20(%r15),%rdi
  5750b4:	e8 f7 96 ff ff       	call   56e7b0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  5750b9:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  5750bd:	e8 ae 5d ff ff       	call   56ae70 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  5750c2:	4d 89 ee             	mov    %r13,%r14
  5750c5:	49 c1 ee 08          	shr    $0x8,%r14
  5750c9:	be 38 00 00 00       	mov    $0x38,%esi
  5750ce:	ba 08 00 00 00       	mov    $0x8,%edx
  5750d3:	4c 89 ff             	mov    %r15,%rdi
  5750d6:	ff 15 84 ab 2e 00    	call   *0x2eab84(%rip)        # 85fc60 <_DYNAMIC+0x258>
  5750dc:	31 c0                	xor    %eax,%eax
  5750de:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  5750e3:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
  5750e8:	49 89 ef             	mov    %rbp,%r15
  5750eb:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  5750f2:	00 00 
  5750f4:	e9 b3 f9 ff ff       	jmp    574aac <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x57c>
  5750f9:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
  5750fe:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
  575103:	f3 0f 6f 44 24 20    	movdqu 0x20(%rsp),%xmm0
  575109:	66 0f 7f 84 24 90 00 	movdqa %xmm0,0x90(%rsp)
  575110:	00 00 
  575112:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
  575117:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
  57511c:	4c 8b 64 24 38       	mov    0x38(%rsp),%r12
  575121:	4c 8b 6c 24 40       	mov    0x40(%rsp),%r13
  575126:	4c 8b 3c 24          	mov    (%rsp),%r15
  57512a:	49 8b 7f 20          	mov    0x20(%r15),%rdi
  57512e:	f6 07 01             	testb  $0x1,(%rdi)
  575131:	75 17                	jne    57514a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  575133:	48 8b 47 08          	mov    0x8(%rdi),%rax
  575137:	a8 01                	test   $0x1,%al
  575139:	75 0f                	jne    57514a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  57513b:	48 8d 47 08          	lea    0x8(%rdi),%rax
  57513f:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  575144:	0f 84 bc 06 00 00    	je     575806 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12d6>
  57514a:	4d 8b 7f 30          	mov    0x30(%r15),%r15
  57514e:	4d 85 ff             	test   %r15,%r15
  575151:	74 33                	je     575186 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc56>
  575153:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  575157:	f6 07 01             	testb  $0x1,(%rdi)
  57515a:	75 17                	jne    575173 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  57515c:	48 8b 47 08          	mov    0x8(%rdi),%rax
  575160:	a8 01                	test   $0x1,%al
  575162:	75 0f                	jne    575173 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  575164:	48 8d 47 08          	lea    0x8(%rdi),%rax
  575168:	f0 48 83 28 02       	lock subq $0x2,(%rax)
  57516d:	0f 84 a2 06 00 00    	je     575815 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12e5>
  575173:	be 60 00 00 00       	mov    $0x60,%esi
  575178:	ba 08 00 00 00       	mov    $0x8,%edx
  57517d:	4c 89 ff             	mov    %r15,%rdi
  575180:	ff 15 da aa 2e 00    	call   *0x2eaada(%rip)        # 85fc60 <_DYNAMIC+0x258>
  575186:	4d 89 e7             	mov    %r12,%r15
  575189:	49 81 e7 00 ff ff ff 	and    $0xffffffffffffff00,%r15
  575190:	be 38 00 00 00       	mov    $0x38,%esi
  575195:	ba 08 00 00 00       	mov    $0x8,%edx
  57519a:	48 8b 3c 24          	mov    (%rsp),%rdi
  57519e:	ff 15 bc aa 2e 00    	call   *0x2eaabc(%rip)        # 85fc60 <_DYNAMIC+0x258>
  5751a4:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
  5751a9:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  5751ae:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
  5751b3:	66 0f 6f 8c 24 90 00 	movdqa 0x90(%rsp),%xmm1
  5751ba:	00 00 
  5751bc:	e9 f3 f4 ff ff       	jmp    5746b4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x184>
  5751c1:	f3 0f 6f 44 24 18    	movdqu 0x18(%rsp),%xmm0
  5751c7:	f3 0f 6f 4c 24 28    	movdqu 0x28(%rsp),%xmm1
  5751cd:	f3 0f 6f 54 24 38    	movdqu 0x38(%rsp),%xmm2
  5751d3:	f3 0f 7f 94 24 c8 00 	movdqu %xmm2,0xc8(%rsp)
  5751da:	00 00 
  5751dc:	f3 0f 7f 8c 24 b8 00 	movdqu %xmm1,0xb8(%rsp)
  5751e3:	00 00 
  5751e5:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  5751ec:	00 
  5751ed:	f3 0f 7f 84 24 a8 00 	movdqu %xmm0,0xa8(%rsp)
  5751f4:	00 00 
  5751f6:	e9 21 fe ff ff       	jmp    57501c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xaec>
  5751fb:	49 8b b6 a8 02 00 00 	mov    0x2a8(%r14),%rsi
  575202:	48 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%rdi
  575209:	00 
  57520a:	48 39 f7             	cmp    %rsi,%rdi
  57520d:	0f 83 6b 06 00 00    	jae    57587e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x134e>
  575213:	49 8b 86 a0 02 00 00 	mov    0x2a0(%r14),%rax
  57521a:	48 8d 0c 7f          	lea    (%rdi,%rdi,2),%rcx
  57521e:	48 8b 04 c8          	mov    (%rax,%rcx,8),%rax
  575222:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
  575229:	00 
  57522a:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
  57522f:	48 85 f6             	test   %rsi,%rsi
  575232:	0f 85 d1 00 00 00    	jne    575309 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xdd9>
  575238:	f6 45 00 01          	testb  $0x1,0x0(%rbp)
  57523c:	75 2e                	jne    57526c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  57523e:	48 8b 45 08          	mov    0x8(%rbp),%rax
  575242:	a8 01                	test   $0x1,%al
  575244:	75 26                	jne    57526c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  575246:	b8 02 00 00 00       	mov    $0x2,%eax
  57524b:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  575251:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  575258:	00 00 80 
  57525b:	48 ff c1             	inc    %rcx
  57525e:	48 21 c1             	and    %rax,%rcx
  575261:	48 f7 d9             	neg    %rcx
  575264:	71 06                	jno    57526c <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xd3c>
  575266:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  57526c:	48 8b 04 24          	mov    (%rsp),%rax
  575270:	4c 8b 28             	mov    (%rax),%r13
  575273:	ff 15 d7 a9 2e 00    	call   *0x2ea9d7(%rip)        # 85fc50 <_DYNAMIC+0x248>
  575279:	bf 60 00 00 00       	mov    $0x60,%edi
  57527e:	be 08 00 00 00       	mov    $0x8,%esi
  575283:	ff 15 cf a9 2e 00    	call   *0x2ea9cf(%rip)        # 85fc58 <_DYNAMIC+0x250>
  575289:	48 85 c0             	test   %rax,%rax
  57528c:	0f 84 c0 05 00 00    	je     575852 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1322>
  575292:	48 89 c6             	mov    %rax,%rsi
  575295:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  57529a:	48 89 c8             	mov    %rcx,%rax
  57529d:	48 c1 e0 20          	shl    $0x20,%rax
  5752a1:	48 09 c8             	or     %rcx,%rax
  5752a4:	66 0f 6e 84 24 dc 00 	movd   0xdc(%rsp),%xmm0
  5752ab:	00 00 
  5752ad:	66 0f 6e 8c 24 d8 00 	movd   0xd8(%rsp),%xmm1
  5752b4:	00 00 
  5752b6:	66 0f 62 c1          	punpckldq %xmm1,%xmm0
  5752ba:	66 0f 6e 8c 24 e0 00 	movd   0xe0(%rsp),%xmm1
  5752c1:	00 00 
  5752c3:	66 0f 6e 94 24 e4 00 	movd   0xe4(%rsp),%xmm2
  5752ca:	00 00 
  5752cc:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
  5752d0:	66 0f 6c c1          	punpcklqdq %xmm1,%xmm0
  5752d4:	f3 0f 7f 06          	movdqu %xmm0,(%rsi)
  5752d8:	f3 0f 7f 46 10       	movdqu %xmm0,0x10(%rsi)
  5752dd:	f3 0f 7f 46 20       	movdqu %xmm0,0x20(%rsi)
  5752e2:	48 89 6e 30          	mov    %rbp,0x30(%rsi)
  5752e6:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
  5752ed:	00 
  5752ee:	48 89 4e 38          	mov    %rcx,0x38(%rsi)
  5752f2:	4c 89 6e 40          	mov    %r13,0x40(%rsi)
  5752f6:	48 89 46 48          	mov    %rax,0x48(%rsi)
  5752fa:	c7 46 50 00 00 00 00 	movl   $0x0,0x50(%rsi)
  575301:	48 8b 04 24          	mov    (%rsp),%rax
  575305:	48 89 70 30          	mov    %rsi,0x30(%rax)
  575309:	48 83 bc 24 90 00 00 	cmpq   $0x0,0x90(%rsp)
  575310:	00 00 
  575312:	48 89 74 24 70       	mov    %rsi,0x70(%rsp)
  575317:	0f 84 80 00 00 00    	je     57539d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe6d>
  57531d:	48 8b 46 48          	mov    0x48(%rsi),%rax
  575321:	89 c2                	mov    %eax,%edx
  575323:	48 c1 e8 20          	shr    $0x20,%rax
  575327:	48 89 c1             	mov    %rax,%rcx
  57532a:	48 29 d1             	sub    %rdx,%rcx
  57532d:	0f 85 cc 00 00 00    	jne    5753ff <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xecf>
  575333:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  575337:	48 d1 ee             	shr    $1,%rsi
  57533a:	4c 8d 05 cf 29 2d 00 	lea    0x2d29cf(%rip),%r8        # 847d10 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa40>
  575341:	48 39 74 24 78       	cmp    %rsi,0x78(%rsp)
  575346:	0f 87 d8 04 00 00    	ja     575824 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  57534c:	48 39 74 24 60       	cmp    %rsi,0x60(%rsp)
  575351:	74 35                	je     575388 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe58>
  575353:	48 83 7c 24 60 00    	cmpq   $0x0,0x60(%rsp)
  575359:	74 13                	je     57536e <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe3e>
  57535b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575360:	48 8d 4d 10          	lea    0x10(%rbp),%rcx
  575364:	80 3c 01 bf          	cmpb   $0xbf,(%rcx,%rax,1)
  575368:	0f 8e b6 04 00 00    	jle    575824 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  57536e:	48 39 74 24 78       	cmp    %rsi,0x78(%rsp)
  575373:	74 13                	je     575388 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe58>
  575375:	48 8d 45 10          	lea    0x10(%rbp),%rax
  575379:	48 8b 4c 24 78       	mov    0x78(%rsp),%rcx
  57537e:	80 3c 08 bf          	cmpb   $0xbf,(%rax,%rcx,1)
  575382:	0f 8e 9c 04 00 00    	jle    575824 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x12f4>
  575388:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  57538d:	48 8d 4d 10          	lea    0x10(%rbp),%rcx
  575391:	48 8d 3c 01          	lea    (%rcx,%rax,1),%rdi
  575395:	4c 89 f9             	mov    %r15,%rcx
  575398:	e9 ae 00 00 00       	jmp    57544b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf1b>
  57539d:	48 8b 4e 30          	mov    0x30(%rsi),%rcx
  5753a1:	48 8b 45 00          	mov    0x0(%rbp),%rax
  5753a5:	48 39 e9             	cmp    %rbp,%rcx
  5753a8:	75 10                	jne    5753ba <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xe8a>
  5753aa:	48 8b 09             	mov    (%rcx),%rcx
  5753ad:	48 31 c1             	xor    %rax,%rcx
  5753b0:	48 83 f9 01          	cmp    $0x1,%rcx
  5753b4:	0f 86 e7 00 00 00    	jbe    5754a1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf71>
  5753ba:	a8 01                	test   $0x1,%al
  5753bc:	75 2e                	jne    5753ec <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  5753be:	48 8b 45 08          	mov    0x8(%rbp),%rax
  5753c2:	a8 01                	test   $0x1,%al
  5753c4:	75 26                	jne    5753ec <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  5753c6:	b8 02 00 00 00       	mov    $0x2,%eax
  5753cb:	f0 48 0f c1 45 08    	lock xadd %rax,0x8(%rbp)
  5753d1:	48 b9 00 00 00 00 00 	movabs $0x8000000000000000,%rcx
  5753d8:	00 00 80 
  5753db:	48 ff c1             	inc    %rcx
  5753de:	48 21 c1             	and    %rax,%rcx
  5753e1:	48 f7 d9             	neg    %rcx
  5753e4:	71 06                	jno    5753ec <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xebc>
  5753e6:	f0 48 83 4d 08 01    	lock orq $0x1,0x8(%rbp)
  5753ec:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  5753f1:	48 8b 78 30          	mov    0x30(%rax),%rdi
  5753f5:	e8 b6 93 ff ff       	call   56e7b0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  5753fa:	e9 9c 01 00 00       	jmp    57559b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x106b>
  5753ff:	48 8b 7e 30          	mov    0x30(%rsi),%rdi
  575403:	48 8b 37             	mov    (%rdi),%rsi
  575406:	48 d1 ee             	shr    $1,%rsi
  575409:	48 83 c7 10          	add    $0x10,%rdi
  57540d:	4c 8d 05 e4 28 2d 00 	lea    0x2d28e4(%rip),%r8        # 847cf8 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa28>
  575414:	39 d0                	cmp    %edx,%eax
  575416:	0f 82 14 04 00 00    	jb     575830 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  57541c:	48 39 f0             	cmp    %rsi,%rax
  57541f:	0f 87 0b 04 00 00    	ja     575830 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  575425:	48 39 f2             	cmp    %rsi,%rdx
  575428:	74 1e                	je     575448 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf18>
  57542a:	48 85 d2             	test   %rdx,%rdx
  57542d:	74 0a                	je     575439 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf09>
  57542f:	80 3c 17 bf          	cmpb   $0xbf,(%rdi,%rdx,1)
  575433:	0f 8e f7 03 00 00    	jle    575830 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  575439:	48 39 f0             	cmp    %rsi,%rax
  57543c:	74 0a                	je     575448 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf18>
  57543e:	80 3c 07 bf          	cmpb   $0xbf,(%rdi,%rax,1)
  575442:	0f 8e e8 03 00 00    	jle    575830 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1300>
  575448:	48 01 d7             	add    %rdx,%rdi
  57544b:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
  575452:	00 
  575453:	48 39 ca             	cmp    %rcx,%rdx
  575456:	75 12                	jne    57546a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf3a>
  575458:	48 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%rsi
  57545f:	00 
  575460:	ff 15 82 a8 2e 00    	call   *0x2ea882(%rip)        # 85fce8 <bcmp@GLIBC_2.2.5>
  575466:	85 c0                	test   %eax,%eax
  575468:	74 37                	je     5754a1 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf71>
  57546a:	48 8b 75 00          	mov    0x0(%rbp),%rsi
  57546e:	48 d1 ee             	shr    $1,%rsi
  575471:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575476:	48 85 c0             	test   %rax,%rax
  575479:	74 68                	je     5754e3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfb3>
  57547b:	48 39 f0             	cmp    %rsi,%rax
  57547e:	73 5c                	jae    5754dc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfac>
  575480:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575485:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  57548c:	00 
  57548d:	80 3c 01 c0          	cmpb   $0xc0,(%rcx,%rax,1)
  575491:	7d 50                	jge    5754e3 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfb3>
  575493:	4c 8d 05 8e 28 2d 00 	lea    0x2d288e(%rip),%r8        # 847d28 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa58>
  57549a:	31 d2                	xor    %edx,%edx
  57549c:	e9 9c 03 00 00       	jmp    57583d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x130d>
  5754a1:	45 31 ff             	xor    %r15d,%r15d
  5754a4:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  5754a9:	48 01 8c 24 90 00 00 	add    %rcx,0x90(%rsp)
  5754b0:	00 
  5754b1:	41 f6 c4 01          	test   $0x1,%r12b
  5754b5:	0f 85 03 01 00 00    	jne    5755be <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x108e>
  5754bb:	45 31 ed             	xor    %r13d,%r13d
  5754be:	e9 19 01 00 00       	jmp    5755dc <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x10ac>
  5754c3:	48 8d 3d 66 13 ad ff 	lea    -0x52ec9a(%rip),%rdi        # 46830 <anon.72786b07d16308d9adbd85e9b0d1bfa8.348.llvm.9246593494314379644+0x2d50>
  5754ca:	48 8d 15 87 28 2d 00 	lea    0x2d2887(%rip),%rdx        # 847d58 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa88>
  5754d1:	be 17 00 00 00       	mov    $0x17,%esi
  5754d6:	ff 15 f4 a8 2e 00    	call   *0x2ea8f4(%rip)        # 85fdd0 <_DYNAMIC+0x3c8>
  5754dc:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  5754e1:	75 b0                	jne    575493 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf63>
  5754e3:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  5754e8:	48 85 d2             	test   %rdx,%rdx
  5754eb:	74 3a                	je     575527 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xff7>
  5754ed:	48 39 d6             	cmp    %rdx,%rsi
  5754f0:	76 29                	jbe    57551b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfeb>
  5754f2:	48 8b 84 24 80 00 00 	mov    0x80(%rsp),%rax
  5754f9:	00 
  5754fa:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  5754ff:	80 3c 10 c0          	cmpb   $0xc0,(%rax,%rdx,1)
  575503:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575508:	7d 1d                	jge    575527 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xff7>
  57550a:	4c 8d 05 2f 28 2d 00 	lea    0x2d282f(%rip),%r8        # 847d40 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa70>
  575511:	48 89 74 24 60       	mov    %rsi,0x60(%rsp)
  575516:	e9 22 03 00 00       	jmp    57583d <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x130d>
  57551b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
  575520:	48 8b 54 24 78       	mov    0x78(%rsp),%rdx
  575525:	75 e3                	jne    57550a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xfda>
  575527:	48 29 d6             	sub    %rdx,%rsi
  57552a:	48 8b 8c 24 80 00 00 	mov    0x80(%rsp),%rcx
  575531:	00 
  575532:	48 01 ca             	add    %rcx,%rdx
  575535:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
  57553a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  57553f:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
  575546:	00 
  575547:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
  57554c:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
  575553:	00 
  575554:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
  575559:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
  57555e:	48 89 74 24 38       	mov    %rsi,0x38(%rsp)
  575563:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  575568:	ff 15 ca a8 2e 00    	call   *0x2ea8ca(%rip)        # 85fe38 <_DYNAMIC+0x430>
  57556e:	48 89 c5             	mov    %rax,%rbp
  575571:	48 c7 44 24 10 20 00 	movq   $0x20,0x10(%rsp)
  575578:	00 00 
  57557a:	48 85 c0             	test   %rax,%rax
  57557d:	0f 84 71 fa ff ff    	je     574ff4 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xac4>
  575583:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  575588:	e8 e3 93 ff ff       	call   56e970 <core::ptr::drop_glue::<gpui::runtime::Error>>
  57558d:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  575592:	48 8b 78 30          	mov    0x30(%rax),%rdi
  575596:	e8 15 92 ff ff       	call   56e7b0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  57559b:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  5755a0:	48 89 68 30          	mov    %rbp,0x30(%rax)
  5755a4:	41 b7 01             	mov    $0x1,%r15b
  5755a7:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  5755ac:	48 01 8c 24 90 00 00 	add    %rcx,0x90(%rsp)
  5755b3:	00 
  5755b4:	41 f6 c4 01          	test   $0x1,%r12b
  5755b8:	0f 84 fd fe ff ff    	je     5754bb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xf8b>
  5755be:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
  5755c3:	44 8b 60 08          	mov    0x8(%rax),%r12d
  5755c7:	41 01 cc             	add    %ecx,%r12d
  5755ca:	8b 40 10             	mov    0x10(%rax),%eax
  5755cd:	01 c8                	add    %ecx,%eax
  5755cf:	48 c1 e0 20          	shl    $0x20,%rax
  5755d3:	49 09 c4             	or     %rax,%r12
  5755d6:	41 bd 01 00 00 00    	mov    $0x1,%r13d
  5755dc:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  5755e1:	48 8b 70 30          	mov    0x30(%rax),%rsi
  5755e5:	48 8b 16             	mov    (%rsi),%rdx
  5755e8:	48 d1 ea             	shr    $1,%rdx
  5755eb:	48 83 c6 10          	add    $0x10,%rsi
  5755ef:	44 89 ac 24 10 01 00 	mov    %r13d,0x110(%rsp)
  5755f6:	00 
  5755f7:	4c 89 a4 24 14 01 00 	mov    %r12,0x114(%rsp)
  5755fe:	00 
  5755ff:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  575604:	4c 8d 8c 24 10 01 00 	lea    0x110(%rsp),%r9
  57560b:	00 
  57560c:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
  575613:	00 
  575614:	ff 15 26 a8 2e 00    	call   *0x2ea826(%rip)        # 85fe40 <_DYNAMIC+0x438>
  57561a:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  57561f:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
  575624:	0f 29 84 24 40 01 00 	movaps %xmm0,0x140(%rsp)
  57562b:	00 
  57562c:	0f 10 44 24 28       	movups 0x28(%rsp),%xmm0
  575631:	0f 29 84 24 50 01 00 	movaps %xmm0,0x150(%rsp)
  575638:	00 
  575639:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  57563d:	0f 85 f5 00 00 00    	jne    575738 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1208>
  575643:	0f 28 84 24 40 01 00 	movaps 0x140(%rsp),%xmm0
  57564a:	00 
  57564b:	66 0f 6f 8c 24 50 01 	movdqa 0x150(%rsp),%xmm1
  575652:	00 00 
  575654:	0f 29 84 24 60 01 00 	movaps %xmm0,0x160(%rsp)
  57565b:	00 
  57565c:	66 0f 7f 8c 24 10 01 	movdqa %xmm1,0x110(%rsp)
  575663:	00 00 
  575665:	48 8b 54 24 70       	mov    0x70(%rsp),%rdx
  57566a:	0f 11 42 10          	movups %xmm0,0x10(%rdx)
  57566e:	66 0f 6f 84 24 10 01 	movdqa 0x110(%rsp),%xmm0
  575675:	00 00 
  575677:	f3 0f 7f 42 20       	movdqu %xmm0,0x20(%rdx)
  57567c:	48 8b 04 24          	mov    (%rsp),%rax
  575680:	48 8b 00             	mov    (%rax),%rax
  575683:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
  57568a:	00 
  57568b:	48 c1 e1 20          	shl    $0x20,%rcx
  57568f:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
  575694:	48 09 f1             	or     %rsi,%rcx
  575697:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
  57569e:	00 
  57569f:	48 89 7a 38          	mov    %rdi,0x38(%rdx)
  5756a3:	48 89 42 40          	mov    %rax,0x40(%rdx)
  5756a7:	48 89 4a 48          	mov    %rcx,0x48(%rdx)
  5756ab:	44 89 6a 50          	mov    %r13d,0x50(%rdx)
  5756af:	4c 89 62 54          	mov    %r12,0x54(%rdx)
  5756b3:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  5756b8:	ff 15 4a a7 2e 00    	call   *0x2ea74a(%rip)        # 85fe08 <_DYNAMIC+0x400>
  5756be:	48 8b 6c 24 10       	mov    0x10(%rsp),%rbp
  5756c3:	8b 4c 24 18          	mov    0x18(%rsp),%ecx
  5756c7:	0f b6 44 24 1c       	movzbl 0x1c(%rsp),%eax
  5756cc:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5756d0:	0f 85 a0 00 00 00    	jne    575776 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1246>
  5756d6:	89 4c 24 10          	mov    %ecx,0x10(%rsp)
  5756da:	88 44 24 14          	mov    %al,0x14(%rsp)
  5756de:	89 4c 24 18          	mov    %ecx,0x18(%rsp)
  5756e2:	88 44 24 1c          	mov    %al,0x1c(%rsp)
  5756e6:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
  5756eb:	4c 89 f7             	mov    %r14,%rdi
  5756ee:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
  5756f5:	00 
  5756f6:	e8 a5 c7 ff ff       	call   571ea0 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::set_selection>
  5756fb:	45 84 ff             	test   %r15b,%r15b
  5756fe:	74 18                	je     575718 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x11e8>
  575700:	4c 89 f7             	mov    %r14,%rdi
  575703:	48 8b b4 24 00 01 00 	mov    0x100(%rsp),%rsi
  57570a:	00 
  57570b:	48 8b 94 24 08 01 00 	mov    0x108(%rsp),%rdx
  575712:	00 
  575713:	e8 28 db ff ff       	call   573240 <<gpui::runtime::Runtime<ime_cursor_cost::Input>>::invalidate_display>
  575718:	41 c6 86 2b 07 00 00 	movb   $0x1,0x72b(%r14)
  57571f:	01 
  575720:	48 c7 84 24 a0 00 00 	movq   $0xfffffffffffffffe,0xa0(%rsp)
  575727:	00 fe ff ff ff 
  57572c:	48 c7 c5 fe ff ff ff 	mov    $0xfffffffffffffffe,%rbp
  575733:	e9 e0 f8 ff ff       	jmp    575018 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  575738:	0f 10 44 24 38       	movups 0x38(%rsp),%xmm0
  57573d:	0f 11 84 24 c8 00 00 	movups %xmm0,0xc8(%rsp)
  575744:	00 
  575745:	66 0f 6f 84 24 40 01 	movdqa 0x140(%rsp),%xmm0
  57574c:	00 00 
  57574e:	66 0f 6f 8c 24 50 01 	movdqa 0x150(%rsp),%xmm1
  575755:	00 00 
  575757:	f3 0f 7f 84 24 a8 00 	movdqu %xmm0,0xa8(%rsp)
  57575e:	00 00 
  575760:	f3 0f 7f 8c 24 b8 00 	movdqu %xmm1,0xb8(%rsp)
  575767:	00 00 
  575769:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  575770:	00 
  575771:	e9 a2 f8 ff ff       	jmp    575018 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  575776:	f3 0f 6f 44 24 1d    	movdqu 0x1d(%rsp),%xmm0
  57577c:	f3 0f 6f 4c 24 2d    	movdqu 0x2d(%rsp),%xmm1
  575782:	f3 0f 6f 54 24 38    	movdqu 0x38(%rsp),%xmm2
  575788:	f3 0f 7f 94 24 c8 00 	movdqu %xmm2,0xc8(%rsp)
  57578f:	00 00 
  575791:	f3 0f 7f 8c 24 bd 00 	movdqu %xmm1,0xbd(%rsp)
  575798:	00 00 
  57579a:	f3 0f 7f 84 24 ad 00 	movdqu %xmm0,0xad(%rsp)
  5757a1:	00 00 
  5757a3:	48 89 ac 24 a0 00 00 	mov    %rbp,0xa0(%rsp)
  5757aa:	00 
  5757ab:	89 8c 24 a8 00 00 00 	mov    %ecx,0xa8(%rsp)
  5757b2:	88 84 24 ac 00 00 00 	mov    %al,0xac(%rsp)
  5757b9:	e9 5a f8 ff ff       	jmp    575018 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xae8>
  5757be:	48 8d 3d fb 1d 2d 00 	lea    0x2d1dfb(%rip),%rdi        # 8475c0 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x2f0>
  5757c5:	ff 15 bd a4 2e 00    	call   *0x2ea4bd(%rip)        # 85fc88 <_DYNAMIC+0x280>
  5757cb:	48 8d 3d 76 23 2d 00 	lea    0x2d2376(%rip),%rdi        # 847b48 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x878>
  5757d2:	ff 15 b0 a4 2e 00    	call   *0x2ea4b0(%rip)        # 85fc88 <_DYNAMIC+0x280>
  5757d8:	bf 08 00 00 00       	mov    $0x8,%edi
  5757dd:	be 38 00 00 00       	mov    $0x38,%esi
  5757e2:	ff 15 90 a4 2e 00    	call   *0x2ea490(%rip)        # 85fc78 <_DYNAMIC+0x270>
  5757e8:	e9 9e 00 00 00       	jmp    57588b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  5757ed:	48 8d 3d e0 10 ad ff 	lea    -0x52ef20(%rip),%rdi        # 468d4 <anon.72786b07d16308d9adbd85e9b0d1bfa8.348.llvm.9246593494314379644+0x2df4>
  5757f4:	48 8d 15 05 26 2d 00 	lea    0x2d2605(%rip),%rdx        # 847e00 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xb30>
  5757fb:	be 83 00 00 00       	mov    $0x83,%esi
  575800:	ff 15 9a a4 2e 00    	call   *0x2ea49a(%rip)        # 85fca0 <_DYNAMIC+0x298>
  575806:	48 8b 47 08          	mov    0x8(%rdi),%rax
  57580a:	ff 15 a8 a4 2e 00    	call   *0x2ea4a8(%rip)        # 85fcb8 <_DYNAMIC+0x2b0>
  575810:	e9 35 f9 ff ff       	jmp    57514a <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc1a>
  575815:	48 8b 47 08          	mov    0x8(%rdi),%rax
  575819:	ff 15 99 a4 2e 00    	call   *0x2ea499(%rip)        # 85fcb8 <_DYNAMIC+0x2b0>
  57581f:	e9 4f f9 ff ff       	jmp    575173 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0xc43>
  575824:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
  575829:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
  57582e:	eb 08                	jmp    575838 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x1308>
  575830:	48 89 bc 24 80 00 00 	mov    %rdi,0x80(%rsp)
  575837:	00 
  575838:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  57583d:	48 8b bc 24 80 00 00 	mov    0x80(%rsp),%rdi
  575844:	00 
  575845:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
  57584a:	ff 15 f8 a5 2e 00    	call   *0x2ea5f8(%rip)        # 85fe48 <_DYNAMIC+0x440>
  575850:	eb 39                	jmp    57588b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  575852:	bf 08 00 00 00       	mov    $0x8,%edi
  575857:	be 60 00 00 00       	mov    $0x60,%esi
  57585c:	ff 15 16 a4 2e 00    	call   *0x2ea416(%rip)        # 85fc78 <_DYNAMIC+0x270>
  575862:	eb 27                	jmp    57588b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x135b>
  575864:	48 8d 15 ad 22 2d 00 	lea    0x2d22ad(%rip),%rdx        # 847b18 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x848>
  57586b:	ff 15 3f a5 2e 00    	call   *0x2ea53f(%rip)        # 85fdb0 <_DYNAMIC+0x3a8>
  575871:	48 8d 15 30 1d 2d 00 	lea    0x2d1d30(%rip),%rdx        # 8475a8 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0x2d8>
  575878:	ff 15 32 a5 2e 00    	call   *0x2ea532(%rip)        # 85fdb0 <_DYNAMIC+0x3a8>
  57587e:	48 8d 15 5b 24 2d 00 	lea    0x2d245b(%rip),%rdx        # 847ce0 <anon.ae0671d4caff78773914e075212a1ccb.17.llvm.11041048271037086772+0xa10>
  575885:	ff 15 25 a5 2e 00    	call   *0x2ea525(%rip)        # 85fdb0 <_DYNAMIC+0x3a8>
  57588b:	0f 0b                	ud2
  57588d:	48 89 c3             	mov    %rax,%rbx
  575890:	be 60 00 00 00       	mov    $0x60,%esi
  575895:	ba 08 00 00 00       	mov    $0x8,%edx
  57589a:	4c 89 ff             	mov    %r15,%rdi
  57589d:	ff 15 bd a3 2e 00    	call   *0x2ea3bd(%rip)        # 85fc60 <_DYNAMIC+0x258>
  5758a3:	e9 93 00 00 00       	jmp    57593b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  5758a8:	48 89 c3             	mov    %rax,%rbx
  5758ab:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  5758af:	e8 bc 55 ff ff       	call   56ae70 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  5758b4:	e9 82 00 00 00       	jmp    57593b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  5758b9:	eb 00                	jmp    5758bb <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x138b>
  5758bb:	48 89 c3             	mov    %rax,%rbx
  5758be:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
  5758c3:	48 89 68 30          	mov    %rbp,0x30(%rax)
  5758c7:	eb 58                	jmp    575921 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  5758c9:	48 89 c3             	mov    %rax,%rbx
  5758cc:	eb 6d                	jmp    57593b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  5758ce:	48 89 c3             	mov    %rax,%rbx
  5758d1:	49 8b 7f 30          	mov    0x30(%r15),%rdi
  5758d5:	e8 96 55 ff ff       	call   56ae70 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  5758da:	eb 5f                	jmp    57593b <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x140b>
  5758dc:	48 89 c3             	mov    %rax,%rbx
  5758df:	48 c7 45 30 00 00 00 	movq   $0x0,0x30(%rbp)
  5758e6:	00 
  5758e7:	eb 38                	jmp    575921 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  5758e9:	48 89 c3             	mov    %rax,%rbx
  5758ec:	48 83 fd fe          	cmp    $0xfffffffffffffffe,%rbp
  5758f0:	0f 84 89 00 00 00    	je     57597f <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x144f>
  5758f6:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
  5758fd:	00 
  5758fe:	e8 6d 90 ff ff       	call   56e970 <core::ptr::drop_glue::<gpui::runtime::Error>>
  575903:	48 89 df             	mov    %rbx,%rdi
  575906:	e8 25 05 2d 00       	call   845e30 <_Unwind_Resume@plt>
  57590b:	48 89 c3             	mov    %rax,%rbx
  57590e:	48 89 ef             	mov    %rbp,%rdi
  575911:	e8 ba 62 ff ff       	call   56bbd0 <core::ptr::drop_glue::<core::option::Option<gpui::runtime::editing::LogicalSelection>>>
  575916:	eb 09                	jmp    575921 <<gpui::runtime::Win<ime_cursor_cost::Input>>::ime_event+0x13f1>
  575918:	ff 15 7a a3 2e 00    	call   *0x2ea37a(%rip)        # 85fc98 <_DYNAMIC+0x290>
  57591e:	48 89 c3             	mov    %rax,%rbx
  575921:	48 8b 04 24          	mov    (%rsp),%rax
  575925:	48 8b 78 20          	mov    0x20(%rax),%rdi
  575929:	e8 82 8e ff ff       	call   56e7b0 <core::ptr::drop_glue::<gpui::shared_text::SharedText>>
  57592e:	48 8b 04 24          	mov    (%rsp),%rax
  575932:	48 8b 78 30          	mov    0x30(%rax),%rdi
  575936:	e8 35 55 ff ff       	call   56ae70 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui::runtime::ime::Preview>>>>
  57593b:	be 38 00 00 00       	mov    $0x38,%esi
  575940:	ba 08 00 00 00       	mov    $0x8,%edx
  575945:	48 8b 3c 24          	mov    (%rsp),%rdi
  575949:	ff 15 11 a3 2e 00    	call   *0x2ea311(%rip)        # 85fc60 <_DYNAMIC+0x258>
  57594f:	48 89 df             	mov    %rbx,%rdi
  575952:	e8 d9 04 2d 00       	call   845e30 <_Unwind_Resume@plt>
  575957:	ff 15 3b a3 2e 00    	call   *0x2ea33b(%rip)        # 85fc98 <_DYNAMIC+0x290>
  57595d:	48 89 c3             	mov    %rax,%rbx
  575960:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
  575965:	e8 06 90 ff ff       	call   56e970 <core::ptr::drop_glue::<gpui::runtime::Error>>
  57596a:	48 89 df             	mov    %rbx,%rdi
  57596d:	e8 be 04 2d 00       	call   845e30 <_Unwind_Resume@plt>
  575972:	48 89 c3             	mov    %rax,%rbx
  575975:	48 89 ef             	mov    %rbp,%rdi
  575978:	31 f6                	xor    %esi,%esi
  57597a:	e8 31 a1 ff ff       	call   56fab0 <core::ptr::drop_glue::<gpui::runtime::ime::Active>>
  57597f:	48 89 df             	mov    %rbx,%rdi
  575982:	e8 a9 04 2d 00       	call   845e30 <_Unwind_Resume@plt>
  575987:	ff 15 0b a3 2e 00    	call   *0x2ea30b(%rip)        # 85fc98 <_DYNAMIC+0x290>
