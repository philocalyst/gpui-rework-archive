
/tmp/gpui-ime-ascii-control-executable-root/ime_cursor_cost:     file format elf64-x86-64


Disassembly of section .text:

00000000005d6d90 <gpui::runtime::ime::preview_selections>:
  5d6d90:	55                   	push   %rbp
  5d6d91:	41 57                	push   %r15
  5d6d93:	41 56                	push   %r14
  5d6d95:	41 55                	push   %r13
  5d6d97:	41 54                	push   %r12
  5d6d99:	53                   	push   %rbx
  5d6d9a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
  5d6da1:	4c 89 44 24 18       	mov    %r8,0x18(%rsp)
  5d6da6:	49 89 cc             	mov    %rcx,%r12
  5d6da9:	48 89 3c 24          	mov    %rdi,(%rsp)
  5d6dad:	49 8b 41 04          	mov    0x4(%r9),%rax
  5d6db1:	49 89 c6             	mov    %rax,%r14
  5d6db4:	49 c1 ee 20          	shr    $0x20,%r14
  5d6db8:	41 80 39 00          	cmpb   $0x0,(%r9)
  5d6dbc:	4c 0f 44 f1          	cmove  %rcx,%r14
  5d6dc0:	41 89 c5             	mov    %eax,%r13d
  5d6dc3:	4c 0f 44 e9          	cmove  %rcx,%r13
  5d6dc7:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  5d6dce:	00 00 
  5d6dd0:	48 c7 44 24 28 08 00 	movq   $0x8,0x28(%rsp)
  5d6dd7:	00 00 
  5d6dd9:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
  5d6de0:	00 00 
  5d6de2:	c7 44 24 40 ff ff ff 	movl   $0xffffffff,0x40(%rsp)
  5d6de9:	ff 
  5d6dea:	48 89 74 24 48       	mov    %rsi,0x48(%rsp)
  5d6def:	48 01 d6             	add    %rdx,%rsi
  5d6df2:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
  5d6df7:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
  5d6dfe:	00 00 
  5d6e00:	48 8d 05 59 0a 27 00 	lea    0x270a59(%rip),%rax        # 847860 <anon.5223b83a52d5df3c567aefc3cf4b02da.47.llvm.3662758644422267572+0x158>
  5d6e07:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
  5d6e0c:	48 8d 05 bd eb ff ff 	lea    -0x1443(%rip),%rax        # 5d59d0 <icu_segmenter::rule_segmenter_v1::empty_handle_complex::<icu_segmenter::scaffold::Utf8>>
  5d6e13:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
  5d6e18:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
  5d6e1d:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
  5d6e22:	48 c7 44 24 78 00 00 	movq   $0x0,0x78(%rsp)
  5d6e29:	00 00 
  5d6e2b:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
  5d6e32:	00 00 00 00 00 
  5d6e37:	c6 84 24 b0 00 00 00 	movb   $0x0,0xb0(%rsp)
  5d6e3e:	00 
  5d6e3f:	31 db                	xor    %ebx,%ebx
  5d6e41:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
  5d6e48:	00 00 
  5d6e4a:	45 31 ff             	xor    %r15d,%r15d
  5d6e4d:	31 ed                	xor    %ebp,%ebp
  5d6e4f:	eb 20                	jmp    5d6e71 <gpui::runtime::ime::preview_selections+0xe1>
  5d6e51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  5d6e58:	0f 1f 84 00 00 00 00 
  5d6e5f:	00 
  5d6e60:	4c 39 e2             	cmp    %r12,%rdx
  5d6e63:	48 0f 46 ea          	cmovbe %rdx,%rbp
  5d6e67:	49 89 d7             	mov    %rdx,%r15
  5d6e6a:	48 3b 54 24 18       	cmp    0x18(%rsp),%rdx
  5d6e6f:	73 7e                	jae    5d6eef <gpui::runtime::ime::preview_selections+0x15f>
  5d6e71:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
  5d6e76:	e8 05 f2 fe ff       	call   5c6080 <<icu_segmenter::rule_segmenter_v1::RuleBreakIterator<icu_segmenter::scaffold::Utf8> as core::iter::traits::iterator::Iterator>::next>
  5d6e7b:	48 83 f8 01          	cmp    $0x1,%rax
  5d6e7f:	75 69                	jne    5d6eea <gpui::runtime::ime::preview_selections+0x15a>
  5d6e81:	4c 89 e8             	mov    %r13,%rax
  5d6e84:	4c 29 f8             	sub    %r15,%rax
  5d6e87:	0f 93 c1             	setae  %cl
  5d6e8a:	4c 39 ea             	cmp    %r13,%rdx
  5d6e8d:	40 0f 93 c6          	setae  %sil
  5d6e91:	40 84 f1             	test   %sil,%cl
  5d6e94:	74 1a                	je     5d6eb0 <gpui::runtime::ime::preview_selections+0x120>
  5d6e96:	4c 89 e9             	mov    %r13,%rcx
  5d6e99:	48 29 d1             	sub    %rdx,%rcx
  5d6e9c:	48 89 d6             	mov    %rdx,%rsi
  5d6e9f:	4c 29 ee             	sub    %r13,%rsi
  5d6ea2:	48 0f 42 f1          	cmovb  %rcx,%rsi
  5d6ea6:	48 39 f0             	cmp    %rsi,%rax
  5d6ea9:	48 89 d3             	mov    %rdx,%rbx
  5d6eac:	49 0f 42 df          	cmovb  %r15,%rbx
  5d6eb0:	4c 89 f0             	mov    %r14,%rax
  5d6eb3:	4c 29 f8             	sub    %r15,%rax
  5d6eb6:	0f 93 c1             	setae  %cl
  5d6eb9:	4c 39 f2             	cmp    %r14,%rdx
  5d6ebc:	40 0f 93 c6          	setae  %sil
  5d6ec0:	40 20 ce             	and    %cl,%sil
  5d6ec3:	40 80 fe 01          	cmp    $0x1,%sil
  5d6ec7:	75 97                	jne    5d6e60 <gpui::runtime::ime::preview_selections+0xd0>
  5d6ec9:	4c 89 f1             	mov    %r14,%rcx
  5d6ecc:	48 29 d1             	sub    %rdx,%rcx
  5d6ecf:	48 89 d6             	mov    %rdx,%rsi
  5d6ed2:	4c 29 f6             	sub    %r14,%rsi
  5d6ed5:	48 0f 42 f1          	cmovb  %rcx,%rsi
  5d6ed9:	48 39 f0             	cmp    %rsi,%rax
  5d6edc:	4c 0f 43 fa          	cmovae %rdx,%r15
  5d6ee0:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
  5d6ee5:	e9 76 ff ff ff       	jmp    5d6e60 <gpui::runtime::ime::preview_selections+0xd0>
  5d6eea:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
  5d6eef:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  5d6ef4:	48 85 f6             	test   %rsi,%rsi
  5d6ef7:	74 1a                	je     5d6f13 <gpui::runtime::ime::preview_selections+0x183>
  5d6ef9:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  5d6efe:	48 c1 e6 03          	shl    $0x3,%rsi
  5d6f02:	49 89 d6             	mov    %rdx,%r14
  5d6f05:	ba 08 00 00 00       	mov    $0x8,%edx
  5d6f0a:	ff 15 c0 61 28 00    	call   *0x2861c0(%rip)        # 85d0d0 <_DYNAMIC+0x258>
  5d6f10:	4c 89 f2             	mov    %r14,%rdx
  5d6f13:	48 89 d8             	mov    %rbx,%rax
  5d6f16:	48 c1 e8 20          	shr    $0x20,%rax
  5d6f1a:	75 20                	jne    5d6f3c <gpui::runtime::ime::preview_selections+0x1ac>
  5d6f1c:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
  5d6f21:	48 89 c8             	mov    %rcx,%rax
  5d6f24:	48 c1 e8 20          	shr    $0x20,%rax
  5d6f28:	75 12                	jne    5d6f3c <gpui::runtime::ime::preview_selections+0x1ac>
  5d6f2a:	48 89 e8             	mov    %rbp,%rax
  5d6f2d:	48 c1 e8 20          	shr    $0x20,%rax
  5d6f31:	75 09                	jne    5d6f3c <gpui::runtime::ime::preview_selections+0x1ac>
  5d6f33:	48 89 d0             	mov    %rdx,%rax
  5d6f36:	48 c1 e8 20          	shr    $0x20,%rax
  5d6f3a:	74 21                	je     5d6f5d <gpui::runtime::ime::preview_selections+0x1cd>
  5d6f3c:	48 8b 04 24          	mov    (%rsp),%rax
  5d6f40:	48 c7 00 20 00 00 00 	movq   $0x20,(%rax)
  5d6f47:	c6 40 0c 01          	movb   $0x1,0xc(%rax)
  5d6f4b:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
  5d6f52:	5b                   	pop    %rbx
  5d6f53:	41 5c                	pop    %r12
  5d6f55:	41 5d                	pop    %r13
  5d6f57:	41 5e                	pop    %r14
  5d6f59:	41 5f                	pop    %r15
  5d6f5b:	5d                   	pop    %rbp
  5d6f5c:	c3                   	ret
  5d6f5d:	48 8b 04 24          	mov    (%rsp),%rax
  5d6f61:	89 58 08             	mov    %ebx,0x8(%rax)
  5d6f64:	c6 40 0c 01          	movb   $0x1,0xc(%rax)
  5d6f68:	89 48 10             	mov    %ecx,0x10(%rax)
  5d6f6b:	c6 40 14 01          	movb   $0x1,0x14(%rax)
  5d6f6f:	89 68 18             	mov    %ebp,0x18(%rax)
  5d6f72:	c6 40 1c 01          	movb   $0x1,0x1c(%rax)
  5d6f76:	89 50 20             	mov    %edx,0x20(%rax)
  5d6f79:	c6 40 24 01          	movb   $0x1,0x24(%rax)
  5d6f7d:	48 c7 00 fe ff ff ff 	movq   $0xfffffffffffffffe,(%rax)
  5d6f84:	eb c5                	jmp    5d6f4b <gpui::runtime::ime::preview_selections+0x1bb>
  5d6f86:	48 89 c3             	mov    %rax,%rbx
  5d6f89:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
  5d6f8e:	48 85 f6             	test   %rsi,%rsi
  5d6f91:	74 14                	je     5d6fa7 <gpui::runtime::ime::preview_selections+0x217>
  5d6f93:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  5d6f98:	48 c1 e6 03          	shl    $0x3,%rsi
  5d6f9c:	ba 08 00 00 00       	mov    $0x8,%edx
  5d6fa1:	ff 15 29 61 28 00    	call   *0x286129(%rip)        # 85d0d0 <_DYNAMIC+0x258>
  5d6fa7:	48 89 df             	mov    %rbx,%rdi
  5d6faa:	e8 c1 c3 26 00       	call   843370 <_Unwind_Resume@plt>
