from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/root/gpui-ce3')
git = ['git', '-c', f'safe.directory={root}', '-C', str(root)]
pin = 'fb8b775315642eef8c9415b5e35185248f19c27c'
base = '5222d7cfb790ecee1a74e8fef297ed6afb9f04d2'
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == '0e97be59c5a033f7ca146a45ab739477261ad900'
assert not subprocess.check_output(git + ['status', '--porcelain'], text=True).strip()
for path in ['/tmp/gpui-ime-ascii-relative-build-root', '/tmp/gpui-ime-ascii-relative-release-build-root', '/tmp/gpui-ime-ascii-relative-strict-root', '/tmp/gpui-ime-ascii-relative-execute-root']:
    result = json.loads((Path(path) / 'result.json').read_text())
    assert result['source'] == pin and result['exit'] == 0 and result['guards_match']
for side in ['left-semantic', 'right']:
    result = json.loads(Path(f'/tmp/gpui-ime-ascii-relative-{side}-executable-root/result.json').read_text())
    assert result['actual_test_exit'] == 101 and result['one_semantic_assertion_failed']
paths = ['reactivity/crates/gpui/src/runtime/ime.rs', 'reactivity/crates/gpui/examples/ime_cursor_cost.rs']
patch = subprocess.check_output(git + ['diff', '--binary', base, pin, '--', *paths])
Path('/tmp/gpui-ime-ascii-adoption-root.patch').write_bytes(patch)
subprocess.run(git + ['apply', '--check', '-'], input=patch, check=True)
subprocess.run(git + ['apply', '-'], input=patch, check=True)
assert all((root / path).read_bytes() == subprocess.check_output(git + ['show', f'{pin}:{path}']) for path in paths)
guard = json.loads(Path('/tmp/gpui-ime-ascii-relative-build-root/before.json').read_text())
differences = [name for name, expected in guard.items() if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected]
assert differences == ['reactivity/crates/gpui/README.md'], differences
subprocess.run(git + ['add', '--', *paths], check=True)
message = Path('/tmp/gpui-ime-ascii-adoption-commit-root.txt')
message.write_text('''Restart IME geometry at a certified ASCII grapheme boundary

Cursor-only preedit updates previously fed the entire unchanged prefix through
ICU. Certify an ASCII prefix with the standard slice scan, retain its final
complete grapheme (including CRLF), and keep the entire right suffix. Rebase
the admitted marked range and cursor endpoints once; the shared ICU loop stays
in suffix coordinates and translates only its four final positions. Non-ASCII
prefixes keep complete context and the same exact downstream tie policy.

No retained certificate, cache, allocation, dependency or unsafe code is added.
The shipping inventory grows by 12 lines. The executed Linux release ELF has
464 additional text bytes; the kernel's own fixed frame grows by 16 bytes.

The actual frozen fb8b775 library/public IME ELFs pass 209 tests, including the
79,333-case raw-byte oracle and a new 43,008-pair valid UTF-8 seam oracle.
Strict Clippy and the ordinary recording consumer pass. Corrected left-context
and right-context mutants both fail semantic full-string geometry comparisons;
the initial bounds-only mutant failure is preserved but is not the certificate.

Six counterbalanced processes on mothership validate unchanged source/display
state and measure 4 KiB 345,962 to 311,059 ns and 32 KiB 2,533,439 to 2,218,598 ns
per complete recording call. Unicode is 2,496,613 to 2,479,354 ns in that run.
Preserve the earlier byte-coordinate candidate's 0.335% Unicode slowdown too.
These are bounded CPU recording results, not native rendering or display
latency, and do not qualify physical IME turnover or any new backend.
''')
subprocess.run(git + ['commit', '-F', str(message)], check=True)
print(subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip())
