from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

source = Path('/tmp/gpui-ime-ascii-restart-root-20261024')
pin = 'fb8b775315642eef8c9415b5e35185248f19c27c'
out = Path('/tmp/gpui-ime-ascii-relative-mothership-stage-root')
prior = Path('/tmp/gpui-ime-ascii-byte-mothership-stage-root')
candidate = Path('/tmp/gpui-ime-ascii-relative-release-executable-root')
gate = Path('/tmp/gpui-ime-ascii-relative-release-build-root')
git = ['git', '-c', f'safe.directory={source}', '-C', str(source)]
assert subprocess.check_output(git + ['rev-parse', 'HEAD'], text=True).strip() == pin
assert not subprocess.check_output(git + ['status', '--porcelain'], text=True).strip()
guard = json.loads((gate / 'before.json').read_text())
assert guard == json.loads((gate / 'after.json').read_text())
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
assert all(digest(source / name) == expected for name, expected in guard.items())
out.mkdir()
for name in ['control', 'control-binary.json', 'control-command.json', 'control-source-guard.json', 'control-source.tar.gz']:
    shutil.copy2(prior / name, out / name)
shutil.copy2(candidate / 'ime_cursor_cost', out / 'candidate')
shutil.copy2(candidate / 'binary.json', out / 'candidate-binary.json')
shutil.copy2(gate / 'command.json', out / 'candidate-command.json')
shutil.copy2(gate / 'before.json', out / 'candidate-source-guard.json')
shutil.copy2('/tmp/gpui-ime-ascii-remote-root.py', out / 'run.py')
with (out / 'candidate-source.tar.gz').open('wb') as stream:
    subprocess.run(git + ['archive', '--format=tar.gz', pin, '.cargo', 'clippy.toml', 'reactivity/Cargo.toml', 'reactivity/Cargo.lock', 'reactivity/rust-toolchain.toml', 'reactivity/crates', 'reactivity/vendor'], stdout=stream, check=True)
with tarfile.open(out / 'candidate-source.tar.gz') as archive:
    for name, expected in guard.items():
        member = archive.extractfile(name)
        assert member and hashlib.sha256(member.read()).hexdigest() == expected, name
variants = {name: {'source': json.loads((out / f'{name}-binary.json').read_text())['source'], 'binary_sha256': digest(out / name)} for name in ['control', 'candidate']}
assert variants['candidate']['source'] == pin
manifest = {'variants': variants, 'files': {path.name: digest(path) for path in sorted(out.iterdir()) if path.is_file()}}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
bundle = out.with_suffix('.tar')
with tarfile.open(bundle, 'w') as archive:
    for path in sorted(out.iterdir()):
        archive.add(path, arcname=path.name, recursive=False)
print(json.dumps({'stage': str(out), 'bundle': str(bundle), 'bytes': bundle.stat().st_size, 'sha256': digest(bundle), 'variants': variants}))
