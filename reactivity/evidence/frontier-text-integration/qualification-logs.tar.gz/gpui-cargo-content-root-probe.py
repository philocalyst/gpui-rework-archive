from pathlib import Path
import hashlib, json, os, subprocess

root = Path('/tmp/gpui-cargo-content-root-probe')
root.mkdir(exist_ok=False)
target = root / 'target'
manifest = '[package]\nname="gpui-content-probe"\nversion="0.0.0"\nedition="2024"\n'
directories = []
for label, tag in [('baseline', 17), ('changed', 19)]:
    directory = root / label
    (directory / 'src').mkdir(parents=True)
    (directory / 'Cargo.toml').write_text(manifest)
    (directory / 'src/main.rs').write_text(f'fn main() {{ println!("CONTENT_TAG={tag}"); }}\n')
    # Both input versions predate either build. Mtime ordering cannot identify
    # which content generated the shared target's current executable.
    os.utime(directory / 'src/main.rs', (1_600_000_000, 1_600_000_000))
    subprocess.run(['cargo', 'generate-lockfile', '--offline'], cwd=directory, check=True,
                   capture_output=True, text=True)
    directories.append(directory)
guard = lambda directory: {str(path.relative_to(directory)): hashlib.sha256(path.read_bytes()).hexdigest()
                           for path in directory.rglob('*') if path.is_file()}
before = [guard(directory) for directory in directories]
results = []
env = dict(os.environ, CARGO_TARGET_DIR=str(target))
for index, label in [(0, 'first-baseline'), (1, 'changed-old-mtime'), (0, 'restored-old-mtime')]:
    directory = directories[index]
    command = ['cargo', '-Z', 'checksum-freshness', '--config', 'build.fingerprint="content"',
               'build', '--locked', '--offline', '--message-format=json']
    result = subprocess.run(command, cwd=directory, env=env, capture_output=True, text=True)
    (root / f'{label}.stdout.log').write_text(result.stdout)
    (root / f'{label}.stderr.log').write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    artifacts = [row for line in result.stdout.splitlines() if (row := json.loads(line)).get('executable')]
    assert len(artifacts) == 1 and not artifacts[0]['fresh']
    binary = Path(artifacts[0]['executable'])
    value = subprocess.check_output([str(binary)], text=True).strip()
    assert value == f'CONTENT_TAG={17 if index == 0 else 19}', value
    results.append({'label': label, 'argv': command, 'cwd': str(directory), 'output': value,
                    'fresh': artifacts[0]['fresh'], 'elf_sha256': hashlib.sha256(binary.read_bytes()).hexdigest()})
assert before == [guard(directory) for directory in directories]
report = {'results': results, 'source_guards_match': True, 'inputs': before,
          'cargo': subprocess.check_output(['cargo', '-Vv'], text=True),
          'rustc': subprocess.check_output(['rustc', '-Vv'], text=True),
          'scope': 'Content freshness control on actual pinned Cargo; build-script rerun-if-changed remains outside this guarantee.'}
(root / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(results), flush=True)
