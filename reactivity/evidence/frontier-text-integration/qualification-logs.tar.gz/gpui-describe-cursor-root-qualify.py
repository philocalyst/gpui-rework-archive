from pathlib import Path
import hashlib, json, os, re, shutil, subprocess, sys

gate = Path('/root/gpui-ce3/reactivity/evidence/clipping-gradients-integration/gpui-run-frozen-gate-root.py')
out = Path('/tmp/gpui-describe-cursor-root-qualification')
out.mkdir(exist_ok=False)
scopes = ['.cargo', 'clippy.toml', 'reactivity/Cargo.toml', 'reactivity/Cargo.lock',
          'reactivity/rust-toolchain.toml', 'reactivity/crates', 'reactivity/vendor']
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
pins = [('/tmp/gpui-frontier-text-compose-root', '73fe8cf27b01d4517076ca49b4a9c076f7a40838', 'baseline'),
        ('/tmp/gpui-describe-cursor-root', '81735ae7b0efb50dd2acb27d47961fc55305607b', 'candidate')]
results = []
for source, pin, label in pins:
    directory = out / label
    directory.mkdir()
    common = [sys.executable, str(gate), '--source', source, '--pin', pin, '--timeout', '1800']
    for scope in scopes:
        common += ['--scope', scope]
    subprocess.run(common + ['--out', str(directory / 'build'), '--', 'cargo', 'test', '--manifest-path',
                            'reactivity/Cargo.toml', '--locked', '--offline', '-p', 'gpui', '--test',
                            'frontier', '--no-run', '--message-format=json'], check=True)
    rows = [json.loads(line) for line in (directory / 'build/stdout.log').read_text().splitlines()]
    artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact'
                 and row.get('executable') and row['target']['name'] == 'frontier']
    assert len(artifacts) == 1
    row = artifacts[0]
    binary = directory / 'frontier'
    shutil.copy2(row['executable'], binary)
    binary.chmod(0o555)
    identity = {'source': pin, 'sha256': digest(binary), 'bytes': binary.stat().st_size,
                'original': row['executable'], 'frozen': str(binary), 'cargo': row,
                'target_dir': os.environ['CARGO_TARGET_DIR']}
    (directory / 'binary.json').write_text(json.dumps(identity, indent=2) + '\n')
    evidence = directory / 'public-artifacts'
    os.environ['GPUI_FRONTIER_EVIDENCE'] = str(evidence)
    subprocess.run(common + ['--out', str(directory / 'execute'), '--', str(binary), '--nocapture',
                             '--test-threads=1'], check=True)
    assert digest(binary) == identity['sha256']
    artifacts = {str(path.relative_to(evidence)): digest(path) for path in evidence.iterdir() if path.is_file()}
    stdout = (directory / 'execute/stdout.log').read_text()
    allocations = [line[line.index('FRONTIER '):] for line in stdout.splitlines() if 'FRONTIER ' in line]
    assert len(artifacts) == 120, len(artifacts)
    assert allocations, stdout
    results.append({'label': label, 'source': pin, 'artifacts': artifacts, 'allocation_lines': allocations,
                    'elf_sha256': identity['sha256'], 'elf_after_matches': True})
assert results[0]['artifacts'] == results[1]['artifacts']
report = {'results': results, 'exact_public_artifacts': 120,
          'scope': 'Actual allocation requests and exact semantic/hit/RGBA artifacts; no speed or RSS inference.'}
(out / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'exact_public_artifacts': 120, 'scope': report['scope']}), flush=True)
