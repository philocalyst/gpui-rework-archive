from pathlib import Path
import hashlib,json,subprocess
root=Path('/tmp/gpui-frontier-text-compose-root-artifacts')
out=Path('/tmp/gpui-frontier-text-root-density-replay');out.mkdir(exist_ok=False)
matches=[]
for p in root.glob('*/binary.json'):
    row=json.loads(p.read_text())
    if row['target']['name']=='text_metric_scale_probe':matches.append((p.parent/'test',row))
assert len(matches)==1,matches
binary,row=matches[0]
digest=lambda:hashlib.sha256(binary.read_bytes()).hexdigest()
assert digest()==row['sha256']
command=[str(binary),'--nocapture','--test-threads=1']
result=subprocess.run(command,capture_output=True,text=True,timeout=300)
(out/'stdout.log').write_text(result.stdout);(out/'stderr.log').write_text(result.stderr)
assert result.returncode==0,(result.stdout,result.stderr)
assert digest()==row['sha256']
report={'elf_source':'73fe8cf27b01d4517076ca49b4a9c076f7a40838','current_source':'22dae0afcc65071909ddbfcce0d2d8bc00dcbfa1','argv':command,'binary':row,'exit':0,'elf_after_matches':True,'scope':'Actual frozen Canvas-only density fixture replay; Canvas source and all its dependencies unchanged between these two pins. Allocation/capacity/work/bit fingerprints only; elapsed fields are not a performance comparison.'}
(out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(out)
