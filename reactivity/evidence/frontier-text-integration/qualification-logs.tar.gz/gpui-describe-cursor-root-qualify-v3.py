from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys

gate = Path('/root/gpui-ce3/reactivity/evidence/clipping-gradients-integration/gpui-run-frozen-gate-root.py')
out = Path('/tmp/gpui-describe-cursor-root-qualification')
baseline = out / 'baseline'
baseline_result = json.loads((baseline / 'execute/result.json').read_text())
assert baseline_result['exit'] == 0 and baseline_result['passed'] == 3
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
baseline_identity = json.loads((baseline / 'binary.json').read_text())
assert digest(baseline / 'frontier') == baseline_identity['sha256']
directory = out / 'candidate-clean'
directory.mkdir(exist_ok=False)
pin = '81735ae7b0efb50dd2acb27d47961fc55305607b'
common = [sys.executable, str(gate), '--source', '/tmp/gpui-describe-cursor-root', '--pin', pin,
          '--timeout', '1800']
for scope in ['.cargo', 'clippy.toml', 'reactivity/Cargo.toml', 'reactivity/Cargo.lock',
              'reactivity/rust-toolchain.toml', 'reactivity/crates', 'reactivity/vendor']:
    common += ['--scope', scope]
subprocess.run(common + ['--out', str(directory / 'build'), '--', 'cargo', 'test', '--manifest-path',
                        'reactivity/Cargo.toml', '--locked', '--offline', '-p', 'gpui', '--test',
                        'frontier', '--no-run', '--message-format=json'], check=True)
rows = [json.loads(line) for line in (directory / 'build/stdout.log').read_text().splitlines()]
artifacts = [row for row in rows if row.get('reason') == 'compiler-artifact'
             and row.get('executable') and row['target']['name'] == 'frontier']
assert len(artifacts) == 1
row = artifacts[0]
assert not row['fresh'], 'changed package must rebuild' 
binary = directory / 'frontier'
shutil.copy2(row['executable'], binary)
binary.chmod(0o555)
identity = {'source': pin, 'sha256': digest(binary), 'bytes': binary.stat().st_size,
            'original': row['executable'], 'frozen': str(binary), 'cargo': row,
            'target_dir': os.environ['CARGO_TARGET_DIR']}
(directory / 'binary.json').write_text(json.dumps(identity, indent=2) + '\n')
os.environ['GPUI_FRONTIER_EVIDENCE'] = str(directory / 'public-artifacts')
subprocess.run(common + ['--out', str(directory / 'execute'), '--', str(binary), '--nocapture',
                         '--test-threads=1'], check=True)
assert digest(binary) == identity['sha256']
results = []
for label in ['baseline', 'candidate-clean']:
    directory = out / label
    identity = json.loads((directory / 'binary.json').read_text())
    assert digest(directory / 'frontier') == identity['sha256']
    evidence = directory / 'public-artifacts'
    artifacts = {str(path.relative_to(evidence)): digest(path) for path in evidence.iterdir() if path.is_file()}
    stdout = (directory / 'execute/stdout.log').read_text()
    allocations = [line[line.index('FRONTIER_ALLOC '):] for line in stdout.splitlines() if 'FRONTIER_ALLOC ' in line]
    assert len(artifacts) == 120, len(artifacts)
    assert len(allocations) == 18, len(allocations)
    results.append({'label': label, 'source': identity['source'], 'artifacts': artifacts,
                    'allocation_lines': allocations, 'elf_sha256': identity['sha256'], 'elf_after_matches': True})
assert results[0]['artifacts'] == results[1]['artifacts']
assert results[0]['elf_sha256'] != results[1]['elf_sha256'], 'changed implementation must not reuse baseline ELF'
report = {'results': results, 'exact_public_artifacts': 120,
          'prior_driver_failure': 'v1 matched FRONTIER rather than actual FRONTIER_ALLOC; baseline build and all3 execution tests passed. They are reused after ELF hash revalidation.',
          'scope': 'Actual allocation requests and exact semantic/hit/RGBA artifacts; no speed or RSS inference.'}
(out / 'clean-result.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'exact_public_artifacts': 120, 'scope': report['scope']}), flush=True)
