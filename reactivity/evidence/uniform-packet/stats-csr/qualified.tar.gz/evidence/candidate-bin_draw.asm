
FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4531 frame=840

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008206e0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  8206e0:	push   %rbp
  8206e1:	push   %r15
  8206e3:	push   %r14
  8206e5:	push   %r13
  8206e7:	push   %r12
  8206e9:	push   %rbx
  8206ea:	sub    $0x318,%rsp
  8206f1:	movss  0x88(%rdx),%xmm3
  8206f9:	movss  -0x7716e5(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820701:	movaps %xmm3,%xmm1
  820704:	subss  %xmm0,%xmm1
  820708:	cvttss2si %xmm1,%rax
  82070d:	cvttss2si %xmm3,%r10
  820712:	mov    %r10,%rbp
  820715:	sar    $0x3f,%rbp
  820719:	and    %rax,%rbp
  82071c:	or     %r10,%rbp
  82071f:	xor    %eax,%eax
  820721:	xorps  %xmm1,%xmm1
  820724:	ucomiss %xmm1,%xmm3
  820727:	cmovb  %rax,%rbp
  82072b:	movss  0x90(%rdx),%xmm4
  820733:	movss  -0x77171b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82073b:	ucomiss %xmm2,%xmm3
  82073e:	mov    $0xffffffffffffffff,%r14
  820745:	cmova  %r14,%rbp
  820749:	movaps %xmm4,%xmm3
  82074c:	subss  %xmm0,%xmm3
  820750:	cvttss2si %xmm3,%r10
  820755:	cvttss2si %xmm4,%r11
  82075a:	mov    %r11,%rbx
  82075d:	sar    $0x3f,%rbx
  820761:	and    %r10,%rbx
  820764:	or     %r11,%rbx
  820767:	ucomiss %xmm1,%xmm4
  82076a:	cmovb  %rax,%rbx
  82076e:	ucomiss %xmm2,%xmm4
  820771:	cmova  %r14,%rbx
  820775:	movss  0x8c(%rdx),%xmm3
  82077d:	add    %rbp,%rbx
  820780:	dec    %rbx
  820783:	shr    $0x4,%rbx
  820787:	shr    $0x4,%rbp
  82078b:	mov    %rbx,%r13
  82078e:	sub    %rbp,%r13
  820791:	inc    %r13
  820794:	movaps %xmm3,%xmm4
  820797:	subss  %xmm0,%xmm4
  82079b:	cvttss2si %xmm4,%r11
  8207a0:	cvttss2si %xmm3,%r10
  8207a5:	mov    %r10,%r15
  8207a8:	sar    $0x3f,%r15
  8207ac:	and    %r11,%r15
  8207af:	or     %r10,%r15
  8207b2:	ucomiss %xmm1,%xmm3
  8207b5:	cmovb  %rax,%r15
  8207b9:	ucomiss %xmm2,%xmm3
  8207bc:	movss  0x94(%rdx),%xmm3
  8207c4:	cmova  %r14,%r15
  8207c8:	movaps %xmm3,%xmm4
  8207cb:	subss  %xmm0,%xmm4
  8207cf:	cvttss2si %xmm4,%r12
  8207d4:	cvttss2si %xmm3,%r10
  8207d9:	mov    %r10,%r11
  8207dc:	sar    $0x3f,%r11
  8207e0:	and    %r12,%r11
  8207e3:	or     %r10,%r11
  8207e6:	ucomiss %xmm1,%xmm3
  8207e9:	cmovb  %rax,%r11
  8207ed:	ucomiss %xmm2,%xmm3
  8207f0:	cmova  %r14,%r11
  8207f4:	mov    %r15,%r14
  8207f7:	lea    (%r15,%r11,1),%r10
  8207fb:	dec    %r10
  8207fe:	shr    $0x4,%r10
  820802:	shr    $0x4,%r14
  820806:	mov    %r10,%r12
  820809:	sub    %r14,%r12
  82080c:	inc    %r12
  82080f:	imul   %r13,%r12
  820813:	mov    0x368(%rsp),%r11
  82081b:	add    %r12,%r11
  82081e:	setb   %al
  820821:	cmp    $0x400001,%r11
  820828:	setae  %r15b
  82082c:	or     %al,%r15b
  82082f:	mov    $0x6,%eax
  820834:	jne    820936 <<gpui_gpu::renderer::RendererState>::bin_draw+0x256>
  82083a:	mov    %r12,0x1e8(%rsp)
  820842:	mov    %r11,0x198(%rsp)
  82084a:	mov    %rdi,0x1a0(%rsp)
  820852:	cmpb   $0x0,(%rdx)
  820855:	sete   %al
  820858:	and    0x340(%rsi),%al
  82085e:	movl   $0x0,0x4(%rsp)
  820866:	cmp    $0x1,%al
  820868:	jne    8208f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  82086e:	movss  0xa4(%rdx),%xmm0
  820876:	ucomiss -0x771a9d(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82087d:	jne    8208f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  82087f:	jp     8208f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  820881:	mov    0x98(%rdx),%edi
  820887:	test   %edi,%edi
  820889:	jns    82089b <<gpui_gpu::renderer::RendererState>::bin_draw+0x1bb>
  82088b:	and    $0x7f800000,%edi
  820891:	dec    %edi
  820893:	cmp    $0x7f7fffff,%edi
  820899:	jae    8208f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  82089b:	mov    0x9c(%rdx),%edi
  8208a1:	test   %edi,%edi
  8208a3:	jns    8208b5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d5>
  8208a5:	and    $0x7f800000,%edi
  8208ab:	dec    %edi
  8208ad:	cmp    $0x7f7ffffe,%edi
  8208b3:	ja     8208f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8208b5:	mov    0xa0(%rdx),%edi
  8208bb:	test   %edi,%edi
  8208bd:	jns    8208cf <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ef>
  8208bf:	and    $0x7f800000,%edi
  8208c5:	dec    %edi
  8208c7:	cmp    $0x7f7ffffe,%edi
  8208cd:	ja     8208f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8208cf:	movd   %xmm0,%edi
  8208d3:	test   %edi,%edi
  8208d5:	jns    8208e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8208d7:	and    $0x7f800000,%edi
  8208dd:	dec    %edi
  8208df:	cmp    $0x7f7ffffe,%edi
  8208e5:	ja     8208f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8208e7:	mov    $0x1,%dil
  8208ea:	mov    %edi,0x4(%rsp)
  8208ee:	jmp    8208f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8208f0:	movl   $0x0,0x4(%rsp)
  8208f8:	mov    %rcx,0xe0(%rsp)
  820900:	mov    %r8d,0xbc(%rsp)
  820908:	mov    %r9,0xa8(%rsp)
  820910:	mov    %rdx,0xe8(%rsp)
  820918:	cmp    %r14,%r10
  82091b:	jae    82094a <<gpui_gpu::renderer::RendererState>::bin_draw+0x26a>
  82091d:	mov    0x1a0(%rsp),%rdi
  820925:	mov    0x198(%rsp),%rax
  82092d:	mov    %rax,0x8(%rdi)
  820931:	mov    $0xffffffff,%eax
  820936:	mov    %eax,(%rdi)
  820938:	add    $0x318,%rsp
  82093f:	pop    %rbx
  820940:	pop    %r12
  820942:	pop    %r13
  820944:	pop    %r14
  820946:	pop    %r15
  820948:	pop    %rbp
  820949:	ret
  82094a:	cmp    %rbp,%rbx
  82094d:	jae    820966 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  82094f:	nop
  820950:	mov    %r14,%rax
  820953:	cmp    %r10,%r14
  820956:	adc    $0x0,%r14
  82095a:	cmp    %r10,%rax
  82095d:	jae    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82095f:	cmp    %r10,%r14
  820962:	jbe    820950 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  820964:	jmp    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  820966:	mov    0x350(%rsp),%r13
  82096e:	mov    0x20(%rsi),%r15
  820972:	mov    0x28(%rsi),%r9
  820976:	test   %al,%al
  820978:	je     8217d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  82097e:	mov    0xe0(%rsp),%rax
  820986:	movd   %eax,%xmm0
  82098a:	shr    $0x20,%rax
  82098e:	mov    0xe8(%rsp),%rcx
  820996:	movss  0x78(%rcx),%xmm1
  82099b:	cvtss2sd %xmm1,%xmm12
  8209a0:	movss  0x80(%rcx),%xmm1
  8209a8:	movss  0x7c(%rcx),%xmm2
  8209ad:	xorps  %xmm3,%xmm3
  8209b0:	cvtss2sd %xmm2,%xmm3
  8209b4:	movss  0x84(%rcx),%xmm2
  8209bc:	cvtss2sd %xmm1,%xmm1
  8209c0:	addsd  %xmm12,%xmm1
  8209c5:	movsd  %xmm1,0x1d8(%rsp)
  8209ce:	xorps  %xmm1,%xmm1
  8209d1:	cvtss2sd %xmm2,%xmm1
  8209d5:	movsd  %xmm3,0x1e0(%rsp)
  8209de:	addsd  %xmm3,%xmm1
  8209e2:	movsd  %xmm1,0x1c8(%rsp)
  8209eb:	movsd  0x48(%rcx),%xmm3
  8209f0:	movsd  0x58(%rcx),%xmm4
  8209f5:	movsd  0x68(%rcx),%xmm5
  8209fa:	movss  0x38(%rcx),%xmm1
  8209ff:	movss  0x40(%rcx),%xmm2
  820a04:	cvtss2sd %xmm1,%xmm1
  820a08:	cvtss2sd %xmm2,%xmm2
  820a0c:	movaps -0x775be3(%rip),%xmm6        # aae30 <GCC_except_table0+0x6c>
  820a13:	movaps %xmm1,0x90(%rsp)
  820a1b:	andps  %xmm6,%xmm1
  820a1e:	movaps %xmm1,0x80(%rsp)
  820a26:	movaps %xmm2,0x60(%rsp)
  820a2b:	andps  %xmm6,%xmm2
  820a2e:	movaps %xmm2,0x70(%rsp)
  820a33:	cvtss2sd %xmm0,%xmm0
  820a37:	movsd  %xmm0,0x18(%rsp)
  820a3d:	movaps %xmm3,%xmm0
  820a40:	andps  %xmm6,%xmm0
  820a43:	movaps %xmm0,0x290(%rsp)
  820a4b:	movaps %xmm4,%xmm0
  820a4e:	andps  %xmm6,%xmm0
  820a51:	movaps %xmm0,0x270(%rsp)
  820a59:	movaps %xmm5,%xmm0
  820a5c:	andps  %xmm6,%xmm0
  820a5f:	movaps %xmm0,0x130(%rsp)
  820a67:	movss  0x3c(%rcx),%xmm0
  820a6c:	xorps  %xmm1,%xmm1
  820a6f:	cvtss2sd %xmm0,%xmm1
  820a73:	movss  0x44(%rcx),%xmm0
  820a78:	cvtss2sd %xmm0,%xmm0
  820a7c:	movaps %xmm1,0x50(%rsp)
  820a81:	andps  %xmm6,%xmm1
  820a84:	movaps %xmm1,0x40(%rsp)
  820a89:	movaps %xmm0,0x20(%rsp)
  820a8e:	andps  %xmm6,%xmm0
  820a91:	movaps %xmm0,0x30(%rsp)
  820a96:	movd   %eax,%xmm0
  820a9a:	cvtss2sd %xmm0,%xmm0
  820a9e:	movsd  %xmm0,0x10(%rsp)
  820aa4:	movsd  0x50(%rcx),%xmm1
  820aa9:	movaps %xmm1,%xmm0
  820aac:	andps  %xmm6,%xmm0
  820aaf:	movaps %xmm0,0x210(%rsp)
  820ab7:	movsd  0x60(%rcx),%xmm2
  820abc:	movaps %xmm2,%xmm0
  820abf:	andps  %xmm6,%xmm0
  820ac2:	movaps %xmm0,0x1f0(%rsp)
  820aca:	movsd  0x70(%rcx),%xmm7
  820acf:	andps  %xmm7,%xmm6
  820ad2:	movaps %xmm6,0x100(%rsp)
  820ada:	mov    0x58(%rsi),%rax
  820ade:	mov    %rax,0xd8(%rsp)
  820ae6:	mov    0x50(%rsi),%rax
  820aea:	mov    %rax,0x1d0(%rsp)
  820af2:	movaps %xmm3,0x2a0(%rsp)
  820afa:	movaps %xmm3,%xmm0
  820afd:	movaps %xmm4,0x280(%rsp)
  820b05:	movlhps %xmm4,%xmm0
  820b08:	cvtpd2ps %xmm0,%xmm0
  820b0c:	movaps %xmm1,0x220(%rsp)
  820b14:	cvtsd2ss %xmm1,%xmm1
  820b18:	cvtss2sd %xmm1,%xmm1
  820b1c:	cvtps2pd %xmm0,%xmm3
  820b1f:	movaps %xmm2,0x200(%rsp)
  820b27:	xorps  %xmm0,%xmm0
  820b2a:	cvtsd2ss %xmm2,%xmm0
  820b2e:	xorps  %xmm2,%xmm2
  820b31:	cvtss2sd %xmm0,%xmm2
  820b35:	movaps %xmm5,0x140(%rsp)
  820b3d:	xorps  %xmm0,%xmm0
  820b40:	cvtsd2ss %xmm5,%xmm0
  820b44:	cvtss2sd %xmm0,%xmm4
  820b48:	movaps %xmm7,0xf0(%rsp)
  820b50:	xorps  %xmm0,%xmm0
  820b53:	cvtsd2ss %xmm7,%xmm0
  820b57:	mov    0xa8(%rsp),%rax
  820b5f:	inc    %eax
  820b61:	mov    %rax,0xa8(%rsp)
  820b69:	cvtss2sd %xmm0,%xmm0
  820b6d:	movaps -0x775d44(%rip),%xmm5        # aae30 <GCC_except_table0+0x6c>
  820b74:	movaps %xmm3,%xmm6
  820b77:	andps  %xmm5,%xmm6
  820b7a:	movaps %xmm4,0x160(%rsp)
  820b82:	andps  %xmm5,%xmm4
  820b85:	movaps %xmm4,0x150(%rsp)
  820b8d:	movaps %xmm1,0x260(%rsp)
  820b95:	andps  %xmm5,%xmm1
  820b98:	movaps %xmm1,0x250(%rsp)
  820ba0:	movaps %xmm2,0x240(%rsp)
  820ba8:	andps  %xmm5,%xmm2
  820bab:	movaps %xmm2,0x230(%rsp)
  820bb3:	movaps %xmm0,0x120(%rsp)
  820bbb:	andps  %xmm0,%xmm5
  820bbe:	movaps %xmm5,0x110(%rsp)
  820bc6:	movaps %xmm3,0x2c0(%rsp)
  820bce:	movhlps %xmm3,%xmm3
  820bd1:	movaps %xmm3,0x2f0(%rsp)
  820bd9:	mov    $0x2,%r11b
  820bdc:	xor    %edx,%edx
  820bde:	mov    %r14,%rax
  820be1:	movaps %xmm6,0x2b0(%rsp)
  820be9:	pshufd $0xee,%xmm6,%xmm0
  820bee:	movdqa %xmm0,0x2e0(%rsp)
  820bf7:	movsd  %xmm12,0x8(%rsp)
  820bfe:	mov    %rbp,0x1b0(%rsp)
  820c06:	mov    %r10,0x1a8(%rsp)
  820c0e:	xchg   %ax,%ax
  820c10:	cmp    %r10,%r14
  820c13:	adc    $0x0,%rax
  820c17:	mov    %rax,0x1b8(%rsp)
  820c1f:	mov    %r14,0x1c0(%rsp)
  820c27:	imul   %r13,%r14
  820c2b:	mov    %rbp,%r10
  820c2e:	mov    0x360(%rsp),%r8d
  820c36:	mov    0x358(%rsp),%ecx
  820c3d:	jmp    820c60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820c3f:	cmp    %r9,%r12
  820c42:	jae    821835 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820c48:	incl   0x4(%r15,%r12,8)
  820c4d:	mov    $0x1,%dl
  820c4f:	cmp    %rbx,%r10
  820c52:	jb     820e23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820c58:	jmp    821790 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820c5d:	nopl   (%rax)
  820c60:	cmp    %rbx,%r10
  820c63:	adc    $0x0,%rbp
  820c67:	lea    (%r10,%r14,1),%r12
  820c6b:	cmpb   $0x0,0x4(%rsp)
  820c70:	jne    820c87 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a7>
  820c72:	cmp    %r9,%r12
  820c75:	jae    821855 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1175>
  820c7b:	testb  $0x40,0x7(%r15,%r12,8)
  820c81:	je     820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820c87:	cmpq   $0x2,0x1e8(%rsp)
  820c90:	setae  %al
  820c93:	and    %dl,%al
  820c95:	cmp    $0x1,%al
  820c97:	jne    820d72 <<gpui_gpu::renderer::RendererState>::bin_draw+0x692>
  820c9d:	cmp    $0x2,%r11b
  820ca1:	jne    820d0c <<gpui_gpu::renderer::RendererState>::bin_draw+0x62c>
  820ca3:	mov    %r10,0xb0(%rsp)
  820cab:	mov    0xe8(%rsp),%rdi
  820cb3:	mov    0xe0(%rsp),%rsi
  820cbb:	mov    %r13,%rdx
  820cbe:	mov    %rbp,0xc0(%rsp)
  820cc6:	mov    %rbx,%rbp
  820cc9:	mov    %r14,%rbx
  820ccc:	mov    %r15,%r14
  820ccf:	mov    %r9,%r15
  820cd2:	call   8257d0 <gpui_gpu::renderer::coverage::whole>
  820cd7:	mov    0xb0(%rsp),%r10
  820cdf:	movsd  0x8(%rsp),%xmm12
  820ce6:	mov    0x360(%rsp),%r8d
  820cee:	mov    %r15,%r9
  820cf1:	mov    %r14,%r15
  820cf4:	mov    %rbx,%r14
  820cf7:	mov    %rbp,%rbx
  820cfa:	mov    0xc0(%rsp),%rbp
  820d02:	mov    0x358(%rsp),%ecx
  820d09:	mov    %eax,%r11d
  820d0c:	test   $0x1,%r11b
  820d10:	mov    $0x1,%r11b
  820d13:	je     820d6f <<gpui_gpu::renderer::RendererState>::bin_draw+0x68f>
  820d15:	cmpb   $0x0,0x4(%rsp)
  820d1a:	je     820c3f <<gpui_gpu::renderer::RendererState>::bin_draw+0x55f>
  820d20:	cmp    %r9,%r12
  820d23:	jae    821880 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11a0>
  820d29:	mov    0xbc(%rsp),%eax
  820d30:	mov    %eax,(%r15,%r12,8)
  820d34:	movl   $0x40000001,0x4(%r15,%r12,8)
  820d3d:	cmp    0xd8(%rsp),%r12
  820d45:	jae    821868 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1188>
  820d4b:	mov    0xa8(%rsp),%rax
  820d53:	mov    0x1d0(%rsp),%rdx
  820d5b:	mov    %eax,(%rdx,%r12,4)
  820d5f:	mov    $0x1,%dl
  820d61:	cmp    %rbx,%r10
  820d64:	jb     820e23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820d6a:	jmp    821790 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820d6f:	xor    %r11d,%r11d
  820d72:	test   %r13,%r13
  820d75:	je     821848 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1168>
  820d7b:	mov    %r12,%rax
  820d7e:	shr    $0x20,%rax
  820d82:	je     820d90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b0>
  820d84:	mov    %r12,%rax
  820d87:	xor    %edx,%edx
  820d89:	div    %r13
  820d8c:	jmp    820d98 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b8>
  820d8e:	xchg   %ax,%ax
  820d90:	mov    %r12d,%eax
  820d93:	xor    %edx,%edx
  820d95:	div    %r13d
  820d98:	shl    $0x4,%edx
  820d9b:	shl    $0x4,%eax
  820d9e:	lea    0x10(%rdx),%esi
  820da1:	cmp    %esi,%ecx
  820da3:	cmovb  %ecx,%esi
  820da6:	lea    0x10(%rax),%edi
  820da9:	cmp    %edi,%r8d
  820dac:	cmovb  %r8d,%edi
  820db0:	xorps  %xmm2,%xmm2
  820db3:	cvtsi2sd %edx,%xmm2
  820db7:	mov    $0x1,%dl
  820db9:	ucomisd %xmm2,%xmm12
  820dbe:	ja     820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820dc0:	mov    %eax,%eax
  820dc2:	xorps  %xmm3,%xmm3
  820dc5:	cvtsi2sd %rax,%xmm3
  820dca:	movsd  0x1e0(%rsp),%xmm0
  820dd3:	ucomisd %xmm3,%xmm0
  820dd7:	ja     820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820dd9:	xorps  %xmm0,%xmm0
  820ddc:	cvtsi2sd %esi,%xmm0
  820de0:	ucomisd 0x1d8(%rsp),%xmm0
  820de9:	ja     820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820deb:	xorps  %xmm1,%xmm1
  820dee:	cvtsi2sd %edi,%xmm1
  820df2:	ucomisd 0x1c8(%rsp),%xmm1
  820dfb:	jbe    820e34 <<gpui_gpu::renderer::RendererState>::bin_draw+0x754>
  820dfd:	nopl   (%rax)
  820e00:	cmp    %r9,%r12
  820e03:	jae    821835 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820e09:	mov    0x4(%r15,%r12,8),%eax
  820e0e:	inc    %eax
  820e10:	and    $0xbfffffff,%eax
  820e15:	mov    %eax,0x4(%r15,%r12,8)
  820e1a:	cmp    %rbx,%r10
  820e1d:	jae    821790 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820e23:	mov    %rbp,%r10
  820e26:	cmp    %rbx,%rbp
  820e29:	jbe    820c60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820e2f:	jmp    821790 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820e34:	unpcklpd %xmm3,%xmm2
  820e38:	addpd  -0x773d00(%rip),%xmm2        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820e40:	movapd %xmm2,%xmm3
  820e44:	mulpd  0x2c0(%rsp),%xmm3
  820e4d:	movapd %xmm3,%xmm11
  820e52:	unpckhpd %xmm3,%xmm11
  820e57:	movapd %xmm3,%xmm5
  820e5b:	addsd  %xmm11,%xmm5
  820e60:	addsd  0x160(%rsp),%xmm5
  820e69:	subsd  0x90(%rsp),%xmm5
  820e72:	movapd 0x2b0(%rsp),%xmm8
  820e7c:	mulpd  %xmm2,%xmm8
  820e81:	movapd %xmm8,%xmm4
  820e86:	unpckhpd %xmm8,%xmm4
  820e8b:	movapd %xmm8,%xmm6
  820e90:	addsd  %xmm4,%xmm6
  820e94:	addsd  0x150(%rsp),%xmm6
  820e9d:	addsd  0x80(%rsp),%xmm6
  820ea6:	addsd  0x70(%rsp),%xmm6
  820eac:	addsd  -0x7715d4(%rip),%xmm6        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820eb4:	mulsd  -0x77165c(%rip),%xmm6        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ebc:	addsd  0x18(%rsp),%xmm6
  820ec2:	ucomisd %xmm5,%xmm6
  820ec6:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820ecc:	movapd 0x60(%rsp),%xmm7
  820ed2:	subsd  %xmm5,%xmm7
  820ed6:	ucomisd %xmm7,%xmm6
  820eda:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820ee0:	movapd %xmm2,%xmm13
  820ee5:	unpckhpd %xmm2,%xmm13
  820eea:	movapd 0x280(%rsp),%xmm15
  820ef4:	mulsd  %xmm13,%xmm15
  820ef9:	movapd 0x270(%rsp),%xmm14
  820f03:	mulsd  %xmm13,%xmm14
  820f08:	movapd 0x2a0(%rsp),%xmm5
  820f11:	mulsd  %xmm2,%xmm5
  820f15:	movapd %xmm5,%xmm6
  820f19:	addsd  %xmm15,%xmm6
  820f1e:	addsd  0x140(%rsp),%xmm6
  820f27:	subsd  0x90(%rsp),%xmm6
  820f30:	movapd 0x290(%rsp),%xmm7
  820f39:	mulsd  %xmm2,%xmm7
  820f3d:	movapd %xmm7,%xmm9
  820f42:	addsd  %xmm14,%xmm9
  820f47:	addsd  0x130(%rsp),%xmm9
  820f51:	addsd  0x80(%rsp),%xmm9
  820f5b:	addsd  0x70(%rsp),%xmm9
  820f62:	addsd  -0x77168b(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f6b:	mulsd  -0x771134(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f74:	ucomisd %xmm6,%xmm9
  820f79:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820f7f:	movapd 0x60(%rsp),%xmm10
  820f86:	subsd  %xmm6,%xmm10
  820f8b:	ucomisd %xmm10,%xmm9
  820f90:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820f96:	movapd %xmm13,%xmm9
  820f9b:	mulsd  0x240(%rsp),%xmm9
  820fa5:	movapd %xmm13,%xmm12
  820faa:	mulsd  0x230(%rsp),%xmm12
  820fb4:	movapd %xmm2,%xmm10
  820fb9:	mulsd  0x260(%rsp),%xmm10
  820fc3:	movapd %xmm10,%xmm6
  820fc8:	movapd %xmm9,0xc0(%rsp)
  820fd2:	addsd  %xmm9,%xmm6
  820fd7:	addsd  0x120(%rsp),%xmm6
  820fe0:	subsd  0x50(%rsp),%xmm6
  820fe6:	movapd %xmm2,%xmm9
  820feb:	mulsd  0x250(%rsp),%xmm9
  820ff5:	movsd  %xmm9,0xb0(%rsp)
  820fff:	addsd  %xmm12,%xmm9
  821004:	addsd  0x110(%rsp),%xmm9
  82100e:	addsd  0x40(%rsp),%xmm9
  821015:	addsd  0x30(%rsp),%xmm9
  82101c:	addsd  -0x771745(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821025:	mulsd  -0x7717ce(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82102e:	addsd  0x10(%rsp),%xmm9
  821035:	ucomisd %xmm6,%xmm9
  82103a:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821040:	movsd  %xmm10,0x190(%rsp)
  82104a:	movapd 0x20(%rsp),%xmm10
  821051:	subsd  %xmm6,%xmm10
  821056:	ucomisd %xmm10,%xmm9
  82105b:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821061:	movapd 0x200(%rsp),%xmm9
  82106b:	mulsd  %xmm13,%xmm9
  821070:	mulsd  0x1f0(%rsp),%xmm13
  82107a:	movapd 0x220(%rsp),%xmm10
  821084:	mulsd  %xmm2,%xmm10
  821089:	movapd %xmm10,%xmm6
  82108e:	movapd %xmm9,0x170(%rsp)
  821098:	addsd  %xmm9,%xmm6
  82109d:	addsd  0xf0(%rsp),%xmm6
  8210a6:	subsd  0x50(%rsp),%xmm6
  8210ac:	mulsd  0x210(%rsp),%xmm2
  8210b5:	movapd %xmm2,%xmm9
  8210ba:	addsd  %xmm13,%xmm9
  8210bf:	addsd  0x100(%rsp),%xmm9
  8210c9:	addsd  0x40(%rsp),%xmm9
  8210d0:	addsd  0x30(%rsp),%xmm9
  8210d7:	addsd  -0x771800(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210e0:	mulsd  -0x7712a9(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210e9:	ucomisd %xmm6,%xmm9
  8210ee:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8210f4:	movapd %xmm10,0x300(%rsp)
  8210fe:	movapd 0x20(%rsp),%xmm10
  821105:	subsd  %xmm6,%xmm10
  82110a:	ucomisd %xmm10,%xmm9
  82110f:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821115:	addsd  -0x771b35(%rip),%xmm0        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82111d:	movapd %xmm0,%xmm9
  821122:	mulsd  0x2c0(%rsp),%xmm9
  82112c:	addsd  %xmm9,%xmm11
  821131:	addsd  0x160(%rsp),%xmm11
  82113b:	subsd  0x90(%rsp),%xmm11
  821145:	movapd 0x2b0(%rsp),%xmm10
  82114f:	mulsd  %xmm0,%xmm10
  821154:	addsd  %xmm10,%xmm4
  821159:	addsd  0x150(%rsp),%xmm4
  821162:	addsd  0x80(%rsp),%xmm4
  82116b:	addsd  0x70(%rsp),%xmm4
  821171:	addsd  -0x771899(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821179:	mulsd  -0x771921(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821181:	addsd  0x18(%rsp),%xmm4
  821187:	ucomisd %xmm11,%xmm4
  82118c:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821192:	movapd 0x60(%rsp),%xmm6
  821198:	subsd  %xmm11,%xmm6
  82119d:	ucomisd %xmm6,%xmm4
  8211a1:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8211a7:	movapd 0x2a0(%rsp),%xmm6
  8211b0:	mulsd  %xmm0,%xmm6
  8211b4:	addsd  %xmm6,%xmm15
  8211b9:	addsd  0x140(%rsp),%xmm15
  8211c3:	subsd  0x90(%rsp),%xmm15
  8211cd:	movapd 0x290(%rsp),%xmm11
  8211d7:	mulsd  %xmm0,%xmm11
  8211dc:	addsd  %xmm11,%xmm14
  8211e1:	addsd  0x130(%rsp),%xmm14
  8211eb:	addsd  0x80(%rsp),%xmm14
  8211f5:	addsd  0x70(%rsp),%xmm14
  8211fc:	addsd  -0x771925(%rip),%xmm14        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821205:	mulsd  -0x7713ce(%rip),%xmm14        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82120e:	ucomisd %xmm15,%xmm14
  821213:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821219:	movapd 0x60(%rsp),%xmm4
  82121f:	subsd  %xmm15,%xmm4
  821224:	ucomisd %xmm4,%xmm14
  821229:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  82122f:	movapd %xmm0,%xmm14
  821234:	mulsd  0x260(%rsp),%xmm14
  82123e:	movapd 0xc0(%rsp),%xmm4
  821247:	addsd  %xmm14,%xmm4
  82124c:	addsd  0x120(%rsp),%xmm4
  821255:	subsd  0x50(%rsp),%xmm4
  82125b:	movapd %xmm0,%xmm15
  821260:	mulsd  0x250(%rsp),%xmm15
  82126a:	addsd  %xmm15,%xmm12
  82126f:	addsd  0x110(%rsp),%xmm12
  821279:	addsd  0x40(%rsp),%xmm12
  821280:	addsd  0x30(%rsp),%xmm12
  821287:	addsd  -0x7719b0(%rip),%xmm12        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821290:	mulsd  -0x771a39(%rip),%xmm12        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821299:	addsd  0x10(%rsp),%xmm12
  8212a0:	ucomisd %xmm4,%xmm12
  8212a5:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8212ab:	movsd  %xmm15,0xc0(%rsp)
  8212b5:	movapd %xmm4,%xmm15
  8212ba:	movapd 0x20(%rsp),%xmm4
  8212c0:	subsd  %xmm15,%xmm4
  8212c5:	ucomisd %xmm4,%xmm12
  8212ca:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8212d0:	movapd 0x220(%rsp),%xmm4
  8212d9:	mulsd  %xmm0,%xmm4
  8212dd:	movapd 0x170(%rsp),%xmm15
  8212e7:	addsd  %xmm4,%xmm15
  8212ec:	addsd  0xf0(%rsp),%xmm15
  8212f6:	subsd  0x50(%rsp),%xmm15
  8212fd:	mulsd  0x210(%rsp),%xmm0
  821306:	addsd  %xmm0,%xmm13
  82130b:	addsd  0x100(%rsp),%xmm13
  821315:	addsd  0x40(%rsp),%xmm13
  82131c:	addsd  0x30(%rsp),%xmm13
  821323:	addsd  -0x771a4c(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82132c:	mulsd  -0x7714f5(%rip),%xmm13        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821335:	ucomisd %xmm15,%xmm13
  82133a:	movsd  0x8(%rsp),%xmm12
  821341:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821347:	movapd %xmm4,0x170(%rsp)
  821350:	movapd 0x20(%rsp),%xmm4
  821356:	subsd  %xmm15,%xmm4
  82135b:	ucomisd %xmm4,%xmm13
  821360:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821366:	movsd  %xmm10,0x188(%rsp)
  821370:	addsd  -0x771d90(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  821378:	movapd %xmm1,%xmm10
  82137d:	mulsd  0x2f0(%rsp),%xmm10
  821387:	movapd %xmm1,%xmm4
  82138b:	mulsd  0x2e0(%rsp),%xmm4
  821394:	addsd  %xmm10,%xmm3
  821399:	addsd  0x160(%rsp),%xmm3
  8213a2:	subsd  0x90(%rsp),%xmm3
  8213ab:	addsd  %xmm4,%xmm8
  8213b0:	addsd  0x150(%rsp),%xmm8
  8213ba:	addsd  0x80(%rsp),%xmm8
  8213c4:	addsd  0x70(%rsp),%xmm8
  8213cb:	addsd  -0x771af4(%rip),%xmm8        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213d4:	mulsd  -0x771b7d(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8213dd:	addsd  0x18(%rsp),%xmm8
  8213e4:	ucomisd %xmm3,%xmm8
  8213e9:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8213ef:	movapd %xmm6,0x2d0(%rsp)
  8213f8:	movapd 0x60(%rsp),%xmm6
  8213fe:	subsd  %xmm3,%xmm6
  821402:	ucomisd %xmm6,%xmm8
  821407:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82140d:	movapd 0x280(%rsp),%xmm8
  821417:	mulsd  %xmm1,%xmm8
  82141c:	movapd 0x270(%rsp),%xmm3
  821425:	mulsd  %xmm1,%xmm3
  821429:	addsd  %xmm8,%xmm5
  82142e:	addsd  0x140(%rsp),%xmm5
  821437:	subsd  0x90(%rsp),%xmm5
  821440:	addsd  %xmm3,%xmm7
  821444:	addsd  0x130(%rsp),%xmm7
  82144d:	addsd  0x80(%rsp),%xmm7
  821456:	addsd  0x70(%rsp),%xmm7
  82145c:	addsd  -0x771b84(%rip),%xmm7        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821464:	mulsd  -0x77162c(%rip),%xmm7        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82146c:	ucomisd %xmm5,%xmm7
  821470:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821476:	movapd 0x60(%rsp),%xmm6
  82147c:	subsd  %xmm5,%xmm6
  821480:	ucomisd %xmm6,%xmm7
  821484:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82148a:	movsd  %xmm14,0x180(%rsp)
  821494:	movapd %xmm9,%xmm14
  821499:	movapd %xmm1,%xmm7
  82149d:	mulsd  0x240(%rsp),%xmm7
  8214a6:	movapd %xmm1,%xmm5
  8214aa:	mulsd  0x230(%rsp),%xmm5
  8214b3:	movsd  0x190(%rsp),%xmm9
  8214bd:	addsd  %xmm7,%xmm9
  8214c2:	addsd  0x120(%rsp),%xmm9
  8214cc:	subsd  0x50(%rsp),%xmm9
  8214d3:	movsd  0xb0(%rsp),%xmm13
  8214dd:	addsd  %xmm5,%xmm13
  8214e2:	addsd  0x110(%rsp),%xmm13
  8214ec:	addsd  0x40(%rsp),%xmm13
  8214f3:	addsd  0x30(%rsp),%xmm13
  8214fa:	addsd  -0x771c23(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821503:	mulsd  -0x771cac(%rip),%xmm13        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82150c:	addsd  0x10(%rsp),%xmm13
  821513:	ucomisd %xmm9,%xmm13
  821518:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82151e:	movapd 0x20(%rsp),%xmm6
  821524:	subsd  %xmm9,%xmm6
  821529:	ucomisd %xmm6,%xmm13
  82152e:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821534:	movapd 0x200(%rsp),%xmm6
  82153d:	mulsd  %xmm1,%xmm6
  821541:	mulsd  0x1f0(%rsp),%xmm1
  82154a:	movapd 0x300(%rsp),%xmm13
  821554:	addsd  %xmm6,%xmm13
  821559:	addsd  0xf0(%rsp),%xmm13
  821563:	subsd  0x50(%rsp),%xmm13
  82156a:	addsd  %xmm1,%xmm2
  82156e:	addsd  0x100(%rsp),%xmm2
  821577:	addsd  0x40(%rsp),%xmm2
  82157d:	addsd  0x30(%rsp),%xmm2
  821583:	addsd  -0x771cab(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82158b:	mulsd  -0x771753(%rip),%xmm2        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821593:	ucomisd %xmm13,%xmm2
  821598:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82159e:	movapd 0x20(%rsp),%xmm9
  8215a5:	subsd  %xmm13,%xmm9
  8215aa:	ucomisd %xmm9,%xmm2
  8215af:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8215b5:	addsd  %xmm10,%xmm14
  8215ba:	addsd  0x160(%rsp),%xmm14
  8215c4:	subsd  0x90(%rsp),%xmm14
  8215ce:	movsd  0x188(%rsp),%xmm9
  8215d8:	addsd  %xmm4,%xmm9
  8215dd:	addsd  0x150(%rsp),%xmm9
  8215e7:	addsd  0x80(%rsp),%xmm9
  8215f1:	addsd  0x70(%rsp),%xmm9
  8215f8:	addsd  -0x771d21(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821601:	mulsd  -0x771daa(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82160a:	addsd  0x18(%rsp),%xmm9
  821611:	ucomisd %xmm14,%xmm9
  821616:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82161c:	movapd 0x60(%rsp),%xmm2
  821622:	subsd  %xmm14,%xmm2
  821627:	ucomisd %xmm2,%xmm9
  82162c:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821632:	movapd 0x2d0(%rsp),%xmm4
  82163b:	addsd  %xmm8,%xmm4
  821640:	addsd  0x140(%rsp),%xmm4
  821649:	subsd  0x90(%rsp),%xmm4
  821652:	addsd  %xmm3,%xmm11
  821657:	addsd  0x130(%rsp),%xmm11
  821661:	addsd  0x80(%rsp),%xmm11
  82166b:	addsd  0x70(%rsp),%xmm11
  821672:	addsd  -0x771d9b(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82167b:	mulsd  -0x771844(%rip),%xmm11        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821684:	ucomisd %xmm4,%xmm11
  821689:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82168f:	movapd 0x60(%rsp),%xmm2
  821695:	subsd  %xmm4,%xmm2
  821699:	ucomisd %xmm2,%xmm11
  82169e:	movsd  0x180(%rsp),%xmm3
  8216a7:	movsd  0xc0(%rsp),%xmm4
  8216b0:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8216b6:	addsd  %xmm7,%xmm3
  8216ba:	addsd  0x120(%rsp),%xmm3
  8216c3:	subsd  0x50(%rsp),%xmm3
  8216c9:	addsd  %xmm5,%xmm4
  8216cd:	addsd  0x110(%rsp),%xmm4
  8216d6:	addsd  0x40(%rsp),%xmm4
  8216dc:	addsd  0x30(%rsp),%xmm4
  8216e2:	addsd  -0x771e0a(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8216ea:	mulsd  -0x771e92(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8216f2:	addsd  0x10(%rsp),%xmm4
  8216f8:	ucomisd %xmm3,%xmm4
  8216fc:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821702:	movapd 0x20(%rsp),%xmm2
  821708:	subsd  %xmm3,%xmm2
  82170c:	ucomisd %xmm2,%xmm4
  821710:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821716:	movapd 0x170(%rsp),%xmm3
  82171f:	addsd  %xmm6,%xmm3
  821723:	addsd  0xf0(%rsp),%xmm3
  82172c:	subsd  0x50(%rsp),%xmm3
  821732:	addsd  %xmm1,%xmm0
  821736:	addsd  0x100(%rsp),%xmm0
  82173f:	addsd  0x40(%rsp),%xmm0
  821745:	addsd  0x30(%rsp),%xmm0
  82174b:	addsd  -0x771e73(%rip),%xmm0        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821753:	mulsd  -0x77191b(%rip),%xmm0        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82175b:	ucomisd %xmm3,%xmm0
  82175f:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821765:	movapd 0x20(%rsp),%xmm1
  82176b:	subsd  %xmm3,%xmm1
  82176f:	ucomisd %xmm1,%xmm0
  821773:	jb     820d15 <<gpui_gpu::renderer::RendererState>::bin_draw+0x635>
  821779:	jmp    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82177e:	movsd  0x8(%rsp),%xmm12
  821785:	jmp    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82178a:	nopw   0x0(%rax,%rax,1)
  821790:	mov    0x1a8(%rsp),%r10
  821798:	cmp    %r10,0x1c0(%rsp)
  8217a0:	mov    0x1b0(%rsp),%rbp
  8217a8:	mov    0x1b8(%rsp),%rax
  8217b0:	jae    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8217b6:	mov    %rax,%r14
  8217b9:	cmp    %r10,%rax
  8217bc:	jbe    820c10 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  8217c2:	jmp    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8217c7:	nopw   0x0(%rax,%rax,1)
  8217d0:	mov    %r14,%rax
  8217d3:	cmp    %r10,%r14
  8217d6:	adc    $0x0,%r14
  8217da:	mov    %rax,%rcx
  8217dd:	imul   %r13,%rcx
  8217e1:	mov    %rbp,%rdx
  8217e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  8217f0:	lea    (%rdx,%rcx,1),%r12
  8217f4:	cmp    %r9,%r12
  8217f7:	jae    821835 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  8217f9:	cmp    %rbx,%rdx
  8217fc:	mov    %rdx,%rsi
  8217ff:	adc    $0x0,%rsi
  821803:	mov    0x4(%r15,%r12,8),%edi
  821808:	inc    %edi
  82180a:	and    $0xbfffffff,%edi
  821810:	mov    %edi,0x4(%r15,%r12,8)
  821815:	cmp    %rbx,%rdx
  821818:	jae    821822 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1142>
  82181a:	mov    %rsi,%rdx
  82181d:	cmp    %rbx,%rsi
  821820:	jbe    8217f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1110>
  821822:	cmp    %r10,%rax
  821825:	jae    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82182b:	cmp    %r10,%r14
  82182e:	jbe    8217d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  821830:	jmp    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  821835:	lea    0x60df2c(%rip),%rdx        # e2f768 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  82183c:	mov    %r12,%rdi
  82183f:	mov    %r9,%rsi
  821842:	call   *0x65f918(%rip)        # e81160 <_DYNAMIC+0x4f8>
  821848:	lea    0x60e021(%rip),%rdi        # e2f870 <anon.93049d86f4da36fb5b5cebb14659314f.39.llvm.2397904706780205377>
  82184f:	call   *0x65fa7b(%rip)        # e812d0 <_DYNAMIC+0x668>
  821855:	lea    0x60def4(%rip),%rdx        # e2f750 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  82185c:	mov    %r12,%rdi
  82185f:	mov    %r9,%rsi
  821862:	call   *0x65f8f8(%rip)        # e81160 <_DYNAMIC+0x4f8>
  821868:	lea    0x60df29(%rip),%rdx        # e2f798 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x110>
  82186f:	mov    %r12,%rdi
  821872:	mov    0xd8(%rsp),%rsi
  82187a:	call   *0x65f8e0(%rip)        # e81160 <_DYNAMIC+0x4f8>
  821880:	lea    0x60def9(%rip),%rdx        # e2f780 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf8>
  821887:	mov    %r12,%rdi
  82188a:	mov    %r9,%rsi
  82188d:	call   *0x65f8cd(%rip)        # e81160 <_DYNAMIC+0x4f8>
