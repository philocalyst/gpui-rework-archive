# Fused normalization counter proof

Base is exact299c6aca30c1245c15c2da6a5ccabb41dd435d17. Only the host
normalization/counter placement changes. The complete later diagnostic walk
and its now-unused TILE_END host constant are removed. Shader, range ABI,
record writers, validation, resource preparation, reverse fill, logical caps,
packet revocation and Stats publication remain unchanged.

Before normalization, c is the retained forward count, k the constant bit,
and p = cursor!=0 the covered-opaque cutoff flag. If p && c==1, the original
direct-uniform case remains exactly the same: retain the draw address, write
UNIFORM_TILE, increment uniform count and contribute zero sampled entries or
evaluations. Otherwise normalization reserves c reference slots and writes
exactly the same tagged end/start pair. The unchanged reverse fill decrements
start once per retained reference, so its eventual end-start equals c. Reverse
resource patching does not alter count/end/proof tags. Therefore the old final
walk expression is exactly available at normalization:
 s = clipped_area * (constant ?1:16);
 samples += s;
 sources += clipped_area*p + s*(c-p).
For c==0 it contributes zero. A nonuniform p case has c>=2; an opaque cutoff
starts count1 and only later retained visits can increase it. No subtraction
can underflow. Geometry/source predicates and reference admission are untouched.

Ranges and cursors were both initialized to columns*rows. Width/height are
nonzero, at most16384 each and at most16M pixels before chunks are constructed.
The zipped outer chunks therefore cover every row exactly once; zipped inner
slices cover every column exactly once. Integer row/column origins are16*y/x;
min(16,height-origin_y)*min(16,width-origin_x) is exactly tile_bounds' clipped
area, including every partial last row/column, without per-tile division/mod.
All index casts and products are inside the admitted dimensions. Per-reference
area*16 <=4096; the existing4,194,304 reference cap bounds aggregate source work
by17,179,869,184, so counts convert to u64 before multiplication. The unchanged
u32 offset cap stays below the tag bits.

Counters remain locals and are published only in the existing successful
submission Stats assignment. Moving their calculation before reverse fill does
not publish anything on prepare/tone-map/resource failure or panic. No new
field, allocation, dependency, shader branch, source-kind exception, identity
witness or scalar/SIMD policy is introduced. The same Rust kernel serves both
feature modes. Earlier counter lifetimes, row-loop code, spills, static frames
and full linked size must all be charged from actual generated code; no speed,
line-count, memory or stack improvement is presumed.

An independent35x19 public SDR/HDR fixture uses explicit tile-sized clips to
bound Canvas' conservative one-pixel AABB guard. It checks known empty/full/
3x3-corner-uniform/partial-first-tile counts and exact sampled/proved pixels.
The initial fixture omitted those clips and incorrectly expected geometric
bounds to equal actual visit bounds; its exit101/log is retained. No production
source changed to repair that fixture. Existing partial edges, maximum extent,
opaque/constant/order/bank/mask/image/rounded/admission/HDR cases remain in the
full suites. The original52 public readbacks and complete Stats/ImageStats must
match the frozen299c reference, and a deliberately wrong retained-count term
must fail the independent counter assertion before exact recovery.
