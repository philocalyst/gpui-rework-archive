from pathlib import Path
root=Path('/tmp/gpui-csr-stats-sol/reactivity/crates/gpu')
p=root/'src/renderer.rs';s=p.read_text()
s=s.replace('const TILE_END: u32 = OPAQUE_PREFIX - 1;\n','',1)
a=s.index('        let mut offset = 0;');b=s.index('        let references = offset as usize;',a)
s=s[:a]+'''        let mut offset = 0;
        let mut uniform_tiles = 0;
        let mut sample_evaluations = 0;
        let mut sample_draw_evaluations = 0;
        for (row, (ranges, cursors)) in self
            .ranges
            .chunks_mut(columns)
            .zip(self.cursors.chunks(columns))
            .enumerate()
        {
            let height = (scene.height - row as u32 * 16).min(16);
            for (column, (range, &cursor)) in ranges.iter_mut().zip(cursors).enumerate() {
                let constant = range[1] & CONSTANT_TILE;
                let count = range[1] & !CONSTANT_TILE;
                let prefix = cursor != 0;
                if prefix && count == 1 {
                    range[1] = UNIFORM_TILE;
                    uniform_tiles += 1;
                } else {
                    if count != 0 {
                        let area = u64::from(height * (scene.width - column as u32 * 16).min(16));
                        let samples = area * if constant != 0 { 1 } else { 16 };
                        let prefix = u64::from(prefix);
                        // Reverse filling moves start by exactly this retained
                        // count; neither the end nor the proof tags change.
                        sample_evaluations += samples;
                        sample_draw_evaluations +=
                            area * prefix + samples * (u64::from(count) - prefix);
                    }
                    offset += count;
                    *range = [offset, offset | constant | if prefix { OPAQUE_PREFIX } else { 0 }];
                }
            }
        }
''' +s[b:]
a=s.index('        let mut uniform_tiles = 0;',s.index('        debug_assert_eq!((word, reverse_ordinal)'))
b=s.index('        let (tone, exposure)',a)
s=s[:a]+s[b:];p.write_text(s)
p=root/'tests/render.rs';s=p.read_text();s+='''
#[test]
fn tile_work_counters_use_clipped_areas_and_exact_survivors() {
    pollster::block_on(async {
        for hdr in [false, true] {
            let format = if hdr {
                wgpu::TextureFormat::Rgba16Float
            } else {
                wgpu::TextureFormat::Rgba8UnormSrgb
            };
            let config = if hdr {
                ColorConfig::linear_hdr(gpui_canvas::OutputProfile::DisplayP3, 203.0).unwrap()
            } else {
                ColorConfig::default()
            };
            let mut gpu = renderer(format).await;
            let mut canvas = Canvas::recording(35, 19, config).unwrap();
            canvas.clear(Color::WHITE);
            let viewport = Rect::new(0.0, 0.0, 35.0, 19.0);
            // Six tiles cover 665 pixels. The last tile is only 3 by 3;
            // a partial draw in the first tile later forces 256 sampled pixels.
            for (stage, (original, references, uniform, samples, sources, sampled_sources)) in [
                (0, 0, 0, 0, 0, 0),
                (6, 6, 0, 665, 665, 10_640),
                (7, 5, 1, 656, 656, 10_784),
                (8, 6, 1, 4_496, 8_592, 14_880),
            ]
            .into_iter()
            .enumerate()
            {
                if stage == 1 {
                    canvas
                        .fill_rect(viewport, Affine::IDENTITY, viewport, Color::rgba(10, 20, 30, 128))
                        .unwrap();
                } else if stage == 2 {
                    canvas
                        .fill_rect(
                            Rect::new(32.0, 16.0, 3.0, 3.0),
                            Affine::IDENTITY,
                            viewport,
                            Color::rgb(70, 90, 120),
                        )
                        .unwrap();
                } else if stage == 3 {
                    canvas
                        .fill_rect(
                            Rect::new(0.375, 0.375, 15.25, 15.25),
                            Affine::IDENTITY,
                            viewport,
                            Color::rgba(80, 160, 20, 90),
                        )
                        .unwrap();
                }
                gpu.set_tile_proofs(false);
                let reference = readback(&mut gpu, &canvas);
                let sampled = gpu.stats();
                assert_eq!(sampled.sample_evaluations, if stage == 0 { 0 } else { 10_640 });
                assert_eq!(sampled.sample_draw_evaluations, sampled_sources);
                assert_eq!(sampled.tile_references, original);
                gpu.set_tile_proofs(true);
                assert_eq!(readback(&mut gpu, &canvas), reference, "HDR={hdr}, stage={stage}");
                let stats = gpu.stats();
                assert_eq!(stats.original_tile_references, original);
                assert_eq!(stats.tile_references, references);
                assert_eq!(stats.uniform_tiles, uniform);
                assert_eq!(stats.sample_evaluations, samples);
                assert_eq!(stats.sample_draw_evaluations, sources);
            }
        }
    });
}
''';p.write_text(s)
