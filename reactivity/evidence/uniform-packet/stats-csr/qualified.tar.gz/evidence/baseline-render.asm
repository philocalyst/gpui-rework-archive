
FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9520 frame=1448

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e020 <<gpui_gpu::renderer::RendererState>::render>:
  81e020:	push   %rbp
  81e021:	push   %r15
  81e023:	push   %r14
  81e025:	push   %r13
  81e027:	push   %r12
  81e029:	push   %rbx
  81e02a:	sub    $0x578,%rsp
  81e031:	mov    0x228(%rsi),%rax
  81e038:	mov    0x18(%rdx),%r9
  81e03c:	cmp    %r9,%rax
  81e03f:	je     81e05d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e041:	mov    0x10(%rax),%r10
  81e045:	cmp    0x10(%r9),%r10
  81e049:	jne    81e12b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e04f:	mov    0x18(%rax),%rax
  81e053:	cmp    0x18(%r9),%rax
  81e057:	jne    81e12b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e05d:	lea    0x330(%rsi),%rbx
  81e064:	mov    0x330(%rsi),%rax
  81e06b:	test   %rax,%rax
  81e06e:	je     81e09d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e070:	lock decq (%rax)
  81e074:	jne    81e09d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e076:	mov    %rdi,%r14
  81e079:	mov    %rbx,%rdi
  81e07c:	mov    %rsi,%r12
  81e07f:	mov    %r8,%r13
  81e082:	mov    %rdx,%r15
  81e085:	mov    %rcx,%rbp
  81e088:	call   *0x6630a2(%rip)        # e81130 <_DYNAMIC+0x518>
  81e08e:	mov    %rbp,%rcx
  81e091:	mov    %r15,%rdx
  81e094:	mov    %r13,%r8
  81e097:	mov    %r12,%rsi
  81e09a:	mov    %r14,%rdi
  81e09d:	movq   $0x0,0x330(%rsi)
  81e0a8:	mov    (%rcx),%r13d
  81e0ab:	mov    0x8(%rcx),%r9d
  81e0af:	movzbl 0xd(%rcx),%eax
  81e0b3:	test   %r9d,%r9d
  81e0b6:	sets   %r10b
  81e0ba:	and    $0x7fffffff,%r9d
  81e0c1:	lea    -0x800000(%r9),%r11d
  81e0c8:	cmp    $0x7f000000,%r11d
  81e0cf:	setb   %r11b
  81e0d3:	and    %r10b,%r11b
  81e0d6:	lea    -0x1(%r9),%ebp
  81e0da:	cmp    $0x7fffff,%ebp
  81e0e0:	setb   %bpl
  81e0e4:	and    %r10b,%bpl
  81e0e7:	test   %r9d,%r9d
  81e0ea:	sete   %r10b
  81e0ee:	cmp    $0x7f800000,%r9d
  81e0f5:	sete   %r14b
  81e0f9:	or     %r10b,%r14b
  81e0fc:	cmp    $0x7f800001,%r9d
  81e103:	setge  %r9b
  81e107:	or     %r14b,%r9b
  81e10a:	or     %bpl,%r9b
  81e10d:	test   %r13d,%r13d
  81e110:	setne  %r10b
  81e114:	and    %al,%r10b
  81e117:	or     %r11b,%r10b
  81e11a:	or     %r9b,%r10b
  81e11d:	test   $0x1,%r10b
  81e121:	je     81e146 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e123:	movl   $0x3,(%rdi)
  81e129:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e12b:	movl   $0x4,(%rdi)
  81e131:	mov    %rdi,%rax
  81e134:	add    $0x578,%rsp
  81e13b:	pop    %rbx
  81e13c:	pop    %r12
  81e13e:	pop    %r13
  81e140:	pop    %r14
  81e142:	pop    %r15
  81e144:	pop    %rbp
  81e145:	ret
  81e146:	movd   0x4(%rcx),%xmm2
  81e14b:	movzbl 0xc(%rcx),%ebp
  81e14f:	test   $0x1,%r13b
  81e153:	je     81e1cb <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e155:	movd   %xmm2,%r9d
  81e15a:	test   %r9d,%r9d
  81e15d:	sets   %r10b
  81e161:	and    $0x7fffffff,%r9d
  81e168:	lea    -0x800000(%r9),%r11d
  81e16f:	cmp    $0x7f000000,%r11d
  81e176:	setb   %r11b
  81e17a:	and    %r10b,%r11b
  81e17d:	lea    -0x1(%r9),%r14d
  81e181:	cmp    $0x7fffff,%r14d
  81e188:	setb   %r14b
  81e18c:	and    %r10b,%r14b
  81e18f:	test   %r9d,%r9d
  81e192:	sete   %r10b
  81e196:	cmp    $0x7f800000,%r9d
  81e19d:	sete   %r15b
  81e1a1:	or     %r10b,%r15b
  81e1a4:	cmp    $0x7f800001,%r9d
  81e1ab:	setge  %r9b
  81e1af:	or     %r15b,%r9b
  81e1b2:	or     %r14b,%r9b
  81e1b5:	or     %r11b,%r9b
  81e1b8:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1be:	ucomiss -0x76f2b9(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e1c5:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1cb:	mov    0x28(%rcx),%r14d
  81e1cf:	cmp    %r14d,0x20(%r8)
  81e1d3:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1d9:	mov    0x2c(%rcx),%r15d
  81e1dd:	cmp    %r15d,0x24(%r8)
  81e1e1:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1e7:	mov    0x38(%r8),%r12d
  81e1eb:	cmp    0x20(%rdx),%r12d
  81e1ef:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1f5:	cmp    $0x4c,%r12d
  81e1f9:	jne    81e21e <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e1fb:	movq   0x3c(%r8),%xmm0
  81e201:	movq   0x24(%rdx),%xmm1
  81e206:	pcmpeqd %xmm0,%xmm1
  81e20a:	pshufd $0x50,%xmm1,%xmm0
  81e20f:	movmskpd %xmm0,%r9d
  81e214:	cmp    $0x3,%r9d
  81e218:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e21e:	cmp    $0x4000,%r15d
  81e225:	ja     81e25b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e227:	cmp    $0x4000,%r14d
  81e22e:	ja     81e25b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e230:	mov    %r15,%r9
  81e233:	imul   %r14,%r9
  81e237:	add    $0xfffffffffeffffff,%r9
  81e23e:	cmp    $0xffffffffff000000,%r9
  81e245:	jb     81e25b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e247:	mov    0x10(%rcx),%r11
  81e24b:	mov    0x80(%r11),%r10
  81e252:	cmp    $0x10000,%r10
  81e259:	jbe    81e266 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e25b:	movl   $0x6,(%rdi)
  81e261:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e266:	movd   0x18(%rcx),%xmm0
  81e26b:	movd   %xmm0,%r9d
  81e270:	and    $0x7fffffff,%r9d
  81e277:	cmp    $0x7f7fffff,%r9d
  81e27e:	jg     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e284:	pand   -0x770a9c(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e28c:	ucomiss -0x76f12f(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e293:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e299:	movd   0x1c(%rcx),%xmm0
  81e29e:	movd   %xmm0,%r9d
  81e2a3:	and    $0x7fffffff,%r9d
  81e2aa:	cmp    $0x7f7fffff,%r9d
  81e2b1:	jg     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2b7:	pand   -0x770acf(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e2bf:	ucomiss -0x76f162(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e2c6:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2cc:	movd   0x20(%rcx),%xmm0
  81e2d1:	movd   %xmm0,%r9d
  81e2d6:	and    $0x7fffffff,%r9d
  81e2dd:	cmp    $0x7f7fffff,%r9d
  81e2e4:	jg     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ea:	pand   -0x770b02(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e2f2:	ucomiss -0x76f195(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e2f9:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ff:	movd   0x24(%rcx),%xmm0
  81e304:	movd   %xmm0,%r9d
  81e309:	and    $0x7fffffff,%r9d
  81e310:	cmp    $0x7f7fffff,%r9d
  81e317:	jg     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e31d:	movdqa -0x770b35(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e325:	pand   %xmm0,%xmm1
  81e329:	ucomiss -0x76f1cc(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e330:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e336:	xorps  %xmm1,%xmm1
  81e339:	ucomiss %xmm1,%xmm0
  81e33c:	jb     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e342:	movss  -0x76f56a(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e34a:	ucomiss %xmm0,%xmm1
  81e34d:	jb     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e353:	movzwl 0x30(%rcx),%r9d
  81e358:	mov    %r9w,0x10(%rsp)
  81e35e:	movzwl 0x32(%rcx),%r9d
  81e363:	mov    %r9w,0x18(%rsp)
  81e369:	cmp    $0x28,%r12d
  81e36d:	jne    81e379 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e36f:	test   $0x1,%al
  81e371:	je     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e377:	jmp    81e394 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e379:	test   $0x1,%al
  81e37b:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e381:	ucomiss -0x76f5a8(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e388:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e38e:	jp     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e394:	mov    %r11,0x28(%rsp)
  81e399:	mov    %r10,0x60(%rsp)
  81e39e:	movss  %xmm1,0xe0(%rsp)
  81e3a7:	movd   %xmm2,0x280(%rsp)
  81e3b0:	mov    %rdx,0x110(%rsp)
  81e3b8:	mov    %r8,0x470(%rsp)
  81e3c0:	mov    %rdi,0x58(%rsp)
  81e3c5:	lea    0xf(%r14),%rax
  81e3c9:	shr    $0x4,%rax
  81e3cd:	lea    0xf(%r15),%r8d
  81e3d1:	shr    $0x4,%r8d
  81e3d5:	lea    0x18(%rsi),%rdi
  81e3d9:	movq   $0x0,0x28(%rsi)
  81e3e1:	mov    %rax,0x38(%rsp)
  81e3e6:	imul   %eax,%r8d
  81e3ea:	movabs $0x4000000000000000,%rdx
  81e3f4:	mov    %rdi,0x480(%rsp)
  81e3fc:	mov    %rsi,0x8(%rsp)
  81e401:	mov    %r8,0x30(%rsp)
  81e406:	mov    %r8,%rsi
  81e409:	mov    %rcx,0x118(%rsp)
  81e411:	call   8237a0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e416:	mov    0x8(%rsp),%rax
  81e41b:	movq   $0x0,0x10(%rax)
  81e423:	mov    0x118(%rsp),%rdi
  81e42b:	call   *0x662d8f(%rip)        # e811c0 <_DYNAMIC+0x5a8>
  81e431:	mov    %rdx,%rcx
  81e434:	sub    %rax,%rcx
  81e437:	cmp    $0x300000,%rcx
  81e43e:	jbe    81e450 <<gpui_gpu::renderer::RendererState>::render+0x430>
  81e440:	mov    0x58(%rsp),%rdi
  81e445:	movl   $0x6,(%rdi)
  81e44b:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e450:	mov    %rcx,%rdi
  81e453:	shr    $0x3,%rcx
  81e457:	movabs $0xaaaaaaaaaaaaaaab,%rsi
  81e461:	imul   %rcx,%rsi
  81e465:	mov    %rsi,0x20(%rsp)
  81e46a:	mov    %rax,0x468(%rsp)
  81e472:	mov    %rdx,0x460(%rsp)
  81e47a:	cmp    %rax,%rdx
  81e47d:	je     81e4ab <<gpui_gpu::renderer::RendererState>::render+0x48b>
  81e47f:	mov    $0xaaaaaaab,%eax
  81e484:	imul   %rax,%rdi
  81e488:	shr    $0x2a,%rdi
  81e48c:	mov    0x20(%rsp),%rcx
  81e491:	mov    %ecx,%eax
  81e493:	and    $0x3f,%eax
  81e496:	add    %rcx,%rdi
  81e499:	cmp    $0x1,%rax
  81e49d:	sbb    $0xffffffffffffffff,%rdi
  81e4a1:	inc    %rdi
  81e4a4:	mov    %rdi,0x40(%rsp)
  81e4a9:	jmp    81e4b4 <<gpui_gpu::renderer::RendererState>::render+0x494>
  81e4ab:	movq   $0x0,0x40(%rsp)
  81e4b4:	mov    0x28(%rsp),%rax
  81e4b9:	mov    0x98(%rax),%rcx
  81e4c0:	add    0xb0(%rax),%rcx
  81e4c7:	mov    %rax,0x120(%rsp)
  81e4cf:	movzwl 0x10(%rsp),%eax
  81e4d4:	mov    %ax,0x140(%rsp)
  81e4dc:	movzwl 0x18(%rsp),%eax
  81e4e1:	mov    %ax,0x142(%rsp)
  81e4e9:	movq   $0x0,0x128(%rsp)
  81e4f5:	mov    0x60(%rsp),%rax
  81e4fa:	mov    %rax,0x130(%rsp)
  81e502:	mov    %rcx,0x328(%rsp)
  81e50a:	mov    %rcx,0x138(%rsp)
  81e512:	mov    0x8(%rsp),%rax
  81e517:	movzbl 0x341(%rax),%edx
  81e51e:	lea    0x488(%rsp),%rdi
  81e526:	lea    0x120(%rsp),%rsi
  81e52e:	call   81c770 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e533:	mov    0x488(%rsp),%eax
  81e53a:	cmp    $0xffffffff,%eax
  81e53d:	je     81e56f <<gpui_gpu::renderer::RendererState>::render+0x54f>
  81e53f:	mov    0x48c(%rsp),%ecx
  81e546:	mov    0x490(%rsp),%rdx
  81e54e:	movdqu 0x498(%rsp),%xmm0
  81e557:	mov    0x58(%rsp),%rdi
  81e55c:	movdqu %xmm0,0x10(%rdi)
  81e561:	mov    %eax,(%rdi)
  81e563:	mov    %ecx,0x4(%rdi)
  81e566:	mov    %rdx,0x8(%rdi)
  81e56a:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e56f:	mov    0x40(%rsp),%rdx
  81e574:	add    0x490(%rsp),%rdx
  81e57c:	mov    0x8(%rsp),%rdi
  81e581:	mov    0x10(%rdi),%rsi
  81e585:	mov    $0x4,%ecx
  81e58a:	mov    $0x10,%r8d
  81e590:	call   827010 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e595:	cmp    $0xffffffffffffffff,%rax
  81e599:	jne    81e440 <<gpui_gpu::renderer::RendererState>::render+0x420>
  81e59f:	movzwl 0x10(%rsp),%eax
  81e5a4:	mov    %eax,0x10(%rsp)
  81e5a8:	movzwl 0x18(%rsp),%eax
  81e5ad:	mov    %eax,0xac(%rsp)
  81e5b4:	mov    0x8(%rsp),%rdi
  81e5b9:	mov    0x118(%rsp),%rsi
  81e5c1:	mov    0x20(%rsp),%rdx
  81e5c6:	call   825520 <gpui_gpu::renderer::slots::write_prefix>
  81e5cb:	mov    0x8(%rsp),%rax
  81e5d0:	lea    0x48(%rax),%rdi
  81e5d4:	movq   $0x0,0x58(%rax)
  81e5dc:	mov    %rdi,0x478(%rsp)
  81e5e4:	mov    0x30(%rsp),%rsi
  81e5e9:	xor    %edx,%edx
  81e5eb:	call   8238c0 <<alloc::vec::Vec<u32>>::resize>
  81e5f0:	mov    0x8(%rsp),%rax
  81e5f5:	movq   $0x0,0x70(%rax)
  81e5fd:	cmpq   $0x0,0x60(%rax)
  81e602:	jne    81e613 <<gpui_gpu::renderer::RendererState>::render+0x5f3>
  81e604:	mov    0x8(%rsp),%rax
  81e609:	lea    0x60(%rax),%rdi
  81e60d:	call   *0x662bb5(%rip)        # e811c8 <_DYNAMIC+0x5b0>
  81e613:	mov    0x8(%rsp),%rax
  81e618:	mov    0x68(%rax),%rcx
  81e61c:	pxor   %xmm0,%xmm0
  81e620:	movdqu %xmm0,0x10(%rcx)
  81e625:	movdqu %xmm0,(%rcx)
  81e629:	movq   $0x1,0x70(%rax)
  81e631:	lea    0x2f8(%rax),%rdi
  81e638:	call   8231f0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e63d:	mov    0xac(%rsp),%ecx
  81e644:	shl    $0x10,%ecx
  81e647:	add    0x10(%rsp),%ecx
  81e64b:	mov    0x28(%rsp),%rax
  81e650:	mov    %rax,0x338(%rsp)
  81e658:	movq   $0x0,0x340(%rsp)
  81e664:	mov    0x60(%rsp),%rax
  81e669:	mov    %rax,0x348(%rsp)
  81e671:	mov    0x328(%rsp),%rax
  81e679:	mov    %rax,0x350(%rsp)
  81e681:	mov    %ecx,0xac(%rsp)
  81e688:	mov    %ecx,0x358(%rsp)
  81e68f:	lea    0x288(%rsp),%rdi
  81e697:	lea    0x338(%rsp),%rsi
  81e69f:	call   *0x662b2b(%rip)        # e811d0 <_DYNAMIC+0x5b8>
  81e6a5:	mov    0x288(%rsp),%rax
  81e6ad:	mov    %rax,0x18(%rsp)
  81e6b2:	test   %rax,%rax
  81e6b5:	je     81f427 <<gpui_gpu::renderer::RendererState>::render+0x1407>
  81e6bb:	movq   $0x0,0xc8(%rsp)
  81e6c7:	movq   $0x0,0x10(%rsp)
  81e6d0:	movq   $0x0,0x70(%rsp)
  81e6d9:	movq   $0x0,0x248(%rsp)
  81e6e5:	movq   $0x0,0x250(%rsp)
  81e6f1:	mov    0x290(%rsp),%rcx
  81e6f9:	mov    0x298(%rsp),%rdx
  81e701:	mov    %rdx,0xd0(%rsp)
  81e709:	lea    0x2a0(%rsp),%rdi
  81e711:	movups (%rdi),%xmm0
  81e714:	movups 0x10(%rdi),%xmm1
  81e718:	movups 0x20(%rdi),%xmm2
  81e71c:	movaps %xmm2,0x310(%rsp)
  81e724:	movaps %xmm1,0x300(%rsp)
  81e72c:	movaps %xmm0,0x2f0(%rsp)
  81e734:	lea    0x2d0(%rsp),%r8
  81e73c:	movups (%r8),%xmm0
  81e740:	movaps %xmm0,0x450(%rsp)
  81e748:	movups 0x40(%rdi),%xmm0
  81e74c:	movaps %xmm0,0x380(%rsp)
  81e754:	mov    0x8(%rsp),%rax
  81e759:	movzbl 0x341(%rax),%esi
  81e760:	mov    0x18(%rsp),%rax
  81e765:	mov    %rax,0x120(%rsp)
  81e76d:	mov    %rcx,0x30(%rsp)
  81e772:	mov    %rcx,0x128(%rsp)
  81e77a:	mov    %rdx,0x130(%rsp)
  81e782:	movups (%rdi),%xmm0
  81e785:	movups 0x10(%rdi),%xmm1
  81e789:	movups 0x20(%rdi),%xmm2
  81e78d:	lea    0x138(%rsp),%rax
  81e795:	movups %xmm2,0x20(%rax)
  81e799:	movups %xmm1,0x10(%rax)
  81e79d:	movups %xmm0,(%rax)
  81e7a0:	movups (%r8),%xmm0
  81e7a4:	movups %xmm0,0x30(%rax)
  81e7a8:	movups 0x40(%rdi),%xmm0
  81e7ac:	movups %xmm0,0x40(%rax)
  81e7b0:	lea    0x120(%rsp),%rdi
  81e7b8:	call   821710 <gpui_gpu::renderer::compact_group>
  81e7bd:	mov    %al,0x40(%rsp)
  81e7c1:	lea    0x2a0(%rsp),%rsi
  81e7c9:	movups (%rsi),%xmm0
  81e7cc:	movups 0x10(%rsi),%xmm1
  81e7d0:	movups 0x20(%rsi),%xmm2
  81e7d4:	movaps %xmm0,0x530(%rsp)
  81e7dc:	movaps %xmm1,0x540(%rsp)
  81e7e4:	movaps %xmm2,0x550(%rsp)
  81e7ec:	lea    0x2d0(%rsp),%rdx
  81e7f4:	movdqu (%rdx),%xmm0
  81e7f8:	movdqa %xmm0,0x560(%rsp)
  81e801:	mov    0x8(%rsp),%rdi
  81e806:	call   81d3a0 <<gpui_gpu::renderer::RendererState>::correction>
  81e80b:	mov    %eax,0xc0(%rsp)
  81e812:	mov    0xd0(%rsp),%rax
  81e81a:	lea    0x0(,%rax,4),%rax
  81e822:	mov    %rax,0x258(%rsp)
  81e82a:	cmpb   $0x0,0x40(%rsp)
  81e82f:	je     81ea20 <<gpui_gpu::renderer::RendererState>::render+0xa00>
  81e835:	mov    0x30(%rsp),%rcx
  81e83a:	mov    0xd0(%rsp),%rax
  81e842:	lea    (%rcx,%rax,4),%rax
  81e846:	mov    %rcx,0x430(%rsp)
  81e84e:	mov    %rax,0x438(%rsp)
  81e856:	mov    0x18(%rsp),%rax
  81e85b:	mov    %rax,0x440(%rsp)
  81e863:	movq   $0x0,0x448(%rsp)
  81e86f:	lea    0x390(%rsp),%rdi
  81e877:	lea    0x430(%rsp),%rsi
  81e87f:	call   821da0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e884:	cmpb   $0xff,0x398(%rsp)
  81e88c:	je     81ef70 <<gpui_gpu::renderer::RendererState>::render+0xf50>
  81e892:	pxor   %xmm0,%xmm0
  81e896:	movdqa %xmm0,0xb0(%rsp)
  81e89f:	movdqa %xmm0,0x80(%rsp)
  81e8a8:	mov    0x390(%rsp),%rdx
  81e8b0:	add    0x70(%rsp),%rdx
  81e8b5:	lea    0x398(%rsp),%rsi
  81e8bd:	movups 0x38(%rsi),%xmm0
  81e8c1:	lea    0x121(%rsp),%rax
  81e8c9:	movups %xmm0,0x37(%rax)
  81e8cd:	movups 0x48(%rsi),%xmm0
  81e8d1:	lea    0x138(%rsp),%rcx
  81e8d9:	movups %xmm0,0x70(%rcx)
  81e8dd:	mov    0x30(%rsi),%rax
  81e8e1:	mov    %rax,0x150(%rsp)
  81e8e9:	movups (%rsi),%xmm0
  81e8ec:	movups 0x10(%rsi),%xmm1
  81e8f0:	movups 0x20(%rsi),%xmm2
  81e8f4:	movaps %xmm2,0x140(%rsp)
  81e8fc:	movaps %xmm1,0x130(%rsp)
  81e904:	movaps %xmm0,0x120(%rsp)
  81e90c:	lea    0x2a0(%rsp),%rax
  81e914:	movups 0x40(%rax),%xmm0
  81e918:	movups %xmm0,0x80(%rcx)
  81e91f:	movups (%rax),%xmm0
  81e922:	movups 0x10(%rax),%xmm1
  81e926:	movups 0x20(%rax),%xmm2
  81e92a:	movups %xmm2,0x50(%rcx)
  81e92e:	movups %xmm1,0x40(%rcx)
  81e932:	movups %xmm0,0x30(%rcx)
  81e936:	lea    0x2d0(%rsp),%rax
  81e93e:	movups (%rax),%xmm0
  81e941:	movups %xmm0,0x60(%rcx)
  81e945:	lea    0x360(%rsp),%rdi
  81e94d:	lea    0x120(%rsp),%rsi
  81e955:	mov    %r14d,%ecx
  81e958:	mov    %r15d,%r8d
  81e95b:	call   821760 <gpui_gpu::renderer::validate_draw>
  81e960:	mov    0x360(%rsp),%ecx
  81e967:	mov    0x364(%rsp),%rax
  81e96f:	cmp    $0xffffffff,%ecx
  81e972:	jne    81f4df <<gpui_gpu::renderer::RendererState>::render+0x14bf>
  81e978:	mov    %eax,%ecx
  81e97a:	shr    $0x20,%rax
  81e97e:	movd   %ecx,%xmm0
  81e982:	movaps 0xb0(%rsp),%xmm2
  81e98a:	movaps %xmm2,%xmm1
  81e98d:	maxss  %xmm0,%xmm1
  81e991:	movaps %xmm1,%xmm3
  81e994:	cmpunordss %xmm1,%xmm3
  81e999:	movaps %xmm3,%xmm0
  81e99c:	andnps %xmm1,%xmm0
  81e99f:	andps  %xmm2,%xmm3
  81e9a2:	orps   %xmm0,%xmm3
  81e9a5:	movaps %xmm3,0x40(%rsp)
  81e9aa:	movd   %eax,%xmm0
  81e9ae:	movaps 0x80(%rsp),%xmm2
  81e9b6:	movaps %xmm2,%xmm1
  81e9b9:	maxss  %xmm0,%xmm1
  81e9bd:	movaps %xmm1,%xmm3
  81e9c0:	cmpunordss %xmm1,%xmm3
  81e9c5:	movaps %xmm3,%xmm0
  81e9c8:	andnps %xmm1,%xmm0
  81e9cb:	andps  %xmm2,%xmm3
  81e9ce:	orps   %xmm0,%xmm3
  81e9d1:	movaps %xmm3,0x90(%rsp)
  81e9d9:	lea    0x390(%rsp),%rdi
  81e9e1:	lea    0x430(%rsp),%rsi
  81e9e9:	call   821da0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e9ee:	cmpb   $0xff,0x398(%rsp)
  81e9f6:	movaps 0x40(%rsp),%xmm0
  81e9fb:	movaps %xmm0,0xb0(%rsp)
  81ea03:	movdqa 0x90(%rsp),%xmm0
  81ea0c:	movdqa %xmm0,0x80(%rsp)
  81ea15:	jne    81e8a8 <<gpui_gpu::renderer::RendererState>::render+0x888>
  81ea1b:	jmp    81ef83 <<gpui_gpu::renderer::RendererState>::render+0xf63>
  81ea20:	cmpq   $0x0,0xd0(%rsp)
  81ea29:	je     81f3d1 <<gpui_gpu::renderer::RendererState>::render+0x13b1>
  81ea2f:	mov    0xc0(%rsp),%eax
  81ea36:	or     $0x80000000,%eax
  81ea3b:	mov    %eax,0x27c(%rsp)
  81ea42:	movq   $0x0,0x90(%rsp)
  81ea4e:	mov    0x30(%rsp),%rax
  81ea53:	mov    0x90(%rsp),%rcx
  81ea5b:	mov    (%rax,%rcx,1),%edx
  81ea5e:	lea    0x120(%rsp),%rdi
  81ea66:	mov    0x18(%rsp),%rsi
  81ea6b:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81ea70:	movzbl 0x120(%rsp),%edi
  81ea78:	lea    0x121(%rsp),%rdx
  81ea80:	mov    (%rdx),%eax
  81ea82:	mov    0x3(%rdx),%ecx
  81ea85:	lea    0x4c0(%rsp),%rsi
  81ea8d:	mov    %ecx,-0x34(%rsi)
  81ea90:	mov    %eax,-0x37(%rsi)
  81ea93:	mov    0x128(%rsp),%rcx
  81ea9b:	mov    0x2f(%rdx),%rax
  81ea9f:	mov    %rax,-0x8(%rsi)
  81eaa3:	movups 0xf(%rdx),%xmm0
  81eaa7:	movups 0x1f(%rdx),%xmm1
  81eaab:	movups %xmm1,-0x18(%rsi)
  81eaaf:	movups %xmm0,-0x28(%rsi)
  81eab3:	movups 0x37(%rdx),%xmm0
  81eab7:	movups %xmm0,(%rsi)
  81eaba:	lea    0x138(%rsp),%rax
  81eac2:	movups 0x30(%rax),%xmm0
  81eac6:	movups %xmm0,0x50(%rsi)
  81eaca:	lea    0x2a0(%rsp),%rax
  81ead2:	movups 0x40(%rax),%xmm0
  81ead6:	movups %xmm0,0x60(%rsi)
  81eada:	movups (%rax),%xmm0
  81eadd:	movups 0x10(%rax),%xmm1
  81eae1:	movups 0x20(%rax),%xmm2
  81eae5:	movups %xmm2,0x30(%rsi)
  81eae9:	movups %xmm1,0x20(%rsi)
  81eaed:	movups %xmm0,0x10(%rsi)
  81eaf1:	lea    0x2d0(%rsp),%rax
  81eaf9:	movups (%rax),%xmm0
  81eafc:	movups %xmm0,0x40(%rsi)
  81eb00:	mov    %dil,0x80(%rsp)
  81eb08:	mov    %dil,0x488(%rsp)
  81eb10:	mov    %rcx,0xb0(%rsp)
  81eb18:	mov    %rcx,0x490(%rsp)
  81eb20:	lea    0x120(%rsp),%rdi
  81eb28:	lea    0x488(%rsp),%rsi
  81eb30:	mov    0x70(%rsp),%rdx
  81eb35:	mov    %r14d,%ecx
  81eb38:	mov    %r15d,%r8d
  81eb3b:	call   821760 <gpui_gpu::renderer::validate_draw>
  81eb40:	mov    0x120(%rsp),%eax
  81eb47:	mov    0x124(%rsp),%rcx
  81eb4f:	mov    %rcx,0x40(%rsp)
  81eb54:	cmp    $0xffffffff,%eax
  81eb57:	jne    81f573 <<gpui_gpu::renderer::RendererState>::render+0x1553>
  81eb5d:	movzbl 0x80(%rsp),%eax
  81eb65:	cmp    $0x2,%al
  81eb67:	sete   0x260(%rsp)
  81eb6f:	cmpq   $0x0,0xb0(%rsp)
  81eb78:	setne  0x108(%rsp)
  81eb80:	movups 0x4c0(%rsp),%xmm0
  81eb88:	movaps %xmm0,0x230(%rsp)
  81eb90:	cmp    $0x3,%al
  81eb92:	jne    81ec27 <<gpui_gpu::renderer::RendererState>::render+0xc07>
  81eb98:	movss  0x48c(%rsp),%xmm0
  81eba1:	xorps  %xmm1,%xmm1
  81eba4:	ucomiss %xmm1,%xmm0
  81eba7:	jne    81ebab <<gpui_gpu::renderer::RendererState>::render+0xb8b>
  81eba9:	jnp    81ec27 <<gpui_gpu::renderer::RendererState>::render+0xc07>
  81ebab:	movaps 0x230(%rsp),%xmm5
  81ebb3:	movaps %xmm5,%xmm1
  81ebb6:	unpckhpd %xmm5,%xmm1
  81ebba:	movss  -0x76fbf6(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ebc2:	mulss  %xmm4,%xmm1
  81ebc6:	movaps %xmm0,%xmm2
  81ebc9:	minss  %xmm1,%xmm2
  81ebcd:	movaps %xmm2,%xmm1
  81ebd0:	cmpunordss %xmm2,%xmm1
  81ebd5:	movaps %xmm1,%xmm3
  81ebd8:	andnps %xmm2,%xmm3
  81ebdb:	andps  %xmm0,%xmm1
  81ebde:	orps   %xmm3,%xmm1
  81ebe1:	movaps %xmm5,%xmm0
  81ebe4:	shufps $0xff,%xmm5,%xmm0
  81ebe8:	mulss  %xmm4,%xmm0
  81ebec:	movaps %xmm1,%xmm2
  81ebef:	minss  %xmm0,%xmm2
  81ebf3:	movaps %xmm2,%xmm0
  81ebf6:	cmpunordss %xmm2,%xmm0
  81ebfb:	andps  %xmm0,%xmm1
  81ebfe:	andnps %xmm2,%xmm0
  81ec01:	orps   %xmm1,%xmm0
  81ec04:	movd   %xmm0,%eax
  81ec08:	mov    %eax,0x80(%rsp)
  81ec0f:	and    $0xff800000,%eax
  81ec14:	mov    $0x7f000000,%ecx
  81ec19:	sub    %eax,%ecx
  81ec1b:	mov    %ecx,0xb0(%rsp)
  81ec22:	xorps  %xmm0,%xmm0
  81ec25:	jmp    81ec4c <<gpui_gpu::renderer::RendererState>::render+0xc2c>
  81ec27:	mov    0x520(%rsp),%eax
  81ec2e:	mov    %eax,0x80(%rsp)
  81ec35:	mov    0x524(%rsp),%eax
  81ec3c:	mov    %eax,0xb0(%rsp)
  81ec43:	movsd  0x528(%rsp),%xmm0
  81ec4c:	movaps %xmm0,0xf0(%rsp)
  81ec54:	mov    0x8(%rsp),%rax
  81ec59:	mov    0x10(%rax),%ecx
  81ec5c:	mov    $0x80000000,%eax
  81ec61:	or     %eax,%ecx
  81ec63:	mov    %ecx,0x220(%rsp)
  81ec6a:	movups 0x4d0(%rsp),%xmm0
  81ec72:	movaps %xmm0,0x420(%rsp)
  81ec7a:	movups 0x4d8(%rsp),%xmm0
  81ec82:	movaps %xmm0,0x400(%rsp)
  81ec8a:	movsd  0x4e0(%rsp),%xmm0
  81ec93:	movaps %xmm0,0x410(%rsp)
  81ec9b:	movsd  0x4e8(%rsp),%xmm0
  81eca4:	movaps %xmm0,0x3f0(%rsp)
  81ecac:	movsd  0x4f0(%rsp),%xmm0
  81ecb5:	movsd  %xmm0,0x270(%rsp)
  81ecbe:	movsd  0x4f8(%rsp),%xmm0
  81ecc7:	movsd  %xmm0,0x268(%rsp)
  81ecd0:	movups 0x500(%rsp),%xmm0
  81ecd8:	movaps %xmm0,0x210(%rsp)
  81ece0:	mov    0x18(%rsp),%rax
  81ece5:	mov    %rax,0x120(%rsp)
  81eced:	mov    0x30(%rsp),%rax
  81ecf2:	mov    %rax,0x128(%rsp)
  81ecfa:	mov    0xd0(%rsp),%rax
  81ed02:	mov    %rax,0x130(%rsp)
  81ed0a:	movaps 0x2f0(%rsp),%xmm0
  81ed12:	movaps 0x300(%rsp),%xmm1
  81ed1a:	movaps 0x310(%rsp),%xmm2
  81ed22:	lea    0x138(%rsp),%rax
  81ed2a:	movups %xmm2,0x20(%rax)
  81ed2e:	movups %xmm1,0x10(%rax)
  81ed32:	movups %xmm0,(%rax)
  81ed35:	movaps 0x450(%rsp),%xmm0
  81ed3d:	movups %xmm0,0x30(%rax)
  81ed41:	movaps 0x380(%rsp),%xmm0
  81ed49:	movups %xmm0,0x40(%rax)
  81ed4d:	lea    0x120(%rsp),%rdi
  81ed55:	call   *0x66247d(%rip)        # e811d8 <_DYNAMIC+0x5c0>
  81ed5b:	mov    0xc0(%rsp),%ecx
  81ed62:	mov    %ecx,0x68(%rsp)
  81ed66:	test   %eax,%eax
  81ed68:	je     81ed9e <<gpui_gpu::renderer::RendererState>::render+0xd7e>
  81ed6a:	mov    0x20(%rsp),%rdi
  81ed6f:	mov    %eax,%esi
  81ed71:	call   8254e0 <gpui_gpu::renderer::slots::color_word>
  81ed76:	mov    %eax,0x80(%rsp)
  81ed7d:	xorps  %xmm0,%xmm0
  81ed80:	movaps %xmm0,0xf0(%rsp)
  81ed88:	movl   $0x0,0xb0(%rsp)
  81ed93:	mov    0x27c(%rsp),%eax
  81ed9a:	mov    %eax,0x68(%rsp)
  81ed9e:	mov    0x40(%rsp),%rax
  81eda3:	shr    $0x20,%rax
  81eda7:	mov    %rax,0x78(%rsp)
  81edac:	mov    0x8(%rsp),%rax
  81edb1:	mov    (%rax),%rcx
  81edb4:	mov    0x10(%rax),%rsi
  81edb8:	sub    %rsi,%rcx
  81edbb:	cmp    $0x5,%rcx
  81edbf:	jbe    81ef48 <<gpui_gpu::renderer::RendererState>::render+0xf28>
  81edc5:	movsd  0x268(%rsp),%xmm0
  81edce:	cvtsd2ss %xmm0,%xmm0
  81edd2:	movsd  0x270(%rsp),%xmm1
  81eddb:	cvtsd2ss %xmm1,%xmm1
  81eddf:	movapd 0x400(%rsp),%xmm2
  81ede8:	unpcklpd 0x3f0(%rsp),%xmm2
  81edf1:	cvtpd2ps %xmm2,%xmm2
  81edf5:	movapd 0x420(%rsp),%xmm3
  81edfe:	unpcklpd 0x410(%rsp),%xmm3
  81ee07:	cvtpd2ps %xmm3,%xmm3
  81ee0b:	mov    0x8(%rsp),%rax
  81ee10:	mov    0x8(%rax),%rdx
  81ee14:	shl    $0x4,%rsi
  81ee18:	movaps 0x230(%rsp),%xmm4
  81ee20:	movups %xmm4,(%rdx,%rsi,1)
  81ee24:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ee2a:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ee30:	mov    0x40(%rsp),%rcx
  81ee35:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ee39:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ee3f:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81ee45:	mov    0x78(%rsp),%rdi
  81ee4a:	mov    %edi,0x2c(%rdx,%rsi,1)
  81ee4e:	movaps 0x210(%rsp),%xmm0
  81ee56:	movups %xmm0,0x30(%rdx,%rsi,1)
  81ee5b:	mov    0x80(%rsp),%edi
  81ee62:	mov    %edi,0x40(%rdx,%rsi,1)
  81ee66:	mov    0xb0(%rsp),%edi
  81ee6d:	mov    %edi,0x44(%rdx,%rsi,1)
  81ee71:	movdqa 0xf0(%rsp),%xmm0
  81ee7a:	movq   %xmm0,0x48(%rdx,%rsi,1)
  81ee80:	movq   $0x0,0x50(%rdx,%rsi,1)
  81ee89:	movl   $0x0,0x58(%rdx,%rsi,1)
  81ee91:	mov    0x68(%rsp),%edi
  81ee95:	mov    %edi,0x5c(%rdx,%rsi,1)
  81ee99:	addq   $0x6,0x10(%rax)
  81ee9e:	lea    0x120(%rsp),%rdi
  81eea6:	mov    %rax,%rsi
  81eea9:	lea    0x488(%rsp),%rdx
  81eeb1:	mov    0x220(%rsp),%r8d
  81eeb9:	mov    0x70(%rsp),%r9
  81eebe:	push   0xc8(%rsp)
  81eec5:	push   %r15
  81eec7:	push   %r14
  81eec9:	push   0x50(%rsp)
  81eecd:	call   820550 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81eed2:	add    $0x20,%rsp
  81eed6:	mov    0x120(%rsp),%eax
  81eedd:	cmp    $0xffffffff,%eax
  81eee0:	jne    81f53a <<gpui_gpu::renderer::RendererState>::render+0x151a>
  81eee6:	movzbl 0x260(%rsp),%ecx
  81eeee:	and    0x108(%rsp),%cl
  81eef5:	mov    0x10(%rsp),%rax
  81eefa:	or     %cl,%al
  81eefc:	mov    %rax,0x10(%rsp)
  81ef01:	mov    0x128(%rsp),%rax
  81ef09:	mov    %rax,0xc8(%rsp)
  81ef11:	incq   0x70(%rsp)
  81ef16:	mov    0x90(%rsp),%rdx
  81ef1e:	add    $0x4,%rdx
  81ef22:	mov    0xd0(%rsp),%rax
  81ef2a:	lea    0x0(,%rax,4),%rax
  81ef32:	mov    %rdx,0x90(%rsp)
  81ef3a:	cmp    %rdx,%rax
  81ef3d:	jne    81ea4e <<gpui_gpu::renderer::RendererState>::render+0xa2e>
  81ef43:	jmp    81f3c5 <<gpui_gpu::renderer::RendererState>::render+0x13a5>
  81ef48:	mov    $0x6,%edx
  81ef4d:	mov    $0x4,%ecx
  81ef52:	mov    $0x10,%r8d
  81ef58:	mov    0x8(%rsp),%rdi
  81ef5d:	call   826f80 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81ef62:	mov    0x8(%rsp),%rax
  81ef67:	mov    0x10(%rax),%rsi
  81ef6b:	jmp    81edc5 <<gpui_gpu::renderer::RendererState>::render+0xda5>
  81ef70:	pxor   %xmm0,%xmm0
  81ef74:	movdqa %xmm0,0x90(%rsp)
  81ef7d:	movdqa %xmm0,0x40(%rsp)
  81ef83:	mov    0x8(%rsp),%rax
  81ef88:	mov    0x10(%rax),%eax
  81ef8b:	mov    %eax,0xf0(%rsp)
  81ef92:	movups 0x2a0(%rsp),%xmm1
  81ef9a:	movups 0x2a8(%rsp),%xmm2
  81efa2:	movsd  0x2c0(%rsp),%xmm0
  81efab:	movsd  %xmm0,0x68(%rsp)
  81efb1:	movsd  0x2c8(%rsp),%xmm0
  81efba:	movsd  %xmm0,0x230(%rsp)
  81efc3:	movups 0x2d0(%rsp),%xmm0
  81efcb:	movaps %xmm0,0xb0(%rsp)
  81efd3:	movhps 0x2b0(%rsp),%xmm1
  81efdb:	movaps %xmm1,0x220(%rsp)
  81efe3:	movups 0x2e0(%rsp),%xmm0
  81efeb:	movaps %xmm0,0x80(%rsp)
  81eff3:	movhps 0x2b8(%rsp),%xmm2
  81effb:	movaps %xmm2,0x210(%rsp)
  81f003:	mov    0x18(%rsp),%rax
  81f008:	mov    %rax,0x120(%rsp)
  81f010:	mov    0x30(%rsp),%rax
  81f015:	mov    %rax,0x128(%rsp)
  81f01d:	mov    0xd0(%rsp),%rax
  81f025:	mov    %rax,0x130(%rsp)
  81f02d:	lea    0x2a0(%rsp),%rax
  81f035:	movups (%rax),%xmm0
  81f038:	movups 0x10(%rax),%xmm1
  81f03c:	movups 0x20(%rax),%xmm2
  81f040:	lea    0x138(%rsp),%rdx
  81f048:	movups %xmm2,0x20(%rdx)
  81f04c:	movups %xmm1,0x10(%rdx)
  81f050:	movups %xmm0,(%rdx)
  81f053:	lea    0x2d0(%rsp),%rcx
  81f05b:	movups (%rcx),%xmm0
  81f05e:	movups %xmm0,0x30(%rdx)
  81f062:	movdqu 0x40(%rax),%xmm0
  81f067:	movdqu %xmm0,0x40(%rdx)
  81f06c:	lea    0x120(%rsp),%rdi
  81f074:	call   *0x66215e(%rip)        # e811d8 <_DYNAMIC+0x5c0>
  81f07a:	test   %eax,%eax
  81f07c:	je     81f0a2 <<gpui_gpu::renderer::RendererState>::render+0x1082>
  81f07e:	mov    0x20(%rsp),%rdi
  81f083:	mov    %eax,%esi
  81f085:	call   8254e0 <gpui_gpu::renderer::slots::color_word>
  81f08a:	orl    $0x80000000,0xc0(%rsp)
  81f095:	movd   %eax,%xmm0
  81f099:	movdqa %xmm0,0x80(%rsp)
  81f0a2:	mov    0x8(%rsp),%rax
  81f0a7:	mov    (%rax),%rcx
  81f0aa:	mov    0x10(%rax),%rsi
  81f0ae:	sub    %rsi,%rcx
  81f0b1:	cmp    $0x4,%rcx
  81f0b5:	jbe    81f3ff <<gpui_gpu::renderer::RendererState>::render+0x13df>
  81f0bb:	cvtpd2ps 0x220(%rsp),%xmm0
  81f0c4:	cvtpd2ps 0x210(%rsp),%xmm1
  81f0cd:	movsd  0x68(%rsp),%xmm2
  81f0d3:	cvtsd2ss %xmm2,%xmm2
  81f0d7:	movsd  0x230(%rsp),%xmm3
  81f0e0:	cvtsd2ss %xmm3,%xmm3
  81f0e4:	mov    0x8(%rsp),%rax
  81f0e9:	mov    0x8(%rax),%rcx
  81f0ed:	shl    $0x4,%rsi
  81f0f1:	movlpd %xmm0,(%rcx,%rsi,1)
  81f0f6:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f0fc:	movaps 0x40(%rsp),%xmm0
  81f101:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f107:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f10d:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f113:	movaps 0x90(%rsp),%xmm0
  81f11b:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f121:	movaps 0xb0(%rsp),%xmm0
  81f129:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f12e:	movdqa 0x80(%rsp),%xmm0
  81f137:	movdqu %xmm0,0x30(%rcx,%rsi,1)
  81f13d:	mov    0xc0(%rsp),%edx
  81f144:	mov    %edx,0x40(%rcx,%rsi,1)
  81f148:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f151:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f159:	addq   $0x5,0x10(%rax)
  81f15e:	incq   0x248(%rsp)
  81f166:	mov    0xd0(%rsp),%rax
  81f16e:	add    %rax,0x250(%rsp)
  81f176:	test   %rax,%rax
  81f179:	je     81f3d1 <<gpui_gpu::renderer::RendererState>::render+0x13b1>
  81f17f:	movdqa 0x40(%rsp),%xmm0
  81f185:	movd   %xmm0,%ecx
  81f189:	movdqa 0x90(%rsp),%xmm0
  81f192:	movd   %xmm0,%eax
  81f196:	shl    $0x20,%rax
  81f19a:	or     %rax,%rcx
  81f19d:	mov    %rcx,0x68(%rsp)
  81f1a2:	movq   $0x0,0x40(%rsp)
  81f1ab:	mov    0x30(%rsp),%rax
  81f1b0:	mov    0x40(%rsp),%rcx
  81f1b5:	mov    (%rax,%rcx,1),%edx
  81f1b8:	lea    0x390(%rsp),%rdi
  81f1c0:	mov    0x18(%rsp),%rsi
  81f1c5:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f1ca:	movzbl 0x390(%rsp),%edi
  81f1d2:	lea    0x398(%rsp),%rsi
  81f1da:	mov    -0x7(%rsi),%eax
  81f1dd:	mov    -0x4(%rsi),%ecx
  81f1e0:	lea    0x121(%rsp),%rdx
  81f1e8:	mov    %ecx,0x3(%rdx)
  81f1eb:	mov    %eax,(%rdx)
  81f1ed:	mov    0x398(%rsp),%rcx
  81f1f5:	mov    0x28(%rsi),%rax
  81f1f9:	mov    %rax,0x2f(%rdx)
  81f1fd:	movups 0x8(%rsi),%xmm0
  81f201:	movups 0x18(%rsi),%xmm1
  81f205:	movups %xmm1,0x1f(%rdx)
  81f209:	movups %xmm0,0xf(%rdx)
  81f20d:	movups 0x3c8(%rsp),%xmm1
  81f215:	movups 0x40(%rsi),%xmm0
  81f219:	lea    0x138(%rsp),%rax
  81f221:	movups %xmm0,0x70(%rax)
  81f225:	movaps 0x380(%rsp),%xmm0
  81f22d:	movups %xmm0,0x80(%rax)
  81f234:	movaps %xmm1,0xd0(%rsp)
  81f23c:	movups %xmm1,0x158(%rsp)
  81f244:	movaps 0x530(%rsp),%xmm0
  81f24c:	movaps 0x540(%rsp),%xmm1
  81f254:	movapd 0x550(%rsp),%xmm2
  81f25d:	movupd %xmm2,0x50(%rax)
  81f262:	movups %xmm1,0x40(%rax)
  81f266:	movups %xmm0,0x30(%rax)
  81f26a:	movaps 0x560(%rsp),%xmm0
  81f272:	movups %xmm0,0x60(%rax)
  81f276:	mov    %dil,0x80(%rsp)
  81f27e:	mov    %dil,0x120(%rsp)
  81f286:	mov    %rcx,0xb0(%rsp)
  81f28e:	mov    %rcx,0x128(%rsp)
  81f296:	mov    0x8(%rsp),%rax
  81f29b:	mov    (%rax),%rcx
  81f29e:	mov    0x10(%rax),%rax
  81f2a2:	sub    %rax,%rcx
  81f2a5:	mov    %rax,0x90(%rsp)
  81f2ad:	cmp    $0x1,%rcx
  81f2b1:	jbe    81f395 <<gpui_gpu::renderer::RendererState>::render+0x1375>
  81f2b7:	mov    0x8(%rsp),%rsi
  81f2bc:	mov    0x8(%rsi),%rcx
  81f2c0:	shl    $0x4,%rax
  81f2c4:	movdqa 0xd0(%rsp),%xmm0
  81f2cd:	movdqu %xmm0,(%rcx,%rax,1)
  81f2d2:	movq   $0x0,0x10(%rcx,%rax,1)
  81f2db:	movl   $0x0,0x18(%rcx,%rax,1)
  81f2e3:	mov    0xf0(%rsp),%edx
  81f2ea:	mov    %edx,0x1c(%rcx,%rax,1)
  81f2ee:	addq   $0x2,0x10(%rsi)
  81f2f3:	lea    0x390(%rsp),%rdi
  81f2fb:	lea    0x120(%rsp),%rdx
  81f303:	mov    0x68(%rsp),%rcx
  81f308:	mov    0x90(%rsp),%r8
  81f310:	mov    0x70(%rsp),%r9
  81f315:	push   0xc8(%rsp)
  81f31c:	push   %r15
  81f31e:	push   %r14
  81f320:	push   0x50(%rsp)
  81f324:	call   820550 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f329:	add    $0x20,%rsp
  81f32d:	mov    0x390(%rsp),%eax
  81f334:	cmp    $0xffffffff,%eax
  81f337:	jne    81f557 <<gpui_gpu::renderer::RendererState>::render+0x1537>
  81f33d:	cmpb   $0x2,0x80(%rsp)
  81f345:	sete   %al
  81f348:	cmpq   $0x0,0xb0(%rsp)
  81f351:	setne  %cl
  81f354:	and    %al,%cl
  81f356:	mov    0x10(%rsp),%rax
  81f35b:	or     %cl,%al
  81f35d:	mov    %rax,0x10(%rsp)
  81f362:	mov    0x398(%rsp),%rax
  81f36a:	mov    %rax,0xc8(%rsp)
  81f372:	incq   0x70(%rsp)
  81f377:	mov    0x40(%rsp),%rcx
  81f37c:	add    $0x4,%rcx
  81f380:	mov    %rcx,0x40(%rsp)
  81f385:	cmp    %rcx,0x258(%rsp)
  81f38d:	jne    81f1ab <<gpui_gpu::renderer::RendererState>::render+0x118b>
  81f393:	jmp    81f3c5 <<gpui_gpu::renderer::RendererState>::render+0x13a5>
  81f395:	mov    $0x2,%edx
  81f39a:	mov    $0x4,%ecx
  81f39f:	mov    $0x10,%r8d
  81f3a5:	mov    0x8(%rsp),%rdi
  81f3aa:	mov    0x90(%rsp),%rsi
  81f3b2:	call   826f80 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f3b7:	mov    0x8(%rsp),%rax
  81f3bc:	mov    0x10(%rax),%rax
  81f3c0:	jmp    81f2b7 <<gpui_gpu::renderer::RendererState>::render+0x1297>
  81f3c5:	mov    0x10(%rsp),%rax
  81f3ca:	and    $0x1,%al
  81f3cc:	mov    %rax,0x10(%rsp)
  81f3d1:	lea    0x288(%rsp),%rdi
  81f3d9:	lea    0x338(%rsp),%rsi
  81f3e1:	call   *0x661de9(%rip)        # e811d0 <_DYNAMIC+0x5b8>
  81f3e7:	mov    0x288(%rsp),%rax
  81f3ef:	mov    %rax,0x18(%rsp)
  81f3f4:	test   %rax,%rax
  81f3f7:	jne    81e6f1 <<gpui_gpu::renderer::RendererState>::render+0x6d1>
  81f3fd:	jmp    81f45d <<gpui_gpu::renderer::RendererState>::render+0x143d>
  81f3ff:	mov    $0x5,%edx
  81f404:	mov    $0x4,%ecx
  81f409:	mov    $0x10,%r8d
  81f40f:	mov    0x8(%rsp),%rdi
  81f414:	call   826f80 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f419:	mov    0x8(%rsp),%rax
  81f41e:	mov    0x10(%rax),%rsi
  81f422:	jmp    81f0bb <<gpui_gpu::renderer::RendererState>::render+0x109b>
  81f427:	movq   $0x0,0x250(%rsp)
  81f433:	movq   $0x0,0x248(%rsp)
  81f43f:	movq   $0x0,0x70(%rsp)
  81f448:	movq   $0x0,0x10(%rsp)
  81f451:	movq   $0x0,0xc8(%rsp)
  81f45d:	mov    0x110(%rsp),%rsi
  81f465:	lea    0x8(%rsi),%rdx
  81f469:	mov    0x8(%rsp),%rax
  81f46e:	lea    0x258(%rax),%rcx
  81f475:	lea    0x328(%rax),%r8
  81f47c:	mov    0x10(%rax),%r9
  81f480:	sub    $0x8,%rsp
  81f484:	lea    0x128(%rsp),%rdi
  81f48c:	mov    %rdx,0xc8(%rsp)
  81f494:	mov    %rcx,0x110(%rsp)
  81f49c:	mov    %r8,0x278(%rsp)
  81f4a4:	push   0x120(%rsp)
  81f4ab:	call   823a10 <gpui_gpu::renderer::images::prepare>
  81f4b0:	add    $0x10,%rsp
  81f4b4:	cmpl   $0xffffffff,0x120(%rsp)
  81f4bc:	je     81f505 <<gpui_gpu::renderer::RendererState>::render+0x14e5>
  81f4be:	movups 0x120(%rsp),%xmm0
  81f4c6:	movups 0x130(%rsp),%xmm1
  81f4ce:	mov    0x58(%rsp),%rdi
  81f4d3:	movups %xmm1,0x10(%rdi)
  81f4d7:	movups %xmm0,(%rdi)
  81f4da:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f4df:	mov    0x37c(%rsp),%edx
  81f4e6:	mov    0x58(%rsp),%rdi
  81f4eb:	mov    %edx,0x1c(%rdi)
  81f4ee:	movups 0x36c(%rsp),%xmm0
  81f4f6:	movups %xmm0,0xc(%rdi)
  81f4fa:	mov    %ecx,(%rdi)
  81f4fc:	mov    %rax,0x4(%rdi)
  81f500:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f505:	movzbl 0x10(%rsp),%r8d
  81f50b:	and    $0x1,%r8d
  81f50f:	lea    0x120(%rsp),%rdi
  81f517:	mov    0x8(%rsp),%rsi
  81f51c:	mov    0x110(%rsp),%rdx
  81f524:	mov    0x28(%rsp),%rcx
  81f529:	call   81d780 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f52e:	mov    0x120(%rsp),%eax
  81f535:	cmp    $0xffffffff,%eax
  81f538:	je     81f59e <<gpui_gpu::renderer::RendererState>::render+0x157e>
  81f53a:	mov    0x124(%rsp),%ecx
  81f541:	mov    0x128(%rsp),%rdx
  81f549:	movdqu 0x130(%rsp),%xmm0
  81f552:	jmp    81e557 <<gpui_gpu::renderer::RendererState>::render+0x537>
  81f557:	mov    0x394(%rsp),%ecx
  81f55e:	mov    0x398(%rsp),%rdx
  81f566:	movups 0x3a0(%rsp),%xmm0
  81f56e:	jmp    81e557 <<gpui_gpu::renderer::RendererState>::render+0x537>
  81f573:	mov    0x13c(%rsp),%ecx
  81f57a:	mov    0x58(%rsp),%rdi
  81f57f:	mov    %ecx,0x1c(%rdi)
  81f582:	movups 0x12c(%rsp),%xmm0
  81f58a:	movups %xmm0,0xc(%rdi)
  81f58e:	mov    %eax,(%rdi)
  81f590:	mov    0x40(%rsp),%rax
  81f595:	mov    %rax,0x4(%rdi)
  81f599:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f59e:	mov    0x128(%rsp),%rax
  81f5a6:	mov    %rax,0x258(%rsp)
  81f5ae:	mov    0x8(%rsp),%rax
  81f5b3:	mov    0x28(%rax),%rax
  81f5b7:	movq   $0x0,0x78(%rsp)
  81f5c0:	test   %rax,%rax
  81f5c3:	je     81f65c <<gpui_gpu::renderer::RendererState>::render+0x163c>
  81f5c9:	mov    0x8(%rsp),%rcx
  81f5ce:	mov    0x20(%rcx),%rcx
  81f5d2:	shl    $0x3,%rax
  81f5d6:	xor    %edi,%edi
  81f5d8:	jmp    81f613 <<gpui_gpu::renderer::RendererState>::render+0x15f3>
  81f5da:	and    $0x40000000,%edx
  81f5e0:	mov    0x78(%rsp),%r9
  81f5e5:	add    %esi,%r9d
  81f5e8:	xor    %esi,%esi
  81f5ea:	test   %r8d,%r8d
  81f5ed:	setne  %sil
  81f5f1:	shl    $0x1d,%esi
  81f5f4:	or     %r9d,%edx
  81f5f7:	or     %esi,%edx
  81f5f9:	mov    %r9,0x78(%rsp)
  81f5fe:	mov    %r9d,(%rcx,%rdi,8)
  81f602:	mov    %edx,%r9d
  81f605:	mov    %r9d,0x4(%rcx,%rdi,8)
  81f60a:	inc    %rdi
  81f60d:	add    $0xfffffffffffffff8,%rax
  81f611:	je     81f650 <<gpui_gpu::renderer::RendererState>::render+0x1630>
  81f613:	mov    0x8(%rsp),%rdx
  81f618:	mov    0x58(%rdx),%rsi
  81f61c:	cmp    %rsi,%rdi
  81f61f:	jae    8204f3 <<gpui_gpu::renderer::RendererState>::render+0x24d3>
  81f625:	mov    0x4(%rcx,%rdi,8),%edx
  81f629:	mov    %edx,%esi
  81f62b:	and    $0xbfffffff,%esi
  81f631:	mov    0x8(%rsp),%r8
  81f636:	mov    0x50(%r8),%r8
  81f63a:	mov    (%r8,%rdi,4),%r8d
  81f63e:	cmp    $0x1,%esi
  81f641:	jne    81f5da <<gpui_gpu::renderer::RendererState>::render+0x15ba>
  81f643:	mov    $0x80000000,%r9d
  81f649:	test   %r8d,%r8d
  81f64c:	jne    81f605 <<gpui_gpu::renderer::RendererState>::render+0x15e5>
  81f64e:	jmp    81f5da <<gpui_gpu::renderer::RendererState>::render+0x15ba>
  81f650:	mov    0x78(%rsp),%rax
  81f655:	mov    %eax,%eax
  81f657:	mov    %rax,0x78(%rsp)
  81f65c:	mov    0x8(%rsp),%rax
  81f661:	lea    0x30(%rax),%rdi
  81f665:	movq   $0x0,0x40(%rax)
  81f66d:	mov    %rdi,0x3f0(%rsp)
  81f675:	mov    0x78(%rsp),%rsi
  81f67a:	xor    %edx,%edx
  81f67c:	call   8238c0 <<alloc::vec::Vec<u32>>::resize>
  81f681:	mov    0x8(%rsp),%rax
  81f686:	mov    0x10(%rax),%rax
  81f68a:	mov    %rax,0x20(%rsp)
  81f68f:	mov    0x70(%rsp),%rax
  81f694:	mov    %rax,0x330(%rsp)
  81f69c:	mov    0x28(%rsp),%rax
  81f6a1:	mov    %rax,0x338(%rsp)
  81f6a9:	movq   $0x0,0x340(%rsp)
  81f6b5:	mov    0x60(%rsp),%rax
  81f6ba:	mov    %rax,0x348(%rsp)
  81f6c2:	mov    0x328(%rsp),%rax
  81f6ca:	mov    %rax,0x350(%rsp)
  81f6d2:	mov    0xac(%rsp),%eax
  81f6d9:	mov    %eax,0x358(%rsp)
  81f6e0:	lea    0x288(%rsp),%rdi
  81f6e8:	lea    0x338(%rsp),%rsi
  81f6f0:	call   *0x661aea(%rip)        # e811e0 <_DYNAMIC+0x5c8>
  81f6f6:	mov    0x288(%rsp),%rax
  81f6fe:	mov    %rax,0x210(%rsp)
  81f706:	test   %rax,%rax
  81f709:	je     81fd43 <<gpui_gpu::renderer::RendererState>::render+0x1d23>
  81f70f:	mov    0x8(%rsp),%rax
  81f714:	add    $0x120,%rax
  81f71a:	mov    %rax,0x268(%rsp)
  81f722:	jmp    81f76d <<gpui_gpu::renderer::RendererState>::render+0x174d>
  81f724:	mov    0x20(%rsp),%rcx
  81f729:	lea    -0x5(%rcx),%rax
  81f72d:	cmpb   $0x0,0x220(%rsp)
  81f735:	cmovne %rax,%rcx
  81f739:	mov    %rcx,0x20(%rsp)
  81f73e:	lea    0x288(%rsp),%rdi
  81f746:	lea    0x338(%rsp),%rsi
  81f74e:	call   *0x661a8c(%rip)        # e811e0 <_DYNAMIC+0x5c8>
  81f754:	mov    0x288(%rsp),%rax
  81f75c:	mov    %rax,0x210(%rsp)
  81f764:	test   %rax,%rax
  81f767:	je     81fd43 <<gpui_gpu::renderer::RendererState>::render+0x1d23>
  81f76d:	mov    0x290(%rsp),%rdi
  81f775:	mov    0x298(%rsp),%r8
  81f77d:	mov    %r8,0x30(%rsp)
  81f782:	lea    0x2a0(%rsp),%rcx
  81f78a:	movups (%rcx),%xmm0
  81f78d:	movups 0x10(%rcx),%xmm1
  81f791:	movups 0x20(%rcx),%xmm2
  81f795:	movaps %xmm2,0x3b0(%rsp)
  81f79d:	movaps %xmm1,0x3a0(%rsp)
  81f7a5:	movaps %xmm0,0x390(%rsp)
  81f7ad:	lea    0x2d0(%rsp),%rdx
  81f7b5:	movups (%rdx),%xmm0
  81f7b8:	movaps %xmm0,0x450(%rsp)
  81f7c0:	movups 0x40(%rcx),%xmm0
  81f7c4:	movaps %xmm0,0x380(%rsp)
  81f7cc:	mov    0x8(%rsp),%rax
  81f7d1:	movzbl 0x341(%rax),%esi
  81f7d8:	mov    0x210(%rsp),%rax
  81f7e0:	mov    %rax,0x120(%rsp)
  81f7e8:	mov    %rdi,0x420(%rsp)
  81f7f0:	mov    %rdi,0x128(%rsp)
  81f7f8:	mov    %r8,0x130(%rsp)
  81f800:	movups (%rcx),%xmm0
  81f803:	movups 0x10(%rcx),%xmm1
  81f807:	movups 0x20(%rcx),%xmm2
  81f80b:	lea    0x138(%rsp),%rax
  81f813:	movups %xmm2,0x20(%rax)
  81f817:	movups %xmm1,0x10(%rax)
  81f81b:	movups %xmm0,(%rax)
  81f81e:	movups (%rdx),%xmm0
  81f821:	movups %xmm0,0x30(%rax)
  81f825:	movdqu 0x40(%rcx),%xmm0
  81f82a:	movdqu %xmm0,0x40(%rax)
  81f82f:	lea    0x120(%rsp),%rdi
  81f837:	call   821710 <gpui_gpu::renderer::compact_group>
  81f83c:	mov    %al,0x220(%rsp)
  81f843:	mov    0x30(%rsp),%rax
  81f848:	test   %rax,%rax
  81f84b:	je     81f724 <<gpui_gpu::renderer::RendererState>::render+0x1704>
  81f851:	mov    %rax,%rdx
  81f854:	shl    $0x2,%rdx
  81f858:	movzbl 0x220(%rsp),%eax
  81f860:	lea    0x0(,%rax,4),%esi
  81f867:	or     $0xfffffffffffffffa,%rsi
  81f86b:	xor    $0x1,%al
  81f86d:	movzbl %al,%eax
  81f870:	lea    0x1(,%rax,4),%rcx
  81f878:	mov    %rcx,0x260(%rsp)
  81f880:	mov    0x20(%rsp),%rcx
  81f885:	lea    (%rsi,%rcx,1),%edi
  81f888:	lea    (%rsi,%rax,4),%rax
  81f88c:	inc    %rax
  81f88f:	mov    %rax,0x410(%rsp)
  81f897:	add    %rax,%rcx
  81f89a:	shl    $0x4,%rcx
  81f89e:	mov    %rsi,0x40(%rsp)
  81f8a3:	shl    $0x4,%rsi
  81f8a7:	mov    %rsi,0x400(%rsp)
  81f8af:	mov    %rcx,0x18(%rsp)
  81f8b4:	mov    %edi,0x10(%rsp)
  81f8b8:	mov    0x420(%rsp),%rax
  81f8c0:	mov    %rdx,0x30(%rsp)
  81f8c5:	mov    -0x4(%rax,%rdx,1),%edx
  81f8c9:	lea    0x120(%rsp),%rdi
  81f8d1:	mov    0x210(%rsp),%rsi
  81f8d9:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f8de:	movzbl 0x120(%rsp),%ecx
  81f8e6:	movzbl 0x121(%rsp),%eax
  81f8ee:	mov    %al,0x60(%rsp)
  81f8f2:	movzwl 0x122(%rsp),%eax
  81f8fa:	mov    %ax,0x80(%rsp)
  81f902:	movss  0x124(%rsp),%xmm4
  81f90b:	lea    0x128(%rsp),%rdx
  81f913:	mov    0x10(%rdx),%rax
  81f917:	mov    %rax,0x370(%rsp)
  81f91f:	movups (%rdx),%xmm0
  81f922:	movaps %xmm0,0x360(%rsp)
  81f92a:	mov    0x140(%rsp),%rax
  81f932:	mov    %rax,0x28(%rsp)
  81f937:	mov    0x148(%rsp),%r10d
  81f93f:	mov    0x14c(%rsp),%r11d
  81f947:	movups 0x150(%rsp),%xmm0
  81f94f:	movaps %xmm0,0xb0(%rsp)
  81f957:	mov    0x150(%rsp),%rax
  81f95f:	movsd  0x160(%rsp),%xmm5
  81f968:	lea    0x138(%rsp),%rdx
  81f970:	movups 0x30(%rdx),%xmm0
  81f974:	movaps %xmm0,0x430(%rsp)
  81f97c:	decq   0x330(%rsp)
  81f984:	cmp    $0x1,%ecx
  81f987:	mov    %ecx,0xd0(%rsp)
  81f98e:	movaps %xmm5,0x90(%rsp)
  81f996:	je     81fa2c <<gpui_gpu::renderer::RendererState>::render+0x1a0c>
  81f99c:	mov    %r11d,0x68(%rsp)
  81f9a1:	mov    %r10d,0xf0(%rsp)
  81f9a9:	movaps %xmm4,0x230(%rsp)
  81f9b1:	cmp    $0x3,%ecx
  81f9b4:	jne    81faa9 <<gpui_gpu::renderer::RendererState>::render+0x1a89>
  81f9ba:	mov    0x270(%rsp),%rax
  81f9c2:	mov    (%rax),%rdi
  81f9c5:	test   %rdi,%rdi
  81f9c8:	je     8204c9 <<gpui_gpu::renderer::RendererState>::render+0x24a9>
  81f9ce:	movzbl 0x60(%rsp),%edx
  81f9d3:	mov    0x28(%rsp),%rsi
  81f9d8:	call   8236a0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f9dd:	mov    %eax,%ecx
  81f9df:	shr    $0x20,%rax
  81f9e3:	mov    %eax,%edx
  81f9e5:	or     $0x10,%edx
  81f9e8:	xorps  %xmm0,%xmm0
  81f9eb:	movaps 0x230(%rsp),%xmm4
  81f9f3:	ucomiss %xmm0,%xmm4
  81f9f6:	cmovne %edx,%eax
  81f9f9:	cmovp  %edx,%eax
  81f9fc:	mov    0x68(%rsp),%r11d
  81fa01:	mov    %r11d,%edx
  81fa04:	shl    $0x10,%edx
  81fa07:	mov    0xf0(%rsp),%r10d
  81fa0f:	or     %r10d,%edx
  81fa12:	mov    %ecx,0xe4(%rsp)
  81fa19:	mov    %eax,0xe8(%rsp)
  81fa20:	mov    %edx,0xec(%rsp)
  81fa27:	jmp    81fb5b <<gpui_gpu::renderer::RendererState>::render+0x1b3b>
  81fa2c:	movaps %xmm5,%xmm0
  81fa2f:	movss  -0x770a6b(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81fa37:	mulss  %xmm3,%xmm0
  81fa3b:	movaps %xmm4,%xmm1
  81fa3e:	minss  %xmm0,%xmm1
  81fa42:	movaps %xmm1,%xmm0
  81fa45:	cmpunordss %xmm1,%xmm0
  81fa4a:	movaps %xmm0,%xmm2
  81fa4d:	andnps %xmm1,%xmm2
  81fa50:	andps  %xmm4,%xmm0
  81fa53:	orps   %xmm2,%xmm0
  81fa56:	movaps %xmm5,%xmm1
  81fa59:	shufps $0x55,%xmm5,%xmm1
  81fa5d:	mulss  %xmm3,%xmm1
  81fa61:	movaps %xmm0,%xmm2
  81fa64:	minss  %xmm1,%xmm2
  81fa68:	movaps %xmm2,%xmm1
  81fa6b:	cmpunordss %xmm2,%xmm1
  81fa70:	andps  %xmm1,%xmm0
  81fa73:	andnps %xmm2,%xmm1
  81fa76:	orps   %xmm0,%xmm1
  81fa79:	movd   %xmm1,%eax
  81fa7d:	and    $0xff800000,%eax
  81fa82:	mov    $0x7f000000,%ecx
  81fa87:	sub    %eax,%ecx
  81fa89:	movl   $0x40000000,0xe4(%rsp)
  81fa94:	movss  %xmm1,0xe8(%rsp)
  81fa9d:	mov    %ecx,0xec(%rsp)
  81faa4:	jmp    81fb5b <<gpui_gpu::renderer::RendererState>::render+0x1b3b>
  81faa9:	cmp    $0x2,%cl
  81faac:	jne    81fafe <<gpui_gpu::renderer::RendererState>::render+0x1ade>
  81faae:	mov    0x370(%rsp),%rcx
  81fab6:	mov    %rcx,0x130(%rsp)
  81fabe:	movaps 0x360(%rsp),%xmm0
  81fac6:	movaps %xmm0,0x120(%rsp)
  81face:	mov    0x28(%rsp),%rcx
  81fad3:	mov    %rcx,0x138(%rsp)
  81fadb:	mov    0xf0(%rsp),%ecx
  81fae2:	mov    %ecx,0x140(%rsp)
  81fae9:	mov    0x68(%rsp),%ecx
  81faed:	mov    %ecx,0x144(%rsp)
  81faf4:	mov    %rax,0x148(%rsp)
  81fafc:	jmp    81fb0a <<gpui_gpu::renderer::RendererState>::render+0x1aea>
  81fafe:	movq   $0x0,0x120(%rsp)
  81fb0a:	movl   $0x0,0x2f8(%rsp)
  81fb15:	movq   $0x0,0x2f0(%rsp)
  81fb21:	lea    0xe4(%rsp),%rdi
  81fb29:	lea    0x120(%rsp),%rsi
  81fb31:	lea    0x2f0(%rsp),%rdx
  81fb39:	mov    0x268(%rsp),%rcx
  81fb41:	call   81b640 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fb46:	movaps 0x230(%rsp),%xmm4
  81fb4e:	mov    0xf0(%rsp),%r10d
  81fb56:	mov    0x68(%rsp),%r11d
  81fb5b:	mov    0x20(%rsp),%rdx
  81fb60:	mov    0x410(%rsp),%rax
  81fb68:	lea    (%rax,%rdx,1),%rcx
  81fb6c:	mov    0x8(%rsp),%rax
  81fb71:	mov    0x10(%rax),%rsi
  81fb75:	cmp    %rsi,%rcx
  81fb78:	lea    0x120(%rsp),%rdi
  81fb80:	mov    0x10(%rsp),%r8d
  81fb85:	mov    0x18(%rsp),%r9
  81fb8a:	movapd 0x90(%rsp),%xmm3
  81fb93:	jae    8204d6 <<gpui_gpu::renderer::RendererState>::render+0x24b6>
  81fb99:	add    0x40(%rsp),%rdx
  81fb9e:	mov    %rdx,0x20(%rsp)
  81fba3:	mov    0x8(%rax),%rax
  81fba7:	mov    0xec(%rsp),%ecx
  81fbae:	mov    %ecx,0x8(%rax,%r9,1)
  81fbb3:	mov    0xe4(%rsp),%rcx
  81fbbb:	mov    %r8d,%edx
  81fbbe:	or     $0x80000000,%edx
  81fbc4:	cmpb   $0x0,0x220(%rsp)
  81fbcc:	cmovne %r8d,%edx
  81fbd0:	mov    %rcx,(%rax,%r9,1)
  81fbd4:	mov    %edx,0x284(%rsp)
  81fbdb:	movaps 0x390(%rsp),%xmm0
  81fbe3:	movaps 0x3a0(%rsp),%xmm1
  81fbeb:	movaps 0x3b0(%rsp),%xmm2
  81fbf3:	lea    0x138(%rsp),%rax
  81fbfb:	movups %xmm2,0x50(%rax)
  81fbff:	movups %xmm1,0x40(%rax)
  81fc03:	movups %xmm0,0x30(%rax)
  81fc07:	movaps 0x450(%rsp),%xmm0
  81fc0f:	movups %xmm0,0x60(%rax)
  81fc13:	movaps 0x380(%rsp),%xmm0
  81fc1b:	movups %xmm0,0x80(%rax)
  81fc22:	movlpd %xmm3,0x160(%rsp)
  81fc2b:	movaps 0x430(%rsp),%xmm0
  81fc33:	movups %xmm0,0x70(%rax)
  81fc37:	mov    0xd0(%rsp),%eax
  81fc3e:	mov    %al,0x120(%rsp)
  81fc45:	movzbl 0x60(%rsp),%eax
  81fc4a:	mov    %al,0x121(%rsp)
  81fc51:	movzwl 0x80(%rsp),%eax
  81fc59:	mov    %ax,0x122(%rsp)
  81fc61:	movss  %xmm4,0x124(%rsp)
  81fc6a:	mov    0x370(%rsp),%rax
  81fc72:	lea    0x128(%rsp),%rcx
  81fc7a:	mov    %rax,0x10(%rcx)
  81fc7e:	movaps 0x360(%rsp),%xmm0
  81fc86:	movups %xmm0,(%rcx)
  81fc89:	mov    0x28(%rsp),%rax
  81fc8e:	mov    %rax,0x140(%rsp)
  81fc96:	mov    %r10d,0x148(%rsp)
  81fc9e:	mov    %r11d,0x14c(%rsp)
  81fca6:	movdqa 0xb0(%rsp),%xmm0
  81fcaf:	movdqu %xmm0,0x150(%rsp)
  81fcb8:	mov    0x480(%rsp),%rax
  81fcc0:	mov    %rax,0x2f0(%rsp)
  81fcc8:	mov    0x3f0(%rsp),%rax
  81fcd0:	mov    %rax,0x2f8(%rsp)
  81fcd8:	mov    0x478(%rsp),%rax
  81fce0:	mov    %rax,0x300(%rsp)
  81fce8:	lea    0x330(%rsp),%rax
  81fcf0:	mov    %rax,0x308(%rsp)
  81fcf8:	lea    0x284(%rsp),%rax
  81fd00:	mov    %rax,0x310(%rsp)
  81fd08:	mov    0x38(%rsp),%rsi
  81fd0d:	lea    0x2f0(%rsp),%rdx
  81fd15:	call   81c500 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81fd1a:	mov    0x18(%rsp),%rcx
  81fd1f:	mov    0x10(%rsp),%edi
  81fd23:	add    0x40(%rsp),%edi
  81fd27:	add    0x400(%rsp),%rcx
  81fd2f:	mov    0x30(%rsp),%rdx
  81fd34:	add    $0xfffffffffffffffc,%rdx
  81fd38:	jne    81f8af <<gpui_gpu::renderer::RendererState>::render+0x188f>
  81fd3e:	jmp    81f724 <<gpui_gpu::renderer::RendererState>::render+0x1704>
  81fd43:	mov    0x8(%rsp),%rax
  81fd48:	mov    0x28(%rax),%rdi
  81fd4c:	movq   $0x0,0x20(%rsp)
  81fd55:	test   %rdi,%rdi
  81fd58:	je     81fe69 <<gpui_gpu::renderer::RendererState>::render+0x1e49>
  81fd5e:	mov    0x8(%rsp),%rax
  81fd63:	mov    0x20(%rax),%rax
  81fd67:	mov    %rax,0x10(%rsp)
  81fd6c:	shl    $0x3,%rdi
  81fd70:	cmpl   $0x0,0x38(%rsp)
  81fd75:	je     820475 <<gpui_gpu::renderer::RendererState>::render+0x2455>
  81fd7b:	movq   $0x0,0x28(%rsp)
  81fd84:	movq   $0x0,0x60(%rsp)
  81fd8d:	movq   $0x0,0x18(%rsp)
  81fd96:	xor    %r10d,%r10d
  81fd99:	xor    %ecx,%ecx
  81fd9b:	jmp    81fdc0 <<gpui_gpu::renderer::RendererState>::render+0x1da0>
  81fd9d:	incq   0x18(%rsp)
  81fda2:	inc    %r10
  81fda5:	cmp    0x38(%rsp),%r10
  81fdaa:	mov    $0x0,%eax
  81fdaf:	cmove  %rax,%r10
  81fdb3:	inc    %rcx
  81fdb6:	add    $0xfffffffffffffff8,%rdi
  81fdba:	je     81fe84 <<gpui_gpu::renderer::RendererState>::render+0x1e64>
  81fdc0:	mov    0x10(%rsp),%rax
  81fdc5:	mov    0x4(%rax,%rcx,8),%r11d
  81fdca:	mov    $0x80000000,%eax
  81fdcf:	cmp    %rax,%r11
  81fdd2:	je     81fd9d <<gpui_gpu::renderer::RendererState>::render+0x1d7d>
  81fdd4:	mov    %r11d,%esi
  81fdd7:	and    $0x1fffffff,%esi
  81fddd:	mov    0x10(%rsp),%rax
  81fde2:	sub    (%rax,%rcx,8),%esi
  81fde5:	je     81fda2 <<gpui_gpu::renderer::RendererState>::render+0x1d82>
  81fde7:	mov    %rcx,%rax
  81fdea:	shr    $0x20,%rax
  81fdee:	je     81fdff <<gpui_gpu::renderer::RendererState>::render+0x1ddf>
  81fdf0:	mov    %rcx,%rax
  81fdf3:	xor    %edx,%edx
  81fdf5:	divq   0x38(%rsp)
  81fdfa:	mov    %r10,%rdx
  81fdfd:	jmp    81fe07 <<gpui_gpu::renderer::RendererState>::render+0x1de7>
  81fdff:	mov    %ecx,%eax
  81fe01:	xor    %edx,%edx
  81fe03:	divl   0x38(%rsp)
  81fe07:	shl    $0x4,%edx
  81fe0a:	shl    $0x4,%eax
  81fe0d:	lea    0x10(%rdx),%r8d
  81fe11:	cmp    %r8d,%r14d
  81fe14:	cmovb  %r14d,%r8d
  81fe18:	lea    0x10(%rax),%r9d
  81fe1c:	cmp    %r9d,%r15d
  81fe1f:	cmovb  %r15d,%r9d
  81fe23:	sub    %edx,%r8d
  81fe26:	sub    %eax,%r9d
  81fe29:	imul   %r8d,%r9d
  81fe2d:	mov    %r9,%rax
  81fe30:	shl    $0x4,%rax
  81fe34:	test   $0x40000000,%r11d
  81fe3b:	cmovne %r9,%rax
  81fe3f:	shr    $0x1d,%r11d
  81fe43:	and    $0x1,%r11d
  81fe47:	add    %rax,0x60(%rsp)
  81fe4c:	imul   %r11,%r9
  81fe50:	sub    %r11,%rsi
  81fe53:	imul   %rax,%rsi
  81fe57:	add    0x28(%rsp),%r9
  81fe5c:	add    %rsi,%r9
  81fe5f:	mov    %r9,0x28(%rsp)
  81fe64:	jmp    81fda2 <<gpui_gpu::renderer::RendererState>::render+0x1d82>
  81fe69:	movq   $0x0,0x18(%rsp)
  81fe72:	movq   $0x0,0x60(%rsp)
  81fe7b:	movq   $0x0,0x28(%rsp)
  81fe84:	test   $0x1,%r13b
  81fe88:	je     81feda <<gpui_gpu::renderer::RendererState>::render+0x1eba>
  81fe8a:	movd   0x280(%rsp),%xmm0
  81fe93:	movd   %xmm0,%eax
  81fe97:	test   %eax,%eax
  81fe99:	setns  %cl
  81fe9c:	mov    %eax,%edx
  81fe9e:	and    $0x7fffffff,%edx
  81fea4:	add    $0xff800000,%edx
  81feaa:	cmp    $0x7f000000,%edx
  81feb0:	setb   %dl
  81feb3:	and    %cl,%dl
  81feb5:	dec    %eax
  81feb7:	cmp    $0x7fffff,%eax
  81febc:	setb   %al
  81febf:	or     %dl,%al
  81fec1:	mov    $0x2,%eax
  81fec6:	mov    %rax,0x20(%rsp)
  81fecb:	movd   %xmm0,0xe0(%rsp)
  81fed4:	je     82046b <<gpui_gpu::renderer::RendererState>::render+0x244b>
  81feda:	mov    0x110(%rsp),%r13
  81fee2:	lea    0x18(%r13),%rax
  81fee6:	mov    %rax,0x30(%rsp)
  81feeb:	mov    0x118(%rsp),%rax
  81fef3:	add    $0x18,%rax
  81fef7:	xor    %ecx,%ecx
  81fef9:	cmp    $0x28,%r12d
  81fefd:	sete   %cl
  81ff00:	and    $0x1,%ebp
  81ff03:	lea    0x0(%rbp,%rcx,4),%ecx
  81ff07:	or     0x20(%rsp),%ecx
  81ff0b:	movups (%rax),%xmm0
  81ff0e:	movups %xmm0,0x298(%rsp)
  81ff16:	mov    %r14d,0x288(%rsp)
  81ff1e:	mov    %r15d,0x28c(%rsp)
  81ff26:	mov    0x38(%rsp),%rax
  81ff2b:	mov    %eax,0x290(%rsp)
  81ff32:	mov    %ecx,0x294(%rsp)
  81ff39:	movss  0xe0(%rsp),%xmm0
  81ff42:	movss  %xmm0,0x2a8(%rsp)
  81ff4b:	movq   $0x0,0x2ac(%rsp)
  81ff57:	movl   $0x0,0x2b4(%rsp)
  81ff62:	mov    0x8(%rsp),%rbp
  81ff67:	lea    0x230(%rbp),%rsi
  81ff6e:	movq   $0x0,0x10(%rsp)
  81ff77:	lea    0x288(%rsp),%rcx
  81ff7f:	mov    $0x30,%r8d
  81ff85:	mov    0xc0(%rsp),%r12
  81ff8d:	mov    %r12,%rdi
  81ff90:	mov    %rsi,0x38(%rsp)
  81ff95:	xor    %edx,%edx
  81ff97:	call   *0x66124b(%rip)        # e811e8 <_DYNAMIC+0x5d0>
  81ff9d:	mov    0x8(%rbp),%rcx
  81ffa1:	mov    0x10(%rbp),%r8
  81ffa5:	shl    $0x4,%r8
  81ffa9:	mov    0x108(%rsp),%rdi
  81ffb1:	mov    %r13,%rsi
  81ffb4:	mov    %r12,%rdx
  81ffb7:	call   81cb60 <<gpui_gpu::renderer::Buffer>::write>
  81ffbc:	lea    0x280(%rbp),%rdi
  81ffc3:	mov    0x20(%rbp),%rcx
  81ffc7:	mov    0x28(%rbp),%r8
  81ffcb:	shl    $0x3,%r8
  81ffcf:	mov    %rdi,0x20(%rsp)
  81ffd4:	mov    %r13,%rsi
  81ffd7:	mov    %r12,%rdx
  81ffda:	call   81cb60 <<gpui_gpu::renderer::Buffer>::write>
  81ffdf:	lea    0x2a8(%rbp),%rdi
  81ffe6:	mov    0x38(%rbp),%rcx
  81ffea:	mov    0x40(%rbp),%r8
  81ffee:	shl    $0x2,%r8
  81fff2:	mov    %rdi,0x40(%rsp)
  81fff7:	mov    %r13,%rsi
  81fffa:	mov    %r12,%rdx
  81fffd:	call   81cb60 <<gpui_gpu::renderer::Buffer>::write>
  820002:	lea    0x2d0(%rbp),%rdi
  820009:	mov    0x68(%rbp),%rcx
  82000d:	mov    0x70(%rbp),%r8
  820011:	shl    $0x5,%r8
  820015:	mov    %rdi,0x90(%rsp)
  82001d:	mov    %r13,%rsi
  820020:	mov    %r12,%rdx
  820023:	call   81cb60 <<gpui_gpu::renderer::Buffer>::write>
  820028:	cmpq   $0x0,0x328(%rbp)
  820030:	jne    82004c <<gpui_gpu::renderer::RendererState>::render+0x202c>
  820032:	mov    0x8(%rsp),%rax
  820037:	mov    0x10(%rax),%rax
  82003b:	cmp    $0x1,%rax
  82003f:	adc    $0x0,%rax
  820043:	shl    $0x4,%rax
  820047:	mov    %rax,0x10(%rsp)
  82004c:	mov    0x8(%rsp),%rsi
  820051:	mov    0x28(%rsi),%rdx
  820055:	mov    0x40(%rsi),%rax
  820059:	cmp    $0x1,%rdx
  82005d:	adc    $0x0,%rdx
  820061:	shl    $0x3,%rdx
  820065:	cmp    $0x1,%rax
  820069:	adc    $0x0,%rax
  82006d:	mov    0x70(%rsi),%rcx
  820071:	cmp    $0x1,%rcx
  820075:	adc    $0x0,%rcx
  820079:	add    $0xc8,%rsi
  820080:	shl    $0x2,%rax
  820084:	shl    $0x5,%rcx
  820088:	movq   $0x0,0x120(%rsp)
  820094:	mov    0x38(%rsp),%rdi
  820099:	mov    %rdi,0x128(%rsp)
  8200a1:	movq   $0x0,0x148(%rsp)
  8200ad:	xorps  %xmm0,%xmm0
  8200b0:	movups %xmm0,0x130(%rsp)
  8200b8:	movl   $0x0,0x140(%rsp)
  8200c3:	mov    0x108(%rsp),%rdi
  8200cb:	mov    %rdi,0x150(%rsp)
  8200d3:	movq   $0x0,0x158(%rsp)
  8200df:	mov    0x10(%rsp),%rdi
  8200e4:	mov    %rdi,0x160(%rsp)
  8200ec:	movl   $0x1,0x168(%rsp)
  8200f7:	movq   $0x0,0x170(%rsp)
  820103:	mov    0x20(%rsp),%rdi
  820108:	mov    %rdi,0x178(%rsp)
  820110:	movq   $0x0,0x180(%rsp)
  82011c:	mov    %rdx,0x188(%rsp)
  820124:	movl   $0x2,0x190(%rsp)
  82012f:	movq   $0x0,0x198(%rsp)
  82013b:	mov    0x40(%rsp),%rdx
  820140:	mov    %rdx,0x1a0(%rsp)
  820148:	movq   $0x0,0x1a8(%rsp)
  820154:	mov    %rax,0x1b0(%rsp)
  82015c:	movl   $0x3,0x1b8(%rsp)
  820167:	movq   $0x4,0x1c0(%rsp)
  820173:	mov    %rsi,0x1c8(%rsp)
  82017b:	movl   $0x4,0x1e0(%rsp)
  820186:	movq   $0x0,0x1e8(%rsp)
  820192:	mov    0x90(%rsp),%rax
  82019a:	mov    %rax,0x1f0(%rsp)
  8201a2:	movq   $0x0,0x1f8(%rsp)
  8201ae:	mov    %rcx,0x200(%rsp)
  8201b6:	movl   $0x5,0x208(%rsp)
  8201c1:	lea    -0x74b548(%rip),%rax        # d4c80 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  8201c8:	mov    %rax,0x3a8(%rsp)
  8201d0:	movq   $0xa,0x3b0(%rsp)
  8201dc:	mov    0x30(%rsp),%rax
  8201e1:	mov    %rax,0x390(%rsp)
  8201e9:	lea    0x120(%rsp),%rax
  8201f1:	mov    %rax,0x398(%rsp)
  8201f9:	movq   $0x6,0x3a0(%rsp)
  820205:	lea    0x390(%rsp),%rsi
  82020d:	mov    0x110(%rsp),%r12
  820215:	mov    %r12,%rdi
  820218:	call   *0x660fd2(%rip)        # e811f0 <_DYNAMIC+0x5d8>
  82021e:	mov    %rax,%r13
  820221:	mov    %rax,0x2f0(%rsp)
  820229:	lea    0x2f0(%rsp),%rdx
  820231:	mov    %r12,%rdi
  820234:	mov    0x470(%rsp),%rsi
  82023c:	call   81d1c0 <<gpui_gpu::renderer::GpuContext>::submit>
  820241:	mov    %rax,0x10(%rsp)
  820246:	xor    %ebp,%ebp
  820248:	mov    0x460(%rsp),%rax
  820250:	cmp    0x468(%rsp),%rax
  820258:	setne  %bpl
  82025c:	shl    $0x1f,%ebp
  82025f:	or     %r14d,%ebp
  820262:	shl    $0x20,%r15
  820266:	or     %r15,%rbp
  820269:	mov    (%rbx),%rax
  82026c:	test   %rax,%rax
  82026f:	je     820280 <<gpui_gpu::renderer::RendererState>::render+0x2260>
  820271:	lock decq (%rax)
  820275:	jne    820280 <<gpui_gpu::renderer::RendererState>::render+0x2260>
  820277:	mov    %rbx,%rdi
  82027a:	call   *0x660eb0(%rip)        # e81130 <_DYNAMIC+0x518>
  820280:	mov    0x8(%rsp),%rax
  820285:	mov    %r13,0x330(%rax)
  82028c:	mov    %rbp,0x338(%rax)
  820293:	mov    0x10(%rax),%r8
  820297:	mov    0x28(%rax),%rsi
  82029b:	mov    0x70(%rax),%rcx
  82029f:	mov    %rcx,0x38(%rsp)
  8202a4:	shl    $0x4,%r8
  8202a8:	mov    0x78(%rsp),%rdx
  8202ad:	lea    (%r8,%rdx,4),%rdi
  8202b1:	lea    (%rdi,%rsi,8),%rsi
  8202b5:	mov    %rcx,%rdi
  8202b8:	shl    $0x5,%rdi
  8202bc:	lea    (%rdi,%rsi,1),%rcx
  8202c0:	add    $0x30,%rcx
  8202c4:	mov    %rcx,0x20(%rsp)
  8202c9:	mov    0x278(%rax),%rdi
  8202d0:	add    0x250(%rax),%rdi
  8202d7:	add    0x2a0(%rax),%rdi
  8202de:	add    0x2c8(%rax),%rdi
  8202e5:	add    0x2f0(%rax),%rdi
  8202ec:	mov    0x308(%rax),%rsi
  8202f3:	add    0x310(%rax),%rsi
  8202fa:	mov    0x150(%rax),%r9d
  820301:	imul   %r9,%r9
  820305:	mov    0xc8(%rsp),%r11
  82030d:	mov    %r11,%rcx
  820310:	sub    %rdx,%rcx
  820313:	mov    0x70(%rsp),%r10
  820318:	mov    %r10,%r12
  82031b:	mov    0x250(%rsp),%rbp
  820323:	sub    %rbp,%r12
  820326:	mov    0x160(%rax),%rbx
  82032d:	inc    %rbx
  820330:	mov    $0xffffffffffffffff,%r14
  820337:	cmovne %rbx,%r14
  82033b:	mov    (%rax),%rbx
  82033e:	shl    $0x4,%rbx
  820342:	mov    0x48(%rax),%r15
  820346:	add    0x30(%rax),%r15
  82034a:	mov    0x18(%rax),%r13
  82034e:	lea    (%rbx,%r13,8),%rbx
  820352:	lea    (%rbx,%r15,4),%rbx
  820356:	mov    0x60(%rax),%r15
  82035a:	shl    $0x5,%r15
  82035e:	add    %rbx,%r15
  820361:	mov    0x138(%rax),%rbx
  820368:	mov    0x130(%rax),%r13
  82036f:	mov    %r14,0x160(%rax)
  820376:	mov    %r10,0x168(%rax)
  82037d:	lea    (%r11,%r11,1),%r14
  820381:	mov    %r14,0x170(%rax)
  820388:	movq   $0x1,0x178(%rax)
  820393:	mov    %r10,0x180(%rax)
  82039a:	mov    %rdx,0x188(%rax)
  8203a1:	mov    %r11,0x190(%rax)
  8203a8:	mov    %rcx,0x198(%rax)
  8203af:	mov    0x18(%rsp),%rcx
  8203b4:	mov    %rcx,0x1a0(%rax)
  8203bb:	mov    0x60(%rsp),%rcx
  8203c0:	mov    %rcx,0x1a8(%rax)
  8203c7:	mov    0x28(%rsp),%rcx
  8203cc:	mov    %rcx,0x1b0(%rax)
  8203d3:	mov    0x20(%rsp),%rcx
  8203d8:	mov    %rcx,0x1b8(%rax)
  8203df:	mov    %r8,0x1c0(%rax)
  8203e6:	mov    0x248(%rsp),%rdx
  8203ee:	mov    %rdx,0x1c8(%rax)
  8203f5:	mov    %rbp,0x1d0(%rax)
  8203fc:	mov    %r12,0x1d8(%rax)
  820403:	mov    0x258(%rsp),%rcx
  82040b:	mov    %rcx,0x1e0(%rax)
  820412:	mov    %rdi,0x1e8(%rax)
  820419:	mov    %r9,0x1f0(%rax)
  820420:	add    %rbx,%r13
  820423:	mov    %rbx,0x1f8(%rax)
  82042a:	mov    %r13,0x200(%rax)
  820431:	mov    %r15,0x208(%rax)
  820438:	mov    0x38(%rsp),%rcx
  82043d:	mov    %rcx,0x210(%rax)
  820444:	mov    %rsi,0x218(%rax)
  82044b:	movb   $0x0,0x220(%rax)
  820452:	mov    0x58(%rsp),%rdi
  820457:	mov    0x10(%rsp),%rax
  82045c:	mov    %rax,0x8(%rdi)
  820460:	movl   $0xffffffff,(%rdi)
  820466:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  82046b:	mov    0x58(%rsp),%rdi
  820470:	jmp    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  820475:	movq   $0x0,0x60(%rsp)
  82047e:	xor    %eax,%eax
  820480:	movq   $0x0,0x18(%rsp)
  820489:	jmp    82049d <<gpui_gpu::renderer::RendererState>::render+0x247d>
  82048b:	incq   0x18(%rsp)
  820490:	add    $0x8,%rax
  820494:	cmp    %rax,%rdi
  820497:	je     81fe7b <<gpui_gpu::renderer::RendererState>::render+0x1e5b>
  82049d:	mov    0x10(%rsp),%rcx
  8204a2:	mov    0x4(%rcx,%rax,1),%ecx
  8204a6:	mov    %ecx,%edx
  8204a8:	neg    %edx
  8204aa:	jo     82048b <<gpui_gpu::renderer::RendererState>::render+0x246b>
  8204ac:	and    $0x1fffffff,%ecx
  8204b2:	mov    0x10(%rsp),%rdx
  8204b7:	cmp    %ecx,(%rdx,%rax,1)
  8204ba:	je     820490 <<gpui_gpu::renderer::RendererState>::render+0x2470>
  8204bc:	lea    0x60f38d(%rip),%rdi        # e2f850 <anon.93049d86f4da36fb5b5cebb14659314f.38.llvm.10732147056912049262>
  8204c3:	call   *0x660d2f(%rip)        # e811f8 <_DYNAMIC+0x5e0>
  8204c9:	lea    0x60f1b8(%rip),%rdi        # e2f688 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  8204d0:	call   *0x660d2a(%rip)        # e81200 <_DYNAMIC+0x5e8>
  8204d6:	mov    0x40(%rsp),%rdi
  8204db:	add    0x260(%rsp),%rdi
  8204e3:	add    %rdx,%rdi
  8204e6:	lea    0x60f1b3(%rip),%rdx        # e2f6a0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  8204ed:	call   *0x660c1d(%rip)        # e81110 <_DYNAMIC+0x4f8>
  8204f3:	lea    0x60f1be(%rip),%rdx        # e2f6b8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  8204fa:	call   *0x660c10(%rip)        # e81110 <_DYNAMIC+0x4f8>
  820500:	mov    %rax,%r14
  820503:	mov    0x8(%rsp),%rax
  820508:	mov    %r13,0x330(%rax)
  82050f:	mov    %rbp,0x338(%rax)
  820516:	mov    %r14,%rdi
  820519:	call   e2d970 <_Unwind_Resume@plt>
  82051e:	mov    %rax,%r14
  820521:	lock decq 0x0(%r13)
  820526:	jne    820548 <<gpui_gpu::renderer::RendererState>::render+0x2528>
  820528:	lea    0x2f0(%rsp),%rdi
  820530:	call   *0x660bfa(%rip)        # e81130 <_DYNAMIC+0x518>
  820536:	jmp    820548 <<gpui_gpu::renderer::RendererState>::render+0x2528>
  820538:	call   *0x66092a(%rip)        # e80e68 <_DYNAMIC+0x250>
  82053e:	mov    %rax,%r14
  820541:	movq   $0x0,(%rbx)
  820548:	mov    %r14,%rdi
  82054b:	call   e2d970 <_Unwind_Resume@plt>
