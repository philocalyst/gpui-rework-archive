
FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4531 frame=840

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820550 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820550:	push   %rbp
  820551:	push   %r15
  820553:	push   %r14
  820555:	push   %r13
  820557:	push   %r12
  820559:	push   %rbx
  82055a:	sub    $0x318,%rsp
  820561:	movss  0x88(%rdx),%xmm3
  820569:	movss  -0x771555(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820571:	movaps %xmm3,%xmm1
  820574:	subss  %xmm0,%xmm1
  820578:	cvttss2si %xmm1,%rax
  82057d:	cvttss2si %xmm3,%r10
  820582:	mov    %r10,%rbp
  820585:	sar    $0x3f,%rbp
  820589:	and    %rax,%rbp
  82058c:	or     %r10,%rbp
  82058f:	xor    %eax,%eax
  820591:	xorps  %xmm1,%xmm1
  820594:	ucomiss %xmm1,%xmm3
  820597:	cmovb  %rax,%rbp
  82059b:	movss  0x90(%rdx),%xmm4
  8205a3:	movss  -0x77158b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8205ab:	ucomiss %xmm2,%xmm3
  8205ae:	mov    $0xffffffffffffffff,%r14
  8205b5:	cmova  %r14,%rbp
  8205b9:	movaps %xmm4,%xmm3
  8205bc:	subss  %xmm0,%xmm3
  8205c0:	cvttss2si %xmm3,%r10
  8205c5:	cvttss2si %xmm4,%r11
  8205ca:	mov    %r11,%rbx
  8205cd:	sar    $0x3f,%rbx
  8205d1:	and    %r10,%rbx
  8205d4:	or     %r11,%rbx
  8205d7:	ucomiss %xmm1,%xmm4
  8205da:	cmovb  %rax,%rbx
  8205de:	ucomiss %xmm2,%xmm4
  8205e1:	cmova  %r14,%rbx
  8205e5:	movss  0x8c(%rdx),%xmm3
  8205ed:	add    %rbp,%rbx
  8205f0:	dec    %rbx
  8205f3:	shr    $0x4,%rbx
  8205f7:	shr    $0x4,%rbp
  8205fb:	mov    %rbx,%r13
  8205fe:	sub    %rbp,%r13
  820601:	inc    %r13
  820604:	movaps %xmm3,%xmm4
  820607:	subss  %xmm0,%xmm4
  82060b:	cvttss2si %xmm4,%r11
  820610:	cvttss2si %xmm3,%r10
  820615:	mov    %r10,%r15
  820618:	sar    $0x3f,%r15
  82061c:	and    %r11,%r15
  82061f:	or     %r10,%r15
  820622:	ucomiss %xmm1,%xmm3
  820625:	cmovb  %rax,%r15
  820629:	ucomiss %xmm2,%xmm3
  82062c:	movss  0x94(%rdx),%xmm3
  820634:	cmova  %r14,%r15
  820638:	movaps %xmm3,%xmm4
  82063b:	subss  %xmm0,%xmm4
  82063f:	cvttss2si %xmm4,%r12
  820644:	cvttss2si %xmm3,%r10
  820649:	mov    %r10,%r11
  82064c:	sar    $0x3f,%r11
  820650:	and    %r12,%r11
  820653:	or     %r10,%r11
  820656:	ucomiss %xmm1,%xmm3
  820659:	cmovb  %rax,%r11
  82065d:	ucomiss %xmm2,%xmm3
  820660:	cmova  %r14,%r11
  820664:	mov    %r15,%r14
  820667:	lea    (%r15,%r11,1),%r10
  82066b:	dec    %r10
  82066e:	shr    $0x4,%r10
  820672:	shr    $0x4,%r14
  820676:	mov    %r10,%r12
  820679:	sub    %r14,%r12
  82067c:	inc    %r12
  82067f:	imul   %r13,%r12
  820683:	mov    0x368(%rsp),%r11
  82068b:	add    %r12,%r11
  82068e:	setb   %al
  820691:	cmp    $0x400001,%r11
  820698:	setae  %r15b
  82069c:	or     %al,%r15b
  82069f:	mov    $0x6,%eax
  8206a4:	jne    8207a6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x256>
  8206aa:	mov    %r12,0x1e8(%rsp)
  8206b2:	mov    %r11,0x198(%rsp)
  8206ba:	mov    %rdi,0x1a0(%rsp)
  8206c2:	cmpb   $0x0,(%rdx)
  8206c5:	sete   %al
  8206c8:	and    0x340(%rsi),%al
  8206ce:	movl   $0x0,0x4(%rsp)
  8206d6:	cmp    $0x1,%al
  8206d8:	jne    820768 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8206de:	movss  0xa4(%rdx),%xmm0
  8206e6:	ucomiss -0x77190d(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  8206ed:	jne    820768 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8206ef:	jp     820768 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8206f1:	mov    0x98(%rdx),%edi
  8206f7:	test   %edi,%edi
  8206f9:	jns    82070b <<gpui_gpu::renderer::RendererState>::bin_draw+0x1bb>
  8206fb:	and    $0x7f800000,%edi
  820701:	dec    %edi
  820703:	cmp    $0x7f7fffff,%edi
  820709:	jae    820760 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  82070b:	mov    0x9c(%rdx),%edi
  820711:	test   %edi,%edi
  820713:	jns    820725 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d5>
  820715:	and    $0x7f800000,%edi
  82071b:	dec    %edi
  82071d:	cmp    $0x7f7ffffe,%edi
  820723:	ja     820760 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  820725:	mov    0xa0(%rdx),%edi
  82072b:	test   %edi,%edi
  82072d:	jns    82073f <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ef>
  82072f:	and    $0x7f800000,%edi
  820735:	dec    %edi
  820737:	cmp    $0x7f7ffffe,%edi
  82073d:	ja     820760 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  82073f:	movd   %xmm0,%edi
  820743:	test   %edi,%edi
  820745:	jns    820757 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  820747:	and    $0x7f800000,%edi
  82074d:	dec    %edi
  82074f:	cmp    $0x7f7ffffe,%edi
  820755:	ja     820760 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  820757:	mov    $0x1,%dil
  82075a:	mov    %edi,0x4(%rsp)
  82075e:	jmp    820768 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  820760:	movl   $0x0,0x4(%rsp)
  820768:	mov    %rcx,0xe0(%rsp)
  820770:	mov    %r8d,0xbc(%rsp)
  820778:	mov    %r9,0xa8(%rsp)
  820780:	mov    %rdx,0xe8(%rsp)
  820788:	cmp    %r14,%r10
  82078b:	jae    8207ba <<gpui_gpu::renderer::RendererState>::bin_draw+0x26a>
  82078d:	mov    0x1a0(%rsp),%rdi
  820795:	mov    0x198(%rsp),%rax
  82079d:	mov    %rax,0x8(%rdi)
  8207a1:	mov    $0xffffffff,%eax
  8207a6:	mov    %eax,(%rdi)
  8207a8:	add    $0x318,%rsp
  8207af:	pop    %rbx
  8207b0:	pop    %r12
  8207b2:	pop    %r13
  8207b4:	pop    %r14
  8207b6:	pop    %r15
  8207b8:	pop    %rbp
  8207b9:	ret
  8207ba:	cmp    %rbp,%rbx
  8207bd:	jae    8207d6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  8207bf:	nop
  8207c0:	mov    %r14,%rax
  8207c3:	cmp    %r10,%r14
  8207c6:	adc    $0x0,%r14
  8207ca:	cmp    %r10,%rax
  8207cd:	jae    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8207cf:	cmp    %r10,%r14
  8207d2:	jbe    8207c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  8207d4:	jmp    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8207d6:	mov    0x350(%rsp),%r13
  8207de:	mov    0x20(%rsi),%r15
  8207e2:	mov    0x28(%rsi),%r9
  8207e6:	test   %al,%al
  8207e8:	je     821640 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  8207ee:	mov    0xe0(%rsp),%rax
  8207f6:	movd   %eax,%xmm0
  8207fa:	shr    $0x20,%rax
  8207fe:	mov    0xe8(%rsp),%rcx
  820806:	movss  0x78(%rcx),%xmm1
  82080b:	cvtss2sd %xmm1,%xmm12
  820810:	movss  0x80(%rcx),%xmm1
  820818:	movss  0x7c(%rcx),%xmm2
  82081d:	xorps  %xmm3,%xmm3
  820820:	cvtss2sd %xmm2,%xmm3
  820824:	movss  0x84(%rcx),%xmm2
  82082c:	cvtss2sd %xmm1,%xmm1
  820830:	addsd  %xmm12,%xmm1
  820835:	movsd  %xmm1,0x1d8(%rsp)
  82083e:	xorps  %xmm1,%xmm1
  820841:	cvtss2sd %xmm2,%xmm1
  820845:	movsd  %xmm3,0x1e0(%rsp)
  82084e:	addsd  %xmm3,%xmm1
  820852:	movsd  %xmm1,0x1c8(%rsp)
  82085b:	movsd  0x48(%rcx),%xmm3
  820860:	movsd  0x58(%rcx),%xmm4
  820865:	movsd  0x68(%rcx),%xmm5
  82086a:	movss  0x38(%rcx),%xmm1
  82086f:	movss  0x40(%rcx),%xmm2
  820874:	cvtss2sd %xmm1,%xmm1
  820878:	cvtss2sd %xmm2,%xmm2
  82087c:	movaps -0x775a53(%rip),%xmm6        # aae30 <GCC_except_table0+0x64>
  820883:	movaps %xmm1,0x90(%rsp)
  82088b:	andps  %xmm6,%xmm1
  82088e:	movaps %xmm1,0x80(%rsp)
  820896:	movaps %xmm2,0x60(%rsp)
  82089b:	andps  %xmm6,%xmm2
  82089e:	movaps %xmm2,0x70(%rsp)
  8208a3:	cvtss2sd %xmm0,%xmm0
  8208a7:	movsd  %xmm0,0x18(%rsp)
  8208ad:	movaps %xmm3,%xmm0
  8208b0:	andps  %xmm6,%xmm0
  8208b3:	movaps %xmm0,0x290(%rsp)
  8208bb:	movaps %xmm4,%xmm0
  8208be:	andps  %xmm6,%xmm0
  8208c1:	movaps %xmm0,0x270(%rsp)
  8208c9:	movaps %xmm5,%xmm0
  8208cc:	andps  %xmm6,%xmm0
  8208cf:	movaps %xmm0,0x130(%rsp)
  8208d7:	movss  0x3c(%rcx),%xmm0
  8208dc:	xorps  %xmm1,%xmm1
  8208df:	cvtss2sd %xmm0,%xmm1
  8208e3:	movss  0x44(%rcx),%xmm0
  8208e8:	cvtss2sd %xmm0,%xmm0
  8208ec:	movaps %xmm1,0x50(%rsp)
  8208f1:	andps  %xmm6,%xmm1
  8208f4:	movaps %xmm1,0x40(%rsp)
  8208f9:	movaps %xmm0,0x20(%rsp)
  8208fe:	andps  %xmm6,%xmm0
  820901:	movaps %xmm0,0x30(%rsp)
  820906:	movd   %eax,%xmm0
  82090a:	cvtss2sd %xmm0,%xmm0
  82090e:	movsd  %xmm0,0x10(%rsp)
  820914:	movsd  0x50(%rcx),%xmm1
  820919:	movaps %xmm1,%xmm0
  82091c:	andps  %xmm6,%xmm0
  82091f:	movaps %xmm0,0x210(%rsp)
  820927:	movsd  0x60(%rcx),%xmm2
  82092c:	movaps %xmm2,%xmm0
  82092f:	andps  %xmm6,%xmm0
  820932:	movaps %xmm0,0x1f0(%rsp)
  82093a:	movsd  0x70(%rcx),%xmm7
  82093f:	andps  %xmm7,%xmm6
  820942:	movaps %xmm6,0x100(%rsp)
  82094a:	mov    0x58(%rsi),%rax
  82094e:	mov    %rax,0xd8(%rsp)
  820956:	mov    0x50(%rsi),%rax
  82095a:	mov    %rax,0x1d0(%rsp)
  820962:	movaps %xmm3,0x2a0(%rsp)
  82096a:	movaps %xmm3,%xmm0
  82096d:	movaps %xmm4,0x280(%rsp)
  820975:	movlhps %xmm4,%xmm0
  820978:	cvtpd2ps %xmm0,%xmm0
  82097c:	movaps %xmm1,0x220(%rsp)
  820984:	cvtsd2ss %xmm1,%xmm1
  820988:	cvtss2sd %xmm1,%xmm1
  82098c:	cvtps2pd %xmm0,%xmm3
  82098f:	movaps %xmm2,0x200(%rsp)
  820997:	xorps  %xmm0,%xmm0
  82099a:	cvtsd2ss %xmm2,%xmm0
  82099e:	xorps  %xmm2,%xmm2
  8209a1:	cvtss2sd %xmm0,%xmm2
  8209a5:	movaps %xmm5,0x140(%rsp)
  8209ad:	xorps  %xmm0,%xmm0
  8209b0:	cvtsd2ss %xmm5,%xmm0
  8209b4:	cvtss2sd %xmm0,%xmm4
  8209b8:	movaps %xmm7,0xf0(%rsp)
  8209c0:	xorps  %xmm0,%xmm0
  8209c3:	cvtsd2ss %xmm7,%xmm0
  8209c7:	mov    0xa8(%rsp),%rax
  8209cf:	inc    %eax
  8209d1:	mov    %rax,0xa8(%rsp)
  8209d9:	cvtss2sd %xmm0,%xmm0
  8209dd:	movaps -0x775bb4(%rip),%xmm5        # aae30 <GCC_except_table0+0x64>
  8209e4:	movaps %xmm3,%xmm6
  8209e7:	andps  %xmm5,%xmm6
  8209ea:	movaps %xmm4,0x160(%rsp)
  8209f2:	andps  %xmm5,%xmm4
  8209f5:	movaps %xmm4,0x150(%rsp)
  8209fd:	movaps %xmm1,0x260(%rsp)
  820a05:	andps  %xmm5,%xmm1
  820a08:	movaps %xmm1,0x250(%rsp)
  820a10:	movaps %xmm2,0x240(%rsp)
  820a18:	andps  %xmm5,%xmm2
  820a1b:	movaps %xmm2,0x230(%rsp)
  820a23:	movaps %xmm0,0x120(%rsp)
  820a2b:	andps  %xmm0,%xmm5
  820a2e:	movaps %xmm5,0x110(%rsp)
  820a36:	movaps %xmm3,0x2c0(%rsp)
  820a3e:	movhlps %xmm3,%xmm3
  820a41:	movaps %xmm3,0x2f0(%rsp)
  820a49:	mov    $0x2,%r11b
  820a4c:	xor    %edx,%edx
  820a4e:	mov    %r14,%rax
  820a51:	movaps %xmm6,0x2b0(%rsp)
  820a59:	pshufd $0xee,%xmm6,%xmm0
  820a5e:	movdqa %xmm0,0x2e0(%rsp)
  820a67:	movsd  %xmm12,0x8(%rsp)
  820a6e:	mov    %rbp,0x1b0(%rsp)
  820a76:	mov    %r10,0x1a8(%rsp)
  820a7e:	xchg   %ax,%ax
  820a80:	cmp    %r10,%r14
  820a83:	adc    $0x0,%rax
  820a87:	mov    %rax,0x1b8(%rsp)
  820a8f:	mov    %r14,0x1c0(%rsp)
  820a97:	imul   %r13,%r14
  820a9b:	mov    %rbp,%r10
  820a9e:	mov    0x360(%rsp),%r8d
  820aa6:	mov    0x358(%rsp),%ecx
  820aad:	jmp    820ad0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820aaf:	cmp    %r9,%r12
  820ab2:	jae    8216a5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820ab8:	incl   0x4(%r15,%r12,8)
  820abd:	mov    $0x1,%dl
  820abf:	cmp    %rbx,%r10
  820ac2:	jb     820c93 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820ac8:	jmp    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820acd:	nopl   (%rax)
  820ad0:	cmp    %rbx,%r10
  820ad3:	adc    $0x0,%rbp
  820ad7:	lea    (%r10,%r14,1),%r12
  820adb:	cmpb   $0x0,0x4(%rsp)
  820ae0:	jne    820af7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a7>
  820ae2:	cmp    %r9,%r12
  820ae5:	jae    8216c5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1175>
  820aeb:	testb  $0x40,0x7(%r15,%r12,8)
  820af1:	je     820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820af7:	cmpq   $0x2,0x1e8(%rsp)
  820b00:	setae  %al
  820b03:	and    %dl,%al
  820b05:	cmp    $0x1,%al
  820b07:	jne    820be2 <<gpui_gpu::renderer::RendererState>::bin_draw+0x692>
  820b0d:	cmp    $0x2,%r11b
  820b11:	jne    820b7c <<gpui_gpu::renderer::RendererState>::bin_draw+0x62c>
  820b13:	mov    %r10,0xb0(%rsp)
  820b1b:	mov    0xe8(%rsp),%rdi
  820b23:	mov    0xe0(%rsp),%rsi
  820b2b:	mov    %r13,%rdx
  820b2e:	mov    %rbp,0xc0(%rsp)
  820b36:	mov    %rbx,%rbp
  820b39:	mov    %r14,%rbx
  820b3c:	mov    %r15,%r14
  820b3f:	mov    %r9,%r15
  820b42:	call   8268b0 <gpui_gpu::renderer::coverage::whole>
  820b47:	mov    0xb0(%rsp),%r10
  820b4f:	movsd  0x8(%rsp),%xmm12
  820b56:	mov    0x360(%rsp),%r8d
  820b5e:	mov    %r15,%r9
  820b61:	mov    %r14,%r15
  820b64:	mov    %rbx,%r14
  820b67:	mov    %rbp,%rbx
  820b6a:	mov    0xc0(%rsp),%rbp
  820b72:	mov    0x358(%rsp),%ecx
  820b79:	mov    %eax,%r11d
  820b7c:	test   $0x1,%r11b
  820b80:	mov    $0x1,%r11b
  820b83:	je     820bdf <<gpui_gpu::renderer::RendererState>::bin_draw+0x68f>
  820b85:	cmpb   $0x0,0x4(%rsp)
  820b8a:	je     820aaf <<gpui_gpu::renderer::RendererState>::bin_draw+0x55f>
  820b90:	cmp    %r9,%r12
  820b93:	jae    8216f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11a0>
  820b99:	mov    0xbc(%rsp),%eax
  820ba0:	mov    %eax,(%r15,%r12,8)
  820ba4:	movl   $0x40000001,0x4(%r15,%r12,8)
  820bad:	cmp    0xd8(%rsp),%r12
  820bb5:	jae    8216d8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1188>
  820bbb:	mov    0xa8(%rsp),%rax
  820bc3:	mov    0x1d0(%rsp),%rdx
  820bcb:	mov    %eax,(%rdx,%r12,4)
  820bcf:	mov    $0x1,%dl
  820bd1:	cmp    %rbx,%r10
  820bd4:	jb     820c93 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820bda:	jmp    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820bdf:	xor    %r11d,%r11d
  820be2:	test   %r13,%r13
  820be5:	je     8216b8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1168>
  820beb:	mov    %r12,%rax
  820bee:	shr    $0x20,%rax
  820bf2:	je     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b0>
  820bf4:	mov    %r12,%rax
  820bf7:	xor    %edx,%edx
  820bf9:	div    %r13
  820bfc:	jmp    820c08 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b8>
  820bfe:	xchg   %ax,%ax
  820c00:	mov    %r12d,%eax
  820c03:	xor    %edx,%edx
  820c05:	div    %r13d
  820c08:	shl    $0x4,%edx
  820c0b:	shl    $0x4,%eax
  820c0e:	lea    0x10(%rdx),%esi
  820c11:	cmp    %esi,%ecx
  820c13:	cmovb  %ecx,%esi
  820c16:	lea    0x10(%rax),%edi
  820c19:	cmp    %edi,%r8d
  820c1c:	cmovb  %r8d,%edi
  820c20:	xorps  %xmm2,%xmm2
  820c23:	cvtsi2sd %edx,%xmm2
  820c27:	mov    $0x1,%dl
  820c29:	ucomisd %xmm2,%xmm12
  820c2e:	ja     820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820c30:	mov    %eax,%eax
  820c32:	xorps  %xmm3,%xmm3
  820c35:	cvtsi2sd %rax,%xmm3
  820c3a:	movsd  0x1e0(%rsp),%xmm0
  820c43:	ucomisd %xmm3,%xmm0
  820c47:	ja     820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820c49:	xorps  %xmm0,%xmm0
  820c4c:	cvtsi2sd %esi,%xmm0
  820c50:	ucomisd 0x1d8(%rsp),%xmm0
  820c59:	ja     820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820c5b:	xorps  %xmm1,%xmm1
  820c5e:	cvtsi2sd %edi,%xmm1
  820c62:	ucomisd 0x1c8(%rsp),%xmm1
  820c6b:	jbe    820ca4 <<gpui_gpu::renderer::RendererState>::bin_draw+0x754>
  820c6d:	nopl   (%rax)
  820c70:	cmp    %r9,%r12
  820c73:	jae    8216a5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820c79:	mov    0x4(%r15,%r12,8),%eax
  820c7e:	inc    %eax
  820c80:	and    $0xbfffffff,%eax
  820c85:	mov    %eax,0x4(%r15,%r12,8)
  820c8a:	cmp    %rbx,%r10
  820c8d:	jae    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820c93:	mov    %rbp,%r10
  820c96:	cmp    %rbx,%rbp
  820c99:	jbe    820ad0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820c9f:	jmp    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820ca4:	unpcklpd %xmm3,%xmm2
  820ca8:	addpd  -0x773b70(%rip),%xmm2        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820cb0:	movapd %xmm2,%xmm3
  820cb4:	mulpd  0x2c0(%rsp),%xmm3
  820cbd:	movapd %xmm3,%xmm11
  820cc2:	unpckhpd %xmm3,%xmm11
  820cc7:	movapd %xmm3,%xmm5
  820ccb:	addsd  %xmm11,%xmm5
  820cd0:	addsd  0x160(%rsp),%xmm5
  820cd9:	subsd  0x90(%rsp),%xmm5
  820ce2:	movapd 0x2b0(%rsp),%xmm8
  820cec:	mulpd  %xmm2,%xmm8
  820cf1:	movapd %xmm8,%xmm4
  820cf6:	unpckhpd %xmm8,%xmm4
  820cfb:	movapd %xmm8,%xmm6
  820d00:	addsd  %xmm4,%xmm6
  820d04:	addsd  0x150(%rsp),%xmm6
  820d0d:	addsd  0x80(%rsp),%xmm6
  820d16:	addsd  0x70(%rsp),%xmm6
  820d1c:	addsd  -0x771444(%rip),%xmm6        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d24:	mulsd  -0x7714cc(%rip),%xmm6        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820d2c:	addsd  0x18(%rsp),%xmm6
  820d32:	ucomisd %xmm5,%xmm6
  820d36:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820d3c:	movapd 0x60(%rsp),%xmm7
  820d42:	subsd  %xmm5,%xmm7
  820d46:	ucomisd %xmm7,%xmm6
  820d4a:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820d50:	movapd %xmm2,%xmm13
  820d55:	unpckhpd %xmm2,%xmm13
  820d5a:	movapd 0x280(%rsp),%xmm15
  820d64:	mulsd  %xmm13,%xmm15
  820d69:	movapd 0x270(%rsp),%xmm14
  820d73:	mulsd  %xmm13,%xmm14
  820d78:	movapd 0x2a0(%rsp),%xmm5
  820d81:	mulsd  %xmm2,%xmm5
  820d85:	movapd %xmm5,%xmm6
  820d89:	addsd  %xmm15,%xmm6
  820d8e:	addsd  0x140(%rsp),%xmm6
  820d97:	subsd  0x90(%rsp),%xmm6
  820da0:	movapd 0x290(%rsp),%xmm7
  820da9:	mulsd  %xmm2,%xmm7
  820dad:	movapd %xmm7,%xmm9
  820db2:	addsd  %xmm14,%xmm9
  820db7:	addsd  0x130(%rsp),%xmm9
  820dc1:	addsd  0x80(%rsp),%xmm9
  820dcb:	addsd  0x70(%rsp),%xmm9
  820dd2:	addsd  -0x7714fb(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ddb:	mulsd  -0x770fa4(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820de4:	ucomisd %xmm6,%xmm9
  820de9:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820def:	movapd 0x60(%rsp),%xmm10
  820df6:	subsd  %xmm6,%xmm10
  820dfb:	ucomisd %xmm10,%xmm9
  820e00:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820e06:	movapd %xmm13,%xmm9
  820e0b:	mulsd  0x240(%rsp),%xmm9
  820e15:	movapd %xmm13,%xmm12
  820e1a:	mulsd  0x230(%rsp),%xmm12
  820e24:	movapd %xmm2,%xmm10
  820e29:	mulsd  0x260(%rsp),%xmm10
  820e33:	movapd %xmm10,%xmm6
  820e38:	movapd %xmm9,0xc0(%rsp)
  820e42:	addsd  %xmm9,%xmm6
  820e47:	addsd  0x120(%rsp),%xmm6
  820e50:	subsd  0x50(%rsp),%xmm6
  820e56:	movapd %xmm2,%xmm9
  820e5b:	mulsd  0x250(%rsp),%xmm9
  820e65:	movsd  %xmm9,0xb0(%rsp)
  820e6f:	addsd  %xmm12,%xmm9
  820e74:	addsd  0x110(%rsp),%xmm9
  820e7e:	addsd  0x40(%rsp),%xmm9
  820e85:	addsd  0x30(%rsp),%xmm9
  820e8c:	addsd  -0x7715b5(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e95:	mulsd  -0x77163e(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e9e:	addsd  0x10(%rsp),%xmm9
  820ea5:	ucomisd %xmm6,%xmm9
  820eaa:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820eb0:	movsd  %xmm10,0x190(%rsp)
  820eba:	movapd 0x20(%rsp),%xmm10
  820ec1:	subsd  %xmm6,%xmm10
  820ec6:	ucomisd %xmm10,%xmm9
  820ecb:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820ed1:	movapd 0x200(%rsp),%xmm9
  820edb:	mulsd  %xmm13,%xmm9
  820ee0:	mulsd  0x1f0(%rsp),%xmm13
  820eea:	movapd 0x220(%rsp),%xmm10
  820ef4:	mulsd  %xmm2,%xmm10
  820ef9:	movapd %xmm10,%xmm6
  820efe:	movapd %xmm9,0x170(%rsp)
  820f08:	addsd  %xmm9,%xmm6
  820f0d:	addsd  0xf0(%rsp),%xmm6
  820f16:	subsd  0x50(%rsp),%xmm6
  820f1c:	mulsd  0x210(%rsp),%xmm2
  820f25:	movapd %xmm2,%xmm9
  820f2a:	addsd  %xmm13,%xmm9
  820f2f:	addsd  0x100(%rsp),%xmm9
  820f39:	addsd  0x40(%rsp),%xmm9
  820f40:	addsd  0x30(%rsp),%xmm9
  820f47:	addsd  -0x771670(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f50:	mulsd  -0x771119(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f59:	ucomisd %xmm6,%xmm9
  820f5e:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820f64:	movapd %xmm10,0x300(%rsp)
  820f6e:	movapd 0x20(%rsp),%xmm10
  820f75:	subsd  %xmm6,%xmm10
  820f7a:	ucomisd %xmm10,%xmm9
  820f7f:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820f85:	addsd  -0x7719a5(%rip),%xmm0        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820f8d:	movapd %xmm0,%xmm9
  820f92:	mulsd  0x2c0(%rsp),%xmm9
  820f9c:	addsd  %xmm9,%xmm11
  820fa1:	addsd  0x160(%rsp),%xmm11
  820fab:	subsd  0x90(%rsp),%xmm11
  820fb5:	movapd 0x2b0(%rsp),%xmm10
  820fbf:	mulsd  %xmm0,%xmm10
  820fc4:	addsd  %xmm10,%xmm4
  820fc9:	addsd  0x150(%rsp),%xmm4
  820fd2:	addsd  0x80(%rsp),%xmm4
  820fdb:	addsd  0x70(%rsp),%xmm4
  820fe1:	addsd  -0x771709(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fe9:	mulsd  -0x771791(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ff1:	addsd  0x18(%rsp),%xmm4
  820ff7:	ucomisd %xmm11,%xmm4
  820ffc:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821002:	movapd 0x60(%rsp),%xmm6
  821008:	subsd  %xmm11,%xmm6
  82100d:	ucomisd %xmm6,%xmm4
  821011:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821017:	movapd 0x2a0(%rsp),%xmm6
  821020:	mulsd  %xmm0,%xmm6
  821024:	addsd  %xmm6,%xmm15
  821029:	addsd  0x140(%rsp),%xmm15
  821033:	subsd  0x90(%rsp),%xmm15
  82103d:	movapd 0x290(%rsp),%xmm11
  821047:	mulsd  %xmm0,%xmm11
  82104c:	addsd  %xmm11,%xmm14
  821051:	addsd  0x130(%rsp),%xmm14
  82105b:	addsd  0x80(%rsp),%xmm14
  821065:	addsd  0x70(%rsp),%xmm14
  82106c:	addsd  -0x771795(%rip),%xmm14        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821075:	mulsd  -0x77123e(%rip),%xmm14        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82107e:	ucomisd %xmm15,%xmm14
  821083:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821089:	movapd 0x60(%rsp),%xmm4
  82108f:	subsd  %xmm15,%xmm4
  821094:	ucomisd %xmm4,%xmm14
  821099:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  82109f:	movapd %xmm0,%xmm14
  8210a4:	mulsd  0x260(%rsp),%xmm14
  8210ae:	movapd 0xc0(%rsp),%xmm4
  8210b7:	addsd  %xmm14,%xmm4
  8210bc:	addsd  0x120(%rsp),%xmm4
  8210c5:	subsd  0x50(%rsp),%xmm4
  8210cb:	movapd %xmm0,%xmm15
  8210d0:	mulsd  0x250(%rsp),%xmm15
  8210da:	addsd  %xmm15,%xmm12
  8210df:	addsd  0x110(%rsp),%xmm12
  8210e9:	addsd  0x40(%rsp),%xmm12
  8210f0:	addsd  0x30(%rsp),%xmm12
  8210f7:	addsd  -0x771820(%rip),%xmm12        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821100:	mulsd  -0x7718a9(%rip),%xmm12        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821109:	addsd  0x10(%rsp),%xmm12
  821110:	ucomisd %xmm4,%xmm12
  821115:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  82111b:	movsd  %xmm15,0xc0(%rsp)
  821125:	movapd %xmm4,%xmm15
  82112a:	movapd 0x20(%rsp),%xmm4
  821130:	subsd  %xmm15,%xmm4
  821135:	ucomisd %xmm4,%xmm12
  82113a:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821140:	movapd 0x220(%rsp),%xmm4
  821149:	mulsd  %xmm0,%xmm4
  82114d:	movapd 0x170(%rsp),%xmm15
  821157:	addsd  %xmm4,%xmm15
  82115c:	addsd  0xf0(%rsp),%xmm15
  821166:	subsd  0x50(%rsp),%xmm15
  82116d:	mulsd  0x210(%rsp),%xmm0
  821176:	addsd  %xmm0,%xmm13
  82117b:	addsd  0x100(%rsp),%xmm13
  821185:	addsd  0x40(%rsp),%xmm13
  82118c:	addsd  0x30(%rsp),%xmm13
  821193:	addsd  -0x7718bc(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82119c:	mulsd  -0x771365(%rip),%xmm13        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8211a5:	ucomisd %xmm15,%xmm13
  8211aa:	movsd  0x8(%rsp),%xmm12
  8211b1:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8211b7:	movapd %xmm4,0x170(%rsp)
  8211c0:	movapd 0x20(%rsp),%xmm4
  8211c6:	subsd  %xmm15,%xmm4
  8211cb:	ucomisd %xmm4,%xmm13
  8211d0:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8211d6:	movsd  %xmm10,0x188(%rsp)
  8211e0:	addsd  -0x771c00(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8211e8:	movapd %xmm1,%xmm10
  8211ed:	mulsd  0x2f0(%rsp),%xmm10
  8211f7:	movapd %xmm1,%xmm4
  8211fb:	mulsd  0x2e0(%rsp),%xmm4
  821204:	addsd  %xmm10,%xmm3
  821209:	addsd  0x160(%rsp),%xmm3
  821212:	subsd  0x90(%rsp),%xmm3
  82121b:	addsd  %xmm4,%xmm8
  821220:	addsd  0x150(%rsp),%xmm8
  82122a:	addsd  0x80(%rsp),%xmm8
  821234:	addsd  0x70(%rsp),%xmm8
  82123b:	addsd  -0x771964(%rip),%xmm8        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821244:	mulsd  -0x7719ed(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82124d:	addsd  0x18(%rsp),%xmm8
  821254:	ucomisd %xmm3,%xmm8
  821259:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82125f:	movapd %xmm6,0x2d0(%rsp)
  821268:	movapd 0x60(%rsp),%xmm6
  82126e:	subsd  %xmm3,%xmm6
  821272:	ucomisd %xmm6,%xmm8
  821277:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82127d:	movapd 0x280(%rsp),%xmm8
  821287:	mulsd  %xmm1,%xmm8
  82128c:	movapd 0x270(%rsp),%xmm3
  821295:	mulsd  %xmm1,%xmm3
  821299:	addsd  %xmm8,%xmm5
  82129e:	addsd  0x140(%rsp),%xmm5
  8212a7:	subsd  0x90(%rsp),%xmm5
  8212b0:	addsd  %xmm3,%xmm7
  8212b4:	addsd  0x130(%rsp),%xmm7
  8212bd:	addsd  0x80(%rsp),%xmm7
  8212c6:	addsd  0x70(%rsp),%xmm7
  8212cc:	addsd  -0x7719f4(%rip),%xmm7        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212d4:	mulsd  -0x77149c(%rip),%xmm7        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8212dc:	ucomisd %xmm5,%xmm7
  8212e0:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8212e6:	movapd 0x60(%rsp),%xmm6
  8212ec:	subsd  %xmm5,%xmm6
  8212f0:	ucomisd %xmm6,%xmm7
  8212f4:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8212fa:	movsd  %xmm14,0x180(%rsp)
  821304:	movapd %xmm9,%xmm14
  821309:	movapd %xmm1,%xmm7
  82130d:	mulsd  0x240(%rsp),%xmm7
  821316:	movapd %xmm1,%xmm5
  82131a:	mulsd  0x230(%rsp),%xmm5
  821323:	movsd  0x190(%rsp),%xmm9
  82132d:	addsd  %xmm7,%xmm9
  821332:	addsd  0x120(%rsp),%xmm9
  82133c:	subsd  0x50(%rsp),%xmm9
  821343:	movsd  0xb0(%rsp),%xmm13
  82134d:	addsd  %xmm5,%xmm13
  821352:	addsd  0x110(%rsp),%xmm13
  82135c:	addsd  0x40(%rsp),%xmm13
  821363:	addsd  0x30(%rsp),%xmm13
  82136a:	addsd  -0x771a93(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821373:	mulsd  -0x771b1c(%rip),%xmm13        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82137c:	addsd  0x10(%rsp),%xmm13
  821383:	ucomisd %xmm9,%xmm13
  821388:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82138e:	movapd 0x20(%rsp),%xmm6
  821394:	subsd  %xmm9,%xmm6
  821399:	ucomisd %xmm6,%xmm13
  82139e:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8213a4:	movapd 0x200(%rsp),%xmm6
  8213ad:	mulsd  %xmm1,%xmm6
  8213b1:	mulsd  0x1f0(%rsp),%xmm1
  8213ba:	movapd 0x300(%rsp),%xmm13
  8213c4:	addsd  %xmm6,%xmm13
  8213c9:	addsd  0xf0(%rsp),%xmm13
  8213d3:	subsd  0x50(%rsp),%xmm13
  8213da:	addsd  %xmm1,%xmm2
  8213de:	addsd  0x100(%rsp),%xmm2
  8213e7:	addsd  0x40(%rsp),%xmm2
  8213ed:	addsd  0x30(%rsp),%xmm2
  8213f3:	addsd  -0x771b1b(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213fb:	mulsd  -0x7715c3(%rip),%xmm2        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821403:	ucomisd %xmm13,%xmm2
  821408:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82140e:	movapd 0x20(%rsp),%xmm9
  821415:	subsd  %xmm13,%xmm9
  82141a:	ucomisd %xmm9,%xmm2
  82141f:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821425:	addsd  %xmm10,%xmm14
  82142a:	addsd  0x160(%rsp),%xmm14
  821434:	subsd  0x90(%rsp),%xmm14
  82143e:	movsd  0x188(%rsp),%xmm9
  821448:	addsd  %xmm4,%xmm9
  82144d:	addsd  0x150(%rsp),%xmm9
  821457:	addsd  0x80(%rsp),%xmm9
  821461:	addsd  0x70(%rsp),%xmm9
  821468:	addsd  -0x771b91(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821471:	mulsd  -0x771c1a(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82147a:	addsd  0x18(%rsp),%xmm9
  821481:	ucomisd %xmm14,%xmm9
  821486:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82148c:	movapd 0x60(%rsp),%xmm2
  821492:	subsd  %xmm14,%xmm2
  821497:	ucomisd %xmm2,%xmm9
  82149c:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8214a2:	movapd 0x2d0(%rsp),%xmm4
  8214ab:	addsd  %xmm8,%xmm4
  8214b0:	addsd  0x140(%rsp),%xmm4
  8214b9:	subsd  0x90(%rsp),%xmm4
  8214c2:	addsd  %xmm3,%xmm11
  8214c7:	addsd  0x130(%rsp),%xmm11
  8214d1:	addsd  0x80(%rsp),%xmm11
  8214db:	addsd  0x70(%rsp),%xmm11
  8214e2:	addsd  -0x771c0b(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214eb:	mulsd  -0x7716b4(%rip),%xmm11        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8214f4:	ucomisd %xmm4,%xmm11
  8214f9:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8214ff:	movapd 0x60(%rsp),%xmm2
  821505:	subsd  %xmm4,%xmm2
  821509:	ucomisd %xmm2,%xmm11
  82150e:	movsd  0x180(%rsp),%xmm3
  821517:	movsd  0xc0(%rsp),%xmm4
  821520:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821526:	addsd  %xmm7,%xmm3
  82152a:	addsd  0x120(%rsp),%xmm3
  821533:	subsd  0x50(%rsp),%xmm3
  821539:	addsd  %xmm5,%xmm4
  82153d:	addsd  0x110(%rsp),%xmm4
  821546:	addsd  0x40(%rsp),%xmm4
  82154c:	addsd  0x30(%rsp),%xmm4
  821552:	addsd  -0x771c7a(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82155a:	mulsd  -0x771d02(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821562:	addsd  0x10(%rsp),%xmm4
  821568:	ucomisd %xmm3,%xmm4
  82156c:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821572:	movapd 0x20(%rsp),%xmm2
  821578:	subsd  %xmm3,%xmm2
  82157c:	ucomisd %xmm2,%xmm4
  821580:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821586:	movapd 0x170(%rsp),%xmm3
  82158f:	addsd  %xmm6,%xmm3
  821593:	addsd  0xf0(%rsp),%xmm3
  82159c:	subsd  0x50(%rsp),%xmm3
  8215a2:	addsd  %xmm1,%xmm0
  8215a6:	addsd  0x100(%rsp),%xmm0
  8215af:	addsd  0x40(%rsp),%xmm0
  8215b5:	addsd  0x30(%rsp),%xmm0
  8215bb:	addsd  -0x771ce3(%rip),%xmm0        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8215c3:	mulsd  -0x77178b(%rip),%xmm0        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8215cb:	ucomisd %xmm3,%xmm0
  8215cf:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8215d5:	movapd 0x20(%rsp),%xmm1
  8215db:	subsd  %xmm3,%xmm1
  8215df:	ucomisd %xmm1,%xmm0
  8215e3:	jb     820b85 <<gpui_gpu::renderer::RendererState>::bin_draw+0x635>
  8215e9:	jmp    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8215ee:	movsd  0x8(%rsp),%xmm12
  8215f5:	jmp    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8215fa:	nopw   0x0(%rax,%rax,1)
  821600:	mov    0x1a8(%rsp),%r10
  821608:	cmp    %r10,0x1c0(%rsp)
  821610:	mov    0x1b0(%rsp),%rbp
  821618:	mov    0x1b8(%rsp),%rax
  821620:	jae    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  821626:	mov    %rax,%r14
  821629:	cmp    %r10,%rax
  82162c:	jbe    820a80 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  821632:	jmp    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  821637:	nopw   0x0(%rax,%rax,1)
  821640:	mov    %r14,%rax
  821643:	cmp    %r10,%r14
  821646:	adc    $0x0,%r14
  82164a:	mov    %rax,%rcx
  82164d:	imul   %r13,%rcx
  821651:	mov    %rbp,%rdx
  821654:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  821660:	lea    (%rdx,%rcx,1),%r12
  821664:	cmp    %r9,%r12
  821667:	jae    8216a5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  821669:	cmp    %rbx,%rdx
  82166c:	mov    %rdx,%rsi
  82166f:	adc    $0x0,%rsi
  821673:	mov    0x4(%r15,%r12,8),%edi
  821678:	inc    %edi
  82167a:	and    $0xbfffffff,%edi
  821680:	mov    %edi,0x4(%r15,%r12,8)
  821685:	cmp    %rbx,%rdx
  821688:	jae    821692 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1142>
  82168a:	mov    %rsi,%rdx
  82168d:	cmp    %rbx,%rsi
  821690:	jbe    821660 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1110>
  821692:	cmp    %r10,%rax
  821695:	jae    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82169b:	cmp    %r10,%r14
  82169e:	jbe    821640 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  8216a0:	jmp    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8216a5:	lea    0x60e09c(%rip),%rdx        # e2f748 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  8216ac:	mov    %r12,%rdi
  8216af:	mov    %r9,%rsi
  8216b2:	call   *0x65fa58(%rip)        # e81110 <_DYNAMIC+0x4f8>
  8216b8:	lea    0x60e191(%rip),%rdi        # e2f850 <anon.93049d86f4da36fb5b5cebb14659314f.38.llvm.10732147056912049262>
  8216bf:	call   *0x65fb33(%rip)        # e811f8 <_DYNAMIC+0x5e0>
  8216c5:	lea    0x60e064(%rip),%rdx        # e2f730 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  8216cc:	mov    %r12,%rdi
  8216cf:	mov    %r9,%rsi
  8216d2:	call   *0x65fa38(%rip)        # e81110 <_DYNAMIC+0x4f8>
  8216d8:	lea    0x60e099(%rip),%rdx        # e2f778 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x110>
  8216df:	mov    %r12,%rdi
  8216e2:	mov    0xd8(%rsp),%rsi
  8216ea:	call   *0x65fa20(%rip)        # e81110 <_DYNAMIC+0x4f8>
  8216f0:	lea    0x60e069(%rip),%rdx        # e2f760 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf8>
  8216f7:	mov    %r12,%rdi
  8216fa:	mov    %r9,%rsi
  8216fd:	call   *0x65fa0d(%rip)        # e81110 <_DYNAMIC+0x4f8>
