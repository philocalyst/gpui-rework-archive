from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/tmp/gpui-csr-stats-sol');OUT=Path('/tmp/gpui-csr-stats-evidence')
BASE='299c6aca30c1245c15c2da6a5ccabb41dd435d17';CANDIDATE='b3123ea1b4df2d144108d25499780217aac5b470'
def git(*args):return subprocess.check_output(['git','-c','safe.directory='+str(ROOT),'-C',str(ROOT),*args])
def src(ref,name):return git('show',ref+':reactivity/crates/gpu/src/'+name).decode()
def region(s,a,b):return s[s.index(a):s.index(b,s.index(a))]
a=src(BASE,'renderer.rs');b=src(CANDIDATE,'renderer.rs')
paths=git('diff','--name-only',BASE,CANDIDATE,'--','reactivity/crates/gpu/src','reactivity/crates/gpu/build.rs','reactivity/crates/gpu/Cargo.toml').decode().splitlines()
checks={
 'only_renderer_production_file_changed':paths==['reactivity/crates/gpu/src/renderer.rs'],
 'shader_byte_identical':src(BASE,'shader.rs')==src(CANDIDATE,'shader.rs'),
 'coverage_kernel_byte_identical':src(BASE,'renderer/coverage.rs')==src(CANDIDATE,'renderer/coverage.rs'),
 'record_validation_forward_binning_byte_identical':region(a,'        self.records.clear();','        let mut offset = 0;')==region(b,'        self.records.clear();','        let mut offset = 0;'),
 'reverse_resource_CSR_byte_identical':region(a,'        let references = offset as usize;','        let mut uniform_tiles = 0;')==region(b,'        let references = offset as usize;','        let (tone, exposure)'),
 'uploads_publication_and_rest_byte_identical':a[a.index('        let (tone, exposure)'):]==b[b.index('        let (tone, exposure)'):],
 'no_final_tile_stats_walk': 'for (tile, range) in self.ranges.iter().enumerate()' not in b,
 'no_host_tile_end_mask':'TILE_END' not in b,
 'one_counter_path':b.count('sample_draw_evaluations +=')==1,
}
assert all(checks.values()),checks
r={'baseline':BASE,'candidate':CANDIDATE,'checks':checks,'shader_sha256':hashlib.sha256(src(CANDIDATE,'shader.rs').encode()).hexdigest(),'coverage_kernel_sha256':hashlib.sha256(src(CANDIDATE,'renderer/coverage.rs').encode()).hexdigest()}
(OUT/'source-audit.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
