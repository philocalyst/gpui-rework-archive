
FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9931 frame=1512

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e010 <<gpui_gpu::renderer::RendererState>::render>:
  81e010:	push   %rbp
  81e011:	push   %r15
  81e013:	push   %r14
  81e015:	push   %r13
  81e017:	push   %r12
  81e019:	push   %rbx
  81e01a:	sub    $0x5b8,%rsp
  81e021:	mov    0x228(%rsi),%rax
  81e028:	mov    0x18(%rdx),%r9
  81e02c:	cmp    %r9,%rax
  81e02f:	je     81e04d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e031:	mov    0x10(%rax),%r10
  81e035:	cmp    0x10(%r9),%r10
  81e039:	jne    81e11b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e03f:	mov    0x18(%rax),%rax
  81e043:	cmp    0x18(%r9),%rax
  81e047:	jne    81e11b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e04d:	lea    0x330(%rsi),%rbx
  81e054:	mov    0x330(%rsi),%rax
  81e05b:	test   %rax,%rax
  81e05e:	je     81e08d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e060:	lock decq (%rax)
  81e064:	jne    81e08d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e066:	mov    %rdi,%r14
  81e069:	mov    %rbx,%rdi
  81e06c:	mov    %rsi,%r12
  81e06f:	mov    %r8,%r13
  81e072:	mov    %rdx,%r15
  81e075:	mov    %rcx,%rbp
  81e078:	call   *0x663102(%rip)        # e81180 <_DYNAMIC+0x518>
  81e07e:	mov    %rbp,%rcx
  81e081:	mov    %r15,%rdx
  81e084:	mov    %r13,%r8
  81e087:	mov    %r12,%rsi
  81e08a:	mov    %r14,%rdi
  81e08d:	movq   $0x0,0x330(%rsi)
  81e098:	mov    (%rcx),%r13d
  81e09b:	mov    0x8(%rcx),%r9d
  81e09f:	movzbl 0xd(%rcx),%eax
  81e0a3:	test   %r9d,%r9d
  81e0a6:	sets   %r10b
  81e0aa:	and    $0x7fffffff,%r9d
  81e0b1:	lea    -0x800000(%r9),%r11d
  81e0b8:	cmp    $0x7f000000,%r11d
  81e0bf:	setb   %r11b
  81e0c3:	and    %r10b,%r11b
  81e0c6:	lea    -0x1(%r9),%ebp
  81e0ca:	cmp    $0x7fffff,%ebp
  81e0d0:	setb   %bpl
  81e0d4:	and    %r10b,%bpl
  81e0d7:	test   %r9d,%r9d
  81e0da:	sete   %r10b
  81e0de:	cmp    $0x7f800000,%r9d
  81e0e5:	sete   %r14b
  81e0e9:	or     %r10b,%r14b
  81e0ec:	cmp    $0x7f800001,%r9d
  81e0f3:	setge  %r9b
  81e0f7:	or     %r14b,%r9b
  81e0fa:	or     %bpl,%r9b
  81e0fd:	test   %r13d,%r13d
  81e100:	setne  %r10b
  81e104:	and    %al,%r10b
  81e107:	or     %r11b,%r10b
  81e10a:	or     %r9b,%r10b
  81e10d:	test   $0x1,%r10b
  81e111:	je     81e136 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e113:	movl   $0x3,(%rdi)
  81e119:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e11b:	movl   $0x4,(%rdi)
  81e121:	mov    %rdi,%rax
  81e124:	add    $0x5b8,%rsp
  81e12b:	pop    %rbx
  81e12c:	pop    %r12
  81e12e:	pop    %r13
  81e130:	pop    %r14
  81e132:	pop    %r15
  81e134:	pop    %rbp
  81e135:	ret
  81e136:	movd   0x4(%rcx),%xmm2
  81e13b:	movzbl 0xc(%rcx),%ebp
  81e13f:	test   $0x1,%r13b
  81e143:	je     81e1bb <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e145:	movd   %xmm2,%r9d
  81e14a:	test   %r9d,%r9d
  81e14d:	sets   %r10b
  81e151:	and    $0x7fffffff,%r9d
  81e158:	lea    -0x800000(%r9),%r11d
  81e15f:	cmp    $0x7f000000,%r11d
  81e166:	setb   %r11b
  81e16a:	and    %r10b,%r11b
  81e16d:	lea    -0x1(%r9),%r14d
  81e171:	cmp    $0x7fffff,%r14d
  81e178:	setb   %r14b
  81e17c:	and    %r10b,%r14b
  81e17f:	test   %r9d,%r9d
  81e182:	sete   %r10b
  81e186:	cmp    $0x7f800000,%r9d
  81e18d:	sete   %r15b
  81e191:	or     %r10b,%r15b
  81e194:	cmp    $0x7f800001,%r9d
  81e19b:	setge  %r9b
  81e19f:	or     %r15b,%r9b
  81e1a2:	or     %r14b,%r9b
  81e1a5:	or     %r11b,%r9b
  81e1a8:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1ae:	ucomiss -0x76f2a9(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e1b5:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1bb:	mov    0x28(%rcx),%r14d
  81e1bf:	cmp    %r14d,0x20(%r8)
  81e1c3:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1c9:	mov    0x2c(%rcx),%r15d
  81e1cd:	cmp    %r15d,0x24(%r8)
  81e1d1:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1d7:	mov    0x38(%r8),%r12d
  81e1db:	cmp    0x20(%rdx),%r12d
  81e1df:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1e5:	cmp    $0x4c,%r12d
  81e1e9:	jne    81e20e <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e1eb:	movq   0x3c(%r8),%xmm0
  81e1f1:	movq   0x24(%rdx),%xmm1
  81e1f6:	pcmpeqd %xmm0,%xmm1
  81e1fa:	pshufd $0x50,%xmm1,%xmm0
  81e1ff:	movmskpd %xmm0,%r9d
  81e204:	cmp    $0x3,%r9d
  81e208:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e20e:	cmp    $0x4000,%r15d
  81e215:	ja     81e24b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e217:	cmp    $0x4000,%r14d
  81e21e:	ja     81e24b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e220:	mov    %r15,%r9
  81e223:	imul   %r14,%r9
  81e227:	add    $0xfffffffffeffffff,%r9
  81e22e:	cmp    $0xffffffffff000000,%r9
  81e235:	jb     81e24b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e237:	mov    0x10(%rcx),%r11
  81e23b:	mov    0x80(%r11),%r10
  81e242:	cmp    $0x10000,%r10
  81e249:	jbe    81e256 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e24b:	movl   $0x6,(%rdi)
  81e251:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e256:	movd   0x18(%rcx),%xmm0
  81e25b:	movd   %xmm0,%r9d
  81e260:	and    $0x7fffffff,%r9d
  81e267:	cmp    $0x7f7fffff,%r9d
  81e26e:	jg     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e274:	pand   -0x770a8c(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e27c:	ucomiss -0x76f11f(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e283:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e289:	movd   0x1c(%rcx),%xmm0
  81e28e:	movd   %xmm0,%r9d
  81e293:	and    $0x7fffffff,%r9d
  81e29a:	cmp    $0x7f7fffff,%r9d
  81e2a1:	jg     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2a7:	pand   -0x770abf(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e2af:	ucomiss -0x76f152(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e2b6:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2bc:	movd   0x20(%rcx),%xmm0
  81e2c1:	movd   %xmm0,%r9d
  81e2c6:	and    $0x7fffffff,%r9d
  81e2cd:	cmp    $0x7f7fffff,%r9d
  81e2d4:	jg     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2da:	pand   -0x770af2(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e2e2:	ucomiss -0x76f185(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e2e9:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ef:	movd   0x24(%rcx),%xmm0
  81e2f4:	movd   %xmm0,%r9d
  81e2f9:	and    $0x7fffffff,%r9d
  81e300:	cmp    $0x7f7fffff,%r9d
  81e307:	jg     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e30d:	movdqa -0x770b25(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e315:	pand   %xmm0,%xmm1
  81e319:	ucomiss -0x76f1bc(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e320:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e326:	xorps  %xmm1,%xmm1
  81e329:	ucomiss %xmm1,%xmm0
  81e32c:	jb     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e332:	movss  -0x76f55a(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e33a:	ucomiss %xmm0,%xmm1
  81e33d:	jb     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e343:	movzwl 0x30(%rcx),%r9d
  81e348:	mov    %r9w,0x10(%rsp)
  81e34e:	movzwl 0x32(%rcx),%r9d
  81e353:	mov    %r9w,0x18(%rsp)
  81e359:	cmp    $0x28,%r12d
  81e35d:	jne    81e369 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e35f:	test   $0x1,%al
  81e361:	je     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e367:	jmp    81e384 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e369:	test   $0x1,%al
  81e36b:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e371:	ucomiss -0x76f598(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e378:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e37e:	jp     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e384:	mov    %r11,0x38(%rsp)
  81e389:	mov    %r10,0xa8(%rsp)
  81e391:	movss  %xmm1,0x120(%rsp)
  81e39a:	movd   %xmm2,0x298(%rsp)
  81e3a3:	mov    %rdx,0x170(%rsp)
  81e3ab:	mov    %r8,0x4a0(%rsp)
  81e3b3:	mov    %rdi,0x58(%rsp)
  81e3b8:	lea    0xf(%r14),%rax
  81e3bc:	shr    $0x4,%rax
  81e3c0:	lea    0xf(%r15),%r8d
  81e3c4:	shr    $0x4,%r8d
  81e3c8:	lea    0x18(%rsi),%rdi
  81e3cc:	movq   $0x0,0x28(%rsi)
  81e3d4:	mov    %rax,0xa0(%rsp)
  81e3dc:	imul   %eax,%r8d
  81e3e0:	movabs $0x4000000000000000,%rdx
  81e3ea:	mov    %rdi,0x4b0(%rsp)
  81e3f2:	mov    %rsi,0x8(%rsp)
  81e3f7:	mov    %r8,0x30(%rsp)
  81e3fc:	mov    %r8,%rsi
  81e3ff:	mov    %rcx,0x178(%rsp)
  81e407:	call   8238c0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e40c:	mov    0x8(%rsp),%rax
  81e411:	movq   $0x0,0x10(%rax)
  81e419:	mov    0x178(%rsp),%rdi
  81e421:	call   *0x662de9(%rip)        # e81210 <_DYNAMIC+0x5a8>
  81e427:	mov    %rdx,%rcx
  81e42a:	sub    %rax,%rcx
  81e42d:	cmp    $0x300000,%rcx
  81e434:	jbe    81e446 <<gpui_gpu::renderer::RendererState>::render+0x436>
  81e436:	mov    0x58(%rsp),%rdi
  81e43b:	movl   $0x6,(%rdi)
  81e441:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e446:	mov    %rcx,%rdi
  81e449:	shr    $0x3,%rcx
  81e44d:	movabs $0xaaaaaaaaaaaaaaab,%rsi
  81e457:	imul   %rcx,%rsi
  81e45b:	mov    %rsi,0x20(%rsp)
  81e460:	mov    %rax,0x498(%rsp)
  81e468:	mov    %rdx,0x490(%rsp)
  81e470:	cmp    %rax,%rdx
  81e473:	je     81e4a1 <<gpui_gpu::renderer::RendererState>::render+0x491>
  81e475:	mov    $0xaaaaaaab,%eax
  81e47a:	imul   %rax,%rdi
  81e47e:	shr    $0x2a,%rdi
  81e482:	mov    0x20(%rsp),%rcx
  81e487:	mov    %ecx,%eax
  81e489:	and    $0x3f,%eax
  81e48c:	add    %rcx,%rdi
  81e48f:	cmp    $0x1,%rax
  81e493:	sbb    $0xffffffffffffffff,%rdi
  81e497:	inc    %rdi
  81e49a:	mov    %rdi,0x40(%rsp)
  81e49f:	jmp    81e4aa <<gpui_gpu::renderer::RendererState>::render+0x49a>
  81e4a1:	movq   $0x0,0x40(%rsp)
  81e4aa:	mov    0x38(%rsp),%rax
  81e4af:	mov    0x98(%rax),%rcx
  81e4b6:	add    0xb0(%rax),%rcx
  81e4bd:	mov    %rax,0x180(%rsp)
  81e4c5:	movzwl 0x10(%rsp),%eax
  81e4ca:	mov    %ax,0x1a0(%rsp)
  81e4d2:	movzwl 0x18(%rsp),%eax
  81e4d7:	mov    %ax,0x1a2(%rsp)
  81e4df:	movq   $0x0,0x188(%rsp)
  81e4eb:	mov    0xa8(%rsp),%rax
  81e4f3:	mov    %rax,0x190(%rsp)
  81e4fb:	mov    %rcx,0x168(%rsp)
  81e503:	mov    %rcx,0x198(%rsp)
  81e50b:	mov    0x8(%rsp),%rax
  81e510:	movzbl 0x341(%rax),%edx
  81e517:	lea    0x4b8(%rsp),%rdi
  81e51f:	lea    0x180(%rsp),%rsi
  81e527:	call   81c760 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e52c:	mov    0x4b8(%rsp),%eax
  81e533:	cmp    $0xffffffff,%eax
  81e536:	je     81e566 <<gpui_gpu::renderer::RendererState>::render+0x556>
  81e538:	mov    0x4bc(%rsp),%ecx
  81e53f:	mov    0x4c0(%rsp),%rdx
  81e547:	movups 0x4c8(%rsp),%xmm0
  81e54f:	mov    0x58(%rsp),%rdi
  81e554:	movups %xmm0,0x10(%rdi)
  81e558:	mov    %eax,(%rdi)
  81e55a:	mov    %ecx,0x4(%rdi)
  81e55d:	mov    %rdx,0x8(%rdi)
  81e561:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e566:	mov    0x40(%rsp),%rdx
  81e56b:	add    0x4c0(%rsp),%rdx
  81e573:	mov    0x8(%rsp),%rdi
  81e578:	mov    0x10(%rdi),%rsi
  81e57c:	mov    $0x4,%ecx
  81e581:	mov    $0x10,%r8d
  81e587:	call   824ec0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e58c:	cmp    $0xffffffffffffffff,%rax
  81e590:	jne    81e436 <<gpui_gpu::renderer::RendererState>::render+0x426>
  81e596:	movzwl 0x10(%rsp),%eax
  81e59b:	mov    %eax,0x10(%rsp)
  81e59f:	movzwl 0x18(%rsp),%eax
  81e5a4:	mov    %eax,0xdc(%rsp)
  81e5ab:	mov    0x8(%rsp),%rdi
  81e5b0:	mov    0x178(%rsp),%rsi
  81e5b8:	mov    0x20(%rsp),%rdx
  81e5bd:	call   825fb0 <gpui_gpu::renderer::slots::write_prefix>
  81e5c2:	mov    0x8(%rsp),%rax
  81e5c7:	lea    0x48(%rax),%rdi
  81e5cb:	movq   $0x0,0x58(%rax)
  81e5d3:	mov    %rdi,0x4a8(%rsp)
  81e5db:	mov    0x30(%rsp),%rsi
  81e5e0:	xor    %edx,%edx
  81e5e2:	call   8239e0 <<alloc::vec::Vec<u32>>::resize>
  81e5e7:	mov    0x8(%rsp),%rax
  81e5ec:	movq   $0x0,0x70(%rax)
  81e5f4:	cmpq   $0x0,0x60(%rax)
  81e5f9:	jne    81e60a <<gpui_gpu::renderer::RendererState>::render+0x5fa>
  81e5fb:	mov    0x8(%rsp),%rax
  81e600:	lea    0x60(%rax),%rdi
  81e604:	call   *0x662c0e(%rip)        # e81218 <_DYNAMIC+0x5b0>
  81e60a:	mov    0x8(%rsp),%rax
  81e60f:	mov    0x68(%rax),%rcx
  81e613:	xorps  %xmm0,%xmm0
  81e616:	movups %xmm0,0x10(%rcx)
  81e61a:	movups %xmm0,(%rcx)
  81e61d:	movq   $0x1,0x70(%rax)
  81e625:	lea    0x2f8(%rax),%rdi
  81e62c:	call   823310 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e631:	mov    0xdc(%rsp),%ecx
  81e638:	shl    $0x10,%ecx
  81e63b:	add    0x10(%rsp),%ecx
  81e63f:	mov    0x38(%rsp),%rax
  81e644:	mov    %rax,0x2a0(%rsp)
  81e64c:	movq   $0x0,0x2a8(%rsp)
  81e658:	mov    0xa8(%rsp),%rax
  81e660:	mov    %rax,0x2b0(%rsp)
  81e668:	mov    0x168(%rsp),%rax
  81e670:	mov    %rax,0x2b8(%rsp)
  81e678:	mov    %ecx,0xdc(%rsp)
  81e67f:	mov    %ecx,0x2c0(%rsp)
  81e686:	lea    0x2c8(%rsp),%rdi
  81e68e:	lea    0x2a0(%rsp),%rsi
  81e696:	call   *0x662b84(%rip)        # e81220 <_DYNAMIC+0x5b8>
  81e69c:	mov    0x2c8(%rsp),%rax
  81e6a4:	mov    %rax,0x18(%rsp)
  81e6a9:	test   %rax,%rax
  81e6ac:	je     81f3f0 <<gpui_gpu::renderer::RendererState>::render+0x13e0>
  81e6b2:	movq   $0x0,0xf8(%rsp)
  81e6be:	movq   $0x0,0x10(%rsp)
  81e6c7:	movq   $0x0,0x78(%rsp)
  81e6d0:	movq   $0x0,0x270(%rsp)
  81e6dc:	movq   $0x0,0x278(%rsp)
  81e6e8:	mov    0x2d0(%rsp),%rcx
  81e6f0:	mov    0x2d8(%rsp),%rdx
  81e6f8:	mov    %rdx,0xb0(%rsp)
  81e700:	lea    0x2e0(%rsp),%rdi
  81e708:	movups (%rdi),%xmm0
  81e70b:	movups 0x10(%rdi),%xmm1
  81e70f:	movups 0x20(%rdi),%xmm2
  81e713:	movaps %xmm2,0x390(%rsp)
  81e71b:	movaps %xmm1,0x380(%rsp)
  81e723:	movaps %xmm0,0x370(%rsp)
  81e72b:	lea    0x310(%rsp),%r8
  81e733:	movups (%r8),%xmm0
  81e737:	movaps %xmm0,0x470(%rsp)
  81e73f:	movups 0x40(%rdi),%xmm0
  81e743:	movaps %xmm0,0x3b0(%rsp)
  81e74b:	mov    0x8(%rsp),%rax
  81e750:	movzbl 0x341(%rax),%esi
  81e757:	mov    0x18(%rsp),%rax
  81e75c:	mov    %rax,0x180(%rsp)
  81e764:	mov    %rcx,0x30(%rsp)
  81e769:	mov    %rcx,0x188(%rsp)
  81e771:	mov    %rdx,0x190(%rsp)
  81e779:	movups (%rdi),%xmm0
  81e77c:	movups 0x10(%rdi),%xmm1
  81e780:	movups 0x20(%rdi),%xmm2
  81e784:	lea    0x198(%rsp),%rax
  81e78c:	movups %xmm2,0x20(%rax)
  81e790:	movups %xmm1,0x10(%rax)
  81e794:	movups %xmm0,(%rax)
  81e797:	movups (%r8),%xmm0
  81e79b:	movups %xmm0,0x30(%rax)
  81e79f:	movups 0x40(%rdi),%xmm0
  81e7a3:	movups %xmm0,0x40(%rax)
  81e7a7:	lea    0x180(%rsp),%rdi
  81e7af:	call   8218a0 <gpui_gpu::renderer::compact_group>
  81e7b4:	mov    %al,0x40(%rsp)
  81e7b8:	lea    0x2e0(%rsp),%rsi
  81e7c0:	movups (%rsi),%xmm0
  81e7c3:	movups 0x10(%rsi),%xmm1
  81e7c7:	movups 0x20(%rsi),%xmm2
  81e7cb:	movaps %xmm0,0x560(%rsp)
  81e7d3:	movaps %xmm1,0x570(%rsp)
  81e7db:	movaps %xmm2,0x580(%rsp)
  81e7e3:	lea    0x310(%rsp),%rdx
  81e7eb:	movups (%rdx),%xmm0
  81e7ee:	movaps %xmm0,0x590(%rsp)
  81e7f6:	mov    0x8(%rsp),%rdi
  81e7fb:	call   81d390 <<gpui_gpu::renderer::RendererState>::correction>
  81e800:	mov    %eax,0xc8(%rsp)
  81e807:	mov    0xb0(%rsp),%rax
  81e80f:	lea    0x0(,%rax,4),%rax
  81e817:	mov    %rax,0x280(%rsp)
  81e81f:	cmpb   $0x0,0x40(%rsp)
  81e824:	je     81ea07 <<gpui_gpu::renderer::RendererState>::render+0x9f7>
  81e82a:	mov    0x30(%rsp),%rcx
  81e82f:	mov    0xb0(%rsp),%rax
  81e837:	lea    (%rcx,%rax,4),%rax
  81e83b:	mov    %rcx,0x350(%rsp)
  81e843:	mov    %rax,0x358(%rsp)
  81e84b:	mov    0x18(%rsp),%rax
  81e850:	mov    %rax,0x360(%rsp)
  81e858:	movq   $0x0,0x368(%rsp)
  81e864:	lea    0x3f0(%rsp),%rdi
  81e86c:	lea    0x350(%rsp),%rsi
  81e874:	call   821f30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e879:	cmpb   $0xff,0x3f8(%rsp)
  81e881:	je     81ef4c <<gpui_gpu::renderer::RendererState>::render+0xf3c>
  81e887:	xorps  %xmm0,%xmm0
  81e88a:	movaps %xmm0,0x90(%rsp)
  81e892:	movaps %xmm0,0x60(%rsp)
  81e897:	mov    0x3f0(%rsp),%rdx
  81e89f:	add    0x78(%rsp),%rdx
  81e8a4:	lea    0x3f8(%rsp),%rsi
  81e8ac:	movups 0x38(%rsi),%xmm0
  81e8b0:	lea    0x181(%rsp),%rax
  81e8b8:	movups %xmm0,0x37(%rax)
  81e8bc:	movups 0x48(%rsi),%xmm0
  81e8c0:	lea    0x198(%rsp),%rcx
  81e8c8:	movups %xmm0,0x70(%rcx)
  81e8cc:	mov    0x30(%rsi),%rax
  81e8d0:	mov    %rax,0x1b0(%rsp)
  81e8d8:	movups (%rsi),%xmm0
  81e8db:	movups 0x10(%rsi),%xmm1
  81e8df:	movups 0x20(%rsi),%xmm2
  81e8e3:	movaps %xmm2,0x1a0(%rsp)
  81e8eb:	movaps %xmm1,0x190(%rsp)
  81e8f3:	movaps %xmm0,0x180(%rsp)
  81e8fb:	lea    0x2e0(%rsp),%rax
  81e903:	movups 0x40(%rax),%xmm0
  81e907:	movups %xmm0,0x80(%rcx)
  81e90e:	movups (%rax),%xmm0
  81e911:	movups 0x10(%rax),%xmm1
  81e915:	movups 0x20(%rax),%xmm2
  81e919:	movups %xmm2,0x50(%rcx)
  81e91d:	movups %xmm1,0x40(%rcx)
  81e921:	movups %xmm0,0x30(%rcx)
  81e925:	lea    0x310(%rsp),%rax
  81e92d:	movups (%rax),%xmm0
  81e930:	movups %xmm0,0x60(%rcx)
  81e934:	lea    0x3c8(%rsp),%rdi
  81e93c:	lea    0x180(%rsp),%rsi
  81e944:	mov    %r14d,%ecx
  81e947:	mov    %r15d,%r8d
  81e94a:	call   8218f0 <gpui_gpu::renderer::validate_draw>
  81e94f:	mov    0x3c8(%rsp),%ecx
  81e956:	mov    0x3cc(%rsp),%rax
  81e95e:	cmp    $0xffffffff,%ecx
  81e961:	jne    81f4a8 <<gpui_gpu::renderer::RendererState>::render+0x1498>
  81e967:	mov    %eax,%ecx
  81e969:	shr    $0x20,%rax
  81e96d:	movd   %ecx,%xmm0
  81e971:	movaps 0x90(%rsp),%xmm2
  81e979:	movaps %xmm2,%xmm1
  81e97c:	maxss  %xmm0,%xmm1
  81e980:	movaps %xmm1,%xmm3
  81e983:	cmpunordss %xmm1,%xmm3
  81e988:	movaps %xmm3,%xmm0
  81e98b:	andnps %xmm1,%xmm0
  81e98e:	andps  %xmm2,%xmm3
  81e991:	orps   %xmm0,%xmm3
  81e994:	movaps %xmm3,0x40(%rsp)
  81e999:	movd   %eax,%xmm0
  81e99d:	movaps 0x60(%rsp),%xmm2
  81e9a2:	movaps %xmm2,%xmm1
  81e9a5:	maxss  %xmm0,%xmm1
  81e9a9:	movaps %xmm1,%xmm3
  81e9ac:	cmpunordss %xmm1,%xmm3
  81e9b1:	movaps %xmm3,%xmm0
  81e9b4:	andnps %xmm1,%xmm0
  81e9b7:	andps  %xmm2,%xmm3
  81e9ba:	orps   %xmm0,%xmm3
  81e9bd:	movaps %xmm3,0x80(%rsp)
  81e9c5:	lea    0x3f0(%rsp),%rdi
  81e9cd:	lea    0x350(%rsp),%rsi
  81e9d5:	call   821f30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e9da:	cmpb   $0xff,0x3f8(%rsp)
  81e9e2:	movaps 0x40(%rsp),%xmm0
  81e9e7:	movaps %xmm0,0x90(%rsp)
  81e9ef:	movaps 0x80(%rsp),%xmm0
  81e9f7:	movaps %xmm0,0x60(%rsp)
  81e9fc:	jne    81e897 <<gpui_gpu::renderer::RendererState>::render+0x887>
  81ea02:	jmp    81ef5c <<gpui_gpu::renderer::RendererState>::render+0xf4c>
  81ea07:	cmpq   $0x0,0xb0(%rsp)
  81ea10:	je     81f39a <<gpui_gpu::renderer::RendererState>::render+0x138a>
  81ea16:	mov    0xc8(%rsp),%eax
  81ea1d:	or     $0x80000000,%eax
  81ea22:	mov    %eax,0xe0(%rsp)
  81ea29:	movq   $0x0,0x80(%rsp)
  81ea35:	mov    0x30(%rsp),%rax
  81ea3a:	mov    0x80(%rsp),%rcx
  81ea42:	mov    (%rax,%rcx,1),%edx
  81ea45:	lea    0x180(%rsp),%rdi
  81ea4d:	mov    0x18(%rsp),%rsi
  81ea52:	call   81c8b0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81ea57:	movzbl 0x180(%rsp),%edi
  81ea5f:	lea    0x181(%rsp),%rdx
  81ea67:	mov    (%rdx),%eax
  81ea69:	mov    0x3(%rdx),%ecx
  81ea6c:	lea    0x4f0(%rsp),%rsi
  81ea74:	mov    %ecx,-0x34(%rsi)
  81ea77:	mov    %eax,-0x37(%rsi)
  81ea7a:	mov    0x188(%rsp),%rcx
  81ea82:	mov    0x2f(%rdx),%rax
  81ea86:	mov    %rax,-0x8(%rsi)
  81ea8a:	movups 0xf(%rdx),%xmm0
  81ea8e:	movups 0x1f(%rdx),%xmm1
  81ea92:	movups %xmm1,-0x18(%rsi)
  81ea96:	movups %xmm0,-0x28(%rsi)
  81ea9a:	movups 0x37(%rdx),%xmm0
  81ea9e:	movups %xmm0,(%rsi)
  81eaa1:	lea    0x198(%rsp),%rax
  81eaa9:	movups 0x30(%rax),%xmm0
  81eaad:	movups %xmm0,0x50(%rsi)
  81eab1:	lea    0x2e0(%rsp),%rax
  81eab9:	movups 0x40(%rax),%xmm0
  81eabd:	movups %xmm0,0x60(%rsi)
  81eac1:	movups (%rax),%xmm0
  81eac4:	movups 0x10(%rax),%xmm1
  81eac8:	movups 0x20(%rax),%xmm2
  81eacc:	movups %xmm2,0x30(%rsi)
  81ead0:	movups %xmm1,0x20(%rsi)
  81ead4:	movups %xmm0,0x10(%rsi)
  81ead8:	lea    0x310(%rsp),%rax
  81eae0:	movups (%rax),%xmm0
  81eae3:	movups %xmm0,0x40(%rsi)
  81eae7:	mov    %dil,0x60(%rsp)
  81eaec:	mov    %dil,0x4b8(%rsp)
  81eaf4:	mov    %rcx,0x90(%rsp)
  81eafc:	mov    %rcx,0x4c0(%rsp)
  81eb04:	lea    0x180(%rsp),%rdi
  81eb0c:	lea    0x4b8(%rsp),%rsi
  81eb14:	mov    0x78(%rsp),%rdx
  81eb19:	mov    %r14d,%ecx
  81eb1c:	mov    %r15d,%r8d
  81eb1f:	call   8218f0 <gpui_gpu::renderer::validate_draw>
  81eb24:	mov    0x180(%rsp),%eax
  81eb2b:	mov    0x184(%rsp),%rcx
  81eb33:	mov    %rcx,0x40(%rsp)
  81eb38:	cmp    $0xffffffff,%eax
  81eb3b:	jne    81f53b <<gpui_gpu::renderer::RendererState>::render+0x152b>
  81eb41:	movzbl 0x60(%rsp),%eax
  81eb46:	cmp    $0x2,%al
  81eb48:	sete   0xf0(%rsp)
  81eb50:	cmpq   $0x0,0x90(%rsp)
  81eb59:	setne  0xe8(%rsp)
  81eb61:	movups 0x4f0(%rsp),%xmm0
  81eb69:	movaps %xmm0,0x150(%rsp)
  81eb71:	cmp    $0x3,%al
  81eb73:	jne    81ec05 <<gpui_gpu::renderer::RendererState>::render+0xbf5>
  81eb79:	movss  0x4bc(%rsp),%xmm0
  81eb82:	xorps  %xmm1,%xmm1
  81eb85:	ucomiss %xmm1,%xmm0
  81eb88:	jne    81eb8c <<gpui_gpu::renderer::RendererState>::render+0xb7c>
  81eb8a:	jnp    81ec05 <<gpui_gpu::renderer::RendererState>::render+0xbf5>
  81eb8c:	movaps 0x150(%rsp),%xmm5
  81eb94:	movaps %xmm5,%xmm1
  81eb97:	unpckhpd %xmm5,%xmm1
  81eb9b:	movss  -0x76fbd7(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81eba3:	mulss  %xmm4,%xmm1
  81eba7:	movaps %xmm0,%xmm2
  81ebaa:	minss  %xmm1,%xmm2
  81ebae:	movaps %xmm2,%xmm1
  81ebb1:	cmpunordss %xmm2,%xmm1
  81ebb6:	movaps %xmm1,%xmm3
  81ebb9:	andnps %xmm2,%xmm3
  81ebbc:	andps  %xmm0,%xmm1
  81ebbf:	orps   %xmm3,%xmm1
  81ebc2:	movaps %xmm5,%xmm0
  81ebc5:	shufps $0xff,%xmm5,%xmm0
  81ebc9:	mulss  %xmm4,%xmm0
  81ebcd:	movaps %xmm1,%xmm2
  81ebd0:	minss  %xmm0,%xmm2
  81ebd4:	movaps %xmm2,%xmm0
  81ebd7:	cmpunordss %xmm2,%xmm0
  81ebdc:	andps  %xmm0,%xmm1
  81ebdf:	andnps %xmm2,%xmm0
  81ebe2:	orps   %xmm1,%xmm0
  81ebe5:	movd   %xmm0,%eax
  81ebe9:	mov    %eax,0x60(%rsp)
  81ebed:	and    $0xff800000,%eax
  81ebf2:	mov    $0x7f000000,%ecx
  81ebf7:	sub    %eax,%ecx
  81ebf9:	mov    %ecx,0x90(%rsp)
  81ec00:	xorps  %xmm0,%xmm0
  81ec03:	jmp    81ec27 <<gpui_gpu::renderer::RendererState>::render+0xc17>
  81ec05:	mov    0x550(%rsp),%eax
  81ec0c:	mov    %eax,0x60(%rsp)
  81ec10:	mov    0x554(%rsp),%eax
  81ec17:	mov    %eax,0x90(%rsp)
  81ec1e:	movsd  0x558(%rsp),%xmm0
  81ec27:	movaps %xmm0,0x100(%rsp)
  81ec2f:	mov    0x8(%rsp),%rax
  81ec34:	mov    0x10(%rax),%ecx
  81ec37:	mov    $0x80000000,%eax
  81ec3c:	or     %eax,%ecx
  81ec3e:	mov    %ecx,0x140(%rsp)
  81ec45:	movups 0x500(%rsp),%xmm0
  81ec4d:	movaps %xmm0,0x340(%rsp)
  81ec55:	movups 0x508(%rsp),%xmm0
  81ec5d:	movaps %xmm0,0x460(%rsp)
  81ec65:	movsd  0x510(%rsp),%xmm0
  81ec6e:	movaps %xmm0,0x330(%rsp)
  81ec76:	movsd  0x518(%rsp),%xmm0
  81ec7f:	movaps %xmm0,0x450(%rsp)
  81ec87:	movsd  0x520(%rsp),%xmm0
  81ec90:	movsd  %xmm0,0xd0(%rsp)
  81ec99:	movsd  0x528(%rsp),%xmm0
  81eca2:	movsd  %xmm0,0x290(%rsp)
  81ecab:	movups 0x530(%rsp),%xmm0
  81ecb3:	movaps %xmm0,0x130(%rsp)
  81ecbb:	mov    0x18(%rsp),%rax
  81ecc0:	mov    %rax,0x180(%rsp)
  81ecc8:	mov    0x30(%rsp),%rax
  81eccd:	mov    %rax,0x188(%rsp)
  81ecd5:	mov    0xb0(%rsp),%rax
  81ecdd:	mov    %rax,0x190(%rsp)
  81ece5:	movaps 0x370(%rsp),%xmm0
  81eced:	movaps 0x380(%rsp),%xmm1
  81ecf5:	movaps 0x390(%rsp),%xmm2
  81ecfd:	lea    0x198(%rsp),%rax
  81ed05:	movups %xmm2,0x20(%rax)
  81ed09:	movups %xmm1,0x10(%rax)
  81ed0d:	movups %xmm0,(%rax)
  81ed10:	movaps 0x470(%rsp),%xmm0
  81ed18:	movups %xmm0,0x30(%rax)
  81ed1c:	movaps 0x3b0(%rsp),%xmm0
  81ed24:	movups %xmm0,0x40(%rax)
  81ed28:	lea    0x180(%rsp),%rdi
  81ed30:	call   *0x6624f2(%rip)        # e81228 <_DYNAMIC+0x5c0>
  81ed36:	mov    0xc8(%rsp),%ecx
  81ed3d:	mov    %ecx,0x28(%rsp)
  81ed41:	test   %eax,%eax
  81ed43:	je     81ed76 <<gpui_gpu::renderer::RendererState>::render+0xd66>
  81ed45:	mov    0x20(%rsp),%rdi
  81ed4a:	mov    %eax,%esi
  81ed4c:	call   825f70 <gpui_gpu::renderer::slots::color_word>
  81ed51:	mov    %eax,0x60(%rsp)
  81ed55:	xorps  %xmm0,%xmm0
  81ed58:	movaps %xmm0,0x100(%rsp)
  81ed60:	movl   $0x0,0x90(%rsp)
  81ed6b:	mov    0xe0(%rsp),%eax
  81ed72:	mov    %eax,0x28(%rsp)
  81ed76:	mov    0x40(%rsp),%rax
  81ed7b:	shr    $0x20,%rax
  81ed7f:	mov    %rax,0x288(%rsp)
  81ed87:	mov    0x8(%rsp),%rax
  81ed8c:	mov    (%rax),%rcx
  81ed8f:	mov    0x10(%rax),%rsi
  81ed93:	sub    %rsi,%rcx
  81ed96:	cmp    $0x5,%rcx
  81ed9a:	jbe    81ef24 <<gpui_gpu::renderer::RendererState>::render+0xf14>
  81eda0:	movsd  0x290(%rsp),%xmm0
  81eda9:	cvtsd2ss %xmm0,%xmm0
  81edad:	movsd  0xd0(%rsp),%xmm1
  81edb6:	cvtsd2ss %xmm1,%xmm1
  81edba:	movapd 0x460(%rsp),%xmm2
  81edc3:	unpcklpd 0x450(%rsp),%xmm2
  81edcc:	cvtpd2ps %xmm2,%xmm2
  81edd0:	movapd 0x340(%rsp),%xmm3
  81edd9:	unpcklpd 0x330(%rsp),%xmm3
  81ede2:	cvtpd2ps %xmm3,%xmm3
  81ede6:	mov    0x8(%rsp),%rax
  81edeb:	mov    0x8(%rax),%rdx
  81edef:	shl    $0x4,%rsi
  81edf3:	movaps 0x150(%rsp),%xmm4
  81edfb:	movups %xmm4,(%rdx,%rsi,1)
  81edff:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ee05:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ee0b:	mov    0x40(%rsp),%rcx
  81ee10:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ee14:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ee1a:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81ee20:	mov    0x288(%rsp),%rdi
  81ee28:	mov    %edi,0x2c(%rdx,%rsi,1)
  81ee2c:	movaps 0x130(%rsp),%xmm0
  81ee34:	movups %xmm0,0x30(%rdx,%rsi,1)
  81ee39:	mov    0x60(%rsp),%edi
  81ee3d:	mov    %edi,0x40(%rdx,%rsi,1)
  81ee41:	mov    0x90(%rsp),%edi
  81ee48:	mov    %edi,0x44(%rdx,%rsi,1)
  81ee4c:	movaps 0x100(%rsp),%xmm0
  81ee54:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81ee59:	movq   $0x0,0x50(%rdx,%rsi,1)
  81ee62:	movl   $0x0,0x58(%rdx,%rsi,1)
  81ee6a:	mov    0x28(%rsp),%edi
  81ee6e:	mov    %edi,0x5c(%rdx,%rsi,1)
  81ee72:	addq   $0x6,0x10(%rax)
  81ee77:	lea    0x180(%rsp),%rdi
  81ee7f:	mov    %rax,%rsi
  81ee82:	lea    0x4b8(%rsp),%rdx
  81ee8a:	mov    0x140(%rsp),%r8d
  81ee92:	mov    0x78(%rsp),%r9
  81ee97:	push   0xf8(%rsp)
  81ee9e:	push   %r15
  81eea0:	push   %r14
  81eea2:	push   0xb8(%rsp)
  81eea9:	call   8206e0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81eeae:	add    $0x20,%rsp
  81eeb2:	mov    0x180(%rsp),%eax
  81eeb9:	cmp    $0xffffffff,%eax
  81eebc:	jne    81f503 <<gpui_gpu::renderer::RendererState>::render+0x14f3>
  81eec2:	movzbl 0xf0(%rsp),%ecx
  81eeca:	and    0xe8(%rsp),%cl
  81eed1:	mov    0x10(%rsp),%rax
  81eed6:	or     %cl,%al
  81eed8:	mov    %rax,0x10(%rsp)
  81eedd:	mov    0x188(%rsp),%rax
  81eee5:	mov    %rax,0xf8(%rsp)
  81eeed:	incq   0x78(%rsp)
  81eef2:	mov    0x80(%rsp),%rdx
  81eefa:	add    $0x4,%rdx
  81eefe:	mov    0xb0(%rsp),%rax
  81ef06:	lea    0x0(,%rax,4),%rax
  81ef0e:	mov    %rdx,0x80(%rsp)
  81ef16:	cmp    %rdx,%rax
  81ef19:	jne    81ea35 <<gpui_gpu::renderer::RendererState>::render+0xa25>
  81ef1f:	jmp    81f38e <<gpui_gpu::renderer::RendererState>::render+0x137e>
  81ef24:	mov    $0x6,%edx
  81ef29:	mov    $0x4,%ecx
  81ef2e:	mov    $0x10,%r8d
  81ef34:	mov    0x8(%rsp),%rdi
  81ef39:	call   8248b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81ef3e:	mov    0x8(%rsp),%rax
  81ef43:	mov    0x10(%rax),%rsi
  81ef47:	jmp    81eda0 <<gpui_gpu::renderer::RendererState>::render+0xd90>
  81ef4c:	xorps  %xmm0,%xmm0
  81ef4f:	movaps %xmm0,0x80(%rsp)
  81ef57:	movaps %xmm0,0x40(%rsp)
  81ef5c:	mov    0x8(%rsp),%rax
  81ef61:	mov    0x10(%rax),%eax
  81ef64:	mov    %eax,0x100(%rsp)
  81ef6b:	movups 0x2e0(%rsp),%xmm1
  81ef73:	movups 0x2e8(%rsp),%xmm2
  81ef7b:	movsd  0x300(%rsp),%xmm0
  81ef84:	movsd  %xmm0,0x28(%rsp)
  81ef8a:	movsd  0x308(%rsp),%xmm0
  81ef93:	movsd  %xmm0,0x150(%rsp)
  81ef9c:	movups 0x310(%rsp),%xmm0
  81efa4:	movaps %xmm0,0x90(%rsp)
  81efac:	movhps 0x2f0(%rsp),%xmm1
  81efb4:	movaps %xmm1,0x140(%rsp)
  81efbc:	movups 0x320(%rsp),%xmm0
  81efc4:	movaps %xmm0,0x60(%rsp)
  81efc9:	movhps 0x2f8(%rsp),%xmm2
  81efd1:	movaps %xmm2,0x130(%rsp)
  81efd9:	mov    0x18(%rsp),%rax
  81efde:	mov    %rax,0x180(%rsp)
  81efe6:	mov    0x30(%rsp),%rax
  81efeb:	mov    %rax,0x188(%rsp)
  81eff3:	mov    0xb0(%rsp),%rax
  81effb:	mov    %rax,0x190(%rsp)
  81f003:	lea    0x2e0(%rsp),%rax
  81f00b:	movups (%rax),%xmm0
  81f00e:	movups 0x10(%rax),%xmm1
  81f012:	movups 0x20(%rax),%xmm2
  81f016:	lea    0x198(%rsp),%rdx
  81f01e:	movups %xmm2,0x20(%rdx)
  81f022:	movups %xmm1,0x10(%rdx)
  81f026:	movups %xmm0,(%rdx)
  81f029:	lea    0x310(%rsp),%rcx
  81f031:	movups (%rcx),%xmm0
  81f034:	movups %xmm0,0x30(%rdx)
  81f038:	movdqu 0x40(%rax),%xmm0
  81f03d:	movdqu %xmm0,0x40(%rdx)
  81f042:	lea    0x180(%rsp),%rdi
  81f04a:	call   *0x6621d8(%rip)        # e81228 <_DYNAMIC+0x5c0>
  81f050:	test   %eax,%eax
  81f052:	je     81f075 <<gpui_gpu::renderer::RendererState>::render+0x1065>
  81f054:	mov    0x20(%rsp),%rdi
  81f059:	mov    %eax,%esi
  81f05b:	call   825f70 <gpui_gpu::renderer::slots::color_word>
  81f060:	orl    $0x80000000,0xc8(%rsp)
  81f06b:	movd   %eax,%xmm0
  81f06f:	movdqa %xmm0,0x60(%rsp)
  81f075:	mov    0x8(%rsp),%rax
  81f07a:	mov    (%rax),%rcx
  81f07d:	mov    0x10(%rax),%rsi
  81f081:	sub    %rsi,%rcx
  81f084:	cmp    $0x4,%rcx
  81f088:	jbe    81f3c8 <<gpui_gpu::renderer::RendererState>::render+0x13b8>
  81f08e:	cvtpd2ps 0x140(%rsp),%xmm0
  81f097:	cvtpd2ps 0x130(%rsp),%xmm1
  81f0a0:	movsd  0x28(%rsp),%xmm2
  81f0a6:	cvtsd2ss %xmm2,%xmm2
  81f0aa:	movsd  0x150(%rsp),%xmm3
  81f0b3:	cvtsd2ss %xmm3,%xmm3
  81f0b7:	mov    0x8(%rsp),%rax
  81f0bc:	mov    0x8(%rax),%rcx
  81f0c0:	shl    $0x4,%rsi
  81f0c4:	movlpd %xmm0,(%rcx,%rsi,1)
  81f0c9:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f0cf:	movaps 0x40(%rsp),%xmm0
  81f0d4:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f0da:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f0e0:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f0e6:	movaps 0x80(%rsp),%xmm0
  81f0ee:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f0f4:	movaps 0x90(%rsp),%xmm0
  81f0fc:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f101:	movaps 0x60(%rsp),%xmm0
  81f106:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f10b:	mov    0xc8(%rsp),%edx
  81f112:	mov    %edx,0x40(%rcx,%rsi,1)
  81f116:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f11f:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f127:	addq   $0x5,0x10(%rax)
  81f12c:	incq   0x270(%rsp)
  81f134:	mov    0xb0(%rsp),%rax
  81f13c:	add    %rax,0x278(%rsp)
  81f144:	test   %rax,%rax
  81f147:	je     81f39a <<gpui_gpu::renderer::RendererState>::render+0x138a>
  81f14d:	movdqa 0x40(%rsp),%xmm0
  81f153:	movd   %xmm0,%ecx
  81f157:	movdqa 0x80(%rsp),%xmm0
  81f160:	movd   %xmm0,%eax
  81f164:	shl    $0x20,%rax
  81f168:	or     %rax,%rcx
  81f16b:	mov    %rcx,0x28(%rsp)
  81f170:	movq   $0x0,0x40(%rsp)
  81f179:	mov    0x30(%rsp),%rax
  81f17e:	mov    0x40(%rsp),%rcx
  81f183:	mov    (%rax,%rcx,1),%edx
  81f186:	lea    0x3f0(%rsp),%rdi
  81f18e:	mov    0x18(%rsp),%rsi
  81f193:	call   81c8b0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f198:	movzbl 0x3f0(%rsp),%edi
  81f1a0:	lea    0x3f8(%rsp),%rsi
  81f1a8:	mov    -0x7(%rsi),%eax
  81f1ab:	mov    -0x4(%rsi),%ecx
  81f1ae:	lea    0x181(%rsp),%rdx
  81f1b6:	mov    %ecx,0x3(%rdx)
  81f1b9:	mov    %eax,(%rdx)
  81f1bb:	mov    0x3f8(%rsp),%rcx
  81f1c3:	mov    0x28(%rsi),%rax
  81f1c7:	mov    %rax,0x2f(%rdx)
  81f1cb:	movups 0x8(%rsi),%xmm0
  81f1cf:	movups 0x18(%rsi),%xmm1
  81f1d3:	movups %xmm1,0x1f(%rdx)
  81f1d7:	movups %xmm0,0xf(%rdx)
  81f1db:	movups 0x428(%rsp),%xmm1
  81f1e3:	movups 0x40(%rsi),%xmm0
  81f1e7:	lea    0x198(%rsp),%rax
  81f1ef:	movups %xmm0,0x70(%rax)
  81f1f3:	movaps 0x3b0(%rsp),%xmm0
  81f1fb:	movups %xmm0,0x80(%rax)
  81f202:	movaps %xmm1,0xb0(%rsp)
  81f20a:	movups %xmm1,0x1b8(%rsp)
  81f212:	movaps 0x560(%rsp),%xmm0
  81f21a:	movaps 0x570(%rsp),%xmm1
  81f222:	movapd 0x580(%rsp),%xmm2
  81f22b:	movupd %xmm2,0x50(%rax)
  81f230:	movups %xmm1,0x40(%rax)
  81f234:	movups %xmm0,0x30(%rax)
  81f238:	movaps 0x590(%rsp),%xmm0
  81f240:	movups %xmm0,0x60(%rax)
  81f244:	mov    %dil,0x60(%rsp)
  81f249:	mov    %dil,0x180(%rsp)
  81f251:	mov    %rcx,0x90(%rsp)
  81f259:	mov    %rcx,0x188(%rsp)
  81f261:	mov    0x8(%rsp),%rax
  81f266:	mov    (%rax),%rcx
  81f269:	mov    0x10(%rax),%rax
  81f26d:	sub    %rax,%rcx
  81f270:	mov    %rax,0x80(%rsp)
  81f278:	cmp    $0x1,%rcx
  81f27c:	jbe    81f35e <<gpui_gpu::renderer::RendererState>::render+0x134e>
  81f282:	mov    0x8(%rsp),%rsi
  81f287:	mov    0x8(%rsi),%rcx
  81f28b:	shl    $0x4,%rax
  81f28f:	movaps 0xb0(%rsp),%xmm0
  81f297:	movups %xmm0,(%rcx,%rax,1)
  81f29b:	movq   $0x0,0x10(%rcx,%rax,1)
  81f2a4:	movl   $0x0,0x18(%rcx,%rax,1)
  81f2ac:	mov    0x100(%rsp),%edx
  81f2b3:	mov    %edx,0x1c(%rcx,%rax,1)
  81f2b7:	addq   $0x2,0x10(%rsi)
  81f2bc:	lea    0x3f0(%rsp),%rdi
  81f2c4:	lea    0x180(%rsp),%rdx
  81f2cc:	mov    0x28(%rsp),%rcx
  81f2d1:	mov    0x80(%rsp),%r8
  81f2d9:	mov    0x78(%rsp),%r9
  81f2de:	push   0xf8(%rsp)
  81f2e5:	push   %r15
  81f2e7:	push   %r14
  81f2e9:	push   0xb8(%rsp)
  81f2f0:	call   8206e0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f2f5:	add    $0x20,%rsp
  81f2f9:	mov    0x3f0(%rsp),%eax
  81f300:	cmp    $0xffffffff,%eax
  81f303:	jne    81f51f <<gpui_gpu::renderer::RendererState>::render+0x150f>
  81f309:	cmpb   $0x2,0x60(%rsp)
  81f30e:	sete   %al
  81f311:	cmpq   $0x0,0x90(%rsp)
  81f31a:	setne  %cl
  81f31d:	and    %al,%cl
  81f31f:	mov    0x10(%rsp),%rax
  81f324:	or     %cl,%al
  81f326:	mov    %rax,0x10(%rsp)
  81f32b:	mov    0x3f8(%rsp),%rax
  81f333:	mov    %rax,0xf8(%rsp)
  81f33b:	incq   0x78(%rsp)
  81f340:	mov    0x40(%rsp),%rcx
  81f345:	add    $0x4,%rcx
  81f349:	mov    %rcx,0x40(%rsp)
  81f34e:	cmp    %rcx,0x280(%rsp)
  81f356:	jne    81f179 <<gpui_gpu::renderer::RendererState>::render+0x1169>
  81f35c:	jmp    81f38e <<gpui_gpu::renderer::RendererState>::render+0x137e>
  81f35e:	mov    $0x2,%edx
  81f363:	mov    $0x4,%ecx
  81f368:	mov    $0x10,%r8d
  81f36e:	mov    0x8(%rsp),%rdi
  81f373:	mov    0x80(%rsp),%rsi
  81f37b:	call   8248b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f380:	mov    0x8(%rsp),%rax
  81f385:	mov    0x10(%rax),%rax
  81f389:	jmp    81f282 <<gpui_gpu::renderer::RendererState>::render+0x1272>
  81f38e:	mov    0x10(%rsp),%rax
  81f393:	and    $0x1,%al
  81f395:	mov    %rax,0x10(%rsp)
  81f39a:	lea    0x2c8(%rsp),%rdi
  81f3a2:	lea    0x2a0(%rsp),%rsi
  81f3aa:	call   *0x661e70(%rip)        # e81220 <_DYNAMIC+0x5b8>
  81f3b0:	mov    0x2c8(%rsp),%rax
  81f3b8:	mov    %rax,0x18(%rsp)
  81f3bd:	test   %rax,%rax
  81f3c0:	jne    81e6e8 <<gpui_gpu::renderer::RendererState>::render+0x6d8>
  81f3c6:	jmp    81f426 <<gpui_gpu::renderer::RendererState>::render+0x1416>
  81f3c8:	mov    $0x5,%edx
  81f3cd:	mov    $0x4,%ecx
  81f3d2:	mov    $0x10,%r8d
  81f3d8:	mov    0x8(%rsp),%rdi
  81f3dd:	call   8248b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f3e2:	mov    0x8(%rsp),%rax
  81f3e7:	mov    0x10(%rax),%rsi
  81f3eb:	jmp    81f08e <<gpui_gpu::renderer::RendererState>::render+0x107e>
  81f3f0:	movq   $0x0,0x278(%rsp)
  81f3fc:	movq   $0x0,0x270(%rsp)
  81f408:	movq   $0x0,0x78(%rsp)
  81f411:	movq   $0x0,0x10(%rsp)
  81f41a:	movq   $0x0,0xf8(%rsp)
  81f426:	mov    0x170(%rsp),%rsi
  81f42e:	lea    0x8(%rsi),%rdx
  81f432:	mov    0x8(%rsp),%rax
  81f437:	lea    0x258(%rax),%rcx
  81f43e:	lea    0x328(%rax),%r8
  81f445:	mov    0x10(%rax),%r9
  81f449:	sub    $0x8,%rsp
  81f44d:	lea    0x188(%rsp),%rdi
  81f455:	mov    %rdx,0x288(%rsp)
  81f45d:	mov    %rcx,0xd0(%rsp)
  81f465:	mov    %r8,0x298(%rsp)
  81f46d:	push   0x180(%rsp)
  81f474:	call   823b30 <gpui_gpu::renderer::images::prepare>
  81f479:	add    $0x10,%rsp
  81f47d:	cmpl   $0xffffffff,0x180(%rsp)
  81f485:	je     81f4ce <<gpui_gpu::renderer::RendererState>::render+0x14be>
  81f487:	movups 0x180(%rsp),%xmm0
  81f48f:	movups 0x190(%rsp),%xmm1
  81f497:	mov    0x58(%rsp),%rdi
  81f49c:	movups %xmm1,0x10(%rdi)
  81f4a0:	movups %xmm0,(%rdi)
  81f4a3:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f4a8:	mov    0x3e4(%rsp),%edx
  81f4af:	mov    0x58(%rsp),%rdi
  81f4b4:	mov    %edx,0x1c(%rdi)
  81f4b7:	movups 0x3d4(%rsp),%xmm0
  81f4bf:	movups %xmm0,0xc(%rdi)
  81f4c3:	mov    %ecx,(%rdi)
  81f4c5:	mov    %rax,0x4(%rdi)
  81f4c9:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f4ce:	movzbl 0x10(%rsp),%r8d
  81f4d4:	and    $0x1,%r8d
  81f4d8:	lea    0x180(%rsp),%rdi
  81f4e0:	mov    0x8(%rsp),%rsi
  81f4e5:	mov    0x170(%rsp),%rdx
  81f4ed:	mov    0x38(%rsp),%rcx
  81f4f2:	call   81d770 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f4f7:	mov    0x180(%rsp),%eax
  81f4fe:	cmp    $0xffffffff,%eax
  81f501:	je     81f566 <<gpui_gpu::renderer::RendererState>::render+0x1556>
  81f503:	mov    0x184(%rsp),%ecx
  81f50a:	mov    0x188(%rsp),%rdx
  81f512:	movups 0x190(%rsp),%xmm0
  81f51a:	jmp    81e54f <<gpui_gpu::renderer::RendererState>::render+0x53f>
  81f51f:	mov    0x3f4(%rsp),%ecx
  81f526:	mov    0x3f8(%rsp),%rdx
  81f52e:	movups 0x400(%rsp),%xmm0
  81f536:	jmp    81e54f <<gpui_gpu::renderer::RendererState>::render+0x53f>
  81f53b:	mov    0x19c(%rsp),%ecx
  81f542:	mov    0x58(%rsp),%rdi
  81f547:	mov    %ecx,0x1c(%rdi)
  81f54a:	movups 0x18c(%rsp),%xmm0
  81f552:	movups %xmm0,0xc(%rdi)
  81f556:	mov    %eax,(%rdi)
  81f558:	mov    0x40(%rsp),%rax
  81f55d:	mov    %rax,0x4(%rdi)
  81f561:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f566:	cmpl   $0x0,0xa0(%rsp)
  81f56e:	je     820655 <<gpui_gpu::renderer::RendererState>::render+0x2645>
  81f574:	mov    0x188(%rsp),%rax
  81f57c:	mov    %rax,0x488(%rsp)
  81f584:	mov    0x8(%rsp),%rax
  81f589:	movdqu 0x20(%rax),%xmm0
  81f58e:	movups 0x50(%rax),%xmm1
  81f592:	movdqu %xmm0,0x2c8(%rsp)
  81f59b:	mov    0xa0(%rsp),%rax
  81f5a3:	mov    %rax,0x2d8(%rsp)
  81f5ab:	movups %xmm1,0x180(%rsp)
  81f5b3:	mov    %rax,0x190(%rsp)
  81f5bb:	lea    0x3f0(%rsp),%rdi
  81f5c3:	lea    0x2c8(%rsp),%rsi
  81f5cb:	lea    0x180(%rsp),%rdx
  81f5d3:	call   825d90 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunksMut<[u32; 2]>, core::slice::iter::Chunks<u32>> as core::iter::adapters::zip::ZipImpl<core::slice::iter::ChunksMut<[u32; 2]>, core::slice::iter::Chunks<u32>>>::new>
  81f5d8:	mov    0x420(%rsp),%rax
  81f5e0:	mov    0x428(%rsp),%rcx
  81f5e8:	mov    %rax,0x80(%rsp)
  81f5f0:	mov    %rcx,0x150(%rsp)
  81f5f8:	cmp    %rcx,%rax
  81f5fb:	jae    81f902 <<gpui_gpu::renderer::RendererState>::render+0x18f2>
  81f601:	mov    0x408(%rsp),%rax
  81f609:	movq   $0x0,0xe0(%rsp)
  81f615:	test   %rax,%rax
  81f618:	je     81f90e <<gpui_gpu::renderer::RendererState>::render+0x18fe>
  81f61e:	mov    0x3f0(%rsp),%rcx
  81f626:	mov    0x3f8(%rsp),%rdi
  81f62e:	mov    0x400(%rsp),%r8
  81f636:	mov    0x410(%rsp),%r9
  81f63e:	mov    0x418(%rsp),%r10
  81f646:	mov    0x80(%rsp),%rsi
  81f64e:	mov    %rsi,%rdx
  81f651:	imul   %r8,%rdx
  81f655:	lea    (%rcx,%rdx,4),%rcx
  81f659:	mov    %rcx,0x20(%rsp)
  81f65e:	mov    %r8,0x90(%rsp)
  81f666:	lea    0x0(,%r8,4),%rcx
  81f66e:	mov    %rcx,0x340(%rsp)
  81f676:	mov    %rsi,%rcx
  81f679:	imul   %r10,%rcx
  81f67d:	lea    (%rax,%rcx,8),%rax
  81f681:	add    $0x4,%rax
  81f685:	mov    %rax,0x10(%rsp)
  81f68a:	mov    %r10,0x100(%rsp)
  81f692:	lea    0x0(,%r10,8),%rax
  81f69a:	mov    %rax,0x330(%rsp)
  81f6a2:	mov    %r9,0x130(%rsp)
  81f6aa:	sub    %rcx,%r9
  81f6ad:	mov    %r9,0xb0(%rsp)
  81f6b5:	mov    %rdi,0x140(%rsp)
  81f6bd:	sub    %rdx,%rdi
  81f6c0:	mov    %rdi,0x60(%rsp)
  81f6c5:	movq   $0x0,0xd0(%rsp)
  81f6d1:	movq   $0x0,0xf0(%rsp)
  81f6dd:	movq   $0x0,0xe8(%rsp)
  81f6e9:	movl   $0x0,0x18(%rsp)
  81f6f1:	movl   $0x0,0x28(%rsp)
  81f6f9:	jmp    81f764 <<gpui_gpu::renderer::RendererState>::render+0x1754>
  81f6fb:	mov    0x80(%rsp),%rax
  81f703:	inc    %rax
  81f706:	incl   0x28(%rsp)
  81f70a:	mov    0x340(%rsp),%rcx
  81f712:	add    %rcx,0x20(%rsp)
  81f717:	mov    0x330(%rsp),%rcx
  81f71f:	add    %rcx,0x10(%rsp)
  81f724:	mov    0xb0(%rsp),%rcx
  81f72c:	sub    0x100(%rsp),%rcx
  81f734:	mov    %rcx,0xb0(%rsp)
  81f73c:	mov    0x60(%rsp),%rcx
  81f741:	sub    0x90(%rsp),%rcx
  81f749:	mov    %rcx,0x60(%rsp)
  81f74e:	mov    %rax,0x80(%rsp)
  81f756:	cmp    0x150(%rsp),%rax
  81f75e:	je     81f934 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f764:	mov    0x90(%rsp),%rsi
  81f76c:	mov    0x100(%rsp),%rdi
  81f774:	cmp    %rsi,%rdi
  81f777:	mov    %rsi,%rcx
  81f77a:	cmovb  %rdi,%rcx
  81f77e:	mov    0xb0(%rsp),%rax
  81f786:	cmp    %rax,%rcx
  81f789:	cmovae %rax,%rcx
  81f78d:	mov    0x60(%rsp),%rax
  81f792:	cmp    %rax,%rcx
  81f795:	cmovae %rax,%rcx
  81f799:	mov    %rcx,0x30(%rsp)
  81f79e:	mov    0x80(%rsp),%rcx
  81f7a6:	mov    %rcx,%rax
  81f7a9:	imul   %rdi,%rax
  81f7ad:	imul   %rsi,%rcx
  81f7b1:	mov    0x140(%rsp),%rdx
  81f7b9:	sub    %rcx,%rdx
  81f7bc:	cmp    %rdx,%rsi
  81f7bf:	cmovb  %rsi,%rdx
  81f7c3:	mov    0x130(%rsp),%rcx
  81f7cb:	sub    %rax,%rcx
  81f7ce:	cmp    %rcx,%rdi
  81f7d1:	cmovb  %rdi,%rcx
  81f7d5:	mov    0x28(%rsp),%eax
  81f7d9:	shl    $0x4,%eax
  81f7dc:	mov    %r15d,%esi
  81f7df:	sub    %eax,%esi
  81f7e1:	cmp    $0x10,%esi
  81f7e4:	mov    $0x10,%eax
  81f7e9:	cmovae %eax,%esi
  81f7ec:	mov    %esi,0x40(%rsp)
  81f7f0:	cmp    %rcx,%rdx
  81f7f3:	cmovb  %rdx,%rcx
  81f7f7:	test   %rcx,%rcx
  81f7fa:	je     81f6fb <<gpui_gpu::renderer::RendererState>::render+0x16eb>
  81f800:	mov    %r14d,%ecx
  81f803:	xor    %edi,%edi
  81f805:	jmp    81f8a2 <<gpui_gpu::renderer::RendererState>::render+0x1892>
  81f80a:	test   %r10d,%r10d
  81f80d:	je     81f867 <<gpui_gpu::renderer::RendererState>::render+0x1857>
  81f80f:	cmp    $0x10,%ecx
  81f812:	mov    $0x10,%r9d
  81f818:	cmovb  %ecx,%r9d
  81f81c:	imul   0x40(%rsp),%r9d
  81f822:	mov    %r9,%rsi
  81f825:	shl    $0x4,%rsi
  81f829:	test   %edx,%edx
  81f82b:	cmovne %r9,%rsi
  81f82f:	add    %rsi,0xf0(%rsp)
  81f837:	xor    %r11d,%r11d
  81f83a:	test   %r8d,%r8d
  81f83d:	setne  %r11b
  81f841:	mov    $0x0,%eax
  81f846:	cmove  %rax,%r9
  81f84a:	mov    %r10,%rax
  81f84d:	sub    %r11,%rax
  81f850:	imul   %rsi,%rax
  81f854:	add    0xd0(%rsp),%r9
  81f85c:	add    %rax,%r9
  81f85f:	mov    %r9,0xd0(%rsp)
  81f867:	xor    %r9d,%r9d
  81f86a:	test   %r8d,%r8d
  81f86d:	setne  %r9b
  81f871:	mov    0x18(%rsp),%esi
  81f875:	add    %r10d,%esi
  81f878:	shl    $0x1d,%r9d
  81f87c:	or     %esi,%edx
  81f87e:	or     %r9d,%edx
  81f881:	mov    0x10(%rsp),%rax
  81f886:	mov    %esi,0x18(%rsp)
  81f88a:	mov    %esi,-0x4(%rax,%rdi,8)
  81f88e:	mov    %edx,(%rax,%rdi,8)
  81f891:	inc    %rdi
  81f894:	add    $0xfffffff0,%ecx
  81f897:	cmp    %rdi,0x30(%rsp)
  81f89c:	je     81f6fb <<gpui_gpu::renderer::RendererState>::render+0x16eb>
  81f8a2:	mov    0x20(%rsp),%rax
  81f8a7:	mov    (%rax,%rdi,4),%r8d
  81f8ab:	mov    0x10(%rsp),%rax
  81f8b0:	mov    (%rax,%rdi,8),%r10d
  81f8b4:	mov    %r10d,%edx
  81f8b7:	and    $0x40000000,%edx
  81f8bd:	and    $0xbfffffff,%r10d
  81f8c4:	test   %r8d,%r8d
  81f8c7:	je     81f80a <<gpui_gpu::renderer::RendererState>::render+0x17fa>
  81f8cd:	test   %r10d,%r10d
  81f8d0:	je     81f867 <<gpui_gpu::renderer::RendererState>::render+0x1857>
  81f8d2:	cmp    $0x1,%r10d
  81f8d6:	jne    81f80f <<gpui_gpu::renderer::RendererState>::render+0x17ff>
  81f8dc:	mov    0x10(%rsp),%rax
  81f8e1:	movl   $0x80000000,(%rax,%rdi,8)
  81f8e8:	incq   0xe8(%rsp)
  81f8f0:	inc    %rdi
  81f8f3:	add    $0xfffffff0,%ecx
  81f8f6:	cmp    %rdi,0x30(%rsp)
  81f8fb:	jne    81f8a2 <<gpui_gpu::renderer::RendererState>::render+0x1892>
  81f8fd:	jmp    81f6fb <<gpui_gpu::renderer::RendererState>::render+0x16eb>
  81f902:	movq   $0x0,0xe0(%rsp)
  81f90e:	movq   $0x0,0xe8(%rsp)
  81f91a:	movq   $0x0,0xf0(%rsp)
  81f926:	movq   $0x0,0xd0(%rsp)
  81f932:	jmp    81f940 <<gpui_gpu::renderer::RendererState>::render+0x1930>
  81f934:	mov    0x18(%rsp),%eax
  81f938:	mov    %rax,0xe0(%rsp)
  81f940:	mov    0x8(%rsp),%rax
  81f945:	lea    0x30(%rax),%rdi
  81f949:	movq   $0x0,0x40(%rax)
  81f951:	movl   $0x0,0x11c(%rsp)
  81f95c:	mov    %rdi,0x450(%rsp)
  81f964:	mov    0xe0(%rsp),%rsi
  81f96c:	xor    %edx,%edx
  81f96e:	call   8239e0 <<alloc::vec::Vec<u32>>::resize>
  81f973:	mov    0x8(%rsp),%rax
  81f978:	mov    0x10(%rax),%rax
  81f97c:	mov    %rax,0x20(%rsp)
  81f981:	mov    0x78(%rsp),%rax
  81f986:	mov    %rax,0x3a8(%rsp)
  81f98e:	mov    0x38(%rsp),%rax
  81f993:	mov    %rax,0x3c8(%rsp)
  81f99b:	movq   $0x0,0x3d0(%rsp)
  81f9a7:	mov    0xa8(%rsp),%rax
  81f9af:	mov    %rax,0x3d8(%rsp)
  81f9b7:	mov    0x168(%rsp),%rax
  81f9bf:	mov    %rax,0x3e0(%rsp)
  81f9c7:	mov    0xdc(%rsp),%eax
  81f9ce:	mov    %eax,0x3e8(%rsp)
  81f9d5:	lea    0x2c8(%rsp),%rdi
  81f9dd:	lea    0x3c8(%rsp),%rsi
  81f9e5:	call   *0x661845(%rip)        # e81230 <_DYNAMIC+0x5c8>
  81f9eb:	mov    0x2c8(%rsp),%rax
  81f9f3:	mov    %rax,0x130(%rsp)
  81f9fb:	test   %rax,%rax
  81f9fe:	je     82003e <<gpui_gpu::renderer::RendererState>::render+0x202e>
  81fa04:	mov    0x8(%rsp),%rax
  81fa09:	add    $0x120,%rax
  81fa0f:	mov    %rax,0x288(%rsp)
  81fa17:	jmp    81fa62 <<gpui_gpu::renderer::RendererState>::render+0x1a52>
  81fa19:	mov    0x20(%rsp),%rcx
  81fa1e:	lea    -0x5(%rcx),%rax
  81fa22:	cmpb   $0x0,0x140(%rsp)
  81fa2a:	cmovne %rax,%rcx
  81fa2e:	mov    %rcx,0x20(%rsp)
  81fa33:	lea    0x2c8(%rsp),%rdi
  81fa3b:	lea    0x3c8(%rsp),%rsi
  81fa43:	call   *0x6617e7(%rip)        # e81230 <_DYNAMIC+0x5c8>
  81fa49:	mov    0x2c8(%rsp),%rax
  81fa51:	mov    %rax,0x130(%rsp)
  81fa59:	test   %rax,%rax
  81fa5c:	je     82003e <<gpui_gpu::renderer::RendererState>::render+0x202e>
  81fa62:	mov    0x2d0(%rsp),%rdi
  81fa6a:	mov    0x2d8(%rsp),%r8
  81fa72:	mov    %r8,0x30(%rsp)
  81fa77:	lea    0x2e0(%rsp),%rcx
  81fa7f:	movups (%rcx),%xmm0
  81fa82:	movups 0x10(%rcx),%xmm1
  81fa86:	movups 0x20(%rcx),%xmm2
  81fa8a:	movaps %xmm2,0x390(%rsp)
  81fa92:	movaps %xmm1,0x380(%rsp)
  81fa9a:	movaps %xmm0,0x370(%rsp)
  81faa2:	lea    0x310(%rsp),%rdx
  81faaa:	movups (%rdx),%xmm0
  81faad:	movaps %xmm0,0x3b0(%rsp)
  81fab5:	movups 0x40(%rcx),%xmm0
  81fab9:	movaps %xmm0,0x5a0(%rsp)
  81fac1:	mov    0x8(%rsp),%rax
  81fac6:	movzbl 0x341(%rax),%esi
  81facd:	mov    0x130(%rsp),%rax
  81fad5:	mov    %rax,0x180(%rsp)
  81fadd:	mov    %rdi,0x340(%rsp)
  81fae5:	mov    %rdi,0x188(%rsp)
  81faed:	mov    %r8,0x190(%rsp)
  81faf5:	movups (%rcx),%xmm0
  81faf8:	movups 0x10(%rcx),%xmm1
  81fafc:	movups 0x20(%rcx),%xmm2
  81fb00:	lea    0x198(%rsp),%rax
  81fb08:	movups %xmm2,0x20(%rax)
  81fb0c:	movups %xmm1,0x10(%rax)
  81fb10:	movups %xmm0,(%rax)
  81fb13:	movups (%rdx),%xmm0
  81fb16:	movups %xmm0,0x30(%rax)
  81fb1a:	movdqu 0x40(%rcx),%xmm0
  81fb1f:	movdqu %xmm0,0x40(%rax)
  81fb24:	lea    0x180(%rsp),%rdi
  81fb2c:	call   8218a0 <gpui_gpu::renderer::compact_group>
  81fb31:	mov    %al,0x140(%rsp)
  81fb38:	mov    0x30(%rsp),%rax
  81fb3d:	test   %rax,%rax
  81fb40:	je     81fa19 <<gpui_gpu::renderer::RendererState>::render+0x1a09>
  81fb46:	mov    %rax,%rdx
  81fb49:	shl    $0x2,%rdx
  81fb4d:	movzbl 0x140(%rsp),%eax
  81fb55:	lea    0x0(,%rax,4),%esi
  81fb5c:	or     $0xfffffffffffffffa,%rsi
  81fb60:	xor    $0x1,%al
  81fb62:	movzbl %al,%eax
  81fb65:	lea    0x1(,%rax,4),%rcx
  81fb6d:	mov    %rcx,0x168(%rsp)
  81fb75:	mov    0x20(%rsp),%rcx
  81fb7a:	lea    (%rsi,%rcx,1),%edi
  81fb7d:	lea    (%rsi,%rax,4),%rax
  81fb81:	inc    %rax
  81fb84:	mov    %rax,0x330(%rsp)
  81fb8c:	add    %rax,%rcx
  81fb8f:	shl    $0x4,%rcx
  81fb93:	mov    %rsi,0x40(%rsp)
  81fb98:	shl    $0x4,%rsi
  81fb9c:	mov    %rsi,0x460(%rsp)
  81fba4:	mov    %rcx,0x18(%rsp)
  81fba9:	mov    %edi,0x10(%rsp)
  81fbad:	mov    0x340(%rsp),%rax
  81fbb5:	mov    %rdx,0x30(%rsp)
  81fbba:	mov    -0x4(%rax,%rdx,1),%edx
  81fbbe:	lea    0x180(%rsp),%rdi
  81fbc6:	mov    0x130(%rsp),%rsi
  81fbce:	call   81c8b0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fbd3:	movzbl 0x180(%rsp),%ecx
  81fbdb:	movzbl 0x181(%rsp),%eax
  81fbe3:	mov    %al,0xa8(%rsp)
  81fbea:	movzwl 0x182(%rsp),%eax
  81fbf2:	mov    %ax,0x60(%rsp)
  81fbf7:	movss  0x184(%rsp),%xmm4
  81fc00:	lea    0x188(%rsp),%rdx
  81fc08:	mov    0x10(%rdx),%rax
  81fc0c:	mov    %rax,0x360(%rsp)
  81fc14:	movups (%rdx),%xmm0
  81fc17:	movaps %xmm0,0x350(%rsp)
  81fc1f:	mov    0x1a0(%rsp),%rax
  81fc27:	mov    %rax,0x38(%rsp)
  81fc2c:	mov    0x1a8(%rsp),%r10d
  81fc34:	mov    0x1ac(%rsp),%r11d
  81fc3c:	movups 0x1b0(%rsp),%xmm0
  81fc44:	movaps %xmm0,0x90(%rsp)
  81fc4c:	mov    0x1b0(%rsp),%rax
  81fc54:	movsd  0x1c0(%rsp),%xmm5
  81fc5d:	lea    0x198(%rsp),%rdx
  81fc65:	movups 0x30(%rdx),%xmm0
  81fc69:	movaps %xmm0,0x470(%rsp)
  81fc71:	decq   0x3a8(%rsp)
  81fc79:	cmp    $0x1,%ecx
  81fc7c:	mov    %ecx,0xb0(%rsp)
  81fc83:	movaps %xmm5,0x80(%rsp)
  81fc8b:	je     81fd24 <<gpui_gpu::renderer::RendererState>::render+0x1d14>
  81fc91:	mov    %r11d,0x28(%rsp)
  81fc96:	mov    %r10d,0x100(%rsp)
  81fc9e:	movaps %xmm4,0x150(%rsp)
  81fca6:	cmp    $0x3,%ecx
  81fca9:	jne    81fda1 <<gpui_gpu::renderer::RendererState>::render+0x1d91>
  81fcaf:	mov    0x290(%rsp),%rax
  81fcb7:	mov    (%rax),%rdi
  81fcba:	test   %rdi,%rdi
  81fcbd:	je     820648 <<gpui_gpu::renderer::RendererState>::render+0x2638>
  81fcc3:	movzbl 0xa8(%rsp),%edx
  81fccb:	mov    0x38(%rsp),%rsi
  81fcd0:	call   8237c0 <<gpui_gpu::renderer::images::Images>::metadata>
  81fcd5:	mov    %eax,%ecx
  81fcd7:	shr    $0x20,%rax
  81fcdb:	mov    %eax,%edx
  81fcdd:	or     $0x10,%edx
  81fce0:	xorps  %xmm0,%xmm0
  81fce3:	movaps 0x150(%rsp),%xmm4
  81fceb:	ucomiss %xmm0,%xmm4
  81fcee:	cmovne %edx,%eax
  81fcf1:	cmovp  %edx,%eax
  81fcf4:	mov    0x28(%rsp),%r11d
  81fcf9:	mov    %r11d,%edx
  81fcfc:	shl    $0x10,%edx
  81fcff:	mov    0x100(%rsp),%r10d
  81fd07:	or     %r10d,%edx
  81fd0a:	mov    %ecx,0x124(%rsp)
  81fd11:	mov    %eax,0x128(%rsp)
  81fd18:	mov    %edx,0x12c(%rsp)
  81fd1f:	jmp    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1e43>
  81fd24:	movaps %xmm5,%xmm0
  81fd27:	movss  -0x770d63(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81fd2f:	mulss  %xmm3,%xmm0
  81fd33:	movaps %xmm4,%xmm1
  81fd36:	minss  %xmm0,%xmm1
  81fd3a:	movaps %xmm1,%xmm0
  81fd3d:	cmpunordss %xmm1,%xmm0
  81fd42:	movaps %xmm0,%xmm2
  81fd45:	andnps %xmm1,%xmm2
  81fd48:	andps  %xmm4,%xmm0
  81fd4b:	orps   %xmm2,%xmm0
  81fd4e:	movaps %xmm5,%xmm1
  81fd51:	shufps $0x55,%xmm5,%xmm1
  81fd55:	mulss  %xmm3,%xmm1
  81fd59:	movaps %xmm0,%xmm2
  81fd5c:	minss  %xmm1,%xmm2
  81fd60:	movaps %xmm2,%xmm1
  81fd63:	cmpunordss %xmm2,%xmm1
  81fd68:	andps  %xmm1,%xmm0
  81fd6b:	andnps %xmm2,%xmm1
  81fd6e:	orps   %xmm0,%xmm1
  81fd71:	movd   %xmm1,%eax
  81fd75:	and    $0xff800000,%eax
  81fd7a:	mov    $0x7f000000,%ecx
  81fd7f:	sub    %eax,%ecx
  81fd81:	movl   $0x40000000,0x124(%rsp)
  81fd8c:	movss  %xmm1,0x128(%rsp)
  81fd95:	mov    %ecx,0x12c(%rsp)
  81fd9c:	jmp    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1e43>
  81fda1:	cmp    $0x2,%cl
  81fda4:	jne    81fdf6 <<gpui_gpu::renderer::RendererState>::render+0x1de6>
  81fda6:	mov    0x360(%rsp),%rcx
  81fdae:	mov    %rcx,0x190(%rsp)
  81fdb6:	movaps 0x350(%rsp),%xmm0
  81fdbe:	movaps %xmm0,0x180(%rsp)
  81fdc6:	mov    0x38(%rsp),%rcx
  81fdcb:	mov    %rcx,0x198(%rsp)
  81fdd3:	mov    0x100(%rsp),%ecx
  81fdda:	mov    %ecx,0x1a0(%rsp)
  81fde1:	mov    0x28(%rsp),%ecx
  81fde5:	mov    %ecx,0x1a4(%rsp)
  81fdec:	mov    %rax,0x1a8(%rsp)
  81fdf4:	jmp    81fe02 <<gpui_gpu::renderer::RendererState>::render+0x1df2>
  81fdf6:	movq   $0x0,0x180(%rsp)
  81fe02:	movl   $0x0,0x2a8(%rsp)
  81fe0d:	movq   $0x0,0x2a0(%rsp)
  81fe19:	lea    0x124(%rsp),%rdi
  81fe21:	lea    0x180(%rsp),%rsi
  81fe29:	lea    0x2a0(%rsp),%rdx
  81fe31:	mov    0x288(%rsp),%rcx
  81fe39:	call   81b630 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fe3e:	movaps 0x150(%rsp),%xmm4
  81fe46:	mov    0x100(%rsp),%r10d
  81fe4e:	mov    0x28(%rsp),%r11d
  81fe53:	mov    0x20(%rsp),%rdx
  81fe58:	mov    0x330(%rsp),%rax
  81fe60:	lea    (%rax,%rdx,1),%rcx
  81fe64:	mov    0x8(%rsp),%rax
  81fe69:	mov    0x10(%rax),%rsi
  81fe6d:	cmp    %rsi,%rcx
  81fe70:	lea    0x180(%rsp),%rdi
  81fe78:	mov    0x10(%rsp),%r8d
  81fe7d:	mov    0x18(%rsp),%r9
  81fe82:	movapd 0x80(%rsp),%xmm3
  81fe8b:	jae    82066e <<gpui_gpu::renderer::RendererState>::render+0x265e>
  81fe91:	add    0x40(%rsp),%rdx
  81fe96:	mov    %rdx,0x20(%rsp)
  81fe9b:	mov    0x8(%rax),%rax
  81fe9f:	mov    0x12c(%rsp),%ecx
  81fea6:	mov    %ecx,0x8(%rax,%r9,1)
  81feab:	mov    0x124(%rsp),%rcx
  81feb3:	mov    %r8d,%edx
  81feb6:	or     $0x80000000,%edx
  81febc:	cmpb   $0x0,0x140(%rsp)
  81fec4:	cmovne %r8d,%edx
  81fec8:	mov    %rcx,(%rax,%r9,1)
  81fecc:	mov    %edx,0x29c(%rsp)
  81fed3:	movaps 0x370(%rsp),%xmm0
  81fedb:	movaps 0x380(%rsp),%xmm1
  81fee3:	movaps 0x390(%rsp),%xmm2
  81feeb:	lea    0x198(%rsp),%rax
  81fef3:	movups %xmm2,0x50(%rax)
  81fef7:	movups %xmm1,0x40(%rax)
  81fefb:	movups %xmm0,0x30(%rax)
  81feff:	movaps 0x3b0(%rsp),%xmm0
  81ff07:	movups %xmm0,0x60(%rax)
  81ff0b:	movaps 0x5a0(%rsp),%xmm0
  81ff13:	movups %xmm0,0x80(%rax)
  81ff1a:	movlpd %xmm3,0x1c0(%rsp)
  81ff23:	movaps 0x470(%rsp),%xmm0
  81ff2b:	movups %xmm0,0x70(%rax)
  81ff2f:	mov    0xb0(%rsp),%eax
  81ff36:	mov    %al,0x180(%rsp)
  81ff3d:	movzbl 0xa8(%rsp),%eax
  81ff45:	mov    %al,0x181(%rsp)
  81ff4c:	movzwl 0x60(%rsp),%eax
  81ff51:	mov    %ax,0x182(%rsp)
  81ff59:	movss  %xmm4,0x184(%rsp)
  81ff62:	mov    0x360(%rsp),%rax
  81ff6a:	lea    0x188(%rsp),%rcx
  81ff72:	mov    %rax,0x10(%rcx)
  81ff76:	movaps 0x350(%rsp),%xmm0
  81ff7e:	movups %xmm0,(%rcx)
  81ff81:	mov    0x38(%rsp),%rax
  81ff86:	mov    %rax,0x1a0(%rsp)
  81ff8e:	mov    %r10d,0x1a8(%rsp)
  81ff96:	mov    %r11d,0x1ac(%rsp)
  81ff9e:	movdqa 0x90(%rsp),%xmm0
  81ffa7:	movdqu %xmm0,0x1b0(%rsp)
  81ffb0:	mov    0x4b0(%rsp),%rax
  81ffb8:	mov    %rax,0x2a0(%rsp)
  81ffc0:	mov    0x450(%rsp),%rax
  81ffc8:	mov    %rax,0x2a8(%rsp)
  81ffd0:	mov    0x4a8(%rsp),%rax
  81ffd8:	mov    %rax,0x2b0(%rsp)
  81ffe0:	lea    0x3a8(%rsp),%rax
  81ffe8:	mov    %rax,0x2b8(%rsp)
  81fff0:	lea    0x29c(%rsp),%rax
  81fff8:	mov    %rax,0x2c0(%rsp)
  820000:	mov    0xa0(%rsp),%rsi
  820008:	lea    0x2a0(%rsp),%rdx
  820010:	call   81c4f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  820015:	mov    0x18(%rsp),%rcx
  82001a:	mov    0x10(%rsp),%edi
  82001e:	add    0x40(%rsp),%edi
  820022:	add    0x460(%rsp),%rcx
  82002a:	mov    0x30(%rsp),%rdx
  82002f:	add    $0xfffffffffffffffc,%rdx
  820033:	jne    81fba4 <<gpui_gpu::renderer::RendererState>::render+0x1b94>
  820039:	jmp    81fa19 <<gpui_gpu::renderer::RendererState>::render+0x1a09>
  82003e:	test   $0x1,%r13b
  820042:	je     820095 <<gpui_gpu::renderer::RendererState>::render+0x2085>
  820044:	movd   0x298(%rsp),%xmm0
  82004d:	movd   %xmm0,%eax
  820051:	test   %eax,%eax
  820053:	setns  %cl
  820056:	mov    %eax,%edx
  820058:	and    $0x7fffffff,%edx
  82005e:	add    $0xff800000,%edx
  820064:	cmp    $0x7f000000,%edx
  82006a:	setb   %dl
  82006d:	and    %cl,%dl
  82006f:	dec    %eax
  820071:	cmp    $0x7fffff,%eax
  820076:	setb   %al
  820079:	or     %dl,%al
  82007b:	movl   $0x2,0x11c(%rsp)
  820086:	movd   %xmm0,0x120(%rsp)
  82008f:	je     82063e <<gpui_gpu::renderer::RendererState>::render+0x262e>
  820095:	mov    0x170(%rsp),%r13
  82009d:	lea    0x18(%r13),%rax
  8200a1:	mov    %rax,0x18(%rsp)
  8200a6:	mov    0x178(%rsp),%rax
  8200ae:	add    $0x18,%rax
  8200b2:	xor    %ecx,%ecx
  8200b4:	cmp    $0x28,%r12d
  8200b8:	sete   %cl
  8200bb:	and    $0x1,%ebp
  8200be:	lea    0x0(%rbp,%rcx,4),%ecx
  8200c2:	or     0x11c(%rsp),%ecx
  8200c9:	movups (%rax),%xmm0
  8200cc:	movups %xmm0,0x2d8(%rsp)
  8200d4:	mov    %r14d,0x2c8(%rsp)
  8200dc:	mov    %r15d,0x2cc(%rsp)
  8200e4:	mov    0xa0(%rsp),%rax
  8200ec:	mov    %eax,0x2d0(%rsp)
  8200f3:	mov    %ecx,0x2d4(%rsp)
  8200fa:	movss  0x120(%rsp),%xmm0
  820103:	movss  %xmm0,0x2e8(%rsp)
  82010c:	movq   $0x0,0x2ec(%rsp)
  820118:	movl   $0x0,0x2f4(%rsp)
  820123:	mov    0x8(%rsp),%rbp
  820128:	lea    0x230(%rbp),%rsi
  82012f:	movq   $0x0,0x10(%rsp)
  820138:	lea    0x2c8(%rsp),%rcx
  820140:	mov    $0x30,%r8d
  820146:	mov    0x280(%rsp),%r12
  82014e:	mov    %r12,%rdi
  820151:	mov    %rsi,0x38(%rsp)
  820156:	xor    %edx,%edx
  820158:	call   *0x6610da(%rip)        # e81238 <_DYNAMIC+0x5d0>
  82015e:	mov    0x8(%rbp),%rcx
  820162:	mov    0x10(%rbp),%r8
  820166:	shl    $0x4,%r8
  82016a:	mov    0xc8(%rsp),%rdi
  820172:	mov    %r13,%rsi
  820175:	mov    %r12,%rdx
  820178:	call   81cb50 <<gpui_gpu::renderer::Buffer>::write>
  82017d:	lea    0x280(%rbp),%rdi
  820184:	mov    0x20(%rbp),%rcx
  820188:	mov    0x28(%rbp),%r8
  82018c:	shl    $0x3,%r8
  820190:	mov    %rdi,0xa8(%rsp)
  820198:	mov    %r13,%rsi
  82019b:	mov    %r12,%rdx
  82019e:	call   81cb50 <<gpui_gpu::renderer::Buffer>::write>
  8201a3:	lea    0x2a8(%rbp),%rdi
  8201aa:	mov    0x38(%rbp),%rcx
  8201ae:	mov    0x40(%rbp),%r8
  8201b2:	shl    $0x2,%r8
  8201b6:	mov    %rdi,0xa0(%rsp)
  8201be:	mov    %r13,%rsi
  8201c1:	mov    %r12,%rdx
  8201c4:	call   81cb50 <<gpui_gpu::renderer::Buffer>::write>
  8201c9:	lea    0x2d0(%rbp),%rdi
  8201d0:	mov    0x68(%rbp),%rcx
  8201d4:	mov    0x70(%rbp),%r8
  8201d8:	shl    $0x5,%r8
  8201dc:	mov    %rdi,0x20(%rsp)
  8201e1:	mov    %r13,%rsi
  8201e4:	mov    %r12,%rdx
  8201e7:	call   81cb50 <<gpui_gpu::renderer::Buffer>::write>
  8201ec:	cmpq   $0x0,0x328(%rbp)
  8201f4:	jne    820210 <<gpui_gpu::renderer::RendererState>::render+0x2200>
  8201f6:	mov    0x8(%rsp),%rax
  8201fb:	mov    0x10(%rax),%rax
  8201ff:	cmp    $0x1,%rax
  820203:	adc    $0x0,%rax
  820207:	shl    $0x4,%rax
  82020b:	mov    %rax,0x10(%rsp)
  820210:	mov    0x8(%rsp),%rsi
  820215:	mov    0x28(%rsi),%rdx
  820219:	mov    0x40(%rsi),%rax
  82021d:	cmp    $0x1,%rdx
  820221:	adc    $0x0,%rdx
  820225:	shl    $0x3,%rdx
  820229:	cmp    $0x1,%rax
  82022d:	adc    $0x0,%rax
  820231:	mov    0x70(%rsi),%rcx
  820235:	cmp    $0x1,%rcx
  820239:	adc    $0x0,%rcx
  82023d:	add    $0xc8,%rsi
  820244:	shl    $0x2,%rax
  820248:	shl    $0x5,%rcx
  82024c:	movq   $0x0,0x180(%rsp)
  820258:	mov    0x38(%rsp),%rdi
  82025d:	mov    %rdi,0x188(%rsp)
  820265:	movq   $0x0,0x1a8(%rsp)
  820271:	xorps  %xmm0,%xmm0
  820274:	movups %xmm0,0x190(%rsp)
  82027c:	movl   $0x0,0x1a0(%rsp)
  820287:	mov    0xc8(%rsp),%rdi
  82028f:	mov    %rdi,0x1b0(%rsp)
  820297:	movq   $0x0,0x1b8(%rsp)
  8202a3:	mov    0x10(%rsp),%rdi
  8202a8:	mov    %rdi,0x1c0(%rsp)
  8202b0:	movl   $0x1,0x1c8(%rsp)
  8202bb:	movq   $0x0,0x1d0(%rsp)
  8202c7:	mov    0xa8(%rsp),%rdi
  8202cf:	mov    %rdi,0x1d8(%rsp)
  8202d7:	movq   $0x0,0x1e0(%rsp)
  8202e3:	mov    %rdx,0x1e8(%rsp)
  8202eb:	movl   $0x2,0x1f0(%rsp)
  8202f6:	movq   $0x0,0x1f8(%rsp)
  820302:	mov    0xa0(%rsp),%rdx
  82030a:	mov    %rdx,0x200(%rsp)
  820312:	movq   $0x0,0x208(%rsp)
  82031e:	mov    %rax,0x210(%rsp)
  820326:	movl   $0x3,0x218(%rsp)
  820331:	movq   $0x4,0x220(%rsp)
  82033d:	mov    %rsi,0x228(%rsp)
  820345:	movl   $0x4,0x240(%rsp)
  820350:	movq   $0x0,0x248(%rsp)
  82035c:	mov    0x20(%rsp),%rax
  820361:	mov    %rax,0x250(%rsp)
  820369:	movq   $0x0,0x258(%rsp)
  820375:	mov    %rcx,0x260(%rsp)
  82037d:	movl   $0x5,0x268(%rsp)
  820388:	lea    -0x74b6f4(%rip),%rax        # d4c9b <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x13d>
  82038f:	mov    %rax,0x388(%rsp)
  820397:	movq   $0xa,0x390(%rsp)
  8203a3:	mov    0x18(%rsp),%rax
  8203a8:	mov    %rax,0x370(%rsp)
  8203b0:	lea    0x180(%rsp),%rax
  8203b8:	mov    %rax,0x378(%rsp)
  8203c0:	movq   $0x6,0x380(%rsp)
  8203cc:	lea    0x370(%rsp),%rsi
  8203d4:	mov    0x170(%rsp),%r12
  8203dc:	mov    %r12,%rdi
  8203df:	call   *0x660e5b(%rip)        # e81240 <_DYNAMIC+0x5d8>
  8203e5:	mov    %rax,%r13
  8203e8:	mov    %rax,0x2a0(%rsp)
  8203f0:	lea    0x2a0(%rsp),%rdx
  8203f8:	mov    %r12,%rdi
  8203fb:	mov    0x4a0(%rsp),%rsi
  820403:	call   81d1b0 <<gpui_gpu::renderer::GpuContext>::submit>
  820408:	mov    %rax,0x10(%rsp)
  82040d:	xor    %ebp,%ebp
  82040f:	mov    0x490(%rsp),%rax
  820417:	cmp    0x498(%rsp),%rax
  82041f:	setne  %bpl
  820423:	shl    $0x1f,%ebp
  820426:	or     %r14d,%ebp
  820429:	shl    $0x20,%r15
  82042d:	or     %r15,%rbp
  820430:	mov    (%rbx),%rax
  820433:	test   %rax,%rax
  820436:	je     820447 <<gpui_gpu::renderer::RendererState>::render+0x2437>
  820438:	lock decq (%rax)
  82043c:	jne    820447 <<gpui_gpu::renderer::RendererState>::render+0x2437>
  82043e:	mov    %rbx,%rdi
  820441:	call   *0x660d39(%rip)        # e81180 <_DYNAMIC+0x518>
  820447:	mov    0x8(%rsp),%rax
  82044c:	mov    %r13,0x330(%rax)
  820453:	mov    %rbp,0x338(%rax)
  82045a:	mov    0x10(%rax),%r8
  82045e:	mov    0x28(%rax),%rsi
  820462:	mov    0x70(%rax),%rcx
  820466:	mov    %rcx,0x18(%rsp)
  82046b:	shl    $0x4,%r8
  82046f:	mov    0xe0(%rsp),%rdx
  820477:	lea    (%r8,%rdx,4),%rdi
  82047b:	lea    (%rdi,%rsi,8),%rsi
  82047f:	mov    %rcx,%rdi
  820482:	shl    $0x5,%rdi
  820486:	lea    (%rdi,%rsi,1),%rcx
  82048a:	add    $0x30,%rcx
  82048e:	mov    %rcx,0x38(%rsp)
  820493:	mov    0x278(%rax),%rdi
  82049a:	add    0x250(%rax),%rdi
  8204a1:	add    0x2a0(%rax),%rdi
  8204a8:	add    0x2c8(%rax),%rdi
  8204af:	add    0x2f0(%rax),%rdi
  8204b6:	mov    0x308(%rax),%rsi
  8204bd:	add    0x310(%rax),%rsi
  8204c4:	mov    0x150(%rax),%r9d
  8204cb:	imul   %r9,%r9
  8204cf:	mov    0xf8(%rsp),%r11
  8204d7:	mov    %r11,%rcx
  8204da:	sub    %rdx,%rcx
  8204dd:	mov    0x78(%rsp),%r10
  8204e2:	mov    %r10,%r12
  8204e5:	mov    0x278(%rsp),%rbp
  8204ed:	sub    %rbp,%r12
  8204f0:	mov    0x160(%rax),%rbx
  8204f7:	inc    %rbx
  8204fa:	mov    $0xffffffffffffffff,%r14
  820501:	cmovne %rbx,%r14
  820505:	mov    (%rax),%rbx
  820508:	shl    $0x4,%rbx
  82050c:	mov    0x48(%rax),%r15
  820510:	add    0x30(%rax),%r15
  820514:	mov    0x18(%rax),%r13
  820518:	lea    (%rbx,%r13,8),%rbx
  82051c:	lea    (%rbx,%r15,4),%rbx
  820520:	mov    0x60(%rax),%r15
  820524:	shl    $0x5,%r15
  820528:	add    %rbx,%r15
  82052b:	mov    0x138(%rax),%rbx
  820532:	mov    0x130(%rax),%r13
  820539:	mov    %r14,0x160(%rax)
  820540:	mov    %r10,0x168(%rax)
  820547:	lea    (%r11,%r11,1),%r14
  82054b:	mov    %r14,0x170(%rax)
  820552:	movq   $0x1,0x178(%rax)
  82055d:	mov    %r10,0x180(%rax)
  820564:	mov    %rdx,0x188(%rax)
  82056b:	mov    %r11,0x190(%rax)
  820572:	mov    %rcx,0x198(%rax)
  820579:	mov    0xe8(%rsp),%rcx
  820581:	mov    %rcx,0x1a0(%rax)
  820588:	mov    0xf0(%rsp),%rcx
  820590:	mov    %rcx,0x1a8(%rax)
  820597:	mov    0xd0(%rsp),%rcx
  82059f:	mov    %rcx,0x1b0(%rax)
  8205a6:	mov    0x38(%rsp),%rcx
  8205ab:	mov    %rcx,0x1b8(%rax)
  8205b2:	mov    %r8,0x1c0(%rax)
  8205b9:	mov    0x270(%rsp),%rdx
  8205c1:	mov    %rdx,0x1c8(%rax)
  8205c8:	mov    %rbp,0x1d0(%rax)
  8205cf:	mov    %r12,0x1d8(%rax)
  8205d6:	mov    0x488(%rsp),%rcx
  8205de:	mov    %rcx,0x1e0(%rax)
  8205e5:	mov    %rdi,0x1e8(%rax)
  8205ec:	mov    %r9,0x1f0(%rax)
  8205f3:	add    %rbx,%r13
  8205f6:	mov    %rbx,0x1f8(%rax)
  8205fd:	mov    %r13,0x200(%rax)
  820604:	mov    %r15,0x208(%rax)
  82060b:	mov    0x18(%rsp),%rcx
  820610:	mov    %rcx,0x210(%rax)
  820617:	mov    %rsi,0x218(%rax)
  82061e:	movb   $0x0,0x220(%rax)
  820625:	mov    0x58(%rsp),%rdi
  82062a:	mov    0x10(%rsp),%rax
  82062f:	mov    %rax,0x8(%rdi)
  820633:	movl   $0xffffffff,(%rdi)
  820639:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  82063e:	mov    0x58(%rsp),%rdi
  820643:	jmp    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  820648:	lea    0x60f071(%rip),%rdi        # e2f6c0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  82064f:	call   *0x660bf3(%rip)        # e81248 <_DYNAMIC+0x5e0>
  820655:	lea    -0x74b9dc(%rip),%rdi        # d4c80 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82065c:	lea    0x60f045(%rip),%rdx        # e2f6a8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  820663:	mov    $0x37,%esi
  820668:	call   *0x660912(%rip)        # e80f80 <_DYNAMIC+0x318>
  82066e:	mov    0x40(%rsp),%rdi
  820673:	add    0x168(%rsp),%rdi
  82067b:	add    %rdx,%rdi
  82067e:	lea    0x60f053(%rip),%rdx        # e2f6d8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  820685:	call   *0x660ad5(%rip)        # e81160 <_DYNAMIC+0x4f8>
  82068b:	mov    %rax,%r14
  82068e:	mov    0x8(%rsp),%rax
  820693:	mov    %r13,0x330(%rax)
  82069a:	mov    %rbp,0x338(%rax)
  8206a1:	mov    %r14,%rdi
  8206a4:	call   e2d990 <_Unwind_Resume@plt>
  8206a9:	mov    %rax,%r14
  8206ac:	lock decq 0x0(%r13)
  8206b1:	jne    8206d3 <<gpui_gpu::renderer::RendererState>::render+0x26c3>
  8206b3:	lea    0x2a0(%rsp),%rdi
  8206bb:	call   *0x660abf(%rip)        # e81180 <_DYNAMIC+0x518>
  8206c1:	jmp    8206d3 <<gpui_gpu::renderer::RendererState>::render+0x26c3>
  8206c3:	call   *0x6607ef(%rip)        # e80eb8 <_DYNAMIC+0x250>
  8206c9:	mov    %rax,%r14
  8206cc:	movq   $0x0,(%rbx)
  8206d3:	mov    %r14,%rdi
  8206d6:	call   e2d990 <_Unwind_Resume@plt>
