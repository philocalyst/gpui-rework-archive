# CSR normalization counters: correctness/static qualified, unadopted

Source b3123ea1b4df2d144108d25499780217aac5b470 is an isolated successor to
299c6aca30c1245c15c2da6a5ccabb41dd435d17 at /tmp/gpui-csr-stats-sol.
Only renderer.rs changes production: exact work counters move into existing
CSR normalization, row/cursor chunks derive clipped areas without per-tile
division, and the complete final statistics walk is deleted. The unused host
TILE_END constant is removed. Shader, packet ABI, fields, allocations,
dependencies, logical caps, forward binning, fused reverse resource/CSR walk,
uploads and successful-only Stats publication remain unchanged. One counter
expression serves SIMD and fallback. proof.md derives retained-count equality,
partial areas, u64 bounds, uniform/opaque/constant and failure invariants.

Default/fallback release pass 14 library/4 presentation/51 render/1 doc each.
Offline shader release passes 15/4/52/1 using the qualified SPIR-V validator.
Strict all-target default/offline checks and Apple ARM64/Windows MSVC all-feature
library cross-checks pass. Cross checks are compilation, not runtime claims.
Package formatting and all 1,380 source/config guards pass; worktree is clean.

The original public fixture 8773146b44150adb0150323d51f241c946fb5cda26328f004562dcd9dee39cc0
retains 52 exact GPU readbacks/35,651,584 bytes against both frozen 299c and the
original a81 reference. Every Stats/ImageStats field matches 299c exactly.
The complete 51-test source is then captured in both matched source lanes:
all 668 named raw images/14,407,296 bytes and all 668 complete Stats/ImageStats
snapshots match byte for byte by test name/within-test ordinal/size/format.
This includes empty tiles, partial edges, opaque/constant/prefix, rounded,
masks, images, banks, queued submissions, failed admission and SDR/HDR/P3.
Observer source and binary hashes are retained; observer code is removed.
Calibration clocks are unqualified and provide no performance inference.

Independent 35x19 SDR/HDR counter expectations include empty/full, a clipped
3x3 opaque corner and a partial first tile. The first fixture version omitted
clips bounding Canvas' existing one-pixel AABB halo and incorrectly expected
7 rather than 10 logical references in its corner stage; its exit 101/log and
initial generator remain. Only fixture clips were corrected before sealing;
no production change repaired that expectation. A deliberate counter-only
retained-count c+1 fault then failed the independent assertion 21280 vs 10640,
exit 101. Exact source restoration recovered, exit 0. Actual fault/recovery
executables, source hashes and failed logs remain externally preserved.

Actual matched linked costs use one source path, locked dependencies, qualified
Rust/Cargo 1.97.1, default SIMD+vulkan-tests, opt3 and root v0/tokio flags plus
emit-stack-sizes exactly once. Both library and groups artifacts are fresh:false.
All GPU aliases and caller/helper disassembly are retained, including ambiguous
or unpaired symbols rather than silently collapsing them.

| Cost |299c baseline|b312 candidate|Delta|
|---|---:|---:|---:|
| Non-test/comment core LOC |30834|30830|-4|
| Linked .text |6409367|6409415|+48|
| Linked .rodata |7011384|7011384|0|
| Linked .data.rel.ro |336480|336528|+48|
| Render body / static frame |9520/1448|9931/1512|+411/+64|
| bin_draw body / static frame |4531/840|4531/840|0/0|

The baseline render caller has divq/divl alternatives; the candidate render
caller has no integer division instruction. Existing bin_draw divisions remain
unchanged. The final walk deletion is real, but earlier live counters/row-loop
machinery did not improve caller text or frame. Whole linked growth and the
64-byte static frame increase are charged. Metadata frames are not dynamic peak
stack or additive call chains. There is no timing, RSS or universal-win claim.
Every public payload, retained-capacity and upload field is exactly baseline;
no new heap allocation or retained field is introduced. Full legacy ordinary
warm uploads and common-record costs therefore remain fully charged.

All 6158/299c and campaign trees/captures/ELFs remain intact. All four prior
archives were independently rehashed unchanged. Current archive excludes ELF
bytes, records exact external binaries/compiler paths/sizes/hashes, and reopens
every archived payload for size/hash verification. No timed campaign/retry or
integration is authorized by this correctness/static qualification.
