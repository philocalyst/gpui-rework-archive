
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816550 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  816550:	push   %rbx
  816551:	test   %rdi,%rdi
  816554:	je     8165b7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  816556:	mov    %rdi,%rbx
  816559:	mov    (%rdi),%rsi
  81655c:	test   %rsi,%rsi
  81655f:	je     816574 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816561:	mov    0x8(%rbx),%rdi
  816565:	shl    $0x3,%rsi
  816569:	mov    $0x8,%edx
  81656e:	call   *0x66a8ec(%rip)        # e80e60 <_DYNAMIC+0x248>
  816574:	mov    0x20(%rbx),%rsi
  816578:	test   %rsi,%rsi
  81657b:	je     8165a3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81657d:	mov    %rsi,%rax
  816580:	shl    $0x4,%rax
  816584:	add    %rax,%rsi
  816587:	add    $0x21,%rsi
  81658b:	je     8165a3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81658d:	mov    0x18(%rbx),%rdi
  816591:	sub    %rax,%rdi
  816594:	add    $0xfffffffffffffff0,%rdi
  816598:	mov    $0x10,%edx
  81659d:	call   *0x66a8bd(%rip)        # e80e60 <_DYNAMIC+0x248>
  8165a3:	mov    $0x80,%esi
  8165a8:	mov    $0x8,%edx
  8165ad:	mov    %rbx,%rdi
  8165b0:	pop    %rbx
  8165b1:	jmp    *0x66a8a9(%rip)        # e80e60 <_DYNAMIC+0x248>
  8165b7:	pop    %rbx
  8165b8:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816bc0 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816bc0:	push   %rbx
  816bc1:	cmpb   $0x3,0x19c(%rdi)
  816bc8:	jne    816bf7 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816bca:	movzbl 0x28(%rdi),%eax
  816bce:	cmp    $0x4,%eax
  816bd1:	je     816be5 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816bd3:	cmp    $0x3,%eax
  816bd6:	jne    816bf7 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816bd8:	add    $0x168,%rdi
  816bdf:	pop    %rbx
  816be0:	jmp    816b30 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816be5:	mov    %rdi,%rbx
  816be8:	add    $0x30,%rdi
  816bec:	call   816c10 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816bf1:	movw   $0x0,0x29(%rbx)
  816bf7:	pop    %rbx
  816bf8:	ret
  816bf9:	movw   $0x0,0x29(%rbx)
  816bff:	mov    %rax,%rdi
  816c02:	call   e2d970 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816c10 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816c10:	push   %r15
  816c12:	push   %r14
  816c14:	push   %r12
  816c16:	push   %rbx
  816c17:	push   %rax
  816c18:	mov    %rdi,%rbx
  816c1b:	movzbl 0x9e(%rdi),%eax
  816c22:	test   %eax,%eax
  816c24:	je     816ceb <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816c2a:	cmp    $0x3,%eax
  816c2d:	jne    816d21 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816c33:	mov    0x20(%rbx),%r15
  816c37:	mov    0x28(%rbx),%r12
  816c3b:	mov    (%r12),%rax
  816c3f:	test   %rax,%rax
  816c42:	je     816c49 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816c44:	mov    %r15,%rdi
  816c47:	call   *%rax
  816c49:	mov    0x8(%r12),%rsi
  816c4e:	test   %rsi,%rsi
  816c51:	je     816c61 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816c53:	mov    0x10(%r12),%rdx
  816c58:	mov    %r15,%rdi
  816c5b:	call   *0x66a1ff(%rip)        # e80e60 <_DYNAMIC+0x248>
  816c61:	mov    0x68(%rbx),%rax
  816c65:	lock decq (%rax)
  816c69:	jne    816c75 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816c6b:	lea    0x68(%rbx),%rdi
  816c6f:	call   *0x66a40b(%rip)        # e81080 <_DYNAMIC+0x468>
  816c75:	movb   $0x0,0x98(%rbx)
  816c7c:	mov    0x60(%rbx),%rax
  816c80:	lock decq (%rax)
  816c84:	jne    816c8f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816c86:	lea    0x60(%rbx),%rdi
  816c8a:	call   812d90 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816c8f:	movw   $0x0,0x99(%rbx)
  816c98:	mov    0x40(%rbx),%rax
  816c9c:	lock decq (%rax)
  816ca0:	jne    816cac <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816ca2:	lea    0x40(%rbx),%rdi
  816ca6:	call   *0x66a3dc(%rip)        # e81088 <_DYNAMIC+0x470>
  816cac:	movb   $0x0,0x9b(%rbx)
  816cb3:	mov    0x38(%rbx),%rax
  816cb7:	lock decq (%rax)
  816cbb:	jne    816cc7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816cbd:	lea    0x38(%rbx),%rdi
  816cc1:	call   *0x66a3c9(%rip)        # e81090 <_DYNAMIC+0x478>
  816cc7:	movb   $0x0,0x9c(%rbx)
  816cce:	mov    0x30(%rbx),%rax
  816cd2:	lock decq (%rax)
  816cd6:	jne    816ce2 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816cd8:	lea    0x30(%rbx),%rdi
  816cdc:	call   *0x66a3b6(%rip)        # e81098 <_DYNAMIC+0x480>
  816ce2:	movb   $0x0,0x9d(%rbx)
  816ce9:	jmp    816d21 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816ceb:	mov    0x70(%rbx),%rax
  816cef:	lock decq (%rax)
  816cf3:	jne    816cff <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816cf5:	lea    0x70(%rbx),%rdi
  816cf9:	call   *0x66a399(%rip)        # e81098 <_DYNAMIC+0x480>
  816cff:	mov    0x78(%rbx),%rax
  816d03:	lock decq (%rax)
  816d07:	jne    816d21 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816d09:	add    $0x78,%rbx
  816d0d:	mov    %rbx,%rdi
  816d10:	add    $0x8,%rsp
  816d14:	pop    %rbx
  816d15:	pop    %r12
  816d17:	pop    %r14
  816d19:	pop    %r15
  816d1b:	jmp    *0x66a36f(%rip)        # e81090 <_DYNAMIC+0x478>
  816d21:	add    $0x8,%rsp
  816d25:	pop    %rbx
  816d26:	pop    %r12
  816d28:	pop    %r14
  816d2a:	pop    %r15
  816d2c:	ret
  816d2d:	mov    %rax,%r14
  816d30:	movb   $0x0,0x9d(%rbx)
  816d37:	mov    %r14,%rdi
  816d3a:	call   e2d970 <_Unwind_Resume@plt>
  816d3f:	mov    %rax,%r14
  816d42:	jmp    816dfc <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816d47:	mov    %rax,%r14
  816d4a:	jmp    816de1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816d4f:	mov    %rax,%r14
  816d52:	jmp    816dc4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816d54:	mov    %rax,%r14
  816d57:	jmp    816daa <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816d59:	mov    %rax,%r14
  816d5c:	mov    0x78(%rbx),%rax
  816d60:	lock decq (%rax)
  816d64:	jne    816d73 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816d66:	add    $0x78,%rbx
  816d6a:	mov    %rbx,%rdi
  816d6d:	call   *0x66a31d(%rip)        # e81090 <_DYNAMIC+0x478>
  816d73:	mov    %r14,%rdi
  816d76:	call   e2d970 <_Unwind_Resume@plt>
  816d7b:	mov    %rax,%r14
  816d7e:	mov    0x8(%r12),%rsi
  816d83:	test   %rsi,%rsi
  816d86:	je     816d96 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816d88:	mov    0x10(%r12),%rdx
  816d8d:	mov    %r15,%rdi
  816d90:	call   *0x66a0ca(%rip)        # e80e60 <_DYNAMIC+0x248>
  816d96:	mov    0x68(%rbx),%rax
  816d9a:	lock decq (%rax)
  816d9e:	jne    816daa <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816da0:	lea    0x68(%rbx),%rdi
  816da4:	call   *0x66a2d6(%rip)        # e81080 <_DYNAMIC+0x468>
  816daa:	movb   $0x0,0x98(%rbx)
  816db1:	mov    0x60(%rbx),%rax
  816db5:	lock decq (%rax)
  816db9:	jne    816dc4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816dbb:	lea    0x60(%rbx),%rdi
  816dbf:	call   812d90 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816dc4:	movw   $0x0,0x99(%rbx)
  816dcd:	mov    0x40(%rbx),%rax
  816dd1:	lock decq (%rax)
  816dd5:	jne    816de1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816dd7:	lea    0x40(%rbx),%rdi
  816ddb:	call   *0x66a2a7(%rip)        # e81088 <_DYNAMIC+0x470>
  816de1:	movb   $0x0,0x9b(%rbx)
  816de8:	mov    0x38(%rbx),%rax
  816dec:	lock decq (%rax)
  816df0:	jne    816dfc <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816df2:	lea    0x38(%rbx),%rdi
  816df6:	call   *0x66a294(%rip)        # e81090 <_DYNAMIC+0x478>
  816dfc:	movb   $0x0,0x9c(%rbx)
  816e03:	mov    0x30(%rbx),%rax
  816e07:	lock decq (%rax)
  816e0b:	jne    816e17 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816e0d:	lea    0x30(%rbx),%rdi
  816e11:	call   *0x66a281(%rip)        # e81098 <_DYNAMIC+0x480>
  816e17:	movb   $0x0,0x9d(%rbx)
  816e1e:	mov    %r14,%rdi
  816e21:	call   e2d970 <_Unwind_Resume@plt>
  816e26:	call   *0x66a03c(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816e30 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816e30:	push   %rbx
  816e31:	movzbl 0x20(%rdi),%eax
  816e35:	cmp    $0x3,%eax
  816e38:	je     816e53 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816e3a:	cmp    $0x4,%eax
  816e3d:	jne    816e60 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816e3f:	mov    %rdi,%rbx
  816e42:	add    $0x28,%rdi
  816e46:	call   816c10 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816e4b:	movw   $0x0,0x21(%rbx)
  816e51:	pop    %rbx
  816e52:	ret
  816e53:	add    $0x160,%rdi
  816e5a:	pop    %rbx
  816e5b:	jmp    816b30 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816e60:	pop    %rbx
  816e61:	ret
  816e62:	movw   $0x0,0x21(%rbx)
  816e68:	mov    %rax,%rdi
  816e6b:	call   e2d970 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817350 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  817350:	push   %r14
  817352:	push   %rbx
  817353:	push   %rax
  817354:	mov    %rdi,%rbx
  817357:	mov    (%rdi),%rax
  81735a:	lock decq (%rax)
  81735e:	jne    817369 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817360:	mov    %rbx,%rdi
  817363:	call   *0x669d2f(%rip)        # e81098 <_DYNAMIC+0x480>
  817369:	mov    0x8(%rbx),%rax
  81736d:	lock decq (%rax)
  817371:	jne    81737d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  817373:	lea    0x8(%rbx),%rdi
  817377:	call   *0x669d13(%rip)        # e81090 <_DYNAMIC+0x478>
  81737d:	mov    0x10(%rbx),%rax
  817381:	lock decq (%rax)
  817385:	jne    817390 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  817387:	lea    0x10(%rbx),%rdi
  81738b:	call   812d90 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  817390:	mov    0x18(%rbx),%rax
  817394:	lock decq (%rax)
  817398:	jne    8173ae <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  81739a:	add    $0x18,%rbx
  81739e:	mov    %rbx,%rdi
  8173a1:	add    $0x8,%rsp
  8173a5:	pop    %rbx
  8173a6:	pop    %r14
  8173a8:	jmp    *0x669cd2(%rip)        # e81080 <_DYNAMIC+0x468>
  8173ae:	add    $0x8,%rsp
  8173b2:	pop    %rbx
  8173b3:	pop    %r14
  8173b5:	ret
  8173b6:	mov    %rax,%r14
  8173b9:	jmp    8173ea <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  8173bb:	mov    %rax,%r14
  8173be:	jmp    8173d7 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8173c0:	mov    %rax,%r14
  8173c3:	mov    0x8(%rbx),%rax
  8173c7:	lock decq (%rax)
  8173cb:	jne    8173d7 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8173cd:	lea    0x8(%rbx),%rdi
  8173d1:	call   *0x669cb9(%rip)        # e81090 <_DYNAMIC+0x478>
  8173d7:	mov    0x10(%rbx),%rax
  8173db:	lock decq (%rax)
  8173df:	jne    8173ea <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  8173e1:	lea    0x10(%rbx),%rdi
  8173e5:	call   812d90 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  8173ea:	mov    0x18(%rbx),%rax
  8173ee:	lock decq (%rax)
  8173f2:	jne    817401 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  8173f4:	add    $0x18,%rbx
  8173f8:	mov    %rbx,%rdi
  8173fb:	call   *0x669c7f(%rip)        # e81080 <_DYNAMIC+0x468>
  817401:	mov    %r14,%rdi
  817404:	call   e2d970 <_Unwind_Resume@plt>
  817409:	call   *0x669a59(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1253 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817410 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  817410:	push   %r14
  817412:	push   %rbx
  817413:	push   %rax
  817414:	mov    %rdi,%rbx
  817417:	mov    0x228(%rdi),%rax
  81741e:	lock decq (%rax)
  817422:	jne    817431 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  817424:	lea    0x228(%rbx),%rdi
  81742b:	call   *0x669c4f(%rip)        # e81080 <_DYNAMIC+0x468>
  817431:	mov    0x230(%rbx),%rax
  817438:	lock decq (%rax)
  81743c:	jne    81744b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  81743e:	lea    0x230(%rbx),%rdi
  817445:	call   *0x669cd5(%rip)        # e81120 <_DYNAMIC+0x508>
  81744b:	mov    0x238(%rbx),%rax
  817452:	lock decq (%rax)
  817456:	jne    817465 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  817458:	lea    0x238(%rbx),%rdi
  81745f:	call   *0x669cc3(%rip)        # e81128 <_DYNAMIC+0x510>
  817465:	mov    0x258(%rbx),%rax
  81746c:	lock decq (%rax)
  817470:	jne    81747f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  817472:	lea    0x258(%rbx),%rdi
  817479:	call   *0x669ca1(%rip)        # e81120 <_DYNAMIC+0x508>
  81747f:	mov    0x260(%rbx),%rax
  817486:	lock decq (%rax)
  81748a:	jne    817499 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  81748c:	lea    0x260(%rbx),%rdi
  817493:	call   *0x669c8f(%rip)        # e81128 <_DYNAMIC+0x510>
  817499:	mov    0x280(%rbx),%rax
  8174a0:	lock decq (%rax)
  8174a4:	jne    8174b3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  8174a6:	lea    0x280(%rbx),%rdi
  8174ad:	call   *0x669c6d(%rip)        # e81120 <_DYNAMIC+0x508>
  8174b3:	mov    0x288(%rbx),%rax
  8174ba:	lock decq (%rax)
  8174be:	jne    8174cd <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  8174c0:	lea    0x288(%rbx),%rdi
  8174c7:	call   *0x669c5b(%rip)        # e81128 <_DYNAMIC+0x510>
  8174cd:	mov    0x2a8(%rbx),%rax
  8174d4:	lock decq (%rax)
  8174d8:	jne    8174e7 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  8174da:	lea    0x2a8(%rbx),%rdi
  8174e1:	call   *0x669c39(%rip)        # e81120 <_DYNAMIC+0x508>
  8174e7:	mov    0x2b0(%rbx),%rax
  8174ee:	lock decq (%rax)
  8174f2:	jne    817501 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  8174f4:	lea    0x2b0(%rbx),%rdi
  8174fb:	call   *0x669c27(%rip)        # e81128 <_DYNAMIC+0x510>
  817501:	mov    0x2d0(%rbx),%rax
  817508:	lock decq (%rax)
  81750c:	jne    81751b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  81750e:	lea    0x2d0(%rbx),%rdi
  817515:	call   *0x669c05(%rip)        # e81120 <_DYNAMIC+0x508>
  81751b:	mov    0x2d8(%rbx),%rax
  817522:	lock decq (%rax)
  817526:	jne    817535 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  817528:	lea    0x2d8(%rbx),%rdi
  81752f:	call   *0x669bf3(%rip)        # e81128 <_DYNAMIC+0x510>
  817535:	lea    0x78(%rbx),%rdi
  817539:	call   817900 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81753e:	mov    0x328(%rbx),%r14
  817545:	test   %r14,%r14
  817548:	je     8175a7 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  81754a:	mov    (%r14),%rsi
  81754d:	test   %rsi,%rsi
  817550:	je     817565 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  817552:	mov    0x8(%r14),%rdi
  817556:	shl    $0x3,%rsi
  81755a:	mov    $0x8,%edx
  81755f:	call   *0x6698fb(%rip)        # e80e60 <_DYNAMIC+0x248>
  817565:	mov    0x20(%r14),%rsi
  817569:	test   %rsi,%rsi
  81756c:	je     817594 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81756e:	mov    %rsi,%rax
  817571:	shl    $0x4,%rax
  817575:	add    %rax,%rsi
  817578:	add    $0x21,%rsi
  81757c:	je     817594 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81757e:	mov    0x18(%r14),%rdi
  817582:	sub    %rax,%rdi
  817585:	add    $0xfffffffffffffff0,%rdi
  817589:	mov    $0x10,%edx
  81758e:	call   *0x6698cc(%rip)        # e80e60 <_DYNAMIC+0x248>
  817594:	mov    $0x80,%esi
  817599:	mov    $0x8,%edx
  81759e:	mov    %r14,%rdi
  8175a1:	call   *0x6698b9(%rip)        # e80e60 <_DYNAMIC+0x248>
  8175a7:	mov    (%rbx),%rsi
  8175aa:	test   %rsi,%rsi
  8175ad:	je     8175c2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  8175af:	mov    0x8(%rbx),%rdi
  8175b3:	shl    $0x4,%rsi
  8175b7:	mov    $0x4,%edx
  8175bc:	call   *0x66989e(%rip)        # e80e60 <_DYNAMIC+0x248>
  8175c2:	mov    0x18(%rbx),%rsi
  8175c6:	test   %rsi,%rsi
  8175c9:	je     8175de <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  8175cb:	mov    0x20(%rbx),%rdi
  8175cf:	shl    $0x3,%rsi
  8175d3:	mov    $0x4,%edx
  8175d8:	call   *0x669882(%rip)        # e80e60 <_DYNAMIC+0x248>
  8175de:	mov    0x30(%rbx),%rsi
  8175e2:	test   %rsi,%rsi
  8175e5:	je     8175fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  8175e7:	mov    0x38(%rbx),%rdi
  8175eb:	shl    $0x2,%rsi
  8175ef:	mov    $0x4,%edx
  8175f4:	call   *0x669866(%rip)        # e80e60 <_DYNAMIC+0x248>
  8175fa:	mov    0x48(%rbx),%rsi
  8175fe:	test   %rsi,%rsi
  817601:	je     817616 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  817603:	mov    0x50(%rbx),%rdi
  817607:	shl    $0x2,%rsi
  81760b:	mov    $0x4,%edx
  817610:	call   *0x66984a(%rip)        # e80e60 <_DYNAMIC+0x248>
  817616:	mov    0x60(%rbx),%rsi
  81761a:	test   %rsi,%rsi
  81761d:	je     817632 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  81761f:	mov    0x68(%rbx),%rdi
  817623:	shl    $0x5,%rsi
  817627:	mov    $0x4,%edx
  81762c:	call   *0x66982e(%rip)        # e80e60 <_DYNAMIC+0x248>
  817632:	mov    0x300(%rbx),%rsi
  817639:	test   %rsi,%rsi
  81763c:	je     81766c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  81763e:	lea    (%rsi,%rsi,8),%rax
  817642:	lea    0x33(,%rax,4),%rax
  81764a:	and    $0xfffffffffffffff0,%rax
  81764e:	add    %rax,%rsi
  817651:	add    $0x11,%rsi
  817655:	je     81766c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  817657:	mov    0x2f8(%rbx),%rdi
  81765e:	sub    %rax,%rdi
  817661:	mov    $0x10,%edx
  817666:	call   *0x6697f4(%rip)        # e80e60 <_DYNAMIC+0x248>
  81766c:	mov    0x330(%rbx),%rax
  817673:	test   %rax,%rax
  817676:	je     817695 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  817678:	lock decq (%rax)
  81767c:	jne    817695 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  81767e:	add    $0x330,%rbx
  817685:	mov    %rbx,%rdi
  817688:	add    $0x8,%rsp
  81768c:	pop    %rbx
  81768d:	pop    %r14
  81768f:	jmp    *0x669a9b(%rip)        # e81130 <_DYNAMIC+0x518>
  817695:	add    $0x8,%rsp
  817699:	pop    %rbx
  81769a:	pop    %r14
  81769c:	ret
  81769d:	mov    %rax,%r14
  8176a0:	jmp    8177cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8176a5:	mov    %rax,%r14
  8176a8:	mov    0x2d8(%rbx),%rax
  8176af:	lock decq (%rax)
  8176b3:	jne    8177cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8176b9:	lea    0x2d8(%rbx),%rdi
  8176c0:	call   *0x669a62(%rip)        # e81128 <_DYNAMIC+0x510>
  8176c6:	jmp    8177cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8176cb:	call   *0x669797(%rip)        # e80e68 <_DYNAMIC+0x250>
  8176d1:	mov    %rax,%r14
  8176d4:	jmp    8177c0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  8176d9:	mov    %rax,%r14
  8176dc:	mov    0x2b0(%rbx),%rax
  8176e3:	lock decq (%rax)
  8176e7:	jne    8177c0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  8176ed:	lea    0x2b0(%rbx),%rdi
  8176f4:	call   *0x669a2e(%rip)        # e81128 <_DYNAMIC+0x510>
  8176fa:	jmp    8177c0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  8176ff:	call   *0x669763(%rip)        # e80e68 <_DYNAMIC+0x250>
  817705:	mov    %rax,%r14
  817708:	jmp    8177b4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  81770d:	mov    %rax,%r14
  817710:	mov    0x288(%rbx),%rax
  817717:	lock decq (%rax)
  81771b:	jne    8177b4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  817721:	lea    0x288(%rbx),%rdi
  817728:	call   *0x6699fa(%rip)        # e81128 <_DYNAMIC+0x510>
  81772e:	jmp    8177b4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  817733:	call   *0x66972f(%rip)        # e80e68 <_DYNAMIC+0x250>
  817739:	mov    %rax,%r14
  81773c:	jmp    8177a8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81773e:	mov    %rax,%r14
  817741:	mov    0x260(%rbx),%rax
  817748:	lock decq (%rax)
  81774c:	jne    8177a8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81774e:	lea    0x260(%rbx),%rdi
  817755:	call   *0x6699cd(%rip)        # e81128 <_DYNAMIC+0x510>
  81775b:	jmp    8177a8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81775d:	call   *0x669705(%rip)        # e80e68 <_DYNAMIC+0x250>
  817763:	mov    %rax,%r14
  817766:	jmp    81779c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817768:	mov    %rax,%r14
  81776b:	mov    0x238(%rbx),%rax
  817772:	lock decq (%rax)
  817776:	jne    81779c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817778:	lea    0x238(%rbx),%rdi
  81777f:	call   *0x6699a3(%rip)        # e81128 <_DYNAMIC+0x510>
  817785:	jmp    81779c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817787:	call   *0x6696db(%rip)        # e80e68 <_DYNAMIC+0x250>
  81778d:	mov    %rax,%r14
  817790:	lea    0x230(%rbx),%rdi
  817797:	call   817a00 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81779c:	lea    0x258(%rbx),%rdi
  8177a3:	call   817a00 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8177a8:	lea    0x280(%rbx),%rdi
  8177af:	call   817a00 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8177b4:	lea    0x2a8(%rbx),%rdi
  8177bb:	call   817a00 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8177c0:	lea    0x2d0(%rbx),%rdi
  8177c7:	call   817a00 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8177cc:	lea    0x78(%rbx),%rdi
  8177d0:	call   817900 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  8177d5:	mov    0x328(%rbx),%rdi
  8177dc:	call   816550 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  8177e1:	mov    (%rbx),%rsi
  8177e4:	test   %rsi,%rsi
  8177e7:	jne    817862 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  8177e9:	mov    0x18(%rbx),%rsi
  8177ed:	test   %rsi,%rsi
  8177f0:	jne    817882 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  8177f6:	mov    0x30(%rbx),%rsi
  8177fa:	test   %rsi,%rsi
  8177fd:	jne    8178a2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  817803:	mov    0x48(%rbx),%rsi
  817807:	test   %rsi,%rsi
  81780a:	jne    8178c2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  817810:	mov    0x60(%rbx),%rsi
  817814:	test   %rsi,%rsi
  817817:	je     81782c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817819:	mov    0x68(%rbx),%rdi
  81781d:	shl    $0x5,%rsi
  817821:	mov    $0x4,%edx
  817826:	call   *0x669634(%rip)        # e80e60 <_DYNAMIC+0x248>
  81782c:	lea    0x2f8(%rbx),%rdi
  817833:	call   819d10 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  817838:	mov    0x330(%rbx),%rax
  81783f:	test   %rax,%rax
  817842:	je     81785a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  817844:	lock decq (%rax)
  817848:	jne    81785a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  81784a:	add    $0x330,%rbx
  817851:	mov    %rbx,%rdi
  817854:	call   *0x6698d6(%rip)        # e81130 <_DYNAMIC+0x518>
  81785a:	mov    %r14,%rdi
  81785d:	call   e2d970 <_Unwind_Resume@plt>
  817862:	mov    0x8(%rbx),%rdi
  817866:	shl    $0x4,%rsi
  81786a:	mov    $0x4,%edx
  81786f:	call   *0x6695eb(%rip)        # e80e60 <_DYNAMIC+0x248>
  817875:	mov    0x18(%rbx),%rsi
  817879:	test   %rsi,%rsi
  81787c:	je     8177f6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  817882:	mov    0x20(%rbx),%rdi
  817886:	shl    $0x3,%rsi
  81788a:	mov    $0x4,%edx
  81788f:	call   *0x6695cb(%rip)        # e80e60 <_DYNAMIC+0x248>
  817895:	mov    0x30(%rbx),%rsi
  817899:	test   %rsi,%rsi
  81789c:	je     817803 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  8178a2:	mov    0x38(%rbx),%rdi
  8178a6:	shl    $0x2,%rsi
  8178aa:	mov    $0x4,%edx
  8178af:	call   *0x6695ab(%rip)        # e80e60 <_DYNAMIC+0x248>
  8178b5:	mov    0x48(%rbx),%rsi
  8178b9:	test   %rsi,%rsi
  8178bc:	je     817810 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  8178c2:	mov    0x50(%rbx),%rdi
  8178c6:	shl    $0x2,%rsi
  8178ca:	mov    $0x4,%edx
  8178cf:	call   *0x66958b(%rip)        # e80e60 <_DYNAMIC+0x248>
  8178d5:	mov    0x60(%rbx),%rsi
  8178d9:	test   %rsi,%rsi
  8178dc:	jne    817819 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  8178e2:	jmp    81782c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  8178e7:	call   *0x66957b(%rip)        # e80e68 <_DYNAMIC+0x250>
  8178ed:	mov    %rax,%r14
  8178f0:	jmp    8177d5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817900 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  817900:	push   %r14
  817902:	push   %rbx
  817903:	push   %rax
  817904:	mov    %rdi,%rbx
  817907:	mov    (%rdi),%rax
  81790a:	lock decq (%rax)
  81790e:	jne    817919 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  817910:	mov    %rbx,%rdi
  817913:	call   *0x6697e7(%rip)        # e81100 <_DYNAMIC+0x4e8>
  817919:	mov    0x50(%rbx),%rax
  81791d:	lock decq (%rax)
  817921:	jne    81792d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  817923:	lea    0x50(%rbx),%rdi
  817927:	call   *0x6697cb(%rip)        # e810f8 <_DYNAMIC+0x4e0>
  81792d:	mov    0x58(%rbx),%rax
  817931:	lock decq (%rax)
  817935:	jne    817941 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  817937:	lea    0x58(%rbx),%rdi
  81793b:	call   *0x6697bf(%rip)        # e81100 <_DYNAMIC+0x4e8>
  817941:	mov    0xb0(%rbx),%rsi
  817948:	test   %rsi,%rsi
  81794b:	je     81797d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81794d:	mov    %rsi,%rax
  817950:	shl    $0x5,%rax
  817954:	add    %rax,%rsi
  817957:	add    $0x31,%rsi
  81795b:	je     81797d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81795d:	mov    0xa8(%rbx),%rdi
  817964:	sub    %rax,%rdi
  817967:	add    $0xffffffffffffffe0,%rdi
  81796b:	mov    $0x10,%edx
  817970:	add    $0x8,%rsp
  817974:	pop    %rbx
  817975:	pop    %r14
  817977:	jmp    *0x6694e3(%rip)        # e80e60 <_DYNAMIC+0x248>
  81797d:	add    $0x8,%rsp
  817981:	pop    %rbx
  817982:	pop    %r14
  817984:	ret
  817985:	mov    %rax,%r14
  817988:	jmp    8179b5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81798a:	mov    %rax,%r14
  81798d:	mov    0x58(%rbx),%rax
  817991:	lock decq (%rax)
  817995:	jne    8179b5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817997:	lea    0x58(%rbx),%rdi
  81799b:	call   *0x66975f(%rip)        # e81100 <_DYNAMIC+0x4e8>
  8179a1:	jmp    8179b5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  8179a3:	call   *0x6694bf(%rip)        # e80e68 <_DYNAMIC+0x250>
  8179a9:	mov    %rax,%r14
  8179ac:	lea    0x50(%rbx),%rdi
  8179b0:	call   817b00 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  8179b5:	add    $0xa8,%rbx
  8179bc:	mov    %rbx,%rdi
  8179bf:	call   819d50 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  8179c4:	mov    %r14,%rdi
  8179c7:	call   e2d970 <_Unwind_Resume@plt>
  8179cc:	call   *0x669496(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008179e0 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  8179e0:	cmpl   $0x1,(%rdi)
  8179e3:	ja     8179fd <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  8179e5:	mov    0x8(%rdi),%rsi
  8179e9:	test   %rsi,%rsi
  8179ec:	je     8179fd <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  8179ee:	mov    0x10(%rdi),%rdi
  8179f2:	mov    $0x1,%edx
  8179f7:	jmp    *0x669463(%rip)        # e80e60 <_DYNAMIC+0x248>
  8179fd:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817a00 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  817a00:	push   %r14
  817a02:	push   %rbx
  817a03:	push   %rax
  817a04:	mov    %rdi,%rbx
  817a07:	mov    (%rdi),%rax
  817a0a:	lock decq (%rax)
  817a0e:	jne    817a19 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  817a10:	mov    %rbx,%rdi
  817a13:	call   *0x669707(%rip)        # e81120 <_DYNAMIC+0x508>
  817a19:	mov    0x8(%rbx),%rax
  817a1d:	lock decq (%rax)
  817a21:	jne    817a37 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  817a23:	add    $0x8,%rbx
  817a27:	mov    %rbx,%rdi
  817a2a:	add    $0x8,%rsp
  817a2e:	pop    %rbx
  817a2f:	pop    %r14
  817a31:	jmp    *0x6696f1(%rip)        # e81128 <_DYNAMIC+0x510>
  817a37:	add    $0x8,%rsp
  817a3b:	pop    %rbx
  817a3c:	pop    %r14
  817a3e:	ret
  817a3f:	mov    %rax,%r14
  817a42:	mov    0x8(%rbx),%rax
  817a46:	lock decq (%rax)
  817a4a:	jne    817a59 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  817a4c:	add    $0x8,%rbx
  817a50:	mov    %rbx,%rdi
  817a53:	call   *0x6696cf(%rip)        # e81128 <_DYNAMIC+0x510>
  817a59:	mov    %r14,%rdi
  817a5c:	call   e2d970 <_Unwind_Resume@plt>
  817a61:	call   *0x669401(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008183d0 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  8183d0:	sub    $0x18,%rsp
  8183d4:	mov    %rsi,%rax
  8183d7:	mov    (%rdi),%ecx
  8183d9:	lea    -0x747558(%rip),%rdx        # d0e88 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  8183e0:	movslq (%rdx,%rcx,4),%rcx
  8183e4:	add    %rdx,%rcx
  8183e7:	jmp    *%rcx
  8183e9:	add    $0x8,%rdi
  8183ed:	mov    %rdi,0x10(%rsp)
  8183f2:	lea    -0x743ba7(%rip),%rsi        # d4852 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4582>
  8183f9:	jmp    818488 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  8183fe:	lea    -0x743b8a(%rip),%rsi        # d487b <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x45ab>
  818405:	mov    $0x13,%edx
  81840a:	mov    %rax,%rdi
  81840d:	add    $0x18,%rsp
  818411:	jmp    *0x668b39(%rip)        # e80f50 <_DYNAMIC+0x338>
  818417:	add    $0x4,%rdi
  81841b:	mov    %rdi,0x10(%rsp)
  818420:	lea    -0x743bc9(%rip),%rsi        # d485e <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x458e>
  818427:	lea    0x616e4a(%rip),%r8        # e2f278 <__frame_dummy_init_array_entry+0x8c8>
  81842e:	lea    0x10(%rsp),%rcx
  818433:	mov    $0x11,%edx
  818438:	mov    %rax,%rdi
  81843b:	call   *0x668b17(%rip)        # e80f58 <_DYNAMIC+0x340>
  818441:	add    $0x18,%rsp
  818445:	ret
  818446:	lea    -0x743bde(%rip),%rsi        # d486f <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x459f>
  81844d:	mov    $0xc,%edx
  818452:	mov    %rax,%rdi
  818455:	add    $0x18,%rsp
  818459:	jmp    *0x668af1(%rip)        # e80f50 <_DYNAMIC+0x338>
  81845f:	lea    -0x743bc2(%rip),%rsi        # d48a4 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x45d4>
  818466:	mov    $0x9,%edx
  81846b:	mov    %rax,%rdi
  81846e:	add    $0x18,%rsp
  818472:	jmp    *0x668ad8(%rip)        # e80f50 <_DYNAMIC+0x338>
  818478:	add    $0x8,%rdi
  81847c:	mov    %rdi,0x10(%rsp)
  818481:	lea    -0x743c30(%rip),%rsi        # d4858 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4588>
  818488:	lea    0x616dc9(%rip),%r8        # e2f258 <__frame_dummy_init_array_entry+0x8a8>
  81848f:	lea    0x10(%rsp),%rcx
  818494:	mov    $0x6,%edx
  818499:	mov    %rax,%rdi
  81849c:	call   *0x668ab6(%rip)        # e80f58 <_DYNAMIC+0x340>
  8184a2:	add    $0x18,%rsp
  8184a6:	ret
  8184a7:	add    $0x8,%rdi
  8184ab:	mov    %rdi,0x10(%rsp)
  8184b0:	lea    0x616de1(%rip),%rcx        # e2f298 <__frame_dummy_init_array_entry+0x8e8>
  8184b7:	mov    %rcx,(%rsp)
  8184bb:	lea    -0x743c34(%rip),%rsi        # d488e <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x45be>
  8184c2:	lea    -0x76965d(%rip),%rcx        # aee6c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  8184c9:	lea    0x10(%rsp),%r9
  8184ce:	mov    $0x9,%edx
  8184d3:	mov    $0x4,%r8d
  8184d9:	mov    %rax,%rdi
  8184dc:	call   *0x668c5e(%rip)        # e81140 <_DYNAMIC+0x528>
  8184e2:	add    $0x18,%rsp
  8184e6:	ret
  8184e7:	lea    -0x743c57(%rip),%rsi        # d4897 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x45c7>
  8184ee:	mov    $0xd,%edx
  8184f3:	mov    %rax,%rdi
  8184f6:	add    $0x18,%rsp
  8184fa:	jmp    *0x668a50(%rip)        # e80f50 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819d50 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819d50:	mov    0x8(%rdi),%rsi
  819d54:	test   %rsi,%rsi
  819d57:	je     819d7e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819d59:	mov    %rsi,%rax
  819d5c:	shl    $0x5,%rax
  819d60:	add    %rax,%rsi
  819d63:	add    $0x31,%rsi
  819d67:	je     819d7e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819d69:	mov    (%rdi),%rdi
  819d6c:	sub    %rax,%rdi
  819d6f:	add    $0xffffffffffffffe0,%rdi
  819d73:	mov    $0x10,%edx
  819d78:	jmp    *0x6670e2(%rip)        # e80e60 <_DYNAMIC+0x248>
  819d7e:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819d80 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819d80:	mov    0x8(%rdi),%rsi
  819d84:	test   %rsi,%rsi
  819d87:	je     819dae <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819d89:	mov    %rsi,%rax
  819d8c:	shl    $0x4,%rax
  819d90:	add    %rax,%rsi
  819d93:	add    $0x21,%rsi
  819d97:	je     819dae <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819d99:	mov    (%rdi),%rdi
  819d9c:	sub    %rax,%rdi
  819d9f:	add    $0xfffffffffffffff0,%rdi
  819da3:	mov    $0x10,%edx
  819da8:	jmp    *0x6670b2(%rip)        # e80e60 <_DYNAMIC+0x248>
  819dae:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b640 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b640:	push   %r14
  81b642:	push   %rbx
  81b643:	sub    $0x38,%rsp
  81b647:	mov    %rdi,%rbx
  81b64a:	cmpq   $0x0,(%rsi)
  81b64e:	je     81b758 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b654:	movdqu (%rsi),%xmm0
  81b658:	movdqu 0x10(%rsi),%xmm1
  81b65d:	movdqu 0x20(%rsi),%xmm2
  81b662:	movdqa %xmm2,0x20(%rsp)
  81b668:	movdqa %xmm1,0x10(%rsp)
  81b66e:	movdqa %xmm0,(%rsp)
  81b673:	cmpq   $0x0,0x18(%rcx)
  81b678:	je     81b76c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b67e:	lea    0x10(%rsp),%rsi
  81b683:	lea    0x20(%rcx),%rdi
  81b687:	mov    %rcx,%r14
  81b68a:	call   824880 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b68f:	mov    %rax,%rsi
  81b692:	shr    $0x39,%rsi
  81b696:	mov    (%r14),%rcx
  81b699:	mov    0x8(%r14),%rdx
  81b69d:	movd   %esi,%xmm0
  81b6a1:	punpcklbw %xmm0,%xmm0
  81b6a5:	pshuflw $0x0,%xmm0,%xmm0
  81b6aa:	pshufd $0x44,%xmm0,%xmm0
  81b6af:	mov    0x10(%rsp),%rsi
  81b6b4:	movzwl 0x1c(%rsp),%edi
  81b6b9:	xor    %r8d,%r8d
  81b6bc:	mov    0x18(%rsp),%r9d
  81b6c1:	pcmpeqd %xmm1,%xmm1
  81b6c5:	and    %rdx,%rax
  81b6c8:	movdqu (%rcx,%rax,1),%xmm2
  81b6cd:	movdqa %xmm2,%xmm3
  81b6d1:	pcmpeqb %xmm0,%xmm3
  81b6d5:	pmovmskb %xmm3,%r10d
  81b6da:	test   %r10d,%r10d
  81b6dd:	je     81b720 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b6df:	tzcnt  %r10d,%r14d
  81b6e4:	add    %rax,%r14
  81b6e7:	and    %rdx,%r14
  81b6ea:	shl    $0x5,%r14
  81b6ee:	mov    %rcx,%r11
  81b6f1:	sub    %r14,%r11
  81b6f4:	cmp    -0x20(%r11),%rsi
  81b6f8:	jne    81b707 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b6fa:	cmp    -0x14(%r11),%di
  81b6ff:	jne    81b707 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b701:	cmp    -0x18(%r11),%r9d
  81b705:	je     81b73b <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b707:	lea    -0x1(%r10),%r11d
  81b70b:	and    %r10w,%r11w
  81b70f:	mov    %r11d,%r10d
  81b712:	jne    81b6df <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b714:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b720:	pcmpeqb %xmm1,%xmm2
  81b724:	pmovmskb %xmm2,%r10d
  81b729:	test   %r10d,%r10d
  81b72c:	jne    81b76c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b72e:	add    %r8,%rax
  81b731:	add    $0x10,%rax
  81b735:	add    $0x10,%r8
  81b739:	jmp    81b6c5 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b73b:	mov    -0x4(%r11),%eax
  81b73f:	shl    $0x10,%eax
  81b742:	or     -0x8(%r11),%eax
  81b746:	mov    -0x10(%r11),%rcx
  81b74a:	mov    %rcx,(%rbx)
  81b74d:	mov    %eax,0x8(%rbx)
  81b750:	add    $0x38,%rsp
  81b754:	pop    %rbx
  81b755:	pop    %r14
  81b757:	ret
  81b758:	mov    0x8(%rdx),%eax
  81b75b:	mov    %eax,0x8(%rbx)
  81b75e:	mov    (%rdx),%rax
  81b761:	mov    %rax,(%rbx)
  81b764:	add    $0x38,%rsp
  81b768:	pop    %rbx
  81b769:	pop    %r14
  81b76b:	ret
  81b76c:	lea    -0x746ae9(%rip),%rdi        # d4c8a <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b773:	lea    0x613f56(%rip),%rdx        # e2f6d0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x68>
  81b77a:	mov    $0x16,%esi
  81b77f:	call   *0x665a33(%rip)        # e811b8 <_DYNAMIC+0x5a0>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081ba80 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81ba80:	push   %r14
  81ba82:	push   %rbx
  81ba83:	push   %rax
  81ba84:	mov    %rdi,%rbx
  81ba87:	mov    (%rdi),%rax
  81ba8a:	lock decq (%rax)
  81ba8e:	jne    81ba99 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81ba90:	mov    %rbx,%rdi
  81ba93:	call   *0x665667(%rip)        # e81100 <_DYNAMIC+0x4e8>
  81ba99:	mov    0x50(%rbx),%rax
  81ba9d:	lock decq (%rax)
  81baa1:	jne    81baad <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81baa3:	lea    0x50(%rbx),%rdi
  81baa7:	call   *0x66564b(%rip)        # e810f8 <_DYNAMIC+0x4e0>
  81baad:	mov    0x58(%rbx),%rax
  81bab1:	lock decq (%rax)
  81bab5:	jne    81bac1 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81bab7:	lea    0x58(%rbx),%rdi
  81babb:	call   *0x66563f(%rip)        # e81100 <_DYNAMIC+0x4e8>
  81bac1:	mov    0xb0(%rbx),%rsi
  81bac8:	test   %rsi,%rsi
  81bacb:	je     81bafd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bacd:	mov    %rsi,%rax
  81bad0:	shl    $0x5,%rax
  81bad4:	add    %rax,%rsi
  81bad7:	add    $0x31,%rsi
  81badb:	je     81bafd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81badd:	mov    0xa8(%rbx),%rdi
  81bae4:	sub    %rax,%rdi
  81bae7:	add    $0xffffffffffffffe0,%rdi
  81baeb:	mov    $0x10,%edx
  81baf0:	add    $0x8,%rsp
  81baf4:	pop    %rbx
  81baf5:	pop    %r14
  81baf7:	jmp    *0x665363(%rip)        # e80e60 <_DYNAMIC+0x248>
  81bafd:	add    $0x8,%rsp
  81bb01:	pop    %rbx
  81bb02:	pop    %r14
  81bb04:	ret
  81bb05:	mov    %rax,%r14
  81bb08:	jmp    81bb35 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb0a:	mov    %rax,%r14
  81bb0d:	mov    0x58(%rbx),%rax
  81bb11:	lock decq (%rax)
  81bb15:	jne    81bb35 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb17:	lea    0x58(%rbx),%rdi
  81bb1b:	call   *0x6655df(%rip)        # e81100 <_DYNAMIC+0x4e8>
  81bb21:	jmp    81bb35 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb23:	call   *0x66533f(%rip)        # e80e68 <_DYNAMIC+0x250>
  81bb29:	mov    %rax,%r14
  81bb2c:	lea    0x50(%rbx),%rdi
  81bb30:	call   81c3d0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bb35:	add    $0xa8,%rbx
  81bb3c:	mov    %rbx,%rdi
  81bb3f:	call   823250 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bb44:	mov    %r14,%rdi
  81bb47:	call   e2d970 <_Unwind_Resume@plt>
  81bb4c:	call   *0x665316(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bb60:	push   %r14
  81bb62:	push   %rbx
  81bb63:	push   %rax
  81bb64:	mov    %rdi,%rbx
  81bb67:	mov    (%rdi),%rax
  81bb6a:	lock decq (%rax)
  81bb6e:	jne    81bb79 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bb70:	mov    %rbx,%rdi
  81bb73:	call   *0x6655a7(%rip)        # e81120 <_DYNAMIC+0x508>
  81bb79:	mov    0x8(%rbx),%rax
  81bb7d:	lock decq (%rax)
  81bb81:	jne    81bb97 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bb83:	add    $0x8,%rbx
  81bb87:	mov    %rbx,%rdi
  81bb8a:	add    $0x8,%rsp
  81bb8e:	pop    %rbx
  81bb8f:	pop    %r14
  81bb91:	jmp    *0x665591(%rip)        # e81128 <_DYNAMIC+0x510>
  81bb97:	add    $0x8,%rsp
  81bb9b:	pop    %rbx
  81bb9c:	pop    %r14
  81bb9e:	ret
  81bb9f:	mov    %rax,%r14
  81bba2:	mov    0x8(%rbx),%rax
  81bba6:	lock decq (%rax)
  81bbaa:	jne    81bbb9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bbac:	add    $0x8,%rbx
  81bbb0:	mov    %rbx,%rdi
  81bbb3:	call   *0x66556f(%rip)        # e81128 <_DYNAMIC+0x510>
  81bbb9:	mov    %r14,%rdi
  81bbbc:	call   e2d970 <_Unwind_Resume@plt>
  81bbc1:	call   *0x6652a1(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c500 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c500:	push   %rbp
  81c501:	push   %r15
  81c503:	push   %r14
  81c505:	push   %r13
  81c507:	push   %r12
  81c509:	push   %rbx
  81c50a:	sub    $0x28,%rsp
  81c50e:	movss  0x8c(%rdi),%xmm3
  81c516:	movss  -0x76d502(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c51e:	movaps %xmm3,%xmm1
  81c521:	subss  %xmm0,%xmm1
  81c525:	cvttss2si %xmm1,%rax
  81c52a:	cvttss2si %xmm3,%r8
  81c52f:	mov    %r8,%rcx
  81c532:	sar    $0x3f,%rcx
  81c536:	and    %rax,%rcx
  81c539:	or     %r8,%rcx
  81c53c:	xor    %r9d,%r9d
  81c53f:	xorps  %xmm1,%xmm1
  81c542:	ucomiss %xmm1,%xmm3
  81c545:	cmovb  %r9,%rcx
  81c549:	movss  -0x76d531(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c551:	ucomiss %xmm2,%xmm3
  81c554:	mov    $0xffffffffffffffff,%rax
  81c55b:	cmova  %rax,%rcx
  81c55f:	movss  0x94(%rdi),%xmm3
  81c567:	mov    %rcx,%r8
  81c56a:	shr    $0x4,%r8
  81c56e:	movaps %xmm3,%xmm4
  81c571:	subss  %xmm0,%xmm4
  81c575:	cvttss2si %xmm4,%r10
  81c57a:	cvttss2si %xmm3,%r11
  81c57f:	mov    %r11,%rbx
  81c582:	sar    $0x3f,%rbx
  81c586:	and    %r10,%rbx
  81c589:	or     %r11,%rbx
  81c58c:	ucomiss %xmm1,%xmm3
  81c58f:	cmovb  %r9,%rbx
  81c593:	ucomiss %xmm2,%xmm3
  81c596:	cmova  %rax,%rbx
  81c59a:	mov    %rsi,0x18(%rsp)
  81c59f:	lea    (%rcx,%rbx,1),%r11
  81c5a3:	dec    %r11
  81c5a6:	shr    $0x4,%r11
  81c5aa:	cmp    %r11,%r8
  81c5ad:	jbe    81c5be <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c5af:	add    $0x28,%rsp
  81c5b3:	pop    %rbx
  81c5b4:	pop    %r12
  81c5b6:	pop    %r13
  81c5b8:	pop    %r14
  81c5ba:	pop    %r15
  81c5bc:	pop    %rbp
  81c5bd:	ret
  81c5be:	movss  0x88(%rdi),%xmm3
  81c5c6:	movaps %xmm3,%xmm4
  81c5c9:	subss  %xmm0,%xmm4
  81c5cd:	cvttss2si %xmm4,%rsi
  81c5d2:	cvttss2si %xmm3,%r9
  81c5d7:	mov    %r9,%rcx
  81c5da:	sar    $0x3f,%rcx
  81c5de:	and    %rsi,%rcx
  81c5e1:	or     %r9,%rcx
  81c5e4:	xor    %r10d,%r10d
  81c5e7:	ucomiss %xmm1,%xmm3
  81c5ea:	cmovb  %r10,%rcx
  81c5ee:	ucomiss %xmm2,%xmm3
  81c5f1:	cmova  %rax,%rcx
  81c5f5:	movss  0x90(%rdi),%xmm3
  81c5fd:	mov    %rcx,%r14
  81c600:	shr    $0x4,%r14
  81c604:	movaps %xmm3,%xmm4
  81c607:	subss  %xmm0,%xmm4
  81c60b:	cvttss2si %xmm4,%rsi
  81c610:	cvttss2si %xmm3,%rdi
  81c615:	mov    %rdi,%r9
  81c618:	sar    $0x3f,%r9
  81c61c:	and    %rsi,%r9
  81c61f:	or     %rdi,%r9
  81c622:	ucomiss %xmm1,%xmm3
  81c625:	cmovb  %r10,%r9
  81c629:	ucomiss %xmm2,%xmm3
  81c62c:	cmova  %rax,%r9
  81c630:	lea    (%r9,%rcx,1),%rbx
  81c634:	dec    %rbx
  81c637:	shr    $0x4,%rbx
  81c63b:	mov    %r14,0x10(%rsp)
  81c640:	cmp    %rbx,%r14
  81c643:	jbe    81c66d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c645:	data16 cs nopw 0x0(%rax,%rax,1)
  81c650:	mov    %r8,%rax
  81c653:	cmp    %r11,%r8
  81c656:	adc    $0x0,%r8
  81c65a:	cmp    %r11,%rax
  81c65d:	jae    81c5af <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c663:	cmp    %r11,%r8
  81c666:	jbe    81c650 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c668:	jmp    81c5af <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c66d:	mov    (%rdx),%r14
  81c670:	mov    0x8(%rdx),%r15
  81c674:	mov    0x10(%rdx),%r12
  81c678:	mov    0x18(%rdx),%r13
  81c67c:	mov    0x20(%rdx),%rdx
  81c680:	mov    %r11,0x8(%rsp)
  81c685:	data16 cs nopw 0x0(%rax,%rax,1)
  81c690:	mov    %r8,%rbp
  81c693:	cmp    %r11,%r8
  81c696:	adc    $0x0,%r8
  81c69a:	mov    %rbp,0x20(%rsp)
  81c69f:	imul   0x18(%rsp),%rbp
  81c6a5:	mov    0x10(%rsp),%r9
  81c6aa:	mov    %r9,%rsi
  81c6ad:	nopl   (%rax)
  81c6b0:	cmp    %rbx,%r9
  81c6b3:	adc    $0x0,%rsi
  81c6b7:	lea    (%r9,%rbp,1),%rdi
  81c6bb:	mov    0x10(%r14),%rax
  81c6bf:	cmp    %rax,%rdi
  81c6c2:	jae    81c730 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c6c4:	mov    0x8(%r14),%rcx
  81c6c8:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c6cd:	jo     81c705 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c6cf:	mov    0x10(%r12),%rax
  81c6d4:	cmp    %rax,%rdi
  81c6d7:	jae    81c740 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c6d9:	mov    0x8(%r12),%rax
  81c6de:	mov    0x0(%r13),%r11d
  81c6e2:	inc    %r11d
  81c6e5:	cmp    (%rax,%rdi,4),%r11d
  81c6e9:	jb     81c705 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c6eb:	mov    (%rcx,%rdi,8),%eax
  81c6ee:	dec    %eax
  81c6f0:	mov    %eax,(%rcx,%rdi,8)
  81c6f3:	mov    0x10(%r15),%rcx
  81c6f7:	cmp    %rax,%rcx
  81c6fa:	jbe    81c750 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c6fc:	mov    0x8(%r15),%rcx
  81c700:	mov    (%rdx),%edi
  81c702:	mov    %edi,(%rcx,%rax,4)
  81c705:	cmp    %rbx,%r9
  81c708:	jae    81c712 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c70a:	mov    %rsi,%r9
  81c70d:	cmp    %rbx,%rsi
  81c710:	jbe    81c6b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c712:	mov    0x8(%rsp),%r11
  81c717:	cmp    %r11,0x20(%rsp)
  81c71c:	jae    81c5af <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c722:	cmp    %r11,%r8
  81c725:	jbe    81c690 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c72b:	jmp    81c5af <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c730:	lea    0x612fb1(%rip),%rdx        # e2f6e8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c737:	mov    %rax,%rsi
  81c73a:	call   *0x6649d0(%rip)        # e81110 <_DYNAMIC+0x4f8>
  81c740:	lea    0x612fb9(%rip),%rdx        # e2f700 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c747:	mov    %rax,%rsi
  81c74a:	call   *0x6649c0(%rip)        # e81110 <_DYNAMIC+0x4f8>
  81c750:	lea    0x612fc1(%rip),%rdx        # e2f718 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  81c757:	mov    %rax,%rdi
  81c75a:	mov    %rcx,%rsi
  81c75d:	call   *0x6649ad(%rip)        # e81110 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>> bytes=321 frame=248

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c770 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>:
  81c770:	push   %rbp
  81c771:	push   %r15
  81c773:	push   %r14
  81c775:	push   %r13
  81c777:	push   %r12
  81c779:	push   %rbx
  81c77a:	sub    $0xc8,%rsp
  81c781:	mov    %edx,%ebp
  81c783:	mov    %rsi,%r14
  81c786:	mov    %rdi,(%rsp)
  81c78a:	lea    0x8(%rsp),%rdi
  81c78f:	call   *0x664a3b(%rip)        # e811d0 <_DYNAMIC+0x5b8>
  81c795:	mov    0x8(%rsp),%rsi
  81c79a:	xor    %r13d,%r13d
  81c79d:	test   $0x1,%bpl
  81c7a1:	je     81c840 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xd0>
  81c7a7:	test   %rsi,%rsi
  81c7aa:	je     81c885 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c7b0:	lea    0x70(%rsp),%r15
  81c7b5:	lea    0x8(%rsp),%r12
  81c7ba:	mov    0x664a0f(%rip),%rbp        # e811d0 <_DYNAMIC+0x5b8>
  81c7c1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c7d0:	mov    0x18(%rsp),%rbx
  81c7d5:	cmp    $0x1,%rbx
  81c7d9:	jbe    81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb0>
  81c7db:	mov    0x10(%rsp),%rax
  81c7e0:	mov    (%rax),%edx
  81c7e2:	mov    %r15,%rdi
  81c7e5:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c7ea:	movss  0x74(%rsp),%xmm0
  81c7f0:	xorps  %xmm1,%xmm1
  81c7f3:	ucomiss %xmm1,%xmm0
  81c7f6:	lea    (%rbx,%rbx,1),%rax
  81c7fa:	lea    0x5(%rbx,%rbx,1),%rcx
  81c7ff:	lea    (%rax,%rax,2),%rdx
  81c803:	mov    %rcx,%rax
  81c806:	cmovne %rdx,%rax
  81c80a:	cmovp  %rdx,%rax
  81c80e:	cmpb   $0x3,0x70(%rsp)
  81c813:	cmovne %rcx,%rax
  81c817:	jmp    81c827 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb7>
  81c819:	nopl   0x0(%rax)
  81c820:	add    %rbx,%rbx
  81c823:	lea    (%rbx,%rbx,2),%rax
  81c827:	add    %rax,%r13
  81c82a:	jb     81c8a5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c82c:	mov    %r12,%rdi
  81c82f:	mov    %r14,%rsi
  81c832:	call   *%rbp
  81c834:	mov    0x8(%rsp),%rsi
  81c839:	test   %rsi,%rsi
  81c83c:	jne    81c7d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x60>
  81c83e:	jmp    81c885 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c840:	test   %rsi,%rsi
  81c843:	je     81c885 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c845:	lea    0x8(%rsp),%r15
  81c84a:	mov    0x66497f(%rip),%r12        # e811d0 <_DYNAMIC+0x5b8>
  81c851:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c860:	mov    %r13,%rax
  81c863:	mov    0x18(%rsp),%rcx
  81c868:	add    %rcx,%rcx
  81c86b:	lea    (%rcx,%rcx,2),%r13
  81c86f:	add    %rax,%r13
  81c872:	jb     81c8a5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c874:	mov    %r15,%rdi
  81c877:	mov    %r14,%rsi
  81c87a:	call   *%r12
  81c87d:	cmpq   $0x0,0x8(%rsp)
  81c883:	jne    81c860 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xf0>
  81c885:	mov    (%rsp),%rax
  81c889:	mov    %r13,0x8(%rax)
  81c88d:	movl   $0xffffffff,(%rax)
  81c893:	add    $0xc8,%rsp
  81c89a:	pop    %rbx
  81c89b:	pop    %r12
  81c89d:	pop    %r13
  81c89f:	pop    %r14
  81c8a1:	pop    %r15
  81c8a3:	pop    %rbp
  81c8a4:	ret
  81c8a5:	mov    (%rsp),%rax
  81c8a9:	movl   $0x6,(%rax)
  81c8af:	jmp    81c893 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x123>

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb00 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81cb00:	push   %rbp
  81cb01:	push   %r14
  81cb03:	push   %rbx
  81cb04:	cmp    0x341(%rdi),%sil
  81cb0b:	je     81cb4b <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81cb0d:	mov    0x330(%rdi),%rax
  81cb14:	test   %rax,%rax
  81cb17:	je     81cb39 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cb19:	lock decq (%rax)
  81cb1d:	jne    81cb39 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cb1f:	lea    0x330(%rdi),%rbx
  81cb26:	mov    %rdi,%r14
  81cb29:	mov    %rbx,%rdi
  81cb2c:	mov    %esi,%ebp
  81cb2e:	call   *0x6645fc(%rip)        # e81130 <_DYNAMIC+0x518>
  81cb34:	mov    %r14,%rdi
  81cb37:	mov    %ebp,%esi
  81cb39:	movq   $0x0,0x330(%rdi)
  81cb44:	mov    %sil,0x341(%rdi)
  81cb4b:	pop    %rbx
  81cb4c:	pop    %r14
  81cb4e:	pop    %rbp
  81cb4f:	ret
  81cb50:	movq   $0x0,(%rbx)
  81cb57:	mov    %rax,%rdi
  81cb5a:	call   e2d970 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=303 frame=120

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb60 <<gpui_gpu::renderer::Buffer>::write>:
  81cb60:	push   %r15
  81cb62:	push   %r14
  81cb64:	push   %r13
  81cb66:	push   %r12
  81cb68:	push   %rbx
  81cb69:	sub    $0x50,%rsp
  81cb6d:	mov    %rdx,%r14
  81cb70:	mov    %rdi,%rbx
  81cb73:	cmp    0x20(%rdi),%r8
  81cb77:	jbe    81cc2a <<gpui_gpu::renderer::Buffer>::write+0xca>
  81cb7d:	mov    %rcx,%r15
  81cb80:	mov    $0x1,%r13d
  81cb86:	cmp    $0x2,%r8
  81cb8a:	jb     81cba3 <<gpui_gpu::renderer::Buffer>::write+0x43>
  81cb8c:	lea    -0x1(%r8),%rax
  81cb90:	bsr    %rax,%rcx
  81cb94:	not    %ecx
  81cb96:	mov    $0xffffffffffffffff,%r13
  81cb9d:	shr    %cl,%r13
  81cba0:	inc    %r13
  81cba3:	mov    %r8,%r12
  81cba6:	lea    -0x747f0d(%rip),%rax        # d4ca0 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x142>
  81cbad:	mov    %rax,0x30(%rsp)
  81cbb2:	movq   $0xa,0x38(%rsp)
  81cbbb:	mov    %r13,0x40(%rsp)
  81cbc0:	movl   $0x88,0x48(%rsp)
  81cbc8:	movb   $0x0,0x4c(%rsp)
  81cbcd:	lea    0x8(%rsp),%rdi
  81cbd2:	lea    0x30(%rsp),%rdx
  81cbd7:	call   *0x66465b(%rip)        # e81238 <_DYNAMIC+0x620>
  81cbdd:	mov    %r13,0x28(%rsp)
  81cbe2:	mov    (%rbx),%rax
  81cbe5:	lock decq (%rax)
  81cbe9:	jne    81cbf4 <<gpui_gpu::renderer::Buffer>::write+0x94>
  81cbeb:	mov    %rbx,%rdi
  81cbee:	call   *0x66452c(%rip)        # e81120 <_DYNAMIC+0x508>
  81cbf4:	mov    0x8(%rbx),%rax
  81cbf8:	lock decq (%rax)
  81cbfc:	jne    81cc08 <<gpui_gpu::renderer::Buffer>::write+0xa8>
  81cbfe:	lea    0x8(%rbx),%rdi
  81cc02:	call   *0x664520(%rip)        # e81128 <_DYNAMIC+0x510>
  81cc08:	mov    0x28(%rsp),%rax
  81cc0d:	mov    %rax,0x20(%rbx)
  81cc11:	movups 0x8(%rsp),%xmm0
  81cc16:	movups 0x18(%rsp),%xmm1
  81cc1b:	movups %xmm1,0x10(%rbx)
  81cc1f:	movups %xmm0,(%rbx)
  81cc22:	mov    %r12,%r8
  81cc25:	mov    %r15,%rcx
  81cc28:	jmp    81cc2f <<gpui_gpu::renderer::Buffer>::write+0xcf>
  81cc2a:	test   %r8,%r8
  81cc2d:	je     81cc3d <<gpui_gpu::renderer::Buffer>::write+0xdd>
  81cc2f:	mov    %r14,%rdi
  81cc32:	mov    %rbx,%rsi
  81cc35:	xor    %edx,%edx
  81cc37:	call   *0x6645ab(%rip)        # e811e8 <_DYNAMIC+0x5d0>
  81cc3d:	add    $0x50,%rsp
  81cc41:	pop    %rbx
  81cc42:	pop    %r12
  81cc44:	pop    %r13
  81cc46:	pop    %r14
  81cc48:	pop    %r15
  81cc4a:	ret
  81cc4b:	mov    %rax,%r14
  81cc4e:	jmp    81cc67 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cc50:	mov    %rax,%r14
  81cc53:	mov    0x8(%rbx),%rax
  81cc57:	lock decq (%rax)
  81cc5b:	jne    81cc67 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cc5d:	lea    0x8(%rbx),%rdi
  81cc61:	call   *0x6644c1(%rip)        # e81128 <_DYNAMIC+0x510>
  81cc67:	mov    0x28(%rsp),%rax
  81cc6c:	mov    %rax,0x20(%rbx)
  81cc70:	movups 0x8(%rsp),%xmm0
  81cc75:	movups 0x18(%rsp),%xmm1
  81cc7a:	movups %xmm1,0x10(%rbx)
  81cc7e:	movups %xmm0,(%rbx)
  81cc81:	mov    %r14,%rdi
  81cc84:	call   e2d970 <_Unwind_Resume@plt>
  81cc89:	call   *0x6641d9(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc90 <<gpui_gpu::renderer::Atlas>::new>:
  81cc90:	push   %rbp
  81cc91:	push   %r14
  81cc93:	push   %rbx
  81cc94:	sub    $0x160,%rsp
  81cc9b:	mov    %edx,%ebp
  81cc9d:	mov    %rdi,%rbx
  81cca0:	lea    -0x747ffd(%rip),%rax        # d4caa <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x14c>
  81cca7:	mov    %rax,(%rsp)
  81ccab:	movq   $0xe,0x8(%rsp)
  81ccb4:	mov    %edx,0x10(%rsp)
  81ccb8:	mov    %edx,0x14(%rsp)
  81ccbc:	movaps -0x770753(%rip),%xmm0        # ac570 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81ccc3:	movups %xmm0,0x18(%rsp)
  81ccc8:	movl   $0x0,0x28(%rsp)
  81ccd0:	movl   $0x6,0x34(%rsp)
  81ccd8:	movq   $0x4,0x38(%rsp)
  81cce1:	movq   $0x0,0x40(%rsp)
  81ccea:	lea    0x110(%rsp),%r14
  81ccf2:	mov    %rsp,%rdx
  81ccf5:	mov    %r14,%rdi
  81ccf8:	call   *0x6643ba(%rip)        # e810b8 <_DYNAMIC+0x4a0>
  81ccfe:	movq   $0x0,0x18(%rsp)
  81cd07:	movl   $0xffffffff,0x30(%rsp)
  81cd0f:	movl   $0x0,(%rsp)
  81cd16:	movabs $0xffffffff00000000,%rax
  81cd20:	mov    %rax,0x28(%rsp)
  81cd25:	movq   $0x0,0x3c(%rsp)
  81cd2e:	movl   $0x0,0x8(%rsp)
  81cd36:	movl   $0x0,0x10(%rsp)
  81cd3e:	lea    0xb8(%rsp),%rdi
  81cd46:	mov    %rsp,%rdx
  81cd49:	mov    %r14,%rsi
  81cd4c:	call   *0x66436e(%rip)        # e810c0 <_DYNAMIC+0x4a8>
  81cd52:	movups 0x150(%rsp),%xmm0
  81cd5a:	movaps %xmm0,0xa0(%rsp)
  81cd62:	movups 0x110(%rsp),%xmm0
  81cd6a:	movups 0x120(%rsp),%xmm1
  81cd72:	movups 0x130(%rsp),%xmm2
  81cd7a:	movups 0x140(%rsp),%xmm3
  81cd82:	movaps %xmm3,0x90(%rsp)
  81cd8a:	movaps %xmm2,0x80(%rsp)
  81cd92:	movaps %xmm1,0x70(%rsp)
  81cd97:	movaps %xmm0,0x60(%rsp)
  81cd9c:	mov    0x108(%rsp),%rax
  81cda4:	mov    %rax,0x50(%rsp)
  81cda9:	movups 0xf8(%rsp),%xmm0
  81cdb1:	movaps %xmm0,0x40(%rsp)
  81cdb6:	movups 0xb8(%rsp),%xmm0
  81cdbe:	movups 0xc8(%rsp),%xmm1
  81cdc6:	movups 0xd8(%rsp),%xmm2
  81cdce:	movups 0xe8(%rsp),%xmm3
  81cdd6:	movaps %xmm3,0x30(%rsp)
  81cddb:	movaps %xmm2,0x20(%rsp)
  81cde0:	movaps %xmm1,0x10(%rsp)
  81cde5:	movaps %xmm0,(%rsp)
  81cde9:	mov    %fs:0x0,%rax
  81cdf2:	lea    -0x28(%rax),%rax
  81cdf9:	mov    %rax,%r14
  81cdfc:	cmpb   $0x1,0x10(%rax)
  81ce00:	jne    81ceeb <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81ce06:	mov    (%r14),%rax
  81ce09:	mov    0x8(%r14),%rdx
  81ce0d:	lea    0x1(%rax),%rcx
  81ce11:	mov    %rcx,(%r14)
  81ce14:	movaps 0xa0(%rsp),%xmm0
  81ce1c:	movups %xmm0,0x40(%rbx)
  81ce20:	movaps 0x60(%rsp),%xmm0
  81ce25:	movaps 0x70(%rsp),%xmm1
  81ce2a:	movaps 0x80(%rsp),%xmm2
  81ce32:	movaps 0x90(%rsp),%xmm3
  81ce3a:	movups %xmm3,0x30(%rbx)
  81ce3e:	movups %xmm2,0x20(%rbx)
  81ce42:	movups %xmm1,0x10(%rbx)
  81ce46:	movups %xmm0,(%rbx)
  81ce49:	movups 0xb8(%rsp),%xmm0
  81ce51:	movups 0xc8(%rsp),%xmm1
  81ce59:	movups 0xd8(%rsp),%xmm2
  81ce61:	movups 0xe8(%rsp),%xmm3
  81ce69:	movups %xmm0,0x50(%rbx)
  81ce6d:	movups %xmm1,0x60(%rbx)
  81ce71:	movups %xmm2,0x70(%rbx)
  81ce75:	movups %xmm3,0x80(%rbx)
  81ce7c:	movups 0xf8(%rsp),%xmm0
  81ce84:	movups %xmm0,0x90(%rbx)
  81ce8b:	mov    0x108(%rsp),%rcx
  81ce93:	mov    %rcx,0xa0(%rbx)
  81ce9a:	mov    %ebp,0xd8(%rbx)
  81cea0:	movq   $0x0,0xdc(%rbx)
  81ceab:	movl   $0x0,0xe4(%rbx)
  81ceb5:	movups 0x6128d4(%rip),%xmm0        # e2f790 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x128>
  81cebc:	movups %xmm0,0xa8(%rbx)
  81cec3:	movups 0x6128d6(%rip),%xmm0        # e2f7a0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x138>
  81ceca:	movups %xmm0,0xb8(%rbx)
  81ced1:	mov    %rax,0xc8(%rbx)
  81ced8:	mov    %rdx,0xd0(%rbx)
  81cedf:	add    $0x160,%rsp
  81cee6:	pop    %rbx
  81cee7:	pop    %r14
  81cee9:	pop    %rbp
  81ceea:	ret
  81ceeb:	call   *0x66434f(%rip)        # e81240 <_DYNAMIC+0x628>
  81cef1:	mov    %rax,(%r14)
  81cef4:	mov    %rdx,0x8(%r14)
  81cef8:	movb   $0x1,0x10(%r14)
  81cefd:	jmp    81ce0d <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cf02:	mov    %rax,%rbx
  81cf05:	mov    %rsp,%rdi
  81cf08:	call   81c3d0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cf0d:	mov    0x60(%rsp),%rax
  81cf12:	lock decq (%rax)
  81cf16:	jne    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf18:	lea    0x60(%rsp),%rdi
  81cf1d:	call   *0x6641dd(%rip)        # e81100 <_DYNAMIC+0x4e8>
  81cf23:	jmp    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf25:	mov    %rax,%rbx
  81cf28:	mov    0x110(%rsp),%rax
  81cf30:	lock decq (%rax)
  81cf34:	jne    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf36:	lea    0x110(%rsp),%rdi
  81cf3e:	call   *0x6641bc(%rip)        # e81100 <_DYNAMIC+0x4e8>
  81cf44:	mov    %rbx,%rdi
  81cf47:	call   e2d970 <_Unwind_Resume@plt>
  81cf4c:	call   *0x663f16(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cf60 <<gpui_gpu::renderer::Atlas>::insert>:
  81cf60:	push   %rbp
  81cf61:	push   %r15
  81cf63:	push   %r14
  81cf65:	push   %r13
  81cf67:	push   %r12
  81cf69:	push   %rbx
  81cf6a:	sub    $0x68,%rsp
  81cf6e:	mov    %rdx,%r12
  81cf71:	mov    %rsi,%r15
  81cf74:	mov    %rdi,%r14
  81cf77:	lea    0x10(%rdx),%r13
  81cf7b:	cmpq   $0x0,0xc0(%rdi)
  81cf83:	je     81d04b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81cf89:	lea    0xc8(%r14),%rdi
  81cf90:	mov    %r13,%rsi
  81cf93:	call   824880 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81cf98:	mov    %rax,%rsi
  81cf9b:	shr    $0x39,%rsi
  81cf9f:	mov    0xa8(%r14),%rcx
  81cfa6:	mov    0xb0(%r14),%rdx
  81cfad:	movd   %esi,%xmm0
  81cfb1:	punpcklbw %xmm0,%xmm0
  81cfb5:	pshuflw $0x0,%xmm0,%xmm0
  81cfba:	pshufd $0x44,%xmm0,%xmm0
  81cfbf:	mov    0x10(%r12),%rsi
  81cfc4:	movzwl 0x1c(%r12),%edi
  81cfca:	mov    0x18(%r12),%r8d
  81cfcf:	pcmpeqd %xmm1,%xmm1
  81cfd3:	xor    %r9d,%r9d
  81cfd6:	and    %rdx,%rax
  81cfd9:	movdqu (%rcx,%rax,1),%xmm2
  81cfde:	movdqa %xmm2,%xmm3
  81cfe2:	pcmpeqb %xmm0,%xmm3
  81cfe6:	pmovmskb %xmm3,%r10d
  81cfeb:	test   %r10d,%r10d
  81cfee:	je     81d030 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81cff0:	tzcnt  %r10d,%ebx
  81cff5:	add    %rax,%rbx
  81cff8:	and    %rdx,%rbx
  81cffb:	shl    $0x5,%rbx
  81cfff:	mov    %rcx,%r11
  81d002:	sub    %rbx,%r11
  81d005:	cmp    -0x20(%r11),%rsi
  81d009:	jne    81d01c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d00b:	cmp    -0x14(%r11),%di
  81d010:	jne    81d01c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d012:	cmp    -0x18(%r11),%r8d
  81d016:	je     81d0b3 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d01c:	lea    -0x1(%r10),%r11d
  81d020:	and    %r10w,%r11w
  81d024:	mov    %r11d,%r10d
  81d027:	jne    81cff0 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d029:	nopl   0x0(%rax)
  81d030:	pcmpeqb %xmm1,%xmm2
  81d034:	pmovmskb %xmm2,%r10d
  81d039:	test   %r10d,%r10d
  81d03c:	jne    81d04b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d03e:	add    %r9,%rax
  81d041:	add    $0x10,%rax
  81d045:	add    $0x10,%r9
  81d049:	jmp    81cfd6 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d04b:	mov    0x20(%r12),%ebp
  81d050:	xor    %eax,%eax
  81d052:	test   %ebp,%ebp
  81d054:	je     81d0ae <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d056:	mov    %r15,%rdi
  81d059:	mov    0x28(%r12),%r15d
  81d05e:	test   %r15d,%r15d
  81d061:	je     81d0ae <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d063:	mov    0xd8(%r14),%ecx
  81d06a:	cmp    %ebp,%ecx
  81d06c:	jb     81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d072:	cmp    %r15d,%ecx
  81d075:	jb     81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d07b:	mov    %r13,0x40(%rsp)
  81d080:	mov    0xdc(%r14),%r8d
  81d087:	mov    0xe4(%r14),%r13d
  81d08e:	lea    (%r8,%rbp,1),%edx
  81d092:	xor    %eax,%eax
  81d094:	cmp    %ecx,%edx
  81d096:	mov    $0x0,%ebx
  81d09b:	cmova  %r13d,%ebx
  81d09f:	add    0xe0(%r14),%ebx
  81d0a6:	lea    (%rbx,%r15,1),%esi
  81d0aa:	cmp    %ecx,%esi
  81d0ac:	jbe    81d0bf <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d0ae:	jmp    81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d0b3:	mov    $0x1,%eax
  81d0b8:	xor    %edx,%edx
  81d0ba:	jmp    81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d0bf:	cmp    %r13d,%r15d
  81d0c2:	cmova  %r15d,%r13d
  81d0c6:	cmp    %ecx,%edx
  81d0c8:	cmova  %eax,%r8d
  81d0cc:	lea    0xa8(%r14),%rax
  81d0d3:	mov    %rax,0x38(%rsp)
  81d0d8:	mov    %r14,0x48(%rsp)
  81d0dd:	movl   $0x0,0x50(%rsp)
  81d0e5:	mov    %r8d,0x54(%rsp)
  81d0ea:	mov    %ebx,0x58(%rsp)
  81d0ee:	movq   $0x0,0x5c(%rsp)
  81d0f7:	mov    (%r12),%rdx
  81d0fb:	mov    0x8(%r12),%rcx
  81d100:	mov    %rcx,0x30(%rsp)
  81d105:	movq   $0x0,0x8(%rsp)
  81d10e:	movl   $0x1,0x10(%rsp)
  81d116:	mov    %ebp,0x14(%rsp)
  81d11a:	movl   $0x1,0x18(%rsp)
  81d122:	mov    %r15d,0x1c(%rsp)
  81d127:	mov    %ebp,0x20(%rsp)
  81d12b:	mov    %r15d,0x24(%rsp)
  81d130:	movl   $0x1,0x28(%rsp)
  81d138:	cmova  %r15d,%r13d
  81d13c:	lea    0x48(%rsp),%rsi
  81d141:	mov    %r8,%r12
  81d144:	lea    0x8(%rsp),%r8
  81d149:	lea    0x20(%rsp),%r9
  81d14e:	call   *0x6640f4(%rip)        # e81248 <_DYNAMIC+0x630>
  81d154:	lea    (%r12,%rbp,1),%eax
  81d158:	mov    %eax,0xdc(%r14)
  81d15f:	mov    %ebx,0xe0(%r14)
  81d166:	mov    %r13d,0xe4(%r14)
  81d16d:	mov    0x40(%rsp),%rax
  81d172:	movdqu (%rax),%xmm0
  81d176:	movdqa %xmm0,0x20(%rsp)
  81d17c:	mov    %r12d,0x8(%rsp)
  81d181:	mov    %ebx,0xc(%rsp)
  81d185:	mov    %ebp,0x10(%rsp)
  81d189:	mov    %r15d,0x14(%rsp)
  81d18e:	lea    0x48(%rsp),%rdi
  81d193:	lea    0x20(%rsp),%rdx
  81d198:	lea    0x8(%rsp),%rcx
  81d19d:	mov    0x38(%rsp),%rsi
  81d1a2:	call   825e90 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d1a7:	mov    0x30(%rsp),%rdx
  81d1ac:	mov    $0x1,%eax
  81d1b1:	add    $0x68,%rsp
  81d1b5:	pop    %rbx
  81d1b6:	pop    %r12
  81d1b8:	pop    %r13
  81d1ba:	pop    %r14
  81d1bc:	pop    %r15
  81d1be:	pop    %rbp
  81d1bf:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d1c0 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d1c0:	push   %r15
  81d1c2:	push   %r14
  81d1c4:	push   %r12
  81d1c6:	push   %rbx
  81d1c7:	sub    $0x548,%rsp
  81d1ce:	mov    %rdx,%r14
  81d1d1:	mov    %rsi,%r12
  81d1d4:	mov    %rdi,%rbx
  81d1d7:	lea    0x612662(%rip),%rdx        # e2f840 <anon.93049d86f4da36fb5b5cebb14659314f.30.llvm.10732147056912049262>
  81d1de:	lea    0x30(%rsp),%r15
  81d1e3:	mov    %r15,%rdi
  81d1e6:	mov    %rbx,%rsi
  81d1e9:	call   *0x664061(%rip)        # e81250 <_DYNAMIC+0x638>
  81d1ef:	xorps  %xmm0,%xmm0
  81d1f2:	movups %xmm0,0x10(%rsp)
  81d1f7:	movups %xmm0,0x20(%rsp)
  81d1fc:	movl   $0x0,0x50(%rsp)
  81d204:	movb   $0x0,0x58(%rsp)
  81d209:	movups 0x9(%rsp),%xmm0
  81d20e:	movups %xmm0,0x59(%rsp)
  81d213:	movups 0x19(%rsp),%xmm0
  81d218:	movups %xmm0,0x69(%rsp)
  81d21d:	mov    0x28(%rsp),%rax
  81d222:	mov    %rax,0x78(%rsp)
  81d227:	movl   $0x0,0x80(%rsp)
  81d232:	mov    %r12,0x88(%rsp)
  81d23a:	movq   $0x0,0x90(%rsp)
  81d246:	lea    -0x748595(%rip),%rax        # d4cb8 <anon.93049d86f4da36fb5b5cebb14659314f.29.llvm.10732147056912049262>
  81d24d:	mov    %rax,0xe0(%rsp)
  81d255:	movq   $0xa,0xe8(%rsp)
  81d261:	lea    0x50(%rsp),%rax
  81d266:	mov    %rax,0xd0(%rsp)
  81d26e:	movq   $0x1,0xd8(%rsp)
  81d27a:	movl   $0xffffffff,0xb8(%rsp)
  81d285:	movl   $0x2,0x98(%rsp)
  81d290:	movq   $0x0,0xf0(%rsp)
  81d29c:	movl   $0x0,0xf8(%rsp)
  81d2a7:	lea    0x100(%rsp),%rdi
  81d2af:	lea    0x98(%rsp),%rdx
  81d2b7:	mov    %r15,%rsi
  81d2ba:	call   *0x663f98(%rip)        # e81258 <_DYNAMIC+0x640>
  81d2c0:	lea    0x10(%rbx),%rsi
  81d2c4:	lea    0x100(%rsp),%rdi
  81d2cc:	call   *0x663f8e(%rip)        # e81260 <_DYNAMIC+0x648>
  81d2d2:	lea    0x100(%rsp),%rdi
  81d2da:	mov    $0x4,%ecx
  81d2df:	xor    %esi,%esi
  81d2e1:	mov    %r14,%rdx
  81d2e4:	xor    %r8d,%r8d
  81d2e7:	call   *0x663f7b(%rip)        # e81268 <_DYNAMIC+0x650>
  81d2ed:	lea    0x100(%rsp),%rdi
  81d2f5:	xor    %esi,%esi
  81d2f7:	mov    $0x3,%edx
  81d2fc:	xor    %ecx,%ecx
  81d2fe:	mov    $0x1,%r8d
  81d304:	call   *0x663f66(%rip)        # e81270 <_DYNAMIC+0x658>
  81d30a:	lea    0x100(%rsp),%rdi
  81d312:	call   81c2d0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d317:	movups 0x30(%rsp),%xmm0
  81d31c:	movups 0x40(%rsp),%xmm1
  81d321:	movaps %xmm1,0x110(%rsp)
  81d329:	movaps %xmm0,0x100(%rsp)
  81d331:	lea    0x98(%rsp),%r14
  81d339:	lea    0x100(%rsp),%rsi
  81d341:	mov    %r14,%rdi
  81d344:	call   *0x663f2e(%rip)        # e81278 <_DYNAMIC+0x660>
  81d34a:	add    $0x8,%rbx
  81d34e:	mov    %rbx,%rdi
  81d351:	mov    %r14,%rsi
  81d354:	call   824d60 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d359:	add    $0x548,%rsp
  81d360:	pop    %rbx
  81d361:	pop    %r12
  81d363:	pop    %r14
  81d365:	pop    %r15
  81d367:	ret
  81d368:	mov    %rax,%rbx
  81d36b:	jmp    81d37d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d36d:	mov    %rax,%rbx
  81d370:	lea    0x100(%rsp),%rdi
  81d378:	call   81c2d0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d37d:	lea    0x30(%rsp),%rdi
  81d382:	call   81c440 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d387:	mov    %rbx,%rdi
  81d38a:	call   e2d970 <_Unwind_Resume@plt>
  81d38f:	call   *0x663ad3(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d3a0 <<gpui_gpu::renderer::RendererState>::correction>:
  81d3a0:	push   %r15
  81d3a2:	push   %r14
  81d3a4:	push   %r13
  81d3a6:	push   %r12
  81d3a8:	push   %rbx
  81d3a9:	sub    $0x90,%rsp
  81d3b0:	mov    %rdi,%rbx
  81d3b3:	movss  (%rdx),%xmm1
  81d3b7:	movss  0x8(%rdx),%xmm2
  81d3bc:	movaps %xmm1,%xmm0
  81d3bf:	addss  %xmm2,%xmm0
  81d3c3:	movd   %xmm0,%eax
  81d3c7:	and    $0x7fffffff,%eax
  81d3cc:	xorps  %xmm8,%xmm8
  81d3d0:	xorps  %xmm9,%xmm9
  81d3d4:	cmp    $0x7f7fffff,%eax
  81d3d9:	jg     81d3f8 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d3db:	cvtss2sd %xmm1,%xmm1
  81d3df:	cvtss2sd %xmm2,%xmm2
  81d3e3:	cvtss2sd %xmm0,%xmm0
  81d3e7:	addsd  %xmm1,%xmm2
  81d3eb:	subsd  %xmm0,%xmm2
  81d3ef:	xorps  %xmm9,%xmm9
  81d3f3:	cvtsd2ss %xmm2,%xmm9
  81d3f8:	movupd (%rsi),%xmm0
  81d3fc:	movupd 0x8(%rsi),%xmm1
  81d401:	movsd  0x10(%rsi),%xmm2
  81d406:	movsd  0x18(%rsi),%xmm3
  81d40b:	movupd 0x20(%rsi),%xmm4
  81d410:	movss  0x4(%rdx),%xmm6
  81d415:	movss  0xc(%rdx),%xmm7
  81d41a:	movaps %xmm6,%xmm5
  81d41d:	addss  %xmm7,%xmm5
  81d421:	movd   %xmm5,%eax
  81d425:	and    $0x7fffffff,%eax
  81d42a:	cmp    $0x7f7fffff,%eax
  81d42f:	jg     81d44e <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d431:	cvtss2sd %xmm6,%xmm6
  81d435:	cvtss2sd %xmm7,%xmm7
  81d439:	cvtss2sd %xmm5,%xmm5
  81d43d:	addsd  %xmm6,%xmm7
  81d441:	subsd  %xmm5,%xmm7
  81d445:	xorps  %xmm8,%xmm8
  81d449:	cvtsd2ss %xmm7,%xmm8
  81d44e:	cvtpd2ps %xmm4,%xmm5
  81d452:	cvtps2pd %xmm5,%xmm5
  81d455:	subpd  %xmm5,%xmm4
  81d459:	cvtpd2ps %xmm4,%xmm4
  81d45d:	unpcklpd %xmm3,%xmm1
  81d461:	cvtpd2ps %xmm1,%xmm3
  81d465:	unpcklpd %xmm2,%xmm0
  81d469:	cvtpd2ps %xmm0,%xmm2
  81d46d:	cvtps2pd %xmm3,%xmm3
  81d470:	subpd  %xmm3,%xmm1
  81d474:	cvtpd2ps %xmm1,%xmm5
  81d478:	cvtps2pd %xmm2,%xmm1
  81d47b:	subpd  %xmm1,%xmm0
  81d47f:	cvtpd2ps %xmm0,%xmm6
  81d483:	movapd %xmm6,%xmm0
  81d487:	unpcklps %xmm5,%xmm0
  81d48a:	movaps %xmm8,%xmm1
  81d48e:	movlhps %xmm9,%xmm1
  81d492:	movapd %xmm4,%xmm2
  81d496:	shufps $0x24,%xmm1,%xmm2
  81d49a:	xorps  %xmm1,%xmm1
  81d49d:	movapd %xmm0,%xmm3
  81d4a1:	cmpneqps %xmm1,%xmm3
  81d4a5:	cmpneqps %xmm1,%xmm2
  81d4a9:	packssdw %xmm2,%xmm3
  81d4ad:	pmovmskb %xmm3,%eax
  81d4b1:	test   %eax,%eax
  81d4b3:	je     81d5d7 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d4b9:	movapd %xmm6,0x60(%rsp)
  81d4bf:	movapd %xmm5,0x70(%rsp)
  81d4c5:	lea    0x8(%rsp),%r12
  81d4ca:	movapd %xmm0,(%rsp)
  81d4cf:	movapd %xmm4,0x80(%rsp)
  81d4d8:	movlpd %xmm4,0x10(%rsp)
  81d4de:	movss  %xmm9,0x18(%rsp)
  81d4e5:	movss  %xmm8,0x1c(%rsp)
  81d4ec:	lea    0x318(%rbx),%r14
  81d4f3:	mov    %rsp,%rsi
  81d4f6:	mov    %r14,%rdi
  81d4f9:	movaps %xmm8,0x30(%rsp)
  81d4ff:	movaps %xmm9,0x20(%rsp)
  81d505:	call   824700 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d50a:	movapd 0x20(%rsp),%xmm6
  81d510:	movapd 0x30(%rsp),%xmm5
  81d516:	mov    %rax,%r15
  81d519:	shr    $0x39,%r15
  81d51d:	mov    0x2f8(%rbx),%rcx
  81d524:	mov    0x300(%rbx),%rdx
  81d52b:	movd   %r15d,%xmm0
  81d530:	punpcklbw %xmm0,%xmm0
  81d534:	pshuflw $0x0,%xmm0,%xmm0
  81d539:	pshufd $0x44,%xmm0,%xmm0
  81d53e:	xor    %esi,%esi
  81d540:	pcmpeqd %xmm1,%xmm1
  81d544:	mov    %rax,%rdi
  81d547:	and    %rdx,%rdi
  81d54a:	movdqu (%rcx,%rdi,1),%xmm2
  81d54f:	movdqa %xmm2,%xmm3
  81d553:	pcmpeqb %xmm0,%xmm3
  81d557:	pmovmskb %xmm3,%r8d
  81d55c:	test   %r8d,%r8d
  81d55f:	je     81d5b0 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d561:	tzcnt  %r8d,%r9d
  81d566:	add    %rdi,%r9
  81d569:	and    %rdx,%r9
  81d56c:	neg    %r9
  81d56f:	lea    (%r9,%r9,8),%r9
  81d573:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d57a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d581:	pcmpeqb 0x10(%rsp),%xmm4
  81d587:	pcmpeqb (%rsp),%xmm3
  81d58c:	pand   %xmm4,%xmm3
  81d590:	pmovmskb %xmm3,%r10d
  81d595:	cmp    $0xffff,%r10d
  81d59c:	je     81d5ce <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d59e:	lea    -0x1(%r8),%r9d
  81d5a2:	and    %r8w,%r9w
  81d5a6:	mov    %r9d,%r8d
  81d5a9:	jne    81d561 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d5ab:	nopl   0x0(%rax,%rax,1)
  81d5b0:	pcmpeqb %xmm1,%xmm2
  81d5b4:	pmovmskb %xmm2,%r8d
  81d5b9:	test   %r8d,%r8d
  81d5bc:	jne    81d5de <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d5be:	add    %rsi,%rdi
  81d5c1:	add    $0x10,%rdi
  81d5c5:	add    $0x10,%rsi
  81d5c9:	jmp    81d547 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d5ce:	lea    (%rcx,%r9,4),%rdx
  81d5d2:	jmp    81d6f9 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d5d7:	xor    %eax,%eax
  81d5d9:	jmp    81d6fc <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d5de:	cmpq   $0x0,0x308(%rbx)
  81d5e6:	je     81d72f <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d5ec:	mov    (%rsp),%r14
  81d5f0:	mov    0x10(%r12),%rcx
  81d5f5:	mov    %rcx,0x50(%rsp)
  81d5fa:	movups (%r12),%xmm0
  81d5ff:	movaps %xmm0,0x40(%rsp)
  81d604:	mov    0x70(%rbx),%r12
  81d608:	cmp    0x60(%rbx),%r12
  81d60c:	jne    81d62a <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d60e:	lea    0x60(%rbx),%rdi
  81d612:	mov    %rax,%r13
  81d615:	call   *0x663bad(%rip)        # e811c8 <_DYNAMIC+0x5b0>
  81d61b:	movapd 0x20(%rsp),%xmm6
  81d621:	movapd 0x30(%rsp),%xmm5
  81d627:	mov    %r13,%rax
  81d62a:	mov    0x68(%rbx),%rcx
  81d62e:	mov    %r12,%rdx
  81d631:	shl    $0x5,%rdx
  81d635:	movaps 0x60(%rsp),%xmm0
  81d63a:	movlps %xmm0,(%rcx,%rdx,1)
  81d63e:	movaps 0x80(%rsp),%xmm0
  81d646:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d64c:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d652:	movdqa 0x70(%rsp),%xmm1
  81d658:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d65e:	shufps $0x55,%xmm0,%xmm0
  81d662:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d668:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d66e:	lea    0x1(%r12),%rcx
  81d673:	mov    %rcx,0x70(%rbx)
  81d677:	mov    0x2f8(%rbx),%rcx
  81d67e:	mov    0x300(%rbx),%rdx
  81d685:	and    %rdx,%rax
  81d688:	movdqu (%rcx,%rax,1),%xmm0
  81d68d:	pmovmskb %xmm0,%esi
  81d691:	test   %esi,%esi
  81d693:	je     81d70d <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d695:	tzcnt  %esi,%esi
  81d699:	add    %rax,%rsi
  81d69c:	and    %rdx,%rsi
  81d69f:	movzbl (%rcx,%rsi,1),%eax
  81d6a3:	test   %al,%al
  81d6a5:	jns    81d760 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d6ab:	lea    -0x10(%rsi),%rdi
  81d6af:	and    %rdx,%rdi
  81d6b2:	mov    %r15b,(%rcx,%rsi,1)
  81d6b6:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d6bb:	neg    %rsi
  81d6be:	lea    (%rsi,%rsi,8),%rsi
  81d6c2:	lea    (%rcx,%rsi,4),%rdx
  81d6c6:	and    $0x1,%al
  81d6c8:	movzbl %al,%eax
  81d6cb:	sub    %rax,0x308(%rbx)
  81d6d2:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d6d7:	movdqa 0x40(%rsp),%xmm0
  81d6dd:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d6e3:	mov    0x50(%rsp),%rax
  81d6e8:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d6ed:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d6f2:	incq   0x310(%rbx)
  81d6f9:	mov    -0x4(%rdx),%eax
  81d6fc:	add    $0x90,%rsp
  81d703:	pop    %rbx
  81d704:	pop    %r12
  81d706:	pop    %r13
  81d708:	pop    %r14
  81d70a:	pop    %r15
  81d70c:	ret
  81d70d:	mov    $0x10,%edi
  81d712:	add    %rdi,%rax
  81d715:	and    %rdx,%rax
  81d718:	movdqu (%rcx,%rax,1),%xmm0
  81d71d:	pmovmskb %xmm0,%esi
  81d721:	add    $0x10,%rdi
  81d725:	test   %esi,%esi
  81d727:	jne    81d695 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d72d:	jmp    81d712 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d72f:	lea    0x2f8(%rbx),%rdi
  81d736:	mov    $0x1,%esi
  81d73b:	mov    %r14,%rdx
  81d73e:	mov    $0x1,%ecx
  81d743:	mov    %rax,%r14
  81d746:	call   *0x663b34(%rip)        # e81280 <_DYNAMIC+0x668>
  81d74c:	movapd 0x20(%rsp),%xmm6
  81d752:	movapd 0x30(%rsp),%xmm5
  81d758:	mov    %r14,%rax
  81d75b:	jmp    81d5ec <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d760:	movdqa (%rcx),%xmm0
  81d764:	pmovmskb %xmm0,%eax
  81d768:	tzcnt  %eax,%esi
  81d76c:	movzbl (%rcx,%rsi,1),%eax
  81d770:	jmp    81d6ab <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d780 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d780:	push   %rbp
  81d781:	push   %r15
  81d783:	push   %r14
  81d785:	push   %r13
  81d787:	push   %r12
  81d789:	push   %rbx
  81d78a:	sub    $0x228,%rsp
  81d791:	mov    %rsi,%r14
  81d794:	test   %r8d,%r8d
  81d797:	je     81d82b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d79d:	mov    %rdi,0x10(%rsp)
  81d7a2:	mov    0x110(%rcx),%rbp
  81d7a9:	test   %rbp,%rbp
  81d7ac:	je     81d88f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d7b2:	mov    0x108(%rcx),%r13
  81d7b9:	shl    $0x3,%rbp
  81d7bd:	mov    %r14,0x8(%rsp)
  81d7c2:	lea    0x78(%r14),%rdi
  81d7c6:	mov    %rdx,0x18(%rsp)
  81d7cb:	lea    0x8(%rdx),%rax
  81d7cf:	mov    %rax,0x20(%rsp)
  81d7d4:	xor    %ebx,%ebx
  81d7d6:	lea    0x28(%rsp),%r15
  81d7db:	xor    %r12d,%r12d
  81d7de:	xchg   %ax,%ax
  81d7e0:	mov    0x0(%r13,%r12,1),%rax
  81d7e5:	movups 0x28(%rax),%xmm0
  81d7e9:	lea    0x38(%rsp),%rcx
  81d7ee:	movups %xmm0,(%rcx)
  81d7f1:	movups 0x18(%rax),%xmm0
  81d7f5:	movups %xmm0,0x28(%rsp)
  81d7fa:	movups 0x38(%rax),%xmm0
  81d7fe:	movups %xmm0,0x48(%rsp)
  81d803:	mov    %rdi,%r14
  81d806:	mov    0x20(%rsp),%rsi
  81d80b:	mov    %r15,%rdx
  81d80e:	call   81cf60 <<gpui_gpu::renderer::Atlas>::insert>
  81d813:	test   $0x1,%al
  81d815:	je     81d896 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d817:	add    %rdx,%rbx
  81d81a:	add    $0x8,%r12
  81d81e:	cmp    %r12,%rbp
  81d821:	mov    %r14,%rdi
  81d824:	jne    81d7e0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d826:	jmp    81d99e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d82b:	cmpl   $0x1,0x150(%r14)
  81d833:	jne    81d845 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d835:	mov    0x138(%r14),%rax
  81d83c:	add    0x130(%r14),%rax
  81d843:	je     81d87c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d845:	mov    %rdi,%rbx
  81d848:	add    $0x78,%r14
  81d84c:	lea    0x58(%rsp),%rdi
  81d851:	mov    %rdx,%rsi
  81d854:	mov    $0x1,%edx
  81d859:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81d85e:	mov    %r14,%rdi
  81d861:	call   81ba80 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d866:	lea    0x58(%rsp),%rsi
  81d86b:	mov    $0xe8,%edx
  81d870:	mov    %r14,%rdi
  81d873:	call   *0x66363f(%rip)        # e80eb8 <memcpy@GLIBC_2.14>
  81d879:	mov    %rbx,%rdi
  81d87c:	movq   $0x0,0x8(%rdi)
  81d884:	movl   $0xffffffff,(%rdi)
  81d88a:	jmp    81d9ad <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d88f:	xor    %ebx,%ebx
  81d891:	jmp    81d99e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d896:	mov    0x8(%rsp),%rax
  81d89b:	mov    0x150(%rax),%eax
  81d8a1:	cmp    $0x81,%eax
  81d8a6:	mov    $0x80,%edx
  81d8ab:	cmovae %eax,%edx
  81d8ae:	add    %edx,%edx
  81d8b0:	cmp    $0x800,%edx
  81d8b6:	mov    $0x800,%eax
  81d8bb:	cmovae %eax,%edx
  81d8be:	lea    0x140(%rsp),%r12
  81d8c6:	mov    %r12,%rdi
  81d8c9:	mov    0x18(%rsp),%rsi
  81d8ce:	mov    %edx,0x8(%rsp)
  81d8d2:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81d8d7:	xor    %r15d,%r15d
  81d8da:	nopw   0x0(%rax,%rax,1)
  81d8e0:	mov    0x0(%r13,%r15,1),%rax
  81d8e5:	movups 0x28(%rax),%xmm0
  81d8e9:	lea    0x68(%rsp),%rcx
  81d8ee:	movups %xmm0,(%rcx)
  81d8f1:	movups 0x18(%rax),%xmm0
  81d8f5:	movups %xmm0,0x58(%rsp)
  81d8fa:	movups 0x38(%rax),%xmm0
  81d8fe:	movups %xmm0,0x78(%rsp)
  81d903:	mov    %r12,%rdi
  81d906:	mov    0x20(%rsp),%rsi
  81d90b:	lea    0x58(%rsp),%rdx
  81d910:	call   81cf60 <<gpui_gpu::renderer::Atlas>::insert>
  81d915:	cmp    $0x1,%rax
  81d919:	jne    81d929 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d91b:	add    %rdx,%rbx
  81d91e:	add    $0x8,%r15
  81d922:	cmp    %r15,%rbp
  81d925:	jne    81d8e0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d927:	jmp    81d96b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d929:	mov    0x8(%rsp),%r15d
  81d92e:	cmp    $0x800,%r15d
  81d935:	je     81d9bf <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d93b:	mov    %r12,%rdi
  81d93e:	call   81ba80 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d943:	add    %r15d,%r15d
  81d946:	cmp    $0x800,%r15d
  81d94d:	mov    $0x800,%eax
  81d952:	cmovae %eax,%r15d
  81d956:	mov    %r12,%rdi
  81d959:	mov    0x18(%rsp),%rsi
  81d95e:	mov    %r15d,0x8(%rsp)
  81d963:	mov    %r15d,%edx
  81d966:	jmp    81d8d2 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81d96b:	lea    0x58(%rsp),%rdi
  81d970:	lea    0x140(%rsp),%rsi
  81d978:	mov    $0xe8,%edx
  81d97d:	call   *0x663535(%rip)        # e80eb8 <memcpy@GLIBC_2.14>
  81d983:	mov    %r14,%rdi
  81d986:	call   81ba80 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d98b:	lea    0x58(%rsp),%rsi
  81d990:	mov    $0xe8,%edx
  81d995:	mov    %r14,%rdi
  81d998:	call   *0x66351a(%rip)        # e80eb8 <memcpy@GLIBC_2.14>
  81d99e:	mov    0x10(%rsp),%rax
  81d9a3:	mov    %rbx,0x8(%rax)
  81d9a7:	movl   $0xffffffff,(%rax)
  81d9ad:	add    $0x228,%rsp
  81d9b4:	pop    %rbx
  81d9b5:	pop    %r12
  81d9b7:	pop    %r13
  81d9b9:	pop    %r14
  81d9bb:	pop    %r15
  81d9bd:	pop    %rbp
  81d9be:	ret
  81d9bf:	mov    0x10(%rsp),%rax
  81d9c4:	movl   $0x7,(%rax)
  81d9ca:	lea    0x140(%rsp),%rdi
  81d9d2:	call   81ba80 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9d7:	jmp    81d9ad <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d9d9:	jmp    81d9db <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81d9db:	mov    %rax,%rbx
  81d9de:	lea    0x58(%rsp),%rsi
  81d9e3:	mov    $0xe8,%edx
  81d9e8:	mov    %r14,%rdi
  81d9eb:	call   *0x6634c7(%rip)        # e80eb8 <memcpy@GLIBC_2.14>
  81d9f1:	mov    %rbx,%rdi
  81d9f4:	call   e2d970 <_Unwind_Resume@plt>
  81d9f9:	mov    %rax,%rbx
  81d9fc:	lea    0x140(%rsp),%rdi
  81da04:	call   81ba80 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da09:	mov    %rbx,%rdi
  81da0c:	call   e2d970 <_Unwind_Resume@plt>
  81da11:	call   *0x663451(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1527 frame=952

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081da20 <<gpui_gpu::renderer::RendererState>::new>:
  81da20:	push   %r15
  81da22:	push   %r14
  81da24:	push   %r13
  81da26:	push   %r12
  81da28:	push   %rbx
  81da29:	sub    $0x390,%rsp
  81da30:	mov    %rsi,%r14
  81da33:	mov    %rdi,%rbx
  81da36:	lea    -0x748d7b(%rip),%rax        # d4cc2 <anon.93049d86f4da36fb5b5cebb14659314f.29.llvm.10732147056912049262+0xa>
  81da3d:	mov    %rax,0xd8(%rsp)
  81da45:	movq   $0x7,0xe0(%rsp)
  81da51:	movq   $0x30,0xe8(%rsp)
  81da5d:	movl   $0x48,0xf0(%rsp)
  81da68:	movb   $0x0,0xf4(%rsp)
  81da70:	mov    0x6637c1(%rip),%r15        # e81238 <_DYNAMIC+0x620>
  81da77:	lea    0x10(%rsp),%rdi
  81da7c:	lea    0xd8(%rsp),%rdx
  81da84:	call   *%r15
  81da87:	movq   $0x30,0x30(%rsp)
  81da90:	lea    -0x748dce(%rip),%rax        # d4cc9 <anon.93049d86f4da36fb5b5cebb14659314f.29.llvm.10732147056912049262+0x11>
  81da97:	mov    %rax,0xd8(%rsp)
  81da9f:	movq   $0x5,0xe0(%rsp)
  81daab:	movq   $0x10,0xe8(%rsp)
  81dab7:	movl   $0x88,0xf0(%rsp)
  81dac2:	movb   $0x0,0xf4(%rsp)
  81daca:	lea    0x38(%rsp),%rdi
  81dacf:	lea    0xd8(%rsp),%rdx
  81dad7:	mov    %r14,%rsi
  81dada:	call   *%r15
  81dadd:	movq   $0x10,0x58(%rsp)
  81dae6:	lea    -0x748e1f(%rip),%rax        # d4cce <anon.93049d86f4da36fb5b5cebb14659314f.29.llvm.10732147056912049262+0x16>
  81daed:	mov    %rax,0xd8(%rsp)
  81daf5:	movq   $0x5,0xe0(%rsp)
  81db01:	movq   $0x8,0xe8(%rsp)
  81db0d:	movl   $0x88,0xf0(%rsp)
  81db18:	movb   $0x0,0xf4(%rsp)
  81db20:	lea    0x60(%rsp),%rdi
  81db25:	lea    0xd8(%rsp),%rdx
  81db2d:	mov    %r14,%rsi
  81db30:	call   *0x663702(%rip)        # e81238 <_DYNAMIC+0x620>
  81db36:	movq   $0x8,0x80(%rsp)
  81db42:	lea    -0x748e76(%rip),%rax        # d4cd3 <anon.93049d86f4da36fb5b5cebb14659314f.29.llvm.10732147056912049262+0x1b>
  81db49:	mov    %rax,0xd8(%rsp)
  81db51:	movq   $0x7,0xe0(%rsp)
  81db5d:	movq   $0x4,0xe8(%rsp)
  81db69:	movl   $0x88,0xf0(%rsp)
  81db74:	movb   $0x0,0xf4(%rsp)
  81db7c:	lea    0x88(%rsp),%rdi
  81db84:	lea    0xd8(%rsp),%rdx
  81db8c:	mov    %r14,%rsi
  81db8f:	call   *0x6636a3(%rip)        # e81238 <_DYNAMIC+0x620>
  81db95:	movq   $0x4,0xa8(%rsp)
  81dba1:	lea    -0x748ece(%rip),%rax        # d4cda <anon.93049d86f4da36fb5b5cebb14659314f.29.llvm.10732147056912049262+0x22>
  81dba8:	mov    %rax,0xd8(%rsp)
  81dbb0:	movq   $0x11,0xe0(%rsp)
  81dbbc:	movq   $0x20,0xe8(%rsp)
  81dbc8:	movl   $0x88,0xf0(%rsp)
  81dbd3:	movb   $0x0,0xf4(%rsp)
  81dbdb:	lea    0xb0(%rsp),%rdi
  81dbe3:	lea    0xd8(%rsp),%rdx
  81dbeb:	mov    %r14,%rsi
  81dbee:	call   *0x663644(%rip)        # e81238 <_DYNAMIC+0x620>
  81dbf4:	movq   $0x20,0xd0(%rsp)
  81dc00:	lea    0x2a8(%rsp),%rdi
  81dc08:	mov    %r14,%rsi
  81dc0b:	mov    $0x1,%edx
  81dc10:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81dc15:	mov    0x18(%r14),%r13
  81dc19:	lock incq 0x0(%r13)
  81dc1e:	jle    81df53 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81dc24:	mov    %r13,0x8(%rsp)
  81dc29:	mov    0x30(%rsp),%rax
  81dc2e:	mov    %rax,0x1e0(%rsp)
  81dc36:	movups 0x10(%rsp),%xmm0
  81dc3b:	movups 0x20(%rsp),%xmm1
  81dc40:	movaps %xmm1,0x1d0(%rsp)
  81dc48:	movaps %xmm0,0x1c0(%rsp)
  81dc50:	mov    0x58(%rsp),%rax
  81dc55:	mov    %rax,0x210(%rsp)
  81dc5d:	movups 0x38(%rsp),%xmm0
  81dc62:	movups 0x48(%rsp),%xmm1
  81dc67:	movaps %xmm1,0x200(%rsp)
  81dc6f:	movaps %xmm0,0x1f0(%rsp)
  81dc77:	mov    0x80(%rsp),%rax
  81dc7f:	mov    %rax,0x240(%rsp)
  81dc87:	movups 0x60(%rsp),%xmm0
  81dc8c:	movups 0x70(%rsp),%xmm1
  81dc91:	movaps %xmm1,0x230(%rsp)
  81dc99:	movaps %xmm0,0x220(%rsp)
  81dca1:	mov    0xa8(%rsp),%rax
  81dca9:	mov    %rax,0x270(%rsp)
  81dcb1:	movups 0x88(%rsp),%xmm0
  81dcb9:	movups 0x98(%rsp),%xmm1
  81dcc1:	movaps %xmm1,0x260(%rsp)
  81dcc9:	movaps %xmm0,0x250(%rsp)
  81dcd1:	mov    0xd0(%rsp),%rax
  81dcd9:	mov    %rax,0x2a0(%rsp)
  81dce1:	movups 0xb0(%rsp),%xmm0
  81dce9:	movups 0xc0(%rsp),%xmm1
  81dcf1:	movaps %xmm1,0x290(%rsp)
  81dcf9:	movaps %xmm0,0x280(%rsp)
  81dd01:	lea    0xd8(%rsp),%rdi
  81dd09:	lea    0x2a8(%rsp),%rsi
  81dd11:	mov    $0xe8,%edx
  81dd16:	call   *0x66319c(%rip)        # e80eb8 <memcpy@GLIBC_2.14>
  81dd1c:	mov    %fs:0x0,%rax
  81dd25:	lea    -0x28(%rax),%rax
  81dd2c:	mov    %rax,%r12
  81dd2f:	cmpb   $0x1,0x10(%rax)
  81dd33:	jne    81df33 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81dd39:	mov    (%r12),%r14
  81dd3d:	mov    0x8(%r12),%r15
  81dd42:	lea    0x1(%r14),%rax
  81dd46:	mov    %rax,(%r12)
  81dd4a:	mov    %r13,0x228(%rbx)
  81dd51:	mov    0x30(%rsp),%rax
  81dd56:	mov    %rax,0x250(%rbx)
  81dd5d:	movups 0x10(%rsp),%xmm0
  81dd62:	movups 0x20(%rsp),%xmm1
  81dd67:	movups %xmm1,0x240(%rbx)
  81dd6e:	movups %xmm0,0x230(%rbx)
  81dd75:	mov    0x58(%rsp),%rax
  81dd7a:	mov    %rax,0x278(%rbx)
  81dd81:	movups 0x38(%rsp),%xmm0
  81dd86:	movups 0x48(%rsp),%xmm1
  81dd8b:	movups %xmm1,0x268(%rbx)
  81dd92:	movups %xmm0,0x258(%rbx)
  81dd99:	mov    0x80(%rsp),%rax
  81dda1:	mov    %rax,0x2a0(%rbx)
  81dda8:	movups 0x60(%rsp),%xmm0
  81ddad:	movups 0x70(%rsp),%xmm1
  81ddb2:	movups %xmm1,0x290(%rbx)
  81ddb9:	movups %xmm0,0x280(%rbx)
  81ddc0:	movups 0x88(%rsp),%xmm0
  81ddc8:	movups 0x98(%rsp),%xmm1
  81ddd0:	movups %xmm0,0x2a8(%rbx)
  81ddd7:	movups %xmm1,0x2b8(%rbx)
  81ddde:	mov    0xa8(%rsp),%rax
  81dde6:	mov    %rax,0x2c8(%rbx)
  81dded:	movups 0xb0(%rsp),%xmm0
  81ddf5:	movups 0xc0(%rsp),%xmm1
  81ddfd:	movups %xmm0,0x2d0(%rbx)
  81de04:	movups %xmm1,0x2e0(%rbx)
  81de0b:	mov    0xd0(%rsp),%rax
  81de13:	mov    %rax,0x2f0(%rbx)
  81de1a:	lea    0x78(%rbx),%rdi
  81de1e:	lea    0x2a8(%rsp),%rsi
  81de26:	mov    $0xe8,%edx
  81de2b:	call   *0x663087(%rip)        # e80eb8 <memcpy@GLIBC_2.14>
  81de31:	movq   $0x0,0x328(%rbx)
  81de3c:	movq   $0x0,(%rbx)
  81de43:	movq   $0x4,0x8(%rbx)
  81de4b:	xorps  %xmm0,%xmm0
  81de4e:	movups %xmm0,0x10(%rbx)
  81de52:	movq   $0x4,0x20(%rbx)
  81de5a:	movups %xmm0,0x28(%rbx)
  81de5e:	movq   $0x4,0x38(%rbx)
  81de66:	movups %xmm0,0x40(%rbx)
  81de6a:	movq   $0x4,0x50(%rbx)
  81de72:	movups %xmm0,0x58(%rbx)
  81de76:	movq   $0x4,0x68(%rbx)
  81de7e:	movq   $0x0,0x70(%rbx)
  81de86:	movups 0x611903(%rip),%xmm1        # e2f790 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x128>
  81de8d:	movups %xmm1,0x2f8(%rbx)
  81de94:	movups 0x611905(%rip),%xmm1        # e2f7a0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x138>
  81de9b:	movups %xmm1,0x308(%rbx)
  81dea2:	mov    %r14,0x318(%rbx)
  81dea9:	mov    %r15,0x320(%rbx)
  81deb0:	movw   $0x101,0x340(%rbx)
  81deb9:	movq   $0x0,0x330(%rbx)
  81dec4:	movups %xmm0,0x210(%rbx)
  81decb:	movups %xmm0,0x200(%rbx)
  81ded2:	movups %xmm0,0x1f0(%rbx)
  81ded9:	movups %xmm0,0x1e0(%rbx)
  81dee0:	movups %xmm0,0x1d0(%rbx)
  81dee7:	movups %xmm0,0x1c0(%rbx)
  81deee:	movups %xmm0,0x1b0(%rbx)
  81def5:	movups %xmm0,0x1a0(%rbx)
  81defc:	movups %xmm0,0x190(%rbx)
  81df03:	movups %xmm0,0x180(%rbx)
  81df0a:	movups %xmm0,0x170(%rbx)
  81df11:	movups %xmm0,0x160(%rbx)
  81df18:	movb   $0x0,0x220(%rbx)
  81df1f:	mov    %rbx,%rax
  81df22:	add    $0x390,%rsp
  81df29:	pop    %rbx
  81df2a:	pop    %r12
  81df2c:	pop    %r13
  81df2e:	pop    %r14
  81df30:	pop    %r15
  81df32:	ret
  81df33:	call   *0x663307(%rip)        # e81240 <_DYNAMIC+0x628>
  81df39:	mov    %rax,%r14
  81df3c:	mov    %rdx,%r15
  81df3f:	mov    %rax,(%r12)
  81df43:	mov    %rdx,0x8(%r12)
  81df48:	movb   $0x1,0x10(%r12)
  81df4e:	jmp    81dd42 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81df53:	ud2
  81df55:	mov    %rax,%rbx
  81df58:	lea    0xd8(%rsp),%rdi
  81df60:	call   81ba80 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81df65:	lea    0x280(%rsp),%rdi
  81df6d:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df72:	lea    0x250(%rsp),%rdi
  81df7a:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df7f:	lea    0x220(%rsp),%rdi
  81df87:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df8c:	lea    0x1f0(%rsp),%rdi
  81df94:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df99:	lea    0x1c0(%rsp),%rdi
  81dfa1:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfa6:	lock decq 0x0(%r13)
  81dfab:	jne    81e009 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81dfad:	lea    0x8(%rsp),%rdi
  81dfb2:	call   *0x6630c8(%rip)        # e81080 <_DYNAMIC+0x468>
  81dfb8:	jmp    81e009 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81dfba:	mov    %rax,%rbx
  81dfbd:	lea    0xb0(%rsp),%rdi
  81dfc5:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfca:	jmp    81dfcf <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81dfcc:	mov    %rax,%rbx
  81dfcf:	lea    0x88(%rsp),%rdi
  81dfd7:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfdc:	jmp    81dfe1 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81dfde:	mov    %rax,%rbx
  81dfe1:	lea    0x60(%rsp),%rdi
  81dfe6:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfeb:	jmp    81dff0 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81dfed:	mov    %rax,%rbx
  81dff0:	lea    0x38(%rsp),%rdi
  81dff5:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dffa:	jmp    81dfff <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81dffc:	mov    %rax,%rbx
  81dfff:	lea    0x10(%rsp),%rdi
  81e004:	call   81bb60 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e009:	mov    %rbx,%rdi
  81e00c:	call   e2d970 <_Unwind_Resume@plt>
  81e011:	call   *0x662e51(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9520 frame=1448

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e020 <<gpui_gpu::renderer::RendererState>::render>:
  81e020:	push   %rbp
  81e021:	push   %r15
  81e023:	push   %r14
  81e025:	push   %r13
  81e027:	push   %r12
  81e029:	push   %rbx
  81e02a:	sub    $0x578,%rsp
  81e031:	mov    0x228(%rsi),%rax
  81e038:	mov    0x18(%rdx),%r9
  81e03c:	cmp    %r9,%rax
  81e03f:	je     81e05d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e041:	mov    0x10(%rax),%r10
  81e045:	cmp    0x10(%r9),%r10
  81e049:	jne    81e12b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e04f:	mov    0x18(%rax),%rax
  81e053:	cmp    0x18(%r9),%rax
  81e057:	jne    81e12b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e05d:	lea    0x330(%rsi),%rbx
  81e064:	mov    0x330(%rsi),%rax
  81e06b:	test   %rax,%rax
  81e06e:	je     81e09d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e070:	lock decq (%rax)
  81e074:	jne    81e09d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e076:	mov    %rdi,%r14
  81e079:	mov    %rbx,%rdi
  81e07c:	mov    %rsi,%r12
  81e07f:	mov    %r8,%r13
  81e082:	mov    %rdx,%r15
  81e085:	mov    %rcx,%rbp
  81e088:	call   *0x6630a2(%rip)        # e81130 <_DYNAMIC+0x518>
  81e08e:	mov    %rbp,%rcx
  81e091:	mov    %r15,%rdx
  81e094:	mov    %r13,%r8
  81e097:	mov    %r12,%rsi
  81e09a:	mov    %r14,%rdi
  81e09d:	movq   $0x0,0x330(%rsi)
  81e0a8:	mov    (%rcx),%r13d
  81e0ab:	mov    0x8(%rcx),%r9d
  81e0af:	movzbl 0xd(%rcx),%eax
  81e0b3:	test   %r9d,%r9d
  81e0b6:	sets   %r10b
  81e0ba:	and    $0x7fffffff,%r9d
  81e0c1:	lea    -0x800000(%r9),%r11d
  81e0c8:	cmp    $0x7f000000,%r11d
  81e0cf:	setb   %r11b
  81e0d3:	and    %r10b,%r11b
  81e0d6:	lea    -0x1(%r9),%ebp
  81e0da:	cmp    $0x7fffff,%ebp
  81e0e0:	setb   %bpl
  81e0e4:	and    %r10b,%bpl
  81e0e7:	test   %r9d,%r9d
  81e0ea:	sete   %r10b
  81e0ee:	cmp    $0x7f800000,%r9d
  81e0f5:	sete   %r14b
  81e0f9:	or     %r10b,%r14b
  81e0fc:	cmp    $0x7f800001,%r9d
  81e103:	setge  %r9b
  81e107:	or     %r14b,%r9b
  81e10a:	or     %bpl,%r9b
  81e10d:	test   %r13d,%r13d
  81e110:	setne  %r10b
  81e114:	and    %al,%r10b
  81e117:	or     %r11b,%r10b
  81e11a:	or     %r9b,%r10b
  81e11d:	test   $0x1,%r10b
  81e121:	je     81e146 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e123:	movl   $0x3,(%rdi)
  81e129:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e12b:	movl   $0x4,(%rdi)
  81e131:	mov    %rdi,%rax
  81e134:	add    $0x578,%rsp
  81e13b:	pop    %rbx
  81e13c:	pop    %r12
  81e13e:	pop    %r13
  81e140:	pop    %r14
  81e142:	pop    %r15
  81e144:	pop    %rbp
  81e145:	ret
  81e146:	movd   0x4(%rcx),%xmm2
  81e14b:	movzbl 0xc(%rcx),%ebp
  81e14f:	test   $0x1,%r13b
  81e153:	je     81e1cb <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e155:	movd   %xmm2,%r9d
  81e15a:	test   %r9d,%r9d
  81e15d:	sets   %r10b
  81e161:	and    $0x7fffffff,%r9d
  81e168:	lea    -0x800000(%r9),%r11d
  81e16f:	cmp    $0x7f000000,%r11d
  81e176:	setb   %r11b
  81e17a:	and    %r10b,%r11b
  81e17d:	lea    -0x1(%r9),%r14d
  81e181:	cmp    $0x7fffff,%r14d
  81e188:	setb   %r14b
  81e18c:	and    %r10b,%r14b
  81e18f:	test   %r9d,%r9d
  81e192:	sete   %r10b
  81e196:	cmp    $0x7f800000,%r9d
  81e19d:	sete   %r15b
  81e1a1:	or     %r10b,%r15b
  81e1a4:	cmp    $0x7f800001,%r9d
  81e1ab:	setge  %r9b
  81e1af:	or     %r15b,%r9b
  81e1b2:	or     %r14b,%r9b
  81e1b5:	or     %r11b,%r9b
  81e1b8:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1be:	ucomiss -0x76f2b9(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e1c5:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1cb:	mov    0x28(%rcx),%r14d
  81e1cf:	cmp    %r14d,0x20(%r8)
  81e1d3:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1d9:	mov    0x2c(%rcx),%r15d
  81e1dd:	cmp    %r15d,0x24(%r8)
  81e1e1:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1e7:	mov    0x38(%r8),%r12d
  81e1eb:	cmp    0x20(%rdx),%r12d
  81e1ef:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1f5:	cmp    $0x4c,%r12d
  81e1f9:	jne    81e21e <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e1fb:	movq   0x3c(%r8),%xmm0
  81e201:	movq   0x24(%rdx),%xmm1
  81e206:	pcmpeqd %xmm0,%xmm1
  81e20a:	pshufd $0x50,%xmm1,%xmm0
  81e20f:	movmskpd %xmm0,%r9d
  81e214:	cmp    $0x3,%r9d
  81e218:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e21e:	cmp    $0x4000,%r15d
  81e225:	ja     81e25b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e227:	cmp    $0x4000,%r14d
  81e22e:	ja     81e25b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e230:	mov    %r15,%r9
  81e233:	imul   %r14,%r9
  81e237:	add    $0xfffffffffeffffff,%r9
  81e23e:	cmp    $0xffffffffff000000,%r9
  81e245:	jb     81e25b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e247:	mov    0x10(%rcx),%r11
  81e24b:	mov    0x80(%r11),%r10
  81e252:	cmp    $0x10000,%r10
  81e259:	jbe    81e266 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e25b:	movl   $0x6,(%rdi)
  81e261:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e266:	movd   0x18(%rcx),%xmm0
  81e26b:	movd   %xmm0,%r9d
  81e270:	and    $0x7fffffff,%r9d
  81e277:	cmp    $0x7f7fffff,%r9d
  81e27e:	jg     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e284:	pand   -0x770a9c(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e28c:	ucomiss -0x76f12f(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e293:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e299:	movd   0x1c(%rcx),%xmm0
  81e29e:	movd   %xmm0,%r9d
  81e2a3:	and    $0x7fffffff,%r9d
  81e2aa:	cmp    $0x7f7fffff,%r9d
  81e2b1:	jg     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2b7:	pand   -0x770acf(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e2bf:	ucomiss -0x76f162(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e2c6:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2cc:	movd   0x20(%rcx),%xmm0
  81e2d1:	movd   %xmm0,%r9d
  81e2d6:	and    $0x7fffffff,%r9d
  81e2dd:	cmp    $0x7f7fffff,%r9d
  81e2e4:	jg     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ea:	pand   -0x770b02(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e2f2:	ucomiss -0x76f195(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e2f9:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ff:	movd   0x24(%rcx),%xmm0
  81e304:	movd   %xmm0,%r9d
  81e309:	and    $0x7fffffff,%r9d
  81e310:	cmp    $0x7f7fffff,%r9d
  81e317:	jg     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e31d:	movdqa -0x770b35(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e325:	pand   %xmm0,%xmm1
  81e329:	ucomiss -0x76f1cc(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e330:	ja     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e336:	xorps  %xmm1,%xmm1
  81e339:	ucomiss %xmm1,%xmm0
  81e33c:	jb     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e342:	movss  -0x76f56a(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e34a:	ucomiss %xmm0,%xmm1
  81e34d:	jb     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e353:	movzwl 0x30(%rcx),%r9d
  81e358:	mov    %r9w,0x10(%rsp)
  81e35e:	movzwl 0x32(%rcx),%r9d
  81e363:	mov    %r9w,0x18(%rsp)
  81e369:	cmp    $0x28,%r12d
  81e36d:	jne    81e379 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e36f:	test   $0x1,%al
  81e371:	je     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e377:	jmp    81e394 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e379:	test   $0x1,%al
  81e37b:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e381:	ucomiss -0x76f5a8(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e388:	jne    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e38e:	jp     81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e394:	mov    %r11,0x28(%rsp)
  81e399:	mov    %r10,0x60(%rsp)
  81e39e:	movss  %xmm1,0xe0(%rsp)
  81e3a7:	movd   %xmm2,0x280(%rsp)
  81e3b0:	mov    %rdx,0x110(%rsp)
  81e3b8:	mov    %r8,0x470(%rsp)
  81e3c0:	mov    %rdi,0x58(%rsp)
  81e3c5:	lea    0xf(%r14),%rax
  81e3c9:	shr    $0x4,%rax
  81e3cd:	lea    0xf(%r15),%r8d
  81e3d1:	shr    $0x4,%r8d
  81e3d5:	lea    0x18(%rsi),%rdi
  81e3d9:	movq   $0x0,0x28(%rsi)
  81e3e1:	mov    %rax,0x38(%rsp)
  81e3e6:	imul   %eax,%r8d
  81e3ea:	movabs $0x4000000000000000,%rdx
  81e3f4:	mov    %rdi,0x480(%rsp)
  81e3fc:	mov    %rsi,0x8(%rsp)
  81e401:	mov    %r8,0x30(%rsp)
  81e406:	mov    %r8,%rsi
  81e409:	mov    %rcx,0x118(%rsp)
  81e411:	call   8237a0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e416:	mov    0x8(%rsp),%rax
  81e41b:	movq   $0x0,0x10(%rax)
  81e423:	mov    0x118(%rsp),%rdi
  81e42b:	call   *0x662d8f(%rip)        # e811c0 <_DYNAMIC+0x5a8>
  81e431:	mov    %rdx,%rcx
  81e434:	sub    %rax,%rcx
  81e437:	cmp    $0x300000,%rcx
  81e43e:	jbe    81e450 <<gpui_gpu::renderer::RendererState>::render+0x430>
  81e440:	mov    0x58(%rsp),%rdi
  81e445:	movl   $0x6,(%rdi)
  81e44b:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e450:	mov    %rcx,%rdi
  81e453:	shr    $0x3,%rcx
  81e457:	movabs $0xaaaaaaaaaaaaaaab,%rsi
  81e461:	imul   %rcx,%rsi
  81e465:	mov    %rsi,0x20(%rsp)
  81e46a:	mov    %rax,0x468(%rsp)
  81e472:	mov    %rdx,0x460(%rsp)
  81e47a:	cmp    %rax,%rdx
  81e47d:	je     81e4ab <<gpui_gpu::renderer::RendererState>::render+0x48b>
  81e47f:	mov    $0xaaaaaaab,%eax
  81e484:	imul   %rax,%rdi
  81e488:	shr    $0x2a,%rdi
  81e48c:	mov    0x20(%rsp),%rcx
  81e491:	mov    %ecx,%eax
  81e493:	and    $0x3f,%eax
  81e496:	add    %rcx,%rdi
  81e499:	cmp    $0x1,%rax
  81e49d:	sbb    $0xffffffffffffffff,%rdi
  81e4a1:	inc    %rdi
  81e4a4:	mov    %rdi,0x40(%rsp)
  81e4a9:	jmp    81e4b4 <<gpui_gpu::renderer::RendererState>::render+0x494>
  81e4ab:	movq   $0x0,0x40(%rsp)
  81e4b4:	mov    0x28(%rsp),%rax
  81e4b9:	mov    0x98(%rax),%rcx
  81e4c0:	add    0xb0(%rax),%rcx
  81e4c7:	mov    %rax,0x120(%rsp)
  81e4cf:	movzwl 0x10(%rsp),%eax
  81e4d4:	mov    %ax,0x140(%rsp)
  81e4dc:	movzwl 0x18(%rsp),%eax
  81e4e1:	mov    %ax,0x142(%rsp)
  81e4e9:	movq   $0x0,0x128(%rsp)
  81e4f5:	mov    0x60(%rsp),%rax
  81e4fa:	mov    %rax,0x130(%rsp)
  81e502:	mov    %rcx,0x328(%rsp)
  81e50a:	mov    %rcx,0x138(%rsp)
  81e512:	mov    0x8(%rsp),%rax
  81e517:	movzbl 0x341(%rax),%edx
  81e51e:	lea    0x488(%rsp),%rdi
  81e526:	lea    0x120(%rsp),%rsi
  81e52e:	call   81c770 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e533:	mov    0x488(%rsp),%eax
  81e53a:	cmp    $0xffffffff,%eax
  81e53d:	je     81e56f <<gpui_gpu::renderer::RendererState>::render+0x54f>
  81e53f:	mov    0x48c(%rsp),%ecx
  81e546:	mov    0x490(%rsp),%rdx
  81e54e:	movdqu 0x498(%rsp),%xmm0
  81e557:	mov    0x58(%rsp),%rdi
  81e55c:	movdqu %xmm0,0x10(%rdi)
  81e561:	mov    %eax,(%rdi)
  81e563:	mov    %ecx,0x4(%rdi)
  81e566:	mov    %rdx,0x8(%rdi)
  81e56a:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e56f:	mov    0x40(%rsp),%rdx
  81e574:	add    0x490(%rsp),%rdx
  81e57c:	mov    0x8(%rsp),%rdi
  81e581:	mov    0x10(%rdi),%rsi
  81e585:	mov    $0x4,%ecx
  81e58a:	mov    $0x10,%r8d
  81e590:	call   827010 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e595:	cmp    $0xffffffffffffffff,%rax
  81e599:	jne    81e440 <<gpui_gpu::renderer::RendererState>::render+0x420>
  81e59f:	movzwl 0x10(%rsp),%eax
  81e5a4:	mov    %eax,0x10(%rsp)
  81e5a8:	movzwl 0x18(%rsp),%eax
  81e5ad:	mov    %eax,0xac(%rsp)
  81e5b4:	mov    0x8(%rsp),%rdi
  81e5b9:	mov    0x118(%rsp),%rsi
  81e5c1:	mov    0x20(%rsp),%rdx
  81e5c6:	call   825520 <gpui_gpu::renderer::slots::write_prefix>
  81e5cb:	mov    0x8(%rsp),%rax
  81e5d0:	lea    0x48(%rax),%rdi
  81e5d4:	movq   $0x0,0x58(%rax)
  81e5dc:	mov    %rdi,0x478(%rsp)
  81e5e4:	mov    0x30(%rsp),%rsi
  81e5e9:	xor    %edx,%edx
  81e5eb:	call   8238c0 <<alloc::vec::Vec<u32>>::resize>
  81e5f0:	mov    0x8(%rsp),%rax
  81e5f5:	movq   $0x0,0x70(%rax)
  81e5fd:	cmpq   $0x0,0x60(%rax)
  81e602:	jne    81e613 <<gpui_gpu::renderer::RendererState>::render+0x5f3>
  81e604:	mov    0x8(%rsp),%rax
  81e609:	lea    0x60(%rax),%rdi
  81e60d:	call   *0x662bb5(%rip)        # e811c8 <_DYNAMIC+0x5b0>
  81e613:	mov    0x8(%rsp),%rax
  81e618:	mov    0x68(%rax),%rcx
  81e61c:	pxor   %xmm0,%xmm0
  81e620:	movdqu %xmm0,0x10(%rcx)
  81e625:	movdqu %xmm0,(%rcx)
  81e629:	movq   $0x1,0x70(%rax)
  81e631:	lea    0x2f8(%rax),%rdi
  81e638:	call   8231f0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e63d:	mov    0xac(%rsp),%ecx
  81e644:	shl    $0x10,%ecx
  81e647:	add    0x10(%rsp),%ecx
  81e64b:	mov    0x28(%rsp),%rax
  81e650:	mov    %rax,0x338(%rsp)
  81e658:	movq   $0x0,0x340(%rsp)
  81e664:	mov    0x60(%rsp),%rax
  81e669:	mov    %rax,0x348(%rsp)
  81e671:	mov    0x328(%rsp),%rax
  81e679:	mov    %rax,0x350(%rsp)
  81e681:	mov    %ecx,0xac(%rsp)
  81e688:	mov    %ecx,0x358(%rsp)
  81e68f:	lea    0x288(%rsp),%rdi
  81e697:	lea    0x338(%rsp),%rsi
  81e69f:	call   *0x662b2b(%rip)        # e811d0 <_DYNAMIC+0x5b8>
  81e6a5:	mov    0x288(%rsp),%rax
  81e6ad:	mov    %rax,0x18(%rsp)
  81e6b2:	test   %rax,%rax
  81e6b5:	je     81f427 <<gpui_gpu::renderer::RendererState>::render+0x1407>
  81e6bb:	movq   $0x0,0xc8(%rsp)
  81e6c7:	movq   $0x0,0x10(%rsp)
  81e6d0:	movq   $0x0,0x70(%rsp)
  81e6d9:	movq   $0x0,0x248(%rsp)
  81e6e5:	movq   $0x0,0x250(%rsp)
  81e6f1:	mov    0x290(%rsp),%rcx
  81e6f9:	mov    0x298(%rsp),%rdx
  81e701:	mov    %rdx,0xd0(%rsp)
  81e709:	lea    0x2a0(%rsp),%rdi
  81e711:	movups (%rdi),%xmm0
  81e714:	movups 0x10(%rdi),%xmm1
  81e718:	movups 0x20(%rdi),%xmm2
  81e71c:	movaps %xmm2,0x310(%rsp)
  81e724:	movaps %xmm1,0x300(%rsp)
  81e72c:	movaps %xmm0,0x2f0(%rsp)
  81e734:	lea    0x2d0(%rsp),%r8
  81e73c:	movups (%r8),%xmm0
  81e740:	movaps %xmm0,0x450(%rsp)
  81e748:	movups 0x40(%rdi),%xmm0
  81e74c:	movaps %xmm0,0x380(%rsp)
  81e754:	mov    0x8(%rsp),%rax
  81e759:	movzbl 0x341(%rax),%esi
  81e760:	mov    0x18(%rsp),%rax
  81e765:	mov    %rax,0x120(%rsp)
  81e76d:	mov    %rcx,0x30(%rsp)
  81e772:	mov    %rcx,0x128(%rsp)
  81e77a:	mov    %rdx,0x130(%rsp)
  81e782:	movups (%rdi),%xmm0
  81e785:	movups 0x10(%rdi),%xmm1
  81e789:	movups 0x20(%rdi),%xmm2
  81e78d:	lea    0x138(%rsp),%rax
  81e795:	movups %xmm2,0x20(%rax)
  81e799:	movups %xmm1,0x10(%rax)
  81e79d:	movups %xmm0,(%rax)
  81e7a0:	movups (%r8),%xmm0
  81e7a4:	movups %xmm0,0x30(%rax)
  81e7a8:	movups 0x40(%rdi),%xmm0
  81e7ac:	movups %xmm0,0x40(%rax)
  81e7b0:	lea    0x120(%rsp),%rdi
  81e7b8:	call   821710 <gpui_gpu::renderer::compact_group>
  81e7bd:	mov    %al,0x40(%rsp)
  81e7c1:	lea    0x2a0(%rsp),%rsi
  81e7c9:	movups (%rsi),%xmm0
  81e7cc:	movups 0x10(%rsi),%xmm1
  81e7d0:	movups 0x20(%rsi),%xmm2
  81e7d4:	movaps %xmm0,0x530(%rsp)
  81e7dc:	movaps %xmm1,0x540(%rsp)
  81e7e4:	movaps %xmm2,0x550(%rsp)
  81e7ec:	lea    0x2d0(%rsp),%rdx
  81e7f4:	movdqu (%rdx),%xmm0
  81e7f8:	movdqa %xmm0,0x560(%rsp)
  81e801:	mov    0x8(%rsp),%rdi
  81e806:	call   81d3a0 <<gpui_gpu::renderer::RendererState>::correction>
  81e80b:	mov    %eax,0xc0(%rsp)
  81e812:	mov    0xd0(%rsp),%rax
  81e81a:	lea    0x0(,%rax,4),%rax
  81e822:	mov    %rax,0x258(%rsp)
  81e82a:	cmpb   $0x0,0x40(%rsp)
  81e82f:	je     81ea20 <<gpui_gpu::renderer::RendererState>::render+0xa00>
  81e835:	mov    0x30(%rsp),%rcx
  81e83a:	mov    0xd0(%rsp),%rax
  81e842:	lea    (%rcx,%rax,4),%rax
  81e846:	mov    %rcx,0x430(%rsp)
  81e84e:	mov    %rax,0x438(%rsp)
  81e856:	mov    0x18(%rsp),%rax
  81e85b:	mov    %rax,0x440(%rsp)
  81e863:	movq   $0x0,0x448(%rsp)
  81e86f:	lea    0x390(%rsp),%rdi
  81e877:	lea    0x430(%rsp),%rsi
  81e87f:	call   821da0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e884:	cmpb   $0xff,0x398(%rsp)
  81e88c:	je     81ef70 <<gpui_gpu::renderer::RendererState>::render+0xf50>
  81e892:	pxor   %xmm0,%xmm0
  81e896:	movdqa %xmm0,0xb0(%rsp)
  81e89f:	movdqa %xmm0,0x80(%rsp)
  81e8a8:	mov    0x390(%rsp),%rdx
  81e8b0:	add    0x70(%rsp),%rdx
  81e8b5:	lea    0x398(%rsp),%rsi
  81e8bd:	movups 0x38(%rsi),%xmm0
  81e8c1:	lea    0x121(%rsp),%rax
  81e8c9:	movups %xmm0,0x37(%rax)
  81e8cd:	movups 0x48(%rsi),%xmm0
  81e8d1:	lea    0x138(%rsp),%rcx
  81e8d9:	movups %xmm0,0x70(%rcx)
  81e8dd:	mov    0x30(%rsi),%rax
  81e8e1:	mov    %rax,0x150(%rsp)
  81e8e9:	movups (%rsi),%xmm0
  81e8ec:	movups 0x10(%rsi),%xmm1
  81e8f0:	movups 0x20(%rsi),%xmm2
  81e8f4:	movaps %xmm2,0x140(%rsp)
  81e8fc:	movaps %xmm1,0x130(%rsp)
  81e904:	movaps %xmm0,0x120(%rsp)
  81e90c:	lea    0x2a0(%rsp),%rax
  81e914:	movups 0x40(%rax),%xmm0
  81e918:	movups %xmm0,0x80(%rcx)
  81e91f:	movups (%rax),%xmm0
  81e922:	movups 0x10(%rax),%xmm1
  81e926:	movups 0x20(%rax),%xmm2
  81e92a:	movups %xmm2,0x50(%rcx)
  81e92e:	movups %xmm1,0x40(%rcx)
  81e932:	movups %xmm0,0x30(%rcx)
  81e936:	lea    0x2d0(%rsp),%rax
  81e93e:	movups (%rax),%xmm0
  81e941:	movups %xmm0,0x60(%rcx)
  81e945:	lea    0x360(%rsp),%rdi
  81e94d:	lea    0x120(%rsp),%rsi
  81e955:	mov    %r14d,%ecx
  81e958:	mov    %r15d,%r8d
  81e95b:	call   821760 <gpui_gpu::renderer::validate_draw>
  81e960:	mov    0x360(%rsp),%ecx
  81e967:	mov    0x364(%rsp),%rax
  81e96f:	cmp    $0xffffffff,%ecx
  81e972:	jne    81f4df <<gpui_gpu::renderer::RendererState>::render+0x14bf>
  81e978:	mov    %eax,%ecx
  81e97a:	shr    $0x20,%rax
  81e97e:	movd   %ecx,%xmm0
  81e982:	movaps 0xb0(%rsp),%xmm2
  81e98a:	movaps %xmm2,%xmm1
  81e98d:	maxss  %xmm0,%xmm1
  81e991:	movaps %xmm1,%xmm3
  81e994:	cmpunordss %xmm1,%xmm3
  81e999:	movaps %xmm3,%xmm0
  81e99c:	andnps %xmm1,%xmm0
  81e99f:	andps  %xmm2,%xmm3
  81e9a2:	orps   %xmm0,%xmm3
  81e9a5:	movaps %xmm3,0x40(%rsp)
  81e9aa:	movd   %eax,%xmm0
  81e9ae:	movaps 0x80(%rsp),%xmm2
  81e9b6:	movaps %xmm2,%xmm1
  81e9b9:	maxss  %xmm0,%xmm1
  81e9bd:	movaps %xmm1,%xmm3
  81e9c0:	cmpunordss %xmm1,%xmm3
  81e9c5:	movaps %xmm3,%xmm0
  81e9c8:	andnps %xmm1,%xmm0
  81e9cb:	andps  %xmm2,%xmm3
  81e9ce:	orps   %xmm0,%xmm3
  81e9d1:	movaps %xmm3,0x90(%rsp)
  81e9d9:	lea    0x390(%rsp),%rdi
  81e9e1:	lea    0x430(%rsp),%rsi
  81e9e9:	call   821da0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e9ee:	cmpb   $0xff,0x398(%rsp)
  81e9f6:	movaps 0x40(%rsp),%xmm0
  81e9fb:	movaps %xmm0,0xb0(%rsp)
  81ea03:	movdqa 0x90(%rsp),%xmm0
  81ea0c:	movdqa %xmm0,0x80(%rsp)
  81ea15:	jne    81e8a8 <<gpui_gpu::renderer::RendererState>::render+0x888>
  81ea1b:	jmp    81ef83 <<gpui_gpu::renderer::RendererState>::render+0xf63>
  81ea20:	cmpq   $0x0,0xd0(%rsp)
  81ea29:	je     81f3d1 <<gpui_gpu::renderer::RendererState>::render+0x13b1>
  81ea2f:	mov    0xc0(%rsp),%eax
  81ea36:	or     $0x80000000,%eax
  81ea3b:	mov    %eax,0x27c(%rsp)
  81ea42:	movq   $0x0,0x90(%rsp)
  81ea4e:	mov    0x30(%rsp),%rax
  81ea53:	mov    0x90(%rsp),%rcx
  81ea5b:	mov    (%rax,%rcx,1),%edx
  81ea5e:	lea    0x120(%rsp),%rdi
  81ea66:	mov    0x18(%rsp),%rsi
  81ea6b:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81ea70:	movzbl 0x120(%rsp),%edi
  81ea78:	lea    0x121(%rsp),%rdx
  81ea80:	mov    (%rdx),%eax
  81ea82:	mov    0x3(%rdx),%ecx
  81ea85:	lea    0x4c0(%rsp),%rsi
  81ea8d:	mov    %ecx,-0x34(%rsi)
  81ea90:	mov    %eax,-0x37(%rsi)
  81ea93:	mov    0x128(%rsp),%rcx
  81ea9b:	mov    0x2f(%rdx),%rax
  81ea9f:	mov    %rax,-0x8(%rsi)
  81eaa3:	movups 0xf(%rdx),%xmm0
  81eaa7:	movups 0x1f(%rdx),%xmm1
  81eaab:	movups %xmm1,-0x18(%rsi)
  81eaaf:	movups %xmm0,-0x28(%rsi)
  81eab3:	movups 0x37(%rdx),%xmm0
  81eab7:	movups %xmm0,(%rsi)
  81eaba:	lea    0x138(%rsp),%rax
  81eac2:	movups 0x30(%rax),%xmm0
  81eac6:	movups %xmm0,0x50(%rsi)
  81eaca:	lea    0x2a0(%rsp),%rax
  81ead2:	movups 0x40(%rax),%xmm0
  81ead6:	movups %xmm0,0x60(%rsi)
  81eada:	movups (%rax),%xmm0
  81eadd:	movups 0x10(%rax),%xmm1
  81eae1:	movups 0x20(%rax),%xmm2
  81eae5:	movups %xmm2,0x30(%rsi)
  81eae9:	movups %xmm1,0x20(%rsi)
  81eaed:	movups %xmm0,0x10(%rsi)
  81eaf1:	lea    0x2d0(%rsp),%rax
  81eaf9:	movups (%rax),%xmm0
  81eafc:	movups %xmm0,0x40(%rsi)
  81eb00:	mov    %dil,0x80(%rsp)
  81eb08:	mov    %dil,0x488(%rsp)
  81eb10:	mov    %rcx,0xb0(%rsp)
  81eb18:	mov    %rcx,0x490(%rsp)
  81eb20:	lea    0x120(%rsp),%rdi
  81eb28:	lea    0x488(%rsp),%rsi
  81eb30:	mov    0x70(%rsp),%rdx
  81eb35:	mov    %r14d,%ecx
  81eb38:	mov    %r15d,%r8d
  81eb3b:	call   821760 <gpui_gpu::renderer::validate_draw>
  81eb40:	mov    0x120(%rsp),%eax
  81eb47:	mov    0x124(%rsp),%rcx
  81eb4f:	mov    %rcx,0x40(%rsp)
  81eb54:	cmp    $0xffffffff,%eax
  81eb57:	jne    81f573 <<gpui_gpu::renderer::RendererState>::render+0x1553>
  81eb5d:	movzbl 0x80(%rsp),%eax
  81eb65:	cmp    $0x2,%al
  81eb67:	sete   0x260(%rsp)
  81eb6f:	cmpq   $0x0,0xb0(%rsp)
  81eb78:	setne  0x108(%rsp)
  81eb80:	movups 0x4c0(%rsp),%xmm0
  81eb88:	movaps %xmm0,0x230(%rsp)
  81eb90:	cmp    $0x3,%al
  81eb92:	jne    81ec27 <<gpui_gpu::renderer::RendererState>::render+0xc07>
  81eb98:	movss  0x48c(%rsp),%xmm0
  81eba1:	xorps  %xmm1,%xmm1
  81eba4:	ucomiss %xmm1,%xmm0
  81eba7:	jne    81ebab <<gpui_gpu::renderer::RendererState>::render+0xb8b>
  81eba9:	jnp    81ec27 <<gpui_gpu::renderer::RendererState>::render+0xc07>
  81ebab:	movaps 0x230(%rsp),%xmm5
  81ebb3:	movaps %xmm5,%xmm1
  81ebb6:	unpckhpd %xmm5,%xmm1
  81ebba:	movss  -0x76fbf6(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ebc2:	mulss  %xmm4,%xmm1
  81ebc6:	movaps %xmm0,%xmm2
  81ebc9:	minss  %xmm1,%xmm2
  81ebcd:	movaps %xmm2,%xmm1
  81ebd0:	cmpunordss %xmm2,%xmm1
  81ebd5:	movaps %xmm1,%xmm3
  81ebd8:	andnps %xmm2,%xmm3
  81ebdb:	andps  %xmm0,%xmm1
  81ebde:	orps   %xmm3,%xmm1
  81ebe1:	movaps %xmm5,%xmm0
  81ebe4:	shufps $0xff,%xmm5,%xmm0
  81ebe8:	mulss  %xmm4,%xmm0
  81ebec:	movaps %xmm1,%xmm2
  81ebef:	minss  %xmm0,%xmm2
  81ebf3:	movaps %xmm2,%xmm0
  81ebf6:	cmpunordss %xmm2,%xmm0
  81ebfb:	andps  %xmm0,%xmm1
  81ebfe:	andnps %xmm2,%xmm0
  81ec01:	orps   %xmm1,%xmm0
  81ec04:	movd   %xmm0,%eax
  81ec08:	mov    %eax,0x80(%rsp)
  81ec0f:	and    $0xff800000,%eax
  81ec14:	mov    $0x7f000000,%ecx
  81ec19:	sub    %eax,%ecx
  81ec1b:	mov    %ecx,0xb0(%rsp)
  81ec22:	xorps  %xmm0,%xmm0
  81ec25:	jmp    81ec4c <<gpui_gpu::renderer::RendererState>::render+0xc2c>
  81ec27:	mov    0x520(%rsp),%eax
  81ec2e:	mov    %eax,0x80(%rsp)
  81ec35:	mov    0x524(%rsp),%eax
  81ec3c:	mov    %eax,0xb0(%rsp)
  81ec43:	movsd  0x528(%rsp),%xmm0
  81ec4c:	movaps %xmm0,0xf0(%rsp)
  81ec54:	mov    0x8(%rsp),%rax
  81ec59:	mov    0x10(%rax),%ecx
  81ec5c:	mov    $0x80000000,%eax
  81ec61:	or     %eax,%ecx
  81ec63:	mov    %ecx,0x220(%rsp)
  81ec6a:	movups 0x4d0(%rsp),%xmm0
  81ec72:	movaps %xmm0,0x420(%rsp)
  81ec7a:	movups 0x4d8(%rsp),%xmm0
  81ec82:	movaps %xmm0,0x400(%rsp)
  81ec8a:	movsd  0x4e0(%rsp),%xmm0
  81ec93:	movaps %xmm0,0x410(%rsp)
  81ec9b:	movsd  0x4e8(%rsp),%xmm0
  81eca4:	movaps %xmm0,0x3f0(%rsp)
  81ecac:	movsd  0x4f0(%rsp),%xmm0
  81ecb5:	movsd  %xmm0,0x270(%rsp)
  81ecbe:	movsd  0x4f8(%rsp),%xmm0
  81ecc7:	movsd  %xmm0,0x268(%rsp)
  81ecd0:	movups 0x500(%rsp),%xmm0
  81ecd8:	movaps %xmm0,0x210(%rsp)
  81ece0:	mov    0x18(%rsp),%rax
  81ece5:	mov    %rax,0x120(%rsp)
  81eced:	mov    0x30(%rsp),%rax
  81ecf2:	mov    %rax,0x128(%rsp)
  81ecfa:	mov    0xd0(%rsp),%rax
  81ed02:	mov    %rax,0x130(%rsp)
  81ed0a:	movaps 0x2f0(%rsp),%xmm0
  81ed12:	movaps 0x300(%rsp),%xmm1
  81ed1a:	movaps 0x310(%rsp),%xmm2
  81ed22:	lea    0x138(%rsp),%rax
  81ed2a:	movups %xmm2,0x20(%rax)
  81ed2e:	movups %xmm1,0x10(%rax)
  81ed32:	movups %xmm0,(%rax)
  81ed35:	movaps 0x450(%rsp),%xmm0
  81ed3d:	movups %xmm0,0x30(%rax)
  81ed41:	movaps 0x380(%rsp),%xmm0
  81ed49:	movups %xmm0,0x40(%rax)
  81ed4d:	lea    0x120(%rsp),%rdi
  81ed55:	call   *0x66247d(%rip)        # e811d8 <_DYNAMIC+0x5c0>
  81ed5b:	mov    0xc0(%rsp),%ecx
  81ed62:	mov    %ecx,0x68(%rsp)
  81ed66:	test   %eax,%eax
  81ed68:	je     81ed9e <<gpui_gpu::renderer::RendererState>::render+0xd7e>
  81ed6a:	mov    0x20(%rsp),%rdi
  81ed6f:	mov    %eax,%esi
  81ed71:	call   8254e0 <gpui_gpu::renderer::slots::color_word>
  81ed76:	mov    %eax,0x80(%rsp)
  81ed7d:	xorps  %xmm0,%xmm0
  81ed80:	movaps %xmm0,0xf0(%rsp)
  81ed88:	movl   $0x0,0xb0(%rsp)
  81ed93:	mov    0x27c(%rsp),%eax
  81ed9a:	mov    %eax,0x68(%rsp)
  81ed9e:	mov    0x40(%rsp),%rax
  81eda3:	shr    $0x20,%rax
  81eda7:	mov    %rax,0x78(%rsp)
  81edac:	mov    0x8(%rsp),%rax
  81edb1:	mov    (%rax),%rcx
  81edb4:	mov    0x10(%rax),%rsi
  81edb8:	sub    %rsi,%rcx
  81edbb:	cmp    $0x5,%rcx
  81edbf:	jbe    81ef48 <<gpui_gpu::renderer::RendererState>::render+0xf28>
  81edc5:	movsd  0x268(%rsp),%xmm0
  81edce:	cvtsd2ss %xmm0,%xmm0
  81edd2:	movsd  0x270(%rsp),%xmm1
  81eddb:	cvtsd2ss %xmm1,%xmm1
  81eddf:	movapd 0x400(%rsp),%xmm2
  81ede8:	unpcklpd 0x3f0(%rsp),%xmm2
  81edf1:	cvtpd2ps %xmm2,%xmm2
  81edf5:	movapd 0x420(%rsp),%xmm3
  81edfe:	unpcklpd 0x410(%rsp),%xmm3
  81ee07:	cvtpd2ps %xmm3,%xmm3
  81ee0b:	mov    0x8(%rsp),%rax
  81ee10:	mov    0x8(%rax),%rdx
  81ee14:	shl    $0x4,%rsi
  81ee18:	movaps 0x230(%rsp),%xmm4
  81ee20:	movups %xmm4,(%rdx,%rsi,1)
  81ee24:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ee2a:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ee30:	mov    0x40(%rsp),%rcx
  81ee35:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ee39:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ee3f:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81ee45:	mov    0x78(%rsp),%rdi
  81ee4a:	mov    %edi,0x2c(%rdx,%rsi,1)
  81ee4e:	movaps 0x210(%rsp),%xmm0
  81ee56:	movups %xmm0,0x30(%rdx,%rsi,1)
  81ee5b:	mov    0x80(%rsp),%edi
  81ee62:	mov    %edi,0x40(%rdx,%rsi,1)
  81ee66:	mov    0xb0(%rsp),%edi
  81ee6d:	mov    %edi,0x44(%rdx,%rsi,1)
  81ee71:	movdqa 0xf0(%rsp),%xmm0
  81ee7a:	movq   %xmm0,0x48(%rdx,%rsi,1)
  81ee80:	movq   $0x0,0x50(%rdx,%rsi,1)
  81ee89:	movl   $0x0,0x58(%rdx,%rsi,1)
  81ee91:	mov    0x68(%rsp),%edi
  81ee95:	mov    %edi,0x5c(%rdx,%rsi,1)
  81ee99:	addq   $0x6,0x10(%rax)
  81ee9e:	lea    0x120(%rsp),%rdi
  81eea6:	mov    %rax,%rsi
  81eea9:	lea    0x488(%rsp),%rdx
  81eeb1:	mov    0x220(%rsp),%r8d
  81eeb9:	mov    0x70(%rsp),%r9
  81eebe:	push   0xc8(%rsp)
  81eec5:	push   %r15
  81eec7:	push   %r14
  81eec9:	push   0x50(%rsp)
  81eecd:	call   820550 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81eed2:	add    $0x20,%rsp
  81eed6:	mov    0x120(%rsp),%eax
  81eedd:	cmp    $0xffffffff,%eax
  81eee0:	jne    81f53a <<gpui_gpu::renderer::RendererState>::render+0x151a>
  81eee6:	movzbl 0x260(%rsp),%ecx
  81eeee:	and    0x108(%rsp),%cl
  81eef5:	mov    0x10(%rsp),%rax
  81eefa:	or     %cl,%al
  81eefc:	mov    %rax,0x10(%rsp)
  81ef01:	mov    0x128(%rsp),%rax
  81ef09:	mov    %rax,0xc8(%rsp)
  81ef11:	incq   0x70(%rsp)
  81ef16:	mov    0x90(%rsp),%rdx
  81ef1e:	add    $0x4,%rdx
  81ef22:	mov    0xd0(%rsp),%rax
  81ef2a:	lea    0x0(,%rax,4),%rax
  81ef32:	mov    %rdx,0x90(%rsp)
  81ef3a:	cmp    %rdx,%rax
  81ef3d:	jne    81ea4e <<gpui_gpu::renderer::RendererState>::render+0xa2e>
  81ef43:	jmp    81f3c5 <<gpui_gpu::renderer::RendererState>::render+0x13a5>
  81ef48:	mov    $0x6,%edx
  81ef4d:	mov    $0x4,%ecx
  81ef52:	mov    $0x10,%r8d
  81ef58:	mov    0x8(%rsp),%rdi
  81ef5d:	call   826f80 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81ef62:	mov    0x8(%rsp),%rax
  81ef67:	mov    0x10(%rax),%rsi
  81ef6b:	jmp    81edc5 <<gpui_gpu::renderer::RendererState>::render+0xda5>
  81ef70:	pxor   %xmm0,%xmm0
  81ef74:	movdqa %xmm0,0x90(%rsp)
  81ef7d:	movdqa %xmm0,0x40(%rsp)
  81ef83:	mov    0x8(%rsp),%rax
  81ef88:	mov    0x10(%rax),%eax
  81ef8b:	mov    %eax,0xf0(%rsp)
  81ef92:	movups 0x2a0(%rsp),%xmm1
  81ef9a:	movups 0x2a8(%rsp),%xmm2
  81efa2:	movsd  0x2c0(%rsp),%xmm0
  81efab:	movsd  %xmm0,0x68(%rsp)
  81efb1:	movsd  0x2c8(%rsp),%xmm0
  81efba:	movsd  %xmm0,0x230(%rsp)
  81efc3:	movups 0x2d0(%rsp),%xmm0
  81efcb:	movaps %xmm0,0xb0(%rsp)
  81efd3:	movhps 0x2b0(%rsp),%xmm1
  81efdb:	movaps %xmm1,0x220(%rsp)
  81efe3:	movups 0x2e0(%rsp),%xmm0
  81efeb:	movaps %xmm0,0x80(%rsp)
  81eff3:	movhps 0x2b8(%rsp),%xmm2
  81effb:	movaps %xmm2,0x210(%rsp)
  81f003:	mov    0x18(%rsp),%rax
  81f008:	mov    %rax,0x120(%rsp)
  81f010:	mov    0x30(%rsp),%rax
  81f015:	mov    %rax,0x128(%rsp)
  81f01d:	mov    0xd0(%rsp),%rax
  81f025:	mov    %rax,0x130(%rsp)
  81f02d:	lea    0x2a0(%rsp),%rax
  81f035:	movups (%rax),%xmm0
  81f038:	movups 0x10(%rax),%xmm1
  81f03c:	movups 0x20(%rax),%xmm2
  81f040:	lea    0x138(%rsp),%rdx
  81f048:	movups %xmm2,0x20(%rdx)
  81f04c:	movups %xmm1,0x10(%rdx)
  81f050:	movups %xmm0,(%rdx)
  81f053:	lea    0x2d0(%rsp),%rcx
  81f05b:	movups (%rcx),%xmm0
  81f05e:	movups %xmm0,0x30(%rdx)
  81f062:	movdqu 0x40(%rax),%xmm0
  81f067:	movdqu %xmm0,0x40(%rdx)
  81f06c:	lea    0x120(%rsp),%rdi
  81f074:	call   *0x66215e(%rip)        # e811d8 <_DYNAMIC+0x5c0>
  81f07a:	test   %eax,%eax
  81f07c:	je     81f0a2 <<gpui_gpu::renderer::RendererState>::render+0x1082>
  81f07e:	mov    0x20(%rsp),%rdi
  81f083:	mov    %eax,%esi
  81f085:	call   8254e0 <gpui_gpu::renderer::slots::color_word>
  81f08a:	orl    $0x80000000,0xc0(%rsp)
  81f095:	movd   %eax,%xmm0
  81f099:	movdqa %xmm0,0x80(%rsp)
  81f0a2:	mov    0x8(%rsp),%rax
  81f0a7:	mov    (%rax),%rcx
  81f0aa:	mov    0x10(%rax),%rsi
  81f0ae:	sub    %rsi,%rcx
  81f0b1:	cmp    $0x4,%rcx
  81f0b5:	jbe    81f3ff <<gpui_gpu::renderer::RendererState>::render+0x13df>
  81f0bb:	cvtpd2ps 0x220(%rsp),%xmm0
  81f0c4:	cvtpd2ps 0x210(%rsp),%xmm1
  81f0cd:	movsd  0x68(%rsp),%xmm2
  81f0d3:	cvtsd2ss %xmm2,%xmm2
  81f0d7:	movsd  0x230(%rsp),%xmm3
  81f0e0:	cvtsd2ss %xmm3,%xmm3
  81f0e4:	mov    0x8(%rsp),%rax
  81f0e9:	mov    0x8(%rax),%rcx
  81f0ed:	shl    $0x4,%rsi
  81f0f1:	movlpd %xmm0,(%rcx,%rsi,1)
  81f0f6:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f0fc:	movaps 0x40(%rsp),%xmm0
  81f101:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f107:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f10d:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f113:	movaps 0x90(%rsp),%xmm0
  81f11b:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f121:	movaps 0xb0(%rsp),%xmm0
  81f129:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f12e:	movdqa 0x80(%rsp),%xmm0
  81f137:	movdqu %xmm0,0x30(%rcx,%rsi,1)
  81f13d:	mov    0xc0(%rsp),%edx
  81f144:	mov    %edx,0x40(%rcx,%rsi,1)
  81f148:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f151:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f159:	addq   $0x5,0x10(%rax)
  81f15e:	incq   0x248(%rsp)
  81f166:	mov    0xd0(%rsp),%rax
  81f16e:	add    %rax,0x250(%rsp)
  81f176:	test   %rax,%rax
  81f179:	je     81f3d1 <<gpui_gpu::renderer::RendererState>::render+0x13b1>
  81f17f:	movdqa 0x40(%rsp),%xmm0
  81f185:	movd   %xmm0,%ecx
  81f189:	movdqa 0x90(%rsp),%xmm0
  81f192:	movd   %xmm0,%eax
  81f196:	shl    $0x20,%rax
  81f19a:	or     %rax,%rcx
  81f19d:	mov    %rcx,0x68(%rsp)
  81f1a2:	movq   $0x0,0x40(%rsp)
  81f1ab:	mov    0x30(%rsp),%rax
  81f1b0:	mov    0x40(%rsp),%rcx
  81f1b5:	mov    (%rax,%rcx,1),%edx
  81f1b8:	lea    0x390(%rsp),%rdi
  81f1c0:	mov    0x18(%rsp),%rsi
  81f1c5:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f1ca:	movzbl 0x390(%rsp),%edi
  81f1d2:	lea    0x398(%rsp),%rsi
  81f1da:	mov    -0x7(%rsi),%eax
  81f1dd:	mov    -0x4(%rsi),%ecx
  81f1e0:	lea    0x121(%rsp),%rdx
  81f1e8:	mov    %ecx,0x3(%rdx)
  81f1eb:	mov    %eax,(%rdx)
  81f1ed:	mov    0x398(%rsp),%rcx
  81f1f5:	mov    0x28(%rsi),%rax
  81f1f9:	mov    %rax,0x2f(%rdx)
  81f1fd:	movups 0x8(%rsi),%xmm0
  81f201:	movups 0x18(%rsi),%xmm1
  81f205:	movups %xmm1,0x1f(%rdx)
  81f209:	movups %xmm0,0xf(%rdx)
  81f20d:	movups 0x3c8(%rsp),%xmm1
  81f215:	movups 0x40(%rsi),%xmm0
  81f219:	lea    0x138(%rsp),%rax
  81f221:	movups %xmm0,0x70(%rax)
  81f225:	movaps 0x380(%rsp),%xmm0
  81f22d:	movups %xmm0,0x80(%rax)
  81f234:	movaps %xmm1,0xd0(%rsp)
  81f23c:	movups %xmm1,0x158(%rsp)
  81f244:	movaps 0x530(%rsp),%xmm0
  81f24c:	movaps 0x540(%rsp),%xmm1
  81f254:	movapd 0x550(%rsp),%xmm2
  81f25d:	movupd %xmm2,0x50(%rax)
  81f262:	movups %xmm1,0x40(%rax)
  81f266:	movups %xmm0,0x30(%rax)
  81f26a:	movaps 0x560(%rsp),%xmm0
  81f272:	movups %xmm0,0x60(%rax)
  81f276:	mov    %dil,0x80(%rsp)
  81f27e:	mov    %dil,0x120(%rsp)
  81f286:	mov    %rcx,0xb0(%rsp)
  81f28e:	mov    %rcx,0x128(%rsp)
  81f296:	mov    0x8(%rsp),%rax
  81f29b:	mov    (%rax),%rcx
  81f29e:	mov    0x10(%rax),%rax
  81f2a2:	sub    %rax,%rcx
  81f2a5:	mov    %rax,0x90(%rsp)
  81f2ad:	cmp    $0x1,%rcx
  81f2b1:	jbe    81f395 <<gpui_gpu::renderer::RendererState>::render+0x1375>
  81f2b7:	mov    0x8(%rsp),%rsi
  81f2bc:	mov    0x8(%rsi),%rcx
  81f2c0:	shl    $0x4,%rax
  81f2c4:	movdqa 0xd0(%rsp),%xmm0
  81f2cd:	movdqu %xmm0,(%rcx,%rax,1)
  81f2d2:	movq   $0x0,0x10(%rcx,%rax,1)
  81f2db:	movl   $0x0,0x18(%rcx,%rax,1)
  81f2e3:	mov    0xf0(%rsp),%edx
  81f2ea:	mov    %edx,0x1c(%rcx,%rax,1)
  81f2ee:	addq   $0x2,0x10(%rsi)
  81f2f3:	lea    0x390(%rsp),%rdi
  81f2fb:	lea    0x120(%rsp),%rdx
  81f303:	mov    0x68(%rsp),%rcx
  81f308:	mov    0x90(%rsp),%r8
  81f310:	mov    0x70(%rsp),%r9
  81f315:	push   0xc8(%rsp)
  81f31c:	push   %r15
  81f31e:	push   %r14
  81f320:	push   0x50(%rsp)
  81f324:	call   820550 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f329:	add    $0x20,%rsp
  81f32d:	mov    0x390(%rsp),%eax
  81f334:	cmp    $0xffffffff,%eax
  81f337:	jne    81f557 <<gpui_gpu::renderer::RendererState>::render+0x1537>
  81f33d:	cmpb   $0x2,0x80(%rsp)
  81f345:	sete   %al
  81f348:	cmpq   $0x0,0xb0(%rsp)
  81f351:	setne  %cl
  81f354:	and    %al,%cl
  81f356:	mov    0x10(%rsp),%rax
  81f35b:	or     %cl,%al
  81f35d:	mov    %rax,0x10(%rsp)
  81f362:	mov    0x398(%rsp),%rax
  81f36a:	mov    %rax,0xc8(%rsp)
  81f372:	incq   0x70(%rsp)
  81f377:	mov    0x40(%rsp),%rcx
  81f37c:	add    $0x4,%rcx
  81f380:	mov    %rcx,0x40(%rsp)
  81f385:	cmp    %rcx,0x258(%rsp)
  81f38d:	jne    81f1ab <<gpui_gpu::renderer::RendererState>::render+0x118b>
  81f393:	jmp    81f3c5 <<gpui_gpu::renderer::RendererState>::render+0x13a5>
  81f395:	mov    $0x2,%edx
  81f39a:	mov    $0x4,%ecx
  81f39f:	mov    $0x10,%r8d
  81f3a5:	mov    0x8(%rsp),%rdi
  81f3aa:	mov    0x90(%rsp),%rsi
  81f3b2:	call   826f80 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f3b7:	mov    0x8(%rsp),%rax
  81f3bc:	mov    0x10(%rax),%rax
  81f3c0:	jmp    81f2b7 <<gpui_gpu::renderer::RendererState>::render+0x1297>
  81f3c5:	mov    0x10(%rsp),%rax
  81f3ca:	and    $0x1,%al
  81f3cc:	mov    %rax,0x10(%rsp)
  81f3d1:	lea    0x288(%rsp),%rdi
  81f3d9:	lea    0x338(%rsp),%rsi
  81f3e1:	call   *0x661de9(%rip)        # e811d0 <_DYNAMIC+0x5b8>
  81f3e7:	mov    0x288(%rsp),%rax
  81f3ef:	mov    %rax,0x18(%rsp)
  81f3f4:	test   %rax,%rax
  81f3f7:	jne    81e6f1 <<gpui_gpu::renderer::RendererState>::render+0x6d1>
  81f3fd:	jmp    81f45d <<gpui_gpu::renderer::RendererState>::render+0x143d>
  81f3ff:	mov    $0x5,%edx
  81f404:	mov    $0x4,%ecx
  81f409:	mov    $0x10,%r8d
  81f40f:	mov    0x8(%rsp),%rdi
  81f414:	call   826f80 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f419:	mov    0x8(%rsp),%rax
  81f41e:	mov    0x10(%rax),%rsi
  81f422:	jmp    81f0bb <<gpui_gpu::renderer::RendererState>::render+0x109b>
  81f427:	movq   $0x0,0x250(%rsp)
  81f433:	movq   $0x0,0x248(%rsp)
  81f43f:	movq   $0x0,0x70(%rsp)
  81f448:	movq   $0x0,0x10(%rsp)
  81f451:	movq   $0x0,0xc8(%rsp)
  81f45d:	mov    0x110(%rsp),%rsi
  81f465:	lea    0x8(%rsi),%rdx
  81f469:	mov    0x8(%rsp),%rax
  81f46e:	lea    0x258(%rax),%rcx
  81f475:	lea    0x328(%rax),%r8
  81f47c:	mov    0x10(%rax),%r9
  81f480:	sub    $0x8,%rsp
  81f484:	lea    0x128(%rsp),%rdi
  81f48c:	mov    %rdx,0xc8(%rsp)
  81f494:	mov    %rcx,0x110(%rsp)
  81f49c:	mov    %r8,0x278(%rsp)
  81f4a4:	push   0x120(%rsp)
  81f4ab:	call   823a10 <gpui_gpu::renderer::images::prepare>
  81f4b0:	add    $0x10,%rsp
  81f4b4:	cmpl   $0xffffffff,0x120(%rsp)
  81f4bc:	je     81f505 <<gpui_gpu::renderer::RendererState>::render+0x14e5>
  81f4be:	movups 0x120(%rsp),%xmm0
  81f4c6:	movups 0x130(%rsp),%xmm1
  81f4ce:	mov    0x58(%rsp),%rdi
  81f4d3:	movups %xmm1,0x10(%rdi)
  81f4d7:	movups %xmm0,(%rdi)
  81f4da:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f4df:	mov    0x37c(%rsp),%edx
  81f4e6:	mov    0x58(%rsp),%rdi
  81f4eb:	mov    %edx,0x1c(%rdi)
  81f4ee:	movups 0x36c(%rsp),%xmm0
  81f4f6:	movups %xmm0,0xc(%rdi)
  81f4fa:	mov    %ecx,(%rdi)
  81f4fc:	mov    %rax,0x4(%rdi)
  81f500:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f505:	movzbl 0x10(%rsp),%r8d
  81f50b:	and    $0x1,%r8d
  81f50f:	lea    0x120(%rsp),%rdi
  81f517:	mov    0x8(%rsp),%rsi
  81f51c:	mov    0x110(%rsp),%rdx
  81f524:	mov    0x28(%rsp),%rcx
  81f529:	call   81d780 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f52e:	mov    0x120(%rsp),%eax
  81f535:	cmp    $0xffffffff,%eax
  81f538:	je     81f59e <<gpui_gpu::renderer::RendererState>::render+0x157e>
  81f53a:	mov    0x124(%rsp),%ecx
  81f541:	mov    0x128(%rsp),%rdx
  81f549:	movdqu 0x130(%rsp),%xmm0
  81f552:	jmp    81e557 <<gpui_gpu::renderer::RendererState>::render+0x537>
  81f557:	mov    0x394(%rsp),%ecx
  81f55e:	mov    0x398(%rsp),%rdx
  81f566:	movups 0x3a0(%rsp),%xmm0
  81f56e:	jmp    81e557 <<gpui_gpu::renderer::RendererState>::render+0x537>
  81f573:	mov    0x13c(%rsp),%ecx
  81f57a:	mov    0x58(%rsp),%rdi
  81f57f:	mov    %ecx,0x1c(%rdi)
  81f582:	movups 0x12c(%rsp),%xmm0
  81f58a:	movups %xmm0,0xc(%rdi)
  81f58e:	mov    %eax,(%rdi)
  81f590:	mov    0x40(%rsp),%rax
  81f595:	mov    %rax,0x4(%rdi)
  81f599:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f59e:	mov    0x128(%rsp),%rax
  81f5a6:	mov    %rax,0x258(%rsp)
  81f5ae:	mov    0x8(%rsp),%rax
  81f5b3:	mov    0x28(%rax),%rax
  81f5b7:	movq   $0x0,0x78(%rsp)
  81f5c0:	test   %rax,%rax
  81f5c3:	je     81f65c <<gpui_gpu::renderer::RendererState>::render+0x163c>
  81f5c9:	mov    0x8(%rsp),%rcx
  81f5ce:	mov    0x20(%rcx),%rcx
  81f5d2:	shl    $0x3,%rax
  81f5d6:	xor    %edi,%edi
  81f5d8:	jmp    81f613 <<gpui_gpu::renderer::RendererState>::render+0x15f3>
  81f5da:	and    $0x40000000,%edx
  81f5e0:	mov    0x78(%rsp),%r9
  81f5e5:	add    %esi,%r9d
  81f5e8:	xor    %esi,%esi
  81f5ea:	test   %r8d,%r8d
  81f5ed:	setne  %sil
  81f5f1:	shl    $0x1d,%esi
  81f5f4:	or     %r9d,%edx
  81f5f7:	or     %esi,%edx
  81f5f9:	mov    %r9,0x78(%rsp)
  81f5fe:	mov    %r9d,(%rcx,%rdi,8)
  81f602:	mov    %edx,%r9d
  81f605:	mov    %r9d,0x4(%rcx,%rdi,8)
  81f60a:	inc    %rdi
  81f60d:	add    $0xfffffffffffffff8,%rax
  81f611:	je     81f650 <<gpui_gpu::renderer::RendererState>::render+0x1630>
  81f613:	mov    0x8(%rsp),%rdx
  81f618:	mov    0x58(%rdx),%rsi
  81f61c:	cmp    %rsi,%rdi
  81f61f:	jae    8204f3 <<gpui_gpu::renderer::RendererState>::render+0x24d3>
  81f625:	mov    0x4(%rcx,%rdi,8),%edx
  81f629:	mov    %edx,%esi
  81f62b:	and    $0xbfffffff,%esi
  81f631:	mov    0x8(%rsp),%r8
  81f636:	mov    0x50(%r8),%r8
  81f63a:	mov    (%r8,%rdi,4),%r8d
  81f63e:	cmp    $0x1,%esi
  81f641:	jne    81f5da <<gpui_gpu::renderer::RendererState>::render+0x15ba>
  81f643:	mov    $0x80000000,%r9d
  81f649:	test   %r8d,%r8d
  81f64c:	jne    81f605 <<gpui_gpu::renderer::RendererState>::render+0x15e5>
  81f64e:	jmp    81f5da <<gpui_gpu::renderer::RendererState>::render+0x15ba>
  81f650:	mov    0x78(%rsp),%rax
  81f655:	mov    %eax,%eax
  81f657:	mov    %rax,0x78(%rsp)
  81f65c:	mov    0x8(%rsp),%rax
  81f661:	lea    0x30(%rax),%rdi
  81f665:	movq   $0x0,0x40(%rax)
  81f66d:	mov    %rdi,0x3f0(%rsp)
  81f675:	mov    0x78(%rsp),%rsi
  81f67a:	xor    %edx,%edx
  81f67c:	call   8238c0 <<alloc::vec::Vec<u32>>::resize>
  81f681:	mov    0x8(%rsp),%rax
  81f686:	mov    0x10(%rax),%rax
  81f68a:	mov    %rax,0x20(%rsp)
  81f68f:	mov    0x70(%rsp),%rax
  81f694:	mov    %rax,0x330(%rsp)
  81f69c:	mov    0x28(%rsp),%rax
  81f6a1:	mov    %rax,0x338(%rsp)
  81f6a9:	movq   $0x0,0x340(%rsp)
  81f6b5:	mov    0x60(%rsp),%rax
  81f6ba:	mov    %rax,0x348(%rsp)
  81f6c2:	mov    0x328(%rsp),%rax
  81f6ca:	mov    %rax,0x350(%rsp)
  81f6d2:	mov    0xac(%rsp),%eax
  81f6d9:	mov    %eax,0x358(%rsp)
  81f6e0:	lea    0x288(%rsp),%rdi
  81f6e8:	lea    0x338(%rsp),%rsi
  81f6f0:	call   *0x661aea(%rip)        # e811e0 <_DYNAMIC+0x5c8>
  81f6f6:	mov    0x288(%rsp),%rax
  81f6fe:	mov    %rax,0x210(%rsp)
  81f706:	test   %rax,%rax
  81f709:	je     81fd43 <<gpui_gpu::renderer::RendererState>::render+0x1d23>
  81f70f:	mov    0x8(%rsp),%rax
  81f714:	add    $0x120,%rax
  81f71a:	mov    %rax,0x268(%rsp)
  81f722:	jmp    81f76d <<gpui_gpu::renderer::RendererState>::render+0x174d>
  81f724:	mov    0x20(%rsp),%rcx
  81f729:	lea    -0x5(%rcx),%rax
  81f72d:	cmpb   $0x0,0x220(%rsp)
  81f735:	cmovne %rax,%rcx
  81f739:	mov    %rcx,0x20(%rsp)
  81f73e:	lea    0x288(%rsp),%rdi
  81f746:	lea    0x338(%rsp),%rsi
  81f74e:	call   *0x661a8c(%rip)        # e811e0 <_DYNAMIC+0x5c8>
  81f754:	mov    0x288(%rsp),%rax
  81f75c:	mov    %rax,0x210(%rsp)
  81f764:	test   %rax,%rax
  81f767:	je     81fd43 <<gpui_gpu::renderer::RendererState>::render+0x1d23>
  81f76d:	mov    0x290(%rsp),%rdi
  81f775:	mov    0x298(%rsp),%r8
  81f77d:	mov    %r8,0x30(%rsp)
  81f782:	lea    0x2a0(%rsp),%rcx
  81f78a:	movups (%rcx),%xmm0
  81f78d:	movups 0x10(%rcx),%xmm1
  81f791:	movups 0x20(%rcx),%xmm2
  81f795:	movaps %xmm2,0x3b0(%rsp)
  81f79d:	movaps %xmm1,0x3a0(%rsp)
  81f7a5:	movaps %xmm0,0x390(%rsp)
  81f7ad:	lea    0x2d0(%rsp),%rdx
  81f7b5:	movups (%rdx),%xmm0
  81f7b8:	movaps %xmm0,0x450(%rsp)
  81f7c0:	movups 0x40(%rcx),%xmm0
  81f7c4:	movaps %xmm0,0x380(%rsp)
  81f7cc:	mov    0x8(%rsp),%rax
  81f7d1:	movzbl 0x341(%rax),%esi
  81f7d8:	mov    0x210(%rsp),%rax
  81f7e0:	mov    %rax,0x120(%rsp)
  81f7e8:	mov    %rdi,0x420(%rsp)
  81f7f0:	mov    %rdi,0x128(%rsp)
  81f7f8:	mov    %r8,0x130(%rsp)
  81f800:	movups (%rcx),%xmm0
  81f803:	movups 0x10(%rcx),%xmm1
  81f807:	movups 0x20(%rcx),%xmm2
  81f80b:	lea    0x138(%rsp),%rax
  81f813:	movups %xmm2,0x20(%rax)
  81f817:	movups %xmm1,0x10(%rax)
  81f81b:	movups %xmm0,(%rax)
  81f81e:	movups (%rdx),%xmm0
  81f821:	movups %xmm0,0x30(%rax)
  81f825:	movdqu 0x40(%rcx),%xmm0
  81f82a:	movdqu %xmm0,0x40(%rax)
  81f82f:	lea    0x120(%rsp),%rdi
  81f837:	call   821710 <gpui_gpu::renderer::compact_group>
  81f83c:	mov    %al,0x220(%rsp)
  81f843:	mov    0x30(%rsp),%rax
  81f848:	test   %rax,%rax
  81f84b:	je     81f724 <<gpui_gpu::renderer::RendererState>::render+0x1704>
  81f851:	mov    %rax,%rdx
  81f854:	shl    $0x2,%rdx
  81f858:	movzbl 0x220(%rsp),%eax
  81f860:	lea    0x0(,%rax,4),%esi
  81f867:	or     $0xfffffffffffffffa,%rsi
  81f86b:	xor    $0x1,%al
  81f86d:	movzbl %al,%eax
  81f870:	lea    0x1(,%rax,4),%rcx
  81f878:	mov    %rcx,0x260(%rsp)
  81f880:	mov    0x20(%rsp),%rcx
  81f885:	lea    (%rsi,%rcx,1),%edi
  81f888:	lea    (%rsi,%rax,4),%rax
  81f88c:	inc    %rax
  81f88f:	mov    %rax,0x410(%rsp)
  81f897:	add    %rax,%rcx
  81f89a:	shl    $0x4,%rcx
  81f89e:	mov    %rsi,0x40(%rsp)
  81f8a3:	shl    $0x4,%rsi
  81f8a7:	mov    %rsi,0x400(%rsp)
  81f8af:	mov    %rcx,0x18(%rsp)
  81f8b4:	mov    %edi,0x10(%rsp)
  81f8b8:	mov    0x420(%rsp),%rax
  81f8c0:	mov    %rdx,0x30(%rsp)
  81f8c5:	mov    -0x4(%rax,%rdx,1),%edx
  81f8c9:	lea    0x120(%rsp),%rdi
  81f8d1:	mov    0x210(%rsp),%rsi
  81f8d9:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f8de:	movzbl 0x120(%rsp),%ecx
  81f8e6:	movzbl 0x121(%rsp),%eax
  81f8ee:	mov    %al,0x60(%rsp)
  81f8f2:	movzwl 0x122(%rsp),%eax
  81f8fa:	mov    %ax,0x80(%rsp)
  81f902:	movss  0x124(%rsp),%xmm4
  81f90b:	lea    0x128(%rsp),%rdx
  81f913:	mov    0x10(%rdx),%rax
  81f917:	mov    %rax,0x370(%rsp)
  81f91f:	movups (%rdx),%xmm0
  81f922:	movaps %xmm0,0x360(%rsp)
  81f92a:	mov    0x140(%rsp),%rax
  81f932:	mov    %rax,0x28(%rsp)
  81f937:	mov    0x148(%rsp),%r10d
  81f93f:	mov    0x14c(%rsp),%r11d
  81f947:	movups 0x150(%rsp),%xmm0
  81f94f:	movaps %xmm0,0xb0(%rsp)
  81f957:	mov    0x150(%rsp),%rax
  81f95f:	movsd  0x160(%rsp),%xmm5
  81f968:	lea    0x138(%rsp),%rdx
  81f970:	movups 0x30(%rdx),%xmm0
  81f974:	movaps %xmm0,0x430(%rsp)
  81f97c:	decq   0x330(%rsp)
  81f984:	cmp    $0x1,%ecx
  81f987:	mov    %ecx,0xd0(%rsp)
  81f98e:	movaps %xmm5,0x90(%rsp)
  81f996:	je     81fa2c <<gpui_gpu::renderer::RendererState>::render+0x1a0c>
  81f99c:	mov    %r11d,0x68(%rsp)
  81f9a1:	mov    %r10d,0xf0(%rsp)
  81f9a9:	movaps %xmm4,0x230(%rsp)
  81f9b1:	cmp    $0x3,%ecx
  81f9b4:	jne    81faa9 <<gpui_gpu::renderer::RendererState>::render+0x1a89>
  81f9ba:	mov    0x270(%rsp),%rax
  81f9c2:	mov    (%rax),%rdi
  81f9c5:	test   %rdi,%rdi
  81f9c8:	je     8204c9 <<gpui_gpu::renderer::RendererState>::render+0x24a9>
  81f9ce:	movzbl 0x60(%rsp),%edx
  81f9d3:	mov    0x28(%rsp),%rsi
  81f9d8:	call   8236a0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f9dd:	mov    %eax,%ecx
  81f9df:	shr    $0x20,%rax
  81f9e3:	mov    %eax,%edx
  81f9e5:	or     $0x10,%edx
  81f9e8:	xorps  %xmm0,%xmm0
  81f9eb:	movaps 0x230(%rsp),%xmm4
  81f9f3:	ucomiss %xmm0,%xmm4
  81f9f6:	cmovne %edx,%eax
  81f9f9:	cmovp  %edx,%eax
  81f9fc:	mov    0x68(%rsp),%r11d
  81fa01:	mov    %r11d,%edx
  81fa04:	shl    $0x10,%edx
  81fa07:	mov    0xf0(%rsp),%r10d
  81fa0f:	or     %r10d,%edx
  81fa12:	mov    %ecx,0xe4(%rsp)
  81fa19:	mov    %eax,0xe8(%rsp)
  81fa20:	mov    %edx,0xec(%rsp)
  81fa27:	jmp    81fb5b <<gpui_gpu::renderer::RendererState>::render+0x1b3b>
  81fa2c:	movaps %xmm5,%xmm0
  81fa2f:	movss  -0x770a6b(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81fa37:	mulss  %xmm3,%xmm0
  81fa3b:	movaps %xmm4,%xmm1
  81fa3e:	minss  %xmm0,%xmm1
  81fa42:	movaps %xmm1,%xmm0
  81fa45:	cmpunordss %xmm1,%xmm0
  81fa4a:	movaps %xmm0,%xmm2
  81fa4d:	andnps %xmm1,%xmm2
  81fa50:	andps  %xmm4,%xmm0
  81fa53:	orps   %xmm2,%xmm0
  81fa56:	movaps %xmm5,%xmm1
  81fa59:	shufps $0x55,%xmm5,%xmm1
  81fa5d:	mulss  %xmm3,%xmm1
  81fa61:	movaps %xmm0,%xmm2
  81fa64:	minss  %xmm1,%xmm2
  81fa68:	movaps %xmm2,%xmm1
  81fa6b:	cmpunordss %xmm2,%xmm1
  81fa70:	andps  %xmm1,%xmm0
  81fa73:	andnps %xmm2,%xmm1
  81fa76:	orps   %xmm0,%xmm1
  81fa79:	movd   %xmm1,%eax
  81fa7d:	and    $0xff800000,%eax
  81fa82:	mov    $0x7f000000,%ecx
  81fa87:	sub    %eax,%ecx
  81fa89:	movl   $0x40000000,0xe4(%rsp)
  81fa94:	movss  %xmm1,0xe8(%rsp)
  81fa9d:	mov    %ecx,0xec(%rsp)
  81faa4:	jmp    81fb5b <<gpui_gpu::renderer::RendererState>::render+0x1b3b>
  81faa9:	cmp    $0x2,%cl
  81faac:	jne    81fafe <<gpui_gpu::renderer::RendererState>::render+0x1ade>
  81faae:	mov    0x370(%rsp),%rcx
  81fab6:	mov    %rcx,0x130(%rsp)
  81fabe:	movaps 0x360(%rsp),%xmm0
  81fac6:	movaps %xmm0,0x120(%rsp)
  81face:	mov    0x28(%rsp),%rcx
  81fad3:	mov    %rcx,0x138(%rsp)
  81fadb:	mov    0xf0(%rsp),%ecx
  81fae2:	mov    %ecx,0x140(%rsp)
  81fae9:	mov    0x68(%rsp),%ecx
  81faed:	mov    %ecx,0x144(%rsp)
  81faf4:	mov    %rax,0x148(%rsp)
  81fafc:	jmp    81fb0a <<gpui_gpu::renderer::RendererState>::render+0x1aea>
  81fafe:	movq   $0x0,0x120(%rsp)
  81fb0a:	movl   $0x0,0x2f8(%rsp)
  81fb15:	movq   $0x0,0x2f0(%rsp)
  81fb21:	lea    0xe4(%rsp),%rdi
  81fb29:	lea    0x120(%rsp),%rsi
  81fb31:	lea    0x2f0(%rsp),%rdx
  81fb39:	mov    0x268(%rsp),%rcx
  81fb41:	call   81b640 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fb46:	movaps 0x230(%rsp),%xmm4
  81fb4e:	mov    0xf0(%rsp),%r10d
  81fb56:	mov    0x68(%rsp),%r11d
  81fb5b:	mov    0x20(%rsp),%rdx
  81fb60:	mov    0x410(%rsp),%rax
  81fb68:	lea    (%rax,%rdx,1),%rcx
  81fb6c:	mov    0x8(%rsp),%rax
  81fb71:	mov    0x10(%rax),%rsi
  81fb75:	cmp    %rsi,%rcx
  81fb78:	lea    0x120(%rsp),%rdi
  81fb80:	mov    0x10(%rsp),%r8d
  81fb85:	mov    0x18(%rsp),%r9
  81fb8a:	movapd 0x90(%rsp),%xmm3
  81fb93:	jae    8204d6 <<gpui_gpu::renderer::RendererState>::render+0x24b6>
  81fb99:	add    0x40(%rsp),%rdx
  81fb9e:	mov    %rdx,0x20(%rsp)
  81fba3:	mov    0x8(%rax),%rax
  81fba7:	mov    0xec(%rsp),%ecx
  81fbae:	mov    %ecx,0x8(%rax,%r9,1)
  81fbb3:	mov    0xe4(%rsp),%rcx
  81fbbb:	mov    %r8d,%edx
  81fbbe:	or     $0x80000000,%edx
  81fbc4:	cmpb   $0x0,0x220(%rsp)
  81fbcc:	cmovne %r8d,%edx
  81fbd0:	mov    %rcx,(%rax,%r9,1)
  81fbd4:	mov    %edx,0x284(%rsp)
  81fbdb:	movaps 0x390(%rsp),%xmm0
  81fbe3:	movaps 0x3a0(%rsp),%xmm1
  81fbeb:	movaps 0x3b0(%rsp),%xmm2
  81fbf3:	lea    0x138(%rsp),%rax
  81fbfb:	movups %xmm2,0x50(%rax)
  81fbff:	movups %xmm1,0x40(%rax)
  81fc03:	movups %xmm0,0x30(%rax)
  81fc07:	movaps 0x450(%rsp),%xmm0
  81fc0f:	movups %xmm0,0x60(%rax)
  81fc13:	movaps 0x380(%rsp),%xmm0
  81fc1b:	movups %xmm0,0x80(%rax)
  81fc22:	movlpd %xmm3,0x160(%rsp)
  81fc2b:	movaps 0x430(%rsp),%xmm0
  81fc33:	movups %xmm0,0x70(%rax)
  81fc37:	mov    0xd0(%rsp),%eax
  81fc3e:	mov    %al,0x120(%rsp)
  81fc45:	movzbl 0x60(%rsp),%eax
  81fc4a:	mov    %al,0x121(%rsp)
  81fc51:	movzwl 0x80(%rsp),%eax
  81fc59:	mov    %ax,0x122(%rsp)
  81fc61:	movss  %xmm4,0x124(%rsp)
  81fc6a:	mov    0x370(%rsp),%rax
  81fc72:	lea    0x128(%rsp),%rcx
  81fc7a:	mov    %rax,0x10(%rcx)
  81fc7e:	movaps 0x360(%rsp),%xmm0
  81fc86:	movups %xmm0,(%rcx)
  81fc89:	mov    0x28(%rsp),%rax
  81fc8e:	mov    %rax,0x140(%rsp)
  81fc96:	mov    %r10d,0x148(%rsp)
  81fc9e:	mov    %r11d,0x14c(%rsp)
  81fca6:	movdqa 0xb0(%rsp),%xmm0
  81fcaf:	movdqu %xmm0,0x150(%rsp)
  81fcb8:	mov    0x480(%rsp),%rax
  81fcc0:	mov    %rax,0x2f0(%rsp)
  81fcc8:	mov    0x3f0(%rsp),%rax
  81fcd0:	mov    %rax,0x2f8(%rsp)
  81fcd8:	mov    0x478(%rsp),%rax
  81fce0:	mov    %rax,0x300(%rsp)
  81fce8:	lea    0x330(%rsp),%rax
  81fcf0:	mov    %rax,0x308(%rsp)
  81fcf8:	lea    0x284(%rsp),%rax
  81fd00:	mov    %rax,0x310(%rsp)
  81fd08:	mov    0x38(%rsp),%rsi
  81fd0d:	lea    0x2f0(%rsp),%rdx
  81fd15:	call   81c500 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81fd1a:	mov    0x18(%rsp),%rcx
  81fd1f:	mov    0x10(%rsp),%edi
  81fd23:	add    0x40(%rsp),%edi
  81fd27:	add    0x400(%rsp),%rcx
  81fd2f:	mov    0x30(%rsp),%rdx
  81fd34:	add    $0xfffffffffffffffc,%rdx
  81fd38:	jne    81f8af <<gpui_gpu::renderer::RendererState>::render+0x188f>
  81fd3e:	jmp    81f724 <<gpui_gpu::renderer::RendererState>::render+0x1704>
  81fd43:	mov    0x8(%rsp),%rax
  81fd48:	mov    0x28(%rax),%rdi
  81fd4c:	movq   $0x0,0x20(%rsp)
  81fd55:	test   %rdi,%rdi
  81fd58:	je     81fe69 <<gpui_gpu::renderer::RendererState>::render+0x1e49>
  81fd5e:	mov    0x8(%rsp),%rax
  81fd63:	mov    0x20(%rax),%rax
  81fd67:	mov    %rax,0x10(%rsp)
  81fd6c:	shl    $0x3,%rdi
  81fd70:	cmpl   $0x0,0x38(%rsp)
  81fd75:	je     820475 <<gpui_gpu::renderer::RendererState>::render+0x2455>
  81fd7b:	movq   $0x0,0x28(%rsp)
  81fd84:	movq   $0x0,0x60(%rsp)
  81fd8d:	movq   $0x0,0x18(%rsp)
  81fd96:	xor    %r10d,%r10d
  81fd99:	xor    %ecx,%ecx
  81fd9b:	jmp    81fdc0 <<gpui_gpu::renderer::RendererState>::render+0x1da0>
  81fd9d:	incq   0x18(%rsp)
  81fda2:	inc    %r10
  81fda5:	cmp    0x38(%rsp),%r10
  81fdaa:	mov    $0x0,%eax
  81fdaf:	cmove  %rax,%r10
  81fdb3:	inc    %rcx
  81fdb6:	add    $0xfffffffffffffff8,%rdi
  81fdba:	je     81fe84 <<gpui_gpu::renderer::RendererState>::render+0x1e64>
  81fdc0:	mov    0x10(%rsp),%rax
  81fdc5:	mov    0x4(%rax,%rcx,8),%r11d
  81fdca:	mov    $0x80000000,%eax
  81fdcf:	cmp    %rax,%r11
  81fdd2:	je     81fd9d <<gpui_gpu::renderer::RendererState>::render+0x1d7d>
  81fdd4:	mov    %r11d,%esi
  81fdd7:	and    $0x1fffffff,%esi
  81fddd:	mov    0x10(%rsp),%rax
  81fde2:	sub    (%rax,%rcx,8),%esi
  81fde5:	je     81fda2 <<gpui_gpu::renderer::RendererState>::render+0x1d82>
  81fde7:	mov    %rcx,%rax
  81fdea:	shr    $0x20,%rax
  81fdee:	je     81fdff <<gpui_gpu::renderer::RendererState>::render+0x1ddf>
  81fdf0:	mov    %rcx,%rax
  81fdf3:	xor    %edx,%edx
  81fdf5:	divq   0x38(%rsp)
  81fdfa:	mov    %r10,%rdx
  81fdfd:	jmp    81fe07 <<gpui_gpu::renderer::RendererState>::render+0x1de7>
  81fdff:	mov    %ecx,%eax
  81fe01:	xor    %edx,%edx
  81fe03:	divl   0x38(%rsp)
  81fe07:	shl    $0x4,%edx
  81fe0a:	shl    $0x4,%eax
  81fe0d:	lea    0x10(%rdx),%r8d
  81fe11:	cmp    %r8d,%r14d
  81fe14:	cmovb  %r14d,%r8d
  81fe18:	lea    0x10(%rax),%r9d
  81fe1c:	cmp    %r9d,%r15d
  81fe1f:	cmovb  %r15d,%r9d
  81fe23:	sub    %edx,%r8d
  81fe26:	sub    %eax,%r9d
  81fe29:	imul   %r8d,%r9d
  81fe2d:	mov    %r9,%rax
  81fe30:	shl    $0x4,%rax
  81fe34:	test   $0x40000000,%r11d
  81fe3b:	cmovne %r9,%rax
  81fe3f:	shr    $0x1d,%r11d
  81fe43:	and    $0x1,%r11d
  81fe47:	add    %rax,0x60(%rsp)
  81fe4c:	imul   %r11,%r9
  81fe50:	sub    %r11,%rsi
  81fe53:	imul   %rax,%rsi
  81fe57:	add    0x28(%rsp),%r9
  81fe5c:	add    %rsi,%r9
  81fe5f:	mov    %r9,0x28(%rsp)
  81fe64:	jmp    81fda2 <<gpui_gpu::renderer::RendererState>::render+0x1d82>
  81fe69:	movq   $0x0,0x18(%rsp)
  81fe72:	movq   $0x0,0x60(%rsp)
  81fe7b:	movq   $0x0,0x28(%rsp)
  81fe84:	test   $0x1,%r13b
  81fe88:	je     81feda <<gpui_gpu::renderer::RendererState>::render+0x1eba>
  81fe8a:	movd   0x280(%rsp),%xmm0
  81fe93:	movd   %xmm0,%eax
  81fe97:	test   %eax,%eax
  81fe99:	setns  %cl
  81fe9c:	mov    %eax,%edx
  81fe9e:	and    $0x7fffffff,%edx
  81fea4:	add    $0xff800000,%edx
  81feaa:	cmp    $0x7f000000,%edx
  81feb0:	setb   %dl
  81feb3:	and    %cl,%dl
  81feb5:	dec    %eax
  81feb7:	cmp    $0x7fffff,%eax
  81febc:	setb   %al
  81febf:	or     %dl,%al
  81fec1:	mov    $0x2,%eax
  81fec6:	mov    %rax,0x20(%rsp)
  81fecb:	movd   %xmm0,0xe0(%rsp)
  81fed4:	je     82046b <<gpui_gpu::renderer::RendererState>::render+0x244b>
  81feda:	mov    0x110(%rsp),%r13
  81fee2:	lea    0x18(%r13),%rax
  81fee6:	mov    %rax,0x30(%rsp)
  81feeb:	mov    0x118(%rsp),%rax
  81fef3:	add    $0x18,%rax
  81fef7:	xor    %ecx,%ecx
  81fef9:	cmp    $0x28,%r12d
  81fefd:	sete   %cl
  81ff00:	and    $0x1,%ebp
  81ff03:	lea    0x0(%rbp,%rcx,4),%ecx
  81ff07:	or     0x20(%rsp),%ecx
  81ff0b:	movups (%rax),%xmm0
  81ff0e:	movups %xmm0,0x298(%rsp)
  81ff16:	mov    %r14d,0x288(%rsp)
  81ff1e:	mov    %r15d,0x28c(%rsp)
  81ff26:	mov    0x38(%rsp),%rax
  81ff2b:	mov    %eax,0x290(%rsp)
  81ff32:	mov    %ecx,0x294(%rsp)
  81ff39:	movss  0xe0(%rsp),%xmm0
  81ff42:	movss  %xmm0,0x2a8(%rsp)
  81ff4b:	movq   $0x0,0x2ac(%rsp)
  81ff57:	movl   $0x0,0x2b4(%rsp)
  81ff62:	mov    0x8(%rsp),%rbp
  81ff67:	lea    0x230(%rbp),%rsi
  81ff6e:	movq   $0x0,0x10(%rsp)
  81ff77:	lea    0x288(%rsp),%rcx
  81ff7f:	mov    $0x30,%r8d
  81ff85:	mov    0xc0(%rsp),%r12
  81ff8d:	mov    %r12,%rdi
  81ff90:	mov    %rsi,0x38(%rsp)
  81ff95:	xor    %edx,%edx
  81ff97:	call   *0x66124b(%rip)        # e811e8 <_DYNAMIC+0x5d0>
  81ff9d:	mov    0x8(%rbp),%rcx
  81ffa1:	mov    0x10(%rbp),%r8
  81ffa5:	shl    $0x4,%r8
  81ffa9:	mov    0x108(%rsp),%rdi
  81ffb1:	mov    %r13,%rsi
  81ffb4:	mov    %r12,%rdx
  81ffb7:	call   81cb60 <<gpui_gpu::renderer::Buffer>::write>
  81ffbc:	lea    0x280(%rbp),%rdi
  81ffc3:	mov    0x20(%rbp),%rcx
  81ffc7:	mov    0x28(%rbp),%r8
  81ffcb:	shl    $0x3,%r8
  81ffcf:	mov    %rdi,0x20(%rsp)
  81ffd4:	mov    %r13,%rsi
  81ffd7:	mov    %r12,%rdx
  81ffda:	call   81cb60 <<gpui_gpu::renderer::Buffer>::write>
  81ffdf:	lea    0x2a8(%rbp),%rdi
  81ffe6:	mov    0x38(%rbp),%rcx
  81ffea:	mov    0x40(%rbp),%r8
  81ffee:	shl    $0x2,%r8
  81fff2:	mov    %rdi,0x40(%rsp)
  81fff7:	mov    %r13,%rsi
  81fffa:	mov    %r12,%rdx
  81fffd:	call   81cb60 <<gpui_gpu::renderer::Buffer>::write>
  820002:	lea    0x2d0(%rbp),%rdi
  820009:	mov    0x68(%rbp),%rcx
  82000d:	mov    0x70(%rbp),%r8
  820011:	shl    $0x5,%r8
  820015:	mov    %rdi,0x90(%rsp)
  82001d:	mov    %r13,%rsi
  820020:	mov    %r12,%rdx
  820023:	call   81cb60 <<gpui_gpu::renderer::Buffer>::write>
  820028:	cmpq   $0x0,0x328(%rbp)
  820030:	jne    82004c <<gpui_gpu::renderer::RendererState>::render+0x202c>
  820032:	mov    0x8(%rsp),%rax
  820037:	mov    0x10(%rax),%rax
  82003b:	cmp    $0x1,%rax
  82003f:	adc    $0x0,%rax
  820043:	shl    $0x4,%rax
  820047:	mov    %rax,0x10(%rsp)
  82004c:	mov    0x8(%rsp),%rsi
  820051:	mov    0x28(%rsi),%rdx
  820055:	mov    0x40(%rsi),%rax
  820059:	cmp    $0x1,%rdx
  82005d:	adc    $0x0,%rdx
  820061:	shl    $0x3,%rdx
  820065:	cmp    $0x1,%rax
  820069:	adc    $0x0,%rax
  82006d:	mov    0x70(%rsi),%rcx
  820071:	cmp    $0x1,%rcx
  820075:	adc    $0x0,%rcx
  820079:	add    $0xc8,%rsi
  820080:	shl    $0x2,%rax
  820084:	shl    $0x5,%rcx
  820088:	movq   $0x0,0x120(%rsp)
  820094:	mov    0x38(%rsp),%rdi
  820099:	mov    %rdi,0x128(%rsp)
  8200a1:	movq   $0x0,0x148(%rsp)
  8200ad:	xorps  %xmm0,%xmm0
  8200b0:	movups %xmm0,0x130(%rsp)
  8200b8:	movl   $0x0,0x140(%rsp)
  8200c3:	mov    0x108(%rsp),%rdi
  8200cb:	mov    %rdi,0x150(%rsp)
  8200d3:	movq   $0x0,0x158(%rsp)
  8200df:	mov    0x10(%rsp),%rdi
  8200e4:	mov    %rdi,0x160(%rsp)
  8200ec:	movl   $0x1,0x168(%rsp)
  8200f7:	movq   $0x0,0x170(%rsp)
  820103:	mov    0x20(%rsp),%rdi
  820108:	mov    %rdi,0x178(%rsp)
  820110:	movq   $0x0,0x180(%rsp)
  82011c:	mov    %rdx,0x188(%rsp)
  820124:	movl   $0x2,0x190(%rsp)
  82012f:	movq   $0x0,0x198(%rsp)
  82013b:	mov    0x40(%rsp),%rdx
  820140:	mov    %rdx,0x1a0(%rsp)
  820148:	movq   $0x0,0x1a8(%rsp)
  820154:	mov    %rax,0x1b0(%rsp)
  82015c:	movl   $0x3,0x1b8(%rsp)
  820167:	movq   $0x4,0x1c0(%rsp)
  820173:	mov    %rsi,0x1c8(%rsp)
  82017b:	movl   $0x4,0x1e0(%rsp)
  820186:	movq   $0x0,0x1e8(%rsp)
  820192:	mov    0x90(%rsp),%rax
  82019a:	mov    %rax,0x1f0(%rsp)
  8201a2:	movq   $0x0,0x1f8(%rsp)
  8201ae:	mov    %rcx,0x200(%rsp)
  8201b6:	movl   $0x5,0x208(%rsp)
  8201c1:	lea    -0x74b548(%rip),%rax        # d4c80 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  8201c8:	mov    %rax,0x3a8(%rsp)
  8201d0:	movq   $0xa,0x3b0(%rsp)
  8201dc:	mov    0x30(%rsp),%rax
  8201e1:	mov    %rax,0x390(%rsp)
  8201e9:	lea    0x120(%rsp),%rax
  8201f1:	mov    %rax,0x398(%rsp)
  8201f9:	movq   $0x6,0x3a0(%rsp)
  820205:	lea    0x390(%rsp),%rsi
  82020d:	mov    0x110(%rsp),%r12
  820215:	mov    %r12,%rdi
  820218:	call   *0x660fd2(%rip)        # e811f0 <_DYNAMIC+0x5d8>
  82021e:	mov    %rax,%r13
  820221:	mov    %rax,0x2f0(%rsp)
  820229:	lea    0x2f0(%rsp),%rdx
  820231:	mov    %r12,%rdi
  820234:	mov    0x470(%rsp),%rsi
  82023c:	call   81d1c0 <<gpui_gpu::renderer::GpuContext>::submit>
  820241:	mov    %rax,0x10(%rsp)
  820246:	xor    %ebp,%ebp
  820248:	mov    0x460(%rsp),%rax
  820250:	cmp    0x468(%rsp),%rax
  820258:	setne  %bpl
  82025c:	shl    $0x1f,%ebp
  82025f:	or     %r14d,%ebp
  820262:	shl    $0x20,%r15
  820266:	or     %r15,%rbp
  820269:	mov    (%rbx),%rax
  82026c:	test   %rax,%rax
  82026f:	je     820280 <<gpui_gpu::renderer::RendererState>::render+0x2260>
  820271:	lock decq (%rax)
  820275:	jne    820280 <<gpui_gpu::renderer::RendererState>::render+0x2260>
  820277:	mov    %rbx,%rdi
  82027a:	call   *0x660eb0(%rip)        # e81130 <_DYNAMIC+0x518>
  820280:	mov    0x8(%rsp),%rax
  820285:	mov    %r13,0x330(%rax)
  82028c:	mov    %rbp,0x338(%rax)
  820293:	mov    0x10(%rax),%r8
  820297:	mov    0x28(%rax),%rsi
  82029b:	mov    0x70(%rax),%rcx
  82029f:	mov    %rcx,0x38(%rsp)
  8202a4:	shl    $0x4,%r8
  8202a8:	mov    0x78(%rsp),%rdx
  8202ad:	lea    (%r8,%rdx,4),%rdi
  8202b1:	lea    (%rdi,%rsi,8),%rsi
  8202b5:	mov    %rcx,%rdi
  8202b8:	shl    $0x5,%rdi
  8202bc:	lea    (%rdi,%rsi,1),%rcx
  8202c0:	add    $0x30,%rcx
  8202c4:	mov    %rcx,0x20(%rsp)
  8202c9:	mov    0x278(%rax),%rdi
  8202d0:	add    0x250(%rax),%rdi
  8202d7:	add    0x2a0(%rax),%rdi
  8202de:	add    0x2c8(%rax),%rdi
  8202e5:	add    0x2f0(%rax),%rdi
  8202ec:	mov    0x308(%rax),%rsi
  8202f3:	add    0x310(%rax),%rsi
  8202fa:	mov    0x150(%rax),%r9d
  820301:	imul   %r9,%r9
  820305:	mov    0xc8(%rsp),%r11
  82030d:	mov    %r11,%rcx
  820310:	sub    %rdx,%rcx
  820313:	mov    0x70(%rsp),%r10
  820318:	mov    %r10,%r12
  82031b:	mov    0x250(%rsp),%rbp
  820323:	sub    %rbp,%r12
  820326:	mov    0x160(%rax),%rbx
  82032d:	inc    %rbx
  820330:	mov    $0xffffffffffffffff,%r14
  820337:	cmovne %rbx,%r14
  82033b:	mov    (%rax),%rbx
  82033e:	shl    $0x4,%rbx
  820342:	mov    0x48(%rax),%r15
  820346:	add    0x30(%rax),%r15
  82034a:	mov    0x18(%rax),%r13
  82034e:	lea    (%rbx,%r13,8),%rbx
  820352:	lea    (%rbx,%r15,4),%rbx
  820356:	mov    0x60(%rax),%r15
  82035a:	shl    $0x5,%r15
  82035e:	add    %rbx,%r15
  820361:	mov    0x138(%rax),%rbx
  820368:	mov    0x130(%rax),%r13
  82036f:	mov    %r14,0x160(%rax)
  820376:	mov    %r10,0x168(%rax)
  82037d:	lea    (%r11,%r11,1),%r14
  820381:	mov    %r14,0x170(%rax)
  820388:	movq   $0x1,0x178(%rax)
  820393:	mov    %r10,0x180(%rax)
  82039a:	mov    %rdx,0x188(%rax)
  8203a1:	mov    %r11,0x190(%rax)
  8203a8:	mov    %rcx,0x198(%rax)
  8203af:	mov    0x18(%rsp),%rcx
  8203b4:	mov    %rcx,0x1a0(%rax)
  8203bb:	mov    0x60(%rsp),%rcx
  8203c0:	mov    %rcx,0x1a8(%rax)
  8203c7:	mov    0x28(%rsp),%rcx
  8203cc:	mov    %rcx,0x1b0(%rax)
  8203d3:	mov    0x20(%rsp),%rcx
  8203d8:	mov    %rcx,0x1b8(%rax)
  8203df:	mov    %r8,0x1c0(%rax)
  8203e6:	mov    0x248(%rsp),%rdx
  8203ee:	mov    %rdx,0x1c8(%rax)
  8203f5:	mov    %rbp,0x1d0(%rax)
  8203fc:	mov    %r12,0x1d8(%rax)
  820403:	mov    0x258(%rsp),%rcx
  82040b:	mov    %rcx,0x1e0(%rax)
  820412:	mov    %rdi,0x1e8(%rax)
  820419:	mov    %r9,0x1f0(%rax)
  820420:	add    %rbx,%r13
  820423:	mov    %rbx,0x1f8(%rax)
  82042a:	mov    %r13,0x200(%rax)
  820431:	mov    %r15,0x208(%rax)
  820438:	mov    0x38(%rsp),%rcx
  82043d:	mov    %rcx,0x210(%rax)
  820444:	mov    %rsi,0x218(%rax)
  82044b:	movb   $0x0,0x220(%rax)
  820452:	mov    0x58(%rsp),%rdi
  820457:	mov    0x10(%rsp),%rax
  82045c:	mov    %rax,0x8(%rdi)
  820460:	movl   $0xffffffff,(%rdi)
  820466:	jmp    81e131 <<gpui_gpu::renderer::RendererState>::render+0x111>
  82046b:	mov    0x58(%rsp),%rdi
  820470:	jmp    81e123 <<gpui_gpu::renderer::RendererState>::render+0x103>
  820475:	movq   $0x0,0x60(%rsp)
  82047e:	xor    %eax,%eax
  820480:	movq   $0x0,0x18(%rsp)
  820489:	jmp    82049d <<gpui_gpu::renderer::RendererState>::render+0x247d>
  82048b:	incq   0x18(%rsp)
  820490:	add    $0x8,%rax
  820494:	cmp    %rax,%rdi
  820497:	je     81fe7b <<gpui_gpu::renderer::RendererState>::render+0x1e5b>
  82049d:	mov    0x10(%rsp),%rcx
  8204a2:	mov    0x4(%rcx,%rax,1),%ecx
  8204a6:	mov    %ecx,%edx
  8204a8:	neg    %edx
  8204aa:	jo     82048b <<gpui_gpu::renderer::RendererState>::render+0x246b>
  8204ac:	and    $0x1fffffff,%ecx
  8204b2:	mov    0x10(%rsp),%rdx
  8204b7:	cmp    %ecx,(%rdx,%rax,1)
  8204ba:	je     820490 <<gpui_gpu::renderer::RendererState>::render+0x2470>
  8204bc:	lea    0x60f38d(%rip),%rdi        # e2f850 <anon.93049d86f4da36fb5b5cebb14659314f.38.llvm.10732147056912049262>
  8204c3:	call   *0x660d2f(%rip)        # e811f8 <_DYNAMIC+0x5e0>
  8204c9:	lea    0x60f1b8(%rip),%rdi        # e2f688 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  8204d0:	call   *0x660d2a(%rip)        # e81200 <_DYNAMIC+0x5e8>
  8204d6:	mov    0x40(%rsp),%rdi
  8204db:	add    0x260(%rsp),%rdi
  8204e3:	add    %rdx,%rdi
  8204e6:	lea    0x60f1b3(%rip),%rdx        # e2f6a0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  8204ed:	call   *0x660c1d(%rip)        # e81110 <_DYNAMIC+0x4f8>
  8204f3:	lea    0x60f1be(%rip),%rdx        # e2f6b8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  8204fa:	call   *0x660c10(%rip)        # e81110 <_DYNAMIC+0x4f8>
  820500:	mov    %rax,%r14
  820503:	mov    0x8(%rsp),%rax
  820508:	mov    %r13,0x330(%rax)
  82050f:	mov    %rbp,0x338(%rax)
  820516:	mov    %r14,%rdi
  820519:	call   e2d970 <_Unwind_Resume@plt>
  82051e:	mov    %rax,%r14
  820521:	lock decq 0x0(%r13)
  820526:	jne    820548 <<gpui_gpu::renderer::RendererState>::render+0x2528>
  820528:	lea    0x2f0(%rsp),%rdi
  820530:	call   *0x660bfa(%rip)        # e81130 <_DYNAMIC+0x518>
  820536:	jmp    820548 <<gpui_gpu::renderer::RendererState>::render+0x2528>
  820538:	call   *0x66092a(%rip)        # e80e68 <_DYNAMIC+0x250>
  82053e:	mov    %rax,%r14
  820541:	movq   $0x0,(%rbx)
  820548:	mov    %r14,%rdi
  82054b:	call   e2d970 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4531 frame=840

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820550 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820550:	push   %rbp
  820551:	push   %r15
  820553:	push   %r14
  820555:	push   %r13
  820557:	push   %r12
  820559:	push   %rbx
  82055a:	sub    $0x318,%rsp
  820561:	movss  0x88(%rdx),%xmm3
  820569:	movss  -0x771555(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820571:	movaps %xmm3,%xmm1
  820574:	subss  %xmm0,%xmm1
  820578:	cvttss2si %xmm1,%rax
  82057d:	cvttss2si %xmm3,%r10
  820582:	mov    %r10,%rbp
  820585:	sar    $0x3f,%rbp
  820589:	and    %rax,%rbp
  82058c:	or     %r10,%rbp
  82058f:	xor    %eax,%eax
  820591:	xorps  %xmm1,%xmm1
  820594:	ucomiss %xmm1,%xmm3
  820597:	cmovb  %rax,%rbp
  82059b:	movss  0x90(%rdx),%xmm4
  8205a3:	movss  -0x77158b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8205ab:	ucomiss %xmm2,%xmm3
  8205ae:	mov    $0xffffffffffffffff,%r14
  8205b5:	cmova  %r14,%rbp
  8205b9:	movaps %xmm4,%xmm3
  8205bc:	subss  %xmm0,%xmm3
  8205c0:	cvttss2si %xmm3,%r10
  8205c5:	cvttss2si %xmm4,%r11
  8205ca:	mov    %r11,%rbx
  8205cd:	sar    $0x3f,%rbx
  8205d1:	and    %r10,%rbx
  8205d4:	or     %r11,%rbx
  8205d7:	ucomiss %xmm1,%xmm4
  8205da:	cmovb  %rax,%rbx
  8205de:	ucomiss %xmm2,%xmm4
  8205e1:	cmova  %r14,%rbx
  8205e5:	movss  0x8c(%rdx),%xmm3
  8205ed:	add    %rbp,%rbx
  8205f0:	dec    %rbx
  8205f3:	shr    $0x4,%rbx
  8205f7:	shr    $0x4,%rbp
  8205fb:	mov    %rbx,%r13
  8205fe:	sub    %rbp,%r13
  820601:	inc    %r13
  820604:	movaps %xmm3,%xmm4
  820607:	subss  %xmm0,%xmm4
  82060b:	cvttss2si %xmm4,%r11
  820610:	cvttss2si %xmm3,%r10
  820615:	mov    %r10,%r15
  820618:	sar    $0x3f,%r15
  82061c:	and    %r11,%r15
  82061f:	or     %r10,%r15
  820622:	ucomiss %xmm1,%xmm3
  820625:	cmovb  %rax,%r15
  820629:	ucomiss %xmm2,%xmm3
  82062c:	movss  0x94(%rdx),%xmm3
  820634:	cmova  %r14,%r15
  820638:	movaps %xmm3,%xmm4
  82063b:	subss  %xmm0,%xmm4
  82063f:	cvttss2si %xmm4,%r12
  820644:	cvttss2si %xmm3,%r10
  820649:	mov    %r10,%r11
  82064c:	sar    $0x3f,%r11
  820650:	and    %r12,%r11
  820653:	or     %r10,%r11
  820656:	ucomiss %xmm1,%xmm3
  820659:	cmovb  %rax,%r11
  82065d:	ucomiss %xmm2,%xmm3
  820660:	cmova  %r14,%r11
  820664:	mov    %r15,%r14
  820667:	lea    (%r15,%r11,1),%r10
  82066b:	dec    %r10
  82066e:	shr    $0x4,%r10
  820672:	shr    $0x4,%r14
  820676:	mov    %r10,%r12
  820679:	sub    %r14,%r12
  82067c:	inc    %r12
  82067f:	imul   %r13,%r12
  820683:	mov    0x368(%rsp),%r11
  82068b:	add    %r12,%r11
  82068e:	setb   %al
  820691:	cmp    $0x400001,%r11
  820698:	setae  %r15b
  82069c:	or     %al,%r15b
  82069f:	mov    $0x6,%eax
  8206a4:	jne    8207a6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x256>
  8206aa:	mov    %r12,0x1e8(%rsp)
  8206b2:	mov    %r11,0x198(%rsp)
  8206ba:	mov    %rdi,0x1a0(%rsp)
  8206c2:	cmpb   $0x0,(%rdx)
  8206c5:	sete   %al
  8206c8:	and    0x340(%rsi),%al
  8206ce:	movl   $0x0,0x4(%rsp)
  8206d6:	cmp    $0x1,%al
  8206d8:	jne    820768 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8206de:	movss  0xa4(%rdx),%xmm0
  8206e6:	ucomiss -0x77190d(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  8206ed:	jne    820768 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8206ef:	jp     820768 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8206f1:	mov    0x98(%rdx),%edi
  8206f7:	test   %edi,%edi
  8206f9:	jns    82070b <<gpui_gpu::renderer::RendererState>::bin_draw+0x1bb>
  8206fb:	and    $0x7f800000,%edi
  820701:	dec    %edi
  820703:	cmp    $0x7f7fffff,%edi
  820709:	jae    820760 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  82070b:	mov    0x9c(%rdx),%edi
  820711:	test   %edi,%edi
  820713:	jns    820725 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d5>
  820715:	and    $0x7f800000,%edi
  82071b:	dec    %edi
  82071d:	cmp    $0x7f7ffffe,%edi
  820723:	ja     820760 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  820725:	mov    0xa0(%rdx),%edi
  82072b:	test   %edi,%edi
  82072d:	jns    82073f <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ef>
  82072f:	and    $0x7f800000,%edi
  820735:	dec    %edi
  820737:	cmp    $0x7f7ffffe,%edi
  82073d:	ja     820760 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  82073f:	movd   %xmm0,%edi
  820743:	test   %edi,%edi
  820745:	jns    820757 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  820747:	and    $0x7f800000,%edi
  82074d:	dec    %edi
  82074f:	cmp    $0x7f7ffffe,%edi
  820755:	ja     820760 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  820757:	mov    $0x1,%dil
  82075a:	mov    %edi,0x4(%rsp)
  82075e:	jmp    820768 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  820760:	movl   $0x0,0x4(%rsp)
  820768:	mov    %rcx,0xe0(%rsp)
  820770:	mov    %r8d,0xbc(%rsp)
  820778:	mov    %r9,0xa8(%rsp)
  820780:	mov    %rdx,0xe8(%rsp)
  820788:	cmp    %r14,%r10
  82078b:	jae    8207ba <<gpui_gpu::renderer::RendererState>::bin_draw+0x26a>
  82078d:	mov    0x1a0(%rsp),%rdi
  820795:	mov    0x198(%rsp),%rax
  82079d:	mov    %rax,0x8(%rdi)
  8207a1:	mov    $0xffffffff,%eax
  8207a6:	mov    %eax,(%rdi)
  8207a8:	add    $0x318,%rsp
  8207af:	pop    %rbx
  8207b0:	pop    %r12
  8207b2:	pop    %r13
  8207b4:	pop    %r14
  8207b6:	pop    %r15
  8207b8:	pop    %rbp
  8207b9:	ret
  8207ba:	cmp    %rbp,%rbx
  8207bd:	jae    8207d6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  8207bf:	nop
  8207c0:	mov    %r14,%rax
  8207c3:	cmp    %r10,%r14
  8207c6:	adc    $0x0,%r14
  8207ca:	cmp    %r10,%rax
  8207cd:	jae    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8207cf:	cmp    %r10,%r14
  8207d2:	jbe    8207c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  8207d4:	jmp    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8207d6:	mov    0x350(%rsp),%r13
  8207de:	mov    0x20(%rsi),%r15
  8207e2:	mov    0x28(%rsi),%r9
  8207e6:	test   %al,%al
  8207e8:	je     821640 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  8207ee:	mov    0xe0(%rsp),%rax
  8207f6:	movd   %eax,%xmm0
  8207fa:	shr    $0x20,%rax
  8207fe:	mov    0xe8(%rsp),%rcx
  820806:	movss  0x78(%rcx),%xmm1
  82080b:	cvtss2sd %xmm1,%xmm12
  820810:	movss  0x80(%rcx),%xmm1
  820818:	movss  0x7c(%rcx),%xmm2
  82081d:	xorps  %xmm3,%xmm3
  820820:	cvtss2sd %xmm2,%xmm3
  820824:	movss  0x84(%rcx),%xmm2
  82082c:	cvtss2sd %xmm1,%xmm1
  820830:	addsd  %xmm12,%xmm1
  820835:	movsd  %xmm1,0x1d8(%rsp)
  82083e:	xorps  %xmm1,%xmm1
  820841:	cvtss2sd %xmm2,%xmm1
  820845:	movsd  %xmm3,0x1e0(%rsp)
  82084e:	addsd  %xmm3,%xmm1
  820852:	movsd  %xmm1,0x1c8(%rsp)
  82085b:	movsd  0x48(%rcx),%xmm3
  820860:	movsd  0x58(%rcx),%xmm4
  820865:	movsd  0x68(%rcx),%xmm5
  82086a:	movss  0x38(%rcx),%xmm1
  82086f:	movss  0x40(%rcx),%xmm2
  820874:	cvtss2sd %xmm1,%xmm1
  820878:	cvtss2sd %xmm2,%xmm2
  82087c:	movaps -0x775a53(%rip),%xmm6        # aae30 <GCC_except_table0+0x64>
  820883:	movaps %xmm1,0x90(%rsp)
  82088b:	andps  %xmm6,%xmm1
  82088e:	movaps %xmm1,0x80(%rsp)
  820896:	movaps %xmm2,0x60(%rsp)
  82089b:	andps  %xmm6,%xmm2
  82089e:	movaps %xmm2,0x70(%rsp)
  8208a3:	cvtss2sd %xmm0,%xmm0
  8208a7:	movsd  %xmm0,0x18(%rsp)
  8208ad:	movaps %xmm3,%xmm0
  8208b0:	andps  %xmm6,%xmm0
  8208b3:	movaps %xmm0,0x290(%rsp)
  8208bb:	movaps %xmm4,%xmm0
  8208be:	andps  %xmm6,%xmm0
  8208c1:	movaps %xmm0,0x270(%rsp)
  8208c9:	movaps %xmm5,%xmm0
  8208cc:	andps  %xmm6,%xmm0
  8208cf:	movaps %xmm0,0x130(%rsp)
  8208d7:	movss  0x3c(%rcx),%xmm0
  8208dc:	xorps  %xmm1,%xmm1
  8208df:	cvtss2sd %xmm0,%xmm1
  8208e3:	movss  0x44(%rcx),%xmm0
  8208e8:	cvtss2sd %xmm0,%xmm0
  8208ec:	movaps %xmm1,0x50(%rsp)
  8208f1:	andps  %xmm6,%xmm1
  8208f4:	movaps %xmm1,0x40(%rsp)
  8208f9:	movaps %xmm0,0x20(%rsp)
  8208fe:	andps  %xmm6,%xmm0
  820901:	movaps %xmm0,0x30(%rsp)
  820906:	movd   %eax,%xmm0
  82090a:	cvtss2sd %xmm0,%xmm0
  82090e:	movsd  %xmm0,0x10(%rsp)
  820914:	movsd  0x50(%rcx),%xmm1
  820919:	movaps %xmm1,%xmm0
  82091c:	andps  %xmm6,%xmm0
  82091f:	movaps %xmm0,0x210(%rsp)
  820927:	movsd  0x60(%rcx),%xmm2
  82092c:	movaps %xmm2,%xmm0
  82092f:	andps  %xmm6,%xmm0
  820932:	movaps %xmm0,0x1f0(%rsp)
  82093a:	movsd  0x70(%rcx),%xmm7
  82093f:	andps  %xmm7,%xmm6
  820942:	movaps %xmm6,0x100(%rsp)
  82094a:	mov    0x58(%rsi),%rax
  82094e:	mov    %rax,0xd8(%rsp)
  820956:	mov    0x50(%rsi),%rax
  82095a:	mov    %rax,0x1d0(%rsp)
  820962:	movaps %xmm3,0x2a0(%rsp)
  82096a:	movaps %xmm3,%xmm0
  82096d:	movaps %xmm4,0x280(%rsp)
  820975:	movlhps %xmm4,%xmm0
  820978:	cvtpd2ps %xmm0,%xmm0
  82097c:	movaps %xmm1,0x220(%rsp)
  820984:	cvtsd2ss %xmm1,%xmm1
  820988:	cvtss2sd %xmm1,%xmm1
  82098c:	cvtps2pd %xmm0,%xmm3
  82098f:	movaps %xmm2,0x200(%rsp)
  820997:	xorps  %xmm0,%xmm0
  82099a:	cvtsd2ss %xmm2,%xmm0
  82099e:	xorps  %xmm2,%xmm2
  8209a1:	cvtss2sd %xmm0,%xmm2
  8209a5:	movaps %xmm5,0x140(%rsp)
  8209ad:	xorps  %xmm0,%xmm0
  8209b0:	cvtsd2ss %xmm5,%xmm0
  8209b4:	cvtss2sd %xmm0,%xmm4
  8209b8:	movaps %xmm7,0xf0(%rsp)
  8209c0:	xorps  %xmm0,%xmm0
  8209c3:	cvtsd2ss %xmm7,%xmm0
  8209c7:	mov    0xa8(%rsp),%rax
  8209cf:	inc    %eax
  8209d1:	mov    %rax,0xa8(%rsp)
  8209d9:	cvtss2sd %xmm0,%xmm0
  8209dd:	movaps -0x775bb4(%rip),%xmm5        # aae30 <GCC_except_table0+0x64>
  8209e4:	movaps %xmm3,%xmm6
  8209e7:	andps  %xmm5,%xmm6
  8209ea:	movaps %xmm4,0x160(%rsp)
  8209f2:	andps  %xmm5,%xmm4
  8209f5:	movaps %xmm4,0x150(%rsp)
  8209fd:	movaps %xmm1,0x260(%rsp)
  820a05:	andps  %xmm5,%xmm1
  820a08:	movaps %xmm1,0x250(%rsp)
  820a10:	movaps %xmm2,0x240(%rsp)
  820a18:	andps  %xmm5,%xmm2
  820a1b:	movaps %xmm2,0x230(%rsp)
  820a23:	movaps %xmm0,0x120(%rsp)
  820a2b:	andps  %xmm0,%xmm5
  820a2e:	movaps %xmm5,0x110(%rsp)
  820a36:	movaps %xmm3,0x2c0(%rsp)
  820a3e:	movhlps %xmm3,%xmm3
  820a41:	movaps %xmm3,0x2f0(%rsp)
  820a49:	mov    $0x2,%r11b
  820a4c:	xor    %edx,%edx
  820a4e:	mov    %r14,%rax
  820a51:	movaps %xmm6,0x2b0(%rsp)
  820a59:	pshufd $0xee,%xmm6,%xmm0
  820a5e:	movdqa %xmm0,0x2e0(%rsp)
  820a67:	movsd  %xmm12,0x8(%rsp)
  820a6e:	mov    %rbp,0x1b0(%rsp)
  820a76:	mov    %r10,0x1a8(%rsp)
  820a7e:	xchg   %ax,%ax
  820a80:	cmp    %r10,%r14
  820a83:	adc    $0x0,%rax
  820a87:	mov    %rax,0x1b8(%rsp)
  820a8f:	mov    %r14,0x1c0(%rsp)
  820a97:	imul   %r13,%r14
  820a9b:	mov    %rbp,%r10
  820a9e:	mov    0x360(%rsp),%r8d
  820aa6:	mov    0x358(%rsp),%ecx
  820aad:	jmp    820ad0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820aaf:	cmp    %r9,%r12
  820ab2:	jae    8216a5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820ab8:	incl   0x4(%r15,%r12,8)
  820abd:	mov    $0x1,%dl
  820abf:	cmp    %rbx,%r10
  820ac2:	jb     820c93 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820ac8:	jmp    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820acd:	nopl   (%rax)
  820ad0:	cmp    %rbx,%r10
  820ad3:	adc    $0x0,%rbp
  820ad7:	lea    (%r10,%r14,1),%r12
  820adb:	cmpb   $0x0,0x4(%rsp)
  820ae0:	jne    820af7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a7>
  820ae2:	cmp    %r9,%r12
  820ae5:	jae    8216c5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1175>
  820aeb:	testb  $0x40,0x7(%r15,%r12,8)
  820af1:	je     820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820af7:	cmpq   $0x2,0x1e8(%rsp)
  820b00:	setae  %al
  820b03:	and    %dl,%al
  820b05:	cmp    $0x1,%al
  820b07:	jne    820be2 <<gpui_gpu::renderer::RendererState>::bin_draw+0x692>
  820b0d:	cmp    $0x2,%r11b
  820b11:	jne    820b7c <<gpui_gpu::renderer::RendererState>::bin_draw+0x62c>
  820b13:	mov    %r10,0xb0(%rsp)
  820b1b:	mov    0xe8(%rsp),%rdi
  820b23:	mov    0xe0(%rsp),%rsi
  820b2b:	mov    %r13,%rdx
  820b2e:	mov    %rbp,0xc0(%rsp)
  820b36:	mov    %rbx,%rbp
  820b39:	mov    %r14,%rbx
  820b3c:	mov    %r15,%r14
  820b3f:	mov    %r9,%r15
  820b42:	call   8268b0 <gpui_gpu::renderer::coverage::whole>
  820b47:	mov    0xb0(%rsp),%r10
  820b4f:	movsd  0x8(%rsp),%xmm12
  820b56:	mov    0x360(%rsp),%r8d
  820b5e:	mov    %r15,%r9
  820b61:	mov    %r14,%r15
  820b64:	mov    %rbx,%r14
  820b67:	mov    %rbp,%rbx
  820b6a:	mov    0xc0(%rsp),%rbp
  820b72:	mov    0x358(%rsp),%ecx
  820b79:	mov    %eax,%r11d
  820b7c:	test   $0x1,%r11b
  820b80:	mov    $0x1,%r11b
  820b83:	je     820bdf <<gpui_gpu::renderer::RendererState>::bin_draw+0x68f>
  820b85:	cmpb   $0x0,0x4(%rsp)
  820b8a:	je     820aaf <<gpui_gpu::renderer::RendererState>::bin_draw+0x55f>
  820b90:	cmp    %r9,%r12
  820b93:	jae    8216f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11a0>
  820b99:	mov    0xbc(%rsp),%eax
  820ba0:	mov    %eax,(%r15,%r12,8)
  820ba4:	movl   $0x40000001,0x4(%r15,%r12,8)
  820bad:	cmp    0xd8(%rsp),%r12
  820bb5:	jae    8216d8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1188>
  820bbb:	mov    0xa8(%rsp),%rax
  820bc3:	mov    0x1d0(%rsp),%rdx
  820bcb:	mov    %eax,(%rdx,%r12,4)
  820bcf:	mov    $0x1,%dl
  820bd1:	cmp    %rbx,%r10
  820bd4:	jb     820c93 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820bda:	jmp    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820bdf:	xor    %r11d,%r11d
  820be2:	test   %r13,%r13
  820be5:	je     8216b8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1168>
  820beb:	mov    %r12,%rax
  820bee:	shr    $0x20,%rax
  820bf2:	je     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b0>
  820bf4:	mov    %r12,%rax
  820bf7:	xor    %edx,%edx
  820bf9:	div    %r13
  820bfc:	jmp    820c08 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b8>
  820bfe:	xchg   %ax,%ax
  820c00:	mov    %r12d,%eax
  820c03:	xor    %edx,%edx
  820c05:	div    %r13d
  820c08:	shl    $0x4,%edx
  820c0b:	shl    $0x4,%eax
  820c0e:	lea    0x10(%rdx),%esi
  820c11:	cmp    %esi,%ecx
  820c13:	cmovb  %ecx,%esi
  820c16:	lea    0x10(%rax),%edi
  820c19:	cmp    %edi,%r8d
  820c1c:	cmovb  %r8d,%edi
  820c20:	xorps  %xmm2,%xmm2
  820c23:	cvtsi2sd %edx,%xmm2
  820c27:	mov    $0x1,%dl
  820c29:	ucomisd %xmm2,%xmm12
  820c2e:	ja     820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820c30:	mov    %eax,%eax
  820c32:	xorps  %xmm3,%xmm3
  820c35:	cvtsi2sd %rax,%xmm3
  820c3a:	movsd  0x1e0(%rsp),%xmm0
  820c43:	ucomisd %xmm3,%xmm0
  820c47:	ja     820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820c49:	xorps  %xmm0,%xmm0
  820c4c:	cvtsi2sd %esi,%xmm0
  820c50:	ucomisd 0x1d8(%rsp),%xmm0
  820c59:	ja     820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820c5b:	xorps  %xmm1,%xmm1
  820c5e:	cvtsi2sd %edi,%xmm1
  820c62:	ucomisd 0x1c8(%rsp),%xmm1
  820c6b:	jbe    820ca4 <<gpui_gpu::renderer::RendererState>::bin_draw+0x754>
  820c6d:	nopl   (%rax)
  820c70:	cmp    %r9,%r12
  820c73:	jae    8216a5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820c79:	mov    0x4(%r15,%r12,8),%eax
  820c7e:	inc    %eax
  820c80:	and    $0xbfffffff,%eax
  820c85:	mov    %eax,0x4(%r15,%r12,8)
  820c8a:	cmp    %rbx,%r10
  820c8d:	jae    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820c93:	mov    %rbp,%r10
  820c96:	cmp    %rbx,%rbp
  820c99:	jbe    820ad0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820c9f:	jmp    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820ca4:	unpcklpd %xmm3,%xmm2
  820ca8:	addpd  -0x773b70(%rip),%xmm2        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820cb0:	movapd %xmm2,%xmm3
  820cb4:	mulpd  0x2c0(%rsp),%xmm3
  820cbd:	movapd %xmm3,%xmm11
  820cc2:	unpckhpd %xmm3,%xmm11
  820cc7:	movapd %xmm3,%xmm5
  820ccb:	addsd  %xmm11,%xmm5
  820cd0:	addsd  0x160(%rsp),%xmm5
  820cd9:	subsd  0x90(%rsp),%xmm5
  820ce2:	movapd 0x2b0(%rsp),%xmm8
  820cec:	mulpd  %xmm2,%xmm8
  820cf1:	movapd %xmm8,%xmm4
  820cf6:	unpckhpd %xmm8,%xmm4
  820cfb:	movapd %xmm8,%xmm6
  820d00:	addsd  %xmm4,%xmm6
  820d04:	addsd  0x150(%rsp),%xmm6
  820d0d:	addsd  0x80(%rsp),%xmm6
  820d16:	addsd  0x70(%rsp),%xmm6
  820d1c:	addsd  -0x771444(%rip),%xmm6        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d24:	mulsd  -0x7714cc(%rip),%xmm6        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820d2c:	addsd  0x18(%rsp),%xmm6
  820d32:	ucomisd %xmm5,%xmm6
  820d36:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820d3c:	movapd 0x60(%rsp),%xmm7
  820d42:	subsd  %xmm5,%xmm7
  820d46:	ucomisd %xmm7,%xmm6
  820d4a:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820d50:	movapd %xmm2,%xmm13
  820d55:	unpckhpd %xmm2,%xmm13
  820d5a:	movapd 0x280(%rsp),%xmm15
  820d64:	mulsd  %xmm13,%xmm15
  820d69:	movapd 0x270(%rsp),%xmm14
  820d73:	mulsd  %xmm13,%xmm14
  820d78:	movapd 0x2a0(%rsp),%xmm5
  820d81:	mulsd  %xmm2,%xmm5
  820d85:	movapd %xmm5,%xmm6
  820d89:	addsd  %xmm15,%xmm6
  820d8e:	addsd  0x140(%rsp),%xmm6
  820d97:	subsd  0x90(%rsp),%xmm6
  820da0:	movapd 0x290(%rsp),%xmm7
  820da9:	mulsd  %xmm2,%xmm7
  820dad:	movapd %xmm7,%xmm9
  820db2:	addsd  %xmm14,%xmm9
  820db7:	addsd  0x130(%rsp),%xmm9
  820dc1:	addsd  0x80(%rsp),%xmm9
  820dcb:	addsd  0x70(%rsp),%xmm9
  820dd2:	addsd  -0x7714fb(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ddb:	mulsd  -0x770fa4(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820de4:	ucomisd %xmm6,%xmm9
  820de9:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820def:	movapd 0x60(%rsp),%xmm10
  820df6:	subsd  %xmm6,%xmm10
  820dfb:	ucomisd %xmm10,%xmm9
  820e00:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820e06:	movapd %xmm13,%xmm9
  820e0b:	mulsd  0x240(%rsp),%xmm9
  820e15:	movapd %xmm13,%xmm12
  820e1a:	mulsd  0x230(%rsp),%xmm12
  820e24:	movapd %xmm2,%xmm10
  820e29:	mulsd  0x260(%rsp),%xmm10
  820e33:	movapd %xmm10,%xmm6
  820e38:	movapd %xmm9,0xc0(%rsp)
  820e42:	addsd  %xmm9,%xmm6
  820e47:	addsd  0x120(%rsp),%xmm6
  820e50:	subsd  0x50(%rsp),%xmm6
  820e56:	movapd %xmm2,%xmm9
  820e5b:	mulsd  0x250(%rsp),%xmm9
  820e65:	movsd  %xmm9,0xb0(%rsp)
  820e6f:	addsd  %xmm12,%xmm9
  820e74:	addsd  0x110(%rsp),%xmm9
  820e7e:	addsd  0x40(%rsp),%xmm9
  820e85:	addsd  0x30(%rsp),%xmm9
  820e8c:	addsd  -0x7715b5(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e95:	mulsd  -0x77163e(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e9e:	addsd  0x10(%rsp),%xmm9
  820ea5:	ucomisd %xmm6,%xmm9
  820eaa:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820eb0:	movsd  %xmm10,0x190(%rsp)
  820eba:	movapd 0x20(%rsp),%xmm10
  820ec1:	subsd  %xmm6,%xmm10
  820ec6:	ucomisd %xmm10,%xmm9
  820ecb:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820ed1:	movapd 0x200(%rsp),%xmm9
  820edb:	mulsd  %xmm13,%xmm9
  820ee0:	mulsd  0x1f0(%rsp),%xmm13
  820eea:	movapd 0x220(%rsp),%xmm10
  820ef4:	mulsd  %xmm2,%xmm10
  820ef9:	movapd %xmm10,%xmm6
  820efe:	movapd %xmm9,0x170(%rsp)
  820f08:	addsd  %xmm9,%xmm6
  820f0d:	addsd  0xf0(%rsp),%xmm6
  820f16:	subsd  0x50(%rsp),%xmm6
  820f1c:	mulsd  0x210(%rsp),%xmm2
  820f25:	movapd %xmm2,%xmm9
  820f2a:	addsd  %xmm13,%xmm9
  820f2f:	addsd  0x100(%rsp),%xmm9
  820f39:	addsd  0x40(%rsp),%xmm9
  820f40:	addsd  0x30(%rsp),%xmm9
  820f47:	addsd  -0x771670(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f50:	mulsd  -0x771119(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f59:	ucomisd %xmm6,%xmm9
  820f5e:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820f64:	movapd %xmm10,0x300(%rsp)
  820f6e:	movapd 0x20(%rsp),%xmm10
  820f75:	subsd  %xmm6,%xmm10
  820f7a:	ucomisd %xmm10,%xmm9
  820f7f:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820f85:	addsd  -0x7719a5(%rip),%xmm0        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820f8d:	movapd %xmm0,%xmm9
  820f92:	mulsd  0x2c0(%rsp),%xmm9
  820f9c:	addsd  %xmm9,%xmm11
  820fa1:	addsd  0x160(%rsp),%xmm11
  820fab:	subsd  0x90(%rsp),%xmm11
  820fb5:	movapd 0x2b0(%rsp),%xmm10
  820fbf:	mulsd  %xmm0,%xmm10
  820fc4:	addsd  %xmm10,%xmm4
  820fc9:	addsd  0x150(%rsp),%xmm4
  820fd2:	addsd  0x80(%rsp),%xmm4
  820fdb:	addsd  0x70(%rsp),%xmm4
  820fe1:	addsd  -0x771709(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fe9:	mulsd  -0x771791(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ff1:	addsd  0x18(%rsp),%xmm4
  820ff7:	ucomisd %xmm11,%xmm4
  820ffc:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821002:	movapd 0x60(%rsp),%xmm6
  821008:	subsd  %xmm11,%xmm6
  82100d:	ucomisd %xmm6,%xmm4
  821011:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821017:	movapd 0x2a0(%rsp),%xmm6
  821020:	mulsd  %xmm0,%xmm6
  821024:	addsd  %xmm6,%xmm15
  821029:	addsd  0x140(%rsp),%xmm15
  821033:	subsd  0x90(%rsp),%xmm15
  82103d:	movapd 0x290(%rsp),%xmm11
  821047:	mulsd  %xmm0,%xmm11
  82104c:	addsd  %xmm11,%xmm14
  821051:	addsd  0x130(%rsp),%xmm14
  82105b:	addsd  0x80(%rsp),%xmm14
  821065:	addsd  0x70(%rsp),%xmm14
  82106c:	addsd  -0x771795(%rip),%xmm14        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821075:	mulsd  -0x77123e(%rip),%xmm14        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82107e:	ucomisd %xmm15,%xmm14
  821083:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821089:	movapd 0x60(%rsp),%xmm4
  82108f:	subsd  %xmm15,%xmm4
  821094:	ucomisd %xmm4,%xmm14
  821099:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  82109f:	movapd %xmm0,%xmm14
  8210a4:	mulsd  0x260(%rsp),%xmm14
  8210ae:	movapd 0xc0(%rsp),%xmm4
  8210b7:	addsd  %xmm14,%xmm4
  8210bc:	addsd  0x120(%rsp),%xmm4
  8210c5:	subsd  0x50(%rsp),%xmm4
  8210cb:	movapd %xmm0,%xmm15
  8210d0:	mulsd  0x250(%rsp),%xmm15
  8210da:	addsd  %xmm15,%xmm12
  8210df:	addsd  0x110(%rsp),%xmm12
  8210e9:	addsd  0x40(%rsp),%xmm12
  8210f0:	addsd  0x30(%rsp),%xmm12
  8210f7:	addsd  -0x771820(%rip),%xmm12        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821100:	mulsd  -0x7718a9(%rip),%xmm12        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821109:	addsd  0x10(%rsp),%xmm12
  821110:	ucomisd %xmm4,%xmm12
  821115:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  82111b:	movsd  %xmm15,0xc0(%rsp)
  821125:	movapd %xmm4,%xmm15
  82112a:	movapd 0x20(%rsp),%xmm4
  821130:	subsd  %xmm15,%xmm4
  821135:	ucomisd %xmm4,%xmm12
  82113a:	jae    8215ee <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821140:	movapd 0x220(%rsp),%xmm4
  821149:	mulsd  %xmm0,%xmm4
  82114d:	movapd 0x170(%rsp),%xmm15
  821157:	addsd  %xmm4,%xmm15
  82115c:	addsd  0xf0(%rsp),%xmm15
  821166:	subsd  0x50(%rsp),%xmm15
  82116d:	mulsd  0x210(%rsp),%xmm0
  821176:	addsd  %xmm0,%xmm13
  82117b:	addsd  0x100(%rsp),%xmm13
  821185:	addsd  0x40(%rsp),%xmm13
  82118c:	addsd  0x30(%rsp),%xmm13
  821193:	addsd  -0x7718bc(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82119c:	mulsd  -0x771365(%rip),%xmm13        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8211a5:	ucomisd %xmm15,%xmm13
  8211aa:	movsd  0x8(%rsp),%xmm12
  8211b1:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8211b7:	movapd %xmm4,0x170(%rsp)
  8211c0:	movapd 0x20(%rsp),%xmm4
  8211c6:	subsd  %xmm15,%xmm4
  8211cb:	ucomisd %xmm4,%xmm13
  8211d0:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8211d6:	movsd  %xmm10,0x188(%rsp)
  8211e0:	addsd  -0x771c00(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8211e8:	movapd %xmm1,%xmm10
  8211ed:	mulsd  0x2f0(%rsp),%xmm10
  8211f7:	movapd %xmm1,%xmm4
  8211fb:	mulsd  0x2e0(%rsp),%xmm4
  821204:	addsd  %xmm10,%xmm3
  821209:	addsd  0x160(%rsp),%xmm3
  821212:	subsd  0x90(%rsp),%xmm3
  82121b:	addsd  %xmm4,%xmm8
  821220:	addsd  0x150(%rsp),%xmm8
  82122a:	addsd  0x80(%rsp),%xmm8
  821234:	addsd  0x70(%rsp),%xmm8
  82123b:	addsd  -0x771964(%rip),%xmm8        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821244:	mulsd  -0x7719ed(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82124d:	addsd  0x18(%rsp),%xmm8
  821254:	ucomisd %xmm3,%xmm8
  821259:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82125f:	movapd %xmm6,0x2d0(%rsp)
  821268:	movapd 0x60(%rsp),%xmm6
  82126e:	subsd  %xmm3,%xmm6
  821272:	ucomisd %xmm6,%xmm8
  821277:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82127d:	movapd 0x280(%rsp),%xmm8
  821287:	mulsd  %xmm1,%xmm8
  82128c:	movapd 0x270(%rsp),%xmm3
  821295:	mulsd  %xmm1,%xmm3
  821299:	addsd  %xmm8,%xmm5
  82129e:	addsd  0x140(%rsp),%xmm5
  8212a7:	subsd  0x90(%rsp),%xmm5
  8212b0:	addsd  %xmm3,%xmm7
  8212b4:	addsd  0x130(%rsp),%xmm7
  8212bd:	addsd  0x80(%rsp),%xmm7
  8212c6:	addsd  0x70(%rsp),%xmm7
  8212cc:	addsd  -0x7719f4(%rip),%xmm7        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212d4:	mulsd  -0x77149c(%rip),%xmm7        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8212dc:	ucomisd %xmm5,%xmm7
  8212e0:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8212e6:	movapd 0x60(%rsp),%xmm6
  8212ec:	subsd  %xmm5,%xmm6
  8212f0:	ucomisd %xmm6,%xmm7
  8212f4:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8212fa:	movsd  %xmm14,0x180(%rsp)
  821304:	movapd %xmm9,%xmm14
  821309:	movapd %xmm1,%xmm7
  82130d:	mulsd  0x240(%rsp),%xmm7
  821316:	movapd %xmm1,%xmm5
  82131a:	mulsd  0x230(%rsp),%xmm5
  821323:	movsd  0x190(%rsp),%xmm9
  82132d:	addsd  %xmm7,%xmm9
  821332:	addsd  0x120(%rsp),%xmm9
  82133c:	subsd  0x50(%rsp),%xmm9
  821343:	movsd  0xb0(%rsp),%xmm13
  82134d:	addsd  %xmm5,%xmm13
  821352:	addsd  0x110(%rsp),%xmm13
  82135c:	addsd  0x40(%rsp),%xmm13
  821363:	addsd  0x30(%rsp),%xmm13
  82136a:	addsd  -0x771a93(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821373:	mulsd  -0x771b1c(%rip),%xmm13        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82137c:	addsd  0x10(%rsp),%xmm13
  821383:	ucomisd %xmm9,%xmm13
  821388:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82138e:	movapd 0x20(%rsp),%xmm6
  821394:	subsd  %xmm9,%xmm6
  821399:	ucomisd %xmm6,%xmm13
  82139e:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8213a4:	movapd 0x200(%rsp),%xmm6
  8213ad:	mulsd  %xmm1,%xmm6
  8213b1:	mulsd  0x1f0(%rsp),%xmm1
  8213ba:	movapd 0x300(%rsp),%xmm13
  8213c4:	addsd  %xmm6,%xmm13
  8213c9:	addsd  0xf0(%rsp),%xmm13
  8213d3:	subsd  0x50(%rsp),%xmm13
  8213da:	addsd  %xmm1,%xmm2
  8213de:	addsd  0x100(%rsp),%xmm2
  8213e7:	addsd  0x40(%rsp),%xmm2
  8213ed:	addsd  0x30(%rsp),%xmm2
  8213f3:	addsd  -0x771b1b(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213fb:	mulsd  -0x7715c3(%rip),%xmm2        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821403:	ucomisd %xmm13,%xmm2
  821408:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82140e:	movapd 0x20(%rsp),%xmm9
  821415:	subsd  %xmm13,%xmm9
  82141a:	ucomisd %xmm9,%xmm2
  82141f:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821425:	addsd  %xmm10,%xmm14
  82142a:	addsd  0x160(%rsp),%xmm14
  821434:	subsd  0x90(%rsp),%xmm14
  82143e:	movsd  0x188(%rsp),%xmm9
  821448:	addsd  %xmm4,%xmm9
  82144d:	addsd  0x150(%rsp),%xmm9
  821457:	addsd  0x80(%rsp),%xmm9
  821461:	addsd  0x70(%rsp),%xmm9
  821468:	addsd  -0x771b91(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821471:	mulsd  -0x771c1a(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82147a:	addsd  0x18(%rsp),%xmm9
  821481:	ucomisd %xmm14,%xmm9
  821486:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82148c:	movapd 0x60(%rsp),%xmm2
  821492:	subsd  %xmm14,%xmm2
  821497:	ucomisd %xmm2,%xmm9
  82149c:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8214a2:	movapd 0x2d0(%rsp),%xmm4
  8214ab:	addsd  %xmm8,%xmm4
  8214b0:	addsd  0x140(%rsp),%xmm4
  8214b9:	subsd  0x90(%rsp),%xmm4
  8214c2:	addsd  %xmm3,%xmm11
  8214c7:	addsd  0x130(%rsp),%xmm11
  8214d1:	addsd  0x80(%rsp),%xmm11
  8214db:	addsd  0x70(%rsp),%xmm11
  8214e2:	addsd  -0x771c0b(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214eb:	mulsd  -0x7716b4(%rip),%xmm11        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8214f4:	ucomisd %xmm4,%xmm11
  8214f9:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8214ff:	movapd 0x60(%rsp),%xmm2
  821505:	subsd  %xmm4,%xmm2
  821509:	ucomisd %xmm2,%xmm11
  82150e:	movsd  0x180(%rsp),%xmm3
  821517:	movsd  0xc0(%rsp),%xmm4
  821520:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821526:	addsd  %xmm7,%xmm3
  82152a:	addsd  0x120(%rsp),%xmm3
  821533:	subsd  0x50(%rsp),%xmm3
  821539:	addsd  %xmm5,%xmm4
  82153d:	addsd  0x110(%rsp),%xmm4
  821546:	addsd  0x40(%rsp),%xmm4
  82154c:	addsd  0x30(%rsp),%xmm4
  821552:	addsd  -0x771c7a(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82155a:	mulsd  -0x771d02(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821562:	addsd  0x10(%rsp),%xmm4
  821568:	ucomisd %xmm3,%xmm4
  82156c:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821572:	movapd 0x20(%rsp),%xmm2
  821578:	subsd  %xmm3,%xmm2
  82157c:	ucomisd %xmm2,%xmm4
  821580:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821586:	movapd 0x170(%rsp),%xmm3
  82158f:	addsd  %xmm6,%xmm3
  821593:	addsd  0xf0(%rsp),%xmm3
  82159c:	subsd  0x50(%rsp),%xmm3
  8215a2:	addsd  %xmm1,%xmm0
  8215a6:	addsd  0x100(%rsp),%xmm0
  8215af:	addsd  0x40(%rsp),%xmm0
  8215b5:	addsd  0x30(%rsp),%xmm0
  8215bb:	addsd  -0x771ce3(%rip),%xmm0        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8215c3:	mulsd  -0x77178b(%rip),%xmm0        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8215cb:	ucomisd %xmm3,%xmm0
  8215cf:	jae    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8215d5:	movapd 0x20(%rsp),%xmm1
  8215db:	subsd  %xmm3,%xmm1
  8215df:	ucomisd %xmm1,%xmm0
  8215e3:	jb     820b85 <<gpui_gpu::renderer::RendererState>::bin_draw+0x635>
  8215e9:	jmp    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8215ee:	movsd  0x8(%rsp),%xmm12
  8215f5:	jmp    820c70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8215fa:	nopw   0x0(%rax,%rax,1)
  821600:	mov    0x1a8(%rsp),%r10
  821608:	cmp    %r10,0x1c0(%rsp)
  821610:	mov    0x1b0(%rsp),%rbp
  821618:	mov    0x1b8(%rsp),%rax
  821620:	jae    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  821626:	mov    %rax,%r14
  821629:	cmp    %r10,%rax
  82162c:	jbe    820a80 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  821632:	jmp    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  821637:	nopw   0x0(%rax,%rax,1)
  821640:	mov    %r14,%rax
  821643:	cmp    %r10,%r14
  821646:	adc    $0x0,%r14
  82164a:	mov    %rax,%rcx
  82164d:	imul   %r13,%rcx
  821651:	mov    %rbp,%rdx
  821654:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  821660:	lea    (%rdx,%rcx,1),%r12
  821664:	cmp    %r9,%r12
  821667:	jae    8216a5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  821669:	cmp    %rbx,%rdx
  82166c:	mov    %rdx,%rsi
  82166f:	adc    $0x0,%rsi
  821673:	mov    0x4(%r15,%r12,8),%edi
  821678:	inc    %edi
  82167a:	and    $0xbfffffff,%edi
  821680:	mov    %edi,0x4(%r15,%r12,8)
  821685:	cmp    %rbx,%rdx
  821688:	jae    821692 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1142>
  82168a:	mov    %rsi,%rdx
  82168d:	cmp    %rbx,%rsi
  821690:	jbe    821660 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1110>
  821692:	cmp    %r10,%rax
  821695:	jae    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82169b:	cmp    %r10,%r14
  82169e:	jbe    821640 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  8216a0:	jmp    82078d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8216a5:	lea    0x60e09c(%rip),%rdx        # e2f748 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  8216ac:	mov    %r12,%rdi
  8216af:	mov    %r9,%rsi
  8216b2:	call   *0x65fa58(%rip)        # e81110 <_DYNAMIC+0x4f8>
  8216b8:	lea    0x60e191(%rip),%rdi        # e2f850 <anon.93049d86f4da36fb5b5cebb14659314f.38.llvm.10732147056912049262>
  8216bf:	call   *0x65fb33(%rip)        # e811f8 <_DYNAMIC+0x5e0>
  8216c5:	lea    0x60e064(%rip),%rdx        # e2f730 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  8216cc:	mov    %r12,%rdi
  8216cf:	mov    %r9,%rsi
  8216d2:	call   *0x65fa38(%rip)        # e81110 <_DYNAMIC+0x4f8>
  8216d8:	lea    0x60e099(%rip),%rdx        # e2f778 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x110>
  8216df:	mov    %r12,%rdi
  8216e2:	mov    0xd8(%rsp),%rsi
  8216ea:	call   *0x65fa20(%rip)        # e81110 <_DYNAMIC+0x4f8>
  8216f0:	lea    0x60e069(%rip),%rdx        # e2f760 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf8>
  8216f7:	mov    %r12,%rdi
  8216fa:	mov    %r9,%rsi
  8216fd:	call   *0x65fa0d(%rip)        # e81110 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821710 <gpui_gpu::renderer::compact_group>:
  821710:	xor    %eax,%eax
  821712:	test   %esi,%esi
  821714:	je     821753 <gpui_gpu::renderer::compact_group+0x43>
  821716:	cmpq   $0x2,0x10(%rdi)
  82171b:	jb     821753 <gpui_gpu::renderer::compact_group+0x43>
  82171d:	sub    $0x58,%rsp
  821721:	mov    (%rdi),%rsi
  821724:	mov    0x8(%rdi),%rax
  821728:	mov    (%rax),%edx
  82172a:	mov    %rsp,%rdi
  82172d:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  821732:	movss  0x4(%rsp),%xmm0
  821738:	cmpb   $0x3,(%rsp)
  82173c:	setne  %cl
  82173f:	xorps  %xmm1,%xmm1
  821742:	ucomiss %xmm1,%xmm0
  821745:	setnp  %dl
  821748:	sete   %al
  82174b:	and    %dl,%al
  82174d:	or     %cl,%al
  82174f:	add    $0x58,%rsp
  821753:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821760 <gpui_gpu::renderer::validate_draw>:
  821760:	push   %rbp
  821761:	push   %r15
  821763:	push   %r14
  821765:	push   %r12
  821767:	push   %rbx
  821768:	sub    $0x80,%rsp
  82176f:	mov    %r8d,%ebp
  821772:	mov    %ecx,%r12d
  821775:	mov    %rdx,%r14
  821778:	mov    %rsi,%r15
  82177b:	mov    %rdi,%rbx
  82177e:	movups 0x88(%rsi),%xmm0
  821785:	movaps %xmm0,0x20(%rsp)
  82178a:	movaps %xmm0,0x70(%rsp)
  82178f:	lea    0x70(%rsp),%rdi
  821794:	call   *0x65faee(%rip)        # e81288 <_DYNAMIC+0x670>
  82179a:	movaps 0x20(%rsp),%xmm4
  82179f:	test   %al,%al
  8217a1:	je     8217f7 <gpui_gpu::renderer::validate_draw+0x97>
  8217a3:	movaps %xmm4,%xmm0
  8217a6:	unpckhpd %xmm4,%xmm0
  8217aa:	xorps  %xmm2,%xmm2
  8217ad:	ucomiss %xmm2,%xmm0
  8217b0:	jne    8217b4 <gpui_gpu::renderer::validate_draw+0x54>
  8217b2:	jnp    8217f7 <gpui_gpu::renderer::validate_draw+0x97>
  8217b4:	movaps %xmm4,%xmm1
  8217b7:	shufps $0xff,%xmm4,%xmm1
  8217bb:	ucomiss %xmm2,%xmm1
  8217be:	jne    8217c2 <gpui_gpu::renderer::validate_draw+0x62>
  8217c0:	jnp    8217f7 <gpui_gpu::renderer::validate_draw+0x97>
  8217c2:	xorps  %xmm3,%xmm3
  8217c5:	ucomiss %xmm4,%xmm3
  8217c8:	ja     8217f7 <gpui_gpu::renderer::validate_draw+0x97>
  8217ca:	movaps %xmm4,%xmm2
  8217cd:	shufps $0x55,%xmm4,%xmm2
  8217d1:	ucomiss %xmm2,%xmm3
  8217d4:	ja     8217f7 <gpui_gpu::renderer::validate_draw+0x97>
  8217d6:	xorps  %xmm3,%xmm3
  8217d9:	cvtsi2ss %r12d,%xmm3
  8217de:	addss  %xmm4,%xmm0
  8217e2:	ucomiss %xmm3,%xmm0
  8217e5:	ja     8217f7 <gpui_gpu::renderer::validate_draw+0x97>
  8217e7:	xorps  %xmm0,%xmm0
  8217ea:	cvtsi2ss %ebp,%xmm0
  8217ee:	addss  %xmm1,%xmm2
  8217f2:	ucomiss %xmm0,%xmm2
  8217f5:	jbe    82180d <gpui_gpu::renderer::validate_draw+0xad>
  8217f7:	movl   $0x3,(%rbx)
  8217fd:	add    $0x80,%rsp
  821804:	pop    %rbx
  821805:	pop    %r12
  821807:	pop    %r14
  821809:	pop    %r15
  82180b:	pop    %rbp
  82180c:	ret
  82180d:	movsd  0x48(%r15),%xmm9
  821813:	movsd  0x60(%r15),%xmm1
  821819:	movupd 0x50(%r15),%xmm2
  82181f:	movapd %xmm2,%xmm5
  821823:	shufpd $0x1,%xmm2,%xmm5
  821828:	movupd 0x68(%r15),%xmm0
  82182e:	cvtpd2ps %xmm5,%xmm8
  821833:	movapd %xmm9,%xmm4
  821838:	unpcklpd %xmm1,%xmm4
  82183c:	cvtpd2ps %xmm4,%xmm7
  821840:	cvtpd2ps %xmm0,%xmm6
  821844:	movapd %xmm6,%xmm3
  821848:	shufps $0x55,%xmm6,%xmm3
  82184c:	movd   %xmm3,%ecx
  821850:	movd   %xmm6,%eax
  821854:	movapd %xmm7,%xmm3
  821858:	shufps $0x14,%xmm8,%xmm3
  82185d:	shufps $0x78,%xmm3,%xmm3
  821861:	andps  -0x774078(%rip),%xmm3        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821868:	and    $0x7fffffff,%eax
  82186d:	cmp    $0x7f800000,%eax
  821872:	setge  %al
  821875:	and    $0x7fffffff,%ecx
  82187b:	cmp    $0x7f800000,%ecx
  821881:	setge  %cl
  821884:	pcmpgtd -0x77615c(%rip),%xmm3        # ab730 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  82188c:	movmskps %xmm3,%edx
  82188f:	test   %edx,%edx
  821891:	jne    8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821893:	test   %al,%al
  821895:	jne    8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821897:	test   %cl,%cl
  821899:	jne    8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  82189b:	movapd %xmm9,%xmm3
  8218a0:	mulsd  %xmm1,%xmm3
  8218a4:	movapd %xmm2,%xmm10
  8218a9:	mulsd  %xmm5,%xmm10
  8218ae:	subsd  %xmm10,%xmm3
  8218b3:	xorpd  %xmm10,%xmm10
  8218b8:	ucomisd %xmm10,%xmm3
  8218bd:	jne    8218c1 <gpui_gpu::renderer::validate_draw+0x161>
  8218bf:	jnp    8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  8218c1:	movq   %xmm3,%rcx
  8218c6:	movabs $0x7fffffffffffffff,%rax
  8218d0:	and    %rax,%rcx
  8218d3:	movabs $0x7ff0000000000000,%rdx
  8218dd:	cmp    %rdx,%rcx
  8218e0:	jl     8218f1 <gpui_gpu::renderer::validate_draw+0x191>
  8218e2:	movl   $0x5,(%rbx)
  8218e8:	mov    %r14,0x8(%rbx)
  8218ec:	jmp    8217fd <gpui_gpu::renderer::validate_draw+0x9d>
  8218f1:	xorps  %xmm10,%xmm10
  8218f5:	cvtsi2sd %r12d,%xmm10
  8218fa:	cvtsi2sd %ebp,%xmm12
  8218ff:	movsd  %xmm9,%xmm2
  821904:	movapd -0x776add(%rip),%xmm13        # aae30 <GCC_except_table0+0x64>
  82190d:	andpd  %xmm13,%xmm2
  821912:	movapd %xmm10,%xmm11
  821917:	unpcklpd %xmm12,%xmm11
  82191c:	movapd %xmm2,%xmm9
  821921:	movapd %xmm11,0x50(%rsp)
  821928:	mulpd  %xmm11,%xmm9
  82192d:	movapd %xmm9,%xmm11
  821932:	unpckhpd %xmm9,%xmm11
  821937:	addsd  %xmm9,%xmm11
  82193c:	movapd %xmm0,%xmm9
  821941:	andpd  %xmm13,%xmm9
  821946:	addsd  %xmm11,%xmm9
  82194b:	shufpd $0x2,%xmm5,%xmm1
  821950:	andpd  %xmm13,%xmm1
  821955:	unpcklpd %xmm10,%xmm12
  82195a:	movapd %xmm1,%xmm10
  82195f:	movapd %xmm12,0x40(%rsp)
  821966:	mulpd  %xmm12,%xmm10
  82196b:	movapd %xmm10,%xmm11
  821970:	unpckhpd %xmm10,%xmm11
  821975:	addsd  %xmm9,%xmm11
  82197a:	addsd  %xmm10,%xmm11
  82197f:	movapd %xmm0,%xmm10
  821984:	unpckhpd %xmm0,%xmm10
  821989:	andpd  %xmm13,%xmm10
  82198e:	addsd  %xmm11,%xmm10
  821993:	movsd  0x38(%r15),%xmm9
  821999:	movsd  0x40(%r15),%xmm12
  82199f:	andps  -0x7741b7(%rip),%xmm9        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8219a7:	cvtps2pd %xmm9,%xmm15
  8219ab:	movapd %xmm10,%xmm9
  8219b0:	addsd  %xmm15,%xmm9
  8219b5:	movapd %xmm15,0x60(%rsp)
  8219bc:	unpckhpd %xmm15,%xmm15
  8219c1:	addsd  %xmm15,%xmm9
  8219c6:	cvtps2pd %xmm12,%xmm11
  8219ca:	movapd %xmm11,0x20(%rsp)
  8219d1:	andpd  %xmm13,%xmm11
  8219d6:	addsd  %xmm11,%xmm9
  8219db:	pshufd $0xee,%xmm11,%xmm14
  8219e1:	movdqa %xmm14,0x30(%rsp)
  8219e8:	addsd  %xmm14,%xmm9
  8219ed:	movq   %xmm9,%rsi
  8219f2:	and    %rax,%rsi
  8219f5:	movabs $0x7fefffffffffffff,%rcx
  8219ff:	cmp    %rcx,%rsi
  821a02:	jg     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821a08:	ucomisd -0x772399(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821a11:	ja     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821a17:	movzbl (%r15),%esi
  821a1b:	cmp    $0x3,%esi
  821a1e:	je     821a36 <gpui_gpu::renderer::validate_draw+0x2d6>
  821a20:	xorpd  %xmm14,%xmm14
  821a25:	cmp    $0x1,%esi
  821a28:	jne    821b62 <gpui_gpu::renderer::validate_draw+0x402>
  821a2e:	movss  0x4(%r15),%xmm14
  821a34:	jmp    821a4d <gpui_gpu::renderer::validate_draw+0x2ed>
  821a36:	movss  0x4(%r15),%xmm14
  821a3c:	xorpd  %xmm13,%xmm13
  821a41:	ucomiss %xmm13,%xmm14
  821a45:	jne    821a4d <gpui_gpu::renderer::validate_draw+0x2ed>
  821a47:	jnp    821c87 <gpui_gpu::renderer::validate_draw+0x527>
  821a4d:	movd   %xmm14,%edi
  821a52:	test   %edi,%edi
  821a54:	sets   %r8b
  821a58:	and    $0x7fffffff,%edi
  821a5e:	lea    -0x800000(%rdi),%r9d
  821a65:	cmp    $0x7f000000,%r9d
  821a6c:	setb   %r9b
  821a70:	and    %r8b,%r9b
  821a73:	lea    -0x1(%rdi),%r10d
  821a77:	cmp    $0x7fffff,%r10d
  821a7e:	setb   %r10b
  821a82:	and    %r8b,%r10b
  821a85:	cmp    $0x7f800000,%edi
  821a8b:	sete   %dil
  821a8f:	setg   %r8b
  821a93:	or     %dil,%r8b
  821a96:	or     %r10b,%r8b
  821a99:	or     %r9b,%r8b
  821a9c:	cmp    $0x1,%r8b
  821aa0:	je     8217f7 <gpui_gpu::renderer::validate_draw+0x97>
  821aa6:	movaps %xmm11,(%rsp)
  821aab:	movaps %xmm14,%xmm11
  821aaf:	movaps %xmm14,0x10(%rsp)
  821ab5:	movaps %xmm12,%xmm14
  821ab9:	mulss  -0x772af6(%rip),%xmm14        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821ac2:	minss  %xmm14,%xmm11
  821ac7:	movaps %xmm11,%xmm14
  821acb:	cmpunordss %xmm11,%xmm14
  821ad1:	movaps %xmm14,%xmm13
  821ad5:	andnps %xmm11,%xmm13
  821ad9:	andps  0x10(%rsp),%xmm14
  821adf:	orps   %xmm13,%xmm14
  821ae3:	shufps $0x55,%xmm12,%xmm12
  821ae8:	mulss  -0x772b25(%rip),%xmm12        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821af1:	movaps %xmm14,%xmm11
  821af5:	minss  %xmm12,%xmm11
  821afa:	movaps %xmm11,%xmm12
  821afe:	cmpunordss %xmm11,%xmm12
  821b04:	andps  %xmm12,%xmm14
  821b08:	andnps %xmm11,%xmm12
  821b0c:	orps   %xmm14,%xmm12
  821b10:	movss  -0x772869(%rip),%xmm11        # af2b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821b19:	ucomiss %xmm12,%xmm11
  821b1d:	ja     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821b23:	xorps  %xmm14,%xmm14
  821b27:	cvtss2sd %xmm12,%xmm14
  821b2c:	movapd %xmm9,%xmm11
  821b31:	divsd  %xmm14,%xmm11
  821b36:	ucomisd -0x772257(%rip),%xmm11        # af8e8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  821b3f:	ja     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821b45:	addsd  %xmm9,%xmm14
  821b4a:	mulsd  -0x7723cb(%rip),%xmm14        # af788 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821b53:	movapd (%rsp),%xmm11
  821b59:	movapd -0x776d32(%rip),%xmm13        # aae30 <GCC_except_table0+0x64>
  821b62:	cmp    $0x2,%esi
  821b65:	movaps %xmm11,(%rsp)
  821b6a:	jae    821c7b <gpui_gpu::renderer::validate_draw+0x51b>
  821b70:	cvtps2pd %xmm8,%xmm8
  821b74:	subpd  %xmm8,%xmm5
  821b79:	cvtps2pd %xmm7,%xmm7
  821b7c:	andpd  %xmm13,%xmm5
  821b81:	mulpd  0x40(%rsp),%xmm5
  821b87:	subpd  %xmm7,%xmm4
  821b8b:	andpd  %xmm13,%xmm4
  821b90:	mulpd  0x50(%rsp),%xmm4
  821b96:	addpd  %xmm5,%xmm4
  821b9a:	cvtps2pd %xmm6,%xmm5
  821b9d:	subpd  %xmm5,%xmm0
  821ba1:	addsd  -0x7722ca(%rip),%xmm10        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821baa:	mulsd  -0x772103(%rip),%xmm10        # afab0 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821bb3:	andpd  %xmm13,%xmm0
  821bb8:	addpd  %xmm4,%xmm0
  821bbc:	movapd 0x60(%rsp),%xmm7
  821bc2:	addsd  %xmm7,%xmm15
  821bc7:	movapd (%rsp),%xmm6
  821bcc:	addsd  %xmm6,%xmm15
  821bd1:	addsd  0x30(%rsp),%xmm15
  821bd8:	movapd %xmm0,%xmm4
  821bdc:	unpckhpd %xmm0,%xmm4
  821be0:	addpd  %xmm0,%xmm4
  821be4:	movapd %xmm1,%xmm5
  821be8:	shufpd $0x1,%xmm4,%xmm5
  821bed:	movapd %xmm2,%xmm4
  821bf1:	unpcklpd %xmm10,%xmm4
  821bf6:	addpd  %xmm4,%xmm5
  821bfa:	mulsd  -0x77254b(%rip),%xmm15        # af6b8 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821c03:	shufpd $0x1,%xmm15,%xmm2
  821c09:	addpd  %xmm5,%xmm2
  821c0d:	unpcklpd %xmm14,%xmm1
  821c12:	addpd  %xmm2,%xmm1
  821c16:	movapd %xmm1,%xmm2
  821c1a:	unpckhpd %xmm1,%xmm2
  821c1e:	mulsd  %xmm1,%xmm2
  821c22:	andpd  -0x776dfa(%rip),%xmm3        # aae30 <GCC_except_table0+0x64>
  821c2a:	divsd  %xmm3,%xmm2
  821c2e:	movq   %xmm2,%rdx
  821c33:	and    %rax,%rdx
  821c36:	cmp    %rcx,%rdx
  821c39:	jg     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821c3f:	ucomisd -0x771d37(%rip),%xmm2        # aff10 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821c47:	ja     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821c4d:	unpcklpd %xmm10,%xmm10
  821c52:	addpd  %xmm10,%xmm0
  821c57:	addpd  %xmm7,%xmm6
  821c5b:	mulpd  -0x776c53(%rip),%xmm6        # ab010 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821c63:	addpd  %xmm0,%xmm6
  821c67:	cvtpd2ps %xmm6,%xmm0
  821c6b:	movlpd %xmm0,0x4(%rbx)
  821c70:	movl   $0xffffffff,(%rbx)
  821c76:	jmp    8217fd <gpui_gpu::renderer::validate_draw+0x9d>
  821c7b:	jne    821c90 <gpui_gpu::renderer::validate_draw+0x530>
  821c7d:	mov    0x28(%r15),%rsi
  821c81:	mov    0x30(%r15),%rdi
  821c85:	jmp    821c98 <gpui_gpu::renderer::validate_draw+0x538>
  821c87:	movaps %xmm11,(%rsp)
  821c8c:	xorps  %xmm14,%xmm14
  821c90:	mov    0x28(%r15),%esi
  821c94:	mov    0x2c(%r15),%edi
  821c98:	movq   %rsi,%xmm11
  821c9d:	punpckldq -0x776356(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821ca6:	subpd  -0x776e8f(%rip),%xmm11        # aae20 <GCC_except_table0+0x54>
  821caf:	movapd %xmm11,%xmm12
  821cb4:	unpckhpd %xmm11,%xmm12
  821cb9:	addsd  %xmm11,%xmm12
  821cbe:	movapd 0x20(%rsp),%xmm11
  821cc5:	divsd  %xmm11,%xmm12
  821cca:	movq   %xmm12,%r8
  821ccf:	and    %rax,%r8
  821cd2:	cmp    %rdx,%r8
  821cd5:	jge    8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821cdb:	movaps %xmm14,0x10(%rsp)
  821ce1:	movapd %xmm11,%xmm14
  821ce6:	movq   %rdi,%xmm11
  821ceb:	punpckldq -0x7763a4(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821cf4:	subpd  -0x776edd(%rip),%xmm11        # aae20 <GCC_except_table0+0x54>
  821cfd:	movapd %xmm11,%xmm13
  821d02:	unpckhpd %xmm11,%xmm13
  821d07:	addsd  %xmm11,%xmm13
  821d0c:	unpckhpd %xmm14,%xmm14
  821d11:	divsd  %xmm14,%xmm13
  821d16:	movapd 0x10(%rsp),%xmm14
  821d1d:	movq   %xmm13,%rdx
  821d22:	and    %rax,%rdx
  821d25:	cmp    %rcx,%rdx
  821d28:	setg   %dl
  821d2b:	ucomisd -0x7726bc(%rip),%xmm13        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821d34:	movapd -0x776f0d(%rip),%xmm13        # aae30 <GCC_except_table0+0x64>
  821d3d:	ja     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821d43:	ucomisd -0x7726d4(%rip),%xmm12        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821d4c:	ja     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821d52:	test   %dl,%dl
  821d54:	jne    8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821d5a:	cmp    %rsi,%rdi
  821d5d:	cmova  %rdi,%rsi
  821d61:	movq   %rsi,%xmm11
  821d66:	punpckldq -0x77641f(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821d6f:	subpd  -0x776f58(%rip),%xmm11        # aae20 <GCC_except_table0+0x54>
  821d78:	movapd %xmm11,%xmm12
  821d7d:	unpckhpd %xmm11,%xmm12
  821d82:	addsd  %xmm11,%xmm12
  821d87:	mulsd  %xmm12,%xmm9
  821d8c:	ucomisd -0x77271d(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821d95:	ja     8218e2 <gpui_gpu::renderer::validate_draw+0x182>
  821d9b:	jmp    821b70 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008224b0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  8224b0:	push   %rbp
  8224b1:	push   %r15
  8224b3:	push   %r14
  8224b5:	push   %r13
  8224b7:	push   %r12
  8224b9:	push   %rbx
  8224ba:	sub    $0x58,%rsp
  8224be:	mov    %ecx,%ebp
  8224c0:	mov    %rdx,0x8(%rsp)
  8224c5:	mov    0x18(%rdi),%rax
  8224c9:	add    %rax,%rsi
  8224cc:	jb     8225e1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8224d2:	mov    %rdi,%rbx
  8224d5:	mov    0x8(%rdi),%r15
  8224d9:	lea    0x1(%r15),%rdx
  8224dd:	mov    %rdx,%rdi
  8224e0:	shr    $0x3,%rdi
  8224e4:	mov    %rdx,%rcx
  8224e7:	and    $0xfffffffffffffff8,%rcx
  8224eb:	sub    %rdi,%rcx
  8224ee:	cmp    $0x8,%r15
  8224f2:	cmovb  %r15,%rcx
  8224f6:	mov    %rcx,%rdi
  8224f9:	shr    $1,%rdi
  8224fc:	cmp    %rdi,%rsi
  8224ff:	jbe    822530 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  822501:	inc    %rcx
  822504:	cmp    %rsi,%rcx
  822507:	cmovbe %rsi,%rcx
  82250b:	cmp    $0xf,%rcx
  82250f:	mov    %rbx,(%rsp)
  822513:	jae    822561 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  822515:	mov    %ecx,%eax
  822517:	and    $0x8,%eax
  82251a:	add    $0x8,%rax
  82251e:	cmp    $0x4,%rcx
  822522:	mov    $0x4,%ebx
  822527:	cmovae %rax,%rbx
  82252b:	jmp    8225b9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  822530:	test   %rdx,%rdx
  822533:	je     8227ba <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  822539:	mov    (%rbx),%rsi
  82253c:	mov    %rdx,%rax
  82253f:	shr    $0x4,%rax
  822543:	mov    %edx,%ecx
  822545:	and    $0xf,%ecx
  822548:	cmp    $0x1,%rcx
  82254c:	sbb    $0xffffffffffffffff,%rax
  822550:	cmp    $0x1,%rax
  822554:	jne    8227c1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  82255a:	xor    %ecx,%ecx
  82255c:	jmp    822814 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  822561:	movabs $0x1ffffffffffffffe,%rax
  82256b:	inc    %rax
  82256e:	cmp    %rax,%rcx
  822571:	ja     8225e1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822573:	shl    $0x3,%rcx
  822577:	movabs $0x2492492492492493,%rdx
  822581:	mov    %rcx,%rax
  822584:	mul    %rdx
  822587:	sub    %rdx,%rcx
  82258a:	shr    $1,%rcx
  82258d:	add    %rdx,%rcx
  822590:	shr    $0x2,%rcx
  822594:	dec    %rcx
  822597:	bsr    %rcx,%rcx
  82259b:	not    %ecx
  82259d:	mov    $0xffffffffffffffff,%rbx
  8225a4:	shr    %cl,%rbx
  8225a7:	movabs $0x7fffffffffffffe,%rax
  8225b1:	cmp    %rax,%rbx
  8225b4:	ja     8225e1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8225b6:	inc    %rbx
  8225b9:	mov    %rbx,%r14
  8225bc:	shl    $0x5,%r14
  8225c0:	lea    0x10(%rbx),%r12
  8225c4:	mov    %r12,%r13
  8225c7:	add    %r14,%r13
  8225ca:	setb   %al
  8225cd:	movabs $0x7ffffffffffffff0,%rcx
  8225d7:	cmp    %rcx,%r13
  8225da:	seta   %cl
  8225dd:	or     %al,%cl
  8225df:	je     8225f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  8225e1:	movzbl %bpl,%edi
  8225e5:	call   *0x65eca5(%rip)        # e81290 <_DYNAMIC+0x678>
  8225eb:	jmp    822a35 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8225f0:	call   *0x65e8b2(%rip)        # e80ea8 <_DYNAMIC+0x290>
  8225f6:	mov    $0x10,%esi
  8225fb:	mov    %r13,%rdi
  8225fe:	call   *0x65e8ac(%rip)        # e80eb0 <_DYNAMIC+0x298>
  822604:	test   %rax,%rax
  822607:	je     822a53 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  82260d:	mov    %rax,%r15
  822610:	mov    (%rsp),%rcx
  822614:	lea    0x20(%rcx),%r13
  822618:	add    %r14,%r15
  82261b:	lea    -0x1(%rbx),%r14
  82261f:	mov    %rbx,%rax
  822622:	shr    $0x3,%rax
  822626:	mov    %rbx,%rbp
  822629:	and    $0xfffffffffffffff8,%rbp
  82262d:	sub    %rax,%rbp
  822630:	cmp    $0x9,%rbx
  822634:	mov    %rcx,%rbx
  822637:	cmovb  %r14,%rbp
  82263b:	mov    %r15,%rdi
  82263e:	mov    $0xff,%esi
  822643:	mov    %r12,%rdx
  822646:	call   *0x65ec4c(%rip)        # e81298 <memset@GLIBC_2.2.5>
  82264c:	mov    %r14,%rdi
  82264f:	mov    %r13,0x20(%rsp)
  822654:	movq   $0x20,0x28(%rsp)
  82265d:	movq   $0x10,0x30(%rsp)
  822666:	mov    %r15,0x38(%rsp)
  82266b:	mov    %r14,0x40(%rsp)
  822670:	mov    %rbp,0x48(%rsp)
  822675:	movq   $0x0,0x50(%rsp)
  82267e:	mov    0x18(%rbx),%r12
  822682:	test   %r12,%r12
  822685:	je     822a67 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82268b:	mov    %rbp,0x10(%rsp)
  822690:	mov    (%rbx),%rsi
  822693:	movdqa (%rsi),%xmm0
  822697:	pmovmskb %xmm0,%r13d
  82269c:	not    %r13d
  82269f:	xor    %ebp,%ebp
  8226a1:	mov    %rsi,%r14
  8226a4:	mov    %rdi,0x18(%rsp)
  8226a9:	nopl   0x0(%rax)
  8226b0:	test   %r13w,%r13w
  8226b4:	jne    8226df <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  8226b6:	cs nopw 0x0(%rax,%rax,1)
  8226c0:	movdqa 0x10(%r14),%xmm0
  8226c6:	add    $0x10,%r14
  8226ca:	pmovmskb %xmm0,%r13d
  8226cf:	xor    $0xffff,%r13d
  8226d6:	add    $0x10,%rbp
  8226da:	test   %r13d,%r13d
  8226dd:	je     8226c0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  8226df:	tzcnt  %r13d,%ebx
  8226e4:	add    %rbp,%rbx
  8226e7:	mov    %rbx,%rax
  8226ea:	shl    $0x5,%rax
  8226ee:	sub    %rax,%rsi
  8226f1:	add    $0xffffffffffffffe0,%rsi
  8226f5:	mov    0x8(%rsp),%rdi
  8226fa:	call   824880 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8226ff:	mov    %rax,%rdx
  822702:	mov    0x18(%rsp),%rdi
  822707:	and    %rdi,%rdx
  82270a:	movdqu (%r15,%rdx,1),%xmm0
  822710:	pmovmskb %xmm0,%ecx
  822714:	test   %ecx,%ecx
  822716:	je     822785 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822718:	tzcnt  %ecx,%ecx
  82271c:	add    %rdx,%rcx
  82271f:	and    %rdi,%rcx
  822722:	cmpb   $0x0,(%r15,%rcx,1)
  822727:	jns    8227a8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  822729:	lea    -0x1(%r13),%edx
  82272d:	and    %r13d,%edx
  822730:	dec    %r12
  822733:	shr    $0x39,%rax
  822737:	lea    -0x10(%rcx),%rsi
  82273b:	and    %rdi,%rsi
  82273e:	mov    %al,(%r15,%rcx,1)
  822742:	mov    %al,0x10(%r15,%rsi,1)
  822747:	mov    (%rsp),%rax
  82274b:	mov    (%rax),%rsi
  82274e:	not    %rbx
  822751:	shl    $0x5,%rbx
  822755:	not    %rcx
  822758:	shl    $0x5,%rcx
  82275c:	movdqu (%rsi,%rbx,1),%xmm0
  822761:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  822767:	movdqu %xmm1,0x10(%r15,%rcx,1)
  82276e:	movdqu %xmm0,(%r15,%rcx,1)
  822774:	mov    %edx,%r13d
  822777:	test   %r12,%r12
  82277a:	jne    8226b0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  822780:	jmp    822a44 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  822785:	mov    $0x10,%esi
  82278a:	add    %rsi,%rdx
  82278d:	and    %rdi,%rdx
  822790:	movdqu (%r15,%rdx,1),%xmm0
  822796:	pmovmskb %xmm0,%ecx
  82279a:	add    $0x10,%rsi
  82279e:	test   %ecx,%ecx
  8227a0:	jne    822718 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  8227a6:	jmp    82278a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  8227a8:	movdqa (%r15),%xmm0
  8227ad:	pmovmskb %xmm0,%ecx
  8227b1:	tzcnt  %ecx,%ecx
  8227b5:	jmp    822729 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  8227ba:	xor    %ecx,%ecx
  8227bc:	jmp    822a27 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  8227c1:	movabs $0x1ffffffffffffffe,%rdi
  8227cb:	and    %rax,%rdi
  8227ce:	xor    %ecx,%ecx
  8227d0:	movdqa -0x774bd8(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  8227d8:	nopl   0x0(%rax,%rax,1)
  8227e0:	pxor   %xmm1,%xmm1
  8227e4:	pcmpgtb (%rsi,%rcx,1),%xmm1
  8227e9:	por    %xmm0,%xmm1
  8227ed:	movdqa %xmm1,(%rsi,%rcx,1)
  8227f2:	pxor   %xmm1,%xmm1
  8227f6:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  8227fc:	por    %xmm0,%xmm1
  822800:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  822806:	add    $0x20,%rcx
  82280a:	add    $0xfffffffffffffffe,%rdi
  82280e:	jne    8227e0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  822810:	test   $0x1,%al
  822812:	je     82282a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  822814:	pxor   %xmm0,%xmm0
  822818:	pcmpgtb (%rsi,%rcx,1),%xmm0
  82281d:	por    -0x774c25(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822825:	movdqa %xmm0,(%rsi,%rcx,1)
  82282a:	cmp    $0x10,%rdx
  82282e:	jb     822ab8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  822834:	mov    %rdx,%rdi
  822837:	mov    $0x10,%edx
  82283c:	add    %rsi,%rdi
  82283f:	call   *0x65ea5b(%rip)        # e812a0 <memmove@GLIBC_2.2.5>
  822845:	movq   $0x0,0x28(%rsp)
  82284e:	movq   $0x20,0x30(%rsp)
  822857:	mov    %rbx,0x20(%rsp)
  82285c:	xor    %r12d,%r12d
  82285f:	xor    %r13d,%r13d
  822862:	jmp    8229b1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  822867:	nopw   0x0(%rax,%rax,1)
  822870:	lea    (%rax,%rbp,1),%rsi
  822874:	add    $0xffffffffffffffe0,%rsi
  822878:	mov    0x8(%rsp),%rdi
  82287d:	call   824880 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  822882:	mov    (%rbx),%rcx
  822885:	mov    0x8(%rbx),%rdx
  822889:	mov    %rdx,%rsi
  82288c:	and    %rax,%rsi
  82288f:	movdqu (%rcx,%rsi,1),%xmm0
  822894:	pmovmskb %xmm0,%edi
  822898:	mov    %rsi,%r8
  82289b:	test   %edi,%edi
  82289d:	je     822949 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  8228a3:	tzcnt  %edi,%edi
  8228a7:	add    %r8,%rdi
  8228aa:	and    %rdx,%rdi
  8228ad:	cmpb   $0x0,(%rcx,%rdi,1)
  8228b1:	jns    822970 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  8228b7:	mov    %r12,%r8
  8228ba:	sub    %rsi,%r8
  8228bd:	mov    %rdi,%r9
  8228c0:	sub    %rsi,%r9
  8228c3:	xor    %r8,%r9
  8228c6:	and    %rdx,%r9
  8228c9:	cmp    $0x10,%r9
  8228cd:	jb     822990 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  8228d3:	mov    %rdi,%rsi
  8228d6:	not    %rsi
  8228d9:	shl    $0x5,%rsi
  8228dd:	add    %rcx,%rsi
  8228e0:	movzbl (%rcx,%rdi,1),%r8d
  8228e5:	shr    $0x39,%rax
  8228e9:	lea    -0x10(%rdi),%r9
  8228ed:	and    %rdx,%r9
  8228f0:	mov    %al,(%rcx,%rdi,1)
  8228f3:	mov    (%rbx),%rcx
  8228f6:	mov    %al,0x10(%rcx,%r9,1)
  8228fb:	cmp    $0xff,%r8b
  8228ff:	je     8229d6 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  822905:	mov    (%r14),%rax
  822908:	mov    (%rsi),%rcx
  82290b:	mov    %rcx,(%r14)
  82290e:	mov    %rax,(%rsi)
  822911:	mov    0x8(%r14),%rax
  822915:	mov    0x8(%rsi),%rcx
  822919:	mov    %rcx,0x8(%r14)
  82291d:	mov    %rax,0x8(%rsi)
  822921:	mov    0x10(%r14),%rax
  822925:	mov    0x10(%rsi),%rcx
  822929:	mov    %rcx,0x10(%r14)
  82292d:	mov    %rax,0x10(%rsi)
  822931:	mov    0x18(%r14),%rax
  822935:	mov    0x18(%rsi),%rcx
  822939:	mov    %rcx,0x18(%r14)
  82293d:	mov    %rax,0x18(%rsi)
  822941:	mov    (%rbx),%rax
  822944:	jmp    822870 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822949:	mov    $0x10,%r9d
  82294f:	mov    %rsi,%r8
  822952:	add    %r9,%r8
  822955:	and    %rdx,%r8
  822958:	movdqu (%rcx,%r8,1),%xmm0
  82295e:	pmovmskb %xmm0,%edi
  822962:	add    $0x10,%r9
  822966:	test   %edi,%edi
  822968:	jne    8228a3 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  82296e:	jmp    822952 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  822970:	movdqa (%rcx),%xmm0
  822974:	pmovmskb %xmm0,%edi
  822978:	tzcnt  %edi,%edi
  82297c:	jmp    8228b7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  822981:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  822990:	shr    $0x39,%rax
  822994:	lea    -0x10(%r12),%rsi
  822999:	and    %rsi,%rdx
  82299c:	mov    %al,(%rcx,%r12,1)
  8229a0:	mov    (%rbx),%rcx
  8229a3:	mov    %al,0x10(%rcx,%rdx,1)
  8229a7:	cmp    %r15,%r12
  8229aa:	lea    0x1(%r12),%r12
  8229af:	je     822a05 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  8229b1:	mov    (%rbx),%rax
  8229b4:	cmp    (%rax,%r12,1),%r13b
  8229b8:	jno    8229a7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  8229ba:	mov    %r12,%r14
  8229bd:	not    %r14
  8229c0:	shl    $0x5,%r14
  8229c4:	add    %rax,%r14
  8229c7:	mov    %r12,%rbp
  8229ca:	neg    %rbp
  8229cd:	shl    $0x5,%rbp
  8229d1:	jmp    822870 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  8229d6:	lea    -0x10(%r12),%rax
  8229db:	and    0x8(%rbx),%rax
  8229df:	mov    (%rbx),%rcx
  8229e2:	movb   $0xff,(%rcx,%r12,1)
  8229e7:	mov    (%rbx),%rcx
  8229ea:	movb   $0xff,0x10(%rcx,%rax,1)
  8229ef:	movdqu (%r14),%xmm0
  8229f4:	movdqu 0x10(%r14),%xmm1
  8229fa:	movdqu %xmm1,0x10(%rsi)
  8229ff:	movdqu %xmm0,(%rsi)
  822a03:	jmp    8229a7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  822a05:	mov    0x8(%rbx),%rdx
  822a09:	mov    0x18(%rbx),%rax
  822a0d:	lea    0x1(%rdx),%rcx
  822a11:	mov    %rcx,%rsi
  822a14:	shr    $0x3,%rsi
  822a18:	and    $0xfffffffffffffff8,%rcx
  822a1c:	sub    %rsi,%rcx
  822a1f:	cmp    $0x8,%rdx
  822a23:	cmovb  %rdx,%rcx
  822a27:	sub    %rax,%rcx
  822a2a:	mov    %rcx,0x10(%rbx)
  822a2e:	mov    $0xffffffffffffffff,%rax
  822a35:	add    $0x58,%rsp
  822a39:	pop    %rbx
  822a3a:	pop    %r12
  822a3c:	pop    %r13
  822a3e:	pop    %r14
  822a40:	pop    %r15
  822a42:	pop    %rbp
  822a43:	ret
  822a44:	mov    (%rsp),%rbx
  822a48:	mov    0x18(%rbx),%rcx
  822a4c:	mov    0x10(%rsp),%rbp
  822a51:	jmp    822a6c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  822a53:	movzbl %bpl,%edi
  822a57:	mov    $0x10,%esi
  822a5c:	mov    %r13,%rdx
  822a5f:	call   *0x65e843(%rip)        # e812a8 <_DYNAMIC+0x690>
  822a65:	jmp    822a35 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  822a67:	mov    (%rbx),%rsi
  822a6a:	xor    %ecx,%ecx
  822a6c:	sub    %rcx,%rbp
  822a6f:	mov    %r15,(%rbx)
  822a72:	mov    0x8(%rbx),%rax
  822a76:	mov    %rdi,0x8(%rbx)
  822a7a:	mov    %rbp,0x10(%rbx)
  822a7e:	mov    %rcx,0x18(%rbx)
  822a82:	test   %rax,%rax
  822a85:	je     822a2e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822a87:	mov    %rax,%rcx
  822a8a:	shl    $0x5,%rcx
  822a8e:	add    $0x2f,%rcx
  822a92:	and    $0xffffffffffffffe0,%rcx
  822a96:	add    %rcx,%rax
  822a99:	add    $0x11,%rax
  822a9d:	je     822a2e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822a9f:	sub    %rcx,%rsi
  822aa2:	mov    $0x10,%edx
  822aa7:	mov    %rsi,%rdi
  822aaa:	mov    %rax,%rsi
  822aad:	call   *0x65e3ad(%rip)        # e80e60 <_DYNAMIC+0x248>
  822ab3:	jmp    822a2e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822ab8:	mov    $0x10,%edi
  822abd:	jmp    82283c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  822ac2:	mov    %rax,%rbx
  822ac5:	lea    0x20(%rsp),%rdi
  822aca:	call   8230a0 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  822acf:	mov    %rbx,%rdi
  822ad2:	call   e2d970 <_Unwind_Resume@plt>
  822ad7:	mov    %rax,%rbx
  822ada:	lea    0x20(%rsp),%rdi
  822adf:	call   8230e0 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  822ae4:	mov    %rbx,%rdi
  822ae7:	call   e2d970 <_Unwind_Resume@plt>
  822aec:	call   *0x65e376(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822b00 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  822b00:	push   %rbp
  822b01:	push   %r15
  822b03:	push   %r14
  822b05:	push   %r13
  822b07:	push   %r12
  822b09:	push   %rbx
  822b0a:	sub    $0x38,%rsp
  822b0e:	mov    %ecx,%r15d
  822b11:	mov    %rdx,0x20(%rsp)
  822b16:	mov    %rdi,%rbp
  822b19:	mov    0x18(%rdi),%rdi
  822b1d:	add    %rdi,%rsi
  822b20:	jb     822c38 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822b26:	mov    0x8(%rbp),%rbx
  822b2a:	lea    0x1(%rbx),%rdx
  822b2e:	mov    %rdx,%rax
  822b31:	shr    $0x3,%rax
  822b35:	mov    %rdx,%rcx
  822b38:	and    $0xfffffffffffffff8,%rcx
  822b3c:	sub    %rax,%rcx
  822b3f:	cmp    $0x8,%rbx
  822b43:	cmovb  %rbx,%rcx
  822b47:	mov    %rcx,%rax
  822b4a:	shr    $1,%rax
  822b4d:	cmp    %rax,%rsi
  822b50:	jbe    822b86 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  822b52:	inc    %rcx
  822b55:	cmp    %rsi,%rcx
  822b58:	cmovbe %rsi,%rcx
  822b5c:	cmp    $0xf,%rcx
  822b60:	mov    %rbp,(%rsp)
  822b64:	mov    %rbx,0x30(%rsp)
  822b69:	jae    822bb8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  822b6b:	mov    %ecx,%eax
  822b6d:	and    $0x8,%eax
  822b70:	add    $0x8,%rax
  822b74:	cmp    $0x4,%rcx
  822b78:	mov    $0x4,%ebx
  822b7d:	cmovae %rax,%rbx
  822b81:	jmp    822c10 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  822b86:	test   %rdx,%rdx
  822b89:	je     822dce <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  822b8f:	mov    0x0(%rbp),%r12
  822b93:	mov    %rdx,%rax
  822b96:	shr    $0x4,%rax
  822b9a:	mov    %edx,%ecx
  822b9c:	and    $0xf,%ecx
  822b9f:	cmp    $0x1,%rcx
  822ba3:	sbb    $0xffffffffffffffff,%rax
  822ba7:	cmp    $0x1,%rax
  822bab:	jne    822dd5 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822bb1:	xor    %ecx,%ecx
  822bb3:	jmp    822e28 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  822bb8:	movabs $0x1ffffffffffffffe,%rax
  822bc2:	inc    %rax
  822bc5:	cmp    %rax,%rcx
  822bc8:	ja     822c38 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822bca:	shl    $0x3,%rcx
  822bce:	movabs $0x2492492492492493,%rdx
  822bd8:	mov    %rcx,%rax
  822bdb:	mul    %rdx
  822bde:	sub    %rdx,%rcx
  822be1:	shr    $1,%rcx
  822be4:	add    %rdx,%rcx
  822be7:	shr    $0x2,%rcx
  822beb:	dec    %rcx
  822bee:	bsr    %rcx,%rcx
  822bf2:	not    %ecx
  822bf4:	mov    $0xffffffffffffffff,%rbx
  822bfb:	shr    %cl,%rbx
  822bfe:	movabs $0xffffffffffffffe,%rax
  822c08:	cmp    %rax,%rbx
  822c0b:	ja     822c38 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822c0d:	inc    %rbx
  822c10:	mov    %rbx,%r14
  822c13:	shl    $0x4,%r14
  822c17:	lea    0x10(%rbx),%rbp
  822c1b:	mov    %rbp,%r13
  822c1e:	add    %r14,%r13
  822c21:	setb   %al
  822c24:	movabs $0x7ffffffffffffff0,%rcx
  822c2e:	cmp    %rcx,%r13
  822c31:	seta   %cl
  822c34:	or     %al,%cl
  822c36:	je     822c47 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  822c38:	movzbl %r15b,%edi
  822c3c:	call   *0x65e64e(%rip)        # e81290 <_DYNAMIC+0x678>
  822c42:	jmp    823008 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822c47:	mov    %rdi,0x8(%rsp)
  822c4c:	call   *0x65e256(%rip)        # e80ea8 <_DYNAMIC+0x290>
  822c52:	mov    $0x10,%esi
  822c57:	mov    %r13,%rdi
  822c5a:	call   *0x65e250(%rip)        # e80eb0 <_DYNAMIC+0x298>
  822c60:	test   %rax,%rax
  822c63:	je     823022 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  822c69:	mov    %rax,%rdi
  822c6c:	add    %r14,%rdi
  822c6f:	lea    -0x1(%rbx),%rcx
  822c73:	mov    %rbx,%rax
  822c76:	shr    $0x3,%rax
  822c7a:	mov    %rbx,%r14
  822c7d:	and    $0xfffffffffffffff8,%r14
  822c81:	sub    %rax,%r14
  822c84:	cmp    $0x9,%rbx
  822c88:	mov    %rcx,0x10(%rsp)
  822c8d:	cmovb  %rcx,%r14
  822c91:	mov    %rdi,0x18(%rsp)
  822c96:	mov    $0xff,%esi
  822c9b:	mov    %rbp,%rdx
  822c9e:	call   *0x65e5f4(%rip)        # e81298 <memset@GLIBC_2.2.5>
  822ca4:	mov    0x8(%rsp),%rbx
  822ca9:	test   %rbx,%rbx
  822cac:	je     823036 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  822cb2:	mov    %r14,0x28(%rsp)
  822cb7:	mov    (%rsp),%rax
  822cbb:	mov    (%rax),%rdi
  822cbe:	movdqa (%rdi),%xmm0
  822cc2:	pmovmskb %xmm0,%r14d
  822cc7:	not    %r14d
  822cca:	xor    %ebp,%ebp
  822ccc:	mov    %rdi,%r13
  822ccf:	nop
  822cd0:	test   %r14w,%r14w
  822cd4:	jne    822cff <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  822cd6:	cs nopw 0x0(%rax,%rax,1)
  822ce0:	movdqa 0x10(%r13),%xmm0
  822ce6:	add    $0x10,%r13
  822cea:	pmovmskb %xmm0,%r14d
  822cef:	xor    $0xffff,%r14d
  822cf6:	add    $0x10,%rbp
  822cfa:	test   %r14d,%r14d
  822cfd:	je     822ce0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  822cff:	tzcnt  %r14d,%r15d
  822d04:	add    %rbp,%r15
  822d07:	mov    %r15,%rax
  822d0a:	shl    $0x4,%rax
  822d0e:	mov    %rdi,%r12
  822d11:	mov    %rdi,%rsi
  822d14:	sub    %rax,%rsi
  822d17:	add    $0xfffffffffffffff0,%rsi
  822d1b:	mov    0x20(%rsp),%rdi
  822d20:	call   824a20 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822d25:	mov    %rax,%rcx
  822d28:	mov    0x10(%rsp),%r9
  822d2d:	and    %r9,%rcx
  822d30:	mov    0x18(%rsp),%r8
  822d35:	movdqu (%r8,%rcx,1),%xmm0
  822d3b:	pmovmskb %xmm0,%edx
  822d3f:	test   %edx,%edx
  822d41:	je     822da0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  822d43:	tzcnt  %edx,%edx
  822d47:	add    %rcx,%rdx
  822d4a:	and    %r9,%rdx
  822d4d:	cmpb   $0x0,(%r8,%rdx,1)
  822d52:	mov    %r12,%rdi
  822d55:	jns    822dbf <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  822d57:	lea    -0x1(%r14),%ecx
  822d5b:	and    %r14d,%ecx
  822d5e:	dec    %rbx
  822d61:	shr    $0x39,%rax
  822d65:	lea    -0x10(%rdx),%rsi
  822d69:	and    %r9,%rsi
  822d6c:	mov    %al,(%r8,%rdx,1)
  822d70:	mov    %al,0x10(%r8,%rsi,1)
  822d75:	not    %r15
  822d78:	shl    $0x4,%r15
  822d7c:	not    %rdx
  822d7f:	shl    $0x4,%rdx
  822d83:	movdqu (%rdi,%r15,1),%xmm0
  822d89:	movdqu %xmm0,(%r8,%rdx,1)
  822d8f:	mov    %ecx,%r14d
  822d92:	test   %rbx,%rbx
  822d95:	jne    822cd0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  822d9b:	jmp    823017 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  822da0:	mov    $0x10,%esi
  822da5:	add    %rsi,%rcx
  822da8:	and    %r9,%rcx
  822dab:	movdqu (%r8,%rcx,1),%xmm0
  822db1:	pmovmskb %xmm0,%edx
  822db5:	add    $0x10,%rsi
  822db9:	test   %edx,%edx
  822dbb:	jne    822d43 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  822dbd:	jmp    822da5 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  822dbf:	movdqa (%r8),%xmm0
  822dc4:	pmovmskb %xmm0,%ecx
  822dc8:	tzcnt  %ecx,%edx
  822dcc:	jmp    822d57 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  822dce:	xor    %eax,%eax
  822dd0:	jmp    822ffa <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  822dd5:	movabs $0x1ffffffffffffffe,%rsi
  822ddf:	and    %rax,%rsi
  822de2:	xor    %ecx,%ecx
  822de4:	movdqa -0x7751ec(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822dec:	nopl   0x0(%rax)
  822df0:	pxor   %xmm1,%xmm1
  822df4:	pcmpgtb (%r12,%rcx,1),%xmm1
  822dfa:	por    %xmm0,%xmm1
  822dfe:	movdqa %xmm1,(%r12,%rcx,1)
  822e04:	pxor   %xmm1,%xmm1
  822e08:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  822e0f:	por    %xmm0,%xmm1
  822e13:	movdqa %xmm1,0x10(%r12,%rcx,1)
  822e1a:	add    $0x20,%rcx
  822e1e:	add    $0xfffffffffffffffe,%rsi
  822e22:	jne    822df0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  822e24:	test   $0x1,%al
  822e26:	je     822e40 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  822e28:	pxor   %xmm0,%xmm0
  822e2c:	pcmpgtb (%r12,%rcx,1),%xmm0
  822e32:	por    -0x77523a(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822e3a:	movdqa %xmm0,(%r12,%rcx,1)
  822e40:	cmp    $0x10,%rdx
  822e44:	jb     823093 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  822e4a:	mov    %rdx,%rdi
  822e4d:	mov    $0x10,%edx
  822e52:	add    %r12,%rdi
  822e55:	mov    %r12,%rsi
  822e58:	call   *0x65e442(%rip)        # e812a0 <memmove@GLIBC_2.2.5>
  822e5e:	xor    %r13d,%r13d
  822e61:	xor    %eax,%eax
  822e63:	jmp    822f96 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  822e68:	nopl   0x0(%rax,%rax,1)
  822e70:	lea    (%r12,%r14,1),%rsi
  822e74:	add    $0xfffffffffffffff0,%rsi
  822e78:	mov    0x20(%rsp),%rdi
  822e7d:	call   824a20 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822e82:	mov    0x8(%rbp),%rcx
  822e86:	mov    %rcx,%rdx
  822e89:	and    %rax,%rdx
  822e8c:	movdqu (%r12,%rdx,1),%xmm0
  822e92:	pmovmskb %xmm0,%esi
  822e96:	mov    %rdx,%rdi
  822e99:	test   %esi,%esi
  822e9b:	je     822f2b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  822ea1:	tzcnt  %esi,%esi
  822ea5:	add    %rdi,%rsi
  822ea8:	and    %rcx,%rsi
  822eab:	cmpb   $0x0,(%r12,%rsi,1)
  822eb0:	jns    822f52 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  822eb6:	mov    %r13,%rdi
  822eb9:	sub    %rdx,%rdi
  822ebc:	mov    %rsi,%r8
  822ebf:	sub    %rdx,%r8
  822ec2:	xor    %rdi,%r8
  822ec5:	and    %rcx,%r8
  822ec8:	cmp    $0x10,%r8
  822ecc:	jb     822f70 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  822ed2:	mov    %rsi,%rdx
  822ed5:	not    %rdx
  822ed8:	shl    $0x4,%rdx
  822edc:	add    %r12,%rdx
  822edf:	movzbl (%r12,%rsi,1),%edi
  822ee4:	shr    $0x39,%rax
  822ee8:	lea    -0x10(%rsi),%r8
  822eec:	and    %rcx,%r8
  822eef:	mov    %al,(%r12,%rsi,1)
  822ef3:	mov    0x0(%rbp),%r12
  822ef7:	mov    %al,0x10(%r12,%r8,1)
  822efc:	cmp    $0xff,%dil
  822f00:	je     822fbb <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  822f06:	mov    (%rbx),%rax
  822f09:	mov    (%rdx),%rcx
  822f0c:	mov    %rcx,(%rbx)
  822f0f:	mov    %rax,(%rdx)
  822f12:	mov    0x8(%rbx),%rax
  822f16:	mov    0x8(%rdx),%rcx
  822f1a:	mov    %rcx,0x8(%rbx)
  822f1e:	mov    %rax,0x8(%rdx)
  822f22:	mov    0x0(%rbp),%r12
  822f26:	jmp    822e70 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822f2b:	mov    $0x10,%r8d
  822f31:	mov    %rdx,%rdi
  822f34:	add    %r8,%rdi
  822f37:	and    %rcx,%rdi
  822f3a:	movdqu (%r12,%rdi,1),%xmm0
  822f40:	pmovmskb %xmm0,%esi
  822f44:	add    $0x10,%r8
  822f48:	test   %esi,%esi
  822f4a:	jne    822ea1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  822f50:	jmp    822f34 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  822f52:	movdqa (%r12),%xmm0
  822f58:	pmovmskb %xmm0,%esi
  822f5c:	tzcnt  %esi,%esi
  822f60:	jmp    822eb6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  822f65:	data16 cs nopw 0x0(%rax,%rax,1)
  822f70:	shr    $0x39,%rax
  822f74:	lea    -0x10(%r13),%rdx
  822f78:	and    %rdx,%rcx
  822f7b:	mov    %al,(%r12,%r13,1)
  822f7f:	mov    0x0(%rbp),%r12
  822f83:	mov    %al,0x10(%r12,%rcx,1)
  822f88:	mov    %r15,%rbx
  822f8b:	xor    %eax,%eax
  822f8d:	cmp    %rbx,%r13
  822f90:	lea    0x1(%r13),%r13
  822f94:	je     822fd8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  822f96:	cmp    (%r12,%r13,1),%al
  822f9a:	jno    822f8d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  822f9c:	mov    %rbx,%r15
  822f9f:	mov    %r13,%rbx
  822fa2:	not    %rbx
  822fa5:	shl    $0x4,%rbx
  822fa9:	add    %r12,%rbx
  822fac:	mov    %r13,%r14
  822faf:	neg    %r14
  822fb2:	shl    $0x4,%r14
  822fb6:	jmp    822e70 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822fbb:	lea    -0x10(%r13),%rax
  822fbf:	and    0x8(%rbp),%rax
  822fc3:	movb   $0xff,(%r12,%r13,1)
  822fc8:	movb   $0xff,0x10(%r12,%rax,1)
  822fce:	movdqu (%rbx),%xmm0
  822fd2:	movdqu %xmm0,(%rdx)
  822fd6:	jmp    822f88 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  822fd8:	mov    0x8(%rbp),%rcx
  822fdc:	mov    0x18(%rbp),%rdi
  822fe0:	lea    0x1(%rcx),%rax
  822fe4:	mov    %rax,%rdx
  822fe7:	shr    $0x3,%rdx
  822feb:	and    $0xfffffffffffffff8,%rax
  822fef:	sub    %rdx,%rax
  822ff2:	cmp    $0x8,%rcx
  822ff6:	cmovb  %rcx,%rax
  822ffa:	sub    %rdi,%rax
  822ffd:	mov    %rax,0x10(%rbp)
  823001:	mov    $0xffffffffffffffff,%rax
  823008:	add    $0x38,%rsp
  82300c:	pop    %rbx
  82300d:	pop    %r12
  82300f:	pop    %r13
  823011:	pop    %r14
  823013:	pop    %r15
  823015:	pop    %rbp
  823016:	ret
  823017:	mov    (%rsp),%rax
  82301b:	mov    0x28(%rsp),%r14
  823020:	jmp    823047 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  823022:	movzbl %r15b,%edi
  823026:	mov    $0x10,%esi
  82302b:	mov    %r13,%rdx
  82302e:	call   *0x65e274(%rip)        # e812a8 <_DYNAMIC+0x690>
  823034:	jmp    823008 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  823036:	mov    (%rsp),%rax
  82303a:	mov    (%rax),%rdi
  82303d:	mov    0x18(%rsp),%r8
  823042:	mov    0x10(%rsp),%r9
  823047:	sub    0x8(%rsp),%r14
  82304c:	mov    %r8,(%rax)
  82304f:	mov    %r9,0x8(%rax)
  823053:	mov    %r14,0x10(%rax)
  823057:	mov    $0xffffffffffffffff,%rax
  82305e:	mov    0x30(%rsp),%rsi
  823063:	test   %rsi,%rsi
  823066:	je     823008 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  823068:	mov    %rsi,%rcx
  82306b:	shl    $0x4,%rcx
  82306f:	add    $0x1f,%rcx
  823073:	and    $0xfffffffffffffff0,%rcx
  823077:	add    %rcx,%rsi
  82307a:	add    $0x11,%rsi
  82307e:	je     823008 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  823080:	sub    %rcx,%rdi
  823083:	mov    $0x10,%edx
  823088:	call   *0x65ddd2(%rip)        # e80e60 <_DYNAMIC+0x248>
  82308e:	jmp    823001 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  823093:	mov    $0x10,%edi
  823098:	jmp    822e52 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823250 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  823250:	mov    0x8(%rdi),%rsi
  823254:	test   %rsi,%rsi
  823257:	je     82327e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  823259:	mov    %rsi,%rax
  82325c:	shl    $0x5,%rax
  823260:	add    %rax,%rsi
  823263:	add    $0x31,%rsi
  823267:	je     82327e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  823269:	mov    (%rdi),%rdi
  82326c:	sub    %rax,%rdi
  82326f:	add    $0xffffffffffffffe0,%rdi
  823273:	mov    $0x10,%edx
  823278:	jmp    *0x65dbe2(%rip)        # e80e60 <_DYNAMIC+0x248>
  82327e:	ret

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823280 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  823280:	push   %rbx
  823281:	test   %rdi,%rdi
  823284:	je     8232e7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  823286:	mov    %rdi,%rbx
  823289:	mov    (%rdi),%rsi
  82328c:	test   %rsi,%rsi
  82328f:	je     8232a4 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  823291:	mov    0x8(%rbx),%rdi
  823295:	shl    $0x3,%rsi
  823299:	mov    $0x8,%edx
  82329e:	call   *0x65dbbc(%rip)        # e80e60 <_DYNAMIC+0x248>
  8232a4:	mov    0x20(%rbx),%rsi
  8232a8:	test   %rsi,%rsi
  8232ab:	je     8232d3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8232ad:	mov    %rsi,%rax
  8232b0:	shl    $0x4,%rax
  8232b4:	add    %rax,%rsi
  8232b7:	add    $0x21,%rsi
  8232bb:	je     8232d3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8232bd:	mov    0x18(%rbx),%rdi
  8232c1:	sub    %rax,%rdi
  8232c4:	add    $0xfffffffffffffff0,%rdi
  8232c8:	mov    $0x10,%edx
  8232cd:	call   *0x65db8d(%rip)        # e80e60 <_DYNAMIC+0x248>
  8232d3:	mov    $0x80,%esi
  8232d8:	mov    $0x8,%edx
  8232dd:	mov    %rbx,%rdi
  8232e0:	pop    %rbx
  8232e1:	jmp    *0x65db79(%rip)        # e80e60 <_DYNAMIC+0x248>
  8232e7:	pop    %rbx
  8232e8:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823510 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  823510:	push   %r14
  823512:	push   %rbx
  823513:	push   %rax
  823514:	mov    %rdi,%rbx
  823517:	mov    (%rdi),%rax
  82351a:	lock decq (%rax)
  82351e:	jne    823529 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  823520:	mov    %rbx,%rdi
  823523:	call   *0x65dbf7(%rip)        # e81120 <_DYNAMIC+0x508>
  823529:	mov    0x8(%rbx),%rax
  82352d:	lock decq (%rax)
  823531:	jne    823547 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  823533:	add    $0x8,%rbx
  823537:	mov    %rbx,%rdi
  82353a:	add    $0x8,%rsp
  82353e:	pop    %rbx
  82353f:	pop    %r14
  823541:	jmp    *0x65dbe1(%rip)        # e81128 <_DYNAMIC+0x510>
  823547:	add    $0x8,%rsp
  82354b:	pop    %rbx
  82354c:	pop    %r14
  82354e:	ret
  82354f:	mov    %rax,%r14
  823552:	mov    0x8(%rbx),%rax
  823556:	lock decq (%rax)
  82355a:	jne    823569 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  82355c:	add    $0x8,%rbx
  823560:	mov    %rbx,%rdi
  823563:	call   *0x65dbbf(%rip)        # e81128 <_DYNAMIC+0x510>
  823569:	mov    %r14,%rdi
  82356c:	call   e2d970 <_Unwind_Resume@plt>
  823571:	call   *0x65d8f1(%rip)        # e80e68 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823640 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  823640:	push   %rbx
  823641:	mov    %rdi,%rbx
  823644:	mov    (%rdi),%rsi
  823647:	test   %rsi,%rsi
  82364a:	je     82365f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  82364c:	mov    0x8(%rbx),%rdi
  823650:	shl    $0x3,%rsi
  823654:	mov    $0x8,%edx
  823659:	call   *0x65d801(%rip)        # e80e60 <_DYNAMIC+0x248>
  82365f:	mov    0x20(%rbx),%rsi
  823663:	test   %rsi,%rsi
  823666:	je     82368f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823668:	mov    %rsi,%rax
  82366b:	shl    $0x4,%rax
  82366f:	add    %rax,%rsi
  823672:	add    $0x21,%rsi
  823676:	je     82368f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823678:	mov    0x18(%rbx),%rdi
  82367c:	sub    %rax,%rdi
  82367f:	add    $0xfffffffffffffff0,%rdi
  823683:	mov    $0x10,%edx
  823688:	pop    %rbx
  823689:	jmp    *0x65d7d1(%rip)        # e80e60 <_DYNAMIC+0x248>
  82368f:	pop    %rbx
  823690:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008236a0 <<gpui_gpu::renderer::images::Images>::metadata>:
  8236a0:	push   %r15
  8236a2:	push   %r14
  8236a4:	push   %rbx
  8236a5:	sub    $0x10,%rsp
  8236a9:	mov    %rsi,0x8(%rsp)
  8236ae:	cmpq   $0x0,0x30(%rdi)
  8236b3:	je     82377d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  8236b9:	mov    %edx,%ebx
  8236bb:	mov    %rsi,%r14
  8236be:	mov    %rdi,%r15
  8236c1:	add    $0x38,%rdi
  8236c5:	lea    0x8(%rsp),%rsi
  8236ca:	call   824a20 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8236cf:	mov    %rax,%rsi
  8236d2:	shr    $0x39,%rsi
  8236d6:	mov    0x18(%r15),%rcx
  8236da:	mov    0x20(%r15),%rdx
  8236de:	movd   %esi,%xmm0
  8236e2:	punpcklbw %xmm0,%xmm0
  8236e6:	pshuflw $0x0,%xmm0,%xmm0
  8236eb:	pshufd $0x44,%xmm0,%xmm0
  8236f0:	xor    %esi,%esi
  8236f2:	pcmpeqd %xmm1,%xmm1
  8236f6:	and    %rdx,%rax
  8236f9:	movdqu (%rcx,%rax,1),%xmm2
  8236fe:	movdqa %xmm2,%xmm3
  823702:	pcmpeqb %xmm0,%xmm3
  823706:	pmovmskb %xmm3,%edi
  82370a:	test   %edi,%edi
  82370c:	je     823740 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  82370e:	tzcnt  %edi,%r9d
  823713:	add    %rax,%r9
  823716:	and    %rdx,%r9
  823719:	shl    $0x4,%r9
  82371d:	mov    %rcx,%r8
  823720:	sub    %r9,%r8
  823723:	cmp    -0x10(%r8),%r14
  823727:	je     823759 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  823729:	lea    -0x1(%rdi),%r8d
  82372d:	and    %di,%r8w
  823731:	mov    %r8d,%edi
  823734:	jne    82370e <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  823736:	cs nopw 0x0(%rax,%rax,1)
  823740:	pcmpeqb %xmm1,%xmm2
  823744:	pmovmskb %xmm2,%edi
  823748:	test   %edi,%edi
  82374a:	jne    82377d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  82374c:	add    %rsi,%rax
  82374f:	add    $0x10,%rax
  823753:	add    $0x10,%rsi
  823757:	jmp    8236f6 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  823759:	mov    -0x8(%r8),%eax
  82375d:	movzbl %bl,%ecx
  823760:	or     -0x4(%r8),%ecx
  823764:	shl    $0x20,%rcx
  823768:	or     %rax,%rcx
  82376b:	mov    $0x80000000,%eax
  823770:	or     %rcx,%rax
  823773:	add    $0x10,%rsp
  823777:	pop    %rbx
  823778:	pop    %r14
  82377a:	pop    %r15
  82377c:	ret
  82377d:	lea    -0x74ea40(%rip),%rdi        # d4d44 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  823784:	lea    0x60c0dd(%rip),%rdx        # e2f868 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456>
  82378b:	mov    $0x16,%esi
  823790:	call   *0x65da22(%rip)        # e811b8 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2648 frame=536

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823a10 <gpui_gpu::renderer::images::prepare>:
  823a10:	push   %rbp
  823a11:	push   %r15
  823a13:	push   %r14
  823a15:	push   %r13
  823a17:	push   %r12
  823a19:	push   %rbx
  823a1a:	sub    $0x1e8,%rsp
  823a21:	mov    %r9,%r12
  823a24:	mov    %rcx,%r13
  823a27:	mov    %rdx,0xb0(%rsp)
  823a2f:	mov    %rsi,(%rsp)
  823a33:	mov    %rdi,%r15
  823a36:	mov    0x220(%rsp),%rax
  823a3e:	mov    0x10(%rax),%r14
  823a42:	mov    0x118(%r14),%rax
  823a49:	add    $0x118,%r14
  823a50:	test   %rax,%rax
  823a53:	mov    %r14,%rcx
  823a56:	cmove  %rax,%rcx
  823a5a:	je     823aec <gpui_gpu::renderer::images::prepare+0xdc>
  823a60:	mov    0x10(%rax),%rax
  823a64:	mov    (%r8),%rbp
  823a67:	mov    %rax,0x10(%rsp)
  823a6c:	test   %rax,%rax
  823a6f:	je     823aef <gpui_gpu::renderer::images::prepare+0xdf>
  823a71:	mov    %rcx,0xa0(%rsp)
  823a79:	test   %rbp,%rbp
  823a7c:	je     823c38 <gpui_gpu::renderer::images::prepare+0x228>
  823a82:	cmp    0x48(%rbp),%r12
  823a86:	ja     823c38 <gpui_gpu::renderer::images::prepare+0x228>
  823a8c:	mov    0x8(%rbp),%rdi
  823a90:	mov    0x10(%rbp),%rax
  823a94:	lea    (%rdi,%rax,8),%rsi
  823a98:	movq   $0x1,0xd0(%rsp)
  823aa4:	mov    %r14,0xd8(%rsp)
  823aac:	movq   $0x0,0xe0(%rsp)
  823ab8:	movq   $0x0,0xf0(%rsp)
  823ac4:	lea    0xd0(%rsp),%rdx
  823acc:	mov    %r8,%rbx
  823acf:	call   8245d0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  823ad4:	mov    %rbx,%r8
  823ad7:	test   %al,%al
  823ad9:	je     823c38 <gpui_gpu::renderer::images::prepare+0x228>
  823adf:	movq   $0x0,0x60(%rbp)
  823ae7:	jmp    823c1c <gpui_gpu::renderer::images::prepare+0x20c>
  823aec:	mov    (%r8),%rbp
  823aef:	movq   $0x0,(%r8)
  823af6:	test   %rbp,%rbp
  823af9:	je     823c1c <gpui_gpu::renderer::images::prepare+0x20c>
  823aff:	mov    0x0(%rbp),%rsi
  823b03:	test   %rsi,%rsi
  823b06:	je     823b1b <gpui_gpu::renderer::images::prepare+0x10b>
  823b08:	mov    0x8(%rbp),%rdi
  823b0c:	shl    $0x3,%rsi
  823b10:	mov    $0x8,%edx
  823b15:	call   *0x65d345(%rip)        # e80e60 <_DYNAMIC+0x248>
  823b1b:	mov    0x20(%rbp),%rsi
  823b1f:	test   %rsi,%rsi
  823b22:	je     823b4a <gpui_gpu::renderer::images::prepare+0x13a>
  823b24:	mov    %rsi,%rax
  823b27:	shl    $0x4,%rax
  823b2b:	add    %rax,%rsi
  823b2e:	add    $0x21,%rsi
  823b32:	je     823b4a <gpui_gpu::renderer::images::prepare+0x13a>
  823b34:	mov    0x18(%rbp),%rdi
  823b38:	sub    %rax,%rdi
  823b3b:	add    $0xfffffffffffffff0,%rdi
  823b3f:	mov    $0x10,%edx
  823b44:	call   *0x65d316(%rip)        # e80e60 <_DYNAMIC+0x248>
  823b4a:	mov    $0x80,%esi
  823b4f:	mov    $0x8,%edx
  823b54:	mov    %rbp,%rdi
  823b57:	call   *0x65d303(%rip)        # e80e60 <_DYNAMIC+0x248>
  823b5d:	shl    $0x4,%r12
  823b61:	cmp    $0x101,%r12
  823b68:	mov    $0x100,%eax
  823b6d:	cmovae %r12,%rax
  823b71:	dec    %rax
  823b74:	bsr    %rax,%rcx
  823b78:	not    %ecx
  823b7a:	mov    $0xffffffffffffffff,%rbx
  823b81:	shr    %cl,%rbx
  823b84:	inc    %rbx
  823b87:	lea    -0x74ee34(%rip),%rax        # d4d5a <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x16>
  823b8e:	mov    %rax,0x18(%rsp)
  823b93:	movq   $0xa,0x20(%rsp)
  823b9c:	mov    %rbx,0x28(%rsp)
  823ba1:	movl   $0x88,0x30(%rsp)
  823ba9:	movb   $0x0,0x34(%rsp)
  823bae:	lea    0xd0(%rsp),%rdi
  823bb6:	lea    0x18(%rsp),%rdx
  823bbb:	mov    (%rsp),%rsi
  823bbf:	call   *0x65d673(%rip)        # e81238 <_DYNAMIC+0x620>
  823bc5:	mov    %rbx,0xf0(%rsp)
  823bcd:	mov    0x0(%r13),%rax
  823bd1:	lock decq (%rax)
  823bd5:	jne    823be0 <gpui_gpu::renderer::images::prepare+0x1d0>
  823bd7:	mov    %r13,%rdi
  823bda:	call   *0x65d540(%rip)        # e81120 <_DYNAMIC+0x508>
  823be0:	mov    0x8(%r13),%rax
  823be4:	lock decq (%rax)
  823be8:	jne    823bf4 <gpui_gpu::renderer::images::prepare+0x1e4>
  823bea:	lea    0x8(%r13),%rdi
  823bee:	call   *0x65d534(%rip)        # e81128 <_DYNAMIC+0x510>
  823bf4:	mov    0xf0(%rsp),%rax
  823bfc:	mov    %rax,0x20(%r13)
  823c00:	movdqu 0xd0(%rsp),%xmm0
  823c09:	movups 0xe0(%rsp),%xmm1
  823c11:	movups %xmm1,0x10(%r13)
  823c16:	movdqu %xmm0,0x0(%r13)
  823c1c:	movl   $0xffffffff,(%r15)
  823c23:	mov    %r15,%rax
  823c26:	add    $0x1e8,%rsp
  823c2d:	pop    %rbx
  823c2e:	pop    %r12
  823c30:	pop    %r13
  823c32:	pop    %r14
  823c34:	pop    %r15
  823c36:	pop    %rbp
  823c37:	ret
  823c38:	cmp    $0x1,%r12
  823c3c:	mov    %r12,%rax
  823c3f:	adc    $0xffffffffffffffff,%rax
  823c43:	bsr    %rax,%rcx
  823c47:	not    %ecx
  823c49:	mov    $0xffffffffffffffff,%rax
  823c50:	shr    %cl,%rax
  823c53:	cmp    $0x2,%r12
  823c57:	mov    $0x0,%r12d
  823c5d:	cmovae %rax,%r12
  823c61:	inc    %r12
  823c64:	je     824358 <gpui_gpu::renderer::images::prepare+0x948>
  823c6a:	mov    %r8,0xc8(%rsp)
  823c72:	mov    %fs:0x0,%rax
  823c7b:	lea    -0x28(%rax),%rax
  823c82:	mov    %rax,%rcx
  823c85:	cmpb   $0x1,0x10(%rax)
  823c89:	mov    %r15,0xa8(%rsp)
  823c91:	mov    %r13,0x8(%rsp)
  823c96:	jne    824364 <gpui_gpu::renderer::images::prepare+0x954>
  823c9c:	mov    (%rcx),%rax
  823c9f:	mov    0x8(%rcx),%rdx
  823ca3:	mov    0x10(%rsp),%rbx
  823ca8:	lea    0x1(%rax),%rsi
  823cac:	mov    %rsi,(%rcx)
  823caf:	movq   $0x0,0x18(%rsp)
  823cb8:	movq   $0x8,0x20(%rsp)
  823cc1:	movq   $0x0,0x28(%rsp)
  823cca:	movups 0x60bbaf(%rip),%xmm0        # e2f880 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x18>
  823cd1:	movups %xmm0,0x30(%rsp)
  823cd6:	movdqu 0x60bbb2(%rip),%xmm0        # e2f890 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x28>
  823cde:	movdqu %xmm0,0x40(%rsp)
  823ce4:	mov    %rax,0x50(%rsp)
  823ce9:	mov    %rdx,0x58(%rsp)
  823cee:	mov    %r12,0x60(%rsp)
  823cf3:	pxor   %xmm0,%xmm0
  823cf7:	movdqu %xmm0,0x68(%rsp)
  823cfd:	movdqu %xmm0,0x78(%rsp)
  823d03:	movdqu %xmm0,0x88(%rsp)
  823d0c:	lea    0xd0(%rsp),%rdi
  823d14:	mov    $0x8,%edx
  823d19:	mov    $0x8,%r8d
  823d1f:	mov    $0x8,%r9d
  823d25:	xor    %esi,%esi
  823d27:	mov    %rbx,%rcx
  823d2a:	call   8271f0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823d2f:	cmpl   $0x1,0xd0(%rsp)
  823d37:	jne    823da4 <gpui_gpu::renderer::images::prepare+0x394>
  823d39:	mov    0xa8(%rsp),%r15
  823d41:	movl   $0x6,(%r15)
  823d48:	mov    0x18(%rsp),%rsi
  823d4d:	test   %rsi,%rsi
  823d50:	je     823d66 <gpui_gpu::renderer::images::prepare+0x356>
  823d52:	mov    0x20(%rsp),%rdi
  823d57:	shl    $0x3,%rsi
  823d5b:	mov    $0x8,%edx
  823d60:	call   *0x65d0fa(%rip)        # e80e60 <_DYNAMIC+0x248>
  823d66:	mov    0x38(%rsp),%rsi
  823d6b:	test   %rsi,%rsi
  823d6e:	je     823c23 <gpui_gpu::renderer::images::prepare+0x213>
  823d74:	mov    %rsi,%rax
  823d77:	shl    $0x4,%rax
  823d7b:	add    %rax,%rsi
  823d7e:	add    $0x21,%rsi
  823d82:	je     823c23 <gpui_gpu::renderer::images::prepare+0x213>
  823d88:	mov    0x30(%rsp),%rdi
  823d8d:	sub    %rax,%rdi
  823d90:	add    $0xfffffffffffffff0,%rdi
  823d94:	mov    $0x10,%edx
  823d99:	call   *0x65d0c1(%rip)        # e80e60 <_DYNAMIC+0x248>
  823d9f:	jmp    823c23 <gpui_gpu::renderer::images::prepare+0x213>
  823da4:	mov    %r12,0x98(%rsp)
  823dac:	mov    %rbp,0xc0(%rsp)
  823db4:	mov    0xd8(%rsp),%rax
  823dbc:	mov    %rax,0x20(%rsp)
  823dc1:	mov    %rbx,0x18(%rsp)
  823dc6:	cmp    0x40(%rsp),%rbx
  823dcb:	ja     824380 <gpui_gpu::renderer::images::prepare+0x970>
  823dd1:	xor    %r12d,%r12d
  823dd4:	mov    0x98(%rsp),%r15
  823ddc:	jmp    823df8 <gpui_gpu::renderer::images::prepare+0x3e8>
  823dde:	xchg   %ax,%ax
  823de0:	add    $0x8,%r12
  823de4:	mov    0x20(%rsp),%rax
  823de9:	mov    %rbx,(%rax,%r15,8)
  823ded:	inc    %r15
  823df0:	mov    %r15,0x28(%rsp)
  823df5:	mov    %r13,%r15
  823df8:	test   %r12,%r12
  823dfb:	je     823e20 <gpui_gpu::renderer::images::prepare+0x410>
  823dfd:	cmp    %rbp,%r12
  823e00:	je     823e20 <gpui_gpu::renderer::images::prepare+0x410>
  823e02:	mov    (%r12),%rcx
  823e06:	cmpb   $0x0,0x10(%rcx)
  823e0a:	je     823e4e <gpui_gpu::renderer::images::prepare+0x43e>
  823e0c:	mov    0x20(%rcx),%rax
  823e10:	shl    $0x4,%rax
  823e14:	mov    $0x8,%r8d
  823e1a:	jmp    823e61 <gpui_gpu::renderer::images::prepare+0x451>
  823e1c:	nopl   0x0(%rax)
  823e20:	test   %r14,%r14
  823e23:	je     823ee8 <gpui_gpu::renderer::images::prepare+0x4d8>
  823e29:	mov    (%r14),%rax
  823e2c:	mov    0x10(%rax),%rcx
  823e30:	test   %rcx,%rcx
  823e33:	je     823ee8 <gpui_gpu::renderer::images::prepare+0x4d8>
  823e39:	mov    0x8(%rax),%r12
  823e3d:	lea    (%r12,%rcx,8),%rbp
  823e41:	xor    %r14d,%r14d
  823e44:	mov    (%r12),%rcx
  823e48:	cmpb   $0x0,0x10(%rcx)
  823e4c:	jne    823e0c <gpui_gpu::renderer::images::prepare+0x3fc>
  823e4e:	movzbl 0x11(%rcx),%edx
  823e52:	movzbl 0x12(%rcx),%esi
  823e56:	mov    0x20(%rcx),%rax
  823e5a:	shl    $0x2,%edx
  823e5d:	lea    (%rdx,%rsi,2),%r8d
  823e61:	mov    0x70(%rsp),%rdx
  823e66:	add    %rax,%rdx
  823e69:	jb     823d39 <gpui_gpu::renderer::images::prepare+0x329>
  823e6f:	mov    0x28(%rcx),%rbx
  823e73:	mov    %rdx,0x70(%rsp)
  823e78:	cmp    $0x4000000,%rdx
  823e7f:	ja     823d39 <gpui_gpu::renderer::images::prepare+0x329>
  823e85:	mov    %r15,%rcx
  823e88:	shr    $0x20,%rcx
  823e8c:	jne    823d39 <gpui_gpu::renderer::images::prepare+0x329>
  823e92:	test   %r15d,%r15d
  823e95:	js     823d39 <gpui_gpu::renderer::images::prepare+0x329>
  823e9b:	mov    %rax,%r13
  823e9e:	shr    $0x4,%r13
  823ea2:	and    $0xf,%eax
  823ea5:	add    %r15,%r13
  823ea8:	cmp    $0x1,%rax
  823eac:	sbb    $0xffffffffffffffff,%r13
  823eb0:	lea    0xd0(%rsp),%rdi
  823eb8:	lea    0x30(%rsp),%rsi
  823ebd:	mov    %rbx,%rdx
  823ec0:	mov    %r15d,%ecx
  823ec3:	call   826080 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  823ec8:	mov    0x28(%rsp),%r15
  823ecd:	cmp    0x18(%rsp),%r15
  823ed2:	jne    823de0 <gpui_gpu::renderer::images::prepare+0x3d0>
  823ed8:	lea    0x18(%rsp),%rdi
  823edd:	call   *0x65d3fd(%rip)        # e812e0 <_DYNAMIC+0x6c8>
  823ee3:	jmp    823de0 <gpui_gpu::renderer::images::prepare+0x3d0>
  823ee8:	movabs $0xffffffffffffff0,%rax
  823ef2:	cmp    %rax,%r15
  823ef5:	ja     823d39 <gpui_gpu::renderer::images::prepare+0x329>
  823efb:	lea    0xd0(%rsp),%rdi
  823f03:	mov    (%rsp),%rsi
  823f07:	call   *0x65d3db(%rip)        # e812e8 <_DYNAMIC+0x6d0>
  823f0d:	mov    %r15,%rbx
  823f10:	shl    $0x4,%rbx
  823f14:	add    $0xff,%rbx
  823f1b:	and    $0xffffffffffffff00,%rbx
  823f22:	cmp    0x120(%rsp),%rbx
  823f2a:	ja     823d39 <gpui_gpu::renderer::images::prepare+0x329>
  823f30:	lea    0xd0(%rsp),%rdi
  823f38:	mov    (%rsp),%rsi
  823f3c:	call   *0x65d3a6(%rip)        # e812e8 <_DYNAMIC+0x6d0>
  823f42:	cmp    0x130(%rsp),%rbx
  823f4a:	ja     823d39 <gpui_gpu::renderer::images::prepare+0x329>
  823f50:	mov    0x8(%rsp),%rax
  823f55:	mov    0x20(%rax),%rax
  823f59:	cmp    %rbx,%rax
  823f5c:	jb     823f84 <gpui_gpu::renderer::images::prepare+0x574>
  823f5e:	lea    0x0(,%rbx,4),%rcx
  823f66:	movabs $0x3fffffffffffff1,%rdx
  823f70:	cmp    %rdx,%r15
  823f73:	setb   %dl
  823f76:	cmp    %rcx,%rax
  823f79:	seta   %al
  823f7c:	test   %al,%dl
  823f7e:	je     824012 <gpui_gpu::renderer::images::prepare+0x602>
  823f84:	lea    -0x74f227(%rip),%rax        # d4d64 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x20>
  823f8b:	mov    %rax,0x1c8(%rsp)
  823f93:	movq   $0x1d,0x1d0(%rsp)
  823f9f:	mov    %rbx,0x1d8(%rsp)
  823fa7:	movl   $0x88,0x1e0(%rsp)
  823fb2:	movb   $0x0,0x1e4(%rsp)
  823fba:	lea    0xd0(%rsp),%rdi
  823fc2:	lea    0x1c8(%rsp),%rdx
  823fca:	mov    (%rsp),%rsi
  823fce:	call   *0x65d264(%rip)        # e81238 <_DYNAMIC+0x620>
  823fd4:	mov    %rbx,0xf0(%rsp)
  823fdc:	mov    0x8(%rsp),%r14
  823fe1:	mov    %r14,%rdi
  823fe4:	call   823510 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  823fe9:	mov    0xf0(%rsp),%rax
  823ff1:	mov    %rax,0x20(%r14)
  823ff5:	movdqu 0xd0(%rsp),%xmm0
  823ffe:	movdqu 0xe0(%rsp),%xmm1
  824007:	movdqu %xmm1,0x10(%r14)
  82400d:	movdqu %xmm0,(%r14)
  824012:	movq   $0x0,(%rsp)
  82401a:	mov    0x65d1c7(%rip),%r14        # e811e8 <_DYNAMIC+0x5d0>
  824021:	mov    (%rsp),%rdx
  824025:	test   %rdx,%rdx
  824028:	je     824034 <gpui_gpu::renderer::images::prepare+0x624>
  82402a:	cmp    0xb8(%rsp),%rdx
  824032:	jne    824071 <gpui_gpu::renderer::images::prepare+0x661>
  824034:	mov    0xa0(%rsp),%rax
  82403c:	test   %rax,%rax
  82403f:	je     8241f4 <gpui_gpu::renderer::images::prepare+0x7e4>
  824045:	mov    (%rax),%rax
  824048:	mov    0x10(%rax),%rcx
  82404c:	test   %rcx,%rcx
  82404f:	je     8241f4 <gpui_gpu::renderer::images::prepare+0x7e4>
  824055:	mov    0x8(%rax),%rdx
  824059:	lea    (%rdx,%rcx,8),%rax
  82405d:	mov    %rax,0xb8(%rsp)
  824065:	movq   $0x0,0xa0(%rsp)
  824071:	mov    (%rdx),%rax
  824074:	mov    0x28(%rax),%r12
  824078:	movzbl 0x10(%rax),%ebx
  82407c:	mov    0x18(%rax),%rbp
  824080:	mov    0x20(%rax),%r13
  824084:	mov    %r12,0xd0(%rsp)
  82408c:	cmpq   $0x0,0x48(%rsp)
  824092:	je     8241d9 <gpui_gpu::renderer::images::prepare+0x7c9>
  824098:	add    $0x8,%rdx
  82409c:	mov    %rdx,(%rsp)
  8240a0:	lea    0x50(%rsp),%rdi
  8240a5:	lea    0xd0(%rsp),%rsi
  8240ad:	call   824a20 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8240b2:	mov    %rax,%rsi
  8240b5:	shr    $0x39,%rsi
  8240b9:	mov    0x30(%rsp),%rcx
  8240be:	mov    0x38(%rsp),%rdx
  8240c3:	movd   %esi,%xmm0
  8240c7:	punpcklbw %xmm0,%xmm0
  8240cb:	pshuflw $0x0,%xmm0,%xmm0
  8240d0:	pshufd $0x44,%xmm0,%xmm0
  8240d5:	xor    %esi,%esi
  8240d7:	and    %rdx,%rax
  8240da:	movdqu (%rcx,%rax,1),%xmm1
  8240df:	movdqa %xmm1,%xmm2
  8240e3:	pcmpeqb %xmm0,%xmm2
  8240e7:	pmovmskb %xmm2,%edi
  8240eb:	test   %edi,%edi
  8240ed:	je     824117 <gpui_gpu::renderer::images::prepare+0x707>
  8240ef:	tzcnt  %edi,%r9d
  8240f4:	add    %rax,%r9
  8240f7:	and    %rdx,%r9
  8240fa:	shl    $0x4,%r9
  8240fe:	mov    %rcx,%r8
  824101:	sub    %r9,%r8
  824104:	cmp    -0x10(%r8),%r12
  824108:	je     824138 <gpui_gpu::renderer::images::prepare+0x728>
  82410a:	lea    -0x1(%rdi),%r8d
  82410e:	and    %di,%r8w
  824112:	mov    %r8d,%edi
  824115:	jne    8240ef <gpui_gpu::renderer::images::prepare+0x6df>
  824117:	pcmpeqd %xmm2,%xmm2
  82411b:	pcmpeqb %xmm2,%xmm1
  82411f:	pmovmskb %xmm1,%edi
  824123:	test   %edi,%edi
  824125:	jne    8241d9 <gpui_gpu::renderer::images::prepare+0x7c9>
  82412b:	add    %rsi,%rax
  82412e:	add    $0x10,%rax
  824132:	add    $0x10,%rsi
  824136:	jmp    8240d7 <gpui_gpu::renderer::images::prepare+0x6c7>
  824138:	mov    -0x8(%r8),%r12d
  82413c:	shl    $0x4,%r12
  824140:	test   %bl,%bl
  824142:	je     824197 <gpui_gpu::renderer::images::prepare+0x787>
  824144:	test   %r13,%r13
  824147:	je     824021 <gpui_gpu::renderer::images::prepare+0x611>
  82414d:	nopl   (%rax)
  824150:	cmp    $0x1000,%r13
  824157:	mov    $0x1000,%r15d
  82415d:	cmovb  %r13,%r15
  824161:	mov    %r15d,%ebx
  824164:	shl    $0x4,%ebx
  824167:	mov    0xb0(%rsp),%rdi
  82416f:	mov    0x8(%rsp),%rsi
  824174:	mov    %r12,%rdx
  824177:	mov    %rbp,%rcx
  82417a:	mov    %rbx,%r8
  82417d:	call   *%r14
  824180:	mov    %r15,%rax
  824183:	shl    $0x4,%rax
  824187:	add    %rax,%rbp
  82418a:	add    %rbx,%r12
  82418d:	sub    %r15,%r13
  824190:	jne    824150 <gpui_gpu::renderer::images::prepare+0x740>
  824192:	jmp    824021 <gpui_gpu::renderer::images::prepare+0x611>
  824197:	test   %r13,%r13
  82419a:	je     824021 <gpui_gpu::renderer::images::prepare+0x611>
  8241a0:	cmp    $0x10000,%r13
  8241a7:	mov    $0x10000,%ebx
  8241ac:	cmovb  %r13,%rbx
  8241b0:	mov    0xb0(%rsp),%rdi
  8241b8:	mov    0x8(%rsp),%rsi
  8241bd:	mov    %r12,%rdx
  8241c0:	mov    %rbp,%rcx
  8241c3:	mov    %rbx,%r8
  8241c6:	call   *%r14
  8241c9:	add    %rbx,%rbp
  8241cc:	add    %rbx,%r12
  8241cf:	sub    %rbx,%r13
  8241d2:	jne    8241a0 <gpui_gpu::renderer::images::prepare+0x790>
  8241d4:	jmp    824021 <gpui_gpu::renderer::images::prepare+0x611>
  8241d9:	lea    -0x74f49c(%rip),%rdi        # d4d44 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  8241e0:	lea    0x60b6b9(%rip),%rdx        # e2f8a0 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x38>
  8241e7:	mov    $0x16,%esi
  8241ec:	call   *0x65cfc6(%rip)        # e811b8 <_DYNAMIC+0x5a0>
  8241f2:	ud2
  8241f4:	mov    0x10(%rsp),%rax
  8241f9:	mov    %rax,0x68(%rsp)
  8241fe:	mov    0x70(%rsp),%rax
  824203:	mov    %rax,0x78(%rsp)
  824208:	mov    0x98(%rsp),%rax
  824210:	shl    $0x4,%rax
  824214:	mov    %rax,0x80(%rsp)
  82421c:	mov    0x8(%rsp),%rax
  824221:	mov    0x20(%rax),%rax
  824225:	mov    %rax,0x88(%rsp)
  82422d:	mov    0x40(%rsp),%rax
  824232:	add    0x48(%rsp),%rax
  824237:	mov    %rax,0x90(%rsp)
  82423f:	mov    0x88(%rsp),%rax
  824247:	mov    %rax,0x140(%rsp)
  82424f:	mov    0x90(%rsp),%rax
  824257:	mov    %rax,0x148(%rsp)
  82425f:	mov    0x78(%rsp),%rax
  824264:	mov    %rax,0x130(%rsp)
  82426c:	mov    0x80(%rsp),%rax
  824274:	mov    %rax,0x138(%rsp)
  82427c:	movups 0x68(%rsp),%xmm0
  824281:	movaps %xmm0,0x120(%rsp)
  824289:	movups 0x58(%rsp),%xmm0
  82428e:	movaps %xmm0,0x110(%rsp)
  824296:	movups 0x48(%rsp),%xmm0
  82429b:	movaps %xmm0,0x100(%rsp)
  8242a3:	movups 0x18(%rsp),%xmm0
  8242a8:	movups 0x28(%rsp),%xmm1
  8242ad:	movups 0x38(%rsp),%xmm2
  8242b2:	movaps %xmm2,0xf0(%rsp)
  8242ba:	movaps %xmm1,0xe0(%rsp)
  8242c2:	movaps %xmm0,0xd0(%rsp)
  8242ca:	call   8239e0 <alloc::boxed::box_new_uninit>
  8242cf:	mov    %rax,%rbx
  8242d2:	movaps 0x140(%rsp),%xmm0
  8242da:	movups %xmm0,0x70(%rax)
  8242de:	movaps 0x130(%rsp),%xmm0
  8242e6:	movups %xmm0,0x60(%rax)
  8242ea:	movaps 0x120(%rsp),%xmm0
  8242f2:	movups %xmm0,0x50(%rax)
  8242f6:	movaps 0x110(%rsp),%xmm0
  8242fe:	movups %xmm0,0x40(%rax)
  824302:	movdqa 0xd0(%rsp),%xmm0
  82430b:	movaps 0xe0(%rsp),%xmm1
  824313:	movaps 0xf0(%rsp),%xmm2
  82431b:	movaps 0x100(%rsp),%xmm3
  824323:	movups %xmm3,0x30(%rax)
  824327:	movups %xmm2,0x20(%rax)
  82432b:	movups %xmm1,0x10(%rax)
  82432f:	movdqu %xmm0,(%rax)
  824333:	mov    0xc0(%rsp),%rdi
  82433b:	call   823280 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  824340:	mov    0xc8(%rsp),%rax
  824348:	mov    %rbx,(%rax)
  82434b:	mov    0xa8(%rsp),%r15
  824353:	jmp    823c1c <gpui_gpu::renderer::images::prepare+0x20c>
  824358:	movl   $0x6,(%r15)
  82435f:	jmp    823c23 <gpui_gpu::renderer::images::prepare+0x213>
  824364:	mov    %rcx,%rbx
  824367:	call   *0x65ced3(%rip)        # e81240 <_DYNAMIC+0x628>
  82436d:	mov    %rbx,%rcx
  824370:	mov    %rax,(%rbx)
  824373:	mov    %rdx,0x8(%rbx)
  824377:	movb   $0x1,0x10(%rbx)
  82437b:	jmp    823ca3 <gpui_gpu::renderer::images::prepare+0x293>
  824380:	lea    0x30(%rsp),%rdi
  824385:	mov    0x10(%rsp),%rsi
  82438a:	lea    0x50(%rsp),%rdx
  82438f:	xor    %ecx,%ecx
  824391:	call   *0x65cf21(%rip)        # e812b8 <_DYNAMIC+0x6a0>
  824397:	cmp    $0xffffffffffffffff,%rax
  82439b:	jne    823d39 <gpui_gpu::renderer::images::prepare+0x329>
  8243a1:	jmp    823dd1 <gpui_gpu::renderer::images::prepare+0x3c1>
  8243a6:	mov    %rax,%rbx
  8243a9:	lea    0xd0(%rsp),%rdi
  8243b1:	call   823640 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8243b6:	mov    %rbx,%rdi
  8243b9:	call   e2d970 <_Unwind_Resume@plt>
  8243be:	mov    %rax,%rbx
  8243c1:	mov    0xf0(%rsp),%rax
  8243c9:	mov    %rax,0x20(%r14)
  8243cd:	movups 0xd0(%rsp),%xmm0
  8243d5:	movups 0xe0(%rsp),%xmm1
  8243dd:	movups %xmm1,0x10(%r14)
  8243e2:	movups %xmm0,(%r14)
  8243e6:	lea    0x18(%rsp),%rdi
  8243eb:	call   823640 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8243f0:	mov    %rbx,%rdi
  8243f3:	call   e2d970 <_Unwind_Resume@plt>
  8243f8:	mov    %r13,%r14
  8243fb:	mov    %rax,%rbx
  8243fe:	jmp    82441a <gpui_gpu::renderer::images::prepare+0xa0a>
  824400:	mov    %rax,%rbx
  824403:	mov    %r13,%r14
  824406:	mov    0x8(%r13),%rax
  82440a:	lock decq (%rax)
  82440e:	jne    82441a <gpui_gpu::renderer::images::prepare+0xa0a>
  824410:	lea    0x8(%r14),%rdi
  824414:	call   *0x65cd0e(%rip)        # e81128 <_DYNAMIC+0x510>
  82441a:	mov    0xf0(%rsp),%rax
  824422:	mov    %rax,0x20(%r14)
  824426:	movups 0xd0(%rsp),%xmm0
  82442e:	movups 0xe0(%rsp),%xmm1
  824436:	movups %xmm1,0x10(%r14)
  82443b:	movups %xmm0,(%r14)
  82443f:	mov    %rbx,%rdi
  824442:	call   e2d970 <_Unwind_Resume@plt>
  824447:	call   *0x65ca1b(%rip)        # e80e68 <_DYNAMIC+0x250>
  82444d:	jmp    824453 <gpui_gpu::renderer::images::prepare+0xa43>
  82444f:	jmp    824453 <gpui_gpu::renderer::images::prepare+0xa43>
  824451:	jmp    824453 <gpui_gpu::renderer::images::prepare+0xa43>
  824453:	mov    %rax,%rbx
  824456:	lea    0x18(%rsp),%rdi
  82445b:	call   823640 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  824460:	mov    %rbx,%rdi
  824463:	call   e2d970 <_Unwind_Resume@plt>

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008245d0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  8245d0:	push   %r15
  8245d2:	push   %r14
  8245d4:	push   %rbx
  8245d5:	mov    (%rdx),%r9
  8245d8:	mov    0x8(%rdx),%r11
  8245dc:	mov    0x10(%rdx),%rbx
  8245e0:	mov    0x18(%rdx),%r10
  8245e4:	mov    0x20(%rdx),%r8
  8245e8:	mov    0x28(%rdx),%rcx
  8245ec:	test   $0x1,%r9b
  8245f0:	jne    82468a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  8245f6:	mov    %rbx,%rax
  8245f9:	jmp    82461b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  8245fb:	nopl   0x0(%rax,%rax,1)
  824600:	lea    0x8(%rax),%rbx
  824604:	mov    %rbx,%r14
  824607:	add    $0x8,%rdi
  82460b:	mov    (%rax),%r15
  82460e:	mov    %r14,%rax
  824611:	cmp    0x28(%r15),%rdx
  824615:	jne    8246df <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82461b:	cmp    %rsi,%rdi
  82461e:	je     8246b8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  824624:	mov    (%rdi),%rdx
  824627:	test   %rax,%rax
  82462a:	je     824633 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  82462c:	cmp    %r10,%rax
  82462f:	jne    824600 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  824631:	xor    %ebx,%ebx
  824633:	xor    %eax,%eax
  824635:	test   %r8,%r8
  824638:	je     8246e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82463e:	cmp    %rcx,%r8
  824641:	je     8246e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  824647:	mov    %r8,%rax
  82464a:	add    $0x8,%r8
  82464e:	xor    %r14d,%r14d
  824651:	jmp    824607 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  824653:	mov    (%r11),%rax
  824656:	mov    0x8(%rax),%rbx
  82465a:	mov    0x10(%rax),%rax
  82465e:	lea    (%rbx,%rax,8),%r10
  824662:	test   %rax,%rax
  824665:	je     8246a1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  824667:	xor    %r11d,%r11d
  82466a:	nopw   0x0(%rax,%rax,1)
  824670:	mov    %r8,%rax
  824673:	mov    %rbx,%r8
  824676:	add    $0x8,%rbx
  82467a:	add    $0x8,%rdi
  82467e:	mov    (%r8),%r14
  824681:	mov    %rax,%r8
  824684:	cmp    0x28(%r14),%rdx
  824688:	jne    8246df <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82468a:	cmp    %rsi,%rdi
  82468d:	je     8246b8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  82468f:	mov    (%rdi),%rdx
  824692:	test   %rbx,%rbx
  824695:	je     82469c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  824697:	cmp    %r10,%rbx
  82469a:	jne    824670 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  82469c:	test   %r11,%r11
  82469f:	jne    824653 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  8246a1:	xor    %eax,%eax
  8246a3:	test   %r8,%r8
  8246a6:	je     8246e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8246a8:	cmp    %rcx,%r8
  8246ab:	je     8246e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8246ad:	lea    0x8(%r8),%rax
  8246b1:	xor    %ebx,%ebx
  8246b3:	xor    %r11d,%r11d
  8246b6:	jmp    82467a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  8246b8:	test   %rbx,%rbx
  8246bb:	sete   %dl
  8246be:	cmp    %r10,%rbx
  8246c1:	sete   %al
  8246c4:	or     %dl,%al
  8246c6:	test   $0x1,%r9b
  8246ca:	je     8246e7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  8246cc:	test   %al,%al
  8246ce:	je     8246df <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8246d0:	test   %r11,%r11
  8246d3:	je     8246eb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8246d5:	mov    (%r11),%rax
  8246d8:	cmpq   $0x0,0x10(%rax)
  8246dd:	je     8246eb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8246df:	xor    %eax,%eax
  8246e1:	pop    %rbx
  8246e2:	pop    %r14
  8246e4:	pop    %r15
  8246e6:	ret
  8246e7:	test   %al,%al
  8246e9:	je     8246df <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8246eb:	test   %r8,%r8
  8246ee:	sete   %dl
  8246f1:	cmp    %rcx,%r8
  8246f4:	sete   %al
  8246f7:	or     %dl,%al
  8246f9:	pop    %rbx
  8246fa:	pop    %r14
  8246fc:	pop    %r15
  8246fe:	ret

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008254e0 <gpui_gpu::renderer::slots::color_word>:
  8254e0:	lea    -0x3(%rsi),%eax
  8254e3:	cmp    %rax,%rdi
  8254e6:	jbe    8254ff <gpui_gpu::renderer::slots::color_word+0x1f>
  8254e8:	mov    %rdi,%rax
  8254eb:	shr    $0x6,%rax
  8254ef:	and    $0x3f,%edi
  8254f2:	cmp    $0x1,%rdi
  8254f6:	sbb    $0xffffffff,%eax
  8254f9:	add    %esi,%eax
  8254fb:	add    $0xfffffffe,%eax
  8254fe:	ret
  8254ff:	push   %rax
  825500:	lea    -0x750786(%rip),%rdi        # d4d81 <anon.9952513c24ceb61dc4fba212e421bc6f.6.llvm.251048117738152227>
  825507:	lea    0x60a3e2(%rip),%rdx        # e2f8f0 <anon.9952513c24ceb61dc4fba212e421bc6f.7.llvm.251048117738152227>
  82550e:	mov    $0x1e,%esi
  825513:	call   *0x65bc67(%rip)        # e81180 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=517 frame=72

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825520 <gpui_gpu::renderer::slots::write_prefix>:
  825520:	push   %rbp
  825521:	push   %r15
  825523:	push   %r14
  825525:	push   %r13
  825527:	push   %r12
  825529:	push   %rbx
  82552a:	sub    $0x18,%rsp
  82552e:	test   %rdx,%rdx
  825531:	je     8256cc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825537:	mov    %rdi,%rbx
  82553a:	mov    %rdx,%rax
  82553d:	shr    $0x6,%rax
  825541:	xor    %ecx,%ecx
  825543:	test   $0x3f,%dl
  825546:	setne  %cl
  825549:	lea    (%rax,%rcx,1),%rbp
  82554d:	lea    (%rax,%rcx,1),%r8
  825551:	inc    %r8
  825554:	mov    0x10(%rdi),%r12
  825558:	mov    %rbp,%r13
  82555b:	sub    %r12,%r13
  82555e:	jae    82556c <gpui_gpu::renderer::slots::write_prefix+0x4c>
  825560:	mov    0x8(%rbx),%rax
  825564:	mov    %r8,%r14
  825567:	jmp    82560b <gpui_gpu::renderer::slots::write_prefix+0xeb>
  82556c:	mov    %r8,%r15
  82556f:	sub    %r12,%r15
  825572:	mov    (%rbx),%rax
  825575:	sub    %r12,%rax
  825578:	mov    %r12,%r14
  82557b:	cmp    %rax,%r15
  82557e:	ja     8256db <gpui_gpu::renderer::slots::write_prefix+0x1bb>
  825584:	mov    0x8(%rbx),%rax
  825588:	mov    %r14,%rcx
  82558b:	shl    $0x4,%rcx
  82558f:	add    %rax,%rcx
  825592:	cmp    $0x2,%r15
  825596:	jb     825602 <gpui_gpu::renderer::slots::write_prefix+0xe2>
  825598:	mov    %r13d,%edi
  82559b:	and    $0x7,%edi
  82559e:	sub    %rbp,%r12
  8255a1:	cmp    $0xfffffffffffffff8,%r12
  8255a5:	ja     8255de <gpui_gpu::renderer::slots::write_prefix+0xbe>
  8255a7:	and    $0xfffffffffffffff8,%r13
  8255ab:	xorps  %xmm0,%xmm0
  8255ae:	xchg   %ax,%ax
  8255b0:	movups %xmm0,(%rcx)
  8255b3:	movups %xmm0,0x10(%rcx)
  8255b7:	movups %xmm0,0x20(%rcx)
  8255bb:	movups %xmm0,0x30(%rcx)
  8255bf:	movups %xmm0,0x40(%rcx)
  8255c3:	movups %xmm0,0x50(%rcx)
  8255c7:	movups %xmm0,0x60(%rcx)
  8255cb:	movups %xmm0,0x70(%rcx)
  8255cf:	sub    $0xffffffffffffff80,%rcx
  8255d3:	add    $0xfffffffffffffff8,%r13
  8255d7:	jne    8255b0 <gpui_gpu::renderer::slots::write_prefix+0x90>
  8255d9:	test   %rdi,%rdi
  8255dc:	je     8255fc <gpui_gpu::renderer::slots::write_prefix+0xdc>
  8255de:	xorps  %xmm0,%xmm0
  8255e1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  8255f0:	movups %xmm0,(%rcx)
  8255f3:	add    $0x10,%rcx
  8255f7:	dec    %rdi
  8255fa:	jne    8255f0 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  8255fc:	add    %r15,%r14
  8255ff:	dec    %r14
  825602:	xorps  %xmm0,%xmm0
  825605:	movups %xmm0,(%rcx)
  825608:	inc    %r14
  82560b:	mov    %r14,0x10(%rbx)
  82560f:	mov    %edx,(%rax)
  825611:	mov    %ebp,0x4(%rax)
  825614:	mov    %r8d,0x8(%rax)
  825618:	movl   $0x0,0xc(%rax)
  82561f:	mov    %rsi,%rdi
  825622:	call   *0x65bb98(%rip)        # e811c0 <_DYNAMIC+0x5a8>
  825628:	cmp    %rdx,%rax
  82562b:	je     8256cc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825631:	mov    %rax,%r15
  825634:	mov    %rdx,%r12
  825637:	xor    %r13d,%r13d
  82563a:	xor    %ebp,%ebp
  82563c:	jmp    825666 <gpui_gpu::renderer::slots::write_prefix+0x146>
  82563e:	xchg   %ax,%ax
  825640:	mov    0x8(%rbx),%rax
  825644:	mov    %r14,%rcx
  825647:	shl    $0x4,%rcx
  82564b:	movups %xmm0,(%rax,%rcx,1)
  82564f:	inc    %r14
  825652:	mov    %r14,0x10(%rbx)
  825656:	add    $0x2,%r13d
  82565a:	add    $0x18,%r15
  82565e:	inc    %rbp
  825661:	cmp    %r12,%r15
  825664:	je     8256cc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825666:	mov    %rbp,%rdi
  825669:	shr    $0x6,%rdi
  82566d:	inc    %rdi
  825670:	cmp    %r14,%rdi
  825673:	jae    825715 <gpui_gpu::renderer::slots::write_prefix+0x1f5>
  825679:	movups (%r15),%xmm0
  82567d:	movzwl 0x12(%r15),%eax
  825682:	movzwl 0x10(%r15),%edx
  825687:	shr    $0xe,%eax
  82568a:	and    $0x2,%eax
  82568d:	shr    $0xf,%edx
  825690:	or     %eax,%edx
  825692:	mov    %r13d,%ecx
  825695:	and    $0x1e,%cl
  825698:	shl    %cl,%edx
  82569a:	shl    $0x4,%rdi
  82569e:	add    0x8(%rbx),%rdi
  8256a2:	mov    %ebp,%eax
  8256a4:	shr    $0x2,%eax
  8256a7:	and    $0xc,%eax
  8256aa:	or     %edx,(%rax,%rdi,1)
  8256ad:	mov    0x10(%rbx),%r14
  8256b1:	cmp    (%rbx),%r14
  8256b4:	jne    825640 <gpui_gpu::renderer::slots::write_prefix+0x120>
  8256b6:	mov    %rbx,%rdi
  8256b9:	movaps %xmm0,(%rsp)
  8256bd:	call   *0x65bc9d(%rip)        # e81360 <_DYNAMIC+0x748>
  8256c3:	movaps (%rsp),%xmm0
  8256c7:	jmp    825640 <gpui_gpu::renderer::slots::write_prefix+0x120>
  8256cc:	add    $0x18,%rsp
  8256d0:	pop    %rbx
  8256d1:	pop    %r12
  8256d3:	pop    %r13
  8256d5:	pop    %r14
  8256d7:	pop    %r15
  8256d9:	pop    %rbp
  8256da:	ret
  8256db:	mov    $0x4,%ecx
  8256e0:	mov    %r8,0x10(%rsp)
  8256e5:	mov    $0x10,%r8d
  8256eb:	mov    %rbx,%rdi
  8256ee:	mov    %rsi,(%rsp)
  8256f2:	mov    %r12,%rsi
  8256f5:	mov    %rdx,%r14
  8256f8:	mov    %r15,%rdx
  8256fb:	call   826f80 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  825700:	mov    0x10(%rsp),%r8
  825705:	mov    %r14,%rdx
  825708:	mov    (%rsp),%rsi
  82570c:	mov    0x10(%rbx),%r14
  825710:	jmp    825584 <gpui_gpu::renderer::slots::write_prefix+0x64>
  825715:	lea    0x60a1ec(%rip),%rdx        # e2f908 <anon.9952513c24ceb61dc4fba212e421bc6f.9.llvm.251048117738152227>
  82571c:	mov    %r14,%rsi
  82571f:	call   *0x65b9eb(%rip)        # e81110 <_DYNAMIC+0x4f8>

FUNCTION <gpui_gpu::renderer::coverage::Interval>::add bytes=366 frame=0

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825910 <<gpui_gpu::renderer::coverage::Interval>::add>:
  825910:	xorpd  %xmm4,%xmm4
  825914:	ucomisd %xmm4,%xmm2
  825918:	jne    825924 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  82591a:	jp     825924 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  82591c:	ucomisd %xmm4,%xmm3
  825920:	jne    825924 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  825922:	jnp    82593c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  825924:	ucomisd %xmm4,%xmm0
  825928:	jne    82594f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  82592a:	jp     82594f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  82592c:	ucomisd %xmm4,%xmm1
  825930:	jne    82594f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  825932:	jp     82594f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  825934:	movapd %xmm2,%xmm0
  825938:	movapd %xmm3,%xmm1
  82593c:	movsd  %xmm0,0x8(%rdi)
  825941:	movsd  %xmm1,0x10(%rdi)
  825946:	mov    $0x1,%ecx
  82594b:	mov    %rcx,(%rdi)
  82594e:	ret
  82594f:	addsd  %xmm2,%xmm0
  825953:	addsd  %xmm3,%xmm1
  825957:	movq   %xmm0,%rdx
  82595c:	movq   %xmm1,%rcx
  825961:	ucomisd %xmm0,%xmm0
  825965:	setp   %al
  825968:	movabs $0xfff0000000000000,%rsi
  825972:	cmp    %rsi,%rdx
  825975:	sete   %sil
  825979:	or     %al,%sil
  82597c:	movabs $0x7fffffffffffffff,%rax
  825986:	jne    8259ae <<gpui_gpu::renderer::coverage::Interval>::add+0x9e>
  825988:	mov    %rdx,%rsi
  82598b:	and    %rax,%rsi
  82598e:	je     82599a <<gpui_gpu::renderer::coverage::Interval>::add+0x8a>
  825990:	cmp    %rsi,%rdx
  825993:	jne    8259a6 <<gpui_gpu::renderer::coverage::Interval>::add+0x96>
  825995:	dec    %rdx
  825998:	jmp    8259a9 <<gpui_gpu::renderer::coverage::Interval>::add+0x99>
  82599a:	movabs $0x8000000000000001,%rdx
  8259a4:	jmp    8259a9 <<gpui_gpu::renderer::coverage::Interval>::add+0x99>
  8259a6:	inc    %rdx
  8259a9:	movq   %rdx,%xmm0
  8259ae:	ucomisd %xmm1,%xmm1
  8259b2:	setp   %dl
  8259b5:	movabs $0x7ff0000000000000,%rsi
  8259bf:	cmp    %rsi,%rcx
  8259c2:	sete   %sil
  8259c6:	or     %dl,%sil
  8259c9:	jne    8259ec <<gpui_gpu::renderer::coverage::Interval>::add+0xdc>
  8259cb:	mov    %rcx,%rdx
  8259ce:	and    %rax,%rdx
  8259d1:	je     8259dd <<gpui_gpu::renderer::coverage::Interval>::add+0xcd>
  8259d3:	cmp    %rdx,%rcx
  8259d6:	jne    8259e4 <<gpui_gpu::renderer::coverage::Interval>::add+0xd4>
  8259d8:	inc    %rcx
  8259db:	jmp    8259e7 <<gpui_gpu::renderer::coverage::Interval>::add+0xd7>
  8259dd:	mov    $0x1,%ecx
  8259e2:	jmp    8259e7 <<gpui_gpu::renderer::coverage::Interval>::add+0xd7>
  8259e4:	dec    %rcx
  8259e7:	movq   %rcx,%xmm1
  8259ec:	movq   %xmm0,%rdx
  8259f1:	and    %rax,%rdx
  8259f4:	xor    %ecx,%ecx
  8259f6:	movabs $0x7fefffffffffffff,%rsi
  825a00:	cmp    %rsi,%rdx
  825a03:	jg     825a7a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  825a05:	ucomisd %xmm1,%xmm0
  825a09:	ja     825a7a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  825a0b:	xorpd  %xmm2,%xmm2
  825a0f:	ucomisd %xmm2,%xmm0
  825a13:	jne    825a17 <<gpui_gpu::renderer::coverage::Interval>::add+0x107>
  825a15:	jnp    825a41 <<gpui_gpu::renderer::coverage::Interval>::add+0x131>
  825a17:	dec    %rdx
  825a1a:	movq   %xmm1,%rcx
  825a1f:	and    %rax,%rcx
  825a22:	cmp    %rsi,%rcx
  825a25:	setg   %sil
  825a29:	xor    %ecx,%ecx
  825a2b:	movabs $0xfffffffffffff,%r8
  825a35:	cmp    %r8,%rdx
  825a38:	jb     825a7a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  825a3a:	test   %sil,%sil
  825a3d:	je     825a4e <<gpui_gpu::renderer::coverage::Interval>::add+0x13e>
  825a3f:	jmp    825a7a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  825a41:	movq   %xmm1,%rcx
  825a46:	and    %rax,%rcx
  825a49:	cmp    %rsi,%rcx
  825a4c:	jg     825a78 <<gpui_gpu::renderer::coverage::Interval>::add+0x168>
  825a4e:	ucomisd %xmm2,%xmm1
  825a52:	jne    825a5a <<gpui_gpu::renderer::coverage::Interval>::add+0x14a>
  825a54:	jnp    82593c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  825a5a:	movq   %xmm1,%rcx
  825a5f:	and    %rax,%rcx
  825a62:	dec    %rcx
  825a65:	movabs $0xfffffffffffff,%rax
  825a6f:	cmp    %rax,%rcx
  825a72:	jae    82593c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  825a78:	xor    %ecx,%ecx
  825a7a:	mov    %rcx,(%rdi)
  825a7d:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::scale bytes=453 frame=0

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825a80 <<gpui_gpu::renderer::coverage::Interval>::scale>:
  825a80:	movq   %xmm2,%rdx
  825a85:	movabs $0x7fffffffffffffff,%rax
  825a8f:	and    %rax,%rdx
  825a92:	movabs $0x7fefffffffffffff,%rcx
  825a9c:	cmp    %rcx,%rdx
  825a9f:	jg     825abf <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  825aa1:	xorpd  %xmm3,%xmm3
  825aa5:	ucomisd %xmm3,%xmm2
  825aa9:	jne    825aad <<gpui_gpu::renderer::coverage::Interval>::scale+0x2d>
  825aab:	jnp    825ac5 <<gpui_gpu::renderer::coverage::Interval>::scale+0x45>
  825aad:	dec    %rdx
  825ab0:	movabs $0xfffffffffffff,%rsi
  825aba:	cmp    %rsi,%rdx
  825abd:	jae    825ac5 <<gpui_gpu::renderer::coverage::Interval>::scale+0x45>
  825abf:	xor    %edx,%edx
  825ac1:	mov    %rdx,(%rdi)
  825ac4:	ret
  825ac5:	ucomisd %xmm3,%xmm2
  825ac9:	jne    825acd <<gpui_gpu::renderer::coverage::Interval>::scale+0x4d>
  825acb:	jnp    825add <<gpui_gpu::renderer::coverage::Interval>::scale+0x5d>
  825acd:	ucomisd %xmm3,%xmm0
  825ad1:	jne    825aef <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  825ad3:	jp     825aef <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  825ad5:	ucomisd %xmm3,%xmm1
  825ad9:	jne    825aef <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  825adb:	jp     825aef <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  825add:	xorpd  %xmm0,%xmm0
  825ae1:	movupd %xmm0,0x8(%rdi)
  825ae6:	mov    $0x1,%edx
  825aeb:	mov    %rdx,(%rdi)
  825aee:	ret
  825aef:	ucomisd %xmm3,%xmm2
  825af3:	cmpltsd %xmm2,%xmm3
  825af8:	movapd %xmm3,%xmm4
  825afc:	andpd  %xmm0,%xmm4
  825b00:	andnpd %xmm1,%xmm3
  825b04:	orpd   %xmm4,%xmm3
  825b08:	ja     825b0e <<gpui_gpu::renderer::coverage::Interval>::scale+0x8e>
  825b0a:	movapd %xmm0,%xmm1
  825b0e:	mulsd  %xmm2,%xmm1
  825b12:	mulsd  %xmm2,%xmm3
  825b16:	movq   %xmm3,%rsi
  825b1b:	movq   %xmm1,%rdx
  825b20:	ucomisd %xmm3,%xmm3
  825b24:	setp   %r8b
  825b28:	movabs $0xfff0000000000000,%r9
  825b32:	cmp    %r9,%rsi
  825b35:	sete   %r9b
  825b39:	or     %r8b,%r9b
  825b3c:	jne    825b64 <<gpui_gpu::renderer::coverage::Interval>::scale+0xe4>
  825b3e:	mov    %rsi,%r8
  825b41:	and    %rax,%r8
  825b44:	je     825b50 <<gpui_gpu::renderer::coverage::Interval>::scale+0xd0>
  825b46:	cmp    %r8,%rsi
  825b49:	jne    825b5c <<gpui_gpu::renderer::coverage::Interval>::scale+0xdc>
  825b4b:	dec    %rsi
  825b4e:	jmp    825b5f <<gpui_gpu::renderer::coverage::Interval>::scale+0xdf>
  825b50:	movabs $0x8000000000000001,%rsi
  825b5a:	jmp    825b5f <<gpui_gpu::renderer::coverage::Interval>::scale+0xdf>
  825b5c:	inc    %rsi
  825b5f:	movq   %rsi,%xmm3
  825b64:	ucomisd %xmm1,%xmm1
  825b68:	setp   %sil
  825b6c:	movabs $0x7ff0000000000000,%r8
  825b76:	cmp    %r8,%rdx
  825b79:	sete   %r8b
  825b7d:	or     %sil,%r8b
  825b80:	jne    825ba3 <<gpui_gpu::renderer::coverage::Interval>::scale+0x123>
  825b82:	mov    %rdx,%rsi
  825b85:	and    %rax,%rsi
  825b88:	je     825b94 <<gpui_gpu::renderer::coverage::Interval>::scale+0x114>
  825b8a:	cmp    %rsi,%rdx
  825b8d:	jne    825b9b <<gpui_gpu::renderer::coverage::Interval>::scale+0x11b>
  825b8f:	inc    %rdx
  825b92:	jmp    825b9e <<gpui_gpu::renderer::coverage::Interval>::scale+0x11e>
  825b94:	mov    $0x1,%edx
  825b99:	jmp    825b9e <<gpui_gpu::renderer::coverage::Interval>::scale+0x11e>
  825b9b:	dec    %rdx
  825b9e:	movq   %rdx,%xmm1
  825ba3:	movq   %xmm3,%rsi
  825ba8:	and    %rax,%rsi
  825bab:	xor    %edx,%edx
  825bad:	cmp    %rcx,%rsi
  825bb0:	jg     825ac1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  825bb6:	ucomisd %xmm1,%xmm3
  825bba:	ja     825ac1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  825bc0:	xorpd  %xmm0,%xmm0
  825bc4:	ucomisd %xmm0,%xmm3
  825bc8:	jne    825bcc <<gpui_gpu::renderer::coverage::Interval>::scale+0x14c>
  825bca:	jnp    825bfb <<gpui_gpu::renderer::coverage::Interval>::scale+0x17b>
  825bcc:	dec    %rsi
  825bcf:	movq   %xmm1,%rdx
  825bd4:	and    %rax,%rdx
  825bd7:	cmp    %rcx,%rdx
  825bda:	setg   %cl
  825bdd:	xor    %edx,%edx
  825bdf:	movabs $0xfffffffffffff,%r8
  825be9:	cmp    %r8,%rsi
  825bec:	jb     825ac1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  825bf2:	test   %cl,%cl
  825bf4:	je     825c0c <<gpui_gpu::renderer::coverage::Interval>::scale+0x18c>
  825bf6:	jmp    825ac1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  825bfb:	movq   %xmm1,%rdx
  825c00:	and    %rax,%rdx
  825c03:	cmp    %rcx,%rdx
  825c06:	jg     825abf <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  825c0c:	ucomisd %xmm0,%xmm1
  825c10:	jne    825c14 <<gpui_gpu::renderer::coverage::Interval>::scale+0x194>
  825c12:	jnp    825c32 <<gpui_gpu::renderer::coverage::Interval>::scale+0x1b2>
  825c14:	movq   %xmm1,%rcx
  825c19:	and    %rax,%rcx
  825c1c:	dec    %rcx
  825c1f:	movabs $0xfffffffffffff,%rax
  825c29:	cmp    %rax,%rcx
  825c2c:	jb     825abf <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  825c32:	movsd  %xmm3,0x8(%rdi)
  825c37:	movsd  %xmm1,0x10(%rdi)
  825c3c:	mov    $0x1,%edx
  825c41:	mov    %rdx,(%rdi)
  825c44:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::checked bytes=187 frame=0

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825c50 <<gpui_gpu::renderer::coverage::Interval>::checked>:
  825c50:	movq   %xmm0,%rdx
  825c55:	ucomisd %xmm1,%xmm0
  825c59:	seta   %sil
  825c5d:	movabs $0x7fffffffffffffff,%rax
  825c67:	and    %rax,%rdx
  825c6a:	movabs $0x7fefffffffffffff,%rcx
  825c74:	cmp    %rcx,%rdx
  825c77:	setg   %r8b
  825c7b:	or     %sil,%r8b
  825c7e:	je     825c86 <<gpui_gpu::renderer::coverage::Interval>::checked+0x36>
  825c80:	xor    %eax,%eax
  825c82:	mov    %rax,(%rdi)
  825c85:	ret
  825c86:	xorpd  %xmm2,%xmm2
  825c8a:	ucomisd %xmm2,%xmm0
  825c8e:	jne    825c92 <<gpui_gpu::renderer::coverage::Interval>::checked+0x42>
  825c90:	jnp    825cbd <<gpui_gpu::renderer::coverage::Interval>::checked+0x6d>
  825c92:	dec    %rdx
  825c95:	movabs $0xfffffffffffff,%rsi
  825c9f:	cmp    %rsi,%rdx
  825ca2:	setb   %dl
  825ca5:	movq   %xmm1,%rsi
  825caa:	and    %rax,%rsi
  825cad:	cmp    %rcx,%rsi
  825cb0:	setg   %cl
  825cb3:	or     %dl,%cl
  825cb5:	je     825cd0 <<gpui_gpu::renderer::coverage::Interval>::checked+0x80>
  825cb7:	xor    %eax,%eax
  825cb9:	mov    %rax,(%rdi)
  825cbc:	ret
  825cbd:	movq   %xmm1,%rdx
  825cc2:	and    %rax,%rdx
  825cc5:	cmp    %rcx,%rdx
  825cc8:	jle    825cd0 <<gpui_gpu::renderer::coverage::Interval>::checked+0x80>
  825cca:	xor    %eax,%eax
  825ccc:	mov    %rax,(%rdi)
  825ccf:	ret
  825cd0:	ucomisd %xmm2,%xmm1
  825cd4:	jne    825cd8 <<gpui_gpu::renderer::coverage::Interval>::checked+0x88>
  825cd6:	jnp    825cf8 <<gpui_gpu::renderer::coverage::Interval>::checked+0xa8>
  825cd8:	movq   %xmm1,%rcx
  825cdd:	and    %rax,%rcx
  825ce0:	dec    %rcx
  825ce3:	movabs $0xfffffffffffff,%rax
  825ced:	cmp    %rax,%rcx
  825cf0:	jae    825cf8 <<gpui_gpu::renderer::coverage::Interval>::checked+0xa8>
  825cf2:	xor    %eax,%eax
  825cf4:	mov    %rax,(%rdi)
  825cf7:	ret
  825cf8:	movsd  %xmm0,0x8(%rdi)
  825cfd:	movsd  %xmm1,0x10(%rdi)
  825d02:	mov    $0x1,%eax
  825d07:	mov    %rax,(%rdi)
  825d0a:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::subtract bytes=382 frame=0

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825d10 <<gpui_gpu::renderer::coverage::Interval>::subtract>:
  825d10:	xorpd  %xmm4,%xmm4
  825d14:	ucomisd %xmm4,%xmm2
  825d18:	jne    825d24 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  825d1a:	jp     825d24 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  825d1c:	ucomisd %xmm4,%xmm3
  825d20:	jne    825d24 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  825d22:	jnp    825d4c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  825d24:	ucomisd %xmm4,%xmm0
  825d28:	jne    825d5f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  825d2a:	jp     825d5f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  825d2c:	ucomisd %xmm4,%xmm1
  825d30:	jne    825d5f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  825d32:	jp     825d5f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  825d34:	movapd -0x777b7c(%rip),%xmm0        # ae1c0 <anon.630a3fff68f6bca64b568be97512ab45.90.llvm.826976926275214120+0x90>
  825d3c:	xorpd  %xmm0,%xmm2
  825d40:	xorpd  %xmm0,%xmm3
  825d44:	movapd %xmm3,%xmm0
  825d48:	movapd %xmm2,%xmm1
  825d4c:	movsd  %xmm0,0x8(%rdi)
  825d51:	movsd  %xmm1,0x10(%rdi)
  825d56:	mov    $0x1,%ecx
  825d5b:	mov    %rcx,(%rdi)
  825d5e:	ret
  825d5f:	subsd  %xmm3,%xmm0
  825d63:	subsd  %xmm2,%xmm1
  825d67:	movq   %xmm0,%rdx
  825d6c:	movq   %xmm1,%rcx
  825d71:	ucomisd %xmm0,%xmm0
  825d75:	setp   %al
  825d78:	movabs $0xfff0000000000000,%rsi
  825d82:	cmp    %rsi,%rdx
  825d85:	sete   %sil
  825d89:	or     %al,%sil
  825d8c:	movabs $0x7fffffffffffffff,%rax
  825d96:	jne    825dbe <<gpui_gpu::renderer::coverage::Interval>::subtract+0xae>
  825d98:	mov    %rdx,%rsi
  825d9b:	and    %rax,%rsi
  825d9e:	je     825daa <<gpui_gpu::renderer::coverage::Interval>::subtract+0x9a>
  825da0:	cmp    %rsi,%rdx
  825da3:	jne    825db6 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa6>
  825da5:	dec    %rdx
  825da8:	jmp    825db9 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa9>
  825daa:	movabs $0x8000000000000001,%rdx
  825db4:	jmp    825db9 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa9>
  825db6:	inc    %rdx
  825db9:	movq   %rdx,%xmm0
  825dbe:	ucomisd %xmm1,%xmm1
  825dc2:	setp   %dl
  825dc5:	movabs $0x7ff0000000000000,%rsi
  825dcf:	cmp    %rsi,%rcx
  825dd2:	sete   %sil
  825dd6:	or     %dl,%sil
  825dd9:	jne    825dfc <<gpui_gpu::renderer::coverage::Interval>::subtract+0xec>
  825ddb:	mov    %rcx,%rdx
  825dde:	and    %rax,%rdx
  825de1:	je     825ded <<gpui_gpu::renderer::coverage::Interval>::subtract+0xdd>
  825de3:	cmp    %rdx,%rcx
  825de6:	jne    825df4 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe4>
  825de8:	inc    %rcx
  825deb:	jmp    825df7 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe7>
  825ded:	mov    $0x1,%ecx
  825df2:	jmp    825df7 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe7>
  825df4:	dec    %rcx
  825df7:	movq   %rcx,%xmm1
  825dfc:	movq   %xmm0,%rdx
  825e01:	and    %rax,%rdx
  825e04:	xor    %ecx,%ecx
  825e06:	movabs $0x7fefffffffffffff,%rsi
  825e10:	cmp    %rsi,%rdx
  825e13:	jg     825e8a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  825e15:	ucomisd %xmm1,%xmm0
  825e19:	ja     825e8a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  825e1b:	xorpd  %xmm2,%xmm2
  825e1f:	ucomisd %xmm2,%xmm0
  825e23:	jne    825e27 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x117>
  825e25:	jnp    825e51 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x141>
  825e27:	dec    %rdx
  825e2a:	movq   %xmm1,%rcx
  825e2f:	and    %rax,%rcx
  825e32:	cmp    %rsi,%rcx
  825e35:	setg   %sil
  825e39:	xor    %ecx,%ecx
  825e3b:	movabs $0xfffffffffffff,%r8
  825e45:	cmp    %r8,%rdx
  825e48:	jb     825e8a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  825e4a:	test   %sil,%sil
  825e4d:	je     825e5e <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14e>
  825e4f:	jmp    825e8a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  825e51:	movq   %xmm1,%rcx
  825e56:	and    %rax,%rcx
  825e59:	cmp    %rsi,%rcx
  825e5c:	jg     825e88 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x178>
  825e5e:	ucomisd %xmm2,%xmm1
  825e62:	jne    825e6a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x15a>
  825e64:	jnp    825d4c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  825e6a:	movq   %xmm1,%rcx
  825e6f:	and    %rax,%rcx
  825e72:	dec    %rcx
  825e75:	movabs $0xfffffffffffff,%rax
  825e7f:	cmp    %rax,%rcx
  825e82:	jae    825d4c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  825e88:	xor    %ecx,%ecx
  825e8a:	mov    %rcx,(%rdi)
  825e8d:	ret

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825e90 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  825e90:	push   %rbp
  825e91:	push   %r15
  825e93:	push   %r14
  825e95:	push   %r13
  825e97:	push   %r12
  825e99:	push   %rbx
  825e9a:	sub    $0x38,%rsp
  825e9e:	mov    %rcx,%r15
  825ea1:	mov    %rdx,%r12
  825ea4:	mov    %rsi,%r14
  825ea7:	mov    %rdi,%rbx
  825eaa:	lea    0x20(%rsi),%r13
  825eae:	mov    %r13,%rdi
  825eb1:	mov    %rdx,%rsi
  825eb4:	call   824880 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  825eb9:	cmpq   $0x0,0x10(%r14)
  825ebe:	je     826041 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  825ec4:	mov    (%r14),%r11
  825ec7:	mov    0x8(%r14),%rsi
  825ecb:	mov    %rax,%rdx
  825ece:	shr    $0x39,%rdx
  825ed2:	movd   %edx,%xmm0
  825ed6:	punpcklbw %xmm0,%xmm0
  825eda:	pshuflw $0x0,%xmm0,%xmm0
  825edf:	pshufd $0x44,%xmm0,%xmm0
  825ee4:	mov    (%r12),%rcx
  825ee8:	mov    %rcx,0x8(%rsp)
  825eed:	movzwl 0xc(%r12),%r9d
  825ef3:	mov    0x8(%r12),%r10d
  825ef8:	xor    %r13d,%r13d
  825efb:	pcmpeqd %xmm1,%xmm1
  825eff:	xor    %r8d,%r8d
  825f02:	and    %rsi,%rax
  825f05:	movdqu (%r11,%rax,1),%xmm2
  825f0b:	movdqa %xmm2,%xmm3
  825f0f:	pcmpeqb %xmm0,%xmm3
  825f13:	pmovmskb %xmm3,%ebp
  825f17:	test   %ebp,%ebp
  825f19:	je     825f60 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  825f1b:	mov    %r8,(%rsp)
  825f1f:	mov    %r15,%r8
  825f22:	tzcnt  %ebp,%r15d
  825f27:	add    %rax,%r15
  825f2a:	and    %rsi,%r15
  825f2d:	shl    $0x5,%r15
  825f31:	mov    %r11,%rcx
  825f34:	sub    %r15,%rcx
  825f37:	mov    0x8(%rsp),%r15
  825f3c:	cmp    -0x20(%rcx),%r15
  825f40:	jne    825f4f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  825f42:	cmp    -0x14(%rcx),%r9w
  825f47:	jne    825f4f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  825f49:	cmp    -0x18(%rcx),%r10d
  825f4d:	je     825f9f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  825f4f:	lea    -0x1(%rbp),%ecx
  825f52:	and    %bp,%cx
  825f55:	mov    %ecx,%ebp
  825f57:	mov    %r8,%r15
  825f5a:	mov    (%rsp),%r8
  825f5e:	jne    825f1f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  825f60:	cmp    $0x1,%r13
  825f64:	je     825f78 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  825f66:	pmovmskb %xmm2,%ecx
  825f6a:	test   %ecx,%ecx
  825f6c:	je     825f8c <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  825f6e:	tzcnt  %ecx,%edi
  825f72:	add    %rax,%rdi
  825f75:	and    %rsi,%rdi
  825f78:	pcmpeqb %xmm1,%xmm2
  825f7c:	pmovmskb %xmm2,%ecx
  825f80:	test   %ecx,%ecx
  825f82:	jne    825fb6 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  825f84:	mov    $0x1,%r13d
  825f8a:	jmp    825f8f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  825f8c:	xor    %r13d,%r13d
  825f8f:	add    %r8,%rax
  825f92:	add    $0x10,%rax
  825f96:	add    $0x10,%r8
  825f9a:	jmp    825f02 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  825f9f:	movups -0x10(%rcx),%xmm0
  825fa3:	movups %xmm0,0x4(%rbx)
  825fa7:	movups (%r8),%xmm0
  825fab:	movups %xmm0,-0x10(%rcx)
  825faf:	mov    $0x1,%eax
  825fb4:	jmp    82602d <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  825fb6:	movzbl (%r11,%rdi,1),%eax
  825fbb:	test   %al,%al
  825fbd:	jns    826062 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  825fc3:	movups (%r12),%xmm0
  825fc8:	movaps %xmm0,0x10(%rsp)
  825fcd:	movups (%r15),%xmm0
  825fd1:	movaps %xmm0,0x20(%rsp)
  825fd6:	and    $0x1,%al
  825fd8:	lea    -0x10(%rdi),%rcx
  825fdc:	and    %rsi,%rcx
  825fdf:	mov    %dl,(%r11,%rdi,1)
  825fe3:	mov    %dl,0x10(%r11,%rcx,1)
  825fe8:	movzbl %al,%eax
  825feb:	movd   %eax,%xmm0
  825fef:	shufpd $0x2,-0x77ad98(%rip),%xmm0        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  825ff8:	movdqu 0x10(%r14),%xmm1
  825ffe:	psubq  %xmm0,%xmm1
  826002:	movdqu %xmm1,0x10(%r14)
  826008:	shl    $0x5,%rdi
  82600c:	mov    %r11,%rax
  82600f:	sub    %rdi,%rax
  826012:	neg    %rdi
  826015:	movaps 0x10(%rsp),%xmm0
  82601a:	movdqa 0x20(%rsp),%xmm1
  826020:	movups %xmm0,-0x20(%r11,%rdi,1)
  826026:	movdqu %xmm1,-0x10(%rax)
  82602b:	xor    %eax,%eax
  82602d:	mov    %eax,(%rbx)
  82602f:	mov    %rbx,%rax
  826032:	add    $0x38,%rsp
  826036:	pop    %rbx
  826037:	pop    %r12
  826039:	pop    %r13
  82603b:	pop    %r14
  82603d:	pop    %r15
  82603f:	pop    %rbp
  826040:	ret
  826041:	mov    $0x1,%esi
  826046:	mov    %r14,%rdi
  826049:	mov    %r13,%rdx
  82604c:	mov    $0x1,%ecx
  826051:	mov    %rax,%r13
  826054:	call   *0x65b256(%rip)        # e812b0 <_DYNAMIC+0x698>
  82605a:	mov    %r13,%rax
  82605d:	jmp    825ec4 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  826062:	movdqa (%r11),%xmm0
  826067:	pmovmskb %xmm0,%eax
  82606b:	tzcnt  %eax,%edi
  82606f:	movzbl (%r11,%rdi,1),%eax
  826074:	jmp    825fc3 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826080 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  826080:	push   %rbp
  826081:	push   %r15
  826083:	push   %r14
  826085:	push   %r13
  826087:	push   %r12
  826089:	push   %rbx
  82608a:	push   %rax
  82608b:	mov    %r8d,%ebp
  82608e:	mov    %ecx,%r14d
  826091:	mov    %rdx,%r15
  826094:	mov    %rsi,%r12
  826097:	mov    %rdi,%rbx
  82609a:	mov    %rdx,(%rsp)
  82609e:	lea    0x20(%rsi),%r13
  8260a2:	mov    %rsp,%rsi
  8260a5:	mov    %r13,%rdi
  8260a8:	call   824a20 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8260ad:	cmpq   $0x0,0x10(%r12)
  8260b3:	je     8261f6 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  8260b9:	mov    (%r12),%rcx
  8260bd:	mov    0x8(%r12),%rsi
  8260c2:	mov    %rax,%rdx
  8260c5:	shr    $0x39,%rdx
  8260c9:	movd   %edx,%xmm0
  8260cd:	punpcklbw %xmm0,%xmm0
  8260d1:	pshuflw $0x0,%xmm0,%xmm0
  8260d6:	pshufd $0x44,%xmm0,%xmm0
  8260db:	xor    %r9d,%r9d
  8260de:	pcmpeqd %xmm1,%xmm1
  8260e2:	xor    %r8d,%r8d
  8260e5:	and    %rsi,%rax
  8260e8:	movdqu (%rcx,%rax,1),%xmm2
  8260ed:	movdqa %xmm2,%xmm3
  8260f1:	pcmpeqb %xmm0,%xmm3
  8260f5:	pmovmskb %xmm3,%r10d
  8260fa:	test   %r10d,%r10d
  8260fd:	je     826130 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  8260ff:	tzcnt  %r10d,%r13d
  826104:	add    %rax,%r13
  826107:	and    %rsi,%r13
  82610a:	shl    $0x4,%r13
  82610e:	mov    %rcx,%r11
  826111:	sub    %r13,%r11
  826114:	cmp    -0x10(%r11),%r15
  826118:	je     826171 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  82611a:	lea    -0x1(%r10),%r11d
  82611e:	and    %r10w,%r11w
  826122:	mov    %r11d,%r10d
  826125:	jne    8260ff <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  826127:	nopw   0x0(%rax,%rax,1)
  826130:	cmp    $0x1,%r9
  826134:	je     826148 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  826136:	pmovmskb %xmm2,%edi
  82613a:	test   %edi,%edi
  82613c:	je     82615e <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  82613e:	tzcnt  %edi,%edi
  826142:	add    %rax,%rdi
  826145:	and    %rsi,%rdi
  826148:	pcmpeqb %xmm1,%xmm2
  82614c:	pmovmskb %xmm2,%r9d
  826151:	test   %r9d,%r9d
  826154:	jne    826188 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  826156:	mov    $0x1,%r9d
  82615c:	jmp    826161 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  82615e:	xor    %r9d,%r9d
  826161:	add    %r8,%rax
  826164:	add    $0x10,%rax
  826168:	add    $0x10,%r8
  82616c:	jmp    8260e5 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  826171:	mov    -0x8(%r11),%rax
  826175:	mov    %r14d,-0x8(%r11)
  826179:	mov    %ebp,-0x4(%r11)
  82617d:	mov    %rax,0x4(%rbx)
  826181:	mov    $0x1,%eax
  826186:	jmp    8261e2 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  826188:	movzbl (%rcx,%rdi,1),%eax
  82618c:	test   %al,%al
  82618e:	jns    826217 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  826194:	and    $0x1,%al
  826196:	lea    -0x10(%rdi),%r8
  82619a:	and    %rsi,%r8
  82619d:	mov    %dl,(%rcx,%rdi,1)
  8261a0:	mov    %dl,0x10(%rcx,%r8,1)
  8261a5:	movdqu 0x10(%r12),%xmm0
  8261ac:	movzbl %al,%eax
  8261af:	movd   %eax,%xmm1
  8261b3:	shufpd $0x2,-0x77af5c(%rip),%xmm1        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  8261bc:	psubq  %xmm1,%xmm0
  8261c0:	movdqu %xmm0,0x10(%r12)
  8261c7:	shl    $0x4,%rdi
  8261cb:	mov    %rcx,%rax
  8261ce:	sub    %rdi,%rax
  8261d1:	neg    %rdi
  8261d4:	mov    %r15,-0x10(%rcx,%rdi,1)
  8261d9:	mov    %r14d,-0x8(%rax)
  8261dd:	mov    %ebp,-0x4(%rax)
  8261e0:	xor    %eax,%eax
  8261e2:	mov    %eax,(%rbx)
  8261e4:	mov    %rbx,%rax
  8261e7:	add    $0x8,%rsp
  8261eb:	pop    %rbx
  8261ec:	pop    %r12
  8261ee:	pop    %r13
  8261f0:	pop    %r14
  8261f2:	pop    %r15
  8261f4:	pop    %rbp
  8261f5:	ret
  8261f6:	mov    $0x1,%esi
  8261fb:	mov    %r12,%rdi
  8261fe:	mov    %r13,%rdx
  826201:	mov    $0x1,%ecx
  826206:	mov    %rax,%r13
  826209:	call   *0x65b0a9(%rip)        # e812b8 <_DYNAMIC+0x6a0>
  82620f:	mov    %r13,%rax
  826212:	jmp    8260b9 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  826217:	movdqa (%rcx),%xmm0
  82621b:	pmovmskb %xmm0,%eax
  82621f:	tzcnt  %eax,%edi
  826223:	movzbl (%rcx,%rdi,1),%eax
  826227:	jmp    826194 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

FUNCTION gpui_gpu::renderer::coverage::axis bytes=1662 frame=344

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826230 <gpui_gpu::renderer::coverage::axis>:
  826230:	push   %r15
  826232:	push   %r14
  826234:	push   %r13
  826236:	push   %r12
  826238:	push   %rbx
  826239:	sub    $0x130,%rsp
  826240:	movq   %xmm4,%r12
  826245:	movabs $0x7fffffffffffffff,%rbx
  82624f:	and    %rbx,%r12
  826252:	mov    $0x2,%al
  826254:	movabs $0x7fefffffffffffff,%r14
  82625e:	cmp    %r14,%r12
  826261:	jg     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  826267:	movsd  (%rdi),%xmm11
  82626c:	movsd  0x8(%rdi),%xmm8
  826272:	movsd  0x10(%rdi),%xmm9
  826278:	xorpd  %xmm10,%xmm10
  82627d:	ucomisd %xmm10,%xmm4
  826282:	jne    826286 <gpui_gpu::renderer::coverage::axis+0x56>
  826284:	jnp    82629e <gpui_gpu::renderer::coverage::axis+0x6e>
  826286:	lea    -0x1(%r12),%rcx
  82628b:	movabs $0xfffffffffffff,%rdx
  826295:	cmp    %rdx,%rcx
  826298:	jb     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  82629e:	movq   %xmm5,%r15
  8262a3:	and    %rbx,%r15
  8262a6:	cmp    %r14,%r15
  8262a9:	jg     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  8262af:	ucomisd %xmm10,%xmm5
  8262b4:	jne    8262b8 <gpui_gpu::renderer::coverage::axis+0x88>
  8262b6:	jnp    8262cf <gpui_gpu::renderer::coverage::axis+0x9f>
  8262b8:	lea    -0x1(%r15),%rcx
  8262bc:	movabs $0xfffffffffffff,%rdx
  8262c6:	cmp    %rdx,%rcx
  8262c9:	jb     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  8262cf:	movaps %xmm8,0xc0(%rsp)
  8262d8:	movsd  %xmm2,0x60(%rsp)
  8262de:	movsd  %xmm3,0x28(%rsp)
  8262e4:	movaps %xmm9,0x80(%rsp)
  8262ed:	movaps %xmm4,0xb0(%rsp)
  8262f5:	movsd  %xmm6,0xa8(%rsp)
  8262fe:	movsd  %xmm7,0x30(%rsp)
  826304:	movaps %xmm5,0x90(%rsp)
  82630c:	mov    %rsp,%rdi
  82630f:	movsd  %xmm0,0x38(%rsp)
  826315:	movsd  %xmm1,0x40(%rsp)
  82631b:	movapd %xmm11,0x120(%rsp)
  826325:	movapd %xmm11,%xmm2
  82632a:	call   825a80 <<gpui_gpu::renderer::coverage::Interval>::scale>
  82632f:	cmpl   $0x1,(%rsp)
  826333:	jne    82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  826339:	movsd  0x8(%rsp),%xmm0
  82633f:	movsd  %xmm0,0x20(%rsp)
  826345:	movsd  0x10(%rsp),%xmm0
  82634b:	movsd  %xmm0,0x18(%rsp)
  826351:	mov    %rsp,%rdi
  826354:	movsd  0x60(%rsp),%xmm0
  82635a:	movsd  0x28(%rsp),%xmm1
  826360:	movapd 0xc0(%rsp),%xmm2
  826369:	call   825a80 <<gpui_gpu::renderer::coverage::Interval>::scale>
  82636e:	cmpb   $0x0,(%rsp)
  826372:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  826378:	movsd  0x8(%rsp),%xmm5
  82637e:	movsd  0x10(%rsp),%xmm4
  826384:	xorpd  %xmm2,%xmm2
  826388:	ucomisd %xmm2,%xmm5
  82638c:	mov    $0x2,%al
  82638e:	jne    8263b1 <gpui_gpu::renderer::coverage::axis+0x181>
  826390:	jp     8263b1 <gpui_gpu::renderer::coverage::axis+0x181>
  826392:	ucomisd %xmm2,%xmm4
  826396:	jne    8263b1 <gpui_gpu::renderer::coverage::axis+0x181>
  826398:	jp     8263b1 <gpui_gpu::renderer::coverage::axis+0x181>
  82639a:	movdqa 0x80(%rsp),%xmm2
  8263a3:	movsd  0x18(%rsp),%xmm1
  8263a9:	movsd  0x20(%rsp),%xmm0
  8263af:	jmp    8263f2 <gpui_gpu::renderer::coverage::axis+0x1c2>
  8263b1:	movsd  0x20(%rsp),%xmm0
  8263b7:	ucomisd %xmm2,%xmm0
  8263bb:	movdqa 0x80(%rsp),%xmm2
  8263c4:	movsd  0x18(%rsp),%xmm1
  8263ca:	jne    826781 <gpui_gpu::renderer::coverage::axis+0x551>
  8263d0:	jp     826781 <gpui_gpu::renderer::coverage::axis+0x551>
  8263d6:	xorpd  %xmm3,%xmm3
  8263da:	ucomisd %xmm3,%xmm1
  8263de:	jne    826781 <gpui_gpu::renderer::coverage::axis+0x551>
  8263e4:	jp     826781 <gpui_gpu::renderer::coverage::axis+0x551>
  8263ea:	movapd %xmm4,%xmm1
  8263ee:	movapd %xmm5,%xmm0
  8263f2:	movq   %xmm2,%r13
  8263f7:	and    %rbx,%r13
  8263fa:	cmp    %r14,%r13
  8263fd:	jg     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  826403:	xorpd  %xmm3,%xmm3
  826407:	ucomisd %xmm3,%xmm2
  82640b:	jne    82640f <gpui_gpu::renderer::coverage::axis+0x1df>
  82640d:	jnp    826426 <gpui_gpu::renderer::coverage::axis+0x1f6>
  82640f:	lea    -0x1(%r13),%rcx
  826413:	movabs $0xfffffffffffff,%rdx
  82641d:	cmp    %rdx,%rcx
  826420:	jb     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  826426:	lea    0x48(%rsp),%rdi
  82642b:	movapd 0x80(%rsp),%xmm3
  826434:	call   825910 <<gpui_gpu::renderer::coverage::Interval>::add>
  826439:	movapd 0xb0(%rsp),%xmm2
  826442:	mov    $0x2,%al
  826444:	cmpb   $0x0,0x48(%rsp)
  826449:	je     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  82644f:	movsd  0x50(%rsp),%xmm0
  826455:	movsd  0x58(%rsp),%xmm1
  82645b:	lea    0x68(%rsp),%rdi
  826460:	movapd %xmm2,%xmm3
  826464:	call   825d10 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  826469:	cmpl   $0x1,0x68(%rsp)
  82646e:	jne    82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  826474:	movsd  0x70(%rsp),%xmm0
  82647a:	movsd  %xmm0,0x18(%rsp)
  826480:	movsd  0x78(%rsp),%xmm0
  826486:	movsd  %xmm0,0x20(%rsp)
  82648c:	movapd 0x120(%rsp),%xmm2
  826495:	andpd  -0x77b66d(%rip),%xmm2        # aae30 <GCC_except_table0+0x64>
  82649d:	mov    %rsp,%rdi
  8264a0:	movsd  0x38(%rsp),%xmm0
  8264a6:	movsd  0x40(%rsp),%xmm1
  8264ac:	call   825a80 <<gpui_gpu::renderer::coverage::Interval>::scale>
  8264b1:	cmpb   $0x0,(%rsp)
  8264b5:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  8264bb:	movsd  0x8(%rsp),%xmm0
  8264c1:	movsd  %xmm0,0x40(%rsp)
  8264c7:	movsd  0x10(%rsp),%xmm0
  8264cd:	movsd  %xmm0,0x38(%rsp)
  8264d3:	movapd 0xc0(%rsp),%xmm2
  8264dc:	andpd  -0x77b6b4(%rip),%xmm2        # aae30 <GCC_except_table0+0x64>
  8264e4:	mov    %rsp,%rdi
  8264e7:	movsd  0x60(%rsp),%xmm0
  8264ed:	movsd  0x28(%rsp),%xmm1
  8264f3:	call   825a80 <<gpui_gpu::renderer::coverage::Interval>::scale>
  8264f8:	cmpb   $0x0,(%rsp)
  8264fc:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  826502:	movsd  0x8(%rsp),%xmm2
  826508:	movsd  0x10(%rsp),%xmm3
  82650e:	lea    0x48(%rsp),%rdi
  826513:	movsd  0x40(%rsp),%xmm0
  826519:	movsd  0x38(%rsp),%xmm1
  82651f:	call   825910 <<gpui_gpu::renderer::coverage::Interval>::add>
  826524:	cmpb   $0x0,0x48(%rsp)
  826529:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  82652f:	xorpd  %xmm0,%xmm0
  826533:	movapd 0x80(%rsp),%xmm2
  82653c:	ucomisd %xmm0,%xmm2
  826540:	movsd  0x50(%rsp),%xmm0
  826546:	movsd  0x58(%rsp),%xmm1
  82654c:	jne    826550 <gpui_gpu::renderer::coverage::axis+0x320>
  82654e:	jnp    826566 <gpui_gpu::renderer::coverage::axis+0x336>
  826550:	dec    %r13
  826553:	movabs $0xfffffffffffff,%rax
  82655d:	cmp    %rax,%r13
  826560:	jb     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  826566:	andpd  -0x77b73e(%rip),%xmm2        # aae30 <GCC_except_table0+0x64>
  82656e:	lea    0x68(%rsp),%rdi
  826573:	movapd %xmm2,%xmm3
  826577:	call   825910 <<gpui_gpu::renderer::coverage::Interval>::add>
  82657c:	cmpb   $0x0,0x68(%rsp)
  826581:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  826587:	xorpd  %xmm0,%xmm0
  82658b:	movapd 0xb0(%rsp),%xmm2
  826594:	ucomisd %xmm0,%xmm2
  826598:	movsd  0x70(%rsp),%xmm0
  82659e:	movsd  0x78(%rsp),%xmm1
  8265a4:	jne    8265a8 <gpui_gpu::renderer::coverage::axis+0x378>
  8265a6:	jnp    8265be <gpui_gpu::renderer::coverage::axis+0x38e>
  8265a8:	dec    %r12
  8265ab:	movabs $0xfffffffffffff,%rax
  8265b5:	cmp    %rax,%r12
  8265b8:	jb     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  8265be:	andpd  -0x77b796(%rip),%xmm2        # aae30 <GCC_except_table0+0x64>
  8265c6:	lea    0x108(%rsp),%rdi
  8265ce:	movapd %xmm2,%xmm3
  8265d2:	call   825910 <<gpui_gpu::renderer::coverage::Interval>::add>
  8265d7:	cmpb   $0x0,0x108(%rsp)
  8265df:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  8265e5:	xorpd  %xmm0,%xmm0
  8265e9:	movapd 0x90(%rsp),%xmm1
  8265f2:	ucomisd %xmm0,%xmm1
  8265f6:	movsd  0x110(%rsp),%xmm0
  8265ff:	movsd  0x118(%rsp),%xmm1
  826608:	jne    82660c <gpui_gpu::renderer::coverage::axis+0x3dc>
  82660a:	jnp    826622 <gpui_gpu::renderer::coverage::axis+0x3f2>
  82660c:	dec    %r15
  82660f:	movabs $0xfffffffffffff,%rax
  826619:	cmp    %rax,%r15
  82661c:	jb     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  826622:	movapd -0x77b7fa(%rip),%xmm2        # aae30 <GCC_except_table0+0x64>
  82662a:	andpd  0x90(%rsp),%xmm2
  826633:	lea    0xf0(%rsp),%rdi
  82663b:	movapd %xmm2,%xmm3
  82663f:	call   825910 <<gpui_gpu::renderer::coverage::Interval>::add>
  826644:	cmpb   $0x0,0xf0(%rsp)
  82664c:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  826652:	movsd  0xf8(%rsp),%xmm0
  82665b:	movsd  0x100(%rsp),%xmm1
  826664:	lea    0xd8(%rsp),%rdi
  82666c:	movsd  -0x776d94(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  826674:	movapd %xmm2,%xmm3
  826678:	call   825910 <<gpui_gpu::renderer::coverage::Interval>::add>
  82667d:	cmpl   $0x1,0xd8(%rsp)
  826685:	jne    82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  82668b:	movsd  0xe0(%rsp),%xmm0
  826694:	movsd  0xe8(%rsp),%xmm1
  82669d:	mov    %rsp,%rdi
  8266a0:	movsd  0xa8(%rsp),%xmm2
  8266a9:	call   825a80 <<gpui_gpu::renderer::coverage::Interval>::scale>
  8266ae:	cmpb   $0x0,(%rsp)
  8266b2:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  8266b8:	movq   0x30(%rsp),%xmm0
  8266be:	movq   %xmm0,%rax
  8266c3:	and    %rbx,%rax
  8266c6:	cmp    %r14,%rax
  8266c9:	jg     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  8266cf:	movsd  0x8(%rsp),%xmm0
  8266d5:	movsd  0x10(%rsp),%xmm1
  8266db:	xorpd  %xmm2,%xmm2
  8266df:	movsd  0x30(%rsp),%xmm3
  8266e5:	ucomisd %xmm2,%xmm3
  8266e9:	jne    8266ed <gpui_gpu::renderer::coverage::axis+0x4bd>
  8266eb:	jnp    8266ff <gpui_gpu::renderer::coverage::axis+0x4cf>
  8266ed:	dec    %rax
  8266f0:	movabs $0xfffffffffffff,%rcx
  8266fa:	cmp    %rcx,%rax
  8266fd:	jb     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  8266ff:	lea    0x48(%rsp),%rdi
  826704:	movsd  0x30(%rsp),%xmm2
  82670a:	movapd %xmm2,%xmm3
  82670e:	call   825910 <<gpui_gpu::renderer::coverage::Interval>::add>
  826713:	cmpb   $0x0,0x48(%rsp)
  826718:	je     82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  82671a:	movsd  0x58(%rsp),%xmm1
  826720:	movsd  0x18(%rsp),%xmm0
  826726:	movsd  %xmm1,0x28(%rsp)
  82672c:	ucomisd %xmm1,%xmm0
  826730:	jbe    8268a7 <gpui_gpu::renderer::coverage::axis+0x677>
  826736:	mov    %rsp,%rdi
  826739:	movapd 0x90(%rsp),%xmm0
  826742:	movapd %xmm0,%xmm1
  826746:	movsd  0x18(%rsp),%xmm2
  82674c:	movsd  0x20(%rsp),%xmm3
  826752:	call   825d10 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  826757:	cmpl   $0x1,(%rsp)
  82675b:	jne    82676e <gpui_gpu::renderer::coverage::axis+0x53e>
  82675d:	movsd  0x8(%rsp),%xmm0
  826763:	ucomisd 0x28(%rsp),%xmm0
  826769:	seta   %al
  82676c:	jmp    826770 <gpui_gpu::renderer::coverage::axis+0x540>
  82676e:	mov    $0x2,%al
  826770:	add    $0x130,%rsp
  826777:	pop    %rbx
  826778:	pop    %r12
  82677a:	pop    %r13
  82677c:	pop    %r14
  82677e:	pop    %r15
  826780:	ret
  826781:	addsd  %xmm5,%xmm0
  826785:	addsd  %xmm4,%xmm1
  826789:	movq   %xmm0,%rdx
  82678e:	movq   %xmm1,%rcx
  826793:	ucomisd %xmm0,%xmm0
  826797:	setp   %sil
  82679b:	movabs $0xfff0000000000000,%rdi
  8267a5:	cmp    %rdi,%rdx
  8267a8:	sete   %dil
  8267ac:	or     %sil,%dil
  8267af:	jne    8267d7 <gpui_gpu::renderer::coverage::axis+0x5a7>
  8267b1:	mov    %rdx,%rsi
  8267b4:	and    %rbx,%rsi
  8267b7:	je     8267c3 <gpui_gpu::renderer::coverage::axis+0x593>
  8267b9:	cmp    %rsi,%rdx
  8267bc:	jne    8267cf <gpui_gpu::renderer::coverage::axis+0x59f>
  8267be:	dec    %rdx
  8267c1:	jmp    8267d2 <gpui_gpu::renderer::coverage::axis+0x5a2>
  8267c3:	movabs $0x8000000000000001,%rdx
  8267cd:	jmp    8267d2 <gpui_gpu::renderer::coverage::axis+0x5a2>
  8267cf:	inc    %rdx
  8267d2:	movq   %rdx,%xmm0
  8267d7:	ucomisd %xmm1,%xmm1
  8267db:	setp   %dl
  8267de:	movabs $0x7ff0000000000000,%rsi
  8267e8:	cmp    %rsi,%rcx
  8267eb:	sete   %sil
  8267ef:	or     %dl,%sil
  8267f2:	jne    826815 <gpui_gpu::renderer::coverage::axis+0x5e5>
  8267f4:	mov    %rcx,%rdx
  8267f7:	and    %rbx,%rdx
  8267fa:	je     826806 <gpui_gpu::renderer::coverage::axis+0x5d6>
  8267fc:	cmp    %rdx,%rcx
  8267ff:	jne    82680d <gpui_gpu::renderer::coverage::axis+0x5dd>
  826801:	inc    %rcx
  826804:	jmp    826810 <gpui_gpu::renderer::coverage::axis+0x5e0>
  826806:	mov    $0x1,%ecx
  82680b:	jmp    826810 <gpui_gpu::renderer::coverage::axis+0x5e0>
  82680d:	dec    %rcx
  826810:	movq   %rcx,%xmm1
  826815:	movq   %xmm0,%rdx
  82681a:	and    %rbx,%rdx
  82681d:	cmp    %r14,%rdx
  826820:	jg     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  826826:	ucomisd %xmm1,%xmm0
  82682a:	ja     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  826830:	xorpd  %xmm3,%xmm3
  826834:	ucomisd %xmm3,%xmm0
  826838:	movq   %xmm1,%rcx
  82683d:	jne    826841 <gpui_gpu::renderer::coverage::axis+0x611>
  82683f:	jnp    82686e <gpui_gpu::renderer::coverage::axis+0x63e>
  826841:	dec    %rdx
  826844:	mov    %rcx,%rsi
  826847:	and    %rbx,%rsi
  82684a:	cmp    %r14,%rsi
  82684d:	setg   %sil
  826851:	movabs $0xfffffffffffff,%rdi
  82685b:	cmp    %rdi,%rdx
  82685e:	jb     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  826864:	test   %sil,%sil
  826867:	je     82687d <gpui_gpu::renderer::coverage::axis+0x64d>
  826869:	jmp    826770 <gpui_gpu::renderer::coverage::axis+0x540>
  82686e:	mov    %rcx,%rdx
  826871:	and    %rbx,%rdx
  826874:	cmp    %r14,%rdx
  826877:	jg     826770 <gpui_gpu::renderer::coverage::axis+0x540>
  82687d:	ucomisd %xmm3,%xmm1
  826881:	jne    826889 <gpui_gpu::renderer::coverage::axis+0x659>
  826883:	jnp    8263f2 <gpui_gpu::renderer::coverage::axis+0x1c2>
  826889:	and    %rbx,%rcx
  82688c:	dec    %rcx
  82688f:	movabs $0xfffffffffffff,%rdx
  826899:	cmp    %rdx,%rcx
  82689c:	jae    8263f2 <gpui_gpu::renderer::coverage::axis+0x1c2>
  8268a2:	jmp    826770 <gpui_gpu::renderer::coverage::axis+0x540>
  8268a7:	xor    %eax,%eax
  8268a9:	jmp    826770 <gpui_gpu::renderer::coverage::axis+0x540>

FUNCTION gpui_gpu::renderer::coverage::whole bytes=1462 frame=248

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008268b0 <gpui_gpu::renderer::coverage::whole>:
  8268b0:	push   %rbp
  8268b1:	push   %r15
  8268b3:	push   %r14
  8268b5:	push   %r13
  8268b7:	push   %r12
  8268b9:	push   %rbx
  8268ba:	sub    $0xc8,%rsp
  8268c1:	mov    %rsi,0x30(%rsp)
  8268c6:	cmpb   $0x0,(%rdi)
  8268c9:	jne    82696c <gpui_gpu::renderer::coverage::whole+0xbc>
  8268cf:	test   %esi,%esi
  8268d1:	sets   %al
  8268d4:	mov    %esi,%r9d
  8268d7:	and    $0x7fffffff,%r9d
  8268de:	lea    -0x800000(%r9),%r10d
  8268e5:	cmp    $0x7f000000,%r10d
  8268ec:	setb   %r10b
  8268f0:	and    %al,%r10b
  8268f3:	lea    -0x1(%r9),%r11d
  8268f7:	cmp    $0x7fffff,%r11d
  8268fe:	setb   %r11b
  826902:	and    %al,%r11b
  826905:	cmp    $0x7f800000,%r9d
  82690c:	sete   %al
  82690f:	setg   %r9b
  826913:	or     %al,%r9b
  826916:	or     %r11b,%r9b
  826919:	or     %r10b,%r9b
  82691c:	jne    82696c <gpui_gpu::renderer::coverage::whole+0xbc>
  82691e:	shr    $0x20,%rsi
  826922:	test   %esi,%esi
  826924:	sets   %al
  826927:	and    $0x7fffffff,%esi
  82692d:	lea    -0x800000(%rsi),%r9d
  826934:	cmp    $0x7f000000,%r9d
  82693b:	setb   %r9b
  82693f:	and    %al,%r9b
  826942:	lea    -0x1(%rsi),%r10d
  826946:	cmp    $0x7fffff,%r10d
  82694d:	setb   %r10b
  826951:	and    %al,%r10b
  826954:	cmp    $0x7f800000,%esi
  82695a:	sete   %al
  82695d:	setg   %sil
  826961:	or     %al,%sil
  826964:	or     %r10b,%sil
  826967:	or     %r9b,%sil
  82696a:	je     826982 <gpui_gpu::renderer::coverage::whole+0xd2>
  82696c:	xor    %eax,%eax
  82696e:	and    $0x1,%al
  826970:	add    $0xc8,%rsp
  826977:	pop    %rbx
  826978:	pop    %r12
  82697a:	pop    %r13
  82697c:	pop    %r14
  82697e:	pop    %r15
  826980:	pop    %rbp
  826981:	ret
  826982:	movss  0x88(%rdi),%xmm1
  82698a:	movss  -0x777976(%rip),%xmm2        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  826992:	movaps %xmm1,%xmm0
  826995:	subss  %xmm2,%xmm0
  826999:	cvttss2si %xmm0,%rax
  82699e:	cvttss2si %xmm1,%rsi
  8269a3:	mov    %rsi,%r9
  8269a6:	sar    $0x3f,%r9
  8269aa:	and    %rax,%r9
  8269ad:	or     %rsi,%r9
  8269b0:	xor    %eax,%eax
  8269b2:	xorps  %xmm0,%xmm0
  8269b5:	ucomiss %xmm0,%xmm1
  8269b8:	cmovb  %rax,%r9
  8269bc:	movss  0x8c(%rdi),%xmm4
  8269c4:	movss  -0x7779ac(%rip),%xmm3        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8269cc:	ucomiss %xmm3,%xmm1
  8269cf:	mov    $0xffffffffffffffff,%rbx
  8269d6:	cmova  %rbx,%r9
  8269da:	movaps %xmm4,%xmm1
  8269dd:	subss  %xmm2,%xmm1
  8269e1:	cvttss2si %xmm1,%rsi
  8269e6:	cvttss2si %xmm4,%r11
  8269eb:	mov    %r11,%r10
  8269ee:	sar    $0x3f,%r10
  8269f2:	and    %rsi,%r10
  8269f5:	or     %r11,%r10
  8269f8:	ucomiss %xmm0,%xmm4
  8269fb:	cmovb  %rax,%r10
  8269ff:	ucomiss %xmm3,%xmm4
  826a02:	movss  0x90(%rdi),%xmm1
  826a0a:	cmova  %rbx,%r10
  826a0e:	movaps %xmm1,%xmm4
  826a11:	subss  %xmm2,%xmm4
  826a15:	cvttss2si %xmm4,%r11
  826a1a:	cvttss2si %xmm1,%r14
  826a1f:	mov    %r14,%rsi
  826a22:	sar    $0x3f,%rsi
  826a26:	and    %r11,%rsi
  826a29:	or     %r14,%rsi
  826a2c:	ucomiss %xmm0,%xmm1
  826a2f:	cmovb  %rax,%rsi
  826a33:	ucomiss %xmm3,%xmm1
  826a36:	cmova  %rbx,%rsi
  826a3a:	add    %r9,%rsi
  826a3d:	setb   %r11b
  826a41:	sete   %bpl
  826a45:	or     %r11b,%bpl
  826a48:	jne    82696e <gpui_gpu::renderer::coverage::whole+0xbe>
  826a4e:	movss  0x94(%rdi),%xmm2
  826a56:	cvttss2si %xmm2,%rax
  826a5b:	mov    %rax,%r11
  826a5e:	movaps %xmm2,%xmm3
  826a61:	subss  -0x777a4d(%rip),%xmm3        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  826a69:	sar    $0x3f,%r11
  826a6d:	cvttss2si %xmm3,%r14
  826a72:	and    %r11,%r14
  826a75:	or     %rax,%r14
  826a78:	xor    %eax,%eax
  826a7a:	ucomiss %xmm0,%xmm2
  826a7d:	mov    $0x0,%r11d
  826a83:	cmovae %r14,%r11
  826a87:	ucomiss -0x777a6e(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  826a8e:	cmova  %rbx,%r11
  826a92:	add    %r10,%r11
  826a95:	setb   %bl
  826a98:	sete   %bpl
  826a9c:	or     %bl,%bpl
  826a9f:	jne    82696e <gpui_gpu::renderer::coverage::whole+0xbe>
  826aa5:	xor    %eax,%eax
  826aa7:	test   %rdx,%rdx
  826aaa:	je     82696e <gpui_gpu::renderer::coverage::whole+0xbe>
  826ab0:	movss  -0x777cd8(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  826ab8:	ucomiss %xmm1,%xmm0
  826abb:	ja     82696e <gpui_gpu::renderer::coverage::whole+0xbe>
  826ac1:	ucomiss %xmm2,%xmm0
  826ac4:	ja     82696e <gpui_gpu::renderer::coverage::whole+0xbe>
  826aca:	dec    %rsi
  826acd:	dec    %r11
  826ad0:	shr    $0x4,%r10
  826ad4:	imul   %rdx,%r10
  826ad8:	shr    $0x4,%r9
  826adc:	add    %r10,%r9
  826adf:	mov    %r9,%rax
  826ae2:	mov    %rdx,%rbx
  826ae5:	or     %rdx,%rax
  826ae8:	shr    $0x20,%rax
  826aec:	je     826afe <gpui_gpu::renderer::coverage::whole+0x24e>
  826aee:	mov    %r9,%rax
  826af1:	xor    %edx,%edx
  826af3:	div    %rbx
  826af6:	mov    %rdx,%r10
  826af9:	mov    %rax,%r9
  826afc:	jmp    826b0b <gpui_gpu::renderer::coverage::whole+0x25b>
  826afe:	mov    %r9d,%eax
  826b01:	xor    %edx,%edx
  826b03:	div    %ebx
  826b05:	mov    %edx,%r10d
  826b08:	mov    %eax,%r9d
  826b0b:	shl    $0x4,%r10d
  826b0f:	shr    $0x4,%r11
  826b13:	imul   %rbx,%r11
  826b17:	shr    $0x4,%rsi
  826b1b:	add    %r11,%rsi
  826b1e:	mov    %rsi,%rdx
  826b21:	or     %rbx,%rdx
  826b24:	shr    $0x20,%rdx
  826b28:	je     826b34 <gpui_gpu::renderer::coverage::whole+0x284>
  826b2a:	mov    %rsi,%rax
  826b2d:	xor    %edx,%edx
  826b2f:	div    %rbx
  826b32:	jmp    826b3a <gpui_gpu::renderer::coverage::whole+0x28a>
  826b34:	mov    %esi,%eax
  826b36:	xor    %edx,%edx
  826b38:	div    %ebx
  826b3a:	shl    $0x4,%edx
  826b3d:	shl    $0x4,%eax
  826b40:	add    $0x10,%edx
  826b43:	cmp    %edx,%ecx
  826b45:	cmovb  %ecx,%edx
  826b48:	add    $0x10,%eax
  826b4b:	cmp    %eax,%r8d
  826b4e:	cmovb  %r8d,%eax
  826b52:	movss  0x78(%rdi),%xmm0
  826b57:	cvtss2sd %xmm0,%xmm2
  826b5b:	mov    %r10d,%ecx
  826b5e:	xorps  %xmm0,%xmm0
  826b61:	cvtsi2sd %rcx,%xmm0
  826b66:	ucomisd %xmm0,%xmm2
  826b6a:	ja     82696c <gpui_gpu::renderer::coverage::whole+0xbc>
  826b70:	shl    $0x4,%r9d
  826b74:	movss  0x7c(%rdi),%xmm1
  826b79:	cvtss2sd %xmm1,%xmm3
  826b7d:	cvtsi2sd %r9,%xmm4
  826b82:	ucomisd %xmm4,%xmm3
  826b86:	ja     82696c <gpui_gpu::renderer::coverage::whole+0xbc>
  826b8c:	movss  0x80(%rdi),%xmm1
  826b94:	cvtss2sd %xmm1,%xmm1
  826b98:	addsd  %xmm1,%xmm2
  826b9c:	mov    %edx,%ecx
  826b9e:	xorps  %xmm1,%xmm1
  826ba1:	cvtsi2sd %rcx,%xmm1
  826ba6:	ucomisd %xmm2,%xmm1
  826baa:	ja     82696c <gpui_gpu::renderer::coverage::whole+0xbc>
  826bb0:	movss  0x84(%rdi),%xmm2
  826bb8:	cvtss2sd %xmm2,%xmm2
  826bbc:	addsd  %xmm3,%xmm2
  826bc0:	mov    %eax,%eax
  826bc2:	xorps  %xmm3,%xmm3
  826bc5:	cvtsi2sd %rax,%xmm3
  826bca:	ucomisd %xmm2,%xmm3
  826bce:	ja     82696c <gpui_gpu::renderer::coverage::whole+0xbc>
  826bd4:	movsd  %xmm3,(%rsp)
  826bd9:	movsd  %xmm4,0x8(%rsp)
  826bdf:	mov    %rdi,%rbx
  826be2:	addsd  -0x777382(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  826bea:	addsd  -0x77760a(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  826bf2:	lea    0x38(%rsp),%rdi
  826bf7:	call   825c50 <<gpui_gpu::renderer::coverage::Interval>::checked>
  826bfc:	cmpl   $0x1,0x38(%rsp)
  826c01:	jne    82696c <gpui_gpu::renderer::coverage::whole+0xbc>
  826c07:	movsd  0x40(%rsp),%xmm0
  826c0d:	movsd  %xmm0,0x28(%rsp)
  826c13:	movsd  0x48(%rsp),%xmm0
  826c19:	movsd  %xmm0,0x20(%rsp)
  826c1f:	movsd  0x8(%rsp),%xmm0
  826c25:	addsd  -0x7773c5(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  826c2d:	movsd  (%rsp),%xmm1
  826c32:	addsd  -0x777652(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  826c3a:	lea    0x38(%rsp),%rdi
  826c3f:	call   825c50 <<gpui_gpu::renderer::coverage::Interval>::checked>
  826c44:	cmpb   $0x0,0x38(%rsp)
  826c49:	je     82696c <gpui_gpu::renderer::coverage::whole+0xbc>
  826c4f:	movsd  0x40(%rsp),%xmm0
  826c55:	movsd  %xmm0,0x18(%rsp)
  826c5b:	movsd  0x48(%rsp),%xmm0
  826c61:	movsd  %xmm0,0x10(%rsp)
  826c67:	mov    %rbx,%rcx
  826c6a:	movss  0x38(%rbx),%xmm0
  826c6f:	movss  0x3c(%rbx),%xmm1
  826c74:	movss  0x40(%rbx),%xmm2
  826c79:	movss  0x44(%rbx),%xmm3
  826c7e:	lea    0xa8(%rsp),%r14
  826c86:	movq   $0x0,0xa8(%rsp)
  826c92:	movss  %xmm0,0xb0(%rsp)
  826c9b:	movss  %xmm2,0xb4(%rsp)
  826ca4:	movq   $0x1,0xb8(%rsp)
  826cb0:	movss  %xmm1,0xc0(%rsp)
  826cb9:	movss  %xmm3,0xc4(%rsp)
  826cc2:	lea    0x48(%rsp),%r15
  826cc7:	xor    %r12d,%r12d
  826cca:	movabs $0x3ec0000000000000,%r13
  826cd4:	movsd  -0x776e9d(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  826cdd:	xor    %edx,%edx
  826cdf:	shl    $0x4,%rdx
  826ce3:	mov    (%r14,%rdx,1),%rdi
  826ce7:	cmp    $0x6,%rdi
  826ceb:	jae    826e29 <gpui_gpu::renderer::coverage::whole+0x579>
  826cf1:	cmp    $0x4,%rdi
  826cf5:	jae    826e3b <gpui_gpu::renderer::coverage::whole+0x58b>
  826cfb:	mov    %rdi,%rax
  826cfe:	or     $0x4,%rax
  826d02:	cmp    $0x6,%rax
  826d06:	jae    826e51 <gpui_gpu::renderer::coverage::whole+0x5a1>
  826d0c:	movss  0x8(%r14,%rdx,1),%xmm0
  826d13:	movss  0xc(%r14,%rdx,1),%xmm1
  826d1a:	movsd  0x48(%rcx,%rdi,8),%xmm2
  826d20:	movsd  0x48(%rcx,%rax,8),%xmm3
  826d26:	xorps  %xmm4,%xmm4
  826d29:	cvtsd2ss %xmm3,%xmm4
  826d2d:	movsd  0x58(%rcx,%rdi,8),%xmm5
  826d33:	cvtss2sd %xmm4,%xmm4
  826d37:	movss  0x30(%rsp,%rdi,4),%xmm6
  826d3d:	cvtss2sd %xmm6,%xmm6
  826d41:	movq   $0x0,0x38(%rsp)
  826d4a:	movq   $0x2,0x40(%rsp)
  826d53:	movapd %xmm2,%xmm7
  826d57:	unpcklpd %xmm5,%xmm7
  826d5b:	cvtpd2ps %xmm7,%xmm7
  826d5f:	cvtps2pd %xmm7,%xmm7
  826d62:	movups %xmm7,0x48(%rsp)
  826d67:	movsd  %xmm4,0x58(%rsp)
  826d6d:	mov    %r13,0x60(%rsp)
  826d72:	movsd  %xmm6,0x68(%rsp)
  826d78:	movsd  %xmm2,0x70(%rsp)
  826d7e:	movsd  %xmm5,0x78(%rsp)
  826d84:	movsd  %xmm3,0x80(%rsp)
  826d8d:	movups %xmm8,0x88(%rsp)
  826d96:	cvtss2sd %xmm0,%xmm0
  826d9a:	movsd  %xmm0,0x8(%rsp)
  826da0:	xorps  %xmm0,%xmm0
  826da3:	cvtss2sd %xmm1,%xmm0
  826da7:	movsd  %xmm0,(%rsp)
  826dac:	xor    %ebp,%ebp
  826dae:	xor    %eax,%eax
  826db0:	lea    (%rax,%rax,4),%rax
  826db4:	lea    (%r15,%rax,8),%rdi
  826db8:	movsd  0x18(%r15,%rax,8),%xmm6
  826dbf:	movsd  0x20(%r15,%rax,8),%xmm7
  826dc6:	movsd  0x28(%rsp),%xmm0
  826dcc:	movsd  0x20(%rsp),%xmm1
  826dd2:	movsd  0x18(%rsp),%xmm2
  826dd8:	movsd  0x10(%rsp),%xmm3
  826dde:	movsd  0x8(%rsp),%xmm4
  826de4:	movsd  (%rsp),%xmm5
  826de9:	call   826230 <gpui_gpu::renderer::coverage::axis>
  826dee:	cmp    $0x1,%al
  826df0:	jne    82696e <gpui_gpu::renderer::coverage::whole+0xbe>
  826df6:	mov    $0x1,%eax
  826dfb:	test   $0x1,%bpl
  826dff:	mov    $0x1,%bpl
  826e02:	je     826db0 <gpui_gpu::renderer::coverage::whole+0x500>
  826e04:	mov    $0x1,%edx
  826e09:	test   $0x1,%r12b
  826e0d:	mov    $0x1,%r12b
  826e10:	mov    %rbx,%rcx
  826e13:	movsd  -0x776fdc(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  826e1c:	je     826cdf <gpui_gpu::renderer::coverage::whole+0x42f>
  826e22:	mov    $0x1,%al
  826e24:	jmp    82696e <gpui_gpu::renderer::coverage::whole+0xbe>
  826e29:	lea    0x608af0(%rip),%rdx        # e2f920 <anon.9952513c24ceb61dc4fba212e421bc6f.9.llvm.251048117738152227+0x18>
  826e30:	mov    $0x6,%esi
  826e35:	call   *0x65a2d5(%rip)        # e81110 <_DYNAMIC+0x4f8>
  826e3b:	add    $0x2,%rdi
  826e3f:	lea    0x608af2(%rip),%rdx        # e2f938 <anon.9952513c24ceb61dc4fba212e421bc6f.9.llvm.251048117738152227+0x30>
  826e46:	mov    $0x6,%esi
  826e4b:	call   *0x65a2bf(%rip)        # e81110 <_DYNAMIC+0x4f8>
  826e51:	lea    0x608af8(%rip),%rdx        # e2f950 <anon.9952513c24ceb61dc4fba212e421bc6f.9.llvm.251048117738152227+0x48>
  826e58:	mov    $0x6,%esi
  826e5d:	mov    %rax,%rdi
  826e60:	call   *0x65a2aa(%rip)        # e81110 <_DYNAMIC+0x4f8>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-csr-stats-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000827180 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  827180:	push   %r14
  827182:	push   %rbx
  827183:	sub    $0x18,%rsp
  827187:	mov    %rdi,%rbx
  82718a:	mov    (%rdi),%rsi
  82718d:	lea    (%rsi,%rsi,1),%rax
  827191:	cmp    $0x5,%rax
  827195:	mov    $0x4,%r14d
  82719b:	cmovae %rax,%r14
  82719f:	mov    0x8(%rdi),%rdx
  8271a3:	mov    %rsp,%rdi
  8271a6:	mov    $0x4,%r8d
  8271ac:	mov    $0x20,%r9d
  8271b2:	mov    %r14,%rcx
  8271b5:	call   8271f0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  8271ba:	cmpl   $0x1,(%rsp)
  8271be:	je     8271d4 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  8271c0:	mov    0x8(%rsp),%rax
  8271c5:	mov    %rax,0x8(%rbx)
  8271c9:	mov    %r14,(%rbx)
  8271cc:	add    $0x18,%rsp
  8271d0:	pop    %rbx
  8271d1:	pop    %r14
  8271d3:	ret
  8271d4:	mov    0x8(%rsp),%rdi
  8271d9:	mov    0x10(%rsp),%rsi
  8271de:	call   *0x659cbc(%rip)        # e80ea0 <_DYNAMIC+0x288>
