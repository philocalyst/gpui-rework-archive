
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816540 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  816540:	push   %rbx
  816541:	test   %rdi,%rdi
  816544:	je     8165a7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  816546:	mov    %rdi,%rbx
  816549:	mov    (%rdi),%rsi
  81654c:	test   %rsi,%rsi
  81654f:	je     816564 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816551:	mov    0x8(%rbx),%rdi
  816555:	shl    $0x3,%rsi
  816559:	mov    $0x8,%edx
  81655e:	call   *0x66a94c(%rip)        # e80eb0 <_DYNAMIC+0x248>
  816564:	mov    0x20(%rbx),%rsi
  816568:	test   %rsi,%rsi
  81656b:	je     816593 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81656d:	mov    %rsi,%rax
  816570:	shl    $0x4,%rax
  816574:	add    %rax,%rsi
  816577:	add    $0x21,%rsi
  81657b:	je     816593 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81657d:	mov    0x18(%rbx),%rdi
  816581:	sub    %rax,%rdi
  816584:	add    $0xfffffffffffffff0,%rdi
  816588:	mov    $0x10,%edx
  81658d:	call   *0x66a91d(%rip)        # e80eb0 <_DYNAMIC+0x248>
  816593:	mov    $0x80,%esi
  816598:	mov    $0x8,%edx
  81659d:	mov    %rbx,%rdi
  8165a0:	pop    %rbx
  8165a1:	jmp    *0x66a909(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8165a7:	pop    %rbx
  8165a8:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816bb0 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816bb0:	push   %rbx
  816bb1:	cmpb   $0x3,0x19c(%rdi)
  816bb8:	jne    816be7 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816bba:	movzbl 0x28(%rdi),%eax
  816bbe:	cmp    $0x4,%eax
  816bc1:	je     816bd5 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816bc3:	cmp    $0x3,%eax
  816bc6:	jne    816be7 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816bc8:	add    $0x168,%rdi
  816bcf:	pop    %rbx
  816bd0:	jmp    816b20 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816bd5:	mov    %rdi,%rbx
  816bd8:	add    $0x30,%rdi
  816bdc:	call   816c00 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816be1:	movw   $0x0,0x29(%rbx)
  816be7:	pop    %rbx
  816be8:	ret
  816be9:	movw   $0x0,0x29(%rbx)
  816bef:	mov    %rax,%rdi
  816bf2:	call   e2d990 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816c00 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816c00:	push   %r15
  816c02:	push   %r14
  816c04:	push   %r12
  816c06:	push   %rbx
  816c07:	push   %rax
  816c08:	mov    %rdi,%rbx
  816c0b:	movzbl 0x9e(%rdi),%eax
  816c12:	test   %eax,%eax
  816c14:	je     816cdb <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816c1a:	cmp    $0x3,%eax
  816c1d:	jne    816d11 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816c23:	mov    0x20(%rbx),%r15
  816c27:	mov    0x28(%rbx),%r12
  816c2b:	mov    (%r12),%rax
  816c2f:	test   %rax,%rax
  816c32:	je     816c39 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816c34:	mov    %r15,%rdi
  816c37:	call   *%rax
  816c39:	mov    0x8(%r12),%rsi
  816c3e:	test   %rsi,%rsi
  816c41:	je     816c51 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816c43:	mov    0x10(%r12),%rdx
  816c48:	mov    %r15,%rdi
  816c4b:	call   *0x66a25f(%rip)        # e80eb0 <_DYNAMIC+0x248>
  816c51:	mov    0x68(%rbx),%rax
  816c55:	lock decq (%rax)
  816c59:	jne    816c65 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816c5b:	lea    0x68(%rbx),%rdi
  816c5f:	call   *0x66a46b(%rip)        # e810d0 <_DYNAMIC+0x468>
  816c65:	movb   $0x0,0x98(%rbx)
  816c6c:	mov    0x60(%rbx),%rax
  816c70:	lock decq (%rax)
  816c74:	jne    816c7f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816c76:	lea    0x60(%rbx),%rdi
  816c7a:	call   812d80 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816c7f:	movw   $0x0,0x99(%rbx)
  816c88:	mov    0x40(%rbx),%rax
  816c8c:	lock decq (%rax)
  816c90:	jne    816c9c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816c92:	lea    0x40(%rbx),%rdi
  816c96:	call   *0x66a43c(%rip)        # e810d8 <_DYNAMIC+0x470>
  816c9c:	movb   $0x0,0x9b(%rbx)
  816ca3:	mov    0x38(%rbx),%rax
  816ca7:	lock decq (%rax)
  816cab:	jne    816cb7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816cad:	lea    0x38(%rbx),%rdi
  816cb1:	call   *0x66a429(%rip)        # e810e0 <_DYNAMIC+0x478>
  816cb7:	movb   $0x0,0x9c(%rbx)
  816cbe:	mov    0x30(%rbx),%rax
  816cc2:	lock decq (%rax)
  816cc6:	jne    816cd2 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816cc8:	lea    0x30(%rbx),%rdi
  816ccc:	call   *0x66a416(%rip)        # e810e8 <_DYNAMIC+0x480>
  816cd2:	movb   $0x0,0x9d(%rbx)
  816cd9:	jmp    816d11 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816cdb:	mov    0x70(%rbx),%rax
  816cdf:	lock decq (%rax)
  816ce3:	jne    816cef <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816ce5:	lea    0x70(%rbx),%rdi
  816ce9:	call   *0x66a3f9(%rip)        # e810e8 <_DYNAMIC+0x480>
  816cef:	mov    0x78(%rbx),%rax
  816cf3:	lock decq (%rax)
  816cf7:	jne    816d11 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816cf9:	add    $0x78,%rbx
  816cfd:	mov    %rbx,%rdi
  816d00:	add    $0x8,%rsp
  816d04:	pop    %rbx
  816d05:	pop    %r12
  816d07:	pop    %r14
  816d09:	pop    %r15
  816d0b:	jmp    *0x66a3cf(%rip)        # e810e0 <_DYNAMIC+0x478>
  816d11:	add    $0x8,%rsp
  816d15:	pop    %rbx
  816d16:	pop    %r12
  816d18:	pop    %r14
  816d1a:	pop    %r15
  816d1c:	ret
  816d1d:	mov    %rax,%r14
  816d20:	movb   $0x0,0x9d(%rbx)
  816d27:	mov    %r14,%rdi
  816d2a:	call   e2d990 <_Unwind_Resume@plt>
  816d2f:	mov    %rax,%r14
  816d32:	jmp    816dec <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816d37:	mov    %rax,%r14
  816d3a:	jmp    816dd1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816d3f:	mov    %rax,%r14
  816d42:	jmp    816db4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816d44:	mov    %rax,%r14
  816d47:	jmp    816d9a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816d49:	mov    %rax,%r14
  816d4c:	mov    0x78(%rbx),%rax
  816d50:	lock decq (%rax)
  816d54:	jne    816d63 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816d56:	add    $0x78,%rbx
  816d5a:	mov    %rbx,%rdi
  816d5d:	call   *0x66a37d(%rip)        # e810e0 <_DYNAMIC+0x478>
  816d63:	mov    %r14,%rdi
  816d66:	call   e2d990 <_Unwind_Resume@plt>
  816d6b:	mov    %rax,%r14
  816d6e:	mov    0x8(%r12),%rsi
  816d73:	test   %rsi,%rsi
  816d76:	je     816d86 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816d78:	mov    0x10(%r12),%rdx
  816d7d:	mov    %r15,%rdi
  816d80:	call   *0x66a12a(%rip)        # e80eb0 <_DYNAMIC+0x248>
  816d86:	mov    0x68(%rbx),%rax
  816d8a:	lock decq (%rax)
  816d8e:	jne    816d9a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816d90:	lea    0x68(%rbx),%rdi
  816d94:	call   *0x66a336(%rip)        # e810d0 <_DYNAMIC+0x468>
  816d9a:	movb   $0x0,0x98(%rbx)
  816da1:	mov    0x60(%rbx),%rax
  816da5:	lock decq (%rax)
  816da9:	jne    816db4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816dab:	lea    0x60(%rbx),%rdi
  816daf:	call   812d80 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816db4:	movw   $0x0,0x99(%rbx)
  816dbd:	mov    0x40(%rbx),%rax
  816dc1:	lock decq (%rax)
  816dc5:	jne    816dd1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816dc7:	lea    0x40(%rbx),%rdi
  816dcb:	call   *0x66a307(%rip)        # e810d8 <_DYNAMIC+0x470>
  816dd1:	movb   $0x0,0x9b(%rbx)
  816dd8:	mov    0x38(%rbx),%rax
  816ddc:	lock decq (%rax)
  816de0:	jne    816dec <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816de2:	lea    0x38(%rbx),%rdi
  816de6:	call   *0x66a2f4(%rip)        # e810e0 <_DYNAMIC+0x478>
  816dec:	movb   $0x0,0x9c(%rbx)
  816df3:	mov    0x30(%rbx),%rax
  816df7:	lock decq (%rax)
  816dfb:	jne    816e07 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816dfd:	lea    0x30(%rbx),%rdi
  816e01:	call   *0x66a2e1(%rip)        # e810e8 <_DYNAMIC+0x480>
  816e07:	movb   $0x0,0x9d(%rbx)
  816e0e:	mov    %r14,%rdi
  816e11:	call   e2d990 <_Unwind_Resume@plt>
  816e16:	call   *0x66a09c(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816e20 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816e20:	push   %rbx
  816e21:	movzbl 0x20(%rdi),%eax
  816e25:	cmp    $0x3,%eax
  816e28:	je     816e43 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816e2a:	cmp    $0x4,%eax
  816e2d:	jne    816e50 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816e2f:	mov    %rdi,%rbx
  816e32:	add    $0x28,%rdi
  816e36:	call   816c00 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816e3b:	movw   $0x0,0x21(%rbx)
  816e41:	pop    %rbx
  816e42:	ret
  816e43:	add    $0x160,%rdi
  816e4a:	pop    %rbx
  816e4b:	jmp    816b20 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816e50:	pop    %rbx
  816e51:	ret
  816e52:	movw   $0x0,0x21(%rbx)
  816e58:	mov    %rax,%rdi
  816e5b:	call   e2d990 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817340 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  817340:	push   %r14
  817342:	push   %rbx
  817343:	push   %rax
  817344:	mov    %rdi,%rbx
  817347:	mov    (%rdi),%rax
  81734a:	lock decq (%rax)
  81734e:	jne    817359 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817350:	mov    %rbx,%rdi
  817353:	call   *0x669d8f(%rip)        # e810e8 <_DYNAMIC+0x480>
  817359:	mov    0x8(%rbx),%rax
  81735d:	lock decq (%rax)
  817361:	jne    81736d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  817363:	lea    0x8(%rbx),%rdi
  817367:	call   *0x669d73(%rip)        # e810e0 <_DYNAMIC+0x478>
  81736d:	mov    0x10(%rbx),%rax
  817371:	lock decq (%rax)
  817375:	jne    817380 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  817377:	lea    0x10(%rbx),%rdi
  81737b:	call   812d80 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  817380:	mov    0x18(%rbx),%rax
  817384:	lock decq (%rax)
  817388:	jne    81739e <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  81738a:	add    $0x18,%rbx
  81738e:	mov    %rbx,%rdi
  817391:	add    $0x8,%rsp
  817395:	pop    %rbx
  817396:	pop    %r14
  817398:	jmp    *0x669d32(%rip)        # e810d0 <_DYNAMIC+0x468>
  81739e:	add    $0x8,%rsp
  8173a2:	pop    %rbx
  8173a3:	pop    %r14
  8173a5:	ret
  8173a6:	mov    %rax,%r14
  8173a9:	jmp    8173da <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  8173ab:	mov    %rax,%r14
  8173ae:	jmp    8173c7 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8173b0:	mov    %rax,%r14
  8173b3:	mov    0x8(%rbx),%rax
  8173b7:	lock decq (%rax)
  8173bb:	jne    8173c7 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8173bd:	lea    0x8(%rbx),%rdi
  8173c1:	call   *0x669d19(%rip)        # e810e0 <_DYNAMIC+0x478>
  8173c7:	mov    0x10(%rbx),%rax
  8173cb:	lock decq (%rax)
  8173cf:	jne    8173da <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  8173d1:	lea    0x10(%rbx),%rdi
  8173d5:	call   812d80 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  8173da:	mov    0x18(%rbx),%rax
  8173de:	lock decq (%rax)
  8173e2:	jne    8173f1 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  8173e4:	add    $0x18,%rbx
  8173e8:	mov    %rbx,%rdi
  8173eb:	call   *0x669cdf(%rip)        # e810d0 <_DYNAMIC+0x468>
  8173f1:	mov    %r14,%rdi
  8173f4:	call   e2d990 <_Unwind_Resume@plt>
  8173f9:	call   *0x669ab9(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1253 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817400 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  817400:	push   %r14
  817402:	push   %rbx
  817403:	push   %rax
  817404:	mov    %rdi,%rbx
  817407:	mov    0x228(%rdi),%rax
  81740e:	lock decq (%rax)
  817412:	jne    817421 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  817414:	lea    0x228(%rbx),%rdi
  81741b:	call   *0x669caf(%rip)        # e810d0 <_DYNAMIC+0x468>
  817421:	mov    0x230(%rbx),%rax
  817428:	lock decq (%rax)
  81742c:	jne    81743b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  81742e:	lea    0x230(%rbx),%rdi
  817435:	call   *0x669d35(%rip)        # e81170 <_DYNAMIC+0x508>
  81743b:	mov    0x238(%rbx),%rax
  817442:	lock decq (%rax)
  817446:	jne    817455 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  817448:	lea    0x238(%rbx),%rdi
  81744f:	call   *0x669d23(%rip)        # e81178 <_DYNAMIC+0x510>
  817455:	mov    0x258(%rbx),%rax
  81745c:	lock decq (%rax)
  817460:	jne    81746f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  817462:	lea    0x258(%rbx),%rdi
  817469:	call   *0x669d01(%rip)        # e81170 <_DYNAMIC+0x508>
  81746f:	mov    0x260(%rbx),%rax
  817476:	lock decq (%rax)
  81747a:	jne    817489 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  81747c:	lea    0x260(%rbx),%rdi
  817483:	call   *0x669cef(%rip)        # e81178 <_DYNAMIC+0x510>
  817489:	mov    0x280(%rbx),%rax
  817490:	lock decq (%rax)
  817494:	jne    8174a3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  817496:	lea    0x280(%rbx),%rdi
  81749d:	call   *0x669ccd(%rip)        # e81170 <_DYNAMIC+0x508>
  8174a3:	mov    0x288(%rbx),%rax
  8174aa:	lock decq (%rax)
  8174ae:	jne    8174bd <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  8174b0:	lea    0x288(%rbx),%rdi
  8174b7:	call   *0x669cbb(%rip)        # e81178 <_DYNAMIC+0x510>
  8174bd:	mov    0x2a8(%rbx),%rax
  8174c4:	lock decq (%rax)
  8174c8:	jne    8174d7 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  8174ca:	lea    0x2a8(%rbx),%rdi
  8174d1:	call   *0x669c99(%rip)        # e81170 <_DYNAMIC+0x508>
  8174d7:	mov    0x2b0(%rbx),%rax
  8174de:	lock decq (%rax)
  8174e2:	jne    8174f1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  8174e4:	lea    0x2b0(%rbx),%rdi
  8174eb:	call   *0x669c87(%rip)        # e81178 <_DYNAMIC+0x510>
  8174f1:	mov    0x2d0(%rbx),%rax
  8174f8:	lock decq (%rax)
  8174fc:	jne    81750b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  8174fe:	lea    0x2d0(%rbx),%rdi
  817505:	call   *0x669c65(%rip)        # e81170 <_DYNAMIC+0x508>
  81750b:	mov    0x2d8(%rbx),%rax
  817512:	lock decq (%rax)
  817516:	jne    817525 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  817518:	lea    0x2d8(%rbx),%rdi
  81751f:	call   *0x669c53(%rip)        # e81178 <_DYNAMIC+0x510>
  817525:	lea    0x78(%rbx),%rdi
  817529:	call   8178f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81752e:	mov    0x328(%rbx),%r14
  817535:	test   %r14,%r14
  817538:	je     817597 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  81753a:	mov    (%r14),%rsi
  81753d:	test   %rsi,%rsi
  817540:	je     817555 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  817542:	mov    0x8(%r14),%rdi
  817546:	shl    $0x3,%rsi
  81754a:	mov    $0x8,%edx
  81754f:	call   *0x66995b(%rip)        # e80eb0 <_DYNAMIC+0x248>
  817555:	mov    0x20(%r14),%rsi
  817559:	test   %rsi,%rsi
  81755c:	je     817584 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81755e:	mov    %rsi,%rax
  817561:	shl    $0x4,%rax
  817565:	add    %rax,%rsi
  817568:	add    $0x21,%rsi
  81756c:	je     817584 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81756e:	mov    0x18(%r14),%rdi
  817572:	sub    %rax,%rdi
  817575:	add    $0xfffffffffffffff0,%rdi
  817579:	mov    $0x10,%edx
  81757e:	call   *0x66992c(%rip)        # e80eb0 <_DYNAMIC+0x248>
  817584:	mov    $0x80,%esi
  817589:	mov    $0x8,%edx
  81758e:	mov    %r14,%rdi
  817591:	call   *0x669919(%rip)        # e80eb0 <_DYNAMIC+0x248>
  817597:	mov    (%rbx),%rsi
  81759a:	test   %rsi,%rsi
  81759d:	je     8175b2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  81759f:	mov    0x8(%rbx),%rdi
  8175a3:	shl    $0x4,%rsi
  8175a7:	mov    $0x4,%edx
  8175ac:	call   *0x6698fe(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8175b2:	mov    0x18(%rbx),%rsi
  8175b6:	test   %rsi,%rsi
  8175b9:	je     8175ce <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  8175bb:	mov    0x20(%rbx),%rdi
  8175bf:	shl    $0x3,%rsi
  8175c3:	mov    $0x4,%edx
  8175c8:	call   *0x6698e2(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8175ce:	mov    0x30(%rbx),%rsi
  8175d2:	test   %rsi,%rsi
  8175d5:	je     8175ea <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  8175d7:	mov    0x38(%rbx),%rdi
  8175db:	shl    $0x2,%rsi
  8175df:	mov    $0x4,%edx
  8175e4:	call   *0x6698c6(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8175ea:	mov    0x48(%rbx),%rsi
  8175ee:	test   %rsi,%rsi
  8175f1:	je     817606 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  8175f3:	mov    0x50(%rbx),%rdi
  8175f7:	shl    $0x2,%rsi
  8175fb:	mov    $0x4,%edx
  817600:	call   *0x6698aa(%rip)        # e80eb0 <_DYNAMIC+0x248>
  817606:	mov    0x60(%rbx),%rsi
  81760a:	test   %rsi,%rsi
  81760d:	je     817622 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  81760f:	mov    0x68(%rbx),%rdi
  817613:	shl    $0x5,%rsi
  817617:	mov    $0x4,%edx
  81761c:	call   *0x66988e(%rip)        # e80eb0 <_DYNAMIC+0x248>
  817622:	mov    0x300(%rbx),%rsi
  817629:	test   %rsi,%rsi
  81762c:	je     81765c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  81762e:	lea    (%rsi,%rsi,8),%rax
  817632:	lea    0x33(,%rax,4),%rax
  81763a:	and    $0xfffffffffffffff0,%rax
  81763e:	add    %rax,%rsi
  817641:	add    $0x11,%rsi
  817645:	je     81765c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  817647:	mov    0x2f8(%rbx),%rdi
  81764e:	sub    %rax,%rdi
  817651:	mov    $0x10,%edx
  817656:	call   *0x669854(%rip)        # e80eb0 <_DYNAMIC+0x248>
  81765c:	mov    0x330(%rbx),%rax
  817663:	test   %rax,%rax
  817666:	je     817685 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  817668:	lock decq (%rax)
  81766c:	jne    817685 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  81766e:	add    $0x330,%rbx
  817675:	mov    %rbx,%rdi
  817678:	add    $0x8,%rsp
  81767c:	pop    %rbx
  81767d:	pop    %r14
  81767f:	jmp    *0x669afb(%rip)        # e81180 <_DYNAMIC+0x518>
  817685:	add    $0x8,%rsp
  817689:	pop    %rbx
  81768a:	pop    %r14
  81768c:	ret
  81768d:	mov    %rax,%r14
  817690:	jmp    8177bc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817695:	mov    %rax,%r14
  817698:	mov    0x2d8(%rbx),%rax
  81769f:	lock decq (%rax)
  8176a3:	jne    8177bc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8176a9:	lea    0x2d8(%rbx),%rdi
  8176b0:	call   *0x669ac2(%rip)        # e81178 <_DYNAMIC+0x510>
  8176b6:	jmp    8177bc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8176bb:	call   *0x6697f7(%rip)        # e80eb8 <_DYNAMIC+0x250>
  8176c1:	mov    %rax,%r14
  8176c4:	jmp    8177b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  8176c9:	mov    %rax,%r14
  8176cc:	mov    0x2b0(%rbx),%rax
  8176d3:	lock decq (%rax)
  8176d7:	jne    8177b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  8176dd:	lea    0x2b0(%rbx),%rdi
  8176e4:	call   *0x669a8e(%rip)        # e81178 <_DYNAMIC+0x510>
  8176ea:	jmp    8177b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  8176ef:	call   *0x6697c3(%rip)        # e80eb8 <_DYNAMIC+0x250>
  8176f5:	mov    %rax,%r14
  8176f8:	jmp    8177a4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8176fd:	mov    %rax,%r14
  817700:	mov    0x288(%rbx),%rax
  817707:	lock decq (%rax)
  81770b:	jne    8177a4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  817711:	lea    0x288(%rbx),%rdi
  817718:	call   *0x669a5a(%rip)        # e81178 <_DYNAMIC+0x510>
  81771e:	jmp    8177a4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  817723:	call   *0x66978f(%rip)        # e80eb8 <_DYNAMIC+0x250>
  817729:	mov    %rax,%r14
  81772c:	jmp    817798 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81772e:	mov    %rax,%r14
  817731:	mov    0x260(%rbx),%rax
  817738:	lock decq (%rax)
  81773c:	jne    817798 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81773e:	lea    0x260(%rbx),%rdi
  817745:	call   *0x669a2d(%rip)        # e81178 <_DYNAMIC+0x510>
  81774b:	jmp    817798 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81774d:	call   *0x669765(%rip)        # e80eb8 <_DYNAMIC+0x250>
  817753:	mov    %rax,%r14
  817756:	jmp    81778c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817758:	mov    %rax,%r14
  81775b:	mov    0x238(%rbx),%rax
  817762:	lock decq (%rax)
  817766:	jne    81778c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817768:	lea    0x238(%rbx),%rdi
  81776f:	call   *0x669a03(%rip)        # e81178 <_DYNAMIC+0x510>
  817775:	jmp    81778c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817777:	call   *0x66973b(%rip)        # e80eb8 <_DYNAMIC+0x250>
  81777d:	mov    %rax,%r14
  817780:	lea    0x230(%rbx),%rdi
  817787:	call   8179f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81778c:	lea    0x258(%rbx),%rdi
  817793:	call   8179f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817798:	lea    0x280(%rbx),%rdi
  81779f:	call   8179f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8177a4:	lea    0x2a8(%rbx),%rdi
  8177ab:	call   8179f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8177b0:	lea    0x2d0(%rbx),%rdi
  8177b7:	call   8179f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8177bc:	lea    0x78(%rbx),%rdi
  8177c0:	call   8178f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  8177c5:	mov    0x328(%rbx),%rdi
  8177cc:	call   816540 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  8177d1:	mov    (%rbx),%rsi
  8177d4:	test   %rsi,%rsi
  8177d7:	jne    817852 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  8177d9:	mov    0x18(%rbx),%rsi
  8177dd:	test   %rsi,%rsi
  8177e0:	jne    817872 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  8177e6:	mov    0x30(%rbx),%rsi
  8177ea:	test   %rsi,%rsi
  8177ed:	jne    817892 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  8177f3:	mov    0x48(%rbx),%rsi
  8177f7:	test   %rsi,%rsi
  8177fa:	jne    8178b2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  817800:	mov    0x60(%rbx),%rsi
  817804:	test   %rsi,%rsi
  817807:	je     81781c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817809:	mov    0x68(%rbx),%rdi
  81780d:	shl    $0x5,%rsi
  817811:	mov    $0x4,%edx
  817816:	call   *0x669694(%rip)        # e80eb0 <_DYNAMIC+0x248>
  81781c:	lea    0x2f8(%rbx),%rdi
  817823:	call   819d00 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  817828:	mov    0x330(%rbx),%rax
  81782f:	test   %rax,%rax
  817832:	je     81784a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  817834:	lock decq (%rax)
  817838:	jne    81784a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  81783a:	add    $0x330,%rbx
  817841:	mov    %rbx,%rdi
  817844:	call   *0x669936(%rip)        # e81180 <_DYNAMIC+0x518>
  81784a:	mov    %r14,%rdi
  81784d:	call   e2d990 <_Unwind_Resume@plt>
  817852:	mov    0x8(%rbx),%rdi
  817856:	shl    $0x4,%rsi
  81785a:	mov    $0x4,%edx
  81785f:	call   *0x66964b(%rip)        # e80eb0 <_DYNAMIC+0x248>
  817865:	mov    0x18(%rbx),%rsi
  817869:	test   %rsi,%rsi
  81786c:	je     8177e6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  817872:	mov    0x20(%rbx),%rdi
  817876:	shl    $0x3,%rsi
  81787a:	mov    $0x4,%edx
  81787f:	call   *0x66962b(%rip)        # e80eb0 <_DYNAMIC+0x248>
  817885:	mov    0x30(%rbx),%rsi
  817889:	test   %rsi,%rsi
  81788c:	je     8177f3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  817892:	mov    0x38(%rbx),%rdi
  817896:	shl    $0x2,%rsi
  81789a:	mov    $0x4,%edx
  81789f:	call   *0x66960b(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8178a5:	mov    0x48(%rbx),%rsi
  8178a9:	test   %rsi,%rsi
  8178ac:	je     817800 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  8178b2:	mov    0x50(%rbx),%rdi
  8178b6:	shl    $0x2,%rsi
  8178ba:	mov    $0x4,%edx
  8178bf:	call   *0x6695eb(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8178c5:	mov    0x60(%rbx),%rsi
  8178c9:	test   %rsi,%rsi
  8178cc:	jne    817809 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  8178d2:	jmp    81781c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  8178d7:	call   *0x6695db(%rip)        # e80eb8 <_DYNAMIC+0x250>
  8178dd:	mov    %rax,%r14
  8178e0:	jmp    8177c5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008178f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  8178f0:	push   %r14
  8178f2:	push   %rbx
  8178f3:	push   %rax
  8178f4:	mov    %rdi,%rbx
  8178f7:	mov    (%rdi),%rax
  8178fa:	lock decq (%rax)
  8178fe:	jne    817909 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  817900:	mov    %rbx,%rdi
  817903:	call   *0x669847(%rip)        # e81150 <_DYNAMIC+0x4e8>
  817909:	mov    0x50(%rbx),%rax
  81790d:	lock decq (%rax)
  817911:	jne    81791d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  817913:	lea    0x50(%rbx),%rdi
  817917:	call   *0x66982b(%rip)        # e81148 <_DYNAMIC+0x4e0>
  81791d:	mov    0x58(%rbx),%rax
  817921:	lock decq (%rax)
  817925:	jne    817931 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  817927:	lea    0x58(%rbx),%rdi
  81792b:	call   *0x66981f(%rip)        # e81150 <_DYNAMIC+0x4e8>
  817931:	mov    0xb0(%rbx),%rsi
  817938:	test   %rsi,%rsi
  81793b:	je     81796d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81793d:	mov    %rsi,%rax
  817940:	shl    $0x5,%rax
  817944:	add    %rax,%rsi
  817947:	add    $0x31,%rsi
  81794b:	je     81796d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81794d:	mov    0xa8(%rbx),%rdi
  817954:	sub    %rax,%rdi
  817957:	add    $0xffffffffffffffe0,%rdi
  81795b:	mov    $0x10,%edx
  817960:	add    $0x8,%rsp
  817964:	pop    %rbx
  817965:	pop    %r14
  817967:	jmp    *0x669543(%rip)        # e80eb0 <_DYNAMIC+0x248>
  81796d:	add    $0x8,%rsp
  817971:	pop    %rbx
  817972:	pop    %r14
  817974:	ret
  817975:	mov    %rax,%r14
  817978:	jmp    8179a5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81797a:	mov    %rax,%r14
  81797d:	mov    0x58(%rbx),%rax
  817981:	lock decq (%rax)
  817985:	jne    8179a5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817987:	lea    0x58(%rbx),%rdi
  81798b:	call   *0x6697bf(%rip)        # e81150 <_DYNAMIC+0x4e8>
  817991:	jmp    8179a5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817993:	call   *0x66951f(%rip)        # e80eb8 <_DYNAMIC+0x250>
  817999:	mov    %rax,%r14
  81799c:	lea    0x50(%rbx),%rdi
  8179a0:	call   817af0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  8179a5:	add    $0xa8,%rbx
  8179ac:	mov    %rbx,%rdi
  8179af:	call   819d40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  8179b4:	mov    %r14,%rdi
  8179b7:	call   e2d990 <_Unwind_Resume@plt>
  8179bc:	call   *0x6694f6(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008179d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  8179d0:	cmpl   $0x1,(%rdi)
  8179d3:	ja     8179ed <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  8179d5:	mov    0x8(%rdi),%rsi
  8179d9:	test   %rsi,%rsi
  8179dc:	je     8179ed <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  8179de:	mov    0x10(%rdi),%rdi
  8179e2:	mov    $0x1,%edx
  8179e7:	jmp    *0x6694c3(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8179ed:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008179f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8179f0:	push   %r14
  8179f2:	push   %rbx
  8179f3:	push   %rax
  8179f4:	mov    %rdi,%rbx
  8179f7:	mov    (%rdi),%rax
  8179fa:	lock decq (%rax)
  8179fe:	jne    817a09 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  817a00:	mov    %rbx,%rdi
  817a03:	call   *0x669767(%rip)        # e81170 <_DYNAMIC+0x508>
  817a09:	mov    0x8(%rbx),%rax
  817a0d:	lock decq (%rax)
  817a11:	jne    817a27 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  817a13:	add    $0x8,%rbx
  817a17:	mov    %rbx,%rdi
  817a1a:	add    $0x8,%rsp
  817a1e:	pop    %rbx
  817a1f:	pop    %r14
  817a21:	jmp    *0x669751(%rip)        # e81178 <_DYNAMIC+0x510>
  817a27:	add    $0x8,%rsp
  817a2b:	pop    %rbx
  817a2c:	pop    %r14
  817a2e:	ret
  817a2f:	mov    %rax,%r14
  817a32:	mov    0x8(%rbx),%rax
  817a36:	lock decq (%rax)
  817a3a:	jne    817a49 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  817a3c:	add    $0x8,%rbx
  817a40:	mov    %rbx,%rdi
  817a43:	call   *0x66972f(%rip)        # e81178 <_DYNAMIC+0x510>
  817a49:	mov    %r14,%rdi
  817a4c:	call   e2d990 <_Unwind_Resume@plt>
  817a51:	call   *0x669461(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008183c0 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  8183c0:	sub    $0x18,%rsp
  8183c4:	mov    %rsi,%rax
  8183c7:	mov    (%rdi),%ecx
  8183c9:	lea    -0x747548(%rip),%rdx        # d0e88 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  8183d0:	movslq (%rdx,%rcx,4),%rcx
  8183d4:	add    %rdx,%rcx
  8183d7:	jmp    *%rcx
  8183d9:	add    $0x8,%rdi
  8183dd:	mov    %rdi,0x10(%rsp)
  8183e2:	lea    -0x743b97(%rip),%rsi        # d4852 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4582>
  8183e9:	jmp    818478 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  8183ee:	lea    -0x743b7a(%rip),%rsi        # d487b <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x45ab>
  8183f5:	mov    $0x13,%edx
  8183fa:	mov    %rax,%rdi
  8183fd:	add    $0x18,%rsp
  818401:	jmp    *0x668b99(%rip)        # e80fa0 <_DYNAMIC+0x338>
  818407:	add    $0x4,%rdi
  81840b:	mov    %rdi,0x10(%rsp)
  818410:	lea    -0x743bb9(%rip),%rsi        # d485e <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x458e>
  818417:	lea    0x616e7a(%rip),%r8        # e2f298 <__frame_dummy_init_array_entry+0x8c8>
  81841e:	lea    0x10(%rsp),%rcx
  818423:	mov    $0x11,%edx
  818428:	mov    %rax,%rdi
  81842b:	call   *0x668b77(%rip)        # e80fa8 <_DYNAMIC+0x340>
  818431:	add    $0x18,%rsp
  818435:	ret
  818436:	lea    -0x743bce(%rip),%rsi        # d486f <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x459f>
  81843d:	mov    $0xc,%edx
  818442:	mov    %rax,%rdi
  818445:	add    $0x18,%rsp
  818449:	jmp    *0x668b51(%rip)        # e80fa0 <_DYNAMIC+0x338>
  81844f:	lea    -0x743bb2(%rip),%rsi        # d48a4 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x45d4>
  818456:	mov    $0x9,%edx
  81845b:	mov    %rax,%rdi
  81845e:	add    $0x18,%rsp
  818462:	jmp    *0x668b38(%rip)        # e80fa0 <_DYNAMIC+0x338>
  818468:	add    $0x8,%rdi
  81846c:	mov    %rdi,0x10(%rsp)
  818471:	lea    -0x743c20(%rip),%rsi        # d4858 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4588>
  818478:	lea    0x616df9(%rip),%r8        # e2f278 <__frame_dummy_init_array_entry+0x8a8>
  81847f:	lea    0x10(%rsp),%rcx
  818484:	mov    $0x6,%edx
  818489:	mov    %rax,%rdi
  81848c:	call   *0x668b16(%rip)        # e80fa8 <_DYNAMIC+0x340>
  818492:	add    $0x18,%rsp
  818496:	ret
  818497:	add    $0x8,%rdi
  81849b:	mov    %rdi,0x10(%rsp)
  8184a0:	lea    0x616e11(%rip),%rcx        # e2f2b8 <__frame_dummy_init_array_entry+0x8e8>
  8184a7:	mov    %rcx,(%rsp)
  8184ab:	lea    -0x743c24(%rip),%rsi        # d488e <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x45be>
  8184b2:	lea    -0x76964d(%rip),%rcx        # aee6c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  8184b9:	lea    0x10(%rsp),%r9
  8184be:	mov    $0x9,%edx
  8184c3:	mov    $0x4,%r8d
  8184c9:	mov    %rax,%rdi
  8184cc:	call   *0x668cbe(%rip)        # e81190 <_DYNAMIC+0x528>
  8184d2:	add    $0x18,%rsp
  8184d6:	ret
  8184d7:	lea    -0x743c47(%rip),%rsi        # d4897 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x45c7>
  8184de:	mov    $0xd,%edx
  8184e3:	mov    %rax,%rdi
  8184e6:	add    $0x18,%rsp
  8184ea:	jmp    *0x668ab0(%rip)        # e80fa0 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819d40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819d40:	mov    0x8(%rdi),%rsi
  819d44:	test   %rsi,%rsi
  819d47:	je     819d6e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819d49:	mov    %rsi,%rax
  819d4c:	shl    $0x5,%rax
  819d50:	add    %rax,%rsi
  819d53:	add    $0x31,%rsi
  819d57:	je     819d6e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819d59:	mov    (%rdi),%rdi
  819d5c:	sub    %rax,%rdi
  819d5f:	add    $0xffffffffffffffe0,%rdi
  819d63:	mov    $0x10,%edx
  819d68:	jmp    *0x667142(%rip)        # e80eb0 <_DYNAMIC+0x248>
  819d6e:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819d70 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819d70:	mov    0x8(%rdi),%rsi
  819d74:	test   %rsi,%rsi
  819d77:	je     819d9e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819d79:	mov    %rsi,%rax
  819d7c:	shl    $0x4,%rax
  819d80:	add    %rax,%rsi
  819d83:	add    $0x21,%rsi
  819d87:	je     819d9e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819d89:	mov    (%rdi),%rdi
  819d8c:	sub    %rax,%rdi
  819d8f:	add    $0xfffffffffffffff0,%rdi
  819d93:	mov    $0x10,%edx
  819d98:	jmp    *0x667112(%rip)        # e80eb0 <_DYNAMIC+0x248>
  819d9e:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b630 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b630:	push   %r14
  81b632:	push   %rbx
  81b633:	sub    $0x38,%rsp
  81b637:	mov    %rdi,%rbx
  81b63a:	cmpq   $0x0,(%rsi)
  81b63e:	je     81b748 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b644:	movdqu (%rsi),%xmm0
  81b648:	movdqu 0x10(%rsi),%xmm1
  81b64d:	movdqu 0x20(%rsi),%xmm2
  81b652:	movdqa %xmm2,0x20(%rsp)
  81b658:	movdqa %xmm1,0x10(%rsp)
  81b65e:	movdqa %xmm0,(%rsp)
  81b663:	cmpq   $0x0,0x18(%rcx)
  81b668:	je     81b75c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b66e:	lea    0x10(%rsp),%rsi
  81b673:	lea    0x20(%rcx),%rdi
  81b677:	mov    %rcx,%r14
  81b67a:	call   826f50 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b67f:	mov    %rax,%rsi
  81b682:	shr    $0x39,%rsi
  81b686:	mov    (%r14),%rcx
  81b689:	mov    0x8(%r14),%rdx
  81b68d:	movd   %esi,%xmm0
  81b691:	punpcklbw %xmm0,%xmm0
  81b695:	pshuflw $0x0,%xmm0,%xmm0
  81b69a:	pshufd $0x44,%xmm0,%xmm0
  81b69f:	mov    0x10(%rsp),%rsi
  81b6a4:	movzwl 0x1c(%rsp),%edi
  81b6a9:	xor    %r8d,%r8d
  81b6ac:	mov    0x18(%rsp),%r9d
  81b6b1:	pcmpeqd %xmm1,%xmm1
  81b6b5:	and    %rdx,%rax
  81b6b8:	movdqu (%rcx,%rax,1),%xmm2
  81b6bd:	movdqa %xmm2,%xmm3
  81b6c1:	pcmpeqb %xmm0,%xmm3
  81b6c5:	pmovmskb %xmm3,%r10d
  81b6ca:	test   %r10d,%r10d
  81b6cd:	je     81b710 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b6cf:	tzcnt  %r10d,%r14d
  81b6d4:	add    %rax,%r14
  81b6d7:	and    %rdx,%r14
  81b6da:	shl    $0x5,%r14
  81b6de:	mov    %rcx,%r11
  81b6e1:	sub    %r14,%r11
  81b6e4:	cmp    -0x20(%r11),%rsi
  81b6e8:	jne    81b6f7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b6ea:	cmp    -0x14(%r11),%di
  81b6ef:	jne    81b6f7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b6f1:	cmp    -0x18(%r11),%r9d
  81b6f5:	je     81b72b <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b6f7:	lea    -0x1(%r10),%r11d
  81b6fb:	and    %r10w,%r11w
  81b6ff:	mov    %r11d,%r10d
  81b702:	jne    81b6cf <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b704:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b710:	pcmpeqb %xmm1,%xmm2
  81b714:	pmovmskb %xmm2,%r10d
  81b719:	test   %r10d,%r10d
  81b71c:	jne    81b75c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b71e:	add    %r8,%rax
  81b721:	add    $0x10,%rax
  81b725:	add    $0x10,%r8
  81b729:	jmp    81b6b5 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b72b:	mov    -0x4(%r11),%eax
  81b72f:	shl    $0x10,%eax
  81b732:	or     -0x8(%r11),%eax
  81b736:	mov    -0x10(%r11),%rcx
  81b73a:	mov    %rcx,(%rbx)
  81b73d:	mov    %eax,0x8(%rbx)
  81b740:	add    $0x38,%rsp
  81b744:	pop    %rbx
  81b745:	pop    %r14
  81b747:	ret
  81b748:	mov    0x8(%rdx),%eax
  81b74b:	mov    %eax,0x8(%rbx)
  81b74e:	mov    (%rdx),%rax
  81b751:	mov    %rax,(%rbx)
  81b754:	add    $0x38,%rsp
  81b758:	pop    %rbx
  81b759:	pop    %r14
  81b75b:	ret
  81b75c:	lea    -0x746abe(%rip),%rdi        # d4ca5 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x147>
  81b763:	lea    0x613f86(%rip),%rdx        # e2f6f0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x68>
  81b76a:	mov    $0x16,%esi
  81b76f:	call   *0x665a93(%rip)        # e81208 <_DYNAMIC+0x5a0>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081ba70 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81ba70:	push   %r14
  81ba72:	push   %rbx
  81ba73:	push   %rax
  81ba74:	mov    %rdi,%rbx
  81ba77:	mov    (%rdi),%rax
  81ba7a:	lock decq (%rax)
  81ba7e:	jne    81ba89 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81ba80:	mov    %rbx,%rdi
  81ba83:	call   *0x6656c7(%rip)        # e81150 <_DYNAMIC+0x4e8>
  81ba89:	mov    0x50(%rbx),%rax
  81ba8d:	lock decq (%rax)
  81ba91:	jne    81ba9d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81ba93:	lea    0x50(%rbx),%rdi
  81ba97:	call   *0x6656ab(%rip)        # e81148 <_DYNAMIC+0x4e0>
  81ba9d:	mov    0x58(%rbx),%rax
  81baa1:	lock decq (%rax)
  81baa5:	jne    81bab1 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81baa7:	lea    0x58(%rbx),%rdi
  81baab:	call   *0x66569f(%rip)        # e81150 <_DYNAMIC+0x4e8>
  81bab1:	mov    0xb0(%rbx),%rsi
  81bab8:	test   %rsi,%rsi
  81babb:	je     81baed <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81babd:	mov    %rsi,%rax
  81bac0:	shl    $0x5,%rax
  81bac4:	add    %rax,%rsi
  81bac7:	add    $0x31,%rsi
  81bacb:	je     81baed <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bacd:	mov    0xa8(%rbx),%rdi
  81bad4:	sub    %rax,%rdi
  81bad7:	add    $0xffffffffffffffe0,%rdi
  81badb:	mov    $0x10,%edx
  81bae0:	add    $0x8,%rsp
  81bae4:	pop    %rbx
  81bae5:	pop    %r14
  81bae7:	jmp    *0x6653c3(%rip)        # e80eb0 <_DYNAMIC+0x248>
  81baed:	add    $0x8,%rsp
  81baf1:	pop    %rbx
  81baf2:	pop    %r14
  81baf4:	ret
  81baf5:	mov    %rax,%r14
  81baf8:	jmp    81bb25 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bafa:	mov    %rax,%r14
  81bafd:	mov    0x58(%rbx),%rax
  81bb01:	lock decq (%rax)
  81bb05:	jne    81bb25 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb07:	lea    0x58(%rbx),%rdi
  81bb0b:	call   *0x66563f(%rip)        # e81150 <_DYNAMIC+0x4e8>
  81bb11:	jmp    81bb25 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb13:	call   *0x66539f(%rip)        # e80eb8 <_DYNAMIC+0x250>
  81bb19:	mov    %rax,%r14
  81bb1c:	lea    0x50(%rbx),%rdi
  81bb20:	call   81c3c0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bb25:	add    $0xa8,%rbx
  81bb2c:	mov    %rbx,%rdi
  81bb2f:	call   823370 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bb34:	mov    %r14,%rdi
  81bb37:	call   e2d990 <_Unwind_Resume@plt>
  81bb3c:	call   *0x665376(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bb50:	push   %r14
  81bb52:	push   %rbx
  81bb53:	push   %rax
  81bb54:	mov    %rdi,%rbx
  81bb57:	mov    (%rdi),%rax
  81bb5a:	lock decq (%rax)
  81bb5e:	jne    81bb69 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bb60:	mov    %rbx,%rdi
  81bb63:	call   *0x665607(%rip)        # e81170 <_DYNAMIC+0x508>
  81bb69:	mov    0x8(%rbx),%rax
  81bb6d:	lock decq (%rax)
  81bb71:	jne    81bb87 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bb73:	add    $0x8,%rbx
  81bb77:	mov    %rbx,%rdi
  81bb7a:	add    $0x8,%rsp
  81bb7e:	pop    %rbx
  81bb7f:	pop    %r14
  81bb81:	jmp    *0x6655f1(%rip)        # e81178 <_DYNAMIC+0x510>
  81bb87:	add    $0x8,%rsp
  81bb8b:	pop    %rbx
  81bb8c:	pop    %r14
  81bb8e:	ret
  81bb8f:	mov    %rax,%r14
  81bb92:	mov    0x8(%rbx),%rax
  81bb96:	lock decq (%rax)
  81bb9a:	jne    81bba9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bb9c:	add    $0x8,%rbx
  81bba0:	mov    %rbx,%rdi
  81bba3:	call   *0x6655cf(%rip)        # e81178 <_DYNAMIC+0x510>
  81bba9:	mov    %r14,%rdi
  81bbac:	call   e2d990 <_Unwind_Resume@plt>
  81bbb1:	call   *0x665301(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c4f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c4f0:	push   %rbp
  81c4f1:	push   %r15
  81c4f3:	push   %r14
  81c4f5:	push   %r13
  81c4f7:	push   %r12
  81c4f9:	push   %rbx
  81c4fa:	sub    $0x28,%rsp
  81c4fe:	movss  0x8c(%rdi),%xmm3
  81c506:	movss  -0x76d4f2(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c50e:	movaps %xmm3,%xmm1
  81c511:	subss  %xmm0,%xmm1
  81c515:	cvttss2si %xmm1,%rax
  81c51a:	cvttss2si %xmm3,%r8
  81c51f:	mov    %r8,%rcx
  81c522:	sar    $0x3f,%rcx
  81c526:	and    %rax,%rcx
  81c529:	or     %r8,%rcx
  81c52c:	xor    %r9d,%r9d
  81c52f:	xorps  %xmm1,%xmm1
  81c532:	ucomiss %xmm1,%xmm3
  81c535:	cmovb  %r9,%rcx
  81c539:	movss  -0x76d521(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c541:	ucomiss %xmm2,%xmm3
  81c544:	mov    $0xffffffffffffffff,%rax
  81c54b:	cmova  %rax,%rcx
  81c54f:	movss  0x94(%rdi),%xmm3
  81c557:	mov    %rcx,%r8
  81c55a:	shr    $0x4,%r8
  81c55e:	movaps %xmm3,%xmm4
  81c561:	subss  %xmm0,%xmm4
  81c565:	cvttss2si %xmm4,%r10
  81c56a:	cvttss2si %xmm3,%r11
  81c56f:	mov    %r11,%rbx
  81c572:	sar    $0x3f,%rbx
  81c576:	and    %r10,%rbx
  81c579:	or     %r11,%rbx
  81c57c:	ucomiss %xmm1,%xmm3
  81c57f:	cmovb  %r9,%rbx
  81c583:	ucomiss %xmm2,%xmm3
  81c586:	cmova  %rax,%rbx
  81c58a:	mov    %rsi,0x18(%rsp)
  81c58f:	lea    (%rcx,%rbx,1),%r11
  81c593:	dec    %r11
  81c596:	shr    $0x4,%r11
  81c59a:	cmp    %r11,%r8
  81c59d:	jbe    81c5ae <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c59f:	add    $0x28,%rsp
  81c5a3:	pop    %rbx
  81c5a4:	pop    %r12
  81c5a6:	pop    %r13
  81c5a8:	pop    %r14
  81c5aa:	pop    %r15
  81c5ac:	pop    %rbp
  81c5ad:	ret
  81c5ae:	movss  0x88(%rdi),%xmm3
  81c5b6:	movaps %xmm3,%xmm4
  81c5b9:	subss  %xmm0,%xmm4
  81c5bd:	cvttss2si %xmm4,%rsi
  81c5c2:	cvttss2si %xmm3,%r9
  81c5c7:	mov    %r9,%rcx
  81c5ca:	sar    $0x3f,%rcx
  81c5ce:	and    %rsi,%rcx
  81c5d1:	or     %r9,%rcx
  81c5d4:	xor    %r10d,%r10d
  81c5d7:	ucomiss %xmm1,%xmm3
  81c5da:	cmovb  %r10,%rcx
  81c5de:	ucomiss %xmm2,%xmm3
  81c5e1:	cmova  %rax,%rcx
  81c5e5:	movss  0x90(%rdi),%xmm3
  81c5ed:	mov    %rcx,%r14
  81c5f0:	shr    $0x4,%r14
  81c5f4:	movaps %xmm3,%xmm4
  81c5f7:	subss  %xmm0,%xmm4
  81c5fb:	cvttss2si %xmm4,%rsi
  81c600:	cvttss2si %xmm3,%rdi
  81c605:	mov    %rdi,%r9
  81c608:	sar    $0x3f,%r9
  81c60c:	and    %rsi,%r9
  81c60f:	or     %rdi,%r9
  81c612:	ucomiss %xmm1,%xmm3
  81c615:	cmovb  %r10,%r9
  81c619:	ucomiss %xmm2,%xmm3
  81c61c:	cmova  %rax,%r9
  81c620:	lea    (%r9,%rcx,1),%rbx
  81c624:	dec    %rbx
  81c627:	shr    $0x4,%rbx
  81c62b:	mov    %r14,0x10(%rsp)
  81c630:	cmp    %rbx,%r14
  81c633:	jbe    81c65d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c635:	data16 cs nopw 0x0(%rax,%rax,1)
  81c640:	mov    %r8,%rax
  81c643:	cmp    %r11,%r8
  81c646:	adc    $0x0,%r8
  81c64a:	cmp    %r11,%rax
  81c64d:	jae    81c59f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c653:	cmp    %r11,%r8
  81c656:	jbe    81c640 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c658:	jmp    81c59f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c65d:	mov    (%rdx),%r14
  81c660:	mov    0x8(%rdx),%r15
  81c664:	mov    0x10(%rdx),%r12
  81c668:	mov    0x18(%rdx),%r13
  81c66c:	mov    0x20(%rdx),%rdx
  81c670:	mov    %r11,0x8(%rsp)
  81c675:	data16 cs nopw 0x0(%rax,%rax,1)
  81c680:	mov    %r8,%rbp
  81c683:	cmp    %r11,%r8
  81c686:	adc    $0x0,%r8
  81c68a:	mov    %rbp,0x20(%rsp)
  81c68f:	imul   0x18(%rsp),%rbp
  81c695:	mov    0x10(%rsp),%r9
  81c69a:	mov    %r9,%rsi
  81c69d:	nopl   (%rax)
  81c6a0:	cmp    %rbx,%r9
  81c6a3:	adc    $0x0,%rsi
  81c6a7:	lea    (%r9,%rbp,1),%rdi
  81c6ab:	mov    0x10(%r14),%rax
  81c6af:	cmp    %rax,%rdi
  81c6b2:	jae    81c720 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c6b4:	mov    0x8(%r14),%rcx
  81c6b8:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c6bd:	jo     81c6f5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c6bf:	mov    0x10(%r12),%rax
  81c6c4:	cmp    %rax,%rdi
  81c6c7:	jae    81c730 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c6c9:	mov    0x8(%r12),%rax
  81c6ce:	mov    0x0(%r13),%r11d
  81c6d2:	inc    %r11d
  81c6d5:	cmp    (%rax,%rdi,4),%r11d
  81c6d9:	jb     81c6f5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c6db:	mov    (%rcx,%rdi,8),%eax
  81c6de:	dec    %eax
  81c6e0:	mov    %eax,(%rcx,%rdi,8)
  81c6e3:	mov    0x10(%r15),%rcx
  81c6e7:	cmp    %rax,%rcx
  81c6ea:	jbe    81c740 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c6ec:	mov    0x8(%r15),%rcx
  81c6f0:	mov    (%rdx),%edi
  81c6f2:	mov    %edi,(%rcx,%rax,4)
  81c6f5:	cmp    %rbx,%r9
  81c6f8:	jae    81c702 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c6fa:	mov    %rsi,%r9
  81c6fd:	cmp    %rbx,%rsi
  81c700:	jbe    81c6a0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c702:	mov    0x8(%rsp),%r11
  81c707:	cmp    %r11,0x20(%rsp)
  81c70c:	jae    81c59f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c712:	cmp    %r11,%r8
  81c715:	jbe    81c680 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c71b:	jmp    81c59f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c720:	lea    0x612fe1(%rip),%rdx        # e2f708 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c727:	mov    %rax,%rsi
  81c72a:	call   *0x664a30(%rip)        # e81160 <_DYNAMIC+0x4f8>
  81c730:	lea    0x612fe9(%rip),%rdx        # e2f720 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c737:	mov    %rax,%rsi
  81c73a:	call   *0x664a20(%rip)        # e81160 <_DYNAMIC+0x4f8>
  81c740:	lea    0x612ff1(%rip),%rdx        # e2f738 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  81c747:	mov    %rax,%rdi
  81c74a:	mov    %rcx,%rsi
  81c74d:	call   *0x664a0d(%rip)        # e81160 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>> bytes=321 frame=248

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c760 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>:
  81c760:	push   %rbp
  81c761:	push   %r15
  81c763:	push   %r14
  81c765:	push   %r13
  81c767:	push   %r12
  81c769:	push   %rbx
  81c76a:	sub    $0xc8,%rsp
  81c771:	mov    %edx,%ebp
  81c773:	mov    %rsi,%r14
  81c776:	mov    %rdi,(%rsp)
  81c77a:	lea    0x8(%rsp),%rdi
  81c77f:	call   *0x664a9b(%rip)        # e81220 <_DYNAMIC+0x5b8>
  81c785:	mov    0x8(%rsp),%rsi
  81c78a:	xor    %r13d,%r13d
  81c78d:	test   $0x1,%bpl
  81c791:	je     81c830 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xd0>
  81c797:	test   %rsi,%rsi
  81c79a:	je     81c875 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c7a0:	lea    0x70(%rsp),%r15
  81c7a5:	lea    0x8(%rsp),%r12
  81c7aa:	mov    0x664a6f(%rip),%rbp        # e81220 <_DYNAMIC+0x5b8>
  81c7b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c7c0:	mov    0x18(%rsp),%rbx
  81c7c5:	cmp    $0x1,%rbx
  81c7c9:	jbe    81c810 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb0>
  81c7cb:	mov    0x10(%rsp),%rax
  81c7d0:	mov    (%rax),%edx
  81c7d2:	mov    %r15,%rdi
  81c7d5:	call   81c8b0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c7da:	movss  0x74(%rsp),%xmm0
  81c7e0:	xorps  %xmm1,%xmm1
  81c7e3:	ucomiss %xmm1,%xmm0
  81c7e6:	lea    (%rbx,%rbx,1),%rax
  81c7ea:	lea    0x5(%rbx,%rbx,1),%rcx
  81c7ef:	lea    (%rax,%rax,2),%rdx
  81c7f3:	mov    %rcx,%rax
  81c7f6:	cmovne %rdx,%rax
  81c7fa:	cmovp  %rdx,%rax
  81c7fe:	cmpb   $0x3,0x70(%rsp)
  81c803:	cmovne %rcx,%rax
  81c807:	jmp    81c817 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb7>
  81c809:	nopl   0x0(%rax)
  81c810:	add    %rbx,%rbx
  81c813:	lea    (%rbx,%rbx,2),%rax
  81c817:	add    %rax,%r13
  81c81a:	jb     81c895 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c81c:	mov    %r12,%rdi
  81c81f:	mov    %r14,%rsi
  81c822:	call   *%rbp
  81c824:	mov    0x8(%rsp),%rsi
  81c829:	test   %rsi,%rsi
  81c82c:	jne    81c7c0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x60>
  81c82e:	jmp    81c875 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c830:	test   %rsi,%rsi
  81c833:	je     81c875 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c835:	lea    0x8(%rsp),%r15
  81c83a:	mov    0x6649df(%rip),%r12        # e81220 <_DYNAMIC+0x5b8>
  81c841:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c850:	mov    %r13,%rax
  81c853:	mov    0x18(%rsp),%rcx
  81c858:	add    %rcx,%rcx
  81c85b:	lea    (%rcx,%rcx,2),%r13
  81c85f:	add    %rax,%r13
  81c862:	jb     81c895 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c864:	mov    %r15,%rdi
  81c867:	mov    %r14,%rsi
  81c86a:	call   *%r12
  81c86d:	cmpq   $0x0,0x8(%rsp)
  81c873:	jne    81c850 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xf0>
  81c875:	mov    (%rsp),%rax
  81c879:	mov    %r13,0x8(%rax)
  81c87d:	movl   $0xffffffff,(%rax)
  81c883:	add    $0xc8,%rsp
  81c88a:	pop    %rbx
  81c88b:	pop    %r12
  81c88d:	pop    %r13
  81c88f:	pop    %r14
  81c891:	pop    %r15
  81c893:	pop    %rbp
  81c894:	ret
  81c895:	mov    (%rsp),%rax
  81c899:	movl   $0x6,(%rax)
  81c89f:	jmp    81c883 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x123>

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081caf0 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81caf0:	push   %rbp
  81caf1:	push   %r14
  81caf3:	push   %rbx
  81caf4:	cmp    0x341(%rdi),%sil
  81cafb:	je     81cb3b <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81cafd:	mov    0x330(%rdi),%rax
  81cb04:	test   %rax,%rax
  81cb07:	je     81cb29 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cb09:	lock decq (%rax)
  81cb0d:	jne    81cb29 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cb0f:	lea    0x330(%rdi),%rbx
  81cb16:	mov    %rdi,%r14
  81cb19:	mov    %rbx,%rdi
  81cb1c:	mov    %esi,%ebp
  81cb1e:	call   *0x66465c(%rip)        # e81180 <_DYNAMIC+0x518>
  81cb24:	mov    %r14,%rdi
  81cb27:	mov    %ebp,%esi
  81cb29:	movq   $0x0,0x330(%rdi)
  81cb34:	mov    %sil,0x341(%rdi)
  81cb3b:	pop    %rbx
  81cb3c:	pop    %r14
  81cb3e:	pop    %rbp
  81cb3f:	ret
  81cb40:	movq   $0x0,(%rbx)
  81cb47:	mov    %rax,%rdi
  81cb4a:	call   e2d990 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=303 frame=120

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb50 <<gpui_gpu::renderer::Buffer>::write>:
  81cb50:	push   %r15
  81cb52:	push   %r14
  81cb54:	push   %r13
  81cb56:	push   %r12
  81cb58:	push   %rbx
  81cb59:	sub    $0x50,%rsp
  81cb5d:	mov    %rdx,%r14
  81cb60:	mov    %rdi,%rbx
  81cb63:	cmp    0x20(%rdi),%r8
  81cb67:	jbe    81cc1a <<gpui_gpu::renderer::Buffer>::write+0xca>
  81cb6d:	mov    %rcx,%r15
  81cb70:	mov    $0x1,%r13d
  81cb76:	cmp    $0x2,%r8
  81cb7a:	jb     81cb93 <<gpui_gpu::renderer::Buffer>::write+0x43>
  81cb7c:	lea    -0x1(%r8),%rax
  81cb80:	bsr    %rax,%rcx
  81cb84:	not    %ecx
  81cb86:	mov    $0xffffffffffffffff,%r13
  81cb8d:	shr    %cl,%r13
  81cb90:	inc    %r13
  81cb93:	mov    %r8,%r12
  81cb96:	lea    -0x747ee2(%rip),%rax        # d4cbb <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x15d>
  81cb9d:	mov    %rax,0x30(%rsp)
  81cba2:	movq   $0xa,0x38(%rsp)
  81cbab:	mov    %r13,0x40(%rsp)
  81cbb0:	movl   $0x88,0x48(%rsp)
  81cbb8:	movb   $0x0,0x4c(%rsp)
  81cbbd:	lea    0x8(%rsp),%rdi
  81cbc2:	lea    0x30(%rsp),%rdx
  81cbc7:	call   *0x6646b3(%rip)        # e81280 <_DYNAMIC+0x618>
  81cbcd:	mov    %r13,0x28(%rsp)
  81cbd2:	mov    (%rbx),%rax
  81cbd5:	lock decq (%rax)
  81cbd9:	jne    81cbe4 <<gpui_gpu::renderer::Buffer>::write+0x94>
  81cbdb:	mov    %rbx,%rdi
  81cbde:	call   *0x66458c(%rip)        # e81170 <_DYNAMIC+0x508>
  81cbe4:	mov    0x8(%rbx),%rax
  81cbe8:	lock decq (%rax)
  81cbec:	jne    81cbf8 <<gpui_gpu::renderer::Buffer>::write+0xa8>
  81cbee:	lea    0x8(%rbx),%rdi
  81cbf2:	call   *0x664580(%rip)        # e81178 <_DYNAMIC+0x510>
  81cbf8:	mov    0x28(%rsp),%rax
  81cbfd:	mov    %rax,0x20(%rbx)
  81cc01:	movups 0x8(%rsp),%xmm0
  81cc06:	movups 0x18(%rsp),%xmm1
  81cc0b:	movups %xmm1,0x10(%rbx)
  81cc0f:	movups %xmm0,(%rbx)
  81cc12:	mov    %r12,%r8
  81cc15:	mov    %r15,%rcx
  81cc18:	jmp    81cc1f <<gpui_gpu::renderer::Buffer>::write+0xcf>
  81cc1a:	test   %r8,%r8
  81cc1d:	je     81cc2d <<gpui_gpu::renderer::Buffer>::write+0xdd>
  81cc1f:	mov    %r14,%rdi
  81cc22:	mov    %rbx,%rsi
  81cc25:	xor    %edx,%edx
  81cc27:	call   *0x66460b(%rip)        # e81238 <_DYNAMIC+0x5d0>
  81cc2d:	add    $0x50,%rsp
  81cc31:	pop    %rbx
  81cc32:	pop    %r12
  81cc34:	pop    %r13
  81cc36:	pop    %r14
  81cc38:	pop    %r15
  81cc3a:	ret
  81cc3b:	mov    %rax,%r14
  81cc3e:	jmp    81cc57 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cc40:	mov    %rax,%r14
  81cc43:	mov    0x8(%rbx),%rax
  81cc47:	lock decq (%rax)
  81cc4b:	jne    81cc57 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cc4d:	lea    0x8(%rbx),%rdi
  81cc51:	call   *0x664521(%rip)        # e81178 <_DYNAMIC+0x510>
  81cc57:	mov    0x28(%rsp),%rax
  81cc5c:	mov    %rax,0x20(%rbx)
  81cc60:	movups 0x8(%rsp),%xmm0
  81cc65:	movups 0x18(%rsp),%xmm1
  81cc6a:	movups %xmm1,0x10(%rbx)
  81cc6e:	movups %xmm0,(%rbx)
  81cc71:	mov    %r14,%rdi
  81cc74:	call   e2d990 <_Unwind_Resume@plt>
  81cc79:	call   *0x664239(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc80 <<gpui_gpu::renderer::Atlas>::new>:
  81cc80:	push   %rbp
  81cc81:	push   %r14
  81cc83:	push   %rbx
  81cc84:	sub    $0x160,%rsp
  81cc8b:	mov    %edx,%ebp
  81cc8d:	mov    %rdi,%rbx
  81cc90:	lea    -0x747fd2(%rip),%rax        # d4cc5 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x167>
  81cc97:	mov    %rax,(%rsp)
  81cc9b:	movq   $0xe,0x8(%rsp)
  81cca4:	mov    %edx,0x10(%rsp)
  81cca8:	mov    %edx,0x14(%rsp)
  81ccac:	movaps -0x770743(%rip),%xmm0        # ac570 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81ccb3:	movups %xmm0,0x18(%rsp)
  81ccb8:	movl   $0x0,0x28(%rsp)
  81ccc0:	movl   $0x6,0x34(%rsp)
  81ccc8:	movq   $0x4,0x38(%rsp)
  81ccd1:	movq   $0x0,0x40(%rsp)
  81ccda:	lea    0x110(%rsp),%r14
  81cce2:	mov    %rsp,%rdx
  81cce5:	mov    %r14,%rdi
  81cce8:	call   *0x66441a(%rip)        # e81108 <_DYNAMIC+0x4a0>
  81ccee:	movq   $0x0,0x18(%rsp)
  81ccf7:	movl   $0xffffffff,0x30(%rsp)
  81ccff:	movl   $0x0,(%rsp)
  81cd06:	movabs $0xffffffff00000000,%rax
  81cd10:	mov    %rax,0x28(%rsp)
  81cd15:	movq   $0x0,0x3c(%rsp)
  81cd1e:	movl   $0x0,0x8(%rsp)
  81cd26:	movl   $0x0,0x10(%rsp)
  81cd2e:	lea    0xb8(%rsp),%rdi
  81cd36:	mov    %rsp,%rdx
  81cd39:	mov    %r14,%rsi
  81cd3c:	call   *0x6643ce(%rip)        # e81110 <_DYNAMIC+0x4a8>
  81cd42:	movups 0x150(%rsp),%xmm0
  81cd4a:	movaps %xmm0,0xa0(%rsp)
  81cd52:	movups 0x110(%rsp),%xmm0
  81cd5a:	movups 0x120(%rsp),%xmm1
  81cd62:	movups 0x130(%rsp),%xmm2
  81cd6a:	movups 0x140(%rsp),%xmm3
  81cd72:	movaps %xmm3,0x90(%rsp)
  81cd7a:	movaps %xmm2,0x80(%rsp)
  81cd82:	movaps %xmm1,0x70(%rsp)
  81cd87:	movaps %xmm0,0x60(%rsp)
  81cd8c:	mov    0x108(%rsp),%rax
  81cd94:	mov    %rax,0x50(%rsp)
  81cd99:	movups 0xf8(%rsp),%xmm0
  81cda1:	movaps %xmm0,0x40(%rsp)
  81cda6:	movups 0xb8(%rsp),%xmm0
  81cdae:	movups 0xc8(%rsp),%xmm1
  81cdb6:	movups 0xd8(%rsp),%xmm2
  81cdbe:	movups 0xe8(%rsp),%xmm3
  81cdc6:	movaps %xmm3,0x30(%rsp)
  81cdcb:	movaps %xmm2,0x20(%rsp)
  81cdd0:	movaps %xmm1,0x10(%rsp)
  81cdd5:	movaps %xmm0,(%rsp)
  81cdd9:	mov    %fs:0x0,%rax
  81cde2:	lea    -0x28(%rax),%rax
  81cde9:	mov    %rax,%r14
  81cdec:	cmpb   $0x1,0x10(%rax)
  81cdf0:	jne    81cedb <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81cdf6:	mov    (%r14),%rax
  81cdf9:	mov    0x8(%r14),%rdx
  81cdfd:	lea    0x1(%rax),%rcx
  81ce01:	mov    %rcx,(%r14)
  81ce04:	movaps 0xa0(%rsp),%xmm0
  81ce0c:	movups %xmm0,0x40(%rbx)
  81ce10:	movaps 0x60(%rsp),%xmm0
  81ce15:	movaps 0x70(%rsp),%xmm1
  81ce1a:	movaps 0x80(%rsp),%xmm2
  81ce22:	movaps 0x90(%rsp),%xmm3
  81ce2a:	movups %xmm3,0x30(%rbx)
  81ce2e:	movups %xmm2,0x20(%rbx)
  81ce32:	movups %xmm1,0x10(%rbx)
  81ce36:	movups %xmm0,(%rbx)
  81ce39:	movups 0xb8(%rsp),%xmm0
  81ce41:	movups 0xc8(%rsp),%xmm1
  81ce49:	movups 0xd8(%rsp),%xmm2
  81ce51:	movups 0xe8(%rsp),%xmm3
  81ce59:	movups %xmm0,0x50(%rbx)
  81ce5d:	movups %xmm1,0x60(%rbx)
  81ce61:	movups %xmm2,0x70(%rbx)
  81ce65:	movups %xmm3,0x80(%rbx)
  81ce6c:	movups 0xf8(%rsp),%xmm0
  81ce74:	movups %xmm0,0x90(%rbx)
  81ce7b:	mov    0x108(%rsp),%rcx
  81ce83:	mov    %rcx,0xa0(%rbx)
  81ce8a:	mov    %ebp,0xd8(%rbx)
  81ce90:	movq   $0x0,0xdc(%rbx)
  81ce9b:	movl   $0x0,0xe4(%rbx)
  81cea5:	movups 0x612904(%rip),%xmm0        # e2f7b0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x128>
  81ceac:	movups %xmm0,0xa8(%rbx)
  81ceb3:	movups 0x612906(%rip),%xmm0        # e2f7c0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x138>
  81ceba:	movups %xmm0,0xb8(%rbx)
  81cec1:	mov    %rax,0xc8(%rbx)
  81cec8:	mov    %rdx,0xd0(%rbx)
  81cecf:	add    $0x160,%rsp
  81ced6:	pop    %rbx
  81ced7:	pop    %r14
  81ced9:	pop    %rbp
  81ceda:	ret
  81cedb:	call   *0x6643a7(%rip)        # e81288 <_DYNAMIC+0x620>
  81cee1:	mov    %rax,(%r14)
  81cee4:	mov    %rdx,0x8(%r14)
  81cee8:	movb   $0x1,0x10(%r14)
  81ceed:	jmp    81cdfd <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cef2:	mov    %rax,%rbx
  81cef5:	mov    %rsp,%rdi
  81cef8:	call   81c3c0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cefd:	mov    0x60(%rsp),%rax
  81cf02:	lock decq (%rax)
  81cf06:	jne    81cf34 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf08:	lea    0x60(%rsp),%rdi
  81cf0d:	call   *0x66423d(%rip)        # e81150 <_DYNAMIC+0x4e8>
  81cf13:	jmp    81cf34 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf15:	mov    %rax,%rbx
  81cf18:	mov    0x110(%rsp),%rax
  81cf20:	lock decq (%rax)
  81cf24:	jne    81cf34 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf26:	lea    0x110(%rsp),%rdi
  81cf2e:	call   *0x66421c(%rip)        # e81150 <_DYNAMIC+0x4e8>
  81cf34:	mov    %rbx,%rdi
  81cf37:	call   e2d990 <_Unwind_Resume@plt>
  81cf3c:	call   *0x663f76(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cf50 <<gpui_gpu::renderer::Atlas>::insert>:
  81cf50:	push   %rbp
  81cf51:	push   %r15
  81cf53:	push   %r14
  81cf55:	push   %r13
  81cf57:	push   %r12
  81cf59:	push   %rbx
  81cf5a:	sub    $0x68,%rsp
  81cf5e:	mov    %rdx,%r12
  81cf61:	mov    %rsi,%r15
  81cf64:	mov    %rdi,%r14
  81cf67:	lea    0x10(%rdx),%r13
  81cf6b:	cmpq   $0x0,0xc0(%rdi)
  81cf73:	je     81d03b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81cf79:	lea    0xc8(%r14),%rdi
  81cf80:	mov    %r13,%rsi
  81cf83:	call   826f50 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81cf88:	mov    %rax,%rsi
  81cf8b:	shr    $0x39,%rsi
  81cf8f:	mov    0xa8(%r14),%rcx
  81cf96:	mov    0xb0(%r14),%rdx
  81cf9d:	movd   %esi,%xmm0
  81cfa1:	punpcklbw %xmm0,%xmm0
  81cfa5:	pshuflw $0x0,%xmm0,%xmm0
  81cfaa:	pshufd $0x44,%xmm0,%xmm0
  81cfaf:	mov    0x10(%r12),%rsi
  81cfb4:	movzwl 0x1c(%r12),%edi
  81cfba:	mov    0x18(%r12),%r8d
  81cfbf:	pcmpeqd %xmm1,%xmm1
  81cfc3:	xor    %r9d,%r9d
  81cfc6:	and    %rdx,%rax
  81cfc9:	movdqu (%rcx,%rax,1),%xmm2
  81cfce:	movdqa %xmm2,%xmm3
  81cfd2:	pcmpeqb %xmm0,%xmm3
  81cfd6:	pmovmskb %xmm3,%r10d
  81cfdb:	test   %r10d,%r10d
  81cfde:	je     81d020 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81cfe0:	tzcnt  %r10d,%ebx
  81cfe5:	add    %rax,%rbx
  81cfe8:	and    %rdx,%rbx
  81cfeb:	shl    $0x5,%rbx
  81cfef:	mov    %rcx,%r11
  81cff2:	sub    %rbx,%r11
  81cff5:	cmp    -0x20(%r11),%rsi
  81cff9:	jne    81d00c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81cffb:	cmp    -0x14(%r11),%di
  81d000:	jne    81d00c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d002:	cmp    -0x18(%r11),%r8d
  81d006:	je     81d0a3 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d00c:	lea    -0x1(%r10),%r11d
  81d010:	and    %r10w,%r11w
  81d014:	mov    %r11d,%r10d
  81d017:	jne    81cfe0 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d019:	nopl   0x0(%rax)
  81d020:	pcmpeqb %xmm1,%xmm2
  81d024:	pmovmskb %xmm2,%r10d
  81d029:	test   %r10d,%r10d
  81d02c:	jne    81d03b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d02e:	add    %r9,%rax
  81d031:	add    $0x10,%rax
  81d035:	add    $0x10,%r9
  81d039:	jmp    81cfc6 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d03b:	mov    0x20(%r12),%ebp
  81d040:	xor    %eax,%eax
  81d042:	test   %ebp,%ebp
  81d044:	je     81d09e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d046:	mov    %r15,%rdi
  81d049:	mov    0x28(%r12),%r15d
  81d04e:	test   %r15d,%r15d
  81d051:	je     81d09e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d053:	mov    0xd8(%r14),%ecx
  81d05a:	cmp    %ebp,%ecx
  81d05c:	jb     81d1a1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d062:	cmp    %r15d,%ecx
  81d065:	jb     81d1a1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d06b:	mov    %r13,0x40(%rsp)
  81d070:	mov    0xdc(%r14),%r8d
  81d077:	mov    0xe4(%r14),%r13d
  81d07e:	lea    (%r8,%rbp,1),%edx
  81d082:	xor    %eax,%eax
  81d084:	cmp    %ecx,%edx
  81d086:	mov    $0x0,%ebx
  81d08b:	cmova  %r13d,%ebx
  81d08f:	add    0xe0(%r14),%ebx
  81d096:	lea    (%rbx,%r15,1),%esi
  81d09a:	cmp    %ecx,%esi
  81d09c:	jbe    81d0af <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d09e:	jmp    81d1a1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d0a3:	mov    $0x1,%eax
  81d0a8:	xor    %edx,%edx
  81d0aa:	jmp    81d1a1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d0af:	cmp    %r13d,%r15d
  81d0b2:	cmova  %r15d,%r13d
  81d0b6:	cmp    %ecx,%edx
  81d0b8:	cmova  %eax,%r8d
  81d0bc:	lea    0xa8(%r14),%rax
  81d0c3:	mov    %rax,0x38(%rsp)
  81d0c8:	mov    %r14,0x48(%rsp)
  81d0cd:	movl   $0x0,0x50(%rsp)
  81d0d5:	mov    %r8d,0x54(%rsp)
  81d0da:	mov    %ebx,0x58(%rsp)
  81d0de:	movq   $0x0,0x5c(%rsp)
  81d0e7:	mov    (%r12),%rdx
  81d0eb:	mov    0x8(%r12),%rcx
  81d0f0:	mov    %rcx,0x30(%rsp)
  81d0f5:	movq   $0x0,0x8(%rsp)
  81d0fe:	movl   $0x1,0x10(%rsp)
  81d106:	mov    %ebp,0x14(%rsp)
  81d10a:	movl   $0x1,0x18(%rsp)
  81d112:	mov    %r15d,0x1c(%rsp)
  81d117:	mov    %ebp,0x20(%rsp)
  81d11b:	mov    %r15d,0x24(%rsp)
  81d120:	movl   $0x1,0x28(%rsp)
  81d128:	cmova  %r15d,%r13d
  81d12c:	lea    0x48(%rsp),%rsi
  81d131:	mov    %r8,%r12
  81d134:	lea    0x8(%rsp),%r8
  81d139:	lea    0x20(%rsp),%r9
  81d13e:	call   *0x66414c(%rip)        # e81290 <_DYNAMIC+0x628>
  81d144:	lea    (%r12,%rbp,1),%eax
  81d148:	mov    %eax,0xdc(%r14)
  81d14f:	mov    %ebx,0xe0(%r14)
  81d156:	mov    %r13d,0xe4(%r14)
  81d15d:	mov    0x40(%rsp),%rax
  81d162:	movdqu (%rax),%xmm0
  81d166:	movdqa %xmm0,0x20(%rsp)
  81d16c:	mov    %r12d,0x8(%rsp)
  81d171:	mov    %ebx,0xc(%rsp)
  81d175:	mov    %ebp,0x10(%rsp)
  81d179:	mov    %r15d,0x14(%rsp)
  81d17e:	lea    0x48(%rsp),%rdi
  81d183:	lea    0x20(%rsp),%rdx
  81d188:	lea    0x8(%rsp),%rcx
  81d18d:	mov    0x38(%rsp),%rsi
  81d192:	call   826810 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d197:	mov    0x30(%rsp),%rdx
  81d19c:	mov    $0x1,%eax
  81d1a1:	add    $0x68,%rsp
  81d1a5:	pop    %rbx
  81d1a6:	pop    %r12
  81d1a8:	pop    %r13
  81d1aa:	pop    %r14
  81d1ac:	pop    %r15
  81d1ae:	pop    %rbp
  81d1af:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d1b0 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d1b0:	push   %r15
  81d1b2:	push   %r14
  81d1b4:	push   %r12
  81d1b6:	push   %rbx
  81d1b7:	sub    $0x548,%rsp
  81d1be:	mov    %rdx,%r14
  81d1c1:	mov    %rsi,%r12
  81d1c4:	mov    %rdi,%rbx
  81d1c7:	lea    0x612692(%rip),%rdx        # e2f860 <anon.93049d86f4da36fb5b5cebb14659314f.31.llvm.2397904706780205377>
  81d1ce:	lea    0x30(%rsp),%r15
  81d1d3:	mov    %r15,%rdi
  81d1d6:	mov    %rbx,%rsi
  81d1d9:	call   *0x6640b9(%rip)        # e81298 <_DYNAMIC+0x630>
  81d1df:	xorps  %xmm0,%xmm0
  81d1e2:	movups %xmm0,0x10(%rsp)
  81d1e7:	movups %xmm0,0x20(%rsp)
  81d1ec:	movl   $0x0,0x50(%rsp)
  81d1f4:	movb   $0x0,0x58(%rsp)
  81d1f9:	movups 0x9(%rsp),%xmm0
  81d1fe:	movups %xmm0,0x59(%rsp)
  81d203:	movups 0x19(%rsp),%xmm0
  81d208:	movups %xmm0,0x69(%rsp)
  81d20d:	mov    0x28(%rsp),%rax
  81d212:	mov    %rax,0x78(%rsp)
  81d217:	movl   $0x0,0x80(%rsp)
  81d222:	mov    %r12,0x88(%rsp)
  81d22a:	movq   $0x0,0x90(%rsp)
  81d236:	lea    -0x74856a(%rip),%rax        # d4cd3 <anon.93049d86f4da36fb5b5cebb14659314f.30.llvm.2397904706780205377>
  81d23d:	mov    %rax,0xe0(%rsp)
  81d245:	movq   $0xa,0xe8(%rsp)
  81d251:	lea    0x50(%rsp),%rax
  81d256:	mov    %rax,0xd0(%rsp)
  81d25e:	movq   $0x1,0xd8(%rsp)
  81d26a:	movl   $0xffffffff,0xb8(%rsp)
  81d275:	movl   $0x2,0x98(%rsp)
  81d280:	movq   $0x0,0xf0(%rsp)
  81d28c:	movl   $0x0,0xf8(%rsp)
  81d297:	lea    0x100(%rsp),%rdi
  81d29f:	lea    0x98(%rsp),%rdx
  81d2a7:	mov    %r15,%rsi
  81d2aa:	call   *0x663ff0(%rip)        # e812a0 <_DYNAMIC+0x638>
  81d2b0:	lea    0x10(%rbx),%rsi
  81d2b4:	lea    0x100(%rsp),%rdi
  81d2bc:	call   *0x663fe6(%rip)        # e812a8 <_DYNAMIC+0x640>
  81d2c2:	lea    0x100(%rsp),%rdi
  81d2ca:	mov    $0x4,%ecx
  81d2cf:	xor    %esi,%esi
  81d2d1:	mov    %r14,%rdx
  81d2d4:	xor    %r8d,%r8d
  81d2d7:	call   *0x663fd3(%rip)        # e812b0 <_DYNAMIC+0x648>
  81d2dd:	lea    0x100(%rsp),%rdi
  81d2e5:	xor    %esi,%esi
  81d2e7:	mov    $0x3,%edx
  81d2ec:	xor    %ecx,%ecx
  81d2ee:	mov    $0x1,%r8d
  81d2f4:	call   *0x663fbe(%rip)        # e812b8 <_DYNAMIC+0x650>
  81d2fa:	lea    0x100(%rsp),%rdi
  81d302:	call   81c2c0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d307:	movups 0x30(%rsp),%xmm0
  81d30c:	movups 0x40(%rsp),%xmm1
  81d311:	movaps %xmm1,0x110(%rsp)
  81d319:	movaps %xmm0,0x100(%rsp)
  81d321:	lea    0x98(%rsp),%r14
  81d329:	lea    0x100(%rsp),%rsi
  81d331:	mov    %r14,%rdi
  81d334:	call   *0x663f86(%rip)        # e812c0 <_DYNAMIC+0x658>
  81d33a:	add    $0x8,%rbx
  81d33e:	mov    %rbx,%rdi
  81d341:	mov    %r14,%rsi
  81d344:	call   8262b0 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d349:	add    $0x548,%rsp
  81d350:	pop    %rbx
  81d351:	pop    %r12
  81d353:	pop    %r14
  81d355:	pop    %r15
  81d357:	ret
  81d358:	mov    %rax,%rbx
  81d35b:	jmp    81d36d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d35d:	mov    %rax,%rbx
  81d360:	lea    0x100(%rsp),%rdi
  81d368:	call   81c2c0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d36d:	lea    0x30(%rsp),%rdi
  81d372:	call   81c430 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d377:	mov    %rbx,%rdi
  81d37a:	call   e2d990 <_Unwind_Resume@plt>
  81d37f:	call   *0x663b33(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d390 <<gpui_gpu::renderer::RendererState>::correction>:
  81d390:	push   %r15
  81d392:	push   %r14
  81d394:	push   %r13
  81d396:	push   %r12
  81d398:	push   %rbx
  81d399:	sub    $0x90,%rsp
  81d3a0:	mov    %rdi,%rbx
  81d3a3:	movss  (%rdx),%xmm1
  81d3a7:	movss  0x8(%rdx),%xmm2
  81d3ac:	movaps %xmm1,%xmm0
  81d3af:	addss  %xmm2,%xmm0
  81d3b3:	movd   %xmm0,%eax
  81d3b7:	and    $0x7fffffff,%eax
  81d3bc:	xorps  %xmm8,%xmm8
  81d3c0:	xorps  %xmm9,%xmm9
  81d3c4:	cmp    $0x7f7fffff,%eax
  81d3c9:	jg     81d3e8 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d3cb:	cvtss2sd %xmm1,%xmm1
  81d3cf:	cvtss2sd %xmm2,%xmm2
  81d3d3:	cvtss2sd %xmm0,%xmm0
  81d3d7:	addsd  %xmm1,%xmm2
  81d3db:	subsd  %xmm0,%xmm2
  81d3df:	xorps  %xmm9,%xmm9
  81d3e3:	cvtsd2ss %xmm2,%xmm9
  81d3e8:	movupd (%rsi),%xmm0
  81d3ec:	movupd 0x8(%rsi),%xmm1
  81d3f1:	movsd  0x10(%rsi),%xmm2
  81d3f6:	movsd  0x18(%rsi),%xmm3
  81d3fb:	movupd 0x20(%rsi),%xmm4
  81d400:	movss  0x4(%rdx),%xmm6
  81d405:	movss  0xc(%rdx),%xmm7
  81d40a:	movaps %xmm6,%xmm5
  81d40d:	addss  %xmm7,%xmm5
  81d411:	movd   %xmm5,%eax
  81d415:	and    $0x7fffffff,%eax
  81d41a:	cmp    $0x7f7fffff,%eax
  81d41f:	jg     81d43e <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d421:	cvtss2sd %xmm6,%xmm6
  81d425:	cvtss2sd %xmm7,%xmm7
  81d429:	cvtss2sd %xmm5,%xmm5
  81d42d:	addsd  %xmm6,%xmm7
  81d431:	subsd  %xmm5,%xmm7
  81d435:	xorps  %xmm8,%xmm8
  81d439:	cvtsd2ss %xmm7,%xmm8
  81d43e:	cvtpd2ps %xmm4,%xmm5
  81d442:	cvtps2pd %xmm5,%xmm5
  81d445:	subpd  %xmm5,%xmm4
  81d449:	cvtpd2ps %xmm4,%xmm4
  81d44d:	unpcklpd %xmm3,%xmm1
  81d451:	cvtpd2ps %xmm1,%xmm3
  81d455:	unpcklpd %xmm2,%xmm0
  81d459:	cvtpd2ps %xmm0,%xmm2
  81d45d:	cvtps2pd %xmm3,%xmm3
  81d460:	subpd  %xmm3,%xmm1
  81d464:	cvtpd2ps %xmm1,%xmm5
  81d468:	cvtps2pd %xmm2,%xmm1
  81d46b:	subpd  %xmm1,%xmm0
  81d46f:	cvtpd2ps %xmm0,%xmm6
  81d473:	movapd %xmm6,%xmm0
  81d477:	unpcklps %xmm5,%xmm0
  81d47a:	movaps %xmm8,%xmm1
  81d47e:	movlhps %xmm9,%xmm1
  81d482:	movapd %xmm4,%xmm2
  81d486:	shufps $0x24,%xmm1,%xmm2
  81d48a:	xorps  %xmm1,%xmm1
  81d48d:	movapd %xmm0,%xmm3
  81d491:	cmpneqps %xmm1,%xmm3
  81d495:	cmpneqps %xmm1,%xmm2
  81d499:	packssdw %xmm2,%xmm3
  81d49d:	pmovmskb %xmm3,%eax
  81d4a1:	test   %eax,%eax
  81d4a3:	je     81d5c7 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d4a9:	movapd %xmm6,0x60(%rsp)
  81d4af:	movapd %xmm5,0x70(%rsp)
  81d4b5:	lea    0x8(%rsp),%r12
  81d4ba:	movapd %xmm0,(%rsp)
  81d4bf:	movapd %xmm4,0x80(%rsp)
  81d4c8:	movlpd %xmm4,0x10(%rsp)
  81d4ce:	movss  %xmm9,0x18(%rsp)
  81d4d5:	movss  %xmm8,0x1c(%rsp)
  81d4dc:	lea    0x318(%rbx),%r14
  81d4e3:	mov    %rsp,%rsi
  81d4e6:	mov    %r14,%rdi
  81d4e9:	movaps %xmm8,0x30(%rsp)
  81d4ef:	movaps %xmm9,0x20(%rsp)
  81d4f5:	call   826dd0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d4fa:	movapd 0x20(%rsp),%xmm6
  81d500:	movapd 0x30(%rsp),%xmm5
  81d506:	mov    %rax,%r15
  81d509:	shr    $0x39,%r15
  81d50d:	mov    0x2f8(%rbx),%rcx
  81d514:	mov    0x300(%rbx),%rdx
  81d51b:	movd   %r15d,%xmm0
  81d520:	punpcklbw %xmm0,%xmm0
  81d524:	pshuflw $0x0,%xmm0,%xmm0
  81d529:	pshufd $0x44,%xmm0,%xmm0
  81d52e:	xor    %esi,%esi
  81d530:	pcmpeqd %xmm1,%xmm1
  81d534:	mov    %rax,%rdi
  81d537:	and    %rdx,%rdi
  81d53a:	movdqu (%rcx,%rdi,1),%xmm2
  81d53f:	movdqa %xmm2,%xmm3
  81d543:	pcmpeqb %xmm0,%xmm3
  81d547:	pmovmskb %xmm3,%r8d
  81d54c:	test   %r8d,%r8d
  81d54f:	je     81d5a0 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d551:	tzcnt  %r8d,%r9d
  81d556:	add    %rdi,%r9
  81d559:	and    %rdx,%r9
  81d55c:	neg    %r9
  81d55f:	lea    (%r9,%r9,8),%r9
  81d563:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d56a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d571:	pcmpeqb 0x10(%rsp),%xmm4
  81d577:	pcmpeqb (%rsp),%xmm3
  81d57c:	pand   %xmm4,%xmm3
  81d580:	pmovmskb %xmm3,%r10d
  81d585:	cmp    $0xffff,%r10d
  81d58c:	je     81d5be <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d58e:	lea    -0x1(%r8),%r9d
  81d592:	and    %r8w,%r9w
  81d596:	mov    %r9d,%r8d
  81d599:	jne    81d551 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d59b:	nopl   0x0(%rax,%rax,1)
  81d5a0:	pcmpeqb %xmm1,%xmm2
  81d5a4:	pmovmskb %xmm2,%r8d
  81d5a9:	test   %r8d,%r8d
  81d5ac:	jne    81d5ce <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d5ae:	add    %rsi,%rdi
  81d5b1:	add    $0x10,%rdi
  81d5b5:	add    $0x10,%rsi
  81d5b9:	jmp    81d537 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d5be:	lea    (%rcx,%r9,4),%rdx
  81d5c2:	jmp    81d6e9 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d5c7:	xor    %eax,%eax
  81d5c9:	jmp    81d6ec <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d5ce:	cmpq   $0x0,0x308(%rbx)
  81d5d6:	je     81d71f <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d5dc:	mov    (%rsp),%r14
  81d5e0:	mov    0x10(%r12),%rcx
  81d5e5:	mov    %rcx,0x50(%rsp)
  81d5ea:	movups (%r12),%xmm0
  81d5ef:	movaps %xmm0,0x40(%rsp)
  81d5f4:	mov    0x70(%rbx),%r12
  81d5f8:	cmp    0x60(%rbx),%r12
  81d5fc:	jne    81d61a <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d5fe:	lea    0x60(%rbx),%rdi
  81d602:	mov    %rax,%r13
  81d605:	call   *0x663c0d(%rip)        # e81218 <_DYNAMIC+0x5b0>
  81d60b:	movapd 0x20(%rsp),%xmm6
  81d611:	movapd 0x30(%rsp),%xmm5
  81d617:	mov    %r13,%rax
  81d61a:	mov    0x68(%rbx),%rcx
  81d61e:	mov    %r12,%rdx
  81d621:	shl    $0x5,%rdx
  81d625:	movaps 0x60(%rsp),%xmm0
  81d62a:	movlps %xmm0,(%rcx,%rdx,1)
  81d62e:	movaps 0x80(%rsp),%xmm0
  81d636:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d63c:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d642:	movdqa 0x70(%rsp),%xmm1
  81d648:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d64e:	shufps $0x55,%xmm0,%xmm0
  81d652:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d658:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d65e:	lea    0x1(%r12),%rcx
  81d663:	mov    %rcx,0x70(%rbx)
  81d667:	mov    0x2f8(%rbx),%rcx
  81d66e:	mov    0x300(%rbx),%rdx
  81d675:	and    %rdx,%rax
  81d678:	movdqu (%rcx,%rax,1),%xmm0
  81d67d:	pmovmskb %xmm0,%esi
  81d681:	test   %esi,%esi
  81d683:	je     81d6fd <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d685:	tzcnt  %esi,%esi
  81d689:	add    %rax,%rsi
  81d68c:	and    %rdx,%rsi
  81d68f:	movzbl (%rcx,%rsi,1),%eax
  81d693:	test   %al,%al
  81d695:	jns    81d750 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d69b:	lea    -0x10(%rsi),%rdi
  81d69f:	and    %rdx,%rdi
  81d6a2:	mov    %r15b,(%rcx,%rsi,1)
  81d6a6:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d6ab:	neg    %rsi
  81d6ae:	lea    (%rsi,%rsi,8),%rsi
  81d6b2:	lea    (%rcx,%rsi,4),%rdx
  81d6b6:	and    $0x1,%al
  81d6b8:	movzbl %al,%eax
  81d6bb:	sub    %rax,0x308(%rbx)
  81d6c2:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d6c7:	movdqa 0x40(%rsp),%xmm0
  81d6cd:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d6d3:	mov    0x50(%rsp),%rax
  81d6d8:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d6dd:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d6e2:	incq   0x310(%rbx)
  81d6e9:	mov    -0x4(%rdx),%eax
  81d6ec:	add    $0x90,%rsp
  81d6f3:	pop    %rbx
  81d6f4:	pop    %r12
  81d6f6:	pop    %r13
  81d6f8:	pop    %r14
  81d6fa:	pop    %r15
  81d6fc:	ret
  81d6fd:	mov    $0x10,%edi
  81d702:	add    %rdi,%rax
  81d705:	and    %rdx,%rax
  81d708:	movdqu (%rcx,%rax,1),%xmm0
  81d70d:	pmovmskb %xmm0,%esi
  81d711:	add    $0x10,%rdi
  81d715:	test   %esi,%esi
  81d717:	jne    81d685 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d71d:	jmp    81d702 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d71f:	lea    0x2f8(%rbx),%rdi
  81d726:	mov    $0x1,%esi
  81d72b:	mov    %r14,%rdx
  81d72e:	mov    $0x1,%ecx
  81d733:	mov    %rax,%r14
  81d736:	call   *0x663b8c(%rip)        # e812c8 <_DYNAMIC+0x660>
  81d73c:	movapd 0x20(%rsp),%xmm6
  81d742:	movapd 0x30(%rsp),%xmm5
  81d748:	mov    %r14,%rax
  81d74b:	jmp    81d5dc <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d750:	movdqa (%rcx),%xmm0
  81d754:	pmovmskb %xmm0,%eax
  81d758:	tzcnt  %eax,%esi
  81d75c:	movzbl (%rcx,%rsi,1),%eax
  81d760:	jmp    81d69b <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d770 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d770:	push   %rbp
  81d771:	push   %r15
  81d773:	push   %r14
  81d775:	push   %r13
  81d777:	push   %r12
  81d779:	push   %rbx
  81d77a:	sub    $0x228,%rsp
  81d781:	mov    %rsi,%r14
  81d784:	test   %r8d,%r8d
  81d787:	je     81d81b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d78d:	mov    %rdi,0x10(%rsp)
  81d792:	mov    0x110(%rcx),%rbp
  81d799:	test   %rbp,%rbp
  81d79c:	je     81d87f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d7a2:	mov    0x108(%rcx),%r13
  81d7a9:	shl    $0x3,%rbp
  81d7ad:	mov    %r14,0x8(%rsp)
  81d7b2:	lea    0x78(%r14),%rdi
  81d7b6:	mov    %rdx,0x18(%rsp)
  81d7bb:	lea    0x8(%rdx),%rax
  81d7bf:	mov    %rax,0x20(%rsp)
  81d7c4:	xor    %ebx,%ebx
  81d7c6:	lea    0x28(%rsp),%r15
  81d7cb:	xor    %r12d,%r12d
  81d7ce:	xchg   %ax,%ax
  81d7d0:	mov    0x0(%r13,%r12,1),%rax
  81d7d5:	movups 0x28(%rax),%xmm0
  81d7d9:	lea    0x38(%rsp),%rcx
  81d7de:	movups %xmm0,(%rcx)
  81d7e1:	movups 0x18(%rax),%xmm0
  81d7e5:	movups %xmm0,0x28(%rsp)
  81d7ea:	movups 0x38(%rax),%xmm0
  81d7ee:	movups %xmm0,0x48(%rsp)
  81d7f3:	mov    %rdi,%r14
  81d7f6:	mov    0x20(%rsp),%rsi
  81d7fb:	mov    %r15,%rdx
  81d7fe:	call   81cf50 <<gpui_gpu::renderer::Atlas>::insert>
  81d803:	test   $0x1,%al
  81d805:	je     81d886 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d807:	add    %rdx,%rbx
  81d80a:	add    $0x8,%r12
  81d80e:	cmp    %r12,%rbp
  81d811:	mov    %r14,%rdi
  81d814:	jne    81d7d0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d816:	jmp    81d98e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d81b:	cmpl   $0x1,0x150(%r14)
  81d823:	jne    81d835 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d825:	mov    0x138(%r14),%rax
  81d82c:	add    0x130(%r14),%rax
  81d833:	je     81d86c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d835:	mov    %rdi,%rbx
  81d838:	add    $0x78,%r14
  81d83c:	lea    0x58(%rsp),%rdi
  81d841:	mov    %rdx,%rsi
  81d844:	mov    $0x1,%edx
  81d849:	call   81cc80 <<gpui_gpu::renderer::Atlas>::new>
  81d84e:	mov    %r14,%rdi
  81d851:	call   81ba70 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d856:	lea    0x58(%rsp),%rsi
  81d85b:	mov    $0xe8,%edx
  81d860:	mov    %r14,%rdi
  81d863:	call   *0x66369f(%rip)        # e80f08 <memcpy@GLIBC_2.14>
  81d869:	mov    %rbx,%rdi
  81d86c:	movq   $0x0,0x8(%rdi)
  81d874:	movl   $0xffffffff,(%rdi)
  81d87a:	jmp    81d99d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d87f:	xor    %ebx,%ebx
  81d881:	jmp    81d98e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d886:	mov    0x8(%rsp),%rax
  81d88b:	mov    0x150(%rax),%eax
  81d891:	cmp    $0x81,%eax
  81d896:	mov    $0x80,%edx
  81d89b:	cmovae %eax,%edx
  81d89e:	add    %edx,%edx
  81d8a0:	cmp    $0x800,%edx
  81d8a6:	mov    $0x800,%eax
  81d8ab:	cmovae %eax,%edx
  81d8ae:	lea    0x140(%rsp),%r12
  81d8b6:	mov    %r12,%rdi
  81d8b9:	mov    0x18(%rsp),%rsi
  81d8be:	mov    %edx,0x8(%rsp)
  81d8c2:	call   81cc80 <<gpui_gpu::renderer::Atlas>::new>
  81d8c7:	xor    %r15d,%r15d
  81d8ca:	nopw   0x0(%rax,%rax,1)
  81d8d0:	mov    0x0(%r13,%r15,1),%rax
  81d8d5:	movups 0x28(%rax),%xmm0
  81d8d9:	lea    0x68(%rsp),%rcx
  81d8de:	movups %xmm0,(%rcx)
  81d8e1:	movups 0x18(%rax),%xmm0
  81d8e5:	movups %xmm0,0x58(%rsp)
  81d8ea:	movups 0x38(%rax),%xmm0
  81d8ee:	movups %xmm0,0x78(%rsp)
  81d8f3:	mov    %r12,%rdi
  81d8f6:	mov    0x20(%rsp),%rsi
  81d8fb:	lea    0x58(%rsp),%rdx
  81d900:	call   81cf50 <<gpui_gpu::renderer::Atlas>::insert>
  81d905:	cmp    $0x1,%rax
  81d909:	jne    81d919 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d90b:	add    %rdx,%rbx
  81d90e:	add    $0x8,%r15
  81d912:	cmp    %r15,%rbp
  81d915:	jne    81d8d0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d917:	jmp    81d95b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d919:	mov    0x8(%rsp),%r15d
  81d91e:	cmp    $0x800,%r15d
  81d925:	je     81d9af <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d92b:	mov    %r12,%rdi
  81d92e:	call   81ba70 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d933:	add    %r15d,%r15d
  81d936:	cmp    $0x800,%r15d
  81d93d:	mov    $0x800,%eax
  81d942:	cmovae %eax,%r15d
  81d946:	mov    %r12,%rdi
  81d949:	mov    0x18(%rsp),%rsi
  81d94e:	mov    %r15d,0x8(%rsp)
  81d953:	mov    %r15d,%edx
  81d956:	jmp    81d8c2 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81d95b:	lea    0x58(%rsp),%rdi
  81d960:	lea    0x140(%rsp),%rsi
  81d968:	mov    $0xe8,%edx
  81d96d:	call   *0x663595(%rip)        # e80f08 <memcpy@GLIBC_2.14>
  81d973:	mov    %r14,%rdi
  81d976:	call   81ba70 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d97b:	lea    0x58(%rsp),%rsi
  81d980:	mov    $0xe8,%edx
  81d985:	mov    %r14,%rdi
  81d988:	call   *0x66357a(%rip)        # e80f08 <memcpy@GLIBC_2.14>
  81d98e:	mov    0x10(%rsp),%rax
  81d993:	mov    %rbx,0x8(%rax)
  81d997:	movl   $0xffffffff,(%rax)
  81d99d:	add    $0x228,%rsp
  81d9a4:	pop    %rbx
  81d9a5:	pop    %r12
  81d9a7:	pop    %r13
  81d9a9:	pop    %r14
  81d9ab:	pop    %r15
  81d9ad:	pop    %rbp
  81d9ae:	ret
  81d9af:	mov    0x10(%rsp),%rax
  81d9b4:	movl   $0x7,(%rax)
  81d9ba:	lea    0x140(%rsp),%rdi
  81d9c2:	call   81ba70 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9c7:	jmp    81d99d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d9c9:	jmp    81d9cb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81d9cb:	mov    %rax,%rbx
  81d9ce:	lea    0x58(%rsp),%rsi
  81d9d3:	mov    $0xe8,%edx
  81d9d8:	mov    %r14,%rdi
  81d9db:	call   *0x663527(%rip)        # e80f08 <memcpy@GLIBC_2.14>
  81d9e1:	mov    %rbx,%rdi
  81d9e4:	call   e2d990 <_Unwind_Resume@plt>
  81d9e9:	mov    %rax,%rbx
  81d9ec:	lea    0x140(%rsp),%rdi
  81d9f4:	call   81ba70 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9f9:	mov    %rbx,%rdi
  81d9fc:	call   e2d990 <_Unwind_Resume@plt>
  81da01:	call   *0x6634b1(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1527 frame=952

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081da10 <<gpui_gpu::renderer::RendererState>::new>:
  81da10:	push   %r15
  81da12:	push   %r14
  81da14:	push   %r13
  81da16:	push   %r12
  81da18:	push   %rbx
  81da19:	sub    $0x390,%rsp
  81da20:	mov    %rsi,%r14
  81da23:	mov    %rdi,%rbx
  81da26:	lea    -0x748d50(%rip),%rax        # d4cdd <anon.93049d86f4da36fb5b5cebb14659314f.30.llvm.2397904706780205377+0xa>
  81da2d:	mov    %rax,0xd8(%rsp)
  81da35:	movq   $0x7,0xe0(%rsp)
  81da41:	movq   $0x30,0xe8(%rsp)
  81da4d:	movl   $0x48,0xf0(%rsp)
  81da58:	movb   $0x0,0xf4(%rsp)
  81da60:	mov    0x663819(%rip),%r15        # e81280 <_DYNAMIC+0x618>
  81da67:	lea    0x10(%rsp),%rdi
  81da6c:	lea    0xd8(%rsp),%rdx
  81da74:	call   *%r15
  81da77:	movq   $0x30,0x30(%rsp)
  81da80:	lea    -0x748da3(%rip),%rax        # d4ce4 <anon.93049d86f4da36fb5b5cebb14659314f.30.llvm.2397904706780205377+0x11>
  81da87:	mov    %rax,0xd8(%rsp)
  81da8f:	movq   $0x5,0xe0(%rsp)
  81da9b:	movq   $0x10,0xe8(%rsp)
  81daa7:	movl   $0x88,0xf0(%rsp)
  81dab2:	movb   $0x0,0xf4(%rsp)
  81daba:	lea    0x38(%rsp),%rdi
  81dabf:	lea    0xd8(%rsp),%rdx
  81dac7:	mov    %r14,%rsi
  81daca:	call   *%r15
  81dacd:	movq   $0x10,0x58(%rsp)
  81dad6:	lea    -0x748df4(%rip),%rax        # d4ce9 <anon.93049d86f4da36fb5b5cebb14659314f.30.llvm.2397904706780205377+0x16>
  81dadd:	mov    %rax,0xd8(%rsp)
  81dae5:	movq   $0x5,0xe0(%rsp)
  81daf1:	movq   $0x8,0xe8(%rsp)
  81dafd:	movl   $0x88,0xf0(%rsp)
  81db08:	movb   $0x0,0xf4(%rsp)
  81db10:	lea    0x60(%rsp),%rdi
  81db15:	lea    0xd8(%rsp),%rdx
  81db1d:	mov    %r14,%rsi
  81db20:	call   *0x66375a(%rip)        # e81280 <_DYNAMIC+0x618>
  81db26:	movq   $0x8,0x80(%rsp)
  81db32:	lea    -0x748e4b(%rip),%rax        # d4cee <anon.93049d86f4da36fb5b5cebb14659314f.30.llvm.2397904706780205377+0x1b>
  81db39:	mov    %rax,0xd8(%rsp)
  81db41:	movq   $0x7,0xe0(%rsp)
  81db4d:	movq   $0x4,0xe8(%rsp)
  81db59:	movl   $0x88,0xf0(%rsp)
  81db64:	movb   $0x0,0xf4(%rsp)
  81db6c:	lea    0x88(%rsp),%rdi
  81db74:	lea    0xd8(%rsp),%rdx
  81db7c:	mov    %r14,%rsi
  81db7f:	call   *0x6636fb(%rip)        # e81280 <_DYNAMIC+0x618>
  81db85:	movq   $0x4,0xa8(%rsp)
  81db91:	lea    -0x748ea3(%rip),%rax        # d4cf5 <anon.93049d86f4da36fb5b5cebb14659314f.30.llvm.2397904706780205377+0x22>
  81db98:	mov    %rax,0xd8(%rsp)
  81dba0:	movq   $0x11,0xe0(%rsp)
  81dbac:	movq   $0x20,0xe8(%rsp)
  81dbb8:	movl   $0x88,0xf0(%rsp)
  81dbc3:	movb   $0x0,0xf4(%rsp)
  81dbcb:	lea    0xb0(%rsp),%rdi
  81dbd3:	lea    0xd8(%rsp),%rdx
  81dbdb:	mov    %r14,%rsi
  81dbde:	call   *0x66369c(%rip)        # e81280 <_DYNAMIC+0x618>
  81dbe4:	movq   $0x20,0xd0(%rsp)
  81dbf0:	lea    0x2a8(%rsp),%rdi
  81dbf8:	mov    %r14,%rsi
  81dbfb:	mov    $0x1,%edx
  81dc00:	call   81cc80 <<gpui_gpu::renderer::Atlas>::new>
  81dc05:	mov    0x18(%r14),%r13
  81dc09:	lock incq 0x0(%r13)
  81dc0e:	jle    81df43 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81dc14:	mov    %r13,0x8(%rsp)
  81dc19:	mov    0x30(%rsp),%rax
  81dc1e:	mov    %rax,0x1e0(%rsp)
  81dc26:	movups 0x10(%rsp),%xmm0
  81dc2b:	movups 0x20(%rsp),%xmm1
  81dc30:	movaps %xmm1,0x1d0(%rsp)
  81dc38:	movaps %xmm0,0x1c0(%rsp)
  81dc40:	mov    0x58(%rsp),%rax
  81dc45:	mov    %rax,0x210(%rsp)
  81dc4d:	movups 0x38(%rsp),%xmm0
  81dc52:	movups 0x48(%rsp),%xmm1
  81dc57:	movaps %xmm1,0x200(%rsp)
  81dc5f:	movaps %xmm0,0x1f0(%rsp)
  81dc67:	mov    0x80(%rsp),%rax
  81dc6f:	mov    %rax,0x240(%rsp)
  81dc77:	movups 0x60(%rsp),%xmm0
  81dc7c:	movups 0x70(%rsp),%xmm1
  81dc81:	movaps %xmm1,0x230(%rsp)
  81dc89:	movaps %xmm0,0x220(%rsp)
  81dc91:	mov    0xa8(%rsp),%rax
  81dc99:	mov    %rax,0x270(%rsp)
  81dca1:	movups 0x88(%rsp),%xmm0
  81dca9:	movups 0x98(%rsp),%xmm1
  81dcb1:	movaps %xmm1,0x260(%rsp)
  81dcb9:	movaps %xmm0,0x250(%rsp)
  81dcc1:	mov    0xd0(%rsp),%rax
  81dcc9:	mov    %rax,0x2a0(%rsp)
  81dcd1:	movups 0xb0(%rsp),%xmm0
  81dcd9:	movups 0xc0(%rsp),%xmm1
  81dce1:	movaps %xmm1,0x290(%rsp)
  81dce9:	movaps %xmm0,0x280(%rsp)
  81dcf1:	lea    0xd8(%rsp),%rdi
  81dcf9:	lea    0x2a8(%rsp),%rsi
  81dd01:	mov    $0xe8,%edx
  81dd06:	call   *0x6631fc(%rip)        # e80f08 <memcpy@GLIBC_2.14>
  81dd0c:	mov    %fs:0x0,%rax
  81dd15:	lea    -0x28(%rax),%rax
  81dd1c:	mov    %rax,%r12
  81dd1f:	cmpb   $0x1,0x10(%rax)
  81dd23:	jne    81df23 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81dd29:	mov    (%r12),%r14
  81dd2d:	mov    0x8(%r12),%r15
  81dd32:	lea    0x1(%r14),%rax
  81dd36:	mov    %rax,(%r12)
  81dd3a:	mov    %r13,0x228(%rbx)
  81dd41:	mov    0x30(%rsp),%rax
  81dd46:	mov    %rax,0x250(%rbx)
  81dd4d:	movups 0x10(%rsp),%xmm0
  81dd52:	movups 0x20(%rsp),%xmm1
  81dd57:	movups %xmm1,0x240(%rbx)
  81dd5e:	movups %xmm0,0x230(%rbx)
  81dd65:	mov    0x58(%rsp),%rax
  81dd6a:	mov    %rax,0x278(%rbx)
  81dd71:	movups 0x38(%rsp),%xmm0
  81dd76:	movups 0x48(%rsp),%xmm1
  81dd7b:	movups %xmm1,0x268(%rbx)
  81dd82:	movups %xmm0,0x258(%rbx)
  81dd89:	mov    0x80(%rsp),%rax
  81dd91:	mov    %rax,0x2a0(%rbx)
  81dd98:	movups 0x60(%rsp),%xmm0
  81dd9d:	movups 0x70(%rsp),%xmm1
  81dda2:	movups %xmm1,0x290(%rbx)
  81dda9:	movups %xmm0,0x280(%rbx)
  81ddb0:	movups 0x88(%rsp),%xmm0
  81ddb8:	movups 0x98(%rsp),%xmm1
  81ddc0:	movups %xmm0,0x2a8(%rbx)
  81ddc7:	movups %xmm1,0x2b8(%rbx)
  81ddce:	mov    0xa8(%rsp),%rax
  81ddd6:	mov    %rax,0x2c8(%rbx)
  81dddd:	movups 0xb0(%rsp),%xmm0
  81dde5:	movups 0xc0(%rsp),%xmm1
  81dded:	movups %xmm0,0x2d0(%rbx)
  81ddf4:	movups %xmm1,0x2e0(%rbx)
  81ddfb:	mov    0xd0(%rsp),%rax
  81de03:	mov    %rax,0x2f0(%rbx)
  81de0a:	lea    0x78(%rbx),%rdi
  81de0e:	lea    0x2a8(%rsp),%rsi
  81de16:	mov    $0xe8,%edx
  81de1b:	call   *0x6630e7(%rip)        # e80f08 <memcpy@GLIBC_2.14>
  81de21:	movq   $0x0,0x328(%rbx)
  81de2c:	movq   $0x0,(%rbx)
  81de33:	movq   $0x4,0x8(%rbx)
  81de3b:	xorps  %xmm0,%xmm0
  81de3e:	movups %xmm0,0x10(%rbx)
  81de42:	movq   $0x4,0x20(%rbx)
  81de4a:	movups %xmm0,0x28(%rbx)
  81de4e:	movq   $0x4,0x38(%rbx)
  81de56:	movups %xmm0,0x40(%rbx)
  81de5a:	movq   $0x4,0x50(%rbx)
  81de62:	movups %xmm0,0x58(%rbx)
  81de66:	movq   $0x4,0x68(%rbx)
  81de6e:	movq   $0x0,0x70(%rbx)
  81de76:	movups 0x611933(%rip),%xmm1        # e2f7b0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x128>
  81de7d:	movups %xmm1,0x2f8(%rbx)
  81de84:	movups 0x611935(%rip),%xmm1        # e2f7c0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x138>
  81de8b:	movups %xmm1,0x308(%rbx)
  81de92:	mov    %r14,0x318(%rbx)
  81de99:	mov    %r15,0x320(%rbx)
  81dea0:	movw   $0x101,0x340(%rbx)
  81dea9:	movq   $0x0,0x330(%rbx)
  81deb4:	movups %xmm0,0x210(%rbx)
  81debb:	movups %xmm0,0x200(%rbx)
  81dec2:	movups %xmm0,0x1f0(%rbx)
  81dec9:	movups %xmm0,0x1e0(%rbx)
  81ded0:	movups %xmm0,0x1d0(%rbx)
  81ded7:	movups %xmm0,0x1c0(%rbx)
  81dede:	movups %xmm0,0x1b0(%rbx)
  81dee5:	movups %xmm0,0x1a0(%rbx)
  81deec:	movups %xmm0,0x190(%rbx)
  81def3:	movups %xmm0,0x180(%rbx)
  81defa:	movups %xmm0,0x170(%rbx)
  81df01:	movups %xmm0,0x160(%rbx)
  81df08:	movb   $0x0,0x220(%rbx)
  81df0f:	mov    %rbx,%rax
  81df12:	add    $0x390,%rsp
  81df19:	pop    %rbx
  81df1a:	pop    %r12
  81df1c:	pop    %r13
  81df1e:	pop    %r14
  81df20:	pop    %r15
  81df22:	ret
  81df23:	call   *0x66335f(%rip)        # e81288 <_DYNAMIC+0x620>
  81df29:	mov    %rax,%r14
  81df2c:	mov    %rdx,%r15
  81df2f:	mov    %rax,(%r12)
  81df33:	mov    %rdx,0x8(%r12)
  81df38:	movb   $0x1,0x10(%r12)
  81df3e:	jmp    81dd32 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81df43:	ud2
  81df45:	mov    %rax,%rbx
  81df48:	lea    0xd8(%rsp),%rdi
  81df50:	call   81ba70 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81df55:	lea    0x280(%rsp),%rdi
  81df5d:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df62:	lea    0x250(%rsp),%rdi
  81df6a:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df6f:	lea    0x220(%rsp),%rdi
  81df77:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df7c:	lea    0x1f0(%rsp),%rdi
  81df84:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df89:	lea    0x1c0(%rsp),%rdi
  81df91:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df96:	lock decq 0x0(%r13)
  81df9b:	jne    81dff9 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81df9d:	lea    0x8(%rsp),%rdi
  81dfa2:	call   *0x663128(%rip)        # e810d0 <_DYNAMIC+0x468>
  81dfa8:	jmp    81dff9 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81dfaa:	mov    %rax,%rbx
  81dfad:	lea    0xb0(%rsp),%rdi
  81dfb5:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfba:	jmp    81dfbf <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81dfbc:	mov    %rax,%rbx
  81dfbf:	lea    0x88(%rsp),%rdi
  81dfc7:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfcc:	jmp    81dfd1 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81dfce:	mov    %rax,%rbx
  81dfd1:	lea    0x60(%rsp),%rdi
  81dfd6:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfdb:	jmp    81dfe0 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81dfdd:	mov    %rax,%rbx
  81dfe0:	lea    0x38(%rsp),%rdi
  81dfe5:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfea:	jmp    81dfef <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81dfec:	mov    %rax,%rbx
  81dfef:	lea    0x10(%rsp),%rdi
  81dff4:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dff9:	mov    %rbx,%rdi
  81dffc:	call   e2d990 <_Unwind_Resume@plt>
  81e001:	call   *0x662eb1(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9931 frame=1512

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e010 <<gpui_gpu::renderer::RendererState>::render>:
  81e010:	push   %rbp
  81e011:	push   %r15
  81e013:	push   %r14
  81e015:	push   %r13
  81e017:	push   %r12
  81e019:	push   %rbx
  81e01a:	sub    $0x5b8,%rsp
  81e021:	mov    0x228(%rsi),%rax
  81e028:	mov    0x18(%rdx),%r9
  81e02c:	cmp    %r9,%rax
  81e02f:	je     81e04d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e031:	mov    0x10(%rax),%r10
  81e035:	cmp    0x10(%r9),%r10
  81e039:	jne    81e11b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e03f:	mov    0x18(%rax),%rax
  81e043:	cmp    0x18(%r9),%rax
  81e047:	jne    81e11b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e04d:	lea    0x330(%rsi),%rbx
  81e054:	mov    0x330(%rsi),%rax
  81e05b:	test   %rax,%rax
  81e05e:	je     81e08d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e060:	lock decq (%rax)
  81e064:	jne    81e08d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e066:	mov    %rdi,%r14
  81e069:	mov    %rbx,%rdi
  81e06c:	mov    %rsi,%r12
  81e06f:	mov    %r8,%r13
  81e072:	mov    %rdx,%r15
  81e075:	mov    %rcx,%rbp
  81e078:	call   *0x663102(%rip)        # e81180 <_DYNAMIC+0x518>
  81e07e:	mov    %rbp,%rcx
  81e081:	mov    %r15,%rdx
  81e084:	mov    %r13,%r8
  81e087:	mov    %r12,%rsi
  81e08a:	mov    %r14,%rdi
  81e08d:	movq   $0x0,0x330(%rsi)
  81e098:	mov    (%rcx),%r13d
  81e09b:	mov    0x8(%rcx),%r9d
  81e09f:	movzbl 0xd(%rcx),%eax
  81e0a3:	test   %r9d,%r9d
  81e0a6:	sets   %r10b
  81e0aa:	and    $0x7fffffff,%r9d
  81e0b1:	lea    -0x800000(%r9),%r11d
  81e0b8:	cmp    $0x7f000000,%r11d
  81e0bf:	setb   %r11b
  81e0c3:	and    %r10b,%r11b
  81e0c6:	lea    -0x1(%r9),%ebp
  81e0ca:	cmp    $0x7fffff,%ebp
  81e0d0:	setb   %bpl
  81e0d4:	and    %r10b,%bpl
  81e0d7:	test   %r9d,%r9d
  81e0da:	sete   %r10b
  81e0de:	cmp    $0x7f800000,%r9d
  81e0e5:	sete   %r14b
  81e0e9:	or     %r10b,%r14b
  81e0ec:	cmp    $0x7f800001,%r9d
  81e0f3:	setge  %r9b
  81e0f7:	or     %r14b,%r9b
  81e0fa:	or     %bpl,%r9b
  81e0fd:	test   %r13d,%r13d
  81e100:	setne  %r10b
  81e104:	and    %al,%r10b
  81e107:	or     %r11b,%r10b
  81e10a:	or     %r9b,%r10b
  81e10d:	test   $0x1,%r10b
  81e111:	je     81e136 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e113:	movl   $0x3,(%rdi)
  81e119:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e11b:	movl   $0x4,(%rdi)
  81e121:	mov    %rdi,%rax
  81e124:	add    $0x5b8,%rsp
  81e12b:	pop    %rbx
  81e12c:	pop    %r12
  81e12e:	pop    %r13
  81e130:	pop    %r14
  81e132:	pop    %r15
  81e134:	pop    %rbp
  81e135:	ret
  81e136:	movd   0x4(%rcx),%xmm2
  81e13b:	movzbl 0xc(%rcx),%ebp
  81e13f:	test   $0x1,%r13b
  81e143:	je     81e1bb <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e145:	movd   %xmm2,%r9d
  81e14a:	test   %r9d,%r9d
  81e14d:	sets   %r10b
  81e151:	and    $0x7fffffff,%r9d
  81e158:	lea    -0x800000(%r9),%r11d
  81e15f:	cmp    $0x7f000000,%r11d
  81e166:	setb   %r11b
  81e16a:	and    %r10b,%r11b
  81e16d:	lea    -0x1(%r9),%r14d
  81e171:	cmp    $0x7fffff,%r14d
  81e178:	setb   %r14b
  81e17c:	and    %r10b,%r14b
  81e17f:	test   %r9d,%r9d
  81e182:	sete   %r10b
  81e186:	cmp    $0x7f800000,%r9d
  81e18d:	sete   %r15b
  81e191:	or     %r10b,%r15b
  81e194:	cmp    $0x7f800001,%r9d
  81e19b:	setge  %r9b
  81e19f:	or     %r15b,%r9b
  81e1a2:	or     %r14b,%r9b
  81e1a5:	or     %r11b,%r9b
  81e1a8:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1ae:	ucomiss -0x76f2a9(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e1b5:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1bb:	mov    0x28(%rcx),%r14d
  81e1bf:	cmp    %r14d,0x20(%r8)
  81e1c3:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1c9:	mov    0x2c(%rcx),%r15d
  81e1cd:	cmp    %r15d,0x24(%r8)
  81e1d1:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1d7:	mov    0x38(%r8),%r12d
  81e1db:	cmp    0x20(%rdx),%r12d
  81e1df:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e1e5:	cmp    $0x4c,%r12d
  81e1e9:	jne    81e20e <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e1eb:	movq   0x3c(%r8),%xmm0
  81e1f1:	movq   0x24(%rdx),%xmm1
  81e1f6:	pcmpeqd %xmm0,%xmm1
  81e1fa:	pshufd $0x50,%xmm1,%xmm0
  81e1ff:	movmskpd %xmm0,%r9d
  81e204:	cmp    $0x3,%r9d
  81e208:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e20e:	cmp    $0x4000,%r15d
  81e215:	ja     81e24b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e217:	cmp    $0x4000,%r14d
  81e21e:	ja     81e24b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e220:	mov    %r15,%r9
  81e223:	imul   %r14,%r9
  81e227:	add    $0xfffffffffeffffff,%r9
  81e22e:	cmp    $0xffffffffff000000,%r9
  81e235:	jb     81e24b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e237:	mov    0x10(%rcx),%r11
  81e23b:	mov    0x80(%r11),%r10
  81e242:	cmp    $0x10000,%r10
  81e249:	jbe    81e256 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e24b:	movl   $0x6,(%rdi)
  81e251:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e256:	movd   0x18(%rcx),%xmm0
  81e25b:	movd   %xmm0,%r9d
  81e260:	and    $0x7fffffff,%r9d
  81e267:	cmp    $0x7f7fffff,%r9d
  81e26e:	jg     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e274:	pand   -0x770a8c(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e27c:	ucomiss -0x76f11f(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e283:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e289:	movd   0x1c(%rcx),%xmm0
  81e28e:	movd   %xmm0,%r9d
  81e293:	and    $0x7fffffff,%r9d
  81e29a:	cmp    $0x7f7fffff,%r9d
  81e2a1:	jg     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2a7:	pand   -0x770abf(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e2af:	ucomiss -0x76f152(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e2b6:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2bc:	movd   0x20(%rcx),%xmm0
  81e2c1:	movd   %xmm0,%r9d
  81e2c6:	and    $0x7fffffff,%r9d
  81e2cd:	cmp    $0x7f7fffff,%r9d
  81e2d4:	jg     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2da:	pand   -0x770af2(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e2e2:	ucomiss -0x76f185(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e2e9:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ef:	movd   0x24(%rcx),%xmm0
  81e2f4:	movd   %xmm0,%r9d
  81e2f9:	and    $0x7fffffff,%r9d
  81e300:	cmp    $0x7f7fffff,%r9d
  81e307:	jg     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e30d:	movdqa -0x770b25(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e315:	pand   %xmm0,%xmm1
  81e319:	ucomiss -0x76f1bc(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e320:	ja     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e326:	xorps  %xmm1,%xmm1
  81e329:	ucomiss %xmm1,%xmm0
  81e32c:	jb     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e332:	movss  -0x76f55a(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e33a:	ucomiss %xmm0,%xmm1
  81e33d:	jb     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e343:	movzwl 0x30(%rcx),%r9d
  81e348:	mov    %r9w,0x10(%rsp)
  81e34e:	movzwl 0x32(%rcx),%r9d
  81e353:	mov    %r9w,0x18(%rsp)
  81e359:	cmp    $0x28,%r12d
  81e35d:	jne    81e369 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e35f:	test   $0x1,%al
  81e361:	je     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e367:	jmp    81e384 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e369:	test   $0x1,%al
  81e36b:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e371:	ucomiss -0x76f598(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e378:	jne    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e37e:	jp     81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e384:	mov    %r11,0x38(%rsp)
  81e389:	mov    %r10,0xa8(%rsp)
  81e391:	movss  %xmm1,0x120(%rsp)
  81e39a:	movd   %xmm2,0x298(%rsp)
  81e3a3:	mov    %rdx,0x170(%rsp)
  81e3ab:	mov    %r8,0x4a0(%rsp)
  81e3b3:	mov    %rdi,0x58(%rsp)
  81e3b8:	lea    0xf(%r14),%rax
  81e3bc:	shr    $0x4,%rax
  81e3c0:	lea    0xf(%r15),%r8d
  81e3c4:	shr    $0x4,%r8d
  81e3c8:	lea    0x18(%rsi),%rdi
  81e3cc:	movq   $0x0,0x28(%rsi)
  81e3d4:	mov    %rax,0xa0(%rsp)
  81e3dc:	imul   %eax,%r8d
  81e3e0:	movabs $0x4000000000000000,%rdx
  81e3ea:	mov    %rdi,0x4b0(%rsp)
  81e3f2:	mov    %rsi,0x8(%rsp)
  81e3f7:	mov    %r8,0x30(%rsp)
  81e3fc:	mov    %r8,%rsi
  81e3ff:	mov    %rcx,0x178(%rsp)
  81e407:	call   8238c0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e40c:	mov    0x8(%rsp),%rax
  81e411:	movq   $0x0,0x10(%rax)
  81e419:	mov    0x178(%rsp),%rdi
  81e421:	call   *0x662de9(%rip)        # e81210 <_DYNAMIC+0x5a8>
  81e427:	mov    %rdx,%rcx
  81e42a:	sub    %rax,%rcx
  81e42d:	cmp    $0x300000,%rcx
  81e434:	jbe    81e446 <<gpui_gpu::renderer::RendererState>::render+0x436>
  81e436:	mov    0x58(%rsp),%rdi
  81e43b:	movl   $0x6,(%rdi)
  81e441:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e446:	mov    %rcx,%rdi
  81e449:	shr    $0x3,%rcx
  81e44d:	movabs $0xaaaaaaaaaaaaaaab,%rsi
  81e457:	imul   %rcx,%rsi
  81e45b:	mov    %rsi,0x20(%rsp)
  81e460:	mov    %rax,0x498(%rsp)
  81e468:	mov    %rdx,0x490(%rsp)
  81e470:	cmp    %rax,%rdx
  81e473:	je     81e4a1 <<gpui_gpu::renderer::RendererState>::render+0x491>
  81e475:	mov    $0xaaaaaaab,%eax
  81e47a:	imul   %rax,%rdi
  81e47e:	shr    $0x2a,%rdi
  81e482:	mov    0x20(%rsp),%rcx
  81e487:	mov    %ecx,%eax
  81e489:	and    $0x3f,%eax
  81e48c:	add    %rcx,%rdi
  81e48f:	cmp    $0x1,%rax
  81e493:	sbb    $0xffffffffffffffff,%rdi
  81e497:	inc    %rdi
  81e49a:	mov    %rdi,0x40(%rsp)
  81e49f:	jmp    81e4aa <<gpui_gpu::renderer::RendererState>::render+0x49a>
  81e4a1:	movq   $0x0,0x40(%rsp)
  81e4aa:	mov    0x38(%rsp),%rax
  81e4af:	mov    0x98(%rax),%rcx
  81e4b6:	add    0xb0(%rax),%rcx
  81e4bd:	mov    %rax,0x180(%rsp)
  81e4c5:	movzwl 0x10(%rsp),%eax
  81e4ca:	mov    %ax,0x1a0(%rsp)
  81e4d2:	movzwl 0x18(%rsp),%eax
  81e4d7:	mov    %ax,0x1a2(%rsp)
  81e4df:	movq   $0x0,0x188(%rsp)
  81e4eb:	mov    0xa8(%rsp),%rax
  81e4f3:	mov    %rax,0x190(%rsp)
  81e4fb:	mov    %rcx,0x168(%rsp)
  81e503:	mov    %rcx,0x198(%rsp)
  81e50b:	mov    0x8(%rsp),%rax
  81e510:	movzbl 0x341(%rax),%edx
  81e517:	lea    0x4b8(%rsp),%rdi
  81e51f:	lea    0x180(%rsp),%rsi
  81e527:	call   81c760 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e52c:	mov    0x4b8(%rsp),%eax
  81e533:	cmp    $0xffffffff,%eax
  81e536:	je     81e566 <<gpui_gpu::renderer::RendererState>::render+0x556>
  81e538:	mov    0x4bc(%rsp),%ecx
  81e53f:	mov    0x4c0(%rsp),%rdx
  81e547:	movups 0x4c8(%rsp),%xmm0
  81e54f:	mov    0x58(%rsp),%rdi
  81e554:	movups %xmm0,0x10(%rdi)
  81e558:	mov    %eax,(%rdi)
  81e55a:	mov    %ecx,0x4(%rdi)
  81e55d:	mov    %rdx,0x8(%rdi)
  81e561:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e566:	mov    0x40(%rsp),%rdx
  81e56b:	add    0x4c0(%rsp),%rdx
  81e573:	mov    0x8(%rsp),%rdi
  81e578:	mov    0x10(%rdi),%rsi
  81e57c:	mov    $0x4,%ecx
  81e581:	mov    $0x10,%r8d
  81e587:	call   824ec0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e58c:	cmp    $0xffffffffffffffff,%rax
  81e590:	jne    81e436 <<gpui_gpu::renderer::RendererState>::render+0x426>
  81e596:	movzwl 0x10(%rsp),%eax
  81e59b:	mov    %eax,0x10(%rsp)
  81e59f:	movzwl 0x18(%rsp),%eax
  81e5a4:	mov    %eax,0xdc(%rsp)
  81e5ab:	mov    0x8(%rsp),%rdi
  81e5b0:	mov    0x178(%rsp),%rsi
  81e5b8:	mov    0x20(%rsp),%rdx
  81e5bd:	call   825fb0 <gpui_gpu::renderer::slots::write_prefix>
  81e5c2:	mov    0x8(%rsp),%rax
  81e5c7:	lea    0x48(%rax),%rdi
  81e5cb:	movq   $0x0,0x58(%rax)
  81e5d3:	mov    %rdi,0x4a8(%rsp)
  81e5db:	mov    0x30(%rsp),%rsi
  81e5e0:	xor    %edx,%edx
  81e5e2:	call   8239e0 <<alloc::vec::Vec<u32>>::resize>
  81e5e7:	mov    0x8(%rsp),%rax
  81e5ec:	movq   $0x0,0x70(%rax)
  81e5f4:	cmpq   $0x0,0x60(%rax)
  81e5f9:	jne    81e60a <<gpui_gpu::renderer::RendererState>::render+0x5fa>
  81e5fb:	mov    0x8(%rsp),%rax
  81e600:	lea    0x60(%rax),%rdi
  81e604:	call   *0x662c0e(%rip)        # e81218 <_DYNAMIC+0x5b0>
  81e60a:	mov    0x8(%rsp),%rax
  81e60f:	mov    0x68(%rax),%rcx
  81e613:	xorps  %xmm0,%xmm0
  81e616:	movups %xmm0,0x10(%rcx)
  81e61a:	movups %xmm0,(%rcx)
  81e61d:	movq   $0x1,0x70(%rax)
  81e625:	lea    0x2f8(%rax),%rdi
  81e62c:	call   823310 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e631:	mov    0xdc(%rsp),%ecx
  81e638:	shl    $0x10,%ecx
  81e63b:	add    0x10(%rsp),%ecx
  81e63f:	mov    0x38(%rsp),%rax
  81e644:	mov    %rax,0x2a0(%rsp)
  81e64c:	movq   $0x0,0x2a8(%rsp)
  81e658:	mov    0xa8(%rsp),%rax
  81e660:	mov    %rax,0x2b0(%rsp)
  81e668:	mov    0x168(%rsp),%rax
  81e670:	mov    %rax,0x2b8(%rsp)
  81e678:	mov    %ecx,0xdc(%rsp)
  81e67f:	mov    %ecx,0x2c0(%rsp)
  81e686:	lea    0x2c8(%rsp),%rdi
  81e68e:	lea    0x2a0(%rsp),%rsi
  81e696:	call   *0x662b84(%rip)        # e81220 <_DYNAMIC+0x5b8>
  81e69c:	mov    0x2c8(%rsp),%rax
  81e6a4:	mov    %rax,0x18(%rsp)
  81e6a9:	test   %rax,%rax
  81e6ac:	je     81f3f0 <<gpui_gpu::renderer::RendererState>::render+0x13e0>
  81e6b2:	movq   $0x0,0xf8(%rsp)
  81e6be:	movq   $0x0,0x10(%rsp)
  81e6c7:	movq   $0x0,0x78(%rsp)
  81e6d0:	movq   $0x0,0x270(%rsp)
  81e6dc:	movq   $0x0,0x278(%rsp)
  81e6e8:	mov    0x2d0(%rsp),%rcx
  81e6f0:	mov    0x2d8(%rsp),%rdx
  81e6f8:	mov    %rdx,0xb0(%rsp)
  81e700:	lea    0x2e0(%rsp),%rdi
  81e708:	movups (%rdi),%xmm0
  81e70b:	movups 0x10(%rdi),%xmm1
  81e70f:	movups 0x20(%rdi),%xmm2
  81e713:	movaps %xmm2,0x390(%rsp)
  81e71b:	movaps %xmm1,0x380(%rsp)
  81e723:	movaps %xmm0,0x370(%rsp)
  81e72b:	lea    0x310(%rsp),%r8
  81e733:	movups (%r8),%xmm0
  81e737:	movaps %xmm0,0x470(%rsp)
  81e73f:	movups 0x40(%rdi),%xmm0
  81e743:	movaps %xmm0,0x3b0(%rsp)
  81e74b:	mov    0x8(%rsp),%rax
  81e750:	movzbl 0x341(%rax),%esi
  81e757:	mov    0x18(%rsp),%rax
  81e75c:	mov    %rax,0x180(%rsp)
  81e764:	mov    %rcx,0x30(%rsp)
  81e769:	mov    %rcx,0x188(%rsp)
  81e771:	mov    %rdx,0x190(%rsp)
  81e779:	movups (%rdi),%xmm0
  81e77c:	movups 0x10(%rdi),%xmm1
  81e780:	movups 0x20(%rdi),%xmm2
  81e784:	lea    0x198(%rsp),%rax
  81e78c:	movups %xmm2,0x20(%rax)
  81e790:	movups %xmm1,0x10(%rax)
  81e794:	movups %xmm0,(%rax)
  81e797:	movups (%r8),%xmm0
  81e79b:	movups %xmm0,0x30(%rax)
  81e79f:	movups 0x40(%rdi),%xmm0
  81e7a3:	movups %xmm0,0x40(%rax)
  81e7a7:	lea    0x180(%rsp),%rdi
  81e7af:	call   8218a0 <gpui_gpu::renderer::compact_group>
  81e7b4:	mov    %al,0x40(%rsp)
  81e7b8:	lea    0x2e0(%rsp),%rsi
  81e7c0:	movups (%rsi),%xmm0
  81e7c3:	movups 0x10(%rsi),%xmm1
  81e7c7:	movups 0x20(%rsi),%xmm2
  81e7cb:	movaps %xmm0,0x560(%rsp)
  81e7d3:	movaps %xmm1,0x570(%rsp)
  81e7db:	movaps %xmm2,0x580(%rsp)
  81e7e3:	lea    0x310(%rsp),%rdx
  81e7eb:	movups (%rdx),%xmm0
  81e7ee:	movaps %xmm0,0x590(%rsp)
  81e7f6:	mov    0x8(%rsp),%rdi
  81e7fb:	call   81d390 <<gpui_gpu::renderer::RendererState>::correction>
  81e800:	mov    %eax,0xc8(%rsp)
  81e807:	mov    0xb0(%rsp),%rax
  81e80f:	lea    0x0(,%rax,4),%rax
  81e817:	mov    %rax,0x280(%rsp)
  81e81f:	cmpb   $0x0,0x40(%rsp)
  81e824:	je     81ea07 <<gpui_gpu::renderer::RendererState>::render+0x9f7>
  81e82a:	mov    0x30(%rsp),%rcx
  81e82f:	mov    0xb0(%rsp),%rax
  81e837:	lea    (%rcx,%rax,4),%rax
  81e83b:	mov    %rcx,0x350(%rsp)
  81e843:	mov    %rax,0x358(%rsp)
  81e84b:	mov    0x18(%rsp),%rax
  81e850:	mov    %rax,0x360(%rsp)
  81e858:	movq   $0x0,0x368(%rsp)
  81e864:	lea    0x3f0(%rsp),%rdi
  81e86c:	lea    0x350(%rsp),%rsi
  81e874:	call   821f30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e879:	cmpb   $0xff,0x3f8(%rsp)
  81e881:	je     81ef4c <<gpui_gpu::renderer::RendererState>::render+0xf3c>
  81e887:	xorps  %xmm0,%xmm0
  81e88a:	movaps %xmm0,0x90(%rsp)
  81e892:	movaps %xmm0,0x60(%rsp)
  81e897:	mov    0x3f0(%rsp),%rdx
  81e89f:	add    0x78(%rsp),%rdx
  81e8a4:	lea    0x3f8(%rsp),%rsi
  81e8ac:	movups 0x38(%rsi),%xmm0
  81e8b0:	lea    0x181(%rsp),%rax
  81e8b8:	movups %xmm0,0x37(%rax)
  81e8bc:	movups 0x48(%rsi),%xmm0
  81e8c0:	lea    0x198(%rsp),%rcx
  81e8c8:	movups %xmm0,0x70(%rcx)
  81e8cc:	mov    0x30(%rsi),%rax
  81e8d0:	mov    %rax,0x1b0(%rsp)
  81e8d8:	movups (%rsi),%xmm0
  81e8db:	movups 0x10(%rsi),%xmm1
  81e8df:	movups 0x20(%rsi),%xmm2
  81e8e3:	movaps %xmm2,0x1a0(%rsp)
  81e8eb:	movaps %xmm1,0x190(%rsp)
  81e8f3:	movaps %xmm0,0x180(%rsp)
  81e8fb:	lea    0x2e0(%rsp),%rax
  81e903:	movups 0x40(%rax),%xmm0
  81e907:	movups %xmm0,0x80(%rcx)
  81e90e:	movups (%rax),%xmm0
  81e911:	movups 0x10(%rax),%xmm1
  81e915:	movups 0x20(%rax),%xmm2
  81e919:	movups %xmm2,0x50(%rcx)
  81e91d:	movups %xmm1,0x40(%rcx)
  81e921:	movups %xmm0,0x30(%rcx)
  81e925:	lea    0x310(%rsp),%rax
  81e92d:	movups (%rax),%xmm0
  81e930:	movups %xmm0,0x60(%rcx)
  81e934:	lea    0x3c8(%rsp),%rdi
  81e93c:	lea    0x180(%rsp),%rsi
  81e944:	mov    %r14d,%ecx
  81e947:	mov    %r15d,%r8d
  81e94a:	call   8218f0 <gpui_gpu::renderer::validate_draw>
  81e94f:	mov    0x3c8(%rsp),%ecx
  81e956:	mov    0x3cc(%rsp),%rax
  81e95e:	cmp    $0xffffffff,%ecx
  81e961:	jne    81f4a8 <<gpui_gpu::renderer::RendererState>::render+0x1498>
  81e967:	mov    %eax,%ecx
  81e969:	shr    $0x20,%rax
  81e96d:	movd   %ecx,%xmm0
  81e971:	movaps 0x90(%rsp),%xmm2
  81e979:	movaps %xmm2,%xmm1
  81e97c:	maxss  %xmm0,%xmm1
  81e980:	movaps %xmm1,%xmm3
  81e983:	cmpunordss %xmm1,%xmm3
  81e988:	movaps %xmm3,%xmm0
  81e98b:	andnps %xmm1,%xmm0
  81e98e:	andps  %xmm2,%xmm3
  81e991:	orps   %xmm0,%xmm3
  81e994:	movaps %xmm3,0x40(%rsp)
  81e999:	movd   %eax,%xmm0
  81e99d:	movaps 0x60(%rsp),%xmm2
  81e9a2:	movaps %xmm2,%xmm1
  81e9a5:	maxss  %xmm0,%xmm1
  81e9a9:	movaps %xmm1,%xmm3
  81e9ac:	cmpunordss %xmm1,%xmm3
  81e9b1:	movaps %xmm3,%xmm0
  81e9b4:	andnps %xmm1,%xmm0
  81e9b7:	andps  %xmm2,%xmm3
  81e9ba:	orps   %xmm0,%xmm3
  81e9bd:	movaps %xmm3,0x80(%rsp)
  81e9c5:	lea    0x3f0(%rsp),%rdi
  81e9cd:	lea    0x350(%rsp),%rsi
  81e9d5:	call   821f30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e9da:	cmpb   $0xff,0x3f8(%rsp)
  81e9e2:	movaps 0x40(%rsp),%xmm0
  81e9e7:	movaps %xmm0,0x90(%rsp)
  81e9ef:	movaps 0x80(%rsp),%xmm0
  81e9f7:	movaps %xmm0,0x60(%rsp)
  81e9fc:	jne    81e897 <<gpui_gpu::renderer::RendererState>::render+0x887>
  81ea02:	jmp    81ef5c <<gpui_gpu::renderer::RendererState>::render+0xf4c>
  81ea07:	cmpq   $0x0,0xb0(%rsp)
  81ea10:	je     81f39a <<gpui_gpu::renderer::RendererState>::render+0x138a>
  81ea16:	mov    0xc8(%rsp),%eax
  81ea1d:	or     $0x80000000,%eax
  81ea22:	mov    %eax,0xe0(%rsp)
  81ea29:	movq   $0x0,0x80(%rsp)
  81ea35:	mov    0x30(%rsp),%rax
  81ea3a:	mov    0x80(%rsp),%rcx
  81ea42:	mov    (%rax,%rcx,1),%edx
  81ea45:	lea    0x180(%rsp),%rdi
  81ea4d:	mov    0x18(%rsp),%rsi
  81ea52:	call   81c8b0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81ea57:	movzbl 0x180(%rsp),%edi
  81ea5f:	lea    0x181(%rsp),%rdx
  81ea67:	mov    (%rdx),%eax
  81ea69:	mov    0x3(%rdx),%ecx
  81ea6c:	lea    0x4f0(%rsp),%rsi
  81ea74:	mov    %ecx,-0x34(%rsi)
  81ea77:	mov    %eax,-0x37(%rsi)
  81ea7a:	mov    0x188(%rsp),%rcx
  81ea82:	mov    0x2f(%rdx),%rax
  81ea86:	mov    %rax,-0x8(%rsi)
  81ea8a:	movups 0xf(%rdx),%xmm0
  81ea8e:	movups 0x1f(%rdx),%xmm1
  81ea92:	movups %xmm1,-0x18(%rsi)
  81ea96:	movups %xmm0,-0x28(%rsi)
  81ea9a:	movups 0x37(%rdx),%xmm0
  81ea9e:	movups %xmm0,(%rsi)
  81eaa1:	lea    0x198(%rsp),%rax
  81eaa9:	movups 0x30(%rax),%xmm0
  81eaad:	movups %xmm0,0x50(%rsi)
  81eab1:	lea    0x2e0(%rsp),%rax
  81eab9:	movups 0x40(%rax),%xmm0
  81eabd:	movups %xmm0,0x60(%rsi)
  81eac1:	movups (%rax),%xmm0
  81eac4:	movups 0x10(%rax),%xmm1
  81eac8:	movups 0x20(%rax),%xmm2
  81eacc:	movups %xmm2,0x30(%rsi)
  81ead0:	movups %xmm1,0x20(%rsi)
  81ead4:	movups %xmm0,0x10(%rsi)
  81ead8:	lea    0x310(%rsp),%rax
  81eae0:	movups (%rax),%xmm0
  81eae3:	movups %xmm0,0x40(%rsi)
  81eae7:	mov    %dil,0x60(%rsp)
  81eaec:	mov    %dil,0x4b8(%rsp)
  81eaf4:	mov    %rcx,0x90(%rsp)
  81eafc:	mov    %rcx,0x4c0(%rsp)
  81eb04:	lea    0x180(%rsp),%rdi
  81eb0c:	lea    0x4b8(%rsp),%rsi
  81eb14:	mov    0x78(%rsp),%rdx
  81eb19:	mov    %r14d,%ecx
  81eb1c:	mov    %r15d,%r8d
  81eb1f:	call   8218f0 <gpui_gpu::renderer::validate_draw>
  81eb24:	mov    0x180(%rsp),%eax
  81eb2b:	mov    0x184(%rsp),%rcx
  81eb33:	mov    %rcx,0x40(%rsp)
  81eb38:	cmp    $0xffffffff,%eax
  81eb3b:	jne    81f53b <<gpui_gpu::renderer::RendererState>::render+0x152b>
  81eb41:	movzbl 0x60(%rsp),%eax
  81eb46:	cmp    $0x2,%al
  81eb48:	sete   0xf0(%rsp)
  81eb50:	cmpq   $0x0,0x90(%rsp)
  81eb59:	setne  0xe8(%rsp)
  81eb61:	movups 0x4f0(%rsp),%xmm0
  81eb69:	movaps %xmm0,0x150(%rsp)
  81eb71:	cmp    $0x3,%al
  81eb73:	jne    81ec05 <<gpui_gpu::renderer::RendererState>::render+0xbf5>
  81eb79:	movss  0x4bc(%rsp),%xmm0
  81eb82:	xorps  %xmm1,%xmm1
  81eb85:	ucomiss %xmm1,%xmm0
  81eb88:	jne    81eb8c <<gpui_gpu::renderer::RendererState>::render+0xb7c>
  81eb8a:	jnp    81ec05 <<gpui_gpu::renderer::RendererState>::render+0xbf5>
  81eb8c:	movaps 0x150(%rsp),%xmm5
  81eb94:	movaps %xmm5,%xmm1
  81eb97:	unpckhpd %xmm5,%xmm1
  81eb9b:	movss  -0x76fbd7(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81eba3:	mulss  %xmm4,%xmm1
  81eba7:	movaps %xmm0,%xmm2
  81ebaa:	minss  %xmm1,%xmm2
  81ebae:	movaps %xmm2,%xmm1
  81ebb1:	cmpunordss %xmm2,%xmm1
  81ebb6:	movaps %xmm1,%xmm3
  81ebb9:	andnps %xmm2,%xmm3
  81ebbc:	andps  %xmm0,%xmm1
  81ebbf:	orps   %xmm3,%xmm1
  81ebc2:	movaps %xmm5,%xmm0
  81ebc5:	shufps $0xff,%xmm5,%xmm0
  81ebc9:	mulss  %xmm4,%xmm0
  81ebcd:	movaps %xmm1,%xmm2
  81ebd0:	minss  %xmm0,%xmm2
  81ebd4:	movaps %xmm2,%xmm0
  81ebd7:	cmpunordss %xmm2,%xmm0
  81ebdc:	andps  %xmm0,%xmm1
  81ebdf:	andnps %xmm2,%xmm0
  81ebe2:	orps   %xmm1,%xmm0
  81ebe5:	movd   %xmm0,%eax
  81ebe9:	mov    %eax,0x60(%rsp)
  81ebed:	and    $0xff800000,%eax
  81ebf2:	mov    $0x7f000000,%ecx
  81ebf7:	sub    %eax,%ecx
  81ebf9:	mov    %ecx,0x90(%rsp)
  81ec00:	xorps  %xmm0,%xmm0
  81ec03:	jmp    81ec27 <<gpui_gpu::renderer::RendererState>::render+0xc17>
  81ec05:	mov    0x550(%rsp),%eax
  81ec0c:	mov    %eax,0x60(%rsp)
  81ec10:	mov    0x554(%rsp),%eax
  81ec17:	mov    %eax,0x90(%rsp)
  81ec1e:	movsd  0x558(%rsp),%xmm0
  81ec27:	movaps %xmm0,0x100(%rsp)
  81ec2f:	mov    0x8(%rsp),%rax
  81ec34:	mov    0x10(%rax),%ecx
  81ec37:	mov    $0x80000000,%eax
  81ec3c:	or     %eax,%ecx
  81ec3e:	mov    %ecx,0x140(%rsp)
  81ec45:	movups 0x500(%rsp),%xmm0
  81ec4d:	movaps %xmm0,0x340(%rsp)
  81ec55:	movups 0x508(%rsp),%xmm0
  81ec5d:	movaps %xmm0,0x460(%rsp)
  81ec65:	movsd  0x510(%rsp),%xmm0
  81ec6e:	movaps %xmm0,0x330(%rsp)
  81ec76:	movsd  0x518(%rsp),%xmm0
  81ec7f:	movaps %xmm0,0x450(%rsp)
  81ec87:	movsd  0x520(%rsp),%xmm0
  81ec90:	movsd  %xmm0,0xd0(%rsp)
  81ec99:	movsd  0x528(%rsp),%xmm0
  81eca2:	movsd  %xmm0,0x290(%rsp)
  81ecab:	movups 0x530(%rsp),%xmm0
  81ecb3:	movaps %xmm0,0x130(%rsp)
  81ecbb:	mov    0x18(%rsp),%rax
  81ecc0:	mov    %rax,0x180(%rsp)
  81ecc8:	mov    0x30(%rsp),%rax
  81eccd:	mov    %rax,0x188(%rsp)
  81ecd5:	mov    0xb0(%rsp),%rax
  81ecdd:	mov    %rax,0x190(%rsp)
  81ece5:	movaps 0x370(%rsp),%xmm0
  81eced:	movaps 0x380(%rsp),%xmm1
  81ecf5:	movaps 0x390(%rsp),%xmm2
  81ecfd:	lea    0x198(%rsp),%rax
  81ed05:	movups %xmm2,0x20(%rax)
  81ed09:	movups %xmm1,0x10(%rax)
  81ed0d:	movups %xmm0,(%rax)
  81ed10:	movaps 0x470(%rsp),%xmm0
  81ed18:	movups %xmm0,0x30(%rax)
  81ed1c:	movaps 0x3b0(%rsp),%xmm0
  81ed24:	movups %xmm0,0x40(%rax)
  81ed28:	lea    0x180(%rsp),%rdi
  81ed30:	call   *0x6624f2(%rip)        # e81228 <_DYNAMIC+0x5c0>
  81ed36:	mov    0xc8(%rsp),%ecx
  81ed3d:	mov    %ecx,0x28(%rsp)
  81ed41:	test   %eax,%eax
  81ed43:	je     81ed76 <<gpui_gpu::renderer::RendererState>::render+0xd66>
  81ed45:	mov    0x20(%rsp),%rdi
  81ed4a:	mov    %eax,%esi
  81ed4c:	call   825f70 <gpui_gpu::renderer::slots::color_word>
  81ed51:	mov    %eax,0x60(%rsp)
  81ed55:	xorps  %xmm0,%xmm0
  81ed58:	movaps %xmm0,0x100(%rsp)
  81ed60:	movl   $0x0,0x90(%rsp)
  81ed6b:	mov    0xe0(%rsp),%eax
  81ed72:	mov    %eax,0x28(%rsp)
  81ed76:	mov    0x40(%rsp),%rax
  81ed7b:	shr    $0x20,%rax
  81ed7f:	mov    %rax,0x288(%rsp)
  81ed87:	mov    0x8(%rsp),%rax
  81ed8c:	mov    (%rax),%rcx
  81ed8f:	mov    0x10(%rax),%rsi
  81ed93:	sub    %rsi,%rcx
  81ed96:	cmp    $0x5,%rcx
  81ed9a:	jbe    81ef24 <<gpui_gpu::renderer::RendererState>::render+0xf14>
  81eda0:	movsd  0x290(%rsp),%xmm0
  81eda9:	cvtsd2ss %xmm0,%xmm0
  81edad:	movsd  0xd0(%rsp),%xmm1
  81edb6:	cvtsd2ss %xmm1,%xmm1
  81edba:	movapd 0x460(%rsp),%xmm2
  81edc3:	unpcklpd 0x450(%rsp),%xmm2
  81edcc:	cvtpd2ps %xmm2,%xmm2
  81edd0:	movapd 0x340(%rsp),%xmm3
  81edd9:	unpcklpd 0x330(%rsp),%xmm3
  81ede2:	cvtpd2ps %xmm3,%xmm3
  81ede6:	mov    0x8(%rsp),%rax
  81edeb:	mov    0x8(%rax),%rdx
  81edef:	shl    $0x4,%rsi
  81edf3:	movaps 0x150(%rsp),%xmm4
  81edfb:	movups %xmm4,(%rdx,%rsi,1)
  81edff:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ee05:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ee0b:	mov    0x40(%rsp),%rcx
  81ee10:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ee14:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ee1a:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81ee20:	mov    0x288(%rsp),%rdi
  81ee28:	mov    %edi,0x2c(%rdx,%rsi,1)
  81ee2c:	movaps 0x130(%rsp),%xmm0
  81ee34:	movups %xmm0,0x30(%rdx,%rsi,1)
  81ee39:	mov    0x60(%rsp),%edi
  81ee3d:	mov    %edi,0x40(%rdx,%rsi,1)
  81ee41:	mov    0x90(%rsp),%edi
  81ee48:	mov    %edi,0x44(%rdx,%rsi,1)
  81ee4c:	movaps 0x100(%rsp),%xmm0
  81ee54:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81ee59:	movq   $0x0,0x50(%rdx,%rsi,1)
  81ee62:	movl   $0x0,0x58(%rdx,%rsi,1)
  81ee6a:	mov    0x28(%rsp),%edi
  81ee6e:	mov    %edi,0x5c(%rdx,%rsi,1)
  81ee72:	addq   $0x6,0x10(%rax)
  81ee77:	lea    0x180(%rsp),%rdi
  81ee7f:	mov    %rax,%rsi
  81ee82:	lea    0x4b8(%rsp),%rdx
  81ee8a:	mov    0x140(%rsp),%r8d
  81ee92:	mov    0x78(%rsp),%r9
  81ee97:	push   0xf8(%rsp)
  81ee9e:	push   %r15
  81eea0:	push   %r14
  81eea2:	push   0xb8(%rsp)
  81eea9:	call   8206e0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81eeae:	add    $0x20,%rsp
  81eeb2:	mov    0x180(%rsp),%eax
  81eeb9:	cmp    $0xffffffff,%eax
  81eebc:	jne    81f503 <<gpui_gpu::renderer::RendererState>::render+0x14f3>
  81eec2:	movzbl 0xf0(%rsp),%ecx
  81eeca:	and    0xe8(%rsp),%cl
  81eed1:	mov    0x10(%rsp),%rax
  81eed6:	or     %cl,%al
  81eed8:	mov    %rax,0x10(%rsp)
  81eedd:	mov    0x188(%rsp),%rax
  81eee5:	mov    %rax,0xf8(%rsp)
  81eeed:	incq   0x78(%rsp)
  81eef2:	mov    0x80(%rsp),%rdx
  81eefa:	add    $0x4,%rdx
  81eefe:	mov    0xb0(%rsp),%rax
  81ef06:	lea    0x0(,%rax,4),%rax
  81ef0e:	mov    %rdx,0x80(%rsp)
  81ef16:	cmp    %rdx,%rax
  81ef19:	jne    81ea35 <<gpui_gpu::renderer::RendererState>::render+0xa25>
  81ef1f:	jmp    81f38e <<gpui_gpu::renderer::RendererState>::render+0x137e>
  81ef24:	mov    $0x6,%edx
  81ef29:	mov    $0x4,%ecx
  81ef2e:	mov    $0x10,%r8d
  81ef34:	mov    0x8(%rsp),%rdi
  81ef39:	call   8248b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81ef3e:	mov    0x8(%rsp),%rax
  81ef43:	mov    0x10(%rax),%rsi
  81ef47:	jmp    81eda0 <<gpui_gpu::renderer::RendererState>::render+0xd90>
  81ef4c:	xorps  %xmm0,%xmm0
  81ef4f:	movaps %xmm0,0x80(%rsp)
  81ef57:	movaps %xmm0,0x40(%rsp)
  81ef5c:	mov    0x8(%rsp),%rax
  81ef61:	mov    0x10(%rax),%eax
  81ef64:	mov    %eax,0x100(%rsp)
  81ef6b:	movups 0x2e0(%rsp),%xmm1
  81ef73:	movups 0x2e8(%rsp),%xmm2
  81ef7b:	movsd  0x300(%rsp),%xmm0
  81ef84:	movsd  %xmm0,0x28(%rsp)
  81ef8a:	movsd  0x308(%rsp),%xmm0
  81ef93:	movsd  %xmm0,0x150(%rsp)
  81ef9c:	movups 0x310(%rsp),%xmm0
  81efa4:	movaps %xmm0,0x90(%rsp)
  81efac:	movhps 0x2f0(%rsp),%xmm1
  81efb4:	movaps %xmm1,0x140(%rsp)
  81efbc:	movups 0x320(%rsp),%xmm0
  81efc4:	movaps %xmm0,0x60(%rsp)
  81efc9:	movhps 0x2f8(%rsp),%xmm2
  81efd1:	movaps %xmm2,0x130(%rsp)
  81efd9:	mov    0x18(%rsp),%rax
  81efde:	mov    %rax,0x180(%rsp)
  81efe6:	mov    0x30(%rsp),%rax
  81efeb:	mov    %rax,0x188(%rsp)
  81eff3:	mov    0xb0(%rsp),%rax
  81effb:	mov    %rax,0x190(%rsp)
  81f003:	lea    0x2e0(%rsp),%rax
  81f00b:	movups (%rax),%xmm0
  81f00e:	movups 0x10(%rax),%xmm1
  81f012:	movups 0x20(%rax),%xmm2
  81f016:	lea    0x198(%rsp),%rdx
  81f01e:	movups %xmm2,0x20(%rdx)
  81f022:	movups %xmm1,0x10(%rdx)
  81f026:	movups %xmm0,(%rdx)
  81f029:	lea    0x310(%rsp),%rcx
  81f031:	movups (%rcx),%xmm0
  81f034:	movups %xmm0,0x30(%rdx)
  81f038:	movdqu 0x40(%rax),%xmm0
  81f03d:	movdqu %xmm0,0x40(%rdx)
  81f042:	lea    0x180(%rsp),%rdi
  81f04a:	call   *0x6621d8(%rip)        # e81228 <_DYNAMIC+0x5c0>
  81f050:	test   %eax,%eax
  81f052:	je     81f075 <<gpui_gpu::renderer::RendererState>::render+0x1065>
  81f054:	mov    0x20(%rsp),%rdi
  81f059:	mov    %eax,%esi
  81f05b:	call   825f70 <gpui_gpu::renderer::slots::color_word>
  81f060:	orl    $0x80000000,0xc8(%rsp)
  81f06b:	movd   %eax,%xmm0
  81f06f:	movdqa %xmm0,0x60(%rsp)
  81f075:	mov    0x8(%rsp),%rax
  81f07a:	mov    (%rax),%rcx
  81f07d:	mov    0x10(%rax),%rsi
  81f081:	sub    %rsi,%rcx
  81f084:	cmp    $0x4,%rcx
  81f088:	jbe    81f3c8 <<gpui_gpu::renderer::RendererState>::render+0x13b8>
  81f08e:	cvtpd2ps 0x140(%rsp),%xmm0
  81f097:	cvtpd2ps 0x130(%rsp),%xmm1
  81f0a0:	movsd  0x28(%rsp),%xmm2
  81f0a6:	cvtsd2ss %xmm2,%xmm2
  81f0aa:	movsd  0x150(%rsp),%xmm3
  81f0b3:	cvtsd2ss %xmm3,%xmm3
  81f0b7:	mov    0x8(%rsp),%rax
  81f0bc:	mov    0x8(%rax),%rcx
  81f0c0:	shl    $0x4,%rsi
  81f0c4:	movlpd %xmm0,(%rcx,%rsi,1)
  81f0c9:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f0cf:	movaps 0x40(%rsp),%xmm0
  81f0d4:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f0da:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f0e0:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f0e6:	movaps 0x80(%rsp),%xmm0
  81f0ee:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f0f4:	movaps 0x90(%rsp),%xmm0
  81f0fc:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f101:	movaps 0x60(%rsp),%xmm0
  81f106:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f10b:	mov    0xc8(%rsp),%edx
  81f112:	mov    %edx,0x40(%rcx,%rsi,1)
  81f116:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f11f:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f127:	addq   $0x5,0x10(%rax)
  81f12c:	incq   0x270(%rsp)
  81f134:	mov    0xb0(%rsp),%rax
  81f13c:	add    %rax,0x278(%rsp)
  81f144:	test   %rax,%rax
  81f147:	je     81f39a <<gpui_gpu::renderer::RendererState>::render+0x138a>
  81f14d:	movdqa 0x40(%rsp),%xmm0
  81f153:	movd   %xmm0,%ecx
  81f157:	movdqa 0x80(%rsp),%xmm0
  81f160:	movd   %xmm0,%eax
  81f164:	shl    $0x20,%rax
  81f168:	or     %rax,%rcx
  81f16b:	mov    %rcx,0x28(%rsp)
  81f170:	movq   $0x0,0x40(%rsp)
  81f179:	mov    0x30(%rsp),%rax
  81f17e:	mov    0x40(%rsp),%rcx
  81f183:	mov    (%rax,%rcx,1),%edx
  81f186:	lea    0x3f0(%rsp),%rdi
  81f18e:	mov    0x18(%rsp),%rsi
  81f193:	call   81c8b0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f198:	movzbl 0x3f0(%rsp),%edi
  81f1a0:	lea    0x3f8(%rsp),%rsi
  81f1a8:	mov    -0x7(%rsi),%eax
  81f1ab:	mov    -0x4(%rsi),%ecx
  81f1ae:	lea    0x181(%rsp),%rdx
  81f1b6:	mov    %ecx,0x3(%rdx)
  81f1b9:	mov    %eax,(%rdx)
  81f1bb:	mov    0x3f8(%rsp),%rcx
  81f1c3:	mov    0x28(%rsi),%rax
  81f1c7:	mov    %rax,0x2f(%rdx)
  81f1cb:	movups 0x8(%rsi),%xmm0
  81f1cf:	movups 0x18(%rsi),%xmm1
  81f1d3:	movups %xmm1,0x1f(%rdx)
  81f1d7:	movups %xmm0,0xf(%rdx)
  81f1db:	movups 0x428(%rsp),%xmm1
  81f1e3:	movups 0x40(%rsi),%xmm0
  81f1e7:	lea    0x198(%rsp),%rax
  81f1ef:	movups %xmm0,0x70(%rax)
  81f1f3:	movaps 0x3b0(%rsp),%xmm0
  81f1fb:	movups %xmm0,0x80(%rax)
  81f202:	movaps %xmm1,0xb0(%rsp)
  81f20a:	movups %xmm1,0x1b8(%rsp)
  81f212:	movaps 0x560(%rsp),%xmm0
  81f21a:	movaps 0x570(%rsp),%xmm1
  81f222:	movapd 0x580(%rsp),%xmm2
  81f22b:	movupd %xmm2,0x50(%rax)
  81f230:	movups %xmm1,0x40(%rax)
  81f234:	movups %xmm0,0x30(%rax)
  81f238:	movaps 0x590(%rsp),%xmm0
  81f240:	movups %xmm0,0x60(%rax)
  81f244:	mov    %dil,0x60(%rsp)
  81f249:	mov    %dil,0x180(%rsp)
  81f251:	mov    %rcx,0x90(%rsp)
  81f259:	mov    %rcx,0x188(%rsp)
  81f261:	mov    0x8(%rsp),%rax
  81f266:	mov    (%rax),%rcx
  81f269:	mov    0x10(%rax),%rax
  81f26d:	sub    %rax,%rcx
  81f270:	mov    %rax,0x80(%rsp)
  81f278:	cmp    $0x1,%rcx
  81f27c:	jbe    81f35e <<gpui_gpu::renderer::RendererState>::render+0x134e>
  81f282:	mov    0x8(%rsp),%rsi
  81f287:	mov    0x8(%rsi),%rcx
  81f28b:	shl    $0x4,%rax
  81f28f:	movaps 0xb0(%rsp),%xmm0
  81f297:	movups %xmm0,(%rcx,%rax,1)
  81f29b:	movq   $0x0,0x10(%rcx,%rax,1)
  81f2a4:	movl   $0x0,0x18(%rcx,%rax,1)
  81f2ac:	mov    0x100(%rsp),%edx
  81f2b3:	mov    %edx,0x1c(%rcx,%rax,1)
  81f2b7:	addq   $0x2,0x10(%rsi)
  81f2bc:	lea    0x3f0(%rsp),%rdi
  81f2c4:	lea    0x180(%rsp),%rdx
  81f2cc:	mov    0x28(%rsp),%rcx
  81f2d1:	mov    0x80(%rsp),%r8
  81f2d9:	mov    0x78(%rsp),%r9
  81f2de:	push   0xf8(%rsp)
  81f2e5:	push   %r15
  81f2e7:	push   %r14
  81f2e9:	push   0xb8(%rsp)
  81f2f0:	call   8206e0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f2f5:	add    $0x20,%rsp
  81f2f9:	mov    0x3f0(%rsp),%eax
  81f300:	cmp    $0xffffffff,%eax
  81f303:	jne    81f51f <<gpui_gpu::renderer::RendererState>::render+0x150f>
  81f309:	cmpb   $0x2,0x60(%rsp)
  81f30e:	sete   %al
  81f311:	cmpq   $0x0,0x90(%rsp)
  81f31a:	setne  %cl
  81f31d:	and    %al,%cl
  81f31f:	mov    0x10(%rsp),%rax
  81f324:	or     %cl,%al
  81f326:	mov    %rax,0x10(%rsp)
  81f32b:	mov    0x3f8(%rsp),%rax
  81f333:	mov    %rax,0xf8(%rsp)
  81f33b:	incq   0x78(%rsp)
  81f340:	mov    0x40(%rsp),%rcx
  81f345:	add    $0x4,%rcx
  81f349:	mov    %rcx,0x40(%rsp)
  81f34e:	cmp    %rcx,0x280(%rsp)
  81f356:	jne    81f179 <<gpui_gpu::renderer::RendererState>::render+0x1169>
  81f35c:	jmp    81f38e <<gpui_gpu::renderer::RendererState>::render+0x137e>
  81f35e:	mov    $0x2,%edx
  81f363:	mov    $0x4,%ecx
  81f368:	mov    $0x10,%r8d
  81f36e:	mov    0x8(%rsp),%rdi
  81f373:	mov    0x80(%rsp),%rsi
  81f37b:	call   8248b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f380:	mov    0x8(%rsp),%rax
  81f385:	mov    0x10(%rax),%rax
  81f389:	jmp    81f282 <<gpui_gpu::renderer::RendererState>::render+0x1272>
  81f38e:	mov    0x10(%rsp),%rax
  81f393:	and    $0x1,%al
  81f395:	mov    %rax,0x10(%rsp)
  81f39a:	lea    0x2c8(%rsp),%rdi
  81f3a2:	lea    0x2a0(%rsp),%rsi
  81f3aa:	call   *0x661e70(%rip)        # e81220 <_DYNAMIC+0x5b8>
  81f3b0:	mov    0x2c8(%rsp),%rax
  81f3b8:	mov    %rax,0x18(%rsp)
  81f3bd:	test   %rax,%rax
  81f3c0:	jne    81e6e8 <<gpui_gpu::renderer::RendererState>::render+0x6d8>
  81f3c6:	jmp    81f426 <<gpui_gpu::renderer::RendererState>::render+0x1416>
  81f3c8:	mov    $0x5,%edx
  81f3cd:	mov    $0x4,%ecx
  81f3d2:	mov    $0x10,%r8d
  81f3d8:	mov    0x8(%rsp),%rdi
  81f3dd:	call   8248b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f3e2:	mov    0x8(%rsp),%rax
  81f3e7:	mov    0x10(%rax),%rsi
  81f3eb:	jmp    81f08e <<gpui_gpu::renderer::RendererState>::render+0x107e>
  81f3f0:	movq   $0x0,0x278(%rsp)
  81f3fc:	movq   $0x0,0x270(%rsp)
  81f408:	movq   $0x0,0x78(%rsp)
  81f411:	movq   $0x0,0x10(%rsp)
  81f41a:	movq   $0x0,0xf8(%rsp)
  81f426:	mov    0x170(%rsp),%rsi
  81f42e:	lea    0x8(%rsi),%rdx
  81f432:	mov    0x8(%rsp),%rax
  81f437:	lea    0x258(%rax),%rcx
  81f43e:	lea    0x328(%rax),%r8
  81f445:	mov    0x10(%rax),%r9
  81f449:	sub    $0x8,%rsp
  81f44d:	lea    0x188(%rsp),%rdi
  81f455:	mov    %rdx,0x288(%rsp)
  81f45d:	mov    %rcx,0xd0(%rsp)
  81f465:	mov    %r8,0x298(%rsp)
  81f46d:	push   0x180(%rsp)
  81f474:	call   823b30 <gpui_gpu::renderer::images::prepare>
  81f479:	add    $0x10,%rsp
  81f47d:	cmpl   $0xffffffff,0x180(%rsp)
  81f485:	je     81f4ce <<gpui_gpu::renderer::RendererState>::render+0x14be>
  81f487:	movups 0x180(%rsp),%xmm0
  81f48f:	movups 0x190(%rsp),%xmm1
  81f497:	mov    0x58(%rsp),%rdi
  81f49c:	movups %xmm1,0x10(%rdi)
  81f4a0:	movups %xmm0,(%rdi)
  81f4a3:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f4a8:	mov    0x3e4(%rsp),%edx
  81f4af:	mov    0x58(%rsp),%rdi
  81f4b4:	mov    %edx,0x1c(%rdi)
  81f4b7:	movups 0x3d4(%rsp),%xmm0
  81f4bf:	movups %xmm0,0xc(%rdi)
  81f4c3:	mov    %ecx,(%rdi)
  81f4c5:	mov    %rax,0x4(%rdi)
  81f4c9:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f4ce:	movzbl 0x10(%rsp),%r8d
  81f4d4:	and    $0x1,%r8d
  81f4d8:	lea    0x180(%rsp),%rdi
  81f4e0:	mov    0x8(%rsp),%rsi
  81f4e5:	mov    0x170(%rsp),%rdx
  81f4ed:	mov    0x38(%rsp),%rcx
  81f4f2:	call   81d770 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f4f7:	mov    0x180(%rsp),%eax
  81f4fe:	cmp    $0xffffffff,%eax
  81f501:	je     81f566 <<gpui_gpu::renderer::RendererState>::render+0x1556>
  81f503:	mov    0x184(%rsp),%ecx
  81f50a:	mov    0x188(%rsp),%rdx
  81f512:	movups 0x190(%rsp),%xmm0
  81f51a:	jmp    81e54f <<gpui_gpu::renderer::RendererState>::render+0x53f>
  81f51f:	mov    0x3f4(%rsp),%ecx
  81f526:	mov    0x3f8(%rsp),%rdx
  81f52e:	movups 0x400(%rsp),%xmm0
  81f536:	jmp    81e54f <<gpui_gpu::renderer::RendererState>::render+0x53f>
  81f53b:	mov    0x19c(%rsp),%ecx
  81f542:	mov    0x58(%rsp),%rdi
  81f547:	mov    %ecx,0x1c(%rdi)
  81f54a:	movups 0x18c(%rsp),%xmm0
  81f552:	movups %xmm0,0xc(%rdi)
  81f556:	mov    %eax,(%rdi)
  81f558:	mov    0x40(%rsp),%rax
  81f55d:	mov    %rax,0x4(%rdi)
  81f561:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f566:	cmpl   $0x0,0xa0(%rsp)
  81f56e:	je     820655 <<gpui_gpu::renderer::RendererState>::render+0x2645>
  81f574:	mov    0x188(%rsp),%rax
  81f57c:	mov    %rax,0x488(%rsp)
  81f584:	mov    0x8(%rsp),%rax
  81f589:	movdqu 0x20(%rax),%xmm0
  81f58e:	movups 0x50(%rax),%xmm1
  81f592:	movdqu %xmm0,0x2c8(%rsp)
  81f59b:	mov    0xa0(%rsp),%rax
  81f5a3:	mov    %rax,0x2d8(%rsp)
  81f5ab:	movups %xmm1,0x180(%rsp)
  81f5b3:	mov    %rax,0x190(%rsp)
  81f5bb:	lea    0x3f0(%rsp),%rdi
  81f5c3:	lea    0x2c8(%rsp),%rsi
  81f5cb:	lea    0x180(%rsp),%rdx
  81f5d3:	call   825d90 <<core::iter::adapters::zip::Zip<core::slice::iter::ChunksMut<[u32; 2]>, core::slice::iter::Chunks<u32>> as core::iter::adapters::zip::ZipImpl<core::slice::iter::ChunksMut<[u32; 2]>, core::slice::iter::Chunks<u32>>>::new>
  81f5d8:	mov    0x420(%rsp),%rax
  81f5e0:	mov    0x428(%rsp),%rcx
  81f5e8:	mov    %rax,0x80(%rsp)
  81f5f0:	mov    %rcx,0x150(%rsp)
  81f5f8:	cmp    %rcx,%rax
  81f5fb:	jae    81f902 <<gpui_gpu::renderer::RendererState>::render+0x18f2>
  81f601:	mov    0x408(%rsp),%rax
  81f609:	movq   $0x0,0xe0(%rsp)
  81f615:	test   %rax,%rax
  81f618:	je     81f90e <<gpui_gpu::renderer::RendererState>::render+0x18fe>
  81f61e:	mov    0x3f0(%rsp),%rcx
  81f626:	mov    0x3f8(%rsp),%rdi
  81f62e:	mov    0x400(%rsp),%r8
  81f636:	mov    0x410(%rsp),%r9
  81f63e:	mov    0x418(%rsp),%r10
  81f646:	mov    0x80(%rsp),%rsi
  81f64e:	mov    %rsi,%rdx
  81f651:	imul   %r8,%rdx
  81f655:	lea    (%rcx,%rdx,4),%rcx
  81f659:	mov    %rcx,0x20(%rsp)
  81f65e:	mov    %r8,0x90(%rsp)
  81f666:	lea    0x0(,%r8,4),%rcx
  81f66e:	mov    %rcx,0x340(%rsp)
  81f676:	mov    %rsi,%rcx
  81f679:	imul   %r10,%rcx
  81f67d:	lea    (%rax,%rcx,8),%rax
  81f681:	add    $0x4,%rax
  81f685:	mov    %rax,0x10(%rsp)
  81f68a:	mov    %r10,0x100(%rsp)
  81f692:	lea    0x0(,%r10,8),%rax
  81f69a:	mov    %rax,0x330(%rsp)
  81f6a2:	mov    %r9,0x130(%rsp)
  81f6aa:	sub    %rcx,%r9
  81f6ad:	mov    %r9,0xb0(%rsp)
  81f6b5:	mov    %rdi,0x140(%rsp)
  81f6bd:	sub    %rdx,%rdi
  81f6c0:	mov    %rdi,0x60(%rsp)
  81f6c5:	movq   $0x0,0xd0(%rsp)
  81f6d1:	movq   $0x0,0xf0(%rsp)
  81f6dd:	movq   $0x0,0xe8(%rsp)
  81f6e9:	movl   $0x0,0x18(%rsp)
  81f6f1:	movl   $0x0,0x28(%rsp)
  81f6f9:	jmp    81f764 <<gpui_gpu::renderer::RendererState>::render+0x1754>
  81f6fb:	mov    0x80(%rsp),%rax
  81f703:	inc    %rax
  81f706:	incl   0x28(%rsp)
  81f70a:	mov    0x340(%rsp),%rcx
  81f712:	add    %rcx,0x20(%rsp)
  81f717:	mov    0x330(%rsp),%rcx
  81f71f:	add    %rcx,0x10(%rsp)
  81f724:	mov    0xb0(%rsp),%rcx
  81f72c:	sub    0x100(%rsp),%rcx
  81f734:	mov    %rcx,0xb0(%rsp)
  81f73c:	mov    0x60(%rsp),%rcx
  81f741:	sub    0x90(%rsp),%rcx
  81f749:	mov    %rcx,0x60(%rsp)
  81f74e:	mov    %rax,0x80(%rsp)
  81f756:	cmp    0x150(%rsp),%rax
  81f75e:	je     81f934 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f764:	mov    0x90(%rsp),%rsi
  81f76c:	mov    0x100(%rsp),%rdi
  81f774:	cmp    %rsi,%rdi
  81f777:	mov    %rsi,%rcx
  81f77a:	cmovb  %rdi,%rcx
  81f77e:	mov    0xb0(%rsp),%rax
  81f786:	cmp    %rax,%rcx
  81f789:	cmovae %rax,%rcx
  81f78d:	mov    0x60(%rsp),%rax
  81f792:	cmp    %rax,%rcx
  81f795:	cmovae %rax,%rcx
  81f799:	mov    %rcx,0x30(%rsp)
  81f79e:	mov    0x80(%rsp),%rcx
  81f7a6:	mov    %rcx,%rax
  81f7a9:	imul   %rdi,%rax
  81f7ad:	imul   %rsi,%rcx
  81f7b1:	mov    0x140(%rsp),%rdx
  81f7b9:	sub    %rcx,%rdx
  81f7bc:	cmp    %rdx,%rsi
  81f7bf:	cmovb  %rsi,%rdx
  81f7c3:	mov    0x130(%rsp),%rcx
  81f7cb:	sub    %rax,%rcx
  81f7ce:	cmp    %rcx,%rdi
  81f7d1:	cmovb  %rdi,%rcx
  81f7d5:	mov    0x28(%rsp),%eax
  81f7d9:	shl    $0x4,%eax
  81f7dc:	mov    %r15d,%esi
  81f7df:	sub    %eax,%esi
  81f7e1:	cmp    $0x10,%esi
  81f7e4:	mov    $0x10,%eax
  81f7e9:	cmovae %eax,%esi
  81f7ec:	mov    %esi,0x40(%rsp)
  81f7f0:	cmp    %rcx,%rdx
  81f7f3:	cmovb  %rdx,%rcx
  81f7f7:	test   %rcx,%rcx
  81f7fa:	je     81f6fb <<gpui_gpu::renderer::RendererState>::render+0x16eb>
  81f800:	mov    %r14d,%ecx
  81f803:	xor    %edi,%edi
  81f805:	jmp    81f8a2 <<gpui_gpu::renderer::RendererState>::render+0x1892>
  81f80a:	test   %r10d,%r10d
  81f80d:	je     81f867 <<gpui_gpu::renderer::RendererState>::render+0x1857>
  81f80f:	cmp    $0x10,%ecx
  81f812:	mov    $0x10,%r9d
  81f818:	cmovb  %ecx,%r9d
  81f81c:	imul   0x40(%rsp),%r9d
  81f822:	mov    %r9,%rsi
  81f825:	shl    $0x4,%rsi
  81f829:	test   %edx,%edx
  81f82b:	cmovne %r9,%rsi
  81f82f:	add    %rsi,0xf0(%rsp)
  81f837:	xor    %r11d,%r11d
  81f83a:	test   %r8d,%r8d
  81f83d:	setne  %r11b
  81f841:	mov    $0x0,%eax
  81f846:	cmove  %rax,%r9
  81f84a:	mov    %r10,%rax
  81f84d:	sub    %r11,%rax
  81f850:	imul   %rsi,%rax
  81f854:	add    0xd0(%rsp),%r9
  81f85c:	add    %rax,%r9
  81f85f:	mov    %r9,0xd0(%rsp)
  81f867:	xor    %r9d,%r9d
  81f86a:	test   %r8d,%r8d
  81f86d:	setne  %r9b
  81f871:	mov    0x18(%rsp),%esi
  81f875:	add    %r10d,%esi
  81f878:	shl    $0x1d,%r9d
  81f87c:	or     %esi,%edx
  81f87e:	or     %r9d,%edx
  81f881:	mov    0x10(%rsp),%rax
  81f886:	mov    %esi,0x18(%rsp)
  81f88a:	mov    %esi,-0x4(%rax,%rdi,8)
  81f88e:	mov    %edx,(%rax,%rdi,8)
  81f891:	inc    %rdi
  81f894:	add    $0xfffffff0,%ecx
  81f897:	cmp    %rdi,0x30(%rsp)
  81f89c:	je     81f6fb <<gpui_gpu::renderer::RendererState>::render+0x16eb>
  81f8a2:	mov    0x20(%rsp),%rax
  81f8a7:	mov    (%rax,%rdi,4),%r8d
  81f8ab:	mov    0x10(%rsp),%rax
  81f8b0:	mov    (%rax,%rdi,8),%r10d
  81f8b4:	mov    %r10d,%edx
  81f8b7:	and    $0x40000000,%edx
  81f8bd:	and    $0xbfffffff,%r10d
  81f8c4:	test   %r8d,%r8d
  81f8c7:	je     81f80a <<gpui_gpu::renderer::RendererState>::render+0x17fa>
  81f8cd:	test   %r10d,%r10d
  81f8d0:	je     81f867 <<gpui_gpu::renderer::RendererState>::render+0x1857>
  81f8d2:	cmp    $0x1,%r10d
  81f8d6:	jne    81f80f <<gpui_gpu::renderer::RendererState>::render+0x17ff>
  81f8dc:	mov    0x10(%rsp),%rax
  81f8e1:	movl   $0x80000000,(%rax,%rdi,8)
  81f8e8:	incq   0xe8(%rsp)
  81f8f0:	inc    %rdi
  81f8f3:	add    $0xfffffff0,%ecx
  81f8f6:	cmp    %rdi,0x30(%rsp)
  81f8fb:	jne    81f8a2 <<gpui_gpu::renderer::RendererState>::render+0x1892>
  81f8fd:	jmp    81f6fb <<gpui_gpu::renderer::RendererState>::render+0x16eb>
  81f902:	movq   $0x0,0xe0(%rsp)
  81f90e:	movq   $0x0,0xe8(%rsp)
  81f91a:	movq   $0x0,0xf0(%rsp)
  81f926:	movq   $0x0,0xd0(%rsp)
  81f932:	jmp    81f940 <<gpui_gpu::renderer::RendererState>::render+0x1930>
  81f934:	mov    0x18(%rsp),%eax
  81f938:	mov    %rax,0xe0(%rsp)
  81f940:	mov    0x8(%rsp),%rax
  81f945:	lea    0x30(%rax),%rdi
  81f949:	movq   $0x0,0x40(%rax)
  81f951:	movl   $0x0,0x11c(%rsp)
  81f95c:	mov    %rdi,0x450(%rsp)
  81f964:	mov    0xe0(%rsp),%rsi
  81f96c:	xor    %edx,%edx
  81f96e:	call   8239e0 <<alloc::vec::Vec<u32>>::resize>
  81f973:	mov    0x8(%rsp),%rax
  81f978:	mov    0x10(%rax),%rax
  81f97c:	mov    %rax,0x20(%rsp)
  81f981:	mov    0x78(%rsp),%rax
  81f986:	mov    %rax,0x3a8(%rsp)
  81f98e:	mov    0x38(%rsp),%rax
  81f993:	mov    %rax,0x3c8(%rsp)
  81f99b:	movq   $0x0,0x3d0(%rsp)
  81f9a7:	mov    0xa8(%rsp),%rax
  81f9af:	mov    %rax,0x3d8(%rsp)
  81f9b7:	mov    0x168(%rsp),%rax
  81f9bf:	mov    %rax,0x3e0(%rsp)
  81f9c7:	mov    0xdc(%rsp),%eax
  81f9ce:	mov    %eax,0x3e8(%rsp)
  81f9d5:	lea    0x2c8(%rsp),%rdi
  81f9dd:	lea    0x3c8(%rsp),%rsi
  81f9e5:	call   *0x661845(%rip)        # e81230 <_DYNAMIC+0x5c8>
  81f9eb:	mov    0x2c8(%rsp),%rax
  81f9f3:	mov    %rax,0x130(%rsp)
  81f9fb:	test   %rax,%rax
  81f9fe:	je     82003e <<gpui_gpu::renderer::RendererState>::render+0x202e>
  81fa04:	mov    0x8(%rsp),%rax
  81fa09:	add    $0x120,%rax
  81fa0f:	mov    %rax,0x288(%rsp)
  81fa17:	jmp    81fa62 <<gpui_gpu::renderer::RendererState>::render+0x1a52>
  81fa19:	mov    0x20(%rsp),%rcx
  81fa1e:	lea    -0x5(%rcx),%rax
  81fa22:	cmpb   $0x0,0x140(%rsp)
  81fa2a:	cmovne %rax,%rcx
  81fa2e:	mov    %rcx,0x20(%rsp)
  81fa33:	lea    0x2c8(%rsp),%rdi
  81fa3b:	lea    0x3c8(%rsp),%rsi
  81fa43:	call   *0x6617e7(%rip)        # e81230 <_DYNAMIC+0x5c8>
  81fa49:	mov    0x2c8(%rsp),%rax
  81fa51:	mov    %rax,0x130(%rsp)
  81fa59:	test   %rax,%rax
  81fa5c:	je     82003e <<gpui_gpu::renderer::RendererState>::render+0x202e>
  81fa62:	mov    0x2d0(%rsp),%rdi
  81fa6a:	mov    0x2d8(%rsp),%r8
  81fa72:	mov    %r8,0x30(%rsp)
  81fa77:	lea    0x2e0(%rsp),%rcx
  81fa7f:	movups (%rcx),%xmm0
  81fa82:	movups 0x10(%rcx),%xmm1
  81fa86:	movups 0x20(%rcx),%xmm2
  81fa8a:	movaps %xmm2,0x390(%rsp)
  81fa92:	movaps %xmm1,0x380(%rsp)
  81fa9a:	movaps %xmm0,0x370(%rsp)
  81faa2:	lea    0x310(%rsp),%rdx
  81faaa:	movups (%rdx),%xmm0
  81faad:	movaps %xmm0,0x3b0(%rsp)
  81fab5:	movups 0x40(%rcx),%xmm0
  81fab9:	movaps %xmm0,0x5a0(%rsp)
  81fac1:	mov    0x8(%rsp),%rax
  81fac6:	movzbl 0x341(%rax),%esi
  81facd:	mov    0x130(%rsp),%rax
  81fad5:	mov    %rax,0x180(%rsp)
  81fadd:	mov    %rdi,0x340(%rsp)
  81fae5:	mov    %rdi,0x188(%rsp)
  81faed:	mov    %r8,0x190(%rsp)
  81faf5:	movups (%rcx),%xmm0
  81faf8:	movups 0x10(%rcx),%xmm1
  81fafc:	movups 0x20(%rcx),%xmm2
  81fb00:	lea    0x198(%rsp),%rax
  81fb08:	movups %xmm2,0x20(%rax)
  81fb0c:	movups %xmm1,0x10(%rax)
  81fb10:	movups %xmm0,(%rax)
  81fb13:	movups (%rdx),%xmm0
  81fb16:	movups %xmm0,0x30(%rax)
  81fb1a:	movdqu 0x40(%rcx),%xmm0
  81fb1f:	movdqu %xmm0,0x40(%rax)
  81fb24:	lea    0x180(%rsp),%rdi
  81fb2c:	call   8218a0 <gpui_gpu::renderer::compact_group>
  81fb31:	mov    %al,0x140(%rsp)
  81fb38:	mov    0x30(%rsp),%rax
  81fb3d:	test   %rax,%rax
  81fb40:	je     81fa19 <<gpui_gpu::renderer::RendererState>::render+0x1a09>
  81fb46:	mov    %rax,%rdx
  81fb49:	shl    $0x2,%rdx
  81fb4d:	movzbl 0x140(%rsp),%eax
  81fb55:	lea    0x0(,%rax,4),%esi
  81fb5c:	or     $0xfffffffffffffffa,%rsi
  81fb60:	xor    $0x1,%al
  81fb62:	movzbl %al,%eax
  81fb65:	lea    0x1(,%rax,4),%rcx
  81fb6d:	mov    %rcx,0x168(%rsp)
  81fb75:	mov    0x20(%rsp),%rcx
  81fb7a:	lea    (%rsi,%rcx,1),%edi
  81fb7d:	lea    (%rsi,%rax,4),%rax
  81fb81:	inc    %rax
  81fb84:	mov    %rax,0x330(%rsp)
  81fb8c:	add    %rax,%rcx
  81fb8f:	shl    $0x4,%rcx
  81fb93:	mov    %rsi,0x40(%rsp)
  81fb98:	shl    $0x4,%rsi
  81fb9c:	mov    %rsi,0x460(%rsp)
  81fba4:	mov    %rcx,0x18(%rsp)
  81fba9:	mov    %edi,0x10(%rsp)
  81fbad:	mov    0x340(%rsp),%rax
  81fbb5:	mov    %rdx,0x30(%rsp)
  81fbba:	mov    -0x4(%rax,%rdx,1),%edx
  81fbbe:	lea    0x180(%rsp),%rdi
  81fbc6:	mov    0x130(%rsp),%rsi
  81fbce:	call   81c8b0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fbd3:	movzbl 0x180(%rsp),%ecx
  81fbdb:	movzbl 0x181(%rsp),%eax
  81fbe3:	mov    %al,0xa8(%rsp)
  81fbea:	movzwl 0x182(%rsp),%eax
  81fbf2:	mov    %ax,0x60(%rsp)
  81fbf7:	movss  0x184(%rsp),%xmm4
  81fc00:	lea    0x188(%rsp),%rdx
  81fc08:	mov    0x10(%rdx),%rax
  81fc0c:	mov    %rax,0x360(%rsp)
  81fc14:	movups (%rdx),%xmm0
  81fc17:	movaps %xmm0,0x350(%rsp)
  81fc1f:	mov    0x1a0(%rsp),%rax
  81fc27:	mov    %rax,0x38(%rsp)
  81fc2c:	mov    0x1a8(%rsp),%r10d
  81fc34:	mov    0x1ac(%rsp),%r11d
  81fc3c:	movups 0x1b0(%rsp),%xmm0
  81fc44:	movaps %xmm0,0x90(%rsp)
  81fc4c:	mov    0x1b0(%rsp),%rax
  81fc54:	movsd  0x1c0(%rsp),%xmm5
  81fc5d:	lea    0x198(%rsp),%rdx
  81fc65:	movups 0x30(%rdx),%xmm0
  81fc69:	movaps %xmm0,0x470(%rsp)
  81fc71:	decq   0x3a8(%rsp)
  81fc79:	cmp    $0x1,%ecx
  81fc7c:	mov    %ecx,0xb0(%rsp)
  81fc83:	movaps %xmm5,0x80(%rsp)
  81fc8b:	je     81fd24 <<gpui_gpu::renderer::RendererState>::render+0x1d14>
  81fc91:	mov    %r11d,0x28(%rsp)
  81fc96:	mov    %r10d,0x100(%rsp)
  81fc9e:	movaps %xmm4,0x150(%rsp)
  81fca6:	cmp    $0x3,%ecx
  81fca9:	jne    81fda1 <<gpui_gpu::renderer::RendererState>::render+0x1d91>
  81fcaf:	mov    0x290(%rsp),%rax
  81fcb7:	mov    (%rax),%rdi
  81fcba:	test   %rdi,%rdi
  81fcbd:	je     820648 <<gpui_gpu::renderer::RendererState>::render+0x2638>
  81fcc3:	movzbl 0xa8(%rsp),%edx
  81fccb:	mov    0x38(%rsp),%rsi
  81fcd0:	call   8237c0 <<gpui_gpu::renderer::images::Images>::metadata>
  81fcd5:	mov    %eax,%ecx
  81fcd7:	shr    $0x20,%rax
  81fcdb:	mov    %eax,%edx
  81fcdd:	or     $0x10,%edx
  81fce0:	xorps  %xmm0,%xmm0
  81fce3:	movaps 0x150(%rsp),%xmm4
  81fceb:	ucomiss %xmm0,%xmm4
  81fcee:	cmovne %edx,%eax
  81fcf1:	cmovp  %edx,%eax
  81fcf4:	mov    0x28(%rsp),%r11d
  81fcf9:	mov    %r11d,%edx
  81fcfc:	shl    $0x10,%edx
  81fcff:	mov    0x100(%rsp),%r10d
  81fd07:	or     %r10d,%edx
  81fd0a:	mov    %ecx,0x124(%rsp)
  81fd11:	mov    %eax,0x128(%rsp)
  81fd18:	mov    %edx,0x12c(%rsp)
  81fd1f:	jmp    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1e43>
  81fd24:	movaps %xmm5,%xmm0
  81fd27:	movss  -0x770d63(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81fd2f:	mulss  %xmm3,%xmm0
  81fd33:	movaps %xmm4,%xmm1
  81fd36:	minss  %xmm0,%xmm1
  81fd3a:	movaps %xmm1,%xmm0
  81fd3d:	cmpunordss %xmm1,%xmm0
  81fd42:	movaps %xmm0,%xmm2
  81fd45:	andnps %xmm1,%xmm2
  81fd48:	andps  %xmm4,%xmm0
  81fd4b:	orps   %xmm2,%xmm0
  81fd4e:	movaps %xmm5,%xmm1
  81fd51:	shufps $0x55,%xmm5,%xmm1
  81fd55:	mulss  %xmm3,%xmm1
  81fd59:	movaps %xmm0,%xmm2
  81fd5c:	minss  %xmm1,%xmm2
  81fd60:	movaps %xmm2,%xmm1
  81fd63:	cmpunordss %xmm2,%xmm1
  81fd68:	andps  %xmm1,%xmm0
  81fd6b:	andnps %xmm2,%xmm1
  81fd6e:	orps   %xmm0,%xmm1
  81fd71:	movd   %xmm1,%eax
  81fd75:	and    $0xff800000,%eax
  81fd7a:	mov    $0x7f000000,%ecx
  81fd7f:	sub    %eax,%ecx
  81fd81:	movl   $0x40000000,0x124(%rsp)
  81fd8c:	movss  %xmm1,0x128(%rsp)
  81fd95:	mov    %ecx,0x12c(%rsp)
  81fd9c:	jmp    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1e43>
  81fda1:	cmp    $0x2,%cl
  81fda4:	jne    81fdf6 <<gpui_gpu::renderer::RendererState>::render+0x1de6>
  81fda6:	mov    0x360(%rsp),%rcx
  81fdae:	mov    %rcx,0x190(%rsp)
  81fdb6:	movaps 0x350(%rsp),%xmm0
  81fdbe:	movaps %xmm0,0x180(%rsp)
  81fdc6:	mov    0x38(%rsp),%rcx
  81fdcb:	mov    %rcx,0x198(%rsp)
  81fdd3:	mov    0x100(%rsp),%ecx
  81fdda:	mov    %ecx,0x1a0(%rsp)
  81fde1:	mov    0x28(%rsp),%ecx
  81fde5:	mov    %ecx,0x1a4(%rsp)
  81fdec:	mov    %rax,0x1a8(%rsp)
  81fdf4:	jmp    81fe02 <<gpui_gpu::renderer::RendererState>::render+0x1df2>
  81fdf6:	movq   $0x0,0x180(%rsp)
  81fe02:	movl   $0x0,0x2a8(%rsp)
  81fe0d:	movq   $0x0,0x2a0(%rsp)
  81fe19:	lea    0x124(%rsp),%rdi
  81fe21:	lea    0x180(%rsp),%rsi
  81fe29:	lea    0x2a0(%rsp),%rdx
  81fe31:	mov    0x288(%rsp),%rcx
  81fe39:	call   81b630 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fe3e:	movaps 0x150(%rsp),%xmm4
  81fe46:	mov    0x100(%rsp),%r10d
  81fe4e:	mov    0x28(%rsp),%r11d
  81fe53:	mov    0x20(%rsp),%rdx
  81fe58:	mov    0x330(%rsp),%rax
  81fe60:	lea    (%rax,%rdx,1),%rcx
  81fe64:	mov    0x8(%rsp),%rax
  81fe69:	mov    0x10(%rax),%rsi
  81fe6d:	cmp    %rsi,%rcx
  81fe70:	lea    0x180(%rsp),%rdi
  81fe78:	mov    0x10(%rsp),%r8d
  81fe7d:	mov    0x18(%rsp),%r9
  81fe82:	movapd 0x80(%rsp),%xmm3
  81fe8b:	jae    82066e <<gpui_gpu::renderer::RendererState>::render+0x265e>
  81fe91:	add    0x40(%rsp),%rdx
  81fe96:	mov    %rdx,0x20(%rsp)
  81fe9b:	mov    0x8(%rax),%rax
  81fe9f:	mov    0x12c(%rsp),%ecx
  81fea6:	mov    %ecx,0x8(%rax,%r9,1)
  81feab:	mov    0x124(%rsp),%rcx
  81feb3:	mov    %r8d,%edx
  81feb6:	or     $0x80000000,%edx
  81febc:	cmpb   $0x0,0x140(%rsp)
  81fec4:	cmovne %r8d,%edx
  81fec8:	mov    %rcx,(%rax,%r9,1)
  81fecc:	mov    %edx,0x29c(%rsp)
  81fed3:	movaps 0x370(%rsp),%xmm0
  81fedb:	movaps 0x380(%rsp),%xmm1
  81fee3:	movaps 0x390(%rsp),%xmm2
  81feeb:	lea    0x198(%rsp),%rax
  81fef3:	movups %xmm2,0x50(%rax)
  81fef7:	movups %xmm1,0x40(%rax)
  81fefb:	movups %xmm0,0x30(%rax)
  81feff:	movaps 0x3b0(%rsp),%xmm0
  81ff07:	movups %xmm0,0x60(%rax)
  81ff0b:	movaps 0x5a0(%rsp),%xmm0
  81ff13:	movups %xmm0,0x80(%rax)
  81ff1a:	movlpd %xmm3,0x1c0(%rsp)
  81ff23:	movaps 0x470(%rsp),%xmm0
  81ff2b:	movups %xmm0,0x70(%rax)
  81ff2f:	mov    0xb0(%rsp),%eax
  81ff36:	mov    %al,0x180(%rsp)
  81ff3d:	movzbl 0xa8(%rsp),%eax
  81ff45:	mov    %al,0x181(%rsp)
  81ff4c:	movzwl 0x60(%rsp),%eax
  81ff51:	mov    %ax,0x182(%rsp)
  81ff59:	movss  %xmm4,0x184(%rsp)
  81ff62:	mov    0x360(%rsp),%rax
  81ff6a:	lea    0x188(%rsp),%rcx
  81ff72:	mov    %rax,0x10(%rcx)
  81ff76:	movaps 0x350(%rsp),%xmm0
  81ff7e:	movups %xmm0,(%rcx)
  81ff81:	mov    0x38(%rsp),%rax
  81ff86:	mov    %rax,0x1a0(%rsp)
  81ff8e:	mov    %r10d,0x1a8(%rsp)
  81ff96:	mov    %r11d,0x1ac(%rsp)
  81ff9e:	movdqa 0x90(%rsp),%xmm0
  81ffa7:	movdqu %xmm0,0x1b0(%rsp)
  81ffb0:	mov    0x4b0(%rsp),%rax
  81ffb8:	mov    %rax,0x2a0(%rsp)
  81ffc0:	mov    0x450(%rsp),%rax
  81ffc8:	mov    %rax,0x2a8(%rsp)
  81ffd0:	mov    0x4a8(%rsp),%rax
  81ffd8:	mov    %rax,0x2b0(%rsp)
  81ffe0:	lea    0x3a8(%rsp),%rax
  81ffe8:	mov    %rax,0x2b8(%rsp)
  81fff0:	lea    0x29c(%rsp),%rax
  81fff8:	mov    %rax,0x2c0(%rsp)
  820000:	mov    0xa0(%rsp),%rsi
  820008:	lea    0x2a0(%rsp),%rdx
  820010:	call   81c4f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  820015:	mov    0x18(%rsp),%rcx
  82001a:	mov    0x10(%rsp),%edi
  82001e:	add    0x40(%rsp),%edi
  820022:	add    0x460(%rsp),%rcx
  82002a:	mov    0x30(%rsp),%rdx
  82002f:	add    $0xfffffffffffffffc,%rdx
  820033:	jne    81fba4 <<gpui_gpu::renderer::RendererState>::render+0x1b94>
  820039:	jmp    81fa19 <<gpui_gpu::renderer::RendererState>::render+0x1a09>
  82003e:	test   $0x1,%r13b
  820042:	je     820095 <<gpui_gpu::renderer::RendererState>::render+0x2085>
  820044:	movd   0x298(%rsp),%xmm0
  82004d:	movd   %xmm0,%eax
  820051:	test   %eax,%eax
  820053:	setns  %cl
  820056:	mov    %eax,%edx
  820058:	and    $0x7fffffff,%edx
  82005e:	add    $0xff800000,%edx
  820064:	cmp    $0x7f000000,%edx
  82006a:	setb   %dl
  82006d:	and    %cl,%dl
  82006f:	dec    %eax
  820071:	cmp    $0x7fffff,%eax
  820076:	setb   %al
  820079:	or     %dl,%al
  82007b:	movl   $0x2,0x11c(%rsp)
  820086:	movd   %xmm0,0x120(%rsp)
  82008f:	je     82063e <<gpui_gpu::renderer::RendererState>::render+0x262e>
  820095:	mov    0x170(%rsp),%r13
  82009d:	lea    0x18(%r13),%rax
  8200a1:	mov    %rax,0x18(%rsp)
  8200a6:	mov    0x178(%rsp),%rax
  8200ae:	add    $0x18,%rax
  8200b2:	xor    %ecx,%ecx
  8200b4:	cmp    $0x28,%r12d
  8200b8:	sete   %cl
  8200bb:	and    $0x1,%ebp
  8200be:	lea    0x0(%rbp,%rcx,4),%ecx
  8200c2:	or     0x11c(%rsp),%ecx
  8200c9:	movups (%rax),%xmm0
  8200cc:	movups %xmm0,0x2d8(%rsp)
  8200d4:	mov    %r14d,0x2c8(%rsp)
  8200dc:	mov    %r15d,0x2cc(%rsp)
  8200e4:	mov    0xa0(%rsp),%rax
  8200ec:	mov    %eax,0x2d0(%rsp)
  8200f3:	mov    %ecx,0x2d4(%rsp)
  8200fa:	movss  0x120(%rsp),%xmm0
  820103:	movss  %xmm0,0x2e8(%rsp)
  82010c:	movq   $0x0,0x2ec(%rsp)
  820118:	movl   $0x0,0x2f4(%rsp)
  820123:	mov    0x8(%rsp),%rbp
  820128:	lea    0x230(%rbp),%rsi
  82012f:	movq   $0x0,0x10(%rsp)
  820138:	lea    0x2c8(%rsp),%rcx
  820140:	mov    $0x30,%r8d
  820146:	mov    0x280(%rsp),%r12
  82014e:	mov    %r12,%rdi
  820151:	mov    %rsi,0x38(%rsp)
  820156:	xor    %edx,%edx
  820158:	call   *0x6610da(%rip)        # e81238 <_DYNAMIC+0x5d0>
  82015e:	mov    0x8(%rbp),%rcx
  820162:	mov    0x10(%rbp),%r8
  820166:	shl    $0x4,%r8
  82016a:	mov    0xc8(%rsp),%rdi
  820172:	mov    %r13,%rsi
  820175:	mov    %r12,%rdx
  820178:	call   81cb50 <<gpui_gpu::renderer::Buffer>::write>
  82017d:	lea    0x280(%rbp),%rdi
  820184:	mov    0x20(%rbp),%rcx
  820188:	mov    0x28(%rbp),%r8
  82018c:	shl    $0x3,%r8
  820190:	mov    %rdi,0xa8(%rsp)
  820198:	mov    %r13,%rsi
  82019b:	mov    %r12,%rdx
  82019e:	call   81cb50 <<gpui_gpu::renderer::Buffer>::write>
  8201a3:	lea    0x2a8(%rbp),%rdi
  8201aa:	mov    0x38(%rbp),%rcx
  8201ae:	mov    0x40(%rbp),%r8
  8201b2:	shl    $0x2,%r8
  8201b6:	mov    %rdi,0xa0(%rsp)
  8201be:	mov    %r13,%rsi
  8201c1:	mov    %r12,%rdx
  8201c4:	call   81cb50 <<gpui_gpu::renderer::Buffer>::write>
  8201c9:	lea    0x2d0(%rbp),%rdi
  8201d0:	mov    0x68(%rbp),%rcx
  8201d4:	mov    0x70(%rbp),%r8
  8201d8:	shl    $0x5,%r8
  8201dc:	mov    %rdi,0x20(%rsp)
  8201e1:	mov    %r13,%rsi
  8201e4:	mov    %r12,%rdx
  8201e7:	call   81cb50 <<gpui_gpu::renderer::Buffer>::write>
  8201ec:	cmpq   $0x0,0x328(%rbp)
  8201f4:	jne    820210 <<gpui_gpu::renderer::RendererState>::render+0x2200>
  8201f6:	mov    0x8(%rsp),%rax
  8201fb:	mov    0x10(%rax),%rax
  8201ff:	cmp    $0x1,%rax
  820203:	adc    $0x0,%rax
  820207:	shl    $0x4,%rax
  82020b:	mov    %rax,0x10(%rsp)
  820210:	mov    0x8(%rsp),%rsi
  820215:	mov    0x28(%rsi),%rdx
  820219:	mov    0x40(%rsi),%rax
  82021d:	cmp    $0x1,%rdx
  820221:	adc    $0x0,%rdx
  820225:	shl    $0x3,%rdx
  820229:	cmp    $0x1,%rax
  82022d:	adc    $0x0,%rax
  820231:	mov    0x70(%rsi),%rcx
  820235:	cmp    $0x1,%rcx
  820239:	adc    $0x0,%rcx
  82023d:	add    $0xc8,%rsi
  820244:	shl    $0x2,%rax
  820248:	shl    $0x5,%rcx
  82024c:	movq   $0x0,0x180(%rsp)
  820258:	mov    0x38(%rsp),%rdi
  82025d:	mov    %rdi,0x188(%rsp)
  820265:	movq   $0x0,0x1a8(%rsp)
  820271:	xorps  %xmm0,%xmm0
  820274:	movups %xmm0,0x190(%rsp)
  82027c:	movl   $0x0,0x1a0(%rsp)
  820287:	mov    0xc8(%rsp),%rdi
  82028f:	mov    %rdi,0x1b0(%rsp)
  820297:	movq   $0x0,0x1b8(%rsp)
  8202a3:	mov    0x10(%rsp),%rdi
  8202a8:	mov    %rdi,0x1c0(%rsp)
  8202b0:	movl   $0x1,0x1c8(%rsp)
  8202bb:	movq   $0x0,0x1d0(%rsp)
  8202c7:	mov    0xa8(%rsp),%rdi
  8202cf:	mov    %rdi,0x1d8(%rsp)
  8202d7:	movq   $0x0,0x1e0(%rsp)
  8202e3:	mov    %rdx,0x1e8(%rsp)
  8202eb:	movl   $0x2,0x1f0(%rsp)
  8202f6:	movq   $0x0,0x1f8(%rsp)
  820302:	mov    0xa0(%rsp),%rdx
  82030a:	mov    %rdx,0x200(%rsp)
  820312:	movq   $0x0,0x208(%rsp)
  82031e:	mov    %rax,0x210(%rsp)
  820326:	movl   $0x3,0x218(%rsp)
  820331:	movq   $0x4,0x220(%rsp)
  82033d:	mov    %rsi,0x228(%rsp)
  820345:	movl   $0x4,0x240(%rsp)
  820350:	movq   $0x0,0x248(%rsp)
  82035c:	mov    0x20(%rsp),%rax
  820361:	mov    %rax,0x250(%rsp)
  820369:	movq   $0x0,0x258(%rsp)
  820375:	mov    %rcx,0x260(%rsp)
  82037d:	movl   $0x5,0x268(%rsp)
  820388:	lea    -0x74b6f4(%rip),%rax        # d4c9b <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x13d>
  82038f:	mov    %rax,0x388(%rsp)
  820397:	movq   $0xa,0x390(%rsp)
  8203a3:	mov    0x18(%rsp),%rax
  8203a8:	mov    %rax,0x370(%rsp)
  8203b0:	lea    0x180(%rsp),%rax
  8203b8:	mov    %rax,0x378(%rsp)
  8203c0:	movq   $0x6,0x380(%rsp)
  8203cc:	lea    0x370(%rsp),%rsi
  8203d4:	mov    0x170(%rsp),%r12
  8203dc:	mov    %r12,%rdi
  8203df:	call   *0x660e5b(%rip)        # e81240 <_DYNAMIC+0x5d8>
  8203e5:	mov    %rax,%r13
  8203e8:	mov    %rax,0x2a0(%rsp)
  8203f0:	lea    0x2a0(%rsp),%rdx
  8203f8:	mov    %r12,%rdi
  8203fb:	mov    0x4a0(%rsp),%rsi
  820403:	call   81d1b0 <<gpui_gpu::renderer::GpuContext>::submit>
  820408:	mov    %rax,0x10(%rsp)
  82040d:	xor    %ebp,%ebp
  82040f:	mov    0x490(%rsp),%rax
  820417:	cmp    0x498(%rsp),%rax
  82041f:	setne  %bpl
  820423:	shl    $0x1f,%ebp
  820426:	or     %r14d,%ebp
  820429:	shl    $0x20,%r15
  82042d:	or     %r15,%rbp
  820430:	mov    (%rbx),%rax
  820433:	test   %rax,%rax
  820436:	je     820447 <<gpui_gpu::renderer::RendererState>::render+0x2437>
  820438:	lock decq (%rax)
  82043c:	jne    820447 <<gpui_gpu::renderer::RendererState>::render+0x2437>
  82043e:	mov    %rbx,%rdi
  820441:	call   *0x660d39(%rip)        # e81180 <_DYNAMIC+0x518>
  820447:	mov    0x8(%rsp),%rax
  82044c:	mov    %r13,0x330(%rax)
  820453:	mov    %rbp,0x338(%rax)
  82045a:	mov    0x10(%rax),%r8
  82045e:	mov    0x28(%rax),%rsi
  820462:	mov    0x70(%rax),%rcx
  820466:	mov    %rcx,0x18(%rsp)
  82046b:	shl    $0x4,%r8
  82046f:	mov    0xe0(%rsp),%rdx
  820477:	lea    (%r8,%rdx,4),%rdi
  82047b:	lea    (%rdi,%rsi,8),%rsi
  82047f:	mov    %rcx,%rdi
  820482:	shl    $0x5,%rdi
  820486:	lea    (%rdi,%rsi,1),%rcx
  82048a:	add    $0x30,%rcx
  82048e:	mov    %rcx,0x38(%rsp)
  820493:	mov    0x278(%rax),%rdi
  82049a:	add    0x250(%rax),%rdi
  8204a1:	add    0x2a0(%rax),%rdi
  8204a8:	add    0x2c8(%rax),%rdi
  8204af:	add    0x2f0(%rax),%rdi
  8204b6:	mov    0x308(%rax),%rsi
  8204bd:	add    0x310(%rax),%rsi
  8204c4:	mov    0x150(%rax),%r9d
  8204cb:	imul   %r9,%r9
  8204cf:	mov    0xf8(%rsp),%r11
  8204d7:	mov    %r11,%rcx
  8204da:	sub    %rdx,%rcx
  8204dd:	mov    0x78(%rsp),%r10
  8204e2:	mov    %r10,%r12
  8204e5:	mov    0x278(%rsp),%rbp
  8204ed:	sub    %rbp,%r12
  8204f0:	mov    0x160(%rax),%rbx
  8204f7:	inc    %rbx
  8204fa:	mov    $0xffffffffffffffff,%r14
  820501:	cmovne %rbx,%r14
  820505:	mov    (%rax),%rbx
  820508:	shl    $0x4,%rbx
  82050c:	mov    0x48(%rax),%r15
  820510:	add    0x30(%rax),%r15
  820514:	mov    0x18(%rax),%r13
  820518:	lea    (%rbx,%r13,8),%rbx
  82051c:	lea    (%rbx,%r15,4),%rbx
  820520:	mov    0x60(%rax),%r15
  820524:	shl    $0x5,%r15
  820528:	add    %rbx,%r15
  82052b:	mov    0x138(%rax),%rbx
  820532:	mov    0x130(%rax),%r13
  820539:	mov    %r14,0x160(%rax)
  820540:	mov    %r10,0x168(%rax)
  820547:	lea    (%r11,%r11,1),%r14
  82054b:	mov    %r14,0x170(%rax)
  820552:	movq   $0x1,0x178(%rax)
  82055d:	mov    %r10,0x180(%rax)
  820564:	mov    %rdx,0x188(%rax)
  82056b:	mov    %r11,0x190(%rax)
  820572:	mov    %rcx,0x198(%rax)
  820579:	mov    0xe8(%rsp),%rcx
  820581:	mov    %rcx,0x1a0(%rax)
  820588:	mov    0xf0(%rsp),%rcx
  820590:	mov    %rcx,0x1a8(%rax)
  820597:	mov    0xd0(%rsp),%rcx
  82059f:	mov    %rcx,0x1b0(%rax)
  8205a6:	mov    0x38(%rsp),%rcx
  8205ab:	mov    %rcx,0x1b8(%rax)
  8205b2:	mov    %r8,0x1c0(%rax)
  8205b9:	mov    0x270(%rsp),%rdx
  8205c1:	mov    %rdx,0x1c8(%rax)
  8205c8:	mov    %rbp,0x1d0(%rax)
  8205cf:	mov    %r12,0x1d8(%rax)
  8205d6:	mov    0x488(%rsp),%rcx
  8205de:	mov    %rcx,0x1e0(%rax)
  8205e5:	mov    %rdi,0x1e8(%rax)
  8205ec:	mov    %r9,0x1f0(%rax)
  8205f3:	add    %rbx,%r13
  8205f6:	mov    %rbx,0x1f8(%rax)
  8205fd:	mov    %r13,0x200(%rax)
  820604:	mov    %r15,0x208(%rax)
  82060b:	mov    0x18(%rsp),%rcx
  820610:	mov    %rcx,0x210(%rax)
  820617:	mov    %rsi,0x218(%rax)
  82061e:	movb   $0x0,0x220(%rax)
  820625:	mov    0x58(%rsp),%rdi
  82062a:	mov    0x10(%rsp),%rax
  82062f:	mov    %rax,0x8(%rdi)
  820633:	movl   $0xffffffff,(%rdi)
  820639:	jmp    81e121 <<gpui_gpu::renderer::RendererState>::render+0x111>
  82063e:	mov    0x58(%rsp),%rdi
  820643:	jmp    81e113 <<gpui_gpu::renderer::RendererState>::render+0x103>
  820648:	lea    0x60f071(%rip),%rdi        # e2f6c0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  82064f:	call   *0x660bf3(%rip)        # e81248 <_DYNAMIC+0x5e0>
  820655:	lea    -0x74b9dc(%rip),%rdi        # d4c80 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82065c:	lea    0x60f045(%rip),%rdx        # e2f6a8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  820663:	mov    $0x37,%esi
  820668:	call   *0x660912(%rip)        # e80f80 <_DYNAMIC+0x318>
  82066e:	mov    0x40(%rsp),%rdi
  820673:	add    0x168(%rsp),%rdi
  82067b:	add    %rdx,%rdi
  82067e:	lea    0x60f053(%rip),%rdx        # e2f6d8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  820685:	call   *0x660ad5(%rip)        # e81160 <_DYNAMIC+0x4f8>
  82068b:	mov    %rax,%r14
  82068e:	mov    0x8(%rsp),%rax
  820693:	mov    %r13,0x330(%rax)
  82069a:	mov    %rbp,0x338(%rax)
  8206a1:	mov    %r14,%rdi
  8206a4:	call   e2d990 <_Unwind_Resume@plt>
  8206a9:	mov    %rax,%r14
  8206ac:	lock decq 0x0(%r13)
  8206b1:	jne    8206d3 <<gpui_gpu::renderer::RendererState>::render+0x26c3>
  8206b3:	lea    0x2a0(%rsp),%rdi
  8206bb:	call   *0x660abf(%rip)        # e81180 <_DYNAMIC+0x518>
  8206c1:	jmp    8206d3 <<gpui_gpu::renderer::RendererState>::render+0x26c3>
  8206c3:	call   *0x6607ef(%rip)        # e80eb8 <_DYNAMIC+0x250>
  8206c9:	mov    %rax,%r14
  8206cc:	movq   $0x0,(%rbx)
  8206d3:	mov    %r14,%rdi
  8206d6:	call   e2d990 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4531 frame=840

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008206e0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  8206e0:	push   %rbp
  8206e1:	push   %r15
  8206e3:	push   %r14
  8206e5:	push   %r13
  8206e7:	push   %r12
  8206e9:	push   %rbx
  8206ea:	sub    $0x318,%rsp
  8206f1:	movss  0x88(%rdx),%xmm3
  8206f9:	movss  -0x7716e5(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820701:	movaps %xmm3,%xmm1
  820704:	subss  %xmm0,%xmm1
  820708:	cvttss2si %xmm1,%rax
  82070d:	cvttss2si %xmm3,%r10
  820712:	mov    %r10,%rbp
  820715:	sar    $0x3f,%rbp
  820719:	and    %rax,%rbp
  82071c:	or     %r10,%rbp
  82071f:	xor    %eax,%eax
  820721:	xorps  %xmm1,%xmm1
  820724:	ucomiss %xmm1,%xmm3
  820727:	cmovb  %rax,%rbp
  82072b:	movss  0x90(%rdx),%xmm4
  820733:	movss  -0x77171b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82073b:	ucomiss %xmm2,%xmm3
  82073e:	mov    $0xffffffffffffffff,%r14
  820745:	cmova  %r14,%rbp
  820749:	movaps %xmm4,%xmm3
  82074c:	subss  %xmm0,%xmm3
  820750:	cvttss2si %xmm3,%r10
  820755:	cvttss2si %xmm4,%r11
  82075a:	mov    %r11,%rbx
  82075d:	sar    $0x3f,%rbx
  820761:	and    %r10,%rbx
  820764:	or     %r11,%rbx
  820767:	ucomiss %xmm1,%xmm4
  82076a:	cmovb  %rax,%rbx
  82076e:	ucomiss %xmm2,%xmm4
  820771:	cmova  %r14,%rbx
  820775:	movss  0x8c(%rdx),%xmm3
  82077d:	add    %rbp,%rbx
  820780:	dec    %rbx
  820783:	shr    $0x4,%rbx
  820787:	shr    $0x4,%rbp
  82078b:	mov    %rbx,%r13
  82078e:	sub    %rbp,%r13
  820791:	inc    %r13
  820794:	movaps %xmm3,%xmm4
  820797:	subss  %xmm0,%xmm4
  82079b:	cvttss2si %xmm4,%r11
  8207a0:	cvttss2si %xmm3,%r10
  8207a5:	mov    %r10,%r15
  8207a8:	sar    $0x3f,%r15
  8207ac:	and    %r11,%r15
  8207af:	or     %r10,%r15
  8207b2:	ucomiss %xmm1,%xmm3
  8207b5:	cmovb  %rax,%r15
  8207b9:	ucomiss %xmm2,%xmm3
  8207bc:	movss  0x94(%rdx),%xmm3
  8207c4:	cmova  %r14,%r15
  8207c8:	movaps %xmm3,%xmm4
  8207cb:	subss  %xmm0,%xmm4
  8207cf:	cvttss2si %xmm4,%r12
  8207d4:	cvttss2si %xmm3,%r10
  8207d9:	mov    %r10,%r11
  8207dc:	sar    $0x3f,%r11
  8207e0:	and    %r12,%r11
  8207e3:	or     %r10,%r11
  8207e6:	ucomiss %xmm1,%xmm3
  8207e9:	cmovb  %rax,%r11
  8207ed:	ucomiss %xmm2,%xmm3
  8207f0:	cmova  %r14,%r11
  8207f4:	mov    %r15,%r14
  8207f7:	lea    (%r15,%r11,1),%r10
  8207fb:	dec    %r10
  8207fe:	shr    $0x4,%r10
  820802:	shr    $0x4,%r14
  820806:	mov    %r10,%r12
  820809:	sub    %r14,%r12
  82080c:	inc    %r12
  82080f:	imul   %r13,%r12
  820813:	mov    0x368(%rsp),%r11
  82081b:	add    %r12,%r11
  82081e:	setb   %al
  820821:	cmp    $0x400001,%r11
  820828:	setae  %r15b
  82082c:	or     %al,%r15b
  82082f:	mov    $0x6,%eax
  820834:	jne    820936 <<gpui_gpu::renderer::RendererState>::bin_draw+0x256>
  82083a:	mov    %r12,0x1e8(%rsp)
  820842:	mov    %r11,0x198(%rsp)
  82084a:	mov    %rdi,0x1a0(%rsp)
  820852:	cmpb   $0x0,(%rdx)
  820855:	sete   %al
  820858:	and    0x340(%rsi),%al
  82085e:	movl   $0x0,0x4(%rsp)
  820866:	cmp    $0x1,%al
  820868:	jne    8208f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  82086e:	movss  0xa4(%rdx),%xmm0
  820876:	ucomiss -0x771a9d(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82087d:	jne    8208f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  82087f:	jp     8208f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  820881:	mov    0x98(%rdx),%edi
  820887:	test   %edi,%edi
  820889:	jns    82089b <<gpui_gpu::renderer::RendererState>::bin_draw+0x1bb>
  82088b:	and    $0x7f800000,%edi
  820891:	dec    %edi
  820893:	cmp    $0x7f7fffff,%edi
  820899:	jae    8208f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  82089b:	mov    0x9c(%rdx),%edi
  8208a1:	test   %edi,%edi
  8208a3:	jns    8208b5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d5>
  8208a5:	and    $0x7f800000,%edi
  8208ab:	dec    %edi
  8208ad:	cmp    $0x7f7ffffe,%edi
  8208b3:	ja     8208f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8208b5:	mov    0xa0(%rdx),%edi
  8208bb:	test   %edi,%edi
  8208bd:	jns    8208cf <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ef>
  8208bf:	and    $0x7f800000,%edi
  8208c5:	dec    %edi
  8208c7:	cmp    $0x7f7ffffe,%edi
  8208cd:	ja     8208f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8208cf:	movd   %xmm0,%edi
  8208d3:	test   %edi,%edi
  8208d5:	jns    8208e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8208d7:	and    $0x7f800000,%edi
  8208dd:	dec    %edi
  8208df:	cmp    $0x7f7ffffe,%edi
  8208e5:	ja     8208f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8208e7:	mov    $0x1,%dil
  8208ea:	mov    %edi,0x4(%rsp)
  8208ee:	jmp    8208f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8208f0:	movl   $0x0,0x4(%rsp)
  8208f8:	mov    %rcx,0xe0(%rsp)
  820900:	mov    %r8d,0xbc(%rsp)
  820908:	mov    %r9,0xa8(%rsp)
  820910:	mov    %rdx,0xe8(%rsp)
  820918:	cmp    %r14,%r10
  82091b:	jae    82094a <<gpui_gpu::renderer::RendererState>::bin_draw+0x26a>
  82091d:	mov    0x1a0(%rsp),%rdi
  820925:	mov    0x198(%rsp),%rax
  82092d:	mov    %rax,0x8(%rdi)
  820931:	mov    $0xffffffff,%eax
  820936:	mov    %eax,(%rdi)
  820938:	add    $0x318,%rsp
  82093f:	pop    %rbx
  820940:	pop    %r12
  820942:	pop    %r13
  820944:	pop    %r14
  820946:	pop    %r15
  820948:	pop    %rbp
  820949:	ret
  82094a:	cmp    %rbp,%rbx
  82094d:	jae    820966 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  82094f:	nop
  820950:	mov    %r14,%rax
  820953:	cmp    %r10,%r14
  820956:	adc    $0x0,%r14
  82095a:	cmp    %r10,%rax
  82095d:	jae    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82095f:	cmp    %r10,%r14
  820962:	jbe    820950 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  820964:	jmp    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  820966:	mov    0x350(%rsp),%r13
  82096e:	mov    0x20(%rsi),%r15
  820972:	mov    0x28(%rsi),%r9
  820976:	test   %al,%al
  820978:	je     8217d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  82097e:	mov    0xe0(%rsp),%rax
  820986:	movd   %eax,%xmm0
  82098a:	shr    $0x20,%rax
  82098e:	mov    0xe8(%rsp),%rcx
  820996:	movss  0x78(%rcx),%xmm1
  82099b:	cvtss2sd %xmm1,%xmm12
  8209a0:	movss  0x80(%rcx),%xmm1
  8209a8:	movss  0x7c(%rcx),%xmm2
  8209ad:	xorps  %xmm3,%xmm3
  8209b0:	cvtss2sd %xmm2,%xmm3
  8209b4:	movss  0x84(%rcx),%xmm2
  8209bc:	cvtss2sd %xmm1,%xmm1
  8209c0:	addsd  %xmm12,%xmm1
  8209c5:	movsd  %xmm1,0x1d8(%rsp)
  8209ce:	xorps  %xmm1,%xmm1
  8209d1:	cvtss2sd %xmm2,%xmm1
  8209d5:	movsd  %xmm3,0x1e0(%rsp)
  8209de:	addsd  %xmm3,%xmm1
  8209e2:	movsd  %xmm1,0x1c8(%rsp)
  8209eb:	movsd  0x48(%rcx),%xmm3
  8209f0:	movsd  0x58(%rcx),%xmm4
  8209f5:	movsd  0x68(%rcx),%xmm5
  8209fa:	movss  0x38(%rcx),%xmm1
  8209ff:	movss  0x40(%rcx),%xmm2
  820a04:	cvtss2sd %xmm1,%xmm1
  820a08:	cvtss2sd %xmm2,%xmm2
  820a0c:	movaps -0x775be3(%rip),%xmm6        # aae30 <GCC_except_table0+0x6c>
  820a13:	movaps %xmm1,0x90(%rsp)
  820a1b:	andps  %xmm6,%xmm1
  820a1e:	movaps %xmm1,0x80(%rsp)
  820a26:	movaps %xmm2,0x60(%rsp)
  820a2b:	andps  %xmm6,%xmm2
  820a2e:	movaps %xmm2,0x70(%rsp)
  820a33:	cvtss2sd %xmm0,%xmm0
  820a37:	movsd  %xmm0,0x18(%rsp)
  820a3d:	movaps %xmm3,%xmm0
  820a40:	andps  %xmm6,%xmm0
  820a43:	movaps %xmm0,0x290(%rsp)
  820a4b:	movaps %xmm4,%xmm0
  820a4e:	andps  %xmm6,%xmm0
  820a51:	movaps %xmm0,0x270(%rsp)
  820a59:	movaps %xmm5,%xmm0
  820a5c:	andps  %xmm6,%xmm0
  820a5f:	movaps %xmm0,0x130(%rsp)
  820a67:	movss  0x3c(%rcx),%xmm0
  820a6c:	xorps  %xmm1,%xmm1
  820a6f:	cvtss2sd %xmm0,%xmm1
  820a73:	movss  0x44(%rcx),%xmm0
  820a78:	cvtss2sd %xmm0,%xmm0
  820a7c:	movaps %xmm1,0x50(%rsp)
  820a81:	andps  %xmm6,%xmm1
  820a84:	movaps %xmm1,0x40(%rsp)
  820a89:	movaps %xmm0,0x20(%rsp)
  820a8e:	andps  %xmm6,%xmm0
  820a91:	movaps %xmm0,0x30(%rsp)
  820a96:	movd   %eax,%xmm0
  820a9a:	cvtss2sd %xmm0,%xmm0
  820a9e:	movsd  %xmm0,0x10(%rsp)
  820aa4:	movsd  0x50(%rcx),%xmm1
  820aa9:	movaps %xmm1,%xmm0
  820aac:	andps  %xmm6,%xmm0
  820aaf:	movaps %xmm0,0x210(%rsp)
  820ab7:	movsd  0x60(%rcx),%xmm2
  820abc:	movaps %xmm2,%xmm0
  820abf:	andps  %xmm6,%xmm0
  820ac2:	movaps %xmm0,0x1f0(%rsp)
  820aca:	movsd  0x70(%rcx),%xmm7
  820acf:	andps  %xmm7,%xmm6
  820ad2:	movaps %xmm6,0x100(%rsp)
  820ada:	mov    0x58(%rsi),%rax
  820ade:	mov    %rax,0xd8(%rsp)
  820ae6:	mov    0x50(%rsi),%rax
  820aea:	mov    %rax,0x1d0(%rsp)
  820af2:	movaps %xmm3,0x2a0(%rsp)
  820afa:	movaps %xmm3,%xmm0
  820afd:	movaps %xmm4,0x280(%rsp)
  820b05:	movlhps %xmm4,%xmm0
  820b08:	cvtpd2ps %xmm0,%xmm0
  820b0c:	movaps %xmm1,0x220(%rsp)
  820b14:	cvtsd2ss %xmm1,%xmm1
  820b18:	cvtss2sd %xmm1,%xmm1
  820b1c:	cvtps2pd %xmm0,%xmm3
  820b1f:	movaps %xmm2,0x200(%rsp)
  820b27:	xorps  %xmm0,%xmm0
  820b2a:	cvtsd2ss %xmm2,%xmm0
  820b2e:	xorps  %xmm2,%xmm2
  820b31:	cvtss2sd %xmm0,%xmm2
  820b35:	movaps %xmm5,0x140(%rsp)
  820b3d:	xorps  %xmm0,%xmm0
  820b40:	cvtsd2ss %xmm5,%xmm0
  820b44:	cvtss2sd %xmm0,%xmm4
  820b48:	movaps %xmm7,0xf0(%rsp)
  820b50:	xorps  %xmm0,%xmm0
  820b53:	cvtsd2ss %xmm7,%xmm0
  820b57:	mov    0xa8(%rsp),%rax
  820b5f:	inc    %eax
  820b61:	mov    %rax,0xa8(%rsp)
  820b69:	cvtss2sd %xmm0,%xmm0
  820b6d:	movaps -0x775d44(%rip),%xmm5        # aae30 <GCC_except_table0+0x6c>
  820b74:	movaps %xmm3,%xmm6
  820b77:	andps  %xmm5,%xmm6
  820b7a:	movaps %xmm4,0x160(%rsp)
  820b82:	andps  %xmm5,%xmm4
  820b85:	movaps %xmm4,0x150(%rsp)
  820b8d:	movaps %xmm1,0x260(%rsp)
  820b95:	andps  %xmm5,%xmm1
  820b98:	movaps %xmm1,0x250(%rsp)
  820ba0:	movaps %xmm2,0x240(%rsp)
  820ba8:	andps  %xmm5,%xmm2
  820bab:	movaps %xmm2,0x230(%rsp)
  820bb3:	movaps %xmm0,0x120(%rsp)
  820bbb:	andps  %xmm0,%xmm5
  820bbe:	movaps %xmm5,0x110(%rsp)
  820bc6:	movaps %xmm3,0x2c0(%rsp)
  820bce:	movhlps %xmm3,%xmm3
  820bd1:	movaps %xmm3,0x2f0(%rsp)
  820bd9:	mov    $0x2,%r11b
  820bdc:	xor    %edx,%edx
  820bde:	mov    %r14,%rax
  820be1:	movaps %xmm6,0x2b0(%rsp)
  820be9:	pshufd $0xee,%xmm6,%xmm0
  820bee:	movdqa %xmm0,0x2e0(%rsp)
  820bf7:	movsd  %xmm12,0x8(%rsp)
  820bfe:	mov    %rbp,0x1b0(%rsp)
  820c06:	mov    %r10,0x1a8(%rsp)
  820c0e:	xchg   %ax,%ax
  820c10:	cmp    %r10,%r14
  820c13:	adc    $0x0,%rax
  820c17:	mov    %rax,0x1b8(%rsp)
  820c1f:	mov    %r14,0x1c0(%rsp)
  820c27:	imul   %r13,%r14
  820c2b:	mov    %rbp,%r10
  820c2e:	mov    0x360(%rsp),%r8d
  820c36:	mov    0x358(%rsp),%ecx
  820c3d:	jmp    820c60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820c3f:	cmp    %r9,%r12
  820c42:	jae    821835 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820c48:	incl   0x4(%r15,%r12,8)
  820c4d:	mov    $0x1,%dl
  820c4f:	cmp    %rbx,%r10
  820c52:	jb     820e23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820c58:	jmp    821790 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820c5d:	nopl   (%rax)
  820c60:	cmp    %rbx,%r10
  820c63:	adc    $0x0,%rbp
  820c67:	lea    (%r10,%r14,1),%r12
  820c6b:	cmpb   $0x0,0x4(%rsp)
  820c70:	jne    820c87 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a7>
  820c72:	cmp    %r9,%r12
  820c75:	jae    821855 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1175>
  820c7b:	testb  $0x40,0x7(%r15,%r12,8)
  820c81:	je     820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820c87:	cmpq   $0x2,0x1e8(%rsp)
  820c90:	setae  %al
  820c93:	and    %dl,%al
  820c95:	cmp    $0x1,%al
  820c97:	jne    820d72 <<gpui_gpu::renderer::RendererState>::bin_draw+0x692>
  820c9d:	cmp    $0x2,%r11b
  820ca1:	jne    820d0c <<gpui_gpu::renderer::RendererState>::bin_draw+0x62c>
  820ca3:	mov    %r10,0xb0(%rsp)
  820cab:	mov    0xe8(%rsp),%rdi
  820cb3:	mov    0xe0(%rsp),%rsi
  820cbb:	mov    %r13,%rdx
  820cbe:	mov    %rbp,0xc0(%rsp)
  820cc6:	mov    %rbx,%rbp
  820cc9:	mov    %r14,%rbx
  820ccc:	mov    %r15,%r14
  820ccf:	mov    %r9,%r15
  820cd2:	call   8257d0 <gpui_gpu::renderer::coverage::whole>
  820cd7:	mov    0xb0(%rsp),%r10
  820cdf:	movsd  0x8(%rsp),%xmm12
  820ce6:	mov    0x360(%rsp),%r8d
  820cee:	mov    %r15,%r9
  820cf1:	mov    %r14,%r15
  820cf4:	mov    %rbx,%r14
  820cf7:	mov    %rbp,%rbx
  820cfa:	mov    0xc0(%rsp),%rbp
  820d02:	mov    0x358(%rsp),%ecx
  820d09:	mov    %eax,%r11d
  820d0c:	test   $0x1,%r11b
  820d10:	mov    $0x1,%r11b
  820d13:	je     820d6f <<gpui_gpu::renderer::RendererState>::bin_draw+0x68f>
  820d15:	cmpb   $0x0,0x4(%rsp)
  820d1a:	je     820c3f <<gpui_gpu::renderer::RendererState>::bin_draw+0x55f>
  820d20:	cmp    %r9,%r12
  820d23:	jae    821880 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11a0>
  820d29:	mov    0xbc(%rsp),%eax
  820d30:	mov    %eax,(%r15,%r12,8)
  820d34:	movl   $0x40000001,0x4(%r15,%r12,8)
  820d3d:	cmp    0xd8(%rsp),%r12
  820d45:	jae    821868 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1188>
  820d4b:	mov    0xa8(%rsp),%rax
  820d53:	mov    0x1d0(%rsp),%rdx
  820d5b:	mov    %eax,(%rdx,%r12,4)
  820d5f:	mov    $0x1,%dl
  820d61:	cmp    %rbx,%r10
  820d64:	jb     820e23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820d6a:	jmp    821790 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820d6f:	xor    %r11d,%r11d
  820d72:	test   %r13,%r13
  820d75:	je     821848 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1168>
  820d7b:	mov    %r12,%rax
  820d7e:	shr    $0x20,%rax
  820d82:	je     820d90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b0>
  820d84:	mov    %r12,%rax
  820d87:	xor    %edx,%edx
  820d89:	div    %r13
  820d8c:	jmp    820d98 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b8>
  820d8e:	xchg   %ax,%ax
  820d90:	mov    %r12d,%eax
  820d93:	xor    %edx,%edx
  820d95:	div    %r13d
  820d98:	shl    $0x4,%edx
  820d9b:	shl    $0x4,%eax
  820d9e:	lea    0x10(%rdx),%esi
  820da1:	cmp    %esi,%ecx
  820da3:	cmovb  %ecx,%esi
  820da6:	lea    0x10(%rax),%edi
  820da9:	cmp    %edi,%r8d
  820dac:	cmovb  %r8d,%edi
  820db0:	xorps  %xmm2,%xmm2
  820db3:	cvtsi2sd %edx,%xmm2
  820db7:	mov    $0x1,%dl
  820db9:	ucomisd %xmm2,%xmm12
  820dbe:	ja     820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820dc0:	mov    %eax,%eax
  820dc2:	xorps  %xmm3,%xmm3
  820dc5:	cvtsi2sd %rax,%xmm3
  820dca:	movsd  0x1e0(%rsp),%xmm0
  820dd3:	ucomisd %xmm3,%xmm0
  820dd7:	ja     820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820dd9:	xorps  %xmm0,%xmm0
  820ddc:	cvtsi2sd %esi,%xmm0
  820de0:	ucomisd 0x1d8(%rsp),%xmm0
  820de9:	ja     820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820deb:	xorps  %xmm1,%xmm1
  820dee:	cvtsi2sd %edi,%xmm1
  820df2:	ucomisd 0x1c8(%rsp),%xmm1
  820dfb:	jbe    820e34 <<gpui_gpu::renderer::RendererState>::bin_draw+0x754>
  820dfd:	nopl   (%rax)
  820e00:	cmp    %r9,%r12
  820e03:	jae    821835 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820e09:	mov    0x4(%r15,%r12,8),%eax
  820e0e:	inc    %eax
  820e10:	and    $0xbfffffff,%eax
  820e15:	mov    %eax,0x4(%r15,%r12,8)
  820e1a:	cmp    %rbx,%r10
  820e1d:	jae    821790 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820e23:	mov    %rbp,%r10
  820e26:	cmp    %rbx,%rbp
  820e29:	jbe    820c60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820e2f:	jmp    821790 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820e34:	unpcklpd %xmm3,%xmm2
  820e38:	addpd  -0x773d00(%rip),%xmm2        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820e40:	movapd %xmm2,%xmm3
  820e44:	mulpd  0x2c0(%rsp),%xmm3
  820e4d:	movapd %xmm3,%xmm11
  820e52:	unpckhpd %xmm3,%xmm11
  820e57:	movapd %xmm3,%xmm5
  820e5b:	addsd  %xmm11,%xmm5
  820e60:	addsd  0x160(%rsp),%xmm5
  820e69:	subsd  0x90(%rsp),%xmm5
  820e72:	movapd 0x2b0(%rsp),%xmm8
  820e7c:	mulpd  %xmm2,%xmm8
  820e81:	movapd %xmm8,%xmm4
  820e86:	unpckhpd %xmm8,%xmm4
  820e8b:	movapd %xmm8,%xmm6
  820e90:	addsd  %xmm4,%xmm6
  820e94:	addsd  0x150(%rsp),%xmm6
  820e9d:	addsd  0x80(%rsp),%xmm6
  820ea6:	addsd  0x70(%rsp),%xmm6
  820eac:	addsd  -0x7715d4(%rip),%xmm6        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820eb4:	mulsd  -0x77165c(%rip),%xmm6        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ebc:	addsd  0x18(%rsp),%xmm6
  820ec2:	ucomisd %xmm5,%xmm6
  820ec6:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820ecc:	movapd 0x60(%rsp),%xmm7
  820ed2:	subsd  %xmm5,%xmm7
  820ed6:	ucomisd %xmm7,%xmm6
  820eda:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820ee0:	movapd %xmm2,%xmm13
  820ee5:	unpckhpd %xmm2,%xmm13
  820eea:	movapd 0x280(%rsp),%xmm15
  820ef4:	mulsd  %xmm13,%xmm15
  820ef9:	movapd 0x270(%rsp),%xmm14
  820f03:	mulsd  %xmm13,%xmm14
  820f08:	movapd 0x2a0(%rsp),%xmm5
  820f11:	mulsd  %xmm2,%xmm5
  820f15:	movapd %xmm5,%xmm6
  820f19:	addsd  %xmm15,%xmm6
  820f1e:	addsd  0x140(%rsp),%xmm6
  820f27:	subsd  0x90(%rsp),%xmm6
  820f30:	movapd 0x290(%rsp),%xmm7
  820f39:	mulsd  %xmm2,%xmm7
  820f3d:	movapd %xmm7,%xmm9
  820f42:	addsd  %xmm14,%xmm9
  820f47:	addsd  0x130(%rsp),%xmm9
  820f51:	addsd  0x80(%rsp),%xmm9
  820f5b:	addsd  0x70(%rsp),%xmm9
  820f62:	addsd  -0x77168b(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f6b:	mulsd  -0x771134(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f74:	ucomisd %xmm6,%xmm9
  820f79:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820f7f:	movapd 0x60(%rsp),%xmm10
  820f86:	subsd  %xmm6,%xmm10
  820f8b:	ucomisd %xmm10,%xmm9
  820f90:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820f96:	movapd %xmm13,%xmm9
  820f9b:	mulsd  0x240(%rsp),%xmm9
  820fa5:	movapd %xmm13,%xmm12
  820faa:	mulsd  0x230(%rsp),%xmm12
  820fb4:	movapd %xmm2,%xmm10
  820fb9:	mulsd  0x260(%rsp),%xmm10
  820fc3:	movapd %xmm10,%xmm6
  820fc8:	movapd %xmm9,0xc0(%rsp)
  820fd2:	addsd  %xmm9,%xmm6
  820fd7:	addsd  0x120(%rsp),%xmm6
  820fe0:	subsd  0x50(%rsp),%xmm6
  820fe6:	movapd %xmm2,%xmm9
  820feb:	mulsd  0x250(%rsp),%xmm9
  820ff5:	movsd  %xmm9,0xb0(%rsp)
  820fff:	addsd  %xmm12,%xmm9
  821004:	addsd  0x110(%rsp),%xmm9
  82100e:	addsd  0x40(%rsp),%xmm9
  821015:	addsd  0x30(%rsp),%xmm9
  82101c:	addsd  -0x771745(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821025:	mulsd  -0x7717ce(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82102e:	addsd  0x10(%rsp),%xmm9
  821035:	ucomisd %xmm6,%xmm9
  82103a:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821040:	movsd  %xmm10,0x190(%rsp)
  82104a:	movapd 0x20(%rsp),%xmm10
  821051:	subsd  %xmm6,%xmm10
  821056:	ucomisd %xmm10,%xmm9
  82105b:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821061:	movapd 0x200(%rsp),%xmm9
  82106b:	mulsd  %xmm13,%xmm9
  821070:	mulsd  0x1f0(%rsp),%xmm13
  82107a:	movapd 0x220(%rsp),%xmm10
  821084:	mulsd  %xmm2,%xmm10
  821089:	movapd %xmm10,%xmm6
  82108e:	movapd %xmm9,0x170(%rsp)
  821098:	addsd  %xmm9,%xmm6
  82109d:	addsd  0xf0(%rsp),%xmm6
  8210a6:	subsd  0x50(%rsp),%xmm6
  8210ac:	mulsd  0x210(%rsp),%xmm2
  8210b5:	movapd %xmm2,%xmm9
  8210ba:	addsd  %xmm13,%xmm9
  8210bf:	addsd  0x100(%rsp),%xmm9
  8210c9:	addsd  0x40(%rsp),%xmm9
  8210d0:	addsd  0x30(%rsp),%xmm9
  8210d7:	addsd  -0x771800(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210e0:	mulsd  -0x7712a9(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210e9:	ucomisd %xmm6,%xmm9
  8210ee:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8210f4:	movapd %xmm10,0x300(%rsp)
  8210fe:	movapd 0x20(%rsp),%xmm10
  821105:	subsd  %xmm6,%xmm10
  82110a:	ucomisd %xmm10,%xmm9
  82110f:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821115:	addsd  -0x771b35(%rip),%xmm0        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82111d:	movapd %xmm0,%xmm9
  821122:	mulsd  0x2c0(%rsp),%xmm9
  82112c:	addsd  %xmm9,%xmm11
  821131:	addsd  0x160(%rsp),%xmm11
  82113b:	subsd  0x90(%rsp),%xmm11
  821145:	movapd 0x2b0(%rsp),%xmm10
  82114f:	mulsd  %xmm0,%xmm10
  821154:	addsd  %xmm10,%xmm4
  821159:	addsd  0x150(%rsp),%xmm4
  821162:	addsd  0x80(%rsp),%xmm4
  82116b:	addsd  0x70(%rsp),%xmm4
  821171:	addsd  -0x771899(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821179:	mulsd  -0x771921(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821181:	addsd  0x18(%rsp),%xmm4
  821187:	ucomisd %xmm11,%xmm4
  82118c:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821192:	movapd 0x60(%rsp),%xmm6
  821198:	subsd  %xmm11,%xmm6
  82119d:	ucomisd %xmm6,%xmm4
  8211a1:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8211a7:	movapd 0x2a0(%rsp),%xmm6
  8211b0:	mulsd  %xmm0,%xmm6
  8211b4:	addsd  %xmm6,%xmm15
  8211b9:	addsd  0x140(%rsp),%xmm15
  8211c3:	subsd  0x90(%rsp),%xmm15
  8211cd:	movapd 0x290(%rsp),%xmm11
  8211d7:	mulsd  %xmm0,%xmm11
  8211dc:	addsd  %xmm11,%xmm14
  8211e1:	addsd  0x130(%rsp),%xmm14
  8211eb:	addsd  0x80(%rsp),%xmm14
  8211f5:	addsd  0x70(%rsp),%xmm14
  8211fc:	addsd  -0x771925(%rip),%xmm14        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821205:	mulsd  -0x7713ce(%rip),%xmm14        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82120e:	ucomisd %xmm15,%xmm14
  821213:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821219:	movapd 0x60(%rsp),%xmm4
  82121f:	subsd  %xmm15,%xmm4
  821224:	ucomisd %xmm4,%xmm14
  821229:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  82122f:	movapd %xmm0,%xmm14
  821234:	mulsd  0x260(%rsp),%xmm14
  82123e:	movapd 0xc0(%rsp),%xmm4
  821247:	addsd  %xmm14,%xmm4
  82124c:	addsd  0x120(%rsp),%xmm4
  821255:	subsd  0x50(%rsp),%xmm4
  82125b:	movapd %xmm0,%xmm15
  821260:	mulsd  0x250(%rsp),%xmm15
  82126a:	addsd  %xmm15,%xmm12
  82126f:	addsd  0x110(%rsp),%xmm12
  821279:	addsd  0x40(%rsp),%xmm12
  821280:	addsd  0x30(%rsp),%xmm12
  821287:	addsd  -0x7719b0(%rip),%xmm12        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821290:	mulsd  -0x771a39(%rip),%xmm12        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821299:	addsd  0x10(%rsp),%xmm12
  8212a0:	ucomisd %xmm4,%xmm12
  8212a5:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8212ab:	movsd  %xmm15,0xc0(%rsp)
  8212b5:	movapd %xmm4,%xmm15
  8212ba:	movapd 0x20(%rsp),%xmm4
  8212c0:	subsd  %xmm15,%xmm4
  8212c5:	ucomisd %xmm4,%xmm12
  8212ca:	jae    82177e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8212d0:	movapd 0x220(%rsp),%xmm4
  8212d9:	mulsd  %xmm0,%xmm4
  8212dd:	movapd 0x170(%rsp),%xmm15
  8212e7:	addsd  %xmm4,%xmm15
  8212ec:	addsd  0xf0(%rsp),%xmm15
  8212f6:	subsd  0x50(%rsp),%xmm15
  8212fd:	mulsd  0x210(%rsp),%xmm0
  821306:	addsd  %xmm0,%xmm13
  82130b:	addsd  0x100(%rsp),%xmm13
  821315:	addsd  0x40(%rsp),%xmm13
  82131c:	addsd  0x30(%rsp),%xmm13
  821323:	addsd  -0x771a4c(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82132c:	mulsd  -0x7714f5(%rip),%xmm13        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821335:	ucomisd %xmm15,%xmm13
  82133a:	movsd  0x8(%rsp),%xmm12
  821341:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821347:	movapd %xmm4,0x170(%rsp)
  821350:	movapd 0x20(%rsp),%xmm4
  821356:	subsd  %xmm15,%xmm4
  82135b:	ucomisd %xmm4,%xmm13
  821360:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821366:	movsd  %xmm10,0x188(%rsp)
  821370:	addsd  -0x771d90(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  821378:	movapd %xmm1,%xmm10
  82137d:	mulsd  0x2f0(%rsp),%xmm10
  821387:	movapd %xmm1,%xmm4
  82138b:	mulsd  0x2e0(%rsp),%xmm4
  821394:	addsd  %xmm10,%xmm3
  821399:	addsd  0x160(%rsp),%xmm3
  8213a2:	subsd  0x90(%rsp),%xmm3
  8213ab:	addsd  %xmm4,%xmm8
  8213b0:	addsd  0x150(%rsp),%xmm8
  8213ba:	addsd  0x80(%rsp),%xmm8
  8213c4:	addsd  0x70(%rsp),%xmm8
  8213cb:	addsd  -0x771af4(%rip),%xmm8        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213d4:	mulsd  -0x771b7d(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8213dd:	addsd  0x18(%rsp),%xmm8
  8213e4:	ucomisd %xmm3,%xmm8
  8213e9:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8213ef:	movapd %xmm6,0x2d0(%rsp)
  8213f8:	movapd 0x60(%rsp),%xmm6
  8213fe:	subsd  %xmm3,%xmm6
  821402:	ucomisd %xmm6,%xmm8
  821407:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82140d:	movapd 0x280(%rsp),%xmm8
  821417:	mulsd  %xmm1,%xmm8
  82141c:	movapd 0x270(%rsp),%xmm3
  821425:	mulsd  %xmm1,%xmm3
  821429:	addsd  %xmm8,%xmm5
  82142e:	addsd  0x140(%rsp),%xmm5
  821437:	subsd  0x90(%rsp),%xmm5
  821440:	addsd  %xmm3,%xmm7
  821444:	addsd  0x130(%rsp),%xmm7
  82144d:	addsd  0x80(%rsp),%xmm7
  821456:	addsd  0x70(%rsp),%xmm7
  82145c:	addsd  -0x771b84(%rip),%xmm7        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821464:	mulsd  -0x77162c(%rip),%xmm7        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82146c:	ucomisd %xmm5,%xmm7
  821470:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821476:	movapd 0x60(%rsp),%xmm6
  82147c:	subsd  %xmm5,%xmm6
  821480:	ucomisd %xmm6,%xmm7
  821484:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82148a:	movsd  %xmm14,0x180(%rsp)
  821494:	movapd %xmm9,%xmm14
  821499:	movapd %xmm1,%xmm7
  82149d:	mulsd  0x240(%rsp),%xmm7
  8214a6:	movapd %xmm1,%xmm5
  8214aa:	mulsd  0x230(%rsp),%xmm5
  8214b3:	movsd  0x190(%rsp),%xmm9
  8214bd:	addsd  %xmm7,%xmm9
  8214c2:	addsd  0x120(%rsp),%xmm9
  8214cc:	subsd  0x50(%rsp),%xmm9
  8214d3:	movsd  0xb0(%rsp),%xmm13
  8214dd:	addsd  %xmm5,%xmm13
  8214e2:	addsd  0x110(%rsp),%xmm13
  8214ec:	addsd  0x40(%rsp),%xmm13
  8214f3:	addsd  0x30(%rsp),%xmm13
  8214fa:	addsd  -0x771c23(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821503:	mulsd  -0x771cac(%rip),%xmm13        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82150c:	addsd  0x10(%rsp),%xmm13
  821513:	ucomisd %xmm9,%xmm13
  821518:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82151e:	movapd 0x20(%rsp),%xmm6
  821524:	subsd  %xmm9,%xmm6
  821529:	ucomisd %xmm6,%xmm13
  82152e:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821534:	movapd 0x200(%rsp),%xmm6
  82153d:	mulsd  %xmm1,%xmm6
  821541:	mulsd  0x1f0(%rsp),%xmm1
  82154a:	movapd 0x300(%rsp),%xmm13
  821554:	addsd  %xmm6,%xmm13
  821559:	addsd  0xf0(%rsp),%xmm13
  821563:	subsd  0x50(%rsp),%xmm13
  82156a:	addsd  %xmm1,%xmm2
  82156e:	addsd  0x100(%rsp),%xmm2
  821577:	addsd  0x40(%rsp),%xmm2
  82157d:	addsd  0x30(%rsp),%xmm2
  821583:	addsd  -0x771cab(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82158b:	mulsd  -0x771753(%rip),%xmm2        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821593:	ucomisd %xmm13,%xmm2
  821598:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82159e:	movapd 0x20(%rsp),%xmm9
  8215a5:	subsd  %xmm13,%xmm9
  8215aa:	ucomisd %xmm9,%xmm2
  8215af:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8215b5:	addsd  %xmm10,%xmm14
  8215ba:	addsd  0x160(%rsp),%xmm14
  8215c4:	subsd  0x90(%rsp),%xmm14
  8215ce:	movsd  0x188(%rsp),%xmm9
  8215d8:	addsd  %xmm4,%xmm9
  8215dd:	addsd  0x150(%rsp),%xmm9
  8215e7:	addsd  0x80(%rsp),%xmm9
  8215f1:	addsd  0x70(%rsp),%xmm9
  8215f8:	addsd  -0x771d21(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821601:	mulsd  -0x771daa(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82160a:	addsd  0x18(%rsp),%xmm9
  821611:	ucomisd %xmm14,%xmm9
  821616:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82161c:	movapd 0x60(%rsp),%xmm2
  821622:	subsd  %xmm14,%xmm2
  821627:	ucomisd %xmm2,%xmm9
  82162c:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821632:	movapd 0x2d0(%rsp),%xmm4
  82163b:	addsd  %xmm8,%xmm4
  821640:	addsd  0x140(%rsp),%xmm4
  821649:	subsd  0x90(%rsp),%xmm4
  821652:	addsd  %xmm3,%xmm11
  821657:	addsd  0x130(%rsp),%xmm11
  821661:	addsd  0x80(%rsp),%xmm11
  82166b:	addsd  0x70(%rsp),%xmm11
  821672:	addsd  -0x771d9b(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82167b:	mulsd  -0x771844(%rip),%xmm11        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821684:	ucomisd %xmm4,%xmm11
  821689:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82168f:	movapd 0x60(%rsp),%xmm2
  821695:	subsd  %xmm4,%xmm2
  821699:	ucomisd %xmm2,%xmm11
  82169e:	movsd  0x180(%rsp),%xmm3
  8216a7:	movsd  0xc0(%rsp),%xmm4
  8216b0:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8216b6:	addsd  %xmm7,%xmm3
  8216ba:	addsd  0x120(%rsp),%xmm3
  8216c3:	subsd  0x50(%rsp),%xmm3
  8216c9:	addsd  %xmm5,%xmm4
  8216cd:	addsd  0x110(%rsp),%xmm4
  8216d6:	addsd  0x40(%rsp),%xmm4
  8216dc:	addsd  0x30(%rsp),%xmm4
  8216e2:	addsd  -0x771e0a(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8216ea:	mulsd  -0x771e92(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8216f2:	addsd  0x10(%rsp),%xmm4
  8216f8:	ucomisd %xmm3,%xmm4
  8216fc:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821702:	movapd 0x20(%rsp),%xmm2
  821708:	subsd  %xmm3,%xmm2
  82170c:	ucomisd %xmm2,%xmm4
  821710:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821716:	movapd 0x170(%rsp),%xmm3
  82171f:	addsd  %xmm6,%xmm3
  821723:	addsd  0xf0(%rsp),%xmm3
  82172c:	subsd  0x50(%rsp),%xmm3
  821732:	addsd  %xmm1,%xmm0
  821736:	addsd  0x100(%rsp),%xmm0
  82173f:	addsd  0x40(%rsp),%xmm0
  821745:	addsd  0x30(%rsp),%xmm0
  82174b:	addsd  -0x771e73(%rip),%xmm0        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821753:	mulsd  -0x77191b(%rip),%xmm0        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82175b:	ucomisd %xmm3,%xmm0
  82175f:	jae    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821765:	movapd 0x20(%rsp),%xmm1
  82176b:	subsd  %xmm3,%xmm1
  82176f:	ucomisd %xmm1,%xmm0
  821773:	jb     820d15 <<gpui_gpu::renderer::RendererState>::bin_draw+0x635>
  821779:	jmp    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82177e:	movsd  0x8(%rsp),%xmm12
  821785:	jmp    820e00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82178a:	nopw   0x0(%rax,%rax,1)
  821790:	mov    0x1a8(%rsp),%r10
  821798:	cmp    %r10,0x1c0(%rsp)
  8217a0:	mov    0x1b0(%rsp),%rbp
  8217a8:	mov    0x1b8(%rsp),%rax
  8217b0:	jae    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8217b6:	mov    %rax,%r14
  8217b9:	cmp    %r10,%rax
  8217bc:	jbe    820c10 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  8217c2:	jmp    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8217c7:	nopw   0x0(%rax,%rax,1)
  8217d0:	mov    %r14,%rax
  8217d3:	cmp    %r10,%r14
  8217d6:	adc    $0x0,%r14
  8217da:	mov    %rax,%rcx
  8217dd:	imul   %r13,%rcx
  8217e1:	mov    %rbp,%rdx
  8217e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  8217f0:	lea    (%rdx,%rcx,1),%r12
  8217f4:	cmp    %r9,%r12
  8217f7:	jae    821835 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  8217f9:	cmp    %rbx,%rdx
  8217fc:	mov    %rdx,%rsi
  8217ff:	adc    $0x0,%rsi
  821803:	mov    0x4(%r15,%r12,8),%edi
  821808:	inc    %edi
  82180a:	and    $0xbfffffff,%edi
  821810:	mov    %edi,0x4(%r15,%r12,8)
  821815:	cmp    %rbx,%rdx
  821818:	jae    821822 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1142>
  82181a:	mov    %rsi,%rdx
  82181d:	cmp    %rbx,%rsi
  821820:	jbe    8217f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1110>
  821822:	cmp    %r10,%rax
  821825:	jae    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82182b:	cmp    %r10,%r14
  82182e:	jbe    8217d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  821830:	jmp    82091d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  821835:	lea    0x60df2c(%rip),%rdx        # e2f768 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  82183c:	mov    %r12,%rdi
  82183f:	mov    %r9,%rsi
  821842:	call   *0x65f918(%rip)        # e81160 <_DYNAMIC+0x4f8>
  821848:	lea    0x60e021(%rip),%rdi        # e2f870 <anon.93049d86f4da36fb5b5cebb14659314f.39.llvm.2397904706780205377>
  82184f:	call   *0x65fa7b(%rip)        # e812d0 <_DYNAMIC+0x668>
  821855:	lea    0x60def4(%rip),%rdx        # e2f750 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  82185c:	mov    %r12,%rdi
  82185f:	mov    %r9,%rsi
  821862:	call   *0x65f8f8(%rip)        # e81160 <_DYNAMIC+0x4f8>
  821868:	lea    0x60df29(%rip),%rdx        # e2f798 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x110>
  82186f:	mov    %r12,%rdi
  821872:	mov    0xd8(%rsp),%rsi
  82187a:	call   *0x65f8e0(%rip)        # e81160 <_DYNAMIC+0x4f8>
  821880:	lea    0x60def9(%rip),%rdx        # e2f780 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf8>
  821887:	mov    %r12,%rdi
  82188a:	mov    %r9,%rsi
  82188d:	call   *0x65f8cd(%rip)        # e81160 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008218a0 <gpui_gpu::renderer::compact_group>:
  8218a0:	xor    %eax,%eax
  8218a2:	test   %esi,%esi
  8218a4:	je     8218e3 <gpui_gpu::renderer::compact_group+0x43>
  8218a6:	cmpq   $0x2,0x10(%rdi)
  8218ab:	jb     8218e3 <gpui_gpu::renderer::compact_group+0x43>
  8218ad:	sub    $0x58,%rsp
  8218b1:	mov    (%rdi),%rsi
  8218b4:	mov    0x8(%rdi),%rax
  8218b8:	mov    (%rax),%edx
  8218ba:	mov    %rsp,%rdi
  8218bd:	call   81c8b0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8218c2:	movss  0x4(%rsp),%xmm0
  8218c8:	cmpb   $0x3,(%rsp)
  8218cc:	setne  %cl
  8218cf:	xorps  %xmm1,%xmm1
  8218d2:	ucomiss %xmm1,%xmm0
  8218d5:	setnp  %dl
  8218d8:	sete   %al
  8218db:	and    %dl,%al
  8218dd:	or     %cl,%al
  8218df:	add    $0x58,%rsp
  8218e3:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008218f0 <gpui_gpu::renderer::validate_draw>:
  8218f0:	push   %rbp
  8218f1:	push   %r15
  8218f3:	push   %r14
  8218f5:	push   %r12
  8218f7:	push   %rbx
  8218f8:	sub    $0x80,%rsp
  8218ff:	mov    %r8d,%ebp
  821902:	mov    %ecx,%r12d
  821905:	mov    %rdx,%r14
  821908:	mov    %rsi,%r15
  82190b:	mov    %rdi,%rbx
  82190e:	movups 0x88(%rsi),%xmm0
  821915:	movaps %xmm0,0x20(%rsp)
  82191a:	movaps %xmm0,0x70(%rsp)
  82191f:	lea    0x70(%rsp),%rdi
  821924:	call   *0x65f9ae(%rip)        # e812d8 <_DYNAMIC+0x670>
  82192a:	movaps 0x20(%rsp),%xmm4
  82192f:	test   %al,%al
  821931:	je     821987 <gpui_gpu::renderer::validate_draw+0x97>
  821933:	movaps %xmm4,%xmm0
  821936:	unpckhpd %xmm4,%xmm0
  82193a:	xorps  %xmm2,%xmm2
  82193d:	ucomiss %xmm2,%xmm0
  821940:	jne    821944 <gpui_gpu::renderer::validate_draw+0x54>
  821942:	jnp    821987 <gpui_gpu::renderer::validate_draw+0x97>
  821944:	movaps %xmm4,%xmm1
  821947:	shufps $0xff,%xmm4,%xmm1
  82194b:	ucomiss %xmm2,%xmm1
  82194e:	jne    821952 <gpui_gpu::renderer::validate_draw+0x62>
  821950:	jnp    821987 <gpui_gpu::renderer::validate_draw+0x97>
  821952:	xorps  %xmm3,%xmm3
  821955:	ucomiss %xmm4,%xmm3
  821958:	ja     821987 <gpui_gpu::renderer::validate_draw+0x97>
  82195a:	movaps %xmm4,%xmm2
  82195d:	shufps $0x55,%xmm4,%xmm2
  821961:	ucomiss %xmm2,%xmm3
  821964:	ja     821987 <gpui_gpu::renderer::validate_draw+0x97>
  821966:	xorps  %xmm3,%xmm3
  821969:	cvtsi2ss %r12d,%xmm3
  82196e:	addss  %xmm4,%xmm0
  821972:	ucomiss %xmm3,%xmm0
  821975:	ja     821987 <gpui_gpu::renderer::validate_draw+0x97>
  821977:	xorps  %xmm0,%xmm0
  82197a:	cvtsi2ss %ebp,%xmm0
  82197e:	addss  %xmm1,%xmm2
  821982:	ucomiss %xmm0,%xmm2
  821985:	jbe    82199d <gpui_gpu::renderer::validate_draw+0xad>
  821987:	movl   $0x3,(%rbx)
  82198d:	add    $0x80,%rsp
  821994:	pop    %rbx
  821995:	pop    %r12
  821997:	pop    %r14
  821999:	pop    %r15
  82199b:	pop    %rbp
  82199c:	ret
  82199d:	movsd  0x48(%r15),%xmm9
  8219a3:	movsd  0x60(%r15),%xmm1
  8219a9:	movupd 0x50(%r15),%xmm2
  8219af:	movapd %xmm2,%xmm5
  8219b3:	shufpd $0x1,%xmm2,%xmm5
  8219b8:	movupd 0x68(%r15),%xmm0
  8219be:	cvtpd2ps %xmm5,%xmm8
  8219c3:	movapd %xmm9,%xmm4
  8219c8:	unpcklpd %xmm1,%xmm4
  8219cc:	cvtpd2ps %xmm4,%xmm7
  8219d0:	cvtpd2ps %xmm0,%xmm6
  8219d4:	movapd %xmm6,%xmm3
  8219d8:	shufps $0x55,%xmm6,%xmm3
  8219dc:	movd   %xmm3,%ecx
  8219e0:	movd   %xmm6,%eax
  8219e4:	movapd %xmm7,%xmm3
  8219e8:	shufps $0x14,%xmm8,%xmm3
  8219ed:	shufps $0x78,%xmm3,%xmm3
  8219f1:	andps  -0x774208(%rip),%xmm3        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8219f8:	and    $0x7fffffff,%eax
  8219fd:	cmp    $0x7f800000,%eax
  821a02:	setge  %al
  821a05:	and    $0x7fffffff,%ecx
  821a0b:	cmp    $0x7f800000,%ecx
  821a11:	setge  %cl
  821a14:	pcmpgtd -0x7762ec(%rip),%xmm3        # ab730 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  821a1c:	movmskps %xmm3,%edx
  821a1f:	test   %edx,%edx
  821a21:	jne    821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821a23:	test   %al,%al
  821a25:	jne    821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821a27:	test   %cl,%cl
  821a29:	jne    821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821a2b:	movapd %xmm9,%xmm3
  821a30:	mulsd  %xmm1,%xmm3
  821a34:	movapd %xmm2,%xmm10
  821a39:	mulsd  %xmm5,%xmm10
  821a3e:	subsd  %xmm10,%xmm3
  821a43:	xorpd  %xmm10,%xmm10
  821a48:	ucomisd %xmm10,%xmm3
  821a4d:	jne    821a51 <gpui_gpu::renderer::validate_draw+0x161>
  821a4f:	jnp    821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821a51:	movq   %xmm3,%rcx
  821a56:	movabs $0x7fffffffffffffff,%rax
  821a60:	and    %rax,%rcx
  821a63:	movabs $0x7ff0000000000000,%rdx
  821a6d:	cmp    %rdx,%rcx
  821a70:	jl     821a81 <gpui_gpu::renderer::validate_draw+0x191>
  821a72:	movl   $0x5,(%rbx)
  821a78:	mov    %r14,0x8(%rbx)
  821a7c:	jmp    82198d <gpui_gpu::renderer::validate_draw+0x9d>
  821a81:	xorps  %xmm10,%xmm10
  821a85:	cvtsi2sd %r12d,%xmm10
  821a8a:	cvtsi2sd %ebp,%xmm12
  821a8f:	movsd  %xmm9,%xmm2
  821a94:	movapd -0x776c6d(%rip),%xmm13        # aae30 <GCC_except_table0+0x6c>
  821a9d:	andpd  %xmm13,%xmm2
  821aa2:	movapd %xmm10,%xmm11
  821aa7:	unpcklpd %xmm12,%xmm11
  821aac:	movapd %xmm2,%xmm9
  821ab1:	movapd %xmm11,0x50(%rsp)
  821ab8:	mulpd  %xmm11,%xmm9
  821abd:	movapd %xmm9,%xmm11
  821ac2:	unpckhpd %xmm9,%xmm11
  821ac7:	addsd  %xmm9,%xmm11
  821acc:	movapd %xmm0,%xmm9
  821ad1:	andpd  %xmm13,%xmm9
  821ad6:	addsd  %xmm11,%xmm9
  821adb:	shufpd $0x2,%xmm5,%xmm1
  821ae0:	andpd  %xmm13,%xmm1
  821ae5:	unpcklpd %xmm10,%xmm12
  821aea:	movapd %xmm1,%xmm10
  821aef:	movapd %xmm12,0x40(%rsp)
  821af6:	mulpd  %xmm12,%xmm10
  821afb:	movapd %xmm10,%xmm11
  821b00:	unpckhpd %xmm10,%xmm11
  821b05:	addsd  %xmm9,%xmm11
  821b0a:	addsd  %xmm10,%xmm11
  821b0f:	movapd %xmm0,%xmm10
  821b14:	unpckhpd %xmm0,%xmm10
  821b19:	andpd  %xmm13,%xmm10
  821b1e:	addsd  %xmm11,%xmm10
  821b23:	movsd  0x38(%r15),%xmm9
  821b29:	movsd  0x40(%r15),%xmm12
  821b2f:	andps  -0x774347(%rip),%xmm9        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821b37:	cvtps2pd %xmm9,%xmm15
  821b3b:	movapd %xmm10,%xmm9
  821b40:	addsd  %xmm15,%xmm9
  821b45:	movapd %xmm15,0x60(%rsp)
  821b4c:	unpckhpd %xmm15,%xmm15
  821b51:	addsd  %xmm15,%xmm9
  821b56:	cvtps2pd %xmm12,%xmm11
  821b5a:	movapd %xmm11,0x20(%rsp)
  821b61:	andpd  %xmm13,%xmm11
  821b66:	addsd  %xmm11,%xmm9
  821b6b:	pshufd $0xee,%xmm11,%xmm14
  821b71:	movdqa %xmm14,0x30(%rsp)
  821b78:	addsd  %xmm14,%xmm9
  821b7d:	movq   %xmm9,%rsi
  821b82:	and    %rax,%rsi
  821b85:	movabs $0x7fefffffffffffff,%rcx
  821b8f:	cmp    %rcx,%rsi
  821b92:	jg     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821b98:	ucomisd -0x772529(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821ba1:	ja     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821ba7:	movzbl (%r15),%esi
  821bab:	cmp    $0x3,%esi
  821bae:	je     821bc6 <gpui_gpu::renderer::validate_draw+0x2d6>
  821bb0:	xorpd  %xmm14,%xmm14
  821bb5:	cmp    $0x1,%esi
  821bb8:	jne    821cf2 <gpui_gpu::renderer::validate_draw+0x402>
  821bbe:	movss  0x4(%r15),%xmm14
  821bc4:	jmp    821bdd <gpui_gpu::renderer::validate_draw+0x2ed>
  821bc6:	movss  0x4(%r15),%xmm14
  821bcc:	xorpd  %xmm13,%xmm13
  821bd1:	ucomiss %xmm13,%xmm14
  821bd5:	jne    821bdd <gpui_gpu::renderer::validate_draw+0x2ed>
  821bd7:	jnp    821e17 <gpui_gpu::renderer::validate_draw+0x527>
  821bdd:	movd   %xmm14,%edi
  821be2:	test   %edi,%edi
  821be4:	sets   %r8b
  821be8:	and    $0x7fffffff,%edi
  821bee:	lea    -0x800000(%rdi),%r9d
  821bf5:	cmp    $0x7f000000,%r9d
  821bfc:	setb   %r9b
  821c00:	and    %r8b,%r9b
  821c03:	lea    -0x1(%rdi),%r10d
  821c07:	cmp    $0x7fffff,%r10d
  821c0e:	setb   %r10b
  821c12:	and    %r8b,%r10b
  821c15:	cmp    $0x7f800000,%edi
  821c1b:	sete   %dil
  821c1f:	setg   %r8b
  821c23:	or     %dil,%r8b
  821c26:	or     %r10b,%r8b
  821c29:	or     %r9b,%r8b
  821c2c:	cmp    $0x1,%r8b
  821c30:	je     821987 <gpui_gpu::renderer::validate_draw+0x97>
  821c36:	movaps %xmm11,(%rsp)
  821c3b:	movaps %xmm14,%xmm11
  821c3f:	movaps %xmm14,0x10(%rsp)
  821c45:	movaps %xmm12,%xmm14
  821c49:	mulss  -0x772c86(%rip),%xmm14        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821c52:	minss  %xmm14,%xmm11
  821c57:	movaps %xmm11,%xmm14
  821c5b:	cmpunordss %xmm11,%xmm14
  821c61:	movaps %xmm14,%xmm13
  821c65:	andnps %xmm11,%xmm13
  821c69:	andps  0x10(%rsp),%xmm14
  821c6f:	orps   %xmm13,%xmm14
  821c73:	shufps $0x55,%xmm12,%xmm12
  821c78:	mulss  -0x772cb5(%rip),%xmm12        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821c81:	movaps %xmm14,%xmm11
  821c85:	minss  %xmm12,%xmm11
  821c8a:	movaps %xmm11,%xmm12
  821c8e:	cmpunordss %xmm11,%xmm12
  821c94:	andps  %xmm12,%xmm14
  821c98:	andnps %xmm11,%xmm12
  821c9c:	orps   %xmm14,%xmm12
  821ca0:	movss  -0x7729f9(%rip),%xmm11        # af2b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821ca9:	ucomiss %xmm12,%xmm11
  821cad:	ja     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821cb3:	xorps  %xmm14,%xmm14
  821cb7:	cvtss2sd %xmm12,%xmm14
  821cbc:	movapd %xmm9,%xmm11
  821cc1:	divsd  %xmm14,%xmm11
  821cc6:	ucomisd -0x7723e7(%rip),%xmm11        # af8e8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  821ccf:	ja     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821cd5:	addsd  %xmm9,%xmm14
  821cda:	mulsd  -0x77255b(%rip),%xmm14        # af788 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821ce3:	movapd (%rsp),%xmm11
  821ce9:	movapd -0x776ec2(%rip),%xmm13        # aae30 <GCC_except_table0+0x6c>
  821cf2:	cmp    $0x2,%esi
  821cf5:	movaps %xmm11,(%rsp)
  821cfa:	jae    821e0b <gpui_gpu::renderer::validate_draw+0x51b>
  821d00:	cvtps2pd %xmm8,%xmm8
  821d04:	subpd  %xmm8,%xmm5
  821d09:	cvtps2pd %xmm7,%xmm7
  821d0c:	andpd  %xmm13,%xmm5
  821d11:	mulpd  0x40(%rsp),%xmm5
  821d17:	subpd  %xmm7,%xmm4
  821d1b:	andpd  %xmm13,%xmm4
  821d20:	mulpd  0x50(%rsp),%xmm4
  821d26:	addpd  %xmm5,%xmm4
  821d2a:	cvtps2pd %xmm6,%xmm5
  821d2d:	subpd  %xmm5,%xmm0
  821d31:	addsd  -0x77245a(%rip),%xmm10        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821d3a:	mulsd  -0x772293(%rip),%xmm10        # afab0 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821d43:	andpd  %xmm13,%xmm0
  821d48:	addpd  %xmm4,%xmm0
  821d4c:	movapd 0x60(%rsp),%xmm7
  821d52:	addsd  %xmm7,%xmm15
  821d57:	movapd (%rsp),%xmm6
  821d5c:	addsd  %xmm6,%xmm15
  821d61:	addsd  0x30(%rsp),%xmm15
  821d68:	movapd %xmm0,%xmm4
  821d6c:	unpckhpd %xmm0,%xmm4
  821d70:	addpd  %xmm0,%xmm4
  821d74:	movapd %xmm1,%xmm5
  821d78:	shufpd $0x1,%xmm4,%xmm5
  821d7d:	movapd %xmm2,%xmm4
  821d81:	unpcklpd %xmm10,%xmm4
  821d86:	addpd  %xmm4,%xmm5
  821d8a:	mulsd  -0x7726db(%rip),%xmm15        # af6b8 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821d93:	shufpd $0x1,%xmm15,%xmm2
  821d99:	addpd  %xmm5,%xmm2
  821d9d:	unpcklpd %xmm14,%xmm1
  821da2:	addpd  %xmm2,%xmm1
  821da6:	movapd %xmm1,%xmm2
  821daa:	unpckhpd %xmm1,%xmm2
  821dae:	mulsd  %xmm1,%xmm2
  821db2:	andpd  -0x776f8a(%rip),%xmm3        # aae30 <GCC_except_table0+0x6c>
  821dba:	divsd  %xmm3,%xmm2
  821dbe:	movq   %xmm2,%rdx
  821dc3:	and    %rax,%rdx
  821dc6:	cmp    %rcx,%rdx
  821dc9:	jg     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821dcf:	ucomisd -0x771ec7(%rip),%xmm2        # aff10 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821dd7:	ja     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821ddd:	unpcklpd %xmm10,%xmm10
  821de2:	addpd  %xmm10,%xmm0
  821de7:	addpd  %xmm7,%xmm6
  821deb:	mulpd  -0x776de3(%rip),%xmm6        # ab010 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821df3:	addpd  %xmm0,%xmm6
  821df7:	cvtpd2ps %xmm6,%xmm0
  821dfb:	movlpd %xmm0,0x4(%rbx)
  821e00:	movl   $0xffffffff,(%rbx)
  821e06:	jmp    82198d <gpui_gpu::renderer::validate_draw+0x9d>
  821e0b:	jne    821e20 <gpui_gpu::renderer::validate_draw+0x530>
  821e0d:	mov    0x28(%r15),%rsi
  821e11:	mov    0x30(%r15),%rdi
  821e15:	jmp    821e28 <gpui_gpu::renderer::validate_draw+0x538>
  821e17:	movaps %xmm11,(%rsp)
  821e1c:	xorps  %xmm14,%xmm14
  821e20:	mov    0x28(%r15),%esi
  821e24:	mov    0x2c(%r15),%edi
  821e28:	movq   %rsi,%xmm11
  821e2d:	punpckldq -0x7764e6(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821e36:	subpd  -0x77701f(%rip),%xmm11        # aae20 <GCC_except_table0+0x5c>
  821e3f:	movapd %xmm11,%xmm12
  821e44:	unpckhpd %xmm11,%xmm12
  821e49:	addsd  %xmm11,%xmm12
  821e4e:	movapd 0x20(%rsp),%xmm11
  821e55:	divsd  %xmm11,%xmm12
  821e5a:	movq   %xmm12,%r8
  821e5f:	and    %rax,%r8
  821e62:	cmp    %rdx,%r8
  821e65:	jge    821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821e6b:	movaps %xmm14,0x10(%rsp)
  821e71:	movapd %xmm11,%xmm14
  821e76:	movq   %rdi,%xmm11
  821e7b:	punpckldq -0x776534(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821e84:	subpd  -0x77706d(%rip),%xmm11        # aae20 <GCC_except_table0+0x5c>
  821e8d:	movapd %xmm11,%xmm13
  821e92:	unpckhpd %xmm11,%xmm13
  821e97:	addsd  %xmm11,%xmm13
  821e9c:	unpckhpd %xmm14,%xmm14
  821ea1:	divsd  %xmm14,%xmm13
  821ea6:	movapd 0x10(%rsp),%xmm14
  821ead:	movq   %xmm13,%rdx
  821eb2:	and    %rax,%rdx
  821eb5:	cmp    %rcx,%rdx
  821eb8:	setg   %dl
  821ebb:	ucomisd -0x77284c(%rip),%xmm13        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821ec4:	movapd -0x77709d(%rip),%xmm13        # aae30 <GCC_except_table0+0x6c>
  821ecd:	ja     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821ed3:	ucomisd -0x772864(%rip),%xmm12        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821edc:	ja     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821ee2:	test   %dl,%dl
  821ee4:	jne    821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821eea:	cmp    %rsi,%rdi
  821eed:	cmova  %rdi,%rsi
  821ef1:	movq   %rsi,%xmm11
  821ef6:	punpckldq -0x7765af(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821eff:	subpd  -0x7770e8(%rip),%xmm11        # aae20 <GCC_except_table0+0x5c>
  821f08:	movapd %xmm11,%xmm12
  821f0d:	unpckhpd %xmm11,%xmm12
  821f12:	addsd  %xmm11,%xmm12
  821f17:	mulsd  %xmm12,%xmm9
  821f1c:	ucomisd -0x7728ad(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821f25:	ja     821a72 <gpui_gpu::renderer::validate_draw+0x182>
  821f2b:	jmp    821d00 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008225d0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  8225d0:	push   %rbp
  8225d1:	push   %r15
  8225d3:	push   %r14
  8225d5:	push   %r13
  8225d7:	push   %r12
  8225d9:	push   %rbx
  8225da:	sub    $0x58,%rsp
  8225de:	mov    %ecx,%ebp
  8225e0:	mov    %rdx,0x8(%rsp)
  8225e5:	mov    0x18(%rdi),%rax
  8225e9:	add    %rax,%rsi
  8225ec:	jb     822701 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8225f2:	mov    %rdi,%rbx
  8225f5:	mov    0x8(%rdi),%r15
  8225f9:	lea    0x1(%r15),%rdx
  8225fd:	mov    %rdx,%rdi
  822600:	shr    $0x3,%rdi
  822604:	mov    %rdx,%rcx
  822607:	and    $0xfffffffffffffff8,%rcx
  82260b:	sub    %rdi,%rcx
  82260e:	cmp    $0x8,%r15
  822612:	cmovb  %r15,%rcx
  822616:	mov    %rcx,%rdi
  822619:	shr    $1,%rdi
  82261c:	cmp    %rdi,%rsi
  82261f:	jbe    822650 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  822621:	inc    %rcx
  822624:	cmp    %rsi,%rcx
  822627:	cmovbe %rsi,%rcx
  82262b:	cmp    $0xf,%rcx
  82262f:	mov    %rbx,(%rsp)
  822633:	jae    822681 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  822635:	mov    %ecx,%eax
  822637:	and    $0x8,%eax
  82263a:	add    $0x8,%rax
  82263e:	cmp    $0x4,%rcx
  822642:	mov    $0x4,%ebx
  822647:	cmovae %rax,%rbx
  82264b:	jmp    8226d9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  822650:	test   %rdx,%rdx
  822653:	je     8228da <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  822659:	mov    (%rbx),%rsi
  82265c:	mov    %rdx,%rax
  82265f:	shr    $0x4,%rax
  822663:	mov    %edx,%ecx
  822665:	and    $0xf,%ecx
  822668:	cmp    $0x1,%rcx
  82266c:	sbb    $0xffffffffffffffff,%rax
  822670:	cmp    $0x1,%rax
  822674:	jne    8228e1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  82267a:	xor    %ecx,%ecx
  82267c:	jmp    822934 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  822681:	movabs $0x1ffffffffffffffe,%rax
  82268b:	inc    %rax
  82268e:	cmp    %rax,%rcx
  822691:	ja     822701 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822693:	shl    $0x3,%rcx
  822697:	movabs $0x2492492492492493,%rdx
  8226a1:	mov    %rcx,%rax
  8226a4:	mul    %rdx
  8226a7:	sub    %rdx,%rcx
  8226aa:	shr    $1,%rcx
  8226ad:	add    %rdx,%rcx
  8226b0:	shr    $0x2,%rcx
  8226b4:	dec    %rcx
  8226b7:	bsr    %rcx,%rcx
  8226bb:	not    %ecx
  8226bd:	mov    $0xffffffffffffffff,%rbx
  8226c4:	shr    %cl,%rbx
  8226c7:	movabs $0x7fffffffffffffe,%rax
  8226d1:	cmp    %rax,%rbx
  8226d4:	ja     822701 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8226d6:	inc    %rbx
  8226d9:	mov    %rbx,%r14
  8226dc:	shl    $0x5,%r14
  8226e0:	lea    0x10(%rbx),%r12
  8226e4:	mov    %r12,%r13
  8226e7:	add    %r14,%r13
  8226ea:	setb   %al
  8226ed:	movabs $0x7ffffffffffffff0,%rcx
  8226f7:	cmp    %rcx,%r13
  8226fa:	seta   %cl
  8226fd:	or     %al,%cl
  8226ff:	je     822710 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  822701:	movzbl %bpl,%edi
  822705:	call   *0x65ebd5(%rip)        # e812e0 <_DYNAMIC+0x678>
  82270b:	jmp    822b55 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  822710:	call   *0x65e7e2(%rip)        # e80ef8 <_DYNAMIC+0x290>
  822716:	mov    $0x10,%esi
  82271b:	mov    %r13,%rdi
  82271e:	call   *0x65e7dc(%rip)        # e80f00 <_DYNAMIC+0x298>
  822724:	test   %rax,%rax
  822727:	je     822b73 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  82272d:	mov    %rax,%r15
  822730:	mov    (%rsp),%rcx
  822734:	lea    0x20(%rcx),%r13
  822738:	add    %r14,%r15
  82273b:	lea    -0x1(%rbx),%r14
  82273f:	mov    %rbx,%rax
  822742:	shr    $0x3,%rax
  822746:	mov    %rbx,%rbp
  822749:	and    $0xfffffffffffffff8,%rbp
  82274d:	sub    %rax,%rbp
  822750:	cmp    $0x9,%rbx
  822754:	mov    %rcx,%rbx
  822757:	cmovb  %r14,%rbp
  82275b:	mov    %r15,%rdi
  82275e:	mov    $0xff,%esi
  822763:	mov    %r12,%rdx
  822766:	call   *0x65eb7c(%rip)        # e812e8 <memset@GLIBC_2.2.5>
  82276c:	mov    %r14,%rdi
  82276f:	mov    %r13,0x20(%rsp)
  822774:	movq   $0x20,0x28(%rsp)
  82277d:	movq   $0x10,0x30(%rsp)
  822786:	mov    %r15,0x38(%rsp)
  82278b:	mov    %r14,0x40(%rsp)
  822790:	mov    %rbp,0x48(%rsp)
  822795:	movq   $0x0,0x50(%rsp)
  82279e:	mov    0x18(%rbx),%r12
  8227a2:	test   %r12,%r12
  8227a5:	je     822b87 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  8227ab:	mov    %rbp,0x10(%rsp)
  8227b0:	mov    (%rbx),%rsi
  8227b3:	movdqa (%rsi),%xmm0
  8227b7:	pmovmskb %xmm0,%r13d
  8227bc:	not    %r13d
  8227bf:	xor    %ebp,%ebp
  8227c1:	mov    %rsi,%r14
  8227c4:	mov    %rdi,0x18(%rsp)
  8227c9:	nopl   0x0(%rax)
  8227d0:	test   %r13w,%r13w
  8227d4:	jne    8227ff <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  8227d6:	cs nopw 0x0(%rax,%rax,1)
  8227e0:	movdqa 0x10(%r14),%xmm0
  8227e6:	add    $0x10,%r14
  8227ea:	pmovmskb %xmm0,%r13d
  8227ef:	xor    $0xffff,%r13d
  8227f6:	add    $0x10,%rbp
  8227fa:	test   %r13d,%r13d
  8227fd:	je     8227e0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  8227ff:	tzcnt  %r13d,%ebx
  822804:	add    %rbp,%rbx
  822807:	mov    %rbx,%rax
  82280a:	shl    $0x5,%rax
  82280e:	sub    %rax,%rsi
  822811:	add    $0xffffffffffffffe0,%rsi
  822815:	mov    0x8(%rsp),%rdi
  82281a:	call   826f50 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  82281f:	mov    %rax,%rdx
  822822:	mov    0x18(%rsp),%rdi
  822827:	and    %rdi,%rdx
  82282a:	movdqu (%r15,%rdx,1),%xmm0
  822830:	pmovmskb %xmm0,%ecx
  822834:	test   %ecx,%ecx
  822836:	je     8228a5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822838:	tzcnt  %ecx,%ecx
  82283c:	add    %rdx,%rcx
  82283f:	and    %rdi,%rcx
  822842:	cmpb   $0x0,(%r15,%rcx,1)
  822847:	jns    8228c8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  822849:	lea    -0x1(%r13),%edx
  82284d:	and    %r13d,%edx
  822850:	dec    %r12
  822853:	shr    $0x39,%rax
  822857:	lea    -0x10(%rcx),%rsi
  82285b:	and    %rdi,%rsi
  82285e:	mov    %al,(%r15,%rcx,1)
  822862:	mov    %al,0x10(%r15,%rsi,1)
  822867:	mov    (%rsp),%rax
  82286b:	mov    (%rax),%rsi
  82286e:	not    %rbx
  822871:	shl    $0x5,%rbx
  822875:	not    %rcx
  822878:	shl    $0x5,%rcx
  82287c:	movdqu (%rsi,%rbx,1),%xmm0
  822881:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  822887:	movdqu %xmm1,0x10(%r15,%rcx,1)
  82288e:	movdqu %xmm0,(%r15,%rcx,1)
  822894:	mov    %edx,%r13d
  822897:	test   %r12,%r12
  82289a:	jne    8227d0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  8228a0:	jmp    822b64 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  8228a5:	mov    $0x10,%esi
  8228aa:	add    %rsi,%rdx
  8228ad:	and    %rdi,%rdx
  8228b0:	movdqu (%r15,%rdx,1),%xmm0
  8228b6:	pmovmskb %xmm0,%ecx
  8228ba:	add    $0x10,%rsi
  8228be:	test   %ecx,%ecx
  8228c0:	jne    822838 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  8228c6:	jmp    8228aa <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  8228c8:	movdqa (%r15),%xmm0
  8228cd:	pmovmskb %xmm0,%ecx
  8228d1:	tzcnt  %ecx,%ecx
  8228d5:	jmp    822849 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  8228da:	xor    %ecx,%ecx
  8228dc:	jmp    822b47 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  8228e1:	movabs $0x1ffffffffffffffe,%rdi
  8228eb:	and    %rax,%rdi
  8228ee:	xor    %ecx,%ecx
  8228f0:	movdqa -0x774cf8(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  8228f8:	nopl   0x0(%rax,%rax,1)
  822900:	pxor   %xmm1,%xmm1
  822904:	pcmpgtb (%rsi,%rcx,1),%xmm1
  822909:	por    %xmm0,%xmm1
  82290d:	movdqa %xmm1,(%rsi,%rcx,1)
  822912:	pxor   %xmm1,%xmm1
  822916:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  82291c:	por    %xmm0,%xmm1
  822920:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  822926:	add    $0x20,%rcx
  82292a:	add    $0xfffffffffffffffe,%rdi
  82292e:	jne    822900 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  822930:	test   $0x1,%al
  822932:	je     82294a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  822934:	pxor   %xmm0,%xmm0
  822938:	pcmpgtb (%rsi,%rcx,1),%xmm0
  82293d:	por    -0x774d45(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822945:	movdqa %xmm0,(%rsi,%rcx,1)
  82294a:	cmp    $0x10,%rdx
  82294e:	jb     822bd8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  822954:	mov    %rdx,%rdi
  822957:	mov    $0x10,%edx
  82295c:	add    %rsi,%rdi
  82295f:	call   *0x65e98b(%rip)        # e812f0 <memmove@GLIBC_2.2.5>
  822965:	movq   $0x0,0x28(%rsp)
  82296e:	movq   $0x20,0x30(%rsp)
  822977:	mov    %rbx,0x20(%rsp)
  82297c:	xor    %r12d,%r12d
  82297f:	xor    %r13d,%r13d
  822982:	jmp    822ad1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  822987:	nopw   0x0(%rax,%rax,1)
  822990:	lea    (%rax,%rbp,1),%rsi
  822994:	add    $0xffffffffffffffe0,%rsi
  822998:	mov    0x8(%rsp),%rdi
  82299d:	call   826f50 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8229a2:	mov    (%rbx),%rcx
  8229a5:	mov    0x8(%rbx),%rdx
  8229a9:	mov    %rdx,%rsi
  8229ac:	and    %rax,%rsi
  8229af:	movdqu (%rcx,%rsi,1),%xmm0
  8229b4:	pmovmskb %xmm0,%edi
  8229b8:	mov    %rsi,%r8
  8229bb:	test   %edi,%edi
  8229bd:	je     822a69 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  8229c3:	tzcnt  %edi,%edi
  8229c7:	add    %r8,%rdi
  8229ca:	and    %rdx,%rdi
  8229cd:	cmpb   $0x0,(%rcx,%rdi,1)
  8229d1:	jns    822a90 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  8229d7:	mov    %r12,%r8
  8229da:	sub    %rsi,%r8
  8229dd:	mov    %rdi,%r9
  8229e0:	sub    %rsi,%r9
  8229e3:	xor    %r8,%r9
  8229e6:	and    %rdx,%r9
  8229e9:	cmp    $0x10,%r9
  8229ed:	jb     822ab0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  8229f3:	mov    %rdi,%rsi
  8229f6:	not    %rsi
  8229f9:	shl    $0x5,%rsi
  8229fd:	add    %rcx,%rsi
  822a00:	movzbl (%rcx,%rdi,1),%r8d
  822a05:	shr    $0x39,%rax
  822a09:	lea    -0x10(%rdi),%r9
  822a0d:	and    %rdx,%r9
  822a10:	mov    %al,(%rcx,%rdi,1)
  822a13:	mov    (%rbx),%rcx
  822a16:	mov    %al,0x10(%rcx,%r9,1)
  822a1b:	cmp    $0xff,%r8b
  822a1f:	je     822af6 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  822a25:	mov    (%r14),%rax
  822a28:	mov    (%rsi),%rcx
  822a2b:	mov    %rcx,(%r14)
  822a2e:	mov    %rax,(%rsi)
  822a31:	mov    0x8(%r14),%rax
  822a35:	mov    0x8(%rsi),%rcx
  822a39:	mov    %rcx,0x8(%r14)
  822a3d:	mov    %rax,0x8(%rsi)
  822a41:	mov    0x10(%r14),%rax
  822a45:	mov    0x10(%rsi),%rcx
  822a49:	mov    %rcx,0x10(%r14)
  822a4d:	mov    %rax,0x10(%rsi)
  822a51:	mov    0x18(%r14),%rax
  822a55:	mov    0x18(%rsi),%rcx
  822a59:	mov    %rcx,0x18(%r14)
  822a5d:	mov    %rax,0x18(%rsi)
  822a61:	mov    (%rbx),%rax
  822a64:	jmp    822990 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822a69:	mov    $0x10,%r9d
  822a6f:	mov    %rsi,%r8
  822a72:	add    %r9,%r8
  822a75:	and    %rdx,%r8
  822a78:	movdqu (%rcx,%r8,1),%xmm0
  822a7e:	pmovmskb %xmm0,%edi
  822a82:	add    $0x10,%r9
  822a86:	test   %edi,%edi
  822a88:	jne    8229c3 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  822a8e:	jmp    822a72 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  822a90:	movdqa (%rcx),%xmm0
  822a94:	pmovmskb %xmm0,%edi
  822a98:	tzcnt  %edi,%edi
  822a9c:	jmp    8229d7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  822aa1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  822ab0:	shr    $0x39,%rax
  822ab4:	lea    -0x10(%r12),%rsi
  822ab9:	and    %rsi,%rdx
  822abc:	mov    %al,(%rcx,%r12,1)
  822ac0:	mov    (%rbx),%rcx
  822ac3:	mov    %al,0x10(%rcx,%rdx,1)
  822ac7:	cmp    %r15,%r12
  822aca:	lea    0x1(%r12),%r12
  822acf:	je     822b25 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  822ad1:	mov    (%rbx),%rax
  822ad4:	cmp    (%rax,%r12,1),%r13b
  822ad8:	jno    822ac7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  822ada:	mov    %r12,%r14
  822add:	not    %r14
  822ae0:	shl    $0x5,%r14
  822ae4:	add    %rax,%r14
  822ae7:	mov    %r12,%rbp
  822aea:	neg    %rbp
  822aed:	shl    $0x5,%rbp
  822af1:	jmp    822990 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822af6:	lea    -0x10(%r12),%rax
  822afb:	and    0x8(%rbx),%rax
  822aff:	mov    (%rbx),%rcx
  822b02:	movb   $0xff,(%rcx,%r12,1)
  822b07:	mov    (%rbx),%rcx
  822b0a:	movb   $0xff,0x10(%rcx,%rax,1)
  822b0f:	movdqu (%r14),%xmm0
  822b14:	movdqu 0x10(%r14),%xmm1
  822b1a:	movdqu %xmm1,0x10(%rsi)
  822b1f:	movdqu %xmm0,(%rsi)
  822b23:	jmp    822ac7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  822b25:	mov    0x8(%rbx),%rdx
  822b29:	mov    0x18(%rbx),%rax
  822b2d:	lea    0x1(%rdx),%rcx
  822b31:	mov    %rcx,%rsi
  822b34:	shr    $0x3,%rsi
  822b38:	and    $0xfffffffffffffff8,%rcx
  822b3c:	sub    %rsi,%rcx
  822b3f:	cmp    $0x8,%rdx
  822b43:	cmovb  %rdx,%rcx
  822b47:	sub    %rax,%rcx
  822b4a:	mov    %rcx,0x10(%rbx)
  822b4e:	mov    $0xffffffffffffffff,%rax
  822b55:	add    $0x58,%rsp
  822b59:	pop    %rbx
  822b5a:	pop    %r12
  822b5c:	pop    %r13
  822b5e:	pop    %r14
  822b60:	pop    %r15
  822b62:	pop    %rbp
  822b63:	ret
  822b64:	mov    (%rsp),%rbx
  822b68:	mov    0x18(%rbx),%rcx
  822b6c:	mov    0x10(%rsp),%rbp
  822b71:	jmp    822b8c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  822b73:	movzbl %bpl,%edi
  822b77:	mov    $0x10,%esi
  822b7c:	mov    %r13,%rdx
  822b7f:	call   *0x65e773(%rip)        # e812f8 <_DYNAMIC+0x690>
  822b85:	jmp    822b55 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  822b87:	mov    (%rbx),%rsi
  822b8a:	xor    %ecx,%ecx
  822b8c:	sub    %rcx,%rbp
  822b8f:	mov    %r15,(%rbx)
  822b92:	mov    0x8(%rbx),%rax
  822b96:	mov    %rdi,0x8(%rbx)
  822b9a:	mov    %rbp,0x10(%rbx)
  822b9e:	mov    %rcx,0x18(%rbx)
  822ba2:	test   %rax,%rax
  822ba5:	je     822b4e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822ba7:	mov    %rax,%rcx
  822baa:	shl    $0x5,%rcx
  822bae:	add    $0x2f,%rcx
  822bb2:	and    $0xffffffffffffffe0,%rcx
  822bb6:	add    %rcx,%rax
  822bb9:	add    $0x11,%rax
  822bbd:	je     822b4e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822bbf:	sub    %rcx,%rsi
  822bc2:	mov    $0x10,%edx
  822bc7:	mov    %rsi,%rdi
  822bca:	mov    %rax,%rsi
  822bcd:	call   *0x65e2dd(%rip)        # e80eb0 <_DYNAMIC+0x248>
  822bd3:	jmp    822b4e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822bd8:	mov    $0x10,%edi
  822bdd:	jmp    82295c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  822be2:	mov    %rax,%rbx
  822be5:	lea    0x20(%rsp),%rdi
  822bea:	call   8231c0 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  822bef:	mov    %rbx,%rdi
  822bf2:	call   e2d990 <_Unwind_Resume@plt>
  822bf7:	mov    %rax,%rbx
  822bfa:	lea    0x20(%rsp),%rdi
  822bff:	call   823200 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  822c04:	mov    %rbx,%rdi
  822c07:	call   e2d990 <_Unwind_Resume@plt>
  822c0c:	call   *0x65e2a6(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822c20 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  822c20:	push   %rbp
  822c21:	push   %r15
  822c23:	push   %r14
  822c25:	push   %r13
  822c27:	push   %r12
  822c29:	push   %rbx
  822c2a:	sub    $0x38,%rsp
  822c2e:	mov    %ecx,%r15d
  822c31:	mov    %rdx,0x20(%rsp)
  822c36:	mov    %rdi,%rbp
  822c39:	mov    0x18(%rdi),%rdi
  822c3d:	add    %rdi,%rsi
  822c40:	jb     822d58 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822c46:	mov    0x8(%rbp),%rbx
  822c4a:	lea    0x1(%rbx),%rdx
  822c4e:	mov    %rdx,%rax
  822c51:	shr    $0x3,%rax
  822c55:	mov    %rdx,%rcx
  822c58:	and    $0xfffffffffffffff8,%rcx
  822c5c:	sub    %rax,%rcx
  822c5f:	cmp    $0x8,%rbx
  822c63:	cmovb  %rbx,%rcx
  822c67:	mov    %rcx,%rax
  822c6a:	shr    $1,%rax
  822c6d:	cmp    %rax,%rsi
  822c70:	jbe    822ca6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  822c72:	inc    %rcx
  822c75:	cmp    %rsi,%rcx
  822c78:	cmovbe %rsi,%rcx
  822c7c:	cmp    $0xf,%rcx
  822c80:	mov    %rbp,(%rsp)
  822c84:	mov    %rbx,0x30(%rsp)
  822c89:	jae    822cd8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  822c8b:	mov    %ecx,%eax
  822c8d:	and    $0x8,%eax
  822c90:	add    $0x8,%rax
  822c94:	cmp    $0x4,%rcx
  822c98:	mov    $0x4,%ebx
  822c9d:	cmovae %rax,%rbx
  822ca1:	jmp    822d30 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  822ca6:	test   %rdx,%rdx
  822ca9:	je     822eee <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  822caf:	mov    0x0(%rbp),%r12
  822cb3:	mov    %rdx,%rax
  822cb6:	shr    $0x4,%rax
  822cba:	mov    %edx,%ecx
  822cbc:	and    $0xf,%ecx
  822cbf:	cmp    $0x1,%rcx
  822cc3:	sbb    $0xffffffffffffffff,%rax
  822cc7:	cmp    $0x1,%rax
  822ccb:	jne    822ef5 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822cd1:	xor    %ecx,%ecx
  822cd3:	jmp    822f48 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  822cd8:	movabs $0x1ffffffffffffffe,%rax
  822ce2:	inc    %rax
  822ce5:	cmp    %rax,%rcx
  822ce8:	ja     822d58 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822cea:	shl    $0x3,%rcx
  822cee:	movabs $0x2492492492492493,%rdx
  822cf8:	mov    %rcx,%rax
  822cfb:	mul    %rdx
  822cfe:	sub    %rdx,%rcx
  822d01:	shr    $1,%rcx
  822d04:	add    %rdx,%rcx
  822d07:	shr    $0x2,%rcx
  822d0b:	dec    %rcx
  822d0e:	bsr    %rcx,%rcx
  822d12:	not    %ecx
  822d14:	mov    $0xffffffffffffffff,%rbx
  822d1b:	shr    %cl,%rbx
  822d1e:	movabs $0xffffffffffffffe,%rax
  822d28:	cmp    %rax,%rbx
  822d2b:	ja     822d58 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822d2d:	inc    %rbx
  822d30:	mov    %rbx,%r14
  822d33:	shl    $0x4,%r14
  822d37:	lea    0x10(%rbx),%rbp
  822d3b:	mov    %rbp,%r13
  822d3e:	add    %r14,%r13
  822d41:	setb   %al
  822d44:	movabs $0x7ffffffffffffff0,%rcx
  822d4e:	cmp    %rcx,%r13
  822d51:	seta   %cl
  822d54:	or     %al,%cl
  822d56:	je     822d67 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  822d58:	movzbl %r15b,%edi
  822d5c:	call   *0x65e57e(%rip)        # e812e0 <_DYNAMIC+0x678>
  822d62:	jmp    823128 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822d67:	mov    %rdi,0x8(%rsp)
  822d6c:	call   *0x65e186(%rip)        # e80ef8 <_DYNAMIC+0x290>
  822d72:	mov    $0x10,%esi
  822d77:	mov    %r13,%rdi
  822d7a:	call   *0x65e180(%rip)        # e80f00 <_DYNAMIC+0x298>
  822d80:	test   %rax,%rax
  822d83:	je     823142 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  822d89:	mov    %rax,%rdi
  822d8c:	add    %r14,%rdi
  822d8f:	lea    -0x1(%rbx),%rcx
  822d93:	mov    %rbx,%rax
  822d96:	shr    $0x3,%rax
  822d9a:	mov    %rbx,%r14
  822d9d:	and    $0xfffffffffffffff8,%r14
  822da1:	sub    %rax,%r14
  822da4:	cmp    $0x9,%rbx
  822da8:	mov    %rcx,0x10(%rsp)
  822dad:	cmovb  %rcx,%r14
  822db1:	mov    %rdi,0x18(%rsp)
  822db6:	mov    $0xff,%esi
  822dbb:	mov    %rbp,%rdx
  822dbe:	call   *0x65e524(%rip)        # e812e8 <memset@GLIBC_2.2.5>
  822dc4:	mov    0x8(%rsp),%rbx
  822dc9:	test   %rbx,%rbx
  822dcc:	je     823156 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  822dd2:	mov    %r14,0x28(%rsp)
  822dd7:	mov    (%rsp),%rax
  822ddb:	mov    (%rax),%rdi
  822dde:	movdqa (%rdi),%xmm0
  822de2:	pmovmskb %xmm0,%r14d
  822de7:	not    %r14d
  822dea:	xor    %ebp,%ebp
  822dec:	mov    %rdi,%r13
  822def:	nop
  822df0:	test   %r14w,%r14w
  822df4:	jne    822e1f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  822df6:	cs nopw 0x0(%rax,%rax,1)
  822e00:	movdqa 0x10(%r13),%xmm0
  822e06:	add    $0x10,%r13
  822e0a:	pmovmskb %xmm0,%r14d
  822e0f:	xor    $0xffff,%r14d
  822e16:	add    $0x10,%rbp
  822e1a:	test   %r14d,%r14d
  822e1d:	je     822e00 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  822e1f:	tzcnt  %r14d,%r15d
  822e24:	add    %rbp,%r15
  822e27:	mov    %r15,%rax
  822e2a:	shl    $0x4,%rax
  822e2e:	mov    %rdi,%r12
  822e31:	mov    %rdi,%rsi
  822e34:	sub    %rax,%rsi
  822e37:	add    $0xfffffffffffffff0,%rsi
  822e3b:	mov    0x20(%rsp),%rdi
  822e40:	call   8270f0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822e45:	mov    %rax,%rcx
  822e48:	mov    0x10(%rsp),%r9
  822e4d:	and    %r9,%rcx
  822e50:	mov    0x18(%rsp),%r8
  822e55:	movdqu (%r8,%rcx,1),%xmm0
  822e5b:	pmovmskb %xmm0,%edx
  822e5f:	test   %edx,%edx
  822e61:	je     822ec0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  822e63:	tzcnt  %edx,%edx
  822e67:	add    %rcx,%rdx
  822e6a:	and    %r9,%rdx
  822e6d:	cmpb   $0x0,(%r8,%rdx,1)
  822e72:	mov    %r12,%rdi
  822e75:	jns    822edf <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  822e77:	lea    -0x1(%r14),%ecx
  822e7b:	and    %r14d,%ecx
  822e7e:	dec    %rbx
  822e81:	shr    $0x39,%rax
  822e85:	lea    -0x10(%rdx),%rsi
  822e89:	and    %r9,%rsi
  822e8c:	mov    %al,(%r8,%rdx,1)
  822e90:	mov    %al,0x10(%r8,%rsi,1)
  822e95:	not    %r15
  822e98:	shl    $0x4,%r15
  822e9c:	not    %rdx
  822e9f:	shl    $0x4,%rdx
  822ea3:	movdqu (%rdi,%r15,1),%xmm0
  822ea9:	movdqu %xmm0,(%r8,%rdx,1)
  822eaf:	mov    %ecx,%r14d
  822eb2:	test   %rbx,%rbx
  822eb5:	jne    822df0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  822ebb:	jmp    823137 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  822ec0:	mov    $0x10,%esi
  822ec5:	add    %rsi,%rcx
  822ec8:	and    %r9,%rcx
  822ecb:	movdqu (%r8,%rcx,1),%xmm0
  822ed1:	pmovmskb %xmm0,%edx
  822ed5:	add    $0x10,%rsi
  822ed9:	test   %edx,%edx
  822edb:	jne    822e63 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  822edd:	jmp    822ec5 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  822edf:	movdqa (%r8),%xmm0
  822ee4:	pmovmskb %xmm0,%ecx
  822ee8:	tzcnt  %ecx,%edx
  822eec:	jmp    822e77 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  822eee:	xor    %eax,%eax
  822ef0:	jmp    82311a <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  822ef5:	movabs $0x1ffffffffffffffe,%rsi
  822eff:	and    %rax,%rsi
  822f02:	xor    %ecx,%ecx
  822f04:	movdqa -0x77530c(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822f0c:	nopl   0x0(%rax)
  822f10:	pxor   %xmm1,%xmm1
  822f14:	pcmpgtb (%r12,%rcx,1),%xmm1
  822f1a:	por    %xmm0,%xmm1
  822f1e:	movdqa %xmm1,(%r12,%rcx,1)
  822f24:	pxor   %xmm1,%xmm1
  822f28:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  822f2f:	por    %xmm0,%xmm1
  822f33:	movdqa %xmm1,0x10(%r12,%rcx,1)
  822f3a:	add    $0x20,%rcx
  822f3e:	add    $0xfffffffffffffffe,%rsi
  822f42:	jne    822f10 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  822f44:	test   $0x1,%al
  822f46:	je     822f60 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  822f48:	pxor   %xmm0,%xmm0
  822f4c:	pcmpgtb (%r12,%rcx,1),%xmm0
  822f52:	por    -0x77535a(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822f5a:	movdqa %xmm0,(%r12,%rcx,1)
  822f60:	cmp    $0x10,%rdx
  822f64:	jb     8231b3 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  822f6a:	mov    %rdx,%rdi
  822f6d:	mov    $0x10,%edx
  822f72:	add    %r12,%rdi
  822f75:	mov    %r12,%rsi
  822f78:	call   *0x65e372(%rip)        # e812f0 <memmove@GLIBC_2.2.5>
  822f7e:	xor    %r13d,%r13d
  822f81:	xor    %eax,%eax
  822f83:	jmp    8230b6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  822f88:	nopl   0x0(%rax,%rax,1)
  822f90:	lea    (%r12,%r14,1),%rsi
  822f94:	add    $0xfffffffffffffff0,%rsi
  822f98:	mov    0x20(%rsp),%rdi
  822f9d:	call   8270f0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822fa2:	mov    0x8(%rbp),%rcx
  822fa6:	mov    %rcx,%rdx
  822fa9:	and    %rax,%rdx
  822fac:	movdqu (%r12,%rdx,1),%xmm0
  822fb2:	pmovmskb %xmm0,%esi
  822fb6:	mov    %rdx,%rdi
  822fb9:	test   %esi,%esi
  822fbb:	je     82304b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  822fc1:	tzcnt  %esi,%esi
  822fc5:	add    %rdi,%rsi
  822fc8:	and    %rcx,%rsi
  822fcb:	cmpb   $0x0,(%r12,%rsi,1)
  822fd0:	jns    823072 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  822fd6:	mov    %r13,%rdi
  822fd9:	sub    %rdx,%rdi
  822fdc:	mov    %rsi,%r8
  822fdf:	sub    %rdx,%r8
  822fe2:	xor    %rdi,%r8
  822fe5:	and    %rcx,%r8
  822fe8:	cmp    $0x10,%r8
  822fec:	jb     823090 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  822ff2:	mov    %rsi,%rdx
  822ff5:	not    %rdx
  822ff8:	shl    $0x4,%rdx
  822ffc:	add    %r12,%rdx
  822fff:	movzbl (%r12,%rsi,1),%edi
  823004:	shr    $0x39,%rax
  823008:	lea    -0x10(%rsi),%r8
  82300c:	and    %rcx,%r8
  82300f:	mov    %al,(%r12,%rsi,1)
  823013:	mov    0x0(%rbp),%r12
  823017:	mov    %al,0x10(%r12,%r8,1)
  82301c:	cmp    $0xff,%dil
  823020:	je     8230db <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  823026:	mov    (%rbx),%rax
  823029:	mov    (%rdx),%rcx
  82302c:	mov    %rcx,(%rbx)
  82302f:	mov    %rax,(%rdx)
  823032:	mov    0x8(%rbx),%rax
  823036:	mov    0x8(%rdx),%rcx
  82303a:	mov    %rcx,0x8(%rbx)
  82303e:	mov    %rax,0x8(%rdx)
  823042:	mov    0x0(%rbp),%r12
  823046:	jmp    822f90 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  82304b:	mov    $0x10,%r8d
  823051:	mov    %rdx,%rdi
  823054:	add    %r8,%rdi
  823057:	and    %rcx,%rdi
  82305a:	movdqu (%r12,%rdi,1),%xmm0
  823060:	pmovmskb %xmm0,%esi
  823064:	add    $0x10,%r8
  823068:	test   %esi,%esi
  82306a:	jne    822fc1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  823070:	jmp    823054 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  823072:	movdqa (%r12),%xmm0
  823078:	pmovmskb %xmm0,%esi
  82307c:	tzcnt  %esi,%esi
  823080:	jmp    822fd6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  823085:	data16 cs nopw 0x0(%rax,%rax,1)
  823090:	shr    $0x39,%rax
  823094:	lea    -0x10(%r13),%rdx
  823098:	and    %rdx,%rcx
  82309b:	mov    %al,(%r12,%r13,1)
  82309f:	mov    0x0(%rbp),%r12
  8230a3:	mov    %al,0x10(%r12,%rcx,1)
  8230a8:	mov    %r15,%rbx
  8230ab:	xor    %eax,%eax
  8230ad:	cmp    %rbx,%r13
  8230b0:	lea    0x1(%r13),%r13
  8230b4:	je     8230f8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  8230b6:	cmp    (%r12,%r13,1),%al
  8230ba:	jno    8230ad <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  8230bc:	mov    %rbx,%r15
  8230bf:	mov    %r13,%rbx
  8230c2:	not    %rbx
  8230c5:	shl    $0x4,%rbx
  8230c9:	add    %r12,%rbx
  8230cc:	mov    %r13,%r14
  8230cf:	neg    %r14
  8230d2:	shl    $0x4,%r14
  8230d6:	jmp    822f90 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  8230db:	lea    -0x10(%r13),%rax
  8230df:	and    0x8(%rbp),%rax
  8230e3:	movb   $0xff,(%r12,%r13,1)
  8230e8:	movb   $0xff,0x10(%r12,%rax,1)
  8230ee:	movdqu (%rbx),%xmm0
  8230f2:	movdqu %xmm0,(%rdx)
  8230f6:	jmp    8230a8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  8230f8:	mov    0x8(%rbp),%rcx
  8230fc:	mov    0x18(%rbp),%rdi
  823100:	lea    0x1(%rcx),%rax
  823104:	mov    %rax,%rdx
  823107:	shr    $0x3,%rdx
  82310b:	and    $0xfffffffffffffff8,%rax
  82310f:	sub    %rdx,%rax
  823112:	cmp    $0x8,%rcx
  823116:	cmovb  %rcx,%rax
  82311a:	sub    %rdi,%rax
  82311d:	mov    %rax,0x10(%rbp)
  823121:	mov    $0xffffffffffffffff,%rax
  823128:	add    $0x38,%rsp
  82312c:	pop    %rbx
  82312d:	pop    %r12
  82312f:	pop    %r13
  823131:	pop    %r14
  823133:	pop    %r15
  823135:	pop    %rbp
  823136:	ret
  823137:	mov    (%rsp),%rax
  82313b:	mov    0x28(%rsp),%r14
  823140:	jmp    823167 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  823142:	movzbl %r15b,%edi
  823146:	mov    $0x10,%esi
  82314b:	mov    %r13,%rdx
  82314e:	call   *0x65e1a4(%rip)        # e812f8 <_DYNAMIC+0x690>
  823154:	jmp    823128 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  823156:	mov    (%rsp),%rax
  82315a:	mov    (%rax),%rdi
  82315d:	mov    0x18(%rsp),%r8
  823162:	mov    0x10(%rsp),%r9
  823167:	sub    0x8(%rsp),%r14
  82316c:	mov    %r8,(%rax)
  82316f:	mov    %r9,0x8(%rax)
  823173:	mov    %r14,0x10(%rax)
  823177:	mov    $0xffffffffffffffff,%rax
  82317e:	mov    0x30(%rsp),%rsi
  823183:	test   %rsi,%rsi
  823186:	je     823128 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  823188:	mov    %rsi,%rcx
  82318b:	shl    $0x4,%rcx
  82318f:	add    $0x1f,%rcx
  823193:	and    $0xfffffffffffffff0,%rcx
  823197:	add    %rcx,%rsi
  82319a:	add    $0x11,%rsi
  82319e:	je     823128 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  8231a0:	sub    %rcx,%rdi
  8231a3:	mov    $0x10,%edx
  8231a8:	call   *0x65dd02(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8231ae:	jmp    823121 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  8231b3:	mov    $0x10,%edi
  8231b8:	jmp    822f72 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823370 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  823370:	mov    0x8(%rdi),%rsi
  823374:	test   %rsi,%rsi
  823377:	je     82339e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  823379:	mov    %rsi,%rax
  82337c:	shl    $0x5,%rax
  823380:	add    %rax,%rsi
  823383:	add    $0x31,%rsi
  823387:	je     82339e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  823389:	mov    (%rdi),%rdi
  82338c:	sub    %rax,%rdi
  82338f:	add    $0xffffffffffffffe0,%rdi
  823393:	mov    $0x10,%edx
  823398:	jmp    *0x65db12(%rip)        # e80eb0 <_DYNAMIC+0x248>
  82339e:	ret

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008233a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  8233a0:	push   %rbx
  8233a1:	test   %rdi,%rdi
  8233a4:	je     823407 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  8233a6:	mov    %rdi,%rbx
  8233a9:	mov    (%rdi),%rsi
  8233ac:	test   %rsi,%rsi
  8233af:	je     8233c4 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  8233b1:	mov    0x8(%rbx),%rdi
  8233b5:	shl    $0x3,%rsi
  8233b9:	mov    $0x8,%edx
  8233be:	call   *0x65daec(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8233c4:	mov    0x20(%rbx),%rsi
  8233c8:	test   %rsi,%rsi
  8233cb:	je     8233f3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8233cd:	mov    %rsi,%rax
  8233d0:	shl    $0x4,%rax
  8233d4:	add    %rax,%rsi
  8233d7:	add    $0x21,%rsi
  8233db:	je     8233f3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8233dd:	mov    0x18(%rbx),%rdi
  8233e1:	sub    %rax,%rdi
  8233e4:	add    $0xfffffffffffffff0,%rdi
  8233e8:	mov    $0x10,%edx
  8233ed:	call   *0x65dabd(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8233f3:	mov    $0x80,%esi
  8233f8:	mov    $0x8,%edx
  8233fd:	mov    %rbx,%rdi
  823400:	pop    %rbx
  823401:	jmp    *0x65daa9(%rip)        # e80eb0 <_DYNAMIC+0x248>
  823407:	pop    %rbx
  823408:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823630 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  823630:	push   %r14
  823632:	push   %rbx
  823633:	push   %rax
  823634:	mov    %rdi,%rbx
  823637:	mov    (%rdi),%rax
  82363a:	lock decq (%rax)
  82363e:	jne    823649 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  823640:	mov    %rbx,%rdi
  823643:	call   *0x65db27(%rip)        # e81170 <_DYNAMIC+0x508>
  823649:	mov    0x8(%rbx),%rax
  82364d:	lock decq (%rax)
  823651:	jne    823667 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  823653:	add    $0x8,%rbx
  823657:	mov    %rbx,%rdi
  82365a:	add    $0x8,%rsp
  82365e:	pop    %rbx
  82365f:	pop    %r14
  823661:	jmp    *0x65db11(%rip)        # e81178 <_DYNAMIC+0x510>
  823667:	add    $0x8,%rsp
  82366b:	pop    %rbx
  82366c:	pop    %r14
  82366e:	ret
  82366f:	mov    %rax,%r14
  823672:	mov    0x8(%rbx),%rax
  823676:	lock decq (%rax)
  82367a:	jne    823689 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  82367c:	add    $0x8,%rbx
  823680:	mov    %rbx,%rdi
  823683:	call   *0x65daef(%rip)        # e81178 <_DYNAMIC+0x510>
  823689:	mov    %r14,%rdi
  82368c:	call   e2d990 <_Unwind_Resume@plt>
  823691:	call   *0x65d821(%rip)        # e80eb8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823760 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  823760:	push   %rbx
  823761:	mov    %rdi,%rbx
  823764:	mov    (%rdi),%rsi
  823767:	test   %rsi,%rsi
  82376a:	je     82377f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  82376c:	mov    0x8(%rbx),%rdi
  823770:	shl    $0x3,%rsi
  823774:	mov    $0x8,%edx
  823779:	call   *0x65d731(%rip)        # e80eb0 <_DYNAMIC+0x248>
  82377f:	mov    0x20(%rbx),%rsi
  823783:	test   %rsi,%rsi
  823786:	je     8237af <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823788:	mov    %rsi,%rax
  82378b:	shl    $0x4,%rax
  82378f:	add    %rax,%rsi
  823792:	add    $0x21,%rsi
  823796:	je     8237af <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823798:	mov    0x18(%rbx),%rdi
  82379c:	sub    %rax,%rdi
  82379f:	add    $0xfffffffffffffff0,%rdi
  8237a3:	mov    $0x10,%edx
  8237a8:	pop    %rbx
  8237a9:	jmp    *0x65d701(%rip)        # e80eb0 <_DYNAMIC+0x248>
  8237af:	pop    %rbx
  8237b0:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008237c0 <<gpui_gpu::renderer::images::Images>::metadata>:
  8237c0:	push   %r15
  8237c2:	push   %r14
  8237c4:	push   %rbx
  8237c5:	sub    $0x10,%rsp
  8237c9:	mov    %rsi,0x8(%rsp)
  8237ce:	cmpq   $0x0,0x30(%rdi)
  8237d3:	je     82389d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  8237d9:	mov    %edx,%ebx
  8237db:	mov    %rsi,%r14
  8237de:	mov    %rdi,%r15
  8237e1:	add    $0x38,%rdi
  8237e5:	lea    0x8(%rsp),%rsi
  8237ea:	call   8270f0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8237ef:	mov    %rax,%rsi
  8237f2:	shr    $0x39,%rsi
  8237f6:	mov    0x18(%r15),%rcx
  8237fa:	mov    0x20(%r15),%rdx
  8237fe:	movd   %esi,%xmm0
  823802:	punpcklbw %xmm0,%xmm0
  823806:	pshuflw $0x0,%xmm0,%xmm0
  82380b:	pshufd $0x44,%xmm0,%xmm0
  823810:	xor    %esi,%esi
  823812:	pcmpeqd %xmm1,%xmm1
  823816:	and    %rdx,%rax
  823819:	movdqu (%rcx,%rax,1),%xmm2
  82381e:	movdqa %xmm2,%xmm3
  823822:	pcmpeqb %xmm0,%xmm3
  823826:	pmovmskb %xmm3,%edi
  82382a:	test   %edi,%edi
  82382c:	je     823860 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  82382e:	tzcnt  %edi,%r9d
  823833:	add    %rax,%r9
  823836:	and    %rdx,%r9
  823839:	shl    $0x4,%r9
  82383d:	mov    %rcx,%r8
  823840:	sub    %r9,%r8
  823843:	cmp    -0x10(%r8),%r14
  823847:	je     823879 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  823849:	lea    -0x1(%rdi),%r8d
  82384d:	and    %di,%r8w
  823851:	mov    %r8d,%edi
  823854:	jne    82382e <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  823856:	cs nopw 0x0(%rax,%rax,1)
  823860:	pcmpeqb %xmm1,%xmm2
  823864:	pmovmskb %xmm2,%edi
  823868:	test   %edi,%edi
  82386a:	jne    82389d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  82386c:	add    %rsi,%rax
  82386f:	add    $0x10,%rax
  823873:	add    $0x10,%rsi
  823877:	jmp    823816 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  823879:	mov    -0x8(%r8),%eax
  82387d:	movzbl %bl,%ecx
  823880:	or     -0x4(%r8),%ecx
  823884:	shl    $0x20,%rcx
  823888:	or     %rax,%rcx
  82388b:	mov    $0x80000000,%eax
  823890:	or     %rcx,%rax
  823893:	add    $0x10,%rsp
  823897:	pop    %rbx
  823898:	pop    %r14
  82389a:	pop    %r15
  82389c:	ret
  82389d:	lea    -0x74eb44(%rip),%rdi        # d4d60 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  8238a4:	lea    0x60bfdd(%rip),%rdx        # e2f888 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456>
  8238ab:	mov    $0x16,%esi
  8238b0:	call   *0x65d952(%rip)        # e81208 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2648 frame=536

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823b30 <gpui_gpu::renderer::images::prepare>:
  823b30:	push   %rbp
  823b31:	push   %r15
  823b33:	push   %r14
  823b35:	push   %r13
  823b37:	push   %r12
  823b39:	push   %rbx
  823b3a:	sub    $0x1e8,%rsp
  823b41:	mov    %r9,%r12
  823b44:	mov    %rcx,%r13
  823b47:	mov    %rdx,0xb0(%rsp)
  823b4f:	mov    %rsi,(%rsp)
  823b53:	mov    %rdi,%r15
  823b56:	mov    0x220(%rsp),%rax
  823b5e:	mov    0x10(%rax),%r14
  823b62:	mov    0x118(%r14),%rax
  823b69:	add    $0x118,%r14
  823b70:	test   %rax,%rax
  823b73:	mov    %r14,%rcx
  823b76:	cmove  %rax,%rcx
  823b7a:	je     823c0c <gpui_gpu::renderer::images::prepare+0xdc>
  823b80:	mov    0x10(%rax),%rax
  823b84:	mov    (%r8),%rbp
  823b87:	mov    %rax,0x10(%rsp)
  823b8c:	test   %rax,%rax
  823b8f:	je     823c0f <gpui_gpu::renderer::images::prepare+0xdf>
  823b91:	mov    %rcx,0xa0(%rsp)
  823b99:	test   %rbp,%rbp
  823b9c:	je     823d58 <gpui_gpu::renderer::images::prepare+0x228>
  823ba2:	cmp    0x48(%rbp),%r12
  823ba6:	ja     823d58 <gpui_gpu::renderer::images::prepare+0x228>
  823bac:	mov    0x8(%rbp),%rdi
  823bb0:	mov    0x10(%rbp),%rax
  823bb4:	lea    (%rdi,%rax,8),%rsi
  823bb8:	movq   $0x1,0xd0(%rsp)
  823bc4:	mov    %r14,0xd8(%rsp)
  823bcc:	movq   $0x0,0xe0(%rsp)
  823bd8:	movq   $0x0,0xf0(%rsp)
  823be4:	lea    0xd0(%rsp),%rdx
  823bec:	mov    %r8,%rbx
  823bef:	call   8246f0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  823bf4:	mov    %rbx,%r8
  823bf7:	test   %al,%al
  823bf9:	je     823d58 <gpui_gpu::renderer::images::prepare+0x228>
  823bff:	movq   $0x0,0x60(%rbp)
  823c07:	jmp    823d3c <gpui_gpu::renderer::images::prepare+0x20c>
  823c0c:	mov    (%r8),%rbp
  823c0f:	movq   $0x0,(%r8)
  823c16:	test   %rbp,%rbp
  823c19:	je     823d3c <gpui_gpu::renderer::images::prepare+0x20c>
  823c1f:	mov    0x0(%rbp),%rsi
  823c23:	test   %rsi,%rsi
  823c26:	je     823c3b <gpui_gpu::renderer::images::prepare+0x10b>
  823c28:	mov    0x8(%rbp),%rdi
  823c2c:	shl    $0x3,%rsi
  823c30:	mov    $0x8,%edx
  823c35:	call   *0x65d275(%rip)        # e80eb0 <_DYNAMIC+0x248>
  823c3b:	mov    0x20(%rbp),%rsi
  823c3f:	test   %rsi,%rsi
  823c42:	je     823c6a <gpui_gpu::renderer::images::prepare+0x13a>
  823c44:	mov    %rsi,%rax
  823c47:	shl    $0x4,%rax
  823c4b:	add    %rax,%rsi
  823c4e:	add    $0x21,%rsi
  823c52:	je     823c6a <gpui_gpu::renderer::images::prepare+0x13a>
  823c54:	mov    0x18(%rbp),%rdi
  823c58:	sub    %rax,%rdi
  823c5b:	add    $0xfffffffffffffff0,%rdi
  823c5f:	mov    $0x10,%edx
  823c64:	call   *0x65d246(%rip)        # e80eb0 <_DYNAMIC+0x248>
  823c6a:	mov    $0x80,%esi
  823c6f:	mov    $0x8,%edx
  823c74:	mov    %rbp,%rdi
  823c77:	call   *0x65d233(%rip)        # e80eb0 <_DYNAMIC+0x248>
  823c7d:	shl    $0x4,%r12
  823c81:	cmp    $0x101,%r12
  823c88:	mov    $0x100,%eax
  823c8d:	cmovae %r12,%rax
  823c91:	dec    %rax
  823c94:	bsr    %rax,%rcx
  823c98:	not    %ecx
  823c9a:	mov    $0xffffffffffffffff,%rbx
  823ca1:	shr    %cl,%rbx
  823ca4:	inc    %rbx
  823ca7:	lea    -0x74ef38(%rip),%rax        # d4d76 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x16>
  823cae:	mov    %rax,0x18(%rsp)
  823cb3:	movq   $0xa,0x20(%rsp)
  823cbc:	mov    %rbx,0x28(%rsp)
  823cc1:	movl   $0x88,0x30(%rsp)
  823cc9:	movb   $0x0,0x34(%rsp)
  823cce:	lea    0xd0(%rsp),%rdi
  823cd6:	lea    0x18(%rsp),%rdx
  823cdb:	mov    (%rsp),%rsi
  823cdf:	call   *0x65d59b(%rip)        # e81280 <_DYNAMIC+0x618>
  823ce5:	mov    %rbx,0xf0(%rsp)
  823ced:	mov    0x0(%r13),%rax
  823cf1:	lock decq (%rax)
  823cf5:	jne    823d00 <gpui_gpu::renderer::images::prepare+0x1d0>
  823cf7:	mov    %r13,%rdi
  823cfa:	call   *0x65d470(%rip)        # e81170 <_DYNAMIC+0x508>
  823d00:	mov    0x8(%r13),%rax
  823d04:	lock decq (%rax)
  823d08:	jne    823d14 <gpui_gpu::renderer::images::prepare+0x1e4>
  823d0a:	lea    0x8(%r13),%rdi
  823d0e:	call   *0x65d464(%rip)        # e81178 <_DYNAMIC+0x510>
  823d14:	mov    0xf0(%rsp),%rax
  823d1c:	mov    %rax,0x20(%r13)
  823d20:	movdqu 0xd0(%rsp),%xmm0
  823d29:	movups 0xe0(%rsp),%xmm1
  823d31:	movups %xmm1,0x10(%r13)
  823d36:	movdqu %xmm0,0x0(%r13)
  823d3c:	movl   $0xffffffff,(%r15)
  823d43:	mov    %r15,%rax
  823d46:	add    $0x1e8,%rsp
  823d4d:	pop    %rbx
  823d4e:	pop    %r12
  823d50:	pop    %r13
  823d52:	pop    %r14
  823d54:	pop    %r15
  823d56:	pop    %rbp
  823d57:	ret
  823d58:	cmp    $0x1,%r12
  823d5c:	mov    %r12,%rax
  823d5f:	adc    $0xffffffffffffffff,%rax
  823d63:	bsr    %rax,%rcx
  823d67:	not    %ecx
  823d69:	mov    $0xffffffffffffffff,%rax
  823d70:	shr    %cl,%rax
  823d73:	cmp    $0x2,%r12
  823d77:	mov    $0x0,%r12d
  823d7d:	cmovae %rax,%r12
  823d81:	inc    %r12
  823d84:	je     824478 <gpui_gpu::renderer::images::prepare+0x948>
  823d8a:	mov    %r8,0xc8(%rsp)
  823d92:	mov    %fs:0x0,%rax
  823d9b:	lea    -0x28(%rax),%rax
  823da2:	mov    %rax,%rcx
  823da5:	cmpb   $0x1,0x10(%rax)
  823da9:	mov    %r15,0xa8(%rsp)
  823db1:	mov    %r13,0x8(%rsp)
  823db6:	jne    824484 <gpui_gpu::renderer::images::prepare+0x954>
  823dbc:	mov    (%rcx),%rax
  823dbf:	mov    0x8(%rcx),%rdx
  823dc3:	mov    0x10(%rsp),%rbx
  823dc8:	lea    0x1(%rax),%rsi
  823dcc:	mov    %rsi,(%rcx)
  823dcf:	movq   $0x0,0x18(%rsp)
  823dd8:	movq   $0x8,0x20(%rsp)
  823de1:	movq   $0x0,0x28(%rsp)
  823dea:	movups 0x60baaf(%rip),%xmm0        # e2f8a0 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x18>
  823df1:	movups %xmm0,0x30(%rsp)
  823df6:	movdqu 0x60bab2(%rip),%xmm0        # e2f8b0 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x28>
  823dfe:	movdqu %xmm0,0x40(%rsp)
  823e04:	mov    %rax,0x50(%rsp)
  823e09:	mov    %rdx,0x58(%rsp)
  823e0e:	mov    %r12,0x60(%rsp)
  823e13:	pxor   %xmm0,%xmm0
  823e17:	movdqu %xmm0,0x68(%rsp)
  823e1d:	movdqu %xmm0,0x78(%rsp)
  823e23:	movdqu %xmm0,0x88(%rsp)
  823e2c:	lea    0xd0(%rsp),%rdi
  823e34:	mov    $0x8,%edx
  823e39:	mov    $0x8,%r8d
  823e3f:	mov    $0x8,%r9d
  823e45:	xor    %esi,%esi
  823e47:	mov    %rbx,%rcx
  823e4a:	call   8250a0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823e4f:	cmpl   $0x1,0xd0(%rsp)
  823e57:	jne    823ec4 <gpui_gpu::renderer::images::prepare+0x394>
  823e59:	mov    0xa8(%rsp),%r15
  823e61:	movl   $0x6,(%r15)
  823e68:	mov    0x18(%rsp),%rsi
  823e6d:	test   %rsi,%rsi
  823e70:	je     823e86 <gpui_gpu::renderer::images::prepare+0x356>
  823e72:	mov    0x20(%rsp),%rdi
  823e77:	shl    $0x3,%rsi
  823e7b:	mov    $0x8,%edx
  823e80:	call   *0x65d02a(%rip)        # e80eb0 <_DYNAMIC+0x248>
  823e86:	mov    0x38(%rsp),%rsi
  823e8b:	test   %rsi,%rsi
  823e8e:	je     823d43 <gpui_gpu::renderer::images::prepare+0x213>
  823e94:	mov    %rsi,%rax
  823e97:	shl    $0x4,%rax
  823e9b:	add    %rax,%rsi
  823e9e:	add    $0x21,%rsi
  823ea2:	je     823d43 <gpui_gpu::renderer::images::prepare+0x213>
  823ea8:	mov    0x30(%rsp),%rdi
  823ead:	sub    %rax,%rdi
  823eb0:	add    $0xfffffffffffffff0,%rdi
  823eb4:	mov    $0x10,%edx
  823eb9:	call   *0x65cff1(%rip)        # e80eb0 <_DYNAMIC+0x248>
  823ebf:	jmp    823d43 <gpui_gpu::renderer::images::prepare+0x213>
  823ec4:	mov    %r12,0x98(%rsp)
  823ecc:	mov    %rbp,0xc0(%rsp)
  823ed4:	mov    0xd8(%rsp),%rax
  823edc:	mov    %rax,0x20(%rsp)
  823ee1:	mov    %rbx,0x18(%rsp)
  823ee6:	cmp    0x40(%rsp),%rbx
  823eeb:	ja     8244a0 <gpui_gpu::renderer::images::prepare+0x970>
  823ef1:	xor    %r12d,%r12d
  823ef4:	mov    0x98(%rsp),%r15
  823efc:	jmp    823f18 <gpui_gpu::renderer::images::prepare+0x3e8>
  823efe:	xchg   %ax,%ax
  823f00:	add    $0x8,%r12
  823f04:	mov    0x20(%rsp),%rax
  823f09:	mov    %rbx,(%rax,%r15,8)
  823f0d:	inc    %r15
  823f10:	mov    %r15,0x28(%rsp)
  823f15:	mov    %r13,%r15
  823f18:	test   %r12,%r12
  823f1b:	je     823f40 <gpui_gpu::renderer::images::prepare+0x410>
  823f1d:	cmp    %rbp,%r12
  823f20:	je     823f40 <gpui_gpu::renderer::images::prepare+0x410>
  823f22:	mov    (%r12),%rcx
  823f26:	cmpb   $0x0,0x10(%rcx)
  823f2a:	je     823f6e <gpui_gpu::renderer::images::prepare+0x43e>
  823f2c:	mov    0x20(%rcx),%rax
  823f30:	shl    $0x4,%rax
  823f34:	mov    $0x8,%r8d
  823f3a:	jmp    823f81 <gpui_gpu::renderer::images::prepare+0x451>
  823f3c:	nopl   0x0(%rax)
  823f40:	test   %r14,%r14
  823f43:	je     824008 <gpui_gpu::renderer::images::prepare+0x4d8>
  823f49:	mov    (%r14),%rax
  823f4c:	mov    0x10(%rax),%rcx
  823f50:	test   %rcx,%rcx
  823f53:	je     824008 <gpui_gpu::renderer::images::prepare+0x4d8>
  823f59:	mov    0x8(%rax),%r12
  823f5d:	lea    (%r12,%rcx,8),%rbp
  823f61:	xor    %r14d,%r14d
  823f64:	mov    (%r12),%rcx
  823f68:	cmpb   $0x0,0x10(%rcx)
  823f6c:	jne    823f2c <gpui_gpu::renderer::images::prepare+0x3fc>
  823f6e:	movzbl 0x11(%rcx),%edx
  823f72:	movzbl 0x12(%rcx),%esi
  823f76:	mov    0x20(%rcx),%rax
  823f7a:	shl    $0x2,%edx
  823f7d:	lea    (%rdx,%rsi,2),%r8d
  823f81:	mov    0x70(%rsp),%rdx
  823f86:	add    %rax,%rdx
  823f89:	jb     823e59 <gpui_gpu::renderer::images::prepare+0x329>
  823f8f:	mov    0x28(%rcx),%rbx
  823f93:	mov    %rdx,0x70(%rsp)
  823f98:	cmp    $0x4000000,%rdx
  823f9f:	ja     823e59 <gpui_gpu::renderer::images::prepare+0x329>
  823fa5:	mov    %r15,%rcx
  823fa8:	shr    $0x20,%rcx
  823fac:	jne    823e59 <gpui_gpu::renderer::images::prepare+0x329>
  823fb2:	test   %r15d,%r15d
  823fb5:	js     823e59 <gpui_gpu::renderer::images::prepare+0x329>
  823fbb:	mov    %rax,%r13
  823fbe:	shr    $0x4,%r13
  823fc2:	and    $0xf,%eax
  823fc5:	add    %r15,%r13
  823fc8:	cmp    $0x1,%rax
  823fcc:	sbb    $0xffffffffffffffff,%r13
  823fd0:	lea    0xd0(%rsp),%rdi
  823fd8:	lea    0x30(%rsp),%rsi
  823fdd:	mov    %rbx,%rdx
  823fe0:	mov    %r15d,%ecx
  823fe3:	call   826a00 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  823fe8:	mov    0x28(%rsp),%r15
  823fed:	cmp    0x18(%rsp),%r15
  823ff2:	jne    823f00 <gpui_gpu::renderer::images::prepare+0x3d0>
  823ff8:	lea    0x18(%rsp),%rdi
  823ffd:	call   *0x65d32d(%rip)        # e81330 <_DYNAMIC+0x6c8>
  824003:	jmp    823f00 <gpui_gpu::renderer::images::prepare+0x3d0>
  824008:	movabs $0xffffffffffffff0,%rax
  824012:	cmp    %rax,%r15
  824015:	ja     823e59 <gpui_gpu::renderer::images::prepare+0x329>
  82401b:	lea    0xd0(%rsp),%rdi
  824023:	mov    (%rsp),%rsi
  824027:	call   *0x65d30b(%rip)        # e81338 <_DYNAMIC+0x6d0>
  82402d:	mov    %r15,%rbx
  824030:	shl    $0x4,%rbx
  824034:	add    $0xff,%rbx
  82403b:	and    $0xffffffffffffff00,%rbx
  824042:	cmp    0x120(%rsp),%rbx
  82404a:	ja     823e59 <gpui_gpu::renderer::images::prepare+0x329>
  824050:	lea    0xd0(%rsp),%rdi
  824058:	mov    (%rsp),%rsi
  82405c:	call   *0x65d2d6(%rip)        # e81338 <_DYNAMIC+0x6d0>
  824062:	cmp    0x130(%rsp),%rbx
  82406a:	ja     823e59 <gpui_gpu::renderer::images::prepare+0x329>
  824070:	mov    0x8(%rsp),%rax
  824075:	mov    0x20(%rax),%rax
  824079:	cmp    %rbx,%rax
  82407c:	jb     8240a4 <gpui_gpu::renderer::images::prepare+0x574>
  82407e:	lea    0x0(,%rbx,4),%rcx
  824086:	movabs $0x3fffffffffffff1,%rdx
  824090:	cmp    %rdx,%r15
  824093:	setb   %dl
  824096:	cmp    %rcx,%rax
  824099:	seta   %al
  82409c:	test   %al,%dl
  82409e:	je     824132 <gpui_gpu::renderer::images::prepare+0x602>
  8240a4:	lea    -0x74f32b(%rip),%rax        # d4d80 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x20>
  8240ab:	mov    %rax,0x1c8(%rsp)
  8240b3:	movq   $0x1d,0x1d0(%rsp)
  8240bf:	mov    %rbx,0x1d8(%rsp)
  8240c7:	movl   $0x88,0x1e0(%rsp)
  8240d2:	movb   $0x0,0x1e4(%rsp)
  8240da:	lea    0xd0(%rsp),%rdi
  8240e2:	lea    0x1c8(%rsp),%rdx
  8240ea:	mov    (%rsp),%rsi
  8240ee:	call   *0x65d18c(%rip)        # e81280 <_DYNAMIC+0x618>
  8240f4:	mov    %rbx,0xf0(%rsp)
  8240fc:	mov    0x8(%rsp),%r14
  824101:	mov    %r14,%rdi
  824104:	call   823630 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  824109:	mov    0xf0(%rsp),%rax
  824111:	mov    %rax,0x20(%r14)
  824115:	movdqu 0xd0(%rsp),%xmm0
  82411e:	movdqu 0xe0(%rsp),%xmm1
  824127:	movdqu %xmm1,0x10(%r14)
  82412d:	movdqu %xmm0,(%r14)
  824132:	movq   $0x0,(%rsp)
  82413a:	mov    0x65d0f7(%rip),%r14        # e81238 <_DYNAMIC+0x5d0>
  824141:	mov    (%rsp),%rdx
  824145:	test   %rdx,%rdx
  824148:	je     824154 <gpui_gpu::renderer::images::prepare+0x624>
  82414a:	cmp    0xb8(%rsp),%rdx
  824152:	jne    824191 <gpui_gpu::renderer::images::prepare+0x661>
  824154:	mov    0xa0(%rsp),%rax
  82415c:	test   %rax,%rax
  82415f:	je     824314 <gpui_gpu::renderer::images::prepare+0x7e4>
  824165:	mov    (%rax),%rax
  824168:	mov    0x10(%rax),%rcx
  82416c:	test   %rcx,%rcx
  82416f:	je     824314 <gpui_gpu::renderer::images::prepare+0x7e4>
  824175:	mov    0x8(%rax),%rdx
  824179:	lea    (%rdx,%rcx,8),%rax
  82417d:	mov    %rax,0xb8(%rsp)
  824185:	movq   $0x0,0xa0(%rsp)
  824191:	mov    (%rdx),%rax
  824194:	mov    0x28(%rax),%r12
  824198:	movzbl 0x10(%rax),%ebx
  82419c:	mov    0x18(%rax),%rbp
  8241a0:	mov    0x20(%rax),%r13
  8241a4:	mov    %r12,0xd0(%rsp)
  8241ac:	cmpq   $0x0,0x48(%rsp)
  8241b2:	je     8242f9 <gpui_gpu::renderer::images::prepare+0x7c9>
  8241b8:	add    $0x8,%rdx
  8241bc:	mov    %rdx,(%rsp)
  8241c0:	lea    0x50(%rsp),%rdi
  8241c5:	lea    0xd0(%rsp),%rsi
  8241cd:	call   8270f0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8241d2:	mov    %rax,%rsi
  8241d5:	shr    $0x39,%rsi
  8241d9:	mov    0x30(%rsp),%rcx
  8241de:	mov    0x38(%rsp),%rdx
  8241e3:	movd   %esi,%xmm0
  8241e7:	punpcklbw %xmm0,%xmm0
  8241eb:	pshuflw $0x0,%xmm0,%xmm0
  8241f0:	pshufd $0x44,%xmm0,%xmm0
  8241f5:	xor    %esi,%esi
  8241f7:	and    %rdx,%rax
  8241fa:	movdqu (%rcx,%rax,1),%xmm1
  8241ff:	movdqa %xmm1,%xmm2
  824203:	pcmpeqb %xmm0,%xmm2
  824207:	pmovmskb %xmm2,%edi
  82420b:	test   %edi,%edi
  82420d:	je     824237 <gpui_gpu::renderer::images::prepare+0x707>
  82420f:	tzcnt  %edi,%r9d
  824214:	add    %rax,%r9
  824217:	and    %rdx,%r9
  82421a:	shl    $0x4,%r9
  82421e:	mov    %rcx,%r8
  824221:	sub    %r9,%r8
  824224:	cmp    -0x10(%r8),%r12
  824228:	je     824258 <gpui_gpu::renderer::images::prepare+0x728>
  82422a:	lea    -0x1(%rdi),%r8d
  82422e:	and    %di,%r8w
  824232:	mov    %r8d,%edi
  824235:	jne    82420f <gpui_gpu::renderer::images::prepare+0x6df>
  824237:	pcmpeqd %xmm2,%xmm2
  82423b:	pcmpeqb %xmm2,%xmm1
  82423f:	pmovmskb %xmm1,%edi
  824243:	test   %edi,%edi
  824245:	jne    8242f9 <gpui_gpu::renderer::images::prepare+0x7c9>
  82424b:	add    %rsi,%rax
  82424e:	add    $0x10,%rax
  824252:	add    $0x10,%rsi
  824256:	jmp    8241f7 <gpui_gpu::renderer::images::prepare+0x6c7>
  824258:	mov    -0x8(%r8),%r12d
  82425c:	shl    $0x4,%r12
  824260:	test   %bl,%bl
  824262:	je     8242b7 <gpui_gpu::renderer::images::prepare+0x787>
  824264:	test   %r13,%r13
  824267:	je     824141 <gpui_gpu::renderer::images::prepare+0x611>
  82426d:	nopl   (%rax)
  824270:	cmp    $0x1000,%r13
  824277:	mov    $0x1000,%r15d
  82427d:	cmovb  %r13,%r15
  824281:	mov    %r15d,%ebx
  824284:	shl    $0x4,%ebx
  824287:	mov    0xb0(%rsp),%rdi
  82428f:	mov    0x8(%rsp),%rsi
  824294:	mov    %r12,%rdx
  824297:	mov    %rbp,%rcx
  82429a:	mov    %rbx,%r8
  82429d:	call   *%r14
  8242a0:	mov    %r15,%rax
  8242a3:	shl    $0x4,%rax
  8242a7:	add    %rax,%rbp
  8242aa:	add    %rbx,%r12
  8242ad:	sub    %r15,%r13
  8242b0:	jne    824270 <gpui_gpu::renderer::images::prepare+0x740>
  8242b2:	jmp    824141 <gpui_gpu::renderer::images::prepare+0x611>
  8242b7:	test   %r13,%r13
  8242ba:	je     824141 <gpui_gpu::renderer::images::prepare+0x611>
  8242c0:	cmp    $0x10000,%r13
  8242c7:	mov    $0x10000,%ebx
  8242cc:	cmovb  %r13,%rbx
  8242d0:	mov    0xb0(%rsp),%rdi
  8242d8:	mov    0x8(%rsp),%rsi
  8242dd:	mov    %r12,%rdx
  8242e0:	mov    %rbp,%rcx
  8242e3:	mov    %rbx,%r8
  8242e6:	call   *%r14
  8242e9:	add    %rbx,%rbp
  8242ec:	add    %rbx,%r12
  8242ef:	sub    %rbx,%r13
  8242f2:	jne    8242c0 <gpui_gpu::renderer::images::prepare+0x790>
  8242f4:	jmp    824141 <gpui_gpu::renderer::images::prepare+0x611>
  8242f9:	lea    -0x74f5a0(%rip),%rdi        # d4d60 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  824300:	lea    0x60b5b9(%rip),%rdx        # e2f8c0 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x38>
  824307:	mov    $0x16,%esi
  82430c:	call   *0x65cef6(%rip)        # e81208 <_DYNAMIC+0x5a0>
  824312:	ud2
  824314:	mov    0x10(%rsp),%rax
  824319:	mov    %rax,0x68(%rsp)
  82431e:	mov    0x70(%rsp),%rax
  824323:	mov    %rax,0x78(%rsp)
  824328:	mov    0x98(%rsp),%rax
  824330:	shl    $0x4,%rax
  824334:	mov    %rax,0x80(%rsp)
  82433c:	mov    0x8(%rsp),%rax
  824341:	mov    0x20(%rax),%rax
  824345:	mov    %rax,0x88(%rsp)
  82434d:	mov    0x40(%rsp),%rax
  824352:	add    0x48(%rsp),%rax
  824357:	mov    %rax,0x90(%rsp)
  82435f:	mov    0x88(%rsp),%rax
  824367:	mov    %rax,0x140(%rsp)
  82436f:	mov    0x90(%rsp),%rax
  824377:	mov    %rax,0x148(%rsp)
  82437f:	mov    0x78(%rsp),%rax
  824384:	mov    %rax,0x130(%rsp)
  82438c:	mov    0x80(%rsp),%rax
  824394:	mov    %rax,0x138(%rsp)
  82439c:	movups 0x68(%rsp),%xmm0
  8243a1:	movaps %xmm0,0x120(%rsp)
  8243a9:	movups 0x58(%rsp),%xmm0
  8243ae:	movaps %xmm0,0x110(%rsp)
  8243b6:	movups 0x48(%rsp),%xmm0
  8243bb:	movaps %xmm0,0x100(%rsp)
  8243c3:	movups 0x18(%rsp),%xmm0
  8243c8:	movups 0x28(%rsp),%xmm1
  8243cd:	movups 0x38(%rsp),%xmm2
  8243d2:	movaps %xmm2,0xf0(%rsp)
  8243da:	movaps %xmm1,0xe0(%rsp)
  8243e2:	movaps %xmm0,0xd0(%rsp)
  8243ea:	call   823b00 <alloc::boxed::box_new_uninit>
  8243ef:	mov    %rax,%rbx
  8243f2:	movaps 0x140(%rsp),%xmm0
  8243fa:	movups %xmm0,0x70(%rax)
  8243fe:	movaps 0x130(%rsp),%xmm0
  824406:	movups %xmm0,0x60(%rax)
  82440a:	movaps 0x120(%rsp),%xmm0
  824412:	movups %xmm0,0x50(%rax)
  824416:	movaps 0x110(%rsp),%xmm0
  82441e:	movups %xmm0,0x40(%rax)
  824422:	movdqa 0xd0(%rsp),%xmm0
  82442b:	movaps 0xe0(%rsp),%xmm1
  824433:	movaps 0xf0(%rsp),%xmm2
  82443b:	movaps 0x100(%rsp),%xmm3
  824443:	movups %xmm3,0x30(%rax)
  824447:	movups %xmm2,0x20(%rax)
  82444b:	movups %xmm1,0x10(%rax)
  82444f:	movdqu %xmm0,(%rax)
  824453:	mov    0xc0(%rsp),%rdi
  82445b:	call   8233a0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  824460:	mov    0xc8(%rsp),%rax
  824468:	mov    %rbx,(%rax)
  82446b:	mov    0xa8(%rsp),%r15
  824473:	jmp    823d3c <gpui_gpu::renderer::images::prepare+0x20c>
  824478:	movl   $0x6,(%r15)
  82447f:	jmp    823d43 <gpui_gpu::renderer::images::prepare+0x213>
  824484:	mov    %rcx,%rbx
  824487:	call   *0x65cdfb(%rip)        # e81288 <_DYNAMIC+0x620>
  82448d:	mov    %rbx,%rcx
  824490:	mov    %rax,(%rbx)
  824493:	mov    %rdx,0x8(%rbx)
  824497:	movb   $0x1,0x10(%rbx)
  82449b:	jmp    823dc3 <gpui_gpu::renderer::images::prepare+0x293>
  8244a0:	lea    0x30(%rsp),%rdi
  8244a5:	mov    0x10(%rsp),%rsi
  8244aa:	lea    0x50(%rsp),%rdx
  8244af:	xor    %ecx,%ecx
  8244b1:	call   *0x65ce51(%rip)        # e81308 <_DYNAMIC+0x6a0>
  8244b7:	cmp    $0xffffffffffffffff,%rax
  8244bb:	jne    823e59 <gpui_gpu::renderer::images::prepare+0x329>
  8244c1:	jmp    823ef1 <gpui_gpu::renderer::images::prepare+0x3c1>
  8244c6:	mov    %rax,%rbx
  8244c9:	lea    0xd0(%rsp),%rdi
  8244d1:	call   823760 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8244d6:	mov    %rbx,%rdi
  8244d9:	call   e2d990 <_Unwind_Resume@plt>
  8244de:	mov    %rax,%rbx
  8244e1:	mov    0xf0(%rsp),%rax
  8244e9:	mov    %rax,0x20(%r14)
  8244ed:	movups 0xd0(%rsp),%xmm0
  8244f5:	movups 0xe0(%rsp),%xmm1
  8244fd:	movups %xmm1,0x10(%r14)
  824502:	movups %xmm0,(%r14)
  824506:	lea    0x18(%rsp),%rdi
  82450b:	call   823760 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  824510:	mov    %rbx,%rdi
  824513:	call   e2d990 <_Unwind_Resume@plt>
  824518:	mov    %r13,%r14
  82451b:	mov    %rax,%rbx
  82451e:	jmp    82453a <gpui_gpu::renderer::images::prepare+0xa0a>
  824520:	mov    %rax,%rbx
  824523:	mov    %r13,%r14
  824526:	mov    0x8(%r13),%rax
  82452a:	lock decq (%rax)
  82452e:	jne    82453a <gpui_gpu::renderer::images::prepare+0xa0a>
  824530:	lea    0x8(%r14),%rdi
  824534:	call   *0x65cc3e(%rip)        # e81178 <_DYNAMIC+0x510>
  82453a:	mov    0xf0(%rsp),%rax
  824542:	mov    %rax,0x20(%r14)
  824546:	movups 0xd0(%rsp),%xmm0
  82454e:	movups 0xe0(%rsp),%xmm1
  824556:	movups %xmm1,0x10(%r14)
  82455b:	movups %xmm0,(%r14)
  82455f:	mov    %rbx,%rdi
  824562:	call   e2d990 <_Unwind_Resume@plt>
  824567:	call   *0x65c94b(%rip)        # e80eb8 <_DYNAMIC+0x250>
  82456d:	jmp    824573 <gpui_gpu::renderer::images::prepare+0xa43>
  82456f:	jmp    824573 <gpui_gpu::renderer::images::prepare+0xa43>
  824571:	jmp    824573 <gpui_gpu::renderer::images::prepare+0xa43>
  824573:	mov    %rax,%rbx
  824576:	lea    0x18(%rsp),%rdi
  82457b:	call   823760 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  824580:	mov    %rbx,%rdi
  824583:	call   e2d990 <_Unwind_Resume@plt>

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008246f0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  8246f0:	push   %r15
  8246f2:	push   %r14
  8246f4:	push   %rbx
  8246f5:	mov    (%rdx),%r9
  8246f8:	mov    0x8(%rdx),%r11
  8246fc:	mov    0x10(%rdx),%rbx
  824700:	mov    0x18(%rdx),%r10
  824704:	mov    0x20(%rdx),%r8
  824708:	mov    0x28(%rdx),%rcx
  82470c:	test   $0x1,%r9b
  824710:	jne    8247aa <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  824716:	mov    %rbx,%rax
  824719:	jmp    82473b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  82471b:	nopl   0x0(%rax,%rax,1)
  824720:	lea    0x8(%rax),%rbx
  824724:	mov    %rbx,%r14
  824727:	add    $0x8,%rdi
  82472b:	mov    (%rax),%r15
  82472e:	mov    %r14,%rax
  824731:	cmp    0x28(%r15),%rdx
  824735:	jne    8247ff <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82473b:	cmp    %rsi,%rdi
  82473e:	je     8247d8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  824744:	mov    (%rdi),%rdx
  824747:	test   %rax,%rax
  82474a:	je     824753 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  82474c:	cmp    %r10,%rax
  82474f:	jne    824720 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  824751:	xor    %ebx,%ebx
  824753:	xor    %eax,%eax
  824755:	test   %r8,%r8
  824758:	je     824801 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82475e:	cmp    %rcx,%r8
  824761:	je     824801 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  824767:	mov    %r8,%rax
  82476a:	add    $0x8,%r8
  82476e:	xor    %r14d,%r14d
  824771:	jmp    824727 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  824773:	mov    (%r11),%rax
  824776:	mov    0x8(%rax),%rbx
  82477a:	mov    0x10(%rax),%rax
  82477e:	lea    (%rbx,%rax,8),%r10
  824782:	test   %rax,%rax
  824785:	je     8247c1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  824787:	xor    %r11d,%r11d
  82478a:	nopw   0x0(%rax,%rax,1)
  824790:	mov    %r8,%rax
  824793:	mov    %rbx,%r8
  824796:	add    $0x8,%rbx
  82479a:	add    $0x8,%rdi
  82479e:	mov    (%r8),%r14
  8247a1:	mov    %rax,%r8
  8247a4:	cmp    0x28(%r14),%rdx
  8247a8:	jne    8247ff <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8247aa:	cmp    %rsi,%rdi
  8247ad:	je     8247d8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  8247af:	mov    (%rdi),%rdx
  8247b2:	test   %rbx,%rbx
  8247b5:	je     8247bc <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  8247b7:	cmp    %r10,%rbx
  8247ba:	jne    824790 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  8247bc:	test   %r11,%r11
  8247bf:	jne    824773 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  8247c1:	xor    %eax,%eax
  8247c3:	test   %r8,%r8
  8247c6:	je     824801 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8247c8:	cmp    %rcx,%r8
  8247cb:	je     824801 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8247cd:	lea    0x8(%r8),%rax
  8247d1:	xor    %ebx,%ebx
  8247d3:	xor    %r11d,%r11d
  8247d6:	jmp    82479a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  8247d8:	test   %rbx,%rbx
  8247db:	sete   %dl
  8247de:	cmp    %r10,%rbx
  8247e1:	sete   %al
  8247e4:	or     %dl,%al
  8247e6:	test   $0x1,%r9b
  8247ea:	je     824807 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  8247ec:	test   %al,%al
  8247ee:	je     8247ff <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8247f0:	test   %r11,%r11
  8247f3:	je     82480b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8247f5:	mov    (%r11),%rax
  8247f8:	cmpq   $0x0,0x10(%rax)
  8247fd:	je     82480b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8247ff:	xor    %eax,%eax
  824801:	pop    %rbx
  824802:	pop    %r14
  824804:	pop    %r15
  824806:	ret
  824807:	test   %al,%al
  824809:	je     8247ff <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82480b:	test   %r8,%r8
  82480e:	sete   %dl
  824811:	cmp    %rcx,%r8
  824814:	sete   %al
  824817:	or     %dl,%al
  824819:	pop    %rbx
  82481a:	pop    %r14
  82481c:	pop    %r15
  82481e:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::add bytes=366 frame=0

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824940 <<gpui_gpu::renderer::coverage::Interval>::add>:
  824940:	xorpd  %xmm4,%xmm4
  824944:	ucomisd %xmm4,%xmm2
  824948:	jne    824954 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  82494a:	jp     824954 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  82494c:	ucomisd %xmm4,%xmm3
  824950:	jne    824954 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  824952:	jnp    82496c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  824954:	ucomisd %xmm4,%xmm0
  824958:	jne    82497f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  82495a:	jp     82497f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  82495c:	ucomisd %xmm4,%xmm1
  824960:	jne    82497f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  824962:	jp     82497f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  824964:	movapd %xmm2,%xmm0
  824968:	movapd %xmm3,%xmm1
  82496c:	movsd  %xmm0,0x8(%rdi)
  824971:	movsd  %xmm1,0x10(%rdi)
  824976:	mov    $0x1,%ecx
  82497b:	mov    %rcx,(%rdi)
  82497e:	ret
  82497f:	addsd  %xmm2,%xmm0
  824983:	addsd  %xmm3,%xmm1
  824987:	movq   %xmm0,%rdx
  82498c:	movq   %xmm1,%rcx
  824991:	ucomisd %xmm0,%xmm0
  824995:	setp   %al
  824998:	movabs $0xfff0000000000000,%rsi
  8249a2:	cmp    %rsi,%rdx
  8249a5:	sete   %sil
  8249a9:	or     %al,%sil
  8249ac:	movabs $0x7fffffffffffffff,%rax
  8249b6:	jne    8249de <<gpui_gpu::renderer::coverage::Interval>::add+0x9e>
  8249b8:	mov    %rdx,%rsi
  8249bb:	and    %rax,%rsi
  8249be:	je     8249ca <<gpui_gpu::renderer::coverage::Interval>::add+0x8a>
  8249c0:	cmp    %rsi,%rdx
  8249c3:	jne    8249d6 <<gpui_gpu::renderer::coverage::Interval>::add+0x96>
  8249c5:	dec    %rdx
  8249c8:	jmp    8249d9 <<gpui_gpu::renderer::coverage::Interval>::add+0x99>
  8249ca:	movabs $0x8000000000000001,%rdx
  8249d4:	jmp    8249d9 <<gpui_gpu::renderer::coverage::Interval>::add+0x99>
  8249d6:	inc    %rdx
  8249d9:	movq   %rdx,%xmm0
  8249de:	ucomisd %xmm1,%xmm1
  8249e2:	setp   %dl
  8249e5:	movabs $0x7ff0000000000000,%rsi
  8249ef:	cmp    %rsi,%rcx
  8249f2:	sete   %sil
  8249f6:	or     %dl,%sil
  8249f9:	jne    824a1c <<gpui_gpu::renderer::coverage::Interval>::add+0xdc>
  8249fb:	mov    %rcx,%rdx
  8249fe:	and    %rax,%rdx
  824a01:	je     824a0d <<gpui_gpu::renderer::coverage::Interval>::add+0xcd>
  824a03:	cmp    %rdx,%rcx
  824a06:	jne    824a14 <<gpui_gpu::renderer::coverage::Interval>::add+0xd4>
  824a08:	inc    %rcx
  824a0b:	jmp    824a17 <<gpui_gpu::renderer::coverage::Interval>::add+0xd7>
  824a0d:	mov    $0x1,%ecx
  824a12:	jmp    824a17 <<gpui_gpu::renderer::coverage::Interval>::add+0xd7>
  824a14:	dec    %rcx
  824a17:	movq   %rcx,%xmm1
  824a1c:	movq   %xmm0,%rdx
  824a21:	and    %rax,%rdx
  824a24:	xor    %ecx,%ecx
  824a26:	movabs $0x7fefffffffffffff,%rsi
  824a30:	cmp    %rsi,%rdx
  824a33:	jg     824aaa <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  824a35:	ucomisd %xmm1,%xmm0
  824a39:	ja     824aaa <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  824a3b:	xorpd  %xmm2,%xmm2
  824a3f:	ucomisd %xmm2,%xmm0
  824a43:	jne    824a47 <<gpui_gpu::renderer::coverage::Interval>::add+0x107>
  824a45:	jnp    824a71 <<gpui_gpu::renderer::coverage::Interval>::add+0x131>
  824a47:	dec    %rdx
  824a4a:	movq   %xmm1,%rcx
  824a4f:	and    %rax,%rcx
  824a52:	cmp    %rsi,%rcx
  824a55:	setg   %sil
  824a59:	xor    %ecx,%ecx
  824a5b:	movabs $0xfffffffffffff,%r8
  824a65:	cmp    %r8,%rdx
  824a68:	jb     824aaa <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  824a6a:	test   %sil,%sil
  824a6d:	je     824a7e <<gpui_gpu::renderer::coverage::Interval>::add+0x13e>
  824a6f:	jmp    824aaa <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  824a71:	movq   %xmm1,%rcx
  824a76:	and    %rax,%rcx
  824a79:	cmp    %rsi,%rcx
  824a7c:	jg     824aa8 <<gpui_gpu::renderer::coverage::Interval>::add+0x168>
  824a7e:	ucomisd %xmm2,%xmm1
  824a82:	jne    824a8a <<gpui_gpu::renderer::coverage::Interval>::add+0x14a>
  824a84:	jnp    82496c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  824a8a:	movq   %xmm1,%rcx
  824a8f:	and    %rax,%rcx
  824a92:	dec    %rcx
  824a95:	movabs $0xfffffffffffff,%rax
  824a9f:	cmp    %rax,%rcx
  824aa2:	jae    82496c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  824aa8:	xor    %ecx,%ecx
  824aaa:	mov    %rcx,(%rdi)
  824aad:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::scale bytes=453 frame=0

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824ab0 <<gpui_gpu::renderer::coverage::Interval>::scale>:
  824ab0:	movq   %xmm2,%rdx
  824ab5:	movabs $0x7fffffffffffffff,%rax
  824abf:	and    %rax,%rdx
  824ac2:	movabs $0x7fefffffffffffff,%rcx
  824acc:	cmp    %rcx,%rdx
  824acf:	jg     824aef <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  824ad1:	xorpd  %xmm3,%xmm3
  824ad5:	ucomisd %xmm3,%xmm2
  824ad9:	jne    824add <<gpui_gpu::renderer::coverage::Interval>::scale+0x2d>
  824adb:	jnp    824af5 <<gpui_gpu::renderer::coverage::Interval>::scale+0x45>
  824add:	dec    %rdx
  824ae0:	movabs $0xfffffffffffff,%rsi
  824aea:	cmp    %rsi,%rdx
  824aed:	jae    824af5 <<gpui_gpu::renderer::coverage::Interval>::scale+0x45>
  824aef:	xor    %edx,%edx
  824af1:	mov    %rdx,(%rdi)
  824af4:	ret
  824af5:	ucomisd %xmm3,%xmm2
  824af9:	jne    824afd <<gpui_gpu::renderer::coverage::Interval>::scale+0x4d>
  824afb:	jnp    824b0d <<gpui_gpu::renderer::coverage::Interval>::scale+0x5d>
  824afd:	ucomisd %xmm3,%xmm0
  824b01:	jne    824b1f <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  824b03:	jp     824b1f <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  824b05:	ucomisd %xmm3,%xmm1
  824b09:	jne    824b1f <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  824b0b:	jp     824b1f <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  824b0d:	xorpd  %xmm0,%xmm0
  824b11:	movupd %xmm0,0x8(%rdi)
  824b16:	mov    $0x1,%edx
  824b1b:	mov    %rdx,(%rdi)
  824b1e:	ret
  824b1f:	ucomisd %xmm3,%xmm2
  824b23:	cmpltsd %xmm2,%xmm3
  824b28:	movapd %xmm3,%xmm4
  824b2c:	andpd  %xmm0,%xmm4
  824b30:	andnpd %xmm1,%xmm3
  824b34:	orpd   %xmm4,%xmm3
  824b38:	ja     824b3e <<gpui_gpu::renderer::coverage::Interval>::scale+0x8e>
  824b3a:	movapd %xmm0,%xmm1
  824b3e:	mulsd  %xmm2,%xmm1
  824b42:	mulsd  %xmm2,%xmm3
  824b46:	movq   %xmm3,%rsi
  824b4b:	movq   %xmm1,%rdx
  824b50:	ucomisd %xmm3,%xmm3
  824b54:	setp   %r8b
  824b58:	movabs $0xfff0000000000000,%r9
  824b62:	cmp    %r9,%rsi
  824b65:	sete   %r9b
  824b69:	or     %r8b,%r9b
  824b6c:	jne    824b94 <<gpui_gpu::renderer::coverage::Interval>::scale+0xe4>
  824b6e:	mov    %rsi,%r8
  824b71:	and    %rax,%r8
  824b74:	je     824b80 <<gpui_gpu::renderer::coverage::Interval>::scale+0xd0>
  824b76:	cmp    %r8,%rsi
  824b79:	jne    824b8c <<gpui_gpu::renderer::coverage::Interval>::scale+0xdc>
  824b7b:	dec    %rsi
  824b7e:	jmp    824b8f <<gpui_gpu::renderer::coverage::Interval>::scale+0xdf>
  824b80:	movabs $0x8000000000000001,%rsi
  824b8a:	jmp    824b8f <<gpui_gpu::renderer::coverage::Interval>::scale+0xdf>
  824b8c:	inc    %rsi
  824b8f:	movq   %rsi,%xmm3
  824b94:	ucomisd %xmm1,%xmm1
  824b98:	setp   %sil
  824b9c:	movabs $0x7ff0000000000000,%r8
  824ba6:	cmp    %r8,%rdx
  824ba9:	sete   %r8b
  824bad:	or     %sil,%r8b
  824bb0:	jne    824bd3 <<gpui_gpu::renderer::coverage::Interval>::scale+0x123>
  824bb2:	mov    %rdx,%rsi
  824bb5:	and    %rax,%rsi
  824bb8:	je     824bc4 <<gpui_gpu::renderer::coverage::Interval>::scale+0x114>
  824bba:	cmp    %rsi,%rdx
  824bbd:	jne    824bcb <<gpui_gpu::renderer::coverage::Interval>::scale+0x11b>
  824bbf:	inc    %rdx
  824bc2:	jmp    824bce <<gpui_gpu::renderer::coverage::Interval>::scale+0x11e>
  824bc4:	mov    $0x1,%edx
  824bc9:	jmp    824bce <<gpui_gpu::renderer::coverage::Interval>::scale+0x11e>
  824bcb:	dec    %rdx
  824bce:	movq   %rdx,%xmm1
  824bd3:	movq   %xmm3,%rsi
  824bd8:	and    %rax,%rsi
  824bdb:	xor    %edx,%edx
  824bdd:	cmp    %rcx,%rsi
  824be0:	jg     824af1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  824be6:	ucomisd %xmm1,%xmm3
  824bea:	ja     824af1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  824bf0:	xorpd  %xmm0,%xmm0
  824bf4:	ucomisd %xmm0,%xmm3
  824bf8:	jne    824bfc <<gpui_gpu::renderer::coverage::Interval>::scale+0x14c>
  824bfa:	jnp    824c2b <<gpui_gpu::renderer::coverage::Interval>::scale+0x17b>
  824bfc:	dec    %rsi
  824bff:	movq   %xmm1,%rdx
  824c04:	and    %rax,%rdx
  824c07:	cmp    %rcx,%rdx
  824c0a:	setg   %cl
  824c0d:	xor    %edx,%edx
  824c0f:	movabs $0xfffffffffffff,%r8
  824c19:	cmp    %r8,%rsi
  824c1c:	jb     824af1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  824c22:	test   %cl,%cl
  824c24:	je     824c3c <<gpui_gpu::renderer::coverage::Interval>::scale+0x18c>
  824c26:	jmp    824af1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  824c2b:	movq   %xmm1,%rdx
  824c30:	and    %rax,%rdx
  824c33:	cmp    %rcx,%rdx
  824c36:	jg     824aef <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  824c3c:	ucomisd %xmm0,%xmm1
  824c40:	jne    824c44 <<gpui_gpu::renderer::coverage::Interval>::scale+0x194>
  824c42:	jnp    824c62 <<gpui_gpu::renderer::coverage::Interval>::scale+0x1b2>
  824c44:	movq   %xmm1,%rcx
  824c49:	and    %rax,%rcx
  824c4c:	dec    %rcx
  824c4f:	movabs $0xfffffffffffff,%rax
  824c59:	cmp    %rax,%rcx
  824c5c:	jb     824aef <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  824c62:	movsd  %xmm3,0x8(%rdi)
  824c67:	movsd  %xmm1,0x10(%rdi)
  824c6c:	mov    $0x1,%edx
  824c71:	mov    %rdx,(%rdi)
  824c74:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::checked bytes=187 frame=0

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824c80 <<gpui_gpu::renderer::coverage::Interval>::checked>:
  824c80:	movq   %xmm0,%rdx
  824c85:	ucomisd %xmm1,%xmm0
  824c89:	seta   %sil
  824c8d:	movabs $0x7fffffffffffffff,%rax
  824c97:	and    %rax,%rdx
  824c9a:	movabs $0x7fefffffffffffff,%rcx
  824ca4:	cmp    %rcx,%rdx
  824ca7:	setg   %r8b
  824cab:	or     %sil,%r8b
  824cae:	je     824cb6 <<gpui_gpu::renderer::coverage::Interval>::checked+0x36>
  824cb0:	xor    %eax,%eax
  824cb2:	mov    %rax,(%rdi)
  824cb5:	ret
  824cb6:	xorpd  %xmm2,%xmm2
  824cba:	ucomisd %xmm2,%xmm0
  824cbe:	jne    824cc2 <<gpui_gpu::renderer::coverage::Interval>::checked+0x42>
  824cc0:	jnp    824ced <<gpui_gpu::renderer::coverage::Interval>::checked+0x6d>
  824cc2:	dec    %rdx
  824cc5:	movabs $0xfffffffffffff,%rsi
  824ccf:	cmp    %rsi,%rdx
  824cd2:	setb   %dl
  824cd5:	movq   %xmm1,%rsi
  824cda:	and    %rax,%rsi
  824cdd:	cmp    %rcx,%rsi
  824ce0:	setg   %cl
  824ce3:	or     %dl,%cl
  824ce5:	je     824d00 <<gpui_gpu::renderer::coverage::Interval>::checked+0x80>
  824ce7:	xor    %eax,%eax
  824ce9:	mov    %rax,(%rdi)
  824cec:	ret
  824ced:	movq   %xmm1,%rdx
  824cf2:	and    %rax,%rdx
  824cf5:	cmp    %rcx,%rdx
  824cf8:	jle    824d00 <<gpui_gpu::renderer::coverage::Interval>::checked+0x80>
  824cfa:	xor    %eax,%eax
  824cfc:	mov    %rax,(%rdi)
  824cff:	ret
  824d00:	ucomisd %xmm2,%xmm1
  824d04:	jne    824d08 <<gpui_gpu::renderer::coverage::Interval>::checked+0x88>
  824d06:	jnp    824d28 <<gpui_gpu::renderer::coverage::Interval>::checked+0xa8>
  824d08:	movq   %xmm1,%rcx
  824d0d:	and    %rax,%rcx
  824d10:	dec    %rcx
  824d13:	movabs $0xfffffffffffff,%rax
  824d1d:	cmp    %rax,%rcx
  824d20:	jae    824d28 <<gpui_gpu::renderer::coverage::Interval>::checked+0xa8>
  824d22:	xor    %eax,%eax
  824d24:	mov    %rax,(%rdi)
  824d27:	ret
  824d28:	movsd  %xmm0,0x8(%rdi)
  824d2d:	movsd  %xmm1,0x10(%rdi)
  824d32:	mov    $0x1,%eax
  824d37:	mov    %rax,(%rdi)
  824d3a:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::subtract bytes=382 frame=0

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824d40 <<gpui_gpu::renderer::coverage::Interval>::subtract>:
  824d40:	xorpd  %xmm4,%xmm4
  824d44:	ucomisd %xmm4,%xmm2
  824d48:	jne    824d54 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  824d4a:	jp     824d54 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  824d4c:	ucomisd %xmm4,%xmm3
  824d50:	jne    824d54 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  824d52:	jnp    824d7c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  824d54:	ucomisd %xmm4,%xmm0
  824d58:	jne    824d8f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  824d5a:	jp     824d8f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  824d5c:	ucomisd %xmm4,%xmm1
  824d60:	jne    824d8f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  824d62:	jp     824d8f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  824d64:	movapd -0x776bac(%rip),%xmm0        # ae1c0 <anon.630a3fff68f6bca64b568be97512ab45.90.llvm.826976926275214120+0x90>
  824d6c:	xorpd  %xmm0,%xmm2
  824d70:	xorpd  %xmm0,%xmm3
  824d74:	movapd %xmm3,%xmm0
  824d78:	movapd %xmm2,%xmm1
  824d7c:	movsd  %xmm0,0x8(%rdi)
  824d81:	movsd  %xmm1,0x10(%rdi)
  824d86:	mov    $0x1,%ecx
  824d8b:	mov    %rcx,(%rdi)
  824d8e:	ret
  824d8f:	subsd  %xmm3,%xmm0
  824d93:	subsd  %xmm2,%xmm1
  824d97:	movq   %xmm0,%rdx
  824d9c:	movq   %xmm1,%rcx
  824da1:	ucomisd %xmm0,%xmm0
  824da5:	setp   %al
  824da8:	movabs $0xfff0000000000000,%rsi
  824db2:	cmp    %rsi,%rdx
  824db5:	sete   %sil
  824db9:	or     %al,%sil
  824dbc:	movabs $0x7fffffffffffffff,%rax
  824dc6:	jne    824dee <<gpui_gpu::renderer::coverage::Interval>::subtract+0xae>
  824dc8:	mov    %rdx,%rsi
  824dcb:	and    %rax,%rsi
  824dce:	je     824dda <<gpui_gpu::renderer::coverage::Interval>::subtract+0x9a>
  824dd0:	cmp    %rsi,%rdx
  824dd3:	jne    824de6 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa6>
  824dd5:	dec    %rdx
  824dd8:	jmp    824de9 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa9>
  824dda:	movabs $0x8000000000000001,%rdx
  824de4:	jmp    824de9 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa9>
  824de6:	inc    %rdx
  824de9:	movq   %rdx,%xmm0
  824dee:	ucomisd %xmm1,%xmm1
  824df2:	setp   %dl
  824df5:	movabs $0x7ff0000000000000,%rsi
  824dff:	cmp    %rsi,%rcx
  824e02:	sete   %sil
  824e06:	or     %dl,%sil
  824e09:	jne    824e2c <<gpui_gpu::renderer::coverage::Interval>::subtract+0xec>
  824e0b:	mov    %rcx,%rdx
  824e0e:	and    %rax,%rdx
  824e11:	je     824e1d <<gpui_gpu::renderer::coverage::Interval>::subtract+0xdd>
  824e13:	cmp    %rdx,%rcx
  824e16:	jne    824e24 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe4>
  824e18:	inc    %rcx
  824e1b:	jmp    824e27 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe7>
  824e1d:	mov    $0x1,%ecx
  824e22:	jmp    824e27 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe7>
  824e24:	dec    %rcx
  824e27:	movq   %rcx,%xmm1
  824e2c:	movq   %xmm0,%rdx
  824e31:	and    %rax,%rdx
  824e34:	xor    %ecx,%ecx
  824e36:	movabs $0x7fefffffffffffff,%rsi
  824e40:	cmp    %rsi,%rdx
  824e43:	jg     824eba <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  824e45:	ucomisd %xmm1,%xmm0
  824e49:	ja     824eba <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  824e4b:	xorpd  %xmm2,%xmm2
  824e4f:	ucomisd %xmm2,%xmm0
  824e53:	jne    824e57 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x117>
  824e55:	jnp    824e81 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x141>
  824e57:	dec    %rdx
  824e5a:	movq   %xmm1,%rcx
  824e5f:	and    %rax,%rcx
  824e62:	cmp    %rsi,%rcx
  824e65:	setg   %sil
  824e69:	xor    %ecx,%ecx
  824e6b:	movabs $0xfffffffffffff,%r8
  824e75:	cmp    %r8,%rdx
  824e78:	jb     824eba <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  824e7a:	test   %sil,%sil
  824e7d:	je     824e8e <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14e>
  824e7f:	jmp    824eba <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  824e81:	movq   %xmm1,%rcx
  824e86:	and    %rax,%rcx
  824e89:	cmp    %rsi,%rcx
  824e8c:	jg     824eb8 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x178>
  824e8e:	ucomisd %xmm2,%xmm1
  824e92:	jne    824e9a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x15a>
  824e94:	jnp    824d7c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  824e9a:	movq   %xmm1,%rcx
  824e9f:	and    %rax,%rcx
  824ea2:	dec    %rcx
  824ea5:	movabs $0xfffffffffffff,%rax
  824eaf:	cmp    %rax,%rcx
  824eb2:	jae    824d7c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  824eb8:	xor    %ecx,%ecx
  824eba:	mov    %rcx,(%rdi)
  824ebd:	ret

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825030 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  825030:	push   %r14
  825032:	push   %rbx
  825033:	sub    $0x18,%rsp
  825037:	mov    %rdi,%rbx
  82503a:	mov    (%rdi),%rsi
  82503d:	lea    (%rsi,%rsi,1),%rax
  825041:	cmp    $0x5,%rax
  825045:	mov    $0x4,%r14d
  82504b:	cmovae %rax,%r14
  82504f:	mov    0x8(%rdi),%rdx
  825053:	mov    %rsp,%rdi
  825056:	mov    $0x4,%r8d
  82505c:	mov    $0x20,%r9d
  825062:	mov    %r14,%rcx
  825065:	call   8250a0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  82506a:	cmpl   $0x1,(%rsp)
  82506e:	je     825084 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  825070:	mov    0x8(%rsp),%rax
  825075:	mov    %rax,0x8(%rbx)
  825079:	mov    %r14,(%rbx)
  82507c:	add    $0x18,%rsp
  825080:	pop    %rbx
  825081:	pop    %r14
  825083:	ret
  825084:	mov    0x8(%rsp),%rdi
  825089:	mov    0x10(%rsp),%rsi
  82508e:	call   *0x65be5c(%rip)        # e80ef0 <_DYNAMIC+0x288>

FUNCTION gpui_gpu::renderer::coverage::axis bytes=1662 frame=344

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825150 <gpui_gpu::renderer::coverage::axis>:
  825150:	push   %r15
  825152:	push   %r14
  825154:	push   %r13
  825156:	push   %r12
  825158:	push   %rbx
  825159:	sub    $0x130,%rsp
  825160:	movq   %xmm4,%r12
  825165:	movabs $0x7fffffffffffffff,%rbx
  82516f:	and    %rbx,%r12
  825172:	mov    $0x2,%al
  825174:	movabs $0x7fefffffffffffff,%r14
  82517e:	cmp    %r14,%r12
  825181:	jg     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  825187:	movsd  (%rdi),%xmm11
  82518c:	movsd  0x8(%rdi),%xmm8
  825192:	movsd  0x10(%rdi),%xmm9
  825198:	xorpd  %xmm10,%xmm10
  82519d:	ucomisd %xmm10,%xmm4
  8251a2:	jne    8251a6 <gpui_gpu::renderer::coverage::axis+0x56>
  8251a4:	jnp    8251be <gpui_gpu::renderer::coverage::axis+0x6e>
  8251a6:	lea    -0x1(%r12),%rcx
  8251ab:	movabs $0xfffffffffffff,%rdx
  8251b5:	cmp    %rdx,%rcx
  8251b8:	jb     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  8251be:	movq   %xmm5,%r15
  8251c3:	and    %rbx,%r15
  8251c6:	cmp    %r14,%r15
  8251c9:	jg     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  8251cf:	ucomisd %xmm10,%xmm5
  8251d4:	jne    8251d8 <gpui_gpu::renderer::coverage::axis+0x88>
  8251d6:	jnp    8251ef <gpui_gpu::renderer::coverage::axis+0x9f>
  8251d8:	lea    -0x1(%r15),%rcx
  8251dc:	movabs $0xfffffffffffff,%rdx
  8251e6:	cmp    %rdx,%rcx
  8251e9:	jb     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  8251ef:	movaps %xmm8,0xc0(%rsp)
  8251f8:	movsd  %xmm2,0x60(%rsp)
  8251fe:	movsd  %xmm3,0x28(%rsp)
  825204:	movaps %xmm9,0x80(%rsp)
  82520d:	movaps %xmm4,0xb0(%rsp)
  825215:	movsd  %xmm6,0xa8(%rsp)
  82521e:	movsd  %xmm7,0x30(%rsp)
  825224:	movaps %xmm5,0x90(%rsp)
  82522c:	mov    %rsp,%rdi
  82522f:	movsd  %xmm0,0x38(%rsp)
  825235:	movsd  %xmm1,0x40(%rsp)
  82523b:	movapd %xmm11,0x120(%rsp)
  825245:	movapd %xmm11,%xmm2
  82524a:	call   824ab0 <<gpui_gpu::renderer::coverage::Interval>::scale>
  82524f:	cmpl   $0x1,(%rsp)
  825253:	jne    82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  825259:	movsd  0x8(%rsp),%xmm0
  82525f:	movsd  %xmm0,0x20(%rsp)
  825265:	movsd  0x10(%rsp),%xmm0
  82526b:	movsd  %xmm0,0x18(%rsp)
  825271:	mov    %rsp,%rdi
  825274:	movsd  0x60(%rsp),%xmm0
  82527a:	movsd  0x28(%rsp),%xmm1
  825280:	movapd 0xc0(%rsp),%xmm2
  825289:	call   824ab0 <<gpui_gpu::renderer::coverage::Interval>::scale>
  82528e:	cmpb   $0x0,(%rsp)
  825292:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  825298:	movsd  0x8(%rsp),%xmm5
  82529e:	movsd  0x10(%rsp),%xmm4
  8252a4:	xorpd  %xmm2,%xmm2
  8252a8:	ucomisd %xmm2,%xmm5
  8252ac:	mov    $0x2,%al
  8252ae:	jne    8252d1 <gpui_gpu::renderer::coverage::axis+0x181>
  8252b0:	jp     8252d1 <gpui_gpu::renderer::coverage::axis+0x181>
  8252b2:	ucomisd %xmm2,%xmm4
  8252b6:	jne    8252d1 <gpui_gpu::renderer::coverage::axis+0x181>
  8252b8:	jp     8252d1 <gpui_gpu::renderer::coverage::axis+0x181>
  8252ba:	movdqa 0x80(%rsp),%xmm2
  8252c3:	movsd  0x18(%rsp),%xmm1
  8252c9:	movsd  0x20(%rsp),%xmm0
  8252cf:	jmp    825312 <gpui_gpu::renderer::coverage::axis+0x1c2>
  8252d1:	movsd  0x20(%rsp),%xmm0
  8252d7:	ucomisd %xmm2,%xmm0
  8252db:	movdqa 0x80(%rsp),%xmm2
  8252e4:	movsd  0x18(%rsp),%xmm1
  8252ea:	jne    8256a1 <gpui_gpu::renderer::coverage::axis+0x551>
  8252f0:	jp     8256a1 <gpui_gpu::renderer::coverage::axis+0x551>
  8252f6:	xorpd  %xmm3,%xmm3
  8252fa:	ucomisd %xmm3,%xmm1
  8252fe:	jne    8256a1 <gpui_gpu::renderer::coverage::axis+0x551>
  825304:	jp     8256a1 <gpui_gpu::renderer::coverage::axis+0x551>
  82530a:	movapd %xmm4,%xmm1
  82530e:	movapd %xmm5,%xmm0
  825312:	movq   %xmm2,%r13
  825317:	and    %rbx,%r13
  82531a:	cmp    %r14,%r13
  82531d:	jg     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  825323:	xorpd  %xmm3,%xmm3
  825327:	ucomisd %xmm3,%xmm2
  82532b:	jne    82532f <gpui_gpu::renderer::coverage::axis+0x1df>
  82532d:	jnp    825346 <gpui_gpu::renderer::coverage::axis+0x1f6>
  82532f:	lea    -0x1(%r13),%rcx
  825333:	movabs $0xfffffffffffff,%rdx
  82533d:	cmp    %rdx,%rcx
  825340:	jb     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  825346:	lea    0x48(%rsp),%rdi
  82534b:	movapd 0x80(%rsp),%xmm3
  825354:	call   824940 <<gpui_gpu::renderer::coverage::Interval>::add>
  825359:	movapd 0xb0(%rsp),%xmm2
  825362:	mov    $0x2,%al
  825364:	cmpb   $0x0,0x48(%rsp)
  825369:	je     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  82536f:	movsd  0x50(%rsp),%xmm0
  825375:	movsd  0x58(%rsp),%xmm1
  82537b:	lea    0x68(%rsp),%rdi
  825380:	movapd %xmm2,%xmm3
  825384:	call   824d40 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825389:	cmpl   $0x1,0x68(%rsp)
  82538e:	jne    82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  825394:	movsd  0x70(%rsp),%xmm0
  82539a:	movsd  %xmm0,0x18(%rsp)
  8253a0:	movsd  0x78(%rsp),%xmm0
  8253a6:	movsd  %xmm0,0x20(%rsp)
  8253ac:	movapd 0x120(%rsp),%xmm2
  8253b5:	andpd  -0x77a58d(%rip),%xmm2        # aae30 <GCC_except_table0+0x6c>
  8253bd:	mov    %rsp,%rdi
  8253c0:	movsd  0x38(%rsp),%xmm0
  8253c6:	movsd  0x40(%rsp),%xmm1
  8253cc:	call   824ab0 <<gpui_gpu::renderer::coverage::Interval>::scale>
  8253d1:	cmpb   $0x0,(%rsp)
  8253d5:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  8253db:	movsd  0x8(%rsp),%xmm0
  8253e1:	movsd  %xmm0,0x40(%rsp)
  8253e7:	movsd  0x10(%rsp),%xmm0
  8253ed:	movsd  %xmm0,0x38(%rsp)
  8253f3:	movapd 0xc0(%rsp),%xmm2
  8253fc:	andpd  -0x77a5d4(%rip),%xmm2        # aae30 <GCC_except_table0+0x6c>
  825404:	mov    %rsp,%rdi
  825407:	movsd  0x60(%rsp),%xmm0
  82540d:	movsd  0x28(%rsp),%xmm1
  825413:	call   824ab0 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825418:	cmpb   $0x0,(%rsp)
  82541c:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  825422:	movsd  0x8(%rsp),%xmm2
  825428:	movsd  0x10(%rsp),%xmm3
  82542e:	lea    0x48(%rsp),%rdi
  825433:	movsd  0x40(%rsp),%xmm0
  825439:	movsd  0x38(%rsp),%xmm1
  82543f:	call   824940 <<gpui_gpu::renderer::coverage::Interval>::add>
  825444:	cmpb   $0x0,0x48(%rsp)
  825449:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  82544f:	xorpd  %xmm0,%xmm0
  825453:	movapd 0x80(%rsp),%xmm2
  82545c:	ucomisd %xmm0,%xmm2
  825460:	movsd  0x50(%rsp),%xmm0
  825466:	movsd  0x58(%rsp),%xmm1
  82546c:	jne    825470 <gpui_gpu::renderer::coverage::axis+0x320>
  82546e:	jnp    825486 <gpui_gpu::renderer::coverage::axis+0x336>
  825470:	dec    %r13
  825473:	movabs $0xfffffffffffff,%rax
  82547d:	cmp    %rax,%r13
  825480:	jb     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  825486:	andpd  -0x77a65e(%rip),%xmm2        # aae30 <GCC_except_table0+0x6c>
  82548e:	lea    0x68(%rsp),%rdi
  825493:	movapd %xmm2,%xmm3
  825497:	call   824940 <<gpui_gpu::renderer::coverage::Interval>::add>
  82549c:	cmpb   $0x0,0x68(%rsp)
  8254a1:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  8254a7:	xorpd  %xmm0,%xmm0
  8254ab:	movapd 0xb0(%rsp),%xmm2
  8254b4:	ucomisd %xmm0,%xmm2
  8254b8:	movsd  0x70(%rsp),%xmm0
  8254be:	movsd  0x78(%rsp),%xmm1
  8254c4:	jne    8254c8 <gpui_gpu::renderer::coverage::axis+0x378>
  8254c6:	jnp    8254de <gpui_gpu::renderer::coverage::axis+0x38e>
  8254c8:	dec    %r12
  8254cb:	movabs $0xfffffffffffff,%rax
  8254d5:	cmp    %rax,%r12
  8254d8:	jb     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  8254de:	andpd  -0x77a6b6(%rip),%xmm2        # aae30 <GCC_except_table0+0x6c>
  8254e6:	lea    0x108(%rsp),%rdi
  8254ee:	movapd %xmm2,%xmm3
  8254f2:	call   824940 <<gpui_gpu::renderer::coverage::Interval>::add>
  8254f7:	cmpb   $0x0,0x108(%rsp)
  8254ff:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  825505:	xorpd  %xmm0,%xmm0
  825509:	movapd 0x90(%rsp),%xmm1
  825512:	ucomisd %xmm0,%xmm1
  825516:	movsd  0x110(%rsp),%xmm0
  82551f:	movsd  0x118(%rsp),%xmm1
  825528:	jne    82552c <gpui_gpu::renderer::coverage::axis+0x3dc>
  82552a:	jnp    825542 <gpui_gpu::renderer::coverage::axis+0x3f2>
  82552c:	dec    %r15
  82552f:	movabs $0xfffffffffffff,%rax
  825539:	cmp    %rax,%r15
  82553c:	jb     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  825542:	movapd -0x77a71a(%rip),%xmm2        # aae30 <GCC_except_table0+0x6c>
  82554a:	andpd  0x90(%rsp),%xmm2
  825553:	lea    0xf0(%rsp),%rdi
  82555b:	movapd %xmm2,%xmm3
  82555f:	call   824940 <<gpui_gpu::renderer::coverage::Interval>::add>
  825564:	cmpb   $0x0,0xf0(%rsp)
  82556c:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  825572:	movsd  0xf8(%rsp),%xmm0
  82557b:	movsd  0x100(%rsp),%xmm1
  825584:	lea    0xd8(%rsp),%rdi
  82558c:	movsd  -0x775cb4(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  825594:	movapd %xmm2,%xmm3
  825598:	call   824940 <<gpui_gpu::renderer::coverage::Interval>::add>
  82559d:	cmpl   $0x1,0xd8(%rsp)
  8255a5:	jne    82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  8255ab:	movsd  0xe0(%rsp),%xmm0
  8255b4:	movsd  0xe8(%rsp),%xmm1
  8255bd:	mov    %rsp,%rdi
  8255c0:	movsd  0xa8(%rsp),%xmm2
  8255c9:	call   824ab0 <<gpui_gpu::renderer::coverage::Interval>::scale>
  8255ce:	cmpb   $0x0,(%rsp)
  8255d2:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  8255d8:	movq   0x30(%rsp),%xmm0
  8255de:	movq   %xmm0,%rax
  8255e3:	and    %rbx,%rax
  8255e6:	cmp    %r14,%rax
  8255e9:	jg     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  8255ef:	movsd  0x8(%rsp),%xmm0
  8255f5:	movsd  0x10(%rsp),%xmm1
  8255fb:	xorpd  %xmm2,%xmm2
  8255ff:	movsd  0x30(%rsp),%xmm3
  825605:	ucomisd %xmm2,%xmm3
  825609:	jne    82560d <gpui_gpu::renderer::coverage::axis+0x4bd>
  82560b:	jnp    82561f <gpui_gpu::renderer::coverage::axis+0x4cf>
  82560d:	dec    %rax
  825610:	movabs $0xfffffffffffff,%rcx
  82561a:	cmp    %rcx,%rax
  82561d:	jb     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  82561f:	lea    0x48(%rsp),%rdi
  825624:	movsd  0x30(%rsp),%xmm2
  82562a:	movapd %xmm2,%xmm3
  82562e:	call   824940 <<gpui_gpu::renderer::coverage::Interval>::add>
  825633:	cmpb   $0x0,0x48(%rsp)
  825638:	je     82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  82563a:	movsd  0x58(%rsp),%xmm1
  825640:	movsd  0x18(%rsp),%xmm0
  825646:	movsd  %xmm1,0x28(%rsp)
  82564c:	ucomisd %xmm1,%xmm0
  825650:	jbe    8257c7 <gpui_gpu::renderer::coverage::axis+0x677>
  825656:	mov    %rsp,%rdi
  825659:	movapd 0x90(%rsp),%xmm0
  825662:	movapd %xmm0,%xmm1
  825666:	movsd  0x18(%rsp),%xmm2
  82566c:	movsd  0x20(%rsp),%xmm3
  825672:	call   824d40 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825677:	cmpl   $0x1,(%rsp)
  82567b:	jne    82568e <gpui_gpu::renderer::coverage::axis+0x53e>
  82567d:	movsd  0x8(%rsp),%xmm0
  825683:	ucomisd 0x28(%rsp),%xmm0
  825689:	seta   %al
  82568c:	jmp    825690 <gpui_gpu::renderer::coverage::axis+0x540>
  82568e:	mov    $0x2,%al
  825690:	add    $0x130,%rsp
  825697:	pop    %rbx
  825698:	pop    %r12
  82569a:	pop    %r13
  82569c:	pop    %r14
  82569e:	pop    %r15
  8256a0:	ret
  8256a1:	addsd  %xmm5,%xmm0
  8256a5:	addsd  %xmm4,%xmm1
  8256a9:	movq   %xmm0,%rdx
  8256ae:	movq   %xmm1,%rcx
  8256b3:	ucomisd %xmm0,%xmm0
  8256b7:	setp   %sil
  8256bb:	movabs $0xfff0000000000000,%rdi
  8256c5:	cmp    %rdi,%rdx
  8256c8:	sete   %dil
  8256cc:	or     %sil,%dil
  8256cf:	jne    8256f7 <gpui_gpu::renderer::coverage::axis+0x5a7>
  8256d1:	mov    %rdx,%rsi
  8256d4:	and    %rbx,%rsi
  8256d7:	je     8256e3 <gpui_gpu::renderer::coverage::axis+0x593>
  8256d9:	cmp    %rsi,%rdx
  8256dc:	jne    8256ef <gpui_gpu::renderer::coverage::axis+0x59f>
  8256de:	dec    %rdx
  8256e1:	jmp    8256f2 <gpui_gpu::renderer::coverage::axis+0x5a2>
  8256e3:	movabs $0x8000000000000001,%rdx
  8256ed:	jmp    8256f2 <gpui_gpu::renderer::coverage::axis+0x5a2>
  8256ef:	inc    %rdx
  8256f2:	movq   %rdx,%xmm0
  8256f7:	ucomisd %xmm1,%xmm1
  8256fb:	setp   %dl
  8256fe:	movabs $0x7ff0000000000000,%rsi
  825708:	cmp    %rsi,%rcx
  82570b:	sete   %sil
  82570f:	or     %dl,%sil
  825712:	jne    825735 <gpui_gpu::renderer::coverage::axis+0x5e5>
  825714:	mov    %rcx,%rdx
  825717:	and    %rbx,%rdx
  82571a:	je     825726 <gpui_gpu::renderer::coverage::axis+0x5d6>
  82571c:	cmp    %rdx,%rcx
  82571f:	jne    82572d <gpui_gpu::renderer::coverage::axis+0x5dd>
  825721:	inc    %rcx
  825724:	jmp    825730 <gpui_gpu::renderer::coverage::axis+0x5e0>
  825726:	mov    $0x1,%ecx
  82572b:	jmp    825730 <gpui_gpu::renderer::coverage::axis+0x5e0>
  82572d:	dec    %rcx
  825730:	movq   %rcx,%xmm1
  825735:	movq   %xmm0,%rdx
  82573a:	and    %rbx,%rdx
  82573d:	cmp    %r14,%rdx
  825740:	jg     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  825746:	ucomisd %xmm1,%xmm0
  82574a:	ja     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  825750:	xorpd  %xmm3,%xmm3
  825754:	ucomisd %xmm3,%xmm0
  825758:	movq   %xmm1,%rcx
  82575d:	jne    825761 <gpui_gpu::renderer::coverage::axis+0x611>
  82575f:	jnp    82578e <gpui_gpu::renderer::coverage::axis+0x63e>
  825761:	dec    %rdx
  825764:	mov    %rcx,%rsi
  825767:	and    %rbx,%rsi
  82576a:	cmp    %r14,%rsi
  82576d:	setg   %sil
  825771:	movabs $0xfffffffffffff,%rdi
  82577b:	cmp    %rdi,%rdx
  82577e:	jb     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  825784:	test   %sil,%sil
  825787:	je     82579d <gpui_gpu::renderer::coverage::axis+0x64d>
  825789:	jmp    825690 <gpui_gpu::renderer::coverage::axis+0x540>
  82578e:	mov    %rcx,%rdx
  825791:	and    %rbx,%rdx
  825794:	cmp    %r14,%rdx
  825797:	jg     825690 <gpui_gpu::renderer::coverage::axis+0x540>
  82579d:	ucomisd %xmm3,%xmm1
  8257a1:	jne    8257a9 <gpui_gpu::renderer::coverage::axis+0x659>
  8257a3:	jnp    825312 <gpui_gpu::renderer::coverage::axis+0x1c2>
  8257a9:	and    %rbx,%rcx
  8257ac:	dec    %rcx
  8257af:	movabs $0xfffffffffffff,%rdx
  8257b9:	cmp    %rdx,%rcx
  8257bc:	jae    825312 <gpui_gpu::renderer::coverage::axis+0x1c2>
  8257c2:	jmp    825690 <gpui_gpu::renderer::coverage::axis+0x540>
  8257c7:	xor    %eax,%eax
  8257c9:	jmp    825690 <gpui_gpu::renderer::coverage::axis+0x540>

FUNCTION gpui_gpu::renderer::coverage::whole bytes=1462 frame=248

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008257d0 <gpui_gpu::renderer::coverage::whole>:
  8257d0:	push   %rbp
  8257d1:	push   %r15
  8257d3:	push   %r14
  8257d5:	push   %r13
  8257d7:	push   %r12
  8257d9:	push   %rbx
  8257da:	sub    $0xc8,%rsp
  8257e1:	mov    %rsi,0x30(%rsp)
  8257e6:	cmpb   $0x0,(%rdi)
  8257e9:	jne    82588c <gpui_gpu::renderer::coverage::whole+0xbc>
  8257ef:	test   %esi,%esi
  8257f1:	sets   %al
  8257f4:	mov    %esi,%r9d
  8257f7:	and    $0x7fffffff,%r9d
  8257fe:	lea    -0x800000(%r9),%r10d
  825805:	cmp    $0x7f000000,%r10d
  82580c:	setb   %r10b
  825810:	and    %al,%r10b
  825813:	lea    -0x1(%r9),%r11d
  825817:	cmp    $0x7fffff,%r11d
  82581e:	setb   %r11b
  825822:	and    %al,%r11b
  825825:	cmp    $0x7f800000,%r9d
  82582c:	sete   %al
  82582f:	setg   %r9b
  825833:	or     %al,%r9b
  825836:	or     %r11b,%r9b
  825839:	or     %r10b,%r9b
  82583c:	jne    82588c <gpui_gpu::renderer::coverage::whole+0xbc>
  82583e:	shr    $0x20,%rsi
  825842:	test   %esi,%esi
  825844:	sets   %al
  825847:	and    $0x7fffffff,%esi
  82584d:	lea    -0x800000(%rsi),%r9d
  825854:	cmp    $0x7f000000,%r9d
  82585b:	setb   %r9b
  82585f:	and    %al,%r9b
  825862:	lea    -0x1(%rsi),%r10d
  825866:	cmp    $0x7fffff,%r10d
  82586d:	setb   %r10b
  825871:	and    %al,%r10b
  825874:	cmp    $0x7f800000,%esi
  82587a:	sete   %al
  82587d:	setg   %sil
  825881:	or     %al,%sil
  825884:	or     %r10b,%sil
  825887:	or     %r9b,%sil
  82588a:	je     8258a2 <gpui_gpu::renderer::coverage::whole+0xd2>
  82588c:	xor    %eax,%eax
  82588e:	and    $0x1,%al
  825890:	add    $0xc8,%rsp
  825897:	pop    %rbx
  825898:	pop    %r12
  82589a:	pop    %r13
  82589c:	pop    %r14
  82589e:	pop    %r15
  8258a0:	pop    %rbp
  8258a1:	ret
  8258a2:	movss  0x88(%rdi),%xmm1
  8258aa:	movss  -0x776896(%rip),%xmm2        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8258b2:	movaps %xmm1,%xmm0
  8258b5:	subss  %xmm2,%xmm0
  8258b9:	cvttss2si %xmm0,%rax
  8258be:	cvttss2si %xmm1,%rsi
  8258c3:	mov    %rsi,%r9
  8258c6:	sar    $0x3f,%r9
  8258ca:	and    %rax,%r9
  8258cd:	or     %rsi,%r9
  8258d0:	xor    %eax,%eax
  8258d2:	xorps  %xmm0,%xmm0
  8258d5:	ucomiss %xmm0,%xmm1
  8258d8:	cmovb  %rax,%r9
  8258dc:	movss  0x8c(%rdi),%xmm4
  8258e4:	movss  -0x7768cc(%rip),%xmm3        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8258ec:	ucomiss %xmm3,%xmm1
  8258ef:	mov    $0xffffffffffffffff,%rbx
  8258f6:	cmova  %rbx,%r9
  8258fa:	movaps %xmm4,%xmm1
  8258fd:	subss  %xmm2,%xmm1
  825901:	cvttss2si %xmm1,%rsi
  825906:	cvttss2si %xmm4,%r11
  82590b:	mov    %r11,%r10
  82590e:	sar    $0x3f,%r10
  825912:	and    %rsi,%r10
  825915:	or     %r11,%r10
  825918:	ucomiss %xmm0,%xmm4
  82591b:	cmovb  %rax,%r10
  82591f:	ucomiss %xmm3,%xmm4
  825922:	movss  0x90(%rdi),%xmm1
  82592a:	cmova  %rbx,%r10
  82592e:	movaps %xmm1,%xmm4
  825931:	subss  %xmm2,%xmm4
  825935:	cvttss2si %xmm4,%r11
  82593a:	cvttss2si %xmm1,%r14
  82593f:	mov    %r14,%rsi
  825942:	sar    $0x3f,%rsi
  825946:	and    %r11,%rsi
  825949:	or     %r14,%rsi
  82594c:	ucomiss %xmm0,%xmm1
  82594f:	cmovb  %rax,%rsi
  825953:	ucomiss %xmm3,%xmm1
  825956:	cmova  %rbx,%rsi
  82595a:	add    %r9,%rsi
  82595d:	setb   %r11b
  825961:	sete   %bpl
  825965:	or     %r11b,%bpl
  825968:	jne    82588e <gpui_gpu::renderer::coverage::whole+0xbe>
  82596e:	movss  0x94(%rdi),%xmm2
  825976:	cvttss2si %xmm2,%rax
  82597b:	mov    %rax,%r11
  82597e:	movaps %xmm2,%xmm3
  825981:	subss  -0x77696d(%rip),%xmm3        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  825989:	sar    $0x3f,%r11
  82598d:	cvttss2si %xmm3,%r14
  825992:	and    %r11,%r14
  825995:	or     %rax,%r14
  825998:	xor    %eax,%eax
  82599a:	ucomiss %xmm0,%xmm2
  82599d:	mov    $0x0,%r11d
  8259a3:	cmovae %r14,%r11
  8259a7:	ucomiss -0x77698e(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8259ae:	cmova  %rbx,%r11
  8259b2:	add    %r10,%r11
  8259b5:	setb   %bl
  8259b8:	sete   %bpl
  8259bc:	or     %bl,%bpl
  8259bf:	jne    82588e <gpui_gpu::renderer::coverage::whole+0xbe>
  8259c5:	xor    %eax,%eax
  8259c7:	test   %rdx,%rdx
  8259ca:	je     82588e <gpui_gpu::renderer::coverage::whole+0xbe>
  8259d0:	movss  -0x776bf8(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  8259d8:	ucomiss %xmm1,%xmm0
  8259db:	ja     82588e <gpui_gpu::renderer::coverage::whole+0xbe>
  8259e1:	ucomiss %xmm2,%xmm0
  8259e4:	ja     82588e <gpui_gpu::renderer::coverage::whole+0xbe>
  8259ea:	dec    %rsi
  8259ed:	dec    %r11
  8259f0:	shr    $0x4,%r10
  8259f4:	imul   %rdx,%r10
  8259f8:	shr    $0x4,%r9
  8259fc:	add    %r10,%r9
  8259ff:	mov    %r9,%rax
  825a02:	mov    %rdx,%rbx
  825a05:	or     %rdx,%rax
  825a08:	shr    $0x20,%rax
  825a0c:	je     825a1e <gpui_gpu::renderer::coverage::whole+0x24e>
  825a0e:	mov    %r9,%rax
  825a11:	xor    %edx,%edx
  825a13:	div    %rbx
  825a16:	mov    %rdx,%r10
  825a19:	mov    %rax,%r9
  825a1c:	jmp    825a2b <gpui_gpu::renderer::coverage::whole+0x25b>
  825a1e:	mov    %r9d,%eax
  825a21:	xor    %edx,%edx
  825a23:	div    %ebx
  825a25:	mov    %edx,%r10d
  825a28:	mov    %eax,%r9d
  825a2b:	shl    $0x4,%r10d
  825a2f:	shr    $0x4,%r11
  825a33:	imul   %rbx,%r11
  825a37:	shr    $0x4,%rsi
  825a3b:	add    %r11,%rsi
  825a3e:	mov    %rsi,%rdx
  825a41:	or     %rbx,%rdx
  825a44:	shr    $0x20,%rdx
  825a48:	je     825a54 <gpui_gpu::renderer::coverage::whole+0x284>
  825a4a:	mov    %rsi,%rax
  825a4d:	xor    %edx,%edx
  825a4f:	div    %rbx
  825a52:	jmp    825a5a <gpui_gpu::renderer::coverage::whole+0x28a>
  825a54:	mov    %esi,%eax
  825a56:	xor    %edx,%edx
  825a58:	div    %ebx
  825a5a:	shl    $0x4,%edx
  825a5d:	shl    $0x4,%eax
  825a60:	add    $0x10,%edx
  825a63:	cmp    %edx,%ecx
  825a65:	cmovb  %ecx,%edx
  825a68:	add    $0x10,%eax
  825a6b:	cmp    %eax,%r8d
  825a6e:	cmovb  %r8d,%eax
  825a72:	movss  0x78(%rdi),%xmm0
  825a77:	cvtss2sd %xmm0,%xmm2
  825a7b:	mov    %r10d,%ecx
  825a7e:	xorps  %xmm0,%xmm0
  825a81:	cvtsi2sd %rcx,%xmm0
  825a86:	ucomisd %xmm0,%xmm2
  825a8a:	ja     82588c <gpui_gpu::renderer::coverage::whole+0xbc>
  825a90:	shl    $0x4,%r9d
  825a94:	movss  0x7c(%rdi),%xmm1
  825a99:	cvtss2sd %xmm1,%xmm3
  825a9d:	cvtsi2sd %r9,%xmm4
  825aa2:	ucomisd %xmm4,%xmm3
  825aa6:	ja     82588c <gpui_gpu::renderer::coverage::whole+0xbc>
  825aac:	movss  0x80(%rdi),%xmm1
  825ab4:	cvtss2sd %xmm1,%xmm1
  825ab8:	addsd  %xmm1,%xmm2
  825abc:	mov    %edx,%ecx
  825abe:	xorps  %xmm1,%xmm1
  825ac1:	cvtsi2sd %rcx,%xmm1
  825ac6:	ucomisd %xmm2,%xmm1
  825aca:	ja     82588c <gpui_gpu::renderer::coverage::whole+0xbc>
  825ad0:	movss  0x84(%rdi),%xmm2
  825ad8:	cvtss2sd %xmm2,%xmm2
  825adc:	addsd  %xmm3,%xmm2
  825ae0:	mov    %eax,%eax
  825ae2:	xorps  %xmm3,%xmm3
  825ae5:	cvtsi2sd %rax,%xmm3
  825aea:	ucomisd %xmm2,%xmm3
  825aee:	ja     82588c <gpui_gpu::renderer::coverage::whole+0xbc>
  825af4:	movsd  %xmm3,(%rsp)
  825af9:	movsd  %xmm4,0x8(%rsp)
  825aff:	mov    %rdi,%rbx
  825b02:	addsd  -0x7762a2(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  825b0a:	addsd  -0x77652a(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  825b12:	lea    0x38(%rsp),%rdi
  825b17:	call   824c80 <<gpui_gpu::renderer::coverage::Interval>::checked>
  825b1c:	cmpl   $0x1,0x38(%rsp)
  825b21:	jne    82588c <gpui_gpu::renderer::coverage::whole+0xbc>
  825b27:	movsd  0x40(%rsp),%xmm0
  825b2d:	movsd  %xmm0,0x28(%rsp)
  825b33:	movsd  0x48(%rsp),%xmm0
  825b39:	movsd  %xmm0,0x20(%rsp)
  825b3f:	movsd  0x8(%rsp),%xmm0
  825b45:	addsd  -0x7762e5(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  825b4d:	movsd  (%rsp),%xmm1
  825b52:	addsd  -0x776572(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  825b5a:	lea    0x38(%rsp),%rdi
  825b5f:	call   824c80 <<gpui_gpu::renderer::coverage::Interval>::checked>
  825b64:	cmpb   $0x0,0x38(%rsp)
  825b69:	je     82588c <gpui_gpu::renderer::coverage::whole+0xbc>
  825b6f:	movsd  0x40(%rsp),%xmm0
  825b75:	movsd  %xmm0,0x18(%rsp)
  825b7b:	movsd  0x48(%rsp),%xmm0
  825b81:	movsd  %xmm0,0x10(%rsp)
  825b87:	mov    %rbx,%rcx
  825b8a:	movss  0x38(%rbx),%xmm0
  825b8f:	movss  0x3c(%rbx),%xmm1
  825b94:	movss  0x40(%rbx),%xmm2
  825b99:	movss  0x44(%rbx),%xmm3
  825b9e:	lea    0xa8(%rsp),%r14
  825ba6:	movq   $0x0,0xa8(%rsp)
  825bb2:	movss  %xmm0,0xb0(%rsp)
  825bbb:	movss  %xmm2,0xb4(%rsp)
  825bc4:	movq   $0x1,0xb8(%rsp)
  825bd0:	movss  %xmm1,0xc0(%rsp)
  825bd9:	movss  %xmm3,0xc4(%rsp)
  825be2:	lea    0x48(%rsp),%r15
  825be7:	xor    %r12d,%r12d
  825bea:	movabs $0x3ec0000000000000,%r13
  825bf4:	movsd  -0x775dbd(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  825bfd:	xor    %edx,%edx
  825bff:	shl    $0x4,%rdx
  825c03:	mov    (%r14,%rdx,1),%rdi
  825c07:	cmp    $0x6,%rdi
  825c0b:	jae    825d49 <gpui_gpu::renderer::coverage::whole+0x579>
  825c11:	cmp    $0x4,%rdi
  825c15:	jae    825d5b <gpui_gpu::renderer::coverage::whole+0x58b>
  825c1b:	mov    %rdi,%rax
  825c1e:	or     $0x4,%rax
  825c22:	cmp    $0x6,%rax
  825c26:	jae    825d71 <gpui_gpu::renderer::coverage::whole+0x5a1>
  825c2c:	movss  0x8(%r14,%rdx,1),%xmm0
  825c33:	movss  0xc(%r14,%rdx,1),%xmm1
  825c3a:	movsd  0x48(%rcx,%rdi,8),%xmm2
  825c40:	movsd  0x48(%rcx,%rax,8),%xmm3
  825c46:	xorps  %xmm4,%xmm4
  825c49:	cvtsd2ss %xmm3,%xmm4
  825c4d:	movsd  0x58(%rcx,%rdi,8),%xmm5
  825c53:	cvtss2sd %xmm4,%xmm4
  825c57:	movss  0x30(%rsp,%rdi,4),%xmm6
  825c5d:	cvtss2sd %xmm6,%xmm6
  825c61:	movq   $0x0,0x38(%rsp)
  825c6a:	movq   $0x2,0x40(%rsp)
  825c73:	movapd %xmm2,%xmm7
  825c77:	unpcklpd %xmm5,%xmm7
  825c7b:	cvtpd2ps %xmm7,%xmm7
  825c7f:	cvtps2pd %xmm7,%xmm7
  825c82:	movups %xmm7,0x48(%rsp)
  825c87:	movsd  %xmm4,0x58(%rsp)
  825c8d:	mov    %r13,0x60(%rsp)
  825c92:	movsd  %xmm6,0x68(%rsp)
  825c98:	movsd  %xmm2,0x70(%rsp)
  825c9e:	movsd  %xmm5,0x78(%rsp)
  825ca4:	movsd  %xmm3,0x80(%rsp)
  825cad:	movups %xmm8,0x88(%rsp)
  825cb6:	cvtss2sd %xmm0,%xmm0
  825cba:	movsd  %xmm0,0x8(%rsp)
  825cc0:	xorps  %xmm0,%xmm0
  825cc3:	cvtss2sd %xmm1,%xmm0
  825cc7:	movsd  %xmm0,(%rsp)
  825ccc:	xor    %ebp,%ebp
  825cce:	xor    %eax,%eax
  825cd0:	lea    (%rax,%rax,4),%rax
  825cd4:	lea    (%r15,%rax,8),%rdi
  825cd8:	movsd  0x18(%r15,%rax,8),%xmm6
  825cdf:	movsd  0x20(%r15,%rax,8),%xmm7
  825ce6:	movsd  0x28(%rsp),%xmm0
  825cec:	movsd  0x20(%rsp),%xmm1
  825cf2:	movsd  0x18(%rsp),%xmm2
  825cf8:	movsd  0x10(%rsp),%xmm3
  825cfe:	movsd  0x8(%rsp),%xmm4
  825d04:	movsd  (%rsp),%xmm5
  825d09:	call   825150 <gpui_gpu::renderer::coverage::axis>
  825d0e:	cmp    $0x1,%al
  825d10:	jne    82588e <gpui_gpu::renderer::coverage::whole+0xbe>
  825d16:	mov    $0x1,%eax
  825d1b:	test   $0x1,%bpl
  825d1f:	mov    $0x1,%bpl
  825d22:	je     825cd0 <gpui_gpu::renderer::coverage::whole+0x500>
  825d24:	mov    $0x1,%edx
  825d29:	test   $0x1,%r12b
  825d2d:	mov    $0x1,%r12b
  825d30:	mov    %rbx,%rcx
  825d33:	movsd  -0x775efc(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  825d3c:	je     825bff <gpui_gpu::renderer::coverage::whole+0x42f>
  825d42:	mov    $0x1,%al
  825d44:	jmp    82588e <gpui_gpu::renderer::coverage::whole+0xbe>
  825d49:	lea    0x609b88(%rip),%rdx        # e2f8d8 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x50>
  825d50:	mov    $0x6,%esi
  825d55:	call   *0x65b405(%rip)        # e81160 <_DYNAMIC+0x4f8>
  825d5b:	add    $0x2,%rdi
  825d5f:	lea    0x609b8a(%rip),%rdx        # e2f8f0 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x68>
  825d66:	mov    $0x6,%esi
  825d6b:	call   *0x65b3ef(%rip)        # e81160 <_DYNAMIC+0x4f8>
  825d71:	lea    0x609b90(%rip),%rdx        # e2f908 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x80>
  825d78:	mov    $0x6,%esi
  825d7d:	mov    %rax,%rdi
  825d80:	call   *0x65b3da(%rip)        # e81160 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825f70 <gpui_gpu::renderer::slots::color_word>:
  825f70:	lea    -0x3(%rsi),%eax
  825f73:	cmp    %rax,%rdi
  825f76:	jbe    825f8f <gpui_gpu::renderer::slots::color_word+0x1f>
  825f78:	mov    %rdi,%rax
  825f7b:	shr    $0x6,%rax
  825f7f:	and    $0x3f,%edi
  825f82:	cmp    $0x1,%rdi
  825f86:	sbb    $0xffffffff,%eax
  825f89:	add    %esi,%eax
  825f8b:	add    $0xfffffffe,%eax
  825f8e:	ret
  825f8f:	push   %rax
  825f90:	lea    -0x7511fa(%rip),%rdi        # d4d9d <anon.40d712e5988dd8ceda02be174ecb0ea3.19.llvm.14454761975545227518>
  825f97:	lea    0x609982(%rip),%rdx        # e2f920 <anon.40d712e5988dd8ceda02be174ecb0ea3.20.llvm.14454761975545227518>
  825f9e:	mov    $0x1e,%esi
  825fa3:	call   *0x65b227(%rip)        # e811d0 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=517 frame=72

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825fb0 <gpui_gpu::renderer::slots::write_prefix>:
  825fb0:	push   %rbp
  825fb1:	push   %r15
  825fb3:	push   %r14
  825fb5:	push   %r13
  825fb7:	push   %r12
  825fb9:	push   %rbx
  825fba:	sub    $0x18,%rsp
  825fbe:	test   %rdx,%rdx
  825fc1:	je     82615c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825fc7:	mov    %rdi,%rbx
  825fca:	mov    %rdx,%rax
  825fcd:	shr    $0x6,%rax
  825fd1:	xor    %ecx,%ecx
  825fd3:	test   $0x3f,%dl
  825fd6:	setne  %cl
  825fd9:	lea    (%rax,%rcx,1),%rbp
  825fdd:	lea    (%rax,%rcx,1),%r8
  825fe1:	inc    %r8
  825fe4:	mov    0x10(%rdi),%r12
  825fe8:	mov    %rbp,%r13
  825feb:	sub    %r12,%r13
  825fee:	jae    825ffc <gpui_gpu::renderer::slots::write_prefix+0x4c>
  825ff0:	mov    0x8(%rbx),%rax
  825ff4:	mov    %r8,%r14
  825ff7:	jmp    82609b <gpui_gpu::renderer::slots::write_prefix+0xeb>
  825ffc:	mov    %r8,%r15
  825fff:	sub    %r12,%r15
  826002:	mov    (%rbx),%rax
  826005:	sub    %r12,%rax
  826008:	mov    %r12,%r14
  82600b:	cmp    %rax,%r15
  82600e:	ja     82616b <gpui_gpu::renderer::slots::write_prefix+0x1bb>
  826014:	mov    0x8(%rbx),%rax
  826018:	mov    %r14,%rcx
  82601b:	shl    $0x4,%rcx
  82601f:	add    %rax,%rcx
  826022:	cmp    $0x2,%r15
  826026:	jb     826092 <gpui_gpu::renderer::slots::write_prefix+0xe2>
  826028:	mov    %r13d,%edi
  82602b:	and    $0x7,%edi
  82602e:	sub    %rbp,%r12
  826031:	cmp    $0xfffffffffffffff8,%r12
  826035:	ja     82606e <gpui_gpu::renderer::slots::write_prefix+0xbe>
  826037:	and    $0xfffffffffffffff8,%r13
  82603b:	xorps  %xmm0,%xmm0
  82603e:	xchg   %ax,%ax
  826040:	movups %xmm0,(%rcx)
  826043:	movups %xmm0,0x10(%rcx)
  826047:	movups %xmm0,0x20(%rcx)
  82604b:	movups %xmm0,0x30(%rcx)
  82604f:	movups %xmm0,0x40(%rcx)
  826053:	movups %xmm0,0x50(%rcx)
  826057:	movups %xmm0,0x60(%rcx)
  82605b:	movups %xmm0,0x70(%rcx)
  82605f:	sub    $0xffffffffffffff80,%rcx
  826063:	add    $0xfffffffffffffff8,%r13
  826067:	jne    826040 <gpui_gpu::renderer::slots::write_prefix+0x90>
  826069:	test   %rdi,%rdi
  82606c:	je     82608c <gpui_gpu::renderer::slots::write_prefix+0xdc>
  82606e:	xorps  %xmm0,%xmm0
  826071:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  826080:	movups %xmm0,(%rcx)
  826083:	add    $0x10,%rcx
  826087:	dec    %rdi
  82608a:	jne    826080 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  82608c:	add    %r15,%r14
  82608f:	dec    %r14
  826092:	xorps  %xmm0,%xmm0
  826095:	movups %xmm0,(%rcx)
  826098:	inc    %r14
  82609b:	mov    %r14,0x10(%rbx)
  82609f:	mov    %edx,(%rax)
  8260a1:	mov    %ebp,0x4(%rax)
  8260a4:	mov    %r8d,0x8(%rax)
  8260a8:	movl   $0x0,0xc(%rax)
  8260af:	mov    %rsi,%rdi
  8260b2:	call   *0x65b158(%rip)        # e81210 <_DYNAMIC+0x5a8>
  8260b8:	cmp    %rdx,%rax
  8260bb:	je     82615c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  8260c1:	mov    %rax,%r15
  8260c4:	mov    %rdx,%r12
  8260c7:	xor    %r13d,%r13d
  8260ca:	xor    %ebp,%ebp
  8260cc:	jmp    8260f6 <gpui_gpu::renderer::slots::write_prefix+0x146>
  8260ce:	xchg   %ax,%ax
  8260d0:	mov    0x8(%rbx),%rax
  8260d4:	mov    %r14,%rcx
  8260d7:	shl    $0x4,%rcx
  8260db:	movups %xmm0,(%rax,%rcx,1)
  8260df:	inc    %r14
  8260e2:	mov    %r14,0x10(%rbx)
  8260e6:	add    $0x2,%r13d
  8260ea:	add    $0x18,%r15
  8260ee:	inc    %rbp
  8260f1:	cmp    %r12,%r15
  8260f4:	je     82615c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  8260f6:	mov    %rbp,%rdi
  8260f9:	shr    $0x6,%rdi
  8260fd:	inc    %rdi
  826100:	cmp    %r14,%rdi
  826103:	jae    8261a5 <gpui_gpu::renderer::slots::write_prefix+0x1f5>
  826109:	movups (%r15),%xmm0
  82610d:	movzwl 0x12(%r15),%eax
  826112:	movzwl 0x10(%r15),%edx
  826117:	shr    $0xe,%eax
  82611a:	and    $0x2,%eax
  82611d:	shr    $0xf,%edx
  826120:	or     %eax,%edx
  826122:	mov    %r13d,%ecx
  826125:	and    $0x1e,%cl
  826128:	shl    %cl,%edx
  82612a:	shl    $0x4,%rdi
  82612e:	add    0x8(%rbx),%rdi
  826132:	mov    %ebp,%eax
  826134:	shr    $0x2,%eax
  826137:	and    $0xc,%eax
  82613a:	or     %edx,(%rax,%rdi,1)
  82613d:	mov    0x10(%rbx),%r14
  826141:	cmp    (%rbx),%r14
  826144:	jne    8260d0 <gpui_gpu::renderer::slots::write_prefix+0x120>
  826146:	mov    %rbx,%rdi
  826149:	movaps %xmm0,(%rsp)
  82614d:	call   *0x65b1fd(%rip)        # e81350 <_DYNAMIC+0x6e8>
  826153:	movaps (%rsp),%xmm0
  826157:	jmp    8260d0 <gpui_gpu::renderer::slots::write_prefix+0x120>
  82615c:	add    $0x18,%rsp
  826160:	pop    %rbx
  826161:	pop    %r12
  826163:	pop    %r13
  826165:	pop    %r14
  826167:	pop    %r15
  826169:	pop    %rbp
  82616a:	ret
  82616b:	mov    $0x4,%ecx
  826170:	mov    %r8,0x10(%rsp)
  826175:	mov    $0x10,%r8d
  82617b:	mov    %rbx,%rdi
  82617e:	mov    %rsi,(%rsp)
  826182:	mov    %r12,%rsi
  826185:	mov    %rdx,%r14
  826188:	mov    %r15,%rdx
  82618b:	call   8248b0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  826190:	mov    0x10(%rsp),%r8
  826195:	mov    %r14,%rdx
  826198:	mov    (%rsp),%rsi
  82619c:	mov    0x10(%rbx),%r14
  8261a0:	jmp    826014 <gpui_gpu::renderer::slots::write_prefix+0x64>
  8261a5:	lea    0x60978c(%rip),%rdx        # e2f938 <anon.40d712e5988dd8ceda02be174ecb0ea3.22.llvm.14454761975545227518>
  8261ac:	mov    %r14,%rsi
  8261af:	call   *0x65afab(%rip)        # e81160 <_DYNAMIC+0x4f8>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826810 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  826810:	push   %rbp
  826811:	push   %r15
  826813:	push   %r14
  826815:	push   %r13
  826817:	push   %r12
  826819:	push   %rbx
  82681a:	sub    $0x38,%rsp
  82681e:	mov    %rcx,%r15
  826821:	mov    %rdx,%r12
  826824:	mov    %rsi,%r14
  826827:	mov    %rdi,%rbx
  82682a:	lea    0x20(%rsi),%r13
  82682e:	mov    %r13,%rdi
  826831:	mov    %rdx,%rsi
  826834:	call   826f50 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  826839:	cmpq   $0x0,0x10(%r14)
  82683e:	je     8269c1 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  826844:	mov    (%r14),%r11
  826847:	mov    0x8(%r14),%rsi
  82684b:	mov    %rax,%rdx
  82684e:	shr    $0x39,%rdx
  826852:	movd   %edx,%xmm0
  826856:	punpcklbw %xmm0,%xmm0
  82685a:	pshuflw $0x0,%xmm0,%xmm0
  82685f:	pshufd $0x44,%xmm0,%xmm0
  826864:	mov    (%r12),%rcx
  826868:	mov    %rcx,0x8(%rsp)
  82686d:	movzwl 0xc(%r12),%r9d
  826873:	mov    0x8(%r12),%r10d
  826878:	xor    %r13d,%r13d
  82687b:	pcmpeqd %xmm1,%xmm1
  82687f:	xor    %r8d,%r8d
  826882:	and    %rsi,%rax
  826885:	movdqu (%r11,%rax,1),%xmm2
  82688b:	movdqa %xmm2,%xmm3
  82688f:	pcmpeqb %xmm0,%xmm3
  826893:	pmovmskb %xmm3,%ebp
  826897:	test   %ebp,%ebp
  826899:	je     8268e0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  82689b:	mov    %r8,(%rsp)
  82689f:	mov    %r15,%r8
  8268a2:	tzcnt  %ebp,%r15d
  8268a7:	add    %rax,%r15
  8268aa:	and    %rsi,%r15
  8268ad:	shl    $0x5,%r15
  8268b1:	mov    %r11,%rcx
  8268b4:	sub    %r15,%rcx
  8268b7:	mov    0x8(%rsp),%r15
  8268bc:	cmp    -0x20(%rcx),%r15
  8268c0:	jne    8268cf <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8268c2:	cmp    -0x14(%rcx),%r9w
  8268c7:	jne    8268cf <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8268c9:	cmp    -0x18(%rcx),%r10d
  8268cd:	je     82691f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  8268cf:	lea    -0x1(%rbp),%ecx
  8268d2:	and    %bp,%cx
  8268d5:	mov    %ecx,%ebp
  8268d7:	mov    %r8,%r15
  8268da:	mov    (%rsp),%r8
  8268de:	jne    82689f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  8268e0:	cmp    $0x1,%r13
  8268e4:	je     8268f8 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  8268e6:	pmovmskb %xmm2,%ecx
  8268ea:	test   %ecx,%ecx
  8268ec:	je     82690c <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  8268ee:	tzcnt  %ecx,%edi
  8268f2:	add    %rax,%rdi
  8268f5:	and    %rsi,%rdi
  8268f8:	pcmpeqb %xmm1,%xmm2
  8268fc:	pmovmskb %xmm2,%ecx
  826900:	test   %ecx,%ecx
  826902:	jne    826936 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  826904:	mov    $0x1,%r13d
  82690a:	jmp    82690f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  82690c:	xor    %r13d,%r13d
  82690f:	add    %r8,%rax
  826912:	add    $0x10,%rax
  826916:	add    $0x10,%r8
  82691a:	jmp    826882 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  82691f:	movups -0x10(%rcx),%xmm0
  826923:	movups %xmm0,0x4(%rbx)
  826927:	movups (%r8),%xmm0
  82692b:	movups %xmm0,-0x10(%rcx)
  82692f:	mov    $0x1,%eax
  826934:	jmp    8269ad <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  826936:	movzbl (%r11,%rdi,1),%eax
  82693b:	test   %al,%al
  82693d:	jns    8269e2 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  826943:	movups (%r12),%xmm0
  826948:	movaps %xmm0,0x10(%rsp)
  82694d:	movups (%r15),%xmm0
  826951:	movaps %xmm0,0x20(%rsp)
  826956:	and    $0x1,%al
  826958:	lea    -0x10(%rdi),%rcx
  82695c:	and    %rsi,%rcx
  82695f:	mov    %dl,(%r11,%rdi,1)
  826963:	mov    %dl,0x10(%r11,%rcx,1)
  826968:	movzbl %al,%eax
  82696b:	movd   %eax,%xmm0
  82696f:	shufpd $0x2,-0x77b718(%rip),%xmm0        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  826978:	movdqu 0x10(%r14),%xmm1
  82697e:	psubq  %xmm0,%xmm1
  826982:	movdqu %xmm1,0x10(%r14)
  826988:	shl    $0x5,%rdi
  82698c:	mov    %r11,%rax
  82698f:	sub    %rdi,%rax
  826992:	neg    %rdi
  826995:	movaps 0x10(%rsp),%xmm0
  82699a:	movdqa 0x20(%rsp),%xmm1
  8269a0:	movups %xmm0,-0x20(%r11,%rdi,1)
  8269a6:	movdqu %xmm1,-0x10(%rax)
  8269ab:	xor    %eax,%eax
  8269ad:	mov    %eax,(%rbx)
  8269af:	mov    %rbx,%rax
  8269b2:	add    $0x38,%rsp
  8269b6:	pop    %rbx
  8269b7:	pop    %r12
  8269b9:	pop    %r13
  8269bb:	pop    %r14
  8269bd:	pop    %r15
  8269bf:	pop    %rbp
  8269c0:	ret
  8269c1:	mov    $0x1,%esi
  8269c6:	mov    %r14,%rdi
  8269c9:	mov    %r13,%rdx
  8269cc:	mov    $0x1,%ecx
  8269d1:	mov    %rax,%r13
  8269d4:	call   *0x65a926(%rip)        # e81300 <_DYNAMIC+0x698>
  8269da:	mov    %r13,%rax
  8269dd:	jmp    826844 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  8269e2:	movdqa (%r11),%xmm0
  8269e7:	pmovmskb %xmm0,%eax
  8269eb:	tzcnt  %eax,%edi
  8269ef:	movzbl (%r11,%rdi,1),%eax
  8269f4:	jmp    826943 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-csr-stats-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826a00 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  826a00:	push   %rbp
  826a01:	push   %r15
  826a03:	push   %r14
  826a05:	push   %r13
  826a07:	push   %r12
  826a09:	push   %rbx
  826a0a:	push   %rax
  826a0b:	mov    %r8d,%ebp
  826a0e:	mov    %ecx,%r14d
  826a11:	mov    %rdx,%r15
  826a14:	mov    %rsi,%r12
  826a17:	mov    %rdi,%rbx
  826a1a:	mov    %rdx,(%rsp)
  826a1e:	lea    0x20(%rsi),%r13
  826a22:	mov    %rsp,%rsi
  826a25:	mov    %r13,%rdi
  826a28:	call   8270f0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  826a2d:	cmpq   $0x0,0x10(%r12)
  826a33:	je     826b76 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  826a39:	mov    (%r12),%rcx
  826a3d:	mov    0x8(%r12),%rsi
  826a42:	mov    %rax,%rdx
  826a45:	shr    $0x39,%rdx
  826a49:	movd   %edx,%xmm0
  826a4d:	punpcklbw %xmm0,%xmm0
  826a51:	pshuflw $0x0,%xmm0,%xmm0
  826a56:	pshufd $0x44,%xmm0,%xmm0
  826a5b:	xor    %r9d,%r9d
  826a5e:	pcmpeqd %xmm1,%xmm1
  826a62:	xor    %r8d,%r8d
  826a65:	and    %rsi,%rax
  826a68:	movdqu (%rcx,%rax,1),%xmm2
  826a6d:	movdqa %xmm2,%xmm3
  826a71:	pcmpeqb %xmm0,%xmm3
  826a75:	pmovmskb %xmm3,%r10d
  826a7a:	test   %r10d,%r10d
  826a7d:	je     826ab0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  826a7f:	tzcnt  %r10d,%r13d
  826a84:	add    %rax,%r13
  826a87:	and    %rsi,%r13
  826a8a:	shl    $0x4,%r13
  826a8e:	mov    %rcx,%r11
  826a91:	sub    %r13,%r11
  826a94:	cmp    -0x10(%r11),%r15
  826a98:	je     826af1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  826a9a:	lea    -0x1(%r10),%r11d
  826a9e:	and    %r10w,%r11w
  826aa2:	mov    %r11d,%r10d
  826aa5:	jne    826a7f <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  826aa7:	nopw   0x0(%rax,%rax,1)
  826ab0:	cmp    $0x1,%r9
  826ab4:	je     826ac8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  826ab6:	pmovmskb %xmm2,%edi
  826aba:	test   %edi,%edi
  826abc:	je     826ade <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  826abe:	tzcnt  %edi,%edi
  826ac2:	add    %rax,%rdi
  826ac5:	and    %rsi,%rdi
  826ac8:	pcmpeqb %xmm1,%xmm2
  826acc:	pmovmskb %xmm2,%r9d
  826ad1:	test   %r9d,%r9d
  826ad4:	jne    826b08 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  826ad6:	mov    $0x1,%r9d
  826adc:	jmp    826ae1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  826ade:	xor    %r9d,%r9d
  826ae1:	add    %r8,%rax
  826ae4:	add    $0x10,%rax
  826ae8:	add    $0x10,%r8
  826aec:	jmp    826a65 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  826af1:	mov    -0x8(%r11),%rax
  826af5:	mov    %r14d,-0x8(%r11)
  826af9:	mov    %ebp,-0x4(%r11)
  826afd:	mov    %rax,0x4(%rbx)
  826b01:	mov    $0x1,%eax
  826b06:	jmp    826b62 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  826b08:	movzbl (%rcx,%rdi,1),%eax
  826b0c:	test   %al,%al
  826b0e:	jns    826b97 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  826b14:	and    $0x1,%al
  826b16:	lea    -0x10(%rdi),%r8
  826b1a:	and    %rsi,%r8
  826b1d:	mov    %dl,(%rcx,%rdi,1)
  826b20:	mov    %dl,0x10(%rcx,%r8,1)
  826b25:	movdqu 0x10(%r12),%xmm0
  826b2c:	movzbl %al,%eax
  826b2f:	movd   %eax,%xmm1
  826b33:	shufpd $0x2,-0x77b8dc(%rip),%xmm1        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  826b3c:	psubq  %xmm1,%xmm0
  826b40:	movdqu %xmm0,0x10(%r12)
  826b47:	shl    $0x4,%rdi
  826b4b:	mov    %rcx,%rax
  826b4e:	sub    %rdi,%rax
  826b51:	neg    %rdi
  826b54:	mov    %r15,-0x10(%rcx,%rdi,1)
  826b59:	mov    %r14d,-0x8(%rax)
  826b5d:	mov    %ebp,-0x4(%rax)
  826b60:	xor    %eax,%eax
  826b62:	mov    %eax,(%rbx)
  826b64:	mov    %rbx,%rax
  826b67:	add    $0x8,%rsp
  826b6b:	pop    %rbx
  826b6c:	pop    %r12
  826b6e:	pop    %r13
  826b70:	pop    %r14
  826b72:	pop    %r15
  826b74:	pop    %rbp
  826b75:	ret
  826b76:	mov    $0x1,%esi
  826b7b:	mov    %r12,%rdi
  826b7e:	mov    %r13,%rdx
  826b81:	mov    $0x1,%ecx
  826b86:	mov    %rax,%r13
  826b89:	call   *0x65a779(%rip)        # e81308 <_DYNAMIC+0x6a0>
  826b8f:	mov    %r13,%rax
  826b92:	jmp    826a39 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  826b97:	movdqa (%rcx),%xmm0
  826b9b:	pmovmskb %xmm0,%eax
  826b9f:	tzcnt  %eax,%edi
  826ba3:	movzbl (%rcx,%rdi,1),%eax
  826ba7:	jmp    826b14 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>
