from pathlib import Path
import gzip
import hashlib
import json
import tarfile

ROOTS = {
    'evidence': Path('/tmp/gpui-coverage-setup-evidence'),
    'codegen/initial-0359': Path('/tmp/gpui-coverage-setup-codegen'),
    'codegen/borrowed-779': Path('/tmp/gpui-coverage-borrowed-codegen'),
    'codegen/rejected-e7': Path('/tmp/gpui-coverage-final-codegen'),
    'codegen/sealed': Path('/tmp/gpui-coverage-sealed-codegen'),
}
ARCHIVE = Path('/tmp/gpui-coverage-setup-qualified.tar.gz')
MANIFEST = Path('/tmp/gpui-coverage-setup-capture-manifest.json')

def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while block := stream.read(1024 * 1024):
            value.update(block)
    return value.hexdigest()

members = []
external = []
for prefix, root in ROOTS.items():
    for path in sorted(root.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        with path.open('rb') as stream:
            elf = stream.read(4) == b'\x7fELF'
        entry = {'member': prefix + '/' + str(path.relative_to(root)),
                 'source_path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
        if elf:
            external.append({**entry, 'reason': 'ELF excluded; preserved externally with exact hash.'})
        else:
            members.append(entry)
manifest = {'source': '6158d25e483dea439832399e768ff4fbe1202640',
            'baseline': 'a81bc7536b002b1f81e1b36137c1c4de543e2204',
            'payload_members': members, 'external_elf': external,
            'manifest_member': 'capture-manifest.json',
            'manifest_integrity': 'Anchored by external archive SHA-256; every other member is individually hashed.',
            'scope': 'Correctness/static qualification and intermediate costs. No timing campaign or adoption claim.'}
MANIFEST.write_text(json.dumps(manifest, indent=2) + '\n')
assert not ARCHIVE.exists()
with ARCHIVE.open('wb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, compresslevel=6, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as archive:
            for entry in members:
                archive.add(entry['source_path'], arcname=entry['member'], recursive=False)
            archive.add(MANIFEST, arcname='capture-manifest.json', recursive=False)
expected = {entry['member']: entry for entry in members}
seen = set()
with tarfile.open(ARCHIVE, 'r:gz') as archive:
    for member in archive:
        assert member.isfile() and member.name not in seen
        seen.add(member.name)
        stream = archive.extractfile(member)
        value = hashlib.sha256()
        size = 0
        while block := stream.read(1024 * 1024):
            value.update(block)
            size += len(block)
        if member.name == 'capture-manifest.json':
            assert size == MANIFEST.stat().st_size and value.hexdigest() == sha(MANIFEST)
        else:
            assert size == expected[member.name]['bytes']
            assert value.hexdigest() == expected[member.name]['sha256'], member.name
assert seen == set(expected) | {'capture-manifest.json'}
report = {'archive': str(ARCHIVE), 'bytes': ARCHIVE.stat().st_size,
          'sha256': sha(ARCHIVE), 'payload_files': len(members),
          'payload_bytes': sum(entry['bytes'] for entry in members),
          'external_elf_files': len(external), 'manifest_sha256': sha(MANIFEST),
          'every_member_reopened_and_verified': True}
Path('/tmp/gpui-coverage-setup-archive-verification.json').write_text(json.dumps(report, indent=2) + '\n')
Path('/tmp/gpui-coverage-setup-qualified.tar.gz.sha256').write_text(report['sha256'] + '  ' + str(ARCHIVE) + '\n')
print(json.dumps(report, indent=2))
