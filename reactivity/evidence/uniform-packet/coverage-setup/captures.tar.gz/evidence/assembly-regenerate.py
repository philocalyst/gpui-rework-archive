from pathlib import Path
import json
import subprocess

ROOT = Path('/tmp/gpui-coverage-setup-codegen')
OBJDUMP = '/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/objdump'
selected = {'<gpui_gpu::renderer::RendererState>::bin_draw': 'bin-draw',
            '<gpui_gpu::renderer::RendererState>::render': 'render',
            'gpui_gpu::renderer::coverage::whole': 'whole',
            'gpui_gpu::renderer::coverage::axis': 'axis'}

def write_function(stream, function, binary):
    stream.write(f"\nFUNCTION {function['normalized_name']} bytes={function['code_bytes']} frame={function['stack_bytes']}\n")
    stream.flush()
    subprocess.run([OBJDUMP, '-d', '--demangle=rust', '--no-show-raw-insn',
                    f"--start-address={function['address']}",
                    f"--stop-address={function['address'] + function['code_bytes']}", str(binary)],
                   stdout=stream, check=True)

for label in ['baseline', 'candidate']:
    directory = ROOT / label
    ledger = json.loads((directory / 'groups-elf.json').read_text())
    old = directory / 'all-gpu-functions.asm'
    old.rename(directory / 'all-gpu-functions-initial-buffered-headers.asm')
    with old.open('w') as stream:
        seen = set()
        for function in sorted(ledger['all_gpu_frames'], key=lambda f: f['address']):
            if function['address'] in seen:
                continue
            seen.add(function['address'])
            write_function(stream, function, directory / 'groups')
    for name, stem in selected.items():
        functions = [f for f in ledger['all_gpu_frames'] if f['normalized_name'] == name]
        if functions:
            assert len(functions) == 1
            with (directory / (stem + '.asm')).open('w') as stream:
                write_function(stream, functions[0], directory / 'groups')
print('Assembly headers now flushed before objdump; preserved binaries and metadata unchanged.')
