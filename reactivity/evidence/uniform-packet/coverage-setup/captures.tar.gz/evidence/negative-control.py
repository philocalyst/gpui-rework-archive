from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/tmp/gpui-coverage-setup-sol')
OUT = Path('/tmp/gpui-coverage-setup-evidence')
SOURCE = ROOT / 'reactivity/crates/gpu/src/renderer/coverage.rs'
original = SOURCE.read_bytes()
needle = b'certificate(draw, error, columns, width, height).unwrap_or(false)'
assert original.count(needle) == 1
fault = original.replace(needle, needle + b' || draw.source.is_solid()')
env = dict(os.environ)
env.pop('RUSTFLAGS', None)
env.pop('CARGO_ENCODED_RUSTFLAGS', None)
env['CARGO_BUILD_JOBS'] = '1'
env['CARGO_TARGET_DIR'] = '/tmp/gpui-coverage-setup-target'
args = ['cargo', 'test', '--release', '--offline', '--locked', '-p', 'gpui_gpu',
        '--features', 'vulkan-tests', '--test', 'render',
        'whole_coverage_setup_preserves_partial_edges_and_hdr_order', '--', '--exact', '--nocapture']
result = {'args': args, 'original_sha256': hashlib.sha256(original).hexdigest(),
          'fault_sha256': hashlib.sha256(fault).hexdigest()}
try:
    SOURCE.write_bytes(fault)
    with (OUT / 'negative-false-certificate.log').open('w') as log:
        failed = subprocess.run(args, cwd=ROOT / 'reactivity', env=env,
                                stdout=log, stderr=subprocess.STDOUT)
    result['fault_returncode'] = failed.returncode
    result['actual_pixel_fault_detected'] = (failed.returncode != 0 and
        'whole-coverage setup changed pixels: HDR=false, stage=1' in
        (OUT / 'negative-false-certificate.log').read_text())
    assert result['actual_pixel_fault_detected'], 'fault did not reach the required actual pixel assertion'
finally:
    SOURCE.write_bytes(original)
    assert SOURCE.read_bytes() == original
    result['exact_source_restored'] = True
    (OUT / 'negative-control.json').write_text(json.dumps(result, indent=2) + '\n')
with (OUT / 'negative-recovery.log').open('w') as log:
    recovered = subprocess.run(args, cwd=ROOT / 'reactivity', env=env,
                               stdout=log, stderr=subprocess.STDOUT)
result['recovery_returncode'] = recovered.returncode
(OUT / 'negative-control.json').write_text(json.dumps(result, indent=2) + '\n')
assert recovered.returncode == 0
print(json.dumps(result, indent=2))
