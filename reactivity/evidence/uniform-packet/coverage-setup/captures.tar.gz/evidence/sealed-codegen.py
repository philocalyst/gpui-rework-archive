from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess

ROOT = Path('/tmp/gpui-coverage-setup-sol')
SUPPORT = Path('/tmp/gpui-coverage-setup-evidence')
OUT = Path('/tmp/gpui-coverage-sealed-codegen')
TARGET = Path('/tmp/gpui-coverage-setup-codegen-target')
BASELINE = 'a81bc7536b002b1f81e1b36137c1c4de543e2204'
CANDIDATE = '6158d25e483dea439832399e768ff4fbe1202640'
BIN = '/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/'
spec = importlib.util.spec_from_file_location('elf_inspect', '/tmp/gpui-uniform-support/elf_inspect.py')
elf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(elf)

def git(*args):
    return subprocess.check_output(['git', '-c', 'safe.directory=' + str(ROOT), '-C', str(ROOT), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
assert not git('status', '--porcelain')
paths = git('ls-files', 'reactivity/crates/gpu/src', 'reactivity/crates/gpu/build.rs').decode().splitlines()
original = {name: (ROOT / name).read_bytes() for name in paths}
guards = {name: sha((ROOT / name).read_bytes()) for name in git('ls-files',
          'reactivity/crates', 'reactivity/vendor', 'reactivity/Cargo.lock',
          'reactivity/Cargo.toml', '.cargo/config.toml').decode().splitlines()
          if '/evidence/' not in name}
OUT.mkdir(exist_ok=True)
env = dict(os.environ)
env.pop('RUSTFLAGS', None)
env.pop('CARGO_ENCODED_RUSTFLAGS', None)
env['CARGO_BUILD_JOBS'] = '1'
env['CARGO_TARGET_DIR'] = str(TARGET)
env['RUSTC_BOOTSTRAP'] = '1'
metadata = {'baseline': BASELINE, 'candidate': CANDIDATE, 'same_physical_source_path': str(ROOT),
            'rustc': subprocess.check_output(['rustc', '-vV'], text=True),
            'cargo': subprocess.check_output(['cargo', '-V'], text=True),
            'root_config_sha256': sha((ROOT / '.cargo/config.toml').read_bytes()),
            'stack_config_sha256': sha((SUPPORT / 'codegen.toml').read_bytes()),
            'guards_sha256': guards, 'lanes': {},
            'scope': 'Matched linked code/static metadata frames, not elapsed time or dynamic stack.'}
metadata['lanes']['baseline'] = json.loads(Path('/tmp/gpui-coverage-setup-codegen/metadata.json').read_text())['lanes']['baseline']
metadata['baseline_capture_reused_from'] = '/tmp/gpui-coverage-setup-codegen/baseline'
try:
    for label, ref in [('candidate', CANDIDATE)]:
        directory = OUT / label
        directory.mkdir()
        available = set(git('ls-tree', '-r', '--name-only', ref, '--',
                        'reactivity/crates/gpu/src', 'reactivity/crates/gpu/build.rs').decode().splitlines())
        wanted = {name: git('show', ref + ':' + name) for name in available}
        for name in paths:
            if name in wanted:
                if (ROOT / name).read_bytes() != wanted[name]:
                    (ROOT / name).write_bytes(wanted[name])
            else:
                (ROOT / name).unlink()
        with (directory / 'clean.log').open('w') as log:
            subprocess.run(['cargo', 'clean', '--release', '-p', 'gpui_gpu'],
                           cwd=ROOT / 'reactivity', env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        args = ['cargo', '--config', str(SUPPORT / 'codegen.toml'), 'build', '--release',
                '--offline', '--locked', '-p', 'gpui_gpu', '--example', 'groups',
                '--features', 'vulkan-tests', '--message-format=json', '-vv']
        with (directory / 'cargo.jsonl').open('w') as stdout, (directory / 'cargo.log').open('w') as stderr:
            subprocess.run(args, cwd=ROOT / 'reactivity', env=env, stdout=stdout, stderr=stderr, check=True)
        artifacts = [json.loads(line) for line in (directory / 'cargo.jsonl').read_text().splitlines()
                     if line.startswith('{')]
        library = [a for a in artifacts if a.get('reason') == 'compiler-artifact'
                   and a.get('target', {}).get('name') == 'gpui_gpu'
                   and a.get('target', {}).get('kind') == ['lib']]
        groups = [a for a in artifacts if a.get('reason') == 'compiler-artifact'
                  and a.get('target', {}).get('name') == 'groups'
                  and a.get('target', {}).get('kind') == ['example']]
        assert len(library) == len(groups) == 1 and not library[0]['fresh'] and not groups[0]['fresh']
        assert library[0]['profile']['opt_level'] == groups[0]['profile']['opt_level'] == '3'
        executable = directory / 'groups'
        shutil.copy2(groups[0]['executable'], executable)
        executable.chmod(0o555)
        info = elf.inspect(executable)
        (directory / 'groups-elf.json').write_text(json.dumps(info, indent=2) + '\n')
        lane = {'ref': ref, 'source_sha256': {name: sha(data) for name, data in wanted.items()},
                'args': args, 'library_artifact': library[0], 'groups_artifact': groups[0],
                'binary_sha256': sha(executable.read_bytes()), 'binary': str(executable)}
        metadata['lanes'][label] = lane
        with (directory / 'all-gpu-functions.asm').open('w') as log:
            seen = set()
            for f in sorted(info['all_gpu_frames'], key=lambda f: f['address']):
                if f['address'] in seen:
                    continue
                seen.add(f['address'])
                log.write(f"\nFUNCTION {f['normalized_name']} bytes={f['code_bytes']} frame={f['stack_bytes']}\n")
                log.flush()
                subprocess.run([BIN + 'objdump', '-d', '--demangle=rust', '--no-show-raw-insn',
                                f"--start-address={f['address']}", f"--stop-address={f['address'] + f['code_bytes']}",
                                str(executable)], stdout=log, check=True)
        fingerprints = directory / 'fingerprints'
        fingerprints.mkdir()
        for fp in (TARGET / 'release/.fingerprint').glob('gpui_gpu-*'):
            shutil.copytree(fp, fingerprints / fp.name)
        assert {name: (ROOT / name).read_bytes() for name in available} == wanted
        for name, digest in guards.items():
            if name not in paths:
                assert sha((ROOT / name).read_bytes()) == digest, name
        (OUT / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
        print(label + ' matched binary preserved', flush=True)
finally:
    for name, data in original.items():
        if (ROOT / name).read_bytes() != data:
            (ROOT / name).write_bytes(data)
    assert {name: (ROOT / name).read_bytes() for name in paths} == original
    metadata['restored_status'] = git('status', '--porcelain').decode()
    (OUT / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
assert not metadata['restored_status']
ledgers = {label: json.loads((OUT / label / 'groups-elf.json').read_text()) for label in ['baseline', 'candidate']}
by_name = {}
for label, ledger in ledgers.items():
    values = collections.defaultdict(list)
    for f in ledger['all_gpu_frames']:
        values[f['normalized_name']].append(f)
    by_name[label] = values
pairs = []
unpaired = []
for name in sorted(set(by_name['baseline']) | set(by_name['candidate'])):
    old = by_name['baseline'].get(name, [])
    new = by_name['candidate'].get(name, [])
    if len(old) == len(new) == 1:
        pairs.append({'name': name, 'baseline': old[0], 'candidate': new[0],
                      'code_delta': new[0]['code_bytes'] - old[0]['code_bytes'],
                      'frame_delta': new[0]['stack_bytes'] - old[0]['stack_bytes']})
    else:
        unpaired.append({'name': name, 'baseline': old, 'candidate': new})
summary = {'section_deltas': {name: ledgers['candidate']['sections'][name] - ledgers['baseline']['sections'][name]
                             for name in ['.text', '.rodata', '.data.rel.ro', '.stack_sizes']},
           'unique_name_pairs': pairs, 'unpaired_or_ambiguous': unpaired,
           'scope': 'All GPU symbol aliases retained. Only unique normalized-name pairs are paired. Static frames are not dynamic peak or additive call chains.'}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary['section_deltas'], indent=2), flush=True)
