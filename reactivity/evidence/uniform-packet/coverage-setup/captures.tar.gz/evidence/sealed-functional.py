from pathlib import Path
import csv
import hashlib
import json
import shutil
import subprocess

ROOT = Path('/tmp/gpui-coverage-setup-sol')
OUT = Path('/tmp/gpui-coverage-setup-evidence')
REFERENCE = Path('/tmp/gpui-gpu-frontier-evidence/calibration/pair-00-B')
FIXTURE = ROOT / 'reactivity/crates/gpu/examples/qualification.rs'
assert hashlib.sha256(FIXTURE.read_bytes()).hexdigest() == '8773146b44150adb0150323d51f241c946fb5cda26328f004562dcd9dee39cc0'
artifacts = [json.loads(line) for line in (OUT / 'sealed-functional-build.jsonl').read_text().splitlines()
             if line.startswith('{')]
binary = next(a for a in artifacts if a.get('reason') == 'compiler-artifact'
              and a.get('target', {}).get('name') == 'qualification')
executable = OUT / 'qualification-sealed'
shutil.copy2(binary['executable'], executable)
executable.chmod(0o555)
report = {'source': '6158d25e483dea439832399e768ff4fbe1202640',
          'fixture_sha256': hashlib.sha256(FIXTURE.read_bytes()).hexdigest(),
          'binary_sha256': hashlib.sha256(executable.read_bytes()).hexdigest(),
          'artifact': binary, 'scope': 'One two-frame functional process only; no timing qualification or claim.'}
try:
    with (OUT / 'sealed-functional-run.log').open('w') as log:
        completed = subprocess.run([str(executable), str(OUT / 'sealed-functional-readbacks'), 'calibration'],
                                   stdout=log, stderr=subprocess.STDOUT, timeout=240)
    report['returncode'] = completed.returncode
    assert completed.returncode == 0
    actual = {p.name: p for p in (OUT / 'sealed-functional-readbacks').glob('*.bin')}
    expected = {p.name: p for p in REFERENCE.glob('*.bin')}
    assert actual.keys() == expected.keys() and len(actual) == 52
    captures = []
    for name in sorted(actual):
        new = actual[name].read_bytes()
        old = expected[name].read_bytes()
        assert new == old, name
        captures.append({'path': name, 'bytes': len(new), 'sha256': hashlib.sha256(new).hexdigest()})
    report['readbacks'] = captures
    report['exact_readback_bytes'] = sum(p['bytes'] for p in captures)
    with (OUT / 'sealed-functional-readbacks/frames.csv').open() as stream:
        new_rows = list(csv.DictReader(stream))
    with (REFERENCE / 'frames.csv').open() as stream:
        old_rows = list(csv.DictReader(stream))
    assert len(new_rows) == len(old_rows) == 52
    keys = ['case', 'hdr', 'motion', 'frame', 'sampled', 'stats', 'image_stats']
    assert [{k: r[k] for k in keys} for r in new_rows] == [{k: r[k] for k in keys} for r in old_rows]
    report['all_52_renderer_and_image_diagnostics_match'] = True
    report['adapter_matches'] = (OUT / 'sealed-functional-readbacks/adapter.txt').read_bytes() == (REFERENCE / 'adapter.txt').read_bytes()
    assert report['adapter_matches']
finally:
    FIXTURE.unlink()
    (OUT / 'sealed-functional-summary.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ['readbacks', 'artifact']}, indent=2))
