FUNCTION gpui_gpu::renderer::coverage::axis bytes=2744 frame=376

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825950 <gpui_gpu::renderer::coverage::axis>:
  825950:	push   %r15
  825952:	push   %r14
  825954:	push   %r13
  825956:	push   %r12
  825958:	push   %rbx
  825959:	sub    $0x150,%rsp
  825960:	movq   %xmm4,%r12
  825965:	movabs $0x7fffffffffffffff,%rbx
  82596f:	and    %rbx,%r12
  825972:	mov    $0x2,%al
  825974:	movabs $0x7fefffffffffffff,%r14
  82597e:	cmp    %r14,%r12
  825981:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825987:	movapd %xmm0,%xmm15
  82598c:	movq   (%rdi),%xmm8
  825991:	movq   0x8(%rdi),%xmm13
  825997:	movq   0x10(%rdi),%xmm10
  82599d:	xorpd  %xmm0,%xmm0
  8259a1:	ucomisd %xmm0,%xmm4
  8259a5:	jne    8259a9 <gpui_gpu::renderer::coverage::axis+0x59>
  8259a7:	jnp    8259c1 <gpui_gpu::renderer::coverage::axis+0x71>
  8259a9:	lea    -0x1(%r12),%rcx
  8259ae:	movabs $0xfffffffffffff,%rdx
  8259b8:	cmp    %rdx,%rcx
  8259bb:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8259c1:	movq   %xmm5,%r15
  8259c6:	and    %rbx,%r15
  8259c9:	cmp    %r14,%r15
  8259cc:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8259d2:	ucomisd %xmm0,%xmm5
  8259d6:	jne    8259da <gpui_gpu::renderer::coverage::axis+0x8a>
  8259d8:	jnp    8259f1 <gpui_gpu::renderer::coverage::axis+0xa1>
  8259da:	lea    -0x1(%r15),%rcx
  8259de:	movabs $0xfffffffffffff,%rdx
  8259e8:	cmp    %rdx,%rcx
  8259eb:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8259f1:	movq   %xmm8,%rdx
  8259f6:	and    %rbx,%rdx
  8259f9:	cmp    %r14,%rdx
  8259fc:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825a02:	xorpd  %xmm11,%xmm11
  825a07:	ucomisd %xmm11,%xmm8
  825a0c:	xorpd  %xmm12,%xmm12
  825a11:	jne    825e54 <gpui_gpu::renderer::coverage::axis+0x504>
  825a17:	jp     825e54 <gpui_gpu::renderer::coverage::axis+0x504>
  825a1d:	movq   %xmm13,%rdx
  825a22:	and    %rbx,%rdx
  825a25:	cmp    %r14,%rdx
  825a28:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825a2e:	movapd %xmm1,%xmm14
  825a33:	ucomisd %xmm0,%xmm13
  825a38:	xorpd  %xmm9,%xmm9
  825a3d:	xorpd  %xmm1,%xmm1
  825a41:	jne    825f08 <gpui_gpu::renderer::coverage::axis+0x5b8>
  825a47:	jp     825f08 <gpui_gpu::renderer::coverage::axis+0x5b8>
  825a4d:	ucomisd %xmm0,%xmm9
  825a52:	jne    825a5e <gpui_gpu::renderer::coverage::axis+0x10e>
  825a54:	jp     825a5e <gpui_gpu::renderer::coverage::axis+0x10e>
  825a56:	ucomisd %xmm0,%xmm1
  825a5a:	jne    825a5e <gpui_gpu::renderer::coverage::axis+0x10e>
  825a5c:	jnp    825a8a <gpui_gpu::renderer::coverage::axis+0x13a>
  825a5e:	ucomisd %xmm0,%xmm11
  825a63:	jne    825fbd <gpui_gpu::renderer::coverage::axis+0x66d>
  825a69:	jp     825fbd <gpui_gpu::renderer::coverage::axis+0x66d>
  825a6f:	ucomisd %xmm0,%xmm12
  825a74:	jne    825fbd <gpui_gpu::renderer::coverage::axis+0x66d>
  825a7a:	jp     825fbd <gpui_gpu::renderer::coverage::axis+0x66d>
  825a80:	movapd %xmm9,%xmm12
  825a85:	movapd %xmm1,%xmm11
  825a8a:	movq   %xmm10,%r13
  825a8f:	and    %rbx,%r13
  825a92:	cmp    %r14,%r13
  825a95:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825a9b:	ucomisd %xmm0,%xmm10
  825aa0:	jne    826001 <gpui_gpu::renderer::coverage::axis+0x6b1>
  825aa6:	jp     826001 <gpui_gpu::renderer::coverage::axis+0x6b1>
  825aac:	movapd %xmm11,%xmm0
  825ab1:	movapd %xmm12,%xmm1
  825ab6:	movaps %xmm8,0x20(%rsp)
  825abc:	movapd %xmm15,0x80(%rsp)
  825ac6:	movapd %xmm14,0x40(%rsp)
  825acd:	movaps %xmm13,0x120(%rsp)
  825ad6:	movapd %xmm2,0x130(%rsp)
  825adf:	movapd %xmm3,0x140(%rsp)
  825ae8:	movaps %xmm10,0x110(%rsp)
  825af1:	movsd  %xmm6,0x98(%rsp)
  825afa:	movsd  %xmm7,0x38(%rsp)
  825b00:	movaps %xmm5,0x70(%rsp)
  825b05:	lea    0x8(%rsp),%rdi
  825b0a:	movapd %xmm4,%xmm2
  825b0e:	movaps %xmm4,0x100(%rsp)
  825b16:	movapd %xmm4,%xmm3
  825b1a:	call   8257d0 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825b1f:	cmpl   $0x1,0x8(%rsp)
  825b24:	jne    825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825b2a:	movapd 0x20(%rsp),%xmm2
  825b30:	andpd  -0x77ad08(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825b38:	movsd  0x10(%rsp),%xmm0
  825b3e:	movsd  %xmm0,0x20(%rsp)
  825b44:	movsd  0x18(%rsp),%xmm0
  825b4a:	movsd  %xmm0,0x90(%rsp)
  825b53:	lea    0x8(%rsp),%rdi
  825b58:	movapd 0x80(%rsp),%xmm0
  825b61:	movapd 0x40(%rsp),%xmm1
  825b67:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825b6c:	cmpb   $0x0,0x8(%rsp)
  825b71:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825b77:	movapd 0x120(%rsp),%xmm2
  825b80:	andpd  -0x77ad58(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825b88:	movsd  0x10(%rsp),%xmm0
  825b8e:	movsd  %xmm0,0x40(%rsp)
  825b94:	movsd  0x18(%rsp),%xmm0
  825b9a:	movsd  %xmm0,0x80(%rsp)
  825ba3:	lea    0x8(%rsp),%rdi
  825ba8:	movapd 0x130(%rsp),%xmm0
  825bb1:	movapd 0x140(%rsp),%xmm1
  825bba:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825bbf:	cmpb   $0x0,0x8(%rsp)
  825bc4:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825bca:	movsd  0x10(%rsp),%xmm2
  825bd0:	movsd  0x18(%rsp),%xmm3
  825bd6:	lea    0x58(%rsp),%rdi
  825bdb:	movsd  0x40(%rsp),%xmm0
  825be1:	movsd  0x80(%rsp),%xmm1
  825bea:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825bef:	cmpb   $0x0,0x58(%rsp)
  825bf4:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825bfa:	xorpd  %xmm0,%xmm0
  825bfe:	movapd 0x110(%rsp),%xmm2
  825c07:	ucomisd %xmm0,%xmm2
  825c0b:	movsd  0x60(%rsp),%xmm0
  825c11:	movsd  0x68(%rsp),%xmm1
  825c17:	jne    825c1b <gpui_gpu::renderer::coverage::axis+0x2cb>
  825c19:	jnp    825c31 <gpui_gpu::renderer::coverage::axis+0x2e1>
  825c1b:	dec    %r13
  825c1e:	movabs $0xfffffffffffff,%rax
  825c28:	cmp    %rax,%r13
  825c2b:	jb     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825c31:	andpd  -0x77ae09(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825c39:	lea    0xe8(%rsp),%rdi
  825c41:	movapd %xmm2,%xmm3
  825c45:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825c4a:	cmpb   $0x0,0xe8(%rsp)
  825c52:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825c58:	xorpd  %xmm0,%xmm0
  825c5c:	movapd 0x100(%rsp),%xmm2
  825c65:	ucomisd %xmm0,%xmm2
  825c69:	movsd  0xf0(%rsp),%xmm0
  825c72:	movsd  0xf8(%rsp),%xmm1
  825c7b:	jne    825c7f <gpui_gpu::renderer::coverage::axis+0x32f>
  825c7d:	jnp    825c95 <gpui_gpu::renderer::coverage::axis+0x345>
  825c7f:	dec    %r12
  825c82:	movabs $0xfffffffffffff,%rax
  825c8c:	cmp    %rax,%r12
  825c8f:	jb     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825c95:	andpd  -0x77ae6d(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825c9d:	lea    0xd0(%rsp),%rdi
  825ca5:	movapd %xmm2,%xmm3
  825ca9:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825cae:	cmpb   $0x0,0xd0(%rsp)
  825cb6:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825cbc:	xorpd  %xmm0,%xmm0
  825cc0:	movapd 0x70(%rsp),%xmm1
  825cc6:	ucomisd %xmm0,%xmm1
  825cca:	movsd  0xd8(%rsp),%xmm0
  825cd3:	movsd  0xe0(%rsp),%xmm1
  825cdc:	jne    825ce0 <gpui_gpu::renderer::coverage::axis+0x390>
  825cde:	jnp    825cf6 <gpui_gpu::renderer::coverage::axis+0x3a6>
  825ce0:	dec    %r15
  825ce3:	movabs $0xfffffffffffff,%rax
  825ced:	cmp    %rax,%r15
  825cf0:	jb     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825cf6:	movapd -0x77aece(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825cfe:	andpd  0x70(%rsp),%xmm2
  825d04:	lea    0xb8(%rsp),%rdi
  825d0c:	movapd %xmm2,%xmm3
  825d10:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825d15:	cmpb   $0x0,0xb8(%rsp)
  825d1d:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825d23:	movsd  0xc0(%rsp),%xmm0
  825d2c:	movsd  0xc8(%rsp),%xmm1
  825d35:	lea    0xa0(%rsp),%rdi
  825d3d:	movsd  -0x776465(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  825d45:	movapd %xmm2,%xmm3
  825d49:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825d4e:	cmpl   $0x1,0xa0(%rsp)
  825d56:	jne    825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825d5c:	movsd  0xa8(%rsp),%xmm0
  825d65:	movsd  0xb0(%rsp),%xmm1
  825d6e:	lea    0x8(%rsp),%rdi
  825d73:	movsd  0x98(%rsp),%xmm2
  825d7c:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825d81:	cmpb   $0x0,0x8(%rsp)
  825d86:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825d8c:	movq   0x38(%rsp),%xmm0
  825d92:	movq   %xmm0,%rax
  825d97:	and    %rbx,%rax
  825d9a:	cmp    %r14,%rax
  825d9d:	jg     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825da3:	movsd  0x10(%rsp),%xmm0
  825da9:	movsd  0x18(%rsp),%xmm1
  825daf:	xorpd  %xmm2,%xmm2
  825db3:	movsd  0x38(%rsp),%xmm3
  825db9:	ucomisd %xmm2,%xmm3
  825dbd:	jne    825dc1 <gpui_gpu::renderer::coverage::axis+0x471>
  825dbf:	jnp    825dd7 <gpui_gpu::renderer::coverage::axis+0x487>
  825dc1:	dec    %rax
  825dc4:	movabs $0xfffffffffffff,%rcx
  825dce:	cmp    %rcx,%rax
  825dd1:	jb     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825dd7:	lea    0x58(%rsp),%rdi
  825ddc:	movsd  0x38(%rsp),%xmm2
  825de2:	movapd %xmm2,%xmm3
  825de6:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825deb:	cmpb   $0x0,0x58(%rsp)
  825df0:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825df6:	movsd  0x68(%rsp),%xmm1
  825dfc:	movsd  0x20(%rsp),%xmm0
  825e02:	movsd  %xmm1,0x40(%rsp)
  825e08:	ucomisd %xmm1,%xmm0
  825e0c:	jbe    826404 <gpui_gpu::renderer::coverage::axis+0xab4>
  825e12:	lea    0x8(%rsp),%rdi
  825e17:	movapd 0x70(%rsp),%xmm0
  825e1d:	movapd %xmm0,%xmm1
  825e21:	movsd  0x20(%rsp),%xmm2
  825e27:	movsd  0x90(%rsp),%xmm3
  825e30:	call   8257d0 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825e35:	cmpl   $0x1,0x8(%rsp)
  825e3a:	jne    825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825e40:	movsd  0x10(%rsp),%xmm0
  825e46:	ucomisd 0x40(%rsp),%xmm0
  825e4c:	seta   %al
  825e4f:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825e54:	dec    %rdx
  825e57:	movabs $0xfffffffffffff,%rcx
  825e61:	cmp    %rcx,%rdx
  825e64:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825e6a:	ucomisd %xmm11,%xmm15
  825e6f:	jne    825e7f <gpui_gpu::renderer::coverage::axis+0x52f>
  825e71:	jp     825e7f <gpui_gpu::renderer::coverage::axis+0x52f>
  825e73:	ucomisd %xmm0,%xmm1
  825e77:	jne    825e7f <gpui_gpu::renderer::coverage::axis+0x52f>
  825e79:	jnp    825a1d <gpui_gpu::renderer::coverage::axis+0xcd>
  825e7f:	ucomisd %xmm11,%xmm8
  825e84:	movapd %xmm8,%xmm9
  825e89:	cmpltsd %xmm8,%xmm11
  825e8f:	movapd %xmm11,%xmm0
  825e94:	andpd  %xmm15,%xmm0
  825e99:	andnpd %xmm1,%xmm11
  825e9e:	orpd   %xmm0,%xmm11
  825ea3:	movapd %xmm1,%xmm12
  825ea8:	ja     825eaf <gpui_gpu::renderer::coverage::axis+0x55f>
  825eaa:	movapd %xmm15,%xmm12
  825eaf:	movapd %xmm9,%xmm8
  825eb4:	mulsd  %xmm9,%xmm12
  825eb9:	mulsd  %xmm9,%xmm11
  825ebe:	movq   %xmm11,%rsi
  825ec3:	movq   %xmm12,%rdx
  825ec8:	ucomisd %xmm11,%xmm11
  825ecd:	setp   %dil
  825ed1:	movabs $0xfff0000000000000,%r8
  825edb:	cmp    %r8,%rsi
  825ede:	sete   %r8b
  825ee2:	or     %dil,%r8b
  825ee5:	jne    8260a5 <gpui_gpu::renderer::coverage::axis+0x755>
  825eeb:	mov    %rsi,%rdi
  825eee:	and    %rbx,%rdi
  825ef1:	je     826091 <gpui_gpu::renderer::coverage::axis+0x741>
  825ef7:	cmp    %rdi,%rsi
  825efa:	jne    82609d <gpui_gpu::renderer::coverage::axis+0x74d>
  825f00:	dec    %rsi
  825f03:	jmp    8260a0 <gpui_gpu::renderer::coverage::axis+0x750>
  825f08:	dec    %rdx
  825f0b:	movabs $0xfffffffffffff,%rcx
  825f15:	cmp    %rcx,%rdx
  825f18:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825f1e:	ucomisd %xmm9,%xmm2
  825f23:	jne    825f33 <gpui_gpu::renderer::coverage::axis+0x5e3>
  825f25:	jp     825f33 <gpui_gpu::renderer::coverage::axis+0x5e3>
  825f27:	ucomisd %xmm1,%xmm3
  825f2b:	jne    825f33 <gpui_gpu::renderer::coverage::axis+0x5e3>
  825f2d:	jnp    825a4d <gpui_gpu::renderer::coverage::axis+0xfd>
  825f33:	movaps %xmm8,0x20(%rsp)
  825f39:	ucomisd %xmm1,%xmm13
  825f3e:	cmpltsd %xmm13,%xmm1
  825f44:	movapd %xmm1,%xmm8
  825f49:	andpd  %xmm2,%xmm8
  825f4e:	andnpd %xmm3,%xmm1
  825f52:	orpd   %xmm8,%xmm1
  825f57:	movapd %xmm3,%xmm9
  825f5c:	ja     825f63 <gpui_gpu::renderer::coverage::axis+0x613>
  825f5e:	movapd %xmm2,%xmm9
  825f63:	mulsd  %xmm13,%xmm9
  825f68:	mulsd  %xmm13,%xmm1
  825f6d:	movq   %xmm1,%rsi
  825f72:	movq   %xmm9,%rdx
  825f77:	ucomisd %xmm1,%xmm1
  825f7b:	setp   %dil
  825f7f:	movabs $0xfff0000000000000,%r8
  825f89:	cmp    %r8,%rsi
  825f8c:	sete   %r8b
  825f90:	or     %dil,%r8b
  825f93:	jne    82625d <gpui_gpu::renderer::coverage::axis+0x90d>
  825f99:	mov    %rsi,%rdi
  825f9c:	and    %rbx,%rdi
  825f9f:	je     826249 <gpui_gpu::renderer::coverage::axis+0x8f9>
  825fa5:	cmp    %rdi,%rsi
  825fa8:	jne    826255 <gpui_gpu::renderer::coverage::axis+0x905>
  825fae:	dec    %rsi
  825fb1:	jmp    826258 <gpui_gpu::renderer::coverage::axis+0x908>
  825fb6:	mov    $0x2,%al
  825fb8:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825fbd:	addsd  %xmm1,%xmm11
  825fc2:	addsd  %xmm9,%xmm12
  825fc7:	movq   %xmm11,%rdx
  825fcc:	movq   %xmm12,%rcx
  825fd1:	movabs $0xfff0000000000000,%rsi
  825fdb:	cmp    %rsi,%rdx
  825fde:	je     82617a <gpui_gpu::renderer::coverage::axis+0x82a>
  825fe4:	mov    %rdx,%rsi
  825fe7:	and    %rbx,%rsi
  825fea:	je     826166 <gpui_gpu::renderer::coverage::axis+0x816>
  825ff0:	cmp    %rsi,%rdx
  825ff3:	jne    826172 <gpui_gpu::renderer::coverage::axis+0x822>
  825ff9:	dec    %rdx
  825ffc:	jmp    826175 <gpui_gpu::renderer::coverage::axis+0x825>
  826001:	lea    -0x1(%r13),%rdx
  826005:	movabs $0xfffffffffffff,%rcx
  82600f:	cmp    %rcx,%rdx
  826012:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826018:	ucomisd %xmm0,%xmm12
  82601d:	jne    826038 <gpui_gpu::renderer::coverage::axis+0x6e8>
  82601f:	jp     826038 <gpui_gpu::renderer::coverage::axis+0x6e8>
  826021:	ucomisd %xmm0,%xmm11
  826026:	movapd %xmm10,%xmm0
  82602b:	movapd %xmm10,%xmm1
  826030:	jne    826038 <gpui_gpu::renderer::coverage::axis+0x6e8>
  826032:	jnp    825ab6 <gpui_gpu::renderer::coverage::axis+0x166>
  826038:	addsd  %xmm10,%xmm11
  82603d:	addsd  %xmm10,%xmm12
  826042:	movq   %xmm11,%rsi
  826047:	movq   %xmm12,%rdx
  82604c:	ucomisd %xmm11,%xmm11
  826051:	setp   %dil
  826055:	movabs $0xfff0000000000000,%r8
  82605f:	cmp    %r8,%rsi
  826062:	sete   %r8b
  826066:	or     %dil,%r8b
  826069:	movdqa %xmm11,%xmm0
  82606e:	jne    826342 <gpui_gpu::renderer::coverage::axis+0x9f2>
  826074:	mov    %rsi,%rdi
  826077:	and    %rbx,%rdi
  82607a:	je     82632e <gpui_gpu::renderer::coverage::axis+0x9de>
  826080:	cmp    %rdi,%rsi
  826083:	jne    82633a <gpui_gpu::renderer::coverage::axis+0x9ea>
  826089:	dec    %rsi
  82608c:	jmp    82633d <gpui_gpu::renderer::coverage::axis+0x9ed>
  826091:	movabs $0x8000000000000001,%rsi
  82609b:	jmp    8260a0 <gpui_gpu::renderer::coverage::axis+0x750>
  82609d:	inc    %rsi
  8260a0:	movq   %rsi,%xmm11
  8260a5:	ucomisd %xmm12,%xmm12
  8260aa:	setp   %sil
  8260ae:	movabs $0x7ff0000000000000,%rdi
  8260b8:	cmp    %rdi,%rdx
  8260bb:	sete   %dil
  8260bf:	or     %sil,%dil
  8260c2:	jne    8260e5 <gpui_gpu::renderer::coverage::axis+0x795>
  8260c4:	mov    %rdx,%rsi
  8260c7:	and    %rbx,%rsi
  8260ca:	je     8260d6 <gpui_gpu::renderer::coverage::axis+0x786>
  8260cc:	cmp    %rsi,%rdx
  8260cf:	jne    8260dd <gpui_gpu::renderer::coverage::axis+0x78d>
  8260d1:	inc    %rdx
  8260d4:	jmp    8260e0 <gpui_gpu::renderer::coverage::axis+0x790>
  8260d6:	mov    $0x1,%edx
  8260db:	jmp    8260e0 <gpui_gpu::renderer::coverage::axis+0x790>
  8260dd:	dec    %rdx
  8260e0:	movq   %rdx,%xmm12
  8260e5:	movq   %xmm11,%rsi
  8260ea:	and    %rbx,%rsi
  8260ed:	cmp    %r14,%rsi
  8260f0:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8260f6:	ucomisd %xmm12,%xmm11
  8260fb:	ja     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826101:	xorpd  %xmm0,%xmm0
  826105:	ucomisd %xmm0,%xmm11
  82610a:	movq   %xmm12,%rdx
  82610f:	jne    826123 <gpui_gpu::renderer::coverage::axis+0x7d3>
  826111:	jp     826123 <gpui_gpu::renderer::coverage::axis+0x7d3>
  826113:	mov    %rdx,%rsi
  826116:	and    %rbx,%rsi
  826119:	cmp    %r14,%rsi
  82611c:	jle    826145 <gpui_gpu::renderer::coverage::axis+0x7f5>
  82611e:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826123:	dec    %rsi
  826126:	mov    %rdx,%rdi
  826129:	and    %rbx,%rdi
  82612c:	cmp    %r14,%rdi
  82612f:	setg   %dil
  826133:	cmp    %rcx,%rsi
  826136:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  82613c:	test   %dil,%dil
  82613f:	jne    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826145:	ucomisd %xmm0,%xmm12
  82614a:	jne    826152 <gpui_gpu::renderer::coverage::axis+0x802>
  82614c:	jnp    825a1d <gpui_gpu::renderer::coverage::axis+0xcd>
  826152:	and    %rbx,%rdx
  826155:	dec    %rdx
  826158:	cmp    %rcx,%rdx
  82615b:	jae    825a1d <gpui_gpu::renderer::coverage::axis+0xcd>
  826161:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826166:	movabs $0x8000000000000001,%rdx
  826170:	jmp    826175 <gpui_gpu::renderer::coverage::axis+0x825>
  826172:	inc    %rdx
  826175:	movq   %rdx,%xmm11
  82617a:	ucomisd %xmm12,%xmm12
  82617f:	setp   %sil
  826183:	movabs $0x7ff0000000000000,%rdx
  82618d:	cmp    %rdx,%rcx
  826190:	sete   %dil
  826194:	or     %sil,%dil
  826197:	jne    8261ba <gpui_gpu::renderer::coverage::axis+0x86a>
  826199:	mov    %rcx,%rsi
  82619c:	and    %rbx,%rsi
  82619f:	je     8261ab <gpui_gpu::renderer::coverage::axis+0x85b>
  8261a1:	cmp    %rsi,%rcx
  8261a4:	jne    8261b2 <gpui_gpu::renderer::coverage::axis+0x862>
  8261a6:	inc    %rcx
  8261a9:	jmp    8261b5 <gpui_gpu::renderer::coverage::axis+0x865>
  8261ab:	mov    $0x1,%ecx
  8261b0:	jmp    8261b5 <gpui_gpu::renderer::coverage::axis+0x865>
  8261b2:	dec    %rcx
  8261b5:	movq   %rcx,%xmm12
  8261ba:	movq   %xmm11,%rsi
  8261bf:	and    %rbx,%rsi
  8261c2:	cmp    %r14,%rsi
  8261c5:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8261cb:	ucomisd %xmm12,%xmm11
  8261d0:	ja     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8261d6:	ucomisd %xmm0,%xmm11
  8261db:	movq   %xmm12,%rcx
  8261e0:	jne    8261f4 <gpui_gpu::renderer::coverage::axis+0x8a4>
  8261e2:	jp     8261f4 <gpui_gpu::renderer::coverage::axis+0x8a4>
  8261e4:	mov    %rcx,%rsi
  8261e7:	and    %rbx,%rsi
  8261ea:	cmp    %rdx,%rsi
  8261ed:	jl     82621e <gpui_gpu::renderer::coverage::axis+0x8ce>
  8261ef:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8261f4:	dec    %rsi
  8261f7:	mov    %rcx,%rdx
  8261fa:	and    %rbx,%rdx
  8261fd:	cmp    %r14,%rdx
  826200:	setg   %dl
  826203:	movabs $0xfffffffffffff,%rdi
  82620d:	cmp    %rdi,%rsi
  826210:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826216:	test   %dl,%dl
  826218:	jne    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  82621e:	ucomisd %xmm0,%xmm12
  826223:	jne    82622b <gpui_gpu::renderer::coverage::axis+0x8db>
  826225:	jnp    825a8a <gpui_gpu::renderer::coverage::axis+0x13a>
  82622b:	and    %rbx,%rcx
  82622e:	dec    %rcx
  826231:	movabs $0xfffffffffffff,%rdx
  82623b:	cmp    %rdx,%rcx
  82623e:	jae    825a8a <gpui_gpu::renderer::coverage::axis+0x13a>
  826244:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826249:	movabs $0x8000000000000001,%rsi
  826253:	jmp    826258 <gpui_gpu::renderer::coverage::axis+0x908>
  826255:	inc    %rsi
  826258:	movq   %rsi,%xmm1
  82625d:	ucomisd %xmm9,%xmm9
  826262:	setp   %sil
  826266:	movabs $0x7ff0000000000000,%rdi
  826270:	cmp    %rdi,%rdx
  826273:	sete   %dil
  826277:	or     %sil,%dil
  82627a:	jne    82629d <gpui_gpu::renderer::coverage::axis+0x94d>
  82627c:	mov    %rdx,%rsi
  82627f:	and    %rbx,%rsi
  826282:	je     82628e <gpui_gpu::renderer::coverage::axis+0x93e>
  826284:	cmp    %rsi,%rdx
  826287:	jne    826295 <gpui_gpu::renderer::coverage::axis+0x945>
  826289:	inc    %rdx
  82628c:	jmp    826298 <gpui_gpu::renderer::coverage::axis+0x948>
  82628e:	mov    $0x1,%edx
  826293:	jmp    826298 <gpui_gpu::renderer::coverage::axis+0x948>
  826295:	dec    %rdx
  826298:	movq   %rdx,%xmm9
  82629d:	movq   %xmm1,%rsi
  8262a2:	and    %rbx,%rsi
  8262a5:	cmp    %r14,%rsi
  8262a8:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262ae:	ucomisd %xmm9,%xmm1
  8262b3:	ja     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262b9:	xorpd  %xmm8,%xmm8
  8262be:	ucomisd %xmm8,%xmm1
  8262c3:	movq   %xmm9,%rdx
  8262c8:	jne    8262dc <gpui_gpu::renderer::coverage::axis+0x98c>
  8262ca:	jp     8262dc <gpui_gpu::renderer::coverage::axis+0x98c>
  8262cc:	mov    %rdx,%rsi
  8262cf:	and    %rbx,%rsi
  8262d2:	cmp    %r14,%rsi
  8262d5:	jle    8262fe <gpui_gpu::renderer::coverage::axis+0x9ae>
  8262d7:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262dc:	dec    %rsi
  8262df:	mov    %rdx,%rdi
  8262e2:	and    %rbx,%rdi
  8262e5:	cmp    %r14,%rdi
  8262e8:	setg   %dil
  8262ec:	cmp    %rcx,%rsi
  8262ef:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262f5:	test   %dil,%dil
  8262f8:	jne    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262fe:	ucomisd %xmm8,%xmm9
  826303:	jne    826313 <gpui_gpu::renderer::coverage::axis+0x9c3>
  826305:	jp     826313 <gpui_gpu::renderer::coverage::axis+0x9c3>
  826307:	movapd 0x20(%rsp),%xmm8
  82630e:	jmp    825a4d <gpui_gpu::renderer::coverage::axis+0xfd>
  826313:	and    %rbx,%rdx
  826316:	dec    %rdx
  826319:	cmp    %rcx,%rdx
  82631c:	movapd 0x20(%rsp),%xmm8
  826323:	jae    825a4d <gpui_gpu::renderer::coverage::axis+0xfd>
  826329:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  82632e:	movabs $0x8000000000000001,%rsi
  826338:	jmp    82633d <gpui_gpu::renderer::coverage::axis+0x9ed>
  82633a:	inc    %rsi
  82633d:	movq   %rsi,%xmm0
  826342:	ucomisd %xmm12,%xmm12
  826347:	setp   %dil
  82634b:	movabs $0x7ff0000000000000,%rsi
  826355:	cmp    %rsi,%rdx
  826358:	sete   %r8b
  82635c:	or     %dil,%r8b
  82635f:	jne    826382 <gpui_gpu::renderer::coverage::axis+0xa32>
  826361:	mov    %rdx,%rdi
  826364:	and    %rbx,%rdi
  826367:	je     826373 <gpui_gpu::renderer::coverage::axis+0xa23>
  826369:	cmp    %rdi,%rdx
  82636c:	jne    82637a <gpui_gpu::renderer::coverage::axis+0xa2a>
  82636e:	inc    %rdx
  826371:	jmp    82637d <gpui_gpu::renderer::coverage::axis+0xa2d>
  826373:	mov    $0x1,%edx
  826378:	jmp    82637d <gpui_gpu::renderer::coverage::axis+0xa2d>
  82637a:	dec    %rdx
  82637d:	movq   %rdx,%xmm12
  826382:	movq   %xmm0,%rdx
  826387:	and    %rbx,%rdx
  82638a:	cmp    %r14,%rdx
  82638d:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  82638f:	ucomisd %xmm12,%xmm0
  826394:	ja     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826396:	xorpd  %xmm1,%xmm1
  82639a:	ucomisd %xmm1,%xmm0
  82639e:	jne    8263b1 <gpui_gpu::renderer::coverage::axis+0xa61>
  8263a0:	jp     8263b1 <gpui_gpu::renderer::coverage::axis+0xa61>
  8263a2:	movq   %xmm12,%rdx
  8263a7:	and    %rbx,%rdx
  8263aa:	cmp    %rsi,%rdx
  8263ad:	jl     8263cd <gpui_gpu::renderer::coverage::axis+0xa7d>
  8263af:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8263b1:	dec    %rdx
  8263b4:	movq   %xmm12,%rsi
  8263b9:	and    %rbx,%rsi
  8263bc:	cmp    %r14,%rsi
  8263bf:	setg   %sil
  8263c3:	cmp    %rcx,%rdx
  8263c6:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8263c8:	test   %sil,%sil
  8263cb:	jne    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8263cd:	ucomisd %xmm1,%xmm12
  8263d2:	jne    8263da <gpui_gpu::renderer::coverage::axis+0xa8a>
  8263d4:	jnp    825ab1 <gpui_gpu::renderer::coverage::axis+0x161>
  8263da:	movq   %xmm12,%rdx
  8263df:	and    %rbx,%rdx
  8263e2:	dec    %rdx
  8263e5:	movapd %xmm12,%xmm1
  8263ea:	cmp    %rcx,%rdx
  8263ed:	jae    825ab6 <gpui_gpu::renderer::coverage::axis+0x166>
  8263f3:	add    $0x150,%rsp
  8263fa:	pop    %rbx
  8263fb:	pop    %r12
  8263fd:	pop    %r13
  8263ff:	pop    %r14
  826401:	pop    %r15
  826403:	ret
  826404:	xor    %eax,%eax
  826406:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
