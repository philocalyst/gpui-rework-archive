
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816480 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  816480:	push   %rbx
  816481:	test   %rdi,%rdi
  816484:	je     8164e7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  816486:	mov    %rdi,%rbx
  816489:	mov    (%rdi),%rsi
  81648c:	test   %rsi,%rsi
  81648f:	je     8164a4 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816491:	mov    0x8(%rbx),%rdi
  816495:	shl    $0x3,%rsi
  816499:	mov    $0x8,%edx
  81649e:	call   *0x66ae34(%rip)        # e812d8 <_DYNAMIC+0x248>
  8164a4:	mov    0x20(%rbx),%rsi
  8164a8:	test   %rsi,%rsi
  8164ab:	je     8164d3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8164ad:	mov    %rsi,%rax
  8164b0:	shl    $0x4,%rax
  8164b4:	add    %rax,%rsi
  8164b7:	add    $0x21,%rsi
  8164bb:	je     8164d3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8164bd:	mov    0x18(%rbx),%rdi
  8164c1:	sub    %rax,%rdi
  8164c4:	add    $0xfffffffffffffff0,%rdi
  8164c8:	mov    $0x10,%edx
  8164cd:	call   *0x66ae05(%rip)        # e812d8 <_DYNAMIC+0x248>
  8164d3:	mov    $0x80,%esi
  8164d8:	mov    $0x8,%edx
  8164dd:	mov    %rbx,%rdi
  8164e0:	pop    %rbx
  8164e1:	jmp    *0x66adf1(%rip)        # e812d8 <_DYNAMIC+0x248>
  8164e7:	pop    %rbx
  8164e8:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816af0 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816af0:	push   %rbx
  816af1:	cmpb   $0x3,0x19c(%rdi)
  816af8:	jne    816b27 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816afa:	movzbl 0x28(%rdi),%eax
  816afe:	cmp    $0x4,%eax
  816b01:	je     816b15 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816b03:	cmp    $0x3,%eax
  816b06:	jne    816b27 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816b08:	add    $0x168,%rdi
  816b0f:	pop    %rbx
  816b10:	jmp    816a60 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816b15:	mov    %rdi,%rbx
  816b18:	add    $0x30,%rdi
  816b1c:	call   816b40 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816b21:	movw   $0x0,0x29(%rbx)
  816b27:	pop    %rbx
  816b28:	ret
  816b29:	movw   $0x0,0x29(%rbx)
  816b2f:	mov    %rax,%rdi
  816b32:	call   e2dda0 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816b40 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816b40:	push   %r15
  816b42:	push   %r14
  816b44:	push   %r12
  816b46:	push   %rbx
  816b47:	push   %rax
  816b48:	mov    %rdi,%rbx
  816b4b:	movzbl 0x9e(%rdi),%eax
  816b52:	test   %eax,%eax
  816b54:	je     816c1b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816b5a:	cmp    $0x3,%eax
  816b5d:	jne    816c51 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816b63:	mov    0x20(%rbx),%r15
  816b67:	mov    0x28(%rbx),%r12
  816b6b:	mov    (%r12),%rax
  816b6f:	test   %rax,%rax
  816b72:	je     816b79 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816b74:	mov    %r15,%rdi
  816b77:	call   *%rax
  816b79:	mov    0x8(%r12),%rsi
  816b7e:	test   %rsi,%rsi
  816b81:	je     816b91 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816b83:	mov    0x10(%r12),%rdx
  816b88:	mov    %r15,%rdi
  816b8b:	call   *0x66a747(%rip)        # e812d8 <_DYNAMIC+0x248>
  816b91:	mov    0x68(%rbx),%rax
  816b95:	lock decq (%rax)
  816b99:	jne    816ba5 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816b9b:	lea    0x68(%rbx),%rdi
  816b9f:	call   *0x66a953(%rip)        # e814f8 <_DYNAMIC+0x468>
  816ba5:	movb   $0x0,0x98(%rbx)
  816bac:	mov    0x60(%rbx),%rax
  816bb0:	lock decq (%rax)
  816bb4:	jne    816bbf <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816bb6:	lea    0x60(%rbx),%rdi
  816bba:	call   812cc0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816bbf:	movw   $0x0,0x99(%rbx)
  816bc8:	mov    0x40(%rbx),%rax
  816bcc:	lock decq (%rax)
  816bd0:	jne    816bdc <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816bd2:	lea    0x40(%rbx),%rdi
  816bd6:	call   *0x66a924(%rip)        # e81500 <_DYNAMIC+0x470>
  816bdc:	movb   $0x0,0x9b(%rbx)
  816be3:	mov    0x38(%rbx),%rax
  816be7:	lock decq (%rax)
  816beb:	jne    816bf7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816bed:	lea    0x38(%rbx),%rdi
  816bf1:	call   *0x66a911(%rip)        # e81508 <_DYNAMIC+0x478>
  816bf7:	movb   $0x0,0x9c(%rbx)
  816bfe:	mov    0x30(%rbx),%rax
  816c02:	lock decq (%rax)
  816c06:	jne    816c12 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816c08:	lea    0x30(%rbx),%rdi
  816c0c:	call   *0x66a8fe(%rip)        # e81510 <_DYNAMIC+0x480>
  816c12:	movb   $0x0,0x9d(%rbx)
  816c19:	jmp    816c51 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816c1b:	mov    0x70(%rbx),%rax
  816c1f:	lock decq (%rax)
  816c23:	jne    816c2f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816c25:	lea    0x70(%rbx),%rdi
  816c29:	call   *0x66a8e1(%rip)        # e81510 <_DYNAMIC+0x480>
  816c2f:	mov    0x78(%rbx),%rax
  816c33:	lock decq (%rax)
  816c37:	jne    816c51 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816c39:	add    $0x78,%rbx
  816c3d:	mov    %rbx,%rdi
  816c40:	add    $0x8,%rsp
  816c44:	pop    %rbx
  816c45:	pop    %r12
  816c47:	pop    %r14
  816c49:	pop    %r15
  816c4b:	jmp    *0x66a8b7(%rip)        # e81508 <_DYNAMIC+0x478>
  816c51:	add    $0x8,%rsp
  816c55:	pop    %rbx
  816c56:	pop    %r12
  816c58:	pop    %r14
  816c5a:	pop    %r15
  816c5c:	ret
  816c5d:	mov    %rax,%r14
  816c60:	movb   $0x0,0x9d(%rbx)
  816c67:	mov    %r14,%rdi
  816c6a:	call   e2dda0 <_Unwind_Resume@plt>
  816c6f:	mov    %rax,%r14
  816c72:	jmp    816d2c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816c77:	mov    %rax,%r14
  816c7a:	jmp    816d11 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816c7f:	mov    %rax,%r14
  816c82:	jmp    816cf4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816c84:	mov    %rax,%r14
  816c87:	jmp    816cda <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816c89:	mov    %rax,%r14
  816c8c:	mov    0x78(%rbx),%rax
  816c90:	lock decq (%rax)
  816c94:	jne    816ca3 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816c96:	add    $0x78,%rbx
  816c9a:	mov    %rbx,%rdi
  816c9d:	call   *0x66a865(%rip)        # e81508 <_DYNAMIC+0x478>
  816ca3:	mov    %r14,%rdi
  816ca6:	call   e2dda0 <_Unwind_Resume@plt>
  816cab:	mov    %rax,%r14
  816cae:	mov    0x8(%r12),%rsi
  816cb3:	test   %rsi,%rsi
  816cb6:	je     816cc6 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816cb8:	mov    0x10(%r12),%rdx
  816cbd:	mov    %r15,%rdi
  816cc0:	call   *0x66a612(%rip)        # e812d8 <_DYNAMIC+0x248>
  816cc6:	mov    0x68(%rbx),%rax
  816cca:	lock decq (%rax)
  816cce:	jne    816cda <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816cd0:	lea    0x68(%rbx),%rdi
  816cd4:	call   *0x66a81e(%rip)        # e814f8 <_DYNAMIC+0x468>
  816cda:	movb   $0x0,0x98(%rbx)
  816ce1:	mov    0x60(%rbx),%rax
  816ce5:	lock decq (%rax)
  816ce9:	jne    816cf4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816ceb:	lea    0x60(%rbx),%rdi
  816cef:	call   812cc0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816cf4:	movw   $0x0,0x99(%rbx)
  816cfd:	mov    0x40(%rbx),%rax
  816d01:	lock decq (%rax)
  816d05:	jne    816d11 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816d07:	lea    0x40(%rbx),%rdi
  816d0b:	call   *0x66a7ef(%rip)        # e81500 <_DYNAMIC+0x470>
  816d11:	movb   $0x0,0x9b(%rbx)
  816d18:	mov    0x38(%rbx),%rax
  816d1c:	lock decq (%rax)
  816d20:	jne    816d2c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816d22:	lea    0x38(%rbx),%rdi
  816d26:	call   *0x66a7dc(%rip)        # e81508 <_DYNAMIC+0x478>
  816d2c:	movb   $0x0,0x9c(%rbx)
  816d33:	mov    0x30(%rbx),%rax
  816d37:	lock decq (%rax)
  816d3b:	jne    816d47 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816d3d:	lea    0x30(%rbx),%rdi
  816d41:	call   *0x66a7c9(%rip)        # e81510 <_DYNAMIC+0x480>
  816d47:	movb   $0x0,0x9d(%rbx)
  816d4e:	mov    %r14,%rdi
  816d51:	call   e2dda0 <_Unwind_Resume@plt>
  816d56:	call   *0x66a584(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816d60 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816d60:	push   %rbx
  816d61:	movzbl 0x20(%rdi),%eax
  816d65:	cmp    $0x3,%eax
  816d68:	je     816d83 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816d6a:	cmp    $0x4,%eax
  816d6d:	jne    816d90 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816d6f:	mov    %rdi,%rbx
  816d72:	add    $0x28,%rdi
  816d76:	call   816b40 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816d7b:	movw   $0x0,0x21(%rbx)
  816d81:	pop    %rbx
  816d82:	ret
  816d83:	add    $0x160,%rdi
  816d8a:	pop    %rbx
  816d8b:	jmp    816a60 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816d90:	pop    %rbx
  816d91:	ret
  816d92:	movw   $0x0,0x21(%rbx)
  816d98:	mov    %rax,%rdi
  816d9b:	call   e2dda0 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817280 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  817280:	push   %r14
  817282:	push   %rbx
  817283:	push   %rax
  817284:	mov    %rdi,%rbx
  817287:	mov    (%rdi),%rax
  81728a:	lock decq (%rax)
  81728e:	jne    817299 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817290:	mov    %rbx,%rdi
  817293:	call   *0x66a277(%rip)        # e81510 <_DYNAMIC+0x480>
  817299:	mov    0x8(%rbx),%rax
  81729d:	lock decq (%rax)
  8172a1:	jne    8172ad <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  8172a3:	lea    0x8(%rbx),%rdi
  8172a7:	call   *0x66a25b(%rip)        # e81508 <_DYNAMIC+0x478>
  8172ad:	mov    0x10(%rbx),%rax
  8172b1:	lock decq (%rax)
  8172b5:	jne    8172c0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  8172b7:	lea    0x10(%rbx),%rdi
  8172bb:	call   812cc0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  8172c0:	mov    0x18(%rbx),%rax
  8172c4:	lock decq (%rax)
  8172c8:	jne    8172de <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  8172ca:	add    $0x18,%rbx
  8172ce:	mov    %rbx,%rdi
  8172d1:	add    $0x8,%rsp
  8172d5:	pop    %rbx
  8172d6:	pop    %r14
  8172d8:	jmp    *0x66a21a(%rip)        # e814f8 <_DYNAMIC+0x468>
  8172de:	add    $0x8,%rsp
  8172e2:	pop    %rbx
  8172e3:	pop    %r14
  8172e5:	ret
  8172e6:	mov    %rax,%r14
  8172e9:	jmp    81731a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  8172eb:	mov    %rax,%r14
  8172ee:	jmp    817307 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8172f0:	mov    %rax,%r14
  8172f3:	mov    0x8(%rbx),%rax
  8172f7:	lock decq (%rax)
  8172fb:	jne    817307 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8172fd:	lea    0x8(%rbx),%rdi
  817301:	call   *0x66a201(%rip)        # e81508 <_DYNAMIC+0x478>
  817307:	mov    0x10(%rbx),%rax
  81730b:	lock decq (%rax)
  81730f:	jne    81731a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  817311:	lea    0x10(%rbx),%rdi
  817315:	call   812cc0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81731a:	mov    0x18(%rbx),%rax
  81731e:	lock decq (%rax)
  817322:	jne    817331 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  817324:	add    $0x18,%rbx
  817328:	mov    %rbx,%rdi
  81732b:	call   *0x66a1c7(%rip)        # e814f8 <_DYNAMIC+0x468>
  817331:	mov    %r14,%rdi
  817334:	call   e2dda0 <_Unwind_Resume@plt>
  817339:	call   *0x669fa1(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1253 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817340 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  817340:	push   %r14
  817342:	push   %rbx
  817343:	push   %rax
  817344:	mov    %rdi,%rbx
  817347:	mov    0x228(%rdi),%rax
  81734e:	lock decq (%rax)
  817352:	jne    817361 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  817354:	lea    0x228(%rbx),%rdi
  81735b:	call   *0x66a197(%rip)        # e814f8 <_DYNAMIC+0x468>
  817361:	mov    0x230(%rbx),%rax
  817368:	lock decq (%rax)
  81736c:	jne    81737b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  81736e:	lea    0x230(%rbx),%rdi
  817375:	call   *0x66a21d(%rip)        # e81598 <_DYNAMIC+0x508>
  81737b:	mov    0x238(%rbx),%rax
  817382:	lock decq (%rax)
  817386:	jne    817395 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  817388:	lea    0x238(%rbx),%rdi
  81738f:	call   *0x66a20b(%rip)        # e815a0 <_DYNAMIC+0x510>
  817395:	mov    0x258(%rbx),%rax
  81739c:	lock decq (%rax)
  8173a0:	jne    8173af <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  8173a2:	lea    0x258(%rbx),%rdi
  8173a9:	call   *0x66a1e9(%rip)        # e81598 <_DYNAMIC+0x508>
  8173af:	mov    0x260(%rbx),%rax
  8173b6:	lock decq (%rax)
  8173ba:	jne    8173c9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  8173bc:	lea    0x260(%rbx),%rdi
  8173c3:	call   *0x66a1d7(%rip)        # e815a0 <_DYNAMIC+0x510>
  8173c9:	mov    0x280(%rbx),%rax
  8173d0:	lock decq (%rax)
  8173d4:	jne    8173e3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  8173d6:	lea    0x280(%rbx),%rdi
  8173dd:	call   *0x66a1b5(%rip)        # e81598 <_DYNAMIC+0x508>
  8173e3:	mov    0x288(%rbx),%rax
  8173ea:	lock decq (%rax)
  8173ee:	jne    8173fd <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  8173f0:	lea    0x288(%rbx),%rdi
  8173f7:	call   *0x66a1a3(%rip)        # e815a0 <_DYNAMIC+0x510>
  8173fd:	mov    0x2a8(%rbx),%rax
  817404:	lock decq (%rax)
  817408:	jne    817417 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  81740a:	lea    0x2a8(%rbx),%rdi
  817411:	call   *0x66a181(%rip)        # e81598 <_DYNAMIC+0x508>
  817417:	mov    0x2b0(%rbx),%rax
  81741e:	lock decq (%rax)
  817422:	jne    817431 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  817424:	lea    0x2b0(%rbx),%rdi
  81742b:	call   *0x66a16f(%rip)        # e815a0 <_DYNAMIC+0x510>
  817431:	mov    0x2d0(%rbx),%rax
  817438:	lock decq (%rax)
  81743c:	jne    81744b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  81743e:	lea    0x2d0(%rbx),%rdi
  817445:	call   *0x66a14d(%rip)        # e81598 <_DYNAMIC+0x508>
  81744b:	mov    0x2d8(%rbx),%rax
  817452:	lock decq (%rax)
  817456:	jne    817465 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  817458:	lea    0x2d8(%rbx),%rdi
  81745f:	call   *0x66a13b(%rip)        # e815a0 <_DYNAMIC+0x510>
  817465:	lea    0x78(%rbx),%rdi
  817469:	call   817830 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81746e:	mov    0x328(%rbx),%r14
  817475:	test   %r14,%r14
  817478:	je     8174d7 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  81747a:	mov    (%r14),%rsi
  81747d:	test   %rsi,%rsi
  817480:	je     817495 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  817482:	mov    0x8(%r14),%rdi
  817486:	shl    $0x3,%rsi
  81748a:	mov    $0x8,%edx
  81748f:	call   *0x669e43(%rip)        # e812d8 <_DYNAMIC+0x248>
  817495:	mov    0x20(%r14),%rsi
  817499:	test   %rsi,%rsi
  81749c:	je     8174c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81749e:	mov    %rsi,%rax
  8174a1:	shl    $0x4,%rax
  8174a5:	add    %rax,%rsi
  8174a8:	add    $0x21,%rsi
  8174ac:	je     8174c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  8174ae:	mov    0x18(%r14),%rdi
  8174b2:	sub    %rax,%rdi
  8174b5:	add    $0xfffffffffffffff0,%rdi
  8174b9:	mov    $0x10,%edx
  8174be:	call   *0x669e14(%rip)        # e812d8 <_DYNAMIC+0x248>
  8174c4:	mov    $0x80,%esi
  8174c9:	mov    $0x8,%edx
  8174ce:	mov    %r14,%rdi
  8174d1:	call   *0x669e01(%rip)        # e812d8 <_DYNAMIC+0x248>
  8174d7:	mov    (%rbx),%rsi
  8174da:	test   %rsi,%rsi
  8174dd:	je     8174f2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  8174df:	mov    0x8(%rbx),%rdi
  8174e3:	shl    $0x4,%rsi
  8174e7:	mov    $0x4,%edx
  8174ec:	call   *0x669de6(%rip)        # e812d8 <_DYNAMIC+0x248>
  8174f2:	mov    0x18(%rbx),%rsi
  8174f6:	test   %rsi,%rsi
  8174f9:	je     81750e <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  8174fb:	mov    0x20(%rbx),%rdi
  8174ff:	shl    $0x3,%rsi
  817503:	mov    $0x4,%edx
  817508:	call   *0x669dca(%rip)        # e812d8 <_DYNAMIC+0x248>
  81750e:	mov    0x30(%rbx),%rsi
  817512:	test   %rsi,%rsi
  817515:	je     81752a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817517:	mov    0x38(%rbx),%rdi
  81751b:	shl    $0x2,%rsi
  81751f:	mov    $0x4,%edx
  817524:	call   *0x669dae(%rip)        # e812d8 <_DYNAMIC+0x248>
  81752a:	mov    0x48(%rbx),%rsi
  81752e:	test   %rsi,%rsi
  817531:	je     817546 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  817533:	mov    0x50(%rbx),%rdi
  817537:	shl    $0x2,%rsi
  81753b:	mov    $0x4,%edx
  817540:	call   *0x669d92(%rip)        # e812d8 <_DYNAMIC+0x248>
  817546:	mov    0x60(%rbx),%rsi
  81754a:	test   %rsi,%rsi
  81754d:	je     817562 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  81754f:	mov    0x68(%rbx),%rdi
  817553:	shl    $0x5,%rsi
  817557:	mov    $0x4,%edx
  81755c:	call   *0x669d76(%rip)        # e812d8 <_DYNAMIC+0x248>
  817562:	mov    0x300(%rbx),%rsi
  817569:	test   %rsi,%rsi
  81756c:	je     81759c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  81756e:	lea    (%rsi,%rsi,8),%rax
  817572:	lea    0x33(,%rax,4),%rax
  81757a:	and    $0xfffffffffffffff0,%rax
  81757e:	add    %rax,%rsi
  817581:	add    $0x11,%rsi
  817585:	je     81759c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  817587:	mov    0x2f8(%rbx),%rdi
  81758e:	sub    %rax,%rdi
  817591:	mov    $0x10,%edx
  817596:	call   *0x669d3c(%rip)        # e812d8 <_DYNAMIC+0x248>
  81759c:	mov    0x330(%rbx),%rax
  8175a3:	test   %rax,%rax
  8175a6:	je     8175c5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  8175a8:	lock decq (%rax)
  8175ac:	jne    8175c5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  8175ae:	add    $0x330,%rbx
  8175b5:	mov    %rbx,%rdi
  8175b8:	add    $0x8,%rsp
  8175bc:	pop    %rbx
  8175bd:	pop    %r14
  8175bf:	jmp    *0x669fe3(%rip)        # e815a8 <_DYNAMIC+0x518>
  8175c5:	add    $0x8,%rsp
  8175c9:	pop    %rbx
  8175ca:	pop    %r14
  8175cc:	ret
  8175cd:	mov    %rax,%r14
  8175d0:	jmp    8176fc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8175d5:	mov    %rax,%r14
  8175d8:	mov    0x2d8(%rbx),%rax
  8175df:	lock decq (%rax)
  8175e3:	jne    8176fc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8175e9:	lea    0x2d8(%rbx),%rdi
  8175f0:	call   *0x669faa(%rip)        # e815a0 <_DYNAMIC+0x510>
  8175f6:	jmp    8176fc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8175fb:	call   *0x669cdf(%rip)        # e812e0 <_DYNAMIC+0x250>
  817601:	mov    %rax,%r14
  817604:	jmp    8176f0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  817609:	mov    %rax,%r14
  81760c:	mov    0x2b0(%rbx),%rax
  817613:	lock decq (%rax)
  817617:	jne    8176f0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81761d:	lea    0x2b0(%rbx),%rdi
  817624:	call   *0x669f76(%rip)        # e815a0 <_DYNAMIC+0x510>
  81762a:	jmp    8176f0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81762f:	call   *0x669cab(%rip)        # e812e0 <_DYNAMIC+0x250>
  817635:	mov    %rax,%r14
  817638:	jmp    8176e4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  81763d:	mov    %rax,%r14
  817640:	mov    0x288(%rbx),%rax
  817647:	lock decq (%rax)
  81764b:	jne    8176e4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  817651:	lea    0x288(%rbx),%rdi
  817658:	call   *0x669f42(%rip)        # e815a0 <_DYNAMIC+0x510>
  81765e:	jmp    8176e4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  817663:	call   *0x669c77(%rip)        # e812e0 <_DYNAMIC+0x250>
  817669:	mov    %rax,%r14
  81766c:	jmp    8176d8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81766e:	mov    %rax,%r14
  817671:	mov    0x260(%rbx),%rax
  817678:	lock decq (%rax)
  81767c:	jne    8176d8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81767e:	lea    0x260(%rbx),%rdi
  817685:	call   *0x669f15(%rip)        # e815a0 <_DYNAMIC+0x510>
  81768b:	jmp    8176d8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81768d:	call   *0x669c4d(%rip)        # e812e0 <_DYNAMIC+0x250>
  817693:	mov    %rax,%r14
  817696:	jmp    8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817698:	mov    %rax,%r14
  81769b:	mov    0x238(%rbx),%rax
  8176a2:	lock decq (%rax)
  8176a6:	jne    8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  8176a8:	lea    0x238(%rbx),%rdi
  8176af:	call   *0x669eeb(%rip)        # e815a0 <_DYNAMIC+0x510>
  8176b5:	jmp    8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  8176b7:	call   *0x669c23(%rip)        # e812e0 <_DYNAMIC+0x250>
  8176bd:	mov    %rax,%r14
  8176c0:	lea    0x230(%rbx),%rdi
  8176c7:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176cc:	lea    0x258(%rbx),%rdi
  8176d3:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176d8:	lea    0x280(%rbx),%rdi
  8176df:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176e4:	lea    0x2a8(%rbx),%rdi
  8176eb:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176f0:	lea    0x2d0(%rbx),%rdi
  8176f7:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176fc:	lea    0x78(%rbx),%rdi
  817700:	call   817830 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  817705:	mov    0x328(%rbx),%rdi
  81770c:	call   816480 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  817711:	mov    (%rbx),%rsi
  817714:	test   %rsi,%rsi
  817717:	jne    817792 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  817719:	mov    0x18(%rbx),%rsi
  81771d:	test   %rsi,%rsi
  817720:	jne    8177b2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  817726:	mov    0x30(%rbx),%rsi
  81772a:	test   %rsi,%rsi
  81772d:	jne    8177d2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  817733:	mov    0x48(%rbx),%rsi
  817737:	test   %rsi,%rsi
  81773a:	jne    8177f2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  817740:	mov    0x60(%rbx),%rsi
  817744:	test   %rsi,%rsi
  817747:	je     81775c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817749:	mov    0x68(%rbx),%rdi
  81774d:	shl    $0x5,%rsi
  817751:	mov    $0x4,%edx
  817756:	call   *0x669b7c(%rip)        # e812d8 <_DYNAMIC+0x248>
  81775c:	lea    0x2f8(%rbx),%rdi
  817763:	call   819c40 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  817768:	mov    0x330(%rbx),%rax
  81776f:	test   %rax,%rax
  817772:	je     81778a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  817774:	lock decq (%rax)
  817778:	jne    81778a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  81777a:	add    $0x330,%rbx
  817781:	mov    %rbx,%rdi
  817784:	call   *0x669e1e(%rip)        # e815a8 <_DYNAMIC+0x518>
  81778a:	mov    %r14,%rdi
  81778d:	call   e2dda0 <_Unwind_Resume@plt>
  817792:	mov    0x8(%rbx),%rdi
  817796:	shl    $0x4,%rsi
  81779a:	mov    $0x4,%edx
  81779f:	call   *0x669b33(%rip)        # e812d8 <_DYNAMIC+0x248>
  8177a5:	mov    0x18(%rbx),%rsi
  8177a9:	test   %rsi,%rsi
  8177ac:	je     817726 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  8177b2:	mov    0x20(%rbx),%rdi
  8177b6:	shl    $0x3,%rsi
  8177ba:	mov    $0x4,%edx
  8177bf:	call   *0x669b13(%rip)        # e812d8 <_DYNAMIC+0x248>
  8177c5:	mov    0x30(%rbx),%rsi
  8177c9:	test   %rsi,%rsi
  8177cc:	je     817733 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  8177d2:	mov    0x38(%rbx),%rdi
  8177d6:	shl    $0x2,%rsi
  8177da:	mov    $0x4,%edx
  8177df:	call   *0x669af3(%rip)        # e812d8 <_DYNAMIC+0x248>
  8177e5:	mov    0x48(%rbx),%rsi
  8177e9:	test   %rsi,%rsi
  8177ec:	je     817740 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  8177f2:	mov    0x50(%rbx),%rdi
  8177f6:	shl    $0x2,%rsi
  8177fa:	mov    $0x4,%edx
  8177ff:	call   *0x669ad3(%rip)        # e812d8 <_DYNAMIC+0x248>
  817805:	mov    0x60(%rbx),%rsi
  817809:	test   %rsi,%rsi
  81780c:	jne    817749 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  817812:	jmp    81775c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817817:	call   *0x669ac3(%rip)        # e812e0 <_DYNAMIC+0x250>
  81781d:	mov    %rax,%r14
  817820:	jmp    817705 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817830 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  817830:	push   %r14
  817832:	push   %rbx
  817833:	push   %rax
  817834:	mov    %rdi,%rbx
  817837:	mov    (%rdi),%rax
  81783a:	lock decq (%rax)
  81783e:	jne    817849 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  817840:	mov    %rbx,%rdi
  817843:	call   *0x669d2f(%rip)        # e81578 <_DYNAMIC+0x4e8>
  817849:	mov    0x50(%rbx),%rax
  81784d:	lock decq (%rax)
  817851:	jne    81785d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  817853:	lea    0x50(%rbx),%rdi
  817857:	call   *0x669d13(%rip)        # e81570 <_DYNAMIC+0x4e0>
  81785d:	mov    0x58(%rbx),%rax
  817861:	lock decq (%rax)
  817865:	jne    817871 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  817867:	lea    0x58(%rbx),%rdi
  81786b:	call   *0x669d07(%rip)        # e81578 <_DYNAMIC+0x4e8>
  817871:	mov    0xb0(%rbx),%rsi
  817878:	test   %rsi,%rsi
  81787b:	je     8178ad <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81787d:	mov    %rsi,%rax
  817880:	shl    $0x5,%rax
  817884:	add    %rax,%rsi
  817887:	add    $0x31,%rsi
  81788b:	je     8178ad <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81788d:	mov    0xa8(%rbx),%rdi
  817894:	sub    %rax,%rdi
  817897:	add    $0xffffffffffffffe0,%rdi
  81789b:	mov    $0x10,%edx
  8178a0:	add    $0x8,%rsp
  8178a4:	pop    %rbx
  8178a5:	pop    %r14
  8178a7:	jmp    *0x669a2b(%rip)        # e812d8 <_DYNAMIC+0x248>
  8178ad:	add    $0x8,%rsp
  8178b1:	pop    %rbx
  8178b2:	pop    %r14
  8178b4:	ret
  8178b5:	mov    %rax,%r14
  8178b8:	jmp    8178e5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  8178ba:	mov    %rax,%r14
  8178bd:	mov    0x58(%rbx),%rax
  8178c1:	lock decq (%rax)
  8178c5:	jne    8178e5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  8178c7:	lea    0x58(%rbx),%rdi
  8178cb:	call   *0x669ca7(%rip)        # e81578 <_DYNAMIC+0x4e8>
  8178d1:	jmp    8178e5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  8178d3:	call   *0x669a07(%rip)        # e812e0 <_DYNAMIC+0x250>
  8178d9:	mov    %rax,%r14
  8178dc:	lea    0x50(%rbx),%rdi
  8178e0:	call   817a30 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  8178e5:	add    $0xa8,%rbx
  8178ec:	mov    %rbx,%rdi
  8178ef:	call   819c80 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  8178f4:	mov    %r14,%rdi
  8178f7:	call   e2dda0 <_Unwind_Resume@plt>
  8178fc:	call   *0x6699de(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817910 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817910:	cmpl   $0x1,(%rdi)
  817913:	ja     81792d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817915:	mov    0x8(%rdi),%rsi
  817919:	test   %rsi,%rsi
  81791c:	je     81792d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  81791e:	mov    0x10(%rdi),%rdi
  817922:	mov    $0x1,%edx
  817927:	jmp    *0x6699ab(%rip)        # e812d8 <_DYNAMIC+0x248>
  81792d:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  817930:	push   %r14
  817932:	push   %rbx
  817933:	push   %rax
  817934:	mov    %rdi,%rbx
  817937:	mov    (%rdi),%rax
  81793a:	lock decq (%rax)
  81793e:	jne    817949 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  817940:	mov    %rbx,%rdi
  817943:	call   *0x669c4f(%rip)        # e81598 <_DYNAMIC+0x508>
  817949:	mov    0x8(%rbx),%rax
  81794d:	lock decq (%rax)
  817951:	jne    817967 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  817953:	add    $0x8,%rbx
  817957:	mov    %rbx,%rdi
  81795a:	add    $0x8,%rsp
  81795e:	pop    %rbx
  81795f:	pop    %r14
  817961:	jmp    *0x669c39(%rip)        # e815a0 <_DYNAMIC+0x510>
  817967:	add    $0x8,%rsp
  81796b:	pop    %rbx
  81796c:	pop    %r14
  81796e:	ret
  81796f:	mov    %rax,%r14
  817972:	mov    0x8(%rbx),%rax
  817976:	lock decq (%rax)
  81797a:	jne    817989 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81797c:	add    $0x8,%rbx
  817980:	mov    %rbx,%rdi
  817983:	call   *0x669c17(%rip)        # e815a0 <_DYNAMIC+0x510>
  817989:	mov    %r14,%rdi
  81798c:	call   e2dda0 <_Unwind_Resume@plt>
  817991:	call   *0x669949(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000818300 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  818300:	sub    $0x18,%rsp
  818304:	mov    %rsi,%rax
  818307:	mov    (%rdi),%ecx
  818309:	lea    -0x747488(%rip),%rdx        # d0e88 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  818310:	movslq (%rdx,%rcx,4),%rcx
  818314:	add    %rdx,%rcx
  818317:	jmp    *%rcx
  818319:	add    $0x8,%rdi
  81831d:	mov    %rdi,0x10(%rsp)
  818322:	lea    -0x743b9d(%rip),%rsi        # d478c <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44bc>
  818329:	jmp    8183b8 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  81832e:	lea    -0x743b80(%rip),%rsi        # d47b5 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44e5>
  818335:	mov    $0x13,%edx
  81833a:	mov    %rax,%rdi
  81833d:	add    $0x18,%rsp
  818341:	jmp    *0x669081(%rip)        # e813c8 <_DYNAMIC+0x338>
  818347:	add    $0x4,%rdi
  81834b:	mov    %rdi,0x10(%rsp)
  818350:	lea    -0x743bbf(%rip),%rsi        # d4798 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44c8>
  818357:	lea    0x61734a(%rip),%r8        # e2f6a8 <__frame_dummy_init_array_entry+0x8c8>
  81835e:	lea    0x10(%rsp),%rcx
  818363:	mov    $0x11,%edx
  818368:	mov    %rax,%rdi
  81836b:	call   *0x66905f(%rip)        # e813d0 <_DYNAMIC+0x340>
  818371:	add    $0x18,%rsp
  818375:	ret
  818376:	lea    -0x743bd4(%rip),%rsi        # d47a9 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44d9>
  81837d:	mov    $0xc,%edx
  818382:	mov    %rax,%rdi
  818385:	add    $0x18,%rsp
  818389:	jmp    *0x669039(%rip)        # e813c8 <_DYNAMIC+0x338>
  81838f:	lea    -0x743bb8(%rip),%rsi        # d47de <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x450e>
  818396:	mov    $0x9,%edx
  81839b:	mov    %rax,%rdi
  81839e:	add    $0x18,%rsp
  8183a2:	jmp    *0x669020(%rip)        # e813c8 <_DYNAMIC+0x338>
  8183a8:	add    $0x8,%rdi
  8183ac:	mov    %rdi,0x10(%rsp)
  8183b1:	lea    -0x743c26(%rip),%rsi        # d4792 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44c2>
  8183b8:	lea    0x6172c9(%rip),%r8        # e2f688 <__frame_dummy_init_array_entry+0x8a8>
  8183bf:	lea    0x10(%rsp),%rcx
  8183c4:	mov    $0x6,%edx
  8183c9:	mov    %rax,%rdi
  8183cc:	call   *0x668ffe(%rip)        # e813d0 <_DYNAMIC+0x340>
  8183d2:	add    $0x18,%rsp
  8183d6:	ret
  8183d7:	add    $0x8,%rdi
  8183db:	mov    %rdi,0x10(%rsp)
  8183e0:	lea    0x6172e1(%rip),%rcx        # e2f6c8 <__frame_dummy_init_array_entry+0x8e8>
  8183e7:	mov    %rcx,(%rsp)
  8183eb:	lea    -0x743c2a(%rip),%rsi        # d47c8 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44f8>
  8183f2:	lea    -0x76958d(%rip),%rcx        # aee6c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  8183f9:	lea    0x10(%rsp),%r9
  8183fe:	mov    $0x9,%edx
  818403:	mov    $0x4,%r8d
  818409:	mov    %rax,%rdi
  81840c:	call   *0x6691a6(%rip)        # e815b8 <_DYNAMIC+0x528>
  818412:	add    $0x18,%rsp
  818416:	ret
  818417:	lea    -0x743c4d(%rip),%rsi        # d47d1 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4501>
  81841e:	mov    $0xd,%edx
  818423:	mov    %rax,%rdi
  818426:	add    $0x18,%rsp
  81842a:	jmp    *0x668f98(%rip)        # e813c8 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819c80 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819c80:	mov    0x8(%rdi),%rsi
  819c84:	test   %rsi,%rsi
  819c87:	je     819cae <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819c89:	mov    %rsi,%rax
  819c8c:	shl    $0x5,%rax
  819c90:	add    %rax,%rsi
  819c93:	add    $0x31,%rsi
  819c97:	je     819cae <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819c99:	mov    (%rdi),%rdi
  819c9c:	sub    %rax,%rdi
  819c9f:	add    $0xffffffffffffffe0,%rdi
  819ca3:	mov    $0x10,%edx
  819ca8:	jmp    *0x66762a(%rip)        # e812d8 <_DYNAMIC+0x248>
  819cae:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819cb0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819cb0:	mov    0x8(%rdi),%rsi
  819cb4:	test   %rsi,%rsi
  819cb7:	je     819cde <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819cb9:	mov    %rsi,%rax
  819cbc:	shl    $0x4,%rax
  819cc0:	add    %rax,%rsi
  819cc3:	add    $0x21,%rsi
  819cc7:	je     819cde <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819cc9:	mov    (%rdi),%rdi
  819ccc:	sub    %rax,%rdi
  819ccf:	add    $0xfffffffffffffff0,%rdi
  819cd3:	mov    $0x10,%edx
  819cd8:	jmp    *0x6675fa(%rip)        # e812d8 <_DYNAMIC+0x248>
  819cde:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b570 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b570:	push   %r14
  81b572:	push   %rbx
  81b573:	sub    $0x38,%rsp
  81b577:	mov    %rdi,%rbx
  81b57a:	cmpq   $0x0,(%rsi)
  81b57e:	je     81b688 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b584:	movdqu (%rsi),%xmm0
  81b588:	movdqu 0x10(%rsi),%xmm1
  81b58d:	movdqu 0x20(%rsi),%xmm2
  81b592:	movdqa %xmm2,0x20(%rsp)
  81b598:	movdqa %xmm1,0x10(%rsp)
  81b59e:	movdqa %xmm0,(%rsp)
  81b5a3:	cmpq   $0x0,0x18(%rcx)
  81b5a8:	je     81b69c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b5ae:	lea    0x10(%rsp),%rsi
  81b5b3:	lea    0x20(%rcx),%rdi
  81b5b7:	mov    %rcx,%r14
  81b5ba:	call   8250e0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b5bf:	mov    %rax,%rsi
  81b5c2:	shr    $0x39,%rsi
  81b5c6:	mov    (%r14),%rcx
  81b5c9:	mov    0x8(%r14),%rdx
  81b5cd:	movd   %esi,%xmm0
  81b5d1:	punpcklbw %xmm0,%xmm0
  81b5d5:	pshuflw $0x0,%xmm0,%xmm0
  81b5da:	pshufd $0x44,%xmm0,%xmm0
  81b5df:	mov    0x10(%rsp),%rsi
  81b5e4:	movzwl 0x1c(%rsp),%edi
  81b5e9:	xor    %r8d,%r8d
  81b5ec:	mov    0x18(%rsp),%r9d
  81b5f1:	pcmpeqd %xmm1,%xmm1
  81b5f5:	and    %rdx,%rax
  81b5f8:	movdqu (%rcx,%rax,1),%xmm2
  81b5fd:	movdqa %xmm2,%xmm3
  81b601:	pcmpeqb %xmm0,%xmm3
  81b605:	pmovmskb %xmm3,%r10d
  81b60a:	test   %r10d,%r10d
  81b60d:	je     81b650 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b60f:	tzcnt  %r10d,%r14d
  81b614:	add    %rax,%r14
  81b617:	and    %rdx,%r14
  81b61a:	shl    $0x5,%r14
  81b61e:	mov    %rcx,%r11
  81b621:	sub    %r14,%r11
  81b624:	cmp    -0x20(%r11),%rsi
  81b628:	jne    81b637 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b62a:	cmp    -0x14(%r11),%di
  81b62f:	jne    81b637 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b631:	cmp    -0x18(%r11),%r9d
  81b635:	je     81b66b <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b637:	lea    -0x1(%r10),%r11d
  81b63b:	and    %r10w,%r11w
  81b63f:	mov    %r11d,%r10d
  81b642:	jne    81b60f <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b644:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b650:	pcmpeqb %xmm1,%xmm2
  81b654:	pmovmskb %xmm2,%r10d
  81b659:	test   %r10d,%r10d
  81b65c:	jne    81b69c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b65e:	add    %r8,%rax
  81b661:	add    $0x10,%rax
  81b665:	add    $0x10,%r8
  81b669:	jmp    81b5f5 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b66b:	mov    -0x4(%r11),%eax
  81b66f:	shl    $0x10,%eax
  81b672:	or     -0x8(%r11),%eax
  81b676:	mov    -0x10(%r11),%rcx
  81b67a:	mov    %rcx,(%rbx)
  81b67d:	mov    %eax,0x8(%rbx)
  81b680:	add    $0x38,%rsp
  81b684:	pop    %rbx
  81b685:	pop    %r14
  81b687:	ret
  81b688:	mov    0x8(%rdx),%eax
  81b68b:	mov    %eax,0x8(%rbx)
  81b68e:	mov    (%rdx),%rax
  81b691:	mov    %rax,(%rbx)
  81b694:	add    $0x38,%rsp
  81b698:	pop    %rbx
  81b699:	pop    %r14
  81b69b:	ret
  81b69c:	lea    -0x746ad9(%rip),%rdi        # d4bca <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b6a3:	lea    0x61449e(%rip),%rdx        # e2fb48 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x90>
  81b6aa:	mov    $0x16,%esi
  81b6af:	call   *0x665f7b(%rip)        # e81630 <_DYNAMIC+0x5a0>

FUNCTION <gpui_gpu::renderer::Changes>::replace::<1: usize> bytes=105 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>:
  81b6c0:	cmp    %rdx,%rcx
  81b6c3:	jae    81b711 <<gpui_gpu::renderer::Changes>::replace::<1>+0x51>
  81b6c5:	mov    %rcx,%rax
  81b6c8:	shl    $0x4,%rax
  81b6cc:	movdqu (%rsi,%rax,1),%xmm0
  81b6d1:	movdqu (%r8),%xmm1
  81b6d6:	pcmpeqb %xmm0,%xmm1
  81b6da:	pmovmskb %xmm1,%edx
  81b6de:	cmp    $0xffff,%edx
  81b6e4:	jne    81b6e7 <<gpui_gpu::renderer::Changes>::replace::<1>+0x27>
  81b6e6:	ret
  81b6e7:	add    %rax,%rsi
  81b6ea:	mov    (%rdi),%rax
  81b6ed:	mov    0x8(%rdi),%rdx
  81b6f1:	cmp    %rax,%rcx
  81b6f4:	cmovb  %rcx,%rax
  81b6f8:	inc    %rcx
  81b6fb:	cmp    %rdx,%rcx
  81b6fe:	cmovbe %rdx,%rcx
  81b702:	mov    %rax,(%rdi)
  81b705:	mov    %rcx,0x8(%rdi)
  81b709:	movups (%r8),%xmm0
  81b70d:	movups %xmm0,(%rsi)
  81b710:	ret
  81b711:	push   %rax
  81b712:	lea    0x1(%rcx),%rsi
  81b716:	lea    0x61439b(%rip),%rax        # e2fab8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793>
  81b71d:	mov    %rcx,%rdi
  81b720:	mov    %rax,%rcx
  81b723:	call   *0x665eaf(%rip)        # e815d8 <_DYNAMIC+0x548>

FUNCTION <gpui_gpu::renderer::Changes>::replace::<2: usize> bytes=192 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b730 <<gpui_gpu::renderer::Changes>::replace::<2>>:
  81b730:	mov    %rsi,%rax
  81b733:	lea    0x2(%rcx),%rsi
  81b737:	cmp    $0xfffffffffffffffd,%rcx
  81b73b:	ja     81b7dc <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b741:	cmp    %rdx,%rsi
  81b744:	ja     81b7dc <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b74a:	mov    %rcx,%r11
  81b74d:	shl    $0x4,%r11
  81b751:	lea    (%rax,%r11,1),%rdx
  81b755:	mov    (%rdi),%r10
  81b758:	mov    0x8(%rdi),%r9
  81b75c:	movdqu (%rax,%r11,1),%xmm0
  81b762:	movdqu (%r8),%xmm1
  81b767:	pcmpeqb %xmm0,%xmm1
  81b76b:	pmovmskb %xmm1,%eax
  81b76f:	cmp    $0xffff,%eax
  81b774:	je     81b798 <<gpui_gpu::renderer::Changes>::replace::<2>+0x68>
  81b776:	cmp    %r10,%rcx
  81b779:	cmovb  %rcx,%r10
  81b77d:	lea    0x1(%rcx),%rax
  81b781:	cmp    %r9,%rax
  81b784:	cmova  %rax,%r9
  81b788:	mov    %r10,(%rdi)
  81b78b:	mov    %r9,0x8(%rdi)
  81b78f:	movdqu (%r8),%xmm0
  81b794:	movdqu %xmm0,(%rdx)
  81b798:	movdqu 0x10(%rdx),%xmm0
  81b79d:	movdqu 0x10(%r8),%xmm1
  81b7a3:	pcmpeqb %xmm0,%xmm1
  81b7a7:	pmovmskb %xmm1,%eax
  81b7ab:	cmp    $0xffff,%eax
  81b7b0:	je     81b7db <<gpui_gpu::renderer::Changes>::replace::<2>+0xab>
  81b7b2:	add    $0x10,%rdx
  81b7b6:	add    $0x10,%r8
  81b7ba:	inc    %rcx
  81b7bd:	cmp    %r10,%rcx
  81b7c0:	cmovae %r10,%rcx
  81b7c4:	cmp    %r9,%rsi
  81b7c7:	cmova  %rsi,%r9
  81b7cb:	mov    %rcx,(%rdi)
  81b7ce:	mov    %r9,0x8(%rdi)
  81b7d2:	movdqu (%r8),%xmm0
  81b7d7:	movdqu %xmm0,(%rdx)
  81b7db:	ret
  81b7dc:	push   %rax
  81b7dd:	lea    0x6142d4(%rip),%rax        # e2fab8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793>
  81b7e4:	mov    %rcx,%rdi
  81b7e7:	mov    %rax,%rcx
  81b7ea:	call   *0x665de8(%rip)        # e815d8 <_DYNAMIC+0x548>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81bae0:	push   %r14
  81bae2:	push   %rbx
  81bae3:	push   %rax
  81bae4:	mov    %rdi,%rbx
  81bae7:	mov    (%rdi),%rax
  81baea:	lock decq (%rax)
  81baee:	jne    81baf9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81baf0:	mov    %rbx,%rdi
  81baf3:	call   *0x665a7f(%rip)        # e81578 <_DYNAMIC+0x4e8>
  81baf9:	mov    0x50(%rbx),%rax
  81bafd:	lock decq (%rax)
  81bb01:	jne    81bb0d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81bb03:	lea    0x50(%rbx),%rdi
  81bb07:	call   *0x665a63(%rip)        # e81570 <_DYNAMIC+0x4e0>
  81bb0d:	mov    0x58(%rbx),%rax
  81bb11:	lock decq (%rax)
  81bb15:	jne    81bb21 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81bb17:	lea    0x58(%rbx),%rdi
  81bb1b:	call   *0x665a57(%rip)        # e81578 <_DYNAMIC+0x4e8>
  81bb21:	mov    0xb0(%rbx),%rsi
  81bb28:	test   %rsi,%rsi
  81bb2b:	je     81bb5d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bb2d:	mov    %rsi,%rax
  81bb30:	shl    $0x5,%rax
  81bb34:	add    %rax,%rsi
  81bb37:	add    $0x31,%rsi
  81bb3b:	je     81bb5d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bb3d:	mov    0xa8(%rbx),%rdi
  81bb44:	sub    %rax,%rdi
  81bb47:	add    $0xffffffffffffffe0,%rdi
  81bb4b:	mov    $0x10,%edx
  81bb50:	add    $0x8,%rsp
  81bb54:	pop    %rbx
  81bb55:	pop    %r14
  81bb57:	jmp    *0x66577b(%rip)        # e812d8 <_DYNAMIC+0x248>
  81bb5d:	add    $0x8,%rsp
  81bb61:	pop    %rbx
  81bb62:	pop    %r14
  81bb64:	ret
  81bb65:	mov    %rax,%r14
  81bb68:	jmp    81bb95 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb6a:	mov    %rax,%r14
  81bb6d:	mov    0x58(%rbx),%rax
  81bb71:	lock decq (%rax)
  81bb75:	jne    81bb95 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb77:	lea    0x58(%rbx),%rdi
  81bb7b:	call   *0x6659f7(%rip)        # e81578 <_DYNAMIC+0x4e8>
  81bb81:	jmp    81bb95 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb83:	call   *0x665757(%rip)        # e812e0 <_DYNAMIC+0x250>
  81bb89:	mov    %rax,%r14
  81bb8c:	lea    0x50(%rbx),%rdi
  81bb90:	call   81c430 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bb95:	add    $0xa8,%rbx
  81bb9c:	mov    %rbx,%rdi
  81bb9f:	call   8231e0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bba4:	mov    %r14,%rdi
  81bba7:	call   e2dda0 <_Unwind_Resume@plt>
  81bbac:	call   *0x66572e(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bbc0:	push   %r14
  81bbc2:	push   %rbx
  81bbc3:	push   %rax
  81bbc4:	mov    %rdi,%rbx
  81bbc7:	mov    (%rdi),%rax
  81bbca:	lock decq (%rax)
  81bbce:	jne    81bbd9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bbd0:	mov    %rbx,%rdi
  81bbd3:	call   *0x6659bf(%rip)        # e81598 <_DYNAMIC+0x508>
  81bbd9:	mov    0x8(%rbx),%rax
  81bbdd:	lock decq (%rax)
  81bbe1:	jne    81bbf7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bbe3:	add    $0x8,%rbx
  81bbe7:	mov    %rbx,%rdi
  81bbea:	add    $0x8,%rsp
  81bbee:	pop    %rbx
  81bbef:	pop    %r14
  81bbf1:	jmp    *0x6659a9(%rip)        # e815a0 <_DYNAMIC+0x510>
  81bbf7:	add    $0x8,%rsp
  81bbfb:	pop    %rbx
  81bbfc:	pop    %r14
  81bbfe:	ret
  81bbff:	mov    %rax,%r14
  81bc02:	mov    0x8(%rbx),%rax
  81bc06:	lock decq (%rax)
  81bc0a:	jne    81bc19 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bc0c:	add    $0x8,%rbx
  81bc10:	mov    %rbx,%rdi
  81bc13:	call   *0x665987(%rip)        # e815a0 <_DYNAMIC+0x510>
  81bc19:	mov    %r14,%rdi
  81bc1c:	call   e2dda0 <_Unwind_Resume@plt>
  81bc21:	call   *0x6656b9(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c560 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c560:	push   %rbp
  81c561:	push   %r15
  81c563:	push   %r14
  81c565:	push   %r13
  81c567:	push   %r12
  81c569:	push   %rbx
  81c56a:	sub    $0x28,%rsp
  81c56e:	movss  0x8c(%rdi),%xmm3
  81c576:	movss  -0x76d562(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c57e:	movaps %xmm3,%xmm1
  81c581:	subss  %xmm0,%xmm1
  81c585:	cvttss2si %xmm1,%rax
  81c58a:	cvttss2si %xmm3,%r8
  81c58f:	mov    %r8,%rcx
  81c592:	sar    $0x3f,%rcx
  81c596:	and    %rax,%rcx
  81c599:	or     %r8,%rcx
  81c59c:	xor    %r9d,%r9d
  81c59f:	xorps  %xmm1,%xmm1
  81c5a2:	ucomiss %xmm1,%xmm3
  81c5a5:	cmovb  %r9,%rcx
  81c5a9:	movss  -0x76d591(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c5b1:	ucomiss %xmm2,%xmm3
  81c5b4:	mov    $0xffffffffffffffff,%rax
  81c5bb:	cmova  %rax,%rcx
  81c5bf:	movss  0x94(%rdi),%xmm3
  81c5c7:	mov    %rcx,%r8
  81c5ca:	shr    $0x4,%r8
  81c5ce:	movaps %xmm3,%xmm4
  81c5d1:	subss  %xmm0,%xmm4
  81c5d5:	cvttss2si %xmm4,%r10
  81c5da:	cvttss2si %xmm3,%r11
  81c5df:	mov    %r11,%rbx
  81c5e2:	sar    $0x3f,%rbx
  81c5e6:	and    %r10,%rbx
  81c5e9:	or     %r11,%rbx
  81c5ec:	ucomiss %xmm1,%xmm3
  81c5ef:	cmovb  %r9,%rbx
  81c5f3:	ucomiss %xmm2,%xmm3
  81c5f6:	cmova  %rax,%rbx
  81c5fa:	mov    %rsi,0x18(%rsp)
  81c5ff:	lea    (%rcx,%rbx,1),%r11
  81c603:	dec    %r11
  81c606:	shr    $0x4,%r11
  81c60a:	cmp    %r11,%r8
  81c60d:	jbe    81c61e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c60f:	add    $0x28,%rsp
  81c613:	pop    %rbx
  81c614:	pop    %r12
  81c616:	pop    %r13
  81c618:	pop    %r14
  81c61a:	pop    %r15
  81c61c:	pop    %rbp
  81c61d:	ret
  81c61e:	movss  0x88(%rdi),%xmm3
  81c626:	movaps %xmm3,%xmm4
  81c629:	subss  %xmm0,%xmm4
  81c62d:	cvttss2si %xmm4,%rsi
  81c632:	cvttss2si %xmm3,%r9
  81c637:	mov    %r9,%rcx
  81c63a:	sar    $0x3f,%rcx
  81c63e:	and    %rsi,%rcx
  81c641:	or     %r9,%rcx
  81c644:	xor    %r10d,%r10d
  81c647:	ucomiss %xmm1,%xmm3
  81c64a:	cmovb  %r10,%rcx
  81c64e:	ucomiss %xmm2,%xmm3
  81c651:	cmova  %rax,%rcx
  81c655:	movss  0x90(%rdi),%xmm3
  81c65d:	mov    %rcx,%r14
  81c660:	shr    $0x4,%r14
  81c664:	movaps %xmm3,%xmm4
  81c667:	subss  %xmm0,%xmm4
  81c66b:	cvttss2si %xmm4,%rsi
  81c670:	cvttss2si %xmm3,%rdi
  81c675:	mov    %rdi,%r9
  81c678:	sar    $0x3f,%r9
  81c67c:	and    %rsi,%r9
  81c67f:	or     %rdi,%r9
  81c682:	ucomiss %xmm1,%xmm3
  81c685:	cmovb  %r10,%r9
  81c689:	ucomiss %xmm2,%xmm3
  81c68c:	cmova  %rax,%r9
  81c690:	lea    (%r9,%rcx,1),%rbx
  81c694:	dec    %rbx
  81c697:	shr    $0x4,%rbx
  81c69b:	mov    %r14,0x10(%rsp)
  81c6a0:	cmp    %rbx,%r14
  81c6a3:	jbe    81c6cd <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c6a5:	data16 cs nopw 0x0(%rax,%rax,1)
  81c6b0:	mov    %r8,%rax
  81c6b3:	cmp    %r11,%r8
  81c6b6:	adc    $0x0,%r8
  81c6ba:	cmp    %r11,%rax
  81c6bd:	jae    81c60f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c6c3:	cmp    %r11,%r8
  81c6c6:	jbe    81c6b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c6c8:	jmp    81c60f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c6cd:	mov    (%rdx),%r14
  81c6d0:	mov    0x8(%rdx),%r15
  81c6d4:	mov    0x10(%rdx),%r12
  81c6d8:	mov    0x18(%rdx),%r13
  81c6dc:	mov    0x20(%rdx),%rdx
  81c6e0:	mov    %r11,0x8(%rsp)
  81c6e5:	data16 cs nopw 0x0(%rax,%rax,1)
  81c6f0:	mov    %r8,%rbp
  81c6f3:	cmp    %r11,%r8
  81c6f6:	adc    $0x0,%r8
  81c6fa:	mov    %rbp,0x20(%rsp)
  81c6ff:	imul   0x18(%rsp),%rbp
  81c705:	mov    0x10(%rsp),%r9
  81c70a:	mov    %r9,%rsi
  81c70d:	nopl   (%rax)
  81c710:	cmp    %rbx,%r9
  81c713:	adc    $0x0,%rsi
  81c717:	lea    (%r9,%rbp,1),%rdi
  81c71b:	mov    0x10(%r14),%rax
  81c71f:	cmp    %rax,%rdi
  81c722:	jae    81c790 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c724:	mov    0x8(%r14),%rcx
  81c728:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c72d:	jo     81c765 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c72f:	mov    0x10(%r12),%rax
  81c734:	cmp    %rax,%rdi
  81c737:	jae    81c7a0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c739:	mov    0x8(%r12),%rax
  81c73e:	mov    0x0(%r13),%r11d
  81c742:	inc    %r11d
  81c745:	cmp    (%rax,%rdi,4),%r11d
  81c749:	jb     81c765 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c74b:	mov    (%rcx,%rdi,8),%eax
  81c74e:	dec    %eax
  81c750:	mov    %eax,(%rcx,%rdi,8)
  81c753:	mov    0x10(%r15),%rcx
  81c757:	cmp    %rax,%rcx
  81c75a:	jbe    81c7b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c75c:	mov    0x8(%r15),%rcx
  81c760:	mov    (%rdx),%edi
  81c762:	mov    %edi,(%rcx,%rax,4)
  81c765:	cmp    %rbx,%r9
  81c768:	jae    81c772 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c76a:	mov    %rsi,%r9
  81c76d:	cmp    %rbx,%rsi
  81c770:	jbe    81c710 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c772:	mov    0x8(%rsp),%r11
  81c777:	cmp    %r11,0x20(%rsp)
  81c77c:	jae    81c60f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c782:	cmp    %r11,%r8
  81c785:	jbe    81c6f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c78b:	jmp    81c60f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c790:	lea    0x6133c9(%rip),%rdx        # e2fb60 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0xa8>
  81c797:	mov    %rax,%rsi
  81c79a:	call   *0x664de8(%rip)        # e81588 <_DYNAMIC+0x4f8>
  81c7a0:	lea    0x6133d1(%rip),%rdx        # e2fb78 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0xc0>
  81c7a7:	mov    %rax,%rsi
  81c7aa:	call   *0x664dd8(%rip)        # e81588 <_DYNAMIC+0x4f8>
  81c7b0:	lea    0x6133d9(%rip),%rdx        # e2fb90 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0xd8>
  81c7b7:	mov    %rax,%rdi
  81c7ba:	mov    %rcx,%rsi
  81c7bd:	call   *0x664dc5(%rip)        # e81588 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}> bytes=235 frame=248

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c7d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>:
  81c7d0:	push   %rbp
  81c7d1:	push   %r15
  81c7d3:	push   %r14
  81c7d5:	push   %r13
  81c7d7:	push   %r12
  81c7d9:	push   %rbx
  81c7da:	sub    $0xc8,%rsp
  81c7e1:	mov    %esi,%ebp
  81c7e3:	mov    %rdi,%rbx
  81c7e6:	lea    0x8(%rsp),%rdi
  81c7eb:	mov    %rbx,%rsi
  81c7ee:	call   *0x664e54(%rip)        # e81648 <_DYNAMIC+0x5b8>
  81c7f4:	mov    0x8(%rsp),%rsi
  81c7f9:	xor    %r14d,%r14d
  81c7fc:	test   $0x1,%bpl
  81c800:	je     81c878 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xa8>
  81c802:	test   %rsi,%rsi
  81c805:	je     81c8a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c80b:	mov    $0x1,%r13d
  81c811:	lea    0x8(%rsp),%r12
  81c816:	mov    0x664e2b(%rip),%rbp        # e81648 <_DYNAMIC+0x5b8>
  81c81d:	jmp    81c835 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x65>
  81c81f:	nop
  81c820:	add    %r15,%r14
  81c823:	mov    %r12,%rdi
  81c826:	mov    %rbx,%rsi
  81c829:	call   *%rbp
  81c82b:	mov    0x8(%rsp),%rsi
  81c830:	test   %rsi,%rsi
  81c833:	je     81c8a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c835:	mov    0x18(%rsp),%r15
  81c83a:	cmp    $0x2,%r15
  81c83e:	jb     81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c840:	mov    0x10(%rsp),%rax
  81c845:	mov    (%rax),%edx
  81c847:	lea    0x70(%rsp),%rdi
  81c84c:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c851:	movss  0x74(%rsp),%xmm0
  81c857:	xorps  %xmm1,%xmm1
  81c85a:	ucomiss %xmm1,%xmm0
  81c85d:	mov    $0x1,%eax
  81c862:	cmovne %r15,%rax
  81c866:	cmovp  %r15,%rax
  81c86a:	cmpb   $0x3,0x70(%rsp)
  81c86f:	cmovne %r13,%rax
  81c873:	mov    %rax,%r15
  81c876:	jmp    81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c878:	test   %rsi,%rsi
  81c87b:	je     81c8a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c87d:	lea    0x8(%rsp),%r15
  81c882:	mov    0x664dbf(%rip),%r12        # e81648 <_DYNAMIC+0x5b8>
  81c889:	nopl   0x0(%rax)
  81c890:	add    0x18(%rsp),%r14
  81c895:	mov    %r15,%rdi
  81c898:	mov    %rbx,%rsi
  81c89b:	call   *%r12
  81c89e:	cmpq   $0x0,0x8(%rsp)
  81c8a4:	jne    81c890 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xc0>
  81c8a6:	mov    %r14,%rax
  81c8a9:	add    $0xc8,%rsp
  81c8b0:	pop    %rbx
  81c8b1:	pop    %r12
  81c8b3:	pop    %r13
  81c8b5:	pop    %r14
  81c8b7:	pop    %r15
  81c8b9:	pop    %rbp
  81c8ba:	ret

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb00 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81cb00:	push   %rbp
  81cb01:	push   %r14
  81cb03:	push   %rbx
  81cb04:	cmp    0x341(%rdi),%sil
  81cb0b:	je     81cb4b <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81cb0d:	mov    0x330(%rdi),%rax
  81cb14:	test   %rax,%rax
  81cb17:	je     81cb39 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cb19:	lock decq (%rax)
  81cb1d:	jne    81cb39 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cb1f:	lea    0x330(%rdi),%rbx
  81cb26:	mov    %rdi,%r14
  81cb29:	mov    %rbx,%rdi
  81cb2c:	mov    %esi,%ebp
  81cb2e:	call   *0x664a74(%rip)        # e815a8 <_DYNAMIC+0x518>
  81cb34:	mov    %r14,%rdi
  81cb37:	mov    %ebp,%esi
  81cb39:	movq   $0x0,0x330(%rdi)
  81cb44:	mov    %sil,0x341(%rdi)
  81cb4b:	pop    %rbx
  81cb4c:	pop    %r14
  81cb4e:	pop    %rbp
  81cb4f:	ret
  81cb50:	movq   $0x0,(%rbx)
  81cb57:	mov    %rax,%rdi
  81cb5a:	call   e2dda0 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Changes>::upload bytes=83 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb60 <<gpui_gpu::renderer::Changes>::upload>:
  81cb60:	push   %rbx
  81cb61:	mov    %rsi,%rbx
  81cb64:	sub    %rdi,%rbx
  81cb67:	jbe    81cb96 <<gpui_gpu::renderer::Changes>::upload+0x36>
  81cb69:	mov    %rdx,%rax
  81cb6c:	mov    %rdi,%rdx
  81cb6f:	cmp    %rcx,%rsi
  81cb72:	ja     81cb9d <<gpui_gpu::renderer::Changes>::upload+0x3d>
  81cb74:	shl    $0x4,%rdx
  81cb78:	add    %rdx,%rax
  81cb7b:	shl    $0x4,%rbx
  81cb7f:	mov    %r9,%rdi
  81cb82:	mov    %r8,%rsi
  81cb85:	mov    %rax,%rcx
  81cb88:	mov    %rbx,%r8
  81cb8b:	call   *0x664acf(%rip)        # e81660 <_DYNAMIC+0x5d0>
  81cb91:	mov    %rbx,%rax
  81cb94:	pop    %rbx
  81cb95:	ret
  81cb96:	xor    %ebx,%ebx
  81cb98:	mov    %rbx,%rax
  81cb9b:	pop    %rbx
  81cb9c:	ret
  81cb9d:	lea    0x613064(%rip),%rax        # e2fc08 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x150>
  81cba4:	mov    %rdx,%rdi
  81cba7:	mov    %rcx,%rdx
  81cbaa:	mov    %rax,%rcx
  81cbad:	call   *0x664a25(%rip)        # e815d8 <_DYNAMIC+0x548>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=76 frame=40

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cbc0 <<gpui_gpu::renderer::Buffer>::write>:
  81cbc0:	push   %r15
  81cbc2:	push   %r14
  81cbc4:	push   %r12
  81cbc6:	push   %rbx
  81cbc7:	push   %rax
  81cbc8:	mov    %r8,%r12
  81cbcb:	mov    %rcx,%rbx
  81cbce:	mov    %rdx,%r14
  81cbd1:	mov    %rdi,%r15
  81cbd4:	mov    %r8,%rdx
  81cbd7:	call   81cc10 <<gpui_gpu::renderer::Buffer>::reserve>
  81cbdc:	test   %r12,%r12
  81cbdf:	je     81cc00 <<gpui_gpu::renderer::Buffer>::write+0x40>
  81cbe1:	mov    %r14,%rdi
  81cbe4:	mov    %r15,%rsi
  81cbe7:	xor    %edx,%edx
  81cbe9:	mov    %rbx,%rcx
  81cbec:	mov    %r12,%r8
  81cbef:	add    $0x8,%rsp
  81cbf3:	pop    %rbx
  81cbf4:	pop    %r12
  81cbf6:	pop    %r14
  81cbf8:	pop    %r15
  81cbfa:	jmp    *0x664a60(%rip)        # e81660 <_DYNAMIC+0x5d0>
  81cc00:	add    $0x8,%rsp
  81cc04:	pop    %rbx
  81cc05:	pop    %r12
  81cc07:	pop    %r14
  81cc09:	pop    %r15
  81cc0b:	ret

FUNCTION <gpui_gpu::renderer::Buffer>::reserve bytes=271 frame=104

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc10 <<gpui_gpu::renderer::Buffer>::reserve>:
  81cc10:	push   %r15
  81cc12:	push   %r14
  81cc14:	push   %r12
  81cc16:	push   %rbx
  81cc17:	sub    $0x48,%rsp
  81cc1b:	mov    %rdx,%r14
  81cc1e:	mov    0x20(%rdi),%r15
  81cc22:	cmp    %r15,%rdx
  81cc25:	jbe    81ccca <<gpui_gpu::renderer::Buffer>::reserve+0xba>
  81cc2b:	mov    %rdi,%rbx
  81cc2e:	mov    $0x1,%r12d
  81cc34:	cmp    $0x2,%r14
  81cc38:	jb     81cc51 <<gpui_gpu::renderer::Buffer>::reserve+0x41>
  81cc3a:	lea    -0x1(%r14),%rax
  81cc3e:	bsr    %rax,%rcx
  81cc42:	not    %ecx
  81cc44:	mov    $0xffffffffffffffff,%r12
  81cc4b:	shr    %cl,%r12
  81cc4e:	inc    %r12
  81cc51:	lea    -0x748078(%rip),%rax        # d4be0 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x142>
  81cc58:	mov    %rax,0x28(%rsp)
  81cc5d:	movq   $0xa,0x30(%rsp)
  81cc66:	mov    %r12,0x38(%rsp)
  81cc6b:	movl   $0x88,0x40(%rsp)
  81cc73:	movb   $0x0,0x44(%rsp)
  81cc78:	mov    %rsp,%rdi
  81cc7b:	lea    0x28(%rsp),%rdx
  81cc80:	call   *0x664a2a(%rip)        # e816b0 <_DYNAMIC+0x620>
  81cc86:	mov    %r12,0x20(%rsp)
  81cc8b:	mov    (%rbx),%rax
  81cc8e:	lock decq (%rax)
  81cc92:	jne    81cc9d <<gpui_gpu::renderer::Buffer>::reserve+0x8d>
  81cc94:	mov    %rbx,%rdi
  81cc97:	call   *0x6648fb(%rip)        # e81598 <_DYNAMIC+0x508>
  81cc9d:	mov    0x8(%rbx),%rax
  81cca1:	lock decq (%rax)
  81cca5:	jne    81ccb1 <<gpui_gpu::renderer::Buffer>::reserve+0xa1>
  81cca7:	lea    0x8(%rbx),%rdi
  81ccab:	call   *0x6648ef(%rip)        # e815a0 <_DYNAMIC+0x510>
  81ccb1:	mov    0x20(%rsp),%rax
  81ccb6:	mov    %rax,0x20(%rbx)
  81ccba:	movups (%rsp),%xmm0
  81ccbe:	movups 0x10(%rsp),%xmm1
  81ccc3:	movups %xmm1,0x10(%rbx)
  81ccc7:	movups %xmm0,(%rbx)
  81ccca:	cmp    %r15,%r14
  81cccd:	seta   %al
  81ccd0:	add    $0x48,%rsp
  81ccd4:	pop    %rbx
  81ccd5:	pop    %r12
  81ccd7:	pop    %r14
  81ccd9:	pop    %r15
  81ccdb:	ret
  81ccdc:	mov    %rax,%r14
  81ccdf:	jmp    81ccf8 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81cce1:	mov    %rax,%r14
  81cce4:	mov    0x8(%rbx),%rax
  81cce8:	lock decq (%rax)
  81ccec:	jne    81ccf8 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81ccee:	lea    0x8(%rbx),%rdi
  81ccf2:	call   *0x6648a8(%rip)        # e815a0 <_DYNAMIC+0x510>
  81ccf8:	mov    0x20(%rsp),%rax
  81ccfd:	mov    %rax,0x20(%rbx)
  81cd01:	movups (%rsp),%xmm0
  81cd05:	movups 0x10(%rsp),%xmm1
  81cd0a:	movups %xmm1,0x10(%rbx)
  81cd0e:	movups %xmm0,(%rbx)
  81cd11:	mov    %r14,%rdi
  81cd14:	call   e2dda0 <_Unwind_Resume@plt>
  81cd19:	call   *0x6645c1(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cd20 <<gpui_gpu::renderer::Atlas>::new>:
  81cd20:	push   %rbp
  81cd21:	push   %r14
  81cd23:	push   %rbx
  81cd24:	sub    $0x160,%rsp
  81cd2b:	mov    %edx,%ebp
  81cd2d:	mov    %rdi,%rbx
  81cd30:	lea    -0x74814d(%rip),%rax        # d4bea <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x14c>
  81cd37:	mov    %rax,(%rsp)
  81cd3b:	movq   $0xe,0x8(%rsp)
  81cd44:	mov    %edx,0x10(%rsp)
  81cd48:	mov    %edx,0x14(%rsp)
  81cd4c:	movaps -0x7707e3(%rip),%xmm0        # ac570 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81cd53:	movups %xmm0,0x18(%rsp)
  81cd58:	movl   $0x0,0x28(%rsp)
  81cd60:	movl   $0x6,0x34(%rsp)
  81cd68:	movq   $0x4,0x38(%rsp)
  81cd71:	movq   $0x0,0x40(%rsp)
  81cd7a:	lea    0x110(%rsp),%r14
  81cd82:	mov    %rsp,%rdx
  81cd85:	mov    %r14,%rdi
  81cd88:	call   *0x6647a2(%rip)        # e81530 <_DYNAMIC+0x4a0>
  81cd8e:	movq   $0x0,0x18(%rsp)
  81cd97:	movl   $0xffffffff,0x30(%rsp)
  81cd9f:	movl   $0x0,(%rsp)
  81cda6:	movabs $0xffffffff00000000,%rax
  81cdb0:	mov    %rax,0x28(%rsp)
  81cdb5:	movq   $0x0,0x3c(%rsp)
  81cdbe:	movl   $0x0,0x8(%rsp)
  81cdc6:	movl   $0x0,0x10(%rsp)
  81cdce:	lea    0xb8(%rsp),%rdi
  81cdd6:	mov    %rsp,%rdx
  81cdd9:	mov    %r14,%rsi
  81cddc:	call   *0x664756(%rip)        # e81538 <_DYNAMIC+0x4a8>
  81cde2:	movups 0x150(%rsp),%xmm0
  81cdea:	movaps %xmm0,0xa0(%rsp)
  81cdf2:	movups 0x110(%rsp),%xmm0
  81cdfa:	movups 0x120(%rsp),%xmm1
  81ce02:	movups 0x130(%rsp),%xmm2
  81ce0a:	movups 0x140(%rsp),%xmm3
  81ce12:	movaps %xmm3,0x90(%rsp)
  81ce1a:	movaps %xmm2,0x80(%rsp)
  81ce22:	movaps %xmm1,0x70(%rsp)
  81ce27:	movaps %xmm0,0x60(%rsp)
  81ce2c:	mov    0x108(%rsp),%rax
  81ce34:	mov    %rax,0x50(%rsp)
  81ce39:	movups 0xf8(%rsp),%xmm0
  81ce41:	movaps %xmm0,0x40(%rsp)
  81ce46:	movups 0xb8(%rsp),%xmm0
  81ce4e:	movups 0xc8(%rsp),%xmm1
  81ce56:	movups 0xd8(%rsp),%xmm2
  81ce5e:	movups 0xe8(%rsp),%xmm3
  81ce66:	movaps %xmm3,0x30(%rsp)
  81ce6b:	movaps %xmm2,0x20(%rsp)
  81ce70:	movaps %xmm1,0x10(%rsp)
  81ce75:	movaps %xmm0,(%rsp)
  81ce79:	mov    %fs:0x0,%rax
  81ce82:	lea    -0x28(%rax),%rax
  81ce89:	mov    %rax,%r14
  81ce8c:	cmpb   $0x1,0x10(%rax)
  81ce90:	jne    81cf7b <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81ce96:	mov    (%r14),%rax
  81ce99:	mov    0x8(%r14),%rdx
  81ce9d:	lea    0x1(%rax),%rcx
  81cea1:	mov    %rcx,(%r14)
  81cea4:	movaps 0xa0(%rsp),%xmm0
  81ceac:	movups %xmm0,0x40(%rbx)
  81ceb0:	movaps 0x60(%rsp),%xmm0
  81ceb5:	movaps 0x70(%rsp),%xmm1
  81ceba:	movaps 0x80(%rsp),%xmm2
  81cec2:	movaps 0x90(%rsp),%xmm3
  81ceca:	movups %xmm3,0x30(%rbx)
  81cece:	movups %xmm2,0x20(%rbx)
  81ced2:	movups %xmm1,0x10(%rbx)
  81ced6:	movups %xmm0,(%rbx)
  81ced9:	movups 0xb8(%rsp),%xmm0
  81cee1:	movups 0xc8(%rsp),%xmm1
  81cee9:	movups 0xd8(%rsp),%xmm2
  81cef1:	movups 0xe8(%rsp),%xmm3
  81cef9:	movups %xmm0,0x50(%rbx)
  81cefd:	movups %xmm1,0x60(%rbx)
  81cf01:	movups %xmm2,0x70(%rbx)
  81cf05:	movups %xmm3,0x80(%rbx)
  81cf0c:	movups 0xf8(%rsp),%xmm0
  81cf14:	movups %xmm0,0x90(%rbx)
  81cf1b:	mov    0x108(%rsp),%rcx
  81cf23:	mov    %rcx,0xa0(%rbx)
  81cf2a:	mov    %ebp,0xd8(%rbx)
  81cf30:	movq   $0x0,0xdc(%rbx)
  81cf3b:	movl   $0x0,0xe4(%rbx)
  81cf45:	movups 0x612d64(%rip),%xmm0        # e2fcb0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x1f8>
  81cf4c:	movups %xmm0,0xa8(%rbx)
  81cf53:	movups 0x612d66(%rip),%xmm0        # e2fcc0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x208>
  81cf5a:	movups %xmm0,0xb8(%rbx)
  81cf61:	mov    %rax,0xc8(%rbx)
  81cf68:	mov    %rdx,0xd0(%rbx)
  81cf6f:	add    $0x160,%rsp
  81cf76:	pop    %rbx
  81cf77:	pop    %r14
  81cf79:	pop    %rbp
  81cf7a:	ret
  81cf7b:	call   *0x664737(%rip)        # e816b8 <_DYNAMIC+0x628>
  81cf81:	mov    %rax,(%r14)
  81cf84:	mov    %rdx,0x8(%r14)
  81cf88:	movb   $0x1,0x10(%r14)
  81cf8d:	jmp    81ce9d <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cf92:	mov    %rax,%rbx
  81cf95:	mov    %rsp,%rdi
  81cf98:	call   81c430 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cf9d:	mov    0x60(%rsp),%rax
  81cfa2:	lock decq (%rax)
  81cfa6:	jne    81cfd4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfa8:	lea    0x60(%rsp),%rdi
  81cfad:	call   *0x6645c5(%rip)        # e81578 <_DYNAMIC+0x4e8>
  81cfb3:	jmp    81cfd4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfb5:	mov    %rax,%rbx
  81cfb8:	mov    0x110(%rsp),%rax
  81cfc0:	lock decq (%rax)
  81cfc4:	jne    81cfd4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfc6:	lea    0x110(%rsp),%rdi
  81cfce:	call   *0x6645a4(%rip)        # e81578 <_DYNAMIC+0x4e8>
  81cfd4:	mov    %rbx,%rdi
  81cfd7:	call   e2dda0 <_Unwind_Resume@plt>
  81cfdc:	call   *0x6642fe(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cff0 <<gpui_gpu::renderer::Atlas>::insert>:
  81cff0:	push   %rbp
  81cff1:	push   %r15
  81cff3:	push   %r14
  81cff5:	push   %r13
  81cff7:	push   %r12
  81cff9:	push   %rbx
  81cffa:	sub    $0x68,%rsp
  81cffe:	mov    %rdx,%r12
  81d001:	mov    %rsi,%r15
  81d004:	mov    %rdi,%r14
  81d007:	lea    0x10(%rdx),%r13
  81d00b:	cmpq   $0x0,0xc0(%rdi)
  81d013:	je     81d0db <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d019:	lea    0xc8(%r14),%rdi
  81d020:	mov    %r13,%rsi
  81d023:	call   8250e0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81d028:	mov    %rax,%rsi
  81d02b:	shr    $0x39,%rsi
  81d02f:	mov    0xa8(%r14),%rcx
  81d036:	mov    0xb0(%r14),%rdx
  81d03d:	movd   %esi,%xmm0
  81d041:	punpcklbw %xmm0,%xmm0
  81d045:	pshuflw $0x0,%xmm0,%xmm0
  81d04a:	pshufd $0x44,%xmm0,%xmm0
  81d04f:	mov    0x10(%r12),%rsi
  81d054:	movzwl 0x1c(%r12),%edi
  81d05a:	mov    0x18(%r12),%r8d
  81d05f:	pcmpeqd %xmm1,%xmm1
  81d063:	xor    %r9d,%r9d
  81d066:	and    %rdx,%rax
  81d069:	movdqu (%rcx,%rax,1),%xmm2
  81d06e:	movdqa %xmm2,%xmm3
  81d072:	pcmpeqb %xmm0,%xmm3
  81d076:	pmovmskb %xmm3,%r10d
  81d07b:	test   %r10d,%r10d
  81d07e:	je     81d0c0 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81d080:	tzcnt  %r10d,%ebx
  81d085:	add    %rax,%rbx
  81d088:	and    %rdx,%rbx
  81d08b:	shl    $0x5,%rbx
  81d08f:	mov    %rcx,%r11
  81d092:	sub    %rbx,%r11
  81d095:	cmp    -0x20(%r11),%rsi
  81d099:	jne    81d0ac <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d09b:	cmp    -0x14(%r11),%di
  81d0a0:	jne    81d0ac <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d0a2:	cmp    -0x18(%r11),%r8d
  81d0a6:	je     81d143 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d0ac:	lea    -0x1(%r10),%r11d
  81d0b0:	and    %r10w,%r11w
  81d0b4:	mov    %r11d,%r10d
  81d0b7:	jne    81d080 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d0b9:	nopl   0x0(%rax)
  81d0c0:	pcmpeqb %xmm1,%xmm2
  81d0c4:	pmovmskb %xmm2,%r10d
  81d0c9:	test   %r10d,%r10d
  81d0cc:	jne    81d0db <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d0ce:	add    %r9,%rax
  81d0d1:	add    $0x10,%rax
  81d0d5:	add    $0x10,%r9
  81d0d9:	jmp    81d066 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d0db:	mov    0x20(%r12),%ebp
  81d0e0:	xor    %eax,%eax
  81d0e2:	test   %ebp,%ebp
  81d0e4:	je     81d13e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d0e6:	mov    %r15,%rdi
  81d0e9:	mov    0x28(%r12),%r15d
  81d0ee:	test   %r15d,%r15d
  81d0f1:	je     81d13e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d0f3:	mov    0xd8(%r14),%ecx
  81d0fa:	cmp    %ebp,%ecx
  81d0fc:	jb     81d241 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d102:	cmp    %r15d,%ecx
  81d105:	jb     81d241 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d10b:	mov    %r13,0x40(%rsp)
  81d110:	mov    0xdc(%r14),%r8d
  81d117:	mov    0xe4(%r14),%r13d
  81d11e:	lea    (%r8,%rbp,1),%edx
  81d122:	xor    %eax,%eax
  81d124:	cmp    %ecx,%edx
  81d126:	mov    $0x0,%ebx
  81d12b:	cmova  %r13d,%ebx
  81d12f:	add    0xe0(%r14),%ebx
  81d136:	lea    (%rbx,%r15,1),%esi
  81d13a:	cmp    %ecx,%esi
  81d13c:	jbe    81d14f <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d13e:	jmp    81d241 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d143:	mov    $0x1,%eax
  81d148:	xor    %edx,%edx
  81d14a:	jmp    81d241 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d14f:	cmp    %r13d,%r15d
  81d152:	cmova  %r15d,%r13d
  81d156:	cmp    %ecx,%edx
  81d158:	cmova  %eax,%r8d
  81d15c:	lea    0xa8(%r14),%rax
  81d163:	mov    %rax,0x38(%rsp)
  81d168:	mov    %r14,0x48(%rsp)
  81d16d:	movl   $0x0,0x50(%rsp)
  81d175:	mov    %r8d,0x54(%rsp)
  81d17a:	mov    %ebx,0x58(%rsp)
  81d17e:	movq   $0x0,0x5c(%rsp)
  81d187:	mov    (%r12),%rdx
  81d18b:	mov    0x8(%r12),%rcx
  81d190:	mov    %rcx,0x30(%rsp)
  81d195:	movq   $0x0,0x8(%rsp)
  81d19e:	movl   $0x1,0x10(%rsp)
  81d1a6:	mov    %ebp,0x14(%rsp)
  81d1aa:	movl   $0x1,0x18(%rsp)
  81d1b2:	mov    %r15d,0x1c(%rsp)
  81d1b7:	mov    %ebp,0x20(%rsp)
  81d1bb:	mov    %r15d,0x24(%rsp)
  81d1c0:	movl   $0x1,0x28(%rsp)
  81d1c8:	cmova  %r15d,%r13d
  81d1cc:	lea    0x48(%rsp),%rsi
  81d1d1:	mov    %r8,%r12
  81d1d4:	lea    0x8(%rsp),%r8
  81d1d9:	lea    0x20(%rsp),%r9
  81d1de:	call   *0x6644dc(%rip)        # e816c0 <_DYNAMIC+0x630>
  81d1e4:	lea    (%r12,%rbp,1),%eax
  81d1e8:	mov    %eax,0xdc(%r14)
  81d1ef:	mov    %ebx,0xe0(%r14)
  81d1f6:	mov    %r13d,0xe4(%r14)
  81d1fd:	mov    0x40(%rsp),%rax
  81d202:	movdqu (%rax),%xmm0
  81d206:	movdqa %xmm0,0x20(%rsp)
  81d20c:	mov    %r12d,0x8(%rsp)
  81d211:	mov    %ebx,0xc(%rsp)
  81d215:	mov    %ebp,0x10(%rsp)
  81d219:	mov    %r15d,0x14(%rsp)
  81d21e:	lea    0x48(%rsp),%rdi
  81d223:	lea    0x20(%rsp),%rdx
  81d228:	lea    0x8(%rsp),%rcx
  81d22d:	mov    0x38(%rsp),%rsi
  81d232:	call   827190 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d237:	mov    0x30(%rsp),%rdx
  81d23c:	mov    $0x1,%eax
  81d241:	add    $0x68,%rsp
  81d245:	pop    %rbx
  81d246:	pop    %r12
  81d248:	pop    %r13
  81d24a:	pop    %r14
  81d24c:	pop    %r15
  81d24e:	pop    %rbp
  81d24f:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d250 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d250:	push   %r15
  81d252:	push   %r14
  81d254:	push   %r12
  81d256:	push   %rbx
  81d257:	sub    $0x548,%rsp
  81d25e:	mov    %rdx,%r14
  81d261:	mov    %rsi,%r12
  81d264:	mov    %rdi,%rbx
  81d267:	lea    0x612a62(%rip),%rdx        # e2fcd0 <anon.7e34a6dced7fe4eb77116889a7de5f31.33.llvm.6877253771164693793>
  81d26e:	lea    0x30(%rsp),%r15
  81d273:	mov    %r15,%rdi
  81d276:	mov    %rbx,%rsi
  81d279:	call   *0x664449(%rip)        # e816c8 <_DYNAMIC+0x638>
  81d27f:	xorps  %xmm0,%xmm0
  81d282:	movups %xmm0,0x10(%rsp)
  81d287:	movups %xmm0,0x20(%rsp)
  81d28c:	movl   $0x0,0x50(%rsp)
  81d294:	movb   $0x0,0x58(%rsp)
  81d299:	movups 0x9(%rsp),%xmm0
  81d29e:	movups %xmm0,0x59(%rsp)
  81d2a3:	movups 0x19(%rsp),%xmm0
  81d2a8:	movups %xmm0,0x69(%rsp)
  81d2ad:	mov    0x28(%rsp),%rax
  81d2b2:	mov    %rax,0x78(%rsp)
  81d2b7:	movl   $0x0,0x80(%rsp)
  81d2c2:	mov    %r12,0x88(%rsp)
  81d2ca:	movq   $0x0,0x90(%rsp)
  81d2d6:	lea    -0x7486e5(%rip),%rax        # d4bf8 <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.6877253771164693793>
  81d2dd:	mov    %rax,0xe0(%rsp)
  81d2e5:	movq   $0xa,0xe8(%rsp)
  81d2f1:	lea    0x50(%rsp),%rax
  81d2f6:	mov    %rax,0xd0(%rsp)
  81d2fe:	movq   $0x1,0xd8(%rsp)
  81d30a:	movl   $0xffffffff,0xb8(%rsp)
  81d315:	movl   $0x2,0x98(%rsp)
  81d320:	movq   $0x0,0xf0(%rsp)
  81d32c:	movl   $0x0,0xf8(%rsp)
  81d337:	lea    0x100(%rsp),%rdi
  81d33f:	lea    0x98(%rsp),%rdx
  81d347:	mov    %r15,%rsi
  81d34a:	call   *0x664380(%rip)        # e816d0 <_DYNAMIC+0x640>
  81d350:	lea    0x10(%rbx),%rsi
  81d354:	lea    0x100(%rsp),%rdi
  81d35c:	call   *0x664376(%rip)        # e816d8 <_DYNAMIC+0x648>
  81d362:	lea    0x100(%rsp),%rdi
  81d36a:	mov    $0x4,%ecx
  81d36f:	xor    %esi,%esi
  81d371:	mov    %r14,%rdx
  81d374:	xor    %r8d,%r8d
  81d377:	call   *0x664363(%rip)        # e816e0 <_DYNAMIC+0x650>
  81d37d:	lea    0x100(%rsp),%rdi
  81d385:	xor    %esi,%esi
  81d387:	mov    $0x3,%edx
  81d38c:	xor    %ecx,%ecx
  81d38e:	mov    $0x1,%r8d
  81d394:	call   *0x66434e(%rip)        # e816e8 <_DYNAMIC+0x658>
  81d39a:	lea    0x100(%rsp),%rdi
  81d3a2:	call   81c330 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d3a7:	movups 0x30(%rsp),%xmm0
  81d3ac:	movups 0x40(%rsp),%xmm1
  81d3b1:	movaps %xmm1,0x110(%rsp)
  81d3b9:	movaps %xmm0,0x100(%rsp)
  81d3c1:	lea    0x98(%rsp),%r14
  81d3c9:	lea    0x100(%rsp),%rsi
  81d3d1:	mov    %r14,%rdi
  81d3d4:	call   *0x664316(%rip)        # e816f0 <_DYNAMIC+0x660>
  81d3da:	add    $0x8,%rbx
  81d3de:	mov    %rbx,%rdi
  81d3e1:	mov    %r14,%rsi
  81d3e4:	call   826bb0 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d3e9:	add    $0x548,%rsp
  81d3f0:	pop    %rbx
  81d3f1:	pop    %r12
  81d3f3:	pop    %r14
  81d3f5:	pop    %r15
  81d3f7:	ret
  81d3f8:	mov    %rax,%rbx
  81d3fb:	jmp    81d40d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d3fd:	mov    %rax,%rbx
  81d400:	lea    0x100(%rsp),%rdi
  81d408:	call   81c330 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d40d:	lea    0x30(%rsp),%rdi
  81d412:	call   81c4a0 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d417:	mov    %rbx,%rdi
  81d41a:	call   e2dda0 <_Unwind_Resume@plt>
  81d41f:	call   *0x663ebb(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d430 <<gpui_gpu::renderer::RendererState>::correction>:
  81d430:	push   %r15
  81d432:	push   %r14
  81d434:	push   %r13
  81d436:	push   %r12
  81d438:	push   %rbx
  81d439:	sub    $0x90,%rsp
  81d440:	mov    %rdi,%rbx
  81d443:	movss  (%rdx),%xmm1
  81d447:	movss  0x8(%rdx),%xmm2
  81d44c:	movaps %xmm1,%xmm0
  81d44f:	addss  %xmm2,%xmm0
  81d453:	movd   %xmm0,%eax
  81d457:	and    $0x7fffffff,%eax
  81d45c:	xorps  %xmm8,%xmm8
  81d460:	xorps  %xmm9,%xmm9
  81d464:	cmp    $0x7f7fffff,%eax
  81d469:	jg     81d488 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d46b:	cvtss2sd %xmm1,%xmm1
  81d46f:	cvtss2sd %xmm2,%xmm2
  81d473:	cvtss2sd %xmm0,%xmm0
  81d477:	addsd  %xmm1,%xmm2
  81d47b:	subsd  %xmm0,%xmm2
  81d47f:	xorps  %xmm9,%xmm9
  81d483:	cvtsd2ss %xmm2,%xmm9
  81d488:	movupd (%rsi),%xmm0
  81d48c:	movupd 0x8(%rsi),%xmm1
  81d491:	movsd  0x10(%rsi),%xmm2
  81d496:	movsd  0x18(%rsi),%xmm3
  81d49b:	movupd 0x20(%rsi),%xmm4
  81d4a0:	movss  0x4(%rdx),%xmm6
  81d4a5:	movss  0xc(%rdx),%xmm7
  81d4aa:	movaps %xmm6,%xmm5
  81d4ad:	addss  %xmm7,%xmm5
  81d4b1:	movd   %xmm5,%eax
  81d4b5:	and    $0x7fffffff,%eax
  81d4ba:	cmp    $0x7f7fffff,%eax
  81d4bf:	jg     81d4de <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d4c1:	cvtss2sd %xmm6,%xmm6
  81d4c5:	cvtss2sd %xmm7,%xmm7
  81d4c9:	cvtss2sd %xmm5,%xmm5
  81d4cd:	addsd  %xmm6,%xmm7
  81d4d1:	subsd  %xmm5,%xmm7
  81d4d5:	xorps  %xmm8,%xmm8
  81d4d9:	cvtsd2ss %xmm7,%xmm8
  81d4de:	cvtpd2ps %xmm4,%xmm5
  81d4e2:	cvtps2pd %xmm5,%xmm5
  81d4e5:	subpd  %xmm5,%xmm4
  81d4e9:	cvtpd2ps %xmm4,%xmm4
  81d4ed:	unpcklpd %xmm3,%xmm1
  81d4f1:	cvtpd2ps %xmm1,%xmm3
  81d4f5:	unpcklpd %xmm2,%xmm0
  81d4f9:	cvtpd2ps %xmm0,%xmm2
  81d4fd:	cvtps2pd %xmm3,%xmm3
  81d500:	subpd  %xmm3,%xmm1
  81d504:	cvtpd2ps %xmm1,%xmm5
  81d508:	cvtps2pd %xmm2,%xmm1
  81d50b:	subpd  %xmm1,%xmm0
  81d50f:	cvtpd2ps %xmm0,%xmm6
  81d513:	movapd %xmm6,%xmm0
  81d517:	unpcklps %xmm5,%xmm0
  81d51a:	movaps %xmm8,%xmm1
  81d51e:	movlhps %xmm9,%xmm1
  81d522:	movapd %xmm4,%xmm2
  81d526:	shufps $0x24,%xmm1,%xmm2
  81d52a:	xorps  %xmm1,%xmm1
  81d52d:	movapd %xmm0,%xmm3
  81d531:	cmpneqps %xmm1,%xmm3
  81d535:	cmpneqps %xmm1,%xmm2
  81d539:	packssdw %xmm2,%xmm3
  81d53d:	pmovmskb %xmm3,%eax
  81d541:	test   %eax,%eax
  81d543:	je     81d667 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d549:	movapd %xmm6,0x60(%rsp)
  81d54f:	movapd %xmm5,0x70(%rsp)
  81d555:	lea    0x8(%rsp),%r12
  81d55a:	movapd %xmm0,(%rsp)
  81d55f:	movapd %xmm4,0x80(%rsp)
  81d568:	movlpd %xmm4,0x10(%rsp)
  81d56e:	movss  %xmm9,0x18(%rsp)
  81d575:	movss  %xmm8,0x1c(%rsp)
  81d57c:	lea    0x318(%rbx),%r14
  81d583:	mov    %rsp,%rsi
  81d586:	mov    %r14,%rdi
  81d589:	movaps %xmm8,0x30(%rsp)
  81d58f:	movaps %xmm9,0x20(%rsp)
  81d595:	call   824f60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d59a:	movapd 0x20(%rsp),%xmm6
  81d5a0:	movapd 0x30(%rsp),%xmm5
  81d5a6:	mov    %rax,%r15
  81d5a9:	shr    $0x39,%r15
  81d5ad:	mov    0x2f8(%rbx),%rcx
  81d5b4:	mov    0x300(%rbx),%rdx
  81d5bb:	movd   %r15d,%xmm0
  81d5c0:	punpcklbw %xmm0,%xmm0
  81d5c4:	pshuflw $0x0,%xmm0,%xmm0
  81d5c9:	pshufd $0x44,%xmm0,%xmm0
  81d5ce:	xor    %esi,%esi
  81d5d0:	pcmpeqd %xmm1,%xmm1
  81d5d4:	mov    %rax,%rdi
  81d5d7:	and    %rdx,%rdi
  81d5da:	movdqu (%rcx,%rdi,1),%xmm2
  81d5df:	movdqa %xmm2,%xmm3
  81d5e3:	pcmpeqb %xmm0,%xmm3
  81d5e7:	pmovmskb %xmm3,%r8d
  81d5ec:	test   %r8d,%r8d
  81d5ef:	je     81d640 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d5f1:	tzcnt  %r8d,%r9d
  81d5f6:	add    %rdi,%r9
  81d5f9:	and    %rdx,%r9
  81d5fc:	neg    %r9
  81d5ff:	lea    (%r9,%r9,8),%r9
  81d603:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d60a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d611:	pcmpeqb 0x10(%rsp),%xmm4
  81d617:	pcmpeqb (%rsp),%xmm3
  81d61c:	pand   %xmm4,%xmm3
  81d620:	pmovmskb %xmm3,%r10d
  81d625:	cmp    $0xffff,%r10d
  81d62c:	je     81d65e <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d62e:	lea    -0x1(%r8),%r9d
  81d632:	and    %r8w,%r9w
  81d636:	mov    %r9d,%r8d
  81d639:	jne    81d5f1 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d63b:	nopl   0x0(%rax,%rax,1)
  81d640:	pcmpeqb %xmm1,%xmm2
  81d644:	pmovmskb %xmm2,%r8d
  81d649:	test   %r8d,%r8d
  81d64c:	jne    81d66e <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d64e:	add    %rsi,%rdi
  81d651:	add    $0x10,%rdi
  81d655:	add    $0x10,%rsi
  81d659:	jmp    81d5d7 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d65e:	lea    (%rcx,%r9,4),%rdx
  81d662:	jmp    81d789 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d667:	xor    %eax,%eax
  81d669:	jmp    81d78c <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d66e:	cmpq   $0x0,0x308(%rbx)
  81d676:	je     81d7bf <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d67c:	mov    (%rsp),%r14
  81d680:	mov    0x10(%r12),%rcx
  81d685:	mov    %rcx,0x50(%rsp)
  81d68a:	movups (%r12),%xmm0
  81d68f:	movaps %xmm0,0x40(%rsp)
  81d694:	mov    0x70(%rbx),%r12
  81d698:	cmp    0x60(%rbx),%r12
  81d69c:	jne    81d6ba <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d69e:	lea    0x60(%rbx),%rdi
  81d6a2:	mov    %rax,%r13
  81d6a5:	call   *0x663f95(%rip)        # e81640 <_DYNAMIC+0x5b0>
  81d6ab:	movapd 0x20(%rsp),%xmm6
  81d6b1:	movapd 0x30(%rsp),%xmm5
  81d6b7:	mov    %r13,%rax
  81d6ba:	mov    0x68(%rbx),%rcx
  81d6be:	mov    %r12,%rdx
  81d6c1:	shl    $0x5,%rdx
  81d6c5:	movaps 0x60(%rsp),%xmm0
  81d6ca:	movlps %xmm0,(%rcx,%rdx,1)
  81d6ce:	movaps 0x80(%rsp),%xmm0
  81d6d6:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d6dc:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d6e2:	movdqa 0x70(%rsp),%xmm1
  81d6e8:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d6ee:	shufps $0x55,%xmm0,%xmm0
  81d6f2:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d6f8:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d6fe:	lea    0x1(%r12),%rcx
  81d703:	mov    %rcx,0x70(%rbx)
  81d707:	mov    0x2f8(%rbx),%rcx
  81d70e:	mov    0x300(%rbx),%rdx
  81d715:	and    %rdx,%rax
  81d718:	movdqu (%rcx,%rax,1),%xmm0
  81d71d:	pmovmskb %xmm0,%esi
  81d721:	test   %esi,%esi
  81d723:	je     81d79d <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d725:	tzcnt  %esi,%esi
  81d729:	add    %rax,%rsi
  81d72c:	and    %rdx,%rsi
  81d72f:	movzbl (%rcx,%rsi,1),%eax
  81d733:	test   %al,%al
  81d735:	jns    81d7f0 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d73b:	lea    -0x10(%rsi),%rdi
  81d73f:	and    %rdx,%rdi
  81d742:	mov    %r15b,(%rcx,%rsi,1)
  81d746:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d74b:	neg    %rsi
  81d74e:	lea    (%rsi,%rsi,8),%rsi
  81d752:	lea    (%rcx,%rsi,4),%rdx
  81d756:	and    $0x1,%al
  81d758:	movzbl %al,%eax
  81d75b:	sub    %rax,0x308(%rbx)
  81d762:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d767:	movdqa 0x40(%rsp),%xmm0
  81d76d:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d773:	mov    0x50(%rsp),%rax
  81d778:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d77d:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d782:	incq   0x310(%rbx)
  81d789:	mov    -0x4(%rdx),%eax
  81d78c:	add    $0x90,%rsp
  81d793:	pop    %rbx
  81d794:	pop    %r12
  81d796:	pop    %r13
  81d798:	pop    %r14
  81d79a:	pop    %r15
  81d79c:	ret
  81d79d:	mov    $0x10,%edi
  81d7a2:	add    %rdi,%rax
  81d7a5:	and    %rdx,%rax
  81d7a8:	movdqu (%rcx,%rax,1),%xmm0
  81d7ad:	pmovmskb %xmm0,%esi
  81d7b1:	add    $0x10,%rdi
  81d7b5:	test   %esi,%esi
  81d7b7:	jne    81d725 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d7bd:	jmp    81d7a2 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d7bf:	lea    0x2f8(%rbx),%rdi
  81d7c6:	mov    $0x1,%esi
  81d7cb:	mov    %r14,%rdx
  81d7ce:	mov    $0x1,%ecx
  81d7d3:	mov    %rax,%r14
  81d7d6:	call   *0x663f1c(%rip)        # e816f8 <_DYNAMIC+0x668>
  81d7dc:	movapd 0x20(%rsp),%xmm6
  81d7e2:	movapd 0x30(%rsp),%xmm5
  81d7e8:	mov    %r14,%rax
  81d7eb:	jmp    81d67c <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d7f0:	movdqa (%rcx),%xmm0
  81d7f4:	pmovmskb %xmm0,%eax
  81d7f8:	tzcnt  %eax,%esi
  81d7fc:	movzbl (%rcx,%rsi,1),%eax
  81d800:	jmp    81d73b <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d810 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d810:	push   %rbp
  81d811:	push   %r15
  81d813:	push   %r14
  81d815:	push   %r13
  81d817:	push   %r12
  81d819:	push   %rbx
  81d81a:	sub    $0x228,%rsp
  81d821:	mov    %rsi,%r14
  81d824:	test   %r8d,%r8d
  81d827:	je     81d8bb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d82d:	mov    %rdi,0x10(%rsp)
  81d832:	mov    0x110(%rcx),%rbp
  81d839:	test   %rbp,%rbp
  81d83c:	je     81d91f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d842:	mov    0x108(%rcx),%r13
  81d849:	shl    $0x3,%rbp
  81d84d:	mov    %r14,0x8(%rsp)
  81d852:	lea    0x78(%r14),%rdi
  81d856:	mov    %rdx,0x18(%rsp)
  81d85b:	lea    0x8(%rdx),%rax
  81d85f:	mov    %rax,0x20(%rsp)
  81d864:	xor    %ebx,%ebx
  81d866:	lea    0x28(%rsp),%r15
  81d86b:	xor    %r12d,%r12d
  81d86e:	xchg   %ax,%ax
  81d870:	mov    0x0(%r13,%r12,1),%rax
  81d875:	movups 0x28(%rax),%xmm0
  81d879:	lea    0x38(%rsp),%rcx
  81d87e:	movups %xmm0,(%rcx)
  81d881:	movups 0x18(%rax),%xmm0
  81d885:	movups %xmm0,0x28(%rsp)
  81d88a:	movups 0x38(%rax),%xmm0
  81d88e:	movups %xmm0,0x48(%rsp)
  81d893:	mov    %rdi,%r14
  81d896:	mov    0x20(%rsp),%rsi
  81d89b:	mov    %r15,%rdx
  81d89e:	call   81cff0 <<gpui_gpu::renderer::Atlas>::insert>
  81d8a3:	test   $0x1,%al
  81d8a5:	je     81d926 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d8a7:	add    %rdx,%rbx
  81d8aa:	add    $0x8,%r12
  81d8ae:	cmp    %r12,%rbp
  81d8b1:	mov    %r14,%rdi
  81d8b4:	jne    81d870 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d8b6:	jmp    81da2e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d8bb:	cmpl   $0x1,0x150(%r14)
  81d8c3:	jne    81d8d5 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d8c5:	mov    0x138(%r14),%rax
  81d8cc:	add    0x130(%r14),%rax
  81d8d3:	je     81d90c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d8d5:	mov    %rdi,%rbx
  81d8d8:	add    $0x78,%r14
  81d8dc:	lea    0x58(%rsp),%rdi
  81d8e1:	mov    %rdx,%rsi
  81d8e4:	mov    $0x1,%edx
  81d8e9:	call   81cd20 <<gpui_gpu::renderer::Atlas>::new>
  81d8ee:	mov    %r14,%rdi
  81d8f1:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d8f6:	lea    0x58(%rsp),%rsi
  81d8fb:	mov    $0xe8,%edx
  81d900:	mov    %r14,%rdi
  81d903:	call   *0x663a27(%rip)        # e81330 <memcpy@GLIBC_2.14>
  81d909:	mov    %rbx,%rdi
  81d90c:	movq   $0x0,0x8(%rdi)
  81d914:	movl   $0xffffffff,(%rdi)
  81d91a:	jmp    81da3d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d91f:	xor    %ebx,%ebx
  81d921:	jmp    81da2e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d926:	mov    0x8(%rsp),%rax
  81d92b:	mov    0x150(%rax),%eax
  81d931:	cmp    $0x81,%eax
  81d936:	mov    $0x80,%edx
  81d93b:	cmovae %eax,%edx
  81d93e:	add    %edx,%edx
  81d940:	cmp    $0x800,%edx
  81d946:	mov    $0x800,%eax
  81d94b:	cmovae %eax,%edx
  81d94e:	lea    0x140(%rsp),%r12
  81d956:	mov    %r12,%rdi
  81d959:	mov    0x18(%rsp),%rsi
  81d95e:	mov    %edx,0x8(%rsp)
  81d962:	call   81cd20 <<gpui_gpu::renderer::Atlas>::new>
  81d967:	xor    %r15d,%r15d
  81d96a:	nopw   0x0(%rax,%rax,1)
  81d970:	mov    0x0(%r13,%r15,1),%rax
  81d975:	movups 0x28(%rax),%xmm0
  81d979:	lea    0x68(%rsp),%rcx
  81d97e:	movups %xmm0,(%rcx)
  81d981:	movups 0x18(%rax),%xmm0
  81d985:	movups %xmm0,0x58(%rsp)
  81d98a:	movups 0x38(%rax),%xmm0
  81d98e:	movups %xmm0,0x78(%rsp)
  81d993:	mov    %r12,%rdi
  81d996:	mov    0x20(%rsp),%rsi
  81d99b:	lea    0x58(%rsp),%rdx
  81d9a0:	call   81cff0 <<gpui_gpu::renderer::Atlas>::insert>
  81d9a5:	cmp    $0x1,%rax
  81d9a9:	jne    81d9b9 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d9ab:	add    %rdx,%rbx
  81d9ae:	add    $0x8,%r15
  81d9b2:	cmp    %r15,%rbp
  81d9b5:	jne    81d970 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d9b7:	jmp    81d9fb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d9b9:	mov    0x8(%rsp),%r15d
  81d9be:	cmp    $0x800,%r15d
  81d9c5:	je     81da4f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d9cb:	mov    %r12,%rdi
  81d9ce:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9d3:	add    %r15d,%r15d
  81d9d6:	cmp    $0x800,%r15d
  81d9dd:	mov    $0x800,%eax
  81d9e2:	cmovae %eax,%r15d
  81d9e6:	mov    %r12,%rdi
  81d9e9:	mov    0x18(%rsp),%rsi
  81d9ee:	mov    %r15d,0x8(%rsp)
  81d9f3:	mov    %r15d,%edx
  81d9f6:	jmp    81d962 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81d9fb:	lea    0x58(%rsp),%rdi
  81da00:	lea    0x140(%rsp),%rsi
  81da08:	mov    $0xe8,%edx
  81da0d:	call   *0x66391d(%rip)        # e81330 <memcpy@GLIBC_2.14>
  81da13:	mov    %r14,%rdi
  81da16:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da1b:	lea    0x58(%rsp),%rsi
  81da20:	mov    $0xe8,%edx
  81da25:	mov    %r14,%rdi
  81da28:	call   *0x663902(%rip)        # e81330 <memcpy@GLIBC_2.14>
  81da2e:	mov    0x10(%rsp),%rax
  81da33:	mov    %rbx,0x8(%rax)
  81da37:	movl   $0xffffffff,(%rax)
  81da3d:	add    $0x228,%rsp
  81da44:	pop    %rbx
  81da45:	pop    %r12
  81da47:	pop    %r13
  81da49:	pop    %r14
  81da4b:	pop    %r15
  81da4d:	pop    %rbp
  81da4e:	ret
  81da4f:	mov    0x10(%rsp),%rax
  81da54:	movl   $0x7,(%rax)
  81da5a:	lea    0x140(%rsp),%rdi
  81da62:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da67:	jmp    81da3d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81da69:	jmp    81da6b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81da6b:	mov    %rax,%rbx
  81da6e:	lea    0x58(%rsp),%rsi
  81da73:	mov    $0xe8,%edx
  81da78:	mov    %r14,%rdi
  81da7b:	call   *0x6638af(%rip)        # e81330 <memcpy@GLIBC_2.14>
  81da81:	mov    %rbx,%rdi
  81da84:	call   e2dda0 <_Unwind_Resume@plt>
  81da89:	mov    %rax,%rbx
  81da8c:	lea    0x140(%rsp),%rdi
  81da94:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da99:	mov    %rbx,%rdi
  81da9c:	call   e2dda0 <_Unwind_Resume@plt>
  81daa1:	call   *0x663839(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1527 frame=952

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081dab0 <<gpui_gpu::renderer::RendererState>::new>:
  81dab0:	push   %r15
  81dab2:	push   %r14
  81dab4:	push   %r13
  81dab6:	push   %r12
  81dab8:	push   %rbx
  81dab9:	sub    $0x390,%rsp
  81dac0:	mov    %rsi,%r14
  81dac3:	mov    %rdi,%rbx
  81dac6:	lea    -0x748ecb(%rip),%rax        # d4c02 <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.6877253771164693793+0xa>
  81dacd:	mov    %rax,0xd8(%rsp)
  81dad5:	movq   $0x7,0xe0(%rsp)
  81dae1:	movq   $0x30,0xe8(%rsp)
  81daed:	movl   $0x48,0xf0(%rsp)
  81daf8:	movb   $0x0,0xf4(%rsp)
  81db00:	mov    0x663ba9(%rip),%r15        # e816b0 <_DYNAMIC+0x620>
  81db07:	lea    0x10(%rsp),%rdi
  81db0c:	lea    0xd8(%rsp),%rdx
  81db14:	call   *%r15
  81db17:	movq   $0x30,0x30(%rsp)
  81db20:	lea    -0x748f1e(%rip),%rax        # d4c09 <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.6877253771164693793+0x11>
  81db27:	mov    %rax,0xd8(%rsp)
  81db2f:	movq   $0x5,0xe0(%rsp)
  81db3b:	movq   $0x10,0xe8(%rsp)
  81db47:	movl   $0x88,0xf0(%rsp)
  81db52:	movb   $0x0,0xf4(%rsp)
  81db5a:	lea    0x38(%rsp),%rdi
  81db5f:	lea    0xd8(%rsp),%rdx
  81db67:	mov    %r14,%rsi
  81db6a:	call   *%r15
  81db6d:	movq   $0x10,0x58(%rsp)
  81db76:	lea    -0x748f6f(%rip),%rax        # d4c0e <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.6877253771164693793+0x16>
  81db7d:	mov    %rax,0xd8(%rsp)
  81db85:	movq   $0x5,0xe0(%rsp)
  81db91:	movq   $0x8,0xe8(%rsp)
  81db9d:	movl   $0x88,0xf0(%rsp)
  81dba8:	movb   $0x0,0xf4(%rsp)
  81dbb0:	lea    0x60(%rsp),%rdi
  81dbb5:	lea    0xd8(%rsp),%rdx
  81dbbd:	mov    %r14,%rsi
  81dbc0:	call   *0x663aea(%rip)        # e816b0 <_DYNAMIC+0x620>
  81dbc6:	movq   $0x8,0x80(%rsp)
  81dbd2:	lea    -0x748fc6(%rip),%rax        # d4c13 <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.6877253771164693793+0x1b>
  81dbd9:	mov    %rax,0xd8(%rsp)
  81dbe1:	movq   $0x7,0xe0(%rsp)
  81dbed:	movq   $0x4,0xe8(%rsp)
  81dbf9:	movl   $0x88,0xf0(%rsp)
  81dc04:	movb   $0x0,0xf4(%rsp)
  81dc0c:	lea    0x88(%rsp),%rdi
  81dc14:	lea    0xd8(%rsp),%rdx
  81dc1c:	mov    %r14,%rsi
  81dc1f:	call   *0x663a8b(%rip)        # e816b0 <_DYNAMIC+0x620>
  81dc25:	movq   $0x4,0xa8(%rsp)
  81dc31:	lea    -0x74901e(%rip),%rax        # d4c1a <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.6877253771164693793+0x22>
  81dc38:	mov    %rax,0xd8(%rsp)
  81dc40:	movq   $0x11,0xe0(%rsp)
  81dc4c:	movq   $0x20,0xe8(%rsp)
  81dc58:	movl   $0x88,0xf0(%rsp)
  81dc63:	movb   $0x0,0xf4(%rsp)
  81dc6b:	lea    0xb0(%rsp),%rdi
  81dc73:	lea    0xd8(%rsp),%rdx
  81dc7b:	mov    %r14,%rsi
  81dc7e:	call   *0x663a2c(%rip)        # e816b0 <_DYNAMIC+0x620>
  81dc84:	movq   $0x20,0xd0(%rsp)
  81dc90:	lea    0x2a8(%rsp),%rdi
  81dc98:	mov    %r14,%rsi
  81dc9b:	mov    $0x1,%edx
  81dca0:	call   81cd20 <<gpui_gpu::renderer::Atlas>::new>
  81dca5:	mov    0x18(%r14),%r13
  81dca9:	lock incq 0x0(%r13)
  81dcae:	jle    81dfe3 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81dcb4:	mov    %r13,0x8(%rsp)
  81dcb9:	mov    0x30(%rsp),%rax
  81dcbe:	mov    %rax,0x1e0(%rsp)
  81dcc6:	movups 0x10(%rsp),%xmm0
  81dccb:	movups 0x20(%rsp),%xmm1
  81dcd0:	movaps %xmm1,0x1d0(%rsp)
  81dcd8:	movaps %xmm0,0x1c0(%rsp)
  81dce0:	mov    0x58(%rsp),%rax
  81dce5:	mov    %rax,0x210(%rsp)
  81dced:	movups 0x38(%rsp),%xmm0
  81dcf2:	movups 0x48(%rsp),%xmm1
  81dcf7:	movaps %xmm1,0x200(%rsp)
  81dcff:	movaps %xmm0,0x1f0(%rsp)
  81dd07:	mov    0x80(%rsp),%rax
  81dd0f:	mov    %rax,0x240(%rsp)
  81dd17:	movups 0x60(%rsp),%xmm0
  81dd1c:	movups 0x70(%rsp),%xmm1
  81dd21:	movaps %xmm1,0x230(%rsp)
  81dd29:	movaps %xmm0,0x220(%rsp)
  81dd31:	mov    0xa8(%rsp),%rax
  81dd39:	mov    %rax,0x270(%rsp)
  81dd41:	movups 0x88(%rsp),%xmm0
  81dd49:	movups 0x98(%rsp),%xmm1
  81dd51:	movaps %xmm1,0x260(%rsp)
  81dd59:	movaps %xmm0,0x250(%rsp)
  81dd61:	mov    0xd0(%rsp),%rax
  81dd69:	mov    %rax,0x2a0(%rsp)
  81dd71:	movups 0xb0(%rsp),%xmm0
  81dd79:	movups 0xc0(%rsp),%xmm1
  81dd81:	movaps %xmm1,0x290(%rsp)
  81dd89:	movaps %xmm0,0x280(%rsp)
  81dd91:	lea    0xd8(%rsp),%rdi
  81dd99:	lea    0x2a8(%rsp),%rsi
  81dda1:	mov    $0xe8,%edx
  81dda6:	call   *0x663584(%rip)        # e81330 <memcpy@GLIBC_2.14>
  81ddac:	mov    %fs:0x0,%rax
  81ddb5:	lea    -0x28(%rax),%rax
  81ddbc:	mov    %rax,%r12
  81ddbf:	cmpb   $0x1,0x10(%rax)
  81ddc3:	jne    81dfc3 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81ddc9:	mov    (%r12),%r14
  81ddcd:	mov    0x8(%r12),%r15
  81ddd2:	lea    0x1(%r14),%rax
  81ddd6:	mov    %rax,(%r12)
  81ddda:	mov    %r13,0x228(%rbx)
  81dde1:	mov    0x30(%rsp),%rax
  81dde6:	mov    %rax,0x250(%rbx)
  81dded:	movups 0x10(%rsp),%xmm0
  81ddf2:	movups 0x20(%rsp),%xmm1
  81ddf7:	movups %xmm1,0x240(%rbx)
  81ddfe:	movups %xmm0,0x230(%rbx)
  81de05:	mov    0x58(%rsp),%rax
  81de0a:	mov    %rax,0x278(%rbx)
  81de11:	movups 0x38(%rsp),%xmm0
  81de16:	movups 0x48(%rsp),%xmm1
  81de1b:	movups %xmm1,0x268(%rbx)
  81de22:	movups %xmm0,0x258(%rbx)
  81de29:	mov    0x80(%rsp),%rax
  81de31:	mov    %rax,0x2a0(%rbx)
  81de38:	movups 0x60(%rsp),%xmm0
  81de3d:	movups 0x70(%rsp),%xmm1
  81de42:	movups %xmm1,0x290(%rbx)
  81de49:	movups %xmm0,0x280(%rbx)
  81de50:	movups 0x88(%rsp),%xmm0
  81de58:	movups 0x98(%rsp),%xmm1
  81de60:	movups %xmm0,0x2a8(%rbx)
  81de67:	movups %xmm1,0x2b8(%rbx)
  81de6e:	mov    0xa8(%rsp),%rax
  81de76:	mov    %rax,0x2c8(%rbx)
  81de7d:	movups 0xb0(%rsp),%xmm0
  81de85:	movups 0xc0(%rsp),%xmm1
  81de8d:	movups %xmm0,0x2d0(%rbx)
  81de94:	movups %xmm1,0x2e0(%rbx)
  81de9b:	mov    0xd0(%rsp),%rax
  81dea3:	mov    %rax,0x2f0(%rbx)
  81deaa:	lea    0x78(%rbx),%rdi
  81deae:	lea    0x2a8(%rsp),%rsi
  81deb6:	mov    $0xe8,%edx
  81debb:	call   *0x66346f(%rip)        # e81330 <memcpy@GLIBC_2.14>
  81dec1:	movq   $0x0,0x328(%rbx)
  81decc:	movq   $0x0,(%rbx)
  81ded3:	movq   $0x4,0x8(%rbx)
  81dedb:	xorps  %xmm0,%xmm0
  81dede:	movups %xmm0,0x10(%rbx)
  81dee2:	movq   $0x4,0x20(%rbx)
  81deea:	movups %xmm0,0x28(%rbx)
  81deee:	movq   $0x4,0x38(%rbx)
  81def6:	movups %xmm0,0x40(%rbx)
  81defa:	movq   $0x4,0x50(%rbx)
  81df02:	movups %xmm0,0x58(%rbx)
  81df06:	movq   $0x4,0x68(%rbx)
  81df0e:	movq   $0x0,0x70(%rbx)
  81df16:	movups 0x611d93(%rip),%xmm1        # e2fcb0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x1f8>
  81df1d:	movups %xmm1,0x2f8(%rbx)
  81df24:	movups 0x611d95(%rip),%xmm1        # e2fcc0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x208>
  81df2b:	movups %xmm1,0x308(%rbx)
  81df32:	mov    %r14,0x318(%rbx)
  81df39:	mov    %r15,0x320(%rbx)
  81df40:	movw   $0x101,0x340(%rbx)
  81df49:	movq   $0x0,0x330(%rbx)
  81df54:	movups %xmm0,0x210(%rbx)
  81df5b:	movups %xmm0,0x200(%rbx)
  81df62:	movups %xmm0,0x1f0(%rbx)
  81df69:	movups %xmm0,0x1e0(%rbx)
  81df70:	movups %xmm0,0x1d0(%rbx)
  81df77:	movups %xmm0,0x1c0(%rbx)
  81df7e:	movups %xmm0,0x1b0(%rbx)
  81df85:	movups %xmm0,0x1a0(%rbx)
  81df8c:	movups %xmm0,0x190(%rbx)
  81df93:	movups %xmm0,0x180(%rbx)
  81df9a:	movups %xmm0,0x170(%rbx)
  81dfa1:	movups %xmm0,0x160(%rbx)
  81dfa8:	movb   $0x0,0x220(%rbx)
  81dfaf:	mov    %rbx,%rax
  81dfb2:	add    $0x390,%rsp
  81dfb9:	pop    %rbx
  81dfba:	pop    %r12
  81dfbc:	pop    %r13
  81dfbe:	pop    %r14
  81dfc0:	pop    %r15
  81dfc2:	ret
  81dfc3:	call   *0x6636ef(%rip)        # e816b8 <_DYNAMIC+0x628>
  81dfc9:	mov    %rax,%r14
  81dfcc:	mov    %rdx,%r15
  81dfcf:	mov    %rax,(%r12)
  81dfd3:	mov    %rdx,0x8(%r12)
  81dfd8:	movb   $0x1,0x10(%r12)
  81dfde:	jmp    81ddd2 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81dfe3:	ud2
  81dfe5:	mov    %rax,%rbx
  81dfe8:	lea    0xd8(%rsp),%rdi
  81dff0:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81dff5:	lea    0x280(%rsp),%rdi
  81dffd:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e002:	lea    0x250(%rsp),%rdi
  81e00a:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e00f:	lea    0x220(%rsp),%rdi
  81e017:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e01c:	lea    0x1f0(%rsp),%rdi
  81e024:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e029:	lea    0x1c0(%rsp),%rdi
  81e031:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e036:	lock decq 0x0(%r13)
  81e03b:	jne    81e099 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81e03d:	lea    0x8(%rsp),%rdi
  81e042:	call   *0x6634b0(%rip)        # e814f8 <_DYNAMIC+0x468>
  81e048:	jmp    81e099 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81e04a:	mov    %rax,%rbx
  81e04d:	lea    0xb0(%rsp),%rdi
  81e055:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e05a:	jmp    81e05f <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81e05c:	mov    %rax,%rbx
  81e05f:	lea    0x88(%rsp),%rdi
  81e067:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e06c:	jmp    81e071 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81e06e:	mov    %rax,%rbx
  81e071:	lea    0x60(%rsp),%rdi
  81e076:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e07b:	jmp    81e080 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81e07d:	mov    %rax,%rbx
  81e080:	lea    0x38(%rsp),%rdi
  81e085:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e08a:	jmp    81e08f <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81e08c:	mov    %rax,%rbx
  81e08f:	lea    0x10(%rsp),%rdi
  81e094:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e099:	mov    %rbx,%rdi
  81e09c:	call   e2dda0 <_Unwind_Resume@plt>
  81e0a1:	call   *0x663239(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9261 frame=1448

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0b0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0b0:	push   %rbp
  81e0b1:	push   %r15
  81e0b3:	push   %r14
  81e0b5:	push   %r13
  81e0b7:	push   %r12
  81e0b9:	push   %rbx
  81e0ba:	sub    $0x578,%rsp
  81e0c1:	mov    0x228(%rsi),%rax
  81e0c8:	mov    0x18(%rdx),%rbx
  81e0cc:	cmp    %rbx,%rax
  81e0cf:	je     81e0ed <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0d1:	mov    0x10(%rax),%r9
  81e0d5:	cmp    0x10(%rbx),%r9
  81e0d9:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0df:	mov    0x18(%rax),%rax
  81e0e3:	cmp    0x18(%rbx),%rax
  81e0e7:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0ed:	movupd 0x330(%rsi),%xmm0
  81e0f5:	movapd %xmm0,0x130(%rsp)
  81e0fe:	movq   $0x0,0x330(%rsi)
  81e109:	mov    0x130(%rsp),%r13
  81e111:	test   %r13,%r13
  81e114:	je     81e156 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e116:	lock decq 0x0(%r13)
  81e11b:	jne    81e156 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e11d:	lea    0x130(%rsp),%rax
  81e125:	mov    %rdi,%r14
  81e128:	mov    %rax,%rdi
  81e12b:	mov    %rsi,%r12
  81e12e:	mov    %r8,%rbp
  81e131:	mov    %rdx,%r15
  81e134:	mov    %r13,0x38(%rsp)
  81e139:	mov    %rcx,%r13
  81e13c:	call   *0x663466(%rip)        # e815a8 <_DYNAMIC+0x518>
  81e142:	mov    %r13,%rcx
  81e145:	mov    0x38(%rsp),%r13
  81e14a:	mov    %r15,%rdx
  81e14d:	mov    %rbp,%r8
  81e150:	mov    %r12,%rsi
  81e153:	mov    %r14,%rdi
  81e156:	mov    0x228(%rsi),%rax
  81e15d:	cmp    %rbx,%rax
  81e160:	je     81e17e <<gpui_gpu::renderer::RendererState>::render+0xce>
  81e162:	mov    0x10(%rax),%r9
  81e166:	cmp    0x10(%rbx),%r9
  81e16a:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e170:	mov    0x18(%rax),%rax
  81e174:	cmp    0x18(%rbx),%rax
  81e178:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e17e:	lea    0x330(%rsi),%rax
  81e185:	mov    %rax,0xe8(%rsp)
  81e18d:	mov    (%rax),%rax
  81e190:	test   %rax,%rax
  81e193:	je     81e1cc <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e195:	lock decq (%rax)
  81e199:	jne    81e1cc <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e19b:	mov    %rdi,%r14
  81e19e:	lea    0x330(%rsi),%rdi
  81e1a5:	mov    %rsi,%r12
  81e1a8:	mov    %r8,%rbp
  81e1ab:	mov    %rdx,%r15
  81e1ae:	mov    %r13,%rbx
  81e1b1:	mov    %rcx,%r13
  81e1b4:	call   *0x6633ee(%rip)        # e815a8 <_DYNAMIC+0x518>
  81e1ba:	mov    %r13,%rcx
  81e1bd:	mov    %rbx,%r13
  81e1c0:	mov    %r15,%rdx
  81e1c3:	mov    %rbp,%r8
  81e1c6:	mov    %r12,%rsi
  81e1c9:	mov    %r14,%rdi
  81e1cc:	movq   $0x0,0x330(%rsi)
  81e1d7:	mov    (%rcx),%ebp
  81e1d9:	mov    0x8(%rcx),%r9d
  81e1dd:	movzbl 0xd(%rcx),%eax
  81e1e1:	test   %r9d,%r9d
  81e1e4:	sets   %r10b
  81e1e8:	and    $0x7fffffff,%r9d
  81e1ef:	lea    -0x800000(%r9),%r11d
  81e1f6:	cmp    $0x7f000000,%r11d
  81e1fd:	setb   %r11b
  81e201:	and    %r10b,%r11b
  81e204:	lea    -0x1(%r9),%r14d
  81e208:	cmp    $0x7fffff,%r14d
  81e20f:	setb   %r14b
  81e213:	and    %r10b,%r14b
  81e216:	test   %r9d,%r9d
  81e219:	sete   %r10b
  81e21d:	cmp    $0x7f800000,%r9d
  81e224:	sete   %r15b
  81e228:	or     %r10b,%r15b
  81e22b:	cmp    $0x7f800001,%r9d
  81e232:	setge  %r9b
  81e236:	or     %r15b,%r9b
  81e239:	or     %r14b,%r9b
  81e23c:	test   %ebp,%ebp
  81e23e:	setne  %r10b
  81e242:	and    %al,%r10b
  81e245:	or     %r11b,%r10b
  81e248:	or     %r9b,%r10b
  81e24b:	test   $0x1,%r10b
  81e24f:	je     81e274 <<gpui_gpu::renderer::RendererState>::render+0x1c4>
  81e251:	movl   $0x3,(%rdi)
  81e257:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e259:	movl   $0x4,(%rdi)
  81e25f:	mov    %rdi,%rax
  81e262:	add    $0x578,%rsp
  81e269:	pop    %rbx
  81e26a:	pop    %r12
  81e26c:	pop    %r13
  81e26e:	pop    %r14
  81e270:	pop    %r15
  81e272:	pop    %rbp
  81e273:	ret
  81e274:	movd   0x4(%rcx),%xmm2
  81e279:	movzbl 0xc(%rcx),%r12d
  81e27e:	test   $0x1,%bpl
  81e282:	je     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x24a>
  81e284:	movd   %xmm2,%r9d
  81e289:	test   %r9d,%r9d
  81e28c:	sets   %r10b
  81e290:	and    $0x7fffffff,%r9d
  81e297:	lea    -0x800000(%r9),%r11d
  81e29e:	cmp    $0x7f000000,%r11d
  81e2a5:	setb   %r11b
  81e2a9:	and    %r10b,%r11b
  81e2ac:	lea    -0x1(%r9),%r14d
  81e2b0:	cmp    $0x7fffff,%r14d
  81e2b7:	setb   %r14b
  81e2bb:	and    %r10b,%r14b
  81e2be:	test   %r9d,%r9d
  81e2c1:	sete   %r10b
  81e2c5:	cmp    $0x7f800000,%r9d
  81e2cc:	sete   %r15b
  81e2d0:	or     %r10b,%r15b
  81e2d3:	cmp    $0x7f800001,%r9d
  81e2da:	setge  %r9b
  81e2de:	or     %r15b,%r9b
  81e2e1:	or     %r14b,%r9b
  81e2e4:	or     %r11b,%r9b
  81e2e7:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2ed:	ucomiss -0x76f3e8(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e2f4:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2fa:	mov    0x28(%rcx),%r14d
  81e2fe:	cmp    %r14d,0x20(%r8)
  81e302:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e308:	mov    0x2c(%rcx),%r15d
  81e30c:	cmp    %r15d,0x24(%r8)
  81e310:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e316:	mov    0x38(%r8),%r10d
  81e31a:	cmp    0x20(%rdx),%r10d
  81e31e:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e324:	cmp    $0x4c,%r10d
  81e328:	jne    81e34d <<gpui_gpu::renderer::RendererState>::render+0x29d>
  81e32a:	movq   0x3c(%r8),%xmm0
  81e330:	movq   0x24(%rdx),%xmm1
  81e335:	pcmpeqd %xmm0,%xmm1
  81e339:	pshufd $0x50,%xmm1,%xmm0
  81e33e:	movmskpd %xmm0,%r9d
  81e343:	cmp    $0x3,%r9d
  81e347:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e34d:	cmp    $0x4000,%r15d
  81e354:	ja     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e356:	cmp    $0x4000,%r14d
  81e35d:	ja     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e35f:	mov    %r15,%r9
  81e362:	imul   %r14,%r9
  81e366:	add    $0xfffffffffeffffff,%r9
  81e36d:	cmp    $0xffffffffff000000,%r9
  81e374:	jb     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e376:	mov    0x10(%rcx),%rbx
  81e37a:	mov    0x80(%rbx),%r11
  81e381:	cmp    $0x10000,%r11
  81e388:	jbe    81e395 <<gpui_gpu::renderer::RendererState>::render+0x2e5>
  81e38a:	movl   $0x6,(%rdi)
  81e390:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e395:	movd   0x18(%rcx),%xmm0
  81e39a:	movd   %xmm0,%r9d
  81e39f:	and    $0x7fffffff,%r9d
  81e3a6:	cmp    $0x7f7fffff,%r9d
  81e3ad:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3b3:	pand   -0x770bcb(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3bb:	ucomiss -0x76f25e(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3c2:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3c8:	movd   0x1c(%rcx),%xmm0
  81e3cd:	movd   %xmm0,%r9d
  81e3d2:	and    $0x7fffffff,%r9d
  81e3d9:	cmp    $0x7f7fffff,%r9d
  81e3e0:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3e6:	pand   -0x770bfe(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3ee:	ucomiss -0x76f291(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3f5:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3fb:	movd   0x20(%rcx),%xmm0
  81e400:	movd   %xmm0,%r9d
  81e405:	and    $0x7fffffff,%r9d
  81e40c:	cmp    $0x7f7fffff,%r9d
  81e413:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e419:	pand   -0x770c31(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e421:	ucomiss -0x76f2c4(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e428:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e42e:	movd   0x24(%rcx),%xmm0
  81e433:	movd   %xmm0,%r9d
  81e438:	and    $0x7fffffff,%r9d
  81e43f:	cmp    $0x7f7fffff,%r9d
  81e446:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e44c:	movdqa -0x770c64(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e454:	pand   %xmm0,%xmm1
  81e458:	ucomiss -0x76f2fb(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e45f:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e465:	xorps  %xmm1,%xmm1
  81e468:	ucomiss %xmm1,%xmm0
  81e46b:	jb     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e471:	movss  -0x76f699(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e479:	ucomiss %xmm0,%xmm1
  81e47c:	jb     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e482:	movzwl 0x30(%rcx),%r9d
  81e487:	mov    %r9d,0x10(%rsp)
  81e48c:	movzwl 0x32(%rcx),%r9d
  81e491:	mov    %r9d,0x30(%rsp)
  81e496:	cmp    $0x28,%r10d
  81e49a:	mov    %r8,0x4b8(%rsp)
  81e4a2:	mov    %rcx,0x120(%rsp)
  81e4aa:	mov    %rdx,0xa0(%rsp)
  81e4b2:	mov    %r13,0x38(%rsp)
  81e4b7:	movd   %xmm2,0x2e8(%rsp)
  81e4c0:	movss  %xmm1,0xf4(%rsp)
  81e4c9:	jne    81e4d5 <<gpui_gpu::renderer::RendererState>::render+0x425>
  81e4cb:	test   $0x1,%al
  81e4cd:	je     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4d3:	jmp    81e4f0 <<gpui_gpu::renderer::RendererState>::render+0x440>
  81e4d5:	test   $0x1,%al
  81e4d7:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4dd:	ucomiss -0x76f704(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e4e4:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4ea:	jp     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4f0:	mov    %rbx,0x100(%rsp)
  81e4f8:	mov    %r11,0x108(%rsp)
  81e500:	mov    %r10d,0x2e4(%rsp)
  81e508:	mov    %rdi,0x50(%rsp)
  81e50d:	lea    0xf(%r14),%rax
  81e511:	shr    $0x4,%rax
  81e515:	lea    0xf(%r15),%ecx
  81e519:	shr    $0x4,%ecx
  81e51c:	lea    0x18(%rsi),%rdi
  81e520:	movq   $0x0,0x28(%rsi)
  81e528:	mov    %rax,0x90(%rsp)
  81e530:	imul   %eax,%ecx
  81e533:	movabs $0x4000000000000000,%rdx
  81e53d:	mov    %rdi,0x4c8(%rsp)
  81e545:	mov    %rsi,%r13
  81e548:	mov    %rcx,0x40(%rsp)
  81e54d:	mov    %rcx,%rsi
  81e550:	call   823730 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e555:	mov    %r13,0x8(%rsp)
  81e55a:	mov    0x10(%r13),%rax
  81e55e:	mov    %rax,0x348(%rsp)
  81e566:	mov    0x120(%rsp),%rdi
  81e56e:	call   *0x6630c4(%rip)        # e81638 <_DYNAMIC+0x5a8>
  81e574:	mov    %rdx,0x358(%rsp)
  81e57c:	mov    %rax,0x350(%rsp)
  81e584:	sub    %rax,%rdx
  81e587:	cmp    $0x300000,%rdx
  81e58e:	ja     81e6c5 <<gpui_gpu::renderer::RendererState>::render+0x615>
  81e594:	mov    %rdx,%rcx
  81e597:	mov    %rdx,%rax
  81e59a:	shr    $0x3,%rax
  81e59e:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81e5a8:	imul   %rax,%rdx
  81e5ac:	mov    %rdx,0x2c0(%rsp)
  81e5b4:	mov    0x350(%rsp),%rax
  81e5bc:	cmp    %rax,0x358(%rsp)
  81e5c4:	je     81e5f5 <<gpui_gpu::renderer::RendererState>::render+0x545>
  81e5c6:	mov    $0xaaaaaaab,%eax
  81e5cb:	imul   %rax,%rcx
  81e5cf:	shr    $0x2a,%rcx
  81e5d3:	mov    0x2c0(%rsp),%rdx
  81e5db:	mov    %edx,%eax
  81e5dd:	and    $0x3f,%eax
  81e5e0:	add    %rdx,%rcx
  81e5e3:	cmp    $0x1,%rax
  81e5e7:	sbb    $0xffffffffffffffff,%rcx
  81e5eb:	inc    %rcx
  81e5ee:	mov    %rcx,0x20(%rsp)
  81e5f3:	jmp    81e5fe <<gpui_gpu::renderer::RendererState>::render+0x54e>
  81e5f5:	movq   $0x0,0x20(%rsp)
  81e5fe:	mov    0x100(%rsp),%rax
  81e606:	mov    0x98(%rax),%rdx
  81e60d:	add    0xb0(%rax),%rdx
  81e614:	mov    0x30(%rsp),%ecx
  81e618:	shl    $0x10,%ecx
  81e61b:	add    0x10(%rsp),%ecx
  81e61f:	mov    %rax,0x130(%rsp)
  81e627:	movq   $0x0,0x138(%rsp)
  81e633:	mov    0x108(%rsp),%rbx
  81e63b:	mov    %rbx,0x140(%rsp)
  81e643:	mov    %rdx,0x340(%rsp)
  81e64b:	mov    %rdx,0x148(%rsp)
  81e653:	mov    %ecx,0x30(%rsp)
  81e657:	mov    %ecx,0x150(%rsp)
  81e65e:	mov    0x8(%rsp),%r13
  81e663:	movzbl 0x341(%r13),%esi
  81e66b:	lea    0x130(%rsp),%rdi
  81e673:	call   81c7d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>
  81e678:	mov    %rax,0x110(%rsp)
  81e680:	mov    0x20(%rsp),%rcx
  81e685:	lea    (%rcx,%rax,4),%rcx
  81e689:	mov    %rcx,0x10(%rsp)
  81e68e:	lea    (%rcx,%rbx,2),%rax
  81e692:	xor    %edx,%edx
  81e694:	mov    %rax,0x2b8(%rsp)
  81e69c:	sub    0x348(%rsp),%rax
  81e6a4:	cmovae %rax,%rdx
  81e6a8:	mov    0x10(%r13),%rsi
  81e6ac:	mov    $0x4,%ecx
  81e6b1:	mov    $0x10,%r8d
  81e6b7:	mov    %r13,%rdi
  81e6ba:	call   824b60 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e6bf:	cmp    $0xffffffffffffffff,%rax
  81e6c3:	je     81e6d5 <<gpui_gpu::renderer::RendererState>::render+0x625>
  81e6c5:	mov    0x50(%rsp),%rdi
  81e6ca:	movl   $0x6,(%rdi)
  81e6d0:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e6d5:	pxor   %xmm0,%xmm0
  81e6d9:	movdqa %xmm0,0x130(%rsp)
  81e6e2:	lea    0x130(%rsp),%rdx
  81e6ea:	mov    0x8(%rsp),%rbx
  81e6ef:	mov    %rbx,%rdi
  81e6f2:	mov    0x108(%rsp),%rax
  81e6fa:	mov    0x10(%rsp),%rcx
  81e6ff:	lea    (%rcx,%rax,2),%rsi
  81e703:	call   823850 <<alloc::vec::Vec<[u32; 4]>>::resize>
  81e708:	movq   $0xffffffffffffffff,0x2d0(%rsp)
  81e714:	movq   $0x0,0x2d8(%rsp)
  81e720:	movq   $0xffffffffffffffff,0x230(%rsp)
  81e72c:	movq   $0x0,0x238(%rsp)
  81e738:	mov    0x10(%rbx),%rdx
  81e73c:	cmp    %rdx,0x20(%rsp)
  81e741:	ja     820438 <<gpui_gpu::renderer::RendererState>::render+0x2388>
  81e747:	mov    0x8(%rsp),%r13
  81e74c:	mov    0x8(%r13),%rdi
  81e750:	lea    0x2d0(%rsp),%r8
  81e758:	mov    0x20(%rsp),%rsi
  81e75d:	mov    0x120(%rsp),%rdx
  81e765:	mov    0x2c0(%rsp),%rcx
  81e76d:	call   824810 <gpui_gpu::renderer::slots::write_prefix>
  81e772:	lea    0x48(%r13),%rdi
  81e776:	movq   $0x0,0x58(%r13)
  81e77e:	mov    %rdi,0x4c0(%rsp)
  81e786:	mov    0x40(%rsp),%rsi
  81e78b:	xor    %edx,%edx
  81e78d:	call   823940 <<alloc::vec::Vec<u32>>::resize>
  81e792:	movq   $0x0,0x70(%r13)
  81e79a:	cmpq   $0x0,0x60(%r13)
  81e79f:	jne    81e7b0 <<gpui_gpu::renderer::RendererState>::render+0x700>
  81e7a1:	mov    0x8(%rsp),%rax
  81e7a6:	lea    0x60(%rax),%rdi
  81e7aa:	call   *0x662e90(%rip)        # e81640 <_DYNAMIC+0x5b0>
  81e7b0:	mov    0x110(%rsp),%rax
  81e7b8:	add    %rax,%rax
  81e7bb:	mov    %rax,0x110(%rsp)
  81e7c3:	mov    0x8(%rsp),%rax
  81e7c8:	mov    0x68(%rax),%rcx
  81e7cc:	pxor   %xmm0,%xmm0
  81e7d0:	movdqu %xmm0,0x10(%rcx)
  81e7d5:	movdqu %xmm0,(%rcx)
  81e7d9:	movq   $0x1,0x70(%rax)
  81e7e1:	lea    0x2f8(%rax),%rdi
  81e7e8:	call   823180 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e7ed:	mov    0x100(%rsp),%rax
  81e7f5:	mov    %rax,0x368(%rsp)
  81e7fd:	movq   $0x0,0x370(%rsp)
  81e809:	mov    0x108(%rsp),%rax
  81e811:	mov    %rax,0x378(%rsp)
  81e819:	mov    0x340(%rsp),%rax
  81e821:	mov    %rax,0x380(%rsp)
  81e829:	mov    0x30(%rsp),%eax
  81e82d:	mov    %eax,0x388(%rsp)
  81e834:	lea    0x408(%rsp),%rdi
  81e83c:	lea    0x368(%rsp),%rsi
  81e844:	call   *0x662dfe(%rip)        # e81648 <_DYNAMIC+0x5b8>
  81e84a:	mov    0x408(%rsp),%rax
  81e852:	mov    %rax,0x28(%rsp)
  81e857:	test   %rax,%rax
  81e85a:	je     81f2e6 <<gpui_gpu::renderer::RendererState>::render+0x1236>
  81e860:	movq   $0x0,0x118(%rsp)
  81e86c:	movq   $0x0,0x68(%rsp)
  81e875:	movq   $0x0,0x88(%rsp)
  81e881:	movq   $0x0,0x2a8(%rsp)
  81e88d:	movq   $0x0,0x2b0(%rsp)
  81e899:	mov    0x410(%rsp),%rbx
  81e8a1:	mov    0x418(%rsp),%r13
  81e8a9:	lea    0x420(%rsp),%rcx
  81e8b1:	movups (%rcx),%xmm0
  81e8b4:	movups 0x10(%rcx),%xmm1
  81e8b8:	movups 0x20(%rcx),%xmm2
  81e8bc:	movaps %xmm2,0x290(%rsp)
  81e8c4:	movaps %xmm1,0x280(%rsp)
  81e8cc:	movaps %xmm0,0x270(%rsp)
  81e8d4:	lea    0x450(%rsp),%rdx
  81e8dc:	movups (%rdx),%xmm0
  81e8df:	movaps %xmm0,0x330(%rsp)
  81e8e7:	movups 0x40(%rcx),%xmm0
  81e8eb:	movaps %xmm0,0x320(%rsp)
  81e8f3:	mov    0x8(%rsp),%rax
  81e8f8:	movzbl 0x341(%rax),%esi
  81e8ff:	mov    0x28(%rsp),%rax
  81e904:	mov    %rax,0x130(%rsp)
  81e90c:	mov    %rbx,0x138(%rsp)
  81e914:	mov    %r13,0x140(%rsp)
  81e91c:	movups (%rcx),%xmm0
  81e91f:	movdqu 0x10(%rcx),%xmm1
  81e924:	movdqu 0x20(%rcx),%xmm2
  81e929:	lea    0x148(%rsp),%rdi
  81e931:	movdqu %xmm2,0x20(%rdi)
  81e936:	movdqu %xmm1,0x10(%rdi)
  81e93b:	movups %xmm0,(%rdi)
  81e93e:	movups (%rdx),%xmm0
  81e941:	lea    0x178(%rsp),%rax
  81e949:	movups %xmm0,(%rax)
  81e94c:	movdqu 0x40(%rcx),%xmm0
  81e951:	movdqu %xmm0,0x40(%rdi)
  81e956:	lea    0x130(%rsp),%rdi
  81e95e:	call   8216a0 <gpui_gpu::renderer::compact_group>
  81e963:	mov    %rbx,0xa8(%rsp)
  81e96b:	mov    %r13,0xe0(%rsp)
  81e973:	lea    (%rbx,%r13,4),%rbx
  81e977:	mov    %al,0x1f(%rsp)
  81e97b:	test   %al,%al
  81e97d:	je     81eb72 <<gpui_gpu::renderer::RendererState>::render+0xac2>
  81e983:	mov    0xa8(%rsp),%rax
  81e98b:	mov    %rax,0x490(%rsp)
  81e993:	mov    %rbx,0x498(%rsp)
  81e99b:	mov    0x28(%rsp),%rax
  81e9a0:	mov    %rax,0x4a0(%rsp)
  81e9a8:	movq   $0x0,0x4a8(%rsp)
  81e9b4:	lea    0x3a0(%rsp),%rdi
  81e9bc:	lea    0x490(%rsp),%rsi
  81e9c4:	call   821d30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e9c9:	cmpb   $0xff,0x3a8(%rsp)
  81e9d1:	je     81eb80 <<gpui_gpu::renderer::RendererState>::render+0xad0>
  81e9d7:	pxor   %xmm0,%xmm0
  81e9db:	movdqa %xmm0,0x70(%rsp)
  81e9e1:	movdqa %xmm0,0x40(%rsp)
  81e9e7:	mov    0x3a0(%rsp),%rdx
  81e9ef:	add    0x88(%rsp),%rdx
  81e9f7:	lea    0x3a8(%rsp),%rcx
  81e9ff:	movups 0x38(%rcx),%xmm0
  81ea03:	lea    0x148(%rsp),%rax
  81ea0b:	movups %xmm0,0x20(%rax)
  81ea0f:	movups 0x48(%rcx),%xmm0
  81ea13:	lea    0x178(%rsp),%rsi
  81ea1b:	movups %xmm0,0x40(%rsi)
  81ea1f:	mov    0x30(%rcx),%rax
  81ea23:	mov    %rax,0x160(%rsp)
  81ea2b:	movups (%rcx),%xmm0
  81ea2e:	movups 0x10(%rcx),%xmm1
  81ea32:	movups 0x20(%rcx),%xmm2
  81ea36:	movaps %xmm2,0x150(%rsp)
  81ea3e:	movaps %xmm1,0x140(%rsp)
  81ea46:	movaps %xmm0,0x130(%rsp)
  81ea4e:	lea    0x420(%rsp),%rax
  81ea56:	movups (%rax),%xmm0
  81ea59:	movups 0x10(%rax),%xmm1
  81ea5d:	movups 0x20(%rax),%xmm2
  81ea61:	movups %xmm2,0x20(%rsi)
  81ea65:	movups %xmm1,0x10(%rsi)
  81ea69:	movups %xmm0,(%rsi)
  81ea6c:	lea    0x450(%rsp),%rcx
  81ea74:	movups (%rcx),%xmm0
  81ea77:	movups %xmm0,0x30(%rsi)
  81ea7b:	movups 0x40(%rax),%xmm0
  81ea7f:	movups %xmm0,0x50(%rsi)
  81ea83:	lea    0x240(%rsp),%rdi
  81ea8b:	lea    0x130(%rsp),%rsi
  81ea93:	mov    %r14d,%ecx
  81ea96:	mov    %r15d,%r8d
  81ea99:	call   8216f0 <gpui_gpu::renderer::validate_draw>
  81ea9e:	mov    0x240(%rsp),%ecx
  81eaa5:	mov    0x244(%rsp),%rax
  81eaad:	cmp    $0xffffffff,%ecx
  81eab0:	jne    81f3c2 <<gpui_gpu::renderer::RendererState>::render+0x1312>
  81eab6:	mov    %eax,%ecx
  81eab8:	shr    $0x20,%rax
  81eabc:	movd   %ecx,%xmm0
  81eac0:	movaps 0x70(%rsp),%xmm2
  81eac5:	movaps %xmm2,%xmm1
  81eac8:	maxss  %xmm0,%xmm1
  81eacc:	movaps %xmm1,%xmm3
  81eacf:	cmpunordss %xmm1,%xmm3
  81ead4:	movaps %xmm3,%xmm0
  81ead7:	andnps %xmm1,%xmm0
  81eada:	andps  %xmm2,%xmm3
  81eadd:	orps   %xmm0,%xmm3
  81eae0:	movaps %xmm3,0xc0(%rsp)
  81eae8:	movd   %eax,%xmm0
  81eaec:	movaps 0x40(%rsp),%xmm2
  81eaf1:	movaps %xmm2,%xmm1
  81eaf4:	maxss  %xmm0,%xmm1
  81eaf8:	movaps %xmm1,%xmm3
  81eafb:	cmpunordss %xmm1,%xmm3
  81eb00:	movaps %xmm3,%xmm0
  81eb03:	andnps %xmm1,%xmm0
  81eb06:	andps  %xmm2,%xmm3
  81eb09:	orps   %xmm0,%xmm3
  81eb0c:	movaps %xmm3,0xb0(%rsp)
  81eb14:	lea    0x3a0(%rsp),%rdi
  81eb1c:	lea    0x490(%rsp),%rsi
  81eb24:	call   821d30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81eb29:	cmpb   $0xff,0x3a8(%rsp)
  81eb31:	movdqa 0xc0(%rsp),%xmm1
  81eb3a:	movdqa %xmm1,0x70(%rsp)
  81eb40:	movdqa 0xb0(%rsp),%xmm2
  81eb49:	movdqa %xmm2,0x40(%rsp)
  81eb4f:	jne    81e9e7 <<gpui_gpu::renderer::RendererState>::render+0x937>
  81eb55:	movdqa %xmm1,%xmm0
  81eb59:	movd   %xmm0,%ecx
  81eb5d:	movd   %xmm2,%eax
  81eb61:	shl    $0x20,%rax
  81eb65:	or     %rax,%rcx
  81eb68:	mov    %rcx,0xf8(%rsp)
  81eb70:	jmp    81eb8c <<gpui_gpu::renderer::RendererState>::render+0xadc>
  81eb72:	movq   $0x0,0xf8(%rsp)
  81eb7e:	jmp    81eba4 <<gpui_gpu::renderer::RendererState>::render+0xaf4>
  81eb80:	movq   $0x0,0xf8(%rsp)
  81eb8c:	incq   0x2a8(%rsp)
  81eb94:	mov    0xe0(%rsp),%rax
  81eb9c:	add    %rax,0x2b0(%rsp)
  81eba4:	mov    0xa8(%rsp),%rax
  81ebac:	mov    %rax,0x240(%rsp)
  81ebb4:	mov    %rbx,0x248(%rsp)
  81ebbc:	mov    0x28(%rsp),%rax
  81ebc1:	mov    %rax,0x250(%rsp)
  81ebc9:	movq   $0x0,0x258(%rsp)
  81ebd5:	lea    0x3a0(%rsp),%rdi
  81ebdd:	lea    0x240(%rsp),%rsi
  81ebe5:	call   821d30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ebea:	movzbl 0x3a8(%rsp),%eax
  81ebf2:	cmp    $0xff,%al
  81ebf4:	je     81f2b8 <<gpui_gpu::renderer::RendererState>::render+0x1208>
  81ebfa:	mov    %eax,%r8d
  81ebfd:	mov    0x10(%rsp),%rax
  81ec02:	lea    0x8(,%rax,8),%rax
  81ec0a:	mov    %rax,0x128(%rsp)
  81ec12:	mov    0x20(%rsp),%rax
  81ec17:	mov    %rax,0x80(%rsp)
  81ec1f:	mov    0x3a0(%rsp),%rax
  81ec27:	movups 0x3e0(%rsp),%xmm3
  81ec2f:	lea    0x3a8(%rsp),%rsi
  81ec37:	movups 0x48(%rsi),%xmm0
  81ec3b:	lea    0x518(%rsp),%rdi
  81ec43:	movups %xmm0,0x40(%rdi)
  81ec47:	mov    0x1(%rsi),%ecx
  81ec4a:	mov    0x4(%rsi),%edx
  81ec4d:	mov    %edx,-0x44(%rdi)
  81ec50:	mov    %ecx,-0x47(%rdi)
  81ec53:	mov    0x3b0(%rsp),%rdx
  81ec5b:	mov    0x30(%rsi),%rcx
  81ec5f:	mov    %rcx,-0x18(%rdi)
  81ec63:	movups 0x10(%rsi),%xmm0
  81ec67:	movups 0x20(%rsi),%xmm1
  81ec6b:	movups %xmm1,-0x28(%rdi)
  81ec6f:	movups %xmm0,-0x38(%rdi)
  81ec73:	movaps 0x270(%rsp),%xmm0
  81ec7b:	movaps 0x280(%rsp),%xmm1
  81ec83:	movaps 0x290(%rsp),%xmm2
  81ec8b:	movups %xmm2,0x20(%rdi)
  81ec8f:	movups %xmm1,0x10(%rdi)
  81ec93:	movups %xmm0,(%rdi)
  81ec96:	movaps 0x330(%rsp),%xmm0
  81ec9e:	movups %xmm0,0x30(%rdi)
  81eca2:	movaps 0x320(%rsp),%xmm0
  81ecaa:	movups %xmm0,0x50(%rdi)
  81ecae:	movaps %xmm3,0xc0(%rsp)
  81ecb6:	movups %xmm3,0x508(%rsp)
  81ecbe:	mov    %r8b,0x70(%rsp)
  81ecc3:	mov    %r8b,0x4d0(%rsp)
  81eccb:	mov    %rdx,0x310(%rsp)
  81ecd3:	mov    %rdx,0x4d8(%rsp)
  81ecdb:	cmpb   $0x0,0x1f(%rsp)
  81ece0:	je     81ed28 <<gpui_gpu::renderer::RendererState>::render+0xc78>
  81ece2:	mov    0xf8(%rsp),%rcx
  81ecea:	mov    %rcx,0x40(%rsp)
  81ecef:	mov    0x20(%rsp),%rcx
  81ecf4:	mov    %rcx,0xb0(%rsp)
  81ecfc:	test   %rax,%rax
  81ecff:	je     81ed78 <<gpui_gpu::renderer::RendererState>::render+0xcc8>
  81ed01:	mov    0xf8(%rsp),%rax
  81ed09:	mov    %rax,0x40(%rsp)
  81ed0e:	mov    0x20(%rsp),%rax
  81ed13:	mov    %rax,0xb0(%rsp)
  81ed1b:	lea    0x130(%rsp),%rbx
  81ed23:	jmp    81f090 <<gpui_gpu::renderer::RendererState>::render+0xfe0>
  81ed28:	lea    0x130(%rsp),%rdi
  81ed30:	lea    0x4d0(%rsp),%rsi
  81ed38:	mov    0x88(%rsp),%rdx
  81ed40:	mov    %r14d,%ecx
  81ed43:	mov    %r15d,%r8d
  81ed46:	call   8216f0 <gpui_gpu::renderer::validate_draw>
  81ed4b:	mov    0x130(%rsp),%eax
  81ed52:	mov    0x134(%rsp),%rcx
  81ed5a:	mov    %rcx,0x40(%rsp)
  81ed5f:	cmp    $0xffffffff,%eax
  81ed62:	jne    81f450 <<gpui_gpu::renderer::RendererState>::render+0x13a0>
  81ed68:	mov    0x80(%rsp),%rax
  81ed70:	mov    %rax,0xb0(%rsp)
  81ed78:	cmpb   $0x3,0x70(%rsp)
  81ed7d:	jne    81ee12 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed83:	movss  0x4d4(%rsp),%xmm0
  81ed8c:	xorps  %xmm1,%xmm1
  81ed8f:	ucomiss %xmm1,%xmm0
  81ed92:	jne    81ed96 <<gpui_gpu::renderer::RendererState>::render+0xce6>
  81ed94:	jnp    81ee12 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed96:	movaps 0xc0(%rsp),%xmm5
  81ed9e:	movaps %xmm5,%xmm1
  81eda1:	unpckhpd %xmm5,%xmm1
  81eda5:	movss  -0x76fde1(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81edad:	mulss  %xmm4,%xmm1
  81edb1:	movaps %xmm0,%xmm2
  81edb4:	minss  %xmm1,%xmm2
  81edb8:	movaps %xmm2,%xmm1
  81edbb:	cmpunordss %xmm2,%xmm1
  81edc0:	movaps %xmm1,%xmm3
  81edc3:	andnps %xmm2,%xmm3
  81edc6:	andps  %xmm0,%xmm1
  81edc9:	orps   %xmm3,%xmm1
  81edcc:	movaps %xmm5,%xmm0
  81edcf:	shufps $0xff,%xmm5,%xmm0
  81edd3:	mulss  %xmm4,%xmm0
  81edd7:	movaps %xmm1,%xmm2
  81edda:	minss  %xmm0,%xmm2
  81edde:	movaps %xmm2,%xmm0
  81ede1:	cmpunordss %xmm2,%xmm0
  81ede6:	andps  %xmm0,%xmm1
  81ede9:	andnps %xmm2,%xmm0
  81edec:	orps   %xmm1,%xmm0
  81edef:	movd   %xmm0,%eax
  81edf3:	mov    %eax,0x260(%rsp)
  81edfa:	and    $0xff800000,%eax
  81edff:	mov    $0x7f000000,%ecx
  81ee04:	sub    %eax,%ecx
  81ee06:	mov    %ecx,0xd8(%rsp)
  81ee0d:	xorps  %xmm0,%xmm0
  81ee10:	jmp    81ee37 <<gpui_gpu::renderer::RendererState>::render+0xd87>
  81ee12:	mov    0x568(%rsp),%eax
  81ee19:	mov    %eax,0x260(%rsp)
  81ee20:	mov    0x56c(%rsp),%eax
  81ee27:	mov    %eax,0xd8(%rsp)
  81ee2e:	movsd  0x570(%rsp),%xmm0
  81ee37:	movaps %xmm0,0x300(%rsp)
  81ee3f:	movups 0x518(%rsp),%xmm0
  81ee47:	movaps %xmm0,0x470(%rsp)
  81ee4f:	movups 0x520(%rsp),%xmm0
  81ee57:	movaps %xmm0,0x390(%rsp)
  81ee5f:	movsd  0x528(%rsp),%xmm0
  81ee68:	movaps %xmm0,0x220(%rsp)
  81ee70:	movsd  0x530(%rsp),%xmm0
  81ee79:	movaps %xmm0,0x2f0(%rsp)
  81ee81:	movsd  0x538(%rsp),%xmm0
  81ee8a:	movsd  %xmm0,0x98(%rsp)
  81ee93:	movsd  0x540(%rsp),%xmm0
  81ee9c:	movsd  %xmm0,0x2c8(%rsp)
  81eea5:	movups 0x548(%rsp),%xmm0
  81eead:	movaps %xmm0,0x480(%rsp)
  81eeb5:	mov    0x28(%rsp),%rax
  81eeba:	mov    %rax,0x130(%rsp)
  81eec2:	mov    0xa8(%rsp),%rax
  81eeca:	mov    %rax,0x138(%rsp)
  81eed2:	mov    0xe0(%rsp),%rax
  81eeda:	mov    %rax,0x140(%rsp)
  81eee2:	movaps 0x270(%rsp),%xmm0
  81eeea:	movaps 0x280(%rsp),%xmm1
  81eef2:	movaps 0x290(%rsp),%xmm2
  81eefa:	lea    0x148(%rsp),%rcx
  81ef02:	movups %xmm2,0x20(%rcx)
  81ef06:	movups %xmm1,0x10(%rcx)
  81ef0a:	movups %xmm0,(%rcx)
  81ef0d:	movaps 0x330(%rsp),%xmm0
  81ef15:	lea    0x178(%rsp),%rax
  81ef1d:	movups %xmm0,(%rax)
  81ef20:	movaps 0x320(%rsp),%xmm0
  81ef28:	movups %xmm0,0x40(%rcx)
  81ef2c:	lea    0x130(%rsp),%rdi
  81ef34:	call   *0x662716(%rip)        # e81650 <_DYNAMIC+0x5c0>
  81ef3a:	test   %eax,%eax
  81ef3c:	je     81ef6a <<gpui_gpu::renderer::RendererState>::render+0xeba>
  81ef3e:	mov    0x2c0(%rsp),%rdi
  81ef46:	mov    %eax,%esi
  81ef48:	call   8247d0 <gpui_gpu::renderer::slots::color_word>
  81ef4d:	mov    %eax,0x260(%rsp)
  81ef54:	xorps  %xmm0,%xmm0
  81ef57:	movaps %xmm0,0x300(%rsp)
  81ef5f:	movl   $0x0,0xd8(%rsp)
  81ef6a:	movsd  0x2c8(%rsp),%xmm0
  81ef73:	cvtsd2ss %xmm0,%xmm0
  81ef77:	movapd 0x390(%rsp),%xmm1
  81ef80:	unpcklpd 0x2f0(%rsp),%xmm1
  81ef89:	cvtpd2ps %xmm1,%xmm1
  81ef8d:	movsd  0x98(%rsp),%xmm2
  81ef96:	cvtsd2ss %xmm2,%xmm2
  81ef9a:	movapd 0x470(%rsp),%xmm3
  81efa3:	unpcklpd 0x220(%rsp),%xmm3
  81efac:	cvtpd2ps %xmm3,%xmm3
  81efb0:	mov    0x40(%rsp),%rcx
  81efb5:	mov    %rcx,%rax
  81efb8:	shr    $0x20,%rax
  81efbc:	mov    0x8(%rsp),%rdx
  81efc1:	mov    0x8(%rdx),%rsi
  81efc5:	mov    0x10(%rdx),%rdx
  81efc9:	movlpd %xmm3,0x130(%rsp)
  81efd2:	movss  %xmm2,0x138(%rsp)
  81efdb:	mov    %ecx,0x13c(%rsp)
  81efe2:	movlpd %xmm1,0x140(%rsp)
  81efeb:	movss  %xmm0,0x148(%rsp)
  81eff4:	mov    %eax,0x14c(%rsp)
  81effb:	lea    0x2d0(%rsp),%rdi
  81f003:	mov    0x80(%rsp),%r13
  81f00b:	mov    %r13,%rcx
  81f00e:	lea    0x130(%rsp),%rbx
  81f016:	mov    %rbx,%r8
  81f019:	call   81b730 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81f01e:	mov    0x8(%rsp),%rax
  81f023:	mov    0x8(%rax),%rsi
  81f027:	mov    0x10(%rax),%rdx
  81f02b:	mov    0x110(%rsp),%rax
  81f033:	lea    0x0(%r13,%rax,1),%rcx
  81f038:	movaps 0x480(%rsp),%xmm0
  81f040:	movaps %xmm0,0x130(%rsp)
  81f048:	mov    0x260(%rsp),%eax
  81f04f:	mov    %eax,0x140(%rsp)
  81f056:	mov    0xd8(%rsp),%eax
  81f05d:	mov    %eax,0x144(%rsp)
  81f064:	movaps 0x300(%rsp),%xmm0
  81f06c:	movlps %xmm0,0x148(%rsp)
  81f074:	lea    0x2d0(%rsp),%rdi
  81f07c:	mov    %rbx,%r8
  81f07f:	call   81b730 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81f084:	add    $0x2,%r13
  81f088:	mov    %r13,0x80(%rsp)
  81f090:	cmpb   $0x2,0x70(%rsp)
  81f095:	sete   0x260(%rsp)
  81f09d:	cmpq   $0x0,0x310(%rsp)
  81f0a6:	setne  0x310(%rsp)
  81f0ae:	mov    0x28(%rsp),%rax
  81f0b3:	mov    %rax,0x130(%rsp)
  81f0bb:	mov    0xa8(%rsp),%rax
  81f0c3:	mov    %rax,0x138(%rsp)
  81f0cb:	mov    0xe0(%rsp),%rax
  81f0d3:	mov    %rax,0x140(%rsp)
  81f0db:	movaps 0x270(%rsp),%xmm0
  81f0e3:	movdqa 0x280(%rsp),%xmm1
  81f0ec:	movdqa 0x290(%rsp),%xmm2
  81f0f5:	lea    0x148(%rsp),%rcx
  81f0fd:	movdqu %xmm2,0x20(%rcx)
  81f102:	movdqu %xmm1,0x10(%rcx)
  81f107:	movups %xmm0,(%rcx)
  81f10a:	movaps 0x330(%rsp),%xmm0
  81f112:	lea    0x178(%rsp),%rax
  81f11a:	movups %xmm0,(%rax)
  81f11d:	movaps 0x320(%rsp),%xmm0
  81f125:	movups %xmm0,0x40(%rcx)
  81f129:	mov    %rbx,%rdi
  81f12c:	call   *0x66251e(%rip)        # e81650 <_DYNAMIC+0x5c0>
  81f132:	mov    %eax,0x70(%rsp)
  81f136:	mov    0x8(%rsp),%r13
  81f13b:	mov    0x8(%r13),%rsi
  81f13f:	mov    0x10(%r13),%rdx
  81f143:	movdqa 0xc0(%rsp),%xmm0
  81f14c:	movdqa %xmm0,0x130(%rsp)
  81f155:	lea    0x230(%rsp),%rdi
  81f15d:	mov    %rbx,%r8
  81f160:	mov    0x10(%rsp),%rbx
  81f165:	mov    %rbx,%rcx
  81f168:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f16d:	lea    0x1(%rbx),%rcx
  81f171:	mov    0x10(%r13),%rdx
  81f175:	cmp    %rdx,%rcx
  81f178:	jae    820462 <<gpui_gpu::renderer::RendererState>::render+0x23b2>
  81f17e:	mov    0xb0(%rsp),%rsi
  81f186:	mov    %esi,%edi
  81f188:	or     $0x80000000,%edi
  81f18e:	cmpl   $0x0,0x70(%rsp)
  81f193:	cmove  %esi,%edi
  81f196:	mov    0x8(%r13),%rsi
  81f19a:	mov    0x128(%rsp),%r13
  81f1a2:	mov    0x8(%rsi,%r13,2),%r8d
  81f1a7:	mov    %r8d,0x138(%rsp)
  81f1af:	mov    (%rsi,%r13,2),%r8
  81f1b3:	mov    %r8,0x130(%rsp)
  81f1bb:	mov    %edi,0x13c(%rsp)
  81f1c2:	lea    0x230(%rsp),%rdi
  81f1ca:	lea    0x130(%rsp),%r8
  81f1d2:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f1d7:	lea    0x130(%rsp),%rdi
  81f1df:	mov    0x8(%rsp),%rsi
  81f1e4:	lea    0x4d0(%rsp),%rdx
  81f1ec:	mov    0x40(%rsp),%rcx
  81f1f1:	mov    %rbx,0x10(%rsp)
  81f1f6:	mov    %ebx,%r8d
  81f1f9:	mov    0x88(%rsp),%rbx
  81f201:	mov    %rbx,%r9
  81f204:	push   0x118(%rsp)
  81f20b:	push   %r15
  81f20d:	push   %r14
  81f20f:	push   0xa8(%rsp)
  81f216:	call   8204e0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f21b:	add    $0x20,%rsp
  81f21f:	mov    0x130(%rsp),%eax
  81f226:	cmp    $0xffffffff,%eax
  81f229:	jne    81f420 <<gpui_gpu::renderer::RendererState>::render+0x1370>
  81f22f:	movzbl 0x260(%rsp),%ecx
  81f237:	and    0x310(%rsp),%cl
  81f23e:	mov    0x68(%rsp),%rax
  81f243:	or     %cl,%al
  81f245:	mov    %rax,0x68(%rsp)
  81f24a:	addq   $0x2,0x10(%rsp)
  81f250:	mov    0x138(%rsp),%rax
  81f258:	mov    %rax,0x118(%rsp)
  81f260:	inc    %rbx
  81f263:	mov    %rbx,0x88(%rsp)
  81f26b:	lea    0x3a0(%rsp),%rdi
  81f273:	lea    0x240(%rsp),%rsi
  81f27b:	call   821d30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81f280:	movzbl 0x3a8(%rsp),%r8d
  81f289:	add    $0x10,%r13
  81f28d:	mov    %r13,0x128(%rsp)
  81f295:	cmp    $0xff,%r8b
  81f299:	jne    81ec1f <<gpui_gpu::renderer::RendererState>::render+0xb6f>
  81f29f:	mov    0x68(%rsp),%rax
  81f2a4:	and    $0x1,%al
  81f2a6:	mov    %rax,0x68(%rsp)
  81f2ab:	mov    0x80(%rsp),%rax
  81f2b3:	mov    %rax,0x20(%rsp)
  81f2b8:	lea    0x408(%rsp),%rdi
  81f2c0:	lea    0x368(%rsp),%rsi
  81f2c8:	call   *0x66237a(%rip)        # e81648 <_DYNAMIC+0x5b8>
  81f2ce:	mov    0x408(%rsp),%rax
  81f2d6:	mov    %rax,0x28(%rsp)
  81f2db:	test   %rax,%rax
  81f2de:	jne    81e899 <<gpui_gpu::renderer::RendererState>::render+0x7e9>
  81f2e4:	jmp    81f31f <<gpui_gpu::renderer::RendererState>::render+0x126f>
  81f2e6:	movq   $0x0,0x2b0(%rsp)
  81f2f2:	movq   $0x0,0x2a8(%rsp)
  81f2fe:	movq   $0x0,0x88(%rsp)
  81f30a:	movq   $0x0,0x68(%rsp)
  81f313:	movq   $0x0,0x118(%rsp)
  81f31f:	mov    0xa0(%rsp),%rsi
  81f327:	lea    0x8(%rsi),%rdx
  81f32b:	mov    0x8(%rsp),%rax
  81f330:	lea    0x258(%rax),%rcx
  81f337:	lea    0x328(%rax),%r8
  81f33e:	mov    0x10(%rax),%r9
  81f342:	sub    $0x8,%rsp
  81f346:	lea    0x138(%rsp),%rdi
  81f34e:	mov    %rdx,0x2f8(%rsp)
  81f356:	mov    %rcx,0xa0(%rsp)
  81f35e:	mov    %r8,0x488(%rsp)
  81f366:	push   0x128(%rsp)
  81f36d:	call   823a90 <gpui_gpu::renderer::images::prepare>
  81f372:	add    $0x10,%rsp
  81f376:	mov    0x130(%rsp),%eax
  81f37d:	movzbl 0x134(%rsp),%ecx
  81f385:	mov    %cl,0x390(%rsp)
  81f38c:	cmp    $0xffffffff,%eax
  81f38f:	je     81f3e8 <<gpui_gpu::renderer::RendererState>::render+0x1338>
  81f391:	movupd 0x135(%rsp),%xmm0
  81f39a:	movups 0x140(%rsp),%xmm1
  81f3a2:	mov    0x50(%rsp),%rdi
  81f3a7:	movups %xmm1,0x10(%rdi)
  81f3ab:	movupd %xmm0,0x5(%rdi)
  81f3b0:	mov    %eax,(%rdi)
  81f3b2:	movzbl 0x390(%rsp),%eax
  81f3ba:	mov    %al,0x4(%rdi)
  81f3bd:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3c2:	mov    0x25c(%rsp),%edx
  81f3c9:	mov    0x50(%rsp),%rdi
  81f3ce:	mov    %edx,0x1c(%rdi)
  81f3d1:	movups 0x24c(%rsp),%xmm0
  81f3d9:	movups %xmm0,0xc(%rdi)
  81f3dd:	mov    %ecx,(%rdi)
  81f3df:	mov    %rax,0x4(%rdi)
  81f3e3:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3e8:	movzbl 0x68(%rsp),%r8d
  81f3ee:	and    $0x1,%r8d
  81f3f2:	lea    0x130(%rsp),%rdi
  81f3fa:	mov    0x8(%rsp),%rsi
  81f3ff:	mov    0xa0(%rsp),%rdx
  81f407:	mov    0x100(%rsp),%rcx
  81f40f:	call   81d810 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f414:	mov    0x130(%rsp),%eax
  81f41b:	cmp    $0xffffffff,%eax
  81f41e:	je     81f47b <<gpui_gpu::renderer::RendererState>::render+0x13cb>
  81f420:	mov    0x134(%rsp),%ecx
  81f427:	mov    0x138(%rsp),%rdx
  81f42f:	movupd 0x140(%rsp),%xmm0
  81f438:	mov    0x50(%rsp),%rdi
  81f43d:	movupd %xmm0,0x10(%rdi)
  81f442:	mov    %eax,(%rdi)
  81f444:	mov    %ecx,0x4(%rdi)
  81f447:	mov    %rdx,0x8(%rdi)
  81f44b:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f450:	mov    0x14c(%rsp),%ecx
  81f457:	mov    0x50(%rsp),%rdi
  81f45c:	mov    %ecx,0x1c(%rdi)
  81f45f:	movups 0x13c(%rsp),%xmm0
  81f467:	movups %xmm0,0xc(%rdi)
  81f46b:	mov    %eax,(%rdi)
  81f46d:	mov    0x40(%rsp),%rax
  81f472:	mov    %rax,0x4(%rdi)
  81f476:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f47b:	mov    0x138(%rsp),%rax
  81f483:	mov    %rax,0x2c8(%rsp)
  81f48b:	mov    0x8(%rsp),%rax
  81f490:	mov    0x28(%rax),%rax
  81f494:	movq   $0x0,0x220(%rsp)
  81f4a0:	test   %rax,%rax
  81f4a3:	je     81f548 <<gpui_gpu::renderer::RendererState>::render+0x1498>
  81f4a9:	mov    0x8(%rsp),%rcx
  81f4ae:	mov    0x20(%rcx),%rcx
  81f4b2:	shl    $0x3,%rax
  81f4b6:	xor    %edi,%edi
  81f4b8:	jmp    81f4f9 <<gpui_gpu::renderer::RendererState>::render+0x1449>
  81f4ba:	and    $0x40000000,%edx
  81f4c0:	mov    0x220(%rsp),%r9
  81f4c8:	add    %esi,%r9d
  81f4cb:	xor    %esi,%esi
  81f4cd:	test   %r8d,%r8d
  81f4d0:	setne  %sil
  81f4d4:	shl    $0x1d,%esi
  81f4d7:	or     %r9d,%edx
  81f4da:	or     %esi,%edx
  81f4dc:	mov    %r9,0x220(%rsp)
  81f4e4:	mov    %r9d,(%rcx,%rdi,8)
  81f4e8:	mov    %edx,%r9d
  81f4eb:	mov    %r9d,0x4(%rcx,%rdi,8)
  81f4f0:	inc    %rdi
  81f4f3:	add    $0xfffffffffffffff8,%rax
  81f4f7:	je     81f536 <<gpui_gpu::renderer::RendererState>::render+0x1486>
  81f4f9:	mov    0x8(%rsp),%rdx
  81f4fe:	mov    0x58(%rdx),%rsi
  81f502:	cmp    %rsi,%rdi
  81f505:	jae    820478 <<gpui_gpu::renderer::RendererState>::render+0x23c8>
  81f50b:	mov    0x4(%rcx,%rdi,8),%edx
  81f50f:	mov    %edx,%esi
  81f511:	and    $0xbfffffff,%esi
  81f517:	mov    0x8(%rsp),%r8
  81f51c:	mov    0x50(%r8),%r8
  81f520:	mov    (%r8,%rdi,4),%r8d
  81f524:	cmp    $0x1,%esi
  81f527:	jne    81f4ba <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f529:	mov    $0x80000000,%r9d
  81f52f:	test   %r8d,%r8d
  81f532:	jne    81f4eb <<gpui_gpu::renderer::RendererState>::render+0x143b>
  81f534:	jmp    81f4ba <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f536:	mov    0x220(%rsp),%rax
  81f53e:	mov    %eax,%eax
  81f540:	mov    %rax,0x220(%rsp)
  81f548:	mov    0x8(%rsp),%rax
  81f54d:	lea    0x30(%rax),%rdi
  81f551:	movq   $0x0,0x40(%rax)
  81f559:	mov    %rdi,0xd8(%rsp)
  81f561:	mov    0x220(%rsp),%rsi
  81f569:	xor    %edx,%edx
  81f56b:	call   823940 <<alloc::vec::Vec<u32>>::resize>
  81f570:	mov    0x88(%rsp),%rax
  81f578:	mov    %rax,0x360(%rsp)
  81f580:	mov    0x100(%rsp),%rax
  81f588:	mov    %rax,0x368(%rsp)
  81f590:	movq   $0x0,0x370(%rsp)
  81f59c:	mov    0x108(%rsp),%rax
  81f5a4:	mov    %rax,0x378(%rsp)
  81f5ac:	mov    0x340(%rsp),%rax
  81f5b4:	mov    %rax,0x380(%rsp)
  81f5bc:	mov    0x30(%rsp),%eax
  81f5c0:	mov    %eax,0x388(%rsp)
  81f5c7:	lea    0x408(%rsp),%rdi
  81f5cf:	lea    0x368(%rsp),%rsi
  81f5d7:	call   *0x66207b(%rip)        # e81658 <_DYNAMIC+0x5c8>
  81f5dd:	mov    0x408(%rsp),%rax
  81f5e5:	mov    %rax,0x80(%rsp)
  81f5ed:	test   %rax,%rax
  81f5f0:	je     81fb78 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f5f6:	mov    0x8(%rsp),%rax
  81f5fb:	add    $0x120,%rax
  81f601:	mov    %rax,0x470(%rsp)
  81f609:	mov    0x2b8(%rsp),%rax
  81f611:	mov    %rax,0xb0(%rsp)
  81f619:	jmp    81f64a <<gpui_gpu::renderer::RendererState>::render+0x159a>
  81f61b:	lea    0x408(%rsp),%rdi
  81f623:	lea    0x368(%rsp),%rsi
  81f62b:	call   *0x662027(%rip)        # e81658 <_DYNAMIC+0x5c8>
  81f631:	mov    0x408(%rsp),%rax
  81f639:	mov    %rax,0x80(%rsp)
  81f641:	test   %rax,%rax
  81f644:	je     81fb78 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f64a:	lea    0x420(%rsp),%rsi
  81f652:	movups (%rsi),%xmm0
  81f655:	movups 0x10(%rsi),%xmm1
  81f659:	movups 0x20(%rsi),%xmm2
  81f65d:	movaps %xmm2,0x3c0(%rsp)
  81f665:	movaps %xmm1,0x3b0(%rsp)
  81f66d:	movaps %xmm0,0x3a0(%rsp)
  81f675:	lea    0x450(%rsp),%rdx
  81f67d:	movups (%rdx),%xmm0
  81f680:	movaps %xmm0,0x320(%rsp)
  81f688:	movdqu 0x40(%rsi),%xmm0
  81f68d:	movdqa %xmm0,0x330(%rsp)
  81f696:	mov    0x410(%rsp),%rax
  81f69e:	mov    %rax,0xe0(%rsp)
  81f6a6:	mov    0x418(%rsp),%rbx
  81f6ae:	mov    0x8(%rsp),%rdi
  81f6b3:	call   81d430 <<gpui_gpu::renderer::RendererState>::correction>
  81f6b8:	mov    %eax,0x300(%rsp)
  81f6bf:	test   %rbx,%rbx
  81f6c2:	je     81f61b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f6c8:	mov    %rbx,%rcx
  81f6cb:	shl    $0x2,%rcx
  81f6cf:	mov    0x300(%rsp),%eax
  81f6d6:	shl    $0xf,%eax
  81f6d9:	mov    %eax,0x20(%rsp)
  81f6dd:	mov    0xb0(%rsp),%rax
  81f6e5:	shl    $0x4,%rax
  81f6e9:	mov    %rax,0x28(%rsp)
  81f6ee:	lea    0x138(%rsp),%rbx
  81f6f6:	lea    0x130(%rsp),%r13
  81f6fe:	jmp    81f8c7 <<gpui_gpu::renderer::RendererState>::render+0x1817>
  81f703:	mov    0x60(%rsp),%r9d
  81f708:	or     0x20(%rsp),%r9d
  81f70d:	mov    %r9d,0x60(%rsp)
  81f712:	mov    0x64(%rsp),%r8d
  81f717:	mov    %edi,0x130(%rsp)
  81f71e:	mov    %r9d,0x134(%rsp)
  81f726:	mov    %r8d,0x138(%rsp)
  81f72e:	mov    %eax,0x13c(%rsp)
  81f735:	lea    0x230(%rsp),%rdi
  81f73d:	mov    %rbx,%r8
  81f740:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f745:	add    $0xfffffffffffffffe,%r13
  81f749:	mov    %r13,0xb0(%rsp)
  81f751:	mov    %r13d,0x2ec(%rsp)
  81f759:	movaps 0x260(%rsp),%xmm0
  81f761:	movlps %xmm0,0x170(%rsp)
  81f769:	movaps 0x3a0(%rsp),%xmm0
  81f771:	movaps 0x3b0(%rsp),%xmm1
  81f779:	movaps 0x3c0(%rsp),%xmm2
  81f781:	lea    0x178(%rsp),%rax
  81f789:	movups %xmm2,0x20(%rax)
  81f78d:	movups %xmm1,0x10(%rax)
  81f791:	movups %xmm0,(%rax)
  81f794:	movaps 0x320(%rsp),%xmm0
  81f79c:	movups %xmm0,0x30(%rax)
  81f7a0:	movaps 0x490(%rsp),%xmm0
  81f7a8:	movups %xmm0,0x40(%rax)
  81f7ac:	movaps 0x330(%rsp),%xmm0
  81f7b4:	movups %xmm0,0x50(%rax)
  81f7b8:	mov    0x128(%rsp),%eax
  81f7bf:	mov    %al,0x130(%rsp)
  81f7c6:	movzbl 0x30(%rsp),%eax
  81f7cb:	mov    %al,0x131(%rsp)
  81f7d2:	movzwl 0xa8(%rsp),%eax
  81f7da:	mov    %ax,0x132(%rsp)
  81f7e2:	movaps 0xc0(%rsp),%xmm0
  81f7ea:	movss  %xmm0,0x134(%rsp)
  81f7f3:	mov    0x250(%rsp),%rax
  81f7fb:	mov    %rbx,%r13
  81f7fe:	lea    0x138(%rsp),%rbx
  81f806:	mov    %rax,0x10(%rbx)
  81f80a:	movaps 0x240(%rsp),%xmm0
  81f812:	movups %xmm0,(%rbx)
  81f815:	mov    0x10(%rsp),%rax
  81f81a:	mov    %rax,0x150(%rsp)
  81f822:	mov    0x40(%rsp),%eax
  81f826:	mov    %eax,0x158(%rsp)
  81f82d:	mov    0x70(%rsp),%eax
  81f831:	mov    %eax,0x15c(%rsp)
  81f838:	movdqa 0x310(%rsp),%xmm0
  81f841:	movdqu %xmm0,0x160(%rsp)
  81f84a:	mov    0x4c8(%rsp),%rax
  81f852:	mov    %rax,0x270(%rsp)
  81f85a:	mov    0xd8(%rsp),%rax
  81f862:	mov    %rax,0x278(%rsp)
  81f86a:	mov    0x4c0(%rsp),%rax
  81f872:	mov    %rax,0x280(%rsp)
  81f87a:	lea    0x360(%rsp),%rax
  81f882:	mov    %rax,0x288(%rsp)
  81f88a:	lea    0x2ec(%rsp),%rax
  81f892:	mov    %rax,0x290(%rsp)
  81f89a:	mov    %r13,%rdi
  81f89d:	mov    0x90(%rsp),%rsi
  81f8a5:	lea    0x270(%rsp),%rdx
  81f8ad:	call   81c560 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f8b2:	addq   $0xffffffffffffffe0,0x28(%rsp)
  81f8b8:	mov    0x68(%rsp),%rcx
  81f8bd:	add    $0xfffffffffffffffc,%rcx
  81f8c1:	je     81f61b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f8c7:	mov    0xe0(%rsp),%rax
  81f8cf:	mov    %rcx,0x68(%rsp)
  81f8d4:	mov    -0x4(%rax,%rcx,1),%edx
  81f8d8:	mov    %r13,%rdi
  81f8db:	mov    0x80(%rsp),%rsi
  81f8e3:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f8e8:	movzbl 0x130(%rsp),%ecx
  81f8f0:	movzbl 0x131(%rsp),%eax
  81f8f8:	mov    %al,0x30(%rsp)
  81f8fc:	movzwl 0x132(%rsp),%eax
  81f904:	mov    %ax,0xa8(%rsp)
  81f90c:	movss  0x134(%rsp),%xmm4
  81f915:	mov    0x10(%rbx),%rax
  81f919:	mov    %rax,0x250(%rsp)
  81f921:	movups (%rbx),%xmm0
  81f924:	movaps %xmm0,0x240(%rsp)
  81f92c:	mov    0x150(%rsp),%rax
  81f934:	mov    %rax,0x10(%rsp)
  81f939:	mov    0x158(%rsp),%eax
  81f940:	mov    %eax,0x40(%rsp)
  81f944:	mov    0x15c(%rsp),%eax
  81f94b:	mov    %eax,0x70(%rsp)
  81f94f:	movups 0x160(%rsp),%xmm0
  81f957:	movaps %xmm0,0x310(%rsp)
  81f95f:	mov    0x160(%rsp),%rax
  81f967:	movsd  0x170(%rsp),%xmm5
  81f970:	lea    0x178(%rsp),%rdx
  81f978:	movups (%rdx),%xmm0
  81f97b:	movaps %xmm0,0x490(%rsp)
  81f983:	decq   0x360(%rsp)
  81f98b:	cmp    $0x1,%ecx
  81f98e:	mov    %ecx,0x128(%rsp)
  81f995:	movaps %xmm4,0xc0(%rsp)
  81f99d:	movaps %xmm5,0x260(%rsp)
  81f9a5:	je     81fa0b <<gpui_gpu::renderer::RendererState>::render+0x195b>
  81f9a7:	cmp    $0x3,%ecx
  81f9aa:	jne    81fa87 <<gpui_gpu::renderer::RendererState>::render+0x19d7>
  81f9b0:	mov    0x480(%rsp),%rax
  81f9b8:	mov    (%rax),%rdi
  81f9bb:	test   %rdi,%rdi
  81f9be:	je     82042b <<gpui_gpu::renderer::RendererState>::render+0x237b>
  81f9c4:	movzbl 0x30(%rsp),%edx
  81f9c9:	mov    0x10(%rsp),%rsi
  81f9ce:	call   823630 <<gpui_gpu::renderer::images::Images>::metadata>
  81f9d3:	mov    %eax,%ecx
  81f9d5:	shr    $0x20,%rax
  81f9d9:	mov    %eax,%edx
  81f9db:	or     $0x10,%edx
  81f9de:	xorps  %xmm0,%xmm0
  81f9e1:	movaps 0xc0(%rsp),%xmm1
  81f9e9:	ucomiss %xmm0,%xmm1
  81f9ec:	cmovne %edx,%eax
  81f9ef:	cmovp  %edx,%eax
  81f9f2:	mov    0x70(%rsp),%edx
  81f9f6:	shl    $0x10,%edx
  81f9f9:	or     0x40(%rsp),%edx
  81f9fd:	mov    %ecx,0x5c(%rsp)
  81fa01:	mov    %eax,0x60(%rsp)
  81fa05:	mov    %edx,0x64(%rsp)
  81fa09:	jmp    81fa7a <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  81fa0b:	movaps %xmm5,%xmm0
  81fa0e:	movss  -0x770a4a(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81fa16:	mulss  %xmm3,%xmm0
  81fa1a:	movaps %xmm4,%xmm1
  81fa1d:	minss  %xmm0,%xmm1
  81fa21:	movaps %xmm1,%xmm0
  81fa24:	cmpunordss %xmm1,%xmm0
  81fa29:	movaps %xmm0,%xmm2
  81fa2c:	andnps %xmm1,%xmm2
  81fa2f:	andps  %xmm4,%xmm0
  81fa32:	orps   %xmm2,%xmm0
  81fa35:	movaps %xmm5,%xmm1
  81fa38:	shufps $0x55,%xmm5,%xmm1
  81fa3c:	mulss  %xmm3,%xmm1
  81fa40:	movaps %xmm0,%xmm2
  81fa43:	minss  %xmm1,%xmm2
  81fa47:	movaps %xmm2,%xmm1
  81fa4a:	cmpunordss %xmm2,%xmm1
  81fa4f:	andps  %xmm1,%xmm0
  81fa52:	andnps %xmm2,%xmm1
  81fa55:	orps   %xmm0,%xmm1
  81fa58:	movd   %xmm1,%eax
  81fa5c:	and    $0xff800000,%eax
  81fa61:	mov    $0x7f000000,%ecx
  81fa66:	sub    %eax,%ecx
  81fa68:	movl   $0x40000000,0x5c(%rsp)
  81fa70:	movss  %xmm1,0x60(%rsp)
  81fa76:	mov    %ecx,0x64(%rsp)
  81fa7a:	lea    0x130(%rsp),%rbx
  81fa82:	jmp    81fb21 <<gpui_gpu::renderer::RendererState>::render+0x1a71>
  81fa87:	cmp    $0x2,%cl
  81fa8a:	jne    81fad9 <<gpui_gpu::renderer::RendererState>::render+0x1a29>
  81fa8c:	mov    0x250(%rsp),%rcx
  81fa94:	mov    %rcx,0x140(%rsp)
  81fa9c:	movaps 0x240(%rsp),%xmm0
  81faa4:	movaps %xmm0,0x130(%rsp)
  81faac:	mov    0x10(%rsp),%rcx
  81fab1:	mov    %rcx,0x148(%rsp)
  81fab9:	mov    0x40(%rsp),%ecx
  81fabd:	mov    %ecx,0x150(%rsp)
  81fac4:	mov    0x70(%rsp),%ecx
  81fac8:	mov    %ecx,0x154(%rsp)
  81facf:	mov    %rax,0x158(%rsp)
  81fad7:	jmp    81fae5 <<gpui_gpu::renderer::RendererState>::render+0x1a35>
  81fad9:	movq   $0x0,0x130(%rsp)
  81fae5:	movl   $0x0,0x278(%rsp)
  81faf0:	movq   $0x0,0x270(%rsp)
  81fafc:	lea    0x5c(%rsp),%rdi
  81fb01:	lea    0x130(%rsp),%rbx
  81fb09:	mov    %rbx,%rsi
  81fb0c:	lea    0x270(%rsp),%rdx
  81fb14:	mov    0x470(%rsp),%rcx
  81fb1c:	call   81b570 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fb21:	mov    0xb0(%rsp),%r13
  81fb29:	lea    -0x1(%r13),%rcx
  81fb2d:	mov    0x8(%rsp),%rax
  81fb32:	mov    0x10(%rax),%rdx
  81fb36:	cmp    %rdx,%rcx
  81fb39:	jae    82044c <<gpui_gpu::renderer::RendererState>::render+0x239c>
  81fb3f:	mov    0x8(%rax),%rsi
  81fb43:	mov    0x28(%rsp),%rax
  81fb48:	mov    -0x4(%rsi,%rax,1),%eax
  81fb4c:	mov    0x5c(%rsp),%edi
  81fb50:	cmp    $0x40000000,%edi
  81fb56:	jne    81f703 <<gpui_gpu::renderer::RendererState>::render+0x1653>
  81fb5c:	mov    0x64(%rsp),%r8d
  81fb61:	or     0x300(%rsp),%r8d
  81fb69:	mov    %r8d,0x64(%rsp)
  81fb6e:	mov    0x60(%rsp),%r9d
  81fb73:	jmp    81f717 <<gpui_gpu::renderer::RendererState>::render+0x1667>
  81fb78:	mov    0x8(%rsp),%rax
  81fb7d:	mov    0x28(%rax),%rdi
  81fb81:	xor    %ebx,%ebx
  81fb83:	test   %rdi,%rdi
  81fb86:	je     81fc95 <<gpui_gpu::renderer::RendererState>::render+0x1be5>
  81fb8c:	mov    0x8(%rsp),%rax
  81fb91:	mov    0x20(%rax),%r8
  81fb95:	shl    $0x3,%rdi
  81fb99:	cmpl   $0x0,0x90(%rsp)
  81fba1:	je     81fe90 <<gpui_gpu::renderer::RendererState>::render+0x1de0>
  81fba7:	movq   $0x0,0x40(%rsp)
  81fbb0:	movq   $0x0,0x70(%rsp)
  81fbb9:	movq   $0x0,0x10(%rsp)
  81fbc2:	xor    %r10d,%r10d
  81fbc5:	xor    %ecx,%ecx
  81fbc7:	jmp    81fbef <<gpui_gpu::renderer::RendererState>::render+0x1b3f>
  81fbc9:	incq   0x10(%rsp)
  81fbce:	inc    %r10
  81fbd1:	cmp    0x90(%rsp),%r10
  81fbd9:	mov    $0x0,%eax
  81fbde:	cmove  %rax,%r10
  81fbe2:	inc    %rcx
  81fbe5:	add    $0xfffffffffffffff8,%rdi
  81fbe9:	je     81fcb0 <<gpui_gpu::renderer::RendererState>::render+0x1c00>
  81fbef:	mov    0x4(%r8,%rcx,8),%r11d
  81fbf4:	mov    $0x80000000,%eax
  81fbf9:	cmp    %rax,%r11
  81fbfc:	je     81fbc9 <<gpui_gpu::renderer::RendererState>::render+0x1b19>
  81fbfe:	mov    %r11d,%esi
  81fc01:	and    $0x1fffffff,%esi
  81fc07:	sub    (%r8,%rcx,8),%esi
  81fc0b:	je     81fbce <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc0d:	mov    %rcx,%rax
  81fc10:	shr    $0x20,%rax
  81fc14:	je     81fc28 <<gpui_gpu::renderer::RendererState>::render+0x1b78>
  81fc16:	mov    %rcx,%rax
  81fc19:	xor    %edx,%edx
  81fc1b:	divq   0x90(%rsp)
  81fc23:	mov    %r10,%rdx
  81fc26:	jmp    81fc33 <<gpui_gpu::renderer::RendererState>::render+0x1b83>
  81fc28:	mov    %ecx,%eax
  81fc2a:	xor    %edx,%edx
  81fc2c:	divl   0x90(%rsp)
  81fc33:	shl    $0x4,%edx
  81fc36:	shl    $0x4,%eax
  81fc39:	lea    0x10(%rdx),%r13d
  81fc3d:	cmp    %r13d,%r14d
  81fc40:	cmovb  %r14d,%r13d
  81fc44:	lea    0x10(%rax),%r9d
  81fc48:	cmp    %r9d,%r15d
  81fc4b:	cmovb  %r15d,%r9d
  81fc4f:	sub    %edx,%r13d
  81fc52:	sub    %eax,%r9d
  81fc55:	imul   %r13d,%r9d
  81fc59:	mov    %r9,%rax
  81fc5c:	shl    $0x4,%rax
  81fc60:	test   $0x40000000,%r11d
  81fc67:	cmovne %r9,%rax
  81fc6b:	shr    $0x1d,%r11d
  81fc6f:	and    $0x1,%r11d
  81fc73:	add    %rax,0x70(%rsp)
  81fc78:	imul   %r11,%r9
  81fc7c:	sub    %r11,%rsi
  81fc7f:	imul   %rax,%rsi
  81fc83:	add    0x40(%rsp),%r9
  81fc88:	add    %rsi,%r9
  81fc8b:	mov    %r9,0x40(%rsp)
  81fc90:	jmp    81fbce <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc95:	movq   $0x0,0x10(%rsp)
  81fc9e:	movq   $0x0,0x70(%rsp)
  81fca7:	movq   $0x0,0x40(%rsp)
  81fcb0:	test   $0x1,%bpl
  81fcb4:	je     81fd01 <<gpui_gpu::renderer::RendererState>::render+0x1c51>
  81fcb6:	movd   0x2e8(%rsp),%xmm0
  81fcbf:	movd   %xmm0,%eax
  81fcc3:	test   %eax,%eax
  81fcc5:	setns  %cl
  81fcc8:	mov    %eax,%edx
  81fcca:	and    $0x7fffffff,%edx
  81fcd0:	add    $0xff800000,%edx
  81fcd6:	cmp    $0x7f000000,%edx
  81fcdc:	setb   %dl
  81fcdf:	and    %cl,%dl
  81fce1:	dec    %eax
  81fce3:	cmp    $0x7fffff,%eax
  81fce8:	setb   %al
  81fceb:	or     %dl,%al
  81fced:	mov    $0x2,%ebx
  81fcf2:	movd   %xmm0,0xf4(%rsp)
  81fcfb:	je     81fe86 <<gpui_gpu::renderer::RendererState>::render+0x1dd6>
  81fd01:	mov    0x120(%rsp),%rax
  81fd09:	add    $0x18,%rax
  81fd0d:	xor    %ecx,%ecx
  81fd0f:	cmpl   $0x28,0x2e4(%rsp)
  81fd17:	sete   %cl
  81fd1a:	and    $0x1,%r12d
  81fd1e:	lea    (%r12,%rcx,4),%ecx
  81fd22:	or     %ebx,%ecx
  81fd24:	movups (%rax),%xmm0
  81fd27:	movups %xmm0,0x418(%rsp)
  81fd2f:	mov    %r14d,0x408(%rsp)
  81fd37:	mov    %r15d,0x40c(%rsp)
  81fd3f:	mov    0x90(%rsp),%rax
  81fd47:	mov    %eax,0x410(%rsp)
  81fd4e:	mov    %ecx,0x414(%rsp)
  81fd55:	movss  0xf4(%rsp),%xmm0
  81fd5e:	movss  %xmm0,0x428(%rsp)
  81fd67:	mov    0x110(%rsp),%rax
  81fd6f:	mov    %eax,0x42c(%rsp)
  81fd76:	movq   $0x0,0x430(%rsp)
  81fd82:	mov    0x8(%rsp),%rax
  81fd87:	lea    0x230(%rax),%rsi
  81fd8e:	lea    0x408(%rsp),%rcx
  81fd96:	mov    $0x30,%r8d
  81fd9c:	mov    0x2f0(%rsp),%rdi
  81fda4:	mov    %rsi,0x30(%rsp)
  81fda9:	xor    %edx,%edx
  81fdab:	call   *0x6618af(%rip)        # e81660 <_DYNAMIC+0x5d0>
  81fdb1:	mov    0x2b8(%rsp),%rbx
  81fdb9:	shl    $0x4,%rbx
  81fdbd:	mov    0x98(%rsp),%rdi
  81fdc5:	mov    0xa0(%rsp),%rsi
  81fdcd:	mov    %rbx,%rdx
  81fdd0:	call   81cc10 <<gpui_gpu::renderer::Buffer>::reserve>
  81fdd5:	cmpq   $0x0,0x38(%rsp)
  81fddb:	je     81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fddd:	mov    0x2b8(%rsp),%rcx
  81fde5:	cmp    %rcx,0x348(%rsp)
  81fded:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdef:	test   %al,%al
  81fdf1:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdf3:	testb  $0x1,0x390(%rsp)
  81fdfb:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdfd:	mov    0x2d8(%rsp),%rax
  81fe05:	mov    0x230(%rsp),%rbx
  81fe0d:	mov    0x238(%rsp),%rsi
  81fe15:	cmp    %rbx,%rax
  81fe18:	jne    81fedc <<gpui_gpu::renderer::RendererState>::render+0x1e2c>
  81fe1e:	mov    %rsi,0x2d8(%rsp)
  81fe26:	movq   $0xffffffffffffffff,0x230(%rsp)
  81fe32:	movq   $0x0,0x238(%rsp)
  81fe3e:	mov    $0xffffffffffffffff,%rbx
  81fe45:	movq   $0x0,0x38(%rsp)
  81fe4e:	jmp    81fee4 <<gpui_gpu::renderer::RendererState>::render+0x1e34>
  81fe53:	mov    0x8(%rsp),%rax
  81fe58:	mov    0x8(%rax),%rcx
  81fe5c:	mov    0x10(%rax),%r8
  81fe60:	shl    $0x4,%r8
  81fe64:	mov    0x98(%rsp),%rdi
  81fe6c:	mov    0xa0(%rsp),%rsi
  81fe74:	mov    0x2f0(%rsp),%rdx
  81fe7c:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81fe81:	jmp    81ff42 <<gpui_gpu::renderer::RendererState>::render+0x1e92>
  81fe86:	mov    0x50(%rsp),%rdi
  81fe8b:	jmp    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81fe90:	movq   $0x0,0x70(%rsp)
  81fe99:	xor    %eax,%eax
  81fe9b:	movq   $0x0,0x10(%rsp)
  81fea4:	jmp    81feb8 <<gpui_gpu::renderer::RendererState>::render+0x1e08>
  81fea6:	incq   0x10(%rsp)
  81feab:	add    $0x8,%rax
  81feaf:	cmp    %rax,%rdi
  81feb2:	je     81fca7 <<gpui_gpu::renderer::RendererState>::render+0x1bf7>
  81feb8:	mov    0x4(%r8,%rax,1),%ecx
  81febd:	mov    %ecx,%edx
  81febf:	neg    %edx
  81fec1:	jo     81fea6 <<gpui_gpu::renderer::RendererState>::render+0x1df6>
  81fec3:	and    $0x1fffffff,%ecx
  81fec9:	cmp    %ecx,(%r8,%rax,1)
  81fecd:	je     81feab <<gpui_gpu::renderer::RendererState>::render+0x1dfb>
  81fecf:	lea    0x60fe0a(%rip),%rdi        # e2fce0 <anon.7e34a6dced7fe4eb77116889a7de5f31.41.llvm.6877253771164693793>
  81fed6:	call   *0x66178c(%rip)        # e81668 <_DYNAMIC+0x5d8>
  81fedc:	mov    %rsi,0x38(%rsp)
  81fee1:	mov    %rax,%rsi
  81fee4:	mov    0x8(%rsp),%r13
  81fee9:	mov    0x8(%r13),%rdx
  81feed:	mov    0x10(%r13),%rcx
  81fef1:	mov    0x2d0(%rsp),%rdi
  81fef9:	mov    0x98(%rsp),%rbp
  81ff01:	mov    %rbp,%r8
  81ff04:	mov    0x2f0(%rsp),%r12
  81ff0c:	mov    %r12,%r9
  81ff0f:	call   81cb60 <<gpui_gpu::renderer::Changes>::upload>
  81ff14:	mov    %rax,0xc0(%rsp)
  81ff1c:	mov    0x8(%r13),%rdx
  81ff20:	mov    0x10(%r13),%rcx
  81ff24:	mov    %rbx,%rdi
  81ff27:	mov    0x38(%rsp),%rsi
  81ff2c:	mov    %rbp,%r8
  81ff2f:	mov    %r12,%r9
  81ff32:	call   81cb60 <<gpui_gpu::renderer::Changes>::upload>
  81ff37:	mov    %rax,%rbx
  81ff3a:	add    0xc0(%rsp),%rbx
  81ff42:	mov    0xa0(%rsp),%r13
  81ff4a:	lea    0x18(%r13),%rax
  81ff4e:	mov    %rax,0x38(%rsp)
  81ff53:	mov    0x8(%rsp),%rbp
  81ff58:	lea    0x280(%rbp),%rdi
  81ff5f:	mov    0x20(%rbp),%rcx
  81ff63:	mov    0x28(%rbp),%r8
  81ff67:	shl    $0x3,%r8
  81ff6b:	mov    %rdi,0xc0(%rsp)
  81ff73:	mov    %r13,%rsi
  81ff76:	mov    0x2f0(%rsp),%r12
  81ff7e:	mov    %r12,%rdx
  81ff81:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ff86:	lea    0x2a8(%rbp),%rdi
  81ff8d:	mov    0x38(%rbp),%rcx
  81ff91:	mov    0x40(%rbp),%r8
  81ff95:	shl    $0x2,%r8
  81ff99:	mov    %rdi,0xb0(%rsp)
  81ffa1:	mov    %r13,%rsi
  81ffa4:	mov    %r12,%rdx
  81ffa7:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ffac:	lea    0x2d0(%rbp),%rdi
  81ffb3:	mov    0x68(%rbp),%rcx
  81ffb7:	mov    0x70(%rbp),%r8
  81ffbb:	shl    $0x5,%r8
  81ffbf:	mov    %rdi,0x28(%rsp)
  81ffc4:	mov    %r13,%rsi
  81ffc7:	mov    %r12,%rdx
  81ffca:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ffcf:	cmpq   $0x0,0x328(%rbp)
  81ffd7:	je     81ffdd <<gpui_gpu::renderer::RendererState>::render+0x1f2d>
  81ffd9:	xor    %eax,%eax
  81ffdb:	jmp    81fff2 <<gpui_gpu::renderer::RendererState>::render+0x1f42>
  81ffdd:	mov    0x8(%rsp),%rax
  81ffe2:	mov    0x10(%rax),%rax
  81ffe6:	cmp    $0x1,%rax
  81ffea:	adc    $0x0,%rax
  81ffee:	shl    $0x4,%rax
  81fff2:	mov    0x8(%rsp),%rdi
  81fff7:	mov    0x28(%rdi),%rsi
  81fffb:	mov    0x40(%rdi),%rcx
  81ffff:	cmp    $0x1,%rsi
  820003:	adc    $0x0,%rsi
  820007:	shl    $0x3,%rsi
  82000b:	cmp    $0x1,%rcx
  82000f:	adc    $0x0,%rcx
  820013:	mov    0x70(%rdi),%rdx
  820017:	cmp    $0x1,%rdx
  82001b:	adc    $0x0,%rdx
  82001f:	add    $0xc8,%rdi
  820026:	shl    $0x2,%rcx
  82002a:	shl    $0x5,%rdx
  82002e:	movq   $0x0,0x130(%rsp)
  82003a:	mov    0x30(%rsp),%r8
  82003f:	mov    %r8,0x138(%rsp)
  820047:	movq   $0x0,0x158(%rsp)
  820053:	xorpd  %xmm0,%xmm0
  820057:	movupd %xmm0,0x140(%rsp)
  820060:	movl   $0x0,0x150(%rsp)
  82006b:	mov    0x98(%rsp),%r8
  820073:	mov    %r8,0x160(%rsp)
  82007b:	movq   $0x0,0x168(%rsp)
  820087:	mov    %rax,0x170(%rsp)
  82008f:	movl   $0x1,0x178(%rsp)
  82009a:	movq   $0x0,0x180(%rsp)
  8200a6:	mov    0xc0(%rsp),%rax
  8200ae:	mov    %rax,0x188(%rsp)
  8200b6:	movq   $0x0,0x190(%rsp)
  8200c2:	mov    %rsi,0x198(%rsp)
  8200ca:	movl   $0x2,0x1a0(%rsp)
  8200d5:	movq   $0x0,0x1a8(%rsp)
  8200e1:	mov    0xb0(%rsp),%rax
  8200e9:	mov    %rax,0x1b0(%rsp)
  8200f1:	movq   $0x0,0x1b8(%rsp)
  8200fd:	mov    %rcx,0x1c0(%rsp)
  820105:	movl   $0x3,0x1c8(%rsp)
  820110:	movq   $0x4,0x1d0(%rsp)
  82011c:	mov    %rdi,0x1d8(%rsp)
  820124:	movl   $0x4,0x1f0(%rsp)
  82012f:	movq   $0x0,0x1f8(%rsp)
  82013b:	mov    0x28(%rsp),%rax
  820140:	mov    %rax,0x200(%rsp)
  820148:	movq   $0x0,0x208(%rsp)
  820154:	mov    %rdx,0x210(%rsp)
  82015c:	movl   $0x5,0x218(%rsp)
  820167:	lea    -0x74b5ae(%rip),%rax        # d4bc0 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82016e:	mov    %rax,0x3b8(%rsp)
  820176:	movq   $0xa,0x3c0(%rsp)
  820182:	mov    0x38(%rsp),%rax
  820187:	mov    %rax,0x3a0(%rsp)
  82018f:	lea    0x130(%rsp),%rax
  820197:	mov    %rax,0x3a8(%rsp)
  82019f:	movq   $0x6,0x3b0(%rsp)
  8201ab:	lea    0x3a0(%rsp),%rsi
  8201b3:	mov    0xa0(%rsp),%r13
  8201bb:	mov    %r13,%rdi
  8201be:	call   *0x6614ac(%rip)        # e81670 <_DYNAMIC+0x5e0>
  8201c4:	mov    %rax,%rbp
  8201c7:	mov    %rax,0x270(%rsp)
  8201cf:	lea    0x270(%rsp),%rdx
  8201d7:	mov    %r13,%rdi
  8201da:	mov    0x4b8(%rsp),%rsi
  8201e2:	call   81d250 <<gpui_gpu::renderer::GpuContext>::submit>
  8201e7:	mov    %rax,0x38(%rsp)
  8201ec:	xor    %r13d,%r13d
  8201ef:	mov    0x350(%rsp),%rax
  8201f7:	cmp    %rax,0x358(%rsp)
  8201ff:	setne  %r13b
  820203:	shl    $0x1f,%r13d
  820207:	or     %r14d,%r13d
  82020a:	shl    $0x20,%r15
  82020e:	or     %r15,%r13
  820211:	mov    0xe8(%rsp),%rax
  820219:	mov    (%rax),%rax
  82021c:	test   %rax,%rax
  82021f:	je     820235 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820221:	lock decq (%rax)
  820225:	jne    820235 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820227:	mov    0xe8(%rsp),%rdi
  82022f:	call   *0x661373(%rip)        # e815a8 <_DYNAMIC+0x518>
  820235:	mov    0x8(%rsp),%rax
  82023a:	mov    %rbp,0x330(%rax)
  820241:	mov    %r13,0x338(%rax)
  820248:	mov    0x28(%rax),%rsi
  82024c:	mov    0x70(%rax),%rcx
  820250:	mov    %rcx,0xe8(%rsp)
  820258:	mov    0x278(%rax),%rdx
  82025f:	mov    0x220(%rsp),%r8
  820267:	lea    (%rbx,%r8,4),%rdi
  82026b:	lea    (%rdi,%rsi,8),%rsi
  82026f:	mov    %rcx,%rdi
  820272:	shl    $0x5,%rdi
  820276:	lea    (%rdi,%rsi,1),%rcx
  82027a:	add    $0x30,%rcx
  82027e:	mov    %rcx,0x30(%rsp)
  820283:	mov    0x150(%rax),%esi
  820289:	imul   %rsi,%rsi
  82028d:	add    0x250(%rax),%rdx
  820294:	add    0x2a0(%rax),%rdx
  82029b:	add    0x2c8(%rax),%rdx
  8202a2:	add    0x2f0(%rax),%rdx
  8202a9:	mov    0x308(%rax),%rdi
  8202b0:	add    0x310(%rax),%rdi
  8202b7:	mov    0x118(%rsp),%r11
  8202bf:	mov    %r11,%rcx
  8202c2:	sub    %r8,%rcx
  8202c5:	mov    0x88(%rsp),%rbp
  8202cd:	mov    %rbp,%r9
  8202d0:	mov    0x2b0(%rsp),%r13
  8202d8:	sub    %r13,%r9
  8202db:	mov    0x10(%rax),%r10
  8202df:	shl    $0x4,%r10
  8202e3:	mov    0x160(%rax),%rbx
  8202ea:	inc    %rbx
  8202ed:	mov    $0xffffffffffffffff,%r14
  8202f4:	cmovne %rbx,%r14
  8202f8:	mov    (%rax),%rbx
  8202fb:	shl    $0x4,%rbx
  8202ff:	mov    0x48(%rax),%r15
  820303:	add    0x30(%rax),%r15
  820307:	mov    0x18(%rax),%r12
  82030b:	lea    (%rbx,%r12,8),%rbx
  82030f:	lea    (%rbx,%r15,4),%rbx
  820313:	mov    0x60(%rax),%r15
  820317:	shl    $0x5,%r15
  82031b:	add    %rbx,%r15
  82031e:	mov    0x138(%rax),%rbx
  820325:	mov    0x130(%rax),%r12
  82032c:	mov    %r14,0x160(%rax)
  820333:	mov    %rbp,0x168(%rax)
  82033a:	lea    (%r11,%r11,1),%r14
  82033e:	mov    %r14,0x170(%rax)
  820345:	movq   $0x1,0x178(%rax)
  820350:	mov    %rbp,0x180(%rax)
  820357:	mov    %r8,0x188(%rax)
  82035e:	mov    %r11,0x190(%rax)
  820365:	mov    %rcx,0x198(%rax)
  82036c:	mov    0x10(%rsp),%rcx
  820371:	mov    %rcx,0x1a0(%rax)
  820378:	mov    0x70(%rsp),%rcx
  82037d:	mov    %rcx,0x1a8(%rax)
  820384:	mov    0x40(%rsp),%rcx
  820389:	mov    %rcx,0x1b0(%rax)
  820390:	mov    0x30(%rsp),%rcx
  820395:	mov    %rcx,0x1b8(%rax)
  82039c:	mov    %r10,0x1c0(%rax)
  8203a3:	mov    0x2a8(%rsp),%r8
  8203ab:	mov    %r8,0x1c8(%rax)
  8203b2:	mov    %r13,0x1d0(%rax)
  8203b9:	mov    %r9,0x1d8(%rax)
  8203c0:	mov    0x2c8(%rsp),%rcx
  8203c8:	mov    %rcx,0x1e0(%rax)
  8203cf:	mov    %rdx,0x1e8(%rax)
  8203d6:	mov    %rsi,0x1f0(%rax)
  8203dd:	add    %rbx,%r12
  8203e0:	mov    %rbx,0x1f8(%rax)
  8203e7:	mov    %r12,0x200(%rax)
  8203ee:	mov    %r15,0x208(%rax)
  8203f5:	mov    0xe8(%rsp),%rcx
  8203fd:	mov    %rcx,0x210(%rax)
  820404:	mov    %rdi,0x218(%rax)
  82040b:	movb   $0x0,0x220(%rax)
  820412:	mov    0x50(%rsp),%rdi
  820417:	mov    0x38(%rsp),%rax
  82041c:	mov    %rax,0x8(%rdi)
  820420:	movl   $0xffffffff,(%rdi)
  820426:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  82042b:	lea    0x60f69e(%rip),%rdi        # e2fad0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x18>
  820432:	call   *0x661240(%rip)        # e81678 <_DYNAMIC+0x5e8>
  820438:	lea    0x60f6f1(%rip),%rcx        # e2fb30 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x78>
  82043f:	xor    %edi,%edi
  820441:	mov    0x20(%rsp),%rsi
  820446:	call   *0x66118c(%rip)        # e815d8 <_DYNAMIC+0x548>
  82044c:	lea    0x60f695(%rip),%rax        # e2fae8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x30>
  820453:	mov    %rcx,%rdi
  820456:	mov    %rdx,%rsi
  820459:	mov    %rax,%rdx
  82045c:	call   *0x661126(%rip)        # e81588 <_DYNAMIC+0x4f8>
  820462:	lea    0x60f6af(%rip),%rax        # e2fb18 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x60>
  820469:	mov    %rcx,%rdi
  82046c:	mov    %rdx,%rsi
  82046f:	mov    %rax,%rdx
  820472:	call   *0x661110(%rip)        # e81588 <_DYNAMIC+0x4f8>
  820478:	lea    0x60f681(%rip),%rdx        # e2fb00 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x48>
  82047f:	call   *0x661103(%rip)        # e81588 <_DYNAMIC+0x4f8>
  820485:	mov    %rax,%r14
  820488:	mov    0x8(%rsp),%rax
  82048d:	mov    %rbp,0x330(%rax)
  820494:	mov    %r13,0x338(%rax)
  82049b:	mov    %r14,%rdi
  82049e:	call   e2dda0 <_Unwind_Resume@plt>
  8204a3:	mov    %rax,%r14
  8204a6:	lock decq 0x0(%rbp)
  8204ab:	jne    8204d5 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  8204ad:	lea    0x270(%rsp),%rdi
  8204b5:	call   *0x6610ed(%rip)        # e815a8 <_DYNAMIC+0x518>
  8204bb:	jmp    8204d5 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  8204bd:	call   *0x660e1d(%rip)        # e812e0 <_DYNAMIC+0x250>
  8204c3:	mov    %rax,%r14
  8204c6:	mov    0xe8(%rsp),%rax
  8204ce:	movq   $0x0,(%rax)
  8204d5:	mov    %r14,%rdi
  8204d8:	call   e2dda0 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4531 frame=840

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008204e0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  8204e0:	push   %rbp
  8204e1:	push   %r15
  8204e3:	push   %r14
  8204e5:	push   %r13
  8204e7:	push   %r12
  8204e9:	push   %rbx
  8204ea:	sub    $0x318,%rsp
  8204f1:	movss  0x88(%rdx),%xmm3
  8204f9:	movss  -0x7714e5(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820501:	movaps %xmm3,%xmm1
  820504:	subss  %xmm0,%xmm1
  820508:	cvttss2si %xmm1,%rax
  82050d:	cvttss2si %xmm3,%r10
  820512:	mov    %r10,%rbp
  820515:	sar    $0x3f,%rbp
  820519:	and    %rax,%rbp
  82051c:	or     %r10,%rbp
  82051f:	xor    %eax,%eax
  820521:	xorps  %xmm1,%xmm1
  820524:	ucomiss %xmm1,%xmm3
  820527:	cmovb  %rax,%rbp
  82052b:	movss  0x90(%rdx),%xmm4
  820533:	movss  -0x77151b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82053b:	ucomiss %xmm2,%xmm3
  82053e:	mov    $0xffffffffffffffff,%r14
  820545:	cmova  %r14,%rbp
  820549:	movaps %xmm4,%xmm3
  82054c:	subss  %xmm0,%xmm3
  820550:	cvttss2si %xmm3,%r10
  820555:	cvttss2si %xmm4,%r11
  82055a:	mov    %r11,%rbx
  82055d:	sar    $0x3f,%rbx
  820561:	and    %r10,%rbx
  820564:	or     %r11,%rbx
  820567:	ucomiss %xmm1,%xmm4
  82056a:	cmovb  %rax,%rbx
  82056e:	ucomiss %xmm2,%xmm4
  820571:	cmova  %r14,%rbx
  820575:	movss  0x8c(%rdx),%xmm3
  82057d:	add    %rbp,%rbx
  820580:	dec    %rbx
  820583:	shr    $0x4,%rbx
  820587:	shr    $0x4,%rbp
  82058b:	mov    %rbx,%r13
  82058e:	sub    %rbp,%r13
  820591:	inc    %r13
  820594:	movaps %xmm3,%xmm4
  820597:	subss  %xmm0,%xmm4
  82059b:	cvttss2si %xmm4,%r11
  8205a0:	cvttss2si %xmm3,%r10
  8205a5:	mov    %r10,%r15
  8205a8:	sar    $0x3f,%r15
  8205ac:	and    %r11,%r15
  8205af:	or     %r10,%r15
  8205b2:	ucomiss %xmm1,%xmm3
  8205b5:	cmovb  %rax,%r15
  8205b9:	ucomiss %xmm2,%xmm3
  8205bc:	movss  0x94(%rdx),%xmm3
  8205c4:	cmova  %r14,%r15
  8205c8:	movaps %xmm3,%xmm4
  8205cb:	subss  %xmm0,%xmm4
  8205cf:	cvttss2si %xmm4,%r12
  8205d4:	cvttss2si %xmm3,%r10
  8205d9:	mov    %r10,%r11
  8205dc:	sar    $0x3f,%r11
  8205e0:	and    %r12,%r11
  8205e3:	or     %r10,%r11
  8205e6:	ucomiss %xmm1,%xmm3
  8205e9:	cmovb  %rax,%r11
  8205ed:	ucomiss %xmm2,%xmm3
  8205f0:	cmova  %r14,%r11
  8205f4:	mov    %r15,%r14
  8205f7:	lea    (%r15,%r11,1),%r10
  8205fb:	dec    %r10
  8205fe:	shr    $0x4,%r10
  820602:	shr    $0x4,%r14
  820606:	mov    %r10,%r12
  820609:	sub    %r14,%r12
  82060c:	inc    %r12
  82060f:	imul   %r13,%r12
  820613:	mov    0x368(%rsp),%r11
  82061b:	add    %r12,%r11
  82061e:	setb   %al
  820621:	cmp    $0x400001,%r11
  820628:	setae  %r15b
  82062c:	or     %al,%r15b
  82062f:	mov    $0x6,%eax
  820634:	jne    820736 <<gpui_gpu::renderer::RendererState>::bin_draw+0x256>
  82063a:	mov    %r12,0x1e8(%rsp)
  820642:	mov    %r11,0x198(%rsp)
  82064a:	mov    %rdi,0x1a0(%rsp)
  820652:	cmpb   $0x0,(%rdx)
  820655:	sete   %al
  820658:	and    0x340(%rsi),%al
  82065e:	movl   $0x0,0x4(%rsp)
  820666:	cmp    $0x1,%al
  820668:	jne    8206f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  82066e:	movss  0xa4(%rdx),%xmm0
  820676:	ucomiss -0x77189d(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82067d:	jne    8206f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  82067f:	jp     8206f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  820681:	mov    0x98(%rdx),%edi
  820687:	test   %edi,%edi
  820689:	jns    82069b <<gpui_gpu::renderer::RendererState>::bin_draw+0x1bb>
  82068b:	and    $0x7f800000,%edi
  820691:	dec    %edi
  820693:	cmp    $0x7f7fffff,%edi
  820699:	jae    8206f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  82069b:	mov    0x9c(%rdx),%edi
  8206a1:	test   %edi,%edi
  8206a3:	jns    8206b5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d5>
  8206a5:	and    $0x7f800000,%edi
  8206ab:	dec    %edi
  8206ad:	cmp    $0x7f7ffffe,%edi
  8206b3:	ja     8206f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8206b5:	mov    0xa0(%rdx),%edi
  8206bb:	test   %edi,%edi
  8206bd:	jns    8206cf <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ef>
  8206bf:	and    $0x7f800000,%edi
  8206c5:	dec    %edi
  8206c7:	cmp    $0x7f7ffffe,%edi
  8206cd:	ja     8206f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8206cf:	movd   %xmm0,%edi
  8206d3:	test   %edi,%edi
  8206d5:	jns    8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8206d7:	and    $0x7f800000,%edi
  8206dd:	dec    %edi
  8206df:	cmp    $0x7f7ffffe,%edi
  8206e5:	ja     8206f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8206e7:	mov    $0x1,%dil
  8206ea:	mov    %edi,0x4(%rsp)
  8206ee:	jmp    8206f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8206f0:	movl   $0x0,0x4(%rsp)
  8206f8:	mov    %rcx,0xe0(%rsp)
  820700:	mov    %r8d,0xbc(%rsp)
  820708:	mov    %r9,0xa8(%rsp)
  820710:	mov    %rdx,0xe8(%rsp)
  820718:	cmp    %r14,%r10
  82071b:	jae    82074a <<gpui_gpu::renderer::RendererState>::bin_draw+0x26a>
  82071d:	mov    0x1a0(%rsp),%rdi
  820725:	mov    0x198(%rsp),%rax
  82072d:	mov    %rax,0x8(%rdi)
  820731:	mov    $0xffffffff,%eax
  820736:	mov    %eax,(%rdi)
  820738:	add    $0x318,%rsp
  82073f:	pop    %rbx
  820740:	pop    %r12
  820742:	pop    %r13
  820744:	pop    %r14
  820746:	pop    %r15
  820748:	pop    %rbp
  820749:	ret
  82074a:	cmp    %rbp,%rbx
  82074d:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  82074f:	nop
  820750:	mov    %r14,%rax
  820753:	cmp    %r10,%r14
  820756:	adc    $0x0,%r14
  82075a:	cmp    %r10,%rax
  82075d:	jae    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82075f:	cmp    %r10,%r14
  820762:	jbe    820750 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  820764:	jmp    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  820766:	mov    0x350(%rsp),%r13
  82076e:	mov    0x20(%rsi),%r15
  820772:	mov    0x28(%rsi),%r9
  820776:	test   %al,%al
  820778:	je     8215d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  82077e:	mov    0xe0(%rsp),%rax
  820786:	movd   %eax,%xmm0
  82078a:	shr    $0x20,%rax
  82078e:	mov    0xe8(%rsp),%rcx
  820796:	movss  0x78(%rcx),%xmm1
  82079b:	cvtss2sd %xmm1,%xmm12
  8207a0:	movss  0x80(%rcx),%xmm1
  8207a8:	movss  0x7c(%rcx),%xmm2
  8207ad:	xorps  %xmm3,%xmm3
  8207b0:	cvtss2sd %xmm2,%xmm3
  8207b4:	movss  0x84(%rcx),%xmm2
  8207bc:	cvtss2sd %xmm1,%xmm1
  8207c0:	addsd  %xmm12,%xmm1
  8207c5:	movsd  %xmm1,0x1d8(%rsp)
  8207ce:	xorps  %xmm1,%xmm1
  8207d1:	cvtss2sd %xmm2,%xmm1
  8207d5:	movsd  %xmm3,0x1e0(%rsp)
  8207de:	addsd  %xmm3,%xmm1
  8207e2:	movsd  %xmm1,0x1c8(%rsp)
  8207eb:	movsd  0x48(%rcx),%xmm3
  8207f0:	movsd  0x58(%rcx),%xmm4
  8207f5:	movsd  0x68(%rcx),%xmm5
  8207fa:	movss  0x38(%rcx),%xmm1
  8207ff:	movss  0x40(%rcx),%xmm2
  820804:	cvtss2sd %xmm1,%xmm1
  820808:	cvtss2sd %xmm2,%xmm2
  82080c:	movaps -0x7759e3(%rip),%xmm6        # aae30 <GCC_except_table0+0x7c>
  820813:	movaps %xmm1,0x90(%rsp)
  82081b:	andps  %xmm6,%xmm1
  82081e:	movaps %xmm1,0x80(%rsp)
  820826:	movaps %xmm2,0x60(%rsp)
  82082b:	andps  %xmm6,%xmm2
  82082e:	movaps %xmm2,0x70(%rsp)
  820833:	cvtss2sd %xmm0,%xmm0
  820837:	movsd  %xmm0,0x18(%rsp)
  82083d:	movaps %xmm3,%xmm0
  820840:	andps  %xmm6,%xmm0
  820843:	movaps %xmm0,0x290(%rsp)
  82084b:	movaps %xmm4,%xmm0
  82084e:	andps  %xmm6,%xmm0
  820851:	movaps %xmm0,0x270(%rsp)
  820859:	movaps %xmm5,%xmm0
  82085c:	andps  %xmm6,%xmm0
  82085f:	movaps %xmm0,0x130(%rsp)
  820867:	movss  0x3c(%rcx),%xmm0
  82086c:	xorps  %xmm1,%xmm1
  82086f:	cvtss2sd %xmm0,%xmm1
  820873:	movss  0x44(%rcx),%xmm0
  820878:	cvtss2sd %xmm0,%xmm0
  82087c:	movaps %xmm1,0x50(%rsp)
  820881:	andps  %xmm6,%xmm1
  820884:	movaps %xmm1,0x40(%rsp)
  820889:	movaps %xmm0,0x20(%rsp)
  82088e:	andps  %xmm6,%xmm0
  820891:	movaps %xmm0,0x30(%rsp)
  820896:	movd   %eax,%xmm0
  82089a:	cvtss2sd %xmm0,%xmm0
  82089e:	movsd  %xmm0,0x10(%rsp)
  8208a4:	movsd  0x50(%rcx),%xmm1
  8208a9:	movaps %xmm1,%xmm0
  8208ac:	andps  %xmm6,%xmm0
  8208af:	movaps %xmm0,0x210(%rsp)
  8208b7:	movsd  0x60(%rcx),%xmm2
  8208bc:	movaps %xmm2,%xmm0
  8208bf:	andps  %xmm6,%xmm0
  8208c2:	movaps %xmm0,0x1f0(%rsp)
  8208ca:	movsd  0x70(%rcx),%xmm7
  8208cf:	andps  %xmm7,%xmm6
  8208d2:	movaps %xmm6,0x100(%rsp)
  8208da:	mov    0x58(%rsi),%rax
  8208de:	mov    %rax,0xd8(%rsp)
  8208e6:	mov    0x50(%rsi),%rax
  8208ea:	mov    %rax,0x1d0(%rsp)
  8208f2:	movaps %xmm3,0x2a0(%rsp)
  8208fa:	movaps %xmm3,%xmm0
  8208fd:	movaps %xmm4,0x280(%rsp)
  820905:	movlhps %xmm4,%xmm0
  820908:	cvtpd2ps %xmm0,%xmm0
  82090c:	movaps %xmm1,0x220(%rsp)
  820914:	cvtsd2ss %xmm1,%xmm1
  820918:	cvtss2sd %xmm1,%xmm1
  82091c:	cvtps2pd %xmm0,%xmm3
  82091f:	movaps %xmm2,0x200(%rsp)
  820927:	xorps  %xmm0,%xmm0
  82092a:	cvtsd2ss %xmm2,%xmm0
  82092e:	xorps  %xmm2,%xmm2
  820931:	cvtss2sd %xmm0,%xmm2
  820935:	movaps %xmm5,0x140(%rsp)
  82093d:	xorps  %xmm0,%xmm0
  820940:	cvtsd2ss %xmm5,%xmm0
  820944:	cvtss2sd %xmm0,%xmm4
  820948:	movaps %xmm7,0xf0(%rsp)
  820950:	xorps  %xmm0,%xmm0
  820953:	cvtsd2ss %xmm7,%xmm0
  820957:	mov    0xa8(%rsp),%rax
  82095f:	inc    %eax
  820961:	mov    %rax,0xa8(%rsp)
  820969:	cvtss2sd %xmm0,%xmm0
  82096d:	movaps -0x775b44(%rip),%xmm5        # aae30 <GCC_except_table0+0x7c>
  820974:	movaps %xmm3,%xmm6
  820977:	andps  %xmm5,%xmm6
  82097a:	movaps %xmm4,0x160(%rsp)
  820982:	andps  %xmm5,%xmm4
  820985:	movaps %xmm4,0x150(%rsp)
  82098d:	movaps %xmm1,0x260(%rsp)
  820995:	andps  %xmm5,%xmm1
  820998:	movaps %xmm1,0x250(%rsp)
  8209a0:	movaps %xmm2,0x240(%rsp)
  8209a8:	andps  %xmm5,%xmm2
  8209ab:	movaps %xmm2,0x230(%rsp)
  8209b3:	movaps %xmm0,0x120(%rsp)
  8209bb:	andps  %xmm0,%xmm5
  8209be:	movaps %xmm5,0x110(%rsp)
  8209c6:	movaps %xmm3,0x2c0(%rsp)
  8209ce:	movhlps %xmm3,%xmm3
  8209d1:	movaps %xmm3,0x2f0(%rsp)
  8209d9:	mov    $0x2,%r11b
  8209dc:	xor    %edx,%edx
  8209de:	mov    %r14,%rax
  8209e1:	movaps %xmm6,0x2b0(%rsp)
  8209e9:	pshufd $0xee,%xmm6,%xmm0
  8209ee:	movdqa %xmm0,0x2e0(%rsp)
  8209f7:	movsd  %xmm12,0x8(%rsp)
  8209fe:	mov    %rbp,0x1b0(%rsp)
  820a06:	mov    %r10,0x1a8(%rsp)
  820a0e:	xchg   %ax,%ax
  820a10:	cmp    %r10,%r14
  820a13:	adc    $0x0,%rax
  820a17:	mov    %rax,0x1b8(%rsp)
  820a1f:	mov    %r14,0x1c0(%rsp)
  820a27:	imul   %r13,%r14
  820a2b:	mov    %rbp,%r10
  820a2e:	mov    0x360(%rsp),%r8d
  820a36:	mov    0x358(%rsp),%ecx
  820a3d:	jmp    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820a3f:	cmp    %r9,%r12
  820a42:	jae    821635 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820a48:	incl   0x4(%r15,%r12,8)
  820a4d:	mov    $0x1,%dl
  820a4f:	cmp    %rbx,%r10
  820a52:	jb     820c23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820a58:	jmp    821590 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820a5d:	nopl   (%rax)
  820a60:	cmp    %rbx,%r10
  820a63:	adc    $0x0,%rbp
  820a67:	lea    (%r10,%r14,1),%r12
  820a6b:	cmpb   $0x0,0x4(%rsp)
  820a70:	jne    820a87 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a7>
  820a72:	cmp    %r9,%r12
  820a75:	jae    821655 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1175>
  820a7b:	testb  $0x40,0x7(%r15,%r12,8)
  820a81:	je     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820a87:	cmpq   $0x2,0x1e8(%rsp)
  820a90:	setae  %al
  820a93:	and    %dl,%al
  820a95:	cmp    $0x1,%al
  820a97:	jne    820b72 <<gpui_gpu::renderer::RendererState>::bin_draw+0x692>
  820a9d:	cmp    $0x2,%r11b
  820aa1:	jne    820b0c <<gpui_gpu::renderer::RendererState>::bin_draw+0x62c>
  820aa3:	mov    %r10,0xb0(%rsp)
  820aab:	mov    0xe8(%rsp),%rdi
  820ab3:	mov    0xe0(%rsp),%rsi
  820abb:	mov    %r13,%rdx
  820abe:	mov    %rbp,0xc0(%rsp)
  820ac6:	mov    %rbx,%rbp
  820ac9:	mov    %r14,%rbx
  820acc:	mov    %r15,%r14
  820acf:	mov    %r9,%r15
  820ad2:	call   826410 <gpui_gpu::renderer::coverage::whole>
  820ad7:	mov    0xb0(%rsp),%r10
  820adf:	movsd  0x8(%rsp),%xmm12
  820ae6:	mov    0x360(%rsp),%r8d
  820aee:	mov    %r15,%r9
  820af1:	mov    %r14,%r15
  820af4:	mov    %rbx,%r14
  820af7:	mov    %rbp,%rbx
  820afa:	mov    0xc0(%rsp),%rbp
  820b02:	mov    0x358(%rsp),%ecx
  820b09:	mov    %eax,%r11d
  820b0c:	test   $0x1,%r11b
  820b10:	mov    $0x1,%r11b
  820b13:	je     820b6f <<gpui_gpu::renderer::RendererState>::bin_draw+0x68f>
  820b15:	cmpb   $0x0,0x4(%rsp)
  820b1a:	je     820a3f <<gpui_gpu::renderer::RendererState>::bin_draw+0x55f>
  820b20:	cmp    %r9,%r12
  820b23:	jae    821680 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11a0>
  820b29:	mov    0xbc(%rsp),%eax
  820b30:	mov    %eax,(%r15,%r12,8)
  820b34:	movl   $0x40000001,0x4(%r15,%r12,8)
  820b3d:	cmp    0xd8(%rsp),%r12
  820b45:	jae    821668 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1188>
  820b4b:	mov    0xa8(%rsp),%rax
  820b53:	mov    0x1d0(%rsp),%rdx
  820b5b:	mov    %eax,(%rdx,%r12,4)
  820b5f:	mov    $0x1,%dl
  820b61:	cmp    %rbx,%r10
  820b64:	jb     820c23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820b6a:	jmp    821590 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820b6f:	xor    %r11d,%r11d
  820b72:	test   %r13,%r13
  820b75:	je     821648 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1168>
  820b7b:	mov    %r12,%rax
  820b7e:	shr    $0x20,%rax
  820b82:	je     820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b0>
  820b84:	mov    %r12,%rax
  820b87:	xor    %edx,%edx
  820b89:	div    %r13
  820b8c:	jmp    820b98 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b8>
  820b8e:	xchg   %ax,%ax
  820b90:	mov    %r12d,%eax
  820b93:	xor    %edx,%edx
  820b95:	div    %r13d
  820b98:	shl    $0x4,%edx
  820b9b:	shl    $0x4,%eax
  820b9e:	lea    0x10(%rdx),%esi
  820ba1:	cmp    %esi,%ecx
  820ba3:	cmovb  %ecx,%esi
  820ba6:	lea    0x10(%rax),%edi
  820ba9:	cmp    %edi,%r8d
  820bac:	cmovb  %r8d,%edi
  820bb0:	xorps  %xmm2,%xmm2
  820bb3:	cvtsi2sd %edx,%xmm2
  820bb7:	mov    $0x1,%dl
  820bb9:	ucomisd %xmm2,%xmm12
  820bbe:	ja     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820bc0:	mov    %eax,%eax
  820bc2:	xorps  %xmm3,%xmm3
  820bc5:	cvtsi2sd %rax,%xmm3
  820bca:	movsd  0x1e0(%rsp),%xmm0
  820bd3:	ucomisd %xmm3,%xmm0
  820bd7:	ja     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820bd9:	xorps  %xmm0,%xmm0
  820bdc:	cvtsi2sd %esi,%xmm0
  820be0:	ucomisd 0x1d8(%rsp),%xmm0
  820be9:	ja     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820beb:	xorps  %xmm1,%xmm1
  820bee:	cvtsi2sd %edi,%xmm1
  820bf2:	ucomisd 0x1c8(%rsp),%xmm1
  820bfb:	jbe    820c34 <<gpui_gpu::renderer::RendererState>::bin_draw+0x754>
  820bfd:	nopl   (%rax)
  820c00:	cmp    %r9,%r12
  820c03:	jae    821635 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820c09:	mov    0x4(%r15,%r12,8),%eax
  820c0e:	inc    %eax
  820c10:	and    $0xbfffffff,%eax
  820c15:	mov    %eax,0x4(%r15,%r12,8)
  820c1a:	cmp    %rbx,%r10
  820c1d:	jae    821590 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820c23:	mov    %rbp,%r10
  820c26:	cmp    %rbx,%rbp
  820c29:	jbe    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820c2f:	jmp    821590 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820c34:	unpcklpd %xmm3,%xmm2
  820c38:	addpd  -0x773b00(%rip),%xmm2        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820c40:	movapd %xmm2,%xmm3
  820c44:	mulpd  0x2c0(%rsp),%xmm3
  820c4d:	movapd %xmm3,%xmm11
  820c52:	unpckhpd %xmm3,%xmm11
  820c57:	movapd %xmm3,%xmm5
  820c5b:	addsd  %xmm11,%xmm5
  820c60:	addsd  0x160(%rsp),%xmm5
  820c69:	subsd  0x90(%rsp),%xmm5
  820c72:	movapd 0x2b0(%rsp),%xmm8
  820c7c:	mulpd  %xmm2,%xmm8
  820c81:	movapd %xmm8,%xmm4
  820c86:	unpckhpd %xmm8,%xmm4
  820c8b:	movapd %xmm8,%xmm6
  820c90:	addsd  %xmm4,%xmm6
  820c94:	addsd  0x150(%rsp),%xmm6
  820c9d:	addsd  0x80(%rsp),%xmm6
  820ca6:	addsd  0x70(%rsp),%xmm6
  820cac:	addsd  -0x7713d4(%rip),%xmm6        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cb4:	mulsd  -0x77145c(%rip),%xmm6        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cbc:	addsd  0x18(%rsp),%xmm6
  820cc2:	ucomisd %xmm5,%xmm6
  820cc6:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820ccc:	movapd 0x60(%rsp),%xmm7
  820cd2:	subsd  %xmm5,%xmm7
  820cd6:	ucomisd %xmm7,%xmm6
  820cda:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820ce0:	movapd %xmm2,%xmm13
  820ce5:	unpckhpd %xmm2,%xmm13
  820cea:	movapd 0x280(%rsp),%xmm15
  820cf4:	mulsd  %xmm13,%xmm15
  820cf9:	movapd 0x270(%rsp),%xmm14
  820d03:	mulsd  %xmm13,%xmm14
  820d08:	movapd 0x2a0(%rsp),%xmm5
  820d11:	mulsd  %xmm2,%xmm5
  820d15:	movapd %xmm5,%xmm6
  820d19:	addsd  %xmm15,%xmm6
  820d1e:	addsd  0x140(%rsp),%xmm6
  820d27:	subsd  0x90(%rsp),%xmm6
  820d30:	movapd 0x290(%rsp),%xmm7
  820d39:	mulsd  %xmm2,%xmm7
  820d3d:	movapd %xmm7,%xmm9
  820d42:	addsd  %xmm14,%xmm9
  820d47:	addsd  0x130(%rsp),%xmm9
  820d51:	addsd  0x80(%rsp),%xmm9
  820d5b:	addsd  0x70(%rsp),%xmm9
  820d62:	addsd  -0x77148b(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d6b:	mulsd  -0x770f34(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d74:	ucomisd %xmm6,%xmm9
  820d79:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820d7f:	movapd 0x60(%rsp),%xmm10
  820d86:	subsd  %xmm6,%xmm10
  820d8b:	ucomisd %xmm10,%xmm9
  820d90:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820d96:	movapd %xmm13,%xmm9
  820d9b:	mulsd  0x240(%rsp),%xmm9
  820da5:	movapd %xmm13,%xmm12
  820daa:	mulsd  0x230(%rsp),%xmm12
  820db4:	movapd %xmm2,%xmm10
  820db9:	mulsd  0x260(%rsp),%xmm10
  820dc3:	movapd %xmm10,%xmm6
  820dc8:	movapd %xmm9,0xc0(%rsp)
  820dd2:	addsd  %xmm9,%xmm6
  820dd7:	addsd  0x120(%rsp),%xmm6
  820de0:	subsd  0x50(%rsp),%xmm6
  820de6:	movapd %xmm2,%xmm9
  820deb:	mulsd  0x250(%rsp),%xmm9
  820df5:	movsd  %xmm9,0xb0(%rsp)
  820dff:	addsd  %xmm12,%xmm9
  820e04:	addsd  0x110(%rsp),%xmm9
  820e0e:	addsd  0x40(%rsp),%xmm9
  820e15:	addsd  0x30(%rsp),%xmm9
  820e1c:	addsd  -0x771545(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e25:	mulsd  -0x7715ce(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e2e:	addsd  0x10(%rsp),%xmm9
  820e35:	ucomisd %xmm6,%xmm9
  820e3a:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820e40:	movsd  %xmm10,0x190(%rsp)
  820e4a:	movapd 0x20(%rsp),%xmm10
  820e51:	subsd  %xmm6,%xmm10
  820e56:	ucomisd %xmm10,%xmm9
  820e5b:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820e61:	movapd 0x200(%rsp),%xmm9
  820e6b:	mulsd  %xmm13,%xmm9
  820e70:	mulsd  0x1f0(%rsp),%xmm13
  820e7a:	movapd 0x220(%rsp),%xmm10
  820e84:	mulsd  %xmm2,%xmm10
  820e89:	movapd %xmm10,%xmm6
  820e8e:	movapd %xmm9,0x170(%rsp)
  820e98:	addsd  %xmm9,%xmm6
  820e9d:	addsd  0xf0(%rsp),%xmm6
  820ea6:	subsd  0x50(%rsp),%xmm6
  820eac:	mulsd  0x210(%rsp),%xmm2
  820eb5:	movapd %xmm2,%xmm9
  820eba:	addsd  %xmm13,%xmm9
  820ebf:	addsd  0x100(%rsp),%xmm9
  820ec9:	addsd  0x40(%rsp),%xmm9
  820ed0:	addsd  0x30(%rsp),%xmm9
  820ed7:	addsd  -0x771600(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ee0:	mulsd  -0x7710a9(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820ee9:	ucomisd %xmm6,%xmm9
  820eee:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820ef4:	movapd %xmm10,0x300(%rsp)
  820efe:	movapd 0x20(%rsp),%xmm10
  820f05:	subsd  %xmm6,%xmm10
  820f0a:	ucomisd %xmm10,%xmm9
  820f0f:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820f15:	addsd  -0x771935(%rip),%xmm0        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820f1d:	movapd %xmm0,%xmm9
  820f22:	mulsd  0x2c0(%rsp),%xmm9
  820f2c:	addsd  %xmm9,%xmm11
  820f31:	addsd  0x160(%rsp),%xmm11
  820f3b:	subsd  0x90(%rsp),%xmm11
  820f45:	movapd 0x2b0(%rsp),%xmm10
  820f4f:	mulsd  %xmm0,%xmm10
  820f54:	addsd  %xmm10,%xmm4
  820f59:	addsd  0x150(%rsp),%xmm4
  820f62:	addsd  0x80(%rsp),%xmm4
  820f6b:	addsd  0x70(%rsp),%xmm4
  820f71:	addsd  -0x771699(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f79:	mulsd  -0x771721(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f81:	addsd  0x18(%rsp),%xmm4
  820f87:	ucomisd %xmm11,%xmm4
  820f8c:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820f92:	movapd 0x60(%rsp),%xmm6
  820f98:	subsd  %xmm11,%xmm6
  820f9d:	ucomisd %xmm6,%xmm4
  820fa1:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820fa7:	movapd 0x2a0(%rsp),%xmm6
  820fb0:	mulsd  %xmm0,%xmm6
  820fb4:	addsd  %xmm6,%xmm15
  820fb9:	addsd  0x140(%rsp),%xmm15
  820fc3:	subsd  0x90(%rsp),%xmm15
  820fcd:	movapd 0x290(%rsp),%xmm11
  820fd7:	mulsd  %xmm0,%xmm11
  820fdc:	addsd  %xmm11,%xmm14
  820fe1:	addsd  0x130(%rsp),%xmm14
  820feb:	addsd  0x80(%rsp),%xmm14
  820ff5:	addsd  0x70(%rsp),%xmm14
  820ffc:	addsd  -0x771725(%rip),%xmm14        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821005:	mulsd  -0x7711ce(%rip),%xmm14        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82100e:	ucomisd %xmm15,%xmm14
  821013:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821019:	movapd 0x60(%rsp),%xmm4
  82101f:	subsd  %xmm15,%xmm4
  821024:	ucomisd %xmm4,%xmm14
  821029:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  82102f:	movapd %xmm0,%xmm14
  821034:	mulsd  0x260(%rsp),%xmm14
  82103e:	movapd 0xc0(%rsp),%xmm4
  821047:	addsd  %xmm14,%xmm4
  82104c:	addsd  0x120(%rsp),%xmm4
  821055:	subsd  0x50(%rsp),%xmm4
  82105b:	movapd %xmm0,%xmm15
  821060:	mulsd  0x250(%rsp),%xmm15
  82106a:	addsd  %xmm15,%xmm12
  82106f:	addsd  0x110(%rsp),%xmm12
  821079:	addsd  0x40(%rsp),%xmm12
  821080:	addsd  0x30(%rsp),%xmm12
  821087:	addsd  -0x7717b0(%rip),%xmm12        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821090:	mulsd  -0x771839(%rip),%xmm12        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821099:	addsd  0x10(%rsp),%xmm12
  8210a0:	ucomisd %xmm4,%xmm12
  8210a5:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8210ab:	movsd  %xmm15,0xc0(%rsp)
  8210b5:	movapd %xmm4,%xmm15
  8210ba:	movapd 0x20(%rsp),%xmm4
  8210c0:	subsd  %xmm15,%xmm4
  8210c5:	ucomisd %xmm4,%xmm12
  8210ca:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8210d0:	movapd 0x220(%rsp),%xmm4
  8210d9:	mulsd  %xmm0,%xmm4
  8210dd:	movapd 0x170(%rsp),%xmm15
  8210e7:	addsd  %xmm4,%xmm15
  8210ec:	addsd  0xf0(%rsp),%xmm15
  8210f6:	subsd  0x50(%rsp),%xmm15
  8210fd:	mulsd  0x210(%rsp),%xmm0
  821106:	addsd  %xmm0,%xmm13
  82110b:	addsd  0x100(%rsp),%xmm13
  821115:	addsd  0x40(%rsp),%xmm13
  82111c:	addsd  0x30(%rsp),%xmm13
  821123:	addsd  -0x77184c(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82112c:	mulsd  -0x7712f5(%rip),%xmm13        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821135:	ucomisd %xmm15,%xmm13
  82113a:	movsd  0x8(%rsp),%xmm12
  821141:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821147:	movapd %xmm4,0x170(%rsp)
  821150:	movapd 0x20(%rsp),%xmm4
  821156:	subsd  %xmm15,%xmm4
  82115b:	ucomisd %xmm4,%xmm13
  821160:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821166:	movsd  %xmm10,0x188(%rsp)
  821170:	addsd  -0x771b90(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  821178:	movapd %xmm1,%xmm10
  82117d:	mulsd  0x2f0(%rsp),%xmm10
  821187:	movapd %xmm1,%xmm4
  82118b:	mulsd  0x2e0(%rsp),%xmm4
  821194:	addsd  %xmm10,%xmm3
  821199:	addsd  0x160(%rsp),%xmm3
  8211a2:	subsd  0x90(%rsp),%xmm3
  8211ab:	addsd  %xmm4,%xmm8
  8211b0:	addsd  0x150(%rsp),%xmm8
  8211ba:	addsd  0x80(%rsp),%xmm8
  8211c4:	addsd  0x70(%rsp),%xmm8
  8211cb:	addsd  -0x7718f4(%rip),%xmm8        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211d4:	mulsd  -0x77197d(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8211dd:	addsd  0x18(%rsp),%xmm8
  8211e4:	ucomisd %xmm3,%xmm8
  8211e9:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8211ef:	movapd %xmm6,0x2d0(%rsp)
  8211f8:	movapd 0x60(%rsp),%xmm6
  8211fe:	subsd  %xmm3,%xmm6
  821202:	ucomisd %xmm6,%xmm8
  821207:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82120d:	movapd 0x280(%rsp),%xmm8
  821217:	mulsd  %xmm1,%xmm8
  82121c:	movapd 0x270(%rsp),%xmm3
  821225:	mulsd  %xmm1,%xmm3
  821229:	addsd  %xmm8,%xmm5
  82122e:	addsd  0x140(%rsp),%xmm5
  821237:	subsd  0x90(%rsp),%xmm5
  821240:	addsd  %xmm3,%xmm7
  821244:	addsd  0x130(%rsp),%xmm7
  82124d:	addsd  0x80(%rsp),%xmm7
  821256:	addsd  0x70(%rsp),%xmm7
  82125c:	addsd  -0x771984(%rip),%xmm7        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821264:	mulsd  -0x77142c(%rip),%xmm7        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82126c:	ucomisd %xmm5,%xmm7
  821270:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821276:	movapd 0x60(%rsp),%xmm6
  82127c:	subsd  %xmm5,%xmm6
  821280:	ucomisd %xmm6,%xmm7
  821284:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82128a:	movsd  %xmm14,0x180(%rsp)
  821294:	movapd %xmm9,%xmm14
  821299:	movapd %xmm1,%xmm7
  82129d:	mulsd  0x240(%rsp),%xmm7
  8212a6:	movapd %xmm1,%xmm5
  8212aa:	mulsd  0x230(%rsp),%xmm5
  8212b3:	movsd  0x190(%rsp),%xmm9
  8212bd:	addsd  %xmm7,%xmm9
  8212c2:	addsd  0x120(%rsp),%xmm9
  8212cc:	subsd  0x50(%rsp),%xmm9
  8212d3:	movsd  0xb0(%rsp),%xmm13
  8212dd:	addsd  %xmm5,%xmm13
  8212e2:	addsd  0x110(%rsp),%xmm13
  8212ec:	addsd  0x40(%rsp),%xmm13
  8212f3:	addsd  0x30(%rsp),%xmm13
  8212fa:	addsd  -0x771a23(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821303:	mulsd  -0x771aac(%rip),%xmm13        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82130c:	addsd  0x10(%rsp),%xmm13
  821313:	ucomisd %xmm9,%xmm13
  821318:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82131e:	movapd 0x20(%rsp),%xmm6
  821324:	subsd  %xmm9,%xmm6
  821329:	ucomisd %xmm6,%xmm13
  82132e:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821334:	movapd 0x200(%rsp),%xmm6
  82133d:	mulsd  %xmm1,%xmm6
  821341:	mulsd  0x1f0(%rsp),%xmm1
  82134a:	movapd 0x300(%rsp),%xmm13
  821354:	addsd  %xmm6,%xmm13
  821359:	addsd  0xf0(%rsp),%xmm13
  821363:	subsd  0x50(%rsp),%xmm13
  82136a:	addsd  %xmm1,%xmm2
  82136e:	addsd  0x100(%rsp),%xmm2
  821377:	addsd  0x40(%rsp),%xmm2
  82137d:	addsd  0x30(%rsp),%xmm2
  821383:	addsd  -0x771aab(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82138b:	mulsd  -0x771553(%rip),%xmm2        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821393:	ucomisd %xmm13,%xmm2
  821398:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82139e:	movapd 0x20(%rsp),%xmm9
  8213a5:	subsd  %xmm13,%xmm9
  8213aa:	ucomisd %xmm9,%xmm2
  8213af:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8213b5:	addsd  %xmm10,%xmm14
  8213ba:	addsd  0x160(%rsp),%xmm14
  8213c4:	subsd  0x90(%rsp),%xmm14
  8213ce:	movsd  0x188(%rsp),%xmm9
  8213d8:	addsd  %xmm4,%xmm9
  8213dd:	addsd  0x150(%rsp),%xmm9
  8213e7:	addsd  0x80(%rsp),%xmm9
  8213f1:	addsd  0x70(%rsp),%xmm9
  8213f8:	addsd  -0x771b21(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821401:	mulsd  -0x771baa(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82140a:	addsd  0x18(%rsp),%xmm9
  821411:	ucomisd %xmm14,%xmm9
  821416:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82141c:	movapd 0x60(%rsp),%xmm2
  821422:	subsd  %xmm14,%xmm2
  821427:	ucomisd %xmm2,%xmm9
  82142c:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821432:	movapd 0x2d0(%rsp),%xmm4
  82143b:	addsd  %xmm8,%xmm4
  821440:	addsd  0x140(%rsp),%xmm4
  821449:	subsd  0x90(%rsp),%xmm4
  821452:	addsd  %xmm3,%xmm11
  821457:	addsd  0x130(%rsp),%xmm11
  821461:	addsd  0x80(%rsp),%xmm11
  82146b:	addsd  0x70(%rsp),%xmm11
  821472:	addsd  -0x771b9b(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82147b:	mulsd  -0x771644(%rip),%xmm11        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821484:	ucomisd %xmm4,%xmm11
  821489:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82148f:	movapd 0x60(%rsp),%xmm2
  821495:	subsd  %xmm4,%xmm2
  821499:	ucomisd %xmm2,%xmm11
  82149e:	movsd  0x180(%rsp),%xmm3
  8214a7:	movsd  0xc0(%rsp),%xmm4
  8214b0:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8214b6:	addsd  %xmm7,%xmm3
  8214ba:	addsd  0x120(%rsp),%xmm3
  8214c3:	subsd  0x50(%rsp),%xmm3
  8214c9:	addsd  %xmm5,%xmm4
  8214cd:	addsd  0x110(%rsp),%xmm4
  8214d6:	addsd  0x40(%rsp),%xmm4
  8214dc:	addsd  0x30(%rsp),%xmm4
  8214e2:	addsd  -0x771c0a(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214ea:	mulsd  -0x771c92(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8214f2:	addsd  0x10(%rsp),%xmm4
  8214f8:	ucomisd %xmm3,%xmm4
  8214fc:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821502:	movapd 0x20(%rsp),%xmm2
  821508:	subsd  %xmm3,%xmm2
  82150c:	ucomisd %xmm2,%xmm4
  821510:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821516:	movapd 0x170(%rsp),%xmm3
  82151f:	addsd  %xmm6,%xmm3
  821523:	addsd  0xf0(%rsp),%xmm3
  82152c:	subsd  0x50(%rsp),%xmm3
  821532:	addsd  %xmm1,%xmm0
  821536:	addsd  0x100(%rsp),%xmm0
  82153f:	addsd  0x40(%rsp),%xmm0
  821545:	addsd  0x30(%rsp),%xmm0
  82154b:	addsd  -0x771c73(%rip),%xmm0        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821553:	mulsd  -0x77171b(%rip),%xmm0        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82155b:	ucomisd %xmm3,%xmm0
  82155f:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821565:	movapd 0x20(%rsp),%xmm1
  82156b:	subsd  %xmm3,%xmm1
  82156f:	ucomisd %xmm1,%xmm0
  821573:	jb     820b15 <<gpui_gpu::renderer::RendererState>::bin_draw+0x635>
  821579:	jmp    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82157e:	movsd  0x8(%rsp),%xmm12
  821585:	jmp    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82158a:	nopw   0x0(%rax,%rax,1)
  821590:	mov    0x1a8(%rsp),%r10
  821598:	cmp    %r10,0x1c0(%rsp)
  8215a0:	mov    0x1b0(%rsp),%rbp
  8215a8:	mov    0x1b8(%rsp),%rax
  8215b0:	jae    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8215b6:	mov    %rax,%r14
  8215b9:	cmp    %r10,%rax
  8215bc:	jbe    820a10 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  8215c2:	jmp    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8215c7:	nopw   0x0(%rax,%rax,1)
  8215d0:	mov    %r14,%rax
  8215d3:	cmp    %r10,%r14
  8215d6:	adc    $0x0,%r14
  8215da:	mov    %rax,%rcx
  8215dd:	imul   %r13,%rcx
  8215e1:	mov    %rbp,%rdx
  8215e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  8215f0:	lea    (%rdx,%rcx,1),%r12
  8215f4:	cmp    %r9,%r12
  8215f7:	jae    821635 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  8215f9:	cmp    %rbx,%rdx
  8215fc:	mov    %rdx,%rsi
  8215ff:	adc    $0x0,%rsi
  821603:	mov    0x4(%r15,%r12,8),%edi
  821608:	inc    %edi
  82160a:	and    $0xbfffffff,%edi
  821610:	mov    %edi,0x4(%r15,%r12,8)
  821615:	cmp    %rbx,%rdx
  821618:	jae    821622 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1142>
  82161a:	mov    %rsi,%rdx
  82161d:	cmp    %rbx,%rsi
  821620:	jbe    8215f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1110>
  821622:	cmp    %r10,%rax
  821625:	jae    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82162b:	cmp    %r10,%r14
  82162e:	jbe    8215d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  821630:	jmp    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  821635:	lea    0x60e584(%rip),%rdx        # e2fbc0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x108>
  82163c:	mov    %r12,%rdi
  82163f:	mov    %r9,%rsi
  821642:	call   *0x65ff40(%rip)        # e81588 <_DYNAMIC+0x4f8>
  821648:	lea    0x60e691(%rip),%rdi        # e2fce0 <anon.7e34a6dced7fe4eb77116889a7de5f31.41.llvm.6877253771164693793>
  82164f:	call   *0x660013(%rip)        # e81668 <_DYNAMIC+0x5d8>
  821655:	lea    0x60e54c(%rip),%rdx        # e2fba8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0xf0>
  82165c:	mov    %r12,%rdi
  82165f:	mov    %r9,%rsi
  821662:	call   *0x65ff20(%rip)        # e81588 <_DYNAMIC+0x4f8>
  821668:	lea    0x60e581(%rip),%rdx        # e2fbf0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x138>
  82166f:	mov    %r12,%rdi
  821672:	mov    0xd8(%rsp),%rsi
  82167a:	call   *0x65ff08(%rip)        # e81588 <_DYNAMIC+0x4f8>
  821680:	lea    0x60e551(%rip),%rdx        # e2fbd8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x120>
  821687:	mov    %r12,%rdi
  82168a:	mov    %r9,%rsi
  82168d:	call   *0x65fef5(%rip)        # e81588 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008216a0 <gpui_gpu::renderer::compact_group>:
  8216a0:	xor    %eax,%eax
  8216a2:	test   %esi,%esi
  8216a4:	je     8216e3 <gpui_gpu::renderer::compact_group+0x43>
  8216a6:	cmpq   $0x2,0x10(%rdi)
  8216ab:	jb     8216e3 <gpui_gpu::renderer::compact_group+0x43>
  8216ad:	sub    $0x58,%rsp
  8216b1:	mov    (%rdi),%rsi
  8216b4:	mov    0x8(%rdi),%rax
  8216b8:	mov    (%rax),%edx
  8216ba:	mov    %rsp,%rdi
  8216bd:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8216c2:	movss  0x4(%rsp),%xmm0
  8216c8:	cmpb   $0x3,(%rsp)
  8216cc:	setne  %cl
  8216cf:	xorps  %xmm1,%xmm1
  8216d2:	ucomiss %xmm1,%xmm0
  8216d5:	setnp  %dl
  8216d8:	sete   %al
  8216db:	and    %dl,%al
  8216dd:	or     %cl,%al
  8216df:	add    $0x58,%rsp
  8216e3:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008216f0 <gpui_gpu::renderer::validate_draw>:
  8216f0:	push   %rbp
  8216f1:	push   %r15
  8216f3:	push   %r14
  8216f5:	push   %r12
  8216f7:	push   %rbx
  8216f8:	sub    $0x80,%rsp
  8216ff:	mov    %r8d,%ebp
  821702:	mov    %ecx,%r12d
  821705:	mov    %rdx,%r14
  821708:	mov    %rsi,%r15
  82170b:	mov    %rdi,%rbx
  82170e:	movups 0x88(%rsi),%xmm0
  821715:	movaps %xmm0,0x20(%rsp)
  82171a:	movaps %xmm0,0x70(%rsp)
  82171f:	lea    0x70(%rsp),%rdi
  821724:	call   *0x65ffd6(%rip)        # e81700 <_DYNAMIC+0x670>
  82172a:	movaps 0x20(%rsp),%xmm4
  82172f:	test   %al,%al
  821731:	je     821787 <gpui_gpu::renderer::validate_draw+0x97>
  821733:	movaps %xmm4,%xmm0
  821736:	unpckhpd %xmm4,%xmm0
  82173a:	xorps  %xmm2,%xmm2
  82173d:	ucomiss %xmm2,%xmm0
  821740:	jne    821744 <gpui_gpu::renderer::validate_draw+0x54>
  821742:	jnp    821787 <gpui_gpu::renderer::validate_draw+0x97>
  821744:	movaps %xmm4,%xmm1
  821747:	shufps $0xff,%xmm4,%xmm1
  82174b:	ucomiss %xmm2,%xmm1
  82174e:	jne    821752 <gpui_gpu::renderer::validate_draw+0x62>
  821750:	jnp    821787 <gpui_gpu::renderer::validate_draw+0x97>
  821752:	xorps  %xmm3,%xmm3
  821755:	ucomiss %xmm4,%xmm3
  821758:	ja     821787 <gpui_gpu::renderer::validate_draw+0x97>
  82175a:	movaps %xmm4,%xmm2
  82175d:	shufps $0x55,%xmm4,%xmm2
  821761:	ucomiss %xmm2,%xmm3
  821764:	ja     821787 <gpui_gpu::renderer::validate_draw+0x97>
  821766:	xorps  %xmm3,%xmm3
  821769:	cvtsi2ss %r12d,%xmm3
  82176e:	addss  %xmm4,%xmm0
  821772:	ucomiss %xmm3,%xmm0
  821775:	ja     821787 <gpui_gpu::renderer::validate_draw+0x97>
  821777:	xorps  %xmm0,%xmm0
  82177a:	cvtsi2ss %ebp,%xmm0
  82177e:	addss  %xmm1,%xmm2
  821782:	ucomiss %xmm0,%xmm2
  821785:	jbe    82179d <gpui_gpu::renderer::validate_draw+0xad>
  821787:	movl   $0x3,(%rbx)
  82178d:	add    $0x80,%rsp
  821794:	pop    %rbx
  821795:	pop    %r12
  821797:	pop    %r14
  821799:	pop    %r15
  82179b:	pop    %rbp
  82179c:	ret
  82179d:	movsd  0x48(%r15),%xmm9
  8217a3:	movsd  0x60(%r15),%xmm1
  8217a9:	movupd 0x50(%r15),%xmm2
  8217af:	movapd %xmm2,%xmm5
  8217b3:	shufpd $0x1,%xmm2,%xmm5
  8217b8:	movupd 0x68(%r15),%xmm0
  8217be:	cvtpd2ps %xmm5,%xmm8
  8217c3:	movapd %xmm9,%xmm4
  8217c8:	unpcklpd %xmm1,%xmm4
  8217cc:	cvtpd2ps %xmm4,%xmm7
  8217d0:	cvtpd2ps %xmm0,%xmm6
  8217d4:	movapd %xmm6,%xmm3
  8217d8:	shufps $0x55,%xmm6,%xmm3
  8217dc:	movd   %xmm3,%ecx
  8217e0:	movd   %xmm6,%eax
  8217e4:	movapd %xmm7,%xmm3
  8217e8:	shufps $0x14,%xmm8,%xmm3
  8217ed:	shufps $0x78,%xmm3,%xmm3
  8217f1:	andps  -0x774008(%rip),%xmm3        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8217f8:	and    $0x7fffffff,%eax
  8217fd:	cmp    $0x7f800000,%eax
  821802:	setge  %al
  821805:	and    $0x7fffffff,%ecx
  82180b:	cmp    $0x7f800000,%ecx
  821811:	setge  %cl
  821814:	pcmpgtd -0x7760ec(%rip),%xmm3        # ab730 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  82181c:	movmskps %xmm3,%edx
  82181f:	test   %edx,%edx
  821821:	jne    821872 <gpui_gpu::renderer::validate_draw+0x182>
  821823:	test   %al,%al
  821825:	jne    821872 <gpui_gpu::renderer::validate_draw+0x182>
  821827:	test   %cl,%cl
  821829:	jne    821872 <gpui_gpu::renderer::validate_draw+0x182>
  82182b:	movapd %xmm9,%xmm3
  821830:	mulsd  %xmm1,%xmm3
  821834:	movapd %xmm2,%xmm10
  821839:	mulsd  %xmm5,%xmm10
  82183e:	subsd  %xmm10,%xmm3
  821843:	xorpd  %xmm10,%xmm10
  821848:	ucomisd %xmm10,%xmm3
  82184d:	jne    821851 <gpui_gpu::renderer::validate_draw+0x161>
  82184f:	jnp    821872 <gpui_gpu::renderer::validate_draw+0x182>
  821851:	movq   %xmm3,%rcx
  821856:	movabs $0x7fffffffffffffff,%rax
  821860:	and    %rax,%rcx
  821863:	movabs $0x7ff0000000000000,%rdx
  82186d:	cmp    %rdx,%rcx
  821870:	jl     821881 <gpui_gpu::renderer::validate_draw+0x191>
  821872:	movl   $0x5,(%rbx)
  821878:	mov    %r14,0x8(%rbx)
  82187c:	jmp    82178d <gpui_gpu::renderer::validate_draw+0x9d>
  821881:	xorps  %xmm10,%xmm10
  821885:	cvtsi2sd %r12d,%xmm10
  82188a:	cvtsi2sd %ebp,%xmm12
  82188f:	movsd  %xmm9,%xmm2
  821894:	movapd -0x776a6d(%rip),%xmm13        # aae30 <GCC_except_table0+0x7c>
  82189d:	andpd  %xmm13,%xmm2
  8218a2:	movapd %xmm10,%xmm11
  8218a7:	unpcklpd %xmm12,%xmm11
  8218ac:	movapd %xmm2,%xmm9
  8218b1:	movapd %xmm11,0x50(%rsp)
  8218b8:	mulpd  %xmm11,%xmm9
  8218bd:	movapd %xmm9,%xmm11
  8218c2:	unpckhpd %xmm9,%xmm11
  8218c7:	addsd  %xmm9,%xmm11
  8218cc:	movapd %xmm0,%xmm9
  8218d1:	andpd  %xmm13,%xmm9
  8218d6:	addsd  %xmm11,%xmm9
  8218db:	shufpd $0x2,%xmm5,%xmm1
  8218e0:	andpd  %xmm13,%xmm1
  8218e5:	unpcklpd %xmm10,%xmm12
  8218ea:	movapd %xmm1,%xmm10
  8218ef:	movapd %xmm12,0x40(%rsp)
  8218f6:	mulpd  %xmm12,%xmm10
  8218fb:	movapd %xmm10,%xmm11
  821900:	unpckhpd %xmm10,%xmm11
  821905:	addsd  %xmm9,%xmm11
  82190a:	addsd  %xmm10,%xmm11
  82190f:	movapd %xmm0,%xmm10
  821914:	unpckhpd %xmm0,%xmm10
  821919:	andpd  %xmm13,%xmm10
  82191e:	addsd  %xmm11,%xmm10
  821923:	movsd  0x38(%r15),%xmm9
  821929:	movsd  0x40(%r15),%xmm12
  82192f:	andps  -0x774147(%rip),%xmm9        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821937:	cvtps2pd %xmm9,%xmm15
  82193b:	movapd %xmm10,%xmm9
  821940:	addsd  %xmm15,%xmm9
  821945:	movapd %xmm15,0x60(%rsp)
  82194c:	unpckhpd %xmm15,%xmm15
  821951:	addsd  %xmm15,%xmm9
  821956:	cvtps2pd %xmm12,%xmm11
  82195a:	movapd %xmm11,0x20(%rsp)
  821961:	andpd  %xmm13,%xmm11
  821966:	addsd  %xmm11,%xmm9
  82196b:	pshufd $0xee,%xmm11,%xmm14
  821971:	movdqa %xmm14,0x30(%rsp)
  821978:	addsd  %xmm14,%xmm9
  82197d:	movq   %xmm9,%rsi
  821982:	and    %rax,%rsi
  821985:	movabs $0x7fefffffffffffff,%rcx
  82198f:	cmp    %rcx,%rsi
  821992:	jg     821872 <gpui_gpu::renderer::validate_draw+0x182>
  821998:	ucomisd -0x772329(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8219a1:	ja     821872 <gpui_gpu::renderer::validate_draw+0x182>
  8219a7:	movzbl (%r15),%esi
  8219ab:	cmp    $0x3,%esi
  8219ae:	je     8219c6 <gpui_gpu::renderer::validate_draw+0x2d6>
  8219b0:	xorpd  %xmm14,%xmm14
  8219b5:	cmp    $0x1,%esi
  8219b8:	jne    821af2 <gpui_gpu::renderer::validate_draw+0x402>
  8219be:	movss  0x4(%r15),%xmm14
  8219c4:	jmp    8219dd <gpui_gpu::renderer::validate_draw+0x2ed>
  8219c6:	movss  0x4(%r15),%xmm14
  8219cc:	xorpd  %xmm13,%xmm13
  8219d1:	ucomiss %xmm13,%xmm14
  8219d5:	jne    8219dd <gpui_gpu::renderer::validate_draw+0x2ed>
  8219d7:	jnp    821c17 <gpui_gpu::renderer::validate_draw+0x527>
  8219dd:	movd   %xmm14,%edi
  8219e2:	test   %edi,%edi
  8219e4:	sets   %r8b
  8219e8:	and    $0x7fffffff,%edi
  8219ee:	lea    -0x800000(%rdi),%r9d
  8219f5:	cmp    $0x7f000000,%r9d
  8219fc:	setb   %r9b
  821a00:	and    %r8b,%r9b
  821a03:	lea    -0x1(%rdi),%r10d
  821a07:	cmp    $0x7fffff,%r10d
  821a0e:	setb   %r10b
  821a12:	and    %r8b,%r10b
  821a15:	cmp    $0x7f800000,%edi
  821a1b:	sete   %dil
  821a1f:	setg   %r8b
  821a23:	or     %dil,%r8b
  821a26:	or     %r10b,%r8b
  821a29:	or     %r9b,%r8b
  821a2c:	cmp    $0x1,%r8b
  821a30:	je     821787 <gpui_gpu::renderer::validate_draw+0x97>
  821a36:	movaps %xmm11,(%rsp)
  821a3b:	movaps %xmm14,%xmm11
  821a3f:	movaps %xmm14,0x10(%rsp)
  821a45:	movaps %xmm12,%xmm14
  821a49:	mulss  -0x772a86(%rip),%xmm14        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821a52:	minss  %xmm14,%xmm11
  821a57:	movaps %xmm11,%xmm14
  821a5b:	cmpunordss %xmm11,%xmm14
  821a61:	movaps %xmm14,%xmm13
  821a65:	andnps %xmm11,%xmm13
  821a69:	andps  0x10(%rsp),%xmm14
  821a6f:	orps   %xmm13,%xmm14
  821a73:	shufps $0x55,%xmm12,%xmm12
  821a78:	mulss  -0x772ab5(%rip),%xmm12        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821a81:	movaps %xmm14,%xmm11
  821a85:	minss  %xmm12,%xmm11
  821a8a:	movaps %xmm11,%xmm12
  821a8e:	cmpunordss %xmm11,%xmm12
  821a94:	andps  %xmm12,%xmm14
  821a98:	andnps %xmm11,%xmm12
  821a9c:	orps   %xmm14,%xmm12
  821aa0:	movss  -0x7727f9(%rip),%xmm11        # af2b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821aa9:	ucomiss %xmm12,%xmm11
  821aad:	ja     821872 <gpui_gpu::renderer::validate_draw+0x182>
  821ab3:	xorps  %xmm14,%xmm14
  821ab7:	cvtss2sd %xmm12,%xmm14
  821abc:	movapd %xmm9,%xmm11
  821ac1:	divsd  %xmm14,%xmm11
  821ac6:	ucomisd -0x7721e7(%rip),%xmm11        # af8e8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  821acf:	ja     821872 <gpui_gpu::renderer::validate_draw+0x182>
  821ad5:	addsd  %xmm9,%xmm14
  821ada:	mulsd  -0x77235b(%rip),%xmm14        # af788 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821ae3:	movapd (%rsp),%xmm11
  821ae9:	movapd -0x776cc2(%rip),%xmm13        # aae30 <GCC_except_table0+0x7c>
  821af2:	cmp    $0x2,%esi
  821af5:	movaps %xmm11,(%rsp)
  821afa:	jae    821c0b <gpui_gpu::renderer::validate_draw+0x51b>
  821b00:	cvtps2pd %xmm8,%xmm8
  821b04:	subpd  %xmm8,%xmm5
  821b09:	cvtps2pd %xmm7,%xmm7
  821b0c:	andpd  %xmm13,%xmm5
  821b11:	mulpd  0x40(%rsp),%xmm5
  821b17:	subpd  %xmm7,%xmm4
  821b1b:	andpd  %xmm13,%xmm4
  821b20:	mulpd  0x50(%rsp),%xmm4
  821b26:	addpd  %xmm5,%xmm4
  821b2a:	cvtps2pd %xmm6,%xmm5
  821b2d:	subpd  %xmm5,%xmm0
  821b31:	addsd  -0x77225a(%rip),%xmm10        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821b3a:	mulsd  -0x772093(%rip),%xmm10        # afab0 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821b43:	andpd  %xmm13,%xmm0
  821b48:	addpd  %xmm4,%xmm0
  821b4c:	movapd 0x60(%rsp),%xmm7
  821b52:	addsd  %xmm7,%xmm15
  821b57:	movapd (%rsp),%xmm6
  821b5c:	addsd  %xmm6,%xmm15
  821b61:	addsd  0x30(%rsp),%xmm15
  821b68:	movapd %xmm0,%xmm4
  821b6c:	unpckhpd %xmm0,%xmm4
  821b70:	addpd  %xmm0,%xmm4
  821b74:	movapd %xmm1,%xmm5
  821b78:	shufpd $0x1,%xmm4,%xmm5
  821b7d:	movapd %xmm2,%xmm4
  821b81:	unpcklpd %xmm10,%xmm4
  821b86:	addpd  %xmm4,%xmm5
  821b8a:	mulsd  -0x7724db(%rip),%xmm15        # af6b8 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821b93:	shufpd $0x1,%xmm15,%xmm2
  821b99:	addpd  %xmm5,%xmm2
  821b9d:	unpcklpd %xmm14,%xmm1
  821ba2:	addpd  %xmm2,%xmm1
  821ba6:	movapd %xmm1,%xmm2
  821baa:	unpckhpd %xmm1,%xmm2
  821bae:	mulsd  %xmm1,%xmm2
  821bb2:	andpd  -0x776d8a(%rip),%xmm3        # aae30 <GCC_except_table0+0x7c>
  821bba:	divsd  %xmm3,%xmm2
  821bbe:	movq   %xmm2,%rdx
  821bc3:	and    %rax,%rdx
  821bc6:	cmp    %rcx,%rdx
  821bc9:	jg     821872 <gpui_gpu::renderer::validate_draw+0x182>
  821bcf:	ucomisd -0x771cc7(%rip),%xmm2        # aff10 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821bd7:	ja     821872 <gpui_gpu::renderer::validate_draw+0x182>
  821bdd:	unpcklpd %xmm10,%xmm10
  821be2:	addpd  %xmm10,%xmm0
  821be7:	addpd  %xmm7,%xmm6
  821beb:	mulpd  -0x776be3(%rip),%xmm6        # ab010 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821bf3:	addpd  %xmm0,%xmm6
  821bf7:	cvtpd2ps %xmm6,%xmm0
  821bfb:	movlpd %xmm0,0x4(%rbx)
  821c00:	movl   $0xffffffff,(%rbx)
  821c06:	jmp    82178d <gpui_gpu::renderer::validate_draw+0x9d>
  821c0b:	jne    821c20 <gpui_gpu::renderer::validate_draw+0x530>
  821c0d:	mov    0x28(%r15),%rsi
  821c11:	mov    0x30(%r15),%rdi
  821c15:	jmp    821c28 <gpui_gpu::renderer::validate_draw+0x538>
  821c17:	movaps %xmm11,(%rsp)
  821c1c:	xorps  %xmm14,%xmm14
  821c20:	mov    0x28(%r15),%esi
  821c24:	mov    0x2c(%r15),%edi
  821c28:	movq   %rsi,%xmm11
  821c2d:	punpckldq -0x7762e6(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821c36:	subpd  -0x776e1f(%rip),%xmm11        # aae20 <GCC_except_table0+0x6c>
  821c3f:	movapd %xmm11,%xmm12
  821c44:	unpckhpd %xmm11,%xmm12
  821c49:	addsd  %xmm11,%xmm12
  821c4e:	movapd 0x20(%rsp),%xmm11
  821c55:	divsd  %xmm11,%xmm12
  821c5a:	movq   %xmm12,%r8
  821c5f:	and    %rax,%r8
  821c62:	cmp    %rdx,%r8
  821c65:	jge    821872 <gpui_gpu::renderer::validate_draw+0x182>
  821c6b:	movaps %xmm14,0x10(%rsp)
  821c71:	movapd %xmm11,%xmm14
  821c76:	movq   %rdi,%xmm11
  821c7b:	punpckldq -0x776334(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821c84:	subpd  -0x776e6d(%rip),%xmm11        # aae20 <GCC_except_table0+0x6c>
  821c8d:	movapd %xmm11,%xmm13
  821c92:	unpckhpd %xmm11,%xmm13
  821c97:	addsd  %xmm11,%xmm13
  821c9c:	unpckhpd %xmm14,%xmm14
  821ca1:	divsd  %xmm14,%xmm13
  821ca6:	movapd 0x10(%rsp),%xmm14
  821cad:	movq   %xmm13,%rdx
  821cb2:	and    %rax,%rdx
  821cb5:	cmp    %rcx,%rdx
  821cb8:	setg   %dl
  821cbb:	ucomisd -0x77264c(%rip),%xmm13        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821cc4:	movapd -0x776e9d(%rip),%xmm13        # aae30 <GCC_except_table0+0x7c>
  821ccd:	ja     821872 <gpui_gpu::renderer::validate_draw+0x182>
  821cd3:	ucomisd -0x772664(%rip),%xmm12        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821cdc:	ja     821872 <gpui_gpu::renderer::validate_draw+0x182>
  821ce2:	test   %dl,%dl
  821ce4:	jne    821872 <gpui_gpu::renderer::validate_draw+0x182>
  821cea:	cmp    %rsi,%rdi
  821ced:	cmova  %rdi,%rsi
  821cf1:	movq   %rsi,%xmm11
  821cf6:	punpckldq -0x7763af(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821cff:	subpd  -0x776ee8(%rip),%xmm11        # aae20 <GCC_except_table0+0x6c>
  821d08:	movapd %xmm11,%xmm12
  821d0d:	unpckhpd %xmm11,%xmm12
  821d12:	addsd  %xmm11,%xmm12
  821d17:	mulsd  %xmm12,%xmm9
  821d1c:	ucomisd -0x7726ad(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821d25:	ja     821872 <gpui_gpu::renderer::validate_draw+0x182>
  821d2b:	jmp    821b00 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822440 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  822440:	push   %rbp
  822441:	push   %r15
  822443:	push   %r14
  822445:	push   %r13
  822447:	push   %r12
  822449:	push   %rbx
  82244a:	sub    $0x58,%rsp
  82244e:	mov    %ecx,%ebp
  822450:	mov    %rdx,0x8(%rsp)
  822455:	mov    0x18(%rdi),%rax
  822459:	add    %rax,%rsi
  82245c:	jb     822571 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822462:	mov    %rdi,%rbx
  822465:	mov    0x8(%rdi),%r15
  822469:	lea    0x1(%r15),%rdx
  82246d:	mov    %rdx,%rdi
  822470:	shr    $0x3,%rdi
  822474:	mov    %rdx,%rcx
  822477:	and    $0xfffffffffffffff8,%rcx
  82247b:	sub    %rdi,%rcx
  82247e:	cmp    $0x8,%r15
  822482:	cmovb  %r15,%rcx
  822486:	mov    %rcx,%rdi
  822489:	shr    $1,%rdi
  82248c:	cmp    %rdi,%rsi
  82248f:	jbe    8224c0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  822491:	inc    %rcx
  822494:	cmp    %rsi,%rcx
  822497:	cmovbe %rsi,%rcx
  82249b:	cmp    $0xf,%rcx
  82249f:	mov    %rbx,(%rsp)
  8224a3:	jae    8224f1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  8224a5:	mov    %ecx,%eax
  8224a7:	and    $0x8,%eax
  8224aa:	add    $0x8,%rax
  8224ae:	cmp    $0x4,%rcx
  8224b2:	mov    $0x4,%ebx
  8224b7:	cmovae %rax,%rbx
  8224bb:	jmp    822549 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  8224c0:	test   %rdx,%rdx
  8224c3:	je     82274a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  8224c9:	mov    (%rbx),%rsi
  8224cc:	mov    %rdx,%rax
  8224cf:	shr    $0x4,%rax
  8224d3:	mov    %edx,%ecx
  8224d5:	and    $0xf,%ecx
  8224d8:	cmp    $0x1,%rcx
  8224dc:	sbb    $0xffffffffffffffff,%rax
  8224e0:	cmp    $0x1,%rax
  8224e4:	jne    822751 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  8224ea:	xor    %ecx,%ecx
  8224ec:	jmp    8227a4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  8224f1:	movabs $0x1ffffffffffffffe,%rax
  8224fb:	inc    %rax
  8224fe:	cmp    %rax,%rcx
  822501:	ja     822571 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822503:	shl    $0x3,%rcx
  822507:	movabs $0x2492492492492493,%rdx
  822511:	mov    %rcx,%rax
  822514:	mul    %rdx
  822517:	sub    %rdx,%rcx
  82251a:	shr    $1,%rcx
  82251d:	add    %rdx,%rcx
  822520:	shr    $0x2,%rcx
  822524:	dec    %rcx
  822527:	bsr    %rcx,%rcx
  82252b:	not    %ecx
  82252d:	mov    $0xffffffffffffffff,%rbx
  822534:	shr    %cl,%rbx
  822537:	movabs $0x7fffffffffffffe,%rax
  822541:	cmp    %rax,%rbx
  822544:	ja     822571 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822546:	inc    %rbx
  822549:	mov    %rbx,%r14
  82254c:	shl    $0x5,%r14
  822550:	lea    0x10(%rbx),%r12
  822554:	mov    %r12,%r13
  822557:	add    %r14,%r13
  82255a:	setb   %al
  82255d:	movabs $0x7ffffffffffffff0,%rcx
  822567:	cmp    %rcx,%r13
  82256a:	seta   %cl
  82256d:	or     %al,%cl
  82256f:	je     822580 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  822571:	movzbl %bpl,%edi
  822575:	call   *0x65f18d(%rip)        # e81708 <_DYNAMIC+0x678>
  82257b:	jmp    8229c5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  822580:	call   *0x65ed9a(%rip)        # e81320 <_DYNAMIC+0x290>
  822586:	mov    $0x10,%esi
  82258b:	mov    %r13,%rdi
  82258e:	call   *0x65ed94(%rip)        # e81328 <_DYNAMIC+0x298>
  822594:	test   %rax,%rax
  822597:	je     8229e3 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  82259d:	mov    %rax,%r15
  8225a0:	mov    (%rsp),%rcx
  8225a4:	lea    0x20(%rcx),%r13
  8225a8:	add    %r14,%r15
  8225ab:	lea    -0x1(%rbx),%r14
  8225af:	mov    %rbx,%rax
  8225b2:	shr    $0x3,%rax
  8225b6:	mov    %rbx,%rbp
  8225b9:	and    $0xfffffffffffffff8,%rbp
  8225bd:	sub    %rax,%rbp
  8225c0:	cmp    $0x9,%rbx
  8225c4:	mov    %rcx,%rbx
  8225c7:	cmovb  %r14,%rbp
  8225cb:	mov    %r15,%rdi
  8225ce:	mov    $0xff,%esi
  8225d3:	mov    %r12,%rdx
  8225d6:	call   *0x65f134(%rip)        # e81710 <memset@GLIBC_2.2.5>
  8225dc:	mov    %r14,%rdi
  8225df:	mov    %r13,0x20(%rsp)
  8225e4:	movq   $0x20,0x28(%rsp)
  8225ed:	movq   $0x10,0x30(%rsp)
  8225f6:	mov    %r15,0x38(%rsp)
  8225fb:	mov    %r14,0x40(%rsp)
  822600:	mov    %rbp,0x48(%rsp)
  822605:	movq   $0x0,0x50(%rsp)
  82260e:	mov    0x18(%rbx),%r12
  822612:	test   %r12,%r12
  822615:	je     8229f7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82261b:	mov    %rbp,0x10(%rsp)
  822620:	mov    (%rbx),%rsi
  822623:	movdqa (%rsi),%xmm0
  822627:	pmovmskb %xmm0,%r13d
  82262c:	not    %r13d
  82262f:	xor    %ebp,%ebp
  822631:	mov    %rsi,%r14
  822634:	mov    %rdi,0x18(%rsp)
  822639:	nopl   0x0(%rax)
  822640:	test   %r13w,%r13w
  822644:	jne    82266f <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  822646:	cs nopw 0x0(%rax,%rax,1)
  822650:	movdqa 0x10(%r14),%xmm0
  822656:	add    $0x10,%r14
  82265a:	pmovmskb %xmm0,%r13d
  82265f:	xor    $0xffff,%r13d
  822666:	add    $0x10,%rbp
  82266a:	test   %r13d,%r13d
  82266d:	je     822650 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  82266f:	tzcnt  %r13d,%ebx
  822674:	add    %rbp,%rbx
  822677:	mov    %rbx,%rax
  82267a:	shl    $0x5,%rax
  82267e:	sub    %rax,%rsi
  822681:	add    $0xffffffffffffffe0,%rsi
  822685:	mov    0x8(%rsp),%rdi
  82268a:	call   8250e0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  82268f:	mov    %rax,%rdx
  822692:	mov    0x18(%rsp),%rdi
  822697:	and    %rdi,%rdx
  82269a:	movdqu (%r15,%rdx,1),%xmm0
  8226a0:	pmovmskb %xmm0,%ecx
  8226a4:	test   %ecx,%ecx
  8226a6:	je     822715 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  8226a8:	tzcnt  %ecx,%ecx
  8226ac:	add    %rdx,%rcx
  8226af:	and    %rdi,%rcx
  8226b2:	cmpb   $0x0,(%r15,%rcx,1)
  8226b7:	jns    822738 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  8226b9:	lea    -0x1(%r13),%edx
  8226bd:	and    %r13d,%edx
  8226c0:	dec    %r12
  8226c3:	shr    $0x39,%rax
  8226c7:	lea    -0x10(%rcx),%rsi
  8226cb:	and    %rdi,%rsi
  8226ce:	mov    %al,(%r15,%rcx,1)
  8226d2:	mov    %al,0x10(%r15,%rsi,1)
  8226d7:	mov    (%rsp),%rax
  8226db:	mov    (%rax),%rsi
  8226de:	not    %rbx
  8226e1:	shl    $0x5,%rbx
  8226e5:	not    %rcx
  8226e8:	shl    $0x5,%rcx
  8226ec:	movdqu (%rsi,%rbx,1),%xmm0
  8226f1:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  8226f7:	movdqu %xmm1,0x10(%r15,%rcx,1)
  8226fe:	movdqu %xmm0,(%r15,%rcx,1)
  822704:	mov    %edx,%r13d
  822707:	test   %r12,%r12
  82270a:	jne    822640 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  822710:	jmp    8229d4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  822715:	mov    $0x10,%esi
  82271a:	add    %rsi,%rdx
  82271d:	and    %rdi,%rdx
  822720:	movdqu (%r15,%rdx,1),%xmm0
  822726:	pmovmskb %xmm0,%ecx
  82272a:	add    $0x10,%rsi
  82272e:	test   %ecx,%ecx
  822730:	jne    8226a8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  822736:	jmp    82271a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  822738:	movdqa (%r15),%xmm0
  82273d:	pmovmskb %xmm0,%ecx
  822741:	tzcnt  %ecx,%ecx
  822745:	jmp    8226b9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  82274a:	xor    %ecx,%ecx
  82274c:	jmp    8229b7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  822751:	movabs $0x1ffffffffffffffe,%rdi
  82275b:	and    %rax,%rdi
  82275e:	xor    %ecx,%ecx
  822760:	movdqa -0x774b68(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822768:	nopl   0x0(%rax,%rax,1)
  822770:	pxor   %xmm1,%xmm1
  822774:	pcmpgtb (%rsi,%rcx,1),%xmm1
  822779:	por    %xmm0,%xmm1
  82277d:	movdqa %xmm1,(%rsi,%rcx,1)
  822782:	pxor   %xmm1,%xmm1
  822786:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  82278c:	por    %xmm0,%xmm1
  822790:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  822796:	add    $0x20,%rcx
  82279a:	add    $0xfffffffffffffffe,%rdi
  82279e:	jne    822770 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  8227a0:	test   $0x1,%al
  8227a2:	je     8227ba <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  8227a4:	pxor   %xmm0,%xmm0
  8227a8:	pcmpgtb (%rsi,%rcx,1),%xmm0
  8227ad:	por    -0x774bb5(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  8227b5:	movdqa %xmm0,(%rsi,%rcx,1)
  8227ba:	cmp    $0x10,%rdx
  8227be:	jb     822a48 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  8227c4:	mov    %rdx,%rdi
  8227c7:	mov    $0x10,%edx
  8227cc:	add    %rsi,%rdi
  8227cf:	call   *0x65ef43(%rip)        # e81718 <memmove@GLIBC_2.2.5>
  8227d5:	movq   $0x0,0x28(%rsp)
  8227de:	movq   $0x20,0x30(%rsp)
  8227e7:	mov    %rbx,0x20(%rsp)
  8227ec:	xor    %r12d,%r12d
  8227ef:	xor    %r13d,%r13d
  8227f2:	jmp    822941 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  8227f7:	nopw   0x0(%rax,%rax,1)
  822800:	lea    (%rax,%rbp,1),%rsi
  822804:	add    $0xffffffffffffffe0,%rsi
  822808:	mov    0x8(%rsp),%rdi
  82280d:	call   8250e0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  822812:	mov    (%rbx),%rcx
  822815:	mov    0x8(%rbx),%rdx
  822819:	mov    %rdx,%rsi
  82281c:	and    %rax,%rsi
  82281f:	movdqu (%rcx,%rsi,1),%xmm0
  822824:	pmovmskb %xmm0,%edi
  822828:	mov    %rsi,%r8
  82282b:	test   %edi,%edi
  82282d:	je     8228d9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  822833:	tzcnt  %edi,%edi
  822837:	add    %r8,%rdi
  82283a:	and    %rdx,%rdi
  82283d:	cmpb   $0x0,(%rcx,%rdi,1)
  822841:	jns    822900 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  822847:	mov    %r12,%r8
  82284a:	sub    %rsi,%r8
  82284d:	mov    %rdi,%r9
  822850:	sub    %rsi,%r9
  822853:	xor    %r8,%r9
  822856:	and    %rdx,%r9
  822859:	cmp    $0x10,%r9
  82285d:	jb     822920 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  822863:	mov    %rdi,%rsi
  822866:	not    %rsi
  822869:	shl    $0x5,%rsi
  82286d:	add    %rcx,%rsi
  822870:	movzbl (%rcx,%rdi,1),%r8d
  822875:	shr    $0x39,%rax
  822879:	lea    -0x10(%rdi),%r9
  82287d:	and    %rdx,%r9
  822880:	mov    %al,(%rcx,%rdi,1)
  822883:	mov    (%rbx),%rcx
  822886:	mov    %al,0x10(%rcx,%r9,1)
  82288b:	cmp    $0xff,%r8b
  82288f:	je     822966 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  822895:	mov    (%r14),%rax
  822898:	mov    (%rsi),%rcx
  82289b:	mov    %rcx,(%r14)
  82289e:	mov    %rax,(%rsi)
  8228a1:	mov    0x8(%r14),%rax
  8228a5:	mov    0x8(%rsi),%rcx
  8228a9:	mov    %rcx,0x8(%r14)
  8228ad:	mov    %rax,0x8(%rsi)
  8228b1:	mov    0x10(%r14),%rax
  8228b5:	mov    0x10(%rsi),%rcx
  8228b9:	mov    %rcx,0x10(%r14)
  8228bd:	mov    %rax,0x10(%rsi)
  8228c1:	mov    0x18(%r14),%rax
  8228c5:	mov    0x18(%rsi),%rcx
  8228c9:	mov    %rcx,0x18(%r14)
  8228cd:	mov    %rax,0x18(%rsi)
  8228d1:	mov    (%rbx),%rax
  8228d4:	jmp    822800 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  8228d9:	mov    $0x10,%r9d
  8228df:	mov    %rsi,%r8
  8228e2:	add    %r9,%r8
  8228e5:	and    %rdx,%r8
  8228e8:	movdqu (%rcx,%r8,1),%xmm0
  8228ee:	pmovmskb %xmm0,%edi
  8228f2:	add    $0x10,%r9
  8228f6:	test   %edi,%edi
  8228f8:	jne    822833 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  8228fe:	jmp    8228e2 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  822900:	movdqa (%rcx),%xmm0
  822904:	pmovmskb %xmm0,%edi
  822908:	tzcnt  %edi,%edi
  82290c:	jmp    822847 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  822911:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  822920:	shr    $0x39,%rax
  822924:	lea    -0x10(%r12),%rsi
  822929:	and    %rsi,%rdx
  82292c:	mov    %al,(%rcx,%r12,1)
  822930:	mov    (%rbx),%rcx
  822933:	mov    %al,0x10(%rcx,%rdx,1)
  822937:	cmp    %r15,%r12
  82293a:	lea    0x1(%r12),%r12
  82293f:	je     822995 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  822941:	mov    (%rbx),%rax
  822944:	cmp    (%rax,%r12,1),%r13b
  822948:	jno    822937 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  82294a:	mov    %r12,%r14
  82294d:	not    %r14
  822950:	shl    $0x5,%r14
  822954:	add    %rax,%r14
  822957:	mov    %r12,%rbp
  82295a:	neg    %rbp
  82295d:	shl    $0x5,%rbp
  822961:	jmp    822800 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822966:	lea    -0x10(%r12),%rax
  82296b:	and    0x8(%rbx),%rax
  82296f:	mov    (%rbx),%rcx
  822972:	movb   $0xff,(%rcx,%r12,1)
  822977:	mov    (%rbx),%rcx
  82297a:	movb   $0xff,0x10(%rcx,%rax,1)
  82297f:	movdqu (%r14),%xmm0
  822984:	movdqu 0x10(%r14),%xmm1
  82298a:	movdqu %xmm1,0x10(%rsi)
  82298f:	movdqu %xmm0,(%rsi)
  822993:	jmp    822937 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  822995:	mov    0x8(%rbx),%rdx
  822999:	mov    0x18(%rbx),%rax
  82299d:	lea    0x1(%rdx),%rcx
  8229a1:	mov    %rcx,%rsi
  8229a4:	shr    $0x3,%rsi
  8229a8:	and    $0xfffffffffffffff8,%rcx
  8229ac:	sub    %rsi,%rcx
  8229af:	cmp    $0x8,%rdx
  8229b3:	cmovb  %rdx,%rcx
  8229b7:	sub    %rax,%rcx
  8229ba:	mov    %rcx,0x10(%rbx)
  8229be:	mov    $0xffffffffffffffff,%rax
  8229c5:	add    $0x58,%rsp
  8229c9:	pop    %rbx
  8229ca:	pop    %r12
  8229cc:	pop    %r13
  8229ce:	pop    %r14
  8229d0:	pop    %r15
  8229d2:	pop    %rbp
  8229d3:	ret
  8229d4:	mov    (%rsp),%rbx
  8229d8:	mov    0x18(%rbx),%rcx
  8229dc:	mov    0x10(%rsp),%rbp
  8229e1:	jmp    8229fc <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  8229e3:	movzbl %bpl,%edi
  8229e7:	mov    $0x10,%esi
  8229ec:	mov    %r13,%rdx
  8229ef:	call   *0x65ed2b(%rip)        # e81720 <_DYNAMIC+0x690>
  8229f5:	jmp    8229c5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8229f7:	mov    (%rbx),%rsi
  8229fa:	xor    %ecx,%ecx
  8229fc:	sub    %rcx,%rbp
  8229ff:	mov    %r15,(%rbx)
  822a02:	mov    0x8(%rbx),%rax
  822a06:	mov    %rdi,0x8(%rbx)
  822a0a:	mov    %rbp,0x10(%rbx)
  822a0e:	mov    %rcx,0x18(%rbx)
  822a12:	test   %rax,%rax
  822a15:	je     8229be <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822a17:	mov    %rax,%rcx
  822a1a:	shl    $0x5,%rcx
  822a1e:	add    $0x2f,%rcx
  822a22:	and    $0xffffffffffffffe0,%rcx
  822a26:	add    %rcx,%rax
  822a29:	add    $0x11,%rax
  822a2d:	je     8229be <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822a2f:	sub    %rcx,%rsi
  822a32:	mov    $0x10,%edx
  822a37:	mov    %rsi,%rdi
  822a3a:	mov    %rax,%rsi
  822a3d:	call   *0x65e895(%rip)        # e812d8 <_DYNAMIC+0x248>
  822a43:	jmp    8229be <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822a48:	mov    $0x10,%edi
  822a4d:	jmp    8227cc <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  822a52:	mov    %rax,%rbx
  822a55:	lea    0x20(%rsp),%rdi
  822a5a:	call   823030 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  822a5f:	mov    %rbx,%rdi
  822a62:	call   e2dda0 <_Unwind_Resume@plt>
  822a67:	mov    %rax,%rbx
  822a6a:	lea    0x20(%rsp),%rdi
  822a6f:	call   823070 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  822a74:	mov    %rbx,%rdi
  822a77:	call   e2dda0 <_Unwind_Resume@plt>
  822a7c:	call   *0x65e85e(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822a90 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  822a90:	push   %rbp
  822a91:	push   %r15
  822a93:	push   %r14
  822a95:	push   %r13
  822a97:	push   %r12
  822a99:	push   %rbx
  822a9a:	sub    $0x38,%rsp
  822a9e:	mov    %ecx,%r15d
  822aa1:	mov    %rdx,0x20(%rsp)
  822aa6:	mov    %rdi,%rbp
  822aa9:	mov    0x18(%rdi),%rdi
  822aad:	add    %rdi,%rsi
  822ab0:	jb     822bc8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822ab6:	mov    0x8(%rbp),%rbx
  822aba:	lea    0x1(%rbx),%rdx
  822abe:	mov    %rdx,%rax
  822ac1:	shr    $0x3,%rax
  822ac5:	mov    %rdx,%rcx
  822ac8:	and    $0xfffffffffffffff8,%rcx
  822acc:	sub    %rax,%rcx
  822acf:	cmp    $0x8,%rbx
  822ad3:	cmovb  %rbx,%rcx
  822ad7:	mov    %rcx,%rax
  822ada:	shr    $1,%rax
  822add:	cmp    %rax,%rsi
  822ae0:	jbe    822b16 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  822ae2:	inc    %rcx
  822ae5:	cmp    %rsi,%rcx
  822ae8:	cmovbe %rsi,%rcx
  822aec:	cmp    $0xf,%rcx
  822af0:	mov    %rbp,(%rsp)
  822af4:	mov    %rbx,0x30(%rsp)
  822af9:	jae    822b48 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  822afb:	mov    %ecx,%eax
  822afd:	and    $0x8,%eax
  822b00:	add    $0x8,%rax
  822b04:	cmp    $0x4,%rcx
  822b08:	mov    $0x4,%ebx
  822b0d:	cmovae %rax,%rbx
  822b11:	jmp    822ba0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  822b16:	test   %rdx,%rdx
  822b19:	je     822d5e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  822b1f:	mov    0x0(%rbp),%r12
  822b23:	mov    %rdx,%rax
  822b26:	shr    $0x4,%rax
  822b2a:	mov    %edx,%ecx
  822b2c:	and    $0xf,%ecx
  822b2f:	cmp    $0x1,%rcx
  822b33:	sbb    $0xffffffffffffffff,%rax
  822b37:	cmp    $0x1,%rax
  822b3b:	jne    822d65 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822b41:	xor    %ecx,%ecx
  822b43:	jmp    822db8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  822b48:	movabs $0x1ffffffffffffffe,%rax
  822b52:	inc    %rax
  822b55:	cmp    %rax,%rcx
  822b58:	ja     822bc8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822b5a:	shl    $0x3,%rcx
  822b5e:	movabs $0x2492492492492493,%rdx
  822b68:	mov    %rcx,%rax
  822b6b:	mul    %rdx
  822b6e:	sub    %rdx,%rcx
  822b71:	shr    $1,%rcx
  822b74:	add    %rdx,%rcx
  822b77:	shr    $0x2,%rcx
  822b7b:	dec    %rcx
  822b7e:	bsr    %rcx,%rcx
  822b82:	not    %ecx
  822b84:	mov    $0xffffffffffffffff,%rbx
  822b8b:	shr    %cl,%rbx
  822b8e:	movabs $0xffffffffffffffe,%rax
  822b98:	cmp    %rax,%rbx
  822b9b:	ja     822bc8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822b9d:	inc    %rbx
  822ba0:	mov    %rbx,%r14
  822ba3:	shl    $0x4,%r14
  822ba7:	lea    0x10(%rbx),%rbp
  822bab:	mov    %rbp,%r13
  822bae:	add    %r14,%r13
  822bb1:	setb   %al
  822bb4:	movabs $0x7ffffffffffffff0,%rcx
  822bbe:	cmp    %rcx,%r13
  822bc1:	seta   %cl
  822bc4:	or     %al,%cl
  822bc6:	je     822bd7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  822bc8:	movzbl %r15b,%edi
  822bcc:	call   *0x65eb36(%rip)        # e81708 <_DYNAMIC+0x678>
  822bd2:	jmp    822f98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822bd7:	mov    %rdi,0x8(%rsp)
  822bdc:	call   *0x65e73e(%rip)        # e81320 <_DYNAMIC+0x290>
  822be2:	mov    $0x10,%esi
  822be7:	mov    %r13,%rdi
  822bea:	call   *0x65e738(%rip)        # e81328 <_DYNAMIC+0x298>
  822bf0:	test   %rax,%rax
  822bf3:	je     822fb2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  822bf9:	mov    %rax,%rdi
  822bfc:	add    %r14,%rdi
  822bff:	lea    -0x1(%rbx),%rcx
  822c03:	mov    %rbx,%rax
  822c06:	shr    $0x3,%rax
  822c0a:	mov    %rbx,%r14
  822c0d:	and    $0xfffffffffffffff8,%r14
  822c11:	sub    %rax,%r14
  822c14:	cmp    $0x9,%rbx
  822c18:	mov    %rcx,0x10(%rsp)
  822c1d:	cmovb  %rcx,%r14
  822c21:	mov    %rdi,0x18(%rsp)
  822c26:	mov    $0xff,%esi
  822c2b:	mov    %rbp,%rdx
  822c2e:	call   *0x65eadc(%rip)        # e81710 <memset@GLIBC_2.2.5>
  822c34:	mov    0x8(%rsp),%rbx
  822c39:	test   %rbx,%rbx
  822c3c:	je     822fc6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  822c42:	mov    %r14,0x28(%rsp)
  822c47:	mov    (%rsp),%rax
  822c4b:	mov    (%rax),%rdi
  822c4e:	movdqa (%rdi),%xmm0
  822c52:	pmovmskb %xmm0,%r14d
  822c57:	not    %r14d
  822c5a:	xor    %ebp,%ebp
  822c5c:	mov    %rdi,%r13
  822c5f:	nop
  822c60:	test   %r14w,%r14w
  822c64:	jne    822c8f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  822c66:	cs nopw 0x0(%rax,%rax,1)
  822c70:	movdqa 0x10(%r13),%xmm0
  822c76:	add    $0x10,%r13
  822c7a:	pmovmskb %xmm0,%r14d
  822c7f:	xor    $0xffff,%r14d
  822c86:	add    $0x10,%rbp
  822c8a:	test   %r14d,%r14d
  822c8d:	je     822c70 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  822c8f:	tzcnt  %r14d,%r15d
  822c94:	add    %rbp,%r15
  822c97:	mov    %r15,%rax
  822c9a:	shl    $0x4,%rax
  822c9e:	mov    %rdi,%r12
  822ca1:	mov    %rdi,%rsi
  822ca4:	sub    %rax,%rsi
  822ca7:	add    $0xfffffffffffffff0,%rsi
  822cab:	mov    0x20(%rsp),%rdi
  822cb0:	call   825280 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822cb5:	mov    %rax,%rcx
  822cb8:	mov    0x10(%rsp),%r9
  822cbd:	and    %r9,%rcx
  822cc0:	mov    0x18(%rsp),%r8
  822cc5:	movdqu (%r8,%rcx,1),%xmm0
  822ccb:	pmovmskb %xmm0,%edx
  822ccf:	test   %edx,%edx
  822cd1:	je     822d30 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  822cd3:	tzcnt  %edx,%edx
  822cd7:	add    %rcx,%rdx
  822cda:	and    %r9,%rdx
  822cdd:	cmpb   $0x0,(%r8,%rdx,1)
  822ce2:	mov    %r12,%rdi
  822ce5:	jns    822d4f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  822ce7:	lea    -0x1(%r14),%ecx
  822ceb:	and    %r14d,%ecx
  822cee:	dec    %rbx
  822cf1:	shr    $0x39,%rax
  822cf5:	lea    -0x10(%rdx),%rsi
  822cf9:	and    %r9,%rsi
  822cfc:	mov    %al,(%r8,%rdx,1)
  822d00:	mov    %al,0x10(%r8,%rsi,1)
  822d05:	not    %r15
  822d08:	shl    $0x4,%r15
  822d0c:	not    %rdx
  822d0f:	shl    $0x4,%rdx
  822d13:	movdqu (%rdi,%r15,1),%xmm0
  822d19:	movdqu %xmm0,(%r8,%rdx,1)
  822d1f:	mov    %ecx,%r14d
  822d22:	test   %rbx,%rbx
  822d25:	jne    822c60 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  822d2b:	jmp    822fa7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  822d30:	mov    $0x10,%esi
  822d35:	add    %rsi,%rcx
  822d38:	and    %r9,%rcx
  822d3b:	movdqu (%r8,%rcx,1),%xmm0
  822d41:	pmovmskb %xmm0,%edx
  822d45:	add    $0x10,%rsi
  822d49:	test   %edx,%edx
  822d4b:	jne    822cd3 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  822d4d:	jmp    822d35 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  822d4f:	movdqa (%r8),%xmm0
  822d54:	pmovmskb %xmm0,%ecx
  822d58:	tzcnt  %ecx,%edx
  822d5c:	jmp    822ce7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  822d5e:	xor    %eax,%eax
  822d60:	jmp    822f8a <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  822d65:	movabs $0x1ffffffffffffffe,%rsi
  822d6f:	and    %rax,%rsi
  822d72:	xor    %ecx,%ecx
  822d74:	movdqa -0x77517c(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822d7c:	nopl   0x0(%rax)
  822d80:	pxor   %xmm1,%xmm1
  822d84:	pcmpgtb (%r12,%rcx,1),%xmm1
  822d8a:	por    %xmm0,%xmm1
  822d8e:	movdqa %xmm1,(%r12,%rcx,1)
  822d94:	pxor   %xmm1,%xmm1
  822d98:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  822d9f:	por    %xmm0,%xmm1
  822da3:	movdqa %xmm1,0x10(%r12,%rcx,1)
  822daa:	add    $0x20,%rcx
  822dae:	add    $0xfffffffffffffffe,%rsi
  822db2:	jne    822d80 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  822db4:	test   $0x1,%al
  822db6:	je     822dd0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  822db8:	pxor   %xmm0,%xmm0
  822dbc:	pcmpgtb (%r12,%rcx,1),%xmm0
  822dc2:	por    -0x7751ca(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822dca:	movdqa %xmm0,(%r12,%rcx,1)
  822dd0:	cmp    $0x10,%rdx
  822dd4:	jb     823023 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  822dda:	mov    %rdx,%rdi
  822ddd:	mov    $0x10,%edx
  822de2:	add    %r12,%rdi
  822de5:	mov    %r12,%rsi
  822de8:	call   *0x65e92a(%rip)        # e81718 <memmove@GLIBC_2.2.5>
  822dee:	xor    %r13d,%r13d
  822df1:	xor    %eax,%eax
  822df3:	jmp    822f26 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  822df8:	nopl   0x0(%rax,%rax,1)
  822e00:	lea    (%r12,%r14,1),%rsi
  822e04:	add    $0xfffffffffffffff0,%rsi
  822e08:	mov    0x20(%rsp),%rdi
  822e0d:	call   825280 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822e12:	mov    0x8(%rbp),%rcx
  822e16:	mov    %rcx,%rdx
  822e19:	and    %rax,%rdx
  822e1c:	movdqu (%r12,%rdx,1),%xmm0
  822e22:	pmovmskb %xmm0,%esi
  822e26:	mov    %rdx,%rdi
  822e29:	test   %esi,%esi
  822e2b:	je     822ebb <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  822e31:	tzcnt  %esi,%esi
  822e35:	add    %rdi,%rsi
  822e38:	and    %rcx,%rsi
  822e3b:	cmpb   $0x0,(%r12,%rsi,1)
  822e40:	jns    822ee2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  822e46:	mov    %r13,%rdi
  822e49:	sub    %rdx,%rdi
  822e4c:	mov    %rsi,%r8
  822e4f:	sub    %rdx,%r8
  822e52:	xor    %rdi,%r8
  822e55:	and    %rcx,%r8
  822e58:	cmp    $0x10,%r8
  822e5c:	jb     822f00 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  822e62:	mov    %rsi,%rdx
  822e65:	not    %rdx
  822e68:	shl    $0x4,%rdx
  822e6c:	add    %r12,%rdx
  822e6f:	movzbl (%r12,%rsi,1),%edi
  822e74:	shr    $0x39,%rax
  822e78:	lea    -0x10(%rsi),%r8
  822e7c:	and    %rcx,%r8
  822e7f:	mov    %al,(%r12,%rsi,1)
  822e83:	mov    0x0(%rbp),%r12
  822e87:	mov    %al,0x10(%r12,%r8,1)
  822e8c:	cmp    $0xff,%dil
  822e90:	je     822f4b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  822e96:	mov    (%rbx),%rax
  822e99:	mov    (%rdx),%rcx
  822e9c:	mov    %rcx,(%rbx)
  822e9f:	mov    %rax,(%rdx)
  822ea2:	mov    0x8(%rbx),%rax
  822ea6:	mov    0x8(%rdx),%rcx
  822eaa:	mov    %rcx,0x8(%rbx)
  822eae:	mov    %rax,0x8(%rdx)
  822eb2:	mov    0x0(%rbp),%r12
  822eb6:	jmp    822e00 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822ebb:	mov    $0x10,%r8d
  822ec1:	mov    %rdx,%rdi
  822ec4:	add    %r8,%rdi
  822ec7:	and    %rcx,%rdi
  822eca:	movdqu (%r12,%rdi,1),%xmm0
  822ed0:	pmovmskb %xmm0,%esi
  822ed4:	add    $0x10,%r8
  822ed8:	test   %esi,%esi
  822eda:	jne    822e31 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  822ee0:	jmp    822ec4 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  822ee2:	movdqa (%r12),%xmm0
  822ee8:	pmovmskb %xmm0,%esi
  822eec:	tzcnt  %esi,%esi
  822ef0:	jmp    822e46 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  822ef5:	data16 cs nopw 0x0(%rax,%rax,1)
  822f00:	shr    $0x39,%rax
  822f04:	lea    -0x10(%r13),%rdx
  822f08:	and    %rdx,%rcx
  822f0b:	mov    %al,(%r12,%r13,1)
  822f0f:	mov    0x0(%rbp),%r12
  822f13:	mov    %al,0x10(%r12,%rcx,1)
  822f18:	mov    %r15,%rbx
  822f1b:	xor    %eax,%eax
  822f1d:	cmp    %rbx,%r13
  822f20:	lea    0x1(%r13),%r13
  822f24:	je     822f68 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  822f26:	cmp    (%r12,%r13,1),%al
  822f2a:	jno    822f1d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  822f2c:	mov    %rbx,%r15
  822f2f:	mov    %r13,%rbx
  822f32:	not    %rbx
  822f35:	shl    $0x4,%rbx
  822f39:	add    %r12,%rbx
  822f3c:	mov    %r13,%r14
  822f3f:	neg    %r14
  822f42:	shl    $0x4,%r14
  822f46:	jmp    822e00 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822f4b:	lea    -0x10(%r13),%rax
  822f4f:	and    0x8(%rbp),%rax
  822f53:	movb   $0xff,(%r12,%r13,1)
  822f58:	movb   $0xff,0x10(%r12,%rax,1)
  822f5e:	movdqu (%rbx),%xmm0
  822f62:	movdqu %xmm0,(%rdx)
  822f66:	jmp    822f18 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  822f68:	mov    0x8(%rbp),%rcx
  822f6c:	mov    0x18(%rbp),%rdi
  822f70:	lea    0x1(%rcx),%rax
  822f74:	mov    %rax,%rdx
  822f77:	shr    $0x3,%rdx
  822f7b:	and    $0xfffffffffffffff8,%rax
  822f7f:	sub    %rdx,%rax
  822f82:	cmp    $0x8,%rcx
  822f86:	cmovb  %rcx,%rax
  822f8a:	sub    %rdi,%rax
  822f8d:	mov    %rax,0x10(%rbp)
  822f91:	mov    $0xffffffffffffffff,%rax
  822f98:	add    $0x38,%rsp
  822f9c:	pop    %rbx
  822f9d:	pop    %r12
  822f9f:	pop    %r13
  822fa1:	pop    %r14
  822fa3:	pop    %r15
  822fa5:	pop    %rbp
  822fa6:	ret
  822fa7:	mov    (%rsp),%rax
  822fab:	mov    0x28(%rsp),%r14
  822fb0:	jmp    822fd7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  822fb2:	movzbl %r15b,%edi
  822fb6:	mov    $0x10,%esi
  822fbb:	mov    %r13,%rdx
  822fbe:	call   *0x65e75c(%rip)        # e81720 <_DYNAMIC+0x690>
  822fc4:	jmp    822f98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822fc6:	mov    (%rsp),%rax
  822fca:	mov    (%rax),%rdi
  822fcd:	mov    0x18(%rsp),%r8
  822fd2:	mov    0x10(%rsp),%r9
  822fd7:	sub    0x8(%rsp),%r14
  822fdc:	mov    %r8,(%rax)
  822fdf:	mov    %r9,0x8(%rax)
  822fe3:	mov    %r14,0x10(%rax)
  822fe7:	mov    $0xffffffffffffffff,%rax
  822fee:	mov    0x30(%rsp),%rsi
  822ff3:	test   %rsi,%rsi
  822ff6:	je     822f98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822ff8:	mov    %rsi,%rcx
  822ffb:	shl    $0x4,%rcx
  822fff:	add    $0x1f,%rcx
  823003:	and    $0xfffffffffffffff0,%rcx
  823007:	add    %rcx,%rsi
  82300a:	add    $0x11,%rsi
  82300e:	je     822f98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  823010:	sub    %rcx,%rdi
  823013:	mov    $0x10,%edx
  823018:	call   *0x65e2ba(%rip)        # e812d8 <_DYNAMIC+0x248>
  82301e:	jmp    822f91 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  823023:	mov    $0x10,%edi
  823028:	jmp    822de2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008231e0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  8231e0:	mov    0x8(%rdi),%rsi
  8231e4:	test   %rsi,%rsi
  8231e7:	je     82320e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  8231e9:	mov    %rsi,%rax
  8231ec:	shl    $0x5,%rax
  8231f0:	add    %rax,%rsi
  8231f3:	add    $0x31,%rsi
  8231f7:	je     82320e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  8231f9:	mov    (%rdi),%rdi
  8231fc:	sub    %rax,%rdi
  8231ff:	add    $0xffffffffffffffe0,%rdi
  823203:	mov    $0x10,%edx
  823208:	jmp    *0x65e0ca(%rip)        # e812d8 <_DYNAMIC+0x248>
  82320e:	ret

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823210 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  823210:	push   %rbx
  823211:	test   %rdi,%rdi
  823214:	je     823277 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  823216:	mov    %rdi,%rbx
  823219:	mov    (%rdi),%rsi
  82321c:	test   %rsi,%rsi
  82321f:	je     823234 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  823221:	mov    0x8(%rbx),%rdi
  823225:	shl    $0x3,%rsi
  823229:	mov    $0x8,%edx
  82322e:	call   *0x65e0a4(%rip)        # e812d8 <_DYNAMIC+0x248>
  823234:	mov    0x20(%rbx),%rsi
  823238:	test   %rsi,%rsi
  82323b:	je     823263 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82323d:	mov    %rsi,%rax
  823240:	shl    $0x4,%rax
  823244:	add    %rax,%rsi
  823247:	add    $0x21,%rsi
  82324b:	je     823263 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82324d:	mov    0x18(%rbx),%rdi
  823251:	sub    %rax,%rdi
  823254:	add    $0xfffffffffffffff0,%rdi
  823258:	mov    $0x10,%edx
  82325d:	call   *0x65e075(%rip)        # e812d8 <_DYNAMIC+0x248>
  823263:	mov    $0x80,%esi
  823268:	mov    $0x8,%edx
  82326d:	mov    %rbx,%rdi
  823270:	pop    %rbx
  823271:	jmp    *0x65e061(%rip)        # e812d8 <_DYNAMIC+0x248>
  823277:	pop    %rbx
  823278:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008234a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8234a0:	push   %r14
  8234a2:	push   %rbx
  8234a3:	push   %rax
  8234a4:	mov    %rdi,%rbx
  8234a7:	mov    (%rdi),%rax
  8234aa:	lock decq (%rax)
  8234ae:	jne    8234b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  8234b0:	mov    %rbx,%rdi
  8234b3:	call   *0x65e0df(%rip)        # e81598 <_DYNAMIC+0x508>
  8234b9:	mov    0x8(%rbx),%rax
  8234bd:	lock decq (%rax)
  8234c1:	jne    8234d7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  8234c3:	add    $0x8,%rbx
  8234c7:	mov    %rbx,%rdi
  8234ca:	add    $0x8,%rsp
  8234ce:	pop    %rbx
  8234cf:	pop    %r14
  8234d1:	jmp    *0x65e0c9(%rip)        # e815a0 <_DYNAMIC+0x510>
  8234d7:	add    $0x8,%rsp
  8234db:	pop    %rbx
  8234dc:	pop    %r14
  8234de:	ret
  8234df:	mov    %rax,%r14
  8234e2:	mov    0x8(%rbx),%rax
  8234e6:	lock decq (%rax)
  8234ea:	jne    8234f9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  8234ec:	add    $0x8,%rbx
  8234f0:	mov    %rbx,%rdi
  8234f3:	call   *0x65e0a7(%rip)        # e815a0 <_DYNAMIC+0x510>
  8234f9:	mov    %r14,%rdi
  8234fc:	call   e2dda0 <_Unwind_Resume@plt>
  823501:	call   *0x65ddd9(%rip)        # e812e0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008235d0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  8235d0:	push   %rbx
  8235d1:	mov    %rdi,%rbx
  8235d4:	mov    (%rdi),%rsi
  8235d7:	test   %rsi,%rsi
  8235da:	je     8235ef <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  8235dc:	mov    0x8(%rbx),%rdi
  8235e0:	shl    $0x3,%rsi
  8235e4:	mov    $0x8,%edx
  8235e9:	call   *0x65dce9(%rip)        # e812d8 <_DYNAMIC+0x248>
  8235ef:	mov    0x20(%rbx),%rsi
  8235f3:	test   %rsi,%rsi
  8235f6:	je     82361f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  8235f8:	mov    %rsi,%rax
  8235fb:	shl    $0x4,%rax
  8235ff:	add    %rax,%rsi
  823602:	add    $0x21,%rsi
  823606:	je     82361f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823608:	mov    0x18(%rbx),%rdi
  82360c:	sub    %rax,%rdi
  82360f:	add    $0xfffffffffffffff0,%rdi
  823613:	mov    $0x10,%edx
  823618:	pop    %rbx
  823619:	jmp    *0x65dcb9(%rip)        # e812d8 <_DYNAMIC+0x248>
  82361f:	pop    %rbx
  823620:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823630 <<gpui_gpu::renderer::images::Images>::metadata>:
  823630:	push   %r15
  823632:	push   %r14
  823634:	push   %rbx
  823635:	sub    $0x10,%rsp
  823639:	mov    %rsi,0x8(%rsp)
  82363e:	cmpq   $0x0,0x30(%rdi)
  823643:	je     82370d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  823649:	mov    %edx,%ebx
  82364b:	mov    %rsi,%r14
  82364e:	mov    %rdi,%r15
  823651:	add    $0x38,%rdi
  823655:	lea    0x8(%rsp),%rsi
  82365a:	call   825280 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82365f:	mov    %rax,%rsi
  823662:	shr    $0x39,%rsi
  823666:	mov    0x18(%r15),%rcx
  82366a:	mov    0x20(%r15),%rdx
  82366e:	movd   %esi,%xmm0
  823672:	punpcklbw %xmm0,%xmm0
  823676:	pshuflw $0x0,%xmm0,%xmm0
  82367b:	pshufd $0x44,%xmm0,%xmm0
  823680:	xor    %esi,%esi
  823682:	pcmpeqd %xmm1,%xmm1
  823686:	and    %rdx,%rax
  823689:	movdqu (%rcx,%rax,1),%xmm2
  82368e:	movdqa %xmm2,%xmm3
  823692:	pcmpeqb %xmm0,%xmm3
  823696:	pmovmskb %xmm3,%edi
  82369a:	test   %edi,%edi
  82369c:	je     8236d0 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  82369e:	tzcnt  %edi,%r9d
  8236a3:	add    %rax,%r9
  8236a6:	and    %rdx,%r9
  8236a9:	shl    $0x4,%r9
  8236ad:	mov    %rcx,%r8
  8236b0:	sub    %r9,%r8
  8236b3:	cmp    -0x10(%r8),%r14
  8236b7:	je     8236e9 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  8236b9:	lea    -0x1(%rdi),%r8d
  8236bd:	and    %di,%r8w
  8236c1:	mov    %r8d,%edi
  8236c4:	jne    82369e <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  8236c6:	cs nopw 0x0(%rax,%rax,1)
  8236d0:	pcmpeqb %xmm1,%xmm2
  8236d4:	pmovmskb %xmm2,%edi
  8236d8:	test   %edi,%edi
  8236da:	jne    82370d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  8236dc:	add    %rsi,%rax
  8236df:	add    $0x10,%rax
  8236e3:	add    $0x10,%rsi
  8236e7:	jmp    823686 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  8236e9:	mov    -0x8(%r8),%eax
  8236ed:	movzbl %bl,%ecx
  8236f0:	or     -0x4(%r8),%ecx
  8236f4:	shl    $0x20,%rcx
  8236f8:	or     %rax,%rcx
  8236fb:	mov    $0x80000000,%eax
  823700:	or     %rcx,%rax
  823703:	add    $0x10,%rsp
  823707:	pop    %rbx
  823708:	pop    %r14
  82370a:	pop    %r15
  82370c:	ret
  82370d:	lea    -0x74ea90(%rip),%rdi        # d4c84 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  823714:	lea    0x60c5dd(%rip),%rdx        # e2fcf8 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677>
  82371b:	mov    $0x16,%esi
  823720:	call   *0x65df0a(%rip)        # e81630 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2722 frame=552

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823a90 <gpui_gpu::renderer::images::prepare>:
  823a90:	push   %rbp
  823a91:	push   %r15
  823a93:	push   %r14
  823a95:	push   %r13
  823a97:	push   %r12
  823a99:	push   %rbx
  823a9a:	sub    $0x1f8,%rsp
  823aa1:	mov    %r9,%r12
  823aa4:	mov    %rcx,%r13
  823aa7:	mov    %rdx,0xb8(%rsp)
  823aaf:	mov    %rsi,0x8(%rsp)
  823ab4:	mov    %rdi,%r15
  823ab7:	mov    0x230(%rsp),%rax
  823abf:	mov    0x10(%rax),%r14
  823ac3:	mov    0x118(%r14),%rax
  823aca:	add    $0x118,%r14
  823ad1:	test   %rax,%rax
  823ad4:	mov    %r14,%rcx
  823ad7:	cmove  %rax,%rcx
  823adb:	je     823b76 <gpui_gpu::renderer::images::prepare+0xe6>
  823ae1:	mov    0x10(%rax),%rax
  823ae5:	mov    (%r8),%rbp
  823ae8:	mov    %rax,0x18(%rsp)
  823aed:	test   %rax,%rax
  823af0:	je     823b79 <gpui_gpu::renderer::images::prepare+0xe9>
  823af6:	mov    %rcx,0xa8(%rsp)
  823afe:	test   %rbp,%rbp
  823b01:	je     823ccb <gpui_gpu::renderer::images::prepare+0x23b>
  823b07:	cmp    0x48(%rbp),%r12
  823b0b:	ja     823ccb <gpui_gpu::renderer::images::prepare+0x23b>
  823b11:	mov    0x8(%rbp),%rdi
  823b15:	mov    0x10(%rbp),%rax
  823b19:	lea    (%rdi,%rax,8),%rsi
  823b1d:	movq   $0x1,0xe0(%rsp)
  823b29:	mov    %r14,0xe8(%rsp)
  823b31:	movq   $0x0,0xf0(%rsp)
  823b3d:	movq   $0x0,0x100(%rsp)
  823b49:	lea    0xe0(%rsp),%rdx
  823b51:	mov    %r8,%rbx
  823b54:	call   8246a0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  823b59:	mov    %rbx,%r8
  823b5c:	test   %al,%al
  823b5e:	je     823ccb <gpui_gpu::renderer::images::prepare+0x23b>
  823b64:	movq   $0x0,0x60(%rbp)
  823b6c:	movb   $0x0,0x4(%r15)
  823b71:	jmp    823caf <gpui_gpu::renderer::images::prepare+0x21f>
  823b76:	mov    (%r8),%rbp
  823b79:	movq   $0x0,(%r8)
  823b80:	test   %rbp,%rbp
  823b83:	je     823ca7 <gpui_gpu::renderer::images::prepare+0x217>
  823b89:	mov    0x0(%rbp),%rsi
  823b8d:	test   %rsi,%rsi
  823b90:	je     823ba5 <gpui_gpu::renderer::images::prepare+0x115>
  823b92:	mov    0x8(%rbp),%rdi
  823b96:	shl    $0x3,%rsi
  823b9a:	mov    $0x8,%edx
  823b9f:	call   *0x65d733(%rip)        # e812d8 <_DYNAMIC+0x248>
  823ba5:	mov    0x20(%rbp),%rsi
  823ba9:	test   %rsi,%rsi
  823bac:	je     823bd4 <gpui_gpu::renderer::images::prepare+0x144>
  823bae:	mov    %rsi,%rax
  823bb1:	shl    $0x4,%rax
  823bb5:	add    %rax,%rsi
  823bb8:	add    $0x21,%rsi
  823bbc:	je     823bd4 <gpui_gpu::renderer::images::prepare+0x144>
  823bbe:	mov    0x18(%rbp),%rdi
  823bc2:	sub    %rax,%rdi
  823bc5:	add    $0xfffffffffffffff0,%rdi
  823bc9:	mov    $0x10,%edx
  823bce:	call   *0x65d704(%rip)        # e812d8 <_DYNAMIC+0x248>
  823bd4:	mov    $0x80,%esi
  823bd9:	mov    $0x8,%edx
  823bde:	mov    %rbp,%rdi
  823be1:	call   *0x65d6f1(%rip)        # e812d8 <_DYNAMIC+0x248>
  823be7:	shl    $0x4,%r12
  823beb:	cmp    $0x101,%r12
  823bf2:	mov    $0x100,%eax
  823bf7:	cmovae %r12,%rax
  823bfb:	dec    %rax
  823bfe:	bsr    %rax,%rcx
  823c02:	not    %ecx
  823c04:	mov    $0xffffffffffffffff,%rbx
  823c0b:	shr    %cl,%rbx
  823c0e:	inc    %rbx
  823c11:	lea    -0x74ef7e(%rip),%rax        # d4c9a <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x16>
  823c18:	mov    %rax,0x20(%rsp)
  823c1d:	movq   $0xa,0x28(%rsp)
  823c26:	mov    %rbx,0x30(%rsp)
  823c2b:	movl   $0x88,0x38(%rsp)
  823c33:	movb   $0x0,0x3c(%rsp)
  823c38:	lea    0xe0(%rsp),%rdi
  823c40:	lea    0x20(%rsp),%rdx
  823c45:	mov    0x8(%rsp),%rsi
  823c4a:	call   *0x65da60(%rip)        # e816b0 <_DYNAMIC+0x620>
  823c50:	mov    %rbx,0x100(%rsp)
  823c58:	mov    0x0(%r13),%rax
  823c5c:	lock decq (%rax)
  823c60:	jne    823c6b <gpui_gpu::renderer::images::prepare+0x1db>
  823c62:	mov    %r13,%rdi
  823c65:	call   *0x65d92d(%rip)        # e81598 <_DYNAMIC+0x508>
  823c6b:	mov    0x8(%r13),%rax
  823c6f:	lock decq (%rax)
  823c73:	jne    823c7f <gpui_gpu::renderer::images::prepare+0x1ef>
  823c75:	lea    0x8(%r13),%rdi
  823c79:	call   *0x65d921(%rip)        # e815a0 <_DYNAMIC+0x510>
  823c7f:	mov    0x100(%rsp),%rax
  823c87:	mov    %rax,0x20(%r13)
  823c8b:	movdqu 0xe0(%rsp),%xmm0
  823c94:	movups 0xf0(%rsp),%xmm1
  823c9c:	movups %xmm1,0x10(%r13)
  823ca1:	movdqu %xmm0,0x0(%r13)
  823ca7:	test   %rbp,%rbp
  823caa:	setne  0x4(%r15)
  823caf:	movl   $0xffffffff,(%r15)
  823cb6:	mov    %r15,%rax
  823cb9:	add    $0x1f8,%rsp
  823cc0:	pop    %rbx
  823cc1:	pop    %r12
  823cc3:	pop    %r13
  823cc5:	pop    %r14
  823cc7:	pop    %r15
  823cc9:	pop    %rbp
  823cca:	ret
  823ccb:	cmp    $0x1,%r12
  823ccf:	mov    %r12,%rax
  823cd2:	adc    $0xffffffffffffffff,%rax
  823cd6:	bsr    %rax,%rcx
  823cda:	not    %ecx
  823cdc:	mov    $0xffffffffffffffff,%rax
  823ce3:	shr    %cl,%rax
  823ce6:	cmp    $0x2,%r12
  823cea:	mov    $0x0,%r12d
  823cf0:	cmovae %rax,%r12
  823cf4:	inc    %r12
  823cf7:	je     824422 <gpui_gpu::renderer::images::prepare+0x992>
  823cfd:	mov    %r8,0xd0(%rsp)
  823d05:	mov    %fs:0x0,%rax
  823d0e:	lea    -0x28(%rax),%rax
  823d15:	mov    %rax,%rcx
  823d18:	cmpb   $0x1,0x10(%rax)
  823d1c:	mov    %r15,0xb0(%rsp)
  823d24:	mov    %r13,0xd8(%rsp)
  823d2c:	jne    82442e <gpui_gpu::renderer::images::prepare+0x99e>
  823d32:	mov    (%rcx),%rax
  823d35:	mov    0x8(%rcx),%rdx
  823d39:	mov    0x18(%rsp),%rbx
  823d3e:	lea    0x1(%rax),%rsi
  823d42:	mov    %rsi,(%rcx)
  823d45:	movq   $0x0,0x20(%rsp)
  823d4e:	movq   $0x8,0x28(%rsp)
  823d57:	movq   $0x0,0x30(%rsp)
  823d60:	movups 0x60bfa9(%rip),%xmm0        # e2fd10 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x18>
  823d67:	movups %xmm0,0x38(%rsp)
  823d6c:	movdqu 0x60bfac(%rip),%xmm0        # e2fd20 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x28>
  823d74:	movdqu %xmm0,0x48(%rsp)
  823d7a:	mov    %rax,0x58(%rsp)
  823d7f:	mov    %rdx,0x60(%rsp)
  823d84:	mov    %r12,0x68(%rsp)
  823d89:	pxor   %xmm0,%xmm0
  823d8d:	movdqu %xmm0,0x70(%rsp)
  823d93:	movdqu %xmm0,0x80(%rsp)
  823d9c:	movdqu %xmm0,0x90(%rsp)
  823da5:	lea    0xe0(%rsp),%rdi
  823dad:	mov    $0x8,%edx
  823db2:	mov    $0x8,%r8d
  823db8:	mov    $0x8,%r9d
  823dbe:	xor    %esi,%esi
  823dc0:	mov    %rbx,%rcx
  823dc3:	call   824cd0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823dc8:	cmpl   $0x1,0xe0(%rsp)
  823dd0:	jne    823e3d <gpui_gpu::renderer::images::prepare+0x3ad>
  823dd2:	mov    0xb0(%rsp),%r15
  823dda:	movl   $0x6,(%r15)
  823de1:	mov    0x20(%rsp),%rsi
  823de6:	test   %rsi,%rsi
  823de9:	je     823dff <gpui_gpu::renderer::images::prepare+0x36f>
  823deb:	mov    0x28(%rsp),%rdi
  823df0:	shl    $0x3,%rsi
  823df4:	mov    $0x8,%edx
  823df9:	call   *0x65d4d9(%rip)        # e812d8 <_DYNAMIC+0x248>
  823dff:	mov    0x40(%rsp),%rsi
  823e04:	test   %rsi,%rsi
  823e07:	je     823cb6 <gpui_gpu::renderer::images::prepare+0x226>
  823e0d:	mov    %rsi,%rax
  823e10:	shl    $0x4,%rax
  823e14:	add    %rax,%rsi
  823e17:	add    $0x21,%rsi
  823e1b:	je     823cb6 <gpui_gpu::renderer::images::prepare+0x226>
  823e21:	mov    0x38(%rsp),%rdi
  823e26:	sub    %rax,%rdi
  823e29:	add    $0xfffffffffffffff0,%rdi
  823e2d:	mov    $0x10,%edx
  823e32:	call   *0x65d4a0(%rip)        # e812d8 <_DYNAMIC+0x248>
  823e38:	jmp    823cb6 <gpui_gpu::renderer::images::prepare+0x226>
  823e3d:	mov    %r12,0xa0(%rsp)
  823e45:	mov    %rbp,0xc8(%rsp)
  823e4d:	mov    0xe8(%rsp),%rax
  823e55:	mov    %rax,0x28(%rsp)
  823e5a:	mov    %rbx,0x20(%rsp)
  823e5f:	cmp    0x48(%rsp),%rbx
  823e64:	ja     82444a <gpui_gpu::renderer::images::prepare+0x9ba>
  823e6a:	xor    %r12d,%r12d
  823e6d:	mov    0xa0(%rsp),%r15
  823e75:	jmp    823e98 <gpui_gpu::renderer::images::prepare+0x408>
  823e77:	nopw   0x0(%rax,%rax,1)
  823e80:	add    $0x8,%r12
  823e84:	mov    0x28(%rsp),%rax
  823e89:	mov    %rbx,(%rax,%r15,8)
  823e8d:	inc    %r15
  823e90:	mov    %r15,0x30(%rsp)
  823e95:	mov    %r13,%r15
  823e98:	test   %r12,%r12
  823e9b:	je     823ec0 <gpui_gpu::renderer::images::prepare+0x430>
  823e9d:	cmp    %rbp,%r12
  823ea0:	je     823ec0 <gpui_gpu::renderer::images::prepare+0x430>
  823ea2:	mov    (%r12),%rcx
  823ea6:	cmpb   $0x0,0x10(%rcx)
  823eaa:	je     823eee <gpui_gpu::renderer::images::prepare+0x45e>
  823eac:	mov    0x20(%rcx),%rax
  823eb0:	shl    $0x4,%rax
  823eb4:	mov    $0x8,%r8d
  823eba:	jmp    823f01 <gpui_gpu::renderer::images::prepare+0x471>
  823ebc:	nopl   0x0(%rax)
  823ec0:	test   %r14,%r14
  823ec3:	je     823f88 <gpui_gpu::renderer::images::prepare+0x4f8>
  823ec9:	mov    (%r14),%rax
  823ecc:	mov    0x10(%rax),%rcx
  823ed0:	test   %rcx,%rcx
  823ed3:	je     823f88 <gpui_gpu::renderer::images::prepare+0x4f8>
  823ed9:	mov    0x8(%rax),%r12
  823edd:	lea    (%r12,%rcx,8),%rbp
  823ee1:	xor    %r14d,%r14d
  823ee4:	mov    (%r12),%rcx
  823ee8:	cmpb   $0x0,0x10(%rcx)
  823eec:	jne    823eac <gpui_gpu::renderer::images::prepare+0x41c>
  823eee:	movzbl 0x11(%rcx),%edx
  823ef2:	movzbl 0x12(%rcx),%esi
  823ef6:	mov    0x20(%rcx),%rax
  823efa:	shl    $0x2,%edx
  823efd:	lea    (%rdx,%rsi,2),%r8d
  823f01:	mov    0x78(%rsp),%rdx
  823f06:	add    %rax,%rdx
  823f09:	jb     823dd2 <gpui_gpu::renderer::images::prepare+0x342>
  823f0f:	mov    0x28(%rcx),%rbx
  823f13:	mov    %rdx,0x78(%rsp)
  823f18:	cmp    $0x4000000,%rdx
  823f1f:	ja     823dd2 <gpui_gpu::renderer::images::prepare+0x342>
  823f25:	mov    %r15,%rcx
  823f28:	shr    $0x20,%rcx
  823f2c:	jne    823dd2 <gpui_gpu::renderer::images::prepare+0x342>
  823f32:	test   %r15d,%r15d
  823f35:	js     823dd2 <gpui_gpu::renderer::images::prepare+0x342>
  823f3b:	mov    %rax,%r13
  823f3e:	shr    $0x4,%r13
  823f42:	and    $0xf,%eax
  823f45:	add    %r15,%r13
  823f48:	cmp    $0x1,%rax
  823f4c:	sbb    $0xffffffffffffffff,%r13
  823f50:	lea    0xe0(%rsp),%rdi
  823f58:	lea    0x38(%rsp),%rsi
  823f5d:	mov    %rbx,%rdx
  823f60:	mov    %r15d,%ecx
  823f63:	call   827380 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  823f68:	mov    0x30(%rsp),%r15
  823f6d:	cmp    0x20(%rsp),%r15
  823f72:	jne    823e80 <gpui_gpu::renderer::images::prepare+0x3f0>
  823f78:	lea    0x20(%rsp),%rdi
  823f7d:	call   *0x65d7d5(%rip)        # e81758 <_DYNAMIC+0x6c8>
  823f83:	jmp    823e80 <gpui_gpu::renderer::images::prepare+0x3f0>
  823f88:	movabs $0xffffffffffffff0,%rax
  823f92:	cmp    %rax,%r15
  823f95:	ja     823dd2 <gpui_gpu::renderer::images::prepare+0x342>
  823f9b:	lea    0xe0(%rsp),%rdi
  823fa3:	mov    0x8(%rsp),%rsi
  823fa8:	call   *0x65d7b2(%rip)        # e81760 <_DYNAMIC+0x6d0>
  823fae:	mov    %r15,%rbx
  823fb1:	shl    $0x4,%rbx
  823fb5:	add    $0xff,%rbx
  823fbc:	and    $0xffffffffffffff00,%rbx
  823fc3:	cmp    0x130(%rsp),%rbx
  823fcb:	ja     823dd2 <gpui_gpu::renderer::images::prepare+0x342>
  823fd1:	lea    0xe0(%rsp),%rdi
  823fd9:	mov    0x8(%rsp),%rsi
  823fde:	call   *0x65d77c(%rip)        # e81760 <_DYNAMIC+0x6d0>
  823fe4:	cmp    0x140(%rsp),%rbx
  823fec:	ja     823dd2 <gpui_gpu::renderer::images::prepare+0x342>
  823ff2:	mov    0xd8(%rsp),%r14
  823ffa:	mov    0x20(%r14),%rax
  823ffe:	cmp    %rbx,%rax
  824001:	jb     824032 <gpui_gpu::renderer::images::prepare+0x5a2>
  824003:	lea    0x0(,%rbx,4),%rcx
  82400b:	movabs $0x3fffffffffffff1,%rdx
  824015:	cmp    %rdx,%r15
  824018:	setb   %dl
  82401b:	cmp    %rcx,%rax
  82401e:	seta   %al
  824021:	test   %al,%dl
  824023:	jne    824032 <gpui_gpu::renderer::images::prepare+0x5a2>
  824025:	movl   $0x0,0x14(%rsp)
  82402d:	jmp    8240c5 <gpui_gpu::renderer::images::prepare+0x635>
  824032:	lea    -0x74f395(%rip),%rax        # d4ca4 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x20>
  824039:	mov    %rax,0x1d8(%rsp)
  824041:	movq   $0x1d,0x1e0(%rsp)
  82404d:	mov    %rbx,0x1e8(%rsp)
  824055:	movl   $0x88,0x1f0(%rsp)
  824060:	movb   $0x0,0x1f4(%rsp)
  824068:	lea    0xe0(%rsp),%rdi
  824070:	lea    0x1d8(%rsp),%rdx
  824078:	mov    0x8(%rsp),%rsi
  82407d:	call   *0x65d62d(%rip)        # e816b0 <_DYNAMIC+0x620>
  824083:	mov    %rbx,0x100(%rsp)
  82408b:	mov    %r14,%r15
  82408e:	mov    %r14,%rdi
  824091:	call   8234a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  824096:	mov    0x100(%rsp),%rax
  82409e:	mov    %rax,0x20(%r15)
  8240a2:	movdqu 0xe0(%rsp),%xmm0
  8240ab:	movdqu 0xf0(%rsp),%xmm1
  8240b4:	movdqu %xmm1,0x10(%r15)
  8240ba:	movdqu %xmm0,(%r15)
  8240bf:	mov    $0x1,%al
  8240c1:	mov    %eax,0x14(%rsp)
  8240c5:	movq   $0x0,0x8(%rsp)
  8240ce:	mov    0x8(%rsp),%rdx
  8240d3:	test   %rdx,%rdx
  8240d6:	je     8240e2 <gpui_gpu::renderer::images::prepare+0x652>
  8240d8:	cmp    0xc0(%rsp),%rdx
  8240e0:	jne    82411f <gpui_gpu::renderer::images::prepare+0x68f>
  8240e2:	mov    0xa8(%rsp),%rax
  8240ea:	test   %rax,%rax
  8240ed:	je     8242b5 <gpui_gpu::renderer::images::prepare+0x825>
  8240f3:	mov    (%rax),%rax
  8240f6:	mov    0x10(%rax),%rcx
  8240fa:	test   %rcx,%rcx
  8240fd:	je     8242b5 <gpui_gpu::renderer::images::prepare+0x825>
  824103:	mov    0x8(%rax),%rdx
  824107:	lea    (%rdx,%rcx,8),%rax
  82410b:	mov    %rax,0xc0(%rsp)
  824113:	movq   $0x0,0xa8(%rsp)
  82411f:	mov    (%rdx),%rax
  824122:	mov    0x28(%rax),%r12
  824126:	movzbl 0x10(%rax),%ebx
  82412a:	mov    0x18(%rax),%rbp
  82412e:	mov    0x20(%rax),%r13
  824132:	mov    %r12,0xe0(%rsp)
  82413a:	cmpq   $0x0,0x50(%rsp)
  824140:	je     82429a <gpui_gpu::renderer::images::prepare+0x80a>
  824146:	add    $0x8,%rdx
  82414a:	mov    %rdx,0x8(%rsp)
  82414f:	lea    0x58(%rsp),%rdi
  824154:	lea    0xe0(%rsp),%rsi
  82415c:	call   825280 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  824161:	mov    %rax,%rsi
  824164:	shr    $0x39,%rsi
  824168:	mov    0x38(%rsp),%rcx
  82416d:	mov    0x40(%rsp),%rdx
  824172:	movd   %esi,%xmm0
  824176:	punpcklbw %xmm0,%xmm0
  82417a:	pshuflw $0x0,%xmm0,%xmm0
  82417f:	pshufd $0x44,%xmm0,%xmm0
  824184:	xor    %esi,%esi
  824186:	and    %rdx,%rax
  824189:	movdqu (%rcx,%rax,1),%xmm1
  82418e:	movdqa %xmm1,%xmm2
  824192:	pcmpeqb %xmm0,%xmm2
  824196:	pmovmskb %xmm2,%edi
  82419a:	test   %edi,%edi
  82419c:	je     8241c6 <gpui_gpu::renderer::images::prepare+0x736>
  82419e:	tzcnt  %edi,%r9d
  8241a3:	add    %rax,%r9
  8241a6:	and    %rdx,%r9
  8241a9:	shl    $0x4,%r9
  8241ad:	mov    %rcx,%r8
  8241b0:	sub    %r9,%r8
  8241b3:	cmp    -0x10(%r8),%r12
  8241b7:	je     8241e7 <gpui_gpu::renderer::images::prepare+0x757>
  8241b9:	lea    -0x1(%rdi),%r8d
  8241bd:	and    %di,%r8w
  8241c1:	mov    %r8d,%edi
  8241c4:	jne    82419e <gpui_gpu::renderer::images::prepare+0x70e>
  8241c6:	pcmpeqd %xmm2,%xmm2
  8241ca:	pcmpeqb %xmm2,%xmm1
  8241ce:	pmovmskb %xmm1,%edi
  8241d2:	test   %edi,%edi
  8241d4:	jne    82429a <gpui_gpu::renderer::images::prepare+0x80a>
  8241da:	add    %rsi,%rax
  8241dd:	add    $0x10,%rax
  8241e1:	add    $0x10,%rsi
  8241e5:	jmp    824186 <gpui_gpu::renderer::images::prepare+0x6f6>
  8241e7:	mov    -0x8(%r8),%r12d
  8241eb:	shl    $0x4,%r12
  8241ef:	test   %bl,%bl
  8241f1:	je     824248 <gpui_gpu::renderer::images::prepare+0x7b8>
  8241f3:	test   %r13,%r13
  8241f6:	je     8240ce <gpui_gpu::renderer::images::prepare+0x63e>
  8241fc:	nopl   0x0(%rax)
  824200:	cmp    $0x1000,%r13
  824207:	mov    $0x1000,%r15d
  82420d:	cmovb  %r13,%r15
  824211:	mov    %r15d,%ebx
  824214:	shl    $0x4,%ebx
  824217:	mov    0xb8(%rsp),%rdi
  82421f:	mov    %r14,%rsi
  824222:	mov    %r12,%rdx
  824225:	mov    %rbp,%rcx
  824228:	mov    %rbx,%r8
  82422b:	call   *0x65d42f(%rip)        # e81660 <_DYNAMIC+0x5d0>
  824231:	mov    %r15,%rax
  824234:	shl    $0x4,%rax
  824238:	add    %rax,%rbp
  82423b:	add    %rbx,%r12
  82423e:	sub    %r15,%r13
  824241:	jne    824200 <gpui_gpu::renderer::images::prepare+0x770>
  824243:	jmp    8240ce <gpui_gpu::renderer::images::prepare+0x63e>
  824248:	test   %r13,%r13
  82424b:	je     8240ce <gpui_gpu::renderer::images::prepare+0x63e>
  824251:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824260:	cmp    $0x10000,%r13
  824267:	mov    $0x10000,%ebx
  82426c:	cmovb  %r13,%rbx
  824270:	mov    0xb8(%rsp),%rdi
  824278:	mov    %r14,%rsi
  82427b:	mov    %r12,%rdx
  82427e:	mov    %rbp,%rcx
  824281:	mov    %rbx,%r8
  824284:	call   *0x65d3d6(%rip)        # e81660 <_DYNAMIC+0x5d0>
  82428a:	add    %rbx,%rbp
  82428d:	add    %rbx,%r12
  824290:	sub    %rbx,%r13
  824293:	jne    824260 <gpui_gpu::renderer::images::prepare+0x7d0>
  824295:	jmp    8240ce <gpui_gpu::renderer::images::prepare+0x63e>
  82429a:	lea    -0x74f61d(%rip),%rdi        # d4c84 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  8242a1:	lea    0x60ba88(%rip),%rdx        # e2fd30 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x38>
  8242a8:	mov    $0x16,%esi
  8242ad:	call   *0x65d37d(%rip)        # e81630 <_DYNAMIC+0x5a0>
  8242b3:	ud2
  8242b5:	mov    0x18(%rsp),%rax
  8242ba:	mov    %rax,0x70(%rsp)
  8242bf:	mov    0x78(%rsp),%rax
  8242c4:	mov    %rax,0x80(%rsp)
  8242cc:	mov    0xa0(%rsp),%rax
  8242d4:	shl    $0x4,%rax
  8242d8:	mov    %rax,0x88(%rsp)
  8242e0:	mov    0x20(%r14),%rax
  8242e4:	mov    %rax,0x90(%rsp)
  8242ec:	mov    0x48(%rsp),%rax
  8242f1:	add    0x50(%rsp),%rax
  8242f6:	mov    %rax,0x98(%rsp)
  8242fe:	mov    0x90(%rsp),%rax
  824306:	mov    %rax,0x150(%rsp)
  82430e:	mov    0x98(%rsp),%rax
  824316:	mov    %rax,0x158(%rsp)
  82431e:	mov    0x80(%rsp),%rax
  824326:	mov    %rax,0x140(%rsp)
  82432e:	mov    0x88(%rsp),%rax
  824336:	mov    %rax,0x148(%rsp)
  82433e:	movups 0x70(%rsp),%xmm0
  824343:	movaps %xmm0,0x130(%rsp)
  82434b:	movups 0x60(%rsp),%xmm0
  824350:	movaps %xmm0,0x120(%rsp)
  824358:	movups 0x50(%rsp),%xmm0
  82435d:	movaps %xmm0,0x110(%rsp)
  824365:	movups 0x20(%rsp),%xmm0
  82436a:	movups 0x30(%rsp),%xmm1
  82436f:	movups 0x40(%rsp),%xmm2
  824374:	movaps %xmm2,0x100(%rsp)
  82437c:	movaps %xmm1,0xf0(%rsp)
  824384:	movaps %xmm0,0xe0(%rsp)
  82438c:	call   823a60 <alloc::boxed::box_new_uninit>
  824391:	mov    %rax,%rbx
  824394:	movaps 0x150(%rsp),%xmm0
  82439c:	movups %xmm0,0x70(%rax)
  8243a0:	movaps 0x140(%rsp),%xmm0
  8243a8:	movups %xmm0,0x60(%rax)
  8243ac:	movaps 0x130(%rsp),%xmm0
  8243b4:	movups %xmm0,0x50(%rax)
  8243b8:	movaps 0x120(%rsp),%xmm0
  8243c0:	movups %xmm0,0x40(%rax)
  8243c4:	movdqa 0xe0(%rsp),%xmm0
  8243cd:	movaps 0xf0(%rsp),%xmm1
  8243d5:	movaps 0x100(%rsp),%xmm2
  8243dd:	movaps 0x110(%rsp),%xmm3
  8243e5:	movups %xmm3,0x30(%rax)
  8243e9:	movups %xmm2,0x20(%rax)
  8243ed:	movups %xmm1,0x10(%rax)
  8243f1:	movdqu %xmm0,(%rax)
  8243f5:	mov    0xc8(%rsp),%rdi
  8243fd:	call   823210 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  824402:	mov    0xd0(%rsp),%rax
  82440a:	mov    %rbx,(%rax)
  82440d:	mov    0xb0(%rsp),%r15
  824415:	mov    0x14(%rsp),%eax
  824419:	mov    %al,0x4(%r15)
  82441d:	jmp    823caf <gpui_gpu::renderer::images::prepare+0x21f>
  824422:	movl   $0x6,(%r15)
  824429:	jmp    823cb6 <gpui_gpu::renderer::images::prepare+0x226>
  82442e:	mov    %rcx,%rbx
  824431:	call   *0x65d281(%rip)        # e816b8 <_DYNAMIC+0x628>
  824437:	mov    %rbx,%rcx
  82443a:	mov    %rax,(%rbx)
  82443d:	mov    %rdx,0x8(%rbx)
  824441:	movb   $0x1,0x10(%rbx)
  824445:	jmp    823d39 <gpui_gpu::renderer::images::prepare+0x2a9>
  82444a:	lea    0x38(%rsp),%rdi
  82444f:	mov    0x18(%rsp),%rsi
  824454:	lea    0x58(%rsp),%rdx
  824459:	xor    %ecx,%ecx
  82445b:	call   *0x65d2cf(%rip)        # e81730 <_DYNAMIC+0x6a0>
  824461:	cmp    $0xffffffffffffffff,%rax
  824465:	jne    823dd2 <gpui_gpu::renderer::images::prepare+0x342>
  82446b:	jmp    823e6a <gpui_gpu::renderer::images::prepare+0x3da>
  824470:	mov    %rax,%rbx
  824473:	lea    0xe0(%rsp),%rdi
  82447b:	call   8235d0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  824480:	mov    %rbx,%rdi
  824483:	call   e2dda0 <_Unwind_Resume@plt>
  824488:	mov    %rax,%rbx
  82448b:	mov    0x100(%rsp),%rax
  824493:	mov    %rax,0x20(%r15)
  824497:	movups 0xe0(%rsp),%xmm0
  82449f:	movups 0xf0(%rsp),%xmm1
  8244a7:	movups %xmm1,0x10(%r15)
  8244ac:	movups %xmm0,(%r15)
  8244b0:	lea    0x20(%rsp),%rdi
  8244b5:	call   8235d0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8244ba:	mov    %rbx,%rdi
  8244bd:	call   e2dda0 <_Unwind_Resume@plt>
  8244c2:	mov    %r13,%r14
  8244c5:	mov    %rax,%rbx
  8244c8:	jmp    8244e4 <gpui_gpu::renderer::images::prepare+0xa54>
  8244ca:	mov    %rax,%rbx
  8244cd:	mov    %r13,%r14
  8244d0:	mov    0x8(%r13),%rax
  8244d4:	lock decq (%rax)
  8244d8:	jne    8244e4 <gpui_gpu::renderer::images::prepare+0xa54>
  8244da:	lea    0x8(%r14),%rdi
  8244de:	call   *0x65d0bc(%rip)        # e815a0 <_DYNAMIC+0x510>
  8244e4:	mov    0x100(%rsp),%rax
  8244ec:	mov    %rax,0x20(%r14)
  8244f0:	movups 0xe0(%rsp),%xmm0
  8244f8:	movups 0xf0(%rsp),%xmm1
  824500:	movups %xmm1,0x10(%r14)
  824505:	movups %xmm0,(%r14)
  824509:	mov    %rbx,%rdi
  82450c:	call   e2dda0 <_Unwind_Resume@plt>
  824511:	call   *0x65cdc9(%rip)        # e812e0 <_DYNAMIC+0x250>
  824517:	jmp    82451d <gpui_gpu::renderer::images::prepare+0xa8d>
  824519:	jmp    82451d <gpui_gpu::renderer::images::prepare+0xa8d>
  82451b:	jmp    82451d <gpui_gpu::renderer::images::prepare+0xa8d>
  82451d:	mov    %rax,%rbx
  824520:	lea    0x20(%rsp),%rdi
  824525:	call   8235d0 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  82452a:	mov    %rbx,%rdi
  82452d:	call   e2dda0 <_Unwind_Resume@plt>

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008246a0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  8246a0:	push   %r15
  8246a2:	push   %r14
  8246a4:	push   %rbx
  8246a5:	mov    (%rdx),%r9
  8246a8:	mov    0x8(%rdx),%r11
  8246ac:	mov    0x10(%rdx),%rbx
  8246b0:	mov    0x18(%rdx),%r10
  8246b4:	mov    0x20(%rdx),%r8
  8246b8:	mov    0x28(%rdx),%rcx
  8246bc:	test   $0x1,%r9b
  8246c0:	jne    82475a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  8246c6:	mov    %rbx,%rax
  8246c9:	jmp    8246eb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  8246cb:	nopl   0x0(%rax,%rax,1)
  8246d0:	lea    0x8(%rax),%rbx
  8246d4:	mov    %rbx,%r14
  8246d7:	add    $0x8,%rdi
  8246db:	mov    (%rax),%r15
  8246de:	mov    %r14,%rax
  8246e1:	cmp    0x28(%r15),%rdx
  8246e5:	jne    8247af <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8246eb:	cmp    %rsi,%rdi
  8246ee:	je     824788 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  8246f4:	mov    (%rdi),%rdx
  8246f7:	test   %rax,%rax
  8246fa:	je     824703 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  8246fc:	cmp    %r10,%rax
  8246ff:	jne    8246d0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  824701:	xor    %ebx,%ebx
  824703:	xor    %eax,%eax
  824705:	test   %r8,%r8
  824708:	je     8247b1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82470e:	cmp    %rcx,%r8
  824711:	je     8247b1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  824717:	mov    %r8,%rax
  82471a:	add    $0x8,%r8
  82471e:	xor    %r14d,%r14d
  824721:	jmp    8246d7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  824723:	mov    (%r11),%rax
  824726:	mov    0x8(%rax),%rbx
  82472a:	mov    0x10(%rax),%rax
  82472e:	lea    (%rbx,%rax,8),%r10
  824732:	test   %rax,%rax
  824735:	je     824771 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  824737:	xor    %r11d,%r11d
  82473a:	nopw   0x0(%rax,%rax,1)
  824740:	mov    %r8,%rax
  824743:	mov    %rbx,%r8
  824746:	add    $0x8,%rbx
  82474a:	add    $0x8,%rdi
  82474e:	mov    (%r8),%r14
  824751:	mov    %rax,%r8
  824754:	cmp    0x28(%r14),%rdx
  824758:	jne    8247af <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82475a:	cmp    %rsi,%rdi
  82475d:	je     824788 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  82475f:	mov    (%rdi),%rdx
  824762:	test   %rbx,%rbx
  824765:	je     82476c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  824767:	cmp    %r10,%rbx
  82476a:	jne    824740 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  82476c:	test   %r11,%r11
  82476f:	jne    824723 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  824771:	xor    %eax,%eax
  824773:	test   %r8,%r8
  824776:	je     8247b1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  824778:	cmp    %rcx,%r8
  82477b:	je     8247b1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82477d:	lea    0x8(%r8),%rax
  824781:	xor    %ebx,%ebx
  824783:	xor    %r11d,%r11d
  824786:	jmp    82474a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  824788:	test   %rbx,%rbx
  82478b:	sete   %dl
  82478e:	cmp    %r10,%rbx
  824791:	sete   %al
  824794:	or     %dl,%al
  824796:	test   $0x1,%r9b
  82479a:	je     8247b7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  82479c:	test   %al,%al
  82479e:	je     8247af <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8247a0:	test   %r11,%r11
  8247a3:	je     8247bb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8247a5:	mov    (%r11),%rax
  8247a8:	cmpq   $0x0,0x10(%rax)
  8247ad:	je     8247bb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8247af:	xor    %eax,%eax
  8247b1:	pop    %rbx
  8247b2:	pop    %r14
  8247b4:	pop    %r15
  8247b6:	ret
  8247b7:	test   %al,%al
  8247b9:	je     8247af <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8247bb:	test   %r8,%r8
  8247be:	sete   %dl
  8247c1:	cmp    %rcx,%r8
  8247c4:	sete   %al
  8247c7:	or     %dl,%al
  8247c9:	pop    %rbx
  8247ca:	pop    %r14
  8247cc:	pop    %r15
  8247ce:	ret

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008247d0 <gpui_gpu::renderer::slots::color_word>:
  8247d0:	lea    -0x3(%rsi),%eax
  8247d3:	cmp    %rax,%rdi
  8247d6:	jbe    8247ef <gpui_gpu::renderer::slots::color_word+0x1f>
  8247d8:	mov    %rdi,%rax
  8247db:	shr    $0x6,%rax
  8247df:	and    $0x3f,%edi
  8247e2:	cmp    $0x1,%rdi
  8247e6:	sbb    $0xffffffff,%eax
  8247e9:	add    %esi,%eax
  8247eb:	add    $0xfffffffe,%eax
  8247ee:	ret
  8247ef:	push   %rax
  8247f0:	lea    -0x74fb36(%rip),%rdi        # d4cc1 <anon.627181f3f10afc1966f799818b5539e5.19.llvm.1634448222410874261>
  8247f7:	lea    0x60b54a(%rip),%rdx        # e2fd48 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261>
  8247fe:	mov    $0x1e,%esi
  824803:	call   *0x65cdef(%rip)        # e815f8 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=694 frame=120

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824810 <gpui_gpu::renderer::slots::write_prefix>:
  824810:	push   %rbp
  824811:	push   %r15
  824813:	push   %r14
  824815:	push   %r13
  824817:	push   %r12
  824819:	push   %rbx
  82481a:	sub    $0x48,%rsp
  82481e:	mov    %rsi,0x8(%rsp)
  824823:	test   %rcx,%rcx
  824826:	je     824a6a <gpui_gpu::renderer::slots::write_prefix+0x25a>
  82482c:	mov    %rdi,0x18(%rsp)
  824831:	xor    %r12d,%r12d
  824834:	test   $0x3f,%cl
  824837:	setne  %al
  82483a:	cmpq   $0x0,0x8(%rsp)
  824840:	je     824ab0 <gpui_gpu::renderer::slots::write_prefix+0x2a0>
  824846:	mov    %r8,%r14
  824849:	mov    %rcx,%r10
  82484c:	shr    $0x6,%r10
  824850:	mov    %al,%r12b
  824853:	lea    (%r10,%r12,1),%r9
  824857:	lea    (%r10,%r12,1),%rax
  82485b:	inc    %rax
  82485e:	mov    %eax,%esi
  824860:	mov    %r9,%rdi
  824863:	shl    $0x20,%rdi
  824867:	mov    %ecx,%r8d
  82486a:	mov    0x18(%rsp),%rbx
  82486f:	xor    0x8(%rbx),%rsi
  824873:	or     %rdi,%r8
  824876:	xor    (%rbx),%r8
  824879:	or     %rsi,%r8
  82487c:	mov    %r10,0x10(%rsp)
  824881:	jne    82488c <gpui_gpu::renderer::slots::write_prefix+0x7c>
  824883:	mov    (%r14),%rbp
  824886:	mov    0x8(%r14),%r13
  82488a:	jmp    8248b5 <gpui_gpu::renderer::slots::write_prefix+0xa5>
  82488c:	mov    0x8(%r14),%r13
  824890:	movq   $0x0,(%r14)
  824897:	cmp    $0x1,%r13
  82489b:	adc    $0x0,%r13
  82489f:	mov    %r13,0x8(%r14)
  8248a3:	mov    %ecx,(%rbx)
  8248a5:	mov    %r9d,0x4(%rbx)
  8248a9:	mov    %eax,0x8(%rbx)
  8248ac:	movl   $0x0,0xc(%rbx)
  8248b3:	xor    %ebp,%ebp
  8248b5:	mov    %r9,%r15
  8248b8:	mov    %rdx,%rdi
  8248bb:	call   *0x65cd77(%rip)        # e81638 <_DYNAMIC+0x5a8>
  8248c1:	mov    0x8(%rsp),%rcx
  8248c6:	dec    %rcx
  8248c9:	mov    %rcx,0x40(%rsp)
  8248ce:	mov    0x10(%rsp),%rcx
  8248d3:	shl    $0x4,%rcx
  8248d7:	shl    $0x4,%r12d
  8248db:	add    %rcx,%r12
  8248de:	lea    (%rbx,%r12,1),%r9
  8248e2:	add    $0x10,%r9
  8248e6:	xor    %r12d,%r12d
  8248e9:	xorps  %xmm0,%xmm0
  8248ec:	mov    %r15,0x38(%rsp)
  8248f1:	mov    %r15,%r10
  8248f4:	jmp    824916 <gpui_gpu::renderer::slots::write_prefix+0x106>
  8248f6:	cs nopw 0x0(%rax,%rax,1)
  824900:	add    $0x40,%r10
  824904:	add    $0x400,%r9
  82490b:	cmp    0x38(%rsp),%r12
  824910:	je     824a6a <gpui_gpu::renderer::slots::write_prefix+0x25a>
  824916:	mov    %r12,0x10(%rsp)
  82491b:	lea    0x1(%r12),%rcx
  824920:	mov    %rcx,0x30(%rsp)
  824925:	movaps %xmm0,0x20(%rsp)
  82492a:	mov    $0xffffffffffffffc0,%rsi
  824931:	xor    %r12d,%r12d
  824934:	jmp    824951 <gpui_gpu::renderer::slots::write_prefix+0x141>
  824936:	cs nopw 0x0(%rax,%rax,1)
  824940:	add    $0x18,%rax
  824944:	add    $0x2,%r12
  824948:	inc    %rsi
  82494b:	je     824a00 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  824951:	cmp    %rdx,%rax
  824954:	je     824a00 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  82495a:	lea    0x40(%rsi),%r8
  82495e:	movzwl 0x10(%rax),%ebx
  824962:	movzwl 0x12(%rax),%ecx
  824966:	mov    (%rax),%r11d
  824969:	mov    0x4(%rax),%edi
  82496c:	mov    0x8(%rax),%r15
  824970:	shr    $0xe,%ecx
  824973:	and    $0x2,%ecx
  824976:	shr    $0xf,%ebx
  824979:	or     %ecx,%ebx
  82497b:	mov    %r12d,%ecx
  82497e:	and    $0x1e,%cl
  824981:	shl    %cl,%ebx
  824983:	shr    $0x4,%r8
  824987:	or     %ebx,0x20(%rsp,%r8,4)
  82498c:	lea    (%r10,%rsi,1),%r8
  824990:	add    $0x41,%r8
  824994:	cmp    0x8(%rsp),%r8
  824999:	jae    824a79 <gpui_gpu::renderer::slots::write_prefix+0x269>
  82499f:	mov    %rdi,%rcx
  8249a2:	shl    $0x20,%rcx
  8249a6:	mov    %r11d,%ebx
  8249a9:	or     %rcx,%rbx
  8249ac:	mov    0x8(%r9,%r12,8),%rcx
  8249b1:	xor    %r15,%rcx
  8249b4:	xor    (%r9,%r12,8),%rbx
  8249b8:	or     %rcx,%rbx
  8249bb:	je     824940 <gpui_gpu::renderer::slots::write_prefix+0x130>
  8249bd:	mov    %r15d,%ecx
  8249c0:	shr    $0x20,%r15
  8249c4:	cmp    %rbp,%r8
  8249c7:	cmovb  %r8,%rbp
  8249cb:	mov    %rbp,(%r14)
  8249ce:	lea    (%r10,%rsi,1),%r8
  8249d2:	add    $0x42,%r8
  8249d6:	cmp    %r13,%r8
  8249d9:	cmova  %r8,%r13
  8249dd:	mov    %r13,0x8(%r14)
  8249e1:	mov    %r11d,(%r9,%r12,8)
  8249e5:	mov    %edi,0x4(%r9,%r12,8)
  8249ea:	mov    %ecx,0x8(%r9,%r12,8)
  8249ef:	mov    %r15d,0xc(%r9,%r12,8)
  8249f4:	jmp    824940 <gpui_gpu::renderer::slots::write_prefix+0x130>
  8249f9:	nopl   0x0(%rax)
  824a00:	mov    0x10(%rsp),%r15
  824a05:	cmp    0x40(%rsp),%r15
  824a0a:	je     824a95 <gpui_gpu::renderer::slots::write_prefix+0x285>
  824a10:	mov    0x20(%rsp),%rcx
  824a15:	mov    0x28(%rsp),%rsi
  824a1a:	lea    0x1(%r15),%r12
  824a1e:	mov    %r12,%rdi
  824a21:	shl    $0x4,%rdi
  824a25:	mov    0x18(%rsp),%rbx
  824a2a:	mov    0x8(%rbx,%rdi,1),%r8
  824a2f:	xor    %rsi,%r8
  824a32:	mov    (%rbx,%rdi,1),%r11
  824a36:	xor    %rcx,%r11
  824a39:	or     %r8,%r11
  824a3c:	je     824900 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  824a42:	add    %rbx,%rdi
  824a45:	cmp    %rbp,%r12
  824a48:	cmovb  %r12,%rbp
  824a4c:	add    $0x2,%r15
  824a50:	cmp    %r13,%r15
  824a53:	cmova  %r15,%r13
  824a57:	mov    %rbp,(%r14)
  824a5a:	mov    %r13,0x8(%r14)
  824a5e:	mov    %rsi,0x8(%rdi)
  824a62:	mov    %rcx,(%rdi)
  824a65:	jmp    824900 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  824a6a:	add    $0x48,%rsp
  824a6e:	pop    %rbx
  824a6f:	pop    %r12
  824a71:	pop    %r13
  824a73:	pop    %r14
  824a75:	pop    %r15
  824a77:	pop    %rbp
  824a78:	ret
  824a79:	add    %r10,%rsi
  824a7c:	add    $0x42,%rsi
  824a80:	lea    0x60b031(%rip),%rcx        # e2fab8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793>
  824a87:	mov    %r8,%rdi
  824a8a:	mov    0x8(%rsp),%rdx
  824a8f:	call   *0x65cb43(%rip)        # e815d8 <_DYNAMIC+0x548>
  824a95:	mov    0x8(%rsp),%rdx
  824a9a:	lea    0x1(%rdx),%rsi
  824a9e:	lea    0x60b013(%rip),%rcx        # e2fab8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793>
  824aa5:	mov    0x30(%rsp),%rdi
  824aaa:	call   *0x65cb28(%rip)        # e815d8 <_DYNAMIC+0x548>
  824ab0:	lea    0x60b001(%rip),%rcx        # e2fab8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793>
  824ab7:	mov    $0x1,%esi
  824abc:	xor    %edi,%edi
  824abe:	xor    %edx,%edx
  824ac0:	call   *0x65cb12(%rip)        # e815d8 <_DYNAMIC+0x548>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824c60 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  824c60:	push   %r14
  824c62:	push   %rbx
  824c63:	sub    $0x18,%rsp
  824c67:	mov    %rdi,%rbx
  824c6a:	mov    (%rdi),%rsi
  824c6d:	lea    (%rsi,%rsi,1),%rax
  824c71:	cmp    $0x5,%rax
  824c75:	mov    $0x4,%r14d
  824c7b:	cmovae %rax,%r14
  824c7f:	mov    0x8(%rdi),%rdx
  824c83:	mov    %rsp,%rdi
  824c86:	mov    $0x4,%r8d
  824c8c:	mov    $0x20,%r9d
  824c92:	mov    %r14,%rcx
  824c95:	call   824cd0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  824c9a:	cmpl   $0x1,(%rsp)
  824c9e:	je     824cb4 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  824ca0:	mov    0x8(%rsp),%rax
  824ca5:	mov    %rax,0x8(%rbx)
  824ca9:	mov    %r14,(%rbx)
  824cac:	add    $0x18,%rsp
  824cb0:	pop    %rbx
  824cb1:	pop    %r14
  824cb3:	ret
  824cb4:	mov    0x8(%rsp),%rdi
  824cb9:	mov    0x10(%rsp),%rsi
  824cbe:	call   *0x65c654(%rip)        # e81318 <_DYNAMIC+0x288>

FUNCTION <gpui_gpu::renderer::coverage::Interval>::add bytes=366 frame=0

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008253e0 <<gpui_gpu::renderer::coverage::Interval>::add>:
  8253e0:	xorpd  %xmm4,%xmm4
  8253e4:	ucomisd %xmm4,%xmm2
  8253e8:	jne    8253f4 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  8253ea:	jp     8253f4 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  8253ec:	ucomisd %xmm4,%xmm3
  8253f0:	jne    8253f4 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  8253f2:	jnp    82540c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  8253f4:	ucomisd %xmm4,%xmm0
  8253f8:	jne    82541f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  8253fa:	jp     82541f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  8253fc:	ucomisd %xmm4,%xmm1
  825400:	jne    82541f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  825402:	jp     82541f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  825404:	movapd %xmm2,%xmm0
  825408:	movapd %xmm3,%xmm1
  82540c:	movsd  %xmm0,0x8(%rdi)
  825411:	movsd  %xmm1,0x10(%rdi)
  825416:	mov    $0x1,%ecx
  82541b:	mov    %rcx,(%rdi)
  82541e:	ret
  82541f:	addsd  %xmm2,%xmm0
  825423:	addsd  %xmm3,%xmm1
  825427:	movq   %xmm0,%rdx
  82542c:	movq   %xmm1,%rcx
  825431:	ucomisd %xmm0,%xmm0
  825435:	setp   %al
  825438:	movabs $0xfff0000000000000,%rsi
  825442:	cmp    %rsi,%rdx
  825445:	sete   %sil
  825449:	or     %al,%sil
  82544c:	movabs $0x7fffffffffffffff,%rax
  825456:	jne    82547e <<gpui_gpu::renderer::coverage::Interval>::add+0x9e>
  825458:	mov    %rdx,%rsi
  82545b:	and    %rax,%rsi
  82545e:	je     82546a <<gpui_gpu::renderer::coverage::Interval>::add+0x8a>
  825460:	cmp    %rsi,%rdx
  825463:	jne    825476 <<gpui_gpu::renderer::coverage::Interval>::add+0x96>
  825465:	dec    %rdx
  825468:	jmp    825479 <<gpui_gpu::renderer::coverage::Interval>::add+0x99>
  82546a:	movabs $0x8000000000000001,%rdx
  825474:	jmp    825479 <<gpui_gpu::renderer::coverage::Interval>::add+0x99>
  825476:	inc    %rdx
  825479:	movq   %rdx,%xmm0
  82547e:	ucomisd %xmm1,%xmm1
  825482:	setp   %dl
  825485:	movabs $0x7ff0000000000000,%rsi
  82548f:	cmp    %rsi,%rcx
  825492:	sete   %sil
  825496:	or     %dl,%sil
  825499:	jne    8254bc <<gpui_gpu::renderer::coverage::Interval>::add+0xdc>
  82549b:	mov    %rcx,%rdx
  82549e:	and    %rax,%rdx
  8254a1:	je     8254ad <<gpui_gpu::renderer::coverage::Interval>::add+0xcd>
  8254a3:	cmp    %rdx,%rcx
  8254a6:	jne    8254b4 <<gpui_gpu::renderer::coverage::Interval>::add+0xd4>
  8254a8:	inc    %rcx
  8254ab:	jmp    8254b7 <<gpui_gpu::renderer::coverage::Interval>::add+0xd7>
  8254ad:	mov    $0x1,%ecx
  8254b2:	jmp    8254b7 <<gpui_gpu::renderer::coverage::Interval>::add+0xd7>
  8254b4:	dec    %rcx
  8254b7:	movq   %rcx,%xmm1
  8254bc:	movq   %xmm0,%rdx
  8254c1:	and    %rax,%rdx
  8254c4:	xor    %ecx,%ecx
  8254c6:	movabs $0x7fefffffffffffff,%rsi
  8254d0:	cmp    %rsi,%rdx
  8254d3:	jg     82554a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  8254d5:	ucomisd %xmm1,%xmm0
  8254d9:	ja     82554a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  8254db:	xorpd  %xmm2,%xmm2
  8254df:	ucomisd %xmm2,%xmm0
  8254e3:	jne    8254f6 <<gpui_gpu::renderer::coverage::Interval>::add+0x116>
  8254e5:	jp     8254f6 <<gpui_gpu::renderer::coverage::Interval>::add+0x116>
  8254e7:	movq   %xmm1,%rcx
  8254ec:	and    %rax,%rcx
  8254ef:	cmp    %rsi,%rcx
  8254f2:	jle    82551e <<gpui_gpu::renderer::coverage::Interval>::add+0x13e>
  8254f4:	jmp    825548 <<gpui_gpu::renderer::coverage::Interval>::add+0x168>
  8254f6:	dec    %rdx
  8254f9:	movq   %xmm1,%rcx
  8254fe:	and    %rax,%rcx
  825501:	cmp    %rsi,%rcx
  825504:	setg   %sil
  825508:	xor    %ecx,%ecx
  82550a:	movabs $0xfffffffffffff,%r8
  825514:	cmp    %r8,%rdx
  825517:	jb     82554a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  825519:	test   %sil,%sil
  82551c:	jne    82554a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  82551e:	ucomisd %xmm2,%xmm1
  825522:	jne    82552a <<gpui_gpu::renderer::coverage::Interval>::add+0x14a>
  825524:	jnp    82540c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  82552a:	movq   %xmm1,%rcx
  82552f:	and    %rax,%rcx
  825532:	dec    %rcx
  825535:	movabs $0xfffffffffffff,%rax
  82553f:	cmp    %rax,%rcx
  825542:	jae    82540c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  825548:	xor    %ecx,%ecx
  82554a:	mov    %rcx,(%rdi)
  82554d:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::scale bytes=446 frame=0

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825550 <<gpui_gpu::renderer::coverage::Interval>::scale>:
  825550:	movq   %xmm2,%rdx
  825555:	movabs $0x7fffffffffffffff,%rax
  82555f:	and    %rax,%rdx
  825562:	movabs $0x7fefffffffffffff,%rcx
  82556c:	cmp    %rcx,%rdx
  82556f:	jle    825577 <<gpui_gpu::renderer::coverage::Interval>::scale+0x27>
  825571:	xor    %edx,%edx
  825573:	mov    %rdx,(%rdi)
  825576:	ret
  825577:	xorpd  %xmm3,%xmm3
  82557b:	ucomisd %xmm3,%xmm2
  82557f:	jne    825595 <<gpui_gpu::renderer::coverage::Interval>::scale+0x45>
  825581:	jp     825595 <<gpui_gpu::renderer::coverage::Interval>::scale+0x45>
  825583:	xorpd  %xmm0,%xmm0
  825587:	movupd %xmm0,0x8(%rdi)
  82558c:	mov    $0x1,%edx
  825591:	mov    %rdx,(%rdi)
  825594:	ret
  825595:	dec    %rdx
  825598:	movabs $0xffffffffffffe,%rsi
  8255a2:	cmp    %rsi,%rdx
  8255a5:	jbe    825571 <<gpui_gpu::renderer::coverage::Interval>::scale+0x21>
  8255a7:	ucomisd %xmm3,%xmm0
  8255ab:	jne    8255b7 <<gpui_gpu::renderer::coverage::Interval>::scale+0x67>
  8255ad:	jp     8255b7 <<gpui_gpu::renderer::coverage::Interval>::scale+0x67>
  8255af:	ucomisd %xmm3,%xmm1
  8255b3:	jne    8255b7 <<gpui_gpu::renderer::coverage::Interval>::scale+0x67>
  8255b5:	jnp    825583 <<gpui_gpu::renderer::coverage::Interval>::scale+0x33>
  8255b7:	ucomisd %xmm3,%xmm2
  8255bb:	cmpltsd %xmm2,%xmm3
  8255c0:	movapd %xmm3,%xmm4
  8255c4:	andpd  %xmm0,%xmm4
  8255c8:	andnpd %xmm1,%xmm3
  8255cc:	orpd   %xmm4,%xmm3
  8255d0:	ja     8255d6 <<gpui_gpu::renderer::coverage::Interval>::scale+0x86>
  8255d2:	movapd %xmm0,%xmm1
  8255d6:	mulsd  %xmm2,%xmm1
  8255da:	mulsd  %xmm2,%xmm3
  8255de:	movq   %xmm3,%rsi
  8255e3:	movq   %xmm1,%rdx
  8255e8:	ucomisd %xmm3,%xmm3
  8255ec:	setp   %r8b
  8255f0:	movabs $0xfff0000000000000,%r9
  8255fa:	cmp    %r9,%rsi
  8255fd:	sete   %r9b
  825601:	or     %r8b,%r9b
  825604:	jne    82562c <<gpui_gpu::renderer::coverage::Interval>::scale+0xdc>
  825606:	mov    %rsi,%r8
  825609:	and    %rax,%r8
  82560c:	je     825618 <<gpui_gpu::renderer::coverage::Interval>::scale+0xc8>
  82560e:	cmp    %r8,%rsi
  825611:	jne    825624 <<gpui_gpu::renderer::coverage::Interval>::scale+0xd4>
  825613:	dec    %rsi
  825616:	jmp    825627 <<gpui_gpu::renderer::coverage::Interval>::scale+0xd7>
  825618:	movabs $0x8000000000000001,%rsi
  825622:	jmp    825627 <<gpui_gpu::renderer::coverage::Interval>::scale+0xd7>
  825624:	inc    %rsi
  825627:	movq   %rsi,%xmm3
  82562c:	ucomisd %xmm1,%xmm1
  825630:	setp   %sil
  825634:	movabs $0x7ff0000000000000,%r8
  82563e:	cmp    %r8,%rdx
  825641:	sete   %r8b
  825645:	or     %sil,%r8b
  825648:	jne    82566b <<gpui_gpu::renderer::coverage::Interval>::scale+0x11b>
  82564a:	mov    %rdx,%rsi
  82564d:	and    %rax,%rsi
  825650:	je     82565c <<gpui_gpu::renderer::coverage::Interval>::scale+0x10c>
  825652:	cmp    %rsi,%rdx
  825655:	jne    825663 <<gpui_gpu::renderer::coverage::Interval>::scale+0x113>
  825657:	inc    %rdx
  82565a:	jmp    825666 <<gpui_gpu::renderer::coverage::Interval>::scale+0x116>
  82565c:	mov    $0x1,%edx
  825661:	jmp    825666 <<gpui_gpu::renderer::coverage::Interval>::scale+0x116>
  825663:	dec    %rdx
  825666:	movq   %rdx,%xmm1
  82566b:	movq   %xmm3,%rsi
  825670:	and    %rax,%rsi
  825673:	xor    %edx,%edx
  825675:	cmp    %rcx,%rsi
  825678:	jg     825573 <<gpui_gpu::renderer::coverage::Interval>::scale+0x23>
  82567e:	ucomisd %xmm1,%xmm3
  825682:	ja     825573 <<gpui_gpu::renderer::coverage::Interval>::scale+0x23>
  825688:	xorpd  %xmm0,%xmm0
  82568c:	ucomisd %xmm0,%xmm3
  825690:	jne    8256a7 <<gpui_gpu::renderer::coverage::Interval>::scale+0x157>
  825692:	jp     8256a7 <<gpui_gpu::renderer::coverage::Interval>::scale+0x157>
  825694:	movq   %xmm1,%rdx
  825699:	and    %rax,%rdx
  82569c:	cmp    %rcx,%rdx
  82569f:	jg     825571 <<gpui_gpu::renderer::coverage::Interval>::scale+0x21>
  8256a5:	jmp    8256d5 <<gpui_gpu::renderer::coverage::Interval>::scale+0x185>
  8256a7:	dec    %rsi
  8256aa:	movq   %xmm1,%rdx
  8256af:	and    %rax,%rdx
  8256b2:	cmp    %rcx,%rdx
  8256b5:	setg   %cl
  8256b8:	xor    %edx,%edx
  8256ba:	movabs $0xfffffffffffff,%r8
  8256c4:	cmp    %r8,%rsi
  8256c7:	jb     825573 <<gpui_gpu::renderer::coverage::Interval>::scale+0x23>
  8256cd:	test   %cl,%cl
  8256cf:	jne    825573 <<gpui_gpu::renderer::coverage::Interval>::scale+0x23>
  8256d5:	ucomisd %xmm0,%xmm1
  8256d9:	jne    8256dd <<gpui_gpu::renderer::coverage::Interval>::scale+0x18d>
  8256db:	jnp    8256fb <<gpui_gpu::renderer::coverage::Interval>::scale+0x1ab>
  8256dd:	movq   %xmm1,%rcx
  8256e2:	and    %rax,%rcx
  8256e5:	dec    %rcx
  8256e8:	movabs $0xfffffffffffff,%rax
  8256f2:	cmp    %rax,%rcx
  8256f5:	jb     825571 <<gpui_gpu::renderer::coverage::Interval>::scale+0x21>
  8256fb:	movsd  %xmm3,0x8(%rdi)
  825700:	movsd  %xmm1,0x10(%rdi)
  825705:	mov    $0x1,%edx
  82570a:	mov    %rdx,(%rdi)
  82570d:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::checked bytes=187 frame=0

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825710 <<gpui_gpu::renderer::coverage::Interval>::checked>:
  825710:	movq   %xmm0,%rdx
  825715:	ucomisd %xmm1,%xmm0
  825719:	seta   %sil
  82571d:	movabs $0x7fffffffffffffff,%rax
  825727:	and    %rax,%rdx
  82572a:	movabs $0x7fefffffffffffff,%rcx
  825734:	cmp    %rcx,%rdx
  825737:	setg   %r8b
  82573b:	or     %sil,%r8b
  82573e:	je     825746 <<gpui_gpu::renderer::coverage::Interval>::checked+0x36>
  825740:	xor    %eax,%eax
  825742:	mov    %rax,(%rdi)
  825745:	ret
  825746:	xorpd  %xmm2,%xmm2
  82574a:	ucomisd %xmm2,%xmm0
  82574e:	jne    825765 <<gpui_gpu::renderer::coverage::Interval>::checked+0x55>
  825750:	jp     825765 <<gpui_gpu::renderer::coverage::Interval>::checked+0x55>
  825752:	movq   %xmm1,%rdx
  825757:	and    %rax,%rdx
  82575a:	cmp    %rcx,%rdx
  82575d:	jle    825790 <<gpui_gpu::renderer::coverage::Interval>::checked+0x80>
  82575f:	xor    %eax,%eax
  825761:	mov    %rax,(%rdi)
  825764:	ret
  825765:	dec    %rdx
  825768:	movabs $0xfffffffffffff,%rsi
  825772:	cmp    %rsi,%rdx
  825775:	setb   %dl
  825778:	movq   %xmm1,%rsi
  82577d:	and    %rax,%rsi
  825780:	cmp    %rcx,%rsi
  825783:	setg   %cl
  825786:	or     %dl,%cl
  825788:	je     825790 <<gpui_gpu::renderer::coverage::Interval>::checked+0x80>
  82578a:	xor    %eax,%eax
  82578c:	mov    %rax,(%rdi)
  82578f:	ret
  825790:	ucomisd %xmm2,%xmm1
  825794:	jne    825798 <<gpui_gpu::renderer::coverage::Interval>::checked+0x88>
  825796:	jnp    8257b8 <<gpui_gpu::renderer::coverage::Interval>::checked+0xa8>
  825798:	movq   %xmm1,%rcx
  82579d:	and    %rax,%rcx
  8257a0:	dec    %rcx
  8257a3:	movabs $0xfffffffffffff,%rax
  8257ad:	cmp    %rax,%rcx
  8257b0:	jae    8257b8 <<gpui_gpu::renderer::coverage::Interval>::checked+0xa8>
  8257b2:	xor    %eax,%eax
  8257b4:	mov    %rax,(%rdi)
  8257b7:	ret
  8257b8:	movsd  %xmm0,0x8(%rdi)
  8257bd:	movsd  %xmm1,0x10(%rdi)
  8257c2:	mov    $0x1,%eax
  8257c7:	mov    %rax,(%rdi)
  8257ca:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::subtract bytes=382 frame=0

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008257d0 <<gpui_gpu::renderer::coverage::Interval>::subtract>:
  8257d0:	xorpd  %xmm4,%xmm4
  8257d4:	ucomisd %xmm4,%xmm2
  8257d8:	jne    8257e4 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  8257da:	jp     8257e4 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  8257dc:	ucomisd %xmm4,%xmm3
  8257e0:	jne    8257e4 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  8257e2:	jnp    82580c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  8257e4:	ucomisd %xmm4,%xmm0
  8257e8:	jne    82581f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  8257ea:	jp     82581f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  8257ec:	ucomisd %xmm4,%xmm1
  8257f0:	jne    82581f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  8257f2:	jp     82581f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  8257f4:	movapd -0x77763c(%rip),%xmm0        # ae1c0 <anon.630a3fff68f6bca64b568be97512ab45.90.llvm.826976926275214120+0x90>
  8257fc:	xorpd  %xmm0,%xmm2
  825800:	xorpd  %xmm0,%xmm3
  825804:	movapd %xmm3,%xmm0
  825808:	movapd %xmm2,%xmm1
  82580c:	movsd  %xmm0,0x8(%rdi)
  825811:	movsd  %xmm1,0x10(%rdi)
  825816:	mov    $0x1,%ecx
  82581b:	mov    %rcx,(%rdi)
  82581e:	ret
  82581f:	subsd  %xmm3,%xmm0
  825823:	subsd  %xmm2,%xmm1
  825827:	movq   %xmm0,%rdx
  82582c:	movq   %xmm1,%rcx
  825831:	ucomisd %xmm0,%xmm0
  825835:	setp   %al
  825838:	movabs $0xfff0000000000000,%rsi
  825842:	cmp    %rsi,%rdx
  825845:	sete   %sil
  825849:	or     %al,%sil
  82584c:	movabs $0x7fffffffffffffff,%rax
  825856:	jne    82587e <<gpui_gpu::renderer::coverage::Interval>::subtract+0xae>
  825858:	mov    %rdx,%rsi
  82585b:	and    %rax,%rsi
  82585e:	je     82586a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x9a>
  825860:	cmp    %rsi,%rdx
  825863:	jne    825876 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa6>
  825865:	dec    %rdx
  825868:	jmp    825879 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa9>
  82586a:	movabs $0x8000000000000001,%rdx
  825874:	jmp    825879 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa9>
  825876:	inc    %rdx
  825879:	movq   %rdx,%xmm0
  82587e:	ucomisd %xmm1,%xmm1
  825882:	setp   %dl
  825885:	movabs $0x7ff0000000000000,%rsi
  82588f:	cmp    %rsi,%rcx
  825892:	sete   %sil
  825896:	or     %dl,%sil
  825899:	jne    8258bc <<gpui_gpu::renderer::coverage::Interval>::subtract+0xec>
  82589b:	mov    %rcx,%rdx
  82589e:	and    %rax,%rdx
  8258a1:	je     8258ad <<gpui_gpu::renderer::coverage::Interval>::subtract+0xdd>
  8258a3:	cmp    %rdx,%rcx
  8258a6:	jne    8258b4 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe4>
  8258a8:	inc    %rcx
  8258ab:	jmp    8258b7 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe7>
  8258ad:	mov    $0x1,%ecx
  8258b2:	jmp    8258b7 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe7>
  8258b4:	dec    %rcx
  8258b7:	movq   %rcx,%xmm1
  8258bc:	movq   %xmm0,%rdx
  8258c1:	and    %rax,%rdx
  8258c4:	xor    %ecx,%ecx
  8258c6:	movabs $0x7fefffffffffffff,%rsi
  8258d0:	cmp    %rsi,%rdx
  8258d3:	jg     82594a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  8258d5:	ucomisd %xmm1,%xmm0
  8258d9:	ja     82594a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  8258db:	xorpd  %xmm2,%xmm2
  8258df:	ucomisd %xmm2,%xmm0
  8258e3:	jne    8258f6 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x126>
  8258e5:	jp     8258f6 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x126>
  8258e7:	movq   %xmm1,%rcx
  8258ec:	and    %rax,%rcx
  8258ef:	cmp    %rsi,%rcx
  8258f2:	jle    82591e <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14e>
  8258f4:	jmp    825948 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x178>
  8258f6:	dec    %rdx
  8258f9:	movq   %xmm1,%rcx
  8258fe:	and    %rax,%rcx
  825901:	cmp    %rsi,%rcx
  825904:	setg   %sil
  825908:	xor    %ecx,%ecx
  82590a:	movabs $0xfffffffffffff,%r8
  825914:	cmp    %r8,%rdx
  825917:	jb     82594a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  825919:	test   %sil,%sil
  82591c:	jne    82594a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  82591e:	ucomisd %xmm2,%xmm1
  825922:	jne    82592a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x15a>
  825924:	jnp    82580c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  82592a:	movq   %xmm1,%rcx
  82592f:	and    %rax,%rcx
  825932:	dec    %rcx
  825935:	movabs $0xfffffffffffff,%rax
  82593f:	cmp    %rax,%rcx
  825942:	jae    82580c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  825948:	xor    %ecx,%ecx
  82594a:	mov    %rcx,(%rdi)
  82594d:	ret

FUNCTION gpui_gpu::renderer::coverage::axis bytes=2744 frame=376

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825950 <gpui_gpu::renderer::coverage::axis>:
  825950:	push   %r15
  825952:	push   %r14
  825954:	push   %r13
  825956:	push   %r12
  825958:	push   %rbx
  825959:	sub    $0x150,%rsp
  825960:	movq   %xmm4,%r12
  825965:	movabs $0x7fffffffffffffff,%rbx
  82596f:	and    %rbx,%r12
  825972:	mov    $0x2,%al
  825974:	movabs $0x7fefffffffffffff,%r14
  82597e:	cmp    %r14,%r12
  825981:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825987:	movapd %xmm0,%xmm15
  82598c:	movq   (%rdi),%xmm8
  825991:	movq   0x8(%rdi),%xmm13
  825997:	movq   0x10(%rdi),%xmm10
  82599d:	xorpd  %xmm0,%xmm0
  8259a1:	ucomisd %xmm0,%xmm4
  8259a5:	jne    8259a9 <gpui_gpu::renderer::coverage::axis+0x59>
  8259a7:	jnp    8259c1 <gpui_gpu::renderer::coverage::axis+0x71>
  8259a9:	lea    -0x1(%r12),%rcx
  8259ae:	movabs $0xfffffffffffff,%rdx
  8259b8:	cmp    %rdx,%rcx
  8259bb:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8259c1:	movq   %xmm5,%r15
  8259c6:	and    %rbx,%r15
  8259c9:	cmp    %r14,%r15
  8259cc:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8259d2:	ucomisd %xmm0,%xmm5
  8259d6:	jne    8259da <gpui_gpu::renderer::coverage::axis+0x8a>
  8259d8:	jnp    8259f1 <gpui_gpu::renderer::coverage::axis+0xa1>
  8259da:	lea    -0x1(%r15),%rcx
  8259de:	movabs $0xfffffffffffff,%rdx
  8259e8:	cmp    %rdx,%rcx
  8259eb:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8259f1:	movq   %xmm8,%rdx
  8259f6:	and    %rbx,%rdx
  8259f9:	cmp    %r14,%rdx
  8259fc:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825a02:	xorpd  %xmm11,%xmm11
  825a07:	ucomisd %xmm11,%xmm8
  825a0c:	xorpd  %xmm12,%xmm12
  825a11:	jne    825e54 <gpui_gpu::renderer::coverage::axis+0x504>
  825a17:	jp     825e54 <gpui_gpu::renderer::coverage::axis+0x504>
  825a1d:	movq   %xmm13,%rdx
  825a22:	and    %rbx,%rdx
  825a25:	cmp    %r14,%rdx
  825a28:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825a2e:	movapd %xmm1,%xmm14
  825a33:	ucomisd %xmm0,%xmm13
  825a38:	xorpd  %xmm9,%xmm9
  825a3d:	xorpd  %xmm1,%xmm1
  825a41:	jne    825f08 <gpui_gpu::renderer::coverage::axis+0x5b8>
  825a47:	jp     825f08 <gpui_gpu::renderer::coverage::axis+0x5b8>
  825a4d:	ucomisd %xmm0,%xmm9
  825a52:	jne    825a5e <gpui_gpu::renderer::coverage::axis+0x10e>
  825a54:	jp     825a5e <gpui_gpu::renderer::coverage::axis+0x10e>
  825a56:	ucomisd %xmm0,%xmm1
  825a5a:	jne    825a5e <gpui_gpu::renderer::coverage::axis+0x10e>
  825a5c:	jnp    825a8a <gpui_gpu::renderer::coverage::axis+0x13a>
  825a5e:	ucomisd %xmm0,%xmm11
  825a63:	jne    825fbd <gpui_gpu::renderer::coverage::axis+0x66d>
  825a69:	jp     825fbd <gpui_gpu::renderer::coverage::axis+0x66d>
  825a6f:	ucomisd %xmm0,%xmm12
  825a74:	jne    825fbd <gpui_gpu::renderer::coverage::axis+0x66d>
  825a7a:	jp     825fbd <gpui_gpu::renderer::coverage::axis+0x66d>
  825a80:	movapd %xmm9,%xmm12
  825a85:	movapd %xmm1,%xmm11
  825a8a:	movq   %xmm10,%r13
  825a8f:	and    %rbx,%r13
  825a92:	cmp    %r14,%r13
  825a95:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825a9b:	ucomisd %xmm0,%xmm10
  825aa0:	jne    826001 <gpui_gpu::renderer::coverage::axis+0x6b1>
  825aa6:	jp     826001 <gpui_gpu::renderer::coverage::axis+0x6b1>
  825aac:	movapd %xmm11,%xmm0
  825ab1:	movapd %xmm12,%xmm1
  825ab6:	movaps %xmm8,0x20(%rsp)
  825abc:	movapd %xmm15,0x80(%rsp)
  825ac6:	movapd %xmm14,0x40(%rsp)
  825acd:	movaps %xmm13,0x120(%rsp)
  825ad6:	movapd %xmm2,0x130(%rsp)
  825adf:	movapd %xmm3,0x140(%rsp)
  825ae8:	movaps %xmm10,0x110(%rsp)
  825af1:	movsd  %xmm6,0x98(%rsp)
  825afa:	movsd  %xmm7,0x38(%rsp)
  825b00:	movaps %xmm5,0x70(%rsp)
  825b05:	lea    0x8(%rsp),%rdi
  825b0a:	movapd %xmm4,%xmm2
  825b0e:	movaps %xmm4,0x100(%rsp)
  825b16:	movapd %xmm4,%xmm3
  825b1a:	call   8257d0 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825b1f:	cmpl   $0x1,0x8(%rsp)
  825b24:	jne    825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825b2a:	movapd 0x20(%rsp),%xmm2
  825b30:	andpd  -0x77ad08(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825b38:	movsd  0x10(%rsp),%xmm0
  825b3e:	movsd  %xmm0,0x20(%rsp)
  825b44:	movsd  0x18(%rsp),%xmm0
  825b4a:	movsd  %xmm0,0x90(%rsp)
  825b53:	lea    0x8(%rsp),%rdi
  825b58:	movapd 0x80(%rsp),%xmm0
  825b61:	movapd 0x40(%rsp),%xmm1
  825b67:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825b6c:	cmpb   $0x0,0x8(%rsp)
  825b71:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825b77:	movapd 0x120(%rsp),%xmm2
  825b80:	andpd  -0x77ad58(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825b88:	movsd  0x10(%rsp),%xmm0
  825b8e:	movsd  %xmm0,0x40(%rsp)
  825b94:	movsd  0x18(%rsp),%xmm0
  825b9a:	movsd  %xmm0,0x80(%rsp)
  825ba3:	lea    0x8(%rsp),%rdi
  825ba8:	movapd 0x130(%rsp),%xmm0
  825bb1:	movapd 0x140(%rsp),%xmm1
  825bba:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825bbf:	cmpb   $0x0,0x8(%rsp)
  825bc4:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825bca:	movsd  0x10(%rsp),%xmm2
  825bd0:	movsd  0x18(%rsp),%xmm3
  825bd6:	lea    0x58(%rsp),%rdi
  825bdb:	movsd  0x40(%rsp),%xmm0
  825be1:	movsd  0x80(%rsp),%xmm1
  825bea:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825bef:	cmpb   $0x0,0x58(%rsp)
  825bf4:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825bfa:	xorpd  %xmm0,%xmm0
  825bfe:	movapd 0x110(%rsp),%xmm2
  825c07:	ucomisd %xmm0,%xmm2
  825c0b:	movsd  0x60(%rsp),%xmm0
  825c11:	movsd  0x68(%rsp),%xmm1
  825c17:	jne    825c1b <gpui_gpu::renderer::coverage::axis+0x2cb>
  825c19:	jnp    825c31 <gpui_gpu::renderer::coverage::axis+0x2e1>
  825c1b:	dec    %r13
  825c1e:	movabs $0xfffffffffffff,%rax
  825c28:	cmp    %rax,%r13
  825c2b:	jb     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825c31:	andpd  -0x77ae09(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825c39:	lea    0xe8(%rsp),%rdi
  825c41:	movapd %xmm2,%xmm3
  825c45:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825c4a:	cmpb   $0x0,0xe8(%rsp)
  825c52:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825c58:	xorpd  %xmm0,%xmm0
  825c5c:	movapd 0x100(%rsp),%xmm2
  825c65:	ucomisd %xmm0,%xmm2
  825c69:	movsd  0xf0(%rsp),%xmm0
  825c72:	movsd  0xf8(%rsp),%xmm1
  825c7b:	jne    825c7f <gpui_gpu::renderer::coverage::axis+0x32f>
  825c7d:	jnp    825c95 <gpui_gpu::renderer::coverage::axis+0x345>
  825c7f:	dec    %r12
  825c82:	movabs $0xfffffffffffff,%rax
  825c8c:	cmp    %rax,%r12
  825c8f:	jb     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825c95:	andpd  -0x77ae6d(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825c9d:	lea    0xd0(%rsp),%rdi
  825ca5:	movapd %xmm2,%xmm3
  825ca9:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825cae:	cmpb   $0x0,0xd0(%rsp)
  825cb6:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825cbc:	xorpd  %xmm0,%xmm0
  825cc0:	movapd 0x70(%rsp),%xmm1
  825cc6:	ucomisd %xmm0,%xmm1
  825cca:	movsd  0xd8(%rsp),%xmm0
  825cd3:	movsd  0xe0(%rsp),%xmm1
  825cdc:	jne    825ce0 <gpui_gpu::renderer::coverage::axis+0x390>
  825cde:	jnp    825cf6 <gpui_gpu::renderer::coverage::axis+0x3a6>
  825ce0:	dec    %r15
  825ce3:	movabs $0xfffffffffffff,%rax
  825ced:	cmp    %rax,%r15
  825cf0:	jb     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825cf6:	movapd -0x77aece(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825cfe:	andpd  0x70(%rsp),%xmm2
  825d04:	lea    0xb8(%rsp),%rdi
  825d0c:	movapd %xmm2,%xmm3
  825d10:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825d15:	cmpb   $0x0,0xb8(%rsp)
  825d1d:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825d23:	movsd  0xc0(%rsp),%xmm0
  825d2c:	movsd  0xc8(%rsp),%xmm1
  825d35:	lea    0xa0(%rsp),%rdi
  825d3d:	movsd  -0x776465(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  825d45:	movapd %xmm2,%xmm3
  825d49:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825d4e:	cmpl   $0x1,0xa0(%rsp)
  825d56:	jne    825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825d5c:	movsd  0xa8(%rsp),%xmm0
  825d65:	movsd  0xb0(%rsp),%xmm1
  825d6e:	lea    0x8(%rsp),%rdi
  825d73:	movsd  0x98(%rsp),%xmm2
  825d7c:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825d81:	cmpb   $0x0,0x8(%rsp)
  825d86:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825d8c:	movq   0x38(%rsp),%xmm0
  825d92:	movq   %xmm0,%rax
  825d97:	and    %rbx,%rax
  825d9a:	cmp    %r14,%rax
  825d9d:	jg     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825da3:	movsd  0x10(%rsp),%xmm0
  825da9:	movsd  0x18(%rsp),%xmm1
  825daf:	xorpd  %xmm2,%xmm2
  825db3:	movsd  0x38(%rsp),%xmm3
  825db9:	ucomisd %xmm2,%xmm3
  825dbd:	jne    825dc1 <gpui_gpu::renderer::coverage::axis+0x471>
  825dbf:	jnp    825dd7 <gpui_gpu::renderer::coverage::axis+0x487>
  825dc1:	dec    %rax
  825dc4:	movabs $0xfffffffffffff,%rcx
  825dce:	cmp    %rcx,%rax
  825dd1:	jb     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825dd7:	lea    0x58(%rsp),%rdi
  825ddc:	movsd  0x38(%rsp),%xmm2
  825de2:	movapd %xmm2,%xmm3
  825de6:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825deb:	cmpb   $0x0,0x58(%rsp)
  825df0:	je     825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825df6:	movsd  0x68(%rsp),%xmm1
  825dfc:	movsd  0x20(%rsp),%xmm0
  825e02:	movsd  %xmm1,0x40(%rsp)
  825e08:	ucomisd %xmm1,%xmm0
  825e0c:	jbe    826404 <gpui_gpu::renderer::coverage::axis+0xab4>
  825e12:	lea    0x8(%rsp),%rdi
  825e17:	movapd 0x70(%rsp),%xmm0
  825e1d:	movapd %xmm0,%xmm1
  825e21:	movsd  0x20(%rsp),%xmm2
  825e27:	movsd  0x90(%rsp),%xmm3
  825e30:	call   8257d0 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825e35:	cmpl   $0x1,0x8(%rsp)
  825e3a:	jne    825fb6 <gpui_gpu::renderer::coverage::axis+0x666>
  825e40:	movsd  0x10(%rsp),%xmm0
  825e46:	ucomisd 0x40(%rsp),%xmm0
  825e4c:	seta   %al
  825e4f:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825e54:	dec    %rdx
  825e57:	movabs $0xfffffffffffff,%rcx
  825e61:	cmp    %rcx,%rdx
  825e64:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825e6a:	ucomisd %xmm11,%xmm15
  825e6f:	jne    825e7f <gpui_gpu::renderer::coverage::axis+0x52f>
  825e71:	jp     825e7f <gpui_gpu::renderer::coverage::axis+0x52f>
  825e73:	ucomisd %xmm0,%xmm1
  825e77:	jne    825e7f <gpui_gpu::renderer::coverage::axis+0x52f>
  825e79:	jnp    825a1d <gpui_gpu::renderer::coverage::axis+0xcd>
  825e7f:	ucomisd %xmm11,%xmm8
  825e84:	movapd %xmm8,%xmm9
  825e89:	cmpltsd %xmm8,%xmm11
  825e8f:	movapd %xmm11,%xmm0
  825e94:	andpd  %xmm15,%xmm0
  825e99:	andnpd %xmm1,%xmm11
  825e9e:	orpd   %xmm0,%xmm11
  825ea3:	movapd %xmm1,%xmm12
  825ea8:	ja     825eaf <gpui_gpu::renderer::coverage::axis+0x55f>
  825eaa:	movapd %xmm15,%xmm12
  825eaf:	movapd %xmm9,%xmm8
  825eb4:	mulsd  %xmm9,%xmm12
  825eb9:	mulsd  %xmm9,%xmm11
  825ebe:	movq   %xmm11,%rsi
  825ec3:	movq   %xmm12,%rdx
  825ec8:	ucomisd %xmm11,%xmm11
  825ecd:	setp   %dil
  825ed1:	movabs $0xfff0000000000000,%r8
  825edb:	cmp    %r8,%rsi
  825ede:	sete   %r8b
  825ee2:	or     %dil,%r8b
  825ee5:	jne    8260a5 <gpui_gpu::renderer::coverage::axis+0x755>
  825eeb:	mov    %rsi,%rdi
  825eee:	and    %rbx,%rdi
  825ef1:	je     826091 <gpui_gpu::renderer::coverage::axis+0x741>
  825ef7:	cmp    %rdi,%rsi
  825efa:	jne    82609d <gpui_gpu::renderer::coverage::axis+0x74d>
  825f00:	dec    %rsi
  825f03:	jmp    8260a0 <gpui_gpu::renderer::coverage::axis+0x750>
  825f08:	dec    %rdx
  825f0b:	movabs $0xfffffffffffff,%rcx
  825f15:	cmp    %rcx,%rdx
  825f18:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825f1e:	ucomisd %xmm9,%xmm2
  825f23:	jne    825f33 <gpui_gpu::renderer::coverage::axis+0x5e3>
  825f25:	jp     825f33 <gpui_gpu::renderer::coverage::axis+0x5e3>
  825f27:	ucomisd %xmm1,%xmm3
  825f2b:	jne    825f33 <gpui_gpu::renderer::coverage::axis+0x5e3>
  825f2d:	jnp    825a4d <gpui_gpu::renderer::coverage::axis+0xfd>
  825f33:	movaps %xmm8,0x20(%rsp)
  825f39:	ucomisd %xmm1,%xmm13
  825f3e:	cmpltsd %xmm13,%xmm1
  825f44:	movapd %xmm1,%xmm8
  825f49:	andpd  %xmm2,%xmm8
  825f4e:	andnpd %xmm3,%xmm1
  825f52:	orpd   %xmm8,%xmm1
  825f57:	movapd %xmm3,%xmm9
  825f5c:	ja     825f63 <gpui_gpu::renderer::coverage::axis+0x613>
  825f5e:	movapd %xmm2,%xmm9
  825f63:	mulsd  %xmm13,%xmm9
  825f68:	mulsd  %xmm13,%xmm1
  825f6d:	movq   %xmm1,%rsi
  825f72:	movq   %xmm9,%rdx
  825f77:	ucomisd %xmm1,%xmm1
  825f7b:	setp   %dil
  825f7f:	movabs $0xfff0000000000000,%r8
  825f89:	cmp    %r8,%rsi
  825f8c:	sete   %r8b
  825f90:	or     %dil,%r8b
  825f93:	jne    82625d <gpui_gpu::renderer::coverage::axis+0x90d>
  825f99:	mov    %rsi,%rdi
  825f9c:	and    %rbx,%rdi
  825f9f:	je     826249 <gpui_gpu::renderer::coverage::axis+0x8f9>
  825fa5:	cmp    %rdi,%rsi
  825fa8:	jne    826255 <gpui_gpu::renderer::coverage::axis+0x905>
  825fae:	dec    %rsi
  825fb1:	jmp    826258 <gpui_gpu::renderer::coverage::axis+0x908>
  825fb6:	mov    $0x2,%al
  825fb8:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  825fbd:	addsd  %xmm1,%xmm11
  825fc2:	addsd  %xmm9,%xmm12
  825fc7:	movq   %xmm11,%rdx
  825fcc:	movq   %xmm12,%rcx
  825fd1:	movabs $0xfff0000000000000,%rsi
  825fdb:	cmp    %rsi,%rdx
  825fde:	je     82617a <gpui_gpu::renderer::coverage::axis+0x82a>
  825fe4:	mov    %rdx,%rsi
  825fe7:	and    %rbx,%rsi
  825fea:	je     826166 <gpui_gpu::renderer::coverage::axis+0x816>
  825ff0:	cmp    %rsi,%rdx
  825ff3:	jne    826172 <gpui_gpu::renderer::coverage::axis+0x822>
  825ff9:	dec    %rdx
  825ffc:	jmp    826175 <gpui_gpu::renderer::coverage::axis+0x825>
  826001:	lea    -0x1(%r13),%rdx
  826005:	movabs $0xfffffffffffff,%rcx
  82600f:	cmp    %rcx,%rdx
  826012:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826018:	ucomisd %xmm0,%xmm12
  82601d:	jne    826038 <gpui_gpu::renderer::coverage::axis+0x6e8>
  82601f:	jp     826038 <gpui_gpu::renderer::coverage::axis+0x6e8>
  826021:	ucomisd %xmm0,%xmm11
  826026:	movapd %xmm10,%xmm0
  82602b:	movapd %xmm10,%xmm1
  826030:	jne    826038 <gpui_gpu::renderer::coverage::axis+0x6e8>
  826032:	jnp    825ab6 <gpui_gpu::renderer::coverage::axis+0x166>
  826038:	addsd  %xmm10,%xmm11
  82603d:	addsd  %xmm10,%xmm12
  826042:	movq   %xmm11,%rsi
  826047:	movq   %xmm12,%rdx
  82604c:	ucomisd %xmm11,%xmm11
  826051:	setp   %dil
  826055:	movabs $0xfff0000000000000,%r8
  82605f:	cmp    %r8,%rsi
  826062:	sete   %r8b
  826066:	or     %dil,%r8b
  826069:	movdqa %xmm11,%xmm0
  82606e:	jne    826342 <gpui_gpu::renderer::coverage::axis+0x9f2>
  826074:	mov    %rsi,%rdi
  826077:	and    %rbx,%rdi
  82607a:	je     82632e <gpui_gpu::renderer::coverage::axis+0x9de>
  826080:	cmp    %rdi,%rsi
  826083:	jne    82633a <gpui_gpu::renderer::coverage::axis+0x9ea>
  826089:	dec    %rsi
  82608c:	jmp    82633d <gpui_gpu::renderer::coverage::axis+0x9ed>
  826091:	movabs $0x8000000000000001,%rsi
  82609b:	jmp    8260a0 <gpui_gpu::renderer::coverage::axis+0x750>
  82609d:	inc    %rsi
  8260a0:	movq   %rsi,%xmm11
  8260a5:	ucomisd %xmm12,%xmm12
  8260aa:	setp   %sil
  8260ae:	movabs $0x7ff0000000000000,%rdi
  8260b8:	cmp    %rdi,%rdx
  8260bb:	sete   %dil
  8260bf:	or     %sil,%dil
  8260c2:	jne    8260e5 <gpui_gpu::renderer::coverage::axis+0x795>
  8260c4:	mov    %rdx,%rsi
  8260c7:	and    %rbx,%rsi
  8260ca:	je     8260d6 <gpui_gpu::renderer::coverage::axis+0x786>
  8260cc:	cmp    %rsi,%rdx
  8260cf:	jne    8260dd <gpui_gpu::renderer::coverage::axis+0x78d>
  8260d1:	inc    %rdx
  8260d4:	jmp    8260e0 <gpui_gpu::renderer::coverage::axis+0x790>
  8260d6:	mov    $0x1,%edx
  8260db:	jmp    8260e0 <gpui_gpu::renderer::coverage::axis+0x790>
  8260dd:	dec    %rdx
  8260e0:	movq   %rdx,%xmm12
  8260e5:	movq   %xmm11,%rsi
  8260ea:	and    %rbx,%rsi
  8260ed:	cmp    %r14,%rsi
  8260f0:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8260f6:	ucomisd %xmm12,%xmm11
  8260fb:	ja     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826101:	xorpd  %xmm0,%xmm0
  826105:	ucomisd %xmm0,%xmm11
  82610a:	movq   %xmm12,%rdx
  82610f:	jne    826123 <gpui_gpu::renderer::coverage::axis+0x7d3>
  826111:	jp     826123 <gpui_gpu::renderer::coverage::axis+0x7d3>
  826113:	mov    %rdx,%rsi
  826116:	and    %rbx,%rsi
  826119:	cmp    %r14,%rsi
  82611c:	jle    826145 <gpui_gpu::renderer::coverage::axis+0x7f5>
  82611e:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826123:	dec    %rsi
  826126:	mov    %rdx,%rdi
  826129:	and    %rbx,%rdi
  82612c:	cmp    %r14,%rdi
  82612f:	setg   %dil
  826133:	cmp    %rcx,%rsi
  826136:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  82613c:	test   %dil,%dil
  82613f:	jne    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826145:	ucomisd %xmm0,%xmm12
  82614a:	jne    826152 <gpui_gpu::renderer::coverage::axis+0x802>
  82614c:	jnp    825a1d <gpui_gpu::renderer::coverage::axis+0xcd>
  826152:	and    %rbx,%rdx
  826155:	dec    %rdx
  826158:	cmp    %rcx,%rdx
  82615b:	jae    825a1d <gpui_gpu::renderer::coverage::axis+0xcd>
  826161:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826166:	movabs $0x8000000000000001,%rdx
  826170:	jmp    826175 <gpui_gpu::renderer::coverage::axis+0x825>
  826172:	inc    %rdx
  826175:	movq   %rdx,%xmm11
  82617a:	ucomisd %xmm12,%xmm12
  82617f:	setp   %sil
  826183:	movabs $0x7ff0000000000000,%rdx
  82618d:	cmp    %rdx,%rcx
  826190:	sete   %dil
  826194:	or     %sil,%dil
  826197:	jne    8261ba <gpui_gpu::renderer::coverage::axis+0x86a>
  826199:	mov    %rcx,%rsi
  82619c:	and    %rbx,%rsi
  82619f:	je     8261ab <gpui_gpu::renderer::coverage::axis+0x85b>
  8261a1:	cmp    %rsi,%rcx
  8261a4:	jne    8261b2 <gpui_gpu::renderer::coverage::axis+0x862>
  8261a6:	inc    %rcx
  8261a9:	jmp    8261b5 <gpui_gpu::renderer::coverage::axis+0x865>
  8261ab:	mov    $0x1,%ecx
  8261b0:	jmp    8261b5 <gpui_gpu::renderer::coverage::axis+0x865>
  8261b2:	dec    %rcx
  8261b5:	movq   %rcx,%xmm12
  8261ba:	movq   %xmm11,%rsi
  8261bf:	and    %rbx,%rsi
  8261c2:	cmp    %r14,%rsi
  8261c5:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8261cb:	ucomisd %xmm12,%xmm11
  8261d0:	ja     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8261d6:	ucomisd %xmm0,%xmm11
  8261db:	movq   %xmm12,%rcx
  8261e0:	jne    8261f4 <gpui_gpu::renderer::coverage::axis+0x8a4>
  8261e2:	jp     8261f4 <gpui_gpu::renderer::coverage::axis+0x8a4>
  8261e4:	mov    %rcx,%rsi
  8261e7:	and    %rbx,%rsi
  8261ea:	cmp    %rdx,%rsi
  8261ed:	jl     82621e <gpui_gpu::renderer::coverage::axis+0x8ce>
  8261ef:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8261f4:	dec    %rsi
  8261f7:	mov    %rcx,%rdx
  8261fa:	and    %rbx,%rdx
  8261fd:	cmp    %r14,%rdx
  826200:	setg   %dl
  826203:	movabs $0xfffffffffffff,%rdi
  82620d:	cmp    %rdi,%rsi
  826210:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826216:	test   %dl,%dl
  826218:	jne    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  82621e:	ucomisd %xmm0,%xmm12
  826223:	jne    82622b <gpui_gpu::renderer::coverage::axis+0x8db>
  826225:	jnp    825a8a <gpui_gpu::renderer::coverage::axis+0x13a>
  82622b:	and    %rbx,%rcx
  82622e:	dec    %rcx
  826231:	movabs $0xfffffffffffff,%rdx
  82623b:	cmp    %rdx,%rcx
  82623e:	jae    825a8a <gpui_gpu::renderer::coverage::axis+0x13a>
  826244:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826249:	movabs $0x8000000000000001,%rsi
  826253:	jmp    826258 <gpui_gpu::renderer::coverage::axis+0x908>
  826255:	inc    %rsi
  826258:	movq   %rsi,%xmm1
  82625d:	ucomisd %xmm9,%xmm9
  826262:	setp   %sil
  826266:	movabs $0x7ff0000000000000,%rdi
  826270:	cmp    %rdi,%rdx
  826273:	sete   %dil
  826277:	or     %sil,%dil
  82627a:	jne    82629d <gpui_gpu::renderer::coverage::axis+0x94d>
  82627c:	mov    %rdx,%rsi
  82627f:	and    %rbx,%rsi
  826282:	je     82628e <gpui_gpu::renderer::coverage::axis+0x93e>
  826284:	cmp    %rsi,%rdx
  826287:	jne    826295 <gpui_gpu::renderer::coverage::axis+0x945>
  826289:	inc    %rdx
  82628c:	jmp    826298 <gpui_gpu::renderer::coverage::axis+0x948>
  82628e:	mov    $0x1,%edx
  826293:	jmp    826298 <gpui_gpu::renderer::coverage::axis+0x948>
  826295:	dec    %rdx
  826298:	movq   %rdx,%xmm9
  82629d:	movq   %xmm1,%rsi
  8262a2:	and    %rbx,%rsi
  8262a5:	cmp    %r14,%rsi
  8262a8:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262ae:	ucomisd %xmm9,%xmm1
  8262b3:	ja     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262b9:	xorpd  %xmm8,%xmm8
  8262be:	ucomisd %xmm8,%xmm1
  8262c3:	movq   %xmm9,%rdx
  8262c8:	jne    8262dc <gpui_gpu::renderer::coverage::axis+0x98c>
  8262ca:	jp     8262dc <gpui_gpu::renderer::coverage::axis+0x98c>
  8262cc:	mov    %rdx,%rsi
  8262cf:	and    %rbx,%rsi
  8262d2:	cmp    %r14,%rsi
  8262d5:	jle    8262fe <gpui_gpu::renderer::coverage::axis+0x9ae>
  8262d7:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262dc:	dec    %rsi
  8262df:	mov    %rdx,%rdi
  8262e2:	and    %rbx,%rdi
  8262e5:	cmp    %r14,%rdi
  8262e8:	setg   %dil
  8262ec:	cmp    %rcx,%rsi
  8262ef:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262f5:	test   %dil,%dil
  8262f8:	jne    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8262fe:	ucomisd %xmm8,%xmm9
  826303:	jne    826313 <gpui_gpu::renderer::coverage::axis+0x9c3>
  826305:	jp     826313 <gpui_gpu::renderer::coverage::axis+0x9c3>
  826307:	movapd 0x20(%rsp),%xmm8
  82630e:	jmp    825a4d <gpui_gpu::renderer::coverage::axis+0xfd>
  826313:	and    %rbx,%rdx
  826316:	dec    %rdx
  826319:	cmp    %rcx,%rdx
  82631c:	movapd 0x20(%rsp),%xmm8
  826323:	jae    825a4d <gpui_gpu::renderer::coverage::axis+0xfd>
  826329:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  82632e:	movabs $0x8000000000000001,%rsi
  826338:	jmp    82633d <gpui_gpu::renderer::coverage::axis+0x9ed>
  82633a:	inc    %rsi
  82633d:	movq   %rsi,%xmm0
  826342:	ucomisd %xmm12,%xmm12
  826347:	setp   %dil
  82634b:	movabs $0x7ff0000000000000,%rsi
  826355:	cmp    %rsi,%rdx
  826358:	sete   %r8b
  82635c:	or     %dil,%r8b
  82635f:	jne    826382 <gpui_gpu::renderer::coverage::axis+0xa32>
  826361:	mov    %rdx,%rdi
  826364:	and    %rbx,%rdi
  826367:	je     826373 <gpui_gpu::renderer::coverage::axis+0xa23>
  826369:	cmp    %rdi,%rdx
  82636c:	jne    82637a <gpui_gpu::renderer::coverage::axis+0xa2a>
  82636e:	inc    %rdx
  826371:	jmp    82637d <gpui_gpu::renderer::coverage::axis+0xa2d>
  826373:	mov    $0x1,%edx
  826378:	jmp    82637d <gpui_gpu::renderer::coverage::axis+0xa2d>
  82637a:	dec    %rdx
  82637d:	movq   %rdx,%xmm12
  826382:	movq   %xmm0,%rdx
  826387:	and    %rbx,%rdx
  82638a:	cmp    %r14,%rdx
  82638d:	jg     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  82638f:	ucomisd %xmm12,%xmm0
  826394:	ja     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  826396:	xorpd  %xmm1,%xmm1
  82639a:	ucomisd %xmm1,%xmm0
  82639e:	jne    8263b1 <gpui_gpu::renderer::coverage::axis+0xa61>
  8263a0:	jp     8263b1 <gpui_gpu::renderer::coverage::axis+0xa61>
  8263a2:	movq   %xmm12,%rdx
  8263a7:	and    %rbx,%rdx
  8263aa:	cmp    %rsi,%rdx
  8263ad:	jl     8263cd <gpui_gpu::renderer::coverage::axis+0xa7d>
  8263af:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8263b1:	dec    %rdx
  8263b4:	movq   %xmm12,%rsi
  8263b9:	and    %rbx,%rsi
  8263bc:	cmp    %r14,%rsi
  8263bf:	setg   %sil
  8263c3:	cmp    %rcx,%rdx
  8263c6:	jb     8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8263c8:	test   %sil,%sil
  8263cb:	jne    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>
  8263cd:	ucomisd %xmm1,%xmm12
  8263d2:	jne    8263da <gpui_gpu::renderer::coverage::axis+0xa8a>
  8263d4:	jnp    825ab1 <gpui_gpu::renderer::coverage::axis+0x161>
  8263da:	movq   %xmm12,%rdx
  8263df:	and    %rbx,%rdx
  8263e2:	dec    %rdx
  8263e5:	movapd %xmm12,%xmm1
  8263ea:	cmp    %rcx,%rdx
  8263ed:	jae    825ab6 <gpui_gpu::renderer::coverage::axis+0x166>
  8263f3:	add    $0x150,%rsp
  8263fa:	pop    %rbx
  8263fb:	pop    %r12
  8263fd:	pop    %r13
  8263ff:	pop    %r14
  826401:	pop    %r15
  826403:	ret
  826404:	xor    %eax,%eax
  826406:	jmp    8263f3 <gpui_gpu::renderer::coverage::axis+0xaa3>

FUNCTION gpui_gpu::renderer::coverage::whole bytes=1462 frame=248

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826410 <gpui_gpu::renderer::coverage::whole>:
  826410:	push   %rbp
  826411:	push   %r15
  826413:	push   %r14
  826415:	push   %r13
  826417:	push   %r12
  826419:	push   %rbx
  82641a:	sub    $0xc8,%rsp
  826421:	mov    %rsi,0x30(%rsp)
  826426:	cmpb   $0x0,(%rdi)
  826429:	jne    8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  82642f:	test   %esi,%esi
  826431:	sets   %al
  826434:	mov    %esi,%r9d
  826437:	and    $0x7fffffff,%r9d
  82643e:	lea    -0x800000(%r9),%r10d
  826445:	cmp    $0x7f000000,%r10d
  82644c:	setb   %r10b
  826450:	and    %al,%r10b
  826453:	lea    -0x1(%r9),%r11d
  826457:	cmp    $0x7fffff,%r11d
  82645e:	setb   %r11b
  826462:	and    %al,%r11b
  826465:	cmp    $0x7f800000,%r9d
  82646c:	sete   %al
  82646f:	setg   %r9b
  826473:	or     %al,%r9b
  826476:	or     %r11b,%r9b
  826479:	or     %r10b,%r9b
  82647c:	jne    8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  82647e:	shr    $0x20,%rsi
  826482:	test   %esi,%esi
  826484:	sets   %al
  826487:	and    $0x7fffffff,%esi
  82648d:	lea    -0x800000(%rsi),%r9d
  826494:	cmp    $0x7f000000,%r9d
  82649b:	setb   %r9b
  82649f:	and    %al,%r9b
  8264a2:	lea    -0x1(%rsi),%r10d
  8264a6:	cmp    $0x7fffff,%r10d
  8264ad:	setb   %r10b
  8264b1:	and    %al,%r10b
  8264b4:	cmp    $0x7f800000,%esi
  8264ba:	sete   %al
  8264bd:	setg   %sil
  8264c1:	or     %al,%sil
  8264c4:	or     %r10b,%sil
  8264c7:	or     %r9b,%sil
  8264ca:	je     8264e2 <gpui_gpu::renderer::coverage::whole+0xd2>
  8264cc:	xor    %eax,%eax
  8264ce:	and    $0x1,%al
  8264d0:	add    $0xc8,%rsp
  8264d7:	pop    %rbx
  8264d8:	pop    %r12
  8264da:	pop    %r13
  8264dc:	pop    %r14
  8264de:	pop    %r15
  8264e0:	pop    %rbp
  8264e1:	ret
  8264e2:	movss  0x88(%rdi),%xmm1
  8264ea:	movss  -0x7774d6(%rip),%xmm2        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8264f2:	movaps %xmm1,%xmm0
  8264f5:	subss  %xmm2,%xmm0
  8264f9:	cvttss2si %xmm0,%rax
  8264fe:	cvttss2si %xmm1,%rsi
  826503:	mov    %rsi,%r9
  826506:	sar    $0x3f,%r9
  82650a:	and    %rax,%r9
  82650d:	or     %rsi,%r9
  826510:	xor    %eax,%eax
  826512:	xorps  %xmm0,%xmm0
  826515:	ucomiss %xmm0,%xmm1
  826518:	cmovb  %rax,%r9
  82651c:	movss  0x8c(%rdi),%xmm4
  826524:	movss  -0x77750c(%rip),%xmm3        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82652c:	ucomiss %xmm3,%xmm1
  82652f:	mov    $0xffffffffffffffff,%rbx
  826536:	cmova  %rbx,%r9
  82653a:	movaps %xmm4,%xmm1
  82653d:	subss  %xmm2,%xmm1
  826541:	cvttss2si %xmm1,%rsi
  826546:	cvttss2si %xmm4,%r11
  82654b:	mov    %r11,%r10
  82654e:	sar    $0x3f,%r10
  826552:	and    %rsi,%r10
  826555:	or     %r11,%r10
  826558:	ucomiss %xmm0,%xmm4
  82655b:	cmovb  %rax,%r10
  82655f:	ucomiss %xmm3,%xmm4
  826562:	movss  0x90(%rdi),%xmm1
  82656a:	cmova  %rbx,%r10
  82656e:	movaps %xmm1,%xmm4
  826571:	subss  %xmm2,%xmm4
  826575:	cvttss2si %xmm4,%r11
  82657a:	cvttss2si %xmm1,%r14
  82657f:	mov    %r14,%rsi
  826582:	sar    $0x3f,%rsi
  826586:	and    %r11,%rsi
  826589:	or     %r14,%rsi
  82658c:	ucomiss %xmm0,%xmm1
  82658f:	cmovb  %rax,%rsi
  826593:	ucomiss %xmm3,%xmm1
  826596:	cmova  %rbx,%rsi
  82659a:	add    %r9,%rsi
  82659d:	setb   %r11b
  8265a1:	sete   %bpl
  8265a5:	or     %r11b,%bpl
  8265a8:	jne    8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  8265ae:	movss  0x94(%rdi),%xmm2
  8265b6:	cvttss2si %xmm2,%rax
  8265bb:	mov    %rax,%r11
  8265be:	movaps %xmm2,%xmm3
  8265c1:	subss  -0x7775ad(%rip),%xmm3        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8265c9:	sar    $0x3f,%r11
  8265cd:	cvttss2si %xmm3,%r14
  8265d2:	and    %r11,%r14
  8265d5:	or     %rax,%r14
  8265d8:	xor    %eax,%eax
  8265da:	ucomiss %xmm0,%xmm2
  8265dd:	mov    $0x0,%r11d
  8265e3:	cmovae %r14,%r11
  8265e7:	ucomiss -0x7775ce(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8265ee:	cmova  %rbx,%r11
  8265f2:	add    %r10,%r11
  8265f5:	setb   %bl
  8265f8:	sete   %bpl
  8265fc:	or     %bl,%bpl
  8265ff:	jne    8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826605:	xor    %eax,%eax
  826607:	test   %rdx,%rdx
  82660a:	je     8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826610:	movss  -0x777838(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  826618:	ucomiss %xmm1,%xmm0
  82661b:	ja     8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826621:	ucomiss %xmm2,%xmm0
  826624:	ja     8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  82662a:	dec    %rsi
  82662d:	dec    %r11
  826630:	shr    $0x4,%r10
  826634:	imul   %rdx,%r10
  826638:	shr    $0x4,%r9
  82663c:	add    %r10,%r9
  82663f:	mov    %r9,%rax
  826642:	mov    %rdx,%rbx
  826645:	or     %rdx,%rax
  826648:	shr    $0x20,%rax
  82664c:	je     82665e <gpui_gpu::renderer::coverage::whole+0x24e>
  82664e:	mov    %r9,%rax
  826651:	xor    %edx,%edx
  826653:	div    %rbx
  826656:	mov    %rdx,%r10
  826659:	mov    %rax,%r9
  82665c:	jmp    82666b <gpui_gpu::renderer::coverage::whole+0x25b>
  82665e:	mov    %r9d,%eax
  826661:	xor    %edx,%edx
  826663:	div    %ebx
  826665:	mov    %edx,%r10d
  826668:	mov    %eax,%r9d
  82666b:	shl    $0x4,%r10d
  82666f:	shr    $0x4,%r11
  826673:	imul   %rbx,%r11
  826677:	shr    $0x4,%rsi
  82667b:	add    %r11,%rsi
  82667e:	mov    %rsi,%rdx
  826681:	or     %rbx,%rdx
  826684:	shr    $0x20,%rdx
  826688:	je     826694 <gpui_gpu::renderer::coverage::whole+0x284>
  82668a:	mov    %rsi,%rax
  82668d:	xor    %edx,%edx
  82668f:	div    %rbx
  826692:	jmp    82669a <gpui_gpu::renderer::coverage::whole+0x28a>
  826694:	mov    %esi,%eax
  826696:	xor    %edx,%edx
  826698:	div    %ebx
  82669a:	shl    $0x4,%edx
  82669d:	shl    $0x4,%eax
  8266a0:	add    $0x10,%edx
  8266a3:	cmp    %edx,%ecx
  8266a5:	cmovb  %ecx,%edx
  8266a8:	add    $0x10,%eax
  8266ab:	cmp    %eax,%r8d
  8266ae:	cmovb  %r8d,%eax
  8266b2:	movss  0x78(%rdi),%xmm0
  8266b7:	cvtss2sd %xmm0,%xmm2
  8266bb:	mov    %r10d,%ecx
  8266be:	xorps  %xmm0,%xmm0
  8266c1:	cvtsi2sd %rcx,%xmm0
  8266c6:	ucomisd %xmm0,%xmm2
  8266ca:	ja     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8266d0:	shl    $0x4,%r9d
  8266d4:	movss  0x7c(%rdi),%xmm1
  8266d9:	cvtss2sd %xmm1,%xmm3
  8266dd:	cvtsi2sd %r9,%xmm4
  8266e2:	ucomisd %xmm4,%xmm3
  8266e6:	ja     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8266ec:	movss  0x80(%rdi),%xmm1
  8266f4:	cvtss2sd %xmm1,%xmm1
  8266f8:	addsd  %xmm1,%xmm2
  8266fc:	mov    %edx,%ecx
  8266fe:	xorps  %xmm1,%xmm1
  826701:	cvtsi2sd %rcx,%xmm1
  826706:	ucomisd %xmm2,%xmm1
  82670a:	ja     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826710:	movss  0x84(%rdi),%xmm2
  826718:	cvtss2sd %xmm2,%xmm2
  82671c:	addsd  %xmm3,%xmm2
  826720:	mov    %eax,%eax
  826722:	xorps  %xmm3,%xmm3
  826725:	cvtsi2sd %rax,%xmm3
  82672a:	ucomisd %xmm2,%xmm3
  82672e:	ja     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826734:	movsd  %xmm3,(%rsp)
  826739:	movsd  %xmm4,0x8(%rsp)
  82673f:	mov    %rdi,%rbx
  826742:	addsd  -0x776ee2(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82674a:	addsd  -0x77716a(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  826752:	lea    0x38(%rsp),%rdi
  826757:	call   825710 <<gpui_gpu::renderer::coverage::Interval>::checked>
  82675c:	cmpl   $0x1,0x38(%rsp)
  826761:	jne    8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826767:	movsd  0x40(%rsp),%xmm0
  82676d:	movsd  %xmm0,0x28(%rsp)
  826773:	movsd  0x48(%rsp),%xmm0
  826779:	movsd  %xmm0,0x20(%rsp)
  82677f:	movsd  0x8(%rsp),%xmm0
  826785:	addsd  -0x776f25(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82678d:	movsd  (%rsp),%xmm1
  826792:	addsd  -0x7771b2(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82679a:	lea    0x38(%rsp),%rdi
  82679f:	call   825710 <<gpui_gpu::renderer::coverage::Interval>::checked>
  8267a4:	cmpb   $0x0,0x38(%rsp)
  8267a9:	je     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8267af:	movsd  0x40(%rsp),%xmm0
  8267b5:	movsd  %xmm0,0x18(%rsp)
  8267bb:	movsd  0x48(%rsp),%xmm0
  8267c1:	movsd  %xmm0,0x10(%rsp)
  8267c7:	mov    %rbx,%rcx
  8267ca:	movss  0x38(%rbx),%xmm0
  8267cf:	movss  0x3c(%rbx),%xmm1
  8267d4:	movss  0x40(%rbx),%xmm2
  8267d9:	movss  0x44(%rbx),%xmm3
  8267de:	lea    0xa8(%rsp),%r14
  8267e6:	movq   $0x0,0xa8(%rsp)
  8267f2:	movss  %xmm0,0xb0(%rsp)
  8267fb:	movss  %xmm2,0xb4(%rsp)
  826804:	movq   $0x1,0xb8(%rsp)
  826810:	movss  %xmm1,0xc0(%rsp)
  826819:	movss  %xmm3,0xc4(%rsp)
  826822:	lea    0x48(%rsp),%r15
  826827:	xor    %r12d,%r12d
  82682a:	movabs $0x3ec0000000000000,%r13
  826834:	movsd  -0x7769fd(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82683d:	xor    %edx,%edx
  82683f:	shl    $0x4,%rdx
  826843:	mov    (%r14,%rdx,1),%rdi
  826847:	cmp    $0x6,%rdi
  82684b:	jae    826989 <gpui_gpu::renderer::coverage::whole+0x579>
  826851:	cmp    $0x4,%rdi
  826855:	jae    82699b <gpui_gpu::renderer::coverage::whole+0x58b>
  82685b:	mov    %rdi,%rax
  82685e:	or     $0x4,%rax
  826862:	cmp    $0x6,%rax
  826866:	jae    8269b1 <gpui_gpu::renderer::coverage::whole+0x5a1>
  82686c:	movss  0x8(%r14,%rdx,1),%xmm0
  826873:	movss  0xc(%r14,%rdx,1),%xmm1
  82687a:	movsd  0x48(%rcx,%rdi,8),%xmm2
  826880:	movsd  0x48(%rcx,%rax,8),%xmm3
  826886:	xorps  %xmm4,%xmm4
  826889:	cvtsd2ss %xmm3,%xmm4
  82688d:	movsd  0x58(%rcx,%rdi,8),%xmm5
  826893:	cvtss2sd %xmm4,%xmm4
  826897:	movss  0x30(%rsp,%rdi,4),%xmm6
  82689d:	cvtss2sd %xmm6,%xmm6
  8268a1:	movq   $0x0,0x38(%rsp)
  8268aa:	movq   $0x2,0x40(%rsp)
  8268b3:	movapd %xmm2,%xmm7
  8268b7:	unpcklpd %xmm5,%xmm7
  8268bb:	cvtpd2ps %xmm7,%xmm7
  8268bf:	cvtps2pd %xmm7,%xmm7
  8268c2:	movups %xmm7,0x48(%rsp)
  8268c7:	movsd  %xmm4,0x58(%rsp)
  8268cd:	mov    %r13,0x60(%rsp)
  8268d2:	movsd  %xmm6,0x68(%rsp)
  8268d8:	movsd  %xmm2,0x70(%rsp)
  8268de:	movsd  %xmm5,0x78(%rsp)
  8268e4:	movsd  %xmm3,0x80(%rsp)
  8268ed:	movups %xmm8,0x88(%rsp)
  8268f6:	cvtss2sd %xmm0,%xmm0
  8268fa:	movsd  %xmm0,0x8(%rsp)
  826900:	xorps  %xmm0,%xmm0
  826903:	cvtss2sd %xmm1,%xmm0
  826907:	movsd  %xmm0,(%rsp)
  82690c:	xor    %ebp,%ebp
  82690e:	xor    %eax,%eax
  826910:	lea    (%rax,%rax,4),%rax
  826914:	lea    (%r15,%rax,8),%rdi
  826918:	movsd  0x18(%r15,%rax,8),%xmm6
  82691f:	movsd  0x20(%r15,%rax,8),%xmm7
  826926:	movsd  0x28(%rsp),%xmm0
  82692c:	movsd  0x20(%rsp),%xmm1
  826932:	movsd  0x18(%rsp),%xmm2
  826938:	movsd  0x10(%rsp),%xmm3
  82693e:	movsd  0x8(%rsp),%xmm4
  826944:	movsd  (%rsp),%xmm5
  826949:	call   825950 <gpui_gpu::renderer::coverage::axis>
  82694e:	cmp    $0x1,%al
  826950:	jne    8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826956:	mov    $0x1,%eax
  82695b:	test   $0x1,%bpl
  82695f:	mov    $0x1,%bpl
  826962:	je     826910 <gpui_gpu::renderer::coverage::whole+0x500>
  826964:	mov    $0x1,%edx
  826969:	test   $0x1,%r12b
  82696d:	mov    $0x1,%r12b
  826970:	mov    %rbx,%rcx
  826973:	movsd  -0x776b3c(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82697c:	je     82683f <gpui_gpu::renderer::coverage::whole+0x42f>
  826982:	mov    $0x1,%al
  826984:	jmp    8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826989:	lea    0x6093d0(%rip),%rdx        # e2fd60 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x18>
  826990:	mov    $0x6,%esi
  826995:	call   *0x65abed(%rip)        # e81588 <_DYNAMIC+0x4f8>
  82699b:	add    $0x2,%rdi
  82699f:	lea    0x6093d2(%rip),%rdx        # e2fd78 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x30>
  8269a6:	mov    $0x6,%esi
  8269ab:	call   *0x65abd7(%rip)        # e81588 <_DYNAMIC+0x4f8>
  8269b1:	lea    0x6093d8(%rip),%rdx        # e2fd90 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x48>
  8269b8:	mov    $0x6,%esi
  8269bd:	mov    %rax,%rdi
  8269c0:	call   *0x65abc2(%rip)        # e81588 <_DYNAMIC+0x4f8>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000827190 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  827190:	push   %rbp
  827191:	push   %r15
  827193:	push   %r14
  827195:	push   %r13
  827197:	push   %r12
  827199:	push   %rbx
  82719a:	sub    $0x38,%rsp
  82719e:	mov    %rcx,%r15
  8271a1:	mov    %rdx,%r12
  8271a4:	mov    %rsi,%r14
  8271a7:	mov    %rdi,%rbx
  8271aa:	lea    0x20(%rsi),%r13
  8271ae:	mov    %r13,%rdi
  8271b1:	mov    %rdx,%rsi
  8271b4:	call   8250e0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8271b9:	cmpq   $0x0,0x10(%r14)
  8271be:	je     827341 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  8271c4:	mov    (%r14),%r11
  8271c7:	mov    0x8(%r14),%rsi
  8271cb:	mov    %rax,%rdx
  8271ce:	shr    $0x39,%rdx
  8271d2:	movd   %edx,%xmm0
  8271d6:	punpcklbw %xmm0,%xmm0
  8271da:	pshuflw $0x0,%xmm0,%xmm0
  8271df:	pshufd $0x44,%xmm0,%xmm0
  8271e4:	mov    (%r12),%rcx
  8271e8:	mov    %rcx,0x8(%rsp)
  8271ed:	movzwl 0xc(%r12),%r9d
  8271f3:	mov    0x8(%r12),%r10d
  8271f8:	xor    %r13d,%r13d
  8271fb:	pcmpeqd %xmm1,%xmm1
  8271ff:	xor    %r8d,%r8d
  827202:	and    %rsi,%rax
  827205:	movdqu (%r11,%rax,1),%xmm2
  82720b:	movdqa %xmm2,%xmm3
  82720f:	pcmpeqb %xmm0,%xmm3
  827213:	pmovmskb %xmm3,%ebp
  827217:	test   %ebp,%ebp
  827219:	je     827260 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  82721b:	mov    %r8,(%rsp)
  82721f:	mov    %r15,%r8
  827222:	tzcnt  %ebp,%r15d
  827227:	add    %rax,%r15
  82722a:	and    %rsi,%r15
  82722d:	shl    $0x5,%r15
  827231:	mov    %r11,%rcx
  827234:	sub    %r15,%rcx
  827237:	mov    0x8(%rsp),%r15
  82723c:	cmp    -0x20(%rcx),%r15
  827240:	jne    82724f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  827242:	cmp    -0x14(%rcx),%r9w
  827247:	jne    82724f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  827249:	cmp    -0x18(%rcx),%r10d
  82724d:	je     82729f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  82724f:	lea    -0x1(%rbp),%ecx
  827252:	and    %bp,%cx
  827255:	mov    %ecx,%ebp
  827257:	mov    %r8,%r15
  82725a:	mov    (%rsp),%r8
  82725e:	jne    82721f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  827260:	cmp    $0x1,%r13
  827264:	je     827278 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  827266:	pmovmskb %xmm2,%ecx
  82726a:	test   %ecx,%ecx
  82726c:	je     82728c <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  82726e:	tzcnt  %ecx,%edi
  827272:	add    %rax,%rdi
  827275:	and    %rsi,%rdi
  827278:	pcmpeqb %xmm1,%xmm2
  82727c:	pmovmskb %xmm2,%ecx
  827280:	test   %ecx,%ecx
  827282:	jne    8272b6 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  827284:	mov    $0x1,%r13d
  82728a:	jmp    82728f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  82728c:	xor    %r13d,%r13d
  82728f:	add    %r8,%rax
  827292:	add    $0x10,%rax
  827296:	add    $0x10,%r8
  82729a:	jmp    827202 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  82729f:	movups -0x10(%rcx),%xmm0
  8272a3:	movups %xmm0,0x4(%rbx)
  8272a7:	movups (%r8),%xmm0
  8272ab:	movups %xmm0,-0x10(%rcx)
  8272af:	mov    $0x1,%eax
  8272b4:	jmp    82732d <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  8272b6:	movzbl (%r11,%rdi,1),%eax
  8272bb:	test   %al,%al
  8272bd:	jns    827362 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  8272c3:	movups (%r12),%xmm0
  8272c8:	movaps %xmm0,0x10(%rsp)
  8272cd:	movups (%r15),%xmm0
  8272d1:	movaps %xmm0,0x20(%rsp)
  8272d6:	and    $0x1,%al
  8272d8:	lea    -0x10(%rdi),%rcx
  8272dc:	and    %rsi,%rcx
  8272df:	mov    %dl,(%r11,%rdi,1)
  8272e3:	mov    %dl,0x10(%r11,%rcx,1)
  8272e8:	movzbl %al,%eax
  8272eb:	movd   %eax,%xmm0
  8272ef:	shufpd $0x2,-0x77c098(%rip),%xmm0        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  8272f8:	movdqu 0x10(%r14),%xmm1
  8272fe:	psubq  %xmm0,%xmm1
  827302:	movdqu %xmm1,0x10(%r14)
  827308:	shl    $0x5,%rdi
  82730c:	mov    %r11,%rax
  82730f:	sub    %rdi,%rax
  827312:	neg    %rdi
  827315:	movaps 0x10(%rsp),%xmm0
  82731a:	movdqa 0x20(%rsp),%xmm1
  827320:	movups %xmm0,-0x20(%r11,%rdi,1)
  827326:	movdqu %xmm1,-0x10(%rax)
  82732b:	xor    %eax,%eax
  82732d:	mov    %eax,(%rbx)
  82732f:	mov    %rbx,%rax
  827332:	add    $0x38,%rsp
  827336:	pop    %rbx
  827337:	pop    %r12
  827339:	pop    %r13
  82733b:	pop    %r14
  82733d:	pop    %r15
  82733f:	pop    %rbp
  827340:	ret
  827341:	mov    $0x1,%esi
  827346:	mov    %r14,%rdi
  827349:	mov    %r13,%rdx
  82734c:	mov    $0x1,%ecx
  827351:	mov    %rax,%r13
  827354:	call   *0x65a3ce(%rip)        # e81728 <_DYNAMIC+0x698>
  82735a:	mov    %r13,%rax
  82735d:	jmp    8271c4 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  827362:	movdqa (%r11),%xmm0
  827367:	pmovmskb %xmm0,%eax
  82736b:	tzcnt  %eax,%edi
  82736f:	movzbl (%r11,%rdi,1),%eax
  827374:	jmp    8272c3 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000827380 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  827380:	push   %rbp
  827381:	push   %r15
  827383:	push   %r14
  827385:	push   %r13
  827387:	push   %r12
  827389:	push   %rbx
  82738a:	push   %rax
  82738b:	mov    %r8d,%ebp
  82738e:	mov    %ecx,%r14d
  827391:	mov    %rdx,%r15
  827394:	mov    %rsi,%r12
  827397:	mov    %rdi,%rbx
  82739a:	mov    %rdx,(%rsp)
  82739e:	lea    0x20(%rsi),%r13
  8273a2:	mov    %rsp,%rsi
  8273a5:	mov    %r13,%rdi
  8273a8:	call   825280 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8273ad:	cmpq   $0x0,0x10(%r12)
  8273b3:	je     8274f6 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  8273b9:	mov    (%r12),%rcx
  8273bd:	mov    0x8(%r12),%rsi
  8273c2:	mov    %rax,%rdx
  8273c5:	shr    $0x39,%rdx
  8273c9:	movd   %edx,%xmm0
  8273cd:	punpcklbw %xmm0,%xmm0
  8273d1:	pshuflw $0x0,%xmm0,%xmm0
  8273d6:	pshufd $0x44,%xmm0,%xmm0
  8273db:	xor    %r9d,%r9d
  8273de:	pcmpeqd %xmm1,%xmm1
  8273e2:	xor    %r8d,%r8d
  8273e5:	and    %rsi,%rax
  8273e8:	movdqu (%rcx,%rax,1),%xmm2
  8273ed:	movdqa %xmm2,%xmm3
  8273f1:	pcmpeqb %xmm0,%xmm3
  8273f5:	pmovmskb %xmm3,%r10d
  8273fa:	test   %r10d,%r10d
  8273fd:	je     827430 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  8273ff:	tzcnt  %r10d,%r13d
  827404:	add    %rax,%r13
  827407:	and    %rsi,%r13
  82740a:	shl    $0x4,%r13
  82740e:	mov    %rcx,%r11
  827411:	sub    %r13,%r11
  827414:	cmp    -0x10(%r11),%r15
  827418:	je     827471 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  82741a:	lea    -0x1(%r10),%r11d
  82741e:	and    %r10w,%r11w
  827422:	mov    %r11d,%r10d
  827425:	jne    8273ff <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  827427:	nopw   0x0(%rax,%rax,1)
  827430:	cmp    $0x1,%r9
  827434:	je     827448 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  827436:	pmovmskb %xmm2,%edi
  82743a:	test   %edi,%edi
  82743c:	je     82745e <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  82743e:	tzcnt  %edi,%edi
  827442:	add    %rax,%rdi
  827445:	and    %rsi,%rdi
  827448:	pcmpeqb %xmm1,%xmm2
  82744c:	pmovmskb %xmm2,%r9d
  827451:	test   %r9d,%r9d
  827454:	jne    827488 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  827456:	mov    $0x1,%r9d
  82745c:	jmp    827461 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  82745e:	xor    %r9d,%r9d
  827461:	add    %r8,%rax
  827464:	add    $0x10,%rax
  827468:	add    $0x10,%r8
  82746c:	jmp    8273e5 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  827471:	mov    -0x8(%r11),%rax
  827475:	mov    %r14d,-0x8(%r11)
  827479:	mov    %ebp,-0x4(%r11)
  82747d:	mov    %rax,0x4(%rbx)
  827481:	mov    $0x1,%eax
  827486:	jmp    8274e2 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  827488:	movzbl (%rcx,%rdi,1),%eax
  82748c:	test   %al,%al
  82748e:	jns    827517 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  827494:	and    $0x1,%al
  827496:	lea    -0x10(%rdi),%r8
  82749a:	and    %rsi,%r8
  82749d:	mov    %dl,(%rcx,%rdi,1)
  8274a0:	mov    %dl,0x10(%rcx,%r8,1)
  8274a5:	movdqu 0x10(%r12),%xmm0
  8274ac:	movzbl %al,%eax
  8274af:	movd   %eax,%xmm1
  8274b3:	shufpd $0x2,-0x77c25c(%rip),%xmm1        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  8274bc:	psubq  %xmm1,%xmm0
  8274c0:	movdqu %xmm0,0x10(%r12)
  8274c7:	shl    $0x4,%rdi
  8274cb:	mov    %rcx,%rax
  8274ce:	sub    %rdi,%rax
  8274d1:	neg    %rdi
  8274d4:	mov    %r15,-0x10(%rcx,%rdi,1)
  8274d9:	mov    %r14d,-0x8(%rax)
  8274dd:	mov    %ebp,-0x4(%rax)
  8274e0:	xor    %eax,%eax
  8274e2:	mov    %eax,(%rbx)
  8274e4:	mov    %rbx,%rax
  8274e7:	add    $0x8,%rsp
  8274eb:	pop    %rbx
  8274ec:	pop    %r12
  8274ee:	pop    %r13
  8274f0:	pop    %r14
  8274f2:	pop    %r15
  8274f4:	pop    %rbp
  8274f5:	ret
  8274f6:	mov    $0x1,%esi
  8274fb:	mov    %r12,%rdi
  8274fe:	mov    %r13,%rdx
  827501:	mov    $0x1,%ecx
  827506:	mov    %rax,%r13
  827509:	call   *0x65a221(%rip)        # e81730 <_DYNAMIC+0x6a0>
  82750f:	mov    %r13,%rax
  827512:	jmp    8273b9 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  827517:	movdqa (%rcx),%xmm0
  82751b:	pmovmskb %xmm0,%eax
  82751f:	tzcnt  %eax,%edi
  827523:	movzbl (%rcx,%rdi,1),%eax
  827527:	jmp    827494 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>
