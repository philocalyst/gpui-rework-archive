FUNCTION gpui_gpu::renderer::coverage::whole bytes=1462 frame=248

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826410 <gpui_gpu::renderer::coverage::whole>:
  826410:	push   %rbp
  826411:	push   %r15
  826413:	push   %r14
  826415:	push   %r13
  826417:	push   %r12
  826419:	push   %rbx
  82641a:	sub    $0xc8,%rsp
  826421:	mov    %rsi,0x30(%rsp)
  826426:	cmpb   $0x0,(%rdi)
  826429:	jne    8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  82642f:	test   %esi,%esi
  826431:	sets   %al
  826434:	mov    %esi,%r9d
  826437:	and    $0x7fffffff,%r9d
  82643e:	lea    -0x800000(%r9),%r10d
  826445:	cmp    $0x7f000000,%r10d
  82644c:	setb   %r10b
  826450:	and    %al,%r10b
  826453:	lea    -0x1(%r9),%r11d
  826457:	cmp    $0x7fffff,%r11d
  82645e:	setb   %r11b
  826462:	and    %al,%r11b
  826465:	cmp    $0x7f800000,%r9d
  82646c:	sete   %al
  82646f:	setg   %r9b
  826473:	or     %al,%r9b
  826476:	or     %r11b,%r9b
  826479:	or     %r10b,%r9b
  82647c:	jne    8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  82647e:	shr    $0x20,%rsi
  826482:	test   %esi,%esi
  826484:	sets   %al
  826487:	and    $0x7fffffff,%esi
  82648d:	lea    -0x800000(%rsi),%r9d
  826494:	cmp    $0x7f000000,%r9d
  82649b:	setb   %r9b
  82649f:	and    %al,%r9b
  8264a2:	lea    -0x1(%rsi),%r10d
  8264a6:	cmp    $0x7fffff,%r10d
  8264ad:	setb   %r10b
  8264b1:	and    %al,%r10b
  8264b4:	cmp    $0x7f800000,%esi
  8264ba:	sete   %al
  8264bd:	setg   %sil
  8264c1:	or     %al,%sil
  8264c4:	or     %r10b,%sil
  8264c7:	or     %r9b,%sil
  8264ca:	je     8264e2 <gpui_gpu::renderer::coverage::whole+0xd2>
  8264cc:	xor    %eax,%eax
  8264ce:	and    $0x1,%al
  8264d0:	add    $0xc8,%rsp
  8264d7:	pop    %rbx
  8264d8:	pop    %r12
  8264da:	pop    %r13
  8264dc:	pop    %r14
  8264de:	pop    %r15
  8264e0:	pop    %rbp
  8264e1:	ret
  8264e2:	movss  0x88(%rdi),%xmm1
  8264ea:	movss  -0x7774d6(%rip),%xmm2        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8264f2:	movaps %xmm1,%xmm0
  8264f5:	subss  %xmm2,%xmm0
  8264f9:	cvttss2si %xmm0,%rax
  8264fe:	cvttss2si %xmm1,%rsi
  826503:	mov    %rsi,%r9
  826506:	sar    $0x3f,%r9
  82650a:	and    %rax,%r9
  82650d:	or     %rsi,%r9
  826510:	xor    %eax,%eax
  826512:	xorps  %xmm0,%xmm0
  826515:	ucomiss %xmm0,%xmm1
  826518:	cmovb  %rax,%r9
  82651c:	movss  0x8c(%rdi),%xmm4
  826524:	movss  -0x77750c(%rip),%xmm3        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82652c:	ucomiss %xmm3,%xmm1
  82652f:	mov    $0xffffffffffffffff,%rbx
  826536:	cmova  %rbx,%r9
  82653a:	movaps %xmm4,%xmm1
  82653d:	subss  %xmm2,%xmm1
  826541:	cvttss2si %xmm1,%rsi
  826546:	cvttss2si %xmm4,%r11
  82654b:	mov    %r11,%r10
  82654e:	sar    $0x3f,%r10
  826552:	and    %rsi,%r10
  826555:	or     %r11,%r10
  826558:	ucomiss %xmm0,%xmm4
  82655b:	cmovb  %rax,%r10
  82655f:	ucomiss %xmm3,%xmm4
  826562:	movss  0x90(%rdi),%xmm1
  82656a:	cmova  %rbx,%r10
  82656e:	movaps %xmm1,%xmm4
  826571:	subss  %xmm2,%xmm4
  826575:	cvttss2si %xmm4,%r11
  82657a:	cvttss2si %xmm1,%r14
  82657f:	mov    %r14,%rsi
  826582:	sar    $0x3f,%rsi
  826586:	and    %r11,%rsi
  826589:	or     %r14,%rsi
  82658c:	ucomiss %xmm0,%xmm1
  82658f:	cmovb  %rax,%rsi
  826593:	ucomiss %xmm3,%xmm1
  826596:	cmova  %rbx,%rsi
  82659a:	add    %r9,%rsi
  82659d:	setb   %r11b
  8265a1:	sete   %bpl
  8265a5:	or     %r11b,%bpl
  8265a8:	jne    8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  8265ae:	movss  0x94(%rdi),%xmm2
  8265b6:	cvttss2si %xmm2,%rax
  8265bb:	mov    %rax,%r11
  8265be:	movaps %xmm2,%xmm3
  8265c1:	subss  -0x7775ad(%rip),%xmm3        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8265c9:	sar    $0x3f,%r11
  8265cd:	cvttss2si %xmm3,%r14
  8265d2:	and    %r11,%r14
  8265d5:	or     %rax,%r14
  8265d8:	xor    %eax,%eax
  8265da:	ucomiss %xmm0,%xmm2
  8265dd:	mov    $0x0,%r11d
  8265e3:	cmovae %r14,%r11
  8265e7:	ucomiss -0x7775ce(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8265ee:	cmova  %rbx,%r11
  8265f2:	add    %r10,%r11
  8265f5:	setb   %bl
  8265f8:	sete   %bpl
  8265fc:	or     %bl,%bpl
  8265ff:	jne    8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826605:	xor    %eax,%eax
  826607:	test   %rdx,%rdx
  82660a:	je     8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826610:	movss  -0x777838(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  826618:	ucomiss %xmm1,%xmm0
  82661b:	ja     8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826621:	ucomiss %xmm2,%xmm0
  826624:	ja     8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  82662a:	dec    %rsi
  82662d:	dec    %r11
  826630:	shr    $0x4,%r10
  826634:	imul   %rdx,%r10
  826638:	shr    $0x4,%r9
  82663c:	add    %r10,%r9
  82663f:	mov    %r9,%rax
  826642:	mov    %rdx,%rbx
  826645:	or     %rdx,%rax
  826648:	shr    $0x20,%rax
  82664c:	je     82665e <gpui_gpu::renderer::coverage::whole+0x24e>
  82664e:	mov    %r9,%rax
  826651:	xor    %edx,%edx
  826653:	div    %rbx
  826656:	mov    %rdx,%r10
  826659:	mov    %rax,%r9
  82665c:	jmp    82666b <gpui_gpu::renderer::coverage::whole+0x25b>
  82665e:	mov    %r9d,%eax
  826661:	xor    %edx,%edx
  826663:	div    %ebx
  826665:	mov    %edx,%r10d
  826668:	mov    %eax,%r9d
  82666b:	shl    $0x4,%r10d
  82666f:	shr    $0x4,%r11
  826673:	imul   %rbx,%r11
  826677:	shr    $0x4,%rsi
  82667b:	add    %r11,%rsi
  82667e:	mov    %rsi,%rdx
  826681:	or     %rbx,%rdx
  826684:	shr    $0x20,%rdx
  826688:	je     826694 <gpui_gpu::renderer::coverage::whole+0x284>
  82668a:	mov    %rsi,%rax
  82668d:	xor    %edx,%edx
  82668f:	div    %rbx
  826692:	jmp    82669a <gpui_gpu::renderer::coverage::whole+0x28a>
  826694:	mov    %esi,%eax
  826696:	xor    %edx,%edx
  826698:	div    %ebx
  82669a:	shl    $0x4,%edx
  82669d:	shl    $0x4,%eax
  8266a0:	add    $0x10,%edx
  8266a3:	cmp    %edx,%ecx
  8266a5:	cmovb  %ecx,%edx
  8266a8:	add    $0x10,%eax
  8266ab:	cmp    %eax,%r8d
  8266ae:	cmovb  %r8d,%eax
  8266b2:	movss  0x78(%rdi),%xmm0
  8266b7:	cvtss2sd %xmm0,%xmm2
  8266bb:	mov    %r10d,%ecx
  8266be:	xorps  %xmm0,%xmm0
  8266c1:	cvtsi2sd %rcx,%xmm0
  8266c6:	ucomisd %xmm0,%xmm2
  8266ca:	ja     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8266d0:	shl    $0x4,%r9d
  8266d4:	movss  0x7c(%rdi),%xmm1
  8266d9:	cvtss2sd %xmm1,%xmm3
  8266dd:	cvtsi2sd %r9,%xmm4
  8266e2:	ucomisd %xmm4,%xmm3
  8266e6:	ja     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8266ec:	movss  0x80(%rdi),%xmm1
  8266f4:	cvtss2sd %xmm1,%xmm1
  8266f8:	addsd  %xmm1,%xmm2
  8266fc:	mov    %edx,%ecx
  8266fe:	xorps  %xmm1,%xmm1
  826701:	cvtsi2sd %rcx,%xmm1
  826706:	ucomisd %xmm2,%xmm1
  82670a:	ja     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826710:	movss  0x84(%rdi),%xmm2
  826718:	cvtss2sd %xmm2,%xmm2
  82671c:	addsd  %xmm3,%xmm2
  826720:	mov    %eax,%eax
  826722:	xorps  %xmm3,%xmm3
  826725:	cvtsi2sd %rax,%xmm3
  82672a:	ucomisd %xmm2,%xmm3
  82672e:	ja     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826734:	movsd  %xmm3,(%rsp)
  826739:	movsd  %xmm4,0x8(%rsp)
  82673f:	mov    %rdi,%rbx
  826742:	addsd  -0x776ee2(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82674a:	addsd  -0x77716a(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  826752:	lea    0x38(%rsp),%rdi
  826757:	call   825710 <<gpui_gpu::renderer::coverage::Interval>::checked>
  82675c:	cmpl   $0x1,0x38(%rsp)
  826761:	jne    8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826767:	movsd  0x40(%rsp),%xmm0
  82676d:	movsd  %xmm0,0x28(%rsp)
  826773:	movsd  0x48(%rsp),%xmm0
  826779:	movsd  %xmm0,0x20(%rsp)
  82677f:	movsd  0x8(%rsp),%xmm0
  826785:	addsd  -0x776f25(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82678d:	movsd  (%rsp),%xmm1
  826792:	addsd  -0x7771b2(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82679a:	lea    0x38(%rsp),%rdi
  82679f:	call   825710 <<gpui_gpu::renderer::coverage::Interval>::checked>
  8267a4:	cmpb   $0x0,0x38(%rsp)
  8267a9:	je     8264cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8267af:	movsd  0x40(%rsp),%xmm0
  8267b5:	movsd  %xmm0,0x18(%rsp)
  8267bb:	movsd  0x48(%rsp),%xmm0
  8267c1:	movsd  %xmm0,0x10(%rsp)
  8267c7:	mov    %rbx,%rcx
  8267ca:	movss  0x38(%rbx),%xmm0
  8267cf:	movss  0x3c(%rbx),%xmm1
  8267d4:	movss  0x40(%rbx),%xmm2
  8267d9:	movss  0x44(%rbx),%xmm3
  8267de:	lea    0xa8(%rsp),%r14
  8267e6:	movq   $0x0,0xa8(%rsp)
  8267f2:	movss  %xmm0,0xb0(%rsp)
  8267fb:	movss  %xmm2,0xb4(%rsp)
  826804:	movq   $0x1,0xb8(%rsp)
  826810:	movss  %xmm1,0xc0(%rsp)
  826819:	movss  %xmm3,0xc4(%rsp)
  826822:	lea    0x48(%rsp),%r15
  826827:	xor    %r12d,%r12d
  82682a:	movabs $0x3ec0000000000000,%r13
  826834:	movsd  -0x7769fd(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82683d:	xor    %edx,%edx
  82683f:	shl    $0x4,%rdx
  826843:	mov    (%r14,%rdx,1),%rdi
  826847:	cmp    $0x6,%rdi
  82684b:	jae    826989 <gpui_gpu::renderer::coverage::whole+0x579>
  826851:	cmp    $0x4,%rdi
  826855:	jae    82699b <gpui_gpu::renderer::coverage::whole+0x58b>
  82685b:	mov    %rdi,%rax
  82685e:	or     $0x4,%rax
  826862:	cmp    $0x6,%rax
  826866:	jae    8269b1 <gpui_gpu::renderer::coverage::whole+0x5a1>
  82686c:	movss  0x8(%r14,%rdx,1),%xmm0
  826873:	movss  0xc(%r14,%rdx,1),%xmm1
  82687a:	movsd  0x48(%rcx,%rdi,8),%xmm2
  826880:	movsd  0x48(%rcx,%rax,8),%xmm3
  826886:	xorps  %xmm4,%xmm4
  826889:	cvtsd2ss %xmm3,%xmm4
  82688d:	movsd  0x58(%rcx,%rdi,8),%xmm5
  826893:	cvtss2sd %xmm4,%xmm4
  826897:	movss  0x30(%rsp,%rdi,4),%xmm6
  82689d:	cvtss2sd %xmm6,%xmm6
  8268a1:	movq   $0x0,0x38(%rsp)
  8268aa:	movq   $0x2,0x40(%rsp)
  8268b3:	movapd %xmm2,%xmm7
  8268b7:	unpcklpd %xmm5,%xmm7
  8268bb:	cvtpd2ps %xmm7,%xmm7
  8268bf:	cvtps2pd %xmm7,%xmm7
  8268c2:	movups %xmm7,0x48(%rsp)
  8268c7:	movsd  %xmm4,0x58(%rsp)
  8268cd:	mov    %r13,0x60(%rsp)
  8268d2:	movsd  %xmm6,0x68(%rsp)
  8268d8:	movsd  %xmm2,0x70(%rsp)
  8268de:	movsd  %xmm5,0x78(%rsp)
  8268e4:	movsd  %xmm3,0x80(%rsp)
  8268ed:	movups %xmm8,0x88(%rsp)
  8268f6:	cvtss2sd %xmm0,%xmm0
  8268fa:	movsd  %xmm0,0x8(%rsp)
  826900:	xorps  %xmm0,%xmm0
  826903:	cvtss2sd %xmm1,%xmm0
  826907:	movsd  %xmm0,(%rsp)
  82690c:	xor    %ebp,%ebp
  82690e:	xor    %eax,%eax
  826910:	lea    (%rax,%rax,4),%rax
  826914:	lea    (%r15,%rax,8),%rdi
  826918:	movsd  0x18(%r15,%rax,8),%xmm6
  82691f:	movsd  0x20(%r15,%rax,8),%xmm7
  826926:	movsd  0x28(%rsp),%xmm0
  82692c:	movsd  0x20(%rsp),%xmm1
  826932:	movsd  0x18(%rsp),%xmm2
  826938:	movsd  0x10(%rsp),%xmm3
  82693e:	movsd  0x8(%rsp),%xmm4
  826944:	movsd  (%rsp),%xmm5
  826949:	call   825950 <gpui_gpu::renderer::coverage::axis>
  82694e:	cmp    $0x1,%al
  826950:	jne    8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826956:	mov    $0x1,%eax
  82695b:	test   $0x1,%bpl
  82695f:	mov    $0x1,%bpl
  826962:	je     826910 <gpui_gpu::renderer::coverage::whole+0x500>
  826964:	mov    $0x1,%edx
  826969:	test   $0x1,%r12b
  82696d:	mov    $0x1,%r12b
  826970:	mov    %rbx,%rcx
  826973:	movsd  -0x776b3c(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82697c:	je     82683f <gpui_gpu::renderer::coverage::whole+0x42f>
  826982:	mov    $0x1,%al
  826984:	jmp    8264ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826989:	lea    0x6093d0(%rip),%rdx        # e2fd60 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x18>
  826990:	mov    $0x6,%esi
  826995:	call   *0x65abed(%rip)        # e81588 <_DYNAMIC+0x4f8>
  82699b:	add    $0x2,%rdi
  82699f:	lea    0x6093d2(%rip),%rdx        # e2fd78 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x30>
  8269a6:	mov    $0x6,%esi
  8269ab:	call   *0x65abd7(%rip)        # e81588 <_DYNAMIC+0x4f8>
  8269b1:	lea    0x6093d8(%rip),%rdx        # e2fd90 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x48>
  8269b8:	mov    $0x6,%esi
  8269bd:	mov    %rax,%rdi
  8269c0:	call   *0x65abc2(%rip)        # e81588 <_DYNAMIC+0x4f8>
