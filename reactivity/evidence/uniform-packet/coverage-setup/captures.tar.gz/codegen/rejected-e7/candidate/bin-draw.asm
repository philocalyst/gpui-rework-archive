FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4531 frame=840

/tmp/gpui-coverage-final-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008204e0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  8204e0:	push   %rbp
  8204e1:	push   %r15
  8204e3:	push   %r14
  8204e5:	push   %r13
  8204e7:	push   %r12
  8204e9:	push   %rbx
  8204ea:	sub    $0x318,%rsp
  8204f1:	movss  0x88(%rdx),%xmm3
  8204f9:	movss  -0x7714e5(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820501:	movaps %xmm3,%xmm1
  820504:	subss  %xmm0,%xmm1
  820508:	cvttss2si %xmm1,%rax
  82050d:	cvttss2si %xmm3,%r10
  820512:	mov    %r10,%rbp
  820515:	sar    $0x3f,%rbp
  820519:	and    %rax,%rbp
  82051c:	or     %r10,%rbp
  82051f:	xor    %eax,%eax
  820521:	xorps  %xmm1,%xmm1
  820524:	ucomiss %xmm1,%xmm3
  820527:	cmovb  %rax,%rbp
  82052b:	movss  0x90(%rdx),%xmm4
  820533:	movss  -0x77151b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82053b:	ucomiss %xmm2,%xmm3
  82053e:	mov    $0xffffffffffffffff,%r14
  820545:	cmova  %r14,%rbp
  820549:	movaps %xmm4,%xmm3
  82054c:	subss  %xmm0,%xmm3
  820550:	cvttss2si %xmm3,%r10
  820555:	cvttss2si %xmm4,%r11
  82055a:	mov    %r11,%rbx
  82055d:	sar    $0x3f,%rbx
  820561:	and    %r10,%rbx
  820564:	or     %r11,%rbx
  820567:	ucomiss %xmm1,%xmm4
  82056a:	cmovb  %rax,%rbx
  82056e:	ucomiss %xmm2,%xmm4
  820571:	cmova  %r14,%rbx
  820575:	movss  0x8c(%rdx),%xmm3
  82057d:	add    %rbp,%rbx
  820580:	dec    %rbx
  820583:	shr    $0x4,%rbx
  820587:	shr    $0x4,%rbp
  82058b:	mov    %rbx,%r13
  82058e:	sub    %rbp,%r13
  820591:	inc    %r13
  820594:	movaps %xmm3,%xmm4
  820597:	subss  %xmm0,%xmm4
  82059b:	cvttss2si %xmm4,%r11
  8205a0:	cvttss2si %xmm3,%r10
  8205a5:	mov    %r10,%r15
  8205a8:	sar    $0x3f,%r15
  8205ac:	and    %r11,%r15
  8205af:	or     %r10,%r15
  8205b2:	ucomiss %xmm1,%xmm3
  8205b5:	cmovb  %rax,%r15
  8205b9:	ucomiss %xmm2,%xmm3
  8205bc:	movss  0x94(%rdx),%xmm3
  8205c4:	cmova  %r14,%r15
  8205c8:	movaps %xmm3,%xmm4
  8205cb:	subss  %xmm0,%xmm4
  8205cf:	cvttss2si %xmm4,%r12
  8205d4:	cvttss2si %xmm3,%r10
  8205d9:	mov    %r10,%r11
  8205dc:	sar    $0x3f,%r11
  8205e0:	and    %r12,%r11
  8205e3:	or     %r10,%r11
  8205e6:	ucomiss %xmm1,%xmm3
  8205e9:	cmovb  %rax,%r11
  8205ed:	ucomiss %xmm2,%xmm3
  8205f0:	cmova  %r14,%r11
  8205f4:	mov    %r15,%r14
  8205f7:	lea    (%r15,%r11,1),%r10
  8205fb:	dec    %r10
  8205fe:	shr    $0x4,%r10
  820602:	shr    $0x4,%r14
  820606:	mov    %r10,%r12
  820609:	sub    %r14,%r12
  82060c:	inc    %r12
  82060f:	imul   %r13,%r12
  820613:	mov    0x368(%rsp),%r11
  82061b:	add    %r12,%r11
  82061e:	setb   %al
  820621:	cmp    $0x400001,%r11
  820628:	setae  %r15b
  82062c:	or     %al,%r15b
  82062f:	mov    $0x6,%eax
  820634:	jne    820736 <<gpui_gpu::renderer::RendererState>::bin_draw+0x256>
  82063a:	mov    %r12,0x1e8(%rsp)
  820642:	mov    %r11,0x198(%rsp)
  82064a:	mov    %rdi,0x1a0(%rsp)
  820652:	cmpb   $0x0,(%rdx)
  820655:	sete   %al
  820658:	and    0x340(%rsi),%al
  82065e:	movl   $0x0,0x4(%rsp)
  820666:	cmp    $0x1,%al
  820668:	jne    8206f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  82066e:	movss  0xa4(%rdx),%xmm0
  820676:	ucomiss -0x77189d(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82067d:	jne    8206f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  82067f:	jp     8206f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  820681:	mov    0x98(%rdx),%edi
  820687:	test   %edi,%edi
  820689:	jns    82069b <<gpui_gpu::renderer::RendererState>::bin_draw+0x1bb>
  82068b:	and    $0x7f800000,%edi
  820691:	dec    %edi
  820693:	cmp    $0x7f7fffff,%edi
  820699:	jae    8206f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  82069b:	mov    0x9c(%rdx),%edi
  8206a1:	test   %edi,%edi
  8206a3:	jns    8206b5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d5>
  8206a5:	and    $0x7f800000,%edi
  8206ab:	dec    %edi
  8206ad:	cmp    $0x7f7ffffe,%edi
  8206b3:	ja     8206f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8206b5:	mov    0xa0(%rdx),%edi
  8206bb:	test   %edi,%edi
  8206bd:	jns    8206cf <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ef>
  8206bf:	and    $0x7f800000,%edi
  8206c5:	dec    %edi
  8206c7:	cmp    $0x7f7ffffe,%edi
  8206cd:	ja     8206f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8206cf:	movd   %xmm0,%edi
  8206d3:	test   %edi,%edi
  8206d5:	jns    8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8206d7:	and    $0x7f800000,%edi
  8206dd:	dec    %edi
  8206df:	cmp    $0x7f7ffffe,%edi
  8206e5:	ja     8206f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x210>
  8206e7:	mov    $0x1,%dil
  8206ea:	mov    %edi,0x4(%rsp)
  8206ee:	jmp    8206f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x218>
  8206f0:	movl   $0x0,0x4(%rsp)
  8206f8:	mov    %rcx,0xe0(%rsp)
  820700:	mov    %r8d,0xbc(%rsp)
  820708:	mov    %r9,0xa8(%rsp)
  820710:	mov    %rdx,0xe8(%rsp)
  820718:	cmp    %r14,%r10
  82071b:	jae    82074a <<gpui_gpu::renderer::RendererState>::bin_draw+0x26a>
  82071d:	mov    0x1a0(%rsp),%rdi
  820725:	mov    0x198(%rsp),%rax
  82072d:	mov    %rax,0x8(%rdi)
  820731:	mov    $0xffffffff,%eax
  820736:	mov    %eax,(%rdi)
  820738:	add    $0x318,%rsp
  82073f:	pop    %rbx
  820740:	pop    %r12
  820742:	pop    %r13
  820744:	pop    %r14
  820746:	pop    %r15
  820748:	pop    %rbp
  820749:	ret
  82074a:	cmp    %rbp,%rbx
  82074d:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  82074f:	nop
  820750:	mov    %r14,%rax
  820753:	cmp    %r10,%r14
  820756:	adc    $0x0,%r14
  82075a:	cmp    %r10,%rax
  82075d:	jae    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82075f:	cmp    %r10,%r14
  820762:	jbe    820750 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  820764:	jmp    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  820766:	mov    0x350(%rsp),%r13
  82076e:	mov    0x20(%rsi),%r15
  820772:	mov    0x28(%rsi),%r9
  820776:	test   %al,%al
  820778:	je     8215d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  82077e:	mov    0xe0(%rsp),%rax
  820786:	movd   %eax,%xmm0
  82078a:	shr    $0x20,%rax
  82078e:	mov    0xe8(%rsp),%rcx
  820796:	movss  0x78(%rcx),%xmm1
  82079b:	cvtss2sd %xmm1,%xmm12
  8207a0:	movss  0x80(%rcx),%xmm1
  8207a8:	movss  0x7c(%rcx),%xmm2
  8207ad:	xorps  %xmm3,%xmm3
  8207b0:	cvtss2sd %xmm2,%xmm3
  8207b4:	movss  0x84(%rcx),%xmm2
  8207bc:	cvtss2sd %xmm1,%xmm1
  8207c0:	addsd  %xmm12,%xmm1
  8207c5:	movsd  %xmm1,0x1d8(%rsp)
  8207ce:	xorps  %xmm1,%xmm1
  8207d1:	cvtss2sd %xmm2,%xmm1
  8207d5:	movsd  %xmm3,0x1e0(%rsp)
  8207de:	addsd  %xmm3,%xmm1
  8207e2:	movsd  %xmm1,0x1c8(%rsp)
  8207eb:	movsd  0x48(%rcx),%xmm3
  8207f0:	movsd  0x58(%rcx),%xmm4
  8207f5:	movsd  0x68(%rcx),%xmm5
  8207fa:	movss  0x38(%rcx),%xmm1
  8207ff:	movss  0x40(%rcx),%xmm2
  820804:	cvtss2sd %xmm1,%xmm1
  820808:	cvtss2sd %xmm2,%xmm2
  82080c:	movaps -0x7759e3(%rip),%xmm6        # aae30 <GCC_except_table0+0x7c>
  820813:	movaps %xmm1,0x90(%rsp)
  82081b:	andps  %xmm6,%xmm1
  82081e:	movaps %xmm1,0x80(%rsp)
  820826:	movaps %xmm2,0x60(%rsp)
  82082b:	andps  %xmm6,%xmm2
  82082e:	movaps %xmm2,0x70(%rsp)
  820833:	cvtss2sd %xmm0,%xmm0
  820837:	movsd  %xmm0,0x18(%rsp)
  82083d:	movaps %xmm3,%xmm0
  820840:	andps  %xmm6,%xmm0
  820843:	movaps %xmm0,0x290(%rsp)
  82084b:	movaps %xmm4,%xmm0
  82084e:	andps  %xmm6,%xmm0
  820851:	movaps %xmm0,0x270(%rsp)
  820859:	movaps %xmm5,%xmm0
  82085c:	andps  %xmm6,%xmm0
  82085f:	movaps %xmm0,0x130(%rsp)
  820867:	movss  0x3c(%rcx),%xmm0
  82086c:	xorps  %xmm1,%xmm1
  82086f:	cvtss2sd %xmm0,%xmm1
  820873:	movss  0x44(%rcx),%xmm0
  820878:	cvtss2sd %xmm0,%xmm0
  82087c:	movaps %xmm1,0x50(%rsp)
  820881:	andps  %xmm6,%xmm1
  820884:	movaps %xmm1,0x40(%rsp)
  820889:	movaps %xmm0,0x20(%rsp)
  82088e:	andps  %xmm6,%xmm0
  820891:	movaps %xmm0,0x30(%rsp)
  820896:	movd   %eax,%xmm0
  82089a:	cvtss2sd %xmm0,%xmm0
  82089e:	movsd  %xmm0,0x10(%rsp)
  8208a4:	movsd  0x50(%rcx),%xmm1
  8208a9:	movaps %xmm1,%xmm0
  8208ac:	andps  %xmm6,%xmm0
  8208af:	movaps %xmm0,0x210(%rsp)
  8208b7:	movsd  0x60(%rcx),%xmm2
  8208bc:	movaps %xmm2,%xmm0
  8208bf:	andps  %xmm6,%xmm0
  8208c2:	movaps %xmm0,0x1f0(%rsp)
  8208ca:	movsd  0x70(%rcx),%xmm7
  8208cf:	andps  %xmm7,%xmm6
  8208d2:	movaps %xmm6,0x100(%rsp)
  8208da:	mov    0x58(%rsi),%rax
  8208de:	mov    %rax,0xd8(%rsp)
  8208e6:	mov    0x50(%rsi),%rax
  8208ea:	mov    %rax,0x1d0(%rsp)
  8208f2:	movaps %xmm3,0x2a0(%rsp)
  8208fa:	movaps %xmm3,%xmm0
  8208fd:	movaps %xmm4,0x280(%rsp)
  820905:	movlhps %xmm4,%xmm0
  820908:	cvtpd2ps %xmm0,%xmm0
  82090c:	movaps %xmm1,0x220(%rsp)
  820914:	cvtsd2ss %xmm1,%xmm1
  820918:	cvtss2sd %xmm1,%xmm1
  82091c:	cvtps2pd %xmm0,%xmm3
  82091f:	movaps %xmm2,0x200(%rsp)
  820927:	xorps  %xmm0,%xmm0
  82092a:	cvtsd2ss %xmm2,%xmm0
  82092e:	xorps  %xmm2,%xmm2
  820931:	cvtss2sd %xmm0,%xmm2
  820935:	movaps %xmm5,0x140(%rsp)
  82093d:	xorps  %xmm0,%xmm0
  820940:	cvtsd2ss %xmm5,%xmm0
  820944:	cvtss2sd %xmm0,%xmm4
  820948:	movaps %xmm7,0xf0(%rsp)
  820950:	xorps  %xmm0,%xmm0
  820953:	cvtsd2ss %xmm7,%xmm0
  820957:	mov    0xa8(%rsp),%rax
  82095f:	inc    %eax
  820961:	mov    %rax,0xa8(%rsp)
  820969:	cvtss2sd %xmm0,%xmm0
  82096d:	movaps -0x775b44(%rip),%xmm5        # aae30 <GCC_except_table0+0x7c>
  820974:	movaps %xmm3,%xmm6
  820977:	andps  %xmm5,%xmm6
  82097a:	movaps %xmm4,0x160(%rsp)
  820982:	andps  %xmm5,%xmm4
  820985:	movaps %xmm4,0x150(%rsp)
  82098d:	movaps %xmm1,0x260(%rsp)
  820995:	andps  %xmm5,%xmm1
  820998:	movaps %xmm1,0x250(%rsp)
  8209a0:	movaps %xmm2,0x240(%rsp)
  8209a8:	andps  %xmm5,%xmm2
  8209ab:	movaps %xmm2,0x230(%rsp)
  8209b3:	movaps %xmm0,0x120(%rsp)
  8209bb:	andps  %xmm0,%xmm5
  8209be:	movaps %xmm5,0x110(%rsp)
  8209c6:	movaps %xmm3,0x2c0(%rsp)
  8209ce:	movhlps %xmm3,%xmm3
  8209d1:	movaps %xmm3,0x2f0(%rsp)
  8209d9:	mov    $0x2,%r11b
  8209dc:	xor    %edx,%edx
  8209de:	mov    %r14,%rax
  8209e1:	movaps %xmm6,0x2b0(%rsp)
  8209e9:	pshufd $0xee,%xmm6,%xmm0
  8209ee:	movdqa %xmm0,0x2e0(%rsp)
  8209f7:	movsd  %xmm12,0x8(%rsp)
  8209fe:	mov    %rbp,0x1b0(%rsp)
  820a06:	mov    %r10,0x1a8(%rsp)
  820a0e:	xchg   %ax,%ax
  820a10:	cmp    %r10,%r14
  820a13:	adc    $0x0,%rax
  820a17:	mov    %rax,0x1b8(%rsp)
  820a1f:	mov    %r14,0x1c0(%rsp)
  820a27:	imul   %r13,%r14
  820a2b:	mov    %rbp,%r10
  820a2e:	mov    0x360(%rsp),%r8d
  820a36:	mov    0x358(%rsp),%ecx
  820a3d:	jmp    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820a3f:	cmp    %r9,%r12
  820a42:	jae    821635 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820a48:	incl   0x4(%r15,%r12,8)
  820a4d:	mov    $0x1,%dl
  820a4f:	cmp    %rbx,%r10
  820a52:	jb     820c23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820a58:	jmp    821590 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820a5d:	nopl   (%rax)
  820a60:	cmp    %rbx,%r10
  820a63:	adc    $0x0,%rbp
  820a67:	lea    (%r10,%r14,1),%r12
  820a6b:	cmpb   $0x0,0x4(%rsp)
  820a70:	jne    820a87 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a7>
  820a72:	cmp    %r9,%r12
  820a75:	jae    821655 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1175>
  820a7b:	testb  $0x40,0x7(%r15,%r12,8)
  820a81:	je     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820a87:	cmpq   $0x2,0x1e8(%rsp)
  820a90:	setae  %al
  820a93:	and    %dl,%al
  820a95:	cmp    $0x1,%al
  820a97:	jne    820b72 <<gpui_gpu::renderer::RendererState>::bin_draw+0x692>
  820a9d:	cmp    $0x2,%r11b
  820aa1:	jne    820b0c <<gpui_gpu::renderer::RendererState>::bin_draw+0x62c>
  820aa3:	mov    %r10,0xb0(%rsp)
  820aab:	mov    0xe8(%rsp),%rdi
  820ab3:	mov    0xe0(%rsp),%rsi
  820abb:	mov    %r13,%rdx
  820abe:	mov    %rbp,0xc0(%rsp)
  820ac6:	mov    %rbx,%rbp
  820ac9:	mov    %r14,%rbx
  820acc:	mov    %r15,%r14
  820acf:	mov    %r9,%r15
  820ad2:	call   826410 <gpui_gpu::renderer::coverage::whole>
  820ad7:	mov    0xb0(%rsp),%r10
  820adf:	movsd  0x8(%rsp),%xmm12
  820ae6:	mov    0x360(%rsp),%r8d
  820aee:	mov    %r15,%r9
  820af1:	mov    %r14,%r15
  820af4:	mov    %rbx,%r14
  820af7:	mov    %rbp,%rbx
  820afa:	mov    0xc0(%rsp),%rbp
  820b02:	mov    0x358(%rsp),%ecx
  820b09:	mov    %eax,%r11d
  820b0c:	test   $0x1,%r11b
  820b10:	mov    $0x1,%r11b
  820b13:	je     820b6f <<gpui_gpu::renderer::RendererState>::bin_draw+0x68f>
  820b15:	cmpb   $0x0,0x4(%rsp)
  820b1a:	je     820a3f <<gpui_gpu::renderer::RendererState>::bin_draw+0x55f>
  820b20:	cmp    %r9,%r12
  820b23:	jae    821680 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11a0>
  820b29:	mov    0xbc(%rsp),%eax
  820b30:	mov    %eax,(%r15,%r12,8)
  820b34:	movl   $0x40000001,0x4(%r15,%r12,8)
  820b3d:	cmp    0xd8(%rsp),%r12
  820b45:	jae    821668 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1188>
  820b4b:	mov    0xa8(%rsp),%rax
  820b53:	mov    0x1d0(%rsp),%rdx
  820b5b:	mov    %eax,(%rdx,%r12,4)
  820b5f:	mov    $0x1,%dl
  820b61:	cmp    %rbx,%r10
  820b64:	jb     820c23 <<gpui_gpu::renderer::RendererState>::bin_draw+0x743>
  820b6a:	jmp    821590 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820b6f:	xor    %r11d,%r11d
  820b72:	test   %r13,%r13
  820b75:	je     821648 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1168>
  820b7b:	mov    %r12,%rax
  820b7e:	shr    $0x20,%rax
  820b82:	je     820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b0>
  820b84:	mov    %r12,%rax
  820b87:	xor    %edx,%edx
  820b89:	div    %r13
  820b8c:	jmp    820b98 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b8>
  820b8e:	xchg   %ax,%ax
  820b90:	mov    %r12d,%eax
  820b93:	xor    %edx,%edx
  820b95:	div    %r13d
  820b98:	shl    $0x4,%edx
  820b9b:	shl    $0x4,%eax
  820b9e:	lea    0x10(%rdx),%esi
  820ba1:	cmp    %esi,%ecx
  820ba3:	cmovb  %ecx,%esi
  820ba6:	lea    0x10(%rax),%edi
  820ba9:	cmp    %edi,%r8d
  820bac:	cmovb  %r8d,%edi
  820bb0:	xorps  %xmm2,%xmm2
  820bb3:	cvtsi2sd %edx,%xmm2
  820bb7:	mov    $0x1,%dl
  820bb9:	ucomisd %xmm2,%xmm12
  820bbe:	ja     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820bc0:	mov    %eax,%eax
  820bc2:	xorps  %xmm3,%xmm3
  820bc5:	cvtsi2sd %rax,%xmm3
  820bca:	movsd  0x1e0(%rsp),%xmm0
  820bd3:	ucomisd %xmm3,%xmm0
  820bd7:	ja     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820bd9:	xorps  %xmm0,%xmm0
  820bdc:	cvtsi2sd %esi,%xmm0
  820be0:	ucomisd 0x1d8(%rsp),%xmm0
  820be9:	ja     820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820beb:	xorps  %xmm1,%xmm1
  820bee:	cvtsi2sd %edi,%xmm1
  820bf2:	ucomisd 0x1c8(%rsp),%xmm1
  820bfb:	jbe    820c34 <<gpui_gpu::renderer::RendererState>::bin_draw+0x754>
  820bfd:	nopl   (%rax)
  820c00:	cmp    %r9,%r12
  820c03:	jae    821635 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  820c09:	mov    0x4(%r15,%r12,8),%eax
  820c0e:	inc    %eax
  820c10:	and    $0xbfffffff,%eax
  820c15:	mov    %eax,0x4(%r15,%r12,8)
  820c1a:	cmp    %rbx,%r10
  820c1d:	jae    821590 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820c23:	mov    %rbp,%r10
  820c26:	cmp    %rbx,%rbp
  820c29:	jbe    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820c2f:	jmp    821590 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10b0>
  820c34:	unpcklpd %xmm3,%xmm2
  820c38:	addpd  -0x773b00(%rip),%xmm2        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820c40:	movapd %xmm2,%xmm3
  820c44:	mulpd  0x2c0(%rsp),%xmm3
  820c4d:	movapd %xmm3,%xmm11
  820c52:	unpckhpd %xmm3,%xmm11
  820c57:	movapd %xmm3,%xmm5
  820c5b:	addsd  %xmm11,%xmm5
  820c60:	addsd  0x160(%rsp),%xmm5
  820c69:	subsd  0x90(%rsp),%xmm5
  820c72:	movapd 0x2b0(%rsp),%xmm8
  820c7c:	mulpd  %xmm2,%xmm8
  820c81:	movapd %xmm8,%xmm4
  820c86:	unpckhpd %xmm8,%xmm4
  820c8b:	movapd %xmm8,%xmm6
  820c90:	addsd  %xmm4,%xmm6
  820c94:	addsd  0x150(%rsp),%xmm6
  820c9d:	addsd  0x80(%rsp),%xmm6
  820ca6:	addsd  0x70(%rsp),%xmm6
  820cac:	addsd  -0x7713d4(%rip),%xmm6        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cb4:	mulsd  -0x77145c(%rip),%xmm6        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cbc:	addsd  0x18(%rsp),%xmm6
  820cc2:	ucomisd %xmm5,%xmm6
  820cc6:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820ccc:	movapd 0x60(%rsp),%xmm7
  820cd2:	subsd  %xmm5,%xmm7
  820cd6:	ucomisd %xmm7,%xmm6
  820cda:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820ce0:	movapd %xmm2,%xmm13
  820ce5:	unpckhpd %xmm2,%xmm13
  820cea:	movapd 0x280(%rsp),%xmm15
  820cf4:	mulsd  %xmm13,%xmm15
  820cf9:	movapd 0x270(%rsp),%xmm14
  820d03:	mulsd  %xmm13,%xmm14
  820d08:	movapd 0x2a0(%rsp),%xmm5
  820d11:	mulsd  %xmm2,%xmm5
  820d15:	movapd %xmm5,%xmm6
  820d19:	addsd  %xmm15,%xmm6
  820d1e:	addsd  0x140(%rsp),%xmm6
  820d27:	subsd  0x90(%rsp),%xmm6
  820d30:	movapd 0x290(%rsp),%xmm7
  820d39:	mulsd  %xmm2,%xmm7
  820d3d:	movapd %xmm7,%xmm9
  820d42:	addsd  %xmm14,%xmm9
  820d47:	addsd  0x130(%rsp),%xmm9
  820d51:	addsd  0x80(%rsp),%xmm9
  820d5b:	addsd  0x70(%rsp),%xmm9
  820d62:	addsd  -0x77148b(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d6b:	mulsd  -0x770f34(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d74:	ucomisd %xmm6,%xmm9
  820d79:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820d7f:	movapd 0x60(%rsp),%xmm10
  820d86:	subsd  %xmm6,%xmm10
  820d8b:	ucomisd %xmm10,%xmm9
  820d90:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  820d96:	movapd %xmm13,%xmm9
  820d9b:	mulsd  0x240(%rsp),%xmm9
  820da5:	movapd %xmm13,%xmm12
  820daa:	mulsd  0x230(%rsp),%xmm12
  820db4:	movapd %xmm2,%xmm10
  820db9:	mulsd  0x260(%rsp),%xmm10
  820dc3:	movapd %xmm10,%xmm6
  820dc8:	movapd %xmm9,0xc0(%rsp)
  820dd2:	addsd  %xmm9,%xmm6
  820dd7:	addsd  0x120(%rsp),%xmm6
  820de0:	subsd  0x50(%rsp),%xmm6
  820de6:	movapd %xmm2,%xmm9
  820deb:	mulsd  0x250(%rsp),%xmm9
  820df5:	movsd  %xmm9,0xb0(%rsp)
  820dff:	addsd  %xmm12,%xmm9
  820e04:	addsd  0x110(%rsp),%xmm9
  820e0e:	addsd  0x40(%rsp),%xmm9
  820e15:	addsd  0x30(%rsp),%xmm9
  820e1c:	addsd  -0x771545(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e25:	mulsd  -0x7715ce(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e2e:	addsd  0x10(%rsp),%xmm9
  820e35:	ucomisd %xmm6,%xmm9
  820e3a:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820e40:	movsd  %xmm10,0x190(%rsp)
  820e4a:	movapd 0x20(%rsp),%xmm10
  820e51:	subsd  %xmm6,%xmm10
  820e56:	ucomisd %xmm10,%xmm9
  820e5b:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820e61:	movapd 0x200(%rsp),%xmm9
  820e6b:	mulsd  %xmm13,%xmm9
  820e70:	mulsd  0x1f0(%rsp),%xmm13
  820e7a:	movapd 0x220(%rsp),%xmm10
  820e84:	mulsd  %xmm2,%xmm10
  820e89:	movapd %xmm10,%xmm6
  820e8e:	movapd %xmm9,0x170(%rsp)
  820e98:	addsd  %xmm9,%xmm6
  820e9d:	addsd  0xf0(%rsp),%xmm6
  820ea6:	subsd  0x50(%rsp),%xmm6
  820eac:	mulsd  0x210(%rsp),%xmm2
  820eb5:	movapd %xmm2,%xmm9
  820eba:	addsd  %xmm13,%xmm9
  820ebf:	addsd  0x100(%rsp),%xmm9
  820ec9:	addsd  0x40(%rsp),%xmm9
  820ed0:	addsd  0x30(%rsp),%xmm9
  820ed7:	addsd  -0x771600(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ee0:	mulsd  -0x7710a9(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820ee9:	ucomisd %xmm6,%xmm9
  820eee:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820ef4:	movapd %xmm10,0x300(%rsp)
  820efe:	movapd 0x20(%rsp),%xmm10
  820f05:	subsd  %xmm6,%xmm10
  820f0a:	ucomisd %xmm10,%xmm9
  820f0f:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820f15:	addsd  -0x771935(%rip),%xmm0        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820f1d:	movapd %xmm0,%xmm9
  820f22:	mulsd  0x2c0(%rsp),%xmm9
  820f2c:	addsd  %xmm9,%xmm11
  820f31:	addsd  0x160(%rsp),%xmm11
  820f3b:	subsd  0x90(%rsp),%xmm11
  820f45:	movapd 0x2b0(%rsp),%xmm10
  820f4f:	mulsd  %xmm0,%xmm10
  820f54:	addsd  %xmm10,%xmm4
  820f59:	addsd  0x150(%rsp),%xmm4
  820f62:	addsd  0x80(%rsp),%xmm4
  820f6b:	addsd  0x70(%rsp),%xmm4
  820f71:	addsd  -0x771699(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f79:	mulsd  -0x771721(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f81:	addsd  0x18(%rsp),%xmm4
  820f87:	ucomisd %xmm11,%xmm4
  820f8c:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820f92:	movapd 0x60(%rsp),%xmm6
  820f98:	subsd  %xmm11,%xmm6
  820f9d:	ucomisd %xmm6,%xmm4
  820fa1:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  820fa7:	movapd 0x2a0(%rsp),%xmm6
  820fb0:	mulsd  %xmm0,%xmm6
  820fb4:	addsd  %xmm6,%xmm15
  820fb9:	addsd  0x140(%rsp),%xmm15
  820fc3:	subsd  0x90(%rsp),%xmm15
  820fcd:	movapd 0x290(%rsp),%xmm11
  820fd7:	mulsd  %xmm0,%xmm11
  820fdc:	addsd  %xmm11,%xmm14
  820fe1:	addsd  0x130(%rsp),%xmm14
  820feb:	addsd  0x80(%rsp),%xmm14
  820ff5:	addsd  0x70(%rsp),%xmm14
  820ffc:	addsd  -0x771725(%rip),%xmm14        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821005:	mulsd  -0x7711ce(%rip),%xmm14        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82100e:	ucomisd %xmm15,%xmm14
  821013:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  821019:	movapd 0x60(%rsp),%xmm4
  82101f:	subsd  %xmm15,%xmm4
  821024:	ucomisd %xmm4,%xmm14
  821029:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  82102f:	movapd %xmm0,%xmm14
  821034:	mulsd  0x260(%rsp),%xmm14
  82103e:	movapd 0xc0(%rsp),%xmm4
  821047:	addsd  %xmm14,%xmm4
  82104c:	addsd  0x120(%rsp),%xmm4
  821055:	subsd  0x50(%rsp),%xmm4
  82105b:	movapd %xmm0,%xmm15
  821060:	mulsd  0x250(%rsp),%xmm15
  82106a:	addsd  %xmm15,%xmm12
  82106f:	addsd  0x110(%rsp),%xmm12
  821079:	addsd  0x40(%rsp),%xmm12
  821080:	addsd  0x30(%rsp),%xmm12
  821087:	addsd  -0x7717b0(%rip),%xmm12        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821090:	mulsd  -0x771839(%rip),%xmm12        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821099:	addsd  0x10(%rsp),%xmm12
  8210a0:	ucomisd %xmm4,%xmm12
  8210a5:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8210ab:	movsd  %xmm15,0xc0(%rsp)
  8210b5:	movapd %xmm4,%xmm15
  8210ba:	movapd 0x20(%rsp),%xmm4
  8210c0:	subsd  %xmm15,%xmm4
  8210c5:	ucomisd %xmm4,%xmm12
  8210ca:	jae    82157e <<gpui_gpu::renderer::RendererState>::bin_draw+0x109e>
  8210d0:	movapd 0x220(%rsp),%xmm4
  8210d9:	mulsd  %xmm0,%xmm4
  8210dd:	movapd 0x170(%rsp),%xmm15
  8210e7:	addsd  %xmm4,%xmm15
  8210ec:	addsd  0xf0(%rsp),%xmm15
  8210f6:	subsd  0x50(%rsp),%xmm15
  8210fd:	mulsd  0x210(%rsp),%xmm0
  821106:	addsd  %xmm0,%xmm13
  82110b:	addsd  0x100(%rsp),%xmm13
  821115:	addsd  0x40(%rsp),%xmm13
  82111c:	addsd  0x30(%rsp),%xmm13
  821123:	addsd  -0x77184c(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82112c:	mulsd  -0x7712f5(%rip),%xmm13        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821135:	ucomisd %xmm15,%xmm13
  82113a:	movsd  0x8(%rsp),%xmm12
  821141:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821147:	movapd %xmm4,0x170(%rsp)
  821150:	movapd 0x20(%rsp),%xmm4
  821156:	subsd  %xmm15,%xmm4
  82115b:	ucomisd %xmm4,%xmm13
  821160:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821166:	movsd  %xmm10,0x188(%rsp)
  821170:	addsd  -0x771b90(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  821178:	movapd %xmm1,%xmm10
  82117d:	mulsd  0x2f0(%rsp),%xmm10
  821187:	movapd %xmm1,%xmm4
  82118b:	mulsd  0x2e0(%rsp),%xmm4
  821194:	addsd  %xmm10,%xmm3
  821199:	addsd  0x160(%rsp),%xmm3
  8211a2:	subsd  0x90(%rsp),%xmm3
  8211ab:	addsd  %xmm4,%xmm8
  8211b0:	addsd  0x150(%rsp),%xmm8
  8211ba:	addsd  0x80(%rsp),%xmm8
  8211c4:	addsd  0x70(%rsp),%xmm8
  8211cb:	addsd  -0x7718f4(%rip),%xmm8        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211d4:	mulsd  -0x77197d(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8211dd:	addsd  0x18(%rsp),%xmm8
  8211e4:	ucomisd %xmm3,%xmm8
  8211e9:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8211ef:	movapd %xmm6,0x2d0(%rsp)
  8211f8:	movapd 0x60(%rsp),%xmm6
  8211fe:	subsd  %xmm3,%xmm6
  821202:	ucomisd %xmm6,%xmm8
  821207:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82120d:	movapd 0x280(%rsp),%xmm8
  821217:	mulsd  %xmm1,%xmm8
  82121c:	movapd 0x270(%rsp),%xmm3
  821225:	mulsd  %xmm1,%xmm3
  821229:	addsd  %xmm8,%xmm5
  82122e:	addsd  0x140(%rsp),%xmm5
  821237:	subsd  0x90(%rsp),%xmm5
  821240:	addsd  %xmm3,%xmm7
  821244:	addsd  0x130(%rsp),%xmm7
  82124d:	addsd  0x80(%rsp),%xmm7
  821256:	addsd  0x70(%rsp),%xmm7
  82125c:	addsd  -0x771984(%rip),%xmm7        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821264:	mulsd  -0x77142c(%rip),%xmm7        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82126c:	ucomisd %xmm5,%xmm7
  821270:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821276:	movapd 0x60(%rsp),%xmm6
  82127c:	subsd  %xmm5,%xmm6
  821280:	ucomisd %xmm6,%xmm7
  821284:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82128a:	movsd  %xmm14,0x180(%rsp)
  821294:	movapd %xmm9,%xmm14
  821299:	movapd %xmm1,%xmm7
  82129d:	mulsd  0x240(%rsp),%xmm7
  8212a6:	movapd %xmm1,%xmm5
  8212aa:	mulsd  0x230(%rsp),%xmm5
  8212b3:	movsd  0x190(%rsp),%xmm9
  8212bd:	addsd  %xmm7,%xmm9
  8212c2:	addsd  0x120(%rsp),%xmm9
  8212cc:	subsd  0x50(%rsp),%xmm9
  8212d3:	movsd  0xb0(%rsp),%xmm13
  8212dd:	addsd  %xmm5,%xmm13
  8212e2:	addsd  0x110(%rsp),%xmm13
  8212ec:	addsd  0x40(%rsp),%xmm13
  8212f3:	addsd  0x30(%rsp),%xmm13
  8212fa:	addsd  -0x771a23(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821303:	mulsd  -0x771aac(%rip),%xmm13        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82130c:	addsd  0x10(%rsp),%xmm13
  821313:	ucomisd %xmm9,%xmm13
  821318:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82131e:	movapd 0x20(%rsp),%xmm6
  821324:	subsd  %xmm9,%xmm6
  821329:	ucomisd %xmm6,%xmm13
  82132e:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821334:	movapd 0x200(%rsp),%xmm6
  82133d:	mulsd  %xmm1,%xmm6
  821341:	mulsd  0x1f0(%rsp),%xmm1
  82134a:	movapd 0x300(%rsp),%xmm13
  821354:	addsd  %xmm6,%xmm13
  821359:	addsd  0xf0(%rsp),%xmm13
  821363:	subsd  0x50(%rsp),%xmm13
  82136a:	addsd  %xmm1,%xmm2
  82136e:	addsd  0x100(%rsp),%xmm2
  821377:	addsd  0x40(%rsp),%xmm2
  82137d:	addsd  0x30(%rsp),%xmm2
  821383:	addsd  -0x771aab(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82138b:	mulsd  -0x771553(%rip),%xmm2        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821393:	ucomisd %xmm13,%xmm2
  821398:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82139e:	movapd 0x20(%rsp),%xmm9
  8213a5:	subsd  %xmm13,%xmm9
  8213aa:	ucomisd %xmm9,%xmm2
  8213af:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8213b5:	addsd  %xmm10,%xmm14
  8213ba:	addsd  0x160(%rsp),%xmm14
  8213c4:	subsd  0x90(%rsp),%xmm14
  8213ce:	movsd  0x188(%rsp),%xmm9
  8213d8:	addsd  %xmm4,%xmm9
  8213dd:	addsd  0x150(%rsp),%xmm9
  8213e7:	addsd  0x80(%rsp),%xmm9
  8213f1:	addsd  0x70(%rsp),%xmm9
  8213f8:	addsd  -0x771b21(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821401:	mulsd  -0x771baa(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82140a:	addsd  0x18(%rsp),%xmm9
  821411:	ucomisd %xmm14,%xmm9
  821416:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82141c:	movapd 0x60(%rsp),%xmm2
  821422:	subsd  %xmm14,%xmm2
  821427:	ucomisd %xmm2,%xmm9
  82142c:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821432:	movapd 0x2d0(%rsp),%xmm4
  82143b:	addsd  %xmm8,%xmm4
  821440:	addsd  0x140(%rsp),%xmm4
  821449:	subsd  0x90(%rsp),%xmm4
  821452:	addsd  %xmm3,%xmm11
  821457:	addsd  0x130(%rsp),%xmm11
  821461:	addsd  0x80(%rsp),%xmm11
  82146b:	addsd  0x70(%rsp),%xmm11
  821472:	addsd  -0x771b9b(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82147b:	mulsd  -0x771644(%rip),%xmm11        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821484:	ucomisd %xmm4,%xmm11
  821489:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82148f:	movapd 0x60(%rsp),%xmm2
  821495:	subsd  %xmm4,%xmm2
  821499:	ucomisd %xmm2,%xmm11
  82149e:	movsd  0x180(%rsp),%xmm3
  8214a7:	movsd  0xc0(%rsp),%xmm4
  8214b0:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  8214b6:	addsd  %xmm7,%xmm3
  8214ba:	addsd  0x120(%rsp),%xmm3
  8214c3:	subsd  0x50(%rsp),%xmm3
  8214c9:	addsd  %xmm5,%xmm4
  8214cd:	addsd  0x110(%rsp),%xmm4
  8214d6:	addsd  0x40(%rsp),%xmm4
  8214dc:	addsd  0x30(%rsp),%xmm4
  8214e2:	addsd  -0x771c0a(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214ea:	mulsd  -0x771c92(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8214f2:	addsd  0x10(%rsp),%xmm4
  8214f8:	ucomisd %xmm3,%xmm4
  8214fc:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821502:	movapd 0x20(%rsp),%xmm2
  821508:	subsd  %xmm3,%xmm2
  82150c:	ucomisd %xmm2,%xmm4
  821510:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821516:	movapd 0x170(%rsp),%xmm3
  82151f:	addsd  %xmm6,%xmm3
  821523:	addsd  0xf0(%rsp),%xmm3
  82152c:	subsd  0x50(%rsp),%xmm3
  821532:	addsd  %xmm1,%xmm0
  821536:	addsd  0x100(%rsp),%xmm0
  82153f:	addsd  0x40(%rsp),%xmm0
  821545:	addsd  0x30(%rsp),%xmm0
  82154b:	addsd  -0x771c73(%rip),%xmm0        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821553:	mulsd  -0x77171b(%rip),%xmm0        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82155b:	ucomisd %xmm3,%xmm0
  82155f:	jae    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  821565:	movapd 0x20(%rsp),%xmm1
  82156b:	subsd  %xmm3,%xmm1
  82156f:	ucomisd %xmm1,%xmm0
  821573:	jb     820b15 <<gpui_gpu::renderer::RendererState>::bin_draw+0x635>
  821579:	jmp    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82157e:	movsd  0x8(%rsp),%xmm12
  821585:	jmp    820c00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x720>
  82158a:	nopw   0x0(%rax,%rax,1)
  821590:	mov    0x1a8(%rsp),%r10
  821598:	cmp    %r10,0x1c0(%rsp)
  8215a0:	mov    0x1b0(%rsp),%rbp
  8215a8:	mov    0x1b8(%rsp),%rax
  8215b0:	jae    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8215b6:	mov    %rax,%r14
  8215b9:	cmp    %r10,%rax
  8215bc:	jbe    820a10 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  8215c2:	jmp    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  8215c7:	nopw   0x0(%rax,%rax,1)
  8215d0:	mov    %r14,%rax
  8215d3:	cmp    %r10,%r14
  8215d6:	adc    $0x0,%r14
  8215da:	mov    %rax,%rcx
  8215dd:	imul   %r13,%rcx
  8215e1:	mov    %rbp,%rdx
  8215e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  8215f0:	lea    (%rdx,%rcx,1),%r12
  8215f4:	cmp    %r9,%r12
  8215f7:	jae    821635 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1155>
  8215f9:	cmp    %rbx,%rdx
  8215fc:	mov    %rdx,%rsi
  8215ff:	adc    $0x0,%rsi
  821603:	mov    0x4(%r15,%r12,8),%edi
  821608:	inc    %edi
  82160a:	and    $0xbfffffff,%edi
  821610:	mov    %edi,0x4(%r15,%r12,8)
  821615:	cmp    %rbx,%rdx
  821618:	jae    821622 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1142>
  82161a:	mov    %rsi,%rdx
  82161d:	cmp    %rbx,%rsi
  821620:	jbe    8215f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1110>
  821622:	cmp    %r10,%rax
  821625:	jae    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  82162b:	cmp    %r10,%r14
  82162e:	jbe    8215d0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  821630:	jmp    82071d <<gpui_gpu::renderer::RendererState>::bin_draw+0x23d>
  821635:	lea    0x60e584(%rip),%rdx        # e2fbc0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x108>
  82163c:	mov    %r12,%rdi
  82163f:	mov    %r9,%rsi
  821642:	call   *0x65ff40(%rip)        # e81588 <_DYNAMIC+0x4f8>
  821648:	lea    0x60e691(%rip),%rdi        # e2fce0 <anon.7e34a6dced7fe4eb77116889a7de5f31.41.llvm.6877253771164693793>
  82164f:	call   *0x660013(%rip)        # e81668 <_DYNAMIC+0x5d8>
  821655:	lea    0x60e54c(%rip),%rdx        # e2fba8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0xf0>
  82165c:	mov    %r12,%rdi
  82165f:	mov    %r9,%rsi
  821662:	call   *0x65ff20(%rip)        # e81588 <_DYNAMIC+0x4f8>
  821668:	lea    0x60e581(%rip),%rdx        # e2fbf0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x138>
  82166f:	mov    %r12,%rdi
  821672:	mov    0xd8(%rsp),%rsi
  82167a:	call   *0x65ff08(%rip)        # e81588 <_DYNAMIC+0x4f8>
  821680:	lea    0x60e551(%rip),%rdx        # e2fbd8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x120>
  821687:	mov    %r12,%rdi
  82168a:	mov    %r9,%rsi
  82168d:	call   *0x65fef5(%rip)        # e81588 <_DYNAMIC+0x4f8>
