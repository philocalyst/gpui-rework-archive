FUNCTION gpui_gpu::renderer::coverage::whole bytes=1462 frame=248

/tmp/gpui-coverage-sealed-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825fe0 <gpui_gpu::renderer::coverage::whole>:
  825fe0:	push   %rbp
  825fe1:	push   %r15
  825fe3:	push   %r14
  825fe5:	push   %r13
  825fe7:	push   %r12
  825fe9:	push   %rbx
  825fea:	sub    $0xc8,%rsp
  825ff1:	mov    %rsi,0x30(%rsp)
  825ff6:	cmpb   $0x0,(%rdi)
  825ff9:	jne    82609c <gpui_gpu::renderer::coverage::whole+0xbc>
  825fff:	test   %esi,%esi
  826001:	sets   %al
  826004:	mov    %esi,%r9d
  826007:	and    $0x7fffffff,%r9d
  82600e:	lea    -0x800000(%r9),%r10d
  826015:	cmp    $0x7f000000,%r10d
  82601c:	setb   %r10b
  826020:	and    %al,%r10b
  826023:	lea    -0x1(%r9),%r11d
  826027:	cmp    $0x7fffff,%r11d
  82602e:	setb   %r11b
  826032:	and    %al,%r11b
  826035:	cmp    $0x7f800000,%r9d
  82603c:	sete   %al
  82603f:	setg   %r9b
  826043:	or     %al,%r9b
  826046:	or     %r11b,%r9b
  826049:	or     %r10b,%r9b
  82604c:	jne    82609c <gpui_gpu::renderer::coverage::whole+0xbc>
  82604e:	shr    $0x20,%rsi
  826052:	test   %esi,%esi
  826054:	sets   %al
  826057:	and    $0x7fffffff,%esi
  82605d:	lea    -0x800000(%rsi),%r9d
  826064:	cmp    $0x7f000000,%r9d
  82606b:	setb   %r9b
  82606f:	and    %al,%r9b
  826072:	lea    -0x1(%rsi),%r10d
  826076:	cmp    $0x7fffff,%r10d
  82607d:	setb   %r10b
  826081:	and    %al,%r10b
  826084:	cmp    $0x7f800000,%esi
  82608a:	sete   %al
  82608d:	setg   %sil
  826091:	or     %al,%sil
  826094:	or     %r10b,%sil
  826097:	or     %r9b,%sil
  82609a:	je     8260b2 <gpui_gpu::renderer::coverage::whole+0xd2>
  82609c:	xor    %eax,%eax
  82609e:	and    $0x1,%al
  8260a0:	add    $0xc8,%rsp
  8260a7:	pop    %rbx
  8260a8:	pop    %r12
  8260aa:	pop    %r13
  8260ac:	pop    %r14
  8260ae:	pop    %r15
  8260b0:	pop    %rbp
  8260b1:	ret
  8260b2:	movss  0x88(%rdi),%xmm1
  8260ba:	movss  -0x7770a6(%rip),%xmm2        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8260c2:	movaps %xmm1,%xmm0
  8260c5:	subss  %xmm2,%xmm0
  8260c9:	cvttss2si %xmm0,%rax
  8260ce:	cvttss2si %xmm1,%rsi
  8260d3:	mov    %rsi,%r9
  8260d6:	sar    $0x3f,%r9
  8260da:	and    %rax,%r9
  8260dd:	or     %rsi,%r9
  8260e0:	xor    %eax,%eax
  8260e2:	xorps  %xmm0,%xmm0
  8260e5:	ucomiss %xmm0,%xmm1
  8260e8:	cmovb  %rax,%r9
  8260ec:	movss  0x8c(%rdi),%xmm4
  8260f4:	movss  -0x7770dc(%rip),%xmm3        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8260fc:	ucomiss %xmm3,%xmm1
  8260ff:	mov    $0xffffffffffffffff,%rbx
  826106:	cmova  %rbx,%r9
  82610a:	movaps %xmm4,%xmm1
  82610d:	subss  %xmm2,%xmm1
  826111:	cvttss2si %xmm1,%rsi
  826116:	cvttss2si %xmm4,%r11
  82611b:	mov    %r11,%r10
  82611e:	sar    $0x3f,%r10
  826122:	and    %rsi,%r10
  826125:	or     %r11,%r10
  826128:	ucomiss %xmm0,%xmm4
  82612b:	cmovb  %rax,%r10
  82612f:	ucomiss %xmm3,%xmm4
  826132:	movss  0x90(%rdi),%xmm1
  82613a:	cmova  %rbx,%r10
  82613e:	movaps %xmm1,%xmm4
  826141:	subss  %xmm2,%xmm4
  826145:	cvttss2si %xmm4,%r11
  82614a:	cvttss2si %xmm1,%r14
  82614f:	mov    %r14,%rsi
  826152:	sar    $0x3f,%rsi
  826156:	and    %r11,%rsi
  826159:	or     %r14,%rsi
  82615c:	ucomiss %xmm0,%xmm1
  82615f:	cmovb  %rax,%rsi
  826163:	ucomiss %xmm3,%xmm1
  826166:	cmova  %rbx,%rsi
  82616a:	add    %r9,%rsi
  82616d:	setb   %r11b
  826171:	sete   %bpl
  826175:	or     %r11b,%bpl
  826178:	jne    82609e <gpui_gpu::renderer::coverage::whole+0xbe>
  82617e:	movss  0x94(%rdi),%xmm2
  826186:	cvttss2si %xmm2,%rax
  82618b:	mov    %rax,%r11
  82618e:	movaps %xmm2,%xmm3
  826191:	subss  -0x77717d(%rip),%xmm3        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  826199:	sar    $0x3f,%r11
  82619d:	cvttss2si %xmm3,%r14
  8261a2:	and    %r11,%r14
  8261a5:	or     %rax,%r14
  8261a8:	xor    %eax,%eax
  8261aa:	ucomiss %xmm0,%xmm2
  8261ad:	mov    $0x0,%r11d
  8261b3:	cmovae %r14,%r11
  8261b7:	ucomiss -0x77719e(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8261be:	cmova  %rbx,%r11
  8261c2:	add    %r10,%r11
  8261c5:	setb   %bl
  8261c8:	sete   %bpl
  8261cc:	or     %bl,%bpl
  8261cf:	jne    82609e <gpui_gpu::renderer::coverage::whole+0xbe>
  8261d5:	xor    %eax,%eax
  8261d7:	test   %rdx,%rdx
  8261da:	je     82609e <gpui_gpu::renderer::coverage::whole+0xbe>
  8261e0:	movss  -0x777408(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  8261e8:	ucomiss %xmm1,%xmm0
  8261eb:	ja     82609e <gpui_gpu::renderer::coverage::whole+0xbe>
  8261f1:	ucomiss %xmm2,%xmm0
  8261f4:	ja     82609e <gpui_gpu::renderer::coverage::whole+0xbe>
  8261fa:	dec    %rsi
  8261fd:	dec    %r11
  826200:	shr    $0x4,%r10
  826204:	imul   %rdx,%r10
  826208:	shr    $0x4,%r9
  82620c:	add    %r10,%r9
  82620f:	mov    %r9,%rax
  826212:	mov    %rdx,%rbx
  826215:	or     %rdx,%rax
  826218:	shr    $0x20,%rax
  82621c:	je     82622e <gpui_gpu::renderer::coverage::whole+0x24e>
  82621e:	mov    %r9,%rax
  826221:	xor    %edx,%edx
  826223:	div    %rbx
  826226:	mov    %rdx,%r10
  826229:	mov    %rax,%r9
  82622c:	jmp    82623b <gpui_gpu::renderer::coverage::whole+0x25b>
  82622e:	mov    %r9d,%eax
  826231:	xor    %edx,%edx
  826233:	div    %ebx
  826235:	mov    %edx,%r10d
  826238:	mov    %eax,%r9d
  82623b:	shl    $0x4,%r10d
  82623f:	shr    $0x4,%r11
  826243:	imul   %rbx,%r11
  826247:	shr    $0x4,%rsi
  82624b:	add    %r11,%rsi
  82624e:	mov    %rsi,%rdx
  826251:	or     %rbx,%rdx
  826254:	shr    $0x20,%rdx
  826258:	je     826264 <gpui_gpu::renderer::coverage::whole+0x284>
  82625a:	mov    %rsi,%rax
  82625d:	xor    %edx,%edx
  82625f:	div    %rbx
  826262:	jmp    82626a <gpui_gpu::renderer::coverage::whole+0x28a>
  826264:	mov    %esi,%eax
  826266:	xor    %edx,%edx
  826268:	div    %ebx
  82626a:	shl    $0x4,%edx
  82626d:	shl    $0x4,%eax
  826270:	add    $0x10,%edx
  826273:	cmp    %edx,%ecx
  826275:	cmovb  %ecx,%edx
  826278:	add    $0x10,%eax
  82627b:	cmp    %eax,%r8d
  82627e:	cmovb  %r8d,%eax
  826282:	movss  0x78(%rdi),%xmm0
  826287:	cvtss2sd %xmm0,%xmm2
  82628b:	mov    %r10d,%ecx
  82628e:	xorps  %xmm0,%xmm0
  826291:	cvtsi2sd %rcx,%xmm0
  826296:	ucomisd %xmm0,%xmm2
  82629a:	ja     82609c <gpui_gpu::renderer::coverage::whole+0xbc>
  8262a0:	shl    $0x4,%r9d
  8262a4:	movss  0x7c(%rdi),%xmm1
  8262a9:	cvtss2sd %xmm1,%xmm3
  8262ad:	cvtsi2sd %r9,%xmm4
  8262b2:	ucomisd %xmm4,%xmm3
  8262b6:	ja     82609c <gpui_gpu::renderer::coverage::whole+0xbc>
  8262bc:	movss  0x80(%rdi),%xmm1
  8262c4:	cvtss2sd %xmm1,%xmm1
  8262c8:	addsd  %xmm1,%xmm2
  8262cc:	mov    %edx,%ecx
  8262ce:	xorps  %xmm1,%xmm1
  8262d1:	cvtsi2sd %rcx,%xmm1
  8262d6:	ucomisd %xmm2,%xmm1
  8262da:	ja     82609c <gpui_gpu::renderer::coverage::whole+0xbc>
  8262e0:	movss  0x84(%rdi),%xmm2
  8262e8:	cvtss2sd %xmm2,%xmm2
  8262ec:	addsd  %xmm3,%xmm2
  8262f0:	mov    %eax,%eax
  8262f2:	xorps  %xmm3,%xmm3
  8262f5:	cvtsi2sd %rax,%xmm3
  8262fa:	ucomisd %xmm2,%xmm3
  8262fe:	ja     82609c <gpui_gpu::renderer::coverage::whole+0xbc>
  826304:	movsd  %xmm3,(%rsp)
  826309:	movsd  %xmm4,0x8(%rsp)
  82630f:	mov    %rdi,%rbx
  826312:	addsd  -0x776ab2(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82631a:	addsd  -0x776d3a(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  826322:	lea    0x38(%rsp),%rdi
  826327:	call   825720 <<gpui_gpu::renderer::coverage::Interval>::checked>
  82632c:	cmpl   $0x1,0x38(%rsp)
  826331:	jne    82609c <gpui_gpu::renderer::coverage::whole+0xbc>
  826337:	movsd  0x40(%rsp),%xmm0
  82633d:	movsd  %xmm0,0x28(%rsp)
  826343:	movsd  0x48(%rsp),%xmm0
  826349:	movsd  %xmm0,0x20(%rsp)
  82634f:	movsd  0x8(%rsp),%xmm0
  826355:	addsd  -0x776af5(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82635d:	movsd  (%rsp),%xmm1
  826362:	addsd  -0x776d82(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82636a:	lea    0x38(%rsp),%rdi
  82636f:	call   825720 <<gpui_gpu::renderer::coverage::Interval>::checked>
  826374:	cmpb   $0x0,0x38(%rsp)
  826379:	je     82609c <gpui_gpu::renderer::coverage::whole+0xbc>
  82637f:	movsd  0x40(%rsp),%xmm0
  826385:	movsd  %xmm0,0x18(%rsp)
  82638b:	movsd  0x48(%rsp),%xmm0
  826391:	movsd  %xmm0,0x10(%rsp)
  826397:	mov    %rbx,%rcx
  82639a:	movss  0x38(%rbx),%xmm0
  82639f:	movss  0x3c(%rbx),%xmm1
  8263a4:	movss  0x40(%rbx),%xmm2
  8263a9:	movss  0x44(%rbx),%xmm3
  8263ae:	lea    0xa8(%rsp),%r14
  8263b6:	movq   $0x0,0xa8(%rsp)
  8263c2:	movss  %xmm0,0xb0(%rsp)
  8263cb:	movss  %xmm2,0xb4(%rsp)
  8263d4:	movq   $0x1,0xb8(%rsp)
  8263e0:	movss  %xmm1,0xc0(%rsp)
  8263e9:	movss  %xmm3,0xc4(%rsp)
  8263f2:	lea    0x48(%rsp),%r15
  8263f7:	xor    %r12d,%r12d
  8263fa:	movabs $0x3ec0000000000000,%r13
  826404:	movsd  -0x7765cd(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82640d:	xor    %edx,%edx
  82640f:	shl    $0x4,%rdx
  826413:	mov    (%r14,%rdx,1),%rdi
  826417:	cmp    $0x6,%rdi
  82641b:	jae    826559 <gpui_gpu::renderer::coverage::whole+0x579>
  826421:	cmp    $0x4,%rdi
  826425:	jae    82656b <gpui_gpu::renderer::coverage::whole+0x58b>
  82642b:	mov    %rdi,%rax
  82642e:	or     $0x4,%rax
  826432:	cmp    $0x6,%rax
  826436:	jae    826581 <gpui_gpu::renderer::coverage::whole+0x5a1>
  82643c:	movss  0x8(%r14,%rdx,1),%xmm0
  826443:	movss  0xc(%r14,%rdx,1),%xmm1
  82644a:	movsd  0x48(%rcx,%rdi,8),%xmm2
  826450:	movsd  0x48(%rcx,%rax,8),%xmm3
  826456:	xorps  %xmm4,%xmm4
  826459:	cvtsd2ss %xmm3,%xmm4
  82645d:	movsd  0x58(%rcx,%rdi,8),%xmm5
  826463:	cvtss2sd %xmm4,%xmm4
  826467:	movss  0x30(%rsp,%rdi,4),%xmm6
  82646d:	cvtss2sd %xmm6,%xmm6
  826471:	movq   $0x0,0x38(%rsp)
  82647a:	movq   $0x2,0x40(%rsp)
  826483:	movapd %xmm2,%xmm7
  826487:	unpcklpd %xmm5,%xmm7
  82648b:	cvtpd2ps %xmm7,%xmm7
  82648f:	cvtps2pd %xmm7,%xmm7
  826492:	movups %xmm7,0x48(%rsp)
  826497:	movsd  %xmm4,0x58(%rsp)
  82649d:	mov    %r13,0x60(%rsp)
  8264a2:	movsd  %xmm6,0x68(%rsp)
  8264a8:	movsd  %xmm2,0x70(%rsp)
  8264ae:	movsd  %xmm5,0x78(%rsp)
  8264b4:	movsd  %xmm3,0x80(%rsp)
  8264bd:	movups %xmm8,0x88(%rsp)
  8264c6:	cvtss2sd %xmm0,%xmm0
  8264ca:	movsd  %xmm0,0x8(%rsp)
  8264d0:	xorps  %xmm0,%xmm0
  8264d3:	cvtss2sd %xmm1,%xmm0
  8264d7:	movsd  %xmm0,(%rsp)
  8264dc:	xor    %ebp,%ebp
  8264de:	xor    %eax,%eax
  8264e0:	lea    (%rax,%rax,4),%rax
  8264e4:	lea    (%r15,%rax,8),%rdi
  8264e8:	movsd  0x18(%r15,%rax,8),%xmm6
  8264ef:	movsd  0x20(%r15,%rax,8),%xmm7
  8264f6:	movsd  0x28(%rsp),%xmm0
  8264fc:	movsd  0x20(%rsp),%xmm1
  826502:	movsd  0x18(%rsp),%xmm2
  826508:	movsd  0x10(%rsp),%xmm3
  82650e:	movsd  0x8(%rsp),%xmm4
  826514:	movsd  (%rsp),%xmm5
  826519:	call   825960 <gpui_gpu::renderer::coverage::axis>
  82651e:	cmp    $0x1,%al
  826520:	jne    82609e <gpui_gpu::renderer::coverage::whole+0xbe>
  826526:	mov    $0x1,%eax
  82652b:	test   $0x1,%bpl
  82652f:	mov    $0x1,%bpl
  826532:	je     8264e0 <gpui_gpu::renderer::coverage::whole+0x500>
  826534:	mov    $0x1,%edx
  826539:	test   $0x1,%r12b
  82653d:	mov    $0x1,%r12b
  826540:	mov    %rbx,%rcx
  826543:	movsd  -0x77670c(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82654c:	je     82640f <gpui_gpu::renderer::coverage::whole+0x42f>
  826552:	mov    $0x1,%al
  826554:	jmp    82609e <gpui_gpu::renderer::coverage::whole+0xbe>
  826559:	lea    0x6093d0(%rip),%rdx        # e2f930 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x18>
  826560:	mov    $0x6,%esi
  826565:	call   *0x65abed(%rip)        # e81158 <_DYNAMIC+0x4f8>
  82656b:	add    $0x2,%rdi
  82656f:	lea    0x6093d2(%rip),%rdx        # e2f948 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x30>
  826576:	mov    $0x6,%esi
  82657b:	call   *0x65abd7(%rip)        # e81158 <_DYNAMIC+0x4f8>
  826581:	lea    0x6093d8(%rip),%rdx        # e2f960 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x48>
  826588:	mov    $0x6,%esi
  82658d:	mov    %rax,%rdi
  826590:	call   *0x65abc2(%rip)        # e81158 <_DYNAMIC+0x4f8>
