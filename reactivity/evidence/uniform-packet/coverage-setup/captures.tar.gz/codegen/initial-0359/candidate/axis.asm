
FUNCTION gpui_gpu::renderer::coverage::axis bytes=1662 frame=344

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825990 <gpui_gpu::renderer::coverage::axis>:
  825990:	push   %r15
  825992:	push   %r14
  825994:	push   %r13
  825996:	push   %r12
  825998:	push   %rbx
  825999:	sub    $0x130,%rsp
  8259a0:	movq   %xmm4,%r12
  8259a5:	movabs $0x7fffffffffffffff,%rbx
  8259af:	and    %rbx,%r12
  8259b2:	mov    $0x2,%al
  8259b4:	movabs $0x7fefffffffffffff,%r14
  8259be:	cmp    %r14,%r12
  8259c1:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  8259c7:	movsd  (%rdi),%xmm11
  8259cc:	movsd  0x8(%rdi),%xmm8
  8259d2:	movsd  0x10(%rdi),%xmm9
  8259d8:	xorpd  %xmm10,%xmm10
  8259dd:	ucomisd %xmm10,%xmm4
  8259e2:	jne    8259e6 <gpui_gpu::renderer::coverage::axis+0x56>
  8259e4:	jnp    8259fe <gpui_gpu::renderer::coverage::axis+0x6e>
  8259e6:	lea    -0x1(%r12),%rcx
  8259eb:	movabs $0xfffffffffffff,%rdx
  8259f5:	cmp    %rdx,%rcx
  8259f8:	jb     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  8259fe:	movq   %xmm5,%r15
  825a03:	and    %rbx,%r15
  825a06:	cmp    %r14,%r15
  825a09:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825a0f:	ucomisd %xmm10,%xmm5
  825a14:	jne    825a18 <gpui_gpu::renderer::coverage::axis+0x88>
  825a16:	jnp    825a2f <gpui_gpu::renderer::coverage::axis+0x9f>
  825a18:	lea    -0x1(%r15),%rcx
  825a1c:	movabs $0xfffffffffffff,%rdx
  825a26:	cmp    %rdx,%rcx
  825a29:	jb     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825a2f:	movaps %xmm8,0xc0(%rsp)
  825a38:	movsd  %xmm2,0x60(%rsp)
  825a3e:	movsd  %xmm3,0x28(%rsp)
  825a44:	movaps %xmm9,0x80(%rsp)
  825a4d:	movaps %xmm4,0xb0(%rsp)
  825a55:	movsd  %xmm6,0xa8(%rsp)
  825a5e:	movsd  %xmm7,0x30(%rsp)
  825a64:	movaps %xmm5,0x90(%rsp)
  825a6c:	mov    %rsp,%rdi
  825a6f:	movsd  %xmm0,0x38(%rsp)
  825a75:	movsd  %xmm1,0x40(%rsp)
  825a7b:	movapd %xmm11,0x120(%rsp)
  825a85:	movapd %xmm11,%xmm2
  825a8a:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825a8f:	cmpl   $0x1,(%rsp)
  825a93:	jne    825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825a99:	movsd  0x8(%rsp),%xmm0
  825a9f:	movsd  %xmm0,0x20(%rsp)
  825aa5:	movsd  0x10(%rsp),%xmm0
  825aab:	movsd  %xmm0,0x18(%rsp)
  825ab1:	mov    %rsp,%rdi
  825ab4:	movsd  0x60(%rsp),%xmm0
  825aba:	movsd  0x28(%rsp),%xmm1
  825ac0:	movapd 0xc0(%rsp),%xmm2
  825ac9:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825ace:	cmpb   $0x0,(%rsp)
  825ad2:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825ad8:	movsd  0x8(%rsp),%xmm5
  825ade:	movsd  0x10(%rsp),%xmm4
  825ae4:	xorpd  %xmm2,%xmm2
  825ae8:	ucomisd %xmm2,%xmm5
  825aec:	mov    $0x2,%al
  825aee:	jne    825b11 <gpui_gpu::renderer::coverage::axis+0x181>
  825af0:	jp     825b11 <gpui_gpu::renderer::coverage::axis+0x181>
  825af2:	ucomisd %xmm2,%xmm4
  825af6:	jne    825b11 <gpui_gpu::renderer::coverage::axis+0x181>
  825af8:	jp     825b11 <gpui_gpu::renderer::coverage::axis+0x181>
  825afa:	movdqa 0x80(%rsp),%xmm2
  825b03:	movsd  0x18(%rsp),%xmm1
  825b09:	movsd  0x20(%rsp),%xmm0
  825b0f:	jmp    825b52 <gpui_gpu::renderer::coverage::axis+0x1c2>
  825b11:	movsd  0x20(%rsp),%xmm0
  825b17:	ucomisd %xmm2,%xmm0
  825b1b:	movdqa 0x80(%rsp),%xmm2
  825b24:	movsd  0x18(%rsp),%xmm1
  825b2a:	jne    825ee1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b30:	jp     825ee1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b36:	xorpd  %xmm3,%xmm3
  825b3a:	ucomisd %xmm3,%xmm1
  825b3e:	jne    825ee1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b44:	jp     825ee1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b4a:	movapd %xmm4,%xmm1
  825b4e:	movapd %xmm5,%xmm0
  825b52:	movq   %xmm2,%r13
  825b57:	and    %rbx,%r13
  825b5a:	cmp    %r14,%r13
  825b5d:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825b63:	xorpd  %xmm3,%xmm3
  825b67:	ucomisd %xmm3,%xmm2
  825b6b:	jne    825b6f <gpui_gpu::renderer::coverage::axis+0x1df>
  825b6d:	jnp    825b86 <gpui_gpu::renderer::coverage::axis+0x1f6>
  825b6f:	lea    -0x1(%r13),%rcx
  825b73:	movabs $0xfffffffffffff,%rdx
  825b7d:	cmp    %rdx,%rcx
  825b80:	jb     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825b86:	lea    0x48(%rsp),%rdi
  825b8b:	movapd 0x80(%rsp),%xmm3
  825b94:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825b99:	movapd 0xb0(%rsp),%xmm2
  825ba2:	mov    $0x2,%al
  825ba4:	cmpb   $0x0,0x48(%rsp)
  825ba9:	je     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825baf:	movsd  0x50(%rsp),%xmm0
  825bb5:	movsd  0x58(%rsp),%xmm1
  825bbb:	lea    0x68(%rsp),%rdi
  825bc0:	movapd %xmm2,%xmm3
  825bc4:	call   825810 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825bc9:	cmpl   $0x1,0x68(%rsp)
  825bce:	jne    825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825bd4:	movsd  0x70(%rsp),%xmm0
  825bda:	movsd  %xmm0,0x18(%rsp)
  825be0:	movsd  0x78(%rsp),%xmm0
  825be6:	movsd  %xmm0,0x20(%rsp)
  825bec:	movapd 0x120(%rsp),%xmm2
  825bf5:	andpd  -0x77adcd(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825bfd:	mov    %rsp,%rdi
  825c00:	movsd  0x38(%rsp),%xmm0
  825c06:	movsd  0x40(%rsp),%xmm1
  825c0c:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825c11:	cmpb   $0x0,(%rsp)
  825c15:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825c1b:	movsd  0x8(%rsp),%xmm0
  825c21:	movsd  %xmm0,0x40(%rsp)
  825c27:	movsd  0x10(%rsp),%xmm0
  825c2d:	movsd  %xmm0,0x38(%rsp)
  825c33:	movapd 0xc0(%rsp),%xmm2
  825c3c:	andpd  -0x77ae14(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825c44:	mov    %rsp,%rdi
  825c47:	movsd  0x60(%rsp),%xmm0
  825c4d:	movsd  0x28(%rsp),%xmm1
  825c53:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825c58:	cmpb   $0x0,(%rsp)
  825c5c:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825c62:	movsd  0x8(%rsp),%xmm2
  825c68:	movsd  0x10(%rsp),%xmm3
  825c6e:	lea    0x48(%rsp),%rdi
  825c73:	movsd  0x40(%rsp),%xmm0
  825c79:	movsd  0x38(%rsp),%xmm1
  825c7f:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825c84:	cmpb   $0x0,0x48(%rsp)
  825c89:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825c8f:	xorpd  %xmm0,%xmm0
  825c93:	movapd 0x80(%rsp),%xmm2
  825c9c:	ucomisd %xmm0,%xmm2
  825ca0:	movsd  0x50(%rsp),%xmm0
  825ca6:	movsd  0x58(%rsp),%xmm1
  825cac:	jne    825cb0 <gpui_gpu::renderer::coverage::axis+0x320>
  825cae:	jnp    825cc6 <gpui_gpu::renderer::coverage::axis+0x336>
  825cb0:	dec    %r13
  825cb3:	movabs $0xfffffffffffff,%rax
  825cbd:	cmp    %rax,%r13
  825cc0:	jb     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825cc6:	andpd  -0x77ae9e(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825cce:	lea    0x68(%rsp),%rdi
  825cd3:	movapd %xmm2,%xmm3
  825cd7:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825cdc:	cmpb   $0x0,0x68(%rsp)
  825ce1:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825ce7:	xorpd  %xmm0,%xmm0
  825ceb:	movapd 0xb0(%rsp),%xmm2
  825cf4:	ucomisd %xmm0,%xmm2
  825cf8:	movsd  0x70(%rsp),%xmm0
  825cfe:	movsd  0x78(%rsp),%xmm1
  825d04:	jne    825d08 <gpui_gpu::renderer::coverage::axis+0x378>
  825d06:	jnp    825d1e <gpui_gpu::renderer::coverage::axis+0x38e>
  825d08:	dec    %r12
  825d0b:	movabs $0xfffffffffffff,%rax
  825d15:	cmp    %rax,%r12
  825d18:	jb     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825d1e:	andpd  -0x77aef6(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825d26:	lea    0x108(%rsp),%rdi
  825d2e:	movapd %xmm2,%xmm3
  825d32:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825d37:	cmpb   $0x0,0x108(%rsp)
  825d3f:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825d45:	xorpd  %xmm0,%xmm0
  825d49:	movapd 0x90(%rsp),%xmm1
  825d52:	ucomisd %xmm0,%xmm1
  825d56:	movsd  0x110(%rsp),%xmm0
  825d5f:	movsd  0x118(%rsp),%xmm1
  825d68:	jne    825d6c <gpui_gpu::renderer::coverage::axis+0x3dc>
  825d6a:	jnp    825d82 <gpui_gpu::renderer::coverage::axis+0x3f2>
  825d6c:	dec    %r15
  825d6f:	movabs $0xfffffffffffff,%rax
  825d79:	cmp    %rax,%r15
  825d7c:	jb     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825d82:	movapd -0x77af5a(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825d8a:	andpd  0x90(%rsp),%xmm2
  825d93:	lea    0xf0(%rsp),%rdi
  825d9b:	movapd %xmm2,%xmm3
  825d9f:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825da4:	cmpb   $0x0,0xf0(%rsp)
  825dac:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825db2:	movsd  0xf8(%rsp),%xmm0
  825dbb:	movsd  0x100(%rsp),%xmm1
  825dc4:	lea    0xd8(%rsp),%rdi
  825dcc:	movsd  -0x7764f4(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  825dd4:	movapd %xmm2,%xmm3
  825dd8:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825ddd:	cmpl   $0x1,0xd8(%rsp)
  825de5:	jne    825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825deb:	movsd  0xe0(%rsp),%xmm0
  825df4:	movsd  0xe8(%rsp),%xmm1
  825dfd:	mov    %rsp,%rdi
  825e00:	movsd  0xa8(%rsp),%xmm2
  825e09:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825e0e:	cmpb   $0x0,(%rsp)
  825e12:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825e18:	movq   0x30(%rsp),%xmm0
  825e1e:	movq   %xmm0,%rax
  825e23:	and    %rbx,%rax
  825e26:	cmp    %r14,%rax
  825e29:	jg     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825e2f:	movsd  0x8(%rsp),%xmm0
  825e35:	movsd  0x10(%rsp),%xmm1
  825e3b:	xorpd  %xmm2,%xmm2
  825e3f:	movsd  0x30(%rsp),%xmm3
  825e45:	ucomisd %xmm2,%xmm3
  825e49:	jne    825e4d <gpui_gpu::renderer::coverage::axis+0x4bd>
  825e4b:	jnp    825e5f <gpui_gpu::renderer::coverage::axis+0x4cf>
  825e4d:	dec    %rax
  825e50:	movabs $0xfffffffffffff,%rcx
  825e5a:	cmp    %rcx,%rax
  825e5d:	jb     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825e5f:	lea    0x48(%rsp),%rdi
  825e64:	movsd  0x30(%rsp),%xmm2
  825e6a:	movapd %xmm2,%xmm3
  825e6e:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825e73:	cmpb   $0x0,0x48(%rsp)
  825e78:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825e7a:	movsd  0x58(%rsp),%xmm1
  825e80:	movsd  0x18(%rsp),%xmm0
  825e86:	movsd  %xmm1,0x28(%rsp)
  825e8c:	ucomisd %xmm1,%xmm0
  825e90:	jbe    826007 <gpui_gpu::renderer::coverage::axis+0x677>
  825e96:	mov    %rsp,%rdi
  825e99:	movapd 0x90(%rsp),%xmm0
  825ea2:	movapd %xmm0,%xmm1
  825ea6:	movsd  0x18(%rsp),%xmm2
  825eac:	movsd  0x20(%rsp),%xmm3
  825eb2:	call   825810 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825eb7:	cmpl   $0x1,(%rsp)
  825ebb:	jne    825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825ebd:	movsd  0x8(%rsp),%xmm0
  825ec3:	ucomisd 0x28(%rsp),%xmm0
  825ec9:	seta   %al
  825ecc:	jmp    825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825ece:	mov    $0x2,%al
  825ed0:	add    $0x130,%rsp
  825ed7:	pop    %rbx
  825ed8:	pop    %r12
  825eda:	pop    %r13
  825edc:	pop    %r14
  825ede:	pop    %r15
  825ee0:	ret
  825ee1:	addsd  %xmm5,%xmm0
  825ee5:	addsd  %xmm4,%xmm1
  825ee9:	movq   %xmm0,%rdx
  825eee:	movq   %xmm1,%rcx
  825ef3:	ucomisd %xmm0,%xmm0
  825ef7:	setp   %sil
  825efb:	movabs $0xfff0000000000000,%rdi
  825f05:	cmp    %rdi,%rdx
  825f08:	sete   %dil
  825f0c:	or     %sil,%dil
  825f0f:	jne    825f37 <gpui_gpu::renderer::coverage::axis+0x5a7>
  825f11:	mov    %rdx,%rsi
  825f14:	and    %rbx,%rsi
  825f17:	je     825f23 <gpui_gpu::renderer::coverage::axis+0x593>
  825f19:	cmp    %rsi,%rdx
  825f1c:	jne    825f2f <gpui_gpu::renderer::coverage::axis+0x59f>
  825f1e:	dec    %rdx
  825f21:	jmp    825f32 <gpui_gpu::renderer::coverage::axis+0x5a2>
  825f23:	movabs $0x8000000000000001,%rdx
  825f2d:	jmp    825f32 <gpui_gpu::renderer::coverage::axis+0x5a2>
  825f2f:	inc    %rdx
  825f32:	movq   %rdx,%xmm0
  825f37:	ucomisd %xmm1,%xmm1
  825f3b:	setp   %dl
  825f3e:	movabs $0x7ff0000000000000,%rsi
  825f48:	cmp    %rsi,%rcx
  825f4b:	sete   %sil
  825f4f:	or     %dl,%sil
  825f52:	jne    825f75 <gpui_gpu::renderer::coverage::axis+0x5e5>
  825f54:	mov    %rcx,%rdx
  825f57:	and    %rbx,%rdx
  825f5a:	je     825f66 <gpui_gpu::renderer::coverage::axis+0x5d6>
  825f5c:	cmp    %rdx,%rcx
  825f5f:	jne    825f6d <gpui_gpu::renderer::coverage::axis+0x5dd>
  825f61:	inc    %rcx
  825f64:	jmp    825f70 <gpui_gpu::renderer::coverage::axis+0x5e0>
  825f66:	mov    $0x1,%ecx
  825f6b:	jmp    825f70 <gpui_gpu::renderer::coverage::axis+0x5e0>
  825f6d:	dec    %rcx
  825f70:	movq   %rcx,%xmm1
  825f75:	movq   %xmm0,%rdx
  825f7a:	and    %rbx,%rdx
  825f7d:	cmp    %r14,%rdx
  825f80:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825f86:	ucomisd %xmm1,%xmm0
  825f8a:	ja     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825f90:	xorpd  %xmm3,%xmm3
  825f94:	ucomisd %xmm3,%xmm0
  825f98:	movq   %xmm1,%rcx
  825f9d:	jne    825fa1 <gpui_gpu::renderer::coverage::axis+0x611>
  825f9f:	jnp    825fce <gpui_gpu::renderer::coverage::axis+0x63e>
  825fa1:	dec    %rdx
  825fa4:	mov    %rcx,%rsi
  825fa7:	and    %rbx,%rsi
  825faa:	cmp    %r14,%rsi
  825fad:	setg   %sil
  825fb1:	movabs $0xfffffffffffff,%rdi
  825fbb:	cmp    %rdi,%rdx
  825fbe:	jb     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825fc4:	test   %sil,%sil
  825fc7:	je     825fdd <gpui_gpu::renderer::coverage::axis+0x64d>
  825fc9:	jmp    825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825fce:	mov    %rcx,%rdx
  825fd1:	and    %rbx,%rdx
  825fd4:	cmp    %r14,%rdx
  825fd7:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825fdd:	ucomisd %xmm3,%xmm1
  825fe1:	jne    825fe9 <gpui_gpu::renderer::coverage::axis+0x659>
  825fe3:	jnp    825b52 <gpui_gpu::renderer::coverage::axis+0x1c2>
  825fe9:	and    %rbx,%rcx
  825fec:	dec    %rcx
  825fef:	movabs $0xfffffffffffff,%rdx
  825ff9:	cmp    %rdx,%rcx
  825ffc:	jae    825b52 <gpui_gpu::renderer::coverage::axis+0x1c2>
  826002:	jmp    825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  826007:	xor    %eax,%eax
  826009:	jmp    825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
