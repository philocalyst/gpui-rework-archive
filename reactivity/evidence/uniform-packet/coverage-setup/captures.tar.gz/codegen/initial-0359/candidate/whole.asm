
FUNCTION gpui_gpu::renderer::coverage::whole bytes=1462 frame=248

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826010 <gpui_gpu::renderer::coverage::whole>:
  826010:	push   %rbp
  826011:	push   %r15
  826013:	push   %r14
  826015:	push   %r13
  826017:	push   %r12
  826019:	push   %rbx
  82601a:	sub    $0xc8,%rsp
  826021:	mov    %rsi,0x30(%rsp)
  826026:	cmpb   $0x0,(%rdi)
  826029:	jne    8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  82602f:	test   %esi,%esi
  826031:	sets   %al
  826034:	mov    %esi,%r9d
  826037:	and    $0x7fffffff,%r9d
  82603e:	lea    -0x800000(%r9),%r10d
  826045:	cmp    $0x7f000000,%r10d
  82604c:	setb   %r10b
  826050:	and    %al,%r10b
  826053:	lea    -0x1(%r9),%r11d
  826057:	cmp    $0x7fffff,%r11d
  82605e:	setb   %r11b
  826062:	and    %al,%r11b
  826065:	cmp    $0x7f800000,%r9d
  82606c:	sete   %al
  82606f:	setg   %r9b
  826073:	or     %al,%r9b
  826076:	or     %r11b,%r9b
  826079:	or     %r10b,%r9b
  82607c:	jne    8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  82607e:	shr    $0x20,%rsi
  826082:	test   %esi,%esi
  826084:	sets   %al
  826087:	and    $0x7fffffff,%esi
  82608d:	lea    -0x800000(%rsi),%r9d
  826094:	cmp    $0x7f000000,%r9d
  82609b:	setb   %r9b
  82609f:	and    %al,%r9b
  8260a2:	lea    -0x1(%rsi),%r10d
  8260a6:	cmp    $0x7fffff,%r10d
  8260ad:	setb   %r10b
  8260b1:	and    %al,%r10b
  8260b4:	cmp    $0x7f800000,%esi
  8260ba:	sete   %al
  8260bd:	setg   %sil
  8260c1:	or     %al,%sil
  8260c4:	or     %r10b,%sil
  8260c7:	or     %r9b,%sil
  8260ca:	je     8260e2 <gpui_gpu::renderer::coverage::whole+0xd2>
  8260cc:	xor    %eax,%eax
  8260ce:	and    $0x1,%al
  8260d0:	add    $0xc8,%rsp
  8260d7:	pop    %rbx
  8260d8:	pop    %r12
  8260da:	pop    %r13
  8260dc:	pop    %r14
  8260de:	pop    %r15
  8260e0:	pop    %rbp
  8260e1:	ret
  8260e2:	movss  0x88(%rdi),%xmm1
  8260ea:	movss  -0x7770d6(%rip),%xmm2        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8260f2:	movaps %xmm1,%xmm0
  8260f5:	subss  %xmm2,%xmm0
  8260f9:	cvttss2si %xmm0,%rax
  8260fe:	cvttss2si %xmm1,%rsi
  826103:	mov    %rsi,%r9
  826106:	sar    $0x3f,%r9
  82610a:	and    %rax,%r9
  82610d:	or     %rsi,%r9
  826110:	xor    %eax,%eax
  826112:	xorps  %xmm0,%xmm0
  826115:	ucomiss %xmm0,%xmm1
  826118:	cmovb  %rax,%r9
  82611c:	movss  0x8c(%rdi),%xmm4
  826124:	movss  -0x77710c(%rip),%xmm3        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82612c:	ucomiss %xmm3,%xmm1
  82612f:	mov    $0xffffffffffffffff,%rbx
  826136:	cmova  %rbx,%r9
  82613a:	movaps %xmm4,%xmm1
  82613d:	subss  %xmm2,%xmm1
  826141:	cvttss2si %xmm1,%rsi
  826146:	cvttss2si %xmm4,%r11
  82614b:	mov    %r11,%r10
  82614e:	sar    $0x3f,%r10
  826152:	and    %rsi,%r10
  826155:	or     %r11,%r10
  826158:	ucomiss %xmm0,%xmm4
  82615b:	cmovb  %rax,%r10
  82615f:	ucomiss %xmm3,%xmm4
  826162:	movss  0x90(%rdi),%xmm1
  82616a:	cmova  %rbx,%r10
  82616e:	movaps %xmm1,%xmm4
  826171:	subss  %xmm2,%xmm4
  826175:	cvttss2si %xmm4,%r11
  82617a:	cvttss2si %xmm1,%r14
  82617f:	mov    %r14,%rsi
  826182:	sar    $0x3f,%rsi
  826186:	and    %r11,%rsi
  826189:	or     %r14,%rsi
  82618c:	ucomiss %xmm0,%xmm1
  82618f:	cmovb  %rax,%rsi
  826193:	ucomiss %xmm3,%xmm1
  826196:	cmova  %rbx,%rsi
  82619a:	add    %r9,%rsi
  82619d:	setb   %r11b
  8261a1:	sete   %bpl
  8261a5:	or     %r11b,%bpl
  8261a8:	jne    8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  8261ae:	movss  0x94(%rdi),%xmm2
  8261b6:	cvttss2si %xmm2,%rax
  8261bb:	mov    %rax,%r11
  8261be:	movaps %xmm2,%xmm3
  8261c1:	subss  -0x7771ad(%rip),%xmm3        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8261c9:	sar    $0x3f,%r11
  8261cd:	cvttss2si %xmm3,%r14
  8261d2:	and    %r11,%r14
  8261d5:	or     %rax,%r14
  8261d8:	xor    %eax,%eax
  8261da:	ucomiss %xmm0,%xmm2
  8261dd:	mov    $0x0,%r11d
  8261e3:	cmovae %r14,%r11
  8261e7:	ucomiss -0x7771ce(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8261ee:	cmova  %rbx,%r11
  8261f2:	add    %r10,%r11
  8261f5:	setb   %bl
  8261f8:	sete   %bpl
  8261fc:	or     %bl,%bpl
  8261ff:	jne    8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826205:	xor    %eax,%eax
  826207:	test   %rdx,%rdx
  82620a:	je     8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826210:	movss  -0x777438(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  826218:	ucomiss %xmm1,%xmm0
  82621b:	ja     8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826221:	ucomiss %xmm2,%xmm0
  826224:	ja     8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  82622a:	dec    %rsi
  82622d:	dec    %r11
  826230:	shr    $0x4,%r10
  826234:	imul   %rdx,%r10
  826238:	shr    $0x4,%r9
  82623c:	add    %r10,%r9
  82623f:	mov    %r9,%rax
  826242:	mov    %rdx,%rbx
  826245:	or     %rdx,%rax
  826248:	shr    $0x20,%rax
  82624c:	je     82625e <gpui_gpu::renderer::coverage::whole+0x24e>
  82624e:	mov    %r9,%rax
  826251:	xor    %edx,%edx
  826253:	div    %rbx
  826256:	mov    %rdx,%r10
  826259:	mov    %rax,%r9
  82625c:	jmp    82626b <gpui_gpu::renderer::coverage::whole+0x25b>
  82625e:	mov    %r9d,%eax
  826261:	xor    %edx,%edx
  826263:	div    %ebx
  826265:	mov    %edx,%r10d
  826268:	mov    %eax,%r9d
  82626b:	shl    $0x4,%r10d
  82626f:	shr    $0x4,%r11
  826273:	imul   %rbx,%r11
  826277:	shr    $0x4,%rsi
  82627b:	add    %r11,%rsi
  82627e:	mov    %rsi,%rdx
  826281:	or     %rbx,%rdx
  826284:	shr    $0x20,%rdx
  826288:	je     826294 <gpui_gpu::renderer::coverage::whole+0x284>
  82628a:	mov    %rsi,%rax
  82628d:	xor    %edx,%edx
  82628f:	div    %rbx
  826292:	jmp    82629a <gpui_gpu::renderer::coverage::whole+0x28a>
  826294:	mov    %esi,%eax
  826296:	xor    %edx,%edx
  826298:	div    %ebx
  82629a:	shl    $0x4,%edx
  82629d:	shl    $0x4,%eax
  8262a0:	add    $0x10,%edx
  8262a3:	cmp    %edx,%ecx
  8262a5:	cmovb  %ecx,%edx
  8262a8:	add    $0x10,%eax
  8262ab:	cmp    %eax,%r8d
  8262ae:	cmovb  %r8d,%eax
  8262b2:	movss  0x78(%rdi),%xmm0
  8262b7:	cvtss2sd %xmm0,%xmm2
  8262bb:	mov    %r10d,%ecx
  8262be:	xorps  %xmm0,%xmm0
  8262c1:	cvtsi2sd %rcx,%xmm0
  8262c6:	ucomisd %xmm0,%xmm2
  8262ca:	ja     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8262d0:	shl    $0x4,%r9d
  8262d4:	movss  0x7c(%rdi),%xmm1
  8262d9:	cvtss2sd %xmm1,%xmm3
  8262dd:	cvtsi2sd %r9,%xmm4
  8262e2:	ucomisd %xmm4,%xmm3
  8262e6:	ja     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8262ec:	movss  0x80(%rdi),%xmm1
  8262f4:	cvtss2sd %xmm1,%xmm1
  8262f8:	addsd  %xmm1,%xmm2
  8262fc:	mov    %edx,%ecx
  8262fe:	xorps  %xmm1,%xmm1
  826301:	cvtsi2sd %rcx,%xmm1
  826306:	ucomisd %xmm2,%xmm1
  82630a:	ja     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826310:	movss  0x84(%rdi),%xmm2
  826318:	cvtss2sd %xmm2,%xmm2
  82631c:	addsd  %xmm3,%xmm2
  826320:	mov    %eax,%eax
  826322:	xorps  %xmm3,%xmm3
  826325:	cvtsi2sd %rax,%xmm3
  82632a:	ucomisd %xmm2,%xmm3
  82632e:	ja     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826334:	movsd  %xmm3,(%rsp)
  826339:	movsd  %xmm4,0x8(%rsp)
  82633f:	mov    %rdi,%rbx
  826342:	addsd  -0x776ae2(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82634a:	addsd  -0x776d6a(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  826352:	lea    0x38(%rsp),%rdi
  826357:	call   825750 <<gpui_gpu::renderer::coverage::Interval>::checked>
  82635c:	cmpl   $0x1,0x38(%rsp)
  826361:	jne    8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826367:	movsd  0x40(%rsp),%xmm0
  82636d:	movsd  %xmm0,0x28(%rsp)
  826373:	movsd  0x48(%rsp),%xmm0
  826379:	movsd  %xmm0,0x20(%rsp)
  82637f:	movsd  0x8(%rsp),%xmm0
  826385:	addsd  -0x776b25(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82638d:	movsd  (%rsp),%xmm1
  826392:	addsd  -0x776db2(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82639a:	lea    0x38(%rsp),%rdi
  82639f:	call   825750 <<gpui_gpu::renderer::coverage::Interval>::checked>
  8263a4:	cmpb   $0x0,0x38(%rsp)
  8263a9:	je     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8263af:	movsd  0x40(%rsp),%xmm0
  8263b5:	movsd  %xmm0,0x18(%rsp)
  8263bb:	movsd  0x48(%rsp),%xmm0
  8263c1:	movsd  %xmm0,0x10(%rsp)
  8263c7:	mov    %rbx,%rcx
  8263ca:	movss  0x38(%rbx),%xmm0
  8263cf:	movss  0x3c(%rbx),%xmm1
  8263d4:	movss  0x40(%rbx),%xmm2
  8263d9:	movss  0x44(%rbx),%xmm3
  8263de:	lea    0xa8(%rsp),%r14
  8263e6:	movq   $0x0,0xa8(%rsp)
  8263f2:	movss  %xmm0,0xb0(%rsp)
  8263fb:	movss  %xmm2,0xb4(%rsp)
  826404:	movq   $0x1,0xb8(%rsp)
  826410:	movss  %xmm1,0xc0(%rsp)
  826419:	movss  %xmm3,0xc4(%rsp)
  826422:	lea    0x48(%rsp),%r15
  826427:	xor    %r12d,%r12d
  82642a:	movabs $0x3ec0000000000000,%r13
  826434:	movsd  -0x7765fd(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82643d:	xor    %edx,%edx
  82643f:	shl    $0x4,%rdx
  826443:	mov    (%r14,%rdx,1),%rdi
  826447:	cmp    $0x6,%rdi
  82644b:	jae    826589 <gpui_gpu::renderer::coverage::whole+0x579>
  826451:	cmp    $0x4,%rdi
  826455:	jae    82659b <gpui_gpu::renderer::coverage::whole+0x58b>
  82645b:	mov    %rdi,%rax
  82645e:	or     $0x4,%rax
  826462:	cmp    $0x6,%rax
  826466:	jae    8265b1 <gpui_gpu::renderer::coverage::whole+0x5a1>
  82646c:	movss  0x8(%r14,%rdx,1),%xmm0
  826473:	movss  0xc(%r14,%rdx,1),%xmm1
  82647a:	movsd  0x48(%rcx,%rdi,8),%xmm2
  826480:	movsd  0x48(%rcx,%rax,8),%xmm3
  826486:	xorps  %xmm4,%xmm4
  826489:	cvtsd2ss %xmm3,%xmm4
  82648d:	movsd  0x58(%rcx,%rdi,8),%xmm5
  826493:	cvtss2sd %xmm4,%xmm4
  826497:	movss  0x30(%rsp,%rdi,4),%xmm6
  82649d:	cvtss2sd %xmm6,%xmm6
  8264a1:	movq   $0x0,0x38(%rsp)
  8264aa:	movq   $0x2,0x40(%rsp)
  8264b3:	movapd %xmm2,%xmm7
  8264b7:	unpcklpd %xmm5,%xmm7
  8264bb:	cvtpd2ps %xmm7,%xmm7
  8264bf:	cvtps2pd %xmm7,%xmm7
  8264c2:	movups %xmm7,0x48(%rsp)
  8264c7:	movsd  %xmm4,0x58(%rsp)
  8264cd:	mov    %r13,0x60(%rsp)
  8264d2:	movsd  %xmm6,0x68(%rsp)
  8264d8:	movsd  %xmm2,0x70(%rsp)
  8264de:	movsd  %xmm5,0x78(%rsp)
  8264e4:	movsd  %xmm3,0x80(%rsp)
  8264ed:	movups %xmm8,0x88(%rsp)
  8264f6:	cvtss2sd %xmm0,%xmm0
  8264fa:	movsd  %xmm0,0x8(%rsp)
  826500:	xorps  %xmm0,%xmm0
  826503:	cvtss2sd %xmm1,%xmm0
  826507:	movsd  %xmm0,(%rsp)
  82650c:	xor    %ebp,%ebp
  82650e:	xor    %eax,%eax
  826510:	lea    (%rax,%rax,4),%rax
  826514:	lea    (%r15,%rax,8),%rdi
  826518:	movsd  0x18(%r15,%rax,8),%xmm6
  82651f:	movsd  0x20(%r15,%rax,8),%xmm7
  826526:	movsd  0x28(%rsp),%xmm0
  82652c:	movsd  0x20(%rsp),%xmm1
  826532:	movsd  0x18(%rsp),%xmm2
  826538:	movsd  0x10(%rsp),%xmm3
  82653e:	movsd  0x8(%rsp),%xmm4
  826544:	movsd  (%rsp),%xmm5
  826549:	call   825990 <gpui_gpu::renderer::coverage::axis>
  82654e:	cmp    $0x1,%al
  826550:	jne    8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826556:	mov    $0x1,%eax
  82655b:	test   $0x1,%bpl
  82655f:	mov    $0x1,%bpl
  826562:	je     826510 <gpui_gpu::renderer::coverage::whole+0x500>
  826564:	mov    $0x1,%edx
  826569:	test   $0x1,%r12b
  82656d:	mov    $0x1,%r12b
  826570:	mov    %rbx,%rcx
  826573:	movsd  -0x77673c(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82657c:	je     82643f <gpui_gpu::renderer::coverage::whole+0x42f>
  826582:	mov    $0x1,%al
  826584:	jmp    8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826589:	lea    0x6093d0(%rip),%rdx        # e2f960 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x18>
  826590:	mov    $0x6,%esi
  826595:	call   *0x65abed(%rip)        # e81188 <_DYNAMIC+0x4f8>
  82659b:	add    $0x2,%rdi
  82659f:	lea    0x6093d2(%rip),%rdx        # e2f978 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x30>
  8265a6:	mov    $0x6,%esi
  8265ab:	call   *0x65abd7(%rip)        # e81188 <_DYNAMIC+0x4f8>
  8265b1:	lea    0x6093d8(%rip),%rdx        # e2f990 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x48>
  8265b8:	mov    $0x6,%esi
  8265bd:	mov    %rax,%rdi
  8265c0:	call   *0x65abc2(%rip)        # e81188 <_DYNAMIC+0x4f8>
