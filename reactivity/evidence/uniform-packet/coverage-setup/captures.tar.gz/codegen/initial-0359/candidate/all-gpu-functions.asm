
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816480 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  816480:	push   %rbx
  816481:	test   %rdi,%rdi
  816484:	je     8164e7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  816486:	mov    %rdi,%rbx
  816489:	mov    (%rdi),%rsi
  81648c:	test   %rsi,%rsi
  81648f:	je     8164a4 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816491:	mov    0x8(%rbx),%rdi
  816495:	shl    $0x3,%rsi
  816499:	mov    $0x8,%edx
  81649e:	call   *0x66aa34(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8164a4:	mov    0x20(%rbx),%rsi
  8164a8:	test   %rsi,%rsi
  8164ab:	je     8164d3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8164ad:	mov    %rsi,%rax
  8164b0:	shl    $0x4,%rax
  8164b4:	add    %rax,%rsi
  8164b7:	add    $0x21,%rsi
  8164bb:	je     8164d3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8164bd:	mov    0x18(%rbx),%rdi
  8164c1:	sub    %rax,%rdi
  8164c4:	add    $0xfffffffffffffff0,%rdi
  8164c8:	mov    $0x10,%edx
  8164cd:	call   *0x66aa05(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8164d3:	mov    $0x80,%esi
  8164d8:	mov    $0x8,%edx
  8164dd:	mov    %rbx,%rdi
  8164e0:	pop    %rbx
  8164e1:	jmp    *0x66a9f1(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8164e7:	pop    %rbx
  8164e8:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816af0 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816af0:	push   %rbx
  816af1:	cmpb   $0x3,0x19c(%rdi)
  816af8:	jne    816b27 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816afa:	movzbl 0x28(%rdi),%eax
  816afe:	cmp    $0x4,%eax
  816b01:	je     816b15 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816b03:	cmp    $0x3,%eax
  816b06:	jne    816b27 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816b08:	add    $0x168,%rdi
  816b0f:	pop    %rbx
  816b10:	jmp    816a60 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816b15:	mov    %rdi,%rbx
  816b18:	add    $0x30,%rdi
  816b1c:	call   816b40 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816b21:	movw   $0x0,0x29(%rbx)
  816b27:	pop    %rbx
  816b28:	ret
  816b29:	movw   $0x0,0x29(%rbx)
  816b2f:	mov    %rax,%rdi
  816b32:	call   e2d9a0 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816b40 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816b40:	push   %r15
  816b42:	push   %r14
  816b44:	push   %r12
  816b46:	push   %rbx
  816b47:	push   %rax
  816b48:	mov    %rdi,%rbx
  816b4b:	movzbl 0x9e(%rdi),%eax
  816b52:	test   %eax,%eax
  816b54:	je     816c1b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816b5a:	cmp    $0x3,%eax
  816b5d:	jne    816c51 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816b63:	mov    0x20(%rbx),%r15
  816b67:	mov    0x28(%rbx),%r12
  816b6b:	mov    (%r12),%rax
  816b6f:	test   %rax,%rax
  816b72:	je     816b79 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816b74:	mov    %r15,%rdi
  816b77:	call   *%rax
  816b79:	mov    0x8(%r12),%rsi
  816b7e:	test   %rsi,%rsi
  816b81:	je     816b91 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816b83:	mov    0x10(%r12),%rdx
  816b88:	mov    %r15,%rdi
  816b8b:	call   *0x66a347(%rip)        # e80ed8 <_DYNAMIC+0x248>
  816b91:	mov    0x68(%rbx),%rax
  816b95:	lock decq (%rax)
  816b99:	jne    816ba5 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816b9b:	lea    0x68(%rbx),%rdi
  816b9f:	call   *0x66a553(%rip)        # e810f8 <_DYNAMIC+0x468>
  816ba5:	movb   $0x0,0x98(%rbx)
  816bac:	mov    0x60(%rbx),%rax
  816bb0:	lock decq (%rax)
  816bb4:	jne    816bbf <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816bb6:	lea    0x60(%rbx),%rdi
  816bba:	call   812cc0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816bbf:	movw   $0x0,0x99(%rbx)
  816bc8:	mov    0x40(%rbx),%rax
  816bcc:	lock decq (%rax)
  816bd0:	jne    816bdc <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816bd2:	lea    0x40(%rbx),%rdi
  816bd6:	call   *0x66a524(%rip)        # e81100 <_DYNAMIC+0x470>
  816bdc:	movb   $0x0,0x9b(%rbx)
  816be3:	mov    0x38(%rbx),%rax
  816be7:	lock decq (%rax)
  816beb:	jne    816bf7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816bed:	lea    0x38(%rbx),%rdi
  816bf1:	call   *0x66a511(%rip)        # e81108 <_DYNAMIC+0x478>
  816bf7:	movb   $0x0,0x9c(%rbx)
  816bfe:	mov    0x30(%rbx),%rax
  816c02:	lock decq (%rax)
  816c06:	jne    816c12 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816c08:	lea    0x30(%rbx),%rdi
  816c0c:	call   *0x66a4fe(%rip)        # e81110 <_DYNAMIC+0x480>
  816c12:	movb   $0x0,0x9d(%rbx)
  816c19:	jmp    816c51 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816c1b:	mov    0x70(%rbx),%rax
  816c1f:	lock decq (%rax)
  816c23:	jne    816c2f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816c25:	lea    0x70(%rbx),%rdi
  816c29:	call   *0x66a4e1(%rip)        # e81110 <_DYNAMIC+0x480>
  816c2f:	mov    0x78(%rbx),%rax
  816c33:	lock decq (%rax)
  816c37:	jne    816c51 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816c39:	add    $0x78,%rbx
  816c3d:	mov    %rbx,%rdi
  816c40:	add    $0x8,%rsp
  816c44:	pop    %rbx
  816c45:	pop    %r12
  816c47:	pop    %r14
  816c49:	pop    %r15
  816c4b:	jmp    *0x66a4b7(%rip)        # e81108 <_DYNAMIC+0x478>
  816c51:	add    $0x8,%rsp
  816c55:	pop    %rbx
  816c56:	pop    %r12
  816c58:	pop    %r14
  816c5a:	pop    %r15
  816c5c:	ret
  816c5d:	mov    %rax,%r14
  816c60:	movb   $0x0,0x9d(%rbx)
  816c67:	mov    %r14,%rdi
  816c6a:	call   e2d9a0 <_Unwind_Resume@plt>
  816c6f:	mov    %rax,%r14
  816c72:	jmp    816d2c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816c77:	mov    %rax,%r14
  816c7a:	jmp    816d11 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816c7f:	mov    %rax,%r14
  816c82:	jmp    816cf4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816c84:	mov    %rax,%r14
  816c87:	jmp    816cda <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816c89:	mov    %rax,%r14
  816c8c:	mov    0x78(%rbx),%rax
  816c90:	lock decq (%rax)
  816c94:	jne    816ca3 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816c96:	add    $0x78,%rbx
  816c9a:	mov    %rbx,%rdi
  816c9d:	call   *0x66a465(%rip)        # e81108 <_DYNAMIC+0x478>
  816ca3:	mov    %r14,%rdi
  816ca6:	call   e2d9a0 <_Unwind_Resume@plt>
  816cab:	mov    %rax,%r14
  816cae:	mov    0x8(%r12),%rsi
  816cb3:	test   %rsi,%rsi
  816cb6:	je     816cc6 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816cb8:	mov    0x10(%r12),%rdx
  816cbd:	mov    %r15,%rdi
  816cc0:	call   *0x66a212(%rip)        # e80ed8 <_DYNAMIC+0x248>
  816cc6:	mov    0x68(%rbx),%rax
  816cca:	lock decq (%rax)
  816cce:	jne    816cda <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816cd0:	lea    0x68(%rbx),%rdi
  816cd4:	call   *0x66a41e(%rip)        # e810f8 <_DYNAMIC+0x468>
  816cda:	movb   $0x0,0x98(%rbx)
  816ce1:	mov    0x60(%rbx),%rax
  816ce5:	lock decq (%rax)
  816ce9:	jne    816cf4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816ceb:	lea    0x60(%rbx),%rdi
  816cef:	call   812cc0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816cf4:	movw   $0x0,0x99(%rbx)
  816cfd:	mov    0x40(%rbx),%rax
  816d01:	lock decq (%rax)
  816d05:	jne    816d11 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816d07:	lea    0x40(%rbx),%rdi
  816d0b:	call   *0x66a3ef(%rip)        # e81100 <_DYNAMIC+0x470>
  816d11:	movb   $0x0,0x9b(%rbx)
  816d18:	mov    0x38(%rbx),%rax
  816d1c:	lock decq (%rax)
  816d20:	jne    816d2c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816d22:	lea    0x38(%rbx),%rdi
  816d26:	call   *0x66a3dc(%rip)        # e81108 <_DYNAMIC+0x478>
  816d2c:	movb   $0x0,0x9c(%rbx)
  816d33:	mov    0x30(%rbx),%rax
  816d37:	lock decq (%rax)
  816d3b:	jne    816d47 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816d3d:	lea    0x30(%rbx),%rdi
  816d41:	call   *0x66a3c9(%rip)        # e81110 <_DYNAMIC+0x480>
  816d47:	movb   $0x0,0x9d(%rbx)
  816d4e:	mov    %r14,%rdi
  816d51:	call   e2d9a0 <_Unwind_Resume@plt>
  816d56:	call   *0x66a184(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816d60 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816d60:	push   %rbx
  816d61:	movzbl 0x20(%rdi),%eax
  816d65:	cmp    $0x3,%eax
  816d68:	je     816d83 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816d6a:	cmp    $0x4,%eax
  816d6d:	jne    816d90 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816d6f:	mov    %rdi,%rbx
  816d72:	add    $0x28,%rdi
  816d76:	call   816b40 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816d7b:	movw   $0x0,0x21(%rbx)
  816d81:	pop    %rbx
  816d82:	ret
  816d83:	add    $0x160,%rdi
  816d8a:	pop    %rbx
  816d8b:	jmp    816a60 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816d90:	pop    %rbx
  816d91:	ret
  816d92:	movw   $0x0,0x21(%rbx)
  816d98:	mov    %rax,%rdi
  816d9b:	call   e2d9a0 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817280 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  817280:	push   %r14
  817282:	push   %rbx
  817283:	push   %rax
  817284:	mov    %rdi,%rbx
  817287:	mov    (%rdi),%rax
  81728a:	lock decq (%rax)
  81728e:	jne    817299 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817290:	mov    %rbx,%rdi
  817293:	call   *0x669e77(%rip)        # e81110 <_DYNAMIC+0x480>
  817299:	mov    0x8(%rbx),%rax
  81729d:	lock decq (%rax)
  8172a1:	jne    8172ad <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  8172a3:	lea    0x8(%rbx),%rdi
  8172a7:	call   *0x669e5b(%rip)        # e81108 <_DYNAMIC+0x478>
  8172ad:	mov    0x10(%rbx),%rax
  8172b1:	lock decq (%rax)
  8172b5:	jne    8172c0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  8172b7:	lea    0x10(%rbx),%rdi
  8172bb:	call   812cc0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  8172c0:	mov    0x18(%rbx),%rax
  8172c4:	lock decq (%rax)
  8172c8:	jne    8172de <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  8172ca:	add    $0x18,%rbx
  8172ce:	mov    %rbx,%rdi
  8172d1:	add    $0x8,%rsp
  8172d5:	pop    %rbx
  8172d6:	pop    %r14
  8172d8:	jmp    *0x669e1a(%rip)        # e810f8 <_DYNAMIC+0x468>
  8172de:	add    $0x8,%rsp
  8172e2:	pop    %rbx
  8172e3:	pop    %r14
  8172e5:	ret
  8172e6:	mov    %rax,%r14
  8172e9:	jmp    81731a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  8172eb:	mov    %rax,%r14
  8172ee:	jmp    817307 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8172f0:	mov    %rax,%r14
  8172f3:	mov    0x8(%rbx),%rax
  8172f7:	lock decq (%rax)
  8172fb:	jne    817307 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8172fd:	lea    0x8(%rbx),%rdi
  817301:	call   *0x669e01(%rip)        # e81108 <_DYNAMIC+0x478>
  817307:	mov    0x10(%rbx),%rax
  81730b:	lock decq (%rax)
  81730f:	jne    81731a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  817311:	lea    0x10(%rbx),%rdi
  817315:	call   812cc0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81731a:	mov    0x18(%rbx),%rax
  81731e:	lock decq (%rax)
  817322:	jne    817331 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  817324:	add    $0x18,%rbx
  817328:	mov    %rbx,%rdi
  81732b:	call   *0x669dc7(%rip)        # e810f8 <_DYNAMIC+0x468>
  817331:	mov    %r14,%rdi
  817334:	call   e2d9a0 <_Unwind_Resume@plt>
  817339:	call   *0x669ba1(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1253 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817340 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  817340:	push   %r14
  817342:	push   %rbx
  817343:	push   %rax
  817344:	mov    %rdi,%rbx
  817347:	mov    0x228(%rdi),%rax
  81734e:	lock decq (%rax)
  817352:	jne    817361 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  817354:	lea    0x228(%rbx),%rdi
  81735b:	call   *0x669d97(%rip)        # e810f8 <_DYNAMIC+0x468>
  817361:	mov    0x230(%rbx),%rax
  817368:	lock decq (%rax)
  81736c:	jne    81737b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  81736e:	lea    0x230(%rbx),%rdi
  817375:	call   *0x669e1d(%rip)        # e81198 <_DYNAMIC+0x508>
  81737b:	mov    0x238(%rbx),%rax
  817382:	lock decq (%rax)
  817386:	jne    817395 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  817388:	lea    0x238(%rbx),%rdi
  81738f:	call   *0x669e0b(%rip)        # e811a0 <_DYNAMIC+0x510>
  817395:	mov    0x258(%rbx),%rax
  81739c:	lock decq (%rax)
  8173a0:	jne    8173af <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  8173a2:	lea    0x258(%rbx),%rdi
  8173a9:	call   *0x669de9(%rip)        # e81198 <_DYNAMIC+0x508>
  8173af:	mov    0x260(%rbx),%rax
  8173b6:	lock decq (%rax)
  8173ba:	jne    8173c9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  8173bc:	lea    0x260(%rbx),%rdi
  8173c3:	call   *0x669dd7(%rip)        # e811a0 <_DYNAMIC+0x510>
  8173c9:	mov    0x280(%rbx),%rax
  8173d0:	lock decq (%rax)
  8173d4:	jne    8173e3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  8173d6:	lea    0x280(%rbx),%rdi
  8173dd:	call   *0x669db5(%rip)        # e81198 <_DYNAMIC+0x508>
  8173e3:	mov    0x288(%rbx),%rax
  8173ea:	lock decq (%rax)
  8173ee:	jne    8173fd <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  8173f0:	lea    0x288(%rbx),%rdi
  8173f7:	call   *0x669da3(%rip)        # e811a0 <_DYNAMIC+0x510>
  8173fd:	mov    0x2a8(%rbx),%rax
  817404:	lock decq (%rax)
  817408:	jne    817417 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  81740a:	lea    0x2a8(%rbx),%rdi
  817411:	call   *0x669d81(%rip)        # e81198 <_DYNAMIC+0x508>
  817417:	mov    0x2b0(%rbx),%rax
  81741e:	lock decq (%rax)
  817422:	jne    817431 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  817424:	lea    0x2b0(%rbx),%rdi
  81742b:	call   *0x669d6f(%rip)        # e811a0 <_DYNAMIC+0x510>
  817431:	mov    0x2d0(%rbx),%rax
  817438:	lock decq (%rax)
  81743c:	jne    81744b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  81743e:	lea    0x2d0(%rbx),%rdi
  817445:	call   *0x669d4d(%rip)        # e81198 <_DYNAMIC+0x508>
  81744b:	mov    0x2d8(%rbx),%rax
  817452:	lock decq (%rax)
  817456:	jne    817465 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  817458:	lea    0x2d8(%rbx),%rdi
  81745f:	call   *0x669d3b(%rip)        # e811a0 <_DYNAMIC+0x510>
  817465:	lea    0x78(%rbx),%rdi
  817469:	call   817830 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81746e:	mov    0x328(%rbx),%r14
  817475:	test   %r14,%r14
  817478:	je     8174d7 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  81747a:	mov    (%r14),%rsi
  81747d:	test   %rsi,%rsi
  817480:	je     817495 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  817482:	mov    0x8(%r14),%rdi
  817486:	shl    $0x3,%rsi
  81748a:	mov    $0x8,%edx
  81748f:	call   *0x669a43(%rip)        # e80ed8 <_DYNAMIC+0x248>
  817495:	mov    0x20(%r14),%rsi
  817499:	test   %rsi,%rsi
  81749c:	je     8174c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81749e:	mov    %rsi,%rax
  8174a1:	shl    $0x4,%rax
  8174a5:	add    %rax,%rsi
  8174a8:	add    $0x21,%rsi
  8174ac:	je     8174c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  8174ae:	mov    0x18(%r14),%rdi
  8174b2:	sub    %rax,%rdi
  8174b5:	add    $0xfffffffffffffff0,%rdi
  8174b9:	mov    $0x10,%edx
  8174be:	call   *0x669a14(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8174c4:	mov    $0x80,%esi
  8174c9:	mov    $0x8,%edx
  8174ce:	mov    %r14,%rdi
  8174d1:	call   *0x669a01(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8174d7:	mov    (%rbx),%rsi
  8174da:	test   %rsi,%rsi
  8174dd:	je     8174f2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  8174df:	mov    0x8(%rbx),%rdi
  8174e3:	shl    $0x4,%rsi
  8174e7:	mov    $0x4,%edx
  8174ec:	call   *0x6699e6(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8174f2:	mov    0x18(%rbx),%rsi
  8174f6:	test   %rsi,%rsi
  8174f9:	je     81750e <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  8174fb:	mov    0x20(%rbx),%rdi
  8174ff:	shl    $0x3,%rsi
  817503:	mov    $0x4,%edx
  817508:	call   *0x6699ca(%rip)        # e80ed8 <_DYNAMIC+0x248>
  81750e:	mov    0x30(%rbx),%rsi
  817512:	test   %rsi,%rsi
  817515:	je     81752a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817517:	mov    0x38(%rbx),%rdi
  81751b:	shl    $0x2,%rsi
  81751f:	mov    $0x4,%edx
  817524:	call   *0x6699ae(%rip)        # e80ed8 <_DYNAMIC+0x248>
  81752a:	mov    0x48(%rbx),%rsi
  81752e:	test   %rsi,%rsi
  817531:	je     817546 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  817533:	mov    0x50(%rbx),%rdi
  817537:	shl    $0x2,%rsi
  81753b:	mov    $0x4,%edx
  817540:	call   *0x669992(%rip)        # e80ed8 <_DYNAMIC+0x248>
  817546:	mov    0x60(%rbx),%rsi
  81754a:	test   %rsi,%rsi
  81754d:	je     817562 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  81754f:	mov    0x68(%rbx),%rdi
  817553:	shl    $0x5,%rsi
  817557:	mov    $0x4,%edx
  81755c:	call   *0x669976(%rip)        # e80ed8 <_DYNAMIC+0x248>
  817562:	mov    0x300(%rbx),%rsi
  817569:	test   %rsi,%rsi
  81756c:	je     81759c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  81756e:	lea    (%rsi,%rsi,8),%rax
  817572:	lea    0x33(,%rax,4),%rax
  81757a:	and    $0xfffffffffffffff0,%rax
  81757e:	add    %rax,%rsi
  817581:	add    $0x11,%rsi
  817585:	je     81759c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  817587:	mov    0x2f8(%rbx),%rdi
  81758e:	sub    %rax,%rdi
  817591:	mov    $0x10,%edx
  817596:	call   *0x66993c(%rip)        # e80ed8 <_DYNAMIC+0x248>
  81759c:	mov    0x330(%rbx),%rax
  8175a3:	test   %rax,%rax
  8175a6:	je     8175c5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  8175a8:	lock decq (%rax)
  8175ac:	jne    8175c5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  8175ae:	add    $0x330,%rbx
  8175b5:	mov    %rbx,%rdi
  8175b8:	add    $0x8,%rsp
  8175bc:	pop    %rbx
  8175bd:	pop    %r14
  8175bf:	jmp    *0x669be3(%rip)        # e811a8 <_DYNAMIC+0x518>
  8175c5:	add    $0x8,%rsp
  8175c9:	pop    %rbx
  8175ca:	pop    %r14
  8175cc:	ret
  8175cd:	mov    %rax,%r14
  8175d0:	jmp    8176fc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8175d5:	mov    %rax,%r14
  8175d8:	mov    0x2d8(%rbx),%rax
  8175df:	lock decq (%rax)
  8175e3:	jne    8176fc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8175e9:	lea    0x2d8(%rbx),%rdi
  8175f0:	call   *0x669baa(%rip)        # e811a0 <_DYNAMIC+0x510>
  8175f6:	jmp    8176fc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  8175fb:	call   *0x6698df(%rip)        # e80ee0 <_DYNAMIC+0x250>
  817601:	mov    %rax,%r14
  817604:	jmp    8176f0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  817609:	mov    %rax,%r14
  81760c:	mov    0x2b0(%rbx),%rax
  817613:	lock decq (%rax)
  817617:	jne    8176f0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81761d:	lea    0x2b0(%rbx),%rdi
  817624:	call   *0x669b76(%rip)        # e811a0 <_DYNAMIC+0x510>
  81762a:	jmp    8176f0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81762f:	call   *0x6698ab(%rip)        # e80ee0 <_DYNAMIC+0x250>
  817635:	mov    %rax,%r14
  817638:	jmp    8176e4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  81763d:	mov    %rax,%r14
  817640:	mov    0x288(%rbx),%rax
  817647:	lock decq (%rax)
  81764b:	jne    8176e4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  817651:	lea    0x288(%rbx),%rdi
  817658:	call   *0x669b42(%rip)        # e811a0 <_DYNAMIC+0x510>
  81765e:	jmp    8176e4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  817663:	call   *0x669877(%rip)        # e80ee0 <_DYNAMIC+0x250>
  817669:	mov    %rax,%r14
  81766c:	jmp    8176d8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81766e:	mov    %rax,%r14
  817671:	mov    0x260(%rbx),%rax
  817678:	lock decq (%rax)
  81767c:	jne    8176d8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81767e:	lea    0x260(%rbx),%rdi
  817685:	call   *0x669b15(%rip)        # e811a0 <_DYNAMIC+0x510>
  81768b:	jmp    8176d8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81768d:	call   *0x66984d(%rip)        # e80ee0 <_DYNAMIC+0x250>
  817693:	mov    %rax,%r14
  817696:	jmp    8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817698:	mov    %rax,%r14
  81769b:	mov    0x238(%rbx),%rax
  8176a2:	lock decq (%rax)
  8176a6:	jne    8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  8176a8:	lea    0x238(%rbx),%rdi
  8176af:	call   *0x669aeb(%rip)        # e811a0 <_DYNAMIC+0x510>
  8176b5:	jmp    8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  8176b7:	call   *0x669823(%rip)        # e80ee0 <_DYNAMIC+0x250>
  8176bd:	mov    %rax,%r14
  8176c0:	lea    0x230(%rbx),%rdi
  8176c7:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176cc:	lea    0x258(%rbx),%rdi
  8176d3:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176d8:	lea    0x280(%rbx),%rdi
  8176df:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176e4:	lea    0x2a8(%rbx),%rdi
  8176eb:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176f0:	lea    0x2d0(%rbx),%rdi
  8176f7:	call   817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8176fc:	lea    0x78(%rbx),%rdi
  817700:	call   817830 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  817705:	mov    0x328(%rbx),%rdi
  81770c:	call   816480 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  817711:	mov    (%rbx),%rsi
  817714:	test   %rsi,%rsi
  817717:	jne    817792 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  817719:	mov    0x18(%rbx),%rsi
  81771d:	test   %rsi,%rsi
  817720:	jne    8177b2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  817726:	mov    0x30(%rbx),%rsi
  81772a:	test   %rsi,%rsi
  81772d:	jne    8177d2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  817733:	mov    0x48(%rbx),%rsi
  817737:	test   %rsi,%rsi
  81773a:	jne    8177f2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  817740:	mov    0x60(%rbx),%rsi
  817744:	test   %rsi,%rsi
  817747:	je     81775c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817749:	mov    0x68(%rbx),%rdi
  81774d:	shl    $0x5,%rsi
  817751:	mov    $0x4,%edx
  817756:	call   *0x66977c(%rip)        # e80ed8 <_DYNAMIC+0x248>
  81775c:	lea    0x2f8(%rbx),%rdi
  817763:	call   819c40 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  817768:	mov    0x330(%rbx),%rax
  81776f:	test   %rax,%rax
  817772:	je     81778a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  817774:	lock decq (%rax)
  817778:	jne    81778a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  81777a:	add    $0x330,%rbx
  817781:	mov    %rbx,%rdi
  817784:	call   *0x669a1e(%rip)        # e811a8 <_DYNAMIC+0x518>
  81778a:	mov    %r14,%rdi
  81778d:	call   e2d9a0 <_Unwind_Resume@plt>
  817792:	mov    0x8(%rbx),%rdi
  817796:	shl    $0x4,%rsi
  81779a:	mov    $0x4,%edx
  81779f:	call   *0x669733(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8177a5:	mov    0x18(%rbx),%rsi
  8177a9:	test   %rsi,%rsi
  8177ac:	je     817726 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  8177b2:	mov    0x20(%rbx),%rdi
  8177b6:	shl    $0x3,%rsi
  8177ba:	mov    $0x4,%edx
  8177bf:	call   *0x669713(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8177c5:	mov    0x30(%rbx),%rsi
  8177c9:	test   %rsi,%rsi
  8177cc:	je     817733 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  8177d2:	mov    0x38(%rbx),%rdi
  8177d6:	shl    $0x2,%rsi
  8177da:	mov    $0x4,%edx
  8177df:	call   *0x6696f3(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8177e5:	mov    0x48(%rbx),%rsi
  8177e9:	test   %rsi,%rsi
  8177ec:	je     817740 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  8177f2:	mov    0x50(%rbx),%rdi
  8177f6:	shl    $0x2,%rsi
  8177fa:	mov    $0x4,%edx
  8177ff:	call   *0x6696d3(%rip)        # e80ed8 <_DYNAMIC+0x248>
  817805:	mov    0x60(%rbx),%rsi
  817809:	test   %rsi,%rsi
  81780c:	jne    817749 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  817812:	jmp    81775c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817817:	call   *0x6696c3(%rip)        # e80ee0 <_DYNAMIC+0x250>
  81781d:	mov    %rax,%r14
  817820:	jmp    817705 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817830 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  817830:	push   %r14
  817832:	push   %rbx
  817833:	push   %rax
  817834:	mov    %rdi,%rbx
  817837:	mov    (%rdi),%rax
  81783a:	lock decq (%rax)
  81783e:	jne    817849 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  817840:	mov    %rbx,%rdi
  817843:	call   *0x66992f(%rip)        # e81178 <_DYNAMIC+0x4e8>
  817849:	mov    0x50(%rbx),%rax
  81784d:	lock decq (%rax)
  817851:	jne    81785d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  817853:	lea    0x50(%rbx),%rdi
  817857:	call   *0x669913(%rip)        # e81170 <_DYNAMIC+0x4e0>
  81785d:	mov    0x58(%rbx),%rax
  817861:	lock decq (%rax)
  817865:	jne    817871 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  817867:	lea    0x58(%rbx),%rdi
  81786b:	call   *0x669907(%rip)        # e81178 <_DYNAMIC+0x4e8>
  817871:	mov    0xb0(%rbx),%rsi
  817878:	test   %rsi,%rsi
  81787b:	je     8178ad <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81787d:	mov    %rsi,%rax
  817880:	shl    $0x5,%rax
  817884:	add    %rax,%rsi
  817887:	add    $0x31,%rsi
  81788b:	je     8178ad <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81788d:	mov    0xa8(%rbx),%rdi
  817894:	sub    %rax,%rdi
  817897:	add    $0xffffffffffffffe0,%rdi
  81789b:	mov    $0x10,%edx
  8178a0:	add    $0x8,%rsp
  8178a4:	pop    %rbx
  8178a5:	pop    %r14
  8178a7:	jmp    *0x66962b(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8178ad:	add    $0x8,%rsp
  8178b1:	pop    %rbx
  8178b2:	pop    %r14
  8178b4:	ret
  8178b5:	mov    %rax,%r14
  8178b8:	jmp    8178e5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  8178ba:	mov    %rax,%r14
  8178bd:	mov    0x58(%rbx),%rax
  8178c1:	lock decq (%rax)
  8178c5:	jne    8178e5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  8178c7:	lea    0x58(%rbx),%rdi
  8178cb:	call   *0x6698a7(%rip)        # e81178 <_DYNAMIC+0x4e8>
  8178d1:	jmp    8178e5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  8178d3:	call   *0x669607(%rip)        # e80ee0 <_DYNAMIC+0x250>
  8178d9:	mov    %rax,%r14
  8178dc:	lea    0x50(%rbx),%rdi
  8178e0:	call   817a30 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  8178e5:	add    $0xa8,%rbx
  8178ec:	mov    %rbx,%rdi
  8178ef:	call   819c80 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  8178f4:	mov    %r14,%rdi
  8178f7:	call   e2d9a0 <_Unwind_Resume@plt>
  8178fc:	call   *0x6695de(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817910 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817910:	cmpl   $0x1,(%rdi)
  817913:	ja     81792d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817915:	mov    0x8(%rdi),%rsi
  817919:	test   %rsi,%rsi
  81791c:	je     81792d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  81791e:	mov    0x10(%rdi),%rdi
  817922:	mov    $0x1,%edx
  817927:	jmp    *0x6695ab(%rip)        # e80ed8 <_DYNAMIC+0x248>
  81792d:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817930 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  817930:	push   %r14
  817932:	push   %rbx
  817933:	push   %rax
  817934:	mov    %rdi,%rbx
  817937:	mov    (%rdi),%rax
  81793a:	lock decq (%rax)
  81793e:	jne    817949 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  817940:	mov    %rbx,%rdi
  817943:	call   *0x66984f(%rip)        # e81198 <_DYNAMIC+0x508>
  817949:	mov    0x8(%rbx),%rax
  81794d:	lock decq (%rax)
  817951:	jne    817967 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  817953:	add    $0x8,%rbx
  817957:	mov    %rbx,%rdi
  81795a:	add    $0x8,%rsp
  81795e:	pop    %rbx
  81795f:	pop    %r14
  817961:	jmp    *0x669839(%rip)        # e811a0 <_DYNAMIC+0x510>
  817967:	add    $0x8,%rsp
  81796b:	pop    %rbx
  81796c:	pop    %r14
  81796e:	ret
  81796f:	mov    %rax,%r14
  817972:	mov    0x8(%rbx),%rax
  817976:	lock decq (%rax)
  81797a:	jne    817989 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81797c:	add    $0x8,%rbx
  817980:	mov    %rbx,%rdi
  817983:	call   *0x669817(%rip)        # e811a0 <_DYNAMIC+0x510>
  817989:	mov    %r14,%rdi
  81798c:	call   e2d9a0 <_Unwind_Resume@plt>
  817991:	call   *0x669549(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000818300 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  818300:	sub    $0x18,%rsp
  818304:	mov    %rsi,%rax
  818307:	mov    (%rdi),%ecx
  818309:	lea    -0x747488(%rip),%rdx        # d0e88 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  818310:	movslq (%rdx,%rcx,4),%rcx
  818314:	add    %rdx,%rcx
  818317:	jmp    *%rcx
  818319:	add    $0x8,%rdi
  81831d:	mov    %rdi,0x10(%rsp)
  818322:	lea    -0x743b9d(%rip),%rsi        # d478c <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44bc>
  818329:	jmp    8183b8 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  81832e:	lea    -0x743b80(%rip),%rsi        # d47b5 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44e5>
  818335:	mov    $0x13,%edx
  81833a:	mov    %rax,%rdi
  81833d:	add    $0x18,%rsp
  818341:	jmp    *0x668c81(%rip)        # e80fc8 <_DYNAMIC+0x338>
  818347:	add    $0x4,%rdi
  81834b:	mov    %rdi,0x10(%rsp)
  818350:	lea    -0x743bbf(%rip),%rsi        # d4798 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44c8>
  818357:	lea    0x616f4a(%rip),%r8        # e2f2a8 <__frame_dummy_init_array_entry+0x8c8>
  81835e:	lea    0x10(%rsp),%rcx
  818363:	mov    $0x11,%edx
  818368:	mov    %rax,%rdi
  81836b:	call   *0x668c5f(%rip)        # e80fd0 <_DYNAMIC+0x340>
  818371:	add    $0x18,%rsp
  818375:	ret
  818376:	lea    -0x743bd4(%rip),%rsi        # d47a9 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44d9>
  81837d:	mov    $0xc,%edx
  818382:	mov    %rax,%rdi
  818385:	add    $0x18,%rsp
  818389:	jmp    *0x668c39(%rip)        # e80fc8 <_DYNAMIC+0x338>
  81838f:	lea    -0x743bb8(%rip),%rsi        # d47de <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x450e>
  818396:	mov    $0x9,%edx
  81839b:	mov    %rax,%rdi
  81839e:	add    $0x18,%rsp
  8183a2:	jmp    *0x668c20(%rip)        # e80fc8 <_DYNAMIC+0x338>
  8183a8:	add    $0x8,%rdi
  8183ac:	mov    %rdi,0x10(%rsp)
  8183b1:	lea    -0x743c26(%rip),%rsi        # d4792 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44c2>
  8183b8:	lea    0x616ec9(%rip),%r8        # e2f288 <__frame_dummy_init_array_entry+0x8a8>
  8183bf:	lea    0x10(%rsp),%rcx
  8183c4:	mov    $0x6,%edx
  8183c9:	mov    %rax,%rdi
  8183cc:	call   *0x668bfe(%rip)        # e80fd0 <_DYNAMIC+0x340>
  8183d2:	add    $0x18,%rsp
  8183d6:	ret
  8183d7:	add    $0x8,%rdi
  8183db:	mov    %rdi,0x10(%rsp)
  8183e0:	lea    0x616ee1(%rip),%rcx        # e2f2c8 <__frame_dummy_init_array_entry+0x8e8>
  8183e7:	mov    %rcx,(%rsp)
  8183eb:	lea    -0x743c2a(%rip),%rsi        # d47c8 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44f8>
  8183f2:	lea    -0x76958d(%rip),%rcx        # aee6c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  8183f9:	lea    0x10(%rsp),%r9
  8183fe:	mov    $0x9,%edx
  818403:	mov    $0x4,%r8d
  818409:	mov    %rax,%rdi
  81840c:	call   *0x668da6(%rip)        # e811b8 <_DYNAMIC+0x528>
  818412:	add    $0x18,%rsp
  818416:	ret
  818417:	lea    -0x743c4d(%rip),%rsi        # d47d1 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4501>
  81841e:	mov    $0xd,%edx
  818423:	mov    %rax,%rdi
  818426:	add    $0x18,%rsp
  81842a:	jmp    *0x668b98(%rip)        # e80fc8 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819c80 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819c80:	mov    0x8(%rdi),%rsi
  819c84:	test   %rsi,%rsi
  819c87:	je     819cae <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819c89:	mov    %rsi,%rax
  819c8c:	shl    $0x5,%rax
  819c90:	add    %rax,%rsi
  819c93:	add    $0x31,%rsi
  819c97:	je     819cae <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819c99:	mov    (%rdi),%rdi
  819c9c:	sub    %rax,%rdi
  819c9f:	add    $0xffffffffffffffe0,%rdi
  819ca3:	mov    $0x10,%edx
  819ca8:	jmp    *0x66722a(%rip)        # e80ed8 <_DYNAMIC+0x248>
  819cae:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819cb0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819cb0:	mov    0x8(%rdi),%rsi
  819cb4:	test   %rsi,%rsi
  819cb7:	je     819cde <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819cb9:	mov    %rsi,%rax
  819cbc:	shl    $0x4,%rax
  819cc0:	add    %rax,%rsi
  819cc3:	add    $0x21,%rsi
  819cc7:	je     819cde <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819cc9:	mov    (%rdi),%rdi
  819ccc:	sub    %rax,%rdi
  819ccf:	add    $0xfffffffffffffff0,%rdi
  819cd3:	mov    $0x10,%edx
  819cd8:	jmp    *0x6671fa(%rip)        # e80ed8 <_DYNAMIC+0x248>
  819cde:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b570 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b570:	push   %r14
  81b572:	push   %rbx
  81b573:	sub    $0x38,%rsp
  81b577:	mov    %rdi,%rbx
  81b57a:	cmpq   $0x0,(%rsi)
  81b57e:	je     81b688 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b584:	movdqu (%rsi),%xmm0
  81b588:	movdqu 0x10(%rsi),%xmm1
  81b58d:	movdqu 0x20(%rsi),%xmm2
  81b592:	movdqa %xmm2,0x20(%rsp)
  81b598:	movdqa %xmm1,0x10(%rsp)
  81b59e:	movdqa %xmm0,(%rsp)
  81b5a3:	cmpq   $0x0,0x18(%rcx)
  81b5a8:	je     81b69c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b5ae:	lea    0x10(%rsp),%rsi
  81b5b3:	lea    0x20(%rcx),%rdi
  81b5b7:	mov    %rcx,%r14
  81b5ba:	call   825110 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b5bf:	mov    %rax,%rsi
  81b5c2:	shr    $0x39,%rsi
  81b5c6:	mov    (%r14),%rcx
  81b5c9:	mov    0x8(%r14),%rdx
  81b5cd:	movd   %esi,%xmm0
  81b5d1:	punpcklbw %xmm0,%xmm0
  81b5d5:	pshuflw $0x0,%xmm0,%xmm0
  81b5da:	pshufd $0x44,%xmm0,%xmm0
  81b5df:	mov    0x10(%rsp),%rsi
  81b5e4:	movzwl 0x1c(%rsp),%edi
  81b5e9:	xor    %r8d,%r8d
  81b5ec:	mov    0x18(%rsp),%r9d
  81b5f1:	pcmpeqd %xmm1,%xmm1
  81b5f5:	and    %rdx,%rax
  81b5f8:	movdqu (%rcx,%rax,1),%xmm2
  81b5fd:	movdqa %xmm2,%xmm3
  81b601:	pcmpeqb %xmm0,%xmm3
  81b605:	pmovmskb %xmm3,%r10d
  81b60a:	test   %r10d,%r10d
  81b60d:	je     81b650 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b60f:	tzcnt  %r10d,%r14d
  81b614:	add    %rax,%r14
  81b617:	and    %rdx,%r14
  81b61a:	shl    $0x5,%r14
  81b61e:	mov    %rcx,%r11
  81b621:	sub    %r14,%r11
  81b624:	cmp    -0x20(%r11),%rsi
  81b628:	jne    81b637 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b62a:	cmp    -0x14(%r11),%di
  81b62f:	jne    81b637 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b631:	cmp    -0x18(%r11),%r9d
  81b635:	je     81b66b <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b637:	lea    -0x1(%r10),%r11d
  81b63b:	and    %r10w,%r11w
  81b63f:	mov    %r11d,%r10d
  81b642:	jne    81b60f <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b644:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b650:	pcmpeqb %xmm1,%xmm2
  81b654:	pmovmskb %xmm2,%r10d
  81b659:	test   %r10d,%r10d
  81b65c:	jne    81b69c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b65e:	add    %r8,%rax
  81b661:	add    $0x10,%rax
  81b665:	add    $0x10,%r8
  81b669:	jmp    81b5f5 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b66b:	mov    -0x4(%r11),%eax
  81b66f:	shl    $0x10,%eax
  81b672:	or     -0x8(%r11),%eax
  81b676:	mov    -0x10(%r11),%rcx
  81b67a:	mov    %rcx,(%rbx)
  81b67d:	mov    %eax,0x8(%rbx)
  81b680:	add    $0x38,%rsp
  81b684:	pop    %rbx
  81b685:	pop    %r14
  81b687:	ret
  81b688:	mov    0x8(%rdx),%eax
  81b68b:	mov    %eax,0x8(%rbx)
  81b68e:	mov    (%rdx),%rax
  81b691:	mov    %rax,(%rbx)
  81b694:	add    $0x38,%rsp
  81b698:	pop    %rbx
  81b699:	pop    %r14
  81b69b:	ret
  81b69c:	lea    -0x746ad9(%rip),%rdi        # d4bca <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b6a3:	lea    0x61409e(%rip),%rdx        # e2f748 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x90>
  81b6aa:	mov    $0x16,%esi
  81b6af:	call   *0x665b7b(%rip)        # e81230 <_DYNAMIC+0x5a0>

FUNCTION <gpui_gpu::renderer::Changes>::replace::<1: usize> bytes=105 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>:
  81b6c0:	cmp    %rdx,%rcx
  81b6c3:	jae    81b711 <<gpui_gpu::renderer::Changes>::replace::<1>+0x51>
  81b6c5:	mov    %rcx,%rax
  81b6c8:	shl    $0x4,%rax
  81b6cc:	movdqu (%rsi,%rax,1),%xmm0
  81b6d1:	movdqu (%r8),%xmm1
  81b6d6:	pcmpeqb %xmm0,%xmm1
  81b6da:	pmovmskb %xmm1,%edx
  81b6de:	cmp    $0xffff,%edx
  81b6e4:	jne    81b6e7 <<gpui_gpu::renderer::Changes>::replace::<1>+0x27>
  81b6e6:	ret
  81b6e7:	add    %rax,%rsi
  81b6ea:	mov    (%rdi),%rax
  81b6ed:	mov    0x8(%rdi),%rdx
  81b6f1:	cmp    %rax,%rcx
  81b6f4:	cmovb  %rcx,%rax
  81b6f8:	inc    %rcx
  81b6fb:	cmp    %rdx,%rcx
  81b6fe:	cmovbe %rdx,%rcx
  81b702:	mov    %rax,(%rdi)
  81b705:	mov    %rcx,0x8(%rdi)
  81b709:	movups (%r8),%xmm0
  81b70d:	movups %xmm0,(%rsi)
  81b710:	ret
  81b711:	push   %rax
  81b712:	lea    0x1(%rcx),%rsi
  81b716:	lea    0x613f9b(%rip),%rax        # e2f6b8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318>
  81b71d:	mov    %rcx,%rdi
  81b720:	mov    %rax,%rcx
  81b723:	call   *0x665aaf(%rip)        # e811d8 <_DYNAMIC+0x548>

FUNCTION <gpui_gpu::renderer::Changes>::replace::<2: usize> bytes=192 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b730 <<gpui_gpu::renderer::Changes>::replace::<2>>:
  81b730:	mov    %rsi,%rax
  81b733:	lea    0x2(%rcx),%rsi
  81b737:	cmp    $0xfffffffffffffffd,%rcx
  81b73b:	ja     81b7dc <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b741:	cmp    %rdx,%rsi
  81b744:	ja     81b7dc <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b74a:	mov    %rcx,%r11
  81b74d:	shl    $0x4,%r11
  81b751:	lea    (%rax,%r11,1),%rdx
  81b755:	mov    (%rdi),%r10
  81b758:	mov    0x8(%rdi),%r9
  81b75c:	movdqu (%rax,%r11,1),%xmm0
  81b762:	movdqu (%r8),%xmm1
  81b767:	pcmpeqb %xmm0,%xmm1
  81b76b:	pmovmskb %xmm1,%eax
  81b76f:	cmp    $0xffff,%eax
  81b774:	je     81b798 <<gpui_gpu::renderer::Changes>::replace::<2>+0x68>
  81b776:	cmp    %r10,%rcx
  81b779:	cmovb  %rcx,%r10
  81b77d:	lea    0x1(%rcx),%rax
  81b781:	cmp    %r9,%rax
  81b784:	cmova  %rax,%r9
  81b788:	mov    %r10,(%rdi)
  81b78b:	mov    %r9,0x8(%rdi)
  81b78f:	movdqu (%r8),%xmm0
  81b794:	movdqu %xmm0,(%rdx)
  81b798:	movdqu 0x10(%rdx),%xmm0
  81b79d:	movdqu 0x10(%r8),%xmm1
  81b7a3:	pcmpeqb %xmm0,%xmm1
  81b7a7:	pmovmskb %xmm1,%eax
  81b7ab:	cmp    $0xffff,%eax
  81b7b0:	je     81b7db <<gpui_gpu::renderer::Changes>::replace::<2>+0xab>
  81b7b2:	add    $0x10,%rdx
  81b7b6:	add    $0x10,%r8
  81b7ba:	inc    %rcx
  81b7bd:	cmp    %r10,%rcx
  81b7c0:	cmovae %r10,%rcx
  81b7c4:	cmp    %r9,%rsi
  81b7c7:	cmova  %rsi,%r9
  81b7cb:	mov    %rcx,(%rdi)
  81b7ce:	mov    %r9,0x8(%rdi)
  81b7d2:	movdqu (%r8),%xmm0
  81b7d7:	movdqu %xmm0,(%rdx)
  81b7db:	ret
  81b7dc:	push   %rax
  81b7dd:	lea    0x613ed4(%rip),%rax        # e2f6b8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318>
  81b7e4:	mov    %rcx,%rdi
  81b7e7:	mov    %rax,%rcx
  81b7ea:	call   *0x6659e8(%rip)        # e811d8 <_DYNAMIC+0x548>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81bae0:	push   %r14
  81bae2:	push   %rbx
  81bae3:	push   %rax
  81bae4:	mov    %rdi,%rbx
  81bae7:	mov    (%rdi),%rax
  81baea:	lock decq (%rax)
  81baee:	jne    81baf9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81baf0:	mov    %rbx,%rdi
  81baf3:	call   *0x66567f(%rip)        # e81178 <_DYNAMIC+0x4e8>
  81baf9:	mov    0x50(%rbx),%rax
  81bafd:	lock decq (%rax)
  81bb01:	jne    81bb0d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81bb03:	lea    0x50(%rbx),%rdi
  81bb07:	call   *0x665663(%rip)        # e81170 <_DYNAMIC+0x4e0>
  81bb0d:	mov    0x58(%rbx),%rax
  81bb11:	lock decq (%rax)
  81bb15:	jne    81bb21 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81bb17:	lea    0x58(%rbx),%rdi
  81bb1b:	call   *0x665657(%rip)        # e81178 <_DYNAMIC+0x4e8>
  81bb21:	mov    0xb0(%rbx),%rsi
  81bb28:	test   %rsi,%rsi
  81bb2b:	je     81bb5d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bb2d:	mov    %rsi,%rax
  81bb30:	shl    $0x5,%rax
  81bb34:	add    %rax,%rsi
  81bb37:	add    $0x31,%rsi
  81bb3b:	je     81bb5d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bb3d:	mov    0xa8(%rbx),%rdi
  81bb44:	sub    %rax,%rdi
  81bb47:	add    $0xffffffffffffffe0,%rdi
  81bb4b:	mov    $0x10,%edx
  81bb50:	add    $0x8,%rsp
  81bb54:	pop    %rbx
  81bb55:	pop    %r14
  81bb57:	jmp    *0x66537b(%rip)        # e80ed8 <_DYNAMIC+0x248>
  81bb5d:	add    $0x8,%rsp
  81bb61:	pop    %rbx
  81bb62:	pop    %r14
  81bb64:	ret
  81bb65:	mov    %rax,%r14
  81bb68:	jmp    81bb95 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb6a:	mov    %rax,%r14
  81bb6d:	mov    0x58(%rbx),%rax
  81bb71:	lock decq (%rax)
  81bb75:	jne    81bb95 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb77:	lea    0x58(%rbx),%rdi
  81bb7b:	call   *0x6655f7(%rip)        # e81178 <_DYNAMIC+0x4e8>
  81bb81:	jmp    81bb95 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bb83:	call   *0x665357(%rip)        # e80ee0 <_DYNAMIC+0x250>
  81bb89:	mov    %rax,%r14
  81bb8c:	lea    0x50(%rbx),%rdi
  81bb90:	call   81c430 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bb95:	add    $0xa8,%rbx
  81bb9c:	mov    %rbx,%rdi
  81bb9f:	call   823210 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bba4:	mov    %r14,%rdi
  81bba7:	call   e2d9a0 <_Unwind_Resume@plt>
  81bbac:	call   *0x66532e(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bbc0:	push   %r14
  81bbc2:	push   %rbx
  81bbc3:	push   %rax
  81bbc4:	mov    %rdi,%rbx
  81bbc7:	mov    (%rdi),%rax
  81bbca:	lock decq (%rax)
  81bbce:	jne    81bbd9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bbd0:	mov    %rbx,%rdi
  81bbd3:	call   *0x6655bf(%rip)        # e81198 <_DYNAMIC+0x508>
  81bbd9:	mov    0x8(%rbx),%rax
  81bbdd:	lock decq (%rax)
  81bbe1:	jne    81bbf7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bbe3:	add    $0x8,%rbx
  81bbe7:	mov    %rbx,%rdi
  81bbea:	add    $0x8,%rsp
  81bbee:	pop    %rbx
  81bbef:	pop    %r14
  81bbf1:	jmp    *0x6655a9(%rip)        # e811a0 <_DYNAMIC+0x510>
  81bbf7:	add    $0x8,%rsp
  81bbfb:	pop    %rbx
  81bbfc:	pop    %r14
  81bbfe:	ret
  81bbff:	mov    %rax,%r14
  81bc02:	mov    0x8(%rbx),%rax
  81bc06:	lock decq (%rax)
  81bc0a:	jne    81bc19 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bc0c:	add    $0x8,%rbx
  81bc10:	mov    %rbx,%rdi
  81bc13:	call   *0x665587(%rip)        # e811a0 <_DYNAMIC+0x510>
  81bc19:	mov    %r14,%rdi
  81bc1c:	call   e2d9a0 <_Unwind_Resume@plt>
  81bc21:	call   *0x6652b9(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c560 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c560:	push   %rbp
  81c561:	push   %r15
  81c563:	push   %r14
  81c565:	push   %r13
  81c567:	push   %r12
  81c569:	push   %rbx
  81c56a:	sub    $0x28,%rsp
  81c56e:	movss  0x8c(%rdi),%xmm3
  81c576:	movss  -0x76d562(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c57e:	movaps %xmm3,%xmm1
  81c581:	subss  %xmm0,%xmm1
  81c585:	cvttss2si %xmm1,%rax
  81c58a:	cvttss2si %xmm3,%r8
  81c58f:	mov    %r8,%rcx
  81c592:	sar    $0x3f,%rcx
  81c596:	and    %rax,%rcx
  81c599:	or     %r8,%rcx
  81c59c:	xor    %r9d,%r9d
  81c59f:	xorps  %xmm1,%xmm1
  81c5a2:	ucomiss %xmm1,%xmm3
  81c5a5:	cmovb  %r9,%rcx
  81c5a9:	movss  -0x76d591(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c5b1:	ucomiss %xmm2,%xmm3
  81c5b4:	mov    $0xffffffffffffffff,%rax
  81c5bb:	cmova  %rax,%rcx
  81c5bf:	movss  0x94(%rdi),%xmm3
  81c5c7:	mov    %rcx,%r8
  81c5ca:	shr    $0x4,%r8
  81c5ce:	movaps %xmm3,%xmm4
  81c5d1:	subss  %xmm0,%xmm4
  81c5d5:	cvttss2si %xmm4,%r10
  81c5da:	cvttss2si %xmm3,%r11
  81c5df:	mov    %r11,%rbx
  81c5e2:	sar    $0x3f,%rbx
  81c5e6:	and    %r10,%rbx
  81c5e9:	or     %r11,%rbx
  81c5ec:	ucomiss %xmm1,%xmm3
  81c5ef:	cmovb  %r9,%rbx
  81c5f3:	ucomiss %xmm2,%xmm3
  81c5f6:	cmova  %rax,%rbx
  81c5fa:	mov    %rsi,0x18(%rsp)
  81c5ff:	lea    (%rcx,%rbx,1),%r11
  81c603:	dec    %r11
  81c606:	shr    $0x4,%r11
  81c60a:	cmp    %r11,%r8
  81c60d:	jbe    81c61e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c60f:	add    $0x28,%rsp
  81c613:	pop    %rbx
  81c614:	pop    %r12
  81c616:	pop    %r13
  81c618:	pop    %r14
  81c61a:	pop    %r15
  81c61c:	pop    %rbp
  81c61d:	ret
  81c61e:	movss  0x88(%rdi),%xmm3
  81c626:	movaps %xmm3,%xmm4
  81c629:	subss  %xmm0,%xmm4
  81c62d:	cvttss2si %xmm4,%rsi
  81c632:	cvttss2si %xmm3,%r9
  81c637:	mov    %r9,%rcx
  81c63a:	sar    $0x3f,%rcx
  81c63e:	and    %rsi,%rcx
  81c641:	or     %r9,%rcx
  81c644:	xor    %r10d,%r10d
  81c647:	ucomiss %xmm1,%xmm3
  81c64a:	cmovb  %r10,%rcx
  81c64e:	ucomiss %xmm2,%xmm3
  81c651:	cmova  %rax,%rcx
  81c655:	movss  0x90(%rdi),%xmm3
  81c65d:	mov    %rcx,%r14
  81c660:	shr    $0x4,%r14
  81c664:	movaps %xmm3,%xmm4
  81c667:	subss  %xmm0,%xmm4
  81c66b:	cvttss2si %xmm4,%rsi
  81c670:	cvttss2si %xmm3,%rdi
  81c675:	mov    %rdi,%r9
  81c678:	sar    $0x3f,%r9
  81c67c:	and    %rsi,%r9
  81c67f:	or     %rdi,%r9
  81c682:	ucomiss %xmm1,%xmm3
  81c685:	cmovb  %r10,%r9
  81c689:	ucomiss %xmm2,%xmm3
  81c68c:	cmova  %rax,%r9
  81c690:	lea    (%r9,%rcx,1),%rbx
  81c694:	dec    %rbx
  81c697:	shr    $0x4,%rbx
  81c69b:	mov    %r14,0x10(%rsp)
  81c6a0:	cmp    %rbx,%r14
  81c6a3:	jbe    81c6cd <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c6a5:	data16 cs nopw 0x0(%rax,%rax,1)
  81c6b0:	mov    %r8,%rax
  81c6b3:	cmp    %r11,%r8
  81c6b6:	adc    $0x0,%r8
  81c6ba:	cmp    %r11,%rax
  81c6bd:	jae    81c60f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c6c3:	cmp    %r11,%r8
  81c6c6:	jbe    81c6b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c6c8:	jmp    81c60f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c6cd:	mov    (%rdx),%r14
  81c6d0:	mov    0x8(%rdx),%r15
  81c6d4:	mov    0x10(%rdx),%r12
  81c6d8:	mov    0x18(%rdx),%r13
  81c6dc:	mov    0x20(%rdx),%rdx
  81c6e0:	mov    %r11,0x8(%rsp)
  81c6e5:	data16 cs nopw 0x0(%rax,%rax,1)
  81c6f0:	mov    %r8,%rbp
  81c6f3:	cmp    %r11,%r8
  81c6f6:	adc    $0x0,%r8
  81c6fa:	mov    %rbp,0x20(%rsp)
  81c6ff:	imul   0x18(%rsp),%rbp
  81c705:	mov    0x10(%rsp),%r9
  81c70a:	mov    %r9,%rsi
  81c70d:	nopl   (%rax)
  81c710:	cmp    %rbx,%r9
  81c713:	adc    $0x0,%rsi
  81c717:	lea    (%r9,%rbp,1),%rdi
  81c71b:	mov    0x10(%r14),%rax
  81c71f:	cmp    %rax,%rdi
  81c722:	jae    81c790 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c724:	mov    0x8(%r14),%rcx
  81c728:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c72d:	jo     81c765 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c72f:	mov    0x10(%r12),%rax
  81c734:	cmp    %rax,%rdi
  81c737:	jae    81c7a0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c739:	mov    0x8(%r12),%rax
  81c73e:	mov    0x0(%r13),%r11d
  81c742:	inc    %r11d
  81c745:	cmp    (%rax,%rdi,4),%r11d
  81c749:	jb     81c765 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c74b:	mov    (%rcx,%rdi,8),%eax
  81c74e:	dec    %eax
  81c750:	mov    %eax,(%rcx,%rdi,8)
  81c753:	mov    0x10(%r15),%rcx
  81c757:	cmp    %rax,%rcx
  81c75a:	jbe    81c7b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c75c:	mov    0x8(%r15),%rcx
  81c760:	mov    (%rdx),%edi
  81c762:	mov    %edi,(%rcx,%rax,4)
  81c765:	cmp    %rbx,%r9
  81c768:	jae    81c772 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c76a:	mov    %rsi,%r9
  81c76d:	cmp    %rbx,%rsi
  81c770:	jbe    81c710 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c772:	mov    0x8(%rsp),%r11
  81c777:	cmp    %r11,0x20(%rsp)
  81c77c:	jae    81c60f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c782:	cmp    %r11,%r8
  81c785:	jbe    81c6f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c78b:	jmp    81c60f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c790:	lea    0x612fc9(%rip),%rdx        # e2f760 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0xa8>
  81c797:	mov    %rax,%rsi
  81c79a:	call   *0x6649e8(%rip)        # e81188 <_DYNAMIC+0x4f8>
  81c7a0:	lea    0x612fd1(%rip),%rdx        # e2f778 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0xc0>
  81c7a7:	mov    %rax,%rsi
  81c7aa:	call   *0x6649d8(%rip)        # e81188 <_DYNAMIC+0x4f8>
  81c7b0:	lea    0x612fd9(%rip),%rdx        # e2f790 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0xd8>
  81c7b7:	mov    %rax,%rdi
  81c7ba:	mov    %rcx,%rsi
  81c7bd:	call   *0x6649c5(%rip)        # e81188 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}> bytes=235 frame=248

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c7d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>:
  81c7d0:	push   %rbp
  81c7d1:	push   %r15
  81c7d3:	push   %r14
  81c7d5:	push   %r13
  81c7d7:	push   %r12
  81c7d9:	push   %rbx
  81c7da:	sub    $0xc8,%rsp
  81c7e1:	mov    %esi,%ebp
  81c7e3:	mov    %rdi,%rbx
  81c7e6:	lea    0x8(%rsp),%rdi
  81c7eb:	mov    %rbx,%rsi
  81c7ee:	call   *0x664a54(%rip)        # e81248 <_DYNAMIC+0x5b8>
  81c7f4:	mov    0x8(%rsp),%rsi
  81c7f9:	xor    %r14d,%r14d
  81c7fc:	test   $0x1,%bpl
  81c800:	je     81c878 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xa8>
  81c802:	test   %rsi,%rsi
  81c805:	je     81c8a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c80b:	mov    $0x1,%r13d
  81c811:	lea    0x8(%rsp),%r12
  81c816:	mov    0x664a2b(%rip),%rbp        # e81248 <_DYNAMIC+0x5b8>
  81c81d:	jmp    81c835 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x65>
  81c81f:	nop
  81c820:	add    %r15,%r14
  81c823:	mov    %r12,%rdi
  81c826:	mov    %rbx,%rsi
  81c829:	call   *%rbp
  81c82b:	mov    0x8(%rsp),%rsi
  81c830:	test   %rsi,%rsi
  81c833:	je     81c8a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c835:	mov    0x18(%rsp),%r15
  81c83a:	cmp    $0x2,%r15
  81c83e:	jb     81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c840:	mov    0x10(%rsp),%rax
  81c845:	mov    (%rax),%edx
  81c847:	lea    0x70(%rsp),%rdi
  81c84c:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c851:	movss  0x74(%rsp),%xmm0
  81c857:	xorps  %xmm1,%xmm1
  81c85a:	ucomiss %xmm1,%xmm0
  81c85d:	mov    $0x1,%eax
  81c862:	cmovne %r15,%rax
  81c866:	cmovp  %r15,%rax
  81c86a:	cmpb   $0x3,0x70(%rsp)
  81c86f:	cmovne %r13,%rax
  81c873:	mov    %rax,%r15
  81c876:	jmp    81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c878:	test   %rsi,%rsi
  81c87b:	je     81c8a6 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c87d:	lea    0x8(%rsp),%r15
  81c882:	mov    0x6649bf(%rip),%r12        # e81248 <_DYNAMIC+0x5b8>
  81c889:	nopl   0x0(%rax)
  81c890:	add    0x18(%rsp),%r14
  81c895:	mov    %r15,%rdi
  81c898:	mov    %rbx,%rsi
  81c89b:	call   *%r12
  81c89e:	cmpq   $0x0,0x8(%rsp)
  81c8a4:	jne    81c890 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xc0>
  81c8a6:	mov    %r14,%rax
  81c8a9:	add    $0xc8,%rsp
  81c8b0:	pop    %rbx
  81c8b1:	pop    %r12
  81c8b3:	pop    %r13
  81c8b5:	pop    %r14
  81c8b7:	pop    %r15
  81c8b9:	pop    %rbp
  81c8ba:	ret

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb00 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81cb00:	push   %rbp
  81cb01:	push   %r14
  81cb03:	push   %rbx
  81cb04:	cmp    0x341(%rdi),%sil
  81cb0b:	je     81cb4b <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81cb0d:	mov    0x330(%rdi),%rax
  81cb14:	test   %rax,%rax
  81cb17:	je     81cb39 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cb19:	lock decq (%rax)
  81cb1d:	jne    81cb39 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cb1f:	lea    0x330(%rdi),%rbx
  81cb26:	mov    %rdi,%r14
  81cb29:	mov    %rbx,%rdi
  81cb2c:	mov    %esi,%ebp
  81cb2e:	call   *0x664674(%rip)        # e811a8 <_DYNAMIC+0x518>
  81cb34:	mov    %r14,%rdi
  81cb37:	mov    %ebp,%esi
  81cb39:	movq   $0x0,0x330(%rdi)
  81cb44:	mov    %sil,0x341(%rdi)
  81cb4b:	pop    %rbx
  81cb4c:	pop    %r14
  81cb4e:	pop    %rbp
  81cb4f:	ret
  81cb50:	movq   $0x0,(%rbx)
  81cb57:	mov    %rax,%rdi
  81cb5a:	call   e2d9a0 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Changes>::upload bytes=83 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb60 <<gpui_gpu::renderer::Changes>::upload>:
  81cb60:	push   %rbx
  81cb61:	mov    %rsi,%rbx
  81cb64:	sub    %rdi,%rbx
  81cb67:	jbe    81cb96 <<gpui_gpu::renderer::Changes>::upload+0x36>
  81cb69:	mov    %rdx,%rax
  81cb6c:	mov    %rdi,%rdx
  81cb6f:	cmp    %rcx,%rsi
  81cb72:	ja     81cb9d <<gpui_gpu::renderer::Changes>::upload+0x3d>
  81cb74:	shl    $0x4,%rdx
  81cb78:	add    %rdx,%rax
  81cb7b:	shl    $0x4,%rbx
  81cb7f:	mov    %r9,%rdi
  81cb82:	mov    %r8,%rsi
  81cb85:	mov    %rax,%rcx
  81cb88:	mov    %rbx,%r8
  81cb8b:	call   *0x6646cf(%rip)        # e81260 <_DYNAMIC+0x5d0>
  81cb91:	mov    %rbx,%rax
  81cb94:	pop    %rbx
  81cb95:	ret
  81cb96:	xor    %ebx,%ebx
  81cb98:	mov    %rbx,%rax
  81cb9b:	pop    %rbx
  81cb9c:	ret
  81cb9d:	lea    0x612c64(%rip),%rax        # e2f808 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x150>
  81cba4:	mov    %rdx,%rdi
  81cba7:	mov    %rcx,%rdx
  81cbaa:	mov    %rax,%rcx
  81cbad:	call   *0x664625(%rip)        # e811d8 <_DYNAMIC+0x548>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=76 frame=40

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cbc0 <<gpui_gpu::renderer::Buffer>::write>:
  81cbc0:	push   %r15
  81cbc2:	push   %r14
  81cbc4:	push   %r12
  81cbc6:	push   %rbx
  81cbc7:	push   %rax
  81cbc8:	mov    %r8,%r12
  81cbcb:	mov    %rcx,%rbx
  81cbce:	mov    %rdx,%r14
  81cbd1:	mov    %rdi,%r15
  81cbd4:	mov    %r8,%rdx
  81cbd7:	call   81cc10 <<gpui_gpu::renderer::Buffer>::reserve>
  81cbdc:	test   %r12,%r12
  81cbdf:	je     81cc00 <<gpui_gpu::renderer::Buffer>::write+0x40>
  81cbe1:	mov    %r14,%rdi
  81cbe4:	mov    %r15,%rsi
  81cbe7:	xor    %edx,%edx
  81cbe9:	mov    %rbx,%rcx
  81cbec:	mov    %r12,%r8
  81cbef:	add    $0x8,%rsp
  81cbf3:	pop    %rbx
  81cbf4:	pop    %r12
  81cbf6:	pop    %r14
  81cbf8:	pop    %r15
  81cbfa:	jmp    *0x664660(%rip)        # e81260 <_DYNAMIC+0x5d0>
  81cc00:	add    $0x8,%rsp
  81cc04:	pop    %rbx
  81cc05:	pop    %r12
  81cc07:	pop    %r14
  81cc09:	pop    %r15
  81cc0b:	ret

FUNCTION <gpui_gpu::renderer::Buffer>::reserve bytes=271 frame=104

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc10 <<gpui_gpu::renderer::Buffer>::reserve>:
  81cc10:	push   %r15
  81cc12:	push   %r14
  81cc14:	push   %r12
  81cc16:	push   %rbx
  81cc17:	sub    $0x48,%rsp
  81cc1b:	mov    %rdx,%r14
  81cc1e:	mov    0x20(%rdi),%r15
  81cc22:	cmp    %r15,%rdx
  81cc25:	jbe    81ccca <<gpui_gpu::renderer::Buffer>::reserve+0xba>
  81cc2b:	mov    %rdi,%rbx
  81cc2e:	mov    $0x1,%r12d
  81cc34:	cmp    $0x2,%r14
  81cc38:	jb     81cc51 <<gpui_gpu::renderer::Buffer>::reserve+0x41>
  81cc3a:	lea    -0x1(%r14),%rax
  81cc3e:	bsr    %rax,%rcx
  81cc42:	not    %ecx
  81cc44:	mov    $0xffffffffffffffff,%r12
  81cc4b:	shr    %cl,%r12
  81cc4e:	inc    %r12
  81cc51:	lea    -0x748078(%rip),%rax        # d4be0 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x142>
  81cc58:	mov    %rax,0x28(%rsp)
  81cc5d:	movq   $0xa,0x30(%rsp)
  81cc66:	mov    %r12,0x38(%rsp)
  81cc6b:	movl   $0x88,0x40(%rsp)
  81cc73:	movb   $0x0,0x44(%rsp)
  81cc78:	mov    %rsp,%rdi
  81cc7b:	lea    0x28(%rsp),%rdx
  81cc80:	call   *0x66462a(%rip)        # e812b0 <_DYNAMIC+0x620>
  81cc86:	mov    %r12,0x20(%rsp)
  81cc8b:	mov    (%rbx),%rax
  81cc8e:	lock decq (%rax)
  81cc92:	jne    81cc9d <<gpui_gpu::renderer::Buffer>::reserve+0x8d>
  81cc94:	mov    %rbx,%rdi
  81cc97:	call   *0x6644fb(%rip)        # e81198 <_DYNAMIC+0x508>
  81cc9d:	mov    0x8(%rbx),%rax
  81cca1:	lock decq (%rax)
  81cca5:	jne    81ccb1 <<gpui_gpu::renderer::Buffer>::reserve+0xa1>
  81cca7:	lea    0x8(%rbx),%rdi
  81ccab:	call   *0x6644ef(%rip)        # e811a0 <_DYNAMIC+0x510>
  81ccb1:	mov    0x20(%rsp),%rax
  81ccb6:	mov    %rax,0x20(%rbx)
  81ccba:	movups (%rsp),%xmm0
  81ccbe:	movups 0x10(%rsp),%xmm1
  81ccc3:	movups %xmm1,0x10(%rbx)
  81ccc7:	movups %xmm0,(%rbx)
  81ccca:	cmp    %r15,%r14
  81cccd:	seta   %al
  81ccd0:	add    $0x48,%rsp
  81ccd4:	pop    %rbx
  81ccd5:	pop    %r12
  81ccd7:	pop    %r14
  81ccd9:	pop    %r15
  81ccdb:	ret
  81ccdc:	mov    %rax,%r14
  81ccdf:	jmp    81ccf8 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81cce1:	mov    %rax,%r14
  81cce4:	mov    0x8(%rbx),%rax
  81cce8:	lock decq (%rax)
  81ccec:	jne    81ccf8 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81ccee:	lea    0x8(%rbx),%rdi
  81ccf2:	call   *0x6644a8(%rip)        # e811a0 <_DYNAMIC+0x510>
  81ccf8:	mov    0x20(%rsp),%rax
  81ccfd:	mov    %rax,0x20(%rbx)
  81cd01:	movups (%rsp),%xmm0
  81cd05:	movups 0x10(%rsp),%xmm1
  81cd0a:	movups %xmm1,0x10(%rbx)
  81cd0e:	movups %xmm0,(%rbx)
  81cd11:	mov    %r14,%rdi
  81cd14:	call   e2d9a0 <_Unwind_Resume@plt>
  81cd19:	call   *0x6641c1(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cd20 <<gpui_gpu::renderer::Atlas>::new>:
  81cd20:	push   %rbp
  81cd21:	push   %r14
  81cd23:	push   %rbx
  81cd24:	sub    $0x160,%rsp
  81cd2b:	mov    %edx,%ebp
  81cd2d:	mov    %rdi,%rbx
  81cd30:	lea    -0x74814d(%rip),%rax        # d4bea <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x14c>
  81cd37:	mov    %rax,(%rsp)
  81cd3b:	movq   $0xe,0x8(%rsp)
  81cd44:	mov    %edx,0x10(%rsp)
  81cd48:	mov    %edx,0x14(%rsp)
  81cd4c:	movaps -0x7707e3(%rip),%xmm0        # ac570 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81cd53:	movups %xmm0,0x18(%rsp)
  81cd58:	movl   $0x0,0x28(%rsp)
  81cd60:	movl   $0x6,0x34(%rsp)
  81cd68:	movq   $0x4,0x38(%rsp)
  81cd71:	movq   $0x0,0x40(%rsp)
  81cd7a:	lea    0x110(%rsp),%r14
  81cd82:	mov    %rsp,%rdx
  81cd85:	mov    %r14,%rdi
  81cd88:	call   *0x6643a2(%rip)        # e81130 <_DYNAMIC+0x4a0>
  81cd8e:	movq   $0x0,0x18(%rsp)
  81cd97:	movl   $0xffffffff,0x30(%rsp)
  81cd9f:	movl   $0x0,(%rsp)
  81cda6:	movabs $0xffffffff00000000,%rax
  81cdb0:	mov    %rax,0x28(%rsp)
  81cdb5:	movq   $0x0,0x3c(%rsp)
  81cdbe:	movl   $0x0,0x8(%rsp)
  81cdc6:	movl   $0x0,0x10(%rsp)
  81cdce:	lea    0xb8(%rsp),%rdi
  81cdd6:	mov    %rsp,%rdx
  81cdd9:	mov    %r14,%rsi
  81cddc:	call   *0x664356(%rip)        # e81138 <_DYNAMIC+0x4a8>
  81cde2:	movups 0x150(%rsp),%xmm0
  81cdea:	movaps %xmm0,0xa0(%rsp)
  81cdf2:	movups 0x110(%rsp),%xmm0
  81cdfa:	movups 0x120(%rsp),%xmm1
  81ce02:	movups 0x130(%rsp),%xmm2
  81ce0a:	movups 0x140(%rsp),%xmm3
  81ce12:	movaps %xmm3,0x90(%rsp)
  81ce1a:	movaps %xmm2,0x80(%rsp)
  81ce22:	movaps %xmm1,0x70(%rsp)
  81ce27:	movaps %xmm0,0x60(%rsp)
  81ce2c:	mov    0x108(%rsp),%rax
  81ce34:	mov    %rax,0x50(%rsp)
  81ce39:	movups 0xf8(%rsp),%xmm0
  81ce41:	movaps %xmm0,0x40(%rsp)
  81ce46:	movups 0xb8(%rsp),%xmm0
  81ce4e:	movups 0xc8(%rsp),%xmm1
  81ce56:	movups 0xd8(%rsp),%xmm2
  81ce5e:	movups 0xe8(%rsp),%xmm3
  81ce66:	movaps %xmm3,0x30(%rsp)
  81ce6b:	movaps %xmm2,0x20(%rsp)
  81ce70:	movaps %xmm1,0x10(%rsp)
  81ce75:	movaps %xmm0,(%rsp)
  81ce79:	mov    %fs:0x0,%rax
  81ce82:	lea    -0x28(%rax),%rax
  81ce89:	mov    %rax,%r14
  81ce8c:	cmpb   $0x1,0x10(%rax)
  81ce90:	jne    81cf7b <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81ce96:	mov    (%r14),%rax
  81ce99:	mov    0x8(%r14),%rdx
  81ce9d:	lea    0x1(%rax),%rcx
  81cea1:	mov    %rcx,(%r14)
  81cea4:	movaps 0xa0(%rsp),%xmm0
  81ceac:	movups %xmm0,0x40(%rbx)
  81ceb0:	movaps 0x60(%rsp),%xmm0
  81ceb5:	movaps 0x70(%rsp),%xmm1
  81ceba:	movaps 0x80(%rsp),%xmm2
  81cec2:	movaps 0x90(%rsp),%xmm3
  81ceca:	movups %xmm3,0x30(%rbx)
  81cece:	movups %xmm2,0x20(%rbx)
  81ced2:	movups %xmm1,0x10(%rbx)
  81ced6:	movups %xmm0,(%rbx)
  81ced9:	movups 0xb8(%rsp),%xmm0
  81cee1:	movups 0xc8(%rsp),%xmm1
  81cee9:	movups 0xd8(%rsp),%xmm2
  81cef1:	movups 0xe8(%rsp),%xmm3
  81cef9:	movups %xmm0,0x50(%rbx)
  81cefd:	movups %xmm1,0x60(%rbx)
  81cf01:	movups %xmm2,0x70(%rbx)
  81cf05:	movups %xmm3,0x80(%rbx)
  81cf0c:	movups 0xf8(%rsp),%xmm0
  81cf14:	movups %xmm0,0x90(%rbx)
  81cf1b:	mov    0x108(%rsp),%rcx
  81cf23:	mov    %rcx,0xa0(%rbx)
  81cf2a:	mov    %ebp,0xd8(%rbx)
  81cf30:	movq   $0x0,0xdc(%rbx)
  81cf3b:	movl   $0x0,0xe4(%rbx)
  81cf45:	movups 0x612964(%rip),%xmm0        # e2f8b0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x1f8>
  81cf4c:	movups %xmm0,0xa8(%rbx)
  81cf53:	movups 0x612966(%rip),%xmm0        # e2f8c0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x208>
  81cf5a:	movups %xmm0,0xb8(%rbx)
  81cf61:	mov    %rax,0xc8(%rbx)
  81cf68:	mov    %rdx,0xd0(%rbx)
  81cf6f:	add    $0x160,%rsp
  81cf76:	pop    %rbx
  81cf77:	pop    %r14
  81cf79:	pop    %rbp
  81cf7a:	ret
  81cf7b:	call   *0x664337(%rip)        # e812b8 <_DYNAMIC+0x628>
  81cf81:	mov    %rax,(%r14)
  81cf84:	mov    %rdx,0x8(%r14)
  81cf88:	movb   $0x1,0x10(%r14)
  81cf8d:	jmp    81ce9d <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cf92:	mov    %rax,%rbx
  81cf95:	mov    %rsp,%rdi
  81cf98:	call   81c430 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cf9d:	mov    0x60(%rsp),%rax
  81cfa2:	lock decq (%rax)
  81cfa6:	jne    81cfd4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfa8:	lea    0x60(%rsp),%rdi
  81cfad:	call   *0x6641c5(%rip)        # e81178 <_DYNAMIC+0x4e8>
  81cfb3:	jmp    81cfd4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfb5:	mov    %rax,%rbx
  81cfb8:	mov    0x110(%rsp),%rax
  81cfc0:	lock decq (%rax)
  81cfc4:	jne    81cfd4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfc6:	lea    0x110(%rsp),%rdi
  81cfce:	call   *0x6641a4(%rip)        # e81178 <_DYNAMIC+0x4e8>
  81cfd4:	mov    %rbx,%rdi
  81cfd7:	call   e2d9a0 <_Unwind_Resume@plt>
  81cfdc:	call   *0x663efe(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cff0 <<gpui_gpu::renderer::Atlas>::insert>:
  81cff0:	push   %rbp
  81cff1:	push   %r15
  81cff3:	push   %r14
  81cff5:	push   %r13
  81cff7:	push   %r12
  81cff9:	push   %rbx
  81cffa:	sub    $0x68,%rsp
  81cffe:	mov    %rdx,%r12
  81d001:	mov    %rsi,%r15
  81d004:	mov    %rdi,%r14
  81d007:	lea    0x10(%rdx),%r13
  81d00b:	cmpq   $0x0,0xc0(%rdi)
  81d013:	je     81d0db <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d019:	lea    0xc8(%r14),%rdi
  81d020:	mov    %r13,%rsi
  81d023:	call   825110 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81d028:	mov    %rax,%rsi
  81d02b:	shr    $0x39,%rsi
  81d02f:	mov    0xa8(%r14),%rcx
  81d036:	mov    0xb0(%r14),%rdx
  81d03d:	movd   %esi,%xmm0
  81d041:	punpcklbw %xmm0,%xmm0
  81d045:	pshuflw $0x0,%xmm0,%xmm0
  81d04a:	pshufd $0x44,%xmm0,%xmm0
  81d04f:	mov    0x10(%r12),%rsi
  81d054:	movzwl 0x1c(%r12),%edi
  81d05a:	mov    0x18(%r12),%r8d
  81d05f:	pcmpeqd %xmm1,%xmm1
  81d063:	xor    %r9d,%r9d
  81d066:	and    %rdx,%rax
  81d069:	movdqu (%rcx,%rax,1),%xmm2
  81d06e:	movdqa %xmm2,%xmm3
  81d072:	pcmpeqb %xmm0,%xmm3
  81d076:	pmovmskb %xmm3,%r10d
  81d07b:	test   %r10d,%r10d
  81d07e:	je     81d0c0 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81d080:	tzcnt  %r10d,%ebx
  81d085:	add    %rax,%rbx
  81d088:	and    %rdx,%rbx
  81d08b:	shl    $0x5,%rbx
  81d08f:	mov    %rcx,%r11
  81d092:	sub    %rbx,%r11
  81d095:	cmp    -0x20(%r11),%rsi
  81d099:	jne    81d0ac <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d09b:	cmp    -0x14(%r11),%di
  81d0a0:	jne    81d0ac <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d0a2:	cmp    -0x18(%r11),%r8d
  81d0a6:	je     81d143 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d0ac:	lea    -0x1(%r10),%r11d
  81d0b0:	and    %r10w,%r11w
  81d0b4:	mov    %r11d,%r10d
  81d0b7:	jne    81d080 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d0b9:	nopl   0x0(%rax)
  81d0c0:	pcmpeqb %xmm1,%xmm2
  81d0c4:	pmovmskb %xmm2,%r10d
  81d0c9:	test   %r10d,%r10d
  81d0cc:	jne    81d0db <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d0ce:	add    %r9,%rax
  81d0d1:	add    $0x10,%rax
  81d0d5:	add    $0x10,%r9
  81d0d9:	jmp    81d066 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d0db:	mov    0x20(%r12),%ebp
  81d0e0:	xor    %eax,%eax
  81d0e2:	test   %ebp,%ebp
  81d0e4:	je     81d13e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d0e6:	mov    %r15,%rdi
  81d0e9:	mov    0x28(%r12),%r15d
  81d0ee:	test   %r15d,%r15d
  81d0f1:	je     81d13e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d0f3:	mov    0xd8(%r14),%ecx
  81d0fa:	cmp    %ebp,%ecx
  81d0fc:	jb     81d241 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d102:	cmp    %r15d,%ecx
  81d105:	jb     81d241 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d10b:	mov    %r13,0x40(%rsp)
  81d110:	mov    0xdc(%r14),%r8d
  81d117:	mov    0xe4(%r14),%r13d
  81d11e:	lea    (%r8,%rbp,1),%edx
  81d122:	xor    %eax,%eax
  81d124:	cmp    %ecx,%edx
  81d126:	mov    $0x0,%ebx
  81d12b:	cmova  %r13d,%ebx
  81d12f:	add    0xe0(%r14),%ebx
  81d136:	lea    (%rbx,%r15,1),%esi
  81d13a:	cmp    %ecx,%esi
  81d13c:	jbe    81d14f <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d13e:	jmp    81d241 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d143:	mov    $0x1,%eax
  81d148:	xor    %edx,%edx
  81d14a:	jmp    81d241 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d14f:	cmp    %r13d,%r15d
  81d152:	cmova  %r15d,%r13d
  81d156:	cmp    %ecx,%edx
  81d158:	cmova  %eax,%r8d
  81d15c:	lea    0xa8(%r14),%rax
  81d163:	mov    %rax,0x38(%rsp)
  81d168:	mov    %r14,0x48(%rsp)
  81d16d:	movl   $0x0,0x50(%rsp)
  81d175:	mov    %r8d,0x54(%rsp)
  81d17a:	mov    %ebx,0x58(%rsp)
  81d17e:	movq   $0x0,0x5c(%rsp)
  81d187:	mov    (%r12),%rdx
  81d18b:	mov    0x8(%r12),%rcx
  81d190:	mov    %rcx,0x30(%rsp)
  81d195:	movq   $0x0,0x8(%rsp)
  81d19e:	movl   $0x1,0x10(%rsp)
  81d1a6:	mov    %ebp,0x14(%rsp)
  81d1aa:	movl   $0x1,0x18(%rsp)
  81d1b2:	mov    %r15d,0x1c(%rsp)
  81d1b7:	mov    %ebp,0x20(%rsp)
  81d1bb:	mov    %r15d,0x24(%rsp)
  81d1c0:	movl   $0x1,0x28(%rsp)
  81d1c8:	cmova  %r15d,%r13d
  81d1cc:	lea    0x48(%rsp),%rsi
  81d1d1:	mov    %r8,%r12
  81d1d4:	lea    0x8(%rsp),%r8
  81d1d9:	lea    0x20(%rsp),%r9
  81d1de:	call   *0x6640dc(%rip)        # e812c0 <_DYNAMIC+0x630>
  81d1e4:	lea    (%r12,%rbp,1),%eax
  81d1e8:	mov    %eax,0xdc(%r14)
  81d1ef:	mov    %ebx,0xe0(%r14)
  81d1f6:	mov    %r13d,0xe4(%r14)
  81d1fd:	mov    0x40(%rsp),%rax
  81d202:	movdqu (%rax),%xmm0
  81d206:	movdqa %xmm0,0x20(%rsp)
  81d20c:	mov    %r12d,0x8(%rsp)
  81d211:	mov    %ebx,0xc(%rsp)
  81d215:	mov    %ebp,0x10(%rsp)
  81d219:	mov    %r15d,0x14(%rsp)
  81d21e:	lea    0x48(%rsp),%rdi
  81d223:	lea    0x20(%rsp),%rdx
  81d228:	lea    0x8(%rsp),%rcx
  81d22d:	mov    0x38(%rsp),%rsi
  81d232:	call   826d90 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d237:	mov    0x30(%rsp),%rdx
  81d23c:	mov    $0x1,%eax
  81d241:	add    $0x68,%rsp
  81d245:	pop    %rbx
  81d246:	pop    %r12
  81d248:	pop    %r13
  81d24a:	pop    %r14
  81d24c:	pop    %r15
  81d24e:	pop    %rbp
  81d24f:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d250 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d250:	push   %r15
  81d252:	push   %r14
  81d254:	push   %r12
  81d256:	push   %rbx
  81d257:	sub    $0x548,%rsp
  81d25e:	mov    %rdx,%r14
  81d261:	mov    %rsi,%r12
  81d264:	mov    %rdi,%rbx
  81d267:	lea    0x612662(%rip),%rdx        # e2f8d0 <anon.7e34a6dced7fe4eb77116889a7de5f31.33.llvm.15614097268772730318>
  81d26e:	lea    0x30(%rsp),%r15
  81d273:	mov    %r15,%rdi
  81d276:	mov    %rbx,%rsi
  81d279:	call   *0x664049(%rip)        # e812c8 <_DYNAMIC+0x638>
  81d27f:	xorps  %xmm0,%xmm0
  81d282:	movups %xmm0,0x10(%rsp)
  81d287:	movups %xmm0,0x20(%rsp)
  81d28c:	movl   $0x0,0x50(%rsp)
  81d294:	movb   $0x0,0x58(%rsp)
  81d299:	movups 0x9(%rsp),%xmm0
  81d29e:	movups %xmm0,0x59(%rsp)
  81d2a3:	movups 0x19(%rsp),%xmm0
  81d2a8:	movups %xmm0,0x69(%rsp)
  81d2ad:	mov    0x28(%rsp),%rax
  81d2b2:	mov    %rax,0x78(%rsp)
  81d2b7:	movl   $0x0,0x80(%rsp)
  81d2c2:	mov    %r12,0x88(%rsp)
  81d2ca:	movq   $0x0,0x90(%rsp)
  81d2d6:	lea    -0x7486e5(%rip),%rax        # d4bf8 <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.15614097268772730318>
  81d2dd:	mov    %rax,0xe0(%rsp)
  81d2e5:	movq   $0xa,0xe8(%rsp)
  81d2f1:	lea    0x50(%rsp),%rax
  81d2f6:	mov    %rax,0xd0(%rsp)
  81d2fe:	movq   $0x1,0xd8(%rsp)
  81d30a:	movl   $0xffffffff,0xb8(%rsp)
  81d315:	movl   $0x2,0x98(%rsp)
  81d320:	movq   $0x0,0xf0(%rsp)
  81d32c:	movl   $0x0,0xf8(%rsp)
  81d337:	lea    0x100(%rsp),%rdi
  81d33f:	lea    0x98(%rsp),%rdx
  81d347:	mov    %r15,%rsi
  81d34a:	call   *0x663f80(%rip)        # e812d0 <_DYNAMIC+0x640>
  81d350:	lea    0x10(%rbx),%rsi
  81d354:	lea    0x100(%rsp),%rdi
  81d35c:	call   *0x663f76(%rip)        # e812d8 <_DYNAMIC+0x648>
  81d362:	lea    0x100(%rsp),%rdi
  81d36a:	mov    $0x4,%ecx
  81d36f:	xor    %esi,%esi
  81d371:	mov    %r14,%rdx
  81d374:	xor    %r8d,%r8d
  81d377:	call   *0x663f63(%rip)        # e812e0 <_DYNAMIC+0x650>
  81d37d:	lea    0x100(%rsp),%rdi
  81d385:	xor    %esi,%esi
  81d387:	mov    $0x3,%edx
  81d38c:	xor    %ecx,%ecx
  81d38e:	mov    $0x1,%r8d
  81d394:	call   *0x663f4e(%rip)        # e812e8 <_DYNAMIC+0x658>
  81d39a:	lea    0x100(%rsp),%rdi
  81d3a2:	call   81c330 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d3a7:	movups 0x30(%rsp),%xmm0
  81d3ac:	movups 0x40(%rsp),%xmm1
  81d3b1:	movaps %xmm1,0x110(%rsp)
  81d3b9:	movaps %xmm0,0x100(%rsp)
  81d3c1:	lea    0x98(%rsp),%r14
  81d3c9:	lea    0x100(%rsp),%rsi
  81d3d1:	mov    %r14,%rdi
  81d3d4:	call   *0x663f16(%rip)        # e812f0 <_DYNAMIC+0x660>
  81d3da:	add    $0x8,%rbx
  81d3de:	mov    %rbx,%rdi
  81d3e1:	mov    %r14,%rsi
  81d3e4:	call   8267b0 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d3e9:	add    $0x548,%rsp
  81d3f0:	pop    %rbx
  81d3f1:	pop    %r12
  81d3f3:	pop    %r14
  81d3f5:	pop    %r15
  81d3f7:	ret
  81d3f8:	mov    %rax,%rbx
  81d3fb:	jmp    81d40d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d3fd:	mov    %rax,%rbx
  81d400:	lea    0x100(%rsp),%rdi
  81d408:	call   81c330 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d40d:	lea    0x30(%rsp),%rdi
  81d412:	call   81c4a0 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d417:	mov    %rbx,%rdi
  81d41a:	call   e2d9a0 <_Unwind_Resume@plt>
  81d41f:	call   *0x663abb(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d430 <<gpui_gpu::renderer::RendererState>::correction>:
  81d430:	push   %r15
  81d432:	push   %r14
  81d434:	push   %r13
  81d436:	push   %r12
  81d438:	push   %rbx
  81d439:	sub    $0x90,%rsp
  81d440:	mov    %rdi,%rbx
  81d443:	movss  (%rdx),%xmm1
  81d447:	movss  0x8(%rdx),%xmm2
  81d44c:	movaps %xmm1,%xmm0
  81d44f:	addss  %xmm2,%xmm0
  81d453:	movd   %xmm0,%eax
  81d457:	and    $0x7fffffff,%eax
  81d45c:	xorps  %xmm8,%xmm8
  81d460:	xorps  %xmm9,%xmm9
  81d464:	cmp    $0x7f7fffff,%eax
  81d469:	jg     81d488 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d46b:	cvtss2sd %xmm1,%xmm1
  81d46f:	cvtss2sd %xmm2,%xmm2
  81d473:	cvtss2sd %xmm0,%xmm0
  81d477:	addsd  %xmm1,%xmm2
  81d47b:	subsd  %xmm0,%xmm2
  81d47f:	xorps  %xmm9,%xmm9
  81d483:	cvtsd2ss %xmm2,%xmm9
  81d488:	movupd (%rsi),%xmm0
  81d48c:	movupd 0x8(%rsi),%xmm1
  81d491:	movsd  0x10(%rsi),%xmm2
  81d496:	movsd  0x18(%rsi),%xmm3
  81d49b:	movupd 0x20(%rsi),%xmm4
  81d4a0:	movss  0x4(%rdx),%xmm6
  81d4a5:	movss  0xc(%rdx),%xmm7
  81d4aa:	movaps %xmm6,%xmm5
  81d4ad:	addss  %xmm7,%xmm5
  81d4b1:	movd   %xmm5,%eax
  81d4b5:	and    $0x7fffffff,%eax
  81d4ba:	cmp    $0x7f7fffff,%eax
  81d4bf:	jg     81d4de <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d4c1:	cvtss2sd %xmm6,%xmm6
  81d4c5:	cvtss2sd %xmm7,%xmm7
  81d4c9:	cvtss2sd %xmm5,%xmm5
  81d4cd:	addsd  %xmm6,%xmm7
  81d4d1:	subsd  %xmm5,%xmm7
  81d4d5:	xorps  %xmm8,%xmm8
  81d4d9:	cvtsd2ss %xmm7,%xmm8
  81d4de:	cvtpd2ps %xmm4,%xmm5
  81d4e2:	cvtps2pd %xmm5,%xmm5
  81d4e5:	subpd  %xmm5,%xmm4
  81d4e9:	cvtpd2ps %xmm4,%xmm4
  81d4ed:	unpcklpd %xmm3,%xmm1
  81d4f1:	cvtpd2ps %xmm1,%xmm3
  81d4f5:	unpcklpd %xmm2,%xmm0
  81d4f9:	cvtpd2ps %xmm0,%xmm2
  81d4fd:	cvtps2pd %xmm3,%xmm3
  81d500:	subpd  %xmm3,%xmm1
  81d504:	cvtpd2ps %xmm1,%xmm5
  81d508:	cvtps2pd %xmm2,%xmm1
  81d50b:	subpd  %xmm1,%xmm0
  81d50f:	cvtpd2ps %xmm0,%xmm6
  81d513:	movapd %xmm6,%xmm0
  81d517:	unpcklps %xmm5,%xmm0
  81d51a:	movaps %xmm8,%xmm1
  81d51e:	movlhps %xmm9,%xmm1
  81d522:	movapd %xmm4,%xmm2
  81d526:	shufps $0x24,%xmm1,%xmm2
  81d52a:	xorps  %xmm1,%xmm1
  81d52d:	movapd %xmm0,%xmm3
  81d531:	cmpneqps %xmm1,%xmm3
  81d535:	cmpneqps %xmm1,%xmm2
  81d539:	packssdw %xmm2,%xmm3
  81d53d:	pmovmskb %xmm3,%eax
  81d541:	test   %eax,%eax
  81d543:	je     81d667 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d549:	movapd %xmm6,0x60(%rsp)
  81d54f:	movapd %xmm5,0x70(%rsp)
  81d555:	lea    0x8(%rsp),%r12
  81d55a:	movapd %xmm0,(%rsp)
  81d55f:	movapd %xmm4,0x80(%rsp)
  81d568:	movlpd %xmm4,0x10(%rsp)
  81d56e:	movss  %xmm9,0x18(%rsp)
  81d575:	movss  %xmm8,0x1c(%rsp)
  81d57c:	lea    0x318(%rbx),%r14
  81d583:	mov    %rsp,%rsi
  81d586:	mov    %r14,%rdi
  81d589:	movaps %xmm8,0x30(%rsp)
  81d58f:	movaps %xmm9,0x20(%rsp)
  81d595:	call   824f90 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d59a:	movapd 0x20(%rsp),%xmm6
  81d5a0:	movapd 0x30(%rsp),%xmm5
  81d5a6:	mov    %rax,%r15
  81d5a9:	shr    $0x39,%r15
  81d5ad:	mov    0x2f8(%rbx),%rcx
  81d5b4:	mov    0x300(%rbx),%rdx
  81d5bb:	movd   %r15d,%xmm0
  81d5c0:	punpcklbw %xmm0,%xmm0
  81d5c4:	pshuflw $0x0,%xmm0,%xmm0
  81d5c9:	pshufd $0x44,%xmm0,%xmm0
  81d5ce:	xor    %esi,%esi
  81d5d0:	pcmpeqd %xmm1,%xmm1
  81d5d4:	mov    %rax,%rdi
  81d5d7:	and    %rdx,%rdi
  81d5da:	movdqu (%rcx,%rdi,1),%xmm2
  81d5df:	movdqa %xmm2,%xmm3
  81d5e3:	pcmpeqb %xmm0,%xmm3
  81d5e7:	pmovmskb %xmm3,%r8d
  81d5ec:	test   %r8d,%r8d
  81d5ef:	je     81d640 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d5f1:	tzcnt  %r8d,%r9d
  81d5f6:	add    %rdi,%r9
  81d5f9:	and    %rdx,%r9
  81d5fc:	neg    %r9
  81d5ff:	lea    (%r9,%r9,8),%r9
  81d603:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d60a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d611:	pcmpeqb 0x10(%rsp),%xmm4
  81d617:	pcmpeqb (%rsp),%xmm3
  81d61c:	pand   %xmm4,%xmm3
  81d620:	pmovmskb %xmm3,%r10d
  81d625:	cmp    $0xffff,%r10d
  81d62c:	je     81d65e <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d62e:	lea    -0x1(%r8),%r9d
  81d632:	and    %r8w,%r9w
  81d636:	mov    %r9d,%r8d
  81d639:	jne    81d5f1 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d63b:	nopl   0x0(%rax,%rax,1)
  81d640:	pcmpeqb %xmm1,%xmm2
  81d644:	pmovmskb %xmm2,%r8d
  81d649:	test   %r8d,%r8d
  81d64c:	jne    81d66e <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d64e:	add    %rsi,%rdi
  81d651:	add    $0x10,%rdi
  81d655:	add    $0x10,%rsi
  81d659:	jmp    81d5d7 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d65e:	lea    (%rcx,%r9,4),%rdx
  81d662:	jmp    81d789 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d667:	xor    %eax,%eax
  81d669:	jmp    81d78c <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d66e:	cmpq   $0x0,0x308(%rbx)
  81d676:	je     81d7bf <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d67c:	mov    (%rsp),%r14
  81d680:	mov    0x10(%r12),%rcx
  81d685:	mov    %rcx,0x50(%rsp)
  81d68a:	movups (%r12),%xmm0
  81d68f:	movaps %xmm0,0x40(%rsp)
  81d694:	mov    0x70(%rbx),%r12
  81d698:	cmp    0x60(%rbx),%r12
  81d69c:	jne    81d6ba <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d69e:	lea    0x60(%rbx),%rdi
  81d6a2:	mov    %rax,%r13
  81d6a5:	call   *0x663b95(%rip)        # e81240 <_DYNAMIC+0x5b0>
  81d6ab:	movapd 0x20(%rsp),%xmm6
  81d6b1:	movapd 0x30(%rsp),%xmm5
  81d6b7:	mov    %r13,%rax
  81d6ba:	mov    0x68(%rbx),%rcx
  81d6be:	mov    %r12,%rdx
  81d6c1:	shl    $0x5,%rdx
  81d6c5:	movaps 0x60(%rsp),%xmm0
  81d6ca:	movlps %xmm0,(%rcx,%rdx,1)
  81d6ce:	movaps 0x80(%rsp),%xmm0
  81d6d6:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d6dc:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d6e2:	movdqa 0x70(%rsp),%xmm1
  81d6e8:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d6ee:	shufps $0x55,%xmm0,%xmm0
  81d6f2:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d6f8:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d6fe:	lea    0x1(%r12),%rcx
  81d703:	mov    %rcx,0x70(%rbx)
  81d707:	mov    0x2f8(%rbx),%rcx
  81d70e:	mov    0x300(%rbx),%rdx
  81d715:	and    %rdx,%rax
  81d718:	movdqu (%rcx,%rax,1),%xmm0
  81d71d:	pmovmskb %xmm0,%esi
  81d721:	test   %esi,%esi
  81d723:	je     81d79d <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d725:	tzcnt  %esi,%esi
  81d729:	add    %rax,%rsi
  81d72c:	and    %rdx,%rsi
  81d72f:	movzbl (%rcx,%rsi,1),%eax
  81d733:	test   %al,%al
  81d735:	jns    81d7f0 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d73b:	lea    -0x10(%rsi),%rdi
  81d73f:	and    %rdx,%rdi
  81d742:	mov    %r15b,(%rcx,%rsi,1)
  81d746:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d74b:	neg    %rsi
  81d74e:	lea    (%rsi,%rsi,8),%rsi
  81d752:	lea    (%rcx,%rsi,4),%rdx
  81d756:	and    $0x1,%al
  81d758:	movzbl %al,%eax
  81d75b:	sub    %rax,0x308(%rbx)
  81d762:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d767:	movdqa 0x40(%rsp),%xmm0
  81d76d:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d773:	mov    0x50(%rsp),%rax
  81d778:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d77d:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d782:	incq   0x310(%rbx)
  81d789:	mov    -0x4(%rdx),%eax
  81d78c:	add    $0x90,%rsp
  81d793:	pop    %rbx
  81d794:	pop    %r12
  81d796:	pop    %r13
  81d798:	pop    %r14
  81d79a:	pop    %r15
  81d79c:	ret
  81d79d:	mov    $0x10,%edi
  81d7a2:	add    %rdi,%rax
  81d7a5:	and    %rdx,%rax
  81d7a8:	movdqu (%rcx,%rax,1),%xmm0
  81d7ad:	pmovmskb %xmm0,%esi
  81d7b1:	add    $0x10,%rdi
  81d7b5:	test   %esi,%esi
  81d7b7:	jne    81d725 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d7bd:	jmp    81d7a2 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d7bf:	lea    0x2f8(%rbx),%rdi
  81d7c6:	mov    $0x1,%esi
  81d7cb:	mov    %r14,%rdx
  81d7ce:	mov    $0x1,%ecx
  81d7d3:	mov    %rax,%r14
  81d7d6:	call   *0x663b1c(%rip)        # e812f8 <_DYNAMIC+0x668>
  81d7dc:	movapd 0x20(%rsp),%xmm6
  81d7e2:	movapd 0x30(%rsp),%xmm5
  81d7e8:	mov    %r14,%rax
  81d7eb:	jmp    81d67c <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d7f0:	movdqa (%rcx),%xmm0
  81d7f4:	pmovmskb %xmm0,%eax
  81d7f8:	tzcnt  %eax,%esi
  81d7fc:	movzbl (%rcx,%rsi,1),%eax
  81d800:	jmp    81d73b <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d810 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d810:	push   %rbp
  81d811:	push   %r15
  81d813:	push   %r14
  81d815:	push   %r13
  81d817:	push   %r12
  81d819:	push   %rbx
  81d81a:	sub    $0x228,%rsp
  81d821:	mov    %rsi,%r14
  81d824:	test   %r8d,%r8d
  81d827:	je     81d8bb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d82d:	mov    %rdi,0x10(%rsp)
  81d832:	mov    0x110(%rcx),%rbp
  81d839:	test   %rbp,%rbp
  81d83c:	je     81d91f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d842:	mov    0x108(%rcx),%r13
  81d849:	shl    $0x3,%rbp
  81d84d:	mov    %r14,0x8(%rsp)
  81d852:	lea    0x78(%r14),%rdi
  81d856:	mov    %rdx,0x18(%rsp)
  81d85b:	lea    0x8(%rdx),%rax
  81d85f:	mov    %rax,0x20(%rsp)
  81d864:	xor    %ebx,%ebx
  81d866:	lea    0x28(%rsp),%r15
  81d86b:	xor    %r12d,%r12d
  81d86e:	xchg   %ax,%ax
  81d870:	mov    0x0(%r13,%r12,1),%rax
  81d875:	movups 0x28(%rax),%xmm0
  81d879:	lea    0x38(%rsp),%rcx
  81d87e:	movups %xmm0,(%rcx)
  81d881:	movups 0x18(%rax),%xmm0
  81d885:	movups %xmm0,0x28(%rsp)
  81d88a:	movups 0x38(%rax),%xmm0
  81d88e:	movups %xmm0,0x48(%rsp)
  81d893:	mov    %rdi,%r14
  81d896:	mov    0x20(%rsp),%rsi
  81d89b:	mov    %r15,%rdx
  81d89e:	call   81cff0 <<gpui_gpu::renderer::Atlas>::insert>
  81d8a3:	test   $0x1,%al
  81d8a5:	je     81d926 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d8a7:	add    %rdx,%rbx
  81d8aa:	add    $0x8,%r12
  81d8ae:	cmp    %r12,%rbp
  81d8b1:	mov    %r14,%rdi
  81d8b4:	jne    81d870 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d8b6:	jmp    81da2e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d8bb:	cmpl   $0x1,0x150(%r14)
  81d8c3:	jne    81d8d5 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d8c5:	mov    0x138(%r14),%rax
  81d8cc:	add    0x130(%r14),%rax
  81d8d3:	je     81d90c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d8d5:	mov    %rdi,%rbx
  81d8d8:	add    $0x78,%r14
  81d8dc:	lea    0x58(%rsp),%rdi
  81d8e1:	mov    %rdx,%rsi
  81d8e4:	mov    $0x1,%edx
  81d8e9:	call   81cd20 <<gpui_gpu::renderer::Atlas>::new>
  81d8ee:	mov    %r14,%rdi
  81d8f1:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d8f6:	lea    0x58(%rsp),%rsi
  81d8fb:	mov    $0xe8,%edx
  81d900:	mov    %r14,%rdi
  81d903:	call   *0x663627(%rip)        # e80f30 <memcpy@GLIBC_2.14>
  81d909:	mov    %rbx,%rdi
  81d90c:	movq   $0x0,0x8(%rdi)
  81d914:	movl   $0xffffffff,(%rdi)
  81d91a:	jmp    81da3d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d91f:	xor    %ebx,%ebx
  81d921:	jmp    81da2e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d926:	mov    0x8(%rsp),%rax
  81d92b:	mov    0x150(%rax),%eax
  81d931:	cmp    $0x81,%eax
  81d936:	mov    $0x80,%edx
  81d93b:	cmovae %eax,%edx
  81d93e:	add    %edx,%edx
  81d940:	cmp    $0x800,%edx
  81d946:	mov    $0x800,%eax
  81d94b:	cmovae %eax,%edx
  81d94e:	lea    0x140(%rsp),%r12
  81d956:	mov    %r12,%rdi
  81d959:	mov    0x18(%rsp),%rsi
  81d95e:	mov    %edx,0x8(%rsp)
  81d962:	call   81cd20 <<gpui_gpu::renderer::Atlas>::new>
  81d967:	xor    %r15d,%r15d
  81d96a:	nopw   0x0(%rax,%rax,1)
  81d970:	mov    0x0(%r13,%r15,1),%rax
  81d975:	movups 0x28(%rax),%xmm0
  81d979:	lea    0x68(%rsp),%rcx
  81d97e:	movups %xmm0,(%rcx)
  81d981:	movups 0x18(%rax),%xmm0
  81d985:	movups %xmm0,0x58(%rsp)
  81d98a:	movups 0x38(%rax),%xmm0
  81d98e:	movups %xmm0,0x78(%rsp)
  81d993:	mov    %r12,%rdi
  81d996:	mov    0x20(%rsp),%rsi
  81d99b:	lea    0x58(%rsp),%rdx
  81d9a0:	call   81cff0 <<gpui_gpu::renderer::Atlas>::insert>
  81d9a5:	cmp    $0x1,%rax
  81d9a9:	jne    81d9b9 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d9ab:	add    %rdx,%rbx
  81d9ae:	add    $0x8,%r15
  81d9b2:	cmp    %r15,%rbp
  81d9b5:	jne    81d970 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d9b7:	jmp    81d9fb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d9b9:	mov    0x8(%rsp),%r15d
  81d9be:	cmp    $0x800,%r15d
  81d9c5:	je     81da4f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d9cb:	mov    %r12,%rdi
  81d9ce:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9d3:	add    %r15d,%r15d
  81d9d6:	cmp    $0x800,%r15d
  81d9dd:	mov    $0x800,%eax
  81d9e2:	cmovae %eax,%r15d
  81d9e6:	mov    %r12,%rdi
  81d9e9:	mov    0x18(%rsp),%rsi
  81d9ee:	mov    %r15d,0x8(%rsp)
  81d9f3:	mov    %r15d,%edx
  81d9f6:	jmp    81d962 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81d9fb:	lea    0x58(%rsp),%rdi
  81da00:	lea    0x140(%rsp),%rsi
  81da08:	mov    $0xe8,%edx
  81da0d:	call   *0x66351d(%rip)        # e80f30 <memcpy@GLIBC_2.14>
  81da13:	mov    %r14,%rdi
  81da16:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da1b:	lea    0x58(%rsp),%rsi
  81da20:	mov    $0xe8,%edx
  81da25:	mov    %r14,%rdi
  81da28:	call   *0x663502(%rip)        # e80f30 <memcpy@GLIBC_2.14>
  81da2e:	mov    0x10(%rsp),%rax
  81da33:	mov    %rbx,0x8(%rax)
  81da37:	movl   $0xffffffff,(%rax)
  81da3d:	add    $0x228,%rsp
  81da44:	pop    %rbx
  81da45:	pop    %r12
  81da47:	pop    %r13
  81da49:	pop    %r14
  81da4b:	pop    %r15
  81da4d:	pop    %rbp
  81da4e:	ret
  81da4f:	mov    0x10(%rsp),%rax
  81da54:	movl   $0x7,(%rax)
  81da5a:	lea    0x140(%rsp),%rdi
  81da62:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da67:	jmp    81da3d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81da69:	jmp    81da6b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81da6b:	mov    %rax,%rbx
  81da6e:	lea    0x58(%rsp),%rsi
  81da73:	mov    $0xe8,%edx
  81da78:	mov    %r14,%rdi
  81da7b:	call   *0x6634af(%rip)        # e80f30 <memcpy@GLIBC_2.14>
  81da81:	mov    %rbx,%rdi
  81da84:	call   e2d9a0 <_Unwind_Resume@plt>
  81da89:	mov    %rax,%rbx
  81da8c:	lea    0x140(%rsp),%rdi
  81da94:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da99:	mov    %rbx,%rdi
  81da9c:	call   e2d9a0 <_Unwind_Resume@plt>
  81daa1:	call   *0x663439(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1527 frame=952

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081dab0 <<gpui_gpu::renderer::RendererState>::new>:
  81dab0:	push   %r15
  81dab2:	push   %r14
  81dab4:	push   %r13
  81dab6:	push   %r12
  81dab8:	push   %rbx
  81dab9:	sub    $0x390,%rsp
  81dac0:	mov    %rsi,%r14
  81dac3:	mov    %rdi,%rbx
  81dac6:	lea    -0x748ecb(%rip),%rax        # d4c02 <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.15614097268772730318+0xa>
  81dacd:	mov    %rax,0xd8(%rsp)
  81dad5:	movq   $0x7,0xe0(%rsp)
  81dae1:	movq   $0x30,0xe8(%rsp)
  81daed:	movl   $0x48,0xf0(%rsp)
  81daf8:	movb   $0x0,0xf4(%rsp)
  81db00:	mov    0x6637a9(%rip),%r15        # e812b0 <_DYNAMIC+0x620>
  81db07:	lea    0x10(%rsp),%rdi
  81db0c:	lea    0xd8(%rsp),%rdx
  81db14:	call   *%r15
  81db17:	movq   $0x30,0x30(%rsp)
  81db20:	lea    -0x748f1e(%rip),%rax        # d4c09 <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.15614097268772730318+0x11>
  81db27:	mov    %rax,0xd8(%rsp)
  81db2f:	movq   $0x5,0xe0(%rsp)
  81db3b:	movq   $0x10,0xe8(%rsp)
  81db47:	movl   $0x88,0xf0(%rsp)
  81db52:	movb   $0x0,0xf4(%rsp)
  81db5a:	lea    0x38(%rsp),%rdi
  81db5f:	lea    0xd8(%rsp),%rdx
  81db67:	mov    %r14,%rsi
  81db6a:	call   *%r15
  81db6d:	movq   $0x10,0x58(%rsp)
  81db76:	lea    -0x748f6f(%rip),%rax        # d4c0e <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.15614097268772730318+0x16>
  81db7d:	mov    %rax,0xd8(%rsp)
  81db85:	movq   $0x5,0xe0(%rsp)
  81db91:	movq   $0x8,0xe8(%rsp)
  81db9d:	movl   $0x88,0xf0(%rsp)
  81dba8:	movb   $0x0,0xf4(%rsp)
  81dbb0:	lea    0x60(%rsp),%rdi
  81dbb5:	lea    0xd8(%rsp),%rdx
  81dbbd:	mov    %r14,%rsi
  81dbc0:	call   *0x6636ea(%rip)        # e812b0 <_DYNAMIC+0x620>
  81dbc6:	movq   $0x8,0x80(%rsp)
  81dbd2:	lea    -0x748fc6(%rip),%rax        # d4c13 <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.15614097268772730318+0x1b>
  81dbd9:	mov    %rax,0xd8(%rsp)
  81dbe1:	movq   $0x7,0xe0(%rsp)
  81dbed:	movq   $0x4,0xe8(%rsp)
  81dbf9:	movl   $0x88,0xf0(%rsp)
  81dc04:	movb   $0x0,0xf4(%rsp)
  81dc0c:	lea    0x88(%rsp),%rdi
  81dc14:	lea    0xd8(%rsp),%rdx
  81dc1c:	mov    %r14,%rsi
  81dc1f:	call   *0x66368b(%rip)        # e812b0 <_DYNAMIC+0x620>
  81dc25:	movq   $0x4,0xa8(%rsp)
  81dc31:	lea    -0x74901e(%rip),%rax        # d4c1a <anon.7e34a6dced7fe4eb77116889a7de5f31.32.llvm.15614097268772730318+0x22>
  81dc38:	mov    %rax,0xd8(%rsp)
  81dc40:	movq   $0x11,0xe0(%rsp)
  81dc4c:	movq   $0x20,0xe8(%rsp)
  81dc58:	movl   $0x88,0xf0(%rsp)
  81dc63:	movb   $0x0,0xf4(%rsp)
  81dc6b:	lea    0xb0(%rsp),%rdi
  81dc73:	lea    0xd8(%rsp),%rdx
  81dc7b:	mov    %r14,%rsi
  81dc7e:	call   *0x66362c(%rip)        # e812b0 <_DYNAMIC+0x620>
  81dc84:	movq   $0x20,0xd0(%rsp)
  81dc90:	lea    0x2a8(%rsp),%rdi
  81dc98:	mov    %r14,%rsi
  81dc9b:	mov    $0x1,%edx
  81dca0:	call   81cd20 <<gpui_gpu::renderer::Atlas>::new>
  81dca5:	mov    0x18(%r14),%r13
  81dca9:	lock incq 0x0(%r13)
  81dcae:	jle    81dfe3 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81dcb4:	mov    %r13,0x8(%rsp)
  81dcb9:	mov    0x30(%rsp),%rax
  81dcbe:	mov    %rax,0x1e0(%rsp)
  81dcc6:	movups 0x10(%rsp),%xmm0
  81dccb:	movups 0x20(%rsp),%xmm1
  81dcd0:	movaps %xmm1,0x1d0(%rsp)
  81dcd8:	movaps %xmm0,0x1c0(%rsp)
  81dce0:	mov    0x58(%rsp),%rax
  81dce5:	mov    %rax,0x210(%rsp)
  81dced:	movups 0x38(%rsp),%xmm0
  81dcf2:	movups 0x48(%rsp),%xmm1
  81dcf7:	movaps %xmm1,0x200(%rsp)
  81dcff:	movaps %xmm0,0x1f0(%rsp)
  81dd07:	mov    0x80(%rsp),%rax
  81dd0f:	mov    %rax,0x240(%rsp)
  81dd17:	movups 0x60(%rsp),%xmm0
  81dd1c:	movups 0x70(%rsp),%xmm1
  81dd21:	movaps %xmm1,0x230(%rsp)
  81dd29:	movaps %xmm0,0x220(%rsp)
  81dd31:	mov    0xa8(%rsp),%rax
  81dd39:	mov    %rax,0x270(%rsp)
  81dd41:	movups 0x88(%rsp),%xmm0
  81dd49:	movups 0x98(%rsp),%xmm1
  81dd51:	movaps %xmm1,0x260(%rsp)
  81dd59:	movaps %xmm0,0x250(%rsp)
  81dd61:	mov    0xd0(%rsp),%rax
  81dd69:	mov    %rax,0x2a0(%rsp)
  81dd71:	movups 0xb0(%rsp),%xmm0
  81dd79:	movups 0xc0(%rsp),%xmm1
  81dd81:	movaps %xmm1,0x290(%rsp)
  81dd89:	movaps %xmm0,0x280(%rsp)
  81dd91:	lea    0xd8(%rsp),%rdi
  81dd99:	lea    0x2a8(%rsp),%rsi
  81dda1:	mov    $0xe8,%edx
  81dda6:	call   *0x663184(%rip)        # e80f30 <memcpy@GLIBC_2.14>
  81ddac:	mov    %fs:0x0,%rax
  81ddb5:	lea    -0x28(%rax),%rax
  81ddbc:	mov    %rax,%r12
  81ddbf:	cmpb   $0x1,0x10(%rax)
  81ddc3:	jne    81dfc3 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81ddc9:	mov    (%r12),%r14
  81ddcd:	mov    0x8(%r12),%r15
  81ddd2:	lea    0x1(%r14),%rax
  81ddd6:	mov    %rax,(%r12)
  81ddda:	mov    %r13,0x228(%rbx)
  81dde1:	mov    0x30(%rsp),%rax
  81dde6:	mov    %rax,0x250(%rbx)
  81dded:	movups 0x10(%rsp),%xmm0
  81ddf2:	movups 0x20(%rsp),%xmm1
  81ddf7:	movups %xmm1,0x240(%rbx)
  81ddfe:	movups %xmm0,0x230(%rbx)
  81de05:	mov    0x58(%rsp),%rax
  81de0a:	mov    %rax,0x278(%rbx)
  81de11:	movups 0x38(%rsp),%xmm0
  81de16:	movups 0x48(%rsp),%xmm1
  81de1b:	movups %xmm1,0x268(%rbx)
  81de22:	movups %xmm0,0x258(%rbx)
  81de29:	mov    0x80(%rsp),%rax
  81de31:	mov    %rax,0x2a0(%rbx)
  81de38:	movups 0x60(%rsp),%xmm0
  81de3d:	movups 0x70(%rsp),%xmm1
  81de42:	movups %xmm1,0x290(%rbx)
  81de49:	movups %xmm0,0x280(%rbx)
  81de50:	movups 0x88(%rsp),%xmm0
  81de58:	movups 0x98(%rsp),%xmm1
  81de60:	movups %xmm0,0x2a8(%rbx)
  81de67:	movups %xmm1,0x2b8(%rbx)
  81de6e:	mov    0xa8(%rsp),%rax
  81de76:	mov    %rax,0x2c8(%rbx)
  81de7d:	movups 0xb0(%rsp),%xmm0
  81de85:	movups 0xc0(%rsp),%xmm1
  81de8d:	movups %xmm0,0x2d0(%rbx)
  81de94:	movups %xmm1,0x2e0(%rbx)
  81de9b:	mov    0xd0(%rsp),%rax
  81dea3:	mov    %rax,0x2f0(%rbx)
  81deaa:	lea    0x78(%rbx),%rdi
  81deae:	lea    0x2a8(%rsp),%rsi
  81deb6:	mov    $0xe8,%edx
  81debb:	call   *0x66306f(%rip)        # e80f30 <memcpy@GLIBC_2.14>
  81dec1:	movq   $0x0,0x328(%rbx)
  81decc:	movq   $0x0,(%rbx)
  81ded3:	movq   $0x4,0x8(%rbx)
  81dedb:	xorps  %xmm0,%xmm0
  81dede:	movups %xmm0,0x10(%rbx)
  81dee2:	movq   $0x4,0x20(%rbx)
  81deea:	movups %xmm0,0x28(%rbx)
  81deee:	movq   $0x4,0x38(%rbx)
  81def6:	movups %xmm0,0x40(%rbx)
  81defa:	movq   $0x4,0x50(%rbx)
  81df02:	movups %xmm0,0x58(%rbx)
  81df06:	movq   $0x4,0x68(%rbx)
  81df0e:	movq   $0x0,0x70(%rbx)
  81df16:	movups 0x611993(%rip),%xmm1        # e2f8b0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x1f8>
  81df1d:	movups %xmm1,0x2f8(%rbx)
  81df24:	movups 0x611995(%rip),%xmm1        # e2f8c0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x208>
  81df2b:	movups %xmm1,0x308(%rbx)
  81df32:	mov    %r14,0x318(%rbx)
  81df39:	mov    %r15,0x320(%rbx)
  81df40:	movw   $0x101,0x340(%rbx)
  81df49:	movq   $0x0,0x330(%rbx)
  81df54:	movups %xmm0,0x210(%rbx)
  81df5b:	movups %xmm0,0x200(%rbx)
  81df62:	movups %xmm0,0x1f0(%rbx)
  81df69:	movups %xmm0,0x1e0(%rbx)
  81df70:	movups %xmm0,0x1d0(%rbx)
  81df77:	movups %xmm0,0x1c0(%rbx)
  81df7e:	movups %xmm0,0x1b0(%rbx)
  81df85:	movups %xmm0,0x1a0(%rbx)
  81df8c:	movups %xmm0,0x190(%rbx)
  81df93:	movups %xmm0,0x180(%rbx)
  81df9a:	movups %xmm0,0x170(%rbx)
  81dfa1:	movups %xmm0,0x160(%rbx)
  81dfa8:	movb   $0x0,0x220(%rbx)
  81dfaf:	mov    %rbx,%rax
  81dfb2:	add    $0x390,%rsp
  81dfb9:	pop    %rbx
  81dfba:	pop    %r12
  81dfbc:	pop    %r13
  81dfbe:	pop    %r14
  81dfc0:	pop    %r15
  81dfc2:	ret
  81dfc3:	call   *0x6632ef(%rip)        # e812b8 <_DYNAMIC+0x628>
  81dfc9:	mov    %rax,%r14
  81dfcc:	mov    %rdx,%r15
  81dfcf:	mov    %rax,(%r12)
  81dfd3:	mov    %rdx,0x8(%r12)
  81dfd8:	movb   $0x1,0x10(%r12)
  81dfde:	jmp    81ddd2 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81dfe3:	ud2
  81dfe5:	mov    %rax,%rbx
  81dfe8:	lea    0xd8(%rsp),%rdi
  81dff0:	call   81bae0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81dff5:	lea    0x280(%rsp),%rdi
  81dffd:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e002:	lea    0x250(%rsp),%rdi
  81e00a:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e00f:	lea    0x220(%rsp),%rdi
  81e017:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e01c:	lea    0x1f0(%rsp),%rdi
  81e024:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e029:	lea    0x1c0(%rsp),%rdi
  81e031:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e036:	lock decq 0x0(%r13)
  81e03b:	jne    81e099 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81e03d:	lea    0x8(%rsp),%rdi
  81e042:	call   *0x6630b0(%rip)        # e810f8 <_DYNAMIC+0x468>
  81e048:	jmp    81e099 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81e04a:	mov    %rax,%rbx
  81e04d:	lea    0xb0(%rsp),%rdi
  81e055:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e05a:	jmp    81e05f <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81e05c:	mov    %rax,%rbx
  81e05f:	lea    0x88(%rsp),%rdi
  81e067:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e06c:	jmp    81e071 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81e06e:	mov    %rax,%rbx
  81e071:	lea    0x60(%rsp),%rdi
  81e076:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e07b:	jmp    81e080 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81e07d:	mov    %rax,%rbx
  81e080:	lea    0x38(%rsp),%rdi
  81e085:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e08a:	jmp    81e08f <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81e08c:	mov    %rax,%rbx
  81e08f:	lea    0x10(%rsp),%rdi
  81e094:	call   81bbc0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e099:	mov    %rbx,%rdi
  81e09c:	call   e2d9a0 <_Unwind_Resume@plt>
  81e0a1:	call   *0x662e39(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9261 frame=1448

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0b0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0b0:	push   %rbp
  81e0b1:	push   %r15
  81e0b3:	push   %r14
  81e0b5:	push   %r13
  81e0b7:	push   %r12
  81e0b9:	push   %rbx
  81e0ba:	sub    $0x578,%rsp
  81e0c1:	mov    0x228(%rsi),%rax
  81e0c8:	mov    0x18(%rdx),%rbx
  81e0cc:	cmp    %rbx,%rax
  81e0cf:	je     81e0ed <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0d1:	mov    0x10(%rax),%r9
  81e0d5:	cmp    0x10(%rbx),%r9
  81e0d9:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0df:	mov    0x18(%rax),%rax
  81e0e3:	cmp    0x18(%rbx),%rax
  81e0e7:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0ed:	movupd 0x330(%rsi),%xmm0
  81e0f5:	movapd %xmm0,0x130(%rsp)
  81e0fe:	movq   $0x0,0x330(%rsi)
  81e109:	mov    0x130(%rsp),%r13
  81e111:	test   %r13,%r13
  81e114:	je     81e156 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e116:	lock decq 0x0(%r13)
  81e11b:	jne    81e156 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e11d:	lea    0x130(%rsp),%rax
  81e125:	mov    %rdi,%r14
  81e128:	mov    %rax,%rdi
  81e12b:	mov    %rsi,%r12
  81e12e:	mov    %r8,%rbp
  81e131:	mov    %rdx,%r15
  81e134:	mov    %r13,0x38(%rsp)
  81e139:	mov    %rcx,%r13
  81e13c:	call   *0x663066(%rip)        # e811a8 <_DYNAMIC+0x518>
  81e142:	mov    %r13,%rcx
  81e145:	mov    0x38(%rsp),%r13
  81e14a:	mov    %r15,%rdx
  81e14d:	mov    %rbp,%r8
  81e150:	mov    %r12,%rsi
  81e153:	mov    %r14,%rdi
  81e156:	mov    0x228(%rsi),%rax
  81e15d:	cmp    %rbx,%rax
  81e160:	je     81e17e <<gpui_gpu::renderer::RendererState>::render+0xce>
  81e162:	mov    0x10(%rax),%r9
  81e166:	cmp    0x10(%rbx),%r9
  81e16a:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e170:	mov    0x18(%rax),%rax
  81e174:	cmp    0x18(%rbx),%rax
  81e178:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e17e:	lea    0x330(%rsi),%rax
  81e185:	mov    %rax,0xe8(%rsp)
  81e18d:	mov    (%rax),%rax
  81e190:	test   %rax,%rax
  81e193:	je     81e1cc <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e195:	lock decq (%rax)
  81e199:	jne    81e1cc <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e19b:	mov    %rdi,%r14
  81e19e:	lea    0x330(%rsi),%rdi
  81e1a5:	mov    %rsi,%r12
  81e1a8:	mov    %r8,%rbp
  81e1ab:	mov    %rdx,%r15
  81e1ae:	mov    %r13,%rbx
  81e1b1:	mov    %rcx,%r13
  81e1b4:	call   *0x662fee(%rip)        # e811a8 <_DYNAMIC+0x518>
  81e1ba:	mov    %r13,%rcx
  81e1bd:	mov    %rbx,%r13
  81e1c0:	mov    %r15,%rdx
  81e1c3:	mov    %rbp,%r8
  81e1c6:	mov    %r12,%rsi
  81e1c9:	mov    %r14,%rdi
  81e1cc:	movq   $0x0,0x330(%rsi)
  81e1d7:	mov    (%rcx),%ebp
  81e1d9:	mov    0x8(%rcx),%r9d
  81e1dd:	movzbl 0xd(%rcx),%eax
  81e1e1:	test   %r9d,%r9d
  81e1e4:	sets   %r10b
  81e1e8:	and    $0x7fffffff,%r9d
  81e1ef:	lea    -0x800000(%r9),%r11d
  81e1f6:	cmp    $0x7f000000,%r11d
  81e1fd:	setb   %r11b
  81e201:	and    %r10b,%r11b
  81e204:	lea    -0x1(%r9),%r14d
  81e208:	cmp    $0x7fffff,%r14d
  81e20f:	setb   %r14b
  81e213:	and    %r10b,%r14b
  81e216:	test   %r9d,%r9d
  81e219:	sete   %r10b
  81e21d:	cmp    $0x7f800000,%r9d
  81e224:	sete   %r15b
  81e228:	or     %r10b,%r15b
  81e22b:	cmp    $0x7f800001,%r9d
  81e232:	setge  %r9b
  81e236:	or     %r15b,%r9b
  81e239:	or     %r14b,%r9b
  81e23c:	test   %ebp,%ebp
  81e23e:	setne  %r10b
  81e242:	and    %al,%r10b
  81e245:	or     %r11b,%r10b
  81e248:	or     %r9b,%r10b
  81e24b:	test   $0x1,%r10b
  81e24f:	je     81e274 <<gpui_gpu::renderer::RendererState>::render+0x1c4>
  81e251:	movl   $0x3,(%rdi)
  81e257:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e259:	movl   $0x4,(%rdi)
  81e25f:	mov    %rdi,%rax
  81e262:	add    $0x578,%rsp
  81e269:	pop    %rbx
  81e26a:	pop    %r12
  81e26c:	pop    %r13
  81e26e:	pop    %r14
  81e270:	pop    %r15
  81e272:	pop    %rbp
  81e273:	ret
  81e274:	movd   0x4(%rcx),%xmm2
  81e279:	movzbl 0xc(%rcx),%r12d
  81e27e:	test   $0x1,%bpl
  81e282:	je     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x24a>
  81e284:	movd   %xmm2,%r9d
  81e289:	test   %r9d,%r9d
  81e28c:	sets   %r10b
  81e290:	and    $0x7fffffff,%r9d
  81e297:	lea    -0x800000(%r9),%r11d
  81e29e:	cmp    $0x7f000000,%r11d
  81e2a5:	setb   %r11b
  81e2a9:	and    %r10b,%r11b
  81e2ac:	lea    -0x1(%r9),%r14d
  81e2b0:	cmp    $0x7fffff,%r14d
  81e2b7:	setb   %r14b
  81e2bb:	and    %r10b,%r14b
  81e2be:	test   %r9d,%r9d
  81e2c1:	sete   %r10b
  81e2c5:	cmp    $0x7f800000,%r9d
  81e2cc:	sete   %r15b
  81e2d0:	or     %r10b,%r15b
  81e2d3:	cmp    $0x7f800001,%r9d
  81e2da:	setge  %r9b
  81e2de:	or     %r15b,%r9b
  81e2e1:	or     %r14b,%r9b
  81e2e4:	or     %r11b,%r9b
  81e2e7:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2ed:	ucomiss -0x76f3e8(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e2f4:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2fa:	mov    0x28(%rcx),%r14d
  81e2fe:	cmp    %r14d,0x20(%r8)
  81e302:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e308:	mov    0x2c(%rcx),%r15d
  81e30c:	cmp    %r15d,0x24(%r8)
  81e310:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e316:	mov    0x38(%r8),%r10d
  81e31a:	cmp    0x20(%rdx),%r10d
  81e31e:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e324:	cmp    $0x4c,%r10d
  81e328:	jne    81e34d <<gpui_gpu::renderer::RendererState>::render+0x29d>
  81e32a:	movq   0x3c(%r8),%xmm0
  81e330:	movq   0x24(%rdx),%xmm1
  81e335:	pcmpeqd %xmm0,%xmm1
  81e339:	pshufd $0x50,%xmm1,%xmm0
  81e33e:	movmskpd %xmm0,%r9d
  81e343:	cmp    $0x3,%r9d
  81e347:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e34d:	cmp    $0x4000,%r15d
  81e354:	ja     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e356:	cmp    $0x4000,%r14d
  81e35d:	ja     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e35f:	mov    %r15,%r9
  81e362:	imul   %r14,%r9
  81e366:	add    $0xfffffffffeffffff,%r9
  81e36d:	cmp    $0xffffffffff000000,%r9
  81e374:	jb     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e376:	mov    0x10(%rcx),%rbx
  81e37a:	mov    0x80(%rbx),%r11
  81e381:	cmp    $0x10000,%r11
  81e388:	jbe    81e395 <<gpui_gpu::renderer::RendererState>::render+0x2e5>
  81e38a:	movl   $0x6,(%rdi)
  81e390:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e395:	movd   0x18(%rcx),%xmm0
  81e39a:	movd   %xmm0,%r9d
  81e39f:	and    $0x7fffffff,%r9d
  81e3a6:	cmp    $0x7f7fffff,%r9d
  81e3ad:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3b3:	pand   -0x770bcb(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3bb:	ucomiss -0x76f25e(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3c2:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3c8:	movd   0x1c(%rcx),%xmm0
  81e3cd:	movd   %xmm0,%r9d
  81e3d2:	and    $0x7fffffff,%r9d
  81e3d9:	cmp    $0x7f7fffff,%r9d
  81e3e0:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3e6:	pand   -0x770bfe(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3ee:	ucomiss -0x76f291(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3f5:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3fb:	movd   0x20(%rcx),%xmm0
  81e400:	movd   %xmm0,%r9d
  81e405:	and    $0x7fffffff,%r9d
  81e40c:	cmp    $0x7f7fffff,%r9d
  81e413:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e419:	pand   -0x770c31(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e421:	ucomiss -0x76f2c4(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e428:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e42e:	movd   0x24(%rcx),%xmm0
  81e433:	movd   %xmm0,%r9d
  81e438:	and    $0x7fffffff,%r9d
  81e43f:	cmp    $0x7f7fffff,%r9d
  81e446:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e44c:	movdqa -0x770c64(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e454:	pand   %xmm0,%xmm1
  81e458:	ucomiss -0x76f2fb(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e45f:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e465:	xorps  %xmm1,%xmm1
  81e468:	ucomiss %xmm1,%xmm0
  81e46b:	jb     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e471:	movss  -0x76f699(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e479:	ucomiss %xmm0,%xmm1
  81e47c:	jb     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e482:	movzwl 0x30(%rcx),%r9d
  81e487:	mov    %r9d,0x10(%rsp)
  81e48c:	movzwl 0x32(%rcx),%r9d
  81e491:	mov    %r9d,0x30(%rsp)
  81e496:	cmp    $0x28,%r10d
  81e49a:	mov    %r8,0x4b8(%rsp)
  81e4a2:	mov    %rcx,0x120(%rsp)
  81e4aa:	mov    %rdx,0xa0(%rsp)
  81e4b2:	mov    %r13,0x38(%rsp)
  81e4b7:	movd   %xmm2,0x2e8(%rsp)
  81e4c0:	movss  %xmm1,0xf4(%rsp)
  81e4c9:	jne    81e4d5 <<gpui_gpu::renderer::RendererState>::render+0x425>
  81e4cb:	test   $0x1,%al
  81e4cd:	je     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4d3:	jmp    81e4f0 <<gpui_gpu::renderer::RendererState>::render+0x440>
  81e4d5:	test   $0x1,%al
  81e4d7:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4dd:	ucomiss -0x76f704(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e4e4:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4ea:	jp     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4f0:	mov    %rbx,0x100(%rsp)
  81e4f8:	mov    %r11,0x108(%rsp)
  81e500:	mov    %r10d,0x2e4(%rsp)
  81e508:	mov    %rdi,0x50(%rsp)
  81e50d:	lea    0xf(%r14),%rax
  81e511:	shr    $0x4,%rax
  81e515:	lea    0xf(%r15),%ecx
  81e519:	shr    $0x4,%ecx
  81e51c:	lea    0x18(%rsi),%rdi
  81e520:	movq   $0x0,0x28(%rsi)
  81e528:	mov    %rax,0x90(%rsp)
  81e530:	imul   %eax,%ecx
  81e533:	movabs $0x4000000000000000,%rdx
  81e53d:	mov    %rdi,0x4c8(%rsp)
  81e545:	mov    %rsi,%r13
  81e548:	mov    %rcx,0x40(%rsp)
  81e54d:	mov    %rcx,%rsi
  81e550:	call   823760 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e555:	mov    %r13,0x8(%rsp)
  81e55a:	mov    0x10(%r13),%rax
  81e55e:	mov    %rax,0x348(%rsp)
  81e566:	mov    0x120(%rsp),%rdi
  81e56e:	call   *0x662cc4(%rip)        # e81238 <_DYNAMIC+0x5a8>
  81e574:	mov    %rdx,0x358(%rsp)
  81e57c:	mov    %rax,0x350(%rsp)
  81e584:	sub    %rax,%rdx
  81e587:	cmp    $0x300000,%rdx
  81e58e:	ja     81e6c5 <<gpui_gpu::renderer::RendererState>::render+0x615>
  81e594:	mov    %rdx,%rcx
  81e597:	mov    %rdx,%rax
  81e59a:	shr    $0x3,%rax
  81e59e:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81e5a8:	imul   %rax,%rdx
  81e5ac:	mov    %rdx,0x2c0(%rsp)
  81e5b4:	mov    0x350(%rsp),%rax
  81e5bc:	cmp    %rax,0x358(%rsp)
  81e5c4:	je     81e5f5 <<gpui_gpu::renderer::RendererState>::render+0x545>
  81e5c6:	mov    $0xaaaaaaab,%eax
  81e5cb:	imul   %rax,%rcx
  81e5cf:	shr    $0x2a,%rcx
  81e5d3:	mov    0x2c0(%rsp),%rdx
  81e5db:	mov    %edx,%eax
  81e5dd:	and    $0x3f,%eax
  81e5e0:	add    %rdx,%rcx
  81e5e3:	cmp    $0x1,%rax
  81e5e7:	sbb    $0xffffffffffffffff,%rcx
  81e5eb:	inc    %rcx
  81e5ee:	mov    %rcx,0x20(%rsp)
  81e5f3:	jmp    81e5fe <<gpui_gpu::renderer::RendererState>::render+0x54e>
  81e5f5:	movq   $0x0,0x20(%rsp)
  81e5fe:	mov    0x100(%rsp),%rax
  81e606:	mov    0x98(%rax),%rdx
  81e60d:	add    0xb0(%rax),%rdx
  81e614:	mov    0x30(%rsp),%ecx
  81e618:	shl    $0x10,%ecx
  81e61b:	add    0x10(%rsp),%ecx
  81e61f:	mov    %rax,0x130(%rsp)
  81e627:	movq   $0x0,0x138(%rsp)
  81e633:	mov    0x108(%rsp),%rbx
  81e63b:	mov    %rbx,0x140(%rsp)
  81e643:	mov    %rdx,0x340(%rsp)
  81e64b:	mov    %rdx,0x148(%rsp)
  81e653:	mov    %ecx,0x30(%rsp)
  81e657:	mov    %ecx,0x150(%rsp)
  81e65e:	mov    0x8(%rsp),%r13
  81e663:	movzbl 0x341(%r13),%esi
  81e66b:	lea    0x130(%rsp),%rdi
  81e673:	call   81c7d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>
  81e678:	mov    %rax,0x110(%rsp)
  81e680:	mov    0x20(%rsp),%rcx
  81e685:	lea    (%rcx,%rax,4),%rcx
  81e689:	mov    %rcx,0x10(%rsp)
  81e68e:	lea    (%rcx,%rbx,2),%rax
  81e692:	xor    %edx,%edx
  81e694:	mov    %rax,0x2b8(%rsp)
  81e69c:	sub    0x348(%rsp),%rax
  81e6a4:	cmovae %rax,%rdx
  81e6a8:	mov    0x10(%r13),%rsi
  81e6ac:	mov    $0x4,%ecx
  81e6b1:	mov    $0x10,%r8d
  81e6b7:	mov    %r13,%rdi
  81e6ba:	call   824b90 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e6bf:	cmp    $0xffffffffffffffff,%rax
  81e6c3:	je     81e6d5 <<gpui_gpu::renderer::RendererState>::render+0x625>
  81e6c5:	mov    0x50(%rsp),%rdi
  81e6ca:	movl   $0x6,(%rdi)
  81e6d0:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e6d5:	pxor   %xmm0,%xmm0
  81e6d9:	movdqa %xmm0,0x130(%rsp)
  81e6e2:	lea    0x130(%rsp),%rdx
  81e6ea:	mov    0x8(%rsp),%rbx
  81e6ef:	mov    %rbx,%rdi
  81e6f2:	mov    0x108(%rsp),%rax
  81e6fa:	mov    0x10(%rsp),%rcx
  81e6ff:	lea    (%rcx,%rax,2),%rsi
  81e703:	call   823880 <<alloc::vec::Vec<[u32; 4]>>::resize>
  81e708:	movq   $0xffffffffffffffff,0x2d0(%rsp)
  81e714:	movq   $0x0,0x2d8(%rsp)
  81e720:	movq   $0xffffffffffffffff,0x230(%rsp)
  81e72c:	movq   $0x0,0x238(%rsp)
  81e738:	mov    0x10(%rbx),%rdx
  81e73c:	cmp    %rdx,0x20(%rsp)
  81e741:	ja     820438 <<gpui_gpu::renderer::RendererState>::render+0x2388>
  81e747:	mov    0x8(%rsp),%r13
  81e74c:	mov    0x8(%r13),%rdi
  81e750:	lea    0x2d0(%rsp),%r8
  81e758:	mov    0x20(%rsp),%rsi
  81e75d:	mov    0x120(%rsp),%rdx
  81e765:	mov    0x2c0(%rsp),%rcx
  81e76d:	call   824840 <gpui_gpu::renderer::slots::write_prefix>
  81e772:	lea    0x48(%r13),%rdi
  81e776:	movq   $0x0,0x58(%r13)
  81e77e:	mov    %rdi,0x4c0(%rsp)
  81e786:	mov    0x40(%rsp),%rsi
  81e78b:	xor    %edx,%edx
  81e78d:	call   823970 <<alloc::vec::Vec<u32>>::resize>
  81e792:	movq   $0x0,0x70(%r13)
  81e79a:	cmpq   $0x0,0x60(%r13)
  81e79f:	jne    81e7b0 <<gpui_gpu::renderer::RendererState>::render+0x700>
  81e7a1:	mov    0x8(%rsp),%rax
  81e7a6:	lea    0x60(%rax),%rdi
  81e7aa:	call   *0x662a90(%rip)        # e81240 <_DYNAMIC+0x5b0>
  81e7b0:	mov    0x110(%rsp),%rax
  81e7b8:	add    %rax,%rax
  81e7bb:	mov    %rax,0x110(%rsp)
  81e7c3:	mov    0x8(%rsp),%rax
  81e7c8:	mov    0x68(%rax),%rcx
  81e7cc:	pxor   %xmm0,%xmm0
  81e7d0:	movdqu %xmm0,0x10(%rcx)
  81e7d5:	movdqu %xmm0,(%rcx)
  81e7d9:	movq   $0x1,0x70(%rax)
  81e7e1:	lea    0x2f8(%rax),%rdi
  81e7e8:	call   8231b0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e7ed:	mov    0x100(%rsp),%rax
  81e7f5:	mov    %rax,0x368(%rsp)
  81e7fd:	movq   $0x0,0x370(%rsp)
  81e809:	mov    0x108(%rsp),%rax
  81e811:	mov    %rax,0x378(%rsp)
  81e819:	mov    0x340(%rsp),%rax
  81e821:	mov    %rax,0x380(%rsp)
  81e829:	mov    0x30(%rsp),%eax
  81e82d:	mov    %eax,0x388(%rsp)
  81e834:	lea    0x408(%rsp),%rdi
  81e83c:	lea    0x368(%rsp),%rsi
  81e844:	call   *0x6629fe(%rip)        # e81248 <_DYNAMIC+0x5b8>
  81e84a:	mov    0x408(%rsp),%rax
  81e852:	mov    %rax,0x28(%rsp)
  81e857:	test   %rax,%rax
  81e85a:	je     81f2e6 <<gpui_gpu::renderer::RendererState>::render+0x1236>
  81e860:	movq   $0x0,0x118(%rsp)
  81e86c:	movq   $0x0,0x68(%rsp)
  81e875:	movq   $0x0,0x88(%rsp)
  81e881:	movq   $0x0,0x2a8(%rsp)
  81e88d:	movq   $0x0,0x2b0(%rsp)
  81e899:	mov    0x410(%rsp),%rbx
  81e8a1:	mov    0x418(%rsp),%r13
  81e8a9:	lea    0x420(%rsp),%rcx
  81e8b1:	movups (%rcx),%xmm0
  81e8b4:	movups 0x10(%rcx),%xmm1
  81e8b8:	movups 0x20(%rcx),%xmm2
  81e8bc:	movaps %xmm2,0x290(%rsp)
  81e8c4:	movaps %xmm1,0x280(%rsp)
  81e8cc:	movaps %xmm0,0x270(%rsp)
  81e8d4:	lea    0x450(%rsp),%rdx
  81e8dc:	movups (%rdx),%xmm0
  81e8df:	movaps %xmm0,0x330(%rsp)
  81e8e7:	movups 0x40(%rcx),%xmm0
  81e8eb:	movaps %xmm0,0x320(%rsp)
  81e8f3:	mov    0x8(%rsp),%rax
  81e8f8:	movzbl 0x341(%rax),%esi
  81e8ff:	mov    0x28(%rsp),%rax
  81e904:	mov    %rax,0x130(%rsp)
  81e90c:	mov    %rbx,0x138(%rsp)
  81e914:	mov    %r13,0x140(%rsp)
  81e91c:	movups (%rcx),%xmm0
  81e91f:	movdqu 0x10(%rcx),%xmm1
  81e924:	movdqu 0x20(%rcx),%xmm2
  81e929:	lea    0x148(%rsp),%rdi
  81e931:	movdqu %xmm2,0x20(%rdi)
  81e936:	movdqu %xmm1,0x10(%rdi)
  81e93b:	movups %xmm0,(%rdi)
  81e93e:	movups (%rdx),%xmm0
  81e941:	lea    0x178(%rsp),%rax
  81e949:	movups %xmm0,(%rax)
  81e94c:	movdqu 0x40(%rcx),%xmm0
  81e951:	movdqu %xmm0,0x40(%rdi)
  81e956:	lea    0x130(%rsp),%rdi
  81e95e:	call   8216d0 <gpui_gpu::renderer::compact_group>
  81e963:	mov    %rbx,0xa8(%rsp)
  81e96b:	mov    %r13,0xe0(%rsp)
  81e973:	lea    (%rbx,%r13,4),%rbx
  81e977:	mov    %al,0x1f(%rsp)
  81e97b:	test   %al,%al
  81e97d:	je     81eb72 <<gpui_gpu::renderer::RendererState>::render+0xac2>
  81e983:	mov    0xa8(%rsp),%rax
  81e98b:	mov    %rax,0x490(%rsp)
  81e993:	mov    %rbx,0x498(%rsp)
  81e99b:	mov    0x28(%rsp),%rax
  81e9a0:	mov    %rax,0x4a0(%rsp)
  81e9a8:	movq   $0x0,0x4a8(%rsp)
  81e9b4:	lea    0x3a0(%rsp),%rdi
  81e9bc:	lea    0x490(%rsp),%rsi
  81e9c4:	call   821d60 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e9c9:	cmpb   $0xff,0x3a8(%rsp)
  81e9d1:	je     81eb80 <<gpui_gpu::renderer::RendererState>::render+0xad0>
  81e9d7:	pxor   %xmm0,%xmm0
  81e9db:	movdqa %xmm0,0x70(%rsp)
  81e9e1:	movdqa %xmm0,0x40(%rsp)
  81e9e7:	mov    0x3a0(%rsp),%rdx
  81e9ef:	add    0x88(%rsp),%rdx
  81e9f7:	lea    0x3a8(%rsp),%rcx
  81e9ff:	movups 0x38(%rcx),%xmm0
  81ea03:	lea    0x148(%rsp),%rax
  81ea0b:	movups %xmm0,0x20(%rax)
  81ea0f:	movups 0x48(%rcx),%xmm0
  81ea13:	lea    0x178(%rsp),%rsi
  81ea1b:	movups %xmm0,0x40(%rsi)
  81ea1f:	mov    0x30(%rcx),%rax
  81ea23:	mov    %rax,0x160(%rsp)
  81ea2b:	movups (%rcx),%xmm0
  81ea2e:	movups 0x10(%rcx),%xmm1
  81ea32:	movups 0x20(%rcx),%xmm2
  81ea36:	movaps %xmm2,0x150(%rsp)
  81ea3e:	movaps %xmm1,0x140(%rsp)
  81ea46:	movaps %xmm0,0x130(%rsp)
  81ea4e:	lea    0x420(%rsp),%rax
  81ea56:	movups (%rax),%xmm0
  81ea59:	movups 0x10(%rax),%xmm1
  81ea5d:	movups 0x20(%rax),%xmm2
  81ea61:	movups %xmm2,0x20(%rsi)
  81ea65:	movups %xmm1,0x10(%rsi)
  81ea69:	movups %xmm0,(%rsi)
  81ea6c:	lea    0x450(%rsp),%rcx
  81ea74:	movups (%rcx),%xmm0
  81ea77:	movups %xmm0,0x30(%rsi)
  81ea7b:	movups 0x40(%rax),%xmm0
  81ea7f:	movups %xmm0,0x50(%rsi)
  81ea83:	lea    0x240(%rsp),%rdi
  81ea8b:	lea    0x130(%rsp),%rsi
  81ea93:	mov    %r14d,%ecx
  81ea96:	mov    %r15d,%r8d
  81ea99:	call   821720 <gpui_gpu::renderer::validate_draw>
  81ea9e:	mov    0x240(%rsp),%ecx
  81eaa5:	mov    0x244(%rsp),%rax
  81eaad:	cmp    $0xffffffff,%ecx
  81eab0:	jne    81f3c2 <<gpui_gpu::renderer::RendererState>::render+0x1312>
  81eab6:	mov    %eax,%ecx
  81eab8:	shr    $0x20,%rax
  81eabc:	movd   %ecx,%xmm0
  81eac0:	movaps 0x70(%rsp),%xmm2
  81eac5:	movaps %xmm2,%xmm1
  81eac8:	maxss  %xmm0,%xmm1
  81eacc:	movaps %xmm1,%xmm3
  81eacf:	cmpunordss %xmm1,%xmm3
  81ead4:	movaps %xmm3,%xmm0
  81ead7:	andnps %xmm1,%xmm0
  81eada:	andps  %xmm2,%xmm3
  81eadd:	orps   %xmm0,%xmm3
  81eae0:	movaps %xmm3,0xc0(%rsp)
  81eae8:	movd   %eax,%xmm0
  81eaec:	movaps 0x40(%rsp),%xmm2
  81eaf1:	movaps %xmm2,%xmm1
  81eaf4:	maxss  %xmm0,%xmm1
  81eaf8:	movaps %xmm1,%xmm3
  81eafb:	cmpunordss %xmm1,%xmm3
  81eb00:	movaps %xmm3,%xmm0
  81eb03:	andnps %xmm1,%xmm0
  81eb06:	andps  %xmm2,%xmm3
  81eb09:	orps   %xmm0,%xmm3
  81eb0c:	movaps %xmm3,0xb0(%rsp)
  81eb14:	lea    0x3a0(%rsp),%rdi
  81eb1c:	lea    0x490(%rsp),%rsi
  81eb24:	call   821d60 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81eb29:	cmpb   $0xff,0x3a8(%rsp)
  81eb31:	movdqa 0xc0(%rsp),%xmm1
  81eb3a:	movdqa %xmm1,0x70(%rsp)
  81eb40:	movdqa 0xb0(%rsp),%xmm2
  81eb49:	movdqa %xmm2,0x40(%rsp)
  81eb4f:	jne    81e9e7 <<gpui_gpu::renderer::RendererState>::render+0x937>
  81eb55:	movdqa %xmm1,%xmm0
  81eb59:	movd   %xmm0,%ecx
  81eb5d:	movd   %xmm2,%eax
  81eb61:	shl    $0x20,%rax
  81eb65:	or     %rax,%rcx
  81eb68:	mov    %rcx,0xf8(%rsp)
  81eb70:	jmp    81eb8c <<gpui_gpu::renderer::RendererState>::render+0xadc>
  81eb72:	movq   $0x0,0xf8(%rsp)
  81eb7e:	jmp    81eba4 <<gpui_gpu::renderer::RendererState>::render+0xaf4>
  81eb80:	movq   $0x0,0xf8(%rsp)
  81eb8c:	incq   0x2a8(%rsp)
  81eb94:	mov    0xe0(%rsp),%rax
  81eb9c:	add    %rax,0x2b0(%rsp)
  81eba4:	mov    0xa8(%rsp),%rax
  81ebac:	mov    %rax,0x240(%rsp)
  81ebb4:	mov    %rbx,0x248(%rsp)
  81ebbc:	mov    0x28(%rsp),%rax
  81ebc1:	mov    %rax,0x250(%rsp)
  81ebc9:	movq   $0x0,0x258(%rsp)
  81ebd5:	lea    0x3a0(%rsp),%rdi
  81ebdd:	lea    0x240(%rsp),%rsi
  81ebe5:	call   821d60 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ebea:	movzbl 0x3a8(%rsp),%eax
  81ebf2:	cmp    $0xff,%al
  81ebf4:	je     81f2b8 <<gpui_gpu::renderer::RendererState>::render+0x1208>
  81ebfa:	mov    %eax,%r8d
  81ebfd:	mov    0x10(%rsp),%rax
  81ec02:	lea    0x8(,%rax,8),%rax
  81ec0a:	mov    %rax,0x128(%rsp)
  81ec12:	mov    0x20(%rsp),%rax
  81ec17:	mov    %rax,0x80(%rsp)
  81ec1f:	mov    0x3a0(%rsp),%rax
  81ec27:	movups 0x3e0(%rsp),%xmm3
  81ec2f:	lea    0x3a8(%rsp),%rsi
  81ec37:	movups 0x48(%rsi),%xmm0
  81ec3b:	lea    0x518(%rsp),%rdi
  81ec43:	movups %xmm0,0x40(%rdi)
  81ec47:	mov    0x1(%rsi),%ecx
  81ec4a:	mov    0x4(%rsi),%edx
  81ec4d:	mov    %edx,-0x44(%rdi)
  81ec50:	mov    %ecx,-0x47(%rdi)
  81ec53:	mov    0x3b0(%rsp),%rdx
  81ec5b:	mov    0x30(%rsi),%rcx
  81ec5f:	mov    %rcx,-0x18(%rdi)
  81ec63:	movups 0x10(%rsi),%xmm0
  81ec67:	movups 0x20(%rsi),%xmm1
  81ec6b:	movups %xmm1,-0x28(%rdi)
  81ec6f:	movups %xmm0,-0x38(%rdi)
  81ec73:	movaps 0x270(%rsp),%xmm0
  81ec7b:	movaps 0x280(%rsp),%xmm1
  81ec83:	movaps 0x290(%rsp),%xmm2
  81ec8b:	movups %xmm2,0x20(%rdi)
  81ec8f:	movups %xmm1,0x10(%rdi)
  81ec93:	movups %xmm0,(%rdi)
  81ec96:	movaps 0x330(%rsp),%xmm0
  81ec9e:	movups %xmm0,0x30(%rdi)
  81eca2:	movaps 0x320(%rsp),%xmm0
  81ecaa:	movups %xmm0,0x50(%rdi)
  81ecae:	movaps %xmm3,0xc0(%rsp)
  81ecb6:	movups %xmm3,0x508(%rsp)
  81ecbe:	mov    %r8b,0x70(%rsp)
  81ecc3:	mov    %r8b,0x4d0(%rsp)
  81eccb:	mov    %rdx,0x310(%rsp)
  81ecd3:	mov    %rdx,0x4d8(%rsp)
  81ecdb:	cmpb   $0x0,0x1f(%rsp)
  81ece0:	je     81ed28 <<gpui_gpu::renderer::RendererState>::render+0xc78>
  81ece2:	mov    0xf8(%rsp),%rcx
  81ecea:	mov    %rcx,0x40(%rsp)
  81ecef:	mov    0x20(%rsp),%rcx
  81ecf4:	mov    %rcx,0xb0(%rsp)
  81ecfc:	test   %rax,%rax
  81ecff:	je     81ed78 <<gpui_gpu::renderer::RendererState>::render+0xcc8>
  81ed01:	mov    0xf8(%rsp),%rax
  81ed09:	mov    %rax,0x40(%rsp)
  81ed0e:	mov    0x20(%rsp),%rax
  81ed13:	mov    %rax,0xb0(%rsp)
  81ed1b:	lea    0x130(%rsp),%rbx
  81ed23:	jmp    81f090 <<gpui_gpu::renderer::RendererState>::render+0xfe0>
  81ed28:	lea    0x130(%rsp),%rdi
  81ed30:	lea    0x4d0(%rsp),%rsi
  81ed38:	mov    0x88(%rsp),%rdx
  81ed40:	mov    %r14d,%ecx
  81ed43:	mov    %r15d,%r8d
  81ed46:	call   821720 <gpui_gpu::renderer::validate_draw>
  81ed4b:	mov    0x130(%rsp),%eax
  81ed52:	mov    0x134(%rsp),%rcx
  81ed5a:	mov    %rcx,0x40(%rsp)
  81ed5f:	cmp    $0xffffffff,%eax
  81ed62:	jne    81f450 <<gpui_gpu::renderer::RendererState>::render+0x13a0>
  81ed68:	mov    0x80(%rsp),%rax
  81ed70:	mov    %rax,0xb0(%rsp)
  81ed78:	cmpb   $0x3,0x70(%rsp)
  81ed7d:	jne    81ee12 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed83:	movss  0x4d4(%rsp),%xmm0
  81ed8c:	xorps  %xmm1,%xmm1
  81ed8f:	ucomiss %xmm1,%xmm0
  81ed92:	jne    81ed96 <<gpui_gpu::renderer::RendererState>::render+0xce6>
  81ed94:	jnp    81ee12 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed96:	movaps 0xc0(%rsp),%xmm5
  81ed9e:	movaps %xmm5,%xmm1
  81eda1:	unpckhpd %xmm5,%xmm1
  81eda5:	movss  -0x76fde1(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81edad:	mulss  %xmm4,%xmm1
  81edb1:	movaps %xmm0,%xmm2
  81edb4:	minss  %xmm1,%xmm2
  81edb8:	movaps %xmm2,%xmm1
  81edbb:	cmpunordss %xmm2,%xmm1
  81edc0:	movaps %xmm1,%xmm3
  81edc3:	andnps %xmm2,%xmm3
  81edc6:	andps  %xmm0,%xmm1
  81edc9:	orps   %xmm3,%xmm1
  81edcc:	movaps %xmm5,%xmm0
  81edcf:	shufps $0xff,%xmm5,%xmm0
  81edd3:	mulss  %xmm4,%xmm0
  81edd7:	movaps %xmm1,%xmm2
  81edda:	minss  %xmm0,%xmm2
  81edde:	movaps %xmm2,%xmm0
  81ede1:	cmpunordss %xmm2,%xmm0
  81ede6:	andps  %xmm0,%xmm1
  81ede9:	andnps %xmm2,%xmm0
  81edec:	orps   %xmm1,%xmm0
  81edef:	movd   %xmm0,%eax
  81edf3:	mov    %eax,0x260(%rsp)
  81edfa:	and    $0xff800000,%eax
  81edff:	mov    $0x7f000000,%ecx
  81ee04:	sub    %eax,%ecx
  81ee06:	mov    %ecx,0xd8(%rsp)
  81ee0d:	xorps  %xmm0,%xmm0
  81ee10:	jmp    81ee37 <<gpui_gpu::renderer::RendererState>::render+0xd87>
  81ee12:	mov    0x568(%rsp),%eax
  81ee19:	mov    %eax,0x260(%rsp)
  81ee20:	mov    0x56c(%rsp),%eax
  81ee27:	mov    %eax,0xd8(%rsp)
  81ee2e:	movsd  0x570(%rsp),%xmm0
  81ee37:	movaps %xmm0,0x300(%rsp)
  81ee3f:	movups 0x518(%rsp),%xmm0
  81ee47:	movaps %xmm0,0x470(%rsp)
  81ee4f:	movups 0x520(%rsp),%xmm0
  81ee57:	movaps %xmm0,0x390(%rsp)
  81ee5f:	movsd  0x528(%rsp),%xmm0
  81ee68:	movaps %xmm0,0x220(%rsp)
  81ee70:	movsd  0x530(%rsp),%xmm0
  81ee79:	movaps %xmm0,0x2f0(%rsp)
  81ee81:	movsd  0x538(%rsp),%xmm0
  81ee8a:	movsd  %xmm0,0x98(%rsp)
  81ee93:	movsd  0x540(%rsp),%xmm0
  81ee9c:	movsd  %xmm0,0x2c8(%rsp)
  81eea5:	movups 0x548(%rsp),%xmm0
  81eead:	movaps %xmm0,0x480(%rsp)
  81eeb5:	mov    0x28(%rsp),%rax
  81eeba:	mov    %rax,0x130(%rsp)
  81eec2:	mov    0xa8(%rsp),%rax
  81eeca:	mov    %rax,0x138(%rsp)
  81eed2:	mov    0xe0(%rsp),%rax
  81eeda:	mov    %rax,0x140(%rsp)
  81eee2:	movaps 0x270(%rsp),%xmm0
  81eeea:	movaps 0x280(%rsp),%xmm1
  81eef2:	movaps 0x290(%rsp),%xmm2
  81eefa:	lea    0x148(%rsp),%rcx
  81ef02:	movups %xmm2,0x20(%rcx)
  81ef06:	movups %xmm1,0x10(%rcx)
  81ef0a:	movups %xmm0,(%rcx)
  81ef0d:	movaps 0x330(%rsp),%xmm0
  81ef15:	lea    0x178(%rsp),%rax
  81ef1d:	movups %xmm0,(%rax)
  81ef20:	movaps 0x320(%rsp),%xmm0
  81ef28:	movups %xmm0,0x40(%rcx)
  81ef2c:	lea    0x130(%rsp),%rdi
  81ef34:	call   *0x662316(%rip)        # e81250 <_DYNAMIC+0x5c0>
  81ef3a:	test   %eax,%eax
  81ef3c:	je     81ef6a <<gpui_gpu::renderer::RendererState>::render+0xeba>
  81ef3e:	mov    0x2c0(%rsp),%rdi
  81ef46:	mov    %eax,%esi
  81ef48:	call   824800 <gpui_gpu::renderer::slots::color_word>
  81ef4d:	mov    %eax,0x260(%rsp)
  81ef54:	xorps  %xmm0,%xmm0
  81ef57:	movaps %xmm0,0x300(%rsp)
  81ef5f:	movl   $0x0,0xd8(%rsp)
  81ef6a:	movsd  0x2c8(%rsp),%xmm0
  81ef73:	cvtsd2ss %xmm0,%xmm0
  81ef77:	movapd 0x390(%rsp),%xmm1
  81ef80:	unpcklpd 0x2f0(%rsp),%xmm1
  81ef89:	cvtpd2ps %xmm1,%xmm1
  81ef8d:	movsd  0x98(%rsp),%xmm2
  81ef96:	cvtsd2ss %xmm2,%xmm2
  81ef9a:	movapd 0x470(%rsp),%xmm3
  81efa3:	unpcklpd 0x220(%rsp),%xmm3
  81efac:	cvtpd2ps %xmm3,%xmm3
  81efb0:	mov    0x40(%rsp),%rcx
  81efb5:	mov    %rcx,%rax
  81efb8:	shr    $0x20,%rax
  81efbc:	mov    0x8(%rsp),%rdx
  81efc1:	mov    0x8(%rdx),%rsi
  81efc5:	mov    0x10(%rdx),%rdx
  81efc9:	movlpd %xmm3,0x130(%rsp)
  81efd2:	movss  %xmm2,0x138(%rsp)
  81efdb:	mov    %ecx,0x13c(%rsp)
  81efe2:	movlpd %xmm1,0x140(%rsp)
  81efeb:	movss  %xmm0,0x148(%rsp)
  81eff4:	mov    %eax,0x14c(%rsp)
  81effb:	lea    0x2d0(%rsp),%rdi
  81f003:	mov    0x80(%rsp),%r13
  81f00b:	mov    %r13,%rcx
  81f00e:	lea    0x130(%rsp),%rbx
  81f016:	mov    %rbx,%r8
  81f019:	call   81b730 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81f01e:	mov    0x8(%rsp),%rax
  81f023:	mov    0x8(%rax),%rsi
  81f027:	mov    0x10(%rax),%rdx
  81f02b:	mov    0x110(%rsp),%rax
  81f033:	lea    0x0(%r13,%rax,1),%rcx
  81f038:	movaps 0x480(%rsp),%xmm0
  81f040:	movaps %xmm0,0x130(%rsp)
  81f048:	mov    0x260(%rsp),%eax
  81f04f:	mov    %eax,0x140(%rsp)
  81f056:	mov    0xd8(%rsp),%eax
  81f05d:	mov    %eax,0x144(%rsp)
  81f064:	movaps 0x300(%rsp),%xmm0
  81f06c:	movlps %xmm0,0x148(%rsp)
  81f074:	lea    0x2d0(%rsp),%rdi
  81f07c:	mov    %rbx,%r8
  81f07f:	call   81b730 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81f084:	add    $0x2,%r13
  81f088:	mov    %r13,0x80(%rsp)
  81f090:	cmpb   $0x2,0x70(%rsp)
  81f095:	sete   0x260(%rsp)
  81f09d:	cmpq   $0x0,0x310(%rsp)
  81f0a6:	setne  0x310(%rsp)
  81f0ae:	mov    0x28(%rsp),%rax
  81f0b3:	mov    %rax,0x130(%rsp)
  81f0bb:	mov    0xa8(%rsp),%rax
  81f0c3:	mov    %rax,0x138(%rsp)
  81f0cb:	mov    0xe0(%rsp),%rax
  81f0d3:	mov    %rax,0x140(%rsp)
  81f0db:	movaps 0x270(%rsp),%xmm0
  81f0e3:	movdqa 0x280(%rsp),%xmm1
  81f0ec:	movdqa 0x290(%rsp),%xmm2
  81f0f5:	lea    0x148(%rsp),%rcx
  81f0fd:	movdqu %xmm2,0x20(%rcx)
  81f102:	movdqu %xmm1,0x10(%rcx)
  81f107:	movups %xmm0,(%rcx)
  81f10a:	movaps 0x330(%rsp),%xmm0
  81f112:	lea    0x178(%rsp),%rax
  81f11a:	movups %xmm0,(%rax)
  81f11d:	movaps 0x320(%rsp),%xmm0
  81f125:	movups %xmm0,0x40(%rcx)
  81f129:	mov    %rbx,%rdi
  81f12c:	call   *0x66211e(%rip)        # e81250 <_DYNAMIC+0x5c0>
  81f132:	mov    %eax,0x70(%rsp)
  81f136:	mov    0x8(%rsp),%r13
  81f13b:	mov    0x8(%r13),%rsi
  81f13f:	mov    0x10(%r13),%rdx
  81f143:	movdqa 0xc0(%rsp),%xmm0
  81f14c:	movdqa %xmm0,0x130(%rsp)
  81f155:	lea    0x230(%rsp),%rdi
  81f15d:	mov    %rbx,%r8
  81f160:	mov    0x10(%rsp),%rbx
  81f165:	mov    %rbx,%rcx
  81f168:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f16d:	lea    0x1(%rbx),%rcx
  81f171:	mov    0x10(%r13),%rdx
  81f175:	cmp    %rdx,%rcx
  81f178:	jae    820462 <<gpui_gpu::renderer::RendererState>::render+0x23b2>
  81f17e:	mov    0xb0(%rsp),%rsi
  81f186:	mov    %esi,%edi
  81f188:	or     $0x80000000,%edi
  81f18e:	cmpl   $0x0,0x70(%rsp)
  81f193:	cmove  %esi,%edi
  81f196:	mov    0x8(%r13),%rsi
  81f19a:	mov    0x128(%rsp),%r13
  81f1a2:	mov    0x8(%rsi,%r13,2),%r8d
  81f1a7:	mov    %r8d,0x138(%rsp)
  81f1af:	mov    (%rsi,%r13,2),%r8
  81f1b3:	mov    %r8,0x130(%rsp)
  81f1bb:	mov    %edi,0x13c(%rsp)
  81f1c2:	lea    0x230(%rsp),%rdi
  81f1ca:	lea    0x130(%rsp),%r8
  81f1d2:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f1d7:	lea    0x130(%rsp),%rdi
  81f1df:	mov    0x8(%rsp),%rsi
  81f1e4:	lea    0x4d0(%rsp),%rdx
  81f1ec:	mov    0x40(%rsp),%rcx
  81f1f1:	mov    %rbx,0x10(%rsp)
  81f1f6:	mov    %ebx,%r8d
  81f1f9:	mov    0x88(%rsp),%rbx
  81f201:	mov    %rbx,%r9
  81f204:	push   0x118(%rsp)
  81f20b:	push   %r15
  81f20d:	push   %r14
  81f20f:	push   0xa8(%rsp)
  81f216:	call   8204e0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f21b:	add    $0x20,%rsp
  81f21f:	mov    0x130(%rsp),%eax
  81f226:	cmp    $0xffffffff,%eax
  81f229:	jne    81f420 <<gpui_gpu::renderer::RendererState>::render+0x1370>
  81f22f:	movzbl 0x260(%rsp),%ecx
  81f237:	and    0x310(%rsp),%cl
  81f23e:	mov    0x68(%rsp),%rax
  81f243:	or     %cl,%al
  81f245:	mov    %rax,0x68(%rsp)
  81f24a:	addq   $0x2,0x10(%rsp)
  81f250:	mov    0x138(%rsp),%rax
  81f258:	mov    %rax,0x118(%rsp)
  81f260:	inc    %rbx
  81f263:	mov    %rbx,0x88(%rsp)
  81f26b:	lea    0x3a0(%rsp),%rdi
  81f273:	lea    0x240(%rsp),%rsi
  81f27b:	call   821d60 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81f280:	movzbl 0x3a8(%rsp),%r8d
  81f289:	add    $0x10,%r13
  81f28d:	mov    %r13,0x128(%rsp)
  81f295:	cmp    $0xff,%r8b
  81f299:	jne    81ec1f <<gpui_gpu::renderer::RendererState>::render+0xb6f>
  81f29f:	mov    0x68(%rsp),%rax
  81f2a4:	and    $0x1,%al
  81f2a6:	mov    %rax,0x68(%rsp)
  81f2ab:	mov    0x80(%rsp),%rax
  81f2b3:	mov    %rax,0x20(%rsp)
  81f2b8:	lea    0x408(%rsp),%rdi
  81f2c0:	lea    0x368(%rsp),%rsi
  81f2c8:	call   *0x661f7a(%rip)        # e81248 <_DYNAMIC+0x5b8>
  81f2ce:	mov    0x408(%rsp),%rax
  81f2d6:	mov    %rax,0x28(%rsp)
  81f2db:	test   %rax,%rax
  81f2de:	jne    81e899 <<gpui_gpu::renderer::RendererState>::render+0x7e9>
  81f2e4:	jmp    81f31f <<gpui_gpu::renderer::RendererState>::render+0x126f>
  81f2e6:	movq   $0x0,0x2b0(%rsp)
  81f2f2:	movq   $0x0,0x2a8(%rsp)
  81f2fe:	movq   $0x0,0x88(%rsp)
  81f30a:	movq   $0x0,0x68(%rsp)
  81f313:	movq   $0x0,0x118(%rsp)
  81f31f:	mov    0xa0(%rsp),%rsi
  81f327:	lea    0x8(%rsi),%rdx
  81f32b:	mov    0x8(%rsp),%rax
  81f330:	lea    0x258(%rax),%rcx
  81f337:	lea    0x328(%rax),%r8
  81f33e:	mov    0x10(%rax),%r9
  81f342:	sub    $0x8,%rsp
  81f346:	lea    0x138(%rsp),%rdi
  81f34e:	mov    %rdx,0x2f8(%rsp)
  81f356:	mov    %rcx,0xa0(%rsp)
  81f35e:	mov    %r8,0x488(%rsp)
  81f366:	push   0x128(%rsp)
  81f36d:	call   823ac0 <gpui_gpu::renderer::images::prepare>
  81f372:	add    $0x10,%rsp
  81f376:	mov    0x130(%rsp),%eax
  81f37d:	movzbl 0x134(%rsp),%ecx
  81f385:	mov    %cl,0x390(%rsp)
  81f38c:	cmp    $0xffffffff,%eax
  81f38f:	je     81f3e8 <<gpui_gpu::renderer::RendererState>::render+0x1338>
  81f391:	movupd 0x135(%rsp),%xmm0
  81f39a:	movups 0x140(%rsp),%xmm1
  81f3a2:	mov    0x50(%rsp),%rdi
  81f3a7:	movups %xmm1,0x10(%rdi)
  81f3ab:	movupd %xmm0,0x5(%rdi)
  81f3b0:	mov    %eax,(%rdi)
  81f3b2:	movzbl 0x390(%rsp),%eax
  81f3ba:	mov    %al,0x4(%rdi)
  81f3bd:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3c2:	mov    0x25c(%rsp),%edx
  81f3c9:	mov    0x50(%rsp),%rdi
  81f3ce:	mov    %edx,0x1c(%rdi)
  81f3d1:	movups 0x24c(%rsp),%xmm0
  81f3d9:	movups %xmm0,0xc(%rdi)
  81f3dd:	mov    %ecx,(%rdi)
  81f3df:	mov    %rax,0x4(%rdi)
  81f3e3:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3e8:	movzbl 0x68(%rsp),%r8d
  81f3ee:	and    $0x1,%r8d
  81f3f2:	lea    0x130(%rsp),%rdi
  81f3fa:	mov    0x8(%rsp),%rsi
  81f3ff:	mov    0xa0(%rsp),%rdx
  81f407:	mov    0x100(%rsp),%rcx
  81f40f:	call   81d810 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f414:	mov    0x130(%rsp),%eax
  81f41b:	cmp    $0xffffffff,%eax
  81f41e:	je     81f47b <<gpui_gpu::renderer::RendererState>::render+0x13cb>
  81f420:	mov    0x134(%rsp),%ecx
  81f427:	mov    0x138(%rsp),%rdx
  81f42f:	movupd 0x140(%rsp),%xmm0
  81f438:	mov    0x50(%rsp),%rdi
  81f43d:	movupd %xmm0,0x10(%rdi)
  81f442:	mov    %eax,(%rdi)
  81f444:	mov    %ecx,0x4(%rdi)
  81f447:	mov    %rdx,0x8(%rdi)
  81f44b:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f450:	mov    0x14c(%rsp),%ecx
  81f457:	mov    0x50(%rsp),%rdi
  81f45c:	mov    %ecx,0x1c(%rdi)
  81f45f:	movups 0x13c(%rsp),%xmm0
  81f467:	movups %xmm0,0xc(%rdi)
  81f46b:	mov    %eax,(%rdi)
  81f46d:	mov    0x40(%rsp),%rax
  81f472:	mov    %rax,0x4(%rdi)
  81f476:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f47b:	mov    0x138(%rsp),%rax
  81f483:	mov    %rax,0x2c8(%rsp)
  81f48b:	mov    0x8(%rsp),%rax
  81f490:	mov    0x28(%rax),%rax
  81f494:	movq   $0x0,0x220(%rsp)
  81f4a0:	test   %rax,%rax
  81f4a3:	je     81f548 <<gpui_gpu::renderer::RendererState>::render+0x1498>
  81f4a9:	mov    0x8(%rsp),%rcx
  81f4ae:	mov    0x20(%rcx),%rcx
  81f4b2:	shl    $0x3,%rax
  81f4b6:	xor    %edi,%edi
  81f4b8:	jmp    81f4f9 <<gpui_gpu::renderer::RendererState>::render+0x1449>
  81f4ba:	and    $0x40000000,%edx
  81f4c0:	mov    0x220(%rsp),%r9
  81f4c8:	add    %esi,%r9d
  81f4cb:	xor    %esi,%esi
  81f4cd:	test   %r8d,%r8d
  81f4d0:	setne  %sil
  81f4d4:	shl    $0x1d,%esi
  81f4d7:	or     %r9d,%edx
  81f4da:	or     %esi,%edx
  81f4dc:	mov    %r9,0x220(%rsp)
  81f4e4:	mov    %r9d,(%rcx,%rdi,8)
  81f4e8:	mov    %edx,%r9d
  81f4eb:	mov    %r9d,0x4(%rcx,%rdi,8)
  81f4f0:	inc    %rdi
  81f4f3:	add    $0xfffffffffffffff8,%rax
  81f4f7:	je     81f536 <<gpui_gpu::renderer::RendererState>::render+0x1486>
  81f4f9:	mov    0x8(%rsp),%rdx
  81f4fe:	mov    0x58(%rdx),%rsi
  81f502:	cmp    %rsi,%rdi
  81f505:	jae    820478 <<gpui_gpu::renderer::RendererState>::render+0x23c8>
  81f50b:	mov    0x4(%rcx,%rdi,8),%edx
  81f50f:	mov    %edx,%esi
  81f511:	and    $0xbfffffff,%esi
  81f517:	mov    0x8(%rsp),%r8
  81f51c:	mov    0x50(%r8),%r8
  81f520:	mov    (%r8,%rdi,4),%r8d
  81f524:	cmp    $0x1,%esi
  81f527:	jne    81f4ba <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f529:	mov    $0x80000000,%r9d
  81f52f:	test   %r8d,%r8d
  81f532:	jne    81f4eb <<gpui_gpu::renderer::RendererState>::render+0x143b>
  81f534:	jmp    81f4ba <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f536:	mov    0x220(%rsp),%rax
  81f53e:	mov    %eax,%eax
  81f540:	mov    %rax,0x220(%rsp)
  81f548:	mov    0x8(%rsp),%rax
  81f54d:	lea    0x30(%rax),%rdi
  81f551:	movq   $0x0,0x40(%rax)
  81f559:	mov    %rdi,0xd8(%rsp)
  81f561:	mov    0x220(%rsp),%rsi
  81f569:	xor    %edx,%edx
  81f56b:	call   823970 <<alloc::vec::Vec<u32>>::resize>
  81f570:	mov    0x88(%rsp),%rax
  81f578:	mov    %rax,0x360(%rsp)
  81f580:	mov    0x100(%rsp),%rax
  81f588:	mov    %rax,0x368(%rsp)
  81f590:	movq   $0x0,0x370(%rsp)
  81f59c:	mov    0x108(%rsp),%rax
  81f5a4:	mov    %rax,0x378(%rsp)
  81f5ac:	mov    0x340(%rsp),%rax
  81f5b4:	mov    %rax,0x380(%rsp)
  81f5bc:	mov    0x30(%rsp),%eax
  81f5c0:	mov    %eax,0x388(%rsp)
  81f5c7:	lea    0x408(%rsp),%rdi
  81f5cf:	lea    0x368(%rsp),%rsi
  81f5d7:	call   *0x661c7b(%rip)        # e81258 <_DYNAMIC+0x5c8>
  81f5dd:	mov    0x408(%rsp),%rax
  81f5e5:	mov    %rax,0x80(%rsp)
  81f5ed:	test   %rax,%rax
  81f5f0:	je     81fb78 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f5f6:	mov    0x8(%rsp),%rax
  81f5fb:	add    $0x120,%rax
  81f601:	mov    %rax,0x470(%rsp)
  81f609:	mov    0x2b8(%rsp),%rax
  81f611:	mov    %rax,0xb0(%rsp)
  81f619:	jmp    81f64a <<gpui_gpu::renderer::RendererState>::render+0x159a>
  81f61b:	lea    0x408(%rsp),%rdi
  81f623:	lea    0x368(%rsp),%rsi
  81f62b:	call   *0x661c27(%rip)        # e81258 <_DYNAMIC+0x5c8>
  81f631:	mov    0x408(%rsp),%rax
  81f639:	mov    %rax,0x80(%rsp)
  81f641:	test   %rax,%rax
  81f644:	je     81fb78 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f64a:	lea    0x420(%rsp),%rsi
  81f652:	movups (%rsi),%xmm0
  81f655:	movups 0x10(%rsi),%xmm1
  81f659:	movups 0x20(%rsi),%xmm2
  81f65d:	movaps %xmm2,0x3c0(%rsp)
  81f665:	movaps %xmm1,0x3b0(%rsp)
  81f66d:	movaps %xmm0,0x3a0(%rsp)
  81f675:	lea    0x450(%rsp),%rdx
  81f67d:	movups (%rdx),%xmm0
  81f680:	movaps %xmm0,0x320(%rsp)
  81f688:	movdqu 0x40(%rsi),%xmm0
  81f68d:	movdqa %xmm0,0x330(%rsp)
  81f696:	mov    0x410(%rsp),%rax
  81f69e:	mov    %rax,0xe0(%rsp)
  81f6a6:	mov    0x418(%rsp),%rbx
  81f6ae:	mov    0x8(%rsp),%rdi
  81f6b3:	call   81d430 <<gpui_gpu::renderer::RendererState>::correction>
  81f6b8:	mov    %eax,0x300(%rsp)
  81f6bf:	test   %rbx,%rbx
  81f6c2:	je     81f61b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f6c8:	mov    %rbx,%rcx
  81f6cb:	shl    $0x2,%rcx
  81f6cf:	mov    0x300(%rsp),%eax
  81f6d6:	shl    $0xf,%eax
  81f6d9:	mov    %eax,0x20(%rsp)
  81f6dd:	mov    0xb0(%rsp),%rax
  81f6e5:	shl    $0x4,%rax
  81f6e9:	mov    %rax,0x28(%rsp)
  81f6ee:	lea    0x138(%rsp),%rbx
  81f6f6:	lea    0x130(%rsp),%r13
  81f6fe:	jmp    81f8c7 <<gpui_gpu::renderer::RendererState>::render+0x1817>
  81f703:	mov    0x60(%rsp),%r9d
  81f708:	or     0x20(%rsp),%r9d
  81f70d:	mov    %r9d,0x60(%rsp)
  81f712:	mov    0x64(%rsp),%r8d
  81f717:	mov    %edi,0x130(%rsp)
  81f71e:	mov    %r9d,0x134(%rsp)
  81f726:	mov    %r8d,0x138(%rsp)
  81f72e:	mov    %eax,0x13c(%rsp)
  81f735:	lea    0x230(%rsp),%rdi
  81f73d:	mov    %rbx,%r8
  81f740:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f745:	add    $0xfffffffffffffffe,%r13
  81f749:	mov    %r13,0xb0(%rsp)
  81f751:	mov    %r13d,0x2ec(%rsp)
  81f759:	movaps 0x260(%rsp),%xmm0
  81f761:	movlps %xmm0,0x170(%rsp)
  81f769:	movaps 0x3a0(%rsp),%xmm0
  81f771:	movaps 0x3b0(%rsp),%xmm1
  81f779:	movaps 0x3c0(%rsp),%xmm2
  81f781:	lea    0x178(%rsp),%rax
  81f789:	movups %xmm2,0x20(%rax)
  81f78d:	movups %xmm1,0x10(%rax)
  81f791:	movups %xmm0,(%rax)
  81f794:	movaps 0x320(%rsp),%xmm0
  81f79c:	movups %xmm0,0x30(%rax)
  81f7a0:	movaps 0x490(%rsp),%xmm0
  81f7a8:	movups %xmm0,0x40(%rax)
  81f7ac:	movaps 0x330(%rsp),%xmm0
  81f7b4:	movups %xmm0,0x50(%rax)
  81f7b8:	mov    0x128(%rsp),%eax
  81f7bf:	mov    %al,0x130(%rsp)
  81f7c6:	movzbl 0x30(%rsp),%eax
  81f7cb:	mov    %al,0x131(%rsp)
  81f7d2:	movzwl 0xa8(%rsp),%eax
  81f7da:	mov    %ax,0x132(%rsp)
  81f7e2:	movaps 0xc0(%rsp),%xmm0
  81f7ea:	movss  %xmm0,0x134(%rsp)
  81f7f3:	mov    0x250(%rsp),%rax
  81f7fb:	mov    %rbx,%r13
  81f7fe:	lea    0x138(%rsp),%rbx
  81f806:	mov    %rax,0x10(%rbx)
  81f80a:	movaps 0x240(%rsp),%xmm0
  81f812:	movups %xmm0,(%rbx)
  81f815:	mov    0x10(%rsp),%rax
  81f81a:	mov    %rax,0x150(%rsp)
  81f822:	mov    0x40(%rsp),%eax
  81f826:	mov    %eax,0x158(%rsp)
  81f82d:	mov    0x70(%rsp),%eax
  81f831:	mov    %eax,0x15c(%rsp)
  81f838:	movdqa 0x310(%rsp),%xmm0
  81f841:	movdqu %xmm0,0x160(%rsp)
  81f84a:	mov    0x4c8(%rsp),%rax
  81f852:	mov    %rax,0x270(%rsp)
  81f85a:	mov    0xd8(%rsp),%rax
  81f862:	mov    %rax,0x278(%rsp)
  81f86a:	mov    0x4c0(%rsp),%rax
  81f872:	mov    %rax,0x280(%rsp)
  81f87a:	lea    0x360(%rsp),%rax
  81f882:	mov    %rax,0x288(%rsp)
  81f88a:	lea    0x2ec(%rsp),%rax
  81f892:	mov    %rax,0x290(%rsp)
  81f89a:	mov    %r13,%rdi
  81f89d:	mov    0x90(%rsp),%rsi
  81f8a5:	lea    0x270(%rsp),%rdx
  81f8ad:	call   81c560 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f8b2:	addq   $0xffffffffffffffe0,0x28(%rsp)
  81f8b8:	mov    0x68(%rsp),%rcx
  81f8bd:	add    $0xfffffffffffffffc,%rcx
  81f8c1:	je     81f61b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f8c7:	mov    0xe0(%rsp),%rax
  81f8cf:	mov    %rcx,0x68(%rsp)
  81f8d4:	mov    -0x4(%rax,%rcx,1),%edx
  81f8d8:	mov    %r13,%rdi
  81f8db:	mov    0x80(%rsp),%rsi
  81f8e3:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f8e8:	movzbl 0x130(%rsp),%ecx
  81f8f0:	movzbl 0x131(%rsp),%eax
  81f8f8:	mov    %al,0x30(%rsp)
  81f8fc:	movzwl 0x132(%rsp),%eax
  81f904:	mov    %ax,0xa8(%rsp)
  81f90c:	movss  0x134(%rsp),%xmm4
  81f915:	mov    0x10(%rbx),%rax
  81f919:	mov    %rax,0x250(%rsp)
  81f921:	movups (%rbx),%xmm0
  81f924:	movaps %xmm0,0x240(%rsp)
  81f92c:	mov    0x150(%rsp),%rax
  81f934:	mov    %rax,0x10(%rsp)
  81f939:	mov    0x158(%rsp),%eax
  81f940:	mov    %eax,0x40(%rsp)
  81f944:	mov    0x15c(%rsp),%eax
  81f94b:	mov    %eax,0x70(%rsp)
  81f94f:	movups 0x160(%rsp),%xmm0
  81f957:	movaps %xmm0,0x310(%rsp)
  81f95f:	mov    0x160(%rsp),%rax
  81f967:	movsd  0x170(%rsp),%xmm5
  81f970:	lea    0x178(%rsp),%rdx
  81f978:	movups (%rdx),%xmm0
  81f97b:	movaps %xmm0,0x490(%rsp)
  81f983:	decq   0x360(%rsp)
  81f98b:	cmp    $0x1,%ecx
  81f98e:	mov    %ecx,0x128(%rsp)
  81f995:	movaps %xmm4,0xc0(%rsp)
  81f99d:	movaps %xmm5,0x260(%rsp)
  81f9a5:	je     81fa0b <<gpui_gpu::renderer::RendererState>::render+0x195b>
  81f9a7:	cmp    $0x3,%ecx
  81f9aa:	jne    81fa87 <<gpui_gpu::renderer::RendererState>::render+0x19d7>
  81f9b0:	mov    0x480(%rsp),%rax
  81f9b8:	mov    (%rax),%rdi
  81f9bb:	test   %rdi,%rdi
  81f9be:	je     82042b <<gpui_gpu::renderer::RendererState>::render+0x237b>
  81f9c4:	movzbl 0x30(%rsp),%edx
  81f9c9:	mov    0x10(%rsp),%rsi
  81f9ce:	call   823660 <<gpui_gpu::renderer::images::Images>::metadata>
  81f9d3:	mov    %eax,%ecx
  81f9d5:	shr    $0x20,%rax
  81f9d9:	mov    %eax,%edx
  81f9db:	or     $0x10,%edx
  81f9de:	xorps  %xmm0,%xmm0
  81f9e1:	movaps 0xc0(%rsp),%xmm1
  81f9e9:	ucomiss %xmm0,%xmm1
  81f9ec:	cmovne %edx,%eax
  81f9ef:	cmovp  %edx,%eax
  81f9f2:	mov    0x70(%rsp),%edx
  81f9f6:	shl    $0x10,%edx
  81f9f9:	or     0x40(%rsp),%edx
  81f9fd:	mov    %ecx,0x5c(%rsp)
  81fa01:	mov    %eax,0x60(%rsp)
  81fa05:	mov    %edx,0x64(%rsp)
  81fa09:	jmp    81fa7a <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  81fa0b:	movaps %xmm5,%xmm0
  81fa0e:	movss  -0x770a4a(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81fa16:	mulss  %xmm3,%xmm0
  81fa1a:	movaps %xmm4,%xmm1
  81fa1d:	minss  %xmm0,%xmm1
  81fa21:	movaps %xmm1,%xmm0
  81fa24:	cmpunordss %xmm1,%xmm0
  81fa29:	movaps %xmm0,%xmm2
  81fa2c:	andnps %xmm1,%xmm2
  81fa2f:	andps  %xmm4,%xmm0
  81fa32:	orps   %xmm2,%xmm0
  81fa35:	movaps %xmm5,%xmm1
  81fa38:	shufps $0x55,%xmm5,%xmm1
  81fa3c:	mulss  %xmm3,%xmm1
  81fa40:	movaps %xmm0,%xmm2
  81fa43:	minss  %xmm1,%xmm2
  81fa47:	movaps %xmm2,%xmm1
  81fa4a:	cmpunordss %xmm2,%xmm1
  81fa4f:	andps  %xmm1,%xmm0
  81fa52:	andnps %xmm2,%xmm1
  81fa55:	orps   %xmm0,%xmm1
  81fa58:	movd   %xmm1,%eax
  81fa5c:	and    $0xff800000,%eax
  81fa61:	mov    $0x7f000000,%ecx
  81fa66:	sub    %eax,%ecx
  81fa68:	movl   $0x40000000,0x5c(%rsp)
  81fa70:	movss  %xmm1,0x60(%rsp)
  81fa76:	mov    %ecx,0x64(%rsp)
  81fa7a:	lea    0x130(%rsp),%rbx
  81fa82:	jmp    81fb21 <<gpui_gpu::renderer::RendererState>::render+0x1a71>
  81fa87:	cmp    $0x2,%cl
  81fa8a:	jne    81fad9 <<gpui_gpu::renderer::RendererState>::render+0x1a29>
  81fa8c:	mov    0x250(%rsp),%rcx
  81fa94:	mov    %rcx,0x140(%rsp)
  81fa9c:	movaps 0x240(%rsp),%xmm0
  81faa4:	movaps %xmm0,0x130(%rsp)
  81faac:	mov    0x10(%rsp),%rcx
  81fab1:	mov    %rcx,0x148(%rsp)
  81fab9:	mov    0x40(%rsp),%ecx
  81fabd:	mov    %ecx,0x150(%rsp)
  81fac4:	mov    0x70(%rsp),%ecx
  81fac8:	mov    %ecx,0x154(%rsp)
  81facf:	mov    %rax,0x158(%rsp)
  81fad7:	jmp    81fae5 <<gpui_gpu::renderer::RendererState>::render+0x1a35>
  81fad9:	movq   $0x0,0x130(%rsp)
  81fae5:	movl   $0x0,0x278(%rsp)
  81faf0:	movq   $0x0,0x270(%rsp)
  81fafc:	lea    0x5c(%rsp),%rdi
  81fb01:	lea    0x130(%rsp),%rbx
  81fb09:	mov    %rbx,%rsi
  81fb0c:	lea    0x270(%rsp),%rdx
  81fb14:	mov    0x470(%rsp),%rcx
  81fb1c:	call   81b570 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fb21:	mov    0xb0(%rsp),%r13
  81fb29:	lea    -0x1(%r13),%rcx
  81fb2d:	mov    0x8(%rsp),%rax
  81fb32:	mov    0x10(%rax),%rdx
  81fb36:	cmp    %rdx,%rcx
  81fb39:	jae    82044c <<gpui_gpu::renderer::RendererState>::render+0x239c>
  81fb3f:	mov    0x8(%rax),%rsi
  81fb43:	mov    0x28(%rsp),%rax
  81fb48:	mov    -0x4(%rsi,%rax,1),%eax
  81fb4c:	mov    0x5c(%rsp),%edi
  81fb50:	cmp    $0x40000000,%edi
  81fb56:	jne    81f703 <<gpui_gpu::renderer::RendererState>::render+0x1653>
  81fb5c:	mov    0x64(%rsp),%r8d
  81fb61:	or     0x300(%rsp),%r8d
  81fb69:	mov    %r8d,0x64(%rsp)
  81fb6e:	mov    0x60(%rsp),%r9d
  81fb73:	jmp    81f717 <<gpui_gpu::renderer::RendererState>::render+0x1667>
  81fb78:	mov    0x8(%rsp),%rax
  81fb7d:	mov    0x28(%rax),%rdi
  81fb81:	xor    %ebx,%ebx
  81fb83:	test   %rdi,%rdi
  81fb86:	je     81fc95 <<gpui_gpu::renderer::RendererState>::render+0x1be5>
  81fb8c:	mov    0x8(%rsp),%rax
  81fb91:	mov    0x20(%rax),%r8
  81fb95:	shl    $0x3,%rdi
  81fb99:	cmpl   $0x0,0x90(%rsp)
  81fba1:	je     81fe90 <<gpui_gpu::renderer::RendererState>::render+0x1de0>
  81fba7:	movq   $0x0,0x40(%rsp)
  81fbb0:	movq   $0x0,0x70(%rsp)
  81fbb9:	movq   $0x0,0x10(%rsp)
  81fbc2:	xor    %r10d,%r10d
  81fbc5:	xor    %ecx,%ecx
  81fbc7:	jmp    81fbef <<gpui_gpu::renderer::RendererState>::render+0x1b3f>
  81fbc9:	incq   0x10(%rsp)
  81fbce:	inc    %r10
  81fbd1:	cmp    0x90(%rsp),%r10
  81fbd9:	mov    $0x0,%eax
  81fbde:	cmove  %rax,%r10
  81fbe2:	inc    %rcx
  81fbe5:	add    $0xfffffffffffffff8,%rdi
  81fbe9:	je     81fcb0 <<gpui_gpu::renderer::RendererState>::render+0x1c00>
  81fbef:	mov    0x4(%r8,%rcx,8),%r11d
  81fbf4:	mov    $0x80000000,%eax
  81fbf9:	cmp    %rax,%r11
  81fbfc:	je     81fbc9 <<gpui_gpu::renderer::RendererState>::render+0x1b19>
  81fbfe:	mov    %r11d,%esi
  81fc01:	and    $0x1fffffff,%esi
  81fc07:	sub    (%r8,%rcx,8),%esi
  81fc0b:	je     81fbce <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc0d:	mov    %rcx,%rax
  81fc10:	shr    $0x20,%rax
  81fc14:	je     81fc28 <<gpui_gpu::renderer::RendererState>::render+0x1b78>
  81fc16:	mov    %rcx,%rax
  81fc19:	xor    %edx,%edx
  81fc1b:	divq   0x90(%rsp)
  81fc23:	mov    %r10,%rdx
  81fc26:	jmp    81fc33 <<gpui_gpu::renderer::RendererState>::render+0x1b83>
  81fc28:	mov    %ecx,%eax
  81fc2a:	xor    %edx,%edx
  81fc2c:	divl   0x90(%rsp)
  81fc33:	shl    $0x4,%edx
  81fc36:	shl    $0x4,%eax
  81fc39:	lea    0x10(%rdx),%r13d
  81fc3d:	cmp    %r13d,%r14d
  81fc40:	cmovb  %r14d,%r13d
  81fc44:	lea    0x10(%rax),%r9d
  81fc48:	cmp    %r9d,%r15d
  81fc4b:	cmovb  %r15d,%r9d
  81fc4f:	sub    %edx,%r13d
  81fc52:	sub    %eax,%r9d
  81fc55:	imul   %r13d,%r9d
  81fc59:	mov    %r9,%rax
  81fc5c:	shl    $0x4,%rax
  81fc60:	test   $0x40000000,%r11d
  81fc67:	cmovne %r9,%rax
  81fc6b:	shr    $0x1d,%r11d
  81fc6f:	and    $0x1,%r11d
  81fc73:	add    %rax,0x70(%rsp)
  81fc78:	imul   %r11,%r9
  81fc7c:	sub    %r11,%rsi
  81fc7f:	imul   %rax,%rsi
  81fc83:	add    0x40(%rsp),%r9
  81fc88:	add    %rsi,%r9
  81fc8b:	mov    %r9,0x40(%rsp)
  81fc90:	jmp    81fbce <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc95:	movq   $0x0,0x10(%rsp)
  81fc9e:	movq   $0x0,0x70(%rsp)
  81fca7:	movq   $0x0,0x40(%rsp)
  81fcb0:	test   $0x1,%bpl
  81fcb4:	je     81fd01 <<gpui_gpu::renderer::RendererState>::render+0x1c51>
  81fcb6:	movd   0x2e8(%rsp),%xmm0
  81fcbf:	movd   %xmm0,%eax
  81fcc3:	test   %eax,%eax
  81fcc5:	setns  %cl
  81fcc8:	mov    %eax,%edx
  81fcca:	and    $0x7fffffff,%edx
  81fcd0:	add    $0xff800000,%edx
  81fcd6:	cmp    $0x7f000000,%edx
  81fcdc:	setb   %dl
  81fcdf:	and    %cl,%dl
  81fce1:	dec    %eax
  81fce3:	cmp    $0x7fffff,%eax
  81fce8:	setb   %al
  81fceb:	or     %dl,%al
  81fced:	mov    $0x2,%ebx
  81fcf2:	movd   %xmm0,0xf4(%rsp)
  81fcfb:	je     81fe86 <<gpui_gpu::renderer::RendererState>::render+0x1dd6>
  81fd01:	mov    0x120(%rsp),%rax
  81fd09:	add    $0x18,%rax
  81fd0d:	xor    %ecx,%ecx
  81fd0f:	cmpl   $0x28,0x2e4(%rsp)
  81fd17:	sete   %cl
  81fd1a:	and    $0x1,%r12d
  81fd1e:	lea    (%r12,%rcx,4),%ecx
  81fd22:	or     %ebx,%ecx
  81fd24:	movups (%rax),%xmm0
  81fd27:	movups %xmm0,0x418(%rsp)
  81fd2f:	mov    %r14d,0x408(%rsp)
  81fd37:	mov    %r15d,0x40c(%rsp)
  81fd3f:	mov    0x90(%rsp),%rax
  81fd47:	mov    %eax,0x410(%rsp)
  81fd4e:	mov    %ecx,0x414(%rsp)
  81fd55:	movss  0xf4(%rsp),%xmm0
  81fd5e:	movss  %xmm0,0x428(%rsp)
  81fd67:	mov    0x110(%rsp),%rax
  81fd6f:	mov    %eax,0x42c(%rsp)
  81fd76:	movq   $0x0,0x430(%rsp)
  81fd82:	mov    0x8(%rsp),%rax
  81fd87:	lea    0x230(%rax),%rsi
  81fd8e:	lea    0x408(%rsp),%rcx
  81fd96:	mov    $0x30,%r8d
  81fd9c:	mov    0x2f0(%rsp),%rdi
  81fda4:	mov    %rsi,0x30(%rsp)
  81fda9:	xor    %edx,%edx
  81fdab:	call   *0x6614af(%rip)        # e81260 <_DYNAMIC+0x5d0>
  81fdb1:	mov    0x2b8(%rsp),%rbx
  81fdb9:	shl    $0x4,%rbx
  81fdbd:	mov    0x98(%rsp),%rdi
  81fdc5:	mov    0xa0(%rsp),%rsi
  81fdcd:	mov    %rbx,%rdx
  81fdd0:	call   81cc10 <<gpui_gpu::renderer::Buffer>::reserve>
  81fdd5:	cmpq   $0x0,0x38(%rsp)
  81fddb:	je     81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fddd:	mov    0x2b8(%rsp),%rcx
  81fde5:	cmp    %rcx,0x348(%rsp)
  81fded:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdef:	test   %al,%al
  81fdf1:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdf3:	testb  $0x1,0x390(%rsp)
  81fdfb:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdfd:	mov    0x2d8(%rsp),%rax
  81fe05:	mov    0x230(%rsp),%rbx
  81fe0d:	mov    0x238(%rsp),%rsi
  81fe15:	cmp    %rbx,%rax
  81fe18:	jne    81fedc <<gpui_gpu::renderer::RendererState>::render+0x1e2c>
  81fe1e:	mov    %rsi,0x2d8(%rsp)
  81fe26:	movq   $0xffffffffffffffff,0x230(%rsp)
  81fe32:	movq   $0x0,0x238(%rsp)
  81fe3e:	mov    $0xffffffffffffffff,%rbx
  81fe45:	movq   $0x0,0x38(%rsp)
  81fe4e:	jmp    81fee4 <<gpui_gpu::renderer::RendererState>::render+0x1e34>
  81fe53:	mov    0x8(%rsp),%rax
  81fe58:	mov    0x8(%rax),%rcx
  81fe5c:	mov    0x10(%rax),%r8
  81fe60:	shl    $0x4,%r8
  81fe64:	mov    0x98(%rsp),%rdi
  81fe6c:	mov    0xa0(%rsp),%rsi
  81fe74:	mov    0x2f0(%rsp),%rdx
  81fe7c:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81fe81:	jmp    81ff42 <<gpui_gpu::renderer::RendererState>::render+0x1e92>
  81fe86:	mov    0x50(%rsp),%rdi
  81fe8b:	jmp    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81fe90:	movq   $0x0,0x70(%rsp)
  81fe99:	xor    %eax,%eax
  81fe9b:	movq   $0x0,0x10(%rsp)
  81fea4:	jmp    81feb8 <<gpui_gpu::renderer::RendererState>::render+0x1e08>
  81fea6:	incq   0x10(%rsp)
  81feab:	add    $0x8,%rax
  81feaf:	cmp    %rax,%rdi
  81feb2:	je     81fca7 <<gpui_gpu::renderer::RendererState>::render+0x1bf7>
  81feb8:	mov    0x4(%r8,%rax,1),%ecx
  81febd:	mov    %ecx,%edx
  81febf:	neg    %edx
  81fec1:	jo     81fea6 <<gpui_gpu::renderer::RendererState>::render+0x1df6>
  81fec3:	and    $0x1fffffff,%ecx
  81fec9:	cmp    %ecx,(%r8,%rax,1)
  81fecd:	je     81feab <<gpui_gpu::renderer::RendererState>::render+0x1dfb>
  81fecf:	lea    0x60fa0a(%rip),%rdi        # e2f8e0 <anon.7e34a6dced7fe4eb77116889a7de5f31.41.llvm.15614097268772730318>
  81fed6:	call   *0x66138c(%rip)        # e81268 <_DYNAMIC+0x5d8>
  81fedc:	mov    %rsi,0x38(%rsp)
  81fee1:	mov    %rax,%rsi
  81fee4:	mov    0x8(%rsp),%r13
  81fee9:	mov    0x8(%r13),%rdx
  81feed:	mov    0x10(%r13),%rcx
  81fef1:	mov    0x2d0(%rsp),%rdi
  81fef9:	mov    0x98(%rsp),%rbp
  81ff01:	mov    %rbp,%r8
  81ff04:	mov    0x2f0(%rsp),%r12
  81ff0c:	mov    %r12,%r9
  81ff0f:	call   81cb60 <<gpui_gpu::renderer::Changes>::upload>
  81ff14:	mov    %rax,0xc0(%rsp)
  81ff1c:	mov    0x8(%r13),%rdx
  81ff20:	mov    0x10(%r13),%rcx
  81ff24:	mov    %rbx,%rdi
  81ff27:	mov    0x38(%rsp),%rsi
  81ff2c:	mov    %rbp,%r8
  81ff2f:	mov    %r12,%r9
  81ff32:	call   81cb60 <<gpui_gpu::renderer::Changes>::upload>
  81ff37:	mov    %rax,%rbx
  81ff3a:	add    0xc0(%rsp),%rbx
  81ff42:	mov    0xa0(%rsp),%r13
  81ff4a:	lea    0x18(%r13),%rax
  81ff4e:	mov    %rax,0x38(%rsp)
  81ff53:	mov    0x8(%rsp),%rbp
  81ff58:	lea    0x280(%rbp),%rdi
  81ff5f:	mov    0x20(%rbp),%rcx
  81ff63:	mov    0x28(%rbp),%r8
  81ff67:	shl    $0x3,%r8
  81ff6b:	mov    %rdi,0xc0(%rsp)
  81ff73:	mov    %r13,%rsi
  81ff76:	mov    0x2f0(%rsp),%r12
  81ff7e:	mov    %r12,%rdx
  81ff81:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ff86:	lea    0x2a8(%rbp),%rdi
  81ff8d:	mov    0x38(%rbp),%rcx
  81ff91:	mov    0x40(%rbp),%r8
  81ff95:	shl    $0x2,%r8
  81ff99:	mov    %rdi,0xb0(%rsp)
  81ffa1:	mov    %r13,%rsi
  81ffa4:	mov    %r12,%rdx
  81ffa7:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ffac:	lea    0x2d0(%rbp),%rdi
  81ffb3:	mov    0x68(%rbp),%rcx
  81ffb7:	mov    0x70(%rbp),%r8
  81ffbb:	shl    $0x5,%r8
  81ffbf:	mov    %rdi,0x28(%rsp)
  81ffc4:	mov    %r13,%rsi
  81ffc7:	mov    %r12,%rdx
  81ffca:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ffcf:	cmpq   $0x0,0x328(%rbp)
  81ffd7:	je     81ffdd <<gpui_gpu::renderer::RendererState>::render+0x1f2d>
  81ffd9:	xor    %eax,%eax
  81ffdb:	jmp    81fff2 <<gpui_gpu::renderer::RendererState>::render+0x1f42>
  81ffdd:	mov    0x8(%rsp),%rax
  81ffe2:	mov    0x10(%rax),%rax
  81ffe6:	cmp    $0x1,%rax
  81ffea:	adc    $0x0,%rax
  81ffee:	shl    $0x4,%rax
  81fff2:	mov    0x8(%rsp),%rdi
  81fff7:	mov    0x28(%rdi),%rsi
  81fffb:	mov    0x40(%rdi),%rcx
  81ffff:	cmp    $0x1,%rsi
  820003:	adc    $0x0,%rsi
  820007:	shl    $0x3,%rsi
  82000b:	cmp    $0x1,%rcx
  82000f:	adc    $0x0,%rcx
  820013:	mov    0x70(%rdi),%rdx
  820017:	cmp    $0x1,%rdx
  82001b:	adc    $0x0,%rdx
  82001f:	add    $0xc8,%rdi
  820026:	shl    $0x2,%rcx
  82002a:	shl    $0x5,%rdx
  82002e:	movq   $0x0,0x130(%rsp)
  82003a:	mov    0x30(%rsp),%r8
  82003f:	mov    %r8,0x138(%rsp)
  820047:	movq   $0x0,0x158(%rsp)
  820053:	xorpd  %xmm0,%xmm0
  820057:	movupd %xmm0,0x140(%rsp)
  820060:	movl   $0x0,0x150(%rsp)
  82006b:	mov    0x98(%rsp),%r8
  820073:	mov    %r8,0x160(%rsp)
  82007b:	movq   $0x0,0x168(%rsp)
  820087:	mov    %rax,0x170(%rsp)
  82008f:	movl   $0x1,0x178(%rsp)
  82009a:	movq   $0x0,0x180(%rsp)
  8200a6:	mov    0xc0(%rsp),%rax
  8200ae:	mov    %rax,0x188(%rsp)
  8200b6:	movq   $0x0,0x190(%rsp)
  8200c2:	mov    %rsi,0x198(%rsp)
  8200ca:	movl   $0x2,0x1a0(%rsp)
  8200d5:	movq   $0x0,0x1a8(%rsp)
  8200e1:	mov    0xb0(%rsp),%rax
  8200e9:	mov    %rax,0x1b0(%rsp)
  8200f1:	movq   $0x0,0x1b8(%rsp)
  8200fd:	mov    %rcx,0x1c0(%rsp)
  820105:	movl   $0x3,0x1c8(%rsp)
  820110:	movq   $0x4,0x1d0(%rsp)
  82011c:	mov    %rdi,0x1d8(%rsp)
  820124:	movl   $0x4,0x1f0(%rsp)
  82012f:	movq   $0x0,0x1f8(%rsp)
  82013b:	mov    0x28(%rsp),%rax
  820140:	mov    %rax,0x200(%rsp)
  820148:	movq   $0x0,0x208(%rsp)
  820154:	mov    %rdx,0x210(%rsp)
  82015c:	movl   $0x5,0x218(%rsp)
  820167:	lea    -0x74b5ae(%rip),%rax        # d4bc0 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82016e:	mov    %rax,0x3b8(%rsp)
  820176:	movq   $0xa,0x3c0(%rsp)
  820182:	mov    0x38(%rsp),%rax
  820187:	mov    %rax,0x3a0(%rsp)
  82018f:	lea    0x130(%rsp),%rax
  820197:	mov    %rax,0x3a8(%rsp)
  82019f:	movq   $0x6,0x3b0(%rsp)
  8201ab:	lea    0x3a0(%rsp),%rsi
  8201b3:	mov    0xa0(%rsp),%r13
  8201bb:	mov    %r13,%rdi
  8201be:	call   *0x6610ac(%rip)        # e81270 <_DYNAMIC+0x5e0>
  8201c4:	mov    %rax,%rbp
  8201c7:	mov    %rax,0x270(%rsp)
  8201cf:	lea    0x270(%rsp),%rdx
  8201d7:	mov    %r13,%rdi
  8201da:	mov    0x4b8(%rsp),%rsi
  8201e2:	call   81d250 <<gpui_gpu::renderer::GpuContext>::submit>
  8201e7:	mov    %rax,0x38(%rsp)
  8201ec:	xor    %r13d,%r13d
  8201ef:	mov    0x350(%rsp),%rax
  8201f7:	cmp    %rax,0x358(%rsp)
  8201ff:	setne  %r13b
  820203:	shl    $0x1f,%r13d
  820207:	or     %r14d,%r13d
  82020a:	shl    $0x20,%r15
  82020e:	or     %r15,%r13
  820211:	mov    0xe8(%rsp),%rax
  820219:	mov    (%rax),%rax
  82021c:	test   %rax,%rax
  82021f:	je     820235 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820221:	lock decq (%rax)
  820225:	jne    820235 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820227:	mov    0xe8(%rsp),%rdi
  82022f:	call   *0x660f73(%rip)        # e811a8 <_DYNAMIC+0x518>
  820235:	mov    0x8(%rsp),%rax
  82023a:	mov    %rbp,0x330(%rax)
  820241:	mov    %r13,0x338(%rax)
  820248:	mov    0x28(%rax),%rsi
  82024c:	mov    0x70(%rax),%rcx
  820250:	mov    %rcx,0xe8(%rsp)
  820258:	mov    0x278(%rax),%rdx
  82025f:	mov    0x220(%rsp),%r8
  820267:	lea    (%rbx,%r8,4),%rdi
  82026b:	lea    (%rdi,%rsi,8),%rsi
  82026f:	mov    %rcx,%rdi
  820272:	shl    $0x5,%rdi
  820276:	lea    (%rdi,%rsi,1),%rcx
  82027a:	add    $0x30,%rcx
  82027e:	mov    %rcx,0x30(%rsp)
  820283:	mov    0x150(%rax),%esi
  820289:	imul   %rsi,%rsi
  82028d:	add    0x250(%rax),%rdx
  820294:	add    0x2a0(%rax),%rdx
  82029b:	add    0x2c8(%rax),%rdx
  8202a2:	add    0x2f0(%rax),%rdx
  8202a9:	mov    0x308(%rax),%rdi
  8202b0:	add    0x310(%rax),%rdi
  8202b7:	mov    0x118(%rsp),%r11
  8202bf:	mov    %r11,%rcx
  8202c2:	sub    %r8,%rcx
  8202c5:	mov    0x88(%rsp),%rbp
  8202cd:	mov    %rbp,%r9
  8202d0:	mov    0x2b0(%rsp),%r13
  8202d8:	sub    %r13,%r9
  8202db:	mov    0x10(%rax),%r10
  8202df:	shl    $0x4,%r10
  8202e3:	mov    0x160(%rax),%rbx
  8202ea:	inc    %rbx
  8202ed:	mov    $0xffffffffffffffff,%r14
  8202f4:	cmovne %rbx,%r14
  8202f8:	mov    (%rax),%rbx
  8202fb:	shl    $0x4,%rbx
  8202ff:	mov    0x48(%rax),%r15
  820303:	add    0x30(%rax),%r15
  820307:	mov    0x18(%rax),%r12
  82030b:	lea    (%rbx,%r12,8),%rbx
  82030f:	lea    (%rbx,%r15,4),%rbx
  820313:	mov    0x60(%rax),%r15
  820317:	shl    $0x5,%r15
  82031b:	add    %rbx,%r15
  82031e:	mov    0x138(%rax),%rbx
  820325:	mov    0x130(%rax),%r12
  82032c:	mov    %r14,0x160(%rax)
  820333:	mov    %rbp,0x168(%rax)
  82033a:	lea    (%r11,%r11,1),%r14
  82033e:	mov    %r14,0x170(%rax)
  820345:	movq   $0x1,0x178(%rax)
  820350:	mov    %rbp,0x180(%rax)
  820357:	mov    %r8,0x188(%rax)
  82035e:	mov    %r11,0x190(%rax)
  820365:	mov    %rcx,0x198(%rax)
  82036c:	mov    0x10(%rsp),%rcx
  820371:	mov    %rcx,0x1a0(%rax)
  820378:	mov    0x70(%rsp),%rcx
  82037d:	mov    %rcx,0x1a8(%rax)
  820384:	mov    0x40(%rsp),%rcx
  820389:	mov    %rcx,0x1b0(%rax)
  820390:	mov    0x30(%rsp),%rcx
  820395:	mov    %rcx,0x1b8(%rax)
  82039c:	mov    %r10,0x1c0(%rax)
  8203a3:	mov    0x2a8(%rsp),%r8
  8203ab:	mov    %r8,0x1c8(%rax)
  8203b2:	mov    %r13,0x1d0(%rax)
  8203b9:	mov    %r9,0x1d8(%rax)
  8203c0:	mov    0x2c8(%rsp),%rcx
  8203c8:	mov    %rcx,0x1e0(%rax)
  8203cf:	mov    %rdx,0x1e8(%rax)
  8203d6:	mov    %rsi,0x1f0(%rax)
  8203dd:	add    %rbx,%r12
  8203e0:	mov    %rbx,0x1f8(%rax)
  8203e7:	mov    %r12,0x200(%rax)
  8203ee:	mov    %r15,0x208(%rax)
  8203f5:	mov    0xe8(%rsp),%rcx
  8203fd:	mov    %rcx,0x210(%rax)
  820404:	mov    %rdi,0x218(%rax)
  82040b:	movb   $0x0,0x220(%rax)
  820412:	mov    0x50(%rsp),%rdi
  820417:	mov    0x38(%rsp),%rax
  82041c:	mov    %rax,0x8(%rdi)
  820420:	movl   $0xffffffff,(%rdi)
  820426:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  82042b:	lea    0x60f29e(%rip),%rdi        # e2f6d0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x18>
  820432:	call   *0x660e40(%rip)        # e81278 <_DYNAMIC+0x5e8>
  820438:	lea    0x60f2f1(%rip),%rcx        # e2f730 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x78>
  82043f:	xor    %edi,%edi
  820441:	mov    0x20(%rsp),%rsi
  820446:	call   *0x660d8c(%rip)        # e811d8 <_DYNAMIC+0x548>
  82044c:	lea    0x60f295(%rip),%rax        # e2f6e8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x30>
  820453:	mov    %rcx,%rdi
  820456:	mov    %rdx,%rsi
  820459:	mov    %rax,%rdx
  82045c:	call   *0x660d26(%rip)        # e81188 <_DYNAMIC+0x4f8>
  820462:	lea    0x60f2af(%rip),%rax        # e2f718 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x60>
  820469:	mov    %rcx,%rdi
  82046c:	mov    %rdx,%rsi
  82046f:	mov    %rax,%rdx
  820472:	call   *0x660d10(%rip)        # e81188 <_DYNAMIC+0x4f8>
  820478:	lea    0x60f281(%rip),%rdx        # e2f700 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x48>
  82047f:	call   *0x660d03(%rip)        # e81188 <_DYNAMIC+0x4f8>
  820485:	mov    %rax,%r14
  820488:	mov    0x8(%rsp),%rax
  82048d:	mov    %rbp,0x330(%rax)
  820494:	mov    %r13,0x338(%rax)
  82049b:	mov    %r14,%rdi
  82049e:	call   e2d9a0 <_Unwind_Resume@plt>
  8204a3:	mov    %rax,%r14
  8204a6:	lock decq 0x0(%rbp)
  8204ab:	jne    8204d5 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  8204ad:	lea    0x270(%rsp),%rdi
  8204b5:	call   *0x660ced(%rip)        # e811a8 <_DYNAMIC+0x518>
  8204bb:	jmp    8204d5 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  8204bd:	call   *0x660a1d(%rip)        # e80ee0 <_DYNAMIC+0x250>
  8204c3:	mov    %rax,%r14
  8204c6:	mov    0xe8(%rsp),%rax
  8204ce:	movq   $0x0,(%rax)
  8204d5:	mov    %r14,%rdi
  8204d8:	call   e2d9a0 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4579 frame=1016

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008204e0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  8204e0:	push   %rbp
  8204e1:	push   %r15
  8204e3:	push   %r14
  8204e5:	push   %r13
  8204e7:	push   %r12
  8204e9:	push   %rbx
  8204ea:	sub    $0x3c8,%rsp
  8204f1:	movss  0x88(%rdx),%xmm3
  8204f9:	movss  -0x7714e5(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820501:	movaps %xmm3,%xmm1
  820504:	subss  %xmm0,%xmm1
  820508:	cvttss2si %xmm1,%rax
  82050d:	cvttss2si %xmm3,%r10
  820512:	mov    %r10,%rbp
  820515:	sar    $0x3f,%rbp
  820519:	and    %rax,%rbp
  82051c:	or     %r10,%rbp
  82051f:	xor    %eax,%eax
  820521:	xorps  %xmm1,%xmm1
  820524:	ucomiss %xmm1,%xmm3
  820527:	cmovb  %rax,%rbp
  82052b:	movss  0x90(%rdx),%xmm4
  820533:	movss  -0x77151b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82053b:	ucomiss %xmm2,%xmm3
  82053e:	mov    $0xffffffffffffffff,%r14
  820545:	cmova  %r14,%rbp
  820549:	movaps %xmm4,%xmm3
  82054c:	subss  %xmm0,%xmm3
  820550:	cvttss2si %xmm3,%r10
  820555:	cvttss2si %xmm4,%r11
  82055a:	mov    %r11,%rbx
  82055d:	sar    $0x3f,%rbx
  820561:	and    %r10,%rbx
  820564:	or     %r11,%rbx
  820567:	ucomiss %xmm1,%xmm4
  82056a:	cmovb  %rax,%rbx
  82056e:	ucomiss %xmm2,%xmm4
  820571:	cmova  %r14,%rbx
  820575:	movss  0x8c(%rdx),%xmm3
  82057d:	add    %rbp,%rbx
  820580:	dec    %rbx
  820583:	shr    $0x4,%rbx
  820587:	shr    $0x4,%rbp
  82058b:	mov    %rbx,%r13
  82058e:	sub    %rbp,%r13
  820591:	inc    %r13
  820594:	movaps %xmm3,%xmm4
  820597:	subss  %xmm0,%xmm4
  82059b:	cvttss2si %xmm4,%r11
  8205a0:	cvttss2si %xmm3,%r10
  8205a5:	mov    %r10,%r15
  8205a8:	sar    $0x3f,%r15
  8205ac:	and    %r11,%r15
  8205af:	or     %r10,%r15
  8205b2:	ucomiss %xmm1,%xmm3
  8205b5:	cmovb  %rax,%r15
  8205b9:	ucomiss %xmm2,%xmm3
  8205bc:	movss  0x94(%rdx),%xmm3
  8205c4:	cmova  %r14,%r15
  8205c8:	movaps %xmm3,%xmm4
  8205cb:	subss  %xmm0,%xmm4
  8205cf:	cvttss2si %xmm4,%r12
  8205d4:	cvttss2si %xmm3,%r10
  8205d9:	mov    %r10,%r11
  8205dc:	sar    $0x3f,%r11
  8205e0:	and    %r12,%r11
  8205e3:	or     %r10,%r11
  8205e6:	ucomiss %xmm1,%xmm3
  8205e9:	cmovb  %rax,%r11
  8205ed:	ucomiss %xmm2,%xmm3
  8205f0:	cmova  %r14,%r11
  8205f4:	mov    %r15,%r14
  8205f7:	lea    (%r15,%r11,1),%r10
  8205fb:	dec    %r10
  8205fe:	shr    $0x4,%r10
  820602:	shr    $0x4,%r14
  820606:	mov    %r10,%r12
  820609:	sub    %r14,%r12
  82060c:	inc    %r12
  82060f:	imul   %r13,%r12
  820613:	mov    0x418(%rsp),%r11
  82061b:	add    %r12,%r11
  82061e:	setb   %al
  820621:	cmp    $0x400001,%r11
  820628:	setae  %r15b
  82062c:	or     %al,%r15b
  82062f:	mov    $0x6,%eax
  820634:	jne    820728 <<gpui_gpu::renderer::RendererState>::bin_draw+0x248>
  82063a:	mov    %r12,0x1f8(%rsp)
  820642:	mov    %r11,0x1a0(%rsp)
  82064a:	mov    %rdi,0x1a8(%rsp)
  820652:	cmpb   $0x0,(%rdx)
  820655:	sete   %al
  820658:	and    0x340(%rsi),%al
  82065e:	xor    %r15d,%r15d
  820661:	cmp    $0x1,%al
  820663:	jne    8206ea <<gpui_gpu::renderer::RendererState>::bin_draw+0x20a>
  820669:	movss  0xa4(%rdx),%xmm0
  820671:	ucomiss -0x771898(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  820678:	jne    8206ea <<gpui_gpu::renderer::RendererState>::bin_draw+0x20a>
  82067a:	jp     8206ea <<gpui_gpu::renderer::RendererState>::bin_draw+0x20a>
  82067c:	mov    0x98(%rdx),%edi
  820682:	test   %edi,%edi
  820684:	jns    820696 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b6>
  820686:	and    $0x7f800000,%edi
  82068c:	dec    %edi
  82068e:	cmp    $0x7f7fffff,%edi
  820694:	jae    8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  820696:	mov    0x9c(%rdx),%edi
  82069c:	test   %edi,%edi
  82069e:	jns    8206b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d0>
  8206a0:	and    $0x7f800000,%edi
  8206a6:	dec    %edi
  8206a8:	cmp    $0x7f7ffffe,%edi
  8206ae:	ja     8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8206b0:	mov    0xa0(%rdx),%edi
  8206b6:	test   %edi,%edi
  8206b8:	jns    8206ca <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ea>
  8206ba:	and    $0x7f800000,%edi
  8206c0:	dec    %edi
  8206c2:	cmp    $0x7f7ffffe,%edi
  8206c8:	ja     8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8206ca:	movd   %xmm0,%edi
  8206ce:	test   %edi,%edi
  8206d0:	jns    8206e2 <<gpui_gpu::renderer::RendererState>::bin_draw+0x202>
  8206d2:	and    $0x7f800000,%edi
  8206d8:	dec    %edi
  8206da:	cmp    $0x7f7ffffe,%edi
  8206e0:	ja     8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8206e2:	mov    $0x1,%r15b
  8206e5:	jmp    8206ea <<gpui_gpu::renderer::RendererState>::bin_draw+0x20a>
  8206e7:	xor    %r15d,%r15d
  8206ea:	mov    %rcx,0xe0(%rsp)
  8206f2:	mov    %r8d,0xbc(%rsp)
  8206fa:	mov    %r9,0xa8(%rsp)
  820702:	mov    %rdx,0xe8(%rsp)
  82070a:	cmp    %r14,%r10
  82070d:	jae    82073c <<gpui_gpu::renderer::RendererState>::bin_draw+0x25c>
  82070f:	mov    0x1a8(%rsp),%rdi
  820717:	mov    0x1a0(%rsp),%rax
  82071f:	mov    %rax,0x8(%rdi)
  820723:	mov    $0xffffffff,%eax
  820728:	mov    %eax,(%rdi)
  82072a:	add    $0x3c8,%rsp
  820731:	pop    %rbx
  820732:	pop    %r12
  820734:	pop    %r13
  820736:	pop    %r14
  820738:	pop    %r15
  82073a:	pop    %rbp
  82073b:	ret
  82073c:	cmp    %rbp,%rbx
  82073f:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  820741:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820750:	mov    %r14,%rax
  820753:	cmp    %r10,%r14
  820756:	adc    $0x0,%r14
  82075a:	cmp    %r10,%rax
  82075d:	jae    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  82075f:	cmp    %r10,%r14
  820762:	jbe    820750 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  820764:	jmp    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  820766:	mov    0x400(%rsp),%r13
  82076e:	mov    0x20(%rsi),%r9
  820772:	mov    0x28(%rsi),%r8
  820776:	test   %al,%al
  820778:	je     821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1120>
  82077e:	mov    0xe0(%rsp),%rax
  820786:	movd   %eax,%xmm0
  82078a:	shr    $0x20,%rax
  82078e:	mov    0xe8(%rsp),%rcx
  820796:	movss  0x78(%rcx),%xmm1
  82079b:	movss  0x80(%rcx),%xmm2
  8207a3:	cvtss2sd %xmm1,%xmm12
  8207a8:	movss  0x7c(%rcx),%xmm1
  8207ad:	xorps  %xmm3,%xmm3
  8207b0:	cvtss2sd %xmm1,%xmm3
  8207b4:	cvtss2sd %xmm2,%xmm2
  8207b8:	movss  0x84(%rcx),%xmm1
  8207c0:	addsd  %xmm12,%xmm2
  8207c5:	movsd  %xmm2,0x1e0(%rsp)
  8207ce:	cvtss2sd %xmm1,%xmm1
  8207d2:	movsd  %xmm3,0x1f0(%rsp)
  8207db:	addsd  %xmm3,%xmm1
  8207df:	movsd  %xmm1,0x1d0(%rsp)
  8207e8:	movsd  0x48(%rcx),%xmm4
  8207ed:	movsd  0x58(%rcx),%xmm5
  8207f2:	movss  0x38(%rcx),%xmm1
  8207f7:	movss  0x3c(%rcx),%xmm2
  8207fc:	movss  0x40(%rcx),%xmm3
  820801:	cvtss2sd %xmm1,%xmm6
  820805:	movss  0x44(%rcx),%xmm1
  82080a:	cvtss2sd %xmm3,%xmm3
  82080e:	movaps -0x7759e5(%rip),%xmm7        # aae30 <GCC_except_table0+0x7c>
  820815:	movaps %xmm6,0x90(%rsp)
  82081d:	andps  %xmm7,%xmm6
  820820:	movaps %xmm6,0x80(%rsp)
  820828:	movaps %xmm3,0x60(%rsp)
  82082d:	andps  %xmm7,%xmm3
  820830:	movaps %xmm3,0x70(%rsp)
  820835:	cvtss2sd %xmm0,%xmm0
  820839:	movsd  %xmm0,0x18(%rsp)
  82083f:	movaps %xmm4,%xmm0
  820842:	andps  %xmm7,%xmm0
  820845:	movaps %xmm0,0x2a0(%rsp)
  82084d:	movaps %xmm5,%xmm0
  820850:	andps  %xmm7,%xmm0
  820853:	movaps %xmm0,0x280(%rsp)
  82085b:	xorps  %xmm0,%xmm0
  82085e:	cvtss2sd %xmm2,%xmm0
  820862:	cvtss2sd %xmm1,%xmm1
  820866:	movsd  0x68(%rcx),%xmm2
  82086b:	movaps %xmm2,%xmm3
  82086e:	andps  %xmm7,%xmm3
  820871:	movaps %xmm3,0x130(%rsp)
  820879:	movaps %xmm0,0x50(%rsp)
  82087e:	andps  %xmm7,%xmm0
  820881:	movaps %xmm0,0x40(%rsp)
  820886:	movaps %xmm1,0x20(%rsp)
  82088b:	andps  %xmm7,%xmm1
  82088e:	movaps %xmm1,0x30(%rsp)
  820893:	movd   %eax,%xmm0
  820897:	cvtss2sd %xmm0,%xmm0
  82089b:	movsd  %xmm0,0x10(%rsp)
  8208a1:	movsd  0x50(%rcx),%xmm1
  8208a6:	movaps %xmm1,%xmm0
  8208a9:	andps  %xmm7,%xmm0
  8208ac:	movaps %xmm0,0x220(%rsp)
  8208b4:	movsd  0x60(%rcx),%xmm3
  8208b9:	movaps %xmm3,%xmm0
  8208bc:	andps  %xmm7,%xmm0
  8208bf:	movaps %xmm0,0x200(%rsp)
  8208c7:	movsd  0x70(%rcx),%xmm6
  8208cc:	andps  %xmm6,%xmm7
  8208cf:	movaps %xmm7,0x100(%rsp)
  8208d7:	mov    0x58(%rsi),%rax
  8208db:	mov    %rax,0xd8(%rsp)
  8208e3:	mov    0x50(%rsi),%rax
  8208e7:	mov    %rax,0x1d8(%rsp)
  8208ef:	movaps %xmm4,0x2b0(%rsp)
  8208f7:	movaps %xmm4,%xmm0
  8208fa:	movaps %xmm5,0x290(%rsp)
  820902:	movlhps %xmm5,%xmm0
  820905:	cvtpd2ps %xmm0,%xmm0
  820909:	movaps %xmm1,0x230(%rsp)
  820911:	cvtsd2ss %xmm1,%xmm1
  820915:	cvtss2sd %xmm1,%xmm1
  820919:	cvtps2pd %xmm0,%xmm4
  82091c:	movaps %xmm3,0x210(%rsp)
  820924:	xorps  %xmm0,%xmm0
  820927:	cvtsd2ss %xmm3,%xmm0
  82092b:	xorps  %xmm3,%xmm3
  82092e:	cvtss2sd %xmm0,%xmm3
  820932:	movaps %xmm2,0x140(%rsp)
  82093a:	xorps  %xmm0,%xmm0
  82093d:	cvtsd2ss %xmm2,%xmm0
  820941:	xorps  %xmm2,%xmm2
  820944:	cvtss2sd %xmm0,%xmm2
  820948:	movaps %xmm6,0xf0(%rsp)
  820950:	xorps  %xmm0,%xmm0
  820953:	cvtsd2ss %xmm6,%xmm0
  820957:	cvtss2sd %xmm0,%xmm0
  82095b:	mov    0xa8(%rsp),%rax
  820963:	inc    %eax
  820965:	mov    %rax,0xa8(%rsp)
  82096d:	movaps -0x775b44(%rip),%xmm5        # aae30 <GCC_except_table0+0x7c>
  820974:	movaps %xmm4,%xmm6
  820977:	andps  %xmm5,%xmm6
  82097a:	movaps %xmm2,0x160(%rsp)
  820982:	andps  %xmm5,%xmm2
  820985:	movaps %xmm2,0x150(%rsp)
  82098d:	movaps %xmm1,0x270(%rsp)
  820995:	andps  %xmm5,%xmm1
  820998:	movaps %xmm1,0x260(%rsp)
  8209a0:	movaps %xmm3,0x250(%rsp)
  8209a8:	andps  %xmm5,%xmm3
  8209ab:	movaps %xmm3,0x240(%rsp)
  8209b3:	movaps %xmm0,0x120(%rsp)
  8209bb:	andps  %xmm0,%xmm5
  8209be:	movaps %xmm5,0x110(%rsp)
  8209c6:	movaps %xmm4,0x2d0(%rsp)
  8209ce:	movhlps %xmm4,%xmm4
  8209d1:	movaps %xmm4,0x300(%rsp)
  8209d9:	mov    $0x2,%cl
  8209db:	xor    %edx,%edx
  8209dd:	mov    %r14,%rax
  8209e0:	movaps %xmm6,0x2c0(%rsp)
  8209e8:	pshufd $0xee,%xmm6,%xmm0
  8209ed:	movdqa %xmm0,0x2f0(%rsp)
  8209f6:	movsd  %xmm12,0x8(%rsp)
  8209fd:	mov    %rbp,0x1b8(%rsp)
  820a05:	mov    %r10,0x1b0(%rsp)
  820a0d:	mov    %rbx,0x1e8(%rsp)
  820a15:	data16 cs nopw 0x0(%rax,%rax,1)
  820a20:	cmp    %r10,%r14
  820a23:	adc    $0x0,%rax
  820a27:	mov    %rax,0x1c0(%rsp)
  820a2f:	mov    %r14,0x1c8(%rsp)
  820a37:	imul   %r13,%r14
  820a3b:	mov    %rbp,%r11
  820a3e:	jmp    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820a40:	cmp    %r8,%r12
  820a43:	jae    821665 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1185>
  820a49:	incl   0x4(%r9,%r12,8)
  820a4e:	mov    $0x1,%dl
  820a50:	cmp    %rbx,%r11
  820a53:	jb     820c53 <<gpui_gpu::renderer::RendererState>::bin_draw+0x773>
  820a59:	jmp    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  820a5e:	xchg   %ax,%ax
  820a60:	cmp    %rbx,%r11
  820a63:	adc    $0x0,%rbp
  820a67:	lea    (%r11,%r14,1),%r12
  820a6b:	test   %r15b,%r15b
  820a6e:	jne    820a85 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a5>
  820a70:	cmp    %r8,%r12
  820a73:	jae    821685 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11a5>
  820a79:	testb  $0x40,0x7(%r9,%r12,8)
  820a7f:	je     820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820a85:	cmpq   $0x2,0x1f8(%rsp)
  820a8e:	setae  %al
  820a91:	and    %dl,%al
  820a93:	cmp    $0x1,%al
  820a95:	jne    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b0>
  820a9b:	cmp    $0x2,%cl
  820a9e:	jne    820b2f <<gpui_gpu::renderer::RendererState>::bin_draw+0x64f>
  820aa4:	mov    $0xa8,%edx
  820aa9:	lea    0x320(%rsp),%rdi
  820ab1:	mov    %r11,0xb0(%rsp)
  820ab9:	mov    0xe8(%rsp),%rsi
  820ac1:	mov    %r15d,%ebx
  820ac4:	mov    %r8,%r15
  820ac7:	mov    %rbp,0xc0(%rsp)
  820acf:	mov    %r14,%rbp
  820ad2:	mov    %r9,%r14
  820ad5:	call   *0x660455(%rip)        # e80f30 <memcpy@GLIBC_2.14>
  820adb:	lea    0x320(%rsp),%rdi
  820ae3:	mov    0xe0(%rsp),%rsi
  820aeb:	mov    %r13,%rdx
  820aee:	mov    0x408(%rsp),%ecx
  820af5:	mov    0x410(%rsp),%r8d
  820afd:	call   826010 <gpui_gpu::renderer::coverage::whole>
  820b02:	mov    0xb0(%rsp),%r11
  820b0a:	movsd  0x8(%rsp),%xmm12
  820b11:	mov    %r14,%r9
  820b14:	mov    %rbp,%r14
  820b17:	mov    0xc0(%rsp),%rbp
  820b1f:	mov    %r15,%r8
  820b22:	mov    %ebx,%r15d
  820b25:	mov    0x1e8(%rsp),%rbx
  820b2d:	mov    %eax,%ecx
  820b2f:	test   $0x1,%cl
  820b32:	mov    $0x1,%cl
  820b34:	je     820b8e <<gpui_gpu::renderer::RendererState>::bin_draw+0x6ae>
  820b36:	test   %r15b,%r15b
  820b39:	je     820a40 <<gpui_gpu::renderer::RendererState>::bin_draw+0x560>
  820b3f:	cmp    %r8,%r12
  820b42:	jae    8216b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11d0>
  820b48:	mov    0xbc(%rsp),%eax
  820b4f:	mov    %eax,(%r9,%r12,8)
  820b53:	movl   $0x40000001,0x4(%r9,%r12,8)
  820b5c:	cmp    0xd8(%rsp),%r12
  820b64:	jae    821698 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11b8>
  820b6a:	mov    0xa8(%rsp),%rax
  820b72:	mov    0x1d8(%rsp),%rdx
  820b7a:	mov    %eax,(%rdx,%r12,4)
  820b7e:	mov    $0x1,%dl
  820b80:	cmp    %rbx,%r11
  820b83:	jb     820c53 <<gpui_gpu::renderer::RendererState>::bin_draw+0x773>
  820b89:	jmp    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  820b8e:	xor    %ecx,%ecx
  820b90:	test   %r13,%r13
  820b93:	je     821678 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1198>
  820b99:	mov    %r12,%rax
  820b9c:	shr    $0x20,%rax
  820ba0:	je     820bb0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6d0>
  820ba2:	mov    %r12,%rax
  820ba5:	xor    %edx,%edx
  820ba7:	div    %r13
  820baa:	jmp    820bb8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6d8>
  820bac:	nopl   0x0(%rax)
  820bb0:	mov    %r12d,%eax
  820bb3:	xor    %edx,%edx
  820bb5:	div    %r13d
  820bb8:	shl    $0x4,%edx
  820bbb:	shl    $0x4,%eax
  820bbe:	lea    0x10(%rdx),%esi
  820bc1:	mov    0x408(%rsp),%edi
  820bc8:	cmp    %esi,%edi
  820bca:	cmovb  %edi,%esi
  820bcd:	lea    0x10(%rax),%edi
  820bd0:	mov    0x410(%rsp),%r10d
  820bd8:	cmp    %edi,%r10d
  820bdb:	cmovb  %r10d,%edi
  820bdf:	xorps  %xmm2,%xmm2
  820be2:	cvtsi2sd %edx,%xmm2
  820be6:	mov    $0x1,%dl
  820be8:	ucomisd %xmm2,%xmm12
  820bed:	ja     820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820bef:	mov    %eax,%eax
  820bf1:	xorps  %xmm3,%xmm3
  820bf4:	cvtsi2sd %rax,%xmm3
  820bf9:	movsd  0x1f0(%rsp),%xmm0
  820c02:	ucomisd %xmm3,%xmm0
  820c06:	ja     820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820c08:	xorps  %xmm0,%xmm0
  820c0b:	cvtsi2sd %esi,%xmm0
  820c0f:	ucomisd 0x1e0(%rsp),%xmm0
  820c18:	ja     820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820c1a:	xorps  %xmm1,%xmm1
  820c1d:	cvtsi2sd %edi,%xmm1
  820c21:	ucomisd 0x1d0(%rsp),%xmm1
  820c2a:	jbe    820c64 <<gpui_gpu::renderer::RendererState>::bin_draw+0x784>
  820c2c:	nopl   0x0(%rax)
  820c30:	cmp    %r8,%r12
  820c33:	jae    821665 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1185>
  820c39:	mov    0x4(%r9,%r12,8),%eax
  820c3e:	inc    %eax
  820c40:	and    $0xbfffffff,%eax
  820c45:	mov    %eax,0x4(%r9,%r12,8)
  820c4a:	cmp    %rbx,%r11
  820c4d:	jae    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  820c53:	mov    %rbp,%r11
  820c56:	cmp    %rbx,%rbp
  820c59:	jbe    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820c5f:	jmp    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  820c64:	unpcklpd %xmm3,%xmm2
  820c68:	addpd  -0x773b30(%rip),%xmm2        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820c70:	movapd %xmm2,%xmm3
  820c74:	mulpd  0x2d0(%rsp),%xmm3
  820c7d:	movapd %xmm3,%xmm11
  820c82:	unpckhpd %xmm3,%xmm11
  820c87:	movapd %xmm3,%xmm5
  820c8b:	addsd  %xmm11,%xmm5
  820c90:	addsd  0x160(%rsp),%xmm5
  820c99:	subsd  0x90(%rsp),%xmm5
  820ca2:	movapd 0x2c0(%rsp),%xmm8
  820cac:	mulpd  %xmm2,%xmm8
  820cb1:	movapd %xmm8,%xmm4
  820cb6:	unpckhpd %xmm8,%xmm4
  820cbb:	movapd %xmm8,%xmm6
  820cc0:	addsd  %xmm4,%xmm6
  820cc4:	addsd  0x150(%rsp),%xmm6
  820ccd:	addsd  0x80(%rsp),%xmm6
  820cd6:	addsd  0x70(%rsp),%xmm6
  820cdc:	addsd  -0x771404(%rip),%xmm6        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ce4:	mulsd  -0x77148c(%rip),%xmm6        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cec:	addsd  0x18(%rsp),%xmm6
  820cf2:	ucomisd %xmm5,%xmm6
  820cf6:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820cfc:	movapd 0x60(%rsp),%xmm7
  820d02:	subsd  %xmm5,%xmm7
  820d06:	ucomisd %xmm7,%xmm6
  820d0a:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820d10:	movapd %xmm2,%xmm13
  820d15:	unpckhpd %xmm2,%xmm13
  820d1a:	movapd 0x290(%rsp),%xmm15
  820d24:	mulsd  %xmm13,%xmm15
  820d29:	movapd 0x280(%rsp),%xmm14
  820d33:	mulsd  %xmm13,%xmm14
  820d38:	movapd 0x2b0(%rsp),%xmm5
  820d41:	mulsd  %xmm2,%xmm5
  820d45:	movapd %xmm5,%xmm6
  820d49:	addsd  %xmm15,%xmm6
  820d4e:	addsd  0x140(%rsp),%xmm6
  820d57:	subsd  0x90(%rsp),%xmm6
  820d60:	movapd 0x2a0(%rsp),%xmm7
  820d69:	mulsd  %xmm2,%xmm7
  820d6d:	movapd %xmm7,%xmm9
  820d72:	addsd  %xmm14,%xmm9
  820d77:	addsd  0x130(%rsp),%xmm9
  820d81:	addsd  0x80(%rsp),%xmm9
  820d8b:	addsd  0x70(%rsp),%xmm9
  820d92:	addsd  -0x7714bb(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d9b:	mulsd  -0x770f64(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820da4:	ucomisd %xmm6,%xmm9
  820da9:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820daf:	movapd 0x60(%rsp),%xmm10
  820db6:	subsd  %xmm6,%xmm10
  820dbb:	ucomisd %xmm10,%xmm9
  820dc0:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820dc6:	movapd %xmm13,%xmm9
  820dcb:	mulsd  0x250(%rsp),%xmm9
  820dd5:	movapd %xmm13,%xmm12
  820dda:	mulsd  0x240(%rsp),%xmm12
  820de4:	movapd %xmm2,%xmm10
  820de9:	mulsd  0x270(%rsp),%xmm10
  820df3:	movapd %xmm10,%xmm6
  820df8:	movapd %xmm9,0xc0(%rsp)
  820e02:	addsd  %xmm9,%xmm6
  820e07:	addsd  0x120(%rsp),%xmm6
  820e10:	subsd  0x50(%rsp),%xmm6
  820e16:	movapd %xmm2,%xmm9
  820e1b:	mulsd  0x260(%rsp),%xmm9
  820e25:	movsd  %xmm9,0xb0(%rsp)
  820e2f:	addsd  %xmm12,%xmm9
  820e34:	addsd  0x110(%rsp),%xmm9
  820e3e:	addsd  0x40(%rsp),%xmm9
  820e45:	addsd  0x30(%rsp),%xmm9
  820e4c:	addsd  -0x771575(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e55:	mulsd  -0x7715fe(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e5e:	addsd  0x10(%rsp),%xmm9
  820e65:	ucomisd %xmm6,%xmm9
  820e6a:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820e70:	movsd  %xmm10,0x198(%rsp)
  820e7a:	movapd 0x20(%rsp),%xmm10
  820e81:	subsd  %xmm6,%xmm10
  820e86:	ucomisd %xmm10,%xmm9
  820e8b:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820e91:	movapd 0x210(%rsp),%xmm9
  820e9b:	mulsd  %xmm13,%xmm9
  820ea0:	mulsd  0x200(%rsp),%xmm13
  820eaa:	movapd 0x230(%rsp),%xmm10
  820eb4:	mulsd  %xmm2,%xmm10
  820eb9:	movapd %xmm10,%xmm6
  820ebe:	movapd %xmm9,0x170(%rsp)
  820ec8:	addsd  %xmm9,%xmm6
  820ecd:	addsd  0xf0(%rsp),%xmm6
  820ed6:	subsd  0x50(%rsp),%xmm6
  820edc:	mulsd  0x220(%rsp),%xmm2
  820ee5:	movapd %xmm2,%xmm9
  820eea:	addsd  %xmm13,%xmm9
  820eef:	addsd  0x100(%rsp),%xmm9
  820ef9:	addsd  0x40(%rsp),%xmm9
  820f00:	addsd  0x30(%rsp),%xmm9
  820f07:	addsd  -0x771630(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f10:	mulsd  -0x7710d9(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f19:	ucomisd %xmm6,%xmm9
  820f1e:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820f24:	movapd %xmm10,0x310(%rsp)
  820f2e:	movapd 0x20(%rsp),%xmm10
  820f35:	subsd  %xmm6,%xmm10
  820f3a:	ucomisd %xmm10,%xmm9
  820f3f:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820f45:	addsd  -0x771965(%rip),%xmm0        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820f4d:	movapd %xmm0,%xmm9
  820f52:	mulsd  0x2d0(%rsp),%xmm9
  820f5c:	addsd  %xmm9,%xmm11
  820f61:	addsd  0x160(%rsp),%xmm11
  820f6b:	subsd  0x90(%rsp),%xmm11
  820f75:	movapd 0x2c0(%rsp),%xmm10
  820f7f:	mulsd  %xmm0,%xmm10
  820f84:	addsd  %xmm10,%xmm4
  820f89:	addsd  0x150(%rsp),%xmm4
  820f92:	addsd  0x80(%rsp),%xmm4
  820f9b:	addsd  0x70(%rsp),%xmm4
  820fa1:	addsd  -0x7716c9(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fa9:	mulsd  -0x771751(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820fb1:	addsd  0x18(%rsp),%xmm4
  820fb7:	ucomisd %xmm11,%xmm4
  820fbc:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820fc2:	movapd 0x60(%rsp),%xmm6
  820fc8:	subsd  %xmm11,%xmm6
  820fcd:	ucomisd %xmm6,%xmm4
  820fd1:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820fd7:	movapd 0x2b0(%rsp),%xmm6
  820fe0:	mulsd  %xmm0,%xmm6
  820fe4:	addsd  %xmm6,%xmm15
  820fe9:	addsd  0x140(%rsp),%xmm15
  820ff3:	subsd  0x90(%rsp),%xmm15
  820ffd:	movapd 0x2a0(%rsp),%xmm11
  821007:	mulsd  %xmm0,%xmm11
  82100c:	addsd  %xmm11,%xmm14
  821011:	addsd  0x130(%rsp),%xmm14
  82101b:	addsd  0x80(%rsp),%xmm14
  821025:	addsd  0x70(%rsp),%xmm14
  82102c:	addsd  -0x771755(%rip),%xmm14        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821035:	mulsd  -0x7711fe(%rip),%xmm14        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82103e:	ucomisd %xmm15,%xmm14
  821043:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  821049:	movapd 0x60(%rsp),%xmm4
  82104f:	subsd  %xmm15,%xmm4
  821054:	ucomisd %xmm4,%xmm14
  821059:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  82105f:	movapd %xmm0,%xmm14
  821064:	mulsd  0x270(%rsp),%xmm14
  82106e:	movapd 0xc0(%rsp),%xmm4
  821077:	addsd  %xmm14,%xmm4
  82107c:	addsd  0x120(%rsp),%xmm4
  821085:	subsd  0x50(%rsp),%xmm4
  82108b:	movapd %xmm0,%xmm15
  821090:	mulsd  0x260(%rsp),%xmm15
  82109a:	addsd  %xmm15,%xmm12
  82109f:	addsd  0x110(%rsp),%xmm12
  8210a9:	addsd  0x40(%rsp),%xmm12
  8210b0:	addsd  0x30(%rsp),%xmm12
  8210b7:	addsd  -0x7717e0(%rip),%xmm12        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210c0:	mulsd  -0x771869(%rip),%xmm12        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8210c9:	addsd  0x10(%rsp),%xmm12
  8210d0:	ucomisd %xmm4,%xmm12
  8210d5:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  8210db:	movsd  %xmm15,0xc0(%rsp)
  8210e5:	movapd %xmm4,%xmm15
  8210ea:	movapd 0x20(%rsp),%xmm4
  8210f0:	subsd  %xmm15,%xmm4
  8210f5:	ucomisd %xmm4,%xmm12
  8210fa:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  821100:	movapd 0x230(%rsp),%xmm4
  821109:	mulsd  %xmm0,%xmm4
  82110d:	movapd 0x170(%rsp),%xmm15
  821117:	addsd  %xmm4,%xmm15
  82111c:	addsd  0xf0(%rsp),%xmm15
  821126:	subsd  0x50(%rsp),%xmm15
  82112d:	mulsd  0x220(%rsp),%xmm0
  821136:	addsd  %xmm0,%xmm13
  82113b:	addsd  0x100(%rsp),%xmm13
  821145:	addsd  0x40(%rsp),%xmm13
  82114c:	addsd  0x30(%rsp),%xmm13
  821153:	addsd  -0x77187c(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82115c:	mulsd  -0x771325(%rip),%xmm13        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821165:	ucomisd %xmm15,%xmm13
  82116a:	movsd  0x8(%rsp),%xmm12
  821171:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821177:	movapd %xmm4,0x170(%rsp)
  821180:	movapd 0x20(%rsp),%xmm4
  821186:	subsd  %xmm15,%xmm4
  82118b:	ucomisd %xmm4,%xmm13
  821190:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821196:	movsd  %xmm10,0x190(%rsp)
  8211a0:	addsd  -0x771bc0(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8211a8:	movapd %xmm1,%xmm10
  8211ad:	mulsd  0x300(%rsp),%xmm10
  8211b7:	movapd %xmm1,%xmm4
  8211bb:	mulsd  0x2f0(%rsp),%xmm4
  8211c4:	addsd  %xmm10,%xmm3
  8211c9:	addsd  0x160(%rsp),%xmm3
  8211d2:	subsd  0x90(%rsp),%xmm3
  8211db:	addsd  %xmm4,%xmm8
  8211e0:	addsd  0x150(%rsp),%xmm8
  8211ea:	addsd  0x80(%rsp),%xmm8
  8211f4:	addsd  0x70(%rsp),%xmm8
  8211fb:	addsd  -0x771924(%rip),%xmm8        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821204:	mulsd  -0x7719ad(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82120d:	addsd  0x18(%rsp),%xmm8
  821214:	ucomisd %xmm3,%xmm8
  821219:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  82121f:	movapd %xmm6,0x2e0(%rsp)
  821228:	movapd 0x60(%rsp),%xmm6
  82122e:	subsd  %xmm3,%xmm6
  821232:	ucomisd %xmm6,%xmm8
  821237:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  82123d:	movapd 0x290(%rsp),%xmm8
  821247:	mulsd  %xmm1,%xmm8
  82124c:	movapd 0x280(%rsp),%xmm3
  821255:	mulsd  %xmm1,%xmm3
  821259:	addsd  %xmm8,%xmm5
  82125e:	addsd  0x140(%rsp),%xmm5
  821267:	subsd  0x90(%rsp),%xmm5
  821270:	addsd  %xmm3,%xmm7
  821274:	addsd  0x130(%rsp),%xmm7
  82127d:	addsd  0x80(%rsp),%xmm7
  821286:	addsd  0x70(%rsp),%xmm7
  82128c:	addsd  -0x7719b4(%rip),%xmm7        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821294:	mulsd  -0x77145c(%rip),%xmm7        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82129c:	ucomisd %xmm5,%xmm7
  8212a0:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8212a6:	movapd 0x60(%rsp),%xmm6
  8212ac:	subsd  %xmm5,%xmm6
  8212b0:	ucomisd %xmm6,%xmm7
  8212b4:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8212ba:	movsd  %xmm14,0x188(%rsp)
  8212c4:	movapd %xmm9,%xmm14
  8212c9:	movapd %xmm1,%xmm7
  8212cd:	mulsd  0x250(%rsp),%xmm7
  8212d6:	movapd %xmm1,%xmm5
  8212da:	mulsd  0x240(%rsp),%xmm5
  8212e3:	movsd  0x198(%rsp),%xmm9
  8212ed:	addsd  %xmm7,%xmm9
  8212f2:	addsd  0x120(%rsp),%xmm9
  8212fc:	subsd  0x50(%rsp),%xmm9
  821303:	movsd  0xb0(%rsp),%xmm13
  82130d:	addsd  %xmm5,%xmm13
  821312:	addsd  0x110(%rsp),%xmm13
  82131c:	addsd  0x40(%rsp),%xmm13
  821323:	addsd  0x30(%rsp),%xmm13
  82132a:	addsd  -0x771a53(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821333:	mulsd  -0x771adc(%rip),%xmm13        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82133c:	addsd  0x10(%rsp),%xmm13
  821343:	ucomisd %xmm9,%xmm13
  821348:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  82134e:	movapd 0x20(%rsp),%xmm6
  821354:	subsd  %xmm9,%xmm6
  821359:	ucomisd %xmm6,%xmm13
  82135e:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821364:	movapd 0x210(%rsp),%xmm6
  82136d:	mulsd  %xmm1,%xmm6
  821371:	mulsd  0x200(%rsp),%xmm1
  82137a:	movapd 0x310(%rsp),%xmm13
  821384:	addsd  %xmm6,%xmm13
  821389:	addsd  0xf0(%rsp),%xmm13
  821393:	subsd  0x50(%rsp),%xmm13
  82139a:	addsd  %xmm1,%xmm2
  82139e:	addsd  0x100(%rsp),%xmm2
  8213a7:	addsd  0x40(%rsp),%xmm2
  8213ad:	addsd  0x30(%rsp),%xmm2
  8213b3:	addsd  -0x771adb(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213bb:	mulsd  -0x771583(%rip),%xmm2        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8213c3:	ucomisd %xmm13,%xmm2
  8213c8:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8213ce:	movapd 0x20(%rsp),%xmm9
  8213d5:	subsd  %xmm13,%xmm9
  8213da:	ucomisd %xmm9,%xmm2
  8213df:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8213e5:	addsd  %xmm10,%xmm14
  8213ea:	addsd  0x160(%rsp),%xmm14
  8213f4:	subsd  0x90(%rsp),%xmm14
  8213fe:	movsd  0x190(%rsp),%xmm9
  821408:	addsd  %xmm4,%xmm9
  82140d:	addsd  0x150(%rsp),%xmm9
  821417:	addsd  0x80(%rsp),%xmm9
  821421:	addsd  0x70(%rsp),%xmm9
  821428:	addsd  -0x771b51(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821431:	mulsd  -0x771bda(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82143a:	addsd  0x18(%rsp),%xmm9
  821441:	ucomisd %xmm14,%xmm9
  821446:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  82144c:	movapd 0x60(%rsp),%xmm2
  821452:	subsd  %xmm14,%xmm2
  821457:	ucomisd %xmm2,%xmm9
  82145c:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821462:	movapd 0x2e0(%rsp),%xmm4
  82146b:	addsd  %xmm8,%xmm4
  821470:	addsd  0x140(%rsp),%xmm4
  821479:	subsd  0x90(%rsp),%xmm4
  821482:	addsd  %xmm3,%xmm11
  821487:	addsd  0x130(%rsp),%xmm11
  821491:	addsd  0x80(%rsp),%xmm11
  82149b:	addsd  0x70(%rsp),%xmm11
  8214a2:	addsd  -0x771bcb(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214ab:	mulsd  -0x771674(%rip),%xmm11        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8214b4:	ucomisd %xmm4,%xmm11
  8214b9:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8214bf:	movapd 0x60(%rsp),%xmm2
  8214c5:	subsd  %xmm4,%xmm2
  8214c9:	ucomisd %xmm2,%xmm11
  8214ce:	movsd  0x188(%rsp),%xmm3
  8214d7:	movsd  0xc0(%rsp),%xmm4
  8214e0:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8214e6:	addsd  %xmm7,%xmm3
  8214ea:	addsd  0x120(%rsp),%xmm3
  8214f3:	subsd  0x50(%rsp),%xmm3
  8214f9:	addsd  %xmm5,%xmm4
  8214fd:	addsd  0x110(%rsp),%xmm4
  821506:	addsd  0x40(%rsp),%xmm4
  82150c:	addsd  0x30(%rsp),%xmm4
  821512:	addsd  -0x771c3a(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82151a:	mulsd  -0x771cc2(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821522:	addsd  0x10(%rsp),%xmm4
  821528:	ucomisd %xmm3,%xmm4
  82152c:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821532:	movapd 0x20(%rsp),%xmm2
  821538:	subsd  %xmm3,%xmm2
  82153c:	ucomisd %xmm2,%xmm4
  821540:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821546:	movapd 0x170(%rsp),%xmm3
  82154f:	addsd  %xmm6,%xmm3
  821553:	addsd  0xf0(%rsp),%xmm3
  82155c:	subsd  0x50(%rsp),%xmm3
  821562:	addsd  %xmm1,%xmm0
  821566:	addsd  0x100(%rsp),%xmm0
  82156f:	addsd  0x40(%rsp),%xmm0
  821575:	addsd  0x30(%rsp),%xmm0
  82157b:	addsd  -0x771ca3(%rip),%xmm0        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821583:	mulsd  -0x77174b(%rip),%xmm0        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82158b:	ucomisd %xmm3,%xmm0
  82158f:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821595:	movapd 0x20(%rsp),%xmm1
  82159b:	subsd  %xmm3,%xmm1
  82159f:	ucomisd %xmm1,%xmm0
  8215a3:	jb     820b36 <<gpui_gpu::renderer::RendererState>::bin_draw+0x656>
  8215a9:	jmp    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8215ae:	movsd  0x8(%rsp),%xmm12
  8215b5:	jmp    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8215ba:	nopw   0x0(%rax,%rax,1)
  8215c0:	mov    0x1b0(%rsp),%r10
  8215c8:	cmp    %r10,0x1c8(%rsp)
  8215d0:	mov    0x1b8(%rsp),%rbp
  8215d8:	mov    0x1c0(%rsp),%rax
  8215e0:	jae    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  8215e6:	mov    %rax,%r14
  8215e9:	cmp    %r10,%rax
  8215ec:	jbe    820a20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x540>
  8215f2:	jmp    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  8215f7:	nopw   0x0(%rax,%rax,1)
  821600:	mov    %r14,%rax
  821603:	cmp    %r10,%r14
  821606:	adc    $0x0,%r14
  82160a:	mov    %rax,%rcx
  82160d:	imul   %r13,%rcx
  821611:	mov    %rbp,%rdx
  821614:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  821620:	lea    (%rdx,%rcx,1),%r12
  821624:	cmp    %r8,%r12
  821627:	jae    821665 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1185>
  821629:	cmp    %rbx,%rdx
  82162c:	mov    %rdx,%rsi
  82162f:	adc    $0x0,%rsi
  821633:	mov    0x4(%r9,%r12,8),%edi
  821638:	inc    %edi
  82163a:	and    $0xbfffffff,%edi
  821640:	mov    %edi,0x4(%r9,%r12,8)
  821645:	cmp    %rbx,%rdx
  821648:	jae    821652 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1172>
  82164a:	mov    %rsi,%rdx
  82164d:	cmp    %rbx,%rsi
  821650:	jbe    821620 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1140>
  821652:	cmp    %r10,%rax
  821655:	jae    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  82165b:	cmp    %r10,%r14
  82165e:	jbe    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1120>
  821660:	jmp    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  821665:	lea    0x60e154(%rip),%rdx        # e2f7c0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x108>
  82166c:	mov    %r12,%rdi
  82166f:	mov    %r8,%rsi
  821672:	call   *0x65fb10(%rip)        # e81188 <_DYNAMIC+0x4f8>
  821678:	lea    0x60e261(%rip),%rdi        # e2f8e0 <anon.7e34a6dced7fe4eb77116889a7de5f31.41.llvm.15614097268772730318>
  82167f:	call   *0x65fbe3(%rip)        # e81268 <_DYNAMIC+0x5d8>
  821685:	lea    0x60e11c(%rip),%rdx        # e2f7a8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0xf0>
  82168c:	mov    %r12,%rdi
  82168f:	mov    %r8,%rsi
  821692:	call   *0x65faf0(%rip)        # e81188 <_DYNAMIC+0x4f8>
  821698:	lea    0x60e151(%rip),%rdx        # e2f7f0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x138>
  82169f:	mov    %r12,%rdi
  8216a2:	mov    0xd8(%rsp),%rsi
  8216aa:	call   *0x65fad8(%rip)        # e81188 <_DYNAMIC+0x4f8>
  8216b0:	lea    0x60e121(%rip),%rdx        # e2f7d8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x120>
  8216b7:	mov    %r12,%rdi
  8216ba:	mov    %r8,%rsi
  8216bd:	call   *0x65fac5(%rip)        # e81188 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008216d0 <gpui_gpu::renderer::compact_group>:
  8216d0:	xor    %eax,%eax
  8216d2:	test   %esi,%esi
  8216d4:	je     821713 <gpui_gpu::renderer::compact_group+0x43>
  8216d6:	cmpq   $0x2,0x10(%rdi)
  8216db:	jb     821713 <gpui_gpu::renderer::compact_group+0x43>
  8216dd:	sub    $0x58,%rsp
  8216e1:	mov    (%rdi),%rsi
  8216e4:	mov    0x8(%rdi),%rax
  8216e8:	mov    (%rax),%edx
  8216ea:	mov    %rsp,%rdi
  8216ed:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  8216f2:	movss  0x4(%rsp),%xmm0
  8216f8:	cmpb   $0x3,(%rsp)
  8216fc:	setne  %cl
  8216ff:	xorps  %xmm1,%xmm1
  821702:	ucomiss %xmm1,%xmm0
  821705:	setnp  %dl
  821708:	sete   %al
  82170b:	and    %dl,%al
  82170d:	or     %cl,%al
  82170f:	add    $0x58,%rsp
  821713:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821720 <gpui_gpu::renderer::validate_draw>:
  821720:	push   %rbp
  821721:	push   %r15
  821723:	push   %r14
  821725:	push   %r12
  821727:	push   %rbx
  821728:	sub    $0x80,%rsp
  82172f:	mov    %r8d,%ebp
  821732:	mov    %ecx,%r12d
  821735:	mov    %rdx,%r14
  821738:	mov    %rsi,%r15
  82173b:	mov    %rdi,%rbx
  82173e:	movups 0x88(%rsi),%xmm0
  821745:	movaps %xmm0,0x20(%rsp)
  82174a:	movaps %xmm0,0x70(%rsp)
  82174f:	lea    0x70(%rsp),%rdi
  821754:	call   *0x65fba6(%rip)        # e81300 <_DYNAMIC+0x670>
  82175a:	movaps 0x20(%rsp),%xmm4
  82175f:	test   %al,%al
  821761:	je     8217b7 <gpui_gpu::renderer::validate_draw+0x97>
  821763:	movaps %xmm4,%xmm0
  821766:	unpckhpd %xmm4,%xmm0
  82176a:	xorps  %xmm2,%xmm2
  82176d:	ucomiss %xmm2,%xmm0
  821770:	jne    821774 <gpui_gpu::renderer::validate_draw+0x54>
  821772:	jnp    8217b7 <gpui_gpu::renderer::validate_draw+0x97>
  821774:	movaps %xmm4,%xmm1
  821777:	shufps $0xff,%xmm4,%xmm1
  82177b:	ucomiss %xmm2,%xmm1
  82177e:	jne    821782 <gpui_gpu::renderer::validate_draw+0x62>
  821780:	jnp    8217b7 <gpui_gpu::renderer::validate_draw+0x97>
  821782:	xorps  %xmm3,%xmm3
  821785:	ucomiss %xmm4,%xmm3
  821788:	ja     8217b7 <gpui_gpu::renderer::validate_draw+0x97>
  82178a:	movaps %xmm4,%xmm2
  82178d:	shufps $0x55,%xmm4,%xmm2
  821791:	ucomiss %xmm2,%xmm3
  821794:	ja     8217b7 <gpui_gpu::renderer::validate_draw+0x97>
  821796:	xorps  %xmm3,%xmm3
  821799:	cvtsi2ss %r12d,%xmm3
  82179e:	addss  %xmm4,%xmm0
  8217a2:	ucomiss %xmm3,%xmm0
  8217a5:	ja     8217b7 <gpui_gpu::renderer::validate_draw+0x97>
  8217a7:	xorps  %xmm0,%xmm0
  8217aa:	cvtsi2ss %ebp,%xmm0
  8217ae:	addss  %xmm1,%xmm2
  8217b2:	ucomiss %xmm0,%xmm2
  8217b5:	jbe    8217cd <gpui_gpu::renderer::validate_draw+0xad>
  8217b7:	movl   $0x3,(%rbx)
  8217bd:	add    $0x80,%rsp
  8217c4:	pop    %rbx
  8217c5:	pop    %r12
  8217c7:	pop    %r14
  8217c9:	pop    %r15
  8217cb:	pop    %rbp
  8217cc:	ret
  8217cd:	movsd  0x48(%r15),%xmm9
  8217d3:	movsd  0x60(%r15),%xmm1
  8217d9:	movupd 0x50(%r15),%xmm2
  8217df:	movapd %xmm2,%xmm5
  8217e3:	shufpd $0x1,%xmm2,%xmm5
  8217e8:	movupd 0x68(%r15),%xmm0
  8217ee:	cvtpd2ps %xmm5,%xmm8
  8217f3:	movapd %xmm9,%xmm4
  8217f8:	unpcklpd %xmm1,%xmm4
  8217fc:	cvtpd2ps %xmm4,%xmm7
  821800:	cvtpd2ps %xmm0,%xmm6
  821804:	movapd %xmm6,%xmm3
  821808:	shufps $0x55,%xmm6,%xmm3
  82180c:	movd   %xmm3,%ecx
  821810:	movd   %xmm6,%eax
  821814:	movapd %xmm7,%xmm3
  821818:	shufps $0x14,%xmm8,%xmm3
  82181d:	shufps $0x78,%xmm3,%xmm3
  821821:	andps  -0x774038(%rip),%xmm3        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821828:	and    $0x7fffffff,%eax
  82182d:	cmp    $0x7f800000,%eax
  821832:	setge  %al
  821835:	and    $0x7fffffff,%ecx
  82183b:	cmp    $0x7f800000,%ecx
  821841:	setge  %cl
  821844:	pcmpgtd -0x77611c(%rip),%xmm3        # ab730 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  82184c:	movmskps %xmm3,%edx
  82184f:	test   %edx,%edx
  821851:	jne    8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821853:	test   %al,%al
  821855:	jne    8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821857:	test   %cl,%cl
  821859:	jne    8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  82185b:	movapd %xmm9,%xmm3
  821860:	mulsd  %xmm1,%xmm3
  821864:	movapd %xmm2,%xmm10
  821869:	mulsd  %xmm5,%xmm10
  82186e:	subsd  %xmm10,%xmm3
  821873:	xorpd  %xmm10,%xmm10
  821878:	ucomisd %xmm10,%xmm3
  82187d:	jne    821881 <gpui_gpu::renderer::validate_draw+0x161>
  82187f:	jnp    8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821881:	movq   %xmm3,%rcx
  821886:	movabs $0x7fffffffffffffff,%rax
  821890:	and    %rax,%rcx
  821893:	movabs $0x7ff0000000000000,%rdx
  82189d:	cmp    %rdx,%rcx
  8218a0:	jl     8218b1 <gpui_gpu::renderer::validate_draw+0x191>
  8218a2:	movl   $0x5,(%rbx)
  8218a8:	mov    %r14,0x8(%rbx)
  8218ac:	jmp    8217bd <gpui_gpu::renderer::validate_draw+0x9d>
  8218b1:	xorps  %xmm10,%xmm10
  8218b5:	cvtsi2sd %r12d,%xmm10
  8218ba:	cvtsi2sd %ebp,%xmm12
  8218bf:	movsd  %xmm9,%xmm2
  8218c4:	movapd -0x776a9d(%rip),%xmm13        # aae30 <GCC_except_table0+0x7c>
  8218cd:	andpd  %xmm13,%xmm2
  8218d2:	movapd %xmm10,%xmm11
  8218d7:	unpcklpd %xmm12,%xmm11
  8218dc:	movapd %xmm2,%xmm9
  8218e1:	movapd %xmm11,0x50(%rsp)
  8218e8:	mulpd  %xmm11,%xmm9
  8218ed:	movapd %xmm9,%xmm11
  8218f2:	unpckhpd %xmm9,%xmm11
  8218f7:	addsd  %xmm9,%xmm11
  8218fc:	movapd %xmm0,%xmm9
  821901:	andpd  %xmm13,%xmm9
  821906:	addsd  %xmm11,%xmm9
  82190b:	shufpd $0x2,%xmm5,%xmm1
  821910:	andpd  %xmm13,%xmm1
  821915:	unpcklpd %xmm10,%xmm12
  82191a:	movapd %xmm1,%xmm10
  82191f:	movapd %xmm12,0x40(%rsp)
  821926:	mulpd  %xmm12,%xmm10
  82192b:	movapd %xmm10,%xmm11
  821930:	unpckhpd %xmm10,%xmm11
  821935:	addsd  %xmm9,%xmm11
  82193a:	addsd  %xmm10,%xmm11
  82193f:	movapd %xmm0,%xmm10
  821944:	unpckhpd %xmm0,%xmm10
  821949:	andpd  %xmm13,%xmm10
  82194e:	addsd  %xmm11,%xmm10
  821953:	movsd  0x38(%r15),%xmm9
  821959:	movsd  0x40(%r15),%xmm12
  82195f:	andps  -0x774177(%rip),%xmm9        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821967:	cvtps2pd %xmm9,%xmm15
  82196b:	movapd %xmm10,%xmm9
  821970:	addsd  %xmm15,%xmm9
  821975:	movapd %xmm15,0x60(%rsp)
  82197c:	unpckhpd %xmm15,%xmm15
  821981:	addsd  %xmm15,%xmm9
  821986:	cvtps2pd %xmm12,%xmm11
  82198a:	movapd %xmm11,0x20(%rsp)
  821991:	andpd  %xmm13,%xmm11
  821996:	addsd  %xmm11,%xmm9
  82199b:	pshufd $0xee,%xmm11,%xmm14
  8219a1:	movdqa %xmm14,0x30(%rsp)
  8219a8:	addsd  %xmm14,%xmm9
  8219ad:	movq   %xmm9,%rsi
  8219b2:	and    %rax,%rsi
  8219b5:	movabs $0x7fefffffffffffff,%rcx
  8219bf:	cmp    %rcx,%rsi
  8219c2:	jg     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  8219c8:	ucomisd -0x772359(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8219d1:	ja     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  8219d7:	movzbl (%r15),%esi
  8219db:	cmp    $0x3,%esi
  8219de:	je     8219f6 <gpui_gpu::renderer::validate_draw+0x2d6>
  8219e0:	xorpd  %xmm14,%xmm14
  8219e5:	cmp    $0x1,%esi
  8219e8:	jne    821b22 <gpui_gpu::renderer::validate_draw+0x402>
  8219ee:	movss  0x4(%r15),%xmm14
  8219f4:	jmp    821a0d <gpui_gpu::renderer::validate_draw+0x2ed>
  8219f6:	movss  0x4(%r15),%xmm14
  8219fc:	xorpd  %xmm13,%xmm13
  821a01:	ucomiss %xmm13,%xmm14
  821a05:	jne    821a0d <gpui_gpu::renderer::validate_draw+0x2ed>
  821a07:	jnp    821c47 <gpui_gpu::renderer::validate_draw+0x527>
  821a0d:	movd   %xmm14,%edi
  821a12:	test   %edi,%edi
  821a14:	sets   %r8b
  821a18:	and    $0x7fffffff,%edi
  821a1e:	lea    -0x800000(%rdi),%r9d
  821a25:	cmp    $0x7f000000,%r9d
  821a2c:	setb   %r9b
  821a30:	and    %r8b,%r9b
  821a33:	lea    -0x1(%rdi),%r10d
  821a37:	cmp    $0x7fffff,%r10d
  821a3e:	setb   %r10b
  821a42:	and    %r8b,%r10b
  821a45:	cmp    $0x7f800000,%edi
  821a4b:	sete   %dil
  821a4f:	setg   %r8b
  821a53:	or     %dil,%r8b
  821a56:	or     %r10b,%r8b
  821a59:	or     %r9b,%r8b
  821a5c:	cmp    $0x1,%r8b
  821a60:	je     8217b7 <gpui_gpu::renderer::validate_draw+0x97>
  821a66:	movaps %xmm11,(%rsp)
  821a6b:	movaps %xmm14,%xmm11
  821a6f:	movaps %xmm14,0x10(%rsp)
  821a75:	movaps %xmm12,%xmm14
  821a79:	mulss  -0x772ab6(%rip),%xmm14        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821a82:	minss  %xmm14,%xmm11
  821a87:	movaps %xmm11,%xmm14
  821a8b:	cmpunordss %xmm11,%xmm14
  821a91:	movaps %xmm14,%xmm13
  821a95:	andnps %xmm11,%xmm13
  821a99:	andps  0x10(%rsp),%xmm14
  821a9f:	orps   %xmm13,%xmm14
  821aa3:	shufps $0x55,%xmm12,%xmm12
  821aa8:	mulss  -0x772ae5(%rip),%xmm12        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821ab1:	movaps %xmm14,%xmm11
  821ab5:	minss  %xmm12,%xmm11
  821aba:	movaps %xmm11,%xmm12
  821abe:	cmpunordss %xmm11,%xmm12
  821ac4:	andps  %xmm12,%xmm14
  821ac8:	andnps %xmm11,%xmm12
  821acc:	orps   %xmm14,%xmm12
  821ad0:	movss  -0x772829(%rip),%xmm11        # af2b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821ad9:	ucomiss %xmm12,%xmm11
  821add:	ja     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821ae3:	xorps  %xmm14,%xmm14
  821ae7:	cvtss2sd %xmm12,%xmm14
  821aec:	movapd %xmm9,%xmm11
  821af1:	divsd  %xmm14,%xmm11
  821af6:	ucomisd -0x772217(%rip),%xmm11        # af8e8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  821aff:	ja     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821b05:	addsd  %xmm9,%xmm14
  821b0a:	mulsd  -0x77238b(%rip),%xmm14        # af788 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821b13:	movapd (%rsp),%xmm11
  821b19:	movapd -0x776cf2(%rip),%xmm13        # aae30 <GCC_except_table0+0x7c>
  821b22:	cmp    $0x2,%esi
  821b25:	movaps %xmm11,(%rsp)
  821b2a:	jae    821c3b <gpui_gpu::renderer::validate_draw+0x51b>
  821b30:	cvtps2pd %xmm8,%xmm8
  821b34:	subpd  %xmm8,%xmm5
  821b39:	cvtps2pd %xmm7,%xmm7
  821b3c:	andpd  %xmm13,%xmm5
  821b41:	mulpd  0x40(%rsp),%xmm5
  821b47:	subpd  %xmm7,%xmm4
  821b4b:	andpd  %xmm13,%xmm4
  821b50:	mulpd  0x50(%rsp),%xmm4
  821b56:	addpd  %xmm5,%xmm4
  821b5a:	cvtps2pd %xmm6,%xmm5
  821b5d:	subpd  %xmm5,%xmm0
  821b61:	addsd  -0x77228a(%rip),%xmm10        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821b6a:	mulsd  -0x7720c3(%rip),%xmm10        # afab0 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821b73:	andpd  %xmm13,%xmm0
  821b78:	addpd  %xmm4,%xmm0
  821b7c:	movapd 0x60(%rsp),%xmm7
  821b82:	addsd  %xmm7,%xmm15
  821b87:	movapd (%rsp),%xmm6
  821b8c:	addsd  %xmm6,%xmm15
  821b91:	addsd  0x30(%rsp),%xmm15
  821b98:	movapd %xmm0,%xmm4
  821b9c:	unpckhpd %xmm0,%xmm4
  821ba0:	addpd  %xmm0,%xmm4
  821ba4:	movapd %xmm1,%xmm5
  821ba8:	shufpd $0x1,%xmm4,%xmm5
  821bad:	movapd %xmm2,%xmm4
  821bb1:	unpcklpd %xmm10,%xmm4
  821bb6:	addpd  %xmm4,%xmm5
  821bba:	mulsd  -0x77250b(%rip),%xmm15        # af6b8 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821bc3:	shufpd $0x1,%xmm15,%xmm2
  821bc9:	addpd  %xmm5,%xmm2
  821bcd:	unpcklpd %xmm14,%xmm1
  821bd2:	addpd  %xmm2,%xmm1
  821bd6:	movapd %xmm1,%xmm2
  821bda:	unpckhpd %xmm1,%xmm2
  821bde:	mulsd  %xmm1,%xmm2
  821be2:	andpd  -0x776dba(%rip),%xmm3        # aae30 <GCC_except_table0+0x7c>
  821bea:	divsd  %xmm3,%xmm2
  821bee:	movq   %xmm2,%rdx
  821bf3:	and    %rax,%rdx
  821bf6:	cmp    %rcx,%rdx
  821bf9:	jg     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821bff:	ucomisd -0x771cf7(%rip),%xmm2        # aff10 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821c07:	ja     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821c0d:	unpcklpd %xmm10,%xmm10
  821c12:	addpd  %xmm10,%xmm0
  821c17:	addpd  %xmm7,%xmm6
  821c1b:	mulpd  -0x776c13(%rip),%xmm6        # ab010 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821c23:	addpd  %xmm0,%xmm6
  821c27:	cvtpd2ps %xmm6,%xmm0
  821c2b:	movlpd %xmm0,0x4(%rbx)
  821c30:	movl   $0xffffffff,(%rbx)
  821c36:	jmp    8217bd <gpui_gpu::renderer::validate_draw+0x9d>
  821c3b:	jne    821c50 <gpui_gpu::renderer::validate_draw+0x530>
  821c3d:	mov    0x28(%r15),%rsi
  821c41:	mov    0x30(%r15),%rdi
  821c45:	jmp    821c58 <gpui_gpu::renderer::validate_draw+0x538>
  821c47:	movaps %xmm11,(%rsp)
  821c4c:	xorps  %xmm14,%xmm14
  821c50:	mov    0x28(%r15),%esi
  821c54:	mov    0x2c(%r15),%edi
  821c58:	movq   %rsi,%xmm11
  821c5d:	punpckldq -0x776316(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821c66:	subpd  -0x776e4f(%rip),%xmm11        # aae20 <GCC_except_table0+0x6c>
  821c6f:	movapd %xmm11,%xmm12
  821c74:	unpckhpd %xmm11,%xmm12
  821c79:	addsd  %xmm11,%xmm12
  821c7e:	movapd 0x20(%rsp),%xmm11
  821c85:	divsd  %xmm11,%xmm12
  821c8a:	movq   %xmm12,%r8
  821c8f:	and    %rax,%r8
  821c92:	cmp    %rdx,%r8
  821c95:	jge    8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821c9b:	movaps %xmm14,0x10(%rsp)
  821ca1:	movapd %xmm11,%xmm14
  821ca6:	movq   %rdi,%xmm11
  821cab:	punpckldq -0x776364(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821cb4:	subpd  -0x776e9d(%rip),%xmm11        # aae20 <GCC_except_table0+0x6c>
  821cbd:	movapd %xmm11,%xmm13
  821cc2:	unpckhpd %xmm11,%xmm13
  821cc7:	addsd  %xmm11,%xmm13
  821ccc:	unpckhpd %xmm14,%xmm14
  821cd1:	divsd  %xmm14,%xmm13
  821cd6:	movapd 0x10(%rsp),%xmm14
  821cdd:	movq   %xmm13,%rdx
  821ce2:	and    %rax,%rdx
  821ce5:	cmp    %rcx,%rdx
  821ce8:	setg   %dl
  821ceb:	ucomisd -0x77267c(%rip),%xmm13        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821cf4:	movapd -0x776ecd(%rip),%xmm13        # aae30 <GCC_except_table0+0x7c>
  821cfd:	ja     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821d03:	ucomisd -0x772694(%rip),%xmm12        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821d0c:	ja     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821d12:	test   %dl,%dl
  821d14:	jne    8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821d1a:	cmp    %rsi,%rdi
  821d1d:	cmova  %rdi,%rsi
  821d21:	movq   %rsi,%xmm11
  821d26:	punpckldq -0x7763df(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821d2f:	subpd  -0x776f18(%rip),%xmm11        # aae20 <GCC_except_table0+0x6c>
  821d38:	movapd %xmm11,%xmm12
  821d3d:	unpckhpd %xmm11,%xmm12
  821d42:	addsd  %xmm11,%xmm12
  821d47:	mulsd  %xmm12,%xmm9
  821d4c:	ucomisd -0x7726dd(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821d55:	ja     8218a2 <gpui_gpu::renderer::validate_draw+0x182>
  821d5b:	jmp    821b30 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822470 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  822470:	push   %rbp
  822471:	push   %r15
  822473:	push   %r14
  822475:	push   %r13
  822477:	push   %r12
  822479:	push   %rbx
  82247a:	sub    $0x58,%rsp
  82247e:	mov    %ecx,%ebp
  822480:	mov    %rdx,0x8(%rsp)
  822485:	mov    0x18(%rdi),%rax
  822489:	add    %rax,%rsi
  82248c:	jb     8225a1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822492:	mov    %rdi,%rbx
  822495:	mov    0x8(%rdi),%r15
  822499:	lea    0x1(%r15),%rdx
  82249d:	mov    %rdx,%rdi
  8224a0:	shr    $0x3,%rdi
  8224a4:	mov    %rdx,%rcx
  8224a7:	and    $0xfffffffffffffff8,%rcx
  8224ab:	sub    %rdi,%rcx
  8224ae:	cmp    $0x8,%r15
  8224b2:	cmovb  %r15,%rcx
  8224b6:	mov    %rcx,%rdi
  8224b9:	shr    $1,%rdi
  8224bc:	cmp    %rdi,%rsi
  8224bf:	jbe    8224f0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  8224c1:	inc    %rcx
  8224c4:	cmp    %rsi,%rcx
  8224c7:	cmovbe %rsi,%rcx
  8224cb:	cmp    $0xf,%rcx
  8224cf:	mov    %rbx,(%rsp)
  8224d3:	jae    822521 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  8224d5:	mov    %ecx,%eax
  8224d7:	and    $0x8,%eax
  8224da:	add    $0x8,%rax
  8224de:	cmp    $0x4,%rcx
  8224e2:	mov    $0x4,%ebx
  8224e7:	cmovae %rax,%rbx
  8224eb:	jmp    822579 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  8224f0:	test   %rdx,%rdx
  8224f3:	je     82277a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  8224f9:	mov    (%rbx),%rsi
  8224fc:	mov    %rdx,%rax
  8224ff:	shr    $0x4,%rax
  822503:	mov    %edx,%ecx
  822505:	and    $0xf,%ecx
  822508:	cmp    $0x1,%rcx
  82250c:	sbb    $0xffffffffffffffff,%rax
  822510:	cmp    $0x1,%rax
  822514:	jne    822781 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  82251a:	xor    %ecx,%ecx
  82251c:	jmp    8227d4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  822521:	movabs $0x1ffffffffffffffe,%rax
  82252b:	inc    %rax
  82252e:	cmp    %rax,%rcx
  822531:	ja     8225a1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822533:	shl    $0x3,%rcx
  822537:	movabs $0x2492492492492493,%rdx
  822541:	mov    %rcx,%rax
  822544:	mul    %rdx
  822547:	sub    %rdx,%rcx
  82254a:	shr    $1,%rcx
  82254d:	add    %rdx,%rcx
  822550:	shr    $0x2,%rcx
  822554:	dec    %rcx
  822557:	bsr    %rcx,%rcx
  82255b:	not    %ecx
  82255d:	mov    $0xffffffffffffffff,%rbx
  822564:	shr    %cl,%rbx
  822567:	movabs $0x7fffffffffffffe,%rax
  822571:	cmp    %rax,%rbx
  822574:	ja     8225a1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822576:	inc    %rbx
  822579:	mov    %rbx,%r14
  82257c:	shl    $0x5,%r14
  822580:	lea    0x10(%rbx),%r12
  822584:	mov    %r12,%r13
  822587:	add    %r14,%r13
  82258a:	setb   %al
  82258d:	movabs $0x7ffffffffffffff0,%rcx
  822597:	cmp    %rcx,%r13
  82259a:	seta   %cl
  82259d:	or     %al,%cl
  82259f:	je     8225b0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  8225a1:	movzbl %bpl,%edi
  8225a5:	call   *0x65ed5d(%rip)        # e81308 <_DYNAMIC+0x678>
  8225ab:	jmp    8229f5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8225b0:	call   *0x65e96a(%rip)        # e80f20 <_DYNAMIC+0x290>
  8225b6:	mov    $0x10,%esi
  8225bb:	mov    %r13,%rdi
  8225be:	call   *0x65e964(%rip)        # e80f28 <_DYNAMIC+0x298>
  8225c4:	test   %rax,%rax
  8225c7:	je     822a13 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  8225cd:	mov    %rax,%r15
  8225d0:	mov    (%rsp),%rcx
  8225d4:	lea    0x20(%rcx),%r13
  8225d8:	add    %r14,%r15
  8225db:	lea    -0x1(%rbx),%r14
  8225df:	mov    %rbx,%rax
  8225e2:	shr    $0x3,%rax
  8225e6:	mov    %rbx,%rbp
  8225e9:	and    $0xfffffffffffffff8,%rbp
  8225ed:	sub    %rax,%rbp
  8225f0:	cmp    $0x9,%rbx
  8225f4:	mov    %rcx,%rbx
  8225f7:	cmovb  %r14,%rbp
  8225fb:	mov    %r15,%rdi
  8225fe:	mov    $0xff,%esi
  822603:	mov    %r12,%rdx
  822606:	call   *0x65ed04(%rip)        # e81310 <memset@GLIBC_2.2.5>
  82260c:	mov    %r14,%rdi
  82260f:	mov    %r13,0x20(%rsp)
  822614:	movq   $0x20,0x28(%rsp)
  82261d:	movq   $0x10,0x30(%rsp)
  822626:	mov    %r15,0x38(%rsp)
  82262b:	mov    %r14,0x40(%rsp)
  822630:	mov    %rbp,0x48(%rsp)
  822635:	movq   $0x0,0x50(%rsp)
  82263e:	mov    0x18(%rbx),%r12
  822642:	test   %r12,%r12
  822645:	je     822a27 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82264b:	mov    %rbp,0x10(%rsp)
  822650:	mov    (%rbx),%rsi
  822653:	movdqa (%rsi),%xmm0
  822657:	pmovmskb %xmm0,%r13d
  82265c:	not    %r13d
  82265f:	xor    %ebp,%ebp
  822661:	mov    %rsi,%r14
  822664:	mov    %rdi,0x18(%rsp)
  822669:	nopl   0x0(%rax)
  822670:	test   %r13w,%r13w
  822674:	jne    82269f <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  822676:	cs nopw 0x0(%rax,%rax,1)
  822680:	movdqa 0x10(%r14),%xmm0
  822686:	add    $0x10,%r14
  82268a:	pmovmskb %xmm0,%r13d
  82268f:	xor    $0xffff,%r13d
  822696:	add    $0x10,%rbp
  82269a:	test   %r13d,%r13d
  82269d:	je     822680 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  82269f:	tzcnt  %r13d,%ebx
  8226a4:	add    %rbp,%rbx
  8226a7:	mov    %rbx,%rax
  8226aa:	shl    $0x5,%rax
  8226ae:	sub    %rax,%rsi
  8226b1:	add    $0xffffffffffffffe0,%rsi
  8226b5:	mov    0x8(%rsp),%rdi
  8226ba:	call   825110 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8226bf:	mov    %rax,%rdx
  8226c2:	mov    0x18(%rsp),%rdi
  8226c7:	and    %rdi,%rdx
  8226ca:	movdqu (%r15,%rdx,1),%xmm0
  8226d0:	pmovmskb %xmm0,%ecx
  8226d4:	test   %ecx,%ecx
  8226d6:	je     822745 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  8226d8:	tzcnt  %ecx,%ecx
  8226dc:	add    %rdx,%rcx
  8226df:	and    %rdi,%rcx
  8226e2:	cmpb   $0x0,(%r15,%rcx,1)
  8226e7:	jns    822768 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  8226e9:	lea    -0x1(%r13),%edx
  8226ed:	and    %r13d,%edx
  8226f0:	dec    %r12
  8226f3:	shr    $0x39,%rax
  8226f7:	lea    -0x10(%rcx),%rsi
  8226fb:	and    %rdi,%rsi
  8226fe:	mov    %al,(%r15,%rcx,1)
  822702:	mov    %al,0x10(%r15,%rsi,1)
  822707:	mov    (%rsp),%rax
  82270b:	mov    (%rax),%rsi
  82270e:	not    %rbx
  822711:	shl    $0x5,%rbx
  822715:	not    %rcx
  822718:	shl    $0x5,%rcx
  82271c:	movdqu (%rsi,%rbx,1),%xmm0
  822721:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  822727:	movdqu %xmm1,0x10(%r15,%rcx,1)
  82272e:	movdqu %xmm0,(%r15,%rcx,1)
  822734:	mov    %edx,%r13d
  822737:	test   %r12,%r12
  82273a:	jne    822670 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  822740:	jmp    822a04 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  822745:	mov    $0x10,%esi
  82274a:	add    %rsi,%rdx
  82274d:	and    %rdi,%rdx
  822750:	movdqu (%r15,%rdx,1),%xmm0
  822756:	pmovmskb %xmm0,%ecx
  82275a:	add    $0x10,%rsi
  82275e:	test   %ecx,%ecx
  822760:	jne    8226d8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  822766:	jmp    82274a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  822768:	movdqa (%r15),%xmm0
  82276d:	pmovmskb %xmm0,%ecx
  822771:	tzcnt  %ecx,%ecx
  822775:	jmp    8226e9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  82277a:	xor    %ecx,%ecx
  82277c:	jmp    8229e7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  822781:	movabs $0x1ffffffffffffffe,%rdi
  82278b:	and    %rax,%rdi
  82278e:	xor    %ecx,%ecx
  822790:	movdqa -0x774b98(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822798:	nopl   0x0(%rax,%rax,1)
  8227a0:	pxor   %xmm1,%xmm1
  8227a4:	pcmpgtb (%rsi,%rcx,1),%xmm1
  8227a9:	por    %xmm0,%xmm1
  8227ad:	movdqa %xmm1,(%rsi,%rcx,1)
  8227b2:	pxor   %xmm1,%xmm1
  8227b6:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  8227bc:	por    %xmm0,%xmm1
  8227c0:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  8227c6:	add    $0x20,%rcx
  8227ca:	add    $0xfffffffffffffffe,%rdi
  8227ce:	jne    8227a0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  8227d0:	test   $0x1,%al
  8227d2:	je     8227ea <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  8227d4:	pxor   %xmm0,%xmm0
  8227d8:	pcmpgtb (%rsi,%rcx,1),%xmm0
  8227dd:	por    -0x774be5(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  8227e5:	movdqa %xmm0,(%rsi,%rcx,1)
  8227ea:	cmp    $0x10,%rdx
  8227ee:	jb     822a78 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  8227f4:	mov    %rdx,%rdi
  8227f7:	mov    $0x10,%edx
  8227fc:	add    %rsi,%rdi
  8227ff:	call   *0x65eb13(%rip)        # e81318 <memmove@GLIBC_2.2.5>
  822805:	movq   $0x0,0x28(%rsp)
  82280e:	movq   $0x20,0x30(%rsp)
  822817:	mov    %rbx,0x20(%rsp)
  82281c:	xor    %r12d,%r12d
  82281f:	xor    %r13d,%r13d
  822822:	jmp    822971 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  822827:	nopw   0x0(%rax,%rax,1)
  822830:	lea    (%rax,%rbp,1),%rsi
  822834:	add    $0xffffffffffffffe0,%rsi
  822838:	mov    0x8(%rsp),%rdi
  82283d:	call   825110 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  822842:	mov    (%rbx),%rcx
  822845:	mov    0x8(%rbx),%rdx
  822849:	mov    %rdx,%rsi
  82284c:	and    %rax,%rsi
  82284f:	movdqu (%rcx,%rsi,1),%xmm0
  822854:	pmovmskb %xmm0,%edi
  822858:	mov    %rsi,%r8
  82285b:	test   %edi,%edi
  82285d:	je     822909 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  822863:	tzcnt  %edi,%edi
  822867:	add    %r8,%rdi
  82286a:	and    %rdx,%rdi
  82286d:	cmpb   $0x0,(%rcx,%rdi,1)
  822871:	jns    822930 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  822877:	mov    %r12,%r8
  82287a:	sub    %rsi,%r8
  82287d:	mov    %rdi,%r9
  822880:	sub    %rsi,%r9
  822883:	xor    %r8,%r9
  822886:	and    %rdx,%r9
  822889:	cmp    $0x10,%r9
  82288d:	jb     822950 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  822893:	mov    %rdi,%rsi
  822896:	not    %rsi
  822899:	shl    $0x5,%rsi
  82289d:	add    %rcx,%rsi
  8228a0:	movzbl (%rcx,%rdi,1),%r8d
  8228a5:	shr    $0x39,%rax
  8228a9:	lea    -0x10(%rdi),%r9
  8228ad:	and    %rdx,%r9
  8228b0:	mov    %al,(%rcx,%rdi,1)
  8228b3:	mov    (%rbx),%rcx
  8228b6:	mov    %al,0x10(%rcx,%r9,1)
  8228bb:	cmp    $0xff,%r8b
  8228bf:	je     822996 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  8228c5:	mov    (%r14),%rax
  8228c8:	mov    (%rsi),%rcx
  8228cb:	mov    %rcx,(%r14)
  8228ce:	mov    %rax,(%rsi)
  8228d1:	mov    0x8(%r14),%rax
  8228d5:	mov    0x8(%rsi),%rcx
  8228d9:	mov    %rcx,0x8(%r14)
  8228dd:	mov    %rax,0x8(%rsi)
  8228e1:	mov    0x10(%r14),%rax
  8228e5:	mov    0x10(%rsi),%rcx
  8228e9:	mov    %rcx,0x10(%r14)
  8228ed:	mov    %rax,0x10(%rsi)
  8228f1:	mov    0x18(%r14),%rax
  8228f5:	mov    0x18(%rsi),%rcx
  8228f9:	mov    %rcx,0x18(%r14)
  8228fd:	mov    %rax,0x18(%rsi)
  822901:	mov    (%rbx),%rax
  822904:	jmp    822830 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822909:	mov    $0x10,%r9d
  82290f:	mov    %rsi,%r8
  822912:	add    %r9,%r8
  822915:	and    %rdx,%r8
  822918:	movdqu (%rcx,%r8,1),%xmm0
  82291e:	pmovmskb %xmm0,%edi
  822922:	add    $0x10,%r9
  822926:	test   %edi,%edi
  822928:	jne    822863 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  82292e:	jmp    822912 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  822930:	movdqa (%rcx),%xmm0
  822934:	pmovmskb %xmm0,%edi
  822938:	tzcnt  %edi,%edi
  82293c:	jmp    822877 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  822941:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  822950:	shr    $0x39,%rax
  822954:	lea    -0x10(%r12),%rsi
  822959:	and    %rsi,%rdx
  82295c:	mov    %al,(%rcx,%r12,1)
  822960:	mov    (%rbx),%rcx
  822963:	mov    %al,0x10(%rcx,%rdx,1)
  822967:	cmp    %r15,%r12
  82296a:	lea    0x1(%r12),%r12
  82296f:	je     8229c5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  822971:	mov    (%rbx),%rax
  822974:	cmp    (%rax,%r12,1),%r13b
  822978:	jno    822967 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  82297a:	mov    %r12,%r14
  82297d:	not    %r14
  822980:	shl    $0x5,%r14
  822984:	add    %rax,%r14
  822987:	mov    %r12,%rbp
  82298a:	neg    %rbp
  82298d:	shl    $0x5,%rbp
  822991:	jmp    822830 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822996:	lea    -0x10(%r12),%rax
  82299b:	and    0x8(%rbx),%rax
  82299f:	mov    (%rbx),%rcx
  8229a2:	movb   $0xff,(%rcx,%r12,1)
  8229a7:	mov    (%rbx),%rcx
  8229aa:	movb   $0xff,0x10(%rcx,%rax,1)
  8229af:	movdqu (%r14),%xmm0
  8229b4:	movdqu 0x10(%r14),%xmm1
  8229ba:	movdqu %xmm1,0x10(%rsi)
  8229bf:	movdqu %xmm0,(%rsi)
  8229c3:	jmp    822967 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  8229c5:	mov    0x8(%rbx),%rdx
  8229c9:	mov    0x18(%rbx),%rax
  8229cd:	lea    0x1(%rdx),%rcx
  8229d1:	mov    %rcx,%rsi
  8229d4:	shr    $0x3,%rsi
  8229d8:	and    $0xfffffffffffffff8,%rcx
  8229dc:	sub    %rsi,%rcx
  8229df:	cmp    $0x8,%rdx
  8229e3:	cmovb  %rdx,%rcx
  8229e7:	sub    %rax,%rcx
  8229ea:	mov    %rcx,0x10(%rbx)
  8229ee:	mov    $0xffffffffffffffff,%rax
  8229f5:	add    $0x58,%rsp
  8229f9:	pop    %rbx
  8229fa:	pop    %r12
  8229fc:	pop    %r13
  8229fe:	pop    %r14
  822a00:	pop    %r15
  822a02:	pop    %rbp
  822a03:	ret
  822a04:	mov    (%rsp),%rbx
  822a08:	mov    0x18(%rbx),%rcx
  822a0c:	mov    0x10(%rsp),%rbp
  822a11:	jmp    822a2c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  822a13:	movzbl %bpl,%edi
  822a17:	mov    $0x10,%esi
  822a1c:	mov    %r13,%rdx
  822a1f:	call   *0x65e8fb(%rip)        # e81320 <_DYNAMIC+0x690>
  822a25:	jmp    8229f5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  822a27:	mov    (%rbx),%rsi
  822a2a:	xor    %ecx,%ecx
  822a2c:	sub    %rcx,%rbp
  822a2f:	mov    %r15,(%rbx)
  822a32:	mov    0x8(%rbx),%rax
  822a36:	mov    %rdi,0x8(%rbx)
  822a3a:	mov    %rbp,0x10(%rbx)
  822a3e:	mov    %rcx,0x18(%rbx)
  822a42:	test   %rax,%rax
  822a45:	je     8229ee <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822a47:	mov    %rax,%rcx
  822a4a:	shl    $0x5,%rcx
  822a4e:	add    $0x2f,%rcx
  822a52:	and    $0xffffffffffffffe0,%rcx
  822a56:	add    %rcx,%rax
  822a59:	add    $0x11,%rax
  822a5d:	je     8229ee <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822a5f:	sub    %rcx,%rsi
  822a62:	mov    $0x10,%edx
  822a67:	mov    %rsi,%rdi
  822a6a:	mov    %rax,%rsi
  822a6d:	call   *0x65e465(%rip)        # e80ed8 <_DYNAMIC+0x248>
  822a73:	jmp    8229ee <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822a78:	mov    $0x10,%edi
  822a7d:	jmp    8227fc <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  822a82:	mov    %rax,%rbx
  822a85:	lea    0x20(%rsp),%rdi
  822a8a:	call   823060 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  822a8f:	mov    %rbx,%rdi
  822a92:	call   e2d9a0 <_Unwind_Resume@plt>
  822a97:	mov    %rax,%rbx
  822a9a:	lea    0x20(%rsp),%rdi
  822a9f:	call   8230a0 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  822aa4:	mov    %rbx,%rdi
  822aa7:	call   e2d9a0 <_Unwind_Resume@plt>
  822aac:	call   *0x65e42e(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822ac0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  822ac0:	push   %rbp
  822ac1:	push   %r15
  822ac3:	push   %r14
  822ac5:	push   %r13
  822ac7:	push   %r12
  822ac9:	push   %rbx
  822aca:	sub    $0x38,%rsp
  822ace:	mov    %ecx,%r15d
  822ad1:	mov    %rdx,0x20(%rsp)
  822ad6:	mov    %rdi,%rbp
  822ad9:	mov    0x18(%rdi),%rdi
  822add:	add    %rdi,%rsi
  822ae0:	jb     822bf8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822ae6:	mov    0x8(%rbp),%rbx
  822aea:	lea    0x1(%rbx),%rdx
  822aee:	mov    %rdx,%rax
  822af1:	shr    $0x3,%rax
  822af5:	mov    %rdx,%rcx
  822af8:	and    $0xfffffffffffffff8,%rcx
  822afc:	sub    %rax,%rcx
  822aff:	cmp    $0x8,%rbx
  822b03:	cmovb  %rbx,%rcx
  822b07:	mov    %rcx,%rax
  822b0a:	shr    $1,%rax
  822b0d:	cmp    %rax,%rsi
  822b10:	jbe    822b46 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  822b12:	inc    %rcx
  822b15:	cmp    %rsi,%rcx
  822b18:	cmovbe %rsi,%rcx
  822b1c:	cmp    $0xf,%rcx
  822b20:	mov    %rbp,(%rsp)
  822b24:	mov    %rbx,0x30(%rsp)
  822b29:	jae    822b78 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  822b2b:	mov    %ecx,%eax
  822b2d:	and    $0x8,%eax
  822b30:	add    $0x8,%rax
  822b34:	cmp    $0x4,%rcx
  822b38:	mov    $0x4,%ebx
  822b3d:	cmovae %rax,%rbx
  822b41:	jmp    822bd0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  822b46:	test   %rdx,%rdx
  822b49:	je     822d8e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  822b4f:	mov    0x0(%rbp),%r12
  822b53:	mov    %rdx,%rax
  822b56:	shr    $0x4,%rax
  822b5a:	mov    %edx,%ecx
  822b5c:	and    $0xf,%ecx
  822b5f:	cmp    $0x1,%rcx
  822b63:	sbb    $0xffffffffffffffff,%rax
  822b67:	cmp    $0x1,%rax
  822b6b:	jne    822d95 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822b71:	xor    %ecx,%ecx
  822b73:	jmp    822de8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  822b78:	movabs $0x1ffffffffffffffe,%rax
  822b82:	inc    %rax
  822b85:	cmp    %rax,%rcx
  822b88:	ja     822bf8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822b8a:	shl    $0x3,%rcx
  822b8e:	movabs $0x2492492492492493,%rdx
  822b98:	mov    %rcx,%rax
  822b9b:	mul    %rdx
  822b9e:	sub    %rdx,%rcx
  822ba1:	shr    $1,%rcx
  822ba4:	add    %rdx,%rcx
  822ba7:	shr    $0x2,%rcx
  822bab:	dec    %rcx
  822bae:	bsr    %rcx,%rcx
  822bb2:	not    %ecx
  822bb4:	mov    $0xffffffffffffffff,%rbx
  822bbb:	shr    %cl,%rbx
  822bbe:	movabs $0xffffffffffffffe,%rax
  822bc8:	cmp    %rax,%rbx
  822bcb:	ja     822bf8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822bcd:	inc    %rbx
  822bd0:	mov    %rbx,%r14
  822bd3:	shl    $0x4,%r14
  822bd7:	lea    0x10(%rbx),%rbp
  822bdb:	mov    %rbp,%r13
  822bde:	add    %r14,%r13
  822be1:	setb   %al
  822be4:	movabs $0x7ffffffffffffff0,%rcx
  822bee:	cmp    %rcx,%r13
  822bf1:	seta   %cl
  822bf4:	or     %al,%cl
  822bf6:	je     822c07 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  822bf8:	movzbl %r15b,%edi
  822bfc:	call   *0x65e706(%rip)        # e81308 <_DYNAMIC+0x678>
  822c02:	jmp    822fc8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822c07:	mov    %rdi,0x8(%rsp)
  822c0c:	call   *0x65e30e(%rip)        # e80f20 <_DYNAMIC+0x290>
  822c12:	mov    $0x10,%esi
  822c17:	mov    %r13,%rdi
  822c1a:	call   *0x65e308(%rip)        # e80f28 <_DYNAMIC+0x298>
  822c20:	test   %rax,%rax
  822c23:	je     822fe2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  822c29:	mov    %rax,%rdi
  822c2c:	add    %r14,%rdi
  822c2f:	lea    -0x1(%rbx),%rcx
  822c33:	mov    %rbx,%rax
  822c36:	shr    $0x3,%rax
  822c3a:	mov    %rbx,%r14
  822c3d:	and    $0xfffffffffffffff8,%r14
  822c41:	sub    %rax,%r14
  822c44:	cmp    $0x9,%rbx
  822c48:	mov    %rcx,0x10(%rsp)
  822c4d:	cmovb  %rcx,%r14
  822c51:	mov    %rdi,0x18(%rsp)
  822c56:	mov    $0xff,%esi
  822c5b:	mov    %rbp,%rdx
  822c5e:	call   *0x65e6ac(%rip)        # e81310 <memset@GLIBC_2.2.5>
  822c64:	mov    0x8(%rsp),%rbx
  822c69:	test   %rbx,%rbx
  822c6c:	je     822ff6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  822c72:	mov    %r14,0x28(%rsp)
  822c77:	mov    (%rsp),%rax
  822c7b:	mov    (%rax),%rdi
  822c7e:	movdqa (%rdi),%xmm0
  822c82:	pmovmskb %xmm0,%r14d
  822c87:	not    %r14d
  822c8a:	xor    %ebp,%ebp
  822c8c:	mov    %rdi,%r13
  822c8f:	nop
  822c90:	test   %r14w,%r14w
  822c94:	jne    822cbf <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  822c96:	cs nopw 0x0(%rax,%rax,1)
  822ca0:	movdqa 0x10(%r13),%xmm0
  822ca6:	add    $0x10,%r13
  822caa:	pmovmskb %xmm0,%r14d
  822caf:	xor    $0xffff,%r14d
  822cb6:	add    $0x10,%rbp
  822cba:	test   %r14d,%r14d
  822cbd:	je     822ca0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  822cbf:	tzcnt  %r14d,%r15d
  822cc4:	add    %rbp,%r15
  822cc7:	mov    %r15,%rax
  822cca:	shl    $0x4,%rax
  822cce:	mov    %rdi,%r12
  822cd1:	mov    %rdi,%rsi
  822cd4:	sub    %rax,%rsi
  822cd7:	add    $0xfffffffffffffff0,%rsi
  822cdb:	mov    0x20(%rsp),%rdi
  822ce0:	call   8252b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822ce5:	mov    %rax,%rcx
  822ce8:	mov    0x10(%rsp),%r9
  822ced:	and    %r9,%rcx
  822cf0:	mov    0x18(%rsp),%r8
  822cf5:	movdqu (%r8,%rcx,1),%xmm0
  822cfb:	pmovmskb %xmm0,%edx
  822cff:	test   %edx,%edx
  822d01:	je     822d60 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  822d03:	tzcnt  %edx,%edx
  822d07:	add    %rcx,%rdx
  822d0a:	and    %r9,%rdx
  822d0d:	cmpb   $0x0,(%r8,%rdx,1)
  822d12:	mov    %r12,%rdi
  822d15:	jns    822d7f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  822d17:	lea    -0x1(%r14),%ecx
  822d1b:	and    %r14d,%ecx
  822d1e:	dec    %rbx
  822d21:	shr    $0x39,%rax
  822d25:	lea    -0x10(%rdx),%rsi
  822d29:	and    %r9,%rsi
  822d2c:	mov    %al,(%r8,%rdx,1)
  822d30:	mov    %al,0x10(%r8,%rsi,1)
  822d35:	not    %r15
  822d38:	shl    $0x4,%r15
  822d3c:	not    %rdx
  822d3f:	shl    $0x4,%rdx
  822d43:	movdqu (%rdi,%r15,1),%xmm0
  822d49:	movdqu %xmm0,(%r8,%rdx,1)
  822d4f:	mov    %ecx,%r14d
  822d52:	test   %rbx,%rbx
  822d55:	jne    822c90 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  822d5b:	jmp    822fd7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  822d60:	mov    $0x10,%esi
  822d65:	add    %rsi,%rcx
  822d68:	and    %r9,%rcx
  822d6b:	movdqu (%r8,%rcx,1),%xmm0
  822d71:	pmovmskb %xmm0,%edx
  822d75:	add    $0x10,%rsi
  822d79:	test   %edx,%edx
  822d7b:	jne    822d03 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  822d7d:	jmp    822d65 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  822d7f:	movdqa (%r8),%xmm0
  822d84:	pmovmskb %xmm0,%ecx
  822d88:	tzcnt  %ecx,%edx
  822d8c:	jmp    822d17 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  822d8e:	xor    %eax,%eax
  822d90:	jmp    822fba <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  822d95:	movabs $0x1ffffffffffffffe,%rsi
  822d9f:	and    %rax,%rsi
  822da2:	xor    %ecx,%ecx
  822da4:	movdqa -0x7751ac(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822dac:	nopl   0x0(%rax)
  822db0:	pxor   %xmm1,%xmm1
  822db4:	pcmpgtb (%r12,%rcx,1),%xmm1
  822dba:	por    %xmm0,%xmm1
  822dbe:	movdqa %xmm1,(%r12,%rcx,1)
  822dc4:	pxor   %xmm1,%xmm1
  822dc8:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  822dcf:	por    %xmm0,%xmm1
  822dd3:	movdqa %xmm1,0x10(%r12,%rcx,1)
  822dda:	add    $0x20,%rcx
  822dde:	add    $0xfffffffffffffffe,%rsi
  822de2:	jne    822db0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  822de4:	test   $0x1,%al
  822de6:	je     822e00 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  822de8:	pxor   %xmm0,%xmm0
  822dec:	pcmpgtb (%r12,%rcx,1),%xmm0
  822df2:	por    -0x7751fa(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822dfa:	movdqa %xmm0,(%r12,%rcx,1)
  822e00:	cmp    $0x10,%rdx
  822e04:	jb     823053 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  822e0a:	mov    %rdx,%rdi
  822e0d:	mov    $0x10,%edx
  822e12:	add    %r12,%rdi
  822e15:	mov    %r12,%rsi
  822e18:	call   *0x65e4fa(%rip)        # e81318 <memmove@GLIBC_2.2.5>
  822e1e:	xor    %r13d,%r13d
  822e21:	xor    %eax,%eax
  822e23:	jmp    822f56 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  822e28:	nopl   0x0(%rax,%rax,1)
  822e30:	lea    (%r12,%r14,1),%rsi
  822e34:	add    $0xfffffffffffffff0,%rsi
  822e38:	mov    0x20(%rsp),%rdi
  822e3d:	call   8252b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822e42:	mov    0x8(%rbp),%rcx
  822e46:	mov    %rcx,%rdx
  822e49:	and    %rax,%rdx
  822e4c:	movdqu (%r12,%rdx,1),%xmm0
  822e52:	pmovmskb %xmm0,%esi
  822e56:	mov    %rdx,%rdi
  822e59:	test   %esi,%esi
  822e5b:	je     822eeb <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  822e61:	tzcnt  %esi,%esi
  822e65:	add    %rdi,%rsi
  822e68:	and    %rcx,%rsi
  822e6b:	cmpb   $0x0,(%r12,%rsi,1)
  822e70:	jns    822f12 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  822e76:	mov    %r13,%rdi
  822e79:	sub    %rdx,%rdi
  822e7c:	mov    %rsi,%r8
  822e7f:	sub    %rdx,%r8
  822e82:	xor    %rdi,%r8
  822e85:	and    %rcx,%r8
  822e88:	cmp    $0x10,%r8
  822e8c:	jb     822f30 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  822e92:	mov    %rsi,%rdx
  822e95:	not    %rdx
  822e98:	shl    $0x4,%rdx
  822e9c:	add    %r12,%rdx
  822e9f:	movzbl (%r12,%rsi,1),%edi
  822ea4:	shr    $0x39,%rax
  822ea8:	lea    -0x10(%rsi),%r8
  822eac:	and    %rcx,%r8
  822eaf:	mov    %al,(%r12,%rsi,1)
  822eb3:	mov    0x0(%rbp),%r12
  822eb7:	mov    %al,0x10(%r12,%r8,1)
  822ebc:	cmp    $0xff,%dil
  822ec0:	je     822f7b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  822ec6:	mov    (%rbx),%rax
  822ec9:	mov    (%rdx),%rcx
  822ecc:	mov    %rcx,(%rbx)
  822ecf:	mov    %rax,(%rdx)
  822ed2:	mov    0x8(%rbx),%rax
  822ed6:	mov    0x8(%rdx),%rcx
  822eda:	mov    %rcx,0x8(%rbx)
  822ede:	mov    %rax,0x8(%rdx)
  822ee2:	mov    0x0(%rbp),%r12
  822ee6:	jmp    822e30 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822eeb:	mov    $0x10,%r8d
  822ef1:	mov    %rdx,%rdi
  822ef4:	add    %r8,%rdi
  822ef7:	and    %rcx,%rdi
  822efa:	movdqu (%r12,%rdi,1),%xmm0
  822f00:	pmovmskb %xmm0,%esi
  822f04:	add    $0x10,%r8
  822f08:	test   %esi,%esi
  822f0a:	jne    822e61 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  822f10:	jmp    822ef4 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  822f12:	movdqa (%r12),%xmm0
  822f18:	pmovmskb %xmm0,%esi
  822f1c:	tzcnt  %esi,%esi
  822f20:	jmp    822e76 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  822f25:	data16 cs nopw 0x0(%rax,%rax,1)
  822f30:	shr    $0x39,%rax
  822f34:	lea    -0x10(%r13),%rdx
  822f38:	and    %rdx,%rcx
  822f3b:	mov    %al,(%r12,%r13,1)
  822f3f:	mov    0x0(%rbp),%r12
  822f43:	mov    %al,0x10(%r12,%rcx,1)
  822f48:	mov    %r15,%rbx
  822f4b:	xor    %eax,%eax
  822f4d:	cmp    %rbx,%r13
  822f50:	lea    0x1(%r13),%r13
  822f54:	je     822f98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  822f56:	cmp    (%r12,%r13,1),%al
  822f5a:	jno    822f4d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  822f5c:	mov    %rbx,%r15
  822f5f:	mov    %r13,%rbx
  822f62:	not    %rbx
  822f65:	shl    $0x4,%rbx
  822f69:	add    %r12,%rbx
  822f6c:	mov    %r13,%r14
  822f6f:	neg    %r14
  822f72:	shl    $0x4,%r14
  822f76:	jmp    822e30 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822f7b:	lea    -0x10(%r13),%rax
  822f7f:	and    0x8(%rbp),%rax
  822f83:	movb   $0xff,(%r12,%r13,1)
  822f88:	movb   $0xff,0x10(%r12,%rax,1)
  822f8e:	movdqu (%rbx),%xmm0
  822f92:	movdqu %xmm0,(%rdx)
  822f96:	jmp    822f48 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  822f98:	mov    0x8(%rbp),%rcx
  822f9c:	mov    0x18(%rbp),%rdi
  822fa0:	lea    0x1(%rcx),%rax
  822fa4:	mov    %rax,%rdx
  822fa7:	shr    $0x3,%rdx
  822fab:	and    $0xfffffffffffffff8,%rax
  822faf:	sub    %rdx,%rax
  822fb2:	cmp    $0x8,%rcx
  822fb6:	cmovb  %rcx,%rax
  822fba:	sub    %rdi,%rax
  822fbd:	mov    %rax,0x10(%rbp)
  822fc1:	mov    $0xffffffffffffffff,%rax
  822fc8:	add    $0x38,%rsp
  822fcc:	pop    %rbx
  822fcd:	pop    %r12
  822fcf:	pop    %r13
  822fd1:	pop    %r14
  822fd3:	pop    %r15
  822fd5:	pop    %rbp
  822fd6:	ret
  822fd7:	mov    (%rsp),%rax
  822fdb:	mov    0x28(%rsp),%r14
  822fe0:	jmp    823007 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  822fe2:	movzbl %r15b,%edi
  822fe6:	mov    $0x10,%esi
  822feb:	mov    %r13,%rdx
  822fee:	call   *0x65e32c(%rip)        # e81320 <_DYNAMIC+0x690>
  822ff4:	jmp    822fc8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822ff6:	mov    (%rsp),%rax
  822ffa:	mov    (%rax),%rdi
  822ffd:	mov    0x18(%rsp),%r8
  823002:	mov    0x10(%rsp),%r9
  823007:	sub    0x8(%rsp),%r14
  82300c:	mov    %r8,(%rax)
  82300f:	mov    %r9,0x8(%rax)
  823013:	mov    %r14,0x10(%rax)
  823017:	mov    $0xffffffffffffffff,%rax
  82301e:	mov    0x30(%rsp),%rsi
  823023:	test   %rsi,%rsi
  823026:	je     822fc8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  823028:	mov    %rsi,%rcx
  82302b:	shl    $0x4,%rcx
  82302f:	add    $0x1f,%rcx
  823033:	and    $0xfffffffffffffff0,%rcx
  823037:	add    %rcx,%rsi
  82303a:	add    $0x11,%rsi
  82303e:	je     822fc8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  823040:	sub    %rcx,%rdi
  823043:	mov    $0x10,%edx
  823048:	call   *0x65de8a(%rip)        # e80ed8 <_DYNAMIC+0x248>
  82304e:	jmp    822fc1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  823053:	mov    $0x10,%edi
  823058:	jmp    822e12 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823210 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  823210:	mov    0x8(%rdi),%rsi
  823214:	test   %rsi,%rsi
  823217:	je     82323e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  823219:	mov    %rsi,%rax
  82321c:	shl    $0x5,%rax
  823220:	add    %rax,%rsi
  823223:	add    $0x31,%rsi
  823227:	je     82323e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  823229:	mov    (%rdi),%rdi
  82322c:	sub    %rax,%rdi
  82322f:	add    $0xffffffffffffffe0,%rdi
  823233:	mov    $0x10,%edx
  823238:	jmp    *0x65dc9a(%rip)        # e80ed8 <_DYNAMIC+0x248>
  82323e:	ret

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823240 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  823240:	push   %rbx
  823241:	test   %rdi,%rdi
  823244:	je     8232a7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  823246:	mov    %rdi,%rbx
  823249:	mov    (%rdi),%rsi
  82324c:	test   %rsi,%rsi
  82324f:	je     823264 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  823251:	mov    0x8(%rbx),%rdi
  823255:	shl    $0x3,%rsi
  823259:	mov    $0x8,%edx
  82325e:	call   *0x65dc74(%rip)        # e80ed8 <_DYNAMIC+0x248>
  823264:	mov    0x20(%rbx),%rsi
  823268:	test   %rsi,%rsi
  82326b:	je     823293 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82326d:	mov    %rsi,%rax
  823270:	shl    $0x4,%rax
  823274:	add    %rax,%rsi
  823277:	add    $0x21,%rsi
  82327b:	je     823293 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82327d:	mov    0x18(%rbx),%rdi
  823281:	sub    %rax,%rdi
  823284:	add    $0xfffffffffffffff0,%rdi
  823288:	mov    $0x10,%edx
  82328d:	call   *0x65dc45(%rip)        # e80ed8 <_DYNAMIC+0x248>
  823293:	mov    $0x80,%esi
  823298:	mov    $0x8,%edx
  82329d:	mov    %rbx,%rdi
  8232a0:	pop    %rbx
  8232a1:	jmp    *0x65dc31(%rip)        # e80ed8 <_DYNAMIC+0x248>
  8232a7:	pop    %rbx
  8232a8:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008234d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8234d0:	push   %r14
  8234d2:	push   %rbx
  8234d3:	push   %rax
  8234d4:	mov    %rdi,%rbx
  8234d7:	mov    (%rdi),%rax
  8234da:	lock decq (%rax)
  8234de:	jne    8234e9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  8234e0:	mov    %rbx,%rdi
  8234e3:	call   *0x65dcaf(%rip)        # e81198 <_DYNAMIC+0x508>
  8234e9:	mov    0x8(%rbx),%rax
  8234ed:	lock decq (%rax)
  8234f1:	jne    823507 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  8234f3:	add    $0x8,%rbx
  8234f7:	mov    %rbx,%rdi
  8234fa:	add    $0x8,%rsp
  8234fe:	pop    %rbx
  8234ff:	pop    %r14
  823501:	jmp    *0x65dc99(%rip)        # e811a0 <_DYNAMIC+0x510>
  823507:	add    $0x8,%rsp
  82350b:	pop    %rbx
  82350c:	pop    %r14
  82350e:	ret
  82350f:	mov    %rax,%r14
  823512:	mov    0x8(%rbx),%rax
  823516:	lock decq (%rax)
  82351a:	jne    823529 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  82351c:	add    $0x8,%rbx
  823520:	mov    %rbx,%rdi
  823523:	call   *0x65dc77(%rip)        # e811a0 <_DYNAMIC+0x510>
  823529:	mov    %r14,%rdi
  82352c:	call   e2d9a0 <_Unwind_Resume@plt>
  823531:	call   *0x65d9a9(%rip)        # e80ee0 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823600 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  823600:	push   %rbx
  823601:	mov    %rdi,%rbx
  823604:	mov    (%rdi),%rsi
  823607:	test   %rsi,%rsi
  82360a:	je     82361f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  82360c:	mov    0x8(%rbx),%rdi
  823610:	shl    $0x3,%rsi
  823614:	mov    $0x8,%edx
  823619:	call   *0x65d8b9(%rip)        # e80ed8 <_DYNAMIC+0x248>
  82361f:	mov    0x20(%rbx),%rsi
  823623:	test   %rsi,%rsi
  823626:	je     82364f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823628:	mov    %rsi,%rax
  82362b:	shl    $0x4,%rax
  82362f:	add    %rax,%rsi
  823632:	add    $0x21,%rsi
  823636:	je     82364f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823638:	mov    0x18(%rbx),%rdi
  82363c:	sub    %rax,%rdi
  82363f:	add    $0xfffffffffffffff0,%rdi
  823643:	mov    $0x10,%edx
  823648:	pop    %rbx
  823649:	jmp    *0x65d889(%rip)        # e80ed8 <_DYNAMIC+0x248>
  82364f:	pop    %rbx
  823650:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823660 <<gpui_gpu::renderer::images::Images>::metadata>:
  823660:	push   %r15
  823662:	push   %r14
  823664:	push   %rbx
  823665:	sub    $0x10,%rsp
  823669:	mov    %rsi,0x8(%rsp)
  82366e:	cmpq   $0x0,0x30(%rdi)
  823673:	je     82373d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  823679:	mov    %edx,%ebx
  82367b:	mov    %rsi,%r14
  82367e:	mov    %rdi,%r15
  823681:	add    $0x38,%rdi
  823685:	lea    0x8(%rsp),%rsi
  82368a:	call   8252b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82368f:	mov    %rax,%rsi
  823692:	shr    $0x39,%rsi
  823696:	mov    0x18(%r15),%rcx
  82369a:	mov    0x20(%r15),%rdx
  82369e:	movd   %esi,%xmm0
  8236a2:	punpcklbw %xmm0,%xmm0
  8236a6:	pshuflw $0x0,%xmm0,%xmm0
  8236ab:	pshufd $0x44,%xmm0,%xmm0
  8236b0:	xor    %esi,%esi
  8236b2:	pcmpeqd %xmm1,%xmm1
  8236b6:	and    %rdx,%rax
  8236b9:	movdqu (%rcx,%rax,1),%xmm2
  8236be:	movdqa %xmm2,%xmm3
  8236c2:	pcmpeqb %xmm0,%xmm3
  8236c6:	pmovmskb %xmm3,%edi
  8236ca:	test   %edi,%edi
  8236cc:	je     823700 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  8236ce:	tzcnt  %edi,%r9d
  8236d3:	add    %rax,%r9
  8236d6:	and    %rdx,%r9
  8236d9:	shl    $0x4,%r9
  8236dd:	mov    %rcx,%r8
  8236e0:	sub    %r9,%r8
  8236e3:	cmp    -0x10(%r8),%r14
  8236e7:	je     823719 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  8236e9:	lea    -0x1(%rdi),%r8d
  8236ed:	and    %di,%r8w
  8236f1:	mov    %r8d,%edi
  8236f4:	jne    8236ce <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  8236f6:	cs nopw 0x0(%rax,%rax,1)
  823700:	pcmpeqb %xmm1,%xmm2
  823704:	pmovmskb %xmm2,%edi
  823708:	test   %edi,%edi
  82370a:	jne    82373d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  82370c:	add    %rsi,%rax
  82370f:	add    $0x10,%rax
  823713:	add    $0x10,%rsi
  823717:	jmp    8236b6 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  823719:	mov    -0x8(%r8),%eax
  82371d:	movzbl %bl,%ecx
  823720:	or     -0x4(%r8),%ecx
  823724:	shl    $0x20,%rcx
  823728:	or     %rax,%rcx
  82372b:	mov    $0x80000000,%eax
  823730:	or     %rcx,%rax
  823733:	add    $0x10,%rsp
  823737:	pop    %rbx
  823738:	pop    %r14
  82373a:	pop    %r15
  82373c:	ret
  82373d:	lea    -0x74eac0(%rip),%rdi        # d4c84 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  823744:	lea    0x60c1ad(%rip),%rdx        # e2f8f8 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677>
  82374b:	mov    $0x16,%esi
  823750:	call   *0x65dada(%rip)        # e81230 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2722 frame=552

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823ac0 <gpui_gpu::renderer::images::prepare>:
  823ac0:	push   %rbp
  823ac1:	push   %r15
  823ac3:	push   %r14
  823ac5:	push   %r13
  823ac7:	push   %r12
  823ac9:	push   %rbx
  823aca:	sub    $0x1f8,%rsp
  823ad1:	mov    %r9,%r12
  823ad4:	mov    %rcx,%r13
  823ad7:	mov    %rdx,0xb8(%rsp)
  823adf:	mov    %rsi,0x8(%rsp)
  823ae4:	mov    %rdi,%r15
  823ae7:	mov    0x230(%rsp),%rax
  823aef:	mov    0x10(%rax),%r14
  823af3:	mov    0x118(%r14),%rax
  823afa:	add    $0x118,%r14
  823b01:	test   %rax,%rax
  823b04:	mov    %r14,%rcx
  823b07:	cmove  %rax,%rcx
  823b0b:	je     823ba6 <gpui_gpu::renderer::images::prepare+0xe6>
  823b11:	mov    0x10(%rax),%rax
  823b15:	mov    (%r8),%rbp
  823b18:	mov    %rax,0x18(%rsp)
  823b1d:	test   %rax,%rax
  823b20:	je     823ba9 <gpui_gpu::renderer::images::prepare+0xe9>
  823b26:	mov    %rcx,0xa8(%rsp)
  823b2e:	test   %rbp,%rbp
  823b31:	je     823cfb <gpui_gpu::renderer::images::prepare+0x23b>
  823b37:	cmp    0x48(%rbp),%r12
  823b3b:	ja     823cfb <gpui_gpu::renderer::images::prepare+0x23b>
  823b41:	mov    0x8(%rbp),%rdi
  823b45:	mov    0x10(%rbp),%rax
  823b49:	lea    (%rdi,%rax,8),%rsi
  823b4d:	movq   $0x1,0xe0(%rsp)
  823b59:	mov    %r14,0xe8(%rsp)
  823b61:	movq   $0x0,0xf0(%rsp)
  823b6d:	movq   $0x0,0x100(%rsp)
  823b79:	lea    0xe0(%rsp),%rdx
  823b81:	mov    %r8,%rbx
  823b84:	call   8246d0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  823b89:	mov    %rbx,%r8
  823b8c:	test   %al,%al
  823b8e:	je     823cfb <gpui_gpu::renderer::images::prepare+0x23b>
  823b94:	movq   $0x0,0x60(%rbp)
  823b9c:	movb   $0x0,0x4(%r15)
  823ba1:	jmp    823cdf <gpui_gpu::renderer::images::prepare+0x21f>
  823ba6:	mov    (%r8),%rbp
  823ba9:	movq   $0x0,(%r8)
  823bb0:	test   %rbp,%rbp
  823bb3:	je     823cd7 <gpui_gpu::renderer::images::prepare+0x217>
  823bb9:	mov    0x0(%rbp),%rsi
  823bbd:	test   %rsi,%rsi
  823bc0:	je     823bd5 <gpui_gpu::renderer::images::prepare+0x115>
  823bc2:	mov    0x8(%rbp),%rdi
  823bc6:	shl    $0x3,%rsi
  823bca:	mov    $0x8,%edx
  823bcf:	call   *0x65d303(%rip)        # e80ed8 <_DYNAMIC+0x248>
  823bd5:	mov    0x20(%rbp),%rsi
  823bd9:	test   %rsi,%rsi
  823bdc:	je     823c04 <gpui_gpu::renderer::images::prepare+0x144>
  823bde:	mov    %rsi,%rax
  823be1:	shl    $0x4,%rax
  823be5:	add    %rax,%rsi
  823be8:	add    $0x21,%rsi
  823bec:	je     823c04 <gpui_gpu::renderer::images::prepare+0x144>
  823bee:	mov    0x18(%rbp),%rdi
  823bf2:	sub    %rax,%rdi
  823bf5:	add    $0xfffffffffffffff0,%rdi
  823bf9:	mov    $0x10,%edx
  823bfe:	call   *0x65d2d4(%rip)        # e80ed8 <_DYNAMIC+0x248>
  823c04:	mov    $0x80,%esi
  823c09:	mov    $0x8,%edx
  823c0e:	mov    %rbp,%rdi
  823c11:	call   *0x65d2c1(%rip)        # e80ed8 <_DYNAMIC+0x248>
  823c17:	shl    $0x4,%r12
  823c1b:	cmp    $0x101,%r12
  823c22:	mov    $0x100,%eax
  823c27:	cmovae %r12,%rax
  823c2b:	dec    %rax
  823c2e:	bsr    %rax,%rcx
  823c32:	not    %ecx
  823c34:	mov    $0xffffffffffffffff,%rbx
  823c3b:	shr    %cl,%rbx
  823c3e:	inc    %rbx
  823c41:	lea    -0x74efae(%rip),%rax        # d4c9a <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x16>
  823c48:	mov    %rax,0x20(%rsp)
  823c4d:	movq   $0xa,0x28(%rsp)
  823c56:	mov    %rbx,0x30(%rsp)
  823c5b:	movl   $0x88,0x38(%rsp)
  823c63:	movb   $0x0,0x3c(%rsp)
  823c68:	lea    0xe0(%rsp),%rdi
  823c70:	lea    0x20(%rsp),%rdx
  823c75:	mov    0x8(%rsp),%rsi
  823c7a:	call   *0x65d630(%rip)        # e812b0 <_DYNAMIC+0x620>
  823c80:	mov    %rbx,0x100(%rsp)
  823c88:	mov    0x0(%r13),%rax
  823c8c:	lock decq (%rax)
  823c90:	jne    823c9b <gpui_gpu::renderer::images::prepare+0x1db>
  823c92:	mov    %r13,%rdi
  823c95:	call   *0x65d4fd(%rip)        # e81198 <_DYNAMIC+0x508>
  823c9b:	mov    0x8(%r13),%rax
  823c9f:	lock decq (%rax)
  823ca3:	jne    823caf <gpui_gpu::renderer::images::prepare+0x1ef>
  823ca5:	lea    0x8(%r13),%rdi
  823ca9:	call   *0x65d4f1(%rip)        # e811a0 <_DYNAMIC+0x510>
  823caf:	mov    0x100(%rsp),%rax
  823cb7:	mov    %rax,0x20(%r13)
  823cbb:	movdqu 0xe0(%rsp),%xmm0
  823cc4:	movups 0xf0(%rsp),%xmm1
  823ccc:	movups %xmm1,0x10(%r13)
  823cd1:	movdqu %xmm0,0x0(%r13)
  823cd7:	test   %rbp,%rbp
  823cda:	setne  0x4(%r15)
  823cdf:	movl   $0xffffffff,(%r15)
  823ce6:	mov    %r15,%rax
  823ce9:	add    $0x1f8,%rsp
  823cf0:	pop    %rbx
  823cf1:	pop    %r12
  823cf3:	pop    %r13
  823cf5:	pop    %r14
  823cf7:	pop    %r15
  823cf9:	pop    %rbp
  823cfa:	ret
  823cfb:	cmp    $0x1,%r12
  823cff:	mov    %r12,%rax
  823d02:	adc    $0xffffffffffffffff,%rax
  823d06:	bsr    %rax,%rcx
  823d0a:	not    %ecx
  823d0c:	mov    $0xffffffffffffffff,%rax
  823d13:	shr    %cl,%rax
  823d16:	cmp    $0x2,%r12
  823d1a:	mov    $0x0,%r12d
  823d20:	cmovae %rax,%r12
  823d24:	inc    %r12
  823d27:	je     824452 <gpui_gpu::renderer::images::prepare+0x992>
  823d2d:	mov    %r8,0xd0(%rsp)
  823d35:	mov    %fs:0x0,%rax
  823d3e:	lea    -0x28(%rax),%rax
  823d45:	mov    %rax,%rcx
  823d48:	cmpb   $0x1,0x10(%rax)
  823d4c:	mov    %r15,0xb0(%rsp)
  823d54:	mov    %r13,0xd8(%rsp)
  823d5c:	jne    82445e <gpui_gpu::renderer::images::prepare+0x99e>
  823d62:	mov    (%rcx),%rax
  823d65:	mov    0x8(%rcx),%rdx
  823d69:	mov    0x18(%rsp),%rbx
  823d6e:	lea    0x1(%rax),%rsi
  823d72:	mov    %rsi,(%rcx)
  823d75:	movq   $0x0,0x20(%rsp)
  823d7e:	movq   $0x8,0x28(%rsp)
  823d87:	movq   $0x0,0x30(%rsp)
  823d90:	movups 0x60bb79(%rip),%xmm0        # e2f910 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x18>
  823d97:	movups %xmm0,0x38(%rsp)
  823d9c:	movdqu 0x60bb7c(%rip),%xmm0        # e2f920 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x28>
  823da4:	movdqu %xmm0,0x48(%rsp)
  823daa:	mov    %rax,0x58(%rsp)
  823daf:	mov    %rdx,0x60(%rsp)
  823db4:	mov    %r12,0x68(%rsp)
  823db9:	pxor   %xmm0,%xmm0
  823dbd:	movdqu %xmm0,0x70(%rsp)
  823dc3:	movdqu %xmm0,0x80(%rsp)
  823dcc:	movdqu %xmm0,0x90(%rsp)
  823dd5:	lea    0xe0(%rsp),%rdi
  823ddd:	mov    $0x8,%edx
  823de2:	mov    $0x8,%r8d
  823de8:	mov    $0x8,%r9d
  823dee:	xor    %esi,%esi
  823df0:	mov    %rbx,%rcx
  823df3:	call   824d00 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823df8:	cmpl   $0x1,0xe0(%rsp)
  823e00:	jne    823e6d <gpui_gpu::renderer::images::prepare+0x3ad>
  823e02:	mov    0xb0(%rsp),%r15
  823e0a:	movl   $0x6,(%r15)
  823e11:	mov    0x20(%rsp),%rsi
  823e16:	test   %rsi,%rsi
  823e19:	je     823e2f <gpui_gpu::renderer::images::prepare+0x36f>
  823e1b:	mov    0x28(%rsp),%rdi
  823e20:	shl    $0x3,%rsi
  823e24:	mov    $0x8,%edx
  823e29:	call   *0x65d0a9(%rip)        # e80ed8 <_DYNAMIC+0x248>
  823e2f:	mov    0x40(%rsp),%rsi
  823e34:	test   %rsi,%rsi
  823e37:	je     823ce6 <gpui_gpu::renderer::images::prepare+0x226>
  823e3d:	mov    %rsi,%rax
  823e40:	shl    $0x4,%rax
  823e44:	add    %rax,%rsi
  823e47:	add    $0x21,%rsi
  823e4b:	je     823ce6 <gpui_gpu::renderer::images::prepare+0x226>
  823e51:	mov    0x38(%rsp),%rdi
  823e56:	sub    %rax,%rdi
  823e59:	add    $0xfffffffffffffff0,%rdi
  823e5d:	mov    $0x10,%edx
  823e62:	call   *0x65d070(%rip)        # e80ed8 <_DYNAMIC+0x248>
  823e68:	jmp    823ce6 <gpui_gpu::renderer::images::prepare+0x226>
  823e6d:	mov    %r12,0xa0(%rsp)
  823e75:	mov    %rbp,0xc8(%rsp)
  823e7d:	mov    0xe8(%rsp),%rax
  823e85:	mov    %rax,0x28(%rsp)
  823e8a:	mov    %rbx,0x20(%rsp)
  823e8f:	cmp    0x48(%rsp),%rbx
  823e94:	ja     82447a <gpui_gpu::renderer::images::prepare+0x9ba>
  823e9a:	xor    %r12d,%r12d
  823e9d:	mov    0xa0(%rsp),%r15
  823ea5:	jmp    823ec8 <gpui_gpu::renderer::images::prepare+0x408>
  823ea7:	nopw   0x0(%rax,%rax,1)
  823eb0:	add    $0x8,%r12
  823eb4:	mov    0x28(%rsp),%rax
  823eb9:	mov    %rbx,(%rax,%r15,8)
  823ebd:	inc    %r15
  823ec0:	mov    %r15,0x30(%rsp)
  823ec5:	mov    %r13,%r15
  823ec8:	test   %r12,%r12
  823ecb:	je     823ef0 <gpui_gpu::renderer::images::prepare+0x430>
  823ecd:	cmp    %rbp,%r12
  823ed0:	je     823ef0 <gpui_gpu::renderer::images::prepare+0x430>
  823ed2:	mov    (%r12),%rcx
  823ed6:	cmpb   $0x0,0x10(%rcx)
  823eda:	je     823f1e <gpui_gpu::renderer::images::prepare+0x45e>
  823edc:	mov    0x20(%rcx),%rax
  823ee0:	shl    $0x4,%rax
  823ee4:	mov    $0x8,%r8d
  823eea:	jmp    823f31 <gpui_gpu::renderer::images::prepare+0x471>
  823eec:	nopl   0x0(%rax)
  823ef0:	test   %r14,%r14
  823ef3:	je     823fb8 <gpui_gpu::renderer::images::prepare+0x4f8>
  823ef9:	mov    (%r14),%rax
  823efc:	mov    0x10(%rax),%rcx
  823f00:	test   %rcx,%rcx
  823f03:	je     823fb8 <gpui_gpu::renderer::images::prepare+0x4f8>
  823f09:	mov    0x8(%rax),%r12
  823f0d:	lea    (%r12,%rcx,8),%rbp
  823f11:	xor    %r14d,%r14d
  823f14:	mov    (%r12),%rcx
  823f18:	cmpb   $0x0,0x10(%rcx)
  823f1c:	jne    823edc <gpui_gpu::renderer::images::prepare+0x41c>
  823f1e:	movzbl 0x11(%rcx),%edx
  823f22:	movzbl 0x12(%rcx),%esi
  823f26:	mov    0x20(%rcx),%rax
  823f2a:	shl    $0x2,%edx
  823f2d:	lea    (%rdx,%rsi,2),%r8d
  823f31:	mov    0x78(%rsp),%rdx
  823f36:	add    %rax,%rdx
  823f39:	jb     823e02 <gpui_gpu::renderer::images::prepare+0x342>
  823f3f:	mov    0x28(%rcx),%rbx
  823f43:	mov    %rdx,0x78(%rsp)
  823f48:	cmp    $0x4000000,%rdx
  823f4f:	ja     823e02 <gpui_gpu::renderer::images::prepare+0x342>
  823f55:	mov    %r15,%rcx
  823f58:	shr    $0x20,%rcx
  823f5c:	jne    823e02 <gpui_gpu::renderer::images::prepare+0x342>
  823f62:	test   %r15d,%r15d
  823f65:	js     823e02 <gpui_gpu::renderer::images::prepare+0x342>
  823f6b:	mov    %rax,%r13
  823f6e:	shr    $0x4,%r13
  823f72:	and    $0xf,%eax
  823f75:	add    %r15,%r13
  823f78:	cmp    $0x1,%rax
  823f7c:	sbb    $0xffffffffffffffff,%r13
  823f80:	lea    0xe0(%rsp),%rdi
  823f88:	lea    0x38(%rsp),%rsi
  823f8d:	mov    %rbx,%rdx
  823f90:	mov    %r15d,%ecx
  823f93:	call   826f80 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  823f98:	mov    0x30(%rsp),%r15
  823f9d:	cmp    0x20(%rsp),%r15
  823fa2:	jne    823eb0 <gpui_gpu::renderer::images::prepare+0x3f0>
  823fa8:	lea    0x20(%rsp),%rdi
  823fad:	call   *0x65d3a5(%rip)        # e81358 <_DYNAMIC+0x6c8>
  823fb3:	jmp    823eb0 <gpui_gpu::renderer::images::prepare+0x3f0>
  823fb8:	movabs $0xffffffffffffff0,%rax
  823fc2:	cmp    %rax,%r15
  823fc5:	ja     823e02 <gpui_gpu::renderer::images::prepare+0x342>
  823fcb:	lea    0xe0(%rsp),%rdi
  823fd3:	mov    0x8(%rsp),%rsi
  823fd8:	call   *0x65d382(%rip)        # e81360 <_DYNAMIC+0x6d0>
  823fde:	mov    %r15,%rbx
  823fe1:	shl    $0x4,%rbx
  823fe5:	add    $0xff,%rbx
  823fec:	and    $0xffffffffffffff00,%rbx
  823ff3:	cmp    0x130(%rsp),%rbx
  823ffb:	ja     823e02 <gpui_gpu::renderer::images::prepare+0x342>
  824001:	lea    0xe0(%rsp),%rdi
  824009:	mov    0x8(%rsp),%rsi
  82400e:	call   *0x65d34c(%rip)        # e81360 <_DYNAMIC+0x6d0>
  824014:	cmp    0x140(%rsp),%rbx
  82401c:	ja     823e02 <gpui_gpu::renderer::images::prepare+0x342>
  824022:	mov    0xd8(%rsp),%r14
  82402a:	mov    0x20(%r14),%rax
  82402e:	cmp    %rbx,%rax
  824031:	jb     824062 <gpui_gpu::renderer::images::prepare+0x5a2>
  824033:	lea    0x0(,%rbx,4),%rcx
  82403b:	movabs $0x3fffffffffffff1,%rdx
  824045:	cmp    %rdx,%r15
  824048:	setb   %dl
  82404b:	cmp    %rcx,%rax
  82404e:	seta   %al
  824051:	test   %al,%dl
  824053:	jne    824062 <gpui_gpu::renderer::images::prepare+0x5a2>
  824055:	movl   $0x0,0x14(%rsp)
  82405d:	jmp    8240f5 <gpui_gpu::renderer::images::prepare+0x635>
  824062:	lea    -0x74f3c5(%rip),%rax        # d4ca4 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x20>
  824069:	mov    %rax,0x1d8(%rsp)
  824071:	movq   $0x1d,0x1e0(%rsp)
  82407d:	mov    %rbx,0x1e8(%rsp)
  824085:	movl   $0x88,0x1f0(%rsp)
  824090:	movb   $0x0,0x1f4(%rsp)
  824098:	lea    0xe0(%rsp),%rdi
  8240a0:	lea    0x1d8(%rsp),%rdx
  8240a8:	mov    0x8(%rsp),%rsi
  8240ad:	call   *0x65d1fd(%rip)        # e812b0 <_DYNAMIC+0x620>
  8240b3:	mov    %rbx,0x100(%rsp)
  8240bb:	mov    %r14,%r15
  8240be:	mov    %r14,%rdi
  8240c1:	call   8234d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8240c6:	mov    0x100(%rsp),%rax
  8240ce:	mov    %rax,0x20(%r15)
  8240d2:	movdqu 0xe0(%rsp),%xmm0
  8240db:	movdqu 0xf0(%rsp),%xmm1
  8240e4:	movdqu %xmm1,0x10(%r15)
  8240ea:	movdqu %xmm0,(%r15)
  8240ef:	mov    $0x1,%al
  8240f1:	mov    %eax,0x14(%rsp)
  8240f5:	movq   $0x0,0x8(%rsp)
  8240fe:	mov    0x8(%rsp),%rdx
  824103:	test   %rdx,%rdx
  824106:	je     824112 <gpui_gpu::renderer::images::prepare+0x652>
  824108:	cmp    0xc0(%rsp),%rdx
  824110:	jne    82414f <gpui_gpu::renderer::images::prepare+0x68f>
  824112:	mov    0xa8(%rsp),%rax
  82411a:	test   %rax,%rax
  82411d:	je     8242e5 <gpui_gpu::renderer::images::prepare+0x825>
  824123:	mov    (%rax),%rax
  824126:	mov    0x10(%rax),%rcx
  82412a:	test   %rcx,%rcx
  82412d:	je     8242e5 <gpui_gpu::renderer::images::prepare+0x825>
  824133:	mov    0x8(%rax),%rdx
  824137:	lea    (%rdx,%rcx,8),%rax
  82413b:	mov    %rax,0xc0(%rsp)
  824143:	movq   $0x0,0xa8(%rsp)
  82414f:	mov    (%rdx),%rax
  824152:	mov    0x28(%rax),%r12
  824156:	movzbl 0x10(%rax),%ebx
  82415a:	mov    0x18(%rax),%rbp
  82415e:	mov    0x20(%rax),%r13
  824162:	mov    %r12,0xe0(%rsp)
  82416a:	cmpq   $0x0,0x50(%rsp)
  824170:	je     8242ca <gpui_gpu::renderer::images::prepare+0x80a>
  824176:	add    $0x8,%rdx
  82417a:	mov    %rdx,0x8(%rsp)
  82417f:	lea    0x58(%rsp),%rdi
  824184:	lea    0xe0(%rsp),%rsi
  82418c:	call   8252b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  824191:	mov    %rax,%rsi
  824194:	shr    $0x39,%rsi
  824198:	mov    0x38(%rsp),%rcx
  82419d:	mov    0x40(%rsp),%rdx
  8241a2:	movd   %esi,%xmm0
  8241a6:	punpcklbw %xmm0,%xmm0
  8241aa:	pshuflw $0x0,%xmm0,%xmm0
  8241af:	pshufd $0x44,%xmm0,%xmm0
  8241b4:	xor    %esi,%esi
  8241b6:	and    %rdx,%rax
  8241b9:	movdqu (%rcx,%rax,1),%xmm1
  8241be:	movdqa %xmm1,%xmm2
  8241c2:	pcmpeqb %xmm0,%xmm2
  8241c6:	pmovmskb %xmm2,%edi
  8241ca:	test   %edi,%edi
  8241cc:	je     8241f6 <gpui_gpu::renderer::images::prepare+0x736>
  8241ce:	tzcnt  %edi,%r9d
  8241d3:	add    %rax,%r9
  8241d6:	and    %rdx,%r9
  8241d9:	shl    $0x4,%r9
  8241dd:	mov    %rcx,%r8
  8241e0:	sub    %r9,%r8
  8241e3:	cmp    -0x10(%r8),%r12
  8241e7:	je     824217 <gpui_gpu::renderer::images::prepare+0x757>
  8241e9:	lea    -0x1(%rdi),%r8d
  8241ed:	and    %di,%r8w
  8241f1:	mov    %r8d,%edi
  8241f4:	jne    8241ce <gpui_gpu::renderer::images::prepare+0x70e>
  8241f6:	pcmpeqd %xmm2,%xmm2
  8241fa:	pcmpeqb %xmm2,%xmm1
  8241fe:	pmovmskb %xmm1,%edi
  824202:	test   %edi,%edi
  824204:	jne    8242ca <gpui_gpu::renderer::images::prepare+0x80a>
  82420a:	add    %rsi,%rax
  82420d:	add    $0x10,%rax
  824211:	add    $0x10,%rsi
  824215:	jmp    8241b6 <gpui_gpu::renderer::images::prepare+0x6f6>
  824217:	mov    -0x8(%r8),%r12d
  82421b:	shl    $0x4,%r12
  82421f:	test   %bl,%bl
  824221:	je     824278 <gpui_gpu::renderer::images::prepare+0x7b8>
  824223:	test   %r13,%r13
  824226:	je     8240fe <gpui_gpu::renderer::images::prepare+0x63e>
  82422c:	nopl   0x0(%rax)
  824230:	cmp    $0x1000,%r13
  824237:	mov    $0x1000,%r15d
  82423d:	cmovb  %r13,%r15
  824241:	mov    %r15d,%ebx
  824244:	shl    $0x4,%ebx
  824247:	mov    0xb8(%rsp),%rdi
  82424f:	mov    %r14,%rsi
  824252:	mov    %r12,%rdx
  824255:	mov    %rbp,%rcx
  824258:	mov    %rbx,%r8
  82425b:	call   *0x65cfff(%rip)        # e81260 <_DYNAMIC+0x5d0>
  824261:	mov    %r15,%rax
  824264:	shl    $0x4,%rax
  824268:	add    %rax,%rbp
  82426b:	add    %rbx,%r12
  82426e:	sub    %r15,%r13
  824271:	jne    824230 <gpui_gpu::renderer::images::prepare+0x770>
  824273:	jmp    8240fe <gpui_gpu::renderer::images::prepare+0x63e>
  824278:	test   %r13,%r13
  82427b:	je     8240fe <gpui_gpu::renderer::images::prepare+0x63e>
  824281:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824290:	cmp    $0x10000,%r13
  824297:	mov    $0x10000,%ebx
  82429c:	cmovb  %r13,%rbx
  8242a0:	mov    0xb8(%rsp),%rdi
  8242a8:	mov    %r14,%rsi
  8242ab:	mov    %r12,%rdx
  8242ae:	mov    %rbp,%rcx
  8242b1:	mov    %rbx,%r8
  8242b4:	call   *0x65cfa6(%rip)        # e81260 <_DYNAMIC+0x5d0>
  8242ba:	add    %rbx,%rbp
  8242bd:	add    %rbx,%r12
  8242c0:	sub    %rbx,%r13
  8242c3:	jne    824290 <gpui_gpu::renderer::images::prepare+0x7d0>
  8242c5:	jmp    8240fe <gpui_gpu::renderer::images::prepare+0x63e>
  8242ca:	lea    -0x74f64d(%rip),%rdi        # d4c84 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  8242d1:	lea    0x60b658(%rip),%rdx        # e2f930 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x38>
  8242d8:	mov    $0x16,%esi
  8242dd:	call   *0x65cf4d(%rip)        # e81230 <_DYNAMIC+0x5a0>
  8242e3:	ud2
  8242e5:	mov    0x18(%rsp),%rax
  8242ea:	mov    %rax,0x70(%rsp)
  8242ef:	mov    0x78(%rsp),%rax
  8242f4:	mov    %rax,0x80(%rsp)
  8242fc:	mov    0xa0(%rsp),%rax
  824304:	shl    $0x4,%rax
  824308:	mov    %rax,0x88(%rsp)
  824310:	mov    0x20(%r14),%rax
  824314:	mov    %rax,0x90(%rsp)
  82431c:	mov    0x48(%rsp),%rax
  824321:	add    0x50(%rsp),%rax
  824326:	mov    %rax,0x98(%rsp)
  82432e:	mov    0x90(%rsp),%rax
  824336:	mov    %rax,0x150(%rsp)
  82433e:	mov    0x98(%rsp),%rax
  824346:	mov    %rax,0x158(%rsp)
  82434e:	mov    0x80(%rsp),%rax
  824356:	mov    %rax,0x140(%rsp)
  82435e:	mov    0x88(%rsp),%rax
  824366:	mov    %rax,0x148(%rsp)
  82436e:	movups 0x70(%rsp),%xmm0
  824373:	movaps %xmm0,0x130(%rsp)
  82437b:	movups 0x60(%rsp),%xmm0
  824380:	movaps %xmm0,0x120(%rsp)
  824388:	movups 0x50(%rsp),%xmm0
  82438d:	movaps %xmm0,0x110(%rsp)
  824395:	movups 0x20(%rsp),%xmm0
  82439a:	movups 0x30(%rsp),%xmm1
  82439f:	movups 0x40(%rsp),%xmm2
  8243a4:	movaps %xmm2,0x100(%rsp)
  8243ac:	movaps %xmm1,0xf0(%rsp)
  8243b4:	movaps %xmm0,0xe0(%rsp)
  8243bc:	call   823a90 <alloc::boxed::box_new_uninit>
  8243c1:	mov    %rax,%rbx
  8243c4:	movaps 0x150(%rsp),%xmm0
  8243cc:	movups %xmm0,0x70(%rax)
  8243d0:	movaps 0x140(%rsp),%xmm0
  8243d8:	movups %xmm0,0x60(%rax)
  8243dc:	movaps 0x130(%rsp),%xmm0
  8243e4:	movups %xmm0,0x50(%rax)
  8243e8:	movaps 0x120(%rsp),%xmm0
  8243f0:	movups %xmm0,0x40(%rax)
  8243f4:	movdqa 0xe0(%rsp),%xmm0
  8243fd:	movaps 0xf0(%rsp),%xmm1
  824405:	movaps 0x100(%rsp),%xmm2
  82440d:	movaps 0x110(%rsp),%xmm3
  824415:	movups %xmm3,0x30(%rax)
  824419:	movups %xmm2,0x20(%rax)
  82441d:	movups %xmm1,0x10(%rax)
  824421:	movdqu %xmm0,(%rax)
  824425:	mov    0xc8(%rsp),%rdi
  82442d:	call   823240 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  824432:	mov    0xd0(%rsp),%rax
  82443a:	mov    %rbx,(%rax)
  82443d:	mov    0xb0(%rsp),%r15
  824445:	mov    0x14(%rsp),%eax
  824449:	mov    %al,0x4(%r15)
  82444d:	jmp    823cdf <gpui_gpu::renderer::images::prepare+0x21f>
  824452:	movl   $0x6,(%r15)
  824459:	jmp    823ce6 <gpui_gpu::renderer::images::prepare+0x226>
  82445e:	mov    %rcx,%rbx
  824461:	call   *0x65ce51(%rip)        # e812b8 <_DYNAMIC+0x628>
  824467:	mov    %rbx,%rcx
  82446a:	mov    %rax,(%rbx)
  82446d:	mov    %rdx,0x8(%rbx)
  824471:	movb   $0x1,0x10(%rbx)
  824475:	jmp    823d69 <gpui_gpu::renderer::images::prepare+0x2a9>
  82447a:	lea    0x38(%rsp),%rdi
  82447f:	mov    0x18(%rsp),%rsi
  824484:	lea    0x58(%rsp),%rdx
  824489:	xor    %ecx,%ecx
  82448b:	call   *0x65ce9f(%rip)        # e81330 <_DYNAMIC+0x6a0>
  824491:	cmp    $0xffffffffffffffff,%rax
  824495:	jne    823e02 <gpui_gpu::renderer::images::prepare+0x342>
  82449b:	jmp    823e9a <gpui_gpu::renderer::images::prepare+0x3da>
  8244a0:	mov    %rax,%rbx
  8244a3:	lea    0xe0(%rsp),%rdi
  8244ab:	call   823600 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8244b0:	mov    %rbx,%rdi
  8244b3:	call   e2d9a0 <_Unwind_Resume@plt>
  8244b8:	mov    %rax,%rbx
  8244bb:	mov    0x100(%rsp),%rax
  8244c3:	mov    %rax,0x20(%r15)
  8244c7:	movups 0xe0(%rsp),%xmm0
  8244cf:	movups 0xf0(%rsp),%xmm1
  8244d7:	movups %xmm1,0x10(%r15)
  8244dc:	movups %xmm0,(%r15)
  8244e0:	lea    0x20(%rsp),%rdi
  8244e5:	call   823600 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8244ea:	mov    %rbx,%rdi
  8244ed:	call   e2d9a0 <_Unwind_Resume@plt>
  8244f2:	mov    %r13,%r14
  8244f5:	mov    %rax,%rbx
  8244f8:	jmp    824514 <gpui_gpu::renderer::images::prepare+0xa54>
  8244fa:	mov    %rax,%rbx
  8244fd:	mov    %r13,%r14
  824500:	mov    0x8(%r13),%rax
  824504:	lock decq (%rax)
  824508:	jne    824514 <gpui_gpu::renderer::images::prepare+0xa54>
  82450a:	lea    0x8(%r14),%rdi
  82450e:	call   *0x65cc8c(%rip)        # e811a0 <_DYNAMIC+0x510>
  824514:	mov    0x100(%rsp),%rax
  82451c:	mov    %rax,0x20(%r14)
  824520:	movups 0xe0(%rsp),%xmm0
  824528:	movups 0xf0(%rsp),%xmm1
  824530:	movups %xmm1,0x10(%r14)
  824535:	movups %xmm0,(%r14)
  824539:	mov    %rbx,%rdi
  82453c:	call   e2d9a0 <_Unwind_Resume@plt>
  824541:	call   *0x65c999(%rip)        # e80ee0 <_DYNAMIC+0x250>
  824547:	jmp    82454d <gpui_gpu::renderer::images::prepare+0xa8d>
  824549:	jmp    82454d <gpui_gpu::renderer::images::prepare+0xa8d>
  82454b:	jmp    82454d <gpui_gpu::renderer::images::prepare+0xa8d>
  82454d:	mov    %rax,%rbx
  824550:	lea    0x20(%rsp),%rdi
  824555:	call   823600 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  82455a:	mov    %rbx,%rdi
  82455d:	call   e2d9a0 <_Unwind_Resume@plt>

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008246d0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  8246d0:	push   %r15
  8246d2:	push   %r14
  8246d4:	push   %rbx
  8246d5:	mov    (%rdx),%r9
  8246d8:	mov    0x8(%rdx),%r11
  8246dc:	mov    0x10(%rdx),%rbx
  8246e0:	mov    0x18(%rdx),%r10
  8246e4:	mov    0x20(%rdx),%r8
  8246e8:	mov    0x28(%rdx),%rcx
  8246ec:	test   $0x1,%r9b
  8246f0:	jne    82478a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  8246f6:	mov    %rbx,%rax
  8246f9:	jmp    82471b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  8246fb:	nopl   0x0(%rax,%rax,1)
  824700:	lea    0x8(%rax),%rbx
  824704:	mov    %rbx,%r14
  824707:	add    $0x8,%rdi
  82470b:	mov    (%rax),%r15
  82470e:	mov    %r14,%rax
  824711:	cmp    0x28(%r15),%rdx
  824715:	jne    8247df <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82471b:	cmp    %rsi,%rdi
  82471e:	je     8247b8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  824724:	mov    (%rdi),%rdx
  824727:	test   %rax,%rax
  82472a:	je     824733 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  82472c:	cmp    %r10,%rax
  82472f:	jne    824700 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  824731:	xor    %ebx,%ebx
  824733:	xor    %eax,%eax
  824735:	test   %r8,%r8
  824738:	je     8247e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82473e:	cmp    %rcx,%r8
  824741:	je     8247e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  824747:	mov    %r8,%rax
  82474a:	add    $0x8,%r8
  82474e:	xor    %r14d,%r14d
  824751:	jmp    824707 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  824753:	mov    (%r11),%rax
  824756:	mov    0x8(%rax),%rbx
  82475a:	mov    0x10(%rax),%rax
  82475e:	lea    (%rbx,%rax,8),%r10
  824762:	test   %rax,%rax
  824765:	je     8247a1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  824767:	xor    %r11d,%r11d
  82476a:	nopw   0x0(%rax,%rax,1)
  824770:	mov    %r8,%rax
  824773:	mov    %rbx,%r8
  824776:	add    $0x8,%rbx
  82477a:	add    $0x8,%rdi
  82477e:	mov    (%r8),%r14
  824781:	mov    %rax,%r8
  824784:	cmp    0x28(%r14),%rdx
  824788:	jne    8247df <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82478a:	cmp    %rsi,%rdi
  82478d:	je     8247b8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  82478f:	mov    (%rdi),%rdx
  824792:	test   %rbx,%rbx
  824795:	je     82479c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  824797:	cmp    %r10,%rbx
  82479a:	jne    824770 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  82479c:	test   %r11,%r11
  82479f:	jne    824753 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  8247a1:	xor    %eax,%eax
  8247a3:	test   %r8,%r8
  8247a6:	je     8247e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8247a8:	cmp    %rcx,%r8
  8247ab:	je     8247e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8247ad:	lea    0x8(%r8),%rax
  8247b1:	xor    %ebx,%ebx
  8247b3:	xor    %r11d,%r11d
  8247b6:	jmp    82477a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  8247b8:	test   %rbx,%rbx
  8247bb:	sete   %dl
  8247be:	cmp    %r10,%rbx
  8247c1:	sete   %al
  8247c4:	or     %dl,%al
  8247c6:	test   $0x1,%r9b
  8247ca:	je     8247e7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  8247cc:	test   %al,%al
  8247ce:	je     8247df <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8247d0:	test   %r11,%r11
  8247d3:	je     8247eb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8247d5:	mov    (%r11),%rax
  8247d8:	cmpq   $0x0,0x10(%rax)
  8247dd:	je     8247eb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  8247df:	xor    %eax,%eax
  8247e1:	pop    %rbx
  8247e2:	pop    %r14
  8247e4:	pop    %r15
  8247e6:	ret
  8247e7:	test   %al,%al
  8247e9:	je     8247df <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8247eb:	test   %r8,%r8
  8247ee:	sete   %dl
  8247f1:	cmp    %rcx,%r8
  8247f4:	sete   %al
  8247f7:	or     %dl,%al
  8247f9:	pop    %rbx
  8247fa:	pop    %r14
  8247fc:	pop    %r15
  8247fe:	ret

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824800 <gpui_gpu::renderer::slots::color_word>:
  824800:	lea    -0x3(%rsi),%eax
  824803:	cmp    %rax,%rdi
  824806:	jbe    82481f <gpui_gpu::renderer::slots::color_word+0x1f>
  824808:	mov    %rdi,%rax
  82480b:	shr    $0x6,%rax
  82480f:	and    $0x3f,%edi
  824812:	cmp    $0x1,%rdi
  824816:	sbb    $0xffffffff,%eax
  824819:	add    %esi,%eax
  82481b:	add    $0xfffffffe,%eax
  82481e:	ret
  82481f:	push   %rax
  824820:	lea    -0x74fb66(%rip),%rdi        # d4cc1 <anon.627181f3f10afc1966f799818b5539e5.19.llvm.1634448222410874261>
  824827:	lea    0x60b11a(%rip),%rdx        # e2f948 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261>
  82482e:	mov    $0x1e,%esi
  824833:	call   *0x65c9bf(%rip)        # e811f8 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=694 frame=120

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824840 <gpui_gpu::renderer::slots::write_prefix>:
  824840:	push   %rbp
  824841:	push   %r15
  824843:	push   %r14
  824845:	push   %r13
  824847:	push   %r12
  824849:	push   %rbx
  82484a:	sub    $0x48,%rsp
  82484e:	mov    %rsi,0x8(%rsp)
  824853:	test   %rcx,%rcx
  824856:	je     824a9a <gpui_gpu::renderer::slots::write_prefix+0x25a>
  82485c:	mov    %rdi,0x18(%rsp)
  824861:	xor    %r12d,%r12d
  824864:	test   $0x3f,%cl
  824867:	setne  %al
  82486a:	cmpq   $0x0,0x8(%rsp)
  824870:	je     824ae0 <gpui_gpu::renderer::slots::write_prefix+0x2a0>
  824876:	mov    %r8,%r14
  824879:	mov    %rcx,%r10
  82487c:	shr    $0x6,%r10
  824880:	mov    %al,%r12b
  824883:	lea    (%r10,%r12,1),%r9
  824887:	lea    (%r10,%r12,1),%rax
  82488b:	inc    %rax
  82488e:	mov    %eax,%esi
  824890:	mov    %r9,%rdi
  824893:	shl    $0x20,%rdi
  824897:	mov    %ecx,%r8d
  82489a:	mov    0x18(%rsp),%rbx
  82489f:	xor    0x8(%rbx),%rsi
  8248a3:	or     %rdi,%r8
  8248a6:	xor    (%rbx),%r8
  8248a9:	or     %rsi,%r8
  8248ac:	mov    %r10,0x10(%rsp)
  8248b1:	jne    8248bc <gpui_gpu::renderer::slots::write_prefix+0x7c>
  8248b3:	mov    (%r14),%rbp
  8248b6:	mov    0x8(%r14),%r13
  8248ba:	jmp    8248e5 <gpui_gpu::renderer::slots::write_prefix+0xa5>
  8248bc:	mov    0x8(%r14),%r13
  8248c0:	movq   $0x0,(%r14)
  8248c7:	cmp    $0x1,%r13
  8248cb:	adc    $0x0,%r13
  8248cf:	mov    %r13,0x8(%r14)
  8248d3:	mov    %ecx,(%rbx)
  8248d5:	mov    %r9d,0x4(%rbx)
  8248d9:	mov    %eax,0x8(%rbx)
  8248dc:	movl   $0x0,0xc(%rbx)
  8248e3:	xor    %ebp,%ebp
  8248e5:	mov    %r9,%r15
  8248e8:	mov    %rdx,%rdi
  8248eb:	call   *0x65c947(%rip)        # e81238 <_DYNAMIC+0x5a8>
  8248f1:	mov    0x8(%rsp),%rcx
  8248f6:	dec    %rcx
  8248f9:	mov    %rcx,0x40(%rsp)
  8248fe:	mov    0x10(%rsp),%rcx
  824903:	shl    $0x4,%rcx
  824907:	shl    $0x4,%r12d
  82490b:	add    %rcx,%r12
  82490e:	lea    (%rbx,%r12,1),%r9
  824912:	add    $0x10,%r9
  824916:	xor    %r12d,%r12d
  824919:	xorps  %xmm0,%xmm0
  82491c:	mov    %r15,0x38(%rsp)
  824921:	mov    %r15,%r10
  824924:	jmp    824946 <gpui_gpu::renderer::slots::write_prefix+0x106>
  824926:	cs nopw 0x0(%rax,%rax,1)
  824930:	add    $0x40,%r10
  824934:	add    $0x400,%r9
  82493b:	cmp    0x38(%rsp),%r12
  824940:	je     824a9a <gpui_gpu::renderer::slots::write_prefix+0x25a>
  824946:	mov    %r12,0x10(%rsp)
  82494b:	lea    0x1(%r12),%rcx
  824950:	mov    %rcx,0x30(%rsp)
  824955:	movaps %xmm0,0x20(%rsp)
  82495a:	mov    $0xffffffffffffffc0,%rsi
  824961:	xor    %r12d,%r12d
  824964:	jmp    824981 <gpui_gpu::renderer::slots::write_prefix+0x141>
  824966:	cs nopw 0x0(%rax,%rax,1)
  824970:	add    $0x18,%rax
  824974:	add    $0x2,%r12
  824978:	inc    %rsi
  82497b:	je     824a30 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  824981:	cmp    %rdx,%rax
  824984:	je     824a30 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  82498a:	lea    0x40(%rsi),%r8
  82498e:	movzwl 0x10(%rax),%ebx
  824992:	movzwl 0x12(%rax),%ecx
  824996:	mov    (%rax),%r11d
  824999:	mov    0x4(%rax),%edi
  82499c:	mov    0x8(%rax),%r15
  8249a0:	shr    $0xe,%ecx
  8249a3:	and    $0x2,%ecx
  8249a6:	shr    $0xf,%ebx
  8249a9:	or     %ecx,%ebx
  8249ab:	mov    %r12d,%ecx
  8249ae:	and    $0x1e,%cl
  8249b1:	shl    %cl,%ebx
  8249b3:	shr    $0x4,%r8
  8249b7:	or     %ebx,0x20(%rsp,%r8,4)
  8249bc:	lea    (%r10,%rsi,1),%r8
  8249c0:	add    $0x41,%r8
  8249c4:	cmp    0x8(%rsp),%r8
  8249c9:	jae    824aa9 <gpui_gpu::renderer::slots::write_prefix+0x269>
  8249cf:	mov    %rdi,%rcx
  8249d2:	shl    $0x20,%rcx
  8249d6:	mov    %r11d,%ebx
  8249d9:	or     %rcx,%rbx
  8249dc:	mov    0x8(%r9,%r12,8),%rcx
  8249e1:	xor    %r15,%rcx
  8249e4:	xor    (%r9,%r12,8),%rbx
  8249e8:	or     %rcx,%rbx
  8249eb:	je     824970 <gpui_gpu::renderer::slots::write_prefix+0x130>
  8249ed:	mov    %r15d,%ecx
  8249f0:	shr    $0x20,%r15
  8249f4:	cmp    %rbp,%r8
  8249f7:	cmovb  %r8,%rbp
  8249fb:	mov    %rbp,(%r14)
  8249fe:	lea    (%r10,%rsi,1),%r8
  824a02:	add    $0x42,%r8
  824a06:	cmp    %r13,%r8
  824a09:	cmova  %r8,%r13
  824a0d:	mov    %r13,0x8(%r14)
  824a11:	mov    %r11d,(%r9,%r12,8)
  824a15:	mov    %edi,0x4(%r9,%r12,8)
  824a1a:	mov    %ecx,0x8(%r9,%r12,8)
  824a1f:	mov    %r15d,0xc(%r9,%r12,8)
  824a24:	jmp    824970 <gpui_gpu::renderer::slots::write_prefix+0x130>
  824a29:	nopl   0x0(%rax)
  824a30:	mov    0x10(%rsp),%r15
  824a35:	cmp    0x40(%rsp),%r15
  824a3a:	je     824ac5 <gpui_gpu::renderer::slots::write_prefix+0x285>
  824a40:	mov    0x20(%rsp),%rcx
  824a45:	mov    0x28(%rsp),%rsi
  824a4a:	lea    0x1(%r15),%r12
  824a4e:	mov    %r12,%rdi
  824a51:	shl    $0x4,%rdi
  824a55:	mov    0x18(%rsp),%rbx
  824a5a:	mov    0x8(%rbx,%rdi,1),%r8
  824a5f:	xor    %rsi,%r8
  824a62:	mov    (%rbx,%rdi,1),%r11
  824a66:	xor    %rcx,%r11
  824a69:	or     %r8,%r11
  824a6c:	je     824930 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  824a72:	add    %rbx,%rdi
  824a75:	cmp    %rbp,%r12
  824a78:	cmovb  %r12,%rbp
  824a7c:	add    $0x2,%r15
  824a80:	cmp    %r13,%r15
  824a83:	cmova  %r15,%r13
  824a87:	mov    %rbp,(%r14)
  824a8a:	mov    %r13,0x8(%r14)
  824a8e:	mov    %rsi,0x8(%rdi)
  824a92:	mov    %rcx,(%rdi)
  824a95:	jmp    824930 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  824a9a:	add    $0x48,%rsp
  824a9e:	pop    %rbx
  824a9f:	pop    %r12
  824aa1:	pop    %r13
  824aa3:	pop    %r14
  824aa5:	pop    %r15
  824aa7:	pop    %rbp
  824aa8:	ret
  824aa9:	add    %r10,%rsi
  824aac:	add    $0x42,%rsi
  824ab0:	lea    0x60ac01(%rip),%rcx        # e2f6b8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318>
  824ab7:	mov    %r8,%rdi
  824aba:	mov    0x8(%rsp),%rdx
  824abf:	call   *0x65c713(%rip)        # e811d8 <_DYNAMIC+0x548>
  824ac5:	mov    0x8(%rsp),%rdx
  824aca:	lea    0x1(%rdx),%rsi
  824ace:	lea    0x60abe3(%rip),%rcx        # e2f6b8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318>
  824ad5:	mov    0x30(%rsp),%rdi
  824ada:	call   *0x65c6f8(%rip)        # e811d8 <_DYNAMIC+0x548>
  824ae0:	lea    0x60abd1(%rip),%rcx        # e2f6b8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318>
  824ae7:	mov    $0x1,%esi
  824aec:	xor    %edi,%edi
  824aee:	xor    %edx,%edx
  824af0:	call   *0x65c6e2(%rip)        # e811d8 <_DYNAMIC+0x548>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824c90 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  824c90:	push   %r14
  824c92:	push   %rbx
  824c93:	sub    $0x18,%rsp
  824c97:	mov    %rdi,%rbx
  824c9a:	mov    (%rdi),%rsi
  824c9d:	lea    (%rsi,%rsi,1),%rax
  824ca1:	cmp    $0x5,%rax
  824ca5:	mov    $0x4,%r14d
  824cab:	cmovae %rax,%r14
  824caf:	mov    0x8(%rdi),%rdx
  824cb3:	mov    %rsp,%rdi
  824cb6:	mov    $0x4,%r8d
  824cbc:	mov    $0x20,%r9d
  824cc2:	mov    %r14,%rcx
  824cc5:	call   824d00 <<alloc::raw_vec::RawVecInner>::finish_grow>
  824cca:	cmpl   $0x1,(%rsp)
  824cce:	je     824ce4 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  824cd0:	mov    0x8(%rsp),%rax
  824cd5:	mov    %rax,0x8(%rbx)
  824cd9:	mov    %r14,(%rbx)
  824cdc:	add    $0x18,%rsp
  824ce0:	pop    %rbx
  824ce1:	pop    %r14
  824ce3:	ret
  824ce4:	mov    0x8(%rsp),%rdi
  824ce9:	mov    0x10(%rsp),%rsi
  824cee:	call   *0x65c224(%rip)        # e80f18 <_DYNAMIC+0x288>

FUNCTION <gpui_gpu::renderer::coverage::Interval>::add bytes=366 frame=0

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825410 <<gpui_gpu::renderer::coverage::Interval>::add>:
  825410:	xorpd  %xmm4,%xmm4
  825414:	ucomisd %xmm4,%xmm2
  825418:	jne    825424 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  82541a:	jp     825424 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  82541c:	ucomisd %xmm4,%xmm3
  825420:	jne    825424 <<gpui_gpu::renderer::coverage::Interval>::add+0x14>
  825422:	jnp    82543c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  825424:	ucomisd %xmm4,%xmm0
  825428:	jne    82544f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  82542a:	jp     82544f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  82542c:	ucomisd %xmm4,%xmm1
  825430:	jne    82544f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  825432:	jp     82544f <<gpui_gpu::renderer::coverage::Interval>::add+0x3f>
  825434:	movapd %xmm2,%xmm0
  825438:	movapd %xmm3,%xmm1
  82543c:	movsd  %xmm0,0x8(%rdi)
  825441:	movsd  %xmm1,0x10(%rdi)
  825446:	mov    $0x1,%ecx
  82544b:	mov    %rcx,(%rdi)
  82544e:	ret
  82544f:	addsd  %xmm2,%xmm0
  825453:	addsd  %xmm3,%xmm1
  825457:	movq   %xmm0,%rdx
  82545c:	movq   %xmm1,%rcx
  825461:	ucomisd %xmm0,%xmm0
  825465:	setp   %al
  825468:	movabs $0xfff0000000000000,%rsi
  825472:	cmp    %rsi,%rdx
  825475:	sete   %sil
  825479:	or     %al,%sil
  82547c:	movabs $0x7fffffffffffffff,%rax
  825486:	jne    8254ae <<gpui_gpu::renderer::coverage::Interval>::add+0x9e>
  825488:	mov    %rdx,%rsi
  82548b:	and    %rax,%rsi
  82548e:	je     82549a <<gpui_gpu::renderer::coverage::Interval>::add+0x8a>
  825490:	cmp    %rsi,%rdx
  825493:	jne    8254a6 <<gpui_gpu::renderer::coverage::Interval>::add+0x96>
  825495:	dec    %rdx
  825498:	jmp    8254a9 <<gpui_gpu::renderer::coverage::Interval>::add+0x99>
  82549a:	movabs $0x8000000000000001,%rdx
  8254a4:	jmp    8254a9 <<gpui_gpu::renderer::coverage::Interval>::add+0x99>
  8254a6:	inc    %rdx
  8254a9:	movq   %rdx,%xmm0
  8254ae:	ucomisd %xmm1,%xmm1
  8254b2:	setp   %dl
  8254b5:	movabs $0x7ff0000000000000,%rsi
  8254bf:	cmp    %rsi,%rcx
  8254c2:	sete   %sil
  8254c6:	or     %dl,%sil
  8254c9:	jne    8254ec <<gpui_gpu::renderer::coverage::Interval>::add+0xdc>
  8254cb:	mov    %rcx,%rdx
  8254ce:	and    %rax,%rdx
  8254d1:	je     8254dd <<gpui_gpu::renderer::coverage::Interval>::add+0xcd>
  8254d3:	cmp    %rdx,%rcx
  8254d6:	jne    8254e4 <<gpui_gpu::renderer::coverage::Interval>::add+0xd4>
  8254d8:	inc    %rcx
  8254db:	jmp    8254e7 <<gpui_gpu::renderer::coverage::Interval>::add+0xd7>
  8254dd:	mov    $0x1,%ecx
  8254e2:	jmp    8254e7 <<gpui_gpu::renderer::coverage::Interval>::add+0xd7>
  8254e4:	dec    %rcx
  8254e7:	movq   %rcx,%xmm1
  8254ec:	movq   %xmm0,%rdx
  8254f1:	and    %rax,%rdx
  8254f4:	xor    %ecx,%ecx
  8254f6:	movabs $0x7fefffffffffffff,%rsi
  825500:	cmp    %rsi,%rdx
  825503:	jg     82557a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  825505:	ucomisd %xmm1,%xmm0
  825509:	ja     82557a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  82550b:	xorpd  %xmm2,%xmm2
  82550f:	ucomisd %xmm2,%xmm0
  825513:	jne    825517 <<gpui_gpu::renderer::coverage::Interval>::add+0x107>
  825515:	jnp    825541 <<gpui_gpu::renderer::coverage::Interval>::add+0x131>
  825517:	dec    %rdx
  82551a:	movq   %xmm1,%rcx
  82551f:	and    %rax,%rcx
  825522:	cmp    %rsi,%rcx
  825525:	setg   %sil
  825529:	xor    %ecx,%ecx
  82552b:	movabs $0xfffffffffffff,%r8
  825535:	cmp    %r8,%rdx
  825538:	jb     82557a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  82553a:	test   %sil,%sil
  82553d:	je     82554e <<gpui_gpu::renderer::coverage::Interval>::add+0x13e>
  82553f:	jmp    82557a <<gpui_gpu::renderer::coverage::Interval>::add+0x16a>
  825541:	movq   %xmm1,%rcx
  825546:	and    %rax,%rcx
  825549:	cmp    %rsi,%rcx
  82554c:	jg     825578 <<gpui_gpu::renderer::coverage::Interval>::add+0x168>
  82554e:	ucomisd %xmm2,%xmm1
  825552:	jne    82555a <<gpui_gpu::renderer::coverage::Interval>::add+0x14a>
  825554:	jnp    82543c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  82555a:	movq   %xmm1,%rcx
  82555f:	and    %rax,%rcx
  825562:	dec    %rcx
  825565:	movabs $0xfffffffffffff,%rax
  82556f:	cmp    %rax,%rcx
  825572:	jae    82543c <<gpui_gpu::renderer::coverage::Interval>::add+0x2c>
  825578:	xor    %ecx,%ecx
  82557a:	mov    %rcx,(%rdi)
  82557d:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::scale bytes=453 frame=0

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825580 <<gpui_gpu::renderer::coverage::Interval>::scale>:
  825580:	movq   %xmm2,%rdx
  825585:	movabs $0x7fffffffffffffff,%rax
  82558f:	and    %rax,%rdx
  825592:	movabs $0x7fefffffffffffff,%rcx
  82559c:	cmp    %rcx,%rdx
  82559f:	jg     8255bf <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  8255a1:	xorpd  %xmm3,%xmm3
  8255a5:	ucomisd %xmm3,%xmm2
  8255a9:	jne    8255ad <<gpui_gpu::renderer::coverage::Interval>::scale+0x2d>
  8255ab:	jnp    8255c5 <<gpui_gpu::renderer::coverage::Interval>::scale+0x45>
  8255ad:	dec    %rdx
  8255b0:	movabs $0xfffffffffffff,%rsi
  8255ba:	cmp    %rsi,%rdx
  8255bd:	jae    8255c5 <<gpui_gpu::renderer::coverage::Interval>::scale+0x45>
  8255bf:	xor    %edx,%edx
  8255c1:	mov    %rdx,(%rdi)
  8255c4:	ret
  8255c5:	ucomisd %xmm3,%xmm2
  8255c9:	jne    8255cd <<gpui_gpu::renderer::coverage::Interval>::scale+0x4d>
  8255cb:	jnp    8255dd <<gpui_gpu::renderer::coverage::Interval>::scale+0x5d>
  8255cd:	ucomisd %xmm3,%xmm0
  8255d1:	jne    8255ef <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  8255d3:	jp     8255ef <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  8255d5:	ucomisd %xmm3,%xmm1
  8255d9:	jne    8255ef <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  8255db:	jp     8255ef <<gpui_gpu::renderer::coverage::Interval>::scale+0x6f>
  8255dd:	xorpd  %xmm0,%xmm0
  8255e1:	movupd %xmm0,0x8(%rdi)
  8255e6:	mov    $0x1,%edx
  8255eb:	mov    %rdx,(%rdi)
  8255ee:	ret
  8255ef:	ucomisd %xmm3,%xmm2
  8255f3:	cmpltsd %xmm2,%xmm3
  8255f8:	movapd %xmm3,%xmm4
  8255fc:	andpd  %xmm0,%xmm4
  825600:	andnpd %xmm1,%xmm3
  825604:	orpd   %xmm4,%xmm3
  825608:	ja     82560e <<gpui_gpu::renderer::coverage::Interval>::scale+0x8e>
  82560a:	movapd %xmm0,%xmm1
  82560e:	mulsd  %xmm2,%xmm1
  825612:	mulsd  %xmm2,%xmm3
  825616:	movq   %xmm3,%rsi
  82561b:	movq   %xmm1,%rdx
  825620:	ucomisd %xmm3,%xmm3
  825624:	setp   %r8b
  825628:	movabs $0xfff0000000000000,%r9
  825632:	cmp    %r9,%rsi
  825635:	sete   %r9b
  825639:	or     %r8b,%r9b
  82563c:	jne    825664 <<gpui_gpu::renderer::coverage::Interval>::scale+0xe4>
  82563e:	mov    %rsi,%r8
  825641:	and    %rax,%r8
  825644:	je     825650 <<gpui_gpu::renderer::coverage::Interval>::scale+0xd0>
  825646:	cmp    %r8,%rsi
  825649:	jne    82565c <<gpui_gpu::renderer::coverage::Interval>::scale+0xdc>
  82564b:	dec    %rsi
  82564e:	jmp    82565f <<gpui_gpu::renderer::coverage::Interval>::scale+0xdf>
  825650:	movabs $0x8000000000000001,%rsi
  82565a:	jmp    82565f <<gpui_gpu::renderer::coverage::Interval>::scale+0xdf>
  82565c:	inc    %rsi
  82565f:	movq   %rsi,%xmm3
  825664:	ucomisd %xmm1,%xmm1
  825668:	setp   %sil
  82566c:	movabs $0x7ff0000000000000,%r8
  825676:	cmp    %r8,%rdx
  825679:	sete   %r8b
  82567d:	or     %sil,%r8b
  825680:	jne    8256a3 <<gpui_gpu::renderer::coverage::Interval>::scale+0x123>
  825682:	mov    %rdx,%rsi
  825685:	and    %rax,%rsi
  825688:	je     825694 <<gpui_gpu::renderer::coverage::Interval>::scale+0x114>
  82568a:	cmp    %rsi,%rdx
  82568d:	jne    82569b <<gpui_gpu::renderer::coverage::Interval>::scale+0x11b>
  82568f:	inc    %rdx
  825692:	jmp    82569e <<gpui_gpu::renderer::coverage::Interval>::scale+0x11e>
  825694:	mov    $0x1,%edx
  825699:	jmp    82569e <<gpui_gpu::renderer::coverage::Interval>::scale+0x11e>
  82569b:	dec    %rdx
  82569e:	movq   %rdx,%xmm1
  8256a3:	movq   %xmm3,%rsi
  8256a8:	and    %rax,%rsi
  8256ab:	xor    %edx,%edx
  8256ad:	cmp    %rcx,%rsi
  8256b0:	jg     8255c1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  8256b6:	ucomisd %xmm1,%xmm3
  8256ba:	ja     8255c1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  8256c0:	xorpd  %xmm0,%xmm0
  8256c4:	ucomisd %xmm0,%xmm3
  8256c8:	jne    8256cc <<gpui_gpu::renderer::coverage::Interval>::scale+0x14c>
  8256ca:	jnp    8256fb <<gpui_gpu::renderer::coverage::Interval>::scale+0x17b>
  8256cc:	dec    %rsi
  8256cf:	movq   %xmm1,%rdx
  8256d4:	and    %rax,%rdx
  8256d7:	cmp    %rcx,%rdx
  8256da:	setg   %cl
  8256dd:	xor    %edx,%edx
  8256df:	movabs $0xfffffffffffff,%r8
  8256e9:	cmp    %r8,%rsi
  8256ec:	jb     8255c1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  8256f2:	test   %cl,%cl
  8256f4:	je     82570c <<gpui_gpu::renderer::coverage::Interval>::scale+0x18c>
  8256f6:	jmp    8255c1 <<gpui_gpu::renderer::coverage::Interval>::scale+0x41>
  8256fb:	movq   %xmm1,%rdx
  825700:	and    %rax,%rdx
  825703:	cmp    %rcx,%rdx
  825706:	jg     8255bf <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  82570c:	ucomisd %xmm0,%xmm1
  825710:	jne    825714 <<gpui_gpu::renderer::coverage::Interval>::scale+0x194>
  825712:	jnp    825732 <<gpui_gpu::renderer::coverage::Interval>::scale+0x1b2>
  825714:	movq   %xmm1,%rcx
  825719:	and    %rax,%rcx
  82571c:	dec    %rcx
  82571f:	movabs $0xfffffffffffff,%rax
  825729:	cmp    %rax,%rcx
  82572c:	jb     8255bf <<gpui_gpu::renderer::coverage::Interval>::scale+0x3f>
  825732:	movsd  %xmm3,0x8(%rdi)
  825737:	movsd  %xmm1,0x10(%rdi)
  82573c:	mov    $0x1,%edx
  825741:	mov    %rdx,(%rdi)
  825744:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::checked bytes=187 frame=0

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825750 <<gpui_gpu::renderer::coverage::Interval>::checked>:
  825750:	movq   %xmm0,%rdx
  825755:	ucomisd %xmm1,%xmm0
  825759:	seta   %sil
  82575d:	movabs $0x7fffffffffffffff,%rax
  825767:	and    %rax,%rdx
  82576a:	movabs $0x7fefffffffffffff,%rcx
  825774:	cmp    %rcx,%rdx
  825777:	setg   %r8b
  82577b:	or     %sil,%r8b
  82577e:	je     825786 <<gpui_gpu::renderer::coverage::Interval>::checked+0x36>
  825780:	xor    %eax,%eax
  825782:	mov    %rax,(%rdi)
  825785:	ret
  825786:	xorpd  %xmm2,%xmm2
  82578a:	ucomisd %xmm2,%xmm0
  82578e:	jne    825792 <<gpui_gpu::renderer::coverage::Interval>::checked+0x42>
  825790:	jnp    8257bd <<gpui_gpu::renderer::coverage::Interval>::checked+0x6d>
  825792:	dec    %rdx
  825795:	movabs $0xfffffffffffff,%rsi
  82579f:	cmp    %rsi,%rdx
  8257a2:	setb   %dl
  8257a5:	movq   %xmm1,%rsi
  8257aa:	and    %rax,%rsi
  8257ad:	cmp    %rcx,%rsi
  8257b0:	setg   %cl
  8257b3:	or     %dl,%cl
  8257b5:	je     8257d0 <<gpui_gpu::renderer::coverage::Interval>::checked+0x80>
  8257b7:	xor    %eax,%eax
  8257b9:	mov    %rax,(%rdi)
  8257bc:	ret
  8257bd:	movq   %xmm1,%rdx
  8257c2:	and    %rax,%rdx
  8257c5:	cmp    %rcx,%rdx
  8257c8:	jle    8257d0 <<gpui_gpu::renderer::coverage::Interval>::checked+0x80>
  8257ca:	xor    %eax,%eax
  8257cc:	mov    %rax,(%rdi)
  8257cf:	ret
  8257d0:	ucomisd %xmm2,%xmm1
  8257d4:	jne    8257d8 <<gpui_gpu::renderer::coverage::Interval>::checked+0x88>
  8257d6:	jnp    8257f8 <<gpui_gpu::renderer::coverage::Interval>::checked+0xa8>
  8257d8:	movq   %xmm1,%rcx
  8257dd:	and    %rax,%rcx
  8257e0:	dec    %rcx
  8257e3:	movabs $0xfffffffffffff,%rax
  8257ed:	cmp    %rax,%rcx
  8257f0:	jae    8257f8 <<gpui_gpu::renderer::coverage::Interval>::checked+0xa8>
  8257f2:	xor    %eax,%eax
  8257f4:	mov    %rax,(%rdi)
  8257f7:	ret
  8257f8:	movsd  %xmm0,0x8(%rdi)
  8257fd:	movsd  %xmm1,0x10(%rdi)
  825802:	mov    $0x1,%eax
  825807:	mov    %rax,(%rdi)
  82580a:	ret

FUNCTION <gpui_gpu::renderer::coverage::Interval>::subtract bytes=382 frame=0

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825810 <<gpui_gpu::renderer::coverage::Interval>::subtract>:
  825810:	xorpd  %xmm4,%xmm4
  825814:	ucomisd %xmm4,%xmm2
  825818:	jne    825824 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  82581a:	jp     825824 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  82581c:	ucomisd %xmm4,%xmm3
  825820:	jne    825824 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14>
  825822:	jnp    82584c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  825824:	ucomisd %xmm4,%xmm0
  825828:	jne    82585f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  82582a:	jp     82585f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  82582c:	ucomisd %xmm4,%xmm1
  825830:	jne    82585f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  825832:	jp     82585f <<gpui_gpu::renderer::coverage::Interval>::subtract+0x4f>
  825834:	movapd -0x77767c(%rip),%xmm0        # ae1c0 <anon.630a3fff68f6bca64b568be97512ab45.90.llvm.826976926275214120+0x90>
  82583c:	xorpd  %xmm0,%xmm2
  825840:	xorpd  %xmm0,%xmm3
  825844:	movapd %xmm3,%xmm0
  825848:	movapd %xmm2,%xmm1
  82584c:	movsd  %xmm0,0x8(%rdi)
  825851:	movsd  %xmm1,0x10(%rdi)
  825856:	mov    $0x1,%ecx
  82585b:	mov    %rcx,(%rdi)
  82585e:	ret
  82585f:	subsd  %xmm3,%xmm0
  825863:	subsd  %xmm2,%xmm1
  825867:	movq   %xmm0,%rdx
  82586c:	movq   %xmm1,%rcx
  825871:	ucomisd %xmm0,%xmm0
  825875:	setp   %al
  825878:	movabs $0xfff0000000000000,%rsi
  825882:	cmp    %rsi,%rdx
  825885:	sete   %sil
  825889:	or     %al,%sil
  82588c:	movabs $0x7fffffffffffffff,%rax
  825896:	jne    8258be <<gpui_gpu::renderer::coverage::Interval>::subtract+0xae>
  825898:	mov    %rdx,%rsi
  82589b:	and    %rax,%rsi
  82589e:	je     8258aa <<gpui_gpu::renderer::coverage::Interval>::subtract+0x9a>
  8258a0:	cmp    %rsi,%rdx
  8258a3:	jne    8258b6 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa6>
  8258a5:	dec    %rdx
  8258a8:	jmp    8258b9 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa9>
  8258aa:	movabs $0x8000000000000001,%rdx
  8258b4:	jmp    8258b9 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xa9>
  8258b6:	inc    %rdx
  8258b9:	movq   %rdx,%xmm0
  8258be:	ucomisd %xmm1,%xmm1
  8258c2:	setp   %dl
  8258c5:	movabs $0x7ff0000000000000,%rsi
  8258cf:	cmp    %rsi,%rcx
  8258d2:	sete   %sil
  8258d6:	or     %dl,%sil
  8258d9:	jne    8258fc <<gpui_gpu::renderer::coverage::Interval>::subtract+0xec>
  8258db:	mov    %rcx,%rdx
  8258de:	and    %rax,%rdx
  8258e1:	je     8258ed <<gpui_gpu::renderer::coverage::Interval>::subtract+0xdd>
  8258e3:	cmp    %rdx,%rcx
  8258e6:	jne    8258f4 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe4>
  8258e8:	inc    %rcx
  8258eb:	jmp    8258f7 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe7>
  8258ed:	mov    $0x1,%ecx
  8258f2:	jmp    8258f7 <<gpui_gpu::renderer::coverage::Interval>::subtract+0xe7>
  8258f4:	dec    %rcx
  8258f7:	movq   %rcx,%xmm1
  8258fc:	movq   %xmm0,%rdx
  825901:	and    %rax,%rdx
  825904:	xor    %ecx,%ecx
  825906:	movabs $0x7fefffffffffffff,%rsi
  825910:	cmp    %rsi,%rdx
  825913:	jg     82598a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  825915:	ucomisd %xmm1,%xmm0
  825919:	ja     82598a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  82591b:	xorpd  %xmm2,%xmm2
  82591f:	ucomisd %xmm2,%xmm0
  825923:	jne    825927 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x117>
  825925:	jnp    825951 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x141>
  825927:	dec    %rdx
  82592a:	movq   %xmm1,%rcx
  82592f:	and    %rax,%rcx
  825932:	cmp    %rsi,%rcx
  825935:	setg   %sil
  825939:	xor    %ecx,%ecx
  82593b:	movabs $0xfffffffffffff,%r8
  825945:	cmp    %r8,%rdx
  825948:	jb     82598a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  82594a:	test   %sil,%sil
  82594d:	je     82595e <<gpui_gpu::renderer::coverage::Interval>::subtract+0x14e>
  82594f:	jmp    82598a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x17a>
  825951:	movq   %xmm1,%rcx
  825956:	and    %rax,%rcx
  825959:	cmp    %rsi,%rcx
  82595c:	jg     825988 <<gpui_gpu::renderer::coverage::Interval>::subtract+0x178>
  82595e:	ucomisd %xmm2,%xmm1
  825962:	jne    82596a <<gpui_gpu::renderer::coverage::Interval>::subtract+0x15a>
  825964:	jnp    82584c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  82596a:	movq   %xmm1,%rcx
  82596f:	and    %rax,%rcx
  825972:	dec    %rcx
  825975:	movabs $0xfffffffffffff,%rax
  82597f:	cmp    %rax,%rcx
  825982:	jae    82584c <<gpui_gpu::renderer::coverage::Interval>::subtract+0x3c>
  825988:	xor    %ecx,%ecx
  82598a:	mov    %rcx,(%rdi)
  82598d:	ret

FUNCTION gpui_gpu::renderer::coverage::axis bytes=1662 frame=344

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825990 <gpui_gpu::renderer::coverage::axis>:
  825990:	push   %r15
  825992:	push   %r14
  825994:	push   %r13
  825996:	push   %r12
  825998:	push   %rbx
  825999:	sub    $0x130,%rsp
  8259a0:	movq   %xmm4,%r12
  8259a5:	movabs $0x7fffffffffffffff,%rbx
  8259af:	and    %rbx,%r12
  8259b2:	mov    $0x2,%al
  8259b4:	movabs $0x7fefffffffffffff,%r14
  8259be:	cmp    %r14,%r12
  8259c1:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  8259c7:	movsd  (%rdi),%xmm11
  8259cc:	movsd  0x8(%rdi),%xmm8
  8259d2:	movsd  0x10(%rdi),%xmm9
  8259d8:	xorpd  %xmm10,%xmm10
  8259dd:	ucomisd %xmm10,%xmm4
  8259e2:	jne    8259e6 <gpui_gpu::renderer::coverage::axis+0x56>
  8259e4:	jnp    8259fe <gpui_gpu::renderer::coverage::axis+0x6e>
  8259e6:	lea    -0x1(%r12),%rcx
  8259eb:	movabs $0xfffffffffffff,%rdx
  8259f5:	cmp    %rdx,%rcx
  8259f8:	jb     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  8259fe:	movq   %xmm5,%r15
  825a03:	and    %rbx,%r15
  825a06:	cmp    %r14,%r15
  825a09:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825a0f:	ucomisd %xmm10,%xmm5
  825a14:	jne    825a18 <gpui_gpu::renderer::coverage::axis+0x88>
  825a16:	jnp    825a2f <gpui_gpu::renderer::coverage::axis+0x9f>
  825a18:	lea    -0x1(%r15),%rcx
  825a1c:	movabs $0xfffffffffffff,%rdx
  825a26:	cmp    %rdx,%rcx
  825a29:	jb     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825a2f:	movaps %xmm8,0xc0(%rsp)
  825a38:	movsd  %xmm2,0x60(%rsp)
  825a3e:	movsd  %xmm3,0x28(%rsp)
  825a44:	movaps %xmm9,0x80(%rsp)
  825a4d:	movaps %xmm4,0xb0(%rsp)
  825a55:	movsd  %xmm6,0xa8(%rsp)
  825a5e:	movsd  %xmm7,0x30(%rsp)
  825a64:	movaps %xmm5,0x90(%rsp)
  825a6c:	mov    %rsp,%rdi
  825a6f:	movsd  %xmm0,0x38(%rsp)
  825a75:	movsd  %xmm1,0x40(%rsp)
  825a7b:	movapd %xmm11,0x120(%rsp)
  825a85:	movapd %xmm11,%xmm2
  825a8a:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825a8f:	cmpl   $0x1,(%rsp)
  825a93:	jne    825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825a99:	movsd  0x8(%rsp),%xmm0
  825a9f:	movsd  %xmm0,0x20(%rsp)
  825aa5:	movsd  0x10(%rsp),%xmm0
  825aab:	movsd  %xmm0,0x18(%rsp)
  825ab1:	mov    %rsp,%rdi
  825ab4:	movsd  0x60(%rsp),%xmm0
  825aba:	movsd  0x28(%rsp),%xmm1
  825ac0:	movapd 0xc0(%rsp),%xmm2
  825ac9:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825ace:	cmpb   $0x0,(%rsp)
  825ad2:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825ad8:	movsd  0x8(%rsp),%xmm5
  825ade:	movsd  0x10(%rsp),%xmm4
  825ae4:	xorpd  %xmm2,%xmm2
  825ae8:	ucomisd %xmm2,%xmm5
  825aec:	mov    $0x2,%al
  825aee:	jne    825b11 <gpui_gpu::renderer::coverage::axis+0x181>
  825af0:	jp     825b11 <gpui_gpu::renderer::coverage::axis+0x181>
  825af2:	ucomisd %xmm2,%xmm4
  825af6:	jne    825b11 <gpui_gpu::renderer::coverage::axis+0x181>
  825af8:	jp     825b11 <gpui_gpu::renderer::coverage::axis+0x181>
  825afa:	movdqa 0x80(%rsp),%xmm2
  825b03:	movsd  0x18(%rsp),%xmm1
  825b09:	movsd  0x20(%rsp),%xmm0
  825b0f:	jmp    825b52 <gpui_gpu::renderer::coverage::axis+0x1c2>
  825b11:	movsd  0x20(%rsp),%xmm0
  825b17:	ucomisd %xmm2,%xmm0
  825b1b:	movdqa 0x80(%rsp),%xmm2
  825b24:	movsd  0x18(%rsp),%xmm1
  825b2a:	jne    825ee1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b30:	jp     825ee1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b36:	xorpd  %xmm3,%xmm3
  825b3a:	ucomisd %xmm3,%xmm1
  825b3e:	jne    825ee1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b44:	jp     825ee1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b4a:	movapd %xmm4,%xmm1
  825b4e:	movapd %xmm5,%xmm0
  825b52:	movq   %xmm2,%r13
  825b57:	and    %rbx,%r13
  825b5a:	cmp    %r14,%r13
  825b5d:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825b63:	xorpd  %xmm3,%xmm3
  825b67:	ucomisd %xmm3,%xmm2
  825b6b:	jne    825b6f <gpui_gpu::renderer::coverage::axis+0x1df>
  825b6d:	jnp    825b86 <gpui_gpu::renderer::coverage::axis+0x1f6>
  825b6f:	lea    -0x1(%r13),%rcx
  825b73:	movabs $0xfffffffffffff,%rdx
  825b7d:	cmp    %rdx,%rcx
  825b80:	jb     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825b86:	lea    0x48(%rsp),%rdi
  825b8b:	movapd 0x80(%rsp),%xmm3
  825b94:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825b99:	movapd 0xb0(%rsp),%xmm2
  825ba2:	mov    $0x2,%al
  825ba4:	cmpb   $0x0,0x48(%rsp)
  825ba9:	je     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825baf:	movsd  0x50(%rsp),%xmm0
  825bb5:	movsd  0x58(%rsp),%xmm1
  825bbb:	lea    0x68(%rsp),%rdi
  825bc0:	movapd %xmm2,%xmm3
  825bc4:	call   825810 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825bc9:	cmpl   $0x1,0x68(%rsp)
  825bce:	jne    825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825bd4:	movsd  0x70(%rsp),%xmm0
  825bda:	movsd  %xmm0,0x18(%rsp)
  825be0:	movsd  0x78(%rsp),%xmm0
  825be6:	movsd  %xmm0,0x20(%rsp)
  825bec:	movapd 0x120(%rsp),%xmm2
  825bf5:	andpd  -0x77adcd(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825bfd:	mov    %rsp,%rdi
  825c00:	movsd  0x38(%rsp),%xmm0
  825c06:	movsd  0x40(%rsp),%xmm1
  825c0c:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825c11:	cmpb   $0x0,(%rsp)
  825c15:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825c1b:	movsd  0x8(%rsp),%xmm0
  825c21:	movsd  %xmm0,0x40(%rsp)
  825c27:	movsd  0x10(%rsp),%xmm0
  825c2d:	movsd  %xmm0,0x38(%rsp)
  825c33:	movapd 0xc0(%rsp),%xmm2
  825c3c:	andpd  -0x77ae14(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825c44:	mov    %rsp,%rdi
  825c47:	movsd  0x60(%rsp),%xmm0
  825c4d:	movsd  0x28(%rsp),%xmm1
  825c53:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825c58:	cmpb   $0x0,(%rsp)
  825c5c:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825c62:	movsd  0x8(%rsp),%xmm2
  825c68:	movsd  0x10(%rsp),%xmm3
  825c6e:	lea    0x48(%rsp),%rdi
  825c73:	movsd  0x40(%rsp),%xmm0
  825c79:	movsd  0x38(%rsp),%xmm1
  825c7f:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825c84:	cmpb   $0x0,0x48(%rsp)
  825c89:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825c8f:	xorpd  %xmm0,%xmm0
  825c93:	movapd 0x80(%rsp),%xmm2
  825c9c:	ucomisd %xmm0,%xmm2
  825ca0:	movsd  0x50(%rsp),%xmm0
  825ca6:	movsd  0x58(%rsp),%xmm1
  825cac:	jne    825cb0 <gpui_gpu::renderer::coverage::axis+0x320>
  825cae:	jnp    825cc6 <gpui_gpu::renderer::coverage::axis+0x336>
  825cb0:	dec    %r13
  825cb3:	movabs $0xfffffffffffff,%rax
  825cbd:	cmp    %rax,%r13
  825cc0:	jb     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825cc6:	andpd  -0x77ae9e(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825cce:	lea    0x68(%rsp),%rdi
  825cd3:	movapd %xmm2,%xmm3
  825cd7:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825cdc:	cmpb   $0x0,0x68(%rsp)
  825ce1:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825ce7:	xorpd  %xmm0,%xmm0
  825ceb:	movapd 0xb0(%rsp),%xmm2
  825cf4:	ucomisd %xmm0,%xmm2
  825cf8:	movsd  0x70(%rsp),%xmm0
  825cfe:	movsd  0x78(%rsp),%xmm1
  825d04:	jne    825d08 <gpui_gpu::renderer::coverage::axis+0x378>
  825d06:	jnp    825d1e <gpui_gpu::renderer::coverage::axis+0x38e>
  825d08:	dec    %r12
  825d0b:	movabs $0xfffffffffffff,%rax
  825d15:	cmp    %rax,%r12
  825d18:	jb     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825d1e:	andpd  -0x77aef6(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825d26:	lea    0x108(%rsp),%rdi
  825d2e:	movapd %xmm2,%xmm3
  825d32:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825d37:	cmpb   $0x0,0x108(%rsp)
  825d3f:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825d45:	xorpd  %xmm0,%xmm0
  825d49:	movapd 0x90(%rsp),%xmm1
  825d52:	ucomisd %xmm0,%xmm1
  825d56:	movsd  0x110(%rsp),%xmm0
  825d5f:	movsd  0x118(%rsp),%xmm1
  825d68:	jne    825d6c <gpui_gpu::renderer::coverage::axis+0x3dc>
  825d6a:	jnp    825d82 <gpui_gpu::renderer::coverage::axis+0x3f2>
  825d6c:	dec    %r15
  825d6f:	movabs $0xfffffffffffff,%rax
  825d79:	cmp    %rax,%r15
  825d7c:	jb     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825d82:	movapd -0x77af5a(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825d8a:	andpd  0x90(%rsp),%xmm2
  825d93:	lea    0xf0(%rsp),%rdi
  825d9b:	movapd %xmm2,%xmm3
  825d9f:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825da4:	cmpb   $0x0,0xf0(%rsp)
  825dac:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825db2:	movsd  0xf8(%rsp),%xmm0
  825dbb:	movsd  0x100(%rsp),%xmm1
  825dc4:	lea    0xd8(%rsp),%rdi
  825dcc:	movsd  -0x7764f4(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  825dd4:	movapd %xmm2,%xmm3
  825dd8:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825ddd:	cmpl   $0x1,0xd8(%rsp)
  825de5:	jne    825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825deb:	movsd  0xe0(%rsp),%xmm0
  825df4:	movsd  0xe8(%rsp),%xmm1
  825dfd:	mov    %rsp,%rdi
  825e00:	movsd  0xa8(%rsp),%xmm2
  825e09:	call   825580 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825e0e:	cmpb   $0x0,(%rsp)
  825e12:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825e18:	movq   0x30(%rsp),%xmm0
  825e1e:	movq   %xmm0,%rax
  825e23:	and    %rbx,%rax
  825e26:	cmp    %r14,%rax
  825e29:	jg     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825e2f:	movsd  0x8(%rsp),%xmm0
  825e35:	movsd  0x10(%rsp),%xmm1
  825e3b:	xorpd  %xmm2,%xmm2
  825e3f:	movsd  0x30(%rsp),%xmm3
  825e45:	ucomisd %xmm2,%xmm3
  825e49:	jne    825e4d <gpui_gpu::renderer::coverage::axis+0x4bd>
  825e4b:	jnp    825e5f <gpui_gpu::renderer::coverage::axis+0x4cf>
  825e4d:	dec    %rax
  825e50:	movabs $0xfffffffffffff,%rcx
  825e5a:	cmp    %rcx,%rax
  825e5d:	jb     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825e5f:	lea    0x48(%rsp),%rdi
  825e64:	movsd  0x30(%rsp),%xmm2
  825e6a:	movapd %xmm2,%xmm3
  825e6e:	call   825410 <<gpui_gpu::renderer::coverage::Interval>::add>
  825e73:	cmpb   $0x0,0x48(%rsp)
  825e78:	je     825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825e7a:	movsd  0x58(%rsp),%xmm1
  825e80:	movsd  0x18(%rsp),%xmm0
  825e86:	movsd  %xmm1,0x28(%rsp)
  825e8c:	ucomisd %xmm1,%xmm0
  825e90:	jbe    826007 <gpui_gpu::renderer::coverage::axis+0x677>
  825e96:	mov    %rsp,%rdi
  825e99:	movapd 0x90(%rsp),%xmm0
  825ea2:	movapd %xmm0,%xmm1
  825ea6:	movsd  0x18(%rsp),%xmm2
  825eac:	movsd  0x20(%rsp),%xmm3
  825eb2:	call   825810 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825eb7:	cmpl   $0x1,(%rsp)
  825ebb:	jne    825ece <gpui_gpu::renderer::coverage::axis+0x53e>
  825ebd:	movsd  0x8(%rsp),%xmm0
  825ec3:	ucomisd 0x28(%rsp),%xmm0
  825ec9:	seta   %al
  825ecc:	jmp    825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825ece:	mov    $0x2,%al
  825ed0:	add    $0x130,%rsp
  825ed7:	pop    %rbx
  825ed8:	pop    %r12
  825eda:	pop    %r13
  825edc:	pop    %r14
  825ede:	pop    %r15
  825ee0:	ret
  825ee1:	addsd  %xmm5,%xmm0
  825ee5:	addsd  %xmm4,%xmm1
  825ee9:	movq   %xmm0,%rdx
  825eee:	movq   %xmm1,%rcx
  825ef3:	ucomisd %xmm0,%xmm0
  825ef7:	setp   %sil
  825efb:	movabs $0xfff0000000000000,%rdi
  825f05:	cmp    %rdi,%rdx
  825f08:	sete   %dil
  825f0c:	or     %sil,%dil
  825f0f:	jne    825f37 <gpui_gpu::renderer::coverage::axis+0x5a7>
  825f11:	mov    %rdx,%rsi
  825f14:	and    %rbx,%rsi
  825f17:	je     825f23 <gpui_gpu::renderer::coverage::axis+0x593>
  825f19:	cmp    %rsi,%rdx
  825f1c:	jne    825f2f <gpui_gpu::renderer::coverage::axis+0x59f>
  825f1e:	dec    %rdx
  825f21:	jmp    825f32 <gpui_gpu::renderer::coverage::axis+0x5a2>
  825f23:	movabs $0x8000000000000001,%rdx
  825f2d:	jmp    825f32 <gpui_gpu::renderer::coverage::axis+0x5a2>
  825f2f:	inc    %rdx
  825f32:	movq   %rdx,%xmm0
  825f37:	ucomisd %xmm1,%xmm1
  825f3b:	setp   %dl
  825f3e:	movabs $0x7ff0000000000000,%rsi
  825f48:	cmp    %rsi,%rcx
  825f4b:	sete   %sil
  825f4f:	or     %dl,%sil
  825f52:	jne    825f75 <gpui_gpu::renderer::coverage::axis+0x5e5>
  825f54:	mov    %rcx,%rdx
  825f57:	and    %rbx,%rdx
  825f5a:	je     825f66 <gpui_gpu::renderer::coverage::axis+0x5d6>
  825f5c:	cmp    %rdx,%rcx
  825f5f:	jne    825f6d <gpui_gpu::renderer::coverage::axis+0x5dd>
  825f61:	inc    %rcx
  825f64:	jmp    825f70 <gpui_gpu::renderer::coverage::axis+0x5e0>
  825f66:	mov    $0x1,%ecx
  825f6b:	jmp    825f70 <gpui_gpu::renderer::coverage::axis+0x5e0>
  825f6d:	dec    %rcx
  825f70:	movq   %rcx,%xmm1
  825f75:	movq   %xmm0,%rdx
  825f7a:	and    %rbx,%rdx
  825f7d:	cmp    %r14,%rdx
  825f80:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825f86:	ucomisd %xmm1,%xmm0
  825f8a:	ja     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825f90:	xorpd  %xmm3,%xmm3
  825f94:	ucomisd %xmm3,%xmm0
  825f98:	movq   %xmm1,%rcx
  825f9d:	jne    825fa1 <gpui_gpu::renderer::coverage::axis+0x611>
  825f9f:	jnp    825fce <gpui_gpu::renderer::coverage::axis+0x63e>
  825fa1:	dec    %rdx
  825fa4:	mov    %rcx,%rsi
  825fa7:	and    %rbx,%rsi
  825faa:	cmp    %r14,%rsi
  825fad:	setg   %sil
  825fb1:	movabs $0xfffffffffffff,%rdi
  825fbb:	cmp    %rdi,%rdx
  825fbe:	jb     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825fc4:	test   %sil,%sil
  825fc7:	je     825fdd <gpui_gpu::renderer::coverage::axis+0x64d>
  825fc9:	jmp    825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825fce:	mov    %rcx,%rdx
  825fd1:	and    %rbx,%rdx
  825fd4:	cmp    %r14,%rdx
  825fd7:	jg     825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  825fdd:	ucomisd %xmm3,%xmm1
  825fe1:	jne    825fe9 <gpui_gpu::renderer::coverage::axis+0x659>
  825fe3:	jnp    825b52 <gpui_gpu::renderer::coverage::axis+0x1c2>
  825fe9:	and    %rbx,%rcx
  825fec:	dec    %rcx
  825fef:	movabs $0xfffffffffffff,%rdx
  825ff9:	cmp    %rdx,%rcx
  825ffc:	jae    825b52 <gpui_gpu::renderer::coverage::axis+0x1c2>
  826002:	jmp    825ed0 <gpui_gpu::renderer::coverage::axis+0x540>
  826007:	xor    %eax,%eax
  826009:	jmp    825ed0 <gpui_gpu::renderer::coverage::axis+0x540>

FUNCTION gpui_gpu::renderer::coverage::whole bytes=1462 frame=248

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826010 <gpui_gpu::renderer::coverage::whole>:
  826010:	push   %rbp
  826011:	push   %r15
  826013:	push   %r14
  826015:	push   %r13
  826017:	push   %r12
  826019:	push   %rbx
  82601a:	sub    $0xc8,%rsp
  826021:	mov    %rsi,0x30(%rsp)
  826026:	cmpb   $0x0,(%rdi)
  826029:	jne    8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  82602f:	test   %esi,%esi
  826031:	sets   %al
  826034:	mov    %esi,%r9d
  826037:	and    $0x7fffffff,%r9d
  82603e:	lea    -0x800000(%r9),%r10d
  826045:	cmp    $0x7f000000,%r10d
  82604c:	setb   %r10b
  826050:	and    %al,%r10b
  826053:	lea    -0x1(%r9),%r11d
  826057:	cmp    $0x7fffff,%r11d
  82605e:	setb   %r11b
  826062:	and    %al,%r11b
  826065:	cmp    $0x7f800000,%r9d
  82606c:	sete   %al
  82606f:	setg   %r9b
  826073:	or     %al,%r9b
  826076:	or     %r11b,%r9b
  826079:	or     %r10b,%r9b
  82607c:	jne    8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  82607e:	shr    $0x20,%rsi
  826082:	test   %esi,%esi
  826084:	sets   %al
  826087:	and    $0x7fffffff,%esi
  82608d:	lea    -0x800000(%rsi),%r9d
  826094:	cmp    $0x7f000000,%r9d
  82609b:	setb   %r9b
  82609f:	and    %al,%r9b
  8260a2:	lea    -0x1(%rsi),%r10d
  8260a6:	cmp    $0x7fffff,%r10d
  8260ad:	setb   %r10b
  8260b1:	and    %al,%r10b
  8260b4:	cmp    $0x7f800000,%esi
  8260ba:	sete   %al
  8260bd:	setg   %sil
  8260c1:	or     %al,%sil
  8260c4:	or     %r10b,%sil
  8260c7:	or     %r9b,%sil
  8260ca:	je     8260e2 <gpui_gpu::renderer::coverage::whole+0xd2>
  8260cc:	xor    %eax,%eax
  8260ce:	and    $0x1,%al
  8260d0:	add    $0xc8,%rsp
  8260d7:	pop    %rbx
  8260d8:	pop    %r12
  8260da:	pop    %r13
  8260dc:	pop    %r14
  8260de:	pop    %r15
  8260e0:	pop    %rbp
  8260e1:	ret
  8260e2:	movss  0x88(%rdi),%xmm1
  8260ea:	movss  -0x7770d6(%rip),%xmm2        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8260f2:	movaps %xmm1,%xmm0
  8260f5:	subss  %xmm2,%xmm0
  8260f9:	cvttss2si %xmm0,%rax
  8260fe:	cvttss2si %xmm1,%rsi
  826103:	mov    %rsi,%r9
  826106:	sar    $0x3f,%r9
  82610a:	and    %rax,%r9
  82610d:	or     %rsi,%r9
  826110:	xor    %eax,%eax
  826112:	xorps  %xmm0,%xmm0
  826115:	ucomiss %xmm0,%xmm1
  826118:	cmovb  %rax,%r9
  82611c:	movss  0x8c(%rdi),%xmm4
  826124:	movss  -0x77710c(%rip),%xmm3        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82612c:	ucomiss %xmm3,%xmm1
  82612f:	mov    $0xffffffffffffffff,%rbx
  826136:	cmova  %rbx,%r9
  82613a:	movaps %xmm4,%xmm1
  82613d:	subss  %xmm2,%xmm1
  826141:	cvttss2si %xmm1,%rsi
  826146:	cvttss2si %xmm4,%r11
  82614b:	mov    %r11,%r10
  82614e:	sar    $0x3f,%r10
  826152:	and    %rsi,%r10
  826155:	or     %r11,%r10
  826158:	ucomiss %xmm0,%xmm4
  82615b:	cmovb  %rax,%r10
  82615f:	ucomiss %xmm3,%xmm4
  826162:	movss  0x90(%rdi),%xmm1
  82616a:	cmova  %rbx,%r10
  82616e:	movaps %xmm1,%xmm4
  826171:	subss  %xmm2,%xmm4
  826175:	cvttss2si %xmm4,%r11
  82617a:	cvttss2si %xmm1,%r14
  82617f:	mov    %r14,%rsi
  826182:	sar    $0x3f,%rsi
  826186:	and    %r11,%rsi
  826189:	or     %r14,%rsi
  82618c:	ucomiss %xmm0,%xmm1
  82618f:	cmovb  %rax,%rsi
  826193:	ucomiss %xmm3,%xmm1
  826196:	cmova  %rbx,%rsi
  82619a:	add    %r9,%rsi
  82619d:	setb   %r11b
  8261a1:	sete   %bpl
  8261a5:	or     %r11b,%bpl
  8261a8:	jne    8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  8261ae:	movss  0x94(%rdi),%xmm2
  8261b6:	cvttss2si %xmm2,%rax
  8261bb:	mov    %rax,%r11
  8261be:	movaps %xmm2,%xmm3
  8261c1:	subss  -0x7771ad(%rip),%xmm3        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  8261c9:	sar    $0x3f,%r11
  8261cd:	cvttss2si %xmm3,%r14
  8261d2:	and    %r11,%r14
  8261d5:	or     %rax,%r14
  8261d8:	xor    %eax,%eax
  8261da:	ucomiss %xmm0,%xmm2
  8261dd:	mov    $0x0,%r11d
  8261e3:	cmovae %r14,%r11
  8261e7:	ucomiss -0x7771ce(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8261ee:	cmova  %rbx,%r11
  8261f2:	add    %r10,%r11
  8261f5:	setb   %bl
  8261f8:	sete   %bpl
  8261fc:	or     %bl,%bpl
  8261ff:	jne    8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826205:	xor    %eax,%eax
  826207:	test   %rdx,%rdx
  82620a:	je     8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826210:	movss  -0x777438(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  826218:	ucomiss %xmm1,%xmm0
  82621b:	ja     8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826221:	ucomiss %xmm2,%xmm0
  826224:	ja     8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  82622a:	dec    %rsi
  82622d:	dec    %r11
  826230:	shr    $0x4,%r10
  826234:	imul   %rdx,%r10
  826238:	shr    $0x4,%r9
  82623c:	add    %r10,%r9
  82623f:	mov    %r9,%rax
  826242:	mov    %rdx,%rbx
  826245:	or     %rdx,%rax
  826248:	shr    $0x20,%rax
  82624c:	je     82625e <gpui_gpu::renderer::coverage::whole+0x24e>
  82624e:	mov    %r9,%rax
  826251:	xor    %edx,%edx
  826253:	div    %rbx
  826256:	mov    %rdx,%r10
  826259:	mov    %rax,%r9
  82625c:	jmp    82626b <gpui_gpu::renderer::coverage::whole+0x25b>
  82625e:	mov    %r9d,%eax
  826261:	xor    %edx,%edx
  826263:	div    %ebx
  826265:	mov    %edx,%r10d
  826268:	mov    %eax,%r9d
  82626b:	shl    $0x4,%r10d
  82626f:	shr    $0x4,%r11
  826273:	imul   %rbx,%r11
  826277:	shr    $0x4,%rsi
  82627b:	add    %r11,%rsi
  82627e:	mov    %rsi,%rdx
  826281:	or     %rbx,%rdx
  826284:	shr    $0x20,%rdx
  826288:	je     826294 <gpui_gpu::renderer::coverage::whole+0x284>
  82628a:	mov    %rsi,%rax
  82628d:	xor    %edx,%edx
  82628f:	div    %rbx
  826292:	jmp    82629a <gpui_gpu::renderer::coverage::whole+0x28a>
  826294:	mov    %esi,%eax
  826296:	xor    %edx,%edx
  826298:	div    %ebx
  82629a:	shl    $0x4,%edx
  82629d:	shl    $0x4,%eax
  8262a0:	add    $0x10,%edx
  8262a3:	cmp    %edx,%ecx
  8262a5:	cmovb  %ecx,%edx
  8262a8:	add    $0x10,%eax
  8262ab:	cmp    %eax,%r8d
  8262ae:	cmovb  %r8d,%eax
  8262b2:	movss  0x78(%rdi),%xmm0
  8262b7:	cvtss2sd %xmm0,%xmm2
  8262bb:	mov    %r10d,%ecx
  8262be:	xorps  %xmm0,%xmm0
  8262c1:	cvtsi2sd %rcx,%xmm0
  8262c6:	ucomisd %xmm0,%xmm2
  8262ca:	ja     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8262d0:	shl    $0x4,%r9d
  8262d4:	movss  0x7c(%rdi),%xmm1
  8262d9:	cvtss2sd %xmm1,%xmm3
  8262dd:	cvtsi2sd %r9,%xmm4
  8262e2:	ucomisd %xmm4,%xmm3
  8262e6:	ja     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8262ec:	movss  0x80(%rdi),%xmm1
  8262f4:	cvtss2sd %xmm1,%xmm1
  8262f8:	addsd  %xmm1,%xmm2
  8262fc:	mov    %edx,%ecx
  8262fe:	xorps  %xmm1,%xmm1
  826301:	cvtsi2sd %rcx,%xmm1
  826306:	ucomisd %xmm2,%xmm1
  82630a:	ja     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826310:	movss  0x84(%rdi),%xmm2
  826318:	cvtss2sd %xmm2,%xmm2
  82631c:	addsd  %xmm3,%xmm2
  826320:	mov    %eax,%eax
  826322:	xorps  %xmm3,%xmm3
  826325:	cvtsi2sd %rax,%xmm3
  82632a:	ucomisd %xmm2,%xmm3
  82632e:	ja     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826334:	movsd  %xmm3,(%rsp)
  826339:	movsd  %xmm4,0x8(%rsp)
  82633f:	mov    %rdi,%rbx
  826342:	addsd  -0x776ae2(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82634a:	addsd  -0x776d6a(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  826352:	lea    0x38(%rsp),%rdi
  826357:	call   825750 <<gpui_gpu::renderer::coverage::Interval>::checked>
  82635c:	cmpl   $0x1,0x38(%rsp)
  826361:	jne    8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  826367:	movsd  0x40(%rsp),%xmm0
  82636d:	movsd  %xmm0,0x28(%rsp)
  826373:	movsd  0x48(%rsp),%xmm0
  826379:	movsd  %xmm0,0x20(%rsp)
  82637f:	movsd  0x8(%rsp),%xmm0
  826385:	addsd  -0x776b25(%rip),%xmm0        # af868 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x20>
  82638d:	movsd  (%rsp),%xmm1
  826392:	addsd  -0x776db2(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82639a:	lea    0x38(%rsp),%rdi
  82639f:	call   825750 <<gpui_gpu::renderer::coverage::Interval>::checked>
  8263a4:	cmpb   $0x0,0x38(%rsp)
  8263a9:	je     8260cc <gpui_gpu::renderer::coverage::whole+0xbc>
  8263af:	movsd  0x40(%rsp),%xmm0
  8263b5:	movsd  %xmm0,0x18(%rsp)
  8263bb:	movsd  0x48(%rsp),%xmm0
  8263c1:	movsd  %xmm0,0x10(%rsp)
  8263c7:	mov    %rbx,%rcx
  8263ca:	movss  0x38(%rbx),%xmm0
  8263cf:	movss  0x3c(%rbx),%xmm1
  8263d4:	movss  0x40(%rbx),%xmm2
  8263d9:	movss  0x44(%rbx),%xmm3
  8263de:	lea    0xa8(%rsp),%r14
  8263e6:	movq   $0x0,0xa8(%rsp)
  8263f2:	movss  %xmm0,0xb0(%rsp)
  8263fb:	movss  %xmm2,0xb4(%rsp)
  826404:	movq   $0x1,0xb8(%rsp)
  826410:	movss  %xmm1,0xc0(%rsp)
  826419:	movss  %xmm3,0xc4(%rsp)
  826422:	lea    0x48(%rsp),%r15
  826427:	xor    %r12d,%r12d
  82642a:	movabs $0x3ec0000000000000,%r13
  826434:	movsd  -0x7765fd(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82643d:	xor    %edx,%edx
  82643f:	shl    $0x4,%rdx
  826443:	mov    (%r14,%rdx,1),%rdi
  826447:	cmp    $0x6,%rdi
  82644b:	jae    826589 <gpui_gpu::renderer::coverage::whole+0x579>
  826451:	cmp    $0x4,%rdi
  826455:	jae    82659b <gpui_gpu::renderer::coverage::whole+0x58b>
  82645b:	mov    %rdi,%rax
  82645e:	or     $0x4,%rax
  826462:	cmp    $0x6,%rax
  826466:	jae    8265b1 <gpui_gpu::renderer::coverage::whole+0x5a1>
  82646c:	movss  0x8(%r14,%rdx,1),%xmm0
  826473:	movss  0xc(%r14,%rdx,1),%xmm1
  82647a:	movsd  0x48(%rcx,%rdi,8),%xmm2
  826480:	movsd  0x48(%rcx,%rax,8),%xmm3
  826486:	xorps  %xmm4,%xmm4
  826489:	cvtsd2ss %xmm3,%xmm4
  82648d:	movsd  0x58(%rcx,%rdi,8),%xmm5
  826493:	cvtss2sd %xmm4,%xmm4
  826497:	movss  0x30(%rsp,%rdi,4),%xmm6
  82649d:	cvtss2sd %xmm6,%xmm6
  8264a1:	movq   $0x0,0x38(%rsp)
  8264aa:	movq   $0x2,0x40(%rsp)
  8264b3:	movapd %xmm2,%xmm7
  8264b7:	unpcklpd %xmm5,%xmm7
  8264bb:	cvtpd2ps %xmm7,%xmm7
  8264bf:	cvtps2pd %xmm7,%xmm7
  8264c2:	movups %xmm7,0x48(%rsp)
  8264c7:	movsd  %xmm4,0x58(%rsp)
  8264cd:	mov    %r13,0x60(%rsp)
  8264d2:	movsd  %xmm6,0x68(%rsp)
  8264d8:	movsd  %xmm2,0x70(%rsp)
  8264de:	movsd  %xmm5,0x78(%rsp)
  8264e4:	movsd  %xmm3,0x80(%rsp)
  8264ed:	movups %xmm8,0x88(%rsp)
  8264f6:	cvtss2sd %xmm0,%xmm0
  8264fa:	movsd  %xmm0,0x8(%rsp)
  826500:	xorps  %xmm0,%xmm0
  826503:	cvtss2sd %xmm1,%xmm0
  826507:	movsd  %xmm0,(%rsp)
  82650c:	xor    %ebp,%ebp
  82650e:	xor    %eax,%eax
  826510:	lea    (%rax,%rax,4),%rax
  826514:	lea    (%r15,%rax,8),%rdi
  826518:	movsd  0x18(%r15,%rax,8),%xmm6
  82651f:	movsd  0x20(%r15,%rax,8),%xmm7
  826526:	movsd  0x28(%rsp),%xmm0
  82652c:	movsd  0x20(%rsp),%xmm1
  826532:	movsd  0x18(%rsp),%xmm2
  826538:	movsd  0x10(%rsp),%xmm3
  82653e:	movsd  0x8(%rsp),%xmm4
  826544:	movsd  (%rsp),%xmm5
  826549:	call   825990 <gpui_gpu::renderer::coverage::axis>
  82654e:	cmp    $0x1,%al
  826550:	jne    8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826556:	mov    $0x1,%eax
  82655b:	test   $0x1,%bpl
  82655f:	mov    $0x1,%bpl
  826562:	je     826510 <gpui_gpu::renderer::coverage::whole+0x500>
  826564:	mov    $0x1,%edx
  826569:	test   $0x1,%r12b
  82656d:	mov    $0x1,%r12b
  826570:	mov    %rbx,%rcx
  826573:	movsd  -0x77673c(%rip),%xmm8        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82657c:	je     82643f <gpui_gpu::renderer::coverage::whole+0x42f>
  826582:	mov    $0x1,%al
  826584:	jmp    8260ce <gpui_gpu::renderer::coverage::whole+0xbe>
  826589:	lea    0x6093d0(%rip),%rdx        # e2f960 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x18>
  826590:	mov    $0x6,%esi
  826595:	call   *0x65abed(%rip)        # e81188 <_DYNAMIC+0x4f8>
  82659b:	add    $0x2,%rdi
  82659f:	lea    0x6093d2(%rip),%rdx        # e2f978 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x30>
  8265a6:	mov    $0x6,%esi
  8265ab:	call   *0x65abd7(%rip)        # e81188 <_DYNAMIC+0x4f8>
  8265b1:	lea    0x6093d8(%rip),%rdx        # e2f990 <anon.627181f3f10afc1966f799818b5539e5.20.llvm.1634448222410874261+0x48>
  8265b8:	mov    $0x6,%esi
  8265bd:	mov    %rax,%rdi
  8265c0:	call   *0x65abc2(%rip)        # e81188 <_DYNAMIC+0x4f8>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826d90 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  826d90:	push   %rbp
  826d91:	push   %r15
  826d93:	push   %r14
  826d95:	push   %r13
  826d97:	push   %r12
  826d99:	push   %rbx
  826d9a:	sub    $0x38,%rsp
  826d9e:	mov    %rcx,%r15
  826da1:	mov    %rdx,%r12
  826da4:	mov    %rsi,%r14
  826da7:	mov    %rdi,%rbx
  826daa:	lea    0x20(%rsi),%r13
  826dae:	mov    %r13,%rdi
  826db1:	mov    %rdx,%rsi
  826db4:	call   825110 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  826db9:	cmpq   $0x0,0x10(%r14)
  826dbe:	je     826f41 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  826dc4:	mov    (%r14),%r11
  826dc7:	mov    0x8(%r14),%rsi
  826dcb:	mov    %rax,%rdx
  826dce:	shr    $0x39,%rdx
  826dd2:	movd   %edx,%xmm0
  826dd6:	punpcklbw %xmm0,%xmm0
  826dda:	pshuflw $0x0,%xmm0,%xmm0
  826ddf:	pshufd $0x44,%xmm0,%xmm0
  826de4:	mov    (%r12),%rcx
  826de8:	mov    %rcx,0x8(%rsp)
  826ded:	movzwl 0xc(%r12),%r9d
  826df3:	mov    0x8(%r12),%r10d
  826df8:	xor    %r13d,%r13d
  826dfb:	pcmpeqd %xmm1,%xmm1
  826dff:	xor    %r8d,%r8d
  826e02:	and    %rsi,%rax
  826e05:	movdqu (%r11,%rax,1),%xmm2
  826e0b:	movdqa %xmm2,%xmm3
  826e0f:	pcmpeqb %xmm0,%xmm3
  826e13:	pmovmskb %xmm3,%ebp
  826e17:	test   %ebp,%ebp
  826e19:	je     826e60 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  826e1b:	mov    %r8,(%rsp)
  826e1f:	mov    %r15,%r8
  826e22:	tzcnt  %ebp,%r15d
  826e27:	add    %rax,%r15
  826e2a:	and    %rsi,%r15
  826e2d:	shl    $0x5,%r15
  826e31:	mov    %r11,%rcx
  826e34:	sub    %r15,%rcx
  826e37:	mov    0x8(%rsp),%r15
  826e3c:	cmp    -0x20(%rcx),%r15
  826e40:	jne    826e4f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  826e42:	cmp    -0x14(%rcx),%r9w
  826e47:	jne    826e4f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  826e49:	cmp    -0x18(%rcx),%r10d
  826e4d:	je     826e9f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  826e4f:	lea    -0x1(%rbp),%ecx
  826e52:	and    %bp,%cx
  826e55:	mov    %ecx,%ebp
  826e57:	mov    %r8,%r15
  826e5a:	mov    (%rsp),%r8
  826e5e:	jne    826e1f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  826e60:	cmp    $0x1,%r13
  826e64:	je     826e78 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  826e66:	pmovmskb %xmm2,%ecx
  826e6a:	test   %ecx,%ecx
  826e6c:	je     826e8c <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  826e6e:	tzcnt  %ecx,%edi
  826e72:	add    %rax,%rdi
  826e75:	and    %rsi,%rdi
  826e78:	pcmpeqb %xmm1,%xmm2
  826e7c:	pmovmskb %xmm2,%ecx
  826e80:	test   %ecx,%ecx
  826e82:	jne    826eb6 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  826e84:	mov    $0x1,%r13d
  826e8a:	jmp    826e8f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  826e8c:	xor    %r13d,%r13d
  826e8f:	add    %r8,%rax
  826e92:	add    $0x10,%rax
  826e96:	add    $0x10,%r8
  826e9a:	jmp    826e02 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  826e9f:	movups -0x10(%rcx),%xmm0
  826ea3:	movups %xmm0,0x4(%rbx)
  826ea7:	movups (%r8),%xmm0
  826eab:	movups %xmm0,-0x10(%rcx)
  826eaf:	mov    $0x1,%eax
  826eb4:	jmp    826f2d <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  826eb6:	movzbl (%r11,%rdi,1),%eax
  826ebb:	test   %al,%al
  826ebd:	jns    826f62 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  826ec3:	movups (%r12),%xmm0
  826ec8:	movaps %xmm0,0x10(%rsp)
  826ecd:	movups (%r15),%xmm0
  826ed1:	movaps %xmm0,0x20(%rsp)
  826ed6:	and    $0x1,%al
  826ed8:	lea    -0x10(%rdi),%rcx
  826edc:	and    %rsi,%rcx
  826edf:	mov    %dl,(%r11,%rdi,1)
  826ee3:	mov    %dl,0x10(%r11,%rcx,1)
  826ee8:	movzbl %al,%eax
  826eeb:	movd   %eax,%xmm0
  826eef:	shufpd $0x2,-0x77bc98(%rip),%xmm0        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  826ef8:	movdqu 0x10(%r14),%xmm1
  826efe:	psubq  %xmm0,%xmm1
  826f02:	movdqu %xmm1,0x10(%r14)
  826f08:	shl    $0x5,%rdi
  826f0c:	mov    %r11,%rax
  826f0f:	sub    %rdi,%rax
  826f12:	neg    %rdi
  826f15:	movaps 0x10(%rsp),%xmm0
  826f1a:	movdqa 0x20(%rsp),%xmm1
  826f20:	movups %xmm0,-0x20(%r11,%rdi,1)
  826f26:	movdqu %xmm1,-0x10(%rax)
  826f2b:	xor    %eax,%eax
  826f2d:	mov    %eax,(%rbx)
  826f2f:	mov    %rbx,%rax
  826f32:	add    $0x38,%rsp
  826f36:	pop    %rbx
  826f37:	pop    %r12
  826f39:	pop    %r13
  826f3b:	pop    %r14
  826f3d:	pop    %r15
  826f3f:	pop    %rbp
  826f40:	ret
  826f41:	mov    $0x1,%esi
  826f46:	mov    %r14,%rdi
  826f49:	mov    %r13,%rdx
  826f4c:	mov    $0x1,%ecx
  826f51:	mov    %rax,%r13
  826f54:	call   *0x65a3ce(%rip)        # e81328 <_DYNAMIC+0x698>
  826f5a:	mov    %r13,%rax
  826f5d:	jmp    826dc4 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  826f62:	movdqa (%r11),%xmm0
  826f67:	pmovmskb %xmm0,%eax
  826f6b:	tzcnt  %eax,%edi
  826f6f:	movzbl (%r11,%rdi,1),%eax
  826f74:	jmp    826ec3 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000826f80 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  826f80:	push   %rbp
  826f81:	push   %r15
  826f83:	push   %r14
  826f85:	push   %r13
  826f87:	push   %r12
  826f89:	push   %rbx
  826f8a:	push   %rax
  826f8b:	mov    %r8d,%ebp
  826f8e:	mov    %ecx,%r14d
  826f91:	mov    %rdx,%r15
  826f94:	mov    %rsi,%r12
  826f97:	mov    %rdi,%rbx
  826f9a:	mov    %rdx,(%rsp)
  826f9e:	lea    0x20(%rsi),%r13
  826fa2:	mov    %rsp,%rsi
  826fa5:	mov    %r13,%rdi
  826fa8:	call   8252b0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  826fad:	cmpq   $0x0,0x10(%r12)
  826fb3:	je     8270f6 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  826fb9:	mov    (%r12),%rcx
  826fbd:	mov    0x8(%r12),%rsi
  826fc2:	mov    %rax,%rdx
  826fc5:	shr    $0x39,%rdx
  826fc9:	movd   %edx,%xmm0
  826fcd:	punpcklbw %xmm0,%xmm0
  826fd1:	pshuflw $0x0,%xmm0,%xmm0
  826fd6:	pshufd $0x44,%xmm0,%xmm0
  826fdb:	xor    %r9d,%r9d
  826fde:	pcmpeqd %xmm1,%xmm1
  826fe2:	xor    %r8d,%r8d
  826fe5:	and    %rsi,%rax
  826fe8:	movdqu (%rcx,%rax,1),%xmm2
  826fed:	movdqa %xmm2,%xmm3
  826ff1:	pcmpeqb %xmm0,%xmm3
  826ff5:	pmovmskb %xmm3,%r10d
  826ffa:	test   %r10d,%r10d
  826ffd:	je     827030 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  826fff:	tzcnt  %r10d,%r13d
  827004:	add    %rax,%r13
  827007:	and    %rsi,%r13
  82700a:	shl    $0x4,%r13
  82700e:	mov    %rcx,%r11
  827011:	sub    %r13,%r11
  827014:	cmp    -0x10(%r11),%r15
  827018:	je     827071 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  82701a:	lea    -0x1(%r10),%r11d
  82701e:	and    %r10w,%r11w
  827022:	mov    %r11d,%r10d
  827025:	jne    826fff <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  827027:	nopw   0x0(%rax,%rax,1)
  827030:	cmp    $0x1,%r9
  827034:	je     827048 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  827036:	pmovmskb %xmm2,%edi
  82703a:	test   %edi,%edi
  82703c:	je     82705e <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  82703e:	tzcnt  %edi,%edi
  827042:	add    %rax,%rdi
  827045:	and    %rsi,%rdi
  827048:	pcmpeqb %xmm1,%xmm2
  82704c:	pmovmskb %xmm2,%r9d
  827051:	test   %r9d,%r9d
  827054:	jne    827088 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  827056:	mov    $0x1,%r9d
  82705c:	jmp    827061 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  82705e:	xor    %r9d,%r9d
  827061:	add    %r8,%rax
  827064:	add    $0x10,%rax
  827068:	add    $0x10,%r8
  82706c:	jmp    826fe5 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  827071:	mov    -0x8(%r11),%rax
  827075:	mov    %r14d,-0x8(%r11)
  827079:	mov    %ebp,-0x4(%r11)
  82707d:	mov    %rax,0x4(%rbx)
  827081:	mov    $0x1,%eax
  827086:	jmp    8270e2 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  827088:	movzbl (%rcx,%rdi,1),%eax
  82708c:	test   %al,%al
  82708e:	jns    827117 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  827094:	and    $0x1,%al
  827096:	lea    -0x10(%rdi),%r8
  82709a:	and    %rsi,%r8
  82709d:	mov    %dl,(%rcx,%rdi,1)
  8270a0:	mov    %dl,0x10(%rcx,%r8,1)
  8270a5:	movdqu 0x10(%r12),%xmm0
  8270ac:	movzbl %al,%eax
  8270af:	movd   %eax,%xmm1
  8270b3:	shufpd $0x2,-0x77be5c(%rip),%xmm1        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  8270bc:	psubq  %xmm1,%xmm0
  8270c0:	movdqu %xmm0,0x10(%r12)
  8270c7:	shl    $0x4,%rdi
  8270cb:	mov    %rcx,%rax
  8270ce:	sub    %rdi,%rax
  8270d1:	neg    %rdi
  8270d4:	mov    %r15,-0x10(%rcx,%rdi,1)
  8270d9:	mov    %r14d,-0x8(%rax)
  8270dd:	mov    %ebp,-0x4(%rax)
  8270e0:	xor    %eax,%eax
  8270e2:	mov    %eax,(%rbx)
  8270e4:	mov    %rbx,%rax
  8270e7:	add    $0x8,%rsp
  8270eb:	pop    %rbx
  8270ec:	pop    %r12
  8270ee:	pop    %r13
  8270f0:	pop    %r14
  8270f2:	pop    %r15
  8270f4:	pop    %rbp
  8270f5:	ret
  8270f6:	mov    $0x1,%esi
  8270fb:	mov    %r12,%rdi
  8270fe:	mov    %r13,%rdx
  827101:	mov    $0x1,%ecx
  827106:	mov    %rax,%r13
  827109:	call   *0x65a221(%rip)        # e81330 <_DYNAMIC+0x6a0>
  82710f:	mov    %r13,%rax
  827112:	jmp    826fb9 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  827117:	movdqa (%rcx),%xmm0
  82711b:	pmovmskb %xmm0,%eax
  82711f:	tzcnt  %eax,%edi
  827123:	movzbl (%rcx,%rdi,1),%eax
  827127:	jmp    827094 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>
