
FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4579 frame=1016

/tmp/gpui-coverage-setup-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008204e0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  8204e0:	push   %rbp
  8204e1:	push   %r15
  8204e3:	push   %r14
  8204e5:	push   %r13
  8204e7:	push   %r12
  8204e9:	push   %rbx
  8204ea:	sub    $0x3c8,%rsp
  8204f1:	movss  0x88(%rdx),%xmm3
  8204f9:	movss  -0x7714e5(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820501:	movaps %xmm3,%xmm1
  820504:	subss  %xmm0,%xmm1
  820508:	cvttss2si %xmm1,%rax
  82050d:	cvttss2si %xmm3,%r10
  820512:	mov    %r10,%rbp
  820515:	sar    $0x3f,%rbp
  820519:	and    %rax,%rbp
  82051c:	or     %r10,%rbp
  82051f:	xor    %eax,%eax
  820521:	xorps  %xmm1,%xmm1
  820524:	ucomiss %xmm1,%xmm3
  820527:	cmovb  %rax,%rbp
  82052b:	movss  0x90(%rdx),%xmm4
  820533:	movss  -0x77151b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82053b:	ucomiss %xmm2,%xmm3
  82053e:	mov    $0xffffffffffffffff,%r14
  820545:	cmova  %r14,%rbp
  820549:	movaps %xmm4,%xmm3
  82054c:	subss  %xmm0,%xmm3
  820550:	cvttss2si %xmm3,%r10
  820555:	cvttss2si %xmm4,%r11
  82055a:	mov    %r11,%rbx
  82055d:	sar    $0x3f,%rbx
  820561:	and    %r10,%rbx
  820564:	or     %r11,%rbx
  820567:	ucomiss %xmm1,%xmm4
  82056a:	cmovb  %rax,%rbx
  82056e:	ucomiss %xmm2,%xmm4
  820571:	cmova  %r14,%rbx
  820575:	movss  0x8c(%rdx),%xmm3
  82057d:	add    %rbp,%rbx
  820580:	dec    %rbx
  820583:	shr    $0x4,%rbx
  820587:	shr    $0x4,%rbp
  82058b:	mov    %rbx,%r13
  82058e:	sub    %rbp,%r13
  820591:	inc    %r13
  820594:	movaps %xmm3,%xmm4
  820597:	subss  %xmm0,%xmm4
  82059b:	cvttss2si %xmm4,%r11
  8205a0:	cvttss2si %xmm3,%r10
  8205a5:	mov    %r10,%r15
  8205a8:	sar    $0x3f,%r15
  8205ac:	and    %r11,%r15
  8205af:	or     %r10,%r15
  8205b2:	ucomiss %xmm1,%xmm3
  8205b5:	cmovb  %rax,%r15
  8205b9:	ucomiss %xmm2,%xmm3
  8205bc:	movss  0x94(%rdx),%xmm3
  8205c4:	cmova  %r14,%r15
  8205c8:	movaps %xmm3,%xmm4
  8205cb:	subss  %xmm0,%xmm4
  8205cf:	cvttss2si %xmm4,%r12
  8205d4:	cvttss2si %xmm3,%r10
  8205d9:	mov    %r10,%r11
  8205dc:	sar    $0x3f,%r11
  8205e0:	and    %r12,%r11
  8205e3:	or     %r10,%r11
  8205e6:	ucomiss %xmm1,%xmm3
  8205e9:	cmovb  %rax,%r11
  8205ed:	ucomiss %xmm2,%xmm3
  8205f0:	cmova  %r14,%r11
  8205f4:	mov    %r15,%r14
  8205f7:	lea    (%r15,%r11,1),%r10
  8205fb:	dec    %r10
  8205fe:	shr    $0x4,%r10
  820602:	shr    $0x4,%r14
  820606:	mov    %r10,%r12
  820609:	sub    %r14,%r12
  82060c:	inc    %r12
  82060f:	imul   %r13,%r12
  820613:	mov    0x418(%rsp),%r11
  82061b:	add    %r12,%r11
  82061e:	setb   %al
  820621:	cmp    $0x400001,%r11
  820628:	setae  %r15b
  82062c:	or     %al,%r15b
  82062f:	mov    $0x6,%eax
  820634:	jne    820728 <<gpui_gpu::renderer::RendererState>::bin_draw+0x248>
  82063a:	mov    %r12,0x1f8(%rsp)
  820642:	mov    %r11,0x1a0(%rsp)
  82064a:	mov    %rdi,0x1a8(%rsp)
  820652:	cmpb   $0x0,(%rdx)
  820655:	sete   %al
  820658:	and    0x340(%rsi),%al
  82065e:	xor    %r15d,%r15d
  820661:	cmp    $0x1,%al
  820663:	jne    8206ea <<gpui_gpu::renderer::RendererState>::bin_draw+0x20a>
  820669:	movss  0xa4(%rdx),%xmm0
  820671:	ucomiss -0x771898(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  820678:	jne    8206ea <<gpui_gpu::renderer::RendererState>::bin_draw+0x20a>
  82067a:	jp     8206ea <<gpui_gpu::renderer::RendererState>::bin_draw+0x20a>
  82067c:	mov    0x98(%rdx),%edi
  820682:	test   %edi,%edi
  820684:	jns    820696 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b6>
  820686:	and    $0x7f800000,%edi
  82068c:	dec    %edi
  82068e:	cmp    $0x7f7fffff,%edi
  820694:	jae    8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  820696:	mov    0x9c(%rdx),%edi
  82069c:	test   %edi,%edi
  82069e:	jns    8206b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d0>
  8206a0:	and    $0x7f800000,%edi
  8206a6:	dec    %edi
  8206a8:	cmp    $0x7f7ffffe,%edi
  8206ae:	ja     8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8206b0:	mov    0xa0(%rdx),%edi
  8206b6:	test   %edi,%edi
  8206b8:	jns    8206ca <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ea>
  8206ba:	and    $0x7f800000,%edi
  8206c0:	dec    %edi
  8206c2:	cmp    $0x7f7ffffe,%edi
  8206c8:	ja     8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8206ca:	movd   %xmm0,%edi
  8206ce:	test   %edi,%edi
  8206d0:	jns    8206e2 <<gpui_gpu::renderer::RendererState>::bin_draw+0x202>
  8206d2:	and    $0x7f800000,%edi
  8206d8:	dec    %edi
  8206da:	cmp    $0x7f7ffffe,%edi
  8206e0:	ja     8206e7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x207>
  8206e2:	mov    $0x1,%r15b
  8206e5:	jmp    8206ea <<gpui_gpu::renderer::RendererState>::bin_draw+0x20a>
  8206e7:	xor    %r15d,%r15d
  8206ea:	mov    %rcx,0xe0(%rsp)
  8206f2:	mov    %r8d,0xbc(%rsp)
  8206fa:	mov    %r9,0xa8(%rsp)
  820702:	mov    %rdx,0xe8(%rsp)
  82070a:	cmp    %r14,%r10
  82070d:	jae    82073c <<gpui_gpu::renderer::RendererState>::bin_draw+0x25c>
  82070f:	mov    0x1a8(%rsp),%rdi
  820717:	mov    0x1a0(%rsp),%rax
  82071f:	mov    %rax,0x8(%rdi)
  820723:	mov    $0xffffffff,%eax
  820728:	mov    %eax,(%rdi)
  82072a:	add    $0x3c8,%rsp
  820731:	pop    %rbx
  820732:	pop    %r12
  820734:	pop    %r13
  820736:	pop    %r14
  820738:	pop    %r15
  82073a:	pop    %rbp
  82073b:	ret
  82073c:	cmp    %rbp,%rbx
  82073f:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  820741:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820750:	mov    %r14,%rax
  820753:	cmp    %r10,%r14
  820756:	adc    $0x0,%r14
  82075a:	cmp    %r10,%rax
  82075d:	jae    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  82075f:	cmp    %r10,%r14
  820762:	jbe    820750 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  820764:	jmp    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  820766:	mov    0x400(%rsp),%r13
  82076e:	mov    0x20(%rsi),%r9
  820772:	mov    0x28(%rsi),%r8
  820776:	test   %al,%al
  820778:	je     821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1120>
  82077e:	mov    0xe0(%rsp),%rax
  820786:	movd   %eax,%xmm0
  82078a:	shr    $0x20,%rax
  82078e:	mov    0xe8(%rsp),%rcx
  820796:	movss  0x78(%rcx),%xmm1
  82079b:	movss  0x80(%rcx),%xmm2
  8207a3:	cvtss2sd %xmm1,%xmm12
  8207a8:	movss  0x7c(%rcx),%xmm1
  8207ad:	xorps  %xmm3,%xmm3
  8207b0:	cvtss2sd %xmm1,%xmm3
  8207b4:	cvtss2sd %xmm2,%xmm2
  8207b8:	movss  0x84(%rcx),%xmm1
  8207c0:	addsd  %xmm12,%xmm2
  8207c5:	movsd  %xmm2,0x1e0(%rsp)
  8207ce:	cvtss2sd %xmm1,%xmm1
  8207d2:	movsd  %xmm3,0x1f0(%rsp)
  8207db:	addsd  %xmm3,%xmm1
  8207df:	movsd  %xmm1,0x1d0(%rsp)
  8207e8:	movsd  0x48(%rcx),%xmm4
  8207ed:	movsd  0x58(%rcx),%xmm5
  8207f2:	movss  0x38(%rcx),%xmm1
  8207f7:	movss  0x3c(%rcx),%xmm2
  8207fc:	movss  0x40(%rcx),%xmm3
  820801:	cvtss2sd %xmm1,%xmm6
  820805:	movss  0x44(%rcx),%xmm1
  82080a:	cvtss2sd %xmm3,%xmm3
  82080e:	movaps -0x7759e5(%rip),%xmm7        # aae30 <GCC_except_table0+0x7c>
  820815:	movaps %xmm6,0x90(%rsp)
  82081d:	andps  %xmm7,%xmm6
  820820:	movaps %xmm6,0x80(%rsp)
  820828:	movaps %xmm3,0x60(%rsp)
  82082d:	andps  %xmm7,%xmm3
  820830:	movaps %xmm3,0x70(%rsp)
  820835:	cvtss2sd %xmm0,%xmm0
  820839:	movsd  %xmm0,0x18(%rsp)
  82083f:	movaps %xmm4,%xmm0
  820842:	andps  %xmm7,%xmm0
  820845:	movaps %xmm0,0x2a0(%rsp)
  82084d:	movaps %xmm5,%xmm0
  820850:	andps  %xmm7,%xmm0
  820853:	movaps %xmm0,0x280(%rsp)
  82085b:	xorps  %xmm0,%xmm0
  82085e:	cvtss2sd %xmm2,%xmm0
  820862:	cvtss2sd %xmm1,%xmm1
  820866:	movsd  0x68(%rcx),%xmm2
  82086b:	movaps %xmm2,%xmm3
  82086e:	andps  %xmm7,%xmm3
  820871:	movaps %xmm3,0x130(%rsp)
  820879:	movaps %xmm0,0x50(%rsp)
  82087e:	andps  %xmm7,%xmm0
  820881:	movaps %xmm0,0x40(%rsp)
  820886:	movaps %xmm1,0x20(%rsp)
  82088b:	andps  %xmm7,%xmm1
  82088e:	movaps %xmm1,0x30(%rsp)
  820893:	movd   %eax,%xmm0
  820897:	cvtss2sd %xmm0,%xmm0
  82089b:	movsd  %xmm0,0x10(%rsp)
  8208a1:	movsd  0x50(%rcx),%xmm1
  8208a6:	movaps %xmm1,%xmm0
  8208a9:	andps  %xmm7,%xmm0
  8208ac:	movaps %xmm0,0x220(%rsp)
  8208b4:	movsd  0x60(%rcx),%xmm3
  8208b9:	movaps %xmm3,%xmm0
  8208bc:	andps  %xmm7,%xmm0
  8208bf:	movaps %xmm0,0x200(%rsp)
  8208c7:	movsd  0x70(%rcx),%xmm6
  8208cc:	andps  %xmm6,%xmm7
  8208cf:	movaps %xmm7,0x100(%rsp)
  8208d7:	mov    0x58(%rsi),%rax
  8208db:	mov    %rax,0xd8(%rsp)
  8208e3:	mov    0x50(%rsi),%rax
  8208e7:	mov    %rax,0x1d8(%rsp)
  8208ef:	movaps %xmm4,0x2b0(%rsp)
  8208f7:	movaps %xmm4,%xmm0
  8208fa:	movaps %xmm5,0x290(%rsp)
  820902:	movlhps %xmm5,%xmm0
  820905:	cvtpd2ps %xmm0,%xmm0
  820909:	movaps %xmm1,0x230(%rsp)
  820911:	cvtsd2ss %xmm1,%xmm1
  820915:	cvtss2sd %xmm1,%xmm1
  820919:	cvtps2pd %xmm0,%xmm4
  82091c:	movaps %xmm3,0x210(%rsp)
  820924:	xorps  %xmm0,%xmm0
  820927:	cvtsd2ss %xmm3,%xmm0
  82092b:	xorps  %xmm3,%xmm3
  82092e:	cvtss2sd %xmm0,%xmm3
  820932:	movaps %xmm2,0x140(%rsp)
  82093a:	xorps  %xmm0,%xmm0
  82093d:	cvtsd2ss %xmm2,%xmm0
  820941:	xorps  %xmm2,%xmm2
  820944:	cvtss2sd %xmm0,%xmm2
  820948:	movaps %xmm6,0xf0(%rsp)
  820950:	xorps  %xmm0,%xmm0
  820953:	cvtsd2ss %xmm6,%xmm0
  820957:	cvtss2sd %xmm0,%xmm0
  82095b:	mov    0xa8(%rsp),%rax
  820963:	inc    %eax
  820965:	mov    %rax,0xa8(%rsp)
  82096d:	movaps -0x775b44(%rip),%xmm5        # aae30 <GCC_except_table0+0x7c>
  820974:	movaps %xmm4,%xmm6
  820977:	andps  %xmm5,%xmm6
  82097a:	movaps %xmm2,0x160(%rsp)
  820982:	andps  %xmm5,%xmm2
  820985:	movaps %xmm2,0x150(%rsp)
  82098d:	movaps %xmm1,0x270(%rsp)
  820995:	andps  %xmm5,%xmm1
  820998:	movaps %xmm1,0x260(%rsp)
  8209a0:	movaps %xmm3,0x250(%rsp)
  8209a8:	andps  %xmm5,%xmm3
  8209ab:	movaps %xmm3,0x240(%rsp)
  8209b3:	movaps %xmm0,0x120(%rsp)
  8209bb:	andps  %xmm0,%xmm5
  8209be:	movaps %xmm5,0x110(%rsp)
  8209c6:	movaps %xmm4,0x2d0(%rsp)
  8209ce:	movhlps %xmm4,%xmm4
  8209d1:	movaps %xmm4,0x300(%rsp)
  8209d9:	mov    $0x2,%cl
  8209db:	xor    %edx,%edx
  8209dd:	mov    %r14,%rax
  8209e0:	movaps %xmm6,0x2c0(%rsp)
  8209e8:	pshufd $0xee,%xmm6,%xmm0
  8209ed:	movdqa %xmm0,0x2f0(%rsp)
  8209f6:	movsd  %xmm12,0x8(%rsp)
  8209fd:	mov    %rbp,0x1b8(%rsp)
  820a05:	mov    %r10,0x1b0(%rsp)
  820a0d:	mov    %rbx,0x1e8(%rsp)
  820a15:	data16 cs nopw 0x0(%rax,%rax,1)
  820a20:	cmp    %r10,%r14
  820a23:	adc    $0x0,%rax
  820a27:	mov    %rax,0x1c0(%rsp)
  820a2f:	mov    %r14,0x1c8(%rsp)
  820a37:	imul   %r13,%r14
  820a3b:	mov    %rbp,%r11
  820a3e:	jmp    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820a40:	cmp    %r8,%r12
  820a43:	jae    821665 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1185>
  820a49:	incl   0x4(%r9,%r12,8)
  820a4e:	mov    $0x1,%dl
  820a50:	cmp    %rbx,%r11
  820a53:	jb     820c53 <<gpui_gpu::renderer::RendererState>::bin_draw+0x773>
  820a59:	jmp    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  820a5e:	xchg   %ax,%ax
  820a60:	cmp    %rbx,%r11
  820a63:	adc    $0x0,%rbp
  820a67:	lea    (%r11,%r14,1),%r12
  820a6b:	test   %r15b,%r15b
  820a6e:	jne    820a85 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a5>
  820a70:	cmp    %r8,%r12
  820a73:	jae    821685 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11a5>
  820a79:	testb  $0x40,0x7(%r9,%r12,8)
  820a7f:	je     820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820a85:	cmpq   $0x2,0x1f8(%rsp)
  820a8e:	setae  %al
  820a91:	and    %dl,%al
  820a93:	cmp    $0x1,%al
  820a95:	jne    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6b0>
  820a9b:	cmp    $0x2,%cl
  820a9e:	jne    820b2f <<gpui_gpu::renderer::RendererState>::bin_draw+0x64f>
  820aa4:	mov    $0xa8,%edx
  820aa9:	lea    0x320(%rsp),%rdi
  820ab1:	mov    %r11,0xb0(%rsp)
  820ab9:	mov    0xe8(%rsp),%rsi
  820ac1:	mov    %r15d,%ebx
  820ac4:	mov    %r8,%r15
  820ac7:	mov    %rbp,0xc0(%rsp)
  820acf:	mov    %r14,%rbp
  820ad2:	mov    %r9,%r14
  820ad5:	call   *0x660455(%rip)        # e80f30 <memcpy@GLIBC_2.14>
  820adb:	lea    0x320(%rsp),%rdi
  820ae3:	mov    0xe0(%rsp),%rsi
  820aeb:	mov    %r13,%rdx
  820aee:	mov    0x408(%rsp),%ecx
  820af5:	mov    0x410(%rsp),%r8d
  820afd:	call   826010 <gpui_gpu::renderer::coverage::whole>
  820b02:	mov    0xb0(%rsp),%r11
  820b0a:	movsd  0x8(%rsp),%xmm12
  820b11:	mov    %r14,%r9
  820b14:	mov    %rbp,%r14
  820b17:	mov    0xc0(%rsp),%rbp
  820b1f:	mov    %r15,%r8
  820b22:	mov    %ebx,%r15d
  820b25:	mov    0x1e8(%rsp),%rbx
  820b2d:	mov    %eax,%ecx
  820b2f:	test   $0x1,%cl
  820b32:	mov    $0x1,%cl
  820b34:	je     820b8e <<gpui_gpu::renderer::RendererState>::bin_draw+0x6ae>
  820b36:	test   %r15b,%r15b
  820b39:	je     820a40 <<gpui_gpu::renderer::RendererState>::bin_draw+0x560>
  820b3f:	cmp    %r8,%r12
  820b42:	jae    8216b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11d0>
  820b48:	mov    0xbc(%rsp),%eax
  820b4f:	mov    %eax,(%r9,%r12,8)
  820b53:	movl   $0x40000001,0x4(%r9,%r12,8)
  820b5c:	cmp    0xd8(%rsp),%r12
  820b64:	jae    821698 <<gpui_gpu::renderer::RendererState>::bin_draw+0x11b8>
  820b6a:	mov    0xa8(%rsp),%rax
  820b72:	mov    0x1d8(%rsp),%rdx
  820b7a:	mov    %eax,(%rdx,%r12,4)
  820b7e:	mov    $0x1,%dl
  820b80:	cmp    %rbx,%r11
  820b83:	jb     820c53 <<gpui_gpu::renderer::RendererState>::bin_draw+0x773>
  820b89:	jmp    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  820b8e:	xor    %ecx,%ecx
  820b90:	test   %r13,%r13
  820b93:	je     821678 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1198>
  820b99:	mov    %r12,%rax
  820b9c:	shr    $0x20,%rax
  820ba0:	je     820bb0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6d0>
  820ba2:	mov    %r12,%rax
  820ba5:	xor    %edx,%edx
  820ba7:	div    %r13
  820baa:	jmp    820bb8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x6d8>
  820bac:	nopl   0x0(%rax)
  820bb0:	mov    %r12d,%eax
  820bb3:	xor    %edx,%edx
  820bb5:	div    %r13d
  820bb8:	shl    $0x4,%edx
  820bbb:	shl    $0x4,%eax
  820bbe:	lea    0x10(%rdx),%esi
  820bc1:	mov    0x408(%rsp),%edi
  820bc8:	cmp    %esi,%edi
  820bca:	cmovb  %edi,%esi
  820bcd:	lea    0x10(%rax),%edi
  820bd0:	mov    0x410(%rsp),%r10d
  820bd8:	cmp    %edi,%r10d
  820bdb:	cmovb  %r10d,%edi
  820bdf:	xorps  %xmm2,%xmm2
  820be2:	cvtsi2sd %edx,%xmm2
  820be6:	mov    $0x1,%dl
  820be8:	ucomisd %xmm2,%xmm12
  820bed:	ja     820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820bef:	mov    %eax,%eax
  820bf1:	xorps  %xmm3,%xmm3
  820bf4:	cvtsi2sd %rax,%xmm3
  820bf9:	movsd  0x1f0(%rsp),%xmm0
  820c02:	ucomisd %xmm3,%xmm0
  820c06:	ja     820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820c08:	xorps  %xmm0,%xmm0
  820c0b:	cvtsi2sd %esi,%xmm0
  820c0f:	ucomisd 0x1e0(%rsp),%xmm0
  820c18:	ja     820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820c1a:	xorps  %xmm1,%xmm1
  820c1d:	cvtsi2sd %edi,%xmm1
  820c21:	ucomisd 0x1d0(%rsp),%xmm1
  820c2a:	jbe    820c64 <<gpui_gpu::renderer::RendererState>::bin_draw+0x784>
  820c2c:	nopl   0x0(%rax)
  820c30:	cmp    %r8,%r12
  820c33:	jae    821665 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1185>
  820c39:	mov    0x4(%r9,%r12,8),%eax
  820c3e:	inc    %eax
  820c40:	and    $0xbfffffff,%eax
  820c45:	mov    %eax,0x4(%r9,%r12,8)
  820c4a:	cmp    %rbx,%r11
  820c4d:	jae    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  820c53:	mov    %rbp,%r11
  820c56:	cmp    %rbx,%rbp
  820c59:	jbe    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x580>
  820c5f:	jmp    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  820c64:	unpcklpd %xmm3,%xmm2
  820c68:	addpd  -0x773b30(%rip),%xmm2        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820c70:	movapd %xmm2,%xmm3
  820c74:	mulpd  0x2d0(%rsp),%xmm3
  820c7d:	movapd %xmm3,%xmm11
  820c82:	unpckhpd %xmm3,%xmm11
  820c87:	movapd %xmm3,%xmm5
  820c8b:	addsd  %xmm11,%xmm5
  820c90:	addsd  0x160(%rsp),%xmm5
  820c99:	subsd  0x90(%rsp),%xmm5
  820ca2:	movapd 0x2c0(%rsp),%xmm8
  820cac:	mulpd  %xmm2,%xmm8
  820cb1:	movapd %xmm8,%xmm4
  820cb6:	unpckhpd %xmm8,%xmm4
  820cbb:	movapd %xmm8,%xmm6
  820cc0:	addsd  %xmm4,%xmm6
  820cc4:	addsd  0x150(%rsp),%xmm6
  820ccd:	addsd  0x80(%rsp),%xmm6
  820cd6:	addsd  0x70(%rsp),%xmm6
  820cdc:	addsd  -0x771404(%rip),%xmm6        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ce4:	mulsd  -0x77148c(%rip),%xmm6        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cec:	addsd  0x18(%rsp),%xmm6
  820cf2:	ucomisd %xmm5,%xmm6
  820cf6:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820cfc:	movapd 0x60(%rsp),%xmm7
  820d02:	subsd  %xmm5,%xmm7
  820d06:	ucomisd %xmm7,%xmm6
  820d0a:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820d10:	movapd %xmm2,%xmm13
  820d15:	unpckhpd %xmm2,%xmm13
  820d1a:	movapd 0x290(%rsp),%xmm15
  820d24:	mulsd  %xmm13,%xmm15
  820d29:	movapd 0x280(%rsp),%xmm14
  820d33:	mulsd  %xmm13,%xmm14
  820d38:	movapd 0x2b0(%rsp),%xmm5
  820d41:	mulsd  %xmm2,%xmm5
  820d45:	movapd %xmm5,%xmm6
  820d49:	addsd  %xmm15,%xmm6
  820d4e:	addsd  0x140(%rsp),%xmm6
  820d57:	subsd  0x90(%rsp),%xmm6
  820d60:	movapd 0x2a0(%rsp),%xmm7
  820d69:	mulsd  %xmm2,%xmm7
  820d6d:	movapd %xmm7,%xmm9
  820d72:	addsd  %xmm14,%xmm9
  820d77:	addsd  0x130(%rsp),%xmm9
  820d81:	addsd  0x80(%rsp),%xmm9
  820d8b:	addsd  0x70(%rsp),%xmm9
  820d92:	addsd  -0x7714bb(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d9b:	mulsd  -0x770f64(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820da4:	ucomisd %xmm6,%xmm9
  820da9:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820daf:	movapd 0x60(%rsp),%xmm10
  820db6:	subsd  %xmm6,%xmm10
  820dbb:	ucomisd %xmm10,%xmm9
  820dc0:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  820dc6:	movapd %xmm13,%xmm9
  820dcb:	mulsd  0x250(%rsp),%xmm9
  820dd5:	movapd %xmm13,%xmm12
  820dda:	mulsd  0x240(%rsp),%xmm12
  820de4:	movapd %xmm2,%xmm10
  820de9:	mulsd  0x270(%rsp),%xmm10
  820df3:	movapd %xmm10,%xmm6
  820df8:	movapd %xmm9,0xc0(%rsp)
  820e02:	addsd  %xmm9,%xmm6
  820e07:	addsd  0x120(%rsp),%xmm6
  820e10:	subsd  0x50(%rsp),%xmm6
  820e16:	movapd %xmm2,%xmm9
  820e1b:	mulsd  0x260(%rsp),%xmm9
  820e25:	movsd  %xmm9,0xb0(%rsp)
  820e2f:	addsd  %xmm12,%xmm9
  820e34:	addsd  0x110(%rsp),%xmm9
  820e3e:	addsd  0x40(%rsp),%xmm9
  820e45:	addsd  0x30(%rsp),%xmm9
  820e4c:	addsd  -0x771575(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e55:	mulsd  -0x7715fe(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e5e:	addsd  0x10(%rsp),%xmm9
  820e65:	ucomisd %xmm6,%xmm9
  820e6a:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820e70:	movsd  %xmm10,0x198(%rsp)
  820e7a:	movapd 0x20(%rsp),%xmm10
  820e81:	subsd  %xmm6,%xmm10
  820e86:	ucomisd %xmm10,%xmm9
  820e8b:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820e91:	movapd 0x210(%rsp),%xmm9
  820e9b:	mulsd  %xmm13,%xmm9
  820ea0:	mulsd  0x200(%rsp),%xmm13
  820eaa:	movapd 0x230(%rsp),%xmm10
  820eb4:	mulsd  %xmm2,%xmm10
  820eb9:	movapd %xmm10,%xmm6
  820ebe:	movapd %xmm9,0x170(%rsp)
  820ec8:	addsd  %xmm9,%xmm6
  820ecd:	addsd  0xf0(%rsp),%xmm6
  820ed6:	subsd  0x50(%rsp),%xmm6
  820edc:	mulsd  0x220(%rsp),%xmm2
  820ee5:	movapd %xmm2,%xmm9
  820eea:	addsd  %xmm13,%xmm9
  820eef:	addsd  0x100(%rsp),%xmm9
  820ef9:	addsd  0x40(%rsp),%xmm9
  820f00:	addsd  0x30(%rsp),%xmm9
  820f07:	addsd  -0x771630(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f10:	mulsd  -0x7710d9(%rip),%xmm9        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f19:	ucomisd %xmm6,%xmm9
  820f1e:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820f24:	movapd %xmm10,0x310(%rsp)
  820f2e:	movapd 0x20(%rsp),%xmm10
  820f35:	subsd  %xmm6,%xmm10
  820f3a:	ucomisd %xmm10,%xmm9
  820f3f:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820f45:	addsd  -0x771965(%rip),%xmm0        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820f4d:	movapd %xmm0,%xmm9
  820f52:	mulsd  0x2d0(%rsp),%xmm9
  820f5c:	addsd  %xmm9,%xmm11
  820f61:	addsd  0x160(%rsp),%xmm11
  820f6b:	subsd  0x90(%rsp),%xmm11
  820f75:	movapd 0x2c0(%rsp),%xmm10
  820f7f:	mulsd  %xmm0,%xmm10
  820f84:	addsd  %xmm10,%xmm4
  820f89:	addsd  0x150(%rsp),%xmm4
  820f92:	addsd  0x80(%rsp),%xmm4
  820f9b:	addsd  0x70(%rsp),%xmm4
  820fa1:	addsd  -0x7716c9(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fa9:	mulsd  -0x771751(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820fb1:	addsd  0x18(%rsp),%xmm4
  820fb7:	ucomisd %xmm11,%xmm4
  820fbc:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820fc2:	movapd 0x60(%rsp),%xmm6
  820fc8:	subsd  %xmm11,%xmm6
  820fcd:	ucomisd %xmm6,%xmm4
  820fd1:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  820fd7:	movapd 0x2b0(%rsp),%xmm6
  820fe0:	mulsd  %xmm0,%xmm6
  820fe4:	addsd  %xmm6,%xmm15
  820fe9:	addsd  0x140(%rsp),%xmm15
  820ff3:	subsd  0x90(%rsp),%xmm15
  820ffd:	movapd 0x2a0(%rsp),%xmm11
  821007:	mulsd  %xmm0,%xmm11
  82100c:	addsd  %xmm11,%xmm14
  821011:	addsd  0x130(%rsp),%xmm14
  82101b:	addsd  0x80(%rsp),%xmm14
  821025:	addsd  0x70(%rsp),%xmm14
  82102c:	addsd  -0x771755(%rip),%xmm14        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821035:	mulsd  -0x7711fe(%rip),%xmm14        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82103e:	ucomisd %xmm15,%xmm14
  821043:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  821049:	movapd 0x60(%rsp),%xmm4
  82104f:	subsd  %xmm15,%xmm4
  821054:	ucomisd %xmm4,%xmm14
  821059:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  82105f:	movapd %xmm0,%xmm14
  821064:	mulsd  0x270(%rsp),%xmm14
  82106e:	movapd 0xc0(%rsp),%xmm4
  821077:	addsd  %xmm14,%xmm4
  82107c:	addsd  0x120(%rsp),%xmm4
  821085:	subsd  0x50(%rsp),%xmm4
  82108b:	movapd %xmm0,%xmm15
  821090:	mulsd  0x260(%rsp),%xmm15
  82109a:	addsd  %xmm15,%xmm12
  82109f:	addsd  0x110(%rsp),%xmm12
  8210a9:	addsd  0x40(%rsp),%xmm12
  8210b0:	addsd  0x30(%rsp),%xmm12
  8210b7:	addsd  -0x7717e0(%rip),%xmm12        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210c0:	mulsd  -0x771869(%rip),%xmm12        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8210c9:	addsd  0x10(%rsp),%xmm12
  8210d0:	ucomisd %xmm4,%xmm12
  8210d5:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  8210db:	movsd  %xmm15,0xc0(%rsp)
  8210e5:	movapd %xmm4,%xmm15
  8210ea:	movapd 0x20(%rsp),%xmm4
  8210f0:	subsd  %xmm15,%xmm4
  8210f5:	ucomisd %xmm4,%xmm12
  8210fa:	jae    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x10ce>
  821100:	movapd 0x230(%rsp),%xmm4
  821109:	mulsd  %xmm0,%xmm4
  82110d:	movapd 0x170(%rsp),%xmm15
  821117:	addsd  %xmm4,%xmm15
  82111c:	addsd  0xf0(%rsp),%xmm15
  821126:	subsd  0x50(%rsp),%xmm15
  82112d:	mulsd  0x220(%rsp),%xmm0
  821136:	addsd  %xmm0,%xmm13
  82113b:	addsd  0x100(%rsp),%xmm13
  821145:	addsd  0x40(%rsp),%xmm13
  82114c:	addsd  0x30(%rsp),%xmm13
  821153:	addsd  -0x77187c(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82115c:	mulsd  -0x771325(%rip),%xmm13        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821165:	ucomisd %xmm15,%xmm13
  82116a:	movsd  0x8(%rsp),%xmm12
  821171:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821177:	movapd %xmm4,0x170(%rsp)
  821180:	movapd 0x20(%rsp),%xmm4
  821186:	subsd  %xmm15,%xmm4
  82118b:	ucomisd %xmm4,%xmm13
  821190:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821196:	movsd  %xmm10,0x190(%rsp)
  8211a0:	addsd  -0x771bc0(%rip),%xmm1        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8211a8:	movapd %xmm1,%xmm10
  8211ad:	mulsd  0x300(%rsp),%xmm10
  8211b7:	movapd %xmm1,%xmm4
  8211bb:	mulsd  0x2f0(%rsp),%xmm4
  8211c4:	addsd  %xmm10,%xmm3
  8211c9:	addsd  0x160(%rsp),%xmm3
  8211d2:	subsd  0x90(%rsp),%xmm3
  8211db:	addsd  %xmm4,%xmm8
  8211e0:	addsd  0x150(%rsp),%xmm8
  8211ea:	addsd  0x80(%rsp),%xmm8
  8211f4:	addsd  0x70(%rsp),%xmm8
  8211fb:	addsd  -0x771924(%rip),%xmm8        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821204:	mulsd  -0x7719ad(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82120d:	addsd  0x18(%rsp),%xmm8
  821214:	ucomisd %xmm3,%xmm8
  821219:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  82121f:	movapd %xmm6,0x2e0(%rsp)
  821228:	movapd 0x60(%rsp),%xmm6
  82122e:	subsd  %xmm3,%xmm6
  821232:	ucomisd %xmm6,%xmm8
  821237:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  82123d:	movapd 0x290(%rsp),%xmm8
  821247:	mulsd  %xmm1,%xmm8
  82124c:	movapd 0x280(%rsp),%xmm3
  821255:	mulsd  %xmm1,%xmm3
  821259:	addsd  %xmm8,%xmm5
  82125e:	addsd  0x140(%rsp),%xmm5
  821267:	subsd  0x90(%rsp),%xmm5
  821270:	addsd  %xmm3,%xmm7
  821274:	addsd  0x130(%rsp),%xmm7
  82127d:	addsd  0x80(%rsp),%xmm7
  821286:	addsd  0x70(%rsp),%xmm7
  82128c:	addsd  -0x7719b4(%rip),%xmm7        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821294:	mulsd  -0x77145c(%rip),%xmm7        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82129c:	ucomisd %xmm5,%xmm7
  8212a0:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8212a6:	movapd 0x60(%rsp),%xmm6
  8212ac:	subsd  %xmm5,%xmm6
  8212b0:	ucomisd %xmm6,%xmm7
  8212b4:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8212ba:	movsd  %xmm14,0x188(%rsp)
  8212c4:	movapd %xmm9,%xmm14
  8212c9:	movapd %xmm1,%xmm7
  8212cd:	mulsd  0x250(%rsp),%xmm7
  8212d6:	movapd %xmm1,%xmm5
  8212da:	mulsd  0x240(%rsp),%xmm5
  8212e3:	movsd  0x198(%rsp),%xmm9
  8212ed:	addsd  %xmm7,%xmm9
  8212f2:	addsd  0x120(%rsp),%xmm9
  8212fc:	subsd  0x50(%rsp),%xmm9
  821303:	movsd  0xb0(%rsp),%xmm13
  82130d:	addsd  %xmm5,%xmm13
  821312:	addsd  0x110(%rsp),%xmm13
  82131c:	addsd  0x40(%rsp),%xmm13
  821323:	addsd  0x30(%rsp),%xmm13
  82132a:	addsd  -0x771a53(%rip),%xmm13        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821333:	mulsd  -0x771adc(%rip),%xmm13        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82133c:	addsd  0x10(%rsp),%xmm13
  821343:	ucomisd %xmm9,%xmm13
  821348:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  82134e:	movapd 0x20(%rsp),%xmm6
  821354:	subsd  %xmm9,%xmm6
  821359:	ucomisd %xmm6,%xmm13
  82135e:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821364:	movapd 0x210(%rsp),%xmm6
  82136d:	mulsd  %xmm1,%xmm6
  821371:	mulsd  0x200(%rsp),%xmm1
  82137a:	movapd 0x310(%rsp),%xmm13
  821384:	addsd  %xmm6,%xmm13
  821389:	addsd  0xf0(%rsp),%xmm13
  821393:	subsd  0x50(%rsp),%xmm13
  82139a:	addsd  %xmm1,%xmm2
  82139e:	addsd  0x100(%rsp),%xmm2
  8213a7:	addsd  0x40(%rsp),%xmm2
  8213ad:	addsd  0x30(%rsp),%xmm2
  8213b3:	addsd  -0x771adb(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213bb:	mulsd  -0x771583(%rip),%xmm2        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8213c3:	ucomisd %xmm13,%xmm2
  8213c8:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8213ce:	movapd 0x20(%rsp),%xmm9
  8213d5:	subsd  %xmm13,%xmm9
  8213da:	ucomisd %xmm9,%xmm2
  8213df:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8213e5:	addsd  %xmm10,%xmm14
  8213ea:	addsd  0x160(%rsp),%xmm14
  8213f4:	subsd  0x90(%rsp),%xmm14
  8213fe:	movsd  0x190(%rsp),%xmm9
  821408:	addsd  %xmm4,%xmm9
  82140d:	addsd  0x150(%rsp),%xmm9
  821417:	addsd  0x80(%rsp),%xmm9
  821421:	addsd  0x70(%rsp),%xmm9
  821428:	addsd  -0x771b51(%rip),%xmm9        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821431:	mulsd  -0x771bda(%rip),%xmm9        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82143a:	addsd  0x18(%rsp),%xmm9
  821441:	ucomisd %xmm14,%xmm9
  821446:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  82144c:	movapd 0x60(%rsp),%xmm2
  821452:	subsd  %xmm14,%xmm2
  821457:	ucomisd %xmm2,%xmm9
  82145c:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821462:	movapd 0x2e0(%rsp),%xmm4
  82146b:	addsd  %xmm8,%xmm4
  821470:	addsd  0x140(%rsp),%xmm4
  821479:	subsd  0x90(%rsp),%xmm4
  821482:	addsd  %xmm3,%xmm11
  821487:	addsd  0x130(%rsp),%xmm11
  821491:	addsd  0x80(%rsp),%xmm11
  82149b:	addsd  0x70(%rsp),%xmm11
  8214a2:	addsd  -0x771bcb(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214ab:	mulsd  -0x771674(%rip),%xmm11        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8214b4:	ucomisd %xmm4,%xmm11
  8214b9:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8214bf:	movapd 0x60(%rsp),%xmm2
  8214c5:	subsd  %xmm4,%xmm2
  8214c9:	ucomisd %xmm2,%xmm11
  8214ce:	movsd  0x188(%rsp),%xmm3
  8214d7:	movsd  0xc0(%rsp),%xmm4
  8214e0:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8214e6:	addsd  %xmm7,%xmm3
  8214ea:	addsd  0x120(%rsp),%xmm3
  8214f3:	subsd  0x50(%rsp),%xmm3
  8214f9:	addsd  %xmm5,%xmm4
  8214fd:	addsd  0x110(%rsp),%xmm4
  821506:	addsd  0x40(%rsp),%xmm4
  82150c:	addsd  0x30(%rsp),%xmm4
  821512:	addsd  -0x771c3a(%rip),%xmm4        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82151a:	mulsd  -0x771cc2(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821522:	addsd  0x10(%rsp),%xmm4
  821528:	ucomisd %xmm3,%xmm4
  82152c:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821532:	movapd 0x20(%rsp),%xmm2
  821538:	subsd  %xmm3,%xmm2
  82153c:	ucomisd %xmm2,%xmm4
  821540:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821546:	movapd 0x170(%rsp),%xmm3
  82154f:	addsd  %xmm6,%xmm3
  821553:	addsd  0xf0(%rsp),%xmm3
  82155c:	subsd  0x50(%rsp),%xmm3
  821562:	addsd  %xmm1,%xmm0
  821566:	addsd  0x100(%rsp),%xmm0
  82156f:	addsd  0x40(%rsp),%xmm0
  821575:	addsd  0x30(%rsp),%xmm0
  82157b:	addsd  -0x771ca3(%rip),%xmm0        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821583:	mulsd  -0x77174b(%rip),%xmm0        # afe40 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82158b:	ucomisd %xmm3,%xmm0
  82158f:	jae    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  821595:	movapd 0x20(%rsp),%xmm1
  82159b:	subsd  %xmm3,%xmm1
  82159f:	ucomisd %xmm1,%xmm0
  8215a3:	jb     820b36 <<gpui_gpu::renderer::RendererState>::bin_draw+0x656>
  8215a9:	jmp    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8215ae:	movsd  0x8(%rsp),%xmm12
  8215b5:	jmp    820c30 <<gpui_gpu::renderer::RendererState>::bin_draw+0x750>
  8215ba:	nopw   0x0(%rax,%rax,1)
  8215c0:	mov    0x1b0(%rsp),%r10
  8215c8:	cmp    %r10,0x1c8(%rsp)
  8215d0:	mov    0x1b8(%rsp),%rbp
  8215d8:	mov    0x1c0(%rsp),%rax
  8215e0:	jae    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  8215e6:	mov    %rax,%r14
  8215e9:	cmp    %r10,%rax
  8215ec:	jbe    820a20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x540>
  8215f2:	jmp    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  8215f7:	nopw   0x0(%rax,%rax,1)
  821600:	mov    %r14,%rax
  821603:	cmp    %r10,%r14
  821606:	adc    $0x0,%r14
  82160a:	mov    %rax,%rcx
  82160d:	imul   %r13,%rcx
  821611:	mov    %rbp,%rdx
  821614:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  821620:	lea    (%rdx,%rcx,1),%r12
  821624:	cmp    %r8,%r12
  821627:	jae    821665 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1185>
  821629:	cmp    %rbx,%rdx
  82162c:	mov    %rdx,%rsi
  82162f:	adc    $0x0,%rsi
  821633:	mov    0x4(%r9,%r12,8),%edi
  821638:	inc    %edi
  82163a:	and    $0xbfffffff,%edi
  821640:	mov    %edi,0x4(%r9,%r12,8)
  821645:	cmp    %rbx,%rdx
  821648:	jae    821652 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1172>
  82164a:	mov    %rsi,%rdx
  82164d:	cmp    %rbx,%rsi
  821650:	jbe    821620 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1140>
  821652:	cmp    %r10,%rax
  821655:	jae    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  82165b:	cmp    %r10,%r14
  82165e:	jbe    821600 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1120>
  821660:	jmp    82070f <<gpui_gpu::renderer::RendererState>::bin_draw+0x22f>
  821665:	lea    0x60e154(%rip),%rdx        # e2f7c0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x108>
  82166c:	mov    %r12,%rdi
  82166f:	mov    %r8,%rsi
  821672:	call   *0x65fb10(%rip)        # e81188 <_DYNAMIC+0x4f8>
  821678:	lea    0x60e261(%rip),%rdi        # e2f8e0 <anon.7e34a6dced7fe4eb77116889a7de5f31.41.llvm.15614097268772730318>
  82167f:	call   *0x65fbe3(%rip)        # e81268 <_DYNAMIC+0x5d8>
  821685:	lea    0x60e11c(%rip),%rdx        # e2f7a8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0xf0>
  82168c:	mov    %r12,%rdi
  82168f:	mov    %r8,%rsi
  821692:	call   *0x65faf0(%rip)        # e81188 <_DYNAMIC+0x4f8>
  821698:	lea    0x60e151(%rip),%rdx        # e2f7f0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x138>
  82169f:	mov    %r12,%rdi
  8216a2:	mov    0xd8(%rsp),%rsi
  8216aa:	call   *0x65fad8(%rip)        # e81188 <_DYNAMIC+0x4f8>
  8216b0:	lea    0x60e121(%rip),%rdx        # e2f7d8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.15614097268772730318+0x120>
  8216b7:	mov    %r12,%rdi
  8216ba:	mov    %r8,%rsi
  8216bd:	call   *0x65fac5(%rip)        # e81188 <_DYNAMIC+0x4f8>
