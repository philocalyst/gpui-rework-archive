FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9261 frame=1448

/tmp/gpui-coverage-borrowed-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0b0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0b0:	push   %rbp
  81e0b1:	push   %r15
  81e0b3:	push   %r14
  81e0b5:	push   %r13
  81e0b7:	push   %r12
  81e0b9:	push   %rbx
  81e0ba:	sub    $0x578,%rsp
  81e0c1:	mov    0x228(%rsi),%rax
  81e0c8:	mov    0x18(%rdx),%rbx
  81e0cc:	cmp    %rbx,%rax
  81e0cf:	je     81e0ed <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0d1:	mov    0x10(%rax),%r9
  81e0d5:	cmp    0x10(%rbx),%r9
  81e0d9:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0df:	mov    0x18(%rax),%rax
  81e0e3:	cmp    0x18(%rbx),%rax
  81e0e7:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0ed:	movupd 0x330(%rsi),%xmm0
  81e0f5:	movapd %xmm0,0x130(%rsp)
  81e0fe:	movq   $0x0,0x330(%rsi)
  81e109:	mov    0x130(%rsp),%r13
  81e111:	test   %r13,%r13
  81e114:	je     81e156 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e116:	lock decq 0x0(%r13)
  81e11b:	jne    81e156 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e11d:	lea    0x130(%rsp),%rax
  81e125:	mov    %rdi,%r14
  81e128:	mov    %rax,%rdi
  81e12b:	mov    %rsi,%r12
  81e12e:	mov    %r8,%rbp
  81e131:	mov    %rdx,%r15
  81e134:	mov    %r13,0x38(%rsp)
  81e139:	mov    %rcx,%r13
  81e13c:	call   *0x663036(%rip)        # e81178 <_DYNAMIC+0x518>
  81e142:	mov    %r13,%rcx
  81e145:	mov    0x38(%rsp),%r13
  81e14a:	mov    %r15,%rdx
  81e14d:	mov    %rbp,%r8
  81e150:	mov    %r12,%rsi
  81e153:	mov    %r14,%rdi
  81e156:	mov    0x228(%rsi),%rax
  81e15d:	cmp    %rbx,%rax
  81e160:	je     81e17e <<gpui_gpu::renderer::RendererState>::render+0xce>
  81e162:	mov    0x10(%rax),%r9
  81e166:	cmp    0x10(%rbx),%r9
  81e16a:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e170:	mov    0x18(%rax),%rax
  81e174:	cmp    0x18(%rbx),%rax
  81e178:	jne    81e259 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e17e:	lea    0x330(%rsi),%rax
  81e185:	mov    %rax,0xe8(%rsp)
  81e18d:	mov    (%rax),%rax
  81e190:	test   %rax,%rax
  81e193:	je     81e1cc <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e195:	lock decq (%rax)
  81e199:	jne    81e1cc <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e19b:	mov    %rdi,%r14
  81e19e:	lea    0x330(%rsi),%rdi
  81e1a5:	mov    %rsi,%r12
  81e1a8:	mov    %r8,%rbp
  81e1ab:	mov    %rdx,%r15
  81e1ae:	mov    %r13,%rbx
  81e1b1:	mov    %rcx,%r13
  81e1b4:	call   *0x662fbe(%rip)        # e81178 <_DYNAMIC+0x518>
  81e1ba:	mov    %r13,%rcx
  81e1bd:	mov    %rbx,%r13
  81e1c0:	mov    %r15,%rdx
  81e1c3:	mov    %rbp,%r8
  81e1c6:	mov    %r12,%rsi
  81e1c9:	mov    %r14,%rdi
  81e1cc:	movq   $0x0,0x330(%rsi)
  81e1d7:	mov    (%rcx),%ebp
  81e1d9:	mov    0x8(%rcx),%r9d
  81e1dd:	movzbl 0xd(%rcx),%eax
  81e1e1:	test   %r9d,%r9d
  81e1e4:	sets   %r10b
  81e1e8:	and    $0x7fffffff,%r9d
  81e1ef:	lea    -0x800000(%r9),%r11d
  81e1f6:	cmp    $0x7f000000,%r11d
  81e1fd:	setb   %r11b
  81e201:	and    %r10b,%r11b
  81e204:	lea    -0x1(%r9),%r14d
  81e208:	cmp    $0x7fffff,%r14d
  81e20f:	setb   %r14b
  81e213:	and    %r10b,%r14b
  81e216:	test   %r9d,%r9d
  81e219:	sete   %r10b
  81e21d:	cmp    $0x7f800000,%r9d
  81e224:	sete   %r15b
  81e228:	or     %r10b,%r15b
  81e22b:	cmp    $0x7f800001,%r9d
  81e232:	setge  %r9b
  81e236:	or     %r15b,%r9b
  81e239:	or     %r14b,%r9b
  81e23c:	test   %ebp,%ebp
  81e23e:	setne  %r10b
  81e242:	and    %al,%r10b
  81e245:	or     %r11b,%r10b
  81e248:	or     %r9b,%r10b
  81e24b:	test   $0x1,%r10b
  81e24f:	je     81e274 <<gpui_gpu::renderer::RendererState>::render+0x1c4>
  81e251:	movl   $0x3,(%rdi)
  81e257:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e259:	movl   $0x4,(%rdi)
  81e25f:	mov    %rdi,%rax
  81e262:	add    $0x578,%rsp
  81e269:	pop    %rbx
  81e26a:	pop    %r12
  81e26c:	pop    %r13
  81e26e:	pop    %r14
  81e270:	pop    %r15
  81e272:	pop    %rbp
  81e273:	ret
  81e274:	movd   0x4(%rcx),%xmm2
  81e279:	movzbl 0xc(%rcx),%r12d
  81e27e:	test   $0x1,%bpl
  81e282:	je     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x24a>
  81e284:	movd   %xmm2,%r9d
  81e289:	test   %r9d,%r9d
  81e28c:	sets   %r10b
  81e290:	and    $0x7fffffff,%r9d
  81e297:	lea    -0x800000(%r9),%r11d
  81e29e:	cmp    $0x7f000000,%r11d
  81e2a5:	setb   %r11b
  81e2a9:	and    %r10b,%r11b
  81e2ac:	lea    -0x1(%r9),%r14d
  81e2b0:	cmp    $0x7fffff,%r14d
  81e2b7:	setb   %r14b
  81e2bb:	and    %r10b,%r14b
  81e2be:	test   %r9d,%r9d
  81e2c1:	sete   %r10b
  81e2c5:	cmp    $0x7f800000,%r9d
  81e2cc:	sete   %r15b
  81e2d0:	or     %r10b,%r15b
  81e2d3:	cmp    $0x7f800001,%r9d
  81e2da:	setge  %r9b
  81e2de:	or     %r15b,%r9b
  81e2e1:	or     %r14b,%r9b
  81e2e4:	or     %r11b,%r9b
  81e2e7:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2ed:	ucomiss -0x76f3e8(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e2f4:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2fa:	mov    0x28(%rcx),%r14d
  81e2fe:	cmp    %r14d,0x20(%r8)
  81e302:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e308:	mov    0x2c(%rcx),%r15d
  81e30c:	cmp    %r15d,0x24(%r8)
  81e310:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e316:	mov    0x38(%r8),%r10d
  81e31a:	cmp    0x20(%rdx),%r10d
  81e31e:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e324:	cmp    $0x4c,%r10d
  81e328:	jne    81e34d <<gpui_gpu::renderer::RendererState>::render+0x29d>
  81e32a:	movq   0x3c(%r8),%xmm0
  81e330:	movq   0x24(%rdx),%xmm1
  81e335:	pcmpeqd %xmm0,%xmm1
  81e339:	pshufd $0x50,%xmm1,%xmm0
  81e33e:	movmskpd %xmm0,%r9d
  81e343:	cmp    $0x3,%r9d
  81e347:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e34d:	cmp    $0x4000,%r15d
  81e354:	ja     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e356:	cmp    $0x4000,%r14d
  81e35d:	ja     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e35f:	mov    %r15,%r9
  81e362:	imul   %r14,%r9
  81e366:	add    $0xfffffffffeffffff,%r9
  81e36d:	cmp    $0xffffffffff000000,%r9
  81e374:	jb     81e38a <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e376:	mov    0x10(%rcx),%rbx
  81e37a:	mov    0x80(%rbx),%r11
  81e381:	cmp    $0x10000,%r11
  81e388:	jbe    81e395 <<gpui_gpu::renderer::RendererState>::render+0x2e5>
  81e38a:	movl   $0x6,(%rdi)
  81e390:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e395:	movd   0x18(%rcx),%xmm0
  81e39a:	movd   %xmm0,%r9d
  81e39f:	and    $0x7fffffff,%r9d
  81e3a6:	cmp    $0x7f7fffff,%r9d
  81e3ad:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3b3:	pand   -0x770bcb(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3bb:	ucomiss -0x76f25e(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3c2:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3c8:	movd   0x1c(%rcx),%xmm0
  81e3cd:	movd   %xmm0,%r9d
  81e3d2:	and    $0x7fffffff,%r9d
  81e3d9:	cmp    $0x7f7fffff,%r9d
  81e3e0:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3e6:	pand   -0x770bfe(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3ee:	ucomiss -0x76f291(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3f5:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3fb:	movd   0x20(%rcx),%xmm0
  81e400:	movd   %xmm0,%r9d
  81e405:	and    $0x7fffffff,%r9d
  81e40c:	cmp    $0x7f7fffff,%r9d
  81e413:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e419:	pand   -0x770c31(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e421:	ucomiss -0x76f2c4(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e428:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e42e:	movd   0x24(%rcx),%xmm0
  81e433:	movd   %xmm0,%r9d
  81e438:	and    $0x7fffffff,%r9d
  81e43f:	cmp    $0x7f7fffff,%r9d
  81e446:	jg     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e44c:	movdqa -0x770c64(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e454:	pand   %xmm0,%xmm1
  81e458:	ucomiss -0x76f2fb(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e45f:	ja     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e465:	xorps  %xmm1,%xmm1
  81e468:	ucomiss %xmm1,%xmm0
  81e46b:	jb     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e471:	movss  -0x76f699(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e479:	ucomiss %xmm0,%xmm1
  81e47c:	jb     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e482:	movzwl 0x30(%rcx),%r9d
  81e487:	mov    %r9d,0x10(%rsp)
  81e48c:	movzwl 0x32(%rcx),%r9d
  81e491:	mov    %r9d,0x30(%rsp)
  81e496:	cmp    $0x28,%r10d
  81e49a:	mov    %r8,0x4b8(%rsp)
  81e4a2:	mov    %rcx,0x120(%rsp)
  81e4aa:	mov    %rdx,0xa0(%rsp)
  81e4b2:	mov    %r13,0x38(%rsp)
  81e4b7:	movd   %xmm2,0x2e8(%rsp)
  81e4c0:	movss  %xmm1,0xf4(%rsp)
  81e4c9:	jne    81e4d5 <<gpui_gpu::renderer::RendererState>::render+0x425>
  81e4cb:	test   $0x1,%al
  81e4cd:	je     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4d3:	jmp    81e4f0 <<gpui_gpu::renderer::RendererState>::render+0x440>
  81e4d5:	test   $0x1,%al
  81e4d7:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4dd:	ucomiss -0x76f704(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e4e4:	jne    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4ea:	jp     81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e4f0:	mov    %rbx,0x100(%rsp)
  81e4f8:	mov    %r11,0x108(%rsp)
  81e500:	mov    %r10d,0x2e4(%rsp)
  81e508:	mov    %rdi,0x50(%rsp)
  81e50d:	lea    0xf(%r14),%rax
  81e511:	shr    $0x4,%rax
  81e515:	lea    0xf(%r15),%ecx
  81e519:	shr    $0x4,%ecx
  81e51c:	lea    0x18(%rsi),%rdi
  81e520:	movq   $0x0,0x28(%rsi)
  81e528:	mov    %rax,0x90(%rsp)
  81e530:	imul   %eax,%ecx
  81e533:	movabs $0x4000000000000000,%rdx
  81e53d:	mov    %rdi,0x4c8(%rsp)
  81e545:	mov    %rsi,%r13
  81e548:	mov    %rcx,0x40(%rsp)
  81e54d:	mov    %rcx,%rsi
  81e550:	call   823730 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e555:	mov    %r13,0x8(%rsp)
  81e55a:	mov    0x10(%r13),%rax
  81e55e:	mov    %rax,0x348(%rsp)
  81e566:	mov    0x120(%rsp),%rdi
  81e56e:	call   *0x662c94(%rip)        # e81208 <_DYNAMIC+0x5a8>
  81e574:	mov    %rdx,0x358(%rsp)
  81e57c:	mov    %rax,0x350(%rsp)
  81e584:	sub    %rax,%rdx
  81e587:	cmp    $0x300000,%rdx
  81e58e:	ja     81e6c5 <<gpui_gpu::renderer::RendererState>::render+0x615>
  81e594:	mov    %rdx,%rcx
  81e597:	mov    %rdx,%rax
  81e59a:	shr    $0x3,%rax
  81e59e:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81e5a8:	imul   %rax,%rdx
  81e5ac:	mov    %rdx,0x2c0(%rsp)
  81e5b4:	mov    0x350(%rsp),%rax
  81e5bc:	cmp    %rax,0x358(%rsp)
  81e5c4:	je     81e5f5 <<gpui_gpu::renderer::RendererState>::render+0x545>
  81e5c6:	mov    $0xaaaaaaab,%eax
  81e5cb:	imul   %rax,%rcx
  81e5cf:	shr    $0x2a,%rcx
  81e5d3:	mov    0x2c0(%rsp),%rdx
  81e5db:	mov    %edx,%eax
  81e5dd:	and    $0x3f,%eax
  81e5e0:	add    %rdx,%rcx
  81e5e3:	cmp    $0x1,%rax
  81e5e7:	sbb    $0xffffffffffffffff,%rcx
  81e5eb:	inc    %rcx
  81e5ee:	mov    %rcx,0x20(%rsp)
  81e5f3:	jmp    81e5fe <<gpui_gpu::renderer::RendererState>::render+0x54e>
  81e5f5:	movq   $0x0,0x20(%rsp)
  81e5fe:	mov    0x100(%rsp),%rax
  81e606:	mov    0x98(%rax),%rdx
  81e60d:	add    0xb0(%rax),%rdx
  81e614:	mov    0x30(%rsp),%ecx
  81e618:	shl    $0x10,%ecx
  81e61b:	add    0x10(%rsp),%ecx
  81e61f:	mov    %rax,0x130(%rsp)
  81e627:	movq   $0x0,0x138(%rsp)
  81e633:	mov    0x108(%rsp),%rbx
  81e63b:	mov    %rbx,0x140(%rsp)
  81e643:	mov    %rdx,0x340(%rsp)
  81e64b:	mov    %rdx,0x148(%rsp)
  81e653:	mov    %ecx,0x30(%rsp)
  81e657:	mov    %ecx,0x150(%rsp)
  81e65e:	mov    0x8(%rsp),%r13
  81e663:	movzbl 0x341(%r13),%esi
  81e66b:	lea    0x130(%rsp),%rdi
  81e673:	call   81c7d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>
  81e678:	mov    %rax,0x110(%rsp)
  81e680:	mov    0x20(%rsp),%rcx
  81e685:	lea    (%rcx,%rax,4),%rcx
  81e689:	mov    %rcx,0x10(%rsp)
  81e68e:	lea    (%rcx,%rbx,2),%rax
  81e692:	xor    %edx,%edx
  81e694:	mov    %rax,0x2b8(%rsp)
  81e69c:	sub    0x348(%rsp),%rax
  81e6a4:	cmovae %rax,%rdx
  81e6a8:	mov    0x10(%r13),%rsi
  81e6ac:	mov    $0x4,%ecx
  81e6b1:	mov    $0x10,%r8d
  81e6b7:	mov    %r13,%rdi
  81e6ba:	call   824b60 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e6bf:	cmp    $0xffffffffffffffff,%rax
  81e6c3:	je     81e6d5 <<gpui_gpu::renderer::RendererState>::render+0x625>
  81e6c5:	mov    0x50(%rsp),%rdi
  81e6ca:	movl   $0x6,(%rdi)
  81e6d0:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e6d5:	pxor   %xmm0,%xmm0
  81e6d9:	movdqa %xmm0,0x130(%rsp)
  81e6e2:	lea    0x130(%rsp),%rdx
  81e6ea:	mov    0x8(%rsp),%rbx
  81e6ef:	mov    %rbx,%rdi
  81e6f2:	mov    0x108(%rsp),%rax
  81e6fa:	mov    0x10(%rsp),%rcx
  81e6ff:	lea    (%rcx,%rax,2),%rsi
  81e703:	call   823850 <<alloc::vec::Vec<[u32; 4]>>::resize>
  81e708:	movq   $0xffffffffffffffff,0x2d0(%rsp)
  81e714:	movq   $0x0,0x2d8(%rsp)
  81e720:	movq   $0xffffffffffffffff,0x230(%rsp)
  81e72c:	movq   $0x0,0x238(%rsp)
  81e738:	mov    0x10(%rbx),%rdx
  81e73c:	cmp    %rdx,0x20(%rsp)
  81e741:	ja     820438 <<gpui_gpu::renderer::RendererState>::render+0x2388>
  81e747:	mov    0x8(%rsp),%r13
  81e74c:	mov    0x8(%r13),%rdi
  81e750:	lea    0x2d0(%rsp),%r8
  81e758:	mov    0x20(%rsp),%rsi
  81e75d:	mov    0x120(%rsp),%rdx
  81e765:	mov    0x2c0(%rsp),%rcx
  81e76d:	call   824810 <gpui_gpu::renderer::slots::write_prefix>
  81e772:	lea    0x48(%r13),%rdi
  81e776:	movq   $0x0,0x58(%r13)
  81e77e:	mov    %rdi,0x4c0(%rsp)
  81e786:	mov    0x40(%rsp),%rsi
  81e78b:	xor    %edx,%edx
  81e78d:	call   823940 <<alloc::vec::Vec<u32>>::resize>
  81e792:	movq   $0x0,0x70(%r13)
  81e79a:	cmpq   $0x0,0x60(%r13)
  81e79f:	jne    81e7b0 <<gpui_gpu::renderer::RendererState>::render+0x700>
  81e7a1:	mov    0x8(%rsp),%rax
  81e7a6:	lea    0x60(%rax),%rdi
  81e7aa:	call   *0x662a60(%rip)        # e81210 <_DYNAMIC+0x5b0>
  81e7b0:	mov    0x110(%rsp),%rax
  81e7b8:	add    %rax,%rax
  81e7bb:	mov    %rax,0x110(%rsp)
  81e7c3:	mov    0x8(%rsp),%rax
  81e7c8:	mov    0x68(%rax),%rcx
  81e7cc:	pxor   %xmm0,%xmm0
  81e7d0:	movdqu %xmm0,0x10(%rcx)
  81e7d5:	movdqu %xmm0,(%rcx)
  81e7d9:	movq   $0x1,0x70(%rax)
  81e7e1:	lea    0x2f8(%rax),%rdi
  81e7e8:	call   823180 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e7ed:	mov    0x100(%rsp),%rax
  81e7f5:	mov    %rax,0x368(%rsp)
  81e7fd:	movq   $0x0,0x370(%rsp)
  81e809:	mov    0x108(%rsp),%rax
  81e811:	mov    %rax,0x378(%rsp)
  81e819:	mov    0x340(%rsp),%rax
  81e821:	mov    %rax,0x380(%rsp)
  81e829:	mov    0x30(%rsp),%eax
  81e82d:	mov    %eax,0x388(%rsp)
  81e834:	lea    0x408(%rsp),%rdi
  81e83c:	lea    0x368(%rsp),%rsi
  81e844:	call   *0x6629ce(%rip)        # e81218 <_DYNAMIC+0x5b8>
  81e84a:	mov    0x408(%rsp),%rax
  81e852:	mov    %rax,0x28(%rsp)
  81e857:	test   %rax,%rax
  81e85a:	je     81f2e6 <<gpui_gpu::renderer::RendererState>::render+0x1236>
  81e860:	movq   $0x0,0x118(%rsp)
  81e86c:	movq   $0x0,0x68(%rsp)
  81e875:	movq   $0x0,0x88(%rsp)
  81e881:	movq   $0x0,0x2a8(%rsp)
  81e88d:	movq   $0x0,0x2b0(%rsp)
  81e899:	mov    0x410(%rsp),%rbx
  81e8a1:	mov    0x418(%rsp),%r13
  81e8a9:	lea    0x420(%rsp),%rcx
  81e8b1:	movups (%rcx),%xmm0
  81e8b4:	movups 0x10(%rcx),%xmm1
  81e8b8:	movups 0x20(%rcx),%xmm2
  81e8bc:	movaps %xmm2,0x290(%rsp)
  81e8c4:	movaps %xmm1,0x280(%rsp)
  81e8cc:	movaps %xmm0,0x270(%rsp)
  81e8d4:	lea    0x450(%rsp),%rdx
  81e8dc:	movups (%rdx),%xmm0
  81e8df:	movaps %xmm0,0x330(%rsp)
  81e8e7:	movups 0x40(%rcx),%xmm0
  81e8eb:	movaps %xmm0,0x320(%rsp)
  81e8f3:	mov    0x8(%rsp),%rax
  81e8f8:	movzbl 0x341(%rax),%esi
  81e8ff:	mov    0x28(%rsp),%rax
  81e904:	mov    %rax,0x130(%rsp)
  81e90c:	mov    %rbx,0x138(%rsp)
  81e914:	mov    %r13,0x140(%rsp)
  81e91c:	movups (%rcx),%xmm0
  81e91f:	movdqu 0x10(%rcx),%xmm1
  81e924:	movdqu 0x20(%rcx),%xmm2
  81e929:	lea    0x148(%rsp),%rdi
  81e931:	movdqu %xmm2,0x20(%rdi)
  81e936:	movdqu %xmm1,0x10(%rdi)
  81e93b:	movups %xmm0,(%rdi)
  81e93e:	movups (%rdx),%xmm0
  81e941:	lea    0x178(%rsp),%rax
  81e949:	movups %xmm0,(%rax)
  81e94c:	movdqu 0x40(%rcx),%xmm0
  81e951:	movdqu %xmm0,0x40(%rdi)
  81e956:	lea    0x130(%rsp),%rdi
  81e95e:	call   8216a0 <gpui_gpu::renderer::compact_group>
  81e963:	mov    %rbx,0xa8(%rsp)
  81e96b:	mov    %r13,0xe0(%rsp)
  81e973:	lea    (%rbx,%r13,4),%rbx
  81e977:	mov    %al,0x1f(%rsp)
  81e97b:	test   %al,%al
  81e97d:	je     81eb72 <<gpui_gpu::renderer::RendererState>::render+0xac2>
  81e983:	mov    0xa8(%rsp),%rax
  81e98b:	mov    %rax,0x490(%rsp)
  81e993:	mov    %rbx,0x498(%rsp)
  81e99b:	mov    0x28(%rsp),%rax
  81e9a0:	mov    %rax,0x4a0(%rsp)
  81e9a8:	movq   $0x0,0x4a8(%rsp)
  81e9b4:	lea    0x3a0(%rsp),%rdi
  81e9bc:	lea    0x490(%rsp),%rsi
  81e9c4:	call   821d30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e9c9:	cmpb   $0xff,0x3a8(%rsp)
  81e9d1:	je     81eb80 <<gpui_gpu::renderer::RendererState>::render+0xad0>
  81e9d7:	pxor   %xmm0,%xmm0
  81e9db:	movdqa %xmm0,0x70(%rsp)
  81e9e1:	movdqa %xmm0,0x40(%rsp)
  81e9e7:	mov    0x3a0(%rsp),%rdx
  81e9ef:	add    0x88(%rsp),%rdx
  81e9f7:	lea    0x3a8(%rsp),%rcx
  81e9ff:	movups 0x38(%rcx),%xmm0
  81ea03:	lea    0x148(%rsp),%rax
  81ea0b:	movups %xmm0,0x20(%rax)
  81ea0f:	movups 0x48(%rcx),%xmm0
  81ea13:	lea    0x178(%rsp),%rsi
  81ea1b:	movups %xmm0,0x40(%rsi)
  81ea1f:	mov    0x30(%rcx),%rax
  81ea23:	mov    %rax,0x160(%rsp)
  81ea2b:	movups (%rcx),%xmm0
  81ea2e:	movups 0x10(%rcx),%xmm1
  81ea32:	movups 0x20(%rcx),%xmm2
  81ea36:	movaps %xmm2,0x150(%rsp)
  81ea3e:	movaps %xmm1,0x140(%rsp)
  81ea46:	movaps %xmm0,0x130(%rsp)
  81ea4e:	lea    0x420(%rsp),%rax
  81ea56:	movups (%rax),%xmm0
  81ea59:	movups 0x10(%rax),%xmm1
  81ea5d:	movups 0x20(%rax),%xmm2
  81ea61:	movups %xmm2,0x20(%rsi)
  81ea65:	movups %xmm1,0x10(%rsi)
  81ea69:	movups %xmm0,(%rsi)
  81ea6c:	lea    0x450(%rsp),%rcx
  81ea74:	movups (%rcx),%xmm0
  81ea77:	movups %xmm0,0x30(%rsi)
  81ea7b:	movups 0x40(%rax),%xmm0
  81ea7f:	movups %xmm0,0x50(%rsi)
  81ea83:	lea    0x240(%rsp),%rdi
  81ea8b:	lea    0x130(%rsp),%rsi
  81ea93:	mov    %r14d,%ecx
  81ea96:	mov    %r15d,%r8d
  81ea99:	call   8216f0 <gpui_gpu::renderer::validate_draw>
  81ea9e:	mov    0x240(%rsp),%ecx
  81eaa5:	mov    0x244(%rsp),%rax
  81eaad:	cmp    $0xffffffff,%ecx
  81eab0:	jne    81f3c2 <<gpui_gpu::renderer::RendererState>::render+0x1312>
  81eab6:	mov    %eax,%ecx
  81eab8:	shr    $0x20,%rax
  81eabc:	movd   %ecx,%xmm0
  81eac0:	movaps 0x70(%rsp),%xmm2
  81eac5:	movaps %xmm2,%xmm1
  81eac8:	maxss  %xmm0,%xmm1
  81eacc:	movaps %xmm1,%xmm3
  81eacf:	cmpunordss %xmm1,%xmm3
  81ead4:	movaps %xmm3,%xmm0
  81ead7:	andnps %xmm1,%xmm0
  81eada:	andps  %xmm2,%xmm3
  81eadd:	orps   %xmm0,%xmm3
  81eae0:	movaps %xmm3,0xc0(%rsp)
  81eae8:	movd   %eax,%xmm0
  81eaec:	movaps 0x40(%rsp),%xmm2
  81eaf1:	movaps %xmm2,%xmm1
  81eaf4:	maxss  %xmm0,%xmm1
  81eaf8:	movaps %xmm1,%xmm3
  81eafb:	cmpunordss %xmm1,%xmm3
  81eb00:	movaps %xmm3,%xmm0
  81eb03:	andnps %xmm1,%xmm0
  81eb06:	andps  %xmm2,%xmm3
  81eb09:	orps   %xmm0,%xmm3
  81eb0c:	movaps %xmm3,0xb0(%rsp)
  81eb14:	lea    0x3a0(%rsp),%rdi
  81eb1c:	lea    0x490(%rsp),%rsi
  81eb24:	call   821d30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81eb29:	cmpb   $0xff,0x3a8(%rsp)
  81eb31:	movdqa 0xc0(%rsp),%xmm1
  81eb3a:	movdqa %xmm1,0x70(%rsp)
  81eb40:	movdqa 0xb0(%rsp),%xmm2
  81eb49:	movdqa %xmm2,0x40(%rsp)
  81eb4f:	jne    81e9e7 <<gpui_gpu::renderer::RendererState>::render+0x937>
  81eb55:	movdqa %xmm1,%xmm0
  81eb59:	movd   %xmm0,%ecx
  81eb5d:	movd   %xmm2,%eax
  81eb61:	shl    $0x20,%rax
  81eb65:	or     %rax,%rcx
  81eb68:	mov    %rcx,0xf8(%rsp)
  81eb70:	jmp    81eb8c <<gpui_gpu::renderer::RendererState>::render+0xadc>
  81eb72:	movq   $0x0,0xf8(%rsp)
  81eb7e:	jmp    81eba4 <<gpui_gpu::renderer::RendererState>::render+0xaf4>
  81eb80:	movq   $0x0,0xf8(%rsp)
  81eb8c:	incq   0x2a8(%rsp)
  81eb94:	mov    0xe0(%rsp),%rax
  81eb9c:	add    %rax,0x2b0(%rsp)
  81eba4:	mov    0xa8(%rsp),%rax
  81ebac:	mov    %rax,0x240(%rsp)
  81ebb4:	mov    %rbx,0x248(%rsp)
  81ebbc:	mov    0x28(%rsp),%rax
  81ebc1:	mov    %rax,0x250(%rsp)
  81ebc9:	movq   $0x0,0x258(%rsp)
  81ebd5:	lea    0x3a0(%rsp),%rdi
  81ebdd:	lea    0x240(%rsp),%rsi
  81ebe5:	call   821d30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ebea:	movzbl 0x3a8(%rsp),%eax
  81ebf2:	cmp    $0xff,%al
  81ebf4:	je     81f2b8 <<gpui_gpu::renderer::RendererState>::render+0x1208>
  81ebfa:	mov    %eax,%r8d
  81ebfd:	mov    0x10(%rsp),%rax
  81ec02:	lea    0x8(,%rax,8),%rax
  81ec0a:	mov    %rax,0x128(%rsp)
  81ec12:	mov    0x20(%rsp),%rax
  81ec17:	mov    %rax,0x80(%rsp)
  81ec1f:	mov    0x3a0(%rsp),%rax
  81ec27:	movups 0x3e0(%rsp),%xmm3
  81ec2f:	lea    0x3a8(%rsp),%rsi
  81ec37:	movups 0x48(%rsi),%xmm0
  81ec3b:	lea    0x518(%rsp),%rdi
  81ec43:	movups %xmm0,0x40(%rdi)
  81ec47:	mov    0x1(%rsi),%ecx
  81ec4a:	mov    0x4(%rsi),%edx
  81ec4d:	mov    %edx,-0x44(%rdi)
  81ec50:	mov    %ecx,-0x47(%rdi)
  81ec53:	mov    0x3b0(%rsp),%rdx
  81ec5b:	mov    0x30(%rsi),%rcx
  81ec5f:	mov    %rcx,-0x18(%rdi)
  81ec63:	movups 0x10(%rsi),%xmm0
  81ec67:	movups 0x20(%rsi),%xmm1
  81ec6b:	movups %xmm1,-0x28(%rdi)
  81ec6f:	movups %xmm0,-0x38(%rdi)
  81ec73:	movaps 0x270(%rsp),%xmm0
  81ec7b:	movaps 0x280(%rsp),%xmm1
  81ec83:	movaps 0x290(%rsp),%xmm2
  81ec8b:	movups %xmm2,0x20(%rdi)
  81ec8f:	movups %xmm1,0x10(%rdi)
  81ec93:	movups %xmm0,(%rdi)
  81ec96:	movaps 0x330(%rsp),%xmm0
  81ec9e:	movups %xmm0,0x30(%rdi)
  81eca2:	movaps 0x320(%rsp),%xmm0
  81ecaa:	movups %xmm0,0x50(%rdi)
  81ecae:	movaps %xmm3,0xc0(%rsp)
  81ecb6:	movups %xmm3,0x508(%rsp)
  81ecbe:	mov    %r8b,0x70(%rsp)
  81ecc3:	mov    %r8b,0x4d0(%rsp)
  81eccb:	mov    %rdx,0x310(%rsp)
  81ecd3:	mov    %rdx,0x4d8(%rsp)
  81ecdb:	cmpb   $0x0,0x1f(%rsp)
  81ece0:	je     81ed28 <<gpui_gpu::renderer::RendererState>::render+0xc78>
  81ece2:	mov    0xf8(%rsp),%rcx
  81ecea:	mov    %rcx,0x40(%rsp)
  81ecef:	mov    0x20(%rsp),%rcx
  81ecf4:	mov    %rcx,0xb0(%rsp)
  81ecfc:	test   %rax,%rax
  81ecff:	je     81ed78 <<gpui_gpu::renderer::RendererState>::render+0xcc8>
  81ed01:	mov    0xf8(%rsp),%rax
  81ed09:	mov    %rax,0x40(%rsp)
  81ed0e:	mov    0x20(%rsp),%rax
  81ed13:	mov    %rax,0xb0(%rsp)
  81ed1b:	lea    0x130(%rsp),%rbx
  81ed23:	jmp    81f090 <<gpui_gpu::renderer::RendererState>::render+0xfe0>
  81ed28:	lea    0x130(%rsp),%rdi
  81ed30:	lea    0x4d0(%rsp),%rsi
  81ed38:	mov    0x88(%rsp),%rdx
  81ed40:	mov    %r14d,%ecx
  81ed43:	mov    %r15d,%r8d
  81ed46:	call   8216f0 <gpui_gpu::renderer::validate_draw>
  81ed4b:	mov    0x130(%rsp),%eax
  81ed52:	mov    0x134(%rsp),%rcx
  81ed5a:	mov    %rcx,0x40(%rsp)
  81ed5f:	cmp    $0xffffffff,%eax
  81ed62:	jne    81f450 <<gpui_gpu::renderer::RendererState>::render+0x13a0>
  81ed68:	mov    0x80(%rsp),%rax
  81ed70:	mov    %rax,0xb0(%rsp)
  81ed78:	cmpb   $0x3,0x70(%rsp)
  81ed7d:	jne    81ee12 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed83:	movss  0x4d4(%rsp),%xmm0
  81ed8c:	xorps  %xmm1,%xmm1
  81ed8f:	ucomiss %xmm1,%xmm0
  81ed92:	jne    81ed96 <<gpui_gpu::renderer::RendererState>::render+0xce6>
  81ed94:	jnp    81ee12 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed96:	movaps 0xc0(%rsp),%xmm5
  81ed9e:	movaps %xmm5,%xmm1
  81eda1:	unpckhpd %xmm5,%xmm1
  81eda5:	movss  -0x76fde1(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81edad:	mulss  %xmm4,%xmm1
  81edb1:	movaps %xmm0,%xmm2
  81edb4:	minss  %xmm1,%xmm2
  81edb8:	movaps %xmm2,%xmm1
  81edbb:	cmpunordss %xmm2,%xmm1
  81edc0:	movaps %xmm1,%xmm3
  81edc3:	andnps %xmm2,%xmm3
  81edc6:	andps  %xmm0,%xmm1
  81edc9:	orps   %xmm3,%xmm1
  81edcc:	movaps %xmm5,%xmm0
  81edcf:	shufps $0xff,%xmm5,%xmm0
  81edd3:	mulss  %xmm4,%xmm0
  81edd7:	movaps %xmm1,%xmm2
  81edda:	minss  %xmm0,%xmm2
  81edde:	movaps %xmm2,%xmm0
  81ede1:	cmpunordss %xmm2,%xmm0
  81ede6:	andps  %xmm0,%xmm1
  81ede9:	andnps %xmm2,%xmm0
  81edec:	orps   %xmm1,%xmm0
  81edef:	movd   %xmm0,%eax
  81edf3:	mov    %eax,0x260(%rsp)
  81edfa:	and    $0xff800000,%eax
  81edff:	mov    $0x7f000000,%ecx
  81ee04:	sub    %eax,%ecx
  81ee06:	mov    %ecx,0xd8(%rsp)
  81ee0d:	xorps  %xmm0,%xmm0
  81ee10:	jmp    81ee37 <<gpui_gpu::renderer::RendererState>::render+0xd87>
  81ee12:	mov    0x568(%rsp),%eax
  81ee19:	mov    %eax,0x260(%rsp)
  81ee20:	mov    0x56c(%rsp),%eax
  81ee27:	mov    %eax,0xd8(%rsp)
  81ee2e:	movsd  0x570(%rsp),%xmm0
  81ee37:	movaps %xmm0,0x300(%rsp)
  81ee3f:	movups 0x518(%rsp),%xmm0
  81ee47:	movaps %xmm0,0x470(%rsp)
  81ee4f:	movups 0x520(%rsp),%xmm0
  81ee57:	movaps %xmm0,0x390(%rsp)
  81ee5f:	movsd  0x528(%rsp),%xmm0
  81ee68:	movaps %xmm0,0x220(%rsp)
  81ee70:	movsd  0x530(%rsp),%xmm0
  81ee79:	movaps %xmm0,0x2f0(%rsp)
  81ee81:	movsd  0x538(%rsp),%xmm0
  81ee8a:	movsd  %xmm0,0x98(%rsp)
  81ee93:	movsd  0x540(%rsp),%xmm0
  81ee9c:	movsd  %xmm0,0x2c8(%rsp)
  81eea5:	movups 0x548(%rsp),%xmm0
  81eead:	movaps %xmm0,0x480(%rsp)
  81eeb5:	mov    0x28(%rsp),%rax
  81eeba:	mov    %rax,0x130(%rsp)
  81eec2:	mov    0xa8(%rsp),%rax
  81eeca:	mov    %rax,0x138(%rsp)
  81eed2:	mov    0xe0(%rsp),%rax
  81eeda:	mov    %rax,0x140(%rsp)
  81eee2:	movaps 0x270(%rsp),%xmm0
  81eeea:	movaps 0x280(%rsp),%xmm1
  81eef2:	movaps 0x290(%rsp),%xmm2
  81eefa:	lea    0x148(%rsp),%rcx
  81ef02:	movups %xmm2,0x20(%rcx)
  81ef06:	movups %xmm1,0x10(%rcx)
  81ef0a:	movups %xmm0,(%rcx)
  81ef0d:	movaps 0x330(%rsp),%xmm0
  81ef15:	lea    0x178(%rsp),%rax
  81ef1d:	movups %xmm0,(%rax)
  81ef20:	movaps 0x320(%rsp),%xmm0
  81ef28:	movups %xmm0,0x40(%rcx)
  81ef2c:	lea    0x130(%rsp),%rdi
  81ef34:	call   *0x6622e6(%rip)        # e81220 <_DYNAMIC+0x5c0>
  81ef3a:	test   %eax,%eax
  81ef3c:	je     81ef6a <<gpui_gpu::renderer::RendererState>::render+0xeba>
  81ef3e:	mov    0x2c0(%rsp),%rdi
  81ef46:	mov    %eax,%esi
  81ef48:	call   8247d0 <gpui_gpu::renderer::slots::color_word>
  81ef4d:	mov    %eax,0x260(%rsp)
  81ef54:	xorps  %xmm0,%xmm0
  81ef57:	movaps %xmm0,0x300(%rsp)
  81ef5f:	movl   $0x0,0xd8(%rsp)
  81ef6a:	movsd  0x2c8(%rsp),%xmm0
  81ef73:	cvtsd2ss %xmm0,%xmm0
  81ef77:	movapd 0x390(%rsp),%xmm1
  81ef80:	unpcklpd 0x2f0(%rsp),%xmm1
  81ef89:	cvtpd2ps %xmm1,%xmm1
  81ef8d:	movsd  0x98(%rsp),%xmm2
  81ef96:	cvtsd2ss %xmm2,%xmm2
  81ef9a:	movapd 0x470(%rsp),%xmm3
  81efa3:	unpcklpd 0x220(%rsp),%xmm3
  81efac:	cvtpd2ps %xmm3,%xmm3
  81efb0:	mov    0x40(%rsp),%rcx
  81efb5:	mov    %rcx,%rax
  81efb8:	shr    $0x20,%rax
  81efbc:	mov    0x8(%rsp),%rdx
  81efc1:	mov    0x8(%rdx),%rsi
  81efc5:	mov    0x10(%rdx),%rdx
  81efc9:	movlpd %xmm3,0x130(%rsp)
  81efd2:	movss  %xmm2,0x138(%rsp)
  81efdb:	mov    %ecx,0x13c(%rsp)
  81efe2:	movlpd %xmm1,0x140(%rsp)
  81efeb:	movss  %xmm0,0x148(%rsp)
  81eff4:	mov    %eax,0x14c(%rsp)
  81effb:	lea    0x2d0(%rsp),%rdi
  81f003:	mov    0x80(%rsp),%r13
  81f00b:	mov    %r13,%rcx
  81f00e:	lea    0x130(%rsp),%rbx
  81f016:	mov    %rbx,%r8
  81f019:	call   81b730 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81f01e:	mov    0x8(%rsp),%rax
  81f023:	mov    0x8(%rax),%rsi
  81f027:	mov    0x10(%rax),%rdx
  81f02b:	mov    0x110(%rsp),%rax
  81f033:	lea    0x0(%r13,%rax,1),%rcx
  81f038:	movaps 0x480(%rsp),%xmm0
  81f040:	movaps %xmm0,0x130(%rsp)
  81f048:	mov    0x260(%rsp),%eax
  81f04f:	mov    %eax,0x140(%rsp)
  81f056:	mov    0xd8(%rsp),%eax
  81f05d:	mov    %eax,0x144(%rsp)
  81f064:	movaps 0x300(%rsp),%xmm0
  81f06c:	movlps %xmm0,0x148(%rsp)
  81f074:	lea    0x2d0(%rsp),%rdi
  81f07c:	mov    %rbx,%r8
  81f07f:	call   81b730 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81f084:	add    $0x2,%r13
  81f088:	mov    %r13,0x80(%rsp)
  81f090:	cmpb   $0x2,0x70(%rsp)
  81f095:	sete   0x260(%rsp)
  81f09d:	cmpq   $0x0,0x310(%rsp)
  81f0a6:	setne  0x310(%rsp)
  81f0ae:	mov    0x28(%rsp),%rax
  81f0b3:	mov    %rax,0x130(%rsp)
  81f0bb:	mov    0xa8(%rsp),%rax
  81f0c3:	mov    %rax,0x138(%rsp)
  81f0cb:	mov    0xe0(%rsp),%rax
  81f0d3:	mov    %rax,0x140(%rsp)
  81f0db:	movaps 0x270(%rsp),%xmm0
  81f0e3:	movdqa 0x280(%rsp),%xmm1
  81f0ec:	movdqa 0x290(%rsp),%xmm2
  81f0f5:	lea    0x148(%rsp),%rcx
  81f0fd:	movdqu %xmm2,0x20(%rcx)
  81f102:	movdqu %xmm1,0x10(%rcx)
  81f107:	movups %xmm0,(%rcx)
  81f10a:	movaps 0x330(%rsp),%xmm0
  81f112:	lea    0x178(%rsp),%rax
  81f11a:	movups %xmm0,(%rax)
  81f11d:	movaps 0x320(%rsp),%xmm0
  81f125:	movups %xmm0,0x40(%rcx)
  81f129:	mov    %rbx,%rdi
  81f12c:	call   *0x6620ee(%rip)        # e81220 <_DYNAMIC+0x5c0>
  81f132:	mov    %eax,0x70(%rsp)
  81f136:	mov    0x8(%rsp),%r13
  81f13b:	mov    0x8(%r13),%rsi
  81f13f:	mov    0x10(%r13),%rdx
  81f143:	movdqa 0xc0(%rsp),%xmm0
  81f14c:	movdqa %xmm0,0x130(%rsp)
  81f155:	lea    0x230(%rsp),%rdi
  81f15d:	mov    %rbx,%r8
  81f160:	mov    0x10(%rsp),%rbx
  81f165:	mov    %rbx,%rcx
  81f168:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f16d:	lea    0x1(%rbx),%rcx
  81f171:	mov    0x10(%r13),%rdx
  81f175:	cmp    %rdx,%rcx
  81f178:	jae    820462 <<gpui_gpu::renderer::RendererState>::render+0x23b2>
  81f17e:	mov    0xb0(%rsp),%rsi
  81f186:	mov    %esi,%edi
  81f188:	or     $0x80000000,%edi
  81f18e:	cmpl   $0x0,0x70(%rsp)
  81f193:	cmove  %esi,%edi
  81f196:	mov    0x8(%r13),%rsi
  81f19a:	mov    0x128(%rsp),%r13
  81f1a2:	mov    0x8(%rsi,%r13,2),%r8d
  81f1a7:	mov    %r8d,0x138(%rsp)
  81f1af:	mov    (%rsi,%r13,2),%r8
  81f1b3:	mov    %r8,0x130(%rsp)
  81f1bb:	mov    %edi,0x13c(%rsp)
  81f1c2:	lea    0x230(%rsp),%rdi
  81f1ca:	lea    0x130(%rsp),%r8
  81f1d2:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f1d7:	lea    0x130(%rsp),%rdi
  81f1df:	mov    0x8(%rsp),%rsi
  81f1e4:	lea    0x4d0(%rsp),%rdx
  81f1ec:	mov    0x40(%rsp),%rcx
  81f1f1:	mov    %rbx,0x10(%rsp)
  81f1f6:	mov    %ebx,%r8d
  81f1f9:	mov    0x88(%rsp),%rbx
  81f201:	mov    %rbx,%r9
  81f204:	push   0x118(%rsp)
  81f20b:	push   %r15
  81f20d:	push   %r14
  81f20f:	push   0xa8(%rsp)
  81f216:	call   8204e0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f21b:	add    $0x20,%rsp
  81f21f:	mov    0x130(%rsp),%eax
  81f226:	cmp    $0xffffffff,%eax
  81f229:	jne    81f420 <<gpui_gpu::renderer::RendererState>::render+0x1370>
  81f22f:	movzbl 0x260(%rsp),%ecx
  81f237:	and    0x310(%rsp),%cl
  81f23e:	mov    0x68(%rsp),%rax
  81f243:	or     %cl,%al
  81f245:	mov    %rax,0x68(%rsp)
  81f24a:	addq   $0x2,0x10(%rsp)
  81f250:	mov    0x138(%rsp),%rax
  81f258:	mov    %rax,0x118(%rsp)
  81f260:	inc    %rbx
  81f263:	mov    %rbx,0x88(%rsp)
  81f26b:	lea    0x3a0(%rsp),%rdi
  81f273:	lea    0x240(%rsp),%rsi
  81f27b:	call   821d30 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81f280:	movzbl 0x3a8(%rsp),%r8d
  81f289:	add    $0x10,%r13
  81f28d:	mov    %r13,0x128(%rsp)
  81f295:	cmp    $0xff,%r8b
  81f299:	jne    81ec1f <<gpui_gpu::renderer::RendererState>::render+0xb6f>
  81f29f:	mov    0x68(%rsp),%rax
  81f2a4:	and    $0x1,%al
  81f2a6:	mov    %rax,0x68(%rsp)
  81f2ab:	mov    0x80(%rsp),%rax
  81f2b3:	mov    %rax,0x20(%rsp)
  81f2b8:	lea    0x408(%rsp),%rdi
  81f2c0:	lea    0x368(%rsp),%rsi
  81f2c8:	call   *0x661f4a(%rip)        # e81218 <_DYNAMIC+0x5b8>
  81f2ce:	mov    0x408(%rsp),%rax
  81f2d6:	mov    %rax,0x28(%rsp)
  81f2db:	test   %rax,%rax
  81f2de:	jne    81e899 <<gpui_gpu::renderer::RendererState>::render+0x7e9>
  81f2e4:	jmp    81f31f <<gpui_gpu::renderer::RendererState>::render+0x126f>
  81f2e6:	movq   $0x0,0x2b0(%rsp)
  81f2f2:	movq   $0x0,0x2a8(%rsp)
  81f2fe:	movq   $0x0,0x88(%rsp)
  81f30a:	movq   $0x0,0x68(%rsp)
  81f313:	movq   $0x0,0x118(%rsp)
  81f31f:	mov    0xa0(%rsp),%rsi
  81f327:	lea    0x8(%rsi),%rdx
  81f32b:	mov    0x8(%rsp),%rax
  81f330:	lea    0x258(%rax),%rcx
  81f337:	lea    0x328(%rax),%r8
  81f33e:	mov    0x10(%rax),%r9
  81f342:	sub    $0x8,%rsp
  81f346:	lea    0x138(%rsp),%rdi
  81f34e:	mov    %rdx,0x2f8(%rsp)
  81f356:	mov    %rcx,0xa0(%rsp)
  81f35e:	mov    %r8,0x488(%rsp)
  81f366:	push   0x128(%rsp)
  81f36d:	call   823a90 <gpui_gpu::renderer::images::prepare>
  81f372:	add    $0x10,%rsp
  81f376:	mov    0x130(%rsp),%eax
  81f37d:	movzbl 0x134(%rsp),%ecx
  81f385:	mov    %cl,0x390(%rsp)
  81f38c:	cmp    $0xffffffff,%eax
  81f38f:	je     81f3e8 <<gpui_gpu::renderer::RendererState>::render+0x1338>
  81f391:	movupd 0x135(%rsp),%xmm0
  81f39a:	movups 0x140(%rsp),%xmm1
  81f3a2:	mov    0x50(%rsp),%rdi
  81f3a7:	movups %xmm1,0x10(%rdi)
  81f3ab:	movupd %xmm0,0x5(%rdi)
  81f3b0:	mov    %eax,(%rdi)
  81f3b2:	movzbl 0x390(%rsp),%eax
  81f3ba:	mov    %al,0x4(%rdi)
  81f3bd:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3c2:	mov    0x25c(%rsp),%edx
  81f3c9:	mov    0x50(%rsp),%rdi
  81f3ce:	mov    %edx,0x1c(%rdi)
  81f3d1:	movups 0x24c(%rsp),%xmm0
  81f3d9:	movups %xmm0,0xc(%rdi)
  81f3dd:	mov    %ecx,(%rdi)
  81f3df:	mov    %rax,0x4(%rdi)
  81f3e3:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3e8:	movzbl 0x68(%rsp),%r8d
  81f3ee:	and    $0x1,%r8d
  81f3f2:	lea    0x130(%rsp),%rdi
  81f3fa:	mov    0x8(%rsp),%rsi
  81f3ff:	mov    0xa0(%rsp),%rdx
  81f407:	mov    0x100(%rsp),%rcx
  81f40f:	call   81d810 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f414:	mov    0x130(%rsp),%eax
  81f41b:	cmp    $0xffffffff,%eax
  81f41e:	je     81f47b <<gpui_gpu::renderer::RendererState>::render+0x13cb>
  81f420:	mov    0x134(%rsp),%ecx
  81f427:	mov    0x138(%rsp),%rdx
  81f42f:	movupd 0x140(%rsp),%xmm0
  81f438:	mov    0x50(%rsp),%rdi
  81f43d:	movupd %xmm0,0x10(%rdi)
  81f442:	mov    %eax,(%rdi)
  81f444:	mov    %ecx,0x4(%rdi)
  81f447:	mov    %rdx,0x8(%rdi)
  81f44b:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f450:	mov    0x14c(%rsp),%ecx
  81f457:	mov    0x50(%rsp),%rdi
  81f45c:	mov    %ecx,0x1c(%rdi)
  81f45f:	movups 0x13c(%rsp),%xmm0
  81f467:	movups %xmm0,0xc(%rdi)
  81f46b:	mov    %eax,(%rdi)
  81f46d:	mov    0x40(%rsp),%rax
  81f472:	mov    %rax,0x4(%rdi)
  81f476:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f47b:	mov    0x138(%rsp),%rax
  81f483:	mov    %rax,0x2c8(%rsp)
  81f48b:	mov    0x8(%rsp),%rax
  81f490:	mov    0x28(%rax),%rax
  81f494:	movq   $0x0,0x220(%rsp)
  81f4a0:	test   %rax,%rax
  81f4a3:	je     81f548 <<gpui_gpu::renderer::RendererState>::render+0x1498>
  81f4a9:	mov    0x8(%rsp),%rcx
  81f4ae:	mov    0x20(%rcx),%rcx
  81f4b2:	shl    $0x3,%rax
  81f4b6:	xor    %edi,%edi
  81f4b8:	jmp    81f4f9 <<gpui_gpu::renderer::RendererState>::render+0x1449>
  81f4ba:	and    $0x40000000,%edx
  81f4c0:	mov    0x220(%rsp),%r9
  81f4c8:	add    %esi,%r9d
  81f4cb:	xor    %esi,%esi
  81f4cd:	test   %r8d,%r8d
  81f4d0:	setne  %sil
  81f4d4:	shl    $0x1d,%esi
  81f4d7:	or     %r9d,%edx
  81f4da:	or     %esi,%edx
  81f4dc:	mov    %r9,0x220(%rsp)
  81f4e4:	mov    %r9d,(%rcx,%rdi,8)
  81f4e8:	mov    %edx,%r9d
  81f4eb:	mov    %r9d,0x4(%rcx,%rdi,8)
  81f4f0:	inc    %rdi
  81f4f3:	add    $0xfffffffffffffff8,%rax
  81f4f7:	je     81f536 <<gpui_gpu::renderer::RendererState>::render+0x1486>
  81f4f9:	mov    0x8(%rsp),%rdx
  81f4fe:	mov    0x58(%rdx),%rsi
  81f502:	cmp    %rsi,%rdi
  81f505:	jae    820478 <<gpui_gpu::renderer::RendererState>::render+0x23c8>
  81f50b:	mov    0x4(%rcx,%rdi,8),%edx
  81f50f:	mov    %edx,%esi
  81f511:	and    $0xbfffffff,%esi
  81f517:	mov    0x8(%rsp),%r8
  81f51c:	mov    0x50(%r8),%r8
  81f520:	mov    (%r8,%rdi,4),%r8d
  81f524:	cmp    $0x1,%esi
  81f527:	jne    81f4ba <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f529:	mov    $0x80000000,%r9d
  81f52f:	test   %r8d,%r8d
  81f532:	jne    81f4eb <<gpui_gpu::renderer::RendererState>::render+0x143b>
  81f534:	jmp    81f4ba <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f536:	mov    0x220(%rsp),%rax
  81f53e:	mov    %eax,%eax
  81f540:	mov    %rax,0x220(%rsp)
  81f548:	mov    0x8(%rsp),%rax
  81f54d:	lea    0x30(%rax),%rdi
  81f551:	movq   $0x0,0x40(%rax)
  81f559:	mov    %rdi,0xd8(%rsp)
  81f561:	mov    0x220(%rsp),%rsi
  81f569:	xor    %edx,%edx
  81f56b:	call   823940 <<alloc::vec::Vec<u32>>::resize>
  81f570:	mov    0x88(%rsp),%rax
  81f578:	mov    %rax,0x360(%rsp)
  81f580:	mov    0x100(%rsp),%rax
  81f588:	mov    %rax,0x368(%rsp)
  81f590:	movq   $0x0,0x370(%rsp)
  81f59c:	mov    0x108(%rsp),%rax
  81f5a4:	mov    %rax,0x378(%rsp)
  81f5ac:	mov    0x340(%rsp),%rax
  81f5b4:	mov    %rax,0x380(%rsp)
  81f5bc:	mov    0x30(%rsp),%eax
  81f5c0:	mov    %eax,0x388(%rsp)
  81f5c7:	lea    0x408(%rsp),%rdi
  81f5cf:	lea    0x368(%rsp),%rsi
  81f5d7:	call   *0x661c4b(%rip)        # e81228 <_DYNAMIC+0x5c8>
  81f5dd:	mov    0x408(%rsp),%rax
  81f5e5:	mov    %rax,0x80(%rsp)
  81f5ed:	test   %rax,%rax
  81f5f0:	je     81fb78 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f5f6:	mov    0x8(%rsp),%rax
  81f5fb:	add    $0x120,%rax
  81f601:	mov    %rax,0x470(%rsp)
  81f609:	mov    0x2b8(%rsp),%rax
  81f611:	mov    %rax,0xb0(%rsp)
  81f619:	jmp    81f64a <<gpui_gpu::renderer::RendererState>::render+0x159a>
  81f61b:	lea    0x408(%rsp),%rdi
  81f623:	lea    0x368(%rsp),%rsi
  81f62b:	call   *0x661bf7(%rip)        # e81228 <_DYNAMIC+0x5c8>
  81f631:	mov    0x408(%rsp),%rax
  81f639:	mov    %rax,0x80(%rsp)
  81f641:	test   %rax,%rax
  81f644:	je     81fb78 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f64a:	lea    0x420(%rsp),%rsi
  81f652:	movups (%rsi),%xmm0
  81f655:	movups 0x10(%rsi),%xmm1
  81f659:	movups 0x20(%rsi),%xmm2
  81f65d:	movaps %xmm2,0x3c0(%rsp)
  81f665:	movaps %xmm1,0x3b0(%rsp)
  81f66d:	movaps %xmm0,0x3a0(%rsp)
  81f675:	lea    0x450(%rsp),%rdx
  81f67d:	movups (%rdx),%xmm0
  81f680:	movaps %xmm0,0x320(%rsp)
  81f688:	movdqu 0x40(%rsi),%xmm0
  81f68d:	movdqa %xmm0,0x330(%rsp)
  81f696:	mov    0x410(%rsp),%rax
  81f69e:	mov    %rax,0xe0(%rsp)
  81f6a6:	mov    0x418(%rsp),%rbx
  81f6ae:	mov    0x8(%rsp),%rdi
  81f6b3:	call   81d430 <<gpui_gpu::renderer::RendererState>::correction>
  81f6b8:	mov    %eax,0x300(%rsp)
  81f6bf:	test   %rbx,%rbx
  81f6c2:	je     81f61b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f6c8:	mov    %rbx,%rcx
  81f6cb:	shl    $0x2,%rcx
  81f6cf:	mov    0x300(%rsp),%eax
  81f6d6:	shl    $0xf,%eax
  81f6d9:	mov    %eax,0x20(%rsp)
  81f6dd:	mov    0xb0(%rsp),%rax
  81f6e5:	shl    $0x4,%rax
  81f6e9:	mov    %rax,0x28(%rsp)
  81f6ee:	lea    0x138(%rsp),%rbx
  81f6f6:	lea    0x130(%rsp),%r13
  81f6fe:	jmp    81f8c7 <<gpui_gpu::renderer::RendererState>::render+0x1817>
  81f703:	mov    0x60(%rsp),%r9d
  81f708:	or     0x20(%rsp),%r9d
  81f70d:	mov    %r9d,0x60(%rsp)
  81f712:	mov    0x64(%rsp),%r8d
  81f717:	mov    %edi,0x130(%rsp)
  81f71e:	mov    %r9d,0x134(%rsp)
  81f726:	mov    %r8d,0x138(%rsp)
  81f72e:	mov    %eax,0x13c(%rsp)
  81f735:	lea    0x230(%rsp),%rdi
  81f73d:	mov    %rbx,%r8
  81f740:	call   81b6c0 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f745:	add    $0xfffffffffffffffe,%r13
  81f749:	mov    %r13,0xb0(%rsp)
  81f751:	mov    %r13d,0x2ec(%rsp)
  81f759:	movaps 0x260(%rsp),%xmm0
  81f761:	movlps %xmm0,0x170(%rsp)
  81f769:	movaps 0x3a0(%rsp),%xmm0
  81f771:	movaps 0x3b0(%rsp),%xmm1
  81f779:	movaps 0x3c0(%rsp),%xmm2
  81f781:	lea    0x178(%rsp),%rax
  81f789:	movups %xmm2,0x20(%rax)
  81f78d:	movups %xmm1,0x10(%rax)
  81f791:	movups %xmm0,(%rax)
  81f794:	movaps 0x320(%rsp),%xmm0
  81f79c:	movups %xmm0,0x30(%rax)
  81f7a0:	movaps 0x490(%rsp),%xmm0
  81f7a8:	movups %xmm0,0x40(%rax)
  81f7ac:	movaps 0x330(%rsp),%xmm0
  81f7b4:	movups %xmm0,0x50(%rax)
  81f7b8:	mov    0x128(%rsp),%eax
  81f7bf:	mov    %al,0x130(%rsp)
  81f7c6:	movzbl 0x30(%rsp),%eax
  81f7cb:	mov    %al,0x131(%rsp)
  81f7d2:	movzwl 0xa8(%rsp),%eax
  81f7da:	mov    %ax,0x132(%rsp)
  81f7e2:	movaps 0xc0(%rsp),%xmm0
  81f7ea:	movss  %xmm0,0x134(%rsp)
  81f7f3:	mov    0x250(%rsp),%rax
  81f7fb:	mov    %rbx,%r13
  81f7fe:	lea    0x138(%rsp),%rbx
  81f806:	mov    %rax,0x10(%rbx)
  81f80a:	movaps 0x240(%rsp),%xmm0
  81f812:	movups %xmm0,(%rbx)
  81f815:	mov    0x10(%rsp),%rax
  81f81a:	mov    %rax,0x150(%rsp)
  81f822:	mov    0x40(%rsp),%eax
  81f826:	mov    %eax,0x158(%rsp)
  81f82d:	mov    0x70(%rsp),%eax
  81f831:	mov    %eax,0x15c(%rsp)
  81f838:	movdqa 0x310(%rsp),%xmm0
  81f841:	movdqu %xmm0,0x160(%rsp)
  81f84a:	mov    0x4c8(%rsp),%rax
  81f852:	mov    %rax,0x270(%rsp)
  81f85a:	mov    0xd8(%rsp),%rax
  81f862:	mov    %rax,0x278(%rsp)
  81f86a:	mov    0x4c0(%rsp),%rax
  81f872:	mov    %rax,0x280(%rsp)
  81f87a:	lea    0x360(%rsp),%rax
  81f882:	mov    %rax,0x288(%rsp)
  81f88a:	lea    0x2ec(%rsp),%rax
  81f892:	mov    %rax,0x290(%rsp)
  81f89a:	mov    %r13,%rdi
  81f89d:	mov    0x90(%rsp),%rsi
  81f8a5:	lea    0x270(%rsp),%rdx
  81f8ad:	call   81c560 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f8b2:	addq   $0xffffffffffffffe0,0x28(%rsp)
  81f8b8:	mov    0x68(%rsp),%rcx
  81f8bd:	add    $0xfffffffffffffffc,%rcx
  81f8c1:	je     81f61b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f8c7:	mov    0xe0(%rsp),%rax
  81f8cf:	mov    %rcx,0x68(%rsp)
  81f8d4:	mov    -0x4(%rax,%rcx,1),%edx
  81f8d8:	mov    %r13,%rdi
  81f8db:	mov    0x80(%rsp),%rsi
  81f8e3:	call   81c8c0 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f8e8:	movzbl 0x130(%rsp),%ecx
  81f8f0:	movzbl 0x131(%rsp),%eax
  81f8f8:	mov    %al,0x30(%rsp)
  81f8fc:	movzwl 0x132(%rsp),%eax
  81f904:	mov    %ax,0xa8(%rsp)
  81f90c:	movss  0x134(%rsp),%xmm4
  81f915:	mov    0x10(%rbx),%rax
  81f919:	mov    %rax,0x250(%rsp)
  81f921:	movups (%rbx),%xmm0
  81f924:	movaps %xmm0,0x240(%rsp)
  81f92c:	mov    0x150(%rsp),%rax
  81f934:	mov    %rax,0x10(%rsp)
  81f939:	mov    0x158(%rsp),%eax
  81f940:	mov    %eax,0x40(%rsp)
  81f944:	mov    0x15c(%rsp),%eax
  81f94b:	mov    %eax,0x70(%rsp)
  81f94f:	movups 0x160(%rsp),%xmm0
  81f957:	movaps %xmm0,0x310(%rsp)
  81f95f:	mov    0x160(%rsp),%rax
  81f967:	movsd  0x170(%rsp),%xmm5
  81f970:	lea    0x178(%rsp),%rdx
  81f978:	movups (%rdx),%xmm0
  81f97b:	movaps %xmm0,0x490(%rsp)
  81f983:	decq   0x360(%rsp)
  81f98b:	cmp    $0x1,%ecx
  81f98e:	mov    %ecx,0x128(%rsp)
  81f995:	movaps %xmm4,0xc0(%rsp)
  81f99d:	movaps %xmm5,0x260(%rsp)
  81f9a5:	je     81fa0b <<gpui_gpu::renderer::RendererState>::render+0x195b>
  81f9a7:	cmp    $0x3,%ecx
  81f9aa:	jne    81fa87 <<gpui_gpu::renderer::RendererState>::render+0x19d7>
  81f9b0:	mov    0x480(%rsp),%rax
  81f9b8:	mov    (%rax),%rdi
  81f9bb:	test   %rdi,%rdi
  81f9be:	je     82042b <<gpui_gpu::renderer::RendererState>::render+0x237b>
  81f9c4:	movzbl 0x30(%rsp),%edx
  81f9c9:	mov    0x10(%rsp),%rsi
  81f9ce:	call   823630 <<gpui_gpu::renderer::images::Images>::metadata>
  81f9d3:	mov    %eax,%ecx
  81f9d5:	shr    $0x20,%rax
  81f9d9:	mov    %eax,%edx
  81f9db:	or     $0x10,%edx
  81f9de:	xorps  %xmm0,%xmm0
  81f9e1:	movaps 0xc0(%rsp),%xmm1
  81f9e9:	ucomiss %xmm0,%xmm1
  81f9ec:	cmovne %edx,%eax
  81f9ef:	cmovp  %edx,%eax
  81f9f2:	mov    0x70(%rsp),%edx
  81f9f6:	shl    $0x10,%edx
  81f9f9:	or     0x40(%rsp),%edx
  81f9fd:	mov    %ecx,0x5c(%rsp)
  81fa01:	mov    %eax,0x60(%rsp)
  81fa05:	mov    %edx,0x64(%rsp)
  81fa09:	jmp    81fa7a <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  81fa0b:	movaps %xmm5,%xmm0
  81fa0e:	movss  -0x770a4a(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81fa16:	mulss  %xmm3,%xmm0
  81fa1a:	movaps %xmm4,%xmm1
  81fa1d:	minss  %xmm0,%xmm1
  81fa21:	movaps %xmm1,%xmm0
  81fa24:	cmpunordss %xmm1,%xmm0
  81fa29:	movaps %xmm0,%xmm2
  81fa2c:	andnps %xmm1,%xmm2
  81fa2f:	andps  %xmm4,%xmm0
  81fa32:	orps   %xmm2,%xmm0
  81fa35:	movaps %xmm5,%xmm1
  81fa38:	shufps $0x55,%xmm5,%xmm1
  81fa3c:	mulss  %xmm3,%xmm1
  81fa40:	movaps %xmm0,%xmm2
  81fa43:	minss  %xmm1,%xmm2
  81fa47:	movaps %xmm2,%xmm1
  81fa4a:	cmpunordss %xmm2,%xmm1
  81fa4f:	andps  %xmm1,%xmm0
  81fa52:	andnps %xmm2,%xmm1
  81fa55:	orps   %xmm0,%xmm1
  81fa58:	movd   %xmm1,%eax
  81fa5c:	and    $0xff800000,%eax
  81fa61:	mov    $0x7f000000,%ecx
  81fa66:	sub    %eax,%ecx
  81fa68:	movl   $0x40000000,0x5c(%rsp)
  81fa70:	movss  %xmm1,0x60(%rsp)
  81fa76:	mov    %ecx,0x64(%rsp)
  81fa7a:	lea    0x130(%rsp),%rbx
  81fa82:	jmp    81fb21 <<gpui_gpu::renderer::RendererState>::render+0x1a71>
  81fa87:	cmp    $0x2,%cl
  81fa8a:	jne    81fad9 <<gpui_gpu::renderer::RendererState>::render+0x1a29>
  81fa8c:	mov    0x250(%rsp),%rcx
  81fa94:	mov    %rcx,0x140(%rsp)
  81fa9c:	movaps 0x240(%rsp),%xmm0
  81faa4:	movaps %xmm0,0x130(%rsp)
  81faac:	mov    0x10(%rsp),%rcx
  81fab1:	mov    %rcx,0x148(%rsp)
  81fab9:	mov    0x40(%rsp),%ecx
  81fabd:	mov    %ecx,0x150(%rsp)
  81fac4:	mov    0x70(%rsp),%ecx
  81fac8:	mov    %ecx,0x154(%rsp)
  81facf:	mov    %rax,0x158(%rsp)
  81fad7:	jmp    81fae5 <<gpui_gpu::renderer::RendererState>::render+0x1a35>
  81fad9:	movq   $0x0,0x130(%rsp)
  81fae5:	movl   $0x0,0x278(%rsp)
  81faf0:	movq   $0x0,0x270(%rsp)
  81fafc:	lea    0x5c(%rsp),%rdi
  81fb01:	lea    0x130(%rsp),%rbx
  81fb09:	mov    %rbx,%rsi
  81fb0c:	lea    0x270(%rsp),%rdx
  81fb14:	mov    0x470(%rsp),%rcx
  81fb1c:	call   81b570 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fb21:	mov    0xb0(%rsp),%r13
  81fb29:	lea    -0x1(%r13),%rcx
  81fb2d:	mov    0x8(%rsp),%rax
  81fb32:	mov    0x10(%rax),%rdx
  81fb36:	cmp    %rdx,%rcx
  81fb39:	jae    82044c <<gpui_gpu::renderer::RendererState>::render+0x239c>
  81fb3f:	mov    0x8(%rax),%rsi
  81fb43:	mov    0x28(%rsp),%rax
  81fb48:	mov    -0x4(%rsi,%rax,1),%eax
  81fb4c:	mov    0x5c(%rsp),%edi
  81fb50:	cmp    $0x40000000,%edi
  81fb56:	jne    81f703 <<gpui_gpu::renderer::RendererState>::render+0x1653>
  81fb5c:	mov    0x64(%rsp),%r8d
  81fb61:	or     0x300(%rsp),%r8d
  81fb69:	mov    %r8d,0x64(%rsp)
  81fb6e:	mov    0x60(%rsp),%r9d
  81fb73:	jmp    81f717 <<gpui_gpu::renderer::RendererState>::render+0x1667>
  81fb78:	mov    0x8(%rsp),%rax
  81fb7d:	mov    0x28(%rax),%rdi
  81fb81:	xor    %ebx,%ebx
  81fb83:	test   %rdi,%rdi
  81fb86:	je     81fc95 <<gpui_gpu::renderer::RendererState>::render+0x1be5>
  81fb8c:	mov    0x8(%rsp),%rax
  81fb91:	mov    0x20(%rax),%r8
  81fb95:	shl    $0x3,%rdi
  81fb99:	cmpl   $0x0,0x90(%rsp)
  81fba1:	je     81fe90 <<gpui_gpu::renderer::RendererState>::render+0x1de0>
  81fba7:	movq   $0x0,0x40(%rsp)
  81fbb0:	movq   $0x0,0x70(%rsp)
  81fbb9:	movq   $0x0,0x10(%rsp)
  81fbc2:	xor    %r10d,%r10d
  81fbc5:	xor    %ecx,%ecx
  81fbc7:	jmp    81fbef <<gpui_gpu::renderer::RendererState>::render+0x1b3f>
  81fbc9:	incq   0x10(%rsp)
  81fbce:	inc    %r10
  81fbd1:	cmp    0x90(%rsp),%r10
  81fbd9:	mov    $0x0,%eax
  81fbde:	cmove  %rax,%r10
  81fbe2:	inc    %rcx
  81fbe5:	add    $0xfffffffffffffff8,%rdi
  81fbe9:	je     81fcb0 <<gpui_gpu::renderer::RendererState>::render+0x1c00>
  81fbef:	mov    0x4(%r8,%rcx,8),%r11d
  81fbf4:	mov    $0x80000000,%eax
  81fbf9:	cmp    %rax,%r11
  81fbfc:	je     81fbc9 <<gpui_gpu::renderer::RendererState>::render+0x1b19>
  81fbfe:	mov    %r11d,%esi
  81fc01:	and    $0x1fffffff,%esi
  81fc07:	sub    (%r8,%rcx,8),%esi
  81fc0b:	je     81fbce <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc0d:	mov    %rcx,%rax
  81fc10:	shr    $0x20,%rax
  81fc14:	je     81fc28 <<gpui_gpu::renderer::RendererState>::render+0x1b78>
  81fc16:	mov    %rcx,%rax
  81fc19:	xor    %edx,%edx
  81fc1b:	divq   0x90(%rsp)
  81fc23:	mov    %r10,%rdx
  81fc26:	jmp    81fc33 <<gpui_gpu::renderer::RendererState>::render+0x1b83>
  81fc28:	mov    %ecx,%eax
  81fc2a:	xor    %edx,%edx
  81fc2c:	divl   0x90(%rsp)
  81fc33:	shl    $0x4,%edx
  81fc36:	shl    $0x4,%eax
  81fc39:	lea    0x10(%rdx),%r13d
  81fc3d:	cmp    %r13d,%r14d
  81fc40:	cmovb  %r14d,%r13d
  81fc44:	lea    0x10(%rax),%r9d
  81fc48:	cmp    %r9d,%r15d
  81fc4b:	cmovb  %r15d,%r9d
  81fc4f:	sub    %edx,%r13d
  81fc52:	sub    %eax,%r9d
  81fc55:	imul   %r13d,%r9d
  81fc59:	mov    %r9,%rax
  81fc5c:	shl    $0x4,%rax
  81fc60:	test   $0x40000000,%r11d
  81fc67:	cmovne %r9,%rax
  81fc6b:	shr    $0x1d,%r11d
  81fc6f:	and    $0x1,%r11d
  81fc73:	add    %rax,0x70(%rsp)
  81fc78:	imul   %r11,%r9
  81fc7c:	sub    %r11,%rsi
  81fc7f:	imul   %rax,%rsi
  81fc83:	add    0x40(%rsp),%r9
  81fc88:	add    %rsi,%r9
  81fc8b:	mov    %r9,0x40(%rsp)
  81fc90:	jmp    81fbce <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc95:	movq   $0x0,0x10(%rsp)
  81fc9e:	movq   $0x0,0x70(%rsp)
  81fca7:	movq   $0x0,0x40(%rsp)
  81fcb0:	test   $0x1,%bpl
  81fcb4:	je     81fd01 <<gpui_gpu::renderer::RendererState>::render+0x1c51>
  81fcb6:	movd   0x2e8(%rsp),%xmm0
  81fcbf:	movd   %xmm0,%eax
  81fcc3:	test   %eax,%eax
  81fcc5:	setns  %cl
  81fcc8:	mov    %eax,%edx
  81fcca:	and    $0x7fffffff,%edx
  81fcd0:	add    $0xff800000,%edx
  81fcd6:	cmp    $0x7f000000,%edx
  81fcdc:	setb   %dl
  81fcdf:	and    %cl,%dl
  81fce1:	dec    %eax
  81fce3:	cmp    $0x7fffff,%eax
  81fce8:	setb   %al
  81fceb:	or     %dl,%al
  81fced:	mov    $0x2,%ebx
  81fcf2:	movd   %xmm0,0xf4(%rsp)
  81fcfb:	je     81fe86 <<gpui_gpu::renderer::RendererState>::render+0x1dd6>
  81fd01:	mov    0x120(%rsp),%rax
  81fd09:	add    $0x18,%rax
  81fd0d:	xor    %ecx,%ecx
  81fd0f:	cmpl   $0x28,0x2e4(%rsp)
  81fd17:	sete   %cl
  81fd1a:	and    $0x1,%r12d
  81fd1e:	lea    (%r12,%rcx,4),%ecx
  81fd22:	or     %ebx,%ecx
  81fd24:	movups (%rax),%xmm0
  81fd27:	movups %xmm0,0x418(%rsp)
  81fd2f:	mov    %r14d,0x408(%rsp)
  81fd37:	mov    %r15d,0x40c(%rsp)
  81fd3f:	mov    0x90(%rsp),%rax
  81fd47:	mov    %eax,0x410(%rsp)
  81fd4e:	mov    %ecx,0x414(%rsp)
  81fd55:	movss  0xf4(%rsp),%xmm0
  81fd5e:	movss  %xmm0,0x428(%rsp)
  81fd67:	mov    0x110(%rsp),%rax
  81fd6f:	mov    %eax,0x42c(%rsp)
  81fd76:	movq   $0x0,0x430(%rsp)
  81fd82:	mov    0x8(%rsp),%rax
  81fd87:	lea    0x230(%rax),%rsi
  81fd8e:	lea    0x408(%rsp),%rcx
  81fd96:	mov    $0x30,%r8d
  81fd9c:	mov    0x2f0(%rsp),%rdi
  81fda4:	mov    %rsi,0x30(%rsp)
  81fda9:	xor    %edx,%edx
  81fdab:	call   *0x66147f(%rip)        # e81230 <_DYNAMIC+0x5d0>
  81fdb1:	mov    0x2b8(%rsp),%rbx
  81fdb9:	shl    $0x4,%rbx
  81fdbd:	mov    0x98(%rsp),%rdi
  81fdc5:	mov    0xa0(%rsp),%rsi
  81fdcd:	mov    %rbx,%rdx
  81fdd0:	call   81cc10 <<gpui_gpu::renderer::Buffer>::reserve>
  81fdd5:	cmpq   $0x0,0x38(%rsp)
  81fddb:	je     81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fddd:	mov    0x2b8(%rsp),%rcx
  81fde5:	cmp    %rcx,0x348(%rsp)
  81fded:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdef:	test   %al,%al
  81fdf1:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdf3:	testb  $0x1,0x390(%rsp)
  81fdfb:	jne    81fe53 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fdfd:	mov    0x2d8(%rsp),%rax
  81fe05:	mov    0x230(%rsp),%rbx
  81fe0d:	mov    0x238(%rsp),%rsi
  81fe15:	cmp    %rbx,%rax
  81fe18:	jne    81fedc <<gpui_gpu::renderer::RendererState>::render+0x1e2c>
  81fe1e:	mov    %rsi,0x2d8(%rsp)
  81fe26:	movq   $0xffffffffffffffff,0x230(%rsp)
  81fe32:	movq   $0x0,0x238(%rsp)
  81fe3e:	mov    $0xffffffffffffffff,%rbx
  81fe45:	movq   $0x0,0x38(%rsp)
  81fe4e:	jmp    81fee4 <<gpui_gpu::renderer::RendererState>::render+0x1e34>
  81fe53:	mov    0x8(%rsp),%rax
  81fe58:	mov    0x8(%rax),%rcx
  81fe5c:	mov    0x10(%rax),%r8
  81fe60:	shl    $0x4,%r8
  81fe64:	mov    0x98(%rsp),%rdi
  81fe6c:	mov    0xa0(%rsp),%rsi
  81fe74:	mov    0x2f0(%rsp),%rdx
  81fe7c:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81fe81:	jmp    81ff42 <<gpui_gpu::renderer::RendererState>::render+0x1e92>
  81fe86:	mov    0x50(%rsp),%rdi
  81fe8b:	jmp    81e251 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81fe90:	movq   $0x0,0x70(%rsp)
  81fe99:	xor    %eax,%eax
  81fe9b:	movq   $0x0,0x10(%rsp)
  81fea4:	jmp    81feb8 <<gpui_gpu::renderer::RendererState>::render+0x1e08>
  81fea6:	incq   0x10(%rsp)
  81feab:	add    $0x8,%rax
  81feaf:	cmp    %rax,%rdi
  81feb2:	je     81fca7 <<gpui_gpu::renderer::RendererState>::render+0x1bf7>
  81feb8:	mov    0x4(%r8,%rax,1),%ecx
  81febd:	mov    %ecx,%edx
  81febf:	neg    %edx
  81fec1:	jo     81fea6 <<gpui_gpu::renderer::RendererState>::render+0x1df6>
  81fec3:	and    $0x1fffffff,%ecx
  81fec9:	cmp    %ecx,(%r8,%rax,1)
  81fecd:	je     81feab <<gpui_gpu::renderer::RendererState>::render+0x1dfb>
  81fecf:	lea    0x60f9da(%rip),%rdi        # e2f8b0 <anon.7e34a6dced7fe4eb77116889a7de5f31.41.llvm.6877253771164693793>
  81fed6:	call   *0x66135c(%rip)        # e81238 <_DYNAMIC+0x5d8>
  81fedc:	mov    %rsi,0x38(%rsp)
  81fee1:	mov    %rax,%rsi
  81fee4:	mov    0x8(%rsp),%r13
  81fee9:	mov    0x8(%r13),%rdx
  81feed:	mov    0x10(%r13),%rcx
  81fef1:	mov    0x2d0(%rsp),%rdi
  81fef9:	mov    0x98(%rsp),%rbp
  81ff01:	mov    %rbp,%r8
  81ff04:	mov    0x2f0(%rsp),%r12
  81ff0c:	mov    %r12,%r9
  81ff0f:	call   81cb60 <<gpui_gpu::renderer::Changes>::upload>
  81ff14:	mov    %rax,0xc0(%rsp)
  81ff1c:	mov    0x8(%r13),%rdx
  81ff20:	mov    0x10(%r13),%rcx
  81ff24:	mov    %rbx,%rdi
  81ff27:	mov    0x38(%rsp),%rsi
  81ff2c:	mov    %rbp,%r8
  81ff2f:	mov    %r12,%r9
  81ff32:	call   81cb60 <<gpui_gpu::renderer::Changes>::upload>
  81ff37:	mov    %rax,%rbx
  81ff3a:	add    0xc0(%rsp),%rbx
  81ff42:	mov    0xa0(%rsp),%r13
  81ff4a:	lea    0x18(%r13),%rax
  81ff4e:	mov    %rax,0x38(%rsp)
  81ff53:	mov    0x8(%rsp),%rbp
  81ff58:	lea    0x280(%rbp),%rdi
  81ff5f:	mov    0x20(%rbp),%rcx
  81ff63:	mov    0x28(%rbp),%r8
  81ff67:	shl    $0x3,%r8
  81ff6b:	mov    %rdi,0xc0(%rsp)
  81ff73:	mov    %r13,%rsi
  81ff76:	mov    0x2f0(%rsp),%r12
  81ff7e:	mov    %r12,%rdx
  81ff81:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ff86:	lea    0x2a8(%rbp),%rdi
  81ff8d:	mov    0x38(%rbp),%rcx
  81ff91:	mov    0x40(%rbp),%r8
  81ff95:	shl    $0x2,%r8
  81ff99:	mov    %rdi,0xb0(%rsp)
  81ffa1:	mov    %r13,%rsi
  81ffa4:	mov    %r12,%rdx
  81ffa7:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ffac:	lea    0x2d0(%rbp),%rdi
  81ffb3:	mov    0x68(%rbp),%rcx
  81ffb7:	mov    0x70(%rbp),%r8
  81ffbb:	shl    $0x5,%r8
  81ffbf:	mov    %rdi,0x28(%rsp)
  81ffc4:	mov    %r13,%rsi
  81ffc7:	mov    %r12,%rdx
  81ffca:	call   81cbc0 <<gpui_gpu::renderer::Buffer>::write>
  81ffcf:	cmpq   $0x0,0x328(%rbp)
  81ffd7:	je     81ffdd <<gpui_gpu::renderer::RendererState>::render+0x1f2d>
  81ffd9:	xor    %eax,%eax
  81ffdb:	jmp    81fff2 <<gpui_gpu::renderer::RendererState>::render+0x1f42>
  81ffdd:	mov    0x8(%rsp),%rax
  81ffe2:	mov    0x10(%rax),%rax
  81ffe6:	cmp    $0x1,%rax
  81ffea:	adc    $0x0,%rax
  81ffee:	shl    $0x4,%rax
  81fff2:	mov    0x8(%rsp),%rdi
  81fff7:	mov    0x28(%rdi),%rsi
  81fffb:	mov    0x40(%rdi),%rcx
  81ffff:	cmp    $0x1,%rsi
  820003:	adc    $0x0,%rsi
  820007:	shl    $0x3,%rsi
  82000b:	cmp    $0x1,%rcx
  82000f:	adc    $0x0,%rcx
  820013:	mov    0x70(%rdi),%rdx
  820017:	cmp    $0x1,%rdx
  82001b:	adc    $0x0,%rdx
  82001f:	add    $0xc8,%rdi
  820026:	shl    $0x2,%rcx
  82002a:	shl    $0x5,%rdx
  82002e:	movq   $0x0,0x130(%rsp)
  82003a:	mov    0x30(%rsp),%r8
  82003f:	mov    %r8,0x138(%rsp)
  820047:	movq   $0x0,0x158(%rsp)
  820053:	xorpd  %xmm0,%xmm0
  820057:	movupd %xmm0,0x140(%rsp)
  820060:	movl   $0x0,0x150(%rsp)
  82006b:	mov    0x98(%rsp),%r8
  820073:	mov    %r8,0x160(%rsp)
  82007b:	movq   $0x0,0x168(%rsp)
  820087:	mov    %rax,0x170(%rsp)
  82008f:	movl   $0x1,0x178(%rsp)
  82009a:	movq   $0x0,0x180(%rsp)
  8200a6:	mov    0xc0(%rsp),%rax
  8200ae:	mov    %rax,0x188(%rsp)
  8200b6:	movq   $0x0,0x190(%rsp)
  8200c2:	mov    %rsi,0x198(%rsp)
  8200ca:	movl   $0x2,0x1a0(%rsp)
  8200d5:	movq   $0x0,0x1a8(%rsp)
  8200e1:	mov    0xb0(%rsp),%rax
  8200e9:	mov    %rax,0x1b0(%rsp)
  8200f1:	movq   $0x0,0x1b8(%rsp)
  8200fd:	mov    %rcx,0x1c0(%rsp)
  820105:	movl   $0x3,0x1c8(%rsp)
  820110:	movq   $0x4,0x1d0(%rsp)
  82011c:	mov    %rdi,0x1d8(%rsp)
  820124:	movl   $0x4,0x1f0(%rsp)
  82012f:	movq   $0x0,0x1f8(%rsp)
  82013b:	mov    0x28(%rsp),%rax
  820140:	mov    %rax,0x200(%rsp)
  820148:	movq   $0x0,0x208(%rsp)
  820154:	mov    %rdx,0x210(%rsp)
  82015c:	movl   $0x5,0x218(%rsp)
  820167:	lea    -0x74b5ae(%rip),%rax        # d4bc0 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82016e:	mov    %rax,0x3b8(%rsp)
  820176:	movq   $0xa,0x3c0(%rsp)
  820182:	mov    0x38(%rsp),%rax
  820187:	mov    %rax,0x3a0(%rsp)
  82018f:	lea    0x130(%rsp),%rax
  820197:	mov    %rax,0x3a8(%rsp)
  82019f:	movq   $0x6,0x3b0(%rsp)
  8201ab:	lea    0x3a0(%rsp),%rsi
  8201b3:	mov    0xa0(%rsp),%r13
  8201bb:	mov    %r13,%rdi
  8201be:	call   *0x66107c(%rip)        # e81240 <_DYNAMIC+0x5e0>
  8201c4:	mov    %rax,%rbp
  8201c7:	mov    %rax,0x270(%rsp)
  8201cf:	lea    0x270(%rsp),%rdx
  8201d7:	mov    %r13,%rdi
  8201da:	mov    0x4b8(%rsp),%rsi
  8201e2:	call   81d250 <<gpui_gpu::renderer::GpuContext>::submit>
  8201e7:	mov    %rax,0x38(%rsp)
  8201ec:	xor    %r13d,%r13d
  8201ef:	mov    0x350(%rsp),%rax
  8201f7:	cmp    %rax,0x358(%rsp)
  8201ff:	setne  %r13b
  820203:	shl    $0x1f,%r13d
  820207:	or     %r14d,%r13d
  82020a:	shl    $0x20,%r15
  82020e:	or     %r15,%r13
  820211:	mov    0xe8(%rsp),%rax
  820219:	mov    (%rax),%rax
  82021c:	test   %rax,%rax
  82021f:	je     820235 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820221:	lock decq (%rax)
  820225:	jne    820235 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820227:	mov    0xe8(%rsp),%rdi
  82022f:	call   *0x660f43(%rip)        # e81178 <_DYNAMIC+0x518>
  820235:	mov    0x8(%rsp),%rax
  82023a:	mov    %rbp,0x330(%rax)
  820241:	mov    %r13,0x338(%rax)
  820248:	mov    0x28(%rax),%rsi
  82024c:	mov    0x70(%rax),%rcx
  820250:	mov    %rcx,0xe8(%rsp)
  820258:	mov    0x278(%rax),%rdx
  82025f:	mov    0x220(%rsp),%r8
  820267:	lea    (%rbx,%r8,4),%rdi
  82026b:	lea    (%rdi,%rsi,8),%rsi
  82026f:	mov    %rcx,%rdi
  820272:	shl    $0x5,%rdi
  820276:	lea    (%rdi,%rsi,1),%rcx
  82027a:	add    $0x30,%rcx
  82027e:	mov    %rcx,0x30(%rsp)
  820283:	mov    0x150(%rax),%esi
  820289:	imul   %rsi,%rsi
  82028d:	add    0x250(%rax),%rdx
  820294:	add    0x2a0(%rax),%rdx
  82029b:	add    0x2c8(%rax),%rdx
  8202a2:	add    0x2f0(%rax),%rdx
  8202a9:	mov    0x308(%rax),%rdi
  8202b0:	add    0x310(%rax),%rdi
  8202b7:	mov    0x118(%rsp),%r11
  8202bf:	mov    %r11,%rcx
  8202c2:	sub    %r8,%rcx
  8202c5:	mov    0x88(%rsp),%rbp
  8202cd:	mov    %rbp,%r9
  8202d0:	mov    0x2b0(%rsp),%r13
  8202d8:	sub    %r13,%r9
  8202db:	mov    0x10(%rax),%r10
  8202df:	shl    $0x4,%r10
  8202e3:	mov    0x160(%rax),%rbx
  8202ea:	inc    %rbx
  8202ed:	mov    $0xffffffffffffffff,%r14
  8202f4:	cmovne %rbx,%r14
  8202f8:	mov    (%rax),%rbx
  8202fb:	shl    $0x4,%rbx
  8202ff:	mov    0x48(%rax),%r15
  820303:	add    0x30(%rax),%r15
  820307:	mov    0x18(%rax),%r12
  82030b:	lea    (%rbx,%r12,8),%rbx
  82030f:	lea    (%rbx,%r15,4),%rbx
  820313:	mov    0x60(%rax),%r15
  820317:	shl    $0x5,%r15
  82031b:	add    %rbx,%r15
  82031e:	mov    0x138(%rax),%rbx
  820325:	mov    0x130(%rax),%r12
  82032c:	mov    %r14,0x160(%rax)
  820333:	mov    %rbp,0x168(%rax)
  82033a:	lea    (%r11,%r11,1),%r14
  82033e:	mov    %r14,0x170(%rax)
  820345:	movq   $0x1,0x178(%rax)
  820350:	mov    %rbp,0x180(%rax)
  820357:	mov    %r8,0x188(%rax)
  82035e:	mov    %r11,0x190(%rax)
  820365:	mov    %rcx,0x198(%rax)
  82036c:	mov    0x10(%rsp),%rcx
  820371:	mov    %rcx,0x1a0(%rax)
  820378:	mov    0x70(%rsp),%rcx
  82037d:	mov    %rcx,0x1a8(%rax)
  820384:	mov    0x40(%rsp),%rcx
  820389:	mov    %rcx,0x1b0(%rax)
  820390:	mov    0x30(%rsp),%rcx
  820395:	mov    %rcx,0x1b8(%rax)
  82039c:	mov    %r10,0x1c0(%rax)
  8203a3:	mov    0x2a8(%rsp),%r8
  8203ab:	mov    %r8,0x1c8(%rax)
  8203b2:	mov    %r13,0x1d0(%rax)
  8203b9:	mov    %r9,0x1d8(%rax)
  8203c0:	mov    0x2c8(%rsp),%rcx
  8203c8:	mov    %rcx,0x1e0(%rax)
  8203cf:	mov    %rdx,0x1e8(%rax)
  8203d6:	mov    %rsi,0x1f0(%rax)
  8203dd:	add    %rbx,%r12
  8203e0:	mov    %rbx,0x1f8(%rax)
  8203e7:	mov    %r12,0x200(%rax)
  8203ee:	mov    %r15,0x208(%rax)
  8203f5:	mov    0xe8(%rsp),%rcx
  8203fd:	mov    %rcx,0x210(%rax)
  820404:	mov    %rdi,0x218(%rax)
  82040b:	movb   $0x0,0x220(%rax)
  820412:	mov    0x50(%rsp),%rdi
  820417:	mov    0x38(%rsp),%rax
  82041c:	mov    %rax,0x8(%rdi)
  820420:	movl   $0xffffffff,(%rdi)
  820426:	jmp    81e25f <<gpui_gpu::renderer::RendererState>::render+0x1af>
  82042b:	lea    0x60f26e(%rip),%rdi        # e2f6a0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x18>
  820432:	call   *0x660e10(%rip)        # e81248 <_DYNAMIC+0x5e8>
  820438:	lea    0x60f2c1(%rip),%rcx        # e2f700 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x78>
  82043f:	xor    %edi,%edi
  820441:	mov    0x20(%rsp),%rsi
  820446:	call   *0x660d5c(%rip)        # e811a8 <_DYNAMIC+0x548>
  82044c:	lea    0x60f265(%rip),%rax        # e2f6b8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x30>
  820453:	mov    %rcx,%rdi
  820456:	mov    %rdx,%rsi
  820459:	mov    %rax,%rdx
  82045c:	call   *0x660cf6(%rip)        # e81158 <_DYNAMIC+0x4f8>
  820462:	lea    0x60f27f(%rip),%rax        # e2f6e8 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x60>
  820469:	mov    %rcx,%rdi
  82046c:	mov    %rdx,%rsi
  82046f:	mov    %rax,%rdx
  820472:	call   *0x660ce0(%rip)        # e81158 <_DYNAMIC+0x4f8>
  820478:	lea    0x60f251(%rip),%rdx        # e2f6d0 <anon.7e34a6dced7fe4eb77116889a7de5f31.1.llvm.6877253771164693793+0x48>
  82047f:	call   *0x660cd3(%rip)        # e81158 <_DYNAMIC+0x4f8>
  820485:	mov    %rax,%r14
  820488:	mov    0x8(%rsp),%rax
  82048d:	mov    %rbp,0x330(%rax)
  820494:	mov    %r13,0x338(%rax)
  82049b:	mov    %r14,%rdi
  82049e:	call   e2d970 <_Unwind_Resume@plt>
  8204a3:	mov    %rax,%r14
  8204a6:	lock decq 0x0(%rbp)
  8204ab:	jne    8204d5 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  8204ad:	lea    0x270(%rsp),%rdi
  8204b5:	call   *0x660cbd(%rip)        # e81178 <_DYNAMIC+0x518>
  8204bb:	jmp    8204d5 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  8204bd:	call   *0x6609ed(%rip)        # e80eb0 <_DYNAMIC+0x250>
  8204c3:	mov    %rax,%r14
  8204c6:	mov    0xe8(%rsp),%rax
  8204ce:	movq   $0x0,(%rax)
  8204d5:	mov    %r14,%rdi
  8204d8:	call   e2d970 <_Unwind_Resume@plt>
