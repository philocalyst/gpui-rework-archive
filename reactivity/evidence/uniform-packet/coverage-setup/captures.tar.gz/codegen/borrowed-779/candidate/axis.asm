FUNCTION gpui_gpu::renderer::coverage::axis bytes=1662 frame=344

/tmp/gpui-coverage-borrowed-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825960 <gpui_gpu::renderer::coverage::axis>:
  825960:	push   %r15
  825962:	push   %r14
  825964:	push   %r13
  825966:	push   %r12
  825968:	push   %rbx
  825969:	sub    $0x130,%rsp
  825970:	movq   %xmm4,%r12
  825975:	movabs $0x7fffffffffffffff,%rbx
  82597f:	and    %rbx,%r12
  825982:	mov    $0x2,%al
  825984:	movabs $0x7fefffffffffffff,%r14
  82598e:	cmp    %r14,%r12
  825991:	jg     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825997:	movsd  (%rdi),%xmm11
  82599c:	movsd  0x8(%rdi),%xmm8
  8259a2:	movsd  0x10(%rdi),%xmm9
  8259a8:	xorpd  %xmm10,%xmm10
  8259ad:	ucomisd %xmm10,%xmm4
  8259b2:	jne    8259b6 <gpui_gpu::renderer::coverage::axis+0x56>
  8259b4:	jnp    8259ce <gpui_gpu::renderer::coverage::axis+0x6e>
  8259b6:	lea    -0x1(%r12),%rcx
  8259bb:	movabs $0xfffffffffffff,%rdx
  8259c5:	cmp    %rdx,%rcx
  8259c8:	jb     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  8259ce:	movq   %xmm5,%r15
  8259d3:	and    %rbx,%r15
  8259d6:	cmp    %r14,%r15
  8259d9:	jg     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  8259df:	ucomisd %xmm10,%xmm5
  8259e4:	jne    8259e8 <gpui_gpu::renderer::coverage::axis+0x88>
  8259e6:	jnp    8259ff <gpui_gpu::renderer::coverage::axis+0x9f>
  8259e8:	lea    -0x1(%r15),%rcx
  8259ec:	movabs $0xfffffffffffff,%rdx
  8259f6:	cmp    %rdx,%rcx
  8259f9:	jb     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  8259ff:	movaps %xmm8,0xc0(%rsp)
  825a08:	movsd  %xmm2,0x60(%rsp)
  825a0e:	movsd  %xmm3,0x28(%rsp)
  825a14:	movaps %xmm9,0x80(%rsp)
  825a1d:	movaps %xmm4,0xb0(%rsp)
  825a25:	movsd  %xmm6,0xa8(%rsp)
  825a2e:	movsd  %xmm7,0x30(%rsp)
  825a34:	movaps %xmm5,0x90(%rsp)
  825a3c:	mov    %rsp,%rdi
  825a3f:	movsd  %xmm0,0x38(%rsp)
  825a45:	movsd  %xmm1,0x40(%rsp)
  825a4b:	movapd %xmm11,0x120(%rsp)
  825a55:	movapd %xmm11,%xmm2
  825a5a:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825a5f:	cmpl   $0x1,(%rsp)
  825a63:	jne    825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825a69:	movsd  0x8(%rsp),%xmm0
  825a6f:	movsd  %xmm0,0x20(%rsp)
  825a75:	movsd  0x10(%rsp),%xmm0
  825a7b:	movsd  %xmm0,0x18(%rsp)
  825a81:	mov    %rsp,%rdi
  825a84:	movsd  0x60(%rsp),%xmm0
  825a8a:	movsd  0x28(%rsp),%xmm1
  825a90:	movapd 0xc0(%rsp),%xmm2
  825a99:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825a9e:	cmpb   $0x0,(%rsp)
  825aa2:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825aa8:	movsd  0x8(%rsp),%xmm5
  825aae:	movsd  0x10(%rsp),%xmm4
  825ab4:	xorpd  %xmm2,%xmm2
  825ab8:	ucomisd %xmm2,%xmm5
  825abc:	mov    $0x2,%al
  825abe:	jne    825ae1 <gpui_gpu::renderer::coverage::axis+0x181>
  825ac0:	jp     825ae1 <gpui_gpu::renderer::coverage::axis+0x181>
  825ac2:	ucomisd %xmm2,%xmm4
  825ac6:	jne    825ae1 <gpui_gpu::renderer::coverage::axis+0x181>
  825ac8:	jp     825ae1 <gpui_gpu::renderer::coverage::axis+0x181>
  825aca:	movdqa 0x80(%rsp),%xmm2
  825ad3:	movsd  0x18(%rsp),%xmm1
  825ad9:	movsd  0x20(%rsp),%xmm0
  825adf:	jmp    825b22 <gpui_gpu::renderer::coverage::axis+0x1c2>
  825ae1:	movsd  0x20(%rsp),%xmm0
  825ae7:	ucomisd %xmm2,%xmm0
  825aeb:	movdqa 0x80(%rsp),%xmm2
  825af4:	movsd  0x18(%rsp),%xmm1
  825afa:	jne    825eb1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b00:	jp     825eb1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b06:	xorpd  %xmm3,%xmm3
  825b0a:	ucomisd %xmm3,%xmm1
  825b0e:	jne    825eb1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b14:	jp     825eb1 <gpui_gpu::renderer::coverage::axis+0x551>
  825b1a:	movapd %xmm4,%xmm1
  825b1e:	movapd %xmm5,%xmm0
  825b22:	movq   %xmm2,%r13
  825b27:	and    %rbx,%r13
  825b2a:	cmp    %r14,%r13
  825b2d:	jg     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825b33:	xorpd  %xmm3,%xmm3
  825b37:	ucomisd %xmm3,%xmm2
  825b3b:	jne    825b3f <gpui_gpu::renderer::coverage::axis+0x1df>
  825b3d:	jnp    825b56 <gpui_gpu::renderer::coverage::axis+0x1f6>
  825b3f:	lea    -0x1(%r13),%rcx
  825b43:	movabs $0xfffffffffffff,%rdx
  825b4d:	cmp    %rdx,%rcx
  825b50:	jb     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825b56:	lea    0x48(%rsp),%rdi
  825b5b:	movapd 0x80(%rsp),%xmm3
  825b64:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825b69:	movapd 0xb0(%rsp),%xmm2
  825b72:	mov    $0x2,%al
  825b74:	cmpb   $0x0,0x48(%rsp)
  825b79:	je     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825b7f:	movsd  0x50(%rsp),%xmm0
  825b85:	movsd  0x58(%rsp),%xmm1
  825b8b:	lea    0x68(%rsp),%rdi
  825b90:	movapd %xmm2,%xmm3
  825b94:	call   8257e0 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825b99:	cmpl   $0x1,0x68(%rsp)
  825b9e:	jne    825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825ba4:	movsd  0x70(%rsp),%xmm0
  825baa:	movsd  %xmm0,0x18(%rsp)
  825bb0:	movsd  0x78(%rsp),%xmm0
  825bb6:	movsd  %xmm0,0x20(%rsp)
  825bbc:	movapd 0x120(%rsp),%xmm2
  825bc5:	andpd  -0x77ad9d(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825bcd:	mov    %rsp,%rdi
  825bd0:	movsd  0x38(%rsp),%xmm0
  825bd6:	movsd  0x40(%rsp),%xmm1
  825bdc:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825be1:	cmpb   $0x0,(%rsp)
  825be5:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825beb:	movsd  0x8(%rsp),%xmm0
  825bf1:	movsd  %xmm0,0x40(%rsp)
  825bf7:	movsd  0x10(%rsp),%xmm0
  825bfd:	movsd  %xmm0,0x38(%rsp)
  825c03:	movapd 0xc0(%rsp),%xmm2
  825c0c:	andpd  -0x77ade4(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825c14:	mov    %rsp,%rdi
  825c17:	movsd  0x60(%rsp),%xmm0
  825c1d:	movsd  0x28(%rsp),%xmm1
  825c23:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825c28:	cmpb   $0x0,(%rsp)
  825c2c:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825c32:	movsd  0x8(%rsp),%xmm2
  825c38:	movsd  0x10(%rsp),%xmm3
  825c3e:	lea    0x48(%rsp),%rdi
  825c43:	movsd  0x40(%rsp),%xmm0
  825c49:	movsd  0x38(%rsp),%xmm1
  825c4f:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825c54:	cmpb   $0x0,0x48(%rsp)
  825c59:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825c5f:	xorpd  %xmm0,%xmm0
  825c63:	movapd 0x80(%rsp),%xmm2
  825c6c:	ucomisd %xmm0,%xmm2
  825c70:	movsd  0x50(%rsp),%xmm0
  825c76:	movsd  0x58(%rsp),%xmm1
  825c7c:	jne    825c80 <gpui_gpu::renderer::coverage::axis+0x320>
  825c7e:	jnp    825c96 <gpui_gpu::renderer::coverage::axis+0x336>
  825c80:	dec    %r13
  825c83:	movabs $0xfffffffffffff,%rax
  825c8d:	cmp    %rax,%r13
  825c90:	jb     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825c96:	andpd  -0x77ae6e(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825c9e:	lea    0x68(%rsp),%rdi
  825ca3:	movapd %xmm2,%xmm3
  825ca7:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825cac:	cmpb   $0x0,0x68(%rsp)
  825cb1:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825cb7:	xorpd  %xmm0,%xmm0
  825cbb:	movapd 0xb0(%rsp),%xmm2
  825cc4:	ucomisd %xmm0,%xmm2
  825cc8:	movsd  0x70(%rsp),%xmm0
  825cce:	movsd  0x78(%rsp),%xmm1
  825cd4:	jne    825cd8 <gpui_gpu::renderer::coverage::axis+0x378>
  825cd6:	jnp    825cee <gpui_gpu::renderer::coverage::axis+0x38e>
  825cd8:	dec    %r12
  825cdb:	movabs $0xfffffffffffff,%rax
  825ce5:	cmp    %rax,%r12
  825ce8:	jb     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825cee:	andpd  -0x77aec6(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825cf6:	lea    0x108(%rsp),%rdi
  825cfe:	movapd %xmm2,%xmm3
  825d02:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825d07:	cmpb   $0x0,0x108(%rsp)
  825d0f:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825d15:	xorpd  %xmm0,%xmm0
  825d19:	movapd 0x90(%rsp),%xmm1
  825d22:	ucomisd %xmm0,%xmm1
  825d26:	movsd  0x110(%rsp),%xmm0
  825d2f:	movsd  0x118(%rsp),%xmm1
  825d38:	jne    825d3c <gpui_gpu::renderer::coverage::axis+0x3dc>
  825d3a:	jnp    825d52 <gpui_gpu::renderer::coverage::axis+0x3f2>
  825d3c:	dec    %r15
  825d3f:	movabs $0xfffffffffffff,%rax
  825d49:	cmp    %rax,%r15
  825d4c:	jb     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825d52:	movapd -0x77af2a(%rip),%xmm2        # aae30 <GCC_except_table0+0x7c>
  825d5a:	andpd  0x90(%rsp),%xmm2
  825d63:	lea    0xf0(%rsp),%rdi
  825d6b:	movapd %xmm2,%xmm3
  825d6f:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825d74:	cmpb   $0x0,0xf0(%rsp)
  825d7c:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825d82:	movsd  0xf8(%rsp),%xmm0
  825d8b:	movsd  0x100(%rsp),%xmm1
  825d94:	lea    0xd8(%rsp),%rdi
  825d9c:	movsd  -0x7764c4(%rip),%xmm2        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  825da4:	movapd %xmm2,%xmm3
  825da8:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825dad:	cmpl   $0x1,0xd8(%rsp)
  825db5:	jne    825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825dbb:	movsd  0xe0(%rsp),%xmm0
  825dc4:	movsd  0xe8(%rsp),%xmm1
  825dcd:	mov    %rsp,%rdi
  825dd0:	movsd  0xa8(%rsp),%xmm2
  825dd9:	call   825550 <<gpui_gpu::renderer::coverage::Interval>::scale>
  825dde:	cmpb   $0x0,(%rsp)
  825de2:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825de8:	movq   0x30(%rsp),%xmm0
  825dee:	movq   %xmm0,%rax
  825df3:	and    %rbx,%rax
  825df6:	cmp    %r14,%rax
  825df9:	jg     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825dff:	movsd  0x8(%rsp),%xmm0
  825e05:	movsd  0x10(%rsp),%xmm1
  825e0b:	xorpd  %xmm2,%xmm2
  825e0f:	movsd  0x30(%rsp),%xmm3
  825e15:	ucomisd %xmm2,%xmm3
  825e19:	jne    825e1d <gpui_gpu::renderer::coverage::axis+0x4bd>
  825e1b:	jnp    825e2f <gpui_gpu::renderer::coverage::axis+0x4cf>
  825e1d:	dec    %rax
  825e20:	movabs $0xfffffffffffff,%rcx
  825e2a:	cmp    %rcx,%rax
  825e2d:	jb     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825e2f:	lea    0x48(%rsp),%rdi
  825e34:	movsd  0x30(%rsp),%xmm2
  825e3a:	movapd %xmm2,%xmm3
  825e3e:	call   8253e0 <<gpui_gpu::renderer::coverage::Interval>::add>
  825e43:	cmpb   $0x0,0x48(%rsp)
  825e48:	je     825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825e4a:	movsd  0x58(%rsp),%xmm1
  825e50:	movsd  0x18(%rsp),%xmm0
  825e56:	movsd  %xmm1,0x28(%rsp)
  825e5c:	ucomisd %xmm1,%xmm0
  825e60:	jbe    825fd7 <gpui_gpu::renderer::coverage::axis+0x677>
  825e66:	mov    %rsp,%rdi
  825e69:	movapd 0x90(%rsp),%xmm0
  825e72:	movapd %xmm0,%xmm1
  825e76:	movsd  0x18(%rsp),%xmm2
  825e7c:	movsd  0x20(%rsp),%xmm3
  825e82:	call   8257e0 <<gpui_gpu::renderer::coverage::Interval>::subtract>
  825e87:	cmpl   $0x1,(%rsp)
  825e8b:	jne    825e9e <gpui_gpu::renderer::coverage::axis+0x53e>
  825e8d:	movsd  0x8(%rsp),%xmm0
  825e93:	ucomisd 0x28(%rsp),%xmm0
  825e99:	seta   %al
  825e9c:	jmp    825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825e9e:	mov    $0x2,%al
  825ea0:	add    $0x130,%rsp
  825ea7:	pop    %rbx
  825ea8:	pop    %r12
  825eaa:	pop    %r13
  825eac:	pop    %r14
  825eae:	pop    %r15
  825eb0:	ret
  825eb1:	addsd  %xmm5,%xmm0
  825eb5:	addsd  %xmm4,%xmm1
  825eb9:	movq   %xmm0,%rdx
  825ebe:	movq   %xmm1,%rcx
  825ec3:	ucomisd %xmm0,%xmm0
  825ec7:	setp   %sil
  825ecb:	movabs $0xfff0000000000000,%rdi
  825ed5:	cmp    %rdi,%rdx
  825ed8:	sete   %dil
  825edc:	or     %sil,%dil
  825edf:	jne    825f07 <gpui_gpu::renderer::coverage::axis+0x5a7>
  825ee1:	mov    %rdx,%rsi
  825ee4:	and    %rbx,%rsi
  825ee7:	je     825ef3 <gpui_gpu::renderer::coverage::axis+0x593>
  825ee9:	cmp    %rsi,%rdx
  825eec:	jne    825eff <gpui_gpu::renderer::coverage::axis+0x59f>
  825eee:	dec    %rdx
  825ef1:	jmp    825f02 <gpui_gpu::renderer::coverage::axis+0x5a2>
  825ef3:	movabs $0x8000000000000001,%rdx
  825efd:	jmp    825f02 <gpui_gpu::renderer::coverage::axis+0x5a2>
  825eff:	inc    %rdx
  825f02:	movq   %rdx,%xmm0
  825f07:	ucomisd %xmm1,%xmm1
  825f0b:	setp   %dl
  825f0e:	movabs $0x7ff0000000000000,%rsi
  825f18:	cmp    %rsi,%rcx
  825f1b:	sete   %sil
  825f1f:	or     %dl,%sil
  825f22:	jne    825f45 <gpui_gpu::renderer::coverage::axis+0x5e5>
  825f24:	mov    %rcx,%rdx
  825f27:	and    %rbx,%rdx
  825f2a:	je     825f36 <gpui_gpu::renderer::coverage::axis+0x5d6>
  825f2c:	cmp    %rdx,%rcx
  825f2f:	jne    825f3d <gpui_gpu::renderer::coverage::axis+0x5dd>
  825f31:	inc    %rcx
  825f34:	jmp    825f40 <gpui_gpu::renderer::coverage::axis+0x5e0>
  825f36:	mov    $0x1,%ecx
  825f3b:	jmp    825f40 <gpui_gpu::renderer::coverage::axis+0x5e0>
  825f3d:	dec    %rcx
  825f40:	movq   %rcx,%xmm1
  825f45:	movq   %xmm0,%rdx
  825f4a:	and    %rbx,%rdx
  825f4d:	cmp    %r14,%rdx
  825f50:	jg     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825f56:	ucomisd %xmm1,%xmm0
  825f5a:	ja     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825f60:	xorpd  %xmm3,%xmm3
  825f64:	ucomisd %xmm3,%xmm0
  825f68:	movq   %xmm1,%rcx
  825f6d:	jne    825f71 <gpui_gpu::renderer::coverage::axis+0x611>
  825f6f:	jnp    825f9e <gpui_gpu::renderer::coverage::axis+0x63e>
  825f71:	dec    %rdx
  825f74:	mov    %rcx,%rsi
  825f77:	and    %rbx,%rsi
  825f7a:	cmp    %r14,%rsi
  825f7d:	setg   %sil
  825f81:	movabs $0xfffffffffffff,%rdi
  825f8b:	cmp    %rdi,%rdx
  825f8e:	jb     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825f94:	test   %sil,%sil
  825f97:	je     825fad <gpui_gpu::renderer::coverage::axis+0x64d>
  825f99:	jmp    825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825f9e:	mov    %rcx,%rdx
  825fa1:	and    %rbx,%rdx
  825fa4:	cmp    %r14,%rdx
  825fa7:	jg     825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825fad:	ucomisd %xmm3,%xmm1
  825fb1:	jne    825fb9 <gpui_gpu::renderer::coverage::axis+0x659>
  825fb3:	jnp    825b22 <gpui_gpu::renderer::coverage::axis+0x1c2>
  825fb9:	and    %rbx,%rcx
  825fbc:	dec    %rcx
  825fbf:	movabs $0xfffffffffffff,%rdx
  825fc9:	cmp    %rdx,%rcx
  825fcc:	jae    825b22 <gpui_gpu::renderer::coverage::axis+0x1c2>
  825fd2:	jmp    825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
  825fd7:	xor    %eax,%eax
  825fd9:	jmp    825ea0 <gpui_gpu::renderer::coverage::axis+0x540>
