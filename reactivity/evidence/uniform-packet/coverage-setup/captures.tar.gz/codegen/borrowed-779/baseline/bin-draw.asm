FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4499 frame=808

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820450 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820450:	push   %rbp
  820451:	push   %r15
  820453:	push   %r14
  820455:	push   %r13
  820457:	push   %r12
  820459:	push   %rbx
  82045a:	sub    $0x2f8,%rsp
  820461:	movss  0x88(%rdx),%xmm3
  820469:	movss  -0x771455(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820471:	movaps %xmm3,%xmm1
  820474:	subss  %xmm0,%xmm1
  820478:	cvttss2si %xmm1,%rax
  82047d:	cvttss2si %xmm3,%r10
  820482:	mov    %r10,%r12
  820485:	sar    $0x3f,%r12
  820489:	and    %rax,%r12
  82048c:	or     %r10,%r12
  82048f:	xor    %eax,%eax
  820491:	xorps  %xmm1,%xmm1
  820494:	ucomiss %xmm1,%xmm3
  820497:	cmovb  %rax,%r12
  82049b:	movss  0x90(%rdx),%xmm4
  8204a3:	movss  -0x77148b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8204ab:	ucomiss %xmm2,%xmm3
  8204ae:	mov    $0xffffffffffffffff,%r10
  8204b5:	cmova  %r10,%r12
  8204b9:	movaps %xmm4,%xmm3
  8204bc:	subss  %xmm0,%xmm3
  8204c0:	cvttss2si %xmm3,%r11
  8204c5:	cvttss2si %xmm4,%rbx
  8204ca:	mov    %rbx,%r14
  8204cd:	sar    $0x3f,%r14
  8204d1:	and    %r11,%r14
  8204d4:	or     %rbx,%r14
  8204d7:	ucomiss %xmm1,%xmm4
  8204da:	cmovb  %rax,%r14
  8204de:	ucomiss %xmm2,%xmm4
  8204e1:	cmova  %r10,%r14
  8204e5:	movss  0x8c(%rdx),%xmm3
  8204ed:	lea    (%r12,%r14,1),%rbx
  8204f1:	dec    %rbx
  8204f4:	shr    $0x4,%rbx
  8204f8:	shr    $0x4,%r12
  8204fc:	mov    %rbx,%rbp
  8204ff:	sub    %r12,%rbp
  820502:	inc    %rbp
  820505:	movaps %xmm3,%xmm4
  820508:	subss  %xmm0,%xmm4
  82050c:	cvttss2si %xmm4,%r15
  820511:	cvttss2si %xmm3,%r14
  820516:	mov    %r14,%r11
  820519:	sar    $0x3f,%r11
  82051d:	and    %r15,%r11
  820520:	or     %r14,%r11
  820523:	ucomiss %xmm1,%xmm3
  820526:	cmovb  %rax,%r11
  82052a:	ucomiss %xmm2,%xmm3
  82052d:	movss  0x94(%rdx),%xmm3
  820535:	cmova  %r10,%r11
  820539:	movaps %xmm3,%xmm4
  82053c:	subss  %xmm0,%xmm4
  820540:	cvttss2si %xmm4,%r13
  820545:	cvttss2si %xmm3,%r14
  82054a:	mov    %r14,%r15
  82054d:	sar    $0x3f,%r15
  820551:	and    %r13,%r15
  820554:	or     %r14,%r15
  820557:	ucomiss %xmm1,%xmm3
  82055a:	cmovb  %rax,%r15
  82055e:	ucomiss %xmm2,%xmm3
  820561:	cmova  %r10,%r15
  820565:	lea    (%r11,%r15,1),%r10
  820569:	dec    %r10
  82056c:	shr    $0x4,%r10
  820570:	shr    $0x4,%r11
  820574:	mov    %r10,%r14
  820577:	sub    %r11,%r14
  82057a:	inc    %r14
  82057d:	imul   %rbp,%r14
  820581:	add    0x348(%rsp),%r14
  820589:	setb   %al
  82058c:	cmp    $0x400001,%r14
  820593:	setae  %bpl
  820597:	or     %al,%bpl
  82059a:	mov    $0x6,%eax
  82059f:	jne    820690 <<gpui_gpu::renderer::RendererState>::bin_draw+0x240>
  8205a5:	mov    %r14,0x1a0(%rsp)
  8205ad:	mov    %rdi,0x1a8(%rsp)
  8205b5:	mov    %r12,0xb0(%rsp)
  8205bd:	cmpb   $0x0,(%rdx)
  8205c0:	sete   %al
  8205c3:	and    0x340(%rsi),%al
  8205c9:	xor    %r12d,%r12d
  8205cc:	cmp    $0x1,%al
  8205ce:	jne    8206a4 <<gpui_gpu::renderer::RendererState>::bin_draw+0x254>
  8205d4:	movss  0xa4(%rdx),%xmm0
  8205dc:	ucomiss -0x771803(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  8205e3:	mov    0xb0(%rsp),%r14
  8205eb:	jne    82066a <<gpui_gpu::renderer::RendererState>::bin_draw+0x21a>
  8205ed:	jp     82066a <<gpui_gpu::renderer::RendererState>::bin_draw+0x21a>
  8205ef:	mov    0x98(%rdx),%edi
  8205f5:	test   %edi,%edi
  8205f7:	jns    820609 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b9>
  8205f9:	and    $0x7f800000,%edi
  8205ff:	dec    %edi
  820601:	cmp    $0x7f7fffff,%edi
  820607:	jae    820667 <<gpui_gpu::renderer::RendererState>::bin_draw+0x217>
  820609:	mov    0x9c(%rdx),%edi
  82060f:	test   %edi,%edi
  820611:	jns    820623 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d3>
  820613:	and    $0x7f800000,%edi
  820619:	dec    %edi
  82061b:	cmp    $0x7f7ffffe,%edi
  820621:	ja     820667 <<gpui_gpu::renderer::RendererState>::bin_draw+0x217>
  820623:	mov    0xa0(%rdx),%edi
  820629:	test   %edi,%edi
  82062b:	jns    82063d <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ed>
  82062d:	and    $0x7f800000,%edi
  820633:	dec    %edi
  820635:	cmp    $0x7f7ffffe,%edi
  82063b:	ja     820667 <<gpui_gpu::renderer::RendererState>::bin_draw+0x217>
  82063d:	movd   %xmm0,%edi
  820641:	test   %edi,%edi
  820643:	jns    820655 <<gpui_gpu::renderer::RendererState>::bin_draw+0x205>
  820645:	and    $0x7f800000,%edi
  82064b:	dec    %edi
  82064d:	cmp    $0x7f7ffffe,%edi
  820653:	ja     820667 <<gpui_gpu::renderer::RendererState>::bin_draw+0x217>
  820655:	mov    $0x1,%r12b
  820658:	mov    %r9,0xa8(%rsp)
  820660:	cmp    %r11,%r10
  820663:	jb     820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  820665:	jmp    8206b9 <<gpui_gpu::renderer::RendererState>::bin_draw+0x269>
  820667:	xor    %r12d,%r12d
  82066a:	mov    %r9,0xa8(%rsp)
  820672:	cmp    %r11,%r10
  820675:	jae    8206b9 <<gpui_gpu::renderer::RendererState>::bin_draw+0x269>
  820677:	mov    0x1a8(%rsp),%rdi
  82067f:	mov    0x1a0(%rsp),%rax
  820687:	mov    %rax,0x8(%rdi)
  82068b:	mov    $0xffffffff,%eax
  820690:	mov    %eax,(%rdi)
  820692:	add    $0x2f8,%rsp
  820699:	pop    %rbx
  82069a:	pop    %r12
  82069c:	pop    %r13
  82069e:	pop    %r14
  8206a0:	pop    %r15
  8206a2:	pop    %rbp
  8206a3:	ret
  8206a4:	mov    0xb0(%rsp),%r14
  8206ac:	mov    %r9,0xa8(%rsp)
  8206b4:	cmp    %r11,%r10
  8206b7:	jb     820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  8206b9:	cmp    %r14,%rbx
  8206bc:	jae    8206d6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  8206be:	xchg   %ax,%ax
  8206c0:	mov    %r11,%rax
  8206c3:	cmp    %r10,%r11
  8206c6:	adc    $0x0,%r11
  8206ca:	cmp    %r10,%rax
  8206cd:	jae    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  8206cf:	cmp    %r10,%r11
  8206d2:	jbe    8206c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  8206d4:	jmp    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  8206d6:	mov    0x20(%rsi),%r13
  8206da:	mov    %rsi,%rdi
  8206dd:	mov    0x28(%rsi),%rsi
  8206e1:	test   %al,%al
  8206e3:	mov    %r10,0x18(%rsp)
  8206e8:	je     8214a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1050>
  8206ee:	cmpq   $0x0,0x330(%rsp)
  8206f7:	je     821510 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c0>
  8206fd:	movd   %ecx,%xmm2
  820701:	shr    $0x20,%rcx
  820705:	movss  0x78(%rdx),%xmm0
  82070a:	movss  0x80(%rdx),%xmm3
  820712:	movss  0x84(%rdx),%xmm4
  82071a:	cvtss2sd %xmm0,%xmm0
  82071e:	movss  0x7c(%rdx),%xmm1
  820723:	cvtss2sd %xmm1,%xmm1
  820727:	cvtss2sd %xmm3,%xmm14
  82072c:	addsd  %xmm0,%xmm14
  820731:	xorps  %xmm3,%xmm3
  820734:	cvtss2sd %xmm4,%xmm3
  820738:	addsd  %xmm1,%xmm3
  82073c:	movsd  %xmm3,0x1b8(%rsp)
  820745:	movsd  0x48(%rdx),%xmm6
  82074a:	movsd  0x58(%rdx),%xmm7
  82074f:	movsd  0x68(%rdx),%xmm8
  820755:	movss  0x38(%rdx),%xmm3
  82075a:	movss  0x3c(%rdx),%xmm4
  82075f:	movss  0x40(%rdx),%xmm5
  820764:	cvtss2sd %xmm3,%xmm3
  820768:	cvtss2sd %xmm5,%xmm5
  82076c:	movaps -0x775944(%rip),%xmm9        # aae30 <GCC_except_table0+0x90>
  820774:	movaps %xmm3,0x90(%rsp)
  82077c:	andps  %xmm9,%xmm3
  820780:	movaps %xmm3,0x80(%rsp)
  820788:	movaps %xmm5,0x60(%rsp)
  82078d:	cvtss2sd %xmm2,%xmm2
  820791:	movsd  %xmm2,0x10(%rsp)
  820797:	andps  %xmm9,%xmm5
  82079b:	movaps %xmm5,0x70(%rsp)
  8207a0:	movaps %xmm6,%xmm2
  8207a3:	andps  %xmm9,%xmm2
  8207a7:	movaps %xmm2,0x260(%rsp)
  8207af:	movaps %xmm7,%xmm2
  8207b2:	andps  %xmm9,%xmm2
  8207b6:	movaps %xmm2,0x240(%rsp)
  8207be:	xorps  %xmm3,%xmm3
  8207c1:	cvtss2sd %xmm4,%xmm3
  8207c5:	movaps %xmm8,%xmm2
  8207c9:	andps  %xmm9,%xmm2
  8207cd:	movaps %xmm2,0x100(%rsp)
  8207d5:	movss  0x44(%rdx),%xmm2
  8207da:	cvtss2sd %xmm2,%xmm2
  8207de:	movaps %xmm3,0x50(%rsp)
  8207e3:	andps  %xmm9,%xmm3
  8207e7:	movaps %xmm3,0x40(%rsp)
  8207ec:	movaps %xmm2,0x20(%rsp)
  8207f1:	andps  %xmm9,%xmm2
  8207f5:	movaps %xmm2,0x30(%rsp)
  8207fa:	movd   %ecx,%xmm2
  8207fe:	cvtss2sd %xmm2,%xmm2
  820802:	movsd  %xmm2,(%rsp)
  820807:	movsd  0x50(%rdx),%xmm3
  82080c:	movaps %xmm3,%xmm2
  82080f:	andps  %xmm9,%xmm2
  820813:	movaps %xmm2,0x1e0(%rsp)
  82081b:	movsd  0x60(%rdx),%xmm4
  820820:	movaps %xmm4,%xmm2
  820823:	andps  %xmm9,%xmm2
  820827:	movaps %xmm2,0x1c0(%rsp)
  82082f:	movsd  0x70(%rdx),%xmm5
  820834:	andps  %xmm5,%xmm9
  820838:	movaps %xmm9,0xd0(%rsp)
  820841:	mov    0x58(%rdi),%rax
  820845:	mov    %rax,0xb8(%rsp)
  82084d:	mov    0x50(%rdi),%rax
  820851:	mov    %rax,0x168(%rsp)
  820859:	mov    0xa8(%rsp),%rax
  820861:	inc    %eax
  820863:	mov    %rax,0xa8(%rsp)
  82086b:	movaps %xmm6,0x270(%rsp)
  820873:	movaps %xmm6,%xmm2
  820876:	movaps %xmm7,0x250(%rsp)
  82087e:	movlhps %xmm7,%xmm2
  820881:	cvtpd2ps %xmm2,%xmm2
  820885:	movaps %xmm3,0x1f0(%rsp)
  82088d:	cvtsd2ss %xmm3,%xmm3
  820891:	cvtss2sd %xmm3,%xmm3
  820895:	cvtps2pd %xmm2,%xmm6
  820898:	movaps %xmm4,0x1d0(%rsp)
  8208a0:	xorps  %xmm2,%xmm2
  8208a3:	cvtsd2ss %xmm4,%xmm2
  8208a7:	xorps  %xmm4,%xmm4
  8208aa:	cvtss2sd %xmm2,%xmm4
  8208ae:	movaps %xmm8,0x110(%rsp)
  8208b7:	xorps  %xmm2,%xmm2
  8208ba:	cvtsd2ss %xmm8,%xmm2
  8208bf:	cvtss2sd %xmm2,%xmm7
  8208c3:	movaps %xmm5,0xc0(%rsp)
  8208cb:	xorps  %xmm2,%xmm2
  8208ce:	cvtsd2ss %xmm5,%xmm2
  8208d2:	cvtss2sd %xmm2,%xmm2
  8208d6:	movaps -0x775aad(%rip),%xmm5        # aae30 <GCC_except_table0+0x90>
  8208dd:	movaps %xmm6,%xmm8
  8208e1:	andps  %xmm5,%xmm8
  8208e5:	movaps %xmm7,0x130(%rsp)
  8208ed:	andps  %xmm5,%xmm7
  8208f0:	movaps %xmm7,0x120(%rsp)
  8208f8:	movaps %xmm3,0x230(%rsp)
  820900:	andps  %xmm5,%xmm3
  820903:	movaps %xmm3,0x220(%rsp)
  82090b:	movaps %xmm4,0x210(%rsp)
  820913:	andps  %xmm5,%xmm4
  820916:	movaps %xmm4,0x200(%rsp)
  82091e:	movaps %xmm2,0xf0(%rsp)
  820926:	andps  %xmm2,%xmm5
  820929:	movaps %xmm5,0xe0(%rsp)
  820931:	movaps %xmm6,0x290(%rsp)
  820939:	movhlps %xmm6,%xmm6
  82093c:	movaps %xmm6,0x2c0(%rsp)
  820944:	movaps %xmm8,0x280(%rsp)
  82094d:	movhlps %xmm8,%xmm8
  820951:	movaps %xmm8,0x2b0(%rsp)
  82095a:	mov    %r11,%rax
  82095d:	movsd  %xmm14,0x8(%rsp)
  820964:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  820970:	cmp    %r10,%r11
  820973:	adc    $0x0,%rax
  820977:	mov    %rax,0x1b0(%rsp)
  82097f:	mov    %r14,%rcx
  820982:	mov    %r11,%r14
  820985:	imul   0x330(%rsp),%r14
  82098e:	mov    %rcx,%rdi
  820991:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  8209a0:	cmp    %rbx,%rcx
  8209a3:	adc    $0x0,%rdi
  8209a7:	lea    (%rcx,%r14,1),%r10
  8209ab:	test   %r12b,%r12b
  8209ae:	jne    8209c5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x575>
  8209b0:	cmp    %rsi,%r10
  8209b3:	jae    82159e <<gpui_gpu::renderer::RendererState>::bin_draw+0x114e>
  8209b9:	testb  $0x40,0x7(%r13,%r10,8)
  8209bf:	je     820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8209c5:	mov    %r10,%rax
  8209c8:	shr    $0x20,%rax
  8209cc:	je     8209e0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x590>
  8209ce:	mov    %r10,%rax
  8209d1:	xor    %edx,%edx
  8209d3:	divq   0x330(%rsp)
  8209db:	jmp    8209f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8209dd:	nopl   (%rax)
  8209e0:	mov    %r10d,%eax
  8209e3:	xor    %edx,%edx
  8209e5:	mov    0x330(%rsp),%r15
  8209ed:	div    %r15d
  8209f0:	shl    $0x4,%edx
  8209f3:	shl    $0x4,%eax
  8209f6:	lea    0x10(%rdx),%ebp
  8209f9:	mov    0x338(%rsp),%r9d
  820a01:	cmp    %ebp,%r9d
  820a04:	cmovb  %r9d,%ebp
  820a08:	lea    0x10(%rax),%r15d
  820a0c:	mov    0x340(%rsp),%r9d
  820a14:	cmp    %r15d,%r9d
  820a17:	cmovb  %r9d,%r15d
  820a1b:	xorps  %xmm12,%xmm12
  820a1f:	cvtsi2sd %edx,%xmm12
  820a24:	ucomisd %xmm12,%xmm0
  820a29:	ja     820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820a2b:	mov    %eax,%eax
  820a2d:	xorps  %xmm2,%xmm2
  820a30:	cvtsi2sd %rax,%xmm2
  820a35:	ucomisd %xmm2,%xmm1
  820a39:	ja     820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820a3b:	xorps  %xmm6,%xmm6
  820a3e:	cvtsi2sd %ebp,%xmm6
  820a42:	ucomisd %xmm14,%xmm6
  820a47:	ja     820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820a49:	xorps  %xmm13,%xmm13
  820a4d:	cvtsi2sd %r15d,%xmm13
  820a52:	ucomisd 0x1b8(%rsp),%xmm13
  820a5c:	jbe    820a94 <<gpui_gpu::renderer::RendererState>::bin_draw+0x644>
  820a5e:	xchg   %ax,%ax
  820a60:	cmp    %rsi,%r10
  820a63:	jae    82158e <<gpui_gpu::renderer::RendererState>::bin_draw+0x113e>
  820a69:	mov    0x4(%r13,%r10,8),%eax
  820a6e:	inc    %eax
  820a70:	and    $0xbfffffff,%eax
  820a75:	mov    %eax,0x4(%r13,%r10,8)
  820a7a:	cmp    %rbx,%rcx
  820a7d:	jae    821470 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1020>
  820a83:	mov    %rdi,%rcx
  820a86:	cmp    %rbx,%rdi
  820a89:	jbe    8209a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x550>
  820a8f:	jmp    821470 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1020>
  820a94:	unpcklpd %xmm2,%xmm12
  820a99:	addpd  -0x773962(%rip),%xmm12        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820aa2:	movapd %xmm12,%xmm10
  820aa7:	mulpd  0x290(%rsp),%xmm10
  820ab1:	movapd %xmm10,%xmm9
  820ab6:	unpckhpd %xmm10,%xmm9
  820abb:	movapd %xmm10,%xmm2
  820ac0:	addsd  %xmm9,%xmm2
  820ac5:	addsd  0x130(%rsp),%xmm2
  820ace:	subsd  0x90(%rsp),%xmm2
  820ad7:	movapd 0x280(%rsp),%xmm8
  820ae1:	mulpd  %xmm12,%xmm8
  820ae6:	movapd %xmm8,%xmm15
  820aeb:	unpckhpd %xmm8,%xmm15
  820af0:	movapd %xmm8,%xmm3
  820af5:	addsd  %xmm15,%xmm3
  820afa:	addsd  0x120(%rsp),%xmm3
  820b03:	addsd  0x80(%rsp),%xmm3
  820b0c:	addsd  0x70(%rsp),%xmm3
  820b12:	addsd  -0x771242(%rip),%xmm3        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b1a:	mulsd  -0x7712c2(%rip),%xmm3        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820b22:	addsd  0x10(%rsp),%xmm3
  820b28:	ucomisd %xmm2,%xmm3
  820b2c:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820b32:	movapd 0x60(%rsp),%xmm4
  820b38:	subsd  %xmm2,%xmm4
  820b3c:	ucomisd %xmm4,%xmm3
  820b40:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820b46:	movapd %xmm12,%xmm7
  820b4b:	unpckhpd %xmm12,%xmm7
  820b50:	movapd 0x250(%rsp),%xmm11
  820b5a:	mulsd  %xmm7,%xmm11
  820b5f:	movapd 0x240(%rsp),%xmm3
  820b68:	mulsd  %xmm7,%xmm3
  820b6c:	movapd 0x270(%rsp),%xmm2
  820b75:	mulsd  %xmm12,%xmm2
  820b7a:	movapd %xmm2,0x150(%rsp)
  820b83:	addsd  %xmm11,%xmm2
  820b88:	addsd  0x110(%rsp),%xmm2
  820b91:	subsd  0x90(%rsp),%xmm2
  820b9a:	movapd 0x260(%rsp),%xmm4
  820ba3:	mulsd  %xmm12,%xmm4
  820ba8:	movsd  %xmm4,0x198(%rsp)
  820bb1:	addsd  %xmm3,%xmm4
  820bb5:	addsd  0x100(%rsp),%xmm4
  820bbe:	addsd  0x80(%rsp),%xmm4
  820bc7:	addsd  0x70(%rsp),%xmm4
  820bcd:	addsd  -0x7712fd(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820bd5:	mulsd  -0x770da5(%rip),%xmm4        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820bdd:	ucomisd %xmm2,%xmm4
  820be1:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820be7:	movapd 0x60(%rsp),%xmm5
  820bed:	subsd  %xmm2,%xmm5
  820bf1:	ucomisd %xmm5,%xmm4
  820bf5:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820bfb:	movapd %xmm7,%xmm4
  820bff:	mulsd  0x210(%rsp),%xmm4
  820c08:	movapd %xmm7,%xmm2
  820c0c:	mulsd  0x200(%rsp),%xmm2
  820c15:	movapd %xmm12,%xmm5
  820c1a:	mulsd  0x230(%rsp),%xmm5
  820c23:	movsd  %xmm5,0x190(%rsp)
  820c2c:	movapd %xmm4,0x140(%rsp)
  820c35:	addsd  %xmm4,%xmm5
  820c39:	addsd  0xf0(%rsp),%xmm5
  820c42:	subsd  0x50(%rsp),%xmm5
  820c48:	movapd %xmm12,%xmm4
  820c4d:	mulsd  0x220(%rsp),%xmm4
  820c56:	movsd  %xmm4,0x188(%rsp)
  820c5f:	addsd  %xmm2,%xmm4
  820c63:	addsd  0xe0(%rsp),%xmm4
  820c6c:	addsd  0x40(%rsp),%xmm4
  820c72:	addsd  0x30(%rsp),%xmm4
  820c78:	addsd  -0x7713a8(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c80:	mulsd  -0x771428(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820c88:	addsd  (%rsp),%xmm4
  820c8d:	ucomisd %xmm5,%xmm4
  820c91:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820c97:	movapd 0x20(%rsp),%xmm14
  820c9e:	subsd  %xmm5,%xmm14
  820ca3:	ucomisd %xmm14,%xmm4
  820ca8:	movsd  0x8(%rsp),%xmm14
  820caf:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820cb5:	movapd 0x1d0(%rsp),%xmm4
  820cbe:	mulsd  %xmm7,%xmm4
  820cc2:	mulsd  0x1c0(%rsp),%xmm7
  820ccb:	movapd 0x1f0(%rsp),%xmm5
  820cd4:	mulsd  %xmm12,%xmm5
  820cd9:	movapd %xmm5,0x2d0(%rsp)
  820ce2:	movapd %xmm4,0x2e0(%rsp)
  820ceb:	addsd  %xmm4,%xmm5
  820cef:	addsd  0xc0(%rsp),%xmm5
  820cf8:	subsd  0x50(%rsp),%xmm5
  820cfe:	mulsd  0x1e0(%rsp),%xmm12
  820d08:	movapd %xmm12,%xmm4
  820d0d:	addsd  %xmm7,%xmm4
  820d11:	addsd  0xd0(%rsp),%xmm4
  820d1a:	addsd  0x40(%rsp),%xmm4
  820d20:	addsd  0x30(%rsp),%xmm4
  820d26:	addsd  -0x771456(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d2e:	mulsd  -0x770efe(%rip),%xmm4        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d36:	ucomisd %xmm5,%xmm4
  820d3a:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820d40:	movapd 0x20(%rsp),%xmm14
  820d47:	subsd  %xmm5,%xmm14
  820d4c:	ucomisd %xmm14,%xmm4
  820d51:	movsd  0x8(%rsp),%xmm14
  820d58:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820d5e:	addsd  -0x77177e(%rip),%xmm6        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820d66:	movapd %xmm6,%xmm4
  820d6a:	mulsd  0x290(%rsp),%xmm4
  820d73:	movsd  %xmm4,0x180(%rsp)
  820d7c:	addsd  %xmm4,%xmm9
  820d81:	addsd  0x130(%rsp),%xmm9
  820d8b:	subsd  0x90(%rsp),%xmm9
  820d95:	movapd 0x280(%rsp),%xmm4
  820d9e:	mulsd  %xmm6,%xmm4
  820da2:	movsd  %xmm4,0x178(%rsp)
  820dab:	addsd  %xmm4,%xmm15
  820db0:	addsd  0x120(%rsp),%xmm15
  820dba:	addsd  0x80(%rsp),%xmm15
  820dc4:	addsd  0x70(%rsp),%xmm15
  820dcb:	addsd  -0x7714fc(%rip),%xmm15        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820dd4:	mulsd  -0x77157d(%rip),%xmm15        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ddd:	addsd  0x10(%rsp),%xmm15
  820de4:	ucomisd %xmm9,%xmm15
  820de9:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820def:	movapd 0x60(%rsp),%xmm4
  820df5:	subsd  %xmm9,%xmm4
  820dfa:	ucomisd %xmm4,%xmm15
  820dff:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820e05:	movapd 0x270(%rsp),%xmm15
  820e0f:	mulsd  %xmm6,%xmm15
  820e14:	addsd  %xmm15,%xmm11
  820e19:	addsd  0x110(%rsp),%xmm11
  820e23:	subsd  0x90(%rsp),%xmm11
  820e2d:	movapd 0x260(%rsp),%xmm4
  820e36:	mulsd  %xmm6,%xmm4
  820e3a:	movsd  %xmm4,0x170(%rsp)
  820e43:	addsd  %xmm4,%xmm3
  820e47:	addsd  0x100(%rsp),%xmm3
  820e50:	addsd  0x80(%rsp),%xmm3
  820e59:	addsd  0x70(%rsp),%xmm3
  820e5f:	addsd  -0x77158f(%rip),%xmm3        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e67:	mulsd  -0x771037(%rip),%xmm3        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820e6f:	ucomisd %xmm11,%xmm3
  820e74:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820e7a:	movapd 0x60(%rsp),%xmm4
  820e80:	subsd  %xmm11,%xmm4
  820e85:	ucomisd %xmm4,%xmm3
  820e89:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820e8f:	movapd %xmm6,%xmm3
  820e93:	mulsd  0x230(%rsp),%xmm3
  820e9c:	movsd  %xmm3,0x160(%rsp)
  820ea5:	movapd 0x140(%rsp),%xmm5
  820eae:	addsd  %xmm3,%xmm5
  820eb2:	addsd  0xf0(%rsp),%xmm5
  820ebb:	subsd  0x50(%rsp),%xmm5
  820ec1:	movapd %xmm6,%xmm3
  820ec5:	mulsd  0x220(%rsp),%xmm3
  820ece:	movsd  %xmm3,0x140(%rsp)
  820ed7:	addsd  %xmm3,%xmm2
  820edb:	addsd  0xe0(%rsp),%xmm2
  820ee4:	addsd  0x40(%rsp),%xmm2
  820eea:	addsd  0x30(%rsp),%xmm2
  820ef0:	addsd  -0x771620(%rip),%xmm2        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ef8:	mulsd  -0x7716a0(%rip),%xmm2        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f00:	addsd  (%rsp),%xmm2
  820f05:	ucomisd %xmm5,%xmm2
  820f09:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820f0f:	movapd 0x20(%rsp),%xmm3
  820f15:	subsd  %xmm5,%xmm3
  820f19:	ucomisd %xmm3,%xmm2
  820f1d:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820f23:	movapd 0x1f0(%rsp),%xmm2
  820f2c:	mulsd  %xmm6,%xmm2
  820f30:	movapd %xmm2,0x2a0(%rsp)
  820f39:	movapd 0x2e0(%rsp),%xmm4
  820f42:	addsd  %xmm2,%xmm4
  820f46:	addsd  0xc0(%rsp),%xmm4
  820f4f:	subsd  0x50(%rsp),%xmm4
  820f55:	mulsd  0x1e0(%rsp),%xmm6
  820f5e:	addsd  %xmm6,%xmm7
  820f62:	addsd  0xd0(%rsp),%xmm7
  820f6b:	addsd  0x40(%rsp),%xmm7
  820f71:	addsd  0x30(%rsp),%xmm7
  820f77:	addsd  -0x7716a7(%rip),%xmm7        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f7f:	mulsd  -0x77114f(%rip),%xmm7        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f87:	ucomisd %xmm4,%xmm7
  820f8b:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820f91:	movapd 0x20(%rsp),%xmm2
  820f97:	subsd  %xmm4,%xmm2
  820f9b:	ucomisd %xmm2,%xmm7
  820f9f:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820fa5:	addsd  -0x7719c6(%rip),%xmm13        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820fae:	movapd %xmm13,%xmm3
  820fb3:	mulsd  0x2c0(%rsp),%xmm3
  820fbc:	movapd %xmm13,%xmm2
  820fc1:	mulsd  0x2b0(%rsp),%xmm2
  820fca:	addsd  %xmm3,%xmm10
  820fcf:	addsd  0x130(%rsp),%xmm10
  820fd9:	subsd  0x90(%rsp),%xmm10
  820fe3:	addsd  %xmm2,%xmm8
  820fe8:	addsd  0x120(%rsp),%xmm8
  820ff2:	addsd  0x80(%rsp),%xmm8
  820ffc:	addsd  0x70(%rsp),%xmm8
  821003:	addsd  -0x771734(%rip),%xmm8        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82100c:	mulsd  -0x7717b5(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821015:	addsd  0x10(%rsp),%xmm8
  82101c:	ucomisd %xmm10,%xmm8
  821021:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821027:	movapd 0x60(%rsp),%xmm4
  82102d:	subsd  %xmm10,%xmm4
  821032:	ucomisd %xmm4,%xmm8
  821037:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82103d:	movapd 0x250(%rsp),%xmm7
  821046:	mulsd  %xmm13,%xmm7
  82104b:	movapd 0x240(%rsp),%xmm5
  821054:	mulsd  %xmm13,%xmm5
  821059:	movapd 0x150(%rsp),%xmm4
  821062:	addsd  %xmm7,%xmm4
  821066:	addsd  0x110(%rsp),%xmm4
  82106f:	subsd  0x90(%rsp),%xmm4
  821078:	movsd  0x198(%rsp),%xmm10
  821082:	addsd  %xmm5,%xmm10
  821087:	addsd  0x100(%rsp),%xmm10
  821091:	addsd  0x80(%rsp),%xmm10
  82109b:	addsd  0x70(%rsp),%xmm10
  8210a2:	addsd  -0x7717d3(%rip),%xmm10        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210ab:	mulsd  -0x77127c(%rip),%xmm10        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210b4:	ucomisd %xmm4,%xmm10
  8210b9:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8210bf:	movapd %xmm4,%xmm8
  8210c4:	movapd 0x60(%rsp),%xmm4
  8210ca:	subsd  %xmm8,%xmm4
  8210cf:	ucomisd %xmm4,%xmm10
  8210d4:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8210da:	movapd %xmm13,%xmm8
  8210df:	mulsd  0x210(%rsp),%xmm8
  8210e9:	movapd %xmm13,%xmm10
  8210ee:	mulsd  0x200(%rsp),%xmm10
  8210f8:	movsd  0x190(%rsp),%xmm9
  821102:	addsd  %xmm8,%xmm9
  821107:	addsd  0xf0(%rsp),%xmm9
  821111:	subsd  0x50(%rsp),%xmm9
  821118:	movapd %xmm15,%xmm4
  82111d:	movsd  0x188(%rsp),%xmm15
  821127:	movsd  %xmm10,0x150(%rsp)
  821131:	addsd  %xmm10,%xmm15
  821136:	addsd  0xe0(%rsp),%xmm15
  821140:	addsd  0x40(%rsp),%xmm15
  821147:	addsd  0x30(%rsp),%xmm15
  82114e:	addsd  -0x77187f(%rip),%xmm15        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821157:	mulsd  -0x771900(%rip),%xmm15        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821160:	addsd  (%rsp),%xmm15
  821166:	ucomisd %xmm9,%xmm15
  82116b:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821171:	movapd %xmm9,%xmm10
  821176:	movapd 0x20(%rsp),%xmm9
  82117d:	subsd  %xmm10,%xmm9
  821182:	ucomisd %xmm9,%xmm15
  821187:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82118d:	movapd 0x1d0(%rsp),%xmm9
  821197:	mulsd  %xmm13,%xmm9
  82119c:	mulsd  0x1c0(%rsp),%xmm13
  8211a6:	movapd 0x2d0(%rsp),%xmm10
  8211b0:	addsd  %xmm9,%xmm10
  8211b5:	addsd  0xc0(%rsp),%xmm10
  8211bf:	subsd  0x50(%rsp),%xmm10
  8211c6:	addsd  %xmm13,%xmm12
  8211cb:	addsd  0xd0(%rsp),%xmm12
  8211d5:	addsd  0x40(%rsp),%xmm12
  8211dc:	addsd  0x30(%rsp),%xmm12
  8211e3:	addsd  -0x771914(%rip),%xmm12        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211ec:	mulsd  -0x7713bd(%rip),%xmm12        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8211f5:	ucomisd %xmm10,%xmm12
  8211fa:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821200:	movapd %xmm10,%xmm11
  821205:	movapd 0x20(%rsp),%xmm10
  82120c:	subsd  %xmm11,%xmm10
  821211:	ucomisd %xmm10,%xmm12
  821216:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82121c:	movsd  0x180(%rsp),%xmm10
  821226:	addsd  %xmm3,%xmm10
  82122b:	addsd  0x130(%rsp),%xmm10
  821235:	subsd  0x90(%rsp),%xmm10
  82123f:	movsd  0x178(%rsp),%xmm11
  821249:	addsd  %xmm2,%xmm11
  82124e:	addsd  0x120(%rsp),%xmm11
  821258:	addsd  0x80(%rsp),%xmm11
  821262:	addsd  0x70(%rsp),%xmm11
  821269:	addsd  -0x77199a(%rip),%xmm11        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821272:	mulsd  -0x771a1b(%rip),%xmm11        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82127b:	addsd  0x10(%rsp),%xmm11
  821282:	ucomisd %xmm10,%xmm11
  821287:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82128d:	movapd %xmm4,%xmm15
  821292:	movapd 0x60(%rsp),%xmm2
  821298:	subsd  %xmm10,%xmm2
  82129d:	ucomisd %xmm2,%xmm11
  8212a2:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8212a8:	addsd  %xmm7,%xmm15
  8212ad:	addsd  0x110(%rsp),%xmm15
  8212b7:	subsd  0x90(%rsp),%xmm15
  8212c1:	movsd  0x170(%rsp),%xmm2
  8212ca:	addsd  %xmm5,%xmm2
  8212ce:	addsd  0x100(%rsp),%xmm2
  8212d7:	addsd  0x80(%rsp),%xmm2
  8212e0:	addsd  0x70(%rsp),%xmm2
  8212e6:	addsd  -0x771a16(%rip),%xmm2        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212ee:	mulsd  -0x7714be(%rip),%xmm2        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8212f6:	ucomisd %xmm15,%xmm2
  8212fb:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821301:	movapd %xmm2,%xmm3
  821305:	movapd 0x60(%rsp),%xmm2
  82130b:	subsd  %xmm15,%xmm2
  821310:	ucomisd %xmm2,%xmm3
  821314:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82131a:	movsd  0x160(%rsp),%xmm2
  821323:	addsd  %xmm8,%xmm2
  821328:	addsd  0xf0(%rsp),%xmm2
  821331:	subsd  0x50(%rsp),%xmm2
  821337:	movsd  0x140(%rsp),%xmm5
  821340:	addsd  0x150(%rsp),%xmm5
  821349:	addsd  0xe0(%rsp),%xmm5
  821352:	addsd  0x40(%rsp),%xmm5
  821358:	addsd  0x30(%rsp),%xmm5
  82135e:	addsd  -0x771a8e(%rip),%xmm5        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821366:	mulsd  -0x771b0e(%rip),%xmm5        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82136e:	addsd  (%rsp),%xmm5
  821373:	ucomisd %xmm2,%xmm5
  821377:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82137d:	movapd %xmm2,%xmm3
  821381:	movapd 0x20(%rsp),%xmm2
  821387:	subsd  %xmm3,%xmm2
  82138b:	ucomisd %xmm2,%xmm5
  82138f:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821395:	movapd 0x2a0(%rsp),%xmm2
  82139e:	addsd  %xmm9,%xmm2
  8213a3:	addsd  0xc0(%rsp),%xmm2
  8213ac:	subsd  0x50(%rsp),%xmm2
  8213b2:	addsd  %xmm13,%xmm6
  8213b7:	addsd  0xd0(%rsp),%xmm6
  8213c0:	addsd  0x40(%rsp),%xmm6
  8213c6:	addsd  0x30(%rsp),%xmm6
  8213cc:	addsd  -0x771afc(%rip),%xmm6        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213d4:	mulsd  -0x7715a4(%rip),%xmm6        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8213dc:	ucomisd %xmm2,%xmm6
  8213e0:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8213e6:	movapd %xmm2,%xmm3
  8213ea:	movapd 0x20(%rsp),%xmm2
  8213f0:	subsd  %xmm3,%xmm2
  8213f4:	ucomisd %xmm2,%xmm6
  8213f8:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8213fe:	test   %r12b,%r12b
  821401:	je     821448 <<gpui_gpu::renderer::RendererState>::bin_draw+0xff8>
  821403:	cmp    %rsi,%r10
  821406:	jae    8215bb <<gpui_gpu::renderer::RendererState>::bin_draw+0x116b>
  82140c:	mov    %r8d,0x0(%r13,%r10,8)
  821411:	movl   $0x40000001,0x4(%r13,%r10,8)
  82141a:	cmp    0xb8(%rsp),%r10
  821422:	jae    8215cb <<gpui_gpu::renderer::RendererState>::bin_draw+0x117b>
  821428:	mov    0xa8(%rsp),%rax
  821430:	mov    0x168(%rsp),%rdx
  821438:	mov    %eax,(%rdx,%r10,4)
  82143c:	movsd  0x8(%rsp),%xmm14
  821443:	jmp    820a7a <<gpui_gpu::renderer::RendererState>::bin_draw+0x62a>
  821448:	cmp    %rsi,%r10
  82144b:	jae    82158e <<gpui_gpu::renderer::RendererState>::bin_draw+0x113e>
  821451:	incl   0x4(%r13,%r10,8)
  821456:	movsd  0x8(%rsp),%xmm14
  82145d:	jmp    820a7a <<gpui_gpu::renderer::RendererState>::bin_draw+0x62a>
  821462:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  821470:	mov    0x18(%rsp),%r10
  821475:	cmp    %r10,%r11
  821478:	mov    0xb0(%rsp),%r14
  821480:	mov    0x1b0(%rsp),%rax
  821488:	jae    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  82148e:	mov    %rax,%r11
  821491:	cmp    %r10,%rax
  821494:	jbe    820970 <<gpui_gpu::renderer::RendererState>::bin_draw+0x520>
  82149a:	jmp    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  82149f:	nop
  8214a0:	mov    %r11,%rax
  8214a3:	cmp    %r10,%r11
  8214a6:	adc    $0x0,%r11
  8214aa:	mov    %rax,%rcx
  8214ad:	imul   0x330(%rsp),%rcx
  8214b6:	mov    %r14,%rdx
  8214b9:	nopl   0x0(%rax)
  8214c0:	lea    (%rdx,%rcx,1),%r10
  8214c4:	cmp    %rsi,%r10
  8214c7:	jae    82158e <<gpui_gpu::renderer::RendererState>::bin_draw+0x113e>
  8214cd:	cmp    %rbx,%rdx
  8214d0:	mov    %rdx,%rdi
  8214d3:	adc    $0x0,%rdi
  8214d7:	mov    0x4(%r13,%r10,8),%r8d
  8214dc:	inc    %r8d
  8214df:	and    $0xbfffffff,%r8d
  8214e6:	mov    %r8d,0x4(%r13,%r10,8)
  8214eb:	cmp    %rbx,%rdx
  8214ee:	jae    8214f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10a8>
  8214f0:	mov    %rdi,%rdx
  8214f3:	cmp    %rbx,%rdi
  8214f6:	jbe    8214c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1070>
  8214f8:	mov    0x18(%rsp),%r10
  8214fd:	cmp    %r10,%rax
  821500:	jae    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  821506:	cmp    %r10,%r11
  821509:	jbe    8214a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1050>
  82150b:	jmp    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  821510:	test   %r12b,%r12b
  821513:	jne    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x115e>
  821519:	mov    %r11,%rax
  82151c:	mov    0x18(%rsp),%rcx
  821521:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  821530:	cmp    %rcx,%r11
  821533:	adc    $0x0,%rax
  821537:	mov    %r14,%r10
  82153a:	mov    %r14,%rcx
  82153d:	nopl   (%rax)
  821540:	cmp    %rbx,%r10
  821543:	adc    $0x0,%rcx
  821547:	cmp    %rsi,%r10
  82154a:	jae    82159e <<gpui_gpu::renderer::RendererState>::bin_draw+0x114e>
  82154c:	mov    0x4(%r13,%r10,8),%edx
  821551:	test   $0x40000000,%edx
  821557:	jne    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x115e>
  821559:	inc    %edx
  82155b:	and    $0xbfffffff,%edx
  821561:	mov    %edx,0x4(%r13,%r10,8)
  821566:	cmp    %rbx,%r10
  821569:	jae    821573 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1123>
  82156b:	mov    %rcx,%r10
  82156e:	cmp    %rbx,%rcx
  821571:	jbe    821540 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  821573:	mov    0x18(%rsp),%rcx
  821578:	cmp    %rcx,%r11
  82157b:	jae    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  821581:	mov    %rax,%r11
  821584:	cmp    %rcx,%rax
  821587:	jbe    821530 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  821589:	jmp    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  82158e:	lea    0x60d11b(%rip),%rdx        # e2e6b0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x108>
  821595:	mov    %r10,%rdi
  821598:	call   *0x65ea92(%rip)        # e80030 <_DYNAMIC+0x4f8>
  82159e:	lea    0x60d0f3(%rip),%rdx        # e2e698 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0xf0>
  8215a5:	mov    %r10,%rdi
  8215a8:	call   *0x65ea82(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8215ae:	lea    0x60d21b(%rip),%rdi        # e2e7d0 <anon.36d49f465d299f05a84fba3771e6457e.33.llvm.4447969268566763096+0x10>
  8215b5:	call   *0x65eb55(%rip)        # e80110 <_DYNAMIC+0x5d8>
  8215bb:	lea    0x60d106(%rip),%rdx        # e2e6c8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x120>
  8215c2:	mov    %r10,%rdi
  8215c5:	call   *0x65ea65(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8215cb:	lea    0x60d10e(%rip),%rdx        # e2e6e0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x138>
  8215d2:	mov    %r10,%rdi
  8215d5:	mov    0xb8(%rsp),%rsi
  8215dd:	call   *0x65ea4d(%rip)        # e80030 <_DYNAMIC+0x4f8>
