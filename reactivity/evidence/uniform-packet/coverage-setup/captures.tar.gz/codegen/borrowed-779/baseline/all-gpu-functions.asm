
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008163f0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  8163f0:	push   %rbx
  8163f1:	test   %rdi,%rdi
  8163f4:	je     816457 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  8163f6:	mov    %rdi,%rbx
  8163f9:	mov    (%rdi),%rsi
  8163fc:	test   %rsi,%rsi
  8163ff:	je     816414 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816401:	mov    0x8(%rbx),%rdi
  816405:	shl    $0x3,%rsi
  816409:	mov    $0x8,%edx
  81640e:	call   *0x66996c(%rip)        # e7fd80 <_DYNAMIC+0x248>
  816414:	mov    0x20(%rbx),%rsi
  816418:	test   %rsi,%rsi
  81641b:	je     816443 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81641d:	mov    %rsi,%rax
  816420:	shl    $0x4,%rax
  816424:	add    %rax,%rsi
  816427:	add    $0x21,%rsi
  81642b:	je     816443 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81642d:	mov    0x18(%rbx),%rdi
  816431:	sub    %rax,%rdi
  816434:	add    $0xfffffffffffffff0,%rdi
  816438:	mov    $0x10,%edx
  81643d:	call   *0x66993d(%rip)        # e7fd80 <_DYNAMIC+0x248>
  816443:	mov    $0x80,%esi
  816448:	mov    $0x8,%edx
  81644d:	mov    %rbx,%rdi
  816450:	pop    %rbx
  816451:	jmp    *0x669929(%rip)        # e7fd80 <_DYNAMIC+0x248>
  816457:	pop    %rbx
  816458:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816a60 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816a60:	push   %rbx
  816a61:	cmpb   $0x3,0x19c(%rdi)
  816a68:	jne    816a97 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816a6a:	movzbl 0x28(%rdi),%eax
  816a6e:	cmp    $0x4,%eax
  816a71:	je     816a85 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816a73:	cmp    $0x3,%eax
  816a76:	jne    816a97 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816a78:	add    $0x168,%rdi
  816a7f:	pop    %rbx
  816a80:	jmp    8169d0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816a85:	mov    %rdi,%rbx
  816a88:	add    $0x30,%rdi
  816a8c:	call   816ab0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816a91:	movw   $0x0,0x29(%rbx)
  816a97:	pop    %rbx
  816a98:	ret
  816a99:	movw   $0x0,0x29(%rbx)
  816a9f:	mov    %rax,%rdi
  816aa2:	call   e2c890 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816ab0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816ab0:	push   %r15
  816ab2:	push   %r14
  816ab4:	push   %r12
  816ab6:	push   %rbx
  816ab7:	push   %rax
  816ab8:	mov    %rdi,%rbx
  816abb:	movzbl 0x9e(%rdi),%eax
  816ac2:	test   %eax,%eax
  816ac4:	je     816b8b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816aca:	cmp    $0x3,%eax
  816acd:	jne    816bc1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816ad3:	mov    0x20(%rbx),%r15
  816ad7:	mov    0x28(%rbx),%r12
  816adb:	mov    (%r12),%rax
  816adf:	test   %rax,%rax
  816ae2:	je     816ae9 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816ae4:	mov    %r15,%rdi
  816ae7:	call   *%rax
  816ae9:	mov    0x8(%r12),%rsi
  816aee:	test   %rsi,%rsi
  816af1:	je     816b01 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816af3:	mov    0x10(%r12),%rdx
  816af8:	mov    %r15,%rdi
  816afb:	call   *0x66927f(%rip)        # e7fd80 <_DYNAMIC+0x248>
  816b01:	mov    0x68(%rbx),%rax
  816b05:	lock decq (%rax)
  816b09:	jne    816b15 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816b0b:	lea    0x68(%rbx),%rdi
  816b0f:	call   *0x66948b(%rip)        # e7ffa0 <_DYNAMIC+0x468>
  816b15:	movb   $0x0,0x98(%rbx)
  816b1c:	mov    0x60(%rbx),%rax
  816b20:	lock decq (%rax)
  816b24:	jne    816b2f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816b26:	lea    0x60(%rbx),%rdi
  816b2a:	call   812c30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816b2f:	movw   $0x0,0x99(%rbx)
  816b38:	mov    0x40(%rbx),%rax
  816b3c:	lock decq (%rax)
  816b40:	jne    816b4c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816b42:	lea    0x40(%rbx),%rdi
  816b46:	call   *0x66945c(%rip)        # e7ffa8 <_DYNAMIC+0x470>
  816b4c:	movb   $0x0,0x9b(%rbx)
  816b53:	mov    0x38(%rbx),%rax
  816b57:	lock decq (%rax)
  816b5b:	jne    816b67 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816b5d:	lea    0x38(%rbx),%rdi
  816b61:	call   *0x669449(%rip)        # e7ffb0 <_DYNAMIC+0x478>
  816b67:	movb   $0x0,0x9c(%rbx)
  816b6e:	mov    0x30(%rbx),%rax
  816b72:	lock decq (%rax)
  816b76:	jne    816b82 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816b78:	lea    0x30(%rbx),%rdi
  816b7c:	call   *0x669436(%rip)        # e7ffb8 <_DYNAMIC+0x480>
  816b82:	movb   $0x0,0x9d(%rbx)
  816b89:	jmp    816bc1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816b8b:	mov    0x70(%rbx),%rax
  816b8f:	lock decq (%rax)
  816b93:	jne    816b9f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816b95:	lea    0x70(%rbx),%rdi
  816b99:	call   *0x669419(%rip)        # e7ffb8 <_DYNAMIC+0x480>
  816b9f:	mov    0x78(%rbx),%rax
  816ba3:	lock decq (%rax)
  816ba7:	jne    816bc1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816ba9:	add    $0x78,%rbx
  816bad:	mov    %rbx,%rdi
  816bb0:	add    $0x8,%rsp
  816bb4:	pop    %rbx
  816bb5:	pop    %r12
  816bb7:	pop    %r14
  816bb9:	pop    %r15
  816bbb:	jmp    *0x6693ef(%rip)        # e7ffb0 <_DYNAMIC+0x478>
  816bc1:	add    $0x8,%rsp
  816bc5:	pop    %rbx
  816bc6:	pop    %r12
  816bc8:	pop    %r14
  816bca:	pop    %r15
  816bcc:	ret
  816bcd:	mov    %rax,%r14
  816bd0:	movb   $0x0,0x9d(%rbx)
  816bd7:	mov    %r14,%rdi
  816bda:	call   e2c890 <_Unwind_Resume@plt>
  816bdf:	mov    %rax,%r14
  816be2:	jmp    816c9c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816be7:	mov    %rax,%r14
  816bea:	jmp    816c81 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816bef:	mov    %rax,%r14
  816bf2:	jmp    816c64 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816bf4:	mov    %rax,%r14
  816bf7:	jmp    816c4a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816bf9:	mov    %rax,%r14
  816bfc:	mov    0x78(%rbx),%rax
  816c00:	lock decq (%rax)
  816c04:	jne    816c13 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816c06:	add    $0x78,%rbx
  816c0a:	mov    %rbx,%rdi
  816c0d:	call   *0x66939d(%rip)        # e7ffb0 <_DYNAMIC+0x478>
  816c13:	mov    %r14,%rdi
  816c16:	call   e2c890 <_Unwind_Resume@plt>
  816c1b:	mov    %rax,%r14
  816c1e:	mov    0x8(%r12),%rsi
  816c23:	test   %rsi,%rsi
  816c26:	je     816c36 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816c28:	mov    0x10(%r12),%rdx
  816c2d:	mov    %r15,%rdi
  816c30:	call   *0x66914a(%rip)        # e7fd80 <_DYNAMIC+0x248>
  816c36:	mov    0x68(%rbx),%rax
  816c3a:	lock decq (%rax)
  816c3e:	jne    816c4a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816c40:	lea    0x68(%rbx),%rdi
  816c44:	call   *0x669356(%rip)        # e7ffa0 <_DYNAMIC+0x468>
  816c4a:	movb   $0x0,0x98(%rbx)
  816c51:	mov    0x60(%rbx),%rax
  816c55:	lock decq (%rax)
  816c59:	jne    816c64 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816c5b:	lea    0x60(%rbx),%rdi
  816c5f:	call   812c30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816c64:	movw   $0x0,0x99(%rbx)
  816c6d:	mov    0x40(%rbx),%rax
  816c71:	lock decq (%rax)
  816c75:	jne    816c81 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816c77:	lea    0x40(%rbx),%rdi
  816c7b:	call   *0x669327(%rip)        # e7ffa8 <_DYNAMIC+0x470>
  816c81:	movb   $0x0,0x9b(%rbx)
  816c88:	mov    0x38(%rbx),%rax
  816c8c:	lock decq (%rax)
  816c90:	jne    816c9c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816c92:	lea    0x38(%rbx),%rdi
  816c96:	call   *0x669314(%rip)        # e7ffb0 <_DYNAMIC+0x478>
  816c9c:	movb   $0x0,0x9c(%rbx)
  816ca3:	mov    0x30(%rbx),%rax
  816ca7:	lock decq (%rax)
  816cab:	jne    816cb7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816cad:	lea    0x30(%rbx),%rdi
  816cb1:	call   *0x669301(%rip)        # e7ffb8 <_DYNAMIC+0x480>
  816cb7:	movb   $0x0,0x9d(%rbx)
  816cbe:	mov    %r14,%rdi
  816cc1:	call   e2c890 <_Unwind_Resume@plt>
  816cc6:	call   *0x6690bc(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816cd0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816cd0:	push   %rbx
  816cd1:	movzbl 0x20(%rdi),%eax
  816cd5:	cmp    $0x3,%eax
  816cd8:	je     816cf3 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816cda:	cmp    $0x4,%eax
  816cdd:	jne    816d00 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816cdf:	mov    %rdi,%rbx
  816ce2:	add    $0x28,%rdi
  816ce6:	call   816ab0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816ceb:	movw   $0x0,0x21(%rbx)
  816cf1:	pop    %rbx
  816cf2:	ret
  816cf3:	add    $0x160,%rdi
  816cfa:	pop    %rbx
  816cfb:	jmp    8169d0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816d00:	pop    %rbx
  816d01:	ret
  816d02:	movw   $0x0,0x21(%rbx)
  816d08:	mov    %rax,%rdi
  816d0b:	call   e2c890 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008171f0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  8171f0:	push   %r14
  8171f2:	push   %rbx
  8171f3:	push   %rax
  8171f4:	mov    %rdi,%rbx
  8171f7:	mov    (%rdi),%rax
  8171fa:	lock decq (%rax)
  8171fe:	jne    817209 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817200:	mov    %rbx,%rdi
  817203:	call   *0x668daf(%rip)        # e7ffb8 <_DYNAMIC+0x480>
  817209:	mov    0x8(%rbx),%rax
  81720d:	lock decq (%rax)
  817211:	jne    81721d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  817213:	lea    0x8(%rbx),%rdi
  817217:	call   *0x668d93(%rip)        # e7ffb0 <_DYNAMIC+0x478>
  81721d:	mov    0x10(%rbx),%rax
  817221:	lock decq (%rax)
  817225:	jne    817230 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  817227:	lea    0x10(%rbx),%rdi
  81722b:	call   812c30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  817230:	mov    0x18(%rbx),%rax
  817234:	lock decq (%rax)
  817238:	jne    81724e <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  81723a:	add    $0x18,%rbx
  81723e:	mov    %rbx,%rdi
  817241:	add    $0x8,%rsp
  817245:	pop    %rbx
  817246:	pop    %r14
  817248:	jmp    *0x668d52(%rip)        # e7ffa0 <_DYNAMIC+0x468>
  81724e:	add    $0x8,%rsp
  817252:	pop    %rbx
  817253:	pop    %r14
  817255:	ret
  817256:	mov    %rax,%r14
  817259:	jmp    81728a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  81725b:	mov    %rax,%r14
  81725e:	jmp    817277 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  817260:	mov    %rax,%r14
  817263:	mov    0x8(%rbx),%rax
  817267:	lock decq (%rax)
  81726b:	jne    817277 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  81726d:	lea    0x8(%rbx),%rdi
  817271:	call   *0x668d39(%rip)        # e7ffb0 <_DYNAMIC+0x478>
  817277:	mov    0x10(%rbx),%rax
  81727b:	lock decq (%rax)
  81727f:	jne    81728a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  817281:	lea    0x10(%rbx),%rdi
  817285:	call   812c30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81728a:	mov    0x18(%rbx),%rax
  81728e:	lock decq (%rax)
  817292:	jne    8172a1 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  817294:	add    $0x18,%rbx
  817298:	mov    %rbx,%rdi
  81729b:	call   *0x668cff(%rip)        # e7ffa0 <_DYNAMIC+0x468>
  8172a1:	mov    %r14,%rdi
  8172a4:	call   e2c890 <_Unwind_Resume@plt>
  8172a9:	call   *0x668ad9(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1253 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008172b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  8172b0:	push   %r14
  8172b2:	push   %rbx
  8172b3:	push   %rax
  8172b4:	mov    %rdi,%rbx
  8172b7:	mov    0x228(%rdi),%rax
  8172be:	lock decq (%rax)
  8172c2:	jne    8172d1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  8172c4:	lea    0x228(%rbx),%rdi
  8172cb:	call   *0x668ccf(%rip)        # e7ffa0 <_DYNAMIC+0x468>
  8172d1:	mov    0x230(%rbx),%rax
  8172d8:	lock decq (%rax)
  8172dc:	jne    8172eb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  8172de:	lea    0x230(%rbx),%rdi
  8172e5:	call   *0x668d55(%rip)        # e80040 <_DYNAMIC+0x508>
  8172eb:	mov    0x238(%rbx),%rax
  8172f2:	lock decq (%rax)
  8172f6:	jne    817305 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  8172f8:	lea    0x238(%rbx),%rdi
  8172ff:	call   *0x668d43(%rip)        # e80048 <_DYNAMIC+0x510>
  817305:	mov    0x258(%rbx),%rax
  81730c:	lock decq (%rax)
  817310:	jne    81731f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  817312:	lea    0x258(%rbx),%rdi
  817319:	call   *0x668d21(%rip)        # e80040 <_DYNAMIC+0x508>
  81731f:	mov    0x260(%rbx),%rax
  817326:	lock decq (%rax)
  81732a:	jne    817339 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  81732c:	lea    0x260(%rbx),%rdi
  817333:	call   *0x668d0f(%rip)        # e80048 <_DYNAMIC+0x510>
  817339:	mov    0x280(%rbx),%rax
  817340:	lock decq (%rax)
  817344:	jne    817353 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  817346:	lea    0x280(%rbx),%rdi
  81734d:	call   *0x668ced(%rip)        # e80040 <_DYNAMIC+0x508>
  817353:	mov    0x288(%rbx),%rax
  81735a:	lock decq (%rax)
  81735e:	jne    81736d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  817360:	lea    0x288(%rbx),%rdi
  817367:	call   *0x668cdb(%rip)        # e80048 <_DYNAMIC+0x510>
  81736d:	mov    0x2a8(%rbx),%rax
  817374:	lock decq (%rax)
  817378:	jne    817387 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  81737a:	lea    0x2a8(%rbx),%rdi
  817381:	call   *0x668cb9(%rip)        # e80040 <_DYNAMIC+0x508>
  817387:	mov    0x2b0(%rbx),%rax
  81738e:	lock decq (%rax)
  817392:	jne    8173a1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  817394:	lea    0x2b0(%rbx),%rdi
  81739b:	call   *0x668ca7(%rip)        # e80048 <_DYNAMIC+0x510>
  8173a1:	mov    0x2d0(%rbx),%rax
  8173a8:	lock decq (%rax)
  8173ac:	jne    8173bb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  8173ae:	lea    0x2d0(%rbx),%rdi
  8173b5:	call   *0x668c85(%rip)        # e80040 <_DYNAMIC+0x508>
  8173bb:	mov    0x2d8(%rbx),%rax
  8173c2:	lock decq (%rax)
  8173c6:	jne    8173d5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  8173c8:	lea    0x2d8(%rbx),%rdi
  8173cf:	call   *0x668c73(%rip)        # e80048 <_DYNAMIC+0x510>
  8173d5:	lea    0x78(%rbx),%rdi
  8173d9:	call   8177a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  8173de:	mov    0x328(%rbx),%r14
  8173e5:	test   %r14,%r14
  8173e8:	je     817447 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  8173ea:	mov    (%r14),%rsi
  8173ed:	test   %rsi,%rsi
  8173f0:	je     817405 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  8173f2:	mov    0x8(%r14),%rdi
  8173f6:	shl    $0x3,%rsi
  8173fa:	mov    $0x8,%edx
  8173ff:	call   *0x66897b(%rip)        # e7fd80 <_DYNAMIC+0x248>
  817405:	mov    0x20(%r14),%rsi
  817409:	test   %rsi,%rsi
  81740c:	je     817434 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81740e:	mov    %rsi,%rax
  817411:	shl    $0x4,%rax
  817415:	add    %rax,%rsi
  817418:	add    $0x21,%rsi
  81741c:	je     817434 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81741e:	mov    0x18(%r14),%rdi
  817422:	sub    %rax,%rdi
  817425:	add    $0xfffffffffffffff0,%rdi
  817429:	mov    $0x10,%edx
  81742e:	call   *0x66894c(%rip)        # e7fd80 <_DYNAMIC+0x248>
  817434:	mov    $0x80,%esi
  817439:	mov    $0x8,%edx
  81743e:	mov    %r14,%rdi
  817441:	call   *0x668939(%rip)        # e7fd80 <_DYNAMIC+0x248>
  817447:	mov    (%rbx),%rsi
  81744a:	test   %rsi,%rsi
  81744d:	je     817462 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  81744f:	mov    0x8(%rbx),%rdi
  817453:	shl    $0x4,%rsi
  817457:	mov    $0x4,%edx
  81745c:	call   *0x66891e(%rip)        # e7fd80 <_DYNAMIC+0x248>
  817462:	mov    0x18(%rbx),%rsi
  817466:	test   %rsi,%rsi
  817469:	je     81747e <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  81746b:	mov    0x20(%rbx),%rdi
  81746f:	shl    $0x3,%rsi
  817473:	mov    $0x4,%edx
  817478:	call   *0x668902(%rip)        # e7fd80 <_DYNAMIC+0x248>
  81747e:	mov    0x30(%rbx),%rsi
  817482:	test   %rsi,%rsi
  817485:	je     81749a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817487:	mov    0x38(%rbx),%rdi
  81748b:	shl    $0x2,%rsi
  81748f:	mov    $0x4,%edx
  817494:	call   *0x6688e6(%rip)        # e7fd80 <_DYNAMIC+0x248>
  81749a:	mov    0x48(%rbx),%rsi
  81749e:	test   %rsi,%rsi
  8174a1:	je     8174b6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  8174a3:	mov    0x50(%rbx),%rdi
  8174a7:	shl    $0x2,%rsi
  8174ab:	mov    $0x4,%edx
  8174b0:	call   *0x6688ca(%rip)        # e7fd80 <_DYNAMIC+0x248>
  8174b6:	mov    0x60(%rbx),%rsi
  8174ba:	test   %rsi,%rsi
  8174bd:	je     8174d2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  8174bf:	mov    0x68(%rbx),%rdi
  8174c3:	shl    $0x5,%rsi
  8174c7:	mov    $0x4,%edx
  8174cc:	call   *0x6688ae(%rip)        # e7fd80 <_DYNAMIC+0x248>
  8174d2:	mov    0x300(%rbx),%rsi
  8174d9:	test   %rsi,%rsi
  8174dc:	je     81750c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  8174de:	lea    (%rsi,%rsi,8),%rax
  8174e2:	lea    0x33(,%rax,4),%rax
  8174ea:	and    $0xfffffffffffffff0,%rax
  8174ee:	add    %rax,%rsi
  8174f1:	add    $0x11,%rsi
  8174f5:	je     81750c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  8174f7:	mov    0x2f8(%rbx),%rdi
  8174fe:	sub    %rax,%rdi
  817501:	mov    $0x10,%edx
  817506:	call   *0x668874(%rip)        # e7fd80 <_DYNAMIC+0x248>
  81750c:	mov    0x330(%rbx),%rax
  817513:	test   %rax,%rax
  817516:	je     817535 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  817518:	lock decq (%rax)
  81751c:	jne    817535 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  81751e:	add    $0x330,%rbx
  817525:	mov    %rbx,%rdi
  817528:	add    $0x8,%rsp
  81752c:	pop    %rbx
  81752d:	pop    %r14
  81752f:	jmp    *0x668b1b(%rip)        # e80050 <_DYNAMIC+0x518>
  817535:	add    $0x8,%rsp
  817539:	pop    %rbx
  81753a:	pop    %r14
  81753c:	ret
  81753d:	mov    %rax,%r14
  817540:	jmp    81766c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817545:	mov    %rax,%r14
  817548:	mov    0x2d8(%rbx),%rax
  81754f:	lock decq (%rax)
  817553:	jne    81766c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817559:	lea    0x2d8(%rbx),%rdi
  817560:	call   *0x668ae2(%rip)        # e80048 <_DYNAMIC+0x510>
  817566:	jmp    81766c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  81756b:	call   *0x668817(%rip)        # e7fd88 <_DYNAMIC+0x250>
  817571:	mov    %rax,%r14
  817574:	jmp    817660 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  817579:	mov    %rax,%r14
  81757c:	mov    0x2b0(%rbx),%rax
  817583:	lock decq (%rax)
  817587:	jne    817660 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81758d:	lea    0x2b0(%rbx),%rdi
  817594:	call   *0x668aae(%rip)        # e80048 <_DYNAMIC+0x510>
  81759a:	jmp    817660 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81759f:	call   *0x6687e3(%rip)        # e7fd88 <_DYNAMIC+0x250>
  8175a5:	mov    %rax,%r14
  8175a8:	jmp    817654 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8175ad:	mov    %rax,%r14
  8175b0:	mov    0x288(%rbx),%rax
  8175b7:	lock decq (%rax)
  8175bb:	jne    817654 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8175c1:	lea    0x288(%rbx),%rdi
  8175c8:	call   *0x668a7a(%rip)        # e80048 <_DYNAMIC+0x510>
  8175ce:	jmp    817654 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8175d3:	call   *0x6687af(%rip)        # e7fd88 <_DYNAMIC+0x250>
  8175d9:	mov    %rax,%r14
  8175dc:	jmp    817648 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8175de:	mov    %rax,%r14
  8175e1:	mov    0x260(%rbx),%rax
  8175e8:	lock decq (%rax)
  8175ec:	jne    817648 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8175ee:	lea    0x260(%rbx),%rdi
  8175f5:	call   *0x668a4d(%rip)        # e80048 <_DYNAMIC+0x510>
  8175fb:	jmp    817648 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8175fd:	call   *0x668785(%rip)        # e7fd88 <_DYNAMIC+0x250>
  817603:	mov    %rax,%r14
  817606:	jmp    81763c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817608:	mov    %rax,%r14
  81760b:	mov    0x238(%rbx),%rax
  817612:	lock decq (%rax)
  817616:	jne    81763c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817618:	lea    0x238(%rbx),%rdi
  81761f:	call   *0x668a23(%rip)        # e80048 <_DYNAMIC+0x510>
  817625:	jmp    81763c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817627:	call   *0x66875b(%rip)        # e7fd88 <_DYNAMIC+0x250>
  81762d:	mov    %rax,%r14
  817630:	lea    0x230(%rbx),%rdi
  817637:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81763c:	lea    0x258(%rbx),%rdi
  817643:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817648:	lea    0x280(%rbx),%rdi
  81764f:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817654:	lea    0x2a8(%rbx),%rdi
  81765b:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817660:	lea    0x2d0(%rbx),%rdi
  817667:	call   8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81766c:	lea    0x78(%rbx),%rdi
  817670:	call   8177a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  817675:	mov    0x328(%rbx),%rdi
  81767c:	call   8163f0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  817681:	mov    (%rbx),%rsi
  817684:	test   %rsi,%rsi
  817687:	jne    817702 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  817689:	mov    0x18(%rbx),%rsi
  81768d:	test   %rsi,%rsi
  817690:	jne    817722 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  817696:	mov    0x30(%rbx),%rsi
  81769a:	test   %rsi,%rsi
  81769d:	jne    817742 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  8176a3:	mov    0x48(%rbx),%rsi
  8176a7:	test   %rsi,%rsi
  8176aa:	jne    817762 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  8176b0:	mov    0x60(%rbx),%rsi
  8176b4:	test   %rsi,%rsi
  8176b7:	je     8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  8176b9:	mov    0x68(%rbx),%rdi
  8176bd:	shl    $0x5,%rsi
  8176c1:	mov    $0x4,%edx
  8176c6:	call   *0x6686b4(%rip)        # e7fd80 <_DYNAMIC+0x248>
  8176cc:	lea    0x2f8(%rbx),%rdi
  8176d3:	call   819bb0 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  8176d8:	mov    0x330(%rbx),%rax
  8176df:	test   %rax,%rax
  8176e2:	je     8176fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8176e4:	lock decq (%rax)
  8176e8:	jne    8176fa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8176ea:	add    $0x330,%rbx
  8176f1:	mov    %rbx,%rdi
  8176f4:	call   *0x668956(%rip)        # e80050 <_DYNAMIC+0x518>
  8176fa:	mov    %r14,%rdi
  8176fd:	call   e2c890 <_Unwind_Resume@plt>
  817702:	mov    0x8(%rbx),%rdi
  817706:	shl    $0x4,%rsi
  81770a:	mov    $0x4,%edx
  81770f:	call   *0x66866b(%rip)        # e7fd80 <_DYNAMIC+0x248>
  817715:	mov    0x18(%rbx),%rsi
  817719:	test   %rsi,%rsi
  81771c:	je     817696 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  817722:	mov    0x20(%rbx),%rdi
  817726:	shl    $0x3,%rsi
  81772a:	mov    $0x4,%edx
  81772f:	call   *0x66864b(%rip)        # e7fd80 <_DYNAMIC+0x248>
  817735:	mov    0x30(%rbx),%rsi
  817739:	test   %rsi,%rsi
  81773c:	je     8176a3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  817742:	mov    0x38(%rbx),%rdi
  817746:	shl    $0x2,%rsi
  81774a:	mov    $0x4,%edx
  81774f:	call   *0x66862b(%rip)        # e7fd80 <_DYNAMIC+0x248>
  817755:	mov    0x48(%rbx),%rsi
  817759:	test   %rsi,%rsi
  81775c:	je     8176b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  817762:	mov    0x50(%rbx),%rdi
  817766:	shl    $0x2,%rsi
  81776a:	mov    $0x4,%edx
  81776f:	call   *0x66860b(%rip)        # e7fd80 <_DYNAMIC+0x248>
  817775:	mov    0x60(%rbx),%rsi
  817779:	test   %rsi,%rsi
  81777c:	jne    8176b9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  817782:	jmp    8176cc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817787:	call   *0x6685fb(%rip)        # e7fd88 <_DYNAMIC+0x250>
  81778d:	mov    %rax,%r14
  817790:	jmp    817675 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008177a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  8177a0:	push   %r14
  8177a2:	push   %rbx
  8177a3:	push   %rax
  8177a4:	mov    %rdi,%rbx
  8177a7:	mov    (%rdi),%rax
  8177aa:	lock decq (%rax)
  8177ae:	jne    8177b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  8177b0:	mov    %rbx,%rdi
  8177b3:	call   *0x668867(%rip)        # e80020 <_DYNAMIC+0x4e8>
  8177b9:	mov    0x50(%rbx),%rax
  8177bd:	lock decq (%rax)
  8177c1:	jne    8177cd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  8177c3:	lea    0x50(%rbx),%rdi
  8177c7:	call   *0x66884b(%rip)        # e80018 <_DYNAMIC+0x4e0>
  8177cd:	mov    0x58(%rbx),%rax
  8177d1:	lock decq (%rax)
  8177d5:	jne    8177e1 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  8177d7:	lea    0x58(%rbx),%rdi
  8177db:	call   *0x66883f(%rip)        # e80020 <_DYNAMIC+0x4e8>
  8177e1:	mov    0xb0(%rbx),%rsi
  8177e8:	test   %rsi,%rsi
  8177eb:	je     81781d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8177ed:	mov    %rsi,%rax
  8177f0:	shl    $0x5,%rax
  8177f4:	add    %rax,%rsi
  8177f7:	add    $0x31,%rsi
  8177fb:	je     81781d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8177fd:	mov    0xa8(%rbx),%rdi
  817804:	sub    %rax,%rdi
  817807:	add    $0xffffffffffffffe0,%rdi
  81780b:	mov    $0x10,%edx
  817810:	add    $0x8,%rsp
  817814:	pop    %rbx
  817815:	pop    %r14
  817817:	jmp    *0x668563(%rip)        # e7fd80 <_DYNAMIC+0x248>
  81781d:	add    $0x8,%rsp
  817821:	pop    %rbx
  817822:	pop    %r14
  817824:	ret
  817825:	mov    %rax,%r14
  817828:	jmp    817855 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81782a:	mov    %rax,%r14
  81782d:	mov    0x58(%rbx),%rax
  817831:	lock decq (%rax)
  817835:	jne    817855 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817837:	lea    0x58(%rbx),%rdi
  81783b:	call   *0x6687df(%rip)        # e80020 <_DYNAMIC+0x4e8>
  817841:	jmp    817855 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817843:	call   *0x66853f(%rip)        # e7fd88 <_DYNAMIC+0x250>
  817849:	mov    %rax,%r14
  81784c:	lea    0x50(%rbx),%rdi
  817850:	call   8179a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  817855:	add    $0xa8,%rbx
  81785c:	mov    %rbx,%rdi
  81785f:	call   819bf0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  817864:	mov    %r14,%rdi
  817867:	call   e2c890 <_Unwind_Resume@plt>
  81786c:	call   *0x668516(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817880 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817880:	cmpl   $0x1,(%rdi)
  817883:	ja     81789d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817885:	mov    0x8(%rdi),%rsi
  817889:	test   %rsi,%rsi
  81788c:	je     81789d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  81788e:	mov    0x10(%rdi),%rdi
  817892:	mov    $0x1,%edx
  817897:	jmp    *0x6684e3(%rip)        # e7fd80 <_DYNAMIC+0x248>
  81789d:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8178a0:	push   %r14
  8178a2:	push   %rbx
  8178a3:	push   %rax
  8178a4:	mov    %rdi,%rbx
  8178a7:	mov    (%rdi),%rax
  8178aa:	lock decq (%rax)
  8178ae:	jne    8178b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  8178b0:	mov    %rbx,%rdi
  8178b3:	call   *0x668787(%rip)        # e80040 <_DYNAMIC+0x508>
  8178b9:	mov    0x8(%rbx),%rax
  8178bd:	lock decq (%rax)
  8178c1:	jne    8178d7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  8178c3:	add    $0x8,%rbx
  8178c7:	mov    %rbx,%rdi
  8178ca:	add    $0x8,%rsp
  8178ce:	pop    %rbx
  8178cf:	pop    %r14
  8178d1:	jmp    *0x668771(%rip)        # e80048 <_DYNAMIC+0x510>
  8178d7:	add    $0x8,%rsp
  8178db:	pop    %rbx
  8178dc:	pop    %r14
  8178de:	ret
  8178df:	mov    %rax,%r14
  8178e2:	mov    0x8(%rbx),%rax
  8178e6:	lock decq (%rax)
  8178ea:	jne    8178f9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  8178ec:	add    $0x8,%rbx
  8178f0:	mov    %rbx,%rdi
  8178f3:	call   *0x66874f(%rip)        # e80048 <_DYNAMIC+0x510>
  8178f9:	mov    %r14,%rdi
  8178fc:	call   e2c890 <_Unwind_Resume@plt>
  817901:	call   *0x668481(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000818270 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  818270:	sub    $0x18,%rsp
  818274:	mov    %rsi,%rax
  818277:	mov    (%rdi),%ecx
  818279:	lea    -0x747420(%rip),%rdx        # d0e60 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  818280:	movslq (%rdx,%rcx,4),%rcx
  818284:	add    %rdx,%rcx
  818287:	jmp    *%rcx
  818289:	add    $0x8,%rdi
  81828d:	mov    %rdi,0x10(%rsp)
  818292:	lea    -0x743b35(%rip),%rsi        # d4764 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44bc>
  818299:	jmp    818328 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  81829e:	lea    -0x743b18(%rip),%rsi        # d478d <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44e5>
  8182a5:	mov    $0x13,%edx
  8182aa:	mov    %rax,%rdi
  8182ad:	add    $0x18,%rsp
  8182b1:	jmp    *0x667bb9(%rip)        # e7fe70 <_DYNAMIC+0x338>
  8182b7:	add    $0x4,%rdi
  8182bb:	mov    %rdi,0x10(%rsp)
  8182c0:	lea    -0x743b57(%rip),%rsi        # d4770 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44c8>
  8182c7:	lea    0x615eca(%rip),%r8        # e2e198 <__frame_dummy_init_array_entry+0x8c8>
  8182ce:	lea    0x10(%rsp),%rcx
  8182d3:	mov    $0x11,%edx
  8182d8:	mov    %rax,%rdi
  8182db:	call   *0x667b97(%rip)        # e7fe78 <_DYNAMIC+0x340>
  8182e1:	add    $0x18,%rsp
  8182e5:	ret
  8182e6:	lea    -0x743b6c(%rip),%rsi        # d4781 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44d9>
  8182ed:	mov    $0xc,%edx
  8182f2:	mov    %rax,%rdi
  8182f5:	add    $0x18,%rsp
  8182f9:	jmp    *0x667b71(%rip)        # e7fe70 <_DYNAMIC+0x338>
  8182ff:	lea    -0x743b50(%rip),%rsi        # d47b6 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x450e>
  818306:	mov    $0x9,%edx
  81830b:	mov    %rax,%rdi
  81830e:	add    $0x18,%rsp
  818312:	jmp    *0x667b58(%rip)        # e7fe70 <_DYNAMIC+0x338>
  818318:	add    $0x8,%rdi
  81831c:	mov    %rdi,0x10(%rsp)
  818321:	lea    -0x743bbe(%rip),%rsi        # d476a <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44c2>
  818328:	lea    0x615e49(%rip),%r8        # e2e178 <__frame_dummy_init_array_entry+0x8a8>
  81832f:	lea    0x10(%rsp),%rcx
  818334:	mov    $0x6,%edx
  818339:	mov    %rax,%rdi
  81833c:	call   *0x667b36(%rip)        # e7fe78 <_DYNAMIC+0x340>
  818342:	add    $0x18,%rsp
  818346:	ret
  818347:	add    $0x8,%rdi
  81834b:	mov    %rdi,0x10(%rsp)
  818350:	lea    0x615e61(%rip),%rcx        # e2e1b8 <__frame_dummy_init_array_entry+0x8e8>
  818357:	mov    %rcx,(%rsp)
  81835b:	lea    -0x743bc2(%rip),%rsi        # d47a0 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x44f8>
  818362:	lea    -0x7694fd(%rip),%rcx        # aee6c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  818369:	lea    0x10(%rsp),%r9
  81836e:	mov    $0x9,%edx
  818373:	mov    $0x4,%r8d
  818379:	mov    %rax,%rdi
  81837c:	call   *0x667cde(%rip)        # e80060 <_DYNAMIC+0x528>
  818382:	add    $0x18,%rsp
  818386:	ret
  818387:	lea    -0x743be5(%rip),%rsi        # d47a9 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4501>
  81838e:	mov    $0xd,%edx
  818393:	mov    %rax,%rdi
  818396:	add    $0x18,%rsp
  81839a:	jmp    *0x667ad0(%rip)        # e7fe70 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819bf0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819bf0:	mov    0x8(%rdi),%rsi
  819bf4:	test   %rsi,%rsi
  819bf7:	je     819c1e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819bf9:	mov    %rsi,%rax
  819bfc:	shl    $0x5,%rax
  819c00:	add    %rax,%rsi
  819c03:	add    $0x31,%rsi
  819c07:	je     819c1e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819c09:	mov    (%rdi),%rdi
  819c0c:	sub    %rax,%rdi
  819c0f:	add    $0xffffffffffffffe0,%rdi
  819c13:	mov    $0x10,%edx
  819c18:	jmp    *0x666162(%rip)        # e7fd80 <_DYNAMIC+0x248>
  819c1e:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819c20 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819c20:	mov    0x8(%rdi),%rsi
  819c24:	test   %rsi,%rsi
  819c27:	je     819c4e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819c29:	mov    %rsi,%rax
  819c2c:	shl    $0x4,%rax
  819c30:	add    %rax,%rsi
  819c33:	add    $0x21,%rsi
  819c37:	je     819c4e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819c39:	mov    (%rdi),%rdi
  819c3c:	sub    %rax,%rdi
  819c3f:	add    $0xfffffffffffffff0,%rdi
  819c43:	mov    $0x10,%edx
  819c48:	jmp    *0x666132(%rip)        # e7fd80 <_DYNAMIC+0x248>
  819c4e:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b4e0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b4e0:	push   %r14
  81b4e2:	push   %rbx
  81b4e3:	sub    $0x38,%rsp
  81b4e7:	mov    %rdi,%rbx
  81b4ea:	cmpq   $0x0,(%rsi)
  81b4ee:	je     81b5f8 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b4f4:	movdqu (%rsi),%xmm0
  81b4f8:	movdqu 0x10(%rsi),%xmm1
  81b4fd:	movdqu 0x20(%rsi),%xmm2
  81b502:	movdqa %xmm2,0x20(%rsp)
  81b508:	movdqa %xmm1,0x10(%rsp)
  81b50e:	movdqa %xmm0,(%rsp)
  81b513:	cmpq   $0x0,0x18(%rcx)
  81b518:	je     81b60c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b51e:	lea    0x10(%rsp),%rsi
  81b523:	lea    0x20(%rcx),%rdi
  81b527:	mov    %rcx,%r14
  81b52a:	call   824bc0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b52f:	mov    %rax,%rsi
  81b532:	shr    $0x39,%rsi
  81b536:	mov    (%r14),%rcx
  81b539:	mov    0x8(%r14),%rdx
  81b53d:	movd   %esi,%xmm0
  81b541:	punpcklbw %xmm0,%xmm0
  81b545:	pshuflw $0x0,%xmm0,%xmm0
  81b54a:	pshufd $0x44,%xmm0,%xmm0
  81b54f:	mov    0x10(%rsp),%rsi
  81b554:	movzwl 0x1c(%rsp),%edi
  81b559:	xor    %r8d,%r8d
  81b55c:	mov    0x18(%rsp),%r9d
  81b561:	pcmpeqd %xmm1,%xmm1
  81b565:	and    %rdx,%rax
  81b568:	movdqu (%rcx,%rax,1),%xmm2
  81b56d:	movdqa %xmm2,%xmm3
  81b571:	pcmpeqb %xmm0,%xmm3
  81b575:	pmovmskb %xmm3,%r10d
  81b57a:	test   %r10d,%r10d
  81b57d:	je     81b5c0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b57f:	tzcnt  %r10d,%r14d
  81b584:	add    %rax,%r14
  81b587:	and    %rdx,%r14
  81b58a:	shl    $0x5,%r14
  81b58e:	mov    %rcx,%r11
  81b591:	sub    %r14,%r11
  81b594:	cmp    -0x20(%r11),%rsi
  81b598:	jne    81b5a7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b59a:	cmp    -0x14(%r11),%di
  81b59f:	jne    81b5a7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b5a1:	cmp    -0x18(%r11),%r9d
  81b5a5:	je     81b5db <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b5a7:	lea    -0x1(%r10),%r11d
  81b5ab:	and    %r10w,%r11w
  81b5af:	mov    %r11d,%r10d
  81b5b2:	jne    81b57f <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b5b4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b5c0:	pcmpeqb %xmm1,%xmm2
  81b5c4:	pmovmskb %xmm2,%r10d
  81b5c9:	test   %r10d,%r10d
  81b5cc:	jne    81b60c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b5ce:	add    %r8,%rax
  81b5d1:	add    $0x10,%rax
  81b5d5:	add    $0x10,%r8
  81b5d9:	jmp    81b565 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b5db:	mov    -0x4(%r11),%eax
  81b5df:	shl    $0x10,%eax
  81b5e2:	or     -0x8(%r11),%eax
  81b5e6:	mov    -0x10(%r11),%rcx
  81b5ea:	mov    %rcx,(%rbx)
  81b5ed:	mov    %eax,0x8(%rbx)
  81b5f0:	add    $0x38,%rsp
  81b5f4:	pop    %rbx
  81b5f5:	pop    %r14
  81b5f7:	ret
  81b5f8:	mov    0x8(%rdx),%eax
  81b5fb:	mov    %eax,0x8(%rbx)
  81b5fe:	mov    (%rdx),%rax
  81b601:	mov    %rax,(%rbx)
  81b604:	add    $0x38,%rsp
  81b608:	pop    %rbx
  81b609:	pop    %r14
  81b60b:	ret
  81b60c:	lea    -0x746a71(%rip),%rdi        # d4ba2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b613:	lea    0x61301e(%rip),%rdx        # e2e638 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x90>
  81b61a:	mov    $0x16,%esi
  81b61f:	call   *0x664ab3(%rip)        # e800d8 <_DYNAMIC+0x5a0>

FUNCTION <gpui_gpu::renderer::Changes>::replace::<1: usize> bytes=105 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b630 <<gpui_gpu::renderer::Changes>::replace::<1>>:
  81b630:	cmp    %rdx,%rcx
  81b633:	jae    81b681 <<gpui_gpu::renderer::Changes>::replace::<1>+0x51>
  81b635:	mov    %rcx,%rax
  81b638:	shl    $0x4,%rax
  81b63c:	movdqu (%rsi,%rax,1),%xmm0
  81b641:	movdqu (%r8),%xmm1
  81b646:	pcmpeqb %xmm0,%xmm1
  81b64a:	pmovmskb %xmm1,%edx
  81b64e:	cmp    $0xffff,%edx
  81b654:	jne    81b657 <<gpui_gpu::renderer::Changes>::replace::<1>+0x27>
  81b656:	ret
  81b657:	add    %rax,%rsi
  81b65a:	mov    (%rdi),%rax
  81b65d:	mov    0x8(%rdi),%rdx
  81b661:	cmp    %rax,%rcx
  81b664:	cmovb  %rcx,%rax
  81b668:	inc    %rcx
  81b66b:	cmp    %rdx,%rcx
  81b66e:	cmovbe %rdx,%rcx
  81b672:	mov    %rax,(%rdi)
  81b675:	mov    %rcx,0x8(%rdi)
  81b679:	movups (%r8),%xmm0
  81b67d:	movups %xmm0,(%rsi)
  81b680:	ret
  81b681:	push   %rax
  81b682:	lea    0x1(%rcx),%rsi
  81b686:	lea    0x612f1b(%rip),%rax        # e2e5a8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096>
  81b68d:	mov    %rcx,%rdi
  81b690:	mov    %rax,%rcx
  81b693:	call   *0x6649e7(%rip)        # e80080 <_DYNAMIC+0x548>

FUNCTION <gpui_gpu::renderer::Changes>::replace::<2: usize> bytes=192 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b6a0 <<gpui_gpu::renderer::Changes>::replace::<2>>:
  81b6a0:	mov    %rsi,%rax
  81b6a3:	lea    0x2(%rcx),%rsi
  81b6a7:	cmp    $0xfffffffffffffffd,%rcx
  81b6ab:	ja     81b74c <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b6b1:	cmp    %rdx,%rsi
  81b6b4:	ja     81b74c <<gpui_gpu::renderer::Changes>::replace::<2>+0xac>
  81b6ba:	mov    %rcx,%r11
  81b6bd:	shl    $0x4,%r11
  81b6c1:	lea    (%rax,%r11,1),%rdx
  81b6c5:	mov    (%rdi),%r10
  81b6c8:	mov    0x8(%rdi),%r9
  81b6cc:	movdqu (%rax,%r11,1),%xmm0
  81b6d2:	movdqu (%r8),%xmm1
  81b6d7:	pcmpeqb %xmm0,%xmm1
  81b6db:	pmovmskb %xmm1,%eax
  81b6df:	cmp    $0xffff,%eax
  81b6e4:	je     81b708 <<gpui_gpu::renderer::Changes>::replace::<2>+0x68>
  81b6e6:	cmp    %r10,%rcx
  81b6e9:	cmovb  %rcx,%r10
  81b6ed:	lea    0x1(%rcx),%rax
  81b6f1:	cmp    %r9,%rax
  81b6f4:	cmova  %rax,%r9
  81b6f8:	mov    %r10,(%rdi)
  81b6fb:	mov    %r9,0x8(%rdi)
  81b6ff:	movdqu (%r8),%xmm0
  81b704:	movdqu %xmm0,(%rdx)
  81b708:	movdqu 0x10(%rdx),%xmm0
  81b70d:	movdqu 0x10(%r8),%xmm1
  81b713:	pcmpeqb %xmm0,%xmm1
  81b717:	pmovmskb %xmm1,%eax
  81b71b:	cmp    $0xffff,%eax
  81b720:	je     81b74b <<gpui_gpu::renderer::Changes>::replace::<2>+0xab>
  81b722:	add    $0x10,%rdx
  81b726:	add    $0x10,%r8
  81b72a:	inc    %rcx
  81b72d:	cmp    %r10,%rcx
  81b730:	cmovae %r10,%rcx
  81b734:	cmp    %r9,%rsi
  81b737:	cmova  %rsi,%r9
  81b73b:	mov    %rcx,(%rdi)
  81b73e:	mov    %r9,0x8(%rdi)
  81b742:	movdqu (%r8),%xmm0
  81b747:	movdqu %xmm0,(%rdx)
  81b74b:	ret
  81b74c:	push   %rax
  81b74d:	lea    0x612e54(%rip),%rax        # e2e5a8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096>
  81b754:	mov    %rcx,%rdi
  81b757:	mov    %rax,%rcx
  81b75a:	call   *0x664920(%rip)        # e80080 <_DYNAMIC+0x548>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81ba50:	push   %r14
  81ba52:	push   %rbx
  81ba53:	push   %rax
  81ba54:	mov    %rdi,%rbx
  81ba57:	mov    (%rdi),%rax
  81ba5a:	lock decq (%rax)
  81ba5e:	jne    81ba69 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81ba60:	mov    %rbx,%rdi
  81ba63:	call   *0x6645b7(%rip)        # e80020 <_DYNAMIC+0x4e8>
  81ba69:	mov    0x50(%rbx),%rax
  81ba6d:	lock decq (%rax)
  81ba71:	jne    81ba7d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81ba73:	lea    0x50(%rbx),%rdi
  81ba77:	call   *0x66459b(%rip)        # e80018 <_DYNAMIC+0x4e0>
  81ba7d:	mov    0x58(%rbx),%rax
  81ba81:	lock decq (%rax)
  81ba85:	jne    81ba91 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81ba87:	lea    0x58(%rbx),%rdi
  81ba8b:	call   *0x66458f(%rip)        # e80020 <_DYNAMIC+0x4e8>
  81ba91:	mov    0xb0(%rbx),%rsi
  81ba98:	test   %rsi,%rsi
  81ba9b:	je     81bacd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81ba9d:	mov    %rsi,%rax
  81baa0:	shl    $0x5,%rax
  81baa4:	add    %rax,%rsi
  81baa7:	add    $0x31,%rsi
  81baab:	je     81bacd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81baad:	mov    0xa8(%rbx),%rdi
  81bab4:	sub    %rax,%rdi
  81bab7:	add    $0xffffffffffffffe0,%rdi
  81babb:	mov    $0x10,%edx
  81bac0:	add    $0x8,%rsp
  81bac4:	pop    %rbx
  81bac5:	pop    %r14
  81bac7:	jmp    *0x6642b3(%rip)        # e7fd80 <_DYNAMIC+0x248>
  81bacd:	add    $0x8,%rsp
  81bad1:	pop    %rbx
  81bad2:	pop    %r14
  81bad4:	ret
  81bad5:	mov    %rax,%r14
  81bad8:	jmp    81bb05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bada:	mov    %rax,%r14
  81badd:	mov    0x58(%rbx),%rax
  81bae1:	lock decq (%rax)
  81bae5:	jne    81bb05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bae7:	lea    0x58(%rbx),%rdi
  81baeb:	call   *0x66452f(%rip)        # e80020 <_DYNAMIC+0x4e8>
  81baf1:	jmp    81bb05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81baf3:	call   *0x66428f(%rip)        # e7fd88 <_DYNAMIC+0x250>
  81baf9:	mov    %rax,%r14
  81bafc:	lea    0x50(%rbx),%rdi
  81bb00:	call   81c3a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bb05:	add    $0xa8,%rbx
  81bb0c:	mov    %rbx,%rdi
  81bb0f:	call   823130 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bb14:	mov    %r14,%rdi
  81bb17:	call   e2c890 <_Unwind_Resume@plt>
  81bb1c:	call   *0x664266(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bb30:	push   %r14
  81bb32:	push   %rbx
  81bb33:	push   %rax
  81bb34:	mov    %rdi,%rbx
  81bb37:	mov    (%rdi),%rax
  81bb3a:	lock decq (%rax)
  81bb3e:	jne    81bb49 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bb40:	mov    %rbx,%rdi
  81bb43:	call   *0x6644f7(%rip)        # e80040 <_DYNAMIC+0x508>
  81bb49:	mov    0x8(%rbx),%rax
  81bb4d:	lock decq (%rax)
  81bb51:	jne    81bb67 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bb53:	add    $0x8,%rbx
  81bb57:	mov    %rbx,%rdi
  81bb5a:	add    $0x8,%rsp
  81bb5e:	pop    %rbx
  81bb5f:	pop    %r14
  81bb61:	jmp    *0x6644e1(%rip)        # e80048 <_DYNAMIC+0x510>
  81bb67:	add    $0x8,%rsp
  81bb6b:	pop    %rbx
  81bb6c:	pop    %r14
  81bb6e:	ret
  81bb6f:	mov    %rax,%r14
  81bb72:	mov    0x8(%rbx),%rax
  81bb76:	lock decq (%rax)
  81bb7a:	jne    81bb89 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bb7c:	add    $0x8,%rbx
  81bb80:	mov    %rbx,%rdi
  81bb83:	call   *0x6644bf(%rip)        # e80048 <_DYNAMIC+0x510>
  81bb89:	mov    %r14,%rdi
  81bb8c:	call   e2c890 <_Unwind_Resume@plt>
  81bb91:	call   *0x6641f1(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c4d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c4d0:	push   %rbp
  81c4d1:	push   %r15
  81c4d3:	push   %r14
  81c4d5:	push   %r13
  81c4d7:	push   %r12
  81c4d9:	push   %rbx
  81c4da:	sub    $0x28,%rsp
  81c4de:	movss  0x8c(%rdi),%xmm3
  81c4e6:	movss  -0x76d4d2(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c4ee:	movaps %xmm3,%xmm1
  81c4f1:	subss  %xmm0,%xmm1
  81c4f5:	cvttss2si %xmm1,%rax
  81c4fa:	cvttss2si %xmm3,%r8
  81c4ff:	mov    %r8,%rcx
  81c502:	sar    $0x3f,%rcx
  81c506:	and    %rax,%rcx
  81c509:	or     %r8,%rcx
  81c50c:	xor    %r9d,%r9d
  81c50f:	xorps  %xmm1,%xmm1
  81c512:	ucomiss %xmm1,%xmm3
  81c515:	cmovb  %r9,%rcx
  81c519:	movss  -0x76d501(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c521:	ucomiss %xmm2,%xmm3
  81c524:	mov    $0xffffffffffffffff,%rax
  81c52b:	cmova  %rax,%rcx
  81c52f:	movss  0x94(%rdi),%xmm3
  81c537:	mov    %rcx,%r8
  81c53a:	shr    $0x4,%r8
  81c53e:	movaps %xmm3,%xmm4
  81c541:	subss  %xmm0,%xmm4
  81c545:	cvttss2si %xmm4,%r10
  81c54a:	cvttss2si %xmm3,%r11
  81c54f:	mov    %r11,%rbx
  81c552:	sar    $0x3f,%rbx
  81c556:	and    %r10,%rbx
  81c559:	or     %r11,%rbx
  81c55c:	ucomiss %xmm1,%xmm3
  81c55f:	cmovb  %r9,%rbx
  81c563:	ucomiss %xmm2,%xmm3
  81c566:	cmova  %rax,%rbx
  81c56a:	mov    %rsi,0x18(%rsp)
  81c56f:	lea    (%rcx,%rbx,1),%r11
  81c573:	dec    %r11
  81c576:	shr    $0x4,%r11
  81c57a:	cmp    %r11,%r8
  81c57d:	jbe    81c58e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c57f:	add    $0x28,%rsp
  81c583:	pop    %rbx
  81c584:	pop    %r12
  81c586:	pop    %r13
  81c588:	pop    %r14
  81c58a:	pop    %r15
  81c58c:	pop    %rbp
  81c58d:	ret
  81c58e:	movss  0x88(%rdi),%xmm3
  81c596:	movaps %xmm3,%xmm4
  81c599:	subss  %xmm0,%xmm4
  81c59d:	cvttss2si %xmm4,%rsi
  81c5a2:	cvttss2si %xmm3,%r9
  81c5a7:	mov    %r9,%rcx
  81c5aa:	sar    $0x3f,%rcx
  81c5ae:	and    %rsi,%rcx
  81c5b1:	or     %r9,%rcx
  81c5b4:	xor    %r10d,%r10d
  81c5b7:	ucomiss %xmm1,%xmm3
  81c5ba:	cmovb  %r10,%rcx
  81c5be:	ucomiss %xmm2,%xmm3
  81c5c1:	cmova  %rax,%rcx
  81c5c5:	movss  0x90(%rdi),%xmm3
  81c5cd:	mov    %rcx,%r14
  81c5d0:	shr    $0x4,%r14
  81c5d4:	movaps %xmm3,%xmm4
  81c5d7:	subss  %xmm0,%xmm4
  81c5db:	cvttss2si %xmm4,%rsi
  81c5e0:	cvttss2si %xmm3,%rdi
  81c5e5:	mov    %rdi,%r9
  81c5e8:	sar    $0x3f,%r9
  81c5ec:	and    %rsi,%r9
  81c5ef:	or     %rdi,%r9
  81c5f2:	ucomiss %xmm1,%xmm3
  81c5f5:	cmovb  %r10,%r9
  81c5f9:	ucomiss %xmm2,%xmm3
  81c5fc:	cmova  %rax,%r9
  81c600:	lea    (%r9,%rcx,1),%rbx
  81c604:	dec    %rbx
  81c607:	shr    $0x4,%rbx
  81c60b:	mov    %r14,0x10(%rsp)
  81c610:	cmp    %rbx,%r14
  81c613:	jbe    81c63d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c615:	data16 cs nopw 0x0(%rax,%rax,1)
  81c620:	mov    %r8,%rax
  81c623:	cmp    %r11,%r8
  81c626:	adc    $0x0,%r8
  81c62a:	cmp    %r11,%rax
  81c62d:	jae    81c57f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c633:	cmp    %r11,%r8
  81c636:	jbe    81c620 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c638:	jmp    81c57f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c63d:	mov    (%rdx),%r14
  81c640:	mov    0x8(%rdx),%r15
  81c644:	mov    0x10(%rdx),%r12
  81c648:	mov    0x18(%rdx),%r13
  81c64c:	mov    0x20(%rdx),%rdx
  81c650:	mov    %r11,0x8(%rsp)
  81c655:	data16 cs nopw 0x0(%rax,%rax,1)
  81c660:	mov    %r8,%rbp
  81c663:	cmp    %r11,%r8
  81c666:	adc    $0x0,%r8
  81c66a:	mov    %rbp,0x20(%rsp)
  81c66f:	imul   0x18(%rsp),%rbp
  81c675:	mov    0x10(%rsp),%r9
  81c67a:	mov    %r9,%rsi
  81c67d:	nopl   (%rax)
  81c680:	cmp    %rbx,%r9
  81c683:	adc    $0x0,%rsi
  81c687:	lea    (%r9,%rbp,1),%rdi
  81c68b:	mov    0x10(%r14),%rax
  81c68f:	cmp    %rax,%rdi
  81c692:	jae    81c700 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c694:	mov    0x8(%r14),%rcx
  81c698:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c69d:	jo     81c6d5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c69f:	mov    0x10(%r12),%rax
  81c6a4:	cmp    %rax,%rdi
  81c6a7:	jae    81c710 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c6a9:	mov    0x8(%r12),%rax
  81c6ae:	mov    0x0(%r13),%r11d
  81c6b2:	inc    %r11d
  81c6b5:	cmp    (%rax,%rdi,4),%r11d
  81c6b9:	jb     81c6d5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c6bb:	mov    (%rcx,%rdi,8),%eax
  81c6be:	dec    %eax
  81c6c0:	mov    %eax,(%rcx,%rdi,8)
  81c6c3:	mov    0x10(%r15),%rcx
  81c6c7:	cmp    %rax,%rcx
  81c6ca:	jbe    81c720 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c6cc:	mov    0x8(%r15),%rcx
  81c6d0:	mov    (%rdx),%edi
  81c6d2:	mov    %edi,(%rcx,%rax,4)
  81c6d5:	cmp    %rbx,%r9
  81c6d8:	jae    81c6e2 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c6da:	mov    %rsi,%r9
  81c6dd:	cmp    %rbx,%rsi
  81c6e0:	jbe    81c680 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c6e2:	mov    0x8(%rsp),%r11
  81c6e7:	cmp    %r11,0x20(%rsp)
  81c6ec:	jae    81c57f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c6f2:	cmp    %r11,%r8
  81c6f5:	jbe    81c660 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c6fb:	jmp    81c57f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c700:	lea    0x611f49(%rip),%rdx        # e2e650 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0xa8>
  81c707:	mov    %rax,%rsi
  81c70a:	call   *0x663920(%rip)        # e80030 <_DYNAMIC+0x4f8>
  81c710:	lea    0x611f51(%rip),%rdx        # e2e668 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0xc0>
  81c717:	mov    %rax,%rsi
  81c71a:	call   *0x663910(%rip)        # e80030 <_DYNAMIC+0x4f8>
  81c720:	lea    0x611f59(%rip),%rdx        # e2e680 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0xd8>
  81c727:	mov    %rax,%rdi
  81c72a:	mov    %rcx,%rsi
  81c72d:	call   *0x6638fd(%rip)        # e80030 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}> bytes=235 frame=248

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c740 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>:
  81c740:	push   %rbp
  81c741:	push   %r15
  81c743:	push   %r14
  81c745:	push   %r13
  81c747:	push   %r12
  81c749:	push   %rbx
  81c74a:	sub    $0xc8,%rsp
  81c751:	mov    %esi,%ebp
  81c753:	mov    %rdi,%rbx
  81c756:	lea    0x8(%rsp),%rdi
  81c75b:	mov    %rbx,%rsi
  81c75e:	call   *0x66398c(%rip)        # e800f0 <_DYNAMIC+0x5b8>
  81c764:	mov    0x8(%rsp),%rsi
  81c769:	xor    %r14d,%r14d
  81c76c:	test   $0x1,%bpl
  81c770:	je     81c7e8 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xa8>
  81c772:	test   %rsi,%rsi
  81c775:	je     81c816 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c77b:	mov    $0x1,%r13d
  81c781:	lea    0x8(%rsp),%r12
  81c786:	mov    0x663963(%rip),%rbp        # e800f0 <_DYNAMIC+0x5b8>
  81c78d:	jmp    81c7a5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x65>
  81c78f:	nop
  81c790:	add    %r15,%r14
  81c793:	mov    %r12,%rdi
  81c796:	mov    %rbx,%rsi
  81c799:	call   *%rbp
  81c79b:	mov    0x8(%rsp),%rsi
  81c7a0:	test   %rsi,%rsi
  81c7a3:	je     81c816 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c7a5:	mov    0x18(%rsp),%r15
  81c7aa:	cmp    $0x2,%r15
  81c7ae:	jb     81c790 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c7b0:	mov    0x10(%rsp),%rax
  81c7b5:	mov    (%rax),%edx
  81c7b7:	lea    0x70(%rsp),%rdi
  81c7bc:	call   81c830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c7c1:	movss  0x74(%rsp),%xmm0
  81c7c7:	xorps  %xmm1,%xmm1
  81c7ca:	ucomiss %xmm1,%xmm0
  81c7cd:	mov    $0x1,%eax
  81c7d2:	cmovne %r15,%rax
  81c7d6:	cmovp  %r15,%rax
  81c7da:	cmpb   $0x3,0x70(%rsp)
  81c7df:	cmovne %r13,%rax
  81c7e3:	mov    %rax,%r15
  81c7e6:	jmp    81c790 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0x50>
  81c7e8:	test   %rsi,%rsi
  81c7eb:	je     81c816 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xd6>
  81c7ed:	lea    0x8(%rsp),%r15
  81c7f2:	mov    0x6638f7(%rip),%r12        # e800f0 <_DYNAMIC+0x5b8>
  81c7f9:	nopl   0x0(%rax)
  81c800:	add    0x18(%rsp),%r14
  81c805:	mov    %r15,%rdi
  81c808:	mov    %rbx,%rsi
  81c80b:	call   *%r12
  81c80e:	cmpq   $0x0,0x8(%rsp)
  81c814:	jne    81c800 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>+0xc0>
  81c816:	mov    %r14,%rax
  81c819:	add    $0xc8,%rsp
  81c820:	pop    %rbx
  81c821:	pop    %r12
  81c823:	pop    %r13
  81c825:	pop    %r14
  81c827:	pop    %r15
  81c829:	pop    %rbp
  81c82a:	ret

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081ca70 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81ca70:	push   %rbp
  81ca71:	push   %r14
  81ca73:	push   %rbx
  81ca74:	cmp    0x341(%rdi),%sil
  81ca7b:	je     81cabb <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81ca7d:	mov    0x330(%rdi),%rax
  81ca84:	test   %rax,%rax
  81ca87:	je     81caa9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81ca89:	lock decq (%rax)
  81ca8d:	jne    81caa9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81ca8f:	lea    0x330(%rdi),%rbx
  81ca96:	mov    %rdi,%r14
  81ca99:	mov    %rbx,%rdi
  81ca9c:	mov    %esi,%ebp
  81ca9e:	call   *0x6635ac(%rip)        # e80050 <_DYNAMIC+0x518>
  81caa4:	mov    %r14,%rdi
  81caa7:	mov    %ebp,%esi
  81caa9:	movq   $0x0,0x330(%rdi)
  81cab4:	mov    %sil,0x341(%rdi)
  81cabb:	pop    %rbx
  81cabc:	pop    %r14
  81cabe:	pop    %rbp
  81cabf:	ret
  81cac0:	movq   $0x0,(%rbx)
  81cac7:	mov    %rax,%rdi
  81caca:	call   e2c890 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Changes>::upload bytes=83 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cad0 <<gpui_gpu::renderer::Changes>::upload>:
  81cad0:	push   %rbx
  81cad1:	mov    %rsi,%rbx
  81cad4:	sub    %rdi,%rbx
  81cad7:	jbe    81cb06 <<gpui_gpu::renderer::Changes>::upload+0x36>
  81cad9:	mov    %rdx,%rax
  81cadc:	mov    %rdi,%rdx
  81cadf:	cmp    %rcx,%rsi
  81cae2:	ja     81cb0d <<gpui_gpu::renderer::Changes>::upload+0x3d>
  81cae4:	shl    $0x4,%rdx
  81cae8:	add    %rdx,%rax
  81caeb:	shl    $0x4,%rbx
  81caef:	mov    %r9,%rdi
  81caf2:	mov    %r8,%rsi
  81caf5:	mov    %rax,%rcx
  81caf8:	mov    %rbx,%r8
  81cafb:	call   *0x663607(%rip)        # e80108 <_DYNAMIC+0x5d0>
  81cb01:	mov    %rbx,%rax
  81cb04:	pop    %rbx
  81cb05:	ret
  81cb06:	xor    %ebx,%ebx
  81cb08:	mov    %rbx,%rax
  81cb0b:	pop    %rbx
  81cb0c:	ret
  81cb0d:	lea    0x611be4(%rip),%rax        # e2e6f8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x150>
  81cb14:	mov    %rdx,%rdi
  81cb17:	mov    %rcx,%rdx
  81cb1a:	mov    %rax,%rcx
  81cb1d:	call   *0x66355d(%rip)        # e80080 <_DYNAMIC+0x548>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=76 frame=40

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb30 <<gpui_gpu::renderer::Buffer>::write>:
  81cb30:	push   %r15
  81cb32:	push   %r14
  81cb34:	push   %r12
  81cb36:	push   %rbx
  81cb37:	push   %rax
  81cb38:	mov    %r8,%r12
  81cb3b:	mov    %rcx,%rbx
  81cb3e:	mov    %rdx,%r14
  81cb41:	mov    %rdi,%r15
  81cb44:	mov    %r8,%rdx
  81cb47:	call   81cb80 <<gpui_gpu::renderer::Buffer>::reserve>
  81cb4c:	test   %r12,%r12
  81cb4f:	je     81cb70 <<gpui_gpu::renderer::Buffer>::write+0x40>
  81cb51:	mov    %r14,%rdi
  81cb54:	mov    %r15,%rsi
  81cb57:	xor    %edx,%edx
  81cb59:	mov    %rbx,%rcx
  81cb5c:	mov    %r12,%r8
  81cb5f:	add    $0x8,%rsp
  81cb63:	pop    %rbx
  81cb64:	pop    %r12
  81cb66:	pop    %r14
  81cb68:	pop    %r15
  81cb6a:	jmp    *0x663598(%rip)        # e80108 <_DYNAMIC+0x5d0>
  81cb70:	add    $0x8,%rsp
  81cb74:	pop    %rbx
  81cb75:	pop    %r12
  81cb77:	pop    %r14
  81cb79:	pop    %r15
  81cb7b:	ret

FUNCTION <gpui_gpu::renderer::Buffer>::reserve bytes=271 frame=104

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cb80 <<gpui_gpu::renderer::Buffer>::reserve>:
  81cb80:	push   %r15
  81cb82:	push   %r14
  81cb84:	push   %r12
  81cb86:	push   %rbx
  81cb87:	sub    $0x48,%rsp
  81cb8b:	mov    %rdx,%r14
  81cb8e:	mov    0x20(%rdi),%r15
  81cb92:	cmp    %r15,%rdx
  81cb95:	jbe    81cc3a <<gpui_gpu::renderer::Buffer>::reserve+0xba>
  81cb9b:	mov    %rdi,%rbx
  81cb9e:	mov    $0x1,%r12d
  81cba4:	cmp    $0x2,%r14
  81cba8:	jb     81cbc1 <<gpui_gpu::renderer::Buffer>::reserve+0x41>
  81cbaa:	lea    -0x1(%r14),%rax
  81cbae:	bsr    %rax,%rcx
  81cbb2:	not    %ecx
  81cbb4:	mov    $0xffffffffffffffff,%r12
  81cbbb:	shr    %cl,%r12
  81cbbe:	inc    %r12
  81cbc1:	lea    -0x748010(%rip),%rax        # d4bb8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x142>
  81cbc8:	mov    %rax,0x28(%rsp)
  81cbcd:	movq   $0xa,0x30(%rsp)
  81cbd6:	mov    %r12,0x38(%rsp)
  81cbdb:	movl   $0x88,0x40(%rsp)
  81cbe3:	movb   $0x0,0x44(%rsp)
  81cbe8:	mov    %rsp,%rdi
  81cbeb:	lea    0x28(%rsp),%rdx
  81cbf0:	call   *0x663562(%rip)        # e80158 <_DYNAMIC+0x620>
  81cbf6:	mov    %r12,0x20(%rsp)
  81cbfb:	mov    (%rbx),%rax
  81cbfe:	lock decq (%rax)
  81cc02:	jne    81cc0d <<gpui_gpu::renderer::Buffer>::reserve+0x8d>
  81cc04:	mov    %rbx,%rdi
  81cc07:	call   *0x663433(%rip)        # e80040 <_DYNAMIC+0x508>
  81cc0d:	mov    0x8(%rbx),%rax
  81cc11:	lock decq (%rax)
  81cc15:	jne    81cc21 <<gpui_gpu::renderer::Buffer>::reserve+0xa1>
  81cc17:	lea    0x8(%rbx),%rdi
  81cc1b:	call   *0x663427(%rip)        # e80048 <_DYNAMIC+0x510>
  81cc21:	mov    0x20(%rsp),%rax
  81cc26:	mov    %rax,0x20(%rbx)
  81cc2a:	movups (%rsp),%xmm0
  81cc2e:	movups 0x10(%rsp),%xmm1
  81cc33:	movups %xmm1,0x10(%rbx)
  81cc37:	movups %xmm0,(%rbx)
  81cc3a:	cmp    %r15,%r14
  81cc3d:	seta   %al
  81cc40:	add    $0x48,%rsp
  81cc44:	pop    %rbx
  81cc45:	pop    %r12
  81cc47:	pop    %r14
  81cc49:	pop    %r15
  81cc4b:	ret
  81cc4c:	mov    %rax,%r14
  81cc4f:	jmp    81cc68 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81cc51:	mov    %rax,%r14
  81cc54:	mov    0x8(%rbx),%rax
  81cc58:	lock decq (%rax)
  81cc5c:	jne    81cc68 <<gpui_gpu::renderer::Buffer>::reserve+0xe8>
  81cc5e:	lea    0x8(%rbx),%rdi
  81cc62:	call   *0x6633e0(%rip)        # e80048 <_DYNAMIC+0x510>
  81cc68:	mov    0x20(%rsp),%rax
  81cc6d:	mov    %rax,0x20(%rbx)
  81cc71:	movups (%rsp),%xmm0
  81cc75:	movups 0x10(%rsp),%xmm1
  81cc7a:	movups %xmm1,0x10(%rbx)
  81cc7e:	movups %xmm0,(%rbx)
  81cc81:	mov    %r14,%rdi
  81cc84:	call   e2c890 <_Unwind_Resume@plt>
  81cc89:	call   *0x6630f9(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc90 <<gpui_gpu::renderer::Atlas>::new>:
  81cc90:	push   %rbp
  81cc91:	push   %r14
  81cc93:	push   %rbx
  81cc94:	sub    $0x160,%rsp
  81cc9b:	mov    %edx,%ebp
  81cc9d:	mov    %rdi,%rbx
  81cca0:	lea    -0x7480e5(%rip),%rax        # d4bc2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x14c>
  81cca7:	mov    %rax,(%rsp)
  81ccab:	movq   $0xe,0x8(%rsp)
  81ccb4:	mov    %edx,0x10(%rsp)
  81ccb8:	mov    %edx,0x14(%rsp)
  81ccbc:	movaps -0x770753(%rip),%xmm0        # ac570 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81ccc3:	movups %xmm0,0x18(%rsp)
  81ccc8:	movl   $0x0,0x28(%rsp)
  81ccd0:	movl   $0x6,0x34(%rsp)
  81ccd8:	movq   $0x4,0x38(%rsp)
  81cce1:	movq   $0x0,0x40(%rsp)
  81ccea:	lea    0x110(%rsp),%r14
  81ccf2:	mov    %rsp,%rdx
  81ccf5:	mov    %r14,%rdi
  81ccf8:	call   *0x6632da(%rip)        # e7ffd8 <_DYNAMIC+0x4a0>
  81ccfe:	movq   $0x0,0x18(%rsp)
  81cd07:	movl   $0xffffffff,0x30(%rsp)
  81cd0f:	movl   $0x0,(%rsp)
  81cd16:	movabs $0xffffffff00000000,%rax
  81cd20:	mov    %rax,0x28(%rsp)
  81cd25:	movq   $0x0,0x3c(%rsp)
  81cd2e:	movl   $0x0,0x8(%rsp)
  81cd36:	movl   $0x0,0x10(%rsp)
  81cd3e:	lea    0xb8(%rsp),%rdi
  81cd46:	mov    %rsp,%rdx
  81cd49:	mov    %r14,%rsi
  81cd4c:	call   *0x66328e(%rip)        # e7ffe0 <_DYNAMIC+0x4a8>
  81cd52:	movups 0x150(%rsp),%xmm0
  81cd5a:	movaps %xmm0,0xa0(%rsp)
  81cd62:	movups 0x110(%rsp),%xmm0
  81cd6a:	movups 0x120(%rsp),%xmm1
  81cd72:	movups 0x130(%rsp),%xmm2
  81cd7a:	movups 0x140(%rsp),%xmm3
  81cd82:	movaps %xmm3,0x90(%rsp)
  81cd8a:	movaps %xmm2,0x80(%rsp)
  81cd92:	movaps %xmm1,0x70(%rsp)
  81cd97:	movaps %xmm0,0x60(%rsp)
  81cd9c:	mov    0x108(%rsp),%rax
  81cda4:	mov    %rax,0x50(%rsp)
  81cda9:	movups 0xf8(%rsp),%xmm0
  81cdb1:	movaps %xmm0,0x40(%rsp)
  81cdb6:	movups 0xb8(%rsp),%xmm0
  81cdbe:	movups 0xc8(%rsp),%xmm1
  81cdc6:	movups 0xd8(%rsp),%xmm2
  81cdce:	movups 0xe8(%rsp),%xmm3
  81cdd6:	movaps %xmm3,0x30(%rsp)
  81cddb:	movaps %xmm2,0x20(%rsp)
  81cde0:	movaps %xmm1,0x10(%rsp)
  81cde5:	movaps %xmm0,(%rsp)
  81cde9:	mov    %fs:0x0,%rax
  81cdf2:	lea    -0x28(%rax),%rax
  81cdf9:	mov    %rax,%r14
  81cdfc:	cmpb   $0x1,0x10(%rax)
  81ce00:	jne    81ceeb <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81ce06:	mov    (%r14),%rax
  81ce09:	mov    0x8(%r14),%rdx
  81ce0d:	lea    0x1(%rax),%rcx
  81ce11:	mov    %rcx,(%r14)
  81ce14:	movaps 0xa0(%rsp),%xmm0
  81ce1c:	movups %xmm0,0x40(%rbx)
  81ce20:	movaps 0x60(%rsp),%xmm0
  81ce25:	movaps 0x70(%rsp),%xmm1
  81ce2a:	movaps 0x80(%rsp),%xmm2
  81ce32:	movaps 0x90(%rsp),%xmm3
  81ce3a:	movups %xmm3,0x30(%rbx)
  81ce3e:	movups %xmm2,0x20(%rbx)
  81ce42:	movups %xmm1,0x10(%rbx)
  81ce46:	movups %xmm0,(%rbx)
  81ce49:	movups 0xb8(%rsp),%xmm0
  81ce51:	movups 0xc8(%rsp),%xmm1
  81ce59:	movups 0xd8(%rsp),%xmm2
  81ce61:	movups 0xe8(%rsp),%xmm3
  81ce69:	movups %xmm0,0x50(%rbx)
  81ce6d:	movups %xmm1,0x60(%rbx)
  81ce71:	movups %xmm2,0x70(%rbx)
  81ce75:	movups %xmm3,0x80(%rbx)
  81ce7c:	movups 0xf8(%rsp),%xmm0
  81ce84:	movups %xmm0,0x90(%rbx)
  81ce8b:	mov    0x108(%rsp),%rcx
  81ce93:	mov    %rcx,0xa0(%rbx)
  81ce9a:	mov    %ebp,0xd8(%rbx)
  81cea0:	movq   $0x0,0xdc(%rbx)
  81ceab:	movl   $0x0,0xe4(%rbx)
  81ceb5:	movups 0x6118e4(%rip),%xmm0        # e2e7a0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x1f8>
  81cebc:	movups %xmm0,0xa8(%rbx)
  81cec3:	movups 0x6118e6(%rip),%xmm0        # e2e7b0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x208>
  81ceca:	movups %xmm0,0xb8(%rbx)
  81ced1:	mov    %rax,0xc8(%rbx)
  81ced8:	mov    %rdx,0xd0(%rbx)
  81cedf:	add    $0x160,%rsp
  81cee6:	pop    %rbx
  81cee7:	pop    %r14
  81cee9:	pop    %rbp
  81ceea:	ret
  81ceeb:	call   *0x66326f(%rip)        # e80160 <_DYNAMIC+0x628>
  81cef1:	mov    %rax,(%r14)
  81cef4:	mov    %rdx,0x8(%r14)
  81cef8:	movb   $0x1,0x10(%r14)
  81cefd:	jmp    81ce0d <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cf02:	mov    %rax,%rbx
  81cf05:	mov    %rsp,%rdi
  81cf08:	call   81c3a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cf0d:	mov    0x60(%rsp),%rax
  81cf12:	lock decq (%rax)
  81cf16:	jne    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf18:	lea    0x60(%rsp),%rdi
  81cf1d:	call   *0x6630fd(%rip)        # e80020 <_DYNAMIC+0x4e8>
  81cf23:	jmp    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf25:	mov    %rax,%rbx
  81cf28:	mov    0x110(%rsp),%rax
  81cf30:	lock decq (%rax)
  81cf34:	jne    81cf44 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cf36:	lea    0x110(%rsp),%rdi
  81cf3e:	call   *0x6630dc(%rip)        # e80020 <_DYNAMIC+0x4e8>
  81cf44:	mov    %rbx,%rdi
  81cf47:	call   e2c890 <_Unwind_Resume@plt>
  81cf4c:	call   *0x662e36(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cf60 <<gpui_gpu::renderer::Atlas>::insert>:
  81cf60:	push   %rbp
  81cf61:	push   %r15
  81cf63:	push   %r14
  81cf65:	push   %r13
  81cf67:	push   %r12
  81cf69:	push   %rbx
  81cf6a:	sub    $0x68,%rsp
  81cf6e:	mov    %rdx,%r12
  81cf71:	mov    %rsi,%r15
  81cf74:	mov    %rdi,%r14
  81cf77:	lea    0x10(%rdx),%r13
  81cf7b:	cmpq   $0x0,0xc0(%rdi)
  81cf83:	je     81d04b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81cf89:	lea    0xc8(%r14),%rdi
  81cf90:	mov    %r13,%rsi
  81cf93:	call   824bc0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81cf98:	mov    %rax,%rsi
  81cf9b:	shr    $0x39,%rsi
  81cf9f:	mov    0xa8(%r14),%rcx
  81cfa6:	mov    0xb0(%r14),%rdx
  81cfad:	movd   %esi,%xmm0
  81cfb1:	punpcklbw %xmm0,%xmm0
  81cfb5:	pshuflw $0x0,%xmm0,%xmm0
  81cfba:	pshufd $0x44,%xmm0,%xmm0
  81cfbf:	mov    0x10(%r12),%rsi
  81cfc4:	movzwl 0x1c(%r12),%edi
  81cfca:	mov    0x18(%r12),%r8d
  81cfcf:	pcmpeqd %xmm1,%xmm1
  81cfd3:	xor    %r9d,%r9d
  81cfd6:	and    %rdx,%rax
  81cfd9:	movdqu (%rcx,%rax,1),%xmm2
  81cfde:	movdqa %xmm2,%xmm3
  81cfe2:	pcmpeqb %xmm0,%xmm3
  81cfe6:	pmovmskb %xmm3,%r10d
  81cfeb:	test   %r10d,%r10d
  81cfee:	je     81d030 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81cff0:	tzcnt  %r10d,%ebx
  81cff5:	add    %rax,%rbx
  81cff8:	and    %rdx,%rbx
  81cffb:	shl    $0x5,%rbx
  81cfff:	mov    %rcx,%r11
  81d002:	sub    %rbx,%r11
  81d005:	cmp    -0x20(%r11),%rsi
  81d009:	jne    81d01c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d00b:	cmp    -0x14(%r11),%di
  81d010:	jne    81d01c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d012:	cmp    -0x18(%r11),%r8d
  81d016:	je     81d0b3 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d01c:	lea    -0x1(%r10),%r11d
  81d020:	and    %r10w,%r11w
  81d024:	mov    %r11d,%r10d
  81d027:	jne    81cff0 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d029:	nopl   0x0(%rax)
  81d030:	pcmpeqb %xmm1,%xmm2
  81d034:	pmovmskb %xmm2,%r10d
  81d039:	test   %r10d,%r10d
  81d03c:	jne    81d04b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d03e:	add    %r9,%rax
  81d041:	add    $0x10,%rax
  81d045:	add    $0x10,%r9
  81d049:	jmp    81cfd6 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d04b:	mov    0x20(%r12),%ebp
  81d050:	xor    %eax,%eax
  81d052:	test   %ebp,%ebp
  81d054:	je     81d0ae <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d056:	mov    %r15,%rdi
  81d059:	mov    0x28(%r12),%r15d
  81d05e:	test   %r15d,%r15d
  81d061:	je     81d0ae <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d063:	mov    0xd8(%r14),%ecx
  81d06a:	cmp    %ebp,%ecx
  81d06c:	jb     81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d072:	cmp    %r15d,%ecx
  81d075:	jb     81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d07b:	mov    %r13,0x40(%rsp)
  81d080:	mov    0xdc(%r14),%r8d
  81d087:	mov    0xe4(%r14),%r13d
  81d08e:	lea    (%r8,%rbp,1),%edx
  81d092:	xor    %eax,%eax
  81d094:	cmp    %ecx,%edx
  81d096:	mov    $0x0,%ebx
  81d09b:	cmova  %r13d,%ebx
  81d09f:	add    0xe0(%r14),%ebx
  81d0a6:	lea    (%rbx,%r15,1),%esi
  81d0aa:	cmp    %ecx,%esi
  81d0ac:	jbe    81d0bf <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d0ae:	jmp    81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d0b3:	mov    $0x1,%eax
  81d0b8:	xor    %edx,%edx
  81d0ba:	jmp    81d1b1 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d0bf:	cmp    %r13d,%r15d
  81d0c2:	cmova  %r15d,%r13d
  81d0c6:	cmp    %ecx,%edx
  81d0c8:	cmova  %eax,%r8d
  81d0cc:	lea    0xa8(%r14),%rax
  81d0d3:	mov    %rax,0x38(%rsp)
  81d0d8:	mov    %r14,0x48(%rsp)
  81d0dd:	movl   $0x0,0x50(%rsp)
  81d0e5:	mov    %r8d,0x54(%rsp)
  81d0ea:	mov    %ebx,0x58(%rsp)
  81d0ee:	movq   $0x0,0x5c(%rsp)
  81d0f7:	mov    (%r12),%rdx
  81d0fb:	mov    0x8(%r12),%rcx
  81d100:	mov    %rcx,0x30(%rsp)
  81d105:	movq   $0x0,0x8(%rsp)
  81d10e:	movl   $0x1,0x10(%rsp)
  81d116:	mov    %ebp,0x14(%rsp)
  81d11a:	movl   $0x1,0x18(%rsp)
  81d122:	mov    %r15d,0x1c(%rsp)
  81d127:	mov    %ebp,0x20(%rsp)
  81d12b:	mov    %r15d,0x24(%rsp)
  81d130:	movl   $0x1,0x28(%rsp)
  81d138:	cmova  %r15d,%r13d
  81d13c:	lea    0x48(%rsp),%rsi
  81d141:	mov    %r8,%r12
  81d144:	lea    0x8(%rsp),%r8
  81d149:	lea    0x20(%rsp),%r9
  81d14e:	call   *0x663014(%rip)        # e80168 <_DYNAMIC+0x630>
  81d154:	lea    (%r12,%rbp,1),%eax
  81d158:	mov    %eax,0xdc(%r14)
  81d15f:	mov    %ebx,0xe0(%r14)
  81d166:	mov    %r13d,0xe4(%r14)
  81d16d:	mov    0x40(%rsp),%rax
  81d172:	movdqu (%rax),%xmm0
  81d176:	movdqa %xmm0,0x20(%rsp)
  81d17c:	mov    %r12d,0x8(%rsp)
  81d181:	mov    %ebx,0xc(%rsp)
  81d185:	mov    %ebp,0x10(%rsp)
  81d189:	mov    %r15d,0x14(%rsp)
  81d18e:	lea    0x48(%rsp),%rdi
  81d193:	lea    0x20(%rsp),%rdx
  81d198:	lea    0x8(%rsp),%rcx
  81d19d:	mov    0x38(%rsp),%rsi
  81d1a2:	call   8254f0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d1a7:	mov    0x30(%rsp),%rdx
  81d1ac:	mov    $0x1,%eax
  81d1b1:	add    $0x68,%rsp
  81d1b5:	pop    %rbx
  81d1b6:	pop    %r12
  81d1b8:	pop    %r13
  81d1ba:	pop    %r14
  81d1bc:	pop    %r15
  81d1be:	pop    %rbp
  81d1bf:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d1c0 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d1c0:	push   %r15
  81d1c2:	push   %r14
  81d1c4:	push   %r12
  81d1c6:	push   %rbx
  81d1c7:	sub    $0x548,%rsp
  81d1ce:	mov    %rdx,%r14
  81d1d1:	mov    %rsi,%r12
  81d1d4:	mov    %rdi,%rbx
  81d1d7:	lea    0x6115e2(%rip),%rdx        # e2e7c0 <anon.36d49f465d299f05a84fba3771e6457e.33.llvm.4447969268566763096>
  81d1de:	lea    0x30(%rsp),%r15
  81d1e3:	mov    %r15,%rdi
  81d1e6:	mov    %rbx,%rsi
  81d1e9:	call   *0x662f81(%rip)        # e80170 <_DYNAMIC+0x638>
  81d1ef:	xorps  %xmm0,%xmm0
  81d1f2:	movups %xmm0,0x10(%rsp)
  81d1f7:	movups %xmm0,0x20(%rsp)
  81d1fc:	movl   $0x0,0x50(%rsp)
  81d204:	movb   $0x0,0x58(%rsp)
  81d209:	movups 0x9(%rsp),%xmm0
  81d20e:	movups %xmm0,0x59(%rsp)
  81d213:	movups 0x19(%rsp),%xmm0
  81d218:	movups %xmm0,0x69(%rsp)
  81d21d:	mov    0x28(%rsp),%rax
  81d222:	mov    %rax,0x78(%rsp)
  81d227:	movl   $0x0,0x80(%rsp)
  81d232:	mov    %r12,0x88(%rsp)
  81d23a:	movq   $0x0,0x90(%rsp)
  81d246:	lea    -0x74867d(%rip),%rax        # d4bd0 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.4447969268566763096>
  81d24d:	mov    %rax,0xe0(%rsp)
  81d255:	movq   $0xa,0xe8(%rsp)
  81d261:	lea    0x50(%rsp),%rax
  81d266:	mov    %rax,0xd0(%rsp)
  81d26e:	movq   $0x1,0xd8(%rsp)
  81d27a:	movl   $0xffffffff,0xb8(%rsp)
  81d285:	movl   $0x2,0x98(%rsp)
  81d290:	movq   $0x0,0xf0(%rsp)
  81d29c:	movl   $0x0,0xf8(%rsp)
  81d2a7:	lea    0x100(%rsp),%rdi
  81d2af:	lea    0x98(%rsp),%rdx
  81d2b7:	mov    %r15,%rsi
  81d2ba:	call   *0x662eb8(%rip)        # e80178 <_DYNAMIC+0x640>
  81d2c0:	lea    0x10(%rbx),%rsi
  81d2c4:	lea    0x100(%rsp),%rdi
  81d2cc:	call   *0x662eae(%rip)        # e80180 <_DYNAMIC+0x648>
  81d2d2:	lea    0x100(%rsp),%rdi
  81d2da:	mov    $0x4,%ecx
  81d2df:	xor    %esi,%esi
  81d2e1:	mov    %r14,%rdx
  81d2e4:	xor    %r8d,%r8d
  81d2e7:	call   *0x662e9b(%rip)        # e80188 <_DYNAMIC+0x650>
  81d2ed:	lea    0x100(%rsp),%rdi
  81d2f5:	xor    %esi,%esi
  81d2f7:	mov    $0x3,%edx
  81d2fc:	xor    %ecx,%ecx
  81d2fe:	mov    $0x1,%r8d
  81d304:	call   *0x662e86(%rip)        # e80190 <_DYNAMIC+0x658>
  81d30a:	lea    0x100(%rsp),%rdi
  81d312:	call   81c2a0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d317:	movups 0x30(%rsp),%xmm0
  81d31c:	movups 0x40(%rsp),%xmm1
  81d321:	movaps %xmm1,0x110(%rsp)
  81d329:	movaps %xmm0,0x100(%rsp)
  81d331:	lea    0x98(%rsp),%r14
  81d339:	lea    0x100(%rsp),%rsi
  81d341:	mov    %r14,%rdi
  81d344:	call   *0x662e4e(%rip)        # e80198 <_DYNAMIC+0x660>
  81d34a:	add    $0x8,%rbx
  81d34e:	mov    %rbx,%rdi
  81d351:	mov    %r14,%rsi
  81d354:	call   8250a0 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d359:	add    $0x548,%rsp
  81d360:	pop    %rbx
  81d361:	pop    %r12
  81d363:	pop    %r14
  81d365:	pop    %r15
  81d367:	ret
  81d368:	mov    %rax,%rbx
  81d36b:	jmp    81d37d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d36d:	mov    %rax,%rbx
  81d370:	lea    0x100(%rsp),%rdi
  81d378:	call   81c2a0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d37d:	lea    0x30(%rsp),%rdi
  81d382:	call   81c410 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d387:	mov    %rbx,%rdi
  81d38a:	call   e2c890 <_Unwind_Resume@plt>
  81d38f:	call   *0x6629f3(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d3a0 <<gpui_gpu::renderer::RendererState>::correction>:
  81d3a0:	push   %r15
  81d3a2:	push   %r14
  81d3a4:	push   %r13
  81d3a6:	push   %r12
  81d3a8:	push   %rbx
  81d3a9:	sub    $0x90,%rsp
  81d3b0:	mov    %rdi,%rbx
  81d3b3:	movss  (%rdx),%xmm1
  81d3b7:	movss  0x8(%rdx),%xmm2
  81d3bc:	movaps %xmm1,%xmm0
  81d3bf:	addss  %xmm2,%xmm0
  81d3c3:	movd   %xmm0,%eax
  81d3c7:	and    $0x7fffffff,%eax
  81d3cc:	xorps  %xmm8,%xmm8
  81d3d0:	xorps  %xmm9,%xmm9
  81d3d4:	cmp    $0x7f7fffff,%eax
  81d3d9:	jg     81d3f8 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d3db:	cvtss2sd %xmm1,%xmm1
  81d3df:	cvtss2sd %xmm2,%xmm2
  81d3e3:	cvtss2sd %xmm0,%xmm0
  81d3e7:	addsd  %xmm1,%xmm2
  81d3eb:	subsd  %xmm0,%xmm2
  81d3ef:	xorps  %xmm9,%xmm9
  81d3f3:	cvtsd2ss %xmm2,%xmm9
  81d3f8:	movupd (%rsi),%xmm0
  81d3fc:	movupd 0x8(%rsi),%xmm1
  81d401:	movsd  0x10(%rsi),%xmm2
  81d406:	movsd  0x18(%rsi),%xmm3
  81d40b:	movupd 0x20(%rsi),%xmm4
  81d410:	movss  0x4(%rdx),%xmm6
  81d415:	movss  0xc(%rdx),%xmm7
  81d41a:	movaps %xmm6,%xmm5
  81d41d:	addss  %xmm7,%xmm5
  81d421:	movd   %xmm5,%eax
  81d425:	and    $0x7fffffff,%eax
  81d42a:	cmp    $0x7f7fffff,%eax
  81d42f:	jg     81d44e <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d431:	cvtss2sd %xmm6,%xmm6
  81d435:	cvtss2sd %xmm7,%xmm7
  81d439:	cvtss2sd %xmm5,%xmm5
  81d43d:	addsd  %xmm6,%xmm7
  81d441:	subsd  %xmm5,%xmm7
  81d445:	xorps  %xmm8,%xmm8
  81d449:	cvtsd2ss %xmm7,%xmm8
  81d44e:	cvtpd2ps %xmm4,%xmm5
  81d452:	cvtps2pd %xmm5,%xmm5
  81d455:	subpd  %xmm5,%xmm4
  81d459:	cvtpd2ps %xmm4,%xmm4
  81d45d:	unpcklpd %xmm3,%xmm1
  81d461:	cvtpd2ps %xmm1,%xmm3
  81d465:	unpcklpd %xmm2,%xmm0
  81d469:	cvtpd2ps %xmm0,%xmm2
  81d46d:	cvtps2pd %xmm3,%xmm3
  81d470:	subpd  %xmm3,%xmm1
  81d474:	cvtpd2ps %xmm1,%xmm5
  81d478:	cvtps2pd %xmm2,%xmm1
  81d47b:	subpd  %xmm1,%xmm0
  81d47f:	cvtpd2ps %xmm0,%xmm6
  81d483:	movapd %xmm6,%xmm0
  81d487:	unpcklps %xmm5,%xmm0
  81d48a:	movaps %xmm8,%xmm1
  81d48e:	movlhps %xmm9,%xmm1
  81d492:	movapd %xmm4,%xmm2
  81d496:	shufps $0x24,%xmm1,%xmm2
  81d49a:	xorps  %xmm1,%xmm1
  81d49d:	movapd %xmm0,%xmm3
  81d4a1:	cmpneqps %xmm1,%xmm3
  81d4a5:	cmpneqps %xmm1,%xmm2
  81d4a9:	packssdw %xmm2,%xmm3
  81d4ad:	pmovmskb %xmm3,%eax
  81d4b1:	test   %eax,%eax
  81d4b3:	je     81d5d7 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d4b9:	movapd %xmm6,0x60(%rsp)
  81d4bf:	movapd %xmm5,0x70(%rsp)
  81d4c5:	lea    0x8(%rsp),%r12
  81d4ca:	movapd %xmm0,(%rsp)
  81d4cf:	movapd %xmm4,0x80(%rsp)
  81d4d8:	movlpd %xmm4,0x10(%rsp)
  81d4de:	movss  %xmm9,0x18(%rsp)
  81d4e5:	movss  %xmm8,0x1c(%rsp)
  81d4ec:	lea    0x318(%rbx),%r14
  81d4f3:	mov    %rsp,%rsi
  81d4f6:	mov    %r14,%rdi
  81d4f9:	movaps %xmm8,0x30(%rsp)
  81d4ff:	movaps %xmm9,0x20(%rsp)
  81d505:	call   824a40 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d50a:	movapd 0x20(%rsp),%xmm6
  81d510:	movapd 0x30(%rsp),%xmm5
  81d516:	mov    %rax,%r15
  81d519:	shr    $0x39,%r15
  81d51d:	mov    0x2f8(%rbx),%rcx
  81d524:	mov    0x300(%rbx),%rdx
  81d52b:	movd   %r15d,%xmm0
  81d530:	punpcklbw %xmm0,%xmm0
  81d534:	pshuflw $0x0,%xmm0,%xmm0
  81d539:	pshufd $0x44,%xmm0,%xmm0
  81d53e:	xor    %esi,%esi
  81d540:	pcmpeqd %xmm1,%xmm1
  81d544:	mov    %rax,%rdi
  81d547:	and    %rdx,%rdi
  81d54a:	movdqu (%rcx,%rdi,1),%xmm2
  81d54f:	movdqa %xmm2,%xmm3
  81d553:	pcmpeqb %xmm0,%xmm3
  81d557:	pmovmskb %xmm3,%r8d
  81d55c:	test   %r8d,%r8d
  81d55f:	je     81d5b0 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d561:	tzcnt  %r8d,%r9d
  81d566:	add    %rdi,%r9
  81d569:	and    %rdx,%r9
  81d56c:	neg    %r9
  81d56f:	lea    (%r9,%r9,8),%r9
  81d573:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d57a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d581:	pcmpeqb 0x10(%rsp),%xmm4
  81d587:	pcmpeqb (%rsp),%xmm3
  81d58c:	pand   %xmm4,%xmm3
  81d590:	pmovmskb %xmm3,%r10d
  81d595:	cmp    $0xffff,%r10d
  81d59c:	je     81d5ce <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d59e:	lea    -0x1(%r8),%r9d
  81d5a2:	and    %r8w,%r9w
  81d5a6:	mov    %r9d,%r8d
  81d5a9:	jne    81d561 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d5ab:	nopl   0x0(%rax,%rax,1)
  81d5b0:	pcmpeqb %xmm1,%xmm2
  81d5b4:	pmovmskb %xmm2,%r8d
  81d5b9:	test   %r8d,%r8d
  81d5bc:	jne    81d5de <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d5be:	add    %rsi,%rdi
  81d5c1:	add    $0x10,%rdi
  81d5c5:	add    $0x10,%rsi
  81d5c9:	jmp    81d547 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d5ce:	lea    (%rcx,%r9,4),%rdx
  81d5d2:	jmp    81d6f9 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d5d7:	xor    %eax,%eax
  81d5d9:	jmp    81d6fc <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d5de:	cmpq   $0x0,0x308(%rbx)
  81d5e6:	je     81d72f <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d5ec:	mov    (%rsp),%r14
  81d5f0:	mov    0x10(%r12),%rcx
  81d5f5:	mov    %rcx,0x50(%rsp)
  81d5fa:	movups (%r12),%xmm0
  81d5ff:	movaps %xmm0,0x40(%rsp)
  81d604:	mov    0x70(%rbx),%r12
  81d608:	cmp    0x60(%rbx),%r12
  81d60c:	jne    81d62a <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d60e:	lea    0x60(%rbx),%rdi
  81d612:	mov    %rax,%r13
  81d615:	call   *0x662acd(%rip)        # e800e8 <_DYNAMIC+0x5b0>
  81d61b:	movapd 0x20(%rsp),%xmm6
  81d621:	movapd 0x30(%rsp),%xmm5
  81d627:	mov    %r13,%rax
  81d62a:	mov    0x68(%rbx),%rcx
  81d62e:	mov    %r12,%rdx
  81d631:	shl    $0x5,%rdx
  81d635:	movaps 0x60(%rsp),%xmm0
  81d63a:	movlps %xmm0,(%rcx,%rdx,1)
  81d63e:	movaps 0x80(%rsp),%xmm0
  81d646:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d64c:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d652:	movdqa 0x70(%rsp),%xmm1
  81d658:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d65e:	shufps $0x55,%xmm0,%xmm0
  81d662:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d668:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d66e:	lea    0x1(%r12),%rcx
  81d673:	mov    %rcx,0x70(%rbx)
  81d677:	mov    0x2f8(%rbx),%rcx
  81d67e:	mov    0x300(%rbx),%rdx
  81d685:	and    %rdx,%rax
  81d688:	movdqu (%rcx,%rax,1),%xmm0
  81d68d:	pmovmskb %xmm0,%esi
  81d691:	test   %esi,%esi
  81d693:	je     81d70d <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d695:	tzcnt  %esi,%esi
  81d699:	add    %rax,%rsi
  81d69c:	and    %rdx,%rsi
  81d69f:	movzbl (%rcx,%rsi,1),%eax
  81d6a3:	test   %al,%al
  81d6a5:	jns    81d760 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d6ab:	lea    -0x10(%rsi),%rdi
  81d6af:	and    %rdx,%rdi
  81d6b2:	mov    %r15b,(%rcx,%rsi,1)
  81d6b6:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d6bb:	neg    %rsi
  81d6be:	lea    (%rsi,%rsi,8),%rsi
  81d6c2:	lea    (%rcx,%rsi,4),%rdx
  81d6c6:	and    $0x1,%al
  81d6c8:	movzbl %al,%eax
  81d6cb:	sub    %rax,0x308(%rbx)
  81d6d2:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d6d7:	movdqa 0x40(%rsp),%xmm0
  81d6dd:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d6e3:	mov    0x50(%rsp),%rax
  81d6e8:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d6ed:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d6f2:	incq   0x310(%rbx)
  81d6f9:	mov    -0x4(%rdx),%eax
  81d6fc:	add    $0x90,%rsp
  81d703:	pop    %rbx
  81d704:	pop    %r12
  81d706:	pop    %r13
  81d708:	pop    %r14
  81d70a:	pop    %r15
  81d70c:	ret
  81d70d:	mov    $0x10,%edi
  81d712:	add    %rdi,%rax
  81d715:	and    %rdx,%rax
  81d718:	movdqu (%rcx,%rax,1),%xmm0
  81d71d:	pmovmskb %xmm0,%esi
  81d721:	add    $0x10,%rdi
  81d725:	test   %esi,%esi
  81d727:	jne    81d695 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d72d:	jmp    81d712 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d72f:	lea    0x2f8(%rbx),%rdi
  81d736:	mov    $0x1,%esi
  81d73b:	mov    %r14,%rdx
  81d73e:	mov    $0x1,%ecx
  81d743:	mov    %rax,%r14
  81d746:	call   *0x662a54(%rip)        # e801a0 <_DYNAMIC+0x668>
  81d74c:	movapd 0x20(%rsp),%xmm6
  81d752:	movapd 0x30(%rsp),%xmm5
  81d758:	mov    %r14,%rax
  81d75b:	jmp    81d5ec <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d760:	movdqa (%rcx),%xmm0
  81d764:	pmovmskb %xmm0,%eax
  81d768:	tzcnt  %eax,%esi
  81d76c:	movzbl (%rcx,%rsi,1),%eax
  81d770:	jmp    81d6ab <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d780 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d780:	push   %rbp
  81d781:	push   %r15
  81d783:	push   %r14
  81d785:	push   %r13
  81d787:	push   %r12
  81d789:	push   %rbx
  81d78a:	sub    $0x228,%rsp
  81d791:	mov    %rsi,%r14
  81d794:	test   %r8d,%r8d
  81d797:	je     81d82b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d79d:	mov    %rdi,0x10(%rsp)
  81d7a2:	mov    0x110(%rcx),%rbp
  81d7a9:	test   %rbp,%rbp
  81d7ac:	je     81d88f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d7b2:	mov    0x108(%rcx),%r13
  81d7b9:	shl    $0x3,%rbp
  81d7bd:	mov    %r14,0x8(%rsp)
  81d7c2:	lea    0x78(%r14),%rdi
  81d7c6:	mov    %rdx,0x18(%rsp)
  81d7cb:	lea    0x8(%rdx),%rax
  81d7cf:	mov    %rax,0x20(%rsp)
  81d7d4:	xor    %ebx,%ebx
  81d7d6:	lea    0x28(%rsp),%r15
  81d7db:	xor    %r12d,%r12d
  81d7de:	xchg   %ax,%ax
  81d7e0:	mov    0x0(%r13,%r12,1),%rax
  81d7e5:	movups 0x28(%rax),%xmm0
  81d7e9:	lea    0x38(%rsp),%rcx
  81d7ee:	movups %xmm0,(%rcx)
  81d7f1:	movups 0x18(%rax),%xmm0
  81d7f5:	movups %xmm0,0x28(%rsp)
  81d7fa:	movups 0x38(%rax),%xmm0
  81d7fe:	movups %xmm0,0x48(%rsp)
  81d803:	mov    %rdi,%r14
  81d806:	mov    0x20(%rsp),%rsi
  81d80b:	mov    %r15,%rdx
  81d80e:	call   81cf60 <<gpui_gpu::renderer::Atlas>::insert>
  81d813:	test   $0x1,%al
  81d815:	je     81d896 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d817:	add    %rdx,%rbx
  81d81a:	add    $0x8,%r12
  81d81e:	cmp    %r12,%rbp
  81d821:	mov    %r14,%rdi
  81d824:	jne    81d7e0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d826:	jmp    81d99e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d82b:	cmpl   $0x1,0x150(%r14)
  81d833:	jne    81d845 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d835:	mov    0x138(%r14),%rax
  81d83c:	add    0x130(%r14),%rax
  81d843:	je     81d87c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d845:	mov    %rdi,%rbx
  81d848:	add    $0x78,%r14
  81d84c:	lea    0x58(%rsp),%rdi
  81d851:	mov    %rdx,%rsi
  81d854:	mov    $0x1,%edx
  81d859:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81d85e:	mov    %r14,%rdi
  81d861:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d866:	lea    0x58(%rsp),%rsi
  81d86b:	mov    $0xe8,%edx
  81d870:	mov    %r14,%rdi
  81d873:	call   *0x66255f(%rip)        # e7fdd8 <memcpy@GLIBC_2.14>
  81d879:	mov    %rbx,%rdi
  81d87c:	movq   $0x0,0x8(%rdi)
  81d884:	movl   $0xffffffff,(%rdi)
  81d88a:	jmp    81d9ad <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d88f:	xor    %ebx,%ebx
  81d891:	jmp    81d99e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d896:	mov    0x8(%rsp),%rax
  81d89b:	mov    0x150(%rax),%eax
  81d8a1:	cmp    $0x81,%eax
  81d8a6:	mov    $0x80,%edx
  81d8ab:	cmovae %eax,%edx
  81d8ae:	add    %edx,%edx
  81d8b0:	cmp    $0x800,%edx
  81d8b6:	mov    $0x800,%eax
  81d8bb:	cmovae %eax,%edx
  81d8be:	lea    0x140(%rsp),%r12
  81d8c6:	mov    %r12,%rdi
  81d8c9:	mov    0x18(%rsp),%rsi
  81d8ce:	mov    %edx,0x8(%rsp)
  81d8d2:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81d8d7:	xor    %r15d,%r15d
  81d8da:	nopw   0x0(%rax,%rax,1)
  81d8e0:	mov    0x0(%r13,%r15,1),%rax
  81d8e5:	movups 0x28(%rax),%xmm0
  81d8e9:	lea    0x68(%rsp),%rcx
  81d8ee:	movups %xmm0,(%rcx)
  81d8f1:	movups 0x18(%rax),%xmm0
  81d8f5:	movups %xmm0,0x58(%rsp)
  81d8fa:	movups 0x38(%rax),%xmm0
  81d8fe:	movups %xmm0,0x78(%rsp)
  81d903:	mov    %r12,%rdi
  81d906:	mov    0x20(%rsp),%rsi
  81d90b:	lea    0x58(%rsp),%rdx
  81d910:	call   81cf60 <<gpui_gpu::renderer::Atlas>::insert>
  81d915:	cmp    $0x1,%rax
  81d919:	jne    81d929 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d91b:	add    %rdx,%rbx
  81d91e:	add    $0x8,%r15
  81d922:	cmp    %r15,%rbp
  81d925:	jne    81d8e0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d927:	jmp    81d96b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d929:	mov    0x8(%rsp),%r15d
  81d92e:	cmp    $0x800,%r15d
  81d935:	je     81d9bf <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d93b:	mov    %r12,%rdi
  81d93e:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d943:	add    %r15d,%r15d
  81d946:	cmp    $0x800,%r15d
  81d94d:	mov    $0x800,%eax
  81d952:	cmovae %eax,%r15d
  81d956:	mov    %r12,%rdi
  81d959:	mov    0x18(%rsp),%rsi
  81d95e:	mov    %r15d,0x8(%rsp)
  81d963:	mov    %r15d,%edx
  81d966:	jmp    81d8d2 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81d96b:	lea    0x58(%rsp),%rdi
  81d970:	lea    0x140(%rsp),%rsi
  81d978:	mov    $0xe8,%edx
  81d97d:	call   *0x662455(%rip)        # e7fdd8 <memcpy@GLIBC_2.14>
  81d983:	mov    %r14,%rdi
  81d986:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d98b:	lea    0x58(%rsp),%rsi
  81d990:	mov    $0xe8,%edx
  81d995:	mov    %r14,%rdi
  81d998:	call   *0x66243a(%rip)        # e7fdd8 <memcpy@GLIBC_2.14>
  81d99e:	mov    0x10(%rsp),%rax
  81d9a3:	mov    %rbx,0x8(%rax)
  81d9a7:	movl   $0xffffffff,(%rax)
  81d9ad:	add    $0x228,%rsp
  81d9b4:	pop    %rbx
  81d9b5:	pop    %r12
  81d9b7:	pop    %r13
  81d9b9:	pop    %r14
  81d9bb:	pop    %r15
  81d9bd:	pop    %rbp
  81d9be:	ret
  81d9bf:	mov    0x10(%rsp),%rax
  81d9c4:	movl   $0x7,(%rax)
  81d9ca:	lea    0x140(%rsp),%rdi
  81d9d2:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9d7:	jmp    81d9ad <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d9d9:	jmp    81d9db <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81d9db:	mov    %rax,%rbx
  81d9de:	lea    0x58(%rsp),%rsi
  81d9e3:	mov    $0xe8,%edx
  81d9e8:	mov    %r14,%rdi
  81d9eb:	call   *0x6623e7(%rip)        # e7fdd8 <memcpy@GLIBC_2.14>
  81d9f1:	mov    %rbx,%rdi
  81d9f4:	call   e2c890 <_Unwind_Resume@plt>
  81d9f9:	mov    %rax,%rbx
  81d9fc:	lea    0x140(%rsp),%rdi
  81da04:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da09:	mov    %rbx,%rdi
  81da0c:	call   e2c890 <_Unwind_Resume@plt>
  81da11:	call   *0x662371(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1527 frame=952

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081da20 <<gpui_gpu::renderer::RendererState>::new>:
  81da20:	push   %r15
  81da22:	push   %r14
  81da24:	push   %r13
  81da26:	push   %r12
  81da28:	push   %rbx
  81da29:	sub    $0x390,%rsp
  81da30:	mov    %rsi,%r14
  81da33:	mov    %rdi,%rbx
  81da36:	lea    -0x748e63(%rip),%rax        # d4bda <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.4447969268566763096+0xa>
  81da3d:	mov    %rax,0xd8(%rsp)
  81da45:	movq   $0x7,0xe0(%rsp)
  81da51:	movq   $0x30,0xe8(%rsp)
  81da5d:	movl   $0x48,0xf0(%rsp)
  81da68:	movb   $0x0,0xf4(%rsp)
  81da70:	mov    0x6626e1(%rip),%r15        # e80158 <_DYNAMIC+0x620>
  81da77:	lea    0x10(%rsp),%rdi
  81da7c:	lea    0xd8(%rsp),%rdx
  81da84:	call   *%r15
  81da87:	movq   $0x30,0x30(%rsp)
  81da90:	lea    -0x748eb6(%rip),%rax        # d4be1 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.4447969268566763096+0x11>
  81da97:	mov    %rax,0xd8(%rsp)
  81da9f:	movq   $0x5,0xe0(%rsp)
  81daab:	movq   $0x10,0xe8(%rsp)
  81dab7:	movl   $0x88,0xf0(%rsp)
  81dac2:	movb   $0x0,0xf4(%rsp)
  81daca:	lea    0x38(%rsp),%rdi
  81dacf:	lea    0xd8(%rsp),%rdx
  81dad7:	mov    %r14,%rsi
  81dada:	call   *%r15
  81dadd:	movq   $0x10,0x58(%rsp)
  81dae6:	lea    -0x748f07(%rip),%rax        # d4be6 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.4447969268566763096+0x16>
  81daed:	mov    %rax,0xd8(%rsp)
  81daf5:	movq   $0x5,0xe0(%rsp)
  81db01:	movq   $0x8,0xe8(%rsp)
  81db0d:	movl   $0x88,0xf0(%rsp)
  81db18:	movb   $0x0,0xf4(%rsp)
  81db20:	lea    0x60(%rsp),%rdi
  81db25:	lea    0xd8(%rsp),%rdx
  81db2d:	mov    %r14,%rsi
  81db30:	call   *0x662622(%rip)        # e80158 <_DYNAMIC+0x620>
  81db36:	movq   $0x8,0x80(%rsp)
  81db42:	lea    -0x748f5e(%rip),%rax        # d4beb <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.4447969268566763096+0x1b>
  81db49:	mov    %rax,0xd8(%rsp)
  81db51:	movq   $0x7,0xe0(%rsp)
  81db5d:	movq   $0x4,0xe8(%rsp)
  81db69:	movl   $0x88,0xf0(%rsp)
  81db74:	movb   $0x0,0xf4(%rsp)
  81db7c:	lea    0x88(%rsp),%rdi
  81db84:	lea    0xd8(%rsp),%rdx
  81db8c:	mov    %r14,%rsi
  81db8f:	call   *0x6625c3(%rip)        # e80158 <_DYNAMIC+0x620>
  81db95:	movq   $0x4,0xa8(%rsp)
  81dba1:	lea    -0x748fb6(%rip),%rax        # d4bf2 <anon.36d49f465d299f05a84fba3771e6457e.32.llvm.4447969268566763096+0x22>
  81dba8:	mov    %rax,0xd8(%rsp)
  81dbb0:	movq   $0x11,0xe0(%rsp)
  81dbbc:	movq   $0x20,0xe8(%rsp)
  81dbc8:	movl   $0x88,0xf0(%rsp)
  81dbd3:	movb   $0x0,0xf4(%rsp)
  81dbdb:	lea    0xb0(%rsp),%rdi
  81dbe3:	lea    0xd8(%rsp),%rdx
  81dbeb:	mov    %r14,%rsi
  81dbee:	call   *0x662564(%rip)        # e80158 <_DYNAMIC+0x620>
  81dbf4:	movq   $0x20,0xd0(%rsp)
  81dc00:	lea    0x2a8(%rsp),%rdi
  81dc08:	mov    %r14,%rsi
  81dc0b:	mov    $0x1,%edx
  81dc10:	call   81cc90 <<gpui_gpu::renderer::Atlas>::new>
  81dc15:	mov    0x18(%r14),%r13
  81dc19:	lock incq 0x0(%r13)
  81dc1e:	jle    81df53 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81dc24:	mov    %r13,0x8(%rsp)
  81dc29:	mov    0x30(%rsp),%rax
  81dc2e:	mov    %rax,0x1e0(%rsp)
  81dc36:	movups 0x10(%rsp),%xmm0
  81dc3b:	movups 0x20(%rsp),%xmm1
  81dc40:	movaps %xmm1,0x1d0(%rsp)
  81dc48:	movaps %xmm0,0x1c0(%rsp)
  81dc50:	mov    0x58(%rsp),%rax
  81dc55:	mov    %rax,0x210(%rsp)
  81dc5d:	movups 0x38(%rsp),%xmm0
  81dc62:	movups 0x48(%rsp),%xmm1
  81dc67:	movaps %xmm1,0x200(%rsp)
  81dc6f:	movaps %xmm0,0x1f0(%rsp)
  81dc77:	mov    0x80(%rsp),%rax
  81dc7f:	mov    %rax,0x240(%rsp)
  81dc87:	movups 0x60(%rsp),%xmm0
  81dc8c:	movups 0x70(%rsp),%xmm1
  81dc91:	movaps %xmm1,0x230(%rsp)
  81dc99:	movaps %xmm0,0x220(%rsp)
  81dca1:	mov    0xa8(%rsp),%rax
  81dca9:	mov    %rax,0x270(%rsp)
  81dcb1:	movups 0x88(%rsp),%xmm0
  81dcb9:	movups 0x98(%rsp),%xmm1
  81dcc1:	movaps %xmm1,0x260(%rsp)
  81dcc9:	movaps %xmm0,0x250(%rsp)
  81dcd1:	mov    0xd0(%rsp),%rax
  81dcd9:	mov    %rax,0x2a0(%rsp)
  81dce1:	movups 0xb0(%rsp),%xmm0
  81dce9:	movups 0xc0(%rsp),%xmm1
  81dcf1:	movaps %xmm1,0x290(%rsp)
  81dcf9:	movaps %xmm0,0x280(%rsp)
  81dd01:	lea    0xd8(%rsp),%rdi
  81dd09:	lea    0x2a8(%rsp),%rsi
  81dd11:	mov    $0xe8,%edx
  81dd16:	call   *0x6620bc(%rip)        # e7fdd8 <memcpy@GLIBC_2.14>
  81dd1c:	mov    %fs:0x0,%rax
  81dd25:	lea    -0x28(%rax),%rax
  81dd2c:	mov    %rax,%r12
  81dd2f:	cmpb   $0x1,0x10(%rax)
  81dd33:	jne    81df33 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81dd39:	mov    (%r12),%r14
  81dd3d:	mov    0x8(%r12),%r15
  81dd42:	lea    0x1(%r14),%rax
  81dd46:	mov    %rax,(%r12)
  81dd4a:	mov    %r13,0x228(%rbx)
  81dd51:	mov    0x30(%rsp),%rax
  81dd56:	mov    %rax,0x250(%rbx)
  81dd5d:	movups 0x10(%rsp),%xmm0
  81dd62:	movups 0x20(%rsp),%xmm1
  81dd67:	movups %xmm1,0x240(%rbx)
  81dd6e:	movups %xmm0,0x230(%rbx)
  81dd75:	mov    0x58(%rsp),%rax
  81dd7a:	mov    %rax,0x278(%rbx)
  81dd81:	movups 0x38(%rsp),%xmm0
  81dd86:	movups 0x48(%rsp),%xmm1
  81dd8b:	movups %xmm1,0x268(%rbx)
  81dd92:	movups %xmm0,0x258(%rbx)
  81dd99:	mov    0x80(%rsp),%rax
  81dda1:	mov    %rax,0x2a0(%rbx)
  81dda8:	movups 0x60(%rsp),%xmm0
  81ddad:	movups 0x70(%rsp),%xmm1
  81ddb2:	movups %xmm1,0x290(%rbx)
  81ddb9:	movups %xmm0,0x280(%rbx)
  81ddc0:	movups 0x88(%rsp),%xmm0
  81ddc8:	movups 0x98(%rsp),%xmm1
  81ddd0:	movups %xmm0,0x2a8(%rbx)
  81ddd7:	movups %xmm1,0x2b8(%rbx)
  81ddde:	mov    0xa8(%rsp),%rax
  81dde6:	mov    %rax,0x2c8(%rbx)
  81dded:	movups 0xb0(%rsp),%xmm0
  81ddf5:	movups 0xc0(%rsp),%xmm1
  81ddfd:	movups %xmm0,0x2d0(%rbx)
  81de04:	movups %xmm1,0x2e0(%rbx)
  81de0b:	mov    0xd0(%rsp),%rax
  81de13:	mov    %rax,0x2f0(%rbx)
  81de1a:	lea    0x78(%rbx),%rdi
  81de1e:	lea    0x2a8(%rsp),%rsi
  81de26:	mov    $0xe8,%edx
  81de2b:	call   *0x661fa7(%rip)        # e7fdd8 <memcpy@GLIBC_2.14>
  81de31:	movq   $0x0,0x328(%rbx)
  81de3c:	movq   $0x0,(%rbx)
  81de43:	movq   $0x4,0x8(%rbx)
  81de4b:	xorps  %xmm0,%xmm0
  81de4e:	movups %xmm0,0x10(%rbx)
  81de52:	movq   $0x4,0x20(%rbx)
  81de5a:	movups %xmm0,0x28(%rbx)
  81de5e:	movq   $0x4,0x38(%rbx)
  81de66:	movups %xmm0,0x40(%rbx)
  81de6a:	movq   $0x4,0x50(%rbx)
  81de72:	movups %xmm0,0x58(%rbx)
  81de76:	movq   $0x4,0x68(%rbx)
  81de7e:	movq   $0x0,0x70(%rbx)
  81de86:	movups 0x610913(%rip),%xmm1        # e2e7a0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x1f8>
  81de8d:	movups %xmm1,0x2f8(%rbx)
  81de94:	movups 0x610915(%rip),%xmm1        # e2e7b0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x208>
  81de9b:	movups %xmm1,0x308(%rbx)
  81dea2:	mov    %r14,0x318(%rbx)
  81dea9:	mov    %r15,0x320(%rbx)
  81deb0:	movw   $0x101,0x340(%rbx)
  81deb9:	movq   $0x0,0x330(%rbx)
  81dec4:	movups %xmm0,0x210(%rbx)
  81decb:	movups %xmm0,0x200(%rbx)
  81ded2:	movups %xmm0,0x1f0(%rbx)
  81ded9:	movups %xmm0,0x1e0(%rbx)
  81dee0:	movups %xmm0,0x1d0(%rbx)
  81dee7:	movups %xmm0,0x1c0(%rbx)
  81deee:	movups %xmm0,0x1b0(%rbx)
  81def5:	movups %xmm0,0x1a0(%rbx)
  81defc:	movups %xmm0,0x190(%rbx)
  81df03:	movups %xmm0,0x180(%rbx)
  81df0a:	movups %xmm0,0x170(%rbx)
  81df11:	movups %xmm0,0x160(%rbx)
  81df18:	movb   $0x0,0x220(%rbx)
  81df1f:	mov    %rbx,%rax
  81df22:	add    $0x390,%rsp
  81df29:	pop    %rbx
  81df2a:	pop    %r12
  81df2c:	pop    %r13
  81df2e:	pop    %r14
  81df30:	pop    %r15
  81df32:	ret
  81df33:	call   *0x662227(%rip)        # e80160 <_DYNAMIC+0x628>
  81df39:	mov    %rax,%r14
  81df3c:	mov    %rdx,%r15
  81df3f:	mov    %rax,(%r12)
  81df43:	mov    %rdx,0x8(%r12)
  81df48:	movb   $0x1,0x10(%r12)
  81df4e:	jmp    81dd42 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81df53:	ud2
  81df55:	mov    %rax,%rbx
  81df58:	lea    0xd8(%rsp),%rdi
  81df60:	call   81ba50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81df65:	lea    0x280(%rsp),%rdi
  81df6d:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df72:	lea    0x250(%rsp),%rdi
  81df7a:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df7f:	lea    0x220(%rsp),%rdi
  81df87:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df8c:	lea    0x1f0(%rsp),%rdi
  81df94:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81df99:	lea    0x1c0(%rsp),%rdi
  81dfa1:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfa6:	lock decq 0x0(%r13)
  81dfab:	jne    81e009 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81dfad:	lea    0x8(%rsp),%rdi
  81dfb2:	call   *0x661fe8(%rip)        # e7ffa0 <_DYNAMIC+0x468>
  81dfb8:	jmp    81e009 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81dfba:	mov    %rax,%rbx
  81dfbd:	lea    0xb0(%rsp),%rdi
  81dfc5:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfca:	jmp    81dfcf <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81dfcc:	mov    %rax,%rbx
  81dfcf:	lea    0x88(%rsp),%rdi
  81dfd7:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfdc:	jmp    81dfe1 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81dfde:	mov    %rax,%rbx
  81dfe1:	lea    0x60(%rsp),%rdi
  81dfe6:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dfeb:	jmp    81dff0 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81dfed:	mov    %rax,%rbx
  81dff0:	lea    0x38(%rsp),%rdi
  81dff5:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81dffa:	jmp    81dfff <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81dffc:	mov    %rax,%rbx
  81dfff:	lea    0x10(%rsp),%rdi
  81e004:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e009:	mov    %rbx,%rdi
  81e00c:	call   e2c890 <_Unwind_Resume@plt>
  81e011:	call   *0x661d71(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9261 frame=1448

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e020 <<gpui_gpu::renderer::RendererState>::render>:
  81e020:	push   %rbp
  81e021:	push   %r15
  81e023:	push   %r14
  81e025:	push   %r13
  81e027:	push   %r12
  81e029:	push   %rbx
  81e02a:	sub    $0x578,%rsp
  81e031:	mov    0x228(%rsi),%rax
  81e038:	mov    0x18(%rdx),%rbx
  81e03c:	cmp    %rbx,%rax
  81e03f:	je     81e05d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e041:	mov    0x10(%rax),%r9
  81e045:	cmp    0x10(%rbx),%r9
  81e049:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e04f:	mov    0x18(%rax),%rax
  81e053:	cmp    0x18(%rbx),%rax
  81e057:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e05d:	movupd 0x330(%rsi),%xmm0
  81e065:	movapd %xmm0,0x130(%rsp)
  81e06e:	movq   $0x0,0x330(%rsi)
  81e079:	mov    0x130(%rsp),%r13
  81e081:	test   %r13,%r13
  81e084:	je     81e0c6 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e086:	lock decq 0x0(%r13)
  81e08b:	jne    81e0c6 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e08d:	lea    0x130(%rsp),%rax
  81e095:	mov    %rdi,%r14
  81e098:	mov    %rax,%rdi
  81e09b:	mov    %rsi,%r12
  81e09e:	mov    %r8,%rbp
  81e0a1:	mov    %rdx,%r15
  81e0a4:	mov    %r13,0x38(%rsp)
  81e0a9:	mov    %rcx,%r13
  81e0ac:	call   *0x661f9e(%rip)        # e80050 <_DYNAMIC+0x518>
  81e0b2:	mov    %r13,%rcx
  81e0b5:	mov    0x38(%rsp),%r13
  81e0ba:	mov    %r15,%rdx
  81e0bd:	mov    %rbp,%r8
  81e0c0:	mov    %r12,%rsi
  81e0c3:	mov    %r14,%rdi
  81e0c6:	mov    0x228(%rsi),%rax
  81e0cd:	cmp    %rbx,%rax
  81e0d0:	je     81e0ee <<gpui_gpu::renderer::RendererState>::render+0xce>
  81e0d2:	mov    0x10(%rax),%r9
  81e0d6:	cmp    0x10(%rbx),%r9
  81e0da:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0e0:	mov    0x18(%rax),%rax
  81e0e4:	cmp    0x18(%rbx),%rax
  81e0e8:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0ee:	lea    0x330(%rsi),%rax
  81e0f5:	mov    %rax,0xe8(%rsp)
  81e0fd:	mov    (%rax),%rax
  81e100:	test   %rax,%rax
  81e103:	je     81e13c <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e105:	lock decq (%rax)
  81e109:	jne    81e13c <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e10b:	mov    %rdi,%r14
  81e10e:	lea    0x330(%rsi),%rdi
  81e115:	mov    %rsi,%r12
  81e118:	mov    %r8,%rbp
  81e11b:	mov    %rdx,%r15
  81e11e:	mov    %r13,%rbx
  81e121:	mov    %rcx,%r13
  81e124:	call   *0x661f26(%rip)        # e80050 <_DYNAMIC+0x518>
  81e12a:	mov    %r13,%rcx
  81e12d:	mov    %rbx,%r13
  81e130:	mov    %r15,%rdx
  81e133:	mov    %rbp,%r8
  81e136:	mov    %r12,%rsi
  81e139:	mov    %r14,%rdi
  81e13c:	movq   $0x0,0x330(%rsi)
  81e147:	mov    (%rcx),%ebp
  81e149:	mov    0x8(%rcx),%r9d
  81e14d:	movzbl 0xd(%rcx),%eax
  81e151:	test   %r9d,%r9d
  81e154:	sets   %r10b
  81e158:	and    $0x7fffffff,%r9d
  81e15f:	lea    -0x800000(%r9),%r11d
  81e166:	cmp    $0x7f000000,%r11d
  81e16d:	setb   %r11b
  81e171:	and    %r10b,%r11b
  81e174:	lea    -0x1(%r9),%r14d
  81e178:	cmp    $0x7fffff,%r14d
  81e17f:	setb   %r14b
  81e183:	and    %r10b,%r14b
  81e186:	test   %r9d,%r9d
  81e189:	sete   %r10b
  81e18d:	cmp    $0x7f800000,%r9d
  81e194:	sete   %r15b
  81e198:	or     %r10b,%r15b
  81e19b:	cmp    $0x7f800001,%r9d
  81e1a2:	setge  %r9b
  81e1a6:	or     %r15b,%r9b
  81e1a9:	or     %r14b,%r9b
  81e1ac:	test   %ebp,%ebp
  81e1ae:	setne  %r10b
  81e1b2:	and    %al,%r10b
  81e1b5:	or     %r11b,%r10b
  81e1b8:	or     %r9b,%r10b
  81e1bb:	test   $0x1,%r10b
  81e1bf:	je     81e1e4 <<gpui_gpu::renderer::RendererState>::render+0x1c4>
  81e1c1:	movl   $0x3,(%rdi)
  81e1c7:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e1c9:	movl   $0x4,(%rdi)
  81e1cf:	mov    %rdi,%rax
  81e1d2:	add    $0x578,%rsp
  81e1d9:	pop    %rbx
  81e1da:	pop    %r12
  81e1dc:	pop    %r13
  81e1de:	pop    %r14
  81e1e0:	pop    %r15
  81e1e2:	pop    %rbp
  81e1e3:	ret
  81e1e4:	movd   0x4(%rcx),%xmm2
  81e1e9:	movzbl 0xc(%rcx),%r12d
  81e1ee:	test   $0x1,%bpl
  81e1f2:	je     81e26a <<gpui_gpu::renderer::RendererState>::render+0x24a>
  81e1f4:	movd   %xmm2,%r9d
  81e1f9:	test   %r9d,%r9d
  81e1fc:	sets   %r10b
  81e200:	and    $0x7fffffff,%r9d
  81e207:	lea    -0x800000(%r9),%r11d
  81e20e:	cmp    $0x7f000000,%r11d
  81e215:	setb   %r11b
  81e219:	and    %r10b,%r11b
  81e21c:	lea    -0x1(%r9),%r14d
  81e220:	cmp    $0x7fffff,%r14d
  81e227:	setb   %r14b
  81e22b:	and    %r10b,%r14b
  81e22e:	test   %r9d,%r9d
  81e231:	sete   %r10b
  81e235:	cmp    $0x7f800000,%r9d
  81e23c:	sete   %r15b
  81e240:	or     %r10b,%r15b
  81e243:	cmp    $0x7f800001,%r9d
  81e24a:	setge  %r9b
  81e24e:	or     %r15b,%r9b
  81e251:	or     %r14b,%r9b
  81e254:	or     %r11b,%r9b
  81e257:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e25d:	ucomiss -0x76f358(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e264:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e26a:	mov    0x28(%rcx),%r14d
  81e26e:	cmp    %r14d,0x20(%r8)
  81e272:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e278:	mov    0x2c(%rcx),%r15d
  81e27c:	cmp    %r15d,0x24(%r8)
  81e280:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e286:	mov    0x38(%r8),%r10d
  81e28a:	cmp    0x20(%rdx),%r10d
  81e28e:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e294:	cmp    $0x4c,%r10d
  81e298:	jne    81e2bd <<gpui_gpu::renderer::RendererState>::render+0x29d>
  81e29a:	movq   0x3c(%r8),%xmm0
  81e2a0:	movq   0x24(%rdx),%xmm1
  81e2a5:	pcmpeqd %xmm0,%xmm1
  81e2a9:	pshufd $0x50,%xmm1,%xmm0
  81e2ae:	movmskpd %xmm0,%r9d
  81e2b3:	cmp    $0x3,%r9d
  81e2b7:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2bd:	cmp    $0x4000,%r15d
  81e2c4:	ja     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2c6:	cmp    $0x4000,%r14d
  81e2cd:	ja     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2cf:	mov    %r15,%r9
  81e2d2:	imul   %r14,%r9
  81e2d6:	add    $0xfffffffffeffffff,%r9
  81e2dd:	cmp    $0xffffffffff000000,%r9
  81e2e4:	jb     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2e6:	mov    0x10(%rcx),%rbx
  81e2ea:	mov    0x80(%rbx),%r11
  81e2f1:	cmp    $0x10000,%r11
  81e2f8:	jbe    81e305 <<gpui_gpu::renderer::RendererState>::render+0x2e5>
  81e2fa:	movl   $0x6,(%rdi)
  81e300:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e305:	movd   0x18(%rcx),%xmm0
  81e30a:	movd   %xmm0,%r9d
  81e30f:	and    $0x7fffffff,%r9d
  81e316:	cmp    $0x7f7fffff,%r9d
  81e31d:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e323:	pand   -0x770b3b(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e32b:	ucomiss -0x76f1ce(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e332:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e338:	movd   0x1c(%rcx),%xmm0
  81e33d:	movd   %xmm0,%r9d
  81e342:	and    $0x7fffffff,%r9d
  81e349:	cmp    $0x7f7fffff,%r9d
  81e350:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e356:	pand   -0x770b6e(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e35e:	ucomiss -0x76f201(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e365:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e36b:	movd   0x20(%rcx),%xmm0
  81e370:	movd   %xmm0,%r9d
  81e375:	and    $0x7fffffff,%r9d
  81e37c:	cmp    $0x7f7fffff,%r9d
  81e383:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e389:	pand   -0x770ba1(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e391:	ucomiss -0x76f234(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e398:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e39e:	movd   0x24(%rcx),%xmm0
  81e3a3:	movd   %xmm0,%r9d
  81e3a8:	and    $0x7fffffff,%r9d
  81e3af:	cmp    $0x7f7fffff,%r9d
  81e3b6:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3bc:	movdqa -0x770bd4(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3c4:	pand   %xmm0,%xmm1
  81e3c8:	ucomiss -0x76f26b(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3cf:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3d5:	xorps  %xmm1,%xmm1
  81e3d8:	ucomiss %xmm1,%xmm0
  81e3db:	jb     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3e1:	movss  -0x76f609(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3e9:	ucomiss %xmm0,%xmm1
  81e3ec:	jb     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3f2:	movzwl 0x30(%rcx),%r9d
  81e3f7:	mov    %r9d,0x10(%rsp)
  81e3fc:	movzwl 0x32(%rcx),%r9d
  81e401:	mov    %r9d,0x30(%rsp)
  81e406:	cmp    $0x28,%r10d
  81e40a:	mov    %r8,0x4b8(%rsp)
  81e412:	mov    %rcx,0x120(%rsp)
  81e41a:	mov    %rdx,0xa0(%rsp)
  81e422:	mov    %r13,0x38(%rsp)
  81e427:	movd   %xmm2,0x2e8(%rsp)
  81e430:	movss  %xmm1,0xf4(%rsp)
  81e439:	jne    81e445 <<gpui_gpu::renderer::RendererState>::render+0x425>
  81e43b:	test   $0x1,%al
  81e43d:	je     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e443:	jmp    81e460 <<gpui_gpu::renderer::RendererState>::render+0x440>
  81e445:	test   $0x1,%al
  81e447:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e44d:	ucomiss -0x76f674(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e454:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e45a:	jp     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e460:	mov    %rbx,0x100(%rsp)
  81e468:	mov    %r11,0x108(%rsp)
  81e470:	mov    %r10d,0x2e4(%rsp)
  81e478:	mov    %rdi,0x50(%rsp)
  81e47d:	lea    0xf(%r14),%rax
  81e481:	shr    $0x4,%rax
  81e485:	lea    0xf(%r15),%ecx
  81e489:	shr    $0x4,%ecx
  81e48c:	lea    0x18(%rsi),%rdi
  81e490:	movq   $0x0,0x28(%rsi)
  81e498:	mov    %rax,0x90(%rsp)
  81e4a0:	imul   %eax,%ecx
  81e4a3:	movabs $0x4000000000000000,%rdx
  81e4ad:	mov    %rdi,0x4c8(%rsp)
  81e4b5:	mov    %rsi,%r13
  81e4b8:	mov    %rcx,0x40(%rsp)
  81e4bd:	mov    %rcx,%rsi
  81e4c0:	call   823680 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e4c5:	mov    %r13,0x8(%rsp)
  81e4ca:	mov    0x10(%r13),%rax
  81e4ce:	mov    %rax,0x348(%rsp)
  81e4d6:	mov    0x120(%rsp),%rdi
  81e4de:	call   *0x661bfc(%rip)        # e800e0 <_DYNAMIC+0x5a8>
  81e4e4:	mov    %rdx,0x358(%rsp)
  81e4ec:	mov    %rax,0x350(%rsp)
  81e4f4:	sub    %rax,%rdx
  81e4f7:	cmp    $0x300000,%rdx
  81e4fe:	ja     81e635 <<gpui_gpu::renderer::RendererState>::render+0x615>
  81e504:	mov    %rdx,%rcx
  81e507:	mov    %rdx,%rax
  81e50a:	shr    $0x3,%rax
  81e50e:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81e518:	imul   %rax,%rdx
  81e51c:	mov    %rdx,0x2c0(%rsp)
  81e524:	mov    0x350(%rsp),%rax
  81e52c:	cmp    %rax,0x358(%rsp)
  81e534:	je     81e565 <<gpui_gpu::renderer::RendererState>::render+0x545>
  81e536:	mov    $0xaaaaaaab,%eax
  81e53b:	imul   %rax,%rcx
  81e53f:	shr    $0x2a,%rcx
  81e543:	mov    0x2c0(%rsp),%rdx
  81e54b:	mov    %edx,%eax
  81e54d:	and    $0x3f,%eax
  81e550:	add    %rdx,%rcx
  81e553:	cmp    $0x1,%rax
  81e557:	sbb    $0xffffffffffffffff,%rcx
  81e55b:	inc    %rcx
  81e55e:	mov    %rcx,0x20(%rsp)
  81e563:	jmp    81e56e <<gpui_gpu::renderer::RendererState>::render+0x54e>
  81e565:	movq   $0x0,0x20(%rsp)
  81e56e:	mov    0x100(%rsp),%rax
  81e576:	mov    0x98(%rax),%rdx
  81e57d:	add    0xb0(%rax),%rdx
  81e584:	mov    0x30(%rsp),%ecx
  81e588:	shl    $0x10,%ecx
  81e58b:	add    0x10(%rsp),%ecx
  81e58f:	mov    %rax,0x130(%rsp)
  81e597:	movq   $0x0,0x138(%rsp)
  81e5a3:	mov    0x108(%rsp),%rbx
  81e5ab:	mov    %rbx,0x140(%rsp)
  81e5b3:	mov    %rdx,0x340(%rsp)
  81e5bb:	mov    %rdx,0x148(%rsp)
  81e5c3:	mov    %ecx,0x30(%rsp)
  81e5c7:	mov    %ecx,0x150(%rsp)
  81e5ce:	mov    0x8(%rsp),%r13
  81e5d3:	movzbl 0x341(%r13),%esi
  81e5db:	lea    0x130(%rsp),%rdi
  81e5e3:	call   81c740 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>
  81e5e8:	mov    %rax,0x110(%rsp)
  81e5f0:	mov    0x20(%rsp),%rcx
  81e5f5:	lea    (%rcx,%rax,4),%rcx
  81e5f9:	mov    %rcx,0x10(%rsp)
  81e5fe:	lea    (%rcx,%rbx,2),%rax
  81e602:	xor    %edx,%edx
  81e604:	mov    %rax,0x2b8(%rsp)
  81e60c:	sub    0x348(%rsp),%rax
  81e614:	cmovae %rax,%rdx
  81e618:	mov    0x10(%r13),%rsi
  81e61c:	mov    $0x4,%ecx
  81e621:	mov    $0x10,%r8d
  81e627:	mov    %r13,%rdi
  81e62a:	call   825e40 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e62f:	cmp    $0xffffffffffffffff,%rax
  81e633:	je     81e645 <<gpui_gpu::renderer::RendererState>::render+0x625>
  81e635:	mov    0x50(%rsp),%rdi
  81e63a:	movl   $0x6,(%rdi)
  81e640:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e645:	pxor   %xmm0,%xmm0
  81e649:	movdqa %xmm0,0x130(%rsp)
  81e652:	lea    0x130(%rsp),%rdx
  81e65a:	mov    0x8(%rsp),%rbx
  81e65f:	mov    %rbx,%rdi
  81e662:	mov    0x108(%rsp),%rax
  81e66a:	mov    0x10(%rsp),%rcx
  81e66f:	lea    (%rcx,%rax,2),%rsi
  81e673:	call   8237a0 <<alloc::vec::Vec<[u32; 4]>>::resize>
  81e678:	movq   $0xffffffffffffffff,0x2d0(%rsp)
  81e684:	movq   $0x0,0x2d8(%rsp)
  81e690:	movq   $0xffffffffffffffff,0x230(%rsp)
  81e69c:	movq   $0x0,0x238(%rsp)
  81e6a8:	mov    0x10(%rbx),%rdx
  81e6ac:	cmp    %rdx,0x20(%rsp)
  81e6b1:	ja     8203a8 <<gpui_gpu::renderer::RendererState>::render+0x2388>
  81e6b7:	mov    0x8(%rsp),%r13
  81e6bc:	mov    0x8(%r13),%rdi
  81e6c0:	lea    0x2d0(%rsp),%r8
  81e6c8:	mov    0x20(%rsp),%rsi
  81e6cd:	mov    0x120(%rsp),%rdx
  81e6d5:	mov    0x2c0(%rsp),%rcx
  81e6dd:	call   8258d0 <gpui_gpu::renderer::slots::write_prefix>
  81e6e2:	lea    0x48(%r13),%rdi
  81e6e6:	movq   $0x0,0x58(%r13)
  81e6ee:	mov    %rdi,0x4c0(%rsp)
  81e6f6:	mov    0x40(%rsp),%rsi
  81e6fb:	xor    %edx,%edx
  81e6fd:	call   823890 <<alloc::vec::Vec<u32>>::resize>
  81e702:	movq   $0x0,0x70(%r13)
  81e70a:	cmpq   $0x0,0x60(%r13)
  81e70f:	jne    81e720 <<gpui_gpu::renderer::RendererState>::render+0x700>
  81e711:	mov    0x8(%rsp),%rax
  81e716:	lea    0x60(%rax),%rdi
  81e71a:	call   *0x6619c8(%rip)        # e800e8 <_DYNAMIC+0x5b0>
  81e720:	mov    0x110(%rsp),%rax
  81e728:	add    %rax,%rax
  81e72b:	mov    %rax,0x110(%rsp)
  81e733:	mov    0x8(%rsp),%rax
  81e738:	mov    0x68(%rax),%rcx
  81e73c:	pxor   %xmm0,%xmm0
  81e740:	movdqu %xmm0,0x10(%rcx)
  81e745:	movdqu %xmm0,(%rcx)
  81e749:	movq   $0x1,0x70(%rax)
  81e751:	lea    0x2f8(%rax),%rdi
  81e758:	call   8230d0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e75d:	mov    0x100(%rsp),%rax
  81e765:	mov    %rax,0x368(%rsp)
  81e76d:	movq   $0x0,0x370(%rsp)
  81e779:	mov    0x108(%rsp),%rax
  81e781:	mov    %rax,0x378(%rsp)
  81e789:	mov    0x340(%rsp),%rax
  81e791:	mov    %rax,0x380(%rsp)
  81e799:	mov    0x30(%rsp),%eax
  81e79d:	mov    %eax,0x388(%rsp)
  81e7a4:	lea    0x408(%rsp),%rdi
  81e7ac:	lea    0x368(%rsp),%rsi
  81e7b4:	call   *0x661936(%rip)        # e800f0 <_DYNAMIC+0x5b8>
  81e7ba:	mov    0x408(%rsp),%rax
  81e7c2:	mov    %rax,0x28(%rsp)
  81e7c7:	test   %rax,%rax
  81e7ca:	je     81f256 <<gpui_gpu::renderer::RendererState>::render+0x1236>
  81e7d0:	movq   $0x0,0x118(%rsp)
  81e7dc:	movq   $0x0,0x68(%rsp)
  81e7e5:	movq   $0x0,0x88(%rsp)
  81e7f1:	movq   $0x0,0x2a8(%rsp)
  81e7fd:	movq   $0x0,0x2b0(%rsp)
  81e809:	mov    0x410(%rsp),%rbx
  81e811:	mov    0x418(%rsp),%r13
  81e819:	lea    0x420(%rsp),%rcx
  81e821:	movups (%rcx),%xmm0
  81e824:	movups 0x10(%rcx),%xmm1
  81e828:	movups 0x20(%rcx),%xmm2
  81e82c:	movaps %xmm2,0x290(%rsp)
  81e834:	movaps %xmm1,0x280(%rsp)
  81e83c:	movaps %xmm0,0x270(%rsp)
  81e844:	lea    0x450(%rsp),%rdx
  81e84c:	movups (%rdx),%xmm0
  81e84f:	movaps %xmm0,0x330(%rsp)
  81e857:	movups 0x40(%rcx),%xmm0
  81e85b:	movaps %xmm0,0x320(%rsp)
  81e863:	mov    0x8(%rsp),%rax
  81e868:	movzbl 0x341(%rax),%esi
  81e86f:	mov    0x28(%rsp),%rax
  81e874:	mov    %rax,0x130(%rsp)
  81e87c:	mov    %rbx,0x138(%rsp)
  81e884:	mov    %r13,0x140(%rsp)
  81e88c:	movups (%rcx),%xmm0
  81e88f:	movdqu 0x10(%rcx),%xmm1
  81e894:	movdqu 0x20(%rcx),%xmm2
  81e899:	lea    0x148(%rsp),%rdi
  81e8a1:	movdqu %xmm2,0x20(%rdi)
  81e8a6:	movdqu %xmm1,0x10(%rdi)
  81e8ab:	movups %xmm0,(%rdi)
  81e8ae:	movups (%rdx),%xmm0
  81e8b1:	lea    0x178(%rsp),%rax
  81e8b9:	movups %xmm0,(%rax)
  81e8bc:	movdqu 0x40(%rcx),%xmm0
  81e8c1:	movdqu %xmm0,0x40(%rdi)
  81e8c6:	lea    0x130(%rsp),%rdi
  81e8ce:	call   8215f0 <gpui_gpu::renderer::compact_group>
  81e8d3:	mov    %rbx,0xa8(%rsp)
  81e8db:	mov    %r13,0xe0(%rsp)
  81e8e3:	lea    (%rbx,%r13,4),%rbx
  81e8e7:	mov    %al,0x1f(%rsp)
  81e8eb:	test   %al,%al
  81e8ed:	je     81eae2 <<gpui_gpu::renderer::RendererState>::render+0xac2>
  81e8f3:	mov    0xa8(%rsp),%rax
  81e8fb:	mov    %rax,0x490(%rsp)
  81e903:	mov    %rbx,0x498(%rsp)
  81e90b:	mov    0x28(%rsp),%rax
  81e910:	mov    %rax,0x4a0(%rsp)
  81e918:	movq   $0x0,0x4a8(%rsp)
  81e924:	lea    0x3a0(%rsp),%rdi
  81e92c:	lea    0x490(%rsp),%rsi
  81e934:	call   821c80 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e939:	cmpb   $0xff,0x3a8(%rsp)
  81e941:	je     81eaf0 <<gpui_gpu::renderer::RendererState>::render+0xad0>
  81e947:	pxor   %xmm0,%xmm0
  81e94b:	movdqa %xmm0,0x70(%rsp)
  81e951:	movdqa %xmm0,0x40(%rsp)
  81e957:	mov    0x3a0(%rsp),%rdx
  81e95f:	add    0x88(%rsp),%rdx
  81e967:	lea    0x3a8(%rsp),%rcx
  81e96f:	movups 0x38(%rcx),%xmm0
  81e973:	lea    0x148(%rsp),%rax
  81e97b:	movups %xmm0,0x20(%rax)
  81e97f:	movups 0x48(%rcx),%xmm0
  81e983:	lea    0x178(%rsp),%rsi
  81e98b:	movups %xmm0,0x40(%rsi)
  81e98f:	mov    0x30(%rcx),%rax
  81e993:	mov    %rax,0x160(%rsp)
  81e99b:	movups (%rcx),%xmm0
  81e99e:	movups 0x10(%rcx),%xmm1
  81e9a2:	movups 0x20(%rcx),%xmm2
  81e9a6:	movaps %xmm2,0x150(%rsp)
  81e9ae:	movaps %xmm1,0x140(%rsp)
  81e9b6:	movaps %xmm0,0x130(%rsp)
  81e9be:	lea    0x420(%rsp),%rax
  81e9c6:	movups (%rax),%xmm0
  81e9c9:	movups 0x10(%rax),%xmm1
  81e9cd:	movups 0x20(%rax),%xmm2
  81e9d1:	movups %xmm2,0x20(%rsi)
  81e9d5:	movups %xmm1,0x10(%rsi)
  81e9d9:	movups %xmm0,(%rsi)
  81e9dc:	lea    0x450(%rsp),%rcx
  81e9e4:	movups (%rcx),%xmm0
  81e9e7:	movups %xmm0,0x30(%rsi)
  81e9eb:	movups 0x40(%rax),%xmm0
  81e9ef:	movups %xmm0,0x50(%rsi)
  81e9f3:	lea    0x240(%rsp),%rdi
  81e9fb:	lea    0x130(%rsp),%rsi
  81ea03:	mov    %r14d,%ecx
  81ea06:	mov    %r15d,%r8d
  81ea09:	call   821640 <gpui_gpu::renderer::validate_draw>
  81ea0e:	mov    0x240(%rsp),%ecx
  81ea15:	mov    0x244(%rsp),%rax
  81ea1d:	cmp    $0xffffffff,%ecx
  81ea20:	jne    81f332 <<gpui_gpu::renderer::RendererState>::render+0x1312>
  81ea26:	mov    %eax,%ecx
  81ea28:	shr    $0x20,%rax
  81ea2c:	movd   %ecx,%xmm0
  81ea30:	movaps 0x70(%rsp),%xmm2
  81ea35:	movaps %xmm2,%xmm1
  81ea38:	maxss  %xmm0,%xmm1
  81ea3c:	movaps %xmm1,%xmm3
  81ea3f:	cmpunordss %xmm1,%xmm3
  81ea44:	movaps %xmm3,%xmm0
  81ea47:	andnps %xmm1,%xmm0
  81ea4a:	andps  %xmm2,%xmm3
  81ea4d:	orps   %xmm0,%xmm3
  81ea50:	movaps %xmm3,0xc0(%rsp)
  81ea58:	movd   %eax,%xmm0
  81ea5c:	movaps 0x40(%rsp),%xmm2
  81ea61:	movaps %xmm2,%xmm1
  81ea64:	maxss  %xmm0,%xmm1
  81ea68:	movaps %xmm1,%xmm3
  81ea6b:	cmpunordss %xmm1,%xmm3
  81ea70:	movaps %xmm3,%xmm0
  81ea73:	andnps %xmm1,%xmm0
  81ea76:	andps  %xmm2,%xmm3
  81ea79:	orps   %xmm0,%xmm3
  81ea7c:	movaps %xmm3,0xb0(%rsp)
  81ea84:	lea    0x3a0(%rsp),%rdi
  81ea8c:	lea    0x490(%rsp),%rsi
  81ea94:	call   821c80 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea99:	cmpb   $0xff,0x3a8(%rsp)
  81eaa1:	movdqa 0xc0(%rsp),%xmm1
  81eaaa:	movdqa %xmm1,0x70(%rsp)
  81eab0:	movdqa 0xb0(%rsp),%xmm2
  81eab9:	movdqa %xmm2,0x40(%rsp)
  81eabf:	jne    81e957 <<gpui_gpu::renderer::RendererState>::render+0x937>
  81eac5:	movdqa %xmm1,%xmm0
  81eac9:	movd   %xmm0,%ecx
  81eacd:	movd   %xmm2,%eax
  81ead1:	shl    $0x20,%rax
  81ead5:	or     %rax,%rcx
  81ead8:	mov    %rcx,0xf8(%rsp)
  81eae0:	jmp    81eafc <<gpui_gpu::renderer::RendererState>::render+0xadc>
  81eae2:	movq   $0x0,0xf8(%rsp)
  81eaee:	jmp    81eb14 <<gpui_gpu::renderer::RendererState>::render+0xaf4>
  81eaf0:	movq   $0x0,0xf8(%rsp)
  81eafc:	incq   0x2a8(%rsp)
  81eb04:	mov    0xe0(%rsp),%rax
  81eb0c:	add    %rax,0x2b0(%rsp)
  81eb14:	mov    0xa8(%rsp),%rax
  81eb1c:	mov    %rax,0x240(%rsp)
  81eb24:	mov    %rbx,0x248(%rsp)
  81eb2c:	mov    0x28(%rsp),%rax
  81eb31:	mov    %rax,0x250(%rsp)
  81eb39:	movq   $0x0,0x258(%rsp)
  81eb45:	lea    0x3a0(%rsp),%rdi
  81eb4d:	lea    0x240(%rsp),%rsi
  81eb55:	call   821c80 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81eb5a:	movzbl 0x3a8(%rsp),%eax
  81eb62:	cmp    $0xff,%al
  81eb64:	je     81f228 <<gpui_gpu::renderer::RendererState>::render+0x1208>
  81eb6a:	mov    %eax,%r8d
  81eb6d:	mov    0x10(%rsp),%rax
  81eb72:	lea    0x8(,%rax,8),%rax
  81eb7a:	mov    %rax,0x128(%rsp)
  81eb82:	mov    0x20(%rsp),%rax
  81eb87:	mov    %rax,0x80(%rsp)
  81eb8f:	mov    0x3a0(%rsp),%rax
  81eb97:	movups 0x3e0(%rsp),%xmm3
  81eb9f:	lea    0x3a8(%rsp),%rsi
  81eba7:	movups 0x48(%rsi),%xmm0
  81ebab:	lea    0x518(%rsp),%rdi
  81ebb3:	movups %xmm0,0x40(%rdi)
  81ebb7:	mov    0x1(%rsi),%ecx
  81ebba:	mov    0x4(%rsi),%edx
  81ebbd:	mov    %edx,-0x44(%rdi)
  81ebc0:	mov    %ecx,-0x47(%rdi)
  81ebc3:	mov    0x3b0(%rsp),%rdx
  81ebcb:	mov    0x30(%rsi),%rcx
  81ebcf:	mov    %rcx,-0x18(%rdi)
  81ebd3:	movups 0x10(%rsi),%xmm0
  81ebd7:	movups 0x20(%rsi),%xmm1
  81ebdb:	movups %xmm1,-0x28(%rdi)
  81ebdf:	movups %xmm0,-0x38(%rdi)
  81ebe3:	movaps 0x270(%rsp),%xmm0
  81ebeb:	movaps 0x280(%rsp),%xmm1
  81ebf3:	movaps 0x290(%rsp),%xmm2
  81ebfb:	movups %xmm2,0x20(%rdi)
  81ebff:	movups %xmm1,0x10(%rdi)
  81ec03:	movups %xmm0,(%rdi)
  81ec06:	movaps 0x330(%rsp),%xmm0
  81ec0e:	movups %xmm0,0x30(%rdi)
  81ec12:	movaps 0x320(%rsp),%xmm0
  81ec1a:	movups %xmm0,0x50(%rdi)
  81ec1e:	movaps %xmm3,0xc0(%rsp)
  81ec26:	movups %xmm3,0x508(%rsp)
  81ec2e:	mov    %r8b,0x70(%rsp)
  81ec33:	mov    %r8b,0x4d0(%rsp)
  81ec3b:	mov    %rdx,0x310(%rsp)
  81ec43:	mov    %rdx,0x4d8(%rsp)
  81ec4b:	cmpb   $0x0,0x1f(%rsp)
  81ec50:	je     81ec98 <<gpui_gpu::renderer::RendererState>::render+0xc78>
  81ec52:	mov    0xf8(%rsp),%rcx
  81ec5a:	mov    %rcx,0x40(%rsp)
  81ec5f:	mov    0x20(%rsp),%rcx
  81ec64:	mov    %rcx,0xb0(%rsp)
  81ec6c:	test   %rax,%rax
  81ec6f:	je     81ece8 <<gpui_gpu::renderer::RendererState>::render+0xcc8>
  81ec71:	mov    0xf8(%rsp),%rax
  81ec79:	mov    %rax,0x40(%rsp)
  81ec7e:	mov    0x20(%rsp),%rax
  81ec83:	mov    %rax,0xb0(%rsp)
  81ec8b:	lea    0x130(%rsp),%rbx
  81ec93:	jmp    81f000 <<gpui_gpu::renderer::RendererState>::render+0xfe0>
  81ec98:	lea    0x130(%rsp),%rdi
  81eca0:	lea    0x4d0(%rsp),%rsi
  81eca8:	mov    0x88(%rsp),%rdx
  81ecb0:	mov    %r14d,%ecx
  81ecb3:	mov    %r15d,%r8d
  81ecb6:	call   821640 <gpui_gpu::renderer::validate_draw>
  81ecbb:	mov    0x130(%rsp),%eax
  81ecc2:	mov    0x134(%rsp),%rcx
  81ecca:	mov    %rcx,0x40(%rsp)
  81eccf:	cmp    $0xffffffff,%eax
  81ecd2:	jne    81f3c0 <<gpui_gpu::renderer::RendererState>::render+0x13a0>
  81ecd8:	mov    0x80(%rsp),%rax
  81ece0:	mov    %rax,0xb0(%rsp)
  81ece8:	cmpb   $0x3,0x70(%rsp)
  81eced:	jne    81ed82 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ecf3:	movss  0x4d4(%rsp),%xmm0
  81ecfc:	xorps  %xmm1,%xmm1
  81ecff:	ucomiss %xmm1,%xmm0
  81ed02:	jne    81ed06 <<gpui_gpu::renderer::RendererState>::render+0xce6>
  81ed04:	jnp    81ed82 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed06:	movaps 0xc0(%rsp),%xmm5
  81ed0e:	movaps %xmm5,%xmm1
  81ed11:	unpckhpd %xmm5,%xmm1
  81ed15:	movss  -0x76fd51(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ed1d:	mulss  %xmm4,%xmm1
  81ed21:	movaps %xmm0,%xmm2
  81ed24:	minss  %xmm1,%xmm2
  81ed28:	movaps %xmm2,%xmm1
  81ed2b:	cmpunordss %xmm2,%xmm1
  81ed30:	movaps %xmm1,%xmm3
  81ed33:	andnps %xmm2,%xmm3
  81ed36:	andps  %xmm0,%xmm1
  81ed39:	orps   %xmm3,%xmm1
  81ed3c:	movaps %xmm5,%xmm0
  81ed3f:	shufps $0xff,%xmm5,%xmm0
  81ed43:	mulss  %xmm4,%xmm0
  81ed47:	movaps %xmm1,%xmm2
  81ed4a:	minss  %xmm0,%xmm2
  81ed4e:	movaps %xmm2,%xmm0
  81ed51:	cmpunordss %xmm2,%xmm0
  81ed56:	andps  %xmm0,%xmm1
  81ed59:	andnps %xmm2,%xmm0
  81ed5c:	orps   %xmm1,%xmm0
  81ed5f:	movd   %xmm0,%eax
  81ed63:	mov    %eax,0x260(%rsp)
  81ed6a:	and    $0xff800000,%eax
  81ed6f:	mov    $0x7f000000,%ecx
  81ed74:	sub    %eax,%ecx
  81ed76:	mov    %ecx,0xd8(%rsp)
  81ed7d:	xorps  %xmm0,%xmm0
  81ed80:	jmp    81eda7 <<gpui_gpu::renderer::RendererState>::render+0xd87>
  81ed82:	mov    0x568(%rsp),%eax
  81ed89:	mov    %eax,0x260(%rsp)
  81ed90:	mov    0x56c(%rsp),%eax
  81ed97:	mov    %eax,0xd8(%rsp)
  81ed9e:	movsd  0x570(%rsp),%xmm0
  81eda7:	movaps %xmm0,0x300(%rsp)
  81edaf:	movups 0x518(%rsp),%xmm0
  81edb7:	movaps %xmm0,0x470(%rsp)
  81edbf:	movups 0x520(%rsp),%xmm0
  81edc7:	movaps %xmm0,0x390(%rsp)
  81edcf:	movsd  0x528(%rsp),%xmm0
  81edd8:	movaps %xmm0,0x220(%rsp)
  81ede0:	movsd  0x530(%rsp),%xmm0
  81ede9:	movaps %xmm0,0x2f0(%rsp)
  81edf1:	movsd  0x538(%rsp),%xmm0
  81edfa:	movsd  %xmm0,0x98(%rsp)
  81ee03:	movsd  0x540(%rsp),%xmm0
  81ee0c:	movsd  %xmm0,0x2c8(%rsp)
  81ee15:	movups 0x548(%rsp),%xmm0
  81ee1d:	movaps %xmm0,0x480(%rsp)
  81ee25:	mov    0x28(%rsp),%rax
  81ee2a:	mov    %rax,0x130(%rsp)
  81ee32:	mov    0xa8(%rsp),%rax
  81ee3a:	mov    %rax,0x138(%rsp)
  81ee42:	mov    0xe0(%rsp),%rax
  81ee4a:	mov    %rax,0x140(%rsp)
  81ee52:	movaps 0x270(%rsp),%xmm0
  81ee5a:	movaps 0x280(%rsp),%xmm1
  81ee62:	movaps 0x290(%rsp),%xmm2
  81ee6a:	lea    0x148(%rsp),%rcx
  81ee72:	movups %xmm2,0x20(%rcx)
  81ee76:	movups %xmm1,0x10(%rcx)
  81ee7a:	movups %xmm0,(%rcx)
  81ee7d:	movaps 0x330(%rsp),%xmm0
  81ee85:	lea    0x178(%rsp),%rax
  81ee8d:	movups %xmm0,(%rax)
  81ee90:	movaps 0x320(%rsp),%xmm0
  81ee98:	movups %xmm0,0x40(%rcx)
  81ee9c:	lea    0x130(%rsp),%rdi
  81eea4:	call   *0x66124e(%rip)        # e800f8 <_DYNAMIC+0x5c0>
  81eeaa:	test   %eax,%eax
  81eeac:	je     81eeda <<gpui_gpu::renderer::RendererState>::render+0xeba>
  81eeae:	mov    0x2c0(%rsp),%rdi
  81eeb6:	mov    %eax,%esi
  81eeb8:	call   825890 <gpui_gpu::renderer::slots::color_word>
  81eebd:	mov    %eax,0x260(%rsp)
  81eec4:	xorps  %xmm0,%xmm0
  81eec7:	movaps %xmm0,0x300(%rsp)
  81eecf:	movl   $0x0,0xd8(%rsp)
  81eeda:	movsd  0x2c8(%rsp),%xmm0
  81eee3:	cvtsd2ss %xmm0,%xmm0
  81eee7:	movapd 0x390(%rsp),%xmm1
  81eef0:	unpcklpd 0x2f0(%rsp),%xmm1
  81eef9:	cvtpd2ps %xmm1,%xmm1
  81eefd:	movsd  0x98(%rsp),%xmm2
  81ef06:	cvtsd2ss %xmm2,%xmm2
  81ef0a:	movapd 0x470(%rsp),%xmm3
  81ef13:	unpcklpd 0x220(%rsp),%xmm3
  81ef1c:	cvtpd2ps %xmm3,%xmm3
  81ef20:	mov    0x40(%rsp),%rcx
  81ef25:	mov    %rcx,%rax
  81ef28:	shr    $0x20,%rax
  81ef2c:	mov    0x8(%rsp),%rdx
  81ef31:	mov    0x8(%rdx),%rsi
  81ef35:	mov    0x10(%rdx),%rdx
  81ef39:	movlpd %xmm3,0x130(%rsp)
  81ef42:	movss  %xmm2,0x138(%rsp)
  81ef4b:	mov    %ecx,0x13c(%rsp)
  81ef52:	movlpd %xmm1,0x140(%rsp)
  81ef5b:	movss  %xmm0,0x148(%rsp)
  81ef64:	mov    %eax,0x14c(%rsp)
  81ef6b:	lea    0x2d0(%rsp),%rdi
  81ef73:	mov    0x80(%rsp),%r13
  81ef7b:	mov    %r13,%rcx
  81ef7e:	lea    0x130(%rsp),%rbx
  81ef86:	mov    %rbx,%r8
  81ef89:	call   81b6a0 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81ef8e:	mov    0x8(%rsp),%rax
  81ef93:	mov    0x8(%rax),%rsi
  81ef97:	mov    0x10(%rax),%rdx
  81ef9b:	mov    0x110(%rsp),%rax
  81efa3:	lea    0x0(%r13,%rax,1),%rcx
  81efa8:	movaps 0x480(%rsp),%xmm0
  81efb0:	movaps %xmm0,0x130(%rsp)
  81efb8:	mov    0x260(%rsp),%eax
  81efbf:	mov    %eax,0x140(%rsp)
  81efc6:	mov    0xd8(%rsp),%eax
  81efcd:	mov    %eax,0x144(%rsp)
  81efd4:	movaps 0x300(%rsp),%xmm0
  81efdc:	movlps %xmm0,0x148(%rsp)
  81efe4:	lea    0x2d0(%rsp),%rdi
  81efec:	mov    %rbx,%r8
  81efef:	call   81b6a0 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81eff4:	add    $0x2,%r13
  81eff8:	mov    %r13,0x80(%rsp)
  81f000:	cmpb   $0x2,0x70(%rsp)
  81f005:	sete   0x260(%rsp)
  81f00d:	cmpq   $0x0,0x310(%rsp)
  81f016:	setne  0x310(%rsp)
  81f01e:	mov    0x28(%rsp),%rax
  81f023:	mov    %rax,0x130(%rsp)
  81f02b:	mov    0xa8(%rsp),%rax
  81f033:	mov    %rax,0x138(%rsp)
  81f03b:	mov    0xe0(%rsp),%rax
  81f043:	mov    %rax,0x140(%rsp)
  81f04b:	movaps 0x270(%rsp),%xmm0
  81f053:	movdqa 0x280(%rsp),%xmm1
  81f05c:	movdqa 0x290(%rsp),%xmm2
  81f065:	lea    0x148(%rsp),%rcx
  81f06d:	movdqu %xmm2,0x20(%rcx)
  81f072:	movdqu %xmm1,0x10(%rcx)
  81f077:	movups %xmm0,(%rcx)
  81f07a:	movaps 0x330(%rsp),%xmm0
  81f082:	lea    0x178(%rsp),%rax
  81f08a:	movups %xmm0,(%rax)
  81f08d:	movaps 0x320(%rsp),%xmm0
  81f095:	movups %xmm0,0x40(%rcx)
  81f099:	mov    %rbx,%rdi
  81f09c:	call   *0x661056(%rip)        # e800f8 <_DYNAMIC+0x5c0>
  81f0a2:	mov    %eax,0x70(%rsp)
  81f0a6:	mov    0x8(%rsp),%r13
  81f0ab:	mov    0x8(%r13),%rsi
  81f0af:	mov    0x10(%r13),%rdx
  81f0b3:	movdqa 0xc0(%rsp),%xmm0
  81f0bc:	movdqa %xmm0,0x130(%rsp)
  81f0c5:	lea    0x230(%rsp),%rdi
  81f0cd:	mov    %rbx,%r8
  81f0d0:	mov    0x10(%rsp),%rbx
  81f0d5:	mov    %rbx,%rcx
  81f0d8:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f0dd:	lea    0x1(%rbx),%rcx
  81f0e1:	mov    0x10(%r13),%rdx
  81f0e5:	cmp    %rdx,%rcx
  81f0e8:	jae    8203d2 <<gpui_gpu::renderer::RendererState>::render+0x23b2>
  81f0ee:	mov    0xb0(%rsp),%rsi
  81f0f6:	mov    %esi,%edi
  81f0f8:	or     $0x80000000,%edi
  81f0fe:	cmpl   $0x0,0x70(%rsp)
  81f103:	cmove  %esi,%edi
  81f106:	mov    0x8(%r13),%rsi
  81f10a:	mov    0x128(%rsp),%r13
  81f112:	mov    0x8(%rsi,%r13,2),%r8d
  81f117:	mov    %r8d,0x138(%rsp)
  81f11f:	mov    (%rsi,%r13,2),%r8
  81f123:	mov    %r8,0x130(%rsp)
  81f12b:	mov    %edi,0x13c(%rsp)
  81f132:	lea    0x230(%rsp),%rdi
  81f13a:	lea    0x130(%rsp),%r8
  81f142:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f147:	lea    0x130(%rsp),%rdi
  81f14f:	mov    0x8(%rsp),%rsi
  81f154:	lea    0x4d0(%rsp),%rdx
  81f15c:	mov    0x40(%rsp),%rcx
  81f161:	mov    %rbx,0x10(%rsp)
  81f166:	mov    %ebx,%r8d
  81f169:	mov    0x88(%rsp),%rbx
  81f171:	mov    %rbx,%r9
  81f174:	push   0x118(%rsp)
  81f17b:	push   %r15
  81f17d:	push   %r14
  81f17f:	push   0xa8(%rsp)
  81f186:	call   820450 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f18b:	add    $0x20,%rsp
  81f18f:	mov    0x130(%rsp),%eax
  81f196:	cmp    $0xffffffff,%eax
  81f199:	jne    81f390 <<gpui_gpu::renderer::RendererState>::render+0x1370>
  81f19f:	movzbl 0x260(%rsp),%ecx
  81f1a7:	and    0x310(%rsp),%cl
  81f1ae:	mov    0x68(%rsp),%rax
  81f1b3:	or     %cl,%al
  81f1b5:	mov    %rax,0x68(%rsp)
  81f1ba:	addq   $0x2,0x10(%rsp)
  81f1c0:	mov    0x138(%rsp),%rax
  81f1c8:	mov    %rax,0x118(%rsp)
  81f1d0:	inc    %rbx
  81f1d3:	mov    %rbx,0x88(%rsp)
  81f1db:	lea    0x3a0(%rsp),%rdi
  81f1e3:	lea    0x240(%rsp),%rsi
  81f1eb:	call   821c80 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81f1f0:	movzbl 0x3a8(%rsp),%r8d
  81f1f9:	add    $0x10,%r13
  81f1fd:	mov    %r13,0x128(%rsp)
  81f205:	cmp    $0xff,%r8b
  81f209:	jne    81eb8f <<gpui_gpu::renderer::RendererState>::render+0xb6f>
  81f20f:	mov    0x68(%rsp),%rax
  81f214:	and    $0x1,%al
  81f216:	mov    %rax,0x68(%rsp)
  81f21b:	mov    0x80(%rsp),%rax
  81f223:	mov    %rax,0x20(%rsp)
  81f228:	lea    0x408(%rsp),%rdi
  81f230:	lea    0x368(%rsp),%rsi
  81f238:	call   *0x660eb2(%rip)        # e800f0 <_DYNAMIC+0x5b8>
  81f23e:	mov    0x408(%rsp),%rax
  81f246:	mov    %rax,0x28(%rsp)
  81f24b:	test   %rax,%rax
  81f24e:	jne    81e809 <<gpui_gpu::renderer::RendererState>::render+0x7e9>
  81f254:	jmp    81f28f <<gpui_gpu::renderer::RendererState>::render+0x126f>
  81f256:	movq   $0x0,0x2b0(%rsp)
  81f262:	movq   $0x0,0x2a8(%rsp)
  81f26e:	movq   $0x0,0x88(%rsp)
  81f27a:	movq   $0x0,0x68(%rsp)
  81f283:	movq   $0x0,0x118(%rsp)
  81f28f:	mov    0xa0(%rsp),%rsi
  81f297:	lea    0x8(%rsi),%rdx
  81f29b:	mov    0x8(%rsp),%rax
  81f2a0:	lea    0x258(%rax),%rcx
  81f2a7:	lea    0x328(%rax),%r8
  81f2ae:	mov    0x10(%rax),%r9
  81f2b2:	sub    $0x8,%rsp
  81f2b6:	lea    0x138(%rsp),%rdi
  81f2be:	mov    %rdx,0x2f8(%rsp)
  81f2c6:	mov    %rcx,0xa0(%rsp)
  81f2ce:	mov    %r8,0x488(%rsp)
  81f2d6:	push   0x128(%rsp)
  81f2dd:	call   8239e0 <gpui_gpu::renderer::images::prepare>
  81f2e2:	add    $0x10,%rsp
  81f2e6:	mov    0x130(%rsp),%eax
  81f2ed:	movzbl 0x134(%rsp),%ecx
  81f2f5:	mov    %cl,0x390(%rsp)
  81f2fc:	cmp    $0xffffffff,%eax
  81f2ff:	je     81f358 <<gpui_gpu::renderer::RendererState>::render+0x1338>
  81f301:	movupd 0x135(%rsp),%xmm0
  81f30a:	movups 0x140(%rsp),%xmm1
  81f312:	mov    0x50(%rsp),%rdi
  81f317:	movups %xmm1,0x10(%rdi)
  81f31b:	movupd %xmm0,0x5(%rdi)
  81f320:	mov    %eax,(%rdi)
  81f322:	movzbl 0x390(%rsp),%eax
  81f32a:	mov    %al,0x4(%rdi)
  81f32d:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f332:	mov    0x25c(%rsp),%edx
  81f339:	mov    0x50(%rsp),%rdi
  81f33e:	mov    %edx,0x1c(%rdi)
  81f341:	movups 0x24c(%rsp),%xmm0
  81f349:	movups %xmm0,0xc(%rdi)
  81f34d:	mov    %ecx,(%rdi)
  81f34f:	mov    %rax,0x4(%rdi)
  81f353:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f358:	movzbl 0x68(%rsp),%r8d
  81f35e:	and    $0x1,%r8d
  81f362:	lea    0x130(%rsp),%rdi
  81f36a:	mov    0x8(%rsp),%rsi
  81f36f:	mov    0xa0(%rsp),%rdx
  81f377:	mov    0x100(%rsp),%rcx
  81f37f:	call   81d780 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f384:	mov    0x130(%rsp),%eax
  81f38b:	cmp    $0xffffffff,%eax
  81f38e:	je     81f3eb <<gpui_gpu::renderer::RendererState>::render+0x13cb>
  81f390:	mov    0x134(%rsp),%ecx
  81f397:	mov    0x138(%rsp),%rdx
  81f39f:	movupd 0x140(%rsp),%xmm0
  81f3a8:	mov    0x50(%rsp),%rdi
  81f3ad:	movupd %xmm0,0x10(%rdi)
  81f3b2:	mov    %eax,(%rdi)
  81f3b4:	mov    %ecx,0x4(%rdi)
  81f3b7:	mov    %rdx,0x8(%rdi)
  81f3bb:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3c0:	mov    0x14c(%rsp),%ecx
  81f3c7:	mov    0x50(%rsp),%rdi
  81f3cc:	mov    %ecx,0x1c(%rdi)
  81f3cf:	movups 0x13c(%rsp),%xmm0
  81f3d7:	movups %xmm0,0xc(%rdi)
  81f3db:	mov    %eax,(%rdi)
  81f3dd:	mov    0x40(%rsp),%rax
  81f3e2:	mov    %rax,0x4(%rdi)
  81f3e6:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3eb:	mov    0x138(%rsp),%rax
  81f3f3:	mov    %rax,0x2c8(%rsp)
  81f3fb:	mov    0x8(%rsp),%rax
  81f400:	mov    0x28(%rax),%rax
  81f404:	movq   $0x0,0x220(%rsp)
  81f410:	test   %rax,%rax
  81f413:	je     81f4b8 <<gpui_gpu::renderer::RendererState>::render+0x1498>
  81f419:	mov    0x8(%rsp),%rcx
  81f41e:	mov    0x20(%rcx),%rcx
  81f422:	shl    $0x3,%rax
  81f426:	xor    %edi,%edi
  81f428:	jmp    81f469 <<gpui_gpu::renderer::RendererState>::render+0x1449>
  81f42a:	and    $0x40000000,%edx
  81f430:	mov    0x220(%rsp),%r9
  81f438:	add    %esi,%r9d
  81f43b:	xor    %esi,%esi
  81f43d:	test   %r8d,%r8d
  81f440:	setne  %sil
  81f444:	shl    $0x1d,%esi
  81f447:	or     %r9d,%edx
  81f44a:	or     %esi,%edx
  81f44c:	mov    %r9,0x220(%rsp)
  81f454:	mov    %r9d,(%rcx,%rdi,8)
  81f458:	mov    %edx,%r9d
  81f45b:	mov    %r9d,0x4(%rcx,%rdi,8)
  81f460:	inc    %rdi
  81f463:	add    $0xfffffffffffffff8,%rax
  81f467:	je     81f4a6 <<gpui_gpu::renderer::RendererState>::render+0x1486>
  81f469:	mov    0x8(%rsp),%rdx
  81f46e:	mov    0x58(%rdx),%rsi
  81f472:	cmp    %rsi,%rdi
  81f475:	jae    8203e8 <<gpui_gpu::renderer::RendererState>::render+0x23c8>
  81f47b:	mov    0x4(%rcx,%rdi,8),%edx
  81f47f:	mov    %edx,%esi
  81f481:	and    $0xbfffffff,%esi
  81f487:	mov    0x8(%rsp),%r8
  81f48c:	mov    0x50(%r8),%r8
  81f490:	mov    (%r8,%rdi,4),%r8d
  81f494:	cmp    $0x1,%esi
  81f497:	jne    81f42a <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f499:	mov    $0x80000000,%r9d
  81f49f:	test   %r8d,%r8d
  81f4a2:	jne    81f45b <<gpui_gpu::renderer::RendererState>::render+0x143b>
  81f4a4:	jmp    81f42a <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f4a6:	mov    0x220(%rsp),%rax
  81f4ae:	mov    %eax,%eax
  81f4b0:	mov    %rax,0x220(%rsp)
  81f4b8:	mov    0x8(%rsp),%rax
  81f4bd:	lea    0x30(%rax),%rdi
  81f4c1:	movq   $0x0,0x40(%rax)
  81f4c9:	mov    %rdi,0xd8(%rsp)
  81f4d1:	mov    0x220(%rsp),%rsi
  81f4d9:	xor    %edx,%edx
  81f4db:	call   823890 <<alloc::vec::Vec<u32>>::resize>
  81f4e0:	mov    0x88(%rsp),%rax
  81f4e8:	mov    %rax,0x360(%rsp)
  81f4f0:	mov    0x100(%rsp),%rax
  81f4f8:	mov    %rax,0x368(%rsp)
  81f500:	movq   $0x0,0x370(%rsp)
  81f50c:	mov    0x108(%rsp),%rax
  81f514:	mov    %rax,0x378(%rsp)
  81f51c:	mov    0x340(%rsp),%rax
  81f524:	mov    %rax,0x380(%rsp)
  81f52c:	mov    0x30(%rsp),%eax
  81f530:	mov    %eax,0x388(%rsp)
  81f537:	lea    0x408(%rsp),%rdi
  81f53f:	lea    0x368(%rsp),%rsi
  81f547:	call   *0x660bb3(%rip)        # e80100 <_DYNAMIC+0x5c8>
  81f54d:	mov    0x408(%rsp),%rax
  81f555:	mov    %rax,0x80(%rsp)
  81f55d:	test   %rax,%rax
  81f560:	je     81fae8 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f566:	mov    0x8(%rsp),%rax
  81f56b:	add    $0x120,%rax
  81f571:	mov    %rax,0x470(%rsp)
  81f579:	mov    0x2b8(%rsp),%rax
  81f581:	mov    %rax,0xb0(%rsp)
  81f589:	jmp    81f5ba <<gpui_gpu::renderer::RendererState>::render+0x159a>
  81f58b:	lea    0x408(%rsp),%rdi
  81f593:	lea    0x368(%rsp),%rsi
  81f59b:	call   *0x660b5f(%rip)        # e80100 <_DYNAMIC+0x5c8>
  81f5a1:	mov    0x408(%rsp),%rax
  81f5a9:	mov    %rax,0x80(%rsp)
  81f5b1:	test   %rax,%rax
  81f5b4:	je     81fae8 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f5ba:	lea    0x420(%rsp),%rsi
  81f5c2:	movups (%rsi),%xmm0
  81f5c5:	movups 0x10(%rsi),%xmm1
  81f5c9:	movups 0x20(%rsi),%xmm2
  81f5cd:	movaps %xmm2,0x3c0(%rsp)
  81f5d5:	movaps %xmm1,0x3b0(%rsp)
  81f5dd:	movaps %xmm0,0x3a0(%rsp)
  81f5e5:	lea    0x450(%rsp),%rdx
  81f5ed:	movups (%rdx),%xmm0
  81f5f0:	movaps %xmm0,0x320(%rsp)
  81f5f8:	movdqu 0x40(%rsi),%xmm0
  81f5fd:	movdqa %xmm0,0x330(%rsp)
  81f606:	mov    0x410(%rsp),%rax
  81f60e:	mov    %rax,0xe0(%rsp)
  81f616:	mov    0x418(%rsp),%rbx
  81f61e:	mov    0x8(%rsp),%rdi
  81f623:	call   81d3a0 <<gpui_gpu::renderer::RendererState>::correction>
  81f628:	mov    %eax,0x300(%rsp)
  81f62f:	test   %rbx,%rbx
  81f632:	je     81f58b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f638:	mov    %rbx,%rcx
  81f63b:	shl    $0x2,%rcx
  81f63f:	mov    0x300(%rsp),%eax
  81f646:	shl    $0xf,%eax
  81f649:	mov    %eax,0x20(%rsp)
  81f64d:	mov    0xb0(%rsp),%rax
  81f655:	shl    $0x4,%rax
  81f659:	mov    %rax,0x28(%rsp)
  81f65e:	lea    0x138(%rsp),%rbx
  81f666:	lea    0x130(%rsp),%r13
  81f66e:	jmp    81f837 <<gpui_gpu::renderer::RendererState>::render+0x1817>
  81f673:	mov    0x60(%rsp),%r9d
  81f678:	or     0x20(%rsp),%r9d
  81f67d:	mov    %r9d,0x60(%rsp)
  81f682:	mov    0x64(%rsp),%r8d
  81f687:	mov    %edi,0x130(%rsp)
  81f68e:	mov    %r9d,0x134(%rsp)
  81f696:	mov    %r8d,0x138(%rsp)
  81f69e:	mov    %eax,0x13c(%rsp)
  81f6a5:	lea    0x230(%rsp),%rdi
  81f6ad:	mov    %rbx,%r8
  81f6b0:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f6b5:	add    $0xfffffffffffffffe,%r13
  81f6b9:	mov    %r13,0xb0(%rsp)
  81f6c1:	mov    %r13d,0x2ec(%rsp)
  81f6c9:	movaps 0x260(%rsp),%xmm0
  81f6d1:	movlps %xmm0,0x170(%rsp)
  81f6d9:	movaps 0x3a0(%rsp),%xmm0
  81f6e1:	movaps 0x3b0(%rsp),%xmm1
  81f6e9:	movaps 0x3c0(%rsp),%xmm2
  81f6f1:	lea    0x178(%rsp),%rax
  81f6f9:	movups %xmm2,0x20(%rax)
  81f6fd:	movups %xmm1,0x10(%rax)
  81f701:	movups %xmm0,(%rax)
  81f704:	movaps 0x320(%rsp),%xmm0
  81f70c:	movups %xmm0,0x30(%rax)
  81f710:	movaps 0x490(%rsp),%xmm0
  81f718:	movups %xmm0,0x40(%rax)
  81f71c:	movaps 0x330(%rsp),%xmm0
  81f724:	movups %xmm0,0x50(%rax)
  81f728:	mov    0x128(%rsp),%eax
  81f72f:	mov    %al,0x130(%rsp)
  81f736:	movzbl 0x30(%rsp),%eax
  81f73b:	mov    %al,0x131(%rsp)
  81f742:	movzwl 0xa8(%rsp),%eax
  81f74a:	mov    %ax,0x132(%rsp)
  81f752:	movaps 0xc0(%rsp),%xmm0
  81f75a:	movss  %xmm0,0x134(%rsp)
  81f763:	mov    0x250(%rsp),%rax
  81f76b:	mov    %rbx,%r13
  81f76e:	lea    0x138(%rsp),%rbx
  81f776:	mov    %rax,0x10(%rbx)
  81f77a:	movaps 0x240(%rsp),%xmm0
  81f782:	movups %xmm0,(%rbx)
  81f785:	mov    0x10(%rsp),%rax
  81f78a:	mov    %rax,0x150(%rsp)
  81f792:	mov    0x40(%rsp),%eax
  81f796:	mov    %eax,0x158(%rsp)
  81f79d:	mov    0x70(%rsp),%eax
  81f7a1:	mov    %eax,0x15c(%rsp)
  81f7a8:	movdqa 0x310(%rsp),%xmm0
  81f7b1:	movdqu %xmm0,0x160(%rsp)
  81f7ba:	mov    0x4c8(%rsp),%rax
  81f7c2:	mov    %rax,0x270(%rsp)
  81f7ca:	mov    0xd8(%rsp),%rax
  81f7d2:	mov    %rax,0x278(%rsp)
  81f7da:	mov    0x4c0(%rsp),%rax
  81f7e2:	mov    %rax,0x280(%rsp)
  81f7ea:	lea    0x360(%rsp),%rax
  81f7f2:	mov    %rax,0x288(%rsp)
  81f7fa:	lea    0x2ec(%rsp),%rax
  81f802:	mov    %rax,0x290(%rsp)
  81f80a:	mov    %r13,%rdi
  81f80d:	mov    0x90(%rsp),%rsi
  81f815:	lea    0x270(%rsp),%rdx
  81f81d:	call   81c4d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f822:	addq   $0xffffffffffffffe0,0x28(%rsp)
  81f828:	mov    0x68(%rsp),%rcx
  81f82d:	add    $0xfffffffffffffffc,%rcx
  81f831:	je     81f58b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f837:	mov    0xe0(%rsp),%rax
  81f83f:	mov    %rcx,0x68(%rsp)
  81f844:	mov    -0x4(%rax,%rcx,1),%edx
  81f848:	mov    %r13,%rdi
  81f84b:	mov    0x80(%rsp),%rsi
  81f853:	call   81c830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f858:	movzbl 0x130(%rsp),%ecx
  81f860:	movzbl 0x131(%rsp),%eax
  81f868:	mov    %al,0x30(%rsp)
  81f86c:	movzwl 0x132(%rsp),%eax
  81f874:	mov    %ax,0xa8(%rsp)
  81f87c:	movss  0x134(%rsp),%xmm4
  81f885:	mov    0x10(%rbx),%rax
  81f889:	mov    %rax,0x250(%rsp)
  81f891:	movups (%rbx),%xmm0
  81f894:	movaps %xmm0,0x240(%rsp)
  81f89c:	mov    0x150(%rsp),%rax
  81f8a4:	mov    %rax,0x10(%rsp)
  81f8a9:	mov    0x158(%rsp),%eax
  81f8b0:	mov    %eax,0x40(%rsp)
  81f8b4:	mov    0x15c(%rsp),%eax
  81f8bb:	mov    %eax,0x70(%rsp)
  81f8bf:	movups 0x160(%rsp),%xmm0
  81f8c7:	movaps %xmm0,0x310(%rsp)
  81f8cf:	mov    0x160(%rsp),%rax
  81f8d7:	movsd  0x170(%rsp),%xmm5
  81f8e0:	lea    0x178(%rsp),%rdx
  81f8e8:	movups (%rdx),%xmm0
  81f8eb:	movaps %xmm0,0x490(%rsp)
  81f8f3:	decq   0x360(%rsp)
  81f8fb:	cmp    $0x1,%ecx
  81f8fe:	mov    %ecx,0x128(%rsp)
  81f905:	movaps %xmm4,0xc0(%rsp)
  81f90d:	movaps %xmm5,0x260(%rsp)
  81f915:	je     81f97b <<gpui_gpu::renderer::RendererState>::render+0x195b>
  81f917:	cmp    $0x3,%ecx
  81f91a:	jne    81f9f7 <<gpui_gpu::renderer::RendererState>::render+0x19d7>
  81f920:	mov    0x480(%rsp),%rax
  81f928:	mov    (%rax),%rdi
  81f92b:	test   %rdi,%rdi
  81f92e:	je     82039b <<gpui_gpu::renderer::RendererState>::render+0x237b>
  81f934:	movzbl 0x30(%rsp),%edx
  81f939:	mov    0x10(%rsp),%rsi
  81f93e:	call   823580 <<gpui_gpu::renderer::images::Images>::metadata>
  81f943:	mov    %eax,%ecx
  81f945:	shr    $0x20,%rax
  81f949:	mov    %eax,%edx
  81f94b:	or     $0x10,%edx
  81f94e:	xorps  %xmm0,%xmm0
  81f951:	movaps 0xc0(%rsp),%xmm1
  81f959:	ucomiss %xmm0,%xmm1
  81f95c:	cmovne %edx,%eax
  81f95f:	cmovp  %edx,%eax
  81f962:	mov    0x70(%rsp),%edx
  81f966:	shl    $0x10,%edx
  81f969:	or     0x40(%rsp),%edx
  81f96d:	mov    %ecx,0x5c(%rsp)
  81f971:	mov    %eax,0x60(%rsp)
  81f975:	mov    %edx,0x64(%rsp)
  81f979:	jmp    81f9ea <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  81f97b:	movaps %xmm5,%xmm0
  81f97e:	movss  -0x7709ba(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f986:	mulss  %xmm3,%xmm0
  81f98a:	movaps %xmm4,%xmm1
  81f98d:	minss  %xmm0,%xmm1
  81f991:	movaps %xmm1,%xmm0
  81f994:	cmpunordss %xmm1,%xmm0
  81f999:	movaps %xmm0,%xmm2
  81f99c:	andnps %xmm1,%xmm2
  81f99f:	andps  %xmm4,%xmm0
  81f9a2:	orps   %xmm2,%xmm0
  81f9a5:	movaps %xmm5,%xmm1
  81f9a8:	shufps $0x55,%xmm5,%xmm1
  81f9ac:	mulss  %xmm3,%xmm1
  81f9b0:	movaps %xmm0,%xmm2
  81f9b3:	minss  %xmm1,%xmm2
  81f9b7:	movaps %xmm2,%xmm1
  81f9ba:	cmpunordss %xmm2,%xmm1
  81f9bf:	andps  %xmm1,%xmm0
  81f9c2:	andnps %xmm2,%xmm1
  81f9c5:	orps   %xmm0,%xmm1
  81f9c8:	movd   %xmm1,%eax
  81f9cc:	and    $0xff800000,%eax
  81f9d1:	mov    $0x7f000000,%ecx
  81f9d6:	sub    %eax,%ecx
  81f9d8:	movl   $0x40000000,0x5c(%rsp)
  81f9e0:	movss  %xmm1,0x60(%rsp)
  81f9e6:	mov    %ecx,0x64(%rsp)
  81f9ea:	lea    0x130(%rsp),%rbx
  81f9f2:	jmp    81fa91 <<gpui_gpu::renderer::RendererState>::render+0x1a71>
  81f9f7:	cmp    $0x2,%cl
  81f9fa:	jne    81fa49 <<gpui_gpu::renderer::RendererState>::render+0x1a29>
  81f9fc:	mov    0x250(%rsp),%rcx
  81fa04:	mov    %rcx,0x140(%rsp)
  81fa0c:	movaps 0x240(%rsp),%xmm0
  81fa14:	movaps %xmm0,0x130(%rsp)
  81fa1c:	mov    0x10(%rsp),%rcx
  81fa21:	mov    %rcx,0x148(%rsp)
  81fa29:	mov    0x40(%rsp),%ecx
  81fa2d:	mov    %ecx,0x150(%rsp)
  81fa34:	mov    0x70(%rsp),%ecx
  81fa38:	mov    %ecx,0x154(%rsp)
  81fa3f:	mov    %rax,0x158(%rsp)
  81fa47:	jmp    81fa55 <<gpui_gpu::renderer::RendererState>::render+0x1a35>
  81fa49:	movq   $0x0,0x130(%rsp)
  81fa55:	movl   $0x0,0x278(%rsp)
  81fa60:	movq   $0x0,0x270(%rsp)
  81fa6c:	lea    0x5c(%rsp),%rdi
  81fa71:	lea    0x130(%rsp),%rbx
  81fa79:	mov    %rbx,%rsi
  81fa7c:	lea    0x270(%rsp),%rdx
  81fa84:	mov    0x470(%rsp),%rcx
  81fa8c:	call   81b4e0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fa91:	mov    0xb0(%rsp),%r13
  81fa99:	lea    -0x1(%r13),%rcx
  81fa9d:	mov    0x8(%rsp),%rax
  81faa2:	mov    0x10(%rax),%rdx
  81faa6:	cmp    %rdx,%rcx
  81faa9:	jae    8203bc <<gpui_gpu::renderer::RendererState>::render+0x239c>
  81faaf:	mov    0x8(%rax),%rsi
  81fab3:	mov    0x28(%rsp),%rax
  81fab8:	mov    -0x4(%rsi,%rax,1),%eax
  81fabc:	mov    0x5c(%rsp),%edi
  81fac0:	cmp    $0x40000000,%edi
  81fac6:	jne    81f673 <<gpui_gpu::renderer::RendererState>::render+0x1653>
  81facc:	mov    0x64(%rsp),%r8d
  81fad1:	or     0x300(%rsp),%r8d
  81fad9:	mov    %r8d,0x64(%rsp)
  81fade:	mov    0x60(%rsp),%r9d
  81fae3:	jmp    81f687 <<gpui_gpu::renderer::RendererState>::render+0x1667>
  81fae8:	mov    0x8(%rsp),%rax
  81faed:	mov    0x28(%rax),%rdi
  81faf1:	xor    %ebx,%ebx
  81faf3:	test   %rdi,%rdi
  81faf6:	je     81fc05 <<gpui_gpu::renderer::RendererState>::render+0x1be5>
  81fafc:	mov    0x8(%rsp),%rax
  81fb01:	mov    0x20(%rax),%r8
  81fb05:	shl    $0x3,%rdi
  81fb09:	cmpl   $0x0,0x90(%rsp)
  81fb11:	je     81fe00 <<gpui_gpu::renderer::RendererState>::render+0x1de0>
  81fb17:	movq   $0x0,0x40(%rsp)
  81fb20:	movq   $0x0,0x70(%rsp)
  81fb29:	movq   $0x0,0x10(%rsp)
  81fb32:	xor    %r10d,%r10d
  81fb35:	xor    %ecx,%ecx
  81fb37:	jmp    81fb5f <<gpui_gpu::renderer::RendererState>::render+0x1b3f>
  81fb39:	incq   0x10(%rsp)
  81fb3e:	inc    %r10
  81fb41:	cmp    0x90(%rsp),%r10
  81fb49:	mov    $0x0,%eax
  81fb4e:	cmove  %rax,%r10
  81fb52:	inc    %rcx
  81fb55:	add    $0xfffffffffffffff8,%rdi
  81fb59:	je     81fc20 <<gpui_gpu::renderer::RendererState>::render+0x1c00>
  81fb5f:	mov    0x4(%r8,%rcx,8),%r11d
  81fb64:	mov    $0x80000000,%eax
  81fb69:	cmp    %rax,%r11
  81fb6c:	je     81fb39 <<gpui_gpu::renderer::RendererState>::render+0x1b19>
  81fb6e:	mov    %r11d,%esi
  81fb71:	and    $0x1fffffff,%esi
  81fb77:	sub    (%r8,%rcx,8),%esi
  81fb7b:	je     81fb3e <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fb7d:	mov    %rcx,%rax
  81fb80:	shr    $0x20,%rax
  81fb84:	je     81fb98 <<gpui_gpu::renderer::RendererState>::render+0x1b78>
  81fb86:	mov    %rcx,%rax
  81fb89:	xor    %edx,%edx
  81fb8b:	divq   0x90(%rsp)
  81fb93:	mov    %r10,%rdx
  81fb96:	jmp    81fba3 <<gpui_gpu::renderer::RendererState>::render+0x1b83>
  81fb98:	mov    %ecx,%eax
  81fb9a:	xor    %edx,%edx
  81fb9c:	divl   0x90(%rsp)
  81fba3:	shl    $0x4,%edx
  81fba6:	shl    $0x4,%eax
  81fba9:	lea    0x10(%rdx),%r13d
  81fbad:	cmp    %r13d,%r14d
  81fbb0:	cmovb  %r14d,%r13d
  81fbb4:	lea    0x10(%rax),%r9d
  81fbb8:	cmp    %r9d,%r15d
  81fbbb:	cmovb  %r15d,%r9d
  81fbbf:	sub    %edx,%r13d
  81fbc2:	sub    %eax,%r9d
  81fbc5:	imul   %r13d,%r9d
  81fbc9:	mov    %r9,%rax
  81fbcc:	shl    $0x4,%rax
  81fbd0:	test   $0x40000000,%r11d
  81fbd7:	cmovne %r9,%rax
  81fbdb:	shr    $0x1d,%r11d
  81fbdf:	and    $0x1,%r11d
  81fbe3:	add    %rax,0x70(%rsp)
  81fbe8:	imul   %r11,%r9
  81fbec:	sub    %r11,%rsi
  81fbef:	imul   %rax,%rsi
  81fbf3:	add    0x40(%rsp),%r9
  81fbf8:	add    %rsi,%r9
  81fbfb:	mov    %r9,0x40(%rsp)
  81fc00:	jmp    81fb3e <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc05:	movq   $0x0,0x10(%rsp)
  81fc0e:	movq   $0x0,0x70(%rsp)
  81fc17:	movq   $0x0,0x40(%rsp)
  81fc20:	test   $0x1,%bpl
  81fc24:	je     81fc71 <<gpui_gpu::renderer::RendererState>::render+0x1c51>
  81fc26:	movd   0x2e8(%rsp),%xmm0
  81fc2f:	movd   %xmm0,%eax
  81fc33:	test   %eax,%eax
  81fc35:	setns  %cl
  81fc38:	mov    %eax,%edx
  81fc3a:	and    $0x7fffffff,%edx
  81fc40:	add    $0xff800000,%edx
  81fc46:	cmp    $0x7f000000,%edx
  81fc4c:	setb   %dl
  81fc4f:	and    %cl,%dl
  81fc51:	dec    %eax
  81fc53:	cmp    $0x7fffff,%eax
  81fc58:	setb   %al
  81fc5b:	or     %dl,%al
  81fc5d:	mov    $0x2,%ebx
  81fc62:	movd   %xmm0,0xf4(%rsp)
  81fc6b:	je     81fdf6 <<gpui_gpu::renderer::RendererState>::render+0x1dd6>
  81fc71:	mov    0x120(%rsp),%rax
  81fc79:	add    $0x18,%rax
  81fc7d:	xor    %ecx,%ecx
  81fc7f:	cmpl   $0x28,0x2e4(%rsp)
  81fc87:	sete   %cl
  81fc8a:	and    $0x1,%r12d
  81fc8e:	lea    (%r12,%rcx,4),%ecx
  81fc92:	or     %ebx,%ecx
  81fc94:	movups (%rax),%xmm0
  81fc97:	movups %xmm0,0x418(%rsp)
  81fc9f:	mov    %r14d,0x408(%rsp)
  81fca7:	mov    %r15d,0x40c(%rsp)
  81fcaf:	mov    0x90(%rsp),%rax
  81fcb7:	mov    %eax,0x410(%rsp)
  81fcbe:	mov    %ecx,0x414(%rsp)
  81fcc5:	movss  0xf4(%rsp),%xmm0
  81fcce:	movss  %xmm0,0x428(%rsp)
  81fcd7:	mov    0x110(%rsp),%rax
  81fcdf:	mov    %eax,0x42c(%rsp)
  81fce6:	movq   $0x0,0x430(%rsp)
  81fcf2:	mov    0x8(%rsp),%rax
  81fcf7:	lea    0x230(%rax),%rsi
  81fcfe:	lea    0x408(%rsp),%rcx
  81fd06:	mov    $0x30,%r8d
  81fd0c:	mov    0x2f0(%rsp),%rdi
  81fd14:	mov    %rsi,0x30(%rsp)
  81fd19:	xor    %edx,%edx
  81fd1b:	call   *0x6603e7(%rip)        # e80108 <_DYNAMIC+0x5d0>
  81fd21:	mov    0x2b8(%rsp),%rbx
  81fd29:	shl    $0x4,%rbx
  81fd2d:	mov    0x98(%rsp),%rdi
  81fd35:	mov    0xa0(%rsp),%rsi
  81fd3d:	mov    %rbx,%rdx
  81fd40:	call   81cb80 <<gpui_gpu::renderer::Buffer>::reserve>
  81fd45:	cmpq   $0x0,0x38(%rsp)
  81fd4b:	je     81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd4d:	mov    0x2b8(%rsp),%rcx
  81fd55:	cmp    %rcx,0x348(%rsp)
  81fd5d:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd5f:	test   %al,%al
  81fd61:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd63:	testb  $0x1,0x390(%rsp)
  81fd6b:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd6d:	mov    0x2d8(%rsp),%rax
  81fd75:	mov    0x230(%rsp),%rbx
  81fd7d:	mov    0x238(%rsp),%rsi
  81fd85:	cmp    %rbx,%rax
  81fd88:	jne    81fe4c <<gpui_gpu::renderer::RendererState>::render+0x1e2c>
  81fd8e:	mov    %rsi,0x2d8(%rsp)
  81fd96:	movq   $0xffffffffffffffff,0x230(%rsp)
  81fda2:	movq   $0x0,0x238(%rsp)
  81fdae:	mov    $0xffffffffffffffff,%rbx
  81fdb5:	movq   $0x0,0x38(%rsp)
  81fdbe:	jmp    81fe54 <<gpui_gpu::renderer::RendererState>::render+0x1e34>
  81fdc3:	mov    0x8(%rsp),%rax
  81fdc8:	mov    0x8(%rax),%rcx
  81fdcc:	mov    0x10(%rax),%r8
  81fdd0:	shl    $0x4,%r8
  81fdd4:	mov    0x98(%rsp),%rdi
  81fddc:	mov    0xa0(%rsp),%rsi
  81fde4:	mov    0x2f0(%rsp),%rdx
  81fdec:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81fdf1:	jmp    81feb2 <<gpui_gpu::renderer::RendererState>::render+0x1e92>
  81fdf6:	mov    0x50(%rsp),%rdi
  81fdfb:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81fe00:	movq   $0x0,0x70(%rsp)
  81fe09:	xor    %eax,%eax
  81fe0b:	movq   $0x0,0x10(%rsp)
  81fe14:	jmp    81fe28 <<gpui_gpu::renderer::RendererState>::render+0x1e08>
  81fe16:	incq   0x10(%rsp)
  81fe1b:	add    $0x8,%rax
  81fe1f:	cmp    %rax,%rdi
  81fe22:	je     81fc17 <<gpui_gpu::renderer::RendererState>::render+0x1bf7>
  81fe28:	mov    0x4(%r8,%rax,1),%ecx
  81fe2d:	mov    %ecx,%edx
  81fe2f:	neg    %edx
  81fe31:	jo     81fe16 <<gpui_gpu::renderer::RendererState>::render+0x1df6>
  81fe33:	and    $0x1fffffff,%ecx
  81fe39:	cmp    %ecx,(%r8,%rax,1)
  81fe3d:	je     81fe1b <<gpui_gpu::renderer::RendererState>::render+0x1dfb>
  81fe3f:	lea    0x60e98a(%rip),%rdi        # e2e7d0 <anon.36d49f465d299f05a84fba3771e6457e.33.llvm.4447969268566763096+0x10>
  81fe46:	call   *0x6602c4(%rip)        # e80110 <_DYNAMIC+0x5d8>
  81fe4c:	mov    %rsi,0x38(%rsp)
  81fe51:	mov    %rax,%rsi
  81fe54:	mov    0x8(%rsp),%r13
  81fe59:	mov    0x8(%r13),%rdx
  81fe5d:	mov    0x10(%r13),%rcx
  81fe61:	mov    0x2d0(%rsp),%rdi
  81fe69:	mov    0x98(%rsp),%rbp
  81fe71:	mov    %rbp,%r8
  81fe74:	mov    0x2f0(%rsp),%r12
  81fe7c:	mov    %r12,%r9
  81fe7f:	call   81cad0 <<gpui_gpu::renderer::Changes>::upload>
  81fe84:	mov    %rax,0xc0(%rsp)
  81fe8c:	mov    0x8(%r13),%rdx
  81fe90:	mov    0x10(%r13),%rcx
  81fe94:	mov    %rbx,%rdi
  81fe97:	mov    0x38(%rsp),%rsi
  81fe9c:	mov    %rbp,%r8
  81fe9f:	mov    %r12,%r9
  81fea2:	call   81cad0 <<gpui_gpu::renderer::Changes>::upload>
  81fea7:	mov    %rax,%rbx
  81feaa:	add    0xc0(%rsp),%rbx
  81feb2:	mov    0xa0(%rsp),%r13
  81feba:	lea    0x18(%r13),%rax
  81febe:	mov    %rax,0x38(%rsp)
  81fec3:	mov    0x8(%rsp),%rbp
  81fec8:	lea    0x280(%rbp),%rdi
  81fecf:	mov    0x20(%rbp),%rcx
  81fed3:	mov    0x28(%rbp),%r8
  81fed7:	shl    $0x3,%r8
  81fedb:	mov    %rdi,0xc0(%rsp)
  81fee3:	mov    %r13,%rsi
  81fee6:	mov    0x2f0(%rsp),%r12
  81feee:	mov    %r12,%rdx
  81fef1:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81fef6:	lea    0x2a8(%rbp),%rdi
  81fefd:	mov    0x38(%rbp),%rcx
  81ff01:	mov    0x40(%rbp),%r8
  81ff05:	shl    $0x2,%r8
  81ff09:	mov    %rdi,0xb0(%rsp)
  81ff11:	mov    %r13,%rsi
  81ff14:	mov    %r12,%rdx
  81ff17:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81ff1c:	lea    0x2d0(%rbp),%rdi
  81ff23:	mov    0x68(%rbp),%rcx
  81ff27:	mov    0x70(%rbp),%r8
  81ff2b:	shl    $0x5,%r8
  81ff2f:	mov    %rdi,0x28(%rsp)
  81ff34:	mov    %r13,%rsi
  81ff37:	mov    %r12,%rdx
  81ff3a:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81ff3f:	cmpq   $0x0,0x328(%rbp)
  81ff47:	je     81ff4d <<gpui_gpu::renderer::RendererState>::render+0x1f2d>
  81ff49:	xor    %eax,%eax
  81ff4b:	jmp    81ff62 <<gpui_gpu::renderer::RendererState>::render+0x1f42>
  81ff4d:	mov    0x8(%rsp),%rax
  81ff52:	mov    0x10(%rax),%rax
  81ff56:	cmp    $0x1,%rax
  81ff5a:	adc    $0x0,%rax
  81ff5e:	shl    $0x4,%rax
  81ff62:	mov    0x8(%rsp),%rdi
  81ff67:	mov    0x28(%rdi),%rsi
  81ff6b:	mov    0x40(%rdi),%rcx
  81ff6f:	cmp    $0x1,%rsi
  81ff73:	adc    $0x0,%rsi
  81ff77:	shl    $0x3,%rsi
  81ff7b:	cmp    $0x1,%rcx
  81ff7f:	adc    $0x0,%rcx
  81ff83:	mov    0x70(%rdi),%rdx
  81ff87:	cmp    $0x1,%rdx
  81ff8b:	adc    $0x0,%rdx
  81ff8f:	add    $0xc8,%rdi
  81ff96:	shl    $0x2,%rcx
  81ff9a:	shl    $0x5,%rdx
  81ff9e:	movq   $0x0,0x130(%rsp)
  81ffaa:	mov    0x30(%rsp),%r8
  81ffaf:	mov    %r8,0x138(%rsp)
  81ffb7:	movq   $0x0,0x158(%rsp)
  81ffc3:	xorpd  %xmm0,%xmm0
  81ffc7:	movupd %xmm0,0x140(%rsp)
  81ffd0:	movl   $0x0,0x150(%rsp)
  81ffdb:	mov    0x98(%rsp),%r8
  81ffe3:	mov    %r8,0x160(%rsp)
  81ffeb:	movq   $0x0,0x168(%rsp)
  81fff7:	mov    %rax,0x170(%rsp)
  81ffff:	movl   $0x1,0x178(%rsp)
  82000a:	movq   $0x0,0x180(%rsp)
  820016:	mov    0xc0(%rsp),%rax
  82001e:	mov    %rax,0x188(%rsp)
  820026:	movq   $0x0,0x190(%rsp)
  820032:	mov    %rsi,0x198(%rsp)
  82003a:	movl   $0x2,0x1a0(%rsp)
  820045:	movq   $0x0,0x1a8(%rsp)
  820051:	mov    0xb0(%rsp),%rax
  820059:	mov    %rax,0x1b0(%rsp)
  820061:	movq   $0x0,0x1b8(%rsp)
  82006d:	mov    %rcx,0x1c0(%rsp)
  820075:	movl   $0x3,0x1c8(%rsp)
  820080:	movq   $0x4,0x1d0(%rsp)
  82008c:	mov    %rdi,0x1d8(%rsp)
  820094:	movl   $0x4,0x1f0(%rsp)
  82009f:	movq   $0x0,0x1f8(%rsp)
  8200ab:	mov    0x28(%rsp),%rax
  8200b0:	mov    %rax,0x200(%rsp)
  8200b8:	movq   $0x0,0x208(%rsp)
  8200c4:	mov    %rdx,0x210(%rsp)
  8200cc:	movl   $0x5,0x218(%rsp)
  8200d7:	lea    -0x74b546(%rip),%rax        # d4b98 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  8200de:	mov    %rax,0x3b8(%rsp)
  8200e6:	movq   $0xa,0x3c0(%rsp)
  8200f2:	mov    0x38(%rsp),%rax
  8200f7:	mov    %rax,0x3a0(%rsp)
  8200ff:	lea    0x130(%rsp),%rax
  820107:	mov    %rax,0x3a8(%rsp)
  82010f:	movq   $0x6,0x3b0(%rsp)
  82011b:	lea    0x3a0(%rsp),%rsi
  820123:	mov    0xa0(%rsp),%r13
  82012b:	mov    %r13,%rdi
  82012e:	call   *0x65ffe4(%rip)        # e80118 <_DYNAMIC+0x5e0>
  820134:	mov    %rax,%rbp
  820137:	mov    %rax,0x270(%rsp)
  82013f:	lea    0x270(%rsp),%rdx
  820147:	mov    %r13,%rdi
  82014a:	mov    0x4b8(%rsp),%rsi
  820152:	call   81d1c0 <<gpui_gpu::renderer::GpuContext>::submit>
  820157:	mov    %rax,0x38(%rsp)
  82015c:	xor    %r13d,%r13d
  82015f:	mov    0x350(%rsp),%rax
  820167:	cmp    %rax,0x358(%rsp)
  82016f:	setne  %r13b
  820173:	shl    $0x1f,%r13d
  820177:	or     %r14d,%r13d
  82017a:	shl    $0x20,%r15
  82017e:	or     %r15,%r13
  820181:	mov    0xe8(%rsp),%rax
  820189:	mov    (%rax),%rax
  82018c:	test   %rax,%rax
  82018f:	je     8201a5 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820191:	lock decq (%rax)
  820195:	jne    8201a5 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820197:	mov    0xe8(%rsp),%rdi
  82019f:	call   *0x65feab(%rip)        # e80050 <_DYNAMIC+0x518>
  8201a5:	mov    0x8(%rsp),%rax
  8201aa:	mov    %rbp,0x330(%rax)
  8201b1:	mov    %r13,0x338(%rax)
  8201b8:	mov    0x28(%rax),%rsi
  8201bc:	mov    0x70(%rax),%rcx
  8201c0:	mov    %rcx,0xe8(%rsp)
  8201c8:	mov    0x278(%rax),%rdx
  8201cf:	mov    0x220(%rsp),%r8
  8201d7:	lea    (%rbx,%r8,4),%rdi
  8201db:	lea    (%rdi,%rsi,8),%rsi
  8201df:	mov    %rcx,%rdi
  8201e2:	shl    $0x5,%rdi
  8201e6:	lea    (%rdi,%rsi,1),%rcx
  8201ea:	add    $0x30,%rcx
  8201ee:	mov    %rcx,0x30(%rsp)
  8201f3:	mov    0x150(%rax),%esi
  8201f9:	imul   %rsi,%rsi
  8201fd:	add    0x250(%rax),%rdx
  820204:	add    0x2a0(%rax),%rdx
  82020b:	add    0x2c8(%rax),%rdx
  820212:	add    0x2f0(%rax),%rdx
  820219:	mov    0x308(%rax),%rdi
  820220:	add    0x310(%rax),%rdi
  820227:	mov    0x118(%rsp),%r11
  82022f:	mov    %r11,%rcx
  820232:	sub    %r8,%rcx
  820235:	mov    0x88(%rsp),%rbp
  82023d:	mov    %rbp,%r9
  820240:	mov    0x2b0(%rsp),%r13
  820248:	sub    %r13,%r9
  82024b:	mov    0x10(%rax),%r10
  82024f:	shl    $0x4,%r10
  820253:	mov    0x160(%rax),%rbx
  82025a:	inc    %rbx
  82025d:	mov    $0xffffffffffffffff,%r14
  820264:	cmovne %rbx,%r14
  820268:	mov    (%rax),%rbx
  82026b:	shl    $0x4,%rbx
  82026f:	mov    0x48(%rax),%r15
  820273:	add    0x30(%rax),%r15
  820277:	mov    0x18(%rax),%r12
  82027b:	lea    (%rbx,%r12,8),%rbx
  82027f:	lea    (%rbx,%r15,4),%rbx
  820283:	mov    0x60(%rax),%r15
  820287:	shl    $0x5,%r15
  82028b:	add    %rbx,%r15
  82028e:	mov    0x138(%rax),%rbx
  820295:	mov    0x130(%rax),%r12
  82029c:	mov    %r14,0x160(%rax)
  8202a3:	mov    %rbp,0x168(%rax)
  8202aa:	lea    (%r11,%r11,1),%r14
  8202ae:	mov    %r14,0x170(%rax)
  8202b5:	movq   $0x1,0x178(%rax)
  8202c0:	mov    %rbp,0x180(%rax)
  8202c7:	mov    %r8,0x188(%rax)
  8202ce:	mov    %r11,0x190(%rax)
  8202d5:	mov    %rcx,0x198(%rax)
  8202dc:	mov    0x10(%rsp),%rcx
  8202e1:	mov    %rcx,0x1a0(%rax)
  8202e8:	mov    0x70(%rsp),%rcx
  8202ed:	mov    %rcx,0x1a8(%rax)
  8202f4:	mov    0x40(%rsp),%rcx
  8202f9:	mov    %rcx,0x1b0(%rax)
  820300:	mov    0x30(%rsp),%rcx
  820305:	mov    %rcx,0x1b8(%rax)
  82030c:	mov    %r10,0x1c0(%rax)
  820313:	mov    0x2a8(%rsp),%r8
  82031b:	mov    %r8,0x1c8(%rax)
  820322:	mov    %r13,0x1d0(%rax)
  820329:	mov    %r9,0x1d8(%rax)
  820330:	mov    0x2c8(%rsp),%rcx
  820338:	mov    %rcx,0x1e0(%rax)
  82033f:	mov    %rdx,0x1e8(%rax)
  820346:	mov    %rsi,0x1f0(%rax)
  82034d:	add    %rbx,%r12
  820350:	mov    %rbx,0x1f8(%rax)
  820357:	mov    %r12,0x200(%rax)
  82035e:	mov    %r15,0x208(%rax)
  820365:	mov    0xe8(%rsp),%rcx
  82036d:	mov    %rcx,0x210(%rax)
  820374:	mov    %rdi,0x218(%rax)
  82037b:	movb   $0x0,0x220(%rax)
  820382:	mov    0x50(%rsp),%rdi
  820387:	mov    0x38(%rsp),%rax
  82038c:	mov    %rax,0x8(%rdi)
  820390:	movl   $0xffffffff,(%rdi)
  820396:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  82039b:	lea    0x60e21e(%rip),%rdi        # e2e5c0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x18>
  8203a2:	call   *0x65fd78(%rip)        # e80120 <_DYNAMIC+0x5e8>
  8203a8:	lea    0x60e271(%rip),%rcx        # e2e620 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x78>
  8203af:	xor    %edi,%edi
  8203b1:	mov    0x20(%rsp),%rsi
  8203b6:	call   *0x65fcc4(%rip)        # e80080 <_DYNAMIC+0x548>
  8203bc:	lea    0x60e215(%rip),%rax        # e2e5d8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x30>
  8203c3:	mov    %rcx,%rdi
  8203c6:	mov    %rdx,%rsi
  8203c9:	mov    %rax,%rdx
  8203cc:	call   *0x65fc5e(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8203d2:	lea    0x60e22f(%rip),%rax        # e2e608 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x60>
  8203d9:	mov    %rcx,%rdi
  8203dc:	mov    %rdx,%rsi
  8203df:	mov    %rax,%rdx
  8203e2:	call   *0x65fc48(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8203e8:	lea    0x60e201(%rip),%rdx        # e2e5f0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x48>
  8203ef:	call   *0x65fc3b(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8203f5:	mov    %rax,%r14
  8203f8:	mov    0x8(%rsp),%rax
  8203fd:	mov    %rbp,0x330(%rax)
  820404:	mov    %r13,0x338(%rax)
  82040b:	mov    %r14,%rdi
  82040e:	call   e2c890 <_Unwind_Resume@plt>
  820413:	mov    %rax,%r14
  820416:	lock decq 0x0(%rbp)
  82041b:	jne    820445 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  82041d:	lea    0x270(%rsp),%rdi
  820425:	call   *0x65fc25(%rip)        # e80050 <_DYNAMIC+0x518>
  82042b:	jmp    820445 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  82042d:	call   *0x65f955(%rip)        # e7fd88 <_DYNAMIC+0x250>
  820433:	mov    %rax,%r14
  820436:	mov    0xe8(%rsp),%rax
  82043e:	movq   $0x0,(%rax)
  820445:	mov    %r14,%rdi
  820448:	call   e2c890 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4499 frame=808

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820450 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820450:	push   %rbp
  820451:	push   %r15
  820453:	push   %r14
  820455:	push   %r13
  820457:	push   %r12
  820459:	push   %rbx
  82045a:	sub    $0x2f8,%rsp
  820461:	movss  0x88(%rdx),%xmm3
  820469:	movss  -0x771455(%rip),%xmm0        # af01c <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820471:	movaps %xmm3,%xmm1
  820474:	subss  %xmm0,%xmm1
  820478:	cvttss2si %xmm1,%rax
  82047d:	cvttss2si %xmm3,%r10
  820482:	mov    %r10,%r12
  820485:	sar    $0x3f,%r12
  820489:	and    %rax,%r12
  82048c:	or     %r10,%r12
  82048f:	xor    %eax,%eax
  820491:	xorps  %xmm1,%xmm1
  820494:	ucomiss %xmm1,%xmm3
  820497:	cmovb  %rax,%r12
  82049b:	movss  0x90(%rdx),%xmm4
  8204a3:	movss  -0x77148b(%rip),%xmm2        # af020 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8204ab:	ucomiss %xmm2,%xmm3
  8204ae:	mov    $0xffffffffffffffff,%r10
  8204b5:	cmova  %r10,%r12
  8204b9:	movaps %xmm4,%xmm3
  8204bc:	subss  %xmm0,%xmm3
  8204c0:	cvttss2si %xmm3,%r11
  8204c5:	cvttss2si %xmm4,%rbx
  8204ca:	mov    %rbx,%r14
  8204cd:	sar    $0x3f,%r14
  8204d1:	and    %r11,%r14
  8204d4:	or     %rbx,%r14
  8204d7:	ucomiss %xmm1,%xmm4
  8204da:	cmovb  %rax,%r14
  8204de:	ucomiss %xmm2,%xmm4
  8204e1:	cmova  %r10,%r14
  8204e5:	movss  0x8c(%rdx),%xmm3
  8204ed:	lea    (%r12,%r14,1),%rbx
  8204f1:	dec    %rbx
  8204f4:	shr    $0x4,%rbx
  8204f8:	shr    $0x4,%r12
  8204fc:	mov    %rbx,%rbp
  8204ff:	sub    %r12,%rbp
  820502:	inc    %rbp
  820505:	movaps %xmm3,%xmm4
  820508:	subss  %xmm0,%xmm4
  82050c:	cvttss2si %xmm4,%r15
  820511:	cvttss2si %xmm3,%r14
  820516:	mov    %r14,%r11
  820519:	sar    $0x3f,%r11
  82051d:	and    %r15,%r11
  820520:	or     %r14,%r11
  820523:	ucomiss %xmm1,%xmm3
  820526:	cmovb  %rax,%r11
  82052a:	ucomiss %xmm2,%xmm3
  82052d:	movss  0x94(%rdx),%xmm3
  820535:	cmova  %r10,%r11
  820539:	movaps %xmm3,%xmm4
  82053c:	subss  %xmm0,%xmm4
  820540:	cvttss2si %xmm4,%r13
  820545:	cvttss2si %xmm3,%r14
  82054a:	mov    %r14,%r15
  82054d:	sar    $0x3f,%r15
  820551:	and    %r13,%r15
  820554:	or     %r14,%r15
  820557:	ucomiss %xmm1,%xmm3
  82055a:	cmovb  %rax,%r15
  82055e:	ucomiss %xmm2,%xmm3
  820561:	cmova  %r10,%r15
  820565:	lea    (%r11,%r15,1),%r10
  820569:	dec    %r10
  82056c:	shr    $0x4,%r10
  820570:	shr    $0x4,%r11
  820574:	mov    %r10,%r14
  820577:	sub    %r11,%r14
  82057a:	inc    %r14
  82057d:	imul   %rbp,%r14
  820581:	add    0x348(%rsp),%r14
  820589:	setb   %al
  82058c:	cmp    $0x400001,%r14
  820593:	setae  %bpl
  820597:	or     %al,%bpl
  82059a:	mov    $0x6,%eax
  82059f:	jne    820690 <<gpui_gpu::renderer::RendererState>::bin_draw+0x240>
  8205a5:	mov    %r14,0x1a0(%rsp)
  8205ad:	mov    %rdi,0x1a8(%rsp)
  8205b5:	mov    %r12,0xb0(%rsp)
  8205bd:	cmpb   $0x0,(%rdx)
  8205c0:	sete   %al
  8205c3:	and    0x340(%rsi),%al
  8205c9:	xor    %r12d,%r12d
  8205cc:	cmp    $0x1,%al
  8205ce:	jne    8206a4 <<gpui_gpu::renderer::RendererState>::bin_draw+0x254>
  8205d4:	movss  0xa4(%rdx),%xmm0
  8205dc:	ucomiss -0x771803(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  8205e3:	mov    0xb0(%rsp),%r14
  8205eb:	jne    82066a <<gpui_gpu::renderer::RendererState>::bin_draw+0x21a>
  8205ed:	jp     82066a <<gpui_gpu::renderer::RendererState>::bin_draw+0x21a>
  8205ef:	mov    0x98(%rdx),%edi
  8205f5:	test   %edi,%edi
  8205f7:	jns    820609 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b9>
  8205f9:	and    $0x7f800000,%edi
  8205ff:	dec    %edi
  820601:	cmp    $0x7f7fffff,%edi
  820607:	jae    820667 <<gpui_gpu::renderer::RendererState>::bin_draw+0x217>
  820609:	mov    0x9c(%rdx),%edi
  82060f:	test   %edi,%edi
  820611:	jns    820623 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1d3>
  820613:	and    $0x7f800000,%edi
  820619:	dec    %edi
  82061b:	cmp    $0x7f7ffffe,%edi
  820621:	ja     820667 <<gpui_gpu::renderer::RendererState>::bin_draw+0x217>
  820623:	mov    0xa0(%rdx),%edi
  820629:	test   %edi,%edi
  82062b:	jns    82063d <<gpui_gpu::renderer::RendererState>::bin_draw+0x1ed>
  82062d:	and    $0x7f800000,%edi
  820633:	dec    %edi
  820635:	cmp    $0x7f7ffffe,%edi
  82063b:	ja     820667 <<gpui_gpu::renderer::RendererState>::bin_draw+0x217>
  82063d:	movd   %xmm0,%edi
  820641:	test   %edi,%edi
  820643:	jns    820655 <<gpui_gpu::renderer::RendererState>::bin_draw+0x205>
  820645:	and    $0x7f800000,%edi
  82064b:	dec    %edi
  82064d:	cmp    $0x7f7ffffe,%edi
  820653:	ja     820667 <<gpui_gpu::renderer::RendererState>::bin_draw+0x217>
  820655:	mov    $0x1,%r12b
  820658:	mov    %r9,0xa8(%rsp)
  820660:	cmp    %r11,%r10
  820663:	jb     820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  820665:	jmp    8206b9 <<gpui_gpu::renderer::RendererState>::bin_draw+0x269>
  820667:	xor    %r12d,%r12d
  82066a:	mov    %r9,0xa8(%rsp)
  820672:	cmp    %r11,%r10
  820675:	jae    8206b9 <<gpui_gpu::renderer::RendererState>::bin_draw+0x269>
  820677:	mov    0x1a8(%rsp),%rdi
  82067f:	mov    0x1a0(%rsp),%rax
  820687:	mov    %rax,0x8(%rdi)
  82068b:	mov    $0xffffffff,%eax
  820690:	mov    %eax,(%rdi)
  820692:	add    $0x2f8,%rsp
  820699:	pop    %rbx
  82069a:	pop    %r12
  82069c:	pop    %r13
  82069e:	pop    %r14
  8206a0:	pop    %r15
  8206a2:	pop    %rbp
  8206a3:	ret
  8206a4:	mov    0xb0(%rsp),%r14
  8206ac:	mov    %r9,0xa8(%rsp)
  8206b4:	cmp    %r11,%r10
  8206b7:	jb     820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  8206b9:	cmp    %r14,%rbx
  8206bc:	jae    8206d6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x286>
  8206be:	xchg   %ax,%ax
  8206c0:	mov    %r11,%rax
  8206c3:	cmp    %r10,%r11
  8206c6:	adc    $0x0,%r11
  8206ca:	cmp    %r10,%rax
  8206cd:	jae    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  8206cf:	cmp    %r10,%r11
  8206d2:	jbe    8206c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x270>
  8206d4:	jmp    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  8206d6:	mov    0x20(%rsi),%r13
  8206da:	mov    %rsi,%rdi
  8206dd:	mov    0x28(%rsi),%rsi
  8206e1:	test   %al,%al
  8206e3:	mov    %r10,0x18(%rsp)
  8206e8:	je     8214a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1050>
  8206ee:	cmpq   $0x0,0x330(%rsp)
  8206f7:	je     821510 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10c0>
  8206fd:	movd   %ecx,%xmm2
  820701:	shr    $0x20,%rcx
  820705:	movss  0x78(%rdx),%xmm0
  82070a:	movss  0x80(%rdx),%xmm3
  820712:	movss  0x84(%rdx),%xmm4
  82071a:	cvtss2sd %xmm0,%xmm0
  82071e:	movss  0x7c(%rdx),%xmm1
  820723:	cvtss2sd %xmm1,%xmm1
  820727:	cvtss2sd %xmm3,%xmm14
  82072c:	addsd  %xmm0,%xmm14
  820731:	xorps  %xmm3,%xmm3
  820734:	cvtss2sd %xmm4,%xmm3
  820738:	addsd  %xmm1,%xmm3
  82073c:	movsd  %xmm3,0x1b8(%rsp)
  820745:	movsd  0x48(%rdx),%xmm6
  82074a:	movsd  0x58(%rdx),%xmm7
  82074f:	movsd  0x68(%rdx),%xmm8
  820755:	movss  0x38(%rdx),%xmm3
  82075a:	movss  0x3c(%rdx),%xmm4
  82075f:	movss  0x40(%rdx),%xmm5
  820764:	cvtss2sd %xmm3,%xmm3
  820768:	cvtss2sd %xmm5,%xmm5
  82076c:	movaps -0x775944(%rip),%xmm9        # aae30 <GCC_except_table0+0x90>
  820774:	movaps %xmm3,0x90(%rsp)
  82077c:	andps  %xmm9,%xmm3
  820780:	movaps %xmm3,0x80(%rsp)
  820788:	movaps %xmm5,0x60(%rsp)
  82078d:	cvtss2sd %xmm2,%xmm2
  820791:	movsd  %xmm2,0x10(%rsp)
  820797:	andps  %xmm9,%xmm5
  82079b:	movaps %xmm5,0x70(%rsp)
  8207a0:	movaps %xmm6,%xmm2
  8207a3:	andps  %xmm9,%xmm2
  8207a7:	movaps %xmm2,0x260(%rsp)
  8207af:	movaps %xmm7,%xmm2
  8207b2:	andps  %xmm9,%xmm2
  8207b6:	movaps %xmm2,0x240(%rsp)
  8207be:	xorps  %xmm3,%xmm3
  8207c1:	cvtss2sd %xmm4,%xmm3
  8207c5:	movaps %xmm8,%xmm2
  8207c9:	andps  %xmm9,%xmm2
  8207cd:	movaps %xmm2,0x100(%rsp)
  8207d5:	movss  0x44(%rdx),%xmm2
  8207da:	cvtss2sd %xmm2,%xmm2
  8207de:	movaps %xmm3,0x50(%rsp)
  8207e3:	andps  %xmm9,%xmm3
  8207e7:	movaps %xmm3,0x40(%rsp)
  8207ec:	movaps %xmm2,0x20(%rsp)
  8207f1:	andps  %xmm9,%xmm2
  8207f5:	movaps %xmm2,0x30(%rsp)
  8207fa:	movd   %ecx,%xmm2
  8207fe:	cvtss2sd %xmm2,%xmm2
  820802:	movsd  %xmm2,(%rsp)
  820807:	movsd  0x50(%rdx),%xmm3
  82080c:	movaps %xmm3,%xmm2
  82080f:	andps  %xmm9,%xmm2
  820813:	movaps %xmm2,0x1e0(%rsp)
  82081b:	movsd  0x60(%rdx),%xmm4
  820820:	movaps %xmm4,%xmm2
  820823:	andps  %xmm9,%xmm2
  820827:	movaps %xmm2,0x1c0(%rsp)
  82082f:	movsd  0x70(%rdx),%xmm5
  820834:	andps  %xmm5,%xmm9
  820838:	movaps %xmm9,0xd0(%rsp)
  820841:	mov    0x58(%rdi),%rax
  820845:	mov    %rax,0xb8(%rsp)
  82084d:	mov    0x50(%rdi),%rax
  820851:	mov    %rax,0x168(%rsp)
  820859:	mov    0xa8(%rsp),%rax
  820861:	inc    %eax
  820863:	mov    %rax,0xa8(%rsp)
  82086b:	movaps %xmm6,0x270(%rsp)
  820873:	movaps %xmm6,%xmm2
  820876:	movaps %xmm7,0x250(%rsp)
  82087e:	movlhps %xmm7,%xmm2
  820881:	cvtpd2ps %xmm2,%xmm2
  820885:	movaps %xmm3,0x1f0(%rsp)
  82088d:	cvtsd2ss %xmm3,%xmm3
  820891:	cvtss2sd %xmm3,%xmm3
  820895:	cvtps2pd %xmm2,%xmm6
  820898:	movaps %xmm4,0x1d0(%rsp)
  8208a0:	xorps  %xmm2,%xmm2
  8208a3:	cvtsd2ss %xmm4,%xmm2
  8208a7:	xorps  %xmm4,%xmm4
  8208aa:	cvtss2sd %xmm2,%xmm4
  8208ae:	movaps %xmm8,0x110(%rsp)
  8208b7:	xorps  %xmm2,%xmm2
  8208ba:	cvtsd2ss %xmm8,%xmm2
  8208bf:	cvtss2sd %xmm2,%xmm7
  8208c3:	movaps %xmm5,0xc0(%rsp)
  8208cb:	xorps  %xmm2,%xmm2
  8208ce:	cvtsd2ss %xmm5,%xmm2
  8208d2:	cvtss2sd %xmm2,%xmm2
  8208d6:	movaps -0x775aad(%rip),%xmm5        # aae30 <GCC_except_table0+0x90>
  8208dd:	movaps %xmm6,%xmm8
  8208e1:	andps  %xmm5,%xmm8
  8208e5:	movaps %xmm7,0x130(%rsp)
  8208ed:	andps  %xmm5,%xmm7
  8208f0:	movaps %xmm7,0x120(%rsp)
  8208f8:	movaps %xmm3,0x230(%rsp)
  820900:	andps  %xmm5,%xmm3
  820903:	movaps %xmm3,0x220(%rsp)
  82090b:	movaps %xmm4,0x210(%rsp)
  820913:	andps  %xmm5,%xmm4
  820916:	movaps %xmm4,0x200(%rsp)
  82091e:	movaps %xmm2,0xf0(%rsp)
  820926:	andps  %xmm2,%xmm5
  820929:	movaps %xmm5,0xe0(%rsp)
  820931:	movaps %xmm6,0x290(%rsp)
  820939:	movhlps %xmm6,%xmm6
  82093c:	movaps %xmm6,0x2c0(%rsp)
  820944:	movaps %xmm8,0x280(%rsp)
  82094d:	movhlps %xmm8,%xmm8
  820951:	movaps %xmm8,0x2b0(%rsp)
  82095a:	mov    %r11,%rax
  82095d:	movsd  %xmm14,0x8(%rsp)
  820964:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  820970:	cmp    %r10,%r11
  820973:	adc    $0x0,%rax
  820977:	mov    %rax,0x1b0(%rsp)
  82097f:	mov    %r14,%rcx
  820982:	mov    %r11,%r14
  820985:	imul   0x330(%rsp),%r14
  82098e:	mov    %rcx,%rdi
  820991:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  8209a0:	cmp    %rbx,%rcx
  8209a3:	adc    $0x0,%rdi
  8209a7:	lea    (%rcx,%r14,1),%r10
  8209ab:	test   %r12b,%r12b
  8209ae:	jne    8209c5 <<gpui_gpu::renderer::RendererState>::bin_draw+0x575>
  8209b0:	cmp    %rsi,%r10
  8209b3:	jae    82159e <<gpui_gpu::renderer::RendererState>::bin_draw+0x114e>
  8209b9:	testb  $0x40,0x7(%r13,%r10,8)
  8209bf:	je     820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8209c5:	mov    %r10,%rax
  8209c8:	shr    $0x20,%rax
  8209cc:	je     8209e0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x590>
  8209ce:	mov    %r10,%rax
  8209d1:	xor    %edx,%edx
  8209d3:	divq   0x330(%rsp)
  8209db:	jmp    8209f0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8209dd:	nopl   (%rax)
  8209e0:	mov    %r10d,%eax
  8209e3:	xor    %edx,%edx
  8209e5:	mov    0x330(%rsp),%r15
  8209ed:	div    %r15d
  8209f0:	shl    $0x4,%edx
  8209f3:	shl    $0x4,%eax
  8209f6:	lea    0x10(%rdx),%ebp
  8209f9:	mov    0x338(%rsp),%r9d
  820a01:	cmp    %ebp,%r9d
  820a04:	cmovb  %r9d,%ebp
  820a08:	lea    0x10(%rax),%r15d
  820a0c:	mov    0x340(%rsp),%r9d
  820a14:	cmp    %r15d,%r9d
  820a17:	cmovb  %r9d,%r15d
  820a1b:	xorps  %xmm12,%xmm12
  820a1f:	cvtsi2sd %edx,%xmm12
  820a24:	ucomisd %xmm12,%xmm0
  820a29:	ja     820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820a2b:	mov    %eax,%eax
  820a2d:	xorps  %xmm2,%xmm2
  820a30:	cvtsi2sd %rax,%xmm2
  820a35:	ucomisd %xmm2,%xmm1
  820a39:	ja     820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820a3b:	xorps  %xmm6,%xmm6
  820a3e:	cvtsi2sd %ebp,%xmm6
  820a42:	ucomisd %xmm14,%xmm6
  820a47:	ja     820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820a49:	xorps  %xmm13,%xmm13
  820a4d:	cvtsi2sd %r15d,%xmm13
  820a52:	ucomisd 0x1b8(%rsp),%xmm13
  820a5c:	jbe    820a94 <<gpui_gpu::renderer::RendererState>::bin_draw+0x644>
  820a5e:	xchg   %ax,%ax
  820a60:	cmp    %rsi,%r10
  820a63:	jae    82158e <<gpui_gpu::renderer::RendererState>::bin_draw+0x113e>
  820a69:	mov    0x4(%r13,%r10,8),%eax
  820a6e:	inc    %eax
  820a70:	and    $0xbfffffff,%eax
  820a75:	mov    %eax,0x4(%r13,%r10,8)
  820a7a:	cmp    %rbx,%rcx
  820a7d:	jae    821470 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1020>
  820a83:	mov    %rdi,%rcx
  820a86:	cmp    %rbx,%rdi
  820a89:	jbe    8209a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x550>
  820a8f:	jmp    821470 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1020>
  820a94:	unpcklpd %xmm2,%xmm12
  820a99:	addpd  -0x773962(%rip),%xmm12        # ad140 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820aa2:	movapd %xmm12,%xmm10
  820aa7:	mulpd  0x290(%rsp),%xmm10
  820ab1:	movapd %xmm10,%xmm9
  820ab6:	unpckhpd %xmm10,%xmm9
  820abb:	movapd %xmm10,%xmm2
  820ac0:	addsd  %xmm9,%xmm2
  820ac5:	addsd  0x130(%rsp),%xmm2
  820ace:	subsd  0x90(%rsp),%xmm2
  820ad7:	movapd 0x280(%rsp),%xmm8
  820ae1:	mulpd  %xmm12,%xmm8
  820ae6:	movapd %xmm8,%xmm15
  820aeb:	unpckhpd %xmm8,%xmm15
  820af0:	movapd %xmm8,%xmm3
  820af5:	addsd  %xmm15,%xmm3
  820afa:	addsd  0x120(%rsp),%xmm3
  820b03:	addsd  0x80(%rsp),%xmm3
  820b0c:	addsd  0x70(%rsp),%xmm3
  820b12:	addsd  -0x771242(%rip),%xmm3        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b1a:	mulsd  -0x7712c2(%rip),%xmm3        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820b22:	addsd  0x10(%rsp),%xmm3
  820b28:	ucomisd %xmm2,%xmm3
  820b2c:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820b32:	movapd 0x60(%rsp),%xmm4
  820b38:	subsd  %xmm2,%xmm4
  820b3c:	ucomisd %xmm4,%xmm3
  820b40:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820b46:	movapd %xmm12,%xmm7
  820b4b:	unpckhpd %xmm12,%xmm7
  820b50:	movapd 0x250(%rsp),%xmm11
  820b5a:	mulsd  %xmm7,%xmm11
  820b5f:	movapd 0x240(%rsp),%xmm3
  820b68:	mulsd  %xmm7,%xmm3
  820b6c:	movapd 0x270(%rsp),%xmm2
  820b75:	mulsd  %xmm12,%xmm2
  820b7a:	movapd %xmm2,0x150(%rsp)
  820b83:	addsd  %xmm11,%xmm2
  820b88:	addsd  0x110(%rsp),%xmm2
  820b91:	subsd  0x90(%rsp),%xmm2
  820b9a:	movapd 0x260(%rsp),%xmm4
  820ba3:	mulsd  %xmm12,%xmm4
  820ba8:	movsd  %xmm4,0x198(%rsp)
  820bb1:	addsd  %xmm3,%xmm4
  820bb5:	addsd  0x100(%rsp),%xmm4
  820bbe:	addsd  0x80(%rsp),%xmm4
  820bc7:	addsd  0x70(%rsp),%xmm4
  820bcd:	addsd  -0x7712fd(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820bd5:	mulsd  -0x770da5(%rip),%xmm4        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820bdd:	ucomisd %xmm2,%xmm4
  820be1:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820be7:	movapd 0x60(%rsp),%xmm5
  820bed:	subsd  %xmm2,%xmm5
  820bf1:	ucomisd %xmm5,%xmm4
  820bf5:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820bfb:	movapd %xmm7,%xmm4
  820bff:	mulsd  0x210(%rsp),%xmm4
  820c08:	movapd %xmm7,%xmm2
  820c0c:	mulsd  0x200(%rsp),%xmm2
  820c15:	movapd %xmm12,%xmm5
  820c1a:	mulsd  0x230(%rsp),%xmm5
  820c23:	movsd  %xmm5,0x190(%rsp)
  820c2c:	movapd %xmm4,0x140(%rsp)
  820c35:	addsd  %xmm4,%xmm5
  820c39:	addsd  0xf0(%rsp),%xmm5
  820c42:	subsd  0x50(%rsp),%xmm5
  820c48:	movapd %xmm12,%xmm4
  820c4d:	mulsd  0x220(%rsp),%xmm4
  820c56:	movsd  %xmm4,0x188(%rsp)
  820c5f:	addsd  %xmm2,%xmm4
  820c63:	addsd  0xe0(%rsp),%xmm4
  820c6c:	addsd  0x40(%rsp),%xmm4
  820c72:	addsd  0x30(%rsp),%xmm4
  820c78:	addsd  -0x7713a8(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c80:	mulsd  -0x771428(%rip),%xmm4        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820c88:	addsd  (%rsp),%xmm4
  820c8d:	ucomisd %xmm5,%xmm4
  820c91:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820c97:	movapd 0x20(%rsp),%xmm14
  820c9e:	subsd  %xmm5,%xmm14
  820ca3:	ucomisd %xmm14,%xmm4
  820ca8:	movsd  0x8(%rsp),%xmm14
  820caf:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820cb5:	movapd 0x1d0(%rsp),%xmm4
  820cbe:	mulsd  %xmm7,%xmm4
  820cc2:	mulsd  0x1c0(%rsp),%xmm7
  820ccb:	movapd 0x1f0(%rsp),%xmm5
  820cd4:	mulsd  %xmm12,%xmm5
  820cd9:	movapd %xmm5,0x2d0(%rsp)
  820ce2:	movapd %xmm4,0x2e0(%rsp)
  820ceb:	addsd  %xmm4,%xmm5
  820cef:	addsd  0xc0(%rsp),%xmm5
  820cf8:	subsd  0x50(%rsp),%xmm5
  820cfe:	mulsd  0x1e0(%rsp),%xmm12
  820d08:	movapd %xmm12,%xmm4
  820d0d:	addsd  %xmm7,%xmm4
  820d11:	addsd  0xd0(%rsp),%xmm4
  820d1a:	addsd  0x40(%rsp),%xmm4
  820d20:	addsd  0x30(%rsp),%xmm4
  820d26:	addsd  -0x771456(%rip),%xmm4        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d2e:	mulsd  -0x770efe(%rip),%xmm4        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820d36:	ucomisd %xmm5,%xmm4
  820d3a:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820d40:	movapd 0x20(%rsp),%xmm14
  820d47:	subsd  %xmm5,%xmm14
  820d4c:	ucomisd %xmm14,%xmm4
  820d51:	movsd  0x8(%rsp),%xmm14
  820d58:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820d5e:	addsd  -0x77177e(%rip),%xmm6        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820d66:	movapd %xmm6,%xmm4
  820d6a:	mulsd  0x290(%rsp),%xmm4
  820d73:	movsd  %xmm4,0x180(%rsp)
  820d7c:	addsd  %xmm4,%xmm9
  820d81:	addsd  0x130(%rsp),%xmm9
  820d8b:	subsd  0x90(%rsp),%xmm9
  820d95:	movapd 0x280(%rsp),%xmm4
  820d9e:	mulsd  %xmm6,%xmm4
  820da2:	movsd  %xmm4,0x178(%rsp)
  820dab:	addsd  %xmm4,%xmm15
  820db0:	addsd  0x120(%rsp),%xmm15
  820dba:	addsd  0x80(%rsp),%xmm15
  820dc4:	addsd  0x70(%rsp),%xmm15
  820dcb:	addsd  -0x7714fc(%rip),%xmm15        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820dd4:	mulsd  -0x77157d(%rip),%xmm15        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ddd:	addsd  0x10(%rsp),%xmm15
  820de4:	ucomisd %xmm9,%xmm15
  820de9:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820def:	movapd 0x60(%rsp),%xmm4
  820df5:	subsd  %xmm9,%xmm4
  820dfa:	ucomisd %xmm4,%xmm15
  820dff:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820e05:	movapd 0x270(%rsp),%xmm15
  820e0f:	mulsd  %xmm6,%xmm15
  820e14:	addsd  %xmm15,%xmm11
  820e19:	addsd  0x110(%rsp),%xmm11
  820e23:	subsd  0x90(%rsp),%xmm11
  820e2d:	movapd 0x260(%rsp),%xmm4
  820e36:	mulsd  %xmm6,%xmm4
  820e3a:	movsd  %xmm4,0x170(%rsp)
  820e43:	addsd  %xmm4,%xmm3
  820e47:	addsd  0x100(%rsp),%xmm3
  820e50:	addsd  0x80(%rsp),%xmm3
  820e59:	addsd  0x70(%rsp),%xmm3
  820e5f:	addsd  -0x77158f(%rip),%xmm3        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e67:	mulsd  -0x771037(%rip),%xmm3        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820e6f:	ucomisd %xmm11,%xmm3
  820e74:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820e7a:	movapd 0x60(%rsp),%xmm4
  820e80:	subsd  %xmm11,%xmm4
  820e85:	ucomisd %xmm4,%xmm3
  820e89:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820e8f:	movapd %xmm6,%xmm3
  820e93:	mulsd  0x230(%rsp),%xmm3
  820e9c:	movsd  %xmm3,0x160(%rsp)
  820ea5:	movapd 0x140(%rsp),%xmm5
  820eae:	addsd  %xmm3,%xmm5
  820eb2:	addsd  0xf0(%rsp),%xmm5
  820ebb:	subsd  0x50(%rsp),%xmm5
  820ec1:	movapd %xmm6,%xmm3
  820ec5:	mulsd  0x220(%rsp),%xmm3
  820ece:	movsd  %xmm3,0x140(%rsp)
  820ed7:	addsd  %xmm3,%xmm2
  820edb:	addsd  0xe0(%rsp),%xmm2
  820ee4:	addsd  0x40(%rsp),%xmm2
  820eea:	addsd  0x30(%rsp),%xmm2
  820ef0:	addsd  -0x771620(%rip),%xmm2        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ef8:	mulsd  -0x7716a0(%rip),%xmm2        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f00:	addsd  (%rsp),%xmm2
  820f05:	ucomisd %xmm5,%xmm2
  820f09:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820f0f:	movapd 0x20(%rsp),%xmm3
  820f15:	subsd  %xmm5,%xmm3
  820f19:	ucomisd %xmm3,%xmm2
  820f1d:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820f23:	movapd 0x1f0(%rsp),%xmm2
  820f2c:	mulsd  %xmm6,%xmm2
  820f30:	movapd %xmm2,0x2a0(%rsp)
  820f39:	movapd 0x2e0(%rsp),%xmm4
  820f42:	addsd  %xmm2,%xmm4
  820f46:	addsd  0xc0(%rsp),%xmm4
  820f4f:	subsd  0x50(%rsp),%xmm4
  820f55:	mulsd  0x1e0(%rsp),%xmm6
  820f5e:	addsd  %xmm6,%xmm7
  820f62:	addsd  0xd0(%rsp),%xmm7
  820f6b:	addsd  0x40(%rsp),%xmm7
  820f71:	addsd  0x30(%rsp),%xmm7
  820f77:	addsd  -0x7716a7(%rip),%xmm7        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f7f:	mulsd  -0x77114f(%rip),%xmm7        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f87:	ucomisd %xmm4,%xmm7
  820f8b:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820f91:	movapd 0x20(%rsp),%xmm2
  820f97:	subsd  %xmm4,%xmm2
  820f9b:	ucomisd %xmm2,%xmm7
  820f9f:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  820fa5:	addsd  -0x7719c6(%rip),%xmm13        # af5e8 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820fae:	movapd %xmm13,%xmm3
  820fb3:	mulsd  0x2c0(%rsp),%xmm3
  820fbc:	movapd %xmm13,%xmm2
  820fc1:	mulsd  0x2b0(%rsp),%xmm2
  820fca:	addsd  %xmm3,%xmm10
  820fcf:	addsd  0x130(%rsp),%xmm10
  820fd9:	subsd  0x90(%rsp),%xmm10
  820fe3:	addsd  %xmm2,%xmm8
  820fe8:	addsd  0x120(%rsp),%xmm8
  820ff2:	addsd  0x80(%rsp),%xmm8
  820ffc:	addsd  0x70(%rsp),%xmm8
  821003:	addsd  -0x771734(%rip),%xmm8        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82100c:	mulsd  -0x7717b5(%rip),%xmm8        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821015:	addsd  0x10(%rsp),%xmm8
  82101c:	ucomisd %xmm10,%xmm8
  821021:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821027:	movapd 0x60(%rsp),%xmm4
  82102d:	subsd  %xmm10,%xmm4
  821032:	ucomisd %xmm4,%xmm8
  821037:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82103d:	movapd 0x250(%rsp),%xmm7
  821046:	mulsd  %xmm13,%xmm7
  82104b:	movapd 0x240(%rsp),%xmm5
  821054:	mulsd  %xmm13,%xmm5
  821059:	movapd 0x150(%rsp),%xmm4
  821062:	addsd  %xmm7,%xmm4
  821066:	addsd  0x110(%rsp),%xmm4
  82106f:	subsd  0x90(%rsp),%xmm4
  821078:	movsd  0x198(%rsp),%xmm10
  821082:	addsd  %xmm5,%xmm10
  821087:	addsd  0x100(%rsp),%xmm10
  821091:	addsd  0x80(%rsp),%xmm10
  82109b:	addsd  0x70(%rsp),%xmm10
  8210a2:	addsd  -0x7717d3(%rip),%xmm10        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210ab:	mulsd  -0x77127c(%rip),%xmm10        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210b4:	ucomisd %xmm4,%xmm10
  8210b9:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8210bf:	movapd %xmm4,%xmm8
  8210c4:	movapd 0x60(%rsp),%xmm4
  8210ca:	subsd  %xmm8,%xmm4
  8210cf:	ucomisd %xmm4,%xmm10
  8210d4:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8210da:	movapd %xmm13,%xmm8
  8210df:	mulsd  0x210(%rsp),%xmm8
  8210e9:	movapd %xmm13,%xmm10
  8210ee:	mulsd  0x200(%rsp),%xmm10
  8210f8:	movsd  0x190(%rsp),%xmm9
  821102:	addsd  %xmm8,%xmm9
  821107:	addsd  0xf0(%rsp),%xmm9
  821111:	subsd  0x50(%rsp),%xmm9
  821118:	movapd %xmm15,%xmm4
  82111d:	movsd  0x188(%rsp),%xmm15
  821127:	movsd  %xmm10,0x150(%rsp)
  821131:	addsd  %xmm10,%xmm15
  821136:	addsd  0xe0(%rsp),%xmm15
  821140:	addsd  0x40(%rsp),%xmm15
  821147:	addsd  0x30(%rsp),%xmm15
  82114e:	addsd  -0x77187f(%rip),%xmm15        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821157:	mulsd  -0x771900(%rip),%xmm15        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821160:	addsd  (%rsp),%xmm15
  821166:	ucomisd %xmm9,%xmm15
  82116b:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821171:	movapd %xmm9,%xmm10
  821176:	movapd 0x20(%rsp),%xmm9
  82117d:	subsd  %xmm10,%xmm9
  821182:	ucomisd %xmm9,%xmm15
  821187:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82118d:	movapd 0x1d0(%rsp),%xmm9
  821197:	mulsd  %xmm13,%xmm9
  82119c:	mulsd  0x1c0(%rsp),%xmm13
  8211a6:	movapd 0x2d0(%rsp),%xmm10
  8211b0:	addsd  %xmm9,%xmm10
  8211b5:	addsd  0xc0(%rsp),%xmm10
  8211bf:	subsd  0x50(%rsp),%xmm10
  8211c6:	addsd  %xmm13,%xmm12
  8211cb:	addsd  0xd0(%rsp),%xmm12
  8211d5:	addsd  0x40(%rsp),%xmm12
  8211dc:	addsd  0x30(%rsp),%xmm12
  8211e3:	addsd  -0x771914(%rip),%xmm12        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211ec:	mulsd  -0x7713bd(%rip),%xmm12        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8211f5:	ucomisd %xmm10,%xmm12
  8211fa:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821200:	movapd %xmm10,%xmm11
  821205:	movapd 0x20(%rsp),%xmm10
  82120c:	subsd  %xmm11,%xmm10
  821211:	ucomisd %xmm10,%xmm12
  821216:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82121c:	movsd  0x180(%rsp),%xmm10
  821226:	addsd  %xmm3,%xmm10
  82122b:	addsd  0x130(%rsp),%xmm10
  821235:	subsd  0x90(%rsp),%xmm10
  82123f:	movsd  0x178(%rsp),%xmm11
  821249:	addsd  %xmm2,%xmm11
  82124e:	addsd  0x120(%rsp),%xmm11
  821258:	addsd  0x80(%rsp),%xmm11
  821262:	addsd  0x70(%rsp),%xmm11
  821269:	addsd  -0x77199a(%rip),%xmm11        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821272:	mulsd  -0x771a1b(%rip),%xmm11        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82127b:	addsd  0x10(%rsp),%xmm11
  821282:	ucomisd %xmm10,%xmm11
  821287:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82128d:	movapd %xmm4,%xmm15
  821292:	movapd 0x60(%rsp),%xmm2
  821298:	subsd  %xmm10,%xmm2
  82129d:	ucomisd %xmm2,%xmm11
  8212a2:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8212a8:	addsd  %xmm7,%xmm15
  8212ad:	addsd  0x110(%rsp),%xmm15
  8212b7:	subsd  0x90(%rsp),%xmm15
  8212c1:	movsd  0x170(%rsp),%xmm2
  8212ca:	addsd  %xmm5,%xmm2
  8212ce:	addsd  0x100(%rsp),%xmm2
  8212d7:	addsd  0x80(%rsp),%xmm2
  8212e0:	addsd  0x70(%rsp),%xmm2
  8212e6:	addsd  -0x771a16(%rip),%xmm2        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212ee:	mulsd  -0x7714be(%rip),%xmm2        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8212f6:	ucomisd %xmm15,%xmm2
  8212fb:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821301:	movapd %xmm2,%xmm3
  821305:	movapd 0x60(%rsp),%xmm2
  82130b:	subsd  %xmm15,%xmm2
  821310:	ucomisd %xmm2,%xmm3
  821314:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82131a:	movsd  0x160(%rsp),%xmm2
  821323:	addsd  %xmm8,%xmm2
  821328:	addsd  0xf0(%rsp),%xmm2
  821331:	subsd  0x50(%rsp),%xmm2
  821337:	movsd  0x140(%rsp),%xmm5
  821340:	addsd  0x150(%rsp),%xmm5
  821349:	addsd  0xe0(%rsp),%xmm5
  821352:	addsd  0x40(%rsp),%xmm5
  821358:	addsd  0x30(%rsp),%xmm5
  82135e:	addsd  -0x771a8e(%rip),%xmm5        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821366:	mulsd  -0x771b0e(%rip),%xmm5        # af860 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82136e:	addsd  (%rsp),%xmm5
  821373:	ucomisd %xmm2,%xmm5
  821377:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  82137d:	movapd %xmm2,%xmm3
  821381:	movapd 0x20(%rsp),%xmm2
  821387:	subsd  %xmm3,%xmm2
  82138b:	ucomisd %xmm2,%xmm5
  82138f:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  821395:	movapd 0x2a0(%rsp),%xmm2
  82139e:	addsd  %xmm9,%xmm2
  8213a3:	addsd  0xc0(%rsp),%xmm2
  8213ac:	subsd  0x50(%rsp),%xmm2
  8213b2:	addsd  %xmm13,%xmm6
  8213b7:	addsd  0xd0(%rsp),%xmm6
  8213c0:	addsd  0x40(%rsp),%xmm6
  8213c6:	addsd  0x30(%rsp),%xmm6
  8213cc:	addsd  -0x771afc(%rip),%xmm6        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213d4:	mulsd  -0x7715a4(%rip),%xmm6        # afe38 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8213dc:	ucomisd %xmm2,%xmm6
  8213e0:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8213e6:	movapd %xmm2,%xmm3
  8213ea:	movapd 0x20(%rsp),%xmm2
  8213f0:	subsd  %xmm3,%xmm2
  8213f4:	ucomisd %xmm2,%xmm6
  8213f8:	jae    820a60 <<gpui_gpu::renderer::RendererState>::bin_draw+0x610>
  8213fe:	test   %r12b,%r12b
  821401:	je     821448 <<gpui_gpu::renderer::RendererState>::bin_draw+0xff8>
  821403:	cmp    %rsi,%r10
  821406:	jae    8215bb <<gpui_gpu::renderer::RendererState>::bin_draw+0x116b>
  82140c:	mov    %r8d,0x0(%r13,%r10,8)
  821411:	movl   $0x40000001,0x4(%r13,%r10,8)
  82141a:	cmp    0xb8(%rsp),%r10
  821422:	jae    8215cb <<gpui_gpu::renderer::RendererState>::bin_draw+0x117b>
  821428:	mov    0xa8(%rsp),%rax
  821430:	mov    0x168(%rsp),%rdx
  821438:	mov    %eax,(%rdx,%r10,4)
  82143c:	movsd  0x8(%rsp),%xmm14
  821443:	jmp    820a7a <<gpui_gpu::renderer::RendererState>::bin_draw+0x62a>
  821448:	cmp    %rsi,%r10
  82144b:	jae    82158e <<gpui_gpu::renderer::RendererState>::bin_draw+0x113e>
  821451:	incl   0x4(%r13,%r10,8)
  821456:	movsd  0x8(%rsp),%xmm14
  82145d:	jmp    820a7a <<gpui_gpu::renderer::RendererState>::bin_draw+0x62a>
  821462:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  821470:	mov    0x18(%rsp),%r10
  821475:	cmp    %r10,%r11
  821478:	mov    0xb0(%rsp),%r14
  821480:	mov    0x1b0(%rsp),%rax
  821488:	jae    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  82148e:	mov    %rax,%r11
  821491:	cmp    %r10,%rax
  821494:	jbe    820970 <<gpui_gpu::renderer::RendererState>::bin_draw+0x520>
  82149a:	jmp    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  82149f:	nop
  8214a0:	mov    %r11,%rax
  8214a3:	cmp    %r10,%r11
  8214a6:	adc    $0x0,%r11
  8214aa:	mov    %rax,%rcx
  8214ad:	imul   0x330(%rsp),%rcx
  8214b6:	mov    %r14,%rdx
  8214b9:	nopl   0x0(%rax)
  8214c0:	lea    (%rdx,%rcx,1),%r10
  8214c4:	cmp    %rsi,%r10
  8214c7:	jae    82158e <<gpui_gpu::renderer::RendererState>::bin_draw+0x113e>
  8214cd:	cmp    %rbx,%rdx
  8214d0:	mov    %rdx,%rdi
  8214d3:	adc    $0x0,%rdi
  8214d7:	mov    0x4(%r13,%r10,8),%r8d
  8214dc:	inc    %r8d
  8214df:	and    $0xbfffffff,%r8d
  8214e6:	mov    %r8d,0x4(%r13,%r10,8)
  8214eb:	cmp    %rbx,%rdx
  8214ee:	jae    8214f8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10a8>
  8214f0:	mov    %rdi,%rdx
  8214f3:	cmp    %rbx,%rdi
  8214f6:	jbe    8214c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1070>
  8214f8:	mov    0x18(%rsp),%r10
  8214fd:	cmp    %r10,%rax
  821500:	jae    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  821506:	cmp    %r10,%r11
  821509:	jbe    8214a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1050>
  82150b:	jmp    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  821510:	test   %r12b,%r12b
  821513:	jne    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x115e>
  821519:	mov    %r11,%rax
  82151c:	mov    0x18(%rsp),%rcx
  821521:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  821530:	cmp    %rcx,%r11
  821533:	adc    $0x0,%rax
  821537:	mov    %r14,%r10
  82153a:	mov    %r14,%rcx
  82153d:	nopl   (%rax)
  821540:	cmp    %rbx,%r10
  821543:	adc    $0x0,%rcx
  821547:	cmp    %rsi,%r10
  82154a:	jae    82159e <<gpui_gpu::renderer::RendererState>::bin_draw+0x114e>
  82154c:	mov    0x4(%r13,%r10,8),%edx
  821551:	test   $0x40000000,%edx
  821557:	jne    8215ae <<gpui_gpu::renderer::RendererState>::bin_draw+0x115e>
  821559:	inc    %edx
  82155b:	and    $0xbfffffff,%edx
  821561:	mov    %edx,0x4(%r13,%r10,8)
  821566:	cmp    %rbx,%r10
  821569:	jae    821573 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1123>
  82156b:	mov    %rcx,%r10
  82156e:	cmp    %rbx,%rcx
  821571:	jbe    821540 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10f0>
  821573:	mov    0x18(%rsp),%rcx
  821578:	cmp    %rcx,%r11
  82157b:	jae    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  821581:	mov    %rax,%r11
  821584:	cmp    %rcx,%rax
  821587:	jbe    821530 <<gpui_gpu::renderer::RendererState>::bin_draw+0x10e0>
  821589:	jmp    820677 <<gpui_gpu::renderer::RendererState>::bin_draw+0x227>
  82158e:	lea    0x60d11b(%rip),%rdx        # e2e6b0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x108>
  821595:	mov    %r10,%rdi
  821598:	call   *0x65ea92(%rip)        # e80030 <_DYNAMIC+0x4f8>
  82159e:	lea    0x60d0f3(%rip),%rdx        # e2e698 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0xf0>
  8215a5:	mov    %r10,%rdi
  8215a8:	call   *0x65ea82(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8215ae:	lea    0x60d21b(%rip),%rdi        # e2e7d0 <anon.36d49f465d299f05a84fba3771e6457e.33.llvm.4447969268566763096+0x10>
  8215b5:	call   *0x65eb55(%rip)        # e80110 <_DYNAMIC+0x5d8>
  8215bb:	lea    0x60d106(%rip),%rdx        # e2e6c8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x120>
  8215c2:	mov    %r10,%rdi
  8215c5:	call   *0x65ea65(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8215cb:	lea    0x60d10e(%rip),%rdx        # e2e6e0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x138>
  8215d2:	mov    %r10,%rdi
  8215d5:	mov    0xb8(%rsp),%rsi
  8215dd:	call   *0x65ea4d(%rip)        # e80030 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008215f0 <gpui_gpu::renderer::compact_group>:
  8215f0:	xor    %eax,%eax
  8215f2:	test   %esi,%esi
  8215f4:	je     821633 <gpui_gpu::renderer::compact_group+0x43>
  8215f6:	cmpq   $0x2,0x10(%rdi)
  8215fb:	jb     821633 <gpui_gpu::renderer::compact_group+0x43>
  8215fd:	sub    $0x58,%rsp
  821601:	mov    (%rdi),%rsi
  821604:	mov    0x8(%rdi),%rax
  821608:	mov    (%rax),%edx
  82160a:	mov    %rsp,%rdi
  82160d:	call   81c830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  821612:	movss  0x4(%rsp),%xmm0
  821618:	cmpb   $0x3,(%rsp)
  82161c:	setne  %cl
  82161f:	xorps  %xmm1,%xmm1
  821622:	ucomiss %xmm1,%xmm0
  821625:	setnp  %dl
  821628:	sete   %al
  82162b:	and    %dl,%al
  82162d:	or     %cl,%al
  82162f:	add    $0x58,%rsp
  821633:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821640 <gpui_gpu::renderer::validate_draw>:
  821640:	push   %rbp
  821641:	push   %r15
  821643:	push   %r14
  821645:	push   %r12
  821647:	push   %rbx
  821648:	sub    $0x80,%rsp
  82164f:	mov    %r8d,%ebp
  821652:	mov    %ecx,%r12d
  821655:	mov    %rdx,%r14
  821658:	mov    %rsi,%r15
  82165b:	mov    %rdi,%rbx
  82165e:	movups 0x88(%rsi),%xmm0
  821665:	movaps %xmm0,0x20(%rsp)
  82166a:	movaps %xmm0,0x70(%rsp)
  82166f:	lea    0x70(%rsp),%rdi
  821674:	call   *0x65eb2e(%rip)        # e801a8 <_DYNAMIC+0x670>
  82167a:	movaps 0x20(%rsp),%xmm4
  82167f:	test   %al,%al
  821681:	je     8216d7 <gpui_gpu::renderer::validate_draw+0x97>
  821683:	movaps %xmm4,%xmm0
  821686:	unpckhpd %xmm4,%xmm0
  82168a:	xorps  %xmm2,%xmm2
  82168d:	ucomiss %xmm2,%xmm0
  821690:	jne    821694 <gpui_gpu::renderer::validate_draw+0x54>
  821692:	jnp    8216d7 <gpui_gpu::renderer::validate_draw+0x97>
  821694:	movaps %xmm4,%xmm1
  821697:	shufps $0xff,%xmm4,%xmm1
  82169b:	ucomiss %xmm2,%xmm1
  82169e:	jne    8216a2 <gpui_gpu::renderer::validate_draw+0x62>
  8216a0:	jnp    8216d7 <gpui_gpu::renderer::validate_draw+0x97>
  8216a2:	xorps  %xmm3,%xmm3
  8216a5:	ucomiss %xmm4,%xmm3
  8216a8:	ja     8216d7 <gpui_gpu::renderer::validate_draw+0x97>
  8216aa:	movaps %xmm4,%xmm2
  8216ad:	shufps $0x55,%xmm4,%xmm2
  8216b1:	ucomiss %xmm2,%xmm3
  8216b4:	ja     8216d7 <gpui_gpu::renderer::validate_draw+0x97>
  8216b6:	xorps  %xmm3,%xmm3
  8216b9:	cvtsi2ss %r12d,%xmm3
  8216be:	addss  %xmm4,%xmm0
  8216c2:	ucomiss %xmm3,%xmm0
  8216c5:	ja     8216d7 <gpui_gpu::renderer::validate_draw+0x97>
  8216c7:	xorps  %xmm0,%xmm0
  8216ca:	cvtsi2ss %ebp,%xmm0
  8216ce:	addss  %xmm1,%xmm2
  8216d2:	ucomiss %xmm0,%xmm2
  8216d5:	jbe    8216ed <gpui_gpu::renderer::validate_draw+0xad>
  8216d7:	movl   $0x3,(%rbx)
  8216dd:	add    $0x80,%rsp
  8216e4:	pop    %rbx
  8216e5:	pop    %r12
  8216e7:	pop    %r14
  8216e9:	pop    %r15
  8216eb:	pop    %rbp
  8216ec:	ret
  8216ed:	movsd  0x48(%r15),%xmm9
  8216f3:	movsd  0x60(%r15),%xmm1
  8216f9:	movupd 0x50(%r15),%xmm2
  8216ff:	movapd %xmm2,%xmm5
  821703:	shufpd $0x1,%xmm2,%xmm5
  821708:	movupd 0x68(%r15),%xmm0
  82170e:	cvtpd2ps %xmm5,%xmm8
  821713:	movapd %xmm9,%xmm4
  821718:	unpcklpd %xmm1,%xmm4
  82171c:	cvtpd2ps %xmm4,%xmm7
  821720:	cvtpd2ps %xmm0,%xmm6
  821724:	movapd %xmm6,%xmm3
  821728:	shufps $0x55,%xmm6,%xmm3
  82172c:	movd   %xmm3,%ecx
  821730:	movd   %xmm6,%eax
  821734:	movapd %xmm7,%xmm3
  821738:	shufps $0x14,%xmm8,%xmm3
  82173d:	shufps $0x78,%xmm3,%xmm3
  821741:	andps  -0x773f58(%rip),%xmm3        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821748:	and    $0x7fffffff,%eax
  82174d:	cmp    $0x7f800000,%eax
  821752:	setge  %al
  821755:	and    $0x7fffffff,%ecx
  82175b:	cmp    $0x7f800000,%ecx
  821761:	setge  %cl
  821764:	pcmpgtd -0x77603c(%rip),%xmm3        # ab730 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  82176c:	movmskps %xmm3,%edx
  82176f:	test   %edx,%edx
  821771:	jne    8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821773:	test   %al,%al
  821775:	jne    8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821777:	test   %cl,%cl
  821779:	jne    8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  82177b:	movapd %xmm9,%xmm3
  821780:	mulsd  %xmm1,%xmm3
  821784:	movapd %xmm2,%xmm10
  821789:	mulsd  %xmm5,%xmm10
  82178e:	subsd  %xmm10,%xmm3
  821793:	xorpd  %xmm10,%xmm10
  821798:	ucomisd %xmm10,%xmm3
  82179d:	jne    8217a1 <gpui_gpu::renderer::validate_draw+0x161>
  82179f:	jnp    8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  8217a1:	movq   %xmm3,%rcx
  8217a6:	movabs $0x7fffffffffffffff,%rax
  8217b0:	and    %rax,%rcx
  8217b3:	movabs $0x7ff0000000000000,%rdx
  8217bd:	cmp    %rdx,%rcx
  8217c0:	jl     8217d1 <gpui_gpu::renderer::validate_draw+0x191>
  8217c2:	movl   $0x5,(%rbx)
  8217c8:	mov    %r14,0x8(%rbx)
  8217cc:	jmp    8216dd <gpui_gpu::renderer::validate_draw+0x9d>
  8217d1:	xorps  %xmm10,%xmm10
  8217d5:	cvtsi2sd %r12d,%xmm10
  8217da:	cvtsi2sd %ebp,%xmm12
  8217df:	movsd  %xmm9,%xmm2
  8217e4:	movapd -0x7769bd(%rip),%xmm13        # aae30 <GCC_except_table0+0x90>
  8217ed:	andpd  %xmm13,%xmm2
  8217f2:	movapd %xmm10,%xmm11
  8217f7:	unpcklpd %xmm12,%xmm11
  8217fc:	movapd %xmm2,%xmm9
  821801:	movapd %xmm11,0x50(%rsp)
  821808:	mulpd  %xmm11,%xmm9
  82180d:	movapd %xmm9,%xmm11
  821812:	unpckhpd %xmm9,%xmm11
  821817:	addsd  %xmm9,%xmm11
  82181c:	movapd %xmm0,%xmm9
  821821:	andpd  %xmm13,%xmm9
  821826:	addsd  %xmm11,%xmm9
  82182b:	shufpd $0x2,%xmm5,%xmm1
  821830:	andpd  %xmm13,%xmm1
  821835:	unpcklpd %xmm10,%xmm12
  82183a:	movapd %xmm1,%xmm10
  82183f:	movapd %xmm12,0x40(%rsp)
  821846:	mulpd  %xmm12,%xmm10
  82184b:	movapd %xmm10,%xmm11
  821850:	unpckhpd %xmm10,%xmm11
  821855:	addsd  %xmm9,%xmm11
  82185a:	addsd  %xmm10,%xmm11
  82185f:	movapd %xmm0,%xmm10
  821864:	unpckhpd %xmm0,%xmm10
  821869:	andpd  %xmm13,%xmm10
  82186e:	addsd  %xmm11,%xmm10
  821873:	movsd  0x38(%r15),%xmm9
  821879:	movsd  0x40(%r15),%xmm12
  82187f:	andps  -0x774097(%rip),%xmm9        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821887:	cvtps2pd %xmm9,%xmm15
  82188b:	movapd %xmm10,%xmm9
  821890:	addsd  %xmm15,%xmm9
  821895:	movapd %xmm15,0x60(%rsp)
  82189c:	unpckhpd %xmm15,%xmm15
  8218a1:	addsd  %xmm15,%xmm9
  8218a6:	cvtps2pd %xmm12,%xmm11
  8218aa:	movapd %xmm11,0x20(%rsp)
  8218b1:	andpd  %xmm13,%xmm11
  8218b6:	addsd  %xmm11,%xmm9
  8218bb:	pshufd $0xee,%xmm11,%xmm14
  8218c1:	movdqa %xmm14,0x30(%rsp)
  8218c8:	addsd  %xmm14,%xmm9
  8218cd:	movq   %xmm9,%rsi
  8218d2:	and    %rax,%rsi
  8218d5:	movabs $0x7fefffffffffffff,%rcx
  8218df:	cmp    %rcx,%rsi
  8218e2:	jg     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  8218e8:	ucomisd -0x772279(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8218f1:	ja     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  8218f7:	movzbl (%r15),%esi
  8218fb:	cmp    $0x3,%esi
  8218fe:	je     821916 <gpui_gpu::renderer::validate_draw+0x2d6>
  821900:	xorpd  %xmm14,%xmm14
  821905:	cmp    $0x1,%esi
  821908:	jne    821a42 <gpui_gpu::renderer::validate_draw+0x402>
  82190e:	movss  0x4(%r15),%xmm14
  821914:	jmp    82192d <gpui_gpu::renderer::validate_draw+0x2ed>
  821916:	movss  0x4(%r15),%xmm14
  82191c:	xorpd  %xmm13,%xmm13
  821921:	ucomiss %xmm13,%xmm14
  821925:	jne    82192d <gpui_gpu::renderer::validate_draw+0x2ed>
  821927:	jnp    821b67 <gpui_gpu::renderer::validate_draw+0x527>
  82192d:	movd   %xmm14,%edi
  821932:	test   %edi,%edi
  821934:	sets   %r8b
  821938:	and    $0x7fffffff,%edi
  82193e:	lea    -0x800000(%rdi),%r9d
  821945:	cmp    $0x7f000000,%r9d
  82194c:	setb   %r9b
  821950:	and    %r8b,%r9b
  821953:	lea    -0x1(%rdi),%r10d
  821957:	cmp    $0x7fffff,%r10d
  82195e:	setb   %r10b
  821962:	and    %r8b,%r10b
  821965:	cmp    $0x7f800000,%edi
  82196b:	sete   %dil
  82196f:	setg   %r8b
  821973:	or     %dil,%r8b
  821976:	or     %r10b,%r8b
  821979:	or     %r9b,%r8b
  82197c:	cmp    $0x1,%r8b
  821980:	je     8216d7 <gpui_gpu::renderer::validate_draw+0x97>
  821986:	movaps %xmm11,(%rsp)
  82198b:	movaps %xmm14,%xmm11
  82198f:	movaps %xmm14,0x10(%rsp)
  821995:	movaps %xmm12,%xmm14
  821999:	mulss  -0x7729d6(%rip),%xmm14        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  8219a2:	minss  %xmm14,%xmm11
  8219a7:	movaps %xmm11,%xmm14
  8219ab:	cmpunordss %xmm11,%xmm14
  8219b1:	movaps %xmm14,%xmm13
  8219b5:	andnps %xmm11,%xmm13
  8219b9:	andps  0x10(%rsp),%xmm14
  8219bf:	orps   %xmm13,%xmm14
  8219c3:	shufps $0x55,%xmm12,%xmm12
  8219c8:	mulss  -0x772a05(%rip),%xmm12        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  8219d1:	movaps %xmm14,%xmm11
  8219d5:	minss  %xmm12,%xmm11
  8219da:	movaps %xmm11,%xmm12
  8219de:	cmpunordss %xmm11,%xmm12
  8219e4:	andps  %xmm12,%xmm14
  8219e8:	andnps %xmm11,%xmm12
  8219ec:	orps   %xmm14,%xmm12
  8219f0:	movss  -0x772749(%rip),%xmm11        # af2b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  8219f9:	ucomiss %xmm12,%xmm11
  8219fd:	ja     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821a03:	xorps  %xmm14,%xmm14
  821a07:	cvtss2sd %xmm12,%xmm14
  821a0c:	movapd %xmm9,%xmm11
  821a11:	divsd  %xmm14,%xmm11
  821a16:	ucomisd -0x77213f(%rip),%xmm11        # af8e0 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  821a1f:	ja     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821a25:	addsd  %xmm9,%xmm14
  821a2a:	mulsd  -0x7722ab(%rip),%xmm14        # af788 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821a33:	movapd (%rsp),%xmm11
  821a39:	movapd -0x776c12(%rip),%xmm13        # aae30 <GCC_except_table0+0x90>
  821a42:	cmp    $0x2,%esi
  821a45:	movaps %xmm11,(%rsp)
  821a4a:	jae    821b5b <gpui_gpu::renderer::validate_draw+0x51b>
  821a50:	cvtps2pd %xmm8,%xmm8
  821a54:	subpd  %xmm8,%xmm5
  821a59:	cvtps2pd %xmm7,%xmm7
  821a5c:	andpd  %xmm13,%xmm5
  821a61:	mulpd  0x40(%rsp),%xmm5
  821a67:	subpd  %xmm7,%xmm4
  821a6b:	andpd  %xmm13,%xmm4
  821a70:	mulpd  0x50(%rsp),%xmm4
  821a76:	addpd  %xmm5,%xmm4
  821a7a:	cvtps2pd %xmm6,%xmm5
  821a7d:	subpd  %xmm5,%xmm0
  821a81:	addsd  -0x7721b2(%rip),%xmm10        # af8d8 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821a8a:	mulsd  -0x771feb(%rip),%xmm10        # afaa8 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821a93:	andpd  %xmm13,%xmm0
  821a98:	addpd  %xmm4,%xmm0
  821a9c:	movapd 0x60(%rsp),%xmm7
  821aa2:	addsd  %xmm7,%xmm15
  821aa7:	movapd (%rsp),%xmm6
  821aac:	addsd  %xmm6,%xmm15
  821ab1:	addsd  0x30(%rsp),%xmm15
  821ab8:	movapd %xmm0,%xmm4
  821abc:	unpckhpd %xmm0,%xmm4
  821ac0:	addpd  %xmm0,%xmm4
  821ac4:	movapd %xmm1,%xmm5
  821ac8:	shufpd $0x1,%xmm4,%xmm5
  821acd:	movapd %xmm2,%xmm4
  821ad1:	unpcklpd %xmm10,%xmm4
  821ad6:	addpd  %xmm4,%xmm5
  821ada:	mulsd  -0x77242b(%rip),%xmm15        # af6b8 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821ae3:	shufpd $0x1,%xmm15,%xmm2
  821ae9:	addpd  %xmm5,%xmm2
  821aed:	unpcklpd %xmm14,%xmm1
  821af2:	addpd  %xmm2,%xmm1
  821af6:	movapd %xmm1,%xmm2
  821afa:	unpckhpd %xmm1,%xmm2
  821afe:	mulsd  %xmm1,%xmm2
  821b02:	andpd  -0x776cda(%rip),%xmm3        # aae30 <GCC_except_table0+0x90>
  821b0a:	divsd  %xmm3,%xmm2
  821b0e:	movq   %xmm2,%rdx
  821b13:	and    %rax,%rdx
  821b16:	cmp    %rcx,%rdx
  821b19:	jg     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821b1f:	ucomisd -0x771c1f(%rip),%xmm2        # aff08 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821b27:	ja     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821b2d:	unpcklpd %xmm10,%xmm10
  821b32:	addpd  %xmm10,%xmm0
  821b37:	addpd  %xmm7,%xmm6
  821b3b:	mulpd  -0x776b33(%rip),%xmm6        # ab010 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821b43:	addpd  %xmm0,%xmm6
  821b47:	cvtpd2ps %xmm6,%xmm0
  821b4b:	movlpd %xmm0,0x4(%rbx)
  821b50:	movl   $0xffffffff,(%rbx)
  821b56:	jmp    8216dd <gpui_gpu::renderer::validate_draw+0x9d>
  821b5b:	jne    821b70 <gpui_gpu::renderer::validate_draw+0x530>
  821b5d:	mov    0x28(%r15),%rsi
  821b61:	mov    0x30(%r15),%rdi
  821b65:	jmp    821b78 <gpui_gpu::renderer::validate_draw+0x538>
  821b67:	movaps %xmm11,(%rsp)
  821b6c:	xorps  %xmm14,%xmm14
  821b70:	mov    0x28(%r15),%esi
  821b74:	mov    0x2c(%r15),%edi
  821b78:	movq   %rsi,%xmm11
  821b7d:	punpckldq -0x776236(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821b86:	subpd  -0x776d6f(%rip),%xmm11        # aae20 <GCC_except_table0+0x80>
  821b8f:	movapd %xmm11,%xmm12
  821b94:	unpckhpd %xmm11,%xmm12
  821b99:	addsd  %xmm11,%xmm12
  821b9e:	movapd 0x20(%rsp),%xmm11
  821ba5:	divsd  %xmm11,%xmm12
  821baa:	movq   %xmm12,%r8
  821baf:	and    %rax,%r8
  821bb2:	cmp    %rdx,%r8
  821bb5:	jge    8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821bbb:	movaps %xmm14,0x10(%rsp)
  821bc1:	movapd %xmm11,%xmm14
  821bc6:	movq   %rdi,%xmm11
  821bcb:	punpckldq -0x776284(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821bd4:	subpd  -0x776dbd(%rip),%xmm11        # aae20 <GCC_except_table0+0x80>
  821bdd:	movapd %xmm11,%xmm13
  821be2:	unpckhpd %xmm11,%xmm13
  821be7:	addsd  %xmm11,%xmm13
  821bec:	unpckhpd %xmm14,%xmm14
  821bf1:	divsd  %xmm14,%xmm13
  821bf6:	movapd 0x10(%rsp),%xmm14
  821bfd:	movq   %xmm13,%rdx
  821c02:	and    %rax,%rdx
  821c05:	cmp    %rcx,%rdx
  821c08:	setg   %dl
  821c0b:	ucomisd -0x77259c(%rip),%xmm13        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c14:	movapd -0x776ded(%rip),%xmm13        # aae30 <GCC_except_table0+0x90>
  821c1d:	ja     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821c23:	ucomisd -0x7725b4(%rip),%xmm12        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c2c:	ja     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821c32:	test   %dl,%dl
  821c34:	jne    8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821c3a:	cmp    %rsi,%rdi
  821c3d:	cmova  %rdi,%rsi
  821c41:	movq   %rsi,%xmm11
  821c46:	punpckldq -0x7762ff(%rip),%xmm11        # ab950 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821c4f:	subpd  -0x776e38(%rip),%xmm11        # aae20 <GCC_except_table0+0x80>
  821c58:	movapd %xmm11,%xmm12
  821c5d:	unpckhpd %xmm11,%xmm12
  821c62:	addsd  %xmm11,%xmm12
  821c67:	mulsd  %xmm12,%xmm9
  821c6c:	ucomisd -0x7725fd(%rip),%xmm9        # af678 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c75:	ja     8217c2 <gpui_gpu::renderer::validate_draw+0x182>
  821c7b:	jmp    821a50 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822390 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  822390:	push   %rbp
  822391:	push   %r15
  822393:	push   %r14
  822395:	push   %r13
  822397:	push   %r12
  822399:	push   %rbx
  82239a:	sub    $0x58,%rsp
  82239e:	mov    %ecx,%ebp
  8223a0:	mov    %rdx,0x8(%rsp)
  8223a5:	mov    0x18(%rdi),%rax
  8223a9:	add    %rax,%rsi
  8223ac:	jb     8224c1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8223b2:	mov    %rdi,%rbx
  8223b5:	mov    0x8(%rdi),%r15
  8223b9:	lea    0x1(%r15),%rdx
  8223bd:	mov    %rdx,%rdi
  8223c0:	shr    $0x3,%rdi
  8223c4:	mov    %rdx,%rcx
  8223c7:	and    $0xfffffffffffffff8,%rcx
  8223cb:	sub    %rdi,%rcx
  8223ce:	cmp    $0x8,%r15
  8223d2:	cmovb  %r15,%rcx
  8223d6:	mov    %rcx,%rdi
  8223d9:	shr    $1,%rdi
  8223dc:	cmp    %rdi,%rsi
  8223df:	jbe    822410 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  8223e1:	inc    %rcx
  8223e4:	cmp    %rsi,%rcx
  8223e7:	cmovbe %rsi,%rcx
  8223eb:	cmp    $0xf,%rcx
  8223ef:	mov    %rbx,(%rsp)
  8223f3:	jae    822441 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  8223f5:	mov    %ecx,%eax
  8223f7:	and    $0x8,%eax
  8223fa:	add    $0x8,%rax
  8223fe:	cmp    $0x4,%rcx
  822402:	mov    $0x4,%ebx
  822407:	cmovae %rax,%rbx
  82240b:	jmp    822499 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  822410:	test   %rdx,%rdx
  822413:	je     82269a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  822419:	mov    (%rbx),%rsi
  82241c:	mov    %rdx,%rax
  82241f:	shr    $0x4,%rax
  822423:	mov    %edx,%ecx
  822425:	and    $0xf,%ecx
  822428:	cmp    $0x1,%rcx
  82242c:	sbb    $0xffffffffffffffff,%rax
  822430:	cmp    $0x1,%rax
  822434:	jne    8226a1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  82243a:	xor    %ecx,%ecx
  82243c:	jmp    8226f4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  822441:	movabs $0x1ffffffffffffffe,%rax
  82244b:	inc    %rax
  82244e:	cmp    %rax,%rcx
  822451:	ja     8224c1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822453:	shl    $0x3,%rcx
  822457:	movabs $0x2492492492492493,%rdx
  822461:	mov    %rcx,%rax
  822464:	mul    %rdx
  822467:	sub    %rdx,%rcx
  82246a:	shr    $1,%rcx
  82246d:	add    %rdx,%rcx
  822470:	shr    $0x2,%rcx
  822474:	dec    %rcx
  822477:	bsr    %rcx,%rcx
  82247b:	not    %ecx
  82247d:	mov    $0xffffffffffffffff,%rbx
  822484:	shr    %cl,%rbx
  822487:	movabs $0x7fffffffffffffe,%rax
  822491:	cmp    %rax,%rbx
  822494:	ja     8224c1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  822496:	inc    %rbx
  822499:	mov    %rbx,%r14
  82249c:	shl    $0x5,%r14
  8224a0:	lea    0x10(%rbx),%r12
  8224a4:	mov    %r12,%r13
  8224a7:	add    %r14,%r13
  8224aa:	setb   %al
  8224ad:	movabs $0x7ffffffffffffff0,%rcx
  8224b7:	cmp    %rcx,%r13
  8224ba:	seta   %cl
  8224bd:	or     %al,%cl
  8224bf:	je     8224d0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  8224c1:	movzbl %bpl,%edi
  8224c5:	call   *0x65dce5(%rip)        # e801b0 <_DYNAMIC+0x678>
  8224cb:	jmp    822915 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8224d0:	call   *0x65d8f2(%rip)        # e7fdc8 <_DYNAMIC+0x290>
  8224d6:	mov    $0x10,%esi
  8224db:	mov    %r13,%rdi
  8224de:	call   *0x65d8ec(%rip)        # e7fdd0 <_DYNAMIC+0x298>
  8224e4:	test   %rax,%rax
  8224e7:	je     822933 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  8224ed:	mov    %rax,%r15
  8224f0:	mov    (%rsp),%rcx
  8224f4:	lea    0x20(%rcx),%r13
  8224f8:	add    %r14,%r15
  8224fb:	lea    -0x1(%rbx),%r14
  8224ff:	mov    %rbx,%rax
  822502:	shr    $0x3,%rax
  822506:	mov    %rbx,%rbp
  822509:	and    $0xfffffffffffffff8,%rbp
  82250d:	sub    %rax,%rbp
  822510:	cmp    $0x9,%rbx
  822514:	mov    %rcx,%rbx
  822517:	cmovb  %r14,%rbp
  82251b:	mov    %r15,%rdi
  82251e:	mov    $0xff,%esi
  822523:	mov    %r12,%rdx
  822526:	call   *0x65dc8c(%rip)        # e801b8 <memset@GLIBC_2.2.5>
  82252c:	mov    %r14,%rdi
  82252f:	mov    %r13,0x20(%rsp)
  822534:	movq   $0x20,0x28(%rsp)
  82253d:	movq   $0x10,0x30(%rsp)
  822546:	mov    %r15,0x38(%rsp)
  82254b:	mov    %r14,0x40(%rsp)
  822550:	mov    %rbp,0x48(%rsp)
  822555:	movq   $0x0,0x50(%rsp)
  82255e:	mov    0x18(%rbx),%r12
  822562:	test   %r12,%r12
  822565:	je     822947 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82256b:	mov    %rbp,0x10(%rsp)
  822570:	mov    (%rbx),%rsi
  822573:	movdqa (%rsi),%xmm0
  822577:	pmovmskb %xmm0,%r13d
  82257c:	not    %r13d
  82257f:	xor    %ebp,%ebp
  822581:	mov    %rsi,%r14
  822584:	mov    %rdi,0x18(%rsp)
  822589:	nopl   0x0(%rax)
  822590:	test   %r13w,%r13w
  822594:	jne    8225bf <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  822596:	cs nopw 0x0(%rax,%rax,1)
  8225a0:	movdqa 0x10(%r14),%xmm0
  8225a6:	add    $0x10,%r14
  8225aa:	pmovmskb %xmm0,%r13d
  8225af:	xor    $0xffff,%r13d
  8225b6:	add    $0x10,%rbp
  8225ba:	test   %r13d,%r13d
  8225bd:	je     8225a0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  8225bf:	tzcnt  %r13d,%ebx
  8225c4:	add    %rbp,%rbx
  8225c7:	mov    %rbx,%rax
  8225ca:	shl    $0x5,%rax
  8225ce:	sub    %rax,%rsi
  8225d1:	add    $0xffffffffffffffe0,%rsi
  8225d5:	mov    0x8(%rsp),%rdi
  8225da:	call   824bc0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8225df:	mov    %rax,%rdx
  8225e2:	mov    0x18(%rsp),%rdi
  8225e7:	and    %rdi,%rdx
  8225ea:	movdqu (%r15,%rdx,1),%xmm0
  8225f0:	pmovmskb %xmm0,%ecx
  8225f4:	test   %ecx,%ecx
  8225f6:	je     822665 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  8225f8:	tzcnt  %ecx,%ecx
  8225fc:	add    %rdx,%rcx
  8225ff:	and    %rdi,%rcx
  822602:	cmpb   $0x0,(%r15,%rcx,1)
  822607:	jns    822688 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  822609:	lea    -0x1(%r13),%edx
  82260d:	and    %r13d,%edx
  822610:	dec    %r12
  822613:	shr    $0x39,%rax
  822617:	lea    -0x10(%rcx),%rsi
  82261b:	and    %rdi,%rsi
  82261e:	mov    %al,(%r15,%rcx,1)
  822622:	mov    %al,0x10(%r15,%rsi,1)
  822627:	mov    (%rsp),%rax
  82262b:	mov    (%rax),%rsi
  82262e:	not    %rbx
  822631:	shl    $0x5,%rbx
  822635:	not    %rcx
  822638:	shl    $0x5,%rcx
  82263c:	movdqu (%rsi,%rbx,1),%xmm0
  822641:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  822647:	movdqu %xmm1,0x10(%r15,%rcx,1)
  82264e:	movdqu %xmm0,(%r15,%rcx,1)
  822654:	mov    %edx,%r13d
  822657:	test   %r12,%r12
  82265a:	jne    822590 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  822660:	jmp    822924 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  822665:	mov    $0x10,%esi
  82266a:	add    %rsi,%rdx
  82266d:	and    %rdi,%rdx
  822670:	movdqu (%r15,%rdx,1),%xmm0
  822676:	pmovmskb %xmm0,%ecx
  82267a:	add    $0x10,%rsi
  82267e:	test   %ecx,%ecx
  822680:	jne    8225f8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  822686:	jmp    82266a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  822688:	movdqa (%r15),%xmm0
  82268d:	pmovmskb %xmm0,%ecx
  822691:	tzcnt  %ecx,%ecx
  822695:	jmp    822609 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  82269a:	xor    %ecx,%ecx
  82269c:	jmp    822907 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  8226a1:	movabs $0x1ffffffffffffffe,%rdi
  8226ab:	and    %rax,%rdi
  8226ae:	xor    %ecx,%ecx
  8226b0:	movdqa -0x774ab8(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  8226b8:	nopl   0x0(%rax,%rax,1)
  8226c0:	pxor   %xmm1,%xmm1
  8226c4:	pcmpgtb (%rsi,%rcx,1),%xmm1
  8226c9:	por    %xmm0,%xmm1
  8226cd:	movdqa %xmm1,(%rsi,%rcx,1)
  8226d2:	pxor   %xmm1,%xmm1
  8226d6:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  8226dc:	por    %xmm0,%xmm1
  8226e0:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  8226e6:	add    $0x20,%rcx
  8226ea:	add    $0xfffffffffffffffe,%rdi
  8226ee:	jne    8226c0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  8226f0:	test   $0x1,%al
  8226f2:	je     82270a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  8226f4:	pxor   %xmm0,%xmm0
  8226f8:	pcmpgtb (%rsi,%rcx,1),%xmm0
  8226fd:	por    -0x774b05(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822705:	movdqa %xmm0,(%rsi,%rcx,1)
  82270a:	cmp    $0x10,%rdx
  82270e:	jb     822998 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  822714:	mov    %rdx,%rdi
  822717:	mov    $0x10,%edx
  82271c:	add    %rsi,%rdi
  82271f:	call   *0x65da9b(%rip)        # e801c0 <memmove@GLIBC_2.2.5>
  822725:	movq   $0x0,0x28(%rsp)
  82272e:	movq   $0x20,0x30(%rsp)
  822737:	mov    %rbx,0x20(%rsp)
  82273c:	xor    %r12d,%r12d
  82273f:	xor    %r13d,%r13d
  822742:	jmp    822891 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  822747:	nopw   0x0(%rax,%rax,1)
  822750:	lea    (%rax,%rbp,1),%rsi
  822754:	add    $0xffffffffffffffe0,%rsi
  822758:	mov    0x8(%rsp),%rdi
  82275d:	call   824bc0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  822762:	mov    (%rbx),%rcx
  822765:	mov    0x8(%rbx),%rdx
  822769:	mov    %rdx,%rsi
  82276c:	and    %rax,%rsi
  82276f:	movdqu (%rcx,%rsi,1),%xmm0
  822774:	pmovmskb %xmm0,%edi
  822778:	mov    %rsi,%r8
  82277b:	test   %edi,%edi
  82277d:	je     822829 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  822783:	tzcnt  %edi,%edi
  822787:	add    %r8,%rdi
  82278a:	and    %rdx,%rdi
  82278d:	cmpb   $0x0,(%rcx,%rdi,1)
  822791:	jns    822850 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  822797:	mov    %r12,%r8
  82279a:	sub    %rsi,%r8
  82279d:	mov    %rdi,%r9
  8227a0:	sub    %rsi,%r9
  8227a3:	xor    %r8,%r9
  8227a6:	and    %rdx,%r9
  8227a9:	cmp    $0x10,%r9
  8227ad:	jb     822870 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  8227b3:	mov    %rdi,%rsi
  8227b6:	not    %rsi
  8227b9:	shl    $0x5,%rsi
  8227bd:	add    %rcx,%rsi
  8227c0:	movzbl (%rcx,%rdi,1),%r8d
  8227c5:	shr    $0x39,%rax
  8227c9:	lea    -0x10(%rdi),%r9
  8227cd:	and    %rdx,%r9
  8227d0:	mov    %al,(%rcx,%rdi,1)
  8227d3:	mov    (%rbx),%rcx
  8227d6:	mov    %al,0x10(%rcx,%r9,1)
  8227db:	cmp    $0xff,%r8b
  8227df:	je     8228b6 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  8227e5:	mov    (%r14),%rax
  8227e8:	mov    (%rsi),%rcx
  8227eb:	mov    %rcx,(%r14)
  8227ee:	mov    %rax,(%rsi)
  8227f1:	mov    0x8(%r14),%rax
  8227f5:	mov    0x8(%rsi),%rcx
  8227f9:	mov    %rcx,0x8(%r14)
  8227fd:	mov    %rax,0x8(%rsi)
  822801:	mov    0x10(%r14),%rax
  822805:	mov    0x10(%rsi),%rcx
  822809:	mov    %rcx,0x10(%r14)
  82280d:	mov    %rax,0x10(%rsi)
  822811:	mov    0x18(%r14),%rax
  822815:	mov    0x18(%rsi),%rcx
  822819:	mov    %rcx,0x18(%r14)
  82281d:	mov    %rax,0x18(%rsi)
  822821:	mov    (%rbx),%rax
  822824:	jmp    822750 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  822829:	mov    $0x10,%r9d
  82282f:	mov    %rsi,%r8
  822832:	add    %r9,%r8
  822835:	and    %rdx,%r8
  822838:	movdqu (%rcx,%r8,1),%xmm0
  82283e:	pmovmskb %xmm0,%edi
  822842:	add    $0x10,%r9
  822846:	test   %edi,%edi
  822848:	jne    822783 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  82284e:	jmp    822832 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  822850:	movdqa (%rcx),%xmm0
  822854:	pmovmskb %xmm0,%edi
  822858:	tzcnt  %edi,%edi
  82285c:	jmp    822797 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  822861:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  822870:	shr    $0x39,%rax
  822874:	lea    -0x10(%r12),%rsi
  822879:	and    %rsi,%rdx
  82287c:	mov    %al,(%rcx,%r12,1)
  822880:	mov    (%rbx),%rcx
  822883:	mov    %al,0x10(%rcx,%rdx,1)
  822887:	cmp    %r15,%r12
  82288a:	lea    0x1(%r12),%r12
  82288f:	je     8228e5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  822891:	mov    (%rbx),%rax
  822894:	cmp    (%rax,%r12,1),%r13b
  822898:	jno    822887 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  82289a:	mov    %r12,%r14
  82289d:	not    %r14
  8228a0:	shl    $0x5,%r14
  8228a4:	add    %rax,%r14
  8228a7:	mov    %r12,%rbp
  8228aa:	neg    %rbp
  8228ad:	shl    $0x5,%rbp
  8228b1:	jmp    822750 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  8228b6:	lea    -0x10(%r12),%rax
  8228bb:	and    0x8(%rbx),%rax
  8228bf:	mov    (%rbx),%rcx
  8228c2:	movb   $0xff,(%rcx,%r12,1)
  8228c7:	mov    (%rbx),%rcx
  8228ca:	movb   $0xff,0x10(%rcx,%rax,1)
  8228cf:	movdqu (%r14),%xmm0
  8228d4:	movdqu 0x10(%r14),%xmm1
  8228da:	movdqu %xmm1,0x10(%rsi)
  8228df:	movdqu %xmm0,(%rsi)
  8228e3:	jmp    822887 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  8228e5:	mov    0x8(%rbx),%rdx
  8228e9:	mov    0x18(%rbx),%rax
  8228ed:	lea    0x1(%rdx),%rcx
  8228f1:	mov    %rcx,%rsi
  8228f4:	shr    $0x3,%rsi
  8228f8:	and    $0xfffffffffffffff8,%rcx
  8228fc:	sub    %rsi,%rcx
  8228ff:	cmp    $0x8,%rdx
  822903:	cmovb  %rdx,%rcx
  822907:	sub    %rax,%rcx
  82290a:	mov    %rcx,0x10(%rbx)
  82290e:	mov    $0xffffffffffffffff,%rax
  822915:	add    $0x58,%rsp
  822919:	pop    %rbx
  82291a:	pop    %r12
  82291c:	pop    %r13
  82291e:	pop    %r14
  822920:	pop    %r15
  822922:	pop    %rbp
  822923:	ret
  822924:	mov    (%rsp),%rbx
  822928:	mov    0x18(%rbx),%rcx
  82292c:	mov    0x10(%rsp),%rbp
  822931:	jmp    82294c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  822933:	movzbl %bpl,%edi
  822937:	mov    $0x10,%esi
  82293c:	mov    %r13,%rdx
  82293f:	call   *0x65d883(%rip)        # e801c8 <_DYNAMIC+0x690>
  822945:	jmp    822915 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  822947:	mov    (%rbx),%rsi
  82294a:	xor    %ecx,%ecx
  82294c:	sub    %rcx,%rbp
  82294f:	mov    %r15,(%rbx)
  822952:	mov    0x8(%rbx),%rax
  822956:	mov    %rdi,0x8(%rbx)
  82295a:	mov    %rbp,0x10(%rbx)
  82295e:	mov    %rcx,0x18(%rbx)
  822962:	test   %rax,%rax
  822965:	je     82290e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822967:	mov    %rax,%rcx
  82296a:	shl    $0x5,%rcx
  82296e:	add    $0x2f,%rcx
  822972:	and    $0xffffffffffffffe0,%rcx
  822976:	add    %rcx,%rax
  822979:	add    $0x11,%rax
  82297d:	je     82290e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  82297f:	sub    %rcx,%rsi
  822982:	mov    $0x10,%edx
  822987:	mov    %rsi,%rdi
  82298a:	mov    %rax,%rsi
  82298d:	call   *0x65d3ed(%rip)        # e7fd80 <_DYNAMIC+0x248>
  822993:	jmp    82290e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  822998:	mov    $0x10,%edi
  82299d:	jmp    82271c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  8229a2:	mov    %rax,%rbx
  8229a5:	lea    0x20(%rsp),%rdi
  8229aa:	call   822f80 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  8229af:	mov    %rbx,%rdi
  8229b2:	call   e2c890 <_Unwind_Resume@plt>
  8229b7:	mov    %rax,%rbx
  8229ba:	lea    0x20(%rsp),%rdi
  8229bf:	call   822fc0 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  8229c4:	mov    %rbx,%rdi
  8229c7:	call   e2c890 <_Unwind_Resume@plt>
  8229cc:	call   *0x65d3b6(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008229e0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  8229e0:	push   %rbp
  8229e1:	push   %r15
  8229e3:	push   %r14
  8229e5:	push   %r13
  8229e7:	push   %r12
  8229e9:	push   %rbx
  8229ea:	sub    $0x38,%rsp
  8229ee:	mov    %ecx,%r15d
  8229f1:	mov    %rdx,0x20(%rsp)
  8229f6:	mov    %rdi,%rbp
  8229f9:	mov    0x18(%rdi),%rdi
  8229fd:	add    %rdi,%rsi
  822a00:	jb     822b18 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822a06:	mov    0x8(%rbp),%rbx
  822a0a:	lea    0x1(%rbx),%rdx
  822a0e:	mov    %rdx,%rax
  822a11:	shr    $0x3,%rax
  822a15:	mov    %rdx,%rcx
  822a18:	and    $0xfffffffffffffff8,%rcx
  822a1c:	sub    %rax,%rcx
  822a1f:	cmp    $0x8,%rbx
  822a23:	cmovb  %rbx,%rcx
  822a27:	mov    %rcx,%rax
  822a2a:	shr    $1,%rax
  822a2d:	cmp    %rax,%rsi
  822a30:	jbe    822a66 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  822a32:	inc    %rcx
  822a35:	cmp    %rsi,%rcx
  822a38:	cmovbe %rsi,%rcx
  822a3c:	cmp    $0xf,%rcx
  822a40:	mov    %rbp,(%rsp)
  822a44:	mov    %rbx,0x30(%rsp)
  822a49:	jae    822a98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  822a4b:	mov    %ecx,%eax
  822a4d:	and    $0x8,%eax
  822a50:	add    $0x8,%rax
  822a54:	cmp    $0x4,%rcx
  822a58:	mov    $0x4,%ebx
  822a5d:	cmovae %rax,%rbx
  822a61:	jmp    822af0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  822a66:	test   %rdx,%rdx
  822a69:	je     822cae <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  822a6f:	mov    0x0(%rbp),%r12
  822a73:	mov    %rdx,%rax
  822a76:	shr    $0x4,%rax
  822a7a:	mov    %edx,%ecx
  822a7c:	and    $0xf,%ecx
  822a7f:	cmp    $0x1,%rcx
  822a83:	sbb    $0xffffffffffffffff,%rax
  822a87:	cmp    $0x1,%rax
  822a8b:	jne    822cb5 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  822a91:	xor    %ecx,%ecx
  822a93:	jmp    822d08 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  822a98:	movabs $0x1ffffffffffffffe,%rax
  822aa2:	inc    %rax
  822aa5:	cmp    %rax,%rcx
  822aa8:	ja     822b18 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822aaa:	shl    $0x3,%rcx
  822aae:	movabs $0x2492492492492493,%rdx
  822ab8:	mov    %rcx,%rax
  822abb:	mul    %rdx
  822abe:	sub    %rdx,%rcx
  822ac1:	shr    $1,%rcx
  822ac4:	add    %rdx,%rcx
  822ac7:	shr    $0x2,%rcx
  822acb:	dec    %rcx
  822ace:	bsr    %rcx,%rcx
  822ad2:	not    %ecx
  822ad4:	mov    $0xffffffffffffffff,%rbx
  822adb:	shr    %cl,%rbx
  822ade:	movabs $0xffffffffffffffe,%rax
  822ae8:	cmp    %rax,%rbx
  822aeb:	ja     822b18 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  822aed:	inc    %rbx
  822af0:	mov    %rbx,%r14
  822af3:	shl    $0x4,%r14
  822af7:	lea    0x10(%rbx),%rbp
  822afb:	mov    %rbp,%r13
  822afe:	add    %r14,%r13
  822b01:	setb   %al
  822b04:	movabs $0x7ffffffffffffff0,%rcx
  822b0e:	cmp    %rcx,%r13
  822b11:	seta   %cl
  822b14:	or     %al,%cl
  822b16:	je     822b27 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  822b18:	movzbl %r15b,%edi
  822b1c:	call   *0x65d68e(%rip)        # e801b0 <_DYNAMIC+0x678>
  822b22:	jmp    822ee8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822b27:	mov    %rdi,0x8(%rsp)
  822b2c:	call   *0x65d296(%rip)        # e7fdc8 <_DYNAMIC+0x290>
  822b32:	mov    $0x10,%esi
  822b37:	mov    %r13,%rdi
  822b3a:	call   *0x65d290(%rip)        # e7fdd0 <_DYNAMIC+0x298>
  822b40:	test   %rax,%rax
  822b43:	je     822f02 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  822b49:	mov    %rax,%rdi
  822b4c:	add    %r14,%rdi
  822b4f:	lea    -0x1(%rbx),%rcx
  822b53:	mov    %rbx,%rax
  822b56:	shr    $0x3,%rax
  822b5a:	mov    %rbx,%r14
  822b5d:	and    $0xfffffffffffffff8,%r14
  822b61:	sub    %rax,%r14
  822b64:	cmp    $0x9,%rbx
  822b68:	mov    %rcx,0x10(%rsp)
  822b6d:	cmovb  %rcx,%r14
  822b71:	mov    %rdi,0x18(%rsp)
  822b76:	mov    $0xff,%esi
  822b7b:	mov    %rbp,%rdx
  822b7e:	call   *0x65d634(%rip)        # e801b8 <memset@GLIBC_2.2.5>
  822b84:	mov    0x8(%rsp),%rbx
  822b89:	test   %rbx,%rbx
  822b8c:	je     822f16 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  822b92:	mov    %r14,0x28(%rsp)
  822b97:	mov    (%rsp),%rax
  822b9b:	mov    (%rax),%rdi
  822b9e:	movdqa (%rdi),%xmm0
  822ba2:	pmovmskb %xmm0,%r14d
  822ba7:	not    %r14d
  822baa:	xor    %ebp,%ebp
  822bac:	mov    %rdi,%r13
  822baf:	nop
  822bb0:	test   %r14w,%r14w
  822bb4:	jne    822bdf <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  822bb6:	cs nopw 0x0(%rax,%rax,1)
  822bc0:	movdqa 0x10(%r13),%xmm0
  822bc6:	add    $0x10,%r13
  822bca:	pmovmskb %xmm0,%r14d
  822bcf:	xor    $0xffff,%r14d
  822bd6:	add    $0x10,%rbp
  822bda:	test   %r14d,%r14d
  822bdd:	je     822bc0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  822bdf:	tzcnt  %r14d,%r15d
  822be4:	add    %rbp,%r15
  822be7:	mov    %r15,%rax
  822bea:	shl    $0x4,%rax
  822bee:	mov    %rdi,%r12
  822bf1:	mov    %rdi,%rsi
  822bf4:	sub    %rax,%rsi
  822bf7:	add    $0xfffffffffffffff0,%rsi
  822bfb:	mov    0x20(%rsp),%rdi
  822c00:	call   824d60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822c05:	mov    %rax,%rcx
  822c08:	mov    0x10(%rsp),%r9
  822c0d:	and    %r9,%rcx
  822c10:	mov    0x18(%rsp),%r8
  822c15:	movdqu (%r8,%rcx,1),%xmm0
  822c1b:	pmovmskb %xmm0,%edx
  822c1f:	test   %edx,%edx
  822c21:	je     822c80 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  822c23:	tzcnt  %edx,%edx
  822c27:	add    %rcx,%rdx
  822c2a:	and    %r9,%rdx
  822c2d:	cmpb   $0x0,(%r8,%rdx,1)
  822c32:	mov    %r12,%rdi
  822c35:	jns    822c9f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  822c37:	lea    -0x1(%r14),%ecx
  822c3b:	and    %r14d,%ecx
  822c3e:	dec    %rbx
  822c41:	shr    $0x39,%rax
  822c45:	lea    -0x10(%rdx),%rsi
  822c49:	and    %r9,%rsi
  822c4c:	mov    %al,(%r8,%rdx,1)
  822c50:	mov    %al,0x10(%r8,%rsi,1)
  822c55:	not    %r15
  822c58:	shl    $0x4,%r15
  822c5c:	not    %rdx
  822c5f:	shl    $0x4,%rdx
  822c63:	movdqu (%rdi,%r15,1),%xmm0
  822c69:	movdqu %xmm0,(%r8,%rdx,1)
  822c6f:	mov    %ecx,%r14d
  822c72:	test   %rbx,%rbx
  822c75:	jne    822bb0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  822c7b:	jmp    822ef7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  822c80:	mov    $0x10,%esi
  822c85:	add    %rsi,%rcx
  822c88:	and    %r9,%rcx
  822c8b:	movdqu (%r8,%rcx,1),%xmm0
  822c91:	pmovmskb %xmm0,%edx
  822c95:	add    $0x10,%rsi
  822c99:	test   %edx,%edx
  822c9b:	jne    822c23 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  822c9d:	jmp    822c85 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  822c9f:	movdqa (%r8),%xmm0
  822ca4:	pmovmskb %xmm0,%ecx
  822ca8:	tzcnt  %ecx,%edx
  822cac:	jmp    822c37 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  822cae:	xor    %eax,%eax
  822cb0:	jmp    822eda <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  822cb5:	movabs $0x1ffffffffffffffe,%rsi
  822cbf:	and    %rax,%rsi
  822cc2:	xor    %ecx,%ecx
  822cc4:	movdqa -0x7750cc(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822ccc:	nopl   0x0(%rax)
  822cd0:	pxor   %xmm1,%xmm1
  822cd4:	pcmpgtb (%r12,%rcx,1),%xmm1
  822cda:	por    %xmm0,%xmm1
  822cde:	movdqa %xmm1,(%r12,%rcx,1)
  822ce4:	pxor   %xmm1,%xmm1
  822ce8:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  822cef:	por    %xmm0,%xmm1
  822cf3:	movdqa %xmm1,0x10(%r12,%rcx,1)
  822cfa:	add    $0x20,%rcx
  822cfe:	add    $0xfffffffffffffffe,%rsi
  822d02:	jne    822cd0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  822d04:	test   $0x1,%al
  822d06:	je     822d20 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  822d08:	pxor   %xmm0,%xmm0
  822d0c:	pcmpgtb (%r12,%rcx,1),%xmm0
  822d12:	por    -0x77511a(%rip),%xmm0        # adc00 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x820>
  822d1a:	movdqa %xmm0,(%r12,%rcx,1)
  822d20:	cmp    $0x10,%rdx
  822d24:	jb     822f73 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  822d2a:	mov    %rdx,%rdi
  822d2d:	mov    $0x10,%edx
  822d32:	add    %r12,%rdi
  822d35:	mov    %r12,%rsi
  822d38:	call   *0x65d482(%rip)        # e801c0 <memmove@GLIBC_2.2.5>
  822d3e:	xor    %r13d,%r13d
  822d41:	xor    %eax,%eax
  822d43:	jmp    822e76 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  822d48:	nopl   0x0(%rax,%rax,1)
  822d50:	lea    (%r12,%r14,1),%rsi
  822d54:	add    $0xfffffffffffffff0,%rsi
  822d58:	mov    0x20(%rsp),%rdi
  822d5d:	call   824d60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  822d62:	mov    0x8(%rbp),%rcx
  822d66:	mov    %rcx,%rdx
  822d69:	and    %rax,%rdx
  822d6c:	movdqu (%r12,%rdx,1),%xmm0
  822d72:	pmovmskb %xmm0,%esi
  822d76:	mov    %rdx,%rdi
  822d79:	test   %esi,%esi
  822d7b:	je     822e0b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  822d81:	tzcnt  %esi,%esi
  822d85:	add    %rdi,%rsi
  822d88:	and    %rcx,%rsi
  822d8b:	cmpb   $0x0,(%r12,%rsi,1)
  822d90:	jns    822e32 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  822d96:	mov    %r13,%rdi
  822d99:	sub    %rdx,%rdi
  822d9c:	mov    %rsi,%r8
  822d9f:	sub    %rdx,%r8
  822da2:	xor    %rdi,%r8
  822da5:	and    %rcx,%r8
  822da8:	cmp    $0x10,%r8
  822dac:	jb     822e50 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  822db2:	mov    %rsi,%rdx
  822db5:	not    %rdx
  822db8:	shl    $0x4,%rdx
  822dbc:	add    %r12,%rdx
  822dbf:	movzbl (%r12,%rsi,1),%edi
  822dc4:	shr    $0x39,%rax
  822dc8:	lea    -0x10(%rsi),%r8
  822dcc:	and    %rcx,%r8
  822dcf:	mov    %al,(%r12,%rsi,1)
  822dd3:	mov    0x0(%rbp),%r12
  822dd7:	mov    %al,0x10(%r12,%r8,1)
  822ddc:	cmp    $0xff,%dil
  822de0:	je     822e9b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  822de6:	mov    (%rbx),%rax
  822de9:	mov    (%rdx),%rcx
  822dec:	mov    %rcx,(%rbx)
  822def:	mov    %rax,(%rdx)
  822df2:	mov    0x8(%rbx),%rax
  822df6:	mov    0x8(%rdx),%rcx
  822dfa:	mov    %rcx,0x8(%rbx)
  822dfe:	mov    %rax,0x8(%rdx)
  822e02:	mov    0x0(%rbp),%r12
  822e06:	jmp    822d50 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822e0b:	mov    $0x10,%r8d
  822e11:	mov    %rdx,%rdi
  822e14:	add    %r8,%rdi
  822e17:	and    %rcx,%rdi
  822e1a:	movdqu (%r12,%rdi,1),%xmm0
  822e20:	pmovmskb %xmm0,%esi
  822e24:	add    $0x10,%r8
  822e28:	test   %esi,%esi
  822e2a:	jne    822d81 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  822e30:	jmp    822e14 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  822e32:	movdqa (%r12),%xmm0
  822e38:	pmovmskb %xmm0,%esi
  822e3c:	tzcnt  %esi,%esi
  822e40:	jmp    822d96 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  822e45:	data16 cs nopw 0x0(%rax,%rax,1)
  822e50:	shr    $0x39,%rax
  822e54:	lea    -0x10(%r13),%rdx
  822e58:	and    %rdx,%rcx
  822e5b:	mov    %al,(%r12,%r13,1)
  822e5f:	mov    0x0(%rbp),%r12
  822e63:	mov    %al,0x10(%r12,%rcx,1)
  822e68:	mov    %r15,%rbx
  822e6b:	xor    %eax,%eax
  822e6d:	cmp    %rbx,%r13
  822e70:	lea    0x1(%r13),%r13
  822e74:	je     822eb8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  822e76:	cmp    (%r12,%r13,1),%al
  822e7a:	jno    822e6d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  822e7c:	mov    %rbx,%r15
  822e7f:	mov    %r13,%rbx
  822e82:	not    %rbx
  822e85:	shl    $0x4,%rbx
  822e89:	add    %r12,%rbx
  822e8c:	mov    %r13,%r14
  822e8f:	neg    %r14
  822e92:	shl    $0x4,%r14
  822e96:	jmp    822d50 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  822e9b:	lea    -0x10(%r13),%rax
  822e9f:	and    0x8(%rbp),%rax
  822ea3:	movb   $0xff,(%r12,%r13,1)
  822ea8:	movb   $0xff,0x10(%r12,%rax,1)
  822eae:	movdqu (%rbx),%xmm0
  822eb2:	movdqu %xmm0,(%rdx)
  822eb6:	jmp    822e68 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  822eb8:	mov    0x8(%rbp),%rcx
  822ebc:	mov    0x18(%rbp),%rdi
  822ec0:	lea    0x1(%rcx),%rax
  822ec4:	mov    %rax,%rdx
  822ec7:	shr    $0x3,%rdx
  822ecb:	and    $0xfffffffffffffff8,%rax
  822ecf:	sub    %rdx,%rax
  822ed2:	cmp    $0x8,%rcx
  822ed6:	cmovb  %rcx,%rax
  822eda:	sub    %rdi,%rax
  822edd:	mov    %rax,0x10(%rbp)
  822ee1:	mov    $0xffffffffffffffff,%rax
  822ee8:	add    $0x38,%rsp
  822eec:	pop    %rbx
  822eed:	pop    %r12
  822eef:	pop    %r13
  822ef1:	pop    %r14
  822ef3:	pop    %r15
  822ef5:	pop    %rbp
  822ef6:	ret
  822ef7:	mov    (%rsp),%rax
  822efb:	mov    0x28(%rsp),%r14
  822f00:	jmp    822f27 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  822f02:	movzbl %r15b,%edi
  822f06:	mov    $0x10,%esi
  822f0b:	mov    %r13,%rdx
  822f0e:	call   *0x65d2b4(%rip)        # e801c8 <_DYNAMIC+0x690>
  822f14:	jmp    822ee8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822f16:	mov    (%rsp),%rax
  822f1a:	mov    (%rax),%rdi
  822f1d:	mov    0x18(%rsp),%r8
  822f22:	mov    0x10(%rsp),%r9
  822f27:	sub    0x8(%rsp),%r14
  822f2c:	mov    %r8,(%rax)
  822f2f:	mov    %r9,0x8(%rax)
  822f33:	mov    %r14,0x10(%rax)
  822f37:	mov    $0xffffffffffffffff,%rax
  822f3e:	mov    0x30(%rsp),%rsi
  822f43:	test   %rsi,%rsi
  822f46:	je     822ee8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822f48:	mov    %rsi,%rcx
  822f4b:	shl    $0x4,%rcx
  822f4f:	add    $0x1f,%rcx
  822f53:	and    $0xfffffffffffffff0,%rcx
  822f57:	add    %rcx,%rsi
  822f5a:	add    $0x11,%rsi
  822f5e:	je     822ee8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  822f60:	sub    %rcx,%rdi
  822f63:	mov    $0x10,%edx
  822f68:	call   *0x65ce12(%rip)        # e7fd80 <_DYNAMIC+0x248>
  822f6e:	jmp    822ee1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  822f73:	mov    $0x10,%edi
  822f78:	jmp    822d32 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823130 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  823130:	mov    0x8(%rdi),%rsi
  823134:	test   %rsi,%rsi
  823137:	je     82315e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  823139:	mov    %rsi,%rax
  82313c:	shl    $0x5,%rax
  823140:	add    %rax,%rsi
  823143:	add    $0x31,%rsi
  823147:	je     82315e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  823149:	mov    (%rdi),%rdi
  82314c:	sub    %rax,%rdi
  82314f:	add    $0xffffffffffffffe0,%rdi
  823153:	mov    $0x10,%edx
  823158:	jmp    *0x65cc22(%rip)        # e7fd80 <_DYNAMIC+0x248>
  82315e:	ret

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823160 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  823160:	push   %rbx
  823161:	test   %rdi,%rdi
  823164:	je     8231c7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  823166:	mov    %rdi,%rbx
  823169:	mov    (%rdi),%rsi
  82316c:	test   %rsi,%rsi
  82316f:	je     823184 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  823171:	mov    0x8(%rbx),%rdi
  823175:	shl    $0x3,%rsi
  823179:	mov    $0x8,%edx
  82317e:	call   *0x65cbfc(%rip)        # e7fd80 <_DYNAMIC+0x248>
  823184:	mov    0x20(%rbx),%rsi
  823188:	test   %rsi,%rsi
  82318b:	je     8231b3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82318d:	mov    %rsi,%rax
  823190:	shl    $0x4,%rax
  823194:	add    %rax,%rsi
  823197:	add    $0x21,%rsi
  82319b:	je     8231b3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82319d:	mov    0x18(%rbx),%rdi
  8231a1:	sub    %rax,%rdi
  8231a4:	add    $0xfffffffffffffff0,%rdi
  8231a8:	mov    $0x10,%edx
  8231ad:	call   *0x65cbcd(%rip)        # e7fd80 <_DYNAMIC+0x248>
  8231b3:	mov    $0x80,%esi
  8231b8:	mov    $0x8,%edx
  8231bd:	mov    %rbx,%rdi
  8231c0:	pop    %rbx
  8231c1:	jmp    *0x65cbb9(%rip)        # e7fd80 <_DYNAMIC+0x248>
  8231c7:	pop    %rbx
  8231c8:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008233f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8233f0:	push   %r14
  8233f2:	push   %rbx
  8233f3:	push   %rax
  8233f4:	mov    %rdi,%rbx
  8233f7:	mov    (%rdi),%rax
  8233fa:	lock decq (%rax)
  8233fe:	jne    823409 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  823400:	mov    %rbx,%rdi
  823403:	call   *0x65cc37(%rip)        # e80040 <_DYNAMIC+0x508>
  823409:	mov    0x8(%rbx),%rax
  82340d:	lock decq (%rax)
  823411:	jne    823427 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  823413:	add    $0x8,%rbx
  823417:	mov    %rbx,%rdi
  82341a:	add    $0x8,%rsp
  82341e:	pop    %rbx
  82341f:	pop    %r14
  823421:	jmp    *0x65cc21(%rip)        # e80048 <_DYNAMIC+0x510>
  823427:	add    $0x8,%rsp
  82342b:	pop    %rbx
  82342c:	pop    %r14
  82342e:	ret
  82342f:	mov    %rax,%r14
  823432:	mov    0x8(%rbx),%rax
  823436:	lock decq (%rax)
  82343a:	jne    823449 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  82343c:	add    $0x8,%rbx
  823440:	mov    %rbx,%rdi
  823443:	call   *0x65cbff(%rip)        # e80048 <_DYNAMIC+0x510>
  823449:	mov    %r14,%rdi
  82344c:	call   e2c890 <_Unwind_Resume@plt>
  823451:	call   *0x65c931(%rip)        # e7fd88 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823520 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  823520:	push   %rbx
  823521:	mov    %rdi,%rbx
  823524:	mov    (%rdi),%rsi
  823527:	test   %rsi,%rsi
  82352a:	je     82353f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  82352c:	mov    0x8(%rbx),%rdi
  823530:	shl    $0x3,%rsi
  823534:	mov    $0x8,%edx
  823539:	call   *0x65c841(%rip)        # e7fd80 <_DYNAMIC+0x248>
  82353f:	mov    0x20(%rbx),%rsi
  823543:	test   %rsi,%rsi
  823546:	je     82356f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823548:	mov    %rsi,%rax
  82354b:	shl    $0x4,%rax
  82354f:	add    %rax,%rsi
  823552:	add    $0x21,%rsi
  823556:	je     82356f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  823558:	mov    0x18(%rbx),%rdi
  82355c:	sub    %rax,%rdi
  82355f:	add    $0xfffffffffffffff0,%rdi
  823563:	mov    $0x10,%edx
  823568:	pop    %rbx
  823569:	jmp    *0x65c811(%rip)        # e7fd80 <_DYNAMIC+0x248>
  82356f:	pop    %rbx
  823570:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823580 <<gpui_gpu::renderer::images::Images>::metadata>:
  823580:	push   %r15
  823582:	push   %r14
  823584:	push   %rbx
  823585:	sub    $0x10,%rsp
  823589:	mov    %rsi,0x8(%rsp)
  82358e:	cmpq   $0x0,0x30(%rdi)
  823593:	je     82365d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  823599:	mov    %edx,%ebx
  82359b:	mov    %rsi,%r14
  82359e:	mov    %rdi,%r15
  8235a1:	add    $0x38,%rdi
  8235a5:	lea    0x8(%rsp),%rsi
  8235aa:	call   824d60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8235af:	mov    %rax,%rsi
  8235b2:	shr    $0x39,%rsi
  8235b6:	mov    0x18(%r15),%rcx
  8235ba:	mov    0x20(%r15),%rdx
  8235be:	movd   %esi,%xmm0
  8235c2:	punpcklbw %xmm0,%xmm0
  8235c6:	pshuflw $0x0,%xmm0,%xmm0
  8235cb:	pshufd $0x44,%xmm0,%xmm0
  8235d0:	xor    %esi,%esi
  8235d2:	pcmpeqd %xmm1,%xmm1
  8235d6:	and    %rdx,%rax
  8235d9:	movdqu (%rcx,%rax,1),%xmm2
  8235de:	movdqa %xmm2,%xmm3
  8235e2:	pcmpeqb %xmm0,%xmm3
  8235e6:	pmovmskb %xmm3,%edi
  8235ea:	test   %edi,%edi
  8235ec:	je     823620 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  8235ee:	tzcnt  %edi,%r9d
  8235f3:	add    %rax,%r9
  8235f6:	and    %rdx,%r9
  8235f9:	shl    $0x4,%r9
  8235fd:	mov    %rcx,%r8
  823600:	sub    %r9,%r8
  823603:	cmp    -0x10(%r8),%r14
  823607:	je     823639 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  823609:	lea    -0x1(%rdi),%r8d
  82360d:	and    %di,%r8w
  823611:	mov    %r8d,%edi
  823614:	jne    8235ee <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  823616:	cs nopw 0x0(%rax,%rax,1)
  823620:	pcmpeqb %xmm1,%xmm2
  823624:	pmovmskb %xmm2,%edi
  823628:	test   %edi,%edi
  82362a:	jne    82365d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  82362c:	add    %rsi,%rax
  82362f:	add    $0x10,%rax
  823633:	add    $0x10,%rsi
  823637:	jmp    8235d6 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  823639:	mov    -0x8(%r8),%eax
  82363d:	movzbl %bl,%ecx
  823640:	or     -0x4(%r8),%ecx
  823644:	shl    $0x20,%rcx
  823648:	or     %rax,%rcx
  82364b:	mov    $0x80000000,%eax
  823650:	or     %rcx,%rax
  823653:	add    $0x10,%rsp
  823657:	pop    %rbx
  823658:	pop    %r14
  82365a:	pop    %r15
  82365c:	ret
  82365d:	lea    -0x74ea08(%rip),%rdi        # d4c5c <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  823664:	lea    0x60b17d(%rip),%rdx        # e2e7e8 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677>
  82366b:	mov    $0x16,%esi
  823670:	call   *0x65ca62(%rip)        # e800d8 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2722 frame=552

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008239e0 <gpui_gpu::renderer::images::prepare>:
  8239e0:	push   %rbp
  8239e1:	push   %r15
  8239e3:	push   %r14
  8239e5:	push   %r13
  8239e7:	push   %r12
  8239e9:	push   %rbx
  8239ea:	sub    $0x1f8,%rsp
  8239f1:	mov    %r9,%r12
  8239f4:	mov    %rcx,%r13
  8239f7:	mov    %rdx,0xb8(%rsp)
  8239ff:	mov    %rsi,0x8(%rsp)
  823a04:	mov    %rdi,%r15
  823a07:	mov    0x230(%rsp),%rax
  823a0f:	mov    0x10(%rax),%r14
  823a13:	mov    0x118(%r14),%rax
  823a1a:	add    $0x118,%r14
  823a21:	test   %rax,%rax
  823a24:	mov    %r14,%rcx
  823a27:	cmove  %rax,%rcx
  823a2b:	je     823ac6 <gpui_gpu::renderer::images::prepare+0xe6>
  823a31:	mov    0x10(%rax),%rax
  823a35:	mov    (%r8),%rbp
  823a38:	mov    %rax,0x18(%rsp)
  823a3d:	test   %rax,%rax
  823a40:	je     823ac9 <gpui_gpu::renderer::images::prepare+0xe9>
  823a46:	mov    %rcx,0xa8(%rsp)
  823a4e:	test   %rbp,%rbp
  823a51:	je     823c1b <gpui_gpu::renderer::images::prepare+0x23b>
  823a57:	cmp    0x48(%rbp),%r12
  823a5b:	ja     823c1b <gpui_gpu::renderer::images::prepare+0x23b>
  823a61:	mov    0x8(%rbp),%rdi
  823a65:	mov    0x10(%rbp),%rax
  823a69:	lea    (%rdi,%rax,8),%rsi
  823a6d:	movq   $0x1,0xe0(%rsp)
  823a79:	mov    %r14,0xe8(%rsp)
  823a81:	movq   $0x0,0xf0(%rsp)
  823a8d:	movq   $0x0,0x100(%rsp)
  823a99:	lea    0xe0(%rsp),%rdx
  823aa1:	mov    %r8,%rbx
  823aa4:	call   824910 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  823aa9:	mov    %rbx,%r8
  823aac:	test   %al,%al
  823aae:	je     823c1b <gpui_gpu::renderer::images::prepare+0x23b>
  823ab4:	movq   $0x0,0x60(%rbp)
  823abc:	movb   $0x0,0x4(%r15)
  823ac1:	jmp    823bff <gpui_gpu::renderer::images::prepare+0x21f>
  823ac6:	mov    (%r8),%rbp
  823ac9:	movq   $0x0,(%r8)
  823ad0:	test   %rbp,%rbp
  823ad3:	je     823bf7 <gpui_gpu::renderer::images::prepare+0x217>
  823ad9:	mov    0x0(%rbp),%rsi
  823add:	test   %rsi,%rsi
  823ae0:	je     823af5 <gpui_gpu::renderer::images::prepare+0x115>
  823ae2:	mov    0x8(%rbp),%rdi
  823ae6:	shl    $0x3,%rsi
  823aea:	mov    $0x8,%edx
  823aef:	call   *0x65c28b(%rip)        # e7fd80 <_DYNAMIC+0x248>
  823af5:	mov    0x20(%rbp),%rsi
  823af9:	test   %rsi,%rsi
  823afc:	je     823b24 <gpui_gpu::renderer::images::prepare+0x144>
  823afe:	mov    %rsi,%rax
  823b01:	shl    $0x4,%rax
  823b05:	add    %rax,%rsi
  823b08:	add    $0x21,%rsi
  823b0c:	je     823b24 <gpui_gpu::renderer::images::prepare+0x144>
  823b0e:	mov    0x18(%rbp),%rdi
  823b12:	sub    %rax,%rdi
  823b15:	add    $0xfffffffffffffff0,%rdi
  823b19:	mov    $0x10,%edx
  823b1e:	call   *0x65c25c(%rip)        # e7fd80 <_DYNAMIC+0x248>
  823b24:	mov    $0x80,%esi
  823b29:	mov    $0x8,%edx
  823b2e:	mov    %rbp,%rdi
  823b31:	call   *0x65c249(%rip)        # e7fd80 <_DYNAMIC+0x248>
  823b37:	shl    $0x4,%r12
  823b3b:	cmp    $0x101,%r12
  823b42:	mov    $0x100,%eax
  823b47:	cmovae %r12,%rax
  823b4b:	dec    %rax
  823b4e:	bsr    %rax,%rcx
  823b52:	not    %ecx
  823b54:	mov    $0xffffffffffffffff,%rbx
  823b5b:	shr    %cl,%rbx
  823b5e:	inc    %rbx
  823b61:	lea    -0x74eef6(%rip),%rax        # d4c72 <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x16>
  823b68:	mov    %rax,0x20(%rsp)
  823b6d:	movq   $0xa,0x28(%rsp)
  823b76:	mov    %rbx,0x30(%rsp)
  823b7b:	movl   $0x88,0x38(%rsp)
  823b83:	movb   $0x0,0x3c(%rsp)
  823b88:	lea    0xe0(%rsp),%rdi
  823b90:	lea    0x20(%rsp),%rdx
  823b95:	mov    0x8(%rsp),%rsi
  823b9a:	call   *0x65c5b8(%rip)        # e80158 <_DYNAMIC+0x620>
  823ba0:	mov    %rbx,0x100(%rsp)
  823ba8:	mov    0x0(%r13),%rax
  823bac:	lock decq (%rax)
  823bb0:	jne    823bbb <gpui_gpu::renderer::images::prepare+0x1db>
  823bb2:	mov    %r13,%rdi
  823bb5:	call   *0x65c485(%rip)        # e80040 <_DYNAMIC+0x508>
  823bbb:	mov    0x8(%r13),%rax
  823bbf:	lock decq (%rax)
  823bc3:	jne    823bcf <gpui_gpu::renderer::images::prepare+0x1ef>
  823bc5:	lea    0x8(%r13),%rdi
  823bc9:	call   *0x65c479(%rip)        # e80048 <_DYNAMIC+0x510>
  823bcf:	mov    0x100(%rsp),%rax
  823bd7:	mov    %rax,0x20(%r13)
  823bdb:	movdqu 0xe0(%rsp),%xmm0
  823be4:	movups 0xf0(%rsp),%xmm1
  823bec:	movups %xmm1,0x10(%r13)
  823bf1:	movdqu %xmm0,0x0(%r13)
  823bf7:	test   %rbp,%rbp
  823bfa:	setne  0x4(%r15)
  823bff:	movl   $0xffffffff,(%r15)
  823c06:	mov    %r15,%rax
  823c09:	add    $0x1f8,%rsp
  823c10:	pop    %rbx
  823c11:	pop    %r12
  823c13:	pop    %r13
  823c15:	pop    %r14
  823c17:	pop    %r15
  823c19:	pop    %rbp
  823c1a:	ret
  823c1b:	cmp    $0x1,%r12
  823c1f:	mov    %r12,%rax
  823c22:	adc    $0xffffffffffffffff,%rax
  823c26:	bsr    %rax,%rcx
  823c2a:	not    %ecx
  823c2c:	mov    $0xffffffffffffffff,%rax
  823c33:	shr    %cl,%rax
  823c36:	cmp    $0x2,%r12
  823c3a:	mov    $0x0,%r12d
  823c40:	cmovae %rax,%r12
  823c44:	inc    %r12
  823c47:	je     824372 <gpui_gpu::renderer::images::prepare+0x992>
  823c4d:	mov    %r8,0xd0(%rsp)
  823c55:	mov    %fs:0x0,%rax
  823c5e:	lea    -0x28(%rax),%rax
  823c65:	mov    %rax,%rcx
  823c68:	cmpb   $0x1,0x10(%rax)
  823c6c:	mov    %r15,0xb0(%rsp)
  823c74:	mov    %r13,0xd8(%rsp)
  823c7c:	jne    82437e <gpui_gpu::renderer::images::prepare+0x99e>
  823c82:	mov    (%rcx),%rax
  823c85:	mov    0x8(%rcx),%rdx
  823c89:	mov    0x18(%rsp),%rbx
  823c8e:	lea    0x1(%rax),%rsi
  823c92:	mov    %rsi,(%rcx)
  823c95:	movq   $0x0,0x20(%rsp)
  823c9e:	movq   $0x8,0x28(%rsp)
  823ca7:	movq   $0x0,0x30(%rsp)
  823cb0:	movups 0x60ab49(%rip),%xmm0        # e2e800 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x18>
  823cb7:	movups %xmm0,0x38(%rsp)
  823cbc:	movdqu 0x60ab4c(%rip),%xmm0        # e2e810 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x28>
  823cc4:	movdqu %xmm0,0x48(%rsp)
  823cca:	mov    %rax,0x58(%rsp)
  823ccf:	mov    %rdx,0x60(%rsp)
  823cd4:	mov    %r12,0x68(%rsp)
  823cd9:	pxor   %xmm0,%xmm0
  823cdd:	movdqu %xmm0,0x70(%rsp)
  823ce3:	movdqu %xmm0,0x80(%rsp)
  823cec:	movdqu %xmm0,0x90(%rsp)
  823cf5:	lea    0xe0(%rsp),%rdi
  823cfd:	mov    $0x8,%edx
  823d02:	mov    $0x8,%r8d
  823d08:	mov    $0x8,%r9d
  823d0e:	xor    %esi,%esi
  823d10:	mov    %rbx,%rcx
  823d13:	call   825fb0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823d18:	cmpl   $0x1,0xe0(%rsp)
  823d20:	jne    823d8d <gpui_gpu::renderer::images::prepare+0x3ad>
  823d22:	mov    0xb0(%rsp),%r15
  823d2a:	movl   $0x6,(%r15)
  823d31:	mov    0x20(%rsp),%rsi
  823d36:	test   %rsi,%rsi
  823d39:	je     823d4f <gpui_gpu::renderer::images::prepare+0x36f>
  823d3b:	mov    0x28(%rsp),%rdi
  823d40:	shl    $0x3,%rsi
  823d44:	mov    $0x8,%edx
  823d49:	call   *0x65c031(%rip)        # e7fd80 <_DYNAMIC+0x248>
  823d4f:	mov    0x40(%rsp),%rsi
  823d54:	test   %rsi,%rsi
  823d57:	je     823c06 <gpui_gpu::renderer::images::prepare+0x226>
  823d5d:	mov    %rsi,%rax
  823d60:	shl    $0x4,%rax
  823d64:	add    %rax,%rsi
  823d67:	add    $0x21,%rsi
  823d6b:	je     823c06 <gpui_gpu::renderer::images::prepare+0x226>
  823d71:	mov    0x38(%rsp),%rdi
  823d76:	sub    %rax,%rdi
  823d79:	add    $0xfffffffffffffff0,%rdi
  823d7d:	mov    $0x10,%edx
  823d82:	call   *0x65bff8(%rip)        # e7fd80 <_DYNAMIC+0x248>
  823d88:	jmp    823c06 <gpui_gpu::renderer::images::prepare+0x226>
  823d8d:	mov    %r12,0xa0(%rsp)
  823d95:	mov    %rbp,0xc8(%rsp)
  823d9d:	mov    0xe8(%rsp),%rax
  823da5:	mov    %rax,0x28(%rsp)
  823daa:	mov    %rbx,0x20(%rsp)
  823daf:	cmp    0x48(%rsp),%rbx
  823db4:	ja     82439a <gpui_gpu::renderer::images::prepare+0x9ba>
  823dba:	xor    %r12d,%r12d
  823dbd:	mov    0xa0(%rsp),%r15
  823dc5:	jmp    823de8 <gpui_gpu::renderer::images::prepare+0x408>
  823dc7:	nopw   0x0(%rax,%rax,1)
  823dd0:	add    $0x8,%r12
  823dd4:	mov    0x28(%rsp),%rax
  823dd9:	mov    %rbx,(%rax,%r15,8)
  823ddd:	inc    %r15
  823de0:	mov    %r15,0x30(%rsp)
  823de5:	mov    %r13,%r15
  823de8:	test   %r12,%r12
  823deb:	je     823e10 <gpui_gpu::renderer::images::prepare+0x430>
  823ded:	cmp    %rbp,%r12
  823df0:	je     823e10 <gpui_gpu::renderer::images::prepare+0x430>
  823df2:	mov    (%r12),%rcx
  823df6:	cmpb   $0x0,0x10(%rcx)
  823dfa:	je     823e3e <gpui_gpu::renderer::images::prepare+0x45e>
  823dfc:	mov    0x20(%rcx),%rax
  823e00:	shl    $0x4,%rax
  823e04:	mov    $0x8,%r8d
  823e0a:	jmp    823e51 <gpui_gpu::renderer::images::prepare+0x471>
  823e0c:	nopl   0x0(%rax)
  823e10:	test   %r14,%r14
  823e13:	je     823ed8 <gpui_gpu::renderer::images::prepare+0x4f8>
  823e19:	mov    (%r14),%rax
  823e1c:	mov    0x10(%rax),%rcx
  823e20:	test   %rcx,%rcx
  823e23:	je     823ed8 <gpui_gpu::renderer::images::prepare+0x4f8>
  823e29:	mov    0x8(%rax),%r12
  823e2d:	lea    (%r12,%rcx,8),%rbp
  823e31:	xor    %r14d,%r14d
  823e34:	mov    (%r12),%rcx
  823e38:	cmpb   $0x0,0x10(%rcx)
  823e3c:	jne    823dfc <gpui_gpu::renderer::images::prepare+0x41c>
  823e3e:	movzbl 0x11(%rcx),%edx
  823e42:	movzbl 0x12(%rcx),%esi
  823e46:	mov    0x20(%rcx),%rax
  823e4a:	shl    $0x2,%edx
  823e4d:	lea    (%rdx,%rsi,2),%r8d
  823e51:	mov    0x78(%rsp),%rdx
  823e56:	add    %rax,%rdx
  823e59:	jb     823d22 <gpui_gpu::renderer::images::prepare+0x342>
  823e5f:	mov    0x28(%rcx),%rbx
  823e63:	mov    %rdx,0x78(%rsp)
  823e68:	cmp    $0x4000000,%rdx
  823e6f:	ja     823d22 <gpui_gpu::renderer::images::prepare+0x342>
  823e75:	mov    %r15,%rcx
  823e78:	shr    $0x20,%rcx
  823e7c:	jne    823d22 <gpui_gpu::renderer::images::prepare+0x342>
  823e82:	test   %r15d,%r15d
  823e85:	js     823d22 <gpui_gpu::renderer::images::prepare+0x342>
  823e8b:	mov    %rax,%r13
  823e8e:	shr    $0x4,%r13
  823e92:	and    $0xf,%eax
  823e95:	add    %r15,%r13
  823e98:	cmp    $0x1,%rax
  823e9c:	sbb    $0xffffffffffffffff,%r13
  823ea0:	lea    0xe0(%rsp),%rdi
  823ea8:	lea    0x38(%rsp),%rsi
  823ead:	mov    %rbx,%rdx
  823eb0:	mov    %r15d,%ecx
  823eb3:	call   8256e0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  823eb8:	mov    0x30(%rsp),%r15
  823ebd:	cmp    0x20(%rsp),%r15
  823ec2:	jne    823dd0 <gpui_gpu::renderer::images::prepare+0x3f0>
  823ec8:	lea    0x20(%rsp),%rdi
  823ecd:	call   *0x65c32d(%rip)        # e80200 <_DYNAMIC+0x6c8>
  823ed3:	jmp    823dd0 <gpui_gpu::renderer::images::prepare+0x3f0>
  823ed8:	movabs $0xffffffffffffff0,%rax
  823ee2:	cmp    %rax,%r15
  823ee5:	ja     823d22 <gpui_gpu::renderer::images::prepare+0x342>
  823eeb:	lea    0xe0(%rsp),%rdi
  823ef3:	mov    0x8(%rsp),%rsi
  823ef8:	call   *0x65c30a(%rip)        # e80208 <_DYNAMIC+0x6d0>
  823efe:	mov    %r15,%rbx
  823f01:	shl    $0x4,%rbx
  823f05:	add    $0xff,%rbx
  823f0c:	and    $0xffffffffffffff00,%rbx
  823f13:	cmp    0x130(%rsp),%rbx
  823f1b:	ja     823d22 <gpui_gpu::renderer::images::prepare+0x342>
  823f21:	lea    0xe0(%rsp),%rdi
  823f29:	mov    0x8(%rsp),%rsi
  823f2e:	call   *0x65c2d4(%rip)        # e80208 <_DYNAMIC+0x6d0>
  823f34:	cmp    0x140(%rsp),%rbx
  823f3c:	ja     823d22 <gpui_gpu::renderer::images::prepare+0x342>
  823f42:	mov    0xd8(%rsp),%r14
  823f4a:	mov    0x20(%r14),%rax
  823f4e:	cmp    %rbx,%rax
  823f51:	jb     823f82 <gpui_gpu::renderer::images::prepare+0x5a2>
  823f53:	lea    0x0(,%rbx,4),%rcx
  823f5b:	movabs $0x3fffffffffffff1,%rdx
  823f65:	cmp    %rdx,%r15
  823f68:	setb   %dl
  823f6b:	cmp    %rcx,%rax
  823f6e:	seta   %al
  823f71:	test   %al,%dl
  823f73:	jne    823f82 <gpui_gpu::renderer::images::prepare+0x5a2>
  823f75:	movl   $0x0,0x14(%rsp)
  823f7d:	jmp    824015 <gpui_gpu::renderer::images::prepare+0x635>
  823f82:	lea    -0x74f30d(%rip),%rax        # d4c7c <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677+0x20>
  823f89:	mov    %rax,0x1d8(%rsp)
  823f91:	movq   $0x1d,0x1e0(%rsp)
  823f9d:	mov    %rbx,0x1e8(%rsp)
  823fa5:	movl   $0x88,0x1f0(%rsp)
  823fb0:	movb   $0x0,0x1f4(%rsp)
  823fb8:	lea    0xe0(%rsp),%rdi
  823fc0:	lea    0x1d8(%rsp),%rdx
  823fc8:	mov    0x8(%rsp),%rsi
  823fcd:	call   *0x65c185(%rip)        # e80158 <_DYNAMIC+0x620>
  823fd3:	mov    %rbx,0x100(%rsp)
  823fdb:	mov    %r14,%r15
  823fde:	mov    %r14,%rdi
  823fe1:	call   8233f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  823fe6:	mov    0x100(%rsp),%rax
  823fee:	mov    %rax,0x20(%r15)
  823ff2:	movdqu 0xe0(%rsp),%xmm0
  823ffb:	movdqu 0xf0(%rsp),%xmm1
  824004:	movdqu %xmm1,0x10(%r15)
  82400a:	movdqu %xmm0,(%r15)
  82400f:	mov    $0x1,%al
  824011:	mov    %eax,0x14(%rsp)
  824015:	movq   $0x0,0x8(%rsp)
  82401e:	mov    0x8(%rsp),%rdx
  824023:	test   %rdx,%rdx
  824026:	je     824032 <gpui_gpu::renderer::images::prepare+0x652>
  824028:	cmp    0xc0(%rsp),%rdx
  824030:	jne    82406f <gpui_gpu::renderer::images::prepare+0x68f>
  824032:	mov    0xa8(%rsp),%rax
  82403a:	test   %rax,%rax
  82403d:	je     824205 <gpui_gpu::renderer::images::prepare+0x825>
  824043:	mov    (%rax),%rax
  824046:	mov    0x10(%rax),%rcx
  82404a:	test   %rcx,%rcx
  82404d:	je     824205 <gpui_gpu::renderer::images::prepare+0x825>
  824053:	mov    0x8(%rax),%rdx
  824057:	lea    (%rdx,%rcx,8),%rax
  82405b:	mov    %rax,0xc0(%rsp)
  824063:	movq   $0x0,0xa8(%rsp)
  82406f:	mov    (%rdx),%rax
  824072:	mov    0x28(%rax),%r12
  824076:	movzbl 0x10(%rax),%ebx
  82407a:	mov    0x18(%rax),%rbp
  82407e:	mov    0x20(%rax),%r13
  824082:	mov    %r12,0xe0(%rsp)
  82408a:	cmpq   $0x0,0x50(%rsp)
  824090:	je     8241ea <gpui_gpu::renderer::images::prepare+0x80a>
  824096:	add    $0x8,%rdx
  82409a:	mov    %rdx,0x8(%rsp)
  82409f:	lea    0x58(%rsp),%rdi
  8240a4:	lea    0xe0(%rsp),%rsi
  8240ac:	call   824d60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8240b1:	mov    %rax,%rsi
  8240b4:	shr    $0x39,%rsi
  8240b8:	mov    0x38(%rsp),%rcx
  8240bd:	mov    0x40(%rsp),%rdx
  8240c2:	movd   %esi,%xmm0
  8240c6:	punpcklbw %xmm0,%xmm0
  8240ca:	pshuflw $0x0,%xmm0,%xmm0
  8240cf:	pshufd $0x44,%xmm0,%xmm0
  8240d4:	xor    %esi,%esi
  8240d6:	and    %rdx,%rax
  8240d9:	movdqu (%rcx,%rax,1),%xmm1
  8240de:	movdqa %xmm1,%xmm2
  8240e2:	pcmpeqb %xmm0,%xmm2
  8240e6:	pmovmskb %xmm2,%edi
  8240ea:	test   %edi,%edi
  8240ec:	je     824116 <gpui_gpu::renderer::images::prepare+0x736>
  8240ee:	tzcnt  %edi,%r9d
  8240f3:	add    %rax,%r9
  8240f6:	and    %rdx,%r9
  8240f9:	shl    $0x4,%r9
  8240fd:	mov    %rcx,%r8
  824100:	sub    %r9,%r8
  824103:	cmp    -0x10(%r8),%r12
  824107:	je     824137 <gpui_gpu::renderer::images::prepare+0x757>
  824109:	lea    -0x1(%rdi),%r8d
  82410d:	and    %di,%r8w
  824111:	mov    %r8d,%edi
  824114:	jne    8240ee <gpui_gpu::renderer::images::prepare+0x70e>
  824116:	pcmpeqd %xmm2,%xmm2
  82411a:	pcmpeqb %xmm2,%xmm1
  82411e:	pmovmskb %xmm1,%edi
  824122:	test   %edi,%edi
  824124:	jne    8241ea <gpui_gpu::renderer::images::prepare+0x80a>
  82412a:	add    %rsi,%rax
  82412d:	add    $0x10,%rax
  824131:	add    $0x10,%rsi
  824135:	jmp    8240d6 <gpui_gpu::renderer::images::prepare+0x6f6>
  824137:	mov    -0x8(%r8),%r12d
  82413b:	shl    $0x4,%r12
  82413f:	test   %bl,%bl
  824141:	je     824198 <gpui_gpu::renderer::images::prepare+0x7b8>
  824143:	test   %r13,%r13
  824146:	je     82401e <gpui_gpu::renderer::images::prepare+0x63e>
  82414c:	nopl   0x0(%rax)
  824150:	cmp    $0x1000,%r13
  824157:	mov    $0x1000,%r15d
  82415d:	cmovb  %r13,%r15
  824161:	mov    %r15d,%ebx
  824164:	shl    $0x4,%ebx
  824167:	mov    0xb8(%rsp),%rdi
  82416f:	mov    %r14,%rsi
  824172:	mov    %r12,%rdx
  824175:	mov    %rbp,%rcx
  824178:	mov    %rbx,%r8
  82417b:	call   *0x65bf87(%rip)        # e80108 <_DYNAMIC+0x5d0>
  824181:	mov    %r15,%rax
  824184:	shl    $0x4,%rax
  824188:	add    %rax,%rbp
  82418b:	add    %rbx,%r12
  82418e:	sub    %r15,%r13
  824191:	jne    824150 <gpui_gpu::renderer::images::prepare+0x770>
  824193:	jmp    82401e <gpui_gpu::renderer::images::prepare+0x63e>
  824198:	test   %r13,%r13
  82419b:	je     82401e <gpui_gpu::renderer::images::prepare+0x63e>
  8241a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  8241b0:	cmp    $0x10000,%r13
  8241b7:	mov    $0x10000,%ebx
  8241bc:	cmovb  %r13,%rbx
  8241c0:	mov    0xb8(%rsp),%rdi
  8241c8:	mov    %r14,%rsi
  8241cb:	mov    %r12,%rdx
  8241ce:	mov    %rbp,%rcx
  8241d1:	mov    %rbx,%r8
  8241d4:	call   *0x65bf2e(%rip)        # e80108 <_DYNAMIC+0x5d0>
  8241da:	add    %rbx,%rbp
  8241dd:	add    %rbx,%r12
  8241e0:	sub    %rbx,%r13
  8241e3:	jne    8241b0 <gpui_gpu::renderer::images::prepare+0x7d0>
  8241e5:	jmp    82401e <gpui_gpu::renderer::images::prepare+0x63e>
  8241ea:	lea    -0x74f595(%rip),%rdi        # d4c5c <anon.81378166eea1c96e15e7851dcdc35f4e.0.llvm.4385859340901971677>
  8241f1:	lea    0x60a628(%rip),%rdx        # e2e820 <anon.81378166eea1c96e15e7851dcdc35f4e.2.llvm.4385859340901971677+0x38>
  8241f8:	mov    $0x16,%esi
  8241fd:	call   *0x65bed5(%rip)        # e800d8 <_DYNAMIC+0x5a0>
  824203:	ud2
  824205:	mov    0x18(%rsp),%rax
  82420a:	mov    %rax,0x70(%rsp)
  82420f:	mov    0x78(%rsp),%rax
  824214:	mov    %rax,0x80(%rsp)
  82421c:	mov    0xa0(%rsp),%rax
  824224:	shl    $0x4,%rax
  824228:	mov    %rax,0x88(%rsp)
  824230:	mov    0x20(%r14),%rax
  824234:	mov    %rax,0x90(%rsp)
  82423c:	mov    0x48(%rsp),%rax
  824241:	add    0x50(%rsp),%rax
  824246:	mov    %rax,0x98(%rsp)
  82424e:	mov    0x90(%rsp),%rax
  824256:	mov    %rax,0x150(%rsp)
  82425e:	mov    0x98(%rsp),%rax
  824266:	mov    %rax,0x158(%rsp)
  82426e:	mov    0x80(%rsp),%rax
  824276:	mov    %rax,0x140(%rsp)
  82427e:	mov    0x88(%rsp),%rax
  824286:	mov    %rax,0x148(%rsp)
  82428e:	movups 0x70(%rsp),%xmm0
  824293:	movaps %xmm0,0x130(%rsp)
  82429b:	movups 0x60(%rsp),%xmm0
  8242a0:	movaps %xmm0,0x120(%rsp)
  8242a8:	movups 0x50(%rsp),%xmm0
  8242ad:	movaps %xmm0,0x110(%rsp)
  8242b5:	movups 0x20(%rsp),%xmm0
  8242ba:	movups 0x30(%rsp),%xmm1
  8242bf:	movups 0x40(%rsp),%xmm2
  8242c4:	movaps %xmm2,0x100(%rsp)
  8242cc:	movaps %xmm1,0xf0(%rsp)
  8242d4:	movaps %xmm0,0xe0(%rsp)
  8242dc:	call   8239b0 <alloc::boxed::box_new_uninit>
  8242e1:	mov    %rax,%rbx
  8242e4:	movaps 0x150(%rsp),%xmm0
  8242ec:	movups %xmm0,0x70(%rax)
  8242f0:	movaps 0x140(%rsp),%xmm0
  8242f8:	movups %xmm0,0x60(%rax)
  8242fc:	movaps 0x130(%rsp),%xmm0
  824304:	movups %xmm0,0x50(%rax)
  824308:	movaps 0x120(%rsp),%xmm0
  824310:	movups %xmm0,0x40(%rax)
  824314:	movdqa 0xe0(%rsp),%xmm0
  82431d:	movaps 0xf0(%rsp),%xmm1
  824325:	movaps 0x100(%rsp),%xmm2
  82432d:	movaps 0x110(%rsp),%xmm3
  824335:	movups %xmm3,0x30(%rax)
  824339:	movups %xmm2,0x20(%rax)
  82433d:	movups %xmm1,0x10(%rax)
  824341:	movdqu %xmm0,(%rax)
  824345:	mov    0xc8(%rsp),%rdi
  82434d:	call   823160 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  824352:	mov    0xd0(%rsp),%rax
  82435a:	mov    %rbx,(%rax)
  82435d:	mov    0xb0(%rsp),%r15
  824365:	mov    0x14(%rsp),%eax
  824369:	mov    %al,0x4(%r15)
  82436d:	jmp    823bff <gpui_gpu::renderer::images::prepare+0x21f>
  824372:	movl   $0x6,(%r15)
  824379:	jmp    823c06 <gpui_gpu::renderer::images::prepare+0x226>
  82437e:	mov    %rcx,%rbx
  824381:	call   *0x65bdd9(%rip)        # e80160 <_DYNAMIC+0x628>
  824387:	mov    %rbx,%rcx
  82438a:	mov    %rax,(%rbx)
  82438d:	mov    %rdx,0x8(%rbx)
  824391:	movb   $0x1,0x10(%rbx)
  824395:	jmp    823c89 <gpui_gpu::renderer::images::prepare+0x2a9>
  82439a:	lea    0x38(%rsp),%rdi
  82439f:	mov    0x18(%rsp),%rsi
  8243a4:	lea    0x58(%rsp),%rdx
  8243a9:	xor    %ecx,%ecx
  8243ab:	call   *0x65be27(%rip)        # e801d8 <_DYNAMIC+0x6a0>
  8243b1:	cmp    $0xffffffffffffffff,%rax
  8243b5:	jne    823d22 <gpui_gpu::renderer::images::prepare+0x342>
  8243bb:	jmp    823dba <gpui_gpu::renderer::images::prepare+0x3da>
  8243c0:	mov    %rax,%rbx
  8243c3:	lea    0xe0(%rsp),%rdi
  8243cb:	call   823520 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8243d0:	mov    %rbx,%rdi
  8243d3:	call   e2c890 <_Unwind_Resume@plt>
  8243d8:	mov    %rax,%rbx
  8243db:	mov    0x100(%rsp),%rax
  8243e3:	mov    %rax,0x20(%r15)
  8243e7:	movups 0xe0(%rsp),%xmm0
  8243ef:	movups 0xf0(%rsp),%xmm1
  8243f7:	movups %xmm1,0x10(%r15)
  8243fc:	movups %xmm0,(%r15)
  824400:	lea    0x20(%rsp),%rdi
  824405:	call   823520 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  82440a:	mov    %rbx,%rdi
  82440d:	call   e2c890 <_Unwind_Resume@plt>
  824412:	mov    %r13,%r14
  824415:	mov    %rax,%rbx
  824418:	jmp    824434 <gpui_gpu::renderer::images::prepare+0xa54>
  82441a:	mov    %rax,%rbx
  82441d:	mov    %r13,%r14
  824420:	mov    0x8(%r13),%rax
  824424:	lock decq (%rax)
  824428:	jne    824434 <gpui_gpu::renderer::images::prepare+0xa54>
  82442a:	lea    0x8(%r14),%rdi
  82442e:	call   *0x65bc14(%rip)        # e80048 <_DYNAMIC+0x510>
  824434:	mov    0x100(%rsp),%rax
  82443c:	mov    %rax,0x20(%r14)
  824440:	movups 0xe0(%rsp),%xmm0
  824448:	movups 0xf0(%rsp),%xmm1
  824450:	movups %xmm1,0x10(%r14)
  824455:	movups %xmm0,(%r14)
  824459:	mov    %rbx,%rdi
  82445c:	call   e2c890 <_Unwind_Resume@plt>
  824461:	call   *0x65b921(%rip)        # e7fd88 <_DYNAMIC+0x250>
  824467:	jmp    82446d <gpui_gpu::renderer::images::prepare+0xa8d>
  824469:	jmp    82446d <gpui_gpu::renderer::images::prepare+0xa8d>
  82446b:	jmp    82446d <gpui_gpu::renderer::images::prepare+0xa8d>
  82446d:	mov    %rax,%rbx
  824470:	lea    0x20(%rsp),%rdi
  824475:	call   823520 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  82447a:	mov    %rbx,%rdi
  82447d:	call   e2c890 <_Unwind_Resume@plt>

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824910 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  824910:	push   %r15
  824912:	push   %r14
  824914:	push   %rbx
  824915:	mov    (%rdx),%r9
  824918:	mov    0x8(%rdx),%r11
  82491c:	mov    0x10(%rdx),%rbx
  824920:	mov    0x18(%rdx),%r10
  824924:	mov    0x20(%rdx),%r8
  824928:	mov    0x28(%rdx),%rcx
  82492c:	test   $0x1,%r9b
  824930:	jne    8249ca <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  824936:	mov    %rbx,%rax
  824939:	jmp    82495b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  82493b:	nopl   0x0(%rax,%rax,1)
  824940:	lea    0x8(%rax),%rbx
  824944:	mov    %rbx,%r14
  824947:	add    $0x8,%rdi
  82494b:	mov    (%rax),%r15
  82494e:	mov    %r14,%rax
  824951:	cmp    0x28(%r15),%rdx
  824955:	jne    824a1f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  82495b:	cmp    %rsi,%rdi
  82495e:	je     8249f8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  824964:	mov    (%rdi),%rdx
  824967:	test   %rax,%rax
  82496a:	je     824973 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  82496c:	cmp    %r10,%rax
  82496f:	jne    824940 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  824971:	xor    %ebx,%ebx
  824973:	xor    %eax,%eax
  824975:	test   %r8,%r8
  824978:	je     824a21 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  82497e:	cmp    %rcx,%r8
  824981:	je     824a21 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  824987:	mov    %r8,%rax
  82498a:	add    $0x8,%r8
  82498e:	xor    %r14d,%r14d
  824991:	jmp    824947 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  824993:	mov    (%r11),%rax
  824996:	mov    0x8(%rax),%rbx
  82499a:	mov    0x10(%rax),%rax
  82499e:	lea    (%rbx,%rax,8),%r10
  8249a2:	test   %rax,%rax
  8249a5:	je     8249e1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  8249a7:	xor    %r11d,%r11d
  8249aa:	nopw   0x0(%rax,%rax,1)
  8249b0:	mov    %r8,%rax
  8249b3:	mov    %rbx,%r8
  8249b6:	add    $0x8,%rbx
  8249ba:	add    $0x8,%rdi
  8249be:	mov    (%r8),%r14
  8249c1:	mov    %rax,%r8
  8249c4:	cmp    0x28(%r14),%rdx
  8249c8:	jne    824a1f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8249ca:	cmp    %rsi,%rdi
  8249cd:	je     8249f8 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  8249cf:	mov    (%rdi),%rdx
  8249d2:	test   %rbx,%rbx
  8249d5:	je     8249dc <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  8249d7:	cmp    %r10,%rbx
  8249da:	jne    8249b0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  8249dc:	test   %r11,%r11
  8249df:	jne    824993 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  8249e1:	xor    %eax,%eax
  8249e3:	test   %r8,%r8
  8249e6:	je     824a21 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8249e8:	cmp    %rcx,%r8
  8249eb:	je     824a21 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  8249ed:	lea    0x8(%r8),%rax
  8249f1:	xor    %ebx,%ebx
  8249f3:	xor    %r11d,%r11d
  8249f6:	jmp    8249ba <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  8249f8:	test   %rbx,%rbx
  8249fb:	sete   %dl
  8249fe:	cmp    %r10,%rbx
  824a01:	sete   %al
  824a04:	or     %dl,%al
  824a06:	test   $0x1,%r9b
  824a0a:	je     824a27 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  824a0c:	test   %al,%al
  824a0e:	je     824a1f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  824a10:	test   %r11,%r11
  824a13:	je     824a2b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  824a15:	mov    (%r11),%rax
  824a18:	cmpq   $0x0,0x10(%rax)
  824a1d:	je     824a2b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  824a1f:	xor    %eax,%eax
  824a21:	pop    %rbx
  824a22:	pop    %r14
  824a24:	pop    %r15
  824a26:	ret
  824a27:	test   %al,%al
  824a29:	je     824a1f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  824a2b:	test   %r8,%r8
  824a2e:	sete   %dl
  824a31:	cmp    %rcx,%r8
  824a34:	sete   %al
  824a37:	or     %dl,%al
  824a39:	pop    %rbx
  824a3a:	pop    %r14
  824a3c:	pop    %r15
  824a3e:	ret

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008254f0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  8254f0:	push   %rbp
  8254f1:	push   %r15
  8254f3:	push   %r14
  8254f5:	push   %r13
  8254f7:	push   %r12
  8254f9:	push   %rbx
  8254fa:	sub    $0x38,%rsp
  8254fe:	mov    %rcx,%r15
  825501:	mov    %rdx,%r12
  825504:	mov    %rsi,%r14
  825507:	mov    %rdi,%rbx
  82550a:	lea    0x20(%rsi),%r13
  82550e:	mov    %r13,%rdi
  825511:	mov    %rdx,%rsi
  825514:	call   824bc0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  825519:	cmpq   $0x0,0x10(%r14)
  82551e:	je     8256a1 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  825524:	mov    (%r14),%r11
  825527:	mov    0x8(%r14),%rsi
  82552b:	mov    %rax,%rdx
  82552e:	shr    $0x39,%rdx
  825532:	movd   %edx,%xmm0
  825536:	punpcklbw %xmm0,%xmm0
  82553a:	pshuflw $0x0,%xmm0,%xmm0
  82553f:	pshufd $0x44,%xmm0,%xmm0
  825544:	mov    (%r12),%rcx
  825548:	mov    %rcx,0x8(%rsp)
  82554d:	movzwl 0xc(%r12),%r9d
  825553:	mov    0x8(%r12),%r10d
  825558:	xor    %r13d,%r13d
  82555b:	pcmpeqd %xmm1,%xmm1
  82555f:	xor    %r8d,%r8d
  825562:	and    %rsi,%rax
  825565:	movdqu (%r11,%rax,1),%xmm2
  82556b:	movdqa %xmm2,%xmm3
  82556f:	pcmpeqb %xmm0,%xmm3
  825573:	pmovmskb %xmm3,%ebp
  825577:	test   %ebp,%ebp
  825579:	je     8255c0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  82557b:	mov    %r8,(%rsp)
  82557f:	mov    %r15,%r8
  825582:	tzcnt  %ebp,%r15d
  825587:	add    %rax,%r15
  82558a:	and    %rsi,%r15
  82558d:	shl    $0x5,%r15
  825591:	mov    %r11,%rcx
  825594:	sub    %r15,%rcx
  825597:	mov    0x8(%rsp),%r15
  82559c:	cmp    -0x20(%rcx),%r15
  8255a0:	jne    8255af <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8255a2:	cmp    -0x14(%rcx),%r9w
  8255a7:	jne    8255af <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8255a9:	cmp    -0x18(%rcx),%r10d
  8255ad:	je     8255ff <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  8255af:	lea    -0x1(%rbp),%ecx
  8255b2:	and    %bp,%cx
  8255b5:	mov    %ecx,%ebp
  8255b7:	mov    %r8,%r15
  8255ba:	mov    (%rsp),%r8
  8255be:	jne    82557f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  8255c0:	cmp    $0x1,%r13
  8255c4:	je     8255d8 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  8255c6:	pmovmskb %xmm2,%ecx
  8255ca:	test   %ecx,%ecx
  8255cc:	je     8255ec <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  8255ce:	tzcnt  %ecx,%edi
  8255d2:	add    %rax,%rdi
  8255d5:	and    %rsi,%rdi
  8255d8:	pcmpeqb %xmm1,%xmm2
  8255dc:	pmovmskb %xmm2,%ecx
  8255e0:	test   %ecx,%ecx
  8255e2:	jne    825616 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  8255e4:	mov    $0x1,%r13d
  8255ea:	jmp    8255ef <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  8255ec:	xor    %r13d,%r13d
  8255ef:	add    %r8,%rax
  8255f2:	add    $0x10,%rax
  8255f6:	add    $0x10,%r8
  8255fa:	jmp    825562 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  8255ff:	movups -0x10(%rcx),%xmm0
  825603:	movups %xmm0,0x4(%rbx)
  825607:	movups (%r8),%xmm0
  82560b:	movups %xmm0,-0x10(%rcx)
  82560f:	mov    $0x1,%eax
  825614:	jmp    82568d <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  825616:	movzbl (%r11,%rdi,1),%eax
  82561b:	test   %al,%al
  82561d:	jns    8256c2 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  825623:	movups (%r12),%xmm0
  825628:	movaps %xmm0,0x10(%rsp)
  82562d:	movups (%r15),%xmm0
  825631:	movaps %xmm0,0x20(%rsp)
  825636:	and    $0x1,%al
  825638:	lea    -0x10(%rdi),%rcx
  82563c:	and    %rsi,%rcx
  82563f:	mov    %dl,(%r11,%rdi,1)
  825643:	mov    %dl,0x10(%r11,%rcx,1)
  825648:	movzbl %al,%eax
  82564b:	movd   %eax,%xmm0
  82564f:	shufpd $0x2,-0x77a3f8(%rip),%xmm0        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  825658:	movdqu 0x10(%r14),%xmm1
  82565e:	psubq  %xmm0,%xmm1
  825662:	movdqu %xmm1,0x10(%r14)
  825668:	shl    $0x5,%rdi
  82566c:	mov    %r11,%rax
  82566f:	sub    %rdi,%rax
  825672:	neg    %rdi
  825675:	movaps 0x10(%rsp),%xmm0
  82567a:	movdqa 0x20(%rsp),%xmm1
  825680:	movups %xmm0,-0x20(%r11,%rdi,1)
  825686:	movdqu %xmm1,-0x10(%rax)
  82568b:	xor    %eax,%eax
  82568d:	mov    %eax,(%rbx)
  82568f:	mov    %rbx,%rax
  825692:	add    $0x38,%rsp
  825696:	pop    %rbx
  825697:	pop    %r12
  825699:	pop    %r13
  82569b:	pop    %r14
  82569d:	pop    %r15
  82569f:	pop    %rbp
  8256a0:	ret
  8256a1:	mov    $0x1,%esi
  8256a6:	mov    %r14,%rdi
  8256a9:	mov    %r13,%rdx
  8256ac:	mov    $0x1,%ecx
  8256b1:	mov    %rax,%r13
  8256b4:	call   *0x65ab16(%rip)        # e801d0 <_DYNAMIC+0x698>
  8256ba:	mov    %r13,%rax
  8256bd:	jmp    825524 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  8256c2:	movdqa (%r11),%xmm0
  8256c7:	pmovmskb %xmm0,%eax
  8256cb:	tzcnt  %eax,%edi
  8256cf:	movzbl (%r11,%rdi,1),%eax
  8256d4:	jmp    825623 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008256e0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  8256e0:	push   %rbp
  8256e1:	push   %r15
  8256e3:	push   %r14
  8256e5:	push   %r13
  8256e7:	push   %r12
  8256e9:	push   %rbx
  8256ea:	push   %rax
  8256eb:	mov    %r8d,%ebp
  8256ee:	mov    %ecx,%r14d
  8256f1:	mov    %rdx,%r15
  8256f4:	mov    %rsi,%r12
  8256f7:	mov    %rdi,%rbx
  8256fa:	mov    %rdx,(%rsp)
  8256fe:	lea    0x20(%rsi),%r13
  825702:	mov    %rsp,%rsi
  825705:	mov    %r13,%rdi
  825708:	call   824d60 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82570d:	cmpq   $0x0,0x10(%r12)
  825713:	je     825856 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  825719:	mov    (%r12),%rcx
  82571d:	mov    0x8(%r12),%rsi
  825722:	mov    %rax,%rdx
  825725:	shr    $0x39,%rdx
  825729:	movd   %edx,%xmm0
  82572d:	punpcklbw %xmm0,%xmm0
  825731:	pshuflw $0x0,%xmm0,%xmm0
  825736:	pshufd $0x44,%xmm0,%xmm0
  82573b:	xor    %r9d,%r9d
  82573e:	pcmpeqd %xmm1,%xmm1
  825742:	xor    %r8d,%r8d
  825745:	and    %rsi,%rax
  825748:	movdqu (%rcx,%rax,1),%xmm2
  82574d:	movdqa %xmm2,%xmm3
  825751:	pcmpeqb %xmm0,%xmm3
  825755:	pmovmskb %xmm3,%r10d
  82575a:	test   %r10d,%r10d
  82575d:	je     825790 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  82575f:	tzcnt  %r10d,%r13d
  825764:	add    %rax,%r13
  825767:	and    %rsi,%r13
  82576a:	shl    $0x4,%r13
  82576e:	mov    %rcx,%r11
  825771:	sub    %r13,%r11
  825774:	cmp    -0x10(%r11),%r15
  825778:	je     8257d1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  82577a:	lea    -0x1(%r10),%r11d
  82577e:	and    %r10w,%r11w
  825782:	mov    %r11d,%r10d
  825785:	jne    82575f <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  825787:	nopw   0x0(%rax,%rax,1)
  825790:	cmp    $0x1,%r9
  825794:	je     8257a8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  825796:	pmovmskb %xmm2,%edi
  82579a:	test   %edi,%edi
  82579c:	je     8257be <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  82579e:	tzcnt  %edi,%edi
  8257a2:	add    %rax,%rdi
  8257a5:	and    %rsi,%rdi
  8257a8:	pcmpeqb %xmm1,%xmm2
  8257ac:	pmovmskb %xmm2,%r9d
  8257b1:	test   %r9d,%r9d
  8257b4:	jne    8257e8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  8257b6:	mov    $0x1,%r9d
  8257bc:	jmp    8257c1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  8257be:	xor    %r9d,%r9d
  8257c1:	add    %r8,%rax
  8257c4:	add    $0x10,%rax
  8257c8:	add    $0x10,%r8
  8257cc:	jmp    825745 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  8257d1:	mov    -0x8(%r11),%rax
  8257d5:	mov    %r14d,-0x8(%r11)
  8257d9:	mov    %ebp,-0x4(%r11)
  8257dd:	mov    %rax,0x4(%rbx)
  8257e1:	mov    $0x1,%eax
  8257e6:	jmp    825842 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  8257e8:	movzbl (%rcx,%rdi,1),%eax
  8257ec:	test   %al,%al
  8257ee:	jns    825877 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  8257f4:	and    $0x1,%al
  8257f6:	lea    -0x10(%rdi),%r8
  8257fa:	and    %rsi,%r8
  8257fd:	mov    %dl,(%rcx,%rdi,1)
  825800:	mov    %dl,0x10(%rcx,%r8,1)
  825805:	movdqu 0x10(%r12),%xmm0
  82580c:	movzbl %al,%eax
  82580f:	movd   %eax,%xmm1
  825813:	shufpd $0x2,-0x77a5bc(%rip),%xmm1        # ab260 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  82581c:	psubq  %xmm1,%xmm0
  825820:	movdqu %xmm0,0x10(%r12)
  825827:	shl    $0x4,%rdi
  82582b:	mov    %rcx,%rax
  82582e:	sub    %rdi,%rax
  825831:	neg    %rdi
  825834:	mov    %r15,-0x10(%rcx,%rdi,1)
  825839:	mov    %r14d,-0x8(%rax)
  82583d:	mov    %ebp,-0x4(%rax)
  825840:	xor    %eax,%eax
  825842:	mov    %eax,(%rbx)
  825844:	mov    %rbx,%rax
  825847:	add    $0x8,%rsp
  82584b:	pop    %rbx
  82584c:	pop    %r12
  82584e:	pop    %r13
  825850:	pop    %r14
  825852:	pop    %r15
  825854:	pop    %rbp
  825855:	ret
  825856:	mov    $0x1,%esi
  82585b:	mov    %r12,%rdi
  82585e:	mov    %r13,%rdx
  825861:	mov    $0x1,%ecx
  825866:	mov    %rax,%r13
  825869:	call   *0x65a969(%rip)        # e801d8 <_DYNAMIC+0x6a0>
  82586f:	mov    %r13,%rax
  825872:	jmp    825719 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  825877:	movdqa (%rcx),%xmm0
  82587b:	pmovmskb %xmm0,%eax
  82587f:	tzcnt  %eax,%edi
  825883:	movzbl (%rcx,%rdi,1),%eax
  825887:	jmp    8257f4 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825890 <gpui_gpu::renderer::slots::color_word>:
  825890:	lea    -0x3(%rsi),%eax
  825893:	cmp    %rax,%rdi
  825896:	jbe    8258af <gpui_gpu::renderer::slots::color_word+0x1f>
  825898:	mov    %rdi,%rax
  82589b:	shr    $0x6,%rax
  82589f:	and    $0x3f,%edi
  8258a2:	cmp    $0x1,%rdi
  8258a6:	sbb    $0xffffffff,%eax
  8258a9:	add    %esi,%eax
  8258ab:	add    $0xfffffffe,%eax
  8258ae:	ret
  8258af:	push   %rax
  8258b0:	lea    -0x750c1e(%rip),%rdi        # d4c99 <anon.37a6bc0c9ddf42ae57934ce69d5ecb61.7.llvm.1051716552078069610>
  8258b7:	lea    0x608fb2(%rip),%rdx        # e2e870 <anon.37a6bc0c9ddf42ae57934ce69d5ecb61.8.llvm.1051716552078069610>
  8258be:	mov    $0x1e,%esi
  8258c3:	call   *0x65a7d7(%rip)        # e800a0 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=694 frame=120

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008258d0 <gpui_gpu::renderer::slots::write_prefix>:
  8258d0:	push   %rbp
  8258d1:	push   %r15
  8258d3:	push   %r14
  8258d5:	push   %r13
  8258d7:	push   %r12
  8258d9:	push   %rbx
  8258da:	sub    $0x48,%rsp
  8258de:	mov    %rsi,0x8(%rsp)
  8258e3:	test   %rcx,%rcx
  8258e6:	je     825b2a <gpui_gpu::renderer::slots::write_prefix+0x25a>
  8258ec:	mov    %rdi,0x18(%rsp)
  8258f1:	xor    %r12d,%r12d
  8258f4:	test   $0x3f,%cl
  8258f7:	setne  %al
  8258fa:	cmpq   $0x0,0x8(%rsp)
  825900:	je     825b70 <gpui_gpu::renderer::slots::write_prefix+0x2a0>
  825906:	mov    %r8,%r14
  825909:	mov    %rcx,%r10
  82590c:	shr    $0x6,%r10
  825910:	mov    %al,%r12b
  825913:	lea    (%r10,%r12,1),%r9
  825917:	lea    (%r10,%r12,1),%rax
  82591b:	inc    %rax
  82591e:	mov    %eax,%esi
  825920:	mov    %r9,%rdi
  825923:	shl    $0x20,%rdi
  825927:	mov    %ecx,%r8d
  82592a:	mov    0x18(%rsp),%rbx
  82592f:	xor    0x8(%rbx),%rsi
  825933:	or     %rdi,%r8
  825936:	xor    (%rbx),%r8
  825939:	or     %rsi,%r8
  82593c:	mov    %r10,0x10(%rsp)
  825941:	jne    82594c <gpui_gpu::renderer::slots::write_prefix+0x7c>
  825943:	mov    (%r14),%rbp
  825946:	mov    0x8(%r14),%r13
  82594a:	jmp    825975 <gpui_gpu::renderer::slots::write_prefix+0xa5>
  82594c:	mov    0x8(%r14),%r13
  825950:	movq   $0x0,(%r14)
  825957:	cmp    $0x1,%r13
  82595b:	adc    $0x0,%r13
  82595f:	mov    %r13,0x8(%r14)
  825963:	mov    %ecx,(%rbx)
  825965:	mov    %r9d,0x4(%rbx)
  825969:	mov    %eax,0x8(%rbx)
  82596c:	movl   $0x0,0xc(%rbx)
  825973:	xor    %ebp,%ebp
  825975:	mov    %r9,%r15
  825978:	mov    %rdx,%rdi
  82597b:	call   *0x65a75f(%rip)        # e800e0 <_DYNAMIC+0x5a8>
  825981:	mov    0x8(%rsp),%rcx
  825986:	dec    %rcx
  825989:	mov    %rcx,0x40(%rsp)
  82598e:	mov    0x10(%rsp),%rcx
  825993:	shl    $0x4,%rcx
  825997:	shl    $0x4,%r12d
  82599b:	add    %rcx,%r12
  82599e:	lea    (%rbx,%r12,1),%r9
  8259a2:	add    $0x10,%r9
  8259a6:	xor    %r12d,%r12d
  8259a9:	xorps  %xmm0,%xmm0
  8259ac:	mov    %r15,0x38(%rsp)
  8259b1:	mov    %r15,%r10
  8259b4:	jmp    8259d6 <gpui_gpu::renderer::slots::write_prefix+0x106>
  8259b6:	cs nopw 0x0(%rax,%rax,1)
  8259c0:	add    $0x40,%r10
  8259c4:	add    $0x400,%r9
  8259cb:	cmp    0x38(%rsp),%r12
  8259d0:	je     825b2a <gpui_gpu::renderer::slots::write_prefix+0x25a>
  8259d6:	mov    %r12,0x10(%rsp)
  8259db:	lea    0x1(%r12),%rcx
  8259e0:	mov    %rcx,0x30(%rsp)
  8259e5:	movaps %xmm0,0x20(%rsp)
  8259ea:	mov    $0xffffffffffffffc0,%rsi
  8259f1:	xor    %r12d,%r12d
  8259f4:	jmp    825a11 <gpui_gpu::renderer::slots::write_prefix+0x141>
  8259f6:	cs nopw 0x0(%rax,%rax,1)
  825a00:	add    $0x18,%rax
  825a04:	add    $0x2,%r12
  825a08:	inc    %rsi
  825a0b:	je     825ac0 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  825a11:	cmp    %rdx,%rax
  825a14:	je     825ac0 <gpui_gpu::renderer::slots::write_prefix+0x1f0>
  825a1a:	lea    0x40(%rsi),%r8
  825a1e:	movzwl 0x10(%rax),%ebx
  825a22:	movzwl 0x12(%rax),%ecx
  825a26:	mov    (%rax),%r11d
  825a29:	mov    0x4(%rax),%edi
  825a2c:	mov    0x8(%rax),%r15
  825a30:	shr    $0xe,%ecx
  825a33:	and    $0x2,%ecx
  825a36:	shr    $0xf,%ebx
  825a39:	or     %ecx,%ebx
  825a3b:	mov    %r12d,%ecx
  825a3e:	and    $0x1e,%cl
  825a41:	shl    %cl,%ebx
  825a43:	shr    $0x4,%r8
  825a47:	or     %ebx,0x20(%rsp,%r8,4)
  825a4c:	lea    (%r10,%rsi,1),%r8
  825a50:	add    $0x41,%r8
  825a54:	cmp    0x8(%rsp),%r8
  825a59:	jae    825b39 <gpui_gpu::renderer::slots::write_prefix+0x269>
  825a5f:	mov    %rdi,%rcx
  825a62:	shl    $0x20,%rcx
  825a66:	mov    %r11d,%ebx
  825a69:	or     %rcx,%rbx
  825a6c:	mov    0x8(%r9,%r12,8),%rcx
  825a71:	xor    %r15,%rcx
  825a74:	xor    (%r9,%r12,8),%rbx
  825a78:	or     %rcx,%rbx
  825a7b:	je     825a00 <gpui_gpu::renderer::slots::write_prefix+0x130>
  825a7d:	mov    %r15d,%ecx
  825a80:	shr    $0x20,%r15
  825a84:	cmp    %rbp,%r8
  825a87:	cmovb  %r8,%rbp
  825a8b:	mov    %rbp,(%r14)
  825a8e:	lea    (%r10,%rsi,1),%r8
  825a92:	add    $0x42,%r8
  825a96:	cmp    %r13,%r8
  825a99:	cmova  %r8,%r13
  825a9d:	mov    %r13,0x8(%r14)
  825aa1:	mov    %r11d,(%r9,%r12,8)
  825aa5:	mov    %edi,0x4(%r9,%r12,8)
  825aaa:	mov    %ecx,0x8(%r9,%r12,8)
  825aaf:	mov    %r15d,0xc(%r9,%r12,8)
  825ab4:	jmp    825a00 <gpui_gpu::renderer::slots::write_prefix+0x130>
  825ab9:	nopl   0x0(%rax)
  825ac0:	mov    0x10(%rsp),%r15
  825ac5:	cmp    0x40(%rsp),%r15
  825aca:	je     825b55 <gpui_gpu::renderer::slots::write_prefix+0x285>
  825ad0:	mov    0x20(%rsp),%rcx
  825ad5:	mov    0x28(%rsp),%rsi
  825ada:	lea    0x1(%r15),%r12
  825ade:	mov    %r12,%rdi
  825ae1:	shl    $0x4,%rdi
  825ae5:	mov    0x18(%rsp),%rbx
  825aea:	mov    0x8(%rbx,%rdi,1),%r8
  825aef:	xor    %rsi,%r8
  825af2:	mov    (%rbx,%rdi,1),%r11
  825af6:	xor    %rcx,%r11
  825af9:	or     %r8,%r11
  825afc:	je     8259c0 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  825b02:	add    %rbx,%rdi
  825b05:	cmp    %rbp,%r12
  825b08:	cmovb  %r12,%rbp
  825b0c:	add    $0x2,%r15
  825b10:	cmp    %r13,%r15
  825b13:	cmova  %r15,%r13
  825b17:	mov    %rbp,(%r14)
  825b1a:	mov    %r13,0x8(%r14)
  825b1e:	mov    %rsi,0x8(%rdi)
  825b22:	mov    %rcx,(%rdi)
  825b25:	jmp    8259c0 <gpui_gpu::renderer::slots::write_prefix+0xf0>
  825b2a:	add    $0x48,%rsp
  825b2e:	pop    %rbx
  825b2f:	pop    %r12
  825b31:	pop    %r13
  825b33:	pop    %r14
  825b35:	pop    %r15
  825b37:	pop    %rbp
  825b38:	ret
  825b39:	add    %r10,%rsi
  825b3c:	add    $0x42,%rsi
  825b40:	lea    0x608a61(%rip),%rcx        # e2e5a8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096>
  825b47:	mov    %r8,%rdi
  825b4a:	mov    0x8(%rsp),%rdx
  825b4f:	call   *0x65a52b(%rip)        # e80080 <_DYNAMIC+0x548>
  825b55:	mov    0x8(%rsp),%rdx
  825b5a:	lea    0x1(%rdx),%rsi
  825b5e:	lea    0x608a43(%rip),%rcx        # e2e5a8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096>
  825b65:	mov    0x30(%rsp),%rdi
  825b6a:	call   *0x65a510(%rip)        # e80080 <_DYNAMIC+0x548>
  825b70:	lea    0x608a31(%rip),%rcx        # e2e5a8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096>
  825b77:	mov    $0x1,%esi
  825b7c:	xor    %edi,%edi
  825b7e:	xor    %edx,%edx
  825b80:	call   *0x65a4fa(%rip)        # e80080 <_DYNAMIC+0x548>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825f40 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  825f40:	push   %r14
  825f42:	push   %rbx
  825f43:	sub    $0x18,%rsp
  825f47:	mov    %rdi,%rbx
  825f4a:	mov    (%rdi),%rsi
  825f4d:	lea    (%rsi,%rsi,1),%rax
  825f51:	cmp    $0x5,%rax
  825f55:	mov    $0x4,%r14d
  825f5b:	cmovae %rax,%r14
  825f5f:	mov    0x8(%rdi),%rdx
  825f63:	mov    %rsp,%rdi
  825f66:	mov    $0x4,%r8d
  825f6c:	mov    $0x20,%r9d
  825f72:	mov    %r14,%rcx
  825f75:	call   825fb0 <<alloc::raw_vec::RawVecInner>::finish_grow>
  825f7a:	cmpl   $0x1,(%rsp)
  825f7e:	je     825f94 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  825f80:	mov    0x8(%rsp),%rax
  825f85:	mov    %rax,0x8(%rbx)
  825f89:	mov    %r14,(%rbx)
  825f8c:	add    $0x18,%rsp
  825f90:	pop    %rbx
  825f91:	pop    %r14
  825f93:	ret
  825f94:	mov    0x8(%rsp),%rdi
  825f99:	mov    0x10(%rsp),%rsi
  825f9e:	call   *0x659e1c(%rip)        # e7fdc0 <_DYNAMIC+0x288>
