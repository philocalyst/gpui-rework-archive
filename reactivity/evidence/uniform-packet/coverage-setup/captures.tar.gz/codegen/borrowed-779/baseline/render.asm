FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9261 frame=1448

/tmp/gpui-coverage-setup-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e020 <<gpui_gpu::renderer::RendererState>::render>:
  81e020:	push   %rbp
  81e021:	push   %r15
  81e023:	push   %r14
  81e025:	push   %r13
  81e027:	push   %r12
  81e029:	push   %rbx
  81e02a:	sub    $0x578,%rsp
  81e031:	mov    0x228(%rsi),%rax
  81e038:	mov    0x18(%rdx),%rbx
  81e03c:	cmp    %rbx,%rax
  81e03f:	je     81e05d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e041:	mov    0x10(%rax),%r9
  81e045:	cmp    0x10(%rbx),%r9
  81e049:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e04f:	mov    0x18(%rax),%rax
  81e053:	cmp    0x18(%rbx),%rax
  81e057:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e05d:	movupd 0x330(%rsi),%xmm0
  81e065:	movapd %xmm0,0x130(%rsp)
  81e06e:	movq   $0x0,0x330(%rsi)
  81e079:	mov    0x130(%rsp),%r13
  81e081:	test   %r13,%r13
  81e084:	je     81e0c6 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e086:	lock decq 0x0(%r13)
  81e08b:	jne    81e0c6 <<gpui_gpu::renderer::RendererState>::render+0xa6>
  81e08d:	lea    0x130(%rsp),%rax
  81e095:	mov    %rdi,%r14
  81e098:	mov    %rax,%rdi
  81e09b:	mov    %rsi,%r12
  81e09e:	mov    %r8,%rbp
  81e0a1:	mov    %rdx,%r15
  81e0a4:	mov    %r13,0x38(%rsp)
  81e0a9:	mov    %rcx,%r13
  81e0ac:	call   *0x661f9e(%rip)        # e80050 <_DYNAMIC+0x518>
  81e0b2:	mov    %r13,%rcx
  81e0b5:	mov    0x38(%rsp),%r13
  81e0ba:	mov    %r15,%rdx
  81e0bd:	mov    %rbp,%r8
  81e0c0:	mov    %r12,%rsi
  81e0c3:	mov    %r14,%rdi
  81e0c6:	mov    0x228(%rsi),%rax
  81e0cd:	cmp    %rbx,%rax
  81e0d0:	je     81e0ee <<gpui_gpu::renderer::RendererState>::render+0xce>
  81e0d2:	mov    0x10(%rax),%r9
  81e0d6:	cmp    0x10(%rbx),%r9
  81e0da:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0e0:	mov    0x18(%rax),%rax
  81e0e4:	cmp    0x18(%rbx),%rax
  81e0e8:	jne    81e1c9 <<gpui_gpu::renderer::RendererState>::render+0x1a9>
  81e0ee:	lea    0x330(%rsi),%rax
  81e0f5:	mov    %rax,0xe8(%rsp)
  81e0fd:	mov    (%rax),%rax
  81e100:	test   %rax,%rax
  81e103:	je     81e13c <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e105:	lock decq (%rax)
  81e109:	jne    81e13c <<gpui_gpu::renderer::RendererState>::render+0x11c>
  81e10b:	mov    %rdi,%r14
  81e10e:	lea    0x330(%rsi),%rdi
  81e115:	mov    %rsi,%r12
  81e118:	mov    %r8,%rbp
  81e11b:	mov    %rdx,%r15
  81e11e:	mov    %r13,%rbx
  81e121:	mov    %rcx,%r13
  81e124:	call   *0x661f26(%rip)        # e80050 <_DYNAMIC+0x518>
  81e12a:	mov    %r13,%rcx
  81e12d:	mov    %rbx,%r13
  81e130:	mov    %r15,%rdx
  81e133:	mov    %rbp,%r8
  81e136:	mov    %r12,%rsi
  81e139:	mov    %r14,%rdi
  81e13c:	movq   $0x0,0x330(%rsi)
  81e147:	mov    (%rcx),%ebp
  81e149:	mov    0x8(%rcx),%r9d
  81e14d:	movzbl 0xd(%rcx),%eax
  81e151:	test   %r9d,%r9d
  81e154:	sets   %r10b
  81e158:	and    $0x7fffffff,%r9d
  81e15f:	lea    -0x800000(%r9),%r11d
  81e166:	cmp    $0x7f000000,%r11d
  81e16d:	setb   %r11b
  81e171:	and    %r10b,%r11b
  81e174:	lea    -0x1(%r9),%r14d
  81e178:	cmp    $0x7fffff,%r14d
  81e17f:	setb   %r14b
  81e183:	and    %r10b,%r14b
  81e186:	test   %r9d,%r9d
  81e189:	sete   %r10b
  81e18d:	cmp    $0x7f800000,%r9d
  81e194:	sete   %r15b
  81e198:	or     %r10b,%r15b
  81e19b:	cmp    $0x7f800001,%r9d
  81e1a2:	setge  %r9b
  81e1a6:	or     %r15b,%r9b
  81e1a9:	or     %r14b,%r9b
  81e1ac:	test   %ebp,%ebp
  81e1ae:	setne  %r10b
  81e1b2:	and    %al,%r10b
  81e1b5:	or     %r11b,%r10b
  81e1b8:	or     %r9b,%r10b
  81e1bb:	test   $0x1,%r10b
  81e1bf:	je     81e1e4 <<gpui_gpu::renderer::RendererState>::render+0x1c4>
  81e1c1:	movl   $0x3,(%rdi)
  81e1c7:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e1c9:	movl   $0x4,(%rdi)
  81e1cf:	mov    %rdi,%rax
  81e1d2:	add    $0x578,%rsp
  81e1d9:	pop    %rbx
  81e1da:	pop    %r12
  81e1dc:	pop    %r13
  81e1de:	pop    %r14
  81e1e0:	pop    %r15
  81e1e2:	pop    %rbp
  81e1e3:	ret
  81e1e4:	movd   0x4(%rcx),%xmm2
  81e1e9:	movzbl 0xc(%rcx),%r12d
  81e1ee:	test   $0x1,%bpl
  81e1f2:	je     81e26a <<gpui_gpu::renderer::RendererState>::render+0x24a>
  81e1f4:	movd   %xmm2,%r9d
  81e1f9:	test   %r9d,%r9d
  81e1fc:	sets   %r10b
  81e200:	and    $0x7fffffff,%r9d
  81e207:	lea    -0x800000(%r9),%r11d
  81e20e:	cmp    $0x7f000000,%r11d
  81e215:	setb   %r11b
  81e219:	and    %r10b,%r11b
  81e21c:	lea    -0x1(%r9),%r14d
  81e220:	cmp    $0x7fffff,%r14d
  81e227:	setb   %r14b
  81e22b:	and    %r10b,%r14b
  81e22e:	test   %r9d,%r9d
  81e231:	sete   %r10b
  81e235:	cmp    $0x7f800000,%r9d
  81e23c:	sete   %r15b
  81e240:	or     %r10b,%r15b
  81e243:	cmp    $0x7f800001,%r9d
  81e24a:	setge  %r9b
  81e24e:	or     %r15b,%r9b
  81e251:	or     %r14b,%r9b
  81e254:	or     %r11b,%r9b
  81e257:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e25d:	ucomiss -0x76f358(%rip),%xmm2        # aef0c <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e264:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e26a:	mov    0x28(%rcx),%r14d
  81e26e:	cmp    %r14d,0x20(%r8)
  81e272:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e278:	mov    0x2c(%rcx),%r15d
  81e27c:	cmp    %r15d,0x24(%r8)
  81e280:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e286:	mov    0x38(%r8),%r10d
  81e28a:	cmp    0x20(%rdx),%r10d
  81e28e:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e294:	cmp    $0x4c,%r10d
  81e298:	jne    81e2bd <<gpui_gpu::renderer::RendererState>::render+0x29d>
  81e29a:	movq   0x3c(%r8),%xmm0
  81e2a0:	movq   0x24(%rdx),%xmm1
  81e2a5:	pcmpeqd %xmm0,%xmm1
  81e2a9:	pshufd $0x50,%xmm1,%xmm0
  81e2ae:	movmskpd %xmm0,%r9d
  81e2b3:	cmp    $0x3,%r9d
  81e2b7:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e2bd:	cmp    $0x4000,%r15d
  81e2c4:	ja     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2c6:	cmp    $0x4000,%r14d
  81e2cd:	ja     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2cf:	mov    %r15,%r9
  81e2d2:	imul   %r14,%r9
  81e2d6:	add    $0xfffffffffeffffff,%r9
  81e2dd:	cmp    $0xffffffffff000000,%r9
  81e2e4:	jb     81e2fa <<gpui_gpu::renderer::RendererState>::render+0x2da>
  81e2e6:	mov    0x10(%rcx),%rbx
  81e2ea:	mov    0x80(%rbx),%r11
  81e2f1:	cmp    $0x10000,%r11
  81e2f8:	jbe    81e305 <<gpui_gpu::renderer::RendererState>::render+0x2e5>
  81e2fa:	movl   $0x6,(%rdi)
  81e300:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e305:	movd   0x18(%rcx),%xmm0
  81e30a:	movd   %xmm0,%r9d
  81e30f:	and    $0x7fffffff,%r9d
  81e316:	cmp    $0x7f7fffff,%r9d
  81e31d:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e323:	pand   -0x770b3b(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e32b:	ucomiss -0x76f1ce(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e332:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e338:	movd   0x1c(%rcx),%xmm0
  81e33d:	movd   %xmm0,%r9d
  81e342:	and    $0x7fffffff,%r9d
  81e349:	cmp    $0x7f7fffff,%r9d
  81e350:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e356:	pand   -0x770b6e(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e35e:	ucomiss -0x76f201(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e365:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e36b:	movd   0x20(%rcx),%xmm0
  81e370:	movd   %xmm0,%r9d
  81e375:	and    $0x7fffffff,%r9d
  81e37c:	cmp    $0x7f7fffff,%r9d
  81e383:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e389:	pand   -0x770ba1(%rip),%xmm0        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e391:	ucomiss -0x76f234(%rip),%xmm0        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e398:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e39e:	movd   0x24(%rcx),%xmm0
  81e3a3:	movd   %xmm0,%r9d
  81e3a8:	and    $0x7fffffff,%r9d
  81e3af:	cmp    $0x7f7fffff,%r9d
  81e3b6:	jg     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3bc:	movdqa -0x770bd4(%rip),%xmm1        # ad7f0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3c4:	pand   %xmm0,%xmm1
  81e3c8:	ucomiss -0x76f26b(%rip),%xmm1        # af164 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3cf:	ja     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3d5:	xorps  %xmm1,%xmm1
  81e3d8:	ucomiss %xmm1,%xmm0
  81e3db:	jb     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3e1:	movss  -0x76f609(%rip),%xmm1        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3e9:	ucomiss %xmm0,%xmm1
  81e3ec:	jb     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e3f2:	movzwl 0x30(%rcx),%r9d
  81e3f7:	mov    %r9d,0x10(%rsp)
  81e3fc:	movzwl 0x32(%rcx),%r9d
  81e401:	mov    %r9d,0x30(%rsp)
  81e406:	cmp    $0x28,%r10d
  81e40a:	mov    %r8,0x4b8(%rsp)
  81e412:	mov    %rcx,0x120(%rsp)
  81e41a:	mov    %rdx,0xa0(%rsp)
  81e422:	mov    %r13,0x38(%rsp)
  81e427:	movd   %xmm2,0x2e8(%rsp)
  81e430:	movss  %xmm1,0xf4(%rsp)
  81e439:	jne    81e445 <<gpui_gpu::renderer::RendererState>::render+0x425>
  81e43b:	test   $0x1,%al
  81e43d:	je     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e443:	jmp    81e460 <<gpui_gpu::renderer::RendererState>::render+0x440>
  81e445:	test   $0x1,%al
  81e447:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e44d:	ucomiss -0x76f674(%rip),%xmm0        # aede0 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e454:	jne    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e45a:	jp     81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81e460:	mov    %rbx,0x100(%rsp)
  81e468:	mov    %r11,0x108(%rsp)
  81e470:	mov    %r10d,0x2e4(%rsp)
  81e478:	mov    %rdi,0x50(%rsp)
  81e47d:	lea    0xf(%r14),%rax
  81e481:	shr    $0x4,%rax
  81e485:	lea    0xf(%r15),%ecx
  81e489:	shr    $0x4,%ecx
  81e48c:	lea    0x18(%rsi),%rdi
  81e490:	movq   $0x0,0x28(%rsi)
  81e498:	mov    %rax,0x90(%rsp)
  81e4a0:	imul   %eax,%ecx
  81e4a3:	movabs $0x4000000000000000,%rdx
  81e4ad:	mov    %rdi,0x4c8(%rsp)
  81e4b5:	mov    %rsi,%r13
  81e4b8:	mov    %rcx,0x40(%rsp)
  81e4bd:	mov    %rcx,%rsi
  81e4c0:	call   823680 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e4c5:	mov    %r13,0x8(%rsp)
  81e4ca:	mov    0x10(%r13),%rax
  81e4ce:	mov    %rax,0x348(%rsp)
  81e4d6:	mov    0x120(%rsp),%rdi
  81e4de:	call   *0x661bfc(%rip)        # e800e0 <_DYNAMIC+0x5a8>
  81e4e4:	mov    %rdx,0x358(%rsp)
  81e4ec:	mov    %rax,0x350(%rsp)
  81e4f4:	sub    %rax,%rdx
  81e4f7:	cmp    $0x300000,%rdx
  81e4fe:	ja     81e635 <<gpui_gpu::renderer::RendererState>::render+0x615>
  81e504:	mov    %rdx,%rcx
  81e507:	mov    %rdx,%rax
  81e50a:	shr    $0x3,%rax
  81e50e:	movabs $0xaaaaaaaaaaaaaaab,%rdx
  81e518:	imul   %rax,%rdx
  81e51c:	mov    %rdx,0x2c0(%rsp)
  81e524:	mov    0x350(%rsp),%rax
  81e52c:	cmp    %rax,0x358(%rsp)
  81e534:	je     81e565 <<gpui_gpu::renderer::RendererState>::render+0x545>
  81e536:	mov    $0xaaaaaaab,%eax
  81e53b:	imul   %rax,%rcx
  81e53f:	shr    $0x2a,%rcx
  81e543:	mov    0x2c0(%rsp),%rdx
  81e54b:	mov    %edx,%eax
  81e54d:	and    $0x3f,%eax
  81e550:	add    %rdx,%rcx
  81e553:	cmp    $0x1,%rax
  81e557:	sbb    $0xffffffffffffffff,%rcx
  81e55b:	inc    %rcx
  81e55e:	mov    %rcx,0x20(%rsp)
  81e563:	jmp    81e56e <<gpui_gpu::renderer::RendererState>::render+0x54e>
  81e565:	movq   $0x0,0x20(%rsp)
  81e56e:	mov    0x100(%rsp),%rax
  81e576:	mov    0x98(%rax),%rdx
  81e57d:	add    0xb0(%rax),%rdx
  81e584:	mov    0x30(%rsp),%ecx
  81e588:	shl    $0x10,%ecx
  81e58b:	add    0x10(%rsp),%ecx
  81e58f:	mov    %rax,0x130(%rsp)
  81e597:	movq   $0x0,0x138(%rsp)
  81e5a3:	mov    0x108(%rsp),%rbx
  81e5ab:	mov    %rbx,0x140(%rsp)
  81e5b3:	mov    %rdx,0x340(%rsp)
  81e5bb:	mov    %rdx,0x148(%rsp)
  81e5c3:	mov    %ecx,0x30(%rsp)
  81e5c7:	mov    %ecx,0x150(%rsp)
  81e5ce:	mov    0x8(%rsp),%r13
  81e5d3:	movzbl 0x341(%r13),%esi
  81e5db:	lea    0x130(%rsp),%rdi
  81e5e3:	call   81c740 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::fold::<usize, core::iter::adapters::map::map_fold<gpui_canvas::canvas::PreparedGroup, usize, usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, <usize as core::iter::traits::accum::Sum>::sum<core::iter::adapters::map::Map<gpui_canvas::canvas::Groups, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}>>::{closure#0}>::{closure#0}>>
  81e5e8:	mov    %rax,0x110(%rsp)
  81e5f0:	mov    0x20(%rsp),%rcx
  81e5f5:	lea    (%rcx,%rax,4),%rcx
  81e5f9:	mov    %rcx,0x10(%rsp)
  81e5fe:	lea    (%rcx,%rbx,2),%rax
  81e602:	xor    %edx,%edx
  81e604:	mov    %rax,0x2b8(%rsp)
  81e60c:	sub    0x348(%rsp),%rax
  81e614:	cmovae %rax,%rdx
  81e618:	mov    0x10(%r13),%rsi
  81e61c:	mov    $0x4,%ecx
  81e621:	mov    $0x10,%r8d
  81e627:	mov    %r13,%rdi
  81e62a:	call   825e40 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e62f:	cmp    $0xffffffffffffffff,%rax
  81e633:	je     81e645 <<gpui_gpu::renderer::RendererState>::render+0x625>
  81e635:	mov    0x50(%rsp),%rdi
  81e63a:	movl   $0x6,(%rdi)
  81e640:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81e645:	pxor   %xmm0,%xmm0
  81e649:	movdqa %xmm0,0x130(%rsp)
  81e652:	lea    0x130(%rsp),%rdx
  81e65a:	mov    0x8(%rsp),%rbx
  81e65f:	mov    %rbx,%rdi
  81e662:	mov    0x108(%rsp),%rax
  81e66a:	mov    0x10(%rsp),%rcx
  81e66f:	lea    (%rcx,%rax,2),%rsi
  81e673:	call   8237a0 <<alloc::vec::Vec<[u32; 4]>>::resize>
  81e678:	movq   $0xffffffffffffffff,0x2d0(%rsp)
  81e684:	movq   $0x0,0x2d8(%rsp)
  81e690:	movq   $0xffffffffffffffff,0x230(%rsp)
  81e69c:	movq   $0x0,0x238(%rsp)
  81e6a8:	mov    0x10(%rbx),%rdx
  81e6ac:	cmp    %rdx,0x20(%rsp)
  81e6b1:	ja     8203a8 <<gpui_gpu::renderer::RendererState>::render+0x2388>
  81e6b7:	mov    0x8(%rsp),%r13
  81e6bc:	mov    0x8(%r13),%rdi
  81e6c0:	lea    0x2d0(%rsp),%r8
  81e6c8:	mov    0x20(%rsp),%rsi
  81e6cd:	mov    0x120(%rsp),%rdx
  81e6d5:	mov    0x2c0(%rsp),%rcx
  81e6dd:	call   8258d0 <gpui_gpu::renderer::slots::write_prefix>
  81e6e2:	lea    0x48(%r13),%rdi
  81e6e6:	movq   $0x0,0x58(%r13)
  81e6ee:	mov    %rdi,0x4c0(%rsp)
  81e6f6:	mov    0x40(%rsp),%rsi
  81e6fb:	xor    %edx,%edx
  81e6fd:	call   823890 <<alloc::vec::Vec<u32>>::resize>
  81e702:	movq   $0x0,0x70(%r13)
  81e70a:	cmpq   $0x0,0x60(%r13)
  81e70f:	jne    81e720 <<gpui_gpu::renderer::RendererState>::render+0x700>
  81e711:	mov    0x8(%rsp),%rax
  81e716:	lea    0x60(%rax),%rdi
  81e71a:	call   *0x6619c8(%rip)        # e800e8 <_DYNAMIC+0x5b0>
  81e720:	mov    0x110(%rsp),%rax
  81e728:	add    %rax,%rax
  81e72b:	mov    %rax,0x110(%rsp)
  81e733:	mov    0x8(%rsp),%rax
  81e738:	mov    0x68(%rax),%rcx
  81e73c:	pxor   %xmm0,%xmm0
  81e740:	movdqu %xmm0,0x10(%rcx)
  81e745:	movdqu %xmm0,(%rcx)
  81e749:	movq   $0x1,0x70(%rax)
  81e751:	lea    0x2f8(%rax),%rdi
  81e758:	call   8230d0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e75d:	mov    0x100(%rsp),%rax
  81e765:	mov    %rax,0x368(%rsp)
  81e76d:	movq   $0x0,0x370(%rsp)
  81e779:	mov    0x108(%rsp),%rax
  81e781:	mov    %rax,0x378(%rsp)
  81e789:	mov    0x340(%rsp),%rax
  81e791:	mov    %rax,0x380(%rsp)
  81e799:	mov    0x30(%rsp),%eax
  81e79d:	mov    %eax,0x388(%rsp)
  81e7a4:	lea    0x408(%rsp),%rdi
  81e7ac:	lea    0x368(%rsp),%rsi
  81e7b4:	call   *0x661936(%rip)        # e800f0 <_DYNAMIC+0x5b8>
  81e7ba:	mov    0x408(%rsp),%rax
  81e7c2:	mov    %rax,0x28(%rsp)
  81e7c7:	test   %rax,%rax
  81e7ca:	je     81f256 <<gpui_gpu::renderer::RendererState>::render+0x1236>
  81e7d0:	movq   $0x0,0x118(%rsp)
  81e7dc:	movq   $0x0,0x68(%rsp)
  81e7e5:	movq   $0x0,0x88(%rsp)
  81e7f1:	movq   $0x0,0x2a8(%rsp)
  81e7fd:	movq   $0x0,0x2b0(%rsp)
  81e809:	mov    0x410(%rsp),%rbx
  81e811:	mov    0x418(%rsp),%r13
  81e819:	lea    0x420(%rsp),%rcx
  81e821:	movups (%rcx),%xmm0
  81e824:	movups 0x10(%rcx),%xmm1
  81e828:	movups 0x20(%rcx),%xmm2
  81e82c:	movaps %xmm2,0x290(%rsp)
  81e834:	movaps %xmm1,0x280(%rsp)
  81e83c:	movaps %xmm0,0x270(%rsp)
  81e844:	lea    0x450(%rsp),%rdx
  81e84c:	movups (%rdx),%xmm0
  81e84f:	movaps %xmm0,0x330(%rsp)
  81e857:	movups 0x40(%rcx),%xmm0
  81e85b:	movaps %xmm0,0x320(%rsp)
  81e863:	mov    0x8(%rsp),%rax
  81e868:	movzbl 0x341(%rax),%esi
  81e86f:	mov    0x28(%rsp),%rax
  81e874:	mov    %rax,0x130(%rsp)
  81e87c:	mov    %rbx,0x138(%rsp)
  81e884:	mov    %r13,0x140(%rsp)
  81e88c:	movups (%rcx),%xmm0
  81e88f:	movdqu 0x10(%rcx),%xmm1
  81e894:	movdqu 0x20(%rcx),%xmm2
  81e899:	lea    0x148(%rsp),%rdi
  81e8a1:	movdqu %xmm2,0x20(%rdi)
  81e8a6:	movdqu %xmm1,0x10(%rdi)
  81e8ab:	movups %xmm0,(%rdi)
  81e8ae:	movups (%rdx),%xmm0
  81e8b1:	lea    0x178(%rsp),%rax
  81e8b9:	movups %xmm0,(%rax)
  81e8bc:	movdqu 0x40(%rcx),%xmm0
  81e8c1:	movdqu %xmm0,0x40(%rdi)
  81e8c6:	lea    0x130(%rsp),%rdi
  81e8ce:	call   8215f0 <gpui_gpu::renderer::compact_group>
  81e8d3:	mov    %rbx,0xa8(%rsp)
  81e8db:	mov    %r13,0xe0(%rsp)
  81e8e3:	lea    (%rbx,%r13,4),%rbx
  81e8e7:	mov    %al,0x1f(%rsp)
  81e8eb:	test   %al,%al
  81e8ed:	je     81eae2 <<gpui_gpu::renderer::RendererState>::render+0xac2>
  81e8f3:	mov    0xa8(%rsp),%rax
  81e8fb:	mov    %rax,0x490(%rsp)
  81e903:	mov    %rbx,0x498(%rsp)
  81e90b:	mov    0x28(%rsp),%rax
  81e910:	mov    %rax,0x4a0(%rsp)
  81e918:	movq   $0x0,0x4a8(%rsp)
  81e924:	lea    0x3a0(%rsp),%rdi
  81e92c:	lea    0x490(%rsp),%rsi
  81e934:	call   821c80 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e939:	cmpb   $0xff,0x3a8(%rsp)
  81e941:	je     81eaf0 <<gpui_gpu::renderer::RendererState>::render+0xad0>
  81e947:	pxor   %xmm0,%xmm0
  81e94b:	movdqa %xmm0,0x70(%rsp)
  81e951:	movdqa %xmm0,0x40(%rsp)
  81e957:	mov    0x3a0(%rsp),%rdx
  81e95f:	add    0x88(%rsp),%rdx
  81e967:	lea    0x3a8(%rsp),%rcx
  81e96f:	movups 0x38(%rcx),%xmm0
  81e973:	lea    0x148(%rsp),%rax
  81e97b:	movups %xmm0,0x20(%rax)
  81e97f:	movups 0x48(%rcx),%xmm0
  81e983:	lea    0x178(%rsp),%rsi
  81e98b:	movups %xmm0,0x40(%rsi)
  81e98f:	mov    0x30(%rcx),%rax
  81e993:	mov    %rax,0x160(%rsp)
  81e99b:	movups (%rcx),%xmm0
  81e99e:	movups 0x10(%rcx),%xmm1
  81e9a2:	movups 0x20(%rcx),%xmm2
  81e9a6:	movaps %xmm2,0x150(%rsp)
  81e9ae:	movaps %xmm1,0x140(%rsp)
  81e9b6:	movaps %xmm0,0x130(%rsp)
  81e9be:	lea    0x420(%rsp),%rax
  81e9c6:	movups (%rax),%xmm0
  81e9c9:	movups 0x10(%rax),%xmm1
  81e9cd:	movups 0x20(%rax),%xmm2
  81e9d1:	movups %xmm2,0x20(%rsi)
  81e9d5:	movups %xmm1,0x10(%rsi)
  81e9d9:	movups %xmm0,(%rsi)
  81e9dc:	lea    0x450(%rsp),%rcx
  81e9e4:	movups (%rcx),%xmm0
  81e9e7:	movups %xmm0,0x30(%rsi)
  81e9eb:	movups 0x40(%rax),%xmm0
  81e9ef:	movups %xmm0,0x50(%rsi)
  81e9f3:	lea    0x240(%rsp),%rdi
  81e9fb:	lea    0x130(%rsp),%rsi
  81ea03:	mov    %r14d,%ecx
  81ea06:	mov    %r15d,%r8d
  81ea09:	call   821640 <gpui_gpu::renderer::validate_draw>
  81ea0e:	mov    0x240(%rsp),%ecx
  81ea15:	mov    0x244(%rsp),%rax
  81ea1d:	cmp    $0xffffffff,%ecx
  81ea20:	jne    81f332 <<gpui_gpu::renderer::RendererState>::render+0x1312>
  81ea26:	mov    %eax,%ecx
  81ea28:	shr    $0x20,%rax
  81ea2c:	movd   %ecx,%xmm0
  81ea30:	movaps 0x70(%rsp),%xmm2
  81ea35:	movaps %xmm2,%xmm1
  81ea38:	maxss  %xmm0,%xmm1
  81ea3c:	movaps %xmm1,%xmm3
  81ea3f:	cmpunordss %xmm1,%xmm3
  81ea44:	movaps %xmm3,%xmm0
  81ea47:	andnps %xmm1,%xmm0
  81ea4a:	andps  %xmm2,%xmm3
  81ea4d:	orps   %xmm0,%xmm3
  81ea50:	movaps %xmm3,0xc0(%rsp)
  81ea58:	movd   %eax,%xmm0
  81ea5c:	movaps 0x40(%rsp),%xmm2
  81ea61:	movaps %xmm2,%xmm1
  81ea64:	maxss  %xmm0,%xmm1
  81ea68:	movaps %xmm1,%xmm3
  81ea6b:	cmpunordss %xmm1,%xmm3
  81ea70:	movaps %xmm3,%xmm0
  81ea73:	andnps %xmm1,%xmm0
  81ea76:	andps  %xmm2,%xmm3
  81ea79:	orps   %xmm0,%xmm3
  81ea7c:	movaps %xmm3,0xb0(%rsp)
  81ea84:	lea    0x3a0(%rsp),%rdi
  81ea8c:	lea    0x490(%rsp),%rsi
  81ea94:	call   821c80 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea99:	cmpb   $0xff,0x3a8(%rsp)
  81eaa1:	movdqa 0xc0(%rsp),%xmm1
  81eaaa:	movdqa %xmm1,0x70(%rsp)
  81eab0:	movdqa 0xb0(%rsp),%xmm2
  81eab9:	movdqa %xmm2,0x40(%rsp)
  81eabf:	jne    81e957 <<gpui_gpu::renderer::RendererState>::render+0x937>
  81eac5:	movdqa %xmm1,%xmm0
  81eac9:	movd   %xmm0,%ecx
  81eacd:	movd   %xmm2,%eax
  81ead1:	shl    $0x20,%rax
  81ead5:	or     %rax,%rcx
  81ead8:	mov    %rcx,0xf8(%rsp)
  81eae0:	jmp    81eafc <<gpui_gpu::renderer::RendererState>::render+0xadc>
  81eae2:	movq   $0x0,0xf8(%rsp)
  81eaee:	jmp    81eb14 <<gpui_gpu::renderer::RendererState>::render+0xaf4>
  81eaf0:	movq   $0x0,0xf8(%rsp)
  81eafc:	incq   0x2a8(%rsp)
  81eb04:	mov    0xe0(%rsp),%rax
  81eb0c:	add    %rax,0x2b0(%rsp)
  81eb14:	mov    0xa8(%rsp),%rax
  81eb1c:	mov    %rax,0x240(%rsp)
  81eb24:	mov    %rbx,0x248(%rsp)
  81eb2c:	mov    0x28(%rsp),%rax
  81eb31:	mov    %rax,0x250(%rsp)
  81eb39:	movq   $0x0,0x258(%rsp)
  81eb45:	lea    0x3a0(%rsp),%rdi
  81eb4d:	lea    0x240(%rsp),%rsi
  81eb55:	call   821c80 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81eb5a:	movzbl 0x3a8(%rsp),%eax
  81eb62:	cmp    $0xff,%al
  81eb64:	je     81f228 <<gpui_gpu::renderer::RendererState>::render+0x1208>
  81eb6a:	mov    %eax,%r8d
  81eb6d:	mov    0x10(%rsp),%rax
  81eb72:	lea    0x8(,%rax,8),%rax
  81eb7a:	mov    %rax,0x128(%rsp)
  81eb82:	mov    0x20(%rsp),%rax
  81eb87:	mov    %rax,0x80(%rsp)
  81eb8f:	mov    0x3a0(%rsp),%rax
  81eb97:	movups 0x3e0(%rsp),%xmm3
  81eb9f:	lea    0x3a8(%rsp),%rsi
  81eba7:	movups 0x48(%rsi),%xmm0
  81ebab:	lea    0x518(%rsp),%rdi
  81ebb3:	movups %xmm0,0x40(%rdi)
  81ebb7:	mov    0x1(%rsi),%ecx
  81ebba:	mov    0x4(%rsi),%edx
  81ebbd:	mov    %edx,-0x44(%rdi)
  81ebc0:	mov    %ecx,-0x47(%rdi)
  81ebc3:	mov    0x3b0(%rsp),%rdx
  81ebcb:	mov    0x30(%rsi),%rcx
  81ebcf:	mov    %rcx,-0x18(%rdi)
  81ebd3:	movups 0x10(%rsi),%xmm0
  81ebd7:	movups 0x20(%rsi),%xmm1
  81ebdb:	movups %xmm1,-0x28(%rdi)
  81ebdf:	movups %xmm0,-0x38(%rdi)
  81ebe3:	movaps 0x270(%rsp),%xmm0
  81ebeb:	movaps 0x280(%rsp),%xmm1
  81ebf3:	movaps 0x290(%rsp),%xmm2
  81ebfb:	movups %xmm2,0x20(%rdi)
  81ebff:	movups %xmm1,0x10(%rdi)
  81ec03:	movups %xmm0,(%rdi)
  81ec06:	movaps 0x330(%rsp),%xmm0
  81ec0e:	movups %xmm0,0x30(%rdi)
  81ec12:	movaps 0x320(%rsp),%xmm0
  81ec1a:	movups %xmm0,0x50(%rdi)
  81ec1e:	movaps %xmm3,0xc0(%rsp)
  81ec26:	movups %xmm3,0x508(%rsp)
  81ec2e:	mov    %r8b,0x70(%rsp)
  81ec33:	mov    %r8b,0x4d0(%rsp)
  81ec3b:	mov    %rdx,0x310(%rsp)
  81ec43:	mov    %rdx,0x4d8(%rsp)
  81ec4b:	cmpb   $0x0,0x1f(%rsp)
  81ec50:	je     81ec98 <<gpui_gpu::renderer::RendererState>::render+0xc78>
  81ec52:	mov    0xf8(%rsp),%rcx
  81ec5a:	mov    %rcx,0x40(%rsp)
  81ec5f:	mov    0x20(%rsp),%rcx
  81ec64:	mov    %rcx,0xb0(%rsp)
  81ec6c:	test   %rax,%rax
  81ec6f:	je     81ece8 <<gpui_gpu::renderer::RendererState>::render+0xcc8>
  81ec71:	mov    0xf8(%rsp),%rax
  81ec79:	mov    %rax,0x40(%rsp)
  81ec7e:	mov    0x20(%rsp),%rax
  81ec83:	mov    %rax,0xb0(%rsp)
  81ec8b:	lea    0x130(%rsp),%rbx
  81ec93:	jmp    81f000 <<gpui_gpu::renderer::RendererState>::render+0xfe0>
  81ec98:	lea    0x130(%rsp),%rdi
  81eca0:	lea    0x4d0(%rsp),%rsi
  81eca8:	mov    0x88(%rsp),%rdx
  81ecb0:	mov    %r14d,%ecx
  81ecb3:	mov    %r15d,%r8d
  81ecb6:	call   821640 <gpui_gpu::renderer::validate_draw>
  81ecbb:	mov    0x130(%rsp),%eax
  81ecc2:	mov    0x134(%rsp),%rcx
  81ecca:	mov    %rcx,0x40(%rsp)
  81eccf:	cmp    $0xffffffff,%eax
  81ecd2:	jne    81f3c0 <<gpui_gpu::renderer::RendererState>::render+0x13a0>
  81ecd8:	mov    0x80(%rsp),%rax
  81ece0:	mov    %rax,0xb0(%rsp)
  81ece8:	cmpb   $0x3,0x70(%rsp)
  81eced:	jne    81ed82 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ecf3:	movss  0x4d4(%rsp),%xmm0
  81ecfc:	xorps  %xmm1,%xmm1
  81ecff:	ucomiss %xmm1,%xmm0
  81ed02:	jne    81ed06 <<gpui_gpu::renderer::RendererState>::render+0xce6>
  81ed04:	jnp    81ed82 <<gpui_gpu::renderer::RendererState>::render+0xd62>
  81ed06:	movaps 0xc0(%rsp),%xmm5
  81ed0e:	movaps %xmm5,%xmm1
  81ed11:	unpckhpd %xmm5,%xmm1
  81ed15:	movss  -0x76fd51(%rip),%xmm4        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ed1d:	mulss  %xmm4,%xmm1
  81ed21:	movaps %xmm0,%xmm2
  81ed24:	minss  %xmm1,%xmm2
  81ed28:	movaps %xmm2,%xmm1
  81ed2b:	cmpunordss %xmm2,%xmm1
  81ed30:	movaps %xmm1,%xmm3
  81ed33:	andnps %xmm2,%xmm3
  81ed36:	andps  %xmm0,%xmm1
  81ed39:	orps   %xmm3,%xmm1
  81ed3c:	movaps %xmm5,%xmm0
  81ed3f:	shufps $0xff,%xmm5,%xmm0
  81ed43:	mulss  %xmm4,%xmm0
  81ed47:	movaps %xmm1,%xmm2
  81ed4a:	minss  %xmm0,%xmm2
  81ed4e:	movaps %xmm2,%xmm0
  81ed51:	cmpunordss %xmm2,%xmm0
  81ed56:	andps  %xmm0,%xmm1
  81ed59:	andnps %xmm2,%xmm0
  81ed5c:	orps   %xmm1,%xmm0
  81ed5f:	movd   %xmm0,%eax
  81ed63:	mov    %eax,0x260(%rsp)
  81ed6a:	and    $0xff800000,%eax
  81ed6f:	mov    $0x7f000000,%ecx
  81ed74:	sub    %eax,%ecx
  81ed76:	mov    %ecx,0xd8(%rsp)
  81ed7d:	xorps  %xmm0,%xmm0
  81ed80:	jmp    81eda7 <<gpui_gpu::renderer::RendererState>::render+0xd87>
  81ed82:	mov    0x568(%rsp),%eax
  81ed89:	mov    %eax,0x260(%rsp)
  81ed90:	mov    0x56c(%rsp),%eax
  81ed97:	mov    %eax,0xd8(%rsp)
  81ed9e:	movsd  0x570(%rsp),%xmm0
  81eda7:	movaps %xmm0,0x300(%rsp)
  81edaf:	movups 0x518(%rsp),%xmm0
  81edb7:	movaps %xmm0,0x470(%rsp)
  81edbf:	movups 0x520(%rsp),%xmm0
  81edc7:	movaps %xmm0,0x390(%rsp)
  81edcf:	movsd  0x528(%rsp),%xmm0
  81edd8:	movaps %xmm0,0x220(%rsp)
  81ede0:	movsd  0x530(%rsp),%xmm0
  81ede9:	movaps %xmm0,0x2f0(%rsp)
  81edf1:	movsd  0x538(%rsp),%xmm0
  81edfa:	movsd  %xmm0,0x98(%rsp)
  81ee03:	movsd  0x540(%rsp),%xmm0
  81ee0c:	movsd  %xmm0,0x2c8(%rsp)
  81ee15:	movups 0x548(%rsp),%xmm0
  81ee1d:	movaps %xmm0,0x480(%rsp)
  81ee25:	mov    0x28(%rsp),%rax
  81ee2a:	mov    %rax,0x130(%rsp)
  81ee32:	mov    0xa8(%rsp),%rax
  81ee3a:	mov    %rax,0x138(%rsp)
  81ee42:	mov    0xe0(%rsp),%rax
  81ee4a:	mov    %rax,0x140(%rsp)
  81ee52:	movaps 0x270(%rsp),%xmm0
  81ee5a:	movaps 0x280(%rsp),%xmm1
  81ee62:	movaps 0x290(%rsp),%xmm2
  81ee6a:	lea    0x148(%rsp),%rcx
  81ee72:	movups %xmm2,0x20(%rcx)
  81ee76:	movups %xmm1,0x10(%rcx)
  81ee7a:	movups %xmm0,(%rcx)
  81ee7d:	movaps 0x330(%rsp),%xmm0
  81ee85:	lea    0x178(%rsp),%rax
  81ee8d:	movups %xmm0,(%rax)
  81ee90:	movaps 0x320(%rsp),%xmm0
  81ee98:	movups %xmm0,0x40(%rcx)
  81ee9c:	lea    0x130(%rsp),%rdi
  81eea4:	call   *0x66124e(%rip)        # e800f8 <_DYNAMIC+0x5c0>
  81eeaa:	test   %eax,%eax
  81eeac:	je     81eeda <<gpui_gpu::renderer::RendererState>::render+0xeba>
  81eeae:	mov    0x2c0(%rsp),%rdi
  81eeb6:	mov    %eax,%esi
  81eeb8:	call   825890 <gpui_gpu::renderer::slots::color_word>
  81eebd:	mov    %eax,0x260(%rsp)
  81eec4:	xorps  %xmm0,%xmm0
  81eec7:	movaps %xmm0,0x300(%rsp)
  81eecf:	movl   $0x0,0xd8(%rsp)
  81eeda:	movsd  0x2c8(%rsp),%xmm0
  81eee3:	cvtsd2ss %xmm0,%xmm0
  81eee7:	movapd 0x390(%rsp),%xmm1
  81eef0:	unpcklpd 0x2f0(%rsp),%xmm1
  81eef9:	cvtpd2ps %xmm1,%xmm1
  81eefd:	movsd  0x98(%rsp),%xmm2
  81ef06:	cvtsd2ss %xmm2,%xmm2
  81ef0a:	movapd 0x470(%rsp),%xmm3
  81ef13:	unpcklpd 0x220(%rsp),%xmm3
  81ef1c:	cvtpd2ps %xmm3,%xmm3
  81ef20:	mov    0x40(%rsp),%rcx
  81ef25:	mov    %rcx,%rax
  81ef28:	shr    $0x20,%rax
  81ef2c:	mov    0x8(%rsp),%rdx
  81ef31:	mov    0x8(%rdx),%rsi
  81ef35:	mov    0x10(%rdx),%rdx
  81ef39:	movlpd %xmm3,0x130(%rsp)
  81ef42:	movss  %xmm2,0x138(%rsp)
  81ef4b:	mov    %ecx,0x13c(%rsp)
  81ef52:	movlpd %xmm1,0x140(%rsp)
  81ef5b:	movss  %xmm0,0x148(%rsp)
  81ef64:	mov    %eax,0x14c(%rsp)
  81ef6b:	lea    0x2d0(%rsp),%rdi
  81ef73:	mov    0x80(%rsp),%r13
  81ef7b:	mov    %r13,%rcx
  81ef7e:	lea    0x130(%rsp),%rbx
  81ef86:	mov    %rbx,%r8
  81ef89:	call   81b6a0 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81ef8e:	mov    0x8(%rsp),%rax
  81ef93:	mov    0x8(%rax),%rsi
  81ef97:	mov    0x10(%rax),%rdx
  81ef9b:	mov    0x110(%rsp),%rax
  81efa3:	lea    0x0(%r13,%rax,1),%rcx
  81efa8:	movaps 0x480(%rsp),%xmm0
  81efb0:	movaps %xmm0,0x130(%rsp)
  81efb8:	mov    0x260(%rsp),%eax
  81efbf:	mov    %eax,0x140(%rsp)
  81efc6:	mov    0xd8(%rsp),%eax
  81efcd:	mov    %eax,0x144(%rsp)
  81efd4:	movaps 0x300(%rsp),%xmm0
  81efdc:	movlps %xmm0,0x148(%rsp)
  81efe4:	lea    0x2d0(%rsp),%rdi
  81efec:	mov    %rbx,%r8
  81efef:	call   81b6a0 <<gpui_gpu::renderer::Changes>::replace::<2>>
  81eff4:	add    $0x2,%r13
  81eff8:	mov    %r13,0x80(%rsp)
  81f000:	cmpb   $0x2,0x70(%rsp)
  81f005:	sete   0x260(%rsp)
  81f00d:	cmpq   $0x0,0x310(%rsp)
  81f016:	setne  0x310(%rsp)
  81f01e:	mov    0x28(%rsp),%rax
  81f023:	mov    %rax,0x130(%rsp)
  81f02b:	mov    0xa8(%rsp),%rax
  81f033:	mov    %rax,0x138(%rsp)
  81f03b:	mov    0xe0(%rsp),%rax
  81f043:	mov    %rax,0x140(%rsp)
  81f04b:	movaps 0x270(%rsp),%xmm0
  81f053:	movdqa 0x280(%rsp),%xmm1
  81f05c:	movdqa 0x290(%rsp),%xmm2
  81f065:	lea    0x148(%rsp),%rcx
  81f06d:	movdqu %xmm2,0x20(%rcx)
  81f072:	movdqu %xmm1,0x10(%rcx)
  81f077:	movups %xmm0,(%rcx)
  81f07a:	movaps 0x330(%rsp),%xmm0
  81f082:	lea    0x178(%rsp),%rax
  81f08a:	movups %xmm0,(%rax)
  81f08d:	movaps 0x320(%rsp),%xmm0
  81f095:	movups %xmm0,0x40(%rcx)
  81f099:	mov    %rbx,%rdi
  81f09c:	call   *0x661056(%rip)        # e800f8 <_DYNAMIC+0x5c0>
  81f0a2:	mov    %eax,0x70(%rsp)
  81f0a6:	mov    0x8(%rsp),%r13
  81f0ab:	mov    0x8(%r13),%rsi
  81f0af:	mov    0x10(%r13),%rdx
  81f0b3:	movdqa 0xc0(%rsp),%xmm0
  81f0bc:	movdqa %xmm0,0x130(%rsp)
  81f0c5:	lea    0x230(%rsp),%rdi
  81f0cd:	mov    %rbx,%r8
  81f0d0:	mov    0x10(%rsp),%rbx
  81f0d5:	mov    %rbx,%rcx
  81f0d8:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f0dd:	lea    0x1(%rbx),%rcx
  81f0e1:	mov    0x10(%r13),%rdx
  81f0e5:	cmp    %rdx,%rcx
  81f0e8:	jae    8203d2 <<gpui_gpu::renderer::RendererState>::render+0x23b2>
  81f0ee:	mov    0xb0(%rsp),%rsi
  81f0f6:	mov    %esi,%edi
  81f0f8:	or     $0x80000000,%edi
  81f0fe:	cmpl   $0x0,0x70(%rsp)
  81f103:	cmove  %esi,%edi
  81f106:	mov    0x8(%r13),%rsi
  81f10a:	mov    0x128(%rsp),%r13
  81f112:	mov    0x8(%rsi,%r13,2),%r8d
  81f117:	mov    %r8d,0x138(%rsp)
  81f11f:	mov    (%rsi,%r13,2),%r8
  81f123:	mov    %r8,0x130(%rsp)
  81f12b:	mov    %edi,0x13c(%rsp)
  81f132:	lea    0x230(%rsp),%rdi
  81f13a:	lea    0x130(%rsp),%r8
  81f142:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f147:	lea    0x130(%rsp),%rdi
  81f14f:	mov    0x8(%rsp),%rsi
  81f154:	lea    0x4d0(%rsp),%rdx
  81f15c:	mov    0x40(%rsp),%rcx
  81f161:	mov    %rbx,0x10(%rsp)
  81f166:	mov    %ebx,%r8d
  81f169:	mov    0x88(%rsp),%rbx
  81f171:	mov    %rbx,%r9
  81f174:	push   0x118(%rsp)
  81f17b:	push   %r15
  81f17d:	push   %r14
  81f17f:	push   0xa8(%rsp)
  81f186:	call   820450 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f18b:	add    $0x20,%rsp
  81f18f:	mov    0x130(%rsp),%eax
  81f196:	cmp    $0xffffffff,%eax
  81f199:	jne    81f390 <<gpui_gpu::renderer::RendererState>::render+0x1370>
  81f19f:	movzbl 0x260(%rsp),%ecx
  81f1a7:	and    0x310(%rsp),%cl
  81f1ae:	mov    0x68(%rsp),%rax
  81f1b3:	or     %cl,%al
  81f1b5:	mov    %rax,0x68(%rsp)
  81f1ba:	addq   $0x2,0x10(%rsp)
  81f1c0:	mov    0x138(%rsp),%rax
  81f1c8:	mov    %rax,0x118(%rsp)
  81f1d0:	inc    %rbx
  81f1d3:	mov    %rbx,0x88(%rsp)
  81f1db:	lea    0x3a0(%rsp),%rdi
  81f1e3:	lea    0x240(%rsp),%rsi
  81f1eb:	call   821c80 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81f1f0:	movzbl 0x3a8(%rsp),%r8d
  81f1f9:	add    $0x10,%r13
  81f1fd:	mov    %r13,0x128(%rsp)
  81f205:	cmp    $0xff,%r8b
  81f209:	jne    81eb8f <<gpui_gpu::renderer::RendererState>::render+0xb6f>
  81f20f:	mov    0x68(%rsp),%rax
  81f214:	and    $0x1,%al
  81f216:	mov    %rax,0x68(%rsp)
  81f21b:	mov    0x80(%rsp),%rax
  81f223:	mov    %rax,0x20(%rsp)
  81f228:	lea    0x408(%rsp),%rdi
  81f230:	lea    0x368(%rsp),%rsi
  81f238:	call   *0x660eb2(%rip)        # e800f0 <_DYNAMIC+0x5b8>
  81f23e:	mov    0x408(%rsp),%rax
  81f246:	mov    %rax,0x28(%rsp)
  81f24b:	test   %rax,%rax
  81f24e:	jne    81e809 <<gpui_gpu::renderer::RendererState>::render+0x7e9>
  81f254:	jmp    81f28f <<gpui_gpu::renderer::RendererState>::render+0x126f>
  81f256:	movq   $0x0,0x2b0(%rsp)
  81f262:	movq   $0x0,0x2a8(%rsp)
  81f26e:	movq   $0x0,0x88(%rsp)
  81f27a:	movq   $0x0,0x68(%rsp)
  81f283:	movq   $0x0,0x118(%rsp)
  81f28f:	mov    0xa0(%rsp),%rsi
  81f297:	lea    0x8(%rsi),%rdx
  81f29b:	mov    0x8(%rsp),%rax
  81f2a0:	lea    0x258(%rax),%rcx
  81f2a7:	lea    0x328(%rax),%r8
  81f2ae:	mov    0x10(%rax),%r9
  81f2b2:	sub    $0x8,%rsp
  81f2b6:	lea    0x138(%rsp),%rdi
  81f2be:	mov    %rdx,0x2f8(%rsp)
  81f2c6:	mov    %rcx,0xa0(%rsp)
  81f2ce:	mov    %r8,0x488(%rsp)
  81f2d6:	push   0x128(%rsp)
  81f2dd:	call   8239e0 <gpui_gpu::renderer::images::prepare>
  81f2e2:	add    $0x10,%rsp
  81f2e6:	mov    0x130(%rsp),%eax
  81f2ed:	movzbl 0x134(%rsp),%ecx
  81f2f5:	mov    %cl,0x390(%rsp)
  81f2fc:	cmp    $0xffffffff,%eax
  81f2ff:	je     81f358 <<gpui_gpu::renderer::RendererState>::render+0x1338>
  81f301:	movupd 0x135(%rsp),%xmm0
  81f30a:	movups 0x140(%rsp),%xmm1
  81f312:	mov    0x50(%rsp),%rdi
  81f317:	movups %xmm1,0x10(%rdi)
  81f31b:	movupd %xmm0,0x5(%rdi)
  81f320:	mov    %eax,(%rdi)
  81f322:	movzbl 0x390(%rsp),%eax
  81f32a:	mov    %al,0x4(%rdi)
  81f32d:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f332:	mov    0x25c(%rsp),%edx
  81f339:	mov    0x50(%rsp),%rdi
  81f33e:	mov    %edx,0x1c(%rdi)
  81f341:	movups 0x24c(%rsp),%xmm0
  81f349:	movups %xmm0,0xc(%rdi)
  81f34d:	mov    %ecx,(%rdi)
  81f34f:	mov    %rax,0x4(%rdi)
  81f353:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f358:	movzbl 0x68(%rsp),%r8d
  81f35e:	and    $0x1,%r8d
  81f362:	lea    0x130(%rsp),%rdi
  81f36a:	mov    0x8(%rsp),%rsi
  81f36f:	mov    0xa0(%rsp),%rdx
  81f377:	mov    0x100(%rsp),%rcx
  81f37f:	call   81d780 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f384:	mov    0x130(%rsp),%eax
  81f38b:	cmp    $0xffffffff,%eax
  81f38e:	je     81f3eb <<gpui_gpu::renderer::RendererState>::render+0x13cb>
  81f390:	mov    0x134(%rsp),%ecx
  81f397:	mov    0x138(%rsp),%rdx
  81f39f:	movupd 0x140(%rsp),%xmm0
  81f3a8:	mov    0x50(%rsp),%rdi
  81f3ad:	movupd %xmm0,0x10(%rdi)
  81f3b2:	mov    %eax,(%rdi)
  81f3b4:	mov    %ecx,0x4(%rdi)
  81f3b7:	mov    %rdx,0x8(%rdi)
  81f3bb:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3c0:	mov    0x14c(%rsp),%ecx
  81f3c7:	mov    0x50(%rsp),%rdi
  81f3cc:	mov    %ecx,0x1c(%rdi)
  81f3cf:	movups 0x13c(%rsp),%xmm0
  81f3d7:	movups %xmm0,0xc(%rdi)
  81f3db:	mov    %eax,(%rdi)
  81f3dd:	mov    0x40(%rsp),%rax
  81f3e2:	mov    %rax,0x4(%rdi)
  81f3e6:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  81f3eb:	mov    0x138(%rsp),%rax
  81f3f3:	mov    %rax,0x2c8(%rsp)
  81f3fb:	mov    0x8(%rsp),%rax
  81f400:	mov    0x28(%rax),%rax
  81f404:	movq   $0x0,0x220(%rsp)
  81f410:	test   %rax,%rax
  81f413:	je     81f4b8 <<gpui_gpu::renderer::RendererState>::render+0x1498>
  81f419:	mov    0x8(%rsp),%rcx
  81f41e:	mov    0x20(%rcx),%rcx
  81f422:	shl    $0x3,%rax
  81f426:	xor    %edi,%edi
  81f428:	jmp    81f469 <<gpui_gpu::renderer::RendererState>::render+0x1449>
  81f42a:	and    $0x40000000,%edx
  81f430:	mov    0x220(%rsp),%r9
  81f438:	add    %esi,%r9d
  81f43b:	xor    %esi,%esi
  81f43d:	test   %r8d,%r8d
  81f440:	setne  %sil
  81f444:	shl    $0x1d,%esi
  81f447:	or     %r9d,%edx
  81f44a:	or     %esi,%edx
  81f44c:	mov    %r9,0x220(%rsp)
  81f454:	mov    %r9d,(%rcx,%rdi,8)
  81f458:	mov    %edx,%r9d
  81f45b:	mov    %r9d,0x4(%rcx,%rdi,8)
  81f460:	inc    %rdi
  81f463:	add    $0xfffffffffffffff8,%rax
  81f467:	je     81f4a6 <<gpui_gpu::renderer::RendererState>::render+0x1486>
  81f469:	mov    0x8(%rsp),%rdx
  81f46e:	mov    0x58(%rdx),%rsi
  81f472:	cmp    %rsi,%rdi
  81f475:	jae    8203e8 <<gpui_gpu::renderer::RendererState>::render+0x23c8>
  81f47b:	mov    0x4(%rcx,%rdi,8),%edx
  81f47f:	mov    %edx,%esi
  81f481:	and    $0xbfffffff,%esi
  81f487:	mov    0x8(%rsp),%r8
  81f48c:	mov    0x50(%r8),%r8
  81f490:	mov    (%r8,%rdi,4),%r8d
  81f494:	cmp    $0x1,%esi
  81f497:	jne    81f42a <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f499:	mov    $0x80000000,%r9d
  81f49f:	test   %r8d,%r8d
  81f4a2:	jne    81f45b <<gpui_gpu::renderer::RendererState>::render+0x143b>
  81f4a4:	jmp    81f42a <<gpui_gpu::renderer::RendererState>::render+0x140a>
  81f4a6:	mov    0x220(%rsp),%rax
  81f4ae:	mov    %eax,%eax
  81f4b0:	mov    %rax,0x220(%rsp)
  81f4b8:	mov    0x8(%rsp),%rax
  81f4bd:	lea    0x30(%rax),%rdi
  81f4c1:	movq   $0x0,0x40(%rax)
  81f4c9:	mov    %rdi,0xd8(%rsp)
  81f4d1:	mov    0x220(%rsp),%rsi
  81f4d9:	xor    %edx,%edx
  81f4db:	call   823890 <<alloc::vec::Vec<u32>>::resize>
  81f4e0:	mov    0x88(%rsp),%rax
  81f4e8:	mov    %rax,0x360(%rsp)
  81f4f0:	mov    0x100(%rsp),%rax
  81f4f8:	mov    %rax,0x368(%rsp)
  81f500:	movq   $0x0,0x370(%rsp)
  81f50c:	mov    0x108(%rsp),%rax
  81f514:	mov    %rax,0x378(%rsp)
  81f51c:	mov    0x340(%rsp),%rax
  81f524:	mov    %rax,0x380(%rsp)
  81f52c:	mov    0x30(%rsp),%eax
  81f530:	mov    %eax,0x388(%rsp)
  81f537:	lea    0x408(%rsp),%rdi
  81f53f:	lea    0x368(%rsp),%rsi
  81f547:	call   *0x660bb3(%rip)        # e80100 <_DYNAMIC+0x5c8>
  81f54d:	mov    0x408(%rsp),%rax
  81f555:	mov    %rax,0x80(%rsp)
  81f55d:	test   %rax,%rax
  81f560:	je     81fae8 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f566:	mov    0x8(%rsp),%rax
  81f56b:	add    $0x120,%rax
  81f571:	mov    %rax,0x470(%rsp)
  81f579:	mov    0x2b8(%rsp),%rax
  81f581:	mov    %rax,0xb0(%rsp)
  81f589:	jmp    81f5ba <<gpui_gpu::renderer::RendererState>::render+0x159a>
  81f58b:	lea    0x408(%rsp),%rdi
  81f593:	lea    0x368(%rsp),%rsi
  81f59b:	call   *0x660b5f(%rip)        # e80100 <_DYNAMIC+0x5c8>
  81f5a1:	mov    0x408(%rsp),%rax
  81f5a9:	mov    %rax,0x80(%rsp)
  81f5b1:	test   %rax,%rax
  81f5b4:	je     81fae8 <<gpui_gpu::renderer::RendererState>::render+0x1ac8>
  81f5ba:	lea    0x420(%rsp),%rsi
  81f5c2:	movups (%rsi),%xmm0
  81f5c5:	movups 0x10(%rsi),%xmm1
  81f5c9:	movups 0x20(%rsi),%xmm2
  81f5cd:	movaps %xmm2,0x3c0(%rsp)
  81f5d5:	movaps %xmm1,0x3b0(%rsp)
  81f5dd:	movaps %xmm0,0x3a0(%rsp)
  81f5e5:	lea    0x450(%rsp),%rdx
  81f5ed:	movups (%rdx),%xmm0
  81f5f0:	movaps %xmm0,0x320(%rsp)
  81f5f8:	movdqu 0x40(%rsi),%xmm0
  81f5fd:	movdqa %xmm0,0x330(%rsp)
  81f606:	mov    0x410(%rsp),%rax
  81f60e:	mov    %rax,0xe0(%rsp)
  81f616:	mov    0x418(%rsp),%rbx
  81f61e:	mov    0x8(%rsp),%rdi
  81f623:	call   81d3a0 <<gpui_gpu::renderer::RendererState>::correction>
  81f628:	mov    %eax,0x300(%rsp)
  81f62f:	test   %rbx,%rbx
  81f632:	je     81f58b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f638:	mov    %rbx,%rcx
  81f63b:	shl    $0x2,%rcx
  81f63f:	mov    0x300(%rsp),%eax
  81f646:	shl    $0xf,%eax
  81f649:	mov    %eax,0x20(%rsp)
  81f64d:	mov    0xb0(%rsp),%rax
  81f655:	shl    $0x4,%rax
  81f659:	mov    %rax,0x28(%rsp)
  81f65e:	lea    0x138(%rsp),%rbx
  81f666:	lea    0x130(%rsp),%r13
  81f66e:	jmp    81f837 <<gpui_gpu::renderer::RendererState>::render+0x1817>
  81f673:	mov    0x60(%rsp),%r9d
  81f678:	or     0x20(%rsp),%r9d
  81f67d:	mov    %r9d,0x60(%rsp)
  81f682:	mov    0x64(%rsp),%r8d
  81f687:	mov    %edi,0x130(%rsp)
  81f68e:	mov    %r9d,0x134(%rsp)
  81f696:	mov    %r8d,0x138(%rsp)
  81f69e:	mov    %eax,0x13c(%rsp)
  81f6a5:	lea    0x230(%rsp),%rdi
  81f6ad:	mov    %rbx,%r8
  81f6b0:	call   81b630 <<gpui_gpu::renderer::Changes>::replace::<1>>
  81f6b5:	add    $0xfffffffffffffffe,%r13
  81f6b9:	mov    %r13,0xb0(%rsp)
  81f6c1:	mov    %r13d,0x2ec(%rsp)
  81f6c9:	movaps 0x260(%rsp),%xmm0
  81f6d1:	movlps %xmm0,0x170(%rsp)
  81f6d9:	movaps 0x3a0(%rsp),%xmm0
  81f6e1:	movaps 0x3b0(%rsp),%xmm1
  81f6e9:	movaps 0x3c0(%rsp),%xmm2
  81f6f1:	lea    0x178(%rsp),%rax
  81f6f9:	movups %xmm2,0x20(%rax)
  81f6fd:	movups %xmm1,0x10(%rax)
  81f701:	movups %xmm0,(%rax)
  81f704:	movaps 0x320(%rsp),%xmm0
  81f70c:	movups %xmm0,0x30(%rax)
  81f710:	movaps 0x490(%rsp),%xmm0
  81f718:	movups %xmm0,0x40(%rax)
  81f71c:	movaps 0x330(%rsp),%xmm0
  81f724:	movups %xmm0,0x50(%rax)
  81f728:	mov    0x128(%rsp),%eax
  81f72f:	mov    %al,0x130(%rsp)
  81f736:	movzbl 0x30(%rsp),%eax
  81f73b:	mov    %al,0x131(%rsp)
  81f742:	movzwl 0xa8(%rsp),%eax
  81f74a:	mov    %ax,0x132(%rsp)
  81f752:	movaps 0xc0(%rsp),%xmm0
  81f75a:	movss  %xmm0,0x134(%rsp)
  81f763:	mov    0x250(%rsp),%rax
  81f76b:	mov    %rbx,%r13
  81f76e:	lea    0x138(%rsp),%rbx
  81f776:	mov    %rax,0x10(%rbx)
  81f77a:	movaps 0x240(%rsp),%xmm0
  81f782:	movups %xmm0,(%rbx)
  81f785:	mov    0x10(%rsp),%rax
  81f78a:	mov    %rax,0x150(%rsp)
  81f792:	mov    0x40(%rsp),%eax
  81f796:	mov    %eax,0x158(%rsp)
  81f79d:	mov    0x70(%rsp),%eax
  81f7a1:	mov    %eax,0x15c(%rsp)
  81f7a8:	movdqa 0x310(%rsp),%xmm0
  81f7b1:	movdqu %xmm0,0x160(%rsp)
  81f7ba:	mov    0x4c8(%rsp),%rax
  81f7c2:	mov    %rax,0x270(%rsp)
  81f7ca:	mov    0xd8(%rsp),%rax
  81f7d2:	mov    %rax,0x278(%rsp)
  81f7da:	mov    0x4c0(%rsp),%rax
  81f7e2:	mov    %rax,0x280(%rsp)
  81f7ea:	lea    0x360(%rsp),%rax
  81f7f2:	mov    %rax,0x288(%rsp)
  81f7fa:	lea    0x2ec(%rsp),%rax
  81f802:	mov    %rax,0x290(%rsp)
  81f80a:	mov    %r13,%rdi
  81f80d:	mov    0x90(%rsp),%rsi
  81f815:	lea    0x270(%rsp),%rdx
  81f81d:	call   81c4d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81f822:	addq   $0xffffffffffffffe0,0x28(%rsp)
  81f828:	mov    0x68(%rsp),%rcx
  81f82d:	add    $0xfffffffffffffffc,%rcx
  81f831:	je     81f58b <<gpui_gpu::renderer::RendererState>::render+0x156b>
  81f837:	mov    0xe0(%rsp),%rax
  81f83f:	mov    %rcx,0x68(%rsp)
  81f844:	mov    -0x4(%rax,%rcx,1),%edx
  81f848:	mov    %r13,%rdi
  81f84b:	mov    0x80(%rsp),%rsi
  81f853:	call   81c830 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f858:	movzbl 0x130(%rsp),%ecx
  81f860:	movzbl 0x131(%rsp),%eax
  81f868:	mov    %al,0x30(%rsp)
  81f86c:	movzwl 0x132(%rsp),%eax
  81f874:	mov    %ax,0xa8(%rsp)
  81f87c:	movss  0x134(%rsp),%xmm4
  81f885:	mov    0x10(%rbx),%rax
  81f889:	mov    %rax,0x250(%rsp)
  81f891:	movups (%rbx),%xmm0
  81f894:	movaps %xmm0,0x240(%rsp)
  81f89c:	mov    0x150(%rsp),%rax
  81f8a4:	mov    %rax,0x10(%rsp)
  81f8a9:	mov    0x158(%rsp),%eax
  81f8b0:	mov    %eax,0x40(%rsp)
  81f8b4:	mov    0x15c(%rsp),%eax
  81f8bb:	mov    %eax,0x70(%rsp)
  81f8bf:	movups 0x160(%rsp),%xmm0
  81f8c7:	movaps %xmm0,0x310(%rsp)
  81f8cf:	mov    0x160(%rsp),%rax
  81f8d7:	movsd  0x170(%rsp),%xmm5
  81f8e0:	lea    0x178(%rsp),%rdx
  81f8e8:	movups (%rdx),%xmm0
  81f8eb:	movaps %xmm0,0x490(%rsp)
  81f8f3:	decq   0x360(%rsp)
  81f8fb:	cmp    $0x1,%ecx
  81f8fe:	mov    %ecx,0x128(%rsp)
  81f905:	movaps %xmm4,0xc0(%rsp)
  81f90d:	movaps %xmm5,0x260(%rsp)
  81f915:	je     81f97b <<gpui_gpu::renderer::RendererState>::render+0x195b>
  81f917:	cmp    $0x3,%ecx
  81f91a:	jne    81f9f7 <<gpui_gpu::renderer::RendererState>::render+0x19d7>
  81f920:	mov    0x480(%rsp),%rax
  81f928:	mov    (%rax),%rdi
  81f92b:	test   %rdi,%rdi
  81f92e:	je     82039b <<gpui_gpu::renderer::RendererState>::render+0x237b>
  81f934:	movzbl 0x30(%rsp),%edx
  81f939:	mov    0x10(%rsp),%rsi
  81f93e:	call   823580 <<gpui_gpu::renderer::images::Images>::metadata>
  81f943:	mov    %eax,%ecx
  81f945:	shr    $0x20,%rax
  81f949:	mov    %eax,%edx
  81f94b:	or     $0x10,%edx
  81f94e:	xorps  %xmm0,%xmm0
  81f951:	movaps 0xc0(%rsp),%xmm1
  81f959:	ucomiss %xmm0,%xmm1
  81f95c:	cmovne %edx,%eax
  81f95f:	cmovp  %edx,%eax
  81f962:	mov    0x70(%rsp),%edx
  81f966:	shl    $0x10,%edx
  81f969:	or     0x40(%rsp),%edx
  81f96d:	mov    %ecx,0x5c(%rsp)
  81f971:	mov    %eax,0x60(%rsp)
  81f975:	mov    %edx,0x64(%rsp)
  81f979:	jmp    81f9ea <<gpui_gpu::renderer::RendererState>::render+0x19ca>
  81f97b:	movaps %xmm5,%xmm0
  81f97e:	movss  -0x7709ba(%rip),%xmm3        # aefcc <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f986:	mulss  %xmm3,%xmm0
  81f98a:	movaps %xmm4,%xmm1
  81f98d:	minss  %xmm0,%xmm1
  81f991:	movaps %xmm1,%xmm0
  81f994:	cmpunordss %xmm1,%xmm0
  81f999:	movaps %xmm0,%xmm2
  81f99c:	andnps %xmm1,%xmm2
  81f99f:	andps  %xmm4,%xmm0
  81f9a2:	orps   %xmm2,%xmm0
  81f9a5:	movaps %xmm5,%xmm1
  81f9a8:	shufps $0x55,%xmm5,%xmm1
  81f9ac:	mulss  %xmm3,%xmm1
  81f9b0:	movaps %xmm0,%xmm2
  81f9b3:	minss  %xmm1,%xmm2
  81f9b7:	movaps %xmm2,%xmm1
  81f9ba:	cmpunordss %xmm2,%xmm1
  81f9bf:	andps  %xmm1,%xmm0
  81f9c2:	andnps %xmm2,%xmm1
  81f9c5:	orps   %xmm0,%xmm1
  81f9c8:	movd   %xmm1,%eax
  81f9cc:	and    $0xff800000,%eax
  81f9d1:	mov    $0x7f000000,%ecx
  81f9d6:	sub    %eax,%ecx
  81f9d8:	movl   $0x40000000,0x5c(%rsp)
  81f9e0:	movss  %xmm1,0x60(%rsp)
  81f9e6:	mov    %ecx,0x64(%rsp)
  81f9ea:	lea    0x130(%rsp),%rbx
  81f9f2:	jmp    81fa91 <<gpui_gpu::renderer::RendererState>::render+0x1a71>
  81f9f7:	cmp    $0x2,%cl
  81f9fa:	jne    81fa49 <<gpui_gpu::renderer::RendererState>::render+0x1a29>
  81f9fc:	mov    0x250(%rsp),%rcx
  81fa04:	mov    %rcx,0x140(%rsp)
  81fa0c:	movaps 0x240(%rsp),%xmm0
  81fa14:	movaps %xmm0,0x130(%rsp)
  81fa1c:	mov    0x10(%rsp),%rcx
  81fa21:	mov    %rcx,0x148(%rsp)
  81fa29:	mov    0x40(%rsp),%ecx
  81fa2d:	mov    %ecx,0x150(%rsp)
  81fa34:	mov    0x70(%rsp),%ecx
  81fa38:	mov    %ecx,0x154(%rsp)
  81fa3f:	mov    %rax,0x158(%rsp)
  81fa47:	jmp    81fa55 <<gpui_gpu::renderer::RendererState>::render+0x1a35>
  81fa49:	movq   $0x0,0x130(%rsp)
  81fa55:	movl   $0x0,0x278(%rsp)
  81fa60:	movq   $0x0,0x270(%rsp)
  81fa6c:	lea    0x5c(%rsp),%rdi
  81fa71:	lea    0x130(%rsp),%rbx
  81fa79:	mov    %rbx,%rsi
  81fa7c:	lea    0x270(%rsp),%rdx
  81fa84:	mov    0x470(%rsp),%rcx
  81fa8c:	call   81b4e0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fa91:	mov    0xb0(%rsp),%r13
  81fa99:	lea    -0x1(%r13),%rcx
  81fa9d:	mov    0x8(%rsp),%rax
  81faa2:	mov    0x10(%rax),%rdx
  81faa6:	cmp    %rdx,%rcx
  81faa9:	jae    8203bc <<gpui_gpu::renderer::RendererState>::render+0x239c>
  81faaf:	mov    0x8(%rax),%rsi
  81fab3:	mov    0x28(%rsp),%rax
  81fab8:	mov    -0x4(%rsi,%rax,1),%eax
  81fabc:	mov    0x5c(%rsp),%edi
  81fac0:	cmp    $0x40000000,%edi
  81fac6:	jne    81f673 <<gpui_gpu::renderer::RendererState>::render+0x1653>
  81facc:	mov    0x64(%rsp),%r8d
  81fad1:	or     0x300(%rsp),%r8d
  81fad9:	mov    %r8d,0x64(%rsp)
  81fade:	mov    0x60(%rsp),%r9d
  81fae3:	jmp    81f687 <<gpui_gpu::renderer::RendererState>::render+0x1667>
  81fae8:	mov    0x8(%rsp),%rax
  81faed:	mov    0x28(%rax),%rdi
  81faf1:	xor    %ebx,%ebx
  81faf3:	test   %rdi,%rdi
  81faf6:	je     81fc05 <<gpui_gpu::renderer::RendererState>::render+0x1be5>
  81fafc:	mov    0x8(%rsp),%rax
  81fb01:	mov    0x20(%rax),%r8
  81fb05:	shl    $0x3,%rdi
  81fb09:	cmpl   $0x0,0x90(%rsp)
  81fb11:	je     81fe00 <<gpui_gpu::renderer::RendererState>::render+0x1de0>
  81fb17:	movq   $0x0,0x40(%rsp)
  81fb20:	movq   $0x0,0x70(%rsp)
  81fb29:	movq   $0x0,0x10(%rsp)
  81fb32:	xor    %r10d,%r10d
  81fb35:	xor    %ecx,%ecx
  81fb37:	jmp    81fb5f <<gpui_gpu::renderer::RendererState>::render+0x1b3f>
  81fb39:	incq   0x10(%rsp)
  81fb3e:	inc    %r10
  81fb41:	cmp    0x90(%rsp),%r10
  81fb49:	mov    $0x0,%eax
  81fb4e:	cmove  %rax,%r10
  81fb52:	inc    %rcx
  81fb55:	add    $0xfffffffffffffff8,%rdi
  81fb59:	je     81fc20 <<gpui_gpu::renderer::RendererState>::render+0x1c00>
  81fb5f:	mov    0x4(%r8,%rcx,8),%r11d
  81fb64:	mov    $0x80000000,%eax
  81fb69:	cmp    %rax,%r11
  81fb6c:	je     81fb39 <<gpui_gpu::renderer::RendererState>::render+0x1b19>
  81fb6e:	mov    %r11d,%esi
  81fb71:	and    $0x1fffffff,%esi
  81fb77:	sub    (%r8,%rcx,8),%esi
  81fb7b:	je     81fb3e <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fb7d:	mov    %rcx,%rax
  81fb80:	shr    $0x20,%rax
  81fb84:	je     81fb98 <<gpui_gpu::renderer::RendererState>::render+0x1b78>
  81fb86:	mov    %rcx,%rax
  81fb89:	xor    %edx,%edx
  81fb8b:	divq   0x90(%rsp)
  81fb93:	mov    %r10,%rdx
  81fb96:	jmp    81fba3 <<gpui_gpu::renderer::RendererState>::render+0x1b83>
  81fb98:	mov    %ecx,%eax
  81fb9a:	xor    %edx,%edx
  81fb9c:	divl   0x90(%rsp)
  81fba3:	shl    $0x4,%edx
  81fba6:	shl    $0x4,%eax
  81fba9:	lea    0x10(%rdx),%r13d
  81fbad:	cmp    %r13d,%r14d
  81fbb0:	cmovb  %r14d,%r13d
  81fbb4:	lea    0x10(%rax),%r9d
  81fbb8:	cmp    %r9d,%r15d
  81fbbb:	cmovb  %r15d,%r9d
  81fbbf:	sub    %edx,%r13d
  81fbc2:	sub    %eax,%r9d
  81fbc5:	imul   %r13d,%r9d
  81fbc9:	mov    %r9,%rax
  81fbcc:	shl    $0x4,%rax
  81fbd0:	test   $0x40000000,%r11d
  81fbd7:	cmovne %r9,%rax
  81fbdb:	shr    $0x1d,%r11d
  81fbdf:	and    $0x1,%r11d
  81fbe3:	add    %rax,0x70(%rsp)
  81fbe8:	imul   %r11,%r9
  81fbec:	sub    %r11,%rsi
  81fbef:	imul   %rax,%rsi
  81fbf3:	add    0x40(%rsp),%r9
  81fbf8:	add    %rsi,%r9
  81fbfb:	mov    %r9,0x40(%rsp)
  81fc00:	jmp    81fb3e <<gpui_gpu::renderer::RendererState>::render+0x1b1e>
  81fc05:	movq   $0x0,0x10(%rsp)
  81fc0e:	movq   $0x0,0x70(%rsp)
  81fc17:	movq   $0x0,0x40(%rsp)
  81fc20:	test   $0x1,%bpl
  81fc24:	je     81fc71 <<gpui_gpu::renderer::RendererState>::render+0x1c51>
  81fc26:	movd   0x2e8(%rsp),%xmm0
  81fc2f:	movd   %xmm0,%eax
  81fc33:	test   %eax,%eax
  81fc35:	setns  %cl
  81fc38:	mov    %eax,%edx
  81fc3a:	and    $0x7fffffff,%edx
  81fc40:	add    $0xff800000,%edx
  81fc46:	cmp    $0x7f000000,%edx
  81fc4c:	setb   %dl
  81fc4f:	and    %cl,%dl
  81fc51:	dec    %eax
  81fc53:	cmp    $0x7fffff,%eax
  81fc58:	setb   %al
  81fc5b:	or     %dl,%al
  81fc5d:	mov    $0x2,%ebx
  81fc62:	movd   %xmm0,0xf4(%rsp)
  81fc6b:	je     81fdf6 <<gpui_gpu::renderer::RendererState>::render+0x1dd6>
  81fc71:	mov    0x120(%rsp),%rax
  81fc79:	add    $0x18,%rax
  81fc7d:	xor    %ecx,%ecx
  81fc7f:	cmpl   $0x28,0x2e4(%rsp)
  81fc87:	sete   %cl
  81fc8a:	and    $0x1,%r12d
  81fc8e:	lea    (%r12,%rcx,4),%ecx
  81fc92:	or     %ebx,%ecx
  81fc94:	movups (%rax),%xmm0
  81fc97:	movups %xmm0,0x418(%rsp)
  81fc9f:	mov    %r14d,0x408(%rsp)
  81fca7:	mov    %r15d,0x40c(%rsp)
  81fcaf:	mov    0x90(%rsp),%rax
  81fcb7:	mov    %eax,0x410(%rsp)
  81fcbe:	mov    %ecx,0x414(%rsp)
  81fcc5:	movss  0xf4(%rsp),%xmm0
  81fcce:	movss  %xmm0,0x428(%rsp)
  81fcd7:	mov    0x110(%rsp),%rax
  81fcdf:	mov    %eax,0x42c(%rsp)
  81fce6:	movq   $0x0,0x430(%rsp)
  81fcf2:	mov    0x8(%rsp),%rax
  81fcf7:	lea    0x230(%rax),%rsi
  81fcfe:	lea    0x408(%rsp),%rcx
  81fd06:	mov    $0x30,%r8d
  81fd0c:	mov    0x2f0(%rsp),%rdi
  81fd14:	mov    %rsi,0x30(%rsp)
  81fd19:	xor    %edx,%edx
  81fd1b:	call   *0x6603e7(%rip)        # e80108 <_DYNAMIC+0x5d0>
  81fd21:	mov    0x2b8(%rsp),%rbx
  81fd29:	shl    $0x4,%rbx
  81fd2d:	mov    0x98(%rsp),%rdi
  81fd35:	mov    0xa0(%rsp),%rsi
  81fd3d:	mov    %rbx,%rdx
  81fd40:	call   81cb80 <<gpui_gpu::renderer::Buffer>::reserve>
  81fd45:	cmpq   $0x0,0x38(%rsp)
  81fd4b:	je     81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd4d:	mov    0x2b8(%rsp),%rcx
  81fd55:	cmp    %rcx,0x348(%rsp)
  81fd5d:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd5f:	test   %al,%al
  81fd61:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd63:	testb  $0x1,0x390(%rsp)
  81fd6b:	jne    81fdc3 <<gpui_gpu::renderer::RendererState>::render+0x1da3>
  81fd6d:	mov    0x2d8(%rsp),%rax
  81fd75:	mov    0x230(%rsp),%rbx
  81fd7d:	mov    0x238(%rsp),%rsi
  81fd85:	cmp    %rbx,%rax
  81fd88:	jne    81fe4c <<gpui_gpu::renderer::RendererState>::render+0x1e2c>
  81fd8e:	mov    %rsi,0x2d8(%rsp)
  81fd96:	movq   $0xffffffffffffffff,0x230(%rsp)
  81fda2:	movq   $0x0,0x238(%rsp)
  81fdae:	mov    $0xffffffffffffffff,%rbx
  81fdb5:	movq   $0x0,0x38(%rsp)
  81fdbe:	jmp    81fe54 <<gpui_gpu::renderer::RendererState>::render+0x1e34>
  81fdc3:	mov    0x8(%rsp),%rax
  81fdc8:	mov    0x8(%rax),%rcx
  81fdcc:	mov    0x10(%rax),%r8
  81fdd0:	shl    $0x4,%r8
  81fdd4:	mov    0x98(%rsp),%rdi
  81fddc:	mov    0xa0(%rsp),%rsi
  81fde4:	mov    0x2f0(%rsp),%rdx
  81fdec:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81fdf1:	jmp    81feb2 <<gpui_gpu::renderer::RendererState>::render+0x1e92>
  81fdf6:	mov    0x50(%rsp),%rdi
  81fdfb:	jmp    81e1c1 <<gpui_gpu::renderer::RendererState>::render+0x1a1>
  81fe00:	movq   $0x0,0x70(%rsp)
  81fe09:	xor    %eax,%eax
  81fe0b:	movq   $0x0,0x10(%rsp)
  81fe14:	jmp    81fe28 <<gpui_gpu::renderer::RendererState>::render+0x1e08>
  81fe16:	incq   0x10(%rsp)
  81fe1b:	add    $0x8,%rax
  81fe1f:	cmp    %rax,%rdi
  81fe22:	je     81fc17 <<gpui_gpu::renderer::RendererState>::render+0x1bf7>
  81fe28:	mov    0x4(%r8,%rax,1),%ecx
  81fe2d:	mov    %ecx,%edx
  81fe2f:	neg    %edx
  81fe31:	jo     81fe16 <<gpui_gpu::renderer::RendererState>::render+0x1df6>
  81fe33:	and    $0x1fffffff,%ecx
  81fe39:	cmp    %ecx,(%r8,%rax,1)
  81fe3d:	je     81fe1b <<gpui_gpu::renderer::RendererState>::render+0x1dfb>
  81fe3f:	lea    0x60e98a(%rip),%rdi        # e2e7d0 <anon.36d49f465d299f05a84fba3771e6457e.33.llvm.4447969268566763096+0x10>
  81fe46:	call   *0x6602c4(%rip)        # e80110 <_DYNAMIC+0x5d8>
  81fe4c:	mov    %rsi,0x38(%rsp)
  81fe51:	mov    %rax,%rsi
  81fe54:	mov    0x8(%rsp),%r13
  81fe59:	mov    0x8(%r13),%rdx
  81fe5d:	mov    0x10(%r13),%rcx
  81fe61:	mov    0x2d0(%rsp),%rdi
  81fe69:	mov    0x98(%rsp),%rbp
  81fe71:	mov    %rbp,%r8
  81fe74:	mov    0x2f0(%rsp),%r12
  81fe7c:	mov    %r12,%r9
  81fe7f:	call   81cad0 <<gpui_gpu::renderer::Changes>::upload>
  81fe84:	mov    %rax,0xc0(%rsp)
  81fe8c:	mov    0x8(%r13),%rdx
  81fe90:	mov    0x10(%r13),%rcx
  81fe94:	mov    %rbx,%rdi
  81fe97:	mov    0x38(%rsp),%rsi
  81fe9c:	mov    %rbp,%r8
  81fe9f:	mov    %r12,%r9
  81fea2:	call   81cad0 <<gpui_gpu::renderer::Changes>::upload>
  81fea7:	mov    %rax,%rbx
  81feaa:	add    0xc0(%rsp),%rbx
  81feb2:	mov    0xa0(%rsp),%r13
  81feba:	lea    0x18(%r13),%rax
  81febe:	mov    %rax,0x38(%rsp)
  81fec3:	mov    0x8(%rsp),%rbp
  81fec8:	lea    0x280(%rbp),%rdi
  81fecf:	mov    0x20(%rbp),%rcx
  81fed3:	mov    0x28(%rbp),%r8
  81fed7:	shl    $0x3,%r8
  81fedb:	mov    %rdi,0xc0(%rsp)
  81fee3:	mov    %r13,%rsi
  81fee6:	mov    0x2f0(%rsp),%r12
  81feee:	mov    %r12,%rdx
  81fef1:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81fef6:	lea    0x2a8(%rbp),%rdi
  81fefd:	mov    0x38(%rbp),%rcx
  81ff01:	mov    0x40(%rbp),%r8
  81ff05:	shl    $0x2,%r8
  81ff09:	mov    %rdi,0xb0(%rsp)
  81ff11:	mov    %r13,%rsi
  81ff14:	mov    %r12,%rdx
  81ff17:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81ff1c:	lea    0x2d0(%rbp),%rdi
  81ff23:	mov    0x68(%rbp),%rcx
  81ff27:	mov    0x70(%rbp),%r8
  81ff2b:	shl    $0x5,%r8
  81ff2f:	mov    %rdi,0x28(%rsp)
  81ff34:	mov    %r13,%rsi
  81ff37:	mov    %r12,%rdx
  81ff3a:	call   81cb30 <<gpui_gpu::renderer::Buffer>::write>
  81ff3f:	cmpq   $0x0,0x328(%rbp)
  81ff47:	je     81ff4d <<gpui_gpu::renderer::RendererState>::render+0x1f2d>
  81ff49:	xor    %eax,%eax
  81ff4b:	jmp    81ff62 <<gpui_gpu::renderer::RendererState>::render+0x1f42>
  81ff4d:	mov    0x8(%rsp),%rax
  81ff52:	mov    0x10(%rax),%rax
  81ff56:	cmp    $0x1,%rax
  81ff5a:	adc    $0x0,%rax
  81ff5e:	shl    $0x4,%rax
  81ff62:	mov    0x8(%rsp),%rdi
  81ff67:	mov    0x28(%rdi),%rsi
  81ff6b:	mov    0x40(%rdi),%rcx
  81ff6f:	cmp    $0x1,%rsi
  81ff73:	adc    $0x0,%rsi
  81ff77:	shl    $0x3,%rsi
  81ff7b:	cmp    $0x1,%rcx
  81ff7f:	adc    $0x0,%rcx
  81ff83:	mov    0x70(%rdi),%rdx
  81ff87:	cmp    $0x1,%rdx
  81ff8b:	adc    $0x0,%rdx
  81ff8f:	add    $0xc8,%rdi
  81ff96:	shl    $0x2,%rcx
  81ff9a:	shl    $0x5,%rdx
  81ff9e:	movq   $0x0,0x130(%rsp)
  81ffaa:	mov    0x30(%rsp),%r8
  81ffaf:	mov    %r8,0x138(%rsp)
  81ffb7:	movq   $0x0,0x158(%rsp)
  81ffc3:	xorpd  %xmm0,%xmm0
  81ffc7:	movupd %xmm0,0x140(%rsp)
  81ffd0:	movl   $0x0,0x150(%rsp)
  81ffdb:	mov    0x98(%rsp),%r8
  81ffe3:	mov    %r8,0x160(%rsp)
  81ffeb:	movq   $0x0,0x168(%rsp)
  81fff7:	mov    %rax,0x170(%rsp)
  81ffff:	movl   $0x1,0x178(%rsp)
  82000a:	movq   $0x0,0x180(%rsp)
  820016:	mov    0xc0(%rsp),%rax
  82001e:	mov    %rax,0x188(%rsp)
  820026:	movq   $0x0,0x190(%rsp)
  820032:	mov    %rsi,0x198(%rsp)
  82003a:	movl   $0x2,0x1a0(%rsp)
  820045:	movq   $0x0,0x1a8(%rsp)
  820051:	mov    0xb0(%rsp),%rax
  820059:	mov    %rax,0x1b0(%rsp)
  820061:	movq   $0x0,0x1b8(%rsp)
  82006d:	mov    %rcx,0x1c0(%rsp)
  820075:	movl   $0x3,0x1c8(%rsp)
  820080:	movq   $0x4,0x1d0(%rsp)
  82008c:	mov    %rdi,0x1d8(%rsp)
  820094:	movl   $0x4,0x1f0(%rsp)
  82009f:	movq   $0x0,0x1f8(%rsp)
  8200ab:	mov    0x28(%rsp),%rax
  8200b0:	mov    %rax,0x200(%rsp)
  8200b8:	movq   $0x0,0x208(%rsp)
  8200c4:	mov    %rdx,0x210(%rsp)
  8200cc:	movl   $0x5,0x218(%rsp)
  8200d7:	lea    -0x74b546(%rip),%rax        # d4b98 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  8200de:	mov    %rax,0x3b8(%rsp)
  8200e6:	movq   $0xa,0x3c0(%rsp)
  8200f2:	mov    0x38(%rsp),%rax
  8200f7:	mov    %rax,0x3a0(%rsp)
  8200ff:	lea    0x130(%rsp),%rax
  820107:	mov    %rax,0x3a8(%rsp)
  82010f:	movq   $0x6,0x3b0(%rsp)
  82011b:	lea    0x3a0(%rsp),%rsi
  820123:	mov    0xa0(%rsp),%r13
  82012b:	mov    %r13,%rdi
  82012e:	call   *0x65ffe4(%rip)        # e80118 <_DYNAMIC+0x5e0>
  820134:	mov    %rax,%rbp
  820137:	mov    %rax,0x270(%rsp)
  82013f:	lea    0x270(%rsp),%rdx
  820147:	mov    %r13,%rdi
  82014a:	mov    0x4b8(%rsp),%rsi
  820152:	call   81d1c0 <<gpui_gpu::renderer::GpuContext>::submit>
  820157:	mov    %rax,0x38(%rsp)
  82015c:	xor    %r13d,%r13d
  82015f:	mov    0x350(%rsp),%rax
  820167:	cmp    %rax,0x358(%rsp)
  82016f:	setne  %r13b
  820173:	shl    $0x1f,%r13d
  820177:	or     %r14d,%r13d
  82017a:	shl    $0x20,%r15
  82017e:	or     %r15,%r13
  820181:	mov    0xe8(%rsp),%rax
  820189:	mov    (%rax),%rax
  82018c:	test   %rax,%rax
  82018f:	je     8201a5 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820191:	lock decq (%rax)
  820195:	jne    8201a5 <<gpui_gpu::renderer::RendererState>::render+0x2185>
  820197:	mov    0xe8(%rsp),%rdi
  82019f:	call   *0x65feab(%rip)        # e80050 <_DYNAMIC+0x518>
  8201a5:	mov    0x8(%rsp),%rax
  8201aa:	mov    %rbp,0x330(%rax)
  8201b1:	mov    %r13,0x338(%rax)
  8201b8:	mov    0x28(%rax),%rsi
  8201bc:	mov    0x70(%rax),%rcx
  8201c0:	mov    %rcx,0xe8(%rsp)
  8201c8:	mov    0x278(%rax),%rdx
  8201cf:	mov    0x220(%rsp),%r8
  8201d7:	lea    (%rbx,%r8,4),%rdi
  8201db:	lea    (%rdi,%rsi,8),%rsi
  8201df:	mov    %rcx,%rdi
  8201e2:	shl    $0x5,%rdi
  8201e6:	lea    (%rdi,%rsi,1),%rcx
  8201ea:	add    $0x30,%rcx
  8201ee:	mov    %rcx,0x30(%rsp)
  8201f3:	mov    0x150(%rax),%esi
  8201f9:	imul   %rsi,%rsi
  8201fd:	add    0x250(%rax),%rdx
  820204:	add    0x2a0(%rax),%rdx
  82020b:	add    0x2c8(%rax),%rdx
  820212:	add    0x2f0(%rax),%rdx
  820219:	mov    0x308(%rax),%rdi
  820220:	add    0x310(%rax),%rdi
  820227:	mov    0x118(%rsp),%r11
  82022f:	mov    %r11,%rcx
  820232:	sub    %r8,%rcx
  820235:	mov    0x88(%rsp),%rbp
  82023d:	mov    %rbp,%r9
  820240:	mov    0x2b0(%rsp),%r13
  820248:	sub    %r13,%r9
  82024b:	mov    0x10(%rax),%r10
  82024f:	shl    $0x4,%r10
  820253:	mov    0x160(%rax),%rbx
  82025a:	inc    %rbx
  82025d:	mov    $0xffffffffffffffff,%r14
  820264:	cmovne %rbx,%r14
  820268:	mov    (%rax),%rbx
  82026b:	shl    $0x4,%rbx
  82026f:	mov    0x48(%rax),%r15
  820273:	add    0x30(%rax),%r15
  820277:	mov    0x18(%rax),%r12
  82027b:	lea    (%rbx,%r12,8),%rbx
  82027f:	lea    (%rbx,%r15,4),%rbx
  820283:	mov    0x60(%rax),%r15
  820287:	shl    $0x5,%r15
  82028b:	add    %rbx,%r15
  82028e:	mov    0x138(%rax),%rbx
  820295:	mov    0x130(%rax),%r12
  82029c:	mov    %r14,0x160(%rax)
  8202a3:	mov    %rbp,0x168(%rax)
  8202aa:	lea    (%r11,%r11,1),%r14
  8202ae:	mov    %r14,0x170(%rax)
  8202b5:	movq   $0x1,0x178(%rax)
  8202c0:	mov    %rbp,0x180(%rax)
  8202c7:	mov    %r8,0x188(%rax)
  8202ce:	mov    %r11,0x190(%rax)
  8202d5:	mov    %rcx,0x198(%rax)
  8202dc:	mov    0x10(%rsp),%rcx
  8202e1:	mov    %rcx,0x1a0(%rax)
  8202e8:	mov    0x70(%rsp),%rcx
  8202ed:	mov    %rcx,0x1a8(%rax)
  8202f4:	mov    0x40(%rsp),%rcx
  8202f9:	mov    %rcx,0x1b0(%rax)
  820300:	mov    0x30(%rsp),%rcx
  820305:	mov    %rcx,0x1b8(%rax)
  82030c:	mov    %r10,0x1c0(%rax)
  820313:	mov    0x2a8(%rsp),%r8
  82031b:	mov    %r8,0x1c8(%rax)
  820322:	mov    %r13,0x1d0(%rax)
  820329:	mov    %r9,0x1d8(%rax)
  820330:	mov    0x2c8(%rsp),%rcx
  820338:	mov    %rcx,0x1e0(%rax)
  82033f:	mov    %rdx,0x1e8(%rax)
  820346:	mov    %rsi,0x1f0(%rax)
  82034d:	add    %rbx,%r12
  820350:	mov    %rbx,0x1f8(%rax)
  820357:	mov    %r12,0x200(%rax)
  82035e:	mov    %r15,0x208(%rax)
  820365:	mov    0xe8(%rsp),%rcx
  82036d:	mov    %rcx,0x210(%rax)
  820374:	mov    %rdi,0x218(%rax)
  82037b:	movb   $0x0,0x220(%rax)
  820382:	mov    0x50(%rsp),%rdi
  820387:	mov    0x38(%rsp),%rax
  82038c:	mov    %rax,0x8(%rdi)
  820390:	movl   $0xffffffff,(%rdi)
  820396:	jmp    81e1cf <<gpui_gpu::renderer::RendererState>::render+0x1af>
  82039b:	lea    0x60e21e(%rip),%rdi        # e2e5c0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x18>
  8203a2:	call   *0x65fd78(%rip)        # e80120 <_DYNAMIC+0x5e8>
  8203a8:	lea    0x60e271(%rip),%rcx        # e2e620 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x78>
  8203af:	xor    %edi,%edi
  8203b1:	mov    0x20(%rsp),%rsi
  8203b6:	call   *0x65fcc4(%rip)        # e80080 <_DYNAMIC+0x548>
  8203bc:	lea    0x60e215(%rip),%rax        # e2e5d8 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x30>
  8203c3:	mov    %rcx,%rdi
  8203c6:	mov    %rdx,%rsi
  8203c9:	mov    %rax,%rdx
  8203cc:	call   *0x65fc5e(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8203d2:	lea    0x60e22f(%rip),%rax        # e2e608 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x60>
  8203d9:	mov    %rcx,%rdi
  8203dc:	mov    %rdx,%rsi
  8203df:	mov    %rax,%rdx
  8203e2:	call   *0x65fc48(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8203e8:	lea    0x60e201(%rip),%rdx        # e2e5f0 <anon.36d49f465d299f05a84fba3771e6457e.1.llvm.4447969268566763096+0x48>
  8203ef:	call   *0x65fc3b(%rip)        # e80030 <_DYNAMIC+0x4f8>
  8203f5:	mov    %rax,%r14
  8203f8:	mov    0x8(%rsp),%rax
  8203fd:	mov    %rbp,0x330(%rax)
  820404:	mov    %r13,0x338(%rax)
  82040b:	mov    %r14,%rdi
  82040e:	call   e2c890 <_Unwind_Resume@plt>
  820413:	mov    %rax,%r14
  820416:	lock decq 0x0(%rbp)
  82041b:	jne    820445 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  82041d:	lea    0x270(%rsp),%rdi
  820425:	call   *0x65fc25(%rip)        # e80050 <_DYNAMIC+0x518>
  82042b:	jmp    820445 <<gpui_gpu::renderer::RendererState>::render+0x2425>
  82042d:	call   *0x65f955(%rip)        # e7fd88 <_DYNAMIC+0x250>
  820433:	mov    %rax,%r14
  820436:	mov    0xe8(%rsp),%rax
  82043e:	movq   $0x0,(%rax)
  820445:	mov    %r14,%rdi
  820448:	call   e2c890 <_Unwind_Resume@plt>
