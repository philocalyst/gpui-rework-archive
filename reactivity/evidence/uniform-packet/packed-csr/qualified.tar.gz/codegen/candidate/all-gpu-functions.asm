
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008166f0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  8166f0:	push   %rbx
  8166f1:	test   %rdi,%rdi
  8166f4:	je     816757 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  8166f6:	mov    %rdi,%rbx
  8166f9:	mov    (%rdi),%rsi
  8166fc:	test   %rsi,%rsi
  8166ff:	je     816714 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816701:	mov    0x8(%rbx),%rdi
  816705:	shl    $0x3,%rsi
  816709:	mov    $0x8,%edx
  81670e:	call   *0x6691fc(%rip)        # e7f910 <_DYNAMIC+0x248>
  816714:	mov    0x20(%rbx),%rsi
  816718:	test   %rsi,%rsi
  81671b:	je     816743 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81671d:	mov    %rsi,%rax
  816720:	shl    $0x4,%rax
  816724:	add    %rax,%rsi
  816727:	add    $0x21,%rsi
  81672b:	je     816743 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81672d:	mov    0x18(%rbx),%rdi
  816731:	sub    %rax,%rdi
  816734:	add    $0xfffffffffffffff0,%rdi
  816738:	mov    $0x10,%edx
  81673d:	call   *0x6691cd(%rip)        # e7f910 <_DYNAMIC+0x248>
  816743:	mov    $0x80,%esi
  816748:	mov    $0x8,%edx
  81674d:	mov    %rbx,%rdi
  816750:	pop    %rbx
  816751:	jmp    *0x6691b9(%rip)        # e7f910 <_DYNAMIC+0x248>
  816757:	pop    %rbx
  816758:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816d60 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816d60:	push   %rbx
  816d61:	cmpb   $0x3,0x19c(%rdi)
  816d68:	jne    816d97 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816d6a:	movzbl 0x28(%rdi),%eax
  816d6e:	cmp    $0x4,%eax
  816d71:	je     816d85 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816d73:	cmp    $0x3,%eax
  816d76:	jne    816d97 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816d78:	add    $0x168,%rdi
  816d7f:	pop    %rbx
  816d80:	jmp    816cd0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816d85:	mov    %rdi,%rbx
  816d88:	add    $0x30,%rdi
  816d8c:	call   816db0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816d91:	movw   $0x0,0x29(%rbx)
  816d97:	pop    %rbx
  816d98:	ret
  816d99:	movw   $0x0,0x29(%rbx)
  816d9f:	mov    %rax,%rdi
  816da2:	call   e2c4b0 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816db0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816db0:	push   %r15
  816db2:	push   %r14
  816db4:	push   %r12
  816db6:	push   %rbx
  816db7:	push   %rax
  816db8:	mov    %rdi,%rbx
  816dbb:	movzbl 0x9e(%rdi),%eax
  816dc2:	test   %eax,%eax
  816dc4:	je     816e8b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816dca:	cmp    $0x3,%eax
  816dcd:	jne    816ec1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816dd3:	mov    0x20(%rbx),%r15
  816dd7:	mov    0x28(%rbx),%r12
  816ddb:	mov    (%r12),%rax
  816ddf:	test   %rax,%rax
  816de2:	je     816de9 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816de4:	mov    %r15,%rdi
  816de7:	call   *%rax
  816de9:	mov    0x8(%r12),%rsi
  816dee:	test   %rsi,%rsi
  816df1:	je     816e01 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816df3:	mov    0x10(%r12),%rdx
  816df8:	mov    %r15,%rdi
  816dfb:	call   *0x668b0f(%rip)        # e7f910 <_DYNAMIC+0x248>
  816e01:	mov    0x68(%rbx),%rax
  816e05:	lock decq (%rax)
  816e09:	jne    816e15 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816e0b:	lea    0x68(%rbx),%rdi
  816e0f:	call   *0x668d1b(%rip)        # e7fb30 <_DYNAMIC+0x468>
  816e15:	movb   $0x0,0x98(%rbx)
  816e1c:	mov    0x60(%rbx),%rax
  816e20:	lock decq (%rax)
  816e24:	jne    816e2f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816e26:	lea    0x60(%rbx),%rdi
  816e2a:	call   812f30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816e2f:	movw   $0x0,0x99(%rbx)
  816e38:	mov    0x40(%rbx),%rax
  816e3c:	lock decq (%rax)
  816e40:	jne    816e4c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816e42:	lea    0x40(%rbx),%rdi
  816e46:	call   *0x668cec(%rip)        # e7fb38 <_DYNAMIC+0x470>
  816e4c:	movb   $0x0,0x9b(%rbx)
  816e53:	mov    0x38(%rbx),%rax
  816e57:	lock decq (%rax)
  816e5b:	jne    816e67 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816e5d:	lea    0x38(%rbx),%rdi
  816e61:	call   *0x668cd9(%rip)        # e7fb40 <_DYNAMIC+0x478>
  816e67:	movb   $0x0,0x9c(%rbx)
  816e6e:	mov    0x30(%rbx),%rax
  816e72:	lock decq (%rax)
  816e76:	jne    816e82 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816e78:	lea    0x30(%rbx),%rdi
  816e7c:	call   *0x668cc6(%rip)        # e7fb48 <_DYNAMIC+0x480>
  816e82:	movb   $0x0,0x9d(%rbx)
  816e89:	jmp    816ec1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816e8b:	mov    0x70(%rbx),%rax
  816e8f:	lock decq (%rax)
  816e93:	jne    816e9f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816e95:	lea    0x70(%rbx),%rdi
  816e99:	call   *0x668ca9(%rip)        # e7fb48 <_DYNAMIC+0x480>
  816e9f:	mov    0x78(%rbx),%rax
  816ea3:	lock decq (%rax)
  816ea7:	jne    816ec1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816ea9:	add    $0x78,%rbx
  816ead:	mov    %rbx,%rdi
  816eb0:	add    $0x8,%rsp
  816eb4:	pop    %rbx
  816eb5:	pop    %r12
  816eb7:	pop    %r14
  816eb9:	pop    %r15
  816ebb:	jmp    *0x668c7f(%rip)        # e7fb40 <_DYNAMIC+0x478>
  816ec1:	add    $0x8,%rsp
  816ec5:	pop    %rbx
  816ec6:	pop    %r12
  816ec8:	pop    %r14
  816eca:	pop    %r15
  816ecc:	ret
  816ecd:	mov    %rax,%r14
  816ed0:	movb   $0x0,0x9d(%rbx)
  816ed7:	mov    %r14,%rdi
  816eda:	call   e2c4b0 <_Unwind_Resume@plt>
  816edf:	mov    %rax,%r14
  816ee2:	jmp    816f9c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816ee7:	mov    %rax,%r14
  816eea:	jmp    816f81 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816eef:	mov    %rax,%r14
  816ef2:	jmp    816f64 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816ef4:	mov    %rax,%r14
  816ef7:	jmp    816f4a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816ef9:	mov    %rax,%r14
  816efc:	mov    0x78(%rbx),%rax
  816f00:	lock decq (%rax)
  816f04:	jne    816f13 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816f06:	add    $0x78,%rbx
  816f0a:	mov    %rbx,%rdi
  816f0d:	call   *0x668c2d(%rip)        # e7fb40 <_DYNAMIC+0x478>
  816f13:	mov    %r14,%rdi
  816f16:	call   e2c4b0 <_Unwind_Resume@plt>
  816f1b:	mov    %rax,%r14
  816f1e:	mov    0x8(%r12),%rsi
  816f23:	test   %rsi,%rsi
  816f26:	je     816f36 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816f28:	mov    0x10(%r12),%rdx
  816f2d:	mov    %r15,%rdi
  816f30:	call   *0x6689da(%rip)        # e7f910 <_DYNAMIC+0x248>
  816f36:	mov    0x68(%rbx),%rax
  816f3a:	lock decq (%rax)
  816f3e:	jne    816f4a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816f40:	lea    0x68(%rbx),%rdi
  816f44:	call   *0x668be6(%rip)        # e7fb30 <_DYNAMIC+0x468>
  816f4a:	movb   $0x0,0x98(%rbx)
  816f51:	mov    0x60(%rbx),%rax
  816f55:	lock decq (%rax)
  816f59:	jne    816f64 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816f5b:	lea    0x60(%rbx),%rdi
  816f5f:	call   812f30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816f64:	movw   $0x0,0x99(%rbx)
  816f6d:	mov    0x40(%rbx),%rax
  816f71:	lock decq (%rax)
  816f75:	jne    816f81 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816f77:	lea    0x40(%rbx),%rdi
  816f7b:	call   *0x668bb7(%rip)        # e7fb38 <_DYNAMIC+0x470>
  816f81:	movb   $0x0,0x9b(%rbx)
  816f88:	mov    0x38(%rbx),%rax
  816f8c:	lock decq (%rax)
  816f90:	jne    816f9c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816f92:	lea    0x38(%rbx),%rdi
  816f96:	call   *0x668ba4(%rip)        # e7fb40 <_DYNAMIC+0x478>
  816f9c:	movb   $0x0,0x9c(%rbx)
  816fa3:	mov    0x30(%rbx),%rax
  816fa7:	lock decq (%rax)
  816fab:	jne    816fb7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816fad:	lea    0x30(%rbx),%rdi
  816fb1:	call   *0x668b91(%rip)        # e7fb48 <_DYNAMIC+0x480>
  816fb7:	movb   $0x0,0x9d(%rbx)
  816fbe:	mov    %r14,%rdi
  816fc1:	call   e2c4b0 <_Unwind_Resume@plt>
  816fc6:	call   *0x66894c(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816fd0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816fd0:	push   %rbx
  816fd1:	movzbl 0x20(%rdi),%eax
  816fd5:	cmp    $0x3,%eax
  816fd8:	je     816ff3 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816fda:	cmp    $0x4,%eax
  816fdd:	jne    817000 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816fdf:	mov    %rdi,%rbx
  816fe2:	add    $0x28,%rdi
  816fe6:	call   816db0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816feb:	movw   $0x0,0x21(%rbx)
  816ff1:	pop    %rbx
  816ff2:	ret
  816ff3:	add    $0x160,%rdi
  816ffa:	pop    %rbx
  816ffb:	jmp    816cd0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  817000:	pop    %rbx
  817001:	ret
  817002:	movw   $0x0,0x21(%rbx)
  817008:	mov    %rax,%rdi
  81700b:	call   e2c4b0 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008174f0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  8174f0:	push   %r14
  8174f2:	push   %rbx
  8174f3:	push   %rax
  8174f4:	mov    %rdi,%rbx
  8174f7:	mov    (%rdi),%rax
  8174fa:	lock decq (%rax)
  8174fe:	jne    817509 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817500:	mov    %rbx,%rdi
  817503:	call   *0x66863f(%rip)        # e7fb48 <_DYNAMIC+0x480>
  817509:	mov    0x8(%rbx),%rax
  81750d:	lock decq (%rax)
  817511:	jne    81751d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  817513:	lea    0x8(%rbx),%rdi
  817517:	call   *0x668623(%rip)        # e7fb40 <_DYNAMIC+0x478>
  81751d:	mov    0x10(%rbx),%rax
  817521:	lock decq (%rax)
  817525:	jne    817530 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  817527:	lea    0x10(%rbx),%rdi
  81752b:	call   812f30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  817530:	mov    0x18(%rbx),%rax
  817534:	lock decq (%rax)
  817538:	jne    81754e <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  81753a:	add    $0x18,%rbx
  81753e:	mov    %rbx,%rdi
  817541:	add    $0x8,%rsp
  817545:	pop    %rbx
  817546:	pop    %r14
  817548:	jmp    *0x6685e2(%rip)        # e7fb30 <_DYNAMIC+0x468>
  81754e:	add    $0x8,%rsp
  817552:	pop    %rbx
  817553:	pop    %r14
  817555:	ret
  817556:	mov    %rax,%r14
  817559:	jmp    81758a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  81755b:	mov    %rax,%r14
  81755e:	jmp    817577 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  817560:	mov    %rax,%r14
  817563:	mov    0x8(%rbx),%rax
  817567:	lock decq (%rax)
  81756b:	jne    817577 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  81756d:	lea    0x8(%rbx),%rdi
  817571:	call   *0x6685c9(%rip)        # e7fb40 <_DYNAMIC+0x478>
  817577:	mov    0x10(%rbx),%rax
  81757b:	lock decq (%rax)
  81757f:	jne    81758a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  817581:	lea    0x10(%rbx),%rdi
  817585:	call   812f30 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81758a:	mov    0x18(%rbx),%rax
  81758e:	lock decq (%rax)
  817592:	jne    8175a1 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  817594:	add    $0x18,%rbx
  817598:	mov    %rbx,%rdi
  81759b:	call   *0x66858f(%rip)        # e7fb30 <_DYNAMIC+0x468>
  8175a1:	mov    %r14,%rdi
  8175a4:	call   e2c4b0 <_Unwind_Resume@plt>
  8175a9:	call   *0x668369(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1172 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008175b0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  8175b0:	push   %r14
  8175b2:	push   %rbx
  8175b3:	push   %rax
  8175b4:	mov    %rdi,%rbx
  8175b7:	mov    0x210(%rdi),%rax
  8175be:	lock decq (%rax)
  8175c2:	jne    8175d1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  8175c4:	lea    0x210(%rbx),%rdi
  8175cb:	call   *0x66855f(%rip)        # e7fb30 <_DYNAMIC+0x468>
  8175d1:	mov    0x218(%rbx),%rax
  8175d8:	lock decq (%rax)
  8175dc:	jne    8175eb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  8175de:	lea    0x218(%rbx),%rdi
  8175e5:	call   *0x6685e5(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  8175eb:	mov    0x220(%rbx),%rax
  8175f2:	lock decq (%rax)
  8175f6:	jne    817605 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  8175f8:	lea    0x220(%rbx),%rdi
  8175ff:	call   *0x6685d3(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  817605:	mov    0x240(%rbx),%rax
  81760c:	lock decq (%rax)
  817610:	jne    81761f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  817612:	lea    0x240(%rbx),%rdi
  817619:	call   *0x6685b1(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  81761f:	mov    0x248(%rbx),%rax
  817626:	lock decq (%rax)
  81762a:	jne    817639 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  81762c:	lea    0x248(%rbx),%rdi
  817633:	call   *0x66859f(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  817639:	mov    0x268(%rbx),%rax
  817640:	lock decq (%rax)
  817644:	jne    817653 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  817646:	lea    0x268(%rbx),%rdi
  81764d:	call   *0x66857d(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  817653:	mov    0x270(%rbx),%rax
  81765a:	lock decq (%rax)
  81765e:	jne    81766d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  817660:	lea    0x270(%rbx),%rdi
  817667:	call   *0x66856b(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  81766d:	mov    0x290(%rbx),%rax
  817674:	lock decq (%rax)
  817678:	jne    817687 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  81767a:	lea    0x290(%rbx),%rdi
  817681:	call   *0x668549(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  817687:	mov    0x298(%rbx),%rax
  81768e:	lock decq (%rax)
  817692:	jne    8176a1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  817694:	lea    0x298(%rbx),%rdi
  81769b:	call   *0x668537(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  8176a1:	mov    0x2b8(%rbx),%rax
  8176a8:	lock decq (%rax)
  8176ac:	jne    8176bb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  8176ae:	lea    0x2b8(%rbx),%rdi
  8176b5:	call   *0x668515(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  8176bb:	mov    0x2c0(%rbx),%rax
  8176c2:	lock decq (%rax)
  8176c6:	jne    8176d5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  8176c8:	lea    0x2c0(%rbx),%rdi
  8176cf:	call   *0x668503(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  8176d5:	lea    0x60(%rbx),%rdi
  8176d9:	call   817a50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  8176de:	mov    0x310(%rbx),%r14
  8176e5:	test   %r14,%r14
  8176e8:	je     817747 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  8176ea:	mov    (%r14),%rsi
  8176ed:	test   %rsi,%rsi
  8176f0:	je     817705 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  8176f2:	mov    0x8(%r14),%rdi
  8176f6:	shl    $0x3,%rsi
  8176fa:	mov    $0x8,%edx
  8176ff:	call   *0x66820b(%rip)        # e7f910 <_DYNAMIC+0x248>
  817705:	mov    0x20(%r14),%rsi
  817709:	test   %rsi,%rsi
  81770c:	je     817734 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81770e:	mov    %rsi,%rax
  817711:	shl    $0x4,%rax
  817715:	add    %rax,%rsi
  817718:	add    $0x21,%rsi
  81771c:	je     817734 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81771e:	mov    0x18(%r14),%rdi
  817722:	sub    %rax,%rdi
  817725:	add    $0xfffffffffffffff0,%rdi
  817729:	mov    $0x10,%edx
  81772e:	call   *0x6681dc(%rip)        # e7f910 <_DYNAMIC+0x248>
  817734:	mov    $0x80,%esi
  817739:	mov    $0x8,%edx
  81773e:	mov    %r14,%rdi
  817741:	call   *0x6681c9(%rip)        # e7f910 <_DYNAMIC+0x248>
  817747:	mov    (%rbx),%rsi
  81774a:	test   %rsi,%rsi
  81774d:	je     817762 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  81774f:	mov    0x8(%rbx),%rdi
  817753:	shl    $0x4,%rsi
  817757:	mov    $0x4,%edx
  81775c:	call   *0x6681ae(%rip)        # e7f910 <_DYNAMIC+0x248>
  817762:	mov    0x18(%rbx),%rsi
  817766:	test   %rsi,%rsi
  817769:	je     81777e <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  81776b:	mov    0x20(%rbx),%rdi
  81776f:	shl    $0x3,%rsi
  817773:	mov    $0x4,%edx
  817778:	call   *0x668192(%rip)        # e7f910 <_DYNAMIC+0x248>
  81777e:	mov    0x30(%rbx),%rsi
  817782:	test   %rsi,%rsi
  817785:	je     81779a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817787:	mov    0x38(%rbx),%rdi
  81778b:	shl    $0x2,%rsi
  81778f:	mov    $0x4,%edx
  817794:	call   *0x668176(%rip)        # e7f910 <_DYNAMIC+0x248>
  81779a:	mov    0x48(%rbx),%rsi
  81779e:	test   %rsi,%rsi
  8177a1:	je     8177b6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  8177a3:	mov    0x50(%rbx),%rdi
  8177a7:	shl    $0x5,%rsi
  8177ab:	mov    $0x4,%edx
  8177b0:	call   *0x66815a(%rip)        # e7f910 <_DYNAMIC+0x248>
  8177b6:	mov    0x2e8(%rbx),%rsi
  8177bd:	test   %rsi,%rsi
  8177c0:	je     8177f0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x240>
  8177c2:	lea    (%rsi,%rsi,8),%rax
  8177c6:	lea    0x33(,%rax,4),%rax
  8177ce:	and    $0xfffffffffffffff0,%rax
  8177d2:	add    %rax,%rsi
  8177d5:	add    $0x11,%rsi
  8177d9:	je     8177f0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x240>
  8177db:	mov    0x2e0(%rbx),%rdi
  8177e2:	sub    %rax,%rdi
  8177e5:	mov    $0x10,%edx
  8177ea:	call   *0x668120(%rip)        # e7f910 <_DYNAMIC+0x248>
  8177f0:	mov    0x318(%rbx),%rax
  8177f7:	test   %rax,%rax
  8177fa:	je     817819 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x269>
  8177fc:	lock decq (%rax)
  817800:	jne    817819 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x269>
  817802:	add    $0x318,%rbx
  817809:	mov    %rbx,%rdi
  81780c:	add    $0x8,%rsp
  817810:	pop    %rbx
  817811:	pop    %r14
  817813:	jmp    *0x6683c7(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  817819:	add    $0x8,%rsp
  81781d:	pop    %rbx
  81781e:	pop    %r14
  817820:	ret
  817821:	mov    %rax,%r14
  817824:	jmp    817950 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  817829:	mov    %rax,%r14
  81782c:	mov    0x2c0(%rbx),%rax
  817833:	lock decq (%rax)
  817837:	jne    817950 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  81783d:	lea    0x2c0(%rbx),%rdi
  817844:	call   *0x66838e(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  81784a:	jmp    817950 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  81784f:	call   *0x6680c3(%rip)        # e7f918 <_DYNAMIC+0x250>
  817855:	mov    %rax,%r14
  817858:	jmp    817944 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  81785d:	mov    %rax,%r14
  817860:	mov    0x298(%rbx),%rax
  817867:	lock decq (%rax)
  81786b:	jne    817944 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  817871:	lea    0x298(%rbx),%rdi
  817878:	call   *0x66835a(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  81787e:	jmp    817944 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  817883:	call   *0x66808f(%rip)        # e7f918 <_DYNAMIC+0x250>
  817889:	mov    %rax,%r14
  81788c:	jmp    817938 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  817891:	mov    %rax,%r14
  817894:	mov    0x270(%rbx),%rax
  81789b:	lock decq (%rax)
  81789f:	jne    817938 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  8178a5:	lea    0x270(%rbx),%rdi
  8178ac:	call   *0x668326(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  8178b2:	jmp    817938 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  8178b7:	call   *0x66805b(%rip)        # e7f918 <_DYNAMIC+0x250>
  8178bd:	mov    %rax,%r14
  8178c0:	jmp    81792c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  8178c2:	mov    %rax,%r14
  8178c5:	mov    0x248(%rbx),%rax
  8178cc:	lock decq (%rax)
  8178d0:	jne    81792c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  8178d2:	lea    0x248(%rbx),%rdi
  8178d9:	call   *0x6682f9(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  8178df:	jmp    81792c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  8178e1:	call   *0x668031(%rip)        # e7f918 <_DYNAMIC+0x250>
  8178e7:	mov    %rax,%r14
  8178ea:	jmp    817920 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  8178ec:	mov    %rax,%r14
  8178ef:	mov    0x220(%rbx),%rax
  8178f6:	lock decq (%rax)
  8178fa:	jne    817920 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  8178fc:	lea    0x220(%rbx),%rdi
  817903:	call   *0x6682cf(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  817909:	jmp    817920 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  81790b:	call   *0x668007(%rip)        # e7f918 <_DYNAMIC+0x250>
  817911:	mov    %rax,%r14
  817914:	lea    0x218(%rbx),%rdi
  81791b:	call   817b50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817920:	lea    0x240(%rbx),%rdi
  817927:	call   817b50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81792c:	lea    0x268(%rbx),%rdi
  817933:	call   817b50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817938:	lea    0x290(%rbx),%rdi
  81793f:	call   817b50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817944:	lea    0x2b8(%rbx),%rdi
  81794b:	call   817b50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817950:	lea    0x60(%rbx),%rdi
  817954:	call   817a50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  817959:	mov    0x310(%rbx),%rdi
  817960:	call   8166f0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  817965:	mov    (%rbx),%rsi
  817968:	test   %rsi,%rsi
  81796b:	jne    8179d5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x425>
  81796d:	mov    0x18(%rbx),%rsi
  817971:	test   %rsi,%rsi
  817974:	jne    8179f1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x441>
  817976:	mov    0x30(%rbx),%rsi
  81797a:	test   %rsi,%rsi
  81797d:	jne    817a11 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x461>
  817983:	mov    0x48(%rbx),%rsi
  817987:	test   %rsi,%rsi
  81798a:	je     81799f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3ef>
  81798c:	mov    0x50(%rbx),%rdi
  817990:	shl    $0x5,%rsi
  817994:	mov    $0x4,%edx
  817999:	call   *0x667f71(%rip)        # e7f910 <_DYNAMIC+0x248>
  81799f:	lea    0x2e0(%rbx),%rdi
  8179a6:	call   819e60 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  8179ab:	mov    0x318(%rbx),%rax
  8179b2:	test   %rax,%rax
  8179b5:	je     8179cd <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41d>
  8179b7:	lock decq (%rax)
  8179bb:	jne    8179cd <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41d>
  8179bd:	add    $0x318,%rbx
  8179c4:	mov    %rbx,%rdi
  8179c7:	call   *0x668213(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  8179cd:	mov    %r14,%rdi
  8179d0:	call   e2c4b0 <_Unwind_Resume@plt>
  8179d5:	mov    0x8(%rbx),%rdi
  8179d9:	shl    $0x4,%rsi
  8179dd:	mov    $0x4,%edx
  8179e2:	call   *0x667f28(%rip)        # e7f910 <_DYNAMIC+0x248>
  8179e8:	mov    0x18(%rbx),%rsi
  8179ec:	test   %rsi,%rsi
  8179ef:	je     817976 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c6>
  8179f1:	mov    0x20(%rbx),%rdi
  8179f5:	shl    $0x3,%rsi
  8179f9:	mov    $0x4,%edx
  8179fe:	call   *0x667f0c(%rip)        # e7f910 <_DYNAMIC+0x248>
  817a04:	mov    0x30(%rbx),%rsi
  817a08:	test   %rsi,%rsi
  817a0b:	je     817983 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3d3>
  817a11:	mov    0x38(%rbx),%rdi
  817a15:	shl    $0x2,%rsi
  817a19:	mov    $0x4,%edx
  817a1e:	call   *0x667eec(%rip)        # e7f910 <_DYNAMIC+0x248>
  817a24:	mov    0x48(%rbx),%rsi
  817a28:	test   %rsi,%rsi
  817a2b:	jne    81798c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3dc>
  817a31:	jmp    81799f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3ef>
  817a36:	call   *0x667edc(%rip)        # e7f918 <_DYNAMIC+0x250>
  817a3c:	mov    %rax,%r14
  817a3f:	jmp    817959 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a9>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817a50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  817a50:	push   %r14
  817a52:	push   %rbx
  817a53:	push   %rax
  817a54:	mov    %rdi,%rbx
  817a57:	mov    (%rdi),%rax
  817a5a:	lock decq (%rax)
  817a5e:	jne    817a69 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  817a60:	mov    %rbx,%rdi
  817a63:	call   *0x668147(%rip)        # e7fbb0 <_DYNAMIC+0x4e8>
  817a69:	mov    0x50(%rbx),%rax
  817a6d:	lock decq (%rax)
  817a71:	jne    817a7d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  817a73:	lea    0x50(%rbx),%rdi
  817a77:	call   *0x66812b(%rip)        # e7fba8 <_DYNAMIC+0x4e0>
  817a7d:	mov    0x58(%rbx),%rax
  817a81:	lock decq (%rax)
  817a85:	jne    817a91 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  817a87:	lea    0x58(%rbx),%rdi
  817a8b:	call   *0x66811f(%rip)        # e7fbb0 <_DYNAMIC+0x4e8>
  817a91:	mov    0xb0(%rbx),%rsi
  817a98:	test   %rsi,%rsi
  817a9b:	je     817acd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  817a9d:	mov    %rsi,%rax
  817aa0:	shl    $0x5,%rax
  817aa4:	add    %rax,%rsi
  817aa7:	add    $0x31,%rsi
  817aab:	je     817acd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  817aad:	mov    0xa8(%rbx),%rdi
  817ab4:	sub    %rax,%rdi
  817ab7:	add    $0xffffffffffffffe0,%rdi
  817abb:	mov    $0x10,%edx
  817ac0:	add    $0x8,%rsp
  817ac4:	pop    %rbx
  817ac5:	pop    %r14
  817ac7:	jmp    *0x667e43(%rip)        # e7f910 <_DYNAMIC+0x248>
  817acd:	add    $0x8,%rsp
  817ad1:	pop    %rbx
  817ad2:	pop    %r14
  817ad4:	ret
  817ad5:	mov    %rax,%r14
  817ad8:	jmp    817b05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817ada:	mov    %rax,%r14
  817add:	mov    0x58(%rbx),%rax
  817ae1:	lock decq (%rax)
  817ae5:	jne    817b05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817ae7:	lea    0x58(%rbx),%rdi
  817aeb:	call   *0x6680bf(%rip)        # e7fbb0 <_DYNAMIC+0x4e8>
  817af1:	jmp    817b05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817af3:	call   *0x667e1f(%rip)        # e7f918 <_DYNAMIC+0x250>
  817af9:	mov    %rax,%r14
  817afc:	lea    0x50(%rbx),%rdi
  817b00:	call   817c50 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  817b05:	add    $0xa8,%rbx
  817b0c:	mov    %rbx,%rdi
  817b0f:	call   819ea0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  817b14:	mov    %r14,%rdi
  817b17:	call   e2c4b0 <_Unwind_Resume@plt>
  817b1c:	call   *0x667df6(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817b30 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817b30:	cmpl   $0x1,(%rdi)
  817b33:	ja     817b4d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817b35:	mov    0x8(%rdi),%rsi
  817b39:	test   %rsi,%rsi
  817b3c:	je     817b4d <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817b3e:	mov    0x10(%rdi),%rdi
  817b42:	mov    $0x1,%edx
  817b47:	jmp    *0x667dc3(%rip)        # e7f910 <_DYNAMIC+0x248>
  817b4d:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817b50 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  817b50:	push   %r14
  817b52:	push   %rbx
  817b53:	push   %rax
  817b54:	mov    %rdi,%rbx
  817b57:	mov    (%rdi),%rax
  817b5a:	lock decq (%rax)
  817b5e:	jne    817b69 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  817b60:	mov    %rbx,%rdi
  817b63:	call   *0x668067(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  817b69:	mov    0x8(%rbx),%rax
  817b6d:	lock decq (%rax)
  817b71:	jne    817b87 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  817b73:	add    $0x8,%rbx
  817b77:	mov    %rbx,%rdi
  817b7a:	add    $0x8,%rsp
  817b7e:	pop    %rbx
  817b7f:	pop    %r14
  817b81:	jmp    *0x668051(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  817b87:	add    $0x8,%rsp
  817b8b:	pop    %rbx
  817b8c:	pop    %r14
  817b8e:	ret
  817b8f:	mov    %rax,%r14
  817b92:	mov    0x8(%rbx),%rax
  817b96:	lock decq (%rax)
  817b9a:	jne    817ba9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  817b9c:	add    $0x8,%rbx
  817ba0:	mov    %rbx,%rdi
  817ba3:	call   *0x66802f(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  817ba9:	mov    %r14,%rdi
  817bac:	call   e2c4b0 <_Unwind_Resume@plt>
  817bb1:	call   *0x667d61(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000818520 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  818520:	sub    $0x18,%rsp
  818524:	mov    %rsi,%rax
  818527:	mov    (%rdi),%ecx
  818529:	lea    -0x747730(%rip),%rdx        # d0e00 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  818530:	movslq (%rdx,%rcx,4),%rcx
  818534:	add    %rdx,%rcx
  818537:	jmp    *%rcx
  818539:	add    $0x8,%rdi
  81853d:	mov    %rdi,0x10(%rsp)
  818542:	lea    -0x743a2f(%rip),%rsi        # d4b1a <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x48d2>
  818549:	jmp    8185d8 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  81854e:	lea    -0x743a12(%rip),%rsi        # d4b43 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x48fb>
  818555:	mov    $0x13,%edx
  81855a:	mov    %rax,%rdi
  81855d:	add    $0x18,%rsp
  818561:	jmp    *0x667499(%rip)        # e7fa00 <_DYNAMIC+0x338>
  818567:	add    $0x4,%rdi
  81856b:	mov    %rdi,0x10(%rsp)
  818570:	lea    -0x743a51(%rip),%rsi        # d4b26 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x48de>
  818577:	lea    0x61583a(%rip),%r8        # e2ddb8 <__frame_dummy_init_array_entry+0x8c8>
  81857e:	lea    0x10(%rsp),%rcx
  818583:	mov    $0x11,%edx
  818588:	mov    %rax,%rdi
  81858b:	call   *0x667477(%rip)        # e7fa08 <_DYNAMIC+0x340>
  818591:	add    $0x18,%rsp
  818595:	ret
  818596:	lea    -0x743a66(%rip),%rsi        # d4b37 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x48ef>
  81859d:	mov    $0xc,%edx
  8185a2:	mov    %rax,%rdi
  8185a5:	add    $0x18,%rsp
  8185a9:	jmp    *0x667451(%rip)        # e7fa00 <_DYNAMIC+0x338>
  8185af:	lea    -0x743a4a(%rip),%rsi        # d4b6c <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4924>
  8185b6:	mov    $0x9,%edx
  8185bb:	mov    %rax,%rdi
  8185be:	add    $0x18,%rsp
  8185c2:	jmp    *0x667438(%rip)        # e7fa00 <_DYNAMIC+0x338>
  8185c8:	add    $0x8,%rdi
  8185cc:	mov    %rdi,0x10(%rsp)
  8185d1:	lea    -0x743ab8(%rip),%rsi        # d4b20 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x48d8>
  8185d8:	lea    0x6157b9(%rip),%r8        # e2dd98 <__frame_dummy_init_array_entry+0x8a8>
  8185df:	lea    0x10(%rsp),%rcx
  8185e4:	mov    $0x6,%edx
  8185e9:	mov    %rax,%rdi
  8185ec:	call   *0x667416(%rip)        # e7fa08 <_DYNAMIC+0x340>
  8185f2:	add    $0x18,%rsp
  8185f6:	ret
  8185f7:	add    $0x8,%rdi
  8185fb:	mov    %rdi,0x10(%rsp)
  818600:	lea    0x6157d1(%rip),%rcx        # e2ddd8 <__frame_dummy_init_array_entry+0x8e8>
  818607:	mov    %rcx,(%rsp)
  81860b:	lea    -0x743abc(%rip),%rsi        # d4b56 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x490e>
  818612:	lea    -0x76980d(%rip),%rcx        # aee0c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  818619:	lea    0x10(%rsp),%r9
  81861e:	mov    $0x9,%edx
  818623:	mov    $0x4,%r8d
  818629:	mov    %rax,%rdi
  81862c:	call   *0x6675be(%rip)        # e7fbf0 <_DYNAMIC+0x528>
  818632:	add    $0x18,%rsp
  818636:	ret
  818637:	lea    -0x743adf(%rip),%rsi        # d4b5f <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4917>
  81863e:	mov    $0xd,%edx
  818643:	mov    %rax,%rdi
  818646:	add    $0x18,%rsp
  81864a:	jmp    *0x6673b0(%rip)        # e7fa00 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819ea0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819ea0:	mov    0x8(%rdi),%rsi
  819ea4:	test   %rsi,%rsi
  819ea7:	je     819ece <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819ea9:	mov    %rsi,%rax
  819eac:	shl    $0x5,%rax
  819eb0:	add    %rax,%rsi
  819eb3:	add    $0x31,%rsi
  819eb7:	je     819ece <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819eb9:	mov    (%rdi),%rdi
  819ebc:	sub    %rax,%rdi
  819ebf:	add    $0xffffffffffffffe0,%rdi
  819ec3:	mov    $0x10,%edx
  819ec8:	jmp    *0x665a42(%rip)        # e7f910 <_DYNAMIC+0x248>
  819ece:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819ed0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819ed0:	mov    0x8(%rdi),%rsi
  819ed4:	test   %rsi,%rsi
  819ed7:	je     819efe <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819ed9:	mov    %rsi,%rax
  819edc:	shl    $0x4,%rax
  819ee0:	add    %rax,%rsi
  819ee3:	add    $0x21,%rsi
  819ee7:	je     819efe <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819ee9:	mov    (%rdi),%rdi
  819eec:	sub    %rax,%rdi
  819eef:	add    $0xfffffffffffffff0,%rdi
  819ef3:	mov    $0x10,%edx
  819ef8:	jmp    *0x665a12(%rip)        # e7f910 <_DYNAMIC+0x248>
  819efe:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b790 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b790:	push   %r14
  81b792:	push   %rbx
  81b793:	sub    $0x38,%rsp
  81b797:	mov    %rdi,%rbx
  81b79a:	cmpq   $0x0,(%rsi)
  81b79e:	je     81b8a8 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b7a4:	movdqu (%rsi),%xmm0
  81b7a8:	movdqu 0x10(%rsi),%xmm1
  81b7ad:	movdqu 0x20(%rsi),%xmm2
  81b7b2:	movdqa %xmm2,0x20(%rsp)
  81b7b8:	movdqa %xmm1,0x10(%rsp)
  81b7be:	movdqa %xmm0,(%rsp)
  81b7c3:	cmpq   $0x0,0x18(%rcx)
  81b7c8:	je     81b8bc <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b7ce:	lea    0x10(%rsp),%rsi
  81b7d3:	lea    0x20(%rcx),%rdi
  81b7d7:	mov    %rcx,%r14
  81b7da:	call   821e80 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b7df:	mov    %rax,%rsi
  81b7e2:	shr    $0x39,%rsi
  81b7e6:	mov    (%r14),%rcx
  81b7e9:	mov    0x8(%r14),%rdx
  81b7ed:	movd   %esi,%xmm0
  81b7f1:	punpcklbw %xmm0,%xmm0
  81b7f5:	pshuflw $0x0,%xmm0,%xmm0
  81b7fa:	pshufd $0x44,%xmm0,%xmm0
  81b7ff:	mov    0x10(%rsp),%rsi
  81b804:	movzwl 0x1c(%rsp),%edi
  81b809:	xor    %r8d,%r8d
  81b80c:	mov    0x18(%rsp),%r9d
  81b811:	pcmpeqd %xmm1,%xmm1
  81b815:	and    %rdx,%rax
  81b818:	movdqu (%rcx,%rax,1),%xmm2
  81b81d:	movdqa %xmm2,%xmm3
  81b821:	pcmpeqb %xmm0,%xmm3
  81b825:	pmovmskb %xmm3,%r10d
  81b82a:	test   %r10d,%r10d
  81b82d:	je     81b870 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b82f:	tzcnt  %r10d,%r14d
  81b834:	add    %rax,%r14
  81b837:	and    %rdx,%r14
  81b83a:	shl    $0x5,%r14
  81b83e:	mov    %rcx,%r11
  81b841:	sub    %r14,%r11
  81b844:	cmp    -0x20(%r11),%rsi
  81b848:	jne    81b857 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b84a:	cmp    -0x14(%r11),%di
  81b84f:	jne    81b857 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b851:	cmp    -0x18(%r11),%r9d
  81b855:	je     81b88b <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b857:	lea    -0x1(%r10),%r11d
  81b85b:	and    %r10w,%r11w
  81b85f:	mov    %r11d,%r10d
  81b862:	jne    81b82f <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b864:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b870:	pcmpeqb %xmm1,%xmm2
  81b874:	pmovmskb %xmm2,%r10d
  81b879:	test   %r10d,%r10d
  81b87c:	jne    81b8bc <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b87e:	add    %r8,%rax
  81b881:	add    $0x10,%rax
  81b885:	add    $0x10,%r8
  81b889:	jmp    81b815 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b88b:	mov    -0x4(%r11),%eax
  81b88f:	shl    $0x10,%eax
  81b892:	or     -0x8(%r11),%eax
  81b896:	mov    -0x10(%r11),%rcx
  81b89a:	mov    %rcx,(%rbx)
  81b89d:	mov    %eax,0x8(%rbx)
  81b8a0:	add    $0x38,%rsp
  81b8a4:	pop    %rbx
  81b8a5:	pop    %r14
  81b8a7:	ret
  81b8a8:	mov    0x8(%rdx),%eax
  81b8ab:	mov    %eax,0x8(%rbx)
  81b8ae:	mov    (%rdx),%rax
  81b8b1:	mov    %rax,(%rbx)
  81b8b4:	add    $0x38,%rsp
  81b8b8:	pop    %rbx
  81b8b9:	pop    %r14
  81b8bb:	ret
  81b8bc:	lea    -0x746956(%rip),%rdi        # d4f6d <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x147>
  81b8c3:	lea    0x612946(%rip),%rdx        # e2e210 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x68>
  81b8ca:	mov    $0x16,%esi
  81b8cf:	call   *0x664393(%rip)        # e7fc68 <_DYNAMIC+0x5a0>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bbd0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81bbd0:	push   %r14
  81bbd2:	push   %rbx
  81bbd3:	push   %rax
  81bbd4:	mov    %rdi,%rbx
  81bbd7:	mov    (%rdi),%rax
  81bbda:	lock decq (%rax)
  81bbde:	jne    81bbe9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81bbe0:	mov    %rbx,%rdi
  81bbe3:	call   *0x663fc7(%rip)        # e7fbb0 <_DYNAMIC+0x4e8>
  81bbe9:	mov    0x50(%rbx),%rax
  81bbed:	lock decq (%rax)
  81bbf1:	jne    81bbfd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81bbf3:	lea    0x50(%rbx),%rdi
  81bbf7:	call   *0x663fab(%rip)        # e7fba8 <_DYNAMIC+0x4e0>
  81bbfd:	mov    0x58(%rbx),%rax
  81bc01:	lock decq (%rax)
  81bc05:	jne    81bc11 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81bc07:	lea    0x58(%rbx),%rdi
  81bc0b:	call   *0x663f9f(%rip)        # e7fbb0 <_DYNAMIC+0x4e8>
  81bc11:	mov    0xb0(%rbx),%rsi
  81bc18:	test   %rsi,%rsi
  81bc1b:	je     81bc4d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bc1d:	mov    %rsi,%rax
  81bc20:	shl    $0x5,%rax
  81bc24:	add    %rax,%rsi
  81bc27:	add    $0x31,%rsi
  81bc2b:	je     81bc4d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bc2d:	mov    0xa8(%rbx),%rdi
  81bc34:	sub    %rax,%rdi
  81bc37:	add    $0xffffffffffffffe0,%rdi
  81bc3b:	mov    $0x10,%edx
  81bc40:	add    $0x8,%rsp
  81bc44:	pop    %rbx
  81bc45:	pop    %r14
  81bc47:	jmp    *0x663cc3(%rip)        # e7f910 <_DYNAMIC+0x248>
  81bc4d:	add    $0x8,%rsp
  81bc51:	pop    %rbx
  81bc52:	pop    %r14
  81bc54:	ret
  81bc55:	mov    %rax,%r14
  81bc58:	jmp    81bc85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bc5a:	mov    %rax,%r14
  81bc5d:	mov    0x58(%rbx),%rax
  81bc61:	lock decq (%rax)
  81bc65:	jne    81bc85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bc67:	lea    0x58(%rbx),%rdi
  81bc6b:	call   *0x663f3f(%rip)        # e7fbb0 <_DYNAMIC+0x4e8>
  81bc71:	jmp    81bc85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bc73:	call   *0x663c9f(%rip)        # e7f918 <_DYNAMIC+0x250>
  81bc79:	mov    %rax,%r14
  81bc7c:	lea    0x50(%rbx),%rdi
  81bc80:	call   81c520 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bc85:	add    $0xa8,%rbx
  81bc8c:	mov    %rbx,%rdi
  81bc8f:	call   8255b0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bc94:	mov    %r14,%rdi
  81bc97:	call   e2c4b0 <_Unwind_Resume@plt>
  81bc9c:	call   *0x663c76(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bcb0:	push   %r14
  81bcb2:	push   %rbx
  81bcb3:	push   %rax
  81bcb4:	mov    %rdi,%rbx
  81bcb7:	mov    (%rdi),%rax
  81bcba:	lock decq (%rax)
  81bcbe:	jne    81bcc9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bcc0:	mov    %rbx,%rdi
  81bcc3:	call   *0x663f07(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  81bcc9:	mov    0x8(%rbx),%rax
  81bccd:	lock decq (%rax)
  81bcd1:	jne    81bce7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bcd3:	add    $0x8,%rbx
  81bcd7:	mov    %rbx,%rdi
  81bcda:	add    $0x8,%rsp
  81bcde:	pop    %rbx
  81bcdf:	pop    %r14
  81bce1:	jmp    *0x663ef1(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  81bce7:	add    $0x8,%rsp
  81bceb:	pop    %rbx
  81bcec:	pop    %r14
  81bcee:	ret
  81bcef:	mov    %rax,%r14
  81bcf2:	mov    0x8(%rbx),%rax
  81bcf6:	lock decq (%rax)
  81bcfa:	jne    81bd09 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bcfc:	add    $0x8,%rbx
  81bd00:	mov    %rbx,%rdi
  81bd03:	call   *0x663ecf(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  81bd09:	mov    %r14,%rdi
  81bd0c:	call   e2c4b0 <_Unwind_Resume@plt>
  81bd11:	call   *0x663c01(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=610 frame=72

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c650 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c650:	push   %rbp
  81c651:	push   %r15
  81c653:	push   %r14
  81c655:	push   %r13
  81c657:	push   %r12
  81c659:	push   %rbx
  81c65a:	sub    $0x18,%rsp
  81c65e:	movss  0x8c(%rdi),%xmm3
  81c666:	movss  -0x76d6b2(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c66e:	movaps %xmm3,%xmm1
  81c671:	subss  %xmm0,%xmm1
  81c675:	cvttss2si %xmm1,%rax
  81c67a:	cvttss2si %xmm3,%r8
  81c67f:	mov    %r8,%rcx
  81c682:	sar    $0x3f,%rcx
  81c686:	and    %rax,%rcx
  81c689:	or     %r8,%rcx
  81c68c:	xor    %r9d,%r9d
  81c68f:	xorps  %xmm1,%xmm1
  81c692:	ucomiss %xmm1,%xmm3
  81c695:	cmovb  %r9,%rcx
  81c699:	movss  -0x76d6e1(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c6a1:	ucomiss %xmm2,%xmm3
  81c6a4:	mov    $0xffffffffffffffff,%rax
  81c6ab:	cmova  %rax,%rcx
  81c6af:	movss  0x94(%rdi),%xmm3
  81c6b7:	mov    %rcx,%r8
  81c6ba:	shr    $0x4,%r8
  81c6be:	movaps %xmm3,%xmm4
  81c6c1:	subss  %xmm0,%xmm4
  81c6c5:	cvttss2si %xmm4,%r10
  81c6ca:	cvttss2si %xmm3,%r11
  81c6cf:	mov    %r11,%rbx
  81c6d2:	sar    $0x3f,%rbx
  81c6d6:	and    %r10,%rbx
  81c6d9:	or     %r11,%rbx
  81c6dc:	ucomiss %xmm1,%xmm3
  81c6df:	cmovb  %r9,%rbx
  81c6e3:	ucomiss %xmm2,%xmm3
  81c6e6:	cmova  %rax,%rbx
  81c6ea:	mov    %rsi,0x10(%rsp)
  81c6ef:	lea    (%rcx,%rbx,1),%r9
  81c6f3:	dec    %r9
  81c6f6:	shr    $0x4,%r9
  81c6fa:	cmp    %r9,%r8
  81c6fd:	jbe    81c70e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c6ff:	add    $0x18,%rsp
  81c703:	pop    %rbx
  81c704:	pop    %r12
  81c706:	pop    %r13
  81c708:	pop    %r14
  81c70a:	pop    %r15
  81c70c:	pop    %rbp
  81c70d:	ret
  81c70e:	movss  0x88(%rdi),%xmm3
  81c716:	movaps %xmm3,%xmm4
  81c719:	subss  %xmm0,%xmm4
  81c71d:	cvttss2si %xmm4,%rsi
  81c722:	cvttss2si %xmm3,%r10
  81c727:	mov    %r10,%rcx
  81c72a:	sar    $0x3f,%rcx
  81c72e:	and    %rsi,%rcx
  81c731:	or     %r10,%rcx
  81c734:	xor    %esi,%esi
  81c736:	ucomiss %xmm1,%xmm3
  81c739:	cmovb  %rsi,%rcx
  81c73d:	ucomiss %xmm2,%xmm3
  81c740:	cmova  %rax,%rcx
  81c744:	movss  0x90(%rdi),%xmm3
  81c74c:	mov    %rcx,%rbx
  81c74f:	shr    $0x4,%rbx
  81c753:	movaps %xmm3,%xmm4
  81c756:	subss  %xmm0,%xmm4
  81c75a:	cvttss2si %xmm4,%rdi
  81c75f:	cvttss2si %xmm3,%r10
  81c764:	mov    %r10,%r11
  81c767:	sar    $0x3f,%r11
  81c76b:	and    %rdi,%r11
  81c76e:	or     %r10,%r11
  81c771:	ucomiss %xmm1,%xmm3
  81c774:	cmovb  %rsi,%r11
  81c778:	ucomiss %xmm2,%xmm3
  81c77b:	cmova  %rax,%r11
  81c77f:	add    %rcx,%r11
  81c782:	dec    %r11
  81c785:	shr    $0x4,%r11
  81c789:	mov    %rbx,0x8(%rsp)
  81c78e:	cmp    %r11,%rbx
  81c791:	jbe    81c7bd <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c793:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c7a0:	mov    %r8,%rax
  81c7a3:	cmp    %r9,%r8
  81c7a6:	adc    $0x0,%r8
  81c7aa:	cmp    %r9,%rax
  81c7ad:	jae    81c6ff <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7b3:	cmp    %r9,%r8
  81c7b6:	jbe    81c7a0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c7b8:	jmp    81c6ff <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7bd:	mov    (%rdx),%rbx
  81c7c0:	mov    0x8(%rdx),%r14
  81c7c4:	mov    0x10(%rdx),%rdx
  81c7c8:	movabs $0xffff800000,%r15
  81c7d2:	mov    %r9,(%rsp)
  81c7d6:	cs nopw 0x0(%rax,%rax,1)
  81c7e0:	mov    %r8,%r12
  81c7e3:	cmp    %r9,%r8
  81c7e6:	adc    $0x0,%r8
  81c7ea:	mov    %r12,%r13
  81c7ed:	imul   0x10(%rsp),%r13
  81c7f3:	mov    0x8(%rsp),%r10
  81c7f8:	mov    %r10,%rbp
  81c7fb:	nopl   0x0(%rax,%rax,1)
  81c800:	cmp    %r11,%r10
  81c803:	adc    $0x0,%rbp
  81c807:	lea    (%r10,%r13,1),%rdi
  81c80b:	mov    0x10(%rbx),%rax
  81c80f:	cmp    %rax,%rdi
  81c812:	jae    81c88f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x23f>
  81c814:	mov    0x8(%rbx),%rcx
  81c818:	movslq 0x4(%rcx,%rdi,8),%rsi
  81c81d:	test   %rsi,%rsi
  81c820:	js     81c867 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x217>
  81c822:	mov    (%rcx,%rdi,8),%eax
  81c825:	shl    $0x20,%rsi
  81c829:	or     %rax,%rsi
  81c82c:	test   %r15,%rsi
  81c82f:	je     81c867 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x217>
  81c831:	mov    %rsi,%r9
  81c834:	shr    $0x17,%r9
  81c838:	and    $0x7fffff,%eax
  81c83d:	and    $0x1ffff,%r9d
  81c844:	add    %r9,%rax
  81c847:	dec    %rax
  81c84a:	add    $0xffffffffff800000,%rsi
  81c851:	mov    %rsi,(%rcx,%rdi,8)
  81c855:	mov    0x10(%r14),%rcx
  81c859:	cmp    %rcx,%rax
  81c85c:	jae    81c89f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x24f>
  81c85e:	mov    0x8(%r14),%rcx
  81c862:	mov    (%rdx),%esi
  81c864:	mov    %esi,(%rcx,%rax,4)
  81c867:	cmp    %r11,%r10
  81c86a:	jae    81c874 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x224>
  81c86c:	mov    %rbp,%r10
  81c86f:	cmp    %r11,%rbp
  81c872:	jbe    81c800 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c874:	mov    (%rsp),%r9
  81c878:	cmp    %r9,%r12
  81c87b:	jae    81c6ff <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c881:	cmp    %r9,%r8
  81c884:	jbe    81c7e0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c88a:	jmp    81c6ff <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c88f:	lea    0x611992(%rip),%rdx        # e2e228 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c896:	mov    %rax,%rsi
  81c899:	call   *0x663321(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
  81c89f:	lea    0x61199a(%rip),%rdx        # e2e240 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c8a6:	mov    %rax,%rdi
  81c8a9:	mov    %rcx,%rsi
  81c8ac:	call   *0x66330e(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>> bytes=321 frame=248

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c8c0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>:
  81c8c0:	push   %rbp
  81c8c1:	push   %r15
  81c8c3:	push   %r14
  81c8c5:	push   %r13
  81c8c7:	push   %r12
  81c8c9:	push   %rbx
  81c8ca:	sub    $0xc8,%rsp
  81c8d1:	mov    %edx,%ebp
  81c8d3:	mov    %rsi,%r14
  81c8d6:	mov    %rdi,(%rsp)
  81c8da:	lea    0x8(%rsp),%rdi
  81c8df:	call   *0x66339b(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81c8e5:	mov    0x8(%rsp),%rsi
  81c8ea:	xor    %r13d,%r13d
  81c8ed:	test   $0x1,%bpl
  81c8f1:	je     81c990 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xd0>
  81c8f7:	test   %rsi,%rsi
  81c8fa:	je     81c9d5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c900:	lea    0x70(%rsp),%r15
  81c905:	lea    0x8(%rsp),%r12
  81c90a:	mov    0x66336f(%rip),%rbp        # e7fc80 <_DYNAMIC+0x5b8>
  81c911:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c920:	mov    0x18(%rsp),%rbx
  81c925:	cmp    $0x1,%rbx
  81c929:	jbe    81c970 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb0>
  81c92b:	mov    0x10(%rsp),%rax
  81c930:	mov    (%rax),%edx
  81c932:	mov    %r15,%rdi
  81c935:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c93a:	movss  0x74(%rsp),%xmm0
  81c940:	xorps  %xmm1,%xmm1
  81c943:	ucomiss %xmm1,%xmm0
  81c946:	lea    (%rbx,%rbx,1),%rax
  81c94a:	lea    0x5(%rbx,%rbx,1),%rcx
  81c94f:	lea    (%rax,%rax,2),%rdx
  81c953:	mov    %rcx,%rax
  81c956:	cmovne %rdx,%rax
  81c95a:	cmovp  %rdx,%rax
  81c95e:	cmpb   $0x3,0x70(%rsp)
  81c963:	cmovne %rcx,%rax
  81c967:	jmp    81c977 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb7>
  81c969:	nopl   0x0(%rax)
  81c970:	add    %rbx,%rbx
  81c973:	lea    (%rbx,%rbx,2),%rax
  81c977:	add    %rax,%r13
  81c97a:	jb     81c9f5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c97c:	mov    %r12,%rdi
  81c97f:	mov    %r14,%rsi
  81c982:	call   *%rbp
  81c984:	mov    0x8(%rsp),%rsi
  81c989:	test   %rsi,%rsi
  81c98c:	jne    81c920 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x60>
  81c98e:	jmp    81c9d5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c990:	test   %rsi,%rsi
  81c993:	je     81c9d5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c995:	lea    0x8(%rsp),%r15
  81c99a:	mov    0x6632df(%rip),%r12        # e7fc80 <_DYNAMIC+0x5b8>
  81c9a1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c9b0:	mov    %r13,%rax
  81c9b3:	mov    0x18(%rsp),%rcx
  81c9b8:	add    %rcx,%rcx
  81c9bb:	lea    (%rcx,%rcx,2),%r13
  81c9bf:	add    %rax,%r13
  81c9c2:	jb     81c9f5 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c9c4:	mov    %r15,%rdi
  81c9c7:	mov    %r14,%rsi
  81c9ca:	call   *%r12
  81c9cd:	cmpq   $0x0,0x8(%rsp)
  81c9d3:	jne    81c9b0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xf0>
  81c9d5:	mov    (%rsp),%rax
  81c9d9:	mov    %r13,0x8(%rax)
  81c9dd:	movl   $0xffffffff,(%rax)
  81c9e3:	add    $0xc8,%rsp
  81c9ea:	pop    %rbx
  81c9eb:	pop    %r12
  81c9ed:	pop    %r13
  81c9ef:	pop    %r14
  81c9f1:	pop    %r15
  81c9f3:	pop    %rbp
  81c9f4:	ret
  81c9f5:	mov    (%rsp),%rax
  81c9f9:	movl   $0x6,(%rax)
  81c9ff:	jmp    81c9e3 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x123>

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc50 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81cc50:	push   %rbp
  81cc51:	push   %r14
  81cc53:	push   %rbx
  81cc54:	cmp    0x329(%rdi),%sil
  81cc5b:	je     81cc9b <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81cc5d:	mov    0x318(%rdi),%rax
  81cc64:	test   %rax,%rax
  81cc67:	je     81cc89 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cc69:	lock decq (%rax)
  81cc6d:	jne    81cc89 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cc6f:	lea    0x318(%rdi),%rbx
  81cc76:	mov    %rdi,%r14
  81cc79:	mov    %rbx,%rdi
  81cc7c:	mov    %esi,%ebp
  81cc7e:	call   *0x662f5c(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  81cc84:	mov    %r14,%rdi
  81cc87:	mov    %ebp,%esi
  81cc89:	movq   $0x0,0x318(%rdi)
  81cc94:	mov    %sil,0x329(%rdi)
  81cc9b:	pop    %rbx
  81cc9c:	pop    %r14
  81cc9e:	pop    %rbp
  81cc9f:	ret
  81cca0:	movq   $0x0,(%rbx)
  81cca7:	mov    %rax,%rdi
  81ccaa:	call   e2c4b0 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=303 frame=120

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081ccb0 <<gpui_gpu::renderer::Buffer>::write>:
  81ccb0:	push   %r15
  81ccb2:	push   %r14
  81ccb4:	push   %r13
  81ccb6:	push   %r12
  81ccb8:	push   %rbx
  81ccb9:	sub    $0x50,%rsp
  81ccbd:	mov    %rdx,%r14
  81ccc0:	mov    %rdi,%rbx
  81ccc3:	cmp    0x20(%rdi),%r8
  81ccc7:	jbe    81cd7a <<gpui_gpu::renderer::Buffer>::write+0xca>
  81cccd:	mov    %rcx,%r15
  81ccd0:	mov    $0x1,%r13d
  81ccd6:	cmp    $0x2,%r8
  81ccda:	jb     81ccf3 <<gpui_gpu::renderer::Buffer>::write+0x43>
  81ccdc:	lea    -0x1(%r8),%rax
  81cce0:	bsr    %rax,%rcx
  81cce4:	not    %ecx
  81cce6:	mov    $0xffffffffffffffff,%r13
  81cced:	shr    %cl,%r13
  81ccf0:	inc    %r13
  81ccf3:	mov    %r8,%r12
  81ccf6:	lea    -0x747d7a(%rip),%rax        # d4f83 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x15d>
  81ccfd:	mov    %rax,0x30(%rsp)
  81cd02:	movq   $0xa,0x38(%rsp)
  81cd0b:	mov    %r13,0x40(%rsp)
  81cd10:	movl   $0x88,0x48(%rsp)
  81cd18:	movb   $0x0,0x4c(%rsp)
  81cd1d:	lea    0x8(%rsp),%rdi
  81cd22:	lea    0x30(%rsp),%rdx
  81cd27:	call   *0x662fb3(%rip)        # e7fce0 <_DYNAMIC+0x618>
  81cd2d:	mov    %r13,0x28(%rsp)
  81cd32:	mov    (%rbx),%rax
  81cd35:	lock decq (%rax)
  81cd39:	jne    81cd44 <<gpui_gpu::renderer::Buffer>::write+0x94>
  81cd3b:	mov    %rbx,%rdi
  81cd3e:	call   *0x662e8c(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  81cd44:	mov    0x8(%rbx),%rax
  81cd48:	lock decq (%rax)
  81cd4c:	jne    81cd58 <<gpui_gpu::renderer::Buffer>::write+0xa8>
  81cd4e:	lea    0x8(%rbx),%rdi
  81cd52:	call   *0x662e80(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  81cd58:	mov    0x28(%rsp),%rax
  81cd5d:	mov    %rax,0x20(%rbx)
  81cd61:	movups 0x8(%rsp),%xmm0
  81cd66:	movups 0x18(%rsp),%xmm1
  81cd6b:	movups %xmm1,0x10(%rbx)
  81cd6f:	movups %xmm0,(%rbx)
  81cd72:	mov    %r12,%r8
  81cd75:	mov    %r15,%rcx
  81cd78:	jmp    81cd7f <<gpui_gpu::renderer::Buffer>::write+0xcf>
  81cd7a:	test   %r8,%r8
  81cd7d:	je     81cd8d <<gpui_gpu::renderer::Buffer>::write+0xdd>
  81cd7f:	mov    %r14,%rdi
  81cd82:	mov    %rbx,%rsi
  81cd85:	xor    %edx,%edx
  81cd87:	call   *0x662f0b(%rip)        # e7fc98 <_DYNAMIC+0x5d0>
  81cd8d:	add    $0x50,%rsp
  81cd91:	pop    %rbx
  81cd92:	pop    %r12
  81cd94:	pop    %r13
  81cd96:	pop    %r14
  81cd98:	pop    %r15
  81cd9a:	ret
  81cd9b:	mov    %rax,%r14
  81cd9e:	jmp    81cdb7 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cda0:	mov    %rax,%r14
  81cda3:	mov    0x8(%rbx),%rax
  81cda7:	lock decq (%rax)
  81cdab:	jne    81cdb7 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cdad:	lea    0x8(%rbx),%rdi
  81cdb1:	call   *0x662e21(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  81cdb7:	mov    0x28(%rsp),%rax
  81cdbc:	mov    %rax,0x20(%rbx)
  81cdc0:	movups 0x8(%rsp),%xmm0
  81cdc5:	movups 0x18(%rsp),%xmm1
  81cdca:	movups %xmm1,0x10(%rbx)
  81cdce:	movups %xmm0,(%rbx)
  81cdd1:	mov    %r14,%rdi
  81cdd4:	call   e2c4b0 <_Unwind_Resume@plt>
  81cdd9:	call   *0x662b39(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cde0 <<gpui_gpu::renderer::Atlas>::new>:
  81cde0:	push   %rbp
  81cde1:	push   %r14
  81cde3:	push   %rbx
  81cde4:	sub    $0x160,%rsp
  81cdeb:	mov    %edx,%ebp
  81cded:	mov    %rdi,%rbx
  81cdf0:	lea    -0x747e6a(%rip),%rax        # d4f8d <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x167>
  81cdf7:	mov    %rax,(%rsp)
  81cdfb:	movq   $0xe,0x8(%rsp)
  81ce04:	mov    %edx,0x10(%rsp)
  81ce08:	mov    %edx,0x14(%rsp)
  81ce0c:	movaps -0x770923(%rip),%xmm0        # ac4f0 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81ce13:	movups %xmm0,0x18(%rsp)
  81ce18:	movl   $0x0,0x28(%rsp)
  81ce20:	movl   $0x6,0x34(%rsp)
  81ce28:	movq   $0x4,0x38(%rsp)
  81ce31:	movq   $0x0,0x40(%rsp)
  81ce3a:	lea    0x110(%rsp),%r14
  81ce42:	mov    %rsp,%rdx
  81ce45:	mov    %r14,%rdi
  81ce48:	call   *0x662d1a(%rip)        # e7fb68 <_DYNAMIC+0x4a0>
  81ce4e:	movq   $0x0,0x18(%rsp)
  81ce57:	movl   $0xffffffff,0x30(%rsp)
  81ce5f:	movl   $0x0,(%rsp)
  81ce66:	movabs $0xffffffff00000000,%rax
  81ce70:	mov    %rax,0x28(%rsp)
  81ce75:	movq   $0x0,0x3c(%rsp)
  81ce7e:	movl   $0x0,0x8(%rsp)
  81ce86:	movl   $0x0,0x10(%rsp)
  81ce8e:	lea    0xb8(%rsp),%rdi
  81ce96:	mov    %rsp,%rdx
  81ce99:	mov    %r14,%rsi
  81ce9c:	call   *0x662cce(%rip)        # e7fb70 <_DYNAMIC+0x4a8>
  81cea2:	movups 0x150(%rsp),%xmm0
  81ceaa:	movaps %xmm0,0xa0(%rsp)
  81ceb2:	movups 0x110(%rsp),%xmm0
  81ceba:	movups 0x120(%rsp),%xmm1
  81cec2:	movups 0x130(%rsp),%xmm2
  81ceca:	movups 0x140(%rsp),%xmm3
  81ced2:	movaps %xmm3,0x90(%rsp)
  81ceda:	movaps %xmm2,0x80(%rsp)
  81cee2:	movaps %xmm1,0x70(%rsp)
  81cee7:	movaps %xmm0,0x60(%rsp)
  81ceec:	mov    0x108(%rsp),%rax
  81cef4:	mov    %rax,0x50(%rsp)
  81cef9:	movups 0xf8(%rsp),%xmm0
  81cf01:	movaps %xmm0,0x40(%rsp)
  81cf06:	movups 0xb8(%rsp),%xmm0
  81cf0e:	movups 0xc8(%rsp),%xmm1
  81cf16:	movups 0xd8(%rsp),%xmm2
  81cf1e:	movups 0xe8(%rsp),%xmm3
  81cf26:	movaps %xmm3,0x30(%rsp)
  81cf2b:	movaps %xmm2,0x20(%rsp)
  81cf30:	movaps %xmm1,0x10(%rsp)
  81cf35:	movaps %xmm0,(%rsp)
  81cf39:	mov    %fs:0x0,%rax
  81cf42:	lea    -0x28(%rax),%rax
  81cf49:	mov    %rax,%r14
  81cf4c:	cmpb   $0x1,0x10(%rax)
  81cf50:	jne    81d03b <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81cf56:	mov    (%r14),%rax
  81cf59:	mov    0x8(%r14),%rdx
  81cf5d:	lea    0x1(%rax),%rcx
  81cf61:	mov    %rcx,(%r14)
  81cf64:	movaps 0xa0(%rsp),%xmm0
  81cf6c:	movups %xmm0,0x40(%rbx)
  81cf70:	movaps 0x60(%rsp),%xmm0
  81cf75:	movaps 0x70(%rsp),%xmm1
  81cf7a:	movaps 0x80(%rsp),%xmm2
  81cf82:	movaps 0x90(%rsp),%xmm3
  81cf8a:	movups %xmm3,0x30(%rbx)
  81cf8e:	movups %xmm2,0x20(%rbx)
  81cf92:	movups %xmm1,0x10(%rbx)
  81cf96:	movups %xmm0,(%rbx)
  81cf99:	movups 0xb8(%rsp),%xmm0
  81cfa1:	movups 0xc8(%rsp),%xmm1
  81cfa9:	movups 0xd8(%rsp),%xmm2
  81cfb1:	movups 0xe8(%rsp),%xmm3
  81cfb9:	movups %xmm0,0x50(%rbx)
  81cfbd:	movups %xmm1,0x60(%rbx)
  81cfc1:	movups %xmm2,0x70(%rbx)
  81cfc5:	movups %xmm3,0x80(%rbx)
  81cfcc:	movups 0xf8(%rsp),%xmm0
  81cfd4:	movups %xmm0,0x90(%rbx)
  81cfdb:	mov    0x108(%rsp),%rcx
  81cfe3:	mov    %rcx,0xa0(%rbx)
  81cfea:	mov    %ebp,0xd8(%rbx)
  81cff0:	movq   $0x0,0xdc(%rbx)
  81cffb:	movl   $0x0,0xe4(%rbx)
  81d005:	movups 0x61127c(%rip),%xmm0        # e2e288 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  81d00c:	movups %xmm0,0xa8(%rbx)
  81d013:	movups 0x61127e(%rip),%xmm0        # e2e298 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf0>
  81d01a:	movups %xmm0,0xb8(%rbx)
  81d021:	mov    %rax,0xc8(%rbx)
  81d028:	mov    %rdx,0xd0(%rbx)
  81d02f:	add    $0x160,%rsp
  81d036:	pop    %rbx
  81d037:	pop    %r14
  81d039:	pop    %rbp
  81d03a:	ret
  81d03b:	call   *0x662ca7(%rip)        # e7fce8 <_DYNAMIC+0x620>
  81d041:	mov    %rax,(%r14)
  81d044:	mov    %rdx,0x8(%r14)
  81d048:	movb   $0x1,0x10(%r14)
  81d04d:	jmp    81cf5d <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81d052:	mov    %rax,%rbx
  81d055:	mov    %rsp,%rdi
  81d058:	call   81c520 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81d05d:	mov    0x60(%rsp),%rax
  81d062:	lock decq (%rax)
  81d066:	jne    81d094 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81d068:	lea    0x60(%rsp),%rdi
  81d06d:	call   *0x662b3d(%rip)        # e7fbb0 <_DYNAMIC+0x4e8>
  81d073:	jmp    81d094 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81d075:	mov    %rax,%rbx
  81d078:	mov    0x110(%rsp),%rax
  81d080:	lock decq (%rax)
  81d084:	jne    81d094 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81d086:	lea    0x110(%rsp),%rdi
  81d08e:	call   *0x662b1c(%rip)        # e7fbb0 <_DYNAMIC+0x4e8>
  81d094:	mov    %rbx,%rdi
  81d097:	call   e2c4b0 <_Unwind_Resume@plt>
  81d09c:	call   *0x662876(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d0b0 <<gpui_gpu::renderer::Atlas>::insert>:
  81d0b0:	push   %rbp
  81d0b1:	push   %r15
  81d0b3:	push   %r14
  81d0b5:	push   %r13
  81d0b7:	push   %r12
  81d0b9:	push   %rbx
  81d0ba:	sub    $0x68,%rsp
  81d0be:	mov    %rdx,%r12
  81d0c1:	mov    %rsi,%r15
  81d0c4:	mov    %rdi,%r14
  81d0c7:	lea    0x10(%rdx),%r13
  81d0cb:	cmpq   $0x0,0xc0(%rdi)
  81d0d3:	je     81d19b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d0d9:	lea    0xc8(%r14),%rdi
  81d0e0:	mov    %r13,%rsi
  81d0e3:	call   821e80 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81d0e8:	mov    %rax,%rsi
  81d0eb:	shr    $0x39,%rsi
  81d0ef:	mov    0xa8(%r14),%rcx
  81d0f6:	mov    0xb0(%r14),%rdx
  81d0fd:	movd   %esi,%xmm0
  81d101:	punpcklbw %xmm0,%xmm0
  81d105:	pshuflw $0x0,%xmm0,%xmm0
  81d10a:	pshufd $0x44,%xmm0,%xmm0
  81d10f:	mov    0x10(%r12),%rsi
  81d114:	movzwl 0x1c(%r12),%edi
  81d11a:	mov    0x18(%r12),%r8d
  81d11f:	pcmpeqd %xmm1,%xmm1
  81d123:	xor    %r9d,%r9d
  81d126:	and    %rdx,%rax
  81d129:	movdqu (%rcx,%rax,1),%xmm2
  81d12e:	movdqa %xmm2,%xmm3
  81d132:	pcmpeqb %xmm0,%xmm3
  81d136:	pmovmskb %xmm3,%r10d
  81d13b:	test   %r10d,%r10d
  81d13e:	je     81d180 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81d140:	tzcnt  %r10d,%ebx
  81d145:	add    %rax,%rbx
  81d148:	and    %rdx,%rbx
  81d14b:	shl    $0x5,%rbx
  81d14f:	mov    %rcx,%r11
  81d152:	sub    %rbx,%r11
  81d155:	cmp    -0x20(%r11),%rsi
  81d159:	jne    81d16c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d15b:	cmp    -0x14(%r11),%di
  81d160:	jne    81d16c <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d162:	cmp    -0x18(%r11),%r8d
  81d166:	je     81d203 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d16c:	lea    -0x1(%r10),%r11d
  81d170:	and    %r10w,%r11w
  81d174:	mov    %r11d,%r10d
  81d177:	jne    81d140 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d179:	nopl   0x0(%rax)
  81d180:	pcmpeqb %xmm1,%xmm2
  81d184:	pmovmskb %xmm2,%r10d
  81d189:	test   %r10d,%r10d
  81d18c:	jne    81d19b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d18e:	add    %r9,%rax
  81d191:	add    $0x10,%rax
  81d195:	add    $0x10,%r9
  81d199:	jmp    81d126 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d19b:	mov    0x20(%r12),%ebp
  81d1a0:	xor    %eax,%eax
  81d1a2:	test   %ebp,%ebp
  81d1a4:	je     81d1fe <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d1a6:	mov    %r15,%rdi
  81d1a9:	mov    0x28(%r12),%r15d
  81d1ae:	test   %r15d,%r15d
  81d1b1:	je     81d1fe <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d1b3:	mov    0xd8(%r14),%ecx
  81d1ba:	cmp    %ebp,%ecx
  81d1bc:	jb     81d301 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d1c2:	cmp    %r15d,%ecx
  81d1c5:	jb     81d301 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d1cb:	mov    %r13,0x40(%rsp)
  81d1d0:	mov    0xdc(%r14),%r8d
  81d1d7:	mov    0xe4(%r14),%r13d
  81d1de:	lea    (%r8,%rbp,1),%edx
  81d1e2:	xor    %eax,%eax
  81d1e4:	cmp    %ecx,%edx
  81d1e6:	mov    $0x0,%ebx
  81d1eb:	cmova  %r13d,%ebx
  81d1ef:	add    0xe0(%r14),%ebx
  81d1f6:	lea    (%rbx,%r15,1),%esi
  81d1fa:	cmp    %ecx,%esi
  81d1fc:	jbe    81d20f <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d1fe:	jmp    81d301 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d203:	mov    $0x1,%eax
  81d208:	xor    %edx,%edx
  81d20a:	jmp    81d301 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d20f:	cmp    %r13d,%r15d
  81d212:	cmova  %r15d,%r13d
  81d216:	cmp    %ecx,%edx
  81d218:	cmova  %eax,%r8d
  81d21c:	lea    0xa8(%r14),%rax
  81d223:	mov    %rax,0x38(%rsp)
  81d228:	mov    %r14,0x48(%rsp)
  81d22d:	movl   $0x0,0x50(%rsp)
  81d235:	mov    %r8d,0x54(%rsp)
  81d23a:	mov    %ebx,0x58(%rsp)
  81d23e:	movq   $0x0,0x5c(%rsp)
  81d247:	mov    (%r12),%rdx
  81d24b:	mov    0x8(%r12),%rcx
  81d250:	mov    %rcx,0x30(%rsp)
  81d255:	movq   $0x0,0x8(%rsp)
  81d25e:	movl   $0x1,0x10(%rsp)
  81d266:	mov    %ebp,0x14(%rsp)
  81d26a:	movl   $0x1,0x18(%rsp)
  81d272:	mov    %r15d,0x1c(%rsp)
  81d277:	mov    %ebp,0x20(%rsp)
  81d27b:	mov    %r15d,0x24(%rsp)
  81d280:	movl   $0x1,0x28(%rsp)
  81d288:	cmova  %r15d,%r13d
  81d28c:	lea    0x48(%rsp),%rsi
  81d291:	mov    %r8,%r12
  81d294:	lea    0x8(%rsp),%r8
  81d299:	lea    0x20(%rsp),%r9
  81d29e:	call   *0x662a4c(%rip)        # e7fcf0 <_DYNAMIC+0x628>
  81d2a4:	lea    (%r12,%rbp,1),%eax
  81d2a8:	mov    %eax,0xdc(%r14)
  81d2af:	mov    %ebx,0xe0(%r14)
  81d2b6:	mov    %r13d,0xe4(%r14)
  81d2bd:	mov    0x40(%rsp),%rax
  81d2c2:	movdqu (%rax),%xmm0
  81d2c6:	movdqa %xmm0,0x20(%rsp)
  81d2cc:	mov    %r12d,0x8(%rsp)
  81d2d1:	mov    %ebx,0xc(%rsp)
  81d2d5:	mov    %ebp,0x10(%rsp)
  81d2d9:	mov    %r15d,0x14(%rsp)
  81d2de:	lea    0x48(%rsp),%rdi
  81d2e3:	lea    0x20(%rsp),%rdx
  81d2e8:	lea    0x8(%rsp),%rcx
  81d2ed:	mov    0x38(%rsp),%rsi
  81d2f2:	call   8236b0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d2f7:	mov    0x30(%rsp),%rdx
  81d2fc:	mov    $0x1,%eax
  81d301:	add    $0x68,%rsp
  81d305:	pop    %rbx
  81d306:	pop    %r12
  81d308:	pop    %r13
  81d30a:	pop    %r14
  81d30c:	pop    %r15
  81d30e:	pop    %rbp
  81d30f:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d310 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d310:	push   %r15
  81d312:	push   %r14
  81d314:	push   %r12
  81d316:	push   %rbx
  81d317:	sub    $0x548,%rsp
  81d31e:	mov    %rdx,%r14
  81d321:	mov    %rsi,%r12
  81d324:	mov    %rdi,%rbx
  81d327:	lea    0x61100a(%rip),%rdx        # e2e338 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.12798218693442382726>
  81d32e:	lea    0x30(%rsp),%r15
  81d333:	mov    %r15,%rdi
  81d336:	mov    %rbx,%rsi
  81d339:	call   *0x6629b9(%rip)        # e7fcf8 <_DYNAMIC+0x630>
  81d33f:	xorps  %xmm0,%xmm0
  81d342:	movups %xmm0,0x10(%rsp)
  81d347:	movups %xmm0,0x20(%rsp)
  81d34c:	movl   $0x0,0x50(%rsp)
  81d354:	movb   $0x0,0x58(%rsp)
  81d359:	movups 0x9(%rsp),%xmm0
  81d35e:	movups %xmm0,0x59(%rsp)
  81d363:	movups 0x19(%rsp),%xmm0
  81d368:	movups %xmm0,0x69(%rsp)
  81d36d:	mov    0x28(%rsp),%rax
  81d372:	mov    %rax,0x78(%rsp)
  81d377:	movl   $0x0,0x80(%rsp)
  81d382:	mov    %r12,0x88(%rsp)
  81d38a:	movq   $0x0,0x90(%rsp)
  81d396:	lea    -0x748402(%rip),%rax        # d4f9b <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.12798218693442382726>
  81d39d:	mov    %rax,0xe0(%rsp)
  81d3a5:	movq   $0xa,0xe8(%rsp)
  81d3b1:	lea    0x50(%rsp),%rax
  81d3b6:	mov    %rax,0xd0(%rsp)
  81d3be:	movq   $0x1,0xd8(%rsp)
  81d3ca:	movl   $0xffffffff,0xb8(%rsp)
  81d3d5:	movl   $0x2,0x98(%rsp)
  81d3e0:	movq   $0x0,0xf0(%rsp)
  81d3ec:	movl   $0x0,0xf8(%rsp)
  81d3f7:	lea    0x100(%rsp),%rdi
  81d3ff:	lea    0x98(%rsp),%rdx
  81d407:	mov    %r15,%rsi
  81d40a:	call   *0x6628f0(%rip)        # e7fd00 <_DYNAMIC+0x638>
  81d410:	lea    0x10(%rbx),%rsi
  81d414:	lea    0x100(%rsp),%rdi
  81d41c:	call   *0x6628e6(%rip)        # e7fd08 <_DYNAMIC+0x640>
  81d422:	lea    0x100(%rsp),%rdi
  81d42a:	mov    $0x4,%ecx
  81d42f:	xor    %esi,%esi
  81d431:	mov    %r14,%rdx
  81d434:	xor    %r8d,%r8d
  81d437:	call   *0x6628d3(%rip)        # e7fd10 <_DYNAMIC+0x648>
  81d43d:	lea    0x100(%rsp),%rdi
  81d445:	xor    %esi,%esi
  81d447:	mov    $0x3,%edx
  81d44c:	xor    %ecx,%ecx
  81d44e:	mov    $0x1,%r8d
  81d454:	call   *0x6628be(%rip)        # e7fd18 <_DYNAMIC+0x650>
  81d45a:	lea    0x100(%rsp),%rdi
  81d462:	call   81c420 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d467:	movups 0x30(%rsp),%xmm0
  81d46c:	movups 0x40(%rsp),%xmm1
  81d471:	movaps %xmm1,0x110(%rsp)
  81d479:	movaps %xmm0,0x100(%rsp)
  81d481:	lea    0x98(%rsp),%r14
  81d489:	lea    0x100(%rsp),%rsi
  81d491:	mov    %r14,%rdi
  81d494:	call   *0x662886(%rip)        # e7fd20 <_DYNAMIC+0x658>
  81d49a:	add    $0x8,%rbx
  81d49e:	mov    %rbx,%rdi
  81d4a1:	mov    %r14,%rsi
  81d4a4:	call   8255e0 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d4a9:	add    $0x548,%rsp
  81d4b0:	pop    %rbx
  81d4b1:	pop    %r12
  81d4b3:	pop    %r14
  81d4b5:	pop    %r15
  81d4b7:	ret
  81d4b8:	mov    %rax,%rbx
  81d4bb:	jmp    81d4cd <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d4bd:	mov    %rax,%rbx
  81d4c0:	lea    0x100(%rsp),%rdi
  81d4c8:	call   81c420 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d4cd:	lea    0x30(%rsp),%rdi
  81d4d2:	call   81c590 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d4d7:	mov    %rbx,%rdi
  81d4da:	call   e2c4b0 <_Unwind_Resume@plt>
  81d4df:	call   *0x662433(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d4f0 <<gpui_gpu::renderer::RendererState>::correction>:
  81d4f0:	push   %r15
  81d4f2:	push   %r14
  81d4f4:	push   %r13
  81d4f6:	push   %r12
  81d4f8:	push   %rbx
  81d4f9:	sub    $0x90,%rsp
  81d500:	mov    %rdi,%rbx
  81d503:	movss  (%rdx),%xmm1
  81d507:	movss  0x8(%rdx),%xmm2
  81d50c:	movaps %xmm1,%xmm0
  81d50f:	addss  %xmm2,%xmm0
  81d513:	movd   %xmm0,%eax
  81d517:	and    $0x7fffffff,%eax
  81d51c:	xorps  %xmm8,%xmm8
  81d520:	xorps  %xmm9,%xmm9
  81d524:	cmp    $0x7f7fffff,%eax
  81d529:	jg     81d548 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d52b:	cvtss2sd %xmm1,%xmm1
  81d52f:	cvtss2sd %xmm2,%xmm2
  81d533:	cvtss2sd %xmm0,%xmm0
  81d537:	addsd  %xmm1,%xmm2
  81d53b:	subsd  %xmm0,%xmm2
  81d53f:	xorps  %xmm9,%xmm9
  81d543:	cvtsd2ss %xmm2,%xmm9
  81d548:	movupd (%rsi),%xmm0
  81d54c:	movupd 0x8(%rsi),%xmm1
  81d551:	movsd  0x10(%rsi),%xmm2
  81d556:	movsd  0x18(%rsi),%xmm3
  81d55b:	movupd 0x20(%rsi),%xmm4
  81d560:	movss  0x4(%rdx),%xmm6
  81d565:	movss  0xc(%rdx),%xmm7
  81d56a:	movaps %xmm6,%xmm5
  81d56d:	addss  %xmm7,%xmm5
  81d571:	movd   %xmm5,%eax
  81d575:	and    $0x7fffffff,%eax
  81d57a:	cmp    $0x7f7fffff,%eax
  81d57f:	jg     81d59e <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d581:	cvtss2sd %xmm6,%xmm6
  81d585:	cvtss2sd %xmm7,%xmm7
  81d589:	cvtss2sd %xmm5,%xmm5
  81d58d:	addsd  %xmm6,%xmm7
  81d591:	subsd  %xmm5,%xmm7
  81d595:	xorps  %xmm8,%xmm8
  81d599:	cvtsd2ss %xmm7,%xmm8
  81d59e:	cvtpd2ps %xmm4,%xmm5
  81d5a2:	cvtps2pd %xmm5,%xmm5
  81d5a5:	subpd  %xmm5,%xmm4
  81d5a9:	cvtpd2ps %xmm4,%xmm4
  81d5ad:	unpcklpd %xmm3,%xmm1
  81d5b1:	cvtpd2ps %xmm1,%xmm3
  81d5b5:	unpcklpd %xmm2,%xmm0
  81d5b9:	cvtpd2ps %xmm0,%xmm2
  81d5bd:	cvtps2pd %xmm3,%xmm3
  81d5c0:	subpd  %xmm3,%xmm1
  81d5c4:	cvtpd2ps %xmm1,%xmm5
  81d5c8:	cvtps2pd %xmm2,%xmm1
  81d5cb:	subpd  %xmm1,%xmm0
  81d5cf:	cvtpd2ps %xmm0,%xmm6
  81d5d3:	movapd %xmm6,%xmm0
  81d5d7:	unpcklps %xmm5,%xmm0
  81d5da:	movaps %xmm8,%xmm1
  81d5de:	movlhps %xmm9,%xmm1
  81d5e2:	movapd %xmm4,%xmm2
  81d5e6:	shufps $0x24,%xmm1,%xmm2
  81d5ea:	xorps  %xmm1,%xmm1
  81d5ed:	movapd %xmm0,%xmm3
  81d5f1:	cmpneqps %xmm1,%xmm3
  81d5f5:	cmpneqps %xmm1,%xmm2
  81d5f9:	packssdw %xmm2,%xmm3
  81d5fd:	pmovmskb %xmm3,%eax
  81d601:	test   %eax,%eax
  81d603:	je     81d727 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d609:	movapd %xmm6,0x60(%rsp)
  81d60f:	movapd %xmm5,0x70(%rsp)
  81d615:	lea    0x8(%rsp),%r12
  81d61a:	movapd %xmm0,(%rsp)
  81d61f:	movapd %xmm4,0x80(%rsp)
  81d628:	movlpd %xmm4,0x10(%rsp)
  81d62e:	movss  %xmm9,0x18(%rsp)
  81d635:	movss  %xmm8,0x1c(%rsp)
  81d63c:	lea    0x300(%rbx),%r14
  81d643:	mov    %rsp,%rsi
  81d646:	mov    %r14,%rdi
  81d649:	movaps %xmm8,0x30(%rsp)
  81d64f:	movaps %xmm9,0x20(%rsp)
  81d655:	call   821d00 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d65a:	movapd 0x20(%rsp),%xmm6
  81d660:	movapd 0x30(%rsp),%xmm5
  81d666:	mov    %rax,%r15
  81d669:	shr    $0x39,%r15
  81d66d:	mov    0x2e0(%rbx),%rcx
  81d674:	mov    0x2e8(%rbx),%rdx
  81d67b:	movd   %r15d,%xmm0
  81d680:	punpcklbw %xmm0,%xmm0
  81d684:	pshuflw $0x0,%xmm0,%xmm0
  81d689:	pshufd $0x44,%xmm0,%xmm0
  81d68e:	xor    %esi,%esi
  81d690:	pcmpeqd %xmm1,%xmm1
  81d694:	mov    %rax,%rdi
  81d697:	and    %rdx,%rdi
  81d69a:	movdqu (%rcx,%rdi,1),%xmm2
  81d69f:	movdqa %xmm2,%xmm3
  81d6a3:	pcmpeqb %xmm0,%xmm3
  81d6a7:	pmovmskb %xmm3,%r8d
  81d6ac:	test   %r8d,%r8d
  81d6af:	je     81d700 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d6b1:	tzcnt  %r8d,%r9d
  81d6b6:	add    %rdi,%r9
  81d6b9:	and    %rdx,%r9
  81d6bc:	neg    %r9
  81d6bf:	lea    (%r9,%r9,8),%r9
  81d6c3:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d6ca:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d6d1:	pcmpeqb 0x10(%rsp),%xmm4
  81d6d7:	pcmpeqb (%rsp),%xmm3
  81d6dc:	pand   %xmm4,%xmm3
  81d6e0:	pmovmskb %xmm3,%r10d
  81d6e5:	cmp    $0xffff,%r10d
  81d6ec:	je     81d71e <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d6ee:	lea    -0x1(%r8),%r9d
  81d6f2:	and    %r8w,%r9w
  81d6f6:	mov    %r9d,%r8d
  81d6f9:	jne    81d6b1 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d6fb:	nopl   0x0(%rax,%rax,1)
  81d700:	pcmpeqb %xmm1,%xmm2
  81d704:	pmovmskb %xmm2,%r8d
  81d709:	test   %r8d,%r8d
  81d70c:	jne    81d72e <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d70e:	add    %rsi,%rdi
  81d711:	add    $0x10,%rdi
  81d715:	add    $0x10,%rsi
  81d719:	jmp    81d697 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d71e:	lea    (%rcx,%r9,4),%rdx
  81d722:	jmp    81d849 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d727:	xor    %eax,%eax
  81d729:	jmp    81d84c <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d72e:	cmpq   $0x0,0x2f0(%rbx)
  81d736:	je     81d87f <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d73c:	mov    (%rsp),%r14
  81d740:	mov    0x10(%r12),%rcx
  81d745:	mov    %rcx,0x50(%rsp)
  81d74a:	movups (%r12),%xmm0
  81d74f:	movaps %xmm0,0x40(%rsp)
  81d754:	mov    0x58(%rbx),%r12
  81d758:	cmp    0x48(%rbx),%r12
  81d75c:	jne    81d77a <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d75e:	lea    0x48(%rbx),%rdi
  81d762:	mov    %rax,%r13
  81d765:	call   *0x66250d(%rip)        # e7fc78 <_DYNAMIC+0x5b0>
  81d76b:	movapd 0x20(%rsp),%xmm6
  81d771:	movapd 0x30(%rsp),%xmm5
  81d777:	mov    %r13,%rax
  81d77a:	mov    0x50(%rbx),%rcx
  81d77e:	mov    %r12,%rdx
  81d781:	shl    $0x5,%rdx
  81d785:	movaps 0x60(%rsp),%xmm0
  81d78a:	movlps %xmm0,(%rcx,%rdx,1)
  81d78e:	movaps 0x80(%rsp),%xmm0
  81d796:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d79c:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d7a2:	movdqa 0x70(%rsp),%xmm1
  81d7a8:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d7ae:	shufps $0x55,%xmm0,%xmm0
  81d7b2:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d7b8:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d7be:	lea    0x1(%r12),%rcx
  81d7c3:	mov    %rcx,0x58(%rbx)
  81d7c7:	mov    0x2e0(%rbx),%rcx
  81d7ce:	mov    0x2e8(%rbx),%rdx
  81d7d5:	and    %rdx,%rax
  81d7d8:	movdqu (%rcx,%rax,1),%xmm0
  81d7dd:	pmovmskb %xmm0,%esi
  81d7e1:	test   %esi,%esi
  81d7e3:	je     81d85d <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d7e5:	tzcnt  %esi,%esi
  81d7e9:	add    %rax,%rsi
  81d7ec:	and    %rdx,%rsi
  81d7ef:	movzbl (%rcx,%rsi,1),%eax
  81d7f3:	test   %al,%al
  81d7f5:	jns    81d8b0 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d7fb:	lea    -0x10(%rsi),%rdi
  81d7ff:	and    %rdx,%rdi
  81d802:	mov    %r15b,(%rcx,%rsi,1)
  81d806:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d80b:	neg    %rsi
  81d80e:	lea    (%rsi,%rsi,8),%rsi
  81d812:	lea    (%rcx,%rsi,4),%rdx
  81d816:	and    $0x1,%al
  81d818:	movzbl %al,%eax
  81d81b:	sub    %rax,0x2f0(%rbx)
  81d822:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d827:	movdqa 0x40(%rsp),%xmm0
  81d82d:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d833:	mov    0x50(%rsp),%rax
  81d838:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d83d:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d842:	incq   0x2f8(%rbx)
  81d849:	mov    -0x4(%rdx),%eax
  81d84c:	add    $0x90,%rsp
  81d853:	pop    %rbx
  81d854:	pop    %r12
  81d856:	pop    %r13
  81d858:	pop    %r14
  81d85a:	pop    %r15
  81d85c:	ret
  81d85d:	mov    $0x10,%edi
  81d862:	add    %rdi,%rax
  81d865:	and    %rdx,%rax
  81d868:	movdqu (%rcx,%rax,1),%xmm0
  81d86d:	pmovmskb %xmm0,%esi
  81d871:	add    $0x10,%rdi
  81d875:	test   %esi,%esi
  81d877:	jne    81d7e5 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d87d:	jmp    81d862 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d87f:	lea    0x2e0(%rbx),%rdi
  81d886:	mov    $0x1,%esi
  81d88b:	mov    %r14,%rdx
  81d88e:	mov    $0x1,%ecx
  81d893:	mov    %rax,%r14
  81d896:	call   *0x66248c(%rip)        # e7fd28 <_DYNAMIC+0x660>
  81d89c:	movapd 0x20(%rsp),%xmm6
  81d8a2:	movapd 0x30(%rsp),%xmm5
  81d8a8:	mov    %r14,%rax
  81d8ab:	jmp    81d73c <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d8b0:	movdqa (%rcx),%xmm0
  81d8b4:	pmovmskb %xmm0,%eax
  81d8b8:	tzcnt  %eax,%esi
  81d8bc:	movzbl (%rcx,%rsi,1),%eax
  81d8c0:	jmp    81d7fb <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d8d0 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d8d0:	push   %rbp
  81d8d1:	push   %r15
  81d8d3:	push   %r14
  81d8d5:	push   %r13
  81d8d7:	push   %r12
  81d8d9:	push   %rbx
  81d8da:	sub    $0x228,%rsp
  81d8e1:	mov    %rsi,%r14
  81d8e4:	test   %r8d,%r8d
  81d8e7:	je     81d97b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d8ed:	mov    %rdi,0x10(%rsp)
  81d8f2:	mov    0x110(%rcx),%rbp
  81d8f9:	test   %rbp,%rbp
  81d8fc:	je     81d9df <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d902:	mov    0x108(%rcx),%r13
  81d909:	shl    $0x3,%rbp
  81d90d:	mov    %r14,0x8(%rsp)
  81d912:	lea    0x60(%r14),%rdi
  81d916:	mov    %rdx,0x18(%rsp)
  81d91b:	lea    0x8(%rdx),%rax
  81d91f:	mov    %rax,0x20(%rsp)
  81d924:	xor    %ebx,%ebx
  81d926:	lea    0x28(%rsp),%r15
  81d92b:	xor    %r12d,%r12d
  81d92e:	xchg   %ax,%ax
  81d930:	mov    0x0(%r13,%r12,1),%rax
  81d935:	movups 0x28(%rax),%xmm0
  81d939:	lea    0x38(%rsp),%rcx
  81d93e:	movups %xmm0,(%rcx)
  81d941:	movups 0x18(%rax),%xmm0
  81d945:	movups %xmm0,0x28(%rsp)
  81d94a:	movups 0x38(%rax),%xmm0
  81d94e:	movups %xmm0,0x48(%rsp)
  81d953:	mov    %rdi,%r14
  81d956:	mov    0x20(%rsp),%rsi
  81d95b:	mov    %r15,%rdx
  81d95e:	call   81d0b0 <<gpui_gpu::renderer::Atlas>::insert>
  81d963:	test   $0x1,%al
  81d965:	je     81d9e6 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d967:	add    %rdx,%rbx
  81d96a:	add    $0x8,%r12
  81d96e:	cmp    %r12,%rbp
  81d971:	mov    %r14,%rdi
  81d974:	jne    81d930 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d976:	jmp    81daee <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d97b:	cmpl   $0x1,0x138(%r14)
  81d983:	jne    81d995 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d985:	mov    0x120(%r14),%rax
  81d98c:	add    0x118(%r14),%rax
  81d993:	je     81d9cc <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d995:	mov    %rdi,%rbx
  81d998:	add    $0x60,%r14
  81d99c:	lea    0x58(%rsp),%rdi
  81d9a1:	mov    %rdx,%rsi
  81d9a4:	mov    $0x1,%edx
  81d9a9:	call   81cde0 <<gpui_gpu::renderer::Atlas>::new>
  81d9ae:	mov    %r14,%rdi
  81d9b1:	call   81bbd0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9b6:	lea    0x58(%rsp),%rsi
  81d9bb:	mov    $0xe8,%edx
  81d9c0:	mov    %r14,%rdi
  81d9c3:	call   *0x661f9f(%rip)        # e7f968 <memcpy@GLIBC_2.14>
  81d9c9:	mov    %rbx,%rdi
  81d9cc:	movq   $0x0,0x8(%rdi)
  81d9d4:	movl   $0xffffffff,(%rdi)
  81d9da:	jmp    81dafd <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d9df:	xor    %ebx,%ebx
  81d9e1:	jmp    81daee <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d9e6:	mov    0x8(%rsp),%rax
  81d9eb:	mov    0x138(%rax),%eax
  81d9f1:	cmp    $0x81,%eax
  81d9f6:	mov    $0x80,%edx
  81d9fb:	cmovae %eax,%edx
  81d9fe:	add    %edx,%edx
  81da00:	cmp    $0x800,%edx
  81da06:	mov    $0x800,%eax
  81da0b:	cmovae %eax,%edx
  81da0e:	lea    0x140(%rsp),%r12
  81da16:	mov    %r12,%rdi
  81da19:	mov    0x18(%rsp),%rsi
  81da1e:	mov    %edx,0x8(%rsp)
  81da22:	call   81cde0 <<gpui_gpu::renderer::Atlas>::new>
  81da27:	xor    %r15d,%r15d
  81da2a:	nopw   0x0(%rax,%rax,1)
  81da30:	mov    0x0(%r13,%r15,1),%rax
  81da35:	movups 0x28(%rax),%xmm0
  81da39:	lea    0x68(%rsp),%rcx
  81da3e:	movups %xmm0,(%rcx)
  81da41:	movups 0x18(%rax),%xmm0
  81da45:	movups %xmm0,0x58(%rsp)
  81da4a:	movups 0x38(%rax),%xmm0
  81da4e:	movups %xmm0,0x78(%rsp)
  81da53:	mov    %r12,%rdi
  81da56:	mov    0x20(%rsp),%rsi
  81da5b:	lea    0x58(%rsp),%rdx
  81da60:	call   81d0b0 <<gpui_gpu::renderer::Atlas>::insert>
  81da65:	cmp    $0x1,%rax
  81da69:	jne    81da79 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81da6b:	add    %rdx,%rbx
  81da6e:	add    $0x8,%r15
  81da72:	cmp    %r15,%rbp
  81da75:	jne    81da30 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81da77:	jmp    81dabb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81da79:	mov    0x8(%rsp),%r15d
  81da7e:	cmp    $0x800,%r15d
  81da85:	je     81db0f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81da8b:	mov    %r12,%rdi
  81da8e:	call   81bbd0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da93:	add    %r15d,%r15d
  81da96:	cmp    $0x800,%r15d
  81da9d:	mov    $0x800,%eax
  81daa2:	cmovae %eax,%r15d
  81daa6:	mov    %r12,%rdi
  81daa9:	mov    0x18(%rsp),%rsi
  81daae:	mov    %r15d,0x8(%rsp)
  81dab3:	mov    %r15d,%edx
  81dab6:	jmp    81da22 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81dabb:	lea    0x58(%rsp),%rdi
  81dac0:	lea    0x140(%rsp),%rsi
  81dac8:	mov    $0xe8,%edx
  81dacd:	call   *0x661e95(%rip)        # e7f968 <memcpy@GLIBC_2.14>
  81dad3:	mov    %r14,%rdi
  81dad6:	call   81bbd0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81dadb:	lea    0x58(%rsp),%rsi
  81dae0:	mov    $0xe8,%edx
  81dae5:	mov    %r14,%rdi
  81dae8:	call   *0x661e7a(%rip)        # e7f968 <memcpy@GLIBC_2.14>
  81daee:	mov    0x10(%rsp),%rax
  81daf3:	mov    %rbx,0x8(%rax)
  81daf7:	movl   $0xffffffff,(%rax)
  81dafd:	add    $0x228,%rsp
  81db04:	pop    %rbx
  81db05:	pop    %r12
  81db07:	pop    %r13
  81db09:	pop    %r14
  81db0b:	pop    %r15
  81db0d:	pop    %rbp
  81db0e:	ret
  81db0f:	mov    0x10(%rsp),%rax
  81db14:	movl   $0x7,(%rax)
  81db1a:	lea    0x140(%rsp),%rdi
  81db22:	call   81bbd0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81db27:	jmp    81dafd <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81db29:	jmp    81db2b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81db2b:	mov    %rax,%rbx
  81db2e:	lea    0x58(%rsp),%rsi
  81db33:	mov    $0xe8,%edx
  81db38:	mov    %r14,%rdi
  81db3b:	call   *0x661e27(%rip)        # e7f968 <memcpy@GLIBC_2.14>
  81db41:	mov    %rbx,%rdi
  81db44:	call   e2c4b0 <_Unwind_Resume@plt>
  81db49:	mov    %rax,%rbx
  81db4c:	lea    0x140(%rsp),%rdi
  81db54:	call   81bbd0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81db59:	mov    %rbx,%rdi
  81db5c:	call   e2c4b0 <_Unwind_Resume@plt>
  81db61:	call   *0x661db1(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1500 frame=952

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081db70 <<gpui_gpu::renderer::RendererState>::new>:
  81db70:	push   %r15
  81db72:	push   %r14
  81db74:	push   %r13
  81db76:	push   %r12
  81db78:	push   %rbx
  81db79:	sub    $0x390,%rsp
  81db80:	mov    %rsi,%r14
  81db83:	mov    %rdi,%rbx
  81db86:	lea    -0x748be8(%rip),%rax        # d4fa5 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.12798218693442382726+0xa>
  81db8d:	mov    %rax,0xd8(%rsp)
  81db95:	movq   $0x7,0xe0(%rsp)
  81dba1:	movq   $0x30,0xe8(%rsp)
  81dbad:	movl   $0x48,0xf0(%rsp)
  81dbb8:	movb   $0x0,0xf4(%rsp)
  81dbc0:	mov    0x662119(%rip),%r15        # e7fce0 <_DYNAMIC+0x618>
  81dbc7:	lea    0x10(%rsp),%rdi
  81dbcc:	lea    0xd8(%rsp),%rdx
  81dbd4:	call   *%r15
  81dbd7:	movq   $0x30,0x30(%rsp)
  81dbe0:	lea    -0x748c3b(%rip),%rax        # d4fac <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.12798218693442382726+0x11>
  81dbe7:	mov    %rax,0xd8(%rsp)
  81dbef:	movq   $0x5,0xe0(%rsp)
  81dbfb:	movq   $0x10,0xe8(%rsp)
  81dc07:	movl   $0x88,0xf0(%rsp)
  81dc12:	movb   $0x0,0xf4(%rsp)
  81dc1a:	lea    0x38(%rsp),%rdi
  81dc1f:	lea    0xd8(%rsp),%rdx
  81dc27:	mov    %r14,%rsi
  81dc2a:	call   *%r15
  81dc2d:	movq   $0x10,0x58(%rsp)
  81dc36:	lea    -0x748c8c(%rip),%rax        # d4fb1 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.12798218693442382726+0x16>
  81dc3d:	mov    %rax,0xd8(%rsp)
  81dc45:	movq   $0x5,0xe0(%rsp)
  81dc51:	movq   $0x8,0xe8(%rsp)
  81dc5d:	movl   $0x88,0xf0(%rsp)
  81dc68:	movb   $0x0,0xf4(%rsp)
  81dc70:	lea    0x60(%rsp),%rdi
  81dc75:	lea    0xd8(%rsp),%rdx
  81dc7d:	mov    %r14,%rsi
  81dc80:	call   *0x66205a(%rip)        # e7fce0 <_DYNAMIC+0x618>
  81dc86:	movq   $0x8,0x80(%rsp)
  81dc92:	lea    -0x748ce3(%rip),%rax        # d4fb6 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.12798218693442382726+0x1b>
  81dc99:	mov    %rax,0xd8(%rsp)
  81dca1:	movq   $0x7,0xe0(%rsp)
  81dcad:	movq   $0x4,0xe8(%rsp)
  81dcb9:	movl   $0x88,0xf0(%rsp)
  81dcc4:	movb   $0x0,0xf4(%rsp)
  81dccc:	lea    0x88(%rsp),%rdi
  81dcd4:	lea    0xd8(%rsp),%rdx
  81dcdc:	mov    %r14,%rsi
  81dcdf:	call   *0x661ffb(%rip)        # e7fce0 <_DYNAMIC+0x618>
  81dce5:	movq   $0x4,0xa8(%rsp)
  81dcf1:	lea    -0x748d3b(%rip),%rax        # d4fbd <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.12798218693442382726+0x22>
  81dcf8:	mov    %rax,0xd8(%rsp)
  81dd00:	movq   $0x11,0xe0(%rsp)
  81dd0c:	movq   $0x20,0xe8(%rsp)
  81dd18:	movl   $0x88,0xf0(%rsp)
  81dd23:	movb   $0x0,0xf4(%rsp)
  81dd2b:	lea    0xb0(%rsp),%rdi
  81dd33:	lea    0xd8(%rsp),%rdx
  81dd3b:	mov    %r14,%rsi
  81dd3e:	call   *0x661f9c(%rip)        # e7fce0 <_DYNAMIC+0x618>
  81dd44:	movq   $0x20,0xd0(%rsp)
  81dd50:	lea    0x2a8(%rsp),%rdi
  81dd58:	mov    %r14,%rsi
  81dd5b:	mov    $0x1,%edx
  81dd60:	call   81cde0 <<gpui_gpu::renderer::Atlas>::new>
  81dd65:	mov    0x18(%r14),%r13
  81dd69:	lock incq 0x0(%r13)
  81dd6e:	jle    81e088 <<gpui_gpu::renderer::RendererState>::new+0x518>
  81dd74:	mov    %r13,0x8(%rsp)
  81dd79:	mov    0x30(%rsp),%rax
  81dd7e:	mov    %rax,0x1e0(%rsp)
  81dd86:	movups 0x10(%rsp),%xmm0
  81dd8b:	movups 0x20(%rsp),%xmm1
  81dd90:	movaps %xmm1,0x1d0(%rsp)
  81dd98:	movaps %xmm0,0x1c0(%rsp)
  81dda0:	mov    0x58(%rsp),%rax
  81dda5:	mov    %rax,0x210(%rsp)
  81ddad:	movups 0x38(%rsp),%xmm0
  81ddb2:	movups 0x48(%rsp),%xmm1
  81ddb7:	movaps %xmm1,0x200(%rsp)
  81ddbf:	movaps %xmm0,0x1f0(%rsp)
  81ddc7:	mov    0x80(%rsp),%rax
  81ddcf:	mov    %rax,0x240(%rsp)
  81ddd7:	movups 0x60(%rsp),%xmm0
  81dddc:	movups 0x70(%rsp),%xmm1
  81dde1:	movaps %xmm1,0x230(%rsp)
  81dde9:	movaps %xmm0,0x220(%rsp)
  81ddf1:	mov    0xa8(%rsp),%rax
  81ddf9:	mov    %rax,0x270(%rsp)
  81de01:	movups 0x88(%rsp),%xmm0
  81de09:	movups 0x98(%rsp),%xmm1
  81de11:	movaps %xmm1,0x260(%rsp)
  81de19:	movaps %xmm0,0x250(%rsp)
  81de21:	mov    0xd0(%rsp),%rax
  81de29:	mov    %rax,0x2a0(%rsp)
  81de31:	movups 0xb0(%rsp),%xmm0
  81de39:	movups 0xc0(%rsp),%xmm1
  81de41:	movaps %xmm1,0x290(%rsp)
  81de49:	movaps %xmm0,0x280(%rsp)
  81de51:	lea    0xd8(%rsp),%rdi
  81de59:	lea    0x2a8(%rsp),%rsi
  81de61:	mov    $0xe8,%edx
  81de66:	call   *0x661afc(%rip)        # e7f968 <memcpy@GLIBC_2.14>
  81de6c:	mov    %fs:0x0,%rax
  81de75:	lea    -0x28(%rax),%rax
  81de7c:	mov    %rax,%r12
  81de7f:	cmpb   $0x1,0x10(%rax)
  81de83:	jne    81e068 <<gpui_gpu::renderer::RendererState>::new+0x4f8>
  81de89:	mov    (%r12),%r14
  81de8d:	mov    0x8(%r12),%r15
  81de92:	lea    0x1(%r14),%rax
  81de96:	mov    %rax,(%r12)
  81de9a:	mov    %r13,0x210(%rbx)
  81dea1:	mov    0x30(%rsp),%rax
  81dea6:	mov    %rax,0x238(%rbx)
  81dead:	movups 0x10(%rsp),%xmm0
  81deb2:	movups 0x20(%rsp),%xmm1
  81deb7:	movups %xmm1,0x228(%rbx)
  81debe:	movups %xmm0,0x218(%rbx)
  81dec5:	mov    0x58(%rsp),%rax
  81deca:	mov    %rax,0x260(%rbx)
  81ded1:	movups 0x38(%rsp),%xmm0
  81ded6:	movups 0x48(%rsp),%xmm1
  81dedb:	movups %xmm1,0x250(%rbx)
  81dee2:	movups %xmm0,0x240(%rbx)
  81dee9:	mov    0x80(%rsp),%rax
  81def1:	mov    %rax,0x288(%rbx)
  81def8:	movups 0x60(%rsp),%xmm0
  81defd:	movups 0x70(%rsp),%xmm1
  81df02:	movups %xmm1,0x278(%rbx)
  81df09:	movups %xmm0,0x268(%rbx)
  81df10:	movups 0x88(%rsp),%xmm0
  81df18:	movups 0x98(%rsp),%xmm1
  81df20:	movups %xmm0,0x290(%rbx)
  81df27:	movups %xmm1,0x2a0(%rbx)
  81df2e:	mov    0xa8(%rsp),%rax
  81df36:	mov    %rax,0x2b0(%rbx)
  81df3d:	movups 0xb0(%rsp),%xmm0
  81df45:	movups 0xc0(%rsp),%xmm1
  81df4d:	movups %xmm0,0x2b8(%rbx)
  81df54:	movups %xmm1,0x2c8(%rbx)
  81df5b:	mov    0xd0(%rsp),%rax
  81df63:	mov    %rax,0x2d8(%rbx)
  81df6a:	lea    0x60(%rbx),%rdi
  81df6e:	lea    0x2a8(%rsp),%rsi
  81df76:	mov    $0xe8,%edx
  81df7b:	call   *0x6619e7(%rip)        # e7f968 <memcpy@GLIBC_2.14>
  81df81:	xorps  %xmm0,%xmm0
  81df84:	movups %xmm0,0x310(%rbx)
  81df8b:	movq   $0x0,(%rbx)
  81df92:	movq   $0x4,0x8(%rbx)
  81df9a:	movups %xmm0,0x10(%rbx)
  81df9e:	movq   $0x4,0x20(%rbx)
  81dfa6:	movups %xmm0,0x28(%rbx)
  81dfaa:	movq   $0x4,0x38(%rbx)
  81dfb2:	movups %xmm0,0x40(%rbx)
  81dfb6:	movq   $0x4,0x50(%rbx)
  81dfbe:	movq   $0x0,0x58(%rbx)
  81dfc6:	movups 0x6102bb(%rip),%xmm1        # e2e288 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  81dfcd:	movups %xmm1,0x2e0(%rbx)
  81dfd4:	movups 0x6102bd(%rip),%xmm1        # e2e298 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf0>
  81dfdb:	movups %xmm1,0x2f0(%rbx)
  81dfe2:	mov    %r14,0x300(%rbx)
  81dfe9:	mov    %r15,0x308(%rbx)
  81dff0:	movw   $0x101,0x328(%rbx)
  81dff9:	movups %xmm0,0x1f8(%rbx)
  81e000:	movups %xmm0,0x1e8(%rbx)
  81e007:	movups %xmm0,0x1d8(%rbx)
  81e00e:	movups %xmm0,0x1c8(%rbx)
  81e015:	movups %xmm0,0x1b8(%rbx)
  81e01c:	movups %xmm0,0x1a8(%rbx)
  81e023:	movups %xmm0,0x198(%rbx)
  81e02a:	movups %xmm0,0x188(%rbx)
  81e031:	movups %xmm0,0x178(%rbx)
  81e038:	movups %xmm0,0x168(%rbx)
  81e03f:	movups %xmm0,0x158(%rbx)
  81e046:	movups %xmm0,0x148(%rbx)
  81e04d:	movb   $0x0,0x208(%rbx)
  81e054:	mov    %rbx,%rax
  81e057:	add    $0x390,%rsp
  81e05e:	pop    %rbx
  81e05f:	pop    %r12
  81e061:	pop    %r13
  81e063:	pop    %r14
  81e065:	pop    %r15
  81e067:	ret
  81e068:	call   *0x661c7a(%rip)        # e7fce8 <_DYNAMIC+0x620>
  81e06e:	mov    %rax,%r14
  81e071:	mov    %rdx,%r15
  81e074:	mov    %rax,(%r12)
  81e078:	mov    %rdx,0x8(%r12)
  81e07d:	movb   $0x1,0x10(%r12)
  81e083:	jmp    81de92 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81e088:	ud2
  81e08a:	mov    %rax,%rbx
  81e08d:	lea    0xd8(%rsp),%rdi
  81e095:	call   81bbd0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81e09a:	lea    0x280(%rsp),%rdi
  81e0a2:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0a7:	lea    0x250(%rsp),%rdi
  81e0af:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0b4:	lea    0x220(%rsp),%rdi
  81e0bc:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0c1:	lea    0x1f0(%rsp),%rdi
  81e0c9:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0ce:	lea    0x1c0(%rsp),%rdi
  81e0d6:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0db:	lock decq 0x0(%r13)
  81e0e0:	jne    81e13e <<gpui_gpu::renderer::RendererState>::new+0x5ce>
  81e0e2:	lea    0x8(%rsp),%rdi
  81e0e7:	call   *0x661a43(%rip)        # e7fb30 <_DYNAMIC+0x468>
  81e0ed:	jmp    81e13e <<gpui_gpu::renderer::RendererState>::new+0x5ce>
  81e0ef:	mov    %rax,%rbx
  81e0f2:	lea    0xb0(%rsp),%rdi
  81e0fa:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0ff:	jmp    81e104 <<gpui_gpu::renderer::RendererState>::new+0x594>
  81e101:	mov    %rax,%rbx
  81e104:	lea    0x88(%rsp),%rdi
  81e10c:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e111:	jmp    81e116 <<gpui_gpu::renderer::RendererState>::new+0x5a6>
  81e113:	mov    %rax,%rbx
  81e116:	lea    0x60(%rsp),%rdi
  81e11b:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e120:	jmp    81e125 <<gpui_gpu::renderer::RendererState>::new+0x5b5>
  81e122:	mov    %rax,%rbx
  81e125:	lea    0x38(%rsp),%rdi
  81e12a:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e12f:	jmp    81e134 <<gpui_gpu::renderer::RendererState>::new+0x5c4>
  81e131:	mov    %rax,%rbx
  81e134:	lea    0x10(%rsp),%rdi
  81e139:	call   81bcb0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e13e:	mov    %rbx,%rdi
  81e141:	call   e2c4b0 <_Unwind_Resume@plt>
  81e146:	call   *0x6617cc(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9385 frame=1400

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e150 <<gpui_gpu::renderer::RendererState>::render>:
  81e150:	push   %rbp
  81e151:	push   %r15
  81e153:	push   %r14
  81e155:	push   %r13
  81e157:	push   %r12
  81e159:	push   %rbx
  81e15a:	sub    $0x548,%rsp
  81e161:	mov    0x210(%rsi),%rax
  81e168:	mov    0x18(%rdx),%r9
  81e16c:	cmp    %r9,%rax
  81e16f:	je     81e18d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e171:	mov    0x10(%rax),%r10
  81e175:	cmp    0x10(%r9),%r10
  81e179:	jne    81e25b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e17f:	mov    0x18(%rax),%rax
  81e183:	cmp    0x18(%r9),%rax
  81e187:	jne    81e25b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e18d:	lea    0x318(%rsi),%rbx
  81e194:	mov    0x318(%rsi),%rax
  81e19b:	test   %rax,%rax
  81e19e:	je     81e1cd <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e1a0:	lock decq (%rax)
  81e1a4:	jne    81e1cd <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e1a6:	mov    %rdi,%r14
  81e1a9:	mov    %rbx,%rdi
  81e1ac:	mov    %rsi,%r12
  81e1af:	mov    %r8,%r13
  81e1b2:	mov    %rdx,%r15
  81e1b5:	mov    %rcx,%rbp
  81e1b8:	call   *0x661a22(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  81e1be:	mov    %rbp,%rcx
  81e1c1:	mov    %r15,%rdx
  81e1c4:	mov    %r13,%r8
  81e1c7:	mov    %r12,%rsi
  81e1ca:	mov    %r14,%rdi
  81e1cd:	movq   $0x0,0x318(%rsi)
  81e1d8:	mov    (%rcx),%r12d
  81e1db:	mov    0x8(%rcx),%r9d
  81e1df:	movzbl 0xd(%rcx),%eax
  81e1e3:	test   %r9d,%r9d
  81e1e6:	sets   %r10b
  81e1ea:	and    $0x7fffffff,%r9d
  81e1f1:	lea    -0x800000(%r9),%r11d
  81e1f8:	cmp    $0x7f000000,%r11d
  81e1ff:	setb   %r11b
  81e203:	and    %r10b,%r11b
  81e206:	lea    -0x1(%r9),%ebp
  81e20a:	cmp    $0x7fffff,%ebp
  81e210:	setb   %bpl
  81e214:	and    %r10b,%bpl
  81e217:	test   %r9d,%r9d
  81e21a:	sete   %r10b
  81e21e:	cmp    $0x7f800000,%r9d
  81e225:	sete   %r14b
  81e229:	or     %r10b,%r14b
  81e22c:	cmp    $0x7f800001,%r9d
  81e233:	setge  %r9b
  81e237:	or     %r14b,%r9b
  81e23a:	or     %bpl,%r9b
  81e23d:	test   %r12d,%r12d
  81e240:	setne  %r10b
  81e244:	and    %al,%r10b
  81e247:	or     %r11b,%r10b
  81e24a:	or     %r9b,%r10b
  81e24d:	test   $0x1,%r10b
  81e251:	je     81e276 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e253:	movl   $0x3,(%rdi)
  81e259:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e25b:	movl   $0x4,(%rdi)
  81e261:	mov    %rdi,%rax
  81e264:	add    $0x548,%rsp
  81e26b:	pop    %rbx
  81e26c:	pop    %r12
  81e26e:	pop    %r13
  81e270:	pop    %r14
  81e272:	pop    %r15
  81e274:	pop    %rbp
  81e275:	ret
  81e276:	movd   0x4(%rcx),%xmm2
  81e27b:	movzbl 0xc(%rcx),%ebp
  81e27f:	test   $0x1,%r12b
  81e283:	je     81e2fb <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e285:	movd   %xmm2,%r9d
  81e28a:	test   %r9d,%r9d
  81e28d:	sets   %r10b
  81e291:	and    $0x7fffffff,%r9d
  81e298:	lea    -0x800000(%r9),%r11d
  81e29f:	cmp    $0x7f000000,%r11d
  81e2a6:	setb   %r11b
  81e2aa:	and    %r10b,%r11b
  81e2ad:	lea    -0x1(%r9),%r14d
  81e2b1:	cmp    $0x7fffff,%r14d
  81e2b8:	setb   %r14b
  81e2bc:	and    %r10b,%r14b
  81e2bf:	test   %r9d,%r9d
  81e2c2:	sete   %r10b
  81e2c6:	cmp    $0x7f800000,%r9d
  81e2cd:	sete   %r15b
  81e2d1:	or     %r10b,%r15b
  81e2d4:	cmp    $0x7f800001,%r9d
  81e2db:	setge  %r9b
  81e2df:	or     %r15b,%r9b
  81e2e2:	or     %r14b,%r9b
  81e2e5:	or     %r11b,%r9b
  81e2e8:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ee:	ucomiss -0x76f449(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e2f5:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2fb:	mov    0x28(%rcx),%r14d
  81e2ff:	cmp    %r14d,0x20(%r8)
  81e303:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e309:	mov    0x2c(%rcx),%r15d
  81e30d:	cmp    %r15d,0x24(%r8)
  81e311:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e317:	mov    0x38(%r8),%r13d
  81e31b:	cmp    0x20(%rdx),%r13d
  81e31f:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e325:	cmp    $0x4c,%r13d
  81e329:	jne    81e34e <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e32b:	movq   0x3c(%r8),%xmm0
  81e331:	movq   0x24(%rdx),%xmm1
  81e336:	pcmpeqd %xmm0,%xmm1
  81e33a:	pshufd $0x50,%xmm1,%xmm0
  81e33f:	movmskpd %xmm0,%r9d
  81e344:	cmp    $0x3,%r9d
  81e348:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e34e:	cmp    $0x4000,%r15d
  81e355:	ja     81e38b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e357:	cmp    $0x4000,%r14d
  81e35e:	ja     81e38b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e360:	mov    %r15,%r9
  81e363:	imul   %r14,%r9
  81e367:	add    $0xfffffffffeffffff,%r9
  81e36e:	cmp    $0xffffffffff000000,%r9
  81e375:	jb     81e38b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e377:	mov    0x10(%rcx),%r11
  81e37b:	mov    0x80(%r11),%r10
  81e382:	cmp    $0x10000,%r10
  81e389:	jbe    81e396 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e38b:	movl   $0x6,(%rdi)
  81e391:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e396:	movd   0x18(%rcx),%xmm0
  81e39b:	movd   %xmm0,%r9d
  81e3a0:	and    $0x7fffffff,%r9d
  81e3a7:	cmp    $0x7f7fffff,%r9d
  81e3ae:	jg     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3b4:	pand   -0x770c3c(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3bc:	ucomiss -0x76f2bf(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3c3:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3c9:	movd   0x1c(%rcx),%xmm0
  81e3ce:	movd   %xmm0,%r9d
  81e3d3:	and    $0x7fffffff,%r9d
  81e3da:	cmp    $0x7f7fffff,%r9d
  81e3e1:	jg     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3e7:	pand   -0x770c6f(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3ef:	ucomiss -0x76f2f2(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3f6:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3fc:	movd   0x20(%rcx),%xmm0
  81e401:	movd   %xmm0,%r9d
  81e406:	and    $0x7fffffff,%r9d
  81e40d:	cmp    $0x7f7fffff,%r9d
  81e414:	jg     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e41a:	pand   -0x770ca2(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e422:	ucomiss -0x76f325(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e429:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e42f:	movd   0x24(%rcx),%xmm0
  81e434:	movd   %xmm0,%r9d
  81e439:	and    $0x7fffffff,%r9d
  81e440:	cmp    $0x7f7fffff,%r9d
  81e447:	jg     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e44d:	movdqa -0x770cd5(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e455:	pand   %xmm0,%xmm1
  81e459:	ucomiss -0x76f35c(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e460:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e466:	xorps  %xmm1,%xmm1
  81e469:	ucomiss %xmm1,%xmm0
  81e46c:	jb     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e472:	movss  -0x76f6fa(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e47a:	ucomiss %xmm0,%xmm1
  81e47d:	jb     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e483:	movzwl 0x30(%rcx),%r9d
  81e488:	mov    %r9w,0x10(%rsp)
  81e48e:	movzwl 0x32(%rcx),%r9d
  81e493:	mov    %r9w,0x18(%rsp)
  81e499:	cmp    $0x28,%r13d
  81e49d:	jne    81e4a9 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e49f:	test   $0x1,%al
  81e4a1:	je     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e4a7:	jmp    81e4c4 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e4a9:	test   $0x1,%al
  81e4ab:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e4b1:	ucomiss -0x76f738(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e4b8:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e4be:	jp     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e4c4:	mov    %r11,0xc8(%rsp)
  81e4cc:	mov    %r10,0xc0(%rsp)
  81e4d4:	movss  %xmm1,0x104(%rsp)
  81e4dd:	movd   %xmm2,0x244(%rsp)
  81e4e6:	mov    %rdx,0x108(%rsp)
  81e4ee:	mov    %r8,0x3e8(%rsp)
  81e4f6:	mov    %rdi,0x38(%rsp)
  81e4fb:	lea    0xf(%r14),%rdx
  81e4ff:	shr    $0x4,%rdx
  81e503:	lea    0xf(%r15),%eax
  81e507:	shr    $0x4,%eax
  81e50a:	lea    0x18(%rsi),%rdi
  81e50e:	movq   $0x0,0x28(%rsi)
  81e516:	mov    %rdx,0x58(%rsp)
  81e51b:	imul   %edx,%eax
  81e51e:	mov    %rdi,0x218(%rsp)
  81e526:	mov    %rsi,0x8(%rsp)
  81e52b:	mov    %rax,%rsi
  81e52e:	xor    %edx,%edx
  81e530:	mov    %rcx,0xe8(%rsp)
  81e538:	call   822880 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e53d:	mov    0x8(%rsp),%rax
  81e542:	movq   $0x0,0x10(%rax)
  81e54a:	mov    0xe8(%rsp),%rdi
  81e552:	call   *0x661718(%rip)        # e7fc70 <_DYNAMIC+0x5a8>
  81e558:	mov    %rdx,%rcx
  81e55b:	sub    %rax,%rcx
  81e55e:	cmp    $0x300000,%rcx
  81e565:	jbe    81e577 <<gpui_gpu::renderer::RendererState>::render+0x427>
  81e567:	mov    0x38(%rsp),%rdi
  81e56c:	movl   $0x6,(%rdi)
  81e572:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e577:	mov    %rcx,%rsi
  81e57a:	shr    $0x3,%rcx
  81e57e:	movabs $0xaaaaaaaaaaaaaaab,%rdi
  81e588:	imul   %rcx,%rdi
  81e58c:	mov    %rdi,0x30(%rsp)
  81e591:	mov    %rax,0x380(%rsp)
  81e599:	mov    %rdx,0x378(%rsp)
  81e5a1:	cmp    %rax,%rdx
  81e5a4:	je     81e5d2 <<gpui_gpu::renderer::RendererState>::render+0x482>
  81e5a6:	mov    $0xaaaaaaab,%eax
  81e5ab:	imul   %rax,%rsi
  81e5af:	shr    $0x2a,%rsi
  81e5b3:	mov    0x30(%rsp),%rcx
  81e5b8:	mov    %ecx,%eax
  81e5ba:	and    $0x3f,%eax
  81e5bd:	add    %rcx,%rsi
  81e5c0:	cmp    $0x1,%rax
  81e5c4:	sbb    $0xffffffffffffffff,%rsi
  81e5c8:	inc    %rsi
  81e5cb:	mov    %rsi,0x50(%rsp)
  81e5d0:	jmp    81e5db <<gpui_gpu::renderer::RendererState>::render+0x48b>
  81e5d2:	movq   $0x0,0x50(%rsp)
  81e5db:	mov    0xc8(%rsp),%rax
  81e5e3:	mov    0x98(%rax),%rcx
  81e5ea:	add    0xb0(%rax),%rcx
  81e5f1:	mov    %rax,0x110(%rsp)
  81e5f9:	movzwl 0x10(%rsp),%eax
  81e5fe:	mov    %ax,0x130(%rsp)
  81e606:	movzwl 0x18(%rsp),%eax
  81e60b:	mov    %ax,0x132(%rsp)
  81e613:	movq   $0x0,0x118(%rsp)
  81e61f:	mov    0xc0(%rsp),%rax
  81e627:	mov    %rax,0x120(%rsp)
  81e62f:	mov    %rcx,0x210(%rsp)
  81e637:	mov    %rcx,0x128(%rsp)
  81e63f:	mov    0x8(%rsp),%rax
  81e644:	movzbl 0x329(%rax),%edx
  81e64b:	lea    0x428(%rsp),%rdi
  81e653:	lea    0x110(%rsp),%rsi
  81e65b:	call   81c8c0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e660:	mov    0x428(%rsp),%eax
  81e667:	cmp    $0xffffffff,%eax
  81e66a:	je     81e69a <<gpui_gpu::renderer::RendererState>::render+0x54a>
  81e66c:	mov    0x42c(%rsp),%ecx
  81e673:	mov    0x430(%rsp),%rdx
  81e67b:	movups 0x438(%rsp),%xmm0
  81e683:	mov    0x38(%rsp),%rdi
  81e688:	movups %xmm0,0x10(%rdi)
  81e68c:	mov    %eax,(%rdi)
  81e68e:	mov    %ecx,0x4(%rdi)
  81e691:	mov    %rdx,0x8(%rdi)
  81e695:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e69a:	mov    0x430(%rsp),%rdx
  81e6a2:	add    0x50(%rsp),%rdx
  81e6a7:	mov    0x8(%rsp),%rdi
  81e6ac:	mov    0x10(%rdi),%rsi
  81e6b0:	mov    $0x4,%ecx
  81e6b5:	mov    $0x10,%r8d
  81e6bb:	call   823c40 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e6c0:	cmp    $0xffffffffffffffff,%rax
  81e6c4:	jne    81e567 <<gpui_gpu::renderer::RendererState>::render+0x417>
  81e6ca:	movzwl 0x10(%rsp),%eax
  81e6cf:	mov    %eax,0x10(%rsp)
  81e6d3:	movzwl 0x18(%rsp),%eax
  81e6d8:	mov    %eax,0x78(%rsp)
  81e6dc:	mov    0x8(%rsp),%rdi
  81e6e1:	mov    0xe8(%rsp),%rsi
  81e6e9:	mov    0x30(%rsp),%rdx
  81e6ee:	call   825ba0 <gpui_gpu::renderer::slots::write_prefix>
  81e6f3:	mov    0x8(%rsp),%rax
  81e6f8:	movq   $0x0,0x58(%rax)
  81e700:	cmpq   $0x0,0x48(%rax)
  81e705:	jne    81e716 <<gpui_gpu::renderer::RendererState>::render+0x5c6>
  81e707:	mov    0x8(%rsp),%rax
  81e70c:	lea    0x48(%rax),%rdi
  81e710:	call   *0x661562(%rip)        # e7fc78 <_DYNAMIC+0x5b0>
  81e716:	mov    0x8(%rsp),%rax
  81e71b:	mov    0x50(%rax),%rcx
  81e71f:	xorps  %xmm0,%xmm0
  81e722:	movups %xmm0,0x10(%rcx)
  81e726:	movups %xmm0,(%rcx)
  81e729:	movq   $0x1,0x58(%rax)
  81e731:	lea    0x2e0(%rax),%rdi
  81e738:	call   825550 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e73d:	mov    0x78(%rsp),%ecx
  81e741:	shl    $0x10,%ecx
  81e744:	add    0x10(%rsp),%ecx
  81e748:	mov    0xc8(%rsp),%rax
  81e750:	mov    %rax,0x388(%rsp)
  81e758:	movq   $0x0,0x390(%rsp)
  81e764:	mov    0xc0(%rsp),%rax
  81e76c:	mov    %rax,0x398(%rsp)
  81e774:	mov    0x210(%rsp),%rax
  81e77c:	mov    %rax,0x3a0(%rsp)
  81e784:	mov    %ecx,0x78(%rsp)
  81e788:	mov    %ecx,0x3a8(%rsp)
  81e78f:	lea    0x248(%rsp),%rdi
  81e797:	lea    0x388(%rsp),%rsi
  81e79f:	call   *0x6614db(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81e7a5:	mov    0x248(%rsp),%rax
  81e7ad:	mov    %rax,0x18(%rsp)
  81e7b2:	test   %rax,%rax
  81e7b5:	je     81f519 <<gpui_gpu::renderer::RendererState>::render+0x13c9>
  81e7bb:	movq   $0x0,0xe0(%rsp)
  81e7c7:	movq   $0x0,0x10(%rsp)
  81e7d0:	movq   $0x0,0xb8(%rsp)
  81e7dc:	movq   $0x0,0x200(%rsp)
  81e7e8:	movq   $0x0,0x208(%rsp)
  81e7f4:	mov    0x250(%rsp),%rcx
  81e7fc:	mov    0x258(%rsp),%rdx
  81e804:	mov    %rdx,0xa0(%rsp)
  81e80c:	lea    0x260(%rsp),%rdi
  81e814:	movups (%rdi),%xmm0
  81e817:	movups 0x10(%rdi),%xmm1
  81e81b:	movups 0x20(%rdi),%xmm2
  81e81f:	movaps %xmm2,0x2f0(%rsp)
  81e827:	movaps %xmm1,0x2e0(%rsp)
  81e82f:	movaps %xmm0,0x2d0(%rsp)
  81e837:	lea    0x290(%rsp),%r8
  81e83f:	movups (%r8),%xmm0
  81e843:	movaps %xmm0,0x4f0(%rsp)
  81e84b:	movups 0x40(%rdi),%xmm0
  81e84f:	movaps %xmm0,0x3f0(%rsp)
  81e857:	mov    0x8(%rsp),%rax
  81e85c:	movzbl 0x329(%rax),%esi
  81e863:	mov    0x18(%rsp),%rax
  81e868:	mov    %rax,0x110(%rsp)
  81e870:	mov    %rcx,0x28(%rsp)
  81e875:	mov    %rcx,0x118(%rsp)
  81e87d:	mov    %rdx,0x120(%rsp)
  81e885:	movups (%rdi),%xmm0
  81e888:	movups 0x10(%rdi),%xmm1
  81e88c:	movups 0x20(%rdi),%xmm2
  81e890:	lea    0x128(%rsp),%rax
  81e898:	movups %xmm2,0x20(%rax)
  81e89c:	movups %xmm1,0x10(%rax)
  81e8a0:	movups %xmm0,(%rax)
  81e8a3:	movups (%r8),%xmm0
  81e8a7:	movups %xmm0,0x30(%rax)
  81e8ab:	movups 0x40(%rdi),%xmm0
  81e8af:	movups %xmm0,0x40(%rax)
  81e8b3:	lea    0x110(%rsp),%rdi
  81e8bb:	call   8215e0 <gpui_gpu::renderer::compact_group>
  81e8c0:	mov    %al,0x40(%rsp)
  81e8c4:	lea    0x260(%rsp),%rsi
  81e8cc:	movups (%rsi),%xmm0
  81e8cf:	movups 0x10(%rsi),%xmm1
  81e8d3:	movups 0x20(%rsi),%xmm2
  81e8d7:	movaps %xmm0,0x500(%rsp)
  81e8df:	movaps %xmm1,0x510(%rsp)
  81e8e7:	movaps %xmm2,0x520(%rsp)
  81e8ef:	lea    0x290(%rsp),%rdx
  81e8f7:	movups (%rdx),%xmm0
  81e8fa:	movaps %xmm0,0x530(%rsp)
  81e902:	mov    0x8(%rsp),%rdi
  81e907:	call   81d4f0 <<gpui_gpu::renderer::RendererState>::correction>
  81e90c:	mov    %eax,0x7c(%rsp)
  81e910:	mov    0xa0(%rsp),%rax
  81e918:	lea    0x0(,%rax,4),%rax
  81e920:	mov    %rax,0x370(%rsp)
  81e928:	cmpb   $0x0,0x40(%rsp)
  81e92d:	je     81eb0b <<gpui_gpu::renderer::RendererState>::render+0x9bb>
  81e933:	mov    0x28(%rsp),%rcx
  81e938:	mov    0xa0(%rsp),%rax
  81e940:	lea    (%rcx,%rax,4),%rax
  81e944:	mov    %rcx,0x408(%rsp)
  81e94c:	mov    %rax,0x410(%rsp)
  81e954:	mov    0x18(%rsp),%rax
  81e959:	mov    %rax,0x418(%rsp)
  81e961:	movq   $0x0,0x420(%rsp)
  81e96d:	lea    0x300(%rsp),%rdi
  81e975:	lea    0x408(%rsp),%rsi
  81e97d:	call   821c70 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e982:	cmpb   $0xff,0x308(%rsp)
  81e98a:	je     81f04a <<gpui_gpu::renderer::RendererState>::render+0xefa>
  81e990:	xorps  %xmm0,%xmm0
  81e993:	movaps %xmm0,0x80(%rsp)
  81e99b:	movaps %xmm0,0x60(%rsp)
  81e9a0:	mov    0x300(%rsp),%rdx
  81e9a8:	add    0xb8(%rsp),%rdx
  81e9b0:	lea    0x308(%rsp),%rsi
  81e9b8:	movups 0x38(%rsi),%xmm0
  81e9bc:	lea    0x128(%rsp),%rcx
  81e9c4:	movups %xmm0,0x20(%rcx)
  81e9c8:	movups 0x48(%rsi),%xmm0
  81e9cc:	movups %xmm0,0x70(%rcx)
  81e9d0:	mov    0x30(%rsi),%rax
  81e9d4:	mov    %rax,0x140(%rsp)
  81e9dc:	movups (%rsi),%xmm0
  81e9df:	movups 0x10(%rsi),%xmm1
  81e9e3:	movups 0x20(%rsi),%xmm2
  81e9e7:	movaps %xmm2,0x130(%rsp)
  81e9ef:	movaps %xmm1,0x120(%rsp)
  81e9f7:	movaps %xmm0,0x110(%rsp)
  81e9ff:	lea    0x260(%rsp),%rax
  81ea07:	movups 0x40(%rax),%xmm0
  81ea0b:	movups %xmm0,0x80(%rcx)
  81ea12:	movups (%rax),%xmm0
  81ea15:	movups 0x10(%rax),%xmm1
  81ea19:	movups 0x20(%rax),%xmm2
  81ea1d:	movups %xmm2,0x50(%rcx)
  81ea21:	movups %xmm1,0x40(%rcx)
  81ea25:	movups %xmm0,0x30(%rcx)
  81ea29:	lea    0x290(%rsp),%rax
  81ea31:	movups (%rax),%xmm0
  81ea34:	movups %xmm0,0x60(%rcx)
  81ea38:	lea    0x220(%rsp),%rdi
  81ea40:	lea    0x110(%rsp),%rsi
  81ea48:	mov    %r14d,%ecx
  81ea4b:	mov    %r15d,%r8d
  81ea4e:	call   821630 <gpui_gpu::renderer::validate_draw>
  81ea53:	mov    0x220(%rsp),%ecx
  81ea5a:	mov    0x224(%rsp),%rax
  81ea62:	cmp    $0xffffffff,%ecx
  81ea65:	jne    81f5d4 <<gpui_gpu::renderer::RendererState>::render+0x1484>
  81ea6b:	mov    %eax,%ecx
  81ea6d:	shr    $0x20,%rax
  81ea71:	movd   %ecx,%xmm0
  81ea75:	movaps 0x80(%rsp),%xmm2
  81ea7d:	movaps %xmm2,%xmm1
  81ea80:	maxss  %xmm0,%xmm1
  81ea84:	movaps %xmm1,%xmm3
  81ea87:	cmpunordss %xmm1,%xmm3
  81ea8c:	movaps %xmm3,%xmm0
  81ea8f:	andnps %xmm1,%xmm0
  81ea92:	andps  %xmm2,%xmm3
  81ea95:	orps   %xmm0,%xmm3
  81ea98:	movaps %xmm3,0x40(%rsp)
  81ea9d:	movd   %eax,%xmm0
  81eaa1:	movaps 0x60(%rsp),%xmm2
  81eaa6:	movaps %xmm2,%xmm1
  81eaa9:	maxss  %xmm0,%xmm1
  81eaad:	movaps %xmm1,%xmm3
  81eab0:	cmpunordss %xmm1,%xmm3
  81eab5:	movaps %xmm3,%xmm0
  81eab8:	andnps %xmm1,%xmm0
  81eabb:	andps  %xmm2,%xmm3
  81eabe:	orps   %xmm0,%xmm3
  81eac1:	movaps %xmm3,0x90(%rsp)
  81eac9:	lea    0x300(%rsp),%rdi
  81ead1:	lea    0x408(%rsp),%rsi
  81ead9:	call   821c70 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81eade:	cmpb   $0xff,0x308(%rsp)
  81eae6:	movaps 0x40(%rsp),%xmm0
  81eaeb:	movaps %xmm0,0x80(%rsp)
  81eaf3:	movaps 0x90(%rsp),%xmm0
  81eafb:	movaps %xmm0,0x60(%rsp)
  81eb00:	jne    81e9a0 <<gpui_gpu::renderer::RendererState>::render+0x850>
  81eb06:	jmp    81f05a <<gpui_gpu::renderer::RendererState>::render+0xf0a>
  81eb0b:	cmpq   $0x0,0xa0(%rsp)
  81eb14:	je     81f4c3 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81eb1a:	mov    0x7c(%rsp),%eax
  81eb1e:	or     $0x80000000,%eax
  81eb23:	mov    %eax,0x240(%rsp)
  81eb2a:	movq   $0x0,0x90(%rsp)
  81eb36:	mov    0x28(%rsp),%rax
  81eb3b:	mov    0x90(%rsp),%rcx
  81eb43:	mov    (%rax,%rcx,1),%edx
  81eb46:	lea    0x110(%rsp),%rdi
  81eb4e:	mov    0x18(%rsp),%rsi
  81eb53:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81eb58:	movzbl 0x110(%rsp),%edi
  81eb60:	lea    0x111(%rsp),%rdx
  81eb68:	mov    (%rdx),%eax
  81eb6a:	mov    0x3(%rdx),%ecx
  81eb6d:	lea    0x460(%rsp),%rsi
  81eb75:	mov    %ecx,-0x34(%rsi)
  81eb78:	mov    %eax,-0x37(%rsi)
  81eb7b:	mov    0x118(%rsp),%rcx
  81eb83:	mov    0x2f(%rdx),%rax
  81eb87:	mov    %rax,-0x8(%rsi)
  81eb8b:	movups 0xf(%rdx),%xmm0
  81eb8f:	movups 0x1f(%rdx),%xmm1
  81eb93:	movups %xmm1,-0x18(%rsi)
  81eb97:	movups %xmm0,-0x28(%rsi)
  81eb9b:	lea    0x128(%rsp),%rax
  81eba3:	movups 0x20(%rax),%xmm0
  81eba7:	movups %xmm0,(%rsi)
  81ebaa:	movups 0x30(%rax),%xmm0
  81ebae:	movups %xmm0,0x50(%rsi)
  81ebb2:	lea    0x260(%rsp),%rax
  81ebba:	movups 0x40(%rax),%xmm0
  81ebbe:	movups %xmm0,0x60(%rsi)
  81ebc2:	movups (%rax),%xmm0
  81ebc5:	movups 0x10(%rax),%xmm1
  81ebc9:	movups 0x20(%rax),%xmm2
  81ebcd:	movups %xmm2,0x30(%rsi)
  81ebd1:	movups %xmm1,0x20(%rsi)
  81ebd5:	movups %xmm0,0x10(%rsi)
  81ebd9:	lea    0x290(%rsp),%rax
  81ebe1:	movups (%rax),%xmm0
  81ebe4:	movups %xmm0,0x40(%rsi)
  81ebe8:	mov    %dil,0x60(%rsp)
  81ebed:	mov    %dil,0x428(%rsp)
  81ebf5:	mov    %rcx,0x80(%rsp)
  81ebfd:	mov    %rcx,0x430(%rsp)
  81ec05:	lea    0x110(%rsp),%rdi
  81ec0d:	lea    0x428(%rsp),%rsi
  81ec15:	mov    0xb8(%rsp),%rdx
  81ec1d:	mov    %r14d,%ecx
  81ec20:	mov    %r15d,%r8d
  81ec23:	call   821630 <gpui_gpu::renderer::validate_draw>
  81ec28:	mov    0x110(%rsp),%eax
  81ec2f:	mov    0x114(%rsp),%rcx
  81ec37:	mov    %rcx,0x40(%rsp)
  81ec3c:	cmp    $0xffffffff,%eax
  81ec3f:	jne    81f66a <<gpui_gpu::renderer::RendererState>::render+0x151a>
  81ec45:	movzbl 0x60(%rsp),%eax
  81ec4a:	cmp    $0x2,%al
  81ec4c:	sete   0x27(%rsp)
  81ec51:	cmpq   $0x0,0x80(%rsp)
  81ec5a:	setne  0x26(%rsp)
  81ec5f:	movups 0x460(%rsp),%xmm0
  81ec67:	movaps %xmm0,0x2c0(%rsp)
  81ec6f:	cmp    $0x3,%al
  81ec71:	jne    81ed03 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ec77:	movss  0x42c(%rsp),%xmm0
  81ec80:	xorps  %xmm1,%xmm1
  81ec83:	ucomiss %xmm1,%xmm0
  81ec86:	jne    81ec8a <<gpui_gpu::renderer::RendererState>::render+0xb3a>
  81ec88:	jnp    81ed03 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ec8a:	movaps 0x2c0(%rsp),%xmm5
  81ec92:	movaps %xmm5,%xmm1
  81ec95:	unpckhpd %xmm5,%xmm1
  81ec99:	movss  -0x76fd35(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81eca1:	mulss  %xmm4,%xmm1
  81eca5:	movaps %xmm0,%xmm2
  81eca8:	minss  %xmm1,%xmm2
  81ecac:	movaps %xmm2,%xmm1
  81ecaf:	cmpunordss %xmm2,%xmm1
  81ecb4:	movaps %xmm1,%xmm3
  81ecb7:	andnps %xmm2,%xmm3
  81ecba:	andps  %xmm0,%xmm1
  81ecbd:	orps   %xmm3,%xmm1
  81ecc0:	movaps %xmm5,%xmm0
  81ecc3:	shufps $0xff,%xmm5,%xmm0
  81ecc7:	mulss  %xmm4,%xmm0
  81eccb:	movaps %xmm1,%xmm2
  81ecce:	minss  %xmm0,%xmm2
  81ecd2:	movaps %xmm2,%xmm0
  81ecd5:	cmpunordss %xmm2,%xmm0
  81ecda:	andps  %xmm0,%xmm1
  81ecdd:	andnps %xmm2,%xmm0
  81ece0:	orps   %xmm1,%xmm0
  81ece3:	movd   %xmm0,%eax
  81ece7:	mov    %eax,0x60(%rsp)
  81eceb:	and    $0xff800000,%eax
  81ecf0:	mov    $0x7f000000,%ecx
  81ecf5:	sub    %eax,%ecx
  81ecf7:	mov    %ecx,0x80(%rsp)
  81ecfe:	xorps  %xmm0,%xmm0
  81ed01:	jmp    81ed25 <<gpui_gpu::renderer::RendererState>::render+0xbd5>
  81ed03:	mov    0x4c0(%rsp),%eax
  81ed0a:	mov    %eax,0x60(%rsp)
  81ed0e:	mov    0x4c4(%rsp),%eax
  81ed15:	mov    %eax,0x80(%rsp)
  81ed1c:	movsd  0x4c8(%rsp),%xmm0
  81ed25:	movaps %xmm0,0xd0(%rsp)
  81ed2d:	mov    0x8(%rsp),%rax
  81ed32:	mov    0x10(%rax),%ecx
  81ed35:	mov    $0x80000000,%eax
  81ed3a:	or     %eax,%ecx
  81ed3c:	mov    %ecx,0x360(%rsp)
  81ed43:	movups 0x470(%rsp),%xmm0
  81ed4b:	movaps %xmm0,0x3c0(%rsp)
  81ed53:	movups 0x478(%rsp),%xmm0
  81ed5b:	movaps %xmm0,0x4e0(%rsp)
  81ed63:	movsd  0x480(%rsp),%xmm0
  81ed6c:	movaps %xmm0,0x3b0(%rsp)
  81ed74:	movsd  0x488(%rsp),%xmm0
  81ed7d:	movaps %xmm0,0x4d0(%rsp)
  81ed85:	movsd  0x490(%rsp),%xmm0
  81ed8e:	movsd  %xmm0,0x3e0(%rsp)
  81ed97:	movsd  0x498(%rsp),%xmm0
  81eda0:	movsd  %xmm0,0x3d8(%rsp)
  81eda9:	movups 0x4a0(%rsp),%xmm0
  81edb1:	movaps %xmm0,0x2b0(%rsp)
  81edb9:	mov    0x18(%rsp),%rax
  81edbe:	mov    %rax,0x110(%rsp)
  81edc6:	mov    0x28(%rsp),%rax
  81edcb:	mov    %rax,0x118(%rsp)
  81edd3:	mov    0xa0(%rsp),%rax
  81eddb:	mov    %rax,0x120(%rsp)
  81ede3:	movaps 0x2d0(%rsp),%xmm0
  81edeb:	movaps 0x2e0(%rsp),%xmm1
  81edf3:	movaps 0x2f0(%rsp),%xmm2
  81edfb:	lea    0x128(%rsp),%rax
  81ee03:	movups %xmm2,0x20(%rax)
  81ee07:	movups %xmm1,0x10(%rax)
  81ee0b:	movups %xmm0,(%rax)
  81ee0e:	movaps 0x4f0(%rsp),%xmm0
  81ee16:	movups %xmm0,0x30(%rax)
  81ee1a:	movaps 0x3f0(%rsp),%xmm0
  81ee22:	movups %xmm0,0x40(%rax)
  81ee26:	lea    0x110(%rsp),%rdi
  81ee2e:	call   *0x660e54(%rip)        # e7fc88 <_DYNAMIC+0x5c0>
  81ee34:	mov    0x7c(%rsp),%ecx
  81ee38:	mov    %ecx,0xf0(%rsp)
  81ee3f:	test   %eax,%eax
  81ee41:	je     81ee77 <<gpui_gpu::renderer::RendererState>::render+0xd27>
  81ee43:	mov    0x30(%rsp),%rdi
  81ee48:	mov    %eax,%esi
  81ee4a:	call   825b60 <gpui_gpu::renderer::slots::color_word>
  81ee4f:	mov    %eax,0x60(%rsp)
  81ee53:	xorps  %xmm0,%xmm0
  81ee56:	movaps %xmm0,0xd0(%rsp)
  81ee5e:	movl   $0x0,0x80(%rsp)
  81ee69:	mov    0x240(%rsp),%eax
  81ee70:	mov    %eax,0xf0(%rsp)
  81ee77:	mov    0x40(%rsp),%rax
  81ee7c:	shr    $0x20,%rax
  81ee80:	mov    %rax,0x3d0(%rsp)
  81ee88:	mov    0x8(%rsp),%rax
  81ee8d:	mov    (%rax),%rcx
  81ee90:	mov    0x10(%rax),%rsi
  81ee94:	sub    %rsi,%rcx
  81ee97:	cmp    $0x5,%rcx
  81ee9b:	jbe    81f022 <<gpui_gpu::renderer::RendererState>::render+0xed2>
  81eea1:	movsd  0x3d8(%rsp),%xmm0
  81eeaa:	cvtsd2ss %xmm0,%xmm0
  81eeae:	movsd  0x3e0(%rsp),%xmm1
  81eeb7:	cvtsd2ss %xmm1,%xmm1
  81eebb:	movapd 0x4e0(%rsp),%xmm2
  81eec4:	unpcklpd 0x4d0(%rsp),%xmm2
  81eecd:	cvtpd2ps %xmm2,%xmm2
  81eed1:	movapd 0x3c0(%rsp),%xmm3
  81eeda:	unpcklpd 0x3b0(%rsp),%xmm3
  81eee3:	cvtpd2ps %xmm3,%xmm3
  81eee7:	mov    0x8(%rsp),%rax
  81eeec:	mov    0x8(%rax),%rdx
  81eef0:	shl    $0x4,%rsi
  81eef4:	movaps 0x2c0(%rsp),%xmm4
  81eefc:	movups %xmm4,(%rdx,%rsi,1)
  81ef00:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ef06:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ef0c:	mov    0x40(%rsp),%rcx
  81ef11:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ef15:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ef1b:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81ef21:	mov    0x3d0(%rsp),%rdi
  81ef29:	mov    %edi,0x2c(%rdx,%rsi,1)
  81ef2d:	movaps 0x2b0(%rsp),%xmm0
  81ef35:	movups %xmm0,0x30(%rdx,%rsi,1)
  81ef3a:	mov    0x60(%rsp),%edi
  81ef3e:	mov    %edi,0x40(%rdx,%rsi,1)
  81ef42:	mov    0x80(%rsp),%edi
  81ef49:	mov    %edi,0x44(%rdx,%rsi,1)
  81ef4d:	movaps 0xd0(%rsp),%xmm0
  81ef55:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81ef5a:	movq   $0x0,0x50(%rdx,%rsi,1)
  81ef63:	movl   $0x0,0x58(%rdx,%rsi,1)
  81ef6b:	mov    0xf0(%rsp),%edi
  81ef72:	mov    %edi,0x5c(%rdx,%rsi,1)
  81ef76:	addq   $0x6,0x10(%rax)
  81ef7b:	sub    $0x8,%rsp
  81ef7f:	lea    0x118(%rsp),%rdi
  81ef87:	mov    %rax,%rsi
  81ef8a:	lea    0x430(%rsp),%rdx
  81ef92:	mov    0x368(%rsp),%r8d
  81ef9a:	mov    0x60(%rsp),%r9
  81ef9f:	push   0xe8(%rsp)
  81efa6:	push   %r15
  81efa8:	push   %r14
  81efaa:	call   820600 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81efaf:	add    $0x20,%rsp
  81efb3:	mov    0x110(%rsp),%eax
  81efba:	cmp    $0xffffffff,%eax
  81efbd:	jne    81f632 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  81efc3:	movzbl 0x27(%rsp),%ecx
  81efc8:	and    0x26(%rsp),%cl
  81efcc:	mov    0x10(%rsp),%rax
  81efd1:	or     %cl,%al
  81efd3:	mov    %rax,0x10(%rsp)
  81efd8:	mov    0x118(%rsp),%rax
  81efe0:	mov    %rax,0xe0(%rsp)
  81efe8:	incq   0xb8(%rsp)
  81eff0:	mov    0x90(%rsp),%rdx
  81eff8:	add    $0x4,%rdx
  81effc:	mov    0xa0(%rsp),%rax
  81f004:	lea    0x0(,%rax,4),%rax
  81f00c:	mov    %rdx,0x90(%rsp)
  81f014:	cmp    %rdx,%rax
  81f017:	jne    81eb36 <<gpui_gpu::renderer::RendererState>::render+0x9e6>
  81f01d:	jmp    81f4b7 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81f022:	mov    $0x6,%edx
  81f027:	mov    $0x4,%ecx
  81f02c:	mov    $0x10,%r8d
  81f032:	mov    0x8(%rsp),%rdi
  81f037:	call   823bb0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f03c:	mov    0x8(%rsp),%rax
  81f041:	mov    0x10(%rax),%rsi
  81f045:	jmp    81eea1 <<gpui_gpu::renderer::RendererState>::render+0xd51>
  81f04a:	xorps  %xmm0,%xmm0
  81f04d:	movaps %xmm0,0x90(%rsp)
  81f055:	movaps %xmm0,0x40(%rsp)
  81f05a:	mov    0x8(%rsp),%rax
  81f05f:	mov    0x10(%rax),%eax
  81f062:	mov    %eax,0xd0(%rsp)
  81f069:	movups 0x260(%rsp),%xmm1
  81f071:	movups 0x268(%rsp),%xmm2
  81f079:	movsd  0x280(%rsp),%xmm0
  81f082:	movsd  %xmm0,0xf0(%rsp)
  81f08b:	movsd  0x288(%rsp),%xmm0
  81f094:	movsd  %xmm0,0x2c0(%rsp)
  81f09d:	movups 0x290(%rsp),%xmm0
  81f0a5:	movaps %xmm0,0x80(%rsp)
  81f0ad:	movhps 0x270(%rsp),%xmm1
  81f0b5:	movaps %xmm1,0x360(%rsp)
  81f0bd:	movups 0x2a0(%rsp),%xmm0
  81f0c5:	movaps %xmm0,0x60(%rsp)
  81f0ca:	movhps 0x278(%rsp),%xmm2
  81f0d2:	movaps %xmm2,0x2b0(%rsp)
  81f0da:	mov    0x18(%rsp),%rax
  81f0df:	mov    %rax,0x110(%rsp)
  81f0e7:	mov    0x28(%rsp),%rax
  81f0ec:	mov    %rax,0x118(%rsp)
  81f0f4:	mov    0xa0(%rsp),%rax
  81f0fc:	mov    %rax,0x120(%rsp)
  81f104:	lea    0x260(%rsp),%rax
  81f10c:	movups (%rax),%xmm0
  81f10f:	movups 0x10(%rax),%xmm1
  81f113:	movups 0x20(%rax),%xmm2
  81f117:	lea    0x128(%rsp),%rdx
  81f11f:	movups %xmm2,0x20(%rdx)
  81f123:	movups %xmm1,0x10(%rdx)
  81f127:	movups %xmm0,(%rdx)
  81f12a:	lea    0x290(%rsp),%rcx
  81f132:	movups (%rcx),%xmm0
  81f135:	movups %xmm0,0x30(%rdx)
  81f139:	movdqu 0x40(%rax),%xmm0
  81f13e:	movdqu %xmm0,0x40(%rdx)
  81f143:	lea    0x110(%rsp),%rdi
  81f14b:	call   *0x660b37(%rip)        # e7fc88 <_DYNAMIC+0x5c0>
  81f151:	test   %eax,%eax
  81f153:	je     81f173 <<gpui_gpu::renderer::RendererState>::render+0x1023>
  81f155:	mov    0x30(%rsp),%rdi
  81f15a:	mov    %eax,%esi
  81f15c:	call   825b60 <gpui_gpu::renderer::slots::color_word>
  81f161:	orl    $0x80000000,0x7c(%rsp)
  81f169:	movd   %eax,%xmm0
  81f16d:	movdqa %xmm0,0x60(%rsp)
  81f173:	mov    0x8(%rsp),%rax
  81f178:	mov    (%rax),%rcx
  81f17b:	mov    0x10(%rax),%rsi
  81f17f:	sub    %rsi,%rcx
  81f182:	cmp    $0x4,%rcx
  81f186:	jbe    81f4f1 <<gpui_gpu::renderer::RendererState>::render+0x13a1>
  81f18c:	cvtpd2ps 0x360(%rsp),%xmm0
  81f195:	cvtpd2ps 0x2b0(%rsp),%xmm1
  81f19e:	movsd  0xf0(%rsp),%xmm2
  81f1a7:	cvtsd2ss %xmm2,%xmm2
  81f1ab:	movsd  0x2c0(%rsp),%xmm3
  81f1b4:	cvtsd2ss %xmm3,%xmm3
  81f1b8:	mov    0x8(%rsp),%rax
  81f1bd:	mov    0x8(%rax),%rcx
  81f1c1:	shl    $0x4,%rsi
  81f1c5:	movlpd %xmm0,(%rcx,%rsi,1)
  81f1ca:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f1d0:	movaps 0x40(%rsp),%xmm0
  81f1d5:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f1db:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f1e1:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f1e7:	movaps 0x90(%rsp),%xmm0
  81f1ef:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f1f5:	movaps 0x80(%rsp),%xmm0
  81f1fd:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f202:	movaps 0x60(%rsp),%xmm0
  81f207:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f20c:	mov    0x7c(%rsp),%edx
  81f210:	mov    %edx,0x40(%rcx,%rsi,1)
  81f214:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f21d:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f225:	addq   $0x5,0x10(%rax)
  81f22a:	incq   0x200(%rsp)
  81f232:	mov    0xa0(%rsp),%rax
  81f23a:	add    %rax,0x208(%rsp)
  81f242:	test   %rax,%rax
  81f245:	je     81f4c3 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81f24b:	movdqa 0x40(%rsp),%xmm0
  81f251:	movd   %xmm0,%ecx
  81f255:	movdqa 0x90(%rsp),%xmm0
  81f25e:	movd   %xmm0,%eax
  81f262:	shl    $0x20,%rax
  81f266:	or     %rax,%rcx
  81f269:	mov    %rcx,0xf0(%rsp)
  81f271:	mov    0x370(%rsp),%rax
  81f279:	add    $0xfffffffffffffffc,%rax
  81f27d:	shr    $0x2,%rax
  81f281:	mov    0xb8(%rsp),%rcx
  81f289:	add    %rax,%rcx
  81f28c:	inc    %rcx
  81f28f:	mov    %rcx,0xb8(%rsp)
  81f297:	movq   $0x0,0x40(%rsp)
  81f2a0:	mov    0x28(%rsp),%rax
  81f2a5:	mov    0x40(%rsp),%rcx
  81f2aa:	mov    (%rax,%rcx,1),%edx
  81f2ad:	lea    0x300(%rsp),%rdi
  81f2b5:	mov    0x18(%rsp),%rsi
  81f2ba:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f2bf:	movzbl 0x300(%rsp),%edi
  81f2c7:	lea    0x308(%rsp),%rsi
  81f2cf:	mov    -0x7(%rsi),%eax
  81f2d2:	mov    -0x4(%rsi),%ecx
  81f2d5:	lea    0x111(%rsp),%rdx
  81f2dd:	mov    %ecx,0x3(%rdx)
  81f2e0:	mov    %eax,(%rdx)
  81f2e2:	mov    0x308(%rsp),%rcx
  81f2ea:	mov    0x28(%rsi),%rax
  81f2ee:	mov    %rax,0x2f(%rdx)
  81f2f2:	movups 0x8(%rsi),%xmm0
  81f2f6:	movups 0x18(%rsi),%xmm1
  81f2fa:	movups %xmm1,0x1f(%rdx)
  81f2fe:	movups %xmm0,0xf(%rdx)
  81f302:	movups 0x338(%rsp),%xmm1
  81f30a:	lea    0x348(%rsp),%rax
  81f312:	movups (%rax),%xmm0
  81f315:	lea    0x128(%rsp),%rax
  81f31d:	movups %xmm0,0x70(%rax)
  81f321:	movaps 0x3f0(%rsp),%xmm0
  81f329:	movups %xmm0,0x80(%rax)
  81f330:	movaps %xmm1,0xa0(%rsp)
  81f338:	movups %xmm1,0x148(%rsp)
  81f340:	movaps 0x500(%rsp),%xmm0
  81f348:	movaps 0x510(%rsp),%xmm1
  81f350:	movapd 0x520(%rsp),%xmm2
  81f359:	movupd %xmm2,0x50(%rax)
  81f35e:	movups %xmm1,0x40(%rax)
  81f362:	movups %xmm0,0x30(%rax)
  81f366:	movaps 0x530(%rsp),%xmm0
  81f36e:	movups %xmm0,0x60(%rax)
  81f372:	mov    %dil,0x60(%rsp)
  81f377:	mov    %dil,0x110(%rsp)
  81f37f:	mov    %rcx,0x80(%rsp)
  81f387:	mov    %rcx,0x118(%rsp)
  81f38f:	mov    0x8(%rsp),%rax
  81f394:	mov    (%rax),%rcx
  81f397:	mov    0x10(%rax),%rax
  81f39b:	sub    %rax,%rcx
  81f39e:	mov    %rax,0x90(%rsp)
  81f3a6:	cmp    $0x1,%rcx
  81f3aa:	jbe    81f487 <<gpui_gpu::renderer::RendererState>::render+0x1337>
  81f3b0:	mov    0x8(%rsp),%rsi
  81f3b5:	mov    0x8(%rsi),%rcx
  81f3b9:	shl    $0x4,%rax
  81f3bd:	movaps 0xa0(%rsp),%xmm0
  81f3c5:	movups %xmm0,(%rcx,%rax,1)
  81f3c9:	movq   $0x0,0x10(%rcx,%rax,1)
  81f3d2:	movl   $0x0,0x18(%rcx,%rax,1)
  81f3da:	mov    0xd0(%rsp),%edx
  81f3e1:	mov    %edx,0x1c(%rcx,%rax,1)
  81f3e5:	addq   $0x2,0x10(%rsi)
  81f3ea:	sub    $0x8,%rsp
  81f3ee:	lea    0x308(%rsp),%rdi
  81f3f6:	lea    0x118(%rsp),%rdx
  81f3fe:	mov    0xf8(%rsp),%rcx
  81f406:	mov    0x98(%rsp),%r8
  81f40e:	mov    0x60(%rsp),%r9
  81f413:	push   0xe8(%rsp)
  81f41a:	push   %r15
  81f41c:	push   %r14
  81f41e:	call   820600 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f423:	add    $0x20,%rsp
  81f427:	mov    0x300(%rsp),%eax
  81f42e:	cmp    $0xffffffff,%eax
  81f431:	jne    81f64e <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  81f437:	cmpb   $0x2,0x60(%rsp)
  81f43c:	sete   %al
  81f43f:	cmpq   $0x0,0x80(%rsp)
  81f448:	setne  %cl
  81f44b:	and    %al,%cl
  81f44d:	mov    0x10(%rsp),%rax
  81f452:	or     %cl,%al
  81f454:	mov    %rax,0x10(%rsp)
  81f459:	mov    0x308(%rsp),%rax
  81f461:	mov    %rax,0xe0(%rsp)
  81f469:	mov    0x40(%rsp),%rcx
  81f46e:	add    $0x4,%rcx
  81f472:	mov    %rcx,0x40(%rsp)
  81f477:	cmp    %rcx,0x370(%rsp)
  81f47f:	jne    81f2a0 <<gpui_gpu::renderer::RendererState>::render+0x1150>
  81f485:	jmp    81f4b7 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81f487:	mov    $0x2,%edx
  81f48c:	mov    $0x4,%ecx
  81f491:	mov    $0x10,%r8d
  81f497:	mov    0x8(%rsp),%rdi
  81f49c:	mov    0x90(%rsp),%rsi
  81f4a4:	call   823bb0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f4a9:	mov    0x8(%rsp),%rax
  81f4ae:	mov    0x10(%rax),%rax
  81f4b2:	jmp    81f3b0 <<gpui_gpu::renderer::RendererState>::render+0x1260>
  81f4b7:	mov    0x10(%rsp),%rax
  81f4bc:	and    $0x1,%al
  81f4be:	mov    %rax,0x10(%rsp)
  81f4c3:	lea    0x248(%rsp),%rdi
  81f4cb:	lea    0x388(%rsp),%rsi
  81f4d3:	call   *0x6607a7(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81f4d9:	mov    0x248(%rsp),%rax
  81f4e1:	mov    %rax,0x18(%rsp)
  81f4e6:	test   %rax,%rax
  81f4e9:	jne    81e7f4 <<gpui_gpu::renderer::RendererState>::render+0x6a4>
  81f4ef:	jmp    81f552 <<gpui_gpu::renderer::RendererState>::render+0x1402>
  81f4f1:	mov    $0x5,%edx
  81f4f6:	mov    $0x4,%ecx
  81f4fb:	mov    $0x10,%r8d
  81f501:	mov    0x8(%rsp),%rdi
  81f506:	call   823bb0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f50b:	mov    0x8(%rsp),%rax
  81f510:	mov    0x10(%rax),%rsi
  81f514:	jmp    81f18c <<gpui_gpu::renderer::RendererState>::render+0x103c>
  81f519:	movq   $0x0,0x208(%rsp)
  81f525:	movq   $0x0,0x200(%rsp)
  81f531:	movq   $0x0,0xb8(%rsp)
  81f53d:	movq   $0x0,0x10(%rsp)
  81f546:	movq   $0x0,0xe0(%rsp)
  81f552:	mov    0x108(%rsp),%rsi
  81f55a:	lea    0x8(%rsi),%rdx
  81f55e:	mov    0x8(%rsp),%rax
  81f563:	lea    0x240(%rax),%rcx
  81f56a:	lea    0x310(%rax),%r8
  81f571:	mov    0x10(%rax),%r9
  81f575:	sub    $0x8,%rsp
  81f579:	lea    0x118(%rsp),%rdi
  81f581:	mov    %rdx,0x3c8(%rsp)
  81f589:	mov    %rcx,0x2b8(%rsp)
  81f591:	mov    %r8,0x2c8(%rsp)
  81f599:	push   0xf0(%rsp)
  81f5a0:	call   822af0 <gpui_gpu::renderer::images::prepare>
  81f5a5:	add    $0x10,%rsp
  81f5a9:	cmpl   $0xffffffff,0x110(%rsp)
  81f5b1:	je     81f5fa <<gpui_gpu::renderer::RendererState>::render+0x14aa>
  81f5b3:	movups 0x110(%rsp),%xmm0
  81f5bb:	movups 0x120(%rsp),%xmm1
  81f5c3:	mov    0x38(%rsp),%rdi
  81f5c8:	movups %xmm1,0x10(%rdi)
  81f5cc:	movups %xmm0,(%rdi)
  81f5cf:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f5d4:	mov    0x23c(%rsp),%edx
  81f5db:	mov    0x38(%rsp),%rdi
  81f5e0:	mov    %edx,0x1c(%rdi)
  81f5e3:	movups 0x22c(%rsp),%xmm0
  81f5eb:	movups %xmm0,0xc(%rdi)
  81f5ef:	mov    %ecx,(%rdi)
  81f5f1:	mov    %rax,0x4(%rdi)
  81f5f5:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f5fa:	movzbl 0x10(%rsp),%r8d
  81f600:	and    $0x1,%r8d
  81f604:	lea    0x110(%rsp),%rdi
  81f60c:	mov    0x8(%rsp),%rsi
  81f611:	mov    0x108(%rsp),%rdx
  81f619:	mov    0xc8(%rsp),%rcx
  81f621:	call   81d8d0 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f626:	mov    0x110(%rsp),%eax
  81f62d:	cmp    $0xffffffff,%eax
  81f630:	je     81f695 <<gpui_gpu::renderer::RendererState>::render+0x1545>
  81f632:	mov    0x114(%rsp),%ecx
  81f639:	mov    0x118(%rsp),%rdx
  81f641:	movups 0x120(%rsp),%xmm0
  81f649:	jmp    81e683 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f64e:	mov    0x304(%rsp),%ecx
  81f655:	mov    0x308(%rsp),%rdx
  81f65d:	movups 0x310(%rsp),%xmm0
  81f665:	jmp    81e683 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f66a:	mov    0x12c(%rsp),%ecx
  81f671:	mov    0x38(%rsp),%rdi
  81f676:	mov    %ecx,0x1c(%rdi)
  81f679:	movups 0x11c(%rsp),%xmm0
  81f681:	movups %xmm0,0xc(%rdi)
  81f685:	mov    %eax,(%rdi)
  81f687:	mov    0x40(%rsp),%rax
  81f68c:	mov    %rax,0x4(%rdi)
  81f690:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f695:	mov    0x118(%rsp),%rax
  81f69d:	mov    %rax,0x3b0(%rsp)
  81f6a5:	mov    0xc8(%rsp),%rax
  81f6ad:	mov    %rax,0x300(%rsp)
  81f6b5:	movq   $0x0,0x308(%rsp)
  81f6c1:	mov    0xc0(%rsp),%rax
  81f6c9:	mov    %rax,0x310(%rsp)
  81f6d1:	mov    0x210(%rsp),%rax
  81f6d9:	mov    %rax,0x318(%rsp)
  81f6e1:	mov    0x78(%rsp),%eax
  81f6e5:	mov    %eax,0x320(%rsp)
  81f6ec:	lea    0x248(%rsp),%rdi
  81f6f4:	lea    0x300(%rsp),%rsi
  81f6fc:	call   *0x66057e(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81f702:	mov    0x248(%rsp),%rax
  81f70a:	mov    %rax,0xa0(%rsp)
  81f712:	test   %rax,%rax
  81f715:	je     81fae6 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f71b:	mov    0x8(%rsp),%rax
  81f720:	add    $0x108,%rax
  81f726:	mov    %rax,0x360(%rsp)
  81f72e:	jmp    81f769 <<gpui_gpu::renderer::RendererState>::render+0x1619>
  81f730:	lea    0x248(%rsp),%rdi
  81f738:	lea    0x300(%rsp),%rsi
  81f740:	call   *0x66053a(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81f746:	mov    0x248(%rsp),%rax
  81f74e:	mov    0x10(%rsp),%rcx
  81f753:	mov    %rcx,0x50(%rsp)
  81f758:	mov    %rax,0xa0(%rsp)
  81f760:	test   %rax,%rax
  81f763:	je     81fae6 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f769:	mov    0x250(%rsp),%rdx
  81f771:	mov    0x258(%rsp),%rdi
  81f779:	mov    %rdi,0x90(%rsp)
  81f781:	lea    0x260(%rsp),%rax
  81f789:	movups 0x40(%rax),%xmm0
  81f78d:	lea    0x128(%rsp),%rcx
  81f795:	movups %xmm0,0x40(%rcx)
  81f799:	movups (%rax),%xmm0
  81f79c:	movups 0x10(%rax),%xmm1
  81f7a0:	movups 0x20(%rax),%xmm2
  81f7a4:	movups 0x30(%rax),%xmm3
  81f7a8:	movups %xmm3,0x30(%rcx)
  81f7ac:	movups %xmm2,0x20(%rcx)
  81f7b0:	movups %xmm1,0x10(%rcx)
  81f7b4:	movups %xmm0,(%rcx)
  81f7b7:	mov    0x8(%rsp),%rax
  81f7bc:	movzbl 0x329(%rax),%esi
  81f7c3:	mov    0xa0(%rsp),%rax
  81f7cb:	mov    %rax,0x110(%rsp)
  81f7d3:	mov    %rdx,0x60(%rsp)
  81f7d8:	mov    %rdx,0x118(%rsp)
  81f7e0:	mov    %rdi,0x120(%rsp)
  81f7e8:	lea    0x110(%rsp),%rdi
  81f7f0:	call   8215e0 <gpui_gpu::renderer::compact_group>
  81f7f5:	mov    0x50(%rsp),%rcx
  81f7fa:	lea    0x5(%rcx),%rdx
  81f7fe:	test   %al,%al
  81f800:	cmove  %rcx,%rdx
  81f804:	mov    %rdx,0x10(%rsp)
  81f809:	cmpq   $0x0,0x90(%rsp)
  81f812:	je     81f730 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81f818:	shlq   $0x2,0x90(%rsp)
  81f821:	xor    $0x1,%al
  81f823:	movzbl %al,%ecx
  81f826:	shl    $0x2,%ecx
  81f829:	lea    0x1(%rcx),%rax
  81f82d:	mov    %rax,0x80(%rsp)
  81f835:	mov    0x10(%rsp),%rax
  81f83a:	lea    (%rax,%rcx,1),%r8
  81f83e:	inc    %r8
  81f841:	or     $0x2,%rcx
  81f845:	shl    $0x4,%r8
  81f849:	mov    %rcx,0x50(%rsp)
  81f84e:	shl    $0x4,%ecx
  81f851:	mov    %rcx,0xd0(%rsp)
  81f859:	xor    %ecx,%ecx
  81f85b:	mov    %r8,0x18(%rsp)
  81f860:	mov    0x60(%rsp),%rax
  81f865:	mov    %rcx,0x30(%rsp)
  81f86a:	mov    (%rax,%rcx,1),%edx
  81f86d:	lea    0x110(%rsp),%rdi
  81f875:	mov    0xa0(%rsp),%rsi
  81f87d:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f882:	movzbl 0x110(%rsp),%ecx
  81f88a:	movzbl 0x111(%rsp),%eax
  81f892:	movss  0x114(%rsp),%xmm4
  81f89b:	lea    0x118(%rsp),%rsi
  81f8a3:	mov    0x10(%rsi),%rdx
  81f8a7:	mov    %rdx,0x2e0(%rsp)
  81f8af:	movups (%rsi),%xmm0
  81f8b2:	movaps %xmm0,0x2d0(%rsp)
  81f8ba:	cmp    $0x1,%ecx
  81f8bd:	je     81f952 <<gpui_gpu::renderer::RendererState>::render+0x1802>
  81f8c3:	movaps %xmm4,0xf0(%rsp)
  81f8cb:	mov    0x130(%rsp),%rsi
  81f8d3:	mov    0x138(%rsp),%edx
  81f8da:	mov    %edx,0x40(%rsp)
  81f8de:	mov    0x13c(%rsp),%edx
  81f8e5:	mov    %edx,0x28(%rsp)
  81f8e9:	cmp    $0x3,%ecx
  81f8ec:	jne    81f9d7 <<gpui_gpu::renderer::RendererState>::render+0x1887>
  81f8f2:	mov    0x2c0(%rsp),%rcx
  81f8fa:	mov    (%rcx),%rdi
  81f8fd:	test   %rdi,%rdi
  81f900:	je     820576 <<gpui_gpu::renderer::RendererState>::render+0x2426>
  81f906:	movzbl %al,%edx
  81f909:	call   822780 <<gpui_gpu::renderer::images::Images>::metadata>
  81f90e:	mov    %eax,%ecx
  81f910:	shr    $0x20,%rax
  81f914:	mov    %eax,%edx
  81f916:	or     $0x10,%edx
  81f919:	xorps  %xmm0,%xmm0
  81f91c:	movaps 0xf0(%rsp),%xmm1
  81f924:	ucomiss %xmm0,%xmm1
  81f927:	cmovne %edx,%eax
  81f92a:	cmovp  %edx,%eax
  81f92d:	mov    0x28(%rsp),%edx
  81f931:	shl    $0x10,%edx
  81f934:	or     0x40(%rsp),%edx
  81f938:	mov    %ecx,0x220(%rsp)
  81f93f:	mov    %eax,0x224(%rsp)
  81f946:	mov    %edx,0x228(%rsp)
  81f94d:	jmp    81fa74 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f952:	movss  0x150(%rsp),%xmm0
  81f95b:	movss  -0x7709f7(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f963:	mulss  %xmm3,%xmm0
  81f967:	movaps %xmm4,%xmm1
  81f96a:	minss  %xmm0,%xmm1
  81f96e:	movaps %xmm1,%xmm0
  81f971:	cmpunordss %xmm1,%xmm0
  81f976:	movaps %xmm0,%xmm2
  81f979:	andnps %xmm1,%xmm2
  81f97c:	andps  %xmm4,%xmm0
  81f97f:	orps   %xmm2,%xmm0
  81f982:	movss  0x154(%rsp),%xmm1
  81f98b:	mulss  %xmm3,%xmm1
  81f98f:	movaps %xmm0,%xmm2
  81f992:	minss  %xmm1,%xmm2
  81f996:	movaps %xmm2,%xmm1
  81f999:	cmpunordss %xmm2,%xmm1
  81f99e:	andps  %xmm1,%xmm0
  81f9a1:	andnps %xmm2,%xmm1
  81f9a4:	orps   %xmm0,%xmm1
  81f9a7:	movd   %xmm1,%eax
  81f9ab:	and    $0xff800000,%eax
  81f9b0:	mov    $0x7f000000,%ecx
  81f9b5:	sub    %eax,%ecx
  81f9b7:	movl   $0x40000000,0x220(%rsp)
  81f9c2:	movss  %xmm1,0x224(%rsp)
  81f9cb:	mov    %ecx,0x228(%rsp)
  81f9d2:	jmp    81fa74 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f9d7:	cmp    $0x2,%cl
  81f9da:	jne    81fa2c <<gpui_gpu::renderer::RendererState>::render+0x18dc>
  81f9dc:	mov    0x140(%rsp),%rax
  81f9e4:	mov    0x2e0(%rsp),%rcx
  81f9ec:	mov    %rcx,0x120(%rsp)
  81f9f4:	movaps 0x2d0(%rsp),%xmm0
  81f9fc:	movaps %xmm0,0x110(%rsp)
  81fa04:	mov    %rsi,0x128(%rsp)
  81fa0c:	mov    0x40(%rsp),%ecx
  81fa10:	mov    %ecx,0x130(%rsp)
  81fa17:	mov    0x28(%rsp),%ecx
  81fa1b:	mov    %ecx,0x134(%rsp)
  81fa22:	mov    %rax,0x138(%rsp)
  81fa2a:	jmp    81fa38 <<gpui_gpu::renderer::RendererState>::render+0x18e8>
  81fa2c:	movq   $0x0,0x110(%rsp)
  81fa38:	movl   $0x0,0x390(%rsp)
  81fa43:	movq   $0x0,0x388(%rsp)
  81fa4f:	lea    0x220(%rsp),%rdi
  81fa57:	lea    0x110(%rsp),%rsi
  81fa5f:	lea    0x388(%rsp),%rdx
  81fa67:	mov    0x360(%rsp),%rcx
  81fa6f:	call   81b790 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fa74:	mov    0x10(%rsp),%rdx
  81fa79:	mov    0x80(%rsp),%rax
  81fa81:	lea    (%rax,%rdx,1),%rdi
  81fa85:	mov    0x8(%rsp),%rax
  81fa8a:	mov    0x10(%rax),%rsi
  81fa8e:	cmp    %rsi,%rdi
  81fa91:	mov    0x18(%rsp),%r8
  81fa96:	jae    82059c <<gpui_gpu::renderer::RendererState>::render+0x244c>
  81fa9c:	mov    0x8(%rax),%rax
  81faa0:	mov    0x228(%rsp),%ecx
  81faa7:	mov    %ecx,0x8(%rax,%r8,1)
  81faac:	mov    0x220(%rsp),%rcx
  81fab4:	mov    %rcx,(%rax,%r8,1)
  81fab8:	add    0x50(%rsp),%rdx
  81fabd:	mov    %rdx,0x10(%rsp)
  81fac2:	add    0xd0(%rsp),%r8
  81faca:	mov    0x30(%rsp),%rcx
  81facf:	add    $0x4,%rcx
  81fad3:	cmp    %rcx,0x90(%rsp)
  81fadb:	jne    81f85b <<gpui_gpu::renderer::RendererState>::render+0x170b>
  81fae1:	jmp    81f730 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81fae6:	cmpl   $0x0,0x58(%rsp)
  81faeb:	je     820583 <<gpui_gpu::renderer::RendererState>::render+0x2433>
  81faf1:	mov    0x8(%rsp),%rax
  81faf6:	mov    0x28(%rax),%rax
  81fafa:	movq   $0x0,0xd0(%rsp)
  81fb06:	mov    %rax,0x18(%rsp)
  81fb0b:	test   %rax,%rax
  81fb0e:	je     81fc43 <<gpui_gpu::renderer::RendererState>::render+0x1af3>
  81fb14:	mov    0x8(%rsp),%rax
  81fb19:	mov    0x20(%rax),%rcx
  81fb1d:	movq   $0x0,0x80(%rsp)
  81fb29:	movq   $0x0,0x50(%rsp)
  81fb32:	movq   $0x0,0x60(%rsp)
  81fb3b:	xor    %edi,%edi
  81fb3d:	movabs $0x10000800000,%r9
  81fb47:	jmp    81fb6f <<gpui_gpu::renderer::RendererState>::render+0x1a1f>
  81fb49:	mov    0x30(%rsp),%rdx
  81fb4e:	lea    (%rcx,%rdx,8),%rcx
  81fb52:	mov    0xd0(%rsp),%rax
  81fb5a:	inc    %eax
  81fb5c:	mov    %rax,0xd0(%rsp)
  81fb64:	sub    %rdx,0x18(%rsp)
  81fb69:	je     81fc37 <<gpui_gpu::renderer::RendererState>::render+0x1ae7>
  81fb6f:	mov    0x58(%rsp),%rax
  81fb74:	mov    0x18(%rsp),%rdx
  81fb79:	cmp    %rdx,%rax
  81fb7c:	cmovb  %rax,%rdx
  81fb80:	mov    0xd0(%rsp),%rax
  81fb88:	shl    $0x4,%eax
  81fb8b:	mov    %r15d,%esi
  81fb8e:	sub    %eax,%esi
  81fb90:	cmp    $0x10,%esi
  81fb93:	mov    $0x10,%eax
  81fb98:	cmovae %eax,%esi
  81fb9b:	mov    %rdx,0x30(%rsp)
  81fba0:	lea    0x0(,%rdx,8),%r10d
  81fba8:	shl    $0x4,%esi
  81fbab:	mov    %esi,0x10(%rsp)
  81fbaf:	xor    %r11d,%r11d
  81fbb2:	mov    %r14d,%edx
  81fbb5:	jmp    81fbd5 <<gpui_gpu::renderer::RendererState>::render+0x1a85>
  81fbb7:	movl   $0x80000000,0x4(%rcx,%r11,1)
  81fbc0:	incq   0x60(%rsp)
  81fbc5:	add    $0xfffffff0,%edx
  81fbc8:	add    $0x8,%r11
  81fbcc:	cmp    %r11,%r10
  81fbcf:	je     81fb49 <<gpui_gpu::renderer::RendererState>::render+0x19f9>
  81fbd5:	mov    0x4(%rcx,%r11,1),%r8d
  81fbda:	mov    %r8d,%eax
  81fbdd:	and    $0x8001ffff,%eax
  81fbe2:	cmp    $0x80000001,%eax
  81fbe7:	je     81fbb7 <<gpui_gpu::renderer::RendererState>::render+0x1a67>
  81fbe9:	mov    %r8d,%esi
  81fbec:	and    $0x1ffff,%esi
  81fbf2:	shl    $0x17,%r8d
  81fbf6:	mov    %rsi,%rax
  81fbf9:	imul   %r9,%rax
  81fbfd:	or     %edi,%r8d
  81fc00:	shr    $0x20,%rax
  81fc04:	mov    %r8d,(%rcx,%r11,1)
  81fc08:	mov    %eax,0x4(%rcx,%r11,1)
  81fc0d:	add    %esi,%edi
  81fc0f:	test   %rsi,%rsi
  81fc12:	je     81fbc5 <<gpui_gpu::renderer::RendererState>::render+0x1a75>
  81fc14:	cmp    $0x10,%edx
  81fc17:	mov    $0x10,%eax
  81fc1c:	cmovb  %edx,%eax
  81fc1f:	imul   0x10(%rsp),%eax
  81fc24:	add    %rax,0x50(%rsp)
  81fc29:	imul   %rax,%rsi
  81fc2d:	add    %rsi,0x80(%rsp)
  81fc35:	jmp    81fbc5 <<gpui_gpu::renderer::RendererState>::render+0x1a75>
  81fc37:	mov    %edi,%eax
  81fc39:	mov    %rax,0xd0(%rsp)
  81fc41:	jmp    81fc61 <<gpui_gpu::renderer::RendererState>::render+0x1b11>
  81fc43:	movq   $0x0,0x60(%rsp)
  81fc4c:	movq   $0x0,0x50(%rsp)
  81fc55:	movq   $0x0,0x80(%rsp)
  81fc61:	mov    0x8(%rsp),%rax
  81fc66:	lea    0x30(%rax),%rdi
  81fc6a:	movq   $0x0,0x40(%rax)
  81fc72:	movl   $0x0,0xf0(%rsp)
  81fc7d:	mov    %rdi,0xa0(%rsp)
  81fc85:	mov    0xd0(%rsp),%rsi
  81fc8d:	xor    %edx,%edx
  81fc8f:	call   8229a0 <<alloc::vec::Vec<u32>>::resize>
  81fc94:	mov    0x8(%rsp),%rax
  81fc99:	mov    0x10(%rax),%rax
  81fc9d:	mov    %rax,0x28(%rsp)
  81fca2:	mov    0xc8(%rsp),%rax
  81fcaa:	mov    %rax,0x2d0(%rsp)
  81fcb2:	movq   $0x0,0x2d8(%rsp)
  81fcbe:	mov    0xc0(%rsp),%rax
  81fcc6:	mov    %rax,0x2e0(%rsp)
  81fcce:	mov    0x210(%rsp),%rax
  81fcd6:	mov    %rax,0x2e8(%rsp)
  81fcde:	mov    0x78(%rsp),%eax
  81fce2:	mov    %eax,0x2f0(%rsp)
  81fce9:	jmp    81fd05 <<gpui_gpu::renderer::RendererState>::render+0x1bb5>
  81fceb:	mov    0x28(%rsp),%rcx
  81fcf0:	lea    -0x5(%rcx),%rax
  81fcf4:	cmpb   $0x0,0xc0(%rsp)
  81fcfc:	cmovne %rax,%rcx
  81fd00:	mov    %rcx,0x28(%rsp)
  81fd05:	lea    0x248(%rsp),%rdi
  81fd0d:	lea    0x2d0(%rsp),%rsi
  81fd15:	call   *0x65ff75(%rip)        # e7fc90 <_DYNAMIC+0x5c8>
  81fd1b:	mov    0x248(%rsp),%rax
  81fd23:	mov    %rax,0x40(%rsp)
  81fd28:	test   %rax,%rax
  81fd2b:	je     81ff5e <<gpui_gpu::renderer::RendererState>::render+0x1e0e>
  81fd31:	mov    0x250(%rsp),%rcx
  81fd39:	mov    0x258(%rsp),%rdx
  81fd41:	mov    %rdx,0x18(%rsp)
  81fd46:	mov    0x8(%rsp),%rax
  81fd4b:	movzbl 0x329(%rax),%esi
  81fd52:	mov    0x40(%rsp),%rax
  81fd57:	mov    %rax,0x110(%rsp)
  81fd5f:	mov    %rcx,0x90(%rsp)
  81fd67:	mov    %rcx,0x118(%rsp)
  81fd6f:	mov    %rdx,0x120(%rsp)
  81fd77:	lea    0x260(%rsp),%rax
  81fd7f:	movups (%rax),%xmm0
  81fd82:	movups 0x10(%rax),%xmm1
  81fd86:	movdqu 0x20(%rax),%xmm2
  81fd8b:	lea    0x128(%rsp),%rdx
  81fd93:	movdqu %xmm2,0x20(%rdx)
  81fd98:	movups %xmm1,0x10(%rdx)
  81fd9c:	movups %xmm0,(%rdx)
  81fd9f:	lea    0x290(%rsp),%rcx
  81fda7:	movups (%rcx),%xmm0
  81fdaa:	movups %xmm0,0x30(%rdx)
  81fdae:	movups 0x40(%rax),%xmm0
  81fdb2:	movups %xmm0,0x40(%rdx)
  81fdb6:	lea    0x110(%rsp),%rdi
  81fdbe:	call   8215e0 <gpui_gpu::renderer::compact_group>
  81fdc3:	mov    %al,0xc0(%rsp)
  81fdca:	mov    0x18(%rsp),%rax
  81fdcf:	test   %rax,%rax
  81fdd2:	je     81fceb <<gpui_gpu::renderer::RendererState>::render+0x1b9b>
  81fdd8:	mov    %rax,%rcx
  81fddb:	shl    $0x2,%rcx
  81fddf:	movzbl 0xc0(%rsp),%eax
  81fde7:	lea    0x0(,%rax,4),%edx
  81fdee:	or     $0xfffffffffffffffa,%rdx
  81fdf2:	xor    %esi,%esi
  81fdf4:	test   %al,%al
  81fdf6:	sete   %sil
  81fdfa:	shl    $0x1f,%esi
  81fdfd:	mov    %esi,0xc8(%rsp)
  81fe04:	mov    %rdx,0x30(%rsp)
  81fe09:	mov    0x28(%rsp),%rax
  81fe0e:	add    %edx,%eax
  81fe10:	mov    %eax,0x10(%rsp)
  81fe14:	mov    %rcx,0x18(%rsp)
  81fe19:	mov    0x90(%rsp),%rax
  81fe21:	mov    -0x4(%rax,%rcx,1),%edx
  81fe25:	lea    0x300(%rsp),%rdi
  81fe2d:	mov    0x40(%rsp),%rsi
  81fe32:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fe37:	mov    0x30(%rsp),%rax
  81fe3c:	add    %rax,0x28(%rsp)
  81fe41:	mov    0xc8(%rsp),%eax
  81fe48:	or     0x10(%rsp),%eax
  81fe4c:	mov    %eax,0x220(%rsp)
  81fe53:	lea    0x260(%rsp),%rdx
  81fe5b:	movups (%rdx),%xmm0
  81fe5e:	movups 0x10(%rdx),%xmm1
  81fe62:	movups 0x20(%rdx),%xmm2
  81fe66:	lea    0x128(%rsp),%rcx
  81fe6e:	movups %xmm2,0x50(%rcx)
  81fe72:	movups %xmm1,0x40(%rcx)
  81fe76:	movups %xmm0,0x30(%rcx)
  81fe7a:	lea    0x290(%rsp),%rax
  81fe82:	movups (%rax),%xmm0
  81fe85:	movups %xmm0,0x60(%rcx)
  81fe89:	movups 0x40(%rdx),%xmm0
  81fe8d:	movups %xmm0,0x80(%rcx)
  81fe94:	lea    0x338(%rsp),%rax
  81fe9c:	movups (%rax),%xmm0
  81fe9f:	movups %xmm0,0x20(%rcx)
  81fea3:	lea    0x348(%rsp),%rax
  81feab:	movups (%rax),%xmm0
  81feae:	movups %xmm0,0x70(%rcx)
  81feb2:	mov    0x330(%rsp),%rax
  81feba:	mov    %rax,0x140(%rsp)
  81fec2:	movups 0x300(%rsp),%xmm0
  81feca:	movups 0x310(%rsp),%xmm1
  81fed2:	movdqu 0x320(%rsp),%xmm2
  81fedb:	movdqa %xmm2,0x130(%rsp)
  81fee4:	movaps %xmm1,0x120(%rsp)
  81feec:	movaps %xmm0,0x110(%rsp)
  81fef4:	mov    0x218(%rsp),%rax
  81fefc:	mov    %rax,0x388(%rsp)
  81ff04:	mov    0xa0(%rsp),%rax
  81ff0c:	mov    %rax,0x390(%rsp)
  81ff14:	lea    0x220(%rsp),%rax
  81ff1c:	mov    %rax,0x398(%rsp)
  81ff24:	lea    0x110(%rsp),%rdi
  81ff2c:	mov    0x58(%rsp),%rsi
  81ff31:	lea    0x388(%rsp),%rdx
  81ff39:	call   81c650 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81ff3e:	mov    0x10(%rsp),%eax
  81ff42:	add    0x30(%rsp),%eax
  81ff46:	mov    %eax,0x10(%rsp)
  81ff4a:	mov    0x18(%rsp),%rcx
  81ff4f:	add    $0xfffffffffffffffc,%rcx
  81ff53:	jne    81fe14 <<gpui_gpu::renderer::RendererState>::render+0x1cc4>
  81ff59:	jmp    81fceb <<gpui_gpu::renderer::RendererState>::render+0x1b9b>
  81ff5e:	test   $0x1,%r12b
  81ff62:	je     81ffb5 <<gpui_gpu::renderer::RendererState>::render+0x1e65>
  81ff64:	movd   0x244(%rsp),%xmm0
  81ff6d:	movd   %xmm0,%eax
  81ff71:	test   %eax,%eax
  81ff73:	setns  %cl
  81ff76:	mov    %eax,%edx
  81ff78:	and    $0x7fffffff,%edx
  81ff7e:	add    $0xff800000,%edx
  81ff84:	cmp    $0x7f000000,%edx
  81ff8a:	setb   %dl
  81ff8d:	and    %cl,%dl
  81ff8f:	dec    %eax
  81ff91:	cmp    $0x7fffff,%eax
  81ff96:	setb   %al
  81ff99:	or     %dl,%al
  81ff9b:	movl   $0x2,0xf0(%rsp)
  81ffa6:	movd   %xmm0,0x104(%rsp)
  81ffaf:	je     82056c <<gpui_gpu::renderer::RendererState>::render+0x241c>
  81ffb5:	mov    0x108(%rsp),%r12
  81ffbd:	lea    0x18(%r12),%rax
  81ffc2:	mov    %rax,0x18(%rsp)
  81ffc7:	mov    0xe8(%rsp),%rax
  81ffcf:	add    $0x18,%rax
  81ffd3:	xor    %ecx,%ecx
  81ffd5:	mov    0x378(%rsp),%rdx
  81ffdd:	cmp    0x380(%rsp),%rdx
  81ffe5:	setne  %cl
  81ffe8:	xor    %edx,%edx
  81ffea:	cmp    $0x28,%r13d
  81ffee:	sete   %dl
  81fff1:	and    $0x1,%ebp
  81fff4:	lea    0x0(%rbp,%rdx,4),%edx
  81fff8:	lea    (%rdx,%rcx,8),%ecx
  81fffb:	or     0xf0(%rsp),%ecx
  820002:	movups (%rax),%xmm0
  820005:	movups %xmm0,0x258(%rsp)
  82000d:	mov    %r14d,0x248(%rsp)
  820015:	mov    %r15d,0x24c(%rsp)
  82001d:	mov    0x58(%rsp),%rax
  820022:	mov    %eax,0x250(%rsp)
  820029:	mov    %ecx,0x254(%rsp)
  820030:	movss  0x104(%rsp),%xmm0
  820039:	movss  %xmm0,0x268(%rsp)
  820042:	movq   $0x0,0x26c(%rsp)
  82004e:	movl   $0x0,0x274(%rsp)
  820059:	mov    0x8(%rsp),%rbp
  82005e:	lea    0x218(%rbp),%rsi
  820065:	movq   $0x0,0x10(%rsp)
  82006e:	lea    0x248(%rsp),%rcx
  820076:	mov    $0x30,%r8d
  82007c:	mov    0x3c0(%rsp),%r13
  820084:	mov    %r13,%rdi
  820087:	mov    %rsi,0x58(%rsp)
  82008c:	xor    %edx,%edx
  82008e:	call   *0x65fc04(%rip)        # e7fc98 <_DYNAMIC+0x5d0>
  820094:	mov    0x8(%rbp),%rcx
  820098:	mov    0x10(%rbp),%r8
  82009c:	shl    $0x4,%r8
  8200a0:	mov    0x2b0(%rsp),%rdi
  8200a8:	mov    %r12,%rsi
  8200ab:	mov    %r13,%rdx
  8200ae:	call   81ccb0 <<gpui_gpu::renderer::Buffer>::write>
  8200b3:	lea    0x268(%rbp),%rdi
  8200ba:	mov    0x20(%rbp),%rcx
  8200be:	mov    0x28(%rbp),%r8
  8200c2:	shl    $0x3,%r8
  8200c6:	mov    %rdi,0x30(%rsp)
  8200cb:	mov    %r12,%rsi
  8200ce:	mov    %r13,%rdx
  8200d1:	call   81ccb0 <<gpui_gpu::renderer::Buffer>::write>
  8200d6:	lea    0x290(%rbp),%rdi
  8200dd:	mov    0x38(%rbp),%rcx
  8200e1:	mov    0x40(%rbp),%r8
  8200e5:	shl    $0x2,%r8
  8200e9:	mov    %rdi,0x218(%rsp)
  8200f1:	mov    %r12,%rsi
  8200f4:	mov    %r13,%rdx
  8200f7:	call   81ccb0 <<gpui_gpu::renderer::Buffer>::write>
  8200fc:	lea    0x2b8(%rbp),%rdi
  820103:	mov    0x50(%rbp),%rcx
  820107:	mov    0x58(%rbp),%r8
  82010b:	shl    $0x5,%r8
  82010f:	mov    %rdi,0xe8(%rsp)
  820117:	mov    %r12,%rsi
  82011a:	mov    %r13,%rdx
  82011d:	call   81ccb0 <<gpui_gpu::renderer::Buffer>::write>
  820122:	cmpq   $0x0,0x310(%rbp)
  82012a:	jne    820146 <<gpui_gpu::renderer::RendererState>::render+0x1ff6>
  82012c:	mov    0x8(%rsp),%rax
  820131:	mov    0x10(%rax),%rax
  820135:	cmp    $0x1,%rax
  820139:	adc    $0x0,%rax
  82013d:	shl    $0x4,%rax
  820141:	mov    %rax,0x10(%rsp)
  820146:	mov    0x8(%rsp),%rsi
  82014b:	mov    0x28(%rsi),%rdx
  82014f:	mov    0x40(%rsi),%rax
  820153:	cmp    $0x1,%rdx
  820157:	adc    $0x0,%rdx
  82015b:	shl    $0x3,%rdx
  82015f:	cmp    $0x1,%rax
  820163:	adc    $0x0,%rax
  820167:	mov    0x58(%rsi),%rcx
  82016b:	cmp    $0x1,%rcx
  82016f:	adc    $0x0,%rcx
  820173:	add    $0xb0,%rsi
  82017a:	shl    $0x2,%rax
  82017e:	shl    $0x5,%rcx
  820182:	movq   $0x0,0x110(%rsp)
  82018e:	mov    0x58(%rsp),%rdi
  820193:	mov    %rdi,0x118(%rsp)
  82019b:	movq   $0x0,0x138(%rsp)
  8201a7:	xorps  %xmm0,%xmm0
  8201aa:	movups %xmm0,0x120(%rsp)
  8201b2:	movl   $0x0,0x130(%rsp)
  8201bd:	mov    0x2b0(%rsp),%rdi
  8201c5:	mov    %rdi,0x140(%rsp)
  8201cd:	movq   $0x0,0x148(%rsp)
  8201d9:	mov    0x10(%rsp),%rdi
  8201de:	mov    %rdi,0x150(%rsp)
  8201e6:	movl   $0x1,0x158(%rsp)
  8201f1:	movq   $0x0,0x160(%rsp)
  8201fd:	mov    0x30(%rsp),%rdi
  820202:	mov    %rdi,0x168(%rsp)
  82020a:	movq   $0x0,0x170(%rsp)
  820216:	mov    %rdx,0x178(%rsp)
  82021e:	movl   $0x2,0x180(%rsp)
  820229:	movq   $0x0,0x188(%rsp)
  820235:	mov    0x218(%rsp),%rdx
  82023d:	mov    %rdx,0x190(%rsp)
  820245:	movq   $0x0,0x198(%rsp)
  820251:	mov    %rax,0x1a0(%rsp)
  820259:	movl   $0x3,0x1a8(%rsp)
  820264:	movq   $0x4,0x1b0(%rsp)
  820270:	mov    %rsi,0x1b8(%rsp)
  820278:	movl   $0x4,0x1d0(%rsp)
  820283:	movq   $0x0,0x1d8(%rsp)
  82028f:	mov    0xe8(%rsp),%rax
  820297:	mov    %rax,0x1e0(%rsp)
  82029f:	movq   $0x0,0x1e8(%rsp)
  8202ab:	mov    %rcx,0x1f0(%rsp)
  8202b3:	movl   $0x5,0x1f8(%rsp)
  8202be:	lea    -0x74b362(%rip),%rax        # d4f63 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x13d>
  8202c5:	mov    %rax,0x318(%rsp)
  8202cd:	movq   $0xa,0x320(%rsp)
  8202d9:	mov    0x18(%rsp),%rax
  8202de:	mov    %rax,0x300(%rsp)
  8202e6:	lea    0x110(%rsp),%rax
  8202ee:	mov    %rax,0x308(%rsp)
  8202f6:	movq   $0x6,0x310(%rsp)
  820302:	lea    0x300(%rsp),%rsi
  82030a:	mov    0x108(%rsp),%r12
  820312:	mov    %r12,%rdi
  820315:	call   *0x65f985(%rip)        # e7fca0 <_DYNAMIC+0x5d8>
  82031b:	mov    %rax,%r13
  82031e:	mov    %rax,0x2d0(%rsp)
  820326:	lea    0x2d0(%rsp),%rdx
  82032e:	mov    %r12,%rdi
  820331:	mov    0x3e8(%rsp),%rsi
  820339:	call   81d310 <<gpui_gpu::renderer::GpuContext>::submit>
  82033e:	mov    %rax,0x10(%rsp)
  820343:	xor    %ebp,%ebp
  820345:	mov    0x378(%rsp),%rax
  82034d:	cmp    0x380(%rsp),%rax
  820355:	setne  %bpl
  820359:	shl    $0x1f,%ebp
  82035c:	or     %r14d,%ebp
  82035f:	shl    $0x20,%r15
  820363:	or     %r15,%rbp
  820366:	mov    (%rbx),%rax
  820369:	test   %rax,%rax
  82036c:	je     82037d <<gpui_gpu::renderer::RendererState>::render+0x222d>
  82036e:	lock decq (%rax)
  820372:	jne    82037d <<gpui_gpu::renderer::RendererState>::render+0x222d>
  820374:	mov    %rbx,%rdi
  820377:	call   *0x65f863(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  82037d:	mov    0x8(%rsp),%rax
  820382:	mov    %r13,0x318(%rax)
  820389:	mov    %rbp,0x320(%rax)
  820390:	mov    0x10(%rax),%r9
  820394:	mov    0x28(%rax),%rsi
  820398:	mov    0x58(%rax),%rcx
  82039c:	mov    %rcx,0x18(%rsp)
  8203a1:	shl    $0x4,%r9
  8203a5:	mov    0xd0(%rsp),%rdx
  8203ad:	lea    (%r9,%rdx,4),%rdi
  8203b1:	lea    (%rdi,%rsi,8),%rsi
  8203b5:	mov    %rcx,%rdi
  8203b8:	shl    $0x5,%rdi
  8203bc:	lea    (%rdi,%rsi,1),%rcx
  8203c0:	add    $0x30,%rcx
  8203c4:	mov    %rcx,0x58(%rsp)
  8203c9:	mov    0x138(%rax),%esi
  8203cf:	imul   %rsi,%rsi
  8203d3:	mov    0x260(%rax),%r8
  8203da:	add    0x238(%rax),%r8
  8203e1:	add    0x288(%rax),%r8
  8203e8:	add    0x2b0(%rax),%r8
  8203ef:	add    0x2d8(%rax),%r8
  8203f6:	mov    0x2f0(%rax),%rdi
  8203fd:	add    0x2f8(%rax),%rdi
  820404:	mov    0xe0(%rsp),%r11
  82040c:	mov    %r11,%rcx
  82040f:	sub    %rdx,%rcx
  820412:	mov    0xb8(%rsp),%r10
  82041a:	mov    %r10,%r12
  82041d:	mov    0x208(%rsp),%rbp
  820425:	sub    %rbp,%r12
  820428:	mov    0x148(%rax),%rbx
  82042f:	inc    %rbx
  820432:	mov    $0xffffffffffffffff,%r14
  820439:	cmovne %rbx,%r14
  82043d:	mov    (%rax),%rbx
  820440:	shl    $0x4,%rbx
  820444:	mov    0x18(%rax),%r15
  820448:	lea    (%rbx,%r15,8),%rbx
  82044c:	mov    0x30(%rax),%r15
  820450:	lea    (%rbx,%r15,4),%rbx
  820454:	mov    0x48(%rax),%r15
  820458:	shl    $0x5,%r15
  82045c:	add    %rbx,%r15
  82045f:	mov    0x120(%rax),%rbx
  820466:	mov    0x118(%rax),%r13
  82046d:	mov    %r14,0x148(%rax)
  820474:	mov    %r10,0x150(%rax)
  82047b:	lea    (%r11,%r11,1),%r14
  82047f:	mov    %r14,0x158(%rax)
  820486:	movq   $0x1,0x160(%rax)
  820491:	mov    %r10,0x168(%rax)
  820498:	mov    %rdx,0x170(%rax)
  82049f:	mov    %r11,0x178(%rax)
  8204a6:	mov    %rcx,0x180(%rax)
  8204ad:	mov    0x60(%rsp),%rcx
  8204b2:	mov    %rcx,0x188(%rax)
  8204b9:	mov    0x50(%rsp),%rcx
  8204be:	mov    %rcx,0x190(%rax)
  8204c5:	mov    0x80(%rsp),%rcx
  8204cd:	mov    %rcx,0x198(%rax)
  8204d4:	mov    0x58(%rsp),%rcx
  8204d9:	mov    %rcx,0x1a0(%rax)
  8204e0:	mov    %r9,0x1a8(%rax)
  8204e7:	mov    0x200(%rsp),%rdx
  8204ef:	mov    %rdx,0x1b0(%rax)
  8204f6:	mov    %rbp,0x1b8(%rax)
  8204fd:	mov    %r12,0x1c0(%rax)
  820504:	mov    0x3b0(%rsp),%rcx
  82050c:	mov    %rcx,0x1c8(%rax)
  820513:	mov    %r8,0x1d0(%rax)
  82051a:	mov    %rsi,0x1d8(%rax)
  820521:	add    %rbx,%r13
  820524:	mov    %rbx,0x1e0(%rax)
  82052b:	mov    %r13,0x1e8(%rax)
  820532:	mov    %r15,0x1f0(%rax)
  820539:	mov    0x18(%rsp),%rcx
  82053e:	mov    %rcx,0x1f8(%rax)
  820545:	mov    %rdi,0x200(%rax)
  82054c:	movb   $0x0,0x208(%rax)
  820553:	mov    0x38(%rsp),%rdi
  820558:	mov    0x10(%rsp),%rax
  82055d:	mov    %rax,0x8(%rdi)
  820561:	movl   $0xffffffff,(%rdi)
  820567:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  82056c:	mov    0x38(%rsp),%rdi
  820571:	jmp    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  820576:	lea    0x60dc63(%rip),%rdi        # e2e1e0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  82057d:	call   *0x65f725(%rip)        # e7fca8 <_DYNAMIC+0x5e0>
  820583:	lea    -0x74b642(%rip),%rdi        # d4f48 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82058a:	lea    0x60dc37(%rip),%rdx        # e2e1c8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  820591:	mov    $0x37,%esi
  820596:	call   *0x65f444(%rip)        # e7f9e0 <_DYNAMIC+0x318>
  82059c:	lea    0x60dc55(%rip),%rdx        # e2e1f8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  8205a3:	call   *0x65f617(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
  8205a9:	mov    %rax,%r14
  8205ac:	mov    0x8(%rsp),%rax
  8205b1:	mov    %r13,0x318(%rax)
  8205b8:	mov    %rbp,0x320(%rax)
  8205bf:	mov    %r14,%rdi
  8205c2:	call   e2c4b0 <_Unwind_Resume@plt>
  8205c7:	mov    %rax,%r14
  8205ca:	lock decq 0x0(%r13)
  8205cf:	jne    8205f1 <<gpui_gpu::renderer::RendererState>::render+0x24a1>
  8205d1:	lea    0x2d0(%rsp),%rdi
  8205d9:	call   *0x65f601(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  8205df:	jmp    8205f1 <<gpui_gpu::renderer::RendererState>::render+0x24a1>
  8205e1:	call   *0x65f331(%rip)        # e7f918 <_DYNAMIC+0x250>
  8205e7:	mov    %rax,%r14
  8205ea:	movq   $0x0,(%rbx)
  8205f1:	mov    %r14,%rdi
  8205f4:	call   e2c4b0 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4056 frame=792

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820600 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820600:	push   %rbp
  820601:	push   %r15
  820603:	push   %r14
  820605:	push   %r13
  820607:	push   %r12
  820609:	push   %rbx
  82060a:	sub    $0x2e8,%rsp
  820611:	movss  0x88(%rdx),%xmm3
  820619:	movss  -0x771665(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820621:	movaps %xmm3,%xmm1
  820624:	subss  %xmm0,%xmm1
  820628:	cvttss2si %xmm1,%rax
  82062d:	cvttss2si %xmm3,%r10
  820632:	mov    %r10,%r13
  820635:	sar    $0x3f,%r13
  820639:	and    %rax,%r13
  82063c:	or     %r10,%r13
  82063f:	xor    %eax,%eax
  820641:	xorps  %xmm1,%xmm1
  820644:	ucomiss %xmm1,%xmm3
  820647:	cmovb  %rax,%r13
  82064b:	movss  0x90(%rdx),%xmm4
  820653:	movss  -0x77169b(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82065b:	ucomiss %xmm2,%xmm3
  82065e:	mov    $0xffffffffffffffff,%r14
  820665:	cmova  %r14,%r13
  820669:	movaps %xmm4,%xmm3
  82066c:	subss  %xmm0,%xmm3
  820670:	cvttss2si %xmm3,%r10
  820675:	cvttss2si %xmm4,%r11
  82067a:	mov    %r11,%rbx
  82067d:	sar    $0x3f,%rbx
  820681:	and    %r10,%rbx
  820684:	or     %r11,%rbx
  820687:	ucomiss %xmm1,%xmm4
  82068a:	cmovb  %rax,%rbx
  82068e:	ucomiss %xmm2,%xmm4
  820691:	cmova  %r14,%rbx
  820695:	movss  0x8c(%rdx),%xmm3
  82069d:	lea    (%rbx,%r13,1),%r11
  8206a1:	dec    %r11
  8206a4:	shr    $0x4,%r11
  8206a8:	shr    $0x4,%r13
  8206ac:	mov    %r11,%rbp
  8206af:	sub    %r13,%rbp
  8206b2:	inc    %rbp
  8206b5:	movaps %xmm3,%xmm4
  8206b8:	subss  %xmm0,%xmm4
  8206bc:	cvttss2si %xmm4,%r10
  8206c1:	cvttss2si %xmm3,%r15
  8206c6:	mov    %r15,%rbx
  8206c9:	sar    $0x3f,%rbx
  8206cd:	and    %r10,%rbx
  8206d0:	or     %r15,%rbx
  8206d3:	ucomiss %xmm1,%xmm3
  8206d6:	cmovb  %rax,%rbx
  8206da:	ucomiss %xmm2,%xmm3
  8206dd:	movss  0x94(%rdx),%xmm3
  8206e5:	cmova  %r14,%rbx
  8206e9:	movaps %xmm3,%xmm4
  8206ec:	subss  %xmm0,%xmm4
  8206f0:	cvttss2si %xmm4,%r10
  8206f5:	cvttss2si %xmm3,%r15
  8206fa:	mov    %r15,%r12
  8206fd:	sar    $0x3f,%r12
  820701:	and    %r10,%r12
  820704:	or     %r15,%r12
  820707:	ucomiss %xmm1,%xmm3
  82070a:	cmovb  %rax,%r12
  82070e:	ucomiss %xmm2,%xmm3
  820711:	cmova  %r14,%r12
  820715:	lea    (%rbx,%r12,1),%r10
  820719:	dec    %r10
  82071c:	shr    $0x4,%r10
  820720:	shr    $0x4,%rbx
  820724:	mov    %r10,%r14
  820727:	sub    %rbx,%r14
  82072a:	inc    %r14
  82072d:	imul   %rbp,%r14
  820731:	add    0x330(%rsp),%r14
  820739:	setb   %al
  82073c:	cmp    $0x400001,%r14
  820743:	setae  %bpl
  820747:	or     %al,%bpl
  82074a:	mov    $0x6,%eax
  82074f:	jne    82078f <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  820751:	mov    %r8d,0xac(%rsp)
  820759:	mov    %r14,0x170(%rsp)
  820761:	mov    %rdi,0x178(%rsp)
  820769:	mov    %r13,0xa0(%rsp)
  820771:	cmp    %rbx,%r10
  820774:	jae    8207a3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  820776:	mov    0x178(%rsp),%rdi
  82077e:	mov    0x170(%rsp),%rax
  820786:	mov    %rax,0x8(%rdi)
  82078a:	mov    $0xffffffff,%eax
  82078f:	mov    %eax,(%rdi)
  820791:	add    $0x2e8,%rsp
  820798:	pop    %rbx
  820799:	pop    %r12
  82079b:	pop    %r13
  82079d:	pop    %r14
  82079f:	pop    %r15
  8207a1:	pop    %rbp
  8207a2:	ret
  8207a3:	cmp    0xa0(%rsp),%r11
  8207ab:	jae    8207c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  8207ad:	nopl   (%rax)
  8207b0:	mov    %rbx,%rax
  8207b3:	cmp    %r10,%rbx
  8207b6:	adc    $0x0,%rbx
  8207ba:	cmp    %r10,%rax
  8207bd:	jae    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8207bf:	cmp    %r10,%rbx
  8207c2:	jbe    8207b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  8207c4:	jmp    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8207c6:	movd   0xa4(%rdx),%xmm0
  8207ce:	mov    0x20(%rsi),%r12
  8207d2:	movdqu 0x98(%rdx),%xmm1
  8207da:	movd   0xa0(%rdx),%xmm2
  8207e2:	punpckldq %xmm0,%xmm2
  8207e6:	punpcklqdq %xmm2,%xmm1
  8207ea:	movdqa -0x773ee2(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  8207f2:	pand   %xmm1,%xmm2
  8207f6:	paddd  -0x773c8e(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  8207fe:	pxor   -0x7724d6(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  820806:	pcmpgtd -0x77307e(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  82080e:	mov    %rsi,%rax
  820811:	mov    0x28(%rsi),%rsi
  820815:	pandn  %xmm1,%xmm2
  820819:	movmskps %xmm2,%edi
  82081c:	test   %edi,%edi
  82081e:	jne    821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820824:	ucomiss -0x771aab(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82082b:	jne    821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820831:	jp     821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820837:	cmpb   $0x0,0x328(%rax)
  82083e:	je     821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820844:	cmpb   $0x0,(%rdx)
  820847:	jne    821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  82084d:	test   %r9,%r9
  820850:	je     8215bb <<gpui_gpu::renderer::RendererState>::bin_draw+0xfbb>
  820856:	mov    0x328(%rsp),%ebp
  82085d:	mov    0x320(%rsp),%r13d
  820865:	movd   %ecx,%xmm2
  820869:	shr    $0x20,%rcx
  82086d:	movss  0x78(%rdx),%xmm0
  820872:	movss  0x80(%rdx),%xmm3
  82087a:	movss  0x84(%rdx),%xmm4
  820882:	cvtss2sd %xmm0,%xmm0
  820886:	movss  0x7c(%rdx),%xmm1
  82088b:	cvtss2sd %xmm1,%xmm1
  82088f:	cvtss2sd %xmm3,%xmm14
  820894:	addsd  %xmm0,%xmm14
  820899:	xorps  %xmm3,%xmm3
  82089c:	cvtss2sd %xmm4,%xmm3
  8208a0:	addsd  %xmm1,%xmm3
  8208a4:	movsd  %xmm3,0x1a8(%rsp)
  8208ad:	movsd  0x48(%rdx),%xmm6
  8208b2:	movsd  0x58(%rdx),%xmm7
  8208b7:	movsd  0x68(%rdx),%xmm8
  8208bd:	movss  0x38(%rdx),%xmm3
  8208c2:	movss  0x3c(%rdx),%xmm4
  8208c7:	movss  0x40(%rdx),%xmm5
  8208cc:	cvtss2sd %xmm3,%xmm3
  8208d0:	cvtss2sd %xmm5,%xmm5
  8208d4:	movaps -0x775b2c(%rip),%xmm9        # aadb0 <GCC_except_table0+0xb8>
  8208dc:	movaps %xmm3,0x80(%rsp)
  8208e4:	andps  %xmm9,%xmm3
  8208e8:	movaps %xmm3,0x70(%rsp)
  8208ed:	movaps %xmm5,0x50(%rsp)
  8208f2:	cvtss2sd %xmm2,%xmm2
  8208f6:	movsd  %xmm2,0x8(%rsp)
  8208fc:	andps  %xmm9,%xmm5
  820900:	movaps %xmm5,0x60(%rsp)
  820905:	movaps %xmm6,%xmm2
  820908:	andps  %xmm9,%xmm2
  82090c:	movaps %xmm2,0x250(%rsp)
  820914:	movaps %xmm7,%xmm2
  820917:	andps  %xmm9,%xmm2
  82091b:	movaps %xmm2,0x230(%rsp)
  820923:	xorps  %xmm3,%xmm3
  820926:	cvtss2sd %xmm4,%xmm3
  82092a:	movaps %xmm8,%xmm2
  82092e:	andps  %xmm9,%xmm2
  820932:	movaps %xmm2,0xf0(%rsp)
  82093a:	movss  0x44(%rdx),%xmm2
  82093f:	cvtss2sd %xmm2,%xmm2
  820943:	movaps %xmm3,0x40(%rsp)
  820948:	andps  %xmm9,%xmm3
  82094c:	movaps %xmm3,0x30(%rsp)
  820951:	movaps %xmm2,0x10(%rsp)
  820956:	andps  %xmm9,%xmm2
  82095a:	movaps %xmm2,0x20(%rsp)
  82095f:	movd   %ecx,%xmm2
  820963:	cvtss2sd %xmm2,%xmm2
  820967:	movsd  %xmm2,(%rsp)
  82096c:	movsd  0x50(%rdx),%xmm2
  820971:	movaps %xmm2,%xmm3
  820974:	andps  %xmm9,%xmm3
  820978:	movaps %xmm3,0x1d0(%rsp)
  820980:	movsd  0x60(%rdx),%xmm3
  820985:	movaps %xmm3,%xmm4
  820988:	andps  %xmm9,%xmm4
  82098c:	movaps %xmm4,0x1b0(%rsp)
  820994:	movsd  0x70(%rdx),%xmm4
  820999:	movaps %xmm4,%xmm5
  82099c:	andps  %xmm9,%xmm5
  8209a0:	movaps %xmm5,0xb0(%rsp)
  8209a8:	movaps %xmm2,0x1e0(%rsp)
  8209b0:	cvtsd2ss %xmm2,%xmm2
  8209b4:	xorps  %xmm5,%xmm5
  8209b7:	cvtss2sd %xmm2,%xmm5
  8209bb:	movaps %xmm6,0x260(%rsp)
  8209c3:	movaps %xmm6,%xmm2
  8209c6:	movaps %xmm7,0x240(%rsp)
  8209ce:	movlhps %xmm7,%xmm2
  8209d1:	cvtpd2ps %xmm2,%xmm2
  8209d5:	cvtps2pd %xmm2,%xmm6
  8209d8:	movaps %xmm3,0x1c0(%rsp)
  8209e0:	xorps  %xmm2,%xmm2
  8209e3:	cvtsd2ss %xmm3,%xmm2
  8209e7:	xorps  %xmm3,%xmm3
  8209ea:	cvtss2sd %xmm2,%xmm3
  8209ee:	movaps %xmm8,0x100(%rsp)
  8209f7:	xorps  %xmm2,%xmm2
  8209fa:	cvtsd2ss %xmm8,%xmm2
  8209ff:	xorps  %xmm7,%xmm7
  820a02:	cvtss2sd %xmm2,%xmm7
  820a06:	movaps %xmm4,0xc0(%rsp)
  820a0e:	xorps  %xmm2,%xmm2
  820a11:	cvtsd2ss %xmm4,%xmm2
  820a15:	cvtss2sd %xmm2,%xmm2
  820a19:	movaps %xmm6,%xmm4
  820a1c:	andps  %xmm9,%xmm4
  820a20:	movaps %xmm7,0x120(%rsp)
  820a28:	andps  %xmm9,%xmm7
  820a2c:	movaps %xmm7,0x110(%rsp)
  820a34:	movaps %xmm5,0x220(%rsp)
  820a3c:	andps  %xmm9,%xmm5
  820a40:	movaps %xmm5,0x210(%rsp)
  820a48:	movaps %xmm3,0x200(%rsp)
  820a50:	andps  %xmm9,%xmm3
  820a54:	movaps %xmm3,0x1f0(%rsp)
  820a5c:	movaps %xmm2,0xd0(%rsp)
  820a64:	andps  %xmm2,%xmm9
  820a68:	movaps %xmm9,0xe0(%rsp)
  820a71:	movaps %xmm6,0x280(%rsp)
  820a79:	movhlps %xmm6,%xmm6
  820a7c:	movaps %xmm6,0x2b0(%rsp)
  820a84:	movaps %xmm4,0x270(%rsp)
  820a8c:	movhlps %xmm4,%xmm4
  820a8f:	movaps %xmm4,0x2a0(%rsp)
  820a97:	mov    %r10,0x198(%rsp)
  820a9f:	movsd  %xmm14,0x98(%rsp)
  820aa9:	nopl   0x0(%rax)
  820ab0:	mov    %rbx,%r15
  820ab3:	cmp    %r10,%rbx
  820ab6:	adc    $0x0,%rbx
  820aba:	mov    %r15,0x1a0(%rsp)
  820ac2:	imul   %r9,%r15
  820ac6:	mov    0xa0(%rsp),%rdi
  820ace:	mov    %rdi,%r8
  820ad1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820ae0:	cmp    %r11,%rdi
  820ae3:	adc    $0x0,%r8
  820ae7:	lea    (%rdi,%r15,1),%rcx
  820aeb:	mov    %rcx,%rax
  820aee:	shr    $0x20,%rax
  820af2:	je     820b00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x500>
  820af4:	mov    %rcx,%rax
  820af7:	xor    %edx,%edx
  820af9:	div    %r9
  820afc:	jmp    820b07 <<gpui_gpu::renderer::RendererState>::bin_draw+0x507>
  820afe:	xchg   %ax,%ax
  820b00:	mov    %ecx,%eax
  820b02:	xor    %edx,%edx
  820b04:	div    %r9d
  820b07:	shl    $0x4,%edx
  820b0a:	shl    $0x4,%eax
  820b0d:	lea    0x10(%rdx),%r10d
  820b11:	cmp    %r10d,%r13d
  820b14:	cmovb  %r13d,%r10d
  820b18:	lea    0x10(%rax),%r14d
  820b1c:	cmp    %r14d,%ebp
  820b1f:	cmovb  %ebp,%r14d
  820b23:	xorps  %xmm12,%xmm12
  820b27:	cvtsi2sd %edx,%xmm12
  820b2c:	ucomisd %xmm12,%xmm0
  820b31:	ja     820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b33:	mov    %eax,%eax
  820b35:	xorps  %xmm2,%xmm2
  820b38:	cvtsi2sd %rax,%xmm2
  820b3d:	ucomisd %xmm2,%xmm1
  820b41:	ja     820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b43:	xorps  %xmm6,%xmm6
  820b46:	cvtsi2sd %r10d,%xmm6
  820b4b:	ucomisd %xmm14,%xmm6
  820b50:	ja     820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b52:	xorps  %xmm13,%xmm13
  820b56:	cvtsi2sd %r14d,%xmm13
  820b5b:	ucomisd 0x1a8(%rsp),%xmm13
  820b65:	jbe    820b98 <<gpui_gpu::renderer::RendererState>::bin_draw+0x598>
  820b67:	nopw   0x0(%rax,%rax,1)
  820b70:	cmp    %rsi,%rcx
  820b73:	jae    8215ab <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  820b79:	incl   0x4(%r12,%rcx,8)
  820b7e:	cmp    %r11,%rdi
  820b81:	jae    821520 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820b87:	mov    %r8,%rdi
  820b8a:	cmp    %r11,%r8
  820b8d:	jbe    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4e0>
  820b93:	jmp    821520 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820b98:	unpcklpd %xmm2,%xmm12
  820b9d:	addpd  -0x773ad6(%rip),%xmm12        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820ba6:	movapd %xmm12,%xmm10
  820bab:	mulpd  0x280(%rsp),%xmm10
  820bb5:	movapd %xmm10,%xmm15
  820bba:	unpckhpd %xmm10,%xmm15
  820bbf:	movapd %xmm10,%xmm2
  820bc4:	addsd  %xmm15,%xmm2
  820bc9:	addsd  0x120(%rsp),%xmm2
  820bd2:	subsd  0x80(%rsp),%xmm2
  820bdb:	movapd 0x270(%rsp),%xmm8
  820be5:	mulpd  %xmm12,%xmm8
  820bea:	movapd %xmm8,%xmm9
  820bef:	unpckhpd %xmm8,%xmm9
  820bf4:	movapd %xmm8,%xmm3
  820bf9:	addsd  %xmm9,%xmm3
  820bfe:	addsd  0x110(%rsp),%xmm3
  820c07:	addsd  0x70(%rsp),%xmm3
  820c0d:	addsd  0x60(%rsp),%xmm3
  820c13:	addsd  -0x7713a3(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c1b:	mulsd  -0x771423(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820c23:	addsd  0x8(%rsp),%xmm3
  820c29:	ucomisd %xmm2,%xmm3
  820c2d:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c33:	movapd 0x50(%rsp),%xmm4
  820c39:	subsd  %xmm2,%xmm4
  820c3d:	ucomisd %xmm4,%xmm3
  820c41:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c47:	movapd %xmm12,%xmm7
  820c4c:	unpckhpd %xmm12,%xmm7
  820c51:	movapd 0x240(%rsp),%xmm11
  820c5b:	mulsd  %xmm7,%xmm11
  820c60:	movapd 0x230(%rsp),%xmm3
  820c69:	mulsd  %xmm7,%xmm3
  820c6d:	movapd 0x260(%rsp),%xmm2
  820c76:	mulsd  %xmm12,%xmm2
  820c7b:	movapd %xmm2,0x140(%rsp)
  820c84:	addsd  %xmm11,%xmm2
  820c89:	addsd  0x100(%rsp),%xmm2
  820c92:	subsd  0x80(%rsp),%xmm2
  820c9b:	movapd 0x250(%rsp),%xmm4
  820ca4:	mulsd  %xmm12,%xmm4
  820ca9:	movsd  %xmm4,0x190(%rsp)
  820cb2:	addsd  %xmm3,%xmm4
  820cb6:	addsd  0xf0(%rsp),%xmm4
  820cbf:	addsd  0x70(%rsp),%xmm4
  820cc5:	addsd  0x60(%rsp),%xmm4
  820ccb:	addsd  -0x77145b(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cd3:	mulsd  -0x770f03(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820cdb:	ucomisd %xmm2,%xmm4
  820cdf:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ce5:	movapd 0x50(%rsp),%xmm5
  820ceb:	subsd  %xmm2,%xmm5
  820cef:	ucomisd %xmm5,%xmm4
  820cf3:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820cf9:	movapd %xmm7,%xmm4
  820cfd:	mulsd  0x200(%rsp),%xmm4
  820d06:	movapd %xmm7,%xmm2
  820d0a:	mulsd  0x1f0(%rsp),%xmm2
  820d13:	movapd %xmm12,%xmm5
  820d18:	mulsd  0x220(%rsp),%xmm5
  820d21:	movsd  %xmm5,0x188(%rsp)
  820d2a:	movapd %xmm4,0x130(%rsp)
  820d33:	addsd  %xmm4,%xmm5
  820d37:	addsd  0xd0(%rsp),%xmm5
  820d40:	subsd  0x40(%rsp),%xmm5
  820d46:	movapd %xmm12,%xmm4
  820d4b:	mulsd  0x210(%rsp),%xmm4
  820d54:	movsd  %xmm4,0x180(%rsp)
  820d5d:	addsd  %xmm2,%xmm4
  820d61:	addsd  0xe0(%rsp),%xmm4
  820d6a:	addsd  0x30(%rsp),%xmm4
  820d70:	addsd  0x20(%rsp),%xmm4
  820d76:	addsd  -0x771506(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d7e:	mulsd  -0x771586(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820d86:	addsd  (%rsp),%xmm4
  820d8b:	ucomisd %xmm5,%xmm4
  820d8f:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d95:	movapd 0x10(%rsp),%xmm14
  820d9c:	subsd  %xmm5,%xmm14
  820da1:	ucomisd %xmm14,%xmm4
  820da6:	movsd  0x98(%rsp),%xmm14
  820db0:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820db6:	movapd 0x1c0(%rsp),%xmm4
  820dbf:	mulsd  %xmm7,%xmm4
  820dc3:	mulsd  0x1b0(%rsp),%xmm7
  820dcc:	movapd 0x1e0(%rsp),%xmm5
  820dd5:	mulsd  %xmm12,%xmm5
  820dda:	movapd %xmm5,0x2c0(%rsp)
  820de3:	movapd %xmm4,0x2d0(%rsp)
  820dec:	addsd  %xmm4,%xmm5
  820df0:	addsd  0xc0(%rsp),%xmm5
  820df9:	subsd  0x40(%rsp),%xmm5
  820dff:	mulsd  0x1d0(%rsp),%xmm12
  820e09:	movapd %xmm12,%xmm4
  820e0e:	addsd  %xmm7,%xmm4
  820e12:	addsd  0xb0(%rsp),%xmm4
  820e1b:	addsd  0x30(%rsp),%xmm4
  820e21:	addsd  0x20(%rsp),%xmm4
  820e27:	addsd  -0x7715b7(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e2f:	mulsd  -0x77105f(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820e37:	ucomisd %xmm5,%xmm4
  820e3b:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e41:	movapd 0x10(%rsp),%xmm14
  820e48:	subsd  %xmm5,%xmm14
  820e4d:	ucomisd %xmm14,%xmm4
  820e52:	movsd  0x98(%rsp),%xmm14
  820e5c:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e62:	addsd  -0x7718e2(%rip),%xmm6        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820e6a:	movapd %xmm6,%xmm4
  820e6e:	mulsd  0x280(%rsp),%xmm4
  820e77:	movsd  %xmm4,0x168(%rsp)
  820e80:	addsd  %xmm4,%xmm15
  820e85:	addsd  0x120(%rsp),%xmm15
  820e8f:	subsd  0x80(%rsp),%xmm15
  820e99:	movapd 0x270(%rsp),%xmm4
  820ea2:	mulsd  %xmm6,%xmm4
  820ea6:	movsd  %xmm4,0x160(%rsp)
  820eaf:	addsd  %xmm4,%xmm9
  820eb4:	addsd  0x110(%rsp),%xmm9
  820ebe:	addsd  0x70(%rsp),%xmm9
  820ec5:	addsd  0x60(%rsp),%xmm9
  820ecc:	addsd  -0x77165d(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ed5:	mulsd  -0x7716de(%rip),%xmm9        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ede:	addsd  0x8(%rsp),%xmm9
  820ee5:	ucomisd %xmm15,%xmm9
  820eea:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ef0:	movapd 0x50(%rsp),%xmm4
  820ef6:	subsd  %xmm15,%xmm4
  820efb:	ucomisd %xmm4,%xmm9
  820f00:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f06:	movapd 0x260(%rsp),%xmm15
  820f10:	mulsd  %xmm6,%xmm15
  820f15:	addsd  %xmm15,%xmm11
  820f1a:	addsd  0x100(%rsp),%xmm11
  820f24:	subsd  0x80(%rsp),%xmm11
  820f2e:	movapd 0x250(%rsp),%xmm4
  820f37:	mulsd  %xmm6,%xmm4
  820f3b:	movsd  %xmm4,0x158(%rsp)
  820f44:	addsd  %xmm4,%xmm3
  820f48:	addsd  0xf0(%rsp),%xmm3
  820f51:	addsd  0x70(%rsp),%xmm3
  820f57:	addsd  0x60(%rsp),%xmm3
  820f5d:	addsd  -0x7716ed(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f65:	mulsd  -0x771195(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f6d:	ucomisd %xmm11,%xmm3
  820f72:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f78:	movapd 0x50(%rsp),%xmm4
  820f7e:	subsd  %xmm11,%xmm4
  820f83:	ucomisd %xmm4,%xmm3
  820f87:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f8d:	movapd %xmm6,%xmm3
  820f91:	mulsd  0x220(%rsp),%xmm3
  820f9a:	movsd  %xmm3,0x150(%rsp)
  820fa3:	movapd 0x130(%rsp),%xmm5
  820fac:	addsd  %xmm3,%xmm5
  820fb0:	addsd  0xd0(%rsp),%xmm5
  820fb9:	subsd  0x40(%rsp),%xmm5
  820fbf:	movapd %xmm6,%xmm3
  820fc3:	mulsd  0x210(%rsp),%xmm3
  820fcc:	movsd  %xmm3,0x130(%rsp)
  820fd5:	addsd  %xmm3,%xmm2
  820fd9:	addsd  0xe0(%rsp),%xmm2
  820fe2:	addsd  0x30(%rsp),%xmm2
  820fe8:	addsd  0x20(%rsp),%xmm2
  820fee:	addsd  -0x77177e(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ff6:	mulsd  -0x7717fe(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ffe:	addsd  (%rsp),%xmm2
  821003:	ucomisd %xmm5,%xmm2
  821007:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82100d:	movapd 0x10(%rsp),%xmm3
  821013:	subsd  %xmm5,%xmm3
  821017:	ucomisd %xmm3,%xmm2
  82101b:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821021:	movapd 0x1e0(%rsp),%xmm2
  82102a:	mulsd  %xmm6,%xmm2
  82102e:	movapd %xmm2,0x290(%rsp)
  821037:	movapd 0x2d0(%rsp),%xmm4
  821040:	addsd  %xmm2,%xmm4
  821044:	addsd  0xc0(%rsp),%xmm4
  82104d:	subsd  0x40(%rsp),%xmm4
  821053:	mulsd  0x1d0(%rsp),%xmm6
  82105c:	addsd  %xmm6,%xmm7
  821060:	addsd  0xb0(%rsp),%xmm7
  821069:	addsd  0x30(%rsp),%xmm7
  82106f:	addsd  0x20(%rsp),%xmm7
  821075:	addsd  -0x771805(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82107d:	mulsd  -0x7712ad(%rip),%xmm7        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821085:	ucomisd %xmm4,%xmm7
  821089:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82108f:	movapd 0x10(%rsp),%xmm2
  821095:	subsd  %xmm4,%xmm2
  821099:	ucomisd %xmm2,%xmm7
  82109d:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8210a3:	addsd  -0x771b24(%rip),%xmm13        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8210ac:	movapd %xmm13,%xmm3
  8210b1:	mulsd  0x2b0(%rsp),%xmm3
  8210ba:	movapd %xmm13,%xmm2
  8210bf:	mulsd  0x2a0(%rsp),%xmm2
  8210c8:	addsd  %xmm3,%xmm10
  8210cd:	addsd  0x120(%rsp),%xmm10
  8210d7:	subsd  0x80(%rsp),%xmm10
  8210e1:	addsd  %xmm2,%xmm8
  8210e6:	addsd  0x110(%rsp),%xmm8
  8210f0:	addsd  0x70(%rsp),%xmm8
  8210f7:	addsd  0x60(%rsp),%xmm8
  8210fe:	addsd  -0x77188f(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821107:	mulsd  -0x771910(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821110:	addsd  0x8(%rsp),%xmm8
  821117:	ucomisd %xmm10,%xmm8
  82111c:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821122:	movapd 0x50(%rsp),%xmm4
  821128:	subsd  %xmm10,%xmm4
  82112d:	ucomisd %xmm4,%xmm8
  821132:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821138:	movapd 0x240(%rsp),%xmm7
  821141:	mulsd  %xmm13,%xmm7
  821146:	movapd 0x230(%rsp),%xmm5
  82114f:	mulsd  %xmm13,%xmm5
  821154:	movapd 0x140(%rsp),%xmm4
  82115d:	addsd  %xmm7,%xmm4
  821161:	addsd  0x100(%rsp),%xmm4
  82116a:	subsd  0x80(%rsp),%xmm4
  821173:	movsd  0x190(%rsp),%xmm10
  82117d:	addsd  %xmm5,%xmm10
  821182:	addsd  0xf0(%rsp),%xmm10
  82118c:	addsd  0x70(%rsp),%xmm10
  821193:	addsd  0x60(%rsp),%xmm10
  82119a:	addsd  -0x77192b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211a3:	mulsd  -0x7713d4(%rip),%xmm10        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8211ac:	ucomisd %xmm4,%xmm10
  8211b1:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211b7:	movapd %xmm4,%xmm8
  8211bc:	movapd 0x50(%rsp),%xmm4
  8211c2:	subsd  %xmm8,%xmm4
  8211c7:	ucomisd %xmm4,%xmm10
  8211cc:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211d2:	movapd %xmm13,%xmm8
  8211d7:	mulsd  0x200(%rsp),%xmm8
  8211e1:	movapd %xmm13,%xmm10
  8211e6:	mulsd  0x1f0(%rsp),%xmm10
  8211f0:	movsd  0x188(%rsp),%xmm9
  8211fa:	addsd  %xmm8,%xmm9
  8211ff:	addsd  0xd0(%rsp),%xmm9
  821209:	subsd  0x40(%rsp),%xmm9
  821210:	movapd %xmm15,%xmm4
  821215:	movsd  0x180(%rsp),%xmm15
  82121f:	movsd  %xmm10,0x140(%rsp)
  821229:	addsd  %xmm10,%xmm15
  82122e:	addsd  0xe0(%rsp),%xmm15
  821238:	addsd  0x30(%rsp),%xmm15
  82123f:	addsd  0x20(%rsp),%xmm15
  821246:	addsd  -0x7719d7(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82124f:	mulsd  -0x771a58(%rip),%xmm15        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821258:	addsd  (%rsp),%xmm15
  82125e:	ucomisd %xmm9,%xmm15
  821263:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821269:	movapd %xmm9,%xmm10
  82126e:	movapd 0x10(%rsp),%xmm9
  821275:	subsd  %xmm10,%xmm9
  82127a:	ucomisd %xmm9,%xmm15
  82127f:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821285:	movapd 0x1c0(%rsp),%xmm9
  82128f:	mulsd  %xmm13,%xmm9
  821294:	mulsd  0x1b0(%rsp),%xmm13
  82129e:	movapd 0x2c0(%rsp),%xmm10
  8212a8:	addsd  %xmm9,%xmm10
  8212ad:	addsd  0xc0(%rsp),%xmm10
  8212b7:	subsd  0x40(%rsp),%xmm10
  8212be:	addsd  %xmm13,%xmm12
  8212c3:	addsd  0xb0(%rsp),%xmm12
  8212cd:	addsd  0x30(%rsp),%xmm12
  8212d4:	addsd  0x20(%rsp),%xmm12
  8212db:	addsd  -0x771a6c(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212e4:	mulsd  -0x771515(%rip),%xmm12        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8212ed:	ucomisd %xmm10,%xmm12
  8212f2:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8212f8:	movapd %xmm10,%xmm11
  8212fd:	movapd 0x10(%rsp),%xmm10
  821304:	subsd  %xmm11,%xmm10
  821309:	ucomisd %xmm10,%xmm12
  82130e:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821314:	movsd  0x168(%rsp),%xmm10
  82131e:	addsd  %xmm3,%xmm10
  821323:	addsd  0x120(%rsp),%xmm10
  82132d:	subsd  0x80(%rsp),%xmm10
  821337:	movsd  0x160(%rsp),%xmm11
  821341:	addsd  %xmm2,%xmm11
  821346:	addsd  0x110(%rsp),%xmm11
  821350:	addsd  0x70(%rsp),%xmm11
  821357:	addsd  0x60(%rsp),%xmm11
  82135e:	addsd  -0x771aef(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821367:	mulsd  -0x771b70(%rip),%xmm11        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821370:	addsd  0x8(%rsp),%xmm11
  821377:	ucomisd %xmm10,%xmm11
  82137c:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821382:	movapd %xmm4,%xmm15
  821387:	movapd 0x50(%rsp),%xmm2
  82138d:	subsd  %xmm10,%xmm2
  821392:	ucomisd %xmm2,%xmm11
  821397:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82139d:	addsd  %xmm7,%xmm15
  8213a2:	addsd  0x100(%rsp),%xmm15
  8213ac:	subsd  0x80(%rsp),%xmm15
  8213b6:	movsd  0x158(%rsp),%xmm2
  8213bf:	addsd  %xmm5,%xmm2
  8213c3:	addsd  0xf0(%rsp),%xmm2
  8213cc:	addsd  0x70(%rsp),%xmm2
  8213d2:	addsd  0x60(%rsp),%xmm2
  8213d8:	addsd  -0x771b68(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213e0:	mulsd  -0x771610(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8213e8:	ucomisd %xmm15,%xmm2
  8213ed:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213f3:	movapd %xmm2,%xmm3
  8213f7:	movapd 0x50(%rsp),%xmm2
  8213fd:	subsd  %xmm15,%xmm2
  821402:	ucomisd %xmm2,%xmm3
  821406:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82140c:	movsd  0x150(%rsp),%xmm2
  821415:	addsd  %xmm8,%xmm2
  82141a:	addsd  0xd0(%rsp),%xmm2
  821423:	subsd  0x40(%rsp),%xmm2
  821429:	movsd  0x130(%rsp),%xmm5
  821432:	addsd  0x140(%rsp),%xmm5
  82143b:	addsd  0xe0(%rsp),%xmm5
  821444:	addsd  0x30(%rsp),%xmm5
  82144a:	addsd  0x20(%rsp),%xmm5
  821450:	addsd  -0x771be0(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821458:	mulsd  -0x771c60(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821460:	addsd  (%rsp),%xmm5
  821465:	ucomisd %xmm2,%xmm5
  821469:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82146f:	movapd %xmm2,%xmm3
  821473:	movapd 0x10(%rsp),%xmm2
  821479:	subsd  %xmm3,%xmm2
  82147d:	ucomisd %xmm2,%xmm5
  821481:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821487:	movapd 0x290(%rsp),%xmm2
  821490:	addsd  %xmm9,%xmm2
  821495:	addsd  0xc0(%rsp),%xmm2
  82149e:	subsd  0x40(%rsp),%xmm2
  8214a4:	addsd  %xmm13,%xmm6
  8214a9:	addsd  0xb0(%rsp),%xmm6
  8214b2:	addsd  0x30(%rsp),%xmm6
  8214b8:	addsd  0x20(%rsp),%xmm6
  8214be:	addsd  -0x771c4e(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214c6:	mulsd  -0x7716f6(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8214ce:	ucomisd %xmm2,%xmm6
  8214d2:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8214d8:	movapd %xmm2,%xmm3
  8214dc:	movapd 0x10(%rsp),%xmm2
  8214e2:	subsd  %xmm3,%xmm2
  8214e6:	ucomisd %xmm2,%xmm6
  8214ea:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8214f0:	cmp    %rsi,%rcx
  8214f3:	jae    8215c8 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc8>
  8214f9:	mov    0xac(%rsp),%eax
  821500:	mov    %eax,(%r12,%rcx,8)
  821504:	movl   $0x80000001,0x4(%r12,%rcx,8)
  82150d:	movsd  0x98(%rsp),%xmm14
  821517:	cmp    %r11,%rdi
  82151a:	jb     820b87 <<gpui_gpu::renderer::RendererState>::bin_draw+0x587>
  821520:	mov    0x198(%rsp),%r10
  821528:	cmp    %r10,0x1a0(%rsp)
  821530:	jae    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821536:	cmp    %r10,%rbx
  821539:	jbe    820ab0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4b0>
  82153f:	jmp    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821544:	mov    %rbx,%rax
  821547:	nopw   0x0(%rax,%rax,1)
  821550:	cmp    %r10,%rbx
  821553:	adc    $0x0,%rax
  821557:	mov    %rbx,%rdx
  82155a:	imul   %r9,%rdx
  82155e:	mov    0xa0(%rsp),%rdi
  821566:	cs nopw 0x0(%rax,%rax,1)
  821570:	lea    (%rdi,%rdx,1),%rcx
  821574:	cmp    %rsi,%rcx
  821577:	jae    8215ab <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  821579:	cmp    %r11,%rdi
  82157c:	mov    %rdi,%r8
  82157f:	adc    $0x0,%r8
  821583:	incl   0x4(%r12,%rcx,8)
  821588:	cmp    %r11,%rdi
  82158b:	jae    821595 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf95>
  82158d:	mov    %r8,%rdi
  821590:	cmp    %r11,%r8
  821593:	jbe    821570 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf70>
  821595:	cmp    %r10,%rbx
  821598:	jae    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82159e:	mov    %rax,%rbx
  8215a1:	cmp    %r10,%rax
  8215a4:	jbe    821550 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf50>
  8215a6:	jmp    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8215ab:	lea    0x60cca6(%rip),%rdx        # e2e258 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  8215b2:	mov    %rcx,%rdi
  8215b5:	call   *0x65e605(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
  8215bb:	lea    0x60cd86(%rip),%rdi        # e2e348 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.12798218693442382726+0x10>
  8215c2:	call   *0x65e768(%rip)        # e7fd30 <_DYNAMIC+0x668>
  8215c8:	lea    0x60cca1(%rip),%rdx        # e2e270 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  8215cf:	mov    %rcx,%rdi
  8215d2:	call   *0x65e5e8(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008215e0 <gpui_gpu::renderer::compact_group>:
  8215e0:	xor    %eax,%eax
  8215e2:	test   %esi,%esi
  8215e4:	je     821623 <gpui_gpu::renderer::compact_group+0x43>
  8215e6:	cmpq   $0x2,0x10(%rdi)
  8215eb:	jb     821623 <gpui_gpu::renderer::compact_group+0x43>
  8215ed:	sub    $0x58,%rsp
  8215f1:	mov    (%rdi),%rsi
  8215f4:	mov    0x8(%rdi),%rax
  8215f8:	mov    (%rax),%edx
  8215fa:	mov    %rsp,%rdi
  8215fd:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  821602:	movss  0x4(%rsp),%xmm0
  821608:	cmpb   $0x3,(%rsp)
  82160c:	setne  %cl
  82160f:	xorps  %xmm1,%xmm1
  821612:	ucomiss %xmm1,%xmm0
  821615:	setnp  %dl
  821618:	sete   %al
  82161b:	and    %dl,%al
  82161d:	or     %cl,%al
  82161f:	add    $0x58,%rsp
  821623:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821630 <gpui_gpu::renderer::validate_draw>:
  821630:	push   %rbp
  821631:	push   %r15
  821633:	push   %r14
  821635:	push   %r12
  821637:	push   %rbx
  821638:	sub    $0x80,%rsp
  82163f:	mov    %r8d,%ebp
  821642:	mov    %ecx,%r12d
  821645:	mov    %rdx,%r14
  821648:	mov    %rsi,%r15
  82164b:	mov    %rdi,%rbx
  82164e:	movups 0x88(%rsi),%xmm0
  821655:	movaps %xmm0,0x20(%rsp)
  82165a:	movaps %xmm0,0x70(%rsp)
  82165f:	lea    0x70(%rsp),%rdi
  821664:	call   *0x65e6ce(%rip)        # e7fd38 <_DYNAMIC+0x670>
  82166a:	movaps 0x20(%rsp),%xmm4
  82166f:	test   %al,%al
  821671:	je     8216c7 <gpui_gpu::renderer::validate_draw+0x97>
  821673:	movaps %xmm4,%xmm0
  821676:	unpckhpd %xmm4,%xmm0
  82167a:	xorps  %xmm2,%xmm2
  82167d:	ucomiss %xmm2,%xmm0
  821680:	jne    821684 <gpui_gpu::renderer::validate_draw+0x54>
  821682:	jnp    8216c7 <gpui_gpu::renderer::validate_draw+0x97>
  821684:	movaps %xmm4,%xmm1
  821687:	shufps $0xff,%xmm4,%xmm1
  82168b:	ucomiss %xmm2,%xmm1
  82168e:	jne    821692 <gpui_gpu::renderer::validate_draw+0x62>
  821690:	jnp    8216c7 <gpui_gpu::renderer::validate_draw+0x97>
  821692:	xorps  %xmm3,%xmm3
  821695:	ucomiss %xmm4,%xmm3
  821698:	ja     8216c7 <gpui_gpu::renderer::validate_draw+0x97>
  82169a:	movaps %xmm4,%xmm2
  82169d:	shufps $0x55,%xmm4,%xmm2
  8216a1:	ucomiss %xmm2,%xmm3
  8216a4:	ja     8216c7 <gpui_gpu::renderer::validate_draw+0x97>
  8216a6:	xorps  %xmm3,%xmm3
  8216a9:	cvtsi2ss %r12d,%xmm3
  8216ae:	addss  %xmm4,%xmm0
  8216b2:	ucomiss %xmm3,%xmm0
  8216b5:	ja     8216c7 <gpui_gpu::renderer::validate_draw+0x97>
  8216b7:	xorps  %xmm0,%xmm0
  8216ba:	cvtsi2ss %ebp,%xmm0
  8216be:	addss  %xmm1,%xmm2
  8216c2:	ucomiss %xmm0,%xmm2
  8216c5:	jbe    8216dd <gpui_gpu::renderer::validate_draw+0xad>
  8216c7:	movl   $0x3,(%rbx)
  8216cd:	add    $0x80,%rsp
  8216d4:	pop    %rbx
  8216d5:	pop    %r12
  8216d7:	pop    %r14
  8216d9:	pop    %r15
  8216db:	pop    %rbp
  8216dc:	ret
  8216dd:	movsd  0x48(%r15),%xmm9
  8216e3:	movsd  0x60(%r15),%xmm1
  8216e9:	movupd 0x50(%r15),%xmm2
  8216ef:	movapd %xmm2,%xmm5
  8216f3:	shufpd $0x1,%xmm2,%xmm5
  8216f8:	movupd 0x68(%r15),%xmm0
  8216fe:	cvtpd2ps %xmm5,%xmm8
  821703:	movapd %xmm9,%xmm4
  821708:	unpcklpd %xmm1,%xmm4
  82170c:	cvtpd2ps %xmm4,%xmm7
  821710:	cvtpd2ps %xmm0,%xmm6
  821714:	movapd %xmm6,%xmm3
  821718:	shufps $0x55,%xmm6,%xmm3
  82171c:	movd   %xmm3,%ecx
  821720:	movd   %xmm6,%eax
  821724:	movapd %xmm7,%xmm3
  821728:	shufps $0x14,%xmm8,%xmm3
  82172d:	shufps $0x78,%xmm3,%xmm3
  821731:	andps  -0x773fb8(%rip),%xmm3        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821738:	and    $0x7fffffff,%eax
  82173d:	cmp    $0x7f800000,%eax
  821742:	setge  %al
  821745:	and    $0x7fffffff,%ecx
  82174b:	cmp    $0x7f800000,%ecx
  821751:	setge  %cl
  821754:	pcmpgtd -0x7760ac(%rip),%xmm3        # ab6b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  82175c:	movmskps %xmm3,%edx
  82175f:	test   %edx,%edx
  821761:	jne    8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821763:	test   %al,%al
  821765:	jne    8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821767:	test   %cl,%cl
  821769:	jne    8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  82176b:	movapd %xmm9,%xmm3
  821770:	mulsd  %xmm1,%xmm3
  821774:	movapd %xmm2,%xmm10
  821779:	mulsd  %xmm5,%xmm10
  82177e:	subsd  %xmm10,%xmm3
  821783:	xorpd  %xmm10,%xmm10
  821788:	ucomisd %xmm10,%xmm3
  82178d:	jne    821791 <gpui_gpu::renderer::validate_draw+0x161>
  82178f:	jnp    8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821791:	movq   %xmm3,%rcx
  821796:	movabs $0x7fffffffffffffff,%rax
  8217a0:	and    %rax,%rcx
  8217a3:	movabs $0x7ff0000000000000,%rdx
  8217ad:	cmp    %rdx,%rcx
  8217b0:	jl     8217c1 <gpui_gpu::renderer::validate_draw+0x191>
  8217b2:	movl   $0x5,(%rbx)
  8217b8:	mov    %r14,0x8(%rbx)
  8217bc:	jmp    8216cd <gpui_gpu::renderer::validate_draw+0x9d>
  8217c1:	xorps  %xmm10,%xmm10
  8217c5:	cvtsi2sd %r12d,%xmm10
  8217ca:	cvtsi2sd %ebp,%xmm12
  8217cf:	movsd  %xmm9,%xmm2
  8217d4:	movapd -0x776a2d(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  8217dd:	andpd  %xmm13,%xmm2
  8217e2:	movapd %xmm10,%xmm11
  8217e7:	unpcklpd %xmm12,%xmm11
  8217ec:	movapd %xmm2,%xmm9
  8217f1:	movapd %xmm11,0x50(%rsp)
  8217f8:	mulpd  %xmm11,%xmm9
  8217fd:	movapd %xmm9,%xmm11
  821802:	unpckhpd %xmm9,%xmm11
  821807:	addsd  %xmm9,%xmm11
  82180c:	movapd %xmm0,%xmm9
  821811:	andpd  %xmm13,%xmm9
  821816:	addsd  %xmm11,%xmm9
  82181b:	shufpd $0x2,%xmm5,%xmm1
  821820:	andpd  %xmm13,%xmm1
  821825:	unpcklpd %xmm10,%xmm12
  82182a:	movapd %xmm1,%xmm10
  82182f:	movapd %xmm12,0x40(%rsp)
  821836:	mulpd  %xmm12,%xmm10
  82183b:	movapd %xmm10,%xmm11
  821840:	unpckhpd %xmm10,%xmm11
  821845:	addsd  %xmm9,%xmm11
  82184a:	addsd  %xmm10,%xmm11
  82184f:	movapd %xmm0,%xmm10
  821854:	unpckhpd %xmm0,%xmm10
  821859:	andpd  %xmm13,%xmm10
  82185e:	addsd  %xmm11,%xmm10
  821863:	movsd  0x38(%r15),%xmm9
  821869:	movsd  0x40(%r15),%xmm12
  82186f:	andps  -0x7740f7(%rip),%xmm9        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  821877:	cvtps2pd %xmm9,%xmm15
  82187b:	movapd %xmm10,%xmm9
  821880:	addsd  %xmm15,%xmm9
  821885:	movapd %xmm15,0x60(%rsp)
  82188c:	unpckhpd %xmm15,%xmm15
  821891:	addsd  %xmm15,%xmm9
  821896:	cvtps2pd %xmm12,%xmm11
  82189a:	movapd %xmm11,0x20(%rsp)
  8218a1:	andpd  %xmm13,%xmm11
  8218a6:	addsd  %xmm11,%xmm9
  8218ab:	pshufd $0xee,%xmm11,%xmm14
  8218b1:	movdqa %xmm14,0x30(%rsp)
  8218b8:	addsd  %xmm14,%xmm9
  8218bd:	movq   %xmm9,%rsi
  8218c2:	and    %rax,%rsi
  8218c5:	movabs $0x7fefffffffffffff,%rcx
  8218cf:	cmp    %rcx,%rsi
  8218d2:	jg     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  8218d8:	ucomisd -0x7722c9(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  8218e1:	ja     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  8218e7:	movzbl (%r15),%esi
  8218eb:	cmp    $0x3,%esi
  8218ee:	je     821906 <gpui_gpu::renderer::validate_draw+0x2d6>
  8218f0:	xorpd  %xmm14,%xmm14
  8218f5:	cmp    $0x1,%esi
  8218f8:	jne    821a32 <gpui_gpu::renderer::validate_draw+0x402>
  8218fe:	movss  0x4(%r15),%xmm14
  821904:	jmp    82191d <gpui_gpu::renderer::validate_draw+0x2ed>
  821906:	movss  0x4(%r15),%xmm14
  82190c:	xorpd  %xmm13,%xmm13
  821911:	ucomiss %xmm13,%xmm14
  821915:	jne    82191d <gpui_gpu::renderer::validate_draw+0x2ed>
  821917:	jnp    821b57 <gpui_gpu::renderer::validate_draw+0x527>
  82191d:	movd   %xmm14,%edi
  821922:	test   %edi,%edi
  821924:	sets   %r8b
  821928:	and    $0x7fffffff,%edi
  82192e:	lea    -0x800000(%rdi),%r9d
  821935:	cmp    $0x7f000000,%r9d
  82193c:	setb   %r9b
  821940:	and    %r8b,%r9b
  821943:	lea    -0x1(%rdi),%r10d
  821947:	cmp    $0x7fffff,%r10d
  82194e:	setb   %r10b
  821952:	and    %r8b,%r10b
  821955:	cmp    $0x7f800000,%edi
  82195b:	sete   %dil
  82195f:	setg   %r8b
  821963:	or     %dil,%r8b
  821966:	or     %r10b,%r8b
  821969:	or     %r9b,%r8b
  82196c:	cmp    $0x1,%r8b
  821970:	je     8216c7 <gpui_gpu::renderer::validate_draw+0x97>
  821976:	movaps %xmm11,(%rsp)
  82197b:	movaps %xmm14,%xmm11
  82197f:	movaps %xmm14,0x10(%rsp)
  821985:	movaps %xmm12,%xmm14
  821989:	mulss  -0x772a26(%rip),%xmm14        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821992:	minss  %xmm14,%xmm11
  821997:	movaps %xmm11,%xmm14
  82199b:	cmpunordss %xmm11,%xmm14
  8219a1:	movaps %xmm14,%xmm13
  8219a5:	andnps %xmm11,%xmm13
  8219a9:	andps  0x10(%rsp),%xmm14
  8219af:	orps   %xmm13,%xmm14
  8219b3:	shufps $0x55,%xmm12,%xmm12
  8219b8:	mulss  -0x772a55(%rip),%xmm12        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  8219c1:	movaps %xmm14,%xmm11
  8219c5:	minss  %xmm12,%xmm11
  8219ca:	movaps %xmm11,%xmm12
  8219ce:	cmpunordss %xmm11,%xmm12
  8219d4:	andps  %xmm12,%xmm14
  8219d8:	andnps %xmm11,%xmm12
  8219dc:	orps   %xmm14,%xmm12
  8219e0:	movss  -0x772799(%rip),%xmm11        # af250 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  8219e9:	ucomiss %xmm12,%xmm11
  8219ed:	ja     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  8219f3:	xorps  %xmm14,%xmm14
  8219f7:	cvtss2sd %xmm12,%xmm14
  8219fc:	movapd %xmm9,%xmm11
  821a01:	divsd  %xmm14,%xmm11
  821a06:	ucomisd -0x77218f(%rip),%xmm11        # af880 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  821a0f:	ja     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821a15:	addsd  %xmm9,%xmm14
  821a1a:	mulsd  -0x7722fb(%rip),%xmm14        # af728 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821a23:	movapd (%rsp),%xmm11
  821a29:	movapd -0x776c82(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  821a32:	cmp    $0x2,%esi
  821a35:	movaps %xmm11,(%rsp)
  821a3a:	jae    821b4b <gpui_gpu::renderer::validate_draw+0x51b>
  821a40:	cvtps2pd %xmm8,%xmm8
  821a44:	subpd  %xmm8,%xmm5
  821a49:	cvtps2pd %xmm7,%xmm7
  821a4c:	andpd  %xmm13,%xmm5
  821a51:	mulpd  0x40(%rsp),%xmm5
  821a57:	subpd  %xmm7,%xmm4
  821a5b:	andpd  %xmm13,%xmm4
  821a60:	mulpd  0x50(%rsp),%xmm4
  821a66:	addpd  %xmm5,%xmm4
  821a6a:	cvtps2pd %xmm6,%xmm5
  821a6d:	subpd  %xmm5,%xmm0
  821a71:	addsd  -0x772202(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821a7a:	mulsd  -0x77203b(%rip),%xmm10        # afa48 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821a83:	andpd  %xmm13,%xmm0
  821a88:	addpd  %xmm4,%xmm0
  821a8c:	movapd 0x60(%rsp),%xmm7
  821a92:	addsd  %xmm7,%xmm15
  821a97:	movapd (%rsp),%xmm6
  821a9c:	addsd  %xmm6,%xmm15
  821aa1:	addsd  0x30(%rsp),%xmm15
  821aa8:	movapd %xmm0,%xmm4
  821aac:	unpckhpd %xmm0,%xmm4
  821ab0:	addpd  %xmm0,%xmm4
  821ab4:	movapd %xmm1,%xmm5
  821ab8:	shufpd $0x1,%xmm4,%xmm5
  821abd:	movapd %xmm2,%xmm4
  821ac1:	unpcklpd %xmm10,%xmm4
  821ac6:	addpd  %xmm4,%xmm5
  821aca:	mulsd  -0x77247b(%rip),%xmm15        # af658 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821ad3:	shufpd $0x1,%xmm15,%xmm2
  821ad9:	addpd  %xmm5,%xmm2
  821add:	unpcklpd %xmm14,%xmm1
  821ae2:	addpd  %xmm2,%xmm1
  821ae6:	movapd %xmm1,%xmm2
  821aea:	unpckhpd %xmm1,%xmm2
  821aee:	mulsd  %xmm1,%xmm2
  821af2:	andpd  -0x776d4a(%rip),%xmm3        # aadb0 <GCC_except_table0+0xb8>
  821afa:	divsd  %xmm3,%xmm2
  821afe:	movq   %xmm2,%rdx
  821b03:	and    %rax,%rdx
  821b06:	cmp    %rcx,%rdx
  821b09:	jg     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821b0f:	ucomisd -0x771c6f(%rip),%xmm2        # afea8 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821b17:	ja     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821b1d:	unpcklpd %xmm10,%xmm10
  821b22:	addpd  %xmm10,%xmm0
  821b27:	addpd  %xmm7,%xmm6
  821b2b:	mulpd  -0x776ba3(%rip),%xmm6        # aaf90 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821b33:	addpd  %xmm0,%xmm6
  821b37:	cvtpd2ps %xmm6,%xmm0
  821b3b:	movlpd %xmm0,0x4(%rbx)
  821b40:	movl   $0xffffffff,(%rbx)
  821b46:	jmp    8216cd <gpui_gpu::renderer::validate_draw+0x9d>
  821b4b:	jne    821b60 <gpui_gpu::renderer::validate_draw+0x530>
  821b4d:	mov    0x28(%r15),%rsi
  821b51:	mov    0x30(%r15),%rdi
  821b55:	jmp    821b68 <gpui_gpu::renderer::validate_draw+0x538>
  821b57:	movaps %xmm11,(%rsp)
  821b5c:	xorps  %xmm14,%xmm14
  821b60:	mov    0x28(%r15),%esi
  821b64:	mov    0x2c(%r15),%edi
  821b68:	movq   %rsi,%xmm11
  821b6d:	punpckldq -0x7762a6(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821b76:	subpd  -0x776ddf(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821b7f:	movapd %xmm11,%xmm12
  821b84:	unpckhpd %xmm11,%xmm12
  821b89:	addsd  %xmm11,%xmm12
  821b8e:	movapd 0x20(%rsp),%xmm11
  821b95:	divsd  %xmm11,%xmm12
  821b9a:	movq   %xmm12,%r8
  821b9f:	and    %rax,%r8
  821ba2:	cmp    %rdx,%r8
  821ba5:	jge    8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821bab:	movaps %xmm14,0x10(%rsp)
  821bb1:	movapd %xmm11,%xmm14
  821bb6:	movq   %rdi,%xmm11
  821bbb:	punpckldq -0x7762f4(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821bc4:	subpd  -0x776e2d(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821bcd:	movapd %xmm11,%xmm13
  821bd2:	unpckhpd %xmm11,%xmm13
  821bd7:	addsd  %xmm11,%xmm13
  821bdc:	unpckhpd %xmm14,%xmm14
  821be1:	divsd  %xmm14,%xmm13
  821be6:	movapd 0x10(%rsp),%xmm14
  821bed:	movq   %xmm13,%rdx
  821bf2:	and    %rax,%rdx
  821bf5:	cmp    %rcx,%rdx
  821bf8:	setg   %dl
  821bfb:	ucomisd -0x7725ec(%rip),%xmm13        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c04:	movapd -0x776e5d(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  821c0d:	ja     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821c13:	ucomisd -0x772604(%rip),%xmm12        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c1c:	ja     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821c22:	test   %dl,%dl
  821c24:	jne    8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821c2a:	cmp    %rsi,%rdi
  821c2d:	cmova  %rdi,%rsi
  821c31:	movq   %rsi,%xmm11
  821c36:	punpckldq -0x77636f(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821c3f:	subpd  -0x776ea8(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821c48:	movapd %xmm11,%xmm12
  821c4d:	unpckhpd %xmm11,%xmm12
  821c52:	addsd  %xmm11,%xmm12
  821c57:	mulsd  %xmm12,%xmm9
  821c5c:	ucomisd -0x77264d(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c65:	ja     8217b2 <gpui_gpu::renderer::validate_draw+0x182>
  821c6b:	jmp    821a40 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822360 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  822360:	push   %rbx
  822361:	test   %rdi,%rdi
  822364:	je     8223c7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  822366:	mov    %rdi,%rbx
  822369:	mov    (%rdi),%rsi
  82236c:	test   %rsi,%rsi
  82236f:	je     822384 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  822371:	mov    0x8(%rbx),%rdi
  822375:	shl    $0x3,%rsi
  822379:	mov    $0x8,%edx
  82237e:	call   *0x65d58c(%rip)        # e7f910 <_DYNAMIC+0x248>
  822384:	mov    0x20(%rbx),%rsi
  822388:	test   %rsi,%rsi
  82238b:	je     8223b3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82238d:	mov    %rsi,%rax
  822390:	shl    $0x4,%rax
  822394:	add    %rax,%rsi
  822397:	add    $0x21,%rsi
  82239b:	je     8223b3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82239d:	mov    0x18(%rbx),%rdi
  8223a1:	sub    %rax,%rdi
  8223a4:	add    $0xfffffffffffffff0,%rdi
  8223a8:	mov    $0x10,%edx
  8223ad:	call   *0x65d55d(%rip)        # e7f910 <_DYNAMIC+0x248>
  8223b3:	mov    $0x80,%esi
  8223b8:	mov    $0x8,%edx
  8223bd:	mov    %rbx,%rdi
  8223c0:	pop    %rbx
  8223c1:	jmp    *0x65d549(%rip)        # e7f910 <_DYNAMIC+0x248>
  8223c7:	pop    %rbx
  8223c8:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008225f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  8225f0:	push   %r14
  8225f2:	push   %rbx
  8225f3:	push   %rax
  8225f4:	mov    %rdi,%rbx
  8225f7:	mov    (%rdi),%rax
  8225fa:	lock decq (%rax)
  8225fe:	jne    822609 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  822600:	mov    %rbx,%rdi
  822603:	call   *0x65d5c7(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  822609:	mov    0x8(%rbx),%rax
  82260d:	lock decq (%rax)
  822611:	jne    822627 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  822613:	add    $0x8,%rbx
  822617:	mov    %rbx,%rdi
  82261a:	add    $0x8,%rsp
  82261e:	pop    %rbx
  82261f:	pop    %r14
  822621:	jmp    *0x65d5b1(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  822627:	add    $0x8,%rsp
  82262b:	pop    %rbx
  82262c:	pop    %r14
  82262e:	ret
  82262f:	mov    %rax,%r14
  822632:	mov    0x8(%rbx),%rax
  822636:	lock decq (%rax)
  82263a:	jne    822649 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  82263c:	add    $0x8,%rbx
  822640:	mov    %rbx,%rdi
  822643:	call   *0x65d58f(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  822649:	mov    %r14,%rdi
  82264c:	call   e2c4b0 <_Unwind_Resume@plt>
  822651:	call   *0x65d2c1(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822720 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  822720:	push   %rbx
  822721:	mov    %rdi,%rbx
  822724:	mov    (%rdi),%rsi
  822727:	test   %rsi,%rsi
  82272a:	je     82273f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  82272c:	mov    0x8(%rbx),%rdi
  822730:	shl    $0x3,%rsi
  822734:	mov    $0x8,%edx
  822739:	call   *0x65d1d1(%rip)        # e7f910 <_DYNAMIC+0x248>
  82273f:	mov    0x20(%rbx),%rsi
  822743:	test   %rsi,%rsi
  822746:	je     82276f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  822748:	mov    %rsi,%rax
  82274b:	shl    $0x4,%rax
  82274f:	add    %rax,%rsi
  822752:	add    $0x21,%rsi
  822756:	je     82276f <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  822758:	mov    0x18(%rbx),%rdi
  82275c:	sub    %rax,%rdi
  82275f:	add    $0xfffffffffffffff0,%rdi
  822763:	mov    $0x10,%edx
  822768:	pop    %rbx
  822769:	jmp    *0x65d1a1(%rip)        # e7f910 <_DYNAMIC+0x248>
  82276f:	pop    %rbx
  822770:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822780 <<gpui_gpu::renderer::images::Images>::metadata>:
  822780:	push   %r15
  822782:	push   %r14
  822784:	push   %rbx
  822785:	sub    $0x10,%rsp
  822789:	mov    %rsi,0x8(%rsp)
  82278e:	cmpq   $0x0,0x30(%rdi)
  822793:	je     82285d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  822799:	mov    %edx,%ebx
  82279b:	mov    %rsi,%r14
  82279e:	mov    %rdi,%r15
  8227a1:	add    $0x38,%rdi
  8227a5:	lea    0x8(%rsp),%rsi
  8227aa:	call   822020 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8227af:	mov    %rax,%rsi
  8227b2:	shr    $0x39,%rsi
  8227b6:	mov    0x18(%r15),%rcx
  8227ba:	mov    0x20(%r15),%rdx
  8227be:	movd   %esi,%xmm0
  8227c2:	punpcklbw %xmm0,%xmm0
  8227c6:	pshuflw $0x0,%xmm0,%xmm0
  8227cb:	pshufd $0x44,%xmm0,%xmm0
  8227d0:	xor    %esi,%esi
  8227d2:	pcmpeqd %xmm1,%xmm1
  8227d6:	and    %rdx,%rax
  8227d9:	movdqu (%rcx,%rax,1),%xmm2
  8227de:	movdqa %xmm2,%xmm3
  8227e2:	pcmpeqb %xmm0,%xmm3
  8227e6:	pmovmskb %xmm3,%edi
  8227ea:	test   %edi,%edi
  8227ec:	je     822820 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  8227ee:	tzcnt  %edi,%r9d
  8227f3:	add    %rax,%r9
  8227f6:	and    %rdx,%r9
  8227f9:	shl    $0x4,%r9
  8227fd:	mov    %rcx,%r8
  822800:	sub    %r9,%r8
  822803:	cmp    -0x10(%r8),%r14
  822807:	je     822839 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  822809:	lea    -0x1(%rdi),%r8d
  82280d:	and    %di,%r8w
  822811:	mov    %r8d,%edi
  822814:	jne    8227ee <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  822816:	cs nopw 0x0(%rax,%rax,1)
  822820:	pcmpeqb %xmm1,%xmm2
  822824:	pmovmskb %xmm2,%edi
  822828:	test   %edi,%edi
  82282a:	jne    82285d <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  82282c:	add    %rsi,%rax
  82282f:	add    $0x10,%rax
  822833:	add    $0x10,%rsi
  822837:	jmp    8227d6 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  822839:	mov    -0x8(%r8),%eax
  82283d:	movzbl %bl,%ecx
  822840:	or     -0x4(%r8),%ecx
  822844:	shl    $0x20,%rcx
  822848:	or     %rax,%rcx
  82284b:	mov    $0x80000000,%eax
  822850:	or     %rcx,%rax
  822853:	add    $0x10,%rsp
  822857:	pop    %rbx
  822858:	pop    %r14
  82285a:	pop    %r15
  82285c:	ret
  82285d:	lea    -0x74d83c(%rip),%rdi        # d5028 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  822864:	lea    0x60baf5(%rip),%rdx        # e2e360 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456>
  82286b:	mov    $0x16,%esi
  822870:	call   *0x65d3f2(%rip)        # e7fc68 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2648 frame=536

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822af0 <gpui_gpu::renderer::images::prepare>:
  822af0:	push   %rbp
  822af1:	push   %r15
  822af3:	push   %r14
  822af5:	push   %r13
  822af7:	push   %r12
  822af9:	push   %rbx
  822afa:	sub    $0x1e8,%rsp
  822b01:	mov    %r9,%r12
  822b04:	mov    %rcx,%r13
  822b07:	mov    %rdx,0xb0(%rsp)
  822b0f:	mov    %rsi,(%rsp)
  822b13:	mov    %rdi,%r15
  822b16:	mov    0x220(%rsp),%rax
  822b1e:	mov    0x10(%rax),%r14
  822b22:	mov    0x118(%r14),%rax
  822b29:	add    $0x118,%r14
  822b30:	test   %rax,%rax
  822b33:	mov    %r14,%rcx
  822b36:	cmove  %rax,%rcx
  822b3a:	je     822bcc <gpui_gpu::renderer::images::prepare+0xdc>
  822b40:	mov    0x10(%rax),%rax
  822b44:	mov    (%r8),%rbp
  822b47:	mov    %rax,0x10(%rsp)
  822b4c:	test   %rax,%rax
  822b4f:	je     822bcf <gpui_gpu::renderer::images::prepare+0xdf>
  822b51:	mov    %rcx,0xa0(%rsp)
  822b59:	test   %rbp,%rbp
  822b5c:	je     822d18 <gpui_gpu::renderer::images::prepare+0x228>
  822b62:	cmp    0x48(%rbp),%r12
  822b66:	ja     822d18 <gpui_gpu::renderer::images::prepare+0x228>
  822b6c:	mov    0x8(%rbp),%rdi
  822b70:	mov    0x10(%rbp),%rax
  822b74:	lea    (%rdi,%rax,8),%rsi
  822b78:	movq   $0x1,0xd0(%rsp)
  822b84:	mov    %r14,0xd8(%rsp)
  822b8c:	movq   $0x0,0xe0(%rsp)
  822b98:	movq   $0x0,0xf0(%rsp)
  822ba4:	lea    0xd0(%rsp),%rdx
  822bac:	mov    %r8,%rbx
  822baf:	call   825a30 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  822bb4:	mov    %rbx,%r8
  822bb7:	test   %al,%al
  822bb9:	je     822d18 <gpui_gpu::renderer::images::prepare+0x228>
  822bbf:	movq   $0x0,0x60(%rbp)
  822bc7:	jmp    822cfc <gpui_gpu::renderer::images::prepare+0x20c>
  822bcc:	mov    (%r8),%rbp
  822bcf:	movq   $0x0,(%r8)
  822bd6:	test   %rbp,%rbp
  822bd9:	je     822cfc <gpui_gpu::renderer::images::prepare+0x20c>
  822bdf:	mov    0x0(%rbp),%rsi
  822be3:	test   %rsi,%rsi
  822be6:	je     822bfb <gpui_gpu::renderer::images::prepare+0x10b>
  822be8:	mov    0x8(%rbp),%rdi
  822bec:	shl    $0x3,%rsi
  822bf0:	mov    $0x8,%edx
  822bf5:	call   *0x65cd15(%rip)        # e7f910 <_DYNAMIC+0x248>
  822bfb:	mov    0x20(%rbp),%rsi
  822bff:	test   %rsi,%rsi
  822c02:	je     822c2a <gpui_gpu::renderer::images::prepare+0x13a>
  822c04:	mov    %rsi,%rax
  822c07:	shl    $0x4,%rax
  822c0b:	add    %rax,%rsi
  822c0e:	add    $0x21,%rsi
  822c12:	je     822c2a <gpui_gpu::renderer::images::prepare+0x13a>
  822c14:	mov    0x18(%rbp),%rdi
  822c18:	sub    %rax,%rdi
  822c1b:	add    $0xfffffffffffffff0,%rdi
  822c1f:	mov    $0x10,%edx
  822c24:	call   *0x65cce6(%rip)        # e7f910 <_DYNAMIC+0x248>
  822c2a:	mov    $0x80,%esi
  822c2f:	mov    $0x8,%edx
  822c34:	mov    %rbp,%rdi
  822c37:	call   *0x65ccd3(%rip)        # e7f910 <_DYNAMIC+0x248>
  822c3d:	shl    $0x4,%r12
  822c41:	cmp    $0x101,%r12
  822c48:	mov    $0x100,%eax
  822c4d:	cmovae %r12,%rax
  822c51:	dec    %rax
  822c54:	bsr    %rax,%rcx
  822c58:	not    %ecx
  822c5a:	mov    $0xffffffffffffffff,%rbx
  822c61:	shr    %cl,%rbx
  822c64:	inc    %rbx
  822c67:	lea    -0x74dc30(%rip),%rax        # d503e <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x16>
  822c6e:	mov    %rax,0x18(%rsp)
  822c73:	movq   $0xa,0x20(%rsp)
  822c7c:	mov    %rbx,0x28(%rsp)
  822c81:	movl   $0x88,0x30(%rsp)
  822c89:	movb   $0x0,0x34(%rsp)
  822c8e:	lea    0xd0(%rsp),%rdi
  822c96:	lea    0x18(%rsp),%rdx
  822c9b:	mov    (%rsp),%rsi
  822c9f:	call   *0x65d03b(%rip)        # e7fce0 <_DYNAMIC+0x618>
  822ca5:	mov    %rbx,0xf0(%rsp)
  822cad:	mov    0x0(%r13),%rax
  822cb1:	lock decq (%rax)
  822cb5:	jne    822cc0 <gpui_gpu::renderer::images::prepare+0x1d0>
  822cb7:	mov    %r13,%rdi
  822cba:	call   *0x65cf10(%rip)        # e7fbd0 <_DYNAMIC+0x508>
  822cc0:	mov    0x8(%r13),%rax
  822cc4:	lock decq (%rax)
  822cc8:	jne    822cd4 <gpui_gpu::renderer::images::prepare+0x1e4>
  822cca:	lea    0x8(%r13),%rdi
  822cce:	call   *0x65cf04(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  822cd4:	mov    0xf0(%rsp),%rax
  822cdc:	mov    %rax,0x20(%r13)
  822ce0:	movdqu 0xd0(%rsp),%xmm0
  822ce9:	movups 0xe0(%rsp),%xmm1
  822cf1:	movups %xmm1,0x10(%r13)
  822cf6:	movdqu %xmm0,0x0(%r13)
  822cfc:	movl   $0xffffffff,(%r15)
  822d03:	mov    %r15,%rax
  822d06:	add    $0x1e8,%rsp
  822d0d:	pop    %rbx
  822d0e:	pop    %r12
  822d10:	pop    %r13
  822d12:	pop    %r14
  822d14:	pop    %r15
  822d16:	pop    %rbp
  822d17:	ret
  822d18:	cmp    $0x1,%r12
  822d1c:	mov    %r12,%rax
  822d1f:	adc    $0xffffffffffffffff,%rax
  822d23:	bsr    %rax,%rcx
  822d27:	not    %ecx
  822d29:	mov    $0xffffffffffffffff,%rax
  822d30:	shr    %cl,%rax
  822d33:	cmp    $0x2,%r12
  822d37:	mov    $0x0,%r12d
  822d3d:	cmovae %rax,%r12
  822d41:	inc    %r12
  822d44:	je     823438 <gpui_gpu::renderer::images::prepare+0x948>
  822d4a:	mov    %r8,0xc8(%rsp)
  822d52:	mov    %fs:0x0,%rax
  822d5b:	lea    -0x28(%rax),%rax
  822d62:	mov    %rax,%rcx
  822d65:	cmpb   $0x1,0x10(%rax)
  822d69:	mov    %r15,0xa8(%rsp)
  822d71:	mov    %r13,0x8(%rsp)
  822d76:	jne    823444 <gpui_gpu::renderer::images::prepare+0x954>
  822d7c:	mov    (%rcx),%rax
  822d7f:	mov    0x8(%rcx),%rdx
  822d83:	mov    0x10(%rsp),%rbx
  822d88:	lea    0x1(%rax),%rsi
  822d8c:	mov    %rsi,(%rcx)
  822d8f:	movq   $0x0,0x18(%rsp)
  822d98:	movq   $0x8,0x20(%rsp)
  822da1:	movq   $0x0,0x28(%rsp)
  822daa:	movups 0x60b5c7(%rip),%xmm0        # e2e378 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x18>
  822db1:	movups %xmm0,0x30(%rsp)
  822db6:	movdqu 0x60b5ca(%rip),%xmm0        # e2e388 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x28>
  822dbe:	movdqu %xmm0,0x40(%rsp)
  822dc4:	mov    %rax,0x50(%rsp)
  822dc9:	mov    %rdx,0x58(%rsp)
  822dce:	mov    %r12,0x60(%rsp)
  822dd3:	pxor   %xmm0,%xmm0
  822dd7:	movdqu %xmm0,0x68(%rsp)
  822ddd:	movdqu %xmm0,0x78(%rsp)
  822de3:	movdqu %xmm0,0x88(%rsp)
  822dec:	lea    0xd0(%rsp),%rdi
  822df4:	mov    $0x8,%edx
  822df9:	mov    $0x8,%r8d
  822dff:	mov    $0x8,%r9d
  822e05:	xor    %esi,%esi
  822e07:	mov    %rbx,%rcx
  822e0a:	call   823e20 <<alloc::raw_vec::RawVecInner>::finish_grow>
  822e0f:	cmpl   $0x1,0xd0(%rsp)
  822e17:	jne    822e84 <gpui_gpu::renderer::images::prepare+0x394>
  822e19:	mov    0xa8(%rsp),%r15
  822e21:	movl   $0x6,(%r15)
  822e28:	mov    0x18(%rsp),%rsi
  822e2d:	test   %rsi,%rsi
  822e30:	je     822e46 <gpui_gpu::renderer::images::prepare+0x356>
  822e32:	mov    0x20(%rsp),%rdi
  822e37:	shl    $0x3,%rsi
  822e3b:	mov    $0x8,%edx
  822e40:	call   *0x65caca(%rip)        # e7f910 <_DYNAMIC+0x248>
  822e46:	mov    0x38(%rsp),%rsi
  822e4b:	test   %rsi,%rsi
  822e4e:	je     822d03 <gpui_gpu::renderer::images::prepare+0x213>
  822e54:	mov    %rsi,%rax
  822e57:	shl    $0x4,%rax
  822e5b:	add    %rax,%rsi
  822e5e:	add    $0x21,%rsi
  822e62:	je     822d03 <gpui_gpu::renderer::images::prepare+0x213>
  822e68:	mov    0x30(%rsp),%rdi
  822e6d:	sub    %rax,%rdi
  822e70:	add    $0xfffffffffffffff0,%rdi
  822e74:	mov    $0x10,%edx
  822e79:	call   *0x65ca91(%rip)        # e7f910 <_DYNAMIC+0x248>
  822e7f:	jmp    822d03 <gpui_gpu::renderer::images::prepare+0x213>
  822e84:	mov    %r12,0x98(%rsp)
  822e8c:	mov    %rbp,0xc0(%rsp)
  822e94:	mov    0xd8(%rsp),%rax
  822e9c:	mov    %rax,0x20(%rsp)
  822ea1:	mov    %rbx,0x18(%rsp)
  822ea6:	cmp    0x40(%rsp),%rbx
  822eab:	ja     823460 <gpui_gpu::renderer::images::prepare+0x970>
  822eb1:	xor    %r12d,%r12d
  822eb4:	mov    0x98(%rsp),%r15
  822ebc:	jmp    822ed8 <gpui_gpu::renderer::images::prepare+0x3e8>
  822ebe:	xchg   %ax,%ax
  822ec0:	add    $0x8,%r12
  822ec4:	mov    0x20(%rsp),%rax
  822ec9:	mov    %rbx,(%rax,%r15,8)
  822ecd:	inc    %r15
  822ed0:	mov    %r15,0x28(%rsp)
  822ed5:	mov    %r13,%r15
  822ed8:	test   %r12,%r12
  822edb:	je     822f00 <gpui_gpu::renderer::images::prepare+0x410>
  822edd:	cmp    %rbp,%r12
  822ee0:	je     822f00 <gpui_gpu::renderer::images::prepare+0x410>
  822ee2:	mov    (%r12),%rcx
  822ee6:	cmpb   $0x0,0x10(%rcx)
  822eea:	je     822f2e <gpui_gpu::renderer::images::prepare+0x43e>
  822eec:	mov    0x20(%rcx),%rax
  822ef0:	shl    $0x4,%rax
  822ef4:	mov    $0x8,%r8d
  822efa:	jmp    822f41 <gpui_gpu::renderer::images::prepare+0x451>
  822efc:	nopl   0x0(%rax)
  822f00:	test   %r14,%r14
  822f03:	je     822fc8 <gpui_gpu::renderer::images::prepare+0x4d8>
  822f09:	mov    (%r14),%rax
  822f0c:	mov    0x10(%rax),%rcx
  822f10:	test   %rcx,%rcx
  822f13:	je     822fc8 <gpui_gpu::renderer::images::prepare+0x4d8>
  822f19:	mov    0x8(%rax),%r12
  822f1d:	lea    (%r12,%rcx,8),%rbp
  822f21:	xor    %r14d,%r14d
  822f24:	mov    (%r12),%rcx
  822f28:	cmpb   $0x0,0x10(%rcx)
  822f2c:	jne    822eec <gpui_gpu::renderer::images::prepare+0x3fc>
  822f2e:	movzbl 0x11(%rcx),%edx
  822f32:	movzbl 0x12(%rcx),%esi
  822f36:	mov    0x20(%rcx),%rax
  822f3a:	shl    $0x2,%edx
  822f3d:	lea    (%rdx,%rsi,2),%r8d
  822f41:	mov    0x70(%rsp),%rdx
  822f46:	add    %rax,%rdx
  822f49:	jb     822e19 <gpui_gpu::renderer::images::prepare+0x329>
  822f4f:	mov    0x28(%rcx),%rbx
  822f53:	mov    %rdx,0x70(%rsp)
  822f58:	cmp    $0x4000000,%rdx
  822f5f:	ja     822e19 <gpui_gpu::renderer::images::prepare+0x329>
  822f65:	mov    %r15,%rcx
  822f68:	shr    $0x20,%rcx
  822f6c:	jne    822e19 <gpui_gpu::renderer::images::prepare+0x329>
  822f72:	test   %r15d,%r15d
  822f75:	js     822e19 <gpui_gpu::renderer::images::prepare+0x329>
  822f7b:	mov    %rax,%r13
  822f7e:	shr    $0x4,%r13
  822f82:	and    $0xf,%eax
  822f85:	add    %r15,%r13
  822f88:	cmp    $0x1,%rax
  822f8c:	sbb    $0xffffffffffffffff,%r13
  822f90:	lea    0xd0(%rsp),%rdi
  822f98:	lea    0x30(%rsp),%rsi
  822f9d:	mov    %rbx,%rdx
  822fa0:	mov    %r15d,%ecx
  822fa3:	call   8238a0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  822fa8:	mov    0x28(%rsp),%r15
  822fad:	cmp    0x18(%rsp),%r15
  822fb2:	jne    822ec0 <gpui_gpu::renderer::images::prepare+0x3d0>
  822fb8:	lea    0x18(%rsp),%rdi
  822fbd:	call   *0x65cd9d(%rip)        # e7fd60 <_DYNAMIC+0x698>
  822fc3:	jmp    822ec0 <gpui_gpu::renderer::images::prepare+0x3d0>
  822fc8:	movabs $0xffffffffffffff0,%rax
  822fd2:	cmp    %rax,%r15
  822fd5:	ja     822e19 <gpui_gpu::renderer::images::prepare+0x329>
  822fdb:	lea    0xd0(%rsp),%rdi
  822fe3:	mov    (%rsp),%rsi
  822fe7:	call   *0x65cd7b(%rip)        # e7fd68 <_DYNAMIC+0x6a0>
  822fed:	mov    %r15,%rbx
  822ff0:	shl    $0x4,%rbx
  822ff4:	add    $0xff,%rbx
  822ffb:	and    $0xffffffffffffff00,%rbx
  823002:	cmp    0x120(%rsp),%rbx
  82300a:	ja     822e19 <gpui_gpu::renderer::images::prepare+0x329>
  823010:	lea    0xd0(%rsp),%rdi
  823018:	mov    (%rsp),%rsi
  82301c:	call   *0x65cd46(%rip)        # e7fd68 <_DYNAMIC+0x6a0>
  823022:	cmp    0x130(%rsp),%rbx
  82302a:	ja     822e19 <gpui_gpu::renderer::images::prepare+0x329>
  823030:	mov    0x8(%rsp),%rax
  823035:	mov    0x20(%rax),%rax
  823039:	cmp    %rbx,%rax
  82303c:	jb     823064 <gpui_gpu::renderer::images::prepare+0x574>
  82303e:	lea    0x0(,%rbx,4),%rcx
  823046:	movabs $0x3fffffffffffff1,%rdx
  823050:	cmp    %rdx,%r15
  823053:	setb   %dl
  823056:	cmp    %rcx,%rax
  823059:	seta   %al
  82305c:	test   %al,%dl
  82305e:	je     8230f2 <gpui_gpu::renderer::images::prepare+0x602>
  823064:	lea    -0x74e023(%rip),%rax        # d5048 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x20>
  82306b:	mov    %rax,0x1c8(%rsp)
  823073:	movq   $0x1d,0x1d0(%rsp)
  82307f:	mov    %rbx,0x1d8(%rsp)
  823087:	movl   $0x88,0x1e0(%rsp)
  823092:	movb   $0x0,0x1e4(%rsp)
  82309a:	lea    0xd0(%rsp),%rdi
  8230a2:	lea    0x1c8(%rsp),%rdx
  8230aa:	mov    (%rsp),%rsi
  8230ae:	call   *0x65cc2c(%rip)        # e7fce0 <_DYNAMIC+0x618>
  8230b4:	mov    %rbx,0xf0(%rsp)
  8230bc:	mov    0x8(%rsp),%r14
  8230c1:	mov    %r14,%rdi
  8230c4:	call   8225f0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8230c9:	mov    0xf0(%rsp),%rax
  8230d1:	mov    %rax,0x20(%r14)
  8230d5:	movdqu 0xd0(%rsp),%xmm0
  8230de:	movdqu 0xe0(%rsp),%xmm1
  8230e7:	movdqu %xmm1,0x10(%r14)
  8230ed:	movdqu %xmm0,(%r14)
  8230f2:	movq   $0x0,(%rsp)
  8230fa:	mov    0x65cb97(%rip),%r14        # e7fc98 <_DYNAMIC+0x5d0>
  823101:	mov    (%rsp),%rdx
  823105:	test   %rdx,%rdx
  823108:	je     823114 <gpui_gpu::renderer::images::prepare+0x624>
  82310a:	cmp    0xb8(%rsp),%rdx
  823112:	jne    823151 <gpui_gpu::renderer::images::prepare+0x661>
  823114:	mov    0xa0(%rsp),%rax
  82311c:	test   %rax,%rax
  82311f:	je     8232d4 <gpui_gpu::renderer::images::prepare+0x7e4>
  823125:	mov    (%rax),%rax
  823128:	mov    0x10(%rax),%rcx
  82312c:	test   %rcx,%rcx
  82312f:	je     8232d4 <gpui_gpu::renderer::images::prepare+0x7e4>
  823135:	mov    0x8(%rax),%rdx
  823139:	lea    (%rdx,%rcx,8),%rax
  82313d:	mov    %rax,0xb8(%rsp)
  823145:	movq   $0x0,0xa0(%rsp)
  823151:	mov    (%rdx),%rax
  823154:	mov    0x28(%rax),%r12
  823158:	movzbl 0x10(%rax),%ebx
  82315c:	mov    0x18(%rax),%rbp
  823160:	mov    0x20(%rax),%r13
  823164:	mov    %r12,0xd0(%rsp)
  82316c:	cmpq   $0x0,0x48(%rsp)
  823172:	je     8232b9 <gpui_gpu::renderer::images::prepare+0x7c9>
  823178:	add    $0x8,%rdx
  82317c:	mov    %rdx,(%rsp)
  823180:	lea    0x50(%rsp),%rdi
  823185:	lea    0xd0(%rsp),%rsi
  82318d:	call   822020 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  823192:	mov    %rax,%rsi
  823195:	shr    $0x39,%rsi
  823199:	mov    0x30(%rsp),%rcx
  82319e:	mov    0x38(%rsp),%rdx
  8231a3:	movd   %esi,%xmm0
  8231a7:	punpcklbw %xmm0,%xmm0
  8231ab:	pshuflw $0x0,%xmm0,%xmm0
  8231b0:	pshufd $0x44,%xmm0,%xmm0
  8231b5:	xor    %esi,%esi
  8231b7:	and    %rdx,%rax
  8231ba:	movdqu (%rcx,%rax,1),%xmm1
  8231bf:	movdqa %xmm1,%xmm2
  8231c3:	pcmpeqb %xmm0,%xmm2
  8231c7:	pmovmskb %xmm2,%edi
  8231cb:	test   %edi,%edi
  8231cd:	je     8231f7 <gpui_gpu::renderer::images::prepare+0x707>
  8231cf:	tzcnt  %edi,%r9d
  8231d4:	add    %rax,%r9
  8231d7:	and    %rdx,%r9
  8231da:	shl    $0x4,%r9
  8231de:	mov    %rcx,%r8
  8231e1:	sub    %r9,%r8
  8231e4:	cmp    -0x10(%r8),%r12
  8231e8:	je     823218 <gpui_gpu::renderer::images::prepare+0x728>
  8231ea:	lea    -0x1(%rdi),%r8d
  8231ee:	and    %di,%r8w
  8231f2:	mov    %r8d,%edi
  8231f5:	jne    8231cf <gpui_gpu::renderer::images::prepare+0x6df>
  8231f7:	pcmpeqd %xmm2,%xmm2
  8231fb:	pcmpeqb %xmm2,%xmm1
  8231ff:	pmovmskb %xmm1,%edi
  823203:	test   %edi,%edi
  823205:	jne    8232b9 <gpui_gpu::renderer::images::prepare+0x7c9>
  82320b:	add    %rsi,%rax
  82320e:	add    $0x10,%rax
  823212:	add    $0x10,%rsi
  823216:	jmp    8231b7 <gpui_gpu::renderer::images::prepare+0x6c7>
  823218:	mov    -0x8(%r8),%r12d
  82321c:	shl    $0x4,%r12
  823220:	test   %bl,%bl
  823222:	je     823277 <gpui_gpu::renderer::images::prepare+0x787>
  823224:	test   %r13,%r13
  823227:	je     823101 <gpui_gpu::renderer::images::prepare+0x611>
  82322d:	nopl   (%rax)
  823230:	cmp    $0x1000,%r13
  823237:	mov    $0x1000,%r15d
  82323d:	cmovb  %r13,%r15
  823241:	mov    %r15d,%ebx
  823244:	shl    $0x4,%ebx
  823247:	mov    0xb0(%rsp),%rdi
  82324f:	mov    0x8(%rsp),%rsi
  823254:	mov    %r12,%rdx
  823257:	mov    %rbp,%rcx
  82325a:	mov    %rbx,%r8
  82325d:	call   *%r14
  823260:	mov    %r15,%rax
  823263:	shl    $0x4,%rax
  823267:	add    %rax,%rbp
  82326a:	add    %rbx,%r12
  82326d:	sub    %r15,%r13
  823270:	jne    823230 <gpui_gpu::renderer::images::prepare+0x740>
  823272:	jmp    823101 <gpui_gpu::renderer::images::prepare+0x611>
  823277:	test   %r13,%r13
  82327a:	je     823101 <gpui_gpu::renderer::images::prepare+0x611>
  823280:	cmp    $0x10000,%r13
  823287:	mov    $0x10000,%ebx
  82328c:	cmovb  %r13,%rbx
  823290:	mov    0xb0(%rsp),%rdi
  823298:	mov    0x8(%rsp),%rsi
  82329d:	mov    %r12,%rdx
  8232a0:	mov    %rbp,%rcx
  8232a3:	mov    %rbx,%r8
  8232a6:	call   *%r14
  8232a9:	add    %rbx,%rbp
  8232ac:	add    %rbx,%r12
  8232af:	sub    %rbx,%r13
  8232b2:	jne    823280 <gpui_gpu::renderer::images::prepare+0x790>
  8232b4:	jmp    823101 <gpui_gpu::renderer::images::prepare+0x611>
  8232b9:	lea    -0x74e298(%rip),%rdi        # d5028 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  8232c0:	lea    0x60b0d1(%rip),%rdx        # e2e398 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x38>
  8232c7:	mov    $0x16,%esi
  8232cc:	call   *0x65c996(%rip)        # e7fc68 <_DYNAMIC+0x5a0>
  8232d2:	ud2
  8232d4:	mov    0x10(%rsp),%rax
  8232d9:	mov    %rax,0x68(%rsp)
  8232de:	mov    0x70(%rsp),%rax
  8232e3:	mov    %rax,0x78(%rsp)
  8232e8:	mov    0x98(%rsp),%rax
  8232f0:	shl    $0x4,%rax
  8232f4:	mov    %rax,0x80(%rsp)
  8232fc:	mov    0x8(%rsp),%rax
  823301:	mov    0x20(%rax),%rax
  823305:	mov    %rax,0x88(%rsp)
  82330d:	mov    0x40(%rsp),%rax
  823312:	add    0x48(%rsp),%rax
  823317:	mov    %rax,0x90(%rsp)
  82331f:	mov    0x88(%rsp),%rax
  823327:	mov    %rax,0x140(%rsp)
  82332f:	mov    0x90(%rsp),%rax
  823337:	mov    %rax,0x148(%rsp)
  82333f:	mov    0x78(%rsp),%rax
  823344:	mov    %rax,0x130(%rsp)
  82334c:	mov    0x80(%rsp),%rax
  823354:	mov    %rax,0x138(%rsp)
  82335c:	movups 0x68(%rsp),%xmm0
  823361:	movaps %xmm0,0x120(%rsp)
  823369:	movups 0x58(%rsp),%xmm0
  82336e:	movaps %xmm0,0x110(%rsp)
  823376:	movups 0x48(%rsp),%xmm0
  82337b:	movaps %xmm0,0x100(%rsp)
  823383:	movups 0x18(%rsp),%xmm0
  823388:	movups 0x28(%rsp),%xmm1
  82338d:	movups 0x38(%rsp),%xmm2
  823392:	movaps %xmm2,0xf0(%rsp)
  82339a:	movaps %xmm1,0xe0(%rsp)
  8233a2:	movaps %xmm0,0xd0(%rsp)
  8233aa:	call   822ac0 <alloc::boxed::box_new_uninit>
  8233af:	mov    %rax,%rbx
  8233b2:	movaps 0x140(%rsp),%xmm0
  8233ba:	movups %xmm0,0x70(%rax)
  8233be:	movaps 0x130(%rsp),%xmm0
  8233c6:	movups %xmm0,0x60(%rax)
  8233ca:	movaps 0x120(%rsp),%xmm0
  8233d2:	movups %xmm0,0x50(%rax)
  8233d6:	movaps 0x110(%rsp),%xmm0
  8233de:	movups %xmm0,0x40(%rax)
  8233e2:	movdqa 0xd0(%rsp),%xmm0
  8233eb:	movaps 0xe0(%rsp),%xmm1
  8233f3:	movaps 0xf0(%rsp),%xmm2
  8233fb:	movaps 0x100(%rsp),%xmm3
  823403:	movups %xmm3,0x30(%rax)
  823407:	movups %xmm2,0x20(%rax)
  82340b:	movups %xmm1,0x10(%rax)
  82340f:	movdqu %xmm0,(%rax)
  823413:	mov    0xc0(%rsp),%rdi
  82341b:	call   822360 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  823420:	mov    0xc8(%rsp),%rax
  823428:	mov    %rbx,(%rax)
  82342b:	mov    0xa8(%rsp),%r15
  823433:	jmp    822cfc <gpui_gpu::renderer::images::prepare+0x20c>
  823438:	movl   $0x6,(%r15)
  82343f:	jmp    822d03 <gpui_gpu::renderer::images::prepare+0x213>
  823444:	mov    %rcx,%rbx
  823447:	call   *0x65c89b(%rip)        # e7fce8 <_DYNAMIC+0x620>
  82344d:	mov    %rbx,%rcx
  823450:	mov    %rax,(%rbx)
  823453:	mov    %rdx,0x8(%rbx)
  823457:	movb   $0x1,0x10(%rbx)
  82345b:	jmp    822d83 <gpui_gpu::renderer::images::prepare+0x293>
  823460:	lea    0x30(%rsp),%rdi
  823465:	mov    0x10(%rsp),%rsi
  82346a:	lea    0x50(%rsp),%rdx
  82346f:	xor    %ecx,%ecx
  823471:	call   *0x65c8f9(%rip)        # e7fd70 <_DYNAMIC+0x6a8>
  823477:	cmp    $0xffffffffffffffff,%rax
  82347b:	jne    822e19 <gpui_gpu::renderer::images::prepare+0x329>
  823481:	jmp    822eb1 <gpui_gpu::renderer::images::prepare+0x3c1>
  823486:	mov    %rax,%rbx
  823489:	lea    0xd0(%rsp),%rdi
  823491:	call   822720 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823496:	mov    %rbx,%rdi
  823499:	call   e2c4b0 <_Unwind_Resume@plt>
  82349e:	mov    %rax,%rbx
  8234a1:	mov    0xf0(%rsp),%rax
  8234a9:	mov    %rax,0x20(%r14)
  8234ad:	movups 0xd0(%rsp),%xmm0
  8234b5:	movups 0xe0(%rsp),%xmm1
  8234bd:	movups %xmm1,0x10(%r14)
  8234c2:	movups %xmm0,(%r14)
  8234c6:	lea    0x18(%rsp),%rdi
  8234cb:	call   822720 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8234d0:	mov    %rbx,%rdi
  8234d3:	call   e2c4b0 <_Unwind_Resume@plt>
  8234d8:	mov    %r13,%r14
  8234db:	mov    %rax,%rbx
  8234de:	jmp    8234fa <gpui_gpu::renderer::images::prepare+0xa0a>
  8234e0:	mov    %rax,%rbx
  8234e3:	mov    %r13,%r14
  8234e6:	mov    0x8(%r13),%rax
  8234ea:	lock decq (%rax)
  8234ee:	jne    8234fa <gpui_gpu::renderer::images::prepare+0xa0a>
  8234f0:	lea    0x8(%r14),%rdi
  8234f4:	call   *0x65c6de(%rip)        # e7fbd8 <_DYNAMIC+0x510>
  8234fa:	mov    0xf0(%rsp),%rax
  823502:	mov    %rax,0x20(%r14)
  823506:	movups 0xd0(%rsp),%xmm0
  82350e:	movups 0xe0(%rsp),%xmm1
  823516:	movups %xmm1,0x10(%r14)
  82351b:	movups %xmm0,(%r14)
  82351f:	mov    %rbx,%rdi
  823522:	call   e2c4b0 <_Unwind_Resume@plt>
  823527:	call   *0x65c3eb(%rip)        # e7f918 <_DYNAMIC+0x250>
  82352d:	jmp    823533 <gpui_gpu::renderer::images::prepare+0xa43>
  82352f:	jmp    823533 <gpui_gpu::renderer::images::prepare+0xa43>
  823531:	jmp    823533 <gpui_gpu::renderer::images::prepare+0xa43>
  823533:	mov    %rax,%rbx
  823536:	lea    0x18(%rsp),%rdi
  82353b:	call   822720 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823540:	mov    %rbx,%rdi
  823543:	call   e2c4b0 <_Unwind_Resume@plt>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008236b0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  8236b0:	push   %rbp
  8236b1:	push   %r15
  8236b3:	push   %r14
  8236b5:	push   %r13
  8236b7:	push   %r12
  8236b9:	push   %rbx
  8236ba:	sub    $0x38,%rsp
  8236be:	mov    %rcx,%r15
  8236c1:	mov    %rdx,%r12
  8236c4:	mov    %rsi,%r14
  8236c7:	mov    %rdi,%rbx
  8236ca:	lea    0x20(%rsi),%r13
  8236ce:	mov    %r13,%rdi
  8236d1:	mov    %rdx,%rsi
  8236d4:	call   821e80 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8236d9:	cmpq   $0x0,0x10(%r14)
  8236de:	je     823861 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  8236e4:	mov    (%r14),%r11
  8236e7:	mov    0x8(%r14),%rsi
  8236eb:	mov    %rax,%rdx
  8236ee:	shr    $0x39,%rdx
  8236f2:	movd   %edx,%xmm0
  8236f6:	punpcklbw %xmm0,%xmm0
  8236fa:	pshuflw $0x0,%xmm0,%xmm0
  8236ff:	pshufd $0x44,%xmm0,%xmm0
  823704:	mov    (%r12),%rcx
  823708:	mov    %rcx,0x8(%rsp)
  82370d:	movzwl 0xc(%r12),%r9d
  823713:	mov    0x8(%r12),%r10d
  823718:	xor    %r13d,%r13d
  82371b:	pcmpeqd %xmm1,%xmm1
  82371f:	xor    %r8d,%r8d
  823722:	and    %rsi,%rax
  823725:	movdqu (%r11,%rax,1),%xmm2
  82372b:	movdqa %xmm2,%xmm3
  82372f:	pcmpeqb %xmm0,%xmm3
  823733:	pmovmskb %xmm3,%ebp
  823737:	test   %ebp,%ebp
  823739:	je     823780 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  82373b:	mov    %r8,(%rsp)
  82373f:	mov    %r15,%r8
  823742:	tzcnt  %ebp,%r15d
  823747:	add    %rax,%r15
  82374a:	and    %rsi,%r15
  82374d:	shl    $0x5,%r15
  823751:	mov    %r11,%rcx
  823754:	sub    %r15,%rcx
  823757:	mov    0x8(%rsp),%r15
  82375c:	cmp    -0x20(%rcx),%r15
  823760:	jne    82376f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  823762:	cmp    -0x14(%rcx),%r9w
  823767:	jne    82376f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  823769:	cmp    -0x18(%rcx),%r10d
  82376d:	je     8237bf <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  82376f:	lea    -0x1(%rbp),%ecx
  823772:	and    %bp,%cx
  823775:	mov    %ecx,%ebp
  823777:	mov    %r8,%r15
  82377a:	mov    (%rsp),%r8
  82377e:	jne    82373f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  823780:	cmp    $0x1,%r13
  823784:	je     823798 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  823786:	pmovmskb %xmm2,%ecx
  82378a:	test   %ecx,%ecx
  82378c:	je     8237ac <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  82378e:	tzcnt  %ecx,%edi
  823792:	add    %rax,%rdi
  823795:	and    %rsi,%rdi
  823798:	pcmpeqb %xmm1,%xmm2
  82379c:	pmovmskb %xmm2,%ecx
  8237a0:	test   %ecx,%ecx
  8237a2:	jne    8237d6 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  8237a4:	mov    $0x1,%r13d
  8237aa:	jmp    8237af <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  8237ac:	xor    %r13d,%r13d
  8237af:	add    %r8,%rax
  8237b2:	add    $0x10,%rax
  8237b6:	add    $0x10,%r8
  8237ba:	jmp    823722 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  8237bf:	movups -0x10(%rcx),%xmm0
  8237c3:	movups %xmm0,0x4(%rbx)
  8237c7:	movups (%r8),%xmm0
  8237cb:	movups %xmm0,-0x10(%rcx)
  8237cf:	mov    $0x1,%eax
  8237d4:	jmp    82384d <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  8237d6:	movzbl (%r11,%rdi,1),%eax
  8237db:	test   %al,%al
  8237dd:	jns    823882 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  8237e3:	movups (%r12),%xmm0
  8237e8:	movaps %xmm0,0x10(%rsp)
  8237ed:	movups (%r15),%xmm0
  8237f1:	movaps %xmm0,0x20(%rsp)
  8237f6:	and    $0x1,%al
  8237f8:	lea    -0x10(%rdi),%rcx
  8237fc:	and    %rsi,%rcx
  8237ff:	mov    %dl,(%r11,%rdi,1)
  823803:	mov    %dl,0x10(%r11,%rcx,1)
  823808:	movzbl %al,%eax
  82380b:	movd   %eax,%xmm0
  82380f:	shufpd $0x2,-0x778638(%rip),%xmm0        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  823818:	movdqu 0x10(%r14),%xmm1
  82381e:	psubq  %xmm0,%xmm1
  823822:	movdqu %xmm1,0x10(%r14)
  823828:	shl    $0x5,%rdi
  82382c:	mov    %r11,%rax
  82382f:	sub    %rdi,%rax
  823832:	neg    %rdi
  823835:	movaps 0x10(%rsp),%xmm0
  82383a:	movdqa 0x20(%rsp),%xmm1
  823840:	movups %xmm0,-0x20(%r11,%rdi,1)
  823846:	movdqu %xmm1,-0x10(%rax)
  82384b:	xor    %eax,%eax
  82384d:	mov    %eax,(%rbx)
  82384f:	mov    %rbx,%rax
  823852:	add    $0x38,%rsp
  823856:	pop    %rbx
  823857:	pop    %r12
  823859:	pop    %r13
  82385b:	pop    %r14
  82385d:	pop    %r15
  82385f:	pop    %rbp
  823860:	ret
  823861:	mov    $0x1,%esi
  823866:	mov    %r14,%rdi
  823869:	mov    %r13,%rdx
  82386c:	mov    $0x1,%ecx
  823871:	mov    %rax,%r13
  823874:	call   *0x65c52e(%rip)        # e7fda8 <_DYNAMIC+0x6e0>
  82387a:	mov    %r13,%rax
  82387d:	jmp    8236e4 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  823882:	movdqa (%r11),%xmm0
  823887:	pmovmskb %xmm0,%eax
  82388b:	tzcnt  %eax,%edi
  82388f:	movzbl (%r11,%rdi,1),%eax
  823894:	jmp    8237e3 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008238a0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  8238a0:	push   %rbp
  8238a1:	push   %r15
  8238a3:	push   %r14
  8238a5:	push   %r13
  8238a7:	push   %r12
  8238a9:	push   %rbx
  8238aa:	push   %rax
  8238ab:	mov    %r8d,%ebp
  8238ae:	mov    %ecx,%r14d
  8238b1:	mov    %rdx,%r15
  8238b4:	mov    %rsi,%r12
  8238b7:	mov    %rdi,%rbx
  8238ba:	mov    %rdx,(%rsp)
  8238be:	lea    0x20(%rsi),%r13
  8238c2:	mov    %rsp,%rsi
  8238c5:	mov    %r13,%rdi
  8238c8:	call   822020 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8238cd:	cmpq   $0x0,0x10(%r12)
  8238d3:	je     823a16 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  8238d9:	mov    (%r12),%rcx
  8238dd:	mov    0x8(%r12),%rsi
  8238e2:	mov    %rax,%rdx
  8238e5:	shr    $0x39,%rdx
  8238e9:	movd   %edx,%xmm0
  8238ed:	punpcklbw %xmm0,%xmm0
  8238f1:	pshuflw $0x0,%xmm0,%xmm0
  8238f6:	pshufd $0x44,%xmm0,%xmm0
  8238fb:	xor    %r9d,%r9d
  8238fe:	pcmpeqd %xmm1,%xmm1
  823902:	xor    %r8d,%r8d
  823905:	and    %rsi,%rax
  823908:	movdqu (%rcx,%rax,1),%xmm2
  82390d:	movdqa %xmm2,%xmm3
  823911:	pcmpeqb %xmm0,%xmm3
  823915:	pmovmskb %xmm3,%r10d
  82391a:	test   %r10d,%r10d
  82391d:	je     823950 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  82391f:	tzcnt  %r10d,%r13d
  823924:	add    %rax,%r13
  823927:	and    %rsi,%r13
  82392a:	shl    $0x4,%r13
  82392e:	mov    %rcx,%r11
  823931:	sub    %r13,%r11
  823934:	cmp    -0x10(%r11),%r15
  823938:	je     823991 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  82393a:	lea    -0x1(%r10),%r11d
  82393e:	and    %r10w,%r11w
  823942:	mov    %r11d,%r10d
  823945:	jne    82391f <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  823947:	nopw   0x0(%rax,%rax,1)
  823950:	cmp    $0x1,%r9
  823954:	je     823968 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  823956:	pmovmskb %xmm2,%edi
  82395a:	test   %edi,%edi
  82395c:	je     82397e <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  82395e:	tzcnt  %edi,%edi
  823962:	add    %rax,%rdi
  823965:	and    %rsi,%rdi
  823968:	pcmpeqb %xmm1,%xmm2
  82396c:	pmovmskb %xmm2,%r9d
  823971:	test   %r9d,%r9d
  823974:	jne    8239a8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  823976:	mov    $0x1,%r9d
  82397c:	jmp    823981 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  82397e:	xor    %r9d,%r9d
  823981:	add    %r8,%rax
  823984:	add    $0x10,%rax
  823988:	add    $0x10,%r8
  82398c:	jmp    823905 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  823991:	mov    -0x8(%r11),%rax
  823995:	mov    %r14d,-0x8(%r11)
  823999:	mov    %ebp,-0x4(%r11)
  82399d:	mov    %rax,0x4(%rbx)
  8239a1:	mov    $0x1,%eax
  8239a6:	jmp    823a02 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  8239a8:	movzbl (%rcx,%rdi,1),%eax
  8239ac:	test   %al,%al
  8239ae:	jns    823a37 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  8239b4:	and    $0x1,%al
  8239b6:	lea    -0x10(%rdi),%r8
  8239ba:	and    %rsi,%r8
  8239bd:	mov    %dl,(%rcx,%rdi,1)
  8239c0:	mov    %dl,0x10(%rcx,%r8,1)
  8239c5:	movdqu 0x10(%r12),%xmm0
  8239cc:	movzbl %al,%eax
  8239cf:	movd   %eax,%xmm1
  8239d3:	shufpd $0x2,-0x7787fc(%rip),%xmm1        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  8239dc:	psubq  %xmm1,%xmm0
  8239e0:	movdqu %xmm0,0x10(%r12)
  8239e7:	shl    $0x4,%rdi
  8239eb:	mov    %rcx,%rax
  8239ee:	sub    %rdi,%rax
  8239f1:	neg    %rdi
  8239f4:	mov    %r15,-0x10(%rcx,%rdi,1)
  8239f9:	mov    %r14d,-0x8(%rax)
  8239fd:	mov    %ebp,-0x4(%rax)
  823a00:	xor    %eax,%eax
  823a02:	mov    %eax,(%rbx)
  823a04:	mov    %rbx,%rax
  823a07:	add    $0x8,%rsp
  823a0b:	pop    %rbx
  823a0c:	pop    %r12
  823a0e:	pop    %r13
  823a10:	pop    %r14
  823a12:	pop    %r15
  823a14:	pop    %rbp
  823a15:	ret
  823a16:	mov    $0x1,%esi
  823a1b:	mov    %r12,%rdi
  823a1e:	mov    %r13,%rdx
  823a21:	mov    $0x1,%ecx
  823a26:	mov    %rax,%r13
  823a29:	call   *0x65c341(%rip)        # e7fd70 <_DYNAMIC+0x6a8>
  823a2f:	mov    %r13,%rax
  823a32:	jmp    8238d9 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  823a37:	movdqa (%rcx),%xmm0
  823a3b:	pmovmskb %xmm0,%eax
  823a3f:	tzcnt  %eax,%edi
  823a43:	movzbl (%rcx,%rdi,1),%eax
  823a47:	jmp    8239b4 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823db0 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  823db0:	push   %r14
  823db2:	push   %rbx
  823db3:	sub    $0x18,%rsp
  823db7:	mov    %rdi,%rbx
  823dba:	mov    (%rdi),%rsi
  823dbd:	lea    (%rsi,%rsi,1),%rax
  823dc1:	cmp    $0x5,%rax
  823dc5:	mov    $0x4,%r14d
  823dcb:	cmovae %rax,%r14
  823dcf:	mov    0x8(%rdi),%rdx
  823dd3:	mov    %rsp,%rdi
  823dd6:	mov    $0x4,%r8d
  823ddc:	mov    $0x20,%r9d
  823de2:	mov    %r14,%rcx
  823de5:	call   823e20 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823dea:	cmpl   $0x1,(%rsp)
  823dee:	je     823e04 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  823df0:	mov    0x8(%rsp),%rax
  823df5:	mov    %rax,0x8(%rbx)
  823df9:	mov    %r14,(%rbx)
  823dfc:	add    $0x18,%rsp
  823e00:	pop    %rbx
  823e01:	pop    %r14
  823e03:	ret
  823e04:	mov    0x8(%rsp),%rdi
  823e09:	mov    0x10(%rsp),%rsi
  823e0e:	call   *0x65bb3c(%rip)        # e7f950 <_DYNAMIC+0x288>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824810 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  824810:	push   %rbp
  824811:	push   %r15
  824813:	push   %r14
  824815:	push   %r13
  824817:	push   %r12
  824819:	push   %rbx
  82481a:	sub    $0x58,%rsp
  82481e:	mov    %ecx,%ebp
  824820:	mov    %rdx,0x8(%rsp)
  824825:	mov    0x18(%rdi),%rax
  824829:	add    %rax,%rsi
  82482c:	jb     824941 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824832:	mov    %rdi,%rbx
  824835:	mov    0x8(%rdi),%r15
  824839:	lea    0x1(%r15),%rdx
  82483d:	mov    %rdx,%rdi
  824840:	shr    $0x3,%rdi
  824844:	mov    %rdx,%rcx
  824847:	and    $0xfffffffffffffff8,%rcx
  82484b:	sub    %rdi,%rcx
  82484e:	cmp    $0x8,%r15
  824852:	cmovb  %r15,%rcx
  824856:	mov    %rcx,%rdi
  824859:	shr    $1,%rdi
  82485c:	cmp    %rdi,%rsi
  82485f:	jbe    824890 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  824861:	inc    %rcx
  824864:	cmp    %rsi,%rcx
  824867:	cmovbe %rsi,%rcx
  82486b:	cmp    $0xf,%rcx
  82486f:	mov    %rbx,(%rsp)
  824873:	jae    8248c1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  824875:	mov    %ecx,%eax
  824877:	and    $0x8,%eax
  82487a:	add    $0x8,%rax
  82487e:	cmp    $0x4,%rcx
  824882:	mov    $0x4,%ebx
  824887:	cmovae %rax,%rbx
  82488b:	jmp    824919 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  824890:	test   %rdx,%rdx
  824893:	je     824b1a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  824899:	mov    (%rbx),%rsi
  82489c:	mov    %rdx,%rax
  82489f:	shr    $0x4,%rax
  8248a3:	mov    %edx,%ecx
  8248a5:	and    $0xf,%ecx
  8248a8:	cmp    $0x1,%rcx
  8248ac:	sbb    $0xffffffffffffffff,%rax
  8248b0:	cmp    $0x1,%rax
  8248b4:	jne    824b21 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  8248ba:	xor    %ecx,%ecx
  8248bc:	jmp    824b74 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  8248c1:	movabs $0x1ffffffffffffffe,%rax
  8248cb:	inc    %rax
  8248ce:	cmp    %rax,%rcx
  8248d1:	ja     824941 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8248d3:	shl    $0x3,%rcx
  8248d7:	movabs $0x2492492492492493,%rdx
  8248e1:	mov    %rcx,%rax
  8248e4:	mul    %rdx
  8248e7:	sub    %rdx,%rcx
  8248ea:	shr    $1,%rcx
  8248ed:	add    %rdx,%rcx
  8248f0:	shr    $0x2,%rcx
  8248f4:	dec    %rcx
  8248f7:	bsr    %rcx,%rcx
  8248fb:	not    %ecx
  8248fd:	mov    $0xffffffffffffffff,%rbx
  824904:	shr    %cl,%rbx
  824907:	movabs $0x7fffffffffffffe,%rax
  824911:	cmp    %rax,%rbx
  824914:	ja     824941 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824916:	inc    %rbx
  824919:	mov    %rbx,%r14
  82491c:	shl    $0x5,%r14
  824920:	lea    0x10(%rbx),%r12
  824924:	mov    %r12,%r13
  824927:	add    %r14,%r13
  82492a:	setb   %al
  82492d:	movabs $0x7ffffffffffffff0,%rcx
  824937:	cmp    %rcx,%r13
  82493a:	seta   %cl
  82493d:	or     %al,%cl
  82493f:	je     824950 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  824941:	movzbl %bpl,%edi
  824945:	call   *0x65b49d(%rip)        # e7fde8 <_DYNAMIC+0x720>
  82494b:	jmp    824d95 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  824950:	call   *0x65b002(%rip)        # e7f958 <_DYNAMIC+0x290>
  824956:	mov    $0x10,%esi
  82495b:	mov    %r13,%rdi
  82495e:	call   *0x65affc(%rip)        # e7f960 <_DYNAMIC+0x298>
  824964:	test   %rax,%rax
  824967:	je     824db3 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  82496d:	mov    %rax,%r15
  824970:	mov    (%rsp),%rcx
  824974:	lea    0x20(%rcx),%r13
  824978:	add    %r14,%r15
  82497b:	lea    -0x1(%rbx),%r14
  82497f:	mov    %rbx,%rax
  824982:	shr    $0x3,%rax
  824986:	mov    %rbx,%rbp
  824989:	and    $0xfffffffffffffff8,%rbp
  82498d:	sub    %rax,%rbp
  824990:	cmp    $0x9,%rbx
  824994:	mov    %rcx,%rbx
  824997:	cmovb  %r14,%rbp
  82499b:	mov    %r15,%rdi
  82499e:	mov    $0xff,%esi
  8249a3:	mov    %r12,%rdx
  8249a6:	call   *0x65b444(%rip)        # e7fdf0 <memset@GLIBC_2.2.5>
  8249ac:	mov    %r14,%rdi
  8249af:	mov    %r13,0x20(%rsp)
  8249b4:	movq   $0x20,0x28(%rsp)
  8249bd:	movq   $0x10,0x30(%rsp)
  8249c6:	mov    %r15,0x38(%rsp)
  8249cb:	mov    %r14,0x40(%rsp)
  8249d0:	mov    %rbp,0x48(%rsp)
  8249d5:	movq   $0x0,0x50(%rsp)
  8249de:	mov    0x18(%rbx),%r12
  8249e2:	test   %r12,%r12
  8249e5:	je     824dc7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  8249eb:	mov    %rbp,0x10(%rsp)
  8249f0:	mov    (%rbx),%rsi
  8249f3:	movdqa (%rsi),%xmm0
  8249f7:	pmovmskb %xmm0,%r13d
  8249fc:	not    %r13d
  8249ff:	xor    %ebp,%ebp
  824a01:	mov    %rsi,%r14
  824a04:	mov    %rdi,0x18(%rsp)
  824a09:	nopl   0x0(%rax)
  824a10:	test   %r13w,%r13w
  824a14:	jne    824a3f <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  824a16:	cs nopw 0x0(%rax,%rax,1)
  824a20:	movdqa 0x10(%r14),%xmm0
  824a26:	add    $0x10,%r14
  824a2a:	pmovmskb %xmm0,%r13d
  824a2f:	xor    $0xffff,%r13d
  824a36:	add    $0x10,%rbp
  824a3a:	test   %r13d,%r13d
  824a3d:	je     824a20 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  824a3f:	tzcnt  %r13d,%ebx
  824a44:	add    %rbp,%rbx
  824a47:	mov    %rbx,%rax
  824a4a:	shl    $0x5,%rax
  824a4e:	sub    %rax,%rsi
  824a51:	add    $0xffffffffffffffe0,%rsi
  824a55:	mov    0x8(%rsp),%rdi
  824a5a:	call   821e80 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  824a5f:	mov    %rax,%rdx
  824a62:	mov    0x18(%rsp),%rdi
  824a67:	and    %rdi,%rdx
  824a6a:	movdqu (%r15,%rdx,1),%xmm0
  824a70:	pmovmskb %xmm0,%ecx
  824a74:	test   %ecx,%ecx
  824a76:	je     824ae5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  824a78:	tzcnt  %ecx,%ecx
  824a7c:	add    %rdx,%rcx
  824a7f:	and    %rdi,%rcx
  824a82:	cmpb   $0x0,(%r15,%rcx,1)
  824a87:	jns    824b08 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  824a89:	lea    -0x1(%r13),%edx
  824a8d:	and    %r13d,%edx
  824a90:	dec    %r12
  824a93:	shr    $0x39,%rax
  824a97:	lea    -0x10(%rcx),%rsi
  824a9b:	and    %rdi,%rsi
  824a9e:	mov    %al,(%r15,%rcx,1)
  824aa2:	mov    %al,0x10(%r15,%rsi,1)
  824aa7:	mov    (%rsp),%rax
  824aab:	mov    (%rax),%rsi
  824aae:	not    %rbx
  824ab1:	shl    $0x5,%rbx
  824ab5:	not    %rcx
  824ab8:	shl    $0x5,%rcx
  824abc:	movdqu (%rsi,%rbx,1),%xmm0
  824ac1:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  824ac7:	movdqu %xmm1,0x10(%r15,%rcx,1)
  824ace:	movdqu %xmm0,(%r15,%rcx,1)
  824ad4:	mov    %edx,%r13d
  824ad7:	test   %r12,%r12
  824ada:	jne    824a10 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  824ae0:	jmp    824da4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  824ae5:	mov    $0x10,%esi
  824aea:	add    %rsi,%rdx
  824aed:	and    %rdi,%rdx
  824af0:	movdqu (%r15,%rdx,1),%xmm0
  824af6:	pmovmskb %xmm0,%ecx
  824afa:	add    $0x10,%rsi
  824afe:	test   %ecx,%ecx
  824b00:	jne    824a78 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  824b06:	jmp    824aea <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  824b08:	movdqa (%r15),%xmm0
  824b0d:	pmovmskb %xmm0,%ecx
  824b11:	tzcnt  %ecx,%ecx
  824b15:	jmp    824a89 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  824b1a:	xor    %ecx,%ecx
  824b1c:	jmp    824d87 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  824b21:	movabs $0x1ffffffffffffffe,%rdi
  824b2b:	and    %rax,%rdi
  824b2e:	xor    %ecx,%ecx
  824b30:	movdqa -0x776f98(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824b38:	nopl   0x0(%rax,%rax,1)
  824b40:	pxor   %xmm1,%xmm1
  824b44:	pcmpgtb (%rsi,%rcx,1),%xmm1
  824b49:	por    %xmm0,%xmm1
  824b4d:	movdqa %xmm1,(%rsi,%rcx,1)
  824b52:	pxor   %xmm1,%xmm1
  824b56:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  824b5c:	por    %xmm0,%xmm1
  824b60:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  824b66:	add    $0x20,%rcx
  824b6a:	add    $0xfffffffffffffffe,%rdi
  824b6e:	jne    824b40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  824b70:	test   $0x1,%al
  824b72:	je     824b8a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  824b74:	pxor   %xmm0,%xmm0
  824b78:	pcmpgtb (%rsi,%rcx,1),%xmm0
  824b7d:	por    -0x776fe5(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824b85:	movdqa %xmm0,(%rsi,%rcx,1)
  824b8a:	cmp    $0x10,%rdx
  824b8e:	jb     824e18 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  824b94:	mov    %rdx,%rdi
  824b97:	mov    $0x10,%edx
  824b9c:	add    %rsi,%rdi
  824b9f:	call   *0x65b253(%rip)        # e7fdf8 <memmove@GLIBC_2.2.5>
  824ba5:	movq   $0x0,0x28(%rsp)
  824bae:	movq   $0x20,0x30(%rsp)
  824bb7:	mov    %rbx,0x20(%rsp)
  824bbc:	xor    %r12d,%r12d
  824bbf:	xor    %r13d,%r13d
  824bc2:	jmp    824d11 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  824bc7:	nopw   0x0(%rax,%rax,1)
  824bd0:	lea    (%rax,%rbp,1),%rsi
  824bd4:	add    $0xffffffffffffffe0,%rsi
  824bd8:	mov    0x8(%rsp),%rdi
  824bdd:	call   821e80 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  824be2:	mov    (%rbx),%rcx
  824be5:	mov    0x8(%rbx),%rdx
  824be9:	mov    %rdx,%rsi
  824bec:	and    %rax,%rsi
  824bef:	movdqu (%rcx,%rsi,1),%xmm0
  824bf4:	pmovmskb %xmm0,%edi
  824bf8:	mov    %rsi,%r8
  824bfb:	test   %edi,%edi
  824bfd:	je     824ca9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  824c03:	tzcnt  %edi,%edi
  824c07:	add    %r8,%rdi
  824c0a:	and    %rdx,%rdi
  824c0d:	cmpb   $0x0,(%rcx,%rdi,1)
  824c11:	jns    824cd0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  824c17:	mov    %r12,%r8
  824c1a:	sub    %rsi,%r8
  824c1d:	mov    %rdi,%r9
  824c20:	sub    %rsi,%r9
  824c23:	xor    %r8,%r9
  824c26:	and    %rdx,%r9
  824c29:	cmp    $0x10,%r9
  824c2d:	jb     824cf0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  824c33:	mov    %rdi,%rsi
  824c36:	not    %rsi
  824c39:	shl    $0x5,%rsi
  824c3d:	add    %rcx,%rsi
  824c40:	movzbl (%rcx,%rdi,1),%r8d
  824c45:	shr    $0x39,%rax
  824c49:	lea    -0x10(%rdi),%r9
  824c4d:	and    %rdx,%r9
  824c50:	mov    %al,(%rcx,%rdi,1)
  824c53:	mov    (%rbx),%rcx
  824c56:	mov    %al,0x10(%rcx,%r9,1)
  824c5b:	cmp    $0xff,%r8b
  824c5f:	je     824d36 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  824c65:	mov    (%r14),%rax
  824c68:	mov    (%rsi),%rcx
  824c6b:	mov    %rcx,(%r14)
  824c6e:	mov    %rax,(%rsi)
  824c71:	mov    0x8(%r14),%rax
  824c75:	mov    0x8(%rsi),%rcx
  824c79:	mov    %rcx,0x8(%r14)
  824c7d:	mov    %rax,0x8(%rsi)
  824c81:	mov    0x10(%r14),%rax
  824c85:	mov    0x10(%rsi),%rcx
  824c89:	mov    %rcx,0x10(%r14)
  824c8d:	mov    %rax,0x10(%rsi)
  824c91:	mov    0x18(%r14),%rax
  824c95:	mov    0x18(%rsi),%rcx
  824c99:	mov    %rcx,0x18(%r14)
  824c9d:	mov    %rax,0x18(%rsi)
  824ca1:	mov    (%rbx),%rax
  824ca4:	jmp    824bd0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824ca9:	mov    $0x10,%r9d
  824caf:	mov    %rsi,%r8
  824cb2:	add    %r9,%r8
  824cb5:	and    %rdx,%r8
  824cb8:	movdqu (%rcx,%r8,1),%xmm0
  824cbe:	pmovmskb %xmm0,%edi
  824cc2:	add    $0x10,%r9
  824cc6:	test   %edi,%edi
  824cc8:	jne    824c03 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  824cce:	jmp    824cb2 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  824cd0:	movdqa (%rcx),%xmm0
  824cd4:	pmovmskb %xmm0,%edi
  824cd8:	tzcnt  %edi,%edi
  824cdc:	jmp    824c17 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  824ce1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824cf0:	shr    $0x39,%rax
  824cf4:	lea    -0x10(%r12),%rsi
  824cf9:	and    %rsi,%rdx
  824cfc:	mov    %al,(%rcx,%r12,1)
  824d00:	mov    (%rbx),%rcx
  824d03:	mov    %al,0x10(%rcx,%rdx,1)
  824d07:	cmp    %r15,%r12
  824d0a:	lea    0x1(%r12),%r12
  824d0f:	je     824d65 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  824d11:	mov    (%rbx),%rax
  824d14:	cmp    (%rax,%r12,1),%r13b
  824d18:	jno    824d07 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  824d1a:	mov    %r12,%r14
  824d1d:	not    %r14
  824d20:	shl    $0x5,%r14
  824d24:	add    %rax,%r14
  824d27:	mov    %r12,%rbp
  824d2a:	neg    %rbp
  824d2d:	shl    $0x5,%rbp
  824d31:	jmp    824bd0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824d36:	lea    -0x10(%r12),%rax
  824d3b:	and    0x8(%rbx),%rax
  824d3f:	mov    (%rbx),%rcx
  824d42:	movb   $0xff,(%rcx,%r12,1)
  824d47:	mov    (%rbx),%rcx
  824d4a:	movb   $0xff,0x10(%rcx,%rax,1)
  824d4f:	movdqu (%r14),%xmm0
  824d54:	movdqu 0x10(%r14),%xmm1
  824d5a:	movdqu %xmm1,0x10(%rsi)
  824d5f:	movdqu %xmm0,(%rsi)
  824d63:	jmp    824d07 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  824d65:	mov    0x8(%rbx),%rdx
  824d69:	mov    0x18(%rbx),%rax
  824d6d:	lea    0x1(%rdx),%rcx
  824d71:	mov    %rcx,%rsi
  824d74:	shr    $0x3,%rsi
  824d78:	and    $0xfffffffffffffff8,%rcx
  824d7c:	sub    %rsi,%rcx
  824d7f:	cmp    $0x8,%rdx
  824d83:	cmovb  %rdx,%rcx
  824d87:	sub    %rax,%rcx
  824d8a:	mov    %rcx,0x10(%rbx)
  824d8e:	mov    $0xffffffffffffffff,%rax
  824d95:	add    $0x58,%rsp
  824d99:	pop    %rbx
  824d9a:	pop    %r12
  824d9c:	pop    %r13
  824d9e:	pop    %r14
  824da0:	pop    %r15
  824da2:	pop    %rbp
  824da3:	ret
  824da4:	mov    (%rsp),%rbx
  824da8:	mov    0x18(%rbx),%rcx
  824dac:	mov    0x10(%rsp),%rbp
  824db1:	jmp    824dcc <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  824db3:	movzbl %bpl,%edi
  824db7:	mov    $0x10,%esi
  824dbc:	mov    %r13,%rdx
  824dbf:	call   *0x65b03b(%rip)        # e7fe00 <_DYNAMIC+0x738>
  824dc5:	jmp    824d95 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  824dc7:	mov    (%rbx),%rsi
  824dca:	xor    %ecx,%ecx
  824dcc:	sub    %rcx,%rbp
  824dcf:	mov    %r15,(%rbx)
  824dd2:	mov    0x8(%rbx),%rax
  824dd6:	mov    %rdi,0x8(%rbx)
  824dda:	mov    %rbp,0x10(%rbx)
  824dde:	mov    %rcx,0x18(%rbx)
  824de2:	test   %rax,%rax
  824de5:	je     824d8e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824de7:	mov    %rax,%rcx
  824dea:	shl    $0x5,%rcx
  824dee:	add    $0x2f,%rcx
  824df2:	and    $0xffffffffffffffe0,%rcx
  824df6:	add    %rcx,%rax
  824df9:	add    $0x11,%rax
  824dfd:	je     824d8e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824dff:	sub    %rcx,%rsi
  824e02:	mov    $0x10,%edx
  824e07:	mov    %rsi,%rdi
  824e0a:	mov    %rax,%rsi
  824e0d:	call   *0x65aafd(%rip)        # e7f910 <_DYNAMIC+0x248>
  824e13:	jmp    824d8e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824e18:	mov    $0x10,%edi
  824e1d:	jmp    824b9c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  824e22:	mov    %rax,%rbx
  824e25:	lea    0x20(%rsp),%rdi
  824e2a:	call   825400 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  824e2f:	mov    %rbx,%rdi
  824e32:	call   e2c4b0 <_Unwind_Resume@plt>
  824e37:	mov    %rax,%rbx
  824e3a:	lea    0x20(%rsp),%rdi
  824e3f:	call   825440 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  824e44:	mov    %rbx,%rdi
  824e47:	call   e2c4b0 <_Unwind_Resume@plt>
  824e4c:	call   *0x65aac6(%rip)        # e7f918 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824e60 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  824e60:	push   %rbp
  824e61:	push   %r15
  824e63:	push   %r14
  824e65:	push   %r13
  824e67:	push   %r12
  824e69:	push   %rbx
  824e6a:	sub    $0x38,%rsp
  824e6e:	mov    %ecx,%r15d
  824e71:	mov    %rdx,0x20(%rsp)
  824e76:	mov    %rdi,%rbp
  824e79:	mov    0x18(%rdi),%rdi
  824e7d:	add    %rdi,%rsi
  824e80:	jb     824f98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824e86:	mov    0x8(%rbp),%rbx
  824e8a:	lea    0x1(%rbx),%rdx
  824e8e:	mov    %rdx,%rax
  824e91:	shr    $0x3,%rax
  824e95:	mov    %rdx,%rcx
  824e98:	and    $0xfffffffffffffff8,%rcx
  824e9c:	sub    %rax,%rcx
  824e9f:	cmp    $0x8,%rbx
  824ea3:	cmovb  %rbx,%rcx
  824ea7:	mov    %rcx,%rax
  824eaa:	shr    $1,%rax
  824ead:	cmp    %rax,%rsi
  824eb0:	jbe    824ee6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  824eb2:	inc    %rcx
  824eb5:	cmp    %rsi,%rcx
  824eb8:	cmovbe %rsi,%rcx
  824ebc:	cmp    $0xf,%rcx
  824ec0:	mov    %rbp,(%rsp)
  824ec4:	mov    %rbx,0x30(%rsp)
  824ec9:	jae    824f18 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  824ecb:	mov    %ecx,%eax
  824ecd:	and    $0x8,%eax
  824ed0:	add    $0x8,%rax
  824ed4:	cmp    $0x4,%rcx
  824ed8:	mov    $0x4,%ebx
  824edd:	cmovae %rax,%rbx
  824ee1:	jmp    824f70 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  824ee6:	test   %rdx,%rdx
  824ee9:	je     82512e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  824eef:	mov    0x0(%rbp),%r12
  824ef3:	mov    %rdx,%rax
  824ef6:	shr    $0x4,%rax
  824efa:	mov    %edx,%ecx
  824efc:	and    $0xf,%ecx
  824eff:	cmp    $0x1,%rcx
  824f03:	sbb    $0xffffffffffffffff,%rax
  824f07:	cmp    $0x1,%rax
  824f0b:	jne    825135 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  824f11:	xor    %ecx,%ecx
  824f13:	jmp    825188 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  824f18:	movabs $0x1ffffffffffffffe,%rax
  824f22:	inc    %rax
  824f25:	cmp    %rax,%rcx
  824f28:	ja     824f98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824f2a:	shl    $0x3,%rcx
  824f2e:	movabs $0x2492492492492493,%rdx
  824f38:	mov    %rcx,%rax
  824f3b:	mul    %rdx
  824f3e:	sub    %rdx,%rcx
  824f41:	shr    $1,%rcx
  824f44:	add    %rdx,%rcx
  824f47:	shr    $0x2,%rcx
  824f4b:	dec    %rcx
  824f4e:	bsr    %rcx,%rcx
  824f52:	not    %ecx
  824f54:	mov    $0xffffffffffffffff,%rbx
  824f5b:	shr    %cl,%rbx
  824f5e:	movabs $0xffffffffffffffe,%rax
  824f68:	cmp    %rax,%rbx
  824f6b:	ja     824f98 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824f6d:	inc    %rbx
  824f70:	mov    %rbx,%r14
  824f73:	shl    $0x4,%r14
  824f77:	lea    0x10(%rbx),%rbp
  824f7b:	mov    %rbp,%r13
  824f7e:	add    %r14,%r13
  824f81:	setb   %al
  824f84:	movabs $0x7ffffffffffffff0,%rcx
  824f8e:	cmp    %rcx,%r13
  824f91:	seta   %cl
  824f94:	or     %al,%cl
  824f96:	je     824fa7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  824f98:	movzbl %r15b,%edi
  824f9c:	call   *0x65ae46(%rip)        # e7fde8 <_DYNAMIC+0x720>
  824fa2:	jmp    825368 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  824fa7:	mov    %rdi,0x8(%rsp)
  824fac:	call   *0x65a9a6(%rip)        # e7f958 <_DYNAMIC+0x290>
  824fb2:	mov    $0x10,%esi
  824fb7:	mov    %r13,%rdi
  824fba:	call   *0x65a9a0(%rip)        # e7f960 <_DYNAMIC+0x298>
  824fc0:	test   %rax,%rax
  824fc3:	je     825382 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  824fc9:	mov    %rax,%rdi
  824fcc:	add    %r14,%rdi
  824fcf:	lea    -0x1(%rbx),%rcx
  824fd3:	mov    %rbx,%rax
  824fd6:	shr    $0x3,%rax
  824fda:	mov    %rbx,%r14
  824fdd:	and    $0xfffffffffffffff8,%r14
  824fe1:	sub    %rax,%r14
  824fe4:	cmp    $0x9,%rbx
  824fe8:	mov    %rcx,0x10(%rsp)
  824fed:	cmovb  %rcx,%r14
  824ff1:	mov    %rdi,0x18(%rsp)
  824ff6:	mov    $0xff,%esi
  824ffb:	mov    %rbp,%rdx
  824ffe:	call   *0x65adec(%rip)        # e7fdf0 <memset@GLIBC_2.2.5>
  825004:	mov    0x8(%rsp),%rbx
  825009:	test   %rbx,%rbx
  82500c:	je     825396 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  825012:	mov    %r14,0x28(%rsp)
  825017:	mov    (%rsp),%rax
  82501b:	mov    (%rax),%rdi
  82501e:	movdqa (%rdi),%xmm0
  825022:	pmovmskb %xmm0,%r14d
  825027:	not    %r14d
  82502a:	xor    %ebp,%ebp
  82502c:	mov    %rdi,%r13
  82502f:	nop
  825030:	test   %r14w,%r14w
  825034:	jne    82505f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  825036:	cs nopw 0x0(%rax,%rax,1)
  825040:	movdqa 0x10(%r13),%xmm0
  825046:	add    $0x10,%r13
  82504a:	pmovmskb %xmm0,%r14d
  82504f:	xor    $0xffff,%r14d
  825056:	add    $0x10,%rbp
  82505a:	test   %r14d,%r14d
  82505d:	je     825040 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  82505f:	tzcnt  %r14d,%r15d
  825064:	add    %rbp,%r15
  825067:	mov    %r15,%rax
  82506a:	shl    $0x4,%rax
  82506e:	mov    %rdi,%r12
  825071:	mov    %rdi,%rsi
  825074:	sub    %rax,%rsi
  825077:	add    $0xfffffffffffffff0,%rsi
  82507b:	mov    0x20(%rsp),%rdi
  825080:	call   822020 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  825085:	mov    %rax,%rcx
  825088:	mov    0x10(%rsp),%r9
  82508d:	and    %r9,%rcx
  825090:	mov    0x18(%rsp),%r8
  825095:	movdqu (%r8,%rcx,1),%xmm0
  82509b:	pmovmskb %xmm0,%edx
  82509f:	test   %edx,%edx
  8250a1:	je     825100 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  8250a3:	tzcnt  %edx,%edx
  8250a7:	add    %rcx,%rdx
  8250aa:	and    %r9,%rdx
  8250ad:	cmpb   $0x0,(%r8,%rdx,1)
  8250b2:	mov    %r12,%rdi
  8250b5:	jns    82511f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  8250b7:	lea    -0x1(%r14),%ecx
  8250bb:	and    %r14d,%ecx
  8250be:	dec    %rbx
  8250c1:	shr    $0x39,%rax
  8250c5:	lea    -0x10(%rdx),%rsi
  8250c9:	and    %r9,%rsi
  8250cc:	mov    %al,(%r8,%rdx,1)
  8250d0:	mov    %al,0x10(%r8,%rsi,1)
  8250d5:	not    %r15
  8250d8:	shl    $0x4,%r15
  8250dc:	not    %rdx
  8250df:	shl    $0x4,%rdx
  8250e3:	movdqu (%rdi,%r15,1),%xmm0
  8250e9:	movdqu %xmm0,(%r8,%rdx,1)
  8250ef:	mov    %ecx,%r14d
  8250f2:	test   %rbx,%rbx
  8250f5:	jne    825030 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  8250fb:	jmp    825377 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  825100:	mov    $0x10,%esi
  825105:	add    %rsi,%rcx
  825108:	and    %r9,%rcx
  82510b:	movdqu (%r8,%rcx,1),%xmm0
  825111:	pmovmskb %xmm0,%edx
  825115:	add    $0x10,%rsi
  825119:	test   %edx,%edx
  82511b:	jne    8250a3 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  82511d:	jmp    825105 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  82511f:	movdqa (%r8),%xmm0
  825124:	pmovmskb %xmm0,%ecx
  825128:	tzcnt  %ecx,%edx
  82512c:	jmp    8250b7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  82512e:	xor    %eax,%eax
  825130:	jmp    82535a <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  825135:	movabs $0x1ffffffffffffffe,%rsi
  82513f:	and    %rax,%rsi
  825142:	xor    %ecx,%ecx
  825144:	movdqa -0x7775ac(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  82514c:	nopl   0x0(%rax)
  825150:	pxor   %xmm1,%xmm1
  825154:	pcmpgtb (%r12,%rcx,1),%xmm1
  82515a:	por    %xmm0,%xmm1
  82515e:	movdqa %xmm1,(%r12,%rcx,1)
  825164:	pxor   %xmm1,%xmm1
  825168:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  82516f:	por    %xmm0,%xmm1
  825173:	movdqa %xmm1,0x10(%r12,%rcx,1)
  82517a:	add    $0x20,%rcx
  82517e:	add    $0xfffffffffffffffe,%rsi
  825182:	jne    825150 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  825184:	test   $0x1,%al
  825186:	je     8251a0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  825188:	pxor   %xmm0,%xmm0
  82518c:	pcmpgtb (%r12,%rcx,1),%xmm0
  825192:	por    -0x7775fa(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  82519a:	movdqa %xmm0,(%r12,%rcx,1)
  8251a0:	cmp    $0x10,%rdx
  8251a4:	jb     8253f3 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  8251aa:	mov    %rdx,%rdi
  8251ad:	mov    $0x10,%edx
  8251b2:	add    %r12,%rdi
  8251b5:	mov    %r12,%rsi
  8251b8:	call   *0x65ac3a(%rip)        # e7fdf8 <memmove@GLIBC_2.2.5>
  8251be:	xor    %r13d,%r13d
  8251c1:	xor    %eax,%eax
  8251c3:	jmp    8252f6 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  8251c8:	nopl   0x0(%rax,%rax,1)
  8251d0:	lea    (%r12,%r14,1),%rsi
  8251d4:	add    $0xfffffffffffffff0,%rsi
  8251d8:	mov    0x20(%rsp),%rdi
  8251dd:	call   822020 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8251e2:	mov    0x8(%rbp),%rcx
  8251e6:	mov    %rcx,%rdx
  8251e9:	and    %rax,%rdx
  8251ec:	movdqu (%r12,%rdx,1),%xmm0
  8251f2:	pmovmskb %xmm0,%esi
  8251f6:	mov    %rdx,%rdi
  8251f9:	test   %esi,%esi
  8251fb:	je     82528b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  825201:	tzcnt  %esi,%esi
  825205:	add    %rdi,%rsi
  825208:	and    %rcx,%rsi
  82520b:	cmpb   $0x0,(%r12,%rsi,1)
  825210:	jns    8252b2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  825216:	mov    %r13,%rdi
  825219:	sub    %rdx,%rdi
  82521c:	mov    %rsi,%r8
  82521f:	sub    %rdx,%r8
  825222:	xor    %rdi,%r8
  825225:	and    %rcx,%r8
  825228:	cmp    $0x10,%r8
  82522c:	jb     8252d0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  825232:	mov    %rsi,%rdx
  825235:	not    %rdx
  825238:	shl    $0x4,%rdx
  82523c:	add    %r12,%rdx
  82523f:	movzbl (%r12,%rsi,1),%edi
  825244:	shr    $0x39,%rax
  825248:	lea    -0x10(%rsi),%r8
  82524c:	and    %rcx,%r8
  82524f:	mov    %al,(%r12,%rsi,1)
  825253:	mov    0x0(%rbp),%r12
  825257:	mov    %al,0x10(%r12,%r8,1)
  82525c:	cmp    $0xff,%dil
  825260:	je     82531b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  825266:	mov    (%rbx),%rax
  825269:	mov    (%rdx),%rcx
  82526c:	mov    %rcx,(%rbx)
  82526f:	mov    %rax,(%rdx)
  825272:	mov    0x8(%rbx),%rax
  825276:	mov    0x8(%rdx),%rcx
  82527a:	mov    %rcx,0x8(%rbx)
  82527e:	mov    %rax,0x8(%rdx)
  825282:	mov    0x0(%rbp),%r12
  825286:	jmp    8251d0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  82528b:	mov    $0x10,%r8d
  825291:	mov    %rdx,%rdi
  825294:	add    %r8,%rdi
  825297:	and    %rcx,%rdi
  82529a:	movdqu (%r12,%rdi,1),%xmm0
  8252a0:	pmovmskb %xmm0,%esi
  8252a4:	add    $0x10,%r8
  8252a8:	test   %esi,%esi
  8252aa:	jne    825201 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  8252b0:	jmp    825294 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  8252b2:	movdqa (%r12),%xmm0
  8252b8:	pmovmskb %xmm0,%esi
  8252bc:	tzcnt  %esi,%esi
  8252c0:	jmp    825216 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  8252c5:	data16 cs nopw 0x0(%rax,%rax,1)
  8252d0:	shr    $0x39,%rax
  8252d4:	lea    -0x10(%r13),%rdx
  8252d8:	and    %rdx,%rcx
  8252db:	mov    %al,(%r12,%r13,1)
  8252df:	mov    0x0(%rbp),%r12
  8252e3:	mov    %al,0x10(%r12,%rcx,1)
  8252e8:	mov    %r15,%rbx
  8252eb:	xor    %eax,%eax
  8252ed:	cmp    %rbx,%r13
  8252f0:	lea    0x1(%r13),%r13
  8252f4:	je     825338 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  8252f6:	cmp    (%r12,%r13,1),%al
  8252fa:	jno    8252ed <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  8252fc:	mov    %rbx,%r15
  8252ff:	mov    %r13,%rbx
  825302:	not    %rbx
  825305:	shl    $0x4,%rbx
  825309:	add    %r12,%rbx
  82530c:	mov    %r13,%r14
  82530f:	neg    %r14
  825312:	shl    $0x4,%r14
  825316:	jmp    8251d0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  82531b:	lea    -0x10(%r13),%rax
  82531f:	and    0x8(%rbp),%rax
  825323:	movb   $0xff,(%r12,%r13,1)
  825328:	movb   $0xff,0x10(%r12,%rax,1)
  82532e:	movdqu (%rbx),%xmm0
  825332:	movdqu %xmm0,(%rdx)
  825336:	jmp    8252e8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  825338:	mov    0x8(%rbp),%rcx
  82533c:	mov    0x18(%rbp),%rdi
  825340:	lea    0x1(%rcx),%rax
  825344:	mov    %rax,%rdx
  825347:	shr    $0x3,%rdx
  82534b:	and    $0xfffffffffffffff8,%rax
  82534f:	sub    %rdx,%rax
  825352:	cmp    $0x8,%rcx
  825356:	cmovb  %rcx,%rax
  82535a:	sub    %rdi,%rax
  82535d:	mov    %rax,0x10(%rbp)
  825361:	mov    $0xffffffffffffffff,%rax
  825368:	add    $0x38,%rsp
  82536c:	pop    %rbx
  82536d:	pop    %r12
  82536f:	pop    %r13
  825371:	pop    %r14
  825373:	pop    %r15
  825375:	pop    %rbp
  825376:	ret
  825377:	mov    (%rsp),%rax
  82537b:	mov    0x28(%rsp),%r14
  825380:	jmp    8253a7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  825382:	movzbl %r15b,%edi
  825386:	mov    $0x10,%esi
  82538b:	mov    %r13,%rdx
  82538e:	call   *0x65aa6c(%rip)        # e7fe00 <_DYNAMIC+0x738>
  825394:	jmp    825368 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825396:	mov    (%rsp),%rax
  82539a:	mov    (%rax),%rdi
  82539d:	mov    0x18(%rsp),%r8
  8253a2:	mov    0x10(%rsp),%r9
  8253a7:	sub    0x8(%rsp),%r14
  8253ac:	mov    %r8,(%rax)
  8253af:	mov    %r9,0x8(%rax)
  8253b3:	mov    %r14,0x10(%rax)
  8253b7:	mov    $0xffffffffffffffff,%rax
  8253be:	mov    0x30(%rsp),%rsi
  8253c3:	test   %rsi,%rsi
  8253c6:	je     825368 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  8253c8:	mov    %rsi,%rcx
  8253cb:	shl    $0x4,%rcx
  8253cf:	add    $0x1f,%rcx
  8253d3:	and    $0xfffffffffffffff0,%rcx
  8253d7:	add    %rcx,%rsi
  8253da:	add    $0x11,%rsi
  8253de:	je     825368 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  8253e0:	sub    %rcx,%rdi
  8253e3:	mov    $0x10,%edx
  8253e8:	call   *0x65a522(%rip)        # e7f910 <_DYNAMIC+0x248>
  8253ee:	jmp    825361 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  8253f3:	mov    $0x10,%edi
  8253f8:	jmp    8251b2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008255b0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  8255b0:	mov    0x8(%rdi),%rsi
  8255b4:	test   %rsi,%rsi
  8255b7:	je     8255de <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  8255b9:	mov    %rsi,%rax
  8255bc:	shl    $0x5,%rax
  8255c0:	add    %rax,%rsi
  8255c3:	add    $0x31,%rsi
  8255c7:	je     8255de <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  8255c9:	mov    (%rdi),%rdi
  8255cc:	sub    %rax,%rdi
  8255cf:	add    $0xffffffffffffffe0,%rdi
  8255d3:	mov    $0x10,%edx
  8255d8:	jmp    *0x65a332(%rip)        # e7f910 <_DYNAMIC+0x248>
  8255de:	ret

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825a30 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  825a30:	push   %r15
  825a32:	push   %r14
  825a34:	push   %rbx
  825a35:	mov    (%rdx),%r9
  825a38:	mov    0x8(%rdx),%r11
  825a3c:	mov    0x10(%rdx),%rbx
  825a40:	mov    0x18(%rdx),%r10
  825a44:	mov    0x20(%rdx),%r8
  825a48:	mov    0x28(%rdx),%rcx
  825a4c:	test   $0x1,%r9b
  825a50:	jne    825aea <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  825a56:	mov    %rbx,%rax
  825a59:	jmp    825a7b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  825a5b:	nopl   0x0(%rax,%rax,1)
  825a60:	lea    0x8(%rax),%rbx
  825a64:	mov    %rbx,%r14
  825a67:	add    $0x8,%rdi
  825a6b:	mov    (%rax),%r15
  825a6e:	mov    %r14,%rax
  825a71:	cmp    0x28(%r15),%rdx
  825a75:	jne    825b3f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825a7b:	cmp    %rsi,%rdi
  825a7e:	je     825b18 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  825a84:	mov    (%rdi),%rdx
  825a87:	test   %rax,%rax
  825a8a:	je     825a93 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  825a8c:	cmp    %r10,%rax
  825a8f:	jne    825a60 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  825a91:	xor    %ebx,%ebx
  825a93:	xor    %eax,%eax
  825a95:	test   %r8,%r8
  825a98:	je     825b41 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825a9e:	cmp    %rcx,%r8
  825aa1:	je     825b41 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825aa7:	mov    %r8,%rax
  825aaa:	add    $0x8,%r8
  825aae:	xor    %r14d,%r14d
  825ab1:	jmp    825a67 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  825ab3:	mov    (%r11),%rax
  825ab6:	mov    0x8(%rax),%rbx
  825aba:	mov    0x10(%rax),%rax
  825abe:	lea    (%rbx,%rax,8),%r10
  825ac2:	test   %rax,%rax
  825ac5:	je     825b01 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  825ac7:	xor    %r11d,%r11d
  825aca:	nopw   0x0(%rax,%rax,1)
  825ad0:	mov    %r8,%rax
  825ad3:	mov    %rbx,%r8
  825ad6:	add    $0x8,%rbx
  825ada:	add    $0x8,%rdi
  825ade:	mov    (%r8),%r14
  825ae1:	mov    %rax,%r8
  825ae4:	cmp    0x28(%r14),%rdx
  825ae8:	jne    825b3f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825aea:	cmp    %rsi,%rdi
  825aed:	je     825b18 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  825aef:	mov    (%rdi),%rdx
  825af2:	test   %rbx,%rbx
  825af5:	je     825afc <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  825af7:	cmp    %r10,%rbx
  825afa:	jne    825ad0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  825afc:	test   %r11,%r11
  825aff:	jne    825ab3 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  825b01:	xor    %eax,%eax
  825b03:	test   %r8,%r8
  825b06:	je     825b41 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825b08:	cmp    %rcx,%r8
  825b0b:	je     825b41 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825b0d:	lea    0x8(%r8),%rax
  825b11:	xor    %ebx,%ebx
  825b13:	xor    %r11d,%r11d
  825b16:	jmp    825ada <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  825b18:	test   %rbx,%rbx
  825b1b:	sete   %dl
  825b1e:	cmp    %r10,%rbx
  825b21:	sete   %al
  825b24:	or     %dl,%al
  825b26:	test   $0x1,%r9b
  825b2a:	je     825b47 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  825b2c:	test   %al,%al
  825b2e:	je     825b3f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825b30:	test   %r11,%r11
  825b33:	je     825b4b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  825b35:	mov    (%r11),%rax
  825b38:	cmpq   $0x0,0x10(%rax)
  825b3d:	je     825b4b <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  825b3f:	xor    %eax,%eax
  825b41:	pop    %rbx
  825b42:	pop    %r14
  825b44:	pop    %r15
  825b46:	ret
  825b47:	test   %al,%al
  825b49:	je     825b3f <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825b4b:	test   %r8,%r8
  825b4e:	sete   %dl
  825b51:	cmp    %rcx,%r8
  825b54:	sete   %al
  825b57:	or     %dl,%al
  825b59:	pop    %rbx
  825b5a:	pop    %r14
  825b5c:	pop    %r15
  825b5e:	ret

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825b60 <gpui_gpu::renderer::slots::color_word>:
  825b60:	lea    -0x3(%rsi),%eax
  825b63:	cmp    %rax,%rdi
  825b66:	jbe    825b7f <gpui_gpu::renderer::slots::color_word+0x1f>
  825b68:	mov    %rdi,%rax
  825b6b:	shr    $0x6,%rax
  825b6f:	and    $0x3f,%edi
  825b72:	cmp    $0x1,%rdi
  825b76:	sbb    $0xffffffff,%eax
  825b79:	add    %esi,%eax
  825b7b:	add    $0xfffffffe,%eax
  825b7e:	ret
  825b7f:	push   %rax
  825b80:	lea    -0x750b22(%rip),%rdi        # d5065 <anon.4f92784177f891c02fc0a44bfee03ec4.9.llvm.1533866460487341161>
  825b87:	lea    0x60885a(%rip),%rdx        # e2e3e8 <anon.4f92784177f891c02fc0a44bfee03ec4.10.llvm.1533866460487341161>
  825b8e:	mov    $0x1e,%esi
  825b93:	call   *0x65a097(%rip)        # e7fc30 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=517 frame=72

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825ba0 <gpui_gpu::renderer::slots::write_prefix>:
  825ba0:	push   %rbp
  825ba1:	push   %r15
  825ba3:	push   %r14
  825ba5:	push   %r13
  825ba7:	push   %r12
  825ba9:	push   %rbx
  825baa:	sub    $0x18,%rsp
  825bae:	test   %rdx,%rdx
  825bb1:	je     825d4c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825bb7:	mov    %rdi,%rbx
  825bba:	mov    %rdx,%rax
  825bbd:	shr    $0x6,%rax
  825bc1:	xor    %ecx,%ecx
  825bc3:	test   $0x3f,%dl
  825bc6:	setne  %cl
  825bc9:	lea    (%rax,%rcx,1),%rbp
  825bcd:	lea    (%rax,%rcx,1),%r8
  825bd1:	inc    %r8
  825bd4:	mov    0x10(%rdi),%r12
  825bd8:	mov    %rbp,%r13
  825bdb:	sub    %r12,%r13
  825bde:	jae    825bec <gpui_gpu::renderer::slots::write_prefix+0x4c>
  825be0:	mov    0x8(%rbx),%rax
  825be4:	mov    %r8,%r14
  825be7:	jmp    825c8b <gpui_gpu::renderer::slots::write_prefix+0xeb>
  825bec:	mov    %r8,%r15
  825bef:	sub    %r12,%r15
  825bf2:	mov    (%rbx),%rax
  825bf5:	sub    %r12,%rax
  825bf8:	mov    %r12,%r14
  825bfb:	cmp    %rax,%r15
  825bfe:	ja     825d5b <gpui_gpu::renderer::slots::write_prefix+0x1bb>
  825c04:	mov    0x8(%rbx),%rax
  825c08:	mov    %r14,%rcx
  825c0b:	shl    $0x4,%rcx
  825c0f:	add    %rax,%rcx
  825c12:	cmp    $0x2,%r15
  825c16:	jb     825c82 <gpui_gpu::renderer::slots::write_prefix+0xe2>
  825c18:	mov    %r13d,%edi
  825c1b:	and    $0x7,%edi
  825c1e:	sub    %rbp,%r12
  825c21:	cmp    $0xfffffffffffffff8,%r12
  825c25:	ja     825c5e <gpui_gpu::renderer::slots::write_prefix+0xbe>
  825c27:	and    $0xfffffffffffffff8,%r13
  825c2b:	xorps  %xmm0,%xmm0
  825c2e:	xchg   %ax,%ax
  825c30:	movups %xmm0,(%rcx)
  825c33:	movups %xmm0,0x10(%rcx)
  825c37:	movups %xmm0,0x20(%rcx)
  825c3b:	movups %xmm0,0x30(%rcx)
  825c3f:	movups %xmm0,0x40(%rcx)
  825c43:	movups %xmm0,0x50(%rcx)
  825c47:	movups %xmm0,0x60(%rcx)
  825c4b:	movups %xmm0,0x70(%rcx)
  825c4f:	sub    $0xffffffffffffff80,%rcx
  825c53:	add    $0xfffffffffffffff8,%r13
  825c57:	jne    825c30 <gpui_gpu::renderer::slots::write_prefix+0x90>
  825c59:	test   %rdi,%rdi
  825c5c:	je     825c7c <gpui_gpu::renderer::slots::write_prefix+0xdc>
  825c5e:	xorps  %xmm0,%xmm0
  825c61:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  825c70:	movups %xmm0,(%rcx)
  825c73:	add    $0x10,%rcx
  825c77:	dec    %rdi
  825c7a:	jne    825c70 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  825c7c:	add    %r15,%r14
  825c7f:	dec    %r14
  825c82:	xorps  %xmm0,%xmm0
  825c85:	movups %xmm0,(%rcx)
  825c88:	inc    %r14
  825c8b:	mov    %r14,0x10(%rbx)
  825c8f:	mov    %edx,(%rax)
  825c91:	mov    %ebp,0x4(%rax)
  825c94:	mov    %r8d,0x8(%rax)
  825c98:	movl   $0x0,0xc(%rax)
  825c9f:	mov    %rsi,%rdi
  825ca2:	call   *0x659fc8(%rip)        # e7fc70 <_DYNAMIC+0x5a8>
  825ca8:	cmp    %rdx,%rax
  825cab:	je     825d4c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825cb1:	mov    %rax,%r15
  825cb4:	mov    %rdx,%r12
  825cb7:	xor    %r13d,%r13d
  825cba:	xor    %ebp,%ebp
  825cbc:	jmp    825ce6 <gpui_gpu::renderer::slots::write_prefix+0x146>
  825cbe:	xchg   %ax,%ax
  825cc0:	mov    0x8(%rbx),%rax
  825cc4:	mov    %r14,%rcx
  825cc7:	shl    $0x4,%rcx
  825ccb:	movups %xmm0,(%rax,%rcx,1)
  825ccf:	inc    %r14
  825cd2:	mov    %r14,0x10(%rbx)
  825cd6:	add    $0x2,%r13d
  825cda:	add    $0x18,%r15
  825cde:	inc    %rbp
  825ce1:	cmp    %r12,%r15
  825ce4:	je     825d4c <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825ce6:	mov    %rbp,%rdi
  825ce9:	shr    $0x6,%rdi
  825ced:	inc    %rdi
  825cf0:	cmp    %r14,%rdi
  825cf3:	jae    825d95 <gpui_gpu::renderer::slots::write_prefix+0x1f5>
  825cf9:	movups (%r15),%xmm0
  825cfd:	movzwl 0x12(%r15),%eax
  825d02:	movzwl 0x10(%r15),%edx
  825d07:	shr    $0xe,%eax
  825d0a:	and    $0x2,%eax
  825d0d:	shr    $0xf,%edx
  825d10:	or     %eax,%edx
  825d12:	mov    %r13d,%ecx
  825d15:	and    $0x1e,%cl
  825d18:	shl    %cl,%edx
  825d1a:	shl    $0x4,%rdi
  825d1e:	add    0x8(%rbx),%rdi
  825d22:	mov    %ebp,%eax
  825d24:	shr    $0x2,%eax
  825d27:	and    $0xc,%eax
  825d2a:	or     %edx,(%rax,%rdi,1)
  825d2d:	mov    0x10(%rbx),%r14
  825d31:	cmp    (%rbx),%r14
  825d34:	jne    825cc0 <gpui_gpu::renderer::slots::write_prefix+0x120>
  825d36:	mov    %rbx,%rdi
  825d39:	movaps %xmm0,(%rsp)
  825d3d:	call   *0x65a08d(%rip)        # e7fdd0 <_DYNAMIC+0x708>
  825d43:	movaps (%rsp),%xmm0
  825d47:	jmp    825cc0 <gpui_gpu::renderer::slots::write_prefix+0x120>
  825d4c:	add    $0x18,%rsp
  825d50:	pop    %rbx
  825d51:	pop    %r12
  825d53:	pop    %r13
  825d55:	pop    %r14
  825d57:	pop    %r15
  825d59:	pop    %rbp
  825d5a:	ret
  825d5b:	mov    $0x4,%ecx
  825d60:	mov    %r8,0x10(%rsp)
  825d65:	mov    $0x10,%r8d
  825d6b:	mov    %rbx,%rdi
  825d6e:	mov    %rsi,(%rsp)
  825d72:	mov    %r12,%rsi
  825d75:	mov    %rdx,%r14
  825d78:	mov    %r15,%rdx
  825d7b:	call   823bb0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  825d80:	mov    0x10(%rsp),%r8
  825d85:	mov    %r14,%rdx
  825d88:	mov    (%rsp),%rsi
  825d8c:	mov    0x10(%rbx),%r14
  825d90:	jmp    825c04 <gpui_gpu::renderer::slots::write_prefix+0x64>
  825d95:	lea    0x608664(%rip),%rdx        # e2e400 <anon.4f92784177f891c02fc0a44bfee03ec4.12.llvm.1533866460487341161>
  825d9c:	mov    %r14,%rsi
  825d9f:	call   *0x659e1b(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
