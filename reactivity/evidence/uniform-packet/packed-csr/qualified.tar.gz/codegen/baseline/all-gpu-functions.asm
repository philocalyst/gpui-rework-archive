
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816600 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  816600:	push   %rbx
  816601:	test   %rdi,%rdi
  816604:	je     816667 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  816606:	mov    %rdi,%rbx
  816609:	mov    (%rdi),%rsi
  81660c:	test   %rsi,%rsi
  81660f:	je     816624 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816611:	mov    0x8(%rbx),%rdi
  816615:	shl    $0x3,%rsi
  816619:	mov    $0x8,%edx
  81661e:	call   *0x66938c(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  816624:	mov    0x20(%rbx),%rsi
  816628:	test   %rsi,%rsi
  81662b:	je     816653 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81662d:	mov    %rsi,%rax
  816630:	shl    $0x4,%rax
  816634:	add    %rax,%rsi
  816637:	add    $0x21,%rsi
  81663b:	je     816653 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81663d:	mov    0x18(%rbx),%rdi
  816641:	sub    %rax,%rdi
  816644:	add    $0xfffffffffffffff0,%rdi
  816648:	mov    $0x10,%edx
  81664d:	call   *0x66935d(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  816653:	mov    $0x80,%esi
  816658:	mov    $0x8,%edx
  81665d:	mov    %rbx,%rdi
  816660:	pop    %rbx
  816661:	jmp    *0x669349(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  816667:	pop    %rbx
  816668:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816c70 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816c70:	push   %rbx
  816c71:	cmpb   $0x3,0x19c(%rdi)
  816c78:	jne    816ca7 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816c7a:	movzbl 0x28(%rdi),%eax
  816c7e:	cmp    $0x4,%eax
  816c81:	je     816c95 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816c83:	cmp    $0x3,%eax
  816c86:	jne    816ca7 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816c88:	add    $0x168,%rdi
  816c8f:	pop    %rbx
  816c90:	jmp    816be0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816c95:	mov    %rdi,%rbx
  816c98:	add    $0x30,%rdi
  816c9c:	call   816cc0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816ca1:	movw   $0x0,0x29(%rbx)
  816ca7:	pop    %rbx
  816ca8:	ret
  816ca9:	movw   $0x0,0x29(%rbx)
  816caf:	mov    %rax,%rdi
  816cb2:	call   e2c520 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816cc0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816cc0:	push   %r15
  816cc2:	push   %r14
  816cc4:	push   %r12
  816cc6:	push   %rbx
  816cc7:	push   %rax
  816cc8:	mov    %rdi,%rbx
  816ccb:	movzbl 0x9e(%rdi),%eax
  816cd2:	test   %eax,%eax
  816cd4:	je     816d9b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816cda:	cmp    $0x3,%eax
  816cdd:	jne    816dd1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816ce3:	mov    0x20(%rbx),%r15
  816ce7:	mov    0x28(%rbx),%r12
  816ceb:	mov    (%r12),%rax
  816cef:	test   %rax,%rax
  816cf2:	je     816cf9 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816cf4:	mov    %r15,%rdi
  816cf7:	call   *%rax
  816cf9:	mov    0x8(%r12),%rsi
  816cfe:	test   %rsi,%rsi
  816d01:	je     816d11 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816d03:	mov    0x10(%r12),%rdx
  816d08:	mov    %r15,%rdi
  816d0b:	call   *0x668c9f(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  816d11:	mov    0x68(%rbx),%rax
  816d15:	lock decq (%rax)
  816d19:	jne    816d25 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816d1b:	lea    0x68(%rbx),%rdi
  816d1f:	call   *0x668eab(%rip)        # e7fbd0 <_DYNAMIC+0x468>
  816d25:	movb   $0x0,0x98(%rbx)
  816d2c:	mov    0x60(%rbx),%rax
  816d30:	lock decq (%rax)
  816d34:	jne    816d3f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816d36:	lea    0x60(%rbx),%rdi
  816d3a:	call   812e40 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816d3f:	movw   $0x0,0x99(%rbx)
  816d48:	mov    0x40(%rbx),%rax
  816d4c:	lock decq (%rax)
  816d50:	jne    816d5c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816d52:	lea    0x40(%rbx),%rdi
  816d56:	call   *0x668e7c(%rip)        # e7fbd8 <_DYNAMIC+0x470>
  816d5c:	movb   $0x0,0x9b(%rbx)
  816d63:	mov    0x38(%rbx),%rax
  816d67:	lock decq (%rax)
  816d6b:	jne    816d77 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816d6d:	lea    0x38(%rbx),%rdi
  816d71:	call   *0x668e69(%rip)        # e7fbe0 <_DYNAMIC+0x478>
  816d77:	movb   $0x0,0x9c(%rbx)
  816d7e:	mov    0x30(%rbx),%rax
  816d82:	lock decq (%rax)
  816d86:	jne    816d92 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816d88:	lea    0x30(%rbx),%rdi
  816d8c:	call   *0x668e56(%rip)        # e7fbe8 <_DYNAMIC+0x480>
  816d92:	movb   $0x0,0x9d(%rbx)
  816d99:	jmp    816dd1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816d9b:	mov    0x70(%rbx),%rax
  816d9f:	lock decq (%rax)
  816da3:	jne    816daf <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816da5:	lea    0x70(%rbx),%rdi
  816da9:	call   *0x668e39(%rip)        # e7fbe8 <_DYNAMIC+0x480>
  816daf:	mov    0x78(%rbx),%rax
  816db3:	lock decq (%rax)
  816db7:	jne    816dd1 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816db9:	add    $0x78,%rbx
  816dbd:	mov    %rbx,%rdi
  816dc0:	add    $0x8,%rsp
  816dc4:	pop    %rbx
  816dc5:	pop    %r12
  816dc7:	pop    %r14
  816dc9:	pop    %r15
  816dcb:	jmp    *0x668e0f(%rip)        # e7fbe0 <_DYNAMIC+0x478>
  816dd1:	add    $0x8,%rsp
  816dd5:	pop    %rbx
  816dd6:	pop    %r12
  816dd8:	pop    %r14
  816dda:	pop    %r15
  816ddc:	ret
  816ddd:	mov    %rax,%r14
  816de0:	movb   $0x0,0x9d(%rbx)
  816de7:	mov    %r14,%rdi
  816dea:	call   e2c520 <_Unwind_Resume@plt>
  816def:	mov    %rax,%r14
  816df2:	jmp    816eac <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816df7:	mov    %rax,%r14
  816dfa:	jmp    816e91 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816dff:	mov    %rax,%r14
  816e02:	jmp    816e74 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816e04:	mov    %rax,%r14
  816e07:	jmp    816e5a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816e09:	mov    %rax,%r14
  816e0c:	mov    0x78(%rbx),%rax
  816e10:	lock decq (%rax)
  816e14:	jne    816e23 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816e16:	add    $0x78,%rbx
  816e1a:	mov    %rbx,%rdi
  816e1d:	call   *0x668dbd(%rip)        # e7fbe0 <_DYNAMIC+0x478>
  816e23:	mov    %r14,%rdi
  816e26:	call   e2c520 <_Unwind_Resume@plt>
  816e2b:	mov    %rax,%r14
  816e2e:	mov    0x8(%r12),%rsi
  816e33:	test   %rsi,%rsi
  816e36:	je     816e46 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816e38:	mov    0x10(%r12),%rdx
  816e3d:	mov    %r15,%rdi
  816e40:	call   *0x668b6a(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  816e46:	mov    0x68(%rbx),%rax
  816e4a:	lock decq (%rax)
  816e4e:	jne    816e5a <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816e50:	lea    0x68(%rbx),%rdi
  816e54:	call   *0x668d76(%rip)        # e7fbd0 <_DYNAMIC+0x468>
  816e5a:	movb   $0x0,0x98(%rbx)
  816e61:	mov    0x60(%rbx),%rax
  816e65:	lock decq (%rax)
  816e69:	jne    816e74 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816e6b:	lea    0x60(%rbx),%rdi
  816e6f:	call   812e40 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816e74:	movw   $0x0,0x99(%rbx)
  816e7d:	mov    0x40(%rbx),%rax
  816e81:	lock decq (%rax)
  816e85:	jne    816e91 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816e87:	lea    0x40(%rbx),%rdi
  816e8b:	call   *0x668d47(%rip)        # e7fbd8 <_DYNAMIC+0x470>
  816e91:	movb   $0x0,0x9b(%rbx)
  816e98:	mov    0x38(%rbx),%rax
  816e9c:	lock decq (%rax)
  816ea0:	jne    816eac <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816ea2:	lea    0x38(%rbx),%rdi
  816ea6:	call   *0x668d34(%rip)        # e7fbe0 <_DYNAMIC+0x478>
  816eac:	movb   $0x0,0x9c(%rbx)
  816eb3:	mov    0x30(%rbx),%rax
  816eb7:	lock decq (%rax)
  816ebb:	jne    816ec7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816ebd:	lea    0x30(%rbx),%rdi
  816ec1:	call   *0x668d21(%rip)        # e7fbe8 <_DYNAMIC+0x480>
  816ec7:	movb   $0x0,0x9d(%rbx)
  816ece:	mov    %r14,%rdi
  816ed1:	call   e2c520 <_Unwind_Resume@plt>
  816ed6:	call   *0x668adc(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816ee0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816ee0:	push   %rbx
  816ee1:	movzbl 0x20(%rdi),%eax
  816ee5:	cmp    $0x3,%eax
  816ee8:	je     816f03 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816eea:	cmp    $0x4,%eax
  816eed:	jne    816f10 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816eef:	mov    %rdi,%rbx
  816ef2:	add    $0x28,%rdi
  816ef6:	call   816cc0 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816efb:	movw   $0x0,0x21(%rbx)
  816f01:	pop    %rbx
  816f02:	ret
  816f03:	add    $0x160,%rdi
  816f0a:	pop    %rbx
  816f0b:	jmp    816be0 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816f10:	pop    %rbx
  816f11:	ret
  816f12:	movw   $0x0,0x21(%rbx)
  816f18:	mov    %rax,%rdi
  816f1b:	call   e2c520 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817400 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  817400:	push   %r14
  817402:	push   %rbx
  817403:	push   %rax
  817404:	mov    %rdi,%rbx
  817407:	mov    (%rdi),%rax
  81740a:	lock decq (%rax)
  81740e:	jne    817419 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817410:	mov    %rbx,%rdi
  817413:	call   *0x6687cf(%rip)        # e7fbe8 <_DYNAMIC+0x480>
  817419:	mov    0x8(%rbx),%rax
  81741d:	lock decq (%rax)
  817421:	jne    81742d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  817423:	lea    0x8(%rbx),%rdi
  817427:	call   *0x6687b3(%rip)        # e7fbe0 <_DYNAMIC+0x478>
  81742d:	mov    0x10(%rbx),%rax
  817431:	lock decq (%rax)
  817435:	jne    817440 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  817437:	lea    0x10(%rbx),%rdi
  81743b:	call   812e40 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  817440:	mov    0x18(%rbx),%rax
  817444:	lock decq (%rax)
  817448:	jne    81745e <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  81744a:	add    $0x18,%rbx
  81744e:	mov    %rbx,%rdi
  817451:	add    $0x8,%rsp
  817455:	pop    %rbx
  817456:	pop    %r14
  817458:	jmp    *0x668772(%rip)        # e7fbd0 <_DYNAMIC+0x468>
  81745e:	add    $0x8,%rsp
  817462:	pop    %rbx
  817463:	pop    %r14
  817465:	ret
  817466:	mov    %rax,%r14
  817469:	jmp    81749a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  81746b:	mov    %rax,%r14
  81746e:	jmp    817487 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  817470:	mov    %rax,%r14
  817473:	mov    0x8(%rbx),%rax
  817477:	lock decq (%rax)
  81747b:	jne    817487 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  81747d:	lea    0x8(%rbx),%rdi
  817481:	call   *0x668759(%rip)        # e7fbe0 <_DYNAMIC+0x478>
  817487:	mov    0x10(%rbx),%rax
  81748b:	lock decq (%rax)
  81748f:	jne    81749a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  817491:	lea    0x10(%rbx),%rdi
  817495:	call   812e40 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81749a:	mov    0x18(%rbx),%rax
  81749e:	lock decq (%rax)
  8174a2:	jne    8174b1 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  8174a4:	add    $0x18,%rbx
  8174a8:	mov    %rbx,%rdi
  8174ab:	call   *0x66871f(%rip)        # e7fbd0 <_DYNAMIC+0x468>
  8174b1:	mov    %r14,%rdi
  8174b4:	call   e2c520 <_Unwind_Resume@plt>
  8174b9:	call   *0x6684f9(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1253 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008174c0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  8174c0:	push   %r14
  8174c2:	push   %rbx
  8174c3:	push   %rax
  8174c4:	mov    %rdi,%rbx
  8174c7:	mov    0x228(%rdi),%rax
  8174ce:	lock decq (%rax)
  8174d2:	jne    8174e1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  8174d4:	lea    0x228(%rbx),%rdi
  8174db:	call   *0x6686ef(%rip)        # e7fbd0 <_DYNAMIC+0x468>
  8174e1:	mov    0x230(%rbx),%rax
  8174e8:	lock decq (%rax)
  8174ec:	jne    8174fb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  8174ee:	lea    0x230(%rbx),%rdi
  8174f5:	call   *0x668775(%rip)        # e7fc70 <_DYNAMIC+0x508>
  8174fb:	mov    0x238(%rbx),%rax
  817502:	lock decq (%rax)
  817506:	jne    817515 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  817508:	lea    0x238(%rbx),%rdi
  81750f:	call   *0x668763(%rip)        # e7fc78 <_DYNAMIC+0x510>
  817515:	mov    0x258(%rbx),%rax
  81751c:	lock decq (%rax)
  817520:	jne    81752f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  817522:	lea    0x258(%rbx),%rdi
  817529:	call   *0x668741(%rip)        # e7fc70 <_DYNAMIC+0x508>
  81752f:	mov    0x260(%rbx),%rax
  817536:	lock decq (%rax)
  81753a:	jne    817549 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  81753c:	lea    0x260(%rbx),%rdi
  817543:	call   *0x66872f(%rip)        # e7fc78 <_DYNAMIC+0x510>
  817549:	mov    0x280(%rbx),%rax
  817550:	lock decq (%rax)
  817554:	jne    817563 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  817556:	lea    0x280(%rbx),%rdi
  81755d:	call   *0x66870d(%rip)        # e7fc70 <_DYNAMIC+0x508>
  817563:	mov    0x288(%rbx),%rax
  81756a:	lock decq (%rax)
  81756e:	jne    81757d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  817570:	lea    0x288(%rbx),%rdi
  817577:	call   *0x6686fb(%rip)        # e7fc78 <_DYNAMIC+0x510>
  81757d:	mov    0x2a8(%rbx),%rax
  817584:	lock decq (%rax)
  817588:	jne    817597 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  81758a:	lea    0x2a8(%rbx),%rdi
  817591:	call   *0x6686d9(%rip)        # e7fc70 <_DYNAMIC+0x508>
  817597:	mov    0x2b0(%rbx),%rax
  81759e:	lock decq (%rax)
  8175a2:	jne    8175b1 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  8175a4:	lea    0x2b0(%rbx),%rdi
  8175ab:	call   *0x6686c7(%rip)        # e7fc78 <_DYNAMIC+0x510>
  8175b1:	mov    0x2d0(%rbx),%rax
  8175b8:	lock decq (%rax)
  8175bc:	jne    8175cb <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  8175be:	lea    0x2d0(%rbx),%rdi
  8175c5:	call   *0x6686a5(%rip)        # e7fc70 <_DYNAMIC+0x508>
  8175cb:	mov    0x2d8(%rbx),%rax
  8175d2:	lock decq (%rax)
  8175d6:	jne    8175e5 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  8175d8:	lea    0x2d8(%rbx),%rdi
  8175df:	call   *0x668693(%rip)        # e7fc78 <_DYNAMIC+0x510>
  8175e5:	lea    0x78(%rbx),%rdi
  8175e9:	call   8179b0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  8175ee:	mov    0x328(%rbx),%r14
  8175f5:	test   %r14,%r14
  8175f8:	je     817657 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  8175fa:	mov    (%r14),%rsi
  8175fd:	test   %rsi,%rsi
  817600:	je     817615 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  817602:	mov    0x8(%r14),%rdi
  817606:	shl    $0x3,%rsi
  81760a:	mov    $0x8,%edx
  81760f:	call   *0x66839b(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817615:	mov    0x20(%r14),%rsi
  817619:	test   %rsi,%rsi
  81761c:	je     817644 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81761e:	mov    %rsi,%rax
  817621:	shl    $0x4,%rax
  817625:	add    %rax,%rsi
  817628:	add    $0x21,%rsi
  81762c:	je     817644 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81762e:	mov    0x18(%r14),%rdi
  817632:	sub    %rax,%rdi
  817635:	add    $0xfffffffffffffff0,%rdi
  817639:	mov    $0x10,%edx
  81763e:	call   *0x66836c(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817644:	mov    $0x80,%esi
  817649:	mov    $0x8,%edx
  81764e:	mov    %r14,%rdi
  817651:	call   *0x668359(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817657:	mov    (%rbx),%rsi
  81765a:	test   %rsi,%rsi
  81765d:	je     817672 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  81765f:	mov    0x8(%rbx),%rdi
  817663:	shl    $0x4,%rsi
  817667:	mov    $0x4,%edx
  81766c:	call   *0x66833e(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817672:	mov    0x18(%rbx),%rsi
  817676:	test   %rsi,%rsi
  817679:	je     81768e <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  81767b:	mov    0x20(%rbx),%rdi
  81767f:	shl    $0x3,%rsi
  817683:	mov    $0x4,%edx
  817688:	call   *0x668322(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  81768e:	mov    0x30(%rbx),%rsi
  817692:	test   %rsi,%rsi
  817695:	je     8176aa <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817697:	mov    0x38(%rbx),%rdi
  81769b:	shl    $0x2,%rsi
  81769f:	mov    $0x4,%edx
  8176a4:	call   *0x668306(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  8176aa:	mov    0x48(%rbx),%rsi
  8176ae:	test   %rsi,%rsi
  8176b1:	je     8176c6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  8176b3:	mov    0x50(%rbx),%rdi
  8176b7:	shl    $0x2,%rsi
  8176bb:	mov    $0x4,%edx
  8176c0:	call   *0x6682ea(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  8176c6:	mov    0x60(%rbx),%rsi
  8176ca:	test   %rsi,%rsi
  8176cd:	je     8176e2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x222>
  8176cf:	mov    0x68(%rbx),%rdi
  8176d3:	shl    $0x5,%rsi
  8176d7:	mov    $0x4,%edx
  8176dc:	call   *0x6682ce(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  8176e2:	mov    0x300(%rbx),%rsi
  8176e9:	test   %rsi,%rsi
  8176ec:	je     81771c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  8176ee:	lea    (%rsi,%rsi,8),%rax
  8176f2:	lea    0x33(,%rax,4),%rax
  8176fa:	and    $0xfffffffffffffff0,%rax
  8176fe:	add    %rax,%rsi
  817701:	add    $0x11,%rsi
  817705:	je     81771c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x25c>
  817707:	mov    0x2f8(%rbx),%rdi
  81770e:	sub    %rax,%rdi
  817711:	mov    $0x10,%edx
  817716:	call   *0x668294(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  81771c:	mov    0x330(%rbx),%rax
  817723:	test   %rax,%rax
  817726:	je     817745 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  817728:	lock decq (%rax)
  81772c:	jne    817745 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x285>
  81772e:	add    $0x330,%rbx
  817735:	mov    %rbx,%rdi
  817738:	add    $0x8,%rsp
  81773c:	pop    %rbx
  81773d:	pop    %r14
  81773f:	jmp    *0x66853b(%rip)        # e7fc80 <_DYNAMIC+0x518>
  817745:	add    $0x8,%rsp
  817749:	pop    %rbx
  81774a:	pop    %r14
  81774c:	ret
  81774d:	mov    %rax,%r14
  817750:	jmp    81787c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817755:	mov    %rax,%r14
  817758:	mov    0x2d8(%rbx),%rax
  81775f:	lock decq (%rax)
  817763:	jne    81787c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  817769:	lea    0x2d8(%rbx),%rdi
  817770:	call   *0x668502(%rip)        # e7fc78 <_DYNAMIC+0x510>
  817776:	jmp    81787c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3bc>
  81777b:	call   *0x668237(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  817781:	mov    %rax,%r14
  817784:	jmp    817870 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  817789:	mov    %rax,%r14
  81778c:	mov    0x2b0(%rbx),%rax
  817793:	lock decq (%rax)
  817797:	jne    817870 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  81779d:	lea    0x2b0(%rbx),%rdi
  8177a4:	call   *0x6684ce(%rip)        # e7fc78 <_DYNAMIC+0x510>
  8177aa:	jmp    817870 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b0>
  8177af:	call   *0x668203(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  8177b5:	mov    %rax,%r14
  8177b8:	jmp    817864 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8177bd:	mov    %rax,%r14
  8177c0:	mov    0x288(%rbx),%rax
  8177c7:	lock decq (%rax)
  8177cb:	jne    817864 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8177d1:	lea    0x288(%rbx),%rdi
  8177d8:	call   *0x66849a(%rip)        # e7fc78 <_DYNAMIC+0x510>
  8177de:	jmp    817864 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a4>
  8177e3:	call   *0x6681cf(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  8177e9:	mov    %rax,%r14
  8177ec:	jmp    817858 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8177ee:	mov    %rax,%r14
  8177f1:	mov    0x260(%rbx),%rax
  8177f8:	lock decq (%rax)
  8177fc:	jne    817858 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  8177fe:	lea    0x260(%rbx),%rdi
  817805:	call   *0x66846d(%rip)        # e7fc78 <_DYNAMIC+0x510>
  81780b:	jmp    817858 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x398>
  81780d:	call   *0x6681a5(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  817813:	mov    %rax,%r14
  817816:	jmp    81784c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817818:	mov    %rax,%r14
  81781b:	mov    0x238(%rbx),%rax
  817822:	lock decq (%rax)
  817826:	jne    81784c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817828:	lea    0x238(%rbx),%rdi
  81782f:	call   *0x668443(%rip)        # e7fc78 <_DYNAMIC+0x510>
  817835:	jmp    81784c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x38c>
  817837:	call   *0x66817b(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  81783d:	mov    %rax,%r14
  817840:	lea    0x230(%rbx),%rdi
  817847:	call   817ab0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81784c:	lea    0x258(%rbx),%rdi
  817853:	call   817ab0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817858:	lea    0x280(%rbx),%rdi
  81785f:	call   817ab0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817864:	lea    0x2a8(%rbx),%rdi
  81786b:	call   817ab0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  817870:	lea    0x2d0(%rbx),%rdi
  817877:	call   817ab0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81787c:	lea    0x78(%rbx),%rdi
  817880:	call   8179b0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  817885:	mov    0x328(%rbx),%rdi
  81788c:	call   816600 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  817891:	mov    (%rbx),%rsi
  817894:	test   %rsi,%rsi
  817897:	jne    817912 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x452>
  817899:	mov    0x18(%rbx),%rsi
  81789d:	test   %rsi,%rsi
  8178a0:	jne    817932 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x472>
  8178a6:	mov    0x30(%rbx),%rsi
  8178aa:	test   %rsi,%rsi
  8178ad:	jne    817952 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x492>
  8178b3:	mov    0x48(%rbx),%rsi
  8178b7:	test   %rsi,%rsi
  8178ba:	jne    817972 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x4b2>
  8178c0:	mov    0x60(%rbx),%rsi
  8178c4:	test   %rsi,%rsi
  8178c7:	je     8178dc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  8178c9:	mov    0x68(%rbx),%rdi
  8178cd:	shl    $0x5,%rsi
  8178d1:	mov    $0x4,%edx
  8178d6:	call   *0x6680d4(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  8178dc:	lea    0x2f8(%rbx),%rdi
  8178e3:	call   819dc0 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  8178e8:	mov    0x330(%rbx),%rax
  8178ef:	test   %rax,%rax
  8178f2:	je     81790a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8178f4:	lock decq (%rax)
  8178f8:	jne    81790a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x44a>
  8178fa:	add    $0x330,%rbx
  817901:	mov    %rbx,%rdi
  817904:	call   *0x668376(%rip)        # e7fc80 <_DYNAMIC+0x518>
  81790a:	mov    %r14,%rdi
  81790d:	call   e2c520 <_Unwind_Resume@plt>
  817912:	mov    0x8(%rbx),%rdi
  817916:	shl    $0x4,%rsi
  81791a:	mov    $0x4,%edx
  81791f:	call   *0x66808b(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817925:	mov    0x18(%rbx),%rsi
  817929:	test   %rsi,%rsi
  81792c:	je     8178a6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3e6>
  817932:	mov    0x20(%rbx),%rdi
  817936:	shl    $0x3,%rsi
  81793a:	mov    $0x4,%edx
  81793f:	call   *0x66806b(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817945:	mov    0x30(%rbx),%rsi
  817949:	test   %rsi,%rsi
  81794c:	je     8178b3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3f3>
  817952:	mov    0x38(%rbx),%rdi
  817956:	shl    $0x2,%rsi
  81795a:	mov    $0x4,%edx
  81795f:	call   *0x66804b(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817965:	mov    0x48(%rbx),%rsi
  817969:	test   %rsi,%rsi
  81796c:	je     8178c0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x400>
  817972:	mov    0x50(%rbx),%rdi
  817976:	shl    $0x2,%rsi
  81797a:	mov    $0x4,%edx
  81797f:	call   *0x66802b(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817985:	mov    0x60(%rbx),%rsi
  817989:	test   %rsi,%rsi
  81798c:	jne    8178c9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x409>
  817992:	jmp    8178dc <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41c>
  817997:	call   *0x66801b(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  81799d:	mov    %rax,%r14
  8179a0:	jmp    817885 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c5>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008179b0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  8179b0:	push   %r14
  8179b2:	push   %rbx
  8179b3:	push   %rax
  8179b4:	mov    %rdi,%rbx
  8179b7:	mov    (%rdi),%rax
  8179ba:	lock decq (%rax)
  8179be:	jne    8179c9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  8179c0:	mov    %rbx,%rdi
  8179c3:	call   *0x668287(%rip)        # e7fc50 <_DYNAMIC+0x4e8>
  8179c9:	mov    0x50(%rbx),%rax
  8179cd:	lock decq (%rax)
  8179d1:	jne    8179dd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  8179d3:	lea    0x50(%rbx),%rdi
  8179d7:	call   *0x66826b(%rip)        # e7fc48 <_DYNAMIC+0x4e0>
  8179dd:	mov    0x58(%rbx),%rax
  8179e1:	lock decq (%rax)
  8179e5:	jne    8179f1 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  8179e7:	lea    0x58(%rbx),%rdi
  8179eb:	call   *0x66825f(%rip)        # e7fc50 <_DYNAMIC+0x4e8>
  8179f1:	mov    0xb0(%rbx),%rsi
  8179f8:	test   %rsi,%rsi
  8179fb:	je     817a2d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  8179fd:	mov    %rsi,%rax
  817a00:	shl    $0x5,%rax
  817a04:	add    %rax,%rsi
  817a07:	add    $0x31,%rsi
  817a0b:	je     817a2d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  817a0d:	mov    0xa8(%rbx),%rdi
  817a14:	sub    %rax,%rdi
  817a17:	add    $0xffffffffffffffe0,%rdi
  817a1b:	mov    $0x10,%edx
  817a20:	add    $0x8,%rsp
  817a24:	pop    %rbx
  817a25:	pop    %r14
  817a27:	jmp    *0x667f83(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817a2d:	add    $0x8,%rsp
  817a31:	pop    %rbx
  817a32:	pop    %r14
  817a34:	ret
  817a35:	mov    %rax,%r14
  817a38:	jmp    817a65 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a3a:	mov    %rax,%r14
  817a3d:	mov    0x58(%rbx),%rax
  817a41:	lock decq (%rax)
  817a45:	jne    817a65 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a47:	lea    0x58(%rbx),%rdi
  817a4b:	call   *0x6681ff(%rip)        # e7fc50 <_DYNAMIC+0x4e8>
  817a51:	jmp    817a65 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a53:	call   *0x667f5f(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  817a59:	mov    %rax,%r14
  817a5c:	lea    0x50(%rbx),%rdi
  817a60:	call   817bb0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  817a65:	add    $0xa8,%rbx
  817a6c:	mov    %rbx,%rdi
  817a6f:	call   819e00 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  817a74:	mov    %r14,%rdi
  817a77:	call   e2c520 <_Unwind_Resume@plt>
  817a7c:	call   *0x667f36(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817a90 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817a90:	cmpl   $0x1,(%rdi)
  817a93:	ja     817aad <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817a95:	mov    0x8(%rdi),%rsi
  817a99:	test   %rsi,%rsi
  817a9c:	je     817aad <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817a9e:	mov    0x10(%rdi),%rdi
  817aa2:	mov    $0x1,%edx
  817aa7:	jmp    *0x667f03(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  817aad:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817ab0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  817ab0:	push   %r14
  817ab2:	push   %rbx
  817ab3:	push   %rax
  817ab4:	mov    %rdi,%rbx
  817ab7:	mov    (%rdi),%rax
  817aba:	lock decq (%rax)
  817abe:	jne    817ac9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  817ac0:	mov    %rbx,%rdi
  817ac3:	call   *0x6681a7(%rip)        # e7fc70 <_DYNAMIC+0x508>
  817ac9:	mov    0x8(%rbx),%rax
  817acd:	lock decq (%rax)
  817ad1:	jne    817ae7 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  817ad3:	add    $0x8,%rbx
  817ad7:	mov    %rbx,%rdi
  817ada:	add    $0x8,%rsp
  817ade:	pop    %rbx
  817adf:	pop    %r14
  817ae1:	jmp    *0x668191(%rip)        # e7fc78 <_DYNAMIC+0x510>
  817ae7:	add    $0x8,%rsp
  817aeb:	pop    %rbx
  817aec:	pop    %r14
  817aee:	ret
  817aef:	mov    %rax,%r14
  817af2:	mov    0x8(%rbx),%rax
  817af6:	lock decq (%rax)
  817afa:	jne    817b09 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  817afc:	add    $0x8,%rbx
  817b00:	mov    %rbx,%rdi
  817b03:	call   *0x66816f(%rip)        # e7fc78 <_DYNAMIC+0x510>
  817b09:	mov    %r14,%rdi
  817b0c:	call   e2c520 <_Unwind_Resume@plt>
  817b11:	call   *0x667ea1(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000818480 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  818480:	sub    $0x18,%rsp
  818484:	mov    %rsi,%rax
  818487:	mov    (%rdi),%ecx
  818489:	lea    -0x747690(%rip),%rdx        # d0e00 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  818490:	movslq (%rdx,%rcx,4),%rcx
  818494:	add    %rdx,%rcx
  818497:	jmp    *%rcx
  818499:	add    $0x8,%rdi
  81849d:	mov    %rdi,0x10(%rsp)
  8184a2:	lea    -0x743a10(%rip),%rsi        # d4a99 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4851>
  8184a9:	jmp    818538 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  8184ae:	lea    -0x7439f3(%rip),%rsi        # d4ac2 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x487a>
  8184b5:	mov    $0x13,%edx
  8184ba:	mov    %rax,%rdi
  8184bd:	add    $0x18,%rsp
  8184c1:	jmp    *0x6675d9(%rip)        # e7faa0 <_DYNAMIC+0x338>
  8184c7:	add    $0x4,%rdi
  8184cb:	mov    %rdi,0x10(%rsp)
  8184d0:	lea    -0x743a32(%rip),%rsi        # d4aa5 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x485d>
  8184d7:	lea    0x61594a(%rip),%r8        # e2de28 <__frame_dummy_init_array_entry+0x8c8>
  8184de:	lea    0x10(%rsp),%rcx
  8184e3:	mov    $0x11,%edx
  8184e8:	mov    %rax,%rdi
  8184eb:	call   *0x6675b7(%rip)        # e7faa8 <_DYNAMIC+0x340>
  8184f1:	add    $0x18,%rsp
  8184f5:	ret
  8184f6:	lea    -0x743a47(%rip),%rsi        # d4ab6 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x486e>
  8184fd:	mov    $0xc,%edx
  818502:	mov    %rax,%rdi
  818505:	add    $0x18,%rsp
  818509:	jmp    *0x667591(%rip)        # e7faa0 <_DYNAMIC+0x338>
  81850f:	lea    -0x743a2b(%rip),%rsi        # d4aeb <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x48a3>
  818516:	mov    $0x9,%edx
  81851b:	mov    %rax,%rdi
  81851e:	add    $0x18,%rsp
  818522:	jmp    *0x667578(%rip)        # e7faa0 <_DYNAMIC+0x338>
  818528:	add    $0x8,%rdi
  81852c:	mov    %rdi,0x10(%rsp)
  818531:	lea    -0x743a99(%rip),%rsi        # d4a9f <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4857>
  818538:	lea    0x6158c9(%rip),%r8        # e2de08 <__frame_dummy_init_array_entry+0x8a8>
  81853f:	lea    0x10(%rsp),%rcx
  818544:	mov    $0x6,%edx
  818549:	mov    %rax,%rdi
  81854c:	call   *0x667556(%rip)        # e7faa8 <_DYNAMIC+0x340>
  818552:	add    $0x18,%rsp
  818556:	ret
  818557:	add    $0x8,%rdi
  81855b:	mov    %rdi,0x10(%rsp)
  818560:	lea    0x6158e1(%rip),%rcx        # e2de48 <__frame_dummy_init_array_entry+0x8e8>
  818567:	mov    %rcx,(%rsp)
  81856b:	lea    -0x743a9d(%rip),%rsi        # d4ad5 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x488d>
  818572:	lea    -0x76976d(%rip),%rcx        # aee0c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  818579:	lea    0x10(%rsp),%r9
  81857e:	mov    $0x9,%edx
  818583:	mov    $0x4,%r8d
  818589:	mov    %rax,%rdi
  81858c:	call   *0x6676fe(%rip)        # e7fc90 <_DYNAMIC+0x528>
  818592:	add    $0x18,%rsp
  818596:	ret
  818597:	lea    -0x743ac0(%rip),%rsi        # d4ade <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4896>
  81859e:	mov    $0xd,%edx
  8185a3:	mov    %rax,%rdi
  8185a6:	add    $0x18,%rsp
  8185aa:	jmp    *0x6674f0(%rip)        # e7faa0 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819e00 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819e00:	mov    0x8(%rdi),%rsi
  819e04:	test   %rsi,%rsi
  819e07:	je     819e2e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819e09:	mov    %rsi,%rax
  819e0c:	shl    $0x5,%rax
  819e10:	add    %rax,%rsi
  819e13:	add    $0x31,%rsi
  819e17:	je     819e2e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819e19:	mov    (%rdi),%rdi
  819e1c:	sub    %rax,%rdi
  819e1f:	add    $0xffffffffffffffe0,%rdi
  819e23:	mov    $0x10,%edx
  819e28:	jmp    *0x665b82(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  819e2e:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819e30 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819e30:	mov    0x8(%rdi),%rsi
  819e34:	test   %rsi,%rsi
  819e37:	je     819e5e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819e39:	mov    %rsi,%rax
  819e3c:	shl    $0x4,%rax
  819e40:	add    %rax,%rsi
  819e43:	add    $0x21,%rsi
  819e47:	je     819e5e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819e49:	mov    (%rdi),%rdi
  819e4c:	sub    %rax,%rdi
  819e4f:	add    $0xfffffffffffffff0,%rdi
  819e53:	mov    $0x10,%edx
  819e58:	jmp    *0x665b52(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  819e5e:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b6f0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b6f0:	push   %r14
  81b6f2:	push   %rbx
  81b6f3:	sub    $0x38,%rsp
  81b6f7:	mov    %rdi,%rbx
  81b6fa:	cmpq   $0x0,(%rsi)
  81b6fe:	je     81b808 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b704:	movdqu (%rsi),%xmm0
  81b708:	movdqu 0x10(%rsi),%xmm1
  81b70d:	movdqu 0x20(%rsi),%xmm2
  81b712:	movdqa %xmm2,0x20(%rsp)
  81b718:	movdqa %xmm1,0x10(%rsp)
  81b71e:	movdqa %xmm0,(%rsp)
  81b723:	cmpq   $0x0,0x18(%rcx)
  81b728:	je     81b81c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b72e:	lea    0x10(%rsp),%rsi
  81b733:	lea    0x20(%rcx),%rdi
  81b737:	mov    %rcx,%r14
  81b73a:	call   821ef0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b73f:	mov    %rax,%rsi
  81b742:	shr    $0x39,%rsi
  81b746:	mov    (%r14),%rcx
  81b749:	mov    0x8(%r14),%rdx
  81b74d:	movd   %esi,%xmm0
  81b751:	punpcklbw %xmm0,%xmm0
  81b755:	pshuflw $0x0,%xmm0,%xmm0
  81b75a:	pshufd $0x44,%xmm0,%xmm0
  81b75f:	mov    0x10(%rsp),%rsi
  81b764:	movzwl 0x1c(%rsp),%edi
  81b769:	xor    %r8d,%r8d
  81b76c:	mov    0x18(%rsp),%r9d
  81b771:	pcmpeqd %xmm1,%xmm1
  81b775:	and    %rdx,%rax
  81b778:	movdqu (%rcx,%rax,1),%xmm2
  81b77d:	movdqa %xmm2,%xmm3
  81b781:	pcmpeqb %xmm0,%xmm3
  81b785:	pmovmskb %xmm3,%r10d
  81b78a:	test   %r10d,%r10d
  81b78d:	je     81b7d0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b78f:	tzcnt  %r10d,%r14d
  81b794:	add    %rax,%r14
  81b797:	and    %rdx,%r14
  81b79a:	shl    $0x5,%r14
  81b79e:	mov    %rcx,%r11
  81b7a1:	sub    %r14,%r11
  81b7a4:	cmp    -0x20(%r11),%rsi
  81b7a8:	jne    81b7b7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b7aa:	cmp    -0x14(%r11),%di
  81b7af:	jne    81b7b7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b7b1:	cmp    -0x18(%r11),%r9d
  81b7b5:	je     81b7eb <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b7b7:	lea    -0x1(%r10),%r11d
  81b7bb:	and    %r10w,%r11w
  81b7bf:	mov    %r11d,%r10d
  81b7c2:	jne    81b78f <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b7c4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b7d0:	pcmpeqb %xmm1,%xmm2
  81b7d4:	pmovmskb %xmm2,%r10d
  81b7d9:	test   %r10d,%r10d
  81b7dc:	jne    81b81c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b7de:	add    %r8,%rax
  81b7e1:	add    $0x10,%rax
  81b7e5:	add    $0x10,%r8
  81b7e9:	jmp    81b775 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b7eb:	mov    -0x4(%r11),%eax
  81b7ef:	shl    $0x10,%eax
  81b7f2:	or     -0x8(%r11),%eax
  81b7f6:	mov    -0x10(%r11),%rcx
  81b7fa:	mov    %rcx,(%rbx)
  81b7fd:	mov    %eax,0x8(%rbx)
  81b800:	add    $0x38,%rsp
  81b804:	pop    %rbx
  81b805:	pop    %r14
  81b807:	ret
  81b808:	mov    0x8(%rdx),%eax
  81b80b:	mov    %eax,0x8(%rbx)
  81b80e:	mov    (%rdx),%rax
  81b811:	mov    %rax,(%rbx)
  81b814:	add    $0x38,%rsp
  81b818:	pop    %rbx
  81b819:	pop    %r14
  81b81b:	ret
  81b81c:	lea    -0x746951(%rip),%rdi        # d4ed2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x12c>
  81b823:	lea    0x612a56(%rip),%rdx        # e2e280 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x68>
  81b82a:	mov    $0x16,%esi
  81b82f:	call   *0x6644d3(%rip)        # e7fd08 <_DYNAMIC+0x5a0>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81bb30:	push   %r14
  81bb32:	push   %rbx
  81bb33:	push   %rax
  81bb34:	mov    %rdi,%rbx
  81bb37:	mov    (%rdi),%rax
  81bb3a:	lock decq (%rax)
  81bb3e:	jne    81bb49 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81bb40:	mov    %rbx,%rdi
  81bb43:	call   *0x664107(%rip)        # e7fc50 <_DYNAMIC+0x4e8>
  81bb49:	mov    0x50(%rbx),%rax
  81bb4d:	lock decq (%rax)
  81bb51:	jne    81bb5d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81bb53:	lea    0x50(%rbx),%rdi
  81bb57:	call   *0x6640eb(%rip)        # e7fc48 <_DYNAMIC+0x4e0>
  81bb5d:	mov    0x58(%rbx),%rax
  81bb61:	lock decq (%rax)
  81bb65:	jne    81bb71 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81bb67:	lea    0x58(%rbx),%rdi
  81bb6b:	call   *0x6640df(%rip)        # e7fc50 <_DYNAMIC+0x4e8>
  81bb71:	mov    0xb0(%rbx),%rsi
  81bb78:	test   %rsi,%rsi
  81bb7b:	je     81bbad <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bb7d:	mov    %rsi,%rax
  81bb80:	shl    $0x5,%rax
  81bb84:	add    %rax,%rsi
  81bb87:	add    $0x31,%rsi
  81bb8b:	je     81bbad <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bb8d:	mov    0xa8(%rbx),%rdi
  81bb94:	sub    %rax,%rdi
  81bb97:	add    $0xffffffffffffffe0,%rdi
  81bb9b:	mov    $0x10,%edx
  81bba0:	add    $0x8,%rsp
  81bba4:	pop    %rbx
  81bba5:	pop    %r14
  81bba7:	jmp    *0x663e03(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  81bbad:	add    $0x8,%rsp
  81bbb1:	pop    %rbx
  81bbb2:	pop    %r14
  81bbb4:	ret
  81bbb5:	mov    %rax,%r14
  81bbb8:	jmp    81bbe5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbba:	mov    %rax,%r14
  81bbbd:	mov    0x58(%rbx),%rax
  81bbc1:	lock decq (%rax)
  81bbc5:	jne    81bbe5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbc7:	lea    0x58(%rbx),%rdi
  81bbcb:	call   *0x66407f(%rip)        # e7fc50 <_DYNAMIC+0x4e8>
  81bbd1:	jmp    81bbe5 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbd3:	call   *0x663ddf(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  81bbd9:	mov    %rax,%r14
  81bbdc:	lea    0x50(%rbx),%rdi
  81bbe0:	call   81c480 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bbe5:	add    $0xa8,%rbx
  81bbec:	mov    %rbx,%rdi
  81bbef:	call   825620 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bbf4:	mov    %r14,%rdi
  81bbf7:	call   e2c520 <_Unwind_Resume@plt>
  81bbfc:	call   *0x663db6(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bc10:	push   %r14
  81bc12:	push   %rbx
  81bc13:	push   %rax
  81bc14:	mov    %rdi,%rbx
  81bc17:	mov    (%rdi),%rax
  81bc1a:	lock decq (%rax)
  81bc1e:	jne    81bc29 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bc20:	mov    %rbx,%rdi
  81bc23:	call   *0x664047(%rip)        # e7fc70 <_DYNAMIC+0x508>
  81bc29:	mov    0x8(%rbx),%rax
  81bc2d:	lock decq (%rax)
  81bc31:	jne    81bc47 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bc33:	add    $0x8,%rbx
  81bc37:	mov    %rbx,%rdi
  81bc3a:	add    $0x8,%rsp
  81bc3e:	pop    %rbx
  81bc3f:	pop    %r14
  81bc41:	jmp    *0x664031(%rip)        # e7fc78 <_DYNAMIC+0x510>
  81bc47:	add    $0x8,%rsp
  81bc4b:	pop    %rbx
  81bc4c:	pop    %r14
  81bc4e:	ret
  81bc4f:	mov    %rax,%r14
  81bc52:	mov    0x8(%rbx),%rax
  81bc56:	lock decq (%rax)
  81bc5a:	jne    81bc69 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bc5c:	add    $0x8,%rbx
  81bc60:	mov    %rbx,%rdi
  81bc63:	call   *0x66400f(%rip)        # e7fc78 <_DYNAMIC+0x510>
  81bc69:	mov    %r14,%rdi
  81bc6c:	call   e2c520 <_Unwind_Resume@plt>
  81bc71:	call   *0x663d41(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=611 frame=88

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c5b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c5b0:	push   %rbp
  81c5b1:	push   %r15
  81c5b3:	push   %r14
  81c5b5:	push   %r13
  81c5b7:	push   %r12
  81c5b9:	push   %rbx
  81c5ba:	sub    $0x28,%rsp
  81c5be:	movss  0x8c(%rdi),%xmm3
  81c5c6:	movss  -0x76d612(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c5ce:	movaps %xmm3,%xmm1
  81c5d1:	subss  %xmm0,%xmm1
  81c5d5:	cvttss2si %xmm1,%rax
  81c5da:	cvttss2si %xmm3,%r8
  81c5df:	mov    %r8,%rcx
  81c5e2:	sar    $0x3f,%rcx
  81c5e6:	and    %rax,%rcx
  81c5e9:	or     %r8,%rcx
  81c5ec:	xor    %r9d,%r9d
  81c5ef:	xorps  %xmm1,%xmm1
  81c5f2:	ucomiss %xmm1,%xmm3
  81c5f5:	cmovb  %r9,%rcx
  81c5f9:	movss  -0x76d641(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c601:	ucomiss %xmm2,%xmm3
  81c604:	mov    $0xffffffffffffffff,%rax
  81c60b:	cmova  %rax,%rcx
  81c60f:	movss  0x94(%rdi),%xmm3
  81c617:	mov    %rcx,%r8
  81c61a:	shr    $0x4,%r8
  81c61e:	movaps %xmm3,%xmm4
  81c621:	subss  %xmm0,%xmm4
  81c625:	cvttss2si %xmm4,%r10
  81c62a:	cvttss2si %xmm3,%r11
  81c62f:	mov    %r11,%rbx
  81c632:	sar    $0x3f,%rbx
  81c636:	and    %r10,%rbx
  81c639:	or     %r11,%rbx
  81c63c:	ucomiss %xmm1,%xmm3
  81c63f:	cmovb  %r9,%rbx
  81c643:	ucomiss %xmm2,%xmm3
  81c646:	cmova  %rax,%rbx
  81c64a:	mov    %rsi,0x18(%rsp)
  81c64f:	lea    (%rcx,%rbx,1),%r11
  81c653:	dec    %r11
  81c656:	shr    $0x4,%r11
  81c65a:	cmp    %r11,%r8
  81c65d:	jbe    81c66e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c65f:	add    $0x28,%rsp
  81c663:	pop    %rbx
  81c664:	pop    %r12
  81c666:	pop    %r13
  81c668:	pop    %r14
  81c66a:	pop    %r15
  81c66c:	pop    %rbp
  81c66d:	ret
  81c66e:	movss  0x88(%rdi),%xmm3
  81c676:	movaps %xmm3,%xmm4
  81c679:	subss  %xmm0,%xmm4
  81c67d:	cvttss2si %xmm4,%rsi
  81c682:	cvttss2si %xmm3,%r9
  81c687:	mov    %r9,%rcx
  81c68a:	sar    $0x3f,%rcx
  81c68e:	and    %rsi,%rcx
  81c691:	or     %r9,%rcx
  81c694:	xor    %r10d,%r10d
  81c697:	ucomiss %xmm1,%xmm3
  81c69a:	cmovb  %r10,%rcx
  81c69e:	ucomiss %xmm2,%xmm3
  81c6a1:	cmova  %rax,%rcx
  81c6a5:	movss  0x90(%rdi),%xmm3
  81c6ad:	mov    %rcx,%r14
  81c6b0:	shr    $0x4,%r14
  81c6b4:	movaps %xmm3,%xmm4
  81c6b7:	subss  %xmm0,%xmm4
  81c6bb:	cvttss2si %xmm4,%rsi
  81c6c0:	cvttss2si %xmm3,%rdi
  81c6c5:	mov    %rdi,%r9
  81c6c8:	sar    $0x3f,%r9
  81c6cc:	and    %rsi,%r9
  81c6cf:	or     %rdi,%r9
  81c6d2:	ucomiss %xmm1,%xmm3
  81c6d5:	cmovb  %r10,%r9
  81c6d9:	ucomiss %xmm2,%xmm3
  81c6dc:	cmova  %rax,%r9
  81c6e0:	lea    (%r9,%rcx,1),%rbx
  81c6e4:	dec    %rbx
  81c6e7:	shr    $0x4,%rbx
  81c6eb:	mov    %r14,0x10(%rsp)
  81c6f0:	cmp    %rbx,%r14
  81c6f3:	jbe    81c71d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c6f5:	data16 cs nopw 0x0(%rax,%rax,1)
  81c700:	mov    %r8,%rax
  81c703:	cmp    %r11,%r8
  81c706:	adc    $0x0,%r8
  81c70a:	cmp    %r11,%rax
  81c70d:	jae    81c65f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c713:	cmp    %r11,%r8
  81c716:	jbe    81c700 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c718:	jmp    81c65f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c71d:	mov    (%rdx),%r14
  81c720:	mov    0x8(%rdx),%r15
  81c724:	mov    0x10(%rdx),%r12
  81c728:	mov    0x18(%rdx),%r13
  81c72c:	mov    0x20(%rdx),%rdx
  81c730:	mov    %r11,0x8(%rsp)
  81c735:	data16 cs nopw 0x0(%rax,%rax,1)
  81c740:	mov    %r8,%rbp
  81c743:	cmp    %r11,%r8
  81c746:	adc    $0x0,%r8
  81c74a:	mov    %rbp,0x20(%rsp)
  81c74f:	imul   0x18(%rsp),%rbp
  81c755:	mov    0x10(%rsp),%r9
  81c75a:	mov    %r9,%rsi
  81c75d:	nopl   (%rax)
  81c760:	cmp    %rbx,%r9
  81c763:	adc    $0x0,%rsi
  81c767:	lea    (%r9,%rbp,1),%rdi
  81c76b:	mov    0x10(%r14),%rax
  81c76f:	cmp    %rax,%rdi
  81c772:	jae    81c7e0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c774:	mov    0x8(%r14),%rcx
  81c778:	cmp    0x4(%rcx,%rdi,8),%r10d
  81c77d:	jo     81c7b5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c77f:	mov    0x10(%r12),%rax
  81c784:	cmp    %rax,%rdi
  81c787:	jae    81c7f0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x240>
  81c789:	mov    0x8(%r12),%rax
  81c78e:	mov    0x0(%r13),%r11d
  81c792:	inc    %r11d
  81c795:	cmp    (%rax,%rdi,4),%r11d
  81c799:	jb     81c7b5 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x205>
  81c79b:	mov    (%rcx,%rdi,8),%eax
  81c79e:	dec    %eax
  81c7a0:	mov    %eax,(%rcx,%rdi,8)
  81c7a3:	mov    0x10(%r15),%rcx
  81c7a7:	cmp    %rax,%rcx
  81c7aa:	jbe    81c800 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x250>
  81c7ac:	mov    0x8(%r15),%rcx
  81c7b0:	mov    (%rdx),%edi
  81c7b2:	mov    %edi,(%rcx,%rax,4)
  81c7b5:	cmp    %rbx,%r9
  81c7b8:	jae    81c7c2 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x212>
  81c7ba:	mov    %rsi,%r9
  81c7bd:	cmp    %rbx,%rsi
  81c7c0:	jbe    81c760 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c7c2:	mov    0x8(%rsp),%r11
  81c7c7:	cmp    %r11,0x20(%rsp)
  81c7cc:	jae    81c65f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7d2:	cmp    %r11,%r8
  81c7d5:	jbe    81c740 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c7db:	jmp    81c65f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7e0:	lea    0x611ab1(%rip),%rdx        # e2e298 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c7e7:	mov    %rax,%rsi
  81c7ea:	call   *0x663470(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  81c7f0:	lea    0x611ab9(%rip),%rdx        # e2e2b0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c7f7:	mov    %rax,%rsi
  81c7fa:	call   *0x663460(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  81c800:	lea    0x611ac1(%rip),%rdx        # e2e2c8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  81c807:	mov    %rax,%rdi
  81c80a:	mov    %rcx,%rsi
  81c80d:	call   *0x66344d(%rip)        # e7fc60 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>> bytes=321 frame=248

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>:
  81c820:	push   %rbp
  81c821:	push   %r15
  81c823:	push   %r14
  81c825:	push   %r13
  81c827:	push   %r12
  81c829:	push   %rbx
  81c82a:	sub    $0xc8,%rsp
  81c831:	mov    %edx,%ebp
  81c833:	mov    %rsi,%r14
  81c836:	mov    %rdi,(%rsp)
  81c83a:	lea    0x8(%rsp),%rdi
  81c83f:	call   *0x6634db(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81c845:	mov    0x8(%rsp),%rsi
  81c84a:	xor    %r13d,%r13d
  81c84d:	test   $0x1,%bpl
  81c851:	je     81c8f0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xd0>
  81c857:	test   %rsi,%rsi
  81c85a:	je     81c935 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c860:	lea    0x70(%rsp),%r15
  81c865:	lea    0x8(%rsp),%r12
  81c86a:	mov    0x6634af(%rip),%rbp        # e7fd20 <_DYNAMIC+0x5b8>
  81c871:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c880:	mov    0x18(%rsp),%rbx
  81c885:	cmp    $0x1,%rbx
  81c889:	jbe    81c8d0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb0>
  81c88b:	mov    0x10(%rsp),%rax
  81c890:	mov    (%rax),%edx
  81c892:	mov    %r15,%rdi
  81c895:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c89a:	movss  0x74(%rsp),%xmm0
  81c8a0:	xorps  %xmm1,%xmm1
  81c8a3:	ucomiss %xmm1,%xmm0
  81c8a6:	lea    (%rbx,%rbx,1),%rax
  81c8aa:	lea    0x5(%rbx,%rbx,1),%rcx
  81c8af:	lea    (%rax,%rax,2),%rdx
  81c8b3:	mov    %rcx,%rax
  81c8b6:	cmovne %rdx,%rax
  81c8ba:	cmovp  %rdx,%rax
  81c8be:	cmpb   $0x3,0x70(%rsp)
  81c8c3:	cmovne %rcx,%rax
  81c8c7:	jmp    81c8d7 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb7>
  81c8c9:	nopl   0x0(%rax)
  81c8d0:	add    %rbx,%rbx
  81c8d3:	lea    (%rbx,%rbx,2),%rax
  81c8d7:	add    %rax,%r13
  81c8da:	jb     81c955 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c8dc:	mov    %r12,%rdi
  81c8df:	mov    %r14,%rsi
  81c8e2:	call   *%rbp
  81c8e4:	mov    0x8(%rsp),%rsi
  81c8e9:	test   %rsi,%rsi
  81c8ec:	jne    81c880 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x60>
  81c8ee:	jmp    81c935 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c8f0:	test   %rsi,%rsi
  81c8f3:	je     81c935 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c8f5:	lea    0x8(%rsp),%r15
  81c8fa:	mov    0x66341f(%rip),%r12        # e7fd20 <_DYNAMIC+0x5b8>
  81c901:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c910:	mov    %r13,%rax
  81c913:	mov    0x18(%rsp),%rcx
  81c918:	add    %rcx,%rcx
  81c91b:	lea    (%rcx,%rcx,2),%r13
  81c91f:	add    %rax,%r13
  81c922:	jb     81c955 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c924:	mov    %r15,%rdi
  81c927:	mov    %r14,%rsi
  81c92a:	call   *%r12
  81c92d:	cmpq   $0x0,0x8(%rsp)
  81c933:	jne    81c910 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xf0>
  81c935:	mov    (%rsp),%rax
  81c939:	mov    %r13,0x8(%rax)
  81c93d:	movl   $0xffffffff,(%rax)
  81c943:	add    $0xc8,%rsp
  81c94a:	pop    %rbx
  81c94b:	pop    %r12
  81c94d:	pop    %r13
  81c94f:	pop    %r14
  81c951:	pop    %r15
  81c953:	pop    %rbp
  81c954:	ret
  81c955:	mov    (%rsp),%rax
  81c959:	movl   $0x6,(%rax)
  81c95f:	jmp    81c943 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x123>

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cbb0 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81cbb0:	push   %rbp
  81cbb1:	push   %r14
  81cbb3:	push   %rbx
  81cbb4:	cmp    0x341(%rdi),%sil
  81cbbb:	je     81cbfb <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81cbbd:	mov    0x330(%rdi),%rax
  81cbc4:	test   %rax,%rax
  81cbc7:	je     81cbe9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cbc9:	lock decq (%rax)
  81cbcd:	jne    81cbe9 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cbcf:	lea    0x330(%rdi),%rbx
  81cbd6:	mov    %rdi,%r14
  81cbd9:	mov    %rbx,%rdi
  81cbdc:	mov    %esi,%ebp
  81cbde:	call   *0x66309c(%rip)        # e7fc80 <_DYNAMIC+0x518>
  81cbe4:	mov    %r14,%rdi
  81cbe7:	mov    %ebp,%esi
  81cbe9:	movq   $0x0,0x330(%rdi)
  81cbf4:	mov    %sil,0x341(%rdi)
  81cbfb:	pop    %rbx
  81cbfc:	pop    %r14
  81cbfe:	pop    %rbp
  81cbff:	ret
  81cc00:	movq   $0x0,(%rbx)
  81cc07:	mov    %rax,%rdi
  81cc0a:	call   e2c520 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=303 frame=120

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc10 <<gpui_gpu::renderer::Buffer>::write>:
  81cc10:	push   %r15
  81cc12:	push   %r14
  81cc14:	push   %r13
  81cc16:	push   %r12
  81cc18:	push   %rbx
  81cc19:	sub    $0x50,%rsp
  81cc1d:	mov    %rdx,%r14
  81cc20:	mov    %rdi,%rbx
  81cc23:	cmp    0x20(%rdi),%r8
  81cc27:	jbe    81ccda <<gpui_gpu::renderer::Buffer>::write+0xca>
  81cc2d:	mov    %rcx,%r15
  81cc30:	mov    $0x1,%r13d
  81cc36:	cmp    $0x2,%r8
  81cc3a:	jb     81cc53 <<gpui_gpu::renderer::Buffer>::write+0x43>
  81cc3c:	lea    -0x1(%r8),%rax
  81cc40:	bsr    %rax,%rcx
  81cc44:	not    %ecx
  81cc46:	mov    $0xffffffffffffffff,%r13
  81cc4d:	shr    %cl,%r13
  81cc50:	inc    %r13
  81cc53:	mov    %r8,%r12
  81cc56:	lea    -0x747d75(%rip),%rax        # d4ee8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x142>
  81cc5d:	mov    %rax,0x30(%rsp)
  81cc62:	movq   $0xa,0x38(%rsp)
  81cc6b:	mov    %r13,0x40(%rsp)
  81cc70:	movl   $0x88,0x48(%rsp)
  81cc78:	movb   $0x0,0x4c(%rsp)
  81cc7d:	lea    0x8(%rsp),%rdi
  81cc82:	lea    0x30(%rsp),%rdx
  81cc87:	call   *0x6630fb(%rip)        # e7fd88 <_DYNAMIC+0x620>
  81cc8d:	mov    %r13,0x28(%rsp)
  81cc92:	mov    (%rbx),%rax
  81cc95:	lock decq (%rax)
  81cc99:	jne    81cca4 <<gpui_gpu::renderer::Buffer>::write+0x94>
  81cc9b:	mov    %rbx,%rdi
  81cc9e:	call   *0x662fcc(%rip)        # e7fc70 <_DYNAMIC+0x508>
  81cca4:	mov    0x8(%rbx),%rax
  81cca8:	lock decq (%rax)
  81ccac:	jne    81ccb8 <<gpui_gpu::renderer::Buffer>::write+0xa8>
  81ccae:	lea    0x8(%rbx),%rdi
  81ccb2:	call   *0x662fc0(%rip)        # e7fc78 <_DYNAMIC+0x510>
  81ccb8:	mov    0x28(%rsp),%rax
  81ccbd:	mov    %rax,0x20(%rbx)
  81ccc1:	movups 0x8(%rsp),%xmm0
  81ccc6:	movups 0x18(%rsp),%xmm1
  81cccb:	movups %xmm1,0x10(%rbx)
  81cccf:	movups %xmm0,(%rbx)
  81ccd2:	mov    %r12,%r8
  81ccd5:	mov    %r15,%rcx
  81ccd8:	jmp    81ccdf <<gpui_gpu::renderer::Buffer>::write+0xcf>
  81ccda:	test   %r8,%r8
  81ccdd:	je     81cced <<gpui_gpu::renderer::Buffer>::write+0xdd>
  81ccdf:	mov    %r14,%rdi
  81cce2:	mov    %rbx,%rsi
  81cce5:	xor    %edx,%edx
  81cce7:	call   *0x66304b(%rip)        # e7fd38 <_DYNAMIC+0x5d0>
  81cced:	add    $0x50,%rsp
  81ccf1:	pop    %rbx
  81ccf2:	pop    %r12
  81ccf4:	pop    %r13
  81ccf6:	pop    %r14
  81ccf8:	pop    %r15
  81ccfa:	ret
  81ccfb:	mov    %rax,%r14
  81ccfe:	jmp    81cd17 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cd00:	mov    %rax,%r14
  81cd03:	mov    0x8(%rbx),%rax
  81cd07:	lock decq (%rax)
  81cd0b:	jne    81cd17 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cd0d:	lea    0x8(%rbx),%rdi
  81cd11:	call   *0x662f61(%rip)        # e7fc78 <_DYNAMIC+0x510>
  81cd17:	mov    0x28(%rsp),%rax
  81cd1c:	mov    %rax,0x20(%rbx)
  81cd20:	movups 0x8(%rsp),%xmm0
  81cd25:	movups 0x18(%rsp),%xmm1
  81cd2a:	movups %xmm1,0x10(%rbx)
  81cd2e:	movups %xmm0,(%rbx)
  81cd31:	mov    %r14,%rdi
  81cd34:	call   e2c520 <_Unwind_Resume@plt>
  81cd39:	call   *0x662c79(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cd40 <<gpui_gpu::renderer::Atlas>::new>:
  81cd40:	push   %rbp
  81cd41:	push   %r14
  81cd43:	push   %rbx
  81cd44:	sub    $0x160,%rsp
  81cd4b:	mov    %edx,%ebp
  81cd4d:	mov    %rdi,%rbx
  81cd50:	lea    -0x747e65(%rip),%rax        # d4ef2 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x14c>
  81cd57:	mov    %rax,(%rsp)
  81cd5b:	movq   $0xe,0x8(%rsp)
  81cd64:	mov    %edx,0x10(%rsp)
  81cd68:	mov    %edx,0x14(%rsp)
  81cd6c:	movaps -0x770883(%rip),%xmm0        # ac4f0 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81cd73:	movups %xmm0,0x18(%rsp)
  81cd78:	movl   $0x0,0x28(%rsp)
  81cd80:	movl   $0x6,0x34(%rsp)
  81cd88:	movq   $0x4,0x38(%rsp)
  81cd91:	movq   $0x0,0x40(%rsp)
  81cd9a:	lea    0x110(%rsp),%r14
  81cda2:	mov    %rsp,%rdx
  81cda5:	mov    %r14,%rdi
  81cda8:	call   *0x662e5a(%rip)        # e7fc08 <_DYNAMIC+0x4a0>
  81cdae:	movq   $0x0,0x18(%rsp)
  81cdb7:	movl   $0xffffffff,0x30(%rsp)
  81cdbf:	movl   $0x0,(%rsp)
  81cdc6:	movabs $0xffffffff00000000,%rax
  81cdd0:	mov    %rax,0x28(%rsp)
  81cdd5:	movq   $0x0,0x3c(%rsp)
  81cdde:	movl   $0x0,0x8(%rsp)
  81cde6:	movl   $0x0,0x10(%rsp)
  81cdee:	lea    0xb8(%rsp),%rdi
  81cdf6:	mov    %rsp,%rdx
  81cdf9:	mov    %r14,%rsi
  81cdfc:	call   *0x662e0e(%rip)        # e7fc10 <_DYNAMIC+0x4a8>
  81ce02:	movups 0x150(%rsp),%xmm0
  81ce0a:	movaps %xmm0,0xa0(%rsp)
  81ce12:	movups 0x110(%rsp),%xmm0
  81ce1a:	movups 0x120(%rsp),%xmm1
  81ce22:	movups 0x130(%rsp),%xmm2
  81ce2a:	movups 0x140(%rsp),%xmm3
  81ce32:	movaps %xmm3,0x90(%rsp)
  81ce3a:	movaps %xmm2,0x80(%rsp)
  81ce42:	movaps %xmm1,0x70(%rsp)
  81ce47:	movaps %xmm0,0x60(%rsp)
  81ce4c:	mov    0x108(%rsp),%rax
  81ce54:	mov    %rax,0x50(%rsp)
  81ce59:	movups 0xf8(%rsp),%xmm0
  81ce61:	movaps %xmm0,0x40(%rsp)
  81ce66:	movups 0xb8(%rsp),%xmm0
  81ce6e:	movups 0xc8(%rsp),%xmm1
  81ce76:	movups 0xd8(%rsp),%xmm2
  81ce7e:	movups 0xe8(%rsp),%xmm3
  81ce86:	movaps %xmm3,0x30(%rsp)
  81ce8b:	movaps %xmm2,0x20(%rsp)
  81ce90:	movaps %xmm1,0x10(%rsp)
  81ce95:	movaps %xmm0,(%rsp)
  81ce99:	mov    %fs:0x0,%rax
  81cea2:	lea    -0x28(%rax),%rax
  81cea9:	mov    %rax,%r14
  81ceac:	cmpb   $0x1,0x10(%rax)
  81ceb0:	jne    81cf9b <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81ceb6:	mov    (%r14),%rax
  81ceb9:	mov    0x8(%r14),%rdx
  81cebd:	lea    0x1(%rax),%rcx
  81cec1:	mov    %rcx,(%r14)
  81cec4:	movaps 0xa0(%rsp),%xmm0
  81cecc:	movups %xmm0,0x40(%rbx)
  81ced0:	movaps 0x60(%rsp),%xmm0
  81ced5:	movaps 0x70(%rsp),%xmm1
  81ceda:	movaps 0x80(%rsp),%xmm2
  81cee2:	movaps 0x90(%rsp),%xmm3
  81ceea:	movups %xmm3,0x30(%rbx)
  81ceee:	movups %xmm2,0x20(%rbx)
  81cef2:	movups %xmm1,0x10(%rbx)
  81cef6:	movups %xmm0,(%rbx)
  81cef9:	movups 0xb8(%rsp),%xmm0
  81cf01:	movups 0xc8(%rsp),%xmm1
  81cf09:	movups 0xd8(%rsp),%xmm2
  81cf11:	movups 0xe8(%rsp),%xmm3
  81cf19:	movups %xmm0,0x50(%rbx)
  81cf1d:	movups %xmm1,0x60(%rbx)
  81cf21:	movups %xmm2,0x70(%rbx)
  81cf25:	movups %xmm3,0x80(%rbx)
  81cf2c:	movups 0xf8(%rsp),%xmm0
  81cf34:	movups %xmm0,0x90(%rbx)
  81cf3b:	mov    0x108(%rsp),%rcx
  81cf43:	mov    %rcx,0xa0(%rbx)
  81cf4a:	mov    %ebp,0xd8(%rbx)
  81cf50:	movq   $0x0,0xdc(%rbx)
  81cf5b:	movl   $0x0,0xe4(%rbx)
  81cf65:	movups 0x6113bc(%rip),%xmm0        # e2e328 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x110>
  81cf6c:	movups %xmm0,0xa8(%rbx)
  81cf73:	movups 0x6113be(%rip),%xmm0        # e2e338 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x120>
  81cf7a:	movups %xmm0,0xb8(%rbx)
  81cf81:	mov    %rax,0xc8(%rbx)
  81cf88:	mov    %rdx,0xd0(%rbx)
  81cf8f:	add    $0x160,%rsp
  81cf96:	pop    %rbx
  81cf97:	pop    %r14
  81cf99:	pop    %rbp
  81cf9a:	ret
  81cf9b:	call   *0x662def(%rip)        # e7fd90 <_DYNAMIC+0x628>
  81cfa1:	mov    %rax,(%r14)
  81cfa4:	mov    %rdx,0x8(%r14)
  81cfa8:	movb   $0x1,0x10(%r14)
  81cfad:	jmp    81cebd <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cfb2:	mov    %rax,%rbx
  81cfb5:	mov    %rsp,%rdi
  81cfb8:	call   81c480 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cfbd:	mov    0x60(%rsp),%rax
  81cfc2:	lock decq (%rax)
  81cfc6:	jne    81cff4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfc8:	lea    0x60(%rsp),%rdi
  81cfcd:	call   *0x662c7d(%rip)        # e7fc50 <_DYNAMIC+0x4e8>
  81cfd3:	jmp    81cff4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfd5:	mov    %rax,%rbx
  81cfd8:	mov    0x110(%rsp),%rax
  81cfe0:	lock decq (%rax)
  81cfe4:	jne    81cff4 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfe6:	lea    0x110(%rsp),%rdi
  81cfee:	call   *0x662c5c(%rip)        # e7fc50 <_DYNAMIC+0x4e8>
  81cff4:	mov    %rbx,%rdi
  81cff7:	call   e2c520 <_Unwind_Resume@plt>
  81cffc:	call   *0x6629b6(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d010 <<gpui_gpu::renderer::Atlas>::insert>:
  81d010:	push   %rbp
  81d011:	push   %r15
  81d013:	push   %r14
  81d015:	push   %r13
  81d017:	push   %r12
  81d019:	push   %rbx
  81d01a:	sub    $0x68,%rsp
  81d01e:	mov    %rdx,%r12
  81d021:	mov    %rsi,%r15
  81d024:	mov    %rdi,%r14
  81d027:	lea    0x10(%rdx),%r13
  81d02b:	cmpq   $0x0,0xc0(%rdi)
  81d033:	je     81d0fb <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d039:	lea    0xc8(%r14),%rdi
  81d040:	mov    %r13,%rsi
  81d043:	call   821ef0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81d048:	mov    %rax,%rsi
  81d04b:	shr    $0x39,%rsi
  81d04f:	mov    0xa8(%r14),%rcx
  81d056:	mov    0xb0(%r14),%rdx
  81d05d:	movd   %esi,%xmm0
  81d061:	punpcklbw %xmm0,%xmm0
  81d065:	pshuflw $0x0,%xmm0,%xmm0
  81d06a:	pshufd $0x44,%xmm0,%xmm0
  81d06f:	mov    0x10(%r12),%rsi
  81d074:	movzwl 0x1c(%r12),%edi
  81d07a:	mov    0x18(%r12),%r8d
  81d07f:	pcmpeqd %xmm1,%xmm1
  81d083:	xor    %r9d,%r9d
  81d086:	and    %rdx,%rax
  81d089:	movdqu (%rcx,%rax,1),%xmm2
  81d08e:	movdqa %xmm2,%xmm3
  81d092:	pcmpeqb %xmm0,%xmm3
  81d096:	pmovmskb %xmm3,%r10d
  81d09b:	test   %r10d,%r10d
  81d09e:	je     81d0e0 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81d0a0:	tzcnt  %r10d,%ebx
  81d0a5:	add    %rax,%rbx
  81d0a8:	and    %rdx,%rbx
  81d0ab:	shl    $0x5,%rbx
  81d0af:	mov    %rcx,%r11
  81d0b2:	sub    %rbx,%r11
  81d0b5:	cmp    -0x20(%r11),%rsi
  81d0b9:	jne    81d0cc <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d0bb:	cmp    -0x14(%r11),%di
  81d0c0:	jne    81d0cc <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d0c2:	cmp    -0x18(%r11),%r8d
  81d0c6:	je     81d163 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d0cc:	lea    -0x1(%r10),%r11d
  81d0d0:	and    %r10w,%r11w
  81d0d4:	mov    %r11d,%r10d
  81d0d7:	jne    81d0a0 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d0d9:	nopl   0x0(%rax)
  81d0e0:	pcmpeqb %xmm1,%xmm2
  81d0e4:	pmovmskb %xmm2,%r10d
  81d0e9:	test   %r10d,%r10d
  81d0ec:	jne    81d0fb <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d0ee:	add    %r9,%rax
  81d0f1:	add    $0x10,%rax
  81d0f5:	add    $0x10,%r9
  81d0f9:	jmp    81d086 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d0fb:	mov    0x20(%r12),%ebp
  81d100:	xor    %eax,%eax
  81d102:	test   %ebp,%ebp
  81d104:	je     81d15e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d106:	mov    %r15,%rdi
  81d109:	mov    0x28(%r12),%r15d
  81d10e:	test   %r15d,%r15d
  81d111:	je     81d15e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d113:	mov    0xd8(%r14),%ecx
  81d11a:	cmp    %ebp,%ecx
  81d11c:	jb     81d261 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d122:	cmp    %r15d,%ecx
  81d125:	jb     81d261 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d12b:	mov    %r13,0x40(%rsp)
  81d130:	mov    0xdc(%r14),%r8d
  81d137:	mov    0xe4(%r14),%r13d
  81d13e:	lea    (%r8,%rbp,1),%edx
  81d142:	xor    %eax,%eax
  81d144:	cmp    %ecx,%edx
  81d146:	mov    $0x0,%ebx
  81d14b:	cmova  %r13d,%ebx
  81d14f:	add    0xe0(%r14),%ebx
  81d156:	lea    (%rbx,%r15,1),%esi
  81d15a:	cmp    %ecx,%esi
  81d15c:	jbe    81d16f <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d15e:	jmp    81d261 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d163:	mov    $0x1,%eax
  81d168:	xor    %edx,%edx
  81d16a:	jmp    81d261 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d16f:	cmp    %r13d,%r15d
  81d172:	cmova  %r15d,%r13d
  81d176:	cmp    %ecx,%edx
  81d178:	cmova  %eax,%r8d
  81d17c:	lea    0xa8(%r14),%rax
  81d183:	mov    %rax,0x38(%rsp)
  81d188:	mov    %r14,0x48(%rsp)
  81d18d:	movl   $0x0,0x50(%rsp)
  81d195:	mov    %r8d,0x54(%rsp)
  81d19a:	mov    %ebx,0x58(%rsp)
  81d19e:	movq   $0x0,0x5c(%rsp)
  81d1a7:	mov    (%r12),%rdx
  81d1ab:	mov    0x8(%r12),%rcx
  81d1b0:	mov    %rcx,0x30(%rsp)
  81d1b5:	movq   $0x0,0x8(%rsp)
  81d1be:	movl   $0x1,0x10(%rsp)
  81d1c6:	mov    %ebp,0x14(%rsp)
  81d1ca:	movl   $0x1,0x18(%rsp)
  81d1d2:	mov    %r15d,0x1c(%rsp)
  81d1d7:	mov    %ebp,0x20(%rsp)
  81d1db:	mov    %r15d,0x24(%rsp)
  81d1e0:	movl   $0x1,0x28(%rsp)
  81d1e8:	cmova  %r15d,%r13d
  81d1ec:	lea    0x48(%rsp),%rsi
  81d1f1:	mov    %r8,%r12
  81d1f4:	lea    0x8(%rsp),%r8
  81d1f9:	lea    0x20(%rsp),%r9
  81d1fe:	call   *0x662b94(%rip)        # e7fd98 <_DYNAMIC+0x630>
  81d204:	lea    (%r12,%rbp,1),%eax
  81d208:	mov    %eax,0xdc(%r14)
  81d20f:	mov    %ebx,0xe0(%r14)
  81d216:	mov    %r13d,0xe4(%r14)
  81d21d:	mov    0x40(%rsp),%rax
  81d222:	movdqu (%rax),%xmm0
  81d226:	movdqa %xmm0,0x20(%rsp)
  81d22c:	mov    %r12d,0x8(%rsp)
  81d231:	mov    %ebx,0xc(%rsp)
  81d235:	mov    %ebp,0x10(%rsp)
  81d239:	mov    %r15d,0x14(%rsp)
  81d23e:	lea    0x48(%rsp),%rdi
  81d243:	lea    0x20(%rsp),%rdx
  81d248:	lea    0x8(%rsp),%rcx
  81d24d:	mov    0x38(%rsp),%rsi
  81d252:	call   823720 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d257:	mov    0x30(%rsp),%rdx
  81d25c:	mov    $0x1,%eax
  81d261:	add    $0x68,%rsp
  81d265:	pop    %rbx
  81d266:	pop    %r12
  81d268:	pop    %r13
  81d26a:	pop    %r14
  81d26c:	pop    %r15
  81d26e:	pop    %rbp
  81d26f:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d270 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d270:	push   %r15
  81d272:	push   %r14
  81d274:	push   %r12
  81d276:	push   %rbx
  81d277:	sub    $0x548,%rsp
  81d27e:	mov    %rdx,%r14
  81d281:	mov    %rsi,%r12
  81d284:	mov    %rdi,%rbx
  81d287:	lea    0x61114a(%rip),%rdx        # e2e3d8 <anon.e7af5e0dba0d7261d22cb76253955a85.29.llvm.10167252663607395722>
  81d28e:	lea    0x30(%rsp),%r15
  81d293:	mov    %r15,%rdi
  81d296:	mov    %rbx,%rsi
  81d299:	call   *0x662b01(%rip)        # e7fda0 <_DYNAMIC+0x638>
  81d29f:	xorps  %xmm0,%xmm0
  81d2a2:	movups %xmm0,0x10(%rsp)
  81d2a7:	movups %xmm0,0x20(%rsp)
  81d2ac:	movl   $0x0,0x50(%rsp)
  81d2b4:	movb   $0x0,0x58(%rsp)
  81d2b9:	movups 0x9(%rsp),%xmm0
  81d2be:	movups %xmm0,0x59(%rsp)
  81d2c3:	movups 0x19(%rsp),%xmm0
  81d2c8:	movups %xmm0,0x69(%rsp)
  81d2cd:	mov    0x28(%rsp),%rax
  81d2d2:	mov    %rax,0x78(%rsp)
  81d2d7:	movl   $0x0,0x80(%rsp)
  81d2e2:	mov    %r12,0x88(%rsp)
  81d2ea:	movq   $0x0,0x90(%rsp)
  81d2f6:	lea    -0x7483fd(%rip),%rax        # d4f00 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.10167252663607395722>
  81d2fd:	mov    %rax,0xe0(%rsp)
  81d305:	movq   $0xa,0xe8(%rsp)
  81d311:	lea    0x50(%rsp),%rax
  81d316:	mov    %rax,0xd0(%rsp)
  81d31e:	movq   $0x1,0xd8(%rsp)
  81d32a:	movl   $0xffffffff,0xb8(%rsp)
  81d335:	movl   $0x2,0x98(%rsp)
  81d340:	movq   $0x0,0xf0(%rsp)
  81d34c:	movl   $0x0,0xf8(%rsp)
  81d357:	lea    0x100(%rsp),%rdi
  81d35f:	lea    0x98(%rsp),%rdx
  81d367:	mov    %r15,%rsi
  81d36a:	call   *0x662a38(%rip)        # e7fda8 <_DYNAMIC+0x640>
  81d370:	lea    0x10(%rbx),%rsi
  81d374:	lea    0x100(%rsp),%rdi
  81d37c:	call   *0x662a2e(%rip)        # e7fdb0 <_DYNAMIC+0x648>
  81d382:	lea    0x100(%rsp),%rdi
  81d38a:	mov    $0x4,%ecx
  81d38f:	xor    %esi,%esi
  81d391:	mov    %r14,%rdx
  81d394:	xor    %r8d,%r8d
  81d397:	call   *0x662a1b(%rip)        # e7fdb8 <_DYNAMIC+0x650>
  81d39d:	lea    0x100(%rsp),%rdi
  81d3a5:	xor    %esi,%esi
  81d3a7:	mov    $0x3,%edx
  81d3ac:	xor    %ecx,%ecx
  81d3ae:	mov    $0x1,%r8d
  81d3b4:	call   *0x662a06(%rip)        # e7fdc0 <_DYNAMIC+0x658>
  81d3ba:	lea    0x100(%rsp),%rdi
  81d3c2:	call   81c380 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d3c7:	movups 0x30(%rsp),%xmm0
  81d3cc:	movups 0x40(%rsp),%xmm1
  81d3d1:	movaps %xmm1,0x110(%rsp)
  81d3d9:	movaps %xmm0,0x100(%rsp)
  81d3e1:	lea    0x98(%rsp),%r14
  81d3e9:	lea    0x100(%rsp),%rsi
  81d3f1:	mov    %r14,%rdi
  81d3f4:	call   *0x6629ce(%rip)        # e7fdc8 <_DYNAMIC+0x660>
  81d3fa:	add    $0x8,%rbx
  81d3fe:	mov    %rbx,%rdi
  81d401:	mov    %r14,%rsi
  81d404:	call   825650 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d409:	add    $0x548,%rsp
  81d410:	pop    %rbx
  81d411:	pop    %r12
  81d413:	pop    %r14
  81d415:	pop    %r15
  81d417:	ret
  81d418:	mov    %rax,%rbx
  81d41b:	jmp    81d42d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d41d:	mov    %rax,%rbx
  81d420:	lea    0x100(%rsp),%rdi
  81d428:	call   81c380 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d42d:	lea    0x30(%rsp),%rdi
  81d432:	call   81c4f0 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d437:	mov    %rbx,%rdi
  81d43a:	call   e2c520 <_Unwind_Resume@plt>
  81d43f:	call   *0x662573(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d450 <<gpui_gpu::renderer::RendererState>::correction>:
  81d450:	push   %r15
  81d452:	push   %r14
  81d454:	push   %r13
  81d456:	push   %r12
  81d458:	push   %rbx
  81d459:	sub    $0x90,%rsp
  81d460:	mov    %rdi,%rbx
  81d463:	movss  (%rdx),%xmm1
  81d467:	movss  0x8(%rdx),%xmm2
  81d46c:	movaps %xmm1,%xmm0
  81d46f:	addss  %xmm2,%xmm0
  81d473:	movd   %xmm0,%eax
  81d477:	and    $0x7fffffff,%eax
  81d47c:	xorps  %xmm8,%xmm8
  81d480:	xorps  %xmm9,%xmm9
  81d484:	cmp    $0x7f7fffff,%eax
  81d489:	jg     81d4a8 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d48b:	cvtss2sd %xmm1,%xmm1
  81d48f:	cvtss2sd %xmm2,%xmm2
  81d493:	cvtss2sd %xmm0,%xmm0
  81d497:	addsd  %xmm1,%xmm2
  81d49b:	subsd  %xmm0,%xmm2
  81d49f:	xorps  %xmm9,%xmm9
  81d4a3:	cvtsd2ss %xmm2,%xmm9
  81d4a8:	movupd (%rsi),%xmm0
  81d4ac:	movupd 0x8(%rsi),%xmm1
  81d4b1:	movsd  0x10(%rsi),%xmm2
  81d4b6:	movsd  0x18(%rsi),%xmm3
  81d4bb:	movupd 0x20(%rsi),%xmm4
  81d4c0:	movss  0x4(%rdx),%xmm6
  81d4c5:	movss  0xc(%rdx),%xmm7
  81d4ca:	movaps %xmm6,%xmm5
  81d4cd:	addss  %xmm7,%xmm5
  81d4d1:	movd   %xmm5,%eax
  81d4d5:	and    $0x7fffffff,%eax
  81d4da:	cmp    $0x7f7fffff,%eax
  81d4df:	jg     81d4fe <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d4e1:	cvtss2sd %xmm6,%xmm6
  81d4e5:	cvtss2sd %xmm7,%xmm7
  81d4e9:	cvtss2sd %xmm5,%xmm5
  81d4ed:	addsd  %xmm6,%xmm7
  81d4f1:	subsd  %xmm5,%xmm7
  81d4f5:	xorps  %xmm8,%xmm8
  81d4f9:	cvtsd2ss %xmm7,%xmm8
  81d4fe:	cvtpd2ps %xmm4,%xmm5
  81d502:	cvtps2pd %xmm5,%xmm5
  81d505:	subpd  %xmm5,%xmm4
  81d509:	cvtpd2ps %xmm4,%xmm4
  81d50d:	unpcklpd %xmm3,%xmm1
  81d511:	cvtpd2ps %xmm1,%xmm3
  81d515:	unpcklpd %xmm2,%xmm0
  81d519:	cvtpd2ps %xmm0,%xmm2
  81d51d:	cvtps2pd %xmm3,%xmm3
  81d520:	subpd  %xmm3,%xmm1
  81d524:	cvtpd2ps %xmm1,%xmm5
  81d528:	cvtps2pd %xmm2,%xmm1
  81d52b:	subpd  %xmm1,%xmm0
  81d52f:	cvtpd2ps %xmm0,%xmm6
  81d533:	movapd %xmm6,%xmm0
  81d537:	unpcklps %xmm5,%xmm0
  81d53a:	movaps %xmm8,%xmm1
  81d53e:	movlhps %xmm9,%xmm1
  81d542:	movapd %xmm4,%xmm2
  81d546:	shufps $0x24,%xmm1,%xmm2
  81d54a:	xorps  %xmm1,%xmm1
  81d54d:	movapd %xmm0,%xmm3
  81d551:	cmpneqps %xmm1,%xmm3
  81d555:	cmpneqps %xmm1,%xmm2
  81d559:	packssdw %xmm2,%xmm3
  81d55d:	pmovmskb %xmm3,%eax
  81d561:	test   %eax,%eax
  81d563:	je     81d687 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d569:	movapd %xmm6,0x60(%rsp)
  81d56f:	movapd %xmm5,0x70(%rsp)
  81d575:	lea    0x8(%rsp),%r12
  81d57a:	movapd %xmm0,(%rsp)
  81d57f:	movapd %xmm4,0x80(%rsp)
  81d588:	movlpd %xmm4,0x10(%rsp)
  81d58e:	movss  %xmm9,0x18(%rsp)
  81d595:	movss  %xmm8,0x1c(%rsp)
  81d59c:	lea    0x318(%rbx),%r14
  81d5a3:	mov    %rsp,%rsi
  81d5a6:	mov    %r14,%rdi
  81d5a9:	movaps %xmm8,0x30(%rsp)
  81d5af:	movaps %xmm9,0x20(%rsp)
  81d5b5:	call   821d70 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d5ba:	movapd 0x20(%rsp),%xmm6
  81d5c0:	movapd 0x30(%rsp),%xmm5
  81d5c6:	mov    %rax,%r15
  81d5c9:	shr    $0x39,%r15
  81d5cd:	mov    0x2f8(%rbx),%rcx
  81d5d4:	mov    0x300(%rbx),%rdx
  81d5db:	movd   %r15d,%xmm0
  81d5e0:	punpcklbw %xmm0,%xmm0
  81d5e4:	pshuflw $0x0,%xmm0,%xmm0
  81d5e9:	pshufd $0x44,%xmm0,%xmm0
  81d5ee:	xor    %esi,%esi
  81d5f0:	pcmpeqd %xmm1,%xmm1
  81d5f4:	mov    %rax,%rdi
  81d5f7:	and    %rdx,%rdi
  81d5fa:	movdqu (%rcx,%rdi,1),%xmm2
  81d5ff:	movdqa %xmm2,%xmm3
  81d603:	pcmpeqb %xmm0,%xmm3
  81d607:	pmovmskb %xmm3,%r8d
  81d60c:	test   %r8d,%r8d
  81d60f:	je     81d660 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d611:	tzcnt  %r8d,%r9d
  81d616:	add    %rdi,%r9
  81d619:	and    %rdx,%r9
  81d61c:	neg    %r9
  81d61f:	lea    (%r9,%r9,8),%r9
  81d623:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d62a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d631:	pcmpeqb 0x10(%rsp),%xmm4
  81d637:	pcmpeqb (%rsp),%xmm3
  81d63c:	pand   %xmm4,%xmm3
  81d640:	pmovmskb %xmm3,%r10d
  81d645:	cmp    $0xffff,%r10d
  81d64c:	je     81d67e <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d64e:	lea    -0x1(%r8),%r9d
  81d652:	and    %r8w,%r9w
  81d656:	mov    %r9d,%r8d
  81d659:	jne    81d611 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d65b:	nopl   0x0(%rax,%rax,1)
  81d660:	pcmpeqb %xmm1,%xmm2
  81d664:	pmovmskb %xmm2,%r8d
  81d669:	test   %r8d,%r8d
  81d66c:	jne    81d68e <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d66e:	add    %rsi,%rdi
  81d671:	add    $0x10,%rdi
  81d675:	add    $0x10,%rsi
  81d679:	jmp    81d5f7 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d67e:	lea    (%rcx,%r9,4),%rdx
  81d682:	jmp    81d7a9 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d687:	xor    %eax,%eax
  81d689:	jmp    81d7ac <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d68e:	cmpq   $0x0,0x308(%rbx)
  81d696:	je     81d7df <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d69c:	mov    (%rsp),%r14
  81d6a0:	mov    0x10(%r12),%rcx
  81d6a5:	mov    %rcx,0x50(%rsp)
  81d6aa:	movups (%r12),%xmm0
  81d6af:	movaps %xmm0,0x40(%rsp)
  81d6b4:	mov    0x70(%rbx),%r12
  81d6b8:	cmp    0x60(%rbx),%r12
  81d6bc:	jne    81d6da <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d6be:	lea    0x60(%rbx),%rdi
  81d6c2:	mov    %rax,%r13
  81d6c5:	call   *0x66264d(%rip)        # e7fd18 <_DYNAMIC+0x5b0>
  81d6cb:	movapd 0x20(%rsp),%xmm6
  81d6d1:	movapd 0x30(%rsp),%xmm5
  81d6d7:	mov    %r13,%rax
  81d6da:	mov    0x68(%rbx),%rcx
  81d6de:	mov    %r12,%rdx
  81d6e1:	shl    $0x5,%rdx
  81d6e5:	movaps 0x60(%rsp),%xmm0
  81d6ea:	movlps %xmm0,(%rcx,%rdx,1)
  81d6ee:	movaps 0x80(%rsp),%xmm0
  81d6f6:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d6fc:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d702:	movdqa 0x70(%rsp),%xmm1
  81d708:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d70e:	shufps $0x55,%xmm0,%xmm0
  81d712:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d718:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d71e:	lea    0x1(%r12),%rcx
  81d723:	mov    %rcx,0x70(%rbx)
  81d727:	mov    0x2f8(%rbx),%rcx
  81d72e:	mov    0x300(%rbx),%rdx
  81d735:	and    %rdx,%rax
  81d738:	movdqu (%rcx,%rax,1),%xmm0
  81d73d:	pmovmskb %xmm0,%esi
  81d741:	test   %esi,%esi
  81d743:	je     81d7bd <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d745:	tzcnt  %esi,%esi
  81d749:	add    %rax,%rsi
  81d74c:	and    %rdx,%rsi
  81d74f:	movzbl (%rcx,%rsi,1),%eax
  81d753:	test   %al,%al
  81d755:	jns    81d810 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d75b:	lea    -0x10(%rsi),%rdi
  81d75f:	and    %rdx,%rdi
  81d762:	mov    %r15b,(%rcx,%rsi,1)
  81d766:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d76b:	neg    %rsi
  81d76e:	lea    (%rsi,%rsi,8),%rsi
  81d772:	lea    (%rcx,%rsi,4),%rdx
  81d776:	and    $0x1,%al
  81d778:	movzbl %al,%eax
  81d77b:	sub    %rax,0x308(%rbx)
  81d782:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d787:	movdqa 0x40(%rsp),%xmm0
  81d78d:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d793:	mov    0x50(%rsp),%rax
  81d798:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d79d:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d7a2:	incq   0x310(%rbx)
  81d7a9:	mov    -0x4(%rdx),%eax
  81d7ac:	add    $0x90,%rsp
  81d7b3:	pop    %rbx
  81d7b4:	pop    %r12
  81d7b6:	pop    %r13
  81d7b8:	pop    %r14
  81d7ba:	pop    %r15
  81d7bc:	ret
  81d7bd:	mov    $0x10,%edi
  81d7c2:	add    %rdi,%rax
  81d7c5:	and    %rdx,%rax
  81d7c8:	movdqu (%rcx,%rax,1),%xmm0
  81d7cd:	pmovmskb %xmm0,%esi
  81d7d1:	add    $0x10,%rdi
  81d7d5:	test   %esi,%esi
  81d7d7:	jne    81d745 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d7dd:	jmp    81d7c2 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d7df:	lea    0x2f8(%rbx),%rdi
  81d7e6:	mov    $0x1,%esi
  81d7eb:	mov    %r14,%rdx
  81d7ee:	mov    $0x1,%ecx
  81d7f3:	mov    %rax,%r14
  81d7f6:	call   *0x6625d4(%rip)        # e7fdd0 <_DYNAMIC+0x668>
  81d7fc:	movapd 0x20(%rsp),%xmm6
  81d802:	movapd 0x30(%rsp),%xmm5
  81d808:	mov    %r14,%rax
  81d80b:	jmp    81d69c <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d810:	movdqa (%rcx),%xmm0
  81d814:	pmovmskb %xmm0,%eax
  81d818:	tzcnt  %eax,%esi
  81d81c:	movzbl (%rcx,%rsi,1),%eax
  81d820:	jmp    81d75b <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d830 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d830:	push   %rbp
  81d831:	push   %r15
  81d833:	push   %r14
  81d835:	push   %r13
  81d837:	push   %r12
  81d839:	push   %rbx
  81d83a:	sub    $0x228,%rsp
  81d841:	mov    %rsi,%r14
  81d844:	test   %r8d,%r8d
  81d847:	je     81d8db <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d84d:	mov    %rdi,0x10(%rsp)
  81d852:	mov    0x110(%rcx),%rbp
  81d859:	test   %rbp,%rbp
  81d85c:	je     81d93f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d862:	mov    0x108(%rcx),%r13
  81d869:	shl    $0x3,%rbp
  81d86d:	mov    %r14,0x8(%rsp)
  81d872:	lea    0x78(%r14),%rdi
  81d876:	mov    %rdx,0x18(%rsp)
  81d87b:	lea    0x8(%rdx),%rax
  81d87f:	mov    %rax,0x20(%rsp)
  81d884:	xor    %ebx,%ebx
  81d886:	lea    0x28(%rsp),%r15
  81d88b:	xor    %r12d,%r12d
  81d88e:	xchg   %ax,%ax
  81d890:	mov    0x0(%r13,%r12,1),%rax
  81d895:	movups 0x28(%rax),%xmm0
  81d899:	lea    0x38(%rsp),%rcx
  81d89e:	movups %xmm0,(%rcx)
  81d8a1:	movups 0x18(%rax),%xmm0
  81d8a5:	movups %xmm0,0x28(%rsp)
  81d8aa:	movups 0x38(%rax),%xmm0
  81d8ae:	movups %xmm0,0x48(%rsp)
  81d8b3:	mov    %rdi,%r14
  81d8b6:	mov    0x20(%rsp),%rsi
  81d8bb:	mov    %r15,%rdx
  81d8be:	call   81d010 <<gpui_gpu::renderer::Atlas>::insert>
  81d8c3:	test   $0x1,%al
  81d8c5:	je     81d946 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d8c7:	add    %rdx,%rbx
  81d8ca:	add    $0x8,%r12
  81d8ce:	cmp    %r12,%rbp
  81d8d1:	mov    %r14,%rdi
  81d8d4:	jne    81d890 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d8d6:	jmp    81da4e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d8db:	cmpl   $0x1,0x150(%r14)
  81d8e3:	jne    81d8f5 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d8e5:	mov    0x138(%r14),%rax
  81d8ec:	add    0x130(%r14),%rax
  81d8f3:	je     81d92c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d8f5:	mov    %rdi,%rbx
  81d8f8:	add    $0x78,%r14
  81d8fc:	lea    0x58(%rsp),%rdi
  81d901:	mov    %rdx,%rsi
  81d904:	mov    $0x1,%edx
  81d909:	call   81cd40 <<gpui_gpu::renderer::Atlas>::new>
  81d90e:	mov    %r14,%rdi
  81d911:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d916:	lea    0x58(%rsp),%rsi
  81d91b:	mov    $0xe8,%edx
  81d920:	mov    %r14,%rdi
  81d923:	call   *0x6620df(%rip)        # e7fa08 <memcpy@GLIBC_2.14>
  81d929:	mov    %rbx,%rdi
  81d92c:	movq   $0x0,0x8(%rdi)
  81d934:	movl   $0xffffffff,(%rdi)
  81d93a:	jmp    81da5d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d93f:	xor    %ebx,%ebx
  81d941:	jmp    81da4e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d946:	mov    0x8(%rsp),%rax
  81d94b:	mov    0x150(%rax),%eax
  81d951:	cmp    $0x81,%eax
  81d956:	mov    $0x80,%edx
  81d95b:	cmovae %eax,%edx
  81d95e:	add    %edx,%edx
  81d960:	cmp    $0x800,%edx
  81d966:	mov    $0x800,%eax
  81d96b:	cmovae %eax,%edx
  81d96e:	lea    0x140(%rsp),%r12
  81d976:	mov    %r12,%rdi
  81d979:	mov    0x18(%rsp),%rsi
  81d97e:	mov    %edx,0x8(%rsp)
  81d982:	call   81cd40 <<gpui_gpu::renderer::Atlas>::new>
  81d987:	xor    %r15d,%r15d
  81d98a:	nopw   0x0(%rax,%rax,1)
  81d990:	mov    0x0(%r13,%r15,1),%rax
  81d995:	movups 0x28(%rax),%xmm0
  81d999:	lea    0x68(%rsp),%rcx
  81d99e:	movups %xmm0,(%rcx)
  81d9a1:	movups 0x18(%rax),%xmm0
  81d9a5:	movups %xmm0,0x58(%rsp)
  81d9aa:	movups 0x38(%rax),%xmm0
  81d9ae:	movups %xmm0,0x78(%rsp)
  81d9b3:	mov    %r12,%rdi
  81d9b6:	mov    0x20(%rsp),%rsi
  81d9bb:	lea    0x58(%rsp),%rdx
  81d9c0:	call   81d010 <<gpui_gpu::renderer::Atlas>::insert>
  81d9c5:	cmp    $0x1,%rax
  81d9c9:	jne    81d9d9 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d9cb:	add    %rdx,%rbx
  81d9ce:	add    $0x8,%r15
  81d9d2:	cmp    %r15,%rbp
  81d9d5:	jne    81d990 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d9d7:	jmp    81da1b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d9d9:	mov    0x8(%rsp),%r15d
  81d9de:	cmp    $0x800,%r15d
  81d9e5:	je     81da6f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81d9eb:	mov    %r12,%rdi
  81d9ee:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d9f3:	add    %r15d,%r15d
  81d9f6:	cmp    $0x800,%r15d
  81d9fd:	mov    $0x800,%eax
  81da02:	cmovae %eax,%r15d
  81da06:	mov    %r12,%rdi
  81da09:	mov    0x18(%rsp),%rsi
  81da0e:	mov    %r15d,0x8(%rsp)
  81da13:	mov    %r15d,%edx
  81da16:	jmp    81d982 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81da1b:	lea    0x58(%rsp),%rdi
  81da20:	lea    0x140(%rsp),%rsi
  81da28:	mov    $0xe8,%edx
  81da2d:	call   *0x661fd5(%rip)        # e7fa08 <memcpy@GLIBC_2.14>
  81da33:	mov    %r14,%rdi
  81da36:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da3b:	lea    0x58(%rsp),%rsi
  81da40:	mov    $0xe8,%edx
  81da45:	mov    %r14,%rdi
  81da48:	call   *0x661fba(%rip)        # e7fa08 <memcpy@GLIBC_2.14>
  81da4e:	mov    0x10(%rsp),%rax
  81da53:	mov    %rbx,0x8(%rax)
  81da57:	movl   $0xffffffff,(%rax)
  81da5d:	add    $0x228,%rsp
  81da64:	pop    %rbx
  81da65:	pop    %r12
  81da67:	pop    %r13
  81da69:	pop    %r14
  81da6b:	pop    %r15
  81da6d:	pop    %rbp
  81da6e:	ret
  81da6f:	mov    0x10(%rsp),%rax
  81da74:	movl   $0x7,(%rax)
  81da7a:	lea    0x140(%rsp),%rdi
  81da82:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da87:	jmp    81da5d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81da89:	jmp    81da8b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81da8b:	mov    %rax,%rbx
  81da8e:	lea    0x58(%rsp),%rsi
  81da93:	mov    $0xe8,%edx
  81da98:	mov    %r14,%rdi
  81da9b:	call   *0x661f67(%rip)        # e7fa08 <memcpy@GLIBC_2.14>
  81daa1:	mov    %rbx,%rdi
  81daa4:	call   e2c520 <_Unwind_Resume@plt>
  81daa9:	mov    %rax,%rbx
  81daac:	lea    0x140(%rsp),%rdi
  81dab4:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81dab9:	mov    %rbx,%rdi
  81dabc:	call   e2c520 <_Unwind_Resume@plt>
  81dac1:	call   *0x661ef1(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1527 frame=952

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081dad0 <<gpui_gpu::renderer::RendererState>::new>:
  81dad0:	push   %r15
  81dad2:	push   %r14
  81dad4:	push   %r13
  81dad6:	push   %r12
  81dad8:	push   %rbx
  81dad9:	sub    $0x390,%rsp
  81dae0:	mov    %rsi,%r14
  81dae3:	mov    %rdi,%rbx
  81dae6:	lea    -0x748be3(%rip),%rax        # d4f0a <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.10167252663607395722+0xa>
  81daed:	mov    %rax,0xd8(%rsp)
  81daf5:	movq   $0x7,0xe0(%rsp)
  81db01:	movq   $0x30,0xe8(%rsp)
  81db0d:	movl   $0x48,0xf0(%rsp)
  81db18:	movb   $0x0,0xf4(%rsp)
  81db20:	mov    0x662261(%rip),%r15        # e7fd88 <_DYNAMIC+0x620>
  81db27:	lea    0x10(%rsp),%rdi
  81db2c:	lea    0xd8(%rsp),%rdx
  81db34:	call   *%r15
  81db37:	movq   $0x30,0x30(%rsp)
  81db40:	lea    -0x748c36(%rip),%rax        # d4f11 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.10167252663607395722+0x11>
  81db47:	mov    %rax,0xd8(%rsp)
  81db4f:	movq   $0x5,0xe0(%rsp)
  81db5b:	movq   $0x10,0xe8(%rsp)
  81db67:	movl   $0x88,0xf0(%rsp)
  81db72:	movb   $0x0,0xf4(%rsp)
  81db7a:	lea    0x38(%rsp),%rdi
  81db7f:	lea    0xd8(%rsp),%rdx
  81db87:	mov    %r14,%rsi
  81db8a:	call   *%r15
  81db8d:	movq   $0x10,0x58(%rsp)
  81db96:	lea    -0x748c87(%rip),%rax        # d4f16 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.10167252663607395722+0x16>
  81db9d:	mov    %rax,0xd8(%rsp)
  81dba5:	movq   $0x5,0xe0(%rsp)
  81dbb1:	movq   $0x8,0xe8(%rsp)
  81dbbd:	movl   $0x88,0xf0(%rsp)
  81dbc8:	movb   $0x0,0xf4(%rsp)
  81dbd0:	lea    0x60(%rsp),%rdi
  81dbd5:	lea    0xd8(%rsp),%rdx
  81dbdd:	mov    %r14,%rsi
  81dbe0:	call   *0x6621a2(%rip)        # e7fd88 <_DYNAMIC+0x620>
  81dbe6:	movq   $0x8,0x80(%rsp)
  81dbf2:	lea    -0x748cde(%rip),%rax        # d4f1b <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.10167252663607395722+0x1b>
  81dbf9:	mov    %rax,0xd8(%rsp)
  81dc01:	movq   $0x7,0xe0(%rsp)
  81dc0d:	movq   $0x4,0xe8(%rsp)
  81dc19:	movl   $0x88,0xf0(%rsp)
  81dc24:	movb   $0x0,0xf4(%rsp)
  81dc2c:	lea    0x88(%rsp),%rdi
  81dc34:	lea    0xd8(%rsp),%rdx
  81dc3c:	mov    %r14,%rsi
  81dc3f:	call   *0x662143(%rip)        # e7fd88 <_DYNAMIC+0x620>
  81dc45:	movq   $0x4,0xa8(%rsp)
  81dc51:	lea    -0x748d36(%rip),%rax        # d4f22 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.10167252663607395722+0x22>
  81dc58:	mov    %rax,0xd8(%rsp)
  81dc60:	movq   $0x11,0xe0(%rsp)
  81dc6c:	movq   $0x20,0xe8(%rsp)
  81dc78:	movl   $0x88,0xf0(%rsp)
  81dc83:	movb   $0x0,0xf4(%rsp)
  81dc8b:	lea    0xb0(%rsp),%rdi
  81dc93:	lea    0xd8(%rsp),%rdx
  81dc9b:	mov    %r14,%rsi
  81dc9e:	call   *0x6620e4(%rip)        # e7fd88 <_DYNAMIC+0x620>
  81dca4:	movq   $0x20,0xd0(%rsp)
  81dcb0:	lea    0x2a8(%rsp),%rdi
  81dcb8:	mov    %r14,%rsi
  81dcbb:	mov    $0x1,%edx
  81dcc0:	call   81cd40 <<gpui_gpu::renderer::Atlas>::new>
  81dcc5:	mov    0x18(%r14),%r13
  81dcc9:	lock incq 0x0(%r13)
  81dcce:	jle    81e003 <<gpui_gpu::renderer::RendererState>::new+0x533>
  81dcd4:	mov    %r13,0x8(%rsp)
  81dcd9:	mov    0x30(%rsp),%rax
  81dcde:	mov    %rax,0x1e0(%rsp)
  81dce6:	movups 0x10(%rsp),%xmm0
  81dceb:	movups 0x20(%rsp),%xmm1
  81dcf0:	movaps %xmm1,0x1d0(%rsp)
  81dcf8:	movaps %xmm0,0x1c0(%rsp)
  81dd00:	mov    0x58(%rsp),%rax
  81dd05:	mov    %rax,0x210(%rsp)
  81dd0d:	movups 0x38(%rsp),%xmm0
  81dd12:	movups 0x48(%rsp),%xmm1
  81dd17:	movaps %xmm1,0x200(%rsp)
  81dd1f:	movaps %xmm0,0x1f0(%rsp)
  81dd27:	mov    0x80(%rsp),%rax
  81dd2f:	mov    %rax,0x240(%rsp)
  81dd37:	movups 0x60(%rsp),%xmm0
  81dd3c:	movups 0x70(%rsp),%xmm1
  81dd41:	movaps %xmm1,0x230(%rsp)
  81dd49:	movaps %xmm0,0x220(%rsp)
  81dd51:	mov    0xa8(%rsp),%rax
  81dd59:	mov    %rax,0x270(%rsp)
  81dd61:	movups 0x88(%rsp),%xmm0
  81dd69:	movups 0x98(%rsp),%xmm1
  81dd71:	movaps %xmm1,0x260(%rsp)
  81dd79:	movaps %xmm0,0x250(%rsp)
  81dd81:	mov    0xd0(%rsp),%rax
  81dd89:	mov    %rax,0x2a0(%rsp)
  81dd91:	movups 0xb0(%rsp),%xmm0
  81dd99:	movups 0xc0(%rsp),%xmm1
  81dda1:	movaps %xmm1,0x290(%rsp)
  81dda9:	movaps %xmm0,0x280(%rsp)
  81ddb1:	lea    0xd8(%rsp),%rdi
  81ddb9:	lea    0x2a8(%rsp),%rsi
  81ddc1:	mov    $0xe8,%edx
  81ddc6:	call   *0x661c3c(%rip)        # e7fa08 <memcpy@GLIBC_2.14>
  81ddcc:	mov    %fs:0x0,%rax
  81ddd5:	lea    -0x28(%rax),%rax
  81dddc:	mov    %rax,%r12
  81dddf:	cmpb   $0x1,0x10(%rax)
  81dde3:	jne    81dfe3 <<gpui_gpu::renderer::RendererState>::new+0x513>
  81dde9:	mov    (%r12),%r14
  81dded:	mov    0x8(%r12),%r15
  81ddf2:	lea    0x1(%r14),%rax
  81ddf6:	mov    %rax,(%r12)
  81ddfa:	mov    %r13,0x228(%rbx)
  81de01:	mov    0x30(%rsp),%rax
  81de06:	mov    %rax,0x250(%rbx)
  81de0d:	movups 0x10(%rsp),%xmm0
  81de12:	movups 0x20(%rsp),%xmm1
  81de17:	movups %xmm1,0x240(%rbx)
  81de1e:	movups %xmm0,0x230(%rbx)
  81de25:	mov    0x58(%rsp),%rax
  81de2a:	mov    %rax,0x278(%rbx)
  81de31:	movups 0x38(%rsp),%xmm0
  81de36:	movups 0x48(%rsp),%xmm1
  81de3b:	movups %xmm1,0x268(%rbx)
  81de42:	movups %xmm0,0x258(%rbx)
  81de49:	mov    0x80(%rsp),%rax
  81de51:	mov    %rax,0x2a0(%rbx)
  81de58:	movups 0x60(%rsp),%xmm0
  81de5d:	movups 0x70(%rsp),%xmm1
  81de62:	movups %xmm1,0x290(%rbx)
  81de69:	movups %xmm0,0x280(%rbx)
  81de70:	movups 0x88(%rsp),%xmm0
  81de78:	movups 0x98(%rsp),%xmm1
  81de80:	movups %xmm0,0x2a8(%rbx)
  81de87:	movups %xmm1,0x2b8(%rbx)
  81de8e:	mov    0xa8(%rsp),%rax
  81de96:	mov    %rax,0x2c8(%rbx)
  81de9d:	movups 0xb0(%rsp),%xmm0
  81dea5:	movups 0xc0(%rsp),%xmm1
  81dead:	movups %xmm0,0x2d0(%rbx)
  81deb4:	movups %xmm1,0x2e0(%rbx)
  81debb:	mov    0xd0(%rsp),%rax
  81dec3:	mov    %rax,0x2f0(%rbx)
  81deca:	lea    0x78(%rbx),%rdi
  81dece:	lea    0x2a8(%rsp),%rsi
  81ded6:	mov    $0xe8,%edx
  81dedb:	call   *0x661b27(%rip)        # e7fa08 <memcpy@GLIBC_2.14>
  81dee1:	movq   $0x0,0x328(%rbx)
  81deec:	movq   $0x0,(%rbx)
  81def3:	movq   $0x4,0x8(%rbx)
  81defb:	xorps  %xmm0,%xmm0
  81defe:	movups %xmm0,0x10(%rbx)
  81df02:	movq   $0x4,0x20(%rbx)
  81df0a:	movups %xmm0,0x28(%rbx)
  81df0e:	movq   $0x4,0x38(%rbx)
  81df16:	movups %xmm0,0x40(%rbx)
  81df1a:	movq   $0x4,0x50(%rbx)
  81df22:	movups %xmm0,0x58(%rbx)
  81df26:	movq   $0x4,0x68(%rbx)
  81df2e:	movq   $0x0,0x70(%rbx)
  81df36:	movups 0x6103eb(%rip),%xmm1        # e2e328 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x110>
  81df3d:	movups %xmm1,0x2f8(%rbx)
  81df44:	movups 0x6103ed(%rip),%xmm1        # e2e338 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x120>
  81df4b:	movups %xmm1,0x308(%rbx)
  81df52:	mov    %r14,0x318(%rbx)
  81df59:	mov    %r15,0x320(%rbx)
  81df60:	movw   $0x101,0x340(%rbx)
  81df69:	movq   $0x0,0x330(%rbx)
  81df74:	movups %xmm0,0x210(%rbx)
  81df7b:	movups %xmm0,0x200(%rbx)
  81df82:	movups %xmm0,0x1f0(%rbx)
  81df89:	movups %xmm0,0x1e0(%rbx)
  81df90:	movups %xmm0,0x1d0(%rbx)
  81df97:	movups %xmm0,0x1c0(%rbx)
  81df9e:	movups %xmm0,0x1b0(%rbx)
  81dfa5:	movups %xmm0,0x1a0(%rbx)
  81dfac:	movups %xmm0,0x190(%rbx)
  81dfb3:	movups %xmm0,0x180(%rbx)
  81dfba:	movups %xmm0,0x170(%rbx)
  81dfc1:	movups %xmm0,0x160(%rbx)
  81dfc8:	movb   $0x0,0x220(%rbx)
  81dfcf:	mov    %rbx,%rax
  81dfd2:	add    $0x390,%rsp
  81dfd9:	pop    %rbx
  81dfda:	pop    %r12
  81dfdc:	pop    %r13
  81dfde:	pop    %r14
  81dfe0:	pop    %r15
  81dfe2:	ret
  81dfe3:	call   *0x661da7(%rip)        # e7fd90 <_DYNAMIC+0x628>
  81dfe9:	mov    %rax,%r14
  81dfec:	mov    %rdx,%r15
  81dfef:	mov    %rax,(%r12)
  81dff3:	mov    %rdx,0x8(%r12)
  81dff8:	movb   $0x1,0x10(%r12)
  81dffe:	jmp    81ddf2 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81e003:	ud2
  81e005:	mov    %rax,%rbx
  81e008:	lea    0xd8(%rsp),%rdi
  81e010:	call   81bb30 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81e015:	lea    0x280(%rsp),%rdi
  81e01d:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e022:	lea    0x250(%rsp),%rdi
  81e02a:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e02f:	lea    0x220(%rsp),%rdi
  81e037:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e03c:	lea    0x1f0(%rsp),%rdi
  81e044:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e049:	lea    0x1c0(%rsp),%rdi
  81e051:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e056:	lock decq 0x0(%r13)
  81e05b:	jne    81e0b9 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81e05d:	lea    0x8(%rsp),%rdi
  81e062:	call   *0x661b68(%rip)        # e7fbd0 <_DYNAMIC+0x468>
  81e068:	jmp    81e0b9 <<gpui_gpu::renderer::RendererState>::new+0x5e9>
  81e06a:	mov    %rax,%rbx
  81e06d:	lea    0xb0(%rsp),%rdi
  81e075:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e07a:	jmp    81e07f <<gpui_gpu::renderer::RendererState>::new+0x5af>
  81e07c:	mov    %rax,%rbx
  81e07f:	lea    0x88(%rsp),%rdi
  81e087:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e08c:	jmp    81e091 <<gpui_gpu::renderer::RendererState>::new+0x5c1>
  81e08e:	mov    %rax,%rbx
  81e091:	lea    0x60(%rsp),%rdi
  81e096:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e09b:	jmp    81e0a0 <<gpui_gpu::renderer::RendererState>::new+0x5d0>
  81e09d:	mov    %rax,%rbx
  81e0a0:	lea    0x38(%rsp),%rdi
  81e0a5:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0aa:	jmp    81e0af <<gpui_gpu::renderer::RendererState>::new+0x5df>
  81e0ac:	mov    %rax,%rbx
  81e0af:	lea    0x10(%rsp),%rdi
  81e0b4:	call   81bc10 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0b9:	mov    %rbx,%rdi
  81e0bc:	call   e2c520 <_Unwind_Resume@plt>
  81e0c1:	call   *0x6618f1(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9493 frame=1416

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0d0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0d0:	push   %rbp
  81e0d1:	push   %r15
  81e0d3:	push   %r14
  81e0d5:	push   %r13
  81e0d7:	push   %r12
  81e0d9:	push   %rbx
  81e0da:	sub    $0x558,%rsp
  81e0e1:	mov    0x228(%rsi),%rax
  81e0e8:	mov    0x18(%rdx),%r9
  81e0ec:	cmp    %r9,%rax
  81e0ef:	je     81e10d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0f1:	mov    0x10(%rax),%r10
  81e0f5:	cmp    0x10(%r9),%r10
  81e0f9:	jne    81e1da <<gpui_gpu::renderer::RendererState>::render+0x10a>
  81e0ff:	mov    0x18(%rax),%rax
  81e103:	cmp    0x18(%r9),%rax
  81e107:	jne    81e1da <<gpui_gpu::renderer::RendererState>::render+0x10a>
  81e10d:	lea    0x330(%rsi),%rbx
  81e114:	mov    0x330(%rsi),%rax
  81e11b:	test   %rax,%rax
  81e11e:	je     81e14d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e120:	lock decq (%rax)
  81e124:	jne    81e14d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e126:	mov    %rdi,%r14
  81e129:	mov    %rbx,%rdi
  81e12c:	mov    %rsi,%r12
  81e12f:	mov    %r8,%r13
  81e132:	mov    %rdx,%r15
  81e135:	mov    %rcx,%rbp
  81e138:	call   *0x661b42(%rip)        # e7fc80 <_DYNAMIC+0x518>
  81e13e:	mov    %rbp,%rcx
  81e141:	mov    %r15,%rdx
  81e144:	mov    %r13,%r8
  81e147:	mov    %r12,%rsi
  81e14a:	mov    %r14,%rdi
  81e14d:	movq   $0x0,0x330(%rsi)
  81e158:	mov    (%rcx),%ebp
  81e15a:	mov    0x8(%rcx),%r9d
  81e15e:	movzbl 0xd(%rcx),%eax
  81e162:	test   %r9d,%r9d
  81e165:	sets   %r10b
  81e169:	and    $0x7fffffff,%r9d
  81e170:	lea    -0x800000(%r9),%r11d
  81e177:	cmp    $0x7f000000,%r11d
  81e17e:	setb   %r11b
  81e182:	and    %r10b,%r11b
  81e185:	lea    -0x1(%r9),%r14d
  81e189:	cmp    $0x7fffff,%r14d
  81e190:	setb   %r14b
  81e194:	and    %r10b,%r14b
  81e197:	test   %r9d,%r9d
  81e19a:	sete   %r10b
  81e19e:	cmp    $0x7f800000,%r9d
  81e1a5:	sete   %r15b
  81e1a9:	or     %r10b,%r15b
  81e1ac:	cmp    $0x7f800001,%r9d
  81e1b3:	setge  %r9b
  81e1b7:	or     %r15b,%r9b
  81e1ba:	or     %r14b,%r9b
  81e1bd:	test   %ebp,%ebp
  81e1bf:	setne  %r10b
  81e1c3:	and    %al,%r10b
  81e1c6:	or     %r11b,%r10b
  81e1c9:	or     %r9b,%r10b
  81e1cc:	test   $0x1,%r10b
  81e1d0:	je     81e1f5 <<gpui_gpu::renderer::RendererState>::render+0x125>
  81e1d2:	movl   $0x3,(%rdi)
  81e1d8:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81e1da:	movl   $0x4,(%rdi)
  81e1e0:	mov    %rdi,%rax
  81e1e3:	add    $0x558,%rsp
  81e1ea:	pop    %rbx
  81e1eb:	pop    %r12
  81e1ed:	pop    %r13
  81e1ef:	pop    %r14
  81e1f1:	pop    %r15
  81e1f3:	pop    %rbp
  81e1f4:	ret
  81e1f5:	movd   0x4(%rcx),%xmm2
  81e1fa:	movzbl 0xc(%rcx),%r12d
  81e1ff:	test   $0x1,%bpl
  81e203:	je     81e27b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e205:	movd   %xmm2,%r9d
  81e20a:	test   %r9d,%r9d
  81e20d:	sets   %r10b
  81e211:	and    $0x7fffffff,%r9d
  81e218:	lea    -0x800000(%r9),%r11d
  81e21f:	cmp    $0x7f000000,%r11d
  81e226:	setb   %r11b
  81e22a:	and    %r10b,%r11b
  81e22d:	lea    -0x1(%r9),%r14d
  81e231:	cmp    $0x7fffff,%r14d
  81e238:	setb   %r14b
  81e23c:	and    %r10b,%r14b
  81e23f:	test   %r9d,%r9d
  81e242:	sete   %r10b
  81e246:	cmp    $0x7f800000,%r9d
  81e24d:	sete   %r15b
  81e251:	or     %r10b,%r15b
  81e254:	cmp    $0x7f800001,%r9d
  81e25b:	setge  %r9b
  81e25f:	or     %r15b,%r9b
  81e262:	or     %r14b,%r9b
  81e265:	or     %r11b,%r9b
  81e268:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e26e:	ucomiss -0x76f3c9(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e275:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e27b:	mov    0x28(%rcx),%r14d
  81e27f:	cmp    %r14d,0x20(%r8)
  81e283:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e289:	mov    0x2c(%rcx),%r15d
  81e28d:	cmp    %r15d,0x24(%r8)
  81e291:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e297:	mov    0x38(%r8),%r13d
  81e29b:	cmp    0x20(%rdx),%r13d
  81e29f:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e2a5:	cmp    $0x4c,%r13d
  81e2a9:	jne    81e2ce <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e2ab:	movq   0x3c(%r8),%xmm0
  81e2b1:	movq   0x24(%rdx),%xmm1
  81e2b6:	pcmpeqd %xmm0,%xmm1
  81e2ba:	pshufd $0x50,%xmm1,%xmm0
  81e2bf:	movmskpd %xmm0,%r9d
  81e2c4:	cmp    $0x3,%r9d
  81e2c8:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e2ce:	cmp    $0x4000,%r15d
  81e2d5:	ja     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2d7:	cmp    $0x4000,%r14d
  81e2de:	ja     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2e0:	mov    %r15,%r9
  81e2e3:	imul   %r14,%r9
  81e2e7:	add    $0xfffffffffeffffff,%r9
  81e2ee:	cmp    $0xffffffffff000000,%r9
  81e2f5:	jb     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2f7:	mov    0x10(%rcx),%r11
  81e2fb:	mov    0x80(%r11),%r10
  81e302:	cmp    $0x10000,%r10
  81e309:	jbe    81e316 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e30b:	movl   $0x6,(%rdi)
  81e311:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81e316:	movd   0x18(%rcx),%xmm0
  81e31b:	movd   %xmm0,%r9d
  81e320:	and    $0x7fffffff,%r9d
  81e327:	cmp    $0x7f7fffff,%r9d
  81e32e:	jg     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e334:	pand   -0x770bbc(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e33c:	ucomiss -0x76f23f(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e343:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e349:	movd   0x1c(%rcx),%xmm0
  81e34e:	movd   %xmm0,%r9d
  81e353:	and    $0x7fffffff,%r9d
  81e35a:	cmp    $0x7f7fffff,%r9d
  81e361:	jg     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e367:	pand   -0x770bef(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e36f:	ucomiss -0x76f272(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e376:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e37c:	movd   0x20(%rcx),%xmm0
  81e381:	movd   %xmm0,%r9d
  81e386:	and    $0x7fffffff,%r9d
  81e38d:	cmp    $0x7f7fffff,%r9d
  81e394:	jg     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e39a:	pand   -0x770c22(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3a2:	ucomiss -0x76f2a5(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3a9:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e3af:	movd   0x24(%rcx),%xmm0
  81e3b4:	movd   %xmm0,%r9d
  81e3b9:	and    $0x7fffffff,%r9d
  81e3c0:	cmp    $0x7f7fffff,%r9d
  81e3c7:	jg     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e3cd:	movdqa -0x770c55(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3d5:	pand   %xmm0,%xmm1
  81e3d9:	ucomiss -0x76f2dc(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3e0:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e3e6:	xorps  %xmm1,%xmm1
  81e3e9:	ucomiss %xmm1,%xmm0
  81e3ec:	jb     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e3f2:	movss  -0x76f67a(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3fa:	ucomiss %xmm0,%xmm1
  81e3fd:	jb     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e403:	movzwl 0x30(%rcx),%r9d
  81e408:	mov    %r9w,0x10(%rsp)
  81e40e:	movzwl 0x32(%rcx),%r9d
  81e413:	mov    %r9w,0x18(%rsp)
  81e419:	cmp    $0x28,%r13d
  81e41d:	jne    81e429 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e41f:	test   $0x1,%al
  81e421:	je     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e427:	jmp    81e444 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e429:	test   $0x1,%al
  81e42b:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e431:	ucomiss -0x76f6b8(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e438:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e43e:	jp     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e444:	mov    %r11,0xb8(%rsp)
  81e44c:	mov    %r10,0xb0(%rsp)
  81e454:	movss  %xmm1,0xe4(%rsp)
  81e45d:	movd   %xmm2,0x244(%rsp)
  81e466:	mov    %rdx,0xe8(%rsp)
  81e46e:	mov    %r8,0x3f0(%rsp)
  81e476:	mov    %rdi,0x50(%rsp)
  81e47b:	lea    0xf(%r14),%rax
  81e47f:	shr    $0x4,%rax
  81e483:	lea    0xf(%r15),%edx
  81e487:	shr    $0x4,%edx
  81e48a:	lea    0x18(%rsi),%rdi
  81e48e:	movq   $0x0,0x28(%rsi)
  81e496:	mov    %rax,0x38(%rsp)
  81e49b:	imul   %eax,%edx
  81e49e:	mov    %rdi,0x98(%rsp)
  81e4a6:	mov    %rsi,0x8(%rsp)
  81e4ab:	mov    %rdx,0x58(%rsp)
  81e4b0:	mov    %rdx,%rsi
  81e4b3:	xor    %edx,%edx
  81e4b5:	mov    %rcx,0x90(%rsp)
  81e4bd:	call   8228f0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e4c2:	mov    0x8(%rsp),%rax
  81e4c7:	movq   $0x0,0x10(%rax)
  81e4cf:	mov    0x90(%rsp),%rdi
  81e4d7:	call   *0x661833(%rip)        # e7fd10 <_DYNAMIC+0x5a8>
  81e4dd:	mov    %rdx,%rcx
  81e4e0:	sub    %rax,%rcx
  81e4e3:	cmp    $0x300000,%rcx
  81e4ea:	jbe    81e4fc <<gpui_gpu::renderer::RendererState>::render+0x42c>
  81e4ec:	mov    0x50(%rsp),%rdi
  81e4f1:	movl   $0x6,(%rdi)
  81e4f7:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81e4fc:	mov    %rcx,%rsi
  81e4ff:	shr    $0x3,%rcx
  81e503:	movabs $0xaaaaaaaaaaaaaaab,%rdi
  81e50d:	imul   %rcx,%rdi
  81e511:	mov    %rdi,0x30(%rsp)
  81e516:	mov    %rax,0x3a8(%rsp)
  81e51e:	mov    %rdx,0x3a0(%rsp)
  81e526:	cmp    %rax,%rdx
  81e529:	je     81e55a <<gpui_gpu::renderer::RendererState>::render+0x48a>
  81e52b:	mov    $0xaaaaaaab,%eax
  81e530:	imul   %rax,%rsi
  81e534:	shr    $0x2a,%rsi
  81e538:	mov    0x30(%rsp),%rcx
  81e53d:	mov    %ecx,%eax
  81e53f:	and    $0x3f,%eax
  81e542:	add    %rcx,%rsi
  81e545:	cmp    $0x1,%rax
  81e549:	sbb    $0xffffffffffffffff,%rsi
  81e54d:	inc    %rsi
  81e550:	mov    %rsi,0xd8(%rsp)
  81e558:	jmp    81e566 <<gpui_gpu::renderer::RendererState>::render+0x496>
  81e55a:	movq   $0x0,0xd8(%rsp)
  81e566:	mov    0xb8(%rsp),%rax
  81e56e:	mov    0x98(%rax),%rcx
  81e575:	add    0xb0(%rax),%rcx
  81e57c:	mov    %rax,0x120(%rsp)
  81e584:	movzwl 0x10(%rsp),%eax
  81e589:	mov    %ax,0x140(%rsp)
  81e591:	movzwl 0x18(%rsp),%eax
  81e596:	mov    %ax,0x142(%rsp)
  81e59e:	movq   $0x0,0x128(%rsp)
  81e5aa:	mov    0xb0(%rsp),%rax
  81e5b2:	mov    %rax,0x130(%rsp)
  81e5ba:	mov    %rcx,0x238(%rsp)
  81e5c2:	mov    %rcx,0x138(%rsp)
  81e5ca:	mov    0x8(%rsp),%rax
  81e5cf:	movzbl 0x341(%rax),%edx
  81e5d6:	lea    0x438(%rsp),%rdi
  81e5de:	lea    0x120(%rsp),%rsi
  81e5e6:	call   81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e5eb:	mov    0x438(%rsp),%eax
  81e5f2:	cmp    $0xffffffff,%eax
  81e5f5:	je     81e625 <<gpui_gpu::renderer::RendererState>::render+0x555>
  81e5f7:	mov    0x43c(%rsp),%ecx
  81e5fe:	mov    0x440(%rsp),%rdx
  81e606:	movups 0x448(%rsp),%xmm0
  81e60e:	mov    0x50(%rsp),%rdi
  81e613:	movups %xmm0,0x10(%rdi)
  81e617:	mov    %eax,(%rdi)
  81e619:	mov    %ecx,0x4(%rdi)
  81e61c:	mov    %rdx,0x8(%rdi)
  81e620:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81e625:	mov    0x440(%rsp),%rdx
  81e62d:	add    0xd8(%rsp),%rdx
  81e635:	mov    0x8(%rsp),%rdi
  81e63a:	mov    0x10(%rdi),%rsi
  81e63e:	mov    $0x4,%ecx
  81e643:	mov    $0x10,%r8d
  81e649:	call   823cb0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e64e:	cmp    $0xffffffffffffffff,%rax
  81e652:	jne    81e4ec <<gpui_gpu::renderer::RendererState>::render+0x41c>
  81e658:	movzwl 0x10(%rsp),%eax
  81e65d:	mov    %eax,0x10(%rsp)
  81e661:	movzwl 0x18(%rsp),%eax
  81e666:	mov    %eax,0x88(%rsp)
  81e66d:	mov    0x8(%rsp),%rdi
  81e672:	mov    0x90(%rsp),%rsi
  81e67a:	mov    0x30(%rsp),%rdx
  81e67f:	call   825c10 <gpui_gpu::renderer::slots::write_prefix>
  81e684:	mov    0x8(%rsp),%rax
  81e689:	lea    0x48(%rax),%rdi
  81e68d:	movq   $0x0,0x58(%rax)
  81e695:	mov    %rdi,0x3f8(%rsp)
  81e69d:	mov    0x58(%rsp),%rsi
  81e6a2:	xor    %edx,%edx
  81e6a4:	call   822a10 <<alloc::vec::Vec<u32>>::resize>
  81e6a9:	mov    0x8(%rsp),%rax
  81e6ae:	movq   $0x0,0x70(%rax)
  81e6b6:	cmpq   $0x0,0x60(%rax)
  81e6bb:	jne    81e6cc <<gpui_gpu::renderer::RendererState>::render+0x5fc>
  81e6bd:	mov    0x8(%rsp),%rax
  81e6c2:	lea    0x60(%rax),%rdi
  81e6c6:	call   *0x66164c(%rip)        # e7fd18 <_DYNAMIC+0x5b0>
  81e6cc:	mov    0x8(%rsp),%rax
  81e6d1:	mov    0x68(%rax),%rcx
  81e6d5:	xorps  %xmm0,%xmm0
  81e6d8:	movups %xmm0,0x10(%rcx)
  81e6dc:	movups %xmm0,(%rcx)
  81e6df:	movq   $0x1,0x70(%rax)
  81e6e7:	lea    0x2f8(%rax),%rdi
  81e6ee:	call   8255c0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e6f3:	mov    0x88(%rsp),%ecx
  81e6fa:	shl    $0x10,%ecx
  81e6fd:	add    0x10(%rsp),%ecx
  81e701:	mov    0xb8(%rsp),%rax
  81e709:	mov    %rax,0x2d8(%rsp)
  81e711:	movq   $0x0,0x2e0(%rsp)
  81e71d:	mov    0xb0(%rsp),%rax
  81e725:	mov    %rax,0x2e8(%rsp)
  81e72d:	mov    0x238(%rsp),%rax
  81e735:	mov    %rax,0x2f0(%rsp)
  81e73d:	mov    %ecx,0x88(%rsp)
  81e744:	mov    %ecx,0x2f8(%rsp)
  81e74b:	lea    0x248(%rsp),%rdi
  81e753:	lea    0x2d8(%rsp),%rsi
  81e75b:	call   *0x6615bf(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81e761:	mov    0x248(%rsp),%rax
  81e769:	mov    %rax,0x18(%rsp)
  81e76e:	test   %rax,%rax
  81e771:	je     81f493 <<gpui_gpu::renderer::RendererState>::render+0x13c3>
  81e777:	movq   $0x0,0xd0(%rsp)
  81e783:	movq   $0x0,0x10(%rsp)
  81e78c:	movq   $0x0,0x58(%rsp)
  81e795:	movq   $0x0,0x228(%rsp)
  81e7a1:	movq   $0x0,0x230(%rsp)
  81e7ad:	mov    0x250(%rsp),%rcx
  81e7b5:	mov    0x258(%rsp),%rdx
  81e7bd:	mov    %rdx,0xa0(%rsp)
  81e7c5:	lea    0x260(%rsp),%rdi
  81e7cd:	movups (%rdi),%xmm0
  81e7d0:	movups 0x10(%rdi),%xmm1
  81e7d4:	movups 0x20(%rdi),%xmm2
  81e7d8:	movaps %xmm2,0x320(%rsp)
  81e7e0:	movaps %xmm1,0x310(%rsp)
  81e7e8:	movaps %xmm0,0x300(%rsp)
  81e7f0:	lea    0x290(%rsp),%r8
  81e7f8:	movups (%r8),%xmm0
  81e7fc:	movaps %xmm0,0x500(%rsp)
  81e804:	movups 0x40(%rdi),%xmm0
  81e808:	movaps %xmm0,0x420(%rsp)
  81e810:	mov    0x8(%rsp),%rax
  81e815:	movzbl 0x341(%rax),%esi
  81e81c:	mov    0x18(%rsp),%rax
  81e821:	mov    %rax,0x120(%rsp)
  81e829:	mov    %rcx,0x20(%rsp)
  81e82e:	mov    %rcx,0x128(%rsp)
  81e836:	mov    %rdx,0x130(%rsp)
  81e83e:	movups (%rdi),%xmm0
  81e841:	movups 0x10(%rdi),%xmm1
  81e845:	movups 0x20(%rdi),%xmm2
  81e849:	lea    0x138(%rsp),%rax
  81e851:	movups %xmm2,0x20(%rax)
  81e855:	movups %xmm1,0x10(%rax)
  81e859:	movups %xmm0,(%rax)
  81e85c:	movups (%r8),%xmm0
  81e860:	movups %xmm0,0x30(%rax)
  81e864:	movups 0x40(%rdi),%xmm0
  81e868:	movups %xmm0,0x40(%rax)
  81e86c:	lea    0x120(%rsp),%rdi
  81e874:	call   821650 <gpui_gpu::renderer::compact_group>
  81e879:	mov    %al,0x40(%rsp)
  81e87d:	lea    0x260(%rsp),%rsi
  81e885:	movups (%rsi),%xmm0
  81e888:	movups 0x10(%rsi),%xmm1
  81e88c:	movups 0x20(%rsi),%xmm2
  81e890:	movaps %xmm0,0x510(%rsp)
  81e898:	movaps %xmm1,0x520(%rsp)
  81e8a0:	movaps %xmm2,0x530(%rsp)
  81e8a8:	lea    0x290(%rsp),%rdx
  81e8b0:	movups (%rdx),%xmm0
  81e8b3:	movaps %xmm0,0x540(%rsp)
  81e8bb:	mov    0x8(%rsp),%rdi
  81e8c0:	call   81d450 <<gpui_gpu::renderer::RendererState>::correction>
  81e8c5:	mov    %eax,0x8c(%rsp)
  81e8cc:	mov    0xa0(%rsp),%rax
  81e8d4:	lea    0x0(,%rax,4),%rax
  81e8dc:	mov    %rax,0x3d0(%rsp)
  81e8e4:	cmpb   $0x0,0x40(%rsp)
  81e8e9:	je     81eabe <<gpui_gpu::renderer::RendererState>::render+0x9ee>
  81e8ef:	mov    0x20(%rsp),%rcx
  81e8f4:	mov    0xa0(%rsp),%rax
  81e8fc:	lea    (%rcx,%rax,4),%rax
  81e900:	mov    %rcx,0x400(%rsp)
  81e908:	mov    %rax,0x408(%rsp)
  81e910:	mov    0x18(%rsp),%rax
  81e915:	mov    %rax,0x410(%rsp)
  81e91d:	movq   $0x0,0x418(%rsp)
  81e929:	lea    0x330(%rsp),%rdi
  81e931:	lea    0x400(%rsp),%rsi
  81e939:	call   821ce0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e93e:	cmpb   $0xff,0x338(%rsp)
  81e946:	je     81eff1 <<gpui_gpu::renderer::RendererState>::render+0xf21>
  81e94c:	xorps  %xmm0,%xmm0
  81e94f:	movaps %xmm0,0xc0(%rsp)
  81e957:	movaps %xmm0,0x60(%rsp)
  81e95c:	mov    0x330(%rsp),%rdx
  81e964:	add    0x58(%rsp),%rdx
  81e969:	lea    0x338(%rsp),%rsi
  81e971:	movups 0x38(%rsi),%xmm0
  81e975:	lea    0x138(%rsp),%rcx
  81e97d:	movups %xmm0,0x20(%rcx)
  81e981:	movups 0x48(%rsi),%xmm0
  81e985:	movups %xmm0,0x70(%rcx)
  81e989:	mov    0x30(%rsi),%rax
  81e98d:	mov    %rax,0x150(%rsp)
  81e995:	movups (%rsi),%xmm0
  81e998:	movups 0x10(%rsi),%xmm1
  81e99c:	movups 0x20(%rsi),%xmm2
  81e9a0:	movaps %xmm2,0x140(%rsp)
  81e9a8:	movaps %xmm1,0x130(%rsp)
  81e9b0:	movaps %xmm0,0x120(%rsp)
  81e9b8:	lea    0x260(%rsp),%rax
  81e9c0:	movups 0x40(%rax),%xmm0
  81e9c4:	movups %xmm0,0x80(%rcx)
  81e9cb:	movups (%rax),%xmm0
  81e9ce:	movups 0x10(%rax),%xmm1
  81e9d2:	movups 0x20(%rax),%xmm2
  81e9d6:	movups %xmm2,0x50(%rcx)
  81e9da:	movups %xmm1,0x40(%rcx)
  81e9de:	movups %xmm0,0x30(%rcx)
  81e9e2:	lea    0x290(%rsp),%rax
  81e9ea:	movups (%rax),%xmm0
  81e9ed:	movups %xmm0,0x60(%rcx)
  81e9f1:	lea    0x100(%rsp),%rdi
  81e9f9:	lea    0x120(%rsp),%rsi
  81ea01:	mov    %r14d,%ecx
  81ea04:	mov    %r15d,%r8d
  81ea07:	call   8216a0 <gpui_gpu::renderer::validate_draw>
  81ea0c:	mov    0x100(%rsp),%ecx
  81ea13:	mov    0x104(%rsp),%rax
  81ea1b:	cmp    $0xffffffff,%ecx
  81ea1e:	jne    81f54b <<gpui_gpu::renderer::RendererState>::render+0x147b>
  81ea24:	mov    %eax,%ecx
  81ea26:	shr    $0x20,%rax
  81ea2a:	movd   %ecx,%xmm0
  81ea2e:	movaps 0xc0(%rsp),%xmm2
  81ea36:	movaps %xmm2,%xmm1
  81ea39:	maxss  %xmm0,%xmm1
  81ea3d:	movaps %xmm1,%xmm3
  81ea40:	cmpunordss %xmm1,%xmm3
  81ea45:	movaps %xmm3,%xmm0
  81ea48:	andnps %xmm1,%xmm0
  81ea4b:	andps  %xmm2,%xmm3
  81ea4e:	orps   %xmm0,%xmm3
  81ea51:	movaps %xmm3,0x40(%rsp)
  81ea56:	movd   %eax,%xmm0
  81ea5a:	movaps 0x60(%rsp),%xmm2
  81ea5f:	movaps %xmm2,%xmm1
  81ea62:	maxss  %xmm0,%xmm1
  81ea66:	movaps %xmm1,%xmm3
  81ea69:	cmpunordss %xmm1,%xmm3
  81ea6e:	movaps %xmm3,%xmm0
  81ea71:	andnps %xmm1,%xmm0
  81ea74:	andps  %xmm2,%xmm3
  81ea77:	orps   %xmm0,%xmm3
  81ea7a:	movaps %xmm3,0x70(%rsp)
  81ea7f:	lea    0x330(%rsp),%rdi
  81ea87:	lea    0x400(%rsp),%rsi
  81ea8f:	call   821ce0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea94:	cmpb   $0xff,0x338(%rsp)
  81ea9c:	movaps 0x40(%rsp),%xmm0
  81eaa1:	movaps %xmm0,0xc0(%rsp)
  81eaa9:	movaps 0x70(%rsp),%xmm0
  81eaae:	movaps %xmm0,0x60(%rsp)
  81eab3:	jne    81e95c <<gpui_gpu::renderer::RendererState>::render+0x88c>
  81eab9:	jmp    81effe <<gpui_gpu::renderer::RendererState>::render+0xf2e>
  81eabe:	cmpq   $0x0,0xa0(%rsp)
  81eac7:	je     81f43d <<gpui_gpu::renderer::RendererState>::render+0x136d>
  81eacd:	mov    0x8c(%rsp),%eax
  81ead4:	or     $0x80000000,%eax
  81ead9:	mov    %eax,0x240(%rsp)
  81eae0:	movq   $0x0,0x70(%rsp)
  81eae9:	mov    0x20(%rsp),%rax
  81eaee:	mov    0x70(%rsp),%rcx
  81eaf3:	mov    (%rax,%rcx,1),%edx
  81eaf6:	lea    0x120(%rsp),%rdi
  81eafe:	mov    0x18(%rsp),%rsi
  81eb03:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81eb08:	movzbl 0x120(%rsp),%edi
  81eb10:	lea    0x121(%rsp),%rdx
  81eb18:	mov    (%rdx),%eax
  81eb1a:	mov    0x3(%rdx),%ecx
  81eb1d:	lea    0x470(%rsp),%rsi
  81eb25:	mov    %ecx,-0x34(%rsi)
  81eb28:	mov    %eax,-0x37(%rsi)
  81eb2b:	mov    0x128(%rsp),%rcx
  81eb33:	mov    0x2f(%rdx),%rax
  81eb37:	mov    %rax,-0x8(%rsi)
  81eb3b:	movups 0xf(%rdx),%xmm0
  81eb3f:	movups 0x1f(%rdx),%xmm1
  81eb43:	movups %xmm1,-0x18(%rsi)
  81eb47:	movups %xmm0,-0x28(%rsi)
  81eb4b:	lea    0x138(%rsp),%rax
  81eb53:	movups 0x20(%rax),%xmm0
  81eb57:	movups %xmm0,(%rsi)
  81eb5a:	movups 0x30(%rax),%xmm0
  81eb5e:	movups %xmm0,0x50(%rsi)
  81eb62:	lea    0x260(%rsp),%rax
  81eb6a:	movups 0x40(%rax),%xmm0
  81eb6e:	movups %xmm0,0x60(%rsi)
  81eb72:	movups (%rax),%xmm0
  81eb75:	movups 0x10(%rax),%xmm1
  81eb79:	movups 0x20(%rax),%xmm2
  81eb7d:	movups %xmm2,0x30(%rsi)
  81eb81:	movups %xmm1,0x20(%rsi)
  81eb85:	movups %xmm0,0x10(%rsi)
  81eb89:	lea    0x290(%rsp),%rax
  81eb91:	movups (%rax),%xmm0
  81eb94:	movups %xmm0,0x40(%rsi)
  81eb98:	mov    %dil,0x60(%rsp)
  81eb9d:	mov    %dil,0x438(%rsp)
  81eba5:	mov    %rcx,0xc0(%rsp)
  81ebad:	mov    %rcx,0x440(%rsp)
  81ebb5:	lea    0x120(%rsp),%rdi
  81ebbd:	lea    0x438(%rsp),%rsi
  81ebc5:	mov    0x58(%rsp),%rdx
  81ebca:	mov    %r14d,%ecx
  81ebcd:	mov    %r15d,%r8d
  81ebd0:	call   8216a0 <gpui_gpu::renderer::validate_draw>
  81ebd5:	mov    0x120(%rsp),%eax
  81ebdc:	mov    0x124(%rsp),%rcx
  81ebe4:	mov    %rcx,0x40(%rsp)
  81ebe9:	cmp    $0xffffffff,%eax
  81ebec:	jne    81f5e1 <<gpui_gpu::renderer::RendererState>::render+0x1511>
  81ebf2:	movzbl 0x60(%rsp),%eax
  81ebf7:	cmp    $0x2,%al
  81ebf9:	sete   0x2f(%rsp)
  81ebfe:	cmpq   $0x0,0xc0(%rsp)
  81ec07:	setne  0x2e(%rsp)
  81ec0c:	movups 0x470(%rsp),%xmm0
  81ec14:	movaps %xmm0,0x2c0(%rsp)
  81ec1c:	cmp    $0x3,%al
  81ec1e:	jne    81ecb0 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  81ec24:	movss  0x43c(%rsp),%xmm0
  81ec2d:	xorps  %xmm1,%xmm1
  81ec30:	ucomiss %xmm1,%xmm0
  81ec33:	jne    81ec37 <<gpui_gpu::renderer::RendererState>::render+0xb67>
  81ec35:	jnp    81ecb0 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  81ec37:	movaps 0x2c0(%rsp),%xmm5
  81ec3f:	movaps %xmm5,%xmm1
  81ec42:	unpckhpd %xmm5,%xmm1
  81ec46:	movss  -0x76fce2(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ec4e:	mulss  %xmm4,%xmm1
  81ec52:	movaps %xmm0,%xmm2
  81ec55:	minss  %xmm1,%xmm2
  81ec59:	movaps %xmm2,%xmm1
  81ec5c:	cmpunordss %xmm2,%xmm1
  81ec61:	movaps %xmm1,%xmm3
  81ec64:	andnps %xmm2,%xmm3
  81ec67:	andps  %xmm0,%xmm1
  81ec6a:	orps   %xmm3,%xmm1
  81ec6d:	movaps %xmm5,%xmm0
  81ec70:	shufps $0xff,%xmm5,%xmm0
  81ec74:	mulss  %xmm4,%xmm0
  81ec78:	movaps %xmm1,%xmm2
  81ec7b:	minss  %xmm0,%xmm2
  81ec7f:	movaps %xmm2,%xmm0
  81ec82:	cmpunordss %xmm2,%xmm0
  81ec87:	andps  %xmm0,%xmm1
  81ec8a:	andnps %xmm2,%xmm0
  81ec8d:	orps   %xmm1,%xmm0
  81ec90:	movd   %xmm0,%eax
  81ec94:	mov    %eax,0x60(%rsp)
  81ec98:	and    $0xff800000,%eax
  81ec9d:	mov    $0x7f000000,%ecx
  81eca2:	sub    %eax,%ecx
  81eca4:	mov    %ecx,0xc0(%rsp)
  81ecab:	xorps  %xmm0,%xmm0
  81ecae:	jmp    81ecd2 <<gpui_gpu::renderer::RendererState>::render+0xc02>
  81ecb0:	mov    0x4d0(%rsp),%eax
  81ecb7:	mov    %eax,0x60(%rsp)
  81ecbb:	mov    0x4d4(%rsp),%eax
  81ecc2:	mov    %eax,0xc0(%rsp)
  81ecc9:	movsd  0x4d8(%rsp),%xmm0
  81ecd2:	movaps %xmm0,0x210(%rsp)
  81ecda:	mov    0x8(%rsp),%rax
  81ecdf:	mov    0x10(%rax),%ecx
  81ece2:	mov    $0x80000000,%eax
  81ece7:	or     %eax,%ecx
  81ece9:	mov    %ecx,0x390(%rsp)
  81ecf0:	movups 0x480(%rsp),%xmm0
  81ecf8:	movaps %xmm0,0x3c0(%rsp)
  81ed00:	movups 0x488(%rsp),%xmm0
  81ed08:	movaps %xmm0,0x4f0(%rsp)
  81ed10:	movsd  0x490(%rsp),%xmm0
  81ed19:	movaps %xmm0,0x3b0(%rsp)
  81ed21:	movsd  0x498(%rsp),%xmm0
  81ed2a:	movaps %xmm0,0x4e0(%rsp)
  81ed32:	movsd  0x4a0(%rsp),%xmm0
  81ed3b:	movsd  %xmm0,0x3e8(%rsp)
  81ed44:	movsd  0x4a8(%rsp),%xmm0
  81ed4d:	movsd  %xmm0,0x3e0(%rsp)
  81ed56:	movups 0x4b0(%rsp),%xmm0
  81ed5e:	movaps %xmm0,0x2b0(%rsp)
  81ed66:	mov    0x18(%rsp),%rax
  81ed6b:	mov    %rax,0x120(%rsp)
  81ed73:	mov    0x20(%rsp),%rax
  81ed78:	mov    %rax,0x128(%rsp)
  81ed80:	mov    0xa0(%rsp),%rax
  81ed88:	mov    %rax,0x130(%rsp)
  81ed90:	movaps 0x300(%rsp),%xmm0
  81ed98:	movaps 0x310(%rsp),%xmm1
  81eda0:	movaps 0x320(%rsp),%xmm2
  81eda8:	lea    0x138(%rsp),%rax
  81edb0:	movups %xmm2,0x20(%rax)
  81edb4:	movups %xmm1,0x10(%rax)
  81edb8:	movups %xmm0,(%rax)
  81edbb:	movaps 0x500(%rsp),%xmm0
  81edc3:	movups %xmm0,0x30(%rax)
  81edc7:	movaps 0x420(%rsp),%xmm0
  81edcf:	movups %xmm0,0x40(%rax)
  81edd3:	lea    0x120(%rsp),%rdi
  81eddb:	call   *0x660f47(%rip)        # e7fd28 <_DYNAMIC+0x5c0>
  81ede1:	mov    0x8c(%rsp),%ecx
  81ede8:	mov    %ecx,0xf0(%rsp)
  81edef:	test   %eax,%eax
  81edf1:	je     81ee27 <<gpui_gpu::renderer::RendererState>::render+0xd57>
  81edf3:	mov    0x30(%rsp),%rdi
  81edf8:	mov    %eax,%esi
  81edfa:	call   825bd0 <gpui_gpu::renderer::slots::color_word>
  81edff:	mov    %eax,0x60(%rsp)
  81ee03:	xorps  %xmm0,%xmm0
  81ee06:	movaps %xmm0,0x210(%rsp)
  81ee0e:	movl   $0x0,0xc0(%rsp)
  81ee19:	mov    0x240(%rsp),%eax
  81ee20:	mov    %eax,0xf0(%rsp)
  81ee27:	mov    0x40(%rsp),%rax
  81ee2c:	shr    $0x20,%rax
  81ee30:	mov    %rax,0x3d8(%rsp)
  81ee38:	mov    0x8(%rsp),%rax
  81ee3d:	mov    (%rax),%rcx
  81ee40:	mov    0x10(%rax),%rsi
  81ee44:	sub    %rsi,%rcx
  81ee47:	cmp    $0x5,%rcx
  81ee4b:	jbe    81efc9 <<gpui_gpu::renderer::RendererState>::render+0xef9>
  81ee51:	movsd  0x3e0(%rsp),%xmm0
  81ee5a:	cvtsd2ss %xmm0,%xmm0
  81ee5e:	movsd  0x3e8(%rsp),%xmm1
  81ee67:	cvtsd2ss %xmm1,%xmm1
  81ee6b:	movapd 0x4f0(%rsp),%xmm2
  81ee74:	unpcklpd 0x4e0(%rsp),%xmm2
  81ee7d:	cvtpd2ps %xmm2,%xmm2
  81ee81:	movapd 0x3c0(%rsp),%xmm3
  81ee8a:	unpcklpd 0x3b0(%rsp),%xmm3
  81ee93:	cvtpd2ps %xmm3,%xmm3
  81ee97:	mov    0x8(%rsp),%rax
  81ee9c:	mov    0x8(%rax),%rdx
  81eea0:	shl    $0x4,%rsi
  81eea4:	movaps 0x2c0(%rsp),%xmm4
  81eeac:	movups %xmm4,(%rdx,%rsi,1)
  81eeb0:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81eeb6:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81eebc:	mov    0x40(%rsp),%rcx
  81eec1:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81eec5:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81eecb:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81eed1:	mov    0x3d8(%rsp),%rdi
  81eed9:	mov    %edi,0x2c(%rdx,%rsi,1)
  81eedd:	movaps 0x2b0(%rsp),%xmm0
  81eee5:	movups %xmm0,0x30(%rdx,%rsi,1)
  81eeea:	mov    0x60(%rsp),%edi
  81eeee:	mov    %edi,0x40(%rdx,%rsi,1)
  81eef2:	mov    0xc0(%rsp),%edi
  81eef9:	mov    %edi,0x44(%rdx,%rsi,1)
  81eefd:	movaps 0x210(%rsp),%xmm0
  81ef05:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81ef0a:	movq   $0x0,0x50(%rdx,%rsi,1)
  81ef13:	movl   $0x0,0x58(%rdx,%rsi,1)
  81ef1b:	mov    0xf0(%rsp),%edi
  81ef22:	mov    %edi,0x5c(%rdx,%rsi,1)
  81ef26:	addq   $0x6,0x10(%rax)
  81ef2b:	lea    0x120(%rsp),%rdi
  81ef33:	mov    %rax,%rsi
  81ef36:	lea    0x438(%rsp),%rdx
  81ef3e:	mov    0x390(%rsp),%r8d
  81ef46:	mov    0x58(%rsp),%r9
  81ef4b:	push   0xd0(%rsp)
  81ef52:	push   %r15
  81ef54:	push   %r14
  81ef56:	push   0x50(%rsp)
  81ef5a:	call   8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ef5f:	add    $0x20,%rsp
  81ef63:	mov    0x120(%rsp),%eax
  81ef6a:	cmp    $0xffffffff,%eax
  81ef6d:	jne    81f5a9 <<gpui_gpu::renderer::RendererState>::render+0x14d9>
  81ef73:	movzbl 0x2f(%rsp),%ecx
  81ef78:	and    0x2e(%rsp),%cl
  81ef7c:	mov    0x10(%rsp),%rax
  81ef81:	or     %cl,%al
  81ef83:	mov    %rax,0x10(%rsp)
  81ef88:	mov    0x128(%rsp),%rax
  81ef90:	mov    %rax,0xd0(%rsp)
  81ef98:	incq   0x58(%rsp)
  81ef9d:	mov    0x70(%rsp),%rdx
  81efa2:	add    $0x4,%rdx
  81efa6:	mov    0xa0(%rsp),%rax
  81efae:	lea    0x0(,%rax,4),%rax
  81efb6:	mov    %rdx,0x70(%rsp)
  81efbb:	cmp    %rdx,%rax
  81efbe:	jne    81eae9 <<gpui_gpu::renderer::RendererState>::render+0xa19>
  81efc4:	jmp    81f431 <<gpui_gpu::renderer::RendererState>::render+0x1361>
  81efc9:	mov    $0x6,%edx
  81efce:	mov    $0x4,%ecx
  81efd3:	mov    $0x10,%r8d
  81efd9:	mov    0x8(%rsp),%rdi
  81efde:	call   823c20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81efe3:	mov    0x8(%rsp),%rax
  81efe8:	mov    0x10(%rax),%rsi
  81efec:	jmp    81ee51 <<gpui_gpu::renderer::RendererState>::render+0xd81>
  81eff1:	xorps  %xmm0,%xmm0
  81eff4:	movaps %xmm0,0x70(%rsp)
  81eff9:	movaps %xmm0,0x40(%rsp)
  81effe:	mov    0x8(%rsp),%rax
  81f003:	mov    0x10(%rax),%eax
  81f006:	mov    %eax,0x210(%rsp)
  81f00d:	movups 0x260(%rsp),%xmm1
  81f015:	movups 0x268(%rsp),%xmm2
  81f01d:	movsd  0x280(%rsp),%xmm0
  81f026:	movsd  %xmm0,0xf0(%rsp)
  81f02f:	movsd  0x288(%rsp),%xmm0
  81f038:	movsd  %xmm0,0x2c0(%rsp)
  81f041:	movups 0x290(%rsp),%xmm0
  81f049:	movaps %xmm0,0xc0(%rsp)
  81f051:	movhps 0x270(%rsp),%xmm1
  81f059:	movaps %xmm1,0x390(%rsp)
  81f061:	movups 0x2a0(%rsp),%xmm0
  81f069:	movaps %xmm0,0x60(%rsp)
  81f06e:	movhps 0x278(%rsp),%xmm2
  81f076:	movaps %xmm2,0x2b0(%rsp)
  81f07e:	mov    0x18(%rsp),%rax
  81f083:	mov    %rax,0x120(%rsp)
  81f08b:	mov    0x20(%rsp),%rax
  81f090:	mov    %rax,0x128(%rsp)
  81f098:	mov    0xa0(%rsp),%rax
  81f0a0:	mov    %rax,0x130(%rsp)
  81f0a8:	lea    0x260(%rsp),%rax
  81f0b0:	movups (%rax),%xmm0
  81f0b3:	movups 0x10(%rax),%xmm1
  81f0b7:	movups 0x20(%rax),%xmm2
  81f0bb:	lea    0x138(%rsp),%rdx
  81f0c3:	movups %xmm2,0x20(%rdx)
  81f0c7:	movups %xmm1,0x10(%rdx)
  81f0cb:	movups %xmm0,(%rdx)
  81f0ce:	lea    0x290(%rsp),%rcx
  81f0d6:	movups (%rcx),%xmm0
  81f0d9:	movups %xmm0,0x30(%rdx)
  81f0dd:	movdqu 0x40(%rax),%xmm0
  81f0e2:	movdqu %xmm0,0x40(%rdx)
  81f0e7:	lea    0x120(%rsp),%rdi
  81f0ef:	call   *0x660c33(%rip)        # e7fd28 <_DYNAMIC+0x5c0>
  81f0f5:	test   %eax,%eax
  81f0f7:	je     81f11a <<gpui_gpu::renderer::RendererState>::render+0x104a>
  81f0f9:	mov    0x30(%rsp),%rdi
  81f0fe:	mov    %eax,%esi
  81f100:	call   825bd0 <gpui_gpu::renderer::slots::color_word>
  81f105:	orl    $0x80000000,0x8c(%rsp)
  81f110:	movd   %eax,%xmm0
  81f114:	movdqa %xmm0,0x60(%rsp)
  81f11a:	mov    0x8(%rsp),%rax
  81f11f:	mov    (%rax),%rcx
  81f122:	mov    0x10(%rax),%rsi
  81f126:	sub    %rsi,%rcx
  81f129:	cmp    $0x4,%rcx
  81f12d:	jbe    81f46b <<gpui_gpu::renderer::RendererState>::render+0x139b>
  81f133:	cvtpd2ps 0x390(%rsp),%xmm0
  81f13c:	cvtpd2ps 0x2b0(%rsp),%xmm1
  81f145:	movsd  0xf0(%rsp),%xmm2
  81f14e:	cvtsd2ss %xmm2,%xmm2
  81f152:	movsd  0x2c0(%rsp),%xmm3
  81f15b:	cvtsd2ss %xmm3,%xmm3
  81f15f:	mov    0x8(%rsp),%rax
  81f164:	mov    0x8(%rax),%rcx
  81f168:	shl    $0x4,%rsi
  81f16c:	movlpd %xmm0,(%rcx,%rsi,1)
  81f171:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f177:	movaps 0x40(%rsp),%xmm0
  81f17c:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f182:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f188:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f18e:	movaps 0x70(%rsp),%xmm0
  81f193:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f199:	movaps 0xc0(%rsp),%xmm0
  81f1a1:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f1a6:	movaps 0x60(%rsp),%xmm0
  81f1ab:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f1b0:	mov    0x8c(%rsp),%edx
  81f1b7:	mov    %edx,0x40(%rcx,%rsi,1)
  81f1bb:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f1c4:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f1cc:	addq   $0x5,0x10(%rax)
  81f1d1:	incq   0x228(%rsp)
  81f1d9:	mov    0xa0(%rsp),%rax
  81f1e1:	add    %rax,0x230(%rsp)
  81f1e9:	test   %rax,%rax
  81f1ec:	je     81f43d <<gpui_gpu::renderer::RendererState>::render+0x136d>
  81f1f2:	movdqa 0x40(%rsp),%xmm0
  81f1f8:	movd   %xmm0,%ecx
  81f1fc:	movdqa 0x70(%rsp),%xmm0
  81f202:	movd   %xmm0,%eax
  81f206:	shl    $0x20,%rax
  81f20a:	or     %rax,%rcx
  81f20d:	mov    %rcx,0xf0(%rsp)
  81f215:	movq   $0x0,0x40(%rsp)
  81f21e:	mov    0x20(%rsp),%rax
  81f223:	mov    0x40(%rsp),%rcx
  81f228:	mov    (%rax,%rcx,1),%edx
  81f22b:	lea    0x330(%rsp),%rdi
  81f233:	mov    0x18(%rsp),%rsi
  81f238:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f23d:	movzbl 0x330(%rsp),%edi
  81f245:	lea    0x338(%rsp),%rsi
  81f24d:	mov    -0x7(%rsi),%eax
  81f250:	mov    -0x4(%rsi),%ecx
  81f253:	lea    0x121(%rsp),%rdx
  81f25b:	mov    %ecx,0x3(%rdx)
  81f25e:	mov    %eax,(%rdx)
  81f260:	mov    0x338(%rsp),%rcx
  81f268:	mov    0x28(%rsi),%rax
  81f26c:	mov    %rax,0x2f(%rdx)
  81f270:	movups 0x8(%rsi),%xmm0
  81f274:	movups 0x18(%rsi),%xmm1
  81f278:	movups %xmm1,0x1f(%rdx)
  81f27c:	movups %xmm0,0xf(%rdx)
  81f280:	movups 0x368(%rsp),%xmm1
  81f288:	lea    0x378(%rsp),%rax
  81f290:	movups (%rax),%xmm0
  81f293:	lea    0x138(%rsp),%rax
  81f29b:	movups %xmm0,0x70(%rax)
  81f29f:	movaps 0x420(%rsp),%xmm0
  81f2a7:	movups %xmm0,0x80(%rax)
  81f2ae:	movaps %xmm1,0xa0(%rsp)
  81f2b6:	movups %xmm1,0x158(%rsp)
  81f2be:	movaps 0x510(%rsp),%xmm0
  81f2c6:	movaps 0x520(%rsp),%xmm1
  81f2ce:	movapd 0x530(%rsp),%xmm2
  81f2d7:	movupd %xmm2,0x50(%rax)
  81f2dc:	movups %xmm1,0x40(%rax)
  81f2e0:	movups %xmm0,0x30(%rax)
  81f2e4:	movaps 0x540(%rsp),%xmm0
  81f2ec:	movups %xmm0,0x60(%rax)
  81f2f0:	mov    %dil,0x60(%rsp)
  81f2f5:	mov    %dil,0x120(%rsp)
  81f2fd:	mov    %rcx,0xc0(%rsp)
  81f305:	mov    %rcx,0x128(%rsp)
  81f30d:	mov    0x8(%rsp),%rax
  81f312:	mov    (%rax),%rcx
  81f315:	mov    0x10(%rax),%rax
  81f319:	sub    %rax,%rcx
  81f31c:	mov    %rax,0x70(%rsp)
  81f321:	cmp    $0x1,%rcx
  81f325:	jbe    81f404 <<gpui_gpu::renderer::RendererState>::render+0x1334>
  81f32b:	mov    0x8(%rsp),%rsi
  81f330:	mov    0x8(%rsi),%rcx
  81f334:	shl    $0x4,%rax
  81f338:	movaps 0xa0(%rsp),%xmm0
  81f340:	movups %xmm0,(%rcx,%rax,1)
  81f344:	movq   $0x0,0x10(%rcx,%rax,1)
  81f34d:	movl   $0x0,0x18(%rcx,%rax,1)
  81f355:	mov    0x210(%rsp),%edx
  81f35c:	mov    %edx,0x1c(%rcx,%rax,1)
  81f360:	addq   $0x2,0x10(%rsi)
  81f365:	lea    0x330(%rsp),%rdi
  81f36d:	lea    0x120(%rsp),%rdx
  81f375:	mov    0xf0(%rsp),%rcx
  81f37d:	mov    0x70(%rsp),%r8
  81f382:	mov    0x58(%rsp),%r9
  81f387:	push   0xd0(%rsp)
  81f38e:	push   %r15
  81f390:	push   %r14
  81f392:	push   0x50(%rsp)
  81f396:	call   8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f39b:	add    $0x20,%rsp
  81f39f:	mov    0x330(%rsp),%eax
  81f3a6:	cmp    $0xffffffff,%eax
  81f3a9:	jne    81f5c5 <<gpui_gpu::renderer::RendererState>::render+0x14f5>
  81f3af:	cmpb   $0x2,0x60(%rsp)
  81f3b4:	sete   %al
  81f3b7:	cmpq   $0x0,0xc0(%rsp)
  81f3c0:	setne  %cl
  81f3c3:	and    %al,%cl
  81f3c5:	mov    0x10(%rsp),%rax
  81f3ca:	or     %cl,%al
  81f3cc:	mov    %rax,0x10(%rsp)
  81f3d1:	mov    0x338(%rsp),%rax
  81f3d9:	mov    %rax,0xd0(%rsp)
  81f3e1:	incq   0x58(%rsp)
  81f3e6:	mov    0x40(%rsp),%rcx
  81f3eb:	add    $0x4,%rcx
  81f3ef:	mov    %rcx,0x40(%rsp)
  81f3f4:	cmp    %rcx,0x3d0(%rsp)
  81f3fc:	jne    81f21e <<gpui_gpu::renderer::RendererState>::render+0x114e>
  81f402:	jmp    81f431 <<gpui_gpu::renderer::RendererState>::render+0x1361>
  81f404:	mov    $0x2,%edx
  81f409:	mov    $0x4,%ecx
  81f40e:	mov    $0x10,%r8d
  81f414:	mov    0x8(%rsp),%rdi
  81f419:	mov    0x70(%rsp),%rsi
  81f41e:	call   823c20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f423:	mov    0x8(%rsp),%rax
  81f428:	mov    0x10(%rax),%rax
  81f42c:	jmp    81f32b <<gpui_gpu::renderer::RendererState>::render+0x125b>
  81f431:	mov    0x10(%rsp),%rax
  81f436:	and    $0x1,%al
  81f438:	mov    %rax,0x10(%rsp)
  81f43d:	lea    0x248(%rsp),%rdi
  81f445:	lea    0x2d8(%rsp),%rsi
  81f44d:	call   *0x6608cd(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81f453:	mov    0x248(%rsp),%rax
  81f45b:	mov    %rax,0x18(%rsp)
  81f460:	test   %rax,%rax
  81f463:	jne    81e7ad <<gpui_gpu::renderer::RendererState>::render+0x6dd>
  81f469:	jmp    81f4c9 <<gpui_gpu::renderer::RendererState>::render+0x13f9>
  81f46b:	mov    $0x5,%edx
  81f470:	mov    $0x4,%ecx
  81f475:	mov    $0x10,%r8d
  81f47b:	mov    0x8(%rsp),%rdi
  81f480:	call   823c20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f485:	mov    0x8(%rsp),%rax
  81f48a:	mov    0x10(%rax),%rsi
  81f48e:	jmp    81f133 <<gpui_gpu::renderer::RendererState>::render+0x1063>
  81f493:	movq   $0x0,0x230(%rsp)
  81f49f:	movq   $0x0,0x228(%rsp)
  81f4ab:	movq   $0x0,0x58(%rsp)
  81f4b4:	movq   $0x0,0x10(%rsp)
  81f4bd:	movq   $0x0,0xd0(%rsp)
  81f4c9:	mov    0xe8(%rsp),%rsi
  81f4d1:	lea    0x8(%rsi),%rdx
  81f4d5:	mov    0x8(%rsp),%rax
  81f4da:	lea    0x258(%rax),%rcx
  81f4e1:	lea    0x328(%rax),%r8
  81f4e8:	mov    0x10(%rax),%r9
  81f4ec:	sub    $0x8,%rsp
  81f4f0:	lea    0x128(%rsp),%rdi
  81f4f8:	mov    %rdx,0x3c8(%rsp)
  81f500:	mov    %rcx,0x2b8(%rsp)
  81f508:	mov    %r8,0x2c8(%rsp)
  81f510:	push   0x98(%rsp)
  81f517:	call   822b60 <gpui_gpu::renderer::images::prepare>
  81f51c:	add    $0x10,%rsp
  81f520:	cmpl   $0xffffffff,0x120(%rsp)
  81f528:	je     81f571 <<gpui_gpu::renderer::RendererState>::render+0x14a1>
  81f52a:	movups 0x120(%rsp),%xmm0
  81f532:	movups 0x130(%rsp),%xmm1
  81f53a:	mov    0x50(%rsp),%rdi
  81f53f:	movups %xmm1,0x10(%rdi)
  81f543:	movups %xmm0,(%rdi)
  81f546:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81f54b:	mov    0x11c(%rsp),%edx
  81f552:	mov    0x50(%rsp),%rdi
  81f557:	mov    %edx,0x1c(%rdi)
  81f55a:	movups 0x10c(%rsp),%xmm0
  81f562:	movups %xmm0,0xc(%rdi)
  81f566:	mov    %ecx,(%rdi)
  81f568:	mov    %rax,0x4(%rdi)
  81f56c:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81f571:	movzbl 0x10(%rsp),%r8d
  81f577:	and    $0x1,%r8d
  81f57b:	lea    0x120(%rsp),%rdi
  81f583:	mov    0x8(%rsp),%rsi
  81f588:	mov    0xe8(%rsp),%rdx
  81f590:	mov    0xb8(%rsp),%rcx
  81f598:	call   81d830 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f59d:	mov    0x120(%rsp),%eax
  81f5a4:	cmp    $0xffffffff,%eax
  81f5a7:	je     81f60c <<gpui_gpu::renderer::RendererState>::render+0x153c>
  81f5a9:	mov    0x124(%rsp),%ecx
  81f5b0:	mov    0x128(%rsp),%rdx
  81f5b8:	movups 0x130(%rsp),%xmm0
  81f5c0:	jmp    81e60e <<gpui_gpu::renderer::RendererState>::render+0x53e>
  81f5c5:	mov    0x334(%rsp),%ecx
  81f5cc:	mov    0x338(%rsp),%rdx
  81f5d4:	movups 0x340(%rsp),%xmm0
  81f5dc:	jmp    81e60e <<gpui_gpu::renderer::RendererState>::render+0x53e>
  81f5e1:	mov    0x13c(%rsp),%ecx
  81f5e8:	mov    0x50(%rsp),%rdi
  81f5ed:	mov    %ecx,0x1c(%rdi)
  81f5f0:	movups 0x12c(%rsp),%xmm0
  81f5f8:	movups %xmm0,0xc(%rdi)
  81f5fc:	mov    %eax,(%rdi)
  81f5fe:	mov    0x40(%rsp),%rax
  81f603:	mov    %rax,0x4(%rdi)
  81f607:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81f60c:	mov    0x128(%rsp),%rax
  81f614:	mov    %rax,0x3b0(%rsp)
  81f61c:	mov    0xb8(%rsp),%rax
  81f624:	mov    %rax,0x330(%rsp)
  81f62c:	movq   $0x0,0x338(%rsp)
  81f638:	mov    0xb0(%rsp),%rax
  81f640:	mov    %rax,0x340(%rsp)
  81f648:	mov    0x238(%rsp),%rax
  81f650:	mov    %rax,0x348(%rsp)
  81f658:	mov    0x88(%rsp),%eax
  81f65f:	mov    %eax,0x350(%rsp)
  81f666:	lea    0x248(%rsp),%rdi
  81f66e:	lea    0x330(%rsp),%rsi
  81f676:	call   *0x6606a4(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81f67c:	mov    0x248(%rsp),%rax
  81f684:	mov    %rax,0xa0(%rsp)
  81f68c:	test   %rax,%rax
  81f68f:	je     81fa60 <<gpui_gpu::renderer::RendererState>::render+0x1990>
  81f695:	mov    0x8(%rsp),%rax
  81f69a:	add    $0x120,%rax
  81f6a0:	mov    %rax,0x390(%rsp)
  81f6a8:	jmp    81f6e6 <<gpui_gpu::renderer::RendererState>::render+0x1616>
  81f6aa:	lea    0x248(%rsp),%rdi
  81f6b2:	lea    0x330(%rsp),%rsi
  81f6ba:	call   *0x660660(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81f6c0:	mov    0x248(%rsp),%rax
  81f6c8:	mov    0x10(%rsp),%rcx
  81f6cd:	mov    %rcx,0xd8(%rsp)
  81f6d5:	mov    %rax,0xa0(%rsp)
  81f6dd:	test   %rax,%rax
  81f6e0:	je     81fa60 <<gpui_gpu::renderer::RendererState>::render+0x1990>
  81f6e6:	mov    0x250(%rsp),%rdx
  81f6ee:	mov    0x258(%rsp),%rdi
  81f6f6:	mov    %rdi,0x70(%rsp)
  81f6fb:	lea    0x260(%rsp),%rax
  81f703:	movups 0x40(%rax),%xmm0
  81f707:	lea    0x138(%rsp),%rcx
  81f70f:	movups %xmm0,0x40(%rcx)
  81f713:	movups (%rax),%xmm0
  81f716:	movups 0x10(%rax),%xmm1
  81f71a:	movups 0x20(%rax),%xmm2
  81f71e:	movups 0x30(%rax),%xmm3
  81f722:	movups %xmm3,0x30(%rcx)
  81f726:	movups %xmm2,0x20(%rcx)
  81f72a:	movups %xmm1,0x10(%rcx)
  81f72e:	movups %xmm0,(%rcx)
  81f731:	mov    0x8(%rsp),%rax
  81f736:	movzbl 0x341(%rax),%esi
  81f73d:	mov    0xa0(%rsp),%rax
  81f745:	mov    %rax,0x120(%rsp)
  81f74d:	mov    %rdx,0x60(%rsp)
  81f752:	mov    %rdx,0x128(%rsp)
  81f75a:	mov    %rdi,0x130(%rsp)
  81f762:	lea    0x120(%rsp),%rdi
  81f76a:	call   821650 <gpui_gpu::renderer::compact_group>
  81f76f:	mov    0xd8(%rsp),%rcx
  81f777:	lea    0x5(%rcx),%rdx
  81f77b:	test   %al,%al
  81f77d:	cmove  %rcx,%rdx
  81f781:	mov    %rdx,0x10(%rsp)
  81f786:	cmpq   $0x0,0x70(%rsp)
  81f78c:	je     81f6aa <<gpui_gpu::renderer::RendererState>::render+0x15da>
  81f792:	shlq   $0x2,0x70(%rsp)
  81f798:	xor    $0x1,%al
  81f79a:	movzbl %al,%ecx
  81f79d:	shl    $0x2,%ecx
  81f7a0:	lea    0x1(%rcx),%rax
  81f7a4:	mov    %rax,0xc0(%rsp)
  81f7ac:	mov    0x10(%rsp),%rax
  81f7b1:	lea    (%rax,%rcx,1),%r8
  81f7b5:	inc    %r8
  81f7b8:	or     $0x2,%rcx
  81f7bc:	shl    $0x4,%r8
  81f7c0:	mov    %rcx,0xd8(%rsp)
  81f7c8:	shl    $0x4,%ecx
  81f7cb:	mov    %rcx,0x210(%rsp)
  81f7d3:	xor    %ecx,%ecx
  81f7d5:	mov    %r8,0x18(%rsp)
  81f7da:	mov    0x60(%rsp),%rax
  81f7df:	mov    %rcx,0x30(%rsp)
  81f7e4:	mov    (%rax,%rcx,1),%edx
  81f7e7:	lea    0x120(%rsp),%rdi
  81f7ef:	mov    0xa0(%rsp),%rsi
  81f7f7:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f7fc:	movzbl 0x120(%rsp),%ecx
  81f804:	movzbl 0x121(%rsp),%eax
  81f80c:	movss  0x124(%rsp),%xmm4
  81f815:	lea    0x128(%rsp),%rsi
  81f81d:	mov    0x10(%rsi),%rdx
  81f821:	mov    %rdx,0x310(%rsp)
  81f829:	movups (%rsi),%xmm0
  81f82c:	movaps %xmm0,0x300(%rsp)
  81f834:	cmp    $0x1,%ecx
  81f837:	je     81f8cc <<gpui_gpu::renderer::RendererState>::render+0x17fc>
  81f83d:	movaps %xmm4,0xf0(%rsp)
  81f845:	mov    0x140(%rsp),%rsi
  81f84d:	mov    0x148(%rsp),%edx
  81f854:	mov    %edx,0x40(%rsp)
  81f858:	mov    0x14c(%rsp),%edx
  81f85f:	mov    %edx,0x20(%rsp)
  81f863:	cmp    $0x3,%ecx
  81f866:	jne    81f951 <<gpui_gpu::renderer::RendererState>::render+0x1881>
  81f86c:	mov    0x2c0(%rsp),%rcx
  81f874:	mov    (%rcx),%rdi
  81f877:	test   %rdi,%rdi
  81f87a:	je     82056e <<gpui_gpu::renderer::RendererState>::render+0x249e>
  81f880:	movzbl %al,%edx
  81f883:	call   8227f0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f888:	mov    %eax,%ecx
  81f88a:	shr    $0x20,%rax
  81f88e:	mov    %eax,%edx
  81f890:	or     $0x10,%edx
  81f893:	xorps  %xmm0,%xmm0
  81f896:	movaps 0xf0(%rsp),%xmm1
  81f89e:	ucomiss %xmm0,%xmm1
  81f8a1:	cmovne %edx,%eax
  81f8a4:	cmovp  %edx,%eax
  81f8a7:	mov    0x20(%rsp),%edx
  81f8ab:	shl    $0x10,%edx
  81f8ae:	or     0x40(%rsp),%edx
  81f8b2:	mov    %ecx,0x100(%rsp)
  81f8b9:	mov    %eax,0x104(%rsp)
  81f8c0:	mov    %edx,0x108(%rsp)
  81f8c7:	jmp    81f9ee <<gpui_gpu::renderer::RendererState>::render+0x191e>
  81f8cc:	movss  0x160(%rsp),%xmm0
  81f8d5:	movss  -0x770971(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f8dd:	mulss  %xmm3,%xmm0
  81f8e1:	movaps %xmm4,%xmm1
  81f8e4:	minss  %xmm0,%xmm1
  81f8e8:	movaps %xmm1,%xmm0
  81f8eb:	cmpunordss %xmm1,%xmm0
  81f8f0:	movaps %xmm0,%xmm2
  81f8f3:	andnps %xmm1,%xmm2
  81f8f6:	andps  %xmm4,%xmm0
  81f8f9:	orps   %xmm2,%xmm0
  81f8fc:	movss  0x164(%rsp),%xmm1
  81f905:	mulss  %xmm3,%xmm1
  81f909:	movaps %xmm0,%xmm2
  81f90c:	minss  %xmm1,%xmm2
  81f910:	movaps %xmm2,%xmm1
  81f913:	cmpunordss %xmm2,%xmm1
  81f918:	andps  %xmm1,%xmm0
  81f91b:	andnps %xmm2,%xmm1
  81f91e:	orps   %xmm0,%xmm1
  81f921:	movd   %xmm1,%eax
  81f925:	and    $0xff800000,%eax
  81f92a:	mov    $0x7f000000,%ecx
  81f92f:	sub    %eax,%ecx
  81f931:	movl   $0x40000000,0x100(%rsp)
  81f93c:	movss  %xmm1,0x104(%rsp)
  81f945:	mov    %ecx,0x108(%rsp)
  81f94c:	jmp    81f9ee <<gpui_gpu::renderer::RendererState>::render+0x191e>
  81f951:	cmp    $0x2,%cl
  81f954:	jne    81f9a6 <<gpui_gpu::renderer::RendererState>::render+0x18d6>
  81f956:	mov    0x150(%rsp),%rax
  81f95e:	mov    0x310(%rsp),%rcx
  81f966:	mov    %rcx,0x130(%rsp)
  81f96e:	movaps 0x300(%rsp),%xmm0
  81f976:	movaps %xmm0,0x120(%rsp)
  81f97e:	mov    %rsi,0x138(%rsp)
  81f986:	mov    0x40(%rsp),%ecx
  81f98a:	mov    %ecx,0x140(%rsp)
  81f991:	mov    0x20(%rsp),%ecx
  81f995:	mov    %ecx,0x144(%rsp)
  81f99c:	mov    %rax,0x148(%rsp)
  81f9a4:	jmp    81f9b2 <<gpui_gpu::renderer::RendererState>::render+0x18e2>
  81f9a6:	movq   $0x0,0x120(%rsp)
  81f9b2:	movl   $0x0,0x2e0(%rsp)
  81f9bd:	movq   $0x0,0x2d8(%rsp)
  81f9c9:	lea    0x100(%rsp),%rdi
  81f9d1:	lea    0x120(%rsp),%rsi
  81f9d9:	lea    0x2d8(%rsp),%rdx
  81f9e1:	mov    0x390(%rsp),%rcx
  81f9e9:	call   81b6f0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f9ee:	mov    0x10(%rsp),%rdx
  81f9f3:	mov    0xc0(%rsp),%rax
  81f9fb:	lea    (%rax,%rdx,1),%rdi
  81f9ff:	mov    0x8(%rsp),%rax
  81fa04:	mov    0x10(%rax),%rsi
  81fa08:	cmp    %rsi,%rdi
  81fa0b:	mov    0x18(%rsp),%r8
  81fa10:	jae    82057b <<gpui_gpu::renderer::RendererState>::render+0x24ab>
  81fa16:	mov    0x8(%rax),%rax
  81fa1a:	mov    0x108(%rsp),%ecx
  81fa21:	mov    %ecx,0x8(%rax,%r8,1)
  81fa26:	mov    0x100(%rsp),%rcx
  81fa2e:	mov    %rcx,(%rax,%r8,1)
  81fa32:	add    0xd8(%rsp),%rdx
  81fa3a:	mov    %rdx,0x10(%rsp)
  81fa3f:	add    0x210(%rsp),%r8
  81fa47:	mov    0x30(%rsp),%rcx
  81fa4c:	add    $0x4,%rcx
  81fa50:	cmp    %rcx,0x70(%rsp)
  81fa55:	jne    81f7d5 <<gpui_gpu::renderer::RendererState>::render+0x1705>
  81fa5b:	jmp    81f6aa <<gpui_gpu::renderer::RendererState>::render+0x15da>
  81fa60:	mov    0x8(%rsp),%rax
  81fa65:	mov    0x28(%rax),%rax
  81fa69:	movq   $0x0,0x60(%rsp)
  81fa72:	test   %rax,%rax
  81fa75:	je     81fae2 <<gpui_gpu::renderer::RendererState>::render+0x1a12>
  81fa77:	mov    0x8(%rsp),%rcx
  81fa7c:	mov    0x20(%rcx),%rcx
  81fa80:	shl    $0x3,%rax
  81fa84:	xor    %edi,%edi
  81fa86:	jmp    81faa4 <<gpui_gpu::renderer::RendererState>::render+0x19d4>
  81fa88:	mov    0x60(%rsp),%rdx
  81fa8d:	add    %esi,%edx
  81fa8f:	mov    %edx,(%rcx,%rdi,8)
  81fa92:	mov    %rdx,0x60(%rsp)
  81fa97:	mov    %edx,0x4(%rcx,%rdi,8)
  81fa9b:	inc    %rdi
  81fa9e:	add    $0xfffffffffffffff8,%rax
  81faa2:	je     81fad6 <<gpui_gpu::renderer::RendererState>::render+0x1a06>
  81faa4:	mov    0x8(%rsp),%rdx
  81faa9:	mov    0x58(%rdx),%rsi
  81faad:	cmp    %rsi,%rdi
  81fab0:	jae    820588 <<gpui_gpu::renderer::RendererState>::render+0x24b8>
  81fab6:	mov    0x4(%rcx,%rdi,8),%esi
  81faba:	cmp    $0x1,%esi
  81fabd:	jne    81fa88 <<gpui_gpu::renderer::RendererState>::render+0x19b8>
  81fabf:	mov    0x8(%rsp),%rdx
  81fac4:	mov    0x50(%rdx),%r8
  81fac8:	mov    $0x80000000,%edx
  81facd:	cmpl   $0x0,(%r8,%rdi,4)
  81fad2:	jne    81fa97 <<gpui_gpu::renderer::RendererState>::render+0x19c7>
  81fad4:	jmp    81fa88 <<gpui_gpu::renderer::RendererState>::render+0x19b8>
  81fad6:	mov    0x60(%rsp),%rax
  81fadb:	mov    %eax,%eax
  81fadd:	mov    %rax,0x60(%rsp)
  81fae2:	mov    0x8(%rsp),%rax
  81fae7:	lea    0x30(%rax),%rdi
  81faeb:	movq   $0x0,0x40(%rax)
  81faf3:	mov    %rdi,0xa0(%rsp)
  81fafb:	mov    0x60(%rsp),%rsi
  81fb00:	xor    %edx,%edx
  81fb02:	call   822a10 <<alloc::vec::Vec<u32>>::resize>
  81fb07:	mov    0x8(%rsp),%rax
  81fb0c:	mov    0x10(%rax),%rax
  81fb10:	mov    %rax,0x20(%rsp)
  81fb15:	mov    0x58(%rsp),%rax
  81fb1a:	mov    %rax,0x100(%rsp)
  81fb22:	mov    0xb8(%rsp),%rax
  81fb2a:	mov    %rax,0x2d8(%rsp)
  81fb32:	movq   $0x0,0x2e0(%rsp)
  81fb3e:	mov    0xb0(%rsp),%rax
  81fb46:	mov    %rax,0x2e8(%rsp)
  81fb4e:	mov    0x238(%rsp),%rax
  81fb56:	mov    %rax,0x2f0(%rsp)
  81fb5e:	mov    0x88(%rsp),%eax
  81fb65:	mov    %eax,0x2f8(%rsp)
  81fb6c:	jmp    81fb88 <<gpui_gpu::renderer::RendererState>::render+0x1ab8>
  81fb6e:	mov    0x20(%rsp),%rcx
  81fb73:	lea    -0x5(%rcx),%rax
  81fb77:	cmpb   $0x0,0xb0(%rsp)
  81fb7f:	cmovne %rax,%rcx
  81fb83:	mov    %rcx,0x20(%rsp)
  81fb88:	lea    0x248(%rsp),%rdi
  81fb90:	lea    0x2d8(%rsp),%rsi
  81fb98:	call   *0x660192(%rip)        # e7fd30 <_DYNAMIC+0x5c8>
  81fb9e:	mov    0x248(%rsp),%rax
  81fba6:	mov    %rax,0x40(%rsp)
  81fbab:	test   %rax,%rax
  81fbae:	je     81fe03 <<gpui_gpu::renderer::RendererState>::render+0x1d33>
  81fbb4:	mov    0x250(%rsp),%rcx
  81fbbc:	mov    0x258(%rsp),%rdx
  81fbc4:	mov    %rdx,0x18(%rsp)
  81fbc9:	mov    0x8(%rsp),%rax
  81fbce:	movzbl 0x341(%rax),%esi
  81fbd5:	mov    0x40(%rsp),%rax
  81fbda:	mov    %rax,0x120(%rsp)
  81fbe2:	mov    %rcx,0x70(%rsp)
  81fbe7:	mov    %rcx,0x128(%rsp)
  81fbef:	mov    %rdx,0x130(%rsp)
  81fbf7:	lea    0x260(%rsp),%rax
  81fbff:	movups (%rax),%xmm0
  81fc02:	movups 0x10(%rax),%xmm1
  81fc06:	movdqu 0x20(%rax),%xmm2
  81fc0b:	lea    0x138(%rsp),%rdx
  81fc13:	movdqu %xmm2,0x20(%rdx)
  81fc18:	movups %xmm1,0x10(%rdx)
  81fc1c:	movups %xmm0,(%rdx)
  81fc1f:	lea    0x290(%rsp),%rcx
  81fc27:	movups (%rcx),%xmm0
  81fc2a:	movups %xmm0,0x30(%rdx)
  81fc2e:	movups 0x40(%rax),%xmm0
  81fc32:	movups %xmm0,0x40(%rdx)
  81fc36:	lea    0x120(%rsp),%rdi
  81fc3e:	call   821650 <gpui_gpu::renderer::compact_group>
  81fc43:	mov    %al,0xb0(%rsp)
  81fc4a:	mov    0x18(%rsp),%rax
  81fc4f:	test   %rax,%rax
  81fc52:	je     81fb6e <<gpui_gpu::renderer::RendererState>::render+0x1a9e>
  81fc58:	mov    %rax,%rcx
  81fc5b:	shl    $0x2,%rcx
  81fc5f:	movzbl 0xb0(%rsp),%eax
  81fc67:	lea    0x0(,%rax,4),%edx
  81fc6e:	or     $0xfffffffffffffffa,%rdx
  81fc72:	xor    %esi,%esi
  81fc74:	test   %al,%al
  81fc76:	sete   %sil
  81fc7a:	shl    $0x1f,%esi
  81fc7d:	mov    %esi,0xb8(%rsp)
  81fc84:	mov    %rdx,0x30(%rsp)
  81fc89:	mov    0x20(%rsp),%rax
  81fc8e:	add    %edx,%eax
  81fc90:	mov    %eax,0x10(%rsp)
  81fc94:	mov    %rcx,0x18(%rsp)
  81fc99:	mov    0x70(%rsp),%rax
  81fc9e:	mov    -0x4(%rax,%rcx,1),%edx
  81fca2:	lea    0x330(%rsp),%rdi
  81fcaa:	mov    0x40(%rsp),%rsi
  81fcaf:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fcb4:	decq   0x100(%rsp)
  81fcbc:	mov    0x30(%rsp),%rax
  81fcc1:	add    %rax,0x20(%rsp)
  81fcc6:	mov    0xb8(%rsp),%eax
  81fccd:	or     0x10(%rsp),%eax
  81fcd1:	mov    %eax,0x400(%rsp)
  81fcd8:	lea    0x260(%rsp),%rax
  81fce0:	movups (%rax),%xmm0
  81fce3:	movups 0x10(%rax),%xmm1
  81fce7:	movups 0x20(%rax),%xmm2
  81fceb:	lea    0x138(%rsp),%rdx
  81fcf3:	movups %xmm2,0x50(%rdx)
  81fcf7:	movups %xmm1,0x40(%rdx)
  81fcfb:	movups %xmm0,0x30(%rdx)
  81fcff:	lea    0x290(%rsp),%rcx
  81fd07:	movups (%rcx),%xmm0
  81fd0a:	movups %xmm0,0x60(%rdx)
  81fd0e:	movups 0x40(%rax),%xmm0
  81fd12:	movups %xmm0,0x80(%rdx)
  81fd19:	lea    0x368(%rsp),%rax
  81fd21:	movups (%rax),%xmm0
  81fd24:	movups %xmm0,0x20(%rdx)
  81fd28:	lea    0x378(%rsp),%rax
  81fd30:	movups (%rax),%xmm0
  81fd33:	movups %xmm0,0x70(%rdx)
  81fd37:	mov    0x360(%rsp),%rax
  81fd3f:	mov    %rax,0x150(%rsp)
  81fd47:	movups 0x330(%rsp),%xmm0
  81fd4f:	movups 0x340(%rsp),%xmm1
  81fd57:	movdqu 0x350(%rsp),%xmm2
  81fd60:	movdqa %xmm2,0x140(%rsp)
  81fd69:	movaps %xmm1,0x130(%rsp)
  81fd71:	movaps %xmm0,0x120(%rsp)
  81fd79:	mov    0x98(%rsp),%rax
  81fd81:	mov    %rax,0x300(%rsp)
  81fd89:	mov    0xa0(%rsp),%rax
  81fd91:	mov    %rax,0x308(%rsp)
  81fd99:	mov    0x3f8(%rsp),%rax
  81fda1:	mov    %rax,0x310(%rsp)
  81fda9:	lea    0x100(%rsp),%rax
  81fdb1:	mov    %rax,0x318(%rsp)
  81fdb9:	lea    0x400(%rsp),%rax
  81fdc1:	mov    %rax,0x320(%rsp)
  81fdc9:	lea    0x120(%rsp),%rdi
  81fdd1:	mov    0x38(%rsp),%rsi
  81fdd6:	lea    0x300(%rsp),%rdx
  81fdde:	call   81c5b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81fde3:	mov    0x10(%rsp),%eax
  81fde7:	add    0x30(%rsp),%eax
  81fdeb:	mov    %eax,0x10(%rsp)
  81fdef:	mov    0x18(%rsp),%rcx
  81fdf4:	add    $0xfffffffffffffffc,%rcx
  81fdf8:	jne    81fc94 <<gpui_gpu::renderer::RendererState>::render+0x1bc4>
  81fdfe:	jmp    81fb6e <<gpui_gpu::renderer::RendererState>::render+0x1a9e>
  81fe03:	mov    0x8(%rsp),%rax
  81fe08:	mov    0x28(%rax),%rdi
  81fe0c:	movq   $0x0,0x98(%rsp)
  81fe18:	test   %rdi,%rdi
  81fe1b:	je     81feeb <<gpui_gpu::renderer::RendererState>::render+0x1e1b>
  81fe21:	mov    0x8(%rsp),%rax
  81fe26:	mov    0x20(%rax),%r8
  81fe2a:	shl    $0x3,%rdi
  81fe2e:	cmpl   $0x0,0x38(%rsp)
  81fe33:	je     820528 <<gpui_gpu::renderer::RendererState>::render+0x2458>
  81fe39:	movq   $0x0,0x30(%rsp)
  81fe42:	movq   $0x0,0x18(%rsp)
  81fe4b:	movq   $0x0,0x10(%rsp)
  81fe54:	xor    %r9d,%r9d
  81fe57:	xor    %ecx,%ecx
  81fe59:	jmp    81fe7e <<gpui_gpu::renderer::RendererState>::render+0x1dae>
  81fe5b:	incq   0x10(%rsp)
  81fe60:	inc    %r9
  81fe63:	cmp    0x38(%rsp),%r9
  81fe68:	mov    $0x0,%eax
  81fe6d:	cmove  %rax,%r9
  81fe71:	inc    %rcx
  81fe74:	add    $0xfffffffffffffff8,%rdi
  81fe78:	je     81ff06 <<gpui_gpu::renderer::RendererState>::render+0x1e36>
  81fe7e:	mov    0x4(%r8,%rcx,8),%r10d
  81fe83:	mov    %r10d,%eax
  81fe86:	neg    %eax
  81fe88:	jo     81fe5b <<gpui_gpu::renderer::RendererState>::render+0x1d8b>
  81fe8a:	sub    (%r8,%rcx,8),%r10d
  81fe8e:	je     81fe60 <<gpui_gpu::renderer::RendererState>::render+0x1d90>
  81fe90:	mov    %rcx,%rax
  81fe93:	shr    $0x20,%rax
  81fe97:	je     81fea8 <<gpui_gpu::renderer::RendererState>::render+0x1dd8>
  81fe99:	mov    %rcx,%rax
  81fe9c:	xor    %edx,%edx
  81fe9e:	divq   0x38(%rsp)
  81fea3:	mov    %r9,%rdx
  81fea6:	jmp    81feb0 <<gpui_gpu::renderer::RendererState>::render+0x1de0>
  81fea8:	mov    %ecx,%eax
  81feaa:	xor    %edx,%edx
  81feac:	divl   0x38(%rsp)
  81feb0:	shl    $0x4,%edx
  81feb3:	shl    $0x4,%eax
  81feb6:	lea    0x10(%rdx),%r11d
  81feba:	cmp    %r11d,%r14d
  81febd:	cmovb  %r14d,%r11d
  81fec1:	lea    0x10(%rax),%esi
  81fec4:	cmp    %esi,%r15d
  81fec7:	cmovb  %r15d,%esi
  81fecb:	sub    %edx,%r11d
  81fece:	sub    %eax,%esi
  81fed0:	imul   %r11d,%esi
  81fed4:	shl    $0x4,%rsi
  81fed8:	add    %rsi,0x18(%rsp)
  81fedd:	imul   %rsi,%r10
  81fee1:	add    %r10,0x30(%rsp)
  81fee6:	jmp    81fe60 <<gpui_gpu::renderer::RendererState>::render+0x1d90>
  81feeb:	movq   $0x0,0x10(%rsp)
  81fef4:	movq   $0x0,0x18(%rsp)
  81fefd:	movq   $0x0,0x30(%rsp)
  81ff06:	test   $0x1,%bpl
  81ff0a:	je     81ff5f <<gpui_gpu::renderer::RendererState>::render+0x1e8f>
  81ff0c:	movd   0x244(%rsp),%xmm0
  81ff15:	movd   %xmm0,%eax
  81ff19:	test   %eax,%eax
  81ff1b:	setns  %cl
  81ff1e:	mov    %eax,%edx
  81ff20:	and    $0x7fffffff,%edx
  81ff26:	add    $0xff800000,%edx
  81ff2c:	cmp    $0x7f000000,%edx
  81ff32:	setb   %dl
  81ff35:	and    %cl,%dl
  81ff37:	dec    %eax
  81ff39:	cmp    $0x7fffff,%eax
  81ff3e:	setb   %al
  81ff41:	or     %dl,%al
  81ff43:	mov    $0x2,%eax
  81ff48:	mov    %rax,0x98(%rsp)
  81ff50:	movd   %xmm0,0xe4(%rsp)
  81ff59:	je     82051e <<gpui_gpu::renderer::RendererState>::render+0x244e>
  81ff5f:	mov    0xe8(%rsp),%rbp
  81ff67:	lea    0x18(%rbp),%rax
  81ff6b:	mov    %rax,0x20(%rsp)
  81ff70:	mov    0x90(%rsp),%rax
  81ff78:	add    $0x18,%rax
  81ff7c:	xor    %ecx,%ecx
  81ff7e:	mov    0x3a0(%rsp),%rdx
  81ff86:	cmp    0x3a8(%rsp),%rdx
  81ff8e:	setne  %cl
  81ff91:	xor    %edx,%edx
  81ff93:	cmp    $0x28,%r13d
  81ff97:	sete   %dl
  81ff9a:	and    $0x1,%r12d
  81ff9e:	lea    (%r12,%rdx,4),%edx
  81ffa2:	lea    (%rdx,%rcx,8),%ecx
  81ffa5:	or     0x98(%rsp),%ecx
  81ffac:	movups (%rax),%xmm0
  81ffaf:	movups %xmm0,0x258(%rsp)
  81ffb7:	mov    %r14d,0x248(%rsp)
  81ffbf:	mov    %r15d,0x24c(%rsp)
  81ffc7:	mov    0x38(%rsp),%rax
  81ffcc:	mov    %eax,0x250(%rsp)
  81ffd3:	mov    %ecx,0x254(%rsp)
  81ffda:	movss  0xe4(%rsp),%xmm0
  81ffe3:	movss  %xmm0,0x268(%rsp)
  81ffec:	movq   $0x0,0x26c(%rsp)
  81fff8:	movl   $0x0,0x274(%rsp)
  820003:	mov    0x8(%rsp),%r13
  820008:	lea    0x230(%r13),%rsi
  82000f:	movq   $0x0,0x38(%rsp)
  820018:	lea    0x248(%rsp),%rcx
  820020:	mov    $0x30,%r8d
  820026:	mov    0x3c0(%rsp),%r12
  82002e:	mov    %r12,%rdi
  820031:	mov    %rsi,0x98(%rsp)
  820039:	xor    %edx,%edx
  82003b:	call   *0x65fcf7(%rip)        # e7fd38 <_DYNAMIC+0x5d0>
  820041:	mov    0x8(%r13),%rcx
  820045:	mov    0x10(%r13),%r8
  820049:	shl    $0x4,%r8
  82004d:	mov    0x2b0(%rsp),%rdi
  820055:	mov    %rbp,%rsi
  820058:	mov    %r12,%rdx
  82005b:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  820060:	lea    0x280(%r13),%rdi
  820067:	mov    0x20(%r13),%rcx
  82006b:	mov    0x28(%r13),%r8
  82006f:	shl    $0x3,%r8
  820073:	mov    %rdi,0x90(%rsp)
  82007b:	mov    %rbp,%rsi
  82007e:	mov    %r12,%rdx
  820081:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  820086:	lea    0x2a8(%r13),%rdi
  82008d:	mov    0x38(%r13),%rcx
  820091:	mov    0x40(%r13),%r8
  820095:	shl    $0x2,%r8
  820099:	mov    %rdi,0x40(%rsp)
  82009e:	mov    %rbp,%rsi
  8200a1:	mov    %r12,%rdx
  8200a4:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  8200a9:	lea    0x2d0(%r13),%rdi
  8200b0:	mov    0x68(%r13),%rcx
  8200b4:	mov    0x70(%r13),%r8
  8200b8:	shl    $0x5,%r8
  8200bc:	mov    %rdi,0x70(%rsp)
  8200c1:	mov    %rbp,%rsi
  8200c4:	mov    %r12,%rdx
  8200c7:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  8200cc:	cmpq   $0x0,0x328(%r13)
  8200d4:	jne    8200f0 <<gpui_gpu::renderer::RendererState>::render+0x2020>
  8200d6:	mov    0x8(%rsp),%rax
  8200db:	mov    0x10(%rax),%rax
  8200df:	cmp    $0x1,%rax
  8200e3:	adc    $0x0,%rax
  8200e7:	shl    $0x4,%rax
  8200eb:	mov    %rax,0x38(%rsp)
  8200f0:	mov    0x8(%rsp),%rsi
  8200f5:	mov    0x28(%rsi),%rdx
  8200f9:	mov    0x40(%rsi),%rax
  8200fd:	cmp    $0x1,%rdx
  820101:	adc    $0x0,%rdx
  820105:	shl    $0x3,%rdx
  820109:	cmp    $0x1,%rax
  82010d:	adc    $0x0,%rax
  820111:	mov    0x70(%rsi),%rcx
  820115:	cmp    $0x1,%rcx
  820119:	adc    $0x0,%rcx
  82011d:	add    $0xc8,%rsi
  820124:	shl    $0x2,%rax
  820128:	shl    $0x5,%rcx
  82012c:	movq   $0x0,0x120(%rsp)
  820138:	mov    0x98(%rsp),%rdi
  820140:	mov    %rdi,0x128(%rsp)
  820148:	movq   $0x0,0x148(%rsp)
  820154:	xorps  %xmm0,%xmm0
  820157:	movups %xmm0,0x130(%rsp)
  82015f:	movl   $0x0,0x140(%rsp)
  82016a:	mov    0x2b0(%rsp),%rdi
  820172:	mov    %rdi,0x150(%rsp)
  82017a:	movq   $0x0,0x158(%rsp)
  820186:	mov    0x38(%rsp),%rdi
  82018b:	mov    %rdi,0x160(%rsp)
  820193:	movl   $0x1,0x168(%rsp)
  82019e:	movq   $0x0,0x170(%rsp)
  8201aa:	mov    0x90(%rsp),%rdi
  8201b2:	mov    %rdi,0x178(%rsp)
  8201ba:	movq   $0x0,0x180(%rsp)
  8201c6:	mov    %rdx,0x188(%rsp)
  8201ce:	movl   $0x2,0x190(%rsp)
  8201d9:	movq   $0x0,0x198(%rsp)
  8201e5:	mov    0x40(%rsp),%rdx
  8201ea:	mov    %rdx,0x1a0(%rsp)
  8201f2:	movq   $0x0,0x1a8(%rsp)
  8201fe:	mov    %rax,0x1b0(%rsp)
  820206:	movl   $0x3,0x1b8(%rsp)
  820211:	movq   $0x4,0x1c0(%rsp)
  82021d:	mov    %rsi,0x1c8(%rsp)
  820225:	movl   $0x4,0x1e0(%rsp)
  820230:	movq   $0x0,0x1e8(%rsp)
  82023c:	mov    0x70(%rsp),%rax
  820241:	mov    %rax,0x1f0(%rsp)
  820249:	movq   $0x0,0x1f8(%rsp)
  820255:	mov    %rcx,0x200(%rsp)
  82025d:	movl   $0x5,0x208(%rsp)
  820268:	lea    -0x74b3a7(%rip),%rax        # d4ec8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82026f:	mov    %rax,0x348(%rsp)
  820277:	movq   $0xa,0x350(%rsp)
  820283:	mov    0x20(%rsp),%rax
  820288:	mov    %rax,0x330(%rsp)
  820290:	lea    0x120(%rsp),%rax
  820298:	mov    %rax,0x338(%rsp)
  8202a0:	movq   $0x6,0x340(%rsp)
  8202ac:	lea    0x330(%rsp),%rsi
  8202b4:	mov    0xe8(%rsp),%r12
  8202bc:	mov    %r12,%rdi
  8202bf:	call   *0x65fa7b(%rip)        # e7fd40 <_DYNAMIC+0x5d8>
  8202c5:	mov    %rax,%r13
  8202c8:	mov    %rax,0x300(%rsp)
  8202d0:	lea    0x300(%rsp),%rdx
  8202d8:	mov    %r12,%rdi
  8202db:	mov    0x3f0(%rsp),%rsi
  8202e3:	call   81d270 <<gpui_gpu::renderer::GpuContext>::submit>
  8202e8:	mov    %rax,0x38(%rsp)
  8202ed:	xor    %ebp,%ebp
  8202ef:	mov    0x3a0(%rsp),%rax
  8202f7:	cmp    0x3a8(%rsp),%rax
  8202ff:	setne  %bpl
  820303:	shl    $0x1f,%ebp
  820306:	or     %r14d,%ebp
  820309:	shl    $0x20,%r15
  82030d:	or     %r15,%rbp
  820310:	mov    (%rbx),%rax
  820313:	test   %rax,%rax
  820316:	je     820327 <<gpui_gpu::renderer::RendererState>::render+0x2257>
  820318:	lock decq (%rax)
  82031c:	jne    820327 <<gpui_gpu::renderer::RendererState>::render+0x2257>
  82031e:	mov    %rbx,%rdi
  820321:	call   *0x65f959(%rip)        # e7fc80 <_DYNAMIC+0x518>
  820327:	mov    0x8(%rsp),%rax
  82032c:	mov    %r13,0x330(%rax)
  820333:	mov    %rbp,0x338(%rax)
  82033a:	mov    0x10(%rax),%r8
  82033e:	mov    0x28(%rax),%rsi
  820342:	mov    0x70(%rax),%rcx
  820346:	mov    %rcx,0x98(%rsp)
  82034e:	shl    $0x4,%r8
  820352:	mov    0x60(%rsp),%rdx
  820357:	lea    (%r8,%rdx,4),%rdi
  82035b:	lea    (%rdi,%rsi,8),%rsi
  82035f:	mov    %rcx,%rdi
  820362:	shl    $0x5,%rdi
  820366:	lea    (%rdi,%rsi,1),%rcx
  82036a:	add    $0x30,%rcx
  82036e:	mov    %rcx,0x90(%rsp)
  820376:	mov    0x278(%rax),%rdi
  82037d:	add    0x250(%rax),%rdi
  820384:	add    0x2a0(%rax),%rdi
  82038b:	add    0x2c8(%rax),%rdi
  820392:	add    0x2f0(%rax),%rdi
  820399:	mov    0x308(%rax),%rsi
  8203a0:	add    0x310(%rax),%rsi
  8203a7:	mov    0x150(%rax),%r9d
  8203ae:	imul   %r9,%r9
  8203b2:	mov    0xd0(%rsp),%r11
  8203ba:	mov    %r11,%rcx
  8203bd:	sub    %rdx,%rcx
  8203c0:	mov    0x58(%rsp),%r10
  8203c5:	mov    %r10,%r12
  8203c8:	mov    0x230(%rsp),%rbp
  8203d0:	sub    %rbp,%r12
  8203d3:	mov    0x160(%rax),%rbx
  8203da:	inc    %rbx
  8203dd:	mov    $0xffffffffffffffff,%r14
  8203e4:	cmovne %rbx,%r14
  8203e8:	mov    (%rax),%rbx
  8203eb:	shl    $0x4,%rbx
  8203ef:	mov    0x48(%rax),%r15
  8203f3:	add    0x30(%rax),%r15
  8203f7:	mov    0x18(%rax),%r13
  8203fb:	lea    (%rbx,%r13,8),%rbx
  8203ff:	lea    (%rbx,%r15,4),%rbx
  820403:	mov    0x60(%rax),%r15
  820407:	shl    $0x5,%r15
  82040b:	add    %rbx,%r15
  82040e:	mov    0x138(%rax),%rbx
  820415:	mov    0x130(%rax),%r13
  82041c:	mov    %r14,0x160(%rax)
  820423:	mov    %r10,0x168(%rax)
  82042a:	lea    (%r11,%r11,1),%r14
  82042e:	mov    %r14,0x170(%rax)
  820435:	movq   $0x1,0x178(%rax)
  820440:	mov    %r10,0x180(%rax)
  820447:	mov    %rdx,0x188(%rax)
  82044e:	mov    %r11,0x190(%rax)
  820455:	mov    %rcx,0x198(%rax)
  82045c:	mov    0x10(%rsp),%rcx
  820461:	mov    %rcx,0x1a0(%rax)
  820468:	mov    0x18(%rsp),%rcx
  82046d:	mov    %rcx,0x1a8(%rax)
  820474:	mov    0x30(%rsp),%rcx
  820479:	mov    %rcx,0x1b0(%rax)
  820480:	mov    0x90(%rsp),%rcx
  820488:	mov    %rcx,0x1b8(%rax)
  82048f:	mov    %r8,0x1c0(%rax)
  820496:	mov    0x228(%rsp),%rdx
  82049e:	mov    %rdx,0x1c8(%rax)
  8204a5:	mov    %rbp,0x1d0(%rax)
  8204ac:	mov    %r12,0x1d8(%rax)
  8204b3:	mov    0x3b0(%rsp),%rcx
  8204bb:	mov    %rcx,0x1e0(%rax)
  8204c2:	mov    %rdi,0x1e8(%rax)
  8204c9:	mov    %r9,0x1f0(%rax)
  8204d0:	add    %rbx,%r13
  8204d3:	mov    %rbx,0x1f8(%rax)
  8204da:	mov    %r13,0x200(%rax)
  8204e1:	mov    %r15,0x208(%rax)
  8204e8:	mov    0x98(%rsp),%rcx
  8204f0:	mov    %rcx,0x210(%rax)
  8204f7:	mov    %rsi,0x218(%rax)
  8204fe:	movb   $0x0,0x220(%rax)
  820505:	mov    0x50(%rsp),%rdi
  82050a:	mov    0x38(%rsp),%rax
  82050f:	mov    %rax,0x8(%rdi)
  820513:	movl   $0xffffffff,(%rdi)
  820519:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  82051e:	mov    0x50(%rsp),%rdi
  820523:	jmp    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  820528:	movq   $0x0,0x18(%rsp)
  820531:	xor    %eax,%eax
  820533:	movq   $0x0,0x10(%rsp)
  82053c:	jmp    820550 <<gpui_gpu::renderer::RendererState>::render+0x2480>
  82053e:	incq   0x10(%rsp)
  820543:	add    $0x8,%rax
  820547:	cmp    %rax,%rdi
  82054a:	je     81fefd <<gpui_gpu::renderer::RendererState>::render+0x1e2d>
  820550:	mov    0x4(%r8,%rax,1),%ecx
  820555:	mov    %ecx,%edx
  820557:	neg    %edx
  820559:	jo     82053e <<gpui_gpu::renderer::RendererState>::render+0x246e>
  82055b:	cmp    %ecx,(%r8,%rax,1)
  82055f:	je     820543 <<gpui_gpu::renderer::RendererState>::render+0x2473>
  820561:	lea    0x60de80(%rip),%rdi        # e2e3e8 <anon.e7af5e0dba0d7261d22cb76253955a85.29.llvm.10167252663607395722+0x10>
  820568:	call   *0x65f7da(%rip)        # e7fd48 <_DYNAMIC+0x5e0>
  82056e:	lea    0x60dcdb(%rip),%rdi        # e2e250 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  820575:	call   *0x65f7d5(%rip)        # e7fd50 <_DYNAMIC+0x5e8>
  82057b:	lea    0x60dce6(%rip),%rdx        # e2e268 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  820582:	call   *0x65f6d8(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  820588:	lea    0x60dca9(%rip),%rdx        # e2e238 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  82058f:	call   *0x65f6cb(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  820595:	mov    %rax,%r14
  820598:	mov    0x8(%rsp),%rax
  82059d:	mov    %r13,0x330(%rax)
  8205a4:	mov    %rbp,0x338(%rax)
  8205ab:	mov    %r14,%rdi
  8205ae:	call   e2c520 <_Unwind_Resume@plt>
  8205b3:	mov    %rax,%r14
  8205b6:	lock decq 0x0(%r13)
  8205bb:	jne    8205dd <<gpui_gpu::renderer::RendererState>::render+0x250d>
  8205bd:	lea    0x300(%rsp),%rdi
  8205c5:	call   *0x65f6b5(%rip)        # e7fc80 <_DYNAMIC+0x518>
  8205cb:	jmp    8205dd <<gpui_gpu::renderer::RendererState>::render+0x250d>
  8205cd:	call   *0x65f3e5(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  8205d3:	mov    %rax,%r14
  8205d6:	movq   $0x0,(%rbx)
  8205dd:	mov    %r14,%rdi
  8205e0:	call   e2c520 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4184 frame=824

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008205f0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  8205f0:	push   %rbp
  8205f1:	push   %r15
  8205f3:	push   %r14
  8205f5:	push   %r13
  8205f7:	push   %r12
  8205f9:	push   %rbx
  8205fa:	sub    $0x308,%rsp
  820601:	movss  0x88(%rdx),%xmm3
  820609:	movss  -0x771655(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820611:	movaps %xmm3,%xmm1
  820614:	subss  %xmm0,%xmm1
  820618:	cvttss2si %xmm1,%rax
  82061d:	cvttss2si %xmm3,%r10
  820622:	mov    %r10,%r12
  820625:	sar    $0x3f,%r12
  820629:	and    %rax,%r12
  82062c:	or     %r10,%r12
  82062f:	xor    %eax,%eax
  820631:	xorps  %xmm1,%xmm1
  820634:	ucomiss %xmm1,%xmm3
  820637:	cmovb  %rax,%r12
  82063b:	movss  0x90(%rdx),%xmm4
  820643:	movss  -0x77168b(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82064b:	ucomiss %xmm2,%xmm3
  82064e:	mov    $0xffffffffffffffff,%r10
  820655:	cmova  %r10,%r12
  820659:	movaps %xmm4,%xmm3
  82065c:	subss  %xmm0,%xmm3
  820660:	cvttss2si %xmm3,%r11
  820665:	cvttss2si %xmm4,%rbx
  82066a:	mov    %rbx,%r14
  82066d:	sar    $0x3f,%r14
  820671:	and    %r11,%r14
  820674:	or     %rbx,%r14
  820677:	ucomiss %xmm1,%xmm4
  82067a:	cmovb  %rax,%r14
  82067e:	ucomiss %xmm2,%xmm4
  820681:	cmova  %r10,%r14
  820685:	movss  0x8c(%rdx),%xmm3
  82068d:	lea    (%r12,%r14,1),%rbx
  820691:	dec    %rbx
  820694:	shr    $0x4,%rbx
  820698:	shr    $0x4,%r12
  82069c:	mov    %rbx,%rbp
  82069f:	sub    %r12,%rbp
  8206a2:	inc    %rbp
  8206a5:	movaps %xmm3,%xmm4
  8206a8:	subss  %xmm0,%xmm4
  8206ac:	cvttss2si %xmm4,%r15
  8206b1:	cvttss2si %xmm3,%r11
  8206b6:	mov    %r11,%r14
  8206b9:	sar    $0x3f,%r14
  8206bd:	and    %r15,%r14
  8206c0:	or     %r11,%r14
  8206c3:	ucomiss %xmm1,%xmm3
  8206c6:	cmovb  %rax,%r14
  8206ca:	ucomiss %xmm2,%xmm3
  8206cd:	movss  0x94(%rdx),%xmm3
  8206d5:	cmova  %r10,%r14
  8206d9:	movaps %xmm3,%xmm4
  8206dc:	subss  %xmm0,%xmm4
  8206e0:	cvttss2si %xmm4,%r13
  8206e5:	cvttss2si %xmm3,%r11
  8206ea:	mov    %r11,%r15
  8206ed:	sar    $0x3f,%r15
  8206f1:	and    %r13,%r15
  8206f4:	or     %r11,%r15
  8206f7:	ucomiss %xmm1,%xmm3
  8206fa:	cmovb  %rax,%r15
  8206fe:	ucomiss %xmm2,%xmm3
  820701:	cmova  %r10,%r15
  820705:	lea    (%r14,%r15,1),%r10
  820709:	dec    %r10
  82070c:	shr    $0x4,%r10
  820710:	shr    $0x4,%r14
  820714:	mov    %r10,%r11
  820717:	sub    %r14,%r11
  82071a:	inc    %r11
  82071d:	imul   %rbp,%r11
  820721:	add    0x358(%rsp),%r11
  820729:	setb   %al
  82072c:	cmp    $0x400001,%r11
  820733:	setae  %bpl
  820737:	or     %al,%bpl
  82073a:	mov    $0x6,%eax
  82073f:	jne    82077f <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  820741:	mov    %r8d,0xac(%rsp)
  820749:	mov    %r9,0x98(%rsp)
  820751:	mov    %r11,0x190(%rsp)
  820759:	mov    %rdi,0x198(%rsp)
  820761:	cmp    %r14,%r10
  820764:	jae    820793 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  820766:	mov    0x198(%rsp),%rdi
  82076e:	mov    0x190(%rsp),%rax
  820776:	mov    %rax,0x8(%rdi)
  82077a:	mov    $0xffffffff,%eax
  82077f:	mov    %eax,(%rdi)
  820781:	add    $0x308,%rsp
  820788:	pop    %rbx
  820789:	pop    %r12
  82078b:	pop    %r13
  82078d:	pop    %r14
  82078f:	pop    %r15
  820791:	pop    %rbp
  820792:	ret
  820793:	mov    %r12,%r9
  820796:	cmp    %r12,%rbx
  820799:	jae    8207b6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  82079b:	nopl   0x0(%rax,%rax,1)
  8207a0:	mov    %r14,%rax
  8207a3:	cmp    %r10,%r14
  8207a6:	adc    $0x0,%r14
  8207aa:	cmp    %r10,%rax
  8207ad:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8207af:	cmp    %r10,%r14
  8207b2:	jbe    8207a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  8207b4:	jmp    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8207b6:	mov    0x340(%rsp),%r13
  8207be:	movd   0xa4(%rdx),%xmm0
  8207c6:	mov    0x20(%rsi),%rbp
  8207ca:	movdqu 0x98(%rdx),%xmm1
  8207d2:	movd   0xa0(%rdx),%xmm2
  8207da:	punpckldq %xmm0,%xmm2
  8207de:	punpcklqdq %xmm2,%xmm1
  8207e2:	movdqa -0x773eda(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  8207ea:	pand   %xmm1,%xmm2
  8207ee:	paddd  -0x773c86(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  8207f6:	pxor   -0x7724ce(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  8207fe:	pcmpgtd -0x773076(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  820806:	mov    %rsi,%rax
  820809:	mov    0x28(%rsi),%rsi
  82080d:	pandn  %xmm1,%xmm2
  820811:	movmskps %xmm2,%edi
  820814:	test   %edi,%edi
  820816:	mov    %r10,0xb8(%rsp)
  82081e:	jne    82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820824:	ucomiss -0x771aab(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82082b:	jne    82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820831:	jp     82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820837:	cmpb   $0x0,0x340(%rax)
  82083e:	je     82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820844:	cmpb   $0x0,(%rdx)
  820847:	jne    82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  82084d:	test   %r13,%r13
  820850:	je     821613 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1023>
  820856:	mov    0x350(%rsp),%r12d
  82085e:	mov    0x348(%rsp),%r8d
  820866:	movd   %ecx,%xmm2
  82086a:	shr    $0x20,%rcx
  82086e:	movss  0x78(%rdx),%xmm0
  820873:	movss  0x80(%rdx),%xmm3
  82087b:	cvtss2sd %xmm0,%xmm0
  82087f:	movss  0x7c(%rdx),%xmm1
  820884:	cvtss2sd %xmm1,%xmm1
  820888:	cvtss2sd %xmm3,%xmm13
  82088d:	movss  0x84(%rdx),%xmm3
  820895:	addsd  %xmm0,%xmm13
  82089a:	cvtss2sd %xmm3,%xmm3
  82089e:	addsd  %xmm1,%xmm3
  8208a2:	movsd  %xmm3,0x1c8(%rsp)
  8208ab:	movsd  0x48(%rdx),%xmm6
  8208b0:	movsd  0x58(%rdx),%xmm7
  8208b5:	movss  0x38(%rdx),%xmm3
  8208ba:	movss  0x3c(%rdx),%xmm4
  8208bf:	movss  0x40(%rdx),%xmm5
  8208c4:	cvtss2sd %xmm3,%xmm8
  8208c9:	movss  0x44(%rdx),%xmm3
  8208ce:	cvtss2sd %xmm5,%xmm5
  8208d2:	movaps -0x775b2a(%rip),%xmm9        # aadb0 <GCC_except_table0+0x88>
  8208da:	movaps %xmm8,0x80(%rsp)
  8208e3:	andps  %xmm9,%xmm8
  8208e7:	movaps %xmm8,0x70(%rsp)
  8208ed:	movaps %xmm5,0x50(%rsp)
  8208f2:	andps  %xmm9,%xmm5
  8208f6:	movaps %xmm5,0x60(%rsp)
  8208fb:	cvtss2sd %xmm2,%xmm2
  8208ff:	movsd  %xmm2,0x8(%rsp)
  820905:	movaps %xmm6,%xmm2
  820908:	andps  %xmm9,%xmm2
  82090c:	movaps %xmm2,0x270(%rsp)
  820914:	movaps %xmm7,%xmm2
  820917:	andps  %xmm9,%xmm2
  82091b:	movaps %xmm2,0x250(%rsp)
  820923:	xorps  %xmm2,%xmm2
  820926:	cvtss2sd %xmm4,%xmm2
  82092a:	cvtss2sd %xmm3,%xmm3
  82092e:	movsd  0x68(%rdx),%xmm4
  820933:	movaps %xmm4,%xmm5
  820936:	andps  %xmm9,%xmm5
  82093a:	movaps %xmm5,0x100(%rsp)
  820942:	movaps %xmm2,0x40(%rsp)
  820947:	andps  %xmm9,%xmm2
  82094b:	movaps %xmm2,0x30(%rsp)
  820950:	movaps %xmm3,0x10(%rsp)
  820955:	andps  %xmm9,%xmm3
  820959:	movaps %xmm3,0x20(%rsp)
  82095e:	movd   %ecx,%xmm2
  820962:	cvtss2sd %xmm2,%xmm2
  820966:	movsd  %xmm2,(%rsp)
  82096b:	movsd  0x50(%rdx),%xmm2
  820970:	movaps %xmm2,%xmm3
  820973:	andps  %xmm9,%xmm3
  820977:	movaps %xmm3,0x1f0(%rsp)
  82097f:	movsd  0x60(%rdx),%xmm3
  820984:	movaps %xmm3,%xmm5
  820987:	andps  %xmm9,%xmm5
  82098b:	movaps %xmm5,0x1d0(%rsp)
  820993:	movsd  0x70(%rdx),%xmm5
  820998:	movaps %xmm5,%xmm8
  82099c:	andps  %xmm9,%xmm8
  8209a0:	movaps %xmm8,0xc0(%rsp)
  8209a9:	mov    0x58(%rax),%rcx
  8209ad:	mov    %rcx,0xb0(%rsp)
  8209b5:	mov    0x50(%rax),%rax
  8209b9:	mov    %rax,0x168(%rsp)
  8209c1:	mov    0x98(%rsp),%rax
  8209c9:	inc    %eax
  8209cb:	mov    %rax,0x98(%rsp)
  8209d3:	movaps %xmm2,0x200(%rsp)
  8209db:	cvtsd2ss %xmm2,%xmm2
  8209df:	xorps  %xmm8,%xmm8
  8209e3:	cvtss2sd %xmm2,%xmm8
  8209e8:	movaps %xmm6,0x280(%rsp)
  8209f0:	movaps %xmm6,%xmm2
  8209f3:	movaps %xmm7,0x260(%rsp)
  8209fb:	movlhps %xmm7,%xmm2
  8209fe:	cvtpd2ps %xmm2,%xmm2
  820a02:	cvtps2pd %xmm2,%xmm6
  820a05:	movaps %xmm3,0x1e0(%rsp)
  820a0d:	xorps  %xmm2,%xmm2
  820a10:	cvtsd2ss %xmm3,%xmm2
  820a14:	xorps  %xmm3,%xmm3
  820a17:	cvtss2sd %xmm2,%xmm3
  820a1b:	movaps %xmm4,0x110(%rsp)
  820a23:	xorps  %xmm2,%xmm2
  820a26:	cvtsd2ss %xmm4,%xmm2
  820a2a:	xorps  %xmm4,%xmm4
  820a2d:	cvtss2sd %xmm2,%xmm4
  820a31:	movaps %xmm5,0xd0(%rsp)
  820a39:	xorps  %xmm2,%xmm2
  820a3c:	cvtsd2ss %xmm5,%xmm2
  820a40:	cvtss2sd %xmm2,%xmm2
  820a44:	movaps %xmm6,%xmm5
  820a47:	andps  %xmm9,%xmm5
  820a4b:	movaps %xmm4,0x130(%rsp)
  820a53:	andps  %xmm9,%xmm4
  820a57:	movaps %xmm4,0x120(%rsp)
  820a5f:	movaps %xmm8,0x240(%rsp)
  820a68:	andps  %xmm9,%xmm8
  820a6c:	movaps %xmm8,0x230(%rsp)
  820a75:	movaps %xmm3,0x220(%rsp)
  820a7d:	andps  %xmm9,%xmm3
  820a81:	movaps %xmm3,0x210(%rsp)
  820a89:	movaps %xmm2,0xe0(%rsp)
  820a91:	andps  %xmm2,%xmm9
  820a95:	movaps %xmm9,0xf0(%rsp)
  820a9e:	movaps %xmm6,0x2a0(%rsp)
  820aa6:	movhlps %xmm6,%xmm6
  820aa9:	movaps %xmm6,0x2d0(%rsp)
  820ab1:	movaps %xmm5,0x290(%rsp)
  820ab9:	movhlps %xmm5,%xmm5
  820abc:	movaps %xmm5,0x2c0(%rsp)
  820ac4:	mov    %r9,0x1b8(%rsp)
  820acc:	movsd  %xmm13,0xa0(%rsp)
  820ad6:	cs nopw 0x0(%rax,%rax,1)
  820ae0:	mov    %r14,%rcx
  820ae3:	cmp    %r10,%r14
  820ae6:	adc    $0x0,%r14
  820aea:	mov    %rcx,0x1c0(%rsp)
  820af2:	imul   %r13,%rcx
  820af6:	mov    %r9,%rdi
  820af9:	nopl   0x0(%rax)
  820b00:	cmp    %rbx,%rdi
  820b03:	adc    $0x0,%r9
  820b07:	lea    (%rdi,%rcx,1),%r10
  820b0b:	mov    %r10,%rax
  820b0e:	shr    $0x20,%rax
  820b12:	je     820b20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  820b14:	mov    %r10,%rax
  820b17:	xor    %edx,%edx
  820b19:	div    %r13
  820b1c:	jmp    820b28 <<gpui_gpu::renderer::RendererState>::bin_draw+0x538>
  820b1e:	xchg   %ax,%ax
  820b20:	mov    %r10d,%eax
  820b23:	xor    %edx,%edx
  820b25:	div    %r13d
  820b28:	shl    $0x4,%edx
  820b2b:	shl    $0x4,%eax
  820b2e:	lea    0x10(%rdx),%r11d
  820b32:	cmp    %r11d,%r8d
  820b35:	cmovb  %r8d,%r11d
  820b39:	lea    0x10(%rax),%r15d
  820b3d:	cmp    %r15d,%r12d
  820b40:	cmovb  %r12d,%r15d
  820b44:	xorps  %xmm11,%xmm11
  820b48:	cvtsi2sd %edx,%xmm11
  820b4d:	ucomisd %xmm11,%xmm0
  820b52:	ja     820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b54:	mov    %eax,%eax
  820b56:	xorps  %xmm2,%xmm2
  820b59:	cvtsi2sd %rax,%xmm2
  820b5e:	ucomisd %xmm2,%xmm1
  820b62:	ja     820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b64:	xorps  %xmm15,%xmm15
  820b68:	cvtsi2sd %r11d,%xmm15
  820b6d:	ucomisd %xmm13,%xmm15
  820b72:	ja     820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b74:	xorps  %xmm14,%xmm14
  820b78:	cvtsi2sd %r15d,%xmm14
  820b7d:	ucomisd 0x1c8(%rsp),%xmm14
  820b87:	jbe    820bb8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5c8>
  820b89:	nopl   0x0(%rax)
  820b90:	cmp    %rsi,%r10
  820b93:	jae    821603 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1013>
  820b99:	incl   0x4(%rbp,%r10,8)
  820b9e:	cmp    %rbx,%rdi
  820ba1:	jae    821570 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf80>
  820ba7:	mov    %r9,%rdi
  820baa:	cmp    %rbx,%r9
  820bad:	jbe    820b00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x510>
  820bb3:	jmp    821570 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf80>
  820bb8:	unpcklpd %xmm2,%xmm11
  820bbd:	addpd  -0x773af6(%rip),%xmm11        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820bc6:	movapd %xmm11,%xmm9
  820bcb:	mulpd  0x2a0(%rsp),%xmm9
  820bd5:	movapd %xmm9,%xmm12
  820bda:	unpckhpd %xmm9,%xmm12
  820bdf:	movapd %xmm9,%xmm2
  820be4:	addsd  %xmm12,%xmm2
  820be9:	addsd  0x130(%rsp),%xmm2
  820bf2:	subsd  0x80(%rsp),%xmm2
  820bfb:	movapd 0x290(%rsp),%xmm7
  820c04:	mulpd  %xmm11,%xmm7
  820c09:	movapd %xmm7,%xmm8
  820c0e:	unpckhpd %xmm7,%xmm8
  820c13:	movapd %xmm7,%xmm3
  820c17:	addsd  %xmm8,%xmm3
  820c1c:	addsd  0x120(%rsp),%xmm3
  820c25:	addsd  0x70(%rsp),%xmm3
  820c2b:	addsd  0x60(%rsp),%xmm3
  820c31:	addsd  -0x7713c1(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c39:	mulsd  -0x771441(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820c41:	addsd  0x8(%rsp),%xmm3
  820c47:	ucomisd %xmm2,%xmm3
  820c4b:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820c51:	movapd 0x50(%rsp),%xmm4
  820c57:	subsd  %xmm2,%xmm4
  820c5b:	ucomisd %xmm4,%xmm3
  820c5f:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820c65:	movapd %xmm11,%xmm6
  820c6a:	unpckhpd %xmm11,%xmm6
  820c6f:	movapd 0x260(%rsp),%xmm10
  820c79:	mulsd  %xmm6,%xmm10
  820c7e:	movapd 0x250(%rsp),%xmm3
  820c87:	mulsd  %xmm6,%xmm3
  820c8b:	movapd 0x280(%rsp),%xmm2
  820c94:	mulsd  %xmm11,%xmm2
  820c99:	movapd %xmm2,0x150(%rsp)
  820ca2:	addsd  %xmm10,%xmm2
  820ca7:	addsd  0x110(%rsp),%xmm2
  820cb0:	subsd  0x80(%rsp),%xmm2
  820cb9:	movapd 0x270(%rsp),%xmm4
  820cc2:	mulsd  %xmm11,%xmm4
  820cc7:	movsd  %xmm4,0x1b0(%rsp)
  820cd0:	addsd  %xmm3,%xmm4
  820cd4:	addsd  0x100(%rsp),%xmm4
  820cdd:	addsd  0x70(%rsp),%xmm4
  820ce3:	addsd  0x60(%rsp),%xmm4
  820ce9:	addsd  -0x771479(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cf1:	mulsd  -0x770f21(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820cf9:	ucomisd %xmm2,%xmm4
  820cfd:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d03:	movapd 0x50(%rsp),%xmm5
  820d09:	subsd  %xmm2,%xmm5
  820d0d:	ucomisd %xmm5,%xmm4
  820d11:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d17:	movapd %xmm6,%xmm4
  820d1b:	mulsd  0x220(%rsp),%xmm4
  820d24:	movapd %xmm6,%xmm2
  820d28:	mulsd  0x210(%rsp),%xmm2
  820d31:	movapd %xmm11,%xmm5
  820d36:	mulsd  0x240(%rsp),%xmm5
  820d3f:	movsd  %xmm5,0x1a8(%rsp)
  820d48:	movapd %xmm4,0x140(%rsp)
  820d51:	addsd  %xmm4,%xmm5
  820d55:	addsd  0xe0(%rsp),%xmm5
  820d5e:	subsd  0x40(%rsp),%xmm5
  820d64:	movapd %xmm11,%xmm4
  820d69:	mulsd  0x230(%rsp),%xmm4
  820d72:	movsd  %xmm4,0x1a0(%rsp)
  820d7b:	addsd  %xmm2,%xmm4
  820d7f:	addsd  0xf0(%rsp),%xmm4
  820d88:	addsd  0x30(%rsp),%xmm4
  820d8e:	addsd  0x20(%rsp),%xmm4
  820d94:	addsd  -0x771524(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d9c:	mulsd  -0x7715a4(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820da4:	addsd  (%rsp),%xmm4
  820da9:	ucomisd %xmm5,%xmm4
  820dad:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820db3:	movapd 0x10(%rsp),%xmm13
  820dba:	subsd  %xmm5,%xmm13
  820dbf:	ucomisd %xmm13,%xmm4
  820dc4:	movsd  0xa0(%rsp),%xmm13
  820dce:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820dd4:	movapd 0x1e0(%rsp),%xmm4
  820ddd:	mulsd  %xmm6,%xmm4
  820de1:	mulsd  0x1d0(%rsp),%xmm6
  820dea:	movapd 0x200(%rsp),%xmm5
  820df3:	mulsd  %xmm11,%xmm5
  820df8:	movapd %xmm5,0x2e0(%rsp)
  820e01:	movapd %xmm4,0x2f0(%rsp)
  820e0a:	addsd  %xmm4,%xmm5
  820e0e:	addsd  0xd0(%rsp),%xmm5
  820e17:	subsd  0x40(%rsp),%xmm5
  820e1d:	mulsd  0x1f0(%rsp),%xmm11
  820e27:	movapd %xmm11,%xmm4
  820e2c:	addsd  %xmm6,%xmm4
  820e30:	addsd  0xc0(%rsp),%xmm4
  820e39:	addsd  0x30(%rsp),%xmm4
  820e3f:	addsd  0x20(%rsp),%xmm4
  820e45:	addsd  -0x7715d5(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e4d:	mulsd  -0x77107d(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820e55:	ucomisd %xmm5,%xmm4
  820e59:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820e5f:	movapd 0x10(%rsp),%xmm13
  820e66:	subsd  %xmm5,%xmm13
  820e6b:	ucomisd %xmm13,%xmm4
  820e70:	movsd  0xa0(%rsp),%xmm13
  820e7a:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820e80:	addsd  -0x771901(%rip),%xmm15        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820e89:	movapd %xmm15,%xmm4
  820e8e:	mulsd  0x2a0(%rsp),%xmm4
  820e97:	movsd  %xmm4,0x188(%rsp)
  820ea0:	addsd  %xmm4,%xmm12
  820ea5:	addsd  0x130(%rsp),%xmm12
  820eaf:	subsd  0x80(%rsp),%xmm12
  820eb9:	movapd 0x290(%rsp),%xmm4
  820ec2:	mulsd  %xmm15,%xmm4
  820ec7:	movsd  %xmm4,0x180(%rsp)
  820ed0:	addsd  %xmm4,%xmm8
  820ed5:	addsd  0x120(%rsp),%xmm8
  820edf:	addsd  0x70(%rsp),%xmm8
  820ee6:	addsd  0x60(%rsp),%xmm8
  820eed:	addsd  -0x77167e(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ef6:	mulsd  -0x7716ff(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820eff:	addsd  0x8(%rsp),%xmm8
  820f06:	ucomisd %xmm12,%xmm8
  820f0b:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f11:	movapd 0x50(%rsp),%xmm4
  820f17:	subsd  %xmm12,%xmm4
  820f1c:	ucomisd %xmm4,%xmm8
  820f21:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f27:	movapd 0x280(%rsp),%xmm12
  820f31:	mulsd  %xmm15,%xmm12
  820f36:	addsd  %xmm12,%xmm10
  820f3b:	addsd  0x110(%rsp),%xmm10
  820f45:	subsd  0x80(%rsp),%xmm10
  820f4f:	movapd 0x270(%rsp),%xmm4
  820f58:	mulsd  %xmm15,%xmm4
  820f5d:	movsd  %xmm4,0x178(%rsp)
  820f66:	addsd  %xmm4,%xmm3
  820f6a:	addsd  0x100(%rsp),%xmm3
  820f73:	addsd  0x70(%rsp),%xmm3
  820f79:	addsd  0x60(%rsp),%xmm3
  820f7f:	addsd  -0x77170f(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f87:	mulsd  -0x7711b7(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f8f:	ucomisd %xmm10,%xmm3
  820f94:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f9a:	movapd 0x50(%rsp),%xmm4
  820fa0:	subsd  %xmm10,%xmm4
  820fa5:	ucomisd %xmm4,%xmm3
  820fa9:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820faf:	movapd %xmm15,%xmm3
  820fb4:	mulsd  0x240(%rsp),%xmm3
  820fbd:	movsd  %xmm3,0x170(%rsp)
  820fc6:	movapd 0x140(%rsp),%xmm5
  820fcf:	addsd  %xmm3,%xmm5
  820fd3:	addsd  0xe0(%rsp),%xmm5
  820fdc:	subsd  0x40(%rsp),%xmm5
  820fe2:	movapd %xmm15,%xmm3
  820fe7:	mulsd  0x230(%rsp),%xmm3
  820ff0:	movsd  %xmm3,0x140(%rsp)
  820ff9:	addsd  %xmm3,%xmm2
  820ffd:	addsd  0xf0(%rsp),%xmm2
  821006:	addsd  0x30(%rsp),%xmm2
  82100c:	addsd  0x20(%rsp),%xmm2
  821012:	addsd  -0x7717a2(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82101a:	mulsd  -0x771822(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821022:	addsd  (%rsp),%xmm2
  821027:	ucomisd %xmm5,%xmm2
  82102b:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821031:	movapd 0x10(%rsp),%xmm3
  821037:	subsd  %xmm5,%xmm3
  82103b:	ucomisd %xmm3,%xmm2
  82103f:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821045:	movapd 0x200(%rsp),%xmm2
  82104e:	mulsd  %xmm15,%xmm2
  821053:	movapd %xmm2,0x2b0(%rsp)
  82105c:	movapd 0x2f0(%rsp),%xmm4
  821065:	addsd  %xmm2,%xmm4
  821069:	addsd  0xd0(%rsp),%xmm4
  821072:	subsd  0x40(%rsp),%xmm4
  821078:	mulsd  0x1f0(%rsp),%xmm15
  821082:	addsd  %xmm15,%xmm6
  821087:	addsd  0xc0(%rsp),%xmm6
  821090:	addsd  0x30(%rsp),%xmm6
  821096:	addsd  0x20(%rsp),%xmm6
  82109c:	addsd  -0x77182c(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210a4:	mulsd  -0x7712d4(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210ac:	ucomisd %xmm4,%xmm6
  8210b0:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8210b6:	movapd 0x10(%rsp),%xmm2
  8210bc:	subsd  %xmm4,%xmm2
  8210c0:	ucomisd %xmm2,%xmm6
  8210c4:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8210ca:	addsd  -0x771b4b(%rip),%xmm14        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8210d3:	movapd %xmm14,%xmm3
  8210d8:	mulsd  0x2d0(%rsp),%xmm3
  8210e1:	movapd %xmm14,%xmm2
  8210e6:	mulsd  0x2c0(%rsp),%xmm2
  8210ef:	addsd  %xmm3,%xmm9
  8210f4:	addsd  0x130(%rsp),%xmm9
  8210fe:	subsd  0x80(%rsp),%xmm9
  821108:	addsd  %xmm2,%xmm7
  82110c:	addsd  0x120(%rsp),%xmm7
  821115:	addsd  0x70(%rsp),%xmm7
  82111b:	addsd  0x60(%rsp),%xmm7
  821121:	addsd  -0x7718b1(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821129:	mulsd  -0x771931(%rip),%xmm7        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821131:	addsd  0x8(%rsp),%xmm7
  821137:	ucomisd %xmm9,%xmm7
  82113c:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821142:	movapd 0x50(%rsp),%xmm4
  821148:	subsd  %xmm9,%xmm4
  82114d:	ucomisd %xmm4,%xmm7
  821151:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821157:	movapd 0x260(%rsp),%xmm6
  821160:	mulsd  %xmm14,%xmm6
  821165:	movapd 0x250(%rsp),%xmm5
  82116e:	mulsd  %xmm14,%xmm5
  821173:	movapd 0x150(%rsp),%xmm4
  82117c:	addsd  %xmm6,%xmm4
  821180:	addsd  0x110(%rsp),%xmm4
  821189:	subsd  0x80(%rsp),%xmm4
  821192:	movsd  0x1b0(%rsp),%xmm9
  82119c:	addsd  %xmm5,%xmm9
  8211a1:	addsd  0x100(%rsp),%xmm9
  8211ab:	addsd  0x70(%rsp),%xmm9
  8211b2:	addsd  0x60(%rsp),%xmm9
  8211b9:	addsd  -0x77194a(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211c2:	mulsd  -0x7713f3(%rip),%xmm9        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8211cb:	ucomisd %xmm4,%xmm9
  8211d0:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8211d6:	movapd %xmm4,%xmm7
  8211da:	movapd 0x50(%rsp),%xmm4
  8211e0:	subsd  %xmm7,%xmm4
  8211e4:	ucomisd %xmm4,%xmm9
  8211e9:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8211ef:	movapd %xmm14,%xmm7
  8211f4:	mulsd  0x220(%rsp),%xmm7
  8211fd:	movapd %xmm14,%xmm9
  821202:	mulsd  0x210(%rsp),%xmm9
  82120c:	movsd  0x1a8(%rsp),%xmm8
  821216:	addsd  %xmm7,%xmm8
  82121b:	addsd  0xe0(%rsp),%xmm8
  821225:	subsd  0x40(%rsp),%xmm8
  82122c:	movapd %xmm12,%xmm4
  821231:	movsd  0x1a0(%rsp),%xmm12
  82123b:	movsd  %xmm9,0x150(%rsp)
  821245:	addsd  %xmm9,%xmm12
  82124a:	addsd  0xf0(%rsp),%xmm12
  821254:	addsd  0x30(%rsp),%xmm12
  82125b:	addsd  0x20(%rsp),%xmm12
  821262:	addsd  -0x7719f3(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82126b:	mulsd  -0x771a74(%rip),%xmm12        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821274:	addsd  (%rsp),%xmm12
  82127a:	ucomisd %xmm8,%xmm12
  82127f:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821285:	movapd %xmm8,%xmm9
  82128a:	movapd 0x10(%rsp),%xmm8
  821291:	subsd  %xmm9,%xmm8
  821296:	ucomisd %xmm8,%xmm12
  82129b:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8212a1:	movapd 0x1e0(%rsp),%xmm8
  8212ab:	mulsd  %xmm14,%xmm8
  8212b0:	mulsd  0x1d0(%rsp),%xmm14
  8212ba:	movapd 0x2e0(%rsp),%xmm9
  8212c4:	addsd  %xmm8,%xmm9
  8212c9:	addsd  0xd0(%rsp),%xmm9
  8212d3:	subsd  0x40(%rsp),%xmm9
  8212da:	addsd  %xmm14,%xmm11
  8212df:	addsd  0xc0(%rsp),%xmm11
  8212e9:	addsd  0x30(%rsp),%xmm11
  8212f0:	addsd  0x20(%rsp),%xmm11
  8212f7:	addsd  -0x771a88(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821300:	mulsd  -0x771531(%rip),%xmm11        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821309:	ucomisd %xmm9,%xmm11
  82130e:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821314:	movapd %xmm9,%xmm10
  821319:	movapd 0x10(%rsp),%xmm9
  821320:	subsd  %xmm10,%xmm9
  821325:	ucomisd %xmm9,%xmm11
  82132a:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821330:	movsd  0x188(%rsp),%xmm9
  82133a:	addsd  %xmm3,%xmm9
  82133f:	addsd  0x130(%rsp),%xmm9
  821349:	subsd  0x80(%rsp),%xmm9
  821353:	movsd  0x180(%rsp),%xmm10
  82135d:	addsd  %xmm2,%xmm10
  821362:	addsd  0x120(%rsp),%xmm10
  82136c:	addsd  0x70(%rsp),%xmm10
  821373:	addsd  0x60(%rsp),%xmm10
  82137a:	addsd  -0x771b0b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821383:	mulsd  -0x771b8c(%rip),%xmm10        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82138c:	addsd  0x8(%rsp),%xmm10
  821393:	ucomisd %xmm9,%xmm10
  821398:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  82139e:	movapd %xmm4,%xmm12
  8213a3:	movapd 0x50(%rsp),%xmm2
  8213a9:	subsd  %xmm9,%xmm2
  8213ae:	ucomisd %xmm2,%xmm10
  8213b3:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8213b9:	addsd  %xmm6,%xmm12
  8213be:	addsd  0x110(%rsp),%xmm12
  8213c8:	subsd  0x80(%rsp),%xmm12
  8213d2:	movsd  0x178(%rsp),%xmm2
  8213db:	addsd  %xmm5,%xmm2
  8213df:	addsd  0x100(%rsp),%xmm2
  8213e8:	addsd  0x70(%rsp),%xmm2
  8213ee:	addsd  0x60(%rsp),%xmm2
  8213f4:	addsd  -0x771b84(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213fc:	mulsd  -0x77162c(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821404:	ucomisd %xmm12,%xmm2
  821409:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  82140f:	movapd %xmm2,%xmm3
  821413:	movapd 0x50(%rsp),%xmm2
  821419:	subsd  %xmm12,%xmm2
  82141e:	ucomisd %xmm2,%xmm3
  821422:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821428:	movsd  0x170(%rsp),%xmm2
  821431:	addsd  %xmm7,%xmm2
  821435:	addsd  0xe0(%rsp),%xmm2
  82143e:	subsd  0x40(%rsp),%xmm2
  821444:	movsd  0x140(%rsp),%xmm5
  82144d:	addsd  0x150(%rsp),%xmm5
  821456:	addsd  0xf0(%rsp),%xmm5
  82145f:	addsd  0x30(%rsp),%xmm5
  821465:	addsd  0x20(%rsp),%xmm5
  82146b:	addsd  -0x771bfb(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821473:	mulsd  -0x771c7b(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82147b:	addsd  (%rsp),%xmm5
  821480:	ucomisd %xmm2,%xmm5
  821484:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  82148a:	movapd %xmm2,%xmm3
  82148e:	movapd 0x10(%rsp),%xmm2
  821494:	subsd  %xmm3,%xmm2
  821498:	ucomisd %xmm2,%xmm5
  82149c:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8214a2:	movapd 0x2b0(%rsp),%xmm2
  8214ab:	addsd  %xmm8,%xmm2
  8214b0:	addsd  0xd0(%rsp),%xmm2
  8214b9:	subsd  0x40(%rsp),%xmm2
  8214bf:	addsd  %xmm14,%xmm15
  8214c4:	addsd  0xc0(%rsp),%xmm15
  8214ce:	addsd  0x30(%rsp),%xmm15
  8214d5:	addsd  0x20(%rsp),%xmm15
  8214dc:	addsd  -0x771c6d(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214e5:	mulsd  -0x771716(%rip),%xmm15        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8214ee:	ucomisd %xmm2,%xmm15
  8214f3:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8214f9:	movapd %xmm2,%xmm3
  8214fd:	movapd 0x10(%rsp),%xmm2
  821503:	subsd  %xmm3,%xmm2
  821507:	ucomisd %xmm2,%xmm15
  82150c:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821512:	cmp    %rsi,%r10
  821515:	jae    821620 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1030>
  82151b:	mov    0xac(%rsp),%eax
  821522:	mov    %eax,0x0(%rbp,%r10,8)
  821527:	movl   $0x1,0x4(%rbp,%r10,8)
  821530:	cmp    0xb0(%rsp),%r10
  821538:	jae    821630 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1040>
  82153e:	mov    0x98(%rsp),%rax
  821546:	mov    0x168(%rsp),%rdx
  82154e:	mov    %eax,(%rdx,%r10,4)
  821552:	movsd  0xa0(%rsp),%xmm13
  82155c:	cmp    %rbx,%rdi
  82155f:	jb     820ba7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5b7>
  821565:	data16 cs nopw 0x0(%rax,%rax,1)
  821570:	mov    0xb8(%rsp),%r10
  821578:	cmp    %r10,0x1c0(%rsp)
  821580:	mov    0x1b8(%rsp),%r9
  821588:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82158e:	cmp    %r10,%r14
  821591:	jbe    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4f0>
  821597:	jmp    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82159c:	mov    %r14,%rax
  82159f:	nop
  8215a0:	cmp    %r10,%r14
  8215a3:	adc    $0x0,%rax
  8215a7:	mov    %r14,%rcx
  8215aa:	imul   %r13,%rcx
  8215ae:	mov    %r9,%rdx
  8215b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  8215c0:	lea    (%rdx,%rcx,1),%r10
  8215c4:	cmp    %rsi,%r10
  8215c7:	jae    821603 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1013>
  8215c9:	cmp    %rbx,%rdx
  8215cc:	mov    %rdx,%rdi
  8215cf:	adc    $0x0,%rdi
  8215d3:	incl   0x4(%rbp,%r10,8)
  8215d8:	cmp    %rbx,%rdx
  8215db:	jae    8215e5 <<gpui_gpu::renderer::RendererState>::bin_draw+0xff5>
  8215dd:	mov    %rdi,%rdx
  8215e0:	cmp    %rbx,%rdi
  8215e3:	jbe    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfd0>
  8215e5:	mov    0xb8(%rsp),%r10
  8215ed:	cmp    %r10,%r14
  8215f0:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8215f6:	mov    %rax,%r14
  8215f9:	cmp    %r10,%rax
  8215fc:	jbe    8215a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfb0>
  8215fe:	jmp    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821603:	lea    0x60ccd6(%rip),%rdx        # e2e2e0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  82160a:	mov    %r10,%rdi
  82160d:	call   *0x65e64d(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  821613:	lea    0x60cdce(%rip),%rdi        # e2e3e8 <anon.e7af5e0dba0d7261d22cb76253955a85.29.llvm.10167252663607395722+0x10>
  82161a:	call   *0x65e728(%rip)        # e7fd48 <_DYNAMIC+0x5e0>
  821620:	lea    0x60ccd1(%rip),%rdx        # e2e2f8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  821627:	mov    %r10,%rdi
  82162a:	call   *0x65e630(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  821630:	lea    0x60ccd9(%rip),%rdx        # e2e310 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf8>
  821637:	mov    %r10,%rdi
  82163a:	mov    0xb0(%rsp),%rsi
  821642:	call   *0x65e618(%rip)        # e7fc60 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821650 <gpui_gpu::renderer::compact_group>:
  821650:	xor    %eax,%eax
  821652:	test   %esi,%esi
  821654:	je     821693 <gpui_gpu::renderer::compact_group+0x43>
  821656:	cmpq   $0x2,0x10(%rdi)
  82165b:	jb     821693 <gpui_gpu::renderer::compact_group+0x43>
  82165d:	sub    $0x58,%rsp
  821661:	mov    (%rdi),%rsi
  821664:	mov    0x8(%rdi),%rax
  821668:	mov    (%rax),%edx
  82166a:	mov    %rsp,%rdi
  82166d:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  821672:	movss  0x4(%rsp),%xmm0
  821678:	cmpb   $0x3,(%rsp)
  82167c:	setne  %cl
  82167f:	xorps  %xmm1,%xmm1
  821682:	ucomiss %xmm1,%xmm0
  821685:	setnp  %dl
  821688:	sete   %al
  82168b:	and    %dl,%al
  82168d:	or     %cl,%al
  82168f:	add    $0x58,%rsp
  821693:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008216a0 <gpui_gpu::renderer::validate_draw>:
  8216a0:	push   %rbp
  8216a1:	push   %r15
  8216a3:	push   %r14
  8216a5:	push   %r12
  8216a7:	push   %rbx
  8216a8:	sub    $0x80,%rsp
  8216af:	mov    %r8d,%ebp
  8216b2:	mov    %ecx,%r12d
  8216b5:	mov    %rdx,%r14
  8216b8:	mov    %rsi,%r15
  8216bb:	mov    %rdi,%rbx
  8216be:	movups 0x88(%rsi),%xmm0
  8216c5:	movaps %xmm0,0x20(%rsp)
  8216ca:	movaps %xmm0,0x70(%rsp)
  8216cf:	lea    0x70(%rsp),%rdi
  8216d4:	call   *0x65e6fe(%rip)        # e7fdd8 <_DYNAMIC+0x670>
  8216da:	movaps 0x20(%rsp),%xmm4
  8216df:	test   %al,%al
  8216e1:	je     821737 <gpui_gpu::renderer::validate_draw+0x97>
  8216e3:	movaps %xmm4,%xmm0
  8216e6:	unpckhpd %xmm4,%xmm0
  8216ea:	xorps  %xmm2,%xmm2
  8216ed:	ucomiss %xmm2,%xmm0
  8216f0:	jne    8216f4 <gpui_gpu::renderer::validate_draw+0x54>
  8216f2:	jnp    821737 <gpui_gpu::renderer::validate_draw+0x97>
  8216f4:	movaps %xmm4,%xmm1
  8216f7:	shufps $0xff,%xmm4,%xmm1
  8216fb:	ucomiss %xmm2,%xmm1
  8216fe:	jne    821702 <gpui_gpu::renderer::validate_draw+0x62>
  821700:	jnp    821737 <gpui_gpu::renderer::validate_draw+0x97>
  821702:	xorps  %xmm3,%xmm3
  821705:	ucomiss %xmm4,%xmm3
  821708:	ja     821737 <gpui_gpu::renderer::validate_draw+0x97>
  82170a:	movaps %xmm4,%xmm2
  82170d:	shufps $0x55,%xmm4,%xmm2
  821711:	ucomiss %xmm2,%xmm3
  821714:	ja     821737 <gpui_gpu::renderer::validate_draw+0x97>
  821716:	xorps  %xmm3,%xmm3
  821719:	cvtsi2ss %r12d,%xmm3
  82171e:	addss  %xmm4,%xmm0
  821722:	ucomiss %xmm3,%xmm0
  821725:	ja     821737 <gpui_gpu::renderer::validate_draw+0x97>
  821727:	xorps  %xmm0,%xmm0
  82172a:	cvtsi2ss %ebp,%xmm0
  82172e:	addss  %xmm1,%xmm2
  821732:	ucomiss %xmm0,%xmm2
  821735:	jbe    82174d <gpui_gpu::renderer::validate_draw+0xad>
  821737:	movl   $0x3,(%rbx)
  82173d:	add    $0x80,%rsp
  821744:	pop    %rbx
  821745:	pop    %r12
  821747:	pop    %r14
  821749:	pop    %r15
  82174b:	pop    %rbp
  82174c:	ret
  82174d:	movsd  0x48(%r15),%xmm9
  821753:	movsd  0x60(%r15),%xmm1
  821759:	movupd 0x50(%r15),%xmm2
  82175f:	movapd %xmm2,%xmm5
  821763:	shufpd $0x1,%xmm2,%xmm5
  821768:	movupd 0x68(%r15),%xmm0
  82176e:	cvtpd2ps %xmm5,%xmm8
  821773:	movapd %xmm9,%xmm4
  821778:	unpcklpd %xmm1,%xmm4
  82177c:	cvtpd2ps %xmm4,%xmm7
  821780:	cvtpd2ps %xmm0,%xmm6
  821784:	movapd %xmm6,%xmm3
  821788:	shufps $0x55,%xmm6,%xmm3
  82178c:	movd   %xmm3,%ecx
  821790:	movd   %xmm6,%eax
  821794:	movapd %xmm7,%xmm3
  821798:	shufps $0x14,%xmm8,%xmm3
  82179d:	shufps $0x78,%xmm3,%xmm3
  8217a1:	andps  -0x774028(%rip),%xmm3        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8217a8:	and    $0x7fffffff,%eax
  8217ad:	cmp    $0x7f800000,%eax
  8217b2:	setge  %al
  8217b5:	and    $0x7fffffff,%ecx
  8217bb:	cmp    $0x7f800000,%ecx
  8217c1:	setge  %cl
  8217c4:	pcmpgtd -0x77611c(%rip),%xmm3        # ab6b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  8217cc:	movmskps %xmm3,%edx
  8217cf:	test   %edx,%edx
  8217d1:	jne    821822 <gpui_gpu::renderer::validate_draw+0x182>
  8217d3:	test   %al,%al
  8217d5:	jne    821822 <gpui_gpu::renderer::validate_draw+0x182>
  8217d7:	test   %cl,%cl
  8217d9:	jne    821822 <gpui_gpu::renderer::validate_draw+0x182>
  8217db:	movapd %xmm9,%xmm3
  8217e0:	mulsd  %xmm1,%xmm3
  8217e4:	movapd %xmm2,%xmm10
  8217e9:	mulsd  %xmm5,%xmm10
  8217ee:	subsd  %xmm10,%xmm3
  8217f3:	xorpd  %xmm10,%xmm10
  8217f8:	ucomisd %xmm10,%xmm3
  8217fd:	jne    821801 <gpui_gpu::renderer::validate_draw+0x161>
  8217ff:	jnp    821822 <gpui_gpu::renderer::validate_draw+0x182>
  821801:	movq   %xmm3,%rcx
  821806:	movabs $0x7fffffffffffffff,%rax
  821810:	and    %rax,%rcx
  821813:	movabs $0x7ff0000000000000,%rdx
  82181d:	cmp    %rdx,%rcx
  821820:	jl     821831 <gpui_gpu::renderer::validate_draw+0x191>
  821822:	movl   $0x5,(%rbx)
  821828:	mov    %r14,0x8(%rbx)
  82182c:	jmp    82173d <gpui_gpu::renderer::validate_draw+0x9d>
  821831:	xorps  %xmm10,%xmm10
  821835:	cvtsi2sd %r12d,%xmm10
  82183a:	cvtsi2sd %ebp,%xmm12
  82183f:	movsd  %xmm9,%xmm2
  821844:	movapd -0x776a9d(%rip),%xmm13        # aadb0 <GCC_except_table0+0x88>
  82184d:	andpd  %xmm13,%xmm2
  821852:	movapd %xmm10,%xmm11
  821857:	unpcklpd %xmm12,%xmm11
  82185c:	movapd %xmm2,%xmm9
  821861:	movapd %xmm11,0x50(%rsp)
  821868:	mulpd  %xmm11,%xmm9
  82186d:	movapd %xmm9,%xmm11
  821872:	unpckhpd %xmm9,%xmm11
  821877:	addsd  %xmm9,%xmm11
  82187c:	movapd %xmm0,%xmm9
  821881:	andpd  %xmm13,%xmm9
  821886:	addsd  %xmm11,%xmm9
  82188b:	shufpd $0x2,%xmm5,%xmm1
  821890:	andpd  %xmm13,%xmm1
  821895:	unpcklpd %xmm10,%xmm12
  82189a:	movapd %xmm1,%xmm10
  82189f:	movapd %xmm12,0x40(%rsp)
  8218a6:	mulpd  %xmm12,%xmm10
  8218ab:	movapd %xmm10,%xmm11
  8218b0:	unpckhpd %xmm10,%xmm11
  8218b5:	addsd  %xmm9,%xmm11
  8218ba:	addsd  %xmm10,%xmm11
  8218bf:	movapd %xmm0,%xmm10
  8218c4:	unpckhpd %xmm0,%xmm10
  8218c9:	andpd  %xmm13,%xmm10
  8218ce:	addsd  %xmm11,%xmm10
  8218d3:	movsd  0x38(%r15),%xmm9
  8218d9:	movsd  0x40(%r15),%xmm12
  8218df:	andps  -0x774167(%rip),%xmm9        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8218e7:	cvtps2pd %xmm9,%xmm15
  8218eb:	movapd %xmm10,%xmm9
  8218f0:	addsd  %xmm15,%xmm9
  8218f5:	movapd %xmm15,0x60(%rsp)
  8218fc:	unpckhpd %xmm15,%xmm15
  821901:	addsd  %xmm15,%xmm9
  821906:	cvtps2pd %xmm12,%xmm11
  82190a:	movapd %xmm11,0x20(%rsp)
  821911:	andpd  %xmm13,%xmm11
  821916:	addsd  %xmm11,%xmm9
  82191b:	pshufd $0xee,%xmm11,%xmm14
  821921:	movdqa %xmm14,0x30(%rsp)
  821928:	addsd  %xmm14,%xmm9
  82192d:	movq   %xmm9,%rsi
  821932:	and    %rax,%rsi
  821935:	movabs $0x7fefffffffffffff,%rcx
  82193f:	cmp    %rcx,%rsi
  821942:	jg     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821948:	ucomisd -0x772339(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821951:	ja     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821957:	movzbl (%r15),%esi
  82195b:	cmp    $0x3,%esi
  82195e:	je     821976 <gpui_gpu::renderer::validate_draw+0x2d6>
  821960:	xorpd  %xmm14,%xmm14
  821965:	cmp    $0x1,%esi
  821968:	jne    821aa2 <gpui_gpu::renderer::validate_draw+0x402>
  82196e:	movss  0x4(%r15),%xmm14
  821974:	jmp    82198d <gpui_gpu::renderer::validate_draw+0x2ed>
  821976:	movss  0x4(%r15),%xmm14
  82197c:	xorpd  %xmm13,%xmm13
  821981:	ucomiss %xmm13,%xmm14
  821985:	jne    82198d <gpui_gpu::renderer::validate_draw+0x2ed>
  821987:	jnp    821bc7 <gpui_gpu::renderer::validate_draw+0x527>
  82198d:	movd   %xmm14,%edi
  821992:	test   %edi,%edi
  821994:	sets   %r8b
  821998:	and    $0x7fffffff,%edi
  82199e:	lea    -0x800000(%rdi),%r9d
  8219a5:	cmp    $0x7f000000,%r9d
  8219ac:	setb   %r9b
  8219b0:	and    %r8b,%r9b
  8219b3:	lea    -0x1(%rdi),%r10d
  8219b7:	cmp    $0x7fffff,%r10d
  8219be:	setb   %r10b
  8219c2:	and    %r8b,%r10b
  8219c5:	cmp    $0x7f800000,%edi
  8219cb:	sete   %dil
  8219cf:	setg   %r8b
  8219d3:	or     %dil,%r8b
  8219d6:	or     %r10b,%r8b
  8219d9:	or     %r9b,%r8b
  8219dc:	cmp    $0x1,%r8b
  8219e0:	je     821737 <gpui_gpu::renderer::validate_draw+0x97>
  8219e6:	movaps %xmm11,(%rsp)
  8219eb:	movaps %xmm14,%xmm11
  8219ef:	movaps %xmm14,0x10(%rsp)
  8219f5:	movaps %xmm12,%xmm14
  8219f9:	mulss  -0x772a96(%rip),%xmm14        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821a02:	minss  %xmm14,%xmm11
  821a07:	movaps %xmm11,%xmm14
  821a0b:	cmpunordss %xmm11,%xmm14
  821a11:	movaps %xmm14,%xmm13
  821a15:	andnps %xmm11,%xmm13
  821a19:	andps  0x10(%rsp),%xmm14
  821a1f:	orps   %xmm13,%xmm14
  821a23:	shufps $0x55,%xmm12,%xmm12
  821a28:	mulss  -0x772ac5(%rip),%xmm12        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821a31:	movaps %xmm14,%xmm11
  821a35:	minss  %xmm12,%xmm11
  821a3a:	movaps %xmm11,%xmm12
  821a3e:	cmpunordss %xmm11,%xmm12
  821a44:	andps  %xmm12,%xmm14
  821a48:	andnps %xmm11,%xmm12
  821a4c:	orps   %xmm14,%xmm12
  821a50:	movss  -0x772809(%rip),%xmm11        # af250 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821a59:	ucomiss %xmm12,%xmm11
  821a5d:	ja     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821a63:	xorps  %xmm14,%xmm14
  821a67:	cvtss2sd %xmm12,%xmm14
  821a6c:	movapd %xmm9,%xmm11
  821a71:	divsd  %xmm14,%xmm11
  821a76:	ucomisd -0x7721ff(%rip),%xmm11        # af880 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  821a7f:	ja     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821a85:	addsd  %xmm9,%xmm14
  821a8a:	mulsd  -0x77236b(%rip),%xmm14        # af728 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821a93:	movapd (%rsp),%xmm11
  821a99:	movapd -0x776cf2(%rip),%xmm13        # aadb0 <GCC_except_table0+0x88>
  821aa2:	cmp    $0x2,%esi
  821aa5:	movaps %xmm11,(%rsp)
  821aaa:	jae    821bbb <gpui_gpu::renderer::validate_draw+0x51b>
  821ab0:	cvtps2pd %xmm8,%xmm8
  821ab4:	subpd  %xmm8,%xmm5
  821ab9:	cvtps2pd %xmm7,%xmm7
  821abc:	andpd  %xmm13,%xmm5
  821ac1:	mulpd  0x40(%rsp),%xmm5
  821ac7:	subpd  %xmm7,%xmm4
  821acb:	andpd  %xmm13,%xmm4
  821ad0:	mulpd  0x50(%rsp),%xmm4
  821ad6:	addpd  %xmm5,%xmm4
  821ada:	cvtps2pd %xmm6,%xmm5
  821add:	subpd  %xmm5,%xmm0
  821ae1:	addsd  -0x772272(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821aea:	mulsd  -0x7720ab(%rip),%xmm10        # afa48 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  821af3:	andpd  %xmm13,%xmm0
  821af8:	addpd  %xmm4,%xmm0
  821afc:	movapd 0x60(%rsp),%xmm7
  821b02:	addsd  %xmm7,%xmm15
  821b07:	movapd (%rsp),%xmm6
  821b0c:	addsd  %xmm6,%xmm15
  821b11:	addsd  0x30(%rsp),%xmm15
  821b18:	movapd %xmm0,%xmm4
  821b1c:	unpckhpd %xmm0,%xmm4
  821b20:	addpd  %xmm0,%xmm4
  821b24:	movapd %xmm1,%xmm5
  821b28:	shufpd $0x1,%xmm4,%xmm5
  821b2d:	movapd %xmm2,%xmm4
  821b31:	unpcklpd %xmm10,%xmm4
  821b36:	addpd  %xmm4,%xmm5
  821b3a:	mulsd  -0x7724eb(%rip),%xmm15        # af658 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821b43:	shufpd $0x1,%xmm15,%xmm2
  821b49:	addpd  %xmm5,%xmm2
  821b4d:	unpcklpd %xmm14,%xmm1
  821b52:	addpd  %xmm2,%xmm1
  821b56:	movapd %xmm1,%xmm2
  821b5a:	unpckhpd %xmm1,%xmm2
  821b5e:	mulsd  %xmm1,%xmm2
  821b62:	andpd  -0x776dba(%rip),%xmm3        # aadb0 <GCC_except_table0+0x88>
  821b6a:	divsd  %xmm3,%xmm2
  821b6e:	movq   %xmm2,%rdx
  821b73:	and    %rax,%rdx
  821b76:	cmp    %rcx,%rdx
  821b79:	jg     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821b7f:	ucomisd -0x771cdf(%rip),%xmm2        # afea8 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821b87:	ja     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821b8d:	unpcklpd %xmm10,%xmm10
  821b92:	addpd  %xmm10,%xmm0
  821b97:	addpd  %xmm7,%xmm6
  821b9b:	mulpd  -0x776c13(%rip),%xmm6        # aaf90 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821ba3:	addpd  %xmm0,%xmm6
  821ba7:	cvtpd2ps %xmm6,%xmm0
  821bab:	movlpd %xmm0,0x4(%rbx)
  821bb0:	movl   $0xffffffff,(%rbx)
  821bb6:	jmp    82173d <gpui_gpu::renderer::validate_draw+0x9d>
  821bbb:	jne    821bd0 <gpui_gpu::renderer::validate_draw+0x530>
  821bbd:	mov    0x28(%r15),%rsi
  821bc1:	mov    0x30(%r15),%rdi
  821bc5:	jmp    821bd8 <gpui_gpu::renderer::validate_draw+0x538>
  821bc7:	movaps %xmm11,(%rsp)
  821bcc:	xorps  %xmm14,%xmm14
  821bd0:	mov    0x28(%r15),%esi
  821bd4:	mov    0x2c(%r15),%edi
  821bd8:	movq   %rsi,%xmm11
  821bdd:	punpckldq -0x776316(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821be6:	subpd  -0x776e4f(%rip),%xmm11        # aada0 <GCC_except_table0+0x78>
  821bef:	movapd %xmm11,%xmm12
  821bf4:	unpckhpd %xmm11,%xmm12
  821bf9:	addsd  %xmm11,%xmm12
  821bfe:	movapd 0x20(%rsp),%xmm11
  821c05:	divsd  %xmm11,%xmm12
  821c0a:	movq   %xmm12,%r8
  821c0f:	and    %rax,%r8
  821c12:	cmp    %rdx,%r8
  821c15:	jge    821822 <gpui_gpu::renderer::validate_draw+0x182>
  821c1b:	movaps %xmm14,0x10(%rsp)
  821c21:	movapd %xmm11,%xmm14
  821c26:	movq   %rdi,%xmm11
  821c2b:	punpckldq -0x776364(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821c34:	subpd  -0x776e9d(%rip),%xmm11        # aada0 <GCC_except_table0+0x78>
  821c3d:	movapd %xmm11,%xmm13
  821c42:	unpckhpd %xmm11,%xmm13
  821c47:	addsd  %xmm11,%xmm13
  821c4c:	unpckhpd %xmm14,%xmm14
  821c51:	divsd  %xmm14,%xmm13
  821c56:	movapd 0x10(%rsp),%xmm14
  821c5d:	movq   %xmm13,%rdx
  821c62:	and    %rax,%rdx
  821c65:	cmp    %rcx,%rdx
  821c68:	setg   %dl
  821c6b:	ucomisd -0x77265c(%rip),%xmm13        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c74:	movapd -0x776ecd(%rip),%xmm13        # aadb0 <GCC_except_table0+0x88>
  821c7d:	ja     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821c83:	ucomisd -0x772674(%rip),%xmm12        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821c8c:	ja     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821c92:	test   %dl,%dl
  821c94:	jne    821822 <gpui_gpu::renderer::validate_draw+0x182>
  821c9a:	cmp    %rsi,%rdi
  821c9d:	cmova  %rdi,%rsi
  821ca1:	movq   %rsi,%xmm11
  821ca6:	punpckldq -0x7763df(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821caf:	subpd  -0x776f18(%rip),%xmm11        # aada0 <GCC_except_table0+0x78>
  821cb8:	movapd %xmm11,%xmm12
  821cbd:	unpckhpd %xmm11,%xmm12
  821cc2:	addsd  %xmm11,%xmm12
  821cc7:	mulsd  %xmm12,%xmm9
  821ccc:	ucomisd -0x7726bd(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821cd5:	ja     821822 <gpui_gpu::renderer::validate_draw+0x182>
  821cdb:	jmp    821ab0 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008223d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  8223d0:	push   %rbx
  8223d1:	test   %rdi,%rdi
  8223d4:	je     822437 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  8223d6:	mov    %rdi,%rbx
  8223d9:	mov    (%rdi),%rsi
  8223dc:	test   %rsi,%rsi
  8223df:	je     8223f4 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  8223e1:	mov    0x8(%rbx),%rdi
  8223e5:	shl    $0x3,%rsi
  8223e9:	mov    $0x8,%edx
  8223ee:	call   *0x65d5bc(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  8223f4:	mov    0x20(%rbx),%rsi
  8223f8:	test   %rsi,%rsi
  8223fb:	je     822423 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8223fd:	mov    %rsi,%rax
  822400:	shl    $0x4,%rax
  822404:	add    %rax,%rsi
  822407:	add    $0x21,%rsi
  82240b:	je     822423 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82240d:	mov    0x18(%rbx),%rdi
  822411:	sub    %rax,%rdi
  822414:	add    $0xfffffffffffffff0,%rdi
  822418:	mov    $0x10,%edx
  82241d:	call   *0x65d58d(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  822423:	mov    $0x80,%esi
  822428:	mov    $0x8,%edx
  82242d:	mov    %rbx,%rdi
  822430:	pop    %rbx
  822431:	jmp    *0x65d579(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  822437:	pop    %rbx
  822438:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822660 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  822660:	push   %r14
  822662:	push   %rbx
  822663:	push   %rax
  822664:	mov    %rdi,%rbx
  822667:	mov    (%rdi),%rax
  82266a:	lock decq (%rax)
  82266e:	jne    822679 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  822670:	mov    %rbx,%rdi
  822673:	call   *0x65d5f7(%rip)        # e7fc70 <_DYNAMIC+0x508>
  822679:	mov    0x8(%rbx),%rax
  82267d:	lock decq (%rax)
  822681:	jne    822697 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  822683:	add    $0x8,%rbx
  822687:	mov    %rbx,%rdi
  82268a:	add    $0x8,%rsp
  82268e:	pop    %rbx
  82268f:	pop    %r14
  822691:	jmp    *0x65d5e1(%rip)        # e7fc78 <_DYNAMIC+0x510>
  822697:	add    $0x8,%rsp
  82269b:	pop    %rbx
  82269c:	pop    %r14
  82269e:	ret
  82269f:	mov    %rax,%r14
  8226a2:	mov    0x8(%rbx),%rax
  8226a6:	lock decq (%rax)
  8226aa:	jne    8226b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  8226ac:	add    $0x8,%rbx
  8226b0:	mov    %rbx,%rdi
  8226b3:	call   *0x65d5bf(%rip)        # e7fc78 <_DYNAMIC+0x510>
  8226b9:	mov    %r14,%rdi
  8226bc:	call   e2c520 <_Unwind_Resume@plt>
  8226c1:	call   *0x65d2f1(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822790 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  822790:	push   %rbx
  822791:	mov    %rdi,%rbx
  822794:	mov    (%rdi),%rsi
  822797:	test   %rsi,%rsi
  82279a:	je     8227af <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  82279c:	mov    0x8(%rbx),%rdi
  8227a0:	shl    $0x3,%rsi
  8227a4:	mov    $0x8,%edx
  8227a9:	call   *0x65d201(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  8227af:	mov    0x20(%rbx),%rsi
  8227b3:	test   %rsi,%rsi
  8227b6:	je     8227df <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  8227b8:	mov    %rsi,%rax
  8227bb:	shl    $0x4,%rax
  8227bf:	add    %rax,%rsi
  8227c2:	add    $0x21,%rsi
  8227c6:	je     8227df <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  8227c8:	mov    0x18(%rbx),%rdi
  8227cc:	sub    %rax,%rdi
  8227cf:	add    $0xfffffffffffffff0,%rdi
  8227d3:	mov    $0x10,%edx
  8227d8:	pop    %rbx
  8227d9:	jmp    *0x65d1d1(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  8227df:	pop    %rbx
  8227e0:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008227f0 <<gpui_gpu::renderer::images::Images>::metadata>:
  8227f0:	push   %r15
  8227f2:	push   %r14
  8227f4:	push   %rbx
  8227f5:	sub    $0x10,%rsp
  8227f9:	mov    %rsi,0x8(%rsp)
  8227fe:	cmpq   $0x0,0x30(%rdi)
  822803:	je     8228cd <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  822809:	mov    %edx,%ebx
  82280b:	mov    %rsi,%r14
  82280e:	mov    %rdi,%r15
  822811:	add    $0x38,%rdi
  822815:	lea    0x8(%rsp),%rsi
  82281a:	call   822090 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82281f:	mov    %rax,%rsi
  822822:	shr    $0x39,%rsi
  822826:	mov    0x18(%r15),%rcx
  82282a:	mov    0x20(%r15),%rdx
  82282e:	movd   %esi,%xmm0
  822832:	punpcklbw %xmm0,%xmm0
  822836:	pshuflw $0x0,%xmm0,%xmm0
  82283b:	pshufd $0x44,%xmm0,%xmm0
  822840:	xor    %esi,%esi
  822842:	pcmpeqd %xmm1,%xmm1
  822846:	and    %rdx,%rax
  822849:	movdqu (%rcx,%rax,1),%xmm2
  82284e:	movdqa %xmm2,%xmm3
  822852:	pcmpeqb %xmm0,%xmm3
  822856:	pmovmskb %xmm3,%edi
  82285a:	test   %edi,%edi
  82285c:	je     822890 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  82285e:	tzcnt  %edi,%r9d
  822863:	add    %rax,%r9
  822866:	and    %rdx,%r9
  822869:	shl    $0x4,%r9
  82286d:	mov    %rcx,%r8
  822870:	sub    %r9,%r8
  822873:	cmp    -0x10(%r8),%r14
  822877:	je     8228a9 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  822879:	lea    -0x1(%rdi),%r8d
  82287d:	and    %di,%r8w
  822881:	mov    %r8d,%edi
  822884:	jne    82285e <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  822886:	cs nopw 0x0(%rax,%rax,1)
  822890:	pcmpeqb %xmm1,%xmm2
  822894:	pmovmskb %xmm2,%edi
  822898:	test   %edi,%edi
  82289a:	jne    8228cd <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  82289c:	add    %rsi,%rax
  82289f:	add    $0x10,%rax
  8228a3:	add    $0x10,%rsi
  8228a7:	jmp    822846 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  8228a9:	mov    -0x8(%r8),%eax
  8228ad:	movzbl %bl,%ecx
  8228b0:	or     -0x4(%r8),%ecx
  8228b4:	shl    $0x20,%rcx
  8228b8:	or     %rax,%rcx
  8228bb:	mov    $0x80000000,%eax
  8228c0:	or     %rcx,%rax
  8228c3:	add    $0x10,%rsp
  8228c7:	pop    %rbx
  8228c8:	pop    %r14
  8228ca:	pop    %r15
  8228cc:	ret
  8228cd:	lea    -0x74d948(%rip),%rdi        # d4f8c <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  8228d4:	lea    0x60bb25(%rip),%rdx        # e2e400 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456>
  8228db:	mov    $0x16,%esi
  8228e0:	call   *0x65d422(%rip)        # e7fd08 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2648 frame=536

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822b60 <gpui_gpu::renderer::images::prepare>:
  822b60:	push   %rbp
  822b61:	push   %r15
  822b63:	push   %r14
  822b65:	push   %r13
  822b67:	push   %r12
  822b69:	push   %rbx
  822b6a:	sub    $0x1e8,%rsp
  822b71:	mov    %r9,%r12
  822b74:	mov    %rcx,%r13
  822b77:	mov    %rdx,0xb0(%rsp)
  822b7f:	mov    %rsi,(%rsp)
  822b83:	mov    %rdi,%r15
  822b86:	mov    0x220(%rsp),%rax
  822b8e:	mov    0x10(%rax),%r14
  822b92:	mov    0x118(%r14),%rax
  822b99:	add    $0x118,%r14
  822ba0:	test   %rax,%rax
  822ba3:	mov    %r14,%rcx
  822ba6:	cmove  %rax,%rcx
  822baa:	je     822c3c <gpui_gpu::renderer::images::prepare+0xdc>
  822bb0:	mov    0x10(%rax),%rax
  822bb4:	mov    (%r8),%rbp
  822bb7:	mov    %rax,0x10(%rsp)
  822bbc:	test   %rax,%rax
  822bbf:	je     822c3f <gpui_gpu::renderer::images::prepare+0xdf>
  822bc1:	mov    %rcx,0xa0(%rsp)
  822bc9:	test   %rbp,%rbp
  822bcc:	je     822d88 <gpui_gpu::renderer::images::prepare+0x228>
  822bd2:	cmp    0x48(%rbp),%r12
  822bd6:	ja     822d88 <gpui_gpu::renderer::images::prepare+0x228>
  822bdc:	mov    0x8(%rbp),%rdi
  822be0:	mov    0x10(%rbp),%rax
  822be4:	lea    (%rdi,%rax,8),%rsi
  822be8:	movq   $0x1,0xd0(%rsp)
  822bf4:	mov    %r14,0xd8(%rsp)
  822bfc:	movq   $0x0,0xe0(%rsp)
  822c08:	movq   $0x0,0xf0(%rsp)
  822c14:	lea    0xd0(%rsp),%rdx
  822c1c:	mov    %r8,%rbx
  822c1f:	call   825aa0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  822c24:	mov    %rbx,%r8
  822c27:	test   %al,%al
  822c29:	je     822d88 <gpui_gpu::renderer::images::prepare+0x228>
  822c2f:	movq   $0x0,0x60(%rbp)
  822c37:	jmp    822d6c <gpui_gpu::renderer::images::prepare+0x20c>
  822c3c:	mov    (%r8),%rbp
  822c3f:	movq   $0x0,(%r8)
  822c46:	test   %rbp,%rbp
  822c49:	je     822d6c <gpui_gpu::renderer::images::prepare+0x20c>
  822c4f:	mov    0x0(%rbp),%rsi
  822c53:	test   %rsi,%rsi
  822c56:	je     822c6b <gpui_gpu::renderer::images::prepare+0x10b>
  822c58:	mov    0x8(%rbp),%rdi
  822c5c:	shl    $0x3,%rsi
  822c60:	mov    $0x8,%edx
  822c65:	call   *0x65cd45(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  822c6b:	mov    0x20(%rbp),%rsi
  822c6f:	test   %rsi,%rsi
  822c72:	je     822c9a <gpui_gpu::renderer::images::prepare+0x13a>
  822c74:	mov    %rsi,%rax
  822c77:	shl    $0x4,%rax
  822c7b:	add    %rax,%rsi
  822c7e:	add    $0x21,%rsi
  822c82:	je     822c9a <gpui_gpu::renderer::images::prepare+0x13a>
  822c84:	mov    0x18(%rbp),%rdi
  822c88:	sub    %rax,%rdi
  822c8b:	add    $0xfffffffffffffff0,%rdi
  822c8f:	mov    $0x10,%edx
  822c94:	call   *0x65cd16(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  822c9a:	mov    $0x80,%esi
  822c9f:	mov    $0x8,%edx
  822ca4:	mov    %rbp,%rdi
  822ca7:	call   *0x65cd03(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  822cad:	shl    $0x4,%r12
  822cb1:	cmp    $0x101,%r12
  822cb8:	mov    $0x100,%eax
  822cbd:	cmovae %r12,%rax
  822cc1:	dec    %rax
  822cc4:	bsr    %rax,%rcx
  822cc8:	not    %ecx
  822cca:	mov    $0xffffffffffffffff,%rbx
  822cd1:	shr    %cl,%rbx
  822cd4:	inc    %rbx
  822cd7:	lea    -0x74dd3c(%rip),%rax        # d4fa2 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x16>
  822cde:	mov    %rax,0x18(%rsp)
  822ce3:	movq   $0xa,0x20(%rsp)
  822cec:	mov    %rbx,0x28(%rsp)
  822cf1:	movl   $0x88,0x30(%rsp)
  822cf9:	movb   $0x0,0x34(%rsp)
  822cfe:	lea    0xd0(%rsp),%rdi
  822d06:	lea    0x18(%rsp),%rdx
  822d0b:	mov    (%rsp),%rsi
  822d0f:	call   *0x65d073(%rip)        # e7fd88 <_DYNAMIC+0x620>
  822d15:	mov    %rbx,0xf0(%rsp)
  822d1d:	mov    0x0(%r13),%rax
  822d21:	lock decq (%rax)
  822d25:	jne    822d30 <gpui_gpu::renderer::images::prepare+0x1d0>
  822d27:	mov    %r13,%rdi
  822d2a:	call   *0x65cf40(%rip)        # e7fc70 <_DYNAMIC+0x508>
  822d30:	mov    0x8(%r13),%rax
  822d34:	lock decq (%rax)
  822d38:	jne    822d44 <gpui_gpu::renderer::images::prepare+0x1e4>
  822d3a:	lea    0x8(%r13),%rdi
  822d3e:	call   *0x65cf34(%rip)        # e7fc78 <_DYNAMIC+0x510>
  822d44:	mov    0xf0(%rsp),%rax
  822d4c:	mov    %rax,0x20(%r13)
  822d50:	movdqu 0xd0(%rsp),%xmm0
  822d59:	movups 0xe0(%rsp),%xmm1
  822d61:	movups %xmm1,0x10(%r13)
  822d66:	movdqu %xmm0,0x0(%r13)
  822d6c:	movl   $0xffffffff,(%r15)
  822d73:	mov    %r15,%rax
  822d76:	add    $0x1e8,%rsp
  822d7d:	pop    %rbx
  822d7e:	pop    %r12
  822d80:	pop    %r13
  822d82:	pop    %r14
  822d84:	pop    %r15
  822d86:	pop    %rbp
  822d87:	ret
  822d88:	cmp    $0x1,%r12
  822d8c:	mov    %r12,%rax
  822d8f:	adc    $0xffffffffffffffff,%rax
  822d93:	bsr    %rax,%rcx
  822d97:	not    %ecx
  822d99:	mov    $0xffffffffffffffff,%rax
  822da0:	shr    %cl,%rax
  822da3:	cmp    $0x2,%r12
  822da7:	mov    $0x0,%r12d
  822dad:	cmovae %rax,%r12
  822db1:	inc    %r12
  822db4:	je     8234a8 <gpui_gpu::renderer::images::prepare+0x948>
  822dba:	mov    %r8,0xc8(%rsp)
  822dc2:	mov    %fs:0x0,%rax
  822dcb:	lea    -0x28(%rax),%rax
  822dd2:	mov    %rax,%rcx
  822dd5:	cmpb   $0x1,0x10(%rax)
  822dd9:	mov    %r15,0xa8(%rsp)
  822de1:	mov    %r13,0x8(%rsp)
  822de6:	jne    8234b4 <gpui_gpu::renderer::images::prepare+0x954>
  822dec:	mov    (%rcx),%rax
  822def:	mov    0x8(%rcx),%rdx
  822df3:	mov    0x10(%rsp),%rbx
  822df8:	lea    0x1(%rax),%rsi
  822dfc:	mov    %rsi,(%rcx)
  822dff:	movq   $0x0,0x18(%rsp)
  822e08:	movq   $0x8,0x20(%rsp)
  822e11:	movq   $0x0,0x28(%rsp)
  822e1a:	movups 0x60b5f7(%rip),%xmm0        # e2e418 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x18>
  822e21:	movups %xmm0,0x30(%rsp)
  822e26:	movdqu 0x60b5fa(%rip),%xmm0        # e2e428 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x28>
  822e2e:	movdqu %xmm0,0x40(%rsp)
  822e34:	mov    %rax,0x50(%rsp)
  822e39:	mov    %rdx,0x58(%rsp)
  822e3e:	mov    %r12,0x60(%rsp)
  822e43:	pxor   %xmm0,%xmm0
  822e47:	movdqu %xmm0,0x68(%rsp)
  822e4d:	movdqu %xmm0,0x78(%rsp)
  822e53:	movdqu %xmm0,0x88(%rsp)
  822e5c:	lea    0xd0(%rsp),%rdi
  822e64:	mov    $0x8,%edx
  822e69:	mov    $0x8,%r8d
  822e6f:	mov    $0x8,%r9d
  822e75:	xor    %esi,%esi
  822e77:	mov    %rbx,%rcx
  822e7a:	call   823e90 <<alloc::raw_vec::RawVecInner>::finish_grow>
  822e7f:	cmpl   $0x1,0xd0(%rsp)
  822e87:	jne    822ef4 <gpui_gpu::renderer::images::prepare+0x394>
  822e89:	mov    0xa8(%rsp),%r15
  822e91:	movl   $0x6,(%r15)
  822e98:	mov    0x18(%rsp),%rsi
  822e9d:	test   %rsi,%rsi
  822ea0:	je     822eb6 <gpui_gpu::renderer::images::prepare+0x356>
  822ea2:	mov    0x20(%rsp),%rdi
  822ea7:	shl    $0x3,%rsi
  822eab:	mov    $0x8,%edx
  822eb0:	call   *0x65cafa(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  822eb6:	mov    0x38(%rsp),%rsi
  822ebb:	test   %rsi,%rsi
  822ebe:	je     822d73 <gpui_gpu::renderer::images::prepare+0x213>
  822ec4:	mov    %rsi,%rax
  822ec7:	shl    $0x4,%rax
  822ecb:	add    %rax,%rsi
  822ece:	add    $0x21,%rsi
  822ed2:	je     822d73 <gpui_gpu::renderer::images::prepare+0x213>
  822ed8:	mov    0x30(%rsp),%rdi
  822edd:	sub    %rax,%rdi
  822ee0:	add    $0xfffffffffffffff0,%rdi
  822ee4:	mov    $0x10,%edx
  822ee9:	call   *0x65cac1(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  822eef:	jmp    822d73 <gpui_gpu::renderer::images::prepare+0x213>
  822ef4:	mov    %r12,0x98(%rsp)
  822efc:	mov    %rbp,0xc0(%rsp)
  822f04:	mov    0xd8(%rsp),%rax
  822f0c:	mov    %rax,0x20(%rsp)
  822f11:	mov    %rbx,0x18(%rsp)
  822f16:	cmp    0x40(%rsp),%rbx
  822f1b:	ja     8234d0 <gpui_gpu::renderer::images::prepare+0x970>
  822f21:	xor    %r12d,%r12d
  822f24:	mov    0x98(%rsp),%r15
  822f2c:	jmp    822f48 <gpui_gpu::renderer::images::prepare+0x3e8>
  822f2e:	xchg   %ax,%ax
  822f30:	add    $0x8,%r12
  822f34:	mov    0x20(%rsp),%rax
  822f39:	mov    %rbx,(%rax,%r15,8)
  822f3d:	inc    %r15
  822f40:	mov    %r15,0x28(%rsp)
  822f45:	mov    %r13,%r15
  822f48:	test   %r12,%r12
  822f4b:	je     822f70 <gpui_gpu::renderer::images::prepare+0x410>
  822f4d:	cmp    %rbp,%r12
  822f50:	je     822f70 <gpui_gpu::renderer::images::prepare+0x410>
  822f52:	mov    (%r12),%rcx
  822f56:	cmpb   $0x0,0x10(%rcx)
  822f5a:	je     822f9e <gpui_gpu::renderer::images::prepare+0x43e>
  822f5c:	mov    0x20(%rcx),%rax
  822f60:	shl    $0x4,%rax
  822f64:	mov    $0x8,%r8d
  822f6a:	jmp    822fb1 <gpui_gpu::renderer::images::prepare+0x451>
  822f6c:	nopl   0x0(%rax)
  822f70:	test   %r14,%r14
  822f73:	je     823038 <gpui_gpu::renderer::images::prepare+0x4d8>
  822f79:	mov    (%r14),%rax
  822f7c:	mov    0x10(%rax),%rcx
  822f80:	test   %rcx,%rcx
  822f83:	je     823038 <gpui_gpu::renderer::images::prepare+0x4d8>
  822f89:	mov    0x8(%rax),%r12
  822f8d:	lea    (%r12,%rcx,8),%rbp
  822f91:	xor    %r14d,%r14d
  822f94:	mov    (%r12),%rcx
  822f98:	cmpb   $0x0,0x10(%rcx)
  822f9c:	jne    822f5c <gpui_gpu::renderer::images::prepare+0x3fc>
  822f9e:	movzbl 0x11(%rcx),%edx
  822fa2:	movzbl 0x12(%rcx),%esi
  822fa6:	mov    0x20(%rcx),%rax
  822faa:	shl    $0x2,%edx
  822fad:	lea    (%rdx,%rsi,2),%r8d
  822fb1:	mov    0x70(%rsp),%rdx
  822fb6:	add    %rax,%rdx
  822fb9:	jb     822e89 <gpui_gpu::renderer::images::prepare+0x329>
  822fbf:	mov    0x28(%rcx),%rbx
  822fc3:	mov    %rdx,0x70(%rsp)
  822fc8:	cmp    $0x4000000,%rdx
  822fcf:	ja     822e89 <gpui_gpu::renderer::images::prepare+0x329>
  822fd5:	mov    %r15,%rcx
  822fd8:	shr    $0x20,%rcx
  822fdc:	jne    822e89 <gpui_gpu::renderer::images::prepare+0x329>
  822fe2:	test   %r15d,%r15d
  822fe5:	js     822e89 <gpui_gpu::renderer::images::prepare+0x329>
  822feb:	mov    %rax,%r13
  822fee:	shr    $0x4,%r13
  822ff2:	and    $0xf,%eax
  822ff5:	add    %r15,%r13
  822ff8:	cmp    $0x1,%rax
  822ffc:	sbb    $0xffffffffffffffff,%r13
  823000:	lea    0xd0(%rsp),%rdi
  823008:	lea    0x30(%rsp),%rsi
  82300d:	mov    %rbx,%rdx
  823010:	mov    %r15d,%ecx
  823013:	call   823910 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  823018:	mov    0x28(%rsp),%r15
  82301d:	cmp    0x18(%rsp),%r15
  823022:	jne    822f30 <gpui_gpu::renderer::images::prepare+0x3d0>
  823028:	lea    0x18(%rsp),%rdi
  82302d:	call   *0x65cdcd(%rip)        # e7fe00 <_DYNAMIC+0x698>
  823033:	jmp    822f30 <gpui_gpu::renderer::images::prepare+0x3d0>
  823038:	movabs $0xffffffffffffff0,%rax
  823042:	cmp    %rax,%r15
  823045:	ja     822e89 <gpui_gpu::renderer::images::prepare+0x329>
  82304b:	lea    0xd0(%rsp),%rdi
  823053:	mov    (%rsp),%rsi
  823057:	call   *0x65cdab(%rip)        # e7fe08 <_DYNAMIC+0x6a0>
  82305d:	mov    %r15,%rbx
  823060:	shl    $0x4,%rbx
  823064:	add    $0xff,%rbx
  82306b:	and    $0xffffffffffffff00,%rbx
  823072:	cmp    0x120(%rsp),%rbx
  82307a:	ja     822e89 <gpui_gpu::renderer::images::prepare+0x329>
  823080:	lea    0xd0(%rsp),%rdi
  823088:	mov    (%rsp),%rsi
  82308c:	call   *0x65cd76(%rip)        # e7fe08 <_DYNAMIC+0x6a0>
  823092:	cmp    0x130(%rsp),%rbx
  82309a:	ja     822e89 <gpui_gpu::renderer::images::prepare+0x329>
  8230a0:	mov    0x8(%rsp),%rax
  8230a5:	mov    0x20(%rax),%rax
  8230a9:	cmp    %rbx,%rax
  8230ac:	jb     8230d4 <gpui_gpu::renderer::images::prepare+0x574>
  8230ae:	lea    0x0(,%rbx,4),%rcx
  8230b6:	movabs $0x3fffffffffffff1,%rdx
  8230c0:	cmp    %rdx,%r15
  8230c3:	setb   %dl
  8230c6:	cmp    %rcx,%rax
  8230c9:	seta   %al
  8230cc:	test   %al,%dl
  8230ce:	je     823162 <gpui_gpu::renderer::images::prepare+0x602>
  8230d4:	lea    -0x74e12f(%rip),%rax        # d4fac <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x20>
  8230db:	mov    %rax,0x1c8(%rsp)
  8230e3:	movq   $0x1d,0x1d0(%rsp)
  8230ef:	mov    %rbx,0x1d8(%rsp)
  8230f7:	movl   $0x88,0x1e0(%rsp)
  823102:	movb   $0x0,0x1e4(%rsp)
  82310a:	lea    0xd0(%rsp),%rdi
  823112:	lea    0x1c8(%rsp),%rdx
  82311a:	mov    (%rsp),%rsi
  82311e:	call   *0x65cc64(%rip)        # e7fd88 <_DYNAMIC+0x620>
  823124:	mov    %rbx,0xf0(%rsp)
  82312c:	mov    0x8(%rsp),%r14
  823131:	mov    %r14,%rdi
  823134:	call   822660 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  823139:	mov    0xf0(%rsp),%rax
  823141:	mov    %rax,0x20(%r14)
  823145:	movdqu 0xd0(%rsp),%xmm0
  82314e:	movdqu 0xe0(%rsp),%xmm1
  823157:	movdqu %xmm1,0x10(%r14)
  82315d:	movdqu %xmm0,(%r14)
  823162:	movq   $0x0,(%rsp)
  82316a:	mov    0x65cbc7(%rip),%r14        # e7fd38 <_DYNAMIC+0x5d0>
  823171:	mov    (%rsp),%rdx
  823175:	test   %rdx,%rdx
  823178:	je     823184 <gpui_gpu::renderer::images::prepare+0x624>
  82317a:	cmp    0xb8(%rsp),%rdx
  823182:	jne    8231c1 <gpui_gpu::renderer::images::prepare+0x661>
  823184:	mov    0xa0(%rsp),%rax
  82318c:	test   %rax,%rax
  82318f:	je     823344 <gpui_gpu::renderer::images::prepare+0x7e4>
  823195:	mov    (%rax),%rax
  823198:	mov    0x10(%rax),%rcx
  82319c:	test   %rcx,%rcx
  82319f:	je     823344 <gpui_gpu::renderer::images::prepare+0x7e4>
  8231a5:	mov    0x8(%rax),%rdx
  8231a9:	lea    (%rdx,%rcx,8),%rax
  8231ad:	mov    %rax,0xb8(%rsp)
  8231b5:	movq   $0x0,0xa0(%rsp)
  8231c1:	mov    (%rdx),%rax
  8231c4:	mov    0x28(%rax),%r12
  8231c8:	movzbl 0x10(%rax),%ebx
  8231cc:	mov    0x18(%rax),%rbp
  8231d0:	mov    0x20(%rax),%r13
  8231d4:	mov    %r12,0xd0(%rsp)
  8231dc:	cmpq   $0x0,0x48(%rsp)
  8231e2:	je     823329 <gpui_gpu::renderer::images::prepare+0x7c9>
  8231e8:	add    $0x8,%rdx
  8231ec:	mov    %rdx,(%rsp)
  8231f0:	lea    0x50(%rsp),%rdi
  8231f5:	lea    0xd0(%rsp),%rsi
  8231fd:	call   822090 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  823202:	mov    %rax,%rsi
  823205:	shr    $0x39,%rsi
  823209:	mov    0x30(%rsp),%rcx
  82320e:	mov    0x38(%rsp),%rdx
  823213:	movd   %esi,%xmm0
  823217:	punpcklbw %xmm0,%xmm0
  82321b:	pshuflw $0x0,%xmm0,%xmm0
  823220:	pshufd $0x44,%xmm0,%xmm0
  823225:	xor    %esi,%esi
  823227:	and    %rdx,%rax
  82322a:	movdqu (%rcx,%rax,1),%xmm1
  82322f:	movdqa %xmm1,%xmm2
  823233:	pcmpeqb %xmm0,%xmm2
  823237:	pmovmskb %xmm2,%edi
  82323b:	test   %edi,%edi
  82323d:	je     823267 <gpui_gpu::renderer::images::prepare+0x707>
  82323f:	tzcnt  %edi,%r9d
  823244:	add    %rax,%r9
  823247:	and    %rdx,%r9
  82324a:	shl    $0x4,%r9
  82324e:	mov    %rcx,%r8
  823251:	sub    %r9,%r8
  823254:	cmp    -0x10(%r8),%r12
  823258:	je     823288 <gpui_gpu::renderer::images::prepare+0x728>
  82325a:	lea    -0x1(%rdi),%r8d
  82325e:	and    %di,%r8w
  823262:	mov    %r8d,%edi
  823265:	jne    82323f <gpui_gpu::renderer::images::prepare+0x6df>
  823267:	pcmpeqd %xmm2,%xmm2
  82326b:	pcmpeqb %xmm2,%xmm1
  82326f:	pmovmskb %xmm1,%edi
  823273:	test   %edi,%edi
  823275:	jne    823329 <gpui_gpu::renderer::images::prepare+0x7c9>
  82327b:	add    %rsi,%rax
  82327e:	add    $0x10,%rax
  823282:	add    $0x10,%rsi
  823286:	jmp    823227 <gpui_gpu::renderer::images::prepare+0x6c7>
  823288:	mov    -0x8(%r8),%r12d
  82328c:	shl    $0x4,%r12
  823290:	test   %bl,%bl
  823292:	je     8232e7 <gpui_gpu::renderer::images::prepare+0x787>
  823294:	test   %r13,%r13
  823297:	je     823171 <gpui_gpu::renderer::images::prepare+0x611>
  82329d:	nopl   (%rax)
  8232a0:	cmp    $0x1000,%r13
  8232a7:	mov    $0x1000,%r15d
  8232ad:	cmovb  %r13,%r15
  8232b1:	mov    %r15d,%ebx
  8232b4:	shl    $0x4,%ebx
  8232b7:	mov    0xb0(%rsp),%rdi
  8232bf:	mov    0x8(%rsp),%rsi
  8232c4:	mov    %r12,%rdx
  8232c7:	mov    %rbp,%rcx
  8232ca:	mov    %rbx,%r8
  8232cd:	call   *%r14
  8232d0:	mov    %r15,%rax
  8232d3:	shl    $0x4,%rax
  8232d7:	add    %rax,%rbp
  8232da:	add    %rbx,%r12
  8232dd:	sub    %r15,%r13
  8232e0:	jne    8232a0 <gpui_gpu::renderer::images::prepare+0x740>
  8232e2:	jmp    823171 <gpui_gpu::renderer::images::prepare+0x611>
  8232e7:	test   %r13,%r13
  8232ea:	je     823171 <gpui_gpu::renderer::images::prepare+0x611>
  8232f0:	cmp    $0x10000,%r13
  8232f7:	mov    $0x10000,%ebx
  8232fc:	cmovb  %r13,%rbx
  823300:	mov    0xb0(%rsp),%rdi
  823308:	mov    0x8(%rsp),%rsi
  82330d:	mov    %r12,%rdx
  823310:	mov    %rbp,%rcx
  823313:	mov    %rbx,%r8
  823316:	call   *%r14
  823319:	add    %rbx,%rbp
  82331c:	add    %rbx,%r12
  82331f:	sub    %rbx,%r13
  823322:	jne    8232f0 <gpui_gpu::renderer::images::prepare+0x790>
  823324:	jmp    823171 <gpui_gpu::renderer::images::prepare+0x611>
  823329:	lea    -0x74e3a4(%rip),%rdi        # d4f8c <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  823330:	lea    0x60b101(%rip),%rdx        # e2e438 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x38>
  823337:	mov    $0x16,%esi
  82333c:	call   *0x65c9c6(%rip)        # e7fd08 <_DYNAMIC+0x5a0>
  823342:	ud2
  823344:	mov    0x10(%rsp),%rax
  823349:	mov    %rax,0x68(%rsp)
  82334e:	mov    0x70(%rsp),%rax
  823353:	mov    %rax,0x78(%rsp)
  823358:	mov    0x98(%rsp),%rax
  823360:	shl    $0x4,%rax
  823364:	mov    %rax,0x80(%rsp)
  82336c:	mov    0x8(%rsp),%rax
  823371:	mov    0x20(%rax),%rax
  823375:	mov    %rax,0x88(%rsp)
  82337d:	mov    0x40(%rsp),%rax
  823382:	add    0x48(%rsp),%rax
  823387:	mov    %rax,0x90(%rsp)
  82338f:	mov    0x88(%rsp),%rax
  823397:	mov    %rax,0x140(%rsp)
  82339f:	mov    0x90(%rsp),%rax
  8233a7:	mov    %rax,0x148(%rsp)
  8233af:	mov    0x78(%rsp),%rax
  8233b4:	mov    %rax,0x130(%rsp)
  8233bc:	mov    0x80(%rsp),%rax
  8233c4:	mov    %rax,0x138(%rsp)
  8233cc:	movups 0x68(%rsp),%xmm0
  8233d1:	movaps %xmm0,0x120(%rsp)
  8233d9:	movups 0x58(%rsp),%xmm0
  8233de:	movaps %xmm0,0x110(%rsp)
  8233e6:	movups 0x48(%rsp),%xmm0
  8233eb:	movaps %xmm0,0x100(%rsp)
  8233f3:	movups 0x18(%rsp),%xmm0
  8233f8:	movups 0x28(%rsp),%xmm1
  8233fd:	movups 0x38(%rsp),%xmm2
  823402:	movaps %xmm2,0xf0(%rsp)
  82340a:	movaps %xmm1,0xe0(%rsp)
  823412:	movaps %xmm0,0xd0(%rsp)
  82341a:	call   822b30 <alloc::boxed::box_new_uninit>
  82341f:	mov    %rax,%rbx
  823422:	movaps 0x140(%rsp),%xmm0
  82342a:	movups %xmm0,0x70(%rax)
  82342e:	movaps 0x130(%rsp),%xmm0
  823436:	movups %xmm0,0x60(%rax)
  82343a:	movaps 0x120(%rsp),%xmm0
  823442:	movups %xmm0,0x50(%rax)
  823446:	movaps 0x110(%rsp),%xmm0
  82344e:	movups %xmm0,0x40(%rax)
  823452:	movdqa 0xd0(%rsp),%xmm0
  82345b:	movaps 0xe0(%rsp),%xmm1
  823463:	movaps 0xf0(%rsp),%xmm2
  82346b:	movaps 0x100(%rsp),%xmm3
  823473:	movups %xmm3,0x30(%rax)
  823477:	movups %xmm2,0x20(%rax)
  82347b:	movups %xmm1,0x10(%rax)
  82347f:	movdqu %xmm0,(%rax)
  823483:	mov    0xc0(%rsp),%rdi
  82348b:	call   8223d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  823490:	mov    0xc8(%rsp),%rax
  823498:	mov    %rbx,(%rax)
  82349b:	mov    0xa8(%rsp),%r15
  8234a3:	jmp    822d6c <gpui_gpu::renderer::images::prepare+0x20c>
  8234a8:	movl   $0x6,(%r15)
  8234af:	jmp    822d73 <gpui_gpu::renderer::images::prepare+0x213>
  8234b4:	mov    %rcx,%rbx
  8234b7:	call   *0x65c8d3(%rip)        # e7fd90 <_DYNAMIC+0x628>
  8234bd:	mov    %rbx,%rcx
  8234c0:	mov    %rax,(%rbx)
  8234c3:	mov    %rdx,0x8(%rbx)
  8234c7:	movb   $0x1,0x10(%rbx)
  8234cb:	jmp    822df3 <gpui_gpu::renderer::images::prepare+0x293>
  8234d0:	lea    0x30(%rsp),%rdi
  8234d5:	mov    0x10(%rsp),%rsi
  8234da:	lea    0x50(%rsp),%rdx
  8234df:	xor    %ecx,%ecx
  8234e1:	call   *0x65c929(%rip)        # e7fe10 <_DYNAMIC+0x6a8>
  8234e7:	cmp    $0xffffffffffffffff,%rax
  8234eb:	jne    822e89 <gpui_gpu::renderer::images::prepare+0x329>
  8234f1:	jmp    822f21 <gpui_gpu::renderer::images::prepare+0x3c1>
  8234f6:	mov    %rax,%rbx
  8234f9:	lea    0xd0(%rsp),%rdi
  823501:	call   822790 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823506:	mov    %rbx,%rdi
  823509:	call   e2c520 <_Unwind_Resume@plt>
  82350e:	mov    %rax,%rbx
  823511:	mov    0xf0(%rsp),%rax
  823519:	mov    %rax,0x20(%r14)
  82351d:	movups 0xd0(%rsp),%xmm0
  823525:	movups 0xe0(%rsp),%xmm1
  82352d:	movups %xmm1,0x10(%r14)
  823532:	movups %xmm0,(%r14)
  823536:	lea    0x18(%rsp),%rdi
  82353b:	call   822790 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823540:	mov    %rbx,%rdi
  823543:	call   e2c520 <_Unwind_Resume@plt>
  823548:	mov    %r13,%r14
  82354b:	mov    %rax,%rbx
  82354e:	jmp    82356a <gpui_gpu::renderer::images::prepare+0xa0a>
  823550:	mov    %rax,%rbx
  823553:	mov    %r13,%r14
  823556:	mov    0x8(%r13),%rax
  82355a:	lock decq (%rax)
  82355e:	jne    82356a <gpui_gpu::renderer::images::prepare+0xa0a>
  823560:	lea    0x8(%r14),%rdi
  823564:	call   *0x65c70e(%rip)        # e7fc78 <_DYNAMIC+0x510>
  82356a:	mov    0xf0(%rsp),%rax
  823572:	mov    %rax,0x20(%r14)
  823576:	movups 0xd0(%rsp),%xmm0
  82357e:	movups 0xe0(%rsp),%xmm1
  823586:	movups %xmm1,0x10(%r14)
  82358b:	movups %xmm0,(%r14)
  82358f:	mov    %rbx,%rdi
  823592:	call   e2c520 <_Unwind_Resume@plt>
  823597:	call   *0x65c41b(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  82359d:	jmp    8235a3 <gpui_gpu::renderer::images::prepare+0xa43>
  82359f:	jmp    8235a3 <gpui_gpu::renderer::images::prepare+0xa43>
  8235a1:	jmp    8235a3 <gpui_gpu::renderer::images::prepare+0xa43>
  8235a3:	mov    %rax,%rbx
  8235a6:	lea    0x18(%rsp),%rdi
  8235ab:	call   822790 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8235b0:	mov    %rbx,%rdi
  8235b3:	call   e2c520 <_Unwind_Resume@plt>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823720 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  823720:	push   %rbp
  823721:	push   %r15
  823723:	push   %r14
  823725:	push   %r13
  823727:	push   %r12
  823729:	push   %rbx
  82372a:	sub    $0x38,%rsp
  82372e:	mov    %rcx,%r15
  823731:	mov    %rdx,%r12
  823734:	mov    %rsi,%r14
  823737:	mov    %rdi,%rbx
  82373a:	lea    0x20(%rsi),%r13
  82373e:	mov    %r13,%rdi
  823741:	mov    %rdx,%rsi
  823744:	call   821ef0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  823749:	cmpq   $0x0,0x10(%r14)
  82374e:	je     8238d1 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  823754:	mov    (%r14),%r11
  823757:	mov    0x8(%r14),%rsi
  82375b:	mov    %rax,%rdx
  82375e:	shr    $0x39,%rdx
  823762:	movd   %edx,%xmm0
  823766:	punpcklbw %xmm0,%xmm0
  82376a:	pshuflw $0x0,%xmm0,%xmm0
  82376f:	pshufd $0x44,%xmm0,%xmm0
  823774:	mov    (%r12),%rcx
  823778:	mov    %rcx,0x8(%rsp)
  82377d:	movzwl 0xc(%r12),%r9d
  823783:	mov    0x8(%r12),%r10d
  823788:	xor    %r13d,%r13d
  82378b:	pcmpeqd %xmm1,%xmm1
  82378f:	xor    %r8d,%r8d
  823792:	and    %rsi,%rax
  823795:	movdqu (%r11,%rax,1),%xmm2
  82379b:	movdqa %xmm2,%xmm3
  82379f:	pcmpeqb %xmm0,%xmm3
  8237a3:	pmovmskb %xmm3,%ebp
  8237a7:	test   %ebp,%ebp
  8237a9:	je     8237f0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  8237ab:	mov    %r8,(%rsp)
  8237af:	mov    %r15,%r8
  8237b2:	tzcnt  %ebp,%r15d
  8237b7:	add    %rax,%r15
  8237ba:	and    %rsi,%r15
  8237bd:	shl    $0x5,%r15
  8237c1:	mov    %r11,%rcx
  8237c4:	sub    %r15,%rcx
  8237c7:	mov    0x8(%rsp),%r15
  8237cc:	cmp    -0x20(%rcx),%r15
  8237d0:	jne    8237df <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8237d2:	cmp    -0x14(%rcx),%r9w
  8237d7:	jne    8237df <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8237d9:	cmp    -0x18(%rcx),%r10d
  8237dd:	je     82382f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  8237df:	lea    -0x1(%rbp),%ecx
  8237e2:	and    %bp,%cx
  8237e5:	mov    %ecx,%ebp
  8237e7:	mov    %r8,%r15
  8237ea:	mov    (%rsp),%r8
  8237ee:	jne    8237af <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  8237f0:	cmp    $0x1,%r13
  8237f4:	je     823808 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  8237f6:	pmovmskb %xmm2,%ecx
  8237fa:	test   %ecx,%ecx
  8237fc:	je     82381c <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  8237fe:	tzcnt  %ecx,%edi
  823802:	add    %rax,%rdi
  823805:	and    %rsi,%rdi
  823808:	pcmpeqb %xmm1,%xmm2
  82380c:	pmovmskb %xmm2,%ecx
  823810:	test   %ecx,%ecx
  823812:	jne    823846 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  823814:	mov    $0x1,%r13d
  82381a:	jmp    82381f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  82381c:	xor    %r13d,%r13d
  82381f:	add    %r8,%rax
  823822:	add    $0x10,%rax
  823826:	add    $0x10,%r8
  82382a:	jmp    823792 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  82382f:	movups -0x10(%rcx),%xmm0
  823833:	movups %xmm0,0x4(%rbx)
  823837:	movups (%r8),%xmm0
  82383b:	movups %xmm0,-0x10(%rcx)
  82383f:	mov    $0x1,%eax
  823844:	jmp    8238bd <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  823846:	movzbl (%r11,%rdi,1),%eax
  82384b:	test   %al,%al
  82384d:	jns    8238f2 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  823853:	movups (%r12),%xmm0
  823858:	movaps %xmm0,0x10(%rsp)
  82385d:	movups (%r15),%xmm0
  823861:	movaps %xmm0,0x20(%rsp)
  823866:	and    $0x1,%al
  823868:	lea    -0x10(%rdi),%rcx
  82386c:	and    %rsi,%rcx
  82386f:	mov    %dl,(%r11,%rdi,1)
  823873:	mov    %dl,0x10(%r11,%rcx,1)
  823878:	movzbl %al,%eax
  82387b:	movd   %eax,%xmm0
  82387f:	shufpd $0x2,-0x7786a8(%rip),%xmm0        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  823888:	movdqu 0x10(%r14),%xmm1
  82388e:	psubq  %xmm0,%xmm1
  823892:	movdqu %xmm1,0x10(%r14)
  823898:	shl    $0x5,%rdi
  82389c:	mov    %r11,%rax
  82389f:	sub    %rdi,%rax
  8238a2:	neg    %rdi
  8238a5:	movaps 0x10(%rsp),%xmm0
  8238aa:	movdqa 0x20(%rsp),%xmm1
  8238b0:	movups %xmm0,-0x20(%r11,%rdi,1)
  8238b6:	movdqu %xmm1,-0x10(%rax)
  8238bb:	xor    %eax,%eax
  8238bd:	mov    %eax,(%rbx)
  8238bf:	mov    %rbx,%rax
  8238c2:	add    $0x38,%rsp
  8238c6:	pop    %rbx
  8238c7:	pop    %r12
  8238c9:	pop    %r13
  8238cb:	pop    %r14
  8238cd:	pop    %r15
  8238cf:	pop    %rbp
  8238d0:	ret
  8238d1:	mov    $0x1,%esi
  8238d6:	mov    %r14,%rdi
  8238d9:	mov    %r13,%rdx
  8238dc:	mov    $0x1,%ecx
  8238e1:	mov    %rax,%r13
  8238e4:	call   *0x65c55e(%rip)        # e7fe48 <_DYNAMIC+0x6e0>
  8238ea:	mov    %r13,%rax
  8238ed:	jmp    823754 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  8238f2:	movdqa (%r11),%xmm0
  8238f7:	pmovmskb %xmm0,%eax
  8238fb:	tzcnt  %eax,%edi
  8238ff:	movzbl (%r11,%rdi,1),%eax
  823904:	jmp    823853 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823910 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  823910:	push   %rbp
  823911:	push   %r15
  823913:	push   %r14
  823915:	push   %r13
  823917:	push   %r12
  823919:	push   %rbx
  82391a:	push   %rax
  82391b:	mov    %r8d,%ebp
  82391e:	mov    %ecx,%r14d
  823921:	mov    %rdx,%r15
  823924:	mov    %rsi,%r12
  823927:	mov    %rdi,%rbx
  82392a:	mov    %rdx,(%rsp)
  82392e:	lea    0x20(%rsi),%r13
  823932:	mov    %rsp,%rsi
  823935:	mov    %r13,%rdi
  823938:	call   822090 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82393d:	cmpq   $0x0,0x10(%r12)
  823943:	je     823a86 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  823949:	mov    (%r12),%rcx
  82394d:	mov    0x8(%r12),%rsi
  823952:	mov    %rax,%rdx
  823955:	shr    $0x39,%rdx
  823959:	movd   %edx,%xmm0
  82395d:	punpcklbw %xmm0,%xmm0
  823961:	pshuflw $0x0,%xmm0,%xmm0
  823966:	pshufd $0x44,%xmm0,%xmm0
  82396b:	xor    %r9d,%r9d
  82396e:	pcmpeqd %xmm1,%xmm1
  823972:	xor    %r8d,%r8d
  823975:	and    %rsi,%rax
  823978:	movdqu (%rcx,%rax,1),%xmm2
  82397d:	movdqa %xmm2,%xmm3
  823981:	pcmpeqb %xmm0,%xmm3
  823985:	pmovmskb %xmm3,%r10d
  82398a:	test   %r10d,%r10d
  82398d:	je     8239c0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  82398f:	tzcnt  %r10d,%r13d
  823994:	add    %rax,%r13
  823997:	and    %rsi,%r13
  82399a:	shl    $0x4,%r13
  82399e:	mov    %rcx,%r11
  8239a1:	sub    %r13,%r11
  8239a4:	cmp    -0x10(%r11),%r15
  8239a8:	je     823a01 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  8239aa:	lea    -0x1(%r10),%r11d
  8239ae:	and    %r10w,%r11w
  8239b2:	mov    %r11d,%r10d
  8239b5:	jne    82398f <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  8239b7:	nopw   0x0(%rax,%rax,1)
  8239c0:	cmp    $0x1,%r9
  8239c4:	je     8239d8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  8239c6:	pmovmskb %xmm2,%edi
  8239ca:	test   %edi,%edi
  8239cc:	je     8239ee <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  8239ce:	tzcnt  %edi,%edi
  8239d2:	add    %rax,%rdi
  8239d5:	and    %rsi,%rdi
  8239d8:	pcmpeqb %xmm1,%xmm2
  8239dc:	pmovmskb %xmm2,%r9d
  8239e1:	test   %r9d,%r9d
  8239e4:	jne    823a18 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  8239e6:	mov    $0x1,%r9d
  8239ec:	jmp    8239f1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  8239ee:	xor    %r9d,%r9d
  8239f1:	add    %r8,%rax
  8239f4:	add    $0x10,%rax
  8239f8:	add    $0x10,%r8
  8239fc:	jmp    823975 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  823a01:	mov    -0x8(%r11),%rax
  823a05:	mov    %r14d,-0x8(%r11)
  823a09:	mov    %ebp,-0x4(%r11)
  823a0d:	mov    %rax,0x4(%rbx)
  823a11:	mov    $0x1,%eax
  823a16:	jmp    823a72 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  823a18:	movzbl (%rcx,%rdi,1),%eax
  823a1c:	test   %al,%al
  823a1e:	jns    823aa7 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  823a24:	and    $0x1,%al
  823a26:	lea    -0x10(%rdi),%r8
  823a2a:	and    %rsi,%r8
  823a2d:	mov    %dl,(%rcx,%rdi,1)
  823a30:	mov    %dl,0x10(%rcx,%r8,1)
  823a35:	movdqu 0x10(%r12),%xmm0
  823a3c:	movzbl %al,%eax
  823a3f:	movd   %eax,%xmm1
  823a43:	shufpd $0x2,-0x77886c(%rip),%xmm1        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  823a4c:	psubq  %xmm1,%xmm0
  823a50:	movdqu %xmm0,0x10(%r12)
  823a57:	shl    $0x4,%rdi
  823a5b:	mov    %rcx,%rax
  823a5e:	sub    %rdi,%rax
  823a61:	neg    %rdi
  823a64:	mov    %r15,-0x10(%rcx,%rdi,1)
  823a69:	mov    %r14d,-0x8(%rax)
  823a6d:	mov    %ebp,-0x4(%rax)
  823a70:	xor    %eax,%eax
  823a72:	mov    %eax,(%rbx)
  823a74:	mov    %rbx,%rax
  823a77:	add    $0x8,%rsp
  823a7b:	pop    %rbx
  823a7c:	pop    %r12
  823a7e:	pop    %r13
  823a80:	pop    %r14
  823a82:	pop    %r15
  823a84:	pop    %rbp
  823a85:	ret
  823a86:	mov    $0x1,%esi
  823a8b:	mov    %r12,%rdi
  823a8e:	mov    %r13,%rdx
  823a91:	mov    $0x1,%ecx
  823a96:	mov    %rax,%r13
  823a99:	call   *0x65c371(%rip)        # e7fe10 <_DYNAMIC+0x6a8>
  823a9f:	mov    %r13,%rax
  823aa2:	jmp    823949 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  823aa7:	movdqa (%rcx),%xmm0
  823aab:	pmovmskb %xmm0,%eax
  823aaf:	tzcnt  %eax,%edi
  823ab3:	movzbl (%rcx,%rdi,1),%eax
  823ab7:	jmp    823a24 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823e20 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  823e20:	push   %r14
  823e22:	push   %rbx
  823e23:	sub    $0x18,%rsp
  823e27:	mov    %rdi,%rbx
  823e2a:	mov    (%rdi),%rsi
  823e2d:	lea    (%rsi,%rsi,1),%rax
  823e31:	cmp    $0x5,%rax
  823e35:	mov    $0x4,%r14d
  823e3b:	cmovae %rax,%r14
  823e3f:	mov    0x8(%rdi),%rdx
  823e43:	mov    %rsp,%rdi
  823e46:	mov    $0x4,%r8d
  823e4c:	mov    $0x20,%r9d
  823e52:	mov    %r14,%rcx
  823e55:	call   823e90 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823e5a:	cmpl   $0x1,(%rsp)
  823e5e:	je     823e74 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  823e60:	mov    0x8(%rsp),%rax
  823e65:	mov    %rax,0x8(%rbx)
  823e69:	mov    %r14,(%rbx)
  823e6c:	add    $0x18,%rsp
  823e70:	pop    %rbx
  823e71:	pop    %r14
  823e73:	ret
  823e74:	mov    0x8(%rsp),%rdi
  823e79:	mov    0x10(%rsp),%rsi
  823e7e:	call   *0x65bb6c(%rip)        # e7f9f0 <_DYNAMIC+0x288>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824880 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  824880:	push   %rbp
  824881:	push   %r15
  824883:	push   %r14
  824885:	push   %r13
  824887:	push   %r12
  824889:	push   %rbx
  82488a:	sub    $0x58,%rsp
  82488e:	mov    %ecx,%ebp
  824890:	mov    %rdx,0x8(%rsp)
  824895:	mov    0x18(%rdi),%rax
  824899:	add    %rax,%rsi
  82489c:	jb     8249b1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8248a2:	mov    %rdi,%rbx
  8248a5:	mov    0x8(%rdi),%r15
  8248a9:	lea    0x1(%r15),%rdx
  8248ad:	mov    %rdx,%rdi
  8248b0:	shr    $0x3,%rdi
  8248b4:	mov    %rdx,%rcx
  8248b7:	and    $0xfffffffffffffff8,%rcx
  8248bb:	sub    %rdi,%rcx
  8248be:	cmp    $0x8,%r15
  8248c2:	cmovb  %r15,%rcx
  8248c6:	mov    %rcx,%rdi
  8248c9:	shr    $1,%rdi
  8248cc:	cmp    %rdi,%rsi
  8248cf:	jbe    824900 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  8248d1:	inc    %rcx
  8248d4:	cmp    %rsi,%rcx
  8248d7:	cmovbe %rsi,%rcx
  8248db:	cmp    $0xf,%rcx
  8248df:	mov    %rbx,(%rsp)
  8248e3:	jae    824931 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  8248e5:	mov    %ecx,%eax
  8248e7:	and    $0x8,%eax
  8248ea:	add    $0x8,%rax
  8248ee:	cmp    $0x4,%rcx
  8248f2:	mov    $0x4,%ebx
  8248f7:	cmovae %rax,%rbx
  8248fb:	jmp    824989 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  824900:	test   %rdx,%rdx
  824903:	je     824b8a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  824909:	mov    (%rbx),%rsi
  82490c:	mov    %rdx,%rax
  82490f:	shr    $0x4,%rax
  824913:	mov    %edx,%ecx
  824915:	and    $0xf,%ecx
  824918:	cmp    $0x1,%rcx
  82491c:	sbb    $0xffffffffffffffff,%rax
  824920:	cmp    $0x1,%rax
  824924:	jne    824b91 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  82492a:	xor    %ecx,%ecx
  82492c:	jmp    824be4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  824931:	movabs $0x1ffffffffffffffe,%rax
  82493b:	inc    %rax
  82493e:	cmp    %rax,%rcx
  824941:	ja     8249b1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824943:	shl    $0x3,%rcx
  824947:	movabs $0x2492492492492493,%rdx
  824951:	mov    %rcx,%rax
  824954:	mul    %rdx
  824957:	sub    %rdx,%rcx
  82495a:	shr    $1,%rcx
  82495d:	add    %rdx,%rcx
  824960:	shr    $0x2,%rcx
  824964:	dec    %rcx
  824967:	bsr    %rcx,%rcx
  82496b:	not    %ecx
  82496d:	mov    $0xffffffffffffffff,%rbx
  824974:	shr    %cl,%rbx
  824977:	movabs $0x7fffffffffffffe,%rax
  824981:	cmp    %rax,%rbx
  824984:	ja     8249b1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824986:	inc    %rbx
  824989:	mov    %rbx,%r14
  82498c:	shl    $0x5,%r14
  824990:	lea    0x10(%rbx),%r12
  824994:	mov    %r12,%r13
  824997:	add    %r14,%r13
  82499a:	setb   %al
  82499d:	movabs $0x7ffffffffffffff0,%rcx
  8249a7:	cmp    %rcx,%r13
  8249aa:	seta   %cl
  8249ad:	or     %al,%cl
  8249af:	je     8249c0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  8249b1:	movzbl %bpl,%edi
  8249b5:	call   *0x65b4cd(%rip)        # e7fe88 <_DYNAMIC+0x720>
  8249bb:	jmp    824e05 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8249c0:	call   *0x65b032(%rip)        # e7f9f8 <_DYNAMIC+0x290>
  8249c6:	mov    $0x10,%esi
  8249cb:	mov    %r13,%rdi
  8249ce:	call   *0x65b02c(%rip)        # e7fa00 <_DYNAMIC+0x298>
  8249d4:	test   %rax,%rax
  8249d7:	je     824e23 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  8249dd:	mov    %rax,%r15
  8249e0:	mov    (%rsp),%rcx
  8249e4:	lea    0x20(%rcx),%r13
  8249e8:	add    %r14,%r15
  8249eb:	lea    -0x1(%rbx),%r14
  8249ef:	mov    %rbx,%rax
  8249f2:	shr    $0x3,%rax
  8249f6:	mov    %rbx,%rbp
  8249f9:	and    $0xfffffffffffffff8,%rbp
  8249fd:	sub    %rax,%rbp
  824a00:	cmp    $0x9,%rbx
  824a04:	mov    %rcx,%rbx
  824a07:	cmovb  %r14,%rbp
  824a0b:	mov    %r15,%rdi
  824a0e:	mov    $0xff,%esi
  824a13:	mov    %r12,%rdx
  824a16:	call   *0x65b474(%rip)        # e7fe90 <memset@GLIBC_2.2.5>
  824a1c:	mov    %r14,%rdi
  824a1f:	mov    %r13,0x20(%rsp)
  824a24:	movq   $0x20,0x28(%rsp)
  824a2d:	movq   $0x10,0x30(%rsp)
  824a36:	mov    %r15,0x38(%rsp)
  824a3b:	mov    %r14,0x40(%rsp)
  824a40:	mov    %rbp,0x48(%rsp)
  824a45:	movq   $0x0,0x50(%rsp)
  824a4e:	mov    0x18(%rbx),%r12
  824a52:	test   %r12,%r12
  824a55:	je     824e37 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  824a5b:	mov    %rbp,0x10(%rsp)
  824a60:	mov    (%rbx),%rsi
  824a63:	movdqa (%rsi),%xmm0
  824a67:	pmovmskb %xmm0,%r13d
  824a6c:	not    %r13d
  824a6f:	xor    %ebp,%ebp
  824a71:	mov    %rsi,%r14
  824a74:	mov    %rdi,0x18(%rsp)
  824a79:	nopl   0x0(%rax)
  824a80:	test   %r13w,%r13w
  824a84:	jne    824aaf <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  824a86:	cs nopw 0x0(%rax,%rax,1)
  824a90:	movdqa 0x10(%r14),%xmm0
  824a96:	add    $0x10,%r14
  824a9a:	pmovmskb %xmm0,%r13d
  824a9f:	xor    $0xffff,%r13d
  824aa6:	add    $0x10,%rbp
  824aaa:	test   %r13d,%r13d
  824aad:	je     824a90 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  824aaf:	tzcnt  %r13d,%ebx
  824ab4:	add    %rbp,%rbx
  824ab7:	mov    %rbx,%rax
  824aba:	shl    $0x5,%rax
  824abe:	sub    %rax,%rsi
  824ac1:	add    $0xffffffffffffffe0,%rsi
  824ac5:	mov    0x8(%rsp),%rdi
  824aca:	call   821ef0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  824acf:	mov    %rax,%rdx
  824ad2:	mov    0x18(%rsp),%rdi
  824ad7:	and    %rdi,%rdx
  824ada:	movdqu (%r15,%rdx,1),%xmm0
  824ae0:	pmovmskb %xmm0,%ecx
  824ae4:	test   %ecx,%ecx
  824ae6:	je     824b55 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  824ae8:	tzcnt  %ecx,%ecx
  824aec:	add    %rdx,%rcx
  824aef:	and    %rdi,%rcx
  824af2:	cmpb   $0x0,(%r15,%rcx,1)
  824af7:	jns    824b78 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  824af9:	lea    -0x1(%r13),%edx
  824afd:	and    %r13d,%edx
  824b00:	dec    %r12
  824b03:	shr    $0x39,%rax
  824b07:	lea    -0x10(%rcx),%rsi
  824b0b:	and    %rdi,%rsi
  824b0e:	mov    %al,(%r15,%rcx,1)
  824b12:	mov    %al,0x10(%r15,%rsi,1)
  824b17:	mov    (%rsp),%rax
  824b1b:	mov    (%rax),%rsi
  824b1e:	not    %rbx
  824b21:	shl    $0x5,%rbx
  824b25:	not    %rcx
  824b28:	shl    $0x5,%rcx
  824b2c:	movdqu (%rsi,%rbx,1),%xmm0
  824b31:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  824b37:	movdqu %xmm1,0x10(%r15,%rcx,1)
  824b3e:	movdqu %xmm0,(%r15,%rcx,1)
  824b44:	mov    %edx,%r13d
  824b47:	test   %r12,%r12
  824b4a:	jne    824a80 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  824b50:	jmp    824e14 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  824b55:	mov    $0x10,%esi
  824b5a:	add    %rsi,%rdx
  824b5d:	and    %rdi,%rdx
  824b60:	movdqu (%r15,%rdx,1),%xmm0
  824b66:	pmovmskb %xmm0,%ecx
  824b6a:	add    $0x10,%rsi
  824b6e:	test   %ecx,%ecx
  824b70:	jne    824ae8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  824b76:	jmp    824b5a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  824b78:	movdqa (%r15),%xmm0
  824b7d:	pmovmskb %xmm0,%ecx
  824b81:	tzcnt  %ecx,%ecx
  824b85:	jmp    824af9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  824b8a:	xor    %ecx,%ecx
  824b8c:	jmp    824df7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  824b91:	movabs $0x1ffffffffffffffe,%rdi
  824b9b:	and    %rax,%rdi
  824b9e:	xor    %ecx,%ecx
  824ba0:	movdqa -0x777008(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824ba8:	nopl   0x0(%rax,%rax,1)
  824bb0:	pxor   %xmm1,%xmm1
  824bb4:	pcmpgtb (%rsi,%rcx,1),%xmm1
  824bb9:	por    %xmm0,%xmm1
  824bbd:	movdqa %xmm1,(%rsi,%rcx,1)
  824bc2:	pxor   %xmm1,%xmm1
  824bc6:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  824bcc:	por    %xmm0,%xmm1
  824bd0:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  824bd6:	add    $0x20,%rcx
  824bda:	add    $0xfffffffffffffffe,%rdi
  824bde:	jne    824bb0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  824be0:	test   $0x1,%al
  824be2:	je     824bfa <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  824be4:	pxor   %xmm0,%xmm0
  824be8:	pcmpgtb (%rsi,%rcx,1),%xmm0
  824bed:	por    -0x777055(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824bf5:	movdqa %xmm0,(%rsi,%rcx,1)
  824bfa:	cmp    $0x10,%rdx
  824bfe:	jb     824e88 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  824c04:	mov    %rdx,%rdi
  824c07:	mov    $0x10,%edx
  824c0c:	add    %rsi,%rdi
  824c0f:	call   *0x65b283(%rip)        # e7fe98 <memmove@GLIBC_2.2.5>
  824c15:	movq   $0x0,0x28(%rsp)
  824c1e:	movq   $0x20,0x30(%rsp)
  824c27:	mov    %rbx,0x20(%rsp)
  824c2c:	xor    %r12d,%r12d
  824c2f:	xor    %r13d,%r13d
  824c32:	jmp    824d81 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  824c37:	nopw   0x0(%rax,%rax,1)
  824c40:	lea    (%rax,%rbp,1),%rsi
  824c44:	add    $0xffffffffffffffe0,%rsi
  824c48:	mov    0x8(%rsp),%rdi
  824c4d:	call   821ef0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  824c52:	mov    (%rbx),%rcx
  824c55:	mov    0x8(%rbx),%rdx
  824c59:	mov    %rdx,%rsi
  824c5c:	and    %rax,%rsi
  824c5f:	movdqu (%rcx,%rsi,1),%xmm0
  824c64:	pmovmskb %xmm0,%edi
  824c68:	mov    %rsi,%r8
  824c6b:	test   %edi,%edi
  824c6d:	je     824d19 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  824c73:	tzcnt  %edi,%edi
  824c77:	add    %r8,%rdi
  824c7a:	and    %rdx,%rdi
  824c7d:	cmpb   $0x0,(%rcx,%rdi,1)
  824c81:	jns    824d40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  824c87:	mov    %r12,%r8
  824c8a:	sub    %rsi,%r8
  824c8d:	mov    %rdi,%r9
  824c90:	sub    %rsi,%r9
  824c93:	xor    %r8,%r9
  824c96:	and    %rdx,%r9
  824c99:	cmp    $0x10,%r9
  824c9d:	jb     824d60 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  824ca3:	mov    %rdi,%rsi
  824ca6:	not    %rsi
  824ca9:	shl    $0x5,%rsi
  824cad:	add    %rcx,%rsi
  824cb0:	movzbl (%rcx,%rdi,1),%r8d
  824cb5:	shr    $0x39,%rax
  824cb9:	lea    -0x10(%rdi),%r9
  824cbd:	and    %rdx,%r9
  824cc0:	mov    %al,(%rcx,%rdi,1)
  824cc3:	mov    (%rbx),%rcx
  824cc6:	mov    %al,0x10(%rcx,%r9,1)
  824ccb:	cmp    $0xff,%r8b
  824ccf:	je     824da6 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  824cd5:	mov    (%r14),%rax
  824cd8:	mov    (%rsi),%rcx
  824cdb:	mov    %rcx,(%r14)
  824cde:	mov    %rax,(%rsi)
  824ce1:	mov    0x8(%r14),%rax
  824ce5:	mov    0x8(%rsi),%rcx
  824ce9:	mov    %rcx,0x8(%r14)
  824ced:	mov    %rax,0x8(%rsi)
  824cf1:	mov    0x10(%r14),%rax
  824cf5:	mov    0x10(%rsi),%rcx
  824cf9:	mov    %rcx,0x10(%r14)
  824cfd:	mov    %rax,0x10(%rsi)
  824d01:	mov    0x18(%r14),%rax
  824d05:	mov    0x18(%rsi),%rcx
  824d09:	mov    %rcx,0x18(%r14)
  824d0d:	mov    %rax,0x18(%rsi)
  824d11:	mov    (%rbx),%rax
  824d14:	jmp    824c40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824d19:	mov    $0x10,%r9d
  824d1f:	mov    %rsi,%r8
  824d22:	add    %r9,%r8
  824d25:	and    %rdx,%r8
  824d28:	movdqu (%rcx,%r8,1),%xmm0
  824d2e:	pmovmskb %xmm0,%edi
  824d32:	add    $0x10,%r9
  824d36:	test   %edi,%edi
  824d38:	jne    824c73 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  824d3e:	jmp    824d22 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  824d40:	movdqa (%rcx),%xmm0
  824d44:	pmovmskb %xmm0,%edi
  824d48:	tzcnt  %edi,%edi
  824d4c:	jmp    824c87 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  824d51:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824d60:	shr    $0x39,%rax
  824d64:	lea    -0x10(%r12),%rsi
  824d69:	and    %rsi,%rdx
  824d6c:	mov    %al,(%rcx,%r12,1)
  824d70:	mov    (%rbx),%rcx
  824d73:	mov    %al,0x10(%rcx,%rdx,1)
  824d77:	cmp    %r15,%r12
  824d7a:	lea    0x1(%r12),%r12
  824d7f:	je     824dd5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  824d81:	mov    (%rbx),%rax
  824d84:	cmp    (%rax,%r12,1),%r13b
  824d88:	jno    824d77 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  824d8a:	mov    %r12,%r14
  824d8d:	not    %r14
  824d90:	shl    $0x5,%r14
  824d94:	add    %rax,%r14
  824d97:	mov    %r12,%rbp
  824d9a:	neg    %rbp
  824d9d:	shl    $0x5,%rbp
  824da1:	jmp    824c40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824da6:	lea    -0x10(%r12),%rax
  824dab:	and    0x8(%rbx),%rax
  824daf:	mov    (%rbx),%rcx
  824db2:	movb   $0xff,(%rcx,%r12,1)
  824db7:	mov    (%rbx),%rcx
  824dba:	movb   $0xff,0x10(%rcx,%rax,1)
  824dbf:	movdqu (%r14),%xmm0
  824dc4:	movdqu 0x10(%r14),%xmm1
  824dca:	movdqu %xmm1,0x10(%rsi)
  824dcf:	movdqu %xmm0,(%rsi)
  824dd3:	jmp    824d77 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  824dd5:	mov    0x8(%rbx),%rdx
  824dd9:	mov    0x18(%rbx),%rax
  824ddd:	lea    0x1(%rdx),%rcx
  824de1:	mov    %rcx,%rsi
  824de4:	shr    $0x3,%rsi
  824de8:	and    $0xfffffffffffffff8,%rcx
  824dec:	sub    %rsi,%rcx
  824def:	cmp    $0x8,%rdx
  824df3:	cmovb  %rdx,%rcx
  824df7:	sub    %rax,%rcx
  824dfa:	mov    %rcx,0x10(%rbx)
  824dfe:	mov    $0xffffffffffffffff,%rax
  824e05:	add    $0x58,%rsp
  824e09:	pop    %rbx
  824e0a:	pop    %r12
  824e0c:	pop    %r13
  824e0e:	pop    %r14
  824e10:	pop    %r15
  824e12:	pop    %rbp
  824e13:	ret
  824e14:	mov    (%rsp),%rbx
  824e18:	mov    0x18(%rbx),%rcx
  824e1c:	mov    0x10(%rsp),%rbp
  824e21:	jmp    824e3c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  824e23:	movzbl %bpl,%edi
  824e27:	mov    $0x10,%esi
  824e2c:	mov    %r13,%rdx
  824e2f:	call   *0x65b06b(%rip)        # e7fea0 <_DYNAMIC+0x738>
  824e35:	jmp    824e05 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  824e37:	mov    (%rbx),%rsi
  824e3a:	xor    %ecx,%ecx
  824e3c:	sub    %rcx,%rbp
  824e3f:	mov    %r15,(%rbx)
  824e42:	mov    0x8(%rbx),%rax
  824e46:	mov    %rdi,0x8(%rbx)
  824e4a:	mov    %rbp,0x10(%rbx)
  824e4e:	mov    %rcx,0x18(%rbx)
  824e52:	test   %rax,%rax
  824e55:	je     824dfe <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824e57:	mov    %rax,%rcx
  824e5a:	shl    $0x5,%rcx
  824e5e:	add    $0x2f,%rcx
  824e62:	and    $0xffffffffffffffe0,%rcx
  824e66:	add    %rcx,%rax
  824e69:	add    $0x11,%rax
  824e6d:	je     824dfe <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824e6f:	sub    %rcx,%rsi
  824e72:	mov    $0x10,%edx
  824e77:	mov    %rsi,%rdi
  824e7a:	mov    %rax,%rsi
  824e7d:	call   *0x65ab2d(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  824e83:	jmp    824dfe <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824e88:	mov    $0x10,%edi
  824e8d:	jmp    824c0c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  824e92:	mov    %rax,%rbx
  824e95:	lea    0x20(%rsp),%rdi
  824e9a:	call   825470 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  824e9f:	mov    %rbx,%rdi
  824ea2:	call   e2c520 <_Unwind_Resume@plt>
  824ea7:	mov    %rax,%rbx
  824eaa:	lea    0x20(%rsp),%rdi
  824eaf:	call   8254b0 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  824eb4:	mov    %rbx,%rdi
  824eb7:	call   e2c520 <_Unwind_Resume@plt>
  824ebc:	call   *0x65aaf6(%rip)        # e7f9b8 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824ed0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  824ed0:	push   %rbp
  824ed1:	push   %r15
  824ed3:	push   %r14
  824ed5:	push   %r13
  824ed7:	push   %r12
  824ed9:	push   %rbx
  824eda:	sub    $0x38,%rsp
  824ede:	mov    %ecx,%r15d
  824ee1:	mov    %rdx,0x20(%rsp)
  824ee6:	mov    %rdi,%rbp
  824ee9:	mov    0x18(%rdi),%rdi
  824eed:	add    %rdi,%rsi
  824ef0:	jb     825008 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824ef6:	mov    0x8(%rbp),%rbx
  824efa:	lea    0x1(%rbx),%rdx
  824efe:	mov    %rdx,%rax
  824f01:	shr    $0x3,%rax
  824f05:	mov    %rdx,%rcx
  824f08:	and    $0xfffffffffffffff8,%rcx
  824f0c:	sub    %rax,%rcx
  824f0f:	cmp    $0x8,%rbx
  824f13:	cmovb  %rbx,%rcx
  824f17:	mov    %rcx,%rax
  824f1a:	shr    $1,%rax
  824f1d:	cmp    %rax,%rsi
  824f20:	jbe    824f56 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  824f22:	inc    %rcx
  824f25:	cmp    %rsi,%rcx
  824f28:	cmovbe %rsi,%rcx
  824f2c:	cmp    $0xf,%rcx
  824f30:	mov    %rbp,(%rsp)
  824f34:	mov    %rbx,0x30(%rsp)
  824f39:	jae    824f88 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  824f3b:	mov    %ecx,%eax
  824f3d:	and    $0x8,%eax
  824f40:	add    $0x8,%rax
  824f44:	cmp    $0x4,%rcx
  824f48:	mov    $0x4,%ebx
  824f4d:	cmovae %rax,%rbx
  824f51:	jmp    824fe0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  824f56:	test   %rdx,%rdx
  824f59:	je     82519e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  824f5f:	mov    0x0(%rbp),%r12
  824f63:	mov    %rdx,%rax
  824f66:	shr    $0x4,%rax
  824f6a:	mov    %edx,%ecx
  824f6c:	and    $0xf,%ecx
  824f6f:	cmp    $0x1,%rcx
  824f73:	sbb    $0xffffffffffffffff,%rax
  824f77:	cmp    $0x1,%rax
  824f7b:	jne    8251a5 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  824f81:	xor    %ecx,%ecx
  824f83:	jmp    8251f8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  824f88:	movabs $0x1ffffffffffffffe,%rax
  824f92:	inc    %rax
  824f95:	cmp    %rax,%rcx
  824f98:	ja     825008 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824f9a:	shl    $0x3,%rcx
  824f9e:	movabs $0x2492492492492493,%rdx
  824fa8:	mov    %rcx,%rax
  824fab:	mul    %rdx
  824fae:	sub    %rdx,%rcx
  824fb1:	shr    $1,%rcx
  824fb4:	add    %rdx,%rcx
  824fb7:	shr    $0x2,%rcx
  824fbb:	dec    %rcx
  824fbe:	bsr    %rcx,%rcx
  824fc2:	not    %ecx
  824fc4:	mov    $0xffffffffffffffff,%rbx
  824fcb:	shr    %cl,%rbx
  824fce:	movabs $0xffffffffffffffe,%rax
  824fd8:	cmp    %rax,%rbx
  824fdb:	ja     825008 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824fdd:	inc    %rbx
  824fe0:	mov    %rbx,%r14
  824fe3:	shl    $0x4,%r14
  824fe7:	lea    0x10(%rbx),%rbp
  824feb:	mov    %rbp,%r13
  824fee:	add    %r14,%r13
  824ff1:	setb   %al
  824ff4:	movabs $0x7ffffffffffffff0,%rcx
  824ffe:	cmp    %rcx,%r13
  825001:	seta   %cl
  825004:	or     %al,%cl
  825006:	je     825017 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  825008:	movzbl %r15b,%edi
  82500c:	call   *0x65ae76(%rip)        # e7fe88 <_DYNAMIC+0x720>
  825012:	jmp    8253d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825017:	mov    %rdi,0x8(%rsp)
  82501c:	call   *0x65a9d6(%rip)        # e7f9f8 <_DYNAMIC+0x290>
  825022:	mov    $0x10,%esi
  825027:	mov    %r13,%rdi
  82502a:	call   *0x65a9d0(%rip)        # e7fa00 <_DYNAMIC+0x298>
  825030:	test   %rax,%rax
  825033:	je     8253f2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  825039:	mov    %rax,%rdi
  82503c:	add    %r14,%rdi
  82503f:	lea    -0x1(%rbx),%rcx
  825043:	mov    %rbx,%rax
  825046:	shr    $0x3,%rax
  82504a:	mov    %rbx,%r14
  82504d:	and    $0xfffffffffffffff8,%r14
  825051:	sub    %rax,%r14
  825054:	cmp    $0x9,%rbx
  825058:	mov    %rcx,0x10(%rsp)
  82505d:	cmovb  %rcx,%r14
  825061:	mov    %rdi,0x18(%rsp)
  825066:	mov    $0xff,%esi
  82506b:	mov    %rbp,%rdx
  82506e:	call   *0x65ae1c(%rip)        # e7fe90 <memset@GLIBC_2.2.5>
  825074:	mov    0x8(%rsp),%rbx
  825079:	test   %rbx,%rbx
  82507c:	je     825406 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  825082:	mov    %r14,0x28(%rsp)
  825087:	mov    (%rsp),%rax
  82508b:	mov    (%rax),%rdi
  82508e:	movdqa (%rdi),%xmm0
  825092:	pmovmskb %xmm0,%r14d
  825097:	not    %r14d
  82509a:	xor    %ebp,%ebp
  82509c:	mov    %rdi,%r13
  82509f:	nop
  8250a0:	test   %r14w,%r14w
  8250a4:	jne    8250cf <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  8250a6:	cs nopw 0x0(%rax,%rax,1)
  8250b0:	movdqa 0x10(%r13),%xmm0
  8250b6:	add    $0x10,%r13
  8250ba:	pmovmskb %xmm0,%r14d
  8250bf:	xor    $0xffff,%r14d
  8250c6:	add    $0x10,%rbp
  8250ca:	test   %r14d,%r14d
  8250cd:	je     8250b0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  8250cf:	tzcnt  %r14d,%r15d
  8250d4:	add    %rbp,%r15
  8250d7:	mov    %r15,%rax
  8250da:	shl    $0x4,%rax
  8250de:	mov    %rdi,%r12
  8250e1:	mov    %rdi,%rsi
  8250e4:	sub    %rax,%rsi
  8250e7:	add    $0xfffffffffffffff0,%rsi
  8250eb:	mov    0x20(%rsp),%rdi
  8250f0:	call   822090 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  8250f5:	mov    %rax,%rcx
  8250f8:	mov    0x10(%rsp),%r9
  8250fd:	and    %r9,%rcx
  825100:	mov    0x18(%rsp),%r8
  825105:	movdqu (%r8,%rcx,1),%xmm0
  82510b:	pmovmskb %xmm0,%edx
  82510f:	test   %edx,%edx
  825111:	je     825170 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  825113:	tzcnt  %edx,%edx
  825117:	add    %rcx,%rdx
  82511a:	and    %r9,%rdx
  82511d:	cmpb   $0x0,(%r8,%rdx,1)
  825122:	mov    %r12,%rdi
  825125:	jns    82518f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  825127:	lea    -0x1(%r14),%ecx
  82512b:	and    %r14d,%ecx
  82512e:	dec    %rbx
  825131:	shr    $0x39,%rax
  825135:	lea    -0x10(%rdx),%rsi
  825139:	and    %r9,%rsi
  82513c:	mov    %al,(%r8,%rdx,1)
  825140:	mov    %al,0x10(%r8,%rsi,1)
  825145:	not    %r15
  825148:	shl    $0x4,%r15
  82514c:	not    %rdx
  82514f:	shl    $0x4,%rdx
  825153:	movdqu (%rdi,%r15,1),%xmm0
  825159:	movdqu %xmm0,(%r8,%rdx,1)
  82515f:	mov    %ecx,%r14d
  825162:	test   %rbx,%rbx
  825165:	jne    8250a0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  82516b:	jmp    8253e7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  825170:	mov    $0x10,%esi
  825175:	add    %rsi,%rcx
  825178:	and    %r9,%rcx
  82517b:	movdqu (%r8,%rcx,1),%xmm0
  825181:	pmovmskb %xmm0,%edx
  825185:	add    $0x10,%rsi
  825189:	test   %edx,%edx
  82518b:	jne    825113 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  82518d:	jmp    825175 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  82518f:	movdqa (%r8),%xmm0
  825194:	pmovmskb %xmm0,%ecx
  825198:	tzcnt  %ecx,%edx
  82519c:	jmp    825127 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  82519e:	xor    %eax,%eax
  8251a0:	jmp    8253ca <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  8251a5:	movabs $0x1ffffffffffffffe,%rsi
  8251af:	and    %rax,%rsi
  8251b2:	xor    %ecx,%ecx
  8251b4:	movdqa -0x77761c(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  8251bc:	nopl   0x0(%rax)
  8251c0:	pxor   %xmm1,%xmm1
  8251c4:	pcmpgtb (%r12,%rcx,1),%xmm1
  8251ca:	por    %xmm0,%xmm1
  8251ce:	movdqa %xmm1,(%r12,%rcx,1)
  8251d4:	pxor   %xmm1,%xmm1
  8251d8:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  8251df:	por    %xmm0,%xmm1
  8251e3:	movdqa %xmm1,0x10(%r12,%rcx,1)
  8251ea:	add    $0x20,%rcx
  8251ee:	add    $0xfffffffffffffffe,%rsi
  8251f2:	jne    8251c0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  8251f4:	test   $0x1,%al
  8251f6:	je     825210 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  8251f8:	pxor   %xmm0,%xmm0
  8251fc:	pcmpgtb (%r12,%rcx,1),%xmm0
  825202:	por    -0x77766a(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  82520a:	movdqa %xmm0,(%r12,%rcx,1)
  825210:	cmp    $0x10,%rdx
  825214:	jb     825463 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  82521a:	mov    %rdx,%rdi
  82521d:	mov    $0x10,%edx
  825222:	add    %r12,%rdi
  825225:	mov    %r12,%rsi
  825228:	call   *0x65ac6a(%rip)        # e7fe98 <memmove@GLIBC_2.2.5>
  82522e:	xor    %r13d,%r13d
  825231:	xor    %eax,%eax
  825233:	jmp    825366 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  825238:	nopl   0x0(%rax,%rax,1)
  825240:	lea    (%r12,%r14,1),%rsi
  825244:	add    $0xfffffffffffffff0,%rsi
  825248:	mov    0x20(%rsp),%rdi
  82524d:	call   822090 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  825252:	mov    0x8(%rbp),%rcx
  825256:	mov    %rcx,%rdx
  825259:	and    %rax,%rdx
  82525c:	movdqu (%r12,%rdx,1),%xmm0
  825262:	pmovmskb %xmm0,%esi
  825266:	mov    %rdx,%rdi
  825269:	test   %esi,%esi
  82526b:	je     8252fb <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  825271:	tzcnt  %esi,%esi
  825275:	add    %rdi,%rsi
  825278:	and    %rcx,%rsi
  82527b:	cmpb   $0x0,(%r12,%rsi,1)
  825280:	jns    825322 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  825286:	mov    %r13,%rdi
  825289:	sub    %rdx,%rdi
  82528c:	mov    %rsi,%r8
  82528f:	sub    %rdx,%r8
  825292:	xor    %rdi,%r8
  825295:	and    %rcx,%r8
  825298:	cmp    $0x10,%r8
  82529c:	jb     825340 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  8252a2:	mov    %rsi,%rdx
  8252a5:	not    %rdx
  8252a8:	shl    $0x4,%rdx
  8252ac:	add    %r12,%rdx
  8252af:	movzbl (%r12,%rsi,1),%edi
  8252b4:	shr    $0x39,%rax
  8252b8:	lea    -0x10(%rsi),%r8
  8252bc:	and    %rcx,%r8
  8252bf:	mov    %al,(%r12,%rsi,1)
  8252c3:	mov    0x0(%rbp),%r12
  8252c7:	mov    %al,0x10(%r12,%r8,1)
  8252cc:	cmp    $0xff,%dil
  8252d0:	je     82538b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  8252d6:	mov    (%rbx),%rax
  8252d9:	mov    (%rdx),%rcx
  8252dc:	mov    %rcx,(%rbx)
  8252df:	mov    %rax,(%rdx)
  8252e2:	mov    0x8(%rbx),%rax
  8252e6:	mov    0x8(%rdx),%rcx
  8252ea:	mov    %rcx,0x8(%rbx)
  8252ee:	mov    %rax,0x8(%rdx)
  8252f2:	mov    0x0(%rbp),%r12
  8252f6:	jmp    825240 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  8252fb:	mov    $0x10,%r8d
  825301:	mov    %rdx,%rdi
  825304:	add    %r8,%rdi
  825307:	and    %rcx,%rdi
  82530a:	movdqu (%r12,%rdi,1),%xmm0
  825310:	pmovmskb %xmm0,%esi
  825314:	add    $0x10,%r8
  825318:	test   %esi,%esi
  82531a:	jne    825271 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  825320:	jmp    825304 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  825322:	movdqa (%r12),%xmm0
  825328:	pmovmskb %xmm0,%esi
  82532c:	tzcnt  %esi,%esi
  825330:	jmp    825286 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  825335:	data16 cs nopw 0x0(%rax,%rax,1)
  825340:	shr    $0x39,%rax
  825344:	lea    -0x10(%r13),%rdx
  825348:	and    %rdx,%rcx
  82534b:	mov    %al,(%r12,%r13,1)
  82534f:	mov    0x0(%rbp),%r12
  825353:	mov    %al,0x10(%r12,%rcx,1)
  825358:	mov    %r15,%rbx
  82535b:	xor    %eax,%eax
  82535d:	cmp    %rbx,%r13
  825360:	lea    0x1(%r13),%r13
  825364:	je     8253a8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  825366:	cmp    (%r12,%r13,1),%al
  82536a:	jno    82535d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  82536c:	mov    %rbx,%r15
  82536f:	mov    %r13,%rbx
  825372:	not    %rbx
  825375:	shl    $0x4,%rbx
  825379:	add    %r12,%rbx
  82537c:	mov    %r13,%r14
  82537f:	neg    %r14
  825382:	shl    $0x4,%r14
  825386:	jmp    825240 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  82538b:	lea    -0x10(%r13),%rax
  82538f:	and    0x8(%rbp),%rax
  825393:	movb   $0xff,(%r12,%r13,1)
  825398:	movb   $0xff,0x10(%r12,%rax,1)
  82539e:	movdqu (%rbx),%xmm0
  8253a2:	movdqu %xmm0,(%rdx)
  8253a6:	jmp    825358 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  8253a8:	mov    0x8(%rbp),%rcx
  8253ac:	mov    0x18(%rbp),%rdi
  8253b0:	lea    0x1(%rcx),%rax
  8253b4:	mov    %rax,%rdx
  8253b7:	shr    $0x3,%rdx
  8253bb:	and    $0xfffffffffffffff8,%rax
  8253bf:	sub    %rdx,%rax
  8253c2:	cmp    $0x8,%rcx
  8253c6:	cmovb  %rcx,%rax
  8253ca:	sub    %rdi,%rax
  8253cd:	mov    %rax,0x10(%rbp)
  8253d1:	mov    $0xffffffffffffffff,%rax
  8253d8:	add    $0x38,%rsp
  8253dc:	pop    %rbx
  8253dd:	pop    %r12
  8253df:	pop    %r13
  8253e1:	pop    %r14
  8253e3:	pop    %r15
  8253e5:	pop    %rbp
  8253e6:	ret
  8253e7:	mov    (%rsp),%rax
  8253eb:	mov    0x28(%rsp),%r14
  8253f0:	jmp    825417 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  8253f2:	movzbl %r15b,%edi
  8253f6:	mov    $0x10,%esi
  8253fb:	mov    %r13,%rdx
  8253fe:	call   *0x65aa9c(%rip)        # e7fea0 <_DYNAMIC+0x738>
  825404:	jmp    8253d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825406:	mov    (%rsp),%rax
  82540a:	mov    (%rax),%rdi
  82540d:	mov    0x18(%rsp),%r8
  825412:	mov    0x10(%rsp),%r9
  825417:	sub    0x8(%rsp),%r14
  82541c:	mov    %r8,(%rax)
  82541f:	mov    %r9,0x8(%rax)
  825423:	mov    %r14,0x10(%rax)
  825427:	mov    $0xffffffffffffffff,%rax
  82542e:	mov    0x30(%rsp),%rsi
  825433:	test   %rsi,%rsi
  825436:	je     8253d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825438:	mov    %rsi,%rcx
  82543b:	shl    $0x4,%rcx
  82543f:	add    $0x1f,%rcx
  825443:	and    $0xfffffffffffffff0,%rcx
  825447:	add    %rcx,%rsi
  82544a:	add    $0x11,%rsi
  82544e:	je     8253d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825450:	sub    %rcx,%rdi
  825453:	mov    $0x10,%edx
  825458:	call   *0x65a552(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  82545e:	jmp    8253d1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  825463:	mov    $0x10,%edi
  825468:	jmp    825222 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825620 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  825620:	mov    0x8(%rdi),%rsi
  825624:	test   %rsi,%rsi
  825627:	je     82564e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  825629:	mov    %rsi,%rax
  82562c:	shl    $0x5,%rax
  825630:	add    %rax,%rsi
  825633:	add    $0x31,%rsi
  825637:	je     82564e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  825639:	mov    (%rdi),%rdi
  82563c:	sub    %rax,%rdi
  82563f:	add    $0xffffffffffffffe0,%rdi
  825643:	mov    $0x10,%edx
  825648:	jmp    *0x65a362(%rip)        # e7f9b0 <_DYNAMIC+0x248>
  82564e:	ret

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825aa0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  825aa0:	push   %r15
  825aa2:	push   %r14
  825aa4:	push   %rbx
  825aa5:	mov    (%rdx),%r9
  825aa8:	mov    0x8(%rdx),%r11
  825aac:	mov    0x10(%rdx),%rbx
  825ab0:	mov    0x18(%rdx),%r10
  825ab4:	mov    0x20(%rdx),%r8
  825ab8:	mov    0x28(%rdx),%rcx
  825abc:	test   $0x1,%r9b
  825ac0:	jne    825b5a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  825ac6:	mov    %rbx,%rax
  825ac9:	jmp    825aeb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  825acb:	nopl   0x0(%rax,%rax,1)
  825ad0:	lea    0x8(%rax),%rbx
  825ad4:	mov    %rbx,%r14
  825ad7:	add    $0x8,%rdi
  825adb:	mov    (%rax),%r15
  825ade:	mov    %r14,%rax
  825ae1:	cmp    0x28(%r15),%rdx
  825ae5:	jne    825baf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825aeb:	cmp    %rsi,%rdi
  825aee:	je     825b88 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  825af4:	mov    (%rdi),%rdx
  825af7:	test   %rax,%rax
  825afa:	je     825b03 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  825afc:	cmp    %r10,%rax
  825aff:	jne    825ad0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  825b01:	xor    %ebx,%ebx
  825b03:	xor    %eax,%eax
  825b05:	test   %r8,%r8
  825b08:	je     825bb1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825b0e:	cmp    %rcx,%r8
  825b11:	je     825bb1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825b17:	mov    %r8,%rax
  825b1a:	add    $0x8,%r8
  825b1e:	xor    %r14d,%r14d
  825b21:	jmp    825ad7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  825b23:	mov    (%r11),%rax
  825b26:	mov    0x8(%rax),%rbx
  825b2a:	mov    0x10(%rax),%rax
  825b2e:	lea    (%rbx,%rax,8),%r10
  825b32:	test   %rax,%rax
  825b35:	je     825b71 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  825b37:	xor    %r11d,%r11d
  825b3a:	nopw   0x0(%rax,%rax,1)
  825b40:	mov    %r8,%rax
  825b43:	mov    %rbx,%r8
  825b46:	add    $0x8,%rbx
  825b4a:	add    $0x8,%rdi
  825b4e:	mov    (%r8),%r14
  825b51:	mov    %rax,%r8
  825b54:	cmp    0x28(%r14),%rdx
  825b58:	jne    825baf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825b5a:	cmp    %rsi,%rdi
  825b5d:	je     825b88 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  825b5f:	mov    (%rdi),%rdx
  825b62:	test   %rbx,%rbx
  825b65:	je     825b6c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  825b67:	cmp    %r10,%rbx
  825b6a:	jne    825b40 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  825b6c:	test   %r11,%r11
  825b6f:	jne    825b23 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  825b71:	xor    %eax,%eax
  825b73:	test   %r8,%r8
  825b76:	je     825bb1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825b78:	cmp    %rcx,%r8
  825b7b:	je     825bb1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825b7d:	lea    0x8(%r8),%rax
  825b81:	xor    %ebx,%ebx
  825b83:	xor    %r11d,%r11d
  825b86:	jmp    825b4a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  825b88:	test   %rbx,%rbx
  825b8b:	sete   %dl
  825b8e:	cmp    %r10,%rbx
  825b91:	sete   %al
  825b94:	or     %dl,%al
  825b96:	test   $0x1,%r9b
  825b9a:	je     825bb7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  825b9c:	test   %al,%al
  825b9e:	je     825baf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825ba0:	test   %r11,%r11
  825ba3:	je     825bbb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  825ba5:	mov    (%r11),%rax
  825ba8:	cmpq   $0x0,0x10(%rax)
  825bad:	je     825bbb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  825baf:	xor    %eax,%eax
  825bb1:	pop    %rbx
  825bb2:	pop    %r14
  825bb4:	pop    %r15
  825bb6:	ret
  825bb7:	test   %al,%al
  825bb9:	je     825baf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825bbb:	test   %r8,%r8
  825bbe:	sete   %dl
  825bc1:	cmp    %rcx,%r8
  825bc4:	sete   %al
  825bc7:	or     %dl,%al
  825bc9:	pop    %rbx
  825bca:	pop    %r14
  825bcc:	pop    %r15
  825bce:	ret

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825bd0 <gpui_gpu::renderer::slots::color_word>:
  825bd0:	lea    -0x3(%rsi),%eax
  825bd3:	cmp    %rax,%rdi
  825bd6:	jbe    825bef <gpui_gpu::renderer::slots::color_word+0x1f>
  825bd8:	mov    %rdi,%rax
  825bdb:	shr    $0x6,%rax
  825bdf:	and    $0x3f,%edi
  825be2:	cmp    $0x1,%rdi
  825be6:	sbb    $0xffffffff,%eax
  825be9:	add    %esi,%eax
  825beb:	add    $0xfffffffe,%eax
  825bee:	ret
  825bef:	push   %rax
  825bf0:	lea    -0x750c2e(%rip),%rdi        # d4fc9 <anon.4f92784177f891c02fc0a44bfee03ec4.9.llvm.6639503288718533278>
  825bf7:	lea    0x60888a(%rip),%rdx        # e2e488 <anon.4f92784177f891c02fc0a44bfee03ec4.10.llvm.6639503288718533278>
  825bfe:	mov    $0x1e,%esi
  825c03:	call   *0x65a0c7(%rip)        # e7fcd0 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=517 frame=72

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825c10 <gpui_gpu::renderer::slots::write_prefix>:
  825c10:	push   %rbp
  825c11:	push   %r15
  825c13:	push   %r14
  825c15:	push   %r13
  825c17:	push   %r12
  825c19:	push   %rbx
  825c1a:	sub    $0x18,%rsp
  825c1e:	test   %rdx,%rdx
  825c21:	je     825dbc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825c27:	mov    %rdi,%rbx
  825c2a:	mov    %rdx,%rax
  825c2d:	shr    $0x6,%rax
  825c31:	xor    %ecx,%ecx
  825c33:	test   $0x3f,%dl
  825c36:	setne  %cl
  825c39:	lea    (%rax,%rcx,1),%rbp
  825c3d:	lea    (%rax,%rcx,1),%r8
  825c41:	inc    %r8
  825c44:	mov    0x10(%rdi),%r12
  825c48:	mov    %rbp,%r13
  825c4b:	sub    %r12,%r13
  825c4e:	jae    825c5c <gpui_gpu::renderer::slots::write_prefix+0x4c>
  825c50:	mov    0x8(%rbx),%rax
  825c54:	mov    %r8,%r14
  825c57:	jmp    825cfb <gpui_gpu::renderer::slots::write_prefix+0xeb>
  825c5c:	mov    %r8,%r15
  825c5f:	sub    %r12,%r15
  825c62:	mov    (%rbx),%rax
  825c65:	sub    %r12,%rax
  825c68:	mov    %r12,%r14
  825c6b:	cmp    %rax,%r15
  825c6e:	ja     825dcb <gpui_gpu::renderer::slots::write_prefix+0x1bb>
  825c74:	mov    0x8(%rbx),%rax
  825c78:	mov    %r14,%rcx
  825c7b:	shl    $0x4,%rcx
  825c7f:	add    %rax,%rcx
  825c82:	cmp    $0x2,%r15
  825c86:	jb     825cf2 <gpui_gpu::renderer::slots::write_prefix+0xe2>
  825c88:	mov    %r13d,%edi
  825c8b:	and    $0x7,%edi
  825c8e:	sub    %rbp,%r12
  825c91:	cmp    $0xfffffffffffffff8,%r12
  825c95:	ja     825cce <gpui_gpu::renderer::slots::write_prefix+0xbe>
  825c97:	and    $0xfffffffffffffff8,%r13
  825c9b:	xorps  %xmm0,%xmm0
  825c9e:	xchg   %ax,%ax
  825ca0:	movups %xmm0,(%rcx)
  825ca3:	movups %xmm0,0x10(%rcx)
  825ca7:	movups %xmm0,0x20(%rcx)
  825cab:	movups %xmm0,0x30(%rcx)
  825caf:	movups %xmm0,0x40(%rcx)
  825cb3:	movups %xmm0,0x50(%rcx)
  825cb7:	movups %xmm0,0x60(%rcx)
  825cbb:	movups %xmm0,0x70(%rcx)
  825cbf:	sub    $0xffffffffffffff80,%rcx
  825cc3:	add    $0xfffffffffffffff8,%r13
  825cc7:	jne    825ca0 <gpui_gpu::renderer::slots::write_prefix+0x90>
  825cc9:	test   %rdi,%rdi
  825ccc:	je     825cec <gpui_gpu::renderer::slots::write_prefix+0xdc>
  825cce:	xorps  %xmm0,%xmm0
  825cd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  825ce0:	movups %xmm0,(%rcx)
  825ce3:	add    $0x10,%rcx
  825ce7:	dec    %rdi
  825cea:	jne    825ce0 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  825cec:	add    %r15,%r14
  825cef:	dec    %r14
  825cf2:	xorps  %xmm0,%xmm0
  825cf5:	movups %xmm0,(%rcx)
  825cf8:	inc    %r14
  825cfb:	mov    %r14,0x10(%rbx)
  825cff:	mov    %edx,(%rax)
  825d01:	mov    %ebp,0x4(%rax)
  825d04:	mov    %r8d,0x8(%rax)
  825d08:	movl   $0x0,0xc(%rax)
  825d0f:	mov    %rsi,%rdi
  825d12:	call   *0x659ff8(%rip)        # e7fd10 <_DYNAMIC+0x5a8>
  825d18:	cmp    %rdx,%rax
  825d1b:	je     825dbc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825d21:	mov    %rax,%r15
  825d24:	mov    %rdx,%r12
  825d27:	xor    %r13d,%r13d
  825d2a:	xor    %ebp,%ebp
  825d2c:	jmp    825d56 <gpui_gpu::renderer::slots::write_prefix+0x146>
  825d2e:	xchg   %ax,%ax
  825d30:	mov    0x8(%rbx),%rax
  825d34:	mov    %r14,%rcx
  825d37:	shl    $0x4,%rcx
  825d3b:	movups %xmm0,(%rax,%rcx,1)
  825d3f:	inc    %r14
  825d42:	mov    %r14,0x10(%rbx)
  825d46:	add    $0x2,%r13d
  825d4a:	add    $0x18,%r15
  825d4e:	inc    %rbp
  825d51:	cmp    %r12,%r15
  825d54:	je     825dbc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825d56:	mov    %rbp,%rdi
  825d59:	shr    $0x6,%rdi
  825d5d:	inc    %rdi
  825d60:	cmp    %r14,%rdi
  825d63:	jae    825e05 <gpui_gpu::renderer::slots::write_prefix+0x1f5>
  825d69:	movups (%r15),%xmm0
  825d6d:	movzwl 0x12(%r15),%eax
  825d72:	movzwl 0x10(%r15),%edx
  825d77:	shr    $0xe,%eax
  825d7a:	and    $0x2,%eax
  825d7d:	shr    $0xf,%edx
  825d80:	or     %eax,%edx
  825d82:	mov    %r13d,%ecx
  825d85:	and    $0x1e,%cl
  825d88:	shl    %cl,%edx
  825d8a:	shl    $0x4,%rdi
  825d8e:	add    0x8(%rbx),%rdi
  825d92:	mov    %ebp,%eax
  825d94:	shr    $0x2,%eax
  825d97:	and    $0xc,%eax
  825d9a:	or     %edx,(%rax,%rdi,1)
  825d9d:	mov    0x10(%rbx),%r14
  825da1:	cmp    (%rbx),%r14
  825da4:	jne    825d30 <gpui_gpu::renderer::slots::write_prefix+0x120>
  825da6:	mov    %rbx,%rdi
  825da9:	movaps %xmm0,(%rsp)
  825dad:	call   *0x65a0bd(%rip)        # e7fe70 <_DYNAMIC+0x708>
  825db3:	movaps (%rsp),%xmm0
  825db7:	jmp    825d30 <gpui_gpu::renderer::slots::write_prefix+0x120>
  825dbc:	add    $0x18,%rsp
  825dc0:	pop    %rbx
  825dc1:	pop    %r12
  825dc3:	pop    %r13
  825dc5:	pop    %r14
  825dc7:	pop    %r15
  825dc9:	pop    %rbp
  825dca:	ret
  825dcb:	mov    $0x4,%ecx
  825dd0:	mov    %r8,0x10(%rsp)
  825dd5:	mov    $0x10,%r8d
  825ddb:	mov    %rbx,%rdi
  825dde:	mov    %rsi,(%rsp)
  825de2:	mov    %r12,%rsi
  825de5:	mov    %rdx,%r14
  825de8:	mov    %r15,%rdx
  825deb:	call   823c20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  825df0:	mov    0x10(%rsp),%r8
  825df5:	mov    %r14,%rdx
  825df8:	mov    (%rsp),%rsi
  825dfc:	mov    0x10(%rbx),%r14
  825e00:	jmp    825c74 <gpui_gpu::renderer::slots::write_prefix+0x64>
  825e05:	lea    0x608694(%rip),%rdx        # e2e4a0 <anon.4f92784177f891c02fc0a44bfee03ec4.12.llvm.6639503288718533278>
  825e0c:	mov    %r14,%rsi
  825e0f:	call   *0x659e4b(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
