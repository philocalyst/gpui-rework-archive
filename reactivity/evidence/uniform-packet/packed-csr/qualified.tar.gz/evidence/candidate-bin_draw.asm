
FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4056 frame=792

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820600 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820600:	push   %rbp
  820601:	push   %r15
  820603:	push   %r14
  820605:	push   %r13
  820607:	push   %r12
  820609:	push   %rbx
  82060a:	sub    $0x2e8,%rsp
  820611:	movss  0x88(%rdx),%xmm3
  820619:	movss  -0x771665(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820621:	movaps %xmm3,%xmm1
  820624:	subss  %xmm0,%xmm1
  820628:	cvttss2si %xmm1,%rax
  82062d:	cvttss2si %xmm3,%r10
  820632:	mov    %r10,%r13
  820635:	sar    $0x3f,%r13
  820639:	and    %rax,%r13
  82063c:	or     %r10,%r13
  82063f:	xor    %eax,%eax
  820641:	xorps  %xmm1,%xmm1
  820644:	ucomiss %xmm1,%xmm3
  820647:	cmovb  %rax,%r13
  82064b:	movss  0x90(%rdx),%xmm4
  820653:	movss  -0x77169b(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82065b:	ucomiss %xmm2,%xmm3
  82065e:	mov    $0xffffffffffffffff,%r14
  820665:	cmova  %r14,%r13
  820669:	movaps %xmm4,%xmm3
  82066c:	subss  %xmm0,%xmm3
  820670:	cvttss2si %xmm3,%r10
  820675:	cvttss2si %xmm4,%r11
  82067a:	mov    %r11,%rbx
  82067d:	sar    $0x3f,%rbx
  820681:	and    %r10,%rbx
  820684:	or     %r11,%rbx
  820687:	ucomiss %xmm1,%xmm4
  82068a:	cmovb  %rax,%rbx
  82068e:	ucomiss %xmm2,%xmm4
  820691:	cmova  %r14,%rbx
  820695:	movss  0x8c(%rdx),%xmm3
  82069d:	lea    (%rbx,%r13,1),%r11
  8206a1:	dec    %r11
  8206a4:	shr    $0x4,%r11
  8206a8:	shr    $0x4,%r13
  8206ac:	mov    %r11,%rbp
  8206af:	sub    %r13,%rbp
  8206b2:	inc    %rbp
  8206b5:	movaps %xmm3,%xmm4
  8206b8:	subss  %xmm0,%xmm4
  8206bc:	cvttss2si %xmm4,%r10
  8206c1:	cvttss2si %xmm3,%r15
  8206c6:	mov    %r15,%rbx
  8206c9:	sar    $0x3f,%rbx
  8206cd:	and    %r10,%rbx
  8206d0:	or     %r15,%rbx
  8206d3:	ucomiss %xmm1,%xmm3
  8206d6:	cmovb  %rax,%rbx
  8206da:	ucomiss %xmm2,%xmm3
  8206dd:	movss  0x94(%rdx),%xmm3
  8206e5:	cmova  %r14,%rbx
  8206e9:	movaps %xmm3,%xmm4
  8206ec:	subss  %xmm0,%xmm4
  8206f0:	cvttss2si %xmm4,%r10
  8206f5:	cvttss2si %xmm3,%r15
  8206fa:	mov    %r15,%r12
  8206fd:	sar    $0x3f,%r12
  820701:	and    %r10,%r12
  820704:	or     %r15,%r12
  820707:	ucomiss %xmm1,%xmm3
  82070a:	cmovb  %rax,%r12
  82070e:	ucomiss %xmm2,%xmm3
  820711:	cmova  %r14,%r12
  820715:	lea    (%rbx,%r12,1),%r10
  820719:	dec    %r10
  82071c:	shr    $0x4,%r10
  820720:	shr    $0x4,%rbx
  820724:	mov    %r10,%r14
  820727:	sub    %rbx,%r14
  82072a:	inc    %r14
  82072d:	imul   %rbp,%r14
  820731:	add    0x330(%rsp),%r14
  820739:	setb   %al
  82073c:	cmp    $0x400001,%r14
  820743:	setae  %bpl
  820747:	or     %al,%bpl
  82074a:	mov    $0x6,%eax
  82074f:	jne    82078f <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  820751:	mov    %r8d,0xac(%rsp)
  820759:	mov    %r14,0x170(%rsp)
  820761:	mov    %rdi,0x178(%rsp)
  820769:	mov    %r13,0xa0(%rsp)
  820771:	cmp    %rbx,%r10
  820774:	jae    8207a3 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  820776:	mov    0x178(%rsp),%rdi
  82077e:	mov    0x170(%rsp),%rax
  820786:	mov    %rax,0x8(%rdi)
  82078a:	mov    $0xffffffff,%eax
  82078f:	mov    %eax,(%rdi)
  820791:	add    $0x2e8,%rsp
  820798:	pop    %rbx
  820799:	pop    %r12
  82079b:	pop    %r13
  82079d:	pop    %r14
  82079f:	pop    %r15
  8207a1:	pop    %rbp
  8207a2:	ret
  8207a3:	cmp    0xa0(%rsp),%r11
  8207ab:	jae    8207c6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  8207ad:	nopl   (%rax)
  8207b0:	mov    %rbx,%rax
  8207b3:	cmp    %r10,%rbx
  8207b6:	adc    $0x0,%rbx
  8207ba:	cmp    %r10,%rax
  8207bd:	jae    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8207bf:	cmp    %r10,%rbx
  8207c2:	jbe    8207b0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  8207c4:	jmp    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8207c6:	movd   0xa4(%rdx),%xmm0
  8207ce:	mov    0x20(%rsi),%r12
  8207d2:	movdqu 0x98(%rdx),%xmm1
  8207da:	movd   0xa0(%rdx),%xmm2
  8207e2:	punpckldq %xmm0,%xmm2
  8207e6:	punpcklqdq %xmm2,%xmm1
  8207ea:	movdqa -0x773ee2(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  8207f2:	pand   %xmm1,%xmm2
  8207f6:	paddd  -0x773c8e(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  8207fe:	pxor   -0x7724d6(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  820806:	pcmpgtd -0x77307e(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  82080e:	mov    %rsi,%rax
  820811:	mov    0x28(%rsi),%rsi
  820815:	pandn  %xmm1,%xmm2
  820819:	movmskps %xmm2,%edi
  82081c:	test   %edi,%edi
  82081e:	jne    821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820824:	ucomiss -0x771aab(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82082b:	jne    821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820831:	jp     821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820837:	cmpb   $0x0,0x328(%rax)
  82083e:	je     821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820844:	cmpb   $0x0,(%rdx)
  820847:	jne    821544 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  82084d:	test   %r9,%r9
  820850:	je     8215bb <<gpui_gpu::renderer::RendererState>::bin_draw+0xfbb>
  820856:	mov    0x328(%rsp),%ebp
  82085d:	mov    0x320(%rsp),%r13d
  820865:	movd   %ecx,%xmm2
  820869:	shr    $0x20,%rcx
  82086d:	movss  0x78(%rdx),%xmm0
  820872:	movss  0x80(%rdx),%xmm3
  82087a:	movss  0x84(%rdx),%xmm4
  820882:	cvtss2sd %xmm0,%xmm0
  820886:	movss  0x7c(%rdx),%xmm1
  82088b:	cvtss2sd %xmm1,%xmm1
  82088f:	cvtss2sd %xmm3,%xmm14
  820894:	addsd  %xmm0,%xmm14
  820899:	xorps  %xmm3,%xmm3
  82089c:	cvtss2sd %xmm4,%xmm3
  8208a0:	addsd  %xmm1,%xmm3
  8208a4:	movsd  %xmm3,0x1a8(%rsp)
  8208ad:	movsd  0x48(%rdx),%xmm6
  8208b2:	movsd  0x58(%rdx),%xmm7
  8208b7:	movsd  0x68(%rdx),%xmm8
  8208bd:	movss  0x38(%rdx),%xmm3
  8208c2:	movss  0x3c(%rdx),%xmm4
  8208c7:	movss  0x40(%rdx),%xmm5
  8208cc:	cvtss2sd %xmm3,%xmm3
  8208d0:	cvtss2sd %xmm5,%xmm5
  8208d4:	movaps -0x775b2c(%rip),%xmm9        # aadb0 <GCC_except_table0+0xb8>
  8208dc:	movaps %xmm3,0x80(%rsp)
  8208e4:	andps  %xmm9,%xmm3
  8208e8:	movaps %xmm3,0x70(%rsp)
  8208ed:	movaps %xmm5,0x50(%rsp)
  8208f2:	cvtss2sd %xmm2,%xmm2
  8208f6:	movsd  %xmm2,0x8(%rsp)
  8208fc:	andps  %xmm9,%xmm5
  820900:	movaps %xmm5,0x60(%rsp)
  820905:	movaps %xmm6,%xmm2
  820908:	andps  %xmm9,%xmm2
  82090c:	movaps %xmm2,0x250(%rsp)
  820914:	movaps %xmm7,%xmm2
  820917:	andps  %xmm9,%xmm2
  82091b:	movaps %xmm2,0x230(%rsp)
  820923:	xorps  %xmm3,%xmm3
  820926:	cvtss2sd %xmm4,%xmm3
  82092a:	movaps %xmm8,%xmm2
  82092e:	andps  %xmm9,%xmm2
  820932:	movaps %xmm2,0xf0(%rsp)
  82093a:	movss  0x44(%rdx),%xmm2
  82093f:	cvtss2sd %xmm2,%xmm2
  820943:	movaps %xmm3,0x40(%rsp)
  820948:	andps  %xmm9,%xmm3
  82094c:	movaps %xmm3,0x30(%rsp)
  820951:	movaps %xmm2,0x10(%rsp)
  820956:	andps  %xmm9,%xmm2
  82095a:	movaps %xmm2,0x20(%rsp)
  82095f:	movd   %ecx,%xmm2
  820963:	cvtss2sd %xmm2,%xmm2
  820967:	movsd  %xmm2,(%rsp)
  82096c:	movsd  0x50(%rdx),%xmm2
  820971:	movaps %xmm2,%xmm3
  820974:	andps  %xmm9,%xmm3
  820978:	movaps %xmm3,0x1d0(%rsp)
  820980:	movsd  0x60(%rdx),%xmm3
  820985:	movaps %xmm3,%xmm4
  820988:	andps  %xmm9,%xmm4
  82098c:	movaps %xmm4,0x1b0(%rsp)
  820994:	movsd  0x70(%rdx),%xmm4
  820999:	movaps %xmm4,%xmm5
  82099c:	andps  %xmm9,%xmm5
  8209a0:	movaps %xmm5,0xb0(%rsp)
  8209a8:	movaps %xmm2,0x1e0(%rsp)
  8209b0:	cvtsd2ss %xmm2,%xmm2
  8209b4:	xorps  %xmm5,%xmm5
  8209b7:	cvtss2sd %xmm2,%xmm5
  8209bb:	movaps %xmm6,0x260(%rsp)
  8209c3:	movaps %xmm6,%xmm2
  8209c6:	movaps %xmm7,0x240(%rsp)
  8209ce:	movlhps %xmm7,%xmm2
  8209d1:	cvtpd2ps %xmm2,%xmm2
  8209d5:	cvtps2pd %xmm2,%xmm6
  8209d8:	movaps %xmm3,0x1c0(%rsp)
  8209e0:	xorps  %xmm2,%xmm2
  8209e3:	cvtsd2ss %xmm3,%xmm2
  8209e7:	xorps  %xmm3,%xmm3
  8209ea:	cvtss2sd %xmm2,%xmm3
  8209ee:	movaps %xmm8,0x100(%rsp)
  8209f7:	xorps  %xmm2,%xmm2
  8209fa:	cvtsd2ss %xmm8,%xmm2
  8209ff:	xorps  %xmm7,%xmm7
  820a02:	cvtss2sd %xmm2,%xmm7
  820a06:	movaps %xmm4,0xc0(%rsp)
  820a0e:	xorps  %xmm2,%xmm2
  820a11:	cvtsd2ss %xmm4,%xmm2
  820a15:	cvtss2sd %xmm2,%xmm2
  820a19:	movaps %xmm6,%xmm4
  820a1c:	andps  %xmm9,%xmm4
  820a20:	movaps %xmm7,0x120(%rsp)
  820a28:	andps  %xmm9,%xmm7
  820a2c:	movaps %xmm7,0x110(%rsp)
  820a34:	movaps %xmm5,0x220(%rsp)
  820a3c:	andps  %xmm9,%xmm5
  820a40:	movaps %xmm5,0x210(%rsp)
  820a48:	movaps %xmm3,0x200(%rsp)
  820a50:	andps  %xmm9,%xmm3
  820a54:	movaps %xmm3,0x1f0(%rsp)
  820a5c:	movaps %xmm2,0xd0(%rsp)
  820a64:	andps  %xmm2,%xmm9
  820a68:	movaps %xmm9,0xe0(%rsp)
  820a71:	movaps %xmm6,0x280(%rsp)
  820a79:	movhlps %xmm6,%xmm6
  820a7c:	movaps %xmm6,0x2b0(%rsp)
  820a84:	movaps %xmm4,0x270(%rsp)
  820a8c:	movhlps %xmm4,%xmm4
  820a8f:	movaps %xmm4,0x2a0(%rsp)
  820a97:	mov    %r10,0x198(%rsp)
  820a9f:	movsd  %xmm14,0x98(%rsp)
  820aa9:	nopl   0x0(%rax)
  820ab0:	mov    %rbx,%r15
  820ab3:	cmp    %r10,%rbx
  820ab6:	adc    $0x0,%rbx
  820aba:	mov    %r15,0x1a0(%rsp)
  820ac2:	imul   %r9,%r15
  820ac6:	mov    0xa0(%rsp),%rdi
  820ace:	mov    %rdi,%r8
  820ad1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820ae0:	cmp    %r11,%rdi
  820ae3:	adc    $0x0,%r8
  820ae7:	lea    (%rdi,%r15,1),%rcx
  820aeb:	mov    %rcx,%rax
  820aee:	shr    $0x20,%rax
  820af2:	je     820b00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x500>
  820af4:	mov    %rcx,%rax
  820af7:	xor    %edx,%edx
  820af9:	div    %r9
  820afc:	jmp    820b07 <<gpui_gpu::renderer::RendererState>::bin_draw+0x507>
  820afe:	xchg   %ax,%ax
  820b00:	mov    %ecx,%eax
  820b02:	xor    %edx,%edx
  820b04:	div    %r9d
  820b07:	shl    $0x4,%edx
  820b0a:	shl    $0x4,%eax
  820b0d:	lea    0x10(%rdx),%r10d
  820b11:	cmp    %r10d,%r13d
  820b14:	cmovb  %r13d,%r10d
  820b18:	lea    0x10(%rax),%r14d
  820b1c:	cmp    %r14d,%ebp
  820b1f:	cmovb  %ebp,%r14d
  820b23:	xorps  %xmm12,%xmm12
  820b27:	cvtsi2sd %edx,%xmm12
  820b2c:	ucomisd %xmm12,%xmm0
  820b31:	ja     820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b33:	mov    %eax,%eax
  820b35:	xorps  %xmm2,%xmm2
  820b38:	cvtsi2sd %rax,%xmm2
  820b3d:	ucomisd %xmm2,%xmm1
  820b41:	ja     820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b43:	xorps  %xmm6,%xmm6
  820b46:	cvtsi2sd %r10d,%xmm6
  820b4b:	ucomisd %xmm14,%xmm6
  820b50:	ja     820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820b52:	xorps  %xmm13,%xmm13
  820b56:	cvtsi2sd %r14d,%xmm13
  820b5b:	ucomisd 0x1a8(%rsp),%xmm13
  820b65:	jbe    820b98 <<gpui_gpu::renderer::RendererState>::bin_draw+0x598>
  820b67:	nopw   0x0(%rax,%rax,1)
  820b70:	cmp    %rsi,%rcx
  820b73:	jae    8215ab <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  820b79:	incl   0x4(%r12,%rcx,8)
  820b7e:	cmp    %r11,%rdi
  820b81:	jae    821520 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820b87:	mov    %r8,%rdi
  820b8a:	cmp    %r11,%r8
  820b8d:	jbe    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4e0>
  820b93:	jmp    821520 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820b98:	unpcklpd %xmm2,%xmm12
  820b9d:	addpd  -0x773ad6(%rip),%xmm12        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820ba6:	movapd %xmm12,%xmm10
  820bab:	mulpd  0x280(%rsp),%xmm10
  820bb5:	movapd %xmm10,%xmm15
  820bba:	unpckhpd %xmm10,%xmm15
  820bbf:	movapd %xmm10,%xmm2
  820bc4:	addsd  %xmm15,%xmm2
  820bc9:	addsd  0x120(%rsp),%xmm2
  820bd2:	subsd  0x80(%rsp),%xmm2
  820bdb:	movapd 0x270(%rsp),%xmm8
  820be5:	mulpd  %xmm12,%xmm8
  820bea:	movapd %xmm8,%xmm9
  820bef:	unpckhpd %xmm8,%xmm9
  820bf4:	movapd %xmm8,%xmm3
  820bf9:	addsd  %xmm9,%xmm3
  820bfe:	addsd  0x110(%rsp),%xmm3
  820c07:	addsd  0x70(%rsp),%xmm3
  820c0d:	addsd  0x60(%rsp),%xmm3
  820c13:	addsd  -0x7713a3(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c1b:	mulsd  -0x771423(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820c23:	addsd  0x8(%rsp),%xmm3
  820c29:	ucomisd %xmm2,%xmm3
  820c2d:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c33:	movapd 0x50(%rsp),%xmm4
  820c39:	subsd  %xmm2,%xmm4
  820c3d:	ucomisd %xmm4,%xmm3
  820c41:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c47:	movapd %xmm12,%xmm7
  820c4c:	unpckhpd %xmm12,%xmm7
  820c51:	movapd 0x240(%rsp),%xmm11
  820c5b:	mulsd  %xmm7,%xmm11
  820c60:	movapd 0x230(%rsp),%xmm3
  820c69:	mulsd  %xmm7,%xmm3
  820c6d:	movapd 0x260(%rsp),%xmm2
  820c76:	mulsd  %xmm12,%xmm2
  820c7b:	movapd %xmm2,0x140(%rsp)
  820c84:	addsd  %xmm11,%xmm2
  820c89:	addsd  0x100(%rsp),%xmm2
  820c92:	subsd  0x80(%rsp),%xmm2
  820c9b:	movapd 0x250(%rsp),%xmm4
  820ca4:	mulsd  %xmm12,%xmm4
  820ca9:	movsd  %xmm4,0x190(%rsp)
  820cb2:	addsd  %xmm3,%xmm4
  820cb6:	addsd  0xf0(%rsp),%xmm4
  820cbf:	addsd  0x70(%rsp),%xmm4
  820cc5:	addsd  0x60(%rsp),%xmm4
  820ccb:	addsd  -0x77145b(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cd3:	mulsd  -0x770f03(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820cdb:	ucomisd %xmm2,%xmm4
  820cdf:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ce5:	movapd 0x50(%rsp),%xmm5
  820ceb:	subsd  %xmm2,%xmm5
  820cef:	ucomisd %xmm5,%xmm4
  820cf3:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820cf9:	movapd %xmm7,%xmm4
  820cfd:	mulsd  0x200(%rsp),%xmm4
  820d06:	movapd %xmm7,%xmm2
  820d0a:	mulsd  0x1f0(%rsp),%xmm2
  820d13:	movapd %xmm12,%xmm5
  820d18:	mulsd  0x220(%rsp),%xmm5
  820d21:	movsd  %xmm5,0x188(%rsp)
  820d2a:	movapd %xmm4,0x130(%rsp)
  820d33:	addsd  %xmm4,%xmm5
  820d37:	addsd  0xd0(%rsp),%xmm5
  820d40:	subsd  0x40(%rsp),%xmm5
  820d46:	movapd %xmm12,%xmm4
  820d4b:	mulsd  0x210(%rsp),%xmm4
  820d54:	movsd  %xmm4,0x180(%rsp)
  820d5d:	addsd  %xmm2,%xmm4
  820d61:	addsd  0xe0(%rsp),%xmm4
  820d6a:	addsd  0x30(%rsp),%xmm4
  820d70:	addsd  0x20(%rsp),%xmm4
  820d76:	addsd  -0x771506(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d7e:	mulsd  -0x771586(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820d86:	addsd  (%rsp),%xmm4
  820d8b:	ucomisd %xmm5,%xmm4
  820d8f:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d95:	movapd 0x10(%rsp),%xmm14
  820d9c:	subsd  %xmm5,%xmm14
  820da1:	ucomisd %xmm14,%xmm4
  820da6:	movsd  0x98(%rsp),%xmm14
  820db0:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820db6:	movapd 0x1c0(%rsp),%xmm4
  820dbf:	mulsd  %xmm7,%xmm4
  820dc3:	mulsd  0x1b0(%rsp),%xmm7
  820dcc:	movapd 0x1e0(%rsp),%xmm5
  820dd5:	mulsd  %xmm12,%xmm5
  820dda:	movapd %xmm5,0x2c0(%rsp)
  820de3:	movapd %xmm4,0x2d0(%rsp)
  820dec:	addsd  %xmm4,%xmm5
  820df0:	addsd  0xc0(%rsp),%xmm5
  820df9:	subsd  0x40(%rsp),%xmm5
  820dff:	mulsd  0x1d0(%rsp),%xmm12
  820e09:	movapd %xmm12,%xmm4
  820e0e:	addsd  %xmm7,%xmm4
  820e12:	addsd  0xb0(%rsp),%xmm4
  820e1b:	addsd  0x30(%rsp),%xmm4
  820e21:	addsd  0x20(%rsp),%xmm4
  820e27:	addsd  -0x7715b7(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e2f:	mulsd  -0x77105f(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820e37:	ucomisd %xmm5,%xmm4
  820e3b:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e41:	movapd 0x10(%rsp),%xmm14
  820e48:	subsd  %xmm5,%xmm14
  820e4d:	ucomisd %xmm14,%xmm4
  820e52:	movsd  0x98(%rsp),%xmm14
  820e5c:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e62:	addsd  -0x7718e2(%rip),%xmm6        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820e6a:	movapd %xmm6,%xmm4
  820e6e:	mulsd  0x280(%rsp),%xmm4
  820e77:	movsd  %xmm4,0x168(%rsp)
  820e80:	addsd  %xmm4,%xmm15
  820e85:	addsd  0x120(%rsp),%xmm15
  820e8f:	subsd  0x80(%rsp),%xmm15
  820e99:	movapd 0x270(%rsp),%xmm4
  820ea2:	mulsd  %xmm6,%xmm4
  820ea6:	movsd  %xmm4,0x160(%rsp)
  820eaf:	addsd  %xmm4,%xmm9
  820eb4:	addsd  0x110(%rsp),%xmm9
  820ebe:	addsd  0x70(%rsp),%xmm9
  820ec5:	addsd  0x60(%rsp),%xmm9
  820ecc:	addsd  -0x77165d(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ed5:	mulsd  -0x7716de(%rip),%xmm9        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ede:	addsd  0x8(%rsp),%xmm9
  820ee5:	ucomisd %xmm15,%xmm9
  820eea:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ef0:	movapd 0x50(%rsp),%xmm4
  820ef6:	subsd  %xmm15,%xmm4
  820efb:	ucomisd %xmm4,%xmm9
  820f00:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f06:	movapd 0x260(%rsp),%xmm15
  820f10:	mulsd  %xmm6,%xmm15
  820f15:	addsd  %xmm15,%xmm11
  820f1a:	addsd  0x100(%rsp),%xmm11
  820f24:	subsd  0x80(%rsp),%xmm11
  820f2e:	movapd 0x250(%rsp),%xmm4
  820f37:	mulsd  %xmm6,%xmm4
  820f3b:	movsd  %xmm4,0x158(%rsp)
  820f44:	addsd  %xmm4,%xmm3
  820f48:	addsd  0xf0(%rsp),%xmm3
  820f51:	addsd  0x70(%rsp),%xmm3
  820f57:	addsd  0x60(%rsp),%xmm3
  820f5d:	addsd  -0x7716ed(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f65:	mulsd  -0x771195(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f6d:	ucomisd %xmm11,%xmm3
  820f72:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f78:	movapd 0x50(%rsp),%xmm4
  820f7e:	subsd  %xmm11,%xmm4
  820f83:	ucomisd %xmm4,%xmm3
  820f87:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f8d:	movapd %xmm6,%xmm3
  820f91:	mulsd  0x220(%rsp),%xmm3
  820f9a:	movsd  %xmm3,0x150(%rsp)
  820fa3:	movapd 0x130(%rsp),%xmm5
  820fac:	addsd  %xmm3,%xmm5
  820fb0:	addsd  0xd0(%rsp),%xmm5
  820fb9:	subsd  0x40(%rsp),%xmm5
  820fbf:	movapd %xmm6,%xmm3
  820fc3:	mulsd  0x210(%rsp),%xmm3
  820fcc:	movsd  %xmm3,0x130(%rsp)
  820fd5:	addsd  %xmm3,%xmm2
  820fd9:	addsd  0xe0(%rsp),%xmm2
  820fe2:	addsd  0x30(%rsp),%xmm2
  820fe8:	addsd  0x20(%rsp),%xmm2
  820fee:	addsd  -0x77177e(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ff6:	mulsd  -0x7717fe(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820ffe:	addsd  (%rsp),%xmm2
  821003:	ucomisd %xmm5,%xmm2
  821007:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82100d:	movapd 0x10(%rsp),%xmm3
  821013:	subsd  %xmm5,%xmm3
  821017:	ucomisd %xmm3,%xmm2
  82101b:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821021:	movapd 0x1e0(%rsp),%xmm2
  82102a:	mulsd  %xmm6,%xmm2
  82102e:	movapd %xmm2,0x290(%rsp)
  821037:	movapd 0x2d0(%rsp),%xmm4
  821040:	addsd  %xmm2,%xmm4
  821044:	addsd  0xc0(%rsp),%xmm4
  82104d:	subsd  0x40(%rsp),%xmm4
  821053:	mulsd  0x1d0(%rsp),%xmm6
  82105c:	addsd  %xmm6,%xmm7
  821060:	addsd  0xb0(%rsp),%xmm7
  821069:	addsd  0x30(%rsp),%xmm7
  82106f:	addsd  0x20(%rsp),%xmm7
  821075:	addsd  -0x771805(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82107d:	mulsd  -0x7712ad(%rip),%xmm7        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821085:	ucomisd %xmm4,%xmm7
  821089:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82108f:	movapd 0x10(%rsp),%xmm2
  821095:	subsd  %xmm4,%xmm2
  821099:	ucomisd %xmm2,%xmm7
  82109d:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8210a3:	addsd  -0x771b24(%rip),%xmm13        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8210ac:	movapd %xmm13,%xmm3
  8210b1:	mulsd  0x2b0(%rsp),%xmm3
  8210ba:	movapd %xmm13,%xmm2
  8210bf:	mulsd  0x2a0(%rsp),%xmm2
  8210c8:	addsd  %xmm3,%xmm10
  8210cd:	addsd  0x120(%rsp),%xmm10
  8210d7:	subsd  0x80(%rsp),%xmm10
  8210e1:	addsd  %xmm2,%xmm8
  8210e6:	addsd  0x110(%rsp),%xmm8
  8210f0:	addsd  0x70(%rsp),%xmm8
  8210f7:	addsd  0x60(%rsp),%xmm8
  8210fe:	addsd  -0x77188f(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821107:	mulsd  -0x771910(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821110:	addsd  0x8(%rsp),%xmm8
  821117:	ucomisd %xmm10,%xmm8
  82111c:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821122:	movapd 0x50(%rsp),%xmm4
  821128:	subsd  %xmm10,%xmm4
  82112d:	ucomisd %xmm4,%xmm8
  821132:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821138:	movapd 0x240(%rsp),%xmm7
  821141:	mulsd  %xmm13,%xmm7
  821146:	movapd 0x230(%rsp),%xmm5
  82114f:	mulsd  %xmm13,%xmm5
  821154:	movapd 0x140(%rsp),%xmm4
  82115d:	addsd  %xmm7,%xmm4
  821161:	addsd  0x100(%rsp),%xmm4
  82116a:	subsd  0x80(%rsp),%xmm4
  821173:	movsd  0x190(%rsp),%xmm10
  82117d:	addsd  %xmm5,%xmm10
  821182:	addsd  0xf0(%rsp),%xmm10
  82118c:	addsd  0x70(%rsp),%xmm10
  821193:	addsd  0x60(%rsp),%xmm10
  82119a:	addsd  -0x77192b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211a3:	mulsd  -0x7713d4(%rip),%xmm10        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8211ac:	ucomisd %xmm4,%xmm10
  8211b1:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211b7:	movapd %xmm4,%xmm8
  8211bc:	movapd 0x50(%rsp),%xmm4
  8211c2:	subsd  %xmm8,%xmm4
  8211c7:	ucomisd %xmm4,%xmm10
  8211cc:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211d2:	movapd %xmm13,%xmm8
  8211d7:	mulsd  0x200(%rsp),%xmm8
  8211e1:	movapd %xmm13,%xmm10
  8211e6:	mulsd  0x1f0(%rsp),%xmm10
  8211f0:	movsd  0x188(%rsp),%xmm9
  8211fa:	addsd  %xmm8,%xmm9
  8211ff:	addsd  0xd0(%rsp),%xmm9
  821209:	subsd  0x40(%rsp),%xmm9
  821210:	movapd %xmm15,%xmm4
  821215:	movsd  0x180(%rsp),%xmm15
  82121f:	movsd  %xmm10,0x140(%rsp)
  821229:	addsd  %xmm10,%xmm15
  82122e:	addsd  0xe0(%rsp),%xmm15
  821238:	addsd  0x30(%rsp),%xmm15
  82123f:	addsd  0x20(%rsp),%xmm15
  821246:	addsd  -0x7719d7(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82124f:	mulsd  -0x771a58(%rip),%xmm15        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821258:	addsd  (%rsp),%xmm15
  82125e:	ucomisd %xmm9,%xmm15
  821263:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821269:	movapd %xmm9,%xmm10
  82126e:	movapd 0x10(%rsp),%xmm9
  821275:	subsd  %xmm10,%xmm9
  82127a:	ucomisd %xmm9,%xmm15
  82127f:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821285:	movapd 0x1c0(%rsp),%xmm9
  82128f:	mulsd  %xmm13,%xmm9
  821294:	mulsd  0x1b0(%rsp),%xmm13
  82129e:	movapd 0x2c0(%rsp),%xmm10
  8212a8:	addsd  %xmm9,%xmm10
  8212ad:	addsd  0xc0(%rsp),%xmm10
  8212b7:	subsd  0x40(%rsp),%xmm10
  8212be:	addsd  %xmm13,%xmm12
  8212c3:	addsd  0xb0(%rsp),%xmm12
  8212cd:	addsd  0x30(%rsp),%xmm12
  8212d4:	addsd  0x20(%rsp),%xmm12
  8212db:	addsd  -0x771a6c(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212e4:	mulsd  -0x771515(%rip),%xmm12        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8212ed:	ucomisd %xmm10,%xmm12
  8212f2:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8212f8:	movapd %xmm10,%xmm11
  8212fd:	movapd 0x10(%rsp),%xmm10
  821304:	subsd  %xmm11,%xmm10
  821309:	ucomisd %xmm10,%xmm12
  82130e:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821314:	movsd  0x168(%rsp),%xmm10
  82131e:	addsd  %xmm3,%xmm10
  821323:	addsd  0x120(%rsp),%xmm10
  82132d:	subsd  0x80(%rsp),%xmm10
  821337:	movsd  0x160(%rsp),%xmm11
  821341:	addsd  %xmm2,%xmm11
  821346:	addsd  0x110(%rsp),%xmm11
  821350:	addsd  0x70(%rsp),%xmm11
  821357:	addsd  0x60(%rsp),%xmm11
  82135e:	addsd  -0x771aef(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821367:	mulsd  -0x771b70(%rip),%xmm11        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821370:	addsd  0x8(%rsp),%xmm11
  821377:	ucomisd %xmm10,%xmm11
  82137c:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821382:	movapd %xmm4,%xmm15
  821387:	movapd 0x50(%rsp),%xmm2
  82138d:	subsd  %xmm10,%xmm2
  821392:	ucomisd %xmm2,%xmm11
  821397:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82139d:	addsd  %xmm7,%xmm15
  8213a2:	addsd  0x100(%rsp),%xmm15
  8213ac:	subsd  0x80(%rsp),%xmm15
  8213b6:	movsd  0x158(%rsp),%xmm2
  8213bf:	addsd  %xmm5,%xmm2
  8213c3:	addsd  0xf0(%rsp),%xmm2
  8213cc:	addsd  0x70(%rsp),%xmm2
  8213d2:	addsd  0x60(%rsp),%xmm2
  8213d8:	addsd  -0x771b68(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213e0:	mulsd  -0x771610(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8213e8:	ucomisd %xmm15,%xmm2
  8213ed:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213f3:	movapd %xmm2,%xmm3
  8213f7:	movapd 0x50(%rsp),%xmm2
  8213fd:	subsd  %xmm15,%xmm2
  821402:	ucomisd %xmm2,%xmm3
  821406:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82140c:	movsd  0x150(%rsp),%xmm2
  821415:	addsd  %xmm8,%xmm2
  82141a:	addsd  0xd0(%rsp),%xmm2
  821423:	subsd  0x40(%rsp),%xmm2
  821429:	movsd  0x130(%rsp),%xmm5
  821432:	addsd  0x140(%rsp),%xmm5
  82143b:	addsd  0xe0(%rsp),%xmm5
  821444:	addsd  0x30(%rsp),%xmm5
  82144a:	addsd  0x20(%rsp),%xmm5
  821450:	addsd  -0x771be0(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821458:	mulsd  -0x771c60(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821460:	addsd  (%rsp),%xmm5
  821465:	ucomisd %xmm2,%xmm5
  821469:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82146f:	movapd %xmm2,%xmm3
  821473:	movapd 0x10(%rsp),%xmm2
  821479:	subsd  %xmm3,%xmm2
  82147d:	ucomisd %xmm2,%xmm5
  821481:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821487:	movapd 0x290(%rsp),%xmm2
  821490:	addsd  %xmm9,%xmm2
  821495:	addsd  0xc0(%rsp),%xmm2
  82149e:	subsd  0x40(%rsp),%xmm2
  8214a4:	addsd  %xmm13,%xmm6
  8214a9:	addsd  0xb0(%rsp),%xmm6
  8214b2:	addsd  0x30(%rsp),%xmm6
  8214b8:	addsd  0x20(%rsp),%xmm6
  8214be:	addsd  -0x771c4e(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214c6:	mulsd  -0x7716f6(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8214ce:	ucomisd %xmm2,%xmm6
  8214d2:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8214d8:	movapd %xmm2,%xmm3
  8214dc:	movapd 0x10(%rsp),%xmm2
  8214e2:	subsd  %xmm3,%xmm2
  8214e6:	ucomisd %xmm2,%xmm6
  8214ea:	jae    820b70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8214f0:	cmp    %rsi,%rcx
  8214f3:	jae    8215c8 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc8>
  8214f9:	mov    0xac(%rsp),%eax
  821500:	mov    %eax,(%r12,%rcx,8)
  821504:	movl   $0x80000001,0x4(%r12,%rcx,8)
  82150d:	movsd  0x98(%rsp),%xmm14
  821517:	cmp    %r11,%rdi
  82151a:	jb     820b87 <<gpui_gpu::renderer::RendererState>::bin_draw+0x587>
  821520:	mov    0x198(%rsp),%r10
  821528:	cmp    %r10,0x1a0(%rsp)
  821530:	jae    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821536:	cmp    %r10,%rbx
  821539:	jbe    820ab0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4b0>
  82153f:	jmp    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821544:	mov    %rbx,%rax
  821547:	nopw   0x0(%rax,%rax,1)
  821550:	cmp    %r10,%rbx
  821553:	adc    $0x0,%rax
  821557:	mov    %rbx,%rdx
  82155a:	imul   %r9,%rdx
  82155e:	mov    0xa0(%rsp),%rdi
  821566:	cs nopw 0x0(%rax,%rax,1)
  821570:	lea    (%rdi,%rdx,1),%rcx
  821574:	cmp    %rsi,%rcx
  821577:	jae    8215ab <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  821579:	cmp    %r11,%rdi
  82157c:	mov    %rdi,%r8
  82157f:	adc    $0x0,%r8
  821583:	incl   0x4(%r12,%rcx,8)
  821588:	cmp    %r11,%rdi
  82158b:	jae    821595 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf95>
  82158d:	mov    %r8,%rdi
  821590:	cmp    %r11,%r8
  821593:	jbe    821570 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf70>
  821595:	cmp    %r10,%rbx
  821598:	jae    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82159e:	mov    %rax,%rbx
  8215a1:	cmp    %r10,%rax
  8215a4:	jbe    821550 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf50>
  8215a6:	jmp    820776 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8215ab:	lea    0x60cca6(%rip),%rdx        # e2e258 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  8215b2:	mov    %rcx,%rdi
  8215b5:	call   *0x65e605(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
  8215bb:	lea    0x60cd86(%rip),%rdi        # e2e348 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.12798218693442382726+0x10>
  8215c2:	call   *0x65e768(%rip)        # e7fd30 <_DYNAMIC+0x668>
  8215c8:	lea    0x60cca1(%rip),%rdx        # e2e270 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  8215cf:	mov    %rcx,%rdi
  8215d2:	call   *0x65e5e8(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
