from pathlib import Path
root=Path('/tmp/gpui-packed-csr-sol/reactivity/crates/gpu/src')
p=root/'renderer.rs'
s=p.read_text()
def change(old,new,n=1):
    global s
    assert s.count(old)==n,(old,s.count(old),n)
    s=s.replace(old,new)
change('const _: () = assert!(MAX_REFERENCES < UNIFORM_TILE as usize);\nconst _: () = assert!(MAX_DRAWS < UNIFORM_TILE as usize);', '''const TILE_START_BITS: u32 = 23;
const TILE_COUNT_BITS: u32 = 17;
const TILE_COUNT_SHIFT: u32 = TILE_START_BITS + TILE_COUNT_BITS;
const TILE_START_MASK: u64 = (1 << TILE_START_BITS) - 1;
const TILE_COUNT_MASK: u32 = (1 << TILE_COUNT_BITS) - 1;
const _: () = assert!(MAX_REFERENCES <= TILE_START_MASK as usize);
const _: () = assert!(MAX_DRAWS <= TILE_COUNT_MASK as usize);
const _: () = assert!(TILE_COUNT_SHIFT + TILE_COUNT_BITS == 57);''')
change('    cursors: Vec<u32>,\n','')
change('            cursors: Vec::new(),\n','')
change('        self.cursors.clear();\n        self.cursors.resize(columns * rows, 0);\n','')
change('                        address,\n                        ordinal,\n                        columns,','                        address,\n                        columns,',2)
start=s.index('        let mut offset = 0;\n        for (tile, range) in self.ranges.iter_mut().enumerate()')
end=s.index('        let references = offset as usize;',start)
s=s[:start]+'''        let mut offset = 0;
        let mut uniform_tiles = 0;
        let mut sample_evaluations = 0;
        let mut sample_draw_evaluations = 0;
        for (row, ranges) in self.ranges.chunks_mut(columns).enumerate() {
            let height = (scene.height - row as u32 * 16).min(16);
            for (column, range) in ranges.iter_mut().enumerate() {
                let count = range[1] & TILE_COUNT_MASK;
                if range[1] & UNIFORM_TILE != 0 && count == 1 {
                    range[1] = UNIFORM_TILE;
                    uniform_tiles += 1;
                } else {
                    *range = sampled_tile(offset, count);
                    offset += count;
                    if count != 0 {
                        let width = (scene.width - column as u32 * 16).min(16);
                        let samples = u64::from(width * height) * 16;
                        sample_evaluations += samples;
                        sample_draw_evaluations += samples * u64::from(count);
                    }
                }
            }
        }
'''+s[end:]
change('        let mut reverse_ordinal = ordinal;\n','')
change('                reverse_ordinal -= 1;\n','')
change('''                    let range = &mut self.ranges[tile];
                    if range[1] != UNIFORM_TILE && reverse_ordinal as u32 + 1 >= self.cursors[tile]
                    {
                        range[0] -= 1;
                        self.references[range[0] as usize] = address;
                    }''','''                    if let Some(index) = take_reference(&mut self.ranges[tile]) {
                        self.references[index] = address;
                    }''')
start=s.index('        debug_assert_eq!((word, reverse_ordinal), (bank_words, 0));')
end=s.index('        let (tone, exposure)',start)
s=s[:start]+'        debug_assert_eq!(word, bank_words);\n'+s[end:]
change('                + self.cursors.capacity() * 4\n','')
change('        ordinal: usize,\n','')
change('''                self.ranges[tile] = [address, 1];
                self.cursors[tile] = ordinal as u32 + 1;''','''                self.ranges[tile] = [address, UNIFORM_TILE | 1];''')
marker='fn tile_count(draw: PreparedDraw'
assert s.count(marker)==1
pos=s.index(marker)
s=s[:pos]+'''// During normalization, sampled tiles retain their immutable range and a
// reverse-fill cursor in the same eight bytes sent to the shader.
fn sampled_tile(start: u32, count: u32) -> [u32; 2] {
    let packed = u64::from(start)
        | (u64::from(count) << TILE_START_BITS)
        | (u64::from(count) << TILE_COUNT_SHIFT);
    [packed as u32, (packed >> 32) as u32]
}

fn take_reference(range: &mut [u32; 2]) -> Option<usize> {
    // Uniform tiles carry full draw addresses, including INLINE_RECORD. Their
    // overlapping low-word bits must never be interpreted as a fill cursor.
    if range[1] & UNIFORM_TILE != 0 {
        return None;
    }
    let packed = u64::from(range[0]) | (u64::from(range[1]) << 32);
    let remaining = (packed >> TILE_START_BITS) as u32 & TILE_COUNT_MASK;
    if remaining == 0 {
        return None;
    }
    let index = (packed & TILE_START_MASK) + u64::from(remaining) - 1;
    let next = packed - (1 << TILE_START_BITS);
    *range = [next as u32, (next >> 32) as u32];
    Some(index as usize)
}

'''+s[pos:]
# Existing private cap controls retain the exact admission boundary assertions.
change('            state.cursors.resize(1, 0);\n','')
change('.bin_draw(draw, [0.; 2], 0, MAX_DRAWS - 1, 1, 1, 1, MAX_REFERENCES - 1)', '.bin_draw(draw, [0.; 2], 0, 1, 1, 1, MAX_REFERENCES - 1)')
change('let before = (state.ranges.clone(), state.cursors.clone());','let before = state.ranges.clone();')
change('state.bin_draw(draw, [0.; 2], 0, 0, 1, 1, 1, previous)','state.bin_draw(draw, [0.; 2], 0, 1, 1, 1, previous)')
change('assert_eq!((&state.ranges, &state.cursors), (&before.0, &before.1));','assert_eq!(state.ranges, before);')
p.write_text(s)
p=root/'shader.rs'
s=p.read_text()
old='''        let range = get!(TILES)[tile as usize];
        if (range.y & 0x80000000) != 0 {
            if (globals.viewport.w & 8) != 0 {
                return output(load_banked_draw(range.x).color);
            }
            return output(load_draw(range.x).color);
        }
        if range.x == range.y {'''
new='''        let packed = get!(TILES)[tile as usize];
        if (packed.y & 0x80000000) != 0 {
            if (globals.viewport.w & 8) != 0 {
                return output(load_banked_draw(packed.x).color);
            }
            return output(load_draw(packed.x).color);
        }
        let start = packed.x & 0x7fffff;
        let count = (packed.y >> 8) & 0x1ffff;
        let range = vec2u(start, start + count);
        if count == 0 {'''
assert s.count(old)==1
p.write_text(s.replace(old,new))
