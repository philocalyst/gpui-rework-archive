    #[test]
    fn packed_tile_fields_cover_inclusive_caps_and_uniform_addresses() {
        for (start, count) in [
            (0, 0),
            (MAX_REFERENCES as u32, 0),
            (MAX_REFERENCES as u32 - 1, 1),
            (MAX_REFERENCES as u32 - MAX_DRAWS as u32, MAX_DRAWS as u32),
            (0, 511),
            (511, 512),
            (512, 513),
        ] {
            let mut range = sampled_tile(start, count);
            let retained = range[1] >> 8 & 0x1ffff;
            assert_eq!(range[0] & 0x7fffff, start);
            assert_eq!(retained, count);
            assert_eq!(range[1] & UNIFORM_TILE, 0);
            for remaining in (1..=count).rev() {
                assert_eq!(take_reference(&mut range), Some((start + remaining - 1) as usize));
                assert_eq!(range[0] & 0x7fffff, start);
                assert_eq!(range[1] >> 8 & 0x1ffff, count);
                let packed = u64::from(range[0]) | u64::from(range[1]) << 32;
                assert_eq!((packed >> 23) & 0x1ffff, u64::from(remaining - 1));
            }
            let exhausted = range;
            assert_eq!(take_reference(&mut range), None);
            assert_eq!(range, exhausted);
        }
        for address in [0, 1, MAX_DRAWS as u32 * 6, INLINE_RECORD, INLINE_RECORD | 137] {
            let mut range = [address, UNIFORM_TILE];
            assert_eq!(take_reference(&mut range), None);
            assert_eq!(range, [address, UNIFORM_TILE]);
        }
    }

    #[cfg(feature = "vulkan-tests")]
    #[test]
    fn actual_binning_and_reverse_fill_match_an_independent_suffix_oracle() {
        pollster::block_on(async {
            let mut desc = wgpu::InstanceDescriptor::new_without_display_handle();
            desc.backends = wgpu::Backends::VULKAN;
            let instance = wgpu::Instance::new(desc);
            let adapter = instance.request_adapter(&wgpu::RequestAdapterOptions {
                force_fallback_adapter: true,
                ..Default::default()
            }).await.unwrap();
            let context = GpuContext::request(&adapter, wgpu::TextureFormat::Rgba8UnormSrgb)
                .await.unwrap();
            let mut state = RendererState::new(&context);
            // A full opaque rectangle, full translucent rectangle, and clipped
            // opaque corner produce respectively all, no, and one certificate.
            let full = PreparedDraw {
                local_rect: Rect::new(-1., -1., 37., 21.),
                inverse: [1., 0., 0., 1., 0., 0.],
                clip: Rect::new(0., 0., 35., 19.),
                bounds: Rect::new(0., 0., 35., 19.),
                color: [1.; 4],
                source: gpui_canvas::PreparedSource::Solid,
            };
            let translucent = PreparedDraw { color: [0.5; 4], ..full };
            let corner = PreparedDraw {
                local_rect: Rect::new(31., 15., 5., 5.),
                clip: Rect::new(32., 16., 3., 3.),
                bounds: Rect::new(32., 16., 3., 3.),
                ..full
            };
            let partial = PreparedDraw {
                local_rect: Rect::new(3., 3., 7., 7.),
                bounds: Rect::new(0., 0., 16., 16.),
                ..full
            };
            let draws = [full, translucent, corner, partial];
            for proofs in [false, true] {
                state.tile_proofs = proofs;
                // Enumerate all 4^7 painter streams. The oracle classifies each
                // known geometry independently; it never calls full_tile.
                for pattern in 0..(1_u32 << 14) {
                    state.ranges.clear();
                    state.ranges.resize(6, [0, 0]);
                    let mut expected: [Vec<u32>; 6] = std::array::from_fn(|_| Vec::new());
                    let mut opaque = [false; 6];
                    let mut events = Vec::new();
                    let mut original = 0;
                    for ordinal in 0..7 {
                        let kind = (pattern >> (ordinal * 2)) as usize & 3;
                        let address = (ordinal * 6 + 113) | if ordinal & 1 == 0 { INLINE_RECORD } else { 0 };
                        original = state.bin_draw(draws[kind], [0.; 2], address, 3, 35, 19, original).unwrap();
                        let tiles: &[usize] = match kind {
                            0 | 1 => &[0, 1, 2, 3, 4, 5],
                            2 => &[5],
                            _ => &[0],
                        };
                        for &tile in tiles {
                            let proof = proofs && (kind == 0 || kind == 2);
                            if proof {
                                expected[tile].clear();
                                opaque[tile] = true;
                            }
                            expected[tile].push(address);
                            events.push((tile, address));
                        }
                    }
                    assert_eq!(original, events.len());
                    let mut offset = 0;
                    for (tile, range) in state.ranges.iter_mut().enumerate() {
                        assert_eq!(range[1] & TILE_COUNT_MASK, expected[tile].len() as u32);
                        assert_eq!(range[1] & UNIFORM_TILE != 0, opaque[tile]);
                        if opaque[tile] && expected[tile].len() == 1 {
                            assert_eq!(range[0], expected[tile][0]);
                            range[1] = UNIFORM_TILE;
                        } else {
                            *range = sampled_tile(offset, expected[tile].len() as u32);
                            offset += expected[tile].len() as u32;
                        }
                    }
                    let mut actual = vec![0; offset as usize];
                    for &(tile, address) in events.iter().rev() {
                        if let Some(index) = take_reference(&mut state.ranges[tile]) {
                            actual[index] = address;
                        }
                    }
                    let expected: Vec<u32> = expected.into_iter().enumerate()
                        .filter(|(tile, values)| !(opaque[*tile] && values.len() == 1))
                        .flat_map(|(_, values)| values).collect();
                    assert_eq!(actual, expected, "pattern={pattern},proofs={proofs}");
                    assert!(state.ranges.iter_mut().all(|range| take_reference(range).is_none()));
                }
            }
            state.ranges.fill([0, 0]);
            let mut original = 0;
            for address in 0..MAX_DRAWS as u32 {
                original = state.bin_draw(translucent, [0.; 2], address, 3, 35, 19, original).unwrap();
            }
            assert_eq!(original, MAX_DRAWS * 6);
            assert!(state.ranges.iter().all(|range| range[1] == MAX_DRAWS as u32));
        });
    }
