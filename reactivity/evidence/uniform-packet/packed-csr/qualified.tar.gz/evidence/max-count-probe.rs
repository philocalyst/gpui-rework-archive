
// Nonshipping qualification probe, applied identically to both named captures.
#[test]
fn qualified_gpu_retained_count_65536_uses_the_seventeenth_bit() {
    pollster::block_on(async {
        let mut gpu = renderer(wgpu::TextureFormat::Rgba16Float).await;
        let mut canvas = Canvas::recording(1, 1,
            ColorConfig::linear_hdr(gpui_canvas::OutputProfile::DisplayP3, 203.).unwrap()).unwrap();
        canvas.clear(Color::WHITE);
        for _ in 0..65_536 {
            canvas.fill_rect(Rect::new(-1., -1., 3., 3.), Affine::IDENTITY,
                Rect::new(0., 0., 1., 1.), Color::rgba(30, 80, 150, 1)).unwrap();
        }
        let actual = readback(&mut gpu, &canvas);
        assert_eq!(gpu.stats().draws, 65_536);
        assert_eq!(gpu.stats().original_tile_references, 65_536);
        assert_eq!(gpu.stats().tile_references, 65_536);
        assert_eq!(gpu.stats().sample_evaluations, 16);
        assert_eq!(gpu.stats().sample_draw_evaluations, 1_048_576);
        let mut empty = Canvas::recording(1, 1,
            ColorConfig::linear_hdr(gpui_canvas::OutputProfile::DisplayP3, 203.).unwrap()).unwrap();
        empty.clear(Color::WHITE);
        assert_ne!(actual, readback(&mut gpu, &empty), "65536 must not truncate to empty");
    });
}
