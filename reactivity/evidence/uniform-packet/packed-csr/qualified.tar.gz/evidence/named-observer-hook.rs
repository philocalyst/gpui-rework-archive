    // Nonshipping readback observer: source restored by the guarded runner.
    if let Some(directory) = std::env::var_os("GPUI_NAMED_PIXEL_CAPTURE") {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let index = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let thread = std::thread::current();
        let name = thread.name().expect("named test thread");
        let directory = std::path::PathBuf::from(directory);
        std::fs::create_dir_all(&directory).unwrap();
        std::fs::write(directory.join(format!("{index:04}-{name}-{width}x{height}-{:?}.bin", renderer.format())), &output).unwrap();
        std::fs::write(directory.join(format!("{index:04}-{name}-{width}x{height}-{:?}.stats", renderer.format())), format!("{:?}
{:?}
", renderer.stats(), renderer.image_stats())).unwrap();
        std::fs::write(directory.join(format!("{index:04}-{name}-{width}x{height}-{:?}.cursor", renderer.format())), format!("{:?}", renderer.qualification_capacities())).unwrap();
        std::fs::write(directory.join("layout.json"), format!("{{\"Renderer\":{},\"RendererState\":{},\"Stats\":{}}}\n", std::mem::size_of::<Renderer>(), std::mem::size_of::<gpui_gpu::RendererState>(), std::mem::size_of::<Stats>())).unwrap();
    }
