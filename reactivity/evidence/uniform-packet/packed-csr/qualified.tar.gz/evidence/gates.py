from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path('/tmp/gpui-packed-csr-sol');OUT=Path('/tmp/gpui-packed-csr-evidence')
env=dict(os.environ)
env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
env.update(CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/tmp/gpui-packed-csr-target',GPUI_SPIRV_VAL='/tmp/gpui-qualified-spirv-root/bin/spirv-val')
def git(*args): return subprocess.check_output(['git','-c','safe.directory='+str(ROOT),'-C',str(ROOT),*args])
assert not git('status','--porcelain')
source=git('rev-parse','HEAD').decode().strip()
paths=git('ls-files','reactivity/crates','reactivity/vendor','reactivity/Cargo.lock','reactivity/Cargo.toml','.cargo/config.toml').decode().splitlines()
guards={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if '/evidence/' not in p}
result={'source':source,'qualified_source_sha256':guards,'rustc':subprocess.check_output(['rustc','-vV'],text=True),'cargo':subprocess.check_output(['cargo','-V'],text=True),'gates':{}}
assert result['rustc'].startswith('rustc 1.97.1 ')
def run(name,args):
    with (OUT/(name+'.log')).open('w') as log:
        p=subprocess.run(args,cwd=ROOT/'reactivity',env=env,stdout=log,stderr=subprocess.STDOUT)
    (OUT/(name+'.exit')).write_text(str(p.returncode)+'\n')
    result['gates'][name]={'args':args,'returncode':p.returncode}
    (OUT/'gates-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    assert p.returncode==0,name
    print(name+' PASS',flush=True)
run('format',['cargo','fmt','-p','gpui_gpu','--','--check'])
for name,features in [('default',['--features','vulkan-tests']),('fallback',['--no-default-features','--features','vulkan-tests']),('offline',['--features','vulkan-tests,offline-shader'])]:
    run(name,['cargo','test','--release','--offline','--locked','-p','gpui_gpu',*features])
for name,features in [('strict-default','vulkan-tests'),('strict-offline','vulkan-tests,offline-shader')]:
    run(name,['cargo','clippy','--offline','--locked','-p','gpui_gpu','--all-targets','--features',features,'--','-D','warnings'])
assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest()==digest for p,digest in guards.items())
assert not git('status','--porcelain')
result['all_source_guards_restored']=True
(OUT/'gates-summary.json').write_text(json.dumps(result,indent=2)+'\n')
