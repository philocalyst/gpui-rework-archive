# Matched linked and shader review

Both primary library rustc argument vectors are exactly equal, including opt3,
root v0/tokio and one emit-stack-sizes. Both actual library/groups artifacts are
fresh:false. The same source path, lock and non-GPU sources are guarded.

Default linked .text is 6403991 -> 6403639 (-352); .rodata 7012024 -> 7012280 (+256);
.data.rel.ro 336384 -> 336336 (-48). Offline .text also falls 352, while offline
.rodata grows 640. The complete GPU alias/ambiguity ledger and whole ELF sections
are retained; selected function deltas are not an additive whole-program proof.

Render body 9493/frame 1416 -> 9385/frame 1400. bin_draw 4184/frame 824 -> 4056/frame 792.
The reverse visit monomorph is 611/frame 88 -> 610/frame 72. Constructor falls 27 bytes
and RendererState drop glue falls 81. Frame metadata is static, not dynamic peak
stack or a sum of independent function frames. Core source 30692 -> 30706 (+14).

Baseline render contains divq/divl alternatives for the removed final statistics
walk. Candidate render contains no integer divide; bin_draw retains its existing
integer-divide alternatives. Candidate reverse visit 81c818..81c820 loads the high
word and checks its sign before decoding a cursor, preserving the uniform-inline
alternate representation. 81c822..81c844 reconstructs u64, checks remaining bits,
shifts 23 and masks start/count. 81c84a..81c851 subtracts 1<<23 and stores eight bytes.
The previous path 81c77f..81c799 bounds-checks/loads the separate cursor vector and
compares the reverse ordinal; 81c79b..81c7a0 decrements/stores four range bytes.
Thus the new integer decode and wider range store are charged alongside deleting
the separate vector/cutoff; no latency claim follows from instruction selection.
Full baseline/candidate reverse-visit and render/bin_draw assembly is included.

Generated WGSL checks y bit31 first, then start-mask, count-right-shift8, count-mask,
start+count, empty-count check, and the unchanged banked/sample-major paths.
WGSL 15180 -> 15309 bytes (+129). Each of four validated fragment SPIR-V variants
grows 132 bytes: two OpBitwiseAnd, one OpShiftRightLogical, one OpIAdd, one
OpCompositeConstruct and two OpConstant are added. All four vertex modules have
zero opcode/byte delta. Complete opcode histograms and disassembly remain.
This is SPIR-V static cost, not native GPU ISA, register pressure or device time.
