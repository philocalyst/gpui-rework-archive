from pathlib import Path
import hashlib,json,os,shutil,subprocess
ROOT=Path('/tmp/gpui-packed-csr-sol');OUT=Path('/tmp/gpui-packed-csr-evidence/negative-selection');OUT.mkdir()
source=ROOT/'reactivity/crates/gpu/src/renderer.rs';original=source.read_bytes()
needle=b'let index = (packed & TILE_START_MASK) + u64::from(remaining) - 1;'
assert original.count(needle)==1
fault=original.replace(needle,b'let count = (packed >> TILE_COUNT_SHIFT) as u32 & TILE_COUNT_MASK;\n    let index = (packed & TILE_START_MASK) + u64::from(count - remaining);')
env=dict(os.environ);env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
env.update(CARGO_TARGET_DIR='/tmp/gpui-packed-csr-target',CARGO_BUILD_JOBS='1')
result={'source':'5559828a4f6d093401cc374654f634b4d8fb9ddb','original_source_sha256':hashlib.sha256(original).hexdigest(),'fault_source_sha256':hashlib.sha256(fault).hexdigest(),
        'fault_description':'Reverse visits select ascending retained slots instead of descending slots: same count/allocation, wrong painter address order.'}
(OUT/'fault-renderer.rs').write_bytes(fault)
def build(label,args,target):
    directory=OUT/label;directory.mkdir()
    with (directory/'cargo.jsonl').open('w') as stdout,(directory/'cargo.log').open('w') as stderr:
        subprocess.run(args+['--message-format=json'],cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,check=True)
    artifacts=[json.loads(line) for line in (directory/'cargo.jsonl').read_text().splitlines() if line.startswith('{')]
    artifact=next(a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')==target and a.get('executable'))
    assert not artifact['fresh'] and artifact['profile']['opt_level']=='3'
    exe=directory/target;shutil.copy2(artifact['executable'],exe);exe.chmod(0o555)
    return directory,exe,{'artifact':artifact,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
def oracle(label):
    args=['cargo','test','--release','--offline','--locked','-p','gpui_gpu','--features','vulkan-tests','--lib','--no-run']
    directory,exe,record=build(label,args,'gpui_gpu')
    with (directory/'stdout.log').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:
        p=subprocess.run([str(exe),'renderer::tests::actual_binning_and_reverse_fill_match_an_independent_suffix_oracle','--exact','--nocapture'],cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,timeout=180)
    record['returncode']=p.returncode
    return record
fixture=ROOT/'reactivity/crates/gpu/examples/qualification.rs'
assert not fixture.exists()
try:
    source.write_bytes(fault)
    result['fault_oracle']=oracle('fault-oracle')
    assert result['fault_oracle']['returncode']==101
    assert 'pattern=' in (OUT/'fault-oracle/stderr.log').read_text()
    reference=Path('/tmp/gpui-gpu-frontier-evidence/source/qualification.rs')
    assert hashlib.sha256(reference.read_bytes()).hexdigest()=='8773146b44150adb0150323d51f241c946fb5cda26328f004562dcd9dee39cc0'
    shutil.copy2(reference,fixture)
    directory,exe,record=build('fault-public',['cargo','build','--release','--offline','--locked','-p','gpui_gpu','--example','qualification','--features','vulkan-tests'],'qualification')
    capture=directory/'captures'
    with (directory/'stdout.log').open('w') as stdout,(directory/'stderr.log').open('w') as stderr:
        p=subprocess.run([str(exe),str(capture),'calibration'],cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,timeout=180)
    record['returncode']=p.returncode;assert p.returncode==0
    files=sorted(capture.glob('*.bin'));assert len(files)==52
    shipping=Path('/tmp/gpui-gpu-frontier-evidence/calibration/pair-00-A')
    record['readbacks']=[{'name':f.name,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'shipping_equal':f.read_bytes()==(shipping/f.name).read_bytes()} for f in files]
    mismatches=[r['name'] for r in record['readbacks'] if not r['shipping_equal']]
    assert any(name.startswith('layers8-false-') for name in mismatches)
    assert any(name.startswith('layers8-true-') for name in mismatches)
    result['fault_public']=record;result['mismatched_public_readbacks']=mismatches
finally:
    source.write_bytes(original);assert source.read_bytes()==original
    fixture.unlink(missing_ok=True)
    result['exact_source_restored']=True
    (OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
result['recovery_oracle']=oracle('recovery-oracle')
assert result['recovery_oracle']['returncode']==0
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'fault_oracle':result['fault_oracle']['returncode'],'public_capture_process':result['fault_public']['returncode'],'retained_readbacks':52,'mismatches':len(result['mismatched_public_readbacks']),'recovery_oracle':result['recovery_oracle']['returncode']},indent=2))
