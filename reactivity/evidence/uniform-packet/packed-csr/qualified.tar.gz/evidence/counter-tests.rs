#[test]
fn packed_csr_work_counters_use_clipped_areas_and_exact_survivors() {
    pollster::block_on(async {
        for hdr in [false, true] {
            let format = if hdr {
                wgpu::TextureFormat::Rgba16Float
            } else {
                wgpu::TextureFormat::Rgba8UnormSrgb
            };
            let config = if hdr {
                ColorConfig::linear_hdr(gpui_canvas::OutputProfile::DisplayP3, 203.0).unwrap()
            } else {
                ColorConfig::default()
            };
            let mut gpu = renderer(format).await;
            let mut canvas = Canvas::recording(35, 19, config).unwrap();
            canvas.clear(Color::WHITE);
            let viewport = Rect::new(0.0, 0.0, 35.0, 19.0);
            // Six tiles cover 665 pixels. The last tile is only 3 by 3;
            // a partial draw in the first tile adds a second retained source there.
            // Tile-sized clips bound Canvas's conservative one-pixel AABB halo.
            for (stage, (original, references, uniform, samples, sources, sampled_sources)) in [
                (0, 0, 0, 0, 0, 0),
                (6, 6, 0, 10_640, 10_640, 10_640),
                (7, 5, 1, 10_496, 10_496, 10_784),
                (8, 6, 1, 10_496, 14_592, 14_880),
            ]
            .into_iter()
            .enumerate()
            {
                if stage == 1 {
                    canvas
                        .fill_rect(
                            viewport,
                            Affine::IDENTITY,
                            viewport,
                            Color::rgba(10, 20, 30, 128),
                        )
                        .unwrap();
                } else if stage == 2 {
                    canvas
                        .fill_rect(
                            Rect::new(32.0, 16.0, 3.0, 3.0),
                            Affine::IDENTITY,
                            Rect::new(32.0, 16.0, 3.0, 3.0),
                            Color::rgb(70, 90, 120),
                        )
                        .unwrap();
                } else if stage == 3 {
                    canvas
                        .fill_rect(
                            Rect::new(0.375, 0.375, 15.25, 15.25),
                            Affine::IDENTITY,
                            Rect::new(0.0, 0.0, 16.0, 16.0),
                            Color::rgba(80, 160, 20, 90),
                        )
                        .unwrap();
                }
                gpu.set_tile_proofs(false);
                let reference = readback(&mut gpu, &canvas);
                let sampled = gpu.stats();
                assert_eq!(
                    sampled.sample_evaluations,
                    if stage == 0 { 0 } else { 10_640 }
                );
                assert_eq!(sampled.sample_draw_evaluations, sampled_sources);
                assert_eq!(sampled.tile_references, original);
                gpu.set_tile_proofs(true);
                assert_eq!(
                    readback(&mut gpu, &canvas),
                    reference,
                    "HDR={hdr}, stage={stage}"
                );
                let stats = gpu.stats();
                assert_eq!(stats.original_tile_references, original);
                assert_eq!(stats.tile_references, references);
                assert_eq!(stats.uniform_tiles, uniform);
                assert_eq!(stats.sample_evaluations, samples);
                assert_eq!(stats.sample_draw_evaluations, sources);
            }
        }
    });
}
