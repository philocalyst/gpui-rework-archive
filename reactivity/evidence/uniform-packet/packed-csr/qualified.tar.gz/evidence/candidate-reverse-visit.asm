
FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=610 frame=72

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c650 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c650:	push   %rbp
  81c651:	push   %r15
  81c653:	push   %r14
  81c655:	push   %r13
  81c657:	push   %r12
  81c659:	push   %rbx
  81c65a:	sub    $0x18,%rsp
  81c65e:	movss  0x8c(%rdi),%xmm3
  81c666:	movss  -0x76d6b2(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c66e:	movaps %xmm3,%xmm1
  81c671:	subss  %xmm0,%xmm1
  81c675:	cvttss2si %xmm1,%rax
  81c67a:	cvttss2si %xmm3,%r8
  81c67f:	mov    %r8,%rcx
  81c682:	sar    $0x3f,%rcx
  81c686:	and    %rax,%rcx
  81c689:	or     %r8,%rcx
  81c68c:	xor    %r9d,%r9d
  81c68f:	xorps  %xmm1,%xmm1
  81c692:	ucomiss %xmm1,%xmm3
  81c695:	cmovb  %r9,%rcx
  81c699:	movss  -0x76d6e1(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c6a1:	ucomiss %xmm2,%xmm3
  81c6a4:	mov    $0xffffffffffffffff,%rax
  81c6ab:	cmova  %rax,%rcx
  81c6af:	movss  0x94(%rdi),%xmm3
  81c6b7:	mov    %rcx,%r8
  81c6ba:	shr    $0x4,%r8
  81c6be:	movaps %xmm3,%xmm4
  81c6c1:	subss  %xmm0,%xmm4
  81c6c5:	cvttss2si %xmm4,%r10
  81c6ca:	cvttss2si %xmm3,%r11
  81c6cf:	mov    %r11,%rbx
  81c6d2:	sar    $0x3f,%rbx
  81c6d6:	and    %r10,%rbx
  81c6d9:	or     %r11,%rbx
  81c6dc:	ucomiss %xmm1,%xmm3
  81c6df:	cmovb  %r9,%rbx
  81c6e3:	ucomiss %xmm2,%xmm3
  81c6e6:	cmova  %rax,%rbx
  81c6ea:	mov    %rsi,0x10(%rsp)
  81c6ef:	lea    (%rcx,%rbx,1),%r9
  81c6f3:	dec    %r9
  81c6f6:	shr    $0x4,%r9
  81c6fa:	cmp    %r9,%r8
  81c6fd:	jbe    81c70e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c6ff:	add    $0x18,%rsp
  81c703:	pop    %rbx
  81c704:	pop    %r12
  81c706:	pop    %r13
  81c708:	pop    %r14
  81c70a:	pop    %r15
  81c70c:	pop    %rbp
  81c70d:	ret
  81c70e:	movss  0x88(%rdi),%xmm3
  81c716:	movaps %xmm3,%xmm4
  81c719:	subss  %xmm0,%xmm4
  81c71d:	cvttss2si %xmm4,%rsi
  81c722:	cvttss2si %xmm3,%r10
  81c727:	mov    %r10,%rcx
  81c72a:	sar    $0x3f,%rcx
  81c72e:	and    %rsi,%rcx
  81c731:	or     %r10,%rcx
  81c734:	xor    %esi,%esi
  81c736:	ucomiss %xmm1,%xmm3
  81c739:	cmovb  %rsi,%rcx
  81c73d:	ucomiss %xmm2,%xmm3
  81c740:	cmova  %rax,%rcx
  81c744:	movss  0x90(%rdi),%xmm3
  81c74c:	mov    %rcx,%rbx
  81c74f:	shr    $0x4,%rbx
  81c753:	movaps %xmm3,%xmm4
  81c756:	subss  %xmm0,%xmm4
  81c75a:	cvttss2si %xmm4,%rdi
  81c75f:	cvttss2si %xmm3,%r10
  81c764:	mov    %r10,%r11
  81c767:	sar    $0x3f,%r11
  81c76b:	and    %rdi,%r11
  81c76e:	or     %r10,%r11
  81c771:	ucomiss %xmm1,%xmm3
  81c774:	cmovb  %rsi,%r11
  81c778:	ucomiss %xmm2,%xmm3
  81c77b:	cmova  %rax,%r11
  81c77f:	add    %rcx,%r11
  81c782:	dec    %r11
  81c785:	shr    $0x4,%r11
  81c789:	mov    %rbx,0x8(%rsp)
  81c78e:	cmp    %r11,%rbx
  81c791:	jbe    81c7bd <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c793:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c7a0:	mov    %r8,%rax
  81c7a3:	cmp    %r9,%r8
  81c7a6:	adc    $0x0,%r8
  81c7aa:	cmp    %r9,%rax
  81c7ad:	jae    81c6ff <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7b3:	cmp    %r9,%r8
  81c7b6:	jbe    81c7a0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c7b8:	jmp    81c6ff <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c7bd:	mov    (%rdx),%rbx
  81c7c0:	mov    0x8(%rdx),%r14
  81c7c4:	mov    0x10(%rdx),%rdx
  81c7c8:	movabs $0xffff800000,%r15
  81c7d2:	mov    %r9,(%rsp)
  81c7d6:	cs nopw 0x0(%rax,%rax,1)
  81c7e0:	mov    %r8,%r12
  81c7e3:	cmp    %r9,%r8
  81c7e6:	adc    $0x0,%r8
  81c7ea:	mov    %r12,%r13
  81c7ed:	imul   0x10(%rsp),%r13
  81c7f3:	mov    0x8(%rsp),%r10
  81c7f8:	mov    %r10,%rbp
  81c7fb:	nopl   0x0(%rax,%rax,1)
  81c800:	cmp    %r11,%r10
  81c803:	adc    $0x0,%rbp
  81c807:	lea    (%r10,%r13,1),%rdi
  81c80b:	mov    0x10(%rbx),%rax
  81c80f:	cmp    %rax,%rdi
  81c812:	jae    81c88f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x23f>
  81c814:	mov    0x8(%rbx),%rcx
  81c818:	movslq 0x4(%rcx,%rdi,8),%rsi
  81c81d:	test   %rsi,%rsi
  81c820:	js     81c867 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x217>
  81c822:	mov    (%rcx,%rdi,8),%eax
  81c825:	shl    $0x20,%rsi
  81c829:	or     %rax,%rsi
  81c82c:	test   %r15,%rsi
  81c82f:	je     81c867 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x217>
  81c831:	mov    %rsi,%r9
  81c834:	shr    $0x17,%r9
  81c838:	and    $0x7fffff,%eax
  81c83d:	and    $0x1ffff,%r9d
  81c844:	add    %r9,%rax
  81c847:	dec    %rax
  81c84a:	add    $0xffffffffff800000,%rsi
  81c851:	mov    %rsi,(%rcx,%rdi,8)
  81c855:	mov    0x10(%r14),%rcx
  81c859:	cmp    %rcx,%rax
  81c85c:	jae    81c89f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x24f>
  81c85e:	mov    0x8(%r14),%rcx
  81c862:	mov    (%rdx),%esi
  81c864:	mov    %esi,(%rcx,%rax,4)
  81c867:	cmp    %r11,%r10
  81c86a:	jae    81c874 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x224>
  81c86c:	mov    %rbp,%r10
  81c86f:	cmp    %r11,%rbp
  81c872:	jbe    81c800 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1b0>
  81c874:	mov    (%rsp),%r9
  81c878:	cmp    %r9,%r12
  81c87b:	jae    81c6ff <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c881:	cmp    %r9,%r8
  81c884:	jbe    81c7e0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x190>
  81c88a:	jmp    81c6ff <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c88f:	lea    0x611992(%rip),%rdx        # e2e228 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c896:	mov    %rax,%rsi
  81c899:	call   *0x663321(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
  81c89f:	lea    0x61199a(%rip),%rdx        # e2e240 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c8a6:	mov    %rax,%rdi
  81c8a9:	mov    %rcx,%rsi
  81c8ac:	call   *0x66330e(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
