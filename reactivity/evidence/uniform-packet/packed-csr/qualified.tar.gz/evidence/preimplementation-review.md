# Shipping retained-count CSR representation: preimplementation review

Source reviewed: exact shipping 7a5e1619a27010ec63f6c27506a6d1fcd113f67c.
This is a separate new tree, /tmp/gpui-packed-csr-sol, and target
/tmp/gpui-packed-csr-target. It carries no 299c constant/prefix/whole-bounds
features, no shared-sample rewrite and no fused resource walk. The shipping
resource patch walk remains. No timing, code-size or speed result is inferred.

## Retained suffix theorem

For one tile, list all forward visit events in painter order. A draw has at most
one event for that tile: visit's nested rectangular tile loops contain each tile
once. Preserve the existing tile_proofs && full_tile predicate byte for byte.
Before any accepted proof, c equals the number of events seen. Every accepted
proof resets c to one and records its draw address. Every other event increments
c. Thus c is exactly the length of the suffix beginning at the latest accepted
proof, or the entire event list if there was no proof. This is a combinatorial
statement about the existing accepted predicate, not a new geometry theorem.

The existing cursor ordinal filters reverse visits at or after that latest proof.
Instead accept the first c reverse visits and ignore all later reverse visits.
Those visits are exactly the same suffix. Allocate c reference slots for each
nonuniform tile. With remaining initially c, write its next reverse address into
start + remaining - 1 and decrement remaining. Therefore the stored array is
exactly the existing forward painter order, including the opaque proof itself.
No source-over operation, clear value, float normalization, sample kernel, color
bank, source decode, correction or output mapping changes. In particular no
algebraic regrouping or dropping the clear term is justified or proposed.

Cases: empty c0 writes nothing; no opaque proof keeps every event; proof followed
by transparent/partial geometry keeps proof and every later event; another proof
resets to the later suffix; proof alone (c1) stays the shipping direct uniform
address; later partial/image/mask/rounded events increment c and revoke direct
uniform classification. Those sources never newly qualify as opaque proofs.
A proof's bounds may visit additional tiles: each event is classified only by
existing full_tile on that actual tile, so unproven events remain retained.
Diagnostic proof-disable retains the entire event list. Compact and inline record
address reconstruction, private common addresses and bank prefix are unchanged.

## Three phases and bit budget

Retain Vec<[u32;2]> and its explicit low/high words. Do not reinterpret a Vec<u64>
as GPU words, which would introduce a new host-endianness assumption.
Forward phase: x is latest proved address; y is count low17 plus opaque-seen bit31.
MAX_DRAWS=65536 fits17 bits, including its inclusive maximum. Count additions cannot
reach opaque bit31. A proof stores [address, opaque|1]; no proof increments only c.

Normalization: opaque && c1 becomes exactly [address,UNIFORM_TILE]. Other tiles use
packed integer start[0..22], remaining[23..39], retained_count[40..56], tags[57..63].
No nonuniform tags are needed initially. Start's inclusive empty end at
MAX_REFERENCES=4194304 fits23 bits; both count and remaining fit17 bits. The three
fields total57 bits and leave bit63 clear for nonuniform tiles. Const assertions
must check actual caps and masks, not merely assume them. Prefix sum is at most
original visits <= MAX_REFERENCES because suffix filtering only removes events.
An occupied range has start+c <= MAX_REFERENCES, so start+c-1 is a valid index.
The final empty tile can have start=MAX_REFERENCES with c0 and no dereference.

Reverse: FIRST CHECK UNIFORM. Its x word must remain the original full address;
INLINE_RECORD bit31 overlaps packed remaining and would otherwise decode as256.
For nonuniform remaining>0, subtracting 1<<23 decrements remaining without borrowing
from start or retained_count. At remaining0 skip. Each normalized tile receives
exactly c later reverse events by the suffix theorem, so remaining reaches0.
Use named private encode/decode/consume helpers rather than spread magic shifts.
Helpers may share one source of constants; there is no SIMD/scalar policy split.
All fields can be reconstructed with safe u64 shifts/or and explicit u32 halves.

Shader: check UNIFORM using ybit31 before decoding x. Otherwise start=x&0x7fffff;
count=(y>>8)&0x1ffff; end=start+count. During upload remaining is0, but the masks
make count/start independent of remaining even if a CPU bug leaves it nonzero.
The empty test must use decoded count/range, never raw x==y. Existing banked and
ordinary paths consume the same decoded [start,end] range, preserving iteration
order and all sample arithmetic. Generated WGSL/SPIR-V must be inspected: two
masks, a shift and addition are an actual shader cost, not free compression.
No per-fragment count can overflow start+count under admission bounds.

## Caps, counters, failures and memory

Keep checked total original visit admission before per-draw tile mutation, even
when a later proof could erase all old references. The reference cap is logical
original work, not surviving allocation. Keep forward ordinal for validation,
observer and Stats.draws; remove only bin_draw's ordinal argument and reverse
ordinal/cutoff. Preserve compact group's validation order and errors.

Normalize by row/chunk traversal. A row's height is min(16,height-row*16), and a
column's width is min(16,width-column*16). Nonuniform c>0 contributes area*16
samples and area*16*c sample_draw calls; uniform increments uniform_tiles only;
empty contributes zero. Counters are u64: at most MAX_PIXELS*16*MAX_DRAWS =2^44,
within u64, and clipped per-tile area <=256. Accumulate references excluding
uniform tiles exactly as shipping. There is no final counter walk or lazy Stats
getter over scratch ranges. Publish the complete local counters only at the
existing final successful self.stats assignment, preserving last successful Stats
after every failed preparation and existing packet revocation behavior.

Delete the cursors Vec field, initializer, clearing/resizing, forward stores,
reverse loads and capacity term. All packet bytes stay8/tile; reference count and
upload length are unchanged for equivalent scenes. CPU retained index capacity
must change by exactly the removed cursor capacity*4 for a matched allocation
history; this intended memory diagnostic change is the only anticipated Stats
inequality. No retained field, allocation, dependency or public exception replaces
it. Draw/resource buffers and ordinary full warm uploads remain charged.

## Required adversarial evidence before qualification

1. Independent reference-list oracle, comparing actual CSR addresses/order with a
simple forward retained-suffix model, including interleaved nonvisits, all proof
patterns, compact/inline addresses, c0/c1/c65536 and start0/start4194304 endpoints.
Test packed round trips and decrement field isolation, including uniform inline
address overlap. Actual wrong reverse-selection/count faults must fail controls.
2. Existing source proof oracle and packet cap controls retained, plus partial
right/bottom edges, empty tiles, proof disable, repeated opaque resets, banks,
queued frames, failed admission, image/mask/rounded and SDR/HDR public readbacks.
Compare named images and every work counter to shipping, explicitly separately
charge cpu_index_capacity_bytes instead of demanding impossible capacity equality.
3. Original fixed fixture8773146... 52 named captures exact against frozen shipping
reference. Full named suite matching by labels, not indices across changed suites.
4. Default/fallback/offline strict tests, validator and Apple/Windows cross checks;
whole linked code and render/bin/helper frames, core count, packet/upload/heap
ledger. Match source path, lock, compiler, root flags, opt3 and actual fresh:false
artifacts for both shipping and successor. No timed campaign until separate review
and preregistration. All unfavorable costs and failed attempts stay in evidence.

## Adversarial source follow-up

PreparedScene's dimensions/config/clear are publicly mutable headers, not an
identity witness. Its DisplayList reference and original extent are private and
borrowed. groups(), placements() and draws() derive from the same immutable list;
no caller-provided list lengths or arbitrary reverse sequence is trusted. Keep
all current header/target/clear checks and every validate_draw call. A mutated
width/height can reject draws against the new target before any reverse filling;
if admitted, both visits still use the same prepared draw and columns. No cache
or scene-identity assumption is introduced. Safe borrowing prevents concurrent
DisplayList mutation while this view is rendered.

visit enumerates inclusive integer row and column intervals, each index once:
within one row column indices are strictly increasing; different rows differ by
columns. Admission bounds guarantee column indices below columns, so two rows
cannot alias a tile. Existing integer bounds originate in the private display
list, and validate_draw excludes empty/invalid/out-of-target bounds. Fractional
standalone PreparedDraw helpers are not a public scene constructor; tests should
still exercise legal fractional bounds and compare tile_count with visit count.
No proof requires that bounds equal visible geometry or that every visit shades.
A malformed source rejected by existing validation never reaches normalization
or reverse fill. Mid-forward errors may leave scratch ranges modified exactly as
before, but previous successful public Stats remain untouched and packet eligibility
is revoked by the existing entry path. Next render clears the entire ranges
vector, so forward opaque-seen state cannot survive an error into a new packet.
