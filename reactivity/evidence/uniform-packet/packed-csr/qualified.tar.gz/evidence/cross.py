from pathlib import Path
import hashlib,json,os,subprocess
ROOT=Path('/tmp/gpui-packed-csr-sol');OUT=Path('/tmp/gpui-packed-csr-evidence')
env=dict(os.environ);env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
env.update(CARGO_BUILD_JOBS='1',RUSTC_BOOTSTRAP='1',GPUI_SPIRV_VAL='/tmp/gpui-qualified-spirv-root/bin/spirv-val')
result={}
for name,target in [('apple','aarch64-apple-darwin'),('msvc','x86_64-pc-windows-msvc')]:
    env['CARGO_TARGET_DIR']='/tmp/gpui-packed-csr-'+name+'-target'
    args=['cargo','check','--offline','--locked','-p','gpui_gpu','--lib','--all-features','--target',target,'-Zbuild-std=std,panic_abort']
    with (OUT/(name+'.log')).open('w') as log:
        p=subprocess.run(args,cwd=ROOT/'reactivity',env=env,stdout=log,stderr=subprocess.STDOUT)
    (OUT/(name+'.exit')).write_text(str(p.returncode)+'\n')
    result[name]={'target':target,'args':args,'returncode':p.returncode}
    (OUT/'cross-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    assert p.returncode==0,name
    print(name+' compile PASS; no runtime/link inference',flush=True)
