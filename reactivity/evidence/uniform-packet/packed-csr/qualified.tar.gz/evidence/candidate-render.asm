
FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9385 frame=1400

/tmp/gpui-packed-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e150 <<gpui_gpu::renderer::RendererState>::render>:
  81e150:	push   %rbp
  81e151:	push   %r15
  81e153:	push   %r14
  81e155:	push   %r13
  81e157:	push   %r12
  81e159:	push   %rbx
  81e15a:	sub    $0x548,%rsp
  81e161:	mov    0x210(%rsi),%rax
  81e168:	mov    0x18(%rdx),%r9
  81e16c:	cmp    %r9,%rax
  81e16f:	je     81e18d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e171:	mov    0x10(%rax),%r10
  81e175:	cmp    0x10(%r9),%r10
  81e179:	jne    81e25b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e17f:	mov    0x18(%rax),%rax
  81e183:	cmp    0x18(%r9),%rax
  81e187:	jne    81e25b <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e18d:	lea    0x318(%rsi),%rbx
  81e194:	mov    0x318(%rsi),%rax
  81e19b:	test   %rax,%rax
  81e19e:	je     81e1cd <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e1a0:	lock decq (%rax)
  81e1a4:	jne    81e1cd <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e1a6:	mov    %rdi,%r14
  81e1a9:	mov    %rbx,%rdi
  81e1ac:	mov    %rsi,%r12
  81e1af:	mov    %r8,%r13
  81e1b2:	mov    %rdx,%r15
  81e1b5:	mov    %rcx,%rbp
  81e1b8:	call   *0x661a22(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  81e1be:	mov    %rbp,%rcx
  81e1c1:	mov    %r15,%rdx
  81e1c4:	mov    %r13,%r8
  81e1c7:	mov    %r12,%rsi
  81e1ca:	mov    %r14,%rdi
  81e1cd:	movq   $0x0,0x318(%rsi)
  81e1d8:	mov    (%rcx),%r12d
  81e1db:	mov    0x8(%rcx),%r9d
  81e1df:	movzbl 0xd(%rcx),%eax
  81e1e3:	test   %r9d,%r9d
  81e1e6:	sets   %r10b
  81e1ea:	and    $0x7fffffff,%r9d
  81e1f1:	lea    -0x800000(%r9),%r11d
  81e1f8:	cmp    $0x7f000000,%r11d
  81e1ff:	setb   %r11b
  81e203:	and    %r10b,%r11b
  81e206:	lea    -0x1(%r9),%ebp
  81e20a:	cmp    $0x7fffff,%ebp
  81e210:	setb   %bpl
  81e214:	and    %r10b,%bpl
  81e217:	test   %r9d,%r9d
  81e21a:	sete   %r10b
  81e21e:	cmp    $0x7f800000,%r9d
  81e225:	sete   %r14b
  81e229:	or     %r10b,%r14b
  81e22c:	cmp    $0x7f800001,%r9d
  81e233:	setge  %r9b
  81e237:	or     %r14b,%r9b
  81e23a:	or     %bpl,%r9b
  81e23d:	test   %r12d,%r12d
  81e240:	setne  %r10b
  81e244:	and    %al,%r10b
  81e247:	or     %r11b,%r10b
  81e24a:	or     %r9b,%r10b
  81e24d:	test   $0x1,%r10b
  81e251:	je     81e276 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e253:	movl   $0x3,(%rdi)
  81e259:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e25b:	movl   $0x4,(%rdi)
  81e261:	mov    %rdi,%rax
  81e264:	add    $0x548,%rsp
  81e26b:	pop    %rbx
  81e26c:	pop    %r12
  81e26e:	pop    %r13
  81e270:	pop    %r14
  81e272:	pop    %r15
  81e274:	pop    %rbp
  81e275:	ret
  81e276:	movd   0x4(%rcx),%xmm2
  81e27b:	movzbl 0xc(%rcx),%ebp
  81e27f:	test   $0x1,%r12b
  81e283:	je     81e2fb <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e285:	movd   %xmm2,%r9d
  81e28a:	test   %r9d,%r9d
  81e28d:	sets   %r10b
  81e291:	and    $0x7fffffff,%r9d
  81e298:	lea    -0x800000(%r9),%r11d
  81e29f:	cmp    $0x7f000000,%r11d
  81e2a6:	setb   %r11b
  81e2aa:	and    %r10b,%r11b
  81e2ad:	lea    -0x1(%r9),%r14d
  81e2b1:	cmp    $0x7fffff,%r14d
  81e2b8:	setb   %r14b
  81e2bc:	and    %r10b,%r14b
  81e2bf:	test   %r9d,%r9d
  81e2c2:	sete   %r10b
  81e2c6:	cmp    $0x7f800000,%r9d
  81e2cd:	sete   %r15b
  81e2d1:	or     %r10b,%r15b
  81e2d4:	cmp    $0x7f800001,%r9d
  81e2db:	setge  %r9b
  81e2df:	or     %r15b,%r9b
  81e2e2:	or     %r14b,%r9b
  81e2e5:	or     %r11b,%r9b
  81e2e8:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ee:	ucomiss -0x76f449(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e2f5:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2fb:	mov    0x28(%rcx),%r14d
  81e2ff:	cmp    %r14d,0x20(%r8)
  81e303:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e309:	mov    0x2c(%rcx),%r15d
  81e30d:	cmp    %r15d,0x24(%r8)
  81e311:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e317:	mov    0x38(%r8),%r13d
  81e31b:	cmp    0x20(%rdx),%r13d
  81e31f:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e325:	cmp    $0x4c,%r13d
  81e329:	jne    81e34e <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e32b:	movq   0x3c(%r8),%xmm0
  81e331:	movq   0x24(%rdx),%xmm1
  81e336:	pcmpeqd %xmm0,%xmm1
  81e33a:	pshufd $0x50,%xmm1,%xmm0
  81e33f:	movmskpd %xmm0,%r9d
  81e344:	cmp    $0x3,%r9d
  81e348:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e34e:	cmp    $0x4000,%r15d
  81e355:	ja     81e38b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e357:	cmp    $0x4000,%r14d
  81e35e:	ja     81e38b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e360:	mov    %r15,%r9
  81e363:	imul   %r14,%r9
  81e367:	add    $0xfffffffffeffffff,%r9
  81e36e:	cmp    $0xffffffffff000000,%r9
  81e375:	jb     81e38b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e377:	mov    0x10(%rcx),%r11
  81e37b:	mov    0x80(%r11),%r10
  81e382:	cmp    $0x10000,%r10
  81e389:	jbe    81e396 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e38b:	movl   $0x6,(%rdi)
  81e391:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e396:	movd   0x18(%rcx),%xmm0
  81e39b:	movd   %xmm0,%r9d
  81e3a0:	and    $0x7fffffff,%r9d
  81e3a7:	cmp    $0x7f7fffff,%r9d
  81e3ae:	jg     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3b4:	pand   -0x770c3c(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3bc:	ucomiss -0x76f2bf(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3c3:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3c9:	movd   0x1c(%rcx),%xmm0
  81e3ce:	movd   %xmm0,%r9d
  81e3d3:	and    $0x7fffffff,%r9d
  81e3da:	cmp    $0x7f7fffff,%r9d
  81e3e1:	jg     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3e7:	pand   -0x770c6f(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3ef:	ucomiss -0x76f2f2(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3f6:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3fc:	movd   0x20(%rcx),%xmm0
  81e401:	movd   %xmm0,%r9d
  81e406:	and    $0x7fffffff,%r9d
  81e40d:	cmp    $0x7f7fffff,%r9d
  81e414:	jg     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e41a:	pand   -0x770ca2(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e422:	ucomiss -0x76f325(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e429:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e42f:	movd   0x24(%rcx),%xmm0
  81e434:	movd   %xmm0,%r9d
  81e439:	and    $0x7fffffff,%r9d
  81e440:	cmp    $0x7f7fffff,%r9d
  81e447:	jg     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e44d:	movdqa -0x770cd5(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e455:	pand   %xmm0,%xmm1
  81e459:	ucomiss -0x76f35c(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e460:	ja     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e466:	xorps  %xmm1,%xmm1
  81e469:	ucomiss %xmm1,%xmm0
  81e46c:	jb     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e472:	movss  -0x76f6fa(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e47a:	ucomiss %xmm0,%xmm1
  81e47d:	jb     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e483:	movzwl 0x30(%rcx),%r9d
  81e488:	mov    %r9w,0x10(%rsp)
  81e48e:	movzwl 0x32(%rcx),%r9d
  81e493:	mov    %r9w,0x18(%rsp)
  81e499:	cmp    $0x28,%r13d
  81e49d:	jne    81e4a9 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e49f:	test   $0x1,%al
  81e4a1:	je     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e4a7:	jmp    81e4c4 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e4a9:	test   $0x1,%al
  81e4ab:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e4b1:	ucomiss -0x76f738(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e4b8:	jne    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e4be:	jp     81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e4c4:	mov    %r11,0xc8(%rsp)
  81e4cc:	mov    %r10,0xc0(%rsp)
  81e4d4:	movss  %xmm1,0x104(%rsp)
  81e4dd:	movd   %xmm2,0x244(%rsp)
  81e4e6:	mov    %rdx,0x108(%rsp)
  81e4ee:	mov    %r8,0x3e8(%rsp)
  81e4f6:	mov    %rdi,0x38(%rsp)
  81e4fb:	lea    0xf(%r14),%rdx
  81e4ff:	shr    $0x4,%rdx
  81e503:	lea    0xf(%r15),%eax
  81e507:	shr    $0x4,%eax
  81e50a:	lea    0x18(%rsi),%rdi
  81e50e:	movq   $0x0,0x28(%rsi)
  81e516:	mov    %rdx,0x58(%rsp)
  81e51b:	imul   %edx,%eax
  81e51e:	mov    %rdi,0x218(%rsp)
  81e526:	mov    %rsi,0x8(%rsp)
  81e52b:	mov    %rax,%rsi
  81e52e:	xor    %edx,%edx
  81e530:	mov    %rcx,0xe8(%rsp)
  81e538:	call   822880 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e53d:	mov    0x8(%rsp),%rax
  81e542:	movq   $0x0,0x10(%rax)
  81e54a:	mov    0xe8(%rsp),%rdi
  81e552:	call   *0x661718(%rip)        # e7fc70 <_DYNAMIC+0x5a8>
  81e558:	mov    %rdx,%rcx
  81e55b:	sub    %rax,%rcx
  81e55e:	cmp    $0x300000,%rcx
  81e565:	jbe    81e577 <<gpui_gpu::renderer::RendererState>::render+0x427>
  81e567:	mov    0x38(%rsp),%rdi
  81e56c:	movl   $0x6,(%rdi)
  81e572:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e577:	mov    %rcx,%rsi
  81e57a:	shr    $0x3,%rcx
  81e57e:	movabs $0xaaaaaaaaaaaaaaab,%rdi
  81e588:	imul   %rcx,%rdi
  81e58c:	mov    %rdi,0x30(%rsp)
  81e591:	mov    %rax,0x380(%rsp)
  81e599:	mov    %rdx,0x378(%rsp)
  81e5a1:	cmp    %rax,%rdx
  81e5a4:	je     81e5d2 <<gpui_gpu::renderer::RendererState>::render+0x482>
  81e5a6:	mov    $0xaaaaaaab,%eax
  81e5ab:	imul   %rax,%rsi
  81e5af:	shr    $0x2a,%rsi
  81e5b3:	mov    0x30(%rsp),%rcx
  81e5b8:	mov    %ecx,%eax
  81e5ba:	and    $0x3f,%eax
  81e5bd:	add    %rcx,%rsi
  81e5c0:	cmp    $0x1,%rax
  81e5c4:	sbb    $0xffffffffffffffff,%rsi
  81e5c8:	inc    %rsi
  81e5cb:	mov    %rsi,0x50(%rsp)
  81e5d0:	jmp    81e5db <<gpui_gpu::renderer::RendererState>::render+0x48b>
  81e5d2:	movq   $0x0,0x50(%rsp)
  81e5db:	mov    0xc8(%rsp),%rax
  81e5e3:	mov    0x98(%rax),%rcx
  81e5ea:	add    0xb0(%rax),%rcx
  81e5f1:	mov    %rax,0x110(%rsp)
  81e5f9:	movzwl 0x10(%rsp),%eax
  81e5fe:	mov    %ax,0x130(%rsp)
  81e606:	movzwl 0x18(%rsp),%eax
  81e60b:	mov    %ax,0x132(%rsp)
  81e613:	movq   $0x0,0x118(%rsp)
  81e61f:	mov    0xc0(%rsp),%rax
  81e627:	mov    %rax,0x120(%rsp)
  81e62f:	mov    %rcx,0x210(%rsp)
  81e637:	mov    %rcx,0x128(%rsp)
  81e63f:	mov    0x8(%rsp),%rax
  81e644:	movzbl 0x329(%rax),%edx
  81e64b:	lea    0x428(%rsp),%rdi
  81e653:	lea    0x110(%rsp),%rsi
  81e65b:	call   81c8c0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e660:	mov    0x428(%rsp),%eax
  81e667:	cmp    $0xffffffff,%eax
  81e66a:	je     81e69a <<gpui_gpu::renderer::RendererState>::render+0x54a>
  81e66c:	mov    0x42c(%rsp),%ecx
  81e673:	mov    0x430(%rsp),%rdx
  81e67b:	movups 0x438(%rsp),%xmm0
  81e683:	mov    0x38(%rsp),%rdi
  81e688:	movups %xmm0,0x10(%rdi)
  81e68c:	mov    %eax,(%rdi)
  81e68e:	mov    %ecx,0x4(%rdi)
  81e691:	mov    %rdx,0x8(%rdi)
  81e695:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e69a:	mov    0x430(%rsp),%rdx
  81e6a2:	add    0x50(%rsp),%rdx
  81e6a7:	mov    0x8(%rsp),%rdi
  81e6ac:	mov    0x10(%rdi),%rsi
  81e6b0:	mov    $0x4,%ecx
  81e6b5:	mov    $0x10,%r8d
  81e6bb:	call   823c40 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e6c0:	cmp    $0xffffffffffffffff,%rax
  81e6c4:	jne    81e567 <<gpui_gpu::renderer::RendererState>::render+0x417>
  81e6ca:	movzwl 0x10(%rsp),%eax
  81e6cf:	mov    %eax,0x10(%rsp)
  81e6d3:	movzwl 0x18(%rsp),%eax
  81e6d8:	mov    %eax,0x78(%rsp)
  81e6dc:	mov    0x8(%rsp),%rdi
  81e6e1:	mov    0xe8(%rsp),%rsi
  81e6e9:	mov    0x30(%rsp),%rdx
  81e6ee:	call   825ba0 <gpui_gpu::renderer::slots::write_prefix>
  81e6f3:	mov    0x8(%rsp),%rax
  81e6f8:	movq   $0x0,0x58(%rax)
  81e700:	cmpq   $0x0,0x48(%rax)
  81e705:	jne    81e716 <<gpui_gpu::renderer::RendererState>::render+0x5c6>
  81e707:	mov    0x8(%rsp),%rax
  81e70c:	lea    0x48(%rax),%rdi
  81e710:	call   *0x661562(%rip)        # e7fc78 <_DYNAMIC+0x5b0>
  81e716:	mov    0x8(%rsp),%rax
  81e71b:	mov    0x50(%rax),%rcx
  81e71f:	xorps  %xmm0,%xmm0
  81e722:	movups %xmm0,0x10(%rcx)
  81e726:	movups %xmm0,(%rcx)
  81e729:	movq   $0x1,0x58(%rax)
  81e731:	lea    0x2e0(%rax),%rdi
  81e738:	call   825550 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e73d:	mov    0x78(%rsp),%ecx
  81e741:	shl    $0x10,%ecx
  81e744:	add    0x10(%rsp),%ecx
  81e748:	mov    0xc8(%rsp),%rax
  81e750:	mov    %rax,0x388(%rsp)
  81e758:	movq   $0x0,0x390(%rsp)
  81e764:	mov    0xc0(%rsp),%rax
  81e76c:	mov    %rax,0x398(%rsp)
  81e774:	mov    0x210(%rsp),%rax
  81e77c:	mov    %rax,0x3a0(%rsp)
  81e784:	mov    %ecx,0x78(%rsp)
  81e788:	mov    %ecx,0x3a8(%rsp)
  81e78f:	lea    0x248(%rsp),%rdi
  81e797:	lea    0x388(%rsp),%rsi
  81e79f:	call   *0x6614db(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81e7a5:	mov    0x248(%rsp),%rax
  81e7ad:	mov    %rax,0x18(%rsp)
  81e7b2:	test   %rax,%rax
  81e7b5:	je     81f519 <<gpui_gpu::renderer::RendererState>::render+0x13c9>
  81e7bb:	movq   $0x0,0xe0(%rsp)
  81e7c7:	movq   $0x0,0x10(%rsp)
  81e7d0:	movq   $0x0,0xb8(%rsp)
  81e7dc:	movq   $0x0,0x200(%rsp)
  81e7e8:	movq   $0x0,0x208(%rsp)
  81e7f4:	mov    0x250(%rsp),%rcx
  81e7fc:	mov    0x258(%rsp),%rdx
  81e804:	mov    %rdx,0xa0(%rsp)
  81e80c:	lea    0x260(%rsp),%rdi
  81e814:	movups (%rdi),%xmm0
  81e817:	movups 0x10(%rdi),%xmm1
  81e81b:	movups 0x20(%rdi),%xmm2
  81e81f:	movaps %xmm2,0x2f0(%rsp)
  81e827:	movaps %xmm1,0x2e0(%rsp)
  81e82f:	movaps %xmm0,0x2d0(%rsp)
  81e837:	lea    0x290(%rsp),%r8
  81e83f:	movups (%r8),%xmm0
  81e843:	movaps %xmm0,0x4f0(%rsp)
  81e84b:	movups 0x40(%rdi),%xmm0
  81e84f:	movaps %xmm0,0x3f0(%rsp)
  81e857:	mov    0x8(%rsp),%rax
  81e85c:	movzbl 0x329(%rax),%esi
  81e863:	mov    0x18(%rsp),%rax
  81e868:	mov    %rax,0x110(%rsp)
  81e870:	mov    %rcx,0x28(%rsp)
  81e875:	mov    %rcx,0x118(%rsp)
  81e87d:	mov    %rdx,0x120(%rsp)
  81e885:	movups (%rdi),%xmm0
  81e888:	movups 0x10(%rdi),%xmm1
  81e88c:	movups 0x20(%rdi),%xmm2
  81e890:	lea    0x128(%rsp),%rax
  81e898:	movups %xmm2,0x20(%rax)
  81e89c:	movups %xmm1,0x10(%rax)
  81e8a0:	movups %xmm0,(%rax)
  81e8a3:	movups (%r8),%xmm0
  81e8a7:	movups %xmm0,0x30(%rax)
  81e8ab:	movups 0x40(%rdi),%xmm0
  81e8af:	movups %xmm0,0x40(%rax)
  81e8b3:	lea    0x110(%rsp),%rdi
  81e8bb:	call   8215e0 <gpui_gpu::renderer::compact_group>
  81e8c0:	mov    %al,0x40(%rsp)
  81e8c4:	lea    0x260(%rsp),%rsi
  81e8cc:	movups (%rsi),%xmm0
  81e8cf:	movups 0x10(%rsi),%xmm1
  81e8d3:	movups 0x20(%rsi),%xmm2
  81e8d7:	movaps %xmm0,0x500(%rsp)
  81e8df:	movaps %xmm1,0x510(%rsp)
  81e8e7:	movaps %xmm2,0x520(%rsp)
  81e8ef:	lea    0x290(%rsp),%rdx
  81e8f7:	movups (%rdx),%xmm0
  81e8fa:	movaps %xmm0,0x530(%rsp)
  81e902:	mov    0x8(%rsp),%rdi
  81e907:	call   81d4f0 <<gpui_gpu::renderer::RendererState>::correction>
  81e90c:	mov    %eax,0x7c(%rsp)
  81e910:	mov    0xa0(%rsp),%rax
  81e918:	lea    0x0(,%rax,4),%rax
  81e920:	mov    %rax,0x370(%rsp)
  81e928:	cmpb   $0x0,0x40(%rsp)
  81e92d:	je     81eb0b <<gpui_gpu::renderer::RendererState>::render+0x9bb>
  81e933:	mov    0x28(%rsp),%rcx
  81e938:	mov    0xa0(%rsp),%rax
  81e940:	lea    (%rcx,%rax,4),%rax
  81e944:	mov    %rcx,0x408(%rsp)
  81e94c:	mov    %rax,0x410(%rsp)
  81e954:	mov    0x18(%rsp),%rax
  81e959:	mov    %rax,0x418(%rsp)
  81e961:	movq   $0x0,0x420(%rsp)
  81e96d:	lea    0x300(%rsp),%rdi
  81e975:	lea    0x408(%rsp),%rsi
  81e97d:	call   821c70 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e982:	cmpb   $0xff,0x308(%rsp)
  81e98a:	je     81f04a <<gpui_gpu::renderer::RendererState>::render+0xefa>
  81e990:	xorps  %xmm0,%xmm0
  81e993:	movaps %xmm0,0x80(%rsp)
  81e99b:	movaps %xmm0,0x60(%rsp)
  81e9a0:	mov    0x300(%rsp),%rdx
  81e9a8:	add    0xb8(%rsp),%rdx
  81e9b0:	lea    0x308(%rsp),%rsi
  81e9b8:	movups 0x38(%rsi),%xmm0
  81e9bc:	lea    0x128(%rsp),%rcx
  81e9c4:	movups %xmm0,0x20(%rcx)
  81e9c8:	movups 0x48(%rsi),%xmm0
  81e9cc:	movups %xmm0,0x70(%rcx)
  81e9d0:	mov    0x30(%rsi),%rax
  81e9d4:	mov    %rax,0x140(%rsp)
  81e9dc:	movups (%rsi),%xmm0
  81e9df:	movups 0x10(%rsi),%xmm1
  81e9e3:	movups 0x20(%rsi),%xmm2
  81e9e7:	movaps %xmm2,0x130(%rsp)
  81e9ef:	movaps %xmm1,0x120(%rsp)
  81e9f7:	movaps %xmm0,0x110(%rsp)
  81e9ff:	lea    0x260(%rsp),%rax
  81ea07:	movups 0x40(%rax),%xmm0
  81ea0b:	movups %xmm0,0x80(%rcx)
  81ea12:	movups (%rax),%xmm0
  81ea15:	movups 0x10(%rax),%xmm1
  81ea19:	movups 0x20(%rax),%xmm2
  81ea1d:	movups %xmm2,0x50(%rcx)
  81ea21:	movups %xmm1,0x40(%rcx)
  81ea25:	movups %xmm0,0x30(%rcx)
  81ea29:	lea    0x290(%rsp),%rax
  81ea31:	movups (%rax),%xmm0
  81ea34:	movups %xmm0,0x60(%rcx)
  81ea38:	lea    0x220(%rsp),%rdi
  81ea40:	lea    0x110(%rsp),%rsi
  81ea48:	mov    %r14d,%ecx
  81ea4b:	mov    %r15d,%r8d
  81ea4e:	call   821630 <gpui_gpu::renderer::validate_draw>
  81ea53:	mov    0x220(%rsp),%ecx
  81ea5a:	mov    0x224(%rsp),%rax
  81ea62:	cmp    $0xffffffff,%ecx
  81ea65:	jne    81f5d4 <<gpui_gpu::renderer::RendererState>::render+0x1484>
  81ea6b:	mov    %eax,%ecx
  81ea6d:	shr    $0x20,%rax
  81ea71:	movd   %ecx,%xmm0
  81ea75:	movaps 0x80(%rsp),%xmm2
  81ea7d:	movaps %xmm2,%xmm1
  81ea80:	maxss  %xmm0,%xmm1
  81ea84:	movaps %xmm1,%xmm3
  81ea87:	cmpunordss %xmm1,%xmm3
  81ea8c:	movaps %xmm3,%xmm0
  81ea8f:	andnps %xmm1,%xmm0
  81ea92:	andps  %xmm2,%xmm3
  81ea95:	orps   %xmm0,%xmm3
  81ea98:	movaps %xmm3,0x40(%rsp)
  81ea9d:	movd   %eax,%xmm0
  81eaa1:	movaps 0x60(%rsp),%xmm2
  81eaa6:	movaps %xmm2,%xmm1
  81eaa9:	maxss  %xmm0,%xmm1
  81eaad:	movaps %xmm1,%xmm3
  81eab0:	cmpunordss %xmm1,%xmm3
  81eab5:	movaps %xmm3,%xmm0
  81eab8:	andnps %xmm1,%xmm0
  81eabb:	andps  %xmm2,%xmm3
  81eabe:	orps   %xmm0,%xmm3
  81eac1:	movaps %xmm3,0x90(%rsp)
  81eac9:	lea    0x300(%rsp),%rdi
  81ead1:	lea    0x408(%rsp),%rsi
  81ead9:	call   821c70 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81eade:	cmpb   $0xff,0x308(%rsp)
  81eae6:	movaps 0x40(%rsp),%xmm0
  81eaeb:	movaps %xmm0,0x80(%rsp)
  81eaf3:	movaps 0x90(%rsp),%xmm0
  81eafb:	movaps %xmm0,0x60(%rsp)
  81eb00:	jne    81e9a0 <<gpui_gpu::renderer::RendererState>::render+0x850>
  81eb06:	jmp    81f05a <<gpui_gpu::renderer::RendererState>::render+0xf0a>
  81eb0b:	cmpq   $0x0,0xa0(%rsp)
  81eb14:	je     81f4c3 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81eb1a:	mov    0x7c(%rsp),%eax
  81eb1e:	or     $0x80000000,%eax
  81eb23:	mov    %eax,0x240(%rsp)
  81eb2a:	movq   $0x0,0x90(%rsp)
  81eb36:	mov    0x28(%rsp),%rax
  81eb3b:	mov    0x90(%rsp),%rcx
  81eb43:	mov    (%rax,%rcx,1),%edx
  81eb46:	lea    0x110(%rsp),%rdi
  81eb4e:	mov    0x18(%rsp),%rsi
  81eb53:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81eb58:	movzbl 0x110(%rsp),%edi
  81eb60:	lea    0x111(%rsp),%rdx
  81eb68:	mov    (%rdx),%eax
  81eb6a:	mov    0x3(%rdx),%ecx
  81eb6d:	lea    0x460(%rsp),%rsi
  81eb75:	mov    %ecx,-0x34(%rsi)
  81eb78:	mov    %eax,-0x37(%rsi)
  81eb7b:	mov    0x118(%rsp),%rcx
  81eb83:	mov    0x2f(%rdx),%rax
  81eb87:	mov    %rax,-0x8(%rsi)
  81eb8b:	movups 0xf(%rdx),%xmm0
  81eb8f:	movups 0x1f(%rdx),%xmm1
  81eb93:	movups %xmm1,-0x18(%rsi)
  81eb97:	movups %xmm0,-0x28(%rsi)
  81eb9b:	lea    0x128(%rsp),%rax
  81eba3:	movups 0x20(%rax),%xmm0
  81eba7:	movups %xmm0,(%rsi)
  81ebaa:	movups 0x30(%rax),%xmm0
  81ebae:	movups %xmm0,0x50(%rsi)
  81ebb2:	lea    0x260(%rsp),%rax
  81ebba:	movups 0x40(%rax),%xmm0
  81ebbe:	movups %xmm0,0x60(%rsi)
  81ebc2:	movups (%rax),%xmm0
  81ebc5:	movups 0x10(%rax),%xmm1
  81ebc9:	movups 0x20(%rax),%xmm2
  81ebcd:	movups %xmm2,0x30(%rsi)
  81ebd1:	movups %xmm1,0x20(%rsi)
  81ebd5:	movups %xmm0,0x10(%rsi)
  81ebd9:	lea    0x290(%rsp),%rax
  81ebe1:	movups (%rax),%xmm0
  81ebe4:	movups %xmm0,0x40(%rsi)
  81ebe8:	mov    %dil,0x60(%rsp)
  81ebed:	mov    %dil,0x428(%rsp)
  81ebf5:	mov    %rcx,0x80(%rsp)
  81ebfd:	mov    %rcx,0x430(%rsp)
  81ec05:	lea    0x110(%rsp),%rdi
  81ec0d:	lea    0x428(%rsp),%rsi
  81ec15:	mov    0xb8(%rsp),%rdx
  81ec1d:	mov    %r14d,%ecx
  81ec20:	mov    %r15d,%r8d
  81ec23:	call   821630 <gpui_gpu::renderer::validate_draw>
  81ec28:	mov    0x110(%rsp),%eax
  81ec2f:	mov    0x114(%rsp),%rcx
  81ec37:	mov    %rcx,0x40(%rsp)
  81ec3c:	cmp    $0xffffffff,%eax
  81ec3f:	jne    81f66a <<gpui_gpu::renderer::RendererState>::render+0x151a>
  81ec45:	movzbl 0x60(%rsp),%eax
  81ec4a:	cmp    $0x2,%al
  81ec4c:	sete   0x27(%rsp)
  81ec51:	cmpq   $0x0,0x80(%rsp)
  81ec5a:	setne  0x26(%rsp)
  81ec5f:	movups 0x460(%rsp),%xmm0
  81ec67:	movaps %xmm0,0x2c0(%rsp)
  81ec6f:	cmp    $0x3,%al
  81ec71:	jne    81ed03 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ec77:	movss  0x42c(%rsp),%xmm0
  81ec80:	xorps  %xmm1,%xmm1
  81ec83:	ucomiss %xmm1,%xmm0
  81ec86:	jne    81ec8a <<gpui_gpu::renderer::RendererState>::render+0xb3a>
  81ec88:	jnp    81ed03 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ec8a:	movaps 0x2c0(%rsp),%xmm5
  81ec92:	movaps %xmm5,%xmm1
  81ec95:	unpckhpd %xmm5,%xmm1
  81ec99:	movss  -0x76fd35(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81eca1:	mulss  %xmm4,%xmm1
  81eca5:	movaps %xmm0,%xmm2
  81eca8:	minss  %xmm1,%xmm2
  81ecac:	movaps %xmm2,%xmm1
  81ecaf:	cmpunordss %xmm2,%xmm1
  81ecb4:	movaps %xmm1,%xmm3
  81ecb7:	andnps %xmm2,%xmm3
  81ecba:	andps  %xmm0,%xmm1
  81ecbd:	orps   %xmm3,%xmm1
  81ecc0:	movaps %xmm5,%xmm0
  81ecc3:	shufps $0xff,%xmm5,%xmm0
  81ecc7:	mulss  %xmm4,%xmm0
  81eccb:	movaps %xmm1,%xmm2
  81ecce:	minss  %xmm0,%xmm2
  81ecd2:	movaps %xmm2,%xmm0
  81ecd5:	cmpunordss %xmm2,%xmm0
  81ecda:	andps  %xmm0,%xmm1
  81ecdd:	andnps %xmm2,%xmm0
  81ece0:	orps   %xmm1,%xmm0
  81ece3:	movd   %xmm0,%eax
  81ece7:	mov    %eax,0x60(%rsp)
  81eceb:	and    $0xff800000,%eax
  81ecf0:	mov    $0x7f000000,%ecx
  81ecf5:	sub    %eax,%ecx
  81ecf7:	mov    %ecx,0x80(%rsp)
  81ecfe:	xorps  %xmm0,%xmm0
  81ed01:	jmp    81ed25 <<gpui_gpu::renderer::RendererState>::render+0xbd5>
  81ed03:	mov    0x4c0(%rsp),%eax
  81ed0a:	mov    %eax,0x60(%rsp)
  81ed0e:	mov    0x4c4(%rsp),%eax
  81ed15:	mov    %eax,0x80(%rsp)
  81ed1c:	movsd  0x4c8(%rsp),%xmm0
  81ed25:	movaps %xmm0,0xd0(%rsp)
  81ed2d:	mov    0x8(%rsp),%rax
  81ed32:	mov    0x10(%rax),%ecx
  81ed35:	mov    $0x80000000,%eax
  81ed3a:	or     %eax,%ecx
  81ed3c:	mov    %ecx,0x360(%rsp)
  81ed43:	movups 0x470(%rsp),%xmm0
  81ed4b:	movaps %xmm0,0x3c0(%rsp)
  81ed53:	movups 0x478(%rsp),%xmm0
  81ed5b:	movaps %xmm0,0x4e0(%rsp)
  81ed63:	movsd  0x480(%rsp),%xmm0
  81ed6c:	movaps %xmm0,0x3b0(%rsp)
  81ed74:	movsd  0x488(%rsp),%xmm0
  81ed7d:	movaps %xmm0,0x4d0(%rsp)
  81ed85:	movsd  0x490(%rsp),%xmm0
  81ed8e:	movsd  %xmm0,0x3e0(%rsp)
  81ed97:	movsd  0x498(%rsp),%xmm0
  81eda0:	movsd  %xmm0,0x3d8(%rsp)
  81eda9:	movups 0x4a0(%rsp),%xmm0
  81edb1:	movaps %xmm0,0x2b0(%rsp)
  81edb9:	mov    0x18(%rsp),%rax
  81edbe:	mov    %rax,0x110(%rsp)
  81edc6:	mov    0x28(%rsp),%rax
  81edcb:	mov    %rax,0x118(%rsp)
  81edd3:	mov    0xa0(%rsp),%rax
  81eddb:	mov    %rax,0x120(%rsp)
  81ede3:	movaps 0x2d0(%rsp),%xmm0
  81edeb:	movaps 0x2e0(%rsp),%xmm1
  81edf3:	movaps 0x2f0(%rsp),%xmm2
  81edfb:	lea    0x128(%rsp),%rax
  81ee03:	movups %xmm2,0x20(%rax)
  81ee07:	movups %xmm1,0x10(%rax)
  81ee0b:	movups %xmm0,(%rax)
  81ee0e:	movaps 0x4f0(%rsp),%xmm0
  81ee16:	movups %xmm0,0x30(%rax)
  81ee1a:	movaps 0x3f0(%rsp),%xmm0
  81ee22:	movups %xmm0,0x40(%rax)
  81ee26:	lea    0x110(%rsp),%rdi
  81ee2e:	call   *0x660e54(%rip)        # e7fc88 <_DYNAMIC+0x5c0>
  81ee34:	mov    0x7c(%rsp),%ecx
  81ee38:	mov    %ecx,0xf0(%rsp)
  81ee3f:	test   %eax,%eax
  81ee41:	je     81ee77 <<gpui_gpu::renderer::RendererState>::render+0xd27>
  81ee43:	mov    0x30(%rsp),%rdi
  81ee48:	mov    %eax,%esi
  81ee4a:	call   825b60 <gpui_gpu::renderer::slots::color_word>
  81ee4f:	mov    %eax,0x60(%rsp)
  81ee53:	xorps  %xmm0,%xmm0
  81ee56:	movaps %xmm0,0xd0(%rsp)
  81ee5e:	movl   $0x0,0x80(%rsp)
  81ee69:	mov    0x240(%rsp),%eax
  81ee70:	mov    %eax,0xf0(%rsp)
  81ee77:	mov    0x40(%rsp),%rax
  81ee7c:	shr    $0x20,%rax
  81ee80:	mov    %rax,0x3d0(%rsp)
  81ee88:	mov    0x8(%rsp),%rax
  81ee8d:	mov    (%rax),%rcx
  81ee90:	mov    0x10(%rax),%rsi
  81ee94:	sub    %rsi,%rcx
  81ee97:	cmp    $0x5,%rcx
  81ee9b:	jbe    81f022 <<gpui_gpu::renderer::RendererState>::render+0xed2>
  81eea1:	movsd  0x3d8(%rsp),%xmm0
  81eeaa:	cvtsd2ss %xmm0,%xmm0
  81eeae:	movsd  0x3e0(%rsp),%xmm1
  81eeb7:	cvtsd2ss %xmm1,%xmm1
  81eebb:	movapd 0x4e0(%rsp),%xmm2
  81eec4:	unpcklpd 0x4d0(%rsp),%xmm2
  81eecd:	cvtpd2ps %xmm2,%xmm2
  81eed1:	movapd 0x3c0(%rsp),%xmm3
  81eeda:	unpcklpd 0x3b0(%rsp),%xmm3
  81eee3:	cvtpd2ps %xmm3,%xmm3
  81eee7:	mov    0x8(%rsp),%rax
  81eeec:	mov    0x8(%rax),%rdx
  81eef0:	shl    $0x4,%rsi
  81eef4:	movaps 0x2c0(%rsp),%xmm4
  81eefc:	movups %xmm4,(%rdx,%rsi,1)
  81ef00:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ef06:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ef0c:	mov    0x40(%rsp),%rcx
  81ef11:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ef15:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ef1b:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81ef21:	mov    0x3d0(%rsp),%rdi
  81ef29:	mov    %edi,0x2c(%rdx,%rsi,1)
  81ef2d:	movaps 0x2b0(%rsp),%xmm0
  81ef35:	movups %xmm0,0x30(%rdx,%rsi,1)
  81ef3a:	mov    0x60(%rsp),%edi
  81ef3e:	mov    %edi,0x40(%rdx,%rsi,1)
  81ef42:	mov    0x80(%rsp),%edi
  81ef49:	mov    %edi,0x44(%rdx,%rsi,1)
  81ef4d:	movaps 0xd0(%rsp),%xmm0
  81ef55:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81ef5a:	movq   $0x0,0x50(%rdx,%rsi,1)
  81ef63:	movl   $0x0,0x58(%rdx,%rsi,1)
  81ef6b:	mov    0xf0(%rsp),%edi
  81ef72:	mov    %edi,0x5c(%rdx,%rsi,1)
  81ef76:	addq   $0x6,0x10(%rax)
  81ef7b:	sub    $0x8,%rsp
  81ef7f:	lea    0x118(%rsp),%rdi
  81ef87:	mov    %rax,%rsi
  81ef8a:	lea    0x430(%rsp),%rdx
  81ef92:	mov    0x368(%rsp),%r8d
  81ef9a:	mov    0x60(%rsp),%r9
  81ef9f:	push   0xe8(%rsp)
  81efa6:	push   %r15
  81efa8:	push   %r14
  81efaa:	call   820600 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81efaf:	add    $0x20,%rsp
  81efb3:	mov    0x110(%rsp),%eax
  81efba:	cmp    $0xffffffff,%eax
  81efbd:	jne    81f632 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  81efc3:	movzbl 0x27(%rsp),%ecx
  81efc8:	and    0x26(%rsp),%cl
  81efcc:	mov    0x10(%rsp),%rax
  81efd1:	or     %cl,%al
  81efd3:	mov    %rax,0x10(%rsp)
  81efd8:	mov    0x118(%rsp),%rax
  81efe0:	mov    %rax,0xe0(%rsp)
  81efe8:	incq   0xb8(%rsp)
  81eff0:	mov    0x90(%rsp),%rdx
  81eff8:	add    $0x4,%rdx
  81effc:	mov    0xa0(%rsp),%rax
  81f004:	lea    0x0(,%rax,4),%rax
  81f00c:	mov    %rdx,0x90(%rsp)
  81f014:	cmp    %rdx,%rax
  81f017:	jne    81eb36 <<gpui_gpu::renderer::RendererState>::render+0x9e6>
  81f01d:	jmp    81f4b7 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81f022:	mov    $0x6,%edx
  81f027:	mov    $0x4,%ecx
  81f02c:	mov    $0x10,%r8d
  81f032:	mov    0x8(%rsp),%rdi
  81f037:	call   823bb0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f03c:	mov    0x8(%rsp),%rax
  81f041:	mov    0x10(%rax),%rsi
  81f045:	jmp    81eea1 <<gpui_gpu::renderer::RendererState>::render+0xd51>
  81f04a:	xorps  %xmm0,%xmm0
  81f04d:	movaps %xmm0,0x90(%rsp)
  81f055:	movaps %xmm0,0x40(%rsp)
  81f05a:	mov    0x8(%rsp),%rax
  81f05f:	mov    0x10(%rax),%eax
  81f062:	mov    %eax,0xd0(%rsp)
  81f069:	movups 0x260(%rsp),%xmm1
  81f071:	movups 0x268(%rsp),%xmm2
  81f079:	movsd  0x280(%rsp),%xmm0
  81f082:	movsd  %xmm0,0xf0(%rsp)
  81f08b:	movsd  0x288(%rsp),%xmm0
  81f094:	movsd  %xmm0,0x2c0(%rsp)
  81f09d:	movups 0x290(%rsp),%xmm0
  81f0a5:	movaps %xmm0,0x80(%rsp)
  81f0ad:	movhps 0x270(%rsp),%xmm1
  81f0b5:	movaps %xmm1,0x360(%rsp)
  81f0bd:	movups 0x2a0(%rsp),%xmm0
  81f0c5:	movaps %xmm0,0x60(%rsp)
  81f0ca:	movhps 0x278(%rsp),%xmm2
  81f0d2:	movaps %xmm2,0x2b0(%rsp)
  81f0da:	mov    0x18(%rsp),%rax
  81f0df:	mov    %rax,0x110(%rsp)
  81f0e7:	mov    0x28(%rsp),%rax
  81f0ec:	mov    %rax,0x118(%rsp)
  81f0f4:	mov    0xa0(%rsp),%rax
  81f0fc:	mov    %rax,0x120(%rsp)
  81f104:	lea    0x260(%rsp),%rax
  81f10c:	movups (%rax),%xmm0
  81f10f:	movups 0x10(%rax),%xmm1
  81f113:	movups 0x20(%rax),%xmm2
  81f117:	lea    0x128(%rsp),%rdx
  81f11f:	movups %xmm2,0x20(%rdx)
  81f123:	movups %xmm1,0x10(%rdx)
  81f127:	movups %xmm0,(%rdx)
  81f12a:	lea    0x290(%rsp),%rcx
  81f132:	movups (%rcx),%xmm0
  81f135:	movups %xmm0,0x30(%rdx)
  81f139:	movdqu 0x40(%rax),%xmm0
  81f13e:	movdqu %xmm0,0x40(%rdx)
  81f143:	lea    0x110(%rsp),%rdi
  81f14b:	call   *0x660b37(%rip)        # e7fc88 <_DYNAMIC+0x5c0>
  81f151:	test   %eax,%eax
  81f153:	je     81f173 <<gpui_gpu::renderer::RendererState>::render+0x1023>
  81f155:	mov    0x30(%rsp),%rdi
  81f15a:	mov    %eax,%esi
  81f15c:	call   825b60 <gpui_gpu::renderer::slots::color_word>
  81f161:	orl    $0x80000000,0x7c(%rsp)
  81f169:	movd   %eax,%xmm0
  81f16d:	movdqa %xmm0,0x60(%rsp)
  81f173:	mov    0x8(%rsp),%rax
  81f178:	mov    (%rax),%rcx
  81f17b:	mov    0x10(%rax),%rsi
  81f17f:	sub    %rsi,%rcx
  81f182:	cmp    $0x4,%rcx
  81f186:	jbe    81f4f1 <<gpui_gpu::renderer::RendererState>::render+0x13a1>
  81f18c:	cvtpd2ps 0x360(%rsp),%xmm0
  81f195:	cvtpd2ps 0x2b0(%rsp),%xmm1
  81f19e:	movsd  0xf0(%rsp),%xmm2
  81f1a7:	cvtsd2ss %xmm2,%xmm2
  81f1ab:	movsd  0x2c0(%rsp),%xmm3
  81f1b4:	cvtsd2ss %xmm3,%xmm3
  81f1b8:	mov    0x8(%rsp),%rax
  81f1bd:	mov    0x8(%rax),%rcx
  81f1c1:	shl    $0x4,%rsi
  81f1c5:	movlpd %xmm0,(%rcx,%rsi,1)
  81f1ca:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f1d0:	movaps 0x40(%rsp),%xmm0
  81f1d5:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f1db:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f1e1:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f1e7:	movaps 0x90(%rsp),%xmm0
  81f1ef:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f1f5:	movaps 0x80(%rsp),%xmm0
  81f1fd:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f202:	movaps 0x60(%rsp),%xmm0
  81f207:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f20c:	mov    0x7c(%rsp),%edx
  81f210:	mov    %edx,0x40(%rcx,%rsi,1)
  81f214:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f21d:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f225:	addq   $0x5,0x10(%rax)
  81f22a:	incq   0x200(%rsp)
  81f232:	mov    0xa0(%rsp),%rax
  81f23a:	add    %rax,0x208(%rsp)
  81f242:	test   %rax,%rax
  81f245:	je     81f4c3 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81f24b:	movdqa 0x40(%rsp),%xmm0
  81f251:	movd   %xmm0,%ecx
  81f255:	movdqa 0x90(%rsp),%xmm0
  81f25e:	movd   %xmm0,%eax
  81f262:	shl    $0x20,%rax
  81f266:	or     %rax,%rcx
  81f269:	mov    %rcx,0xf0(%rsp)
  81f271:	mov    0x370(%rsp),%rax
  81f279:	add    $0xfffffffffffffffc,%rax
  81f27d:	shr    $0x2,%rax
  81f281:	mov    0xb8(%rsp),%rcx
  81f289:	add    %rax,%rcx
  81f28c:	inc    %rcx
  81f28f:	mov    %rcx,0xb8(%rsp)
  81f297:	movq   $0x0,0x40(%rsp)
  81f2a0:	mov    0x28(%rsp),%rax
  81f2a5:	mov    0x40(%rsp),%rcx
  81f2aa:	mov    (%rax,%rcx,1),%edx
  81f2ad:	lea    0x300(%rsp),%rdi
  81f2b5:	mov    0x18(%rsp),%rsi
  81f2ba:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f2bf:	movzbl 0x300(%rsp),%edi
  81f2c7:	lea    0x308(%rsp),%rsi
  81f2cf:	mov    -0x7(%rsi),%eax
  81f2d2:	mov    -0x4(%rsi),%ecx
  81f2d5:	lea    0x111(%rsp),%rdx
  81f2dd:	mov    %ecx,0x3(%rdx)
  81f2e0:	mov    %eax,(%rdx)
  81f2e2:	mov    0x308(%rsp),%rcx
  81f2ea:	mov    0x28(%rsi),%rax
  81f2ee:	mov    %rax,0x2f(%rdx)
  81f2f2:	movups 0x8(%rsi),%xmm0
  81f2f6:	movups 0x18(%rsi),%xmm1
  81f2fa:	movups %xmm1,0x1f(%rdx)
  81f2fe:	movups %xmm0,0xf(%rdx)
  81f302:	movups 0x338(%rsp),%xmm1
  81f30a:	lea    0x348(%rsp),%rax
  81f312:	movups (%rax),%xmm0
  81f315:	lea    0x128(%rsp),%rax
  81f31d:	movups %xmm0,0x70(%rax)
  81f321:	movaps 0x3f0(%rsp),%xmm0
  81f329:	movups %xmm0,0x80(%rax)
  81f330:	movaps %xmm1,0xa0(%rsp)
  81f338:	movups %xmm1,0x148(%rsp)
  81f340:	movaps 0x500(%rsp),%xmm0
  81f348:	movaps 0x510(%rsp),%xmm1
  81f350:	movapd 0x520(%rsp),%xmm2
  81f359:	movupd %xmm2,0x50(%rax)
  81f35e:	movups %xmm1,0x40(%rax)
  81f362:	movups %xmm0,0x30(%rax)
  81f366:	movaps 0x530(%rsp),%xmm0
  81f36e:	movups %xmm0,0x60(%rax)
  81f372:	mov    %dil,0x60(%rsp)
  81f377:	mov    %dil,0x110(%rsp)
  81f37f:	mov    %rcx,0x80(%rsp)
  81f387:	mov    %rcx,0x118(%rsp)
  81f38f:	mov    0x8(%rsp),%rax
  81f394:	mov    (%rax),%rcx
  81f397:	mov    0x10(%rax),%rax
  81f39b:	sub    %rax,%rcx
  81f39e:	mov    %rax,0x90(%rsp)
  81f3a6:	cmp    $0x1,%rcx
  81f3aa:	jbe    81f487 <<gpui_gpu::renderer::RendererState>::render+0x1337>
  81f3b0:	mov    0x8(%rsp),%rsi
  81f3b5:	mov    0x8(%rsi),%rcx
  81f3b9:	shl    $0x4,%rax
  81f3bd:	movaps 0xa0(%rsp),%xmm0
  81f3c5:	movups %xmm0,(%rcx,%rax,1)
  81f3c9:	movq   $0x0,0x10(%rcx,%rax,1)
  81f3d2:	movl   $0x0,0x18(%rcx,%rax,1)
  81f3da:	mov    0xd0(%rsp),%edx
  81f3e1:	mov    %edx,0x1c(%rcx,%rax,1)
  81f3e5:	addq   $0x2,0x10(%rsi)
  81f3ea:	sub    $0x8,%rsp
  81f3ee:	lea    0x308(%rsp),%rdi
  81f3f6:	lea    0x118(%rsp),%rdx
  81f3fe:	mov    0xf8(%rsp),%rcx
  81f406:	mov    0x98(%rsp),%r8
  81f40e:	mov    0x60(%rsp),%r9
  81f413:	push   0xe8(%rsp)
  81f41a:	push   %r15
  81f41c:	push   %r14
  81f41e:	call   820600 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f423:	add    $0x20,%rsp
  81f427:	mov    0x300(%rsp),%eax
  81f42e:	cmp    $0xffffffff,%eax
  81f431:	jne    81f64e <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  81f437:	cmpb   $0x2,0x60(%rsp)
  81f43c:	sete   %al
  81f43f:	cmpq   $0x0,0x80(%rsp)
  81f448:	setne  %cl
  81f44b:	and    %al,%cl
  81f44d:	mov    0x10(%rsp),%rax
  81f452:	or     %cl,%al
  81f454:	mov    %rax,0x10(%rsp)
  81f459:	mov    0x308(%rsp),%rax
  81f461:	mov    %rax,0xe0(%rsp)
  81f469:	mov    0x40(%rsp),%rcx
  81f46e:	add    $0x4,%rcx
  81f472:	mov    %rcx,0x40(%rsp)
  81f477:	cmp    %rcx,0x370(%rsp)
  81f47f:	jne    81f2a0 <<gpui_gpu::renderer::RendererState>::render+0x1150>
  81f485:	jmp    81f4b7 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81f487:	mov    $0x2,%edx
  81f48c:	mov    $0x4,%ecx
  81f491:	mov    $0x10,%r8d
  81f497:	mov    0x8(%rsp),%rdi
  81f49c:	mov    0x90(%rsp),%rsi
  81f4a4:	call   823bb0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f4a9:	mov    0x8(%rsp),%rax
  81f4ae:	mov    0x10(%rax),%rax
  81f4b2:	jmp    81f3b0 <<gpui_gpu::renderer::RendererState>::render+0x1260>
  81f4b7:	mov    0x10(%rsp),%rax
  81f4bc:	and    $0x1,%al
  81f4be:	mov    %rax,0x10(%rsp)
  81f4c3:	lea    0x248(%rsp),%rdi
  81f4cb:	lea    0x388(%rsp),%rsi
  81f4d3:	call   *0x6607a7(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81f4d9:	mov    0x248(%rsp),%rax
  81f4e1:	mov    %rax,0x18(%rsp)
  81f4e6:	test   %rax,%rax
  81f4e9:	jne    81e7f4 <<gpui_gpu::renderer::RendererState>::render+0x6a4>
  81f4ef:	jmp    81f552 <<gpui_gpu::renderer::RendererState>::render+0x1402>
  81f4f1:	mov    $0x5,%edx
  81f4f6:	mov    $0x4,%ecx
  81f4fb:	mov    $0x10,%r8d
  81f501:	mov    0x8(%rsp),%rdi
  81f506:	call   823bb0 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f50b:	mov    0x8(%rsp),%rax
  81f510:	mov    0x10(%rax),%rsi
  81f514:	jmp    81f18c <<gpui_gpu::renderer::RendererState>::render+0x103c>
  81f519:	movq   $0x0,0x208(%rsp)
  81f525:	movq   $0x0,0x200(%rsp)
  81f531:	movq   $0x0,0xb8(%rsp)
  81f53d:	movq   $0x0,0x10(%rsp)
  81f546:	movq   $0x0,0xe0(%rsp)
  81f552:	mov    0x108(%rsp),%rsi
  81f55a:	lea    0x8(%rsi),%rdx
  81f55e:	mov    0x8(%rsp),%rax
  81f563:	lea    0x240(%rax),%rcx
  81f56a:	lea    0x310(%rax),%r8
  81f571:	mov    0x10(%rax),%r9
  81f575:	sub    $0x8,%rsp
  81f579:	lea    0x118(%rsp),%rdi
  81f581:	mov    %rdx,0x3c8(%rsp)
  81f589:	mov    %rcx,0x2b8(%rsp)
  81f591:	mov    %r8,0x2c8(%rsp)
  81f599:	push   0xf0(%rsp)
  81f5a0:	call   822af0 <gpui_gpu::renderer::images::prepare>
  81f5a5:	add    $0x10,%rsp
  81f5a9:	cmpl   $0xffffffff,0x110(%rsp)
  81f5b1:	je     81f5fa <<gpui_gpu::renderer::RendererState>::render+0x14aa>
  81f5b3:	movups 0x110(%rsp),%xmm0
  81f5bb:	movups 0x120(%rsp),%xmm1
  81f5c3:	mov    0x38(%rsp),%rdi
  81f5c8:	movups %xmm1,0x10(%rdi)
  81f5cc:	movups %xmm0,(%rdi)
  81f5cf:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f5d4:	mov    0x23c(%rsp),%edx
  81f5db:	mov    0x38(%rsp),%rdi
  81f5e0:	mov    %edx,0x1c(%rdi)
  81f5e3:	movups 0x22c(%rsp),%xmm0
  81f5eb:	movups %xmm0,0xc(%rdi)
  81f5ef:	mov    %ecx,(%rdi)
  81f5f1:	mov    %rax,0x4(%rdi)
  81f5f5:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f5fa:	movzbl 0x10(%rsp),%r8d
  81f600:	and    $0x1,%r8d
  81f604:	lea    0x110(%rsp),%rdi
  81f60c:	mov    0x8(%rsp),%rsi
  81f611:	mov    0x108(%rsp),%rdx
  81f619:	mov    0xc8(%rsp),%rcx
  81f621:	call   81d8d0 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f626:	mov    0x110(%rsp),%eax
  81f62d:	cmp    $0xffffffff,%eax
  81f630:	je     81f695 <<gpui_gpu::renderer::RendererState>::render+0x1545>
  81f632:	mov    0x114(%rsp),%ecx
  81f639:	mov    0x118(%rsp),%rdx
  81f641:	movups 0x120(%rsp),%xmm0
  81f649:	jmp    81e683 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f64e:	mov    0x304(%rsp),%ecx
  81f655:	mov    0x308(%rsp),%rdx
  81f65d:	movups 0x310(%rsp),%xmm0
  81f665:	jmp    81e683 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f66a:	mov    0x12c(%rsp),%ecx
  81f671:	mov    0x38(%rsp),%rdi
  81f676:	mov    %ecx,0x1c(%rdi)
  81f679:	movups 0x11c(%rsp),%xmm0
  81f681:	movups %xmm0,0xc(%rdi)
  81f685:	mov    %eax,(%rdi)
  81f687:	mov    0x40(%rsp),%rax
  81f68c:	mov    %rax,0x4(%rdi)
  81f690:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f695:	mov    0x118(%rsp),%rax
  81f69d:	mov    %rax,0x3b0(%rsp)
  81f6a5:	mov    0xc8(%rsp),%rax
  81f6ad:	mov    %rax,0x300(%rsp)
  81f6b5:	movq   $0x0,0x308(%rsp)
  81f6c1:	mov    0xc0(%rsp),%rax
  81f6c9:	mov    %rax,0x310(%rsp)
  81f6d1:	mov    0x210(%rsp),%rax
  81f6d9:	mov    %rax,0x318(%rsp)
  81f6e1:	mov    0x78(%rsp),%eax
  81f6e5:	mov    %eax,0x320(%rsp)
  81f6ec:	lea    0x248(%rsp),%rdi
  81f6f4:	lea    0x300(%rsp),%rsi
  81f6fc:	call   *0x66057e(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81f702:	mov    0x248(%rsp),%rax
  81f70a:	mov    %rax,0xa0(%rsp)
  81f712:	test   %rax,%rax
  81f715:	je     81fae6 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f71b:	mov    0x8(%rsp),%rax
  81f720:	add    $0x108,%rax
  81f726:	mov    %rax,0x360(%rsp)
  81f72e:	jmp    81f769 <<gpui_gpu::renderer::RendererState>::render+0x1619>
  81f730:	lea    0x248(%rsp),%rdi
  81f738:	lea    0x300(%rsp),%rsi
  81f740:	call   *0x66053a(%rip)        # e7fc80 <_DYNAMIC+0x5b8>
  81f746:	mov    0x248(%rsp),%rax
  81f74e:	mov    0x10(%rsp),%rcx
  81f753:	mov    %rcx,0x50(%rsp)
  81f758:	mov    %rax,0xa0(%rsp)
  81f760:	test   %rax,%rax
  81f763:	je     81fae6 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f769:	mov    0x250(%rsp),%rdx
  81f771:	mov    0x258(%rsp),%rdi
  81f779:	mov    %rdi,0x90(%rsp)
  81f781:	lea    0x260(%rsp),%rax
  81f789:	movups 0x40(%rax),%xmm0
  81f78d:	lea    0x128(%rsp),%rcx
  81f795:	movups %xmm0,0x40(%rcx)
  81f799:	movups (%rax),%xmm0
  81f79c:	movups 0x10(%rax),%xmm1
  81f7a0:	movups 0x20(%rax),%xmm2
  81f7a4:	movups 0x30(%rax),%xmm3
  81f7a8:	movups %xmm3,0x30(%rcx)
  81f7ac:	movups %xmm2,0x20(%rcx)
  81f7b0:	movups %xmm1,0x10(%rcx)
  81f7b4:	movups %xmm0,(%rcx)
  81f7b7:	mov    0x8(%rsp),%rax
  81f7bc:	movzbl 0x329(%rax),%esi
  81f7c3:	mov    0xa0(%rsp),%rax
  81f7cb:	mov    %rax,0x110(%rsp)
  81f7d3:	mov    %rdx,0x60(%rsp)
  81f7d8:	mov    %rdx,0x118(%rsp)
  81f7e0:	mov    %rdi,0x120(%rsp)
  81f7e8:	lea    0x110(%rsp),%rdi
  81f7f0:	call   8215e0 <gpui_gpu::renderer::compact_group>
  81f7f5:	mov    0x50(%rsp),%rcx
  81f7fa:	lea    0x5(%rcx),%rdx
  81f7fe:	test   %al,%al
  81f800:	cmove  %rcx,%rdx
  81f804:	mov    %rdx,0x10(%rsp)
  81f809:	cmpq   $0x0,0x90(%rsp)
  81f812:	je     81f730 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81f818:	shlq   $0x2,0x90(%rsp)
  81f821:	xor    $0x1,%al
  81f823:	movzbl %al,%ecx
  81f826:	shl    $0x2,%ecx
  81f829:	lea    0x1(%rcx),%rax
  81f82d:	mov    %rax,0x80(%rsp)
  81f835:	mov    0x10(%rsp),%rax
  81f83a:	lea    (%rax,%rcx,1),%r8
  81f83e:	inc    %r8
  81f841:	or     $0x2,%rcx
  81f845:	shl    $0x4,%r8
  81f849:	mov    %rcx,0x50(%rsp)
  81f84e:	shl    $0x4,%ecx
  81f851:	mov    %rcx,0xd0(%rsp)
  81f859:	xor    %ecx,%ecx
  81f85b:	mov    %r8,0x18(%rsp)
  81f860:	mov    0x60(%rsp),%rax
  81f865:	mov    %rcx,0x30(%rsp)
  81f86a:	mov    (%rax,%rcx,1),%edx
  81f86d:	lea    0x110(%rsp),%rdi
  81f875:	mov    0xa0(%rsp),%rsi
  81f87d:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f882:	movzbl 0x110(%rsp),%ecx
  81f88a:	movzbl 0x111(%rsp),%eax
  81f892:	movss  0x114(%rsp),%xmm4
  81f89b:	lea    0x118(%rsp),%rsi
  81f8a3:	mov    0x10(%rsi),%rdx
  81f8a7:	mov    %rdx,0x2e0(%rsp)
  81f8af:	movups (%rsi),%xmm0
  81f8b2:	movaps %xmm0,0x2d0(%rsp)
  81f8ba:	cmp    $0x1,%ecx
  81f8bd:	je     81f952 <<gpui_gpu::renderer::RendererState>::render+0x1802>
  81f8c3:	movaps %xmm4,0xf0(%rsp)
  81f8cb:	mov    0x130(%rsp),%rsi
  81f8d3:	mov    0x138(%rsp),%edx
  81f8da:	mov    %edx,0x40(%rsp)
  81f8de:	mov    0x13c(%rsp),%edx
  81f8e5:	mov    %edx,0x28(%rsp)
  81f8e9:	cmp    $0x3,%ecx
  81f8ec:	jne    81f9d7 <<gpui_gpu::renderer::RendererState>::render+0x1887>
  81f8f2:	mov    0x2c0(%rsp),%rcx
  81f8fa:	mov    (%rcx),%rdi
  81f8fd:	test   %rdi,%rdi
  81f900:	je     820576 <<gpui_gpu::renderer::RendererState>::render+0x2426>
  81f906:	movzbl %al,%edx
  81f909:	call   822780 <<gpui_gpu::renderer::images::Images>::metadata>
  81f90e:	mov    %eax,%ecx
  81f910:	shr    $0x20,%rax
  81f914:	mov    %eax,%edx
  81f916:	or     $0x10,%edx
  81f919:	xorps  %xmm0,%xmm0
  81f91c:	movaps 0xf0(%rsp),%xmm1
  81f924:	ucomiss %xmm0,%xmm1
  81f927:	cmovne %edx,%eax
  81f92a:	cmovp  %edx,%eax
  81f92d:	mov    0x28(%rsp),%edx
  81f931:	shl    $0x10,%edx
  81f934:	or     0x40(%rsp),%edx
  81f938:	mov    %ecx,0x220(%rsp)
  81f93f:	mov    %eax,0x224(%rsp)
  81f946:	mov    %edx,0x228(%rsp)
  81f94d:	jmp    81fa74 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f952:	movss  0x150(%rsp),%xmm0
  81f95b:	movss  -0x7709f7(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f963:	mulss  %xmm3,%xmm0
  81f967:	movaps %xmm4,%xmm1
  81f96a:	minss  %xmm0,%xmm1
  81f96e:	movaps %xmm1,%xmm0
  81f971:	cmpunordss %xmm1,%xmm0
  81f976:	movaps %xmm0,%xmm2
  81f979:	andnps %xmm1,%xmm2
  81f97c:	andps  %xmm4,%xmm0
  81f97f:	orps   %xmm2,%xmm0
  81f982:	movss  0x154(%rsp),%xmm1
  81f98b:	mulss  %xmm3,%xmm1
  81f98f:	movaps %xmm0,%xmm2
  81f992:	minss  %xmm1,%xmm2
  81f996:	movaps %xmm2,%xmm1
  81f999:	cmpunordss %xmm2,%xmm1
  81f99e:	andps  %xmm1,%xmm0
  81f9a1:	andnps %xmm2,%xmm1
  81f9a4:	orps   %xmm0,%xmm1
  81f9a7:	movd   %xmm1,%eax
  81f9ab:	and    $0xff800000,%eax
  81f9b0:	mov    $0x7f000000,%ecx
  81f9b5:	sub    %eax,%ecx
  81f9b7:	movl   $0x40000000,0x220(%rsp)
  81f9c2:	movss  %xmm1,0x224(%rsp)
  81f9cb:	mov    %ecx,0x228(%rsp)
  81f9d2:	jmp    81fa74 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f9d7:	cmp    $0x2,%cl
  81f9da:	jne    81fa2c <<gpui_gpu::renderer::RendererState>::render+0x18dc>
  81f9dc:	mov    0x140(%rsp),%rax
  81f9e4:	mov    0x2e0(%rsp),%rcx
  81f9ec:	mov    %rcx,0x120(%rsp)
  81f9f4:	movaps 0x2d0(%rsp),%xmm0
  81f9fc:	movaps %xmm0,0x110(%rsp)
  81fa04:	mov    %rsi,0x128(%rsp)
  81fa0c:	mov    0x40(%rsp),%ecx
  81fa10:	mov    %ecx,0x130(%rsp)
  81fa17:	mov    0x28(%rsp),%ecx
  81fa1b:	mov    %ecx,0x134(%rsp)
  81fa22:	mov    %rax,0x138(%rsp)
  81fa2a:	jmp    81fa38 <<gpui_gpu::renderer::RendererState>::render+0x18e8>
  81fa2c:	movq   $0x0,0x110(%rsp)
  81fa38:	movl   $0x0,0x390(%rsp)
  81fa43:	movq   $0x0,0x388(%rsp)
  81fa4f:	lea    0x220(%rsp),%rdi
  81fa57:	lea    0x110(%rsp),%rsi
  81fa5f:	lea    0x388(%rsp),%rdx
  81fa67:	mov    0x360(%rsp),%rcx
  81fa6f:	call   81b790 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81fa74:	mov    0x10(%rsp),%rdx
  81fa79:	mov    0x80(%rsp),%rax
  81fa81:	lea    (%rax,%rdx,1),%rdi
  81fa85:	mov    0x8(%rsp),%rax
  81fa8a:	mov    0x10(%rax),%rsi
  81fa8e:	cmp    %rsi,%rdi
  81fa91:	mov    0x18(%rsp),%r8
  81fa96:	jae    82059c <<gpui_gpu::renderer::RendererState>::render+0x244c>
  81fa9c:	mov    0x8(%rax),%rax
  81faa0:	mov    0x228(%rsp),%ecx
  81faa7:	mov    %ecx,0x8(%rax,%r8,1)
  81faac:	mov    0x220(%rsp),%rcx
  81fab4:	mov    %rcx,(%rax,%r8,1)
  81fab8:	add    0x50(%rsp),%rdx
  81fabd:	mov    %rdx,0x10(%rsp)
  81fac2:	add    0xd0(%rsp),%r8
  81faca:	mov    0x30(%rsp),%rcx
  81facf:	add    $0x4,%rcx
  81fad3:	cmp    %rcx,0x90(%rsp)
  81fadb:	jne    81f85b <<gpui_gpu::renderer::RendererState>::render+0x170b>
  81fae1:	jmp    81f730 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81fae6:	cmpl   $0x0,0x58(%rsp)
  81faeb:	je     820583 <<gpui_gpu::renderer::RendererState>::render+0x2433>
  81faf1:	mov    0x8(%rsp),%rax
  81faf6:	mov    0x28(%rax),%rax
  81fafa:	movq   $0x0,0xd0(%rsp)
  81fb06:	mov    %rax,0x18(%rsp)
  81fb0b:	test   %rax,%rax
  81fb0e:	je     81fc43 <<gpui_gpu::renderer::RendererState>::render+0x1af3>
  81fb14:	mov    0x8(%rsp),%rax
  81fb19:	mov    0x20(%rax),%rcx
  81fb1d:	movq   $0x0,0x80(%rsp)
  81fb29:	movq   $0x0,0x50(%rsp)
  81fb32:	movq   $0x0,0x60(%rsp)
  81fb3b:	xor    %edi,%edi
  81fb3d:	movabs $0x10000800000,%r9
  81fb47:	jmp    81fb6f <<gpui_gpu::renderer::RendererState>::render+0x1a1f>
  81fb49:	mov    0x30(%rsp),%rdx
  81fb4e:	lea    (%rcx,%rdx,8),%rcx
  81fb52:	mov    0xd0(%rsp),%rax
  81fb5a:	inc    %eax
  81fb5c:	mov    %rax,0xd0(%rsp)
  81fb64:	sub    %rdx,0x18(%rsp)
  81fb69:	je     81fc37 <<gpui_gpu::renderer::RendererState>::render+0x1ae7>
  81fb6f:	mov    0x58(%rsp),%rax
  81fb74:	mov    0x18(%rsp),%rdx
  81fb79:	cmp    %rdx,%rax
  81fb7c:	cmovb  %rax,%rdx
  81fb80:	mov    0xd0(%rsp),%rax
  81fb88:	shl    $0x4,%eax
  81fb8b:	mov    %r15d,%esi
  81fb8e:	sub    %eax,%esi
  81fb90:	cmp    $0x10,%esi
  81fb93:	mov    $0x10,%eax
  81fb98:	cmovae %eax,%esi
  81fb9b:	mov    %rdx,0x30(%rsp)
  81fba0:	lea    0x0(,%rdx,8),%r10d
  81fba8:	shl    $0x4,%esi
  81fbab:	mov    %esi,0x10(%rsp)
  81fbaf:	xor    %r11d,%r11d
  81fbb2:	mov    %r14d,%edx
  81fbb5:	jmp    81fbd5 <<gpui_gpu::renderer::RendererState>::render+0x1a85>
  81fbb7:	movl   $0x80000000,0x4(%rcx,%r11,1)
  81fbc0:	incq   0x60(%rsp)
  81fbc5:	add    $0xfffffff0,%edx
  81fbc8:	add    $0x8,%r11
  81fbcc:	cmp    %r11,%r10
  81fbcf:	je     81fb49 <<gpui_gpu::renderer::RendererState>::render+0x19f9>
  81fbd5:	mov    0x4(%rcx,%r11,1),%r8d
  81fbda:	mov    %r8d,%eax
  81fbdd:	and    $0x8001ffff,%eax
  81fbe2:	cmp    $0x80000001,%eax
  81fbe7:	je     81fbb7 <<gpui_gpu::renderer::RendererState>::render+0x1a67>
  81fbe9:	mov    %r8d,%esi
  81fbec:	and    $0x1ffff,%esi
  81fbf2:	shl    $0x17,%r8d
  81fbf6:	mov    %rsi,%rax
  81fbf9:	imul   %r9,%rax
  81fbfd:	or     %edi,%r8d
  81fc00:	shr    $0x20,%rax
  81fc04:	mov    %r8d,(%rcx,%r11,1)
  81fc08:	mov    %eax,0x4(%rcx,%r11,1)
  81fc0d:	add    %esi,%edi
  81fc0f:	test   %rsi,%rsi
  81fc12:	je     81fbc5 <<gpui_gpu::renderer::RendererState>::render+0x1a75>
  81fc14:	cmp    $0x10,%edx
  81fc17:	mov    $0x10,%eax
  81fc1c:	cmovb  %edx,%eax
  81fc1f:	imul   0x10(%rsp),%eax
  81fc24:	add    %rax,0x50(%rsp)
  81fc29:	imul   %rax,%rsi
  81fc2d:	add    %rsi,0x80(%rsp)
  81fc35:	jmp    81fbc5 <<gpui_gpu::renderer::RendererState>::render+0x1a75>
  81fc37:	mov    %edi,%eax
  81fc39:	mov    %rax,0xd0(%rsp)
  81fc41:	jmp    81fc61 <<gpui_gpu::renderer::RendererState>::render+0x1b11>
  81fc43:	movq   $0x0,0x60(%rsp)
  81fc4c:	movq   $0x0,0x50(%rsp)
  81fc55:	movq   $0x0,0x80(%rsp)
  81fc61:	mov    0x8(%rsp),%rax
  81fc66:	lea    0x30(%rax),%rdi
  81fc6a:	movq   $0x0,0x40(%rax)
  81fc72:	movl   $0x0,0xf0(%rsp)
  81fc7d:	mov    %rdi,0xa0(%rsp)
  81fc85:	mov    0xd0(%rsp),%rsi
  81fc8d:	xor    %edx,%edx
  81fc8f:	call   8229a0 <<alloc::vec::Vec<u32>>::resize>
  81fc94:	mov    0x8(%rsp),%rax
  81fc99:	mov    0x10(%rax),%rax
  81fc9d:	mov    %rax,0x28(%rsp)
  81fca2:	mov    0xc8(%rsp),%rax
  81fcaa:	mov    %rax,0x2d0(%rsp)
  81fcb2:	movq   $0x0,0x2d8(%rsp)
  81fcbe:	mov    0xc0(%rsp),%rax
  81fcc6:	mov    %rax,0x2e0(%rsp)
  81fcce:	mov    0x210(%rsp),%rax
  81fcd6:	mov    %rax,0x2e8(%rsp)
  81fcde:	mov    0x78(%rsp),%eax
  81fce2:	mov    %eax,0x2f0(%rsp)
  81fce9:	jmp    81fd05 <<gpui_gpu::renderer::RendererState>::render+0x1bb5>
  81fceb:	mov    0x28(%rsp),%rcx
  81fcf0:	lea    -0x5(%rcx),%rax
  81fcf4:	cmpb   $0x0,0xc0(%rsp)
  81fcfc:	cmovne %rax,%rcx
  81fd00:	mov    %rcx,0x28(%rsp)
  81fd05:	lea    0x248(%rsp),%rdi
  81fd0d:	lea    0x2d0(%rsp),%rsi
  81fd15:	call   *0x65ff75(%rip)        # e7fc90 <_DYNAMIC+0x5c8>
  81fd1b:	mov    0x248(%rsp),%rax
  81fd23:	mov    %rax,0x40(%rsp)
  81fd28:	test   %rax,%rax
  81fd2b:	je     81ff5e <<gpui_gpu::renderer::RendererState>::render+0x1e0e>
  81fd31:	mov    0x250(%rsp),%rcx
  81fd39:	mov    0x258(%rsp),%rdx
  81fd41:	mov    %rdx,0x18(%rsp)
  81fd46:	mov    0x8(%rsp),%rax
  81fd4b:	movzbl 0x329(%rax),%esi
  81fd52:	mov    0x40(%rsp),%rax
  81fd57:	mov    %rax,0x110(%rsp)
  81fd5f:	mov    %rcx,0x90(%rsp)
  81fd67:	mov    %rcx,0x118(%rsp)
  81fd6f:	mov    %rdx,0x120(%rsp)
  81fd77:	lea    0x260(%rsp),%rax
  81fd7f:	movups (%rax),%xmm0
  81fd82:	movups 0x10(%rax),%xmm1
  81fd86:	movdqu 0x20(%rax),%xmm2
  81fd8b:	lea    0x128(%rsp),%rdx
  81fd93:	movdqu %xmm2,0x20(%rdx)
  81fd98:	movups %xmm1,0x10(%rdx)
  81fd9c:	movups %xmm0,(%rdx)
  81fd9f:	lea    0x290(%rsp),%rcx
  81fda7:	movups (%rcx),%xmm0
  81fdaa:	movups %xmm0,0x30(%rdx)
  81fdae:	movups 0x40(%rax),%xmm0
  81fdb2:	movups %xmm0,0x40(%rdx)
  81fdb6:	lea    0x110(%rsp),%rdi
  81fdbe:	call   8215e0 <gpui_gpu::renderer::compact_group>
  81fdc3:	mov    %al,0xc0(%rsp)
  81fdca:	mov    0x18(%rsp),%rax
  81fdcf:	test   %rax,%rax
  81fdd2:	je     81fceb <<gpui_gpu::renderer::RendererState>::render+0x1b9b>
  81fdd8:	mov    %rax,%rcx
  81fddb:	shl    $0x2,%rcx
  81fddf:	movzbl 0xc0(%rsp),%eax
  81fde7:	lea    0x0(,%rax,4),%edx
  81fdee:	or     $0xfffffffffffffffa,%rdx
  81fdf2:	xor    %esi,%esi
  81fdf4:	test   %al,%al
  81fdf6:	sete   %sil
  81fdfa:	shl    $0x1f,%esi
  81fdfd:	mov    %esi,0xc8(%rsp)
  81fe04:	mov    %rdx,0x30(%rsp)
  81fe09:	mov    0x28(%rsp),%rax
  81fe0e:	add    %edx,%eax
  81fe10:	mov    %eax,0x10(%rsp)
  81fe14:	mov    %rcx,0x18(%rsp)
  81fe19:	mov    0x90(%rsp),%rax
  81fe21:	mov    -0x4(%rax,%rcx,1),%edx
  81fe25:	lea    0x300(%rsp),%rdi
  81fe2d:	mov    0x40(%rsp),%rsi
  81fe32:	call   81ca10 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fe37:	mov    0x30(%rsp),%rax
  81fe3c:	add    %rax,0x28(%rsp)
  81fe41:	mov    0xc8(%rsp),%eax
  81fe48:	or     0x10(%rsp),%eax
  81fe4c:	mov    %eax,0x220(%rsp)
  81fe53:	lea    0x260(%rsp),%rdx
  81fe5b:	movups (%rdx),%xmm0
  81fe5e:	movups 0x10(%rdx),%xmm1
  81fe62:	movups 0x20(%rdx),%xmm2
  81fe66:	lea    0x128(%rsp),%rcx
  81fe6e:	movups %xmm2,0x50(%rcx)
  81fe72:	movups %xmm1,0x40(%rcx)
  81fe76:	movups %xmm0,0x30(%rcx)
  81fe7a:	lea    0x290(%rsp),%rax
  81fe82:	movups (%rax),%xmm0
  81fe85:	movups %xmm0,0x60(%rcx)
  81fe89:	movups 0x40(%rdx),%xmm0
  81fe8d:	movups %xmm0,0x80(%rcx)
  81fe94:	lea    0x338(%rsp),%rax
  81fe9c:	movups (%rax),%xmm0
  81fe9f:	movups %xmm0,0x20(%rcx)
  81fea3:	lea    0x348(%rsp),%rax
  81feab:	movups (%rax),%xmm0
  81feae:	movups %xmm0,0x70(%rcx)
  81feb2:	mov    0x330(%rsp),%rax
  81feba:	mov    %rax,0x140(%rsp)
  81fec2:	movups 0x300(%rsp),%xmm0
  81feca:	movups 0x310(%rsp),%xmm1
  81fed2:	movdqu 0x320(%rsp),%xmm2
  81fedb:	movdqa %xmm2,0x130(%rsp)
  81fee4:	movaps %xmm1,0x120(%rsp)
  81feec:	movaps %xmm0,0x110(%rsp)
  81fef4:	mov    0x218(%rsp),%rax
  81fefc:	mov    %rax,0x388(%rsp)
  81ff04:	mov    0xa0(%rsp),%rax
  81ff0c:	mov    %rax,0x390(%rsp)
  81ff14:	lea    0x220(%rsp),%rax
  81ff1c:	mov    %rax,0x398(%rsp)
  81ff24:	lea    0x110(%rsp),%rdi
  81ff2c:	mov    0x58(%rsp),%rsi
  81ff31:	lea    0x388(%rsp),%rdx
  81ff39:	call   81c650 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81ff3e:	mov    0x10(%rsp),%eax
  81ff42:	add    0x30(%rsp),%eax
  81ff46:	mov    %eax,0x10(%rsp)
  81ff4a:	mov    0x18(%rsp),%rcx
  81ff4f:	add    $0xfffffffffffffffc,%rcx
  81ff53:	jne    81fe14 <<gpui_gpu::renderer::RendererState>::render+0x1cc4>
  81ff59:	jmp    81fceb <<gpui_gpu::renderer::RendererState>::render+0x1b9b>
  81ff5e:	test   $0x1,%r12b
  81ff62:	je     81ffb5 <<gpui_gpu::renderer::RendererState>::render+0x1e65>
  81ff64:	movd   0x244(%rsp),%xmm0
  81ff6d:	movd   %xmm0,%eax
  81ff71:	test   %eax,%eax
  81ff73:	setns  %cl
  81ff76:	mov    %eax,%edx
  81ff78:	and    $0x7fffffff,%edx
  81ff7e:	add    $0xff800000,%edx
  81ff84:	cmp    $0x7f000000,%edx
  81ff8a:	setb   %dl
  81ff8d:	and    %cl,%dl
  81ff8f:	dec    %eax
  81ff91:	cmp    $0x7fffff,%eax
  81ff96:	setb   %al
  81ff99:	or     %dl,%al
  81ff9b:	movl   $0x2,0xf0(%rsp)
  81ffa6:	movd   %xmm0,0x104(%rsp)
  81ffaf:	je     82056c <<gpui_gpu::renderer::RendererState>::render+0x241c>
  81ffb5:	mov    0x108(%rsp),%r12
  81ffbd:	lea    0x18(%r12),%rax
  81ffc2:	mov    %rax,0x18(%rsp)
  81ffc7:	mov    0xe8(%rsp),%rax
  81ffcf:	add    $0x18,%rax
  81ffd3:	xor    %ecx,%ecx
  81ffd5:	mov    0x378(%rsp),%rdx
  81ffdd:	cmp    0x380(%rsp),%rdx
  81ffe5:	setne  %cl
  81ffe8:	xor    %edx,%edx
  81ffea:	cmp    $0x28,%r13d
  81ffee:	sete   %dl
  81fff1:	and    $0x1,%ebp
  81fff4:	lea    0x0(%rbp,%rdx,4),%edx
  81fff8:	lea    (%rdx,%rcx,8),%ecx
  81fffb:	or     0xf0(%rsp),%ecx
  820002:	movups (%rax),%xmm0
  820005:	movups %xmm0,0x258(%rsp)
  82000d:	mov    %r14d,0x248(%rsp)
  820015:	mov    %r15d,0x24c(%rsp)
  82001d:	mov    0x58(%rsp),%rax
  820022:	mov    %eax,0x250(%rsp)
  820029:	mov    %ecx,0x254(%rsp)
  820030:	movss  0x104(%rsp),%xmm0
  820039:	movss  %xmm0,0x268(%rsp)
  820042:	movq   $0x0,0x26c(%rsp)
  82004e:	movl   $0x0,0x274(%rsp)
  820059:	mov    0x8(%rsp),%rbp
  82005e:	lea    0x218(%rbp),%rsi
  820065:	movq   $0x0,0x10(%rsp)
  82006e:	lea    0x248(%rsp),%rcx
  820076:	mov    $0x30,%r8d
  82007c:	mov    0x3c0(%rsp),%r13
  820084:	mov    %r13,%rdi
  820087:	mov    %rsi,0x58(%rsp)
  82008c:	xor    %edx,%edx
  82008e:	call   *0x65fc04(%rip)        # e7fc98 <_DYNAMIC+0x5d0>
  820094:	mov    0x8(%rbp),%rcx
  820098:	mov    0x10(%rbp),%r8
  82009c:	shl    $0x4,%r8
  8200a0:	mov    0x2b0(%rsp),%rdi
  8200a8:	mov    %r12,%rsi
  8200ab:	mov    %r13,%rdx
  8200ae:	call   81ccb0 <<gpui_gpu::renderer::Buffer>::write>
  8200b3:	lea    0x268(%rbp),%rdi
  8200ba:	mov    0x20(%rbp),%rcx
  8200be:	mov    0x28(%rbp),%r8
  8200c2:	shl    $0x3,%r8
  8200c6:	mov    %rdi,0x30(%rsp)
  8200cb:	mov    %r12,%rsi
  8200ce:	mov    %r13,%rdx
  8200d1:	call   81ccb0 <<gpui_gpu::renderer::Buffer>::write>
  8200d6:	lea    0x290(%rbp),%rdi
  8200dd:	mov    0x38(%rbp),%rcx
  8200e1:	mov    0x40(%rbp),%r8
  8200e5:	shl    $0x2,%r8
  8200e9:	mov    %rdi,0x218(%rsp)
  8200f1:	mov    %r12,%rsi
  8200f4:	mov    %r13,%rdx
  8200f7:	call   81ccb0 <<gpui_gpu::renderer::Buffer>::write>
  8200fc:	lea    0x2b8(%rbp),%rdi
  820103:	mov    0x50(%rbp),%rcx
  820107:	mov    0x58(%rbp),%r8
  82010b:	shl    $0x5,%r8
  82010f:	mov    %rdi,0xe8(%rsp)
  820117:	mov    %r12,%rsi
  82011a:	mov    %r13,%rdx
  82011d:	call   81ccb0 <<gpui_gpu::renderer::Buffer>::write>
  820122:	cmpq   $0x0,0x310(%rbp)
  82012a:	jne    820146 <<gpui_gpu::renderer::RendererState>::render+0x1ff6>
  82012c:	mov    0x8(%rsp),%rax
  820131:	mov    0x10(%rax),%rax
  820135:	cmp    $0x1,%rax
  820139:	adc    $0x0,%rax
  82013d:	shl    $0x4,%rax
  820141:	mov    %rax,0x10(%rsp)
  820146:	mov    0x8(%rsp),%rsi
  82014b:	mov    0x28(%rsi),%rdx
  82014f:	mov    0x40(%rsi),%rax
  820153:	cmp    $0x1,%rdx
  820157:	adc    $0x0,%rdx
  82015b:	shl    $0x3,%rdx
  82015f:	cmp    $0x1,%rax
  820163:	adc    $0x0,%rax
  820167:	mov    0x58(%rsi),%rcx
  82016b:	cmp    $0x1,%rcx
  82016f:	adc    $0x0,%rcx
  820173:	add    $0xb0,%rsi
  82017a:	shl    $0x2,%rax
  82017e:	shl    $0x5,%rcx
  820182:	movq   $0x0,0x110(%rsp)
  82018e:	mov    0x58(%rsp),%rdi
  820193:	mov    %rdi,0x118(%rsp)
  82019b:	movq   $0x0,0x138(%rsp)
  8201a7:	xorps  %xmm0,%xmm0
  8201aa:	movups %xmm0,0x120(%rsp)
  8201b2:	movl   $0x0,0x130(%rsp)
  8201bd:	mov    0x2b0(%rsp),%rdi
  8201c5:	mov    %rdi,0x140(%rsp)
  8201cd:	movq   $0x0,0x148(%rsp)
  8201d9:	mov    0x10(%rsp),%rdi
  8201de:	mov    %rdi,0x150(%rsp)
  8201e6:	movl   $0x1,0x158(%rsp)
  8201f1:	movq   $0x0,0x160(%rsp)
  8201fd:	mov    0x30(%rsp),%rdi
  820202:	mov    %rdi,0x168(%rsp)
  82020a:	movq   $0x0,0x170(%rsp)
  820216:	mov    %rdx,0x178(%rsp)
  82021e:	movl   $0x2,0x180(%rsp)
  820229:	movq   $0x0,0x188(%rsp)
  820235:	mov    0x218(%rsp),%rdx
  82023d:	mov    %rdx,0x190(%rsp)
  820245:	movq   $0x0,0x198(%rsp)
  820251:	mov    %rax,0x1a0(%rsp)
  820259:	movl   $0x3,0x1a8(%rsp)
  820264:	movq   $0x4,0x1b0(%rsp)
  820270:	mov    %rsi,0x1b8(%rsp)
  820278:	movl   $0x4,0x1d0(%rsp)
  820283:	movq   $0x0,0x1d8(%rsp)
  82028f:	mov    0xe8(%rsp),%rax
  820297:	mov    %rax,0x1e0(%rsp)
  82029f:	movq   $0x0,0x1e8(%rsp)
  8202ab:	mov    %rcx,0x1f0(%rsp)
  8202b3:	movl   $0x5,0x1f8(%rsp)
  8202be:	lea    -0x74b362(%rip),%rax        # d4f63 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x13d>
  8202c5:	mov    %rax,0x318(%rsp)
  8202cd:	movq   $0xa,0x320(%rsp)
  8202d9:	mov    0x18(%rsp),%rax
  8202de:	mov    %rax,0x300(%rsp)
  8202e6:	lea    0x110(%rsp),%rax
  8202ee:	mov    %rax,0x308(%rsp)
  8202f6:	movq   $0x6,0x310(%rsp)
  820302:	lea    0x300(%rsp),%rsi
  82030a:	mov    0x108(%rsp),%r12
  820312:	mov    %r12,%rdi
  820315:	call   *0x65f985(%rip)        # e7fca0 <_DYNAMIC+0x5d8>
  82031b:	mov    %rax,%r13
  82031e:	mov    %rax,0x2d0(%rsp)
  820326:	lea    0x2d0(%rsp),%rdx
  82032e:	mov    %r12,%rdi
  820331:	mov    0x3e8(%rsp),%rsi
  820339:	call   81d310 <<gpui_gpu::renderer::GpuContext>::submit>
  82033e:	mov    %rax,0x10(%rsp)
  820343:	xor    %ebp,%ebp
  820345:	mov    0x378(%rsp),%rax
  82034d:	cmp    0x380(%rsp),%rax
  820355:	setne  %bpl
  820359:	shl    $0x1f,%ebp
  82035c:	or     %r14d,%ebp
  82035f:	shl    $0x20,%r15
  820363:	or     %r15,%rbp
  820366:	mov    (%rbx),%rax
  820369:	test   %rax,%rax
  82036c:	je     82037d <<gpui_gpu::renderer::RendererState>::render+0x222d>
  82036e:	lock decq (%rax)
  820372:	jne    82037d <<gpui_gpu::renderer::RendererState>::render+0x222d>
  820374:	mov    %rbx,%rdi
  820377:	call   *0x65f863(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  82037d:	mov    0x8(%rsp),%rax
  820382:	mov    %r13,0x318(%rax)
  820389:	mov    %rbp,0x320(%rax)
  820390:	mov    0x10(%rax),%r9
  820394:	mov    0x28(%rax),%rsi
  820398:	mov    0x58(%rax),%rcx
  82039c:	mov    %rcx,0x18(%rsp)
  8203a1:	shl    $0x4,%r9
  8203a5:	mov    0xd0(%rsp),%rdx
  8203ad:	lea    (%r9,%rdx,4),%rdi
  8203b1:	lea    (%rdi,%rsi,8),%rsi
  8203b5:	mov    %rcx,%rdi
  8203b8:	shl    $0x5,%rdi
  8203bc:	lea    (%rdi,%rsi,1),%rcx
  8203c0:	add    $0x30,%rcx
  8203c4:	mov    %rcx,0x58(%rsp)
  8203c9:	mov    0x138(%rax),%esi
  8203cf:	imul   %rsi,%rsi
  8203d3:	mov    0x260(%rax),%r8
  8203da:	add    0x238(%rax),%r8
  8203e1:	add    0x288(%rax),%r8
  8203e8:	add    0x2b0(%rax),%r8
  8203ef:	add    0x2d8(%rax),%r8
  8203f6:	mov    0x2f0(%rax),%rdi
  8203fd:	add    0x2f8(%rax),%rdi
  820404:	mov    0xe0(%rsp),%r11
  82040c:	mov    %r11,%rcx
  82040f:	sub    %rdx,%rcx
  820412:	mov    0xb8(%rsp),%r10
  82041a:	mov    %r10,%r12
  82041d:	mov    0x208(%rsp),%rbp
  820425:	sub    %rbp,%r12
  820428:	mov    0x148(%rax),%rbx
  82042f:	inc    %rbx
  820432:	mov    $0xffffffffffffffff,%r14
  820439:	cmovne %rbx,%r14
  82043d:	mov    (%rax),%rbx
  820440:	shl    $0x4,%rbx
  820444:	mov    0x18(%rax),%r15
  820448:	lea    (%rbx,%r15,8),%rbx
  82044c:	mov    0x30(%rax),%r15
  820450:	lea    (%rbx,%r15,4),%rbx
  820454:	mov    0x48(%rax),%r15
  820458:	shl    $0x5,%r15
  82045c:	add    %rbx,%r15
  82045f:	mov    0x120(%rax),%rbx
  820466:	mov    0x118(%rax),%r13
  82046d:	mov    %r14,0x148(%rax)
  820474:	mov    %r10,0x150(%rax)
  82047b:	lea    (%r11,%r11,1),%r14
  82047f:	mov    %r14,0x158(%rax)
  820486:	movq   $0x1,0x160(%rax)
  820491:	mov    %r10,0x168(%rax)
  820498:	mov    %rdx,0x170(%rax)
  82049f:	mov    %r11,0x178(%rax)
  8204a6:	mov    %rcx,0x180(%rax)
  8204ad:	mov    0x60(%rsp),%rcx
  8204b2:	mov    %rcx,0x188(%rax)
  8204b9:	mov    0x50(%rsp),%rcx
  8204be:	mov    %rcx,0x190(%rax)
  8204c5:	mov    0x80(%rsp),%rcx
  8204cd:	mov    %rcx,0x198(%rax)
  8204d4:	mov    0x58(%rsp),%rcx
  8204d9:	mov    %rcx,0x1a0(%rax)
  8204e0:	mov    %r9,0x1a8(%rax)
  8204e7:	mov    0x200(%rsp),%rdx
  8204ef:	mov    %rdx,0x1b0(%rax)
  8204f6:	mov    %rbp,0x1b8(%rax)
  8204fd:	mov    %r12,0x1c0(%rax)
  820504:	mov    0x3b0(%rsp),%rcx
  82050c:	mov    %rcx,0x1c8(%rax)
  820513:	mov    %r8,0x1d0(%rax)
  82051a:	mov    %rsi,0x1d8(%rax)
  820521:	add    %rbx,%r13
  820524:	mov    %rbx,0x1e0(%rax)
  82052b:	mov    %r13,0x1e8(%rax)
  820532:	mov    %r15,0x1f0(%rax)
  820539:	mov    0x18(%rsp),%rcx
  82053e:	mov    %rcx,0x1f8(%rax)
  820545:	mov    %rdi,0x200(%rax)
  82054c:	movb   $0x0,0x208(%rax)
  820553:	mov    0x38(%rsp),%rdi
  820558:	mov    0x10(%rsp),%rax
  82055d:	mov    %rax,0x8(%rdi)
  820561:	movl   $0xffffffff,(%rdi)
  820567:	jmp    81e261 <<gpui_gpu::renderer::RendererState>::render+0x111>
  82056c:	mov    0x38(%rsp),%rdi
  820571:	jmp    81e253 <<gpui_gpu::renderer::RendererState>::render+0x103>
  820576:	lea    0x60dc63(%rip),%rdi        # e2e1e0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  82057d:	call   *0x65f725(%rip)        # e7fca8 <_DYNAMIC+0x5e0>
  820583:	lea    -0x74b642(%rip),%rdi        # d4f48 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82058a:	lea    0x60dc37(%rip),%rdx        # e2e1c8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  820591:	mov    $0x37,%esi
  820596:	call   *0x65f444(%rip)        # e7f9e0 <_DYNAMIC+0x318>
  82059c:	lea    0x60dc55(%rip),%rdx        # e2e1f8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  8205a3:	call   *0x65f617(%rip)        # e7fbc0 <_DYNAMIC+0x4f8>
  8205a9:	mov    %rax,%r14
  8205ac:	mov    0x8(%rsp),%rax
  8205b1:	mov    %r13,0x318(%rax)
  8205b8:	mov    %rbp,0x320(%rax)
  8205bf:	mov    %r14,%rdi
  8205c2:	call   e2c4b0 <_Unwind_Resume@plt>
  8205c7:	mov    %rax,%r14
  8205ca:	lock decq 0x0(%r13)
  8205cf:	jne    8205f1 <<gpui_gpu::renderer::RendererState>::render+0x24a1>
  8205d1:	lea    0x2d0(%rsp),%rdi
  8205d9:	call   *0x65f601(%rip)        # e7fbe0 <_DYNAMIC+0x518>
  8205df:	jmp    8205f1 <<gpui_gpu::renderer::RendererState>::render+0x24a1>
  8205e1:	call   *0x65f331(%rip)        # e7f918 <_DYNAMIC+0x250>
  8205e7:	mov    %rax,%r14
  8205ea:	movq   $0x0,(%rbx)
  8205f1:	mov    %r14,%rdi
  8205f4:	call   e2c4b0 <_Unwind_Resume@plt>
