# Shipping packed CSR: correctness/static qualified, unadopted

Candidate `5559828a4f6d093401cc374654f634b4d8fb9ddb` at `/tmp/gpui-packed-csr-sol` is a
separate successor to shipping `7a5e1619a27010ec63f6c27506a6d1fcd113f67c`. It removes
the retained cursor vector and ordinal cutoff. Forward counts identify the exact
suffix after the latest existing opaque proof; reverse painter traversal takes
that many visits and fills the same ordered references. An eight-byte private
tile packs start/remaining/count23/17/17 bits. Direct uniform addresses retain
both words and are tagged before any remaining-count decode. Original logical
admission caps and successful-only Stats publication remain. Work counters fold
into row/chunk normalization, deleting the entire final tile-statistics walk.

No 299c constant tiles, opaque-prefix sampling, whole-bounds certificate, shared
sample kernel, uniform planes, record residency or fused resource patch walk is
carried here. Legacy 5-word common/6-word inline records, the shipping float shader
helpers/sample loops, resource patching, proof policy, public APIs, painter/clear
arithmetic and ordinary full warm validation/uploads remain. Only the private
eight-byte tile bit encoding changes together on CPU/GPU. source-audit.json checks
all unchanged source regions byte for byte. No new fields, heap allocation,
dependency, unsafe block, source exception or SIMD/fallback policy fork is added.

This proves discrete equivalence to the existing shipping accepted predicate;
it does not strengthen its numeric guard contract into a universal strict-IEEE
or cross-backend geometry theorem. Actual readbacks use Mesa 26.1.4 llvmpipe,
not a hardware render node. Compilation elsewhere is not a runtime claim.

Default/fallback release each pass 11 library/4 presentation/47 render/1 doc tests;
offline shader passes 12/4/48/1 with qualified `spirv-val`. Strict default/offline
all-target Clippy `-D warnings` and Apple ARM64/Windows MSVC all-feature library
cross-compilation pass. Package formatting, clean source and all 1,380 source/config
guards pass. Exact compiler executable/version guards pin qualified Rust/Cargo 1.97.1.

An independent actual-binning oracle enumerates 32,768 four-choice painter streams
across partial six-tile geometry, alternating synthetic inline/compact word addresses (no record dereference), proofs on/off,
opaque resets and partial non-proof visits. It compares exact address order with
an independent retained-suffix list. It manually reconstructs normalization;
full production-path readbacks below independently cover actual normalization.
Private tests cover empty at 4,194,304, last occupied endpoint, retained count 65,536,
field isolation and uniform inline overlap. Actual binning also reaches 65,536.
Independent 35x19 SDR/HDR public counters cover empty, full translucent, a clipped
3x3 opaque corner and a partial first tile. An existing AtlasFull failure now
asserts the entire previous successful Stats remains unchanged.

Original fixture `8773146b44150adb0150323d51f241c946fb5cda26328f004562dcd9dee39cc0` retains
52 exact readbacks / 35,651,584 bytes against frozen actual shipping pair-00-A, with every
work Stats/ImageStats field exact. cpu_index_capacity_bytes intentionally falls
2,048 per fixed 512-tile frame. The complete same 47-test integration source plus an
identical nonshipping 1x1 HDR/P3 maximum 65,536 count probe runs in both matched lanes:
all 584 named images / 13,484,384 bytes and complete work Stats/ImageStats match by
name/within-test ordinal/dimensions/format. No global index alignment is used.
Both captures finish within the unchanged 180s functional watchdog. Their clocks
are unqualified and provide no performance inference. Exact observer/probe
sources, hashes and actual binaries are retained; all source is restored.

Every one of 584 reported capacity deltas exactly equals the old cursor field's
actual byte charge; all other four current scratch capacity components match.
Observed deleted cursor capacity ranges 0..4096 bytes, including Vec minimum/growth
capacities rather than assuming tile length equals capacity. Renderer 888 -> 864 and
RendererState 840 -> 816 each shrink 24 bytes on this measured Linux build; Stats 200
is unchanged. There is no RSS, allocator-overhead or universal-layout claim.
All GPU payload, reference lengths, uploads and buffer diagnostic fields match;
public-work-payload-ledger.json preserves every 26-cell full-render bill, including
both 32k validation workloads and all ordinary full warm uploads.

Actual wrong reverse-slot selection keeps counts/allocation valid but reverses
painter address order: the independent oracle exits 101 and 28/52 retained public
readbacks differ, including SDR/HDR layers8; exact restoration recovers 0. A separate
counter-only c+1 fault fails 21280 vs 10640, exit 101; restoration recovers 0. Full
fault sources/logs/captures/executable hashes remain. No failing control is dropped.

| Static cost | Shipping | Candidate | Delta |
|---|---:|---:|---:|
| Core non-test/comment LOC |30692|30706|+14|
| Default linked.text |6403991|6403639|-352|
| Default linked.rodata |7012024|7012280|+256|
| Default.data.rel.ro |336384|336336|-48|
| Render body/static frame |9493/1416|9385/1400|-108/-16|
| bin_draw body/static frame |4184/824|4056/792|-128/-32|
| Reverse visit body/static frame |611/88|610/72|-1/-16|

Actual matched groups ELFs use the same physical source path, locked dependencies,
features, opt3, root v0/tokio and emit-stack-sizes exactly once. Both primary rustc
argument vectors are exactly equal; library and groups artifacts are fresh:false.
Offline linked.text also falls 352 but .rodata grows 640. Generated WGSL grows 129
bytes; each fragment SPIR-V variant grows 132 with two masks, a shift, add, vector
construction and two constants; vertex variants are unchanged. All shaders are
validated and disassembled. The new CPU bit decode/eight-byte update, constructor,
drop glue, every GPU symbol alias, whole code and static frames are charged in
assembly-review.md/cost-ledger.json. Static frames are not dynamic peak stack or
additive call chains. There is no timing, speed, adoption or universal-win claim.

Setup history remains: a package-name typo failed formatting before source checks;
two insufficiently specific integration-edit checks stopped before writing that
file; one static setup attempt was cancelled during dependency compilation after
preflight caught missing validator configuration. Its owned Cargo was reaped and
source restored before the corrected run. No matched GPU artifact or qualified
static/timing result came from that cancelled attempt. Production 555 stayed fixed.

All five older campaign/qualification archives were rehashed unchanged, including
b312's unfavorable code/frame bill. No old tree/ELF/capture is modified. The new
archive excludes ELF bytes, records exact external paths/sizes/hashes, preserves
complete source snapshots/patch/config/guards/raw readbacks and reopens every
payload for verification. No timed campaign or follow-on implementation is
included or authorized by this qualification.
