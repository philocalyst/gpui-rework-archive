
FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9493 frame=1416

/tmp/gpui-packed-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0d0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0d0:	push   %rbp
  81e0d1:	push   %r15
  81e0d3:	push   %r14
  81e0d5:	push   %r13
  81e0d7:	push   %r12
  81e0d9:	push   %rbx
  81e0da:	sub    $0x558,%rsp
  81e0e1:	mov    0x228(%rsi),%rax
  81e0e8:	mov    0x18(%rdx),%r9
  81e0ec:	cmp    %r9,%rax
  81e0ef:	je     81e10d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0f1:	mov    0x10(%rax),%r10
  81e0f5:	cmp    0x10(%r9),%r10
  81e0f9:	jne    81e1da <<gpui_gpu::renderer::RendererState>::render+0x10a>
  81e0ff:	mov    0x18(%rax),%rax
  81e103:	cmp    0x18(%r9),%rax
  81e107:	jne    81e1da <<gpui_gpu::renderer::RendererState>::render+0x10a>
  81e10d:	lea    0x330(%rsi),%rbx
  81e114:	mov    0x330(%rsi),%rax
  81e11b:	test   %rax,%rax
  81e11e:	je     81e14d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e120:	lock decq (%rax)
  81e124:	jne    81e14d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e126:	mov    %rdi,%r14
  81e129:	mov    %rbx,%rdi
  81e12c:	mov    %rsi,%r12
  81e12f:	mov    %r8,%r13
  81e132:	mov    %rdx,%r15
  81e135:	mov    %rcx,%rbp
  81e138:	call   *0x661b42(%rip)        # e7fc80 <_DYNAMIC+0x518>
  81e13e:	mov    %rbp,%rcx
  81e141:	mov    %r15,%rdx
  81e144:	mov    %r13,%r8
  81e147:	mov    %r12,%rsi
  81e14a:	mov    %r14,%rdi
  81e14d:	movq   $0x0,0x330(%rsi)
  81e158:	mov    (%rcx),%ebp
  81e15a:	mov    0x8(%rcx),%r9d
  81e15e:	movzbl 0xd(%rcx),%eax
  81e162:	test   %r9d,%r9d
  81e165:	sets   %r10b
  81e169:	and    $0x7fffffff,%r9d
  81e170:	lea    -0x800000(%r9),%r11d
  81e177:	cmp    $0x7f000000,%r11d
  81e17e:	setb   %r11b
  81e182:	and    %r10b,%r11b
  81e185:	lea    -0x1(%r9),%r14d
  81e189:	cmp    $0x7fffff,%r14d
  81e190:	setb   %r14b
  81e194:	and    %r10b,%r14b
  81e197:	test   %r9d,%r9d
  81e19a:	sete   %r10b
  81e19e:	cmp    $0x7f800000,%r9d
  81e1a5:	sete   %r15b
  81e1a9:	or     %r10b,%r15b
  81e1ac:	cmp    $0x7f800001,%r9d
  81e1b3:	setge  %r9b
  81e1b7:	or     %r15b,%r9b
  81e1ba:	or     %r14b,%r9b
  81e1bd:	test   %ebp,%ebp
  81e1bf:	setne  %r10b
  81e1c3:	and    %al,%r10b
  81e1c6:	or     %r11b,%r10b
  81e1c9:	or     %r9b,%r10b
  81e1cc:	test   $0x1,%r10b
  81e1d0:	je     81e1f5 <<gpui_gpu::renderer::RendererState>::render+0x125>
  81e1d2:	movl   $0x3,(%rdi)
  81e1d8:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81e1da:	movl   $0x4,(%rdi)
  81e1e0:	mov    %rdi,%rax
  81e1e3:	add    $0x558,%rsp
  81e1ea:	pop    %rbx
  81e1eb:	pop    %r12
  81e1ed:	pop    %r13
  81e1ef:	pop    %r14
  81e1f1:	pop    %r15
  81e1f3:	pop    %rbp
  81e1f4:	ret
  81e1f5:	movd   0x4(%rcx),%xmm2
  81e1fa:	movzbl 0xc(%rcx),%r12d
  81e1ff:	test   $0x1,%bpl
  81e203:	je     81e27b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e205:	movd   %xmm2,%r9d
  81e20a:	test   %r9d,%r9d
  81e20d:	sets   %r10b
  81e211:	and    $0x7fffffff,%r9d
  81e218:	lea    -0x800000(%r9),%r11d
  81e21f:	cmp    $0x7f000000,%r11d
  81e226:	setb   %r11b
  81e22a:	and    %r10b,%r11b
  81e22d:	lea    -0x1(%r9),%r14d
  81e231:	cmp    $0x7fffff,%r14d
  81e238:	setb   %r14b
  81e23c:	and    %r10b,%r14b
  81e23f:	test   %r9d,%r9d
  81e242:	sete   %r10b
  81e246:	cmp    $0x7f800000,%r9d
  81e24d:	sete   %r15b
  81e251:	or     %r10b,%r15b
  81e254:	cmp    $0x7f800001,%r9d
  81e25b:	setge  %r9b
  81e25f:	or     %r15b,%r9b
  81e262:	or     %r14b,%r9b
  81e265:	or     %r11b,%r9b
  81e268:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e26e:	ucomiss -0x76f3c9(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e275:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e27b:	mov    0x28(%rcx),%r14d
  81e27f:	cmp    %r14d,0x20(%r8)
  81e283:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e289:	mov    0x2c(%rcx),%r15d
  81e28d:	cmp    %r15d,0x24(%r8)
  81e291:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e297:	mov    0x38(%r8),%r13d
  81e29b:	cmp    0x20(%rdx),%r13d
  81e29f:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e2a5:	cmp    $0x4c,%r13d
  81e2a9:	jne    81e2ce <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e2ab:	movq   0x3c(%r8),%xmm0
  81e2b1:	movq   0x24(%rdx),%xmm1
  81e2b6:	pcmpeqd %xmm0,%xmm1
  81e2ba:	pshufd $0x50,%xmm1,%xmm0
  81e2bf:	movmskpd %xmm0,%r9d
  81e2c4:	cmp    $0x3,%r9d
  81e2c8:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e2ce:	cmp    $0x4000,%r15d
  81e2d5:	ja     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2d7:	cmp    $0x4000,%r14d
  81e2de:	ja     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2e0:	mov    %r15,%r9
  81e2e3:	imul   %r14,%r9
  81e2e7:	add    $0xfffffffffeffffff,%r9
  81e2ee:	cmp    $0xffffffffff000000,%r9
  81e2f5:	jb     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2f7:	mov    0x10(%rcx),%r11
  81e2fb:	mov    0x80(%r11),%r10
  81e302:	cmp    $0x10000,%r10
  81e309:	jbe    81e316 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e30b:	movl   $0x6,(%rdi)
  81e311:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81e316:	movd   0x18(%rcx),%xmm0
  81e31b:	movd   %xmm0,%r9d
  81e320:	and    $0x7fffffff,%r9d
  81e327:	cmp    $0x7f7fffff,%r9d
  81e32e:	jg     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e334:	pand   -0x770bbc(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e33c:	ucomiss -0x76f23f(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e343:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e349:	movd   0x1c(%rcx),%xmm0
  81e34e:	movd   %xmm0,%r9d
  81e353:	and    $0x7fffffff,%r9d
  81e35a:	cmp    $0x7f7fffff,%r9d
  81e361:	jg     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e367:	pand   -0x770bef(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e36f:	ucomiss -0x76f272(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e376:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e37c:	movd   0x20(%rcx),%xmm0
  81e381:	movd   %xmm0,%r9d
  81e386:	and    $0x7fffffff,%r9d
  81e38d:	cmp    $0x7f7fffff,%r9d
  81e394:	jg     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e39a:	pand   -0x770c22(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3a2:	ucomiss -0x76f2a5(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3a9:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e3af:	movd   0x24(%rcx),%xmm0
  81e3b4:	movd   %xmm0,%r9d
  81e3b9:	and    $0x7fffffff,%r9d
  81e3c0:	cmp    $0x7f7fffff,%r9d
  81e3c7:	jg     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e3cd:	movdqa -0x770c55(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3d5:	pand   %xmm0,%xmm1
  81e3d9:	ucomiss -0x76f2dc(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3e0:	ja     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e3e6:	xorps  %xmm1,%xmm1
  81e3e9:	ucomiss %xmm1,%xmm0
  81e3ec:	jb     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e3f2:	movss  -0x76f67a(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3fa:	ucomiss %xmm0,%xmm1
  81e3fd:	jb     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e403:	movzwl 0x30(%rcx),%r9d
  81e408:	mov    %r9w,0x10(%rsp)
  81e40e:	movzwl 0x32(%rcx),%r9d
  81e413:	mov    %r9w,0x18(%rsp)
  81e419:	cmp    $0x28,%r13d
  81e41d:	jne    81e429 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e41f:	test   $0x1,%al
  81e421:	je     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e427:	jmp    81e444 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e429:	test   $0x1,%al
  81e42b:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e431:	ucomiss -0x76f6b8(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e438:	jne    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e43e:	jp     81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  81e444:	mov    %r11,0xb8(%rsp)
  81e44c:	mov    %r10,0xb0(%rsp)
  81e454:	movss  %xmm1,0xe4(%rsp)
  81e45d:	movd   %xmm2,0x244(%rsp)
  81e466:	mov    %rdx,0xe8(%rsp)
  81e46e:	mov    %r8,0x3f0(%rsp)
  81e476:	mov    %rdi,0x50(%rsp)
  81e47b:	lea    0xf(%r14),%rax
  81e47f:	shr    $0x4,%rax
  81e483:	lea    0xf(%r15),%edx
  81e487:	shr    $0x4,%edx
  81e48a:	lea    0x18(%rsi),%rdi
  81e48e:	movq   $0x0,0x28(%rsi)
  81e496:	mov    %rax,0x38(%rsp)
  81e49b:	imul   %eax,%edx
  81e49e:	mov    %rdi,0x98(%rsp)
  81e4a6:	mov    %rsi,0x8(%rsp)
  81e4ab:	mov    %rdx,0x58(%rsp)
  81e4b0:	mov    %rdx,%rsi
  81e4b3:	xor    %edx,%edx
  81e4b5:	mov    %rcx,0x90(%rsp)
  81e4bd:	call   8228f0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e4c2:	mov    0x8(%rsp),%rax
  81e4c7:	movq   $0x0,0x10(%rax)
  81e4cf:	mov    0x90(%rsp),%rdi
  81e4d7:	call   *0x661833(%rip)        # e7fd10 <_DYNAMIC+0x5a8>
  81e4dd:	mov    %rdx,%rcx
  81e4e0:	sub    %rax,%rcx
  81e4e3:	cmp    $0x300000,%rcx
  81e4ea:	jbe    81e4fc <<gpui_gpu::renderer::RendererState>::render+0x42c>
  81e4ec:	mov    0x50(%rsp),%rdi
  81e4f1:	movl   $0x6,(%rdi)
  81e4f7:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81e4fc:	mov    %rcx,%rsi
  81e4ff:	shr    $0x3,%rcx
  81e503:	movabs $0xaaaaaaaaaaaaaaab,%rdi
  81e50d:	imul   %rcx,%rdi
  81e511:	mov    %rdi,0x30(%rsp)
  81e516:	mov    %rax,0x3a8(%rsp)
  81e51e:	mov    %rdx,0x3a0(%rsp)
  81e526:	cmp    %rax,%rdx
  81e529:	je     81e55a <<gpui_gpu::renderer::RendererState>::render+0x48a>
  81e52b:	mov    $0xaaaaaaab,%eax
  81e530:	imul   %rax,%rsi
  81e534:	shr    $0x2a,%rsi
  81e538:	mov    0x30(%rsp),%rcx
  81e53d:	mov    %ecx,%eax
  81e53f:	and    $0x3f,%eax
  81e542:	add    %rcx,%rsi
  81e545:	cmp    $0x1,%rax
  81e549:	sbb    $0xffffffffffffffff,%rsi
  81e54d:	inc    %rsi
  81e550:	mov    %rsi,0xd8(%rsp)
  81e558:	jmp    81e566 <<gpui_gpu::renderer::RendererState>::render+0x496>
  81e55a:	movq   $0x0,0xd8(%rsp)
  81e566:	mov    0xb8(%rsp),%rax
  81e56e:	mov    0x98(%rax),%rcx
  81e575:	add    0xb0(%rax),%rcx
  81e57c:	mov    %rax,0x120(%rsp)
  81e584:	movzwl 0x10(%rsp),%eax
  81e589:	mov    %ax,0x140(%rsp)
  81e591:	movzwl 0x18(%rsp),%eax
  81e596:	mov    %ax,0x142(%rsp)
  81e59e:	movq   $0x0,0x128(%rsp)
  81e5aa:	mov    0xb0(%rsp),%rax
  81e5b2:	mov    %rax,0x130(%rsp)
  81e5ba:	mov    %rcx,0x238(%rsp)
  81e5c2:	mov    %rcx,0x138(%rsp)
  81e5ca:	mov    0x8(%rsp),%rax
  81e5cf:	movzbl 0x341(%rax),%edx
  81e5d6:	lea    0x438(%rsp),%rdi
  81e5de:	lea    0x120(%rsp),%rsi
  81e5e6:	call   81c820 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e5eb:	mov    0x438(%rsp),%eax
  81e5f2:	cmp    $0xffffffff,%eax
  81e5f5:	je     81e625 <<gpui_gpu::renderer::RendererState>::render+0x555>
  81e5f7:	mov    0x43c(%rsp),%ecx
  81e5fe:	mov    0x440(%rsp),%rdx
  81e606:	movups 0x448(%rsp),%xmm0
  81e60e:	mov    0x50(%rsp),%rdi
  81e613:	movups %xmm0,0x10(%rdi)
  81e617:	mov    %eax,(%rdi)
  81e619:	mov    %ecx,0x4(%rdi)
  81e61c:	mov    %rdx,0x8(%rdi)
  81e620:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81e625:	mov    0x440(%rsp),%rdx
  81e62d:	add    0xd8(%rsp),%rdx
  81e635:	mov    0x8(%rsp),%rdi
  81e63a:	mov    0x10(%rdi),%rsi
  81e63e:	mov    $0x4,%ecx
  81e643:	mov    $0x10,%r8d
  81e649:	call   823cb0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e64e:	cmp    $0xffffffffffffffff,%rax
  81e652:	jne    81e4ec <<gpui_gpu::renderer::RendererState>::render+0x41c>
  81e658:	movzwl 0x10(%rsp),%eax
  81e65d:	mov    %eax,0x10(%rsp)
  81e661:	movzwl 0x18(%rsp),%eax
  81e666:	mov    %eax,0x88(%rsp)
  81e66d:	mov    0x8(%rsp),%rdi
  81e672:	mov    0x90(%rsp),%rsi
  81e67a:	mov    0x30(%rsp),%rdx
  81e67f:	call   825c10 <gpui_gpu::renderer::slots::write_prefix>
  81e684:	mov    0x8(%rsp),%rax
  81e689:	lea    0x48(%rax),%rdi
  81e68d:	movq   $0x0,0x58(%rax)
  81e695:	mov    %rdi,0x3f8(%rsp)
  81e69d:	mov    0x58(%rsp),%rsi
  81e6a2:	xor    %edx,%edx
  81e6a4:	call   822a10 <<alloc::vec::Vec<u32>>::resize>
  81e6a9:	mov    0x8(%rsp),%rax
  81e6ae:	movq   $0x0,0x70(%rax)
  81e6b6:	cmpq   $0x0,0x60(%rax)
  81e6bb:	jne    81e6cc <<gpui_gpu::renderer::RendererState>::render+0x5fc>
  81e6bd:	mov    0x8(%rsp),%rax
  81e6c2:	lea    0x60(%rax),%rdi
  81e6c6:	call   *0x66164c(%rip)        # e7fd18 <_DYNAMIC+0x5b0>
  81e6cc:	mov    0x8(%rsp),%rax
  81e6d1:	mov    0x68(%rax),%rcx
  81e6d5:	xorps  %xmm0,%xmm0
  81e6d8:	movups %xmm0,0x10(%rcx)
  81e6dc:	movups %xmm0,(%rcx)
  81e6df:	movq   $0x1,0x70(%rax)
  81e6e7:	lea    0x2f8(%rax),%rdi
  81e6ee:	call   8255c0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e6f3:	mov    0x88(%rsp),%ecx
  81e6fa:	shl    $0x10,%ecx
  81e6fd:	add    0x10(%rsp),%ecx
  81e701:	mov    0xb8(%rsp),%rax
  81e709:	mov    %rax,0x2d8(%rsp)
  81e711:	movq   $0x0,0x2e0(%rsp)
  81e71d:	mov    0xb0(%rsp),%rax
  81e725:	mov    %rax,0x2e8(%rsp)
  81e72d:	mov    0x238(%rsp),%rax
  81e735:	mov    %rax,0x2f0(%rsp)
  81e73d:	mov    %ecx,0x88(%rsp)
  81e744:	mov    %ecx,0x2f8(%rsp)
  81e74b:	lea    0x248(%rsp),%rdi
  81e753:	lea    0x2d8(%rsp),%rsi
  81e75b:	call   *0x6615bf(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81e761:	mov    0x248(%rsp),%rax
  81e769:	mov    %rax,0x18(%rsp)
  81e76e:	test   %rax,%rax
  81e771:	je     81f493 <<gpui_gpu::renderer::RendererState>::render+0x13c3>
  81e777:	movq   $0x0,0xd0(%rsp)
  81e783:	movq   $0x0,0x10(%rsp)
  81e78c:	movq   $0x0,0x58(%rsp)
  81e795:	movq   $0x0,0x228(%rsp)
  81e7a1:	movq   $0x0,0x230(%rsp)
  81e7ad:	mov    0x250(%rsp),%rcx
  81e7b5:	mov    0x258(%rsp),%rdx
  81e7bd:	mov    %rdx,0xa0(%rsp)
  81e7c5:	lea    0x260(%rsp),%rdi
  81e7cd:	movups (%rdi),%xmm0
  81e7d0:	movups 0x10(%rdi),%xmm1
  81e7d4:	movups 0x20(%rdi),%xmm2
  81e7d8:	movaps %xmm2,0x320(%rsp)
  81e7e0:	movaps %xmm1,0x310(%rsp)
  81e7e8:	movaps %xmm0,0x300(%rsp)
  81e7f0:	lea    0x290(%rsp),%r8
  81e7f8:	movups (%r8),%xmm0
  81e7fc:	movaps %xmm0,0x500(%rsp)
  81e804:	movups 0x40(%rdi),%xmm0
  81e808:	movaps %xmm0,0x420(%rsp)
  81e810:	mov    0x8(%rsp),%rax
  81e815:	movzbl 0x341(%rax),%esi
  81e81c:	mov    0x18(%rsp),%rax
  81e821:	mov    %rax,0x120(%rsp)
  81e829:	mov    %rcx,0x20(%rsp)
  81e82e:	mov    %rcx,0x128(%rsp)
  81e836:	mov    %rdx,0x130(%rsp)
  81e83e:	movups (%rdi),%xmm0
  81e841:	movups 0x10(%rdi),%xmm1
  81e845:	movups 0x20(%rdi),%xmm2
  81e849:	lea    0x138(%rsp),%rax
  81e851:	movups %xmm2,0x20(%rax)
  81e855:	movups %xmm1,0x10(%rax)
  81e859:	movups %xmm0,(%rax)
  81e85c:	movups (%r8),%xmm0
  81e860:	movups %xmm0,0x30(%rax)
  81e864:	movups 0x40(%rdi),%xmm0
  81e868:	movups %xmm0,0x40(%rax)
  81e86c:	lea    0x120(%rsp),%rdi
  81e874:	call   821650 <gpui_gpu::renderer::compact_group>
  81e879:	mov    %al,0x40(%rsp)
  81e87d:	lea    0x260(%rsp),%rsi
  81e885:	movups (%rsi),%xmm0
  81e888:	movups 0x10(%rsi),%xmm1
  81e88c:	movups 0x20(%rsi),%xmm2
  81e890:	movaps %xmm0,0x510(%rsp)
  81e898:	movaps %xmm1,0x520(%rsp)
  81e8a0:	movaps %xmm2,0x530(%rsp)
  81e8a8:	lea    0x290(%rsp),%rdx
  81e8b0:	movups (%rdx),%xmm0
  81e8b3:	movaps %xmm0,0x540(%rsp)
  81e8bb:	mov    0x8(%rsp),%rdi
  81e8c0:	call   81d450 <<gpui_gpu::renderer::RendererState>::correction>
  81e8c5:	mov    %eax,0x8c(%rsp)
  81e8cc:	mov    0xa0(%rsp),%rax
  81e8d4:	lea    0x0(,%rax,4),%rax
  81e8dc:	mov    %rax,0x3d0(%rsp)
  81e8e4:	cmpb   $0x0,0x40(%rsp)
  81e8e9:	je     81eabe <<gpui_gpu::renderer::RendererState>::render+0x9ee>
  81e8ef:	mov    0x20(%rsp),%rcx
  81e8f4:	mov    0xa0(%rsp),%rax
  81e8fc:	lea    (%rcx,%rax,4),%rax
  81e900:	mov    %rcx,0x400(%rsp)
  81e908:	mov    %rax,0x408(%rsp)
  81e910:	mov    0x18(%rsp),%rax
  81e915:	mov    %rax,0x410(%rsp)
  81e91d:	movq   $0x0,0x418(%rsp)
  81e929:	lea    0x330(%rsp),%rdi
  81e931:	lea    0x400(%rsp),%rsi
  81e939:	call   821ce0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e93e:	cmpb   $0xff,0x338(%rsp)
  81e946:	je     81eff1 <<gpui_gpu::renderer::RendererState>::render+0xf21>
  81e94c:	xorps  %xmm0,%xmm0
  81e94f:	movaps %xmm0,0xc0(%rsp)
  81e957:	movaps %xmm0,0x60(%rsp)
  81e95c:	mov    0x330(%rsp),%rdx
  81e964:	add    0x58(%rsp),%rdx
  81e969:	lea    0x338(%rsp),%rsi
  81e971:	movups 0x38(%rsi),%xmm0
  81e975:	lea    0x138(%rsp),%rcx
  81e97d:	movups %xmm0,0x20(%rcx)
  81e981:	movups 0x48(%rsi),%xmm0
  81e985:	movups %xmm0,0x70(%rcx)
  81e989:	mov    0x30(%rsi),%rax
  81e98d:	mov    %rax,0x150(%rsp)
  81e995:	movups (%rsi),%xmm0
  81e998:	movups 0x10(%rsi),%xmm1
  81e99c:	movups 0x20(%rsi),%xmm2
  81e9a0:	movaps %xmm2,0x140(%rsp)
  81e9a8:	movaps %xmm1,0x130(%rsp)
  81e9b0:	movaps %xmm0,0x120(%rsp)
  81e9b8:	lea    0x260(%rsp),%rax
  81e9c0:	movups 0x40(%rax),%xmm0
  81e9c4:	movups %xmm0,0x80(%rcx)
  81e9cb:	movups (%rax),%xmm0
  81e9ce:	movups 0x10(%rax),%xmm1
  81e9d2:	movups 0x20(%rax),%xmm2
  81e9d6:	movups %xmm2,0x50(%rcx)
  81e9da:	movups %xmm1,0x40(%rcx)
  81e9de:	movups %xmm0,0x30(%rcx)
  81e9e2:	lea    0x290(%rsp),%rax
  81e9ea:	movups (%rax),%xmm0
  81e9ed:	movups %xmm0,0x60(%rcx)
  81e9f1:	lea    0x100(%rsp),%rdi
  81e9f9:	lea    0x120(%rsp),%rsi
  81ea01:	mov    %r14d,%ecx
  81ea04:	mov    %r15d,%r8d
  81ea07:	call   8216a0 <gpui_gpu::renderer::validate_draw>
  81ea0c:	mov    0x100(%rsp),%ecx
  81ea13:	mov    0x104(%rsp),%rax
  81ea1b:	cmp    $0xffffffff,%ecx
  81ea1e:	jne    81f54b <<gpui_gpu::renderer::RendererState>::render+0x147b>
  81ea24:	mov    %eax,%ecx
  81ea26:	shr    $0x20,%rax
  81ea2a:	movd   %ecx,%xmm0
  81ea2e:	movaps 0xc0(%rsp),%xmm2
  81ea36:	movaps %xmm2,%xmm1
  81ea39:	maxss  %xmm0,%xmm1
  81ea3d:	movaps %xmm1,%xmm3
  81ea40:	cmpunordss %xmm1,%xmm3
  81ea45:	movaps %xmm3,%xmm0
  81ea48:	andnps %xmm1,%xmm0
  81ea4b:	andps  %xmm2,%xmm3
  81ea4e:	orps   %xmm0,%xmm3
  81ea51:	movaps %xmm3,0x40(%rsp)
  81ea56:	movd   %eax,%xmm0
  81ea5a:	movaps 0x60(%rsp),%xmm2
  81ea5f:	movaps %xmm2,%xmm1
  81ea62:	maxss  %xmm0,%xmm1
  81ea66:	movaps %xmm1,%xmm3
  81ea69:	cmpunordss %xmm1,%xmm3
  81ea6e:	movaps %xmm3,%xmm0
  81ea71:	andnps %xmm1,%xmm0
  81ea74:	andps  %xmm2,%xmm3
  81ea77:	orps   %xmm0,%xmm3
  81ea7a:	movaps %xmm3,0x70(%rsp)
  81ea7f:	lea    0x330(%rsp),%rdi
  81ea87:	lea    0x400(%rsp),%rsi
  81ea8f:	call   821ce0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea94:	cmpb   $0xff,0x338(%rsp)
  81ea9c:	movaps 0x40(%rsp),%xmm0
  81eaa1:	movaps %xmm0,0xc0(%rsp)
  81eaa9:	movaps 0x70(%rsp),%xmm0
  81eaae:	movaps %xmm0,0x60(%rsp)
  81eab3:	jne    81e95c <<gpui_gpu::renderer::RendererState>::render+0x88c>
  81eab9:	jmp    81effe <<gpui_gpu::renderer::RendererState>::render+0xf2e>
  81eabe:	cmpq   $0x0,0xa0(%rsp)
  81eac7:	je     81f43d <<gpui_gpu::renderer::RendererState>::render+0x136d>
  81eacd:	mov    0x8c(%rsp),%eax
  81ead4:	or     $0x80000000,%eax
  81ead9:	mov    %eax,0x240(%rsp)
  81eae0:	movq   $0x0,0x70(%rsp)
  81eae9:	mov    0x20(%rsp),%rax
  81eaee:	mov    0x70(%rsp),%rcx
  81eaf3:	mov    (%rax,%rcx,1),%edx
  81eaf6:	lea    0x120(%rsp),%rdi
  81eafe:	mov    0x18(%rsp),%rsi
  81eb03:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81eb08:	movzbl 0x120(%rsp),%edi
  81eb10:	lea    0x121(%rsp),%rdx
  81eb18:	mov    (%rdx),%eax
  81eb1a:	mov    0x3(%rdx),%ecx
  81eb1d:	lea    0x470(%rsp),%rsi
  81eb25:	mov    %ecx,-0x34(%rsi)
  81eb28:	mov    %eax,-0x37(%rsi)
  81eb2b:	mov    0x128(%rsp),%rcx
  81eb33:	mov    0x2f(%rdx),%rax
  81eb37:	mov    %rax,-0x8(%rsi)
  81eb3b:	movups 0xf(%rdx),%xmm0
  81eb3f:	movups 0x1f(%rdx),%xmm1
  81eb43:	movups %xmm1,-0x18(%rsi)
  81eb47:	movups %xmm0,-0x28(%rsi)
  81eb4b:	lea    0x138(%rsp),%rax
  81eb53:	movups 0x20(%rax),%xmm0
  81eb57:	movups %xmm0,(%rsi)
  81eb5a:	movups 0x30(%rax),%xmm0
  81eb5e:	movups %xmm0,0x50(%rsi)
  81eb62:	lea    0x260(%rsp),%rax
  81eb6a:	movups 0x40(%rax),%xmm0
  81eb6e:	movups %xmm0,0x60(%rsi)
  81eb72:	movups (%rax),%xmm0
  81eb75:	movups 0x10(%rax),%xmm1
  81eb79:	movups 0x20(%rax),%xmm2
  81eb7d:	movups %xmm2,0x30(%rsi)
  81eb81:	movups %xmm1,0x20(%rsi)
  81eb85:	movups %xmm0,0x10(%rsi)
  81eb89:	lea    0x290(%rsp),%rax
  81eb91:	movups (%rax),%xmm0
  81eb94:	movups %xmm0,0x40(%rsi)
  81eb98:	mov    %dil,0x60(%rsp)
  81eb9d:	mov    %dil,0x438(%rsp)
  81eba5:	mov    %rcx,0xc0(%rsp)
  81ebad:	mov    %rcx,0x440(%rsp)
  81ebb5:	lea    0x120(%rsp),%rdi
  81ebbd:	lea    0x438(%rsp),%rsi
  81ebc5:	mov    0x58(%rsp),%rdx
  81ebca:	mov    %r14d,%ecx
  81ebcd:	mov    %r15d,%r8d
  81ebd0:	call   8216a0 <gpui_gpu::renderer::validate_draw>
  81ebd5:	mov    0x120(%rsp),%eax
  81ebdc:	mov    0x124(%rsp),%rcx
  81ebe4:	mov    %rcx,0x40(%rsp)
  81ebe9:	cmp    $0xffffffff,%eax
  81ebec:	jne    81f5e1 <<gpui_gpu::renderer::RendererState>::render+0x1511>
  81ebf2:	movzbl 0x60(%rsp),%eax
  81ebf7:	cmp    $0x2,%al
  81ebf9:	sete   0x2f(%rsp)
  81ebfe:	cmpq   $0x0,0xc0(%rsp)
  81ec07:	setne  0x2e(%rsp)
  81ec0c:	movups 0x470(%rsp),%xmm0
  81ec14:	movaps %xmm0,0x2c0(%rsp)
  81ec1c:	cmp    $0x3,%al
  81ec1e:	jne    81ecb0 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  81ec24:	movss  0x43c(%rsp),%xmm0
  81ec2d:	xorps  %xmm1,%xmm1
  81ec30:	ucomiss %xmm1,%xmm0
  81ec33:	jne    81ec37 <<gpui_gpu::renderer::RendererState>::render+0xb67>
  81ec35:	jnp    81ecb0 <<gpui_gpu::renderer::RendererState>::render+0xbe0>
  81ec37:	movaps 0x2c0(%rsp),%xmm5
  81ec3f:	movaps %xmm5,%xmm1
  81ec42:	unpckhpd %xmm5,%xmm1
  81ec46:	movss  -0x76fce2(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ec4e:	mulss  %xmm4,%xmm1
  81ec52:	movaps %xmm0,%xmm2
  81ec55:	minss  %xmm1,%xmm2
  81ec59:	movaps %xmm2,%xmm1
  81ec5c:	cmpunordss %xmm2,%xmm1
  81ec61:	movaps %xmm1,%xmm3
  81ec64:	andnps %xmm2,%xmm3
  81ec67:	andps  %xmm0,%xmm1
  81ec6a:	orps   %xmm3,%xmm1
  81ec6d:	movaps %xmm5,%xmm0
  81ec70:	shufps $0xff,%xmm5,%xmm0
  81ec74:	mulss  %xmm4,%xmm0
  81ec78:	movaps %xmm1,%xmm2
  81ec7b:	minss  %xmm0,%xmm2
  81ec7f:	movaps %xmm2,%xmm0
  81ec82:	cmpunordss %xmm2,%xmm0
  81ec87:	andps  %xmm0,%xmm1
  81ec8a:	andnps %xmm2,%xmm0
  81ec8d:	orps   %xmm1,%xmm0
  81ec90:	movd   %xmm0,%eax
  81ec94:	mov    %eax,0x60(%rsp)
  81ec98:	and    $0xff800000,%eax
  81ec9d:	mov    $0x7f000000,%ecx
  81eca2:	sub    %eax,%ecx
  81eca4:	mov    %ecx,0xc0(%rsp)
  81ecab:	xorps  %xmm0,%xmm0
  81ecae:	jmp    81ecd2 <<gpui_gpu::renderer::RendererState>::render+0xc02>
  81ecb0:	mov    0x4d0(%rsp),%eax
  81ecb7:	mov    %eax,0x60(%rsp)
  81ecbb:	mov    0x4d4(%rsp),%eax
  81ecc2:	mov    %eax,0xc0(%rsp)
  81ecc9:	movsd  0x4d8(%rsp),%xmm0
  81ecd2:	movaps %xmm0,0x210(%rsp)
  81ecda:	mov    0x8(%rsp),%rax
  81ecdf:	mov    0x10(%rax),%ecx
  81ece2:	mov    $0x80000000,%eax
  81ece7:	or     %eax,%ecx
  81ece9:	mov    %ecx,0x390(%rsp)
  81ecf0:	movups 0x480(%rsp),%xmm0
  81ecf8:	movaps %xmm0,0x3c0(%rsp)
  81ed00:	movups 0x488(%rsp),%xmm0
  81ed08:	movaps %xmm0,0x4f0(%rsp)
  81ed10:	movsd  0x490(%rsp),%xmm0
  81ed19:	movaps %xmm0,0x3b0(%rsp)
  81ed21:	movsd  0x498(%rsp),%xmm0
  81ed2a:	movaps %xmm0,0x4e0(%rsp)
  81ed32:	movsd  0x4a0(%rsp),%xmm0
  81ed3b:	movsd  %xmm0,0x3e8(%rsp)
  81ed44:	movsd  0x4a8(%rsp),%xmm0
  81ed4d:	movsd  %xmm0,0x3e0(%rsp)
  81ed56:	movups 0x4b0(%rsp),%xmm0
  81ed5e:	movaps %xmm0,0x2b0(%rsp)
  81ed66:	mov    0x18(%rsp),%rax
  81ed6b:	mov    %rax,0x120(%rsp)
  81ed73:	mov    0x20(%rsp),%rax
  81ed78:	mov    %rax,0x128(%rsp)
  81ed80:	mov    0xa0(%rsp),%rax
  81ed88:	mov    %rax,0x130(%rsp)
  81ed90:	movaps 0x300(%rsp),%xmm0
  81ed98:	movaps 0x310(%rsp),%xmm1
  81eda0:	movaps 0x320(%rsp),%xmm2
  81eda8:	lea    0x138(%rsp),%rax
  81edb0:	movups %xmm2,0x20(%rax)
  81edb4:	movups %xmm1,0x10(%rax)
  81edb8:	movups %xmm0,(%rax)
  81edbb:	movaps 0x500(%rsp),%xmm0
  81edc3:	movups %xmm0,0x30(%rax)
  81edc7:	movaps 0x420(%rsp),%xmm0
  81edcf:	movups %xmm0,0x40(%rax)
  81edd3:	lea    0x120(%rsp),%rdi
  81eddb:	call   *0x660f47(%rip)        # e7fd28 <_DYNAMIC+0x5c0>
  81ede1:	mov    0x8c(%rsp),%ecx
  81ede8:	mov    %ecx,0xf0(%rsp)
  81edef:	test   %eax,%eax
  81edf1:	je     81ee27 <<gpui_gpu::renderer::RendererState>::render+0xd57>
  81edf3:	mov    0x30(%rsp),%rdi
  81edf8:	mov    %eax,%esi
  81edfa:	call   825bd0 <gpui_gpu::renderer::slots::color_word>
  81edff:	mov    %eax,0x60(%rsp)
  81ee03:	xorps  %xmm0,%xmm0
  81ee06:	movaps %xmm0,0x210(%rsp)
  81ee0e:	movl   $0x0,0xc0(%rsp)
  81ee19:	mov    0x240(%rsp),%eax
  81ee20:	mov    %eax,0xf0(%rsp)
  81ee27:	mov    0x40(%rsp),%rax
  81ee2c:	shr    $0x20,%rax
  81ee30:	mov    %rax,0x3d8(%rsp)
  81ee38:	mov    0x8(%rsp),%rax
  81ee3d:	mov    (%rax),%rcx
  81ee40:	mov    0x10(%rax),%rsi
  81ee44:	sub    %rsi,%rcx
  81ee47:	cmp    $0x5,%rcx
  81ee4b:	jbe    81efc9 <<gpui_gpu::renderer::RendererState>::render+0xef9>
  81ee51:	movsd  0x3e0(%rsp),%xmm0
  81ee5a:	cvtsd2ss %xmm0,%xmm0
  81ee5e:	movsd  0x3e8(%rsp),%xmm1
  81ee67:	cvtsd2ss %xmm1,%xmm1
  81ee6b:	movapd 0x4f0(%rsp),%xmm2
  81ee74:	unpcklpd 0x4e0(%rsp),%xmm2
  81ee7d:	cvtpd2ps %xmm2,%xmm2
  81ee81:	movapd 0x3c0(%rsp),%xmm3
  81ee8a:	unpcklpd 0x3b0(%rsp),%xmm3
  81ee93:	cvtpd2ps %xmm3,%xmm3
  81ee97:	mov    0x8(%rsp),%rax
  81ee9c:	mov    0x8(%rax),%rdx
  81eea0:	shl    $0x4,%rsi
  81eea4:	movaps 0x2c0(%rsp),%xmm4
  81eeac:	movups %xmm4,(%rdx,%rsi,1)
  81eeb0:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81eeb6:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81eebc:	mov    0x40(%rsp),%rcx
  81eec1:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81eec5:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81eecb:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81eed1:	mov    0x3d8(%rsp),%rdi
  81eed9:	mov    %edi,0x2c(%rdx,%rsi,1)
  81eedd:	movaps 0x2b0(%rsp),%xmm0
  81eee5:	movups %xmm0,0x30(%rdx,%rsi,1)
  81eeea:	mov    0x60(%rsp),%edi
  81eeee:	mov    %edi,0x40(%rdx,%rsi,1)
  81eef2:	mov    0xc0(%rsp),%edi
  81eef9:	mov    %edi,0x44(%rdx,%rsi,1)
  81eefd:	movaps 0x210(%rsp),%xmm0
  81ef05:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81ef0a:	movq   $0x0,0x50(%rdx,%rsi,1)
  81ef13:	movl   $0x0,0x58(%rdx,%rsi,1)
  81ef1b:	mov    0xf0(%rsp),%edi
  81ef22:	mov    %edi,0x5c(%rdx,%rsi,1)
  81ef26:	addq   $0x6,0x10(%rax)
  81ef2b:	lea    0x120(%rsp),%rdi
  81ef33:	mov    %rax,%rsi
  81ef36:	lea    0x438(%rsp),%rdx
  81ef3e:	mov    0x390(%rsp),%r8d
  81ef46:	mov    0x58(%rsp),%r9
  81ef4b:	push   0xd0(%rsp)
  81ef52:	push   %r15
  81ef54:	push   %r14
  81ef56:	push   0x50(%rsp)
  81ef5a:	call   8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ef5f:	add    $0x20,%rsp
  81ef63:	mov    0x120(%rsp),%eax
  81ef6a:	cmp    $0xffffffff,%eax
  81ef6d:	jne    81f5a9 <<gpui_gpu::renderer::RendererState>::render+0x14d9>
  81ef73:	movzbl 0x2f(%rsp),%ecx
  81ef78:	and    0x2e(%rsp),%cl
  81ef7c:	mov    0x10(%rsp),%rax
  81ef81:	or     %cl,%al
  81ef83:	mov    %rax,0x10(%rsp)
  81ef88:	mov    0x128(%rsp),%rax
  81ef90:	mov    %rax,0xd0(%rsp)
  81ef98:	incq   0x58(%rsp)
  81ef9d:	mov    0x70(%rsp),%rdx
  81efa2:	add    $0x4,%rdx
  81efa6:	mov    0xa0(%rsp),%rax
  81efae:	lea    0x0(,%rax,4),%rax
  81efb6:	mov    %rdx,0x70(%rsp)
  81efbb:	cmp    %rdx,%rax
  81efbe:	jne    81eae9 <<gpui_gpu::renderer::RendererState>::render+0xa19>
  81efc4:	jmp    81f431 <<gpui_gpu::renderer::RendererState>::render+0x1361>
  81efc9:	mov    $0x6,%edx
  81efce:	mov    $0x4,%ecx
  81efd3:	mov    $0x10,%r8d
  81efd9:	mov    0x8(%rsp),%rdi
  81efde:	call   823c20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81efe3:	mov    0x8(%rsp),%rax
  81efe8:	mov    0x10(%rax),%rsi
  81efec:	jmp    81ee51 <<gpui_gpu::renderer::RendererState>::render+0xd81>
  81eff1:	xorps  %xmm0,%xmm0
  81eff4:	movaps %xmm0,0x70(%rsp)
  81eff9:	movaps %xmm0,0x40(%rsp)
  81effe:	mov    0x8(%rsp),%rax
  81f003:	mov    0x10(%rax),%eax
  81f006:	mov    %eax,0x210(%rsp)
  81f00d:	movups 0x260(%rsp),%xmm1
  81f015:	movups 0x268(%rsp),%xmm2
  81f01d:	movsd  0x280(%rsp),%xmm0
  81f026:	movsd  %xmm0,0xf0(%rsp)
  81f02f:	movsd  0x288(%rsp),%xmm0
  81f038:	movsd  %xmm0,0x2c0(%rsp)
  81f041:	movups 0x290(%rsp),%xmm0
  81f049:	movaps %xmm0,0xc0(%rsp)
  81f051:	movhps 0x270(%rsp),%xmm1
  81f059:	movaps %xmm1,0x390(%rsp)
  81f061:	movups 0x2a0(%rsp),%xmm0
  81f069:	movaps %xmm0,0x60(%rsp)
  81f06e:	movhps 0x278(%rsp),%xmm2
  81f076:	movaps %xmm2,0x2b0(%rsp)
  81f07e:	mov    0x18(%rsp),%rax
  81f083:	mov    %rax,0x120(%rsp)
  81f08b:	mov    0x20(%rsp),%rax
  81f090:	mov    %rax,0x128(%rsp)
  81f098:	mov    0xa0(%rsp),%rax
  81f0a0:	mov    %rax,0x130(%rsp)
  81f0a8:	lea    0x260(%rsp),%rax
  81f0b0:	movups (%rax),%xmm0
  81f0b3:	movups 0x10(%rax),%xmm1
  81f0b7:	movups 0x20(%rax),%xmm2
  81f0bb:	lea    0x138(%rsp),%rdx
  81f0c3:	movups %xmm2,0x20(%rdx)
  81f0c7:	movups %xmm1,0x10(%rdx)
  81f0cb:	movups %xmm0,(%rdx)
  81f0ce:	lea    0x290(%rsp),%rcx
  81f0d6:	movups (%rcx),%xmm0
  81f0d9:	movups %xmm0,0x30(%rdx)
  81f0dd:	movdqu 0x40(%rax),%xmm0
  81f0e2:	movdqu %xmm0,0x40(%rdx)
  81f0e7:	lea    0x120(%rsp),%rdi
  81f0ef:	call   *0x660c33(%rip)        # e7fd28 <_DYNAMIC+0x5c0>
  81f0f5:	test   %eax,%eax
  81f0f7:	je     81f11a <<gpui_gpu::renderer::RendererState>::render+0x104a>
  81f0f9:	mov    0x30(%rsp),%rdi
  81f0fe:	mov    %eax,%esi
  81f100:	call   825bd0 <gpui_gpu::renderer::slots::color_word>
  81f105:	orl    $0x80000000,0x8c(%rsp)
  81f110:	movd   %eax,%xmm0
  81f114:	movdqa %xmm0,0x60(%rsp)
  81f11a:	mov    0x8(%rsp),%rax
  81f11f:	mov    (%rax),%rcx
  81f122:	mov    0x10(%rax),%rsi
  81f126:	sub    %rsi,%rcx
  81f129:	cmp    $0x4,%rcx
  81f12d:	jbe    81f46b <<gpui_gpu::renderer::RendererState>::render+0x139b>
  81f133:	cvtpd2ps 0x390(%rsp),%xmm0
  81f13c:	cvtpd2ps 0x2b0(%rsp),%xmm1
  81f145:	movsd  0xf0(%rsp),%xmm2
  81f14e:	cvtsd2ss %xmm2,%xmm2
  81f152:	movsd  0x2c0(%rsp),%xmm3
  81f15b:	cvtsd2ss %xmm3,%xmm3
  81f15f:	mov    0x8(%rsp),%rax
  81f164:	mov    0x8(%rax),%rcx
  81f168:	shl    $0x4,%rsi
  81f16c:	movlpd %xmm0,(%rcx,%rsi,1)
  81f171:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f177:	movaps 0x40(%rsp),%xmm0
  81f17c:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f182:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f188:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f18e:	movaps 0x70(%rsp),%xmm0
  81f193:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f199:	movaps 0xc0(%rsp),%xmm0
  81f1a1:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f1a6:	movaps 0x60(%rsp),%xmm0
  81f1ab:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f1b0:	mov    0x8c(%rsp),%edx
  81f1b7:	mov    %edx,0x40(%rcx,%rsi,1)
  81f1bb:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f1c4:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f1cc:	addq   $0x5,0x10(%rax)
  81f1d1:	incq   0x228(%rsp)
  81f1d9:	mov    0xa0(%rsp),%rax
  81f1e1:	add    %rax,0x230(%rsp)
  81f1e9:	test   %rax,%rax
  81f1ec:	je     81f43d <<gpui_gpu::renderer::RendererState>::render+0x136d>
  81f1f2:	movdqa 0x40(%rsp),%xmm0
  81f1f8:	movd   %xmm0,%ecx
  81f1fc:	movdqa 0x70(%rsp),%xmm0
  81f202:	movd   %xmm0,%eax
  81f206:	shl    $0x20,%rax
  81f20a:	or     %rax,%rcx
  81f20d:	mov    %rcx,0xf0(%rsp)
  81f215:	movq   $0x0,0x40(%rsp)
  81f21e:	mov    0x20(%rsp),%rax
  81f223:	mov    0x40(%rsp),%rcx
  81f228:	mov    (%rax,%rcx,1),%edx
  81f22b:	lea    0x330(%rsp),%rdi
  81f233:	mov    0x18(%rsp),%rsi
  81f238:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f23d:	movzbl 0x330(%rsp),%edi
  81f245:	lea    0x338(%rsp),%rsi
  81f24d:	mov    -0x7(%rsi),%eax
  81f250:	mov    -0x4(%rsi),%ecx
  81f253:	lea    0x121(%rsp),%rdx
  81f25b:	mov    %ecx,0x3(%rdx)
  81f25e:	mov    %eax,(%rdx)
  81f260:	mov    0x338(%rsp),%rcx
  81f268:	mov    0x28(%rsi),%rax
  81f26c:	mov    %rax,0x2f(%rdx)
  81f270:	movups 0x8(%rsi),%xmm0
  81f274:	movups 0x18(%rsi),%xmm1
  81f278:	movups %xmm1,0x1f(%rdx)
  81f27c:	movups %xmm0,0xf(%rdx)
  81f280:	movups 0x368(%rsp),%xmm1
  81f288:	lea    0x378(%rsp),%rax
  81f290:	movups (%rax),%xmm0
  81f293:	lea    0x138(%rsp),%rax
  81f29b:	movups %xmm0,0x70(%rax)
  81f29f:	movaps 0x420(%rsp),%xmm0
  81f2a7:	movups %xmm0,0x80(%rax)
  81f2ae:	movaps %xmm1,0xa0(%rsp)
  81f2b6:	movups %xmm1,0x158(%rsp)
  81f2be:	movaps 0x510(%rsp),%xmm0
  81f2c6:	movaps 0x520(%rsp),%xmm1
  81f2ce:	movapd 0x530(%rsp),%xmm2
  81f2d7:	movupd %xmm2,0x50(%rax)
  81f2dc:	movups %xmm1,0x40(%rax)
  81f2e0:	movups %xmm0,0x30(%rax)
  81f2e4:	movaps 0x540(%rsp),%xmm0
  81f2ec:	movups %xmm0,0x60(%rax)
  81f2f0:	mov    %dil,0x60(%rsp)
  81f2f5:	mov    %dil,0x120(%rsp)
  81f2fd:	mov    %rcx,0xc0(%rsp)
  81f305:	mov    %rcx,0x128(%rsp)
  81f30d:	mov    0x8(%rsp),%rax
  81f312:	mov    (%rax),%rcx
  81f315:	mov    0x10(%rax),%rax
  81f319:	sub    %rax,%rcx
  81f31c:	mov    %rax,0x70(%rsp)
  81f321:	cmp    $0x1,%rcx
  81f325:	jbe    81f404 <<gpui_gpu::renderer::RendererState>::render+0x1334>
  81f32b:	mov    0x8(%rsp),%rsi
  81f330:	mov    0x8(%rsi),%rcx
  81f334:	shl    $0x4,%rax
  81f338:	movaps 0xa0(%rsp),%xmm0
  81f340:	movups %xmm0,(%rcx,%rax,1)
  81f344:	movq   $0x0,0x10(%rcx,%rax,1)
  81f34d:	movl   $0x0,0x18(%rcx,%rax,1)
  81f355:	mov    0x210(%rsp),%edx
  81f35c:	mov    %edx,0x1c(%rcx,%rax,1)
  81f360:	addq   $0x2,0x10(%rsi)
  81f365:	lea    0x330(%rsp),%rdi
  81f36d:	lea    0x120(%rsp),%rdx
  81f375:	mov    0xf0(%rsp),%rcx
  81f37d:	mov    0x70(%rsp),%r8
  81f382:	mov    0x58(%rsp),%r9
  81f387:	push   0xd0(%rsp)
  81f38e:	push   %r15
  81f390:	push   %r14
  81f392:	push   0x50(%rsp)
  81f396:	call   8205f0 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f39b:	add    $0x20,%rsp
  81f39f:	mov    0x330(%rsp),%eax
  81f3a6:	cmp    $0xffffffff,%eax
  81f3a9:	jne    81f5c5 <<gpui_gpu::renderer::RendererState>::render+0x14f5>
  81f3af:	cmpb   $0x2,0x60(%rsp)
  81f3b4:	sete   %al
  81f3b7:	cmpq   $0x0,0xc0(%rsp)
  81f3c0:	setne  %cl
  81f3c3:	and    %al,%cl
  81f3c5:	mov    0x10(%rsp),%rax
  81f3ca:	or     %cl,%al
  81f3cc:	mov    %rax,0x10(%rsp)
  81f3d1:	mov    0x338(%rsp),%rax
  81f3d9:	mov    %rax,0xd0(%rsp)
  81f3e1:	incq   0x58(%rsp)
  81f3e6:	mov    0x40(%rsp),%rcx
  81f3eb:	add    $0x4,%rcx
  81f3ef:	mov    %rcx,0x40(%rsp)
  81f3f4:	cmp    %rcx,0x3d0(%rsp)
  81f3fc:	jne    81f21e <<gpui_gpu::renderer::RendererState>::render+0x114e>
  81f402:	jmp    81f431 <<gpui_gpu::renderer::RendererState>::render+0x1361>
  81f404:	mov    $0x2,%edx
  81f409:	mov    $0x4,%ecx
  81f40e:	mov    $0x10,%r8d
  81f414:	mov    0x8(%rsp),%rdi
  81f419:	mov    0x70(%rsp),%rsi
  81f41e:	call   823c20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f423:	mov    0x8(%rsp),%rax
  81f428:	mov    0x10(%rax),%rax
  81f42c:	jmp    81f32b <<gpui_gpu::renderer::RendererState>::render+0x125b>
  81f431:	mov    0x10(%rsp),%rax
  81f436:	and    $0x1,%al
  81f438:	mov    %rax,0x10(%rsp)
  81f43d:	lea    0x248(%rsp),%rdi
  81f445:	lea    0x2d8(%rsp),%rsi
  81f44d:	call   *0x6608cd(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81f453:	mov    0x248(%rsp),%rax
  81f45b:	mov    %rax,0x18(%rsp)
  81f460:	test   %rax,%rax
  81f463:	jne    81e7ad <<gpui_gpu::renderer::RendererState>::render+0x6dd>
  81f469:	jmp    81f4c9 <<gpui_gpu::renderer::RendererState>::render+0x13f9>
  81f46b:	mov    $0x5,%edx
  81f470:	mov    $0x4,%ecx
  81f475:	mov    $0x10,%r8d
  81f47b:	mov    0x8(%rsp),%rdi
  81f480:	call   823c20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f485:	mov    0x8(%rsp),%rax
  81f48a:	mov    0x10(%rax),%rsi
  81f48e:	jmp    81f133 <<gpui_gpu::renderer::RendererState>::render+0x1063>
  81f493:	movq   $0x0,0x230(%rsp)
  81f49f:	movq   $0x0,0x228(%rsp)
  81f4ab:	movq   $0x0,0x58(%rsp)
  81f4b4:	movq   $0x0,0x10(%rsp)
  81f4bd:	movq   $0x0,0xd0(%rsp)
  81f4c9:	mov    0xe8(%rsp),%rsi
  81f4d1:	lea    0x8(%rsi),%rdx
  81f4d5:	mov    0x8(%rsp),%rax
  81f4da:	lea    0x258(%rax),%rcx
  81f4e1:	lea    0x328(%rax),%r8
  81f4e8:	mov    0x10(%rax),%r9
  81f4ec:	sub    $0x8,%rsp
  81f4f0:	lea    0x128(%rsp),%rdi
  81f4f8:	mov    %rdx,0x3c8(%rsp)
  81f500:	mov    %rcx,0x2b8(%rsp)
  81f508:	mov    %r8,0x2c8(%rsp)
  81f510:	push   0x98(%rsp)
  81f517:	call   822b60 <gpui_gpu::renderer::images::prepare>
  81f51c:	add    $0x10,%rsp
  81f520:	cmpl   $0xffffffff,0x120(%rsp)
  81f528:	je     81f571 <<gpui_gpu::renderer::RendererState>::render+0x14a1>
  81f52a:	movups 0x120(%rsp),%xmm0
  81f532:	movups 0x130(%rsp),%xmm1
  81f53a:	mov    0x50(%rsp),%rdi
  81f53f:	movups %xmm1,0x10(%rdi)
  81f543:	movups %xmm0,(%rdi)
  81f546:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81f54b:	mov    0x11c(%rsp),%edx
  81f552:	mov    0x50(%rsp),%rdi
  81f557:	mov    %edx,0x1c(%rdi)
  81f55a:	movups 0x10c(%rsp),%xmm0
  81f562:	movups %xmm0,0xc(%rdi)
  81f566:	mov    %ecx,(%rdi)
  81f568:	mov    %rax,0x4(%rdi)
  81f56c:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81f571:	movzbl 0x10(%rsp),%r8d
  81f577:	and    $0x1,%r8d
  81f57b:	lea    0x120(%rsp),%rdi
  81f583:	mov    0x8(%rsp),%rsi
  81f588:	mov    0xe8(%rsp),%rdx
  81f590:	mov    0xb8(%rsp),%rcx
  81f598:	call   81d830 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f59d:	mov    0x120(%rsp),%eax
  81f5a4:	cmp    $0xffffffff,%eax
  81f5a7:	je     81f60c <<gpui_gpu::renderer::RendererState>::render+0x153c>
  81f5a9:	mov    0x124(%rsp),%ecx
  81f5b0:	mov    0x128(%rsp),%rdx
  81f5b8:	movups 0x130(%rsp),%xmm0
  81f5c0:	jmp    81e60e <<gpui_gpu::renderer::RendererState>::render+0x53e>
  81f5c5:	mov    0x334(%rsp),%ecx
  81f5cc:	mov    0x338(%rsp),%rdx
  81f5d4:	movups 0x340(%rsp),%xmm0
  81f5dc:	jmp    81e60e <<gpui_gpu::renderer::RendererState>::render+0x53e>
  81f5e1:	mov    0x13c(%rsp),%ecx
  81f5e8:	mov    0x50(%rsp),%rdi
  81f5ed:	mov    %ecx,0x1c(%rdi)
  81f5f0:	movups 0x12c(%rsp),%xmm0
  81f5f8:	movups %xmm0,0xc(%rdi)
  81f5fc:	mov    %eax,(%rdi)
  81f5fe:	mov    0x40(%rsp),%rax
  81f603:	mov    %rax,0x4(%rdi)
  81f607:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  81f60c:	mov    0x128(%rsp),%rax
  81f614:	mov    %rax,0x3b0(%rsp)
  81f61c:	mov    0xb8(%rsp),%rax
  81f624:	mov    %rax,0x330(%rsp)
  81f62c:	movq   $0x0,0x338(%rsp)
  81f638:	mov    0xb0(%rsp),%rax
  81f640:	mov    %rax,0x340(%rsp)
  81f648:	mov    0x238(%rsp),%rax
  81f650:	mov    %rax,0x348(%rsp)
  81f658:	mov    0x88(%rsp),%eax
  81f65f:	mov    %eax,0x350(%rsp)
  81f666:	lea    0x248(%rsp),%rdi
  81f66e:	lea    0x330(%rsp),%rsi
  81f676:	call   *0x6606a4(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81f67c:	mov    0x248(%rsp),%rax
  81f684:	mov    %rax,0xa0(%rsp)
  81f68c:	test   %rax,%rax
  81f68f:	je     81fa60 <<gpui_gpu::renderer::RendererState>::render+0x1990>
  81f695:	mov    0x8(%rsp),%rax
  81f69a:	add    $0x120,%rax
  81f6a0:	mov    %rax,0x390(%rsp)
  81f6a8:	jmp    81f6e6 <<gpui_gpu::renderer::RendererState>::render+0x1616>
  81f6aa:	lea    0x248(%rsp),%rdi
  81f6b2:	lea    0x330(%rsp),%rsi
  81f6ba:	call   *0x660660(%rip)        # e7fd20 <_DYNAMIC+0x5b8>
  81f6c0:	mov    0x248(%rsp),%rax
  81f6c8:	mov    0x10(%rsp),%rcx
  81f6cd:	mov    %rcx,0xd8(%rsp)
  81f6d5:	mov    %rax,0xa0(%rsp)
  81f6dd:	test   %rax,%rax
  81f6e0:	je     81fa60 <<gpui_gpu::renderer::RendererState>::render+0x1990>
  81f6e6:	mov    0x250(%rsp),%rdx
  81f6ee:	mov    0x258(%rsp),%rdi
  81f6f6:	mov    %rdi,0x70(%rsp)
  81f6fb:	lea    0x260(%rsp),%rax
  81f703:	movups 0x40(%rax),%xmm0
  81f707:	lea    0x138(%rsp),%rcx
  81f70f:	movups %xmm0,0x40(%rcx)
  81f713:	movups (%rax),%xmm0
  81f716:	movups 0x10(%rax),%xmm1
  81f71a:	movups 0x20(%rax),%xmm2
  81f71e:	movups 0x30(%rax),%xmm3
  81f722:	movups %xmm3,0x30(%rcx)
  81f726:	movups %xmm2,0x20(%rcx)
  81f72a:	movups %xmm1,0x10(%rcx)
  81f72e:	movups %xmm0,(%rcx)
  81f731:	mov    0x8(%rsp),%rax
  81f736:	movzbl 0x341(%rax),%esi
  81f73d:	mov    0xa0(%rsp),%rax
  81f745:	mov    %rax,0x120(%rsp)
  81f74d:	mov    %rdx,0x60(%rsp)
  81f752:	mov    %rdx,0x128(%rsp)
  81f75a:	mov    %rdi,0x130(%rsp)
  81f762:	lea    0x120(%rsp),%rdi
  81f76a:	call   821650 <gpui_gpu::renderer::compact_group>
  81f76f:	mov    0xd8(%rsp),%rcx
  81f777:	lea    0x5(%rcx),%rdx
  81f77b:	test   %al,%al
  81f77d:	cmove  %rcx,%rdx
  81f781:	mov    %rdx,0x10(%rsp)
  81f786:	cmpq   $0x0,0x70(%rsp)
  81f78c:	je     81f6aa <<gpui_gpu::renderer::RendererState>::render+0x15da>
  81f792:	shlq   $0x2,0x70(%rsp)
  81f798:	xor    $0x1,%al
  81f79a:	movzbl %al,%ecx
  81f79d:	shl    $0x2,%ecx
  81f7a0:	lea    0x1(%rcx),%rax
  81f7a4:	mov    %rax,0xc0(%rsp)
  81f7ac:	mov    0x10(%rsp),%rax
  81f7b1:	lea    (%rax,%rcx,1),%r8
  81f7b5:	inc    %r8
  81f7b8:	or     $0x2,%rcx
  81f7bc:	shl    $0x4,%r8
  81f7c0:	mov    %rcx,0xd8(%rsp)
  81f7c8:	shl    $0x4,%ecx
  81f7cb:	mov    %rcx,0x210(%rsp)
  81f7d3:	xor    %ecx,%ecx
  81f7d5:	mov    %r8,0x18(%rsp)
  81f7da:	mov    0x60(%rsp),%rax
  81f7df:	mov    %rcx,0x30(%rsp)
  81f7e4:	mov    (%rax,%rcx,1),%edx
  81f7e7:	lea    0x120(%rsp),%rdi
  81f7ef:	mov    0xa0(%rsp),%rsi
  81f7f7:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f7fc:	movzbl 0x120(%rsp),%ecx
  81f804:	movzbl 0x121(%rsp),%eax
  81f80c:	movss  0x124(%rsp),%xmm4
  81f815:	lea    0x128(%rsp),%rsi
  81f81d:	mov    0x10(%rsi),%rdx
  81f821:	mov    %rdx,0x310(%rsp)
  81f829:	movups (%rsi),%xmm0
  81f82c:	movaps %xmm0,0x300(%rsp)
  81f834:	cmp    $0x1,%ecx
  81f837:	je     81f8cc <<gpui_gpu::renderer::RendererState>::render+0x17fc>
  81f83d:	movaps %xmm4,0xf0(%rsp)
  81f845:	mov    0x140(%rsp),%rsi
  81f84d:	mov    0x148(%rsp),%edx
  81f854:	mov    %edx,0x40(%rsp)
  81f858:	mov    0x14c(%rsp),%edx
  81f85f:	mov    %edx,0x20(%rsp)
  81f863:	cmp    $0x3,%ecx
  81f866:	jne    81f951 <<gpui_gpu::renderer::RendererState>::render+0x1881>
  81f86c:	mov    0x2c0(%rsp),%rcx
  81f874:	mov    (%rcx),%rdi
  81f877:	test   %rdi,%rdi
  81f87a:	je     82056e <<gpui_gpu::renderer::RendererState>::render+0x249e>
  81f880:	movzbl %al,%edx
  81f883:	call   8227f0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f888:	mov    %eax,%ecx
  81f88a:	shr    $0x20,%rax
  81f88e:	mov    %eax,%edx
  81f890:	or     $0x10,%edx
  81f893:	xorps  %xmm0,%xmm0
  81f896:	movaps 0xf0(%rsp),%xmm1
  81f89e:	ucomiss %xmm0,%xmm1
  81f8a1:	cmovne %edx,%eax
  81f8a4:	cmovp  %edx,%eax
  81f8a7:	mov    0x20(%rsp),%edx
  81f8ab:	shl    $0x10,%edx
  81f8ae:	or     0x40(%rsp),%edx
  81f8b2:	mov    %ecx,0x100(%rsp)
  81f8b9:	mov    %eax,0x104(%rsp)
  81f8c0:	mov    %edx,0x108(%rsp)
  81f8c7:	jmp    81f9ee <<gpui_gpu::renderer::RendererState>::render+0x191e>
  81f8cc:	movss  0x160(%rsp),%xmm0
  81f8d5:	movss  -0x770971(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f8dd:	mulss  %xmm3,%xmm0
  81f8e1:	movaps %xmm4,%xmm1
  81f8e4:	minss  %xmm0,%xmm1
  81f8e8:	movaps %xmm1,%xmm0
  81f8eb:	cmpunordss %xmm1,%xmm0
  81f8f0:	movaps %xmm0,%xmm2
  81f8f3:	andnps %xmm1,%xmm2
  81f8f6:	andps  %xmm4,%xmm0
  81f8f9:	orps   %xmm2,%xmm0
  81f8fc:	movss  0x164(%rsp),%xmm1
  81f905:	mulss  %xmm3,%xmm1
  81f909:	movaps %xmm0,%xmm2
  81f90c:	minss  %xmm1,%xmm2
  81f910:	movaps %xmm2,%xmm1
  81f913:	cmpunordss %xmm2,%xmm1
  81f918:	andps  %xmm1,%xmm0
  81f91b:	andnps %xmm2,%xmm1
  81f91e:	orps   %xmm0,%xmm1
  81f921:	movd   %xmm1,%eax
  81f925:	and    $0xff800000,%eax
  81f92a:	mov    $0x7f000000,%ecx
  81f92f:	sub    %eax,%ecx
  81f931:	movl   $0x40000000,0x100(%rsp)
  81f93c:	movss  %xmm1,0x104(%rsp)
  81f945:	mov    %ecx,0x108(%rsp)
  81f94c:	jmp    81f9ee <<gpui_gpu::renderer::RendererState>::render+0x191e>
  81f951:	cmp    $0x2,%cl
  81f954:	jne    81f9a6 <<gpui_gpu::renderer::RendererState>::render+0x18d6>
  81f956:	mov    0x150(%rsp),%rax
  81f95e:	mov    0x310(%rsp),%rcx
  81f966:	mov    %rcx,0x130(%rsp)
  81f96e:	movaps 0x300(%rsp),%xmm0
  81f976:	movaps %xmm0,0x120(%rsp)
  81f97e:	mov    %rsi,0x138(%rsp)
  81f986:	mov    0x40(%rsp),%ecx
  81f98a:	mov    %ecx,0x140(%rsp)
  81f991:	mov    0x20(%rsp),%ecx
  81f995:	mov    %ecx,0x144(%rsp)
  81f99c:	mov    %rax,0x148(%rsp)
  81f9a4:	jmp    81f9b2 <<gpui_gpu::renderer::RendererState>::render+0x18e2>
  81f9a6:	movq   $0x0,0x120(%rsp)
  81f9b2:	movl   $0x0,0x2e0(%rsp)
  81f9bd:	movq   $0x0,0x2d8(%rsp)
  81f9c9:	lea    0x100(%rsp),%rdi
  81f9d1:	lea    0x120(%rsp),%rsi
  81f9d9:	lea    0x2d8(%rsp),%rdx
  81f9e1:	mov    0x390(%rsp),%rcx
  81f9e9:	call   81b6f0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f9ee:	mov    0x10(%rsp),%rdx
  81f9f3:	mov    0xc0(%rsp),%rax
  81f9fb:	lea    (%rax,%rdx,1),%rdi
  81f9ff:	mov    0x8(%rsp),%rax
  81fa04:	mov    0x10(%rax),%rsi
  81fa08:	cmp    %rsi,%rdi
  81fa0b:	mov    0x18(%rsp),%r8
  81fa10:	jae    82057b <<gpui_gpu::renderer::RendererState>::render+0x24ab>
  81fa16:	mov    0x8(%rax),%rax
  81fa1a:	mov    0x108(%rsp),%ecx
  81fa21:	mov    %ecx,0x8(%rax,%r8,1)
  81fa26:	mov    0x100(%rsp),%rcx
  81fa2e:	mov    %rcx,(%rax,%r8,1)
  81fa32:	add    0xd8(%rsp),%rdx
  81fa3a:	mov    %rdx,0x10(%rsp)
  81fa3f:	add    0x210(%rsp),%r8
  81fa47:	mov    0x30(%rsp),%rcx
  81fa4c:	add    $0x4,%rcx
  81fa50:	cmp    %rcx,0x70(%rsp)
  81fa55:	jne    81f7d5 <<gpui_gpu::renderer::RendererState>::render+0x1705>
  81fa5b:	jmp    81f6aa <<gpui_gpu::renderer::RendererState>::render+0x15da>
  81fa60:	mov    0x8(%rsp),%rax
  81fa65:	mov    0x28(%rax),%rax
  81fa69:	movq   $0x0,0x60(%rsp)
  81fa72:	test   %rax,%rax
  81fa75:	je     81fae2 <<gpui_gpu::renderer::RendererState>::render+0x1a12>
  81fa77:	mov    0x8(%rsp),%rcx
  81fa7c:	mov    0x20(%rcx),%rcx
  81fa80:	shl    $0x3,%rax
  81fa84:	xor    %edi,%edi
  81fa86:	jmp    81faa4 <<gpui_gpu::renderer::RendererState>::render+0x19d4>
  81fa88:	mov    0x60(%rsp),%rdx
  81fa8d:	add    %esi,%edx
  81fa8f:	mov    %edx,(%rcx,%rdi,8)
  81fa92:	mov    %rdx,0x60(%rsp)
  81fa97:	mov    %edx,0x4(%rcx,%rdi,8)
  81fa9b:	inc    %rdi
  81fa9e:	add    $0xfffffffffffffff8,%rax
  81faa2:	je     81fad6 <<gpui_gpu::renderer::RendererState>::render+0x1a06>
  81faa4:	mov    0x8(%rsp),%rdx
  81faa9:	mov    0x58(%rdx),%rsi
  81faad:	cmp    %rsi,%rdi
  81fab0:	jae    820588 <<gpui_gpu::renderer::RendererState>::render+0x24b8>
  81fab6:	mov    0x4(%rcx,%rdi,8),%esi
  81faba:	cmp    $0x1,%esi
  81fabd:	jne    81fa88 <<gpui_gpu::renderer::RendererState>::render+0x19b8>
  81fabf:	mov    0x8(%rsp),%rdx
  81fac4:	mov    0x50(%rdx),%r8
  81fac8:	mov    $0x80000000,%edx
  81facd:	cmpl   $0x0,(%r8,%rdi,4)
  81fad2:	jne    81fa97 <<gpui_gpu::renderer::RendererState>::render+0x19c7>
  81fad4:	jmp    81fa88 <<gpui_gpu::renderer::RendererState>::render+0x19b8>
  81fad6:	mov    0x60(%rsp),%rax
  81fadb:	mov    %eax,%eax
  81fadd:	mov    %rax,0x60(%rsp)
  81fae2:	mov    0x8(%rsp),%rax
  81fae7:	lea    0x30(%rax),%rdi
  81faeb:	movq   $0x0,0x40(%rax)
  81faf3:	mov    %rdi,0xa0(%rsp)
  81fafb:	mov    0x60(%rsp),%rsi
  81fb00:	xor    %edx,%edx
  81fb02:	call   822a10 <<alloc::vec::Vec<u32>>::resize>
  81fb07:	mov    0x8(%rsp),%rax
  81fb0c:	mov    0x10(%rax),%rax
  81fb10:	mov    %rax,0x20(%rsp)
  81fb15:	mov    0x58(%rsp),%rax
  81fb1a:	mov    %rax,0x100(%rsp)
  81fb22:	mov    0xb8(%rsp),%rax
  81fb2a:	mov    %rax,0x2d8(%rsp)
  81fb32:	movq   $0x0,0x2e0(%rsp)
  81fb3e:	mov    0xb0(%rsp),%rax
  81fb46:	mov    %rax,0x2e8(%rsp)
  81fb4e:	mov    0x238(%rsp),%rax
  81fb56:	mov    %rax,0x2f0(%rsp)
  81fb5e:	mov    0x88(%rsp),%eax
  81fb65:	mov    %eax,0x2f8(%rsp)
  81fb6c:	jmp    81fb88 <<gpui_gpu::renderer::RendererState>::render+0x1ab8>
  81fb6e:	mov    0x20(%rsp),%rcx
  81fb73:	lea    -0x5(%rcx),%rax
  81fb77:	cmpb   $0x0,0xb0(%rsp)
  81fb7f:	cmovne %rax,%rcx
  81fb83:	mov    %rcx,0x20(%rsp)
  81fb88:	lea    0x248(%rsp),%rdi
  81fb90:	lea    0x2d8(%rsp),%rsi
  81fb98:	call   *0x660192(%rip)        # e7fd30 <_DYNAMIC+0x5c8>
  81fb9e:	mov    0x248(%rsp),%rax
  81fba6:	mov    %rax,0x40(%rsp)
  81fbab:	test   %rax,%rax
  81fbae:	je     81fe03 <<gpui_gpu::renderer::RendererState>::render+0x1d33>
  81fbb4:	mov    0x250(%rsp),%rcx
  81fbbc:	mov    0x258(%rsp),%rdx
  81fbc4:	mov    %rdx,0x18(%rsp)
  81fbc9:	mov    0x8(%rsp),%rax
  81fbce:	movzbl 0x341(%rax),%esi
  81fbd5:	mov    0x40(%rsp),%rax
  81fbda:	mov    %rax,0x120(%rsp)
  81fbe2:	mov    %rcx,0x70(%rsp)
  81fbe7:	mov    %rcx,0x128(%rsp)
  81fbef:	mov    %rdx,0x130(%rsp)
  81fbf7:	lea    0x260(%rsp),%rax
  81fbff:	movups (%rax),%xmm0
  81fc02:	movups 0x10(%rax),%xmm1
  81fc06:	movdqu 0x20(%rax),%xmm2
  81fc0b:	lea    0x138(%rsp),%rdx
  81fc13:	movdqu %xmm2,0x20(%rdx)
  81fc18:	movups %xmm1,0x10(%rdx)
  81fc1c:	movups %xmm0,(%rdx)
  81fc1f:	lea    0x290(%rsp),%rcx
  81fc27:	movups (%rcx),%xmm0
  81fc2a:	movups %xmm0,0x30(%rdx)
  81fc2e:	movups 0x40(%rax),%xmm0
  81fc32:	movups %xmm0,0x40(%rdx)
  81fc36:	lea    0x120(%rsp),%rdi
  81fc3e:	call   821650 <gpui_gpu::renderer::compact_group>
  81fc43:	mov    %al,0xb0(%rsp)
  81fc4a:	mov    0x18(%rsp),%rax
  81fc4f:	test   %rax,%rax
  81fc52:	je     81fb6e <<gpui_gpu::renderer::RendererState>::render+0x1a9e>
  81fc58:	mov    %rax,%rcx
  81fc5b:	shl    $0x2,%rcx
  81fc5f:	movzbl 0xb0(%rsp),%eax
  81fc67:	lea    0x0(,%rax,4),%edx
  81fc6e:	or     $0xfffffffffffffffa,%rdx
  81fc72:	xor    %esi,%esi
  81fc74:	test   %al,%al
  81fc76:	sete   %sil
  81fc7a:	shl    $0x1f,%esi
  81fc7d:	mov    %esi,0xb8(%rsp)
  81fc84:	mov    %rdx,0x30(%rsp)
  81fc89:	mov    0x20(%rsp),%rax
  81fc8e:	add    %edx,%eax
  81fc90:	mov    %eax,0x10(%rsp)
  81fc94:	mov    %rcx,0x18(%rsp)
  81fc99:	mov    0x70(%rsp),%rax
  81fc9e:	mov    -0x4(%rax,%rcx,1),%edx
  81fca2:	lea    0x330(%rsp),%rdi
  81fcaa:	mov    0x40(%rsp),%rsi
  81fcaf:	call   81c970 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fcb4:	decq   0x100(%rsp)
  81fcbc:	mov    0x30(%rsp),%rax
  81fcc1:	add    %rax,0x20(%rsp)
  81fcc6:	mov    0xb8(%rsp),%eax
  81fccd:	or     0x10(%rsp),%eax
  81fcd1:	mov    %eax,0x400(%rsp)
  81fcd8:	lea    0x260(%rsp),%rax
  81fce0:	movups (%rax),%xmm0
  81fce3:	movups 0x10(%rax),%xmm1
  81fce7:	movups 0x20(%rax),%xmm2
  81fceb:	lea    0x138(%rsp),%rdx
  81fcf3:	movups %xmm2,0x50(%rdx)
  81fcf7:	movups %xmm1,0x40(%rdx)
  81fcfb:	movups %xmm0,0x30(%rdx)
  81fcff:	lea    0x290(%rsp),%rcx
  81fd07:	movups (%rcx),%xmm0
  81fd0a:	movups %xmm0,0x60(%rdx)
  81fd0e:	movups 0x40(%rax),%xmm0
  81fd12:	movups %xmm0,0x80(%rdx)
  81fd19:	lea    0x368(%rsp),%rax
  81fd21:	movups (%rax),%xmm0
  81fd24:	movups %xmm0,0x20(%rdx)
  81fd28:	lea    0x378(%rsp),%rax
  81fd30:	movups (%rax),%xmm0
  81fd33:	movups %xmm0,0x70(%rdx)
  81fd37:	mov    0x360(%rsp),%rax
  81fd3f:	mov    %rax,0x150(%rsp)
  81fd47:	movups 0x330(%rsp),%xmm0
  81fd4f:	movups 0x340(%rsp),%xmm1
  81fd57:	movdqu 0x350(%rsp),%xmm2
  81fd60:	movdqa %xmm2,0x140(%rsp)
  81fd69:	movaps %xmm1,0x130(%rsp)
  81fd71:	movaps %xmm0,0x120(%rsp)
  81fd79:	mov    0x98(%rsp),%rax
  81fd81:	mov    %rax,0x300(%rsp)
  81fd89:	mov    0xa0(%rsp),%rax
  81fd91:	mov    %rax,0x308(%rsp)
  81fd99:	mov    0x3f8(%rsp),%rax
  81fda1:	mov    %rax,0x310(%rsp)
  81fda9:	lea    0x100(%rsp),%rax
  81fdb1:	mov    %rax,0x318(%rsp)
  81fdb9:	lea    0x400(%rsp),%rax
  81fdc1:	mov    %rax,0x320(%rsp)
  81fdc9:	lea    0x120(%rsp),%rdi
  81fdd1:	mov    0x38(%rsp),%rsi
  81fdd6:	lea    0x300(%rsp),%rdx
  81fdde:	call   81c5b0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81fde3:	mov    0x10(%rsp),%eax
  81fde7:	add    0x30(%rsp),%eax
  81fdeb:	mov    %eax,0x10(%rsp)
  81fdef:	mov    0x18(%rsp),%rcx
  81fdf4:	add    $0xfffffffffffffffc,%rcx
  81fdf8:	jne    81fc94 <<gpui_gpu::renderer::RendererState>::render+0x1bc4>
  81fdfe:	jmp    81fb6e <<gpui_gpu::renderer::RendererState>::render+0x1a9e>
  81fe03:	mov    0x8(%rsp),%rax
  81fe08:	mov    0x28(%rax),%rdi
  81fe0c:	movq   $0x0,0x98(%rsp)
  81fe18:	test   %rdi,%rdi
  81fe1b:	je     81feeb <<gpui_gpu::renderer::RendererState>::render+0x1e1b>
  81fe21:	mov    0x8(%rsp),%rax
  81fe26:	mov    0x20(%rax),%r8
  81fe2a:	shl    $0x3,%rdi
  81fe2e:	cmpl   $0x0,0x38(%rsp)
  81fe33:	je     820528 <<gpui_gpu::renderer::RendererState>::render+0x2458>
  81fe39:	movq   $0x0,0x30(%rsp)
  81fe42:	movq   $0x0,0x18(%rsp)
  81fe4b:	movq   $0x0,0x10(%rsp)
  81fe54:	xor    %r9d,%r9d
  81fe57:	xor    %ecx,%ecx
  81fe59:	jmp    81fe7e <<gpui_gpu::renderer::RendererState>::render+0x1dae>
  81fe5b:	incq   0x10(%rsp)
  81fe60:	inc    %r9
  81fe63:	cmp    0x38(%rsp),%r9
  81fe68:	mov    $0x0,%eax
  81fe6d:	cmove  %rax,%r9
  81fe71:	inc    %rcx
  81fe74:	add    $0xfffffffffffffff8,%rdi
  81fe78:	je     81ff06 <<gpui_gpu::renderer::RendererState>::render+0x1e36>
  81fe7e:	mov    0x4(%r8,%rcx,8),%r10d
  81fe83:	mov    %r10d,%eax
  81fe86:	neg    %eax
  81fe88:	jo     81fe5b <<gpui_gpu::renderer::RendererState>::render+0x1d8b>
  81fe8a:	sub    (%r8,%rcx,8),%r10d
  81fe8e:	je     81fe60 <<gpui_gpu::renderer::RendererState>::render+0x1d90>
  81fe90:	mov    %rcx,%rax
  81fe93:	shr    $0x20,%rax
  81fe97:	je     81fea8 <<gpui_gpu::renderer::RendererState>::render+0x1dd8>
  81fe99:	mov    %rcx,%rax
  81fe9c:	xor    %edx,%edx
  81fe9e:	divq   0x38(%rsp)
  81fea3:	mov    %r9,%rdx
  81fea6:	jmp    81feb0 <<gpui_gpu::renderer::RendererState>::render+0x1de0>
  81fea8:	mov    %ecx,%eax
  81feaa:	xor    %edx,%edx
  81feac:	divl   0x38(%rsp)
  81feb0:	shl    $0x4,%edx
  81feb3:	shl    $0x4,%eax
  81feb6:	lea    0x10(%rdx),%r11d
  81feba:	cmp    %r11d,%r14d
  81febd:	cmovb  %r14d,%r11d
  81fec1:	lea    0x10(%rax),%esi
  81fec4:	cmp    %esi,%r15d
  81fec7:	cmovb  %r15d,%esi
  81fecb:	sub    %edx,%r11d
  81fece:	sub    %eax,%esi
  81fed0:	imul   %r11d,%esi
  81fed4:	shl    $0x4,%rsi
  81fed8:	add    %rsi,0x18(%rsp)
  81fedd:	imul   %rsi,%r10
  81fee1:	add    %r10,0x30(%rsp)
  81fee6:	jmp    81fe60 <<gpui_gpu::renderer::RendererState>::render+0x1d90>
  81feeb:	movq   $0x0,0x10(%rsp)
  81fef4:	movq   $0x0,0x18(%rsp)
  81fefd:	movq   $0x0,0x30(%rsp)
  81ff06:	test   $0x1,%bpl
  81ff0a:	je     81ff5f <<gpui_gpu::renderer::RendererState>::render+0x1e8f>
  81ff0c:	movd   0x244(%rsp),%xmm0
  81ff15:	movd   %xmm0,%eax
  81ff19:	test   %eax,%eax
  81ff1b:	setns  %cl
  81ff1e:	mov    %eax,%edx
  81ff20:	and    $0x7fffffff,%edx
  81ff26:	add    $0xff800000,%edx
  81ff2c:	cmp    $0x7f000000,%edx
  81ff32:	setb   %dl
  81ff35:	and    %cl,%dl
  81ff37:	dec    %eax
  81ff39:	cmp    $0x7fffff,%eax
  81ff3e:	setb   %al
  81ff41:	or     %dl,%al
  81ff43:	mov    $0x2,%eax
  81ff48:	mov    %rax,0x98(%rsp)
  81ff50:	movd   %xmm0,0xe4(%rsp)
  81ff59:	je     82051e <<gpui_gpu::renderer::RendererState>::render+0x244e>
  81ff5f:	mov    0xe8(%rsp),%rbp
  81ff67:	lea    0x18(%rbp),%rax
  81ff6b:	mov    %rax,0x20(%rsp)
  81ff70:	mov    0x90(%rsp),%rax
  81ff78:	add    $0x18,%rax
  81ff7c:	xor    %ecx,%ecx
  81ff7e:	mov    0x3a0(%rsp),%rdx
  81ff86:	cmp    0x3a8(%rsp),%rdx
  81ff8e:	setne  %cl
  81ff91:	xor    %edx,%edx
  81ff93:	cmp    $0x28,%r13d
  81ff97:	sete   %dl
  81ff9a:	and    $0x1,%r12d
  81ff9e:	lea    (%r12,%rdx,4),%edx
  81ffa2:	lea    (%rdx,%rcx,8),%ecx
  81ffa5:	or     0x98(%rsp),%ecx
  81ffac:	movups (%rax),%xmm0
  81ffaf:	movups %xmm0,0x258(%rsp)
  81ffb7:	mov    %r14d,0x248(%rsp)
  81ffbf:	mov    %r15d,0x24c(%rsp)
  81ffc7:	mov    0x38(%rsp),%rax
  81ffcc:	mov    %eax,0x250(%rsp)
  81ffd3:	mov    %ecx,0x254(%rsp)
  81ffda:	movss  0xe4(%rsp),%xmm0
  81ffe3:	movss  %xmm0,0x268(%rsp)
  81ffec:	movq   $0x0,0x26c(%rsp)
  81fff8:	movl   $0x0,0x274(%rsp)
  820003:	mov    0x8(%rsp),%r13
  820008:	lea    0x230(%r13),%rsi
  82000f:	movq   $0x0,0x38(%rsp)
  820018:	lea    0x248(%rsp),%rcx
  820020:	mov    $0x30,%r8d
  820026:	mov    0x3c0(%rsp),%r12
  82002e:	mov    %r12,%rdi
  820031:	mov    %rsi,0x98(%rsp)
  820039:	xor    %edx,%edx
  82003b:	call   *0x65fcf7(%rip)        # e7fd38 <_DYNAMIC+0x5d0>
  820041:	mov    0x8(%r13),%rcx
  820045:	mov    0x10(%r13),%r8
  820049:	shl    $0x4,%r8
  82004d:	mov    0x2b0(%rsp),%rdi
  820055:	mov    %rbp,%rsi
  820058:	mov    %r12,%rdx
  82005b:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  820060:	lea    0x280(%r13),%rdi
  820067:	mov    0x20(%r13),%rcx
  82006b:	mov    0x28(%r13),%r8
  82006f:	shl    $0x3,%r8
  820073:	mov    %rdi,0x90(%rsp)
  82007b:	mov    %rbp,%rsi
  82007e:	mov    %r12,%rdx
  820081:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  820086:	lea    0x2a8(%r13),%rdi
  82008d:	mov    0x38(%r13),%rcx
  820091:	mov    0x40(%r13),%r8
  820095:	shl    $0x2,%r8
  820099:	mov    %rdi,0x40(%rsp)
  82009e:	mov    %rbp,%rsi
  8200a1:	mov    %r12,%rdx
  8200a4:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  8200a9:	lea    0x2d0(%r13),%rdi
  8200b0:	mov    0x68(%r13),%rcx
  8200b4:	mov    0x70(%r13),%r8
  8200b8:	shl    $0x5,%r8
  8200bc:	mov    %rdi,0x70(%rsp)
  8200c1:	mov    %rbp,%rsi
  8200c4:	mov    %r12,%rdx
  8200c7:	call   81cc10 <<gpui_gpu::renderer::Buffer>::write>
  8200cc:	cmpq   $0x0,0x328(%r13)
  8200d4:	jne    8200f0 <<gpui_gpu::renderer::RendererState>::render+0x2020>
  8200d6:	mov    0x8(%rsp),%rax
  8200db:	mov    0x10(%rax),%rax
  8200df:	cmp    $0x1,%rax
  8200e3:	adc    $0x0,%rax
  8200e7:	shl    $0x4,%rax
  8200eb:	mov    %rax,0x38(%rsp)
  8200f0:	mov    0x8(%rsp),%rsi
  8200f5:	mov    0x28(%rsi),%rdx
  8200f9:	mov    0x40(%rsi),%rax
  8200fd:	cmp    $0x1,%rdx
  820101:	adc    $0x0,%rdx
  820105:	shl    $0x3,%rdx
  820109:	cmp    $0x1,%rax
  82010d:	adc    $0x0,%rax
  820111:	mov    0x70(%rsi),%rcx
  820115:	cmp    $0x1,%rcx
  820119:	adc    $0x0,%rcx
  82011d:	add    $0xc8,%rsi
  820124:	shl    $0x2,%rax
  820128:	shl    $0x5,%rcx
  82012c:	movq   $0x0,0x120(%rsp)
  820138:	mov    0x98(%rsp),%rdi
  820140:	mov    %rdi,0x128(%rsp)
  820148:	movq   $0x0,0x148(%rsp)
  820154:	xorps  %xmm0,%xmm0
  820157:	movups %xmm0,0x130(%rsp)
  82015f:	movl   $0x0,0x140(%rsp)
  82016a:	mov    0x2b0(%rsp),%rdi
  820172:	mov    %rdi,0x150(%rsp)
  82017a:	movq   $0x0,0x158(%rsp)
  820186:	mov    0x38(%rsp),%rdi
  82018b:	mov    %rdi,0x160(%rsp)
  820193:	movl   $0x1,0x168(%rsp)
  82019e:	movq   $0x0,0x170(%rsp)
  8201aa:	mov    0x90(%rsp),%rdi
  8201b2:	mov    %rdi,0x178(%rsp)
  8201ba:	movq   $0x0,0x180(%rsp)
  8201c6:	mov    %rdx,0x188(%rsp)
  8201ce:	movl   $0x2,0x190(%rsp)
  8201d9:	movq   $0x0,0x198(%rsp)
  8201e5:	mov    0x40(%rsp),%rdx
  8201ea:	mov    %rdx,0x1a0(%rsp)
  8201f2:	movq   $0x0,0x1a8(%rsp)
  8201fe:	mov    %rax,0x1b0(%rsp)
  820206:	movl   $0x3,0x1b8(%rsp)
  820211:	movq   $0x4,0x1c0(%rsp)
  82021d:	mov    %rsi,0x1c8(%rsp)
  820225:	movl   $0x4,0x1e0(%rsp)
  820230:	movq   $0x0,0x1e8(%rsp)
  82023c:	mov    0x70(%rsp),%rax
  820241:	mov    %rax,0x1f0(%rsp)
  820249:	movq   $0x0,0x1f8(%rsp)
  820255:	mov    %rcx,0x200(%rsp)
  82025d:	movl   $0x5,0x208(%rsp)
  820268:	lea    -0x74b3a7(%rip),%rax        # d4ec8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  82026f:	mov    %rax,0x348(%rsp)
  820277:	movq   $0xa,0x350(%rsp)
  820283:	mov    0x20(%rsp),%rax
  820288:	mov    %rax,0x330(%rsp)
  820290:	lea    0x120(%rsp),%rax
  820298:	mov    %rax,0x338(%rsp)
  8202a0:	movq   $0x6,0x340(%rsp)
  8202ac:	lea    0x330(%rsp),%rsi
  8202b4:	mov    0xe8(%rsp),%r12
  8202bc:	mov    %r12,%rdi
  8202bf:	call   *0x65fa7b(%rip)        # e7fd40 <_DYNAMIC+0x5d8>
  8202c5:	mov    %rax,%r13
  8202c8:	mov    %rax,0x300(%rsp)
  8202d0:	lea    0x300(%rsp),%rdx
  8202d8:	mov    %r12,%rdi
  8202db:	mov    0x3f0(%rsp),%rsi
  8202e3:	call   81d270 <<gpui_gpu::renderer::GpuContext>::submit>
  8202e8:	mov    %rax,0x38(%rsp)
  8202ed:	xor    %ebp,%ebp
  8202ef:	mov    0x3a0(%rsp),%rax
  8202f7:	cmp    0x3a8(%rsp),%rax
  8202ff:	setne  %bpl
  820303:	shl    $0x1f,%ebp
  820306:	or     %r14d,%ebp
  820309:	shl    $0x20,%r15
  82030d:	or     %r15,%rbp
  820310:	mov    (%rbx),%rax
  820313:	test   %rax,%rax
  820316:	je     820327 <<gpui_gpu::renderer::RendererState>::render+0x2257>
  820318:	lock decq (%rax)
  82031c:	jne    820327 <<gpui_gpu::renderer::RendererState>::render+0x2257>
  82031e:	mov    %rbx,%rdi
  820321:	call   *0x65f959(%rip)        # e7fc80 <_DYNAMIC+0x518>
  820327:	mov    0x8(%rsp),%rax
  82032c:	mov    %r13,0x330(%rax)
  820333:	mov    %rbp,0x338(%rax)
  82033a:	mov    0x10(%rax),%r8
  82033e:	mov    0x28(%rax),%rsi
  820342:	mov    0x70(%rax),%rcx
  820346:	mov    %rcx,0x98(%rsp)
  82034e:	shl    $0x4,%r8
  820352:	mov    0x60(%rsp),%rdx
  820357:	lea    (%r8,%rdx,4),%rdi
  82035b:	lea    (%rdi,%rsi,8),%rsi
  82035f:	mov    %rcx,%rdi
  820362:	shl    $0x5,%rdi
  820366:	lea    (%rdi,%rsi,1),%rcx
  82036a:	add    $0x30,%rcx
  82036e:	mov    %rcx,0x90(%rsp)
  820376:	mov    0x278(%rax),%rdi
  82037d:	add    0x250(%rax),%rdi
  820384:	add    0x2a0(%rax),%rdi
  82038b:	add    0x2c8(%rax),%rdi
  820392:	add    0x2f0(%rax),%rdi
  820399:	mov    0x308(%rax),%rsi
  8203a0:	add    0x310(%rax),%rsi
  8203a7:	mov    0x150(%rax),%r9d
  8203ae:	imul   %r9,%r9
  8203b2:	mov    0xd0(%rsp),%r11
  8203ba:	mov    %r11,%rcx
  8203bd:	sub    %rdx,%rcx
  8203c0:	mov    0x58(%rsp),%r10
  8203c5:	mov    %r10,%r12
  8203c8:	mov    0x230(%rsp),%rbp
  8203d0:	sub    %rbp,%r12
  8203d3:	mov    0x160(%rax),%rbx
  8203da:	inc    %rbx
  8203dd:	mov    $0xffffffffffffffff,%r14
  8203e4:	cmovne %rbx,%r14
  8203e8:	mov    (%rax),%rbx
  8203eb:	shl    $0x4,%rbx
  8203ef:	mov    0x48(%rax),%r15
  8203f3:	add    0x30(%rax),%r15
  8203f7:	mov    0x18(%rax),%r13
  8203fb:	lea    (%rbx,%r13,8),%rbx
  8203ff:	lea    (%rbx,%r15,4),%rbx
  820403:	mov    0x60(%rax),%r15
  820407:	shl    $0x5,%r15
  82040b:	add    %rbx,%r15
  82040e:	mov    0x138(%rax),%rbx
  820415:	mov    0x130(%rax),%r13
  82041c:	mov    %r14,0x160(%rax)
  820423:	mov    %r10,0x168(%rax)
  82042a:	lea    (%r11,%r11,1),%r14
  82042e:	mov    %r14,0x170(%rax)
  820435:	movq   $0x1,0x178(%rax)
  820440:	mov    %r10,0x180(%rax)
  820447:	mov    %rdx,0x188(%rax)
  82044e:	mov    %r11,0x190(%rax)
  820455:	mov    %rcx,0x198(%rax)
  82045c:	mov    0x10(%rsp),%rcx
  820461:	mov    %rcx,0x1a0(%rax)
  820468:	mov    0x18(%rsp),%rcx
  82046d:	mov    %rcx,0x1a8(%rax)
  820474:	mov    0x30(%rsp),%rcx
  820479:	mov    %rcx,0x1b0(%rax)
  820480:	mov    0x90(%rsp),%rcx
  820488:	mov    %rcx,0x1b8(%rax)
  82048f:	mov    %r8,0x1c0(%rax)
  820496:	mov    0x228(%rsp),%rdx
  82049e:	mov    %rdx,0x1c8(%rax)
  8204a5:	mov    %rbp,0x1d0(%rax)
  8204ac:	mov    %r12,0x1d8(%rax)
  8204b3:	mov    0x3b0(%rsp),%rcx
  8204bb:	mov    %rcx,0x1e0(%rax)
  8204c2:	mov    %rdi,0x1e8(%rax)
  8204c9:	mov    %r9,0x1f0(%rax)
  8204d0:	add    %rbx,%r13
  8204d3:	mov    %rbx,0x1f8(%rax)
  8204da:	mov    %r13,0x200(%rax)
  8204e1:	mov    %r15,0x208(%rax)
  8204e8:	mov    0x98(%rsp),%rcx
  8204f0:	mov    %rcx,0x210(%rax)
  8204f7:	mov    %rsi,0x218(%rax)
  8204fe:	movb   $0x0,0x220(%rax)
  820505:	mov    0x50(%rsp),%rdi
  82050a:	mov    0x38(%rsp),%rax
  82050f:	mov    %rax,0x8(%rdi)
  820513:	movl   $0xffffffff,(%rdi)
  820519:	jmp    81e1e0 <<gpui_gpu::renderer::RendererState>::render+0x110>
  82051e:	mov    0x50(%rsp),%rdi
  820523:	jmp    81e1d2 <<gpui_gpu::renderer::RendererState>::render+0x102>
  820528:	movq   $0x0,0x18(%rsp)
  820531:	xor    %eax,%eax
  820533:	movq   $0x0,0x10(%rsp)
  82053c:	jmp    820550 <<gpui_gpu::renderer::RendererState>::render+0x2480>
  82053e:	incq   0x10(%rsp)
  820543:	add    $0x8,%rax
  820547:	cmp    %rax,%rdi
  82054a:	je     81fefd <<gpui_gpu::renderer::RendererState>::render+0x1e2d>
  820550:	mov    0x4(%r8,%rax,1),%ecx
  820555:	mov    %ecx,%edx
  820557:	neg    %edx
  820559:	jo     82053e <<gpui_gpu::renderer::RendererState>::render+0x246e>
  82055b:	cmp    %ecx,(%r8,%rax,1)
  82055f:	je     820543 <<gpui_gpu::renderer::RendererState>::render+0x2473>
  820561:	lea    0x60de80(%rip),%rdi        # e2e3e8 <anon.e7af5e0dba0d7261d22cb76253955a85.29.llvm.10167252663607395722+0x10>
  820568:	call   *0x65f7da(%rip)        # e7fd48 <_DYNAMIC+0x5e0>
  82056e:	lea    0x60dcdb(%rip),%rdi        # e2e250 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  820575:	call   *0x65f7d5(%rip)        # e7fd50 <_DYNAMIC+0x5e8>
  82057b:	lea    0x60dce6(%rip),%rdx        # e2e268 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  820582:	call   *0x65f6d8(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  820588:	lea    0x60dca9(%rip),%rdx        # e2e238 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  82058f:	call   *0x65f6cb(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  820595:	mov    %rax,%r14
  820598:	mov    0x8(%rsp),%rax
  82059d:	mov    %r13,0x330(%rax)
  8205a4:	mov    %rbp,0x338(%rax)
  8205ab:	mov    %r14,%rdi
  8205ae:	call   e2c520 <_Unwind_Resume@plt>
  8205b3:	mov    %rax,%r14
  8205b6:	lock decq 0x0(%r13)
  8205bb:	jne    8205dd <<gpui_gpu::renderer::RendererState>::render+0x250d>
  8205bd:	lea    0x300(%rsp),%rdi
  8205c5:	call   *0x65f6b5(%rip)        # e7fc80 <_DYNAMIC+0x518>
  8205cb:	jmp    8205dd <<gpui_gpu::renderer::RendererState>::render+0x250d>
  8205cd:	call   *0x65f3e5(%rip)        # e7f9b8 <_DYNAMIC+0x250>
  8205d3:	mov    %rax,%r14
  8205d6:	movq   $0x0,(%rbx)
  8205dd:	mov    %r14,%rdi
  8205e0:	call   e2c520 <_Unwind_Resume@plt>
