from pathlib import Path
import hashlib,json,os,re,shutil,subprocess


def capture(root,out,env,label):
    out.mkdir()
    source=root/'reactivity/crates/gpu/tests/render.rs';original=source.read_bytes()
    private=root/'reactivity/crates/gpu/src/renderer/owned.rs';private_original=private.read_bytes()
    cursor=b'self.state.cursors.capacity() * 4' if label == 'baseline' else b'0'
    private_hook=(b'\nimpl Renderer { pub fn qualification_capacities(&self) -> [usize; 5] { [self.state.records.capacity() * 16, self.state.ranges.capacity() * 8, self.state.references.capacity() * 4, '+cursor+b', self.state.residuals.capacity() * 32] } }\n')
    needle=b'    buffer.unmap();\n    output\n';assert original.count(needle)==1
    hook=b'''    // Nonshipping readback observer: source restored by the guarded runner.
    if let Some(directory) = std::env::var_os("GPUI_NAMED_PIXEL_CAPTURE") {
        static NEXT: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(0);
        let index = NEXT.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
        let thread = std::thread::current();
        let name = thread.name().expect("named test thread");
        let directory = std::path::PathBuf::from(directory);
        std::fs::create_dir_all(&directory).unwrap();
        std::fs::write(directory.join(format!("{index:04}-{name}-{width}x{height}-{:?}.bin", renderer.format())), &output).unwrap();
        std::fs::write(directory.join(format!("{index:04}-{name}-{width}x{height}-{:?}.stats", renderer.format())), format!("{:?}\n{:?}\n", renderer.stats(), renderer.image_stats())).unwrap();
        std::fs::write(directory.join(format!("{index:04}-{name}-{width}x{height}-{:?}.cursor", renderer.format())), format!("{:?}", renderer.qualification_capacities())).unwrap();
        std::fs::write(directory.join("layout.json"), format!("{{\\"Renderer\\":{},\\"RendererState\\":{},\\"Stats\\":{}}}\\n", std::mem::size_of::<Renderer>(), std::mem::size_of::<gpui_gpu::RendererState>(), std::mem::size_of::<Stats>())).unwrap();
    }
'''
    probe=(Path('/tmp/gpui-packed-csr-evidence/max-count-probe.rs')).read_bytes()
    observed=original.replace(needle,b'    buffer.unmap();\n'+hook+b'    output\n')+probe
    local=dict(env);local['GPUI_NAMED_PIXEL_CAPTURE']=str(out/'pixels')
    local['CARGO_TARGET_DIR']='/tmp/gpui-packed-csr-target'
    result={'label':label,'original_test_source_sha256':hashlib.sha256(original).hexdigest(),
            'observer_test_source_sha256':hashlib.sha256(observed).hexdigest(),
            'selection':'all47 exact same integration tests plus identical nonshipping1x1 maximum-count probe in both source lanes',
            'max_count_probe_sha256':hashlib.sha256(probe).hexdigest(),
            'original_private_source_sha256':hashlib.sha256(private_original).hexdigest(),
            'observer_private_source_sha256':hashlib.sha256(private_original+private_hook).hexdigest()}
    try:
        private.write_bytes(private_original+private_hook)
        source.write_bytes(observed)
        args=['cargo','test','--release','--offline','--locked','-p','gpui_gpu','--test','render','--features','vulkan-tests','--no-run','--message-format=json']
        with (out/'cargo.jsonl').open('w') as stdout,(out/'cargo.log').open('w') as stderr:
            subprocess.run(args,cwd=root/'reactivity',env=local,stdout=stdout,stderr=stderr,check=True)
        artifacts=[json.loads(line) for line in (out/'cargo.jsonl').read_text().splitlines() if line.startswith('{')]
        artifact=next(a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='render')
        assert not artifact['fresh'] and artifact['profile']['opt_level']=='3'
        executable=out/'render-tests';shutil.copy2(artifact['executable'],executable);executable.chmod(0o555)
        result.update(artifact=artifact,binary_sha256=hashlib.sha256(executable.read_bytes()).hexdigest())
        args=[str(executable),'--test-threads=1','--nocapture']
        with (out/'stdout.log').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
            p=subprocess.run(args,cwd=root/'reactivity',env=local,stdout=stdout,stderr=stderr,timeout=180)
        result.update(args=args,returncode=p.returncode);assert p.returncode==0
        files={};counts={};diagnostics={};capacities={}
        for path in sorted((out/'pixels').glob('*.bin')):
            m=re.fullmatch(r'\d+-(.+)-(\d+x\d+)-(Rgba\w+)\.bin',path.name);assert m,path.name
            test,dimensions,format=m.groups();ordinal=counts.get(test,0);counts[test]=ordinal+1
            key=f'{test}/{ordinal}/{dimensions}/{format}'
            files[key]={'path':str(path),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
            diagnostic=path.with_suffix('.stats')
            diagnostics[key]={'path':str(diagnostic),'sha256':hashlib.sha256(diagnostic.read_bytes()).hexdigest()}
            cursor=path.with_suffix('.cursor')
            capacities[key]={'path':str(cursor),'components':json.loads(cursor.read_text())}
        result.update(files=files,diagnostics=diagnostics,per_test_counts=counts,current_scratch_capacities=capacities,
                      object_layout=json.loads((out/'pixels/layout.json').read_text()))
    finally:
        source.write_bytes(original);assert source.read_bytes()==original
        private.write_bytes(private_original);assert private.read_bytes()==private_original
        result['exact_test_source_restored']=True
        (out/'manifest.json').write_text(json.dumps(result,indent=2)+'\n')
    print(f'{label}: {len(files)} named raw readbacks preserved',flush=True)
