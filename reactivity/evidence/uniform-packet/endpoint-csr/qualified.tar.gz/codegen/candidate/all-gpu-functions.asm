
FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816670 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  816670:	push   %rbx
  816671:	test   %rdi,%rdi
  816674:	je     8166d7 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  816676:	mov    %rdi,%rbx
  816679:	mov    (%rdi),%rsi
  81667c:	test   %rsi,%rsi
  81667f:	je     816694 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  816681:	mov    0x8(%rbx),%rdi
  816685:	shl    $0x3,%rsi
  816689:	mov    $0x8,%edx
  81668e:	call   *0x6691ec(%rip)        # e7f880 <_DYNAMIC+0x248>
  816694:	mov    0x20(%rbx),%rsi
  816698:	test   %rsi,%rsi
  81669b:	je     8166c3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  81669d:	mov    %rsi,%rax
  8166a0:	shl    $0x4,%rax
  8166a4:	add    %rax,%rsi
  8166a7:	add    $0x21,%rsi
  8166ab:	je     8166c3 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8166ad:	mov    0x18(%rbx),%rdi
  8166b1:	sub    %rax,%rdi
  8166b4:	add    $0xfffffffffffffff0,%rdi
  8166b8:	mov    $0x10,%edx
  8166bd:	call   *0x6691bd(%rip)        # e7f880 <_DYNAMIC+0x248>
  8166c3:	mov    $0x80,%esi
  8166c8:	mov    $0x8,%edx
  8166cd:	mov    %rbx,%rdi
  8166d0:	pop    %rbx
  8166d1:	jmp    *0x6691a9(%rip)        # e7f880 <_DYNAMIC+0x248>
  8166d7:	pop    %rbx
  8166d8:	ret

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}> bytes=71 frame=8

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816ce0 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>>:
  816ce0:	push   %rbx
  816ce1:	cmpb   $0x3,0x19c(%rdi)
  816ce8:	jne    816d17 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816cea:	movzbl 0x28(%rdi),%eax
  816cee:	cmp    $0x4,%eax
  816cf1:	je     816d05 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x25>
  816cf3:	cmp    $0x3,%eax
  816cf6:	jne    816d17 <core::ptr::drop_glue::<<gpui_gpu::renderer::Renderer>::request::{closure#0}>+0x37>
  816cf8:	add    $0x168,%rdi
  816cff:	pop    %rbx
  816d00:	jmp    816c50 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816d05:	mov    %rdi,%rbx
  816d08:	add    $0x30,%rdi
  816d0c:	call   816d30 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816d11:	movw   $0x0,0x29(%rbx)
  816d17:	pop    %rbx
  816d18:	ret
  816d19:	movw   $0x0,0x29(%rbx)
  816d1f:	mov    %rax,%rdi
  816d22:	call   e2c420 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}> bytes=540 frame=40

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816d30 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>:
  816d30:	push   %r15
  816d32:	push   %r14
  816d34:	push   %r12
  816d36:	push   %rbx
  816d37:	push   %rax
  816d38:	mov    %rdi,%rbx
  816d3b:	movzbl 0x9e(%rdi),%eax
  816d42:	test   %eax,%eax
  816d44:	je     816e0b <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xdb>
  816d4a:	cmp    $0x3,%eax
  816d4d:	jne    816e41 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816d53:	mov    0x20(%rbx),%r15
  816d57:	mov    0x28(%rbx),%r12
  816d5b:	mov    (%r12),%rax
  816d5f:	test   %rax,%rax
  816d62:	je     816d69 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x39>
  816d64:	mov    %r15,%rdi
  816d67:	call   *%rax
  816d69:	mov    0x8(%r12),%rsi
  816d6e:	test   %rsi,%rsi
  816d71:	je     816d81 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x51>
  816d73:	mov    0x10(%r12),%rdx
  816d78:	mov    %r15,%rdi
  816d7b:	call   *0x668aff(%rip)        # e7f880 <_DYNAMIC+0x248>
  816d81:	mov    0x68(%rbx),%rax
  816d85:	lock decq (%rax)
  816d89:	jne    816d95 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x65>
  816d8b:	lea    0x68(%rbx),%rdi
  816d8f:	call   *0x668d0b(%rip)        # e7faa0 <_DYNAMIC+0x468>
  816d95:	movb   $0x0,0x98(%rbx)
  816d9c:	mov    0x60(%rbx),%rax
  816da0:	lock decq (%rax)
  816da4:	jne    816daf <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x7f>
  816da6:	lea    0x60(%rbx),%rdi
  816daa:	call   812eb0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816daf:	movw   $0x0,0x99(%rbx)
  816db8:	mov    0x40(%rbx),%rax
  816dbc:	lock decq (%rax)
  816dc0:	jne    816dcc <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x9c>
  816dc2:	lea    0x40(%rbx),%rdi
  816dc6:	call   *0x668cdc(%rip)        # e7faa8 <_DYNAMIC+0x470>
  816dcc:	movb   $0x0,0x9b(%rbx)
  816dd3:	mov    0x38(%rbx),%rax
  816dd7:	lock decq (%rax)
  816ddb:	jne    816de7 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xb7>
  816ddd:	lea    0x38(%rbx),%rdi
  816de1:	call   *0x668cc9(%rip)        # e7fab0 <_DYNAMIC+0x478>
  816de7:	movb   $0x0,0x9c(%rbx)
  816dee:	mov    0x30(%rbx),%rax
  816df2:	lock decq (%rax)
  816df6:	jne    816e02 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xd2>
  816df8:	lea    0x30(%rbx),%rdi
  816dfc:	call   *0x668cb6(%rip)        # e7fab8 <_DYNAMIC+0x480>
  816e02:	movb   $0x0,0x9d(%rbx)
  816e09:	jmp    816e41 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816e0b:	mov    0x70(%rbx),%rax
  816e0f:	lock decq (%rax)
  816e13:	jne    816e1f <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0xef>
  816e15:	lea    0x70(%rbx),%rdi
  816e19:	call   *0x668c99(%rip)        # e7fab8 <_DYNAMIC+0x480>
  816e1f:	mov    0x78(%rbx),%rax
  816e23:	lock decq (%rax)
  816e27:	jne    816e41 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x111>
  816e29:	add    $0x78,%rbx
  816e2d:	mov    %rbx,%rdi
  816e30:	add    $0x8,%rsp
  816e34:	pop    %rbx
  816e35:	pop    %r12
  816e37:	pop    %r14
  816e39:	pop    %r15
  816e3b:	jmp    *0x668c6f(%rip)        # e7fab0 <_DYNAMIC+0x478>
  816e41:	add    $0x8,%rsp
  816e45:	pop    %rbx
  816e46:	pop    %r12
  816e48:	pop    %r14
  816e4a:	pop    %r15
  816e4c:	ret
  816e4d:	mov    %rax,%r14
  816e50:	movb   $0x0,0x9d(%rbx)
  816e57:	mov    %r14,%rdi
  816e5a:	call   e2c420 <_Unwind_Resume@plt>
  816e5f:	mov    %rax,%r14
  816e62:	jmp    816f1c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816e67:	mov    %rax,%r14
  816e6a:	jmp    816f01 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816e6f:	mov    %rax,%r14
  816e72:	jmp    816ee4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816e74:	mov    %rax,%r14
  816e77:	jmp    816eca <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816e79:	mov    %rax,%r14
  816e7c:	mov    0x78(%rbx),%rax
  816e80:	lock decq (%rax)
  816e84:	jne    816e93 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x163>
  816e86:	add    $0x78,%rbx
  816e8a:	mov    %rbx,%rdi
  816e8d:	call   *0x668c1d(%rip)        # e7fab0 <_DYNAMIC+0x478>
  816e93:	mov    %r14,%rdi
  816e96:	call   e2c420 <_Unwind_Resume@plt>
  816e9b:	mov    %rax,%r14
  816e9e:	mov    0x8(%r12),%rsi
  816ea3:	test   %rsi,%rsi
  816ea6:	je     816eb6 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x186>
  816ea8:	mov    0x10(%r12),%rdx
  816ead:	mov    %r15,%rdi
  816eb0:	call   *0x6689ca(%rip)        # e7f880 <_DYNAMIC+0x248>
  816eb6:	mov    0x68(%rbx),%rax
  816eba:	lock decq (%rax)
  816ebe:	jne    816eca <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x19a>
  816ec0:	lea    0x68(%rbx),%rdi
  816ec4:	call   *0x668bd6(%rip)        # e7faa0 <_DYNAMIC+0x468>
  816eca:	movb   $0x0,0x98(%rbx)
  816ed1:	mov    0x60(%rbx),%rax
  816ed5:	lock decq (%rax)
  816ed9:	jne    816ee4 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1b4>
  816edb:	lea    0x60(%rbx),%rdi
  816edf:	call   812eb0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  816ee4:	movw   $0x0,0x99(%rbx)
  816eed:	mov    0x40(%rbx),%rax
  816ef1:	lock decq (%rax)
  816ef5:	jne    816f01 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1d1>
  816ef7:	lea    0x40(%rbx),%rdi
  816efb:	call   *0x668ba7(%rip)        # e7faa8 <_DYNAMIC+0x470>
  816f01:	movb   $0x0,0x9b(%rbx)
  816f08:	mov    0x38(%rbx),%rax
  816f0c:	lock decq (%rax)
  816f10:	jne    816f1c <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x1ec>
  816f12:	lea    0x38(%rbx),%rdi
  816f16:	call   *0x668b94(%rip)        # e7fab0 <_DYNAMIC+0x478>
  816f1c:	movb   $0x0,0x9c(%rbx)
  816f23:	mov    0x30(%rbx),%rax
  816f27:	lock decq (%rax)
  816f2b:	jne    816f37 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>+0x207>
  816f2d:	lea    0x30(%rbx),%rdi
  816f31:	call   *0x668b81(%rip)        # e7fab8 <_DYNAMIC+0x480>
  816f37:	movb   $0x0,0x9d(%rbx)
  816f3e:	mov    %r14,%rdi
  816f41:	call   e2c420 <_Unwind_Resume@plt>
  816f46:	call   *0x66893c(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}> bytes=64 frame=8

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000816f50 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>>:
  816f50:	push   %rbx
  816f51:	movzbl 0x20(%rdi),%eax
  816f55:	cmp    $0x3,%eax
  816f58:	je     816f73 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x23>
  816f5a:	cmp    $0x4,%eax
  816f5d:	jne    816f80 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::request::{closure#0}>+0x30>
  816f5f:	mov    %rdi,%rbx
  816f62:	add    $0x28,%rdi
  816f66:	call   816d30 <core::ptr::drop_glue::<<gpui_gpu::renderer::GpuContext>::new::{closure#0}>>
  816f6b:	movw   $0x0,0x21(%rbx)
  816f71:	pop    %rbx
  816f72:	ret
  816f73:	add    $0x160,%rdi
  816f7a:	pop    %rbx
  816f7b:	jmp    816c50 <core::ptr::drop_glue::<<wgpu::api::adapter::Adapter>::request_device::{closure#0}>>
  816f80:	pop    %rbx
  816f81:	ret
  816f82:	movw   $0x0,0x21(%rbx)
  816f88:	mov    %rax,%rdi
  816f8b:	call   e2c420 <_Unwind_Resume@plt>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext> bytes=191 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817470 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>>:
  817470:	push   %r14
  817472:	push   %rbx
  817473:	push   %rax
  817474:	mov    %rdi,%rbx
  817477:	mov    (%rdi),%rax
  81747a:	lock decq (%rax)
  81747e:	jne    817489 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x19>
  817480:	mov    %rbx,%rdi
  817483:	call   *0x66862f(%rip)        # e7fab8 <_DYNAMIC+0x480>
  817489:	mov    0x8(%rbx),%rax
  81748d:	lock decq (%rax)
  817491:	jne    81749d <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x2d>
  817493:	lea    0x8(%rbx),%rdi
  817497:	call   *0x668613(%rip)        # e7fab0 <_DYNAMIC+0x478>
  81749d:	mov    0x10(%rbx),%rax
  8174a1:	lock decq (%rax)
  8174a5:	jne    8174b0 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x40>
  8174a7:	lea    0x10(%rbx),%rdi
  8174ab:	call   812eb0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  8174b0:	mov    0x18(%rbx),%rax
  8174b4:	lock decq (%rax)
  8174b8:	jne    8174ce <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x5e>
  8174ba:	add    $0x18,%rbx
  8174be:	mov    %rbx,%rdi
  8174c1:	add    $0x8,%rsp
  8174c5:	pop    %rbx
  8174c6:	pop    %r14
  8174c8:	jmp    *0x6685d2(%rip)        # e7faa0 <_DYNAMIC+0x468>
  8174ce:	add    $0x8,%rsp
  8174d2:	pop    %rbx
  8174d3:	pop    %r14
  8174d5:	ret
  8174d6:	mov    %rax,%r14
  8174d9:	jmp    81750a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  8174db:	mov    %rax,%r14
  8174de:	jmp    8174f7 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8174e0:	mov    %rax,%r14
  8174e3:	mov    0x8(%rbx),%rax
  8174e7:	lock decq (%rax)
  8174eb:	jne    8174f7 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x87>
  8174ed:	lea    0x8(%rbx),%rdi
  8174f1:	call   *0x6685b9(%rip)        # e7fab0 <_DYNAMIC+0x478>
  8174f7:	mov    0x10(%rbx),%rax
  8174fb:	lock decq (%rax)
  8174ff:	jne    81750a <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0x9a>
  817501:	lea    0x10(%rbx),%rdi
  817505:	call   812eb0 <<alloc::sync::Arc<wgpu::backend::wgpu_core::CoreRenderPipeline>>::drop_slow>
  81750a:	mov    0x18(%rbx),%rax
  81750e:	lock decq (%rax)
  817512:	jne    817521 <core::ptr::drop_glue::<gpui_gpu::renderer::GpuContext>+0xb1>
  817514:	add    $0x18,%rbx
  817518:	mov    %rbx,%rdi
  81751b:	call   *0x66857f(%rip)        # e7faa0 <_DYNAMIC+0x468>
  817521:	mov    %r14,%rdi
  817524:	call   e2c420 <_Unwind_Resume@plt>
  817529:	call   *0x668359(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::RendererState> bytes=1172 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817530 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>>:
  817530:	push   %r14
  817532:	push   %rbx
  817533:	push   %rax
  817534:	mov    %rdi,%rbx
  817537:	mov    0x210(%rdi),%rax
  81753e:	lock decq (%rax)
  817542:	jne    817551 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x21>
  817544:	lea    0x210(%rbx),%rdi
  81754b:	call   *0x66854f(%rip)        # e7faa0 <_DYNAMIC+0x468>
  817551:	mov    0x218(%rbx),%rax
  817558:	lock decq (%rax)
  81755c:	jne    81756b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3b>
  81755e:	lea    0x218(%rbx),%rdi
  817565:	call   *0x6685d5(%rip)        # e7fb40 <_DYNAMIC+0x508>
  81756b:	mov    0x220(%rbx),%rax
  817572:	lock decq (%rax)
  817576:	jne    817585 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x55>
  817578:	lea    0x220(%rbx),%rdi
  81757f:	call   *0x6685c3(%rip)        # e7fb48 <_DYNAMIC+0x510>
  817585:	mov    0x240(%rbx),%rax
  81758c:	lock decq (%rax)
  817590:	jne    81759f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x6f>
  817592:	lea    0x240(%rbx),%rdi
  817599:	call   *0x6685a1(%rip)        # e7fb40 <_DYNAMIC+0x508>
  81759f:	mov    0x248(%rbx),%rax
  8175a6:	lock decq (%rax)
  8175aa:	jne    8175b9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x89>
  8175ac:	lea    0x248(%rbx),%rdi
  8175b3:	call   *0x66858f(%rip)        # e7fb48 <_DYNAMIC+0x510>
  8175b9:	mov    0x268(%rbx),%rax
  8175c0:	lock decq (%rax)
  8175c4:	jne    8175d3 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xa3>
  8175c6:	lea    0x268(%rbx),%rdi
  8175cd:	call   *0x66856d(%rip)        # e7fb40 <_DYNAMIC+0x508>
  8175d3:	mov    0x270(%rbx),%rax
  8175da:	lock decq (%rax)
  8175de:	jne    8175ed <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xbd>
  8175e0:	lea    0x270(%rbx),%rdi
  8175e7:	call   *0x66855b(%rip)        # e7fb48 <_DYNAMIC+0x510>
  8175ed:	mov    0x290(%rbx),%rax
  8175f4:	lock decq (%rax)
  8175f8:	jne    817607 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xd7>
  8175fa:	lea    0x290(%rbx),%rdi
  817601:	call   *0x668539(%rip)        # e7fb40 <_DYNAMIC+0x508>
  817607:	mov    0x298(%rbx),%rax
  81760e:	lock decq (%rax)
  817612:	jne    817621 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0xf1>
  817614:	lea    0x298(%rbx),%rdi
  81761b:	call   *0x668527(%rip)        # e7fb48 <_DYNAMIC+0x510>
  817621:	mov    0x2b8(%rbx),%rax
  817628:	lock decq (%rax)
  81762c:	jne    81763b <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x10b>
  81762e:	lea    0x2b8(%rbx),%rdi
  817635:	call   *0x668505(%rip)        # e7fb40 <_DYNAMIC+0x508>
  81763b:	mov    0x2c0(%rbx),%rax
  817642:	lock decq (%rax)
  817646:	jne    817655 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x125>
  817648:	lea    0x2c0(%rbx),%rdi
  81764f:	call   *0x6684f3(%rip)        # e7fb48 <_DYNAMIC+0x510>
  817655:	lea    0x60(%rbx),%rdi
  817659:	call   8179d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81765e:	mov    0x310(%rbx),%r14
  817665:	test   %r14,%r14
  817668:	je     8176c7 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x197>
  81766a:	mov    (%r14),%rsi
  81766d:	test   %rsi,%rsi
  817670:	je     817685 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x155>
  817672:	mov    0x8(%r14),%rdi
  817676:	shl    $0x3,%rsi
  81767a:	mov    $0x8,%edx
  81767f:	call   *0x6681fb(%rip)        # e7f880 <_DYNAMIC+0x248>
  817685:	mov    0x20(%r14),%rsi
  817689:	test   %rsi,%rsi
  81768c:	je     8176b4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81768e:	mov    %rsi,%rax
  817691:	shl    $0x4,%rax
  817695:	add    %rax,%rsi
  817698:	add    $0x21,%rsi
  81769c:	je     8176b4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x184>
  81769e:	mov    0x18(%r14),%rdi
  8176a2:	sub    %rax,%rdi
  8176a5:	add    $0xfffffffffffffff0,%rdi
  8176a9:	mov    $0x10,%edx
  8176ae:	call   *0x6681cc(%rip)        # e7f880 <_DYNAMIC+0x248>
  8176b4:	mov    $0x80,%esi
  8176b9:	mov    $0x8,%edx
  8176be:	mov    %r14,%rdi
  8176c1:	call   *0x6681b9(%rip)        # e7f880 <_DYNAMIC+0x248>
  8176c7:	mov    (%rbx),%rsi
  8176ca:	test   %rsi,%rsi
  8176cd:	je     8176e2 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1b2>
  8176cf:	mov    0x8(%rbx),%rdi
  8176d3:	shl    $0x4,%rsi
  8176d7:	mov    $0x4,%edx
  8176dc:	call   *0x66819e(%rip)        # e7f880 <_DYNAMIC+0x248>
  8176e2:	mov    0x18(%rbx),%rsi
  8176e6:	test   %rsi,%rsi
  8176e9:	je     8176fe <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ce>
  8176eb:	mov    0x20(%rbx),%rdi
  8176ef:	shl    $0x3,%rsi
  8176f3:	mov    $0x4,%edx
  8176f8:	call   *0x668182(%rip)        # e7f880 <_DYNAMIC+0x248>
  8176fe:	mov    0x30(%rbx),%rsi
  817702:	test   %rsi,%rsi
  817705:	je     81771a <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x1ea>
  817707:	mov    0x38(%rbx),%rdi
  81770b:	shl    $0x2,%rsi
  81770f:	mov    $0x4,%edx
  817714:	call   *0x668166(%rip)        # e7f880 <_DYNAMIC+0x248>
  81771a:	mov    0x48(%rbx),%rsi
  81771e:	test   %rsi,%rsi
  817721:	je     817736 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x206>
  817723:	mov    0x50(%rbx),%rdi
  817727:	shl    $0x5,%rsi
  81772b:	mov    $0x4,%edx
  817730:	call   *0x66814a(%rip)        # e7f880 <_DYNAMIC+0x248>
  817736:	mov    0x2e8(%rbx),%rsi
  81773d:	test   %rsi,%rsi
  817740:	je     817770 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x240>
  817742:	lea    (%rsi,%rsi,8),%rax
  817746:	lea    0x33(,%rax,4),%rax
  81774e:	and    $0xfffffffffffffff0,%rax
  817752:	add    %rax,%rsi
  817755:	add    $0x11,%rsi
  817759:	je     817770 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x240>
  81775b:	mov    0x2e0(%rbx),%rdi
  817762:	sub    %rax,%rdi
  817765:	mov    $0x10,%edx
  81776a:	call   *0x668110(%rip)        # e7f880 <_DYNAMIC+0x248>
  817770:	mov    0x318(%rbx),%rax
  817777:	test   %rax,%rax
  81777a:	je     817799 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x269>
  81777c:	lock decq (%rax)
  817780:	jne    817799 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x269>
  817782:	add    $0x318,%rbx
  817789:	mov    %rbx,%rdi
  81778c:	add    $0x8,%rsp
  817790:	pop    %rbx
  817791:	pop    %r14
  817793:	jmp    *0x6683b7(%rip)        # e7fb50 <_DYNAMIC+0x518>
  817799:	add    $0x8,%rsp
  81779d:	pop    %rbx
  81779e:	pop    %r14
  8177a0:	ret
  8177a1:	mov    %rax,%r14
  8177a4:	jmp    8178d0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  8177a9:	mov    %rax,%r14
  8177ac:	mov    0x2c0(%rbx),%rax
  8177b3:	lock decq (%rax)
  8177b7:	jne    8178d0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  8177bd:	lea    0x2c0(%rbx),%rdi
  8177c4:	call   *0x66837e(%rip)        # e7fb48 <_DYNAMIC+0x510>
  8177ca:	jmp    8178d0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a0>
  8177cf:	call   *0x6680b3(%rip)        # e7f888 <_DYNAMIC+0x250>
  8177d5:	mov    %rax,%r14
  8177d8:	jmp    8178c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  8177dd:	mov    %rax,%r14
  8177e0:	mov    0x298(%rbx),%rax
  8177e7:	lock decq (%rax)
  8177eb:	jne    8178c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  8177f1:	lea    0x298(%rbx),%rdi
  8177f8:	call   *0x66834a(%rip)        # e7fb48 <_DYNAMIC+0x510>
  8177fe:	jmp    8178c4 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x394>
  817803:	call   *0x66807f(%rip)        # e7f888 <_DYNAMIC+0x250>
  817809:	mov    %rax,%r14
  81780c:	jmp    8178b8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  817811:	mov    %rax,%r14
  817814:	mov    0x270(%rbx),%rax
  81781b:	lock decq (%rax)
  81781f:	jne    8178b8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  817825:	lea    0x270(%rbx),%rdi
  81782c:	call   *0x668316(%rip)        # e7fb48 <_DYNAMIC+0x510>
  817832:	jmp    8178b8 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x388>
  817837:	call   *0x66804b(%rip)        # e7f888 <_DYNAMIC+0x250>
  81783d:	mov    %rax,%r14
  817840:	jmp    8178ac <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  817842:	mov    %rax,%r14
  817845:	mov    0x248(%rbx),%rax
  81784c:	lock decq (%rax)
  817850:	jne    8178ac <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  817852:	lea    0x248(%rbx),%rdi
  817859:	call   *0x6682e9(%rip)        # e7fb48 <_DYNAMIC+0x510>
  81785f:	jmp    8178ac <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x37c>
  817861:	call   *0x668021(%rip)        # e7f888 <_DYNAMIC+0x250>
  817867:	mov    %rax,%r14
  81786a:	jmp    8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  81786c:	mov    %rax,%r14
  81786f:	mov    0x220(%rbx),%rax
  817876:	lock decq (%rax)
  81787a:	jne    8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  81787c:	lea    0x220(%rbx),%rdi
  817883:	call   *0x6682bf(%rip)        # e7fb48 <_DYNAMIC+0x510>
  817889:	jmp    8178a0 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x370>
  81788b:	call   *0x667ff7(%rip)        # e7f888 <_DYNAMIC+0x250>
  817891:	mov    %rax,%r14
  817894:	lea    0x218(%rbx),%rdi
  81789b:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178a0:	lea    0x240(%rbx),%rdi
  8178a7:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178ac:	lea    0x268(%rbx),%rdi
  8178b3:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178b8:	lea    0x290(%rbx),%rdi
  8178bf:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178c4:	lea    0x2b8(%rbx),%rdi
  8178cb:	call   817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  8178d0:	lea    0x60(%rbx),%rdi
  8178d4:	call   8179d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  8178d9:	mov    0x310(%rbx),%rdi
  8178e0:	call   816670 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  8178e5:	mov    (%rbx),%rsi
  8178e8:	test   %rsi,%rsi
  8178eb:	jne    817955 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x425>
  8178ed:	mov    0x18(%rbx),%rsi
  8178f1:	test   %rsi,%rsi
  8178f4:	jne    817971 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x441>
  8178f6:	mov    0x30(%rbx),%rsi
  8178fa:	test   %rsi,%rsi
  8178fd:	jne    817991 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x461>
  817903:	mov    0x48(%rbx),%rsi
  817907:	test   %rsi,%rsi
  81790a:	je     81791f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3ef>
  81790c:	mov    0x50(%rbx),%rdi
  817910:	shl    $0x5,%rsi
  817914:	mov    $0x4,%edx
  817919:	call   *0x667f61(%rip)        # e7f880 <_DYNAMIC+0x248>
  81791f:	lea    0x2e0(%rbx),%rdi
  817926:	call   819de0 <<hashbrown::raw::RawTable<([u32; 8], u32)> as core::ops::drop::Drop>::drop>
  81792b:	mov    0x318(%rbx),%rax
  817932:	test   %rax,%rax
  817935:	je     81794d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41d>
  817937:	lock decq (%rax)
  81793b:	jne    81794d <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x41d>
  81793d:	add    $0x318,%rbx
  817944:	mov    %rbx,%rdi
  817947:	call   *0x668203(%rip)        # e7fb50 <_DYNAMIC+0x518>
  81794d:	mov    %r14,%rdi
  817950:	call   e2c420 <_Unwind_Resume@plt>
  817955:	mov    0x8(%rbx),%rdi
  817959:	shl    $0x4,%rsi
  81795d:	mov    $0x4,%edx
  817962:	call   *0x667f18(%rip)        # e7f880 <_DYNAMIC+0x248>
  817968:	mov    0x18(%rbx),%rsi
  81796c:	test   %rsi,%rsi
  81796f:	je     8178f6 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3c6>
  817971:	mov    0x20(%rbx),%rdi
  817975:	shl    $0x3,%rsi
  817979:	mov    $0x4,%edx
  81797e:	call   *0x667efc(%rip)        # e7f880 <_DYNAMIC+0x248>
  817984:	mov    0x30(%rbx),%rsi
  817988:	test   %rsi,%rsi
  81798b:	je     817903 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3d3>
  817991:	mov    0x38(%rbx),%rdi
  817995:	shl    $0x2,%rsi
  817999:	mov    $0x4,%edx
  81799e:	call   *0x667edc(%rip)        # e7f880 <_DYNAMIC+0x248>
  8179a4:	mov    0x48(%rbx),%rsi
  8179a8:	test   %rsi,%rsi
  8179ab:	jne    81790c <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3dc>
  8179b1:	jmp    81791f <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3ef>
  8179b6:	call   *0x667ecc(%rip)        # e7f888 <_DYNAMIC+0x250>
  8179bc:	mov    %rax,%r14
  8179bf:	jmp    8178d9 <core::ptr::drop_glue::<gpui_gpu::renderer::RendererState>+0x3a9>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008179d0 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  8179d0:	push   %r14
  8179d2:	push   %rbx
  8179d3:	push   %rax
  8179d4:	mov    %rdi,%rbx
  8179d7:	mov    (%rdi),%rax
  8179da:	lock decq (%rax)
  8179de:	jne    8179e9 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  8179e0:	mov    %rbx,%rdi
  8179e3:	call   *0x668137(%rip)        # e7fb20 <_DYNAMIC+0x4e8>
  8179e9:	mov    0x50(%rbx),%rax
  8179ed:	lock decq (%rax)
  8179f1:	jne    8179fd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  8179f3:	lea    0x50(%rbx),%rdi
  8179f7:	call   *0x66811b(%rip)        # e7fb18 <_DYNAMIC+0x4e0>
  8179fd:	mov    0x58(%rbx),%rax
  817a01:	lock decq (%rax)
  817a05:	jne    817a11 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  817a07:	lea    0x58(%rbx),%rdi
  817a0b:	call   *0x66810f(%rip)        # e7fb20 <_DYNAMIC+0x4e8>
  817a11:	mov    0xb0(%rbx),%rsi
  817a18:	test   %rsi,%rsi
  817a1b:	je     817a4d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  817a1d:	mov    %rsi,%rax
  817a20:	shl    $0x5,%rax
  817a24:	add    %rax,%rsi
  817a27:	add    $0x31,%rsi
  817a2b:	je     817a4d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  817a2d:	mov    0xa8(%rbx),%rdi
  817a34:	sub    %rax,%rdi
  817a37:	add    $0xffffffffffffffe0,%rdi
  817a3b:	mov    $0x10,%edx
  817a40:	add    $0x8,%rsp
  817a44:	pop    %rbx
  817a45:	pop    %r14
  817a47:	jmp    *0x667e33(%rip)        # e7f880 <_DYNAMIC+0x248>
  817a4d:	add    $0x8,%rsp
  817a51:	pop    %rbx
  817a52:	pop    %r14
  817a54:	ret
  817a55:	mov    %rax,%r14
  817a58:	jmp    817a85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a5a:	mov    %rax,%r14
  817a5d:	mov    0x58(%rbx),%rax
  817a61:	lock decq (%rax)
  817a65:	jne    817a85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a67:	lea    0x58(%rbx),%rdi
  817a6b:	call   *0x6680af(%rip)        # e7fb20 <_DYNAMIC+0x4e8>
  817a71:	jmp    817a85 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  817a73:	call   *0x667e0f(%rip)        # e7f888 <_DYNAMIC+0x250>
  817a79:	mov    %rax,%r14
  817a7c:	lea    0x50(%rbx),%rdi
  817a80:	call   817bd0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  817a85:	add    $0xa8,%rbx
  817a8c:	mov    %rbx,%rdi
  817a8f:	call   819e20 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  817a94:	mov    %r14,%rdi
  817a97:	call   e2c420 <_Unwind_Resume@plt>
  817a9c:	call   *0x667de6(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Error> bytes=30 frame=0

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817ab0 <core::ptr::drop_glue::<gpui_gpu::renderer::Error>>:
  817ab0:	cmpl   $0x1,(%rdi)
  817ab3:	ja     817acd <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817ab5:	mov    0x8(%rdi),%rsi
  817ab9:	test   %rsi,%rsi
  817abc:	je     817acd <core::ptr::drop_glue::<gpui_gpu::renderer::Error>+0x1d>
  817abe:	mov    0x10(%rdi),%rdi
  817ac2:	mov    $0x1,%edx
  817ac7:	jmp    *0x667db3(%rip)        # e7f880 <_DYNAMIC+0x248>
  817acd:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000817ad0 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  817ad0:	push   %r14
  817ad2:	push   %rbx
  817ad3:	push   %rax
  817ad4:	mov    %rdi,%rbx
  817ad7:	mov    (%rdi),%rax
  817ada:	lock decq (%rax)
  817ade:	jne    817ae9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  817ae0:	mov    %rbx,%rdi
  817ae3:	call   *0x668057(%rip)        # e7fb40 <_DYNAMIC+0x508>
  817ae9:	mov    0x8(%rbx),%rax
  817aed:	lock decq (%rax)
  817af1:	jne    817b07 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  817af3:	add    $0x8,%rbx
  817af7:	mov    %rbx,%rdi
  817afa:	add    $0x8,%rsp
  817afe:	pop    %rbx
  817aff:	pop    %r14
  817b01:	jmp    *0x668041(%rip)        # e7fb48 <_DYNAMIC+0x510>
  817b07:	add    $0x8,%rsp
  817b0b:	pop    %rbx
  817b0c:	pop    %r14
  817b0e:	ret
  817b0f:	mov    %rax,%r14
  817b12:	mov    0x8(%rbx),%rax
  817b16:	lock decq (%rax)
  817b1a:	jne    817b29 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  817b1c:	add    $0x8,%rbx
  817b20:	mov    %rbx,%rdi
  817b23:	call   *0x66801f(%rip)        # e7fb48 <_DYNAMIC+0x510>
  817b29:	mov    %r14,%rdi
  817b2c:	call   e2c420 <_Unwind_Resume@plt>
  817b31:	call   *0x667d51(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Error as core::fmt::Debug>::fmt bytes=304 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008184a0 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt>:
  8184a0:	sub    $0x18,%rsp
  8184a4:	mov    %rsi,%rax
  8184a7:	mov    (%rdi),%ecx
  8184a9:	lea    -0x7476b0(%rip),%rdx        # d0e00 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0xbb8>
  8184b0:	movslq (%rdx,%rcx,4),%rcx
  8184b4:	add    %rdx,%rcx
  8184b7:	jmp    *%rcx
  8184b9:	add    $0x8,%rdi
  8184bd:	mov    %rdi,0x10(%rsp)
  8184c2:	lea    -0x743a30(%rip),%rsi        # d4a99 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4851>
  8184c9:	jmp    818558 <<gpui_gpu::renderer::Error as core::fmt::Debug>::fmt+0xb8>
  8184ce:	lea    -0x743a13(%rip),%rsi        # d4ac2 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x487a>
  8184d5:	mov    $0x13,%edx
  8184da:	mov    %rax,%rdi
  8184dd:	add    $0x18,%rsp
  8184e1:	jmp    *0x667489(%rip)        # e7f970 <_DYNAMIC+0x338>
  8184e7:	add    $0x4,%rdi
  8184eb:	mov    %rdi,0x10(%rsp)
  8184f0:	lea    -0x743a52(%rip),%rsi        # d4aa5 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x485d>
  8184f7:	lea    0x61582a(%rip),%r8        # e2dd28 <__frame_dummy_init_array_entry+0x8c8>
  8184fe:	lea    0x10(%rsp),%rcx
  818503:	mov    $0x11,%edx
  818508:	mov    %rax,%rdi
  81850b:	call   *0x667467(%rip)        # e7f978 <_DYNAMIC+0x340>
  818511:	add    $0x18,%rsp
  818515:	ret
  818516:	lea    -0x743a67(%rip),%rsi        # d4ab6 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x486e>
  81851d:	mov    $0xc,%edx
  818522:	mov    %rax,%rdi
  818525:	add    $0x18,%rsp
  818529:	jmp    *0x667441(%rip)        # e7f970 <_DYNAMIC+0x338>
  81852f:	lea    -0x743a4b(%rip),%rsi        # d4aeb <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x48a3>
  818536:	mov    $0x9,%edx
  81853b:	mov    %rax,%rdi
  81853e:	add    $0x18,%rsp
  818542:	jmp    *0x667428(%rip)        # e7f970 <_DYNAMIC+0x338>
  818548:	add    $0x8,%rdi
  81854c:	mov    %rdi,0x10(%rsp)
  818551:	lea    -0x743ab9(%rip),%rsi        # d4a9f <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4857>
  818558:	lea    0x6157a9(%rip),%r8        # e2dd08 <__frame_dummy_init_array_entry+0x8a8>
  81855f:	lea    0x10(%rsp),%rcx
  818564:	mov    $0x6,%edx
  818569:	mov    %rax,%rdi
  81856c:	call   *0x667406(%rip)        # e7f978 <_DYNAMIC+0x340>
  818572:	add    $0x18,%rsp
  818576:	ret
  818577:	add    $0x8,%rdi
  81857b:	mov    %rdi,0x10(%rsp)
  818580:	lea    0x6157c1(%rip),%rcx        # e2dd48 <__frame_dummy_init_array_entry+0x8e8>
  818587:	mov    %rcx,(%rsp)
  81858b:	lea    -0x743abd(%rip),%rsi        # d4ad5 <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x488d>
  818592:	lea    -0x76978d(%rip),%rcx        # aee0c <anon.a16d5d421a76dfd8c37a17b53540311d.67.llvm.14190004212411149437+0x20>
  818599:	lea    0x10(%rsp),%r9
  81859e:	mov    $0x9,%edx
  8185a3:	mov    $0x4,%r8d
  8185a9:	mov    %rax,%rdi
  8185ac:	call   *0x6675ae(%rip)        # e7fb60 <_DYNAMIC+0x528>
  8185b2:	add    $0x18,%rsp
  8185b6:	ret
  8185b7:	lea    -0x743ae0(%rip),%rsi        # d4ade <anon.068260129a360d3c14a88deb110120c9.116.llvm.7357624670875813013+0x4896>
  8185be:	mov    $0xd,%edx
  8185c3:	mov    %rax,%rdi
  8185c6:	add    $0x18,%rsp
  8185ca:	jmp    *0x6673a0(%rip)        # e7f970 <_DYNAMIC+0x338>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819e20 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  819e20:	mov    0x8(%rdi),%rsi
  819e24:	test   %rsi,%rsi
  819e27:	je     819e4e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819e29:	mov    %rsi,%rax
  819e2c:	shl    $0x5,%rax
  819e30:	add    %rax,%rsi
  819e33:	add    $0x31,%rsi
  819e37:	je     819e4e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  819e39:	mov    (%rdi),%rdi
  819e3c:	sub    %rax,%rdi
  819e3f:	add    $0xffffffffffffffe0,%rdi
  819e43:	mov    $0x10,%edx
  819e48:	jmp    *0x665a32(%rip)        # e7f880 <_DYNAMIC+0x248>
  819e4e:	ret

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000819e50 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop>:
  819e50:	mov    0x8(%rdi),%rsi
  819e54:	test   %rsi,%rsi
  819e57:	je     819e7e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819e59:	mov    %rsi,%rax
  819e5c:	shl    $0x4,%rax
  819e60:	add    %rax,%rsi
  819e63:	add    $0x21,%rsi
  819e67:	je     819e7e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)> as core::ops::drop::Drop>::drop+0x2e>
  819e69:	mov    (%rdi),%rdi
  819e6c:	sub    %rax,%rdi
  819e6f:	add    $0xfffffffffffffff0,%rdi
  819e73:	mov    $0x10,%edx
  819e78:	jmp    *0x665a02(%rip)        # e7f880 <_DYNAMIC+0x248>
  819e7e:	ret

FUNCTION <core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3: usize], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}> bytes=325 frame=72

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081b710 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>:
  81b710:	push   %r14
  81b712:	push   %rbx
  81b713:	sub    $0x38,%rsp
  81b717:	mov    %rdi,%rbx
  81b71a:	cmpq   $0x0,(%rsi)
  81b71e:	je     81b828 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x118>
  81b724:	movdqu (%rsi),%xmm0
  81b728:	movdqu 0x10(%rsi),%xmm1
  81b72d:	movdqu 0x20(%rsi),%xmm2
  81b732:	movdqa %xmm2,0x20(%rsp)
  81b738:	movdqa %xmm1,0x10(%rsp)
  81b73e:	movdqa %xmm0,(%rsp)
  81b743:	cmpq   $0x0,0x18(%rcx)
  81b748:	je     81b83c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b74e:	lea    0x10(%rsp),%rsi
  81b753:	lea    0x20(%rcx),%rdi
  81b757:	mov    %rcx,%r14
  81b75a:	call   821df0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81b75f:	mov    %rax,%rsi
  81b762:	shr    $0x39,%rsi
  81b766:	mov    (%r14),%rcx
  81b769:	mov    0x8(%r14),%rdx
  81b76d:	movd   %esi,%xmm0
  81b771:	punpcklbw %xmm0,%xmm0
  81b775:	pshuflw $0x0,%xmm0,%xmm0
  81b77a:	pshufd $0x44,%xmm0,%xmm0
  81b77f:	mov    0x10(%rsp),%rsi
  81b784:	movzwl 0x1c(%rsp),%edi
  81b789:	xor    %r8d,%r8d
  81b78c:	mov    0x18(%rsp),%r9d
  81b791:	pcmpeqd %xmm1,%xmm1
  81b795:	and    %rdx,%rax
  81b798:	movdqu (%rcx,%rax,1),%xmm2
  81b79d:	movdqa %xmm2,%xmm3
  81b7a1:	pcmpeqb %xmm0,%xmm3
  81b7a5:	pmovmskb %xmm3,%r10d
  81b7aa:	test   %r10d,%r10d
  81b7ad:	je     81b7f0 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xe0>
  81b7af:	tzcnt  %r10d,%r14d
  81b7b4:	add    %rax,%r14
  81b7b7:	and    %rdx,%r14
  81b7ba:	shl    $0x5,%r14
  81b7be:	mov    %rcx,%r11
  81b7c1:	sub    %r14,%r11
  81b7c4:	cmp    -0x20(%r11),%rsi
  81b7c8:	jne    81b7d7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b7ca:	cmp    -0x14(%r11),%di
  81b7cf:	jne    81b7d7 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xc7>
  81b7d1:	cmp    -0x18(%r11),%r9d
  81b7d5:	je     81b80b <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0xfb>
  81b7d7:	lea    -0x1(%r10),%r11d
  81b7db:	and    %r10w,%r11w
  81b7df:	mov    %r11d,%r10d
  81b7e2:	jne    81b7af <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x9f>
  81b7e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
  81b7f0:	pcmpeqb %xmm1,%xmm2
  81b7f4:	pmovmskb %xmm2,%r10d
  81b7f9:	test   %r10d,%r10d
  81b7fc:	jne    81b83c <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x12c>
  81b7fe:	add    %r8,%rax
  81b801:	add    $0x10,%rax
  81b805:	add    $0x10,%r8
  81b809:	jmp    81b795 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>+0x85>
  81b80b:	mov    -0x4(%r11),%eax
  81b80f:	shl    $0x10,%eax
  81b812:	or     -0x8(%r11),%eax
  81b816:	mov    -0x10(%r11),%rcx
  81b81a:	mov    %rcx,(%rbx)
  81b81d:	mov    %eax,0x8(%rbx)
  81b820:	add    $0x38,%rsp
  81b824:	pop    %rbx
  81b825:	pop    %r14
  81b827:	ret
  81b828:	mov    0x8(%rdx),%eax
  81b82b:	mov    %eax,0x8(%rbx)
  81b82e:	mov    (%rdx),%rax
  81b831:	mov    %rax,(%rbx)
  81b834:	add    $0x38,%rsp
  81b838:	pop    %rbx
  81b839:	pop    %r14
  81b83b:	ret
  81b83c:	lea    -0x746956(%rip),%rdi        # d4eed <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x147>
  81b843:	lea    0x612936(%rip),%rdx        # e2e180 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x68>
  81b84a:	mov    $0x16,%esi
  81b84f:	call   *0x664383(%rip)        # e7fbd8 <_DYNAMIC+0x5a0>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Atlas> bytes=210 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>:
  81bb50:	push   %r14
  81bb52:	push   %rbx
  81bb53:	push   %rax
  81bb54:	mov    %rdi,%rbx
  81bb57:	mov    (%rdi),%rax
  81bb5a:	lock decq (%rax)
  81bb5e:	jne    81bb69 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x19>
  81bb60:	mov    %rbx,%rdi
  81bb63:	call   *0x663fb7(%rip)        # e7fb20 <_DYNAMIC+0x4e8>
  81bb69:	mov    0x50(%rbx),%rax
  81bb6d:	lock decq (%rax)
  81bb71:	jne    81bb7d <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x2d>
  81bb73:	lea    0x50(%rbx),%rdi
  81bb77:	call   *0x663f9b(%rip)        # e7fb18 <_DYNAMIC+0x4e0>
  81bb7d:	mov    0x58(%rbx),%rax
  81bb81:	lock decq (%rax)
  81bb85:	jne    81bb91 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x41>
  81bb87:	lea    0x58(%rbx),%rdi
  81bb8b:	call   *0x663f8f(%rip)        # e7fb20 <_DYNAMIC+0x4e8>
  81bb91:	mov    0xb0(%rbx),%rsi
  81bb98:	test   %rsi,%rsi
  81bb9b:	je     81bbcd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bb9d:	mov    %rsi,%rax
  81bba0:	shl    $0x5,%rax
  81bba4:	add    %rax,%rsi
  81bba7:	add    $0x31,%rsi
  81bbab:	je     81bbcd <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0x7d>
  81bbad:	mov    0xa8(%rbx),%rdi
  81bbb4:	sub    %rax,%rdi
  81bbb7:	add    $0xffffffffffffffe0,%rdi
  81bbbb:	mov    $0x10,%edx
  81bbc0:	add    $0x8,%rsp
  81bbc4:	pop    %rbx
  81bbc5:	pop    %r14
  81bbc7:	jmp    *0x663cb3(%rip)        # e7f880 <_DYNAMIC+0x248>
  81bbcd:	add    $0x8,%rsp
  81bbd1:	pop    %rbx
  81bbd2:	pop    %r14
  81bbd4:	ret
  81bbd5:	mov    %rax,%r14
  81bbd8:	jmp    81bc05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbda:	mov    %rax,%r14
  81bbdd:	mov    0x58(%rbx),%rax
  81bbe1:	lock decq (%rax)
  81bbe5:	jne    81bc05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbe7:	lea    0x58(%rbx),%rdi
  81bbeb:	call   *0x663f2f(%rip)        # e7fb20 <_DYNAMIC+0x4e8>
  81bbf1:	jmp    81bc05 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>+0xb5>
  81bbf3:	call   *0x663c8f(%rip)        # e7f888 <_DYNAMIC+0x250>
  81bbf9:	mov    %rax,%r14
  81bbfc:	lea    0x50(%rbx),%rdi
  81bc00:	call   81c4a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81bc05:	add    $0xa8,%rbx
  81bc0c:	mov    %rbx,%rdi
  81bc0f:	call   825520 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>
  81bc14:	mov    %r14,%rdi
  81bc17:	call   e2c420 <_Unwind_Resume@plt>
  81bc1c:	call   *0x663c66(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  81bc30:	push   %r14
  81bc32:	push   %rbx
  81bc33:	push   %rax
  81bc34:	mov    %rdi,%rbx
  81bc37:	mov    (%rdi),%rax
  81bc3a:	lock decq (%rax)
  81bc3e:	jne    81bc49 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  81bc40:	mov    %rbx,%rdi
  81bc43:	call   *0x663ef7(%rip)        # e7fb40 <_DYNAMIC+0x508>
  81bc49:	mov    0x8(%rbx),%rax
  81bc4d:	lock decq (%rax)
  81bc51:	jne    81bc67 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  81bc53:	add    $0x8,%rbx
  81bc57:	mov    %rbx,%rdi
  81bc5a:	add    $0x8,%rsp
  81bc5e:	pop    %rbx
  81bc5f:	pop    %r14
  81bc61:	jmp    *0x663ee1(%rip)        # e7fb48 <_DYNAMIC+0x510>
  81bc67:	add    $0x8,%rsp
  81bc6b:	pop    %rbx
  81bc6c:	pop    %r14
  81bc6e:	ret
  81bc6f:	mov    %rax,%r14
  81bc72:	mov    0x8(%rbx),%rax
  81bc76:	lock decq (%rax)
  81bc7a:	jne    81bc89 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  81bc7c:	add    $0x8,%rbx
  81bc80:	mov    %rbx,%rdi
  81bc83:	call   *0x663ebf(%rip)        # e7fb48 <_DYNAMIC+0x510>
  81bc89:	mov    %r14,%rdi
  81bc8c:	call   e2c420 <_Unwind_Resume@plt>
  81bc91:	call   *0x663bf1(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=622 frame=72

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c5d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c5d0:	push   %rbp
  81c5d1:	push   %r15
  81c5d3:	push   %r14
  81c5d5:	push   %r13
  81c5d7:	push   %r12
  81c5d9:	push   %rbx
  81c5da:	sub    $0x18,%rsp
  81c5de:	movss  0x8c(%rdi),%xmm3
  81c5e6:	movss  -0x76d632(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c5ee:	movaps %xmm3,%xmm1
  81c5f1:	subss  %xmm0,%xmm1
  81c5f5:	cvttss2si %xmm1,%rax
  81c5fa:	cvttss2si %xmm3,%r8
  81c5ff:	mov    %r8,%rcx
  81c602:	sar    $0x3f,%rcx
  81c606:	and    %rax,%rcx
  81c609:	or     %r8,%rcx
  81c60c:	xor    %r9d,%r9d
  81c60f:	xorps  %xmm1,%xmm1
  81c612:	ucomiss %xmm1,%xmm3
  81c615:	cmovb  %r9,%rcx
  81c619:	movss  -0x76d661(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c621:	ucomiss %xmm2,%xmm3
  81c624:	mov    $0xffffffffffffffff,%rax
  81c62b:	cmova  %rax,%rcx
  81c62f:	movss  0x94(%rdi),%xmm3
  81c637:	mov    %rcx,%r8
  81c63a:	shr    $0x4,%r8
  81c63e:	movaps %xmm3,%xmm4
  81c641:	subss  %xmm0,%xmm4
  81c645:	cvttss2si %xmm4,%r10
  81c64a:	cvttss2si %xmm3,%r11
  81c64f:	mov    %r11,%rbx
  81c652:	sar    $0x3f,%rbx
  81c656:	and    %r10,%rbx
  81c659:	or     %r11,%rbx
  81c65c:	ucomiss %xmm1,%xmm3
  81c65f:	cmovb  %r9,%rbx
  81c663:	ucomiss %xmm2,%xmm3
  81c666:	cmova  %rax,%rbx
  81c66a:	mov    %rsi,0x10(%rsp)
  81c66f:	lea    (%rcx,%rbx,1),%r9
  81c673:	dec    %r9
  81c676:	shr    $0x4,%r9
  81c67a:	cmp    %r9,%r8
  81c67d:	jbe    81c68e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c67f:	add    $0x18,%rsp
  81c683:	pop    %rbx
  81c684:	pop    %r12
  81c686:	pop    %r13
  81c688:	pop    %r14
  81c68a:	pop    %r15
  81c68c:	pop    %rbp
  81c68d:	ret
  81c68e:	movss  0x88(%rdi),%xmm3
  81c696:	movaps %xmm3,%xmm4
  81c699:	subss  %xmm0,%xmm4
  81c69d:	cvttss2si %xmm4,%rsi
  81c6a2:	cvttss2si %xmm3,%r10
  81c6a7:	mov    %r10,%rcx
  81c6aa:	sar    $0x3f,%rcx
  81c6ae:	and    %rsi,%rcx
  81c6b1:	or     %r10,%rcx
  81c6b4:	xor    %esi,%esi
  81c6b6:	ucomiss %xmm1,%xmm3
  81c6b9:	cmovb  %rsi,%rcx
  81c6bd:	ucomiss %xmm2,%xmm3
  81c6c0:	cmova  %rax,%rcx
  81c6c4:	movss  0x90(%rdi),%xmm3
  81c6cc:	mov    %rcx,%rbx
  81c6cf:	shr    $0x4,%rbx
  81c6d3:	movaps %xmm3,%xmm4
  81c6d6:	subss  %xmm0,%xmm4
  81c6da:	cvttss2si %xmm4,%rdi
  81c6df:	cvttss2si %xmm3,%r10
  81c6e4:	mov    %r10,%r11
  81c6e7:	sar    $0x3f,%r11
  81c6eb:	and    %rdi,%r11
  81c6ee:	or     %r10,%r11
  81c6f1:	ucomiss %xmm1,%xmm3
  81c6f4:	cmovb  %rsi,%r11
  81c6f8:	ucomiss %xmm2,%xmm3
  81c6fb:	cmova  %rax,%r11
  81c6ff:	add    %rcx,%r11
  81c702:	dec    %r11
  81c705:	shr    $0x4,%r11
  81c709:	mov    %rbx,0x8(%rsp)
  81c70e:	cmp    %r11,%rbx
  81c711:	jbe    81c73d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c713:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c720:	mov    %r8,%rax
  81c723:	cmp    %r9,%r8
  81c726:	adc    $0x0,%r8
  81c72a:	cmp    %r9,%rax
  81c72d:	jae    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c733:	cmp    %r9,%r8
  81c736:	jbe    81c720 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c738:	jmp    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c73d:	mov    (%rdx),%rbx
  81c740:	mov    0x8(%rdx),%r14
  81c744:	mov    0x10(%rdx),%rdx
  81c748:	mov    %r9,(%rsp)
  81c74c:	nopl   0x0(%rax)
  81c750:	mov    %r8,%r15
  81c753:	cmp    %r9,%r8
  81c756:	adc    $0x0,%r8
  81c75a:	mov    %r15,%r12
  81c75d:	imul   0x10(%rsp),%r12
  81c763:	mov    0x8(%rsp),%rbp
  81c768:	mov    %rbp,%r13
  81c76b:	nopl   0x0(%rax,%rax,1)
  81c770:	cmp    %r11,%rbp
  81c773:	adc    $0x0,%r13
  81c777:	lea    (%r12,%rbp,1),%rdi
  81c77b:	mov    0x10(%rbx),%rax
  81c77f:	cmp    %rax,%rdi
  81c782:	jae    81c81b <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x24b>
  81c788:	mov    0x8(%rbx),%rcx
  81c78c:	mov    0x4(%rcx,%rdi,8),%r10d
  81c791:	test   %r10d,%r10d
  81c794:	js     81c7ef <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x21f>
  81c796:	mov    (%rcx,%rdi,8),%r9d
  81c79a:	mov    %r9d,%esi
  81c79d:	shr    $0x17,%esi
  81c7a0:	mov    %r10d,%eax
  81c7a3:	shr    $0xe,%eax
  81c7a6:	and    $0x1fe00,%eax
  81c7ab:	or     %esi,%eax
  81c7ad:	je     81c7ef <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x21f>
  81c7af:	mov    %r9d,%esi
  81c7b2:	and    $0x7fffff,%esi
  81c7b8:	add    %esi,%eax
  81c7ba:	dec    %eax
  81c7bc:	xor    %esi,%esi
  81c7be:	sub    $0x800000,%r9d
  81c7c5:	mov    %r9d,(%rcx,%rdi,8)
  81c7c9:	setae  %sil
  81c7cd:	shl    $0x17,%esi
  81c7d0:	add    %r10d,%esi
  81c7d3:	add    $0xff800000,%esi
  81c7d9:	mov    %esi,0x4(%rcx,%rdi,8)
  81c7dd:	mov    0x10(%r14),%rcx
  81c7e1:	cmp    %rax,%rcx
  81c7e4:	jbe    81c82b <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x25b>
  81c7e6:	mov    0x8(%r14),%rcx
  81c7ea:	mov    (%rdx),%esi
  81c7ec:	mov    %esi,(%rcx,%rax,4)
  81c7ef:	cmp    %r11,%rbp
  81c7f2:	jae    81c800 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c7f4:	mov    %r13,%rbp
  81c7f7:	cmp    %r11,%r13
  81c7fa:	jbe    81c770 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1a0>
  81c800:	mov    (%rsp),%r9
  81c804:	cmp    %r9,%r15
  81c807:	jae    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c80d:	cmp    %r9,%r8
  81c810:	jbe    81c750 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x180>
  81c816:	jmp    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c81b:	lea    0x611976(%rip),%rdx        # e2e198 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c822:	mov    %rax,%rsi
  81c825:	call   *0x663305(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
  81c82b:	lea    0x61197e(%rip),%rdx        # e2e1b0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c832:	mov    %rax,%rdi
  81c835:	mov    %rcx,%rsi
  81c838:	call   *0x6632f2(%rip)        # e7fb30 <_DYNAMIC+0x4f8>

FUNCTION <gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>> bytes=321 frame=248

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c840 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>:
  81c840:	push   %rbp
  81c841:	push   %r15
  81c843:	push   %r14
  81c845:	push   %r13
  81c847:	push   %r12
  81c849:	push   %rbx
  81c84a:	sub    $0xc8,%rsp
  81c851:	mov    %edx,%ebp
  81c853:	mov    %rsi,%r14
  81c856:	mov    %rdi,(%rsp)
  81c85a:	lea    0x8(%rsp),%rdi
  81c85f:	call   *0x66338b(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81c865:	mov    0x8(%rsp),%rsi
  81c86a:	xor    %r13d,%r13d
  81c86d:	test   $0x1,%bpl
  81c871:	je     81c910 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xd0>
  81c877:	test   %rsi,%rsi
  81c87a:	je     81c955 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c880:	lea    0x70(%rsp),%r15
  81c885:	lea    0x8(%rsp),%r12
  81c88a:	mov    0x66335f(%rip),%rbp        # e7fbf0 <_DYNAMIC+0x5b8>
  81c891:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c8a0:	mov    0x18(%rsp),%rbx
  81c8a5:	cmp    $0x1,%rbx
  81c8a9:	jbe    81c8f0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb0>
  81c8ab:	mov    0x10(%rsp),%rax
  81c8b0:	mov    (%rax),%edx
  81c8b2:	mov    %r15,%rdi
  81c8b5:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81c8ba:	movss  0x74(%rsp),%xmm0
  81c8c0:	xorps  %xmm1,%xmm1
  81c8c3:	ucomiss %xmm1,%xmm0
  81c8c6:	lea    (%rbx,%rbx,1),%rax
  81c8ca:	lea    0x5(%rbx,%rbx,1),%rcx
  81c8cf:	lea    (%rax,%rax,2),%rdx
  81c8d3:	mov    %rcx,%rax
  81c8d6:	cmovne %rdx,%rax
  81c8da:	cmovp  %rdx,%rax
  81c8de:	cmpb   $0x3,0x70(%rsp)
  81c8e3:	cmovne %rcx,%rax
  81c8e7:	jmp    81c8f7 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xb7>
  81c8e9:	nopl   0x0(%rax)
  81c8f0:	add    %rbx,%rbx
  81c8f3:	lea    (%rbx,%rbx,2),%rax
  81c8f7:	add    %rax,%r13
  81c8fa:	jb     81c975 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c8fc:	mov    %r12,%rdi
  81c8ff:	mov    %r14,%rsi
  81c902:	call   *%rbp
  81c904:	mov    0x8(%rsp),%rsi
  81c909:	test   %rsi,%rsi
  81c90c:	jne    81c8a0 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x60>
  81c90e:	jmp    81c955 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c910:	test   %rsi,%rsi
  81c913:	je     81c955 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x115>
  81c915:	lea    0x8(%rsp),%r15
  81c91a:	mov    0x6632cf(%rip),%r12        # e7fbf0 <_DYNAMIC+0x5b8>
  81c921:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c930:	mov    %r13,%rax
  81c933:	mov    0x18(%rsp),%rcx
  81c938:	add    %rcx,%rcx
  81c93b:	lea    (%rcx,%rcx,2),%r13
  81c93f:	add    %rax,%r13
  81c942:	jb     81c975 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x135>
  81c944:	mov    %r15,%rdi
  81c947:	mov    %r14,%rsi
  81c94a:	call   *%r12
  81c94d:	cmpq   $0x0,0x8(%rsp)
  81c953:	jne    81c930 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0xf0>
  81c955:	mov    (%rsp),%rax
  81c959:	mov    %r13,0x8(%rax)
  81c95d:	movl   $0xffffffff,(%rax)
  81c963:	add    $0xc8,%rsp
  81c96a:	pop    %rbx
  81c96b:	pop    %r12
  81c96d:	pop    %r13
  81c96f:	pop    %r14
  81c971:	pop    %r15
  81c973:	pop    %rbp
  81c974:	ret
  81c975:	mov    (%rsp),%rax
  81c979:	movl   $0x6,(%rax)
  81c97f:	jmp    81c963 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>+0x123>

FUNCTION <gpui_gpu::renderer::Renderer>::set_grouped_records bytes=95 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cbd0 <<gpui_gpu::renderer::Renderer>::set_grouped_records>:
  81cbd0:	push   %rbp
  81cbd1:	push   %r14
  81cbd3:	push   %rbx
  81cbd4:	cmp    0x329(%rdi),%sil
  81cbdb:	je     81cc1b <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x4b>
  81cbdd:	mov    0x318(%rdi),%rax
  81cbe4:	test   %rax,%rax
  81cbe7:	je     81cc09 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cbe9:	lock decq (%rax)
  81cbed:	jne    81cc09 <<gpui_gpu::renderer::Renderer>::set_grouped_records+0x39>
  81cbef:	lea    0x318(%rdi),%rbx
  81cbf6:	mov    %rdi,%r14
  81cbf9:	mov    %rbx,%rdi
  81cbfc:	mov    %esi,%ebp
  81cbfe:	call   *0x662f4c(%rip)        # e7fb50 <_DYNAMIC+0x518>
  81cc04:	mov    %r14,%rdi
  81cc07:	mov    %ebp,%esi
  81cc09:	movq   $0x0,0x318(%rdi)
  81cc14:	mov    %sil,0x329(%rdi)
  81cc1b:	pop    %rbx
  81cc1c:	pop    %r14
  81cc1e:	pop    %rbp
  81cc1f:	ret
  81cc20:	movq   $0x0,(%rbx)
  81cc27:	mov    %rax,%rdi
  81cc2a:	call   e2c420 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::Buffer>::write bytes=303 frame=120

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cc30 <<gpui_gpu::renderer::Buffer>::write>:
  81cc30:	push   %r15
  81cc32:	push   %r14
  81cc34:	push   %r13
  81cc36:	push   %r12
  81cc38:	push   %rbx
  81cc39:	sub    $0x50,%rsp
  81cc3d:	mov    %rdx,%r14
  81cc40:	mov    %rdi,%rbx
  81cc43:	cmp    0x20(%rdi),%r8
  81cc47:	jbe    81ccfa <<gpui_gpu::renderer::Buffer>::write+0xca>
  81cc4d:	mov    %rcx,%r15
  81cc50:	mov    $0x1,%r13d
  81cc56:	cmp    $0x2,%r8
  81cc5a:	jb     81cc73 <<gpui_gpu::renderer::Buffer>::write+0x43>
  81cc5c:	lea    -0x1(%r8),%rax
  81cc60:	bsr    %rax,%rcx
  81cc64:	not    %ecx
  81cc66:	mov    $0xffffffffffffffff,%r13
  81cc6d:	shr    %cl,%r13
  81cc70:	inc    %r13
  81cc73:	mov    %r8,%r12
  81cc76:	lea    -0x747d7a(%rip),%rax        # d4f03 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x15d>
  81cc7d:	mov    %rax,0x30(%rsp)
  81cc82:	movq   $0xa,0x38(%rsp)
  81cc8b:	mov    %r13,0x40(%rsp)
  81cc90:	movl   $0x88,0x48(%rsp)
  81cc98:	movb   $0x0,0x4c(%rsp)
  81cc9d:	lea    0x8(%rsp),%rdi
  81cca2:	lea    0x30(%rsp),%rdx
  81cca7:	call   *0x662fa3(%rip)        # e7fc50 <_DYNAMIC+0x618>
  81ccad:	mov    %r13,0x28(%rsp)
  81ccb2:	mov    (%rbx),%rax
  81ccb5:	lock decq (%rax)
  81ccb9:	jne    81ccc4 <<gpui_gpu::renderer::Buffer>::write+0x94>
  81ccbb:	mov    %rbx,%rdi
  81ccbe:	call   *0x662e7c(%rip)        # e7fb40 <_DYNAMIC+0x508>
  81ccc4:	mov    0x8(%rbx),%rax
  81ccc8:	lock decq (%rax)
  81cccc:	jne    81ccd8 <<gpui_gpu::renderer::Buffer>::write+0xa8>
  81ccce:	lea    0x8(%rbx),%rdi
  81ccd2:	call   *0x662e70(%rip)        # e7fb48 <_DYNAMIC+0x510>
  81ccd8:	mov    0x28(%rsp),%rax
  81ccdd:	mov    %rax,0x20(%rbx)
  81cce1:	movups 0x8(%rsp),%xmm0
  81cce6:	movups 0x18(%rsp),%xmm1
  81cceb:	movups %xmm1,0x10(%rbx)
  81ccef:	movups %xmm0,(%rbx)
  81ccf2:	mov    %r12,%r8
  81ccf5:	mov    %r15,%rcx
  81ccf8:	jmp    81ccff <<gpui_gpu::renderer::Buffer>::write+0xcf>
  81ccfa:	test   %r8,%r8
  81ccfd:	je     81cd0d <<gpui_gpu::renderer::Buffer>::write+0xdd>
  81ccff:	mov    %r14,%rdi
  81cd02:	mov    %rbx,%rsi
  81cd05:	xor    %edx,%edx
  81cd07:	call   *0x662efb(%rip)        # e7fc08 <_DYNAMIC+0x5d0>
  81cd0d:	add    $0x50,%rsp
  81cd11:	pop    %rbx
  81cd12:	pop    %r12
  81cd14:	pop    %r13
  81cd16:	pop    %r14
  81cd18:	pop    %r15
  81cd1a:	ret
  81cd1b:	mov    %rax,%r14
  81cd1e:	jmp    81cd37 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cd20:	mov    %rax,%r14
  81cd23:	mov    0x8(%rbx),%rax
  81cd27:	lock decq (%rax)
  81cd2b:	jne    81cd37 <<gpui_gpu::renderer::Buffer>::write+0x107>
  81cd2d:	lea    0x8(%rbx),%rdi
  81cd31:	call   *0x662e11(%rip)        # e7fb48 <_DYNAMIC+0x510>
  81cd37:	mov    0x28(%rsp),%rax
  81cd3c:	mov    %rax,0x20(%rbx)
  81cd40:	movups 0x8(%rsp),%xmm0
  81cd45:	movups 0x18(%rsp),%xmm1
  81cd4a:	movups %xmm1,0x10(%rbx)
  81cd4e:	movups %xmm0,(%rbx)
  81cd51:	mov    %r14,%rdi
  81cd54:	call   e2c420 <_Unwind_Resume@plt>
  81cd59:	call   *0x662b29(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::new bytes=706 frame=376

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081cd60 <<gpui_gpu::renderer::Atlas>::new>:
  81cd60:	push   %rbp
  81cd61:	push   %r14
  81cd63:	push   %rbx
  81cd64:	sub    $0x160,%rsp
  81cd6b:	mov    %edx,%ebp
  81cd6d:	mov    %rdi,%rbx
  81cd70:	lea    -0x747e6a(%rip),%rax        # d4f0d <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x167>
  81cd77:	mov    %rax,(%rsp)
  81cd7b:	movq   $0xe,0x8(%rsp)
  81cd84:	mov    %edx,0x10(%rsp)
  81cd88:	mov    %edx,0x14(%rsp)
  81cd8c:	movaps -0x7708a3(%rip),%xmm0        # ac4f0 <anon.531a4b6c7f642b9eba5e0e986955623b.109.llvm.14547199655466482296+0x2c0>
  81cd93:	movups %xmm0,0x18(%rsp)
  81cd98:	movl   $0x0,0x28(%rsp)
  81cda0:	movl   $0x6,0x34(%rsp)
  81cda8:	movq   $0x4,0x38(%rsp)
  81cdb1:	movq   $0x0,0x40(%rsp)
  81cdba:	lea    0x110(%rsp),%r14
  81cdc2:	mov    %rsp,%rdx
  81cdc5:	mov    %r14,%rdi
  81cdc8:	call   *0x662d0a(%rip)        # e7fad8 <_DYNAMIC+0x4a0>
  81cdce:	movq   $0x0,0x18(%rsp)
  81cdd7:	movl   $0xffffffff,0x30(%rsp)
  81cddf:	movl   $0x0,(%rsp)
  81cde6:	movabs $0xffffffff00000000,%rax
  81cdf0:	mov    %rax,0x28(%rsp)
  81cdf5:	movq   $0x0,0x3c(%rsp)
  81cdfe:	movl   $0x0,0x8(%rsp)
  81ce06:	movl   $0x0,0x10(%rsp)
  81ce0e:	lea    0xb8(%rsp),%rdi
  81ce16:	mov    %rsp,%rdx
  81ce19:	mov    %r14,%rsi
  81ce1c:	call   *0x662cbe(%rip)        # e7fae0 <_DYNAMIC+0x4a8>
  81ce22:	movups 0x150(%rsp),%xmm0
  81ce2a:	movaps %xmm0,0xa0(%rsp)
  81ce32:	movups 0x110(%rsp),%xmm0
  81ce3a:	movups 0x120(%rsp),%xmm1
  81ce42:	movups 0x130(%rsp),%xmm2
  81ce4a:	movups 0x140(%rsp),%xmm3
  81ce52:	movaps %xmm3,0x90(%rsp)
  81ce5a:	movaps %xmm2,0x80(%rsp)
  81ce62:	movaps %xmm1,0x70(%rsp)
  81ce67:	movaps %xmm0,0x60(%rsp)
  81ce6c:	mov    0x108(%rsp),%rax
  81ce74:	mov    %rax,0x50(%rsp)
  81ce79:	movups 0xf8(%rsp),%xmm0
  81ce81:	movaps %xmm0,0x40(%rsp)
  81ce86:	movups 0xb8(%rsp),%xmm0
  81ce8e:	movups 0xc8(%rsp),%xmm1
  81ce96:	movups 0xd8(%rsp),%xmm2
  81ce9e:	movups 0xe8(%rsp),%xmm3
  81cea6:	movaps %xmm3,0x30(%rsp)
  81ceab:	movaps %xmm2,0x20(%rsp)
  81ceb0:	movaps %xmm1,0x10(%rsp)
  81ceb5:	movaps %xmm0,(%rsp)
  81ceb9:	mov    %fs:0x0,%rax
  81cec2:	lea    -0x28(%rax),%rax
  81cec9:	mov    %rax,%r14
  81cecc:	cmpb   $0x1,0x10(%rax)
  81ced0:	jne    81cfbb <<gpui_gpu::renderer::Atlas>::new+0x25b>
  81ced6:	mov    (%r14),%rax
  81ced9:	mov    0x8(%r14),%rdx
  81cedd:	lea    0x1(%rax),%rcx
  81cee1:	mov    %rcx,(%r14)
  81cee4:	movaps 0xa0(%rsp),%xmm0
  81ceec:	movups %xmm0,0x40(%rbx)
  81cef0:	movaps 0x60(%rsp),%xmm0
  81cef5:	movaps 0x70(%rsp),%xmm1
  81cefa:	movaps 0x80(%rsp),%xmm2
  81cf02:	movaps 0x90(%rsp),%xmm3
  81cf0a:	movups %xmm3,0x30(%rbx)
  81cf0e:	movups %xmm2,0x20(%rbx)
  81cf12:	movups %xmm1,0x10(%rbx)
  81cf16:	movups %xmm0,(%rbx)
  81cf19:	movups 0xb8(%rsp),%xmm0
  81cf21:	movups 0xc8(%rsp),%xmm1
  81cf29:	movups 0xd8(%rsp),%xmm2
  81cf31:	movups 0xe8(%rsp),%xmm3
  81cf39:	movups %xmm0,0x50(%rbx)
  81cf3d:	movups %xmm1,0x60(%rbx)
  81cf41:	movups %xmm2,0x70(%rbx)
  81cf45:	movups %xmm3,0x80(%rbx)
  81cf4c:	movups 0xf8(%rsp),%xmm0
  81cf54:	movups %xmm0,0x90(%rbx)
  81cf5b:	mov    0x108(%rsp),%rcx
  81cf63:	mov    %rcx,0xa0(%rbx)
  81cf6a:	mov    %ebp,0xd8(%rbx)
  81cf70:	movq   $0x0,0xdc(%rbx)
  81cf7b:	movl   $0x0,0xe4(%rbx)
  81cf85:	movups 0x61126c(%rip),%xmm0        # e2e1f8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  81cf8c:	movups %xmm0,0xa8(%rbx)
  81cf93:	movups 0x61126e(%rip),%xmm0        # e2e208 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf0>
  81cf9a:	movups %xmm0,0xb8(%rbx)
  81cfa1:	mov    %rax,0xc8(%rbx)
  81cfa8:	mov    %rdx,0xd0(%rbx)
  81cfaf:	add    $0x160,%rsp
  81cfb6:	pop    %rbx
  81cfb7:	pop    %r14
  81cfb9:	pop    %rbp
  81cfba:	ret
  81cfbb:	call   *0x662c97(%rip)        # e7fc58 <_DYNAMIC+0x620>
  81cfc1:	mov    %rax,(%r14)
  81cfc4:	mov    %rdx,0x8(%r14)
  81cfc8:	movb   $0x1,0x10(%r14)
  81cfcd:	jmp    81cedd <<gpui_gpu::renderer::Atlas>::new+0x17d>
  81cfd2:	mov    %rax,%rbx
  81cfd5:	mov    %rsp,%rdi
  81cfd8:	call   81c4a0 <core::ptr::drop_glue::<wgpu::api::texture_view::TextureView>>
  81cfdd:	mov    0x60(%rsp),%rax
  81cfe2:	lock decq (%rax)
  81cfe6:	jne    81d014 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cfe8:	lea    0x60(%rsp),%rdi
  81cfed:	call   *0x662b2d(%rip)        # e7fb20 <_DYNAMIC+0x4e8>
  81cff3:	jmp    81d014 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81cff5:	mov    %rax,%rbx
  81cff8:	mov    0x110(%rsp),%rax
  81d000:	lock decq (%rax)
  81d004:	jne    81d014 <<gpui_gpu::renderer::Atlas>::new+0x2b4>
  81d006:	lea    0x110(%rsp),%rdi
  81d00e:	call   *0x662b0c(%rip)        # e7fb20 <_DYNAMIC+0x4e8>
  81d014:	mov    %rbx,%rdi
  81d017:	call   e2c420 <_Unwind_Resume@plt>
  81d01c:	call   *0x662866(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::Atlas>::insert bytes=608 frame=152

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d030 <<gpui_gpu::renderer::Atlas>::insert>:
  81d030:	push   %rbp
  81d031:	push   %r15
  81d033:	push   %r14
  81d035:	push   %r13
  81d037:	push   %r12
  81d039:	push   %rbx
  81d03a:	sub    $0x68,%rsp
  81d03e:	mov    %rdx,%r12
  81d041:	mov    %rsi,%r15
  81d044:	mov    %rdi,%r14
  81d047:	lea    0x10(%rdx),%r13
  81d04b:	cmpq   $0x0,0xc0(%rdi)
  81d053:	je     81d11b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d059:	lea    0xc8(%r14),%rdi
  81d060:	mov    %r13,%rsi
  81d063:	call   821df0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  81d068:	mov    %rax,%rsi
  81d06b:	shr    $0x39,%rsi
  81d06f:	mov    0xa8(%r14),%rcx
  81d076:	mov    0xb0(%r14),%rdx
  81d07d:	movd   %esi,%xmm0
  81d081:	punpcklbw %xmm0,%xmm0
  81d085:	pshuflw $0x0,%xmm0,%xmm0
  81d08a:	pshufd $0x44,%xmm0,%xmm0
  81d08f:	mov    0x10(%r12),%rsi
  81d094:	movzwl 0x1c(%r12),%edi
  81d09a:	mov    0x18(%r12),%r8d
  81d09f:	pcmpeqd %xmm1,%xmm1
  81d0a3:	xor    %r9d,%r9d
  81d0a6:	and    %rdx,%rax
  81d0a9:	movdqu (%rcx,%rax,1),%xmm2
  81d0ae:	movdqa %xmm2,%xmm3
  81d0b2:	pcmpeqb %xmm0,%xmm3
  81d0b6:	pmovmskb %xmm3,%r10d
  81d0bb:	test   %r10d,%r10d
  81d0be:	je     81d100 <<gpui_gpu::renderer::Atlas>::insert+0xd0>
  81d0c0:	tzcnt  %r10d,%ebx
  81d0c5:	add    %rax,%rbx
  81d0c8:	and    %rdx,%rbx
  81d0cb:	shl    $0x5,%rbx
  81d0cf:	mov    %rcx,%r11
  81d0d2:	sub    %rbx,%r11
  81d0d5:	cmp    -0x20(%r11),%rsi
  81d0d9:	jne    81d0ec <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d0db:	cmp    -0x14(%r11),%di
  81d0e0:	jne    81d0ec <<gpui_gpu::renderer::Atlas>::insert+0xbc>
  81d0e2:	cmp    -0x18(%r11),%r8d
  81d0e6:	je     81d183 <<gpui_gpu::renderer::Atlas>::insert+0x153>
  81d0ec:	lea    -0x1(%r10),%r11d
  81d0f0:	and    %r10w,%r11w
  81d0f4:	mov    %r11d,%r10d
  81d0f7:	jne    81d0c0 <<gpui_gpu::renderer::Atlas>::insert+0x90>
  81d0f9:	nopl   0x0(%rax)
  81d100:	pcmpeqb %xmm1,%xmm2
  81d104:	pmovmskb %xmm2,%r10d
  81d109:	test   %r10d,%r10d
  81d10c:	jne    81d11b <<gpui_gpu::renderer::Atlas>::insert+0xeb>
  81d10e:	add    %r9,%rax
  81d111:	add    $0x10,%rax
  81d115:	add    $0x10,%r9
  81d119:	jmp    81d0a6 <<gpui_gpu::renderer::Atlas>::insert+0x76>
  81d11b:	mov    0x20(%r12),%ebp
  81d120:	xor    %eax,%eax
  81d122:	test   %ebp,%ebp
  81d124:	je     81d17e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d126:	mov    %r15,%rdi
  81d129:	mov    0x28(%r12),%r15d
  81d12e:	test   %r15d,%r15d
  81d131:	je     81d17e <<gpui_gpu::renderer::Atlas>::insert+0x14e>
  81d133:	mov    0xd8(%r14),%ecx
  81d13a:	cmp    %ebp,%ecx
  81d13c:	jb     81d281 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d142:	cmp    %r15d,%ecx
  81d145:	jb     81d281 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d14b:	mov    %r13,0x40(%rsp)
  81d150:	mov    0xdc(%r14),%r8d
  81d157:	mov    0xe4(%r14),%r13d
  81d15e:	lea    (%r8,%rbp,1),%edx
  81d162:	xor    %eax,%eax
  81d164:	cmp    %ecx,%edx
  81d166:	mov    $0x0,%ebx
  81d16b:	cmova  %r13d,%ebx
  81d16f:	add    0xe0(%r14),%ebx
  81d176:	lea    (%rbx,%r15,1),%esi
  81d17a:	cmp    %ecx,%esi
  81d17c:	jbe    81d18f <<gpui_gpu::renderer::Atlas>::insert+0x15f>
  81d17e:	jmp    81d281 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d183:	mov    $0x1,%eax
  81d188:	xor    %edx,%edx
  81d18a:	jmp    81d281 <<gpui_gpu::renderer::Atlas>::insert+0x251>
  81d18f:	cmp    %r13d,%r15d
  81d192:	cmova  %r15d,%r13d
  81d196:	cmp    %ecx,%edx
  81d198:	cmova  %eax,%r8d
  81d19c:	lea    0xa8(%r14),%rax
  81d1a3:	mov    %rax,0x38(%rsp)
  81d1a8:	mov    %r14,0x48(%rsp)
  81d1ad:	movl   $0x0,0x50(%rsp)
  81d1b5:	mov    %r8d,0x54(%rsp)
  81d1ba:	mov    %ebx,0x58(%rsp)
  81d1be:	movq   $0x0,0x5c(%rsp)
  81d1c7:	mov    (%r12),%rdx
  81d1cb:	mov    0x8(%r12),%rcx
  81d1d0:	mov    %rcx,0x30(%rsp)
  81d1d5:	movq   $0x0,0x8(%rsp)
  81d1de:	movl   $0x1,0x10(%rsp)
  81d1e6:	mov    %ebp,0x14(%rsp)
  81d1ea:	movl   $0x1,0x18(%rsp)
  81d1f2:	mov    %r15d,0x1c(%rsp)
  81d1f7:	mov    %ebp,0x20(%rsp)
  81d1fb:	mov    %r15d,0x24(%rsp)
  81d200:	movl   $0x1,0x28(%rsp)
  81d208:	cmova  %r15d,%r13d
  81d20c:	lea    0x48(%rsp),%rsi
  81d211:	mov    %r8,%r12
  81d214:	lea    0x8(%rsp),%r8
  81d219:	lea    0x20(%rsp),%r9
  81d21e:	call   *0x662a3c(%rip)        # e7fc60 <_DYNAMIC+0x628>
  81d224:	lea    (%r12,%rbp,1),%eax
  81d228:	mov    %eax,0xdc(%r14)
  81d22f:	mov    %ebx,0xe0(%r14)
  81d236:	mov    %r13d,0xe4(%r14)
  81d23d:	mov    0x40(%rsp),%rax
  81d242:	movdqu (%rax),%xmm0
  81d246:	movdqa %xmm0,0x20(%rsp)
  81d24c:	mov    %r12d,0x8(%rsp)
  81d251:	mov    %ebx,0xc(%rsp)
  81d255:	mov    %ebp,0x10(%rsp)
  81d259:	mov    %r15d,0x14(%rsp)
  81d25e:	lea    0x48(%rsp),%rdi
  81d263:	lea    0x20(%rsp),%rdx
  81d268:	lea    0x8(%rsp),%rcx
  81d26d:	mov    0x38(%rsp),%rsi
  81d272:	call   823620 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>
  81d277:	mov    0x30(%rsp),%rdx
  81d27c:	mov    $0x1,%eax
  81d281:	add    $0x68,%rsp
  81d285:	pop    %rbx
  81d286:	pop    %r12
  81d288:	pop    %r13
  81d28a:	pop    %r14
  81d28c:	pop    %r15
  81d28e:	pop    %rbp
  81d28f:	ret

FUNCTION <gpui_gpu::renderer::GpuContext>::submit bytes=469 frame=1384

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d290 <<gpui_gpu::renderer::GpuContext>::submit>:
  81d290:	push   %r15
  81d292:	push   %r14
  81d294:	push   %r12
  81d296:	push   %rbx
  81d297:	sub    $0x548,%rsp
  81d29e:	mov    %rdx,%r14
  81d2a1:	mov    %rsi,%r12
  81d2a4:	mov    %rdi,%rbx
  81d2a7:	lea    0x610ffa(%rip),%rdx        # e2e2a8 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.264339216088034180>
  81d2ae:	lea    0x30(%rsp),%r15
  81d2b3:	mov    %r15,%rdi
  81d2b6:	mov    %rbx,%rsi
  81d2b9:	call   *0x6629a9(%rip)        # e7fc68 <_DYNAMIC+0x630>
  81d2bf:	xorps  %xmm0,%xmm0
  81d2c2:	movups %xmm0,0x10(%rsp)
  81d2c7:	movups %xmm0,0x20(%rsp)
  81d2cc:	movl   $0x0,0x50(%rsp)
  81d2d4:	movb   $0x0,0x58(%rsp)
  81d2d9:	movups 0x9(%rsp),%xmm0
  81d2de:	movups %xmm0,0x59(%rsp)
  81d2e3:	movups 0x19(%rsp),%xmm0
  81d2e8:	movups %xmm0,0x69(%rsp)
  81d2ed:	mov    0x28(%rsp),%rax
  81d2f2:	mov    %rax,0x78(%rsp)
  81d2f7:	movl   $0x0,0x80(%rsp)
  81d302:	mov    %r12,0x88(%rsp)
  81d30a:	movq   $0x0,0x90(%rsp)
  81d316:	lea    -0x748402(%rip),%rax        # d4f1b <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.264339216088034180>
  81d31d:	mov    %rax,0xe0(%rsp)
  81d325:	movq   $0xa,0xe8(%rsp)
  81d331:	lea    0x50(%rsp),%rax
  81d336:	mov    %rax,0xd0(%rsp)
  81d33e:	movq   $0x1,0xd8(%rsp)
  81d34a:	movl   $0xffffffff,0xb8(%rsp)
  81d355:	movl   $0x2,0x98(%rsp)
  81d360:	movq   $0x0,0xf0(%rsp)
  81d36c:	movl   $0x0,0xf8(%rsp)
  81d377:	lea    0x100(%rsp),%rdi
  81d37f:	lea    0x98(%rsp),%rdx
  81d387:	mov    %r15,%rsi
  81d38a:	call   *0x6628e0(%rip)        # e7fc70 <_DYNAMIC+0x638>
  81d390:	lea    0x10(%rbx),%rsi
  81d394:	lea    0x100(%rsp),%rdi
  81d39c:	call   *0x6628d6(%rip)        # e7fc78 <_DYNAMIC+0x640>
  81d3a2:	lea    0x100(%rsp),%rdi
  81d3aa:	mov    $0x4,%ecx
  81d3af:	xor    %esi,%esi
  81d3b1:	mov    %r14,%rdx
  81d3b4:	xor    %r8d,%r8d
  81d3b7:	call   *0x6628c3(%rip)        # e7fc80 <_DYNAMIC+0x648>
  81d3bd:	lea    0x100(%rsp),%rdi
  81d3c5:	xor    %esi,%esi
  81d3c7:	mov    $0x3,%edx
  81d3cc:	xor    %ecx,%ecx
  81d3ce:	mov    $0x1,%r8d
  81d3d4:	call   *0x6628ae(%rip)        # e7fc88 <_DYNAMIC+0x650>
  81d3da:	lea    0x100(%rsp),%rdi
  81d3e2:	call   81c3a0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d3e7:	movups 0x30(%rsp),%xmm0
  81d3ec:	movups 0x40(%rsp),%xmm1
  81d3f1:	movaps %xmm1,0x110(%rsp)
  81d3f9:	movaps %xmm0,0x100(%rsp)
  81d401:	lea    0x98(%rsp),%r14
  81d409:	lea    0x100(%rsp),%rsi
  81d411:	mov    %r14,%rdi
  81d414:	call   *0x662876(%rip)        # e7fc90 <_DYNAMIC+0x658>
  81d41a:	add    $0x8,%rbx
  81d41e:	mov    %rbx,%rdi
  81d421:	mov    %r14,%rsi
  81d424:	call   825550 <<wgpu::api::queue::Queue>::submit::<[wgpu::api::command_buffer::CommandBuffer; 1]>>
  81d429:	add    $0x548,%rsp
  81d430:	pop    %rbx
  81d431:	pop    %r12
  81d433:	pop    %r14
  81d435:	pop    %r15
  81d437:	ret
  81d438:	mov    %rax,%rbx
  81d43b:	jmp    81d44d <<gpui_gpu::renderer::GpuContext>::submit+0x1bd>
  81d43d:	mov    %rax,%rbx
  81d440:	lea    0x100(%rsp),%rdi
  81d448:	call   81c3a0 <core::ptr::drop_glue::<wgpu::api::render_pass::RenderPass>>
  81d44d:	lea    0x30(%rsp),%rdi
  81d452:	call   81c510 <core::ptr::drop_glue::<wgpu::api::command_encoder::CommandEncoder>>
  81d457:	mov    %rbx,%rdi
  81d45a:	call   e2c420 <_Unwind_Resume@plt>
  81d45f:	call   *0x662423(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::correction bytes=981 frame=184

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d470 <<gpui_gpu::renderer::RendererState>::correction>:
  81d470:	push   %r15
  81d472:	push   %r14
  81d474:	push   %r13
  81d476:	push   %r12
  81d478:	push   %rbx
  81d479:	sub    $0x90,%rsp
  81d480:	mov    %rdi,%rbx
  81d483:	movss  (%rdx),%xmm1
  81d487:	movss  0x8(%rdx),%xmm2
  81d48c:	movaps %xmm1,%xmm0
  81d48f:	addss  %xmm2,%xmm0
  81d493:	movd   %xmm0,%eax
  81d497:	and    $0x7fffffff,%eax
  81d49c:	xorps  %xmm8,%xmm8
  81d4a0:	xorps  %xmm9,%xmm9
  81d4a4:	cmp    $0x7f7fffff,%eax
  81d4a9:	jg     81d4c8 <<gpui_gpu::renderer::RendererState>::correction+0x58>
  81d4ab:	cvtss2sd %xmm1,%xmm1
  81d4af:	cvtss2sd %xmm2,%xmm2
  81d4b3:	cvtss2sd %xmm0,%xmm0
  81d4b7:	addsd  %xmm1,%xmm2
  81d4bb:	subsd  %xmm0,%xmm2
  81d4bf:	xorps  %xmm9,%xmm9
  81d4c3:	cvtsd2ss %xmm2,%xmm9
  81d4c8:	movupd (%rsi),%xmm0
  81d4cc:	movupd 0x8(%rsi),%xmm1
  81d4d1:	movsd  0x10(%rsi),%xmm2
  81d4d6:	movsd  0x18(%rsi),%xmm3
  81d4db:	movupd 0x20(%rsi),%xmm4
  81d4e0:	movss  0x4(%rdx),%xmm6
  81d4e5:	movss  0xc(%rdx),%xmm7
  81d4ea:	movaps %xmm6,%xmm5
  81d4ed:	addss  %xmm7,%xmm5
  81d4f1:	movd   %xmm5,%eax
  81d4f5:	and    $0x7fffffff,%eax
  81d4fa:	cmp    $0x7f7fffff,%eax
  81d4ff:	jg     81d51e <<gpui_gpu::renderer::RendererState>::correction+0xae>
  81d501:	cvtss2sd %xmm6,%xmm6
  81d505:	cvtss2sd %xmm7,%xmm7
  81d509:	cvtss2sd %xmm5,%xmm5
  81d50d:	addsd  %xmm6,%xmm7
  81d511:	subsd  %xmm5,%xmm7
  81d515:	xorps  %xmm8,%xmm8
  81d519:	cvtsd2ss %xmm7,%xmm8
  81d51e:	cvtpd2ps %xmm4,%xmm5
  81d522:	cvtps2pd %xmm5,%xmm5
  81d525:	subpd  %xmm5,%xmm4
  81d529:	cvtpd2ps %xmm4,%xmm4
  81d52d:	unpcklpd %xmm3,%xmm1
  81d531:	cvtpd2ps %xmm1,%xmm3
  81d535:	unpcklpd %xmm2,%xmm0
  81d539:	cvtpd2ps %xmm0,%xmm2
  81d53d:	cvtps2pd %xmm3,%xmm3
  81d540:	subpd  %xmm3,%xmm1
  81d544:	cvtpd2ps %xmm1,%xmm5
  81d548:	cvtps2pd %xmm2,%xmm1
  81d54b:	subpd  %xmm1,%xmm0
  81d54f:	cvtpd2ps %xmm0,%xmm6
  81d553:	movapd %xmm6,%xmm0
  81d557:	unpcklps %xmm5,%xmm0
  81d55a:	movaps %xmm8,%xmm1
  81d55e:	movlhps %xmm9,%xmm1
  81d562:	movapd %xmm4,%xmm2
  81d566:	shufps $0x24,%xmm1,%xmm2
  81d56a:	xorps  %xmm1,%xmm1
  81d56d:	movapd %xmm0,%xmm3
  81d571:	cmpneqps %xmm1,%xmm3
  81d575:	cmpneqps %xmm1,%xmm2
  81d579:	packssdw %xmm2,%xmm3
  81d57d:	pmovmskb %xmm3,%eax
  81d581:	test   %eax,%eax
  81d583:	je     81d6a7 <<gpui_gpu::renderer::RendererState>::correction+0x237>
  81d589:	movapd %xmm6,0x60(%rsp)
  81d58f:	movapd %xmm5,0x70(%rsp)
  81d595:	lea    0x8(%rsp),%r12
  81d59a:	movapd %xmm0,(%rsp)
  81d59f:	movapd %xmm4,0x80(%rsp)
  81d5a8:	movlpd %xmm4,0x10(%rsp)
  81d5ae:	movss  %xmm9,0x18(%rsp)
  81d5b5:	movss  %xmm8,0x1c(%rsp)
  81d5bc:	lea    0x300(%rbx),%r14
  81d5c3:	mov    %rsp,%rsi
  81d5c6:	mov    %r14,%rdi
  81d5c9:	movaps %xmm8,0x30(%rsp)
  81d5cf:	movaps %xmm9,0x20(%rsp)
  81d5d5:	call   821c70 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&[u32; 8]>>
  81d5da:	movapd 0x20(%rsp),%xmm6
  81d5e0:	movapd 0x30(%rsp),%xmm5
  81d5e6:	mov    %rax,%r15
  81d5e9:	shr    $0x39,%r15
  81d5ed:	mov    0x2e0(%rbx),%rcx
  81d5f4:	mov    0x2e8(%rbx),%rdx
  81d5fb:	movd   %r15d,%xmm0
  81d600:	punpcklbw %xmm0,%xmm0
  81d604:	pshuflw $0x0,%xmm0,%xmm0
  81d609:	pshufd $0x44,%xmm0,%xmm0
  81d60e:	xor    %esi,%esi
  81d610:	pcmpeqd %xmm1,%xmm1
  81d614:	mov    %rax,%rdi
  81d617:	and    %rdx,%rdi
  81d61a:	movdqu (%rcx,%rdi,1),%xmm2
  81d61f:	movdqa %xmm2,%xmm3
  81d623:	pcmpeqb %xmm0,%xmm3
  81d627:	pmovmskb %xmm3,%r8d
  81d62c:	test   %r8d,%r8d
  81d62f:	je     81d680 <<gpui_gpu::renderer::RendererState>::correction+0x210>
  81d631:	tzcnt  %r8d,%r9d
  81d636:	add    %rdi,%r9
  81d639:	and    %rdx,%r9
  81d63c:	neg    %r9
  81d63f:	lea    (%r9,%r9,8),%r9
  81d643:	movdqu -0x24(%rcx,%r9,4),%xmm3
  81d64a:	movdqu -0x14(%rcx,%r9,4),%xmm4
  81d651:	pcmpeqb 0x10(%rsp),%xmm4
  81d657:	pcmpeqb (%rsp),%xmm3
  81d65c:	pand   %xmm4,%xmm3
  81d660:	pmovmskb %xmm3,%r10d
  81d665:	cmp    $0xffff,%r10d
  81d66c:	je     81d69e <<gpui_gpu::renderer::RendererState>::correction+0x22e>
  81d66e:	lea    -0x1(%r8),%r9d
  81d672:	and    %r8w,%r9w
  81d676:	mov    %r9d,%r8d
  81d679:	jne    81d631 <<gpui_gpu::renderer::RendererState>::correction+0x1c1>
  81d67b:	nopl   0x0(%rax,%rax,1)
  81d680:	pcmpeqb %xmm1,%xmm2
  81d684:	pmovmskb %xmm2,%r8d
  81d689:	test   %r8d,%r8d
  81d68c:	jne    81d6ae <<gpui_gpu::renderer::RendererState>::correction+0x23e>
  81d68e:	add    %rsi,%rdi
  81d691:	add    $0x10,%rdi
  81d695:	add    $0x10,%rsi
  81d699:	jmp    81d617 <<gpui_gpu::renderer::RendererState>::correction+0x1a7>
  81d69e:	lea    (%rcx,%r9,4),%rdx
  81d6a2:	jmp    81d7c9 <<gpui_gpu::renderer::RendererState>::correction+0x359>
  81d6a7:	xor    %eax,%eax
  81d6a9:	jmp    81d7cc <<gpui_gpu::renderer::RendererState>::correction+0x35c>
  81d6ae:	cmpq   $0x0,0x2f0(%rbx)
  81d6b6:	je     81d7ff <<gpui_gpu::renderer::RendererState>::correction+0x38f>
  81d6bc:	mov    (%rsp),%r14
  81d6c0:	mov    0x10(%r12),%rcx
  81d6c5:	mov    %rcx,0x50(%rsp)
  81d6ca:	movups (%r12),%xmm0
  81d6cf:	movaps %xmm0,0x40(%rsp)
  81d6d4:	mov    0x58(%rbx),%r12
  81d6d8:	cmp    0x48(%rbx),%r12
  81d6dc:	jne    81d6fa <<gpui_gpu::renderer::RendererState>::correction+0x28a>
  81d6de:	lea    0x48(%rbx),%rdi
  81d6e2:	mov    %rax,%r13
  81d6e5:	call   *0x6624fd(%rip)        # e7fbe8 <_DYNAMIC+0x5b0>
  81d6eb:	movapd 0x20(%rsp),%xmm6
  81d6f1:	movapd 0x30(%rsp),%xmm5
  81d6f7:	mov    %r13,%rax
  81d6fa:	mov    0x50(%rbx),%rcx
  81d6fe:	mov    %r12,%rdx
  81d701:	shl    $0x5,%rdx
  81d705:	movaps 0x60(%rsp),%xmm0
  81d70a:	movlps %xmm0,(%rcx,%rdx,1)
  81d70e:	movaps 0x80(%rsp),%xmm0
  81d716:	movss  %xmm0,0x8(%rcx,%rdx,1)
  81d71c:	movss  %xmm6,0xc(%rcx,%rdx,1)
  81d722:	movdqa 0x70(%rsp),%xmm1
  81d728:	movq   %xmm1,0x10(%rcx,%rdx,1)
  81d72e:	shufps $0x55,%xmm0,%xmm0
  81d732:	movss  %xmm0,0x18(%rcx,%rdx,1)
  81d738:	movss  %xmm5,0x1c(%rcx,%rdx,1)
  81d73e:	lea    0x1(%r12),%rcx
  81d743:	mov    %rcx,0x58(%rbx)
  81d747:	mov    0x2e0(%rbx),%rcx
  81d74e:	mov    0x2e8(%rbx),%rdx
  81d755:	and    %rdx,%rax
  81d758:	movdqu (%rcx,%rax,1),%xmm0
  81d75d:	pmovmskb %xmm0,%esi
  81d761:	test   %esi,%esi
  81d763:	je     81d7dd <<gpui_gpu::renderer::RendererState>::correction+0x36d>
  81d765:	tzcnt  %esi,%esi
  81d769:	add    %rax,%rsi
  81d76c:	and    %rdx,%rsi
  81d76f:	movzbl (%rcx,%rsi,1),%eax
  81d773:	test   %al,%al
  81d775:	jns    81d830 <<gpui_gpu::renderer::RendererState>::correction+0x3c0>
  81d77b:	lea    -0x10(%rsi),%rdi
  81d77f:	and    %rdx,%rdi
  81d782:	mov    %r15b,(%rcx,%rsi,1)
  81d786:	mov    %r15b,0x10(%rcx,%rdi,1)
  81d78b:	neg    %rsi
  81d78e:	lea    (%rsi,%rsi,8),%rsi
  81d792:	lea    (%rcx,%rsi,4),%rdx
  81d796:	and    $0x1,%al
  81d798:	movzbl %al,%eax
  81d79b:	sub    %rax,0x2f0(%rbx)
  81d7a2:	mov    %r14,-0x24(%rcx,%rsi,4)
  81d7a7:	movdqa 0x40(%rsp),%xmm0
  81d7ad:	movdqu %xmm0,-0x1c(%rcx,%rsi,4)
  81d7b3:	mov    0x50(%rsp),%rax
  81d7b8:	mov    %rax,-0xc(%rcx,%rsi,4)
  81d7bd:	mov    %r12d,-0x4(%rcx,%rsi,4)
  81d7c2:	incq   0x2f8(%rbx)
  81d7c9:	mov    -0x4(%rdx),%eax
  81d7cc:	add    $0x90,%rsp
  81d7d3:	pop    %rbx
  81d7d4:	pop    %r12
  81d7d6:	pop    %r13
  81d7d8:	pop    %r14
  81d7da:	pop    %r15
  81d7dc:	ret
  81d7dd:	mov    $0x10,%edi
  81d7e2:	add    %rdi,%rax
  81d7e5:	and    %rdx,%rax
  81d7e8:	movdqu (%rcx,%rax,1),%xmm0
  81d7ed:	pmovmskb %xmm0,%esi
  81d7f1:	add    $0x10,%rdi
  81d7f5:	test   %esi,%esi
  81d7f7:	jne    81d765 <<gpui_gpu::renderer::RendererState>::correction+0x2f5>
  81d7fd:	jmp    81d7e2 <<gpui_gpu::renderer::RendererState>::correction+0x372>
  81d7ff:	lea    0x2e0(%rbx),%rdi
  81d806:	mov    $0x1,%esi
  81d80b:	mov    %r14,%rdx
  81d80e:	mov    $0x1,%ecx
  81d813:	mov    %rax,%r14
  81d816:	call   *0x66247c(%rip)        # e7fc98 <_DYNAMIC+0x660>
  81d81c:	movapd 0x20(%rsp),%xmm6
  81d822:	movapd 0x30(%rsp),%xmm5
  81d828:	mov    %r14,%rax
  81d82b:	jmp    81d6bc <<gpui_gpu::renderer::RendererState>::correction+0x24c>
  81d830:	movdqa (%rcx),%xmm0
  81d834:	pmovmskb %xmm0,%eax
  81d838:	tzcnt  %eax,%esi
  81d83c:	movzbl (%rcx,%rsi,1),%eax
  81d840:	jmp    81d77b <<gpui_gpu::renderer::RendererState>::correction+0x30b>

FUNCTION <gpui_gpu::renderer::RendererState>::prepare_atlas bytes=663 frame=600

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081d850 <<gpui_gpu::renderer::RendererState>::prepare_atlas>:
  81d850:	push   %rbp
  81d851:	push   %r15
  81d853:	push   %r14
  81d855:	push   %r13
  81d857:	push   %r12
  81d859:	push   %rbx
  81d85a:	sub    $0x228,%rsp
  81d861:	mov    %rsi,%r14
  81d864:	test   %r8d,%r8d
  81d867:	je     81d8fb <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xab>
  81d86d:	mov    %rdi,0x10(%rsp)
  81d872:	mov    0x110(%rcx),%rbp
  81d879:	test   %rbp,%rbp
  81d87c:	je     81d95f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x10f>
  81d882:	mov    0x108(%rcx),%r13
  81d889:	shl    $0x3,%rbp
  81d88d:	mov    %r14,0x8(%rsp)
  81d892:	lea    0x60(%r14),%rdi
  81d896:	mov    %rdx,0x18(%rsp)
  81d89b:	lea    0x8(%rdx),%rax
  81d89f:	mov    %rax,0x20(%rsp)
  81d8a4:	xor    %ebx,%ebx
  81d8a6:	lea    0x28(%rsp),%r15
  81d8ab:	xor    %r12d,%r12d
  81d8ae:	xchg   %ax,%ax
  81d8b0:	mov    0x0(%r13,%r12,1),%rax
  81d8b5:	movups 0x28(%rax),%xmm0
  81d8b9:	lea    0x38(%rsp),%rcx
  81d8be:	movups %xmm0,(%rcx)
  81d8c1:	movups 0x18(%rax),%xmm0
  81d8c5:	movups %xmm0,0x28(%rsp)
  81d8ca:	movups 0x38(%rax),%xmm0
  81d8ce:	movups %xmm0,0x48(%rsp)
  81d8d3:	mov    %rdi,%r14
  81d8d6:	mov    0x20(%rsp),%rsi
  81d8db:	mov    %r15,%rdx
  81d8de:	call   81d030 <<gpui_gpu::renderer::Atlas>::insert>
  81d8e3:	test   $0x1,%al
  81d8e5:	je     81d966 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x116>
  81d8e7:	add    %rdx,%rbx
  81d8ea:	add    $0x8,%r12
  81d8ee:	cmp    %r12,%rbp
  81d8f1:	mov    %r14,%rdi
  81d8f4:	jne    81d8b0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x60>
  81d8f6:	jmp    81da6e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d8fb:	cmpl   $0x1,0x138(%r14)
  81d903:	jne    81d915 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xc5>
  81d905:	mov    0x120(%r14),%rax
  81d90c:	add    0x118(%r14),%rax
  81d913:	je     81d94c <<gpui_gpu::renderer::RendererState>::prepare_atlas+0xfc>
  81d915:	mov    %rdi,%rbx
  81d918:	add    $0x60,%r14
  81d91c:	lea    0x58(%rsp),%rdi
  81d921:	mov    %rdx,%rsi
  81d924:	mov    $0x1,%edx
  81d929:	call   81cd60 <<gpui_gpu::renderer::Atlas>::new>
  81d92e:	mov    %r14,%rdi
  81d931:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81d936:	lea    0x58(%rsp),%rsi
  81d93b:	mov    $0xe8,%edx
  81d940:	mov    %r14,%rdi
  81d943:	call   *0x661f8f(%rip)        # e7f8d8 <memcpy@GLIBC_2.14>
  81d949:	mov    %rbx,%rdi
  81d94c:	movq   $0x0,0x8(%rdi)
  81d954:	movl   $0xffffffff,(%rdi)
  81d95a:	jmp    81da7d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81d95f:	xor    %ebx,%ebx
  81d961:	jmp    81da6e <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x21e>
  81d966:	mov    0x8(%rsp),%rax
  81d96b:	mov    0x138(%rax),%eax
  81d971:	cmp    $0x81,%eax
  81d976:	mov    $0x80,%edx
  81d97b:	cmovae %eax,%edx
  81d97e:	add    %edx,%edx
  81d980:	cmp    $0x800,%edx
  81d986:	mov    $0x800,%eax
  81d98b:	cmovae %eax,%edx
  81d98e:	lea    0x140(%rsp),%r12
  81d996:	mov    %r12,%rdi
  81d999:	mov    0x18(%rsp),%rsi
  81d99e:	mov    %edx,0x8(%rsp)
  81d9a2:	call   81cd60 <<gpui_gpu::renderer::Atlas>::new>
  81d9a7:	xor    %r15d,%r15d
  81d9aa:	nopw   0x0(%rax,%rax,1)
  81d9b0:	mov    0x0(%r13,%r15,1),%rax
  81d9b5:	movups 0x28(%rax),%xmm0
  81d9b9:	lea    0x68(%rsp),%rcx
  81d9be:	movups %xmm0,(%rcx)
  81d9c1:	movups 0x18(%rax),%xmm0
  81d9c5:	movups %xmm0,0x58(%rsp)
  81d9ca:	movups 0x38(%rax),%xmm0
  81d9ce:	movups %xmm0,0x78(%rsp)
  81d9d3:	mov    %r12,%rdi
  81d9d6:	mov    0x20(%rsp),%rsi
  81d9db:	lea    0x58(%rsp),%rdx
  81d9e0:	call   81d030 <<gpui_gpu::renderer::Atlas>::insert>
  81d9e5:	cmp    $0x1,%rax
  81d9e9:	jne    81d9f9 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1a9>
  81d9eb:	add    %rdx,%rbx
  81d9ee:	add    $0x8,%r15
  81d9f2:	cmp    %r15,%rbp
  81d9f5:	jne    81d9b0 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x160>
  81d9f7:	jmp    81da3b <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x1eb>
  81d9f9:	mov    0x8(%rsp),%r15d
  81d9fe:	cmp    $0x800,%r15d
  81da05:	je     81da8f <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x23f>
  81da0b:	mov    %r12,%rdi
  81da0e:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da13:	add    %r15d,%r15d
  81da16:	cmp    $0x800,%r15d
  81da1d:	mov    $0x800,%eax
  81da22:	cmovae %eax,%r15d
  81da26:	mov    %r12,%rdi
  81da29:	mov    0x18(%rsp),%rsi
  81da2e:	mov    %r15d,0x8(%rsp)
  81da33:	mov    %r15d,%edx
  81da36:	jmp    81d9a2 <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x152>
  81da3b:	lea    0x58(%rsp),%rdi
  81da40:	lea    0x140(%rsp),%rsi
  81da48:	mov    $0xe8,%edx
  81da4d:	call   *0x661e85(%rip)        # e7f8d8 <memcpy@GLIBC_2.14>
  81da53:	mov    %r14,%rdi
  81da56:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81da5b:	lea    0x58(%rsp),%rsi
  81da60:	mov    $0xe8,%edx
  81da65:	mov    %r14,%rdi
  81da68:	call   *0x661e6a(%rip)        # e7f8d8 <memcpy@GLIBC_2.14>
  81da6e:	mov    0x10(%rsp),%rax
  81da73:	mov    %rbx,0x8(%rax)
  81da77:	movl   $0xffffffff,(%rax)
  81da7d:	add    $0x228,%rsp
  81da84:	pop    %rbx
  81da85:	pop    %r12
  81da87:	pop    %r13
  81da89:	pop    %r14
  81da8b:	pop    %r15
  81da8d:	pop    %rbp
  81da8e:	ret
  81da8f:	mov    0x10(%rsp),%rax
  81da94:	movl   $0x7,(%rax)
  81da9a:	lea    0x140(%rsp),%rdi
  81daa2:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81daa7:	jmp    81da7d <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x22d>
  81daa9:	jmp    81daab <<gpui_gpu::renderer::RendererState>::prepare_atlas+0x25b>
  81daab:	mov    %rax,%rbx
  81daae:	lea    0x58(%rsp),%rsi
  81dab3:	mov    $0xe8,%edx
  81dab8:	mov    %r14,%rdi
  81dabb:	call   *0x661e17(%rip)        # e7f8d8 <memcpy@GLIBC_2.14>
  81dac1:	mov    %rbx,%rdi
  81dac4:	call   e2c420 <_Unwind_Resume@plt>
  81dac9:	mov    %rax,%rbx
  81dacc:	lea    0x140(%rsp),%rdi
  81dad4:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81dad9:	mov    %rbx,%rdi
  81dadc:	call   e2c420 <_Unwind_Resume@plt>
  81dae1:	call   *0x661da1(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::new bytes=1500 frame=952

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081daf0 <<gpui_gpu::renderer::RendererState>::new>:
  81daf0:	push   %r15
  81daf2:	push   %r14
  81daf4:	push   %r13
  81daf6:	push   %r12
  81daf8:	push   %rbx
  81daf9:	sub    $0x390,%rsp
  81db00:	mov    %rsi,%r14
  81db03:	mov    %rdi,%rbx
  81db06:	lea    -0x748be8(%rip),%rax        # d4f25 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.264339216088034180+0xa>
  81db0d:	mov    %rax,0xd8(%rsp)
  81db15:	movq   $0x7,0xe0(%rsp)
  81db21:	movq   $0x30,0xe8(%rsp)
  81db2d:	movl   $0x48,0xf0(%rsp)
  81db38:	movb   $0x0,0xf4(%rsp)
  81db40:	mov    0x662109(%rip),%r15        # e7fc50 <_DYNAMIC+0x618>
  81db47:	lea    0x10(%rsp),%rdi
  81db4c:	lea    0xd8(%rsp),%rdx
  81db54:	call   *%r15
  81db57:	movq   $0x30,0x30(%rsp)
  81db60:	lea    -0x748c3b(%rip),%rax        # d4f2c <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.264339216088034180+0x11>
  81db67:	mov    %rax,0xd8(%rsp)
  81db6f:	movq   $0x5,0xe0(%rsp)
  81db7b:	movq   $0x10,0xe8(%rsp)
  81db87:	movl   $0x88,0xf0(%rsp)
  81db92:	movb   $0x0,0xf4(%rsp)
  81db9a:	lea    0x38(%rsp),%rdi
  81db9f:	lea    0xd8(%rsp),%rdx
  81dba7:	mov    %r14,%rsi
  81dbaa:	call   *%r15
  81dbad:	movq   $0x10,0x58(%rsp)
  81dbb6:	lea    -0x748c8c(%rip),%rax        # d4f31 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.264339216088034180+0x16>
  81dbbd:	mov    %rax,0xd8(%rsp)
  81dbc5:	movq   $0x5,0xe0(%rsp)
  81dbd1:	movq   $0x8,0xe8(%rsp)
  81dbdd:	movl   $0x88,0xf0(%rsp)
  81dbe8:	movb   $0x0,0xf4(%rsp)
  81dbf0:	lea    0x60(%rsp),%rdi
  81dbf5:	lea    0xd8(%rsp),%rdx
  81dbfd:	mov    %r14,%rsi
  81dc00:	call   *0x66204a(%rip)        # e7fc50 <_DYNAMIC+0x618>
  81dc06:	movq   $0x8,0x80(%rsp)
  81dc12:	lea    -0x748ce3(%rip),%rax        # d4f36 <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.264339216088034180+0x1b>
  81dc19:	mov    %rax,0xd8(%rsp)
  81dc21:	movq   $0x7,0xe0(%rsp)
  81dc2d:	movq   $0x4,0xe8(%rsp)
  81dc39:	movl   $0x88,0xf0(%rsp)
  81dc44:	movb   $0x0,0xf4(%rsp)
  81dc4c:	lea    0x88(%rsp),%rdi
  81dc54:	lea    0xd8(%rsp),%rdx
  81dc5c:	mov    %r14,%rsi
  81dc5f:	call   *0x661feb(%rip)        # e7fc50 <_DYNAMIC+0x618>
  81dc65:	movq   $0x4,0xa8(%rsp)
  81dc71:	lea    -0x748d3b(%rip),%rax        # d4f3d <anon.e7af5e0dba0d7261d22cb76253955a85.27.llvm.264339216088034180+0x22>
  81dc78:	mov    %rax,0xd8(%rsp)
  81dc80:	movq   $0x11,0xe0(%rsp)
  81dc8c:	movq   $0x20,0xe8(%rsp)
  81dc98:	movl   $0x88,0xf0(%rsp)
  81dca3:	movb   $0x0,0xf4(%rsp)
  81dcab:	lea    0xb0(%rsp),%rdi
  81dcb3:	lea    0xd8(%rsp),%rdx
  81dcbb:	mov    %r14,%rsi
  81dcbe:	call   *0x661f8c(%rip)        # e7fc50 <_DYNAMIC+0x618>
  81dcc4:	movq   $0x20,0xd0(%rsp)
  81dcd0:	lea    0x2a8(%rsp),%rdi
  81dcd8:	mov    %r14,%rsi
  81dcdb:	mov    $0x1,%edx
  81dce0:	call   81cd60 <<gpui_gpu::renderer::Atlas>::new>
  81dce5:	mov    0x18(%r14),%r13
  81dce9:	lock incq 0x0(%r13)
  81dcee:	jle    81e008 <<gpui_gpu::renderer::RendererState>::new+0x518>
  81dcf4:	mov    %r13,0x8(%rsp)
  81dcf9:	mov    0x30(%rsp),%rax
  81dcfe:	mov    %rax,0x1e0(%rsp)
  81dd06:	movups 0x10(%rsp),%xmm0
  81dd0b:	movups 0x20(%rsp),%xmm1
  81dd10:	movaps %xmm1,0x1d0(%rsp)
  81dd18:	movaps %xmm0,0x1c0(%rsp)
  81dd20:	mov    0x58(%rsp),%rax
  81dd25:	mov    %rax,0x210(%rsp)
  81dd2d:	movups 0x38(%rsp),%xmm0
  81dd32:	movups 0x48(%rsp),%xmm1
  81dd37:	movaps %xmm1,0x200(%rsp)
  81dd3f:	movaps %xmm0,0x1f0(%rsp)
  81dd47:	mov    0x80(%rsp),%rax
  81dd4f:	mov    %rax,0x240(%rsp)
  81dd57:	movups 0x60(%rsp),%xmm0
  81dd5c:	movups 0x70(%rsp),%xmm1
  81dd61:	movaps %xmm1,0x230(%rsp)
  81dd69:	movaps %xmm0,0x220(%rsp)
  81dd71:	mov    0xa8(%rsp),%rax
  81dd79:	mov    %rax,0x270(%rsp)
  81dd81:	movups 0x88(%rsp),%xmm0
  81dd89:	movups 0x98(%rsp),%xmm1
  81dd91:	movaps %xmm1,0x260(%rsp)
  81dd99:	movaps %xmm0,0x250(%rsp)
  81dda1:	mov    0xd0(%rsp),%rax
  81dda9:	mov    %rax,0x2a0(%rsp)
  81ddb1:	movups 0xb0(%rsp),%xmm0
  81ddb9:	movups 0xc0(%rsp),%xmm1
  81ddc1:	movaps %xmm1,0x290(%rsp)
  81ddc9:	movaps %xmm0,0x280(%rsp)
  81ddd1:	lea    0xd8(%rsp),%rdi
  81ddd9:	lea    0x2a8(%rsp),%rsi
  81dde1:	mov    $0xe8,%edx
  81dde6:	call   *0x661aec(%rip)        # e7f8d8 <memcpy@GLIBC_2.14>
  81ddec:	mov    %fs:0x0,%rax
  81ddf5:	lea    -0x28(%rax),%rax
  81ddfc:	mov    %rax,%r12
  81ddff:	cmpb   $0x1,0x10(%rax)
  81de03:	jne    81dfe8 <<gpui_gpu::renderer::RendererState>::new+0x4f8>
  81de09:	mov    (%r12),%r14
  81de0d:	mov    0x8(%r12),%r15
  81de12:	lea    0x1(%r14),%rax
  81de16:	mov    %rax,(%r12)
  81de1a:	mov    %r13,0x210(%rbx)
  81de21:	mov    0x30(%rsp),%rax
  81de26:	mov    %rax,0x238(%rbx)
  81de2d:	movups 0x10(%rsp),%xmm0
  81de32:	movups 0x20(%rsp),%xmm1
  81de37:	movups %xmm1,0x228(%rbx)
  81de3e:	movups %xmm0,0x218(%rbx)
  81de45:	mov    0x58(%rsp),%rax
  81de4a:	mov    %rax,0x260(%rbx)
  81de51:	movups 0x38(%rsp),%xmm0
  81de56:	movups 0x48(%rsp),%xmm1
  81de5b:	movups %xmm1,0x250(%rbx)
  81de62:	movups %xmm0,0x240(%rbx)
  81de69:	mov    0x80(%rsp),%rax
  81de71:	mov    %rax,0x288(%rbx)
  81de78:	movups 0x60(%rsp),%xmm0
  81de7d:	movups 0x70(%rsp),%xmm1
  81de82:	movups %xmm1,0x278(%rbx)
  81de89:	movups %xmm0,0x268(%rbx)
  81de90:	movups 0x88(%rsp),%xmm0
  81de98:	movups 0x98(%rsp),%xmm1
  81dea0:	movups %xmm0,0x290(%rbx)
  81dea7:	movups %xmm1,0x2a0(%rbx)
  81deae:	mov    0xa8(%rsp),%rax
  81deb6:	mov    %rax,0x2b0(%rbx)
  81debd:	movups 0xb0(%rsp),%xmm0
  81dec5:	movups 0xc0(%rsp),%xmm1
  81decd:	movups %xmm0,0x2b8(%rbx)
  81ded4:	movups %xmm1,0x2c8(%rbx)
  81dedb:	mov    0xd0(%rsp),%rax
  81dee3:	mov    %rax,0x2d8(%rbx)
  81deea:	lea    0x60(%rbx),%rdi
  81deee:	lea    0x2a8(%rsp),%rsi
  81def6:	mov    $0xe8,%edx
  81defb:	call   *0x6619d7(%rip)        # e7f8d8 <memcpy@GLIBC_2.14>
  81df01:	xorps  %xmm0,%xmm0
  81df04:	movups %xmm0,0x310(%rbx)
  81df0b:	movq   $0x0,(%rbx)
  81df12:	movq   $0x4,0x8(%rbx)
  81df1a:	movups %xmm0,0x10(%rbx)
  81df1e:	movq   $0x4,0x20(%rbx)
  81df26:	movups %xmm0,0x28(%rbx)
  81df2a:	movq   $0x4,0x38(%rbx)
  81df32:	movups %xmm0,0x40(%rbx)
  81df36:	movq   $0x4,0x50(%rbx)
  81df3e:	movq   $0x0,0x58(%rbx)
  81df46:	movups 0x6102ab(%rip),%xmm1        # e2e1f8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  81df4d:	movups %xmm1,0x2e0(%rbx)
  81df54:	movups 0x6102ad(%rip),%xmm1        # e2e208 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf0>
  81df5b:	movups %xmm1,0x2f0(%rbx)
  81df62:	mov    %r14,0x300(%rbx)
  81df69:	mov    %r15,0x308(%rbx)
  81df70:	movw   $0x101,0x328(%rbx)
  81df79:	movups %xmm0,0x1f8(%rbx)
  81df80:	movups %xmm0,0x1e8(%rbx)
  81df87:	movups %xmm0,0x1d8(%rbx)
  81df8e:	movups %xmm0,0x1c8(%rbx)
  81df95:	movups %xmm0,0x1b8(%rbx)
  81df9c:	movups %xmm0,0x1a8(%rbx)
  81dfa3:	movups %xmm0,0x198(%rbx)
  81dfaa:	movups %xmm0,0x188(%rbx)
  81dfb1:	movups %xmm0,0x178(%rbx)
  81dfb8:	movups %xmm0,0x168(%rbx)
  81dfbf:	movups %xmm0,0x158(%rbx)
  81dfc6:	movups %xmm0,0x148(%rbx)
  81dfcd:	movb   $0x0,0x208(%rbx)
  81dfd4:	mov    %rbx,%rax
  81dfd7:	add    $0x390,%rsp
  81dfde:	pop    %rbx
  81dfdf:	pop    %r12
  81dfe1:	pop    %r13
  81dfe3:	pop    %r14
  81dfe5:	pop    %r15
  81dfe7:	ret
  81dfe8:	call   *0x661c6a(%rip)        # e7fc58 <_DYNAMIC+0x620>
  81dfee:	mov    %rax,%r14
  81dff1:	mov    %rdx,%r15
  81dff4:	mov    %rax,(%r12)
  81dff8:	mov    %rdx,0x8(%r12)
  81dffd:	movb   $0x1,0x10(%r12)
  81e003:	jmp    81de12 <<gpui_gpu::renderer::RendererState>::new+0x322>
  81e008:	ud2
  81e00a:	mov    %rax,%rbx
  81e00d:	lea    0xd8(%rsp),%rdi
  81e015:	call   81bb50 <core::ptr::drop_glue::<gpui_gpu::renderer::Atlas>>
  81e01a:	lea    0x280(%rsp),%rdi
  81e022:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e027:	lea    0x250(%rsp),%rdi
  81e02f:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e034:	lea    0x220(%rsp),%rdi
  81e03c:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e041:	lea    0x1f0(%rsp),%rdi
  81e049:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e04e:	lea    0x1c0(%rsp),%rdi
  81e056:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e05b:	lock decq 0x0(%r13)
  81e060:	jne    81e0be <<gpui_gpu::renderer::RendererState>::new+0x5ce>
  81e062:	lea    0x8(%rsp),%rdi
  81e067:	call   *0x661a33(%rip)        # e7faa0 <_DYNAMIC+0x468>
  81e06d:	jmp    81e0be <<gpui_gpu::renderer::RendererState>::new+0x5ce>
  81e06f:	mov    %rax,%rbx
  81e072:	lea    0xb0(%rsp),%rdi
  81e07a:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e07f:	jmp    81e084 <<gpui_gpu::renderer::RendererState>::new+0x594>
  81e081:	mov    %rax,%rbx
  81e084:	lea    0x88(%rsp),%rdi
  81e08c:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e091:	jmp    81e096 <<gpui_gpu::renderer::RendererState>::new+0x5a6>
  81e093:	mov    %rax,%rbx
  81e096:	lea    0x60(%rsp),%rdi
  81e09b:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0a0:	jmp    81e0a5 <<gpui_gpu::renderer::RendererState>::new+0x5b5>
  81e0a2:	mov    %rax,%rbx
  81e0a5:	lea    0x38(%rsp),%rdi
  81e0aa:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0af:	jmp    81e0b4 <<gpui_gpu::renderer::RendererState>::new+0x5c4>
  81e0b1:	mov    %rax,%rbx
  81e0b4:	lea    0x10(%rsp),%rdi
  81e0b9:	call   81bc30 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  81e0be:	mov    %rbx,%rdi
  81e0c1:	call   e2c420 <_Unwind_Resume@plt>
  81e0c6:	call   *0x6617bc(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9376 frame=1400

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0d0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0d0:	push   %rbp
  81e0d1:	push   %r15
  81e0d3:	push   %r14
  81e0d5:	push   %r13
  81e0d7:	push   %r12
  81e0d9:	push   %rbx
  81e0da:	sub    $0x548,%rsp
  81e0e1:	mov    0x210(%rsi),%rax
  81e0e8:	mov    0x18(%rdx),%r9
  81e0ec:	cmp    %r9,%rax
  81e0ef:	je     81e10d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0f1:	mov    0x10(%rax),%r10
  81e0f5:	cmp    0x10(%r9),%r10
  81e0f9:	jne    81e1db <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e0ff:	mov    0x18(%rax),%rax
  81e103:	cmp    0x18(%r9),%rax
  81e107:	jne    81e1db <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e10d:	lea    0x318(%rsi),%rbx
  81e114:	mov    0x318(%rsi),%rax
  81e11b:	test   %rax,%rax
  81e11e:	je     81e14d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e120:	lock decq (%rax)
  81e124:	jne    81e14d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e126:	mov    %rdi,%r14
  81e129:	mov    %rbx,%rdi
  81e12c:	mov    %rsi,%r12
  81e12f:	mov    %r8,%r13
  81e132:	mov    %rdx,%r15
  81e135:	mov    %rcx,%rbp
  81e138:	call   *0x661a12(%rip)        # e7fb50 <_DYNAMIC+0x518>
  81e13e:	mov    %rbp,%rcx
  81e141:	mov    %r15,%rdx
  81e144:	mov    %r13,%r8
  81e147:	mov    %r12,%rsi
  81e14a:	mov    %r14,%rdi
  81e14d:	movq   $0x0,0x318(%rsi)
  81e158:	mov    (%rcx),%r12d
  81e15b:	mov    0x8(%rcx),%r9d
  81e15f:	movzbl 0xd(%rcx),%eax
  81e163:	test   %r9d,%r9d
  81e166:	sets   %r10b
  81e16a:	and    $0x7fffffff,%r9d
  81e171:	lea    -0x800000(%r9),%r11d
  81e178:	cmp    $0x7f000000,%r11d
  81e17f:	setb   %r11b
  81e183:	and    %r10b,%r11b
  81e186:	lea    -0x1(%r9),%ebp
  81e18a:	cmp    $0x7fffff,%ebp
  81e190:	setb   %bpl
  81e194:	and    %r10b,%bpl
  81e197:	test   %r9d,%r9d
  81e19a:	sete   %r10b
  81e19e:	cmp    $0x7f800000,%r9d
  81e1a5:	sete   %r14b
  81e1a9:	or     %r10b,%r14b
  81e1ac:	cmp    $0x7f800001,%r9d
  81e1b3:	setge  %r9b
  81e1b7:	or     %r14b,%r9b
  81e1ba:	or     %bpl,%r9b
  81e1bd:	test   %r12d,%r12d
  81e1c0:	setne  %r10b
  81e1c4:	and    %al,%r10b
  81e1c7:	or     %r11b,%r10b
  81e1ca:	or     %r9b,%r10b
  81e1cd:	test   $0x1,%r10b
  81e1d1:	je     81e1f6 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e1d3:	movl   $0x3,(%rdi)
  81e1d9:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e1db:	movl   $0x4,(%rdi)
  81e1e1:	mov    %rdi,%rax
  81e1e4:	add    $0x548,%rsp
  81e1eb:	pop    %rbx
  81e1ec:	pop    %r12
  81e1ee:	pop    %r13
  81e1f0:	pop    %r14
  81e1f2:	pop    %r15
  81e1f4:	pop    %rbp
  81e1f5:	ret
  81e1f6:	movd   0x4(%rcx),%xmm2
  81e1fb:	movzbl 0xc(%rcx),%ebp
  81e1ff:	test   $0x1,%r12b
  81e203:	je     81e27b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e205:	movd   %xmm2,%r9d
  81e20a:	test   %r9d,%r9d
  81e20d:	sets   %r10b
  81e211:	and    $0x7fffffff,%r9d
  81e218:	lea    -0x800000(%r9),%r11d
  81e21f:	cmp    $0x7f000000,%r11d
  81e226:	setb   %r11b
  81e22a:	and    %r10b,%r11b
  81e22d:	lea    -0x1(%r9),%r14d
  81e231:	cmp    $0x7fffff,%r14d
  81e238:	setb   %r14b
  81e23c:	and    %r10b,%r14b
  81e23f:	test   %r9d,%r9d
  81e242:	sete   %r10b
  81e246:	cmp    $0x7f800000,%r9d
  81e24d:	sete   %r15b
  81e251:	or     %r10b,%r15b
  81e254:	cmp    $0x7f800001,%r9d
  81e25b:	setge  %r9b
  81e25f:	or     %r15b,%r9b
  81e262:	or     %r14b,%r9b
  81e265:	or     %r11b,%r9b
  81e268:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e26e:	ucomiss -0x76f3c9(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e275:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e27b:	mov    0x28(%rcx),%r14d
  81e27f:	cmp    %r14d,0x20(%r8)
  81e283:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e289:	mov    0x2c(%rcx),%r15d
  81e28d:	cmp    %r15d,0x24(%r8)
  81e291:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e297:	mov    0x38(%r8),%r13d
  81e29b:	cmp    0x20(%rdx),%r13d
  81e29f:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2a5:	cmp    $0x4c,%r13d
  81e2a9:	jne    81e2ce <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e2ab:	movq   0x3c(%r8),%xmm0
  81e2b1:	movq   0x24(%rdx),%xmm1
  81e2b6:	pcmpeqd %xmm0,%xmm1
  81e2ba:	pshufd $0x50,%xmm1,%xmm0
  81e2bf:	movmskpd %xmm0,%r9d
  81e2c4:	cmp    $0x3,%r9d
  81e2c8:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ce:	cmp    $0x4000,%r15d
  81e2d5:	ja     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2d7:	cmp    $0x4000,%r14d
  81e2de:	ja     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2e0:	mov    %r15,%r9
  81e2e3:	imul   %r14,%r9
  81e2e7:	add    $0xfffffffffeffffff,%r9
  81e2ee:	cmp    $0xffffffffff000000,%r9
  81e2f5:	jb     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2f7:	mov    0x10(%rcx),%r11
  81e2fb:	mov    0x80(%r11),%r10
  81e302:	cmp    $0x10000,%r10
  81e309:	jbe    81e316 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e30b:	movl   $0x6,(%rdi)
  81e311:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e316:	movd   0x18(%rcx),%xmm0
  81e31b:	movd   %xmm0,%r9d
  81e320:	and    $0x7fffffff,%r9d
  81e327:	cmp    $0x7f7fffff,%r9d
  81e32e:	jg     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e334:	pand   -0x770bbc(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e33c:	ucomiss -0x76f23f(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e343:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e349:	movd   0x1c(%rcx),%xmm0
  81e34e:	movd   %xmm0,%r9d
  81e353:	and    $0x7fffffff,%r9d
  81e35a:	cmp    $0x7f7fffff,%r9d
  81e361:	jg     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e367:	pand   -0x770bef(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e36f:	ucomiss -0x76f272(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e376:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e37c:	movd   0x20(%rcx),%xmm0
  81e381:	movd   %xmm0,%r9d
  81e386:	and    $0x7fffffff,%r9d
  81e38d:	cmp    $0x7f7fffff,%r9d
  81e394:	jg     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e39a:	pand   -0x770c22(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3a2:	ucomiss -0x76f2a5(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3a9:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3af:	movd   0x24(%rcx),%xmm0
  81e3b4:	movd   %xmm0,%r9d
  81e3b9:	and    $0x7fffffff,%r9d
  81e3c0:	cmp    $0x7f7fffff,%r9d
  81e3c7:	jg     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3cd:	movdqa -0x770c55(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3d5:	pand   %xmm0,%xmm1
  81e3d9:	ucomiss -0x76f2dc(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3e0:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3e6:	xorps  %xmm1,%xmm1
  81e3e9:	ucomiss %xmm1,%xmm0
  81e3ec:	jb     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3f2:	movss  -0x76f67a(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3fa:	ucomiss %xmm0,%xmm1
  81e3fd:	jb     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e403:	movzwl 0x30(%rcx),%r9d
  81e408:	mov    %r9w,0x10(%rsp)
  81e40e:	movzwl 0x32(%rcx),%r9d
  81e413:	mov    %r9w,0x18(%rsp)
  81e419:	cmp    $0x28,%r13d
  81e41d:	jne    81e429 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e41f:	test   $0x1,%al
  81e421:	je     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e427:	jmp    81e444 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e429:	test   $0x1,%al
  81e42b:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e431:	ucomiss -0x76f6b8(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e438:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e43e:	jp     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e444:	mov    %r11,0xc8(%rsp)
  81e44c:	mov    %r10,0xc0(%rsp)
  81e454:	movss  %xmm1,0x104(%rsp)
  81e45d:	movd   %xmm2,0x244(%rsp)
  81e466:	mov    %rdx,0x108(%rsp)
  81e46e:	mov    %r8,0x3e8(%rsp)
  81e476:	mov    %rdi,0x30(%rsp)
  81e47b:	lea    0xf(%r14),%rdx
  81e47f:	shr    $0x4,%rdx
  81e483:	lea    0xf(%r15),%eax
  81e487:	shr    $0x4,%eax
  81e48a:	lea    0x18(%rsi),%rdi
  81e48e:	movq   $0x0,0x28(%rsi)
  81e496:	mov    %rdx,0x58(%rsp)
  81e49b:	imul   %edx,%eax
  81e49e:	mov    %rdi,0x218(%rsp)
  81e4a6:	mov    %rsi,0x8(%rsp)
  81e4ab:	mov    %rax,%rsi
  81e4ae:	xor    %edx,%edx
  81e4b0:	mov    %rcx,0xe8(%rsp)
  81e4b8:	call   8227f0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e4bd:	mov    0x8(%rsp),%rax
  81e4c2:	movq   $0x0,0x10(%rax)
  81e4ca:	mov    0xe8(%rsp),%rdi
  81e4d2:	call   *0x661708(%rip)        # e7fbe0 <_DYNAMIC+0x5a8>
  81e4d8:	mov    %rdx,%rcx
  81e4db:	sub    %rax,%rcx
  81e4de:	cmp    $0x300000,%rcx
  81e4e5:	jbe    81e4f7 <<gpui_gpu::renderer::RendererState>::render+0x427>
  81e4e7:	mov    0x30(%rsp),%rdi
  81e4ec:	movl   $0x6,(%rdi)
  81e4f2:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e4f7:	mov    %rcx,%rsi
  81e4fa:	shr    $0x3,%rcx
  81e4fe:	movabs $0xaaaaaaaaaaaaaaab,%rdi
  81e508:	imul   %rcx,%rdi
  81e50c:	mov    %rdi,0x38(%rsp)
  81e511:	mov    %rax,0x380(%rsp)
  81e519:	mov    %rdx,0x378(%rsp)
  81e521:	cmp    %rax,%rdx
  81e524:	je     81e552 <<gpui_gpu::renderer::RendererState>::render+0x482>
  81e526:	mov    $0xaaaaaaab,%eax
  81e52b:	imul   %rax,%rsi
  81e52f:	shr    $0x2a,%rsi
  81e533:	mov    0x38(%rsp),%rcx
  81e538:	mov    %ecx,%eax
  81e53a:	and    $0x3f,%eax
  81e53d:	add    %rcx,%rsi
  81e540:	cmp    $0x1,%rax
  81e544:	sbb    $0xffffffffffffffff,%rsi
  81e548:	inc    %rsi
  81e54b:	mov    %rsi,0x50(%rsp)
  81e550:	jmp    81e55b <<gpui_gpu::renderer::RendererState>::render+0x48b>
  81e552:	movq   $0x0,0x50(%rsp)
  81e55b:	mov    0xc8(%rsp),%rax
  81e563:	mov    0x98(%rax),%rcx
  81e56a:	add    0xb0(%rax),%rcx
  81e571:	mov    %rax,0x110(%rsp)
  81e579:	movzwl 0x10(%rsp),%eax
  81e57e:	mov    %ax,0x130(%rsp)
  81e586:	movzwl 0x18(%rsp),%eax
  81e58b:	mov    %ax,0x132(%rsp)
  81e593:	movq   $0x0,0x118(%rsp)
  81e59f:	mov    0xc0(%rsp),%rax
  81e5a7:	mov    %rax,0x120(%rsp)
  81e5af:	mov    %rcx,0x210(%rsp)
  81e5b7:	mov    %rcx,0x128(%rsp)
  81e5bf:	mov    0x8(%rsp),%rax
  81e5c4:	movzbl 0x329(%rax),%edx
  81e5cb:	lea    0x428(%rsp),%rdi
  81e5d3:	lea    0x110(%rsp),%rsi
  81e5db:	call   81c840 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e5e0:	mov    0x428(%rsp),%eax
  81e5e7:	cmp    $0xffffffff,%eax
  81e5ea:	je     81e61a <<gpui_gpu::renderer::RendererState>::render+0x54a>
  81e5ec:	mov    0x42c(%rsp),%ecx
  81e5f3:	mov    0x430(%rsp),%rdx
  81e5fb:	movups 0x438(%rsp),%xmm0
  81e603:	mov    0x30(%rsp),%rdi
  81e608:	movups %xmm0,0x10(%rdi)
  81e60c:	mov    %eax,(%rdi)
  81e60e:	mov    %ecx,0x4(%rdi)
  81e611:	mov    %rdx,0x8(%rdi)
  81e615:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e61a:	mov    0x430(%rsp),%rdx
  81e622:	add    0x50(%rsp),%rdx
  81e627:	mov    0x8(%rsp),%rdi
  81e62c:	mov    0x10(%rdi),%rsi
  81e630:	mov    $0x4,%ecx
  81e635:	mov    $0x10,%r8d
  81e63b:	call   823bb0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e640:	cmp    $0xffffffffffffffff,%rax
  81e644:	jne    81e4e7 <<gpui_gpu::renderer::RendererState>::render+0x417>
  81e64a:	movzwl 0x10(%rsp),%eax
  81e64f:	mov    %eax,0x10(%rsp)
  81e653:	movzwl 0x18(%rsp),%eax
  81e658:	mov    %eax,0x78(%rsp)
  81e65c:	mov    0x8(%rsp),%rdi
  81e661:	mov    0xe8(%rsp),%rsi
  81e669:	mov    0x38(%rsp),%rdx
  81e66e:	call   825b10 <gpui_gpu::renderer::slots::write_prefix>
  81e673:	mov    0x8(%rsp),%rax
  81e678:	movq   $0x0,0x58(%rax)
  81e680:	cmpq   $0x0,0x48(%rax)
  81e685:	jne    81e696 <<gpui_gpu::renderer::RendererState>::render+0x5c6>
  81e687:	mov    0x8(%rsp),%rax
  81e68c:	lea    0x48(%rax),%rdi
  81e690:	call   *0x661552(%rip)        # e7fbe8 <_DYNAMIC+0x5b0>
  81e696:	mov    0x8(%rsp),%rax
  81e69b:	mov    0x50(%rax),%rcx
  81e69f:	xorps  %xmm0,%xmm0
  81e6a2:	movups %xmm0,0x10(%rcx)
  81e6a6:	movups %xmm0,(%rcx)
  81e6a9:	movq   $0x1,0x58(%rax)
  81e6b1:	lea    0x2e0(%rax),%rdi
  81e6b8:	call   8254c0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e6bd:	mov    0x78(%rsp),%ecx
  81e6c1:	shl    $0x10,%ecx
  81e6c4:	add    0x10(%rsp),%ecx
  81e6c8:	mov    0xc8(%rsp),%rax
  81e6d0:	mov    %rax,0x388(%rsp)
  81e6d8:	movq   $0x0,0x390(%rsp)
  81e6e4:	mov    0xc0(%rsp),%rax
  81e6ec:	mov    %rax,0x398(%rsp)
  81e6f4:	mov    0x210(%rsp),%rax
  81e6fc:	mov    %rax,0x3a0(%rsp)
  81e704:	mov    %ecx,0x78(%rsp)
  81e708:	mov    %ecx,0x3a8(%rsp)
  81e70f:	lea    0x248(%rsp),%rdi
  81e717:	lea    0x388(%rsp),%rsi
  81e71f:	call   *0x6614cb(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81e725:	mov    0x248(%rsp),%rax
  81e72d:	mov    %rax,0x18(%rsp)
  81e732:	test   %rax,%rax
  81e735:	je     81f499 <<gpui_gpu::renderer::RendererState>::render+0x13c9>
  81e73b:	movq   $0x0,0xe0(%rsp)
  81e747:	movq   $0x0,0x10(%rsp)
  81e750:	movq   $0x0,0xb8(%rsp)
  81e75c:	movq   $0x0,0x200(%rsp)
  81e768:	movq   $0x0,0x208(%rsp)
  81e774:	mov    0x250(%rsp),%rcx
  81e77c:	mov    0x258(%rsp),%rdx
  81e784:	mov    %rdx,0xa0(%rsp)
  81e78c:	lea    0x260(%rsp),%rdi
  81e794:	movups (%rdi),%xmm0
  81e797:	movups 0x10(%rdi),%xmm1
  81e79b:	movups 0x20(%rdi),%xmm2
  81e79f:	movaps %xmm2,0x2f0(%rsp)
  81e7a7:	movaps %xmm1,0x2e0(%rsp)
  81e7af:	movaps %xmm0,0x2d0(%rsp)
  81e7b7:	lea    0x290(%rsp),%r8
  81e7bf:	movups (%r8),%xmm0
  81e7c3:	movaps %xmm0,0x4f0(%rsp)
  81e7cb:	movups 0x40(%rdi),%xmm0
  81e7cf:	movaps %xmm0,0x3f0(%rsp)
  81e7d7:	mov    0x8(%rsp),%rax
  81e7dc:	movzbl 0x329(%rax),%esi
  81e7e3:	mov    0x18(%rsp),%rax
  81e7e8:	mov    %rax,0x110(%rsp)
  81e7f0:	mov    %rcx,0x28(%rsp)
  81e7f5:	mov    %rcx,0x118(%rsp)
  81e7fd:	mov    %rdx,0x120(%rsp)
  81e805:	movups (%rdi),%xmm0
  81e808:	movups 0x10(%rdi),%xmm1
  81e80c:	movups 0x20(%rdi),%xmm2
  81e810:	lea    0x128(%rsp),%rax
  81e818:	movups %xmm2,0x20(%rax)
  81e81c:	movups %xmm1,0x10(%rax)
  81e820:	movups %xmm0,(%rax)
  81e823:	movups (%r8),%xmm0
  81e827:	movups %xmm0,0x30(%rax)
  81e82b:	movups 0x40(%rdi),%xmm0
  81e82f:	movups %xmm0,0x40(%rax)
  81e833:	lea    0x110(%rsp),%rdi
  81e83b:	call   821550 <gpui_gpu::renderer::compact_group>
  81e840:	mov    %al,0x40(%rsp)
  81e844:	lea    0x260(%rsp),%rsi
  81e84c:	movups (%rsi),%xmm0
  81e84f:	movups 0x10(%rsi),%xmm1
  81e853:	movups 0x20(%rsi),%xmm2
  81e857:	movaps %xmm0,0x500(%rsp)
  81e85f:	movaps %xmm1,0x510(%rsp)
  81e867:	movaps %xmm2,0x520(%rsp)
  81e86f:	lea    0x290(%rsp),%rdx
  81e877:	movups (%rdx),%xmm0
  81e87a:	movaps %xmm0,0x530(%rsp)
  81e882:	mov    0x8(%rsp),%rdi
  81e887:	call   81d470 <<gpui_gpu::renderer::RendererState>::correction>
  81e88c:	mov    %eax,0x7c(%rsp)
  81e890:	mov    0xa0(%rsp),%rax
  81e898:	lea    0x0(,%rax,4),%rax
  81e8a0:	mov    %rax,0x370(%rsp)
  81e8a8:	cmpb   $0x0,0x40(%rsp)
  81e8ad:	je     81ea8b <<gpui_gpu::renderer::RendererState>::render+0x9bb>
  81e8b3:	mov    0x28(%rsp),%rcx
  81e8b8:	mov    0xa0(%rsp),%rax
  81e8c0:	lea    (%rcx,%rax,4),%rax
  81e8c4:	mov    %rcx,0x408(%rsp)
  81e8cc:	mov    %rax,0x410(%rsp)
  81e8d4:	mov    0x18(%rsp),%rax
  81e8d9:	mov    %rax,0x418(%rsp)
  81e8e1:	movq   $0x0,0x420(%rsp)
  81e8ed:	lea    0x300(%rsp),%rdi
  81e8f5:	lea    0x408(%rsp),%rsi
  81e8fd:	call   821be0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e902:	cmpb   $0xff,0x308(%rsp)
  81e90a:	je     81efca <<gpui_gpu::renderer::RendererState>::render+0xefa>
  81e910:	xorps  %xmm0,%xmm0
  81e913:	movaps %xmm0,0x80(%rsp)
  81e91b:	movaps %xmm0,0x60(%rsp)
  81e920:	mov    0x300(%rsp),%rdx
  81e928:	add    0xb8(%rsp),%rdx
  81e930:	lea    0x308(%rsp),%rsi
  81e938:	movups 0x38(%rsi),%xmm0
  81e93c:	lea    0x128(%rsp),%rcx
  81e944:	movups %xmm0,0x20(%rcx)
  81e948:	movups 0x48(%rsi),%xmm0
  81e94c:	movups %xmm0,0x70(%rcx)
  81e950:	mov    0x30(%rsi),%rax
  81e954:	mov    %rax,0x140(%rsp)
  81e95c:	movups (%rsi),%xmm0
  81e95f:	movups 0x10(%rsi),%xmm1
  81e963:	movups 0x20(%rsi),%xmm2
  81e967:	movaps %xmm2,0x130(%rsp)
  81e96f:	movaps %xmm1,0x120(%rsp)
  81e977:	movaps %xmm0,0x110(%rsp)
  81e97f:	lea    0x260(%rsp),%rax
  81e987:	movups 0x40(%rax),%xmm0
  81e98b:	movups %xmm0,0x80(%rcx)
  81e992:	movups (%rax),%xmm0
  81e995:	movups 0x10(%rax),%xmm1
  81e999:	movups 0x20(%rax),%xmm2
  81e99d:	movups %xmm2,0x50(%rcx)
  81e9a1:	movups %xmm1,0x40(%rcx)
  81e9a5:	movups %xmm0,0x30(%rcx)
  81e9a9:	lea    0x290(%rsp),%rax
  81e9b1:	movups (%rax),%xmm0
  81e9b4:	movups %xmm0,0x60(%rcx)
  81e9b8:	lea    0x220(%rsp),%rdi
  81e9c0:	lea    0x110(%rsp),%rsi
  81e9c8:	mov    %r14d,%ecx
  81e9cb:	mov    %r15d,%r8d
  81e9ce:	call   8215a0 <gpui_gpu::renderer::validate_draw>
  81e9d3:	mov    0x220(%rsp),%ecx
  81e9da:	mov    0x224(%rsp),%rax
  81e9e2:	cmp    $0xffffffff,%ecx
  81e9e5:	jne    81f554 <<gpui_gpu::renderer::RendererState>::render+0x1484>
  81e9eb:	mov    %eax,%ecx
  81e9ed:	shr    $0x20,%rax
  81e9f1:	movd   %ecx,%xmm0
  81e9f5:	movaps 0x80(%rsp),%xmm2
  81e9fd:	movaps %xmm2,%xmm1
  81ea00:	maxss  %xmm0,%xmm1
  81ea04:	movaps %xmm1,%xmm3
  81ea07:	cmpunordss %xmm1,%xmm3
  81ea0c:	movaps %xmm3,%xmm0
  81ea0f:	andnps %xmm1,%xmm0
  81ea12:	andps  %xmm2,%xmm3
  81ea15:	orps   %xmm0,%xmm3
  81ea18:	movaps %xmm3,0x40(%rsp)
  81ea1d:	movd   %eax,%xmm0
  81ea21:	movaps 0x60(%rsp),%xmm2
  81ea26:	movaps %xmm2,%xmm1
  81ea29:	maxss  %xmm0,%xmm1
  81ea2d:	movaps %xmm1,%xmm3
  81ea30:	cmpunordss %xmm1,%xmm3
  81ea35:	movaps %xmm3,%xmm0
  81ea38:	andnps %xmm1,%xmm0
  81ea3b:	andps  %xmm2,%xmm3
  81ea3e:	orps   %xmm0,%xmm3
  81ea41:	movaps %xmm3,0x90(%rsp)
  81ea49:	lea    0x300(%rsp),%rdi
  81ea51:	lea    0x408(%rsp),%rsi
  81ea59:	call   821be0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea5e:	cmpb   $0xff,0x308(%rsp)
  81ea66:	movaps 0x40(%rsp),%xmm0
  81ea6b:	movaps %xmm0,0x80(%rsp)
  81ea73:	movaps 0x90(%rsp),%xmm0
  81ea7b:	movaps %xmm0,0x60(%rsp)
  81ea80:	jne    81e920 <<gpui_gpu::renderer::RendererState>::render+0x850>
  81ea86:	jmp    81efda <<gpui_gpu::renderer::RendererState>::render+0xf0a>
  81ea8b:	cmpq   $0x0,0xa0(%rsp)
  81ea94:	je     81f443 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81ea9a:	mov    0x7c(%rsp),%eax
  81ea9e:	or     $0x80000000,%eax
  81eaa3:	mov    %eax,0x240(%rsp)
  81eaaa:	movq   $0x0,0x90(%rsp)
  81eab6:	mov    0x28(%rsp),%rax
  81eabb:	mov    0x90(%rsp),%rcx
  81eac3:	mov    (%rax,%rcx,1),%edx
  81eac6:	lea    0x110(%rsp),%rdi
  81eace:	mov    0x18(%rsp),%rsi
  81ead3:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81ead8:	movzbl 0x110(%rsp),%edi
  81eae0:	lea    0x111(%rsp),%rdx
  81eae8:	mov    (%rdx),%eax
  81eaea:	mov    0x3(%rdx),%ecx
  81eaed:	lea    0x460(%rsp),%rsi
  81eaf5:	mov    %ecx,-0x34(%rsi)
  81eaf8:	mov    %eax,-0x37(%rsi)
  81eafb:	mov    0x118(%rsp),%rcx
  81eb03:	mov    0x2f(%rdx),%rax
  81eb07:	mov    %rax,-0x8(%rsi)
  81eb0b:	movups 0xf(%rdx),%xmm0
  81eb0f:	movups 0x1f(%rdx),%xmm1
  81eb13:	movups %xmm1,-0x18(%rsi)
  81eb17:	movups %xmm0,-0x28(%rsi)
  81eb1b:	lea    0x128(%rsp),%rax
  81eb23:	movups 0x20(%rax),%xmm0
  81eb27:	movups %xmm0,(%rsi)
  81eb2a:	movups 0x30(%rax),%xmm0
  81eb2e:	movups %xmm0,0x50(%rsi)
  81eb32:	lea    0x260(%rsp),%rax
  81eb3a:	movups 0x40(%rax),%xmm0
  81eb3e:	movups %xmm0,0x60(%rsi)
  81eb42:	movups (%rax),%xmm0
  81eb45:	movups 0x10(%rax),%xmm1
  81eb49:	movups 0x20(%rax),%xmm2
  81eb4d:	movups %xmm2,0x30(%rsi)
  81eb51:	movups %xmm1,0x20(%rsi)
  81eb55:	movups %xmm0,0x10(%rsi)
  81eb59:	lea    0x290(%rsp),%rax
  81eb61:	movups (%rax),%xmm0
  81eb64:	movups %xmm0,0x40(%rsi)
  81eb68:	mov    %dil,0x60(%rsp)
  81eb6d:	mov    %dil,0x428(%rsp)
  81eb75:	mov    %rcx,0x80(%rsp)
  81eb7d:	mov    %rcx,0x430(%rsp)
  81eb85:	lea    0x110(%rsp),%rdi
  81eb8d:	lea    0x428(%rsp),%rsi
  81eb95:	mov    0xb8(%rsp),%rdx
  81eb9d:	mov    %r14d,%ecx
  81eba0:	mov    %r15d,%r8d
  81eba3:	call   8215a0 <gpui_gpu::renderer::validate_draw>
  81eba8:	mov    0x110(%rsp),%eax
  81ebaf:	mov    0x114(%rsp),%rcx
  81ebb7:	mov    %rcx,0x40(%rsp)
  81ebbc:	cmp    $0xffffffff,%eax
  81ebbf:	jne    81f5ea <<gpui_gpu::renderer::RendererState>::render+0x151a>
  81ebc5:	movzbl 0x60(%rsp),%eax
  81ebca:	cmp    $0x2,%al
  81ebcc:	sete   0x27(%rsp)
  81ebd1:	cmpq   $0x0,0x80(%rsp)
  81ebda:	setne  0x26(%rsp)
  81ebdf:	movups 0x460(%rsp),%xmm0
  81ebe7:	movaps %xmm0,0x2c0(%rsp)
  81ebef:	cmp    $0x3,%al
  81ebf1:	jne    81ec83 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ebf7:	movss  0x42c(%rsp),%xmm0
  81ec00:	xorps  %xmm1,%xmm1
  81ec03:	ucomiss %xmm1,%xmm0
  81ec06:	jne    81ec0a <<gpui_gpu::renderer::RendererState>::render+0xb3a>
  81ec08:	jnp    81ec83 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ec0a:	movaps 0x2c0(%rsp),%xmm5
  81ec12:	movaps %xmm5,%xmm1
  81ec15:	unpckhpd %xmm5,%xmm1
  81ec19:	movss  -0x76fcb5(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ec21:	mulss  %xmm4,%xmm1
  81ec25:	movaps %xmm0,%xmm2
  81ec28:	minss  %xmm1,%xmm2
  81ec2c:	movaps %xmm2,%xmm1
  81ec2f:	cmpunordss %xmm2,%xmm1
  81ec34:	movaps %xmm1,%xmm3
  81ec37:	andnps %xmm2,%xmm3
  81ec3a:	andps  %xmm0,%xmm1
  81ec3d:	orps   %xmm3,%xmm1
  81ec40:	movaps %xmm5,%xmm0
  81ec43:	shufps $0xff,%xmm5,%xmm0
  81ec47:	mulss  %xmm4,%xmm0
  81ec4b:	movaps %xmm1,%xmm2
  81ec4e:	minss  %xmm0,%xmm2
  81ec52:	movaps %xmm2,%xmm0
  81ec55:	cmpunordss %xmm2,%xmm0
  81ec5a:	andps  %xmm0,%xmm1
  81ec5d:	andnps %xmm2,%xmm0
  81ec60:	orps   %xmm1,%xmm0
  81ec63:	movd   %xmm0,%eax
  81ec67:	mov    %eax,0x60(%rsp)
  81ec6b:	and    $0xff800000,%eax
  81ec70:	mov    $0x7f000000,%ecx
  81ec75:	sub    %eax,%ecx
  81ec77:	mov    %ecx,0x80(%rsp)
  81ec7e:	xorps  %xmm0,%xmm0
  81ec81:	jmp    81eca5 <<gpui_gpu::renderer::RendererState>::render+0xbd5>
  81ec83:	mov    0x4c0(%rsp),%eax
  81ec8a:	mov    %eax,0x60(%rsp)
  81ec8e:	mov    0x4c4(%rsp),%eax
  81ec95:	mov    %eax,0x80(%rsp)
  81ec9c:	movsd  0x4c8(%rsp),%xmm0
  81eca5:	movaps %xmm0,0xd0(%rsp)
  81ecad:	mov    0x8(%rsp),%rax
  81ecb2:	mov    0x10(%rax),%ecx
  81ecb5:	mov    $0x80000000,%eax
  81ecba:	or     %eax,%ecx
  81ecbc:	mov    %ecx,0x360(%rsp)
  81ecc3:	movups 0x470(%rsp),%xmm0
  81eccb:	movaps %xmm0,0x3c0(%rsp)
  81ecd3:	movups 0x478(%rsp),%xmm0
  81ecdb:	movaps %xmm0,0x4e0(%rsp)
  81ece3:	movsd  0x480(%rsp),%xmm0
  81ecec:	movaps %xmm0,0x3b0(%rsp)
  81ecf4:	movsd  0x488(%rsp),%xmm0
  81ecfd:	movaps %xmm0,0x4d0(%rsp)
  81ed05:	movsd  0x490(%rsp),%xmm0
  81ed0e:	movsd  %xmm0,0x3e0(%rsp)
  81ed17:	movsd  0x498(%rsp),%xmm0
  81ed20:	movsd  %xmm0,0x3d8(%rsp)
  81ed29:	movups 0x4a0(%rsp),%xmm0
  81ed31:	movaps %xmm0,0x2b0(%rsp)
  81ed39:	mov    0x18(%rsp),%rax
  81ed3e:	mov    %rax,0x110(%rsp)
  81ed46:	mov    0x28(%rsp),%rax
  81ed4b:	mov    %rax,0x118(%rsp)
  81ed53:	mov    0xa0(%rsp),%rax
  81ed5b:	mov    %rax,0x120(%rsp)
  81ed63:	movaps 0x2d0(%rsp),%xmm0
  81ed6b:	movaps 0x2e0(%rsp),%xmm1
  81ed73:	movaps 0x2f0(%rsp),%xmm2
  81ed7b:	lea    0x128(%rsp),%rax
  81ed83:	movups %xmm2,0x20(%rax)
  81ed87:	movups %xmm1,0x10(%rax)
  81ed8b:	movups %xmm0,(%rax)
  81ed8e:	movaps 0x4f0(%rsp),%xmm0
  81ed96:	movups %xmm0,0x30(%rax)
  81ed9a:	movaps 0x3f0(%rsp),%xmm0
  81eda2:	movups %xmm0,0x40(%rax)
  81eda6:	lea    0x110(%rsp),%rdi
  81edae:	call   *0x660e44(%rip)        # e7fbf8 <_DYNAMIC+0x5c0>
  81edb4:	mov    0x7c(%rsp),%ecx
  81edb8:	mov    %ecx,0xf0(%rsp)
  81edbf:	test   %eax,%eax
  81edc1:	je     81edf7 <<gpui_gpu::renderer::RendererState>::render+0xd27>
  81edc3:	mov    0x38(%rsp),%rdi
  81edc8:	mov    %eax,%esi
  81edca:	call   825ad0 <gpui_gpu::renderer::slots::color_word>
  81edcf:	mov    %eax,0x60(%rsp)
  81edd3:	xorps  %xmm0,%xmm0
  81edd6:	movaps %xmm0,0xd0(%rsp)
  81edde:	movl   $0x0,0x80(%rsp)
  81ede9:	mov    0x240(%rsp),%eax
  81edf0:	mov    %eax,0xf0(%rsp)
  81edf7:	mov    0x40(%rsp),%rax
  81edfc:	shr    $0x20,%rax
  81ee00:	mov    %rax,0x3d0(%rsp)
  81ee08:	mov    0x8(%rsp),%rax
  81ee0d:	mov    (%rax),%rcx
  81ee10:	mov    0x10(%rax),%rsi
  81ee14:	sub    %rsi,%rcx
  81ee17:	cmp    $0x5,%rcx
  81ee1b:	jbe    81efa2 <<gpui_gpu::renderer::RendererState>::render+0xed2>
  81ee21:	movsd  0x3d8(%rsp),%xmm0
  81ee2a:	cvtsd2ss %xmm0,%xmm0
  81ee2e:	movsd  0x3e0(%rsp),%xmm1
  81ee37:	cvtsd2ss %xmm1,%xmm1
  81ee3b:	movapd 0x4e0(%rsp),%xmm2
  81ee44:	unpcklpd 0x4d0(%rsp),%xmm2
  81ee4d:	cvtpd2ps %xmm2,%xmm2
  81ee51:	movapd 0x3c0(%rsp),%xmm3
  81ee5a:	unpcklpd 0x3b0(%rsp),%xmm3
  81ee63:	cvtpd2ps %xmm3,%xmm3
  81ee67:	mov    0x8(%rsp),%rax
  81ee6c:	mov    0x8(%rax),%rdx
  81ee70:	shl    $0x4,%rsi
  81ee74:	movaps 0x2c0(%rsp),%xmm4
  81ee7c:	movups %xmm4,(%rdx,%rsi,1)
  81ee80:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ee86:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ee8c:	mov    0x40(%rsp),%rcx
  81ee91:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ee95:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ee9b:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81eea1:	mov    0x3d0(%rsp),%rdi
  81eea9:	mov    %edi,0x2c(%rdx,%rsi,1)
  81eead:	movaps 0x2b0(%rsp),%xmm0
  81eeb5:	movups %xmm0,0x30(%rdx,%rsi,1)
  81eeba:	mov    0x60(%rsp),%edi
  81eebe:	mov    %edi,0x40(%rdx,%rsi,1)
  81eec2:	mov    0x80(%rsp),%edi
  81eec9:	mov    %edi,0x44(%rdx,%rsi,1)
  81eecd:	movaps 0xd0(%rsp),%xmm0
  81eed5:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81eeda:	movq   $0x0,0x50(%rdx,%rsi,1)
  81eee3:	movl   $0x0,0x58(%rdx,%rsi,1)
  81eeeb:	mov    0xf0(%rsp),%edi
  81eef2:	mov    %edi,0x5c(%rdx,%rsi,1)
  81eef6:	addq   $0x6,0x10(%rax)
  81eefb:	sub    $0x8,%rsp
  81eeff:	lea    0x118(%rsp),%rdi
  81ef07:	mov    %rax,%rsi
  81ef0a:	lea    0x430(%rsp),%rdx
  81ef12:	mov    0x368(%rsp),%r8d
  81ef1a:	mov    0x60(%rsp),%r9
  81ef1f:	push   0xe8(%rsp)
  81ef26:	push   %r15
  81ef28:	push   %r14
  81ef2a:	call   820570 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ef2f:	add    $0x20,%rsp
  81ef33:	mov    0x110(%rsp),%eax
  81ef3a:	cmp    $0xffffffff,%eax
  81ef3d:	jne    81f5b2 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  81ef43:	movzbl 0x27(%rsp),%ecx
  81ef48:	and    0x26(%rsp),%cl
  81ef4c:	mov    0x10(%rsp),%rax
  81ef51:	or     %cl,%al
  81ef53:	mov    %rax,0x10(%rsp)
  81ef58:	mov    0x118(%rsp),%rax
  81ef60:	mov    %rax,0xe0(%rsp)
  81ef68:	incq   0xb8(%rsp)
  81ef70:	mov    0x90(%rsp),%rdx
  81ef78:	add    $0x4,%rdx
  81ef7c:	mov    0xa0(%rsp),%rax
  81ef84:	lea    0x0(,%rax,4),%rax
  81ef8c:	mov    %rdx,0x90(%rsp)
  81ef94:	cmp    %rdx,%rax
  81ef97:	jne    81eab6 <<gpui_gpu::renderer::RendererState>::render+0x9e6>
  81ef9d:	jmp    81f437 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81efa2:	mov    $0x6,%edx
  81efa7:	mov    $0x4,%ecx
  81efac:	mov    $0x10,%r8d
  81efb2:	mov    0x8(%rsp),%rdi
  81efb7:	call   823b20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81efbc:	mov    0x8(%rsp),%rax
  81efc1:	mov    0x10(%rax),%rsi
  81efc5:	jmp    81ee21 <<gpui_gpu::renderer::RendererState>::render+0xd51>
  81efca:	xorps  %xmm0,%xmm0
  81efcd:	movaps %xmm0,0x90(%rsp)
  81efd5:	movaps %xmm0,0x40(%rsp)
  81efda:	mov    0x8(%rsp),%rax
  81efdf:	mov    0x10(%rax),%eax
  81efe2:	mov    %eax,0xd0(%rsp)
  81efe9:	movups 0x260(%rsp),%xmm1
  81eff1:	movups 0x268(%rsp),%xmm2
  81eff9:	movsd  0x280(%rsp),%xmm0
  81f002:	movsd  %xmm0,0xf0(%rsp)
  81f00b:	movsd  0x288(%rsp),%xmm0
  81f014:	movsd  %xmm0,0x2c0(%rsp)
  81f01d:	movups 0x290(%rsp),%xmm0
  81f025:	movaps %xmm0,0x80(%rsp)
  81f02d:	movhps 0x270(%rsp),%xmm1
  81f035:	movaps %xmm1,0x360(%rsp)
  81f03d:	movups 0x2a0(%rsp),%xmm0
  81f045:	movaps %xmm0,0x60(%rsp)
  81f04a:	movhps 0x278(%rsp),%xmm2
  81f052:	movaps %xmm2,0x2b0(%rsp)
  81f05a:	mov    0x18(%rsp),%rax
  81f05f:	mov    %rax,0x110(%rsp)
  81f067:	mov    0x28(%rsp),%rax
  81f06c:	mov    %rax,0x118(%rsp)
  81f074:	mov    0xa0(%rsp),%rax
  81f07c:	mov    %rax,0x120(%rsp)
  81f084:	lea    0x260(%rsp),%rax
  81f08c:	movups (%rax),%xmm0
  81f08f:	movups 0x10(%rax),%xmm1
  81f093:	movups 0x20(%rax),%xmm2
  81f097:	lea    0x128(%rsp),%rdx
  81f09f:	movups %xmm2,0x20(%rdx)
  81f0a3:	movups %xmm1,0x10(%rdx)
  81f0a7:	movups %xmm0,(%rdx)
  81f0aa:	lea    0x290(%rsp),%rcx
  81f0b2:	movups (%rcx),%xmm0
  81f0b5:	movups %xmm0,0x30(%rdx)
  81f0b9:	movdqu 0x40(%rax),%xmm0
  81f0be:	movdqu %xmm0,0x40(%rdx)
  81f0c3:	lea    0x110(%rsp),%rdi
  81f0cb:	call   *0x660b27(%rip)        # e7fbf8 <_DYNAMIC+0x5c0>
  81f0d1:	test   %eax,%eax
  81f0d3:	je     81f0f3 <<gpui_gpu::renderer::RendererState>::render+0x1023>
  81f0d5:	mov    0x38(%rsp),%rdi
  81f0da:	mov    %eax,%esi
  81f0dc:	call   825ad0 <gpui_gpu::renderer::slots::color_word>
  81f0e1:	orl    $0x80000000,0x7c(%rsp)
  81f0e9:	movd   %eax,%xmm0
  81f0ed:	movdqa %xmm0,0x60(%rsp)
  81f0f3:	mov    0x8(%rsp),%rax
  81f0f8:	mov    (%rax),%rcx
  81f0fb:	mov    0x10(%rax),%rsi
  81f0ff:	sub    %rsi,%rcx
  81f102:	cmp    $0x4,%rcx
  81f106:	jbe    81f471 <<gpui_gpu::renderer::RendererState>::render+0x13a1>
  81f10c:	cvtpd2ps 0x360(%rsp),%xmm0
  81f115:	cvtpd2ps 0x2b0(%rsp),%xmm1
  81f11e:	movsd  0xf0(%rsp),%xmm2
  81f127:	cvtsd2ss %xmm2,%xmm2
  81f12b:	movsd  0x2c0(%rsp),%xmm3
  81f134:	cvtsd2ss %xmm3,%xmm3
  81f138:	mov    0x8(%rsp),%rax
  81f13d:	mov    0x8(%rax),%rcx
  81f141:	shl    $0x4,%rsi
  81f145:	movlpd %xmm0,(%rcx,%rsi,1)
  81f14a:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f150:	movaps 0x40(%rsp),%xmm0
  81f155:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f15b:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f161:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f167:	movaps 0x90(%rsp),%xmm0
  81f16f:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f175:	movaps 0x80(%rsp),%xmm0
  81f17d:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f182:	movaps 0x60(%rsp),%xmm0
  81f187:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f18c:	mov    0x7c(%rsp),%edx
  81f190:	mov    %edx,0x40(%rcx,%rsi,1)
  81f194:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f19d:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f1a5:	addq   $0x5,0x10(%rax)
  81f1aa:	incq   0x200(%rsp)
  81f1b2:	mov    0xa0(%rsp),%rax
  81f1ba:	add    %rax,0x208(%rsp)
  81f1c2:	test   %rax,%rax
  81f1c5:	je     81f443 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81f1cb:	movdqa 0x40(%rsp),%xmm0
  81f1d1:	movd   %xmm0,%ecx
  81f1d5:	movdqa 0x90(%rsp),%xmm0
  81f1de:	movd   %xmm0,%eax
  81f1e2:	shl    $0x20,%rax
  81f1e6:	or     %rax,%rcx
  81f1e9:	mov    %rcx,0xf0(%rsp)
  81f1f1:	mov    0x370(%rsp),%rax
  81f1f9:	add    $0xfffffffffffffffc,%rax
  81f1fd:	shr    $0x2,%rax
  81f201:	mov    0xb8(%rsp),%rcx
  81f209:	add    %rax,%rcx
  81f20c:	inc    %rcx
  81f20f:	mov    %rcx,0xb8(%rsp)
  81f217:	movq   $0x0,0x40(%rsp)
  81f220:	mov    0x28(%rsp),%rax
  81f225:	mov    0x40(%rsp),%rcx
  81f22a:	mov    (%rax,%rcx,1),%edx
  81f22d:	lea    0x300(%rsp),%rdi
  81f235:	mov    0x18(%rsp),%rsi
  81f23a:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f23f:	movzbl 0x300(%rsp),%edi
  81f247:	lea    0x308(%rsp),%rsi
  81f24f:	mov    -0x7(%rsi),%eax
  81f252:	mov    -0x4(%rsi),%ecx
  81f255:	lea    0x111(%rsp),%rdx
  81f25d:	mov    %ecx,0x3(%rdx)
  81f260:	mov    %eax,(%rdx)
  81f262:	mov    0x308(%rsp),%rcx
  81f26a:	mov    0x28(%rsi),%rax
  81f26e:	mov    %rax,0x2f(%rdx)
  81f272:	movups 0x8(%rsi),%xmm0
  81f276:	movups 0x18(%rsi),%xmm1
  81f27a:	movups %xmm1,0x1f(%rdx)
  81f27e:	movups %xmm0,0xf(%rdx)
  81f282:	movups 0x338(%rsp),%xmm1
  81f28a:	lea    0x348(%rsp),%rax
  81f292:	movups (%rax),%xmm0
  81f295:	lea    0x128(%rsp),%rax
  81f29d:	movups %xmm0,0x70(%rax)
  81f2a1:	movaps 0x3f0(%rsp),%xmm0
  81f2a9:	movups %xmm0,0x80(%rax)
  81f2b0:	movaps %xmm1,0xa0(%rsp)
  81f2b8:	movups %xmm1,0x148(%rsp)
  81f2c0:	movaps 0x500(%rsp),%xmm0
  81f2c8:	movaps 0x510(%rsp),%xmm1
  81f2d0:	movapd 0x520(%rsp),%xmm2
  81f2d9:	movupd %xmm2,0x50(%rax)
  81f2de:	movups %xmm1,0x40(%rax)
  81f2e2:	movups %xmm0,0x30(%rax)
  81f2e6:	movaps 0x530(%rsp),%xmm0
  81f2ee:	movups %xmm0,0x60(%rax)
  81f2f2:	mov    %dil,0x60(%rsp)
  81f2f7:	mov    %dil,0x110(%rsp)
  81f2ff:	mov    %rcx,0x80(%rsp)
  81f307:	mov    %rcx,0x118(%rsp)
  81f30f:	mov    0x8(%rsp),%rax
  81f314:	mov    (%rax),%rcx
  81f317:	mov    0x10(%rax),%rax
  81f31b:	sub    %rax,%rcx
  81f31e:	mov    %rax,0x90(%rsp)
  81f326:	cmp    $0x1,%rcx
  81f32a:	jbe    81f407 <<gpui_gpu::renderer::RendererState>::render+0x1337>
  81f330:	mov    0x8(%rsp),%rsi
  81f335:	mov    0x8(%rsi),%rcx
  81f339:	shl    $0x4,%rax
  81f33d:	movaps 0xa0(%rsp),%xmm0
  81f345:	movups %xmm0,(%rcx,%rax,1)
  81f349:	movq   $0x0,0x10(%rcx,%rax,1)
  81f352:	movl   $0x0,0x18(%rcx,%rax,1)
  81f35a:	mov    0xd0(%rsp),%edx
  81f361:	mov    %edx,0x1c(%rcx,%rax,1)
  81f365:	addq   $0x2,0x10(%rsi)
  81f36a:	sub    $0x8,%rsp
  81f36e:	lea    0x308(%rsp),%rdi
  81f376:	lea    0x118(%rsp),%rdx
  81f37e:	mov    0xf8(%rsp),%rcx
  81f386:	mov    0x98(%rsp),%r8
  81f38e:	mov    0x60(%rsp),%r9
  81f393:	push   0xe8(%rsp)
  81f39a:	push   %r15
  81f39c:	push   %r14
  81f39e:	call   820570 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f3a3:	add    $0x20,%rsp
  81f3a7:	mov    0x300(%rsp),%eax
  81f3ae:	cmp    $0xffffffff,%eax
  81f3b1:	jne    81f5ce <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  81f3b7:	cmpb   $0x2,0x60(%rsp)
  81f3bc:	sete   %al
  81f3bf:	cmpq   $0x0,0x80(%rsp)
  81f3c8:	setne  %cl
  81f3cb:	and    %al,%cl
  81f3cd:	mov    0x10(%rsp),%rax
  81f3d2:	or     %cl,%al
  81f3d4:	mov    %rax,0x10(%rsp)
  81f3d9:	mov    0x308(%rsp),%rax
  81f3e1:	mov    %rax,0xe0(%rsp)
  81f3e9:	mov    0x40(%rsp),%rcx
  81f3ee:	add    $0x4,%rcx
  81f3f2:	mov    %rcx,0x40(%rsp)
  81f3f7:	cmp    %rcx,0x370(%rsp)
  81f3ff:	jne    81f220 <<gpui_gpu::renderer::RendererState>::render+0x1150>
  81f405:	jmp    81f437 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81f407:	mov    $0x2,%edx
  81f40c:	mov    $0x4,%ecx
  81f411:	mov    $0x10,%r8d
  81f417:	mov    0x8(%rsp),%rdi
  81f41c:	mov    0x90(%rsp),%rsi
  81f424:	call   823b20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f429:	mov    0x8(%rsp),%rax
  81f42e:	mov    0x10(%rax),%rax
  81f432:	jmp    81f330 <<gpui_gpu::renderer::RendererState>::render+0x1260>
  81f437:	mov    0x10(%rsp),%rax
  81f43c:	and    $0x1,%al
  81f43e:	mov    %rax,0x10(%rsp)
  81f443:	lea    0x248(%rsp),%rdi
  81f44b:	lea    0x388(%rsp),%rsi
  81f453:	call   *0x660797(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81f459:	mov    0x248(%rsp),%rax
  81f461:	mov    %rax,0x18(%rsp)
  81f466:	test   %rax,%rax
  81f469:	jne    81e774 <<gpui_gpu::renderer::RendererState>::render+0x6a4>
  81f46f:	jmp    81f4d2 <<gpui_gpu::renderer::RendererState>::render+0x1402>
  81f471:	mov    $0x5,%edx
  81f476:	mov    $0x4,%ecx
  81f47b:	mov    $0x10,%r8d
  81f481:	mov    0x8(%rsp),%rdi
  81f486:	call   823b20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f48b:	mov    0x8(%rsp),%rax
  81f490:	mov    0x10(%rax),%rsi
  81f494:	jmp    81f10c <<gpui_gpu::renderer::RendererState>::render+0x103c>
  81f499:	movq   $0x0,0x208(%rsp)
  81f4a5:	movq   $0x0,0x200(%rsp)
  81f4b1:	movq   $0x0,0xb8(%rsp)
  81f4bd:	movq   $0x0,0x10(%rsp)
  81f4c6:	movq   $0x0,0xe0(%rsp)
  81f4d2:	mov    0x108(%rsp),%rsi
  81f4da:	lea    0x8(%rsi),%rdx
  81f4de:	mov    0x8(%rsp),%rax
  81f4e3:	lea    0x240(%rax),%rcx
  81f4ea:	lea    0x310(%rax),%r8
  81f4f1:	mov    0x10(%rax),%r9
  81f4f5:	sub    $0x8,%rsp
  81f4f9:	lea    0x118(%rsp),%rdi
  81f501:	mov    %rdx,0x3c8(%rsp)
  81f509:	mov    %rcx,0x2b8(%rsp)
  81f511:	mov    %r8,0x2c8(%rsp)
  81f519:	push   0xf0(%rsp)
  81f520:	call   822a60 <gpui_gpu::renderer::images::prepare>
  81f525:	add    $0x10,%rsp
  81f529:	cmpl   $0xffffffff,0x110(%rsp)
  81f531:	je     81f57a <<gpui_gpu::renderer::RendererState>::render+0x14aa>
  81f533:	movups 0x110(%rsp),%xmm0
  81f53b:	movups 0x120(%rsp),%xmm1
  81f543:	mov    0x30(%rsp),%rdi
  81f548:	movups %xmm1,0x10(%rdi)
  81f54c:	movups %xmm0,(%rdi)
  81f54f:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f554:	mov    0x23c(%rsp),%edx
  81f55b:	mov    0x30(%rsp),%rdi
  81f560:	mov    %edx,0x1c(%rdi)
  81f563:	movups 0x22c(%rsp),%xmm0
  81f56b:	movups %xmm0,0xc(%rdi)
  81f56f:	mov    %ecx,(%rdi)
  81f571:	mov    %rax,0x4(%rdi)
  81f575:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f57a:	movzbl 0x10(%rsp),%r8d
  81f580:	and    $0x1,%r8d
  81f584:	lea    0x110(%rsp),%rdi
  81f58c:	mov    0x8(%rsp),%rsi
  81f591:	mov    0x108(%rsp),%rdx
  81f599:	mov    0xc8(%rsp),%rcx
  81f5a1:	call   81d850 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f5a6:	mov    0x110(%rsp),%eax
  81f5ad:	cmp    $0xffffffff,%eax
  81f5b0:	je     81f615 <<gpui_gpu::renderer::RendererState>::render+0x1545>
  81f5b2:	mov    0x114(%rsp),%ecx
  81f5b9:	mov    0x118(%rsp),%rdx
  81f5c1:	movups 0x120(%rsp),%xmm0
  81f5c9:	jmp    81e603 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f5ce:	mov    0x304(%rsp),%ecx
  81f5d5:	mov    0x308(%rsp),%rdx
  81f5dd:	movups 0x310(%rsp),%xmm0
  81f5e5:	jmp    81e603 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f5ea:	mov    0x12c(%rsp),%ecx
  81f5f1:	mov    0x30(%rsp),%rdi
  81f5f6:	mov    %ecx,0x1c(%rdi)
  81f5f9:	movups 0x11c(%rsp),%xmm0
  81f601:	movups %xmm0,0xc(%rdi)
  81f605:	mov    %eax,(%rdi)
  81f607:	mov    0x40(%rsp),%rax
  81f60c:	mov    %rax,0x4(%rdi)
  81f610:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f615:	mov    0x118(%rsp),%rax
  81f61d:	mov    %rax,0x3b0(%rsp)
  81f625:	mov    0xc8(%rsp),%rax
  81f62d:	mov    %rax,0x300(%rsp)
  81f635:	movq   $0x0,0x308(%rsp)
  81f641:	mov    0xc0(%rsp),%rax
  81f649:	mov    %rax,0x310(%rsp)
  81f651:	mov    0x210(%rsp),%rax
  81f659:	mov    %rax,0x318(%rsp)
  81f661:	mov    0x78(%rsp),%eax
  81f665:	mov    %eax,0x320(%rsp)
  81f66c:	lea    0x248(%rsp),%rdi
  81f674:	lea    0x300(%rsp),%rsi
  81f67c:	call   *0x66056e(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81f682:	mov    0x248(%rsp),%rax
  81f68a:	mov    %rax,0xa0(%rsp)
  81f692:	test   %rax,%rax
  81f695:	je     81fa66 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f69b:	mov    0x8(%rsp),%rax
  81f6a0:	add    $0x108,%rax
  81f6a6:	mov    %rax,0x360(%rsp)
  81f6ae:	jmp    81f6e9 <<gpui_gpu::renderer::RendererState>::render+0x1619>
  81f6b0:	lea    0x248(%rsp),%rdi
  81f6b8:	lea    0x300(%rsp),%rsi
  81f6c0:	call   *0x66052a(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81f6c6:	mov    0x248(%rsp),%rax
  81f6ce:	mov    0x10(%rsp),%rcx
  81f6d3:	mov    %rcx,0x50(%rsp)
  81f6d8:	mov    %rax,0xa0(%rsp)
  81f6e0:	test   %rax,%rax
  81f6e3:	je     81fa66 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f6e9:	mov    0x250(%rsp),%rdx
  81f6f1:	mov    0x258(%rsp),%rdi
  81f6f9:	mov    %rdi,0x90(%rsp)
  81f701:	lea    0x260(%rsp),%rax
  81f709:	movups 0x40(%rax),%xmm0
  81f70d:	lea    0x128(%rsp),%rcx
  81f715:	movups %xmm0,0x40(%rcx)
  81f719:	movups (%rax),%xmm0
  81f71c:	movups 0x10(%rax),%xmm1
  81f720:	movups 0x20(%rax),%xmm2
  81f724:	movups 0x30(%rax),%xmm3
  81f728:	movups %xmm3,0x30(%rcx)
  81f72c:	movups %xmm2,0x20(%rcx)
  81f730:	movups %xmm1,0x10(%rcx)
  81f734:	movups %xmm0,(%rcx)
  81f737:	mov    0x8(%rsp),%rax
  81f73c:	movzbl 0x329(%rax),%esi
  81f743:	mov    0xa0(%rsp),%rax
  81f74b:	mov    %rax,0x110(%rsp)
  81f753:	mov    %rdx,0x60(%rsp)
  81f758:	mov    %rdx,0x118(%rsp)
  81f760:	mov    %rdi,0x120(%rsp)
  81f768:	lea    0x110(%rsp),%rdi
  81f770:	call   821550 <gpui_gpu::renderer::compact_group>
  81f775:	mov    0x50(%rsp),%rcx
  81f77a:	lea    0x5(%rcx),%rdx
  81f77e:	test   %al,%al
  81f780:	cmove  %rcx,%rdx
  81f784:	mov    %rdx,0x10(%rsp)
  81f789:	cmpq   $0x0,0x90(%rsp)
  81f792:	je     81f6b0 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81f798:	shlq   $0x2,0x90(%rsp)
  81f7a1:	xor    $0x1,%al
  81f7a3:	movzbl %al,%ecx
  81f7a6:	shl    $0x2,%ecx
  81f7a9:	lea    0x1(%rcx),%rax
  81f7ad:	mov    %rax,0x80(%rsp)
  81f7b5:	mov    0x10(%rsp),%rax
  81f7ba:	lea    (%rax,%rcx,1),%r8
  81f7be:	inc    %r8
  81f7c1:	or     $0x2,%rcx
  81f7c5:	shl    $0x4,%r8
  81f7c9:	mov    %rcx,0x50(%rsp)
  81f7ce:	shl    $0x4,%ecx
  81f7d1:	mov    %rcx,0xd0(%rsp)
  81f7d9:	xor    %ecx,%ecx
  81f7db:	mov    %r8,0x18(%rsp)
  81f7e0:	mov    0x60(%rsp),%rax
  81f7e5:	mov    %rcx,0x38(%rsp)
  81f7ea:	mov    (%rax,%rcx,1),%edx
  81f7ed:	lea    0x110(%rsp),%rdi
  81f7f5:	mov    0xa0(%rsp),%rsi
  81f7fd:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f802:	movzbl 0x110(%rsp),%ecx
  81f80a:	movzbl 0x111(%rsp),%eax
  81f812:	movss  0x114(%rsp),%xmm4
  81f81b:	lea    0x118(%rsp),%rsi
  81f823:	mov    0x10(%rsi),%rdx
  81f827:	mov    %rdx,0x2e0(%rsp)
  81f82f:	movups (%rsi),%xmm0
  81f832:	movaps %xmm0,0x2d0(%rsp)
  81f83a:	cmp    $0x1,%ecx
  81f83d:	je     81f8d2 <<gpui_gpu::renderer::RendererState>::render+0x1802>
  81f843:	movaps %xmm4,0xf0(%rsp)
  81f84b:	mov    0x130(%rsp),%rsi
  81f853:	mov    0x138(%rsp),%edx
  81f85a:	mov    %edx,0x40(%rsp)
  81f85e:	mov    0x13c(%rsp),%edx
  81f865:	mov    %edx,0x28(%rsp)
  81f869:	cmp    $0x3,%ecx
  81f86c:	jne    81f957 <<gpui_gpu::renderer::RendererState>::render+0x1887>
  81f872:	mov    0x2c0(%rsp),%rcx
  81f87a:	mov    (%rcx),%rdi
  81f87d:	test   %rdi,%rdi
  81f880:	je     8204ed <<gpui_gpu::renderer::RendererState>::render+0x241d>
  81f886:	movzbl %al,%edx
  81f889:	call   8226f0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f88e:	mov    %eax,%ecx
  81f890:	shr    $0x20,%rax
  81f894:	mov    %eax,%edx
  81f896:	or     $0x10,%edx
  81f899:	xorps  %xmm0,%xmm0
  81f89c:	movaps 0xf0(%rsp),%xmm1
  81f8a4:	ucomiss %xmm0,%xmm1
  81f8a7:	cmovne %edx,%eax
  81f8aa:	cmovp  %edx,%eax
  81f8ad:	mov    0x28(%rsp),%edx
  81f8b1:	shl    $0x10,%edx
  81f8b4:	or     0x40(%rsp),%edx
  81f8b8:	mov    %ecx,0x220(%rsp)
  81f8bf:	mov    %eax,0x224(%rsp)
  81f8c6:	mov    %edx,0x228(%rsp)
  81f8cd:	jmp    81f9f4 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f8d2:	movss  0x150(%rsp),%xmm0
  81f8db:	movss  -0x770977(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f8e3:	mulss  %xmm3,%xmm0
  81f8e7:	movaps %xmm4,%xmm1
  81f8ea:	minss  %xmm0,%xmm1
  81f8ee:	movaps %xmm1,%xmm0
  81f8f1:	cmpunordss %xmm1,%xmm0
  81f8f6:	movaps %xmm0,%xmm2
  81f8f9:	andnps %xmm1,%xmm2
  81f8fc:	andps  %xmm4,%xmm0
  81f8ff:	orps   %xmm2,%xmm0
  81f902:	movss  0x154(%rsp),%xmm1
  81f90b:	mulss  %xmm3,%xmm1
  81f90f:	movaps %xmm0,%xmm2
  81f912:	minss  %xmm1,%xmm2
  81f916:	movaps %xmm2,%xmm1
  81f919:	cmpunordss %xmm2,%xmm1
  81f91e:	andps  %xmm1,%xmm0
  81f921:	andnps %xmm2,%xmm1
  81f924:	orps   %xmm0,%xmm1
  81f927:	movd   %xmm1,%eax
  81f92b:	and    $0xff800000,%eax
  81f930:	mov    $0x7f000000,%ecx
  81f935:	sub    %eax,%ecx
  81f937:	movl   $0x40000000,0x220(%rsp)
  81f942:	movss  %xmm1,0x224(%rsp)
  81f94b:	mov    %ecx,0x228(%rsp)
  81f952:	jmp    81f9f4 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f957:	cmp    $0x2,%cl
  81f95a:	jne    81f9ac <<gpui_gpu::renderer::RendererState>::render+0x18dc>
  81f95c:	mov    0x140(%rsp),%rax
  81f964:	mov    0x2e0(%rsp),%rcx
  81f96c:	mov    %rcx,0x120(%rsp)
  81f974:	movaps 0x2d0(%rsp),%xmm0
  81f97c:	movaps %xmm0,0x110(%rsp)
  81f984:	mov    %rsi,0x128(%rsp)
  81f98c:	mov    0x40(%rsp),%ecx
  81f990:	mov    %ecx,0x130(%rsp)
  81f997:	mov    0x28(%rsp),%ecx
  81f99b:	mov    %ecx,0x134(%rsp)
  81f9a2:	mov    %rax,0x138(%rsp)
  81f9aa:	jmp    81f9b8 <<gpui_gpu::renderer::RendererState>::render+0x18e8>
  81f9ac:	movq   $0x0,0x110(%rsp)
  81f9b8:	movl   $0x0,0x390(%rsp)
  81f9c3:	movq   $0x0,0x388(%rsp)
  81f9cf:	lea    0x220(%rsp),%rdi
  81f9d7:	lea    0x110(%rsp),%rsi
  81f9df:	lea    0x388(%rsp),%rdx
  81f9e7:	mov    0x360(%rsp),%rcx
  81f9ef:	call   81b710 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f9f4:	mov    0x10(%rsp),%rdx
  81f9f9:	mov    0x80(%rsp),%rax
  81fa01:	lea    (%rax,%rdx,1),%rdi
  81fa05:	mov    0x8(%rsp),%rax
  81fa0a:	mov    0x10(%rax),%rsi
  81fa0e:	cmp    %rsi,%rdi
  81fa11:	mov    0x18(%rsp),%r8
  81fa16:	jae    820513 <<gpui_gpu::renderer::RendererState>::render+0x2443>
  81fa1c:	mov    0x8(%rax),%rax
  81fa20:	mov    0x228(%rsp),%ecx
  81fa27:	mov    %ecx,0x8(%rax,%r8,1)
  81fa2c:	mov    0x220(%rsp),%rcx
  81fa34:	mov    %rcx,(%rax,%r8,1)
  81fa38:	add    0x50(%rsp),%rdx
  81fa3d:	mov    %rdx,0x10(%rsp)
  81fa42:	add    0xd0(%rsp),%r8
  81fa4a:	mov    0x38(%rsp),%rcx
  81fa4f:	add    $0x4,%rcx
  81fa53:	cmp    %rcx,0x90(%rsp)
  81fa5b:	jne    81f7db <<gpui_gpu::renderer::RendererState>::render+0x170b>
  81fa61:	jmp    81f6b0 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81fa66:	cmpl   $0x0,0x58(%rsp)
  81fa6b:	je     8204fa <<gpui_gpu::renderer::RendererState>::render+0x242a>
  81fa71:	mov    0x8(%rsp),%rax
  81fa76:	mov    0x28(%rax),%rax
  81fa7a:	movq   $0x0,0xd0(%rsp)
  81fa86:	mov    %rax,0x10(%rsp)
  81fa8b:	test   %rax,%rax
  81fa8e:	je     81fbba <<gpui_gpu::renderer::RendererState>::render+0x1aea>
  81fa94:	mov    0x8(%rsp),%rcx
  81fa99:	mov    0x20(%rcx),%rcx
  81fa9d:	movq   $0x0,0x80(%rsp)
  81faa9:	movq   $0x0,0x50(%rsp)
  81fab2:	movq   $0x0,0x60(%rsp)
  81fabb:	xor    %esi,%esi
  81fabd:	jmp    81fae5 <<gpui_gpu::renderer::RendererState>::render+0x1a15>
  81fabf:	mov    0x18(%rsp),%rdx
  81fac4:	lea    (%rcx,%rdx,8),%rcx
  81fac8:	mov    0xd0(%rsp),%rax
  81fad0:	inc    %eax
  81fad2:	mov    %rax,0xd0(%rsp)
  81fada:	sub    %rdx,0x10(%rsp)
  81fadf:	je     81fbae <<gpui_gpu::renderer::RendererState>::render+0x1ade>
  81fae5:	mov    0x58(%rsp),%rax
  81faea:	mov    0x10(%rsp),%rdi
  81faef:	cmp    %rdi,%rax
  81faf2:	cmovb  %rax,%rdi
  81faf6:	mov    0xd0(%rsp),%rax
  81fafe:	mov    %eax,%edx
  81fb00:	shl    $0x4,%edx
  81fb03:	mov    %r15d,%r8d
  81fb06:	sub    %edx,%r8d
  81fb09:	cmp    $0x10,%r8d
  81fb0d:	mov    $0x10,%eax
  81fb12:	cmovae %eax,%r8d
  81fb16:	mov    %rdi,0x18(%rsp)
  81fb1b:	lea    0x0(,%rdi,8),%r9d
  81fb23:	shl    $0x4,%r8d
  81fb27:	xor    %r10d,%r10d
  81fb2a:	mov    %r14d,%r11d
  81fb2d:	jmp    81fb4e <<gpui_gpu::renderer::RendererState>::render+0x1a7e>
  81fb2f:	movl   $0x80000000,0x4(%rcx,%r10,1)
  81fb38:	incq   0x60(%rsp)
  81fb3d:	add    $0xfffffff0,%r11d
  81fb41:	add    $0x8,%r10
  81fb45:	cmp    %r10,%r9
  81fb48:	je     81fabf <<gpui_gpu::renderer::RendererState>::render+0x19ef>
  81fb4e:	mov    0x4(%rcx,%r10,1),%edx
  81fb53:	mov    %edx,%edi
  81fb55:	and    $0x8001ffff,%edi
  81fb5b:	cmp    $0x80000001,%edi
  81fb61:	je     81fb2f <<gpui_gpu::renderer::RendererState>::render+0x1a5f>
  81fb63:	mov    %edx,%eax
  81fb65:	and    $0x1ffff,%eax
  81fb6a:	shl    $0x17,%edx
  81fb6d:	or     %esi,%edx
  81fb6f:	add    %eax,%esi
  81fb71:	mov    %eax,%edi
  81fb73:	shl    $0xe,%edi
  81fb76:	and    $0x7f800000,%edi
  81fb7c:	or     %esi,%edi
  81fb7e:	mov    %edx,(%rcx,%r10,1)
  81fb82:	mov    %edi,0x4(%rcx,%r10,1)
  81fb87:	test   %eax,%eax
  81fb89:	je     81fb3d <<gpui_gpu::renderer::RendererState>::render+0x1a6d>
  81fb8b:	cmp    $0x10,%r11d
  81fb8f:	mov    $0x10,%edx
  81fb94:	cmovb  %r11d,%edx
  81fb98:	imul   %r8d,%edx
  81fb9c:	add    %rdx,0x50(%rsp)
  81fba1:	imul   %eax,%edx
  81fba4:	add    %rdx,0x80(%rsp)
  81fbac:	jmp    81fb3d <<gpui_gpu::renderer::RendererState>::render+0x1a6d>
  81fbae:	mov    %esi,%eax
  81fbb0:	mov    %rax,0xd0(%rsp)
  81fbb8:	jmp    81fbd8 <<gpui_gpu::renderer::RendererState>::render+0x1b08>
  81fbba:	movq   $0x0,0x60(%rsp)
  81fbc3:	movq   $0x0,0x50(%rsp)
  81fbcc:	movq   $0x0,0x80(%rsp)
  81fbd8:	mov    0x8(%rsp),%rax
  81fbdd:	lea    0x30(%rax),%rdi
  81fbe1:	movq   $0x0,0x40(%rax)
  81fbe9:	movl   $0x0,0xf0(%rsp)
  81fbf4:	mov    %rdi,0xa0(%rsp)
  81fbfc:	mov    0xd0(%rsp),%rsi
  81fc04:	xor    %edx,%edx
  81fc06:	call   822910 <<alloc::vec::Vec<u32>>::resize>
  81fc0b:	mov    0x8(%rsp),%rax
  81fc10:	mov    0x10(%rax),%rax
  81fc14:	mov    %rax,0x28(%rsp)
  81fc19:	mov    0xc8(%rsp),%rax
  81fc21:	mov    %rax,0x2d0(%rsp)
  81fc29:	movq   $0x0,0x2d8(%rsp)
  81fc35:	mov    0xc0(%rsp),%rax
  81fc3d:	mov    %rax,0x2e0(%rsp)
  81fc45:	mov    0x210(%rsp),%rax
  81fc4d:	mov    %rax,0x2e8(%rsp)
  81fc55:	mov    0x78(%rsp),%eax
  81fc59:	mov    %eax,0x2f0(%rsp)
  81fc60:	jmp    81fc7c <<gpui_gpu::renderer::RendererState>::render+0x1bac>
  81fc62:	mov    0x28(%rsp),%rcx
  81fc67:	lea    -0x5(%rcx),%rax
  81fc6b:	cmpb   $0x0,0xc0(%rsp)
  81fc73:	cmovne %rax,%rcx
  81fc77:	mov    %rcx,0x28(%rsp)
  81fc7c:	lea    0x248(%rsp),%rdi
  81fc84:	lea    0x2d0(%rsp),%rsi
  81fc8c:	call   *0x65ff6e(%rip)        # e7fc00 <_DYNAMIC+0x5c8>
  81fc92:	mov    0x248(%rsp),%rax
  81fc9a:	mov    %rax,0x40(%rsp)
  81fc9f:	test   %rax,%rax
  81fca2:	je     81fed5 <<gpui_gpu::renderer::RendererState>::render+0x1e05>
  81fca8:	mov    0x250(%rsp),%rcx
  81fcb0:	mov    0x258(%rsp),%rdx
  81fcb8:	mov    %rdx,0x18(%rsp)
  81fcbd:	mov    0x8(%rsp),%rax
  81fcc2:	movzbl 0x329(%rax),%esi
  81fcc9:	mov    0x40(%rsp),%rax
  81fcce:	mov    %rax,0x110(%rsp)
  81fcd6:	mov    %rcx,0x90(%rsp)
  81fcde:	mov    %rcx,0x118(%rsp)
  81fce6:	mov    %rdx,0x120(%rsp)
  81fcee:	lea    0x260(%rsp),%rax
  81fcf6:	movups (%rax),%xmm0
  81fcf9:	movups 0x10(%rax),%xmm1
  81fcfd:	movdqu 0x20(%rax),%xmm2
  81fd02:	lea    0x128(%rsp),%rdx
  81fd0a:	movdqu %xmm2,0x20(%rdx)
  81fd0f:	movups %xmm1,0x10(%rdx)
  81fd13:	movups %xmm0,(%rdx)
  81fd16:	lea    0x290(%rsp),%rcx
  81fd1e:	movups (%rcx),%xmm0
  81fd21:	movups %xmm0,0x30(%rdx)
  81fd25:	movups 0x40(%rax),%xmm0
  81fd29:	movups %xmm0,0x40(%rdx)
  81fd2d:	lea    0x110(%rsp),%rdi
  81fd35:	call   821550 <gpui_gpu::renderer::compact_group>
  81fd3a:	mov    %al,0xc0(%rsp)
  81fd41:	mov    0x18(%rsp),%rax
  81fd46:	test   %rax,%rax
  81fd49:	je     81fc62 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81fd4f:	mov    %rax,%rcx
  81fd52:	shl    $0x2,%rcx
  81fd56:	movzbl 0xc0(%rsp),%eax
  81fd5e:	lea    0x0(,%rax,4),%edx
  81fd65:	or     $0xfffffffffffffffa,%rdx
  81fd69:	xor    %esi,%esi
  81fd6b:	test   %al,%al
  81fd6d:	sete   %sil
  81fd71:	shl    $0x1f,%esi
  81fd74:	mov    %esi,0xc8(%rsp)
  81fd7b:	mov    %rdx,0x38(%rsp)
  81fd80:	mov    0x28(%rsp),%rax
  81fd85:	add    %edx,%eax
  81fd87:	mov    %eax,0x10(%rsp)
  81fd8b:	mov    %rcx,0x18(%rsp)
  81fd90:	mov    0x90(%rsp),%rax
  81fd98:	mov    -0x4(%rax,%rcx,1),%edx
  81fd9c:	lea    0x300(%rsp),%rdi
  81fda4:	mov    0x40(%rsp),%rsi
  81fda9:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fdae:	mov    0x38(%rsp),%rax
  81fdb3:	add    %rax,0x28(%rsp)
  81fdb8:	mov    0xc8(%rsp),%eax
  81fdbf:	or     0x10(%rsp),%eax
  81fdc3:	mov    %eax,0x220(%rsp)
  81fdca:	lea    0x260(%rsp),%rdx
  81fdd2:	movups (%rdx),%xmm0
  81fdd5:	movups 0x10(%rdx),%xmm1
  81fdd9:	movups 0x20(%rdx),%xmm2
  81fddd:	lea    0x128(%rsp),%rcx
  81fde5:	movups %xmm2,0x50(%rcx)
  81fde9:	movups %xmm1,0x40(%rcx)
  81fded:	movups %xmm0,0x30(%rcx)
  81fdf1:	lea    0x290(%rsp),%rax
  81fdf9:	movups (%rax),%xmm0
  81fdfc:	movups %xmm0,0x60(%rcx)
  81fe00:	movups 0x40(%rdx),%xmm0
  81fe04:	movups %xmm0,0x80(%rcx)
  81fe0b:	lea    0x338(%rsp),%rax
  81fe13:	movups (%rax),%xmm0
  81fe16:	movups %xmm0,0x20(%rcx)
  81fe1a:	lea    0x348(%rsp),%rax
  81fe22:	movups (%rax),%xmm0
  81fe25:	movups %xmm0,0x70(%rcx)
  81fe29:	mov    0x330(%rsp),%rax
  81fe31:	mov    %rax,0x140(%rsp)
  81fe39:	movups 0x300(%rsp),%xmm0
  81fe41:	movups 0x310(%rsp),%xmm1
  81fe49:	movdqu 0x320(%rsp),%xmm2
  81fe52:	movdqa %xmm2,0x130(%rsp)
  81fe5b:	movaps %xmm1,0x120(%rsp)
  81fe63:	movaps %xmm0,0x110(%rsp)
  81fe6b:	mov    0x218(%rsp),%rax
  81fe73:	mov    %rax,0x388(%rsp)
  81fe7b:	mov    0xa0(%rsp),%rax
  81fe83:	mov    %rax,0x390(%rsp)
  81fe8b:	lea    0x220(%rsp),%rax
  81fe93:	mov    %rax,0x398(%rsp)
  81fe9b:	lea    0x110(%rsp),%rdi
  81fea3:	mov    0x58(%rsp),%rsi
  81fea8:	lea    0x388(%rsp),%rdx
  81feb0:	call   81c5d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81feb5:	mov    0x10(%rsp),%eax
  81feb9:	add    0x38(%rsp),%eax
  81febd:	mov    %eax,0x10(%rsp)
  81fec1:	mov    0x18(%rsp),%rcx
  81fec6:	add    $0xfffffffffffffffc,%rcx
  81feca:	jne    81fd8b <<gpui_gpu::renderer::RendererState>::render+0x1cbb>
  81fed0:	jmp    81fc62 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81fed5:	test   $0x1,%r12b
  81fed9:	je     81ff2c <<gpui_gpu::renderer::RendererState>::render+0x1e5c>
  81fedb:	movd   0x244(%rsp),%xmm0
  81fee4:	movd   %xmm0,%eax
  81fee8:	test   %eax,%eax
  81feea:	setns  %cl
  81feed:	mov    %eax,%edx
  81feef:	and    $0x7fffffff,%edx
  81fef5:	add    $0xff800000,%edx
  81fefb:	cmp    $0x7f000000,%edx
  81ff01:	setb   %dl
  81ff04:	and    %cl,%dl
  81ff06:	dec    %eax
  81ff08:	cmp    $0x7fffff,%eax
  81ff0d:	setb   %al
  81ff10:	or     %dl,%al
  81ff12:	movl   $0x2,0xf0(%rsp)
  81ff1d:	movd   %xmm0,0x104(%rsp)
  81ff26:	je     8204e3 <<gpui_gpu::renderer::RendererState>::render+0x2413>
  81ff2c:	mov    0x108(%rsp),%r12
  81ff34:	lea    0x18(%r12),%rax
  81ff39:	mov    %rax,0x18(%rsp)
  81ff3e:	mov    0xe8(%rsp),%rax
  81ff46:	add    $0x18,%rax
  81ff4a:	xor    %ecx,%ecx
  81ff4c:	mov    0x378(%rsp),%rdx
  81ff54:	cmp    0x380(%rsp),%rdx
  81ff5c:	setne  %cl
  81ff5f:	xor    %edx,%edx
  81ff61:	cmp    $0x28,%r13d
  81ff65:	sete   %dl
  81ff68:	and    $0x1,%ebp
  81ff6b:	lea    0x0(%rbp,%rdx,4),%edx
  81ff6f:	lea    (%rdx,%rcx,8),%ecx
  81ff72:	or     0xf0(%rsp),%ecx
  81ff79:	movups (%rax),%xmm0
  81ff7c:	movups %xmm0,0x258(%rsp)
  81ff84:	mov    %r14d,0x248(%rsp)
  81ff8c:	mov    %r15d,0x24c(%rsp)
  81ff94:	mov    0x58(%rsp),%rax
  81ff99:	mov    %eax,0x250(%rsp)
  81ffa0:	mov    %ecx,0x254(%rsp)
  81ffa7:	movss  0x104(%rsp),%xmm0
  81ffb0:	movss  %xmm0,0x268(%rsp)
  81ffb9:	movq   $0x0,0x26c(%rsp)
  81ffc5:	movl   $0x0,0x274(%rsp)
  81ffd0:	mov    0x8(%rsp),%rbp
  81ffd5:	lea    0x218(%rbp),%rsi
  81ffdc:	movq   $0x0,0x10(%rsp)
  81ffe5:	lea    0x248(%rsp),%rcx
  81ffed:	mov    $0x30,%r8d
  81fff3:	mov    0x3c0(%rsp),%r13
  81fffb:	mov    %r13,%rdi
  81fffe:	mov    %rsi,0x58(%rsp)
  820003:	xor    %edx,%edx
  820005:	call   *0x65fbfd(%rip)        # e7fc08 <_DYNAMIC+0x5d0>
  82000b:	mov    0x8(%rbp),%rcx
  82000f:	mov    0x10(%rbp),%r8
  820013:	shl    $0x4,%r8
  820017:	mov    0x2b0(%rsp),%rdi
  82001f:	mov    %r12,%rsi
  820022:	mov    %r13,%rdx
  820025:	call   81cc30 <<gpui_gpu::renderer::Buffer>::write>
  82002a:	lea    0x268(%rbp),%rdi
  820031:	mov    0x20(%rbp),%rcx
  820035:	mov    0x28(%rbp),%r8
  820039:	shl    $0x3,%r8
  82003d:	mov    %rdi,0x38(%rsp)
  820042:	mov    %r12,%rsi
  820045:	mov    %r13,%rdx
  820048:	call   81cc30 <<gpui_gpu::renderer::Buffer>::write>
  82004d:	lea    0x290(%rbp),%rdi
  820054:	mov    0x38(%rbp),%rcx
  820058:	mov    0x40(%rbp),%r8
  82005c:	shl    $0x2,%r8
  820060:	mov    %rdi,0x218(%rsp)
  820068:	mov    %r12,%rsi
  82006b:	mov    %r13,%rdx
  82006e:	call   81cc30 <<gpui_gpu::renderer::Buffer>::write>
  820073:	lea    0x2b8(%rbp),%rdi
  82007a:	mov    0x50(%rbp),%rcx
  82007e:	mov    0x58(%rbp),%r8
  820082:	shl    $0x5,%r8
  820086:	mov    %rdi,0xe8(%rsp)
  82008e:	mov    %r12,%rsi
  820091:	mov    %r13,%rdx
  820094:	call   81cc30 <<gpui_gpu::renderer::Buffer>::write>
  820099:	cmpq   $0x0,0x310(%rbp)
  8200a1:	jne    8200bd <<gpui_gpu::renderer::RendererState>::render+0x1fed>
  8200a3:	mov    0x8(%rsp),%rax
  8200a8:	mov    0x10(%rax),%rax
  8200ac:	cmp    $0x1,%rax
  8200b0:	adc    $0x0,%rax
  8200b4:	shl    $0x4,%rax
  8200b8:	mov    %rax,0x10(%rsp)
  8200bd:	mov    0x8(%rsp),%rsi
  8200c2:	mov    0x28(%rsi),%rdx
  8200c6:	mov    0x40(%rsi),%rax
  8200ca:	cmp    $0x1,%rdx
  8200ce:	adc    $0x0,%rdx
  8200d2:	shl    $0x3,%rdx
  8200d6:	cmp    $0x1,%rax
  8200da:	adc    $0x0,%rax
  8200de:	mov    0x58(%rsi),%rcx
  8200e2:	cmp    $0x1,%rcx
  8200e6:	adc    $0x0,%rcx
  8200ea:	add    $0xb0,%rsi
  8200f1:	shl    $0x2,%rax
  8200f5:	shl    $0x5,%rcx
  8200f9:	movq   $0x0,0x110(%rsp)
  820105:	mov    0x58(%rsp),%rdi
  82010a:	mov    %rdi,0x118(%rsp)
  820112:	movq   $0x0,0x138(%rsp)
  82011e:	xorps  %xmm0,%xmm0
  820121:	movups %xmm0,0x120(%rsp)
  820129:	movl   $0x0,0x130(%rsp)
  820134:	mov    0x2b0(%rsp),%rdi
  82013c:	mov    %rdi,0x140(%rsp)
  820144:	movq   $0x0,0x148(%rsp)
  820150:	mov    0x10(%rsp),%rdi
  820155:	mov    %rdi,0x150(%rsp)
  82015d:	movl   $0x1,0x158(%rsp)
  820168:	movq   $0x0,0x160(%rsp)
  820174:	mov    0x38(%rsp),%rdi
  820179:	mov    %rdi,0x168(%rsp)
  820181:	movq   $0x0,0x170(%rsp)
  82018d:	mov    %rdx,0x178(%rsp)
  820195:	movl   $0x2,0x180(%rsp)
  8201a0:	movq   $0x0,0x188(%rsp)
  8201ac:	mov    0x218(%rsp),%rdx
  8201b4:	mov    %rdx,0x190(%rsp)
  8201bc:	movq   $0x0,0x198(%rsp)
  8201c8:	mov    %rax,0x1a0(%rsp)
  8201d0:	movl   $0x3,0x1a8(%rsp)
  8201db:	movq   $0x4,0x1b0(%rsp)
  8201e7:	mov    %rsi,0x1b8(%rsp)
  8201ef:	movl   $0x4,0x1d0(%rsp)
  8201fa:	movq   $0x0,0x1d8(%rsp)
  820206:	mov    0xe8(%rsp),%rax
  82020e:	mov    %rax,0x1e0(%rsp)
  820216:	movq   $0x0,0x1e8(%rsp)
  820222:	mov    %rcx,0x1f0(%rsp)
  82022a:	movl   $0x5,0x1f8(%rsp)
  820235:	lea    -0x74b359(%rip),%rax        # d4ee3 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x13d>
  82023c:	mov    %rax,0x318(%rsp)
  820244:	movq   $0xa,0x320(%rsp)
  820250:	mov    0x18(%rsp),%rax
  820255:	mov    %rax,0x300(%rsp)
  82025d:	lea    0x110(%rsp),%rax
  820265:	mov    %rax,0x308(%rsp)
  82026d:	movq   $0x6,0x310(%rsp)
  820279:	lea    0x300(%rsp),%rsi
  820281:	mov    0x108(%rsp),%r12
  820289:	mov    %r12,%rdi
  82028c:	call   *0x65f97e(%rip)        # e7fc10 <_DYNAMIC+0x5d8>
  820292:	mov    %rax,%r13
  820295:	mov    %rax,0x2d0(%rsp)
  82029d:	lea    0x2d0(%rsp),%rdx
  8202a5:	mov    %r12,%rdi
  8202a8:	mov    0x3e8(%rsp),%rsi
  8202b0:	call   81d290 <<gpui_gpu::renderer::GpuContext>::submit>
  8202b5:	mov    %rax,0x10(%rsp)
  8202ba:	xor    %ebp,%ebp
  8202bc:	mov    0x378(%rsp),%rax
  8202c4:	cmp    0x380(%rsp),%rax
  8202cc:	setne  %bpl
  8202d0:	shl    $0x1f,%ebp
  8202d3:	or     %r14d,%ebp
  8202d6:	shl    $0x20,%r15
  8202da:	or     %r15,%rbp
  8202dd:	mov    (%rbx),%rax
  8202e0:	test   %rax,%rax
  8202e3:	je     8202f4 <<gpui_gpu::renderer::RendererState>::render+0x2224>
  8202e5:	lock decq (%rax)
  8202e9:	jne    8202f4 <<gpui_gpu::renderer::RendererState>::render+0x2224>
  8202eb:	mov    %rbx,%rdi
  8202ee:	call   *0x65f85c(%rip)        # e7fb50 <_DYNAMIC+0x518>
  8202f4:	mov    0x8(%rsp),%rax
  8202f9:	mov    %r13,0x318(%rax)
  820300:	mov    %rbp,0x320(%rax)
  820307:	mov    0x10(%rax),%r9
  82030b:	mov    0x28(%rax),%rsi
  82030f:	mov    0x58(%rax),%rcx
  820313:	mov    %rcx,0x18(%rsp)
  820318:	shl    $0x4,%r9
  82031c:	mov    0xd0(%rsp),%rdx
  820324:	lea    (%r9,%rdx,4),%rdi
  820328:	lea    (%rdi,%rsi,8),%rsi
  82032c:	mov    %rcx,%rdi
  82032f:	shl    $0x5,%rdi
  820333:	lea    (%rdi,%rsi,1),%rcx
  820337:	add    $0x30,%rcx
  82033b:	mov    %rcx,0x58(%rsp)
  820340:	mov    0x138(%rax),%esi
  820346:	imul   %rsi,%rsi
  82034a:	mov    0x260(%rax),%r8
  820351:	add    0x238(%rax),%r8
  820358:	add    0x288(%rax),%r8
  82035f:	add    0x2b0(%rax),%r8
  820366:	add    0x2d8(%rax),%r8
  82036d:	mov    0x2f0(%rax),%rdi
  820374:	add    0x2f8(%rax),%rdi
  82037b:	mov    0xe0(%rsp),%r11
  820383:	mov    %r11,%rcx
  820386:	sub    %rdx,%rcx
  820389:	mov    0xb8(%rsp),%r10
  820391:	mov    %r10,%r12
  820394:	mov    0x208(%rsp),%rbp
  82039c:	sub    %rbp,%r12
  82039f:	mov    0x148(%rax),%rbx
  8203a6:	inc    %rbx
  8203a9:	mov    $0xffffffffffffffff,%r14
  8203b0:	cmovne %rbx,%r14
  8203b4:	mov    (%rax),%rbx
  8203b7:	shl    $0x4,%rbx
  8203bb:	mov    0x18(%rax),%r15
  8203bf:	lea    (%rbx,%r15,8),%rbx
  8203c3:	mov    0x30(%rax),%r15
  8203c7:	lea    (%rbx,%r15,4),%rbx
  8203cb:	mov    0x48(%rax),%r15
  8203cf:	shl    $0x5,%r15
  8203d3:	add    %rbx,%r15
  8203d6:	mov    0x120(%rax),%rbx
  8203dd:	mov    0x118(%rax),%r13
  8203e4:	mov    %r14,0x148(%rax)
  8203eb:	mov    %r10,0x150(%rax)
  8203f2:	lea    (%r11,%r11,1),%r14
  8203f6:	mov    %r14,0x158(%rax)
  8203fd:	movq   $0x1,0x160(%rax)
  820408:	mov    %r10,0x168(%rax)
  82040f:	mov    %rdx,0x170(%rax)
  820416:	mov    %r11,0x178(%rax)
  82041d:	mov    %rcx,0x180(%rax)
  820424:	mov    0x60(%rsp),%rcx
  820429:	mov    %rcx,0x188(%rax)
  820430:	mov    0x50(%rsp),%rcx
  820435:	mov    %rcx,0x190(%rax)
  82043c:	mov    0x80(%rsp),%rcx
  820444:	mov    %rcx,0x198(%rax)
  82044b:	mov    0x58(%rsp),%rcx
  820450:	mov    %rcx,0x1a0(%rax)
  820457:	mov    %r9,0x1a8(%rax)
  82045e:	mov    0x200(%rsp),%rdx
  820466:	mov    %rdx,0x1b0(%rax)
  82046d:	mov    %rbp,0x1b8(%rax)
  820474:	mov    %r12,0x1c0(%rax)
  82047b:	mov    0x3b0(%rsp),%rcx
  820483:	mov    %rcx,0x1c8(%rax)
  82048a:	mov    %r8,0x1d0(%rax)
  820491:	mov    %rsi,0x1d8(%rax)
  820498:	add    %rbx,%r13
  82049b:	mov    %rbx,0x1e0(%rax)
  8204a2:	mov    %r13,0x1e8(%rax)
  8204a9:	mov    %r15,0x1f0(%rax)
  8204b0:	mov    0x18(%rsp),%rcx
  8204b5:	mov    %rcx,0x1f8(%rax)
  8204bc:	mov    %rdi,0x200(%rax)
  8204c3:	movb   $0x0,0x208(%rax)
  8204ca:	mov    0x30(%rsp),%rdi
  8204cf:	mov    0x10(%rsp),%rax
  8204d4:	mov    %rax,0x8(%rdi)
  8204d8:	movl   $0xffffffff,(%rdi)
  8204de:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  8204e3:	mov    0x30(%rsp),%rdi
  8204e8:	jmp    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  8204ed:	lea    0x60dc5c(%rip),%rdi        # e2e150 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  8204f4:	call   *0x65f71e(%rip)        # e7fc18 <_DYNAMIC+0x5e0>
  8204fa:	lea    -0x74b639(%rip),%rdi        # d4ec8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  820501:	lea    0x60dc30(%rip),%rdx        # e2e138 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  820508:	mov    $0x37,%esi
  82050d:	call   *0x65f43d(%rip)        # e7f950 <_DYNAMIC+0x318>
  820513:	lea    0x60dc4e(%rip),%rdx        # e2e168 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  82051a:	call   *0x65f610(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
  820520:	mov    %rax,%r14
  820523:	mov    0x8(%rsp),%rax
  820528:	mov    %r13,0x318(%rax)
  82052f:	mov    %rbp,0x320(%rax)
  820536:	mov    %r14,%rdi
  820539:	call   e2c420 <_Unwind_Resume@plt>
  82053e:	mov    %rax,%r14
  820541:	lock decq 0x0(%r13)
  820546:	jne    820568 <<gpui_gpu::renderer::RendererState>::render+0x2498>
  820548:	lea    0x2d0(%rsp),%rdi
  820550:	call   *0x65f5fa(%rip)        # e7fb50 <_DYNAMIC+0x518>
  820556:	jmp    820568 <<gpui_gpu::renderer::RendererState>::render+0x2498>
  820558:	call   *0x65f32a(%rip)        # e7f888 <_DYNAMIC+0x250>
  82055e:	mov    %rax,%r14
  820561:	movq   $0x0,(%rbx)
  820568:	mov    %r14,%rdi
  82056b:	call   e2c420 <_Unwind_Resume@plt>

FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4056 frame=792

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820570 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820570:	push   %rbp
  820571:	push   %r15
  820573:	push   %r14
  820575:	push   %r13
  820577:	push   %r12
  820579:	push   %rbx
  82057a:	sub    $0x2e8,%rsp
  820581:	movss  0x88(%rdx),%xmm3
  820589:	movss  -0x7715d5(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820591:	movaps %xmm3,%xmm1
  820594:	subss  %xmm0,%xmm1
  820598:	cvttss2si %xmm1,%rax
  82059d:	cvttss2si %xmm3,%r10
  8205a2:	mov    %r10,%r13
  8205a5:	sar    $0x3f,%r13
  8205a9:	and    %rax,%r13
  8205ac:	or     %r10,%r13
  8205af:	xor    %eax,%eax
  8205b1:	xorps  %xmm1,%xmm1
  8205b4:	ucomiss %xmm1,%xmm3
  8205b7:	cmovb  %rax,%r13
  8205bb:	movss  0x90(%rdx),%xmm4
  8205c3:	movss  -0x77160b(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8205cb:	ucomiss %xmm2,%xmm3
  8205ce:	mov    $0xffffffffffffffff,%r14
  8205d5:	cmova  %r14,%r13
  8205d9:	movaps %xmm4,%xmm3
  8205dc:	subss  %xmm0,%xmm3
  8205e0:	cvttss2si %xmm3,%r10
  8205e5:	cvttss2si %xmm4,%r11
  8205ea:	mov    %r11,%rbx
  8205ed:	sar    $0x3f,%rbx
  8205f1:	and    %r10,%rbx
  8205f4:	or     %r11,%rbx
  8205f7:	ucomiss %xmm1,%xmm4
  8205fa:	cmovb  %rax,%rbx
  8205fe:	ucomiss %xmm2,%xmm4
  820601:	cmova  %r14,%rbx
  820605:	movss  0x8c(%rdx),%xmm3
  82060d:	lea    (%rbx,%r13,1),%r11
  820611:	dec    %r11
  820614:	shr    $0x4,%r11
  820618:	shr    $0x4,%r13
  82061c:	mov    %r11,%rbp
  82061f:	sub    %r13,%rbp
  820622:	inc    %rbp
  820625:	movaps %xmm3,%xmm4
  820628:	subss  %xmm0,%xmm4
  82062c:	cvttss2si %xmm4,%r10
  820631:	cvttss2si %xmm3,%r15
  820636:	mov    %r15,%rbx
  820639:	sar    $0x3f,%rbx
  82063d:	and    %r10,%rbx
  820640:	or     %r15,%rbx
  820643:	ucomiss %xmm1,%xmm3
  820646:	cmovb  %rax,%rbx
  82064a:	ucomiss %xmm2,%xmm3
  82064d:	movss  0x94(%rdx),%xmm3
  820655:	cmova  %r14,%rbx
  820659:	movaps %xmm3,%xmm4
  82065c:	subss  %xmm0,%xmm4
  820660:	cvttss2si %xmm4,%r10
  820665:	cvttss2si %xmm3,%r15
  82066a:	mov    %r15,%r12
  82066d:	sar    $0x3f,%r12
  820671:	and    %r10,%r12
  820674:	or     %r15,%r12
  820677:	ucomiss %xmm1,%xmm3
  82067a:	cmovb  %rax,%r12
  82067e:	ucomiss %xmm2,%xmm3
  820681:	cmova  %r14,%r12
  820685:	lea    (%rbx,%r12,1),%r10
  820689:	dec    %r10
  82068c:	shr    $0x4,%r10
  820690:	shr    $0x4,%rbx
  820694:	mov    %r10,%r14
  820697:	sub    %rbx,%r14
  82069a:	inc    %r14
  82069d:	imul   %rbp,%r14
  8206a1:	add    0x330(%rsp),%r14
  8206a9:	setb   %al
  8206ac:	cmp    $0x400001,%r14
  8206b3:	setae  %bpl
  8206b7:	or     %al,%bpl
  8206ba:	mov    $0x6,%eax
  8206bf:	jne    8206ff <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  8206c1:	mov    %r8d,0xac(%rsp)
  8206c9:	mov    %r14,0x170(%rsp)
  8206d1:	mov    %rdi,0x178(%rsp)
  8206d9:	mov    %r13,0xa0(%rsp)
  8206e1:	cmp    %rbx,%r10
  8206e4:	jae    820713 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  8206e6:	mov    0x178(%rsp),%rdi
  8206ee:	mov    0x170(%rsp),%rax
  8206f6:	mov    %rax,0x8(%rdi)
  8206fa:	mov    $0xffffffff,%eax
  8206ff:	mov    %eax,(%rdi)
  820701:	add    $0x2e8,%rsp
  820708:	pop    %rbx
  820709:	pop    %r12
  82070b:	pop    %r13
  82070d:	pop    %r14
  82070f:	pop    %r15
  820711:	pop    %rbp
  820712:	ret
  820713:	cmp    0xa0(%rsp),%r11
  82071b:	jae    820736 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  82071d:	nopl   (%rax)
  820720:	mov    %rbx,%rax
  820723:	cmp    %r10,%rbx
  820726:	adc    $0x0,%rbx
  82072a:	cmp    %r10,%rax
  82072d:	jae    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82072f:	cmp    %r10,%rbx
  820732:	jbe    820720 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  820734:	jmp    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820736:	movd   0xa4(%rdx),%xmm0
  82073e:	mov    0x20(%rsi),%r12
  820742:	movdqu 0x98(%rdx),%xmm1
  82074a:	movd   0xa0(%rdx),%xmm2
  820752:	punpckldq %xmm0,%xmm2
  820756:	punpcklqdq %xmm2,%xmm1
  82075a:	movdqa -0x773e52(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  820762:	pand   %xmm1,%xmm2
  820766:	paddd  -0x773bfe(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  82076e:	pxor   -0x772446(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  820776:	pcmpgtd -0x772fee(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  82077e:	mov    %rsi,%rax
  820781:	mov    0x28(%rsi),%rsi
  820785:	pandn  %xmm1,%xmm2
  820789:	movmskps %xmm2,%edi
  82078c:	test   %edi,%edi
  82078e:	jne    8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820794:	ucomiss -0x771a1b(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82079b:	jne    8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  8207a1:	jp     8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  8207a7:	cmpb   $0x0,0x328(%rax)
  8207ae:	je     8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  8207b4:	cmpb   $0x0,(%rdx)
  8207b7:	jne    8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  8207bd:	test   %r9,%r9
  8207c0:	je     82152b <<gpui_gpu::renderer::RendererState>::bin_draw+0xfbb>
  8207c6:	mov    0x328(%rsp),%ebp
  8207cd:	mov    0x320(%rsp),%r13d
  8207d5:	movd   %ecx,%xmm2
  8207d9:	shr    $0x20,%rcx
  8207dd:	movss  0x78(%rdx),%xmm0
  8207e2:	movss  0x80(%rdx),%xmm3
  8207ea:	movss  0x84(%rdx),%xmm4
  8207f2:	cvtss2sd %xmm0,%xmm0
  8207f6:	movss  0x7c(%rdx),%xmm1
  8207fb:	cvtss2sd %xmm1,%xmm1
  8207ff:	cvtss2sd %xmm3,%xmm14
  820804:	addsd  %xmm0,%xmm14
  820809:	xorps  %xmm3,%xmm3
  82080c:	cvtss2sd %xmm4,%xmm3
  820810:	addsd  %xmm1,%xmm3
  820814:	movsd  %xmm3,0x1a8(%rsp)
  82081d:	movsd  0x48(%rdx),%xmm6
  820822:	movsd  0x58(%rdx),%xmm7
  820827:	movsd  0x68(%rdx),%xmm8
  82082d:	movss  0x38(%rdx),%xmm3
  820832:	movss  0x3c(%rdx),%xmm4
  820837:	movss  0x40(%rdx),%xmm5
  82083c:	cvtss2sd %xmm3,%xmm3
  820840:	cvtss2sd %xmm5,%xmm5
  820844:	movaps -0x775a9c(%rip),%xmm9        # aadb0 <GCC_except_table0+0xb8>
  82084c:	movaps %xmm3,0x80(%rsp)
  820854:	andps  %xmm9,%xmm3
  820858:	movaps %xmm3,0x70(%rsp)
  82085d:	movaps %xmm5,0x50(%rsp)
  820862:	cvtss2sd %xmm2,%xmm2
  820866:	movsd  %xmm2,0x8(%rsp)
  82086c:	andps  %xmm9,%xmm5
  820870:	movaps %xmm5,0x60(%rsp)
  820875:	movaps %xmm6,%xmm2
  820878:	andps  %xmm9,%xmm2
  82087c:	movaps %xmm2,0x250(%rsp)
  820884:	movaps %xmm7,%xmm2
  820887:	andps  %xmm9,%xmm2
  82088b:	movaps %xmm2,0x230(%rsp)
  820893:	xorps  %xmm3,%xmm3
  820896:	cvtss2sd %xmm4,%xmm3
  82089a:	movaps %xmm8,%xmm2
  82089e:	andps  %xmm9,%xmm2
  8208a2:	movaps %xmm2,0xf0(%rsp)
  8208aa:	movss  0x44(%rdx),%xmm2
  8208af:	cvtss2sd %xmm2,%xmm2
  8208b3:	movaps %xmm3,0x40(%rsp)
  8208b8:	andps  %xmm9,%xmm3
  8208bc:	movaps %xmm3,0x30(%rsp)
  8208c1:	movaps %xmm2,0x10(%rsp)
  8208c6:	andps  %xmm9,%xmm2
  8208ca:	movaps %xmm2,0x20(%rsp)
  8208cf:	movd   %ecx,%xmm2
  8208d3:	cvtss2sd %xmm2,%xmm2
  8208d7:	movsd  %xmm2,(%rsp)
  8208dc:	movsd  0x50(%rdx),%xmm2
  8208e1:	movaps %xmm2,%xmm3
  8208e4:	andps  %xmm9,%xmm3
  8208e8:	movaps %xmm3,0x1d0(%rsp)
  8208f0:	movsd  0x60(%rdx),%xmm3
  8208f5:	movaps %xmm3,%xmm4
  8208f8:	andps  %xmm9,%xmm4
  8208fc:	movaps %xmm4,0x1b0(%rsp)
  820904:	movsd  0x70(%rdx),%xmm4
  820909:	movaps %xmm4,%xmm5
  82090c:	andps  %xmm9,%xmm5
  820910:	movaps %xmm5,0xb0(%rsp)
  820918:	movaps %xmm2,0x1e0(%rsp)
  820920:	cvtsd2ss %xmm2,%xmm2
  820924:	xorps  %xmm5,%xmm5
  820927:	cvtss2sd %xmm2,%xmm5
  82092b:	movaps %xmm6,0x260(%rsp)
  820933:	movaps %xmm6,%xmm2
  820936:	movaps %xmm7,0x240(%rsp)
  82093e:	movlhps %xmm7,%xmm2
  820941:	cvtpd2ps %xmm2,%xmm2
  820945:	cvtps2pd %xmm2,%xmm6
  820948:	movaps %xmm3,0x1c0(%rsp)
  820950:	xorps  %xmm2,%xmm2
  820953:	cvtsd2ss %xmm3,%xmm2
  820957:	xorps  %xmm3,%xmm3
  82095a:	cvtss2sd %xmm2,%xmm3
  82095e:	movaps %xmm8,0x100(%rsp)
  820967:	xorps  %xmm2,%xmm2
  82096a:	cvtsd2ss %xmm8,%xmm2
  82096f:	xorps  %xmm7,%xmm7
  820972:	cvtss2sd %xmm2,%xmm7
  820976:	movaps %xmm4,0xc0(%rsp)
  82097e:	xorps  %xmm2,%xmm2
  820981:	cvtsd2ss %xmm4,%xmm2
  820985:	cvtss2sd %xmm2,%xmm2
  820989:	movaps %xmm6,%xmm4
  82098c:	andps  %xmm9,%xmm4
  820990:	movaps %xmm7,0x120(%rsp)
  820998:	andps  %xmm9,%xmm7
  82099c:	movaps %xmm7,0x110(%rsp)
  8209a4:	movaps %xmm5,0x220(%rsp)
  8209ac:	andps  %xmm9,%xmm5
  8209b0:	movaps %xmm5,0x210(%rsp)
  8209b8:	movaps %xmm3,0x200(%rsp)
  8209c0:	andps  %xmm9,%xmm3
  8209c4:	movaps %xmm3,0x1f0(%rsp)
  8209cc:	movaps %xmm2,0xd0(%rsp)
  8209d4:	andps  %xmm2,%xmm9
  8209d8:	movaps %xmm9,0xe0(%rsp)
  8209e1:	movaps %xmm6,0x280(%rsp)
  8209e9:	movhlps %xmm6,%xmm6
  8209ec:	movaps %xmm6,0x2b0(%rsp)
  8209f4:	movaps %xmm4,0x270(%rsp)
  8209fc:	movhlps %xmm4,%xmm4
  8209ff:	movaps %xmm4,0x2a0(%rsp)
  820a07:	mov    %r10,0x198(%rsp)
  820a0f:	movsd  %xmm14,0x98(%rsp)
  820a19:	nopl   0x0(%rax)
  820a20:	mov    %rbx,%r15
  820a23:	cmp    %r10,%rbx
  820a26:	adc    $0x0,%rbx
  820a2a:	mov    %r15,0x1a0(%rsp)
  820a32:	imul   %r9,%r15
  820a36:	mov    0xa0(%rsp),%rdi
  820a3e:	mov    %rdi,%r8
  820a41:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820a50:	cmp    %r11,%rdi
  820a53:	adc    $0x0,%r8
  820a57:	lea    (%rdi,%r15,1),%rcx
  820a5b:	mov    %rcx,%rax
  820a5e:	shr    $0x20,%rax
  820a62:	je     820a70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x500>
  820a64:	mov    %rcx,%rax
  820a67:	xor    %edx,%edx
  820a69:	div    %r9
  820a6c:	jmp    820a77 <<gpui_gpu::renderer::RendererState>::bin_draw+0x507>
  820a6e:	xchg   %ax,%ax
  820a70:	mov    %ecx,%eax
  820a72:	xor    %edx,%edx
  820a74:	div    %r9d
  820a77:	shl    $0x4,%edx
  820a7a:	shl    $0x4,%eax
  820a7d:	lea    0x10(%rdx),%r10d
  820a81:	cmp    %r10d,%r13d
  820a84:	cmovb  %r13d,%r10d
  820a88:	lea    0x10(%rax),%r14d
  820a8c:	cmp    %r14d,%ebp
  820a8f:	cmovb  %ebp,%r14d
  820a93:	xorps  %xmm12,%xmm12
  820a97:	cvtsi2sd %edx,%xmm12
  820a9c:	ucomisd %xmm12,%xmm0
  820aa1:	ja     820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820aa3:	mov    %eax,%eax
  820aa5:	xorps  %xmm2,%xmm2
  820aa8:	cvtsi2sd %rax,%xmm2
  820aad:	ucomisd %xmm2,%xmm1
  820ab1:	ja     820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ab3:	xorps  %xmm6,%xmm6
  820ab6:	cvtsi2sd %r10d,%xmm6
  820abb:	ucomisd %xmm14,%xmm6
  820ac0:	ja     820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ac2:	xorps  %xmm13,%xmm13
  820ac6:	cvtsi2sd %r14d,%xmm13
  820acb:	ucomisd 0x1a8(%rsp),%xmm13
  820ad5:	jbe    820b08 <<gpui_gpu::renderer::RendererState>::bin_draw+0x598>
  820ad7:	nopw   0x0(%rax,%rax,1)
  820ae0:	cmp    %rsi,%rcx
  820ae3:	jae    82151b <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  820ae9:	incl   0x4(%r12,%rcx,8)
  820aee:	cmp    %r11,%rdi
  820af1:	jae    821490 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820af7:	mov    %r8,%rdi
  820afa:	cmp    %r11,%r8
  820afd:	jbe    820a50 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4e0>
  820b03:	jmp    821490 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820b08:	unpcklpd %xmm2,%xmm12
  820b0d:	addpd  -0x773a46(%rip),%xmm12        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820b16:	movapd %xmm12,%xmm10
  820b1b:	mulpd  0x280(%rsp),%xmm10
  820b25:	movapd %xmm10,%xmm15
  820b2a:	unpckhpd %xmm10,%xmm15
  820b2f:	movapd %xmm10,%xmm2
  820b34:	addsd  %xmm15,%xmm2
  820b39:	addsd  0x120(%rsp),%xmm2
  820b42:	subsd  0x80(%rsp),%xmm2
  820b4b:	movapd 0x270(%rsp),%xmm8
  820b55:	mulpd  %xmm12,%xmm8
  820b5a:	movapd %xmm8,%xmm9
  820b5f:	unpckhpd %xmm8,%xmm9
  820b64:	movapd %xmm8,%xmm3
  820b69:	addsd  %xmm9,%xmm3
  820b6e:	addsd  0x110(%rsp),%xmm3
  820b77:	addsd  0x70(%rsp),%xmm3
  820b7d:	addsd  0x60(%rsp),%xmm3
  820b83:	addsd  -0x771313(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b8b:	mulsd  -0x771393(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820b93:	addsd  0x8(%rsp),%xmm3
  820b99:	ucomisd %xmm2,%xmm3
  820b9d:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ba3:	movapd 0x50(%rsp),%xmm4
  820ba9:	subsd  %xmm2,%xmm4
  820bad:	ucomisd %xmm4,%xmm3
  820bb1:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820bb7:	movapd %xmm12,%xmm7
  820bbc:	unpckhpd %xmm12,%xmm7
  820bc1:	movapd 0x240(%rsp),%xmm11
  820bcb:	mulsd  %xmm7,%xmm11
  820bd0:	movapd 0x230(%rsp),%xmm3
  820bd9:	mulsd  %xmm7,%xmm3
  820bdd:	movapd 0x260(%rsp),%xmm2
  820be6:	mulsd  %xmm12,%xmm2
  820beb:	movapd %xmm2,0x140(%rsp)
  820bf4:	addsd  %xmm11,%xmm2
  820bf9:	addsd  0x100(%rsp),%xmm2
  820c02:	subsd  0x80(%rsp),%xmm2
  820c0b:	movapd 0x250(%rsp),%xmm4
  820c14:	mulsd  %xmm12,%xmm4
  820c19:	movsd  %xmm4,0x190(%rsp)
  820c22:	addsd  %xmm3,%xmm4
  820c26:	addsd  0xf0(%rsp),%xmm4
  820c2f:	addsd  0x70(%rsp),%xmm4
  820c35:	addsd  0x60(%rsp),%xmm4
  820c3b:	addsd  -0x7713cb(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c43:	mulsd  -0x770e73(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820c4b:	ucomisd %xmm2,%xmm4
  820c4f:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c55:	movapd 0x50(%rsp),%xmm5
  820c5b:	subsd  %xmm2,%xmm5
  820c5f:	ucomisd %xmm5,%xmm4
  820c63:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c69:	movapd %xmm7,%xmm4
  820c6d:	mulsd  0x200(%rsp),%xmm4
  820c76:	movapd %xmm7,%xmm2
  820c7a:	mulsd  0x1f0(%rsp),%xmm2
  820c83:	movapd %xmm12,%xmm5
  820c88:	mulsd  0x220(%rsp),%xmm5
  820c91:	movsd  %xmm5,0x188(%rsp)
  820c9a:	movapd %xmm4,0x130(%rsp)
  820ca3:	addsd  %xmm4,%xmm5
  820ca7:	addsd  0xd0(%rsp),%xmm5
  820cb0:	subsd  0x40(%rsp),%xmm5
  820cb6:	movapd %xmm12,%xmm4
  820cbb:	mulsd  0x210(%rsp),%xmm4
  820cc4:	movsd  %xmm4,0x180(%rsp)
  820ccd:	addsd  %xmm2,%xmm4
  820cd1:	addsd  0xe0(%rsp),%xmm4
  820cda:	addsd  0x30(%rsp),%xmm4
  820ce0:	addsd  0x20(%rsp),%xmm4
  820ce6:	addsd  -0x771476(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cee:	mulsd  -0x7714f6(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cf6:	addsd  (%rsp),%xmm4
  820cfb:	ucomisd %xmm5,%xmm4
  820cff:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d05:	movapd 0x10(%rsp),%xmm14
  820d0c:	subsd  %xmm5,%xmm14
  820d11:	ucomisd %xmm14,%xmm4
  820d16:	movsd  0x98(%rsp),%xmm14
  820d20:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d26:	movapd 0x1c0(%rsp),%xmm4
  820d2f:	mulsd  %xmm7,%xmm4
  820d33:	mulsd  0x1b0(%rsp),%xmm7
  820d3c:	movapd 0x1e0(%rsp),%xmm5
  820d45:	mulsd  %xmm12,%xmm5
  820d4a:	movapd %xmm5,0x2c0(%rsp)
  820d53:	movapd %xmm4,0x2d0(%rsp)
  820d5c:	addsd  %xmm4,%xmm5
  820d60:	addsd  0xc0(%rsp),%xmm5
  820d69:	subsd  0x40(%rsp),%xmm5
  820d6f:	mulsd  0x1d0(%rsp),%xmm12
  820d79:	movapd %xmm12,%xmm4
  820d7e:	addsd  %xmm7,%xmm4
  820d82:	addsd  0xb0(%rsp),%xmm4
  820d8b:	addsd  0x30(%rsp),%xmm4
  820d91:	addsd  0x20(%rsp),%xmm4
  820d97:	addsd  -0x771527(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d9f:	mulsd  -0x770fcf(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820da7:	ucomisd %xmm5,%xmm4
  820dab:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820db1:	movapd 0x10(%rsp),%xmm14
  820db8:	subsd  %xmm5,%xmm14
  820dbd:	ucomisd %xmm14,%xmm4
  820dc2:	movsd  0x98(%rsp),%xmm14
  820dcc:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820dd2:	addsd  -0x771852(%rip),%xmm6        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820dda:	movapd %xmm6,%xmm4
  820dde:	mulsd  0x280(%rsp),%xmm4
  820de7:	movsd  %xmm4,0x168(%rsp)
  820df0:	addsd  %xmm4,%xmm15
  820df5:	addsd  0x120(%rsp),%xmm15
  820dff:	subsd  0x80(%rsp),%xmm15
  820e09:	movapd 0x270(%rsp),%xmm4
  820e12:	mulsd  %xmm6,%xmm4
  820e16:	movsd  %xmm4,0x160(%rsp)
  820e1f:	addsd  %xmm4,%xmm9
  820e24:	addsd  0x110(%rsp),%xmm9
  820e2e:	addsd  0x70(%rsp),%xmm9
  820e35:	addsd  0x60(%rsp),%xmm9
  820e3c:	addsd  -0x7715cd(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e45:	mulsd  -0x77164e(%rip),%xmm9        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e4e:	addsd  0x8(%rsp),%xmm9
  820e55:	ucomisd %xmm15,%xmm9
  820e5a:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e60:	movapd 0x50(%rsp),%xmm4
  820e66:	subsd  %xmm15,%xmm4
  820e6b:	ucomisd %xmm4,%xmm9
  820e70:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e76:	movapd 0x260(%rsp),%xmm15
  820e80:	mulsd  %xmm6,%xmm15
  820e85:	addsd  %xmm15,%xmm11
  820e8a:	addsd  0x100(%rsp),%xmm11
  820e94:	subsd  0x80(%rsp),%xmm11
  820e9e:	movapd 0x250(%rsp),%xmm4
  820ea7:	mulsd  %xmm6,%xmm4
  820eab:	movsd  %xmm4,0x158(%rsp)
  820eb4:	addsd  %xmm4,%xmm3
  820eb8:	addsd  0xf0(%rsp),%xmm3
  820ec1:	addsd  0x70(%rsp),%xmm3
  820ec7:	addsd  0x60(%rsp),%xmm3
  820ecd:	addsd  -0x77165d(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ed5:	mulsd  -0x771105(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820edd:	ucomisd %xmm11,%xmm3
  820ee2:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ee8:	movapd 0x50(%rsp),%xmm4
  820eee:	subsd  %xmm11,%xmm4
  820ef3:	ucomisd %xmm4,%xmm3
  820ef7:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820efd:	movapd %xmm6,%xmm3
  820f01:	mulsd  0x220(%rsp),%xmm3
  820f0a:	movsd  %xmm3,0x150(%rsp)
  820f13:	movapd 0x130(%rsp),%xmm5
  820f1c:	addsd  %xmm3,%xmm5
  820f20:	addsd  0xd0(%rsp),%xmm5
  820f29:	subsd  0x40(%rsp),%xmm5
  820f2f:	movapd %xmm6,%xmm3
  820f33:	mulsd  0x210(%rsp),%xmm3
  820f3c:	movsd  %xmm3,0x130(%rsp)
  820f45:	addsd  %xmm3,%xmm2
  820f49:	addsd  0xe0(%rsp),%xmm2
  820f52:	addsd  0x30(%rsp),%xmm2
  820f58:	addsd  0x20(%rsp),%xmm2
  820f5e:	addsd  -0x7716ee(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f66:	mulsd  -0x77176e(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f6e:	addsd  (%rsp),%xmm2
  820f73:	ucomisd %xmm5,%xmm2
  820f77:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f7d:	movapd 0x10(%rsp),%xmm3
  820f83:	subsd  %xmm5,%xmm3
  820f87:	ucomisd %xmm3,%xmm2
  820f8b:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f91:	movapd 0x1e0(%rsp),%xmm2
  820f9a:	mulsd  %xmm6,%xmm2
  820f9e:	movapd %xmm2,0x290(%rsp)
  820fa7:	movapd 0x2d0(%rsp),%xmm4
  820fb0:	addsd  %xmm2,%xmm4
  820fb4:	addsd  0xc0(%rsp),%xmm4
  820fbd:	subsd  0x40(%rsp),%xmm4
  820fc3:	mulsd  0x1d0(%rsp),%xmm6
  820fcc:	addsd  %xmm6,%xmm7
  820fd0:	addsd  0xb0(%rsp),%xmm7
  820fd9:	addsd  0x30(%rsp),%xmm7
  820fdf:	addsd  0x20(%rsp),%xmm7
  820fe5:	addsd  -0x771775(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fed:	mulsd  -0x77121d(%rip),%xmm7        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820ff5:	ucomisd %xmm4,%xmm7
  820ff9:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820fff:	movapd 0x10(%rsp),%xmm2
  821005:	subsd  %xmm4,%xmm2
  821009:	ucomisd %xmm2,%xmm7
  82100d:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821013:	addsd  -0x771a94(%rip),%xmm13        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82101c:	movapd %xmm13,%xmm3
  821021:	mulsd  0x2b0(%rsp),%xmm3
  82102a:	movapd %xmm13,%xmm2
  82102f:	mulsd  0x2a0(%rsp),%xmm2
  821038:	addsd  %xmm3,%xmm10
  82103d:	addsd  0x120(%rsp),%xmm10
  821047:	subsd  0x80(%rsp),%xmm10
  821051:	addsd  %xmm2,%xmm8
  821056:	addsd  0x110(%rsp),%xmm8
  821060:	addsd  0x70(%rsp),%xmm8
  821067:	addsd  0x60(%rsp),%xmm8
  82106e:	addsd  -0x7717ff(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821077:	mulsd  -0x771880(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821080:	addsd  0x8(%rsp),%xmm8
  821087:	ucomisd %xmm10,%xmm8
  82108c:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821092:	movapd 0x50(%rsp),%xmm4
  821098:	subsd  %xmm10,%xmm4
  82109d:	ucomisd %xmm4,%xmm8
  8210a2:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8210a8:	movapd 0x240(%rsp),%xmm7
  8210b1:	mulsd  %xmm13,%xmm7
  8210b6:	movapd 0x230(%rsp),%xmm5
  8210bf:	mulsd  %xmm13,%xmm5
  8210c4:	movapd 0x140(%rsp),%xmm4
  8210cd:	addsd  %xmm7,%xmm4
  8210d1:	addsd  0x100(%rsp),%xmm4
  8210da:	subsd  0x80(%rsp),%xmm4
  8210e3:	movsd  0x190(%rsp),%xmm10
  8210ed:	addsd  %xmm5,%xmm10
  8210f2:	addsd  0xf0(%rsp),%xmm10
  8210fc:	addsd  0x70(%rsp),%xmm10
  821103:	addsd  0x60(%rsp),%xmm10
  82110a:	addsd  -0x77189b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821113:	mulsd  -0x771344(%rip),%xmm10        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82111c:	ucomisd %xmm4,%xmm10
  821121:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821127:	movapd %xmm4,%xmm8
  82112c:	movapd 0x50(%rsp),%xmm4
  821132:	subsd  %xmm8,%xmm4
  821137:	ucomisd %xmm4,%xmm10
  82113c:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821142:	movapd %xmm13,%xmm8
  821147:	mulsd  0x200(%rsp),%xmm8
  821151:	movapd %xmm13,%xmm10
  821156:	mulsd  0x1f0(%rsp),%xmm10
  821160:	movsd  0x188(%rsp),%xmm9
  82116a:	addsd  %xmm8,%xmm9
  82116f:	addsd  0xd0(%rsp),%xmm9
  821179:	subsd  0x40(%rsp),%xmm9
  821180:	movapd %xmm15,%xmm4
  821185:	movsd  0x180(%rsp),%xmm15
  82118f:	movsd  %xmm10,0x140(%rsp)
  821199:	addsd  %xmm10,%xmm15
  82119e:	addsd  0xe0(%rsp),%xmm15
  8211a8:	addsd  0x30(%rsp),%xmm15
  8211af:	addsd  0x20(%rsp),%xmm15
  8211b6:	addsd  -0x771947(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211bf:	mulsd  -0x7719c8(%rip),%xmm15        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8211c8:	addsd  (%rsp),%xmm15
  8211ce:	ucomisd %xmm9,%xmm15
  8211d3:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211d9:	movapd %xmm9,%xmm10
  8211de:	movapd 0x10(%rsp),%xmm9
  8211e5:	subsd  %xmm10,%xmm9
  8211ea:	ucomisd %xmm9,%xmm15
  8211ef:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211f5:	movapd 0x1c0(%rsp),%xmm9
  8211ff:	mulsd  %xmm13,%xmm9
  821204:	mulsd  0x1b0(%rsp),%xmm13
  82120e:	movapd 0x2c0(%rsp),%xmm10
  821218:	addsd  %xmm9,%xmm10
  82121d:	addsd  0xc0(%rsp),%xmm10
  821227:	subsd  0x40(%rsp),%xmm10
  82122e:	addsd  %xmm13,%xmm12
  821233:	addsd  0xb0(%rsp),%xmm12
  82123d:	addsd  0x30(%rsp),%xmm12
  821244:	addsd  0x20(%rsp),%xmm12
  82124b:	addsd  -0x7719dc(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821254:	mulsd  -0x771485(%rip),%xmm12        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82125d:	ucomisd %xmm10,%xmm12
  821262:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821268:	movapd %xmm10,%xmm11
  82126d:	movapd 0x10(%rsp),%xmm10
  821274:	subsd  %xmm11,%xmm10
  821279:	ucomisd %xmm10,%xmm12
  82127e:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821284:	movsd  0x168(%rsp),%xmm10
  82128e:	addsd  %xmm3,%xmm10
  821293:	addsd  0x120(%rsp),%xmm10
  82129d:	subsd  0x80(%rsp),%xmm10
  8212a7:	movsd  0x160(%rsp),%xmm11
  8212b1:	addsd  %xmm2,%xmm11
  8212b6:	addsd  0x110(%rsp),%xmm11
  8212c0:	addsd  0x70(%rsp),%xmm11
  8212c7:	addsd  0x60(%rsp),%xmm11
  8212ce:	addsd  -0x771a5f(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212d7:	mulsd  -0x771ae0(%rip),%xmm11        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8212e0:	addsd  0x8(%rsp),%xmm11
  8212e7:	ucomisd %xmm10,%xmm11
  8212ec:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8212f2:	movapd %xmm4,%xmm15
  8212f7:	movapd 0x50(%rsp),%xmm2
  8212fd:	subsd  %xmm10,%xmm2
  821302:	ucomisd %xmm2,%xmm11
  821307:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82130d:	addsd  %xmm7,%xmm15
  821312:	addsd  0x100(%rsp),%xmm15
  82131c:	subsd  0x80(%rsp),%xmm15
  821326:	movsd  0x158(%rsp),%xmm2
  82132f:	addsd  %xmm5,%xmm2
  821333:	addsd  0xf0(%rsp),%xmm2
  82133c:	addsd  0x70(%rsp),%xmm2
  821342:	addsd  0x60(%rsp),%xmm2
  821348:	addsd  -0x771ad8(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821350:	mulsd  -0x771580(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821358:	ucomisd %xmm15,%xmm2
  82135d:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821363:	movapd %xmm2,%xmm3
  821367:	movapd 0x50(%rsp),%xmm2
  82136d:	subsd  %xmm15,%xmm2
  821372:	ucomisd %xmm2,%xmm3
  821376:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82137c:	movsd  0x150(%rsp),%xmm2
  821385:	addsd  %xmm8,%xmm2
  82138a:	addsd  0xd0(%rsp),%xmm2
  821393:	subsd  0x40(%rsp),%xmm2
  821399:	movsd  0x130(%rsp),%xmm5
  8213a2:	addsd  0x140(%rsp),%xmm5
  8213ab:	addsd  0xe0(%rsp),%xmm5
  8213b4:	addsd  0x30(%rsp),%xmm5
  8213ba:	addsd  0x20(%rsp),%xmm5
  8213c0:	addsd  -0x771b50(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213c8:	mulsd  -0x771bd0(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8213d0:	addsd  (%rsp),%xmm5
  8213d5:	ucomisd %xmm2,%xmm5
  8213d9:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213df:	movapd %xmm2,%xmm3
  8213e3:	movapd 0x10(%rsp),%xmm2
  8213e9:	subsd  %xmm3,%xmm2
  8213ed:	ucomisd %xmm2,%xmm5
  8213f1:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213f7:	movapd 0x290(%rsp),%xmm2
  821400:	addsd  %xmm9,%xmm2
  821405:	addsd  0xc0(%rsp),%xmm2
  82140e:	subsd  0x40(%rsp),%xmm2
  821414:	addsd  %xmm13,%xmm6
  821419:	addsd  0xb0(%rsp),%xmm6
  821422:	addsd  0x30(%rsp),%xmm6
  821428:	addsd  0x20(%rsp),%xmm6
  82142e:	addsd  -0x771bbe(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821436:	mulsd  -0x771666(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82143e:	ucomisd %xmm2,%xmm6
  821442:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821448:	movapd %xmm2,%xmm3
  82144c:	movapd 0x10(%rsp),%xmm2
  821452:	subsd  %xmm3,%xmm2
  821456:	ucomisd %xmm2,%xmm6
  82145a:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821460:	cmp    %rsi,%rcx
  821463:	jae    821538 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc8>
  821469:	mov    0xac(%rsp),%eax
  821470:	mov    %eax,(%r12,%rcx,8)
  821474:	movl   $0x80000001,0x4(%r12,%rcx,8)
  82147d:	movsd  0x98(%rsp),%xmm14
  821487:	cmp    %r11,%rdi
  82148a:	jb     820af7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x587>
  821490:	mov    0x198(%rsp),%r10
  821498:	cmp    %r10,0x1a0(%rsp)
  8214a0:	jae    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8214a6:	cmp    %r10,%rbx
  8214a9:	jbe    820a20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4b0>
  8214af:	jmp    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8214b4:	mov    %rbx,%rax
  8214b7:	nopw   0x0(%rax,%rax,1)
  8214c0:	cmp    %r10,%rbx
  8214c3:	adc    $0x0,%rax
  8214c7:	mov    %rbx,%rdx
  8214ca:	imul   %r9,%rdx
  8214ce:	mov    0xa0(%rsp),%rdi
  8214d6:	cs nopw 0x0(%rax,%rax,1)
  8214e0:	lea    (%rdi,%rdx,1),%rcx
  8214e4:	cmp    %rsi,%rcx
  8214e7:	jae    82151b <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  8214e9:	cmp    %r11,%rdi
  8214ec:	mov    %rdi,%r8
  8214ef:	adc    $0x0,%r8
  8214f3:	incl   0x4(%r12,%rcx,8)
  8214f8:	cmp    %r11,%rdi
  8214fb:	jae    821505 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf95>
  8214fd:	mov    %r8,%rdi
  821500:	cmp    %r11,%r8
  821503:	jbe    8214e0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf70>
  821505:	cmp    %r10,%rbx
  821508:	jae    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82150e:	mov    %rax,%rbx
  821511:	cmp    %r10,%rax
  821514:	jbe    8214c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf50>
  821516:	jmp    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82151b:	lea    0x60cca6(%rip),%rdx        # e2e1c8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  821522:	mov    %rcx,%rdi
  821525:	call   *0x65e605(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
  82152b:	lea    0x60cd86(%rip),%rdi        # e2e2b8 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.264339216088034180+0x10>
  821532:	call   *0x65e768(%rip)        # e7fca0 <_DYNAMIC+0x668>
  821538:	lea    0x60cca1(%rip),%rdx        # e2e1e0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  82153f:	mov    %rcx,%rdi
  821542:	call   *0x65e5e8(%rip)        # e7fb30 <_DYNAMIC+0x4f8>

FUNCTION gpui_gpu::renderer::compact_group bytes=68 frame=88

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000821550 <gpui_gpu::renderer::compact_group>:
  821550:	xor    %eax,%eax
  821552:	test   %esi,%esi
  821554:	je     821593 <gpui_gpu::renderer::compact_group+0x43>
  821556:	cmpq   $0x2,0x10(%rdi)
  82155b:	jb     821593 <gpui_gpu::renderer::compact_group+0x43>
  82155d:	sub    $0x58,%rsp
  821561:	mov    (%rdi),%rsi
  821564:	mov    0x8(%rdi),%rax
  821568:	mov    (%rax),%edx
  82156a:	mov    %rsp,%rdi
  82156d:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  821572:	movss  0x4(%rsp),%xmm0
  821578:	cmpb   $0x3,(%rsp)
  82157c:	setne  %cl
  82157f:	xorps  %xmm1,%xmm1
  821582:	ucomiss %xmm1,%xmm0
  821585:	setnp  %dl
  821588:	sete   %al
  82158b:	and    %dl,%al
  82158d:	or     %cl,%al
  82158f:	add    $0x58,%rsp
  821593:	ret

FUNCTION gpui_gpu::renderer::validate_draw bytes=1600 frame=168

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008215a0 <gpui_gpu::renderer::validate_draw>:
  8215a0:	push   %rbp
  8215a1:	push   %r15
  8215a3:	push   %r14
  8215a5:	push   %r12
  8215a7:	push   %rbx
  8215a8:	sub    $0x80,%rsp
  8215af:	mov    %r8d,%ebp
  8215b2:	mov    %ecx,%r12d
  8215b5:	mov    %rdx,%r14
  8215b8:	mov    %rsi,%r15
  8215bb:	mov    %rdi,%rbx
  8215be:	movups 0x88(%rsi),%xmm0
  8215c5:	movaps %xmm0,0x20(%rsp)
  8215ca:	movaps %xmm0,0x70(%rsp)
  8215cf:	lea    0x70(%rsp),%rdi
  8215d4:	call   *0x65e6ce(%rip)        # e7fca8 <_DYNAMIC+0x670>
  8215da:	movaps 0x20(%rsp),%xmm4
  8215df:	test   %al,%al
  8215e1:	je     821637 <gpui_gpu::renderer::validate_draw+0x97>
  8215e3:	movaps %xmm4,%xmm0
  8215e6:	unpckhpd %xmm4,%xmm0
  8215ea:	xorps  %xmm2,%xmm2
  8215ed:	ucomiss %xmm2,%xmm0
  8215f0:	jne    8215f4 <gpui_gpu::renderer::validate_draw+0x54>
  8215f2:	jnp    821637 <gpui_gpu::renderer::validate_draw+0x97>
  8215f4:	movaps %xmm4,%xmm1
  8215f7:	shufps $0xff,%xmm4,%xmm1
  8215fb:	ucomiss %xmm2,%xmm1
  8215fe:	jne    821602 <gpui_gpu::renderer::validate_draw+0x62>
  821600:	jnp    821637 <gpui_gpu::renderer::validate_draw+0x97>
  821602:	xorps  %xmm3,%xmm3
  821605:	ucomiss %xmm4,%xmm3
  821608:	ja     821637 <gpui_gpu::renderer::validate_draw+0x97>
  82160a:	movaps %xmm4,%xmm2
  82160d:	shufps $0x55,%xmm4,%xmm2
  821611:	ucomiss %xmm2,%xmm3
  821614:	ja     821637 <gpui_gpu::renderer::validate_draw+0x97>
  821616:	xorps  %xmm3,%xmm3
  821619:	cvtsi2ss %r12d,%xmm3
  82161e:	addss  %xmm4,%xmm0
  821622:	ucomiss %xmm3,%xmm0
  821625:	ja     821637 <gpui_gpu::renderer::validate_draw+0x97>
  821627:	xorps  %xmm0,%xmm0
  82162a:	cvtsi2ss %ebp,%xmm0
  82162e:	addss  %xmm1,%xmm2
  821632:	ucomiss %xmm0,%xmm2
  821635:	jbe    82164d <gpui_gpu::renderer::validate_draw+0xad>
  821637:	movl   $0x3,(%rbx)
  82163d:	add    $0x80,%rsp
  821644:	pop    %rbx
  821645:	pop    %r12
  821647:	pop    %r14
  821649:	pop    %r15
  82164b:	pop    %rbp
  82164c:	ret
  82164d:	movsd  0x48(%r15),%xmm9
  821653:	movsd  0x60(%r15),%xmm1
  821659:	movupd 0x50(%r15),%xmm2
  82165f:	movapd %xmm2,%xmm5
  821663:	shufpd $0x1,%xmm2,%xmm5
  821668:	movupd 0x68(%r15),%xmm0
  82166e:	cvtpd2ps %xmm5,%xmm8
  821673:	movapd %xmm9,%xmm4
  821678:	unpcklpd %xmm1,%xmm4
  82167c:	cvtpd2ps %xmm4,%xmm7
  821680:	cvtpd2ps %xmm0,%xmm6
  821684:	movapd %xmm6,%xmm3
  821688:	shufps $0x55,%xmm6,%xmm3
  82168c:	movd   %xmm3,%ecx
  821690:	movd   %xmm6,%eax
  821694:	movapd %xmm7,%xmm3
  821698:	shufps $0x14,%xmm8,%xmm3
  82169d:	shufps $0x78,%xmm3,%xmm3
  8216a1:	andps  -0x773f28(%rip),%xmm3        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8216a8:	and    $0x7fffffff,%eax
  8216ad:	cmp    $0x7f800000,%eax
  8216b2:	setge  %al
  8216b5:	and    $0x7fffffff,%ecx
  8216bb:	cmp    $0x7f800000,%ecx
  8216c1:	setge  %cl
  8216c4:	pcmpgtd -0x77601c(%rip),%xmm3        # ab6b0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x70>
  8216cc:	movmskps %xmm3,%edx
  8216cf:	test   %edx,%edx
  8216d1:	jne    821722 <gpui_gpu::renderer::validate_draw+0x182>
  8216d3:	test   %al,%al
  8216d5:	jne    821722 <gpui_gpu::renderer::validate_draw+0x182>
  8216d7:	test   %cl,%cl
  8216d9:	jne    821722 <gpui_gpu::renderer::validate_draw+0x182>
  8216db:	movapd %xmm9,%xmm3
  8216e0:	mulsd  %xmm1,%xmm3
  8216e4:	movapd %xmm2,%xmm10
  8216e9:	mulsd  %xmm5,%xmm10
  8216ee:	subsd  %xmm10,%xmm3
  8216f3:	xorpd  %xmm10,%xmm10
  8216f8:	ucomisd %xmm10,%xmm3
  8216fd:	jne    821701 <gpui_gpu::renderer::validate_draw+0x161>
  8216ff:	jnp    821722 <gpui_gpu::renderer::validate_draw+0x182>
  821701:	movq   %xmm3,%rcx
  821706:	movabs $0x7fffffffffffffff,%rax
  821710:	and    %rax,%rcx
  821713:	movabs $0x7ff0000000000000,%rdx
  82171d:	cmp    %rdx,%rcx
  821720:	jl     821731 <gpui_gpu::renderer::validate_draw+0x191>
  821722:	movl   $0x5,(%rbx)
  821728:	mov    %r14,0x8(%rbx)
  82172c:	jmp    82163d <gpui_gpu::renderer::validate_draw+0x9d>
  821731:	xorps  %xmm10,%xmm10
  821735:	cvtsi2sd %r12d,%xmm10
  82173a:	cvtsi2sd %ebp,%xmm12
  82173f:	movsd  %xmm9,%xmm2
  821744:	movapd -0x77699d(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  82174d:	andpd  %xmm13,%xmm2
  821752:	movapd %xmm10,%xmm11
  821757:	unpcklpd %xmm12,%xmm11
  82175c:	movapd %xmm2,%xmm9
  821761:	movapd %xmm11,0x50(%rsp)
  821768:	mulpd  %xmm11,%xmm9
  82176d:	movapd %xmm9,%xmm11
  821772:	unpckhpd %xmm9,%xmm11
  821777:	addsd  %xmm9,%xmm11
  82177c:	movapd %xmm0,%xmm9
  821781:	andpd  %xmm13,%xmm9
  821786:	addsd  %xmm11,%xmm9
  82178b:	shufpd $0x2,%xmm5,%xmm1
  821790:	andpd  %xmm13,%xmm1
  821795:	unpcklpd %xmm10,%xmm12
  82179a:	movapd %xmm1,%xmm10
  82179f:	movapd %xmm12,0x40(%rsp)
  8217a6:	mulpd  %xmm12,%xmm10
  8217ab:	movapd %xmm10,%xmm11
  8217b0:	unpckhpd %xmm10,%xmm11
  8217b5:	addsd  %xmm9,%xmm11
  8217ba:	addsd  %xmm10,%xmm11
  8217bf:	movapd %xmm0,%xmm10
  8217c4:	unpckhpd %xmm0,%xmm10
  8217c9:	andpd  %xmm13,%xmm10
  8217ce:	addsd  %xmm11,%xmm10
  8217d3:	movsd  0x38(%r15),%xmm9
  8217d9:	movsd  0x40(%r15),%xmm12
  8217df:	andps  -0x774067(%rip),%xmm9        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  8217e7:	cvtps2pd %xmm9,%xmm15
  8217eb:	movapd %xmm10,%xmm9
  8217f0:	addsd  %xmm15,%xmm9
  8217f5:	movapd %xmm15,0x60(%rsp)
  8217fc:	unpckhpd %xmm15,%xmm15
  821801:	addsd  %xmm15,%xmm9
  821806:	cvtps2pd %xmm12,%xmm11
  82180a:	movapd %xmm11,0x20(%rsp)
  821811:	andpd  %xmm13,%xmm11
  821816:	addsd  %xmm11,%xmm9
  82181b:	pshufd $0xee,%xmm11,%xmm14
  821821:	movdqa %xmm14,0x30(%rsp)
  821828:	addsd  %xmm14,%xmm9
  82182d:	movq   %xmm9,%rsi
  821832:	and    %rax,%rsi
  821835:	movabs $0x7fefffffffffffff,%rcx
  82183f:	cmp    %rcx,%rsi
  821842:	jg     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821848:	ucomisd -0x772239(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821851:	ja     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821857:	movzbl (%r15),%esi
  82185b:	cmp    $0x3,%esi
  82185e:	je     821876 <gpui_gpu::renderer::validate_draw+0x2d6>
  821860:	xorpd  %xmm14,%xmm14
  821865:	cmp    $0x1,%esi
  821868:	jne    8219a2 <gpui_gpu::renderer::validate_draw+0x402>
  82186e:	movss  0x4(%r15),%xmm14
  821874:	jmp    82188d <gpui_gpu::renderer::validate_draw+0x2ed>
  821876:	movss  0x4(%r15),%xmm14
  82187c:	xorpd  %xmm13,%xmm13
  821881:	ucomiss %xmm13,%xmm14
  821885:	jne    82188d <gpui_gpu::renderer::validate_draw+0x2ed>
  821887:	jnp    821ac7 <gpui_gpu::renderer::validate_draw+0x527>
  82188d:	movd   %xmm14,%edi
  821892:	test   %edi,%edi
  821894:	sets   %r8b
  821898:	and    $0x7fffffff,%edi
  82189e:	lea    -0x800000(%rdi),%r9d
  8218a5:	cmp    $0x7f000000,%r9d
  8218ac:	setb   %r9b
  8218b0:	and    %r8b,%r9b
  8218b3:	lea    -0x1(%rdi),%r10d
  8218b7:	cmp    $0x7fffff,%r10d
  8218be:	setb   %r10b
  8218c2:	and    %r8b,%r10b
  8218c5:	cmp    $0x7f800000,%edi
  8218cb:	sete   %dil
  8218cf:	setg   %r8b
  8218d3:	or     %dil,%r8b
  8218d6:	or     %r10b,%r8b
  8218d9:	or     %r9b,%r8b
  8218dc:	cmp    $0x1,%r8b
  8218e0:	je     821637 <gpui_gpu::renderer::validate_draw+0x97>
  8218e6:	movaps %xmm11,(%rsp)
  8218eb:	movaps %xmm14,%xmm11
  8218ef:	movaps %xmm14,0x10(%rsp)
  8218f5:	movaps %xmm12,%xmm14
  8218f9:	mulss  -0x772996(%rip),%xmm14        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821902:	minss  %xmm14,%xmm11
  821907:	movaps %xmm11,%xmm14
  82190b:	cmpunordss %xmm11,%xmm14
  821911:	movaps %xmm14,%xmm13
  821915:	andnps %xmm11,%xmm13
  821919:	andps  0x10(%rsp),%xmm14
  82191f:	orps   %xmm13,%xmm14
  821923:	shufps $0x55,%xmm12,%xmm12
  821928:	mulss  -0x7729c5(%rip),%xmm12        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  821931:	movaps %xmm14,%xmm11
  821935:	minss  %xmm12,%xmm11
  82193a:	movaps %xmm11,%xmm12
  82193e:	cmpunordss %xmm11,%xmm12
  821944:	andps  %xmm12,%xmm14
  821948:	andnps %xmm11,%xmm12
  82194c:	orps   %xmm14,%xmm12
  821950:	movss  -0x772709(%rip),%xmm11        # af250 <anon.4109cdd7ddb1990ee57d5626700ecb68.286.llvm.4479275319843201559+0xc>
  821959:	ucomiss %xmm12,%xmm11
  82195d:	ja     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821963:	xorps  %xmm14,%xmm14
  821967:	cvtss2sd %xmm12,%xmm14
  82196c:	movapd %xmm9,%xmm11
  821971:	divsd  %xmm14,%xmm11
  821976:	ucomisd -0x7720ff(%rip),%xmm11        # af880 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x10>
  82197f:	ja     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821985:	addsd  %xmm9,%xmm14
  82198a:	mulsd  -0x77226b(%rip),%xmm14        # af728 <anon.4109cdd7ddb1990ee57d5626700ecb68.92.llvm.4479275319843201559+0x10>
  821993:	movapd (%rsp),%xmm11
  821999:	movapd -0x776bf2(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  8219a2:	cmp    $0x2,%esi
  8219a5:	movaps %xmm11,(%rsp)
  8219aa:	jae    821abb <gpui_gpu::renderer::validate_draw+0x51b>
  8219b0:	cvtps2pd %xmm8,%xmm8
  8219b4:	subpd  %xmm8,%xmm5
  8219b9:	cvtps2pd %xmm7,%xmm7
  8219bc:	andpd  %xmm13,%xmm5
  8219c1:	mulpd  0x40(%rsp),%xmm5
  8219c7:	subpd  %xmm7,%xmm4
  8219cb:	andpd  %xmm13,%xmm4
  8219d0:	mulpd  0x50(%rsp),%xmm4
  8219d6:	addpd  %xmm5,%xmm4
  8219da:	cvtps2pd %xmm6,%xmm5
  8219dd:	subpd  %xmm5,%xmm0
  8219e1:	addsd  -0x772172(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8219ea:	mulsd  -0x771fab(%rip),%xmm10        # afa48 <anon.4109cdd7ddb1990ee57d5626700ecb68.350.llvm.4479275319843201559+0x18>
  8219f3:	andpd  %xmm13,%xmm0
  8219f8:	addpd  %xmm4,%xmm0
  8219fc:	movapd 0x60(%rsp),%xmm7
  821a02:	addsd  %xmm7,%xmm15
  821a07:	movapd (%rsp),%xmm6
  821a0c:	addsd  %xmm6,%xmm15
  821a11:	addsd  0x30(%rsp),%xmm15
  821a18:	movapd %xmm0,%xmm4
  821a1c:	unpckhpd %xmm0,%xmm4
  821a20:	addpd  %xmm0,%xmm4
  821a24:	movapd %xmm1,%xmm5
  821a28:	shufpd $0x1,%xmm4,%xmm5
  821a2d:	movapd %xmm2,%xmm4
  821a31:	unpcklpd %xmm10,%xmm4
  821a36:	addpd  %xmm4,%xmm5
  821a3a:	mulsd  -0x7723eb(%rip),%xmm15        # af658 <anon.a16d5d421a76dfd8c37a17b53540311d.77.llvm.14190004212411149437+0x10>
  821a43:	shufpd $0x1,%xmm15,%xmm2
  821a49:	addpd  %xmm5,%xmm2
  821a4d:	unpcklpd %xmm14,%xmm1
  821a52:	addpd  %xmm2,%xmm1
  821a56:	movapd %xmm1,%xmm2
  821a5a:	unpckhpd %xmm1,%xmm2
  821a5e:	mulsd  %xmm1,%xmm2
  821a62:	andpd  -0x776cba(%rip),%xmm3        # aadb0 <GCC_except_table0+0xb8>
  821a6a:	divsd  %xmm3,%xmm2
  821a6e:	movq   %xmm2,%rdx
  821a73:	and    %rax,%rdx
  821a76:	cmp    %rcx,%rdx
  821a79:	jg     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821a7f:	ucomisd -0x771bdf(%rip),%xmm2        # afea8 <anon.a16d5d421a76dfd8c37a17b53540311d.26.llvm.14190004212411149437+0x10>
  821a87:	ja     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821a8d:	unpcklpd %xmm10,%xmm10
  821a92:	addpd  %xmm10,%xmm0
  821a97:	addpd  %xmm7,%xmm6
  821a9b:	mulpd  -0x776b13(%rip),%xmm6        # aaf90 <anon.068260129a360d3c14a88deb110120c9.101.llvm.7357624670875813013+0x1d0>
  821aa3:	addpd  %xmm0,%xmm6
  821aa7:	cvtpd2ps %xmm6,%xmm0
  821aab:	movlpd %xmm0,0x4(%rbx)
  821ab0:	movl   $0xffffffff,(%rbx)
  821ab6:	jmp    82163d <gpui_gpu::renderer::validate_draw+0x9d>
  821abb:	jne    821ad0 <gpui_gpu::renderer::validate_draw+0x530>
  821abd:	mov    0x28(%r15),%rsi
  821ac1:	mov    0x30(%r15),%rdi
  821ac5:	jmp    821ad8 <gpui_gpu::renderer::validate_draw+0x538>
  821ac7:	movaps %xmm11,(%rsp)
  821acc:	xorps  %xmm14,%xmm14
  821ad0:	mov    0x28(%r15),%esi
  821ad4:	mov    0x2c(%r15),%edi
  821ad8:	movq   %rsi,%xmm11
  821add:	punpckldq -0x776216(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821ae6:	subpd  -0x776d4f(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821aef:	movapd %xmm11,%xmm12
  821af4:	unpckhpd %xmm11,%xmm12
  821af9:	addsd  %xmm11,%xmm12
  821afe:	movapd 0x20(%rsp),%xmm11
  821b05:	divsd  %xmm11,%xmm12
  821b0a:	movq   %xmm12,%r8
  821b0f:	and    %rax,%r8
  821b12:	cmp    %rdx,%r8
  821b15:	jge    821722 <gpui_gpu::renderer::validate_draw+0x182>
  821b1b:	movaps %xmm14,0x10(%rsp)
  821b21:	movapd %xmm11,%xmm14
  821b26:	movq   %rdi,%xmm11
  821b2b:	punpckldq -0x776264(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821b34:	subpd  -0x776d9d(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821b3d:	movapd %xmm11,%xmm13
  821b42:	unpckhpd %xmm11,%xmm13
  821b47:	addsd  %xmm11,%xmm13
  821b4c:	unpckhpd %xmm14,%xmm14
  821b51:	divsd  %xmm14,%xmm13
  821b56:	movapd 0x10(%rsp),%xmm14
  821b5d:	movq   %xmm13,%rdx
  821b62:	and    %rax,%rdx
  821b65:	cmp    %rcx,%rdx
  821b68:	setg   %dl
  821b6b:	ucomisd -0x77255c(%rip),%xmm13        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821b74:	movapd -0x776dcd(%rip),%xmm13        # aadb0 <GCC_except_table0+0xb8>
  821b7d:	ja     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821b83:	ucomisd -0x772574(%rip),%xmm12        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821b8c:	ja     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821b92:	test   %dl,%dl
  821b94:	jne    821722 <gpui_gpu::renderer::validate_draw+0x182>
  821b9a:	cmp    %rsi,%rdi
  821b9d:	cmova  %rdi,%rsi
  821ba1:	movq   %rsi,%xmm11
  821ba6:	punpckldq -0x7762df(%rip),%xmm11        # ab8d0 <anon.4109cdd7ddb1990ee57d5626700ecb68.391.llvm.4479275319843201559+0x290>
  821baf:	subpd  -0x776e18(%rip),%xmm11        # aada0 <GCC_except_table0+0xa8>
  821bb8:	movapd %xmm11,%xmm12
  821bbd:	unpckhpd %xmm11,%xmm12
  821bc2:	addsd  %xmm11,%xmm12
  821bc7:	mulsd  %xmm12,%xmm9
  821bcc:	ucomisd -0x7725bd(%rip),%xmm9        # af618 <anon.37b98eb2fdb7e423a2bbca0028b9f848.34.llvm.10068956358450262974+0x28>
  821bd5:	ja     821722 <gpui_gpu::renderer::validate_draw+0x182>
  821bdb:	jmp    8219b0 <gpui_gpu::renderer::validate_draw+0x410>

FUNCTION core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>> bytes=105 frame=8

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008222d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>:
  8222d0:	push   %rbx
  8222d1:	test   %rdi,%rdi
  8222d4:	je     822337 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x67>
  8222d6:	mov    %rdi,%rbx
  8222d9:	mov    (%rdi),%rsi
  8222dc:	test   %rsi,%rsi
  8222df:	je     8222f4 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x24>
  8222e1:	mov    0x8(%rbx),%rdi
  8222e5:	shl    $0x3,%rsi
  8222e9:	mov    $0x8,%edx
  8222ee:	call   *0x65d58c(%rip)        # e7f880 <_DYNAMIC+0x248>
  8222f4:	mov    0x20(%rbx),%rsi
  8222f8:	test   %rsi,%rsi
  8222fb:	je     822323 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  8222fd:	mov    %rsi,%rax
  822300:	shl    $0x4,%rax
  822304:	add    %rax,%rsi
  822307:	add    $0x21,%rsi
  82230b:	je     822323 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>+0x53>
  82230d:	mov    0x18(%rbx),%rdi
  822311:	sub    %rax,%rdi
  822314:	add    $0xfffffffffffffff0,%rdi
  822318:	mov    $0x10,%edx
  82231d:	call   *0x65d55d(%rip)        # e7f880 <_DYNAMIC+0x248>
  822323:	mov    $0x80,%esi
  822328:	mov    $0x8,%edx
  82232d:	mov    %rbx,%rdi
  822330:	pop    %rbx
  822331:	jmp    *0x65d549(%rip)        # e7f880 <_DYNAMIC+0x248>
  822337:	pop    %rbx
  822338:	ret

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::Buffer> bytes=103 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822560 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>:
  822560:	push   %r14
  822562:	push   %rbx
  822563:	push   %rax
  822564:	mov    %rdi,%rbx
  822567:	mov    (%rdi),%rax
  82256a:	lock decq (%rax)
  82256e:	jne    822579 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x19>
  822570:	mov    %rbx,%rdi
  822573:	call   *0x65d5c7(%rip)        # e7fb40 <_DYNAMIC+0x508>
  822579:	mov    0x8(%rbx),%rax
  82257d:	lock decq (%rax)
  822581:	jne    822597 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x37>
  822583:	add    $0x8,%rbx
  822587:	mov    %rbx,%rdi
  82258a:	add    $0x8,%rsp
  82258e:	pop    %rbx
  82258f:	pop    %r14
  822591:	jmp    *0x65d5b1(%rip)        # e7fb48 <_DYNAMIC+0x510>
  822597:	add    $0x8,%rsp
  82259b:	pop    %rbx
  82259c:	pop    %r14
  82259e:	ret
  82259f:	mov    %rax,%r14
  8225a2:	mov    0x8(%rbx),%rax
  8225a6:	lock decq (%rax)
  8225aa:	jne    8225b9 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>+0x59>
  8225ac:	add    $0x8,%rbx
  8225b0:	mov    %rbx,%rdi
  8225b3:	call   *0x65d58f(%rip)        # e7fb48 <_DYNAMIC+0x510>
  8225b9:	mov    %r14,%rdi
  8225bc:	call   e2c420 <_Unwind_Resume@plt>
  8225c1:	call   *0x65d2c1(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION core::ptr::drop_glue::<gpui_gpu::renderer::images::Images> bytes=81 frame=8

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822690 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>:
  822690:	push   %rbx
  822691:	mov    %rdi,%rbx
  822694:	mov    (%rdi),%rsi
  822697:	test   %rsi,%rsi
  82269a:	je     8226af <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x1f>
  82269c:	mov    0x8(%rbx),%rdi
  8226a0:	shl    $0x3,%rsi
  8226a4:	mov    $0x8,%edx
  8226a9:	call   *0x65d1d1(%rip)        # e7f880 <_DYNAMIC+0x248>
  8226af:	mov    0x20(%rbx),%rsi
  8226b3:	test   %rsi,%rsi
  8226b6:	je     8226df <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  8226b8:	mov    %rsi,%rax
  8226bb:	shl    $0x4,%rax
  8226bf:	add    %rax,%rsi
  8226c2:	add    $0x21,%rsi
  8226c6:	je     8226df <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>+0x4f>
  8226c8:	mov    0x18(%rbx),%rdi
  8226cc:	sub    %rax,%rdi
  8226cf:	add    $0xfffffffffffffff0,%rdi
  8226d3:	mov    $0x10,%edx
  8226d8:	pop    %rbx
  8226d9:	jmp    *0x65d1a1(%rip)        # e7f880 <_DYNAMIC+0x248>
  8226df:	pop    %rbx
  8226e0:	ret

FUNCTION <gpui_gpu::renderer::images::Images>::metadata bytes=246 frame=40

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008226f0 <<gpui_gpu::renderer::images::Images>::metadata>:
  8226f0:	push   %r15
  8226f2:	push   %r14
  8226f4:	push   %rbx
  8226f5:	sub    $0x10,%rsp
  8226f9:	mov    %rsi,0x8(%rsp)
  8226fe:	cmpq   $0x0,0x30(%rdi)
  822703:	je     8227cd <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  822709:	mov    %edx,%ebx
  82270b:	mov    %rsi,%r14
  82270e:	mov    %rdi,%r15
  822711:	add    $0x38,%rdi
  822715:	lea    0x8(%rsp),%rsi
  82271a:	call   821f90 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82271f:	mov    %rax,%rsi
  822722:	shr    $0x39,%rsi
  822726:	mov    0x18(%r15),%rcx
  82272a:	mov    0x20(%r15),%rdx
  82272e:	movd   %esi,%xmm0
  822732:	punpcklbw %xmm0,%xmm0
  822736:	pshuflw $0x0,%xmm0,%xmm0
  82273b:	pshufd $0x44,%xmm0,%xmm0
  822740:	xor    %esi,%esi
  822742:	pcmpeqd %xmm1,%xmm1
  822746:	and    %rdx,%rax
  822749:	movdqu (%rcx,%rax,1),%xmm2
  82274e:	movdqa %xmm2,%xmm3
  822752:	pcmpeqb %xmm0,%xmm3
  822756:	pmovmskb %xmm3,%edi
  82275a:	test   %edi,%edi
  82275c:	je     822790 <<gpui_gpu::renderer::images::Images>::metadata+0xa0>
  82275e:	tzcnt  %edi,%r9d
  822763:	add    %rax,%r9
  822766:	and    %rdx,%r9
  822769:	shl    $0x4,%r9
  82276d:	mov    %rcx,%r8
  822770:	sub    %r9,%r8
  822773:	cmp    -0x10(%r8),%r14
  822777:	je     8227a9 <<gpui_gpu::renderer::images::Images>::metadata+0xb9>
  822779:	lea    -0x1(%rdi),%r8d
  82277d:	and    %di,%r8w
  822781:	mov    %r8d,%edi
  822784:	jne    82275e <<gpui_gpu::renderer::images::Images>::metadata+0x6e>
  822786:	cs nopw 0x0(%rax,%rax,1)
  822790:	pcmpeqb %xmm1,%xmm2
  822794:	pmovmskb %xmm2,%edi
  822798:	test   %edi,%edi
  82279a:	jne    8227cd <<gpui_gpu::renderer::images::Images>::metadata+0xdd>
  82279c:	add    %rsi,%rax
  82279f:	add    $0x10,%rax
  8227a3:	add    $0x10,%rsi
  8227a7:	jmp    822746 <<gpui_gpu::renderer::images::Images>::metadata+0x56>
  8227a9:	mov    -0x8(%r8),%eax
  8227ad:	movzbl %bl,%ecx
  8227b0:	or     -0x4(%r8),%ecx
  8227b4:	shl    $0x20,%rcx
  8227b8:	or     %rax,%rcx
  8227bb:	mov    $0x80000000,%eax
  8227c0:	or     %rcx,%rax
  8227c3:	add    $0x10,%rsp
  8227c7:	pop    %rbx
  8227c8:	pop    %r14
  8227ca:	pop    %r15
  8227cc:	ret
  8227cd:	lea    -0x74d82c(%rip),%rdi        # d4fa8 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  8227d4:	lea    0x60baf5(%rip),%rdx        # e2e2d0 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456>
  8227db:	mov    $0x16,%esi
  8227e0:	call   *0x65d3f2(%rip)        # e7fbd8 <_DYNAMIC+0x5a0>

FUNCTION gpui_gpu::renderer::images::prepare bytes=2648 frame=536

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000822a60 <gpui_gpu::renderer::images::prepare>:
  822a60:	push   %rbp
  822a61:	push   %r15
  822a63:	push   %r14
  822a65:	push   %r13
  822a67:	push   %r12
  822a69:	push   %rbx
  822a6a:	sub    $0x1e8,%rsp
  822a71:	mov    %r9,%r12
  822a74:	mov    %rcx,%r13
  822a77:	mov    %rdx,0xb0(%rsp)
  822a7f:	mov    %rsi,(%rsp)
  822a83:	mov    %rdi,%r15
  822a86:	mov    0x220(%rsp),%rax
  822a8e:	mov    0x10(%rax),%r14
  822a92:	mov    0x118(%r14),%rax
  822a99:	add    $0x118,%r14
  822aa0:	test   %rax,%rax
  822aa3:	mov    %r14,%rcx
  822aa6:	cmove  %rax,%rcx
  822aaa:	je     822b3c <gpui_gpu::renderer::images::prepare+0xdc>
  822ab0:	mov    0x10(%rax),%rax
  822ab4:	mov    (%r8),%rbp
  822ab7:	mov    %rax,0x10(%rsp)
  822abc:	test   %rax,%rax
  822abf:	je     822b3f <gpui_gpu::renderer::images::prepare+0xdf>
  822ac1:	mov    %rcx,0xa0(%rsp)
  822ac9:	test   %rbp,%rbp
  822acc:	je     822c88 <gpui_gpu::renderer::images::prepare+0x228>
  822ad2:	cmp    0x48(%rbp),%r12
  822ad6:	ja     822c88 <gpui_gpu::renderer::images::prepare+0x228>
  822adc:	mov    0x8(%rbp),%rdi
  822ae0:	mov    0x10(%rbp),%rax
  822ae4:	lea    (%rdi,%rax,8),%rsi
  822ae8:	movq   $0x1,0xd0(%rsp)
  822af4:	mov    %r14,0xd8(%rsp)
  822afc:	movq   $0x0,0xe0(%rsp)
  822b08:	movq   $0x0,0xf0(%rsp)
  822b14:	lea    0xd0(%rsp),%rdx
  822b1c:	mov    %r8,%rbx
  822b1f:	call   8259a0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>
  822b24:	mov    %rbx,%r8
  822b27:	test   %al,%al
  822b29:	je     822c88 <gpui_gpu::renderer::images::prepare+0x228>
  822b2f:	movq   $0x0,0x60(%rbp)
  822b37:	jmp    822c6c <gpui_gpu::renderer::images::prepare+0x20c>
  822b3c:	mov    (%r8),%rbp
  822b3f:	movq   $0x0,(%r8)
  822b46:	test   %rbp,%rbp
  822b49:	je     822c6c <gpui_gpu::renderer::images::prepare+0x20c>
  822b4f:	mov    0x0(%rbp),%rsi
  822b53:	test   %rsi,%rsi
  822b56:	je     822b6b <gpui_gpu::renderer::images::prepare+0x10b>
  822b58:	mov    0x8(%rbp),%rdi
  822b5c:	shl    $0x3,%rsi
  822b60:	mov    $0x8,%edx
  822b65:	call   *0x65cd15(%rip)        # e7f880 <_DYNAMIC+0x248>
  822b6b:	mov    0x20(%rbp),%rsi
  822b6f:	test   %rsi,%rsi
  822b72:	je     822b9a <gpui_gpu::renderer::images::prepare+0x13a>
  822b74:	mov    %rsi,%rax
  822b77:	shl    $0x4,%rax
  822b7b:	add    %rax,%rsi
  822b7e:	add    $0x21,%rsi
  822b82:	je     822b9a <gpui_gpu::renderer::images::prepare+0x13a>
  822b84:	mov    0x18(%rbp),%rdi
  822b88:	sub    %rax,%rdi
  822b8b:	add    $0xfffffffffffffff0,%rdi
  822b8f:	mov    $0x10,%edx
  822b94:	call   *0x65cce6(%rip)        # e7f880 <_DYNAMIC+0x248>
  822b9a:	mov    $0x80,%esi
  822b9f:	mov    $0x8,%edx
  822ba4:	mov    %rbp,%rdi
  822ba7:	call   *0x65ccd3(%rip)        # e7f880 <_DYNAMIC+0x248>
  822bad:	shl    $0x4,%r12
  822bb1:	cmp    $0x101,%r12
  822bb8:	mov    $0x100,%eax
  822bbd:	cmovae %r12,%rax
  822bc1:	dec    %rax
  822bc4:	bsr    %rax,%rcx
  822bc8:	not    %ecx
  822bca:	mov    $0xffffffffffffffff,%rbx
  822bd1:	shr    %cl,%rbx
  822bd4:	inc    %rbx
  822bd7:	lea    -0x74dc20(%rip),%rax        # d4fbe <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x16>
  822bde:	mov    %rax,0x18(%rsp)
  822be3:	movq   $0xa,0x20(%rsp)
  822bec:	mov    %rbx,0x28(%rsp)
  822bf1:	movl   $0x88,0x30(%rsp)
  822bf9:	movb   $0x0,0x34(%rsp)
  822bfe:	lea    0xd0(%rsp),%rdi
  822c06:	lea    0x18(%rsp),%rdx
  822c0b:	mov    (%rsp),%rsi
  822c0f:	call   *0x65d03b(%rip)        # e7fc50 <_DYNAMIC+0x618>
  822c15:	mov    %rbx,0xf0(%rsp)
  822c1d:	mov    0x0(%r13),%rax
  822c21:	lock decq (%rax)
  822c25:	jne    822c30 <gpui_gpu::renderer::images::prepare+0x1d0>
  822c27:	mov    %r13,%rdi
  822c2a:	call   *0x65cf10(%rip)        # e7fb40 <_DYNAMIC+0x508>
  822c30:	mov    0x8(%r13),%rax
  822c34:	lock decq (%rax)
  822c38:	jne    822c44 <gpui_gpu::renderer::images::prepare+0x1e4>
  822c3a:	lea    0x8(%r13),%rdi
  822c3e:	call   *0x65cf04(%rip)        # e7fb48 <_DYNAMIC+0x510>
  822c44:	mov    0xf0(%rsp),%rax
  822c4c:	mov    %rax,0x20(%r13)
  822c50:	movdqu 0xd0(%rsp),%xmm0
  822c59:	movups 0xe0(%rsp),%xmm1
  822c61:	movups %xmm1,0x10(%r13)
  822c66:	movdqu %xmm0,0x0(%r13)
  822c6c:	movl   $0xffffffff,(%r15)
  822c73:	mov    %r15,%rax
  822c76:	add    $0x1e8,%rsp
  822c7d:	pop    %rbx
  822c7e:	pop    %r12
  822c80:	pop    %r13
  822c82:	pop    %r14
  822c84:	pop    %r15
  822c86:	pop    %rbp
  822c87:	ret
  822c88:	cmp    $0x1,%r12
  822c8c:	mov    %r12,%rax
  822c8f:	adc    $0xffffffffffffffff,%rax
  822c93:	bsr    %rax,%rcx
  822c97:	not    %ecx
  822c99:	mov    $0xffffffffffffffff,%rax
  822ca0:	shr    %cl,%rax
  822ca3:	cmp    $0x2,%r12
  822ca7:	mov    $0x0,%r12d
  822cad:	cmovae %rax,%r12
  822cb1:	inc    %r12
  822cb4:	je     8233a8 <gpui_gpu::renderer::images::prepare+0x948>
  822cba:	mov    %r8,0xc8(%rsp)
  822cc2:	mov    %fs:0x0,%rax
  822ccb:	lea    -0x28(%rax),%rax
  822cd2:	mov    %rax,%rcx
  822cd5:	cmpb   $0x1,0x10(%rax)
  822cd9:	mov    %r15,0xa8(%rsp)
  822ce1:	mov    %r13,0x8(%rsp)
  822ce6:	jne    8233b4 <gpui_gpu::renderer::images::prepare+0x954>
  822cec:	mov    (%rcx),%rax
  822cef:	mov    0x8(%rcx),%rdx
  822cf3:	mov    0x10(%rsp),%rbx
  822cf8:	lea    0x1(%rax),%rsi
  822cfc:	mov    %rsi,(%rcx)
  822cff:	movq   $0x0,0x18(%rsp)
  822d08:	movq   $0x8,0x20(%rsp)
  822d11:	movq   $0x0,0x28(%rsp)
  822d1a:	movups 0x60b5c7(%rip),%xmm0        # e2e2e8 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x18>
  822d21:	movups %xmm0,0x30(%rsp)
  822d26:	movdqu 0x60b5ca(%rip),%xmm0        # e2e2f8 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x28>
  822d2e:	movdqu %xmm0,0x40(%rsp)
  822d34:	mov    %rax,0x50(%rsp)
  822d39:	mov    %rdx,0x58(%rsp)
  822d3e:	mov    %r12,0x60(%rsp)
  822d43:	pxor   %xmm0,%xmm0
  822d47:	movdqu %xmm0,0x68(%rsp)
  822d4d:	movdqu %xmm0,0x78(%rsp)
  822d53:	movdqu %xmm0,0x88(%rsp)
  822d5c:	lea    0xd0(%rsp),%rdi
  822d64:	mov    $0x8,%edx
  822d69:	mov    $0x8,%r8d
  822d6f:	mov    $0x8,%r9d
  822d75:	xor    %esi,%esi
  822d77:	mov    %rbx,%rcx
  822d7a:	call   823d90 <<alloc::raw_vec::RawVecInner>::finish_grow>
  822d7f:	cmpl   $0x1,0xd0(%rsp)
  822d87:	jne    822df4 <gpui_gpu::renderer::images::prepare+0x394>
  822d89:	mov    0xa8(%rsp),%r15
  822d91:	movl   $0x6,(%r15)
  822d98:	mov    0x18(%rsp),%rsi
  822d9d:	test   %rsi,%rsi
  822da0:	je     822db6 <gpui_gpu::renderer::images::prepare+0x356>
  822da2:	mov    0x20(%rsp),%rdi
  822da7:	shl    $0x3,%rsi
  822dab:	mov    $0x8,%edx
  822db0:	call   *0x65caca(%rip)        # e7f880 <_DYNAMIC+0x248>
  822db6:	mov    0x38(%rsp),%rsi
  822dbb:	test   %rsi,%rsi
  822dbe:	je     822c73 <gpui_gpu::renderer::images::prepare+0x213>
  822dc4:	mov    %rsi,%rax
  822dc7:	shl    $0x4,%rax
  822dcb:	add    %rax,%rsi
  822dce:	add    $0x21,%rsi
  822dd2:	je     822c73 <gpui_gpu::renderer::images::prepare+0x213>
  822dd8:	mov    0x30(%rsp),%rdi
  822ddd:	sub    %rax,%rdi
  822de0:	add    $0xfffffffffffffff0,%rdi
  822de4:	mov    $0x10,%edx
  822de9:	call   *0x65ca91(%rip)        # e7f880 <_DYNAMIC+0x248>
  822def:	jmp    822c73 <gpui_gpu::renderer::images::prepare+0x213>
  822df4:	mov    %r12,0x98(%rsp)
  822dfc:	mov    %rbp,0xc0(%rsp)
  822e04:	mov    0xd8(%rsp),%rax
  822e0c:	mov    %rax,0x20(%rsp)
  822e11:	mov    %rbx,0x18(%rsp)
  822e16:	cmp    0x40(%rsp),%rbx
  822e1b:	ja     8233d0 <gpui_gpu::renderer::images::prepare+0x970>
  822e21:	xor    %r12d,%r12d
  822e24:	mov    0x98(%rsp),%r15
  822e2c:	jmp    822e48 <gpui_gpu::renderer::images::prepare+0x3e8>
  822e2e:	xchg   %ax,%ax
  822e30:	add    $0x8,%r12
  822e34:	mov    0x20(%rsp),%rax
  822e39:	mov    %rbx,(%rax,%r15,8)
  822e3d:	inc    %r15
  822e40:	mov    %r15,0x28(%rsp)
  822e45:	mov    %r13,%r15
  822e48:	test   %r12,%r12
  822e4b:	je     822e70 <gpui_gpu::renderer::images::prepare+0x410>
  822e4d:	cmp    %rbp,%r12
  822e50:	je     822e70 <gpui_gpu::renderer::images::prepare+0x410>
  822e52:	mov    (%r12),%rcx
  822e56:	cmpb   $0x0,0x10(%rcx)
  822e5a:	je     822e9e <gpui_gpu::renderer::images::prepare+0x43e>
  822e5c:	mov    0x20(%rcx),%rax
  822e60:	shl    $0x4,%rax
  822e64:	mov    $0x8,%r8d
  822e6a:	jmp    822eb1 <gpui_gpu::renderer::images::prepare+0x451>
  822e6c:	nopl   0x0(%rax)
  822e70:	test   %r14,%r14
  822e73:	je     822f38 <gpui_gpu::renderer::images::prepare+0x4d8>
  822e79:	mov    (%r14),%rax
  822e7c:	mov    0x10(%rax),%rcx
  822e80:	test   %rcx,%rcx
  822e83:	je     822f38 <gpui_gpu::renderer::images::prepare+0x4d8>
  822e89:	mov    0x8(%rax),%r12
  822e8d:	lea    (%r12,%rcx,8),%rbp
  822e91:	xor    %r14d,%r14d
  822e94:	mov    (%r12),%rcx
  822e98:	cmpb   $0x0,0x10(%rcx)
  822e9c:	jne    822e5c <gpui_gpu::renderer::images::prepare+0x3fc>
  822e9e:	movzbl 0x11(%rcx),%edx
  822ea2:	movzbl 0x12(%rcx),%esi
  822ea6:	mov    0x20(%rcx),%rax
  822eaa:	shl    $0x2,%edx
  822ead:	lea    (%rdx,%rsi,2),%r8d
  822eb1:	mov    0x70(%rsp),%rdx
  822eb6:	add    %rax,%rdx
  822eb9:	jb     822d89 <gpui_gpu::renderer::images::prepare+0x329>
  822ebf:	mov    0x28(%rcx),%rbx
  822ec3:	mov    %rdx,0x70(%rsp)
  822ec8:	cmp    $0x4000000,%rdx
  822ecf:	ja     822d89 <gpui_gpu::renderer::images::prepare+0x329>
  822ed5:	mov    %r15,%rcx
  822ed8:	shr    $0x20,%rcx
  822edc:	jne    822d89 <gpui_gpu::renderer::images::prepare+0x329>
  822ee2:	test   %r15d,%r15d
  822ee5:	js     822d89 <gpui_gpu::renderer::images::prepare+0x329>
  822eeb:	mov    %rax,%r13
  822eee:	shr    $0x4,%r13
  822ef2:	and    $0xf,%eax
  822ef5:	add    %r15,%r13
  822ef8:	cmp    $0x1,%rax
  822efc:	sbb    $0xffffffffffffffff,%r13
  822f00:	lea    0xd0(%rsp),%rdi
  822f08:	lea    0x30(%rsp),%rsi
  822f0d:	mov    %rbx,%rdx
  822f10:	mov    %r15d,%ecx
  822f13:	call   823810 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>
  822f18:	mov    0x28(%rsp),%r15
  822f1d:	cmp    0x18(%rsp),%r15
  822f22:	jne    822e30 <gpui_gpu::renderer::images::prepare+0x3d0>
  822f28:	lea    0x18(%rsp),%rdi
  822f2d:	call   *0x65cd9d(%rip)        # e7fcd0 <_DYNAMIC+0x698>
  822f33:	jmp    822e30 <gpui_gpu::renderer::images::prepare+0x3d0>
  822f38:	movabs $0xffffffffffffff0,%rax
  822f42:	cmp    %rax,%r15
  822f45:	ja     822d89 <gpui_gpu::renderer::images::prepare+0x329>
  822f4b:	lea    0xd0(%rsp),%rdi
  822f53:	mov    (%rsp),%rsi
  822f57:	call   *0x65cd7b(%rip)        # e7fcd8 <_DYNAMIC+0x6a0>
  822f5d:	mov    %r15,%rbx
  822f60:	shl    $0x4,%rbx
  822f64:	add    $0xff,%rbx
  822f6b:	and    $0xffffffffffffff00,%rbx
  822f72:	cmp    0x120(%rsp),%rbx
  822f7a:	ja     822d89 <gpui_gpu::renderer::images::prepare+0x329>
  822f80:	lea    0xd0(%rsp),%rdi
  822f88:	mov    (%rsp),%rsi
  822f8c:	call   *0x65cd46(%rip)        # e7fcd8 <_DYNAMIC+0x6a0>
  822f92:	cmp    0x130(%rsp),%rbx
  822f9a:	ja     822d89 <gpui_gpu::renderer::images::prepare+0x329>
  822fa0:	mov    0x8(%rsp),%rax
  822fa5:	mov    0x20(%rax),%rax
  822fa9:	cmp    %rbx,%rax
  822fac:	jb     822fd4 <gpui_gpu::renderer::images::prepare+0x574>
  822fae:	lea    0x0(,%rbx,4),%rcx
  822fb6:	movabs $0x3fffffffffffff1,%rdx
  822fc0:	cmp    %rdx,%r15
  822fc3:	setb   %dl
  822fc6:	cmp    %rcx,%rax
  822fc9:	seta   %al
  822fcc:	test   %al,%dl
  822fce:	je     823062 <gpui_gpu::renderer::images::prepare+0x602>
  822fd4:	lea    -0x74e013(%rip),%rax        # d4fc8 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456+0x20>
  822fdb:	mov    %rax,0x1c8(%rsp)
  822fe3:	movq   $0x1d,0x1d0(%rsp)
  822fef:	mov    %rbx,0x1d8(%rsp)
  822ff7:	movl   $0x88,0x1e0(%rsp)
  823002:	movb   $0x0,0x1e4(%rsp)
  82300a:	lea    0xd0(%rsp),%rdi
  823012:	lea    0x1c8(%rsp),%rdx
  82301a:	mov    (%rsp),%rsi
  82301e:	call   *0x65cc2c(%rip)        # e7fc50 <_DYNAMIC+0x618>
  823024:	mov    %rbx,0xf0(%rsp)
  82302c:	mov    0x8(%rsp),%r14
  823031:	mov    %r14,%rdi
  823034:	call   822560 <core::ptr::drop_glue::<gpui_gpu::renderer::Buffer>>
  823039:	mov    0xf0(%rsp),%rax
  823041:	mov    %rax,0x20(%r14)
  823045:	movdqu 0xd0(%rsp),%xmm0
  82304e:	movdqu 0xe0(%rsp),%xmm1
  823057:	movdqu %xmm1,0x10(%r14)
  82305d:	movdqu %xmm0,(%r14)
  823062:	movq   $0x0,(%rsp)
  82306a:	mov    0x65cb97(%rip),%r14        # e7fc08 <_DYNAMIC+0x5d0>
  823071:	mov    (%rsp),%rdx
  823075:	test   %rdx,%rdx
  823078:	je     823084 <gpui_gpu::renderer::images::prepare+0x624>
  82307a:	cmp    0xb8(%rsp),%rdx
  823082:	jne    8230c1 <gpui_gpu::renderer::images::prepare+0x661>
  823084:	mov    0xa0(%rsp),%rax
  82308c:	test   %rax,%rax
  82308f:	je     823244 <gpui_gpu::renderer::images::prepare+0x7e4>
  823095:	mov    (%rax),%rax
  823098:	mov    0x10(%rax),%rcx
  82309c:	test   %rcx,%rcx
  82309f:	je     823244 <gpui_gpu::renderer::images::prepare+0x7e4>
  8230a5:	mov    0x8(%rax),%rdx
  8230a9:	lea    (%rdx,%rcx,8),%rax
  8230ad:	mov    %rax,0xb8(%rsp)
  8230b5:	movq   $0x0,0xa0(%rsp)
  8230c1:	mov    (%rdx),%rax
  8230c4:	mov    0x28(%rax),%r12
  8230c8:	movzbl 0x10(%rax),%ebx
  8230cc:	mov    0x18(%rax),%rbp
  8230d0:	mov    0x20(%rax),%r13
  8230d4:	mov    %r12,0xd0(%rsp)
  8230dc:	cmpq   $0x0,0x48(%rsp)
  8230e2:	je     823229 <gpui_gpu::renderer::images::prepare+0x7c9>
  8230e8:	add    $0x8,%rdx
  8230ec:	mov    %rdx,(%rsp)
  8230f0:	lea    0x50(%rsp),%rdi
  8230f5:	lea    0xd0(%rsp),%rsi
  8230fd:	call   821f90 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  823102:	mov    %rax,%rsi
  823105:	shr    $0x39,%rsi
  823109:	mov    0x30(%rsp),%rcx
  82310e:	mov    0x38(%rsp),%rdx
  823113:	movd   %esi,%xmm0
  823117:	punpcklbw %xmm0,%xmm0
  82311b:	pshuflw $0x0,%xmm0,%xmm0
  823120:	pshufd $0x44,%xmm0,%xmm0
  823125:	xor    %esi,%esi
  823127:	and    %rdx,%rax
  82312a:	movdqu (%rcx,%rax,1),%xmm1
  82312f:	movdqa %xmm1,%xmm2
  823133:	pcmpeqb %xmm0,%xmm2
  823137:	pmovmskb %xmm2,%edi
  82313b:	test   %edi,%edi
  82313d:	je     823167 <gpui_gpu::renderer::images::prepare+0x707>
  82313f:	tzcnt  %edi,%r9d
  823144:	add    %rax,%r9
  823147:	and    %rdx,%r9
  82314a:	shl    $0x4,%r9
  82314e:	mov    %rcx,%r8
  823151:	sub    %r9,%r8
  823154:	cmp    -0x10(%r8),%r12
  823158:	je     823188 <gpui_gpu::renderer::images::prepare+0x728>
  82315a:	lea    -0x1(%rdi),%r8d
  82315e:	and    %di,%r8w
  823162:	mov    %r8d,%edi
  823165:	jne    82313f <gpui_gpu::renderer::images::prepare+0x6df>
  823167:	pcmpeqd %xmm2,%xmm2
  82316b:	pcmpeqb %xmm2,%xmm1
  82316f:	pmovmskb %xmm1,%edi
  823173:	test   %edi,%edi
  823175:	jne    823229 <gpui_gpu::renderer::images::prepare+0x7c9>
  82317b:	add    %rsi,%rax
  82317e:	add    $0x10,%rax
  823182:	add    $0x10,%rsi
  823186:	jmp    823127 <gpui_gpu::renderer::images::prepare+0x6c7>
  823188:	mov    -0x8(%r8),%r12d
  82318c:	shl    $0x4,%r12
  823190:	test   %bl,%bl
  823192:	je     8231e7 <gpui_gpu::renderer::images::prepare+0x787>
  823194:	test   %r13,%r13
  823197:	je     823071 <gpui_gpu::renderer::images::prepare+0x611>
  82319d:	nopl   (%rax)
  8231a0:	cmp    $0x1000,%r13
  8231a7:	mov    $0x1000,%r15d
  8231ad:	cmovb  %r13,%r15
  8231b1:	mov    %r15d,%ebx
  8231b4:	shl    $0x4,%ebx
  8231b7:	mov    0xb0(%rsp),%rdi
  8231bf:	mov    0x8(%rsp),%rsi
  8231c4:	mov    %r12,%rdx
  8231c7:	mov    %rbp,%rcx
  8231ca:	mov    %rbx,%r8
  8231cd:	call   *%r14
  8231d0:	mov    %r15,%rax
  8231d3:	shl    $0x4,%rax
  8231d7:	add    %rax,%rbp
  8231da:	add    %rbx,%r12
  8231dd:	sub    %r15,%r13
  8231e0:	jne    8231a0 <gpui_gpu::renderer::images::prepare+0x740>
  8231e2:	jmp    823071 <gpui_gpu::renderer::images::prepare+0x611>
  8231e7:	test   %r13,%r13
  8231ea:	je     823071 <gpui_gpu::renderer::images::prepare+0x611>
  8231f0:	cmp    $0x10000,%r13
  8231f7:	mov    $0x10000,%ebx
  8231fc:	cmovb  %r13,%rbx
  823200:	mov    0xb0(%rsp),%rdi
  823208:	mov    0x8(%rsp),%rsi
  82320d:	mov    %r12,%rdx
  823210:	mov    %rbp,%rcx
  823213:	mov    %rbx,%r8
  823216:	call   *%r14
  823219:	add    %rbx,%rbp
  82321c:	add    %rbx,%r12
  82321f:	sub    %rbx,%r13
  823222:	jne    8231f0 <gpui_gpu::renderer::images::prepare+0x790>
  823224:	jmp    823071 <gpui_gpu::renderer::images::prepare+0x611>
  823229:	lea    -0x74e288(%rip),%rdi        # d4fa8 <anon.0e6fcc70e21e3189c77400f0a226742f.0.llvm.548032719764101456>
  823230:	lea    0x60b0d1(%rip),%rdx        # e2e308 <anon.0e6fcc70e21e3189c77400f0a226742f.2.llvm.548032719764101456+0x38>
  823237:	mov    $0x16,%esi
  82323c:	call   *0x65c996(%rip)        # e7fbd8 <_DYNAMIC+0x5a0>
  823242:	ud2
  823244:	mov    0x10(%rsp),%rax
  823249:	mov    %rax,0x68(%rsp)
  82324e:	mov    0x70(%rsp),%rax
  823253:	mov    %rax,0x78(%rsp)
  823258:	mov    0x98(%rsp),%rax
  823260:	shl    $0x4,%rax
  823264:	mov    %rax,0x80(%rsp)
  82326c:	mov    0x8(%rsp),%rax
  823271:	mov    0x20(%rax),%rax
  823275:	mov    %rax,0x88(%rsp)
  82327d:	mov    0x40(%rsp),%rax
  823282:	add    0x48(%rsp),%rax
  823287:	mov    %rax,0x90(%rsp)
  82328f:	mov    0x88(%rsp),%rax
  823297:	mov    %rax,0x140(%rsp)
  82329f:	mov    0x90(%rsp),%rax
  8232a7:	mov    %rax,0x148(%rsp)
  8232af:	mov    0x78(%rsp),%rax
  8232b4:	mov    %rax,0x130(%rsp)
  8232bc:	mov    0x80(%rsp),%rax
  8232c4:	mov    %rax,0x138(%rsp)
  8232cc:	movups 0x68(%rsp),%xmm0
  8232d1:	movaps %xmm0,0x120(%rsp)
  8232d9:	movups 0x58(%rsp),%xmm0
  8232de:	movaps %xmm0,0x110(%rsp)
  8232e6:	movups 0x48(%rsp),%xmm0
  8232eb:	movaps %xmm0,0x100(%rsp)
  8232f3:	movups 0x18(%rsp),%xmm0
  8232f8:	movups 0x28(%rsp),%xmm1
  8232fd:	movups 0x38(%rsp),%xmm2
  823302:	movaps %xmm2,0xf0(%rsp)
  82330a:	movaps %xmm1,0xe0(%rsp)
  823312:	movaps %xmm0,0xd0(%rsp)
  82331a:	call   822a30 <alloc::boxed::box_new_uninit>
  82331f:	mov    %rax,%rbx
  823322:	movaps 0x140(%rsp),%xmm0
  82332a:	movups %xmm0,0x70(%rax)
  82332e:	movaps 0x130(%rsp),%xmm0
  823336:	movups %xmm0,0x60(%rax)
  82333a:	movaps 0x120(%rsp),%xmm0
  823342:	movups %xmm0,0x50(%rax)
  823346:	movaps 0x110(%rsp),%xmm0
  82334e:	movups %xmm0,0x40(%rax)
  823352:	movdqa 0xd0(%rsp),%xmm0
  82335b:	movaps 0xe0(%rsp),%xmm1
  823363:	movaps 0xf0(%rsp),%xmm2
  82336b:	movaps 0x100(%rsp),%xmm3
  823373:	movups %xmm3,0x30(%rax)
  823377:	movups %xmm2,0x20(%rax)
  82337b:	movups %xmm1,0x10(%rax)
  82337f:	movdqu %xmm0,(%rax)
  823383:	mov    0xc0(%rsp),%rdi
  82338b:	call   8222d0 <core::ptr::drop_glue::<core::option::Option<alloc::boxed::Box<gpui_gpu::renderer::images::Images>>>>
  823390:	mov    0xc8(%rsp),%rax
  823398:	mov    %rbx,(%rax)
  82339b:	mov    0xa8(%rsp),%r15
  8233a3:	jmp    822c6c <gpui_gpu::renderer::images::prepare+0x20c>
  8233a8:	movl   $0x6,(%r15)
  8233af:	jmp    822c73 <gpui_gpu::renderer::images::prepare+0x213>
  8233b4:	mov    %rcx,%rbx
  8233b7:	call   *0x65c89b(%rip)        # e7fc58 <_DYNAMIC+0x620>
  8233bd:	mov    %rbx,%rcx
  8233c0:	mov    %rax,(%rbx)
  8233c3:	mov    %rdx,0x8(%rbx)
  8233c7:	movb   $0x1,0x10(%rbx)
  8233cb:	jmp    822cf3 <gpui_gpu::renderer::images::prepare+0x293>
  8233d0:	lea    0x30(%rsp),%rdi
  8233d5:	mov    0x10(%rsp),%rsi
  8233da:	lea    0x50(%rsp),%rdx
  8233df:	xor    %ecx,%ecx
  8233e1:	call   *0x65c8f9(%rip)        # e7fce0 <_DYNAMIC+0x6a8>
  8233e7:	cmp    $0xffffffffffffffff,%rax
  8233eb:	jne    822d89 <gpui_gpu::renderer::images::prepare+0x329>
  8233f1:	jmp    822e21 <gpui_gpu::renderer::images::prepare+0x3c1>
  8233f6:	mov    %rax,%rbx
  8233f9:	lea    0xd0(%rsp),%rdi
  823401:	call   822690 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823406:	mov    %rbx,%rdi
  823409:	call   e2c420 <_Unwind_Resume@plt>
  82340e:	mov    %rax,%rbx
  823411:	mov    0xf0(%rsp),%rax
  823419:	mov    %rax,0x20(%r14)
  82341d:	movups 0xd0(%rsp),%xmm0
  823425:	movups 0xe0(%rsp),%xmm1
  82342d:	movups %xmm1,0x10(%r14)
  823432:	movups %xmm0,(%r14)
  823436:	lea    0x18(%rsp),%rdi
  82343b:	call   822690 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  823440:	mov    %rbx,%rdi
  823443:	call   e2c420 <_Unwind_Resume@plt>
  823448:	mov    %r13,%r14
  82344b:	mov    %rax,%rbx
  82344e:	jmp    82346a <gpui_gpu::renderer::images::prepare+0xa0a>
  823450:	mov    %rax,%rbx
  823453:	mov    %r13,%r14
  823456:	mov    0x8(%r13),%rax
  82345a:	lock decq (%rax)
  82345e:	jne    82346a <gpui_gpu::renderer::images::prepare+0xa0a>
  823460:	lea    0x8(%r14),%rdi
  823464:	call   *0x65c6de(%rip)        # e7fb48 <_DYNAMIC+0x510>
  82346a:	mov    0xf0(%rsp),%rax
  823472:	mov    %rax,0x20(%r14)
  823476:	movups 0xd0(%rsp),%xmm0
  82347e:	movups 0xe0(%rsp),%xmm1
  823486:	movups %xmm1,0x10(%r14)
  82348b:	movups %xmm0,(%r14)
  82348f:	mov    %rbx,%rdi
  823492:	call   e2c420 <_Unwind_Resume@plt>
  823497:	call   *0x65c3eb(%rip)        # e7f888 <_DYNAMIC+0x250>
  82349d:	jmp    8234a3 <gpui_gpu::renderer::images::prepare+0xa43>
  82349f:	jmp    8234a3 <gpui_gpu::renderer::images::prepare+0xa43>
  8234a1:	jmp    8234a3 <gpui_gpu::renderer::images::prepare+0xa43>
  8234a3:	mov    %rax,%rbx
  8234a6:	lea    0x18(%rsp),%rdi
  8234ab:	call   822690 <core::ptr::drop_glue::<gpui_gpu::renderer::images::Images>>
  8234b0:	mov    %rbx,%rdi
  8234b3:	call   e2c420 <_Unwind_Resume@plt>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert bytes=489 frame=104

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823620 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert>:
  823620:	push   %rbp
  823621:	push   %r15
  823623:	push   %r14
  823625:	push   %r13
  823627:	push   %r12
  823629:	push   %rbx
  82362a:	sub    $0x38,%rsp
  82362e:	mov    %rcx,%r15
  823631:	mov    %rdx,%r12
  823634:	mov    %rsi,%r14
  823637:	mov    %rdi,%rbx
  82363a:	lea    0x20(%rsi),%r13
  82363e:	mov    %r13,%rdi
  823641:	mov    %rdx,%rsi
  823644:	call   821df0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  823649:	cmpq   $0x0,0x10(%r14)
  82364e:	je     8237d1 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1b1>
  823654:	mov    (%r14),%r11
  823657:	mov    0x8(%r14),%rsi
  82365b:	mov    %rax,%rdx
  82365e:	shr    $0x39,%rdx
  823662:	movd   %edx,%xmm0
  823666:	punpcklbw %xmm0,%xmm0
  82366a:	pshuflw $0x0,%xmm0,%xmm0
  82366f:	pshufd $0x44,%xmm0,%xmm0
  823674:	mov    (%r12),%rcx
  823678:	mov    %rcx,0x8(%rsp)
  82367d:	movzwl 0xc(%r12),%r9d
  823683:	mov    0x8(%r12),%r10d
  823688:	xor    %r13d,%r13d
  82368b:	pcmpeqd %xmm1,%xmm1
  82368f:	xor    %r8d,%r8d
  823692:	and    %rsi,%rax
  823695:	movdqu (%r11,%rax,1),%xmm2
  82369b:	movdqa %xmm2,%xmm3
  82369f:	pcmpeqb %xmm0,%xmm3
  8236a3:	pmovmskb %xmm3,%ebp
  8236a7:	test   %ebp,%ebp
  8236a9:	je     8236f0 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xd0>
  8236ab:	mov    %r8,(%rsp)
  8236af:	mov    %r15,%r8
  8236b2:	tzcnt  %ebp,%r15d
  8236b7:	add    %rax,%r15
  8236ba:	and    %rsi,%r15
  8236bd:	shl    $0x5,%r15
  8236c1:	mov    %r11,%rcx
  8236c4:	sub    %r15,%rcx
  8236c7:	mov    0x8(%rsp),%r15
  8236cc:	cmp    -0x20(%rcx),%r15
  8236d0:	jne    8236df <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8236d2:	cmp    -0x14(%rcx),%r9w
  8236d7:	jne    8236df <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xbf>
  8236d9:	cmp    -0x18(%rcx),%r10d
  8236dd:	je     82372f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x10f>
  8236df:	lea    -0x1(%rbp),%ecx
  8236e2:	and    %bp,%cx
  8236e5:	mov    %ecx,%ebp
  8236e7:	mov    %r8,%r15
  8236ea:	mov    (%rsp),%r8
  8236ee:	jne    8236af <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x8f>
  8236f0:	cmp    $0x1,%r13
  8236f4:	je     823708 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xe8>
  8236f6:	pmovmskb %xmm2,%ecx
  8236fa:	test   %ecx,%ecx
  8236fc:	je     82371c <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xfc>
  8236fe:	tzcnt  %ecx,%edi
  823702:	add    %rax,%rdi
  823705:	and    %rsi,%rdi
  823708:	pcmpeqb %xmm1,%xmm2
  82370c:	pmovmskb %xmm2,%ecx
  823710:	test   %ecx,%ecx
  823712:	jne    823746 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x126>
  823714:	mov    $0x1,%r13d
  82371a:	jmp    82371f <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0xff>
  82371c:	xor    %r13d,%r13d
  82371f:	add    %r8,%rax
  823722:	add    $0x10,%rax
  823726:	add    $0x10,%r8
  82372a:	jmp    823692 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x72>
  82372f:	movups -0x10(%rcx),%xmm0
  823733:	movups %xmm0,0x4(%rbx)
  823737:	movups (%r8),%xmm0
  82373b:	movups %xmm0,-0x10(%rcx)
  82373f:	mov    $0x1,%eax
  823744:	jmp    8237bd <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x19d>
  823746:	movzbl (%r11,%rdi,1),%eax
  82374b:	test   %al,%al
  82374d:	jns    8237f2 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x1d2>
  823753:	movups (%r12),%xmm0
  823758:	movaps %xmm0,0x10(%rsp)
  82375d:	movups (%r15),%xmm0
  823761:	movaps %xmm0,0x20(%rsp)
  823766:	and    $0x1,%al
  823768:	lea    -0x10(%rdi),%rcx
  82376c:	and    %rsi,%rcx
  82376f:	mov    %dl,(%r11,%rdi,1)
  823773:	mov    %dl,0x10(%r11,%rcx,1)
  823778:	movzbl %al,%eax
  82377b:	movd   %eax,%xmm0
  82377f:	shufpd $0x2,-0x7785a8(%rip),%xmm0        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  823788:	movdqu 0x10(%r14),%xmm1
  82378e:	psubq  %xmm0,%xmm1
  823792:	movdqu %xmm1,0x10(%r14)
  823798:	shl    $0x5,%rdi
  82379c:	mov    %r11,%rax
  82379f:	sub    %rdi,%rax
  8237a2:	neg    %rdi
  8237a5:	movaps 0x10(%rsp),%xmm0
  8237aa:	movdqa 0x20(%rsp),%xmm1
  8237b0:	movups %xmm0,-0x20(%r11,%rdi,1)
  8237b6:	movdqu %xmm1,-0x10(%rax)
  8237bb:	xor    %eax,%eax
  8237bd:	mov    %eax,(%rbx)
  8237bf:	mov    %rbx,%rax
  8237c2:	add    $0x38,%rsp
  8237c6:	pop    %rbx
  8237c7:	pop    %r12
  8237c9:	pop    %r13
  8237cb:	pop    %r14
  8237cd:	pop    %r15
  8237cf:	pop    %rbp
  8237d0:	ret
  8237d1:	mov    $0x1,%esi
  8237d6:	mov    %r14,%rdi
  8237d9:	mov    %r13,%rdx
  8237dc:	mov    $0x1,%ecx
  8237e1:	mov    %rax,%r13
  8237e4:	call   *0x65c52e(%rip)        # e7fd18 <_DYNAMIC+0x6e0>
  8237ea:	mov    %r13,%rax
  8237ed:	jmp    823654 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x34>
  8237f2:	movdqa (%r11),%xmm0
  8237f7:	pmovmskb %xmm0,%eax
  8237fb:	tzcnt  %eax,%edi
  8237ff:	movzbl (%r11,%rdi,1),%eax
  823804:	jmp    823753 <<hashbrown::map::HashMap<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>>::insert+0x133>

FUNCTION <hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert bytes=428 frame=56

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823810 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert>:
  823810:	push   %rbp
  823811:	push   %r15
  823813:	push   %r14
  823815:	push   %r13
  823817:	push   %r12
  823819:	push   %rbx
  82381a:	push   %rax
  82381b:	mov    %r8d,%ebp
  82381e:	mov    %ecx,%r14d
  823821:	mov    %rdx,%r15
  823824:	mov    %rsi,%r12
  823827:	mov    %rdi,%rbx
  82382a:	mov    %rdx,(%rsp)
  82382e:	lea    0x20(%rsi),%r13
  823832:	mov    %rsp,%rsi
  823835:	mov    %r13,%rdi
  823838:	call   821f90 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  82383d:	cmpq   $0x0,0x10(%r12)
  823843:	je     823986 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x176>
  823849:	mov    (%r12),%rcx
  82384d:	mov    0x8(%r12),%rsi
  823852:	mov    %rax,%rdx
  823855:	shr    $0x39,%rdx
  823859:	movd   %edx,%xmm0
  82385d:	punpcklbw %xmm0,%xmm0
  823861:	pshuflw $0x0,%xmm0,%xmm0
  823866:	pshufd $0x44,%xmm0,%xmm0
  82386b:	xor    %r9d,%r9d
  82386e:	pcmpeqd %xmm1,%xmm1
  823872:	xor    %r8d,%r8d
  823875:	and    %rsi,%rax
  823878:	movdqu (%rcx,%rax,1),%xmm2
  82387d:	movdqa %xmm2,%xmm3
  823881:	pcmpeqb %xmm0,%xmm3
  823885:	pmovmskb %xmm3,%r10d
  82388a:	test   %r10d,%r10d
  82388d:	je     8238c0 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xb0>
  82388f:	tzcnt  %r10d,%r13d
  823894:	add    %rax,%r13
  823897:	and    %rsi,%r13
  82389a:	shl    $0x4,%r13
  82389e:	mov    %rcx,%r11
  8238a1:	sub    %r13,%r11
  8238a4:	cmp    -0x10(%r11),%r15
  8238a8:	je     823901 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xf1>
  8238aa:	lea    -0x1(%r10),%r11d
  8238ae:	and    %r10w,%r11w
  8238b2:	mov    %r11d,%r10d
  8238b5:	jne    82388f <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x7f>
  8238b7:	nopw   0x0(%rax,%rax,1)
  8238c0:	cmp    $0x1,%r9
  8238c4:	je     8238d8 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xc8>
  8238c6:	pmovmskb %xmm2,%edi
  8238ca:	test   %edi,%edi
  8238cc:	je     8238ee <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xde>
  8238ce:	tzcnt  %edi,%edi
  8238d2:	add    %rax,%rdi
  8238d5:	and    %rsi,%rdi
  8238d8:	pcmpeqb %xmm1,%xmm2
  8238dc:	pmovmskb %xmm2,%r9d
  8238e1:	test   %r9d,%r9d
  8238e4:	jne    823918 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x108>
  8238e6:	mov    $0x1,%r9d
  8238ec:	jmp    8238f1 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0xe1>
  8238ee:	xor    %r9d,%r9d
  8238f1:	add    %r8,%rax
  8238f4:	add    $0x10,%rax
  8238f8:	add    $0x10,%r8
  8238fc:	jmp    823875 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x65>
  823901:	mov    -0x8(%r11),%rax
  823905:	mov    %r14d,-0x8(%r11)
  823909:	mov    %ebp,-0x4(%r11)
  82390d:	mov    %rax,0x4(%rbx)
  823911:	mov    $0x1,%eax
  823916:	jmp    823972 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x162>
  823918:	movzbl (%rcx,%rdi,1),%eax
  82391c:	test   %al,%al
  82391e:	jns    8239a7 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x197>
  823924:	and    $0x1,%al
  823926:	lea    -0x10(%rdi),%r8
  82392a:	and    %rsi,%r8
  82392d:	mov    %dl,(%rcx,%rdi,1)
  823930:	mov    %dl,0x10(%rcx,%r8,1)
  823935:	movdqu 0x10(%r12),%xmm0
  82393c:	movzbl %al,%eax
  82393f:	movd   %eax,%xmm1
  823943:	shufpd $0x2,-0x77876c(%rip),%xmm1        # ab1e0 <anon.a16d5d421a76dfd8c37a17b53540311d.51.llvm.14190004212411149437+0xe0>
  82394c:	psubq  %xmm1,%xmm0
  823950:	movdqu %xmm0,0x10(%r12)
  823957:	shl    $0x4,%rdi
  82395b:	mov    %rcx,%rax
  82395e:	sub    %rdi,%rax
  823961:	neg    %rdi
  823964:	mov    %r15,-0x10(%rcx,%rdi,1)
  823969:	mov    %r14d,-0x8(%rax)
  82396d:	mov    %ebp,-0x4(%rax)
  823970:	xor    %eax,%eax
  823972:	mov    %eax,(%rbx)
  823974:	mov    %rbx,%rax
  823977:	add    $0x8,%rsp
  82397b:	pop    %rbx
  82397c:	pop    %r12
  82397e:	pop    %r13
  823980:	pop    %r14
  823982:	pop    %r15
  823984:	pop    %rbp
  823985:	ret
  823986:	mov    $0x1,%esi
  82398b:	mov    %r12,%rdi
  82398e:	mov    %r13,%rdx
  823991:	mov    $0x1,%ecx
  823996:	mov    %rax,%r13
  823999:	call   *0x65c341(%rip)        # e7fce0 <_DYNAMIC+0x6a8>
  82399f:	mov    %r13,%rax
  8239a2:	jmp    823849 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x39>
  8239a7:	movdqa (%rcx),%xmm0
  8239ab:	pmovmskb %xmm0,%eax
  8239af:	tzcnt  %eax,%edi
  8239b3:	movzbl (%rcx,%rdi,1),%eax
  8239b7:	jmp    823924 <<hashbrown::map::HashMap<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>>::insert+0x114>

FUNCTION <alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one bytes=100 frame=40

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000823d20 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one>:
  823d20:	push   %r14
  823d22:	push   %rbx
  823d23:	sub    $0x18,%rsp
  823d27:	mov    %rdi,%rbx
  823d2a:	mov    (%rdi),%rsi
  823d2d:	lea    (%rsi,%rsi,1),%rax
  823d31:	cmp    $0x5,%rax
  823d35:	mov    $0x4,%r14d
  823d3b:	cmovae %rax,%r14
  823d3f:	mov    0x8(%rdi),%rdx
  823d43:	mov    %rsp,%rdi
  823d46:	mov    $0x4,%r8d
  823d4c:	mov    $0x20,%r9d
  823d52:	mov    %r14,%rcx
  823d55:	call   823d90 <<alloc::raw_vec::RawVecInner>::finish_grow>
  823d5a:	cmpl   $0x1,(%rsp)
  823d5e:	je     823d74 <<alloc::raw_vec::RawVec<gpui_gpu::renderer::Correction>>::grow_one+0x54>
  823d60:	mov    0x8(%rsp),%rax
  823d65:	mov    %rax,0x8(%rbx)
  823d69:	mov    %r14,(%rbx)
  823d6c:	add    $0x18,%rsp
  823d70:	pop    %rbx
  823d71:	pop    %r14
  823d73:	ret
  823d74:	mov    0x8(%rsp),%rdi
  823d79:	mov    0x10(%rsp),%rsi
  823d7e:	call   *0x65bb3c(%rip)        # e7f8c0 <_DYNAMIC+0x288>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}> bytes=1602 frame=136

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824780 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>>:
  824780:	push   %rbp
  824781:	push   %r15
  824783:	push   %r14
  824785:	push   %r13
  824787:	push   %r12
  824789:	push   %rbx
  82478a:	sub    $0x58,%rsp
  82478e:	mov    %ecx,%ebp
  824790:	mov    %rdx,0x8(%rsp)
  824795:	mov    0x18(%rdi),%rax
  824799:	add    %rax,%rsi
  82479c:	jb     8248b1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  8247a2:	mov    %rdi,%rbx
  8247a5:	mov    0x8(%rdi),%r15
  8247a9:	lea    0x1(%r15),%rdx
  8247ad:	mov    %rdx,%rdi
  8247b0:	shr    $0x3,%rdi
  8247b4:	mov    %rdx,%rcx
  8247b7:	and    $0xfffffffffffffff8,%rcx
  8247bb:	sub    %rdi,%rcx
  8247be:	cmp    $0x8,%r15
  8247c2:	cmovb  %r15,%rcx
  8247c6:	mov    %rcx,%rdi
  8247c9:	shr    $1,%rdi
  8247cc:	cmp    %rdi,%rsi
  8247cf:	jbe    824800 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x80>
  8247d1:	inc    %rcx
  8247d4:	cmp    %rsi,%rcx
  8247d7:	cmovbe %rsi,%rcx
  8247db:	cmp    $0xf,%rcx
  8247df:	mov    %rbx,(%rsp)
  8247e3:	jae    824831 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0xb1>
  8247e5:	mov    %ecx,%eax
  8247e7:	and    $0x8,%eax
  8247ea:	add    $0x8,%rax
  8247ee:	cmp    $0x4,%rcx
  8247f2:	mov    $0x4,%ebx
  8247f7:	cmovae %rax,%rbx
  8247fb:	jmp    824889 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x109>
  824800:	test   %rdx,%rdx
  824803:	je     824a8a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x30a>
  824809:	mov    (%rbx),%rsi
  82480c:	mov    %rdx,%rax
  82480f:	shr    $0x4,%rax
  824813:	mov    %edx,%ecx
  824815:	and    $0xf,%ecx
  824818:	cmp    $0x1,%rcx
  82481c:	sbb    $0xffffffffffffffff,%rax
  824820:	cmp    $0x1,%rax
  824824:	jne    824a91 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x311>
  82482a:	xor    %ecx,%ecx
  82482c:	jmp    824ae4 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x364>
  824831:	movabs $0x1ffffffffffffffe,%rax
  82483b:	inc    %rax
  82483e:	cmp    %rax,%rcx
  824841:	ja     8248b1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824843:	shl    $0x3,%rcx
  824847:	movabs $0x2492492492492493,%rdx
  824851:	mov    %rcx,%rax
  824854:	mul    %rdx
  824857:	sub    %rdx,%rcx
  82485a:	shr    $1,%rcx
  82485d:	add    %rdx,%rcx
  824860:	shr    $0x2,%rcx
  824864:	dec    %rcx
  824867:	bsr    %rcx,%rcx
  82486b:	not    %ecx
  82486d:	mov    $0xffffffffffffffff,%rbx
  824874:	shr    %cl,%rbx
  824877:	movabs $0x7fffffffffffffe,%rax
  824881:	cmp    %rax,%rbx
  824884:	ja     8248b1 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x131>
  824886:	inc    %rbx
  824889:	mov    %rbx,%r14
  82488c:	shl    $0x5,%r14
  824890:	lea    0x10(%rbx),%r12
  824894:	mov    %r12,%r13
  824897:	add    %r14,%r13
  82489a:	setb   %al
  82489d:	movabs $0x7ffffffffffffff0,%rcx
  8248a7:	cmp    %rcx,%r13
  8248aa:	seta   %cl
  8248ad:	or     %al,%cl
  8248af:	je     8248c0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x140>
  8248b1:	movzbl %bpl,%edi
  8248b5:	call   *0x65b49d(%rip)        # e7fd58 <_DYNAMIC+0x720>
  8248bb:	jmp    824d05 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  8248c0:	call   *0x65b002(%rip)        # e7f8c8 <_DYNAMIC+0x290>
  8248c6:	mov    $0x10,%esi
  8248cb:	mov    %r13,%rdi
  8248ce:	call   *0x65affc(%rip)        # e7f8d0 <_DYNAMIC+0x298>
  8248d4:	test   %rax,%rax
  8248d7:	je     824d23 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5a3>
  8248dd:	mov    %rax,%r15
  8248e0:	mov    (%rsp),%rcx
  8248e4:	lea    0x20(%rcx),%r13
  8248e8:	add    %r14,%r15
  8248eb:	lea    -0x1(%rbx),%r14
  8248ef:	mov    %rbx,%rax
  8248f2:	shr    $0x3,%rax
  8248f6:	mov    %rbx,%rbp
  8248f9:	and    $0xfffffffffffffff8,%rbp
  8248fd:	sub    %rax,%rbp
  824900:	cmp    $0x9,%rbx
  824904:	mov    %rcx,%rbx
  824907:	cmovb  %r14,%rbp
  82490b:	mov    %r15,%rdi
  82490e:	mov    $0xff,%esi
  824913:	mov    %r12,%rdx
  824916:	call   *0x65b444(%rip)        # e7fd60 <memset@GLIBC_2.2.5>
  82491c:	mov    %r14,%rdi
  82491f:	mov    %r13,0x20(%rsp)
  824924:	movq   $0x20,0x28(%rsp)
  82492d:	movq   $0x10,0x30(%rsp)
  824936:	mov    %r15,0x38(%rsp)
  82493b:	mov    %r14,0x40(%rsp)
  824940:	mov    %rbp,0x48(%rsp)
  824945:	movq   $0x0,0x50(%rsp)
  82494e:	mov    0x18(%rbx),%r12
  824952:	test   %r12,%r12
  824955:	je     824d37 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5b7>
  82495b:	mov    %rbp,0x10(%rsp)
  824960:	mov    (%rbx),%rsi
  824963:	movdqa (%rsi),%xmm0
  824967:	pmovmskb %xmm0,%r13d
  82496c:	not    %r13d
  82496f:	xor    %ebp,%ebp
  824971:	mov    %rsi,%r14
  824974:	mov    %rdi,0x18(%rsp)
  824979:	nopl   0x0(%rax)
  824980:	test   %r13w,%r13w
  824984:	jne    8249af <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x22f>
  824986:	cs nopw 0x0(%rax,%rax,1)
  824990:	movdqa 0x10(%r14),%xmm0
  824996:	add    $0x10,%r14
  82499a:	pmovmskb %xmm0,%r13d
  82499f:	xor    $0xffff,%r13d
  8249a6:	add    $0x10,%rbp
  8249aa:	test   %r13d,%r13d
  8249ad:	je     824990 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x210>
  8249af:	tzcnt  %r13d,%ebx
  8249b4:	add    %rbp,%rbx
  8249b7:	mov    %rbx,%rax
  8249ba:	shl    $0x5,%rax
  8249be:	sub    %rax,%rsi
  8249c1:	add    $0xffffffffffffffe0,%rsi
  8249c5:	mov    0x8(%rsp),%rdi
  8249ca:	call   821df0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  8249cf:	mov    %rax,%rdx
  8249d2:	mov    0x18(%rsp),%rdi
  8249d7:	and    %rdi,%rdx
  8249da:	movdqu (%r15,%rdx,1),%xmm0
  8249e0:	pmovmskb %xmm0,%ecx
  8249e4:	test   %ecx,%ecx
  8249e6:	je     824a55 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  8249e8:	tzcnt  %ecx,%ecx
  8249ec:	add    %rdx,%rcx
  8249ef:	and    %rdi,%rcx
  8249f2:	cmpb   $0x0,(%r15,%rcx,1)
  8249f7:	jns    824a78 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2f8>
  8249f9:	lea    -0x1(%r13),%edx
  8249fd:	and    %r13d,%edx
  824a00:	dec    %r12
  824a03:	shr    $0x39,%rax
  824a07:	lea    -0x10(%rcx),%rsi
  824a0b:	and    %rdi,%rsi
  824a0e:	mov    %al,(%r15,%rcx,1)
  824a12:	mov    %al,0x10(%r15,%rsi,1)
  824a17:	mov    (%rsp),%rax
  824a1b:	mov    (%rax),%rsi
  824a1e:	not    %rbx
  824a21:	shl    $0x5,%rbx
  824a25:	not    %rcx
  824a28:	shl    $0x5,%rcx
  824a2c:	movdqu (%rsi,%rbx,1),%xmm0
  824a31:	movdqu 0x10(%rsi,%rbx,1),%xmm1
  824a37:	movdqu %xmm1,0x10(%r15,%rcx,1)
  824a3e:	movdqu %xmm0,(%r15,%rcx,1)
  824a44:	mov    %edx,%r13d
  824a47:	test   %r12,%r12
  824a4a:	jne    824980 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x200>
  824a50:	jmp    824d14 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x594>
  824a55:	mov    $0x10,%esi
  824a5a:	add    %rsi,%rdx
  824a5d:	and    %rdi,%rdx
  824a60:	movdqu (%r15,%rdx,1),%xmm0
  824a66:	pmovmskb %xmm0,%ecx
  824a6a:	add    $0x10,%rsi
  824a6e:	test   %ecx,%ecx
  824a70:	jne    8249e8 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x268>
  824a76:	jmp    824a5a <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x2da>
  824a78:	movdqa (%r15),%xmm0
  824a7d:	pmovmskb %xmm0,%ecx
  824a81:	tzcnt  %ecx,%ecx
  824a85:	jmp    8249f9 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x279>
  824a8a:	xor    %ecx,%ecx
  824a8c:	jmp    824cf7 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x577>
  824a91:	movabs $0x1ffffffffffffffe,%rdi
  824a9b:	and    %rax,%rdi
  824a9e:	xor    %ecx,%ecx
  824aa0:	movdqa -0x776f08(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824aa8:	nopl   0x0(%rax,%rax,1)
  824ab0:	pxor   %xmm1,%xmm1
  824ab4:	pcmpgtb (%rsi,%rcx,1),%xmm1
  824ab9:	por    %xmm0,%xmm1
  824abd:	movdqa %xmm1,(%rsi,%rcx,1)
  824ac2:	pxor   %xmm1,%xmm1
  824ac6:	pcmpgtb 0x10(%rsi,%rcx,1),%xmm1
  824acc:	por    %xmm0,%xmm1
  824ad0:	movdqa %xmm1,0x10(%rsi,%rcx,1)
  824ad6:	add    $0x20,%rcx
  824ada:	add    $0xfffffffffffffffe,%rdi
  824ade:	jne    824ab0 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x330>
  824ae0:	test   $0x1,%al
  824ae2:	je     824afa <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x37a>
  824ae4:	pxor   %xmm0,%xmm0
  824ae8:	pcmpgtb (%rsi,%rcx,1),%xmm0
  824aed:	por    -0x776f55(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  824af5:	movdqa %xmm0,(%rsi,%rcx,1)
  824afa:	cmp    $0x10,%rdx
  824afe:	jb     824d88 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x608>
  824b04:	mov    %rdx,%rdi
  824b07:	mov    $0x10,%edx
  824b0c:	add    %rsi,%rdi
  824b0f:	call   *0x65b253(%rip)        # e7fd68 <memmove@GLIBC_2.2.5>
  824b15:	movq   $0x0,0x28(%rsp)
  824b1e:	movq   $0x20,0x30(%rsp)
  824b27:	mov    %rbx,0x20(%rsp)
  824b2c:	xor    %r12d,%r12d
  824b2f:	xor    %r13d,%r13d
  824b32:	jmp    824c81 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x501>
  824b37:	nopw   0x0(%rax,%rax,1)
  824b40:	lea    (%rax,%rbp,1),%rsi
  824b44:	add    $0xffffffffffffffe0,%rsi
  824b48:	mov    0x8(%rsp),%rdi
  824b4d:	call   821df0 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::text::GlyphKey>>
  824b52:	mov    (%rbx),%rcx
  824b55:	mov    0x8(%rbx),%rdx
  824b59:	mov    %rdx,%rsi
  824b5c:	and    %rax,%rsi
  824b5f:	movdqu (%rcx,%rsi,1),%xmm0
  824b64:	pmovmskb %xmm0,%edi
  824b68:	mov    %rsi,%r8
  824b6b:	test   %edi,%edi
  824b6d:	je     824c19 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x499>
  824b73:	tzcnt  %edi,%edi
  824b77:	add    %r8,%rdi
  824b7a:	and    %rdx,%rdi
  824b7d:	cmpb   $0x0,(%rcx,%rdi,1)
  824b81:	jns    824c40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4c0>
  824b87:	mov    %r12,%r8
  824b8a:	sub    %rsi,%r8
  824b8d:	mov    %rdi,%r9
  824b90:	sub    %rsi,%r9
  824b93:	xor    %r8,%r9
  824b96:	and    %rdx,%r9
  824b99:	cmp    $0x10,%r9
  824b9d:	jb     824c60 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4e0>
  824ba3:	mov    %rdi,%rsi
  824ba6:	not    %rsi
  824ba9:	shl    $0x5,%rsi
  824bad:	add    %rcx,%rsi
  824bb0:	movzbl (%rcx,%rdi,1),%r8d
  824bb5:	shr    $0x39,%rax
  824bb9:	lea    -0x10(%rdi),%r9
  824bbd:	and    %rdx,%r9
  824bc0:	mov    %al,(%rcx,%rdi,1)
  824bc3:	mov    (%rbx),%rcx
  824bc6:	mov    %al,0x10(%rcx,%r9,1)
  824bcb:	cmp    $0xff,%r8b
  824bcf:	je     824ca6 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x526>
  824bd5:	mov    (%r14),%rax
  824bd8:	mov    (%rsi),%rcx
  824bdb:	mov    %rcx,(%r14)
  824bde:	mov    %rax,(%rsi)
  824be1:	mov    0x8(%r14),%rax
  824be5:	mov    0x8(%rsi),%rcx
  824be9:	mov    %rcx,0x8(%r14)
  824bed:	mov    %rax,0x8(%rsi)
  824bf1:	mov    0x10(%r14),%rax
  824bf5:	mov    0x10(%rsi),%rcx
  824bf9:	mov    %rcx,0x10(%r14)
  824bfd:	mov    %rax,0x10(%rsi)
  824c01:	mov    0x18(%r14),%rax
  824c05:	mov    0x18(%rsi),%rcx
  824c09:	mov    %rcx,0x18(%r14)
  824c0d:	mov    %rax,0x18(%rsi)
  824c11:	mov    (%rbx),%rax
  824c14:	jmp    824b40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824c19:	mov    $0x10,%r9d
  824c1f:	mov    %rsi,%r8
  824c22:	add    %r9,%r8
  824c25:	and    %rdx,%r8
  824c28:	movdqu (%rcx,%r8,1),%xmm0
  824c2e:	pmovmskb %xmm0,%edi
  824c32:	add    $0x10,%r9
  824c36:	test   %edi,%edi
  824c38:	jne    824b73 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3f3>
  824c3e:	jmp    824c22 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4a2>
  824c40:	movdqa (%rcx),%xmm0
  824c44:	pmovmskb %xmm0,%edi
  824c48:	tzcnt  %edi,%edi
  824c4c:	jmp    824b87 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x407>
  824c51:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  824c60:	shr    $0x39,%rax
  824c64:	lea    -0x10(%r12),%rsi
  824c69:	and    %rsi,%rdx
  824c6c:	mov    %al,(%rcx,%r12,1)
  824c70:	mov    (%rbx),%rcx
  824c73:	mov    %al,0x10(%rcx,%rdx,1)
  824c77:	cmp    %r15,%r12
  824c7a:	lea    0x1(%r12),%r12
  824c7f:	je     824cd5 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x555>
  824c81:	mov    (%rbx),%rax
  824c84:	cmp    (%rax,%r12,1),%r13b
  824c88:	jno    824c77 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  824c8a:	mov    %r12,%r14
  824c8d:	not    %r14
  824c90:	shl    $0x5,%r14
  824c94:	add    %rax,%r14
  824c97:	mov    %r12,%rbp
  824c9a:	neg    %rbp
  824c9d:	shl    $0x5,%rbp
  824ca1:	jmp    824b40 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x3c0>
  824ca6:	lea    -0x10(%r12),%rax
  824cab:	and    0x8(%rbx),%rax
  824caf:	mov    (%rbx),%rcx
  824cb2:	movb   $0xff,(%rcx,%r12,1)
  824cb7:	mov    (%rbx),%rcx
  824cba:	movb   $0xff,0x10(%rcx,%rax,1)
  824cbf:	movdqu (%r14),%xmm0
  824cc4:	movdqu 0x10(%r14),%xmm1
  824cca:	movdqu %xmm1,0x10(%rsi)
  824ccf:	movdqu %xmm0,(%rsi)
  824cd3:	jmp    824c77 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x4f7>
  824cd5:	mov    0x8(%rbx),%rdx
  824cd9:	mov    0x18(%rbx),%rax
  824cdd:	lea    0x1(%rdx),%rcx
  824ce1:	mov    %rcx,%rsi
  824ce4:	shr    $0x3,%rsi
  824ce8:	and    $0xfffffffffffffff8,%rcx
  824cec:	sub    %rsi,%rcx
  824cef:	cmp    $0x8,%rdx
  824cf3:	cmovb  %rdx,%rcx
  824cf7:	sub    %rax,%rcx
  824cfa:	mov    %rcx,0x10(%rbx)
  824cfe:	mov    $0xffffffffffffffff,%rax
  824d05:	add    $0x58,%rsp
  824d09:	pop    %rbx
  824d0a:	pop    %r12
  824d0c:	pop    %r13
  824d0e:	pop    %r14
  824d10:	pop    %r15
  824d12:	pop    %rbp
  824d13:	ret
  824d14:	mov    (%rsp),%rbx
  824d18:	mov    0x18(%rbx),%rcx
  824d1c:	mov    0x10(%rsp),%rbp
  824d21:	jmp    824d3c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x5bc>
  824d23:	movzbl %bpl,%edi
  824d27:	mov    $0x10,%esi
  824d2c:	mov    %r13,%rdx
  824d2f:	call   *0x65b03b(%rip)        # e7fd70 <_DYNAMIC+0x738>
  824d35:	jmp    824d05 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x585>
  824d37:	mov    (%rbx),%rsi
  824d3a:	xor    %ecx,%ecx
  824d3c:	sub    %rcx,%rbp
  824d3f:	mov    %r15,(%rbx)
  824d42:	mov    0x8(%rbx),%rax
  824d46:	mov    %rdi,0x8(%rbx)
  824d4a:	mov    %rbp,0x10(%rbx)
  824d4e:	mov    %rcx,0x18(%rbx)
  824d52:	test   %rax,%rax
  824d55:	je     824cfe <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824d57:	mov    %rax,%rcx
  824d5a:	shl    $0x5,%rcx
  824d5e:	add    $0x2f,%rcx
  824d62:	and    $0xffffffffffffffe0,%rcx
  824d66:	add    %rcx,%rax
  824d69:	add    $0x11,%rax
  824d6d:	je     824cfe <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824d6f:	sub    %rcx,%rsi
  824d72:	mov    $0x10,%edx
  824d77:	mov    %rsi,%rdi
  824d7a:	mov    %rax,%rsi
  824d7d:	call   *0x65aafd(%rip)        # e7f880 <_DYNAMIC+0x248>
  824d83:	jmp    824cfe <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x57e>
  824d88:	mov    $0x10,%edi
  824d8d:	jmp    824b0c <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile, std::hash::random::RandomState>::{closure#0}>+0x38c>
  824d92:	mov    %rax,%rbx
  824d95:	lea    0x20(%rsp),%rdi
  824d9a:	call   825370 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::prepare_resize<alloc::alloc::Global>::{closure#0}>>>
  824d9f:	mov    %rbx,%rdi
  824da2:	call   e2c420 <_Unwind_Resume@plt>
  824da7:	mov    %rax,%rbx
  824daa:	lea    0x20(%rsp),%rdi
  824daf:	call   8253b0 <core::ptr::drop_glue::<hashbrown::scopeguard::ScopeGuard<&mut hashbrown::raw::RawTableInner, <hashbrown::raw::RawTableInner>::rehash_in_place::{closure#0}>>>
  824db4:	mov    %rbx,%rdi
  824db7:	call   e2c420 <_Unwind_Resume@plt>
  824dbc:	call   *0x65aac6(%rip)        # e7f888 <_DYNAMIC+0x250>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}> bytes=1437 frame=104

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000824dd0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>>:
  824dd0:	push   %rbp
  824dd1:	push   %r15
  824dd3:	push   %r14
  824dd5:	push   %r13
  824dd7:	push   %r12
  824dd9:	push   %rbx
  824dda:	sub    $0x38,%rsp
  824dde:	mov    %ecx,%r15d
  824de1:	mov    %rdx,0x20(%rsp)
  824de6:	mov    %rdi,%rbp
  824de9:	mov    0x18(%rdi),%rdi
  824ded:	add    %rdi,%rsi
  824df0:	jb     824f08 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824df6:	mov    0x8(%rbp),%rbx
  824dfa:	lea    0x1(%rbx),%rdx
  824dfe:	mov    %rdx,%rax
  824e01:	shr    $0x3,%rax
  824e05:	mov    %rdx,%rcx
  824e08:	and    $0xfffffffffffffff8,%rcx
  824e0c:	sub    %rax,%rcx
  824e0f:	cmp    $0x8,%rbx
  824e13:	cmovb  %rbx,%rcx
  824e17:	mov    %rcx,%rax
  824e1a:	shr    $1,%rax
  824e1d:	cmp    %rax,%rsi
  824e20:	jbe    824e56 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x86>
  824e22:	inc    %rcx
  824e25:	cmp    %rsi,%rcx
  824e28:	cmovbe %rsi,%rcx
  824e2c:	cmp    $0xf,%rcx
  824e30:	mov    %rbp,(%rsp)
  824e34:	mov    %rbx,0x30(%rsp)
  824e39:	jae    824e88 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0xb8>
  824e3b:	mov    %ecx,%eax
  824e3d:	and    $0x8,%eax
  824e40:	add    $0x8,%rax
  824e44:	cmp    $0x4,%rcx
  824e48:	mov    $0x4,%ebx
  824e4d:	cmovae %rax,%rbx
  824e51:	jmp    824ee0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x110>
  824e56:	test   %rdx,%rdx
  824e59:	je     82509e <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2ce>
  824e5f:	mov    0x0(%rbp),%r12
  824e63:	mov    %rdx,%rax
  824e66:	shr    $0x4,%rax
  824e6a:	mov    %edx,%ecx
  824e6c:	and    $0xf,%ecx
  824e6f:	cmp    $0x1,%rcx
  824e73:	sbb    $0xffffffffffffffff,%rax
  824e77:	cmp    $0x1,%rax
  824e7b:	jne    8250a5 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2d5>
  824e81:	xor    %ecx,%ecx
  824e83:	jmp    8250f8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x328>
  824e88:	movabs $0x1ffffffffffffffe,%rax
  824e92:	inc    %rax
  824e95:	cmp    %rax,%rcx
  824e98:	ja     824f08 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824e9a:	shl    $0x3,%rcx
  824e9e:	movabs $0x2492492492492493,%rdx
  824ea8:	mov    %rcx,%rax
  824eab:	mul    %rdx
  824eae:	sub    %rdx,%rcx
  824eb1:	shr    $1,%rcx
  824eb4:	add    %rdx,%rcx
  824eb7:	shr    $0x2,%rcx
  824ebb:	dec    %rcx
  824ebe:	bsr    %rcx,%rcx
  824ec2:	not    %ecx
  824ec4:	mov    $0xffffffffffffffff,%rbx
  824ecb:	shr    %cl,%rbx
  824ece:	movabs $0xffffffffffffffe,%rax
  824ed8:	cmp    %rax,%rbx
  824edb:	ja     824f08 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x138>
  824edd:	inc    %rbx
  824ee0:	mov    %rbx,%r14
  824ee3:	shl    $0x4,%r14
  824ee7:	lea    0x10(%rbx),%rbp
  824eeb:	mov    %rbp,%r13
  824eee:	add    %r14,%r13
  824ef1:	setb   %al
  824ef4:	movabs $0x7ffffffffffffff0,%rcx
  824efe:	cmp    %rcx,%r13
  824f01:	seta   %cl
  824f04:	or     %al,%cl
  824f06:	je     824f17 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x147>
  824f08:	movzbl %r15b,%edi
  824f0c:	call   *0x65ae46(%rip)        # e7fd58 <_DYNAMIC+0x720>
  824f12:	jmp    8252d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  824f17:	mov    %rdi,0x8(%rsp)
  824f1c:	call   *0x65a9a6(%rip)        # e7f8c8 <_DYNAMIC+0x290>
  824f22:	mov    $0x10,%esi
  824f27:	mov    %r13,%rdi
  824f2a:	call   *0x65a9a0(%rip)        # e7f8d0 <_DYNAMIC+0x298>
  824f30:	test   %rax,%rax
  824f33:	je     8252f2 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x522>
  824f39:	mov    %rax,%rdi
  824f3c:	add    %r14,%rdi
  824f3f:	lea    -0x1(%rbx),%rcx
  824f43:	mov    %rbx,%rax
  824f46:	shr    $0x3,%rax
  824f4a:	mov    %rbx,%r14
  824f4d:	and    $0xfffffffffffffff8,%r14
  824f51:	sub    %rax,%r14
  824f54:	cmp    $0x9,%rbx
  824f58:	mov    %rcx,0x10(%rsp)
  824f5d:	cmovb  %rcx,%r14
  824f61:	mov    %rdi,0x18(%rsp)
  824f66:	mov    $0xff,%esi
  824f6b:	mov    %rbp,%rdx
  824f6e:	call   *0x65adec(%rip)        # e7fd60 <memset@GLIBC_2.2.5>
  824f74:	mov    0x8(%rsp),%rbx
  824f79:	test   %rbx,%rbx
  824f7c:	je     825306 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x536>
  824f82:	mov    %r14,0x28(%rsp)
  824f87:	mov    (%rsp),%rax
  824f8b:	mov    (%rax),%rdi
  824f8e:	movdqa (%rdi),%xmm0
  824f92:	pmovmskb %xmm0,%r14d
  824f97:	not    %r14d
  824f9a:	xor    %ebp,%ebp
  824f9c:	mov    %rdi,%r13
  824f9f:	nop
  824fa0:	test   %r14w,%r14w
  824fa4:	jne    824fcf <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1ff>
  824fa6:	cs nopw 0x0(%rax,%rax,1)
  824fb0:	movdqa 0x10(%r13),%xmm0
  824fb6:	add    $0x10,%r13
  824fba:	pmovmskb %xmm0,%r14d
  824fbf:	xor    $0xffff,%r14d
  824fc6:	add    $0x10,%rbp
  824fca:	test   %r14d,%r14d
  824fcd:	je     824fb0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1e0>
  824fcf:	tzcnt  %r14d,%r15d
  824fd4:	add    %rbp,%r15
  824fd7:	mov    %r15,%rax
  824fda:	shl    $0x4,%rax
  824fde:	mov    %rdi,%r12
  824fe1:	mov    %rdi,%rsi
  824fe4:	sub    %rax,%rsi
  824fe7:	add    $0xfffffffffffffff0,%rsi
  824feb:	mov    0x20(%rsp),%rdi
  824ff0:	call   821f90 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  824ff5:	mov    %rax,%rcx
  824ff8:	mov    0x10(%rsp),%r9
  824ffd:	and    %r9,%rcx
  825000:	mov    0x18(%rsp),%r8
  825005:	movdqu (%r8,%rcx,1),%xmm0
  82500b:	pmovmskb %xmm0,%edx
  82500f:	test   %edx,%edx
  825011:	je     825070 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a0>
  825013:	tzcnt  %edx,%edx
  825017:	add    %rcx,%rdx
  82501a:	and    %r9,%rdx
  82501d:	cmpb   $0x0,(%r8,%rdx,1)
  825022:	mov    %r12,%rdi
  825025:	jns    82508f <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2bf>
  825027:	lea    -0x1(%r14),%ecx
  82502b:	and    %r14d,%ecx
  82502e:	dec    %rbx
  825031:	shr    $0x39,%rax
  825035:	lea    -0x10(%rdx),%rsi
  825039:	and    %r9,%rsi
  82503c:	mov    %al,(%r8,%rdx,1)
  825040:	mov    %al,0x10(%r8,%rsi,1)
  825045:	not    %r15
  825048:	shl    $0x4,%r15
  82504c:	not    %rdx
  82504f:	shl    $0x4,%rdx
  825053:	movdqu (%rdi,%r15,1),%xmm0
  825059:	movdqu %xmm0,(%r8,%rdx,1)
  82505f:	mov    %ecx,%r14d
  825062:	test   %rbx,%rbx
  825065:	jne    824fa0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x1d0>
  82506b:	jmp    8252e7 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x517>
  825070:	mov    $0x10,%esi
  825075:	add    %rsi,%rcx
  825078:	and    %r9,%rcx
  82507b:	movdqu (%r8,%rcx,1),%xmm0
  825081:	pmovmskb %xmm0,%edx
  825085:	add    $0x10,%rsi
  825089:	test   %edx,%edx
  82508b:	jne    825013 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x243>
  82508d:	jmp    825075 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2a5>
  82508f:	movdqa (%r8),%xmm0
  825094:	pmovmskb %xmm0,%ecx
  825098:	tzcnt  %ecx,%edx
  82509c:	jmp    825027 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x257>
  82509e:	xor    %eax,%eax
  8250a0:	jmp    8252ca <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4fa>
  8250a5:	movabs $0x1ffffffffffffffe,%rsi
  8250af:	and    %rax,%rsi
  8250b2:	xor    %ecx,%ecx
  8250b4:	movdqa -0x77751c(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  8250bc:	nopl   0x0(%rax)
  8250c0:	pxor   %xmm1,%xmm1
  8250c4:	pcmpgtb (%r12,%rcx,1),%xmm1
  8250ca:	por    %xmm0,%xmm1
  8250ce:	movdqa %xmm1,(%r12,%rcx,1)
  8250d4:	pxor   %xmm1,%xmm1
  8250d8:	pcmpgtb 0x10(%r12,%rcx,1),%xmm1
  8250df:	por    %xmm0,%xmm1
  8250e3:	movdqa %xmm1,0x10(%r12,%rcx,1)
  8250ea:	add    $0x20,%rcx
  8250ee:	add    $0xfffffffffffffffe,%rsi
  8250f2:	jne    8250c0 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x2f0>
  8250f4:	test   $0x1,%al
  8250f6:	je     825110 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x340>
  8250f8:	pxor   %xmm0,%xmm0
  8250fc:	pcmpgtb (%r12,%rcx,1),%xmm0
  825102:	por    -0x77756a(%rip),%xmm0        # adba0 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x830>
  82510a:	movdqa %xmm0,(%r12,%rcx,1)
  825110:	cmp    $0x10,%rdx
  825114:	jb     825363 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x593>
  82511a:	mov    %rdx,%rdi
  82511d:	mov    $0x10,%edx
  825122:	add    %r12,%rdi
  825125:	mov    %r12,%rsi
  825128:	call   *0x65ac3a(%rip)        # e7fd68 <memmove@GLIBC_2.2.5>
  82512e:	xor    %r13d,%r13d
  825131:	xor    %eax,%eax
  825133:	jmp    825266 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x496>
  825138:	nopl   0x0(%rax,%rax,1)
  825140:	lea    (%r12,%r14,1),%rsi
  825144:	add    $0xfffffffffffffff0,%rsi
  825148:	mov    0x20(%rsp),%rdi
  82514d:	call   821f90 <<std::hash::random::RandomState as core::hash::BuildHasher>::hash_one::<&gpui_canvas::image::ImageKey>>
  825152:	mov    0x8(%rbp),%rcx
  825156:	mov    %rcx,%rdx
  825159:	and    %rax,%rdx
  82515c:	movdqu (%r12,%rdx,1),%xmm0
  825162:	pmovmskb %xmm0,%esi
  825166:	mov    %rdx,%rdi
  825169:	test   %esi,%esi
  82516b:	je     8251fb <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x42b>
  825171:	tzcnt  %esi,%esi
  825175:	add    %rdi,%rsi
  825178:	and    %rcx,%rsi
  82517b:	cmpb   $0x0,(%r12,%rsi,1)
  825180:	jns    825222 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x452>
  825186:	mov    %r13,%rdi
  825189:	sub    %rdx,%rdi
  82518c:	mov    %rsi,%r8
  82518f:	sub    %rdx,%r8
  825192:	xor    %rdi,%r8
  825195:	and    %rcx,%r8
  825198:	cmp    $0x10,%r8
  82519c:	jb     825240 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x470>
  8251a2:	mov    %rsi,%rdx
  8251a5:	not    %rdx
  8251a8:	shl    $0x4,%rdx
  8251ac:	add    %r12,%rdx
  8251af:	movzbl (%r12,%rsi,1),%edi
  8251b4:	shr    $0x39,%rax
  8251b8:	lea    -0x10(%rsi),%r8
  8251bc:	and    %rcx,%r8
  8251bf:	mov    %al,(%r12,%rsi,1)
  8251c3:	mov    0x0(%rbp),%r12
  8251c7:	mov    %al,0x10(%r12,%r8,1)
  8251cc:	cmp    $0xff,%dil
  8251d0:	je     82528b <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4bb>
  8251d6:	mov    (%rbx),%rax
  8251d9:	mov    (%rdx),%rcx
  8251dc:	mov    %rcx,(%rbx)
  8251df:	mov    %rax,(%rdx)
  8251e2:	mov    0x8(%rbx),%rax
  8251e6:	mov    0x8(%rdx),%rcx
  8251ea:	mov    %rcx,0x8(%rbx)
  8251ee:	mov    %rax,0x8(%rdx)
  8251f2:	mov    0x0(%rbp),%r12
  8251f6:	jmp    825140 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  8251fb:	mov    $0x10,%r8d
  825201:	mov    %rdx,%rdi
  825204:	add    %r8,%rdi
  825207:	and    %rcx,%rdi
  82520a:	movdqu (%r12,%rdi,1),%xmm0
  825210:	pmovmskb %xmm0,%esi
  825214:	add    $0x10,%r8
  825218:	test   %esi,%esi
  82521a:	jne    825171 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3a1>
  825220:	jmp    825204 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x434>
  825222:	movdqa (%r12),%xmm0
  825228:	pmovmskb %xmm0,%esi
  82522c:	tzcnt  %esi,%esi
  825230:	jmp    825186 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x3b6>
  825235:	data16 cs nopw 0x0(%rax,%rax,1)
  825240:	shr    $0x39,%rax
  825244:	lea    -0x10(%r13),%rdx
  825248:	and    %rdx,%rcx
  82524b:	mov    %al,(%r12,%r13,1)
  82524f:	mov    0x0(%rbp),%r12
  825253:	mov    %al,0x10(%r12,%rcx,1)
  825258:	mov    %r15,%rbx
  82525b:	xor    %eax,%eax
  82525d:	cmp    %rbx,%r13
  825260:	lea    0x1(%r13),%r13
  825264:	je     8252a8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x4d8>
  825266:	cmp    (%r12,%r13,1),%al
  82526a:	jno    82525d <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x48d>
  82526c:	mov    %rbx,%r15
  82526f:	mov    %r13,%rbx
  825272:	not    %rbx
  825275:	shl    $0x4,%rbx
  825279:	add    %r12,%rbx
  82527c:	mov    %r13,%r14
  82527f:	neg    %r14
  825282:	shl    $0x4,%r14
  825286:	jmp    825140 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x370>
  82528b:	lea    -0x10(%r13),%rax
  82528f:	and    0x8(%rbp),%rax
  825293:	movb   $0xff,(%r12,%r13,1)
  825298:	movb   $0xff,0x10(%r12,%rax,1)
  82529e:	movdqu (%rbx),%xmm0
  8252a2:	movdqu %xmm0,(%rdx)
  8252a6:	jmp    825258 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x488>
  8252a8:	mov    0x8(%rbp),%rcx
  8252ac:	mov    0x18(%rbp),%rdi
  8252b0:	lea    0x1(%rcx),%rax
  8252b4:	mov    %rax,%rdx
  8252b7:	shr    $0x3,%rdx
  8252bb:	and    $0xfffffffffffffff8,%rax
  8252bf:	sub    %rdx,%rax
  8252c2:	cmp    $0x8,%rcx
  8252c6:	cmovb  %rcx,%rax
  8252ca:	sub    %rdi,%rax
  8252cd:	mov    %rax,0x10(%rbp)
  8252d1:	mov    $0xffffffffffffffff,%rax
  8252d8:	add    $0x38,%rsp
  8252dc:	pop    %rbx
  8252dd:	pop    %r12
  8252df:	pop    %r13
  8252e1:	pop    %r14
  8252e3:	pop    %r15
  8252e5:	pop    %rbp
  8252e6:	ret
  8252e7:	mov    (%rsp),%rax
  8252eb:	mov    0x28(%rsp),%r14
  8252f0:	jmp    825317 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x547>
  8252f2:	movzbl %r15b,%edi
  8252f6:	mov    $0x10,%esi
  8252fb:	mov    %r13,%rdx
  8252fe:	call   *0x65aa6c(%rip)        # e7fd70 <_DYNAMIC+0x738>
  825304:	jmp    8252d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825306:	mov    (%rsp),%rax
  82530a:	mov    (%rax),%rdi
  82530d:	mov    0x18(%rsp),%r8
  825312:	mov    0x10(%rsp),%r9
  825317:	sub    0x8(%rsp),%r14
  82531c:	mov    %r8,(%rax)
  82531f:	mov    %r9,0x8(%rax)
  825323:	mov    %r14,0x10(%rax)
  825327:	mov    $0xffffffffffffffff,%rax
  82532e:	mov    0x30(%rsp),%rsi
  825333:	test   %rsi,%rsi
  825336:	je     8252d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825338:	mov    %rsi,%rcx
  82533b:	shl    $0x4,%rcx
  82533f:	add    $0x1f,%rcx
  825343:	and    $0xfffffffffffffff0,%rcx
  825347:	add    %rcx,%rsi
  82534a:	add    $0x11,%rsi
  82534e:	je     8252d8 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x508>
  825350:	sub    %rcx,%rdi
  825353:	mov    $0x10,%edx
  825358:	call   *0x65a522(%rip)        # e7f880 <_DYNAMIC+0x248>
  82535e:	jmp    8252d1 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x501>
  825363:	mov    $0x10,%edi
  825368:	jmp    825122 <<hashbrown::raw::RawTable<(gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry)>>::reserve_rehash::<hashbrown::map::make_hasher<gpui_canvas::image::ImageKey, gpui_gpu::renderer::images::Entry, std::hash::random::RandomState>::{closure#0}>+0x352>

FUNCTION <hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop bytes=47 frame=0

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825520 <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop>:
  825520:	mov    0x8(%rdi),%rsi
  825524:	test   %rsi,%rsi
  825527:	je     82554e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  825529:	mov    %rsi,%rax
  82552c:	shl    $0x5,%rax
  825530:	add    %rax,%rsi
  825533:	add    $0x31,%rsi
  825537:	je     82554e <<hashbrown::raw::RawTable<(gpui_canvas::text::GlyphKey, gpui_gpu::renderer::Tile)> as core::ops::drop::Drop>::drop+0x2e>
  825539:	mov    (%rdi),%rdi
  82553c:	sub    %rax,%rdi
  82553f:	add    $0xffffffffffffffe0,%rdi
  825543:	mov    $0x10,%edx
  825548:	jmp    *0x65a332(%rip)        # e7f880 <_DYNAMIC+0x248>
  82554e:	ret

FUNCTION <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}> bytes=303 frame=24

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008259a0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>>:
  8259a0:	push   %r15
  8259a2:	push   %r14
  8259a4:	push   %rbx
  8259a5:	mov    (%rdx),%r9
  8259a8:	mov    0x8(%rdx),%r11
  8259ac:	mov    0x10(%rdx),%rbx
  8259b0:	mov    0x18(%rdx),%r10
  8259b4:	mov    0x20(%rdx),%r8
  8259b8:	mov    0x28(%rdx),%rcx
  8259bc:	test   $0x1,%r9b
  8259c0:	jne    825a5a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xba>
  8259c6:	mov    %rbx,%rax
  8259c9:	jmp    8259eb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x4b>
  8259cb:	nopl   0x0(%rax,%rax,1)
  8259d0:	lea    0x8(%rax),%rbx
  8259d4:	mov    %rbx,%r14
  8259d7:	add    $0x8,%rdi
  8259db:	mov    (%rax),%r15
  8259de:	mov    %r14,%rax
  8259e1:	cmp    0x28(%r15),%rdx
  8259e5:	jne    825aaf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  8259eb:	cmp    %rsi,%rdi
  8259ee:	je     825a88 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  8259f4:	mov    (%rdi),%rdx
  8259f7:	test   %rax,%rax
  8259fa:	je     825a03 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x63>
  8259fc:	cmp    %r10,%rax
  8259ff:	jne    8259d0 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x30>
  825a01:	xor    %ebx,%ebx
  825a03:	xor    %eax,%eax
  825a05:	test   %r8,%r8
  825a08:	je     825ab1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825a0e:	cmp    %rcx,%r8
  825a11:	je     825ab1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825a17:	mov    %r8,%rax
  825a1a:	add    $0x8,%r8
  825a1e:	xor    %r14d,%r14d
  825a21:	jmp    8259d7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x37>
  825a23:	mov    (%r11),%rax
  825a26:	mov    0x8(%rax),%rbx
  825a2a:	mov    0x10(%rax),%rax
  825a2e:	lea    (%rbx,%rax,8),%r10
  825a32:	test   %rax,%rax
  825a35:	je     825a71 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xd1>
  825a37:	xor    %r11d,%r11d
  825a3a:	nopw   0x0(%rax,%rax,1)
  825a40:	mov    %r8,%rax
  825a43:	mov    %rbx,%r8
  825a46:	add    $0x8,%rbx
  825a4a:	add    $0x8,%rdi
  825a4e:	mov    (%r8),%r14
  825a51:	mov    %rax,%r8
  825a54:	cmp    0x28(%r14),%rdx
  825a58:	jne    825aaf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825a5a:	cmp    %rsi,%rdi
  825a5d:	je     825a88 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xe8>
  825a5f:	mov    (%rdi),%rdx
  825a62:	test   %rbx,%rbx
  825a65:	je     825a6c <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xcc>
  825a67:	cmp    %r10,%rbx
  825a6a:	jne    825a40 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xa0>
  825a6c:	test   %r11,%r11
  825a6f:	jne    825a23 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x83>
  825a71:	xor    %eax,%eax
  825a73:	test   %r8,%r8
  825a76:	je     825ab1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825a78:	cmp    %rcx,%r8
  825a7b:	je     825ab1 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x111>
  825a7d:	lea    0x8(%r8),%rax
  825a81:	xor    %ebx,%ebx
  825a83:	xor    %r11d,%r11d
  825a86:	jmp    825a4a <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0xaa>
  825a88:	test   %rbx,%rbx
  825a8b:	sete   %dl
  825a8e:	cmp    %r10,%rbx
  825a91:	sete   %al
  825a94:	or     %dl,%al
  825a96:	test   $0x1,%r9b
  825a9a:	je     825ab7 <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x117>
  825a9c:	test   %al,%al
  825a9e:	je     825aaf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825aa0:	test   %r11,%r11
  825aa3:	je     825abb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  825aa5:	mov    (%r11),%rax
  825aa8:	cmpq   $0x0,0x10(%rax)
  825aad:	je     825abb <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x11b>
  825aaf:	xor    %eax,%eax
  825ab1:	pop    %rbx
  825ab2:	pop    %r14
  825ab4:	pop    %r15
  825ab6:	ret
  825ab7:	test   %al,%al
  825ab9:	je     825aaf <<core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq_by::<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>, <core::iter::adapters::copied::Copied<core::slice::iter::Iter<gpui_canvas::image::ImageKey>> as core::iter::traits::iterator::Iterator>::eq<core::iter::adapters::map::Map<core::iter::adapters::flatten::FlatMap<core::option::Iter<alloc::boxed::Box<gpui_canvas::canvas::ImageResources>>, core::iter::adapters::map::Map<core::slice::iter::Iter<gpui_canvas::image::Image>, <gpui_canvas::image::Image>::view>, <gpui_canvas::canvas::PreparedScene>::images::{closure#0}>, gpui_gpu::renderer::images::prepare::{closure#0}>>::{closure#0}>+0x10f>
  825abb:	test   %r8,%r8
  825abe:	sete   %dl
  825ac1:	cmp    %rcx,%r8
  825ac4:	sete   %al
  825ac7:	or     %dl,%al
  825ac9:	pop    %rbx
  825aca:	pop    %r14
  825acc:	pop    %r15
  825ace:	ret

FUNCTION gpui_gpu::renderer::slots::color_word bytes=57 frame=8

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825ad0 <gpui_gpu::renderer::slots::color_word>:
  825ad0:	lea    -0x3(%rsi),%eax
  825ad3:	cmp    %rax,%rdi
  825ad6:	jbe    825aef <gpui_gpu::renderer::slots::color_word+0x1f>
  825ad8:	mov    %rdi,%rax
  825adb:	shr    $0x6,%rax
  825adf:	and    $0x3f,%edi
  825ae2:	cmp    $0x1,%rdi
  825ae6:	sbb    $0xffffffff,%eax
  825ae9:	add    %esi,%eax
  825aeb:	add    $0xfffffffe,%eax
  825aee:	ret
  825aef:	push   %rax
  825af0:	lea    -0x750b12(%rip),%rdi        # d4fe5 <anon.4f92784177f891c02fc0a44bfee03ec4.9.llvm.1533866460487341161>
  825af7:	lea    0x60885a(%rip),%rdx        # e2e358 <anon.4f92784177f891c02fc0a44bfee03ec4.10.llvm.1533866460487341161>
  825afe:	mov    $0x1e,%esi
  825b03:	call   *0x65a097(%rip)        # e7fba0 <_DYNAMIC+0x568>

FUNCTION gpui_gpu::renderer::slots::write_prefix bytes=517 frame=72

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000825b10 <gpui_gpu::renderer::slots::write_prefix>:
  825b10:	push   %rbp
  825b11:	push   %r15
  825b13:	push   %r14
  825b15:	push   %r13
  825b17:	push   %r12
  825b19:	push   %rbx
  825b1a:	sub    $0x18,%rsp
  825b1e:	test   %rdx,%rdx
  825b21:	je     825cbc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825b27:	mov    %rdi,%rbx
  825b2a:	mov    %rdx,%rax
  825b2d:	shr    $0x6,%rax
  825b31:	xor    %ecx,%ecx
  825b33:	test   $0x3f,%dl
  825b36:	setne  %cl
  825b39:	lea    (%rax,%rcx,1),%rbp
  825b3d:	lea    (%rax,%rcx,1),%r8
  825b41:	inc    %r8
  825b44:	mov    0x10(%rdi),%r12
  825b48:	mov    %rbp,%r13
  825b4b:	sub    %r12,%r13
  825b4e:	jae    825b5c <gpui_gpu::renderer::slots::write_prefix+0x4c>
  825b50:	mov    0x8(%rbx),%rax
  825b54:	mov    %r8,%r14
  825b57:	jmp    825bfb <gpui_gpu::renderer::slots::write_prefix+0xeb>
  825b5c:	mov    %r8,%r15
  825b5f:	sub    %r12,%r15
  825b62:	mov    (%rbx),%rax
  825b65:	sub    %r12,%rax
  825b68:	mov    %r12,%r14
  825b6b:	cmp    %rax,%r15
  825b6e:	ja     825ccb <gpui_gpu::renderer::slots::write_prefix+0x1bb>
  825b74:	mov    0x8(%rbx),%rax
  825b78:	mov    %r14,%rcx
  825b7b:	shl    $0x4,%rcx
  825b7f:	add    %rax,%rcx
  825b82:	cmp    $0x2,%r15
  825b86:	jb     825bf2 <gpui_gpu::renderer::slots::write_prefix+0xe2>
  825b88:	mov    %r13d,%edi
  825b8b:	and    $0x7,%edi
  825b8e:	sub    %rbp,%r12
  825b91:	cmp    $0xfffffffffffffff8,%r12
  825b95:	ja     825bce <gpui_gpu::renderer::slots::write_prefix+0xbe>
  825b97:	and    $0xfffffffffffffff8,%r13
  825b9b:	xorps  %xmm0,%xmm0
  825b9e:	xchg   %ax,%ax
  825ba0:	movups %xmm0,(%rcx)
  825ba3:	movups %xmm0,0x10(%rcx)
  825ba7:	movups %xmm0,0x20(%rcx)
  825bab:	movups %xmm0,0x30(%rcx)
  825baf:	movups %xmm0,0x40(%rcx)
  825bb3:	movups %xmm0,0x50(%rcx)
  825bb7:	movups %xmm0,0x60(%rcx)
  825bbb:	movups %xmm0,0x70(%rcx)
  825bbf:	sub    $0xffffffffffffff80,%rcx
  825bc3:	add    $0xfffffffffffffff8,%r13
  825bc7:	jne    825ba0 <gpui_gpu::renderer::slots::write_prefix+0x90>
  825bc9:	test   %rdi,%rdi
  825bcc:	je     825bec <gpui_gpu::renderer::slots::write_prefix+0xdc>
  825bce:	xorps  %xmm0,%xmm0
  825bd1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  825be0:	movups %xmm0,(%rcx)
  825be3:	add    $0x10,%rcx
  825be7:	dec    %rdi
  825bea:	jne    825be0 <gpui_gpu::renderer::slots::write_prefix+0xd0>
  825bec:	add    %r15,%r14
  825bef:	dec    %r14
  825bf2:	xorps  %xmm0,%xmm0
  825bf5:	movups %xmm0,(%rcx)
  825bf8:	inc    %r14
  825bfb:	mov    %r14,0x10(%rbx)
  825bff:	mov    %edx,(%rax)
  825c01:	mov    %ebp,0x4(%rax)
  825c04:	mov    %r8d,0x8(%rax)
  825c08:	movl   $0x0,0xc(%rax)
  825c0f:	mov    %rsi,%rdi
  825c12:	call   *0x659fc8(%rip)        # e7fbe0 <_DYNAMIC+0x5a8>
  825c18:	cmp    %rdx,%rax
  825c1b:	je     825cbc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825c21:	mov    %rax,%r15
  825c24:	mov    %rdx,%r12
  825c27:	xor    %r13d,%r13d
  825c2a:	xor    %ebp,%ebp
  825c2c:	jmp    825c56 <gpui_gpu::renderer::slots::write_prefix+0x146>
  825c2e:	xchg   %ax,%ax
  825c30:	mov    0x8(%rbx),%rax
  825c34:	mov    %r14,%rcx
  825c37:	shl    $0x4,%rcx
  825c3b:	movups %xmm0,(%rax,%rcx,1)
  825c3f:	inc    %r14
  825c42:	mov    %r14,0x10(%rbx)
  825c46:	add    $0x2,%r13d
  825c4a:	add    $0x18,%r15
  825c4e:	inc    %rbp
  825c51:	cmp    %r12,%r15
  825c54:	je     825cbc <gpui_gpu::renderer::slots::write_prefix+0x1ac>
  825c56:	mov    %rbp,%rdi
  825c59:	shr    $0x6,%rdi
  825c5d:	inc    %rdi
  825c60:	cmp    %r14,%rdi
  825c63:	jae    825d05 <gpui_gpu::renderer::slots::write_prefix+0x1f5>
  825c69:	movups (%r15),%xmm0
  825c6d:	movzwl 0x12(%r15),%eax
  825c72:	movzwl 0x10(%r15),%edx
  825c77:	shr    $0xe,%eax
  825c7a:	and    $0x2,%eax
  825c7d:	shr    $0xf,%edx
  825c80:	or     %eax,%edx
  825c82:	mov    %r13d,%ecx
  825c85:	and    $0x1e,%cl
  825c88:	shl    %cl,%edx
  825c8a:	shl    $0x4,%rdi
  825c8e:	add    0x8(%rbx),%rdi
  825c92:	mov    %ebp,%eax
  825c94:	shr    $0x2,%eax
  825c97:	and    $0xc,%eax
  825c9a:	or     %edx,(%rax,%rdi,1)
  825c9d:	mov    0x10(%rbx),%r14
  825ca1:	cmp    (%rbx),%r14
  825ca4:	jne    825c30 <gpui_gpu::renderer::slots::write_prefix+0x120>
  825ca6:	mov    %rbx,%rdi
  825ca9:	movaps %xmm0,(%rsp)
  825cad:	call   *0x65a08d(%rip)        # e7fd40 <_DYNAMIC+0x708>
  825cb3:	movaps (%rsp),%xmm0
  825cb7:	jmp    825c30 <gpui_gpu::renderer::slots::write_prefix+0x120>
  825cbc:	add    $0x18,%rsp
  825cc0:	pop    %rbx
  825cc1:	pop    %r12
  825cc3:	pop    %r13
  825cc5:	pop    %r14
  825cc7:	pop    %r15
  825cc9:	pop    %rbp
  825cca:	ret
  825ccb:	mov    $0x4,%ecx
  825cd0:	mov    %r8,0x10(%rsp)
  825cd5:	mov    $0x10,%r8d
  825cdb:	mov    %rbx,%rdi
  825cde:	mov    %rsi,(%rsp)
  825ce2:	mov    %r12,%rsi
  825ce5:	mov    %rdx,%r14
  825ce8:	mov    %r15,%rdx
  825ceb:	call   823b20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  825cf0:	mov    0x10(%rsp),%r8
  825cf5:	mov    %r14,%rdx
  825cf8:	mov    (%rsp),%rsi
  825cfc:	mov    0x10(%rbx),%r14
  825d00:	jmp    825b74 <gpui_gpu::renderer::slots::write_prefix+0x64>
  825d05:	lea    0x608664(%rip),%rdx        # e2e370 <anon.4f92784177f891c02fc0a44bfee03ec4.12.llvm.1533866460487341161>
  825d0c:	mov    %r14,%rsi
  825d0f:	call   *0x659e1b(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
