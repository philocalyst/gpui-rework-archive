
FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4056 frame=792

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

0000000000820570 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  820570:	push   %rbp
  820571:	push   %r15
  820573:	push   %r14
  820575:	push   %r13
  820577:	push   %r12
  820579:	push   %rbx
  82057a:	sub    $0x2e8,%rsp
  820581:	movss  0x88(%rdx),%xmm3
  820589:	movss  -0x7715d5(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820591:	movaps %xmm3,%xmm1
  820594:	subss  %xmm0,%xmm1
  820598:	cvttss2si %xmm1,%rax
  82059d:	cvttss2si %xmm3,%r10
  8205a2:	mov    %r10,%r13
  8205a5:	sar    $0x3f,%r13
  8205a9:	and    %rax,%r13
  8205ac:	or     %r10,%r13
  8205af:	xor    %eax,%eax
  8205b1:	xorps  %xmm1,%xmm1
  8205b4:	ucomiss %xmm1,%xmm3
  8205b7:	cmovb  %rax,%r13
  8205bb:	movss  0x90(%rdx),%xmm4
  8205c3:	movss  -0x77160b(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  8205cb:	ucomiss %xmm2,%xmm3
  8205ce:	mov    $0xffffffffffffffff,%r14
  8205d5:	cmova  %r14,%r13
  8205d9:	movaps %xmm4,%xmm3
  8205dc:	subss  %xmm0,%xmm3
  8205e0:	cvttss2si %xmm3,%r10
  8205e5:	cvttss2si %xmm4,%r11
  8205ea:	mov    %r11,%rbx
  8205ed:	sar    $0x3f,%rbx
  8205f1:	and    %r10,%rbx
  8205f4:	or     %r11,%rbx
  8205f7:	ucomiss %xmm1,%xmm4
  8205fa:	cmovb  %rax,%rbx
  8205fe:	ucomiss %xmm2,%xmm4
  820601:	cmova  %r14,%rbx
  820605:	movss  0x8c(%rdx),%xmm3
  82060d:	lea    (%rbx,%r13,1),%r11
  820611:	dec    %r11
  820614:	shr    $0x4,%r11
  820618:	shr    $0x4,%r13
  82061c:	mov    %r11,%rbp
  82061f:	sub    %r13,%rbp
  820622:	inc    %rbp
  820625:	movaps %xmm3,%xmm4
  820628:	subss  %xmm0,%xmm4
  82062c:	cvttss2si %xmm4,%r10
  820631:	cvttss2si %xmm3,%r15
  820636:	mov    %r15,%rbx
  820639:	sar    $0x3f,%rbx
  82063d:	and    %r10,%rbx
  820640:	or     %r15,%rbx
  820643:	ucomiss %xmm1,%xmm3
  820646:	cmovb  %rax,%rbx
  82064a:	ucomiss %xmm2,%xmm3
  82064d:	movss  0x94(%rdx),%xmm3
  820655:	cmova  %r14,%rbx
  820659:	movaps %xmm3,%xmm4
  82065c:	subss  %xmm0,%xmm4
  820660:	cvttss2si %xmm4,%r10
  820665:	cvttss2si %xmm3,%r15
  82066a:	mov    %r15,%r12
  82066d:	sar    $0x3f,%r12
  820671:	and    %r10,%r12
  820674:	or     %r15,%r12
  820677:	ucomiss %xmm1,%xmm3
  82067a:	cmovb  %rax,%r12
  82067e:	ucomiss %xmm2,%xmm3
  820681:	cmova  %r14,%r12
  820685:	lea    (%rbx,%r12,1),%r10
  820689:	dec    %r10
  82068c:	shr    $0x4,%r10
  820690:	shr    $0x4,%rbx
  820694:	mov    %r10,%r14
  820697:	sub    %rbx,%r14
  82069a:	inc    %r14
  82069d:	imul   %rbp,%r14
  8206a1:	add    0x330(%rsp),%r14
  8206a9:	setb   %al
  8206ac:	cmp    $0x400001,%r14
  8206b3:	setae  %bpl
  8206b7:	or     %al,%bpl
  8206ba:	mov    $0x6,%eax
  8206bf:	jne    8206ff <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  8206c1:	mov    %r8d,0xac(%rsp)
  8206c9:	mov    %r14,0x170(%rsp)
  8206d1:	mov    %rdi,0x178(%rsp)
  8206d9:	mov    %r13,0xa0(%rsp)
  8206e1:	cmp    %rbx,%r10
  8206e4:	jae    820713 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  8206e6:	mov    0x178(%rsp),%rdi
  8206ee:	mov    0x170(%rsp),%rax
  8206f6:	mov    %rax,0x8(%rdi)
  8206fa:	mov    $0xffffffff,%eax
  8206ff:	mov    %eax,(%rdi)
  820701:	add    $0x2e8,%rsp
  820708:	pop    %rbx
  820709:	pop    %r12
  82070b:	pop    %r13
  82070d:	pop    %r14
  82070f:	pop    %r15
  820711:	pop    %rbp
  820712:	ret
  820713:	cmp    0xa0(%rsp),%r11
  82071b:	jae    820736 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  82071d:	nopl   (%rax)
  820720:	mov    %rbx,%rax
  820723:	cmp    %r10,%rbx
  820726:	adc    $0x0,%rbx
  82072a:	cmp    %r10,%rax
  82072d:	jae    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82072f:	cmp    %r10,%rbx
  820732:	jbe    820720 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  820734:	jmp    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  820736:	movd   0xa4(%rdx),%xmm0
  82073e:	mov    0x20(%rsi),%r12
  820742:	movdqu 0x98(%rdx),%xmm1
  82074a:	movd   0xa0(%rdx),%xmm2
  820752:	punpckldq %xmm0,%xmm2
  820756:	punpcklqdq %xmm2,%xmm1
  82075a:	movdqa -0x773e52(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  820762:	pand   %xmm1,%xmm2
  820766:	paddd  -0x773bfe(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  82076e:	pxor   -0x772446(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  820776:	pcmpgtd -0x772fee(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  82077e:	mov    %rsi,%rax
  820781:	mov    0x28(%rsi),%rsi
  820785:	pandn  %xmm1,%xmm2
  820789:	movmskps %xmm2,%edi
  82078c:	test   %edi,%edi
  82078e:	jne    8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  820794:	ucomiss -0x771a1b(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82079b:	jne    8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  8207a1:	jp     8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  8207a7:	cmpb   $0x0,0x328(%rax)
  8207ae:	je     8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  8207b4:	cmpb   $0x0,(%rdx)
  8207b7:	jne    8214b4 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf44>
  8207bd:	test   %r9,%r9
  8207c0:	je     82152b <<gpui_gpu::renderer::RendererState>::bin_draw+0xfbb>
  8207c6:	mov    0x328(%rsp),%ebp
  8207cd:	mov    0x320(%rsp),%r13d
  8207d5:	movd   %ecx,%xmm2
  8207d9:	shr    $0x20,%rcx
  8207dd:	movss  0x78(%rdx),%xmm0
  8207e2:	movss  0x80(%rdx),%xmm3
  8207ea:	movss  0x84(%rdx),%xmm4
  8207f2:	cvtss2sd %xmm0,%xmm0
  8207f6:	movss  0x7c(%rdx),%xmm1
  8207fb:	cvtss2sd %xmm1,%xmm1
  8207ff:	cvtss2sd %xmm3,%xmm14
  820804:	addsd  %xmm0,%xmm14
  820809:	xorps  %xmm3,%xmm3
  82080c:	cvtss2sd %xmm4,%xmm3
  820810:	addsd  %xmm1,%xmm3
  820814:	movsd  %xmm3,0x1a8(%rsp)
  82081d:	movsd  0x48(%rdx),%xmm6
  820822:	movsd  0x58(%rdx),%xmm7
  820827:	movsd  0x68(%rdx),%xmm8
  82082d:	movss  0x38(%rdx),%xmm3
  820832:	movss  0x3c(%rdx),%xmm4
  820837:	movss  0x40(%rdx),%xmm5
  82083c:	cvtss2sd %xmm3,%xmm3
  820840:	cvtss2sd %xmm5,%xmm5
  820844:	movaps -0x775a9c(%rip),%xmm9        # aadb0 <GCC_except_table0+0xb8>
  82084c:	movaps %xmm3,0x80(%rsp)
  820854:	andps  %xmm9,%xmm3
  820858:	movaps %xmm3,0x70(%rsp)
  82085d:	movaps %xmm5,0x50(%rsp)
  820862:	cvtss2sd %xmm2,%xmm2
  820866:	movsd  %xmm2,0x8(%rsp)
  82086c:	andps  %xmm9,%xmm5
  820870:	movaps %xmm5,0x60(%rsp)
  820875:	movaps %xmm6,%xmm2
  820878:	andps  %xmm9,%xmm2
  82087c:	movaps %xmm2,0x250(%rsp)
  820884:	movaps %xmm7,%xmm2
  820887:	andps  %xmm9,%xmm2
  82088b:	movaps %xmm2,0x230(%rsp)
  820893:	xorps  %xmm3,%xmm3
  820896:	cvtss2sd %xmm4,%xmm3
  82089a:	movaps %xmm8,%xmm2
  82089e:	andps  %xmm9,%xmm2
  8208a2:	movaps %xmm2,0xf0(%rsp)
  8208aa:	movss  0x44(%rdx),%xmm2
  8208af:	cvtss2sd %xmm2,%xmm2
  8208b3:	movaps %xmm3,0x40(%rsp)
  8208b8:	andps  %xmm9,%xmm3
  8208bc:	movaps %xmm3,0x30(%rsp)
  8208c1:	movaps %xmm2,0x10(%rsp)
  8208c6:	andps  %xmm9,%xmm2
  8208ca:	movaps %xmm2,0x20(%rsp)
  8208cf:	movd   %ecx,%xmm2
  8208d3:	cvtss2sd %xmm2,%xmm2
  8208d7:	movsd  %xmm2,(%rsp)
  8208dc:	movsd  0x50(%rdx),%xmm2
  8208e1:	movaps %xmm2,%xmm3
  8208e4:	andps  %xmm9,%xmm3
  8208e8:	movaps %xmm3,0x1d0(%rsp)
  8208f0:	movsd  0x60(%rdx),%xmm3
  8208f5:	movaps %xmm3,%xmm4
  8208f8:	andps  %xmm9,%xmm4
  8208fc:	movaps %xmm4,0x1b0(%rsp)
  820904:	movsd  0x70(%rdx),%xmm4
  820909:	movaps %xmm4,%xmm5
  82090c:	andps  %xmm9,%xmm5
  820910:	movaps %xmm5,0xb0(%rsp)
  820918:	movaps %xmm2,0x1e0(%rsp)
  820920:	cvtsd2ss %xmm2,%xmm2
  820924:	xorps  %xmm5,%xmm5
  820927:	cvtss2sd %xmm2,%xmm5
  82092b:	movaps %xmm6,0x260(%rsp)
  820933:	movaps %xmm6,%xmm2
  820936:	movaps %xmm7,0x240(%rsp)
  82093e:	movlhps %xmm7,%xmm2
  820941:	cvtpd2ps %xmm2,%xmm2
  820945:	cvtps2pd %xmm2,%xmm6
  820948:	movaps %xmm3,0x1c0(%rsp)
  820950:	xorps  %xmm2,%xmm2
  820953:	cvtsd2ss %xmm3,%xmm2
  820957:	xorps  %xmm3,%xmm3
  82095a:	cvtss2sd %xmm2,%xmm3
  82095e:	movaps %xmm8,0x100(%rsp)
  820967:	xorps  %xmm2,%xmm2
  82096a:	cvtsd2ss %xmm8,%xmm2
  82096f:	xorps  %xmm7,%xmm7
  820972:	cvtss2sd %xmm2,%xmm7
  820976:	movaps %xmm4,0xc0(%rsp)
  82097e:	xorps  %xmm2,%xmm2
  820981:	cvtsd2ss %xmm4,%xmm2
  820985:	cvtss2sd %xmm2,%xmm2
  820989:	movaps %xmm6,%xmm4
  82098c:	andps  %xmm9,%xmm4
  820990:	movaps %xmm7,0x120(%rsp)
  820998:	andps  %xmm9,%xmm7
  82099c:	movaps %xmm7,0x110(%rsp)
  8209a4:	movaps %xmm5,0x220(%rsp)
  8209ac:	andps  %xmm9,%xmm5
  8209b0:	movaps %xmm5,0x210(%rsp)
  8209b8:	movaps %xmm3,0x200(%rsp)
  8209c0:	andps  %xmm9,%xmm3
  8209c4:	movaps %xmm3,0x1f0(%rsp)
  8209cc:	movaps %xmm2,0xd0(%rsp)
  8209d4:	andps  %xmm2,%xmm9
  8209d8:	movaps %xmm9,0xe0(%rsp)
  8209e1:	movaps %xmm6,0x280(%rsp)
  8209e9:	movhlps %xmm6,%xmm6
  8209ec:	movaps %xmm6,0x2b0(%rsp)
  8209f4:	movaps %xmm4,0x270(%rsp)
  8209fc:	movhlps %xmm4,%xmm4
  8209ff:	movaps %xmm4,0x2a0(%rsp)
  820a07:	mov    %r10,0x198(%rsp)
  820a0f:	movsd  %xmm14,0x98(%rsp)
  820a19:	nopl   0x0(%rax)
  820a20:	mov    %rbx,%r15
  820a23:	cmp    %r10,%rbx
  820a26:	adc    $0x0,%rbx
  820a2a:	mov    %r15,0x1a0(%rsp)
  820a32:	imul   %r9,%r15
  820a36:	mov    0xa0(%rsp),%rdi
  820a3e:	mov    %rdi,%r8
  820a41:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  820a50:	cmp    %r11,%rdi
  820a53:	adc    $0x0,%r8
  820a57:	lea    (%rdi,%r15,1),%rcx
  820a5b:	mov    %rcx,%rax
  820a5e:	shr    $0x20,%rax
  820a62:	je     820a70 <<gpui_gpu::renderer::RendererState>::bin_draw+0x500>
  820a64:	mov    %rcx,%rax
  820a67:	xor    %edx,%edx
  820a69:	div    %r9
  820a6c:	jmp    820a77 <<gpui_gpu::renderer::RendererState>::bin_draw+0x507>
  820a6e:	xchg   %ax,%ax
  820a70:	mov    %ecx,%eax
  820a72:	xor    %edx,%edx
  820a74:	div    %r9d
  820a77:	shl    $0x4,%edx
  820a7a:	shl    $0x4,%eax
  820a7d:	lea    0x10(%rdx),%r10d
  820a81:	cmp    %r10d,%r13d
  820a84:	cmovb  %r13d,%r10d
  820a88:	lea    0x10(%rax),%r14d
  820a8c:	cmp    %r14d,%ebp
  820a8f:	cmovb  %ebp,%r14d
  820a93:	xorps  %xmm12,%xmm12
  820a97:	cvtsi2sd %edx,%xmm12
  820a9c:	ucomisd %xmm12,%xmm0
  820aa1:	ja     820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820aa3:	mov    %eax,%eax
  820aa5:	xorps  %xmm2,%xmm2
  820aa8:	cvtsi2sd %rax,%xmm2
  820aad:	ucomisd %xmm2,%xmm1
  820ab1:	ja     820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ab3:	xorps  %xmm6,%xmm6
  820ab6:	cvtsi2sd %r10d,%xmm6
  820abb:	ucomisd %xmm14,%xmm6
  820ac0:	ja     820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ac2:	xorps  %xmm13,%xmm13
  820ac6:	cvtsi2sd %r14d,%xmm13
  820acb:	ucomisd 0x1a8(%rsp),%xmm13
  820ad5:	jbe    820b08 <<gpui_gpu::renderer::RendererState>::bin_draw+0x598>
  820ad7:	nopw   0x0(%rax,%rax,1)
  820ae0:	cmp    %rsi,%rcx
  820ae3:	jae    82151b <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  820ae9:	incl   0x4(%r12,%rcx,8)
  820aee:	cmp    %r11,%rdi
  820af1:	jae    821490 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820af7:	mov    %r8,%rdi
  820afa:	cmp    %r11,%r8
  820afd:	jbe    820a50 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4e0>
  820b03:	jmp    821490 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf20>
  820b08:	unpcklpd %xmm2,%xmm12
  820b0d:	addpd  -0x773a46(%rip),%xmm12        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820b16:	movapd %xmm12,%xmm10
  820b1b:	mulpd  0x280(%rsp),%xmm10
  820b25:	movapd %xmm10,%xmm15
  820b2a:	unpckhpd %xmm10,%xmm15
  820b2f:	movapd %xmm10,%xmm2
  820b34:	addsd  %xmm15,%xmm2
  820b39:	addsd  0x120(%rsp),%xmm2
  820b42:	subsd  0x80(%rsp),%xmm2
  820b4b:	movapd 0x270(%rsp),%xmm8
  820b55:	mulpd  %xmm12,%xmm8
  820b5a:	movapd %xmm8,%xmm9
  820b5f:	unpckhpd %xmm8,%xmm9
  820b64:	movapd %xmm8,%xmm3
  820b69:	addsd  %xmm9,%xmm3
  820b6e:	addsd  0x110(%rsp),%xmm3
  820b77:	addsd  0x70(%rsp),%xmm3
  820b7d:	addsd  0x60(%rsp),%xmm3
  820b83:	addsd  -0x771313(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820b8b:	mulsd  -0x771393(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820b93:	addsd  0x8(%rsp),%xmm3
  820b99:	ucomisd %xmm2,%xmm3
  820b9d:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ba3:	movapd 0x50(%rsp),%xmm4
  820ba9:	subsd  %xmm2,%xmm4
  820bad:	ucomisd %xmm4,%xmm3
  820bb1:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820bb7:	movapd %xmm12,%xmm7
  820bbc:	unpckhpd %xmm12,%xmm7
  820bc1:	movapd 0x240(%rsp),%xmm11
  820bcb:	mulsd  %xmm7,%xmm11
  820bd0:	movapd 0x230(%rsp),%xmm3
  820bd9:	mulsd  %xmm7,%xmm3
  820bdd:	movapd 0x260(%rsp),%xmm2
  820be6:	mulsd  %xmm12,%xmm2
  820beb:	movapd %xmm2,0x140(%rsp)
  820bf4:	addsd  %xmm11,%xmm2
  820bf9:	addsd  0x100(%rsp),%xmm2
  820c02:	subsd  0x80(%rsp),%xmm2
  820c0b:	movapd 0x250(%rsp),%xmm4
  820c14:	mulsd  %xmm12,%xmm4
  820c19:	movsd  %xmm4,0x190(%rsp)
  820c22:	addsd  %xmm3,%xmm4
  820c26:	addsd  0xf0(%rsp),%xmm4
  820c2f:	addsd  0x70(%rsp),%xmm4
  820c35:	addsd  0x60(%rsp),%xmm4
  820c3b:	addsd  -0x7713cb(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c43:	mulsd  -0x770e73(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820c4b:	ucomisd %xmm2,%xmm4
  820c4f:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c55:	movapd 0x50(%rsp),%xmm5
  820c5b:	subsd  %xmm2,%xmm5
  820c5f:	ucomisd %xmm5,%xmm4
  820c63:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820c69:	movapd %xmm7,%xmm4
  820c6d:	mulsd  0x200(%rsp),%xmm4
  820c76:	movapd %xmm7,%xmm2
  820c7a:	mulsd  0x1f0(%rsp),%xmm2
  820c83:	movapd %xmm12,%xmm5
  820c88:	mulsd  0x220(%rsp),%xmm5
  820c91:	movsd  %xmm5,0x188(%rsp)
  820c9a:	movapd %xmm4,0x130(%rsp)
  820ca3:	addsd  %xmm4,%xmm5
  820ca7:	addsd  0xd0(%rsp),%xmm5
  820cb0:	subsd  0x40(%rsp),%xmm5
  820cb6:	movapd %xmm12,%xmm4
  820cbb:	mulsd  0x210(%rsp),%xmm4
  820cc4:	movsd  %xmm4,0x180(%rsp)
  820ccd:	addsd  %xmm2,%xmm4
  820cd1:	addsd  0xe0(%rsp),%xmm4
  820cda:	addsd  0x30(%rsp),%xmm4
  820ce0:	addsd  0x20(%rsp),%xmm4
  820ce6:	addsd  -0x771476(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cee:	mulsd  -0x7714f6(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820cf6:	addsd  (%rsp),%xmm4
  820cfb:	ucomisd %xmm5,%xmm4
  820cff:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d05:	movapd 0x10(%rsp),%xmm14
  820d0c:	subsd  %xmm5,%xmm14
  820d11:	ucomisd %xmm14,%xmm4
  820d16:	movsd  0x98(%rsp),%xmm14
  820d20:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820d26:	movapd 0x1c0(%rsp),%xmm4
  820d2f:	mulsd  %xmm7,%xmm4
  820d33:	mulsd  0x1b0(%rsp),%xmm7
  820d3c:	movapd 0x1e0(%rsp),%xmm5
  820d45:	mulsd  %xmm12,%xmm5
  820d4a:	movapd %xmm5,0x2c0(%rsp)
  820d53:	movapd %xmm4,0x2d0(%rsp)
  820d5c:	addsd  %xmm4,%xmm5
  820d60:	addsd  0xc0(%rsp),%xmm5
  820d69:	subsd  0x40(%rsp),%xmm5
  820d6f:	mulsd  0x1d0(%rsp),%xmm12
  820d79:	movapd %xmm12,%xmm4
  820d7e:	addsd  %xmm7,%xmm4
  820d82:	addsd  0xb0(%rsp),%xmm4
  820d8b:	addsd  0x30(%rsp),%xmm4
  820d91:	addsd  0x20(%rsp),%xmm4
  820d97:	addsd  -0x771527(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d9f:	mulsd  -0x770fcf(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820da7:	ucomisd %xmm5,%xmm4
  820dab:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820db1:	movapd 0x10(%rsp),%xmm14
  820db8:	subsd  %xmm5,%xmm14
  820dbd:	ucomisd %xmm14,%xmm4
  820dc2:	movsd  0x98(%rsp),%xmm14
  820dcc:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820dd2:	addsd  -0x771852(%rip),%xmm6        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820dda:	movapd %xmm6,%xmm4
  820dde:	mulsd  0x280(%rsp),%xmm4
  820de7:	movsd  %xmm4,0x168(%rsp)
  820df0:	addsd  %xmm4,%xmm15
  820df5:	addsd  0x120(%rsp),%xmm15
  820dff:	subsd  0x80(%rsp),%xmm15
  820e09:	movapd 0x270(%rsp),%xmm4
  820e12:	mulsd  %xmm6,%xmm4
  820e16:	movsd  %xmm4,0x160(%rsp)
  820e1f:	addsd  %xmm4,%xmm9
  820e24:	addsd  0x110(%rsp),%xmm9
  820e2e:	addsd  0x70(%rsp),%xmm9
  820e35:	addsd  0x60(%rsp),%xmm9
  820e3c:	addsd  -0x7715cd(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e45:	mulsd  -0x77164e(%rip),%xmm9        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820e4e:	addsd  0x8(%rsp),%xmm9
  820e55:	ucomisd %xmm15,%xmm9
  820e5a:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e60:	movapd 0x50(%rsp),%xmm4
  820e66:	subsd  %xmm15,%xmm4
  820e6b:	ucomisd %xmm4,%xmm9
  820e70:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820e76:	movapd 0x260(%rsp),%xmm15
  820e80:	mulsd  %xmm6,%xmm15
  820e85:	addsd  %xmm15,%xmm11
  820e8a:	addsd  0x100(%rsp),%xmm11
  820e94:	subsd  0x80(%rsp),%xmm11
  820e9e:	movapd 0x250(%rsp),%xmm4
  820ea7:	mulsd  %xmm6,%xmm4
  820eab:	movsd  %xmm4,0x158(%rsp)
  820eb4:	addsd  %xmm4,%xmm3
  820eb8:	addsd  0xf0(%rsp),%xmm3
  820ec1:	addsd  0x70(%rsp),%xmm3
  820ec7:	addsd  0x60(%rsp),%xmm3
  820ecd:	addsd  -0x77165d(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ed5:	mulsd  -0x771105(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820edd:	ucomisd %xmm11,%xmm3
  820ee2:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820ee8:	movapd 0x50(%rsp),%xmm4
  820eee:	subsd  %xmm11,%xmm4
  820ef3:	ucomisd %xmm4,%xmm3
  820ef7:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820efd:	movapd %xmm6,%xmm3
  820f01:	mulsd  0x220(%rsp),%xmm3
  820f0a:	movsd  %xmm3,0x150(%rsp)
  820f13:	movapd 0x130(%rsp),%xmm5
  820f1c:	addsd  %xmm3,%xmm5
  820f20:	addsd  0xd0(%rsp),%xmm5
  820f29:	subsd  0x40(%rsp),%xmm5
  820f2f:	movapd %xmm6,%xmm3
  820f33:	mulsd  0x210(%rsp),%xmm3
  820f3c:	movsd  %xmm3,0x130(%rsp)
  820f45:	addsd  %xmm3,%xmm2
  820f49:	addsd  0xe0(%rsp),%xmm2
  820f52:	addsd  0x30(%rsp),%xmm2
  820f58:	addsd  0x20(%rsp),%xmm2
  820f5e:	addsd  -0x7716ee(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f66:	mulsd  -0x77176e(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820f6e:	addsd  (%rsp),%xmm2
  820f73:	ucomisd %xmm5,%xmm2
  820f77:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f7d:	movapd 0x10(%rsp),%xmm3
  820f83:	subsd  %xmm5,%xmm3
  820f87:	ucomisd %xmm3,%xmm2
  820f8b:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820f91:	movapd 0x1e0(%rsp),%xmm2
  820f9a:	mulsd  %xmm6,%xmm2
  820f9e:	movapd %xmm2,0x290(%rsp)
  820fa7:	movapd 0x2d0(%rsp),%xmm4
  820fb0:	addsd  %xmm2,%xmm4
  820fb4:	addsd  0xc0(%rsp),%xmm4
  820fbd:	subsd  0x40(%rsp),%xmm4
  820fc3:	mulsd  0x1d0(%rsp),%xmm6
  820fcc:	addsd  %xmm6,%xmm7
  820fd0:	addsd  0xb0(%rsp),%xmm7
  820fd9:	addsd  0x30(%rsp),%xmm7
  820fdf:	addsd  0x20(%rsp),%xmm7
  820fe5:	addsd  -0x771775(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820fed:	mulsd  -0x77121d(%rip),%xmm7        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820ff5:	ucomisd %xmm4,%xmm7
  820ff9:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  820fff:	movapd 0x10(%rsp),%xmm2
  821005:	subsd  %xmm4,%xmm2
  821009:	ucomisd %xmm2,%xmm7
  82100d:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821013:	addsd  -0x771a94(%rip),%xmm13        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  82101c:	movapd %xmm13,%xmm3
  821021:	mulsd  0x2b0(%rsp),%xmm3
  82102a:	movapd %xmm13,%xmm2
  82102f:	mulsd  0x2a0(%rsp),%xmm2
  821038:	addsd  %xmm3,%xmm10
  82103d:	addsd  0x120(%rsp),%xmm10
  821047:	subsd  0x80(%rsp),%xmm10
  821051:	addsd  %xmm2,%xmm8
  821056:	addsd  0x110(%rsp),%xmm8
  821060:	addsd  0x70(%rsp),%xmm8
  821067:	addsd  0x60(%rsp),%xmm8
  82106e:	addsd  -0x7717ff(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821077:	mulsd  -0x771880(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821080:	addsd  0x8(%rsp),%xmm8
  821087:	ucomisd %xmm10,%xmm8
  82108c:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821092:	movapd 0x50(%rsp),%xmm4
  821098:	subsd  %xmm10,%xmm4
  82109d:	ucomisd %xmm4,%xmm8
  8210a2:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8210a8:	movapd 0x240(%rsp),%xmm7
  8210b1:	mulsd  %xmm13,%xmm7
  8210b6:	movapd 0x230(%rsp),%xmm5
  8210bf:	mulsd  %xmm13,%xmm5
  8210c4:	movapd 0x140(%rsp),%xmm4
  8210cd:	addsd  %xmm7,%xmm4
  8210d1:	addsd  0x100(%rsp),%xmm4
  8210da:	subsd  0x80(%rsp),%xmm4
  8210e3:	movsd  0x190(%rsp),%xmm10
  8210ed:	addsd  %xmm5,%xmm10
  8210f2:	addsd  0xf0(%rsp),%xmm10
  8210fc:	addsd  0x70(%rsp),%xmm10
  821103:	addsd  0x60(%rsp),%xmm10
  82110a:	addsd  -0x77189b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821113:	mulsd  -0x771344(%rip),%xmm10        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82111c:	ucomisd %xmm4,%xmm10
  821121:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821127:	movapd %xmm4,%xmm8
  82112c:	movapd 0x50(%rsp),%xmm4
  821132:	subsd  %xmm8,%xmm4
  821137:	ucomisd %xmm4,%xmm10
  82113c:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821142:	movapd %xmm13,%xmm8
  821147:	mulsd  0x200(%rsp),%xmm8
  821151:	movapd %xmm13,%xmm10
  821156:	mulsd  0x1f0(%rsp),%xmm10
  821160:	movsd  0x188(%rsp),%xmm9
  82116a:	addsd  %xmm8,%xmm9
  82116f:	addsd  0xd0(%rsp),%xmm9
  821179:	subsd  0x40(%rsp),%xmm9
  821180:	movapd %xmm15,%xmm4
  821185:	movsd  0x180(%rsp),%xmm15
  82118f:	movsd  %xmm10,0x140(%rsp)
  821199:	addsd  %xmm10,%xmm15
  82119e:	addsd  0xe0(%rsp),%xmm15
  8211a8:	addsd  0x30(%rsp),%xmm15
  8211af:	addsd  0x20(%rsp),%xmm15
  8211b6:	addsd  -0x771947(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211bf:	mulsd  -0x7719c8(%rip),%xmm15        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8211c8:	addsd  (%rsp),%xmm15
  8211ce:	ucomisd %xmm9,%xmm15
  8211d3:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211d9:	movapd %xmm9,%xmm10
  8211de:	movapd 0x10(%rsp),%xmm9
  8211e5:	subsd  %xmm10,%xmm9
  8211ea:	ucomisd %xmm9,%xmm15
  8211ef:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8211f5:	movapd 0x1c0(%rsp),%xmm9
  8211ff:	mulsd  %xmm13,%xmm9
  821204:	mulsd  0x1b0(%rsp),%xmm13
  82120e:	movapd 0x2c0(%rsp),%xmm10
  821218:	addsd  %xmm9,%xmm10
  82121d:	addsd  0xc0(%rsp),%xmm10
  821227:	subsd  0x40(%rsp),%xmm10
  82122e:	addsd  %xmm13,%xmm12
  821233:	addsd  0xb0(%rsp),%xmm12
  82123d:	addsd  0x30(%rsp),%xmm12
  821244:	addsd  0x20(%rsp),%xmm12
  82124b:	addsd  -0x7719dc(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821254:	mulsd  -0x771485(%rip),%xmm12        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82125d:	ucomisd %xmm10,%xmm12
  821262:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821268:	movapd %xmm10,%xmm11
  82126d:	movapd 0x10(%rsp),%xmm10
  821274:	subsd  %xmm11,%xmm10
  821279:	ucomisd %xmm10,%xmm12
  82127e:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821284:	movsd  0x168(%rsp),%xmm10
  82128e:	addsd  %xmm3,%xmm10
  821293:	addsd  0x120(%rsp),%xmm10
  82129d:	subsd  0x80(%rsp),%xmm10
  8212a7:	movsd  0x160(%rsp),%xmm11
  8212b1:	addsd  %xmm2,%xmm11
  8212b6:	addsd  0x110(%rsp),%xmm11
  8212c0:	addsd  0x70(%rsp),%xmm11
  8212c7:	addsd  0x60(%rsp),%xmm11
  8212ce:	addsd  -0x771a5f(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8212d7:	mulsd  -0x771ae0(%rip),%xmm11        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8212e0:	addsd  0x8(%rsp),%xmm11
  8212e7:	ucomisd %xmm10,%xmm11
  8212ec:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8212f2:	movapd %xmm4,%xmm15
  8212f7:	movapd 0x50(%rsp),%xmm2
  8212fd:	subsd  %xmm10,%xmm2
  821302:	ucomisd %xmm2,%xmm11
  821307:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82130d:	addsd  %xmm7,%xmm15
  821312:	addsd  0x100(%rsp),%xmm15
  82131c:	subsd  0x80(%rsp),%xmm15
  821326:	movsd  0x158(%rsp),%xmm2
  82132f:	addsd  %xmm5,%xmm2
  821333:	addsd  0xf0(%rsp),%xmm2
  82133c:	addsd  0x70(%rsp),%xmm2
  821342:	addsd  0x60(%rsp),%xmm2
  821348:	addsd  -0x771ad8(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821350:	mulsd  -0x771580(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821358:	ucomisd %xmm15,%xmm2
  82135d:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821363:	movapd %xmm2,%xmm3
  821367:	movapd 0x50(%rsp),%xmm2
  82136d:	subsd  %xmm15,%xmm2
  821372:	ucomisd %xmm2,%xmm3
  821376:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  82137c:	movsd  0x150(%rsp),%xmm2
  821385:	addsd  %xmm8,%xmm2
  82138a:	addsd  0xd0(%rsp),%xmm2
  821393:	subsd  0x40(%rsp),%xmm2
  821399:	movsd  0x130(%rsp),%xmm5
  8213a2:	addsd  0x140(%rsp),%xmm5
  8213ab:	addsd  0xe0(%rsp),%xmm5
  8213b4:	addsd  0x30(%rsp),%xmm5
  8213ba:	addsd  0x20(%rsp),%xmm5
  8213c0:	addsd  -0x771b50(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213c8:	mulsd  -0x771bd0(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  8213d0:	addsd  (%rsp),%xmm5
  8213d5:	ucomisd %xmm2,%xmm5
  8213d9:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213df:	movapd %xmm2,%xmm3
  8213e3:	movapd 0x10(%rsp),%xmm2
  8213e9:	subsd  %xmm3,%xmm2
  8213ed:	ucomisd %xmm2,%xmm5
  8213f1:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  8213f7:	movapd 0x290(%rsp),%xmm2
  821400:	addsd  %xmm9,%xmm2
  821405:	addsd  0xc0(%rsp),%xmm2
  82140e:	subsd  0x40(%rsp),%xmm2
  821414:	addsd  %xmm13,%xmm6
  821419:	addsd  0xb0(%rsp),%xmm6
  821422:	addsd  0x30(%rsp),%xmm6
  821428:	addsd  0x20(%rsp),%xmm6
  82142e:	addsd  -0x771bbe(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821436:	mulsd  -0x771666(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  82143e:	ucomisd %xmm2,%xmm6
  821442:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821448:	movapd %xmm2,%xmm3
  82144c:	movapd 0x10(%rsp),%xmm2
  821452:	subsd  %xmm3,%xmm2
  821456:	ucomisd %xmm2,%xmm6
  82145a:	jae    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x570>
  821460:	cmp    %rsi,%rcx
  821463:	jae    821538 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfc8>
  821469:	mov    0xac(%rsp),%eax
  821470:	mov    %eax,(%r12,%rcx,8)
  821474:	movl   $0x80000001,0x4(%r12,%rcx,8)
  82147d:	movsd  0x98(%rsp),%xmm14
  821487:	cmp    %r11,%rdi
  82148a:	jb     820af7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x587>
  821490:	mov    0x198(%rsp),%r10
  821498:	cmp    %r10,0x1a0(%rsp)
  8214a0:	jae    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8214a6:	cmp    %r10,%rbx
  8214a9:	jbe    820a20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4b0>
  8214af:	jmp    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8214b4:	mov    %rbx,%rax
  8214b7:	nopw   0x0(%rax,%rax,1)
  8214c0:	cmp    %r10,%rbx
  8214c3:	adc    $0x0,%rax
  8214c7:	mov    %rbx,%rdx
  8214ca:	imul   %r9,%rdx
  8214ce:	mov    0xa0(%rsp),%rdi
  8214d6:	cs nopw 0x0(%rax,%rax,1)
  8214e0:	lea    (%rdi,%rdx,1),%rcx
  8214e4:	cmp    %rsi,%rcx
  8214e7:	jae    82151b <<gpui_gpu::renderer::RendererState>::bin_draw+0xfab>
  8214e9:	cmp    %r11,%rdi
  8214ec:	mov    %rdi,%r8
  8214ef:	adc    $0x0,%r8
  8214f3:	incl   0x4(%r12,%rcx,8)
  8214f8:	cmp    %r11,%rdi
  8214fb:	jae    821505 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf95>
  8214fd:	mov    %r8,%rdi
  821500:	cmp    %r11,%r8
  821503:	jbe    8214e0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf70>
  821505:	cmp    %r10,%rbx
  821508:	jae    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82150e:	mov    %rax,%rbx
  821511:	cmp    %r10,%rax
  821514:	jbe    8214c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf50>
  821516:	jmp    8206e6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82151b:	lea    0x60cca6(%rip),%rdx        # e2e1c8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xb0>
  821522:	mov    %rcx,%rdi
  821525:	call   *0x65e605(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
  82152b:	lea    0x60cd86(%rip),%rdi        # e2e2b8 <anon.e7af5e0dba0d7261d22cb76253955a85.28.llvm.264339216088034180+0x10>
  821532:	call   *0x65e768(%rip)        # e7fca0 <_DYNAMIC+0x668>
  821538:	lea    0x60cca1(%rip),%rdx        # e2e1e0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  82153f:	mov    %rcx,%rdi
  821542:	call   *0x65e5e8(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
