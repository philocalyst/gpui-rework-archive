from pathlib import Path
import collections,hashlib,json,subprocess
CG=Path('/tmp/gpui-endpoint-csr-codegen');OUT=Path('/tmp/gpui-endpoint-csr-evidence')
DIS=Path('/tmp/gpui-qualified-spirv-root/bin/spirv-dis');VAL=DIS.with_name('spirv-val')
report={'tools':{},'lanes':{},'scope':'Generated WGSL and validated SPIR-V static costs, not native GPU ISA, timestamp duration, register pressure or a performance claim.'}
for tool in [DIS,VAL]:
 report['tools'][str(tool)]={'sha256':hashlib.sha256(tool.read_bytes()).hexdigest(),'version':subprocess.check_output([str(tool),'--version'],text=True)}
for label in ['baseline','candidate']:
 directory=CG/label/'shader-offline';entries={}
 for path in sorted(directory.glob('*.spv')):
  asm=path.with_suffix('.spvasm')
  subprocess.run([str(VAL),'--target-env','vulkan1.0',str(path)],check=True,capture_output=True)
  with asm.open('w') as stream:subprocess.run([str(DIS),str(path)],stdout=stream,check=True)
  ops=collections.Counter()
  for line in asm.read_text().splitlines():
   words=line.split()
   for word in words:
    if word.startswith('Op'):
     ops[word]+=1;break
  entries[path.name]={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'opcodes':dict(sorted(ops.items()))}
 assert len(entries)==8
 wgsl=CG/label/'shader-default/ui.wgsl'
 report['lanes'][label]={'default_wgsl_bytes':wgsl.stat().st_size,'default_wgsl_sha256':hashlib.sha256(wgsl.read_bytes()).hexdigest(),'spirv':entries}
 deltas={}
for name,old in report['lanes']['baseline']['spirv'].items():
 new=report['lanes']['candidate']['spirv'][name]
 deltas[name]={'bytes':new['bytes']-old['bytes'],'opcode_deltas':{op:new['opcodes'].get(op,0)-old['opcodes'].get(op,0) for op in sorted(set(old['opcodes'])|set(new['opcodes'])) if new['opcodes'].get(op,0)!=old['opcodes'].get(op,0)}}
report['spirv_deltas']=deltas
report['explicit_new_decode_operations']=[]
assert report['lanes']['baseline']==report['lanes']['candidate'], 'shipping shader artifacts must be exactly identical'
(OUT/'shader-cost-ledger.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'wgsl_bytes':{lane:row['default_wgsl_bytes'] for lane,row in report['lanes'].items()},'spirv_deltas':deltas},indent=2))
