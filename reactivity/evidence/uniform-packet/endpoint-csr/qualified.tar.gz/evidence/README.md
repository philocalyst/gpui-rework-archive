# Endpoint spare-bit CSR: correctness/static qualified, unadopted

Source `6bf679e2b2fe175d87eddeea7e4f7362f042bf17` is isolated at
`/tmp/gpui-endpoint-csr-sol`. It succeeds sealed `5559828a4f6d093401cc374654f634b4d8fb9ddb`
without modifying that source/evidence. Against shipping `7a5e1619a27010ec63f6c27506a6d1fcd113f67c`,
it removes the cursor vector, reverse ordinal cutoff and final statistics walk.
Forward retained suffix counts, normalization counters and complete reverse
traversal are inherited from 555. No zero-reference traversal skip is combined.

Each inclusive endpoint fits 23 bits, remaining fits 17, and uniform uses one bit:
2*23+17+1=64. Temporary remaining low 9 bits occupy x's spare bits; high 8 occupy
y's spare bits below its uniform tag. overflowing_sub implements the low-field
wrap and conditional high-field borrow. Both low 23 endpoints remain immutable.
Exhaustion DIRECTLY restores the exact original shipping [start, end] words.
Uniform tags are checked first, retaining full inline/compact draw addresses.
No final conversion walk or GPU decoder exists. The entire shader is shipping
byte for byte. Legacy common-5/inline-6 ABI, record/resource passes, source/clear
order, old opaque predicate, logical admission caps and public API remain.

Only renderer.rs changes production against shipping. source-audit.json checks
all unchanged regions, including full forward/resource/normalization/reverse
and upload/submission/Stats/replay paths against 555 as applicable. The only tile
upload follows complete reverse exhaustion. Replay and paint/slot commits retain
admitted packets and never rewrite tiles/references. Failed preparation revokes
eligibility and retains last-successful Stats. No mutable header is an identity
witness. No new retained fields, heap allocation, dependency, unsafe code, source
exception or SIMD/scalar policy fork is added. No 299c constant/prefix/coverage,
uniform planes/residency, shared sample rewrite or fused resource walk is carried.

The proof is discrete equivalence to the existing accepted predicate, not a new
universal strict-IEEE geometry theorem. Shader artifact identity preserves its
existing numeric contract. Actual readbacks use Mesa 26.1.4 llvmpipe; cross checks
are compilation, not native hardware/runtime claims.

All gates pass: default/fallback: 11 library/4 presentation/47 render/1 doc each;
offline: 12/4/48/1 with qualified spirv-val; strict default/offline all-target
Clippy with -D warnings; Apple ARM64/Windows MSVC all-feature library compilation;
formatting, clean source and all 1380 source/config guards. Rust/Cargo 1.97.1 actual
executables/versions and analysis tools are hash guarded. Boundary tests check
511/512/513,65535/65536, end4194304, every intermediate endpoint and exact final
words, empty-at-cap, last occupied endpoint and uniform-inline overlap. Actual
binning reaches 65536 and 32768 independent four-choice painter streams compare
exact suffix address order with a simple forward-list oracle. That oracle's
normalization is manual; full production-path evidence below is independent.

Original unchanged fixture 8773146b44150adb0150323d51f241c946fb5cda26328f004562dcd9dee39cc0
matches all 52 frozen shipping readbacks/35651584 bytes and every work Stats/ImageStats
field. Capacity intentionally falls 2048 bytes per fixed 512-tile frame. Full warm
validation, streaming records and all uploads remain: every 26-cell work/payload
bill is retained, including both 32k workloads. No API/harness revision witness
bypasses native warm validation.

Matched same-source 47 integration tests plus the identical nonshipping 1×1 HDR/P3
65536-count probe pass both preregistered 360s functional watchdogs. All 584 named
images/13484384 bytes and complete work Stats/ImageStats match by test name,
within-test ordinal, dimensions and format. All 574 current eligible CPU tile and
reference packets/401440 bytes per lane are also byte-exact shipping. Ten no-packet
scratch frames are labelled; their pixels/work still compare and no unpublishable
scratch is presented as a packet. The current CPU packet can differ from an older
queued target being read; both observations are explicit. An independent oracle
requires actual max-count [0, 65536] and every INLINE|6*ordinal address (all 65536),
plus exact empty [0, 0]. Local wrong-endpoint/reference analyzer copies must fail.
Exact observer/probe sources, manifests and binaries remain; source is restored.
Capture/calibration clocks are unqualified and provide no performance inference.

Actual wrong reverse-slot selection fails the address oracle, exit 101, and changes
28/52 retained public captures including SDR/HDR; restoration recovers exit 0. Separate
counter-only c+1 fails: 21280 vs 10640, exit 101; restoration recovers exit 0. Full faults,
logs, raw captures and actual executable hashes remain. No controls are dropped.
Every reported capacity delta equals the actual deleted old cursor charge; other
four scratch capacities match. Observed cursor capacity deletion is 0..4096 bytes.
Renderer 888->864 and RendererState 840->816 each shrink 24 bytes in this Linux build;
Stats 200 is unchanged. This is not allocator overhead, dynamic peak or RSS.

| Static cost | Shipping | Endpoint | Delta |
|---|---:|---:|---:|
| Non-test/comment core LOC |30692|30704|+12|
| Default linked.text |6403991|6403623|-368|
| Default linked.rodata |7012024|7012152|+128|
| Default.data.rel.ro |336384|336336|-48|
| Render body/static frame |9493/1416|9376/1400|-117/-16|
| bin_draw body/static frame |4184/824|4056/792|-128/-32|
| Reverse visit body/static frame |611/88|622/72|+11/-16|

Actual same-path locked/features/opt3/root v0/tokio builds preserve both real
fresh:false groups/library artifacts; emit-stack-sizes occurs exactly once.
Primary library argument vectors are exactly equal. Offline.text falls 368 and
.rodata is unchanged. CPU borrow/bit-decode/two-store work and helper growth are
charged alongside smaller whole code/frames. Generated WGSL 15180 bytes and all 8
SPIR-V artifacts are byte-identical shipping; no GPU operation is added. Complete
assembly, opcode/section/alias ledgers and exact source/core counts remain.
Static frames are not peak stack or additive call chains. No timing/adoption or
universal-win claim is made; no timed campaign was run or authorized.

All six prior archives, including 555 and b312's unfavorable bill, rehash unchanged.
No old tree/ELF/capture is modified. The new archive contains all raw images,
CPU packets/Stats, proof, patch/source/config snapshots, logs/guards/controls and
code/heap/upload bills. ELF bytes remain external with exact paths/sizes/hashes;
every archived payload is reopened and verified. Follow-on work stays separate.
