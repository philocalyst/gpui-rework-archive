from pathlib import Path
import hashlib,json,os,shutil,subprocess
ROOT=Path('/tmp/gpui-endpoint-csr-sol');OUT=Path('/tmp/gpui-endpoint-csr-evidence/negative-count');OUT.mkdir()
source=ROOT/'reactivity/crates/gpu/src/renderer.rs';original=source.read_bytes()
needle=b'samples * u64::from(count)';assert original.count(needle)==1
fault=original.replace(needle,b'samples * u64::from(count + 1)')
env=dict(os.environ);env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
env.update(CARGO_TARGET_DIR='/tmp/gpui-endpoint-csr-target',CARGO_BUILD_JOBS='1')
name='packed_csr_work_counters_use_clipped_areas_and_exact_survivors'
result={'source':'6bf679e2b2fe175d87eddeea7e4f7362f042bf17','original_source_sha256':hashlib.sha256(original).hexdigest(),'fault_source_sha256':hashlib.sha256(fault).hexdigest(),'fault_description':'Counter-only retained c+1; actual CSR allocation/ordering unchanged.'}
(OUT/'fault-renderer.rs').write_bytes(fault)
def run(label):
    d=OUT/label;d.mkdir()
    args=['cargo','test','--release','--offline','--locked','-p','gpui_gpu','--features','vulkan-tests','--test','render','--no-run','--message-format=json']
    with (d/'cargo.jsonl').open('w') as stdout,(d/'cargo.log').open('w') as stderr:
        subprocess.run(args,cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,check=True)
    artifacts=[json.loads(line) for line in (d/'cargo.jsonl').read_text().splitlines() if line.startswith('{')]
    artifact=next(a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='render')
    assert not artifact['fresh']
    exe=d/'render-tests';shutil.copy2(artifact['executable'],exe);exe.chmod(0o555)
    with (d/'stdout.log').open('w') as stdout,(d/'stderr.log').open('w') as stderr:
        p=subprocess.run([str(exe),name,'--exact','--nocapture'],cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,timeout=180)
    return {'returncode':p.returncode,'artifact':artifact,'binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest()}
try:
    source.write_bytes(fault)
    result['fault']=run('fault')
    text=(OUT/'fault/stderr.log').read_text()
    result['independent_wrong_count_detected']=result['fault']['returncode']==101 and 'left: 21280' in text and 'right: 10640' in text
    assert result['independent_wrong_count_detected'],text[-500:]
finally:
    source.write_bytes(original);assert source.read_bytes()==original
    result['exact_source_restored']=True
    (OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
result['recovery']=run('recovery');assert result['recovery']['returncode']==0
(OUT/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v if not isinstance(v,dict) else {'returncode':v['returncode']} for k,v in result.items()},indent=2))
