
FUNCTION <gpui_gpu::renderer::RendererState>::bin_draw bytes=4184 frame=824

/tmp/gpui-endpoint-csr-codegen/baseline/groups:     file format elf64-x86-64


Disassembly of section .text:

00000000008205f0 <<gpui_gpu::renderer::RendererState>::bin_draw>:
  8205f0:	push   %rbp
  8205f1:	push   %r15
  8205f3:	push   %r14
  8205f5:	push   %r13
  8205f7:	push   %r12
  8205f9:	push   %rbx
  8205fa:	sub    $0x308,%rsp
  820601:	movss  0x88(%rdx),%xmm3
  820609:	movss  -0x771655(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  820611:	movaps %xmm3,%xmm1
  820614:	subss  %xmm0,%xmm1
  820618:	cvttss2si %xmm1,%rax
  82061d:	cvttss2si %xmm3,%r10
  820622:	mov    %r10,%r12
  820625:	sar    $0x3f,%r12
  820629:	and    %rax,%r12
  82062c:	or     %r10,%r12
  82062f:	xor    %eax,%eax
  820631:	xorps  %xmm1,%xmm1
  820634:	ucomiss %xmm1,%xmm3
  820637:	cmovb  %rax,%r12
  82063b:	movss  0x90(%rdx),%xmm4
  820643:	movss  -0x77168b(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  82064b:	ucomiss %xmm2,%xmm3
  82064e:	mov    $0xffffffffffffffff,%r10
  820655:	cmova  %r10,%r12
  820659:	movaps %xmm4,%xmm3
  82065c:	subss  %xmm0,%xmm3
  820660:	cvttss2si %xmm3,%r11
  820665:	cvttss2si %xmm4,%rbx
  82066a:	mov    %rbx,%r14
  82066d:	sar    $0x3f,%r14
  820671:	and    %r11,%r14
  820674:	or     %rbx,%r14
  820677:	ucomiss %xmm1,%xmm4
  82067a:	cmovb  %rax,%r14
  82067e:	ucomiss %xmm2,%xmm4
  820681:	cmova  %r10,%r14
  820685:	movss  0x8c(%rdx),%xmm3
  82068d:	lea    (%r12,%r14,1),%rbx
  820691:	dec    %rbx
  820694:	shr    $0x4,%rbx
  820698:	shr    $0x4,%r12
  82069c:	mov    %rbx,%rbp
  82069f:	sub    %r12,%rbp
  8206a2:	inc    %rbp
  8206a5:	movaps %xmm3,%xmm4
  8206a8:	subss  %xmm0,%xmm4
  8206ac:	cvttss2si %xmm4,%r15
  8206b1:	cvttss2si %xmm3,%r11
  8206b6:	mov    %r11,%r14
  8206b9:	sar    $0x3f,%r14
  8206bd:	and    %r15,%r14
  8206c0:	or     %r11,%r14
  8206c3:	ucomiss %xmm1,%xmm3
  8206c6:	cmovb  %rax,%r14
  8206ca:	ucomiss %xmm2,%xmm3
  8206cd:	movss  0x94(%rdx),%xmm3
  8206d5:	cmova  %r10,%r14
  8206d9:	movaps %xmm3,%xmm4
  8206dc:	subss  %xmm0,%xmm4
  8206e0:	cvttss2si %xmm4,%r13
  8206e5:	cvttss2si %xmm3,%r11
  8206ea:	mov    %r11,%r15
  8206ed:	sar    $0x3f,%r15
  8206f1:	and    %r13,%r15
  8206f4:	or     %r11,%r15
  8206f7:	ucomiss %xmm1,%xmm3
  8206fa:	cmovb  %rax,%r15
  8206fe:	ucomiss %xmm2,%xmm3
  820701:	cmova  %r10,%r15
  820705:	lea    (%r14,%r15,1),%r10
  820709:	dec    %r10
  82070c:	shr    $0x4,%r10
  820710:	shr    $0x4,%r14
  820714:	mov    %r10,%r11
  820717:	sub    %r14,%r11
  82071a:	inc    %r11
  82071d:	imul   %rbp,%r11
  820721:	add    0x358(%rsp),%r11
  820729:	setb   %al
  82072c:	cmp    $0x400001,%r11
  820733:	setae  %bpl
  820737:	or     %al,%bpl
  82073a:	mov    $0x6,%eax
  82073f:	jne    82077f <<gpui_gpu::renderer::RendererState>::bin_draw+0x18f>
  820741:	mov    %r8d,0xac(%rsp)
  820749:	mov    %r9,0x98(%rsp)
  820751:	mov    %r11,0x190(%rsp)
  820759:	mov    %rdi,0x198(%rsp)
  820761:	cmp    %r14,%r10
  820764:	jae    820793 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1a3>
  820766:	mov    0x198(%rsp),%rdi
  82076e:	mov    0x190(%rsp),%rax
  820776:	mov    %rax,0x8(%rdi)
  82077a:	mov    $0xffffffff,%eax
  82077f:	mov    %eax,(%rdi)
  820781:	add    $0x308,%rsp
  820788:	pop    %rbx
  820789:	pop    %r12
  82078b:	pop    %r13
  82078d:	pop    %r14
  82078f:	pop    %r15
  820791:	pop    %rbp
  820792:	ret
  820793:	mov    %r12,%r9
  820796:	cmp    %r12,%rbx
  820799:	jae    8207b6 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1c6>
  82079b:	nopl   0x0(%rax,%rax,1)
  8207a0:	mov    %r14,%rax
  8207a3:	cmp    %r10,%r14
  8207a6:	adc    $0x0,%r14
  8207aa:	cmp    %r10,%rax
  8207ad:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8207af:	cmp    %r10,%r14
  8207b2:	jbe    8207a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1b0>
  8207b4:	jmp    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8207b6:	mov    0x340(%rsp),%r13
  8207be:	movd   0xa4(%rdx),%xmm0
  8207c6:	mov    0x20(%rsi),%rbp
  8207ca:	movdqu 0x98(%rdx),%xmm1
  8207d2:	movd   0xa0(%rdx),%xmm2
  8207da:	punpckldq %xmm0,%xmm2
  8207de:	punpcklqdq %xmm2,%xmm1
  8207e2:	movdqa -0x773eda(%rip),%xmm2        # ac910 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x110>
  8207ea:	pand   %xmm1,%xmm2
  8207ee:	paddd  -0x773c86(%rip),%xmm2        # acb70 <anon.fd4379edd0b71335c3c29b3337cd5ea0.320.llvm.353578272256937679+0x370>
  8207f6:	pxor   -0x7724ce(%rip),%xmm2        # ae330 <anon.630a3fff68f6bca64b568be97512ab45.101.llvm.826976926275214120+0x80>
  8207fe:	pcmpgtd -0x773076(%rip),%xmm2        # ad790 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x420>
  820806:	mov    %rsi,%rax
  820809:	mov    0x28(%rsi),%rsi
  82080d:	pandn  %xmm1,%xmm2
  820811:	movmskps %xmm2,%edi
  820814:	test   %edi,%edi
  820816:	mov    %r10,0xb8(%rsp)
  82081e:	jne    82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820824:	ucomiss -0x771aab(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  82082b:	jne    82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820831:	jp     82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820837:	cmpb   $0x0,0x340(%rax)
  82083e:	je     82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  820844:	cmpb   $0x0,(%rdx)
  820847:	jne    82159c <<gpui_gpu::renderer::RendererState>::bin_draw+0xfac>
  82084d:	test   %r13,%r13
  820850:	je     821613 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1023>
  820856:	mov    0x350(%rsp),%r12d
  82085e:	mov    0x348(%rsp),%r8d
  820866:	movd   %ecx,%xmm2
  82086a:	shr    $0x20,%rcx
  82086e:	movss  0x78(%rdx),%xmm0
  820873:	movss  0x80(%rdx),%xmm3
  82087b:	cvtss2sd %xmm0,%xmm0
  82087f:	movss  0x7c(%rdx),%xmm1
  820884:	cvtss2sd %xmm1,%xmm1
  820888:	cvtss2sd %xmm3,%xmm13
  82088d:	movss  0x84(%rdx),%xmm3
  820895:	addsd  %xmm0,%xmm13
  82089a:	cvtss2sd %xmm3,%xmm3
  82089e:	addsd  %xmm1,%xmm3
  8208a2:	movsd  %xmm3,0x1c8(%rsp)
  8208ab:	movsd  0x48(%rdx),%xmm6
  8208b0:	movsd  0x58(%rdx),%xmm7
  8208b5:	movss  0x38(%rdx),%xmm3
  8208ba:	movss  0x3c(%rdx),%xmm4
  8208bf:	movss  0x40(%rdx),%xmm5
  8208c4:	cvtss2sd %xmm3,%xmm8
  8208c9:	movss  0x44(%rdx),%xmm3
  8208ce:	cvtss2sd %xmm5,%xmm5
  8208d2:	movaps -0x775b2a(%rip),%xmm9        # aadb0 <GCC_except_table0+0x88>
  8208da:	movaps %xmm8,0x80(%rsp)
  8208e3:	andps  %xmm9,%xmm8
  8208e7:	movaps %xmm8,0x70(%rsp)
  8208ed:	movaps %xmm5,0x50(%rsp)
  8208f2:	andps  %xmm9,%xmm5
  8208f6:	movaps %xmm5,0x60(%rsp)
  8208fb:	cvtss2sd %xmm2,%xmm2
  8208ff:	movsd  %xmm2,0x8(%rsp)
  820905:	movaps %xmm6,%xmm2
  820908:	andps  %xmm9,%xmm2
  82090c:	movaps %xmm2,0x270(%rsp)
  820914:	movaps %xmm7,%xmm2
  820917:	andps  %xmm9,%xmm2
  82091b:	movaps %xmm2,0x250(%rsp)
  820923:	xorps  %xmm2,%xmm2
  820926:	cvtss2sd %xmm4,%xmm2
  82092a:	cvtss2sd %xmm3,%xmm3
  82092e:	movsd  0x68(%rdx),%xmm4
  820933:	movaps %xmm4,%xmm5
  820936:	andps  %xmm9,%xmm5
  82093a:	movaps %xmm5,0x100(%rsp)
  820942:	movaps %xmm2,0x40(%rsp)
  820947:	andps  %xmm9,%xmm2
  82094b:	movaps %xmm2,0x30(%rsp)
  820950:	movaps %xmm3,0x10(%rsp)
  820955:	andps  %xmm9,%xmm3
  820959:	movaps %xmm3,0x20(%rsp)
  82095e:	movd   %ecx,%xmm2
  820962:	cvtss2sd %xmm2,%xmm2
  820966:	movsd  %xmm2,(%rsp)
  82096b:	movsd  0x50(%rdx),%xmm2
  820970:	movaps %xmm2,%xmm3
  820973:	andps  %xmm9,%xmm3
  820977:	movaps %xmm3,0x1f0(%rsp)
  82097f:	movsd  0x60(%rdx),%xmm3
  820984:	movaps %xmm3,%xmm5
  820987:	andps  %xmm9,%xmm5
  82098b:	movaps %xmm5,0x1d0(%rsp)
  820993:	movsd  0x70(%rdx),%xmm5
  820998:	movaps %xmm5,%xmm8
  82099c:	andps  %xmm9,%xmm8
  8209a0:	movaps %xmm8,0xc0(%rsp)
  8209a9:	mov    0x58(%rax),%rcx
  8209ad:	mov    %rcx,0xb0(%rsp)
  8209b5:	mov    0x50(%rax),%rax
  8209b9:	mov    %rax,0x168(%rsp)
  8209c1:	mov    0x98(%rsp),%rax
  8209c9:	inc    %eax
  8209cb:	mov    %rax,0x98(%rsp)
  8209d3:	movaps %xmm2,0x200(%rsp)
  8209db:	cvtsd2ss %xmm2,%xmm2
  8209df:	xorps  %xmm8,%xmm8
  8209e3:	cvtss2sd %xmm2,%xmm8
  8209e8:	movaps %xmm6,0x280(%rsp)
  8209f0:	movaps %xmm6,%xmm2
  8209f3:	movaps %xmm7,0x260(%rsp)
  8209fb:	movlhps %xmm7,%xmm2
  8209fe:	cvtpd2ps %xmm2,%xmm2
  820a02:	cvtps2pd %xmm2,%xmm6
  820a05:	movaps %xmm3,0x1e0(%rsp)
  820a0d:	xorps  %xmm2,%xmm2
  820a10:	cvtsd2ss %xmm3,%xmm2
  820a14:	xorps  %xmm3,%xmm3
  820a17:	cvtss2sd %xmm2,%xmm3
  820a1b:	movaps %xmm4,0x110(%rsp)
  820a23:	xorps  %xmm2,%xmm2
  820a26:	cvtsd2ss %xmm4,%xmm2
  820a2a:	xorps  %xmm4,%xmm4
  820a2d:	cvtss2sd %xmm2,%xmm4
  820a31:	movaps %xmm5,0xd0(%rsp)
  820a39:	xorps  %xmm2,%xmm2
  820a3c:	cvtsd2ss %xmm5,%xmm2
  820a40:	cvtss2sd %xmm2,%xmm2
  820a44:	movaps %xmm6,%xmm5
  820a47:	andps  %xmm9,%xmm5
  820a4b:	movaps %xmm4,0x130(%rsp)
  820a53:	andps  %xmm9,%xmm4
  820a57:	movaps %xmm4,0x120(%rsp)
  820a5f:	movaps %xmm8,0x240(%rsp)
  820a68:	andps  %xmm9,%xmm8
  820a6c:	movaps %xmm8,0x230(%rsp)
  820a75:	movaps %xmm3,0x220(%rsp)
  820a7d:	andps  %xmm9,%xmm3
  820a81:	movaps %xmm3,0x210(%rsp)
  820a89:	movaps %xmm2,0xe0(%rsp)
  820a91:	andps  %xmm2,%xmm9
  820a95:	movaps %xmm9,0xf0(%rsp)
  820a9e:	movaps %xmm6,0x2a0(%rsp)
  820aa6:	movhlps %xmm6,%xmm6
  820aa9:	movaps %xmm6,0x2d0(%rsp)
  820ab1:	movaps %xmm5,0x290(%rsp)
  820ab9:	movhlps %xmm5,%xmm5
  820abc:	movaps %xmm5,0x2c0(%rsp)
  820ac4:	mov    %r9,0x1b8(%rsp)
  820acc:	movsd  %xmm13,0xa0(%rsp)
  820ad6:	cs nopw 0x0(%rax,%rax,1)
  820ae0:	mov    %r14,%rcx
  820ae3:	cmp    %r10,%r14
  820ae6:	adc    $0x0,%r14
  820aea:	mov    %rcx,0x1c0(%rsp)
  820af2:	imul   %r13,%rcx
  820af6:	mov    %r9,%rdi
  820af9:	nopl   0x0(%rax)
  820b00:	cmp    %rbx,%rdi
  820b03:	adc    $0x0,%r9
  820b07:	lea    (%rdi,%rcx,1),%r10
  820b0b:	mov    %r10,%rax
  820b0e:	shr    $0x20,%rax
  820b12:	je     820b20 <<gpui_gpu::renderer::RendererState>::bin_draw+0x530>
  820b14:	mov    %r10,%rax
  820b17:	xor    %edx,%edx
  820b19:	div    %r13
  820b1c:	jmp    820b28 <<gpui_gpu::renderer::RendererState>::bin_draw+0x538>
  820b1e:	xchg   %ax,%ax
  820b20:	mov    %r10d,%eax
  820b23:	xor    %edx,%edx
  820b25:	div    %r13d
  820b28:	shl    $0x4,%edx
  820b2b:	shl    $0x4,%eax
  820b2e:	lea    0x10(%rdx),%r11d
  820b32:	cmp    %r11d,%r8d
  820b35:	cmovb  %r8d,%r11d
  820b39:	lea    0x10(%rax),%r15d
  820b3d:	cmp    %r15d,%r12d
  820b40:	cmovb  %r12d,%r15d
  820b44:	xorps  %xmm11,%xmm11
  820b48:	cvtsi2sd %edx,%xmm11
  820b4d:	ucomisd %xmm11,%xmm0
  820b52:	ja     820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b54:	mov    %eax,%eax
  820b56:	xorps  %xmm2,%xmm2
  820b59:	cvtsi2sd %rax,%xmm2
  820b5e:	ucomisd %xmm2,%xmm1
  820b62:	ja     820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b64:	xorps  %xmm15,%xmm15
  820b68:	cvtsi2sd %r11d,%xmm15
  820b6d:	ucomisd %xmm13,%xmm15
  820b72:	ja     820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820b74:	xorps  %xmm14,%xmm14
  820b78:	cvtsi2sd %r15d,%xmm14
  820b7d:	ucomisd 0x1c8(%rsp),%xmm14
  820b87:	jbe    820bb8 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5c8>
  820b89:	nopl   0x0(%rax)
  820b90:	cmp    %rsi,%r10
  820b93:	jae    821603 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1013>
  820b99:	incl   0x4(%rbp,%r10,8)
  820b9e:	cmp    %rbx,%rdi
  820ba1:	jae    821570 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf80>
  820ba7:	mov    %r9,%rdi
  820baa:	cmp    %rbx,%r9
  820bad:	jbe    820b00 <<gpui_gpu::renderer::RendererState>::bin_draw+0x510>
  820bb3:	jmp    821570 <<gpui_gpu::renderer::RendererState>::bin_draw+0xf80>
  820bb8:	unpcklpd %xmm2,%xmm11
  820bbd:	addpd  -0x773af6(%rip),%xmm11        # ad0d0 <anon.a16d5d421a76dfd8c37a17b53540311d.58.llvm.14190004212411149437+0x270>
  820bc6:	movapd %xmm11,%xmm9
  820bcb:	mulpd  0x2a0(%rsp),%xmm9
  820bd5:	movapd %xmm9,%xmm12
  820bda:	unpckhpd %xmm9,%xmm12
  820bdf:	movapd %xmm9,%xmm2
  820be4:	addsd  %xmm12,%xmm2
  820be9:	addsd  0x130(%rsp),%xmm2
  820bf2:	subsd  0x80(%rsp),%xmm2
  820bfb:	movapd 0x290(%rsp),%xmm7
  820c04:	mulpd  %xmm11,%xmm7
  820c09:	movapd %xmm7,%xmm8
  820c0e:	unpckhpd %xmm7,%xmm8
  820c13:	movapd %xmm7,%xmm3
  820c17:	addsd  %xmm8,%xmm3
  820c1c:	addsd  0x120(%rsp),%xmm3
  820c25:	addsd  0x70(%rsp),%xmm3
  820c2b:	addsd  0x60(%rsp),%xmm3
  820c31:	addsd  -0x7713c1(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820c39:	mulsd  -0x771441(%rip),%xmm3        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820c41:	addsd  0x8(%rsp),%xmm3
  820c47:	ucomisd %xmm2,%xmm3
  820c4b:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820c51:	movapd 0x50(%rsp),%xmm4
  820c57:	subsd  %xmm2,%xmm4
  820c5b:	ucomisd %xmm4,%xmm3
  820c5f:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820c65:	movapd %xmm11,%xmm6
  820c6a:	unpckhpd %xmm11,%xmm6
  820c6f:	movapd 0x260(%rsp),%xmm10
  820c79:	mulsd  %xmm6,%xmm10
  820c7e:	movapd 0x250(%rsp),%xmm3
  820c87:	mulsd  %xmm6,%xmm3
  820c8b:	movapd 0x280(%rsp),%xmm2
  820c94:	mulsd  %xmm11,%xmm2
  820c99:	movapd %xmm2,0x150(%rsp)
  820ca2:	addsd  %xmm10,%xmm2
  820ca7:	addsd  0x110(%rsp),%xmm2
  820cb0:	subsd  0x80(%rsp),%xmm2
  820cb9:	movapd 0x270(%rsp),%xmm4
  820cc2:	mulsd  %xmm11,%xmm4
  820cc7:	movsd  %xmm4,0x1b0(%rsp)
  820cd0:	addsd  %xmm3,%xmm4
  820cd4:	addsd  0x100(%rsp),%xmm4
  820cdd:	addsd  0x70(%rsp),%xmm4
  820ce3:	addsd  0x60(%rsp),%xmm4
  820ce9:	addsd  -0x771479(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820cf1:	mulsd  -0x770f21(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820cf9:	ucomisd %xmm2,%xmm4
  820cfd:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d03:	movapd 0x50(%rsp),%xmm5
  820d09:	subsd  %xmm2,%xmm5
  820d0d:	ucomisd %xmm5,%xmm4
  820d11:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820d17:	movapd %xmm6,%xmm4
  820d1b:	mulsd  0x220(%rsp),%xmm4
  820d24:	movapd %xmm6,%xmm2
  820d28:	mulsd  0x210(%rsp),%xmm2
  820d31:	movapd %xmm11,%xmm5
  820d36:	mulsd  0x240(%rsp),%xmm5
  820d3f:	movsd  %xmm5,0x1a8(%rsp)
  820d48:	movapd %xmm4,0x140(%rsp)
  820d51:	addsd  %xmm4,%xmm5
  820d55:	addsd  0xe0(%rsp),%xmm5
  820d5e:	subsd  0x40(%rsp),%xmm5
  820d64:	movapd %xmm11,%xmm4
  820d69:	mulsd  0x230(%rsp),%xmm4
  820d72:	movsd  %xmm4,0x1a0(%rsp)
  820d7b:	addsd  %xmm2,%xmm4
  820d7f:	addsd  0xf0(%rsp),%xmm4
  820d88:	addsd  0x30(%rsp),%xmm4
  820d8e:	addsd  0x20(%rsp),%xmm4
  820d94:	addsd  -0x771524(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820d9c:	mulsd  -0x7715a4(%rip),%xmm4        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820da4:	addsd  (%rsp),%xmm4
  820da9:	ucomisd %xmm5,%xmm4
  820dad:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820db3:	movapd 0x10(%rsp),%xmm13
  820dba:	subsd  %xmm5,%xmm13
  820dbf:	ucomisd %xmm13,%xmm4
  820dc4:	movsd  0xa0(%rsp),%xmm13
  820dce:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820dd4:	movapd 0x1e0(%rsp),%xmm4
  820ddd:	mulsd  %xmm6,%xmm4
  820de1:	mulsd  0x1d0(%rsp),%xmm6
  820dea:	movapd 0x200(%rsp),%xmm5
  820df3:	mulsd  %xmm11,%xmm5
  820df8:	movapd %xmm5,0x2e0(%rsp)
  820e01:	movapd %xmm4,0x2f0(%rsp)
  820e0a:	addsd  %xmm4,%xmm5
  820e0e:	addsd  0xd0(%rsp),%xmm5
  820e17:	subsd  0x40(%rsp),%xmm5
  820e1d:	mulsd  0x1f0(%rsp),%xmm11
  820e27:	movapd %xmm11,%xmm4
  820e2c:	addsd  %xmm6,%xmm4
  820e30:	addsd  0xc0(%rsp),%xmm4
  820e39:	addsd  0x30(%rsp),%xmm4
  820e3f:	addsd  0x20(%rsp),%xmm4
  820e45:	addsd  -0x7715d5(%rip),%xmm4        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820e4d:	mulsd  -0x77107d(%rip),%xmm4        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820e55:	ucomisd %xmm5,%xmm4
  820e59:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820e5f:	movapd 0x10(%rsp),%xmm13
  820e66:	subsd  %xmm5,%xmm13
  820e6b:	ucomisd %xmm13,%xmm4
  820e70:	movsd  0xa0(%rsp),%xmm13
  820e7a:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820e80:	addsd  -0x771901(%rip),%xmm15        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  820e89:	movapd %xmm15,%xmm4
  820e8e:	mulsd  0x2a0(%rsp),%xmm4
  820e97:	movsd  %xmm4,0x188(%rsp)
  820ea0:	addsd  %xmm4,%xmm12
  820ea5:	addsd  0x130(%rsp),%xmm12
  820eaf:	subsd  0x80(%rsp),%xmm12
  820eb9:	movapd 0x290(%rsp),%xmm4
  820ec2:	mulsd  %xmm15,%xmm4
  820ec7:	movsd  %xmm4,0x180(%rsp)
  820ed0:	addsd  %xmm4,%xmm8
  820ed5:	addsd  0x120(%rsp),%xmm8
  820edf:	addsd  0x70(%rsp),%xmm8
  820ee6:	addsd  0x60(%rsp),%xmm8
  820eed:	addsd  -0x77167e(%rip),%xmm8        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820ef6:	mulsd  -0x7716ff(%rip),%xmm8        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  820eff:	addsd  0x8(%rsp),%xmm8
  820f06:	ucomisd %xmm12,%xmm8
  820f0b:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f11:	movapd 0x50(%rsp),%xmm4
  820f17:	subsd  %xmm12,%xmm4
  820f1c:	ucomisd %xmm4,%xmm8
  820f21:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f27:	movapd 0x280(%rsp),%xmm12
  820f31:	mulsd  %xmm15,%xmm12
  820f36:	addsd  %xmm12,%xmm10
  820f3b:	addsd  0x110(%rsp),%xmm10
  820f45:	subsd  0x80(%rsp),%xmm10
  820f4f:	movapd 0x270(%rsp),%xmm4
  820f58:	mulsd  %xmm15,%xmm4
  820f5d:	movsd  %xmm4,0x178(%rsp)
  820f66:	addsd  %xmm4,%xmm3
  820f6a:	addsd  0x100(%rsp),%xmm3
  820f73:	addsd  0x70(%rsp),%xmm3
  820f79:	addsd  0x60(%rsp),%xmm3
  820f7f:	addsd  -0x77170f(%rip),%xmm3        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  820f87:	mulsd  -0x7711b7(%rip),%xmm3        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  820f8f:	ucomisd %xmm10,%xmm3
  820f94:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820f9a:	movapd 0x50(%rsp),%xmm4
  820fa0:	subsd  %xmm10,%xmm4
  820fa5:	ucomisd %xmm4,%xmm3
  820fa9:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  820faf:	movapd %xmm15,%xmm3
  820fb4:	mulsd  0x240(%rsp),%xmm3
  820fbd:	movsd  %xmm3,0x170(%rsp)
  820fc6:	movapd 0x140(%rsp),%xmm5
  820fcf:	addsd  %xmm3,%xmm5
  820fd3:	addsd  0xe0(%rsp),%xmm5
  820fdc:	subsd  0x40(%rsp),%xmm5
  820fe2:	movapd %xmm15,%xmm3
  820fe7:	mulsd  0x230(%rsp),%xmm3
  820ff0:	movsd  %xmm3,0x140(%rsp)
  820ff9:	addsd  %xmm3,%xmm2
  820ffd:	addsd  0xf0(%rsp),%xmm2
  821006:	addsd  0x30(%rsp),%xmm2
  82100c:	addsd  0x20(%rsp),%xmm2
  821012:	addsd  -0x7717a2(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82101a:	mulsd  -0x771822(%rip),%xmm2        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821022:	addsd  (%rsp),%xmm2
  821027:	ucomisd %xmm5,%xmm2
  82102b:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821031:	movapd 0x10(%rsp),%xmm3
  821037:	subsd  %xmm5,%xmm3
  82103b:	ucomisd %xmm3,%xmm2
  82103f:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821045:	movapd 0x200(%rsp),%xmm2
  82104e:	mulsd  %xmm15,%xmm2
  821053:	movapd %xmm2,0x2b0(%rsp)
  82105c:	movapd 0x2f0(%rsp),%xmm4
  821065:	addsd  %xmm2,%xmm4
  821069:	addsd  0xd0(%rsp),%xmm4
  821072:	subsd  0x40(%rsp),%xmm4
  821078:	mulsd  0x1f0(%rsp),%xmm15
  821082:	addsd  %xmm15,%xmm6
  821087:	addsd  0xc0(%rsp),%xmm6
  821090:	addsd  0x30(%rsp),%xmm6
  821096:	addsd  0x20(%rsp),%xmm6
  82109c:	addsd  -0x77182c(%rip),%xmm6        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8210a4:	mulsd  -0x7712d4(%rip),%xmm6        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8210ac:	ucomisd %xmm4,%xmm6
  8210b0:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8210b6:	movapd 0x10(%rsp),%xmm2
  8210bc:	subsd  %xmm4,%xmm2
  8210c0:	ucomisd %xmm2,%xmm6
  8210c4:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8210ca:	addsd  -0x771b4b(%rip),%xmm14        # af588 <anon.630a3fff68f6bca64b568be97512ab45.206.llvm.826976926275214120+0x30>
  8210d3:	movapd %xmm14,%xmm3
  8210d8:	mulsd  0x2d0(%rsp),%xmm3
  8210e1:	movapd %xmm14,%xmm2
  8210e6:	mulsd  0x2c0(%rsp),%xmm2
  8210ef:	addsd  %xmm3,%xmm9
  8210f4:	addsd  0x130(%rsp),%xmm9
  8210fe:	subsd  0x80(%rsp),%xmm9
  821108:	addsd  %xmm2,%xmm7
  82110c:	addsd  0x120(%rsp),%xmm7
  821115:	addsd  0x70(%rsp),%xmm7
  82111b:	addsd  0x60(%rsp),%xmm7
  821121:	addsd  -0x7718b1(%rip),%xmm7        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821129:	mulsd  -0x771931(%rip),%xmm7        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821131:	addsd  0x8(%rsp),%xmm7
  821137:	ucomisd %xmm9,%xmm7
  82113c:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821142:	movapd 0x50(%rsp),%xmm4
  821148:	subsd  %xmm9,%xmm4
  82114d:	ucomisd %xmm4,%xmm7
  821151:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821157:	movapd 0x260(%rsp),%xmm6
  821160:	mulsd  %xmm14,%xmm6
  821165:	movapd 0x250(%rsp),%xmm5
  82116e:	mulsd  %xmm14,%xmm5
  821173:	movapd 0x150(%rsp),%xmm4
  82117c:	addsd  %xmm6,%xmm4
  821180:	addsd  0x110(%rsp),%xmm4
  821189:	subsd  0x80(%rsp),%xmm4
  821192:	movsd  0x1b0(%rsp),%xmm9
  82119c:	addsd  %xmm5,%xmm9
  8211a1:	addsd  0x100(%rsp),%xmm9
  8211ab:	addsd  0x70(%rsp),%xmm9
  8211b2:	addsd  0x60(%rsp),%xmm9
  8211b9:	addsd  -0x77194a(%rip),%xmm9        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8211c2:	mulsd  -0x7713f3(%rip),%xmm9        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8211cb:	ucomisd %xmm4,%xmm9
  8211d0:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8211d6:	movapd %xmm4,%xmm7
  8211da:	movapd 0x50(%rsp),%xmm4
  8211e0:	subsd  %xmm7,%xmm4
  8211e4:	ucomisd %xmm4,%xmm9
  8211e9:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8211ef:	movapd %xmm14,%xmm7
  8211f4:	mulsd  0x220(%rsp),%xmm7
  8211fd:	movapd %xmm14,%xmm9
  821202:	mulsd  0x210(%rsp),%xmm9
  82120c:	movsd  0x1a8(%rsp),%xmm8
  821216:	addsd  %xmm7,%xmm8
  82121b:	addsd  0xe0(%rsp),%xmm8
  821225:	subsd  0x40(%rsp),%xmm8
  82122c:	movapd %xmm12,%xmm4
  821231:	movsd  0x1a0(%rsp),%xmm12
  82123b:	movsd  %xmm9,0x150(%rsp)
  821245:	addsd  %xmm9,%xmm12
  82124a:	addsd  0xf0(%rsp),%xmm12
  821254:	addsd  0x30(%rsp),%xmm12
  82125b:	addsd  0x20(%rsp),%xmm12
  821262:	addsd  -0x7719f3(%rip),%xmm12        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  82126b:	mulsd  -0x771a74(%rip),%xmm12        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  821274:	addsd  (%rsp),%xmm12
  82127a:	ucomisd %xmm8,%xmm12
  82127f:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821285:	movapd %xmm8,%xmm9
  82128a:	movapd 0x10(%rsp),%xmm8
  821291:	subsd  %xmm9,%xmm8
  821296:	ucomisd %xmm8,%xmm12
  82129b:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8212a1:	movapd 0x1e0(%rsp),%xmm8
  8212ab:	mulsd  %xmm14,%xmm8
  8212b0:	mulsd  0x1d0(%rsp),%xmm14
  8212ba:	movapd 0x2e0(%rsp),%xmm9
  8212c4:	addsd  %xmm8,%xmm9
  8212c9:	addsd  0xd0(%rsp),%xmm9
  8212d3:	subsd  0x40(%rsp),%xmm9
  8212da:	addsd  %xmm14,%xmm11
  8212df:	addsd  0xc0(%rsp),%xmm11
  8212e9:	addsd  0x30(%rsp),%xmm11
  8212f0:	addsd  0x20(%rsp),%xmm11
  8212f7:	addsd  -0x771a88(%rip),%xmm11        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821300:	mulsd  -0x771531(%rip),%xmm11        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821309:	ucomisd %xmm9,%xmm11
  82130e:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821314:	movapd %xmm9,%xmm10
  821319:	movapd 0x10(%rsp),%xmm9
  821320:	subsd  %xmm10,%xmm9
  821325:	ucomisd %xmm9,%xmm11
  82132a:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821330:	movsd  0x188(%rsp),%xmm9
  82133a:	addsd  %xmm3,%xmm9
  82133f:	addsd  0x130(%rsp),%xmm9
  821349:	subsd  0x80(%rsp),%xmm9
  821353:	movsd  0x180(%rsp),%xmm10
  82135d:	addsd  %xmm2,%xmm10
  821362:	addsd  0x120(%rsp),%xmm10
  82136c:	addsd  0x70(%rsp),%xmm10
  821373:	addsd  0x60(%rsp),%xmm10
  82137a:	addsd  -0x771b0b(%rip),%xmm10        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821383:	mulsd  -0x771b8c(%rip),%xmm10        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82138c:	addsd  0x8(%rsp),%xmm10
  821393:	ucomisd %xmm9,%xmm10
  821398:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  82139e:	movapd %xmm4,%xmm12
  8213a3:	movapd 0x50(%rsp),%xmm2
  8213a9:	subsd  %xmm9,%xmm2
  8213ae:	ucomisd %xmm2,%xmm10
  8213b3:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8213b9:	addsd  %xmm6,%xmm12
  8213be:	addsd  0x110(%rsp),%xmm12
  8213c8:	subsd  0x80(%rsp),%xmm12
  8213d2:	movsd  0x178(%rsp),%xmm2
  8213db:	addsd  %xmm5,%xmm2
  8213df:	addsd  0x100(%rsp),%xmm2
  8213e8:	addsd  0x70(%rsp),%xmm2
  8213ee:	addsd  0x60(%rsp),%xmm2
  8213f4:	addsd  -0x771b84(%rip),%xmm2        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8213fc:	mulsd  -0x77162c(%rip),%xmm2        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  821404:	ucomisd %xmm12,%xmm2
  821409:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  82140f:	movapd %xmm2,%xmm3
  821413:	movapd 0x50(%rsp),%xmm2
  821419:	subsd  %xmm12,%xmm2
  82141e:	ucomisd %xmm2,%xmm3
  821422:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821428:	movsd  0x170(%rsp),%xmm2
  821431:	addsd  %xmm7,%xmm2
  821435:	addsd  0xe0(%rsp),%xmm2
  82143e:	subsd  0x40(%rsp),%xmm2
  821444:	movsd  0x140(%rsp),%xmm5
  82144d:	addsd  0x150(%rsp),%xmm5
  821456:	addsd  0xf0(%rsp),%xmm5
  82145f:	addsd  0x30(%rsp),%xmm5
  821465:	addsd  0x20(%rsp),%xmm5
  82146b:	addsd  -0x771bfb(%rip),%xmm5        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  821473:	mulsd  -0x771c7b(%rip),%xmm5        # af800 <anon.4109cdd7ddb1990ee57d5626700ecb68.164.llvm.4479275319843201559+0x18>
  82147b:	addsd  (%rsp),%xmm5
  821480:	ucomisd %xmm2,%xmm5
  821484:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  82148a:	movapd %xmm2,%xmm3
  82148e:	movapd 0x10(%rsp),%xmm2
  821494:	subsd  %xmm3,%xmm2
  821498:	ucomisd %xmm2,%xmm5
  82149c:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8214a2:	movapd 0x2b0(%rsp),%xmm2
  8214ab:	addsd  %xmm8,%xmm2
  8214b0:	addsd  0xd0(%rsp),%xmm2
  8214b9:	subsd  0x40(%rsp),%xmm2
  8214bf:	addsd  %xmm14,%xmm15
  8214c4:	addsd  0xc0(%rsp),%xmm15
  8214ce:	addsd  0x30(%rsp),%xmm15
  8214d5:	addsd  0x20(%rsp),%xmm15
  8214dc:	addsd  -0x771c6d(%rip),%xmm15        # af878 <anon.630a3fff68f6bca64b568be97512ab45.85.llvm.826976926275214120+0x8>
  8214e5:	mulsd  -0x771716(%rip),%xmm15        # afdd8 <anon.630a3fff68f6bca64b568be97512ab45.143.llvm.826976926275214120+0x8>
  8214ee:	ucomisd %xmm2,%xmm15
  8214f3:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  8214f9:	movapd %xmm2,%xmm3
  8214fd:	movapd 0x10(%rsp),%xmm2
  821503:	subsd  %xmm3,%xmm2
  821507:	ucomisd %xmm2,%xmm15
  82150c:	jae    820b90 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5a0>
  821512:	cmp    %rsi,%r10
  821515:	jae    821620 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1030>
  82151b:	mov    0xac(%rsp),%eax
  821522:	mov    %eax,0x0(%rbp,%r10,8)
  821527:	movl   $0x1,0x4(%rbp,%r10,8)
  821530:	cmp    0xb0(%rsp),%r10
  821538:	jae    821630 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1040>
  82153e:	mov    0x98(%rsp),%rax
  821546:	mov    0x168(%rsp),%rdx
  82154e:	mov    %eax,(%rdx,%r10,4)
  821552:	movsd  0xa0(%rsp),%xmm13
  82155c:	cmp    %rbx,%rdi
  82155f:	jb     820ba7 <<gpui_gpu::renderer::RendererState>::bin_draw+0x5b7>
  821565:	data16 cs nopw 0x0(%rax,%rax,1)
  821570:	mov    0xb8(%rsp),%r10
  821578:	cmp    %r10,0x1c0(%rsp)
  821580:	mov    0x1b8(%rsp),%r9
  821588:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82158e:	cmp    %r10,%r14
  821591:	jbe    820ae0 <<gpui_gpu::renderer::RendererState>::bin_draw+0x4f0>
  821597:	jmp    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  82159c:	mov    %r14,%rax
  82159f:	nop
  8215a0:	cmp    %r10,%r14
  8215a3:	adc    $0x0,%rax
  8215a7:	mov    %r14,%rcx
  8215aa:	imul   %r13,%rcx
  8215ae:	mov    %r9,%rdx
  8215b1:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  8215c0:	lea    (%rdx,%rcx,1),%r10
  8215c4:	cmp    %rsi,%r10
  8215c7:	jae    821603 <<gpui_gpu::renderer::RendererState>::bin_draw+0x1013>
  8215c9:	cmp    %rbx,%rdx
  8215cc:	mov    %rdx,%rdi
  8215cf:	adc    $0x0,%rdi
  8215d3:	incl   0x4(%rbp,%r10,8)
  8215d8:	cmp    %rbx,%rdx
  8215db:	jae    8215e5 <<gpui_gpu::renderer::RendererState>::bin_draw+0xff5>
  8215dd:	mov    %rdi,%rdx
  8215e0:	cmp    %rbx,%rdi
  8215e3:	jbe    8215c0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfd0>
  8215e5:	mov    0xb8(%rsp),%r10
  8215ed:	cmp    %r10,%r14
  8215f0:	jae    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  8215f6:	mov    %rax,%r14
  8215f9:	cmp    %r10,%rax
  8215fc:	jbe    8215a0 <<gpui_gpu::renderer::RendererState>::bin_draw+0xfb0>
  8215fe:	jmp    820766 <<gpui_gpu::renderer::RendererState>::bin_draw+0x176>
  821603:	lea    0x60ccd6(%rip),%rdx        # e2e2e0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xc8>
  82160a:	mov    %r10,%rdi
  82160d:	call   *0x65e64d(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  821613:	lea    0x60cdce(%rip),%rdi        # e2e3e8 <anon.e7af5e0dba0d7261d22cb76253955a85.29.llvm.10167252663607395722+0x10>
  82161a:	call   *0x65e728(%rip)        # e7fd48 <_DYNAMIC+0x5e0>
  821620:	lea    0x60ccd1(%rip),%rdx        # e2e2f8 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xe0>
  821627:	mov    %r10,%rdi
  82162a:	call   *0x65e630(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
  821630:	lea    0x60ccd9(%rip),%rdx        # e2e310 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0xf8>
  821637:	mov    %r10,%rdi
  82163a:	mov    0xb0(%rsp),%rsi
  821642:	call   *0x65e618(%rip)        # e7fc60 <_DYNAMIC+0x4f8>
