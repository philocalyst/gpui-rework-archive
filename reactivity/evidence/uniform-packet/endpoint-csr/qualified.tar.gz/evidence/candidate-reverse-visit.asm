
FUNCTION gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}> bytes=622 frame=72

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081c5d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>:
  81c5d0:	push   %rbp
  81c5d1:	push   %r15
  81c5d3:	push   %r14
  81c5d5:	push   %r13
  81c5d7:	push   %r12
  81c5d9:	push   %rbx
  81c5da:	sub    $0x18,%rsp
  81c5de:	movss  0x8c(%rdi),%xmm3
  81c5e6:	movss  -0x76d632(%rip),%xmm0        # aefbc <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x30>
  81c5ee:	movaps %xmm3,%xmm1
  81c5f1:	subss  %xmm0,%xmm1
  81c5f5:	cvttss2si %xmm1,%rax
  81c5fa:	cvttss2si %xmm3,%r8
  81c5ff:	mov    %r8,%rcx
  81c602:	sar    $0x3f,%rcx
  81c606:	and    %rax,%rcx
  81c609:	or     %r8,%rcx
  81c60c:	xor    %r9d,%r9d
  81c60f:	xorps  %xmm1,%xmm1
  81c612:	ucomiss %xmm1,%xmm3
  81c615:	cmovb  %r9,%rcx
  81c619:	movss  -0x76d661(%rip),%xmm2        # aefc0 <anon.a16d5d421a76dfd8c37a17b53540311d.81.llvm.14190004212411149437+0x34>
  81c621:	ucomiss %xmm2,%xmm3
  81c624:	mov    $0xffffffffffffffff,%rax
  81c62b:	cmova  %rax,%rcx
  81c62f:	movss  0x94(%rdi),%xmm3
  81c637:	mov    %rcx,%r8
  81c63a:	shr    $0x4,%r8
  81c63e:	movaps %xmm3,%xmm4
  81c641:	subss  %xmm0,%xmm4
  81c645:	cvttss2si %xmm4,%r10
  81c64a:	cvttss2si %xmm3,%r11
  81c64f:	mov    %r11,%rbx
  81c652:	sar    $0x3f,%rbx
  81c656:	and    %r10,%rbx
  81c659:	or     %r11,%rbx
  81c65c:	ucomiss %xmm1,%xmm3
  81c65f:	cmovb  %r9,%rbx
  81c663:	ucomiss %xmm2,%xmm3
  81c666:	cmova  %rax,%rbx
  81c66a:	mov    %rsi,0x10(%rsp)
  81c66f:	lea    (%rcx,%rbx,1),%r9
  81c673:	dec    %r9
  81c676:	shr    $0x4,%r9
  81c67a:	cmp    %r9,%r8
  81c67d:	jbe    81c68e <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xbe>
  81c67f:	add    $0x18,%rsp
  81c683:	pop    %rbx
  81c684:	pop    %r12
  81c686:	pop    %r13
  81c688:	pop    %r14
  81c68a:	pop    %r15
  81c68c:	pop    %rbp
  81c68d:	ret
  81c68e:	movss  0x88(%rdi),%xmm3
  81c696:	movaps %xmm3,%xmm4
  81c699:	subss  %xmm0,%xmm4
  81c69d:	cvttss2si %xmm4,%rsi
  81c6a2:	cvttss2si %xmm3,%r10
  81c6a7:	mov    %r10,%rcx
  81c6aa:	sar    $0x3f,%rcx
  81c6ae:	and    %rsi,%rcx
  81c6b1:	or     %r10,%rcx
  81c6b4:	xor    %esi,%esi
  81c6b6:	ucomiss %xmm1,%xmm3
  81c6b9:	cmovb  %rsi,%rcx
  81c6bd:	ucomiss %xmm2,%xmm3
  81c6c0:	cmova  %rax,%rcx
  81c6c4:	movss  0x90(%rdi),%xmm3
  81c6cc:	mov    %rcx,%rbx
  81c6cf:	shr    $0x4,%rbx
  81c6d3:	movaps %xmm3,%xmm4
  81c6d6:	subss  %xmm0,%xmm4
  81c6da:	cvttss2si %xmm4,%rdi
  81c6df:	cvttss2si %xmm3,%r10
  81c6e4:	mov    %r10,%r11
  81c6e7:	sar    $0x3f,%r11
  81c6eb:	and    %rdi,%r11
  81c6ee:	or     %r10,%r11
  81c6f1:	ucomiss %xmm1,%xmm3
  81c6f4:	cmovb  %rsi,%r11
  81c6f8:	ucomiss %xmm2,%xmm3
  81c6fb:	cmova  %rax,%r11
  81c6ff:	add    %rcx,%r11
  81c702:	dec    %r11
  81c705:	shr    $0x4,%r11
  81c709:	mov    %rbx,0x8(%rsp)
  81c70e:	cmp    %r11,%rbx
  81c711:	jbe    81c73d <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x16d>
  81c713:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
  81c720:	mov    %r8,%rax
  81c723:	cmp    %r9,%r8
  81c726:	adc    $0x0,%r8
  81c72a:	cmp    %r9,%rax
  81c72d:	jae    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c733:	cmp    %r9,%r8
  81c736:	jbe    81c720 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x150>
  81c738:	jmp    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c73d:	mov    (%rdx),%rbx
  81c740:	mov    0x8(%rdx),%r14
  81c744:	mov    0x10(%rdx),%rdx
  81c748:	mov    %r9,(%rsp)
  81c74c:	nopl   0x0(%rax)
  81c750:	mov    %r8,%r15
  81c753:	cmp    %r9,%r8
  81c756:	adc    $0x0,%r8
  81c75a:	mov    %r15,%r12
  81c75d:	imul   0x10(%rsp),%r12
  81c763:	mov    0x8(%rsp),%rbp
  81c768:	mov    %rbp,%r13
  81c76b:	nopl   0x0(%rax,%rax,1)
  81c770:	cmp    %r11,%rbp
  81c773:	adc    $0x0,%r13
  81c777:	lea    (%r12,%rbp,1),%rdi
  81c77b:	mov    0x10(%rbx),%rax
  81c77f:	cmp    %rax,%rdi
  81c782:	jae    81c81b <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x24b>
  81c788:	mov    0x8(%rbx),%rcx
  81c78c:	mov    0x4(%rcx,%rdi,8),%r10d
  81c791:	test   %r10d,%r10d
  81c794:	js     81c7ef <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x21f>
  81c796:	mov    (%rcx,%rdi,8),%r9d
  81c79a:	mov    %r9d,%esi
  81c79d:	shr    $0x17,%esi
  81c7a0:	mov    %r10d,%eax
  81c7a3:	shr    $0xe,%eax
  81c7a6:	and    $0x1fe00,%eax
  81c7ab:	or     %esi,%eax
  81c7ad:	je     81c7ef <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x21f>
  81c7af:	mov    %r9d,%esi
  81c7b2:	and    $0x7fffff,%esi
  81c7b8:	add    %esi,%eax
  81c7ba:	dec    %eax
  81c7bc:	xor    %esi,%esi
  81c7be:	sub    $0x800000,%r9d
  81c7c5:	mov    %r9d,(%rcx,%rdi,8)
  81c7c9:	setae  %sil
  81c7cd:	shl    $0x17,%esi
  81c7d0:	add    %r10d,%esi
  81c7d3:	add    $0xff800000,%esi
  81c7d9:	mov    %esi,0x4(%rcx,%rdi,8)
  81c7dd:	mov    0x10(%r14),%rcx
  81c7e1:	cmp    %rax,%rcx
  81c7e4:	jbe    81c82b <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x25b>
  81c7e6:	mov    0x8(%r14),%rcx
  81c7ea:	mov    (%rdx),%esi
  81c7ec:	mov    %esi,(%rcx,%rax,4)
  81c7ef:	cmp    %r11,%rbp
  81c7f2:	jae    81c800 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x230>
  81c7f4:	mov    %r13,%rbp
  81c7f7:	cmp    %r11,%r13
  81c7fa:	jbe    81c770 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x1a0>
  81c800:	mov    (%rsp),%r9
  81c804:	cmp    %r9,%r15
  81c807:	jae    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c80d:	cmp    %r9,%r8
  81c810:	jbe    81c750 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0x180>
  81c816:	jmp    81c67f <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>+0xaf>
  81c81b:	lea    0x611976(%rip),%rdx        # e2e198 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x80>
  81c822:	mov    %rax,%rsi
  81c825:	call   *0x663305(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
  81c82b:	lea    0x61197e(%rip),%rdx        # e2e1b0 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x98>
  81c832:	mov    %rax,%rdi
  81c835:	mov    %rcx,%rsi
  81c838:	call   *0x6632f2(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
