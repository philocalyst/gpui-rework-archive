from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
from named_capture import capture

ROOT = Path('/tmp/gpui-endpoint-csr-sol')
SUPPORT = Path('/tmp/gpui-endpoint-csr-evidence')
OUT = Path('/tmp/gpui-endpoint-csr-codegen')
TARGET = Path('/tmp/gpui-endpoint-csr-codegen-target')
BASELINE = '7a5e1619a27010ec63f6c27506a6d1fcd113f67c'
CANDIDATE = '6bf679e2b2fe175d87eddeea7e4f7362f042bf17'
BIN = '/nix/store/ddk8rvjihg4vhh1k6x9rc65y1zb1kx34-binutils-2.46/bin/'
spec = importlib.util.spec_from_file_location('elf_inspect', '/tmp/gpui-uniform-support/elf_inspect.py')
elf = importlib.util.module_from_spec(spec)
spec.loader.exec_module(elf)

def git(*args):
    return subprocess.check_output(['git', '-c', 'safe.directory=' + str(ROOT), '-C', str(ROOT), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', 'HEAD').decode().strip() == CANDIDATE
assert not git('status', '--porcelain')
paths = git('ls-files', 'reactivity/crates/gpu/src', 'reactivity/crates/gpu/build.rs').decode().splitlines()
original = {name: (ROOT / name).read_bytes() for name in paths}
guards = {name: sha((ROOT / name).read_bytes()) for name in git('ls-files',
          'reactivity/crates', 'reactivity/vendor', 'reactivity/Cargo.lock',
          'reactivity/Cargo.toml', '.cargo/config.toml').decode().splitlines()
          if '/evidence/' not in name}
OUT.mkdir(exist_ok=False)
env = dict(os.environ)
env.pop('RUSTFLAGS', None)
env.pop('CARGO_ENCODED_RUSTFLAGS', None)
env['CARGO_BUILD_JOBS'] = '1'
env['CARGO_TARGET_DIR'] = str(TARGET)
env['RUSTC_BOOTSTRAP'] = '1'
env['GPUI_SPIRV_VAL'] = '/tmp/gpui-qualified-spirv-root/bin/spirv-val'
metadata = {'baseline': BASELINE, 'candidate': CANDIDATE, 'same_physical_source_path': str(ROOT),
            'rustc': subprocess.check_output(['rustc', '-vV'], text=True),
            'cargo': subprocess.check_output(['cargo', '-V'], text=True),
            'root_config_sha256': sha((ROOT / '.cargo/config.toml').read_bytes()),
            'stack_config_sha256': sha((SUPPORT / 'codegen.toml').read_bytes()),
            'guards_sha256': guards, 'lanes': {},
            'scope': 'Matched linked code/static metadata frames, not elapsed time or dynamic stack.'}
try:
    for label, ref in [('baseline', BASELINE), ('candidate', CANDIDATE)]:
        directory = OUT / label
        directory.mkdir()
        available = set(git('ls-tree', '-r', '--name-only', ref, '--',
                        'reactivity/crates/gpu/src', 'reactivity/crates/gpu/build.rs').decode().splitlines())
        wanted = {name: git('show', ref + ':' + name) for name in available}
        for name in paths:
            if name in wanted:
                (ROOT / name).write_bytes(wanted[name])
            else:
                (ROOT / name).unlink()
        with (directory / 'clean.log').open('w') as log:
            subprocess.run(['cargo', 'clean', '--release', '-p', 'gpui_gpu'],
                           cwd=ROOT / 'reactivity', env=env, stdout=log, stderr=subprocess.STDOUT, check=True)
        args = ['cargo', '--config', str(SUPPORT / 'codegen.toml'), 'build', '--release',
                '--offline', '--locked', '-p', 'gpui_gpu', '--example', 'groups',
                '--features', 'vulkan-tests', '--message-format=json', '-vv']
        with (directory / 'cargo.jsonl').open('w') as stdout, (directory / 'cargo.log').open('w') as stderr:
            subprocess.run(args, cwd=ROOT / 'reactivity', env=env, stdout=stdout, stderr=stderr, check=True)
        artifacts = [json.loads(line) for line in (directory / 'cargo.jsonl').read_text().splitlines()
                     if line.startswith('{')]
        library = [a for a in artifacts if a.get('reason') == 'compiler-artifact'
                   and a.get('target', {}).get('name') == 'gpui_gpu'
                   and a.get('target', {}).get('kind') == ['lib']]
        groups = [a for a in artifacts if a.get('reason') == 'compiler-artifact'
                  and a.get('target', {}).get('name') == 'groups'
                  and a.get('target', {}).get('kind') == ['example']]
        assert len(library) == len(groups) == 1 and not library[0]['fresh'] and not groups[0]['fresh']
        assert library[0]['profile']['opt_level'] == groups[0]['profile']['opt_level'] == '3'
        executable = directory / 'groups'
        shutil.copy2(groups[0]['executable'], executable)
        executable.chmod(0o555)
        info = elf.inspect(executable)
        (directory / 'groups-elf.json').write_text(json.dumps(info, indent=2) + '\n')
        lane = {'ref': ref, 'source_sha256': {name: sha(data) for name, data in wanted.items()},
                'args': args, 'library_artifact': library[0], 'groups_artifact': groups[0],
                'binary_sha256': sha(executable.read_bytes()), 'binary': str(executable)}
        metadata['lanes'][label] = lane
        with (directory / 'all-gpu-functions.asm').open('w') as log:
            seen = set()
            for f in sorted(info['all_gpu_frames'], key=lambda f: f['address']):
                if f['address'] in seen:
                    continue
                seen.add(f['address'])
                log.write(f"\nFUNCTION {f['normalized_name']} bytes={f['code_bytes']} frame={f['stack_bytes']}\n")
                log.flush()
                subprocess.run([BIN + 'objdump', '-d', '--demangle=rust', '--no-show-raw-insn',
                                f"--start-address={f['address']}", f"--stop-address={f['address'] + f['code_bytes']}",
                                str(executable)], stdout=log, check=True)
        build = next(a for a in artifacts if a.get('reason') == 'build-script-executed'
                     and 'crates/gpu#gpui_gpu@' in a.get('package_id', ''))
        shutil.copytree(build['out_dir'], directory / 'shader-default')
        fingerprints = directory / 'fingerprints'
        fingerprints.mkdir()
        for fp in (TARGET / 'release/.fingerprint').glob('gpui_gpu-*'):
            shutil.copytree(fp, fingerprints / fp.name)
        capture(ROOT, directory / 'named-readbacks', env, label)
        offline_args = ['cargo', '--config', str(SUPPORT / 'codegen.toml'), 'build', '--release',
                        '--offline', '--locked', '-p', 'gpui_gpu', '--example', 'groups',
                        '--features', 'vulkan-tests,offline-shader', '--message-format=json', '-vv']
        with (directory / 'offline-cargo.jsonl').open('w') as stdout, (directory / 'offline-cargo.log').open('w') as stderr:
            subprocess.run(offline_args, cwd=ROOT / 'reactivity', env=env, stdout=stdout, stderr=stderr, check=True)
        offline = [json.loads(line) for line in (directory / 'offline-cargo.jsonl').read_text().splitlines() if line.startswith('{')]
        artifact = next(a for a in offline if a.get('reason') == 'compiler-artifact' and a.get('target', {}).get('name') == 'groups')
        assert not artifact['fresh'] and artifact['profile']['opt_level'] == '3'
        executable = directory / 'offline-groups'
        shutil.copy2(artifact['executable'], executable); executable.chmod(0o555)
        (directory / 'offline-groups-elf.json').write_text(json.dumps(elf.inspect(executable), indent=2) + '\n')
        lane['offline'] = {'args': offline_args, 'artifact': artifact, 'binary': str(executable), 'binary_sha256': sha(executable.read_bytes())}
        build = next(a for a in offline if a.get('reason') == 'build-script-executed' and 'crates/gpu#gpui_gpu@' in a.get('package_id', ''))
        shutil.copytree(build['out_dir'], directory / 'shader-offline')
        assert {name: (ROOT / name).read_bytes() for name in available} == wanted
        for name, digest in guards.items():
            if name not in paths:
                assert sha((ROOT / name).read_bytes()) == digest, name
        (OUT / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
        print(label + ' matched binary preserved', flush=True)
finally:
    for name, data in original.items():
        (ROOT / name).write_bytes(data)
    assert {name: (ROOT / name).read_bytes() for name in paths} == original
    metadata['restored_status'] = git('status', '--porcelain').decode()
    (OUT / 'metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
assert not metadata['restored_status']
ledgers = {label: json.loads((OUT / label / 'groups-elf.json').read_text()) for label in ['baseline', 'candidate']}
by_name = {}
for label, ledger in ledgers.items():
    values = collections.defaultdict(list)
    for f in ledger['all_gpu_frames']:
        values[f['normalized_name']].append(f)
    by_name[label] = values
pairs = []
unpaired = []
for name in sorted(set(by_name['baseline']) | set(by_name['candidate'])):
    old = by_name['baseline'].get(name, [])
    new = by_name['candidate'].get(name, [])
    if len(old) == len(new) == 1:
        pairs.append({'name': name, 'baseline': old[0], 'candidate': new[0],
                      'code_delta': new[0]['code_bytes'] - old[0]['code_bytes'],
                      'frame_delta': new[0]['stack_bytes'] - old[0]['stack_bytes']})
    else:
        unpaired.append({'name': name, 'baseline': old, 'candidate': new})
summary = {'section_deltas': {name: ledgers['candidate']['sections'][name] - ledgers['baseline']['sections'][name]
                             for name in ['.text', '.rodata', '.data.rel.ro', '.stack_sizes']},
           'unique_name_pairs': pairs, 'unpaired_or_ambiguous': unpaired,
           'scope': 'All GPU symbol aliases retained. Only unique normalized-name pairs are paired. Static frames are not dynamic peak or additive call chains.'}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary['section_deltas'], indent=2), flush=True)

a=json.loads((OUT/'baseline/named-readbacks/manifest.json').read_text())
b=json.loads((OUT/'candidate/named-readbacks/manifest.json').read_text())
assert a['files'].keys()==b['files'].keys()
comparisons=[]
capacities=[]
for key,old in a['files'].items():
    new=b['files'][key]
    assert Path(old['path']).read_bytes()==Path(new['path']).read_bytes(),key
    before=Path(a['diagnostics'][key]['path']).read_text()
    after=Path(b['diagnostics'][key]['path']).read_text()
    def normalize(text):
        value, count=re.subn(r'cpu_index_capacity_bytes: (\d+)', 'cpu_index_capacity_bytes: CAPACITY', text)
        assert count == 1
        return value
    assert normalize(before)==normalize(after),('work_stats',key)
    old_packet=a['packets'][key];new_packet=b['packets'][key]
    assert old_packet['eligible']==new_packet['eligible'],('packet_eligibility',key)
    if old_packet['eligible']:
        for lane in ['tiles','references']:
            assert Path(old_packet[lane]['path']).read_bytes()==Path(new_packet[lane]['path']).read_bytes(),('actual_CPU_packet',lane,key)

    old_capacity=a['current_scratch_capacities'][key]['components']
    new_capacity=b['current_scratch_capacities'][key]['components']
    assert len(old_capacity)==len(new_capacity)==5
    assert old_capacity[:3]==new_capacity[:3] and old_capacity[4]==new_capacity[4],('allocation',key)
    assert new_capacity[3]==0
    assert sum(old_capacity)-sum(new_capacity)==old_capacity[3]
    reported_old=int(re.search(r'cpu_index_capacity_bytes: (\d+)',before)[1])
    reported_new=int(re.search(r'cpu_index_capacity_bytes: (\d+)',after)[1])
    assert 0 <= reported_old-reported_new <= old_capacity[3],('reported_capacity',key)
    capacities.append({'key':key,'shipping_components':old_capacity,'candidate_components':new_capacity,
                       'current_removed_cursor_bytes':old_capacity[3],
                       'last_successful_reported_capacity_delta':reported_old-reported_new})
    comparisons.append({'key':key,'bytes':old['bytes'],'sha256':old['sha256'],
                        'shipping_diagnostics_sha256':a['diagnostics'][key]['sha256'],
                        'candidate_diagnostics_sha256':b['diagnostics'][key]['sha256']})
report={'baseline':BASELINE,'candidate':CANDIDATE,'matched_named_readbacks':len(comparisons),
        'matched_bytes':sum(x['bytes'] for x in comparisons),'complete_work_stats_image_stats_exact':True,
        'matching':'test name / ordinal within that test / dimensions / format; never shifted global index',
        'comparisons':comparisons,
        'actual_CPU_eligible_packets_exact':sum(x['eligible'] for x in a['packets'].values()),
        'no_packet_scratch_frames_labelled':sum(not x['eligible'] for x in a['packets'].values()),
        'actual_CPU_tile_reference_bytes_per_lane':sum(x[lane]['bytes'] for x in a['packets'].values() if x['eligible'] for lane in ['tiles','references'])}
(OUT/'named-readback-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
capacity_report={'object_layout':{'shipping':a['object_layout'],'candidate':b['object_layout']},
                 'component_order':['record_capacity_bytes','tile_capacity_bytes','reference_capacity_bytes','cursor_capacity_bytes','correction_capacity_bytes'],
                 'all_other_current_scratch_capacities_exact':True,'captures':capacities,
                 'scope':'Actual nonshipping private getter observation, restored after each lane. Current scratch capacities and published last-successful Stats capacities are separately recorded; failed prepare can grow scratch without republishing Stats.'}
(OUT/'capacity-ledger.json').write_text(json.dumps(capacity_report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='comparisons'},indent=2))
