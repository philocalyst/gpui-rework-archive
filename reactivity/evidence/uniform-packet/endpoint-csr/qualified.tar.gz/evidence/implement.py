from pathlib import Path
import subprocess
ROOT=Path('/tmp/gpui-endpoint-csr-sol');p=ROOT/'reactivity/crates/gpu/src/renderer.rs';s=p.read_text()
old='''const TILE_START_BITS: u32 = 23;
const TILE_COUNT_BITS: u32 = 17;
const TILE_COUNT_SHIFT: u32 = TILE_START_BITS + TILE_COUNT_BITS;
const TILE_START_MASK: u64 = (1 << TILE_START_BITS) - 1;
const TILE_COUNT_MASK: u32 = (1 << TILE_COUNT_BITS) - 1;
const _: () = assert!(MAX_REFERENCES <= TILE_START_MASK as usize);
const _: () = assert!(MAX_DRAWS <= TILE_COUNT_MASK as usize);
const _: () = assert!(TILE_COUNT_SHIFT + TILE_COUNT_BITS == 57);'''
new='''const TILE_ENDPOINT_BITS: u32 = 23;
const TILE_CURSOR_LOW_BITS: u32 = u32::BITS - TILE_ENDPOINT_BITS;
const TILE_COUNT_BITS: u32 = 17;
const TILE_ENDPOINT_MASK: u32 = (1 << TILE_ENDPOINT_BITS) - 1;
const TILE_COUNT_MASK: u32 = (1 << TILE_COUNT_BITS) - 1;
const _: () = assert!(MAX_REFERENCES <= TILE_ENDPOINT_MASK as usize);
const _: () = assert!(MAX_DRAWS <= TILE_COUNT_MASK as usize);
const _: () = assert!(2 * TILE_ENDPOINT_BITS + TILE_COUNT_BITS + 1 == u64::BITS);'''
assert s.count(old)==1;s=s.replace(old,new)
a=s.index('// During normalization, sampled tiles retain')
b=s.index('fn tile_count(',a)
s=s[:a]+'''// Endpoint spare bits hold the reverse-fill cursor. Exhaustion restores the
// shipping [start, end] words directly, without a conversion pass or GPU decode.
fn sampled_tile(start: u32, count: u32) -> [u32; 2] {
    [
        start | (count << TILE_ENDPOINT_BITS),
        (start + count) | ((count >> TILE_CURSOR_LOW_BITS) << TILE_ENDPOINT_BITS),
    ]
}

fn take_reference(range: &mut [u32; 2]) -> Option<usize> {
    // Uniform tiles carry full draw addresses, including INLINE_RECORD. Their
    // overlapping low-word bits must never be interpreted as a fill cursor.
    if range[1] & UNIFORM_TILE != 0 {
        return None;
    }
    let remaining = (range[0] >> TILE_ENDPOINT_BITS)
        | ((range[1] >> TILE_ENDPOINT_BITS) << TILE_CURSOR_LOW_BITS);
    if remaining == 0 {
        return None;
    }
    let index = (range[0] & TILE_ENDPOINT_MASK) + remaining - 1;
    // A low cursor wrap borrows from its live high bits, never either endpoint.
    let (next, borrow) = range[0].overflowing_sub(1 << TILE_ENDPOINT_BITS);
    range[0] = next;
    range[1] -= u32::from(borrow) << TILE_ENDPOINT_BITS;
    Some(index as usize)
}

'''+s[b:]
a=s.index('    #[test]\n    fn packed_tile_fields_cover_inclusive_caps_and_uniform_addresses()')
b=s.index('    #[cfg(feature = "vulkan-tests")]',a)
s=s[:a]+'''    #[test]
    fn packed_tile_fields_cover_inclusive_caps_and_uniform_addresses() {
        for (start, count) in [
            (0, 0),
            (MAX_REFERENCES as u32, 0),
            (MAX_REFERENCES as u32 - 1, 1),
            (MAX_REFERENCES as u32 - MAX_DRAWS as u32, MAX_DRAWS as u32),
            (MAX_REFERENCES as u32 - 65_535, 65_535),
            (0, 511),
            (511, 512),
            (512, 513),
        ] {
            let end = start + count;
            let mut range = sampled_tile(start, count);
            assert_eq!(range[0] & 0x7fffff, start);
            assert_eq!(range[1] & 0x7fffff, end);
            assert_eq!(range[1] & UNIFORM_TILE, 0);
            assert_eq!((range[0] >> 23) | ((range[1] >> 23) << 9), count);
            for remaining in (1..=count).rev() {
                assert_eq!(take_reference(&mut range), Some((start + remaining - 1) as usize));
                assert_eq!(range[0] & 0x7fffff, start);
                assert_eq!(range[1] & 0x7fffff, end);
                assert_eq!(range[1] & UNIFORM_TILE, 0);
                assert_eq!((range[0] >> 23) | ((range[1] >> 23) << 9), remaining - 1);
            }
            assert_eq!(range, [start, end], "exact shipping words at exhaustion");
            assert_eq!(take_reference(&mut range), None);
            assert_eq!(range, [start, end]);
        }
        for address in [0, 1, MAX_DRAWS as u32 * 6, INLINE_RECORD, INLINE_RECORD | 137] {
            let mut range = [address, UNIFORM_TILE];
            assert_eq!(take_reference(&mut range), None);
            assert_eq!(range, [address, UNIFORM_TILE]);
        }
    }

'''+s[b:]
assert 'TILE_START_BITS' not in s and 'TILE_START_MASK' not in s and 'TILE_COUNT_SHIFT' not in s
shader=subprocess.check_output(['git','-c','safe.directory='+str(ROOT),'-C',str(ROOT),'show','7a5e1619a27010ec63f6c27506a6d1fcd113f67c:reactivity/crates/gpu/src/shader.rs'])
p.write_text(s);(ROOT/'reactivity/crates/gpu/src/shader.rs').write_bytes(shader)
