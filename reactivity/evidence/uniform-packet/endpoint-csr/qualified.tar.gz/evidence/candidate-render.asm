
FUNCTION <gpui_gpu::renderer::RendererState>::render bytes=9376 frame=1400

/tmp/gpui-endpoint-csr-codegen/candidate/groups:     file format elf64-x86-64


Disassembly of section .text:

000000000081e0d0 <<gpui_gpu::renderer::RendererState>::render>:
  81e0d0:	push   %rbp
  81e0d1:	push   %r15
  81e0d3:	push   %r14
  81e0d5:	push   %r13
  81e0d7:	push   %r12
  81e0d9:	push   %rbx
  81e0da:	sub    $0x548,%rsp
  81e0e1:	mov    0x210(%rsi),%rax
  81e0e8:	mov    0x18(%rdx),%r9
  81e0ec:	cmp    %r9,%rax
  81e0ef:	je     81e10d <<gpui_gpu::renderer::RendererState>::render+0x3d>
  81e0f1:	mov    0x10(%rax),%r10
  81e0f5:	cmp    0x10(%r9),%r10
  81e0f9:	jne    81e1db <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e0ff:	mov    0x18(%rax),%rax
  81e103:	cmp    0x18(%r9),%rax
  81e107:	jne    81e1db <<gpui_gpu::renderer::RendererState>::render+0x10b>
  81e10d:	lea    0x318(%rsi),%rbx
  81e114:	mov    0x318(%rsi),%rax
  81e11b:	test   %rax,%rax
  81e11e:	je     81e14d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e120:	lock decq (%rax)
  81e124:	jne    81e14d <<gpui_gpu::renderer::RendererState>::render+0x7d>
  81e126:	mov    %rdi,%r14
  81e129:	mov    %rbx,%rdi
  81e12c:	mov    %rsi,%r12
  81e12f:	mov    %r8,%r13
  81e132:	mov    %rdx,%r15
  81e135:	mov    %rcx,%rbp
  81e138:	call   *0x661a12(%rip)        # e7fb50 <_DYNAMIC+0x518>
  81e13e:	mov    %rbp,%rcx
  81e141:	mov    %r15,%rdx
  81e144:	mov    %r13,%r8
  81e147:	mov    %r12,%rsi
  81e14a:	mov    %r14,%rdi
  81e14d:	movq   $0x0,0x318(%rsi)
  81e158:	mov    (%rcx),%r12d
  81e15b:	mov    0x8(%rcx),%r9d
  81e15f:	movzbl 0xd(%rcx),%eax
  81e163:	test   %r9d,%r9d
  81e166:	sets   %r10b
  81e16a:	and    $0x7fffffff,%r9d
  81e171:	lea    -0x800000(%r9),%r11d
  81e178:	cmp    $0x7f000000,%r11d
  81e17f:	setb   %r11b
  81e183:	and    %r10b,%r11b
  81e186:	lea    -0x1(%r9),%ebp
  81e18a:	cmp    $0x7fffff,%ebp
  81e190:	setb   %bpl
  81e194:	and    %r10b,%bpl
  81e197:	test   %r9d,%r9d
  81e19a:	sete   %r10b
  81e19e:	cmp    $0x7f800000,%r9d
  81e1a5:	sete   %r14b
  81e1a9:	or     %r10b,%r14b
  81e1ac:	cmp    $0x7f800001,%r9d
  81e1b3:	setge  %r9b
  81e1b7:	or     %r14b,%r9b
  81e1ba:	or     %bpl,%r9b
  81e1bd:	test   %r12d,%r12d
  81e1c0:	setne  %r10b
  81e1c4:	and    %al,%r10b
  81e1c7:	or     %r11b,%r10b
  81e1ca:	or     %r9b,%r10b
  81e1cd:	test   $0x1,%r10b
  81e1d1:	je     81e1f6 <<gpui_gpu::renderer::RendererState>::render+0x126>
  81e1d3:	movl   $0x3,(%rdi)
  81e1d9:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e1db:	movl   $0x4,(%rdi)
  81e1e1:	mov    %rdi,%rax
  81e1e4:	add    $0x548,%rsp
  81e1eb:	pop    %rbx
  81e1ec:	pop    %r12
  81e1ee:	pop    %r13
  81e1f0:	pop    %r14
  81e1f2:	pop    %r15
  81e1f4:	pop    %rbp
  81e1f5:	ret
  81e1f6:	movd   0x4(%rcx),%xmm2
  81e1fb:	movzbl 0xc(%rcx),%ebp
  81e1ff:	test   $0x1,%r12b
  81e203:	je     81e27b <<gpui_gpu::renderer::RendererState>::render+0x1ab>
  81e205:	movd   %xmm2,%r9d
  81e20a:	test   %r9d,%r9d
  81e20d:	sets   %r10b
  81e211:	and    $0x7fffffff,%r9d
  81e218:	lea    -0x800000(%r9),%r11d
  81e21f:	cmp    $0x7f000000,%r11d
  81e226:	setb   %r11b
  81e22a:	and    %r10b,%r11b
  81e22d:	lea    -0x1(%r9),%r14d
  81e231:	cmp    $0x7fffff,%r14d
  81e238:	setb   %r14b
  81e23c:	and    %r10b,%r14b
  81e23f:	test   %r9d,%r9d
  81e242:	sete   %r10b
  81e246:	cmp    $0x7f800000,%r9d
  81e24d:	sete   %r15b
  81e251:	or     %r10b,%r15b
  81e254:	cmp    $0x7f800001,%r9d
  81e25b:	setge  %r9b
  81e25f:	or     %r15b,%r9b
  81e262:	or     %r14b,%r9b
  81e265:	or     %r11b,%r9b
  81e268:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e26e:	ucomiss -0x76f3c9(%rip),%xmm2        # aeeac <anon.630a3fff68f6bca64b568be97512ab45.57.llvm.826976926275214120+0x1c>
  81e275:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e27b:	mov    0x28(%rcx),%r14d
  81e27f:	cmp    %r14d,0x20(%r8)
  81e283:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e289:	mov    0x2c(%rcx),%r15d
  81e28d:	cmp    %r15d,0x24(%r8)
  81e291:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e297:	mov    0x38(%r8),%r13d
  81e29b:	cmp    0x20(%rdx),%r13d
  81e29f:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2a5:	cmp    $0x4c,%r13d
  81e2a9:	jne    81e2ce <<gpui_gpu::renderer::RendererState>::render+0x1fe>
  81e2ab:	movq   0x3c(%r8),%xmm0
  81e2b1:	movq   0x24(%rdx),%xmm1
  81e2b6:	pcmpeqd %xmm0,%xmm1
  81e2ba:	pshufd $0x50,%xmm1,%xmm0
  81e2bf:	movmskpd %xmm0,%r9d
  81e2c4:	cmp    $0x3,%r9d
  81e2c8:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e2ce:	cmp    $0x4000,%r15d
  81e2d5:	ja     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2d7:	cmp    $0x4000,%r14d
  81e2de:	ja     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2e0:	mov    %r15,%r9
  81e2e3:	imul   %r14,%r9
  81e2e7:	add    $0xfffffffffeffffff,%r9
  81e2ee:	cmp    $0xffffffffff000000,%r9
  81e2f5:	jb     81e30b <<gpui_gpu::renderer::RendererState>::render+0x23b>
  81e2f7:	mov    0x10(%rcx),%r11
  81e2fb:	mov    0x80(%r11),%r10
  81e302:	cmp    $0x10000,%r10
  81e309:	jbe    81e316 <<gpui_gpu::renderer::RendererState>::render+0x246>
  81e30b:	movl   $0x6,(%rdi)
  81e311:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e316:	movd   0x18(%rcx),%xmm0
  81e31b:	movd   %xmm0,%r9d
  81e320:	and    $0x7fffffff,%r9d
  81e327:	cmp    $0x7f7fffff,%r9d
  81e32e:	jg     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e334:	pand   -0x770bbc(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e33c:	ucomiss -0x76f23f(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e343:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e349:	movd   0x1c(%rcx),%xmm0
  81e34e:	movd   %xmm0,%r9d
  81e353:	and    $0x7fffffff,%r9d
  81e35a:	cmp    $0x7f7fffff,%r9d
  81e361:	jg     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e367:	pand   -0x770bef(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e36f:	ucomiss -0x76f272(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e376:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e37c:	movd   0x20(%rcx),%xmm0
  81e381:	movd   %xmm0,%r9d
  81e386:	and    $0x7fffffff,%r9d
  81e38d:	cmp    $0x7f7fffff,%r9d
  81e394:	jg     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e39a:	pand   -0x770c22(%rip),%xmm0        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3a2:	ucomiss -0x76f2a5(%rip),%xmm0        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3a9:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3af:	movd   0x24(%rcx),%xmm0
  81e3b4:	movd   %xmm0,%r9d
  81e3b9:	and    $0x7fffffff,%r9d
  81e3c0:	cmp    $0x7f7fffff,%r9d
  81e3c7:	jg     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3cd:	movdqa -0x770c55(%rip),%xmm1        # ad780 <anon.068260129a360d3c14a88deb110120c9.144.llvm.7357624670875813013+0x410>
  81e3d5:	pand   %xmm0,%xmm1
  81e3d9:	ucomiss -0x76f2dc(%rip),%xmm1        # af104 <anon.a16d5d421a76dfd8c37a17b53540311d.71.llvm.14190004212411149437+0x1c>
  81e3e0:	ja     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3e6:	xorps  %xmm1,%xmm1
  81e3e9:	ucomiss %xmm1,%xmm0
  81e3ec:	jb     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e3f2:	movss  -0x76f67a(%rip),%xmm1        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e3fa:	ucomiss %xmm0,%xmm1
  81e3fd:	jb     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e403:	movzwl 0x30(%rcx),%r9d
  81e408:	mov    %r9w,0x10(%rsp)
  81e40e:	movzwl 0x32(%rcx),%r9d
  81e413:	mov    %r9w,0x18(%rsp)
  81e419:	cmp    $0x28,%r13d
  81e41d:	jne    81e429 <<gpui_gpu::renderer::RendererState>::render+0x359>
  81e41f:	test   $0x1,%al
  81e421:	je     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e427:	jmp    81e444 <<gpui_gpu::renderer::RendererState>::render+0x374>
  81e429:	test   $0x1,%al
  81e42b:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e431:	ucomiss -0x76f6b8(%rip),%xmm0        # aed80 <anon.630a3fff68f6bca64b568be97512ab45.136.llvm.826976926275214120+0x8>
  81e438:	jne    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e43e:	jp     81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  81e444:	mov    %r11,0xc8(%rsp)
  81e44c:	mov    %r10,0xc0(%rsp)
  81e454:	movss  %xmm1,0x104(%rsp)
  81e45d:	movd   %xmm2,0x244(%rsp)
  81e466:	mov    %rdx,0x108(%rsp)
  81e46e:	mov    %r8,0x3e8(%rsp)
  81e476:	mov    %rdi,0x30(%rsp)
  81e47b:	lea    0xf(%r14),%rdx
  81e47f:	shr    $0x4,%rdx
  81e483:	lea    0xf(%r15),%eax
  81e487:	shr    $0x4,%eax
  81e48a:	lea    0x18(%rsi),%rdi
  81e48e:	movq   $0x0,0x28(%rsi)
  81e496:	mov    %rdx,0x58(%rsp)
  81e49b:	imul   %edx,%eax
  81e49e:	mov    %rdi,0x218(%rsp)
  81e4a6:	mov    %rsi,0x8(%rsp)
  81e4ab:	mov    %rax,%rsi
  81e4ae:	xor    %edx,%edx
  81e4b0:	mov    %rcx,0xe8(%rsp)
  81e4b8:	call   8227f0 <<alloc::vec::Vec<[u32; 2]>>::resize>
  81e4bd:	mov    0x8(%rsp),%rax
  81e4c2:	movq   $0x0,0x10(%rax)
  81e4ca:	mov    0xe8(%rsp),%rdi
  81e4d2:	call   *0x661708(%rip)        # e7fbe0 <_DYNAMIC+0x5a8>
  81e4d8:	mov    %rdx,%rcx
  81e4db:	sub    %rax,%rcx
  81e4de:	cmp    $0x300000,%rcx
  81e4e5:	jbe    81e4f7 <<gpui_gpu::renderer::RendererState>::render+0x427>
  81e4e7:	mov    0x30(%rsp),%rdi
  81e4ec:	movl   $0x6,(%rdi)
  81e4f2:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e4f7:	mov    %rcx,%rsi
  81e4fa:	shr    $0x3,%rcx
  81e4fe:	movabs $0xaaaaaaaaaaaaaaab,%rdi
  81e508:	imul   %rcx,%rdi
  81e50c:	mov    %rdi,0x38(%rsp)
  81e511:	mov    %rax,0x380(%rsp)
  81e519:	mov    %rdx,0x378(%rsp)
  81e521:	cmp    %rax,%rdx
  81e524:	je     81e552 <<gpui_gpu::renderer::RendererState>::render+0x482>
  81e526:	mov    $0xaaaaaaab,%eax
  81e52b:	imul   %rax,%rsi
  81e52f:	shr    $0x2a,%rsi
  81e533:	mov    0x38(%rsp),%rcx
  81e538:	mov    %ecx,%eax
  81e53a:	and    $0x3f,%eax
  81e53d:	add    %rcx,%rsi
  81e540:	cmp    $0x1,%rax
  81e544:	sbb    $0xffffffffffffffff,%rsi
  81e548:	inc    %rsi
  81e54b:	mov    %rsi,0x50(%rsp)
  81e550:	jmp    81e55b <<gpui_gpu::renderer::RendererState>::render+0x48b>
  81e552:	movq   $0x0,0x50(%rsp)
  81e55b:	mov    0xc8(%rsp),%rax
  81e563:	mov    0x98(%rax),%rcx
  81e56a:	add    0xb0(%rax),%rcx
  81e571:	mov    %rax,0x110(%rsp)
  81e579:	movzwl 0x10(%rsp),%eax
  81e57e:	mov    %ax,0x130(%rsp)
  81e586:	movzwl 0x18(%rsp),%eax
  81e58b:	mov    %ax,0x132(%rsp)
  81e593:	movq   $0x0,0x118(%rsp)
  81e59f:	mov    0xc0(%rsp),%rax
  81e5a7:	mov    %rax,0x120(%rsp)
  81e5af:	mov    %rcx,0x210(%rsp)
  81e5b7:	mov    %rcx,0x128(%rsp)
  81e5bf:	mov    0x8(%rsp),%rax
  81e5c4:	movzbl 0x329(%rax),%edx
  81e5cb:	lea    0x428(%rsp),%rdi
  81e5d3:	lea    0x110(%rsp),%rsi
  81e5db:	call   81c840 <<gpui_canvas::canvas::Groups as core::iter::traits::iterator::Iterator>::try_fold::<usize, <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#2}, core::result::Result<usize, gpui_gpu::renderer::Error>>>
  81e5e0:	mov    0x428(%rsp),%eax
  81e5e7:	cmp    $0xffffffff,%eax
  81e5ea:	je     81e61a <<gpui_gpu::renderer::RendererState>::render+0x54a>
  81e5ec:	mov    0x42c(%rsp),%ecx
  81e5f3:	mov    0x430(%rsp),%rdx
  81e5fb:	movups 0x438(%rsp),%xmm0
  81e603:	mov    0x30(%rsp),%rdi
  81e608:	movups %xmm0,0x10(%rdi)
  81e60c:	mov    %eax,(%rdi)
  81e60e:	mov    %ecx,0x4(%rdi)
  81e611:	mov    %rdx,0x8(%rdi)
  81e615:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81e61a:	mov    0x430(%rsp),%rdx
  81e622:	add    0x50(%rsp),%rdx
  81e627:	mov    0x8(%rsp),%rdi
  81e62c:	mov    0x10(%rdi),%rsi
  81e630:	mov    $0x4,%ecx
  81e635:	mov    $0x10,%r8d
  81e63b:	call   823bb0 <<alloc::raw_vec::RawVecInner>::try_reserve_exact>
  81e640:	cmp    $0xffffffffffffffff,%rax
  81e644:	jne    81e4e7 <<gpui_gpu::renderer::RendererState>::render+0x417>
  81e64a:	movzwl 0x10(%rsp),%eax
  81e64f:	mov    %eax,0x10(%rsp)
  81e653:	movzwl 0x18(%rsp),%eax
  81e658:	mov    %eax,0x78(%rsp)
  81e65c:	mov    0x8(%rsp),%rdi
  81e661:	mov    0xe8(%rsp),%rsi
  81e669:	mov    0x38(%rsp),%rdx
  81e66e:	call   825b10 <gpui_gpu::renderer::slots::write_prefix>
  81e673:	mov    0x8(%rsp),%rax
  81e678:	movq   $0x0,0x58(%rax)
  81e680:	cmpq   $0x0,0x48(%rax)
  81e685:	jne    81e696 <<gpui_gpu::renderer::RendererState>::render+0x5c6>
  81e687:	mov    0x8(%rsp),%rax
  81e68c:	lea    0x48(%rax),%rdi
  81e690:	call   *0x661552(%rip)        # e7fbe8 <_DYNAMIC+0x5b0>
  81e696:	mov    0x8(%rsp),%rax
  81e69b:	mov    0x50(%rax),%rcx
  81e69f:	xorps  %xmm0,%xmm0
  81e6a2:	movups %xmm0,0x10(%rcx)
  81e6a6:	movups %xmm0,(%rcx)
  81e6a9:	movq   $0x1,0x58(%rax)
  81e6b1:	lea    0x2e0(%rax),%rdi
  81e6b8:	call   8254c0 <<hashbrown::raw::RawTable<([u32; 8], u32)>>::clear>
  81e6bd:	mov    0x78(%rsp),%ecx
  81e6c1:	shl    $0x10,%ecx
  81e6c4:	add    0x10(%rsp),%ecx
  81e6c8:	mov    0xc8(%rsp),%rax
  81e6d0:	mov    %rax,0x388(%rsp)
  81e6d8:	movq   $0x0,0x390(%rsp)
  81e6e4:	mov    0xc0(%rsp),%rax
  81e6ec:	mov    %rax,0x398(%rsp)
  81e6f4:	mov    0x210(%rsp),%rax
  81e6fc:	mov    %rax,0x3a0(%rsp)
  81e704:	mov    %ecx,0x78(%rsp)
  81e708:	mov    %ecx,0x3a8(%rsp)
  81e70f:	lea    0x248(%rsp),%rdi
  81e717:	lea    0x388(%rsp),%rsi
  81e71f:	call   *0x6614cb(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81e725:	mov    0x248(%rsp),%rax
  81e72d:	mov    %rax,0x18(%rsp)
  81e732:	test   %rax,%rax
  81e735:	je     81f499 <<gpui_gpu::renderer::RendererState>::render+0x13c9>
  81e73b:	movq   $0x0,0xe0(%rsp)
  81e747:	movq   $0x0,0x10(%rsp)
  81e750:	movq   $0x0,0xb8(%rsp)
  81e75c:	movq   $0x0,0x200(%rsp)
  81e768:	movq   $0x0,0x208(%rsp)
  81e774:	mov    0x250(%rsp),%rcx
  81e77c:	mov    0x258(%rsp),%rdx
  81e784:	mov    %rdx,0xa0(%rsp)
  81e78c:	lea    0x260(%rsp),%rdi
  81e794:	movups (%rdi),%xmm0
  81e797:	movups 0x10(%rdi),%xmm1
  81e79b:	movups 0x20(%rdi),%xmm2
  81e79f:	movaps %xmm2,0x2f0(%rsp)
  81e7a7:	movaps %xmm1,0x2e0(%rsp)
  81e7af:	movaps %xmm0,0x2d0(%rsp)
  81e7b7:	lea    0x290(%rsp),%r8
  81e7bf:	movups (%r8),%xmm0
  81e7c3:	movaps %xmm0,0x4f0(%rsp)
  81e7cb:	movups 0x40(%rdi),%xmm0
  81e7cf:	movaps %xmm0,0x3f0(%rsp)
  81e7d7:	mov    0x8(%rsp),%rax
  81e7dc:	movzbl 0x329(%rax),%esi
  81e7e3:	mov    0x18(%rsp),%rax
  81e7e8:	mov    %rax,0x110(%rsp)
  81e7f0:	mov    %rcx,0x28(%rsp)
  81e7f5:	mov    %rcx,0x118(%rsp)
  81e7fd:	mov    %rdx,0x120(%rsp)
  81e805:	movups (%rdi),%xmm0
  81e808:	movups 0x10(%rdi),%xmm1
  81e80c:	movups 0x20(%rdi),%xmm2
  81e810:	lea    0x128(%rsp),%rax
  81e818:	movups %xmm2,0x20(%rax)
  81e81c:	movups %xmm1,0x10(%rax)
  81e820:	movups %xmm0,(%rax)
  81e823:	movups (%r8),%xmm0
  81e827:	movups %xmm0,0x30(%rax)
  81e82b:	movups 0x40(%rdi),%xmm0
  81e82f:	movups %xmm0,0x40(%rax)
  81e833:	lea    0x110(%rsp),%rdi
  81e83b:	call   821550 <gpui_gpu::renderer::compact_group>
  81e840:	mov    %al,0x40(%rsp)
  81e844:	lea    0x260(%rsp),%rsi
  81e84c:	movups (%rsi),%xmm0
  81e84f:	movups 0x10(%rsi),%xmm1
  81e853:	movups 0x20(%rsi),%xmm2
  81e857:	movaps %xmm0,0x500(%rsp)
  81e85f:	movaps %xmm1,0x510(%rsp)
  81e867:	movaps %xmm2,0x520(%rsp)
  81e86f:	lea    0x290(%rsp),%rdx
  81e877:	movups (%rdx),%xmm0
  81e87a:	movaps %xmm0,0x530(%rsp)
  81e882:	mov    0x8(%rsp),%rdi
  81e887:	call   81d470 <<gpui_gpu::renderer::RendererState>::correction>
  81e88c:	mov    %eax,0x7c(%rsp)
  81e890:	mov    0xa0(%rsp),%rax
  81e898:	lea    0x0(,%rax,4),%rax
  81e8a0:	mov    %rax,0x370(%rsp)
  81e8a8:	cmpb   $0x0,0x40(%rsp)
  81e8ad:	je     81ea8b <<gpui_gpu::renderer::RendererState>::render+0x9bb>
  81e8b3:	mov    0x28(%rsp),%rcx
  81e8b8:	mov    0xa0(%rsp),%rax
  81e8c0:	lea    (%rcx,%rax,4),%rax
  81e8c4:	mov    %rcx,0x408(%rsp)
  81e8cc:	mov    %rax,0x410(%rsp)
  81e8d4:	mov    0x18(%rsp),%rax
  81e8d9:	mov    %rax,0x418(%rsp)
  81e8e1:	movq   $0x0,0x420(%rsp)
  81e8ed:	lea    0x300(%rsp),%rdi
  81e8f5:	lea    0x408(%rsp),%rsi
  81e8fd:	call   821be0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81e902:	cmpb   $0xff,0x308(%rsp)
  81e90a:	je     81efca <<gpui_gpu::renderer::RendererState>::render+0xefa>
  81e910:	xorps  %xmm0,%xmm0
  81e913:	movaps %xmm0,0x80(%rsp)
  81e91b:	movaps %xmm0,0x60(%rsp)
  81e920:	mov    0x300(%rsp),%rdx
  81e928:	add    0xb8(%rsp),%rdx
  81e930:	lea    0x308(%rsp),%rsi
  81e938:	movups 0x38(%rsi),%xmm0
  81e93c:	lea    0x128(%rsp),%rcx
  81e944:	movups %xmm0,0x20(%rcx)
  81e948:	movups 0x48(%rsi),%xmm0
  81e94c:	movups %xmm0,0x70(%rcx)
  81e950:	mov    0x30(%rsi),%rax
  81e954:	mov    %rax,0x140(%rsp)
  81e95c:	movups (%rsi),%xmm0
  81e95f:	movups 0x10(%rsi),%xmm1
  81e963:	movups 0x20(%rsi),%xmm2
  81e967:	movaps %xmm2,0x130(%rsp)
  81e96f:	movaps %xmm1,0x120(%rsp)
  81e977:	movaps %xmm0,0x110(%rsp)
  81e97f:	lea    0x260(%rsp),%rax
  81e987:	movups 0x40(%rax),%xmm0
  81e98b:	movups %xmm0,0x80(%rcx)
  81e992:	movups (%rax),%xmm0
  81e995:	movups 0x10(%rax),%xmm1
  81e999:	movups 0x20(%rax),%xmm2
  81e99d:	movups %xmm2,0x50(%rcx)
  81e9a1:	movups %xmm1,0x40(%rcx)
  81e9a5:	movups %xmm0,0x30(%rcx)
  81e9a9:	lea    0x290(%rsp),%rax
  81e9b1:	movups (%rax),%xmm0
  81e9b4:	movups %xmm0,0x60(%rcx)
  81e9b8:	lea    0x220(%rsp),%rdi
  81e9c0:	lea    0x110(%rsp),%rsi
  81e9c8:	mov    %r14d,%ecx
  81e9cb:	mov    %r15d,%r8d
  81e9ce:	call   8215a0 <gpui_gpu::renderer::validate_draw>
  81e9d3:	mov    0x220(%rsp),%ecx
  81e9da:	mov    0x224(%rsp),%rax
  81e9e2:	cmp    $0xffffffff,%ecx
  81e9e5:	jne    81f554 <<gpui_gpu::renderer::RendererState>::render+0x1484>
  81e9eb:	mov    %eax,%ecx
  81e9ed:	shr    $0x20,%rax
  81e9f1:	movd   %ecx,%xmm0
  81e9f5:	movaps 0x80(%rsp),%xmm2
  81e9fd:	movaps %xmm2,%xmm1
  81ea00:	maxss  %xmm0,%xmm1
  81ea04:	movaps %xmm1,%xmm3
  81ea07:	cmpunordss %xmm1,%xmm3
  81ea0c:	movaps %xmm3,%xmm0
  81ea0f:	andnps %xmm1,%xmm0
  81ea12:	andps  %xmm2,%xmm3
  81ea15:	orps   %xmm0,%xmm3
  81ea18:	movaps %xmm3,0x40(%rsp)
  81ea1d:	movd   %eax,%xmm0
  81ea21:	movaps 0x60(%rsp),%xmm2
  81ea26:	movaps %xmm2,%xmm1
  81ea29:	maxss  %xmm0,%xmm1
  81ea2d:	movaps %xmm1,%xmm3
  81ea30:	cmpunordss %xmm1,%xmm3
  81ea35:	movaps %xmm3,%xmm0
  81ea38:	andnps %xmm1,%xmm0
  81ea3b:	andps  %xmm2,%xmm3
  81ea3e:	orps   %xmm0,%xmm3
  81ea41:	movaps %xmm3,0x90(%rsp)
  81ea49:	lea    0x300(%rsp),%rdi
  81ea51:	lea    0x408(%rsp),%rsi
  81ea59:	call   821be0 <<core::iter::adapters::enumerate::Enumerate<core::iter::adapters::map::Map<core::slice::iter::Iter<u32>, <gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>> as core::iter::traits::iterator::Iterator>::next>
  81ea5e:	cmpb   $0xff,0x308(%rsp)
  81ea66:	movaps 0x40(%rsp),%xmm0
  81ea6b:	movaps %xmm0,0x80(%rsp)
  81ea73:	movaps 0x90(%rsp),%xmm0
  81ea7b:	movaps %xmm0,0x60(%rsp)
  81ea80:	jne    81e920 <<gpui_gpu::renderer::RendererState>::render+0x850>
  81ea86:	jmp    81efda <<gpui_gpu::renderer::RendererState>::render+0xf0a>
  81ea8b:	cmpq   $0x0,0xa0(%rsp)
  81ea94:	je     81f443 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81ea9a:	mov    0x7c(%rsp),%eax
  81ea9e:	or     $0x80000000,%eax
  81eaa3:	mov    %eax,0x240(%rsp)
  81eaaa:	movq   $0x0,0x90(%rsp)
  81eab6:	mov    0x28(%rsp),%rax
  81eabb:	mov    0x90(%rsp),%rcx
  81eac3:	mov    (%rax,%rcx,1),%edx
  81eac6:	lea    0x110(%rsp),%rdi
  81eace:	mov    0x18(%rsp),%rsi
  81ead3:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81ead8:	movzbl 0x110(%rsp),%edi
  81eae0:	lea    0x111(%rsp),%rdx
  81eae8:	mov    (%rdx),%eax
  81eaea:	mov    0x3(%rdx),%ecx
  81eaed:	lea    0x460(%rsp),%rsi
  81eaf5:	mov    %ecx,-0x34(%rsi)
  81eaf8:	mov    %eax,-0x37(%rsi)
  81eafb:	mov    0x118(%rsp),%rcx
  81eb03:	mov    0x2f(%rdx),%rax
  81eb07:	mov    %rax,-0x8(%rsi)
  81eb0b:	movups 0xf(%rdx),%xmm0
  81eb0f:	movups 0x1f(%rdx),%xmm1
  81eb13:	movups %xmm1,-0x18(%rsi)
  81eb17:	movups %xmm0,-0x28(%rsi)
  81eb1b:	lea    0x128(%rsp),%rax
  81eb23:	movups 0x20(%rax),%xmm0
  81eb27:	movups %xmm0,(%rsi)
  81eb2a:	movups 0x30(%rax),%xmm0
  81eb2e:	movups %xmm0,0x50(%rsi)
  81eb32:	lea    0x260(%rsp),%rax
  81eb3a:	movups 0x40(%rax),%xmm0
  81eb3e:	movups %xmm0,0x60(%rsi)
  81eb42:	movups (%rax),%xmm0
  81eb45:	movups 0x10(%rax),%xmm1
  81eb49:	movups 0x20(%rax),%xmm2
  81eb4d:	movups %xmm2,0x30(%rsi)
  81eb51:	movups %xmm1,0x20(%rsi)
  81eb55:	movups %xmm0,0x10(%rsi)
  81eb59:	lea    0x290(%rsp),%rax
  81eb61:	movups (%rax),%xmm0
  81eb64:	movups %xmm0,0x40(%rsi)
  81eb68:	mov    %dil,0x60(%rsp)
  81eb6d:	mov    %dil,0x428(%rsp)
  81eb75:	mov    %rcx,0x80(%rsp)
  81eb7d:	mov    %rcx,0x430(%rsp)
  81eb85:	lea    0x110(%rsp),%rdi
  81eb8d:	lea    0x428(%rsp),%rsi
  81eb95:	mov    0xb8(%rsp),%rdx
  81eb9d:	mov    %r14d,%ecx
  81eba0:	mov    %r15d,%r8d
  81eba3:	call   8215a0 <gpui_gpu::renderer::validate_draw>
  81eba8:	mov    0x110(%rsp),%eax
  81ebaf:	mov    0x114(%rsp),%rcx
  81ebb7:	mov    %rcx,0x40(%rsp)
  81ebbc:	cmp    $0xffffffff,%eax
  81ebbf:	jne    81f5ea <<gpui_gpu::renderer::RendererState>::render+0x151a>
  81ebc5:	movzbl 0x60(%rsp),%eax
  81ebca:	cmp    $0x2,%al
  81ebcc:	sete   0x27(%rsp)
  81ebd1:	cmpq   $0x0,0x80(%rsp)
  81ebda:	setne  0x26(%rsp)
  81ebdf:	movups 0x460(%rsp),%xmm0
  81ebe7:	movaps %xmm0,0x2c0(%rsp)
  81ebef:	cmp    $0x3,%al
  81ebf1:	jne    81ec83 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ebf7:	movss  0x42c(%rsp),%xmm0
  81ec00:	xorps  %xmm1,%xmm1
  81ec03:	ucomiss %xmm1,%xmm0
  81ec06:	jne    81ec0a <<gpui_gpu::renderer::RendererState>::render+0xb3a>
  81ec08:	jnp    81ec83 <<gpui_gpu::renderer::RendererState>::render+0xbb3>
  81ec0a:	movaps 0x2c0(%rsp),%xmm5
  81ec12:	movaps %xmm5,%xmm1
  81ec15:	unpckhpd %xmm5,%xmm1
  81ec19:	movss  -0x76fcb5(%rip),%xmm4        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81ec21:	mulss  %xmm4,%xmm1
  81ec25:	movaps %xmm0,%xmm2
  81ec28:	minss  %xmm1,%xmm2
  81ec2c:	movaps %xmm2,%xmm1
  81ec2f:	cmpunordss %xmm2,%xmm1
  81ec34:	movaps %xmm1,%xmm3
  81ec37:	andnps %xmm2,%xmm3
  81ec3a:	andps  %xmm0,%xmm1
  81ec3d:	orps   %xmm3,%xmm1
  81ec40:	movaps %xmm5,%xmm0
  81ec43:	shufps $0xff,%xmm5,%xmm0
  81ec47:	mulss  %xmm4,%xmm0
  81ec4b:	movaps %xmm1,%xmm2
  81ec4e:	minss  %xmm0,%xmm2
  81ec52:	movaps %xmm2,%xmm0
  81ec55:	cmpunordss %xmm2,%xmm0
  81ec5a:	andps  %xmm0,%xmm1
  81ec5d:	andnps %xmm2,%xmm0
  81ec60:	orps   %xmm1,%xmm0
  81ec63:	movd   %xmm0,%eax
  81ec67:	mov    %eax,0x60(%rsp)
  81ec6b:	and    $0xff800000,%eax
  81ec70:	mov    $0x7f000000,%ecx
  81ec75:	sub    %eax,%ecx
  81ec77:	mov    %ecx,0x80(%rsp)
  81ec7e:	xorps  %xmm0,%xmm0
  81ec81:	jmp    81eca5 <<gpui_gpu::renderer::RendererState>::render+0xbd5>
  81ec83:	mov    0x4c0(%rsp),%eax
  81ec8a:	mov    %eax,0x60(%rsp)
  81ec8e:	mov    0x4c4(%rsp),%eax
  81ec95:	mov    %eax,0x80(%rsp)
  81ec9c:	movsd  0x4c8(%rsp),%xmm0
  81eca5:	movaps %xmm0,0xd0(%rsp)
  81ecad:	mov    0x8(%rsp),%rax
  81ecb2:	mov    0x10(%rax),%ecx
  81ecb5:	mov    $0x80000000,%eax
  81ecba:	or     %eax,%ecx
  81ecbc:	mov    %ecx,0x360(%rsp)
  81ecc3:	movups 0x470(%rsp),%xmm0
  81eccb:	movaps %xmm0,0x3c0(%rsp)
  81ecd3:	movups 0x478(%rsp),%xmm0
  81ecdb:	movaps %xmm0,0x4e0(%rsp)
  81ece3:	movsd  0x480(%rsp),%xmm0
  81ecec:	movaps %xmm0,0x3b0(%rsp)
  81ecf4:	movsd  0x488(%rsp),%xmm0
  81ecfd:	movaps %xmm0,0x4d0(%rsp)
  81ed05:	movsd  0x490(%rsp),%xmm0
  81ed0e:	movsd  %xmm0,0x3e0(%rsp)
  81ed17:	movsd  0x498(%rsp),%xmm0
  81ed20:	movsd  %xmm0,0x3d8(%rsp)
  81ed29:	movups 0x4a0(%rsp),%xmm0
  81ed31:	movaps %xmm0,0x2b0(%rsp)
  81ed39:	mov    0x18(%rsp),%rax
  81ed3e:	mov    %rax,0x110(%rsp)
  81ed46:	mov    0x28(%rsp),%rax
  81ed4b:	mov    %rax,0x118(%rsp)
  81ed53:	mov    0xa0(%rsp),%rax
  81ed5b:	mov    %rax,0x120(%rsp)
  81ed63:	movaps 0x2d0(%rsp),%xmm0
  81ed6b:	movaps 0x2e0(%rsp),%xmm1
  81ed73:	movaps 0x2f0(%rsp),%xmm2
  81ed7b:	lea    0x128(%rsp),%rax
  81ed83:	movups %xmm2,0x20(%rax)
  81ed87:	movups %xmm1,0x10(%rax)
  81ed8b:	movups %xmm0,(%rax)
  81ed8e:	movaps 0x4f0(%rsp),%xmm0
  81ed96:	movups %xmm0,0x30(%rax)
  81ed9a:	movaps 0x3f0(%rsp),%xmm0
  81eda2:	movups %xmm0,0x40(%rax)
  81eda6:	lea    0x110(%rsp),%rdi
  81edae:	call   *0x660e44(%rip)        # e7fbf8 <_DYNAMIC+0x5c0>
  81edb4:	mov    0x7c(%rsp),%ecx
  81edb8:	mov    %ecx,0xf0(%rsp)
  81edbf:	test   %eax,%eax
  81edc1:	je     81edf7 <<gpui_gpu::renderer::RendererState>::render+0xd27>
  81edc3:	mov    0x38(%rsp),%rdi
  81edc8:	mov    %eax,%esi
  81edca:	call   825ad0 <gpui_gpu::renderer::slots::color_word>
  81edcf:	mov    %eax,0x60(%rsp)
  81edd3:	xorps  %xmm0,%xmm0
  81edd6:	movaps %xmm0,0xd0(%rsp)
  81edde:	movl   $0x0,0x80(%rsp)
  81ede9:	mov    0x240(%rsp),%eax
  81edf0:	mov    %eax,0xf0(%rsp)
  81edf7:	mov    0x40(%rsp),%rax
  81edfc:	shr    $0x20,%rax
  81ee00:	mov    %rax,0x3d0(%rsp)
  81ee08:	mov    0x8(%rsp),%rax
  81ee0d:	mov    (%rax),%rcx
  81ee10:	mov    0x10(%rax),%rsi
  81ee14:	sub    %rsi,%rcx
  81ee17:	cmp    $0x5,%rcx
  81ee1b:	jbe    81efa2 <<gpui_gpu::renderer::RendererState>::render+0xed2>
  81ee21:	movsd  0x3d8(%rsp),%xmm0
  81ee2a:	cvtsd2ss %xmm0,%xmm0
  81ee2e:	movsd  0x3e0(%rsp),%xmm1
  81ee37:	cvtsd2ss %xmm1,%xmm1
  81ee3b:	movapd 0x4e0(%rsp),%xmm2
  81ee44:	unpcklpd 0x4d0(%rsp),%xmm2
  81ee4d:	cvtpd2ps %xmm2,%xmm2
  81ee51:	movapd 0x3c0(%rsp),%xmm3
  81ee5a:	unpcklpd 0x3b0(%rsp),%xmm3
  81ee63:	cvtpd2ps %xmm3,%xmm3
  81ee67:	mov    0x8(%rsp),%rax
  81ee6c:	mov    0x8(%rax),%rdx
  81ee70:	shl    $0x4,%rsi
  81ee74:	movaps 0x2c0(%rsp),%xmm4
  81ee7c:	movups %xmm4,(%rdx,%rsi,1)
  81ee80:	movlpd %xmm3,0x10(%rdx,%rsi,1)
  81ee86:	movss  %xmm1,0x18(%rdx,%rsi,1)
  81ee8c:	mov    0x40(%rsp),%rcx
  81ee91:	mov    %ecx,0x1c(%rdx,%rsi,1)
  81ee95:	movlpd %xmm2,0x20(%rdx,%rsi,1)
  81ee9b:	movss  %xmm0,0x28(%rdx,%rsi,1)
  81eea1:	mov    0x3d0(%rsp),%rdi
  81eea9:	mov    %edi,0x2c(%rdx,%rsi,1)
  81eead:	movaps 0x2b0(%rsp),%xmm0
  81eeb5:	movups %xmm0,0x30(%rdx,%rsi,1)
  81eeba:	mov    0x60(%rsp),%edi
  81eebe:	mov    %edi,0x40(%rdx,%rsi,1)
  81eec2:	mov    0x80(%rsp),%edi
  81eec9:	mov    %edi,0x44(%rdx,%rsi,1)
  81eecd:	movaps 0xd0(%rsp),%xmm0
  81eed5:	movlps %xmm0,0x48(%rdx,%rsi,1)
  81eeda:	movq   $0x0,0x50(%rdx,%rsi,1)
  81eee3:	movl   $0x0,0x58(%rdx,%rsi,1)
  81eeeb:	mov    0xf0(%rsp),%edi
  81eef2:	mov    %edi,0x5c(%rdx,%rsi,1)
  81eef6:	addq   $0x6,0x10(%rax)
  81eefb:	sub    $0x8,%rsp
  81eeff:	lea    0x118(%rsp),%rdi
  81ef07:	mov    %rax,%rsi
  81ef0a:	lea    0x430(%rsp),%rdx
  81ef12:	mov    0x368(%rsp),%r8d
  81ef1a:	mov    0x60(%rsp),%r9
  81ef1f:	push   0xe8(%rsp)
  81ef26:	push   %r15
  81ef28:	push   %r14
  81ef2a:	call   820570 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81ef2f:	add    $0x20,%rsp
  81ef33:	mov    0x110(%rsp),%eax
  81ef3a:	cmp    $0xffffffff,%eax
  81ef3d:	jne    81f5b2 <<gpui_gpu::renderer::RendererState>::render+0x14e2>
  81ef43:	movzbl 0x27(%rsp),%ecx
  81ef48:	and    0x26(%rsp),%cl
  81ef4c:	mov    0x10(%rsp),%rax
  81ef51:	or     %cl,%al
  81ef53:	mov    %rax,0x10(%rsp)
  81ef58:	mov    0x118(%rsp),%rax
  81ef60:	mov    %rax,0xe0(%rsp)
  81ef68:	incq   0xb8(%rsp)
  81ef70:	mov    0x90(%rsp),%rdx
  81ef78:	add    $0x4,%rdx
  81ef7c:	mov    0xa0(%rsp),%rax
  81ef84:	lea    0x0(,%rax,4),%rax
  81ef8c:	mov    %rdx,0x90(%rsp)
  81ef94:	cmp    %rdx,%rax
  81ef97:	jne    81eab6 <<gpui_gpu::renderer::RendererState>::render+0x9e6>
  81ef9d:	jmp    81f437 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81efa2:	mov    $0x6,%edx
  81efa7:	mov    $0x4,%ecx
  81efac:	mov    $0x10,%r8d
  81efb2:	mov    0x8(%rsp),%rdi
  81efb7:	call   823b20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81efbc:	mov    0x8(%rsp),%rax
  81efc1:	mov    0x10(%rax),%rsi
  81efc5:	jmp    81ee21 <<gpui_gpu::renderer::RendererState>::render+0xd51>
  81efca:	xorps  %xmm0,%xmm0
  81efcd:	movaps %xmm0,0x90(%rsp)
  81efd5:	movaps %xmm0,0x40(%rsp)
  81efda:	mov    0x8(%rsp),%rax
  81efdf:	mov    0x10(%rax),%eax
  81efe2:	mov    %eax,0xd0(%rsp)
  81efe9:	movups 0x260(%rsp),%xmm1
  81eff1:	movups 0x268(%rsp),%xmm2
  81eff9:	movsd  0x280(%rsp),%xmm0
  81f002:	movsd  %xmm0,0xf0(%rsp)
  81f00b:	movsd  0x288(%rsp),%xmm0
  81f014:	movsd  %xmm0,0x2c0(%rsp)
  81f01d:	movups 0x290(%rsp),%xmm0
  81f025:	movaps %xmm0,0x80(%rsp)
  81f02d:	movhps 0x270(%rsp),%xmm1
  81f035:	movaps %xmm1,0x360(%rsp)
  81f03d:	movups 0x2a0(%rsp),%xmm0
  81f045:	movaps %xmm0,0x60(%rsp)
  81f04a:	movhps 0x278(%rsp),%xmm2
  81f052:	movaps %xmm2,0x2b0(%rsp)
  81f05a:	mov    0x18(%rsp),%rax
  81f05f:	mov    %rax,0x110(%rsp)
  81f067:	mov    0x28(%rsp),%rax
  81f06c:	mov    %rax,0x118(%rsp)
  81f074:	mov    0xa0(%rsp),%rax
  81f07c:	mov    %rax,0x120(%rsp)
  81f084:	lea    0x260(%rsp),%rax
  81f08c:	movups (%rax),%xmm0
  81f08f:	movups 0x10(%rax),%xmm1
  81f093:	movups 0x20(%rax),%xmm2
  81f097:	lea    0x128(%rsp),%rdx
  81f09f:	movups %xmm2,0x20(%rdx)
  81f0a3:	movups %xmm1,0x10(%rdx)
  81f0a7:	movups %xmm0,(%rdx)
  81f0aa:	lea    0x290(%rsp),%rcx
  81f0b2:	movups (%rcx),%xmm0
  81f0b5:	movups %xmm0,0x30(%rdx)
  81f0b9:	movdqu 0x40(%rax),%xmm0
  81f0be:	movdqu %xmm0,0x40(%rdx)
  81f0c3:	lea    0x110(%rsp),%rdi
  81f0cb:	call   *0x660b27(%rip)        # e7fbf8 <_DYNAMIC+0x5c0>
  81f0d1:	test   %eax,%eax
  81f0d3:	je     81f0f3 <<gpui_gpu::renderer::RendererState>::render+0x1023>
  81f0d5:	mov    0x38(%rsp),%rdi
  81f0da:	mov    %eax,%esi
  81f0dc:	call   825ad0 <gpui_gpu::renderer::slots::color_word>
  81f0e1:	orl    $0x80000000,0x7c(%rsp)
  81f0e9:	movd   %eax,%xmm0
  81f0ed:	movdqa %xmm0,0x60(%rsp)
  81f0f3:	mov    0x8(%rsp),%rax
  81f0f8:	mov    (%rax),%rcx
  81f0fb:	mov    0x10(%rax),%rsi
  81f0ff:	sub    %rsi,%rcx
  81f102:	cmp    $0x4,%rcx
  81f106:	jbe    81f471 <<gpui_gpu::renderer::RendererState>::render+0x13a1>
  81f10c:	cvtpd2ps 0x360(%rsp),%xmm0
  81f115:	cvtpd2ps 0x2b0(%rsp),%xmm1
  81f11e:	movsd  0xf0(%rsp),%xmm2
  81f127:	cvtsd2ss %xmm2,%xmm2
  81f12b:	movsd  0x2c0(%rsp),%xmm3
  81f134:	cvtsd2ss %xmm3,%xmm3
  81f138:	mov    0x8(%rsp),%rax
  81f13d:	mov    0x8(%rax),%rcx
  81f141:	shl    $0x4,%rsi
  81f145:	movlpd %xmm0,(%rcx,%rsi,1)
  81f14a:	movss  %xmm2,0x8(%rcx,%rsi,1)
  81f150:	movaps 0x40(%rsp),%xmm0
  81f155:	movss  %xmm0,0xc(%rcx,%rsi,1)
  81f15b:	movlpd %xmm1,0x10(%rcx,%rsi,1)
  81f161:	movss  %xmm3,0x18(%rcx,%rsi,1)
  81f167:	movaps 0x90(%rsp),%xmm0
  81f16f:	movss  %xmm0,0x1c(%rcx,%rsi,1)
  81f175:	movaps 0x80(%rsp),%xmm0
  81f17d:	movups %xmm0,0x20(%rcx,%rsi,1)
  81f182:	movaps 0x60(%rsp),%xmm0
  81f187:	movups %xmm0,0x30(%rcx,%rsi,1)
  81f18c:	mov    0x7c(%rsp),%edx
  81f190:	mov    %edx,0x40(%rcx,%rsi,1)
  81f194:	movq   $0x0,0x44(%rcx,%rsi,1)
  81f19d:	movl   $0x0,0x4c(%rcx,%rsi,1)
  81f1a5:	addq   $0x5,0x10(%rax)
  81f1aa:	incq   0x200(%rsp)
  81f1b2:	mov    0xa0(%rsp),%rax
  81f1ba:	add    %rax,0x208(%rsp)
  81f1c2:	test   %rax,%rax
  81f1c5:	je     81f443 <<gpui_gpu::renderer::RendererState>::render+0x1373>
  81f1cb:	movdqa 0x40(%rsp),%xmm0
  81f1d1:	movd   %xmm0,%ecx
  81f1d5:	movdqa 0x90(%rsp),%xmm0
  81f1de:	movd   %xmm0,%eax
  81f1e2:	shl    $0x20,%rax
  81f1e6:	or     %rax,%rcx
  81f1e9:	mov    %rcx,0xf0(%rsp)
  81f1f1:	mov    0x370(%rsp),%rax
  81f1f9:	add    $0xfffffffffffffffc,%rax
  81f1fd:	shr    $0x2,%rax
  81f201:	mov    0xb8(%rsp),%rcx
  81f209:	add    %rax,%rcx
  81f20c:	inc    %rcx
  81f20f:	mov    %rcx,0xb8(%rsp)
  81f217:	movq   $0x0,0x40(%rsp)
  81f220:	mov    0x28(%rsp),%rax
  81f225:	mov    0x40(%rsp),%rcx
  81f22a:	mov    (%rax,%rcx,1),%edx
  81f22d:	lea    0x300(%rsp),%rdi
  81f235:	mov    0x18(%rsp),%rsi
  81f23a:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f23f:	movzbl 0x300(%rsp),%edi
  81f247:	lea    0x308(%rsp),%rsi
  81f24f:	mov    -0x7(%rsi),%eax
  81f252:	mov    -0x4(%rsi),%ecx
  81f255:	lea    0x111(%rsp),%rdx
  81f25d:	mov    %ecx,0x3(%rdx)
  81f260:	mov    %eax,(%rdx)
  81f262:	mov    0x308(%rsp),%rcx
  81f26a:	mov    0x28(%rsi),%rax
  81f26e:	mov    %rax,0x2f(%rdx)
  81f272:	movups 0x8(%rsi),%xmm0
  81f276:	movups 0x18(%rsi),%xmm1
  81f27a:	movups %xmm1,0x1f(%rdx)
  81f27e:	movups %xmm0,0xf(%rdx)
  81f282:	movups 0x338(%rsp),%xmm1
  81f28a:	lea    0x348(%rsp),%rax
  81f292:	movups (%rax),%xmm0
  81f295:	lea    0x128(%rsp),%rax
  81f29d:	movups %xmm0,0x70(%rax)
  81f2a1:	movaps 0x3f0(%rsp),%xmm0
  81f2a9:	movups %xmm0,0x80(%rax)
  81f2b0:	movaps %xmm1,0xa0(%rsp)
  81f2b8:	movups %xmm1,0x148(%rsp)
  81f2c0:	movaps 0x500(%rsp),%xmm0
  81f2c8:	movaps 0x510(%rsp),%xmm1
  81f2d0:	movapd 0x520(%rsp),%xmm2
  81f2d9:	movupd %xmm2,0x50(%rax)
  81f2de:	movups %xmm1,0x40(%rax)
  81f2e2:	movups %xmm0,0x30(%rax)
  81f2e6:	movaps 0x530(%rsp),%xmm0
  81f2ee:	movups %xmm0,0x60(%rax)
  81f2f2:	mov    %dil,0x60(%rsp)
  81f2f7:	mov    %dil,0x110(%rsp)
  81f2ff:	mov    %rcx,0x80(%rsp)
  81f307:	mov    %rcx,0x118(%rsp)
  81f30f:	mov    0x8(%rsp),%rax
  81f314:	mov    (%rax),%rcx
  81f317:	mov    0x10(%rax),%rax
  81f31b:	sub    %rax,%rcx
  81f31e:	mov    %rax,0x90(%rsp)
  81f326:	cmp    $0x1,%rcx
  81f32a:	jbe    81f407 <<gpui_gpu::renderer::RendererState>::render+0x1337>
  81f330:	mov    0x8(%rsp),%rsi
  81f335:	mov    0x8(%rsi),%rcx
  81f339:	shl    $0x4,%rax
  81f33d:	movaps 0xa0(%rsp),%xmm0
  81f345:	movups %xmm0,(%rcx,%rax,1)
  81f349:	movq   $0x0,0x10(%rcx,%rax,1)
  81f352:	movl   $0x0,0x18(%rcx,%rax,1)
  81f35a:	mov    0xd0(%rsp),%edx
  81f361:	mov    %edx,0x1c(%rcx,%rax,1)
  81f365:	addq   $0x2,0x10(%rsi)
  81f36a:	sub    $0x8,%rsp
  81f36e:	lea    0x308(%rsp),%rdi
  81f376:	lea    0x118(%rsp),%rdx
  81f37e:	mov    0xf8(%rsp),%rcx
  81f386:	mov    0x98(%rsp),%r8
  81f38e:	mov    0x60(%rsp),%r9
  81f393:	push   0xe8(%rsp)
  81f39a:	push   %r15
  81f39c:	push   %r14
  81f39e:	call   820570 <<gpui_gpu::renderer::RendererState>::bin_draw>
  81f3a3:	add    $0x20,%rsp
  81f3a7:	mov    0x300(%rsp),%eax
  81f3ae:	cmp    $0xffffffff,%eax
  81f3b1:	jne    81f5ce <<gpui_gpu::renderer::RendererState>::render+0x14fe>
  81f3b7:	cmpb   $0x2,0x60(%rsp)
  81f3bc:	sete   %al
  81f3bf:	cmpq   $0x0,0x80(%rsp)
  81f3c8:	setne  %cl
  81f3cb:	and    %al,%cl
  81f3cd:	mov    0x10(%rsp),%rax
  81f3d2:	or     %cl,%al
  81f3d4:	mov    %rax,0x10(%rsp)
  81f3d9:	mov    0x308(%rsp),%rax
  81f3e1:	mov    %rax,0xe0(%rsp)
  81f3e9:	mov    0x40(%rsp),%rcx
  81f3ee:	add    $0x4,%rcx
  81f3f2:	mov    %rcx,0x40(%rsp)
  81f3f7:	cmp    %rcx,0x370(%rsp)
  81f3ff:	jne    81f220 <<gpui_gpu::renderer::RendererState>::render+0x1150>
  81f405:	jmp    81f437 <<gpui_gpu::renderer::RendererState>::render+0x1367>
  81f407:	mov    $0x2,%edx
  81f40c:	mov    $0x4,%ecx
  81f411:	mov    $0x10,%r8d
  81f417:	mov    0x8(%rsp),%rdi
  81f41c:	mov    0x90(%rsp),%rsi
  81f424:	call   823b20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f429:	mov    0x8(%rsp),%rax
  81f42e:	mov    0x10(%rax),%rax
  81f432:	jmp    81f330 <<gpui_gpu::renderer::RendererState>::render+0x1260>
  81f437:	mov    0x10(%rsp),%rax
  81f43c:	and    $0x1,%al
  81f43e:	mov    %rax,0x10(%rsp)
  81f443:	lea    0x248(%rsp),%rdi
  81f44b:	lea    0x388(%rsp),%rsi
  81f453:	call   *0x660797(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81f459:	mov    0x248(%rsp),%rax
  81f461:	mov    %rax,0x18(%rsp)
  81f466:	test   %rax,%rax
  81f469:	jne    81e774 <<gpui_gpu::renderer::RendererState>::render+0x6a4>
  81f46f:	jmp    81f4d2 <<gpui_gpu::renderer::RendererState>::render+0x1402>
  81f471:	mov    $0x5,%edx
  81f476:	mov    $0x4,%ecx
  81f47b:	mov    $0x10,%r8d
  81f481:	mov    0x8(%rsp),%rdi
  81f486:	call   823b20 <<alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>>
  81f48b:	mov    0x8(%rsp),%rax
  81f490:	mov    0x10(%rax),%rsi
  81f494:	jmp    81f10c <<gpui_gpu::renderer::RendererState>::render+0x103c>
  81f499:	movq   $0x0,0x208(%rsp)
  81f4a5:	movq   $0x0,0x200(%rsp)
  81f4b1:	movq   $0x0,0xb8(%rsp)
  81f4bd:	movq   $0x0,0x10(%rsp)
  81f4c6:	movq   $0x0,0xe0(%rsp)
  81f4d2:	mov    0x108(%rsp),%rsi
  81f4da:	lea    0x8(%rsi),%rdx
  81f4de:	mov    0x8(%rsp),%rax
  81f4e3:	lea    0x240(%rax),%rcx
  81f4ea:	lea    0x310(%rax),%r8
  81f4f1:	mov    0x10(%rax),%r9
  81f4f5:	sub    $0x8,%rsp
  81f4f9:	lea    0x118(%rsp),%rdi
  81f501:	mov    %rdx,0x3c8(%rsp)
  81f509:	mov    %rcx,0x2b8(%rsp)
  81f511:	mov    %r8,0x2c8(%rsp)
  81f519:	push   0xf0(%rsp)
  81f520:	call   822a60 <gpui_gpu::renderer::images::prepare>
  81f525:	add    $0x10,%rsp
  81f529:	cmpl   $0xffffffff,0x110(%rsp)
  81f531:	je     81f57a <<gpui_gpu::renderer::RendererState>::render+0x14aa>
  81f533:	movups 0x110(%rsp),%xmm0
  81f53b:	movups 0x120(%rsp),%xmm1
  81f543:	mov    0x30(%rsp),%rdi
  81f548:	movups %xmm1,0x10(%rdi)
  81f54c:	movups %xmm0,(%rdi)
  81f54f:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f554:	mov    0x23c(%rsp),%edx
  81f55b:	mov    0x30(%rsp),%rdi
  81f560:	mov    %edx,0x1c(%rdi)
  81f563:	movups 0x22c(%rsp),%xmm0
  81f56b:	movups %xmm0,0xc(%rdi)
  81f56f:	mov    %ecx,(%rdi)
  81f571:	mov    %rax,0x4(%rdi)
  81f575:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f57a:	movzbl 0x10(%rsp),%r8d
  81f580:	and    $0x1,%r8d
  81f584:	lea    0x110(%rsp),%rdi
  81f58c:	mov    0x8(%rsp),%rsi
  81f591:	mov    0x108(%rsp),%rdx
  81f599:	mov    0xc8(%rsp),%rcx
  81f5a1:	call   81d850 <<gpui_gpu::renderer::RendererState>::prepare_atlas>
  81f5a6:	mov    0x110(%rsp),%eax
  81f5ad:	cmp    $0xffffffff,%eax
  81f5b0:	je     81f615 <<gpui_gpu::renderer::RendererState>::render+0x1545>
  81f5b2:	mov    0x114(%rsp),%ecx
  81f5b9:	mov    0x118(%rsp),%rdx
  81f5c1:	movups 0x120(%rsp),%xmm0
  81f5c9:	jmp    81e603 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f5ce:	mov    0x304(%rsp),%ecx
  81f5d5:	mov    0x308(%rsp),%rdx
  81f5dd:	movups 0x310(%rsp),%xmm0
  81f5e5:	jmp    81e603 <<gpui_gpu::renderer::RendererState>::render+0x533>
  81f5ea:	mov    0x12c(%rsp),%ecx
  81f5f1:	mov    0x30(%rsp),%rdi
  81f5f6:	mov    %ecx,0x1c(%rdi)
  81f5f9:	movups 0x11c(%rsp),%xmm0
  81f601:	movups %xmm0,0xc(%rdi)
  81f605:	mov    %eax,(%rdi)
  81f607:	mov    0x40(%rsp),%rax
  81f60c:	mov    %rax,0x4(%rdi)
  81f610:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  81f615:	mov    0x118(%rsp),%rax
  81f61d:	mov    %rax,0x3b0(%rsp)
  81f625:	mov    0xc8(%rsp),%rax
  81f62d:	mov    %rax,0x300(%rsp)
  81f635:	movq   $0x0,0x308(%rsp)
  81f641:	mov    0xc0(%rsp),%rax
  81f649:	mov    %rax,0x310(%rsp)
  81f651:	mov    0x210(%rsp),%rax
  81f659:	mov    %rax,0x318(%rsp)
  81f661:	mov    0x78(%rsp),%eax
  81f665:	mov    %eax,0x320(%rsp)
  81f66c:	lea    0x248(%rsp),%rdi
  81f674:	lea    0x300(%rsp),%rsi
  81f67c:	call   *0x66056e(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81f682:	mov    0x248(%rsp),%rax
  81f68a:	mov    %rax,0xa0(%rsp)
  81f692:	test   %rax,%rax
  81f695:	je     81fa66 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f69b:	mov    0x8(%rsp),%rax
  81f6a0:	add    $0x108,%rax
  81f6a6:	mov    %rax,0x360(%rsp)
  81f6ae:	jmp    81f6e9 <<gpui_gpu::renderer::RendererState>::render+0x1619>
  81f6b0:	lea    0x248(%rsp),%rdi
  81f6b8:	lea    0x300(%rsp),%rsi
  81f6c0:	call   *0x66052a(%rip)        # e7fbf0 <_DYNAMIC+0x5b8>
  81f6c6:	mov    0x248(%rsp),%rax
  81f6ce:	mov    0x10(%rsp),%rcx
  81f6d3:	mov    %rcx,0x50(%rsp)
  81f6d8:	mov    %rax,0xa0(%rsp)
  81f6e0:	test   %rax,%rax
  81f6e3:	je     81fa66 <<gpui_gpu::renderer::RendererState>::render+0x1996>
  81f6e9:	mov    0x250(%rsp),%rdx
  81f6f1:	mov    0x258(%rsp),%rdi
  81f6f9:	mov    %rdi,0x90(%rsp)
  81f701:	lea    0x260(%rsp),%rax
  81f709:	movups 0x40(%rax),%xmm0
  81f70d:	lea    0x128(%rsp),%rcx
  81f715:	movups %xmm0,0x40(%rcx)
  81f719:	movups (%rax),%xmm0
  81f71c:	movups 0x10(%rax),%xmm1
  81f720:	movups 0x20(%rax),%xmm2
  81f724:	movups 0x30(%rax),%xmm3
  81f728:	movups %xmm3,0x30(%rcx)
  81f72c:	movups %xmm2,0x20(%rcx)
  81f730:	movups %xmm1,0x10(%rcx)
  81f734:	movups %xmm0,(%rcx)
  81f737:	mov    0x8(%rsp),%rax
  81f73c:	movzbl 0x329(%rax),%esi
  81f743:	mov    0xa0(%rsp),%rax
  81f74b:	mov    %rax,0x110(%rsp)
  81f753:	mov    %rdx,0x60(%rsp)
  81f758:	mov    %rdx,0x118(%rsp)
  81f760:	mov    %rdi,0x120(%rsp)
  81f768:	lea    0x110(%rsp),%rdi
  81f770:	call   821550 <gpui_gpu::renderer::compact_group>
  81f775:	mov    0x50(%rsp),%rcx
  81f77a:	lea    0x5(%rcx),%rdx
  81f77e:	test   %al,%al
  81f780:	cmove  %rcx,%rdx
  81f784:	mov    %rdx,0x10(%rsp)
  81f789:	cmpq   $0x0,0x90(%rsp)
  81f792:	je     81f6b0 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81f798:	shlq   $0x2,0x90(%rsp)
  81f7a1:	xor    $0x1,%al
  81f7a3:	movzbl %al,%ecx
  81f7a6:	shl    $0x2,%ecx
  81f7a9:	lea    0x1(%rcx),%rax
  81f7ad:	mov    %rax,0x80(%rsp)
  81f7b5:	mov    0x10(%rsp),%rax
  81f7ba:	lea    (%rax,%rcx,1),%r8
  81f7be:	inc    %r8
  81f7c1:	or     $0x2,%rcx
  81f7c5:	shl    $0x4,%r8
  81f7c9:	mov    %rcx,0x50(%rsp)
  81f7ce:	shl    $0x4,%ecx
  81f7d1:	mov    %rcx,0xd0(%rsp)
  81f7d9:	xor    %ecx,%ecx
  81f7db:	mov    %r8,0x18(%rsp)
  81f7e0:	mov    0x60(%rsp),%rax
  81f7e5:	mov    %rcx,0x38(%rsp)
  81f7ea:	mov    (%rax,%rcx,1),%edx
  81f7ed:	lea    0x110(%rsp),%rdi
  81f7f5:	mov    0xa0(%rsp),%rsi
  81f7fd:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81f802:	movzbl 0x110(%rsp),%ecx
  81f80a:	movzbl 0x111(%rsp),%eax
  81f812:	movss  0x114(%rsp),%xmm4
  81f81b:	lea    0x118(%rsp),%rsi
  81f823:	mov    0x10(%rsi),%rdx
  81f827:	mov    %rdx,0x2e0(%rsp)
  81f82f:	movups (%rsi),%xmm0
  81f832:	movaps %xmm0,0x2d0(%rsp)
  81f83a:	cmp    $0x1,%ecx
  81f83d:	je     81f8d2 <<gpui_gpu::renderer::RendererState>::render+0x1802>
  81f843:	movaps %xmm4,0xf0(%rsp)
  81f84b:	mov    0x130(%rsp),%rsi
  81f853:	mov    0x138(%rsp),%edx
  81f85a:	mov    %edx,0x40(%rsp)
  81f85e:	mov    0x13c(%rsp),%edx
  81f865:	mov    %edx,0x28(%rsp)
  81f869:	cmp    $0x3,%ecx
  81f86c:	jne    81f957 <<gpui_gpu::renderer::RendererState>::render+0x1887>
  81f872:	mov    0x2c0(%rsp),%rcx
  81f87a:	mov    (%rcx),%rdi
  81f87d:	test   %rdi,%rdi
  81f880:	je     8204ed <<gpui_gpu::renderer::RendererState>::render+0x241d>
  81f886:	movzbl %al,%edx
  81f889:	call   8226f0 <<gpui_gpu::renderer::images::Images>::metadata>
  81f88e:	mov    %eax,%ecx
  81f890:	shr    $0x20,%rax
  81f894:	mov    %eax,%edx
  81f896:	or     $0x10,%edx
  81f899:	xorps  %xmm0,%xmm0
  81f89c:	movaps 0xf0(%rsp),%xmm1
  81f8a4:	ucomiss %xmm0,%xmm1
  81f8a7:	cmovne %edx,%eax
  81f8aa:	cmovp  %edx,%eax
  81f8ad:	mov    0x28(%rsp),%edx
  81f8b1:	shl    $0x10,%edx
  81f8b4:	or     0x40(%rsp),%edx
  81f8b8:	mov    %ecx,0x220(%rsp)
  81f8bf:	mov    %eax,0x224(%rsp)
  81f8c6:	mov    %edx,0x228(%rsp)
  81f8cd:	jmp    81f9f4 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f8d2:	movss  0x150(%rsp),%xmm0
  81f8db:	movss  -0x770977(%rip),%xmm3        # aef6c <anon.4109cdd7ddb1990ee57d5626700ecb68.316.llvm.4479275319843201559+0x10>
  81f8e3:	mulss  %xmm3,%xmm0
  81f8e7:	movaps %xmm4,%xmm1
  81f8ea:	minss  %xmm0,%xmm1
  81f8ee:	movaps %xmm1,%xmm0
  81f8f1:	cmpunordss %xmm1,%xmm0
  81f8f6:	movaps %xmm0,%xmm2
  81f8f9:	andnps %xmm1,%xmm2
  81f8fc:	andps  %xmm4,%xmm0
  81f8ff:	orps   %xmm2,%xmm0
  81f902:	movss  0x154(%rsp),%xmm1
  81f90b:	mulss  %xmm3,%xmm1
  81f90f:	movaps %xmm0,%xmm2
  81f912:	minss  %xmm1,%xmm2
  81f916:	movaps %xmm2,%xmm1
  81f919:	cmpunordss %xmm2,%xmm1
  81f91e:	andps  %xmm1,%xmm0
  81f921:	andnps %xmm2,%xmm1
  81f924:	orps   %xmm0,%xmm1
  81f927:	movd   %xmm1,%eax
  81f92b:	and    $0xff800000,%eax
  81f930:	mov    $0x7f000000,%ecx
  81f935:	sub    %eax,%ecx
  81f937:	movl   $0x40000000,0x220(%rsp)
  81f942:	movss  %xmm1,0x224(%rsp)
  81f94b:	mov    %ecx,0x228(%rsp)
  81f952:	jmp    81f9f4 <<gpui_gpu::renderer::RendererState>::render+0x1924>
  81f957:	cmp    $0x2,%cl
  81f95a:	jne    81f9ac <<gpui_gpu::renderer::RendererState>::render+0x18dc>
  81f95c:	mov    0x140(%rsp),%rax
  81f964:	mov    0x2e0(%rsp),%rcx
  81f96c:	mov    %rcx,0x120(%rsp)
  81f974:	movaps 0x2d0(%rsp),%xmm0
  81f97c:	movaps %xmm0,0x110(%rsp)
  81f984:	mov    %rsi,0x128(%rsp)
  81f98c:	mov    0x40(%rsp),%ecx
  81f990:	mov    %ecx,0x130(%rsp)
  81f997:	mov    0x28(%rsp),%ecx
  81f99b:	mov    %ecx,0x134(%rsp)
  81f9a2:	mov    %rax,0x138(%rsp)
  81f9aa:	jmp    81f9b8 <<gpui_gpu::renderer::RendererState>::render+0x18e8>
  81f9ac:	movq   $0x0,0x110(%rsp)
  81f9b8:	movl   $0x0,0x390(%rsp)
  81f9c3:	movq   $0x0,0x388(%rsp)
  81f9cf:	lea    0x220(%rsp),%rdi
  81f9d7:	lea    0x110(%rsp),%rsi
  81f9df:	lea    0x388(%rsp),%rdx
  81f9e7:	mov    0x360(%rsp),%rcx
  81f9ef:	call   81b710 <<core::option::Option<gpui_canvas::canvas::GlyphMask>>::map_or::<[u32; 3], <gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#4}>>
  81f9f4:	mov    0x10(%rsp),%rdx
  81f9f9:	mov    0x80(%rsp),%rax
  81fa01:	lea    (%rax,%rdx,1),%rdi
  81fa05:	mov    0x8(%rsp),%rax
  81fa0a:	mov    0x10(%rax),%rsi
  81fa0e:	cmp    %rsi,%rdi
  81fa11:	mov    0x18(%rsp),%r8
  81fa16:	jae    820513 <<gpui_gpu::renderer::RendererState>::render+0x2443>
  81fa1c:	mov    0x8(%rax),%rax
  81fa20:	mov    0x228(%rsp),%ecx
  81fa27:	mov    %ecx,0x8(%rax,%r8,1)
  81fa2c:	mov    0x220(%rsp),%rcx
  81fa34:	mov    %rcx,(%rax,%r8,1)
  81fa38:	add    0x50(%rsp),%rdx
  81fa3d:	mov    %rdx,0x10(%rsp)
  81fa42:	add    0xd0(%rsp),%r8
  81fa4a:	mov    0x38(%rsp),%rcx
  81fa4f:	add    $0x4,%rcx
  81fa53:	cmp    %rcx,0x90(%rsp)
  81fa5b:	jne    81f7db <<gpui_gpu::renderer::RendererState>::render+0x170b>
  81fa61:	jmp    81f6b0 <<gpui_gpu::renderer::RendererState>::render+0x15e0>
  81fa66:	cmpl   $0x0,0x58(%rsp)
  81fa6b:	je     8204fa <<gpui_gpu::renderer::RendererState>::render+0x242a>
  81fa71:	mov    0x8(%rsp),%rax
  81fa76:	mov    0x28(%rax),%rax
  81fa7a:	movq   $0x0,0xd0(%rsp)
  81fa86:	mov    %rax,0x10(%rsp)
  81fa8b:	test   %rax,%rax
  81fa8e:	je     81fbba <<gpui_gpu::renderer::RendererState>::render+0x1aea>
  81fa94:	mov    0x8(%rsp),%rcx
  81fa99:	mov    0x20(%rcx),%rcx
  81fa9d:	movq   $0x0,0x80(%rsp)
  81faa9:	movq   $0x0,0x50(%rsp)
  81fab2:	movq   $0x0,0x60(%rsp)
  81fabb:	xor    %esi,%esi
  81fabd:	jmp    81fae5 <<gpui_gpu::renderer::RendererState>::render+0x1a15>
  81fabf:	mov    0x18(%rsp),%rdx
  81fac4:	lea    (%rcx,%rdx,8),%rcx
  81fac8:	mov    0xd0(%rsp),%rax
  81fad0:	inc    %eax
  81fad2:	mov    %rax,0xd0(%rsp)
  81fada:	sub    %rdx,0x10(%rsp)
  81fadf:	je     81fbae <<gpui_gpu::renderer::RendererState>::render+0x1ade>
  81fae5:	mov    0x58(%rsp),%rax
  81faea:	mov    0x10(%rsp),%rdi
  81faef:	cmp    %rdi,%rax
  81faf2:	cmovb  %rax,%rdi
  81faf6:	mov    0xd0(%rsp),%rax
  81fafe:	mov    %eax,%edx
  81fb00:	shl    $0x4,%edx
  81fb03:	mov    %r15d,%r8d
  81fb06:	sub    %edx,%r8d
  81fb09:	cmp    $0x10,%r8d
  81fb0d:	mov    $0x10,%eax
  81fb12:	cmovae %eax,%r8d
  81fb16:	mov    %rdi,0x18(%rsp)
  81fb1b:	lea    0x0(,%rdi,8),%r9d
  81fb23:	shl    $0x4,%r8d
  81fb27:	xor    %r10d,%r10d
  81fb2a:	mov    %r14d,%r11d
  81fb2d:	jmp    81fb4e <<gpui_gpu::renderer::RendererState>::render+0x1a7e>
  81fb2f:	movl   $0x80000000,0x4(%rcx,%r10,1)
  81fb38:	incq   0x60(%rsp)
  81fb3d:	add    $0xfffffff0,%r11d
  81fb41:	add    $0x8,%r10
  81fb45:	cmp    %r10,%r9
  81fb48:	je     81fabf <<gpui_gpu::renderer::RendererState>::render+0x19ef>
  81fb4e:	mov    0x4(%rcx,%r10,1),%edx
  81fb53:	mov    %edx,%edi
  81fb55:	and    $0x8001ffff,%edi
  81fb5b:	cmp    $0x80000001,%edi
  81fb61:	je     81fb2f <<gpui_gpu::renderer::RendererState>::render+0x1a5f>
  81fb63:	mov    %edx,%eax
  81fb65:	and    $0x1ffff,%eax
  81fb6a:	shl    $0x17,%edx
  81fb6d:	or     %esi,%edx
  81fb6f:	add    %eax,%esi
  81fb71:	mov    %eax,%edi
  81fb73:	shl    $0xe,%edi
  81fb76:	and    $0x7f800000,%edi
  81fb7c:	or     %esi,%edi
  81fb7e:	mov    %edx,(%rcx,%r10,1)
  81fb82:	mov    %edi,0x4(%rcx,%r10,1)
  81fb87:	test   %eax,%eax
  81fb89:	je     81fb3d <<gpui_gpu::renderer::RendererState>::render+0x1a6d>
  81fb8b:	cmp    $0x10,%r11d
  81fb8f:	mov    $0x10,%edx
  81fb94:	cmovb  %r11d,%edx
  81fb98:	imul   %r8d,%edx
  81fb9c:	add    %rdx,0x50(%rsp)
  81fba1:	imul   %eax,%edx
  81fba4:	add    %rdx,0x80(%rsp)
  81fbac:	jmp    81fb3d <<gpui_gpu::renderer::RendererState>::render+0x1a6d>
  81fbae:	mov    %esi,%eax
  81fbb0:	mov    %rax,0xd0(%rsp)
  81fbb8:	jmp    81fbd8 <<gpui_gpu::renderer::RendererState>::render+0x1b08>
  81fbba:	movq   $0x0,0x60(%rsp)
  81fbc3:	movq   $0x0,0x50(%rsp)
  81fbcc:	movq   $0x0,0x80(%rsp)
  81fbd8:	mov    0x8(%rsp),%rax
  81fbdd:	lea    0x30(%rax),%rdi
  81fbe1:	movq   $0x0,0x40(%rax)
  81fbe9:	movl   $0x0,0xf0(%rsp)
  81fbf4:	mov    %rdi,0xa0(%rsp)
  81fbfc:	mov    0xd0(%rsp),%rsi
  81fc04:	xor    %edx,%edx
  81fc06:	call   822910 <<alloc::vec::Vec<u32>>::resize>
  81fc0b:	mov    0x8(%rsp),%rax
  81fc10:	mov    0x10(%rax),%rax
  81fc14:	mov    %rax,0x28(%rsp)
  81fc19:	mov    0xc8(%rsp),%rax
  81fc21:	mov    %rax,0x2d0(%rsp)
  81fc29:	movq   $0x0,0x2d8(%rsp)
  81fc35:	mov    0xc0(%rsp),%rax
  81fc3d:	mov    %rax,0x2e0(%rsp)
  81fc45:	mov    0x210(%rsp),%rax
  81fc4d:	mov    %rax,0x2e8(%rsp)
  81fc55:	mov    0x78(%rsp),%eax
  81fc59:	mov    %eax,0x2f0(%rsp)
  81fc60:	jmp    81fc7c <<gpui_gpu::renderer::RendererState>::render+0x1bac>
  81fc62:	mov    0x28(%rsp),%rcx
  81fc67:	lea    -0x5(%rcx),%rax
  81fc6b:	cmpb   $0x0,0xc0(%rsp)
  81fc73:	cmovne %rax,%rcx
  81fc77:	mov    %rcx,0x28(%rsp)
  81fc7c:	lea    0x248(%rsp),%rdi
  81fc84:	lea    0x2d0(%rsp),%rsi
  81fc8c:	call   *0x65ff6e(%rip)        # e7fc00 <_DYNAMIC+0x5c8>
  81fc92:	mov    0x248(%rsp),%rax
  81fc9a:	mov    %rax,0x40(%rsp)
  81fc9f:	test   %rax,%rax
  81fca2:	je     81fed5 <<gpui_gpu::renderer::RendererState>::render+0x1e05>
  81fca8:	mov    0x250(%rsp),%rcx
  81fcb0:	mov    0x258(%rsp),%rdx
  81fcb8:	mov    %rdx,0x18(%rsp)
  81fcbd:	mov    0x8(%rsp),%rax
  81fcc2:	movzbl 0x329(%rax),%esi
  81fcc9:	mov    0x40(%rsp),%rax
  81fcce:	mov    %rax,0x110(%rsp)
  81fcd6:	mov    %rcx,0x90(%rsp)
  81fcde:	mov    %rcx,0x118(%rsp)
  81fce6:	mov    %rdx,0x120(%rsp)
  81fcee:	lea    0x260(%rsp),%rax
  81fcf6:	movups (%rax),%xmm0
  81fcf9:	movups 0x10(%rax),%xmm1
  81fcfd:	movdqu 0x20(%rax),%xmm2
  81fd02:	lea    0x128(%rsp),%rdx
  81fd0a:	movdqu %xmm2,0x20(%rdx)
  81fd0f:	movups %xmm1,0x10(%rdx)
  81fd13:	movups %xmm0,(%rdx)
  81fd16:	lea    0x290(%rsp),%rcx
  81fd1e:	movups (%rcx),%xmm0
  81fd21:	movups %xmm0,0x30(%rdx)
  81fd25:	movups 0x40(%rax),%xmm0
  81fd29:	movups %xmm0,0x40(%rdx)
  81fd2d:	lea    0x110(%rsp),%rdi
  81fd35:	call   821550 <gpui_gpu::renderer::compact_group>
  81fd3a:	mov    %al,0xc0(%rsp)
  81fd41:	mov    0x18(%rsp),%rax
  81fd46:	test   %rax,%rax
  81fd49:	je     81fc62 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81fd4f:	mov    %rax,%rcx
  81fd52:	shl    $0x2,%rcx
  81fd56:	movzbl 0xc0(%rsp),%eax
  81fd5e:	lea    0x0(,%rax,4),%edx
  81fd65:	or     $0xfffffffffffffffa,%rdx
  81fd69:	xor    %esi,%esi
  81fd6b:	test   %al,%al
  81fd6d:	sete   %sil
  81fd71:	shl    $0x1f,%esi
  81fd74:	mov    %esi,0xc8(%rsp)
  81fd7b:	mov    %rdx,0x38(%rsp)
  81fd80:	mov    0x28(%rsp),%rax
  81fd85:	add    %edx,%eax
  81fd87:	mov    %eax,0x10(%rsp)
  81fd8b:	mov    %rcx,0x18(%rsp)
  81fd90:	mov    0x90(%rsp),%rax
  81fd98:	mov    -0x4(%rax,%rcx,1),%edx
  81fd9c:	lea    0x300(%rsp),%rdi
  81fda4:	mov    0x40(%rsp),%rsi
  81fda9:	call   81c990 <<gpui_canvas::canvas::PreparedGroup>::placements::{closure#0}>
  81fdae:	mov    0x38(%rsp),%rax
  81fdb3:	add    %rax,0x28(%rsp)
  81fdb8:	mov    0xc8(%rsp),%eax
  81fdbf:	or     0x10(%rsp),%eax
  81fdc3:	mov    %eax,0x220(%rsp)
  81fdca:	lea    0x260(%rsp),%rdx
  81fdd2:	movups (%rdx),%xmm0
  81fdd5:	movups 0x10(%rdx),%xmm1
  81fdd9:	movups 0x20(%rdx),%xmm2
  81fddd:	lea    0x128(%rsp),%rcx
  81fde5:	movups %xmm2,0x50(%rcx)
  81fde9:	movups %xmm1,0x40(%rcx)
  81fded:	movups %xmm0,0x30(%rcx)
  81fdf1:	lea    0x290(%rsp),%rax
  81fdf9:	movups (%rax),%xmm0
  81fdfc:	movups %xmm0,0x60(%rcx)
  81fe00:	movups 0x40(%rdx),%xmm0
  81fe04:	movups %xmm0,0x80(%rcx)
  81fe0b:	lea    0x338(%rsp),%rax
  81fe13:	movups (%rax),%xmm0
  81fe16:	movups %xmm0,0x20(%rcx)
  81fe1a:	lea    0x348(%rsp),%rax
  81fe22:	movups (%rax),%xmm0
  81fe25:	movups %xmm0,0x70(%rcx)
  81fe29:	mov    0x330(%rsp),%rax
  81fe31:	mov    %rax,0x140(%rsp)
  81fe39:	movups 0x300(%rsp),%xmm0
  81fe41:	movups 0x310(%rsp),%xmm1
  81fe49:	movdqu 0x320(%rsp),%xmm2
  81fe52:	movdqa %xmm2,0x130(%rsp)
  81fe5b:	movaps %xmm1,0x120(%rsp)
  81fe63:	movaps %xmm0,0x110(%rsp)
  81fe6b:	mov    0x218(%rsp),%rax
  81fe73:	mov    %rax,0x388(%rsp)
  81fe7b:	mov    0xa0(%rsp),%rax
  81fe83:	mov    %rax,0x390(%rsp)
  81fe8b:	lea    0x220(%rsp),%rax
  81fe93:	mov    %rax,0x398(%rsp)
  81fe9b:	lea    0x110(%rsp),%rdi
  81fea3:	mov    0x58(%rsp),%rsi
  81fea8:	lea    0x388(%rsp),%rdx
  81feb0:	call   81c5d0 <gpui_gpu::renderer::visit::<<gpui_gpu::renderer::RendererState>::render_observed<<gpui_gpu::renderer::RendererState>::render::{closure#0}>::{closure#5}>>
  81feb5:	mov    0x10(%rsp),%eax
  81feb9:	add    0x38(%rsp),%eax
  81febd:	mov    %eax,0x10(%rsp)
  81fec1:	mov    0x18(%rsp),%rcx
  81fec6:	add    $0xfffffffffffffffc,%rcx
  81feca:	jne    81fd8b <<gpui_gpu::renderer::RendererState>::render+0x1cbb>
  81fed0:	jmp    81fc62 <<gpui_gpu::renderer::RendererState>::render+0x1b92>
  81fed5:	test   $0x1,%r12b
  81fed9:	je     81ff2c <<gpui_gpu::renderer::RendererState>::render+0x1e5c>
  81fedb:	movd   0x244(%rsp),%xmm0
  81fee4:	movd   %xmm0,%eax
  81fee8:	test   %eax,%eax
  81feea:	setns  %cl
  81feed:	mov    %eax,%edx
  81feef:	and    $0x7fffffff,%edx
  81fef5:	add    $0xff800000,%edx
  81fefb:	cmp    $0x7f000000,%edx
  81ff01:	setb   %dl
  81ff04:	and    %cl,%dl
  81ff06:	dec    %eax
  81ff08:	cmp    $0x7fffff,%eax
  81ff0d:	setb   %al
  81ff10:	or     %dl,%al
  81ff12:	movl   $0x2,0xf0(%rsp)
  81ff1d:	movd   %xmm0,0x104(%rsp)
  81ff26:	je     8204e3 <<gpui_gpu::renderer::RendererState>::render+0x2413>
  81ff2c:	mov    0x108(%rsp),%r12
  81ff34:	lea    0x18(%r12),%rax
  81ff39:	mov    %rax,0x18(%rsp)
  81ff3e:	mov    0xe8(%rsp),%rax
  81ff46:	add    $0x18,%rax
  81ff4a:	xor    %ecx,%ecx
  81ff4c:	mov    0x378(%rsp),%rdx
  81ff54:	cmp    0x380(%rsp),%rdx
  81ff5c:	setne  %cl
  81ff5f:	xor    %edx,%edx
  81ff61:	cmp    $0x28,%r13d
  81ff65:	sete   %dl
  81ff68:	and    $0x1,%ebp
  81ff6b:	lea    0x0(%rbp,%rdx,4),%edx
  81ff6f:	lea    (%rdx,%rcx,8),%ecx
  81ff72:	or     0xf0(%rsp),%ecx
  81ff79:	movups (%rax),%xmm0
  81ff7c:	movups %xmm0,0x258(%rsp)
  81ff84:	mov    %r14d,0x248(%rsp)
  81ff8c:	mov    %r15d,0x24c(%rsp)
  81ff94:	mov    0x58(%rsp),%rax
  81ff99:	mov    %eax,0x250(%rsp)
  81ffa0:	mov    %ecx,0x254(%rsp)
  81ffa7:	movss  0x104(%rsp),%xmm0
  81ffb0:	movss  %xmm0,0x268(%rsp)
  81ffb9:	movq   $0x0,0x26c(%rsp)
  81ffc5:	movl   $0x0,0x274(%rsp)
  81ffd0:	mov    0x8(%rsp),%rbp
  81ffd5:	lea    0x218(%rbp),%rsi
  81ffdc:	movq   $0x0,0x10(%rsp)
  81ffe5:	lea    0x248(%rsp),%rcx
  81ffed:	mov    $0x30,%r8d
  81fff3:	mov    0x3c0(%rsp),%r13
  81fffb:	mov    %r13,%rdi
  81fffe:	mov    %rsi,0x58(%rsp)
  820003:	xor    %edx,%edx
  820005:	call   *0x65fbfd(%rip)        # e7fc08 <_DYNAMIC+0x5d0>
  82000b:	mov    0x8(%rbp),%rcx
  82000f:	mov    0x10(%rbp),%r8
  820013:	shl    $0x4,%r8
  820017:	mov    0x2b0(%rsp),%rdi
  82001f:	mov    %r12,%rsi
  820022:	mov    %r13,%rdx
  820025:	call   81cc30 <<gpui_gpu::renderer::Buffer>::write>
  82002a:	lea    0x268(%rbp),%rdi
  820031:	mov    0x20(%rbp),%rcx
  820035:	mov    0x28(%rbp),%r8
  820039:	shl    $0x3,%r8
  82003d:	mov    %rdi,0x38(%rsp)
  820042:	mov    %r12,%rsi
  820045:	mov    %r13,%rdx
  820048:	call   81cc30 <<gpui_gpu::renderer::Buffer>::write>
  82004d:	lea    0x290(%rbp),%rdi
  820054:	mov    0x38(%rbp),%rcx
  820058:	mov    0x40(%rbp),%r8
  82005c:	shl    $0x2,%r8
  820060:	mov    %rdi,0x218(%rsp)
  820068:	mov    %r12,%rsi
  82006b:	mov    %r13,%rdx
  82006e:	call   81cc30 <<gpui_gpu::renderer::Buffer>::write>
  820073:	lea    0x2b8(%rbp),%rdi
  82007a:	mov    0x50(%rbp),%rcx
  82007e:	mov    0x58(%rbp),%r8
  820082:	shl    $0x5,%r8
  820086:	mov    %rdi,0xe8(%rsp)
  82008e:	mov    %r12,%rsi
  820091:	mov    %r13,%rdx
  820094:	call   81cc30 <<gpui_gpu::renderer::Buffer>::write>
  820099:	cmpq   $0x0,0x310(%rbp)
  8200a1:	jne    8200bd <<gpui_gpu::renderer::RendererState>::render+0x1fed>
  8200a3:	mov    0x8(%rsp),%rax
  8200a8:	mov    0x10(%rax),%rax
  8200ac:	cmp    $0x1,%rax
  8200b0:	adc    $0x0,%rax
  8200b4:	shl    $0x4,%rax
  8200b8:	mov    %rax,0x10(%rsp)
  8200bd:	mov    0x8(%rsp),%rsi
  8200c2:	mov    0x28(%rsi),%rdx
  8200c6:	mov    0x40(%rsi),%rax
  8200ca:	cmp    $0x1,%rdx
  8200ce:	adc    $0x0,%rdx
  8200d2:	shl    $0x3,%rdx
  8200d6:	cmp    $0x1,%rax
  8200da:	adc    $0x0,%rax
  8200de:	mov    0x58(%rsi),%rcx
  8200e2:	cmp    $0x1,%rcx
  8200e6:	adc    $0x0,%rcx
  8200ea:	add    $0xb0,%rsi
  8200f1:	shl    $0x2,%rax
  8200f5:	shl    $0x5,%rcx
  8200f9:	movq   $0x0,0x110(%rsp)
  820105:	mov    0x58(%rsp),%rdi
  82010a:	mov    %rdi,0x118(%rsp)
  820112:	movq   $0x0,0x138(%rsp)
  82011e:	xorps  %xmm0,%xmm0
  820121:	movups %xmm0,0x120(%rsp)
  820129:	movl   $0x0,0x130(%rsp)
  820134:	mov    0x2b0(%rsp),%rdi
  82013c:	mov    %rdi,0x140(%rsp)
  820144:	movq   $0x0,0x148(%rsp)
  820150:	mov    0x10(%rsp),%rdi
  820155:	mov    %rdi,0x150(%rsp)
  82015d:	movl   $0x1,0x158(%rsp)
  820168:	movq   $0x0,0x160(%rsp)
  820174:	mov    0x38(%rsp),%rdi
  820179:	mov    %rdi,0x168(%rsp)
  820181:	movq   $0x0,0x170(%rsp)
  82018d:	mov    %rdx,0x178(%rsp)
  820195:	movl   $0x2,0x180(%rsp)
  8201a0:	movq   $0x0,0x188(%rsp)
  8201ac:	mov    0x218(%rsp),%rdx
  8201b4:	mov    %rdx,0x190(%rsp)
  8201bc:	movq   $0x0,0x198(%rsp)
  8201c8:	mov    %rax,0x1a0(%rsp)
  8201d0:	movl   $0x3,0x1a8(%rsp)
  8201db:	movq   $0x4,0x1b0(%rsp)
  8201e7:	mov    %rsi,0x1b8(%rsp)
  8201ef:	movl   $0x4,0x1d0(%rsp)
  8201fa:	movq   $0x0,0x1d8(%rsp)
  820206:	mov    0xe8(%rsp),%rax
  82020e:	mov    %rax,0x1e0(%rsp)
  820216:	movq   $0x0,0x1e8(%rsp)
  820222:	mov    %rcx,0x1f0(%rsp)
  82022a:	movl   $0x5,0x1f8(%rsp)
  820235:	lea    -0x74b359(%rip),%rax        # d4ee3 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x13d>
  82023c:	mov    %rax,0x318(%rsp)
  820244:	movq   $0xa,0x320(%rsp)
  820250:	mov    0x18(%rsp),%rax
  820255:	mov    %rax,0x300(%rsp)
  82025d:	lea    0x110(%rsp),%rax
  820265:	mov    %rax,0x308(%rsp)
  82026d:	movq   $0x6,0x310(%rsp)
  820279:	lea    0x300(%rsp),%rsi
  820281:	mov    0x108(%rsp),%r12
  820289:	mov    %r12,%rdi
  82028c:	call   *0x65f97e(%rip)        # e7fc10 <_DYNAMIC+0x5d8>
  820292:	mov    %rax,%r13
  820295:	mov    %rax,0x2d0(%rsp)
  82029d:	lea    0x2d0(%rsp),%rdx
  8202a5:	mov    %r12,%rdi
  8202a8:	mov    0x3e8(%rsp),%rsi
  8202b0:	call   81d290 <<gpui_gpu::renderer::GpuContext>::submit>
  8202b5:	mov    %rax,0x10(%rsp)
  8202ba:	xor    %ebp,%ebp
  8202bc:	mov    0x378(%rsp),%rax
  8202c4:	cmp    0x380(%rsp),%rax
  8202cc:	setne  %bpl
  8202d0:	shl    $0x1f,%ebp
  8202d3:	or     %r14d,%ebp
  8202d6:	shl    $0x20,%r15
  8202da:	or     %r15,%rbp
  8202dd:	mov    (%rbx),%rax
  8202e0:	test   %rax,%rax
  8202e3:	je     8202f4 <<gpui_gpu::renderer::RendererState>::render+0x2224>
  8202e5:	lock decq (%rax)
  8202e9:	jne    8202f4 <<gpui_gpu::renderer::RendererState>::render+0x2224>
  8202eb:	mov    %rbx,%rdi
  8202ee:	call   *0x65f85c(%rip)        # e7fb50 <_DYNAMIC+0x518>
  8202f4:	mov    0x8(%rsp),%rax
  8202f9:	mov    %r13,0x318(%rax)
  820300:	mov    %rbp,0x320(%rax)
  820307:	mov    0x10(%rax),%r9
  82030b:	mov    0x28(%rax),%rsi
  82030f:	mov    0x58(%rax),%rcx
  820313:	mov    %rcx,0x18(%rsp)
  820318:	shl    $0x4,%r9
  82031c:	mov    0xd0(%rsp),%rdx
  820324:	lea    (%r9,%rdx,4),%rdi
  820328:	lea    (%rdi,%rsi,8),%rsi
  82032c:	mov    %rcx,%rdi
  82032f:	shl    $0x5,%rdi
  820333:	lea    (%rdi,%rsi,1),%rcx
  820337:	add    $0x30,%rcx
  82033b:	mov    %rcx,0x58(%rsp)
  820340:	mov    0x138(%rax),%esi
  820346:	imul   %rsi,%rsi
  82034a:	mov    0x260(%rax),%r8
  820351:	add    0x238(%rax),%r8
  820358:	add    0x288(%rax),%r8
  82035f:	add    0x2b0(%rax),%r8
  820366:	add    0x2d8(%rax),%r8
  82036d:	mov    0x2f0(%rax),%rdi
  820374:	add    0x2f8(%rax),%rdi
  82037b:	mov    0xe0(%rsp),%r11
  820383:	mov    %r11,%rcx
  820386:	sub    %rdx,%rcx
  820389:	mov    0xb8(%rsp),%r10
  820391:	mov    %r10,%r12
  820394:	mov    0x208(%rsp),%rbp
  82039c:	sub    %rbp,%r12
  82039f:	mov    0x148(%rax),%rbx
  8203a6:	inc    %rbx
  8203a9:	mov    $0xffffffffffffffff,%r14
  8203b0:	cmovne %rbx,%r14
  8203b4:	mov    (%rax),%rbx
  8203b7:	shl    $0x4,%rbx
  8203bb:	mov    0x18(%rax),%r15
  8203bf:	lea    (%rbx,%r15,8),%rbx
  8203c3:	mov    0x30(%rax),%r15
  8203c7:	lea    (%rbx,%r15,4),%rbx
  8203cb:	mov    0x48(%rax),%r15
  8203cf:	shl    $0x5,%r15
  8203d3:	add    %rbx,%r15
  8203d6:	mov    0x120(%rax),%rbx
  8203dd:	mov    0x118(%rax),%r13
  8203e4:	mov    %r14,0x148(%rax)
  8203eb:	mov    %r10,0x150(%rax)
  8203f2:	lea    (%r11,%r11,1),%r14
  8203f6:	mov    %r14,0x158(%rax)
  8203fd:	movq   $0x1,0x160(%rax)
  820408:	mov    %r10,0x168(%rax)
  82040f:	mov    %rdx,0x170(%rax)
  820416:	mov    %r11,0x178(%rax)
  82041d:	mov    %rcx,0x180(%rax)
  820424:	mov    0x60(%rsp),%rcx
  820429:	mov    %rcx,0x188(%rax)
  820430:	mov    0x50(%rsp),%rcx
  820435:	mov    %rcx,0x190(%rax)
  82043c:	mov    0x80(%rsp),%rcx
  820444:	mov    %rcx,0x198(%rax)
  82044b:	mov    0x58(%rsp),%rcx
  820450:	mov    %rcx,0x1a0(%rax)
  820457:	mov    %r9,0x1a8(%rax)
  82045e:	mov    0x200(%rsp),%rdx
  820466:	mov    %rdx,0x1b0(%rax)
  82046d:	mov    %rbp,0x1b8(%rax)
  820474:	mov    %r12,0x1c0(%rax)
  82047b:	mov    0x3b0(%rsp),%rcx
  820483:	mov    %rcx,0x1c8(%rax)
  82048a:	mov    %r8,0x1d0(%rax)
  820491:	mov    %rsi,0x1d8(%rax)
  820498:	add    %rbx,%r13
  82049b:	mov    %rbx,0x1e0(%rax)
  8204a2:	mov    %r13,0x1e8(%rax)
  8204a9:	mov    %r15,0x1f0(%rax)
  8204b0:	mov    0x18(%rsp),%rcx
  8204b5:	mov    %rcx,0x1f8(%rax)
  8204bc:	mov    %rdi,0x200(%rax)
  8204c3:	movb   $0x0,0x208(%rax)
  8204ca:	mov    0x30(%rsp),%rdi
  8204cf:	mov    0x10(%rsp),%rax
  8204d4:	mov    %rax,0x8(%rdi)
  8204d8:	movl   $0xffffffff,(%rdi)
  8204de:	jmp    81e1e1 <<gpui_gpu::renderer::RendererState>::render+0x111>
  8204e3:	mov    0x30(%rsp),%rdi
  8204e8:	jmp    81e1d3 <<gpui_gpu::renderer::RendererState>::render+0x103>
  8204ed:	lea    0x60dc5c(%rip),%rdi        # e2e150 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x38>
  8204f4:	call   *0x65f71e(%rip)        # e7fc18 <_DYNAMIC+0x5e0>
  8204fa:	lea    -0x74b639(%rip),%rdi        # d4ec8 <anon.1add4a29f827c591dd1953eebb581508.0.llvm.16250067668830351554+0x122>
  820501:	lea    0x60dc30(%rip),%rdx        # e2e138 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x20>
  820508:	mov    $0x37,%esi
  82050d:	call   *0x65f43d(%rip)        # e7f950 <_DYNAMIC+0x318>
  820513:	lea    0x60dc4e(%rip),%rdx        # e2e168 <anon.1add4a29f827c591dd1953eebb581508.6.llvm.16250067668830351554+0x50>
  82051a:	call   *0x65f610(%rip)        # e7fb30 <_DYNAMIC+0x4f8>
  820520:	mov    %rax,%r14
  820523:	mov    0x8(%rsp),%rax
  820528:	mov    %r13,0x318(%rax)
  82052f:	mov    %rbp,0x320(%rax)
  820536:	mov    %r14,%rdi
  820539:	call   e2c420 <_Unwind_Resume@plt>
  82053e:	mov    %rax,%r14
  820541:	lock decq 0x0(%r13)
  820546:	jne    820568 <<gpui_gpu::renderer::RendererState>::render+0x2498>
  820548:	lea    0x2d0(%rsp),%rdi
  820550:	call   *0x65f5fa(%rip)        # e7fb50 <_DYNAMIC+0x518>
  820556:	jmp    820568 <<gpui_gpu::renderer::RendererState>::render+0x2498>
  820558:	call   *0x65f32a(%rip)        # e7f888 <_DYNAMIC+0x250>
  82055e:	mov    %rax,%r14
  820561:	movq   $0x0,(%rbx)
  820568:	mov    %r14,%rdi
  82056b:	call   e2c420 <_Unwind_Resume@plt>
