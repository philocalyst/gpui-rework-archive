# Matched CPU and shader bill

The primary library rustc argument vectors are exactly equal: same source path,
lock/features, Rust/Cargo 1.97.1, opt3, root v0/tokio and emit-stack-sizes once.
Actual library/groups artifacts are fresh:false in each lane. Default .text is
6403991 -> 6403623 (-368); .rodata 7012024 -> 7012152 (+128); .data.rel.ro
336384 -> 336336 (-48). Offline .text also falls 368; offline .rodata is unchanged.
Complete alias/unpaired-symbol ledgers and whole ELF sections are retained.

Render body 9493/frame 1416 -> 9376/frame 1400 (-117/-16); bin_draw 4184/frame 824 ->
4056/frame 792 (-128/-32). Constructor falls 27 bytes and state drop glue falls 81.
Unfavorable reverse visit grows 611 -> 622 bytes (+11), though its static frame
falls 88 -> 72. No isolated helper/caller sums are claimed as whole linked size,
peak stack or a dynamic call chain. Actual core LOC 30692 -> 30704 (+12).

Baseline reverse visit retains the cursor-vector length/data loads and reverse
ordinal comparison before its four-byte range-start decrement/store. Candidate
81c78c..81c794 loads/tests y and skips uniform tags BEFORE cursor interpretation.
81c796..81c7ab decodes remaining via a 23-bit shift and a 14-bit shift/mask/OR;
81c7af..81c7ba masks immutable start, adds remaining and subtracts one. The actual
overflowing_sub lowering at 81c7be..81c7d9 subtracts 0x800000 from x, stores 32 bits,
uses setae (inverted borrow), shift 23 and additions to conditionally decrement
high cursor bits, then stores y's 32 bits. These extra operations/two stores and
the helper's 11-byte growth are charged; no instruction-latency inference follows.
Full matched reverse/render/bin_draw disassembly remains. Render integer division
from the old final statistics walk is gone; existing bin_draw divisions remain.

The entire shipping shader source, generated 15180-byte WGSL and all eight validated
SPIR-V artifacts are BYTE-IDENTICAL, including every fragment/vertex variant.
Direct compare of sizes/hashes/opcode histograms is asserted. There is no new GPU
decoder, integer mask/shift/add, branch, layout, floating operation or conversion
walk. This is artifact identity, not native hardware timing or a universal speed
claim. The inherited shipping floating/opaque-proof contract is unchanged.
