from pathlib import Path
import csv, hashlib, json, os, re, shutil, subprocess
ROOT=Path('/tmp/gpui-endpoint-csr-sol'); OUT=Path('/tmp/gpui-endpoint-csr-evidence')
REFERENCE=Path('/tmp/gpui-gpu-frontier-evidence/calibration/pair-00-A')
FIXTURE=Path('/tmp/gpui-gpu-frontier-evidence/source/qualification.rs')
SOURCE=ROOT/'reactivity/crates/gpu/examples/qualification.rs'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(FIXTURE)=='8773146b44150adb0150323d51f241c946fb5cda26328f004562dcd9dee39cc0'
assert not SOURCE.exists()
env=dict(os.environ);env.pop('RUSTFLAGS',None);env.pop('CARGO_ENCODED_RUSTFLAGS',None)
env.update(CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR='/tmp/gpui-endpoint-csr-target')
result={'source':'6bf679e2b2fe175d87eddeea7e4f7362f042bf17','fixture_sha256':sha(FIXTURE),
        'scope':'One two-frame public-API functional process; calibration clocks retained but no performance claims.'}
try:
    shutil.copy2(FIXTURE,SOURCE)
    args=['cargo','build','--release','--offline','--locked','-p','gpui_gpu','--example','qualification','--features','vulkan-tests','--message-format=json']
    with (OUT/'functional-cargo.jsonl').open('w') as stdout,(OUT/'functional-cargo.log').open('w') as stderr:
        subprocess.run(args,cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,check=True)
    artifacts=[json.loads(x) for x in (OUT/'functional-cargo.jsonl').read_text().splitlines() if x.startswith('{')]
    artifact=next(a for a in artifacts if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='qualification')
    assert not artifact['fresh'] and artifact['profile']['opt_level']=='3'
    executable=OUT/'qualification';shutil.copy2(artifact['executable'],executable);executable.chmod(0o555)
    result.update(artifact=artifact,binary_sha256=sha(executable))
    capture=OUT/'public-calibration'
    with (OUT/'functional.stdout').open('w') as stdout,(OUT/'functional.stderr').open('w') as stderr:
        p=subprocess.run([str(executable),str(capture),'calibration'],cwd=ROOT/'reactivity',env=env,stdout=stdout,stderr=stderr,timeout=180)
    result['returncode']=p.returncode;assert p.returncode==0
    files=sorted(capture.glob('*.bin'));assert len(files)==52
    result['readbacks']=[]
    for f in files:
        assert f.read_bytes()==(REFERENCE/f.name).read_bytes(),f.name
        result['readbacks'].append({'path':f.name,'bytes':f.stat().st_size,'sha256':sha(f)})
    assert (capture/'adapter.txt').read_bytes()==(REFERENCE/'adapter.txt').read_bytes()
    def rows(directory):
        return {(r['case'],r['hdr'],r['motion'],r['frame']):r for r in csv.DictReader((directory/'frames.csv').open())}
    reference=rows(REFERENCE);actual=rows(capture);assert reference.keys()==actual.keys()
    changes=[]
    for key,row in actual.items():
        for name in ['stats','image_stats']:
            def fields(s): return dict(re.findall(r'(\w+): ([^,}]+)',s))
            before=fields(reference[key][name]);after=fields(row[name]);assert before.keys()==after.keys()
            delta={k:{'shipping':before[k],'packed_candidate':after[k]} for k in before if before[k]!=after[k]}
            if name == 'stats':
                capacity = delta.pop('cpu_index_capacity_bytes')
                assert int(capacity['shipping']) - int(capacity['packed_candidate']) == 512 * 4, (key, capacity)
            if delta: changes.append({'cell_frame':key,'diagnostic':name,'fields':delta})
    assert not changes, changes
    result['all_work_stats_and_image_stats_exact']=True
    result['charged_cpu_index_capacity_removed_bytes_per_frame']=2048
    result['diagnostic_differences']=changes
    result['exact_readback_bytes']=sum(x['bytes'] for x in result['readbacks'])
finally:
    SOURCE.unlink(missing_ok=True)
    result['temporary_fixture_removed']=not SOURCE.exists()
    (OUT/'functional-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'readbacks':len(result.get('readbacks',[])),'bytes':result.get('exact_readback_bytes'),'diagnostic_difference_rows':len(result.get('diagnostic_differences',[]))},indent=2))
