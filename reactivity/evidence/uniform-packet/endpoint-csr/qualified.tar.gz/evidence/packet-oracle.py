from pathlib import Path
import hashlib,json,struct
CG=Path('/tmp/gpui-endpoint-csr-codegen');OUT=Path('/tmp/gpui-endpoint-csr-evidence')
KEY='qualified_gpu_retained_count_65536_uses_the_seventeenth_bit'
expected_refs=b''.join(struct.pack('<I',0x80000000|6*ordinal) for ordinal in range(65536))
def check_probe(tiles,references):
 assert tiles==struct.pack('<II',0,65536), 'exact completed shipping endpoints'
 assert references==expected_refs, 'exact complete forward inline word-address stream'
# Deterministic analyzer controls use local copies; no frozen payload is mutated.
for tiles,refs in [(struct.pack('<II',0,65535),expected_refs),(struct.pack('<II',0,65536),struct.pack('<I',0x80000001)+expected_refs[4:])]:
 try:check_probe(tiles,refs)
 except AssertionError:pass
 else:raise AssertionError('packet analyzer accepted injected corruption')
report={'analyzer_negative_controls':{'one_wrong_endpoint_detected':True,'one_wrong_reference_detected':True},'lanes':{},
        'scope':'Actual current eligible CPU packet, which can differ from the queued GPU target being read. Pixel/work comparisons retain every frame including explicitly ineligible scratch.'}
for label in ['baseline','candidate']:
 manifest=json.loads((CG/label/'named-readbacks/manifest.json').read_text())
 packets=manifest['packets'];first=packets[KEY+'/0/1x1/Rgba16Float'];empty=packets[KEY+'/1/1x1/Rgba16Float']
 assert first['eligible'] and empty['eligible']
 for packet in [first,empty]:
  for lane in ['tiles','references']:
   path=Path(packet[lane]['path']);assert path.is_relative_to(CG/label/'named-readbacks')
   assert hashlib.sha256(path.read_bytes()).hexdigest()==packet[lane]['sha256']
 check_probe(Path(first['tiles']['path']).read_bytes(),Path(first['references']['path']).read_bytes())
 assert Path(empty['tiles']['path']).read_bytes()==struct.pack('<II',0,0)
 assert Path(empty['references']['path']).read_bytes()==b''
 report['lanes'][label]={'eligible_packets':sum(p['eligible'] for p in packets.values()),'no_packet_scratch_frames':sum(not p['eligible'] for p in packets.values()),
                         'probe_exact_endpoints':[0,65536],'probe_exact_forward_inline_references':65536,'empty_packet_exact':True}
assert report['lanes']['baseline']==report['lanes']['candidate']
(OUT/'packet-oracle.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
