from pathlib import Path
OLD=Path('/tmp/gpui-packed-csr-evidence');NEW=Path('/tmp/gpui-endpoint-csr-evidence')
PIN='6bf679e2b2fe175d87eddeea7e4f7362f042bf17'
for name in ['functional.py','negative-control.py','negative-selection.py','codegen.py','cost-ledger.py','shader-ledger.py','source-audit.py']:
 s=(OLD/name).read_text().replace('gpui-packed-csr','gpui-endpoint-csr').replace('5559828a4f6d093401cc374654f634b4d8fb9ddb',PIN)
 if name=='negative-selection.py':
  s=s.replace("needle=b'let index = (packed & TILE_START_MASK) + u64::from(remaining) - 1;'", "needle=b'let index = (range[0] & TILE_ENDPOINT_MASK) + remaining - 1;'")
  s=s.replace("b'let count = (packed >> TILE_COUNT_SHIFT) as u32 & TILE_COUNT_MASK;\\n    let index = (packed & TILE_START_MASK) + u64::from(count - remaining);'", "b'let count = (range[1] & TILE_ENDPOINT_MASK) - (range[0] & TILE_ENDPOINT_MASK);\\n    let index = (range[0] & TILE_ENDPOINT_MASK) + count - remaining;'")
 if name=='shader-ledger.py':
  s=s.replace("report['explicit_new_decode_operations']=['AND start mask','logical right shift8','AND count mask','ADD start+count']", "report['explicit_new_decode_operations']=[]\nassert report['lanes']['baseline']==report['lanes']['candidate'], 'shipping shader artifacts must be exactly identical'")
 if name=='source-audit.py':
  s=s.replace("checks['only_two_production_files_changed']=set(changed)=={'reactivity/crates/gpu/src/renderer.rs','reactivity/crates/gpu/src/shader.rs','reactivity/crates/gpu/tests/render.rs'}", "checks['only_renderer_production_changed']=set(changed)=={'reactivity/crates/gpu/src/renderer.rs','reactivity/crates/gpu/tests/render.rs'}\nchecks['entire_shader_source_byte_identical']=sa==sb\nprior=source('5559828a4f6d093401cc374654f634b4d8fb9ddb','src/renderer.rs')\nchecks['forward_normalization_reverse_upload_unchanged_from555']=region(prior,'        let mut offset = 0;','        let (tone, exposure)')==region(b,'        let mut offset = 0;','        let (tone, exposure)')")
  s=s.replace("'shader_decode_source_operations':['AND start mask','shift right 8','AND count mask','ADD start+count']", "'shader_decode_source_operations':[]")
  s=s.replace('Private tile bit encoding changes together on CPU/GPU; its width stays8B.', 'Transient CPU spare bits exhaust into the original shipping8B [start,end] words; shader byte-identical.')
 (NEW/name).write_text(s)
for name in ['codegen.toml','max-count-probe.rs']:(NEW/name).write_bytes((OLD/name).read_bytes())
s=(OLD/'named_capture.py').read_text().replace('gpui-packed-csr','gpui-endpoint-csr')
s=s.replace("local=dict(env);local['GPUI_NAMED_PIXEL_CAPTURE']", "local=dict(env);local.pop('RUSTC_BOOTSTRAP',None);local['GPUI_NAMED_PIXEL_CAPTURE']")
s=s.replace('timeout=180','timeout=360')
s=s.replace("'max_count_probe_sha256':hashlib.sha256(probe).hexdigest()", "'max_count_probe_sha256':hashlib.sha256(probe).hexdigest(),'functional_watchdog_seconds':360")
old="+cursor+b', self.state.residuals.capacity() * 32] } }\\n')"
new="+cursor+b', self.state.residuals.capacity() * 32] } pub fn qualification_packet(&self) -> Option<(&[[u32; 2]], &[u32])> { self.state.packet.as_ref().map(|_| (self.state.ranges.as_slice(), self.state.references.as_slice())) } }\\n')"
assert s.count(old)==1;s=s.replace(old,new)
needle='''        std::fs::write(directory.join(format!("{index:04}-{name}-{width}x{height}-{:?}.cursor", renderer.format())), format!("{:?}", renderer.qualification_capacities())).unwrap();'''
assert s.count(needle)==1
s=s.replace(needle,needle+'''
        let stem = format!("{index:04}-{name}-{width}x{height}-{:?}", renderer.format());
        if let Some((tiles, references)) = renderer.qualification_packet() {
            std::fs::write(directory.join(format!("{stem}.tiles")), bytemuck::cast_slice(tiles)).unwrap();
            std::fs::write(directory.join(format!("{stem}.references")), bytemuck::cast_slice(references)).unwrap();
            std::fs::write(directory.join(format!("{stem}.eligible")), b"yes").unwrap();
        } else {
            std::fs::write(directory.join(format!("{stem}.eligible")), b"no").unwrap();
        }''')
s=s.replace('files={};counts={};diagnostics={};capacities={}', 'files={};counts={};diagnostics={};capacities={};packets={}')
needle="            capacities[key]={'path':str(cursor),'components':json.loads(cursor.read_text())}"
assert s.count(needle)==1
s=s.replace(needle,needle+'''
            status=path.with_suffix('.eligible').read_bytes();assert status in [b'yes',b'no']
            packet={'eligible':status==b'yes'}
            for suffix,stride in [('tiles',8),('references',4)]:
                data=path.with_suffix('.'+suffix)
                if packet['eligible']:
                    assert data.exists() and data.stat().st_size%stride==0
                    packet[suffix]={'path':str(data),'bytes':data.stat().st_size,'sha256':hashlib.sha256(data.read_bytes()).hexdigest()}
                else:
                    assert not data.exists()
            packets[key]=packet''')
s=s.replace('current_scratch_capacities=capacities,','current_scratch_capacities=capacities,packets=packets,')
(NEW/'named_capture.py').write_text(s)
# Compare every actual admitted CPU packet, never an unpublishable failed scratch lane.
p=NEW/'codegen.py';s=p.read_text();needle="    assert normalize(before)==normalize(after),('work_stats',key)";assert s.count(needle)==1
s=s.replace(needle,needle+'''
    old_packet=a['packets'][key];new_packet=b['packets'][key]
    assert old_packet['eligible']==new_packet['eligible'],('packet_eligibility',key)
    if old_packet['eligible']:
        for lane in ['tiles','references']:
            assert Path(old_packet[lane]['path']).read_bytes()==Path(new_packet[lane]['path']).read_bytes(),('actual_CPU_packet',lane,key)
''')
needle="        'comparisons':comparisons}"
assert s.count(needle)==1
s=s.replace(needle,"""        'comparisons':comparisons,
        'actual_CPU_eligible_packets_exact':sum(x['eligible'] for x in a['packets'].values()),
        'no_packet_scratch_frames_labelled':sum(not x['eligible'] for x in a['packets'].values()),
        'actual_CPU_tile_reference_bytes_per_lane':sum(x[lane]['bytes'] for x in a['packets'].values() if x['eligible'] for lane in ['tiles','references'])}""")
p.write_text(s)
