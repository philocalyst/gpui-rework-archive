# Endpoint spare bits: independent proof and publication audit

New isolated successor to sealed5559828a4f6d093401cc374654f634b4d8fb9ddb.
Keep the complete shipping7a5e shader byte for byte; no zero-reference traversal
skip or unrelated formulation. Retain555's cursor-vector/cutoff deletion and
single normalization counter path. All source/records/validation/proof/resource
behavior outside the private sampled-tile representation stays unchanged.

## Representation and induction

Let B=2^23, start/end in[0,MAX_REFERENCES], start<=end, c=end-start<=65536.
Each inclusive endpoint needs23 bits because MAX_REFERENCES=4194304. Remaining
needs17 bits including65536.2*23+17+1=64: x holds start low23 and remaining low9;
y holds end low23, remaining high8 in bits23..30, and uniform tag bit31.

Normalize nonuniform tiles to x=start|(c<<23),
y=end|((c>>9)<<23), with end=start+c. Rust u32 left shift intentionally retains
only c's low9 bits in x. Inputs satisfy endpoint caps before construction.
MAX_DRAWS65536 makes remaining high8 at most128, so ybit31 is clear.
A uniform tile remains exactly[address,UNIFORM_TILE], including INLINE_RECORD in
xbit31. Always check y's uniform tag before cursor decode or subtraction.

For nonuniform words, remaining=(x>>23)|((y>>23)<<9). The high expression is safe
without an additional mask precisely because ybit31 is clear. If remaining0,
return None and leave both words unchanged. Otherwise index=(x&(B-1))+remaining-1
is in[start,end), and the retained-suffix theorem selects the same next reverse
address as shipping. Set(next_x,borrow)=x.overflowing_sub(B), and subtract
u32::from(borrow)<<23 from y. Use overflowing_sub directly, not signed casts.

If remainingLow9>0, x>=B and borrow is false; subtraction decrements that field
while retaining start. If remainingLow9==0, x=start<B, so unsigned subtraction
wraps to start|511<<23 and borrow is true. remaining>0 then implies high8>0:
subtracting B from y decrements only that high field, without borrowing into end
or changing uniform tag. Thus the mixed-radix cursor decreases exactly by one,
while both immutable endpoints survive every step. At exhaustion both spare
fields are zero, and the words are EXACTLY the original shipping[start,end].
No shader decoder or final conversion/statistics pass is necessary.

The proof covers start=end=4194304 (empty, no dereference), last occupied end at
4194304, c511/512 transitions,65535 and65536, repeated carries every512 pops,
multiple opaque resets, c1 without proof, c1 uniform, partial/nonvisiting draws,
proof-disable and all source variants. Index bounds derive from original logical
visit admission, which is preserved before filtering. Per-draw injective visits
bound c by MAX_DRAWS. Uniform alternate interpretation never enters this proof.

## Every publication/replay/patch route

RendererState::render delegates to private render_observed. Its context check and
entry packet revocation precede scratch preparation. Forward validation, packing,
original visit cap and existing full_tile proofs are unchanged. Normalization
builds transient words; the complete reverse group/placement/visit traversal stays
and consumes exactly c visits per nonuniform tile. No hidden early exit is added.
The suffix theorem from the sealed555 proof establishes full exhaustion.

The only self.tiles.write is after this completed reverse pass and tone/profile
admission, alongside records/references/corrections uploads. Binding creation and
context.submit follow; only then is packet Some and the full Stats published.
Errors before this point cannot publish partially transient endpoints or replace
last-successful Stats. A later render clears/resizes the entire ranges array.
Queued earlier GPU submissions retain ordinary queue ordering/leases; CPU scratch
mutation alone does not change the previously uploaded tile buffer.

redraw reads the retained successful Packet/bindings and makes no tile/reference
write. Wrong-target rejection preserves the valid packet; invalid diagnostic mode
changes revoke it. prepare_slots only checks a banked admitted packet and paint
edits. GpuSlotCommit takes that packet, writes only draw-bank colors, submits and
restores it; no ranges/references change. PaintRenderer full render uses the same
render_observed; its paint commit similarly takes the admitted packet, writes only
draw color words, submits and restores it. Proof-invalidating alpha/exceptional
opaque RGB edits retain the existing rejection behavior. Owned convenience API
only delegates to these paths. No public entry writes a caller-supplied tile packet.

Therefore every successful upload sees exhausted original words; replay and all
paint routes retain those words. No mutable PreparedScene header is trusted as
an identity; all existing target/header/per-draw checks remain. No new retained
field, allocation, dependency, unsafe code, source exception or SIMD policy fork.
The shipping float predicate/kernel contract is inherited, not strengthened.

## Frozen qualification intent before execution

Actual helpers and binning oracle retain boundary and wrong-order/count controls.
Independently exercise511,512,65535,65536 and end4194304; assert low endpoints on
every decrement and exact final[start,end]. Default/fallback/offline strict gates
and Apple/Windows library compilation remain. The original8773146... public
fixture stays unchanged; all52 named images and work counters compare to frozen
shipping with the intended deleted-cursor capacity charge explicit.

The same47 committed integration tests plus the identical1x1 HDR maxcount probe
will run in both source lanes. The nonshipping observer will also capture actual
final tile/reference bytes only when the private successful packet is eligible.
Eligibility/None must match in both lanes; no-packet frames still compare all
pixels/work counters and are explicitly labelled as unpublishable scratch.
Observe capacity components/object layout separately. Because these extra files
increase observer I/O, preregister360s for BOTH full named-capture processes before
any new capture starts. This is a functional watchdog, not a performance gate;
no retry/drop or adaptive timeout change. Calibration clocks remain unqualified.

Same-path locked/opt3/Rust1.97.1/root v0/tokio builds will preserve fresh:false
matched groups ELFs; emit-stack-sizes exactly once for static qualification.
Charge actual CPU shift/OR/mask/borrow/store code, full callers/helpers/frames,
whole linked sections and exact core count. Generated WGSL plus all offline
fragment/vertex artifacts must be byte-identical to shipping, verified directly.
No timing campaign, runtime speed or universal-layout assertion is authorized.
